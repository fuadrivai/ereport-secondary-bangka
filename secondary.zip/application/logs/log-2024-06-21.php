<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-21 08:09:31 --> Config Class Initialized
INFO - 2024-06-21 08:09:31 --> Hooks Class Initialized
DEBUG - 2024-06-21 08:09:31 --> UTF-8 Support Enabled
INFO - 2024-06-21 08:09:31 --> Utf8 Class Initialized
INFO - 2024-06-21 08:09:31 --> URI Class Initialized
INFO - 2024-06-21 08:09:31 --> Router Class Initialized
INFO - 2024-06-21 08:09:31 --> Output Class Initialized
INFO - 2024-06-21 08:09:31 --> Security Class Initialized
DEBUG - 2024-06-21 08:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 08:09:31 --> Input Class Initialized
INFO - 2024-06-21 08:09:31 --> Language Class Initialized
INFO - 2024-06-21 08:09:31 --> Language Class Initialized
INFO - 2024-06-21 08:09:31 --> Config Class Initialized
INFO - 2024-06-21 08:09:31 --> Loader Class Initialized
INFO - 2024-06-21 08:09:31 --> Helper loaded: url_helper
INFO - 2024-06-21 08:09:31 --> Helper loaded: file_helper
INFO - 2024-06-21 08:09:31 --> Helper loaded: form_helper
INFO - 2024-06-21 08:09:31 --> Helper loaded: my_helper
INFO - 2024-06-21 08:09:31 --> Database Driver Class Initialized
INFO - 2024-06-21 08:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 08:09:31 --> Controller Class Initialized
DEBUG - 2024-06-21 08:09:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-21 08:09:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 08:09:31 --> Final output sent to browser
DEBUG - 2024-06-21 08:09:31 --> Total execution time: 0.0575
INFO - 2024-06-21 08:09:38 --> Config Class Initialized
INFO - 2024-06-21 08:09:38 --> Hooks Class Initialized
DEBUG - 2024-06-21 08:09:38 --> UTF-8 Support Enabled
INFO - 2024-06-21 08:09:38 --> Utf8 Class Initialized
INFO - 2024-06-21 08:09:38 --> URI Class Initialized
INFO - 2024-06-21 08:09:38 --> Router Class Initialized
INFO - 2024-06-21 08:09:38 --> Output Class Initialized
INFO - 2024-06-21 08:09:38 --> Security Class Initialized
DEBUG - 2024-06-21 08:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 08:09:38 --> Input Class Initialized
INFO - 2024-06-21 08:09:38 --> Language Class Initialized
INFO - 2024-06-21 08:09:38 --> Language Class Initialized
INFO - 2024-06-21 08:09:38 --> Config Class Initialized
INFO - 2024-06-21 08:09:38 --> Loader Class Initialized
INFO - 2024-06-21 08:09:38 --> Helper loaded: url_helper
INFO - 2024-06-21 08:09:38 --> Helper loaded: file_helper
INFO - 2024-06-21 08:09:38 --> Helper loaded: form_helper
INFO - 2024-06-21 08:09:38 --> Helper loaded: my_helper
INFO - 2024-06-21 08:09:38 --> Database Driver Class Initialized
INFO - 2024-06-21 08:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 08:09:38 --> Controller Class Initialized
INFO - 2024-06-21 08:09:38 --> Helper loaded: cookie_helper
INFO - 2024-06-21 08:09:38 --> Final output sent to browser
DEBUG - 2024-06-21 08:09:38 --> Total execution time: 0.0371
INFO - 2024-06-21 08:09:38 --> Config Class Initialized
INFO - 2024-06-21 08:09:38 --> Hooks Class Initialized
DEBUG - 2024-06-21 08:09:38 --> UTF-8 Support Enabled
INFO - 2024-06-21 08:09:38 --> Utf8 Class Initialized
INFO - 2024-06-21 08:09:38 --> URI Class Initialized
INFO - 2024-06-21 08:09:38 --> Router Class Initialized
INFO - 2024-06-21 08:09:38 --> Output Class Initialized
INFO - 2024-06-21 08:09:38 --> Security Class Initialized
DEBUG - 2024-06-21 08:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 08:09:38 --> Input Class Initialized
INFO - 2024-06-21 08:09:38 --> Language Class Initialized
INFO - 2024-06-21 08:09:38 --> Language Class Initialized
INFO - 2024-06-21 08:09:38 --> Config Class Initialized
INFO - 2024-06-21 08:09:38 --> Loader Class Initialized
INFO - 2024-06-21 08:09:38 --> Helper loaded: url_helper
INFO - 2024-06-21 08:09:38 --> Helper loaded: file_helper
INFO - 2024-06-21 08:09:38 --> Helper loaded: form_helper
INFO - 2024-06-21 08:09:38 --> Helper loaded: my_helper
INFO - 2024-06-21 08:09:38 --> Database Driver Class Initialized
INFO - 2024-06-21 08:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 08:09:38 --> Controller Class Initialized
DEBUG - 2024-06-21 08:09:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-21 08:09:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 08:09:38 --> Final output sent to browser
DEBUG - 2024-06-21 08:09:38 --> Total execution time: 0.0417
INFO - 2024-06-21 08:57:03 --> Config Class Initialized
INFO - 2024-06-21 08:57:03 --> Hooks Class Initialized
DEBUG - 2024-06-21 08:57:03 --> UTF-8 Support Enabled
INFO - 2024-06-21 08:57:03 --> Utf8 Class Initialized
INFO - 2024-06-21 08:57:03 --> URI Class Initialized
INFO - 2024-06-21 08:57:03 --> Router Class Initialized
INFO - 2024-06-21 08:57:03 --> Output Class Initialized
INFO - 2024-06-21 08:57:03 --> Security Class Initialized
DEBUG - 2024-06-21 08:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 08:57:03 --> Input Class Initialized
INFO - 2024-06-21 08:57:03 --> Language Class Initialized
INFO - 2024-06-21 08:57:03 --> Language Class Initialized
INFO - 2024-06-21 08:57:03 --> Config Class Initialized
INFO - 2024-06-21 08:57:03 --> Loader Class Initialized
INFO - 2024-06-21 08:57:03 --> Helper loaded: url_helper
INFO - 2024-06-21 08:57:03 --> Helper loaded: file_helper
INFO - 2024-06-21 08:57:03 --> Helper loaded: form_helper
INFO - 2024-06-21 08:57:03 --> Helper loaded: my_helper
INFO - 2024-06-21 08:57:03 --> Database Driver Class Initialized
INFO - 2024-06-21 08:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 08:57:03 --> Controller Class Initialized
DEBUG - 2024-06-21 08:57:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-21 08:57:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 08:57:03 --> Final output sent to browser
DEBUG - 2024-06-21 08:57:03 --> Total execution time: 0.0840
INFO - 2024-06-21 08:57:12 --> Config Class Initialized
INFO - 2024-06-21 08:57:12 --> Hooks Class Initialized
DEBUG - 2024-06-21 08:57:12 --> UTF-8 Support Enabled
INFO - 2024-06-21 08:57:12 --> Utf8 Class Initialized
INFO - 2024-06-21 08:57:12 --> URI Class Initialized
INFO - 2024-06-21 08:57:12 --> Router Class Initialized
INFO - 2024-06-21 08:57:12 --> Output Class Initialized
INFO - 2024-06-21 08:57:12 --> Security Class Initialized
DEBUG - 2024-06-21 08:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 08:57:12 --> Input Class Initialized
INFO - 2024-06-21 08:57:12 --> Language Class Initialized
INFO - 2024-06-21 08:57:12 --> Language Class Initialized
INFO - 2024-06-21 08:57:12 --> Config Class Initialized
INFO - 2024-06-21 08:57:12 --> Loader Class Initialized
INFO - 2024-06-21 08:57:12 --> Helper loaded: url_helper
INFO - 2024-06-21 08:57:12 --> Helper loaded: file_helper
INFO - 2024-06-21 08:57:12 --> Helper loaded: form_helper
INFO - 2024-06-21 08:57:12 --> Helper loaded: my_helper
INFO - 2024-06-21 08:57:12 --> Database Driver Class Initialized
INFO - 2024-06-21 08:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 08:57:12 --> Controller Class Initialized
ERROR - 2024-06-21 08:57:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3014
ERROR - 2024-06-21 08:57:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3015
DEBUG - 2024-06-21 08:57:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-21 08:57:16 --> Final output sent to browser
DEBUG - 2024-06-21 08:57:16 --> Total execution time: 4.1974
INFO - 2024-06-21 09:43:45 --> Config Class Initialized
INFO - 2024-06-21 09:43:45 --> Hooks Class Initialized
DEBUG - 2024-06-21 09:43:45 --> UTF-8 Support Enabled
INFO - 2024-06-21 09:43:45 --> Utf8 Class Initialized
INFO - 2024-06-21 09:43:45 --> URI Class Initialized
INFO - 2024-06-21 09:43:45 --> Router Class Initialized
INFO - 2024-06-21 09:43:45 --> Output Class Initialized
INFO - 2024-06-21 09:43:45 --> Security Class Initialized
DEBUG - 2024-06-21 09:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 09:43:45 --> Input Class Initialized
INFO - 2024-06-21 09:43:45 --> Language Class Initialized
INFO - 2024-06-21 09:43:45 --> Language Class Initialized
INFO - 2024-06-21 09:43:45 --> Config Class Initialized
INFO - 2024-06-21 09:43:45 --> Loader Class Initialized
INFO - 2024-06-21 09:43:45 --> Helper loaded: url_helper
INFO - 2024-06-21 09:43:45 --> Helper loaded: file_helper
INFO - 2024-06-21 09:43:45 --> Helper loaded: form_helper
INFO - 2024-06-21 09:43:45 --> Helper loaded: my_helper
INFO - 2024-06-21 09:43:45 --> Database Driver Class Initialized
INFO - 2024-06-21 09:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 09:43:45 --> Controller Class Initialized
DEBUG - 2024-06-21 09:43:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-21 09:43:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 09:43:45 --> Final output sent to browser
DEBUG - 2024-06-21 09:43:45 --> Total execution time: 0.0782
INFO - 2024-06-21 09:44:27 --> Config Class Initialized
INFO - 2024-06-21 09:44:27 --> Hooks Class Initialized
DEBUG - 2024-06-21 09:44:27 --> UTF-8 Support Enabled
INFO - 2024-06-21 09:44:27 --> Utf8 Class Initialized
INFO - 2024-06-21 09:44:27 --> URI Class Initialized
INFO - 2024-06-21 09:44:27 --> Router Class Initialized
INFO - 2024-06-21 09:44:27 --> Output Class Initialized
INFO - 2024-06-21 09:44:27 --> Security Class Initialized
DEBUG - 2024-06-21 09:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 09:44:27 --> Input Class Initialized
INFO - 2024-06-21 09:44:27 --> Language Class Initialized
INFO - 2024-06-21 09:44:27 --> Language Class Initialized
INFO - 2024-06-21 09:44:27 --> Config Class Initialized
INFO - 2024-06-21 09:44:27 --> Loader Class Initialized
INFO - 2024-06-21 09:44:27 --> Helper loaded: url_helper
INFO - 2024-06-21 09:44:27 --> Helper loaded: file_helper
INFO - 2024-06-21 09:44:27 --> Helper loaded: form_helper
INFO - 2024-06-21 09:44:27 --> Helper loaded: my_helper
INFO - 2024-06-21 09:44:27 --> Database Driver Class Initialized
INFO - 2024-06-21 09:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 09:44:27 --> Controller Class Initialized
INFO - 2024-06-21 09:44:27 --> Helper loaded: cookie_helper
INFO - 2024-06-21 09:44:27 --> Final output sent to browser
DEBUG - 2024-06-21 09:44:27 --> Total execution time: 0.0331
INFO - 2024-06-21 09:44:27 --> Config Class Initialized
INFO - 2024-06-21 09:44:27 --> Hooks Class Initialized
DEBUG - 2024-06-21 09:44:27 --> UTF-8 Support Enabled
INFO - 2024-06-21 09:44:27 --> Utf8 Class Initialized
INFO - 2024-06-21 09:44:27 --> URI Class Initialized
INFO - 2024-06-21 09:44:27 --> Router Class Initialized
INFO - 2024-06-21 09:44:27 --> Output Class Initialized
INFO - 2024-06-21 09:44:27 --> Security Class Initialized
DEBUG - 2024-06-21 09:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 09:44:27 --> Input Class Initialized
INFO - 2024-06-21 09:44:27 --> Language Class Initialized
INFO - 2024-06-21 09:44:27 --> Language Class Initialized
INFO - 2024-06-21 09:44:27 --> Config Class Initialized
INFO - 2024-06-21 09:44:27 --> Loader Class Initialized
INFO - 2024-06-21 09:44:27 --> Helper loaded: url_helper
INFO - 2024-06-21 09:44:27 --> Helper loaded: file_helper
INFO - 2024-06-21 09:44:27 --> Helper loaded: form_helper
INFO - 2024-06-21 09:44:27 --> Helper loaded: my_helper
INFO - 2024-06-21 09:44:27 --> Database Driver Class Initialized
INFO - 2024-06-21 09:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 09:44:27 --> Controller Class Initialized
DEBUG - 2024-06-21 09:44:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-06-21 09:44:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 09:44:27 --> Final output sent to browser
DEBUG - 2024-06-21 09:44:27 --> Total execution time: 0.0312
INFO - 2024-06-21 09:44:39 --> Config Class Initialized
INFO - 2024-06-21 09:44:39 --> Hooks Class Initialized
DEBUG - 2024-06-21 09:44:39 --> UTF-8 Support Enabled
INFO - 2024-06-21 09:44:39 --> Utf8 Class Initialized
INFO - 2024-06-21 09:44:39 --> URI Class Initialized
INFO - 2024-06-21 09:44:39 --> Router Class Initialized
INFO - 2024-06-21 09:44:39 --> Output Class Initialized
INFO - 2024-06-21 09:44:39 --> Security Class Initialized
DEBUG - 2024-06-21 09:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 09:44:39 --> Input Class Initialized
INFO - 2024-06-21 09:44:39 --> Language Class Initialized
INFO - 2024-06-21 09:44:39 --> Language Class Initialized
INFO - 2024-06-21 09:44:39 --> Config Class Initialized
INFO - 2024-06-21 09:44:39 --> Loader Class Initialized
INFO - 2024-06-21 09:44:39 --> Helper loaded: url_helper
INFO - 2024-06-21 09:44:39 --> Helper loaded: file_helper
INFO - 2024-06-21 09:44:39 --> Helper loaded: form_helper
INFO - 2024-06-21 09:44:39 --> Helper loaded: my_helper
INFO - 2024-06-21 09:44:39 --> Database Driver Class Initialized
INFO - 2024-06-21 09:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 09:44:39 --> Controller Class Initialized
DEBUG - 2024-06-21 09:44:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-06-21 09:44:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 09:44:39 --> Final output sent to browser
DEBUG - 2024-06-21 09:44:39 --> Total execution time: 0.0898
INFO - 2024-06-21 09:44:39 --> Config Class Initialized
INFO - 2024-06-21 09:44:39 --> Hooks Class Initialized
DEBUG - 2024-06-21 09:44:39 --> UTF-8 Support Enabled
INFO - 2024-06-21 09:44:39 --> Utf8 Class Initialized
INFO - 2024-06-21 09:44:39 --> URI Class Initialized
INFO - 2024-06-21 09:44:39 --> Router Class Initialized
INFO - 2024-06-21 09:44:39 --> Output Class Initialized
INFO - 2024-06-21 09:44:39 --> Security Class Initialized
DEBUG - 2024-06-21 09:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 09:44:39 --> Input Class Initialized
INFO - 2024-06-21 09:44:39 --> Language Class Initialized
ERROR - 2024-06-21 09:44:39 --> 404 Page Not Found: /index
INFO - 2024-06-21 09:44:39 --> Config Class Initialized
INFO - 2024-06-21 09:44:39 --> Hooks Class Initialized
DEBUG - 2024-06-21 09:44:39 --> UTF-8 Support Enabled
INFO - 2024-06-21 09:44:39 --> Utf8 Class Initialized
INFO - 2024-06-21 09:44:39 --> URI Class Initialized
INFO - 2024-06-21 09:44:39 --> Router Class Initialized
INFO - 2024-06-21 09:44:39 --> Output Class Initialized
INFO - 2024-06-21 09:44:39 --> Security Class Initialized
DEBUG - 2024-06-21 09:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 09:44:39 --> Input Class Initialized
INFO - 2024-06-21 09:44:39 --> Language Class Initialized
INFO - 2024-06-21 09:44:39 --> Language Class Initialized
INFO - 2024-06-21 09:44:39 --> Config Class Initialized
INFO - 2024-06-21 09:44:39 --> Loader Class Initialized
INFO - 2024-06-21 09:44:39 --> Helper loaded: url_helper
INFO - 2024-06-21 09:44:39 --> Helper loaded: file_helper
INFO - 2024-06-21 09:44:39 --> Helper loaded: form_helper
INFO - 2024-06-21 09:44:39 --> Helper loaded: my_helper
INFO - 2024-06-21 09:44:39 --> Database Driver Class Initialized
INFO - 2024-06-21 09:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 09:44:39 --> Controller Class Initialized
INFO - 2024-06-21 09:44:45 --> Config Class Initialized
INFO - 2024-06-21 09:44:45 --> Hooks Class Initialized
DEBUG - 2024-06-21 09:44:45 --> UTF-8 Support Enabled
INFO - 2024-06-21 09:44:45 --> Utf8 Class Initialized
INFO - 2024-06-21 09:44:45 --> URI Class Initialized
INFO - 2024-06-21 09:44:45 --> Router Class Initialized
INFO - 2024-06-21 09:44:45 --> Output Class Initialized
INFO - 2024-06-21 09:44:45 --> Security Class Initialized
DEBUG - 2024-06-21 09:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 09:44:45 --> Input Class Initialized
INFO - 2024-06-21 09:44:45 --> Language Class Initialized
INFO - 2024-06-21 09:44:45 --> Language Class Initialized
INFO - 2024-06-21 09:44:45 --> Config Class Initialized
INFO - 2024-06-21 09:44:45 --> Loader Class Initialized
INFO - 2024-06-21 09:44:45 --> Helper loaded: url_helper
INFO - 2024-06-21 09:44:45 --> Helper loaded: file_helper
INFO - 2024-06-21 09:44:45 --> Helper loaded: form_helper
INFO - 2024-06-21 09:44:45 --> Helper loaded: my_helper
INFO - 2024-06-21 09:44:45 --> Database Driver Class Initialized
INFO - 2024-06-21 09:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 09:44:45 --> Controller Class Initialized
DEBUG - 2024-06-21 09:44:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2024-06-21 09:44:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 09:44:45 --> Final output sent to browser
DEBUG - 2024-06-21 09:44:45 --> Total execution time: 0.0284
INFO - 2024-06-21 09:44:45 --> Config Class Initialized
INFO - 2024-06-21 09:44:45 --> Hooks Class Initialized
DEBUG - 2024-06-21 09:44:45 --> UTF-8 Support Enabled
INFO - 2024-06-21 09:44:45 --> Utf8 Class Initialized
INFO - 2024-06-21 09:44:45 --> URI Class Initialized
INFO - 2024-06-21 09:44:45 --> Router Class Initialized
INFO - 2024-06-21 09:44:45 --> Output Class Initialized
INFO - 2024-06-21 09:44:45 --> Security Class Initialized
DEBUG - 2024-06-21 09:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 09:44:45 --> Input Class Initialized
INFO - 2024-06-21 09:44:45 --> Language Class Initialized
ERROR - 2024-06-21 09:44:45 --> 404 Page Not Found: /index
INFO - 2024-06-21 09:44:45 --> Config Class Initialized
INFO - 2024-06-21 09:44:45 --> Hooks Class Initialized
DEBUG - 2024-06-21 09:44:45 --> UTF-8 Support Enabled
INFO - 2024-06-21 09:44:45 --> Utf8 Class Initialized
INFO - 2024-06-21 09:44:45 --> URI Class Initialized
INFO - 2024-06-21 09:44:45 --> Router Class Initialized
INFO - 2024-06-21 09:44:45 --> Output Class Initialized
INFO - 2024-06-21 09:44:45 --> Security Class Initialized
DEBUG - 2024-06-21 09:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 09:44:45 --> Input Class Initialized
INFO - 2024-06-21 09:44:45 --> Language Class Initialized
INFO - 2024-06-21 09:44:45 --> Language Class Initialized
INFO - 2024-06-21 09:44:45 --> Config Class Initialized
INFO - 2024-06-21 09:44:45 --> Loader Class Initialized
INFO - 2024-06-21 09:44:45 --> Helper loaded: url_helper
INFO - 2024-06-21 09:44:45 --> Helper loaded: file_helper
INFO - 2024-06-21 09:44:45 --> Helper loaded: form_helper
INFO - 2024-06-21 09:44:45 --> Helper loaded: my_helper
INFO - 2024-06-21 09:44:45 --> Database Driver Class Initialized
INFO - 2024-06-21 09:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 09:44:45 --> Controller Class Initialized
INFO - 2024-06-21 09:44:47 --> Config Class Initialized
INFO - 2024-06-21 09:44:47 --> Hooks Class Initialized
DEBUG - 2024-06-21 09:44:47 --> UTF-8 Support Enabled
INFO - 2024-06-21 09:44:47 --> Utf8 Class Initialized
INFO - 2024-06-21 09:44:47 --> URI Class Initialized
INFO - 2024-06-21 09:44:47 --> Router Class Initialized
INFO - 2024-06-21 09:44:47 --> Output Class Initialized
INFO - 2024-06-21 09:44:47 --> Security Class Initialized
DEBUG - 2024-06-21 09:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 09:44:47 --> Input Class Initialized
INFO - 2024-06-21 09:44:47 --> Language Class Initialized
INFO - 2024-06-21 09:44:47 --> Language Class Initialized
INFO - 2024-06-21 09:44:47 --> Config Class Initialized
INFO - 2024-06-21 09:44:47 --> Loader Class Initialized
INFO - 2024-06-21 09:44:47 --> Helper loaded: url_helper
INFO - 2024-06-21 09:44:47 --> Helper loaded: file_helper
INFO - 2024-06-21 09:44:47 --> Helper loaded: form_helper
INFO - 2024-06-21 09:44:47 --> Helper loaded: my_helper
INFO - 2024-06-21 09:44:47 --> Database Driver Class Initialized
INFO - 2024-06-21 09:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 09:44:47 --> Controller Class Initialized
DEBUG - 2024-06-21 09:44:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-06-21 09:44:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 09:44:47 --> Final output sent to browser
DEBUG - 2024-06-21 09:44:47 --> Total execution time: 0.0274
INFO - 2024-06-21 09:44:47 --> Config Class Initialized
INFO - 2024-06-21 09:44:47 --> Hooks Class Initialized
DEBUG - 2024-06-21 09:44:47 --> UTF-8 Support Enabled
INFO - 2024-06-21 09:44:47 --> Utf8 Class Initialized
INFO - 2024-06-21 09:44:47 --> URI Class Initialized
INFO - 2024-06-21 09:44:47 --> Router Class Initialized
INFO - 2024-06-21 09:44:47 --> Output Class Initialized
INFO - 2024-06-21 09:44:47 --> Security Class Initialized
DEBUG - 2024-06-21 09:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 09:44:47 --> Input Class Initialized
INFO - 2024-06-21 09:44:47 --> Language Class Initialized
ERROR - 2024-06-21 09:44:47 --> 404 Page Not Found: /index
INFO - 2024-06-21 09:44:47 --> Config Class Initialized
INFO - 2024-06-21 09:44:47 --> Hooks Class Initialized
DEBUG - 2024-06-21 09:44:47 --> UTF-8 Support Enabled
INFO - 2024-06-21 09:44:47 --> Utf8 Class Initialized
INFO - 2024-06-21 09:44:47 --> URI Class Initialized
INFO - 2024-06-21 09:44:47 --> Router Class Initialized
INFO - 2024-06-21 09:44:47 --> Output Class Initialized
INFO - 2024-06-21 09:44:47 --> Security Class Initialized
DEBUG - 2024-06-21 09:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 09:44:47 --> Input Class Initialized
INFO - 2024-06-21 09:44:47 --> Language Class Initialized
INFO - 2024-06-21 09:44:47 --> Language Class Initialized
INFO - 2024-06-21 09:44:47 --> Config Class Initialized
INFO - 2024-06-21 09:44:47 --> Loader Class Initialized
INFO - 2024-06-21 09:44:47 --> Helper loaded: url_helper
INFO - 2024-06-21 09:44:47 --> Helper loaded: file_helper
INFO - 2024-06-21 09:44:47 --> Helper loaded: form_helper
INFO - 2024-06-21 09:44:47 --> Helper loaded: my_helper
INFO - 2024-06-21 09:44:47 --> Database Driver Class Initialized
INFO - 2024-06-21 09:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 09:44:47 --> Controller Class Initialized
INFO - 2024-06-21 09:44:50 --> Config Class Initialized
INFO - 2024-06-21 09:44:50 --> Hooks Class Initialized
DEBUG - 2024-06-21 09:44:50 --> UTF-8 Support Enabled
INFO - 2024-06-21 09:44:50 --> Utf8 Class Initialized
INFO - 2024-06-21 09:44:50 --> URI Class Initialized
INFO - 2024-06-21 09:44:50 --> Router Class Initialized
INFO - 2024-06-21 09:44:50 --> Output Class Initialized
INFO - 2024-06-21 09:44:50 --> Security Class Initialized
DEBUG - 2024-06-21 09:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 09:44:50 --> Input Class Initialized
INFO - 2024-06-21 09:44:50 --> Language Class Initialized
INFO - 2024-06-21 09:44:50 --> Language Class Initialized
INFO - 2024-06-21 09:44:50 --> Config Class Initialized
INFO - 2024-06-21 09:44:50 --> Loader Class Initialized
INFO - 2024-06-21 09:44:50 --> Helper loaded: url_helper
INFO - 2024-06-21 09:44:50 --> Helper loaded: file_helper
INFO - 2024-06-21 09:44:50 --> Helper loaded: form_helper
INFO - 2024-06-21 09:44:50 --> Helper loaded: my_helper
INFO - 2024-06-21 09:44:50 --> Database Driver Class Initialized
INFO - 2024-06-21 09:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 09:44:50 --> Controller Class Initialized
DEBUG - 2024-06-21 09:44:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-06-21 09:44:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 09:44:50 --> Final output sent to browser
DEBUG - 2024-06-21 09:44:50 --> Total execution time: 0.0253
INFO - 2024-06-21 09:44:50 --> Config Class Initialized
INFO - 2024-06-21 09:44:50 --> Hooks Class Initialized
DEBUG - 2024-06-21 09:44:50 --> UTF-8 Support Enabled
INFO - 2024-06-21 09:44:50 --> Utf8 Class Initialized
INFO - 2024-06-21 09:44:50 --> URI Class Initialized
INFO - 2024-06-21 09:44:50 --> Router Class Initialized
INFO - 2024-06-21 09:44:50 --> Output Class Initialized
INFO - 2024-06-21 09:44:50 --> Security Class Initialized
DEBUG - 2024-06-21 09:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 09:44:50 --> Input Class Initialized
INFO - 2024-06-21 09:44:50 --> Language Class Initialized
ERROR - 2024-06-21 09:44:50 --> 404 Page Not Found: /index
INFO - 2024-06-21 09:44:50 --> Config Class Initialized
INFO - 2024-06-21 09:44:50 --> Hooks Class Initialized
DEBUG - 2024-06-21 09:44:50 --> UTF-8 Support Enabled
INFO - 2024-06-21 09:44:50 --> Utf8 Class Initialized
INFO - 2024-06-21 09:44:50 --> URI Class Initialized
INFO - 2024-06-21 09:44:50 --> Router Class Initialized
INFO - 2024-06-21 09:44:50 --> Output Class Initialized
INFO - 2024-06-21 09:44:50 --> Security Class Initialized
DEBUG - 2024-06-21 09:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 09:44:50 --> Input Class Initialized
INFO - 2024-06-21 09:44:50 --> Language Class Initialized
INFO - 2024-06-21 09:44:50 --> Language Class Initialized
INFO - 2024-06-21 09:44:50 --> Config Class Initialized
INFO - 2024-06-21 09:44:50 --> Loader Class Initialized
INFO - 2024-06-21 09:44:50 --> Helper loaded: url_helper
INFO - 2024-06-21 09:44:50 --> Helper loaded: file_helper
INFO - 2024-06-21 09:44:50 --> Helper loaded: form_helper
INFO - 2024-06-21 09:44:50 --> Helper loaded: my_helper
INFO - 2024-06-21 09:44:50 --> Database Driver Class Initialized
INFO - 2024-06-21 09:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 09:44:50 --> Controller Class Initialized
INFO - 2024-06-21 11:28:02 --> Config Class Initialized
INFO - 2024-06-21 11:28:02 --> Hooks Class Initialized
DEBUG - 2024-06-21 11:28:02 --> UTF-8 Support Enabled
INFO - 2024-06-21 11:28:02 --> Utf8 Class Initialized
INFO - 2024-06-21 11:28:02 --> URI Class Initialized
INFO - 2024-06-21 11:28:02 --> Router Class Initialized
INFO - 2024-06-21 11:28:02 --> Output Class Initialized
INFO - 2024-06-21 11:28:02 --> Security Class Initialized
DEBUG - 2024-06-21 11:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 11:28:02 --> Input Class Initialized
INFO - 2024-06-21 11:28:02 --> Language Class Initialized
INFO - 2024-06-21 11:28:02 --> Language Class Initialized
INFO - 2024-06-21 11:28:02 --> Config Class Initialized
INFO - 2024-06-21 11:28:02 --> Loader Class Initialized
INFO - 2024-06-21 11:28:02 --> Helper loaded: url_helper
INFO - 2024-06-21 11:28:02 --> Helper loaded: file_helper
INFO - 2024-06-21 11:28:02 --> Helper loaded: form_helper
INFO - 2024-06-21 11:28:02 --> Helper loaded: my_helper
INFO - 2024-06-21 11:28:02 --> Database Driver Class Initialized
INFO - 2024-06-21 11:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 11:28:02 --> Controller Class Initialized
INFO - 2024-06-21 11:28:02 --> Helper loaded: cookie_helper
INFO - 2024-06-21 11:28:02 --> Config Class Initialized
INFO - 2024-06-21 11:28:02 --> Hooks Class Initialized
DEBUG - 2024-06-21 11:28:02 --> UTF-8 Support Enabled
INFO - 2024-06-21 11:28:02 --> Utf8 Class Initialized
INFO - 2024-06-21 11:28:02 --> URI Class Initialized
INFO - 2024-06-21 11:28:02 --> Router Class Initialized
INFO - 2024-06-21 11:28:02 --> Output Class Initialized
INFO - 2024-06-21 11:28:02 --> Security Class Initialized
DEBUG - 2024-06-21 11:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 11:28:02 --> Input Class Initialized
INFO - 2024-06-21 11:28:02 --> Language Class Initialized
INFO - 2024-06-21 11:28:02 --> Language Class Initialized
INFO - 2024-06-21 11:28:02 --> Config Class Initialized
INFO - 2024-06-21 11:28:02 --> Loader Class Initialized
INFO - 2024-06-21 11:28:02 --> Helper loaded: url_helper
INFO - 2024-06-21 11:28:02 --> Helper loaded: file_helper
INFO - 2024-06-21 11:28:02 --> Helper loaded: form_helper
INFO - 2024-06-21 11:28:02 --> Helper loaded: my_helper
INFO - 2024-06-21 11:28:02 --> Database Driver Class Initialized
INFO - 2024-06-21 11:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 11:28:02 --> Controller Class Initialized
INFO - 2024-06-21 11:28:03 --> Config Class Initialized
INFO - 2024-06-21 11:28:03 --> Hooks Class Initialized
DEBUG - 2024-06-21 11:28:03 --> UTF-8 Support Enabled
INFO - 2024-06-21 11:28:03 --> Utf8 Class Initialized
INFO - 2024-06-21 11:28:03 --> URI Class Initialized
INFO - 2024-06-21 11:28:03 --> Router Class Initialized
INFO - 2024-06-21 11:28:03 --> Output Class Initialized
INFO - 2024-06-21 11:28:03 --> Security Class Initialized
DEBUG - 2024-06-21 11:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 11:28:03 --> Input Class Initialized
INFO - 2024-06-21 11:28:03 --> Language Class Initialized
INFO - 2024-06-21 11:28:03 --> Language Class Initialized
INFO - 2024-06-21 11:28:03 --> Config Class Initialized
INFO - 2024-06-21 11:28:03 --> Loader Class Initialized
INFO - 2024-06-21 11:28:03 --> Helper loaded: url_helper
INFO - 2024-06-21 11:28:03 --> Helper loaded: file_helper
INFO - 2024-06-21 11:28:03 --> Helper loaded: form_helper
INFO - 2024-06-21 11:28:03 --> Helper loaded: my_helper
INFO - 2024-06-21 11:28:03 --> Database Driver Class Initialized
INFO - 2024-06-21 11:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 11:28:03 --> Controller Class Initialized
DEBUG - 2024-06-21 11:28:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-21 11:28:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 11:28:03 --> Final output sent to browser
DEBUG - 2024-06-21 11:28:03 --> Total execution time: 0.0480
INFO - 2024-06-21 11:30:39 --> Config Class Initialized
INFO - 2024-06-21 11:30:39 --> Hooks Class Initialized
DEBUG - 2024-06-21 11:30:39 --> UTF-8 Support Enabled
INFO - 2024-06-21 11:30:39 --> Utf8 Class Initialized
INFO - 2024-06-21 11:30:39 --> URI Class Initialized
INFO - 2024-06-21 11:30:39 --> Router Class Initialized
INFO - 2024-06-21 11:30:39 --> Output Class Initialized
INFO - 2024-06-21 11:30:39 --> Security Class Initialized
DEBUG - 2024-06-21 11:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 11:30:39 --> Input Class Initialized
INFO - 2024-06-21 11:30:39 --> Language Class Initialized
INFO - 2024-06-21 11:30:39 --> Language Class Initialized
INFO - 2024-06-21 11:30:39 --> Config Class Initialized
INFO - 2024-06-21 11:30:39 --> Loader Class Initialized
INFO - 2024-06-21 11:30:39 --> Helper loaded: url_helper
INFO - 2024-06-21 11:30:39 --> Helper loaded: file_helper
INFO - 2024-06-21 11:30:39 --> Helper loaded: form_helper
INFO - 2024-06-21 11:30:39 --> Helper loaded: my_helper
INFO - 2024-06-21 11:30:39 --> Database Driver Class Initialized
INFO - 2024-06-21 11:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 11:30:39 --> Controller Class Initialized
INFO - 2024-06-21 11:30:39 --> Helper loaded: cookie_helper
INFO - 2024-06-21 11:30:39 --> Final output sent to browser
DEBUG - 2024-06-21 11:30:39 --> Total execution time: 0.0373
INFO - 2024-06-21 11:30:39 --> Config Class Initialized
INFO - 2024-06-21 11:30:39 --> Hooks Class Initialized
DEBUG - 2024-06-21 11:30:39 --> UTF-8 Support Enabled
INFO - 2024-06-21 11:30:39 --> Utf8 Class Initialized
INFO - 2024-06-21 11:30:39 --> URI Class Initialized
INFO - 2024-06-21 11:30:39 --> Router Class Initialized
INFO - 2024-06-21 11:30:39 --> Output Class Initialized
INFO - 2024-06-21 11:30:39 --> Security Class Initialized
DEBUG - 2024-06-21 11:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 11:30:39 --> Input Class Initialized
INFO - 2024-06-21 11:30:39 --> Language Class Initialized
INFO - 2024-06-21 11:30:39 --> Language Class Initialized
INFO - 2024-06-21 11:30:39 --> Config Class Initialized
INFO - 2024-06-21 11:30:39 --> Loader Class Initialized
INFO - 2024-06-21 11:30:39 --> Helper loaded: url_helper
INFO - 2024-06-21 11:30:39 --> Helper loaded: file_helper
INFO - 2024-06-21 11:30:39 --> Helper loaded: form_helper
INFO - 2024-06-21 11:30:39 --> Helper loaded: my_helper
INFO - 2024-06-21 11:30:39 --> Database Driver Class Initialized
INFO - 2024-06-21 11:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 11:30:39 --> Controller Class Initialized
DEBUG - 2024-06-21 11:30:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-21 11:30:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 11:30:39 --> Final output sent to browser
DEBUG - 2024-06-21 11:30:39 --> Total execution time: 0.0414
INFO - 2024-06-21 11:31:21 --> Config Class Initialized
INFO - 2024-06-21 11:31:21 --> Hooks Class Initialized
DEBUG - 2024-06-21 11:31:21 --> UTF-8 Support Enabled
INFO - 2024-06-21 11:31:21 --> Utf8 Class Initialized
INFO - 2024-06-21 11:31:21 --> URI Class Initialized
INFO - 2024-06-21 11:31:21 --> Router Class Initialized
INFO - 2024-06-21 11:31:21 --> Output Class Initialized
INFO - 2024-06-21 11:31:21 --> Security Class Initialized
DEBUG - 2024-06-21 11:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 11:31:21 --> Input Class Initialized
INFO - 2024-06-21 11:31:21 --> Language Class Initialized
INFO - 2024-06-21 11:31:22 --> Language Class Initialized
INFO - 2024-06-21 11:31:22 --> Config Class Initialized
INFO - 2024-06-21 11:31:22 --> Loader Class Initialized
INFO - 2024-06-21 11:31:22 --> Helper loaded: url_helper
INFO - 2024-06-21 11:31:22 --> Helper loaded: file_helper
INFO - 2024-06-21 11:31:22 --> Helper loaded: form_helper
INFO - 2024-06-21 11:31:22 --> Helper loaded: my_helper
INFO - 2024-06-21 11:31:22 --> Database Driver Class Initialized
INFO - 2024-06-21 11:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 11:31:22 --> Controller Class Initialized
DEBUG - 2024-06-21 11:31:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-21 11:31:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 11:31:22 --> Final output sent to browser
DEBUG - 2024-06-21 11:31:22 --> Total execution time: 0.0637
INFO - 2024-06-21 11:31:24 --> Config Class Initialized
INFO - 2024-06-21 11:31:24 --> Hooks Class Initialized
DEBUG - 2024-06-21 11:31:24 --> UTF-8 Support Enabled
INFO - 2024-06-21 11:31:24 --> Utf8 Class Initialized
INFO - 2024-06-21 11:31:24 --> URI Class Initialized
INFO - 2024-06-21 11:31:24 --> Router Class Initialized
INFO - 2024-06-21 11:31:24 --> Output Class Initialized
INFO - 2024-06-21 11:31:24 --> Security Class Initialized
DEBUG - 2024-06-21 11:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 11:31:24 --> Input Class Initialized
INFO - 2024-06-21 11:31:24 --> Language Class Initialized
INFO - 2024-06-21 11:31:24 --> Language Class Initialized
INFO - 2024-06-21 11:31:24 --> Config Class Initialized
INFO - 2024-06-21 11:31:24 --> Loader Class Initialized
INFO - 2024-06-21 11:31:24 --> Helper loaded: url_helper
INFO - 2024-06-21 11:31:24 --> Helper loaded: file_helper
INFO - 2024-06-21 11:31:24 --> Helper loaded: form_helper
INFO - 2024-06-21 11:31:24 --> Helper loaded: my_helper
INFO - 2024-06-21 11:31:24 --> Database Driver Class Initialized
INFO - 2024-06-21 11:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 11:31:24 --> Controller Class Initialized
DEBUG - 2024-06-21 11:31:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-21 11:31:26 --> Final output sent to browser
DEBUG - 2024-06-21 11:31:26 --> Total execution time: 2.1312
INFO - 2024-06-21 11:33:10 --> Config Class Initialized
INFO - 2024-06-21 11:33:10 --> Hooks Class Initialized
DEBUG - 2024-06-21 11:33:10 --> UTF-8 Support Enabled
INFO - 2024-06-21 11:33:10 --> Utf8 Class Initialized
INFO - 2024-06-21 11:33:10 --> URI Class Initialized
INFO - 2024-06-21 11:33:10 --> Router Class Initialized
INFO - 2024-06-21 11:33:10 --> Output Class Initialized
INFO - 2024-06-21 11:33:10 --> Security Class Initialized
DEBUG - 2024-06-21 11:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 11:33:10 --> Input Class Initialized
INFO - 2024-06-21 11:33:10 --> Language Class Initialized
INFO - 2024-06-21 11:33:10 --> Language Class Initialized
INFO - 2024-06-21 11:33:10 --> Config Class Initialized
INFO - 2024-06-21 11:33:10 --> Loader Class Initialized
INFO - 2024-06-21 11:33:10 --> Helper loaded: url_helper
INFO - 2024-06-21 11:33:10 --> Helper loaded: file_helper
INFO - 2024-06-21 11:33:10 --> Helper loaded: form_helper
INFO - 2024-06-21 11:33:10 --> Helper loaded: my_helper
INFO - 2024-06-21 11:33:10 --> Database Driver Class Initialized
INFO - 2024-06-21 11:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 11:33:10 --> Controller Class Initialized
DEBUG - 2024-06-21 11:33:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-21 11:33:12 --> Final output sent to browser
DEBUG - 2024-06-21 11:33:12 --> Total execution time: 1.8204
INFO - 2024-06-21 11:34:33 --> Config Class Initialized
INFO - 2024-06-21 11:34:33 --> Hooks Class Initialized
DEBUG - 2024-06-21 11:34:33 --> UTF-8 Support Enabled
INFO - 2024-06-21 11:34:33 --> Utf8 Class Initialized
INFO - 2024-06-21 11:34:33 --> URI Class Initialized
INFO - 2024-06-21 11:34:33 --> Router Class Initialized
INFO - 2024-06-21 11:34:33 --> Output Class Initialized
INFO - 2024-06-21 11:34:33 --> Security Class Initialized
DEBUG - 2024-06-21 11:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 11:34:33 --> Input Class Initialized
INFO - 2024-06-21 11:34:33 --> Language Class Initialized
INFO - 2024-06-21 11:34:33 --> Language Class Initialized
INFO - 2024-06-21 11:34:33 --> Config Class Initialized
INFO - 2024-06-21 11:34:33 --> Loader Class Initialized
INFO - 2024-06-21 11:34:33 --> Helper loaded: url_helper
INFO - 2024-06-21 11:34:33 --> Helper loaded: file_helper
INFO - 2024-06-21 11:34:33 --> Helper loaded: form_helper
INFO - 2024-06-21 11:34:33 --> Helper loaded: my_helper
INFO - 2024-06-21 11:34:33 --> Database Driver Class Initialized
INFO - 2024-06-21 11:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 11:34:33 --> Controller Class Initialized
DEBUG - 2024-06-21 11:34:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-21 11:34:35 --> Final output sent to browser
DEBUG - 2024-06-21 11:34:35 --> Total execution time: 2.3948
INFO - 2024-06-21 11:35:50 --> Config Class Initialized
INFO - 2024-06-21 11:35:50 --> Hooks Class Initialized
DEBUG - 2024-06-21 11:35:50 --> UTF-8 Support Enabled
INFO - 2024-06-21 11:35:50 --> Utf8 Class Initialized
INFO - 2024-06-21 11:35:50 --> URI Class Initialized
INFO - 2024-06-21 11:35:50 --> Router Class Initialized
INFO - 2024-06-21 11:35:50 --> Output Class Initialized
INFO - 2024-06-21 11:35:50 --> Security Class Initialized
DEBUG - 2024-06-21 11:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 11:35:50 --> Input Class Initialized
INFO - 2024-06-21 11:35:50 --> Language Class Initialized
INFO - 2024-06-21 11:35:50 --> Language Class Initialized
INFO - 2024-06-21 11:35:50 --> Config Class Initialized
INFO - 2024-06-21 11:35:50 --> Loader Class Initialized
INFO - 2024-06-21 11:35:50 --> Helper loaded: url_helper
INFO - 2024-06-21 11:35:50 --> Helper loaded: file_helper
INFO - 2024-06-21 11:35:50 --> Helper loaded: form_helper
INFO - 2024-06-21 11:35:50 --> Helper loaded: my_helper
INFO - 2024-06-21 11:35:50 --> Database Driver Class Initialized
INFO - 2024-06-21 11:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 11:35:50 --> Controller Class Initialized
DEBUG - 2024-06-21 11:35:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-21 11:35:52 --> Final output sent to browser
DEBUG - 2024-06-21 11:35:52 --> Total execution time: 2.0411
INFO - 2024-06-21 11:36:56 --> Config Class Initialized
INFO - 2024-06-21 11:36:56 --> Hooks Class Initialized
DEBUG - 2024-06-21 11:36:56 --> UTF-8 Support Enabled
INFO - 2024-06-21 11:36:56 --> Utf8 Class Initialized
INFO - 2024-06-21 11:36:56 --> URI Class Initialized
INFO - 2024-06-21 11:36:56 --> Router Class Initialized
INFO - 2024-06-21 11:36:56 --> Output Class Initialized
INFO - 2024-06-21 11:36:56 --> Security Class Initialized
DEBUG - 2024-06-21 11:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 11:36:56 --> Input Class Initialized
INFO - 2024-06-21 11:36:56 --> Language Class Initialized
INFO - 2024-06-21 11:36:56 --> Language Class Initialized
INFO - 2024-06-21 11:36:56 --> Config Class Initialized
INFO - 2024-06-21 11:36:56 --> Loader Class Initialized
INFO - 2024-06-21 11:36:56 --> Helper loaded: url_helper
INFO - 2024-06-21 11:36:56 --> Helper loaded: file_helper
INFO - 2024-06-21 11:36:56 --> Helper loaded: form_helper
INFO - 2024-06-21 11:36:56 --> Helper loaded: my_helper
INFO - 2024-06-21 11:36:56 --> Database Driver Class Initialized
INFO - 2024-06-21 11:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 11:36:56 --> Controller Class Initialized
DEBUG - 2024-06-21 11:36:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-21 11:36:58 --> Final output sent to browser
DEBUG - 2024-06-21 11:36:58 --> Total execution time: 2.1260
INFO - 2024-06-21 11:38:03 --> Config Class Initialized
INFO - 2024-06-21 11:38:03 --> Hooks Class Initialized
DEBUG - 2024-06-21 11:38:03 --> UTF-8 Support Enabled
INFO - 2024-06-21 11:38:03 --> Utf8 Class Initialized
INFO - 2024-06-21 11:38:03 --> URI Class Initialized
INFO - 2024-06-21 11:38:03 --> Router Class Initialized
INFO - 2024-06-21 11:38:03 --> Output Class Initialized
INFO - 2024-06-21 11:38:03 --> Security Class Initialized
DEBUG - 2024-06-21 11:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 11:38:03 --> Input Class Initialized
INFO - 2024-06-21 11:38:03 --> Language Class Initialized
INFO - 2024-06-21 11:38:03 --> Language Class Initialized
INFO - 2024-06-21 11:38:03 --> Config Class Initialized
INFO - 2024-06-21 11:38:03 --> Loader Class Initialized
INFO - 2024-06-21 11:38:03 --> Helper loaded: url_helper
INFO - 2024-06-21 11:38:03 --> Helper loaded: file_helper
INFO - 2024-06-21 11:38:03 --> Helper loaded: form_helper
INFO - 2024-06-21 11:38:03 --> Helper loaded: my_helper
INFO - 2024-06-21 11:38:03 --> Database Driver Class Initialized
INFO - 2024-06-21 11:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 11:38:03 --> Controller Class Initialized
DEBUG - 2024-06-21 11:38:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-21 11:38:05 --> Final output sent to browser
DEBUG - 2024-06-21 11:38:05 --> Total execution time: 1.9050
INFO - 2024-06-21 11:38:51 --> Config Class Initialized
INFO - 2024-06-21 11:38:51 --> Hooks Class Initialized
DEBUG - 2024-06-21 11:38:51 --> UTF-8 Support Enabled
INFO - 2024-06-21 11:38:51 --> Utf8 Class Initialized
INFO - 2024-06-21 11:38:51 --> URI Class Initialized
INFO - 2024-06-21 11:38:51 --> Router Class Initialized
INFO - 2024-06-21 11:38:51 --> Output Class Initialized
INFO - 2024-06-21 11:38:51 --> Security Class Initialized
DEBUG - 2024-06-21 11:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 11:38:51 --> Input Class Initialized
INFO - 2024-06-21 11:38:51 --> Language Class Initialized
INFO - 2024-06-21 11:38:51 --> Language Class Initialized
INFO - 2024-06-21 11:38:51 --> Config Class Initialized
INFO - 2024-06-21 11:38:51 --> Loader Class Initialized
INFO - 2024-06-21 11:38:51 --> Helper loaded: url_helper
INFO - 2024-06-21 11:38:51 --> Helper loaded: file_helper
INFO - 2024-06-21 11:38:51 --> Helper loaded: form_helper
INFO - 2024-06-21 11:38:51 --> Helper loaded: my_helper
INFO - 2024-06-21 11:38:51 --> Database Driver Class Initialized
INFO - 2024-06-21 11:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 11:38:51 --> Controller Class Initialized
DEBUG - 2024-06-21 11:38:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-21 11:38:53 --> Final output sent to browser
DEBUG - 2024-06-21 11:38:53 --> Total execution time: 2.0374
INFO - 2024-06-21 11:39:48 --> Config Class Initialized
INFO - 2024-06-21 11:39:48 --> Hooks Class Initialized
DEBUG - 2024-06-21 11:39:48 --> UTF-8 Support Enabled
INFO - 2024-06-21 11:39:48 --> Utf8 Class Initialized
INFO - 2024-06-21 11:39:48 --> URI Class Initialized
INFO - 2024-06-21 11:39:48 --> Router Class Initialized
INFO - 2024-06-21 11:39:48 --> Output Class Initialized
INFO - 2024-06-21 11:39:48 --> Security Class Initialized
DEBUG - 2024-06-21 11:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 11:39:48 --> Input Class Initialized
INFO - 2024-06-21 11:39:48 --> Language Class Initialized
INFO - 2024-06-21 11:39:48 --> Language Class Initialized
INFO - 2024-06-21 11:39:48 --> Config Class Initialized
INFO - 2024-06-21 11:39:48 --> Loader Class Initialized
INFO - 2024-06-21 11:39:48 --> Helper loaded: url_helper
INFO - 2024-06-21 11:39:48 --> Helper loaded: file_helper
INFO - 2024-06-21 11:39:48 --> Helper loaded: form_helper
INFO - 2024-06-21 11:39:48 --> Helper loaded: my_helper
INFO - 2024-06-21 11:39:48 --> Database Driver Class Initialized
INFO - 2024-06-21 11:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 11:39:48 --> Controller Class Initialized
DEBUG - 2024-06-21 11:39:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-21 11:39:50 --> Final output sent to browser
DEBUG - 2024-06-21 11:39:50 --> Total execution time: 2.1343
INFO - 2024-06-21 11:40:50 --> Config Class Initialized
INFO - 2024-06-21 11:40:50 --> Hooks Class Initialized
DEBUG - 2024-06-21 11:40:50 --> UTF-8 Support Enabled
INFO - 2024-06-21 11:40:50 --> Utf8 Class Initialized
INFO - 2024-06-21 11:40:50 --> URI Class Initialized
INFO - 2024-06-21 11:40:50 --> Router Class Initialized
INFO - 2024-06-21 11:40:50 --> Output Class Initialized
INFO - 2024-06-21 11:40:50 --> Security Class Initialized
DEBUG - 2024-06-21 11:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 11:40:50 --> Input Class Initialized
INFO - 2024-06-21 11:40:50 --> Language Class Initialized
INFO - 2024-06-21 11:40:50 --> Language Class Initialized
INFO - 2024-06-21 11:40:50 --> Config Class Initialized
INFO - 2024-06-21 11:40:50 --> Loader Class Initialized
INFO - 2024-06-21 11:40:50 --> Helper loaded: url_helper
INFO - 2024-06-21 11:40:50 --> Helper loaded: file_helper
INFO - 2024-06-21 11:40:50 --> Helper loaded: form_helper
INFO - 2024-06-21 11:40:50 --> Helper loaded: my_helper
INFO - 2024-06-21 11:40:50 --> Database Driver Class Initialized
INFO - 2024-06-21 11:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 11:40:50 --> Controller Class Initialized
DEBUG - 2024-06-21 11:40:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-21 11:40:52 --> Final output sent to browser
DEBUG - 2024-06-21 11:40:52 --> Total execution time: 1.8449
INFO - 2024-06-21 11:41:57 --> Config Class Initialized
INFO - 2024-06-21 11:41:57 --> Hooks Class Initialized
DEBUG - 2024-06-21 11:41:57 --> UTF-8 Support Enabled
INFO - 2024-06-21 11:41:57 --> Utf8 Class Initialized
INFO - 2024-06-21 11:41:57 --> URI Class Initialized
INFO - 2024-06-21 11:41:57 --> Router Class Initialized
INFO - 2024-06-21 11:41:57 --> Output Class Initialized
INFO - 2024-06-21 11:41:57 --> Security Class Initialized
DEBUG - 2024-06-21 11:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 11:41:57 --> Input Class Initialized
INFO - 2024-06-21 11:41:57 --> Language Class Initialized
INFO - 2024-06-21 11:41:57 --> Language Class Initialized
INFO - 2024-06-21 11:41:57 --> Config Class Initialized
INFO - 2024-06-21 11:41:57 --> Loader Class Initialized
INFO - 2024-06-21 11:41:57 --> Helper loaded: url_helper
INFO - 2024-06-21 11:41:57 --> Helper loaded: file_helper
INFO - 2024-06-21 11:41:57 --> Helper loaded: form_helper
INFO - 2024-06-21 11:41:57 --> Helper loaded: my_helper
INFO - 2024-06-21 11:41:57 --> Database Driver Class Initialized
INFO - 2024-06-21 11:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 11:41:57 --> Controller Class Initialized
DEBUG - 2024-06-21 11:41:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-21 11:41:59 --> Final output sent to browser
DEBUG - 2024-06-21 11:41:59 --> Total execution time: 1.9797
INFO - 2024-06-21 11:42:50 --> Config Class Initialized
INFO - 2024-06-21 11:42:50 --> Hooks Class Initialized
DEBUG - 2024-06-21 11:42:50 --> UTF-8 Support Enabled
INFO - 2024-06-21 11:42:50 --> Utf8 Class Initialized
INFO - 2024-06-21 11:42:50 --> URI Class Initialized
INFO - 2024-06-21 11:42:50 --> Router Class Initialized
INFO - 2024-06-21 11:42:50 --> Output Class Initialized
INFO - 2024-06-21 11:42:50 --> Security Class Initialized
DEBUG - 2024-06-21 11:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 11:42:50 --> Input Class Initialized
INFO - 2024-06-21 11:42:50 --> Language Class Initialized
INFO - 2024-06-21 11:42:50 --> Language Class Initialized
INFO - 2024-06-21 11:42:50 --> Config Class Initialized
INFO - 2024-06-21 11:42:50 --> Loader Class Initialized
INFO - 2024-06-21 11:42:50 --> Helper loaded: url_helper
INFO - 2024-06-21 11:42:50 --> Helper loaded: file_helper
INFO - 2024-06-21 11:42:50 --> Helper loaded: form_helper
INFO - 2024-06-21 11:42:50 --> Helper loaded: my_helper
INFO - 2024-06-21 11:42:50 --> Database Driver Class Initialized
INFO - 2024-06-21 11:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 11:42:50 --> Controller Class Initialized
DEBUG - 2024-06-21 11:42:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-21 11:42:52 --> Final output sent to browser
DEBUG - 2024-06-21 11:42:52 --> Total execution time: 2.1355
INFO - 2024-06-21 11:43:49 --> Config Class Initialized
INFO - 2024-06-21 11:43:49 --> Hooks Class Initialized
DEBUG - 2024-06-21 11:43:49 --> UTF-8 Support Enabled
INFO - 2024-06-21 11:43:49 --> Utf8 Class Initialized
INFO - 2024-06-21 11:43:49 --> URI Class Initialized
INFO - 2024-06-21 11:43:49 --> Router Class Initialized
INFO - 2024-06-21 11:43:49 --> Output Class Initialized
INFO - 2024-06-21 11:43:49 --> Security Class Initialized
DEBUG - 2024-06-21 11:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 11:43:49 --> Input Class Initialized
INFO - 2024-06-21 11:43:49 --> Language Class Initialized
INFO - 2024-06-21 11:43:49 --> Language Class Initialized
INFO - 2024-06-21 11:43:49 --> Config Class Initialized
INFO - 2024-06-21 11:43:49 --> Loader Class Initialized
INFO - 2024-06-21 11:43:49 --> Helper loaded: url_helper
INFO - 2024-06-21 11:43:49 --> Helper loaded: file_helper
INFO - 2024-06-21 11:43:49 --> Helper loaded: form_helper
INFO - 2024-06-21 11:43:49 --> Helper loaded: my_helper
INFO - 2024-06-21 11:43:49 --> Database Driver Class Initialized
INFO - 2024-06-21 11:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 11:43:49 --> Controller Class Initialized
DEBUG - 2024-06-21 11:43:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-21 11:43:51 --> Final output sent to browser
DEBUG - 2024-06-21 11:43:51 --> Total execution time: 1.9815
INFO - 2024-06-21 11:44:34 --> Config Class Initialized
INFO - 2024-06-21 11:44:34 --> Hooks Class Initialized
DEBUG - 2024-06-21 11:44:34 --> UTF-8 Support Enabled
INFO - 2024-06-21 11:44:34 --> Utf8 Class Initialized
INFO - 2024-06-21 11:44:34 --> URI Class Initialized
INFO - 2024-06-21 11:44:34 --> Router Class Initialized
INFO - 2024-06-21 11:44:34 --> Output Class Initialized
INFO - 2024-06-21 11:44:34 --> Security Class Initialized
DEBUG - 2024-06-21 11:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 11:44:34 --> Input Class Initialized
INFO - 2024-06-21 11:44:34 --> Language Class Initialized
INFO - 2024-06-21 11:44:34 --> Language Class Initialized
INFO - 2024-06-21 11:44:34 --> Config Class Initialized
INFO - 2024-06-21 11:44:34 --> Loader Class Initialized
INFO - 2024-06-21 11:44:34 --> Helper loaded: url_helper
INFO - 2024-06-21 11:44:34 --> Helper loaded: file_helper
INFO - 2024-06-21 11:44:34 --> Helper loaded: form_helper
INFO - 2024-06-21 11:44:34 --> Helper loaded: my_helper
INFO - 2024-06-21 11:44:34 --> Database Driver Class Initialized
INFO - 2024-06-21 11:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 11:44:34 --> Controller Class Initialized
DEBUG - 2024-06-21 11:44:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-21 11:44:36 --> Final output sent to browser
DEBUG - 2024-06-21 11:44:36 --> Total execution time: 2.0452
INFO - 2024-06-21 11:45:20 --> Config Class Initialized
INFO - 2024-06-21 11:45:20 --> Hooks Class Initialized
DEBUG - 2024-06-21 11:45:20 --> UTF-8 Support Enabled
INFO - 2024-06-21 11:45:20 --> Utf8 Class Initialized
INFO - 2024-06-21 11:45:20 --> URI Class Initialized
INFO - 2024-06-21 11:45:20 --> Router Class Initialized
INFO - 2024-06-21 11:45:20 --> Output Class Initialized
INFO - 2024-06-21 11:45:20 --> Security Class Initialized
DEBUG - 2024-06-21 11:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 11:45:20 --> Input Class Initialized
INFO - 2024-06-21 11:45:20 --> Language Class Initialized
INFO - 2024-06-21 11:45:20 --> Language Class Initialized
INFO - 2024-06-21 11:45:20 --> Config Class Initialized
INFO - 2024-06-21 11:45:20 --> Loader Class Initialized
INFO - 2024-06-21 11:45:20 --> Helper loaded: url_helper
INFO - 2024-06-21 11:45:20 --> Helper loaded: file_helper
INFO - 2024-06-21 11:45:20 --> Helper loaded: form_helper
INFO - 2024-06-21 11:45:20 --> Helper loaded: my_helper
INFO - 2024-06-21 11:45:20 --> Database Driver Class Initialized
INFO - 2024-06-21 11:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 11:45:20 --> Controller Class Initialized
DEBUG - 2024-06-21 11:45:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-21 11:45:22 --> Final output sent to browser
DEBUG - 2024-06-21 11:45:22 --> Total execution time: 2.1585
INFO - 2024-06-21 11:46:00 --> Config Class Initialized
INFO - 2024-06-21 11:46:00 --> Hooks Class Initialized
DEBUG - 2024-06-21 11:46:00 --> UTF-8 Support Enabled
INFO - 2024-06-21 11:46:00 --> Utf8 Class Initialized
INFO - 2024-06-21 11:46:00 --> URI Class Initialized
INFO - 2024-06-21 11:46:00 --> Router Class Initialized
INFO - 2024-06-21 11:46:00 --> Output Class Initialized
INFO - 2024-06-21 11:46:00 --> Security Class Initialized
DEBUG - 2024-06-21 11:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 11:46:00 --> Input Class Initialized
INFO - 2024-06-21 11:46:00 --> Language Class Initialized
INFO - 2024-06-21 11:46:00 --> Language Class Initialized
INFO - 2024-06-21 11:46:00 --> Config Class Initialized
INFO - 2024-06-21 11:46:00 --> Loader Class Initialized
INFO - 2024-06-21 11:46:00 --> Helper loaded: url_helper
INFO - 2024-06-21 11:46:00 --> Helper loaded: file_helper
INFO - 2024-06-21 11:46:00 --> Helper loaded: form_helper
INFO - 2024-06-21 11:46:00 --> Helper loaded: my_helper
INFO - 2024-06-21 11:46:00 --> Database Driver Class Initialized
INFO - 2024-06-21 11:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 11:46:00 --> Controller Class Initialized
DEBUG - 2024-06-21 11:46:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-21 11:46:03 --> Final output sent to browser
DEBUG - 2024-06-21 11:46:03 --> Total execution time: 3.8157
INFO - 2024-06-21 11:46:41 --> Config Class Initialized
INFO - 2024-06-21 11:46:41 --> Hooks Class Initialized
DEBUG - 2024-06-21 11:46:41 --> UTF-8 Support Enabled
INFO - 2024-06-21 11:46:41 --> Utf8 Class Initialized
INFO - 2024-06-21 11:46:41 --> URI Class Initialized
INFO - 2024-06-21 11:46:41 --> Router Class Initialized
INFO - 2024-06-21 11:46:41 --> Output Class Initialized
INFO - 2024-06-21 11:46:41 --> Security Class Initialized
DEBUG - 2024-06-21 11:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 11:46:41 --> Input Class Initialized
INFO - 2024-06-21 11:46:41 --> Language Class Initialized
INFO - 2024-06-21 11:46:41 --> Language Class Initialized
INFO - 2024-06-21 11:46:41 --> Config Class Initialized
INFO - 2024-06-21 11:46:41 --> Loader Class Initialized
INFO - 2024-06-21 11:46:41 --> Helper loaded: url_helper
INFO - 2024-06-21 11:46:41 --> Helper loaded: file_helper
INFO - 2024-06-21 11:46:41 --> Helper loaded: form_helper
INFO - 2024-06-21 11:46:41 --> Helper loaded: my_helper
INFO - 2024-06-21 11:46:41 --> Database Driver Class Initialized
INFO - 2024-06-21 11:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 11:46:41 --> Controller Class Initialized
DEBUG - 2024-06-21 11:46:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-21 11:46:43 --> Final output sent to browser
DEBUG - 2024-06-21 11:46:43 --> Total execution time: 2.2688
INFO - 2024-06-21 13:01:16 --> Config Class Initialized
INFO - 2024-06-21 13:01:16 --> Hooks Class Initialized
DEBUG - 2024-06-21 13:01:16 --> UTF-8 Support Enabled
INFO - 2024-06-21 13:01:16 --> Utf8 Class Initialized
INFO - 2024-06-21 13:01:16 --> URI Class Initialized
INFO - 2024-06-21 13:01:16 --> Router Class Initialized
INFO - 2024-06-21 13:01:16 --> Output Class Initialized
INFO - 2024-06-21 13:01:16 --> Security Class Initialized
DEBUG - 2024-06-21 13:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 13:01:16 --> Input Class Initialized
INFO - 2024-06-21 13:01:16 --> Language Class Initialized
INFO - 2024-06-21 13:01:16 --> Language Class Initialized
INFO - 2024-06-21 13:01:16 --> Config Class Initialized
INFO - 2024-06-21 13:01:16 --> Loader Class Initialized
INFO - 2024-06-21 13:01:16 --> Helper loaded: url_helper
INFO - 2024-06-21 13:01:16 --> Helper loaded: file_helper
INFO - 2024-06-21 13:01:16 --> Helper loaded: form_helper
INFO - 2024-06-21 13:01:16 --> Helper loaded: my_helper
INFO - 2024-06-21 13:01:16 --> Database Driver Class Initialized
INFO - 2024-06-21 13:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 13:01:16 --> Controller Class Initialized
INFO - 2024-06-21 13:01:16 --> Helper loaded: cookie_helper
INFO - 2024-06-21 13:01:16 --> Final output sent to browser
DEBUG - 2024-06-21 13:01:16 --> Total execution time: 0.0953
INFO - 2024-06-21 13:01:16 --> Config Class Initialized
INFO - 2024-06-21 13:01:16 --> Hooks Class Initialized
DEBUG - 2024-06-21 13:01:16 --> UTF-8 Support Enabled
INFO - 2024-06-21 13:01:16 --> Utf8 Class Initialized
INFO - 2024-06-21 13:01:16 --> URI Class Initialized
INFO - 2024-06-21 13:01:16 --> Router Class Initialized
INFO - 2024-06-21 13:01:16 --> Output Class Initialized
INFO - 2024-06-21 13:01:16 --> Security Class Initialized
DEBUG - 2024-06-21 13:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 13:01:17 --> Input Class Initialized
INFO - 2024-06-21 13:01:17 --> Language Class Initialized
INFO - 2024-06-21 13:01:17 --> Language Class Initialized
INFO - 2024-06-21 13:01:17 --> Config Class Initialized
INFO - 2024-06-21 13:01:17 --> Loader Class Initialized
INFO - 2024-06-21 13:01:17 --> Helper loaded: url_helper
INFO - 2024-06-21 13:01:17 --> Helper loaded: file_helper
INFO - 2024-06-21 13:01:17 --> Helper loaded: form_helper
INFO - 2024-06-21 13:01:17 --> Helper loaded: my_helper
INFO - 2024-06-21 13:01:17 --> Database Driver Class Initialized
INFO - 2024-06-21 13:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 13:01:17 --> Controller Class Initialized
INFO - 2024-06-21 13:01:17 --> Helper loaded: cookie_helper
INFO - 2024-06-21 13:01:17 --> Final output sent to browser
DEBUG - 2024-06-21 13:01:17 --> Total execution time: 0.0872
INFO - 2024-06-21 13:01:17 --> Config Class Initialized
INFO - 2024-06-21 13:01:17 --> Hooks Class Initialized
DEBUG - 2024-06-21 13:01:17 --> UTF-8 Support Enabled
INFO - 2024-06-21 13:01:17 --> Utf8 Class Initialized
INFO - 2024-06-21 13:01:17 --> URI Class Initialized
INFO - 2024-06-21 13:01:17 --> Router Class Initialized
INFO - 2024-06-21 13:01:17 --> Output Class Initialized
INFO - 2024-06-21 13:01:17 --> Security Class Initialized
DEBUG - 2024-06-21 13:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 13:01:17 --> Input Class Initialized
INFO - 2024-06-21 13:01:17 --> Language Class Initialized
INFO - 2024-06-21 13:01:17 --> Language Class Initialized
INFO - 2024-06-21 13:01:17 --> Config Class Initialized
INFO - 2024-06-21 13:01:17 --> Loader Class Initialized
INFO - 2024-06-21 13:01:17 --> Helper loaded: url_helper
INFO - 2024-06-21 13:01:17 --> Helper loaded: file_helper
INFO - 2024-06-21 13:01:17 --> Helper loaded: form_helper
INFO - 2024-06-21 13:01:17 --> Helper loaded: my_helper
INFO - 2024-06-21 13:01:17 --> Database Driver Class Initialized
INFO - 2024-06-21 13:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 13:01:17 --> Controller Class Initialized
INFO - 2024-06-21 13:01:17 --> Config Class Initialized
INFO - 2024-06-21 13:01:17 --> Hooks Class Initialized
INFO - 2024-06-21 13:01:17 --> Helper loaded: cookie_helper
DEBUG - 2024-06-21 13:01:17 --> UTF-8 Support Enabled
INFO - 2024-06-21 13:01:17 --> Utf8 Class Initialized
INFO - 2024-06-21 13:01:17 --> URI Class Initialized
INFO - 2024-06-21 13:01:17 --> Router Class Initialized
INFO - 2024-06-21 13:01:17 --> Output Class Initialized
INFO - 2024-06-21 13:01:17 --> Security Class Initialized
DEBUG - 2024-06-21 13:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 13:01:17 --> Input Class Initialized
INFO - 2024-06-21 13:01:17 --> Language Class Initialized
INFO - 2024-06-21 13:01:17 --> Language Class Initialized
INFO - 2024-06-21 13:01:17 --> Config Class Initialized
INFO - 2024-06-21 13:01:17 --> Loader Class Initialized
INFO - 2024-06-21 13:01:17 --> Helper loaded: url_helper
INFO - 2024-06-21 13:01:17 --> Helper loaded: file_helper
INFO - 2024-06-21 13:01:17 --> Helper loaded: form_helper
INFO - 2024-06-21 13:01:17 --> Helper loaded: my_helper
INFO - 2024-06-21 13:01:17 --> Database Driver Class Initialized
INFO - 2024-06-21 13:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 13:01:17 --> Controller Class Initialized
INFO - 2024-06-21 13:01:17 --> Helper loaded: cookie_helper
INFO - 2024-06-21 13:01:17 --> Config Class Initialized
INFO - 2024-06-21 13:01:17 --> Hooks Class Initialized
DEBUG - 2024-06-21 13:01:17 --> UTF-8 Support Enabled
INFO - 2024-06-21 13:01:17 --> Utf8 Class Initialized
INFO - 2024-06-21 13:01:17 --> URI Class Initialized
INFO - 2024-06-21 13:01:17 --> Router Class Initialized
INFO - 2024-06-21 13:01:17 --> Output Class Initialized
INFO - 2024-06-21 13:01:17 --> Security Class Initialized
DEBUG - 2024-06-21 13:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 13:01:17 --> Input Class Initialized
INFO - 2024-06-21 13:01:17 --> Language Class Initialized
INFO - 2024-06-21 13:01:17 --> Language Class Initialized
INFO - 2024-06-21 13:01:17 --> Config Class Initialized
INFO - 2024-06-21 13:01:17 --> Loader Class Initialized
INFO - 2024-06-21 13:01:17 --> Config Class Initialized
INFO - 2024-06-21 13:01:17 --> Hooks Class Initialized
DEBUG - 2024-06-21 13:01:17 --> UTF-8 Support Enabled
INFO - 2024-06-21 13:01:17 --> Utf8 Class Initialized
INFO - 2024-06-21 13:01:17 --> Helper loaded: url_helper
INFO - 2024-06-21 13:01:17 --> Helper loaded: file_helper
INFO - 2024-06-21 13:01:17 --> Helper loaded: form_helper
INFO - 2024-06-21 13:01:17 --> Helper loaded: my_helper
INFO - 2024-06-21 13:01:17 --> Database Driver Class Initialized
INFO - 2024-06-21 13:01:17 --> URI Class Initialized
INFO - 2024-06-21 13:01:17 --> Router Class Initialized
INFO - 2024-06-21 13:01:17 --> Output Class Initialized
INFO - 2024-06-21 13:01:17 --> Security Class Initialized
DEBUG - 2024-06-21 13:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 13:01:17 --> Input Class Initialized
INFO - 2024-06-21 13:01:17 --> Language Class Initialized
INFO - 2024-06-21 13:01:17 --> Language Class Initialized
INFO - 2024-06-21 13:01:17 --> Config Class Initialized
INFO - 2024-06-21 13:01:17 --> Loader Class Initialized
INFO - 2024-06-21 13:01:17 --> Helper loaded: url_helper
INFO - 2024-06-21 13:01:17 --> Helper loaded: file_helper
INFO - 2024-06-21 13:01:17 --> Helper loaded: form_helper
INFO - 2024-06-21 13:01:17 --> Helper loaded: my_helper
INFO - 2024-06-21 13:01:17 --> Database Driver Class Initialized
INFO - 2024-06-21 13:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 13:01:17 --> Controller Class Initialized
INFO - 2024-06-21 13:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 13:01:17 --> Controller Class Initialized
INFO - 2024-06-21 13:01:17 --> Helper loaded: cookie_helper
DEBUG - 2024-06-21 13:01:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-06-21 13:01:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 13:01:17 --> Final output sent to browser
DEBUG - 2024-06-21 13:01:17 --> Total execution time: 0.0728
INFO - 2024-06-21 13:01:17 --> Config Class Initialized
INFO - 2024-06-21 13:01:17 --> Hooks Class Initialized
DEBUG - 2024-06-21 13:01:17 --> UTF-8 Support Enabled
INFO - 2024-06-21 13:01:17 --> Utf8 Class Initialized
INFO - 2024-06-21 13:01:17 --> URI Class Initialized
INFO - 2024-06-21 13:01:17 --> Router Class Initialized
INFO - 2024-06-21 13:01:17 --> Output Class Initialized
INFO - 2024-06-21 13:01:17 --> Security Class Initialized
DEBUG - 2024-06-21 13:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 13:01:17 --> Input Class Initialized
INFO - 2024-06-21 13:01:17 --> Language Class Initialized
INFO - 2024-06-21 13:01:17 --> Language Class Initialized
INFO - 2024-06-21 13:01:17 --> Config Class Initialized
INFO - 2024-06-21 13:01:17 --> Loader Class Initialized
INFO - 2024-06-21 13:01:17 --> Helper loaded: url_helper
INFO - 2024-06-21 13:01:17 --> Helper loaded: file_helper
INFO - 2024-06-21 13:01:17 --> Helper loaded: form_helper
INFO - 2024-06-21 13:01:17 --> Helper loaded: my_helper
INFO - 2024-06-21 13:01:17 --> Database Driver Class Initialized
INFO - 2024-06-21 13:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 13:01:17 --> Controller Class Initialized
DEBUG - 2024-06-21 13:01:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-06-21 13:01:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 13:01:17 --> Final output sent to browser
DEBUG - 2024-06-21 13:01:17 --> Total execution time: 0.0341
INFO - 2024-06-21 13:01:19 --> Config Class Initialized
INFO - 2024-06-21 13:01:19 --> Hooks Class Initialized
DEBUG - 2024-06-21 13:01:19 --> UTF-8 Support Enabled
INFO - 2024-06-21 13:01:19 --> Utf8 Class Initialized
INFO - 2024-06-21 13:01:19 --> URI Class Initialized
INFO - 2024-06-21 13:01:19 --> Router Class Initialized
INFO - 2024-06-21 13:01:19 --> Output Class Initialized
INFO - 2024-06-21 13:01:19 --> Security Class Initialized
DEBUG - 2024-06-21 13:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 13:01:19 --> Input Class Initialized
INFO - 2024-06-21 13:01:19 --> Language Class Initialized
INFO - 2024-06-21 13:01:19 --> Language Class Initialized
INFO - 2024-06-21 13:01:19 --> Config Class Initialized
INFO - 2024-06-21 13:01:19 --> Loader Class Initialized
INFO - 2024-06-21 13:01:19 --> Helper loaded: url_helper
INFO - 2024-06-21 13:01:19 --> Helper loaded: file_helper
INFO - 2024-06-21 13:01:19 --> Helper loaded: form_helper
INFO - 2024-06-21 13:01:19 --> Helper loaded: my_helper
INFO - 2024-06-21 13:01:19 --> Database Driver Class Initialized
INFO - 2024-06-21 13:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 13:01:19 --> Controller Class Initialized
INFO - 2024-06-21 13:01:19 --> Helper loaded: cookie_helper
INFO - 2024-06-21 13:01:19 --> Final output sent to browser
DEBUG - 2024-06-21 13:01:19 --> Total execution time: 0.0627
INFO - 2024-06-21 13:01:19 --> Config Class Initialized
INFO - 2024-06-21 13:01:19 --> Hooks Class Initialized
DEBUG - 2024-06-21 13:01:19 --> UTF-8 Support Enabled
INFO - 2024-06-21 13:01:19 --> Utf8 Class Initialized
INFO - 2024-06-21 13:01:19 --> URI Class Initialized
INFO - 2024-06-21 13:01:19 --> Router Class Initialized
INFO - 2024-06-21 13:01:19 --> Output Class Initialized
INFO - 2024-06-21 13:01:19 --> Security Class Initialized
DEBUG - 2024-06-21 13:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 13:01:19 --> Input Class Initialized
INFO - 2024-06-21 13:01:19 --> Language Class Initialized
INFO - 2024-06-21 13:01:19 --> Language Class Initialized
INFO - 2024-06-21 13:01:19 --> Config Class Initialized
INFO - 2024-06-21 13:01:19 --> Loader Class Initialized
INFO - 2024-06-21 13:01:19 --> Helper loaded: url_helper
INFO - 2024-06-21 13:01:19 --> Helper loaded: file_helper
INFO - 2024-06-21 13:01:19 --> Helper loaded: form_helper
INFO - 2024-06-21 13:01:19 --> Config Class Initialized
INFO - 2024-06-21 13:01:19 --> Hooks Class Initialized
DEBUG - 2024-06-21 13:01:19 --> UTF-8 Support Enabled
INFO - 2024-06-21 13:01:19 --> Utf8 Class Initialized
INFO - 2024-06-21 13:01:19 --> URI Class Initialized
INFO - 2024-06-21 13:01:19 --> Router Class Initialized
INFO - 2024-06-21 13:01:19 --> Output Class Initialized
INFO - 2024-06-21 13:01:19 --> Security Class Initialized
DEBUG - 2024-06-21 13:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 13:01:19 --> Input Class Initialized
INFO - 2024-06-21 13:01:19 --> Language Class Initialized
INFO - 2024-06-21 13:01:19 --> Language Class Initialized
INFO - 2024-06-21 13:01:19 --> Config Class Initialized
INFO - 2024-06-21 13:01:19 --> Loader Class Initialized
INFO - 2024-06-21 13:01:19 --> Helper loaded: url_helper
INFO - 2024-06-21 13:01:19 --> Helper loaded: file_helper
INFO - 2024-06-21 13:01:19 --> Helper loaded: my_helper
INFO - 2024-06-21 13:01:19 --> Database Driver Class Initialized
INFO - 2024-06-21 13:01:19 --> Helper loaded: form_helper
INFO - 2024-06-21 13:01:19 --> Helper loaded: my_helper
INFO - 2024-06-21 13:01:19 --> Database Driver Class Initialized
INFO - 2024-06-21 13:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 13:01:19 --> Controller Class Initialized
INFO - 2024-06-21 13:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 13:01:19 --> Controller Class Initialized
INFO - 2024-06-21 13:01:19 --> Helper loaded: cookie_helper
INFO - 2024-06-21 13:01:19 --> Config Class Initialized
INFO - 2024-06-21 13:01:19 --> Hooks Class Initialized
DEBUG - 2024-06-21 13:01:19 --> UTF-8 Support Enabled
INFO - 2024-06-21 13:01:19 --> Utf8 Class Initialized
INFO - 2024-06-21 13:01:19 --> Helper loaded: cookie_helper
INFO - 2024-06-21 13:01:19 --> Final output sent to browser
DEBUG - 2024-06-21 13:01:19 --> Total execution time: 0.0734
INFO - 2024-06-21 13:01:19 --> URI Class Initialized
INFO - 2024-06-21 13:01:19 --> Router Class Initialized
INFO - 2024-06-21 13:01:19 --> Output Class Initialized
INFO - 2024-06-21 13:01:19 --> Security Class Initialized
DEBUG - 2024-06-21 13:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 13:01:19 --> Input Class Initialized
INFO - 2024-06-21 13:01:19 --> Language Class Initialized
INFO - 2024-06-21 13:01:19 --> Language Class Initialized
INFO - 2024-06-21 13:01:19 --> Config Class Initialized
INFO - 2024-06-21 13:01:19 --> Loader Class Initialized
INFO - 2024-06-21 13:01:19 --> Helper loaded: url_helper
INFO - 2024-06-21 13:01:19 --> Helper loaded: file_helper
INFO - 2024-06-21 13:01:19 --> Helper loaded: form_helper
INFO - 2024-06-21 13:01:19 --> Helper loaded: my_helper
INFO - 2024-06-21 13:01:19 --> Database Driver Class Initialized
INFO - 2024-06-21 13:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 13:01:19 --> Controller Class Initialized
INFO - 2024-06-21 13:01:19 --> Helper loaded: cookie_helper
INFO - 2024-06-21 13:01:19 --> Config Class Initialized
INFO - 2024-06-21 13:01:19 --> Hooks Class Initialized
DEBUG - 2024-06-21 13:01:19 --> UTF-8 Support Enabled
INFO - 2024-06-21 13:01:19 --> Utf8 Class Initialized
INFO - 2024-06-21 13:01:19 --> URI Class Initialized
INFO - 2024-06-21 13:01:19 --> Router Class Initialized
INFO - 2024-06-21 13:01:19 --> Output Class Initialized
INFO - 2024-06-21 13:01:19 --> Security Class Initialized
DEBUG - 2024-06-21 13:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 13:01:19 --> Input Class Initialized
INFO - 2024-06-21 13:01:19 --> Language Class Initialized
INFO - 2024-06-21 13:01:19 --> Language Class Initialized
INFO - 2024-06-21 13:01:19 --> Config Class Initialized
INFO - 2024-06-21 13:01:19 --> Loader Class Initialized
INFO - 2024-06-21 13:01:19 --> Helper loaded: url_helper
INFO - 2024-06-21 13:01:19 --> Helper loaded: file_helper
INFO - 2024-06-21 13:01:19 --> Helper loaded: form_helper
INFO - 2024-06-21 13:01:19 --> Helper loaded: my_helper
INFO - 2024-06-21 13:01:19 --> Config Class Initialized
INFO - 2024-06-21 13:01:19 --> Hooks Class Initialized
INFO - 2024-06-21 13:01:19 --> Database Driver Class Initialized
DEBUG - 2024-06-21 13:01:19 --> UTF-8 Support Enabled
INFO - 2024-06-21 13:01:19 --> Utf8 Class Initialized
INFO - 2024-06-21 13:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 13:01:19 --> Controller Class Initialized
INFO - 2024-06-21 13:01:19 --> URI Class Initialized
INFO - 2024-06-21 13:01:19 --> Helper loaded: cookie_helper
INFO - 2024-06-21 13:01:19 --> Router Class Initialized
INFO - 2024-06-21 13:01:19 --> Output Class Initialized
INFO - 2024-06-21 13:01:19 --> Security Class Initialized
INFO - 2024-06-21 13:01:19 --> Config Class Initialized
INFO - 2024-06-21 13:01:19 --> Hooks Class Initialized
DEBUG - 2024-06-21 13:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 13:01:19 --> Input Class Initialized
INFO - 2024-06-21 13:01:19 --> Language Class Initialized
DEBUG - 2024-06-21 13:01:19 --> UTF-8 Support Enabled
INFO - 2024-06-21 13:01:19 --> Utf8 Class Initialized
INFO - 2024-06-21 13:01:19 --> URI Class Initialized
INFO - 2024-06-21 13:01:19 --> Router Class Initialized
INFO - 2024-06-21 13:01:19 --> Language Class Initialized
INFO - 2024-06-21 13:01:19 --> Config Class Initialized
INFO - 2024-06-21 13:01:19 --> Loader Class Initialized
INFO - 2024-06-21 13:01:19 --> Helper loaded: url_helper
INFO - 2024-06-21 13:01:19 --> Helper loaded: file_helper
INFO - 2024-06-21 13:01:19 --> Output Class Initialized
INFO - 2024-06-21 13:01:19 --> Security Class Initialized
INFO - 2024-06-21 13:01:19 --> Helper loaded: form_helper
INFO - 2024-06-21 13:01:19 --> Helper loaded: my_helper
DEBUG - 2024-06-21 13:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 13:01:20 --> Input Class Initialized
INFO - 2024-06-21 13:01:20 --> Language Class Initialized
INFO - 2024-06-21 13:01:20 --> Database Driver Class Initialized
INFO - 2024-06-21 13:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 13:01:20 --> Controller Class Initialized
INFO - 2024-06-21 13:01:20 --> Language Class Initialized
INFO - 2024-06-21 13:01:20 --> Config Class Initialized
INFO - 2024-06-21 13:01:20 --> Loader Class Initialized
DEBUG - 2024-06-21 13:01:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-06-21 13:01:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 13:01:20 --> Final output sent to browser
DEBUG - 2024-06-21 13:01:20 --> Total execution time: 0.1592
INFO - 2024-06-21 13:01:20 --> Helper loaded: url_helper
INFO - 2024-06-21 13:01:20 --> Helper loaded: file_helper
INFO - 2024-06-21 13:01:20 --> Helper loaded: form_helper
INFO - 2024-06-21 13:01:20 --> Helper loaded: my_helper
INFO - 2024-06-21 13:01:20 --> Database Driver Class Initialized
INFO - 2024-06-21 13:01:20 --> Config Class Initialized
INFO - 2024-06-21 13:01:20 --> Hooks Class Initialized
DEBUG - 2024-06-21 13:01:20 --> UTF-8 Support Enabled
INFO - 2024-06-21 13:01:20 --> Utf8 Class Initialized
INFO - 2024-06-21 13:01:20 --> URI Class Initialized
INFO - 2024-06-21 13:01:20 --> Router Class Initialized
INFO - 2024-06-21 13:01:20 --> Output Class Initialized
INFO - 2024-06-21 13:01:20 --> Security Class Initialized
DEBUG - 2024-06-21 13:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 13:01:20 --> Input Class Initialized
INFO - 2024-06-21 13:01:20 --> Language Class Initialized
INFO - 2024-06-21 13:01:20 --> Language Class Initialized
INFO - 2024-06-21 13:01:20 --> Config Class Initialized
INFO - 2024-06-21 13:01:20 --> Loader Class Initialized
INFO - 2024-06-21 13:01:20 --> Helper loaded: url_helper
INFO - 2024-06-21 13:01:20 --> Helper loaded: file_helper
INFO - 2024-06-21 13:01:20 --> Helper loaded: form_helper
INFO - 2024-06-21 13:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 13:01:20 --> Controller Class Initialized
INFO - 2024-06-21 13:01:20 --> Helper loaded: my_helper
INFO - 2024-06-21 13:01:20 --> Database Driver Class Initialized
INFO - 2024-06-21 13:01:20 --> Helper loaded: cookie_helper
INFO - 2024-06-21 13:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 13:01:20 --> Controller Class Initialized
INFO - 2024-06-21 13:01:20 --> Helper loaded: cookie_helper
INFO - 2024-06-21 13:01:20 --> Final output sent to browser
DEBUG - 2024-06-21 13:01:20 --> Total execution time: 0.1400
INFO - 2024-06-21 13:01:20 --> Config Class Initialized
INFO - 2024-06-21 13:01:20 --> Hooks Class Initialized
DEBUG - 2024-06-21 13:01:20 --> UTF-8 Support Enabled
INFO - 2024-06-21 13:01:20 --> Utf8 Class Initialized
INFO - 2024-06-21 13:01:20 --> URI Class Initialized
INFO - 2024-06-21 13:01:20 --> Router Class Initialized
INFO - 2024-06-21 13:01:20 --> Output Class Initialized
INFO - 2024-06-21 13:01:20 --> Security Class Initialized
DEBUG - 2024-06-21 13:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 13:01:20 --> Input Class Initialized
INFO - 2024-06-21 13:01:20 --> Language Class Initialized
INFO - 2024-06-21 13:01:20 --> Language Class Initialized
INFO - 2024-06-21 13:01:20 --> Config Class Initialized
INFO - 2024-06-21 13:01:20 --> Loader Class Initialized
INFO - 2024-06-21 13:01:20 --> Helper loaded: url_helper
INFO - 2024-06-21 13:01:20 --> Helper loaded: file_helper
INFO - 2024-06-21 13:01:20 --> Helper loaded: form_helper
INFO - 2024-06-21 13:01:20 --> Helper loaded: my_helper
INFO - 2024-06-21 13:01:20 --> Database Driver Class Initialized
INFO - 2024-06-21 13:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 13:01:20 --> Controller Class Initialized
DEBUG - 2024-06-21 13:01:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-06-21 13:01:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 13:01:20 --> Final output sent to browser
DEBUG - 2024-06-21 13:01:20 --> Total execution time: 0.0333
INFO - 2024-06-21 13:01:20 --> Config Class Initialized
INFO - 2024-06-21 13:01:20 --> Hooks Class Initialized
DEBUG - 2024-06-21 13:01:20 --> UTF-8 Support Enabled
INFO - 2024-06-21 13:01:20 --> Utf8 Class Initialized
INFO - 2024-06-21 13:01:20 --> URI Class Initialized
INFO - 2024-06-21 13:01:20 --> Router Class Initialized
INFO - 2024-06-21 13:01:20 --> Output Class Initialized
INFO - 2024-06-21 13:01:20 --> Security Class Initialized
DEBUG - 2024-06-21 13:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 13:01:20 --> Input Class Initialized
INFO - 2024-06-21 13:01:20 --> Language Class Initialized
INFO - 2024-06-21 13:01:20 --> Language Class Initialized
INFO - 2024-06-21 13:01:20 --> Config Class Initialized
INFO - 2024-06-21 13:01:20 --> Loader Class Initialized
INFO - 2024-06-21 13:01:20 --> Helper loaded: url_helper
INFO - 2024-06-21 13:01:20 --> Helper loaded: file_helper
INFO - 2024-06-21 13:01:20 --> Helper loaded: form_helper
INFO - 2024-06-21 13:01:20 --> Helper loaded: my_helper
INFO - 2024-06-21 13:01:20 --> Database Driver Class Initialized
INFO - 2024-06-21 13:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 13:01:20 --> Controller Class Initialized
INFO - 2024-06-21 13:01:20 --> Helper loaded: cookie_helper
INFO - 2024-06-21 13:01:20 --> Config Class Initialized
INFO - 2024-06-21 13:01:20 --> Hooks Class Initialized
DEBUG - 2024-06-21 13:01:20 --> UTF-8 Support Enabled
INFO - 2024-06-21 13:01:20 --> Utf8 Class Initialized
INFO - 2024-06-21 13:01:20 --> URI Class Initialized
INFO - 2024-06-21 13:01:20 --> Router Class Initialized
INFO - 2024-06-21 13:01:20 --> Output Class Initialized
INFO - 2024-06-21 13:01:20 --> Config Class Initialized
INFO - 2024-06-21 13:01:20 --> Hooks Class Initialized
DEBUG - 2024-06-21 13:01:20 --> UTF-8 Support Enabled
INFO - 2024-06-21 13:01:20 --> Utf8 Class Initialized
INFO - 2024-06-21 13:01:20 --> URI Class Initialized
INFO - 2024-06-21 13:01:20 --> Router Class Initialized
INFO - 2024-06-21 13:01:20 --> Output Class Initialized
INFO - 2024-06-21 13:01:20 --> Security Class Initialized
DEBUG - 2024-06-21 13:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 13:01:20 --> Input Class Initialized
INFO - 2024-06-21 13:01:20 --> Language Class Initialized
INFO - 2024-06-21 13:01:20 --> Language Class Initialized
INFO - 2024-06-21 13:01:20 --> Config Class Initialized
INFO - 2024-06-21 13:01:20 --> Loader Class Initialized
INFO - 2024-06-21 13:01:20 --> Helper loaded: url_helper
INFO - 2024-06-21 13:01:20 --> Helper loaded: file_helper
INFO - 2024-06-21 13:01:20 --> Security Class Initialized
DEBUG - 2024-06-21 13:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 13:01:20 --> Input Class Initialized
INFO - 2024-06-21 13:01:20 --> Language Class Initialized
INFO - 2024-06-21 13:01:20 --> Language Class Initialized
INFO - 2024-06-21 13:01:20 --> Config Class Initialized
INFO - 2024-06-21 13:01:20 --> Loader Class Initialized
INFO - 2024-06-21 13:01:20 --> Helper loaded: url_helper
INFO - 2024-06-21 13:01:20 --> Helper loaded: file_helper
INFO - 2024-06-21 13:01:20 --> Helper loaded: form_helper
INFO - 2024-06-21 13:01:20 --> Helper loaded: form_helper
INFO - 2024-06-21 13:01:20 --> Helper loaded: my_helper
INFO - 2024-06-21 13:01:20 --> Database Driver Class Initialized
INFO - 2024-06-21 13:01:20 --> Helper loaded: my_helper
INFO - 2024-06-21 13:01:20 --> Database Driver Class Initialized
INFO - 2024-06-21 13:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 13:01:20 --> Controller Class Initialized
DEBUG - 2024-06-21 13:01:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-06-21 13:01:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 13:01:20 --> Final output sent to browser
DEBUG - 2024-06-21 13:01:20 --> Total execution time: 0.0616
INFO - 2024-06-21 13:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 13:01:20 --> Controller Class Initialized
INFO - 2024-06-21 13:01:20 --> Helper loaded: cookie_helper
INFO - 2024-06-21 13:01:28 --> Config Class Initialized
INFO - 2024-06-21 13:01:28 --> Hooks Class Initialized
DEBUG - 2024-06-21 13:01:28 --> UTF-8 Support Enabled
INFO - 2024-06-21 13:01:28 --> Utf8 Class Initialized
INFO - 2024-06-21 13:01:28 --> URI Class Initialized
INFO - 2024-06-21 13:01:28 --> Router Class Initialized
INFO - 2024-06-21 13:01:28 --> Output Class Initialized
INFO - 2024-06-21 13:01:28 --> Security Class Initialized
DEBUG - 2024-06-21 13:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 13:01:28 --> Input Class Initialized
INFO - 2024-06-21 13:01:28 --> Language Class Initialized
INFO - 2024-06-21 13:01:28 --> Language Class Initialized
INFO - 2024-06-21 13:01:28 --> Config Class Initialized
INFO - 2024-06-21 13:01:28 --> Loader Class Initialized
INFO - 2024-06-21 13:01:28 --> Helper loaded: url_helper
INFO - 2024-06-21 13:01:28 --> Helper loaded: file_helper
INFO - 2024-06-21 13:01:28 --> Helper loaded: form_helper
INFO - 2024-06-21 13:01:28 --> Helper loaded: my_helper
INFO - 2024-06-21 13:01:28 --> Database Driver Class Initialized
INFO - 2024-06-21 13:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 13:01:28 --> Controller Class Initialized
DEBUG - 2024-06-21 13:01:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-06-21 13:01:32 --> Final output sent to browser
DEBUG - 2024-06-21 13:01:32 --> Total execution time: 4.0229
INFO - 2024-06-21 13:10:32 --> Config Class Initialized
INFO - 2024-06-21 13:10:32 --> Hooks Class Initialized
DEBUG - 2024-06-21 13:10:32 --> UTF-8 Support Enabled
INFO - 2024-06-21 13:10:32 --> Utf8 Class Initialized
INFO - 2024-06-21 13:10:32 --> URI Class Initialized
INFO - 2024-06-21 13:10:32 --> Router Class Initialized
INFO - 2024-06-21 13:10:32 --> Output Class Initialized
INFO - 2024-06-21 13:10:32 --> Security Class Initialized
DEBUG - 2024-06-21 13:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 13:10:32 --> Input Class Initialized
INFO - 2024-06-21 13:10:32 --> Language Class Initialized
INFO - 2024-06-21 13:10:32 --> Language Class Initialized
INFO - 2024-06-21 13:10:32 --> Config Class Initialized
INFO - 2024-06-21 13:10:32 --> Loader Class Initialized
INFO - 2024-06-21 13:10:32 --> Helper loaded: url_helper
INFO - 2024-06-21 13:10:32 --> Helper loaded: file_helper
INFO - 2024-06-21 13:10:32 --> Helper loaded: form_helper
INFO - 2024-06-21 13:10:32 --> Helper loaded: my_helper
INFO - 2024-06-21 13:10:32 --> Database Driver Class Initialized
INFO - 2024-06-21 13:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 13:10:32 --> Controller Class Initialized
DEBUG - 2024-06-21 13:10:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-21 13:10:34 --> Final output sent to browser
DEBUG - 2024-06-21 13:10:34 --> Total execution time: 2.6308
INFO - 2024-06-21 13:10:41 --> Config Class Initialized
INFO - 2024-06-21 13:10:41 --> Hooks Class Initialized
DEBUG - 2024-06-21 13:10:41 --> UTF-8 Support Enabled
INFO - 2024-06-21 13:10:41 --> Utf8 Class Initialized
INFO - 2024-06-21 13:10:41 --> URI Class Initialized
INFO - 2024-06-21 13:10:41 --> Router Class Initialized
INFO - 2024-06-21 13:10:41 --> Output Class Initialized
INFO - 2024-06-21 13:10:41 --> Security Class Initialized
DEBUG - 2024-06-21 13:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 13:10:41 --> Input Class Initialized
INFO - 2024-06-21 13:10:41 --> Language Class Initialized
INFO - 2024-06-21 13:10:41 --> Language Class Initialized
INFO - 2024-06-21 13:10:41 --> Config Class Initialized
INFO - 2024-06-21 13:10:41 --> Loader Class Initialized
INFO - 2024-06-21 13:10:41 --> Helper loaded: url_helper
INFO - 2024-06-21 13:10:41 --> Helper loaded: file_helper
INFO - 2024-06-21 13:10:41 --> Helper loaded: form_helper
INFO - 2024-06-21 13:10:41 --> Helper loaded: my_helper
INFO - 2024-06-21 13:10:41 --> Database Driver Class Initialized
INFO - 2024-06-21 13:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 13:10:41 --> Controller Class Initialized
DEBUG - 2024-06-21 13:10:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-21 13:10:46 --> Final output sent to browser
DEBUG - 2024-06-21 13:10:46 --> Total execution time: 5.3331
INFO - 2024-06-21 13:10:55 --> Config Class Initialized
INFO - 2024-06-21 13:10:55 --> Hooks Class Initialized
DEBUG - 2024-06-21 13:10:55 --> UTF-8 Support Enabled
INFO - 2024-06-21 13:10:55 --> Utf8 Class Initialized
INFO - 2024-06-21 13:10:55 --> URI Class Initialized
INFO - 2024-06-21 13:10:55 --> Router Class Initialized
INFO - 2024-06-21 13:10:55 --> Output Class Initialized
INFO - 2024-06-21 13:10:55 --> Security Class Initialized
DEBUG - 2024-06-21 13:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 13:10:55 --> Input Class Initialized
INFO - 2024-06-21 13:10:55 --> Language Class Initialized
INFO - 2024-06-21 13:10:55 --> Language Class Initialized
INFO - 2024-06-21 13:10:55 --> Config Class Initialized
INFO - 2024-06-21 13:10:55 --> Loader Class Initialized
INFO - 2024-06-21 13:10:55 --> Helper loaded: url_helper
INFO - 2024-06-21 13:10:55 --> Helper loaded: file_helper
INFO - 2024-06-21 13:10:55 --> Helper loaded: form_helper
INFO - 2024-06-21 13:10:55 --> Helper loaded: my_helper
INFO - 2024-06-21 13:10:55 --> Database Driver Class Initialized
INFO - 2024-06-21 13:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 13:10:55 --> Controller Class Initialized
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:10:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-21 13:10:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-21 13:11:03 --> Final output sent to browser
DEBUG - 2024-06-21 13:11:03 --> Total execution time: 8.5927
INFO - 2024-06-21 13:11:09 --> Config Class Initialized
INFO - 2024-06-21 13:11:09 --> Hooks Class Initialized
DEBUG - 2024-06-21 13:11:09 --> UTF-8 Support Enabled
INFO - 2024-06-21 13:11:09 --> Utf8 Class Initialized
INFO - 2024-06-21 13:11:09 --> URI Class Initialized
INFO - 2024-06-21 13:11:09 --> Router Class Initialized
INFO - 2024-06-21 13:11:09 --> Output Class Initialized
INFO - 2024-06-21 13:11:09 --> Security Class Initialized
DEBUG - 2024-06-21 13:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 13:11:09 --> Input Class Initialized
INFO - 2024-06-21 13:11:09 --> Language Class Initialized
INFO - 2024-06-21 13:11:09 --> Language Class Initialized
INFO - 2024-06-21 13:11:09 --> Config Class Initialized
INFO - 2024-06-21 13:11:09 --> Loader Class Initialized
INFO - 2024-06-21 13:11:09 --> Helper loaded: url_helper
INFO - 2024-06-21 13:11:09 --> Helper loaded: file_helper
INFO - 2024-06-21 13:11:09 --> Helper loaded: form_helper
INFO - 2024-06-21 13:11:09 --> Helper loaded: my_helper
INFO - 2024-06-21 13:11:09 --> Database Driver Class Initialized
INFO - 2024-06-21 13:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 13:11:09 --> Controller Class Initialized
DEBUG - 2024-06-21 13:11:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-21 13:11:15 --> Final output sent to browser
DEBUG - 2024-06-21 13:11:15 --> Total execution time: 6.3447
INFO - 2024-06-21 13:17:15 --> Config Class Initialized
INFO - 2024-06-21 13:17:15 --> Hooks Class Initialized
DEBUG - 2024-06-21 13:17:15 --> UTF-8 Support Enabled
INFO - 2024-06-21 13:17:15 --> Utf8 Class Initialized
INFO - 2024-06-21 13:17:15 --> URI Class Initialized
INFO - 2024-06-21 13:17:15 --> Router Class Initialized
INFO - 2024-06-21 13:17:15 --> Output Class Initialized
INFO - 2024-06-21 13:17:15 --> Security Class Initialized
DEBUG - 2024-06-21 13:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 13:17:15 --> Input Class Initialized
INFO - 2024-06-21 13:17:15 --> Language Class Initialized
INFO - 2024-06-21 13:17:15 --> Language Class Initialized
INFO - 2024-06-21 13:17:15 --> Config Class Initialized
INFO - 2024-06-21 13:17:15 --> Loader Class Initialized
INFO - 2024-06-21 13:17:15 --> Helper loaded: url_helper
INFO - 2024-06-21 13:17:15 --> Helper loaded: file_helper
INFO - 2024-06-21 13:17:15 --> Helper loaded: form_helper
INFO - 2024-06-21 13:17:15 --> Helper loaded: my_helper
INFO - 2024-06-21 13:17:15 --> Database Driver Class Initialized
INFO - 2024-06-21 13:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 13:17:15 --> Controller Class Initialized
DEBUG - 2024-06-21 13:17:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-21 13:17:23 --> Final output sent to browser
DEBUG - 2024-06-21 13:17:23 --> Total execution time: 8.0039
INFO - 2024-06-21 13:17:54 --> Config Class Initialized
INFO - 2024-06-21 13:17:54 --> Hooks Class Initialized
DEBUG - 2024-06-21 13:17:54 --> UTF-8 Support Enabled
INFO - 2024-06-21 13:17:54 --> Utf8 Class Initialized
INFO - 2024-06-21 13:17:54 --> URI Class Initialized
INFO - 2024-06-21 13:17:55 --> Router Class Initialized
INFO - 2024-06-21 13:17:55 --> Output Class Initialized
INFO - 2024-06-21 13:17:55 --> Security Class Initialized
DEBUG - 2024-06-21 13:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 13:17:55 --> Input Class Initialized
INFO - 2024-06-21 13:17:55 --> Language Class Initialized
INFO - 2024-06-21 13:17:55 --> Language Class Initialized
INFO - 2024-06-21 13:17:55 --> Config Class Initialized
INFO - 2024-06-21 13:17:55 --> Loader Class Initialized
INFO - 2024-06-21 13:17:55 --> Helper loaded: url_helper
INFO - 2024-06-21 13:17:55 --> Helper loaded: file_helper
INFO - 2024-06-21 13:17:55 --> Helper loaded: form_helper
INFO - 2024-06-21 13:17:55 --> Helper loaded: my_helper
INFO - 2024-06-21 13:17:55 --> Database Driver Class Initialized
INFO - 2024-06-21 13:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 13:17:55 --> Controller Class Initialized
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 13:17:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-21 13:17:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-21 13:18:04 --> Final output sent to browser
DEBUG - 2024-06-21 13:18:04 --> Total execution time: 9.3701
INFO - 2024-06-21 13:18:35 --> Config Class Initialized
INFO - 2024-06-21 13:18:35 --> Hooks Class Initialized
DEBUG - 2024-06-21 13:18:35 --> UTF-8 Support Enabled
INFO - 2024-06-21 13:18:35 --> Utf8 Class Initialized
INFO - 2024-06-21 13:18:35 --> URI Class Initialized
INFO - 2024-06-21 13:18:35 --> Router Class Initialized
INFO - 2024-06-21 13:18:35 --> Output Class Initialized
INFO - 2024-06-21 13:18:35 --> Security Class Initialized
DEBUG - 2024-06-21 13:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 13:18:35 --> Input Class Initialized
INFO - 2024-06-21 13:18:35 --> Language Class Initialized
INFO - 2024-06-21 13:18:35 --> Language Class Initialized
INFO - 2024-06-21 13:18:35 --> Config Class Initialized
INFO - 2024-06-21 13:18:35 --> Loader Class Initialized
INFO - 2024-06-21 13:18:35 --> Helper loaded: url_helper
INFO - 2024-06-21 13:18:35 --> Helper loaded: file_helper
INFO - 2024-06-21 13:18:35 --> Helper loaded: form_helper
INFO - 2024-06-21 13:18:35 --> Helper loaded: my_helper
INFO - 2024-06-21 13:18:35 --> Database Driver Class Initialized
INFO - 2024-06-21 13:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 13:18:35 --> Controller Class Initialized
DEBUG - 2024-06-21 13:18:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-21 13:18:40 --> Final output sent to browser
DEBUG - 2024-06-21 13:18:40 --> Total execution time: 5.4220
INFO - 2024-06-21 13:19:37 --> Config Class Initialized
INFO - 2024-06-21 13:19:37 --> Hooks Class Initialized
DEBUG - 2024-06-21 13:19:37 --> UTF-8 Support Enabled
INFO - 2024-06-21 13:19:37 --> Utf8 Class Initialized
INFO - 2024-06-21 13:19:37 --> URI Class Initialized
INFO - 2024-06-21 13:19:37 --> Router Class Initialized
INFO - 2024-06-21 13:19:37 --> Output Class Initialized
INFO - 2024-06-21 13:19:37 --> Security Class Initialized
DEBUG - 2024-06-21 13:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 13:19:37 --> Input Class Initialized
INFO - 2024-06-21 13:19:37 --> Language Class Initialized
INFO - 2024-06-21 13:19:37 --> Language Class Initialized
INFO - 2024-06-21 13:19:37 --> Config Class Initialized
INFO - 2024-06-21 13:19:37 --> Loader Class Initialized
INFO - 2024-06-21 13:19:37 --> Helper loaded: url_helper
INFO - 2024-06-21 13:19:37 --> Helper loaded: file_helper
INFO - 2024-06-21 13:19:37 --> Helper loaded: form_helper
INFO - 2024-06-21 13:19:37 --> Helper loaded: my_helper
INFO - 2024-06-21 13:19:37 --> Database Driver Class Initialized
INFO - 2024-06-21 13:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 13:19:37 --> Controller Class Initialized
DEBUG - 2024-06-21 13:19:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-21 14:07:42 --> Config Class Initialized
INFO - 2024-06-21 14:07:42 --> Hooks Class Initialized
DEBUG - 2024-06-21 14:07:42 --> UTF-8 Support Enabled
INFO - 2024-06-21 14:07:42 --> Utf8 Class Initialized
INFO - 2024-06-21 14:07:42 --> URI Class Initialized
INFO - 2024-06-21 14:07:42 --> Router Class Initialized
INFO - 2024-06-21 14:07:42 --> Output Class Initialized
INFO - 2024-06-21 14:07:42 --> Security Class Initialized
DEBUG - 2024-06-21 14:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 14:07:42 --> Input Class Initialized
INFO - 2024-06-21 14:07:42 --> Language Class Initialized
INFO - 2024-06-21 14:07:42 --> Language Class Initialized
INFO - 2024-06-21 14:07:42 --> Config Class Initialized
INFO - 2024-06-21 14:07:42 --> Loader Class Initialized
INFO - 2024-06-21 14:07:42 --> Helper loaded: url_helper
INFO - 2024-06-21 14:07:42 --> Helper loaded: file_helper
INFO - 2024-06-21 14:07:42 --> Helper loaded: form_helper
INFO - 2024-06-21 14:07:42 --> Helper loaded: my_helper
INFO - 2024-06-21 14:07:42 --> Database Driver Class Initialized
INFO - 2024-06-21 14:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 14:07:42 --> Controller Class Initialized
ERROR - 2024-06-21 14:07:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3888
DEBUG - 2024-06-21 14:07:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-21 14:07:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 14:07:42 --> Final output sent to browser
DEBUG - 2024-06-21 14:07:42 --> Total execution time: 0.0565
INFO - 2024-06-21 15:30:26 --> Config Class Initialized
INFO - 2024-06-21 15:30:26 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:30:26 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:30:26 --> Utf8 Class Initialized
INFO - 2024-06-21 15:30:26 --> URI Class Initialized
INFO - 2024-06-21 15:30:26 --> Router Class Initialized
INFO - 2024-06-21 15:30:26 --> Output Class Initialized
INFO - 2024-06-21 15:30:26 --> Security Class Initialized
DEBUG - 2024-06-21 15:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:30:26 --> Input Class Initialized
INFO - 2024-06-21 15:30:26 --> Language Class Initialized
INFO - 2024-06-21 15:30:26 --> Language Class Initialized
INFO - 2024-06-21 15:30:26 --> Config Class Initialized
INFO - 2024-06-21 15:30:26 --> Loader Class Initialized
INFO - 2024-06-21 15:30:26 --> Helper loaded: url_helper
INFO - 2024-06-21 15:30:26 --> Helper loaded: file_helper
INFO - 2024-06-21 15:30:26 --> Helper loaded: form_helper
INFO - 2024-06-21 15:30:26 --> Helper loaded: my_helper
INFO - 2024-06-21 15:30:26 --> Database Driver Class Initialized
INFO - 2024-06-21 15:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:30:26 --> Controller Class Initialized
INFO - 2024-06-21 15:30:26 --> Helper loaded: cookie_helper
INFO - 2024-06-21 15:30:26 --> Final output sent to browser
DEBUG - 2024-06-21 15:30:26 --> Total execution time: 0.0754
INFO - 2024-06-21 15:30:27 --> Config Class Initialized
INFO - 2024-06-21 15:30:27 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:30:27 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:30:27 --> Utf8 Class Initialized
INFO - 2024-06-21 15:30:27 --> URI Class Initialized
INFO - 2024-06-21 15:30:27 --> Router Class Initialized
INFO - 2024-06-21 15:30:27 --> Output Class Initialized
INFO - 2024-06-21 15:30:27 --> Security Class Initialized
DEBUG - 2024-06-21 15:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:30:27 --> Input Class Initialized
INFO - 2024-06-21 15:30:27 --> Language Class Initialized
INFO - 2024-06-21 15:30:27 --> Language Class Initialized
INFO - 2024-06-21 15:30:27 --> Config Class Initialized
INFO - 2024-06-21 15:30:27 --> Loader Class Initialized
INFO - 2024-06-21 15:30:27 --> Helper loaded: url_helper
INFO - 2024-06-21 15:30:27 --> Helper loaded: file_helper
INFO - 2024-06-21 15:30:27 --> Helper loaded: form_helper
INFO - 2024-06-21 15:30:27 --> Helper loaded: my_helper
INFO - 2024-06-21 15:30:27 --> Database Driver Class Initialized
INFO - 2024-06-21 15:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:30:27 --> Controller Class Initialized
INFO - 2024-06-21 15:30:27 --> Helper loaded: cookie_helper
INFO - 2024-06-21 15:30:27 --> Config Class Initialized
INFO - 2024-06-21 15:30:27 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:30:27 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:30:27 --> Utf8 Class Initialized
INFO - 2024-06-21 15:30:27 --> URI Class Initialized
INFO - 2024-06-21 15:30:27 --> Router Class Initialized
INFO - 2024-06-21 15:30:27 --> Output Class Initialized
INFO - 2024-06-21 15:30:27 --> Security Class Initialized
DEBUG - 2024-06-21 15:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:30:27 --> Input Class Initialized
INFO - 2024-06-21 15:30:27 --> Language Class Initialized
INFO - 2024-06-21 15:30:27 --> Language Class Initialized
INFO - 2024-06-21 15:30:27 --> Config Class Initialized
INFO - 2024-06-21 15:30:27 --> Loader Class Initialized
INFO - 2024-06-21 15:30:27 --> Helper loaded: url_helper
INFO - 2024-06-21 15:30:27 --> Helper loaded: file_helper
INFO - 2024-06-21 15:30:27 --> Helper loaded: form_helper
INFO - 2024-06-21 15:30:27 --> Helper loaded: my_helper
INFO - 2024-06-21 15:30:27 --> Database Driver Class Initialized
INFO - 2024-06-21 15:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:30:27 --> Controller Class Initialized
DEBUG - 2024-06-21 15:30:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-06-21 15:30:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 15:30:27 --> Final output sent to browser
DEBUG - 2024-06-21 15:30:27 --> Total execution time: 0.0459
INFO - 2024-06-21 15:30:28 --> Config Class Initialized
INFO - 2024-06-21 15:30:28 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:30:28 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:30:28 --> Utf8 Class Initialized
INFO - 2024-06-21 15:30:28 --> URI Class Initialized
INFO - 2024-06-21 15:30:28 --> Router Class Initialized
INFO - 2024-06-21 15:30:28 --> Output Class Initialized
INFO - 2024-06-21 15:30:28 --> Security Class Initialized
DEBUG - 2024-06-21 15:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:30:28 --> Input Class Initialized
INFO - 2024-06-21 15:30:28 --> Language Class Initialized
INFO - 2024-06-21 15:30:28 --> Language Class Initialized
INFO - 2024-06-21 15:30:28 --> Config Class Initialized
INFO - 2024-06-21 15:30:28 --> Loader Class Initialized
INFO - 2024-06-21 15:30:28 --> Helper loaded: url_helper
INFO - 2024-06-21 15:30:28 --> Helper loaded: file_helper
INFO - 2024-06-21 15:30:28 --> Helper loaded: form_helper
INFO - 2024-06-21 15:30:28 --> Helper loaded: my_helper
INFO - 2024-06-21 15:30:28 --> Database Driver Class Initialized
INFO - 2024-06-21 15:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:30:28 --> Controller Class Initialized
INFO - 2024-06-21 15:30:28 --> Helper loaded: cookie_helper
INFO - 2024-06-21 15:30:28 --> Final output sent to browser
DEBUG - 2024-06-21 15:30:28 --> Total execution time: 0.4104
INFO - 2024-06-21 15:30:29 --> Config Class Initialized
INFO - 2024-06-21 15:30:29 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:30:29 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:30:29 --> Utf8 Class Initialized
INFO - 2024-06-21 15:30:29 --> URI Class Initialized
INFO - 2024-06-21 15:30:29 --> Router Class Initialized
INFO - 2024-06-21 15:30:29 --> Output Class Initialized
INFO - 2024-06-21 15:30:29 --> Security Class Initialized
DEBUG - 2024-06-21 15:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:30:29 --> Input Class Initialized
INFO - 2024-06-21 15:30:29 --> Language Class Initialized
INFO - 2024-06-21 15:30:29 --> Language Class Initialized
INFO - 2024-06-21 15:30:29 --> Config Class Initialized
INFO - 2024-06-21 15:30:29 --> Loader Class Initialized
INFO - 2024-06-21 15:30:29 --> Helper loaded: url_helper
INFO - 2024-06-21 15:30:29 --> Helper loaded: file_helper
INFO - 2024-06-21 15:30:29 --> Helper loaded: form_helper
INFO - 2024-06-21 15:30:29 --> Helper loaded: my_helper
INFO - 2024-06-21 15:30:29 --> Database Driver Class Initialized
INFO - 2024-06-21 15:30:29 --> Config Class Initialized
INFO - 2024-06-21 15:30:29 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:30:29 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:30:29 --> Utf8 Class Initialized
INFO - 2024-06-21 15:30:29 --> URI Class Initialized
INFO - 2024-06-21 15:30:29 --> Router Class Initialized
INFO - 2024-06-21 15:30:29 --> Output Class Initialized
INFO - 2024-06-21 15:30:29 --> Security Class Initialized
DEBUG - 2024-06-21 15:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:30:29 --> Input Class Initialized
INFO - 2024-06-21 15:30:29 --> Language Class Initialized
INFO - 2024-06-21 15:30:29 --> Language Class Initialized
INFO - 2024-06-21 15:30:29 --> Config Class Initialized
INFO - 2024-06-21 15:30:29 --> Loader Class Initialized
INFO - 2024-06-21 15:30:29 --> Helper loaded: url_helper
INFO - 2024-06-21 15:30:29 --> Helper loaded: file_helper
INFO - 2024-06-21 15:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:30:29 --> Controller Class Initialized
INFO - 2024-06-21 15:30:29 --> Helper loaded: form_helper
INFO - 2024-06-21 15:30:29 --> Helper loaded: my_helper
INFO - 2024-06-21 15:30:29 --> Database Driver Class Initialized
INFO - 2024-06-21 15:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:30:29 --> Controller Class Initialized
INFO - 2024-06-21 15:30:29 --> Helper loaded: cookie_helper
INFO - 2024-06-21 15:30:29 --> Helper loaded: cookie_helper
INFO - 2024-06-21 15:30:29 --> Final output sent to browser
DEBUG - 2024-06-21 15:30:29 --> Total execution time: 0.1599
INFO - 2024-06-21 15:30:29 --> Config Class Initialized
INFO - 2024-06-21 15:30:29 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:30:29 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:30:29 --> Utf8 Class Initialized
INFO - 2024-06-21 15:30:29 --> Config Class Initialized
INFO - 2024-06-21 15:30:29 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:30:29 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:30:29 --> Utf8 Class Initialized
INFO - 2024-06-21 15:30:29 --> URI Class Initialized
INFO - 2024-06-21 15:30:29 --> Router Class Initialized
INFO - 2024-06-21 15:30:29 --> URI Class Initialized
INFO - 2024-06-21 15:30:29 --> Router Class Initialized
INFO - 2024-06-21 15:30:29 --> Output Class Initialized
INFO - 2024-06-21 15:30:29 --> Security Class Initialized
DEBUG - 2024-06-21 15:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:30:29 --> Input Class Initialized
INFO - 2024-06-21 15:30:29 --> Language Class Initialized
INFO - 2024-06-21 15:30:29 --> Language Class Initialized
INFO - 2024-06-21 15:30:29 --> Config Class Initialized
INFO - 2024-06-21 15:30:29 --> Loader Class Initialized
INFO - 2024-06-21 15:30:29 --> Output Class Initialized
INFO - 2024-06-21 15:30:29 --> Security Class Initialized
DEBUG - 2024-06-21 15:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:30:29 --> Input Class Initialized
INFO - 2024-06-21 15:30:29 --> Language Class Initialized
INFO - 2024-06-21 15:30:29 --> Language Class Initialized
INFO - 2024-06-21 15:30:29 --> Config Class Initialized
INFO - 2024-06-21 15:30:29 --> Loader Class Initialized
INFO - 2024-06-21 15:30:29 --> Helper loaded: url_helper
INFO - 2024-06-21 15:30:29 --> Helper loaded: file_helper
INFO - 2024-06-21 15:30:29 --> Helper loaded: url_helper
INFO - 2024-06-21 15:30:29 --> Helper loaded: file_helper
INFO - 2024-06-21 15:30:29 --> Helper loaded: form_helper
INFO - 2024-06-21 15:30:29 --> Helper loaded: my_helper
INFO - 2024-06-21 15:30:29 --> Database Driver Class Initialized
INFO - 2024-06-21 15:30:29 --> Config Class Initialized
INFO - 2024-06-21 15:30:29 --> Hooks Class Initialized
INFO - 2024-06-21 15:30:29 --> Helper loaded: form_helper
INFO - 2024-06-21 15:30:29 --> Helper loaded: my_helper
INFO - 2024-06-21 15:30:29 --> Database Driver Class Initialized
DEBUG - 2024-06-21 15:30:29 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:30:29 --> Utf8 Class Initialized
INFO - 2024-06-21 15:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:30:29 --> Controller Class Initialized
INFO - 2024-06-21 15:30:29 --> URI Class Initialized
DEBUG - 2024-06-21 15:30:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-06-21 15:30:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 15:30:29 --> Final output sent to browser
DEBUG - 2024-06-21 15:30:29 --> Total execution time: 0.2083
INFO - 2024-06-21 15:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:30:29 --> Controller Class Initialized
INFO - 2024-06-21 15:30:29 --> Helper loaded: cookie_helper
INFO - 2024-06-21 15:30:29 --> Router Class Initialized
INFO - 2024-06-21 15:30:29 --> Output Class Initialized
INFO - 2024-06-21 15:30:29 --> Security Class Initialized
DEBUG - 2024-06-21 15:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:30:29 --> Input Class Initialized
INFO - 2024-06-21 15:30:29 --> Language Class Initialized
INFO - 2024-06-21 15:30:29 --> Language Class Initialized
INFO - 2024-06-21 15:30:29 --> Config Class Initialized
INFO - 2024-06-21 15:30:29 --> Loader Class Initialized
INFO - 2024-06-21 15:30:29 --> Helper loaded: url_helper
INFO - 2024-06-21 15:30:29 --> Helper loaded: file_helper
INFO - 2024-06-21 15:30:29 --> Helper loaded: form_helper
INFO - 2024-06-21 15:30:29 --> Helper loaded: my_helper
INFO - 2024-06-21 15:30:29 --> Database Driver Class Initialized
INFO - 2024-06-21 15:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:30:29 --> Controller Class Initialized
INFO - 2024-06-21 15:30:29 --> Helper loaded: cookie_helper
INFO - 2024-06-21 15:30:29 --> Config Class Initialized
INFO - 2024-06-21 15:30:29 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:30:29 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:30:29 --> Utf8 Class Initialized
INFO - 2024-06-21 15:30:29 --> URI Class Initialized
INFO - 2024-06-21 15:30:30 --> Router Class Initialized
INFO - 2024-06-21 15:30:30 --> Output Class Initialized
INFO - 2024-06-21 15:30:30 --> Security Class Initialized
DEBUG - 2024-06-21 15:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:30:30 --> Input Class Initialized
INFO - 2024-06-21 15:30:30 --> Language Class Initialized
INFO - 2024-06-21 15:30:30 --> Language Class Initialized
INFO - 2024-06-21 15:30:30 --> Config Class Initialized
INFO - 2024-06-21 15:30:30 --> Loader Class Initialized
INFO - 2024-06-21 15:30:30 --> Helper loaded: url_helper
INFO - 2024-06-21 15:30:30 --> Helper loaded: file_helper
INFO - 2024-06-21 15:30:30 --> Helper loaded: form_helper
INFO - 2024-06-21 15:30:30 --> Helper loaded: my_helper
INFO - 2024-06-21 15:30:30 --> Database Driver Class Initialized
INFO - 2024-06-21 15:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:30:30 --> Controller Class Initialized
DEBUG - 2024-06-21 15:30:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-06-21 15:30:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 15:30:30 --> Final output sent to browser
DEBUG - 2024-06-21 15:30:30 --> Total execution time: 0.3267
INFO - 2024-06-21 15:30:40 --> Config Class Initialized
INFO - 2024-06-21 15:30:40 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:30:40 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:30:40 --> Utf8 Class Initialized
INFO - 2024-06-21 15:30:40 --> URI Class Initialized
INFO - 2024-06-21 15:30:40 --> Router Class Initialized
INFO - 2024-06-21 15:30:40 --> Output Class Initialized
INFO - 2024-06-21 15:30:40 --> Security Class Initialized
DEBUG - 2024-06-21 15:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:30:40 --> Input Class Initialized
INFO - 2024-06-21 15:30:40 --> Language Class Initialized
INFO - 2024-06-21 15:30:40 --> Language Class Initialized
INFO - 2024-06-21 15:30:40 --> Config Class Initialized
INFO - 2024-06-21 15:30:40 --> Loader Class Initialized
INFO - 2024-06-21 15:30:40 --> Helper loaded: url_helper
INFO - 2024-06-21 15:30:40 --> Helper loaded: file_helper
INFO - 2024-06-21 15:30:40 --> Helper loaded: form_helper
INFO - 2024-06-21 15:30:40 --> Helper loaded: my_helper
INFO - 2024-06-21 15:30:40 --> Database Driver Class Initialized
INFO - 2024-06-21 15:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:30:40 --> Controller Class Initialized
DEBUG - 2024-06-21 15:30:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-21 15:30:47 --> Final output sent to browser
DEBUG - 2024-06-21 15:30:47 --> Total execution time: 7.1214
INFO - 2024-06-21 15:31:21 --> Config Class Initialized
INFO - 2024-06-21 15:31:21 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:31:21 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:31:21 --> Utf8 Class Initialized
INFO - 2024-06-21 15:31:21 --> URI Class Initialized
INFO - 2024-06-21 15:31:21 --> Router Class Initialized
INFO - 2024-06-21 15:31:21 --> Output Class Initialized
INFO - 2024-06-21 15:31:21 --> Security Class Initialized
DEBUG - 2024-06-21 15:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:31:21 --> Input Class Initialized
INFO - 2024-06-21 15:31:21 --> Language Class Initialized
INFO - 2024-06-21 15:31:21 --> Language Class Initialized
INFO - 2024-06-21 15:31:21 --> Config Class Initialized
INFO - 2024-06-21 15:31:21 --> Loader Class Initialized
INFO - 2024-06-21 15:31:21 --> Helper loaded: url_helper
INFO - 2024-06-21 15:31:21 --> Helper loaded: file_helper
INFO - 2024-06-21 15:31:21 --> Helper loaded: form_helper
INFO - 2024-06-21 15:31:21 --> Helper loaded: my_helper
INFO - 2024-06-21 15:31:21 --> Database Driver Class Initialized
INFO - 2024-06-21 15:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:31:21 --> Controller Class Initialized
DEBUG - 2024-06-21 15:31:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-21 15:31:27 --> Final output sent to browser
DEBUG - 2024-06-21 15:31:27 --> Total execution time: 5.8732
INFO - 2024-06-21 15:31:35 --> Config Class Initialized
INFO - 2024-06-21 15:31:35 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:31:35 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:31:35 --> Utf8 Class Initialized
INFO - 2024-06-21 15:31:35 --> URI Class Initialized
INFO - 2024-06-21 15:31:35 --> Router Class Initialized
INFO - 2024-06-21 15:31:35 --> Output Class Initialized
INFO - 2024-06-21 15:31:35 --> Security Class Initialized
DEBUG - 2024-06-21 15:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:31:35 --> Input Class Initialized
INFO - 2024-06-21 15:31:35 --> Language Class Initialized
INFO - 2024-06-21 15:31:35 --> Language Class Initialized
INFO - 2024-06-21 15:31:35 --> Config Class Initialized
INFO - 2024-06-21 15:31:35 --> Loader Class Initialized
INFO - 2024-06-21 15:31:35 --> Helper loaded: url_helper
INFO - 2024-06-21 15:31:35 --> Helper loaded: file_helper
INFO - 2024-06-21 15:31:35 --> Helper loaded: form_helper
INFO - 2024-06-21 15:31:35 --> Helper loaded: my_helper
INFO - 2024-06-21 15:31:35 --> Database Driver Class Initialized
INFO - 2024-06-21 15:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:31:35 --> Controller Class Initialized
DEBUG - 2024-06-21 15:31:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-21 15:31:43 --> Final output sent to browser
DEBUG - 2024-06-21 15:31:43 --> Total execution time: 7.9152
INFO - 2024-06-21 15:32:53 --> Config Class Initialized
INFO - 2024-06-21 15:32:53 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:32:53 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:32:53 --> Utf8 Class Initialized
INFO - 2024-06-21 15:32:53 --> URI Class Initialized
INFO - 2024-06-21 15:32:53 --> Router Class Initialized
INFO - 2024-06-21 15:32:53 --> Output Class Initialized
INFO - 2024-06-21 15:32:53 --> Security Class Initialized
DEBUG - 2024-06-21 15:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:32:53 --> Input Class Initialized
INFO - 2024-06-21 15:32:53 --> Language Class Initialized
INFO - 2024-06-21 15:32:53 --> Language Class Initialized
INFO - 2024-06-21 15:32:53 --> Config Class Initialized
INFO - 2024-06-21 15:32:53 --> Loader Class Initialized
INFO - 2024-06-21 15:32:53 --> Helper loaded: url_helper
INFO - 2024-06-21 15:32:53 --> Helper loaded: file_helper
INFO - 2024-06-21 15:32:53 --> Helper loaded: form_helper
INFO - 2024-06-21 15:32:53 --> Helper loaded: my_helper
INFO - 2024-06-21 15:32:53 --> Database Driver Class Initialized
INFO - 2024-06-21 15:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:32:53 --> Controller Class Initialized
DEBUG - 2024-06-21 15:32:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-06-21 15:32:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 15:32:54 --> Final output sent to browser
DEBUG - 2024-06-21 15:32:54 --> Total execution time: 0.2964
INFO - 2024-06-21 15:32:57 --> Config Class Initialized
INFO - 2024-06-21 15:32:57 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:32:58 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:32:58 --> Utf8 Class Initialized
INFO - 2024-06-21 15:32:58 --> URI Class Initialized
DEBUG - 2024-06-21 15:32:58 --> No URI present. Default controller set.
INFO - 2024-06-21 15:32:58 --> Router Class Initialized
INFO - 2024-06-21 15:32:58 --> Output Class Initialized
INFO - 2024-06-21 15:32:58 --> Security Class Initialized
DEBUG - 2024-06-21 15:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:32:58 --> Input Class Initialized
INFO - 2024-06-21 15:32:58 --> Language Class Initialized
INFO - 2024-06-21 15:32:58 --> Language Class Initialized
INFO - 2024-06-21 15:32:58 --> Config Class Initialized
INFO - 2024-06-21 15:32:58 --> Loader Class Initialized
INFO - 2024-06-21 15:32:58 --> Helper loaded: url_helper
INFO - 2024-06-21 15:32:58 --> Helper loaded: file_helper
INFO - 2024-06-21 15:32:58 --> Helper loaded: form_helper
INFO - 2024-06-21 15:32:58 --> Helper loaded: my_helper
INFO - 2024-06-21 15:32:58 --> Database Driver Class Initialized
INFO - 2024-06-21 15:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:32:58 --> Controller Class Initialized
DEBUG - 2024-06-21 15:32:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-06-21 15:32:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 15:32:58 --> Final output sent to browser
DEBUG - 2024-06-21 15:32:58 --> Total execution time: 0.3289
INFO - 2024-06-21 15:33:11 --> Config Class Initialized
INFO - 2024-06-21 15:33:11 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:33:11 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:33:11 --> Utf8 Class Initialized
INFO - 2024-06-21 15:33:11 --> URI Class Initialized
DEBUG - 2024-06-21 15:33:11 --> No URI present. Default controller set.
INFO - 2024-06-21 15:33:11 --> Router Class Initialized
INFO - 2024-06-21 15:33:11 --> Output Class Initialized
INFO - 2024-06-21 15:33:11 --> Security Class Initialized
DEBUG - 2024-06-21 15:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:33:11 --> Input Class Initialized
INFO - 2024-06-21 15:33:11 --> Language Class Initialized
INFO - 2024-06-21 15:33:11 --> Language Class Initialized
INFO - 2024-06-21 15:33:11 --> Config Class Initialized
INFO - 2024-06-21 15:33:11 --> Loader Class Initialized
INFO - 2024-06-21 15:33:11 --> Helper loaded: url_helper
INFO - 2024-06-21 15:33:11 --> Helper loaded: file_helper
INFO - 2024-06-21 15:33:11 --> Helper loaded: form_helper
INFO - 2024-06-21 15:33:11 --> Helper loaded: my_helper
INFO - 2024-06-21 15:33:11 --> Database Driver Class Initialized
INFO - 2024-06-21 15:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:33:11 --> Controller Class Initialized
DEBUG - 2024-06-21 15:33:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-06-21 15:33:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 15:33:11 --> Final output sent to browser
DEBUG - 2024-06-21 15:33:11 --> Total execution time: 0.1219
INFO - 2024-06-21 15:34:15 --> Config Class Initialized
INFO - 2024-06-21 15:34:15 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:34:15 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:34:15 --> Utf8 Class Initialized
INFO - 2024-06-21 15:34:15 --> URI Class Initialized
INFO - 2024-06-21 15:34:15 --> Router Class Initialized
INFO - 2024-06-21 15:34:15 --> Output Class Initialized
INFO - 2024-06-21 15:34:15 --> Security Class Initialized
DEBUG - 2024-06-21 15:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:34:15 --> Input Class Initialized
INFO - 2024-06-21 15:34:15 --> Language Class Initialized
INFO - 2024-06-21 15:34:15 --> Language Class Initialized
INFO - 2024-06-21 15:34:15 --> Config Class Initialized
INFO - 2024-06-21 15:34:15 --> Loader Class Initialized
INFO - 2024-06-21 15:34:15 --> Helper loaded: url_helper
INFO - 2024-06-21 15:34:15 --> Helper loaded: file_helper
INFO - 2024-06-21 15:34:15 --> Helper loaded: form_helper
INFO - 2024-06-21 15:34:15 --> Helper loaded: my_helper
INFO - 2024-06-21 15:34:15 --> Database Driver Class Initialized
INFO - 2024-06-21 15:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:34:15 --> Controller Class Initialized
INFO - 2024-06-21 15:34:15 --> Helper loaded: cookie_helper
INFO - 2024-06-21 15:34:15 --> Final output sent to browser
DEBUG - 2024-06-21 15:34:15 --> Total execution time: 0.1680
INFO - 2024-06-21 15:34:16 --> Config Class Initialized
INFO - 2024-06-21 15:34:16 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:34:16 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:34:16 --> Utf8 Class Initialized
INFO - 2024-06-21 15:34:16 --> URI Class Initialized
INFO - 2024-06-21 15:34:16 --> Router Class Initialized
INFO - 2024-06-21 15:34:16 --> Output Class Initialized
INFO - 2024-06-21 15:34:16 --> Security Class Initialized
DEBUG - 2024-06-21 15:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:34:16 --> Input Class Initialized
INFO - 2024-06-21 15:34:16 --> Language Class Initialized
INFO - 2024-06-21 15:34:16 --> Language Class Initialized
INFO - 2024-06-21 15:34:16 --> Config Class Initialized
INFO - 2024-06-21 15:34:16 --> Loader Class Initialized
INFO - 2024-06-21 15:34:16 --> Helper loaded: url_helper
INFO - 2024-06-21 15:34:16 --> Helper loaded: file_helper
INFO - 2024-06-21 15:34:16 --> Helper loaded: form_helper
INFO - 2024-06-21 15:34:16 --> Helper loaded: my_helper
INFO - 2024-06-21 15:34:16 --> Database Driver Class Initialized
INFO - 2024-06-21 15:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:34:16 --> Controller Class Initialized
INFO - 2024-06-21 15:34:16 --> Helper loaded: cookie_helper
INFO - 2024-06-21 15:34:16 --> Config Class Initialized
INFO - 2024-06-21 15:34:16 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:34:16 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:34:16 --> Utf8 Class Initialized
INFO - 2024-06-21 15:34:16 --> URI Class Initialized
INFO - 2024-06-21 15:34:16 --> Router Class Initialized
INFO - 2024-06-21 15:34:16 --> Output Class Initialized
INFO - 2024-06-21 15:34:16 --> Security Class Initialized
DEBUG - 2024-06-21 15:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:34:16 --> Input Class Initialized
INFO - 2024-06-21 15:34:16 --> Language Class Initialized
INFO - 2024-06-21 15:34:16 --> Language Class Initialized
INFO - 2024-06-21 15:34:16 --> Config Class Initialized
INFO - 2024-06-21 15:34:16 --> Loader Class Initialized
INFO - 2024-06-21 15:34:16 --> Helper loaded: url_helper
INFO - 2024-06-21 15:34:16 --> Helper loaded: file_helper
INFO - 2024-06-21 15:34:16 --> Helper loaded: form_helper
INFO - 2024-06-21 15:34:16 --> Helper loaded: my_helper
INFO - 2024-06-21 15:34:16 --> Database Driver Class Initialized
INFO - 2024-06-21 15:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:34:16 --> Controller Class Initialized
DEBUG - 2024-06-21 15:34:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-06-21 15:34:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 15:34:16 --> Final output sent to browser
DEBUG - 2024-06-21 15:34:16 --> Total execution time: 0.1518
INFO - 2024-06-21 15:34:23 --> Config Class Initialized
INFO - 2024-06-21 15:34:23 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:34:23 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:34:23 --> Utf8 Class Initialized
INFO - 2024-06-21 15:34:23 --> URI Class Initialized
INFO - 2024-06-21 15:34:23 --> Router Class Initialized
INFO - 2024-06-21 15:34:23 --> Output Class Initialized
INFO - 2024-06-21 15:34:23 --> Security Class Initialized
DEBUG - 2024-06-21 15:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:34:23 --> Input Class Initialized
INFO - 2024-06-21 15:34:23 --> Language Class Initialized
INFO - 2024-06-21 15:34:23 --> Language Class Initialized
INFO - 2024-06-21 15:34:23 --> Config Class Initialized
INFO - 2024-06-21 15:34:23 --> Loader Class Initialized
INFO - 2024-06-21 15:34:23 --> Helper loaded: url_helper
INFO - 2024-06-21 15:34:23 --> Helper loaded: file_helper
INFO - 2024-06-21 15:34:23 --> Helper loaded: form_helper
INFO - 2024-06-21 15:34:23 --> Helper loaded: my_helper
INFO - 2024-06-21 15:34:23 --> Database Driver Class Initialized
INFO - 2024-06-21 15:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:34:23 --> Controller Class Initialized
DEBUG - 2024-06-21 15:34:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-21 15:34:31 --> Final output sent to browser
DEBUG - 2024-06-21 15:34:31 --> Total execution time: 7.7122
INFO - 2024-06-21 15:35:18 --> Config Class Initialized
INFO - 2024-06-21 15:35:18 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:35:18 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:35:18 --> Utf8 Class Initialized
INFO - 2024-06-21 15:35:18 --> URI Class Initialized
INFO - 2024-06-21 15:35:18 --> Router Class Initialized
INFO - 2024-06-21 15:35:18 --> Output Class Initialized
INFO - 2024-06-21 15:35:18 --> Security Class Initialized
DEBUG - 2024-06-21 15:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:35:18 --> Input Class Initialized
INFO - 2024-06-21 15:35:18 --> Language Class Initialized
INFO - 2024-06-21 15:35:18 --> Language Class Initialized
INFO - 2024-06-21 15:35:18 --> Config Class Initialized
INFO - 2024-06-21 15:35:18 --> Loader Class Initialized
INFO - 2024-06-21 15:35:18 --> Helper loaded: url_helper
INFO - 2024-06-21 15:35:18 --> Helper loaded: file_helper
INFO - 2024-06-21 15:35:18 --> Helper loaded: form_helper
INFO - 2024-06-21 15:35:18 --> Helper loaded: my_helper
INFO - 2024-06-21 15:35:18 --> Database Driver Class Initialized
INFO - 2024-06-21 15:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:35:19 --> Controller Class Initialized
DEBUG - 2024-06-21 15:35:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-21 15:35:25 --> Final output sent to browser
DEBUG - 2024-06-21 15:35:25 --> Total execution time: 6.4392
INFO - 2024-06-21 15:35:31 --> Config Class Initialized
INFO - 2024-06-21 15:35:31 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:35:31 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:35:31 --> Utf8 Class Initialized
INFO - 2024-06-21 15:35:31 --> URI Class Initialized
INFO - 2024-06-21 15:35:31 --> Router Class Initialized
INFO - 2024-06-21 15:35:31 --> Output Class Initialized
INFO - 2024-06-21 15:35:31 --> Security Class Initialized
DEBUG - 2024-06-21 15:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:35:31 --> Input Class Initialized
INFO - 2024-06-21 15:35:31 --> Language Class Initialized
INFO - 2024-06-21 15:35:31 --> Language Class Initialized
INFO - 2024-06-21 15:35:31 --> Config Class Initialized
INFO - 2024-06-21 15:35:31 --> Loader Class Initialized
INFO - 2024-06-21 15:35:31 --> Helper loaded: url_helper
INFO - 2024-06-21 15:35:31 --> Helper loaded: file_helper
INFO - 2024-06-21 15:35:31 --> Helper loaded: form_helper
INFO - 2024-06-21 15:35:31 --> Helper loaded: my_helper
INFO - 2024-06-21 15:35:31 --> Database Driver Class Initialized
INFO - 2024-06-21 15:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:35:31 --> Controller Class Initialized
DEBUG - 2024-06-21 15:35:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-21 15:35:34 --> Final output sent to browser
DEBUG - 2024-06-21 15:35:34 --> Total execution time: 2.9929
INFO - 2024-06-21 15:35:53 --> Config Class Initialized
INFO - 2024-06-21 15:35:53 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:35:53 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:35:53 --> Utf8 Class Initialized
INFO - 2024-06-21 15:35:53 --> URI Class Initialized
INFO - 2024-06-21 15:35:53 --> Router Class Initialized
INFO - 2024-06-21 15:35:53 --> Output Class Initialized
INFO - 2024-06-21 15:35:53 --> Security Class Initialized
DEBUG - 2024-06-21 15:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:35:53 --> Input Class Initialized
INFO - 2024-06-21 15:35:53 --> Language Class Initialized
INFO - 2024-06-21 15:35:53 --> Language Class Initialized
INFO - 2024-06-21 15:35:53 --> Config Class Initialized
INFO - 2024-06-21 15:35:53 --> Loader Class Initialized
INFO - 2024-06-21 15:35:53 --> Helper loaded: url_helper
INFO - 2024-06-21 15:35:53 --> Helper loaded: file_helper
INFO - 2024-06-21 15:35:53 --> Helper loaded: form_helper
INFO - 2024-06-21 15:35:53 --> Helper loaded: my_helper
INFO - 2024-06-21 15:35:53 --> Database Driver Class Initialized
INFO - 2024-06-21 15:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:35:53 --> Controller Class Initialized
DEBUG - 2024-06-21 15:35:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-21 15:35:56 --> Final output sent to browser
DEBUG - 2024-06-21 15:35:56 --> Total execution time: 2.5000
INFO - 2024-06-21 15:35:58 --> Config Class Initialized
INFO - 2024-06-21 15:35:58 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:35:58 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:35:58 --> Utf8 Class Initialized
INFO - 2024-06-21 15:35:58 --> URI Class Initialized
INFO - 2024-06-21 15:35:58 --> Router Class Initialized
INFO - 2024-06-21 15:35:58 --> Output Class Initialized
INFO - 2024-06-21 15:35:58 --> Security Class Initialized
DEBUG - 2024-06-21 15:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:35:58 --> Input Class Initialized
INFO - 2024-06-21 15:35:58 --> Language Class Initialized
INFO - 2024-06-21 15:35:58 --> Language Class Initialized
INFO - 2024-06-21 15:35:58 --> Config Class Initialized
INFO - 2024-06-21 15:35:58 --> Loader Class Initialized
INFO - 2024-06-21 15:35:58 --> Helper loaded: url_helper
INFO - 2024-06-21 15:35:58 --> Helper loaded: file_helper
INFO - 2024-06-21 15:35:58 --> Helper loaded: form_helper
INFO - 2024-06-21 15:35:58 --> Helper loaded: my_helper
INFO - 2024-06-21 15:35:58 --> Database Driver Class Initialized
INFO - 2024-06-21 15:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:35:58 --> Controller Class Initialized
DEBUG - 2024-06-21 15:35:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-21 15:36:02 --> Final output sent to browser
DEBUG - 2024-06-21 15:36:02 --> Total execution time: 3.4326
INFO - 2024-06-21 15:36:45 --> Config Class Initialized
INFO - 2024-06-21 15:36:45 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:36:45 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:36:45 --> Utf8 Class Initialized
INFO - 2024-06-21 15:36:45 --> URI Class Initialized
INFO - 2024-06-21 15:36:45 --> Router Class Initialized
INFO - 2024-06-21 15:36:45 --> Output Class Initialized
INFO - 2024-06-21 15:36:45 --> Security Class Initialized
DEBUG - 2024-06-21 15:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:36:45 --> Input Class Initialized
INFO - 2024-06-21 15:36:45 --> Language Class Initialized
INFO - 2024-06-21 15:36:45 --> Language Class Initialized
INFO - 2024-06-21 15:36:45 --> Config Class Initialized
INFO - 2024-06-21 15:36:45 --> Loader Class Initialized
INFO - 2024-06-21 15:36:45 --> Helper loaded: url_helper
INFO - 2024-06-21 15:36:45 --> Helper loaded: file_helper
INFO - 2024-06-21 15:36:45 --> Helper loaded: form_helper
INFO - 2024-06-21 15:36:45 --> Helper loaded: my_helper
INFO - 2024-06-21 15:36:46 --> Database Driver Class Initialized
INFO - 2024-06-21 15:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:36:46 --> Controller Class Initialized
DEBUG - 2024-06-21 15:36:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-21 15:36:55 --> Final output sent to browser
DEBUG - 2024-06-21 15:36:55 --> Total execution time: 9.5692
INFO - 2024-06-21 15:37:10 --> Config Class Initialized
INFO - 2024-06-21 15:37:10 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:37:10 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:37:10 --> Utf8 Class Initialized
INFO - 2024-06-21 15:37:10 --> URI Class Initialized
INFO - 2024-06-21 15:37:10 --> Router Class Initialized
INFO - 2024-06-21 15:37:10 --> Output Class Initialized
INFO - 2024-06-21 15:37:10 --> Security Class Initialized
DEBUG - 2024-06-21 15:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:37:10 --> Input Class Initialized
INFO - 2024-06-21 15:37:10 --> Language Class Initialized
INFO - 2024-06-21 15:37:10 --> Language Class Initialized
INFO - 2024-06-21 15:37:10 --> Config Class Initialized
INFO - 2024-06-21 15:37:10 --> Loader Class Initialized
INFO - 2024-06-21 15:37:10 --> Helper loaded: url_helper
INFO - 2024-06-21 15:37:10 --> Helper loaded: file_helper
INFO - 2024-06-21 15:37:10 --> Helper loaded: form_helper
INFO - 2024-06-21 15:37:10 --> Helper loaded: my_helper
INFO - 2024-06-21 15:37:10 --> Database Driver Class Initialized
INFO - 2024-06-21 15:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:37:11 --> Controller Class Initialized
DEBUG - 2024-06-21 15:37:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-21 15:37:20 --> Final output sent to browser
DEBUG - 2024-06-21 15:37:20 --> Total execution time: 9.3263
INFO - 2024-06-21 15:37:22 --> Config Class Initialized
INFO - 2024-06-21 15:37:22 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:37:22 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:37:22 --> Utf8 Class Initialized
INFO - 2024-06-21 15:37:22 --> URI Class Initialized
INFO - 2024-06-21 15:37:22 --> Router Class Initialized
INFO - 2024-06-21 15:37:22 --> Output Class Initialized
INFO - 2024-06-21 15:37:22 --> Security Class Initialized
DEBUG - 2024-06-21 15:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:37:22 --> Input Class Initialized
INFO - 2024-06-21 15:37:22 --> Language Class Initialized
INFO - 2024-06-21 15:37:22 --> Language Class Initialized
INFO - 2024-06-21 15:37:22 --> Config Class Initialized
INFO - 2024-06-21 15:37:22 --> Loader Class Initialized
INFO - 2024-06-21 15:37:22 --> Helper loaded: url_helper
INFO - 2024-06-21 15:37:22 --> Helper loaded: file_helper
INFO - 2024-06-21 15:37:22 --> Helper loaded: form_helper
INFO - 2024-06-21 15:37:22 --> Helper loaded: my_helper
INFO - 2024-06-21 15:37:22 --> Database Driver Class Initialized
INFO - 2024-06-21 15:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:37:22 --> Controller Class Initialized
DEBUG - 2024-06-21 15:37:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-21 15:37:31 --> Final output sent to browser
DEBUG - 2024-06-21 15:37:31 --> Total execution time: 9.1004
INFO - 2024-06-21 15:38:01 --> Config Class Initialized
INFO - 2024-06-21 15:38:01 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:38:01 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:38:01 --> Utf8 Class Initialized
INFO - 2024-06-21 15:38:01 --> URI Class Initialized
INFO - 2024-06-21 15:38:01 --> Router Class Initialized
INFO - 2024-06-21 15:38:01 --> Output Class Initialized
INFO - 2024-06-21 15:38:01 --> Security Class Initialized
DEBUG - 2024-06-21 15:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:38:01 --> Input Class Initialized
INFO - 2024-06-21 15:38:01 --> Language Class Initialized
INFO - 2024-06-21 15:38:01 --> Language Class Initialized
INFO - 2024-06-21 15:38:01 --> Config Class Initialized
INFO - 2024-06-21 15:38:01 --> Loader Class Initialized
INFO - 2024-06-21 15:38:01 --> Helper loaded: url_helper
INFO - 2024-06-21 15:38:01 --> Helper loaded: file_helper
INFO - 2024-06-21 15:38:01 --> Helper loaded: form_helper
INFO - 2024-06-21 15:38:01 --> Helper loaded: my_helper
INFO - 2024-06-21 15:38:02 --> Database Driver Class Initialized
INFO - 2024-06-21 15:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:38:02 --> Controller Class Initialized
DEBUG - 2024-06-21 15:38:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-21 15:38:11 --> Config Class Initialized
INFO - 2024-06-21 15:38:11 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:38:11 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:38:11 --> Utf8 Class Initialized
INFO - 2024-06-21 15:38:11 --> URI Class Initialized
INFO - 2024-06-21 15:38:11 --> Router Class Initialized
INFO - 2024-06-21 15:38:11 --> Output Class Initialized
INFO - 2024-06-21 15:38:11 --> Security Class Initialized
DEBUG - 2024-06-21 15:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:38:11 --> Input Class Initialized
INFO - 2024-06-21 15:38:11 --> Language Class Initialized
INFO - 2024-06-21 15:38:11 --> Language Class Initialized
INFO - 2024-06-21 15:38:11 --> Config Class Initialized
INFO - 2024-06-21 15:38:11 --> Loader Class Initialized
INFO - 2024-06-21 15:38:11 --> Helper loaded: url_helper
INFO - 2024-06-21 15:38:11 --> Helper loaded: file_helper
INFO - 2024-06-21 15:38:11 --> Helper loaded: form_helper
INFO - 2024-06-21 15:38:11 --> Helper loaded: my_helper
INFO - 2024-06-21 15:38:11 --> Database Driver Class Initialized
INFO - 2024-06-21 15:38:15 --> Final output sent to browser
DEBUG - 2024-06-21 15:38:15 --> Total execution time: 13.8761
INFO - 2024-06-21 15:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:38:15 --> Controller Class Initialized
DEBUG - 2024-06-21 15:38:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-21 15:38:24 --> Final output sent to browser
DEBUG - 2024-06-21 15:38:24 --> Total execution time: 12.7619
INFO - 2024-06-21 15:39:17 --> Config Class Initialized
INFO - 2024-06-21 15:39:17 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:39:19 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:39:19 --> Utf8 Class Initialized
INFO - 2024-06-21 15:39:19 --> URI Class Initialized
INFO - 2024-06-21 15:39:20 --> Router Class Initialized
INFO - 2024-06-21 15:39:21 --> Output Class Initialized
INFO - 2024-06-21 15:39:22 --> Security Class Initialized
DEBUG - 2024-06-21 15:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:39:22 --> Input Class Initialized
INFO - 2024-06-21 15:39:22 --> Language Class Initialized
INFO - 2024-06-21 15:39:22 --> Language Class Initialized
INFO - 2024-06-21 15:39:22 --> Config Class Initialized
INFO - 2024-06-21 15:39:22 --> Loader Class Initialized
INFO - 2024-06-21 15:39:22 --> Helper loaded: url_helper
INFO - 2024-06-21 15:39:22 --> Helper loaded: file_helper
INFO - 2024-06-21 15:39:22 --> Helper loaded: form_helper
INFO - 2024-06-21 15:39:22 --> Helper loaded: my_helper
INFO - 2024-06-21 15:39:22 --> Database Driver Class Initialized
INFO - 2024-06-21 15:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:39:23 --> Controller Class Initialized
DEBUG - 2024-06-21 15:39:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-21 15:39:34 --> Final output sent to browser
DEBUG - 2024-06-21 15:39:34 --> Total execution time: 16.6996
INFO - 2024-06-21 15:39:35 --> Config Class Initialized
INFO - 2024-06-21 15:39:35 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:39:35 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:39:35 --> Utf8 Class Initialized
INFO - 2024-06-21 15:39:35 --> URI Class Initialized
INFO - 2024-06-21 15:39:35 --> Router Class Initialized
INFO - 2024-06-21 15:39:35 --> Output Class Initialized
INFO - 2024-06-21 15:39:35 --> Security Class Initialized
DEBUG - 2024-06-21 15:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:39:35 --> Input Class Initialized
INFO - 2024-06-21 15:39:35 --> Language Class Initialized
INFO - 2024-06-21 15:39:35 --> Language Class Initialized
INFO - 2024-06-21 15:39:35 --> Config Class Initialized
INFO - 2024-06-21 15:39:35 --> Loader Class Initialized
INFO - 2024-06-21 15:39:35 --> Helper loaded: url_helper
INFO - 2024-06-21 15:39:35 --> Helper loaded: file_helper
INFO - 2024-06-21 15:39:35 --> Helper loaded: form_helper
INFO - 2024-06-21 15:39:35 --> Helper loaded: my_helper
INFO - 2024-06-21 15:39:35 --> Database Driver Class Initialized
INFO - 2024-06-21 15:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:39:35 --> Controller Class Initialized
DEBUG - 2024-06-21 15:39:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-21 15:40:21 --> Final output sent to browser
DEBUG - 2024-06-21 15:40:21 --> Total execution time: 46.0057
INFO - 2024-06-21 15:46:40 --> Config Class Initialized
INFO - 2024-06-21 15:46:40 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:46:40 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:46:40 --> Utf8 Class Initialized
INFO - 2024-06-21 15:46:40 --> URI Class Initialized
INFO - 2024-06-21 15:46:40 --> Router Class Initialized
INFO - 2024-06-21 15:46:40 --> Output Class Initialized
INFO - 2024-06-21 15:46:40 --> Security Class Initialized
DEBUG - 2024-06-21 15:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:46:40 --> Input Class Initialized
INFO - 2024-06-21 15:46:40 --> Language Class Initialized
INFO - 2024-06-21 15:46:40 --> Language Class Initialized
INFO - 2024-06-21 15:46:40 --> Config Class Initialized
INFO - 2024-06-21 15:46:40 --> Loader Class Initialized
INFO - 2024-06-21 15:46:40 --> Helper loaded: url_helper
INFO - 2024-06-21 15:46:40 --> Helper loaded: file_helper
INFO - 2024-06-21 15:46:40 --> Helper loaded: form_helper
INFO - 2024-06-21 15:46:40 --> Helper loaded: my_helper
INFO - 2024-06-21 15:46:40 --> Database Driver Class Initialized
INFO - 2024-06-21 15:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:46:40 --> Controller Class Initialized
INFO - 2024-06-21 15:46:40 --> Helper loaded: cookie_helper
INFO - 2024-06-21 15:46:40 --> Final output sent to browser
DEBUG - 2024-06-21 15:46:40 --> Total execution time: 0.0505
INFO - 2024-06-21 15:46:40 --> Config Class Initialized
INFO - 2024-06-21 15:46:40 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:46:40 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:46:40 --> Utf8 Class Initialized
INFO - 2024-06-21 15:46:40 --> URI Class Initialized
INFO - 2024-06-21 15:46:40 --> Router Class Initialized
INFO - 2024-06-21 15:46:40 --> Output Class Initialized
INFO - 2024-06-21 15:46:40 --> Security Class Initialized
DEBUG - 2024-06-21 15:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:46:40 --> Input Class Initialized
INFO - 2024-06-21 15:46:40 --> Language Class Initialized
INFO - 2024-06-21 15:46:40 --> Language Class Initialized
INFO - 2024-06-21 15:46:40 --> Config Class Initialized
INFO - 2024-06-21 15:46:40 --> Loader Class Initialized
INFO - 2024-06-21 15:46:40 --> Helper loaded: url_helper
INFO - 2024-06-21 15:46:40 --> Helper loaded: file_helper
INFO - 2024-06-21 15:46:40 --> Helper loaded: form_helper
INFO - 2024-06-21 15:46:40 --> Helper loaded: my_helper
INFO - 2024-06-21 15:46:40 --> Database Driver Class Initialized
INFO - 2024-06-21 15:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:46:40 --> Controller Class Initialized
INFO - 2024-06-21 15:46:40 --> Helper loaded: cookie_helper
INFO - 2024-06-21 15:46:40 --> Config Class Initialized
INFO - 2024-06-21 15:46:40 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:46:40 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:46:40 --> Utf8 Class Initialized
INFO - 2024-06-21 15:46:40 --> URI Class Initialized
INFO - 2024-06-21 15:46:40 --> Router Class Initialized
INFO - 2024-06-21 15:46:40 --> Output Class Initialized
INFO - 2024-06-21 15:46:40 --> Security Class Initialized
DEBUG - 2024-06-21 15:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:46:40 --> Input Class Initialized
INFO - 2024-06-21 15:46:40 --> Language Class Initialized
INFO - 2024-06-21 15:46:40 --> Language Class Initialized
INFO - 2024-06-21 15:46:40 --> Config Class Initialized
INFO - 2024-06-21 15:46:40 --> Loader Class Initialized
INFO - 2024-06-21 15:46:40 --> Helper loaded: url_helper
INFO - 2024-06-21 15:46:40 --> Helper loaded: file_helper
INFO - 2024-06-21 15:46:40 --> Helper loaded: form_helper
INFO - 2024-06-21 15:46:40 --> Helper loaded: my_helper
INFO - 2024-06-21 15:46:40 --> Database Driver Class Initialized
INFO - 2024-06-21 15:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:46:40 --> Controller Class Initialized
DEBUG - 2024-06-21 15:46:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-06-21 15:46:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 15:46:40 --> Final output sent to browser
DEBUG - 2024-06-21 15:46:40 --> Total execution time: 0.0342
INFO - 2024-06-21 15:46:40 --> Config Class Initialized
INFO - 2024-06-21 15:46:40 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:46:40 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:46:40 --> Utf8 Class Initialized
INFO - 2024-06-21 15:46:40 --> URI Class Initialized
INFO - 2024-06-21 15:46:40 --> Router Class Initialized
INFO - 2024-06-21 15:46:40 --> Output Class Initialized
INFO - 2024-06-21 15:46:40 --> Security Class Initialized
DEBUG - 2024-06-21 15:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:46:40 --> Input Class Initialized
INFO - 2024-06-21 15:46:40 --> Language Class Initialized
INFO - 2024-06-21 15:46:40 --> Language Class Initialized
INFO - 2024-06-21 15:46:40 --> Config Class Initialized
INFO - 2024-06-21 15:46:40 --> Loader Class Initialized
INFO - 2024-06-21 15:46:40 --> Helper loaded: url_helper
INFO - 2024-06-21 15:46:40 --> Helper loaded: file_helper
INFO - 2024-06-21 15:46:40 --> Helper loaded: form_helper
INFO - 2024-06-21 15:46:40 --> Helper loaded: my_helper
INFO - 2024-06-21 15:46:40 --> Database Driver Class Initialized
INFO - 2024-06-21 15:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:46:41 --> Controller Class Initialized
INFO - 2024-06-21 15:46:41 --> Helper loaded: cookie_helper
INFO - 2024-06-21 15:46:41 --> Final output sent to browser
DEBUG - 2024-06-21 15:46:41 --> Total execution time: 0.1354
INFO - 2024-06-21 15:46:41 --> Config Class Initialized
INFO - 2024-06-21 15:46:41 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:46:41 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:46:41 --> Utf8 Class Initialized
INFO - 2024-06-21 15:46:41 --> URI Class Initialized
INFO - 2024-06-21 15:46:41 --> Router Class Initialized
INFO - 2024-06-21 15:46:41 --> Output Class Initialized
INFO - 2024-06-21 15:46:41 --> Security Class Initialized
DEBUG - 2024-06-21 15:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:46:41 --> Input Class Initialized
INFO - 2024-06-21 15:46:41 --> Language Class Initialized
INFO - 2024-06-21 15:46:41 --> Language Class Initialized
INFO - 2024-06-21 15:46:41 --> Config Class Initialized
INFO - 2024-06-21 15:46:41 --> Loader Class Initialized
INFO - 2024-06-21 15:46:41 --> Helper loaded: url_helper
INFO - 2024-06-21 15:46:41 --> Helper loaded: file_helper
INFO - 2024-06-21 15:46:41 --> Helper loaded: form_helper
INFO - 2024-06-21 15:46:41 --> Helper loaded: my_helper
INFO - 2024-06-21 15:46:41 --> Database Driver Class Initialized
INFO - 2024-06-21 15:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:46:41 --> Controller Class Initialized
INFO - 2024-06-21 15:46:41 --> Helper loaded: cookie_helper
INFO - 2024-06-21 15:46:41 --> Config Class Initialized
INFO - 2024-06-21 15:46:41 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:46:41 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:46:41 --> Utf8 Class Initialized
INFO - 2024-06-21 15:46:41 --> URI Class Initialized
INFO - 2024-06-21 15:46:41 --> Router Class Initialized
INFO - 2024-06-21 15:46:41 --> Output Class Initialized
INFO - 2024-06-21 15:46:41 --> Security Class Initialized
DEBUG - 2024-06-21 15:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:46:41 --> Input Class Initialized
INFO - 2024-06-21 15:46:41 --> Language Class Initialized
INFO - 2024-06-21 15:46:41 --> Language Class Initialized
INFO - 2024-06-21 15:46:41 --> Config Class Initialized
INFO - 2024-06-21 15:46:41 --> Loader Class Initialized
INFO - 2024-06-21 15:46:41 --> Helper loaded: url_helper
INFO - 2024-06-21 15:46:41 --> Helper loaded: file_helper
INFO - 2024-06-21 15:46:41 --> Helper loaded: form_helper
INFO - 2024-06-21 15:46:41 --> Helper loaded: my_helper
INFO - 2024-06-21 15:46:41 --> Database Driver Class Initialized
INFO - 2024-06-21 15:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:46:41 --> Controller Class Initialized
DEBUG - 2024-06-21 15:46:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-06-21 15:46:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 15:46:41 --> Final output sent to browser
DEBUG - 2024-06-21 15:46:41 --> Total execution time: 0.0375
INFO - 2024-06-21 15:46:46 --> Config Class Initialized
INFO - 2024-06-21 15:46:46 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:46:46 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:46:46 --> Utf8 Class Initialized
INFO - 2024-06-21 15:46:46 --> URI Class Initialized
INFO - 2024-06-21 15:46:46 --> Router Class Initialized
INFO - 2024-06-21 15:46:46 --> Output Class Initialized
INFO - 2024-06-21 15:46:46 --> Security Class Initialized
DEBUG - 2024-06-21 15:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:46:46 --> Input Class Initialized
INFO - 2024-06-21 15:46:46 --> Language Class Initialized
INFO - 2024-06-21 15:46:46 --> Language Class Initialized
INFO - 2024-06-21 15:46:46 --> Config Class Initialized
INFO - 2024-06-21 15:46:46 --> Loader Class Initialized
INFO - 2024-06-21 15:46:46 --> Helper loaded: url_helper
INFO - 2024-06-21 15:46:46 --> Helper loaded: file_helper
INFO - 2024-06-21 15:46:46 --> Helper loaded: form_helper
INFO - 2024-06-21 15:46:46 --> Helper loaded: my_helper
INFO - 2024-06-21 15:46:46 --> Database Driver Class Initialized
INFO - 2024-06-21 15:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:46:46 --> Controller Class Initialized
DEBUG - 2024-06-21 15:46:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-21 15:46:47 --> Final output sent to browser
DEBUG - 2024-06-21 15:46:47 --> Total execution time: 1.6268
INFO - 2024-06-21 15:46:52 --> Config Class Initialized
INFO - 2024-06-21 15:46:52 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:46:52 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:46:52 --> Utf8 Class Initialized
INFO - 2024-06-21 15:46:52 --> URI Class Initialized
INFO - 2024-06-21 15:46:52 --> Router Class Initialized
INFO - 2024-06-21 15:46:52 --> Output Class Initialized
INFO - 2024-06-21 15:46:52 --> Security Class Initialized
DEBUG - 2024-06-21 15:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:46:52 --> Input Class Initialized
INFO - 2024-06-21 15:46:52 --> Language Class Initialized
INFO - 2024-06-21 15:46:52 --> Language Class Initialized
INFO - 2024-06-21 15:46:52 --> Config Class Initialized
INFO - 2024-06-21 15:46:52 --> Loader Class Initialized
INFO - 2024-06-21 15:46:52 --> Helper loaded: url_helper
INFO - 2024-06-21 15:46:52 --> Helper loaded: file_helper
INFO - 2024-06-21 15:46:52 --> Helper loaded: form_helper
INFO - 2024-06-21 15:46:52 --> Helper loaded: my_helper
INFO - 2024-06-21 15:46:52 --> Database Driver Class Initialized
INFO - 2024-06-21 15:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:46:52 --> Controller Class Initialized
DEBUG - 2024-06-21 15:46:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-21 15:46:53 --> Final output sent to browser
DEBUG - 2024-06-21 15:46:53 --> Total execution time: 1.8437
INFO - 2024-06-21 15:51:39 --> Config Class Initialized
INFO - 2024-06-21 15:51:39 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:51:39 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:51:39 --> Utf8 Class Initialized
INFO - 2024-06-21 15:51:39 --> URI Class Initialized
INFO - 2024-06-21 15:51:39 --> Router Class Initialized
INFO - 2024-06-21 15:51:39 --> Output Class Initialized
INFO - 2024-06-21 15:51:39 --> Security Class Initialized
DEBUG - 2024-06-21 15:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:51:39 --> Input Class Initialized
INFO - 2024-06-21 15:51:39 --> Language Class Initialized
INFO - 2024-06-21 15:51:39 --> Language Class Initialized
INFO - 2024-06-21 15:51:39 --> Config Class Initialized
INFO - 2024-06-21 15:51:39 --> Loader Class Initialized
INFO - 2024-06-21 15:51:39 --> Helper loaded: url_helper
INFO - 2024-06-21 15:51:39 --> Helper loaded: file_helper
INFO - 2024-06-21 15:51:39 --> Helper loaded: form_helper
INFO - 2024-06-21 15:51:39 --> Helper loaded: my_helper
INFO - 2024-06-21 15:51:39 --> Database Driver Class Initialized
INFO - 2024-06-21 15:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:51:39 --> Controller Class Initialized
INFO - 2024-06-21 15:51:39 --> Helper loaded: cookie_helper
INFO - 2024-06-21 15:51:39 --> Final output sent to browser
DEBUG - 2024-06-21 15:51:39 --> Total execution time: 0.0308
INFO - 2024-06-21 15:51:40 --> Config Class Initialized
INFO - 2024-06-21 15:51:40 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:51:40 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:51:40 --> Utf8 Class Initialized
INFO - 2024-06-21 15:51:40 --> URI Class Initialized
INFO - 2024-06-21 15:51:40 --> Router Class Initialized
INFO - 2024-06-21 15:51:40 --> Output Class Initialized
INFO - 2024-06-21 15:51:40 --> Security Class Initialized
DEBUG - 2024-06-21 15:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:51:40 --> Input Class Initialized
INFO - 2024-06-21 15:51:40 --> Language Class Initialized
INFO - 2024-06-21 15:51:40 --> Language Class Initialized
INFO - 2024-06-21 15:51:40 --> Config Class Initialized
INFO - 2024-06-21 15:51:40 --> Loader Class Initialized
INFO - 2024-06-21 15:51:40 --> Helper loaded: url_helper
INFO - 2024-06-21 15:51:40 --> Helper loaded: file_helper
INFO - 2024-06-21 15:51:40 --> Helper loaded: form_helper
INFO - 2024-06-21 15:51:40 --> Helper loaded: my_helper
INFO - 2024-06-21 15:51:40 --> Database Driver Class Initialized
INFO - 2024-06-21 15:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:51:40 --> Controller Class Initialized
INFO - 2024-06-21 15:51:40 --> Helper loaded: cookie_helper
INFO - 2024-06-21 15:51:40 --> Config Class Initialized
INFO - 2024-06-21 15:51:40 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:51:40 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:51:40 --> Utf8 Class Initialized
INFO - 2024-06-21 15:51:40 --> URI Class Initialized
INFO - 2024-06-21 15:51:40 --> Router Class Initialized
INFO - 2024-06-21 15:51:40 --> Output Class Initialized
INFO - 2024-06-21 15:51:40 --> Security Class Initialized
DEBUG - 2024-06-21 15:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:51:40 --> Input Class Initialized
INFO - 2024-06-21 15:51:40 --> Language Class Initialized
INFO - 2024-06-21 15:51:40 --> Language Class Initialized
INFO - 2024-06-21 15:51:40 --> Config Class Initialized
INFO - 2024-06-21 15:51:40 --> Loader Class Initialized
INFO - 2024-06-21 15:51:40 --> Helper loaded: url_helper
INFO - 2024-06-21 15:51:40 --> Helper loaded: file_helper
INFO - 2024-06-21 15:51:40 --> Helper loaded: form_helper
INFO - 2024-06-21 15:51:40 --> Helper loaded: my_helper
INFO - 2024-06-21 15:51:40 --> Database Driver Class Initialized
INFO - 2024-06-21 15:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:51:40 --> Controller Class Initialized
DEBUG - 2024-06-21 15:51:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-06-21 15:51:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 15:51:40 --> Final output sent to browser
DEBUG - 2024-06-21 15:51:40 --> Total execution time: 0.0509
INFO - 2024-06-21 15:51:49 --> Config Class Initialized
INFO - 2024-06-21 15:51:49 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:51:49 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:51:49 --> Utf8 Class Initialized
INFO - 2024-06-21 15:51:49 --> URI Class Initialized
INFO - 2024-06-21 15:51:49 --> Router Class Initialized
INFO - 2024-06-21 15:51:49 --> Output Class Initialized
INFO - 2024-06-21 15:51:49 --> Security Class Initialized
DEBUG - 2024-06-21 15:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:51:49 --> Input Class Initialized
INFO - 2024-06-21 15:51:49 --> Language Class Initialized
INFO - 2024-06-21 15:51:49 --> Language Class Initialized
INFO - 2024-06-21 15:51:49 --> Config Class Initialized
INFO - 2024-06-21 15:51:49 --> Loader Class Initialized
INFO - 2024-06-21 15:51:49 --> Helper loaded: url_helper
INFO - 2024-06-21 15:51:49 --> Helper loaded: file_helper
INFO - 2024-06-21 15:51:49 --> Helper loaded: form_helper
INFO - 2024-06-21 15:51:49 --> Helper loaded: my_helper
INFO - 2024-06-21 15:51:49 --> Database Driver Class Initialized
INFO - 2024-06-21 15:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:51:49 --> Controller Class Initialized
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:49 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-21 15:51:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-21 15:51:54 --> Final output sent to browser
DEBUG - 2024-06-21 15:51:54 --> Total execution time: 5.1170
INFO - 2024-06-21 15:51:56 --> Config Class Initialized
INFO - 2024-06-21 15:51:56 --> Hooks Class Initialized
DEBUG - 2024-06-21 15:51:56 --> UTF-8 Support Enabled
INFO - 2024-06-21 15:51:56 --> Utf8 Class Initialized
INFO - 2024-06-21 15:51:56 --> URI Class Initialized
INFO - 2024-06-21 15:51:56 --> Router Class Initialized
INFO - 2024-06-21 15:51:56 --> Output Class Initialized
INFO - 2024-06-21 15:51:56 --> Security Class Initialized
DEBUG - 2024-06-21 15:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 15:51:56 --> Input Class Initialized
INFO - 2024-06-21 15:51:56 --> Language Class Initialized
INFO - 2024-06-21 15:51:56 --> Language Class Initialized
INFO - 2024-06-21 15:51:56 --> Config Class Initialized
INFO - 2024-06-21 15:51:56 --> Loader Class Initialized
INFO - 2024-06-21 15:51:56 --> Helper loaded: url_helper
INFO - 2024-06-21 15:51:56 --> Helper loaded: file_helper
INFO - 2024-06-21 15:51:56 --> Helper loaded: form_helper
INFO - 2024-06-21 15:51:56 --> Helper loaded: my_helper
INFO - 2024-06-21 15:51:56 --> Database Driver Class Initialized
INFO - 2024-06-21 15:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 15:51:56 --> Controller Class Initialized
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-21 15:51:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-21 15:51:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-21 15:52:01 --> Final output sent to browser
DEBUG - 2024-06-21 15:52:01 --> Total execution time: 5.5942
INFO - 2024-06-21 23:20:12 --> Config Class Initialized
INFO - 2024-06-21 23:20:12 --> Hooks Class Initialized
INFO - 2024-06-21 23:20:12 --> Config Class Initialized
INFO - 2024-06-21 23:20:12 --> Hooks Class Initialized
DEBUG - 2024-06-21 23:20:12 --> UTF-8 Support Enabled
INFO - 2024-06-21 23:20:12 --> Utf8 Class Initialized
DEBUG - 2024-06-21 23:20:12 --> UTF-8 Support Enabled
INFO - 2024-06-21 23:20:12 --> Utf8 Class Initialized
INFO - 2024-06-21 23:20:12 --> URI Class Initialized
INFO - 2024-06-21 23:20:12 --> Config Class Initialized
INFO - 2024-06-21 23:20:12 --> Hooks Class Initialized
DEBUG - 2024-06-21 23:20:12 --> UTF-8 Support Enabled
INFO - 2024-06-21 23:20:12 --> Utf8 Class Initialized
INFO - 2024-06-21 23:20:12 --> URI Class Initialized
INFO - 2024-06-21 23:20:12 --> URI Class Initialized
INFO - 2024-06-21 23:20:12 --> Router Class Initialized
INFO - 2024-06-21 23:20:12 --> Router Class Initialized
INFO - 2024-06-21 23:20:12 --> Router Class Initialized
INFO - 2024-06-21 23:20:12 --> Output Class Initialized
INFO - 2024-06-21 23:20:12 --> Output Class Initialized
INFO - 2024-06-21 23:20:12 --> Output Class Initialized
INFO - 2024-06-21 23:20:12 --> Security Class Initialized
INFO - 2024-06-21 23:20:12 --> Security Class Initialized
DEBUG - 2024-06-21 23:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 23:20:12 --> Input Class Initialized
INFO - 2024-06-21 23:20:12 --> Security Class Initialized
DEBUG - 2024-06-21 23:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 23:20:12 --> Input Class Initialized
INFO - 2024-06-21 23:20:12 --> Language Class Initialized
INFO - 2024-06-21 23:20:12 --> Language Class Initialized
DEBUG - 2024-06-21 23:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 23:20:12 --> Input Class Initialized
INFO - 2024-06-21 23:20:12 --> Language Class Initialized
INFO - 2024-06-21 23:20:12 --> Language Class Initialized
INFO - 2024-06-21 23:20:12 --> Config Class Initialized
INFO - 2024-06-21 23:20:12 --> Loader Class Initialized
INFO - 2024-06-21 23:20:12 --> Language Class Initialized
INFO - 2024-06-21 23:20:12 --> Config Class Initialized
INFO - 2024-06-21 23:20:12 --> Loader Class Initialized
INFO - 2024-06-21 23:20:12 --> Language Class Initialized
INFO - 2024-06-21 23:20:12 --> Config Class Initialized
INFO - 2024-06-21 23:20:12 --> Loader Class Initialized
INFO - 2024-06-21 23:20:12 --> Helper loaded: url_helper
INFO - 2024-06-21 23:20:12 --> Helper loaded: url_helper
INFO - 2024-06-21 23:20:12 --> Helper loaded: file_helper
INFO - 2024-06-21 23:20:12 --> Helper loaded: url_helper
INFO - 2024-06-21 23:20:12 --> Helper loaded: file_helper
INFO - 2024-06-21 23:20:12 --> Helper loaded: form_helper
INFO - 2024-06-21 23:20:12 --> Helper loaded: form_helper
INFO - 2024-06-21 23:20:12 --> Helper loaded: my_helper
INFO - 2024-06-21 23:20:12 --> Helper loaded: my_helper
INFO - 2024-06-21 23:20:12 --> Helper loaded: file_helper
INFO - 2024-06-21 23:20:12 --> Helper loaded: form_helper
INFO - 2024-06-21 23:20:12 --> Helper loaded: my_helper
INFO - 2024-06-21 23:20:12 --> Database Driver Class Initialized
INFO - 2024-06-21 23:20:12 --> Database Driver Class Initialized
INFO - 2024-06-21 23:20:12 --> Database Driver Class Initialized
INFO - 2024-06-21 23:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 23:20:12 --> Controller Class Initialized
INFO - 2024-06-21 23:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 23:20:12 --> Controller Class Initialized
INFO - 2024-06-21 23:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 23:20:12 --> Controller Class Initialized
INFO - 2024-06-21 23:20:12 --> Helper loaded: cookie_helper
INFO - 2024-06-21 23:20:12 --> Final output sent to browser
DEBUG - 2024-06-21 23:20:12 --> Total execution time: 0.2274
INFO - 2024-06-21 23:20:12 --> Helper loaded: cookie_helper
INFO - 2024-06-21 23:20:12 --> Final output sent to browser
DEBUG - 2024-06-21 23:20:12 --> Total execution time: 0.2220
INFO - 2024-06-21 23:20:12 --> Helper loaded: cookie_helper
INFO - 2024-06-21 23:20:12 --> Final output sent to browser
DEBUG - 2024-06-21 23:20:12 --> Total execution time: 0.2466
INFO - 2024-06-21 23:20:12 --> Config Class Initialized
INFO - 2024-06-21 23:20:12 --> Hooks Class Initialized
DEBUG - 2024-06-21 23:20:12 --> UTF-8 Support Enabled
INFO - 2024-06-21 23:20:12 --> Utf8 Class Initialized
INFO - 2024-06-21 23:20:12 --> URI Class Initialized
INFO - 2024-06-21 23:20:12 --> Router Class Initialized
INFO - 2024-06-21 23:20:12 --> Output Class Initialized
INFO - 2024-06-21 23:20:12 --> Security Class Initialized
DEBUG - 2024-06-21 23:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 23:20:12 --> Input Class Initialized
INFO - 2024-06-21 23:20:12 --> Language Class Initialized
INFO - 2024-06-21 23:20:12 --> Language Class Initialized
INFO - 2024-06-21 23:20:12 --> Config Class Initialized
INFO - 2024-06-21 23:20:12 --> Loader Class Initialized
INFO - 2024-06-21 23:20:12 --> Helper loaded: url_helper
INFO - 2024-06-21 23:20:12 --> Helper loaded: file_helper
INFO - 2024-06-21 23:20:12 --> Helper loaded: form_helper
INFO - 2024-06-21 23:20:12 --> Helper loaded: my_helper
INFO - 2024-06-21 23:20:12 --> Database Driver Class Initialized
INFO - 2024-06-21 23:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 23:20:12 --> Controller Class Initialized
INFO - 2024-06-21 23:20:12 --> Helper loaded: cookie_helper
INFO - 2024-06-21 23:20:12 --> Final output sent to browser
DEBUG - 2024-06-21 23:20:12 --> Total execution time: 0.0373
INFO - 2024-06-21 23:20:13 --> Config Class Initialized
INFO - 2024-06-21 23:20:13 --> Hooks Class Initialized
DEBUG - 2024-06-21 23:20:13 --> UTF-8 Support Enabled
INFO - 2024-06-21 23:20:13 --> Utf8 Class Initialized
INFO - 2024-06-21 23:20:13 --> URI Class Initialized
INFO - 2024-06-21 23:20:13 --> Router Class Initialized
INFO - 2024-06-21 23:20:13 --> Output Class Initialized
INFO - 2024-06-21 23:20:13 --> Security Class Initialized
DEBUG - 2024-06-21 23:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 23:20:13 --> Input Class Initialized
INFO - 2024-06-21 23:20:13 --> Language Class Initialized
INFO - 2024-06-21 23:20:13 --> Language Class Initialized
INFO - 2024-06-21 23:20:13 --> Config Class Initialized
INFO - 2024-06-21 23:20:13 --> Loader Class Initialized
INFO - 2024-06-21 23:20:13 --> Helper loaded: url_helper
INFO - 2024-06-21 23:20:13 --> Helper loaded: file_helper
INFO - 2024-06-21 23:20:13 --> Helper loaded: form_helper
INFO - 2024-06-21 23:20:13 --> Helper loaded: my_helper
INFO - 2024-06-21 23:20:13 --> Database Driver Class Initialized
INFO - 2024-06-21 23:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 23:20:13 --> Controller Class Initialized
INFO - 2024-06-21 23:20:13 --> Helper loaded: cookie_helper
INFO - 2024-06-21 23:20:13 --> Config Class Initialized
INFO - 2024-06-21 23:20:13 --> Hooks Class Initialized
DEBUG - 2024-06-21 23:20:13 --> UTF-8 Support Enabled
INFO - 2024-06-21 23:20:13 --> Utf8 Class Initialized
INFO - 2024-06-21 23:20:13 --> URI Class Initialized
INFO - 2024-06-21 23:20:13 --> Router Class Initialized
INFO - 2024-06-21 23:20:13 --> Output Class Initialized
INFO - 2024-06-21 23:20:13 --> Security Class Initialized
DEBUG - 2024-06-21 23:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 23:20:13 --> Input Class Initialized
INFO - 2024-06-21 23:20:13 --> Language Class Initialized
INFO - 2024-06-21 23:20:13 --> Language Class Initialized
INFO - 2024-06-21 23:20:13 --> Config Class Initialized
INFO - 2024-06-21 23:20:13 --> Loader Class Initialized
INFO - 2024-06-21 23:20:13 --> Helper loaded: url_helper
INFO - 2024-06-21 23:20:13 --> Helper loaded: file_helper
INFO - 2024-06-21 23:20:13 --> Helper loaded: form_helper
INFO - 2024-06-21 23:20:13 --> Helper loaded: my_helper
INFO - 2024-06-21 23:20:13 --> Database Driver Class Initialized
INFO - 2024-06-21 23:20:13 --> Config Class Initialized
INFO - 2024-06-21 23:20:13 --> Hooks Class Initialized
DEBUG - 2024-06-21 23:20:13 --> UTF-8 Support Enabled
INFO - 2024-06-21 23:20:13 --> Utf8 Class Initialized
INFO - 2024-06-21 23:20:13 --> URI Class Initialized
INFO - 2024-06-21 23:20:13 --> Router Class Initialized
INFO - 2024-06-21 23:20:13 --> Output Class Initialized
INFO - 2024-06-21 23:20:13 --> Security Class Initialized
DEBUG - 2024-06-21 23:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 23:20:13 --> Input Class Initialized
INFO - 2024-06-21 23:20:13 --> Language Class Initialized
INFO - 2024-06-21 23:20:13 --> Language Class Initialized
INFO - 2024-06-21 23:20:13 --> Config Class Initialized
INFO - 2024-06-21 23:20:13 --> Loader Class Initialized
INFO - 2024-06-21 23:20:13 --> Helper loaded: url_helper
INFO - 2024-06-21 23:20:13 --> Helper loaded: file_helper
INFO - 2024-06-21 23:20:13 --> Helper loaded: form_helper
INFO - 2024-06-21 23:20:13 --> Helper loaded: my_helper
INFO - 2024-06-21 23:20:13 --> Database Driver Class Initialized
INFO - 2024-06-21 23:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 23:20:13 --> Controller Class Initialized
INFO - 2024-06-21 23:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 23:20:13 --> Controller Class Initialized
INFO - 2024-06-21 23:20:13 --> Helper loaded: cookie_helper
INFO - 2024-06-21 23:20:13 --> Final output sent to browser
DEBUG - 2024-06-21 23:20:13 --> Total execution time: 0.0757
INFO - 2024-06-21 23:20:13 --> Config Class Initialized
INFO - 2024-06-21 23:20:13 --> Hooks Class Initialized
DEBUG - 2024-06-21 23:20:13 --> UTF-8 Support Enabled
INFO - 2024-06-21 23:20:13 --> Utf8 Class Initialized
INFO - 2024-06-21 23:20:13 --> Helper loaded: cookie_helper
INFO - 2024-06-21 23:20:13 --> URI Class Initialized
INFO - 2024-06-21 23:20:13 --> Router Class Initialized
INFO - 2024-06-21 23:20:13 --> Output Class Initialized
INFO - 2024-06-21 23:20:13 --> Security Class Initialized
INFO - 2024-06-21 23:20:13 --> Config Class Initialized
INFO - 2024-06-21 23:20:13 --> Hooks Class Initialized
DEBUG - 2024-06-21 23:20:13 --> UTF-8 Support Enabled
INFO - 2024-06-21 23:20:13 --> Utf8 Class Initialized
INFO - 2024-06-21 23:20:13 --> URI Class Initialized
INFO - 2024-06-21 23:20:13 --> Router Class Initialized
INFO - 2024-06-21 23:20:13 --> Output Class Initialized
INFO - 2024-06-21 23:20:13 --> Security Class Initialized
DEBUG - 2024-06-21 23:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 23:20:13 --> Input Class Initialized
INFO - 2024-06-21 23:20:13 --> Language Class Initialized
INFO - 2024-06-21 23:20:13 --> Language Class Initialized
INFO - 2024-06-21 23:20:13 --> Config Class Initialized
INFO - 2024-06-21 23:20:13 --> Loader Class Initialized
INFO - 2024-06-21 23:20:13 --> Helper loaded: url_helper
INFO - 2024-06-21 23:20:13 --> Helper loaded: file_helper
INFO - 2024-06-21 23:20:13 --> Helper loaded: form_helper
INFO - 2024-06-21 23:20:13 --> Helper loaded: my_helper
INFO - 2024-06-21 23:20:13 --> Database Driver Class Initialized
DEBUG - 2024-06-21 23:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 23:20:13 --> Input Class Initialized
INFO - 2024-06-21 23:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 23:20:13 --> Controller Class Initialized
INFO - 2024-06-21 23:20:13 --> Language Class Initialized
INFO - 2024-06-21 23:20:13 --> Config Class Initialized
INFO - 2024-06-21 23:20:13 --> Hooks Class Initialized
DEBUG - 2024-06-21 23:20:13 --> UTF-8 Support Enabled
INFO - 2024-06-21 23:20:13 --> Utf8 Class Initialized
INFO - 2024-06-21 23:20:13 --> URI Class Initialized
INFO - 2024-06-21 23:20:13 --> Router Class Initialized
INFO - 2024-06-21 23:20:13 --> Output Class Initialized
INFO - 2024-06-21 23:20:13 --> Security Class Initialized
DEBUG - 2024-06-21 23:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 23:20:13 --> Input Class Initialized
INFO - 2024-06-21 23:20:13 --> Language Class Initialized
INFO - 2024-06-21 23:20:13 --> Language Class Initialized
INFO - 2024-06-21 23:20:13 --> Config Class Initialized
INFO - 2024-06-21 23:20:13 --> Loader Class Initialized
INFO - 2024-06-21 23:20:13 --> Helper loaded: url_helper
INFO - 2024-06-21 23:20:13 --> Helper loaded: file_helper
INFO - 2024-06-21 23:20:13 --> Helper loaded: form_helper
INFO - 2024-06-21 23:20:13 --> Helper loaded: my_helper
INFO - 2024-06-21 23:20:13 --> Helper loaded: cookie_helper
INFO - 2024-06-21 23:20:13 --> Language Class Initialized
INFO - 2024-06-21 23:20:13 --> Config Class Initialized
INFO - 2024-06-21 23:20:13 --> Loader Class Initialized
INFO - 2024-06-21 23:20:13 --> Helper loaded: url_helper
INFO - 2024-06-21 23:20:13 --> Helper loaded: file_helper
INFO - 2024-06-21 23:20:13 --> Helper loaded: form_helper
INFO - 2024-06-21 23:20:13 --> Helper loaded: my_helper
INFO - 2024-06-21 23:20:13 --> Database Driver Class Initialized
INFO - 2024-06-21 23:20:13 --> Config Class Initialized
INFO - 2024-06-21 23:20:13 --> Hooks Class Initialized
DEBUG - 2024-06-21 23:20:13 --> UTF-8 Support Enabled
INFO - 2024-06-21 23:20:13 --> Utf8 Class Initialized
INFO - 2024-06-21 23:20:13 --> URI Class Initialized
INFO - 2024-06-21 23:20:13 --> Router Class Initialized
INFO - 2024-06-21 23:20:13 --> Output Class Initialized
INFO - 2024-06-21 23:20:13 --> Security Class Initialized
DEBUG - 2024-06-21 23:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 23:20:13 --> Input Class Initialized
INFO - 2024-06-21 23:20:13 --> Language Class Initialized
INFO - 2024-06-21 23:20:13 --> Language Class Initialized
INFO - 2024-06-21 23:20:13 --> Config Class Initialized
INFO - 2024-06-21 23:20:13 --> Loader Class Initialized
INFO - 2024-06-21 23:20:13 --> Helper loaded: url_helper
INFO - 2024-06-21 23:20:13 --> Helper loaded: file_helper
INFO - 2024-06-21 23:20:13 --> Helper loaded: form_helper
INFO - 2024-06-21 23:20:13 --> Helper loaded: my_helper
INFO - 2024-06-21 23:20:13 --> Database Driver Class Initialized
INFO - 2024-06-21 23:20:13 --> Database Driver Class Initialized
INFO - 2024-06-21 23:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 23:20:13 --> Controller Class Initialized
INFO - 2024-06-21 23:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 23:20:13 --> Controller Class Initialized
INFO - 2024-06-21 23:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 23:20:13 --> Controller Class Initialized
INFO - 2024-06-21 23:20:13 --> Helper loaded: cookie_helper
INFO - 2024-06-21 23:20:13 --> Final output sent to browser
DEBUG - 2024-06-21 23:20:13 --> Total execution time: 0.1011
INFO - 2024-06-21 23:20:13 --> Helper loaded: cookie_helper
DEBUG - 2024-06-21 23:20:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-06-21 23:20:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 23:20:13 --> Final output sent to browser
DEBUG - 2024-06-21 23:20:13 --> Total execution time: 0.2096
INFO - 2024-06-21 23:20:13 --> Config Class Initialized
INFO - 2024-06-21 23:20:13 --> Hooks Class Initialized
DEBUG - 2024-06-21 23:20:13 --> UTF-8 Support Enabled
INFO - 2024-06-21 23:20:13 --> Utf8 Class Initialized
INFO - 2024-06-21 23:20:13 --> Config Class Initialized
INFO - 2024-06-21 23:20:13 --> Hooks Class Initialized
DEBUG - 2024-06-21 23:20:13 --> UTF-8 Support Enabled
INFO - 2024-06-21 23:20:13 --> Utf8 Class Initialized
INFO - 2024-06-21 23:20:13 --> URI Class Initialized
INFO - 2024-06-21 23:20:13 --> Router Class Initialized
INFO - 2024-06-21 23:20:13 --> Output Class Initialized
INFO - 2024-06-21 23:20:13 --> Security Class Initialized
DEBUG - 2024-06-21 23:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 23:20:13 --> Input Class Initialized
INFO - 2024-06-21 23:20:13 --> Language Class Initialized
INFO - 2024-06-21 23:20:13 --> Language Class Initialized
INFO - 2024-06-21 23:20:13 --> Config Class Initialized
INFO - 2024-06-21 23:20:13 --> Loader Class Initialized
INFO - 2024-06-21 23:20:13 --> URI Class Initialized
INFO - 2024-06-21 23:20:13 --> Router Class Initialized
INFO - 2024-06-21 23:20:13 --> Output Class Initialized
INFO - 2024-06-21 23:20:13 --> Security Class Initialized
DEBUG - 2024-06-21 23:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 23:20:13 --> Input Class Initialized
INFO - 2024-06-21 23:20:13 --> Language Class Initialized
INFO - 2024-06-21 23:20:13 --> Language Class Initialized
INFO - 2024-06-21 23:20:13 --> Config Class Initialized
INFO - 2024-06-21 23:20:13 --> Loader Class Initialized
INFO - 2024-06-21 23:20:13 --> Helper loaded: url_helper
INFO - 2024-06-21 23:20:13 --> Helper loaded: file_helper
INFO - 2024-06-21 23:20:13 --> Helper loaded: form_helper
INFO - 2024-06-21 23:20:13 --> Helper loaded: my_helper
INFO - 2024-06-21 23:20:13 --> Helper loaded: url_helper
INFO - 2024-06-21 23:20:13 --> Helper loaded: file_helper
INFO - 2024-06-21 23:20:13 --> Helper loaded: form_helper
INFO - 2024-06-21 23:20:13 --> Helper loaded: my_helper
INFO - 2024-06-21 23:20:13 --> Database Driver Class Initialized
INFO - 2024-06-21 23:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 23:20:13 --> Controller Class Initialized
DEBUG - 2024-06-21 23:20:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-06-21 23:20:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 23:20:13 --> Final output sent to browser
DEBUG - 2024-06-21 23:20:13 --> Total execution time: 0.0459
INFO - 2024-06-21 23:20:13 --> Database Driver Class Initialized
INFO - 2024-06-21 23:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 23:20:14 --> Controller Class Initialized
INFO - 2024-06-21 23:20:14 --> Helper loaded: cookie_helper
INFO - 2024-06-21 23:20:14 --> Config Class Initialized
INFO - 2024-06-21 23:20:14 --> Hooks Class Initialized
DEBUG - 2024-06-21 23:20:14 --> UTF-8 Support Enabled
INFO - 2024-06-21 23:20:14 --> Utf8 Class Initialized
INFO - 2024-06-21 23:20:14 --> URI Class Initialized
INFO - 2024-06-21 23:20:14 --> Router Class Initialized
INFO - 2024-06-21 23:20:14 --> Output Class Initialized
INFO - 2024-06-21 23:20:14 --> Security Class Initialized
DEBUG - 2024-06-21 23:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 23:20:14 --> Input Class Initialized
INFO - 2024-06-21 23:20:14 --> Language Class Initialized
INFO - 2024-06-21 23:20:14 --> Language Class Initialized
INFO - 2024-06-21 23:20:14 --> Config Class Initialized
INFO - 2024-06-21 23:20:14 --> Loader Class Initialized
INFO - 2024-06-21 23:20:14 --> Helper loaded: url_helper
INFO - 2024-06-21 23:20:14 --> Helper loaded: file_helper
INFO - 2024-06-21 23:20:14 --> Helper loaded: form_helper
INFO - 2024-06-21 23:20:14 --> Helper loaded: my_helper
INFO - 2024-06-21 23:20:14 --> Database Driver Class Initialized
INFO - 2024-06-21 23:20:14 --> Config Class Initialized
INFO - 2024-06-21 23:20:14 --> Hooks Class Initialized
DEBUG - 2024-06-21 23:20:14 --> UTF-8 Support Enabled
INFO - 2024-06-21 23:20:14 --> Utf8 Class Initialized
INFO - 2024-06-21 23:20:14 --> URI Class Initialized
INFO - 2024-06-21 23:20:14 --> Router Class Initialized
INFO - 2024-06-21 23:20:14 --> Output Class Initialized
INFO - 2024-06-21 23:20:14 --> Security Class Initialized
DEBUG - 2024-06-21 23:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 23:20:14 --> Input Class Initialized
INFO - 2024-06-21 23:20:14 --> Language Class Initialized
INFO - 2024-06-21 23:20:14 --> Language Class Initialized
INFO - 2024-06-21 23:20:14 --> Config Class Initialized
INFO - 2024-06-21 23:20:14 --> Loader Class Initialized
INFO - 2024-06-21 23:20:14 --> Helper loaded: url_helper
INFO - 2024-06-21 23:20:14 --> Helper loaded: file_helper
INFO - 2024-06-21 23:20:14 --> Helper loaded: form_helper
INFO - 2024-06-21 23:20:14 --> Helper loaded: my_helper
INFO - 2024-06-21 23:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 23:20:14 --> Controller Class Initialized
DEBUG - 2024-06-21 23:20:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-06-21 23:20:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 23:20:14 --> Final output sent to browser
DEBUG - 2024-06-21 23:20:14 --> Total execution time: 0.0656
INFO - 2024-06-21 23:20:14 --> Database Driver Class Initialized
INFO - 2024-06-21 23:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 23:20:14 --> Controller Class Initialized
INFO - 2024-06-21 23:20:14 --> Helper loaded: cookie_helper
INFO - 2024-06-21 23:20:14 --> Config Class Initialized
INFO - 2024-06-21 23:20:14 --> Hooks Class Initialized
DEBUG - 2024-06-21 23:20:14 --> UTF-8 Support Enabled
INFO - 2024-06-21 23:20:14 --> Utf8 Class Initialized
INFO - 2024-06-21 23:20:14 --> URI Class Initialized
INFO - 2024-06-21 23:20:14 --> Router Class Initialized
INFO - 2024-06-21 23:20:14 --> Output Class Initialized
INFO - 2024-06-21 23:20:14 --> Security Class Initialized
DEBUG - 2024-06-21 23:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 23:20:14 --> Input Class Initialized
INFO - 2024-06-21 23:20:14 --> Language Class Initialized
INFO - 2024-06-21 23:20:14 --> Language Class Initialized
INFO - 2024-06-21 23:20:14 --> Config Class Initialized
INFO - 2024-06-21 23:20:14 --> Loader Class Initialized
INFO - 2024-06-21 23:20:14 --> Helper loaded: url_helper
INFO - 2024-06-21 23:20:14 --> Helper loaded: file_helper
INFO - 2024-06-21 23:20:14 --> Helper loaded: form_helper
INFO - 2024-06-21 23:20:14 --> Helper loaded: my_helper
INFO - 2024-06-21 23:20:14 --> Database Driver Class Initialized
INFO - 2024-06-21 23:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 23:20:14 --> Controller Class Initialized
DEBUG - 2024-06-21 23:20:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-06-21 23:20:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 23:20:14 --> Final output sent to browser
DEBUG - 2024-06-21 23:20:14 --> Total execution time: 0.0985
INFO - 2024-06-21 23:20:15 --> Config Class Initialized
INFO - 2024-06-21 23:20:15 --> Hooks Class Initialized
DEBUG - 2024-06-21 23:20:15 --> UTF-8 Support Enabled
INFO - 2024-06-21 23:20:15 --> Utf8 Class Initialized
INFO - 2024-06-21 23:20:15 --> URI Class Initialized
INFO - 2024-06-21 23:20:15 --> Router Class Initialized
INFO - 2024-06-21 23:20:15 --> Output Class Initialized
INFO - 2024-06-21 23:20:15 --> Security Class Initialized
DEBUG - 2024-06-21 23:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 23:20:15 --> Input Class Initialized
INFO - 2024-06-21 23:20:15 --> Language Class Initialized
INFO - 2024-06-21 23:20:15 --> Language Class Initialized
INFO - 2024-06-21 23:20:15 --> Config Class Initialized
INFO - 2024-06-21 23:20:15 --> Loader Class Initialized
INFO - 2024-06-21 23:20:15 --> Helper loaded: url_helper
INFO - 2024-06-21 23:20:15 --> Helper loaded: file_helper
INFO - 2024-06-21 23:20:15 --> Helper loaded: form_helper
INFO - 2024-06-21 23:20:15 --> Helper loaded: my_helper
INFO - 2024-06-21 23:20:15 --> Database Driver Class Initialized
INFO - 2024-06-21 23:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 23:20:15 --> Controller Class Initialized
DEBUG - 2024-06-21 23:20:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-06-21 23:20:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 23:20:15 --> Final output sent to browser
DEBUG - 2024-06-21 23:20:15 --> Total execution time: 0.0335
INFO - 2024-06-21 23:20:15 --> Config Class Initialized
INFO - 2024-06-21 23:20:15 --> Hooks Class Initialized
DEBUG - 2024-06-21 23:20:15 --> UTF-8 Support Enabled
INFO - 2024-06-21 23:20:15 --> Utf8 Class Initialized
INFO - 2024-06-21 23:20:15 --> URI Class Initialized
INFO - 2024-06-21 23:20:15 --> Router Class Initialized
INFO - 2024-06-21 23:20:15 --> Output Class Initialized
INFO - 2024-06-21 23:20:15 --> Security Class Initialized
DEBUG - 2024-06-21 23:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 23:20:15 --> Input Class Initialized
INFO - 2024-06-21 23:20:15 --> Language Class Initialized
INFO - 2024-06-21 23:20:15 --> Language Class Initialized
INFO - 2024-06-21 23:20:15 --> Config Class Initialized
INFO - 2024-06-21 23:20:15 --> Loader Class Initialized
INFO - 2024-06-21 23:20:15 --> Helper loaded: url_helper
INFO - 2024-06-21 23:20:15 --> Helper loaded: file_helper
INFO - 2024-06-21 23:20:15 --> Helper loaded: form_helper
INFO - 2024-06-21 23:20:15 --> Helper loaded: my_helper
INFO - 2024-06-21 23:20:15 --> Database Driver Class Initialized
INFO - 2024-06-21 23:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 23:20:15 --> Controller Class Initialized
DEBUG - 2024-06-21 23:20:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-06-21 23:20:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-21 23:20:15 --> Final output sent to browser
DEBUG - 2024-06-21 23:20:15 --> Total execution time: 0.0315
INFO - 2024-06-21 23:20:26 --> Config Class Initialized
INFO - 2024-06-21 23:20:26 --> Hooks Class Initialized
DEBUG - 2024-06-21 23:20:26 --> UTF-8 Support Enabled
INFO - 2024-06-21 23:20:26 --> Utf8 Class Initialized
INFO - 2024-06-21 23:20:26 --> URI Class Initialized
INFO - 2024-06-21 23:20:26 --> Router Class Initialized
INFO - 2024-06-21 23:20:26 --> Output Class Initialized
INFO - 2024-06-21 23:20:26 --> Security Class Initialized
DEBUG - 2024-06-21 23:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 23:20:26 --> Input Class Initialized
INFO - 2024-06-21 23:20:26 --> Language Class Initialized
INFO - 2024-06-21 23:20:26 --> Language Class Initialized
INFO - 2024-06-21 23:20:26 --> Config Class Initialized
INFO - 2024-06-21 23:20:26 --> Loader Class Initialized
INFO - 2024-06-21 23:20:26 --> Helper loaded: url_helper
INFO - 2024-06-21 23:20:26 --> Helper loaded: file_helper
INFO - 2024-06-21 23:20:26 --> Helper loaded: form_helper
INFO - 2024-06-21 23:20:26 --> Helper loaded: my_helper
INFO - 2024-06-21 23:20:26 --> Database Driver Class Initialized
INFO - 2024-06-21 23:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 23:20:27 --> Controller Class Initialized
DEBUG - 2024-06-21 23:20:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-21 23:20:34 --> Final output sent to browser
DEBUG - 2024-06-21 23:20:34 --> Total execution time: 7.2905
INFO - 2024-06-21 23:20:35 --> Config Class Initialized
INFO - 2024-06-21 23:20:35 --> Hooks Class Initialized
DEBUG - 2024-06-21 23:20:35 --> UTF-8 Support Enabled
INFO - 2024-06-21 23:20:35 --> Utf8 Class Initialized
INFO - 2024-06-21 23:20:35 --> URI Class Initialized
INFO - 2024-06-21 23:20:35 --> Router Class Initialized
INFO - 2024-06-21 23:20:35 --> Output Class Initialized
INFO - 2024-06-21 23:20:35 --> Security Class Initialized
DEBUG - 2024-06-21 23:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 23:20:35 --> Input Class Initialized
INFO - 2024-06-21 23:20:35 --> Language Class Initialized
INFO - 2024-06-21 23:20:35 --> Language Class Initialized
INFO - 2024-06-21 23:20:35 --> Config Class Initialized
INFO - 2024-06-21 23:20:35 --> Loader Class Initialized
INFO - 2024-06-21 23:20:35 --> Helper loaded: url_helper
INFO - 2024-06-21 23:20:35 --> Helper loaded: file_helper
INFO - 2024-06-21 23:20:35 --> Helper loaded: form_helper
INFO - 2024-06-21 23:20:35 --> Helper loaded: my_helper
INFO - 2024-06-21 23:20:35 --> Database Driver Class Initialized
INFO - 2024-06-21 23:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 23:20:35 --> Controller Class Initialized
DEBUG - 2024-06-21 23:20:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-21 23:20:39 --> Final output sent to browser
DEBUG - 2024-06-21 23:20:39 --> Total execution time: 4.5517
INFO - 2024-06-21 23:20:53 --> Config Class Initialized
INFO - 2024-06-21 23:20:53 --> Hooks Class Initialized
DEBUG - 2024-06-21 23:20:53 --> UTF-8 Support Enabled
INFO - 2024-06-21 23:20:53 --> Utf8 Class Initialized
INFO - 2024-06-21 23:20:53 --> URI Class Initialized
INFO - 2024-06-21 23:20:53 --> Router Class Initialized
INFO - 2024-06-21 23:20:53 --> Output Class Initialized
INFO - 2024-06-21 23:20:53 --> Security Class Initialized
DEBUG - 2024-06-21 23:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 23:20:53 --> Input Class Initialized
INFO - 2024-06-21 23:20:53 --> Language Class Initialized
INFO - 2024-06-21 23:20:53 --> Language Class Initialized
INFO - 2024-06-21 23:20:53 --> Config Class Initialized
INFO - 2024-06-21 23:20:53 --> Loader Class Initialized
INFO - 2024-06-21 23:20:53 --> Helper loaded: url_helper
INFO - 2024-06-21 23:20:53 --> Helper loaded: file_helper
INFO - 2024-06-21 23:20:53 --> Helper loaded: form_helper
INFO - 2024-06-21 23:20:53 --> Helper loaded: my_helper
INFO - 2024-06-21 23:20:53 --> Database Driver Class Initialized
INFO - 2024-06-21 23:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 23:20:53 --> Controller Class Initialized
DEBUG - 2024-06-21 23:20:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-21 23:20:57 --> Final output sent to browser
DEBUG - 2024-06-21 23:20:57 --> Total execution time: 4.0795
INFO - 2024-06-21 23:20:58 --> Config Class Initialized
INFO - 2024-06-21 23:20:58 --> Hooks Class Initialized
DEBUG - 2024-06-21 23:20:58 --> UTF-8 Support Enabled
INFO - 2024-06-21 23:20:58 --> Utf8 Class Initialized
INFO - 2024-06-21 23:20:58 --> URI Class Initialized
INFO - 2024-06-21 23:20:58 --> Router Class Initialized
INFO - 2024-06-21 23:20:58 --> Output Class Initialized
INFO - 2024-06-21 23:20:58 --> Security Class Initialized
DEBUG - 2024-06-21 23:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 23:20:58 --> Input Class Initialized
INFO - 2024-06-21 23:20:58 --> Language Class Initialized
INFO - 2024-06-21 23:20:58 --> Language Class Initialized
INFO - 2024-06-21 23:20:58 --> Config Class Initialized
INFO - 2024-06-21 23:20:58 --> Loader Class Initialized
INFO - 2024-06-21 23:20:58 --> Helper loaded: url_helper
INFO - 2024-06-21 23:20:58 --> Helper loaded: file_helper
INFO - 2024-06-21 23:20:58 --> Helper loaded: form_helper
INFO - 2024-06-21 23:20:58 --> Helper loaded: my_helper
INFO - 2024-06-21 23:20:58 --> Database Driver Class Initialized
INFO - 2024-06-21 23:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 23:20:58 --> Controller Class Initialized
DEBUG - 2024-06-21 23:20:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-21 23:21:01 --> Config Class Initialized
INFO - 2024-06-21 23:21:01 --> Hooks Class Initialized
DEBUG - 2024-06-21 23:21:01 --> UTF-8 Support Enabled
INFO - 2024-06-21 23:21:01 --> Utf8 Class Initialized
INFO - 2024-06-21 23:21:01 --> URI Class Initialized
INFO - 2024-06-21 23:21:01 --> Router Class Initialized
INFO - 2024-06-21 23:21:01 --> Output Class Initialized
INFO - 2024-06-21 23:21:01 --> Security Class Initialized
DEBUG - 2024-06-21 23:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 23:21:01 --> Input Class Initialized
INFO - 2024-06-21 23:21:01 --> Language Class Initialized
INFO - 2024-06-21 23:21:02 --> Language Class Initialized
INFO - 2024-06-21 23:21:02 --> Config Class Initialized
INFO - 2024-06-21 23:21:02 --> Loader Class Initialized
INFO - 2024-06-21 23:21:02 --> Helper loaded: url_helper
INFO - 2024-06-21 23:21:02 --> Helper loaded: file_helper
INFO - 2024-06-21 23:21:02 --> Helper loaded: form_helper
INFO - 2024-06-21 23:21:02 --> Helper loaded: my_helper
INFO - 2024-06-21 23:21:02 --> Database Driver Class Initialized
INFO - 2024-06-21 23:21:03 --> Final output sent to browser
DEBUG - 2024-06-21 23:21:03 --> Total execution time: 5.0005
INFO - 2024-06-21 23:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 23:21:03 --> Controller Class Initialized
DEBUG - 2024-06-21 23:21:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-21 23:21:09 --> Final output sent to browser
DEBUG - 2024-06-21 23:21:09 --> Total execution time: 7.2639
INFO - 2024-06-21 23:21:09 --> Config Class Initialized
INFO - 2024-06-21 23:21:09 --> Hooks Class Initialized
DEBUG - 2024-06-21 23:21:09 --> UTF-8 Support Enabled
INFO - 2024-06-21 23:21:09 --> Utf8 Class Initialized
INFO - 2024-06-21 23:21:09 --> URI Class Initialized
INFO - 2024-06-21 23:21:09 --> Router Class Initialized
INFO - 2024-06-21 23:21:09 --> Output Class Initialized
INFO - 2024-06-21 23:21:09 --> Security Class Initialized
DEBUG - 2024-06-21 23:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-21 23:21:09 --> Input Class Initialized
INFO - 2024-06-21 23:21:09 --> Language Class Initialized
INFO - 2024-06-21 23:21:09 --> Language Class Initialized
INFO - 2024-06-21 23:21:09 --> Config Class Initialized
INFO - 2024-06-21 23:21:09 --> Loader Class Initialized
INFO - 2024-06-21 23:21:09 --> Helper loaded: url_helper
INFO - 2024-06-21 23:21:09 --> Helper loaded: file_helper
INFO - 2024-06-21 23:21:09 --> Helper loaded: form_helper
INFO - 2024-06-21 23:21:09 --> Helper loaded: my_helper
INFO - 2024-06-21 23:21:09 --> Database Driver Class Initialized
INFO - 2024-06-21 23:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-21 23:21:09 --> Controller Class Initialized
DEBUG - 2024-06-21 23:21:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-21 23:21:13 --> Final output sent to browser
DEBUG - 2024-06-21 23:21:13 --> Total execution time: 4.3385
