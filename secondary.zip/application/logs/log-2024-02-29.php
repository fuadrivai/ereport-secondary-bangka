<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-02-29 09:55:08 --> Config Class Initialized
INFO - 2024-02-29 09:55:08 --> Hooks Class Initialized
DEBUG - 2024-02-29 09:55:08 --> UTF-8 Support Enabled
INFO - 2024-02-29 09:55:08 --> Utf8 Class Initialized
INFO - 2024-02-29 09:55:08 --> URI Class Initialized
INFO - 2024-02-29 09:55:08 --> Router Class Initialized
INFO - 2024-02-29 09:55:08 --> Output Class Initialized
INFO - 2024-02-29 09:55:08 --> Security Class Initialized
DEBUG - 2024-02-29 09:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 09:55:08 --> Input Class Initialized
INFO - 2024-02-29 09:55:08 --> Language Class Initialized
INFO - 2024-02-29 09:55:08 --> Language Class Initialized
INFO - 2024-02-29 09:55:08 --> Config Class Initialized
INFO - 2024-02-29 09:55:08 --> Loader Class Initialized
INFO - 2024-02-29 09:55:08 --> Helper loaded: url_helper
INFO - 2024-02-29 09:55:08 --> Helper loaded: file_helper
INFO - 2024-02-29 09:55:08 --> Helper loaded: form_helper
INFO - 2024-02-29 09:55:08 --> Helper loaded: my_helper
INFO - 2024-02-29 09:55:08 --> Database Driver Class Initialized
INFO - 2024-02-29 09:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 09:55:08 --> Controller Class Initialized
DEBUG - 2024-02-29 09:55:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-02-29 09:55:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-02-29 09:55:08 --> Final output sent to browser
DEBUG - 2024-02-29 09:55:08 --> Total execution time: 0.0688
