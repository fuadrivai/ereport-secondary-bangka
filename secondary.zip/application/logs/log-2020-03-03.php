<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-03-03 01:34:22 --> Config Class Initialized
INFO - 2020-03-03 01:34:22 --> Hooks Class Initialized
DEBUG - 2020-03-03 01:34:22 --> UTF-8 Support Enabled
INFO - 2020-03-03 01:34:22 --> Utf8 Class Initialized
INFO - 2020-03-03 01:34:22 --> URI Class Initialized
DEBUG - 2020-03-03 01:34:22 --> No URI present. Default controller set.
INFO - 2020-03-03 01:34:22 --> Router Class Initialized
INFO - 2020-03-03 01:34:22 --> Output Class Initialized
INFO - 2020-03-03 01:34:23 --> Security Class Initialized
DEBUG - 2020-03-03 01:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 01:34:23 --> Input Class Initialized
INFO - 2020-03-03 01:34:23 --> Language Class Initialized
INFO - 2020-03-03 01:34:23 --> Language Class Initialized
INFO - 2020-03-03 01:34:23 --> Config Class Initialized
INFO - 2020-03-03 01:34:23 --> Loader Class Initialized
INFO - 2020-03-03 01:34:23 --> Helper loaded: url_helper
INFO - 2020-03-03 01:34:23 --> Helper loaded: file_helper
INFO - 2020-03-03 01:34:23 --> Helper loaded: form_helper
INFO - 2020-03-03 01:34:23 --> Helper loaded: my_helper
INFO - 2020-03-03 01:34:23 --> Database Driver Class Initialized
DEBUG - 2020-03-03 01:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 01:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 01:34:23 --> Controller Class Initialized
INFO - 2020-03-03 01:34:23 --> Config Class Initialized
INFO - 2020-03-03 01:34:23 --> Hooks Class Initialized
DEBUG - 2020-03-03 01:34:23 --> UTF-8 Support Enabled
INFO - 2020-03-03 01:34:23 --> Utf8 Class Initialized
INFO - 2020-03-03 01:34:23 --> URI Class Initialized
INFO - 2020-03-03 01:34:23 --> Router Class Initialized
INFO - 2020-03-03 01:34:23 --> Output Class Initialized
INFO - 2020-03-03 01:34:23 --> Security Class Initialized
DEBUG - 2020-03-03 01:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 01:34:23 --> Input Class Initialized
INFO - 2020-03-03 01:34:23 --> Language Class Initialized
INFO - 2020-03-03 01:34:23 --> Language Class Initialized
INFO - 2020-03-03 01:34:23 --> Config Class Initialized
INFO - 2020-03-03 01:34:23 --> Loader Class Initialized
INFO - 2020-03-03 01:34:23 --> Helper loaded: url_helper
INFO - 2020-03-03 01:34:23 --> Helper loaded: file_helper
INFO - 2020-03-03 01:34:23 --> Helper loaded: form_helper
INFO - 2020-03-03 01:34:23 --> Helper loaded: my_helper
INFO - 2020-03-03 01:34:23 --> Database Driver Class Initialized
DEBUG - 2020-03-03 01:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 01:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 01:34:23 --> Controller Class Initialized
DEBUG - 2020-03-03 01:34:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-03 01:34:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-03 01:34:24 --> Final output sent to browser
DEBUG - 2020-03-03 01:34:24 --> Total execution time: 0.3663
INFO - 2020-03-03 01:34:30 --> Config Class Initialized
INFO - 2020-03-03 01:34:30 --> Hooks Class Initialized
DEBUG - 2020-03-03 01:34:30 --> UTF-8 Support Enabled
INFO - 2020-03-03 01:34:30 --> Utf8 Class Initialized
INFO - 2020-03-03 01:34:30 --> URI Class Initialized
INFO - 2020-03-03 01:34:30 --> Router Class Initialized
INFO - 2020-03-03 01:34:30 --> Output Class Initialized
INFO - 2020-03-03 01:34:30 --> Security Class Initialized
DEBUG - 2020-03-03 01:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 01:34:30 --> Input Class Initialized
INFO - 2020-03-03 01:34:30 --> Language Class Initialized
INFO - 2020-03-03 01:34:30 --> Language Class Initialized
INFO - 2020-03-03 01:34:30 --> Config Class Initialized
INFO - 2020-03-03 01:34:30 --> Loader Class Initialized
INFO - 2020-03-03 01:34:30 --> Helper loaded: url_helper
INFO - 2020-03-03 01:34:30 --> Helper loaded: file_helper
INFO - 2020-03-03 01:34:30 --> Helper loaded: form_helper
INFO - 2020-03-03 01:34:30 --> Helper loaded: my_helper
INFO - 2020-03-03 01:34:30 --> Database Driver Class Initialized
DEBUG - 2020-03-03 01:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 01:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 01:34:30 --> Controller Class Initialized
INFO - 2020-03-03 01:34:30 --> Helper loaded: cookie_helper
INFO - 2020-03-03 01:34:30 --> Final output sent to browser
DEBUG - 2020-03-03 01:34:30 --> Total execution time: 0.4087
INFO - 2020-03-03 01:34:30 --> Config Class Initialized
INFO - 2020-03-03 01:34:30 --> Hooks Class Initialized
DEBUG - 2020-03-03 01:34:30 --> UTF-8 Support Enabled
INFO - 2020-03-03 01:34:30 --> Utf8 Class Initialized
INFO - 2020-03-03 01:34:30 --> URI Class Initialized
INFO - 2020-03-03 01:34:30 --> Router Class Initialized
INFO - 2020-03-03 01:34:30 --> Output Class Initialized
INFO - 2020-03-03 01:34:30 --> Security Class Initialized
DEBUG - 2020-03-03 01:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 01:34:30 --> Input Class Initialized
INFO - 2020-03-03 01:34:30 --> Language Class Initialized
INFO - 2020-03-03 01:34:30 --> Language Class Initialized
INFO - 2020-03-03 01:34:30 --> Config Class Initialized
INFO - 2020-03-03 01:34:30 --> Loader Class Initialized
INFO - 2020-03-03 01:34:30 --> Helper loaded: url_helper
INFO - 2020-03-03 01:34:30 --> Helper loaded: file_helper
INFO - 2020-03-03 01:34:30 --> Helper loaded: form_helper
INFO - 2020-03-03 01:34:31 --> Helper loaded: my_helper
INFO - 2020-03-03 01:34:31 --> Database Driver Class Initialized
DEBUG - 2020-03-03 01:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 01:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 01:34:31 --> Controller Class Initialized
DEBUG - 2020-03-03 01:34:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-03 01:34:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-03 01:34:31 --> Final output sent to browser
DEBUG - 2020-03-03 01:34:31 --> Total execution time: 0.5885
INFO - 2020-03-03 01:34:38 --> Config Class Initialized
INFO - 2020-03-03 01:34:38 --> Hooks Class Initialized
DEBUG - 2020-03-03 01:34:38 --> UTF-8 Support Enabled
INFO - 2020-03-03 01:34:38 --> Utf8 Class Initialized
INFO - 2020-03-03 01:34:38 --> URI Class Initialized
INFO - 2020-03-03 01:34:38 --> Router Class Initialized
INFO - 2020-03-03 01:34:38 --> Output Class Initialized
INFO - 2020-03-03 01:34:38 --> Security Class Initialized
DEBUG - 2020-03-03 01:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 01:34:38 --> Input Class Initialized
INFO - 2020-03-03 01:34:38 --> Language Class Initialized
INFO - 2020-03-03 01:34:38 --> Language Class Initialized
INFO - 2020-03-03 01:34:38 --> Config Class Initialized
INFO - 2020-03-03 01:34:38 --> Loader Class Initialized
INFO - 2020-03-03 01:34:38 --> Helper loaded: url_helper
INFO - 2020-03-03 01:34:38 --> Helper loaded: file_helper
INFO - 2020-03-03 01:34:38 --> Helper loaded: form_helper
INFO - 2020-03-03 01:34:38 --> Helper loaded: my_helper
INFO - 2020-03-03 01:34:38 --> Database Driver Class Initialized
DEBUG - 2020-03-03 01:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 01:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 01:34:38 --> Controller Class Initialized
DEBUG - 2020-03-03 01:34:38 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-03-03 01:34:38 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-03 01:34:38 --> Final output sent to browser
DEBUG - 2020-03-03 01:34:38 --> Total execution time: 0.3210
INFO - 2020-03-03 01:40:43 --> Config Class Initialized
INFO - 2020-03-03 01:40:43 --> Hooks Class Initialized
DEBUG - 2020-03-03 01:40:43 --> UTF-8 Support Enabled
INFO - 2020-03-03 01:40:43 --> Utf8 Class Initialized
INFO - 2020-03-03 01:40:43 --> URI Class Initialized
DEBUG - 2020-03-03 01:40:43 --> No URI present. Default controller set.
INFO - 2020-03-03 01:40:43 --> Router Class Initialized
INFO - 2020-03-03 01:40:43 --> Output Class Initialized
INFO - 2020-03-03 01:40:43 --> Security Class Initialized
DEBUG - 2020-03-03 01:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 01:40:43 --> Input Class Initialized
INFO - 2020-03-03 01:40:43 --> Language Class Initialized
INFO - 2020-03-03 01:40:43 --> Language Class Initialized
INFO - 2020-03-03 01:40:44 --> Config Class Initialized
INFO - 2020-03-03 01:40:44 --> Loader Class Initialized
INFO - 2020-03-03 01:40:44 --> Helper loaded: url_helper
INFO - 2020-03-03 01:40:44 --> Helper loaded: file_helper
INFO - 2020-03-03 01:40:44 --> Helper loaded: form_helper
INFO - 2020-03-03 01:40:44 --> Helper loaded: my_helper
INFO - 2020-03-03 01:40:44 --> Database Driver Class Initialized
DEBUG - 2020-03-03 01:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 01:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 01:40:44 --> Controller Class Initialized
DEBUG - 2020-03-03 01:40:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-03 01:40:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-03 01:40:44 --> Final output sent to browser
DEBUG - 2020-03-03 01:40:44 --> Total execution time: 0.3721
INFO - 2020-03-03 01:40:49 --> Config Class Initialized
INFO - 2020-03-03 01:40:49 --> Hooks Class Initialized
DEBUG - 2020-03-03 01:40:49 --> UTF-8 Support Enabled
INFO - 2020-03-03 01:40:49 --> Utf8 Class Initialized
INFO - 2020-03-03 01:40:49 --> URI Class Initialized
INFO - 2020-03-03 01:40:49 --> Router Class Initialized
INFO - 2020-03-03 01:40:49 --> Output Class Initialized
INFO - 2020-03-03 01:40:50 --> Security Class Initialized
DEBUG - 2020-03-03 01:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 01:40:50 --> Input Class Initialized
INFO - 2020-03-03 01:40:50 --> Language Class Initialized
INFO - 2020-03-03 01:40:50 --> Language Class Initialized
INFO - 2020-03-03 01:40:50 --> Config Class Initialized
INFO - 2020-03-03 01:40:50 --> Loader Class Initialized
INFO - 2020-03-03 01:40:50 --> Helper loaded: url_helper
INFO - 2020-03-03 01:40:50 --> Helper loaded: file_helper
INFO - 2020-03-03 01:40:50 --> Helper loaded: form_helper
INFO - 2020-03-03 01:40:50 --> Helper loaded: my_helper
INFO - 2020-03-03 01:40:50 --> Database Driver Class Initialized
DEBUG - 2020-03-03 01:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 01:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 01:40:50 --> Controller Class Initialized
DEBUG - 2020-03-03 01:40:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-03-03 01:40:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-03 01:40:50 --> Final output sent to browser
DEBUG - 2020-03-03 01:40:50 --> Total execution time: 0.4117
INFO - 2020-03-03 01:40:50 --> Config Class Initialized
INFO - 2020-03-03 01:40:50 --> Hooks Class Initialized
DEBUG - 2020-03-03 01:40:50 --> UTF-8 Support Enabled
INFO - 2020-03-03 01:40:50 --> Utf8 Class Initialized
INFO - 2020-03-03 01:40:50 --> URI Class Initialized
INFO - 2020-03-03 01:40:50 --> Router Class Initialized
INFO - 2020-03-03 01:40:50 --> Output Class Initialized
INFO - 2020-03-03 01:40:50 --> Security Class Initialized
DEBUG - 2020-03-03 01:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 01:40:50 --> Input Class Initialized
INFO - 2020-03-03 01:40:50 --> Language Class Initialized
INFO - 2020-03-03 01:40:50 --> Language Class Initialized
INFO - 2020-03-03 01:40:50 --> Config Class Initialized
INFO - 2020-03-03 01:40:50 --> Loader Class Initialized
INFO - 2020-03-03 01:40:50 --> Helper loaded: url_helper
INFO - 2020-03-03 01:40:50 --> Helper loaded: file_helper
INFO - 2020-03-03 01:40:50 --> Helper loaded: form_helper
INFO - 2020-03-03 01:40:50 --> Helper loaded: my_helper
INFO - 2020-03-03 01:40:50 --> Database Driver Class Initialized
DEBUG - 2020-03-03 01:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 01:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 01:40:50 --> Controller Class Initialized
INFO - 2020-03-03 01:40:52 --> Config Class Initialized
INFO - 2020-03-03 01:40:52 --> Hooks Class Initialized
DEBUG - 2020-03-03 01:40:52 --> UTF-8 Support Enabled
INFO - 2020-03-03 01:40:52 --> Utf8 Class Initialized
INFO - 2020-03-03 01:40:52 --> URI Class Initialized
INFO - 2020-03-03 01:40:52 --> Router Class Initialized
INFO - 2020-03-03 01:40:52 --> Output Class Initialized
INFO - 2020-03-03 01:40:52 --> Security Class Initialized
DEBUG - 2020-03-03 01:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 01:40:52 --> Input Class Initialized
INFO - 2020-03-03 01:40:52 --> Language Class Initialized
INFO - 2020-03-03 01:40:52 --> Language Class Initialized
INFO - 2020-03-03 01:40:52 --> Config Class Initialized
INFO - 2020-03-03 01:40:52 --> Loader Class Initialized
INFO - 2020-03-03 01:40:52 --> Helper loaded: url_helper
INFO - 2020-03-03 01:40:52 --> Helper loaded: file_helper
INFO - 2020-03-03 01:40:52 --> Helper loaded: form_helper
INFO - 2020-03-03 01:40:52 --> Helper loaded: my_helper
INFO - 2020-03-03 01:40:52 --> Database Driver Class Initialized
DEBUG - 2020-03-03 01:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 01:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 01:40:52 --> Controller Class Initialized
DEBUG - 2020-03-03 01:40:52 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/list.php
DEBUG - 2020-03-03 01:40:52 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-03 01:40:52 --> Final output sent to browser
DEBUG - 2020-03-03 01:40:52 --> Total execution time: 0.4256
INFO - 2020-03-03 01:40:53 --> Config Class Initialized
INFO - 2020-03-03 01:40:53 --> Hooks Class Initialized
DEBUG - 2020-03-03 01:40:53 --> UTF-8 Support Enabled
INFO - 2020-03-03 01:40:53 --> Utf8 Class Initialized
INFO - 2020-03-03 01:40:53 --> URI Class Initialized
INFO - 2020-03-03 01:40:53 --> Router Class Initialized
INFO - 2020-03-03 01:40:53 --> Output Class Initialized
INFO - 2020-03-03 01:40:53 --> Security Class Initialized
DEBUG - 2020-03-03 01:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 01:40:53 --> Input Class Initialized
INFO - 2020-03-03 01:40:53 --> Language Class Initialized
INFO - 2020-03-03 01:40:53 --> Language Class Initialized
INFO - 2020-03-03 01:40:53 --> Config Class Initialized
INFO - 2020-03-03 01:40:53 --> Loader Class Initialized
INFO - 2020-03-03 01:40:53 --> Helper loaded: url_helper
INFO - 2020-03-03 01:40:53 --> Helper loaded: file_helper
INFO - 2020-03-03 01:40:53 --> Helper loaded: form_helper
INFO - 2020-03-03 01:40:53 --> Helper loaded: my_helper
INFO - 2020-03-03 01:40:53 --> Database Driver Class Initialized
DEBUG - 2020-03-03 01:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 01:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 01:40:53 --> Controller Class Initialized
INFO - 2020-03-03 01:40:53 --> Config Class Initialized
INFO - 2020-03-03 01:40:53 --> Hooks Class Initialized
DEBUG - 2020-03-03 01:40:53 --> UTF-8 Support Enabled
INFO - 2020-03-03 01:40:53 --> Utf8 Class Initialized
INFO - 2020-03-03 01:40:53 --> URI Class Initialized
INFO - 2020-03-03 01:40:53 --> Router Class Initialized
INFO - 2020-03-03 01:40:53 --> Output Class Initialized
INFO - 2020-03-03 01:40:53 --> Security Class Initialized
DEBUG - 2020-03-03 01:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 01:40:53 --> Input Class Initialized
INFO - 2020-03-03 01:40:53 --> Language Class Initialized
INFO - 2020-03-03 01:40:53 --> Language Class Initialized
INFO - 2020-03-03 01:40:53 --> Config Class Initialized
INFO - 2020-03-03 01:40:53 --> Loader Class Initialized
INFO - 2020-03-03 01:40:53 --> Helper loaded: url_helper
INFO - 2020-03-03 01:40:53 --> Helper loaded: file_helper
INFO - 2020-03-03 01:40:53 --> Helper loaded: form_helper
INFO - 2020-03-03 01:40:54 --> Helper loaded: my_helper
INFO - 2020-03-03 01:40:54 --> Database Driver Class Initialized
DEBUG - 2020-03-03 01:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 01:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 01:40:54 --> Controller Class Initialized
DEBUG - 2020-03-03 01:40:54 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-03-03 01:40:54 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-03 01:40:54 --> Final output sent to browser
DEBUG - 2020-03-03 01:40:54 --> Total execution time: 0.4470
INFO - 2020-03-03 01:40:54 --> Config Class Initialized
INFO - 2020-03-03 01:40:54 --> Hooks Class Initialized
DEBUG - 2020-03-03 01:40:54 --> UTF-8 Support Enabled
INFO - 2020-03-03 01:40:54 --> Utf8 Class Initialized
INFO - 2020-03-03 01:40:54 --> URI Class Initialized
INFO - 2020-03-03 01:40:54 --> Router Class Initialized
INFO - 2020-03-03 01:40:54 --> Output Class Initialized
INFO - 2020-03-03 01:40:54 --> Security Class Initialized
DEBUG - 2020-03-03 01:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 01:40:54 --> Input Class Initialized
INFO - 2020-03-03 01:40:54 --> Language Class Initialized
INFO - 2020-03-03 01:40:54 --> Language Class Initialized
INFO - 2020-03-03 01:40:54 --> Config Class Initialized
INFO - 2020-03-03 01:40:54 --> Loader Class Initialized
INFO - 2020-03-03 01:40:54 --> Helper loaded: url_helper
INFO - 2020-03-03 01:40:54 --> Helper loaded: file_helper
INFO - 2020-03-03 01:40:54 --> Helper loaded: form_helper
INFO - 2020-03-03 01:40:54 --> Helper loaded: my_helper
INFO - 2020-03-03 01:40:54 --> Database Driver Class Initialized
DEBUG - 2020-03-03 01:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 01:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 01:40:54 --> Controller Class Initialized
INFO - 2020-03-03 01:40:56 --> Config Class Initialized
INFO - 2020-03-03 01:40:56 --> Hooks Class Initialized
DEBUG - 2020-03-03 01:40:56 --> UTF-8 Support Enabled
INFO - 2020-03-03 01:40:56 --> Utf8 Class Initialized
INFO - 2020-03-03 01:40:56 --> URI Class Initialized
INFO - 2020-03-03 01:40:56 --> Router Class Initialized
INFO - 2020-03-03 01:40:56 --> Output Class Initialized
INFO - 2020-03-03 01:40:56 --> Security Class Initialized
DEBUG - 2020-03-03 01:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 01:40:56 --> Input Class Initialized
INFO - 2020-03-03 01:40:56 --> Language Class Initialized
INFO - 2020-03-03 01:40:56 --> Language Class Initialized
INFO - 2020-03-03 01:40:56 --> Config Class Initialized
INFO - 2020-03-03 01:40:56 --> Loader Class Initialized
INFO - 2020-03-03 01:40:56 --> Helper loaded: url_helper
INFO - 2020-03-03 01:40:56 --> Helper loaded: file_helper
INFO - 2020-03-03 01:40:56 --> Helper loaded: form_helper
INFO - 2020-03-03 01:40:56 --> Helper loaded: my_helper
INFO - 2020-03-03 01:40:56 --> Database Driver Class Initialized
DEBUG - 2020-03-03 01:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 01:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 01:40:56 --> Controller Class Initialized
INFO - 2020-03-03 01:40:56 --> Final output sent to browser
DEBUG - 2020-03-03 01:40:56 --> Total execution time: 0.3278
INFO - 2020-03-03 01:40:59 --> Config Class Initialized
INFO - 2020-03-03 01:40:59 --> Hooks Class Initialized
DEBUG - 2020-03-03 01:40:59 --> UTF-8 Support Enabled
INFO - 2020-03-03 01:40:59 --> Utf8 Class Initialized
INFO - 2020-03-03 01:40:59 --> URI Class Initialized
INFO - 2020-03-03 01:40:59 --> Router Class Initialized
INFO - 2020-03-03 01:40:59 --> Output Class Initialized
INFO - 2020-03-03 01:40:59 --> Security Class Initialized
DEBUG - 2020-03-03 01:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 01:40:59 --> Input Class Initialized
INFO - 2020-03-03 01:40:59 --> Language Class Initialized
INFO - 2020-03-03 01:40:59 --> Language Class Initialized
INFO - 2020-03-03 01:40:59 --> Config Class Initialized
INFO - 2020-03-03 01:40:59 --> Loader Class Initialized
INFO - 2020-03-03 01:40:59 --> Helper loaded: url_helper
INFO - 2020-03-03 01:40:59 --> Helper loaded: file_helper
INFO - 2020-03-03 01:40:59 --> Helper loaded: form_helper
INFO - 2020-03-03 01:40:59 --> Helper loaded: my_helper
INFO - 2020-03-03 01:40:59 --> Database Driver Class Initialized
DEBUG - 2020-03-03 01:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 01:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 01:40:59 --> Controller Class Initialized
INFO - 2020-03-03 01:40:59 --> Final output sent to browser
DEBUG - 2020-03-03 01:40:59 --> Total execution time: 0.3263
INFO - 2020-03-03 01:40:59 --> Config Class Initialized
INFO - 2020-03-03 01:40:59 --> Hooks Class Initialized
DEBUG - 2020-03-03 01:40:59 --> UTF-8 Support Enabled
INFO - 2020-03-03 01:40:59 --> Utf8 Class Initialized
INFO - 2020-03-03 01:40:59 --> URI Class Initialized
INFO - 2020-03-03 01:40:59 --> Router Class Initialized
INFO - 2020-03-03 01:40:59 --> Output Class Initialized
INFO - 2020-03-03 01:40:59 --> Security Class Initialized
DEBUG - 2020-03-03 01:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 01:40:59 --> Input Class Initialized
INFO - 2020-03-03 01:40:59 --> Language Class Initialized
INFO - 2020-03-03 01:40:59 --> Language Class Initialized
INFO - 2020-03-03 01:40:59 --> Config Class Initialized
INFO - 2020-03-03 01:40:59 --> Loader Class Initialized
INFO - 2020-03-03 01:40:59 --> Helper loaded: url_helper
INFO - 2020-03-03 01:40:59 --> Helper loaded: file_helper
INFO - 2020-03-03 01:40:59 --> Helper loaded: form_helper
INFO - 2020-03-03 01:40:59 --> Helper loaded: my_helper
INFO - 2020-03-03 01:40:59 --> Database Driver Class Initialized
DEBUG - 2020-03-03 01:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 01:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 01:40:59 --> Controller Class Initialized
INFO - 2020-03-03 01:41:01 --> Config Class Initialized
INFO - 2020-03-03 01:41:01 --> Hooks Class Initialized
DEBUG - 2020-03-03 01:41:01 --> UTF-8 Support Enabled
INFO - 2020-03-03 01:41:01 --> Utf8 Class Initialized
INFO - 2020-03-03 01:41:01 --> URI Class Initialized
INFO - 2020-03-03 01:41:01 --> Router Class Initialized
INFO - 2020-03-03 01:41:01 --> Output Class Initialized
INFO - 2020-03-03 01:41:01 --> Security Class Initialized
DEBUG - 2020-03-03 01:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 01:41:01 --> Input Class Initialized
INFO - 2020-03-03 01:41:01 --> Language Class Initialized
INFO - 2020-03-03 01:41:01 --> Language Class Initialized
INFO - 2020-03-03 01:41:01 --> Config Class Initialized
INFO - 2020-03-03 01:41:01 --> Loader Class Initialized
INFO - 2020-03-03 01:41:01 --> Helper loaded: url_helper
INFO - 2020-03-03 01:41:01 --> Helper loaded: file_helper
INFO - 2020-03-03 01:41:01 --> Helper loaded: form_helper
INFO - 2020-03-03 01:41:01 --> Helper loaded: my_helper
INFO - 2020-03-03 01:41:01 --> Database Driver Class Initialized
DEBUG - 2020-03-03 01:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 01:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 01:41:01 --> Controller Class Initialized
INFO - 2020-03-03 01:41:01 --> Final output sent to browser
DEBUG - 2020-03-03 01:41:01 --> Total execution time: 0.3865
INFO - 2020-03-03 01:41:06 --> Config Class Initialized
INFO - 2020-03-03 01:41:06 --> Hooks Class Initialized
DEBUG - 2020-03-03 01:41:06 --> UTF-8 Support Enabled
INFO - 2020-03-03 01:41:06 --> Utf8 Class Initialized
INFO - 2020-03-03 01:41:06 --> URI Class Initialized
INFO - 2020-03-03 01:41:06 --> Router Class Initialized
INFO - 2020-03-03 01:41:06 --> Output Class Initialized
INFO - 2020-03-03 01:41:06 --> Security Class Initialized
DEBUG - 2020-03-03 01:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 01:41:06 --> Input Class Initialized
INFO - 2020-03-03 01:41:06 --> Language Class Initialized
INFO - 2020-03-03 01:41:06 --> Language Class Initialized
INFO - 2020-03-03 01:41:06 --> Config Class Initialized
INFO - 2020-03-03 01:41:06 --> Loader Class Initialized
INFO - 2020-03-03 01:41:06 --> Helper loaded: url_helper
INFO - 2020-03-03 01:41:06 --> Helper loaded: file_helper
INFO - 2020-03-03 01:41:06 --> Helper loaded: form_helper
INFO - 2020-03-03 01:41:06 --> Helper loaded: my_helper
INFO - 2020-03-03 01:41:06 --> Database Driver Class Initialized
DEBUG - 2020-03-03 01:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 01:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 01:41:06 --> Controller Class Initialized
INFO - 2020-03-03 01:41:06 --> Final output sent to browser
DEBUG - 2020-03-03 01:41:06 --> Total execution time: 0.3219
INFO - 2020-03-03 01:41:06 --> Config Class Initialized
INFO - 2020-03-03 01:41:06 --> Hooks Class Initialized
DEBUG - 2020-03-03 01:41:06 --> UTF-8 Support Enabled
INFO - 2020-03-03 01:41:06 --> Utf8 Class Initialized
INFO - 2020-03-03 01:41:06 --> URI Class Initialized
INFO - 2020-03-03 01:41:07 --> Router Class Initialized
INFO - 2020-03-03 01:41:07 --> Output Class Initialized
INFO - 2020-03-03 01:41:07 --> Security Class Initialized
DEBUG - 2020-03-03 01:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 01:41:07 --> Input Class Initialized
INFO - 2020-03-03 01:41:07 --> Language Class Initialized
INFO - 2020-03-03 01:41:07 --> Language Class Initialized
INFO - 2020-03-03 01:41:07 --> Config Class Initialized
INFO - 2020-03-03 01:41:07 --> Loader Class Initialized
INFO - 2020-03-03 01:41:07 --> Helper loaded: url_helper
INFO - 2020-03-03 01:41:07 --> Helper loaded: file_helper
INFO - 2020-03-03 01:41:07 --> Helper loaded: form_helper
INFO - 2020-03-03 01:41:07 --> Helper loaded: my_helper
INFO - 2020-03-03 01:41:07 --> Database Driver Class Initialized
DEBUG - 2020-03-03 01:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 01:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 01:41:07 --> Controller Class Initialized
INFO - 2020-03-03 02:34:35 --> Config Class Initialized
INFO - 2020-03-03 02:34:35 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:34:35 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:34:35 --> Utf8 Class Initialized
INFO - 2020-03-03 02:34:35 --> URI Class Initialized
DEBUG - 2020-03-03 02:34:35 --> No URI present. Default controller set.
INFO - 2020-03-03 02:34:35 --> Router Class Initialized
INFO - 2020-03-03 02:34:35 --> Output Class Initialized
INFO - 2020-03-03 02:34:35 --> Security Class Initialized
DEBUG - 2020-03-03 02:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:34:35 --> Input Class Initialized
INFO - 2020-03-03 02:34:35 --> Language Class Initialized
INFO - 2020-03-03 02:34:35 --> Language Class Initialized
INFO - 2020-03-03 02:34:35 --> Config Class Initialized
INFO - 2020-03-03 02:34:35 --> Loader Class Initialized
INFO - 2020-03-03 02:34:35 --> Helper loaded: url_helper
INFO - 2020-03-03 02:34:35 --> Helper loaded: file_helper
INFO - 2020-03-03 02:34:35 --> Helper loaded: form_helper
INFO - 2020-03-03 02:34:35 --> Helper loaded: my_helper
INFO - 2020-03-03 02:34:35 --> Database Driver Class Initialized
DEBUG - 2020-03-03 02:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 02:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 02:34:35 --> Controller Class Initialized
DEBUG - 2020-03-03 02:34:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-03 02:34:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-03 02:34:35 --> Final output sent to browser
DEBUG - 2020-03-03 02:34:35 --> Total execution time: 0.3735
