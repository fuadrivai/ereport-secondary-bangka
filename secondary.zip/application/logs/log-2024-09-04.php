<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-04 09:56:58 --> Config Class Initialized
INFO - 2024-09-04 09:56:58 --> Hooks Class Initialized
DEBUG - 2024-09-04 09:56:58 --> UTF-8 Support Enabled
INFO - 2024-09-04 09:56:58 --> Utf8 Class Initialized
INFO - 2024-09-04 09:56:58 --> URI Class Initialized
INFO - 2024-09-04 09:56:58 --> Router Class Initialized
INFO - 2024-09-04 09:56:58 --> Output Class Initialized
INFO - 2024-09-04 09:56:58 --> Security Class Initialized
DEBUG - 2024-09-04 09:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 09:56:58 --> Input Class Initialized
INFO - 2024-09-04 09:56:58 --> Language Class Initialized
INFO - 2024-09-04 09:56:58 --> Language Class Initialized
INFO - 2024-09-04 09:56:58 --> Config Class Initialized
INFO - 2024-09-04 09:56:58 --> Loader Class Initialized
INFO - 2024-09-04 09:56:58 --> Helper loaded: url_helper
INFO - 2024-09-04 09:56:58 --> Helper loaded: file_helper
INFO - 2024-09-04 09:56:58 --> Helper loaded: form_helper
INFO - 2024-09-04 09:56:58 --> Helper loaded: my_helper
INFO - 2024-09-04 09:56:58 --> Database Driver Class Initialized
INFO - 2024-09-04 09:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 09:56:58 --> Controller Class Initialized
INFO - 2024-09-04 09:56:58 --> Helper loaded: cookie_helper
INFO - 2024-09-04 09:56:58 --> Final output sent to browser
DEBUG - 2024-09-04 09:56:58 --> Total execution time: 0.0572
INFO - 2024-09-04 09:56:59 --> Config Class Initialized
INFO - 2024-09-04 09:56:59 --> Hooks Class Initialized
DEBUG - 2024-09-04 09:56:59 --> UTF-8 Support Enabled
INFO - 2024-09-04 09:56:59 --> Utf8 Class Initialized
INFO - 2024-09-04 09:56:59 --> URI Class Initialized
INFO - 2024-09-04 09:56:59 --> Router Class Initialized
INFO - 2024-09-04 09:56:59 --> Output Class Initialized
INFO - 2024-09-04 09:56:59 --> Security Class Initialized
DEBUG - 2024-09-04 09:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 09:56:59 --> Input Class Initialized
INFO - 2024-09-04 09:56:59 --> Language Class Initialized
INFO - 2024-09-04 09:56:59 --> Language Class Initialized
INFO - 2024-09-04 09:56:59 --> Config Class Initialized
INFO - 2024-09-04 09:56:59 --> Loader Class Initialized
INFO - 2024-09-04 09:56:59 --> Helper loaded: url_helper
INFO - 2024-09-04 09:56:59 --> Helper loaded: file_helper
INFO - 2024-09-04 09:56:59 --> Helper loaded: form_helper
INFO - 2024-09-04 09:56:59 --> Helper loaded: my_helper
INFO - 2024-09-04 09:56:59 --> Database Driver Class Initialized
INFO - 2024-09-04 09:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 09:56:59 --> Controller Class Initialized
INFO - 2024-09-04 09:56:59 --> Helper loaded: cookie_helper
INFO - 2024-09-04 09:56:59 --> Config Class Initialized
INFO - 2024-09-04 09:56:59 --> Hooks Class Initialized
DEBUG - 2024-09-04 09:56:59 --> UTF-8 Support Enabled
INFO - 2024-09-04 09:56:59 --> Utf8 Class Initialized
INFO - 2024-09-04 09:56:59 --> URI Class Initialized
INFO - 2024-09-04 09:56:59 --> Router Class Initialized
INFO - 2024-09-04 09:56:59 --> Output Class Initialized
INFO - 2024-09-04 09:56:59 --> Security Class Initialized
DEBUG - 2024-09-04 09:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 09:56:59 --> Input Class Initialized
INFO - 2024-09-04 09:56:59 --> Language Class Initialized
INFO - 2024-09-04 09:56:59 --> Language Class Initialized
INFO - 2024-09-04 09:56:59 --> Config Class Initialized
INFO - 2024-09-04 09:56:59 --> Loader Class Initialized
INFO - 2024-09-04 09:56:59 --> Helper loaded: url_helper
INFO - 2024-09-04 09:56:59 --> Helper loaded: file_helper
INFO - 2024-09-04 09:56:59 --> Helper loaded: form_helper
INFO - 2024-09-04 09:56:59 --> Helper loaded: my_helper
INFO - 2024-09-04 09:56:59 --> Database Driver Class Initialized
INFO - 2024-09-04 09:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 09:56:59 --> Controller Class Initialized
DEBUG - 2024-09-04 09:56:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-04 09:56:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-04 09:56:59 --> Final output sent to browser
DEBUG - 2024-09-04 09:56:59 --> Total execution time: 0.0384
INFO - 2024-09-04 09:57:09 --> Config Class Initialized
INFO - 2024-09-04 09:57:09 --> Hooks Class Initialized
DEBUG - 2024-09-04 09:57:09 --> UTF-8 Support Enabled
INFO - 2024-09-04 09:57:09 --> Utf8 Class Initialized
INFO - 2024-09-04 09:57:09 --> URI Class Initialized
INFO - 2024-09-04 09:57:09 --> Router Class Initialized
INFO - 2024-09-04 09:57:09 --> Output Class Initialized
INFO - 2024-09-04 09:57:09 --> Security Class Initialized
DEBUG - 2024-09-04 09:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 09:57:09 --> Input Class Initialized
INFO - 2024-09-04 09:57:09 --> Language Class Initialized
INFO - 2024-09-04 09:57:09 --> Language Class Initialized
INFO - 2024-09-04 09:57:09 --> Config Class Initialized
INFO - 2024-09-04 09:57:09 --> Loader Class Initialized
INFO - 2024-09-04 09:57:09 --> Helper loaded: url_helper
INFO - 2024-09-04 09:57:09 --> Helper loaded: file_helper
INFO - 2024-09-04 09:57:09 --> Helper loaded: form_helper
INFO - 2024-09-04 09:57:09 --> Helper loaded: my_helper
INFO - 2024-09-04 09:57:09 --> Database Driver Class Initialized
INFO - 2024-09-04 09:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 09:57:09 --> Controller Class Initialized
ERROR - 2024-09-04 09:57:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-04 09:57:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-04 09:57:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-04 09:57:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-04 09:57:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-04 09:57:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-04 09:57:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-04 09:57:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-04 09:57:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-04 09:57:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-04 09:57:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-04 09:57:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-04 09:57:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-04 09:57:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-04 09:57:11 --> Config Class Initialized
INFO - 2024-09-04 09:57:11 --> Hooks Class Initialized
DEBUG - 2024-09-04 09:57:11 --> UTF-8 Support Enabled
INFO - 2024-09-04 09:57:11 --> Utf8 Class Initialized
INFO - 2024-09-04 09:57:11 --> URI Class Initialized
INFO - 2024-09-04 09:57:11 --> Router Class Initialized
INFO - 2024-09-04 09:57:11 --> Output Class Initialized
INFO - 2024-09-04 09:57:11 --> Security Class Initialized
DEBUG - 2024-09-04 09:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 09:57:11 --> Input Class Initialized
INFO - 2024-09-04 09:57:11 --> Language Class Initialized
INFO - 2024-09-04 09:57:11 --> Language Class Initialized
INFO - 2024-09-04 09:57:11 --> Config Class Initialized
INFO - 2024-09-04 09:57:11 --> Loader Class Initialized
INFO - 2024-09-04 09:57:11 --> Helper loaded: url_helper
INFO - 2024-09-04 09:57:11 --> Helper loaded: file_helper
INFO - 2024-09-04 09:57:11 --> Helper loaded: form_helper
INFO - 2024-09-04 09:57:11 --> Helper loaded: my_helper
INFO - 2024-09-04 09:57:11 --> Database Driver Class Initialized
INFO - 2024-09-04 09:57:12 --> Final output sent to browser
DEBUG - 2024-09-04 09:57:12 --> Total execution time: 2.9465
INFO - 2024-09-04 09:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 09:57:12 --> Controller Class Initialized
ERROR - 2024-09-04 09:57:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-04 09:57:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-04 09:57:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-04 09:57:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-04 09:57:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-04 09:57:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-04 09:57:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-04 09:57:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-04 09:57:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-04 09:57:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-04 09:57:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-04 09:57:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-04 09:57:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-04 09:57:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-04 09:57:15 --> Config Class Initialized
INFO - 2024-09-04 09:57:15 --> Hooks Class Initialized
DEBUG - 2024-09-04 09:57:15 --> UTF-8 Support Enabled
INFO - 2024-09-04 09:57:15 --> Utf8 Class Initialized
INFO - 2024-09-04 09:57:15 --> URI Class Initialized
INFO - 2024-09-04 09:57:15 --> Router Class Initialized
INFO - 2024-09-04 09:57:15 --> Output Class Initialized
INFO - 2024-09-04 09:57:15 --> Security Class Initialized
DEBUG - 2024-09-04 09:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 09:57:15 --> Input Class Initialized
INFO - 2024-09-04 09:57:15 --> Language Class Initialized
INFO - 2024-09-04 09:57:15 --> Language Class Initialized
INFO - 2024-09-04 09:57:15 --> Config Class Initialized
INFO - 2024-09-04 09:57:15 --> Loader Class Initialized
INFO - 2024-09-04 09:57:16 --> Helper loaded: url_helper
INFO - 2024-09-04 09:57:16 --> Helper loaded: file_helper
INFO - 2024-09-04 09:57:16 --> Helper loaded: form_helper
INFO - 2024-09-04 09:57:16 --> Helper loaded: my_helper
INFO - 2024-09-04 09:57:16 --> Database Driver Class Initialized
INFO - 2024-09-04 09:57:16 --> Final output sent to browser
DEBUG - 2024-09-04 09:57:16 --> Total execution time: 4.4135
INFO - 2024-09-04 09:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 09:57:16 --> Controller Class Initialized
ERROR - 2024-09-04 09:57:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-09-04 09:57:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-04 09:57:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-04 09:57:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-09-04 09:57:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-04 09:57:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-04 09:57:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-09-04 09:57:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-09-04 09:57:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-04 09:57:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-04 09:57:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-09-04 09:57:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-04 09:57:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-04 09:57:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-09-04 09:57:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-04 09:57:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-04 09:57:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-09-04 09:57:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-09-04 09:57:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-09-04 09:57:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-09-04 09:57:19 --> Final output sent to browser
DEBUG - 2024-09-04 09:57:19 --> Total execution time: 4.1801
INFO - 2024-09-04 09:57:19 --> Config Class Initialized
INFO - 2024-09-04 09:57:19 --> Hooks Class Initialized
DEBUG - 2024-09-04 09:57:19 --> UTF-8 Support Enabled
INFO - 2024-09-04 09:57:19 --> Utf8 Class Initialized
INFO - 2024-09-04 09:57:19 --> URI Class Initialized
INFO - 2024-09-04 09:57:19 --> Router Class Initialized
INFO - 2024-09-04 09:57:19 --> Output Class Initialized
INFO - 2024-09-04 09:57:19 --> Security Class Initialized
DEBUG - 2024-09-04 09:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 09:57:19 --> Input Class Initialized
INFO - 2024-09-04 09:57:19 --> Language Class Initialized
INFO - 2024-09-04 09:57:19 --> Language Class Initialized
INFO - 2024-09-04 09:57:19 --> Config Class Initialized
INFO - 2024-09-04 09:57:19 --> Loader Class Initialized
INFO - 2024-09-04 09:57:19 --> Helper loaded: url_helper
INFO - 2024-09-04 09:57:19 --> Helper loaded: file_helper
INFO - 2024-09-04 09:57:19 --> Helper loaded: form_helper
INFO - 2024-09-04 09:57:19 --> Helper loaded: my_helper
INFO - 2024-09-04 09:57:19 --> Database Driver Class Initialized
INFO - 2024-09-04 09:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 09:57:19 --> Controller Class Initialized
ERROR - 2024-09-04 09:57:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-09-04 09:57:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-04 09:57:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-04 09:57:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-09-04 09:57:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-04 09:57:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-04 09:57:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-09-04 09:57:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-09-04 09:57:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-04 09:57:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-04 09:57:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-09-04 09:57:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-04 09:57:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-04 09:57:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-09-04 09:57:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-04 09:57:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-04 09:57:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-09-04 09:57:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-09-04 09:57:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-09-04 09:57:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-09-04 09:57:23 --> Final output sent to browser
DEBUG - 2024-09-04 09:57:23 --> Total execution time: 3.6076
INFO - 2024-09-04 09:57:23 --> Config Class Initialized
INFO - 2024-09-04 09:57:23 --> Hooks Class Initialized
DEBUG - 2024-09-04 09:57:23 --> UTF-8 Support Enabled
INFO - 2024-09-04 09:57:23 --> Utf8 Class Initialized
INFO - 2024-09-04 09:57:23 --> URI Class Initialized
INFO - 2024-09-04 09:57:23 --> Router Class Initialized
INFO - 2024-09-04 09:57:23 --> Output Class Initialized
INFO - 2024-09-04 09:57:23 --> Security Class Initialized
DEBUG - 2024-09-04 09:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 09:57:23 --> Input Class Initialized
INFO - 2024-09-04 09:57:23 --> Language Class Initialized
INFO - 2024-09-04 09:57:23 --> Language Class Initialized
INFO - 2024-09-04 09:57:23 --> Config Class Initialized
INFO - 2024-09-04 09:57:23 --> Loader Class Initialized
INFO - 2024-09-04 09:57:23 --> Helper loaded: url_helper
INFO - 2024-09-04 09:57:23 --> Helper loaded: file_helper
INFO - 2024-09-04 09:57:23 --> Helper loaded: form_helper
INFO - 2024-09-04 09:57:23 --> Helper loaded: my_helper
INFO - 2024-09-04 09:57:23 --> Database Driver Class Initialized
INFO - 2024-09-04 09:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 09:57:23 --> Controller Class Initialized
ERROR - 2024-09-04 09:57:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-09-04 09:57:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-04 09:57:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-04 09:57:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-09-04 09:57:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-04 09:57:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-04 09:57:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-09-04 09:57:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-09-04 09:57:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-04 09:57:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-04 09:57:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-09-04 09:57:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-04 09:57:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-04 09:57:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-09-04 09:57:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-04 09:57:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-04 09:57:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-09-04 09:57:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-09-04 09:57:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-09-04 09:57:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-09-04 09:57:27 --> Final output sent to browser
DEBUG - 2024-09-04 09:57:27 --> Total execution time: 3.8130
INFO - 2024-09-04 09:57:27 --> Config Class Initialized
INFO - 2024-09-04 09:57:27 --> Hooks Class Initialized
DEBUG - 2024-09-04 09:57:27 --> UTF-8 Support Enabled
INFO - 2024-09-04 09:57:27 --> Utf8 Class Initialized
INFO - 2024-09-04 09:57:27 --> URI Class Initialized
INFO - 2024-09-04 09:57:27 --> Router Class Initialized
INFO - 2024-09-04 09:57:27 --> Output Class Initialized
INFO - 2024-09-04 09:57:27 --> Security Class Initialized
DEBUG - 2024-09-04 09:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 09:57:27 --> Input Class Initialized
INFO - 2024-09-04 09:57:27 --> Language Class Initialized
INFO - 2024-09-04 09:57:27 --> Language Class Initialized
INFO - 2024-09-04 09:57:27 --> Config Class Initialized
INFO - 2024-09-04 09:57:27 --> Loader Class Initialized
INFO - 2024-09-04 09:57:27 --> Helper loaded: url_helper
INFO - 2024-09-04 09:57:27 --> Helper loaded: file_helper
INFO - 2024-09-04 09:57:27 --> Helper loaded: form_helper
INFO - 2024-09-04 09:57:27 --> Helper loaded: my_helper
INFO - 2024-09-04 09:57:27 --> Database Driver Class Initialized
INFO - 2024-09-04 09:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 09:57:27 --> Controller Class Initialized
ERROR - 2024-09-04 09:57:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-09-04 09:57:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-04 09:57:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-04 09:57:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-09-04 09:57:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-04 09:57:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-04 09:57:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-09-04 09:57:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-09-04 09:57:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-04 09:57:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-04 09:57:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-09-04 09:57:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-04 09:57:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-04 09:57:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-09-04 09:57:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-04 09:57:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-04 09:57:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-09-04 09:57:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-09-04 09:57:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-09-04 09:57:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-09-04 09:57:29 --> Final output sent to browser
DEBUG - 2024-09-04 09:57:29 --> Total execution time: 2.7549
INFO - 2024-09-04 09:57:30 --> Config Class Initialized
INFO - 2024-09-04 09:57:30 --> Hooks Class Initialized
DEBUG - 2024-09-04 09:57:30 --> UTF-8 Support Enabled
INFO - 2024-09-04 09:57:30 --> Utf8 Class Initialized
INFO - 2024-09-04 09:57:30 --> URI Class Initialized
INFO - 2024-09-04 09:57:30 --> Router Class Initialized
INFO - 2024-09-04 09:57:30 --> Output Class Initialized
INFO - 2024-09-04 09:57:30 --> Security Class Initialized
DEBUG - 2024-09-04 09:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 09:57:30 --> Input Class Initialized
INFO - 2024-09-04 09:57:30 --> Language Class Initialized
INFO - 2024-09-04 09:57:30 --> Language Class Initialized
INFO - 2024-09-04 09:57:30 --> Config Class Initialized
INFO - 2024-09-04 09:57:30 --> Loader Class Initialized
INFO - 2024-09-04 09:57:30 --> Helper loaded: url_helper
INFO - 2024-09-04 09:57:30 --> Helper loaded: file_helper
INFO - 2024-09-04 09:57:30 --> Helper loaded: form_helper
INFO - 2024-09-04 09:57:30 --> Helper loaded: my_helper
INFO - 2024-09-04 09:57:30 --> Database Driver Class Initialized
INFO - 2024-09-04 09:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 09:57:30 --> Controller Class Initialized
ERROR - 2024-09-04 09:57:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-09-04 09:57:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-04 09:57:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-04 09:57:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-09-04 09:57:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-04 09:57:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-04 09:57:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-09-04 09:57:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-09-04 09:57:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-04 09:57:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-04 09:57:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-09-04 09:57:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-04 09:57:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-04 09:57:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-09-04 09:57:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-04 09:57:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-04 09:57:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-09-04 09:57:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-09-04 09:57:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-09-04 09:57:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-09-04 09:57:32 --> Final output sent to browser
DEBUG - 2024-09-04 09:57:32 --> Total execution time: 2.6009
INFO - 2024-09-04 09:57:32 --> Config Class Initialized
INFO - 2024-09-04 09:57:32 --> Hooks Class Initialized
DEBUG - 2024-09-04 09:57:32 --> UTF-8 Support Enabled
INFO - 2024-09-04 09:57:32 --> Utf8 Class Initialized
INFO - 2024-09-04 09:57:32 --> URI Class Initialized
INFO - 2024-09-04 09:57:32 --> Router Class Initialized
INFO - 2024-09-04 09:57:32 --> Output Class Initialized
INFO - 2024-09-04 09:57:32 --> Security Class Initialized
DEBUG - 2024-09-04 09:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 09:57:32 --> Input Class Initialized
INFO - 2024-09-04 09:57:32 --> Language Class Initialized
INFO - 2024-09-04 09:57:32 --> Language Class Initialized
INFO - 2024-09-04 09:57:32 --> Config Class Initialized
INFO - 2024-09-04 09:57:32 --> Loader Class Initialized
INFO - 2024-09-04 09:57:32 --> Helper loaded: url_helper
INFO - 2024-09-04 09:57:32 --> Helper loaded: file_helper
INFO - 2024-09-04 09:57:32 --> Helper loaded: form_helper
INFO - 2024-09-04 09:57:32 --> Helper loaded: my_helper
INFO - 2024-09-04 09:57:32 --> Database Driver Class Initialized
INFO - 2024-09-04 09:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 09:57:32 --> Controller Class Initialized
ERROR - 2024-09-04 09:57:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-09-04 09:57:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-04 09:57:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-04 09:57:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-09-04 09:57:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-04 09:57:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-04 09:57:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-09-04 09:57:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-09-04 09:57:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-04 09:57:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-04 09:57:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-09-04 09:57:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-04 09:57:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-04 09:57:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-09-04 09:57:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-04 09:57:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-04 09:57:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-09-04 09:57:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-09-04 09:57:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-09-04 09:57:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-09-04 09:57:35 --> Final output sent to browser
DEBUG - 2024-09-04 09:57:35 --> Total execution time: 2.6634
INFO - 2024-09-04 09:57:35 --> Config Class Initialized
INFO - 2024-09-04 09:57:35 --> Hooks Class Initialized
DEBUG - 2024-09-04 09:57:35 --> UTF-8 Support Enabled
INFO - 2024-09-04 09:57:35 --> Utf8 Class Initialized
INFO - 2024-09-04 09:57:35 --> URI Class Initialized
INFO - 2024-09-04 09:57:35 --> Router Class Initialized
INFO - 2024-09-04 09:57:35 --> Output Class Initialized
INFO - 2024-09-04 09:57:35 --> Security Class Initialized
DEBUG - 2024-09-04 09:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 09:57:35 --> Input Class Initialized
INFO - 2024-09-04 09:57:35 --> Language Class Initialized
INFO - 2024-09-04 09:57:35 --> Language Class Initialized
INFO - 2024-09-04 09:57:35 --> Config Class Initialized
INFO - 2024-09-04 09:57:35 --> Loader Class Initialized
INFO - 2024-09-04 09:57:35 --> Helper loaded: url_helper
INFO - 2024-09-04 09:57:35 --> Helper loaded: file_helper
INFO - 2024-09-04 09:57:35 --> Helper loaded: form_helper
INFO - 2024-09-04 09:57:35 --> Helper loaded: my_helper
INFO - 2024-09-04 09:57:35 --> Database Driver Class Initialized
INFO - 2024-09-04 09:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 09:57:35 --> Controller Class Initialized
ERROR - 2024-09-04 09:57:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-09-04 09:57:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-04 09:57:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-04 09:57:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-09-04 09:57:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-04 09:57:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-04 09:57:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-09-04 09:57:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-09-04 09:57:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-04 09:57:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-04 09:57:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-09-04 09:57:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-04 09:57:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-04 09:57:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-09-04 09:57:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-04 09:57:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-04 09:57:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-09-04 09:57:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-09-04 09:57:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-09-04 09:57:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-09-04 09:57:38 --> Final output sent to browser
DEBUG - 2024-09-04 09:57:38 --> Total execution time: 2.7116
INFO - 2024-09-04 09:57:38 --> Config Class Initialized
INFO - 2024-09-04 09:57:38 --> Hooks Class Initialized
DEBUG - 2024-09-04 09:57:38 --> UTF-8 Support Enabled
INFO - 2024-09-04 09:57:38 --> Utf8 Class Initialized
INFO - 2024-09-04 09:57:38 --> URI Class Initialized
INFO - 2024-09-04 09:57:38 --> Router Class Initialized
INFO - 2024-09-04 09:57:38 --> Output Class Initialized
INFO - 2024-09-04 09:57:38 --> Security Class Initialized
DEBUG - 2024-09-04 09:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 09:57:38 --> Input Class Initialized
INFO - 2024-09-04 09:57:38 --> Language Class Initialized
INFO - 2024-09-04 09:57:38 --> Language Class Initialized
INFO - 2024-09-04 09:57:38 --> Config Class Initialized
INFO - 2024-09-04 09:57:38 --> Loader Class Initialized
INFO - 2024-09-04 09:57:38 --> Helper loaded: url_helper
INFO - 2024-09-04 09:57:38 --> Helper loaded: file_helper
INFO - 2024-09-04 09:57:38 --> Helper loaded: form_helper
INFO - 2024-09-04 09:57:38 --> Helper loaded: my_helper
INFO - 2024-09-04 09:57:38 --> Database Driver Class Initialized
INFO - 2024-09-04 09:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 09:57:38 --> Controller Class Initialized
ERROR - 2024-09-04 09:57:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-09-04 09:57:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-04 09:57:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-04 09:57:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-09-04 09:57:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-04 09:57:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-04 09:57:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-09-04 09:57:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-09-04 09:57:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-04 09:57:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-04 09:57:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-09-04 09:57:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-04 09:57:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-04 09:57:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-09-04 09:57:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-04 09:57:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-04 09:57:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-09-04 09:57:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-09-04 09:57:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-09-04 09:57:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-09-04 09:57:40 --> Final output sent to browser
DEBUG - 2024-09-04 09:57:40 --> Total execution time: 2.4816
INFO - 2024-09-04 09:57:41 --> Config Class Initialized
INFO - 2024-09-04 09:57:41 --> Hooks Class Initialized
DEBUG - 2024-09-04 09:57:41 --> UTF-8 Support Enabled
INFO - 2024-09-04 09:57:41 --> Utf8 Class Initialized
INFO - 2024-09-04 09:57:41 --> URI Class Initialized
INFO - 2024-09-04 09:57:41 --> Router Class Initialized
INFO - 2024-09-04 09:57:41 --> Output Class Initialized
INFO - 2024-09-04 09:57:41 --> Security Class Initialized
DEBUG - 2024-09-04 09:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 09:57:41 --> Input Class Initialized
INFO - 2024-09-04 09:57:41 --> Language Class Initialized
INFO - 2024-09-04 09:57:41 --> Language Class Initialized
INFO - 2024-09-04 09:57:41 --> Config Class Initialized
INFO - 2024-09-04 09:57:41 --> Loader Class Initialized
INFO - 2024-09-04 09:57:41 --> Helper loaded: url_helper
INFO - 2024-09-04 09:57:41 --> Helper loaded: file_helper
INFO - 2024-09-04 09:57:41 --> Helper loaded: form_helper
INFO - 2024-09-04 09:57:41 --> Helper loaded: my_helper
INFO - 2024-09-04 09:57:41 --> Database Driver Class Initialized
INFO - 2024-09-04 09:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 09:57:41 --> Controller Class Initialized
ERROR - 2024-09-04 09:57:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-09-04 09:57:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-04 09:57:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-04 09:57:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-09-04 09:57:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-04 09:57:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-04 09:57:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-09-04 09:57:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-09-04 09:57:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-04 09:57:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-04 09:57:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-09-04 09:57:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-04 09:57:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-04 09:57:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-09-04 09:57:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-04 09:57:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-04 09:57:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-09-04 09:57:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-09-04 09:57:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-09-04 09:57:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-09-04 09:57:43 --> Final output sent to browser
DEBUG - 2024-09-04 09:57:43 --> Total execution time: 2.5260
INFO - 2024-09-04 09:57:43 --> Config Class Initialized
INFO - 2024-09-04 09:57:43 --> Hooks Class Initialized
DEBUG - 2024-09-04 09:57:43 --> UTF-8 Support Enabled
INFO - 2024-09-04 09:57:43 --> Utf8 Class Initialized
INFO - 2024-09-04 09:57:43 --> URI Class Initialized
INFO - 2024-09-04 09:57:43 --> Router Class Initialized
INFO - 2024-09-04 09:57:43 --> Output Class Initialized
INFO - 2024-09-04 09:57:43 --> Security Class Initialized
DEBUG - 2024-09-04 09:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 09:57:43 --> Input Class Initialized
INFO - 2024-09-04 09:57:43 --> Language Class Initialized
INFO - 2024-09-04 09:57:43 --> Language Class Initialized
INFO - 2024-09-04 09:57:43 --> Config Class Initialized
INFO - 2024-09-04 09:57:43 --> Loader Class Initialized
INFO - 2024-09-04 09:57:43 --> Helper loaded: url_helper
INFO - 2024-09-04 09:57:43 --> Helper loaded: file_helper
INFO - 2024-09-04 09:57:43 --> Helper loaded: form_helper
INFO - 2024-09-04 09:57:43 --> Helper loaded: my_helper
INFO - 2024-09-04 09:57:43 --> Database Driver Class Initialized
INFO - 2024-09-04 09:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 09:57:43 --> Controller Class Initialized
ERROR - 2024-09-04 09:57:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-09-04 09:57:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-04 09:57:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-04 09:57:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-09-04 09:57:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-04 09:57:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-04 09:57:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-09-04 09:57:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-09-04 09:57:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-04 09:57:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-04 09:57:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-09-04 09:57:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-04 09:57:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-04 09:57:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-09-04 09:57:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-04 09:57:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-04 09:57:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-09-04 09:57:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-09-04 09:57:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-09-04 09:57:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-09-04 09:57:46 --> Final output sent to browser
DEBUG - 2024-09-04 09:57:46 --> Total execution time: 2.6440
INFO - 2024-09-04 09:57:46 --> Config Class Initialized
INFO - 2024-09-04 09:57:46 --> Hooks Class Initialized
DEBUG - 2024-09-04 09:57:46 --> UTF-8 Support Enabled
INFO - 2024-09-04 09:57:46 --> Utf8 Class Initialized
INFO - 2024-09-04 09:57:46 --> URI Class Initialized
INFO - 2024-09-04 09:57:46 --> Router Class Initialized
INFO - 2024-09-04 09:57:46 --> Output Class Initialized
INFO - 2024-09-04 09:57:46 --> Security Class Initialized
DEBUG - 2024-09-04 09:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 09:57:46 --> Input Class Initialized
INFO - 2024-09-04 09:57:46 --> Language Class Initialized
INFO - 2024-09-04 09:57:46 --> Language Class Initialized
INFO - 2024-09-04 09:57:46 --> Config Class Initialized
INFO - 2024-09-04 09:57:46 --> Loader Class Initialized
INFO - 2024-09-04 09:57:46 --> Helper loaded: url_helper
INFO - 2024-09-04 09:57:46 --> Helper loaded: file_helper
INFO - 2024-09-04 09:57:46 --> Helper loaded: form_helper
INFO - 2024-09-04 09:57:46 --> Helper loaded: my_helper
INFO - 2024-09-04 09:57:46 --> Database Driver Class Initialized
INFO - 2024-09-04 09:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 09:57:46 --> Controller Class Initialized
ERROR - 2024-09-04 09:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-09-04 09:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-04 09:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-04 09:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-09-04 09:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-04 09:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-04 09:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-09-04 09:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-09-04 09:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-04 09:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-04 09:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-09-04 09:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-04 09:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-04 09:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-09-04 09:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-04 09:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-04 09:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-09-04 09:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-09-04 09:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-09-04 09:57:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-09-04 09:57:48 --> Final output sent to browser
DEBUG - 2024-09-04 09:57:48 --> Total execution time: 2.5538
INFO - 2024-09-04 09:57:49 --> Config Class Initialized
INFO - 2024-09-04 09:57:49 --> Hooks Class Initialized
DEBUG - 2024-09-04 09:57:49 --> UTF-8 Support Enabled
INFO - 2024-09-04 09:57:49 --> Utf8 Class Initialized
INFO - 2024-09-04 09:57:49 --> URI Class Initialized
INFO - 2024-09-04 09:57:49 --> Router Class Initialized
INFO - 2024-09-04 09:57:49 --> Output Class Initialized
INFO - 2024-09-04 09:57:49 --> Security Class Initialized
DEBUG - 2024-09-04 09:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 09:57:49 --> Input Class Initialized
INFO - 2024-09-04 09:57:49 --> Language Class Initialized
INFO - 2024-09-04 09:57:49 --> Language Class Initialized
INFO - 2024-09-04 09:57:49 --> Config Class Initialized
INFO - 2024-09-04 09:57:49 --> Loader Class Initialized
INFO - 2024-09-04 09:57:49 --> Helper loaded: url_helper
INFO - 2024-09-04 09:57:49 --> Helper loaded: file_helper
INFO - 2024-09-04 09:57:49 --> Helper loaded: form_helper
INFO - 2024-09-04 09:57:49 --> Helper loaded: my_helper
INFO - 2024-09-04 09:57:49 --> Database Driver Class Initialized
INFO - 2024-09-04 09:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 09:57:49 --> Controller Class Initialized
ERROR - 2024-09-04 09:57:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-09-04 09:57:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-04 09:57:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-04 09:57:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-09-04 09:57:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-04 09:57:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-04 09:57:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-09-04 09:57:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-09-04 09:57:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-04 09:57:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-04 09:57:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-09-04 09:57:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-04 09:57:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-04 09:57:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-09-04 09:57:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-04 09:57:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-04 09:57:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-09-04 09:57:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-09-04 09:57:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-09-04 09:57:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-09-04 09:57:51 --> Final output sent to browser
DEBUG - 2024-09-04 09:57:51 --> Total execution time: 2.5526
INFO - 2024-09-04 09:57:51 --> Config Class Initialized
INFO - 2024-09-04 09:57:51 --> Hooks Class Initialized
DEBUG - 2024-09-04 09:57:51 --> UTF-8 Support Enabled
INFO - 2024-09-04 09:57:51 --> Utf8 Class Initialized
INFO - 2024-09-04 09:57:51 --> URI Class Initialized
INFO - 2024-09-04 09:57:51 --> Router Class Initialized
INFO - 2024-09-04 09:57:51 --> Output Class Initialized
INFO - 2024-09-04 09:57:51 --> Security Class Initialized
DEBUG - 2024-09-04 09:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 09:57:51 --> Input Class Initialized
INFO - 2024-09-04 09:57:51 --> Language Class Initialized
INFO - 2024-09-04 09:57:51 --> Language Class Initialized
INFO - 2024-09-04 09:57:51 --> Config Class Initialized
INFO - 2024-09-04 09:57:51 --> Loader Class Initialized
INFO - 2024-09-04 09:57:51 --> Helper loaded: url_helper
INFO - 2024-09-04 09:57:51 --> Helper loaded: file_helper
INFO - 2024-09-04 09:57:51 --> Helper loaded: form_helper
INFO - 2024-09-04 09:57:51 --> Helper loaded: my_helper
INFO - 2024-09-04 09:57:51 --> Database Driver Class Initialized
INFO - 2024-09-04 09:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 09:57:51 --> Controller Class Initialized
ERROR - 2024-09-04 09:57:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-09-04 09:57:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-04 09:57:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-04 09:57:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-09-04 09:57:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-04 09:57:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-04 09:57:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-09-04 09:57:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-09-04 09:57:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-04 09:57:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-04 09:57:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-09-04 09:57:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-04 09:57:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-04 09:57:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-09-04 09:57:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-04 09:57:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-04 09:57:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-09-04 09:57:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-09-04 09:57:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-09-04 09:57:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-09-04 09:57:54 --> Final output sent to browser
DEBUG - 2024-09-04 09:57:54 --> Total execution time: 2.4315
INFO - 2024-09-04 09:57:54 --> Config Class Initialized
INFO - 2024-09-04 09:57:54 --> Hooks Class Initialized
DEBUG - 2024-09-04 09:57:54 --> UTF-8 Support Enabled
INFO - 2024-09-04 09:57:54 --> Utf8 Class Initialized
INFO - 2024-09-04 09:57:54 --> URI Class Initialized
INFO - 2024-09-04 09:57:54 --> Router Class Initialized
INFO - 2024-09-04 09:57:54 --> Output Class Initialized
INFO - 2024-09-04 09:57:54 --> Security Class Initialized
DEBUG - 2024-09-04 09:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 09:57:54 --> Input Class Initialized
INFO - 2024-09-04 09:57:54 --> Language Class Initialized
INFO - 2024-09-04 09:57:54 --> Language Class Initialized
INFO - 2024-09-04 09:57:54 --> Config Class Initialized
INFO - 2024-09-04 09:57:54 --> Loader Class Initialized
INFO - 2024-09-04 09:57:54 --> Helper loaded: url_helper
INFO - 2024-09-04 09:57:54 --> Helper loaded: file_helper
INFO - 2024-09-04 09:57:54 --> Helper loaded: form_helper
INFO - 2024-09-04 09:57:54 --> Helper loaded: my_helper
INFO - 2024-09-04 09:57:54 --> Database Driver Class Initialized
INFO - 2024-09-04 09:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 09:57:54 --> Controller Class Initialized
ERROR - 2024-09-04 09:57:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-09-04 09:57:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-04 09:57:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-04 09:57:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-09-04 09:57:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-04 09:57:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-04 09:57:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-09-04 09:57:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-09-04 09:57:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-04 09:57:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-04 09:57:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-09-04 09:57:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-04 09:57:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-04 09:57:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-09-04 09:57:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-04 09:57:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-04 09:57:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-09-04 09:57:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-09-04 09:57:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-09-04 09:57:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-09-04 09:57:56 --> Final output sent to browser
DEBUG - 2024-09-04 09:57:56 --> Total execution time: 2.5690
INFO - 2024-09-04 09:57:57 --> Config Class Initialized
INFO - 2024-09-04 09:57:57 --> Hooks Class Initialized
DEBUG - 2024-09-04 09:57:57 --> UTF-8 Support Enabled
INFO - 2024-09-04 09:57:57 --> Utf8 Class Initialized
INFO - 2024-09-04 09:57:57 --> URI Class Initialized
INFO - 2024-09-04 09:57:57 --> Router Class Initialized
INFO - 2024-09-04 09:57:57 --> Output Class Initialized
INFO - 2024-09-04 09:57:57 --> Security Class Initialized
DEBUG - 2024-09-04 09:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 09:57:57 --> Input Class Initialized
INFO - 2024-09-04 09:57:57 --> Language Class Initialized
INFO - 2024-09-04 09:57:57 --> Language Class Initialized
INFO - 2024-09-04 09:57:57 --> Config Class Initialized
INFO - 2024-09-04 09:57:57 --> Loader Class Initialized
INFO - 2024-09-04 09:57:57 --> Helper loaded: url_helper
INFO - 2024-09-04 09:57:57 --> Helper loaded: file_helper
INFO - 2024-09-04 09:57:57 --> Helper loaded: form_helper
INFO - 2024-09-04 09:57:57 --> Helper loaded: my_helper
INFO - 2024-09-04 09:57:57 --> Database Driver Class Initialized
INFO - 2024-09-04 09:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 09:57:57 --> Controller Class Initialized
ERROR - 2024-09-04 09:57:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-09-04 09:57:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-04 09:57:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-04 09:57:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-09-04 09:57:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-04 09:57:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-04 09:57:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-09-04 09:57:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-09-04 09:57:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-04 09:57:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-04 09:57:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-09-04 09:57:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-04 09:57:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-04 09:57:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-09-04 09:57:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-04 09:57:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-04 09:57:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-09-04 09:57:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-09-04 09:57:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-09-04 09:57:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-09-04 09:57:59 --> Final output sent to browser
DEBUG - 2024-09-04 09:57:59 --> Total execution time: 2.4309
INFO - 2024-09-04 09:57:59 --> Config Class Initialized
INFO - 2024-09-04 09:57:59 --> Hooks Class Initialized
DEBUG - 2024-09-04 09:57:59 --> UTF-8 Support Enabled
INFO - 2024-09-04 09:57:59 --> Utf8 Class Initialized
INFO - 2024-09-04 09:57:59 --> URI Class Initialized
INFO - 2024-09-04 09:57:59 --> Router Class Initialized
INFO - 2024-09-04 09:57:59 --> Output Class Initialized
INFO - 2024-09-04 09:57:59 --> Security Class Initialized
DEBUG - 2024-09-04 09:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 09:57:59 --> Input Class Initialized
INFO - 2024-09-04 09:57:59 --> Language Class Initialized
INFO - 2024-09-04 09:57:59 --> Language Class Initialized
INFO - 2024-09-04 09:57:59 --> Config Class Initialized
INFO - 2024-09-04 09:57:59 --> Loader Class Initialized
INFO - 2024-09-04 09:57:59 --> Helper loaded: url_helper
INFO - 2024-09-04 09:57:59 --> Helper loaded: file_helper
INFO - 2024-09-04 09:57:59 --> Helper loaded: form_helper
INFO - 2024-09-04 09:57:59 --> Helper loaded: my_helper
INFO - 2024-09-04 09:57:59 --> Database Driver Class Initialized
INFO - 2024-09-04 09:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 09:57:59 --> Controller Class Initialized
ERROR - 2024-09-04 09:57:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-09-04 09:57:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-04 09:57:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-04 09:57:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-09-04 09:57:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-04 09:57:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-04 09:57:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-09-04 09:57:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-09-04 09:57:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-04 09:57:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-04 09:57:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-09-04 09:57:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-04 09:57:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-04 09:57:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-09-04 09:57:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-04 09:57:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-04 09:57:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-09-04 09:57:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-09-04 09:57:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-09-04 09:57:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-09-04 09:58:02 --> Final output sent to browser
DEBUG - 2024-09-04 09:58:02 --> Total execution time: 3.0552
INFO - 2024-09-04 19:23:53 --> Config Class Initialized
INFO - 2024-09-04 19:23:53 --> Hooks Class Initialized
DEBUG - 2024-09-04 19:23:53 --> UTF-8 Support Enabled
INFO - 2024-09-04 19:23:53 --> Utf8 Class Initialized
INFO - 2024-09-04 19:23:53 --> URI Class Initialized
INFO - 2024-09-04 19:23:53 --> Router Class Initialized
INFO - 2024-09-04 19:23:53 --> Output Class Initialized
INFO - 2024-09-04 19:23:53 --> Security Class Initialized
DEBUG - 2024-09-04 19:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 19:23:53 --> Input Class Initialized
INFO - 2024-09-04 19:23:53 --> Language Class Initialized
INFO - 2024-09-04 19:23:53 --> Language Class Initialized
INFO - 2024-09-04 19:23:53 --> Config Class Initialized
INFO - 2024-09-04 19:23:53 --> Loader Class Initialized
INFO - 2024-09-04 19:23:53 --> Helper loaded: url_helper
INFO - 2024-09-04 19:23:53 --> Helper loaded: file_helper
INFO - 2024-09-04 19:23:53 --> Helper loaded: form_helper
INFO - 2024-09-04 19:23:53 --> Helper loaded: my_helper
INFO - 2024-09-04 19:23:53 --> Database Driver Class Initialized
INFO - 2024-09-04 19:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 19:23:53 --> Controller Class Initialized
INFO - 2024-09-04 19:23:53 --> Helper loaded: cookie_helper
INFO - 2024-09-04 19:23:53 --> Final output sent to browser
DEBUG - 2024-09-04 19:23:53 --> Total execution time: 0.0616
INFO - 2024-09-04 19:23:53 --> Config Class Initialized
INFO - 2024-09-04 19:23:53 --> Hooks Class Initialized
DEBUG - 2024-09-04 19:23:53 --> UTF-8 Support Enabled
INFO - 2024-09-04 19:23:53 --> Utf8 Class Initialized
INFO - 2024-09-04 19:23:53 --> URI Class Initialized
INFO - 2024-09-04 19:23:53 --> Router Class Initialized
INFO - 2024-09-04 19:23:53 --> Output Class Initialized
INFO - 2024-09-04 19:23:53 --> Security Class Initialized
DEBUG - 2024-09-04 19:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 19:23:53 --> Input Class Initialized
INFO - 2024-09-04 19:23:53 --> Language Class Initialized
INFO - 2024-09-04 19:23:53 --> Language Class Initialized
INFO - 2024-09-04 19:23:53 --> Config Class Initialized
INFO - 2024-09-04 19:23:53 --> Loader Class Initialized
INFO - 2024-09-04 19:23:53 --> Helper loaded: url_helper
INFO - 2024-09-04 19:23:53 --> Helper loaded: file_helper
INFO - 2024-09-04 19:23:53 --> Helper loaded: form_helper
INFO - 2024-09-04 19:23:53 --> Helper loaded: my_helper
INFO - 2024-09-04 19:23:53 --> Database Driver Class Initialized
INFO - 2024-09-04 19:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 19:23:53 --> Controller Class Initialized
INFO - 2024-09-04 19:23:53 --> Helper loaded: cookie_helper
INFO - 2024-09-04 19:23:53 --> Config Class Initialized
INFO - 2024-09-04 19:23:53 --> Hooks Class Initialized
DEBUG - 2024-09-04 19:23:53 --> UTF-8 Support Enabled
INFO - 2024-09-04 19:23:53 --> Utf8 Class Initialized
INFO - 2024-09-04 19:23:53 --> URI Class Initialized
INFO - 2024-09-04 19:23:53 --> Router Class Initialized
INFO - 2024-09-04 19:23:53 --> Output Class Initialized
INFO - 2024-09-04 19:23:53 --> Security Class Initialized
DEBUG - 2024-09-04 19:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 19:23:53 --> Input Class Initialized
INFO - 2024-09-04 19:23:53 --> Language Class Initialized
INFO - 2024-09-04 19:23:53 --> Language Class Initialized
INFO - 2024-09-04 19:23:53 --> Config Class Initialized
INFO - 2024-09-04 19:23:53 --> Loader Class Initialized
INFO - 2024-09-04 19:23:53 --> Helper loaded: url_helper
INFO - 2024-09-04 19:23:53 --> Helper loaded: file_helper
INFO - 2024-09-04 19:23:53 --> Helper loaded: form_helper
INFO - 2024-09-04 19:23:53 --> Helper loaded: my_helper
INFO - 2024-09-04 19:23:53 --> Database Driver Class Initialized
INFO - 2024-09-04 19:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 19:23:53 --> Controller Class Initialized
DEBUG - 2024-09-04 19:23:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-04 19:23:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-04 19:23:53 --> Final output sent to browser
DEBUG - 2024-09-04 19:23:53 --> Total execution time: 0.0414
INFO - 2024-09-04 19:24:09 --> Config Class Initialized
INFO - 2024-09-04 19:24:09 --> Hooks Class Initialized
DEBUG - 2024-09-04 19:24:09 --> UTF-8 Support Enabled
INFO - 2024-09-04 19:24:09 --> Utf8 Class Initialized
INFO - 2024-09-04 19:24:09 --> URI Class Initialized
INFO - 2024-09-04 19:24:09 --> Router Class Initialized
INFO - 2024-09-04 19:24:09 --> Output Class Initialized
INFO - 2024-09-04 19:24:09 --> Security Class Initialized
DEBUG - 2024-09-04 19:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 19:24:09 --> Input Class Initialized
INFO - 2024-09-04 19:24:09 --> Language Class Initialized
INFO - 2024-09-04 19:24:09 --> Language Class Initialized
INFO - 2024-09-04 19:24:09 --> Config Class Initialized
INFO - 2024-09-04 19:24:09 --> Loader Class Initialized
INFO - 2024-09-04 19:24:09 --> Helper loaded: url_helper
INFO - 2024-09-04 19:24:09 --> Helper loaded: file_helper
INFO - 2024-09-04 19:24:09 --> Helper loaded: form_helper
INFO - 2024-09-04 19:24:09 --> Helper loaded: my_helper
INFO - 2024-09-04 19:24:09 --> Database Driver Class Initialized
INFO - 2024-09-04 19:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 19:24:09 --> Controller Class Initialized
INFO - 2024-09-04 19:24:09 --> Helper loaded: cookie_helper
INFO - 2024-09-04 19:24:09 --> Final output sent to browser
DEBUG - 2024-09-04 19:24:09 --> Total execution time: 0.0433
INFO - 2024-09-04 19:24:10 --> Config Class Initialized
INFO - 2024-09-04 19:24:10 --> Hooks Class Initialized
DEBUG - 2024-09-04 19:24:10 --> UTF-8 Support Enabled
INFO - 2024-09-04 19:24:10 --> Utf8 Class Initialized
INFO - 2024-09-04 19:24:10 --> URI Class Initialized
INFO - 2024-09-04 19:24:10 --> Router Class Initialized
INFO - 2024-09-04 19:24:10 --> Output Class Initialized
INFO - 2024-09-04 19:24:10 --> Security Class Initialized
DEBUG - 2024-09-04 19:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 19:24:10 --> Input Class Initialized
INFO - 2024-09-04 19:24:10 --> Language Class Initialized
INFO - 2024-09-04 19:24:10 --> Language Class Initialized
INFO - 2024-09-04 19:24:10 --> Config Class Initialized
INFO - 2024-09-04 19:24:10 --> Loader Class Initialized
INFO - 2024-09-04 19:24:10 --> Helper loaded: url_helper
INFO - 2024-09-04 19:24:10 --> Helper loaded: file_helper
INFO - 2024-09-04 19:24:10 --> Helper loaded: form_helper
INFO - 2024-09-04 19:24:10 --> Helper loaded: my_helper
INFO - 2024-09-04 19:24:10 --> Database Driver Class Initialized
INFO - 2024-09-04 19:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 19:24:10 --> Controller Class Initialized
INFO - 2024-09-04 19:24:10 --> Helper loaded: cookie_helper
INFO - 2024-09-04 19:24:10 --> Config Class Initialized
INFO - 2024-09-04 19:24:10 --> Hooks Class Initialized
DEBUG - 2024-09-04 19:24:10 --> UTF-8 Support Enabled
INFO - 2024-09-04 19:24:10 --> Utf8 Class Initialized
INFO - 2024-09-04 19:24:10 --> URI Class Initialized
INFO - 2024-09-04 19:24:10 --> Router Class Initialized
INFO - 2024-09-04 19:24:10 --> Output Class Initialized
INFO - 2024-09-04 19:24:10 --> Security Class Initialized
DEBUG - 2024-09-04 19:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 19:24:10 --> Input Class Initialized
INFO - 2024-09-04 19:24:10 --> Language Class Initialized
INFO - 2024-09-04 19:24:10 --> Language Class Initialized
INFO - 2024-09-04 19:24:10 --> Config Class Initialized
INFO - 2024-09-04 19:24:10 --> Loader Class Initialized
INFO - 2024-09-04 19:24:10 --> Helper loaded: url_helper
INFO - 2024-09-04 19:24:10 --> Helper loaded: file_helper
INFO - 2024-09-04 19:24:10 --> Helper loaded: form_helper
INFO - 2024-09-04 19:24:10 --> Helper loaded: my_helper
INFO - 2024-09-04 19:24:10 --> Database Driver Class Initialized
INFO - 2024-09-04 19:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 19:24:10 --> Controller Class Initialized
DEBUG - 2024-09-04 19:24:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-04 19:24:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-04 19:24:10 --> Final output sent to browser
DEBUG - 2024-09-04 19:24:10 --> Total execution time: 0.0352
INFO - 2024-09-04 19:26:03 --> Config Class Initialized
INFO - 2024-09-04 19:26:03 --> Hooks Class Initialized
DEBUG - 2024-09-04 19:26:03 --> UTF-8 Support Enabled
INFO - 2024-09-04 19:26:03 --> Utf8 Class Initialized
INFO - 2024-09-04 19:26:03 --> URI Class Initialized
INFO - 2024-09-04 19:26:03 --> Router Class Initialized
INFO - 2024-09-04 19:26:03 --> Output Class Initialized
INFO - 2024-09-04 19:26:03 --> Security Class Initialized
DEBUG - 2024-09-04 19:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 19:26:03 --> Input Class Initialized
INFO - 2024-09-04 19:26:03 --> Language Class Initialized
INFO - 2024-09-04 19:26:03 --> Language Class Initialized
INFO - 2024-09-04 19:26:03 --> Config Class Initialized
INFO - 2024-09-04 19:26:03 --> Loader Class Initialized
INFO - 2024-09-04 19:26:03 --> Helper loaded: url_helper
INFO - 2024-09-04 19:26:03 --> Helper loaded: file_helper
INFO - 2024-09-04 19:26:03 --> Helper loaded: form_helper
INFO - 2024-09-04 19:26:03 --> Helper loaded: my_helper
INFO - 2024-09-04 19:26:03 --> Database Driver Class Initialized
INFO - 2024-09-04 19:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 19:26:03 --> Controller Class Initialized
INFO - 2024-09-04 19:26:03 --> Helper loaded: cookie_helper
INFO - 2024-09-04 19:26:03 --> Final output sent to browser
DEBUG - 2024-09-04 19:26:03 --> Total execution time: 0.0323
INFO - 2024-09-04 19:26:03 --> Config Class Initialized
INFO - 2024-09-04 19:26:03 --> Hooks Class Initialized
DEBUG - 2024-09-04 19:26:03 --> UTF-8 Support Enabled
INFO - 2024-09-04 19:26:03 --> Utf8 Class Initialized
INFO - 2024-09-04 19:26:03 --> URI Class Initialized
INFO - 2024-09-04 19:26:03 --> Router Class Initialized
INFO - 2024-09-04 19:26:03 --> Output Class Initialized
INFO - 2024-09-04 19:26:03 --> Security Class Initialized
DEBUG - 2024-09-04 19:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 19:26:03 --> Input Class Initialized
INFO - 2024-09-04 19:26:03 --> Language Class Initialized
INFO - 2024-09-04 19:26:03 --> Language Class Initialized
INFO - 2024-09-04 19:26:03 --> Config Class Initialized
INFO - 2024-09-04 19:26:03 --> Loader Class Initialized
INFO - 2024-09-04 19:26:03 --> Helper loaded: url_helper
INFO - 2024-09-04 19:26:03 --> Helper loaded: file_helper
INFO - 2024-09-04 19:26:03 --> Helper loaded: form_helper
INFO - 2024-09-04 19:26:03 --> Helper loaded: my_helper
INFO - 2024-09-04 19:26:03 --> Database Driver Class Initialized
INFO - 2024-09-04 19:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 19:26:03 --> Controller Class Initialized
INFO - 2024-09-04 19:26:03 --> Helper loaded: cookie_helper
INFO - 2024-09-04 19:26:03 --> Config Class Initialized
INFO - 2024-09-04 19:26:03 --> Hooks Class Initialized
DEBUG - 2024-09-04 19:26:03 --> UTF-8 Support Enabled
INFO - 2024-09-04 19:26:03 --> Utf8 Class Initialized
INFO - 2024-09-04 19:26:03 --> URI Class Initialized
INFO - 2024-09-04 19:26:03 --> Router Class Initialized
INFO - 2024-09-04 19:26:03 --> Output Class Initialized
INFO - 2024-09-04 19:26:03 --> Security Class Initialized
DEBUG - 2024-09-04 19:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 19:26:03 --> Input Class Initialized
INFO - 2024-09-04 19:26:03 --> Language Class Initialized
INFO - 2024-09-04 19:26:03 --> Language Class Initialized
INFO - 2024-09-04 19:26:03 --> Config Class Initialized
INFO - 2024-09-04 19:26:03 --> Loader Class Initialized
INFO - 2024-09-04 19:26:03 --> Helper loaded: url_helper
INFO - 2024-09-04 19:26:03 --> Helper loaded: file_helper
INFO - 2024-09-04 19:26:03 --> Helper loaded: form_helper
INFO - 2024-09-04 19:26:03 --> Helper loaded: my_helper
INFO - 2024-09-04 19:26:03 --> Database Driver Class Initialized
INFO - 2024-09-04 19:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 19:26:03 --> Controller Class Initialized
DEBUG - 2024-09-04 19:26:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-04 19:26:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-04 19:26:03 --> Final output sent to browser
DEBUG - 2024-09-04 19:26:03 --> Total execution time: 0.0361
