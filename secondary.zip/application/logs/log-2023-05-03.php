<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-03 02:34:48 --> Config Class Initialized
INFO - 2023-05-03 02:34:48 --> Hooks Class Initialized
DEBUG - 2023-05-03 02:34:49 --> UTF-8 Support Enabled
INFO - 2023-05-03 02:34:49 --> Utf8 Class Initialized
INFO - 2023-05-03 02:34:49 --> URI Class Initialized
INFO - 2023-05-03 02:34:49 --> Router Class Initialized
INFO - 2023-05-03 02:34:49 --> Output Class Initialized
INFO - 2023-05-03 02:34:49 --> Security Class Initialized
DEBUG - 2023-05-03 02:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-03 02:34:49 --> Input Class Initialized
INFO - 2023-05-03 02:34:49 --> Language Class Initialized
INFO - 2023-05-03 02:34:49 --> Language Class Initialized
INFO - 2023-05-03 02:34:49 --> Config Class Initialized
INFO - 2023-05-03 02:34:49 --> Loader Class Initialized
INFO - 2023-05-03 02:34:49 --> Helper loaded: url_helper
INFO - 2023-05-03 02:34:49 --> Helper loaded: file_helper
INFO - 2023-05-03 02:34:49 --> Helper loaded: form_helper
INFO - 2023-05-03 02:34:49 --> Helper loaded: my_helper
INFO - 2023-05-03 02:34:49 --> Database Driver Class Initialized
DEBUG - 2023-05-03 02:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-03 02:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-03 02:34:49 --> Controller Class Initialized
ERROR - 2023-05-03 02:34:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 21
ERROR - 2023-05-03 02:34:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 22
DEBUG - 2023-05-03 02:34:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-03 02:34:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-03 02:34:49 --> Final output sent to browser
DEBUG - 2023-05-03 02:34:49 --> Total execution time: 0.9696
INFO - 2023-05-03 02:35:03 --> Config Class Initialized
INFO - 2023-05-03 02:35:03 --> Hooks Class Initialized
DEBUG - 2023-05-03 02:35:03 --> UTF-8 Support Enabled
INFO - 2023-05-03 02:35:03 --> Utf8 Class Initialized
INFO - 2023-05-03 02:35:03 --> URI Class Initialized
DEBUG - 2023-05-03 02:35:03 --> No URI present. Default controller set.
INFO - 2023-05-03 02:35:03 --> Router Class Initialized
INFO - 2023-05-03 02:35:03 --> Output Class Initialized
INFO - 2023-05-03 02:35:03 --> Security Class Initialized
DEBUG - 2023-05-03 02:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-03 02:35:03 --> Input Class Initialized
INFO - 2023-05-03 02:35:03 --> Language Class Initialized
INFO - 2023-05-03 02:35:03 --> Language Class Initialized
INFO - 2023-05-03 02:35:03 --> Config Class Initialized
INFO - 2023-05-03 02:35:03 --> Loader Class Initialized
INFO - 2023-05-03 02:35:03 --> Helper loaded: url_helper
INFO - 2023-05-03 02:35:03 --> Helper loaded: file_helper
INFO - 2023-05-03 02:35:03 --> Helper loaded: form_helper
INFO - 2023-05-03 02:35:03 --> Helper loaded: my_helper
INFO - 2023-05-03 02:35:03 --> Database Driver Class Initialized
DEBUG - 2023-05-03 02:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-03 02:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-03 02:35:03 --> Controller Class Initialized
INFO - 2023-05-03 02:35:03 --> Config Class Initialized
INFO - 2023-05-03 02:35:03 --> Hooks Class Initialized
DEBUG - 2023-05-03 02:35:03 --> UTF-8 Support Enabled
INFO - 2023-05-03 02:35:03 --> Utf8 Class Initialized
INFO - 2023-05-03 02:35:03 --> URI Class Initialized
INFO - 2023-05-03 02:35:03 --> Router Class Initialized
INFO - 2023-05-03 02:35:03 --> Output Class Initialized
INFO - 2023-05-03 02:35:03 --> Security Class Initialized
DEBUG - 2023-05-03 02:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-03 02:35:03 --> Input Class Initialized
INFO - 2023-05-03 02:35:03 --> Language Class Initialized
INFO - 2023-05-03 02:35:03 --> Language Class Initialized
INFO - 2023-05-03 02:35:03 --> Config Class Initialized
INFO - 2023-05-03 02:35:03 --> Loader Class Initialized
INFO - 2023-05-03 02:35:03 --> Helper loaded: url_helper
INFO - 2023-05-03 02:35:03 --> Helper loaded: file_helper
INFO - 2023-05-03 02:35:03 --> Helper loaded: form_helper
INFO - 2023-05-03 02:35:03 --> Helper loaded: my_helper
INFO - 2023-05-03 02:35:03 --> Database Driver Class Initialized
DEBUG - 2023-05-03 02:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-03 02:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-03 02:35:03 --> Controller Class Initialized
DEBUG - 2023-05-03 02:35:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-05-03 02:35:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-03 02:35:03 --> Final output sent to browser
DEBUG - 2023-05-03 02:35:03 --> Total execution time: 0.0723
INFO - 2023-05-03 02:35:08 --> Config Class Initialized
INFO - 2023-05-03 02:35:08 --> Hooks Class Initialized
DEBUG - 2023-05-03 02:35:08 --> UTF-8 Support Enabled
INFO - 2023-05-03 02:35:08 --> Utf8 Class Initialized
INFO - 2023-05-03 02:35:08 --> URI Class Initialized
INFO - 2023-05-03 02:35:08 --> Router Class Initialized
INFO - 2023-05-03 02:35:08 --> Output Class Initialized
INFO - 2023-05-03 02:35:08 --> Security Class Initialized
DEBUG - 2023-05-03 02:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-03 02:35:08 --> Input Class Initialized
INFO - 2023-05-03 02:35:08 --> Language Class Initialized
INFO - 2023-05-03 02:35:08 --> Language Class Initialized
INFO - 2023-05-03 02:35:08 --> Config Class Initialized
INFO - 2023-05-03 02:35:08 --> Loader Class Initialized
INFO - 2023-05-03 02:35:08 --> Helper loaded: url_helper
INFO - 2023-05-03 02:35:08 --> Helper loaded: file_helper
INFO - 2023-05-03 02:35:08 --> Helper loaded: form_helper
INFO - 2023-05-03 02:35:08 --> Helper loaded: my_helper
INFO - 2023-05-03 02:35:08 --> Database Driver Class Initialized
DEBUG - 2023-05-03 02:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-03 02:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-03 02:35:08 --> Controller Class Initialized
INFO - 2023-05-03 02:35:08 --> Helper loaded: cookie_helper
INFO - 2023-05-03 02:35:08 --> Final output sent to browser
DEBUG - 2023-05-03 02:35:08 --> Total execution time: 0.1039
INFO - 2023-05-03 02:35:08 --> Config Class Initialized
INFO - 2023-05-03 02:35:08 --> Hooks Class Initialized
DEBUG - 2023-05-03 02:35:08 --> UTF-8 Support Enabled
INFO - 2023-05-03 02:35:08 --> Utf8 Class Initialized
INFO - 2023-05-03 02:35:08 --> URI Class Initialized
INFO - 2023-05-03 02:35:08 --> Router Class Initialized
INFO - 2023-05-03 02:35:08 --> Output Class Initialized
INFO - 2023-05-03 02:35:08 --> Security Class Initialized
DEBUG - 2023-05-03 02:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-03 02:35:08 --> Input Class Initialized
INFO - 2023-05-03 02:35:08 --> Language Class Initialized
INFO - 2023-05-03 02:35:08 --> Language Class Initialized
INFO - 2023-05-03 02:35:08 --> Config Class Initialized
INFO - 2023-05-03 02:35:08 --> Loader Class Initialized
INFO - 2023-05-03 02:35:08 --> Helper loaded: url_helper
INFO - 2023-05-03 02:35:08 --> Helper loaded: file_helper
INFO - 2023-05-03 02:35:08 --> Helper loaded: form_helper
INFO - 2023-05-03 02:35:08 --> Helper loaded: my_helper
INFO - 2023-05-03 02:35:08 --> Database Driver Class Initialized
DEBUG - 2023-05-03 02:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-03 02:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-03 02:35:08 --> Controller Class Initialized
DEBUG - 2023-05-03 02:35:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-03 02:35:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-03 02:35:08 --> Final output sent to browser
DEBUG - 2023-05-03 02:35:08 --> Total execution time: 0.0736
INFO - 2023-05-03 02:35:13 --> Config Class Initialized
INFO - 2023-05-03 02:35:13 --> Hooks Class Initialized
DEBUG - 2023-05-03 02:35:13 --> UTF-8 Support Enabled
INFO - 2023-05-03 02:35:13 --> Utf8 Class Initialized
INFO - 2023-05-03 02:35:13 --> URI Class Initialized
INFO - 2023-05-03 02:35:13 --> Router Class Initialized
INFO - 2023-05-03 02:35:13 --> Output Class Initialized
INFO - 2023-05-03 02:35:13 --> Security Class Initialized
DEBUG - 2023-05-03 02:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-03 02:35:13 --> Input Class Initialized
INFO - 2023-05-03 02:35:13 --> Language Class Initialized
INFO - 2023-05-03 02:35:13 --> Language Class Initialized
INFO - 2023-05-03 02:35:13 --> Config Class Initialized
INFO - 2023-05-03 02:35:13 --> Loader Class Initialized
INFO - 2023-05-03 02:35:13 --> Helper loaded: url_helper
INFO - 2023-05-03 02:35:13 --> Helper loaded: file_helper
INFO - 2023-05-03 02:35:13 --> Helper loaded: form_helper
INFO - 2023-05-03 02:35:13 --> Helper loaded: my_helper
INFO - 2023-05-03 02:35:13 --> Database Driver Class Initialized
DEBUG - 2023-05-03 02:35:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-03 02:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-03 02:35:13 --> Controller Class Initialized
DEBUG - 2023-05-03 02:35:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-03 02:35:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-03 02:35:13 --> Final output sent to browser
DEBUG - 2023-05-03 02:35:13 --> Total execution time: 0.0668
INFO - 2023-05-03 03:09:29 --> Config Class Initialized
INFO - 2023-05-03 03:09:29 --> Hooks Class Initialized
DEBUG - 2023-05-03 03:09:29 --> UTF-8 Support Enabled
INFO - 2023-05-03 03:09:29 --> Utf8 Class Initialized
INFO - 2023-05-03 03:09:29 --> URI Class Initialized
DEBUG - 2023-05-03 03:09:29 --> No URI present. Default controller set.
INFO - 2023-05-03 03:09:29 --> Router Class Initialized
INFO - 2023-05-03 03:09:29 --> Output Class Initialized
INFO - 2023-05-03 03:09:29 --> Security Class Initialized
DEBUG - 2023-05-03 03:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-03 03:09:29 --> Input Class Initialized
INFO - 2023-05-03 03:09:29 --> Language Class Initialized
INFO - 2023-05-03 03:09:29 --> Language Class Initialized
INFO - 2023-05-03 03:09:29 --> Config Class Initialized
INFO - 2023-05-03 03:09:29 --> Loader Class Initialized
INFO - 2023-05-03 03:09:29 --> Helper loaded: url_helper
INFO - 2023-05-03 03:09:29 --> Helper loaded: file_helper
INFO - 2023-05-03 03:09:29 --> Helper loaded: form_helper
INFO - 2023-05-03 03:09:29 --> Helper loaded: my_helper
INFO - 2023-05-03 03:09:29 --> Database Driver Class Initialized
DEBUG - 2023-05-03 03:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-03 03:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-03 03:09:30 --> Controller Class Initialized
DEBUG - 2023-05-03 03:09:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-03 03:09:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-03 03:09:30 --> Final output sent to browser
DEBUG - 2023-05-03 03:09:30 --> Total execution time: 0.3833
INFO - 2023-05-03 03:09:32 --> Config Class Initialized
INFO - 2023-05-03 03:09:32 --> Hooks Class Initialized
DEBUG - 2023-05-03 03:09:32 --> UTF-8 Support Enabled
INFO - 2023-05-03 03:09:32 --> Utf8 Class Initialized
INFO - 2023-05-03 03:09:32 --> URI Class Initialized
INFO - 2023-05-03 03:09:32 --> Router Class Initialized
INFO - 2023-05-03 03:09:32 --> Output Class Initialized
INFO - 2023-05-03 03:09:32 --> Security Class Initialized
DEBUG - 2023-05-03 03:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-03 03:09:32 --> Input Class Initialized
INFO - 2023-05-03 03:09:32 --> Language Class Initialized
INFO - 2023-05-03 03:09:32 --> Language Class Initialized
INFO - 2023-05-03 03:09:32 --> Config Class Initialized
INFO - 2023-05-03 03:09:32 --> Loader Class Initialized
INFO - 2023-05-03 03:09:32 --> Helper loaded: url_helper
INFO - 2023-05-03 03:09:32 --> Helper loaded: file_helper
INFO - 2023-05-03 03:09:32 --> Helper loaded: form_helper
INFO - 2023-05-03 03:09:32 --> Helper loaded: my_helper
INFO - 2023-05-03 03:09:32 --> Database Driver Class Initialized
DEBUG - 2023-05-03 03:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-03 03:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-03 03:09:32 --> Controller Class Initialized
INFO - 2023-05-03 03:09:32 --> Helper loaded: cookie_helper
INFO - 2023-05-03 03:09:32 --> Config Class Initialized
INFO - 2023-05-03 03:09:32 --> Hooks Class Initialized
DEBUG - 2023-05-03 03:09:32 --> UTF-8 Support Enabled
INFO - 2023-05-03 03:09:32 --> Utf8 Class Initialized
INFO - 2023-05-03 03:09:32 --> URI Class Initialized
INFO - 2023-05-03 03:09:32 --> Router Class Initialized
INFO - 2023-05-03 03:09:32 --> Output Class Initialized
INFO - 2023-05-03 03:09:32 --> Security Class Initialized
DEBUG - 2023-05-03 03:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-03 03:09:32 --> Input Class Initialized
INFO - 2023-05-03 03:09:32 --> Language Class Initialized
INFO - 2023-05-03 03:09:32 --> Language Class Initialized
INFO - 2023-05-03 03:09:32 --> Config Class Initialized
INFO - 2023-05-03 03:09:32 --> Loader Class Initialized
INFO - 2023-05-03 03:09:32 --> Helper loaded: url_helper
INFO - 2023-05-03 03:09:32 --> Helper loaded: file_helper
INFO - 2023-05-03 03:09:32 --> Helper loaded: form_helper
INFO - 2023-05-03 03:09:32 --> Helper loaded: my_helper
INFO - 2023-05-03 03:09:32 --> Database Driver Class Initialized
DEBUG - 2023-05-03 03:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-03 03:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-03 03:09:32 --> Controller Class Initialized
INFO - 2023-05-03 03:09:32 --> Config Class Initialized
INFO - 2023-05-03 03:09:32 --> Hooks Class Initialized
DEBUG - 2023-05-03 03:09:32 --> UTF-8 Support Enabled
INFO - 2023-05-03 03:09:32 --> Utf8 Class Initialized
INFO - 2023-05-03 03:09:32 --> URI Class Initialized
INFO - 2023-05-03 03:09:32 --> Router Class Initialized
INFO - 2023-05-03 03:09:32 --> Output Class Initialized
INFO - 2023-05-03 03:09:32 --> Security Class Initialized
DEBUG - 2023-05-03 03:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-03 03:09:32 --> Input Class Initialized
INFO - 2023-05-03 03:09:32 --> Language Class Initialized
INFO - 2023-05-03 03:09:32 --> Language Class Initialized
INFO - 2023-05-03 03:09:32 --> Config Class Initialized
INFO - 2023-05-03 03:09:32 --> Loader Class Initialized
INFO - 2023-05-03 03:09:32 --> Helper loaded: url_helper
INFO - 2023-05-03 03:09:32 --> Helper loaded: file_helper
INFO - 2023-05-03 03:09:32 --> Helper loaded: form_helper
INFO - 2023-05-03 03:09:32 --> Helper loaded: my_helper
INFO - 2023-05-03 03:09:32 --> Database Driver Class Initialized
DEBUG - 2023-05-03 03:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-03 03:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-03 03:09:32 --> Controller Class Initialized
DEBUG - 2023-05-03 03:09:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-05-03 03:09:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-03 03:09:32 --> Final output sent to browser
DEBUG - 2023-05-03 03:09:32 --> Total execution time: 0.0474
INFO - 2023-05-03 03:09:36 --> Config Class Initialized
INFO - 2023-05-03 03:09:36 --> Hooks Class Initialized
DEBUG - 2023-05-03 03:09:36 --> UTF-8 Support Enabled
INFO - 2023-05-03 03:09:36 --> Utf8 Class Initialized
INFO - 2023-05-03 03:09:36 --> URI Class Initialized
INFO - 2023-05-03 03:09:36 --> Router Class Initialized
INFO - 2023-05-03 03:09:36 --> Output Class Initialized
INFO - 2023-05-03 03:09:36 --> Security Class Initialized
DEBUG - 2023-05-03 03:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-03 03:09:36 --> Input Class Initialized
INFO - 2023-05-03 03:09:36 --> Language Class Initialized
INFO - 2023-05-03 03:09:36 --> Language Class Initialized
INFO - 2023-05-03 03:09:36 --> Config Class Initialized
INFO - 2023-05-03 03:09:36 --> Loader Class Initialized
INFO - 2023-05-03 03:09:36 --> Helper loaded: url_helper
INFO - 2023-05-03 03:09:36 --> Helper loaded: file_helper
INFO - 2023-05-03 03:09:36 --> Helper loaded: form_helper
INFO - 2023-05-03 03:09:36 --> Helper loaded: my_helper
INFO - 2023-05-03 03:09:36 --> Database Driver Class Initialized
DEBUG - 2023-05-03 03:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-03 03:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-03 03:09:36 --> Controller Class Initialized
INFO - 2023-05-03 03:09:36 --> Helper loaded: cookie_helper
INFO - 2023-05-03 03:09:36 --> Final output sent to browser
DEBUG - 2023-05-03 03:09:36 --> Total execution time: 0.0370
INFO - 2023-05-03 03:09:36 --> Config Class Initialized
INFO - 2023-05-03 03:09:36 --> Hooks Class Initialized
DEBUG - 2023-05-03 03:09:36 --> UTF-8 Support Enabled
INFO - 2023-05-03 03:09:36 --> Utf8 Class Initialized
INFO - 2023-05-03 03:09:36 --> URI Class Initialized
INFO - 2023-05-03 03:09:36 --> Router Class Initialized
INFO - 2023-05-03 03:09:36 --> Output Class Initialized
INFO - 2023-05-03 03:09:36 --> Security Class Initialized
DEBUG - 2023-05-03 03:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-03 03:09:36 --> Input Class Initialized
INFO - 2023-05-03 03:09:36 --> Language Class Initialized
INFO - 2023-05-03 03:09:36 --> Language Class Initialized
INFO - 2023-05-03 03:09:36 --> Config Class Initialized
INFO - 2023-05-03 03:09:36 --> Loader Class Initialized
INFO - 2023-05-03 03:09:36 --> Helper loaded: url_helper
INFO - 2023-05-03 03:09:36 --> Helper loaded: file_helper
INFO - 2023-05-03 03:09:36 --> Helper loaded: form_helper
INFO - 2023-05-03 03:09:36 --> Helper loaded: my_helper
INFO - 2023-05-03 03:09:36 --> Database Driver Class Initialized
DEBUG - 2023-05-03 03:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-03 03:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-03 03:09:36 --> Controller Class Initialized
DEBUG - 2023-05-03 03:09:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-05-03 03:09:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-03 03:09:36 --> Final output sent to browser
DEBUG - 2023-05-03 03:09:36 --> Total execution time: 0.0748
INFO - 2023-05-03 03:09:38 --> Config Class Initialized
INFO - 2023-05-03 03:09:38 --> Hooks Class Initialized
DEBUG - 2023-05-03 03:09:38 --> UTF-8 Support Enabled
INFO - 2023-05-03 03:09:38 --> Utf8 Class Initialized
INFO - 2023-05-03 03:09:38 --> URI Class Initialized
INFO - 2023-05-03 03:09:38 --> Router Class Initialized
INFO - 2023-05-03 03:09:38 --> Output Class Initialized
INFO - 2023-05-03 03:09:38 --> Security Class Initialized
DEBUG - 2023-05-03 03:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-03 03:09:38 --> Input Class Initialized
INFO - 2023-05-03 03:09:38 --> Language Class Initialized
INFO - 2023-05-03 03:09:38 --> Language Class Initialized
INFO - 2023-05-03 03:09:38 --> Config Class Initialized
INFO - 2023-05-03 03:09:38 --> Loader Class Initialized
INFO - 2023-05-03 03:09:38 --> Helper loaded: url_helper
INFO - 2023-05-03 03:09:38 --> Helper loaded: file_helper
INFO - 2023-05-03 03:09:38 --> Helper loaded: form_helper
INFO - 2023-05-03 03:09:38 --> Helper loaded: my_helper
INFO - 2023-05-03 03:09:38 --> Database Driver Class Initialized
DEBUG - 2023-05-03 03:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-03 03:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-03 03:09:38 --> Controller Class Initialized
DEBUG - 2023-05-03 03:09:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_guru/views/list.php
DEBUG - 2023-05-03 03:09:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-03 03:09:38 --> Final output sent to browser
DEBUG - 2023-05-03 03:09:38 --> Total execution time: 0.0834
INFO - 2023-05-03 03:09:38 --> Config Class Initialized
INFO - 2023-05-03 03:09:38 --> Hooks Class Initialized
DEBUG - 2023-05-03 03:09:38 --> UTF-8 Support Enabled
INFO - 2023-05-03 03:09:38 --> Utf8 Class Initialized
INFO - 2023-05-03 03:09:38 --> URI Class Initialized
INFO - 2023-05-03 03:09:38 --> Router Class Initialized
INFO - 2023-05-03 03:09:38 --> Output Class Initialized
INFO - 2023-05-03 03:09:38 --> Security Class Initialized
DEBUG - 2023-05-03 03:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-03 03:09:38 --> Input Class Initialized
INFO - 2023-05-03 03:09:38 --> Language Class Initialized
INFO - 2023-05-03 03:09:38 --> Language Class Initialized
INFO - 2023-05-03 03:09:38 --> Config Class Initialized
INFO - 2023-05-03 03:09:38 --> Loader Class Initialized
INFO - 2023-05-03 03:09:38 --> Helper loaded: url_helper
INFO - 2023-05-03 03:09:38 --> Helper loaded: file_helper
INFO - 2023-05-03 03:09:38 --> Helper loaded: form_helper
INFO - 2023-05-03 03:09:38 --> Helper loaded: my_helper
INFO - 2023-05-03 03:09:38 --> Database Driver Class Initialized
DEBUG - 2023-05-03 03:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-03 03:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-03 03:09:38 --> Controller Class Initialized
INFO - 2023-05-03 03:09:56 --> Config Class Initialized
INFO - 2023-05-03 03:09:56 --> Hooks Class Initialized
DEBUG - 2023-05-03 03:09:56 --> UTF-8 Support Enabled
INFO - 2023-05-03 03:09:56 --> Utf8 Class Initialized
INFO - 2023-05-03 03:09:56 --> URI Class Initialized
INFO - 2023-05-03 03:09:56 --> Router Class Initialized
INFO - 2023-05-03 03:09:56 --> Output Class Initialized
INFO - 2023-05-03 03:09:56 --> Security Class Initialized
DEBUG - 2023-05-03 03:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-03 03:09:56 --> Input Class Initialized
INFO - 2023-05-03 03:09:56 --> Language Class Initialized
INFO - 2023-05-03 03:09:56 --> Language Class Initialized
INFO - 2023-05-03 03:09:56 --> Config Class Initialized
INFO - 2023-05-03 03:09:56 --> Loader Class Initialized
INFO - 2023-05-03 03:09:56 --> Helper loaded: url_helper
INFO - 2023-05-03 03:09:56 --> Helper loaded: file_helper
INFO - 2023-05-03 03:09:56 --> Helper loaded: form_helper
INFO - 2023-05-03 03:09:56 --> Helper loaded: my_helper
INFO - 2023-05-03 03:09:56 --> Database Driver Class Initialized
DEBUG - 2023-05-03 03:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-03 03:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-03 03:09:56 --> Controller Class Initialized
DEBUG - 2023-05-03 03:09:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_guru/views/list.php
DEBUG - 2023-05-03 03:09:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-03 03:09:56 --> Final output sent to browser
DEBUG - 2023-05-03 03:09:56 --> Total execution time: 0.0561
INFO - 2023-05-03 03:09:56 --> Config Class Initialized
INFO - 2023-05-03 03:09:56 --> Hooks Class Initialized
DEBUG - 2023-05-03 03:09:56 --> UTF-8 Support Enabled
INFO - 2023-05-03 03:09:56 --> Utf8 Class Initialized
INFO - 2023-05-03 03:09:56 --> URI Class Initialized
INFO - 2023-05-03 03:09:56 --> Router Class Initialized
INFO - 2023-05-03 03:09:56 --> Output Class Initialized
INFO - 2023-05-03 03:09:56 --> Security Class Initialized
DEBUG - 2023-05-03 03:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-03 03:09:56 --> Input Class Initialized
INFO - 2023-05-03 03:09:56 --> Language Class Initialized
INFO - 2023-05-03 03:09:56 --> Language Class Initialized
INFO - 2023-05-03 03:09:56 --> Config Class Initialized
INFO - 2023-05-03 03:09:56 --> Loader Class Initialized
INFO - 2023-05-03 03:09:56 --> Helper loaded: url_helper
INFO - 2023-05-03 03:09:56 --> Helper loaded: file_helper
INFO - 2023-05-03 03:09:56 --> Helper loaded: form_helper
INFO - 2023-05-03 03:09:56 --> Helper loaded: my_helper
INFO - 2023-05-03 03:09:56 --> Database Driver Class Initialized
DEBUG - 2023-05-03 03:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-03 03:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-03 03:09:56 --> Controller Class Initialized
INFO - 2023-05-03 03:09:58 --> Config Class Initialized
INFO - 2023-05-03 03:09:58 --> Hooks Class Initialized
DEBUG - 2023-05-03 03:09:58 --> UTF-8 Support Enabled
INFO - 2023-05-03 03:09:58 --> Utf8 Class Initialized
INFO - 2023-05-03 03:09:58 --> URI Class Initialized
INFO - 2023-05-03 03:09:58 --> Router Class Initialized
INFO - 2023-05-03 03:09:58 --> Output Class Initialized
INFO - 2023-05-03 03:09:58 --> Security Class Initialized
DEBUG - 2023-05-03 03:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-03 03:09:58 --> Input Class Initialized
INFO - 2023-05-03 03:09:58 --> Language Class Initialized
INFO - 2023-05-03 03:09:58 --> Language Class Initialized
INFO - 2023-05-03 03:09:58 --> Config Class Initialized
INFO - 2023-05-03 03:09:58 --> Loader Class Initialized
INFO - 2023-05-03 03:09:58 --> Helper loaded: url_helper
INFO - 2023-05-03 03:09:58 --> Helper loaded: file_helper
INFO - 2023-05-03 03:09:58 --> Helper loaded: form_helper
INFO - 2023-05-03 03:09:58 --> Helper loaded: my_helper
INFO - 2023-05-03 03:09:58 --> Database Driver Class Initialized
DEBUG - 2023-05-03 03:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-03 03:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-03 03:09:58 --> Controller Class Initialized
INFO - 2023-05-03 03:09:58 --> Final output sent to browser
DEBUG - 2023-05-03 03:09:58 --> Total execution time: 0.0631
INFO - 2023-05-03 03:10:05 --> Config Class Initialized
INFO - 2023-05-03 03:10:05 --> Hooks Class Initialized
DEBUG - 2023-05-03 03:10:05 --> UTF-8 Support Enabled
INFO - 2023-05-03 03:10:05 --> Utf8 Class Initialized
INFO - 2023-05-03 03:10:05 --> URI Class Initialized
INFO - 2023-05-03 03:10:05 --> Router Class Initialized
INFO - 2023-05-03 03:10:05 --> Output Class Initialized
INFO - 2023-05-03 03:10:05 --> Security Class Initialized
DEBUG - 2023-05-03 03:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-03 03:10:05 --> Input Class Initialized
INFO - 2023-05-03 03:10:05 --> Language Class Initialized
INFO - 2023-05-03 03:10:05 --> Language Class Initialized
INFO - 2023-05-03 03:10:05 --> Config Class Initialized
INFO - 2023-05-03 03:10:05 --> Loader Class Initialized
INFO - 2023-05-03 03:10:05 --> Helper loaded: url_helper
INFO - 2023-05-03 03:10:05 --> Helper loaded: file_helper
INFO - 2023-05-03 03:10:05 --> Helper loaded: form_helper
INFO - 2023-05-03 03:10:05 --> Helper loaded: my_helper
INFO - 2023-05-03 03:10:05 --> Database Driver Class Initialized
DEBUG - 2023-05-03 03:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-03 03:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-03 03:10:05 --> Controller Class Initialized
DEBUG - 2023-05-03 03:10:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/list.php
DEBUG - 2023-05-03 03:10:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-03 03:10:05 --> Final output sent to browser
DEBUG - 2023-05-03 03:10:05 --> Total execution time: 0.1049
INFO - 2023-05-03 03:10:05 --> Config Class Initialized
INFO - 2023-05-03 03:10:05 --> Hooks Class Initialized
DEBUG - 2023-05-03 03:10:05 --> UTF-8 Support Enabled
INFO - 2023-05-03 03:10:05 --> Utf8 Class Initialized
INFO - 2023-05-03 03:10:05 --> URI Class Initialized
INFO - 2023-05-03 03:10:05 --> Router Class Initialized
INFO - 2023-05-03 03:10:05 --> Output Class Initialized
INFO - 2023-05-03 03:10:05 --> Security Class Initialized
DEBUG - 2023-05-03 03:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-03 03:10:05 --> Input Class Initialized
INFO - 2023-05-03 03:10:05 --> Language Class Initialized
INFO - 2023-05-03 03:10:05 --> Language Class Initialized
INFO - 2023-05-03 03:10:05 --> Config Class Initialized
INFO - 2023-05-03 03:10:05 --> Loader Class Initialized
INFO - 2023-05-03 03:10:05 --> Helper loaded: url_helper
INFO - 2023-05-03 03:10:05 --> Helper loaded: file_helper
INFO - 2023-05-03 03:10:05 --> Helper loaded: form_helper
INFO - 2023-05-03 03:10:05 --> Helper loaded: my_helper
INFO - 2023-05-03 03:10:05 --> Database Driver Class Initialized
DEBUG - 2023-05-03 03:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-03 03:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-03 03:10:05 --> Controller Class Initialized
INFO - 2023-05-03 03:10:07 --> Config Class Initialized
INFO - 2023-05-03 03:10:07 --> Hooks Class Initialized
DEBUG - 2023-05-03 03:10:07 --> UTF-8 Support Enabled
INFO - 2023-05-03 03:10:07 --> Utf8 Class Initialized
INFO - 2023-05-03 03:10:07 --> URI Class Initialized
INFO - 2023-05-03 03:10:07 --> Router Class Initialized
INFO - 2023-05-03 03:10:07 --> Output Class Initialized
INFO - 2023-05-03 03:10:07 --> Security Class Initialized
DEBUG - 2023-05-03 03:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-03 03:10:07 --> Input Class Initialized
INFO - 2023-05-03 03:10:07 --> Language Class Initialized
INFO - 2023-05-03 03:10:07 --> Language Class Initialized
INFO - 2023-05-03 03:10:07 --> Config Class Initialized
INFO - 2023-05-03 03:10:07 --> Loader Class Initialized
INFO - 2023-05-03 03:10:07 --> Helper loaded: url_helper
INFO - 2023-05-03 03:10:07 --> Helper loaded: file_helper
INFO - 2023-05-03 03:10:07 --> Helper loaded: form_helper
INFO - 2023-05-03 03:10:07 --> Helper loaded: my_helper
INFO - 2023-05-03 03:10:07 --> Database Driver Class Initialized
DEBUG - 2023-05-03 03:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-03 03:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-03 03:10:07 --> Controller Class Initialized
ERROR - 2023-05-03 03:10:07 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\myraportk13\application\modules\data_siswa\views\form.php 231
DEBUG - 2023-05-03 03:10:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/form.php
DEBUG - 2023-05-03 03:10:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-03 03:10:07 --> Final output sent to browser
DEBUG - 2023-05-03 03:10:07 --> Total execution time: 0.1133
INFO - 2023-05-03 03:10:11 --> Config Class Initialized
INFO - 2023-05-03 03:10:11 --> Hooks Class Initialized
DEBUG - 2023-05-03 03:10:11 --> UTF-8 Support Enabled
INFO - 2023-05-03 03:10:11 --> Utf8 Class Initialized
INFO - 2023-05-03 03:10:11 --> URI Class Initialized
INFO - 2023-05-03 03:10:11 --> Router Class Initialized
INFO - 2023-05-03 03:10:11 --> Output Class Initialized
INFO - 2023-05-03 03:10:11 --> Security Class Initialized
DEBUG - 2023-05-03 03:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-03 03:10:11 --> Input Class Initialized
INFO - 2023-05-03 03:10:11 --> Language Class Initialized
INFO - 2023-05-03 03:10:11 --> Language Class Initialized
INFO - 2023-05-03 03:10:11 --> Config Class Initialized
INFO - 2023-05-03 03:10:11 --> Loader Class Initialized
INFO - 2023-05-03 03:10:11 --> Helper loaded: url_helper
INFO - 2023-05-03 03:10:11 --> Helper loaded: file_helper
INFO - 2023-05-03 03:10:11 --> Helper loaded: form_helper
INFO - 2023-05-03 03:10:11 --> Helper loaded: my_helper
INFO - 2023-05-03 03:10:11 --> Database Driver Class Initialized
DEBUG - 2023-05-03 03:10:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-03 03:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-03 03:10:11 --> Controller Class Initialized
DEBUG - 2023-05-03 03:10:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/list.php
DEBUG - 2023-05-03 03:10:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-03 03:10:11 --> Final output sent to browser
DEBUG - 2023-05-03 03:10:11 --> Total execution time: 0.0639
INFO - 2023-05-03 03:10:11 --> Config Class Initialized
INFO - 2023-05-03 03:10:11 --> Hooks Class Initialized
DEBUG - 2023-05-03 03:10:11 --> UTF-8 Support Enabled
INFO - 2023-05-03 03:10:11 --> Utf8 Class Initialized
INFO - 2023-05-03 03:10:11 --> URI Class Initialized
INFO - 2023-05-03 03:10:11 --> Router Class Initialized
INFO - 2023-05-03 03:10:11 --> Output Class Initialized
INFO - 2023-05-03 03:10:11 --> Security Class Initialized
DEBUG - 2023-05-03 03:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-03 03:10:11 --> Input Class Initialized
INFO - 2023-05-03 03:10:11 --> Language Class Initialized
INFO - 2023-05-03 03:10:11 --> Language Class Initialized
INFO - 2023-05-03 03:10:11 --> Config Class Initialized
INFO - 2023-05-03 03:10:11 --> Loader Class Initialized
INFO - 2023-05-03 03:10:11 --> Helper loaded: url_helper
INFO - 2023-05-03 03:10:11 --> Helper loaded: file_helper
INFO - 2023-05-03 03:10:11 --> Helper loaded: form_helper
INFO - 2023-05-03 03:10:11 --> Helper loaded: my_helper
INFO - 2023-05-03 03:10:11 --> Database Driver Class Initialized
DEBUG - 2023-05-03 03:10:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-03 03:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-03 03:10:11 --> Controller Class Initialized
INFO - 2023-05-03 03:10:12 --> Config Class Initialized
INFO - 2023-05-03 03:10:12 --> Hooks Class Initialized
DEBUG - 2023-05-03 03:10:12 --> UTF-8 Support Enabled
INFO - 2023-05-03 03:10:12 --> Utf8 Class Initialized
INFO - 2023-05-03 03:10:12 --> URI Class Initialized
INFO - 2023-05-03 03:10:12 --> Router Class Initialized
INFO - 2023-05-03 03:10:12 --> Output Class Initialized
INFO - 2023-05-03 03:10:12 --> Security Class Initialized
DEBUG - 2023-05-03 03:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-03 03:10:12 --> Input Class Initialized
INFO - 2023-05-03 03:10:12 --> Language Class Initialized
INFO - 2023-05-03 03:10:12 --> Language Class Initialized
INFO - 2023-05-03 03:10:12 --> Config Class Initialized
INFO - 2023-05-03 03:10:12 --> Loader Class Initialized
INFO - 2023-05-03 03:10:12 --> Helper loaded: url_helper
INFO - 2023-05-03 03:10:12 --> Helper loaded: file_helper
INFO - 2023-05-03 03:10:12 --> Helper loaded: form_helper
INFO - 2023-05-03 03:10:12 --> Helper loaded: my_helper
INFO - 2023-05-03 03:10:12 --> Database Driver Class Initialized
DEBUG - 2023-05-03 03:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-03 03:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-03 03:10:12 --> Controller Class Initialized
DEBUG - 2023-05-03 03:10:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_kelas/views/list.php
DEBUG - 2023-05-03 03:10:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-03 03:10:12 --> Final output sent to browser
DEBUG - 2023-05-03 03:10:12 --> Total execution time: 0.0812
INFO - 2023-05-03 03:10:12 --> Config Class Initialized
INFO - 2023-05-03 03:10:12 --> Hooks Class Initialized
DEBUG - 2023-05-03 03:10:12 --> UTF-8 Support Enabled
INFO - 2023-05-03 03:10:12 --> Utf8 Class Initialized
INFO - 2023-05-03 03:10:12 --> URI Class Initialized
INFO - 2023-05-03 03:10:12 --> Router Class Initialized
INFO - 2023-05-03 03:10:12 --> Output Class Initialized
INFO - 2023-05-03 03:10:12 --> Security Class Initialized
DEBUG - 2023-05-03 03:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-03 03:10:12 --> Input Class Initialized
INFO - 2023-05-03 03:10:12 --> Language Class Initialized
INFO - 2023-05-03 03:10:12 --> Language Class Initialized
INFO - 2023-05-03 03:10:12 --> Config Class Initialized
INFO - 2023-05-03 03:10:12 --> Loader Class Initialized
INFO - 2023-05-03 03:10:12 --> Helper loaded: url_helper
INFO - 2023-05-03 03:10:12 --> Helper loaded: file_helper
INFO - 2023-05-03 03:10:12 --> Helper loaded: form_helper
INFO - 2023-05-03 03:10:12 --> Helper loaded: my_helper
INFO - 2023-05-03 03:10:12 --> Database Driver Class Initialized
DEBUG - 2023-05-03 03:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-03 03:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-03 03:10:12 --> Controller Class Initialized
INFO - 2023-05-03 03:39:27 --> Config Class Initialized
INFO - 2023-05-03 03:39:27 --> Hooks Class Initialized
DEBUG - 2023-05-03 03:39:27 --> UTF-8 Support Enabled
INFO - 2023-05-03 03:39:27 --> Utf8 Class Initialized
INFO - 2023-05-03 03:39:27 --> URI Class Initialized
INFO - 2023-05-03 03:39:27 --> Router Class Initialized
INFO - 2023-05-03 03:39:27 --> Output Class Initialized
INFO - 2023-05-03 03:39:27 --> Security Class Initialized
DEBUG - 2023-05-03 03:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-03 03:39:27 --> Input Class Initialized
INFO - 2023-05-03 03:39:27 --> Language Class Initialized
INFO - 2023-05-03 03:39:27 --> Language Class Initialized
INFO - 2023-05-03 03:39:27 --> Config Class Initialized
INFO - 2023-05-03 03:39:27 --> Loader Class Initialized
INFO - 2023-05-03 03:39:27 --> Helper loaded: url_helper
INFO - 2023-05-03 03:39:27 --> Helper loaded: file_helper
INFO - 2023-05-03 03:39:27 --> Helper loaded: form_helper
INFO - 2023-05-03 03:39:27 --> Helper loaded: my_helper
INFO - 2023-05-03 03:39:27 --> Database Driver Class Initialized
DEBUG - 2023-05-03 03:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-03 03:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-03 03:39:27 --> Controller Class Initialized
DEBUG - 2023-05-03 03:39:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-03 03:39:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-03 03:39:27 --> Final output sent to browser
DEBUG - 2023-05-03 03:39:27 --> Total execution time: 0.0596
INFO - 2023-05-03 08:30:23 --> Config Class Initialized
INFO - 2023-05-03 08:30:23 --> Hooks Class Initialized
DEBUG - 2023-05-03 08:30:23 --> UTF-8 Support Enabled
INFO - 2023-05-03 08:30:23 --> Utf8 Class Initialized
INFO - 2023-05-03 08:30:23 --> URI Class Initialized
INFO - 2023-05-03 08:30:23 --> Router Class Initialized
INFO - 2023-05-03 08:30:23 --> Output Class Initialized
INFO - 2023-05-03 08:30:23 --> Security Class Initialized
DEBUG - 2023-05-03 08:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-03 08:30:23 --> Input Class Initialized
INFO - 2023-05-03 08:30:23 --> Language Class Initialized
INFO - 2023-05-03 08:30:23 --> Language Class Initialized
INFO - 2023-05-03 08:30:23 --> Config Class Initialized
INFO - 2023-05-03 08:30:23 --> Loader Class Initialized
INFO - 2023-05-03 08:30:23 --> Helper loaded: url_helper
INFO - 2023-05-03 08:30:23 --> Helper loaded: file_helper
INFO - 2023-05-03 08:30:23 --> Helper loaded: form_helper
INFO - 2023-05-03 08:30:23 --> Helper loaded: my_helper
INFO - 2023-05-03 08:30:23 --> Database Driver Class Initialized
DEBUG - 2023-05-03 08:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-03 08:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-03 08:30:23 --> Controller Class Initialized
DEBUG - 2023-05-03 08:30:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_kelas/views/list.php
DEBUG - 2023-05-03 08:30:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-03 08:30:23 --> Final output sent to browser
DEBUG - 2023-05-03 08:30:23 --> Total execution time: 0.1010
INFO - 2023-05-03 08:30:23 --> Config Class Initialized
INFO - 2023-05-03 08:30:23 --> Hooks Class Initialized
DEBUG - 2023-05-03 08:30:23 --> UTF-8 Support Enabled
INFO - 2023-05-03 08:30:23 --> Utf8 Class Initialized
INFO - 2023-05-03 08:30:23 --> URI Class Initialized
INFO - 2023-05-03 08:30:23 --> Router Class Initialized
INFO - 2023-05-03 08:30:23 --> Output Class Initialized
INFO - 2023-05-03 08:30:23 --> Security Class Initialized
DEBUG - 2023-05-03 08:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-03 08:30:23 --> Input Class Initialized
INFO - 2023-05-03 08:30:23 --> Language Class Initialized
INFO - 2023-05-03 08:30:23 --> Language Class Initialized
INFO - 2023-05-03 08:30:23 --> Config Class Initialized
INFO - 2023-05-03 08:30:23 --> Loader Class Initialized
INFO - 2023-05-03 08:30:23 --> Helper loaded: url_helper
INFO - 2023-05-03 08:30:23 --> Helper loaded: file_helper
INFO - 2023-05-03 08:30:23 --> Helper loaded: form_helper
INFO - 2023-05-03 08:30:23 --> Helper loaded: my_helper
INFO - 2023-05-03 08:30:23 --> Database Driver Class Initialized
DEBUG - 2023-05-03 08:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-03 08:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-03 08:30:23 --> Controller Class Initialized
INFO - 2023-05-03 08:44:27 --> Config Class Initialized
INFO - 2023-05-03 08:44:27 --> Hooks Class Initialized
DEBUG - 2023-05-03 08:44:27 --> UTF-8 Support Enabled
INFO - 2023-05-03 08:44:27 --> Utf8 Class Initialized
INFO - 2023-05-03 08:44:27 --> URI Class Initialized
INFO - 2023-05-03 08:44:27 --> Router Class Initialized
INFO - 2023-05-03 08:44:27 --> Output Class Initialized
INFO - 2023-05-03 08:44:27 --> Security Class Initialized
DEBUG - 2023-05-03 08:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-03 08:44:27 --> Input Class Initialized
INFO - 2023-05-03 08:44:27 --> Language Class Initialized
INFO - 2023-05-03 08:44:27 --> Language Class Initialized
INFO - 2023-05-03 08:44:27 --> Config Class Initialized
INFO - 2023-05-03 08:44:27 --> Loader Class Initialized
INFO - 2023-05-03 08:44:27 --> Helper loaded: url_helper
INFO - 2023-05-03 08:44:27 --> Helper loaded: file_helper
INFO - 2023-05-03 08:44:27 --> Helper loaded: form_helper
INFO - 2023-05-03 08:44:27 --> Helper loaded: my_helper
INFO - 2023-05-03 08:44:27 --> Database Driver Class Initialized
DEBUG - 2023-05-03 08:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-03 08:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-03 08:44:27 --> Controller Class Initialized
ERROR - 2023-05-03 08:44:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 21
ERROR - 2023-05-03 08:44:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 22
DEBUG - 2023-05-03 08:44:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-03 08:44:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-03 08:44:27 --> Final output sent to browser
DEBUG - 2023-05-03 08:44:27 --> Total execution time: 0.1242
INFO - 2023-05-03 09:20:35 --> Config Class Initialized
INFO - 2023-05-03 09:20:35 --> Hooks Class Initialized
DEBUG - 2023-05-03 09:20:35 --> UTF-8 Support Enabled
INFO - 2023-05-03 09:20:35 --> Utf8 Class Initialized
INFO - 2023-05-03 09:20:35 --> URI Class Initialized
INFO - 2023-05-03 09:20:36 --> Router Class Initialized
INFO - 2023-05-03 09:20:36 --> Output Class Initialized
INFO - 2023-05-03 09:20:36 --> Security Class Initialized
DEBUG - 2023-05-03 09:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-03 09:20:36 --> Input Class Initialized
INFO - 2023-05-03 09:20:36 --> Language Class Initialized
INFO - 2023-05-03 09:20:36 --> Language Class Initialized
INFO - 2023-05-03 09:20:36 --> Config Class Initialized
INFO - 2023-05-03 09:20:36 --> Loader Class Initialized
INFO - 2023-05-03 09:20:36 --> Helper loaded: url_helper
INFO - 2023-05-03 09:20:36 --> Helper loaded: file_helper
INFO - 2023-05-03 09:20:36 --> Helper loaded: form_helper
INFO - 2023-05-03 09:20:36 --> Helper loaded: my_helper
INFO - 2023-05-03 09:20:36 --> Database Driver Class Initialized
DEBUG - 2023-05-03 09:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-03 09:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-03 09:20:36 --> Controller Class Initialized
DEBUG - 2023-05-03 09:20:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_kelas/views/list.php
DEBUG - 2023-05-03 09:20:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-03 09:20:36 --> Final output sent to browser
DEBUG - 2023-05-03 09:20:36 --> Total execution time: 0.7389
INFO - 2023-05-03 09:20:36 --> Config Class Initialized
INFO - 2023-05-03 09:20:36 --> Hooks Class Initialized
DEBUG - 2023-05-03 09:20:36 --> UTF-8 Support Enabled
INFO - 2023-05-03 09:20:36 --> Utf8 Class Initialized
INFO - 2023-05-03 09:20:36 --> URI Class Initialized
INFO - 2023-05-03 09:20:36 --> Router Class Initialized
INFO - 2023-05-03 09:20:36 --> Output Class Initialized
INFO - 2023-05-03 09:20:36 --> Security Class Initialized
DEBUG - 2023-05-03 09:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-03 09:20:36 --> Input Class Initialized
INFO - 2023-05-03 09:20:36 --> Language Class Initialized
INFO - 2023-05-03 09:20:36 --> Language Class Initialized
INFO - 2023-05-03 09:20:36 --> Config Class Initialized
INFO - 2023-05-03 09:20:36 --> Loader Class Initialized
INFO - 2023-05-03 09:20:36 --> Helper loaded: url_helper
INFO - 2023-05-03 09:20:36 --> Helper loaded: file_helper
INFO - 2023-05-03 09:20:36 --> Helper loaded: form_helper
INFO - 2023-05-03 09:20:36 --> Helper loaded: my_helper
INFO - 2023-05-03 09:20:36 --> Database Driver Class Initialized
DEBUG - 2023-05-03 09:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-03 09:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-03 09:20:36 --> Controller Class Initialized
