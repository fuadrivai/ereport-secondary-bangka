<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-03-13 06:53:16 --> Config Class Initialized
INFO - 2020-03-13 06:53:16 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:53:16 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:53:17 --> Utf8 Class Initialized
INFO - 2020-03-13 06:53:17 --> URI Class Initialized
DEBUG - 2020-03-13 06:53:17 --> No URI present. Default controller set.
INFO - 2020-03-13 06:53:17 --> Router Class Initialized
INFO - 2020-03-13 06:53:17 --> Output Class Initialized
INFO - 2020-03-13 06:53:17 --> Security Class Initialized
DEBUG - 2020-03-13 06:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:53:17 --> Input Class Initialized
INFO - 2020-03-13 06:53:17 --> Language Class Initialized
INFO - 2020-03-13 06:53:17 --> Language Class Initialized
INFO - 2020-03-13 06:53:17 --> Config Class Initialized
INFO - 2020-03-13 06:53:17 --> Loader Class Initialized
INFO - 2020-03-13 06:53:17 --> Helper loaded: url_helper
INFO - 2020-03-13 06:53:17 --> Helper loaded: file_helper
INFO - 2020-03-13 06:53:17 --> Helper loaded: form_helper
INFO - 2020-03-13 06:53:17 --> Helper loaded: my_helper
INFO - 2020-03-13 06:53:17 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:53:17 --> Controller Class Initialized
INFO - 2020-03-13 06:53:17 --> Config Class Initialized
INFO - 2020-03-13 06:53:17 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:53:17 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:53:17 --> Utf8 Class Initialized
INFO - 2020-03-13 06:53:17 --> URI Class Initialized
INFO - 2020-03-13 06:53:17 --> Router Class Initialized
INFO - 2020-03-13 06:53:17 --> Output Class Initialized
INFO - 2020-03-13 06:53:17 --> Security Class Initialized
DEBUG - 2020-03-13 06:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:53:17 --> Input Class Initialized
INFO - 2020-03-13 06:53:17 --> Language Class Initialized
INFO - 2020-03-13 06:53:17 --> Language Class Initialized
INFO - 2020-03-13 06:53:17 --> Config Class Initialized
INFO - 2020-03-13 06:53:17 --> Loader Class Initialized
INFO - 2020-03-13 06:53:17 --> Helper loaded: url_helper
INFO - 2020-03-13 06:53:17 --> Helper loaded: file_helper
INFO - 2020-03-13 06:53:17 --> Helper loaded: form_helper
INFO - 2020-03-13 06:53:18 --> Helper loaded: my_helper
INFO - 2020-03-13 06:53:18 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:53:18 --> Controller Class Initialized
DEBUG - 2020-03-13 06:53:18 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-13 06:53:18 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-13 06:53:18 --> Final output sent to browser
DEBUG - 2020-03-13 06:53:18 --> Total execution time: 0.3321
INFO - 2020-03-13 06:53:35 --> Config Class Initialized
INFO - 2020-03-13 06:53:35 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:53:35 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:53:35 --> Utf8 Class Initialized
INFO - 2020-03-13 06:53:35 --> URI Class Initialized
INFO - 2020-03-13 06:53:35 --> Router Class Initialized
INFO - 2020-03-13 06:53:35 --> Output Class Initialized
INFO - 2020-03-13 06:53:35 --> Security Class Initialized
DEBUG - 2020-03-13 06:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:53:35 --> Input Class Initialized
INFO - 2020-03-13 06:53:35 --> Language Class Initialized
INFO - 2020-03-13 06:53:35 --> Language Class Initialized
INFO - 2020-03-13 06:53:35 --> Config Class Initialized
INFO - 2020-03-13 06:53:35 --> Loader Class Initialized
INFO - 2020-03-13 06:53:35 --> Helper loaded: url_helper
INFO - 2020-03-13 06:53:35 --> Helper loaded: file_helper
INFO - 2020-03-13 06:53:35 --> Helper loaded: form_helper
INFO - 2020-03-13 06:53:35 --> Helper loaded: my_helper
INFO - 2020-03-13 06:53:35 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:53:35 --> Controller Class Initialized
INFO - 2020-03-13 06:53:35 --> Helper loaded: cookie_helper
INFO - 2020-03-13 06:53:35 --> Final output sent to browser
DEBUG - 2020-03-13 06:53:35 --> Total execution time: 0.3338
INFO - 2020-03-13 06:53:35 --> Config Class Initialized
INFO - 2020-03-13 06:53:35 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:53:36 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:53:36 --> Utf8 Class Initialized
INFO - 2020-03-13 06:53:36 --> URI Class Initialized
INFO - 2020-03-13 06:53:36 --> Router Class Initialized
INFO - 2020-03-13 06:53:36 --> Output Class Initialized
INFO - 2020-03-13 06:53:36 --> Security Class Initialized
DEBUG - 2020-03-13 06:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:53:36 --> Input Class Initialized
INFO - 2020-03-13 06:53:36 --> Language Class Initialized
INFO - 2020-03-13 06:53:36 --> Language Class Initialized
INFO - 2020-03-13 06:53:36 --> Config Class Initialized
INFO - 2020-03-13 06:53:36 --> Loader Class Initialized
INFO - 2020-03-13 06:53:36 --> Helper loaded: url_helper
INFO - 2020-03-13 06:53:36 --> Helper loaded: file_helper
INFO - 2020-03-13 06:53:36 --> Helper loaded: form_helper
INFO - 2020-03-13 06:53:36 --> Helper loaded: my_helper
INFO - 2020-03-13 06:53:36 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:53:36 --> Controller Class Initialized
DEBUG - 2020-03-13 06:53:36 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-13 06:53:36 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-13 06:53:36 --> Final output sent to browser
DEBUG - 2020-03-13 06:53:36 --> Total execution time: 0.4319
INFO - 2020-03-13 06:53:47 --> Config Class Initialized
INFO - 2020-03-13 06:53:47 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:53:47 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:53:47 --> Utf8 Class Initialized
INFO - 2020-03-13 06:53:47 --> URI Class Initialized
INFO - 2020-03-13 06:53:47 --> Router Class Initialized
INFO - 2020-03-13 06:53:47 --> Output Class Initialized
INFO - 2020-03-13 06:53:47 --> Security Class Initialized
DEBUG - 2020-03-13 06:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:53:47 --> Input Class Initialized
INFO - 2020-03-13 06:53:47 --> Language Class Initialized
INFO - 2020-03-13 06:53:47 --> Language Class Initialized
INFO - 2020-03-13 06:53:47 --> Config Class Initialized
INFO - 2020-03-13 06:53:47 --> Loader Class Initialized
INFO - 2020-03-13 06:53:47 --> Helper loaded: url_helper
INFO - 2020-03-13 06:53:47 --> Helper loaded: file_helper
INFO - 2020-03-13 06:53:47 --> Helper loaded: form_helper
INFO - 2020-03-13 06:53:47 --> Helper loaded: my_helper
INFO - 2020-03-13 06:53:47 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:53:47 --> Controller Class Initialized
INFO - 2020-03-13 06:53:47 --> Helper loaded: cookie_helper
INFO - 2020-03-13 06:53:47 --> Config Class Initialized
INFO - 2020-03-13 06:53:47 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:53:48 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:53:48 --> Utf8 Class Initialized
INFO - 2020-03-13 06:53:48 --> URI Class Initialized
INFO - 2020-03-13 06:53:48 --> Router Class Initialized
INFO - 2020-03-13 06:53:48 --> Output Class Initialized
INFO - 2020-03-13 06:53:48 --> Security Class Initialized
DEBUG - 2020-03-13 06:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:53:48 --> Input Class Initialized
INFO - 2020-03-13 06:53:48 --> Language Class Initialized
INFO - 2020-03-13 06:53:48 --> Language Class Initialized
INFO - 2020-03-13 06:53:48 --> Config Class Initialized
INFO - 2020-03-13 06:53:48 --> Loader Class Initialized
INFO - 2020-03-13 06:53:48 --> Helper loaded: url_helper
INFO - 2020-03-13 06:53:48 --> Helper loaded: file_helper
INFO - 2020-03-13 06:53:48 --> Helper loaded: form_helper
INFO - 2020-03-13 06:53:48 --> Helper loaded: my_helper
INFO - 2020-03-13 06:53:48 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:53:48 --> Controller Class Initialized
INFO - 2020-03-13 06:53:48 --> Config Class Initialized
INFO - 2020-03-13 06:53:48 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:53:48 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:53:48 --> Utf8 Class Initialized
INFO - 2020-03-13 06:53:48 --> URI Class Initialized
INFO - 2020-03-13 06:53:48 --> Router Class Initialized
INFO - 2020-03-13 06:53:48 --> Output Class Initialized
INFO - 2020-03-13 06:53:48 --> Security Class Initialized
DEBUG - 2020-03-13 06:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:53:48 --> Input Class Initialized
INFO - 2020-03-13 06:53:48 --> Language Class Initialized
INFO - 2020-03-13 06:53:48 --> Language Class Initialized
INFO - 2020-03-13 06:53:48 --> Config Class Initialized
INFO - 2020-03-13 06:53:48 --> Loader Class Initialized
INFO - 2020-03-13 06:53:48 --> Helper loaded: url_helper
INFO - 2020-03-13 06:53:48 --> Helper loaded: file_helper
INFO - 2020-03-13 06:53:48 --> Helper loaded: form_helper
INFO - 2020-03-13 06:53:48 --> Helper loaded: my_helper
INFO - 2020-03-13 06:53:48 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:53:48 --> Controller Class Initialized
DEBUG - 2020-03-13 06:53:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-13 06:53:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-13 06:53:48 --> Final output sent to browser
DEBUG - 2020-03-13 06:53:48 --> Total execution time: 0.2936
INFO - 2020-03-13 06:54:08 --> Config Class Initialized
INFO - 2020-03-13 06:54:08 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:54:08 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:54:08 --> Utf8 Class Initialized
INFO - 2020-03-13 06:54:08 --> URI Class Initialized
INFO - 2020-03-13 06:54:08 --> Router Class Initialized
INFO - 2020-03-13 06:54:08 --> Output Class Initialized
INFO - 2020-03-13 06:54:08 --> Security Class Initialized
DEBUG - 2020-03-13 06:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:54:08 --> Input Class Initialized
INFO - 2020-03-13 06:54:08 --> Language Class Initialized
INFO - 2020-03-13 06:54:08 --> Language Class Initialized
INFO - 2020-03-13 06:54:08 --> Config Class Initialized
INFO - 2020-03-13 06:54:08 --> Loader Class Initialized
INFO - 2020-03-13 06:54:09 --> Helper loaded: url_helper
INFO - 2020-03-13 06:54:09 --> Helper loaded: file_helper
INFO - 2020-03-13 06:54:09 --> Helper loaded: form_helper
INFO - 2020-03-13 06:54:09 --> Helper loaded: my_helper
INFO - 2020-03-13 06:54:09 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:54:09 --> Controller Class Initialized
INFO - 2020-03-13 06:54:09 --> Helper loaded: cookie_helper
INFO - 2020-03-13 06:54:09 --> Final output sent to browser
DEBUG - 2020-03-13 06:54:09 --> Total execution time: 0.3742
INFO - 2020-03-13 06:54:09 --> Config Class Initialized
INFO - 2020-03-13 06:54:09 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:54:09 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:54:09 --> Utf8 Class Initialized
INFO - 2020-03-13 06:54:09 --> URI Class Initialized
INFO - 2020-03-13 06:54:09 --> Router Class Initialized
INFO - 2020-03-13 06:54:09 --> Output Class Initialized
INFO - 2020-03-13 06:54:09 --> Security Class Initialized
DEBUG - 2020-03-13 06:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:54:09 --> Input Class Initialized
INFO - 2020-03-13 06:54:09 --> Language Class Initialized
INFO - 2020-03-13 06:54:09 --> Language Class Initialized
INFO - 2020-03-13 06:54:09 --> Config Class Initialized
INFO - 2020-03-13 06:54:09 --> Loader Class Initialized
INFO - 2020-03-13 06:54:09 --> Helper loaded: url_helper
INFO - 2020-03-13 06:54:09 --> Helper loaded: file_helper
INFO - 2020-03-13 06:54:09 --> Helper loaded: form_helper
INFO - 2020-03-13 06:54:09 --> Helper loaded: my_helper
INFO - 2020-03-13 06:54:09 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:54:09 --> Controller Class Initialized
DEBUG - 2020-03-13 06:54:09 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-03-13 06:54:09 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-13 06:54:09 --> Final output sent to browser
DEBUG - 2020-03-13 06:54:09 --> Total execution time: 0.4991
INFO - 2020-03-13 06:54:13 --> Config Class Initialized
INFO - 2020-03-13 06:54:13 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:54:13 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:54:13 --> Utf8 Class Initialized
INFO - 2020-03-13 06:54:13 --> URI Class Initialized
INFO - 2020-03-13 06:54:13 --> Router Class Initialized
INFO - 2020-03-13 06:54:13 --> Output Class Initialized
INFO - 2020-03-13 06:54:13 --> Security Class Initialized
DEBUG - 2020-03-13 06:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:54:13 --> Input Class Initialized
INFO - 2020-03-13 06:54:13 --> Language Class Initialized
INFO - 2020-03-13 06:54:13 --> Language Class Initialized
INFO - 2020-03-13 06:54:13 --> Config Class Initialized
INFO - 2020-03-13 06:54:13 --> Loader Class Initialized
INFO - 2020-03-13 06:54:13 --> Helper loaded: url_helper
INFO - 2020-03-13 06:54:13 --> Helper loaded: file_helper
INFO - 2020-03-13 06:54:13 --> Helper loaded: form_helper
INFO - 2020-03-13 06:54:13 --> Helper loaded: my_helper
INFO - 2020-03-13 06:54:13 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:54:13 --> Controller Class Initialized
DEBUG - 2020-03-13 06:54:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2020-03-13 06:54:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-13 06:54:13 --> Final output sent to browser
DEBUG - 2020-03-13 06:54:13 --> Total execution time: 0.4306
INFO - 2020-03-13 06:54:14 --> Config Class Initialized
INFO - 2020-03-13 06:54:14 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:54:14 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:54:14 --> Utf8 Class Initialized
INFO - 2020-03-13 06:54:14 --> URI Class Initialized
INFO - 2020-03-13 06:54:14 --> Router Class Initialized
INFO - 2020-03-13 06:54:14 --> Output Class Initialized
INFO - 2020-03-13 06:54:14 --> Security Class Initialized
DEBUG - 2020-03-13 06:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:54:14 --> Input Class Initialized
INFO - 2020-03-13 06:54:15 --> Language Class Initialized
INFO - 2020-03-13 06:54:15 --> Language Class Initialized
INFO - 2020-03-13 06:54:15 --> Config Class Initialized
INFO - 2020-03-13 06:54:15 --> Loader Class Initialized
INFO - 2020-03-13 06:54:15 --> Helper loaded: url_helper
INFO - 2020-03-13 06:54:15 --> Helper loaded: file_helper
INFO - 2020-03-13 06:54:15 --> Helper loaded: form_helper
INFO - 2020-03-13 06:54:15 --> Helper loaded: my_helper
INFO - 2020-03-13 06:54:15 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:54:15 --> Controller Class Initialized
DEBUG - 2020-03-13 06:54:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/list.php
DEBUG - 2020-03-13 06:54:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-13 06:54:15 --> Final output sent to browser
DEBUG - 2020-03-13 06:54:15 --> Total execution time: 0.4866
INFO - 2020-03-13 06:54:18 --> Config Class Initialized
INFO - 2020-03-13 06:54:18 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:54:18 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:54:18 --> Utf8 Class Initialized
INFO - 2020-03-13 06:54:18 --> URI Class Initialized
INFO - 2020-03-13 06:54:18 --> Router Class Initialized
INFO - 2020-03-13 06:54:18 --> Output Class Initialized
INFO - 2020-03-13 06:54:18 --> Security Class Initialized
DEBUG - 2020-03-13 06:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:54:18 --> Input Class Initialized
INFO - 2020-03-13 06:54:18 --> Language Class Initialized
INFO - 2020-03-13 06:54:18 --> Language Class Initialized
INFO - 2020-03-13 06:54:18 --> Config Class Initialized
INFO - 2020-03-13 06:54:18 --> Loader Class Initialized
INFO - 2020-03-13 06:54:18 --> Helper loaded: url_helper
INFO - 2020-03-13 06:54:18 --> Helper loaded: file_helper
INFO - 2020-03-13 06:54:18 --> Helper loaded: form_helper
INFO - 2020-03-13 06:54:18 --> Helper loaded: my_helper
INFO - 2020-03-13 06:54:18 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:54:18 --> Controller Class Initialized
DEBUG - 2020-03-13 06:54:19 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/list.php
DEBUG - 2020-03-13 06:54:19 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-13 06:54:19 --> Final output sent to browser
DEBUG - 2020-03-13 06:54:19 --> Total execution time: 0.4325
INFO - 2020-03-13 06:54:24 --> Config Class Initialized
INFO - 2020-03-13 06:54:24 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:54:24 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:54:24 --> Utf8 Class Initialized
INFO - 2020-03-13 06:54:24 --> URI Class Initialized
INFO - 2020-03-13 06:54:24 --> Router Class Initialized
INFO - 2020-03-13 06:54:24 --> Output Class Initialized
INFO - 2020-03-13 06:54:24 --> Security Class Initialized
DEBUG - 2020-03-13 06:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:54:24 --> Input Class Initialized
INFO - 2020-03-13 06:54:24 --> Language Class Initialized
INFO - 2020-03-13 06:54:24 --> Language Class Initialized
INFO - 2020-03-13 06:54:24 --> Config Class Initialized
INFO - 2020-03-13 06:54:24 --> Loader Class Initialized
INFO - 2020-03-13 06:54:24 --> Helper loaded: url_helper
INFO - 2020-03-13 06:54:24 --> Helper loaded: file_helper
INFO - 2020-03-13 06:54:24 --> Helper loaded: form_helper
INFO - 2020-03-13 06:54:24 --> Helper loaded: my_helper
INFO - 2020-03-13 06:54:24 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:54:24 --> Controller Class Initialized
DEBUG - 2020-03-13 06:54:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-03-13 06:54:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-13 06:54:24 --> Final output sent to browser
DEBUG - 2020-03-13 06:54:24 --> Total execution time: 0.5674
INFO - 2020-03-13 06:54:28 --> Config Class Initialized
INFO - 2020-03-13 06:54:28 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:54:28 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:54:28 --> Utf8 Class Initialized
INFO - 2020-03-13 06:54:28 --> URI Class Initialized
INFO - 2020-03-13 06:54:28 --> Router Class Initialized
INFO - 2020-03-13 06:54:28 --> Output Class Initialized
INFO - 2020-03-13 06:54:28 --> Security Class Initialized
DEBUG - 2020-03-13 06:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:54:28 --> Input Class Initialized
INFO - 2020-03-13 06:54:28 --> Language Class Initialized
INFO - 2020-03-13 06:54:28 --> Language Class Initialized
INFO - 2020-03-13 06:54:28 --> Config Class Initialized
INFO - 2020-03-13 06:54:28 --> Loader Class Initialized
INFO - 2020-03-13 06:54:28 --> Helper loaded: url_helper
INFO - 2020-03-13 06:54:28 --> Helper loaded: file_helper
INFO - 2020-03-13 06:54:28 --> Helper loaded: form_helper
INFO - 2020-03-13 06:54:28 --> Helper loaded: my_helper
INFO - 2020-03-13 06:54:28 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:54:28 --> Controller Class Initialized
INFO - 2020-03-13 06:54:28 --> Helper loaded: cookie_helper
INFO - 2020-03-13 06:54:28 --> Config Class Initialized
INFO - 2020-03-13 06:54:28 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:54:28 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:54:28 --> Utf8 Class Initialized
INFO - 2020-03-13 06:54:28 --> URI Class Initialized
INFO - 2020-03-13 06:54:28 --> Router Class Initialized
INFO - 2020-03-13 06:54:28 --> Output Class Initialized
INFO - 2020-03-13 06:54:28 --> Security Class Initialized
DEBUG - 2020-03-13 06:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:54:29 --> Input Class Initialized
INFO - 2020-03-13 06:54:29 --> Language Class Initialized
INFO - 2020-03-13 06:54:29 --> Language Class Initialized
INFO - 2020-03-13 06:54:29 --> Config Class Initialized
INFO - 2020-03-13 06:54:29 --> Loader Class Initialized
INFO - 2020-03-13 06:54:29 --> Helper loaded: url_helper
INFO - 2020-03-13 06:54:29 --> Helper loaded: file_helper
INFO - 2020-03-13 06:54:29 --> Helper loaded: form_helper
INFO - 2020-03-13 06:54:29 --> Helper loaded: my_helper
INFO - 2020-03-13 06:54:29 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:54:29 --> Controller Class Initialized
INFO - 2020-03-13 06:54:29 --> Config Class Initialized
INFO - 2020-03-13 06:54:29 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:54:29 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:54:29 --> Utf8 Class Initialized
INFO - 2020-03-13 06:54:29 --> URI Class Initialized
INFO - 2020-03-13 06:54:29 --> Router Class Initialized
INFO - 2020-03-13 06:54:29 --> Output Class Initialized
INFO - 2020-03-13 06:54:29 --> Security Class Initialized
DEBUG - 2020-03-13 06:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:54:29 --> Input Class Initialized
INFO - 2020-03-13 06:54:29 --> Language Class Initialized
INFO - 2020-03-13 06:54:29 --> Language Class Initialized
INFO - 2020-03-13 06:54:29 --> Config Class Initialized
INFO - 2020-03-13 06:54:29 --> Loader Class Initialized
INFO - 2020-03-13 06:54:29 --> Helper loaded: url_helper
INFO - 2020-03-13 06:54:29 --> Helper loaded: file_helper
INFO - 2020-03-13 06:54:29 --> Helper loaded: form_helper
INFO - 2020-03-13 06:54:29 --> Helper loaded: my_helper
INFO - 2020-03-13 06:54:29 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:54:29 --> Controller Class Initialized
DEBUG - 2020-03-13 06:54:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-13 06:54:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-13 06:54:29 --> Final output sent to browser
DEBUG - 2020-03-13 06:54:29 --> Total execution time: 0.4701
INFO - 2020-03-13 06:54:36 --> Config Class Initialized
INFO - 2020-03-13 06:54:36 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:54:36 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:54:36 --> Utf8 Class Initialized
INFO - 2020-03-13 06:54:36 --> URI Class Initialized
INFO - 2020-03-13 06:54:36 --> Router Class Initialized
INFO - 2020-03-13 06:54:36 --> Output Class Initialized
INFO - 2020-03-13 06:54:36 --> Security Class Initialized
DEBUG - 2020-03-13 06:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:54:36 --> Input Class Initialized
INFO - 2020-03-13 06:54:36 --> Language Class Initialized
INFO - 2020-03-13 06:54:36 --> Language Class Initialized
INFO - 2020-03-13 06:54:36 --> Config Class Initialized
INFO - 2020-03-13 06:54:36 --> Loader Class Initialized
INFO - 2020-03-13 06:54:36 --> Helper loaded: url_helper
INFO - 2020-03-13 06:54:36 --> Helper loaded: file_helper
INFO - 2020-03-13 06:54:36 --> Helper loaded: form_helper
INFO - 2020-03-13 06:54:36 --> Helper loaded: my_helper
INFO - 2020-03-13 06:54:36 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:54:36 --> Controller Class Initialized
INFO - 2020-03-13 06:54:36 --> Helper loaded: cookie_helper
INFO - 2020-03-13 06:54:36 --> Final output sent to browser
DEBUG - 2020-03-13 06:54:36 --> Total execution time: 0.3298
INFO - 2020-03-13 06:54:36 --> Config Class Initialized
INFO - 2020-03-13 06:54:36 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:54:36 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:54:36 --> Utf8 Class Initialized
INFO - 2020-03-13 06:54:36 --> URI Class Initialized
INFO - 2020-03-13 06:54:36 --> Router Class Initialized
INFO - 2020-03-13 06:54:36 --> Output Class Initialized
INFO - 2020-03-13 06:54:36 --> Security Class Initialized
DEBUG - 2020-03-13 06:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:54:36 --> Input Class Initialized
INFO - 2020-03-13 06:54:36 --> Language Class Initialized
INFO - 2020-03-13 06:54:37 --> Language Class Initialized
INFO - 2020-03-13 06:54:37 --> Config Class Initialized
INFO - 2020-03-13 06:54:37 --> Loader Class Initialized
INFO - 2020-03-13 06:54:37 --> Helper loaded: url_helper
INFO - 2020-03-13 06:54:37 --> Helper loaded: file_helper
INFO - 2020-03-13 06:54:37 --> Helper loaded: form_helper
INFO - 2020-03-13 06:54:37 --> Helper loaded: my_helper
INFO - 2020-03-13 06:54:37 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:54:37 --> Controller Class Initialized
DEBUG - 2020-03-13 06:54:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-13 06:54:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-13 06:54:37 --> Final output sent to browser
DEBUG - 2020-03-13 06:54:37 --> Total execution time: 0.3672
INFO - 2020-03-13 06:54:40 --> Config Class Initialized
INFO - 2020-03-13 06:54:40 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:54:40 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:54:40 --> Utf8 Class Initialized
INFO - 2020-03-13 06:54:40 --> URI Class Initialized
INFO - 2020-03-13 06:54:40 --> Router Class Initialized
INFO - 2020-03-13 06:54:40 --> Output Class Initialized
INFO - 2020-03-13 06:54:40 --> Security Class Initialized
DEBUG - 2020-03-13 06:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:54:40 --> Input Class Initialized
INFO - 2020-03-13 06:54:40 --> Language Class Initialized
INFO - 2020-03-13 06:54:40 --> Language Class Initialized
INFO - 2020-03-13 06:54:40 --> Config Class Initialized
INFO - 2020-03-13 06:54:40 --> Loader Class Initialized
INFO - 2020-03-13 06:54:40 --> Helper loaded: url_helper
INFO - 2020-03-13 06:54:40 --> Helper loaded: file_helper
INFO - 2020-03-13 06:54:40 --> Helper loaded: form_helper
INFO - 2020-03-13 06:54:40 --> Helper loaded: my_helper
INFO - 2020-03-13 06:54:40 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:54:40 --> Controller Class Initialized
DEBUG - 2020-03-13 06:54:40 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-03-13 06:54:40 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-13 06:54:40 --> Final output sent to browser
DEBUG - 2020-03-13 06:54:40 --> Total execution time: 0.3223
INFO - 2020-03-13 06:54:42 --> Config Class Initialized
INFO - 2020-03-13 06:54:42 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:54:42 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:54:42 --> Utf8 Class Initialized
INFO - 2020-03-13 06:54:42 --> URI Class Initialized
INFO - 2020-03-13 06:54:42 --> Router Class Initialized
INFO - 2020-03-13 06:54:42 --> Output Class Initialized
INFO - 2020-03-13 06:54:42 --> Security Class Initialized
DEBUG - 2020-03-13 06:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:54:42 --> Input Class Initialized
INFO - 2020-03-13 06:54:42 --> Language Class Initialized
INFO - 2020-03-13 06:54:42 --> Language Class Initialized
INFO - 2020-03-13 06:54:42 --> Config Class Initialized
INFO - 2020-03-13 06:54:42 --> Loader Class Initialized
INFO - 2020-03-13 06:54:42 --> Helper loaded: url_helper
INFO - 2020-03-13 06:54:42 --> Helper loaded: file_helper
INFO - 2020-03-13 06:54:42 --> Helper loaded: form_helper
INFO - 2020-03-13 06:54:42 --> Helper loaded: my_helper
INFO - 2020-03-13 06:54:42 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:54:42 --> Controller Class Initialized
DEBUG - 2020-03-13 06:54:42 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/list.php
DEBUG - 2020-03-13 06:54:42 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-13 06:54:42 --> Final output sent to browser
DEBUG - 2020-03-13 06:54:42 --> Total execution time: 0.4818
INFO - 2020-03-13 06:54:43 --> Config Class Initialized
INFO - 2020-03-13 06:54:43 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:54:43 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:54:43 --> Utf8 Class Initialized
INFO - 2020-03-13 06:54:43 --> URI Class Initialized
INFO - 2020-03-13 06:54:43 --> Router Class Initialized
INFO - 2020-03-13 06:54:43 --> Output Class Initialized
INFO - 2020-03-13 06:54:43 --> Security Class Initialized
DEBUG - 2020-03-13 06:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:54:43 --> Input Class Initialized
INFO - 2020-03-13 06:54:43 --> Language Class Initialized
INFO - 2020-03-13 06:54:43 --> Language Class Initialized
INFO - 2020-03-13 06:54:43 --> Config Class Initialized
INFO - 2020-03-13 06:54:43 --> Loader Class Initialized
INFO - 2020-03-13 06:54:43 --> Helper loaded: url_helper
INFO - 2020-03-13 06:54:43 --> Helper loaded: file_helper
INFO - 2020-03-13 06:54:43 --> Helper loaded: form_helper
INFO - 2020-03-13 06:54:43 --> Helper loaded: my_helper
INFO - 2020-03-13 06:54:43 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:54:43 --> Controller Class Initialized
INFO - 2020-03-13 06:54:45 --> Config Class Initialized
INFO - 2020-03-13 06:54:45 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:54:45 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:54:45 --> Utf8 Class Initialized
INFO - 2020-03-13 06:54:45 --> URI Class Initialized
INFO - 2020-03-13 06:54:45 --> Router Class Initialized
INFO - 2020-03-13 06:54:45 --> Output Class Initialized
INFO - 2020-03-13 06:54:45 --> Security Class Initialized
DEBUG - 2020-03-13 06:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:54:45 --> Input Class Initialized
INFO - 2020-03-13 06:54:45 --> Language Class Initialized
INFO - 2020-03-13 06:54:45 --> Language Class Initialized
INFO - 2020-03-13 06:54:45 --> Config Class Initialized
INFO - 2020-03-13 06:54:45 --> Loader Class Initialized
INFO - 2020-03-13 06:54:45 --> Helper loaded: url_helper
INFO - 2020-03-13 06:54:46 --> Helper loaded: file_helper
INFO - 2020-03-13 06:54:46 --> Helper loaded: form_helper
INFO - 2020-03-13 06:54:46 --> Helper loaded: my_helper
INFO - 2020-03-13 06:54:46 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:54:46 --> Controller Class Initialized
DEBUG - 2020-03-13 06:54:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_walikelas/views/list.php
DEBUG - 2020-03-13 06:54:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-13 06:54:46 --> Final output sent to browser
DEBUG - 2020-03-13 06:54:46 --> Total execution time: 0.3412
INFO - 2020-03-13 06:54:46 --> Config Class Initialized
INFO - 2020-03-13 06:54:46 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:54:46 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:54:46 --> Utf8 Class Initialized
INFO - 2020-03-13 06:54:46 --> URI Class Initialized
INFO - 2020-03-13 06:54:46 --> Router Class Initialized
INFO - 2020-03-13 06:54:46 --> Output Class Initialized
INFO - 2020-03-13 06:54:46 --> Security Class Initialized
DEBUG - 2020-03-13 06:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:54:46 --> Input Class Initialized
INFO - 2020-03-13 06:54:46 --> Language Class Initialized
INFO - 2020-03-13 06:54:46 --> Language Class Initialized
INFO - 2020-03-13 06:54:46 --> Config Class Initialized
INFO - 2020-03-13 06:54:46 --> Loader Class Initialized
INFO - 2020-03-13 06:54:46 --> Helper loaded: url_helper
INFO - 2020-03-13 06:54:46 --> Helper loaded: file_helper
INFO - 2020-03-13 06:54:46 --> Helper loaded: form_helper
INFO - 2020-03-13 06:54:46 --> Helper loaded: my_helper
INFO - 2020-03-13 06:54:46 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:54:46 --> Controller Class Initialized
INFO - 2020-03-13 06:54:56 --> Config Class Initialized
INFO - 2020-03-13 06:54:56 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:54:56 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:54:56 --> Utf8 Class Initialized
INFO - 2020-03-13 06:54:56 --> URI Class Initialized
INFO - 2020-03-13 06:54:56 --> Router Class Initialized
INFO - 2020-03-13 06:54:56 --> Output Class Initialized
INFO - 2020-03-13 06:54:56 --> Security Class Initialized
DEBUG - 2020-03-13 06:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:54:56 --> Input Class Initialized
INFO - 2020-03-13 06:54:56 --> Language Class Initialized
INFO - 2020-03-13 06:54:56 --> Language Class Initialized
INFO - 2020-03-13 06:54:56 --> Config Class Initialized
INFO - 2020-03-13 06:54:56 --> Loader Class Initialized
INFO - 2020-03-13 06:54:56 --> Helper loaded: url_helper
INFO - 2020-03-13 06:54:56 --> Helper loaded: file_helper
INFO - 2020-03-13 06:54:56 --> Helper loaded: form_helper
INFO - 2020-03-13 06:54:56 --> Helper loaded: my_helper
INFO - 2020-03-13 06:54:56 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:54:56 --> Controller Class Initialized
DEBUG - 2020-03-13 06:54:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-03-13 06:54:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-13 06:54:56 --> Final output sent to browser
DEBUG - 2020-03-13 06:54:56 --> Total execution time: 0.5427
INFO - 2020-03-13 06:55:02 --> Config Class Initialized
INFO - 2020-03-13 06:55:02 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:55:02 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:55:02 --> Utf8 Class Initialized
INFO - 2020-03-13 06:55:02 --> URI Class Initialized
INFO - 2020-03-13 06:55:02 --> Router Class Initialized
INFO - 2020-03-13 06:55:03 --> Output Class Initialized
INFO - 2020-03-13 06:55:03 --> Security Class Initialized
DEBUG - 2020-03-13 06:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:55:03 --> Input Class Initialized
INFO - 2020-03-13 06:55:03 --> Language Class Initialized
INFO - 2020-03-13 06:55:03 --> Language Class Initialized
INFO - 2020-03-13 06:55:03 --> Config Class Initialized
INFO - 2020-03-13 06:55:03 --> Loader Class Initialized
INFO - 2020-03-13 06:55:03 --> Helper loaded: url_helper
INFO - 2020-03-13 06:55:03 --> Helper loaded: file_helper
INFO - 2020-03-13 06:55:03 --> Helper loaded: form_helper
INFO - 2020-03-13 06:55:03 --> Helper loaded: my_helper
INFO - 2020-03-13 06:55:03 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:55:03 --> Controller Class Initialized
DEBUG - 2020-03-13 06:55:03 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-03-13 06:55:03 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-13 06:55:03 --> Final output sent to browser
DEBUG - 2020-03-13 06:55:03 --> Total execution time: 0.4003
INFO - 2020-03-13 06:55:11 --> Config Class Initialized
INFO - 2020-03-13 06:55:11 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:55:11 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:55:11 --> Utf8 Class Initialized
INFO - 2020-03-13 06:55:11 --> URI Class Initialized
INFO - 2020-03-13 06:55:11 --> Router Class Initialized
INFO - 2020-03-13 06:55:11 --> Output Class Initialized
INFO - 2020-03-13 06:55:11 --> Security Class Initialized
DEBUG - 2020-03-13 06:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:55:11 --> Input Class Initialized
INFO - 2020-03-13 06:55:11 --> Language Class Initialized
INFO - 2020-03-13 06:55:11 --> Language Class Initialized
INFO - 2020-03-13 06:55:11 --> Config Class Initialized
INFO - 2020-03-13 06:55:11 --> Loader Class Initialized
INFO - 2020-03-13 06:55:11 --> Helper loaded: url_helper
INFO - 2020-03-13 06:55:11 --> Helper loaded: file_helper
INFO - 2020-03-13 06:55:11 --> Helper loaded: form_helper
INFO - 2020-03-13 06:55:11 --> Helper loaded: my_helper
INFO - 2020-03-13 06:55:11 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:55:11 --> Controller Class Initialized
DEBUG - 2020-03-13 06:55:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/list.php
DEBUG - 2020-03-13 06:55:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-13 06:55:12 --> Final output sent to browser
DEBUG - 2020-03-13 06:55:12 --> Total execution time: 0.4963
INFO - 2020-03-13 06:55:12 --> Config Class Initialized
INFO - 2020-03-13 06:55:12 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:55:12 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:55:12 --> Utf8 Class Initialized
INFO - 2020-03-13 06:55:12 --> URI Class Initialized
INFO - 2020-03-13 06:55:12 --> Router Class Initialized
INFO - 2020-03-13 06:55:12 --> Output Class Initialized
INFO - 2020-03-13 06:55:12 --> Security Class Initialized
DEBUG - 2020-03-13 06:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:55:12 --> Input Class Initialized
INFO - 2020-03-13 06:55:12 --> Language Class Initialized
INFO - 2020-03-13 06:55:12 --> Language Class Initialized
INFO - 2020-03-13 06:55:12 --> Config Class Initialized
INFO - 2020-03-13 06:55:12 --> Loader Class Initialized
INFO - 2020-03-13 06:55:12 --> Helper loaded: url_helper
INFO - 2020-03-13 06:55:12 --> Helper loaded: file_helper
INFO - 2020-03-13 06:55:12 --> Helper loaded: form_helper
INFO - 2020-03-13 06:55:12 --> Helper loaded: my_helper
INFO - 2020-03-13 06:55:12 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:55:12 --> Controller Class Initialized
INFO - 2020-03-13 06:55:12 --> Config Class Initialized
INFO - 2020-03-13 06:55:12 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:55:12 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:55:12 --> Utf8 Class Initialized
INFO - 2020-03-13 06:55:12 --> URI Class Initialized
INFO - 2020-03-13 06:55:12 --> Router Class Initialized
INFO - 2020-03-13 06:55:12 --> Output Class Initialized
INFO - 2020-03-13 06:55:12 --> Security Class Initialized
DEBUG - 2020-03-13 06:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:55:12 --> Input Class Initialized
INFO - 2020-03-13 06:55:12 --> Language Class Initialized
INFO - 2020-03-13 06:55:12 --> Language Class Initialized
INFO - 2020-03-13 06:55:12 --> Config Class Initialized
INFO - 2020-03-13 06:55:12 --> Loader Class Initialized
INFO - 2020-03-13 06:55:12 --> Helper loaded: url_helper
INFO - 2020-03-13 06:55:13 --> Helper loaded: file_helper
INFO - 2020-03-13 06:55:13 --> Helper loaded: form_helper
INFO - 2020-03-13 06:55:13 --> Helper loaded: my_helper
INFO - 2020-03-13 06:55:13 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:55:13 --> Controller Class Initialized
DEBUG - 2020-03-13 06:55:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-03-13 06:55:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-13 06:55:13 --> Final output sent to browser
DEBUG - 2020-03-13 06:55:13 --> Total execution time: 0.5342
INFO - 2020-03-13 06:55:15 --> Config Class Initialized
INFO - 2020-03-13 06:55:15 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:55:15 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:55:15 --> Utf8 Class Initialized
INFO - 2020-03-13 06:55:16 --> URI Class Initialized
INFO - 2020-03-13 06:55:16 --> Router Class Initialized
INFO - 2020-03-13 06:55:16 --> Output Class Initialized
INFO - 2020-03-13 06:55:16 --> Security Class Initialized
DEBUG - 2020-03-13 06:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:55:16 --> Input Class Initialized
INFO - 2020-03-13 06:55:16 --> Language Class Initialized
INFO - 2020-03-13 06:55:16 --> Language Class Initialized
INFO - 2020-03-13 06:55:16 --> Config Class Initialized
INFO - 2020-03-13 06:55:16 --> Loader Class Initialized
INFO - 2020-03-13 06:55:16 --> Helper loaded: url_helper
INFO - 2020-03-13 06:55:16 --> Helper loaded: file_helper
INFO - 2020-03-13 06:55:16 --> Helper loaded: form_helper
INFO - 2020-03-13 06:55:16 --> Helper loaded: my_helper
INFO - 2020-03-13 06:55:16 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:55:16 --> Controller Class Initialized
INFO - 2020-03-13 06:55:16 --> Final output sent to browser
DEBUG - 2020-03-13 06:55:16 --> Total execution time: 0.5352
INFO - 2020-03-13 06:55:18 --> Config Class Initialized
INFO - 2020-03-13 06:55:18 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:55:18 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:55:18 --> Utf8 Class Initialized
INFO - 2020-03-13 06:55:18 --> URI Class Initialized
INFO - 2020-03-13 06:55:18 --> Router Class Initialized
INFO - 2020-03-13 06:55:18 --> Output Class Initialized
INFO - 2020-03-13 06:55:18 --> Security Class Initialized
DEBUG - 2020-03-13 06:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:55:18 --> Input Class Initialized
INFO - 2020-03-13 06:55:19 --> Language Class Initialized
INFO - 2020-03-13 06:55:19 --> Language Class Initialized
INFO - 2020-03-13 06:55:19 --> Config Class Initialized
INFO - 2020-03-13 06:55:19 --> Loader Class Initialized
INFO - 2020-03-13 06:55:19 --> Helper loaded: url_helper
INFO - 2020-03-13 06:55:19 --> Helper loaded: file_helper
INFO - 2020-03-13 06:55:19 --> Helper loaded: form_helper
INFO - 2020-03-13 06:55:19 --> Helper loaded: my_helper
INFO - 2020-03-13 06:55:19 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:55:19 --> Controller Class Initialized
INFO - 2020-03-13 06:55:19 --> Final output sent to browser
DEBUG - 2020-03-13 06:55:19 --> Total execution time: 0.3634
INFO - 2020-03-13 06:55:21 --> Config Class Initialized
INFO - 2020-03-13 06:55:21 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:55:21 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:55:21 --> Utf8 Class Initialized
INFO - 2020-03-13 06:55:21 --> URI Class Initialized
INFO - 2020-03-13 06:55:21 --> Router Class Initialized
INFO - 2020-03-13 06:55:21 --> Output Class Initialized
INFO - 2020-03-13 06:55:21 --> Security Class Initialized
DEBUG - 2020-03-13 06:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:55:21 --> Input Class Initialized
INFO - 2020-03-13 06:55:21 --> Language Class Initialized
INFO - 2020-03-13 06:55:21 --> Language Class Initialized
INFO - 2020-03-13 06:55:21 --> Config Class Initialized
INFO - 2020-03-13 06:55:21 --> Loader Class Initialized
INFO - 2020-03-13 06:55:21 --> Helper loaded: url_helper
INFO - 2020-03-13 06:55:21 --> Helper loaded: file_helper
INFO - 2020-03-13 06:55:21 --> Helper loaded: form_helper
INFO - 2020-03-13 06:55:21 --> Helper loaded: my_helper
INFO - 2020-03-13 06:55:21 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:55:22 --> Controller Class Initialized
INFO - 2020-03-13 06:55:22 --> Final output sent to browser
DEBUG - 2020-03-13 06:55:22 --> Total execution time: 0.3718
INFO - 2020-03-13 06:55:22 --> Config Class Initialized
INFO - 2020-03-13 06:55:22 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:55:22 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:55:22 --> Utf8 Class Initialized
INFO - 2020-03-13 06:55:22 --> URI Class Initialized
INFO - 2020-03-13 06:55:22 --> Router Class Initialized
INFO - 2020-03-13 06:55:22 --> Output Class Initialized
INFO - 2020-03-13 06:55:23 --> Security Class Initialized
DEBUG - 2020-03-13 06:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:55:23 --> Input Class Initialized
INFO - 2020-03-13 06:55:23 --> Language Class Initialized
INFO - 2020-03-13 06:55:23 --> Language Class Initialized
INFO - 2020-03-13 06:55:23 --> Config Class Initialized
INFO - 2020-03-13 06:55:23 --> Loader Class Initialized
INFO - 2020-03-13 06:55:23 --> Helper loaded: url_helper
INFO - 2020-03-13 06:55:23 --> Helper loaded: file_helper
INFO - 2020-03-13 06:55:23 --> Helper loaded: form_helper
INFO - 2020-03-13 06:55:23 --> Helper loaded: my_helper
INFO - 2020-03-13 06:55:23 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:55:23 --> Controller Class Initialized
DEBUG - 2020-03-13 06:55:23 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-03-13 06:55:23 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-13 06:55:23 --> Final output sent to browser
DEBUG - 2020-03-13 06:55:23 --> Total execution time: 0.4105
INFO - 2020-03-13 06:55:25 --> Config Class Initialized
INFO - 2020-03-13 06:55:25 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:55:25 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:55:25 --> Utf8 Class Initialized
INFO - 2020-03-13 06:55:25 --> URI Class Initialized
INFO - 2020-03-13 06:55:25 --> Router Class Initialized
INFO - 2020-03-13 06:55:25 --> Output Class Initialized
INFO - 2020-03-13 06:55:26 --> Security Class Initialized
DEBUG - 2020-03-13 06:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:55:26 --> Input Class Initialized
INFO - 2020-03-13 06:55:26 --> Language Class Initialized
INFO - 2020-03-13 06:55:26 --> Language Class Initialized
INFO - 2020-03-13 06:55:26 --> Config Class Initialized
INFO - 2020-03-13 06:55:26 --> Loader Class Initialized
INFO - 2020-03-13 06:55:26 --> Helper loaded: url_helper
INFO - 2020-03-13 06:55:26 --> Helper loaded: file_helper
INFO - 2020-03-13 06:55:26 --> Helper loaded: form_helper
INFO - 2020-03-13 06:55:26 --> Helper loaded: my_helper
INFO - 2020-03-13 06:55:26 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:55:26 --> Controller Class Initialized
INFO - 2020-03-13 06:55:26 --> Final output sent to browser
DEBUG - 2020-03-13 06:55:26 --> Total execution time: 0.3686
INFO - 2020-03-13 06:55:28 --> Config Class Initialized
INFO - 2020-03-13 06:55:28 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:55:28 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:55:28 --> Utf8 Class Initialized
INFO - 2020-03-13 06:55:28 --> URI Class Initialized
INFO - 2020-03-13 06:55:28 --> Router Class Initialized
INFO - 2020-03-13 06:55:28 --> Output Class Initialized
INFO - 2020-03-13 06:55:28 --> Security Class Initialized
DEBUG - 2020-03-13 06:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:55:28 --> Input Class Initialized
INFO - 2020-03-13 06:55:28 --> Language Class Initialized
INFO - 2020-03-13 06:55:28 --> Language Class Initialized
INFO - 2020-03-13 06:55:28 --> Config Class Initialized
INFO - 2020-03-13 06:55:28 --> Loader Class Initialized
INFO - 2020-03-13 06:55:28 --> Helper loaded: url_helper
INFO - 2020-03-13 06:55:28 --> Helper loaded: file_helper
INFO - 2020-03-13 06:55:28 --> Helper loaded: form_helper
INFO - 2020-03-13 06:55:28 --> Helper loaded: my_helper
INFO - 2020-03-13 06:55:28 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:55:28 --> Controller Class Initialized
INFO - 2020-03-13 06:55:28 --> Final output sent to browser
DEBUG - 2020-03-13 06:55:28 --> Total execution time: 0.3943
INFO - 2020-03-13 06:55:29 --> Config Class Initialized
INFO - 2020-03-13 06:55:29 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:55:29 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:55:29 --> Utf8 Class Initialized
INFO - 2020-03-13 06:55:29 --> URI Class Initialized
INFO - 2020-03-13 06:55:30 --> Router Class Initialized
INFO - 2020-03-13 06:55:30 --> Output Class Initialized
INFO - 2020-03-13 06:55:30 --> Security Class Initialized
DEBUG - 2020-03-13 06:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:55:30 --> Input Class Initialized
INFO - 2020-03-13 06:55:30 --> Language Class Initialized
INFO - 2020-03-13 06:55:30 --> Language Class Initialized
INFO - 2020-03-13 06:55:30 --> Config Class Initialized
INFO - 2020-03-13 06:55:30 --> Loader Class Initialized
INFO - 2020-03-13 06:55:30 --> Helper loaded: url_helper
INFO - 2020-03-13 06:55:30 --> Helper loaded: file_helper
INFO - 2020-03-13 06:55:30 --> Helper loaded: form_helper
INFO - 2020-03-13 06:55:30 --> Helper loaded: my_helper
INFO - 2020-03-13 06:55:30 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:55:30 --> Controller Class Initialized
INFO - 2020-03-13 06:55:30 --> Final output sent to browser
DEBUG - 2020-03-13 06:55:30 --> Total execution time: 0.4236
INFO - 2020-03-13 06:55:30 --> Config Class Initialized
INFO - 2020-03-13 06:55:30 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:55:30 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:55:30 --> Utf8 Class Initialized
INFO - 2020-03-13 06:55:30 --> URI Class Initialized
INFO - 2020-03-13 06:55:30 --> Router Class Initialized
INFO - 2020-03-13 06:55:30 --> Output Class Initialized
INFO - 2020-03-13 06:55:30 --> Security Class Initialized
DEBUG - 2020-03-13 06:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:55:30 --> Input Class Initialized
INFO - 2020-03-13 06:55:30 --> Language Class Initialized
INFO - 2020-03-13 06:55:31 --> Language Class Initialized
INFO - 2020-03-13 06:55:31 --> Config Class Initialized
INFO - 2020-03-13 06:55:31 --> Loader Class Initialized
INFO - 2020-03-13 06:55:31 --> Helper loaded: url_helper
INFO - 2020-03-13 06:55:31 --> Helper loaded: file_helper
INFO - 2020-03-13 06:55:31 --> Helper loaded: form_helper
INFO - 2020-03-13 06:55:31 --> Helper loaded: my_helper
INFO - 2020-03-13 06:55:31 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:55:31 --> Controller Class Initialized
DEBUG - 2020-03-13 06:55:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-03-13 06:55:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-13 06:55:31 --> Final output sent to browser
DEBUG - 2020-03-13 06:55:31 --> Total execution time: 0.4761
INFO - 2020-03-13 06:55:34 --> Config Class Initialized
INFO - 2020-03-13 06:55:34 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:55:34 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:55:34 --> Utf8 Class Initialized
INFO - 2020-03-13 06:55:34 --> URI Class Initialized
INFO - 2020-03-13 06:55:34 --> Router Class Initialized
INFO - 2020-03-13 06:55:34 --> Output Class Initialized
INFO - 2020-03-13 06:55:34 --> Security Class Initialized
DEBUG - 2020-03-13 06:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:55:34 --> Input Class Initialized
INFO - 2020-03-13 06:55:34 --> Language Class Initialized
INFO - 2020-03-13 06:55:34 --> Language Class Initialized
INFO - 2020-03-13 06:55:34 --> Config Class Initialized
INFO - 2020-03-13 06:55:34 --> Loader Class Initialized
INFO - 2020-03-13 06:55:34 --> Helper loaded: url_helper
INFO - 2020-03-13 06:55:34 --> Helper loaded: file_helper
INFO - 2020-03-13 06:55:34 --> Helper loaded: form_helper
INFO - 2020-03-13 06:55:34 --> Helper loaded: my_helper
INFO - 2020-03-13 06:55:34 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:55:34 --> Controller Class Initialized
ERROR - 2020-03-13 06:55:34 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-13 06:55:34 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-13 06:55:34 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-13 06:55:34 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
DEBUG - 2020-03-13 06:55:34 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-03-13 06:55:34 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-13 06:55:34 --> Final output sent to browser
DEBUG - 2020-03-13 06:55:34 --> Total execution time: 0.3819
INFO - 2020-03-13 06:55:45 --> Config Class Initialized
INFO - 2020-03-13 06:55:45 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:55:46 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:55:46 --> Utf8 Class Initialized
INFO - 2020-03-13 06:55:46 --> URI Class Initialized
INFO - 2020-03-13 06:55:46 --> Router Class Initialized
INFO - 2020-03-13 06:55:46 --> Output Class Initialized
INFO - 2020-03-13 06:55:46 --> Security Class Initialized
DEBUG - 2020-03-13 06:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:55:46 --> Input Class Initialized
INFO - 2020-03-13 06:55:46 --> Language Class Initialized
INFO - 2020-03-13 06:55:46 --> Language Class Initialized
INFO - 2020-03-13 06:55:46 --> Config Class Initialized
INFO - 2020-03-13 06:55:46 --> Loader Class Initialized
INFO - 2020-03-13 06:55:46 --> Helper loaded: url_helper
INFO - 2020-03-13 06:55:46 --> Helper loaded: file_helper
INFO - 2020-03-13 06:55:46 --> Helper loaded: form_helper
INFO - 2020-03-13 06:55:46 --> Helper loaded: my_helper
INFO - 2020-03-13 06:55:46 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:55:46 --> Controller Class Initialized
INFO - 2020-03-13 06:55:46 --> Config Class Initialized
INFO - 2020-03-13 06:55:46 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:55:46 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:55:46 --> Utf8 Class Initialized
INFO - 2020-03-13 06:55:46 --> URI Class Initialized
INFO - 2020-03-13 06:55:46 --> Router Class Initialized
INFO - 2020-03-13 06:55:46 --> Output Class Initialized
INFO - 2020-03-13 06:55:46 --> Security Class Initialized
DEBUG - 2020-03-13 06:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:55:46 --> Input Class Initialized
INFO - 2020-03-13 06:55:46 --> Language Class Initialized
INFO - 2020-03-13 06:55:46 --> Language Class Initialized
INFO - 2020-03-13 06:55:46 --> Config Class Initialized
INFO - 2020-03-13 06:55:46 --> Loader Class Initialized
INFO - 2020-03-13 06:55:46 --> Helper loaded: url_helper
INFO - 2020-03-13 06:55:46 --> Helper loaded: file_helper
INFO - 2020-03-13 06:55:46 --> Helper loaded: form_helper
INFO - 2020-03-13 06:55:46 --> Helper loaded: my_helper
INFO - 2020-03-13 06:55:46 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:55:46 --> Controller Class Initialized
DEBUG - 2020-03-13 06:55:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-03-13 06:55:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-13 06:55:46 --> Final output sent to browser
DEBUG - 2020-03-13 06:55:46 --> Total execution time: 0.3239
INFO - 2020-03-13 06:55:49 --> Config Class Initialized
INFO - 2020-03-13 06:55:49 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:55:49 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:55:49 --> Utf8 Class Initialized
INFO - 2020-03-13 06:55:49 --> URI Class Initialized
INFO - 2020-03-13 06:55:49 --> Router Class Initialized
INFO - 2020-03-13 06:55:49 --> Output Class Initialized
INFO - 2020-03-13 06:55:49 --> Security Class Initialized
DEBUG - 2020-03-13 06:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:55:49 --> Input Class Initialized
INFO - 2020-03-13 06:55:49 --> Language Class Initialized
INFO - 2020-03-13 06:55:49 --> Language Class Initialized
INFO - 2020-03-13 06:55:49 --> Config Class Initialized
INFO - 2020-03-13 06:55:49 --> Loader Class Initialized
INFO - 2020-03-13 06:55:49 --> Helper loaded: url_helper
INFO - 2020-03-13 06:55:49 --> Helper loaded: file_helper
INFO - 2020-03-13 06:55:49 --> Helper loaded: form_helper
INFO - 2020-03-13 06:55:49 --> Helper loaded: my_helper
INFO - 2020-03-13 06:55:49 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:55:49 --> Controller Class Initialized
INFO - 2020-03-13 06:55:49 --> Helper loaded: cookie_helper
INFO - 2020-03-13 06:55:49 --> Config Class Initialized
INFO - 2020-03-13 06:55:49 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:55:49 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:55:49 --> Utf8 Class Initialized
INFO - 2020-03-13 06:55:49 --> URI Class Initialized
INFO - 2020-03-13 06:55:49 --> Router Class Initialized
INFO - 2020-03-13 06:55:49 --> Output Class Initialized
INFO - 2020-03-13 06:55:49 --> Security Class Initialized
DEBUG - 2020-03-13 06:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:55:49 --> Input Class Initialized
INFO - 2020-03-13 06:55:49 --> Language Class Initialized
INFO - 2020-03-13 06:55:49 --> Language Class Initialized
INFO - 2020-03-13 06:55:49 --> Config Class Initialized
INFO - 2020-03-13 06:55:49 --> Loader Class Initialized
INFO - 2020-03-13 06:55:49 --> Helper loaded: url_helper
INFO - 2020-03-13 06:55:49 --> Helper loaded: file_helper
INFO - 2020-03-13 06:55:49 --> Helper loaded: form_helper
INFO - 2020-03-13 06:55:49 --> Helper loaded: my_helper
INFO - 2020-03-13 06:55:49 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:55:49 --> Controller Class Initialized
INFO - 2020-03-13 06:55:49 --> Config Class Initialized
INFO - 2020-03-13 06:55:49 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:55:49 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:55:49 --> Utf8 Class Initialized
INFO - 2020-03-13 06:55:49 --> URI Class Initialized
INFO - 2020-03-13 06:55:49 --> Router Class Initialized
INFO - 2020-03-13 06:55:49 --> Output Class Initialized
INFO - 2020-03-13 06:55:49 --> Security Class Initialized
DEBUG - 2020-03-13 06:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:55:49 --> Input Class Initialized
INFO - 2020-03-13 06:55:49 --> Language Class Initialized
INFO - 2020-03-13 06:55:50 --> Language Class Initialized
INFO - 2020-03-13 06:55:50 --> Config Class Initialized
INFO - 2020-03-13 06:55:50 --> Loader Class Initialized
INFO - 2020-03-13 06:55:50 --> Helper loaded: url_helper
INFO - 2020-03-13 06:55:50 --> Helper loaded: file_helper
INFO - 2020-03-13 06:55:50 --> Helper loaded: form_helper
INFO - 2020-03-13 06:55:50 --> Helper loaded: my_helper
INFO - 2020-03-13 06:55:50 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:55:50 --> Controller Class Initialized
DEBUG - 2020-03-13 06:55:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-13 06:55:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-13 06:55:50 --> Final output sent to browser
DEBUG - 2020-03-13 06:55:50 --> Total execution time: 0.3407
INFO - 2020-03-13 06:55:57 --> Config Class Initialized
INFO - 2020-03-13 06:55:57 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:55:57 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:55:57 --> Utf8 Class Initialized
INFO - 2020-03-13 06:55:57 --> URI Class Initialized
INFO - 2020-03-13 06:55:57 --> Router Class Initialized
INFO - 2020-03-13 06:55:57 --> Output Class Initialized
INFO - 2020-03-13 06:55:57 --> Security Class Initialized
DEBUG - 2020-03-13 06:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:55:57 --> Input Class Initialized
INFO - 2020-03-13 06:55:57 --> Language Class Initialized
INFO - 2020-03-13 06:55:57 --> Language Class Initialized
INFO - 2020-03-13 06:55:57 --> Config Class Initialized
INFO - 2020-03-13 06:55:57 --> Loader Class Initialized
INFO - 2020-03-13 06:55:57 --> Helper loaded: url_helper
INFO - 2020-03-13 06:55:57 --> Helper loaded: file_helper
INFO - 2020-03-13 06:55:57 --> Helper loaded: form_helper
INFO - 2020-03-13 06:55:57 --> Helper loaded: my_helper
INFO - 2020-03-13 06:55:57 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:55:57 --> Controller Class Initialized
INFO - 2020-03-13 06:55:57 --> Helper loaded: cookie_helper
INFO - 2020-03-13 06:55:57 --> Final output sent to browser
DEBUG - 2020-03-13 06:55:57 --> Total execution time: 0.3351
INFO - 2020-03-13 06:55:57 --> Config Class Initialized
INFO - 2020-03-13 06:55:57 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:55:57 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:55:57 --> Utf8 Class Initialized
INFO - 2020-03-13 06:55:57 --> URI Class Initialized
INFO - 2020-03-13 06:55:57 --> Router Class Initialized
INFO - 2020-03-13 06:55:57 --> Output Class Initialized
INFO - 2020-03-13 06:55:57 --> Security Class Initialized
DEBUG - 2020-03-13 06:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:55:57 --> Input Class Initialized
INFO - 2020-03-13 06:55:57 --> Language Class Initialized
INFO - 2020-03-13 06:55:57 --> Language Class Initialized
INFO - 2020-03-13 06:55:57 --> Config Class Initialized
INFO - 2020-03-13 06:55:57 --> Loader Class Initialized
INFO - 2020-03-13 06:55:57 --> Helper loaded: url_helper
INFO - 2020-03-13 06:55:57 --> Helper loaded: file_helper
INFO - 2020-03-13 06:55:57 --> Helper loaded: form_helper
INFO - 2020-03-13 06:55:57 --> Helper loaded: my_helper
INFO - 2020-03-13 06:55:57 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:55:57 --> Controller Class Initialized
DEBUG - 2020-03-13 06:55:57 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-03-13 06:55:57 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-13 06:55:57 --> Final output sent to browser
DEBUG - 2020-03-13 06:55:57 --> Total execution time: 0.3777
INFO - 2020-03-13 06:56:00 --> Config Class Initialized
INFO - 2020-03-13 06:56:00 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:56:00 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:56:00 --> Utf8 Class Initialized
INFO - 2020-03-13 06:56:00 --> URI Class Initialized
INFO - 2020-03-13 06:56:00 --> Router Class Initialized
INFO - 2020-03-13 06:56:00 --> Output Class Initialized
INFO - 2020-03-13 06:56:00 --> Security Class Initialized
DEBUG - 2020-03-13 06:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:56:00 --> Input Class Initialized
INFO - 2020-03-13 06:56:00 --> Language Class Initialized
INFO - 2020-03-13 06:56:00 --> Language Class Initialized
INFO - 2020-03-13 06:56:00 --> Config Class Initialized
INFO - 2020-03-13 06:56:00 --> Loader Class Initialized
INFO - 2020-03-13 06:56:00 --> Helper loaded: url_helper
INFO - 2020-03-13 06:56:00 --> Helper loaded: file_helper
INFO - 2020-03-13 06:56:00 --> Helper loaded: form_helper
INFO - 2020-03-13 06:56:00 --> Helper loaded: my_helper
INFO - 2020-03-13 06:56:00 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:56:00 --> Controller Class Initialized
DEBUG - 2020-03-13 06:56:00 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/list.php
DEBUG - 2020-03-13 06:56:00 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-13 06:56:00 --> Final output sent to browser
DEBUG - 2020-03-13 06:56:00 --> Total execution time: 0.3454
INFO - 2020-03-13 06:56:02 --> Config Class Initialized
INFO - 2020-03-13 06:56:02 --> Hooks Class Initialized
DEBUG - 2020-03-13 06:56:02 --> UTF-8 Support Enabled
INFO - 2020-03-13 06:56:02 --> Utf8 Class Initialized
INFO - 2020-03-13 06:56:02 --> URI Class Initialized
INFO - 2020-03-13 06:56:02 --> Router Class Initialized
INFO - 2020-03-13 06:56:02 --> Output Class Initialized
INFO - 2020-03-13 06:56:03 --> Security Class Initialized
DEBUG - 2020-03-13 06:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-13 06:56:03 --> Input Class Initialized
INFO - 2020-03-13 06:56:03 --> Language Class Initialized
INFO - 2020-03-13 06:56:03 --> Language Class Initialized
INFO - 2020-03-13 06:56:03 --> Config Class Initialized
INFO - 2020-03-13 06:56:03 --> Loader Class Initialized
INFO - 2020-03-13 06:56:03 --> Helper loaded: url_helper
INFO - 2020-03-13 06:56:03 --> Helper loaded: file_helper
INFO - 2020-03-13 06:56:03 --> Helper loaded: form_helper
INFO - 2020-03-13 06:56:03 --> Helper loaded: my_helper
INFO - 2020-03-13 06:56:03 --> Database Driver Class Initialized
DEBUG - 2020-03-13 06:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-13 06:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-13 06:56:03 --> Controller Class Initialized
DEBUG - 2020-03-13 06:56:03 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-03-13 06:56:03 --> Final output sent to browser
DEBUG - 2020-03-13 06:56:03 --> Total execution time: 0.6656
