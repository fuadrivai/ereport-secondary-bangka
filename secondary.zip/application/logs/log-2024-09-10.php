<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-10 08:02:48 --> Config Class Initialized
INFO - 2024-09-10 08:02:48 --> Hooks Class Initialized
DEBUG - 2024-09-10 08:02:48 --> UTF-8 Support Enabled
INFO - 2024-09-10 08:02:48 --> Utf8 Class Initialized
INFO - 2024-09-10 08:02:48 --> URI Class Initialized
INFO - 2024-09-10 08:02:48 --> Router Class Initialized
INFO - 2024-09-10 08:02:48 --> Output Class Initialized
INFO - 2024-09-10 08:02:48 --> Security Class Initialized
DEBUG - 2024-09-10 08:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 08:02:48 --> Input Class Initialized
INFO - 2024-09-10 08:02:48 --> Language Class Initialized
INFO - 2024-09-10 08:02:48 --> Language Class Initialized
INFO - 2024-09-10 08:02:48 --> Config Class Initialized
INFO - 2024-09-10 08:02:48 --> Loader Class Initialized
INFO - 2024-09-10 08:02:48 --> Helper loaded: url_helper
INFO - 2024-09-10 08:02:48 --> Helper loaded: file_helper
INFO - 2024-09-10 08:02:48 --> Helper loaded: form_helper
INFO - 2024-09-10 08:02:48 --> Helper loaded: my_helper
INFO - 2024-09-10 08:02:48 --> Database Driver Class Initialized
INFO - 2024-09-10 08:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 08:02:48 --> Controller Class Initialized
INFO - 2024-09-10 08:02:48 --> Helper loaded: cookie_helper
INFO - 2024-09-10 08:02:48 --> Final output sent to browser
DEBUG - 2024-09-10 08:02:48 --> Total execution time: 0.0889
INFO - 2024-09-10 08:02:49 --> Config Class Initialized
INFO - 2024-09-10 08:02:49 --> Hooks Class Initialized
DEBUG - 2024-09-10 08:02:49 --> UTF-8 Support Enabled
INFO - 2024-09-10 08:02:49 --> Utf8 Class Initialized
INFO - 2024-09-10 08:02:49 --> URI Class Initialized
INFO - 2024-09-10 08:02:49 --> Router Class Initialized
INFO - 2024-09-10 08:02:49 --> Output Class Initialized
INFO - 2024-09-10 08:02:49 --> Security Class Initialized
DEBUG - 2024-09-10 08:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 08:02:49 --> Input Class Initialized
INFO - 2024-09-10 08:02:49 --> Language Class Initialized
INFO - 2024-09-10 08:02:49 --> Language Class Initialized
INFO - 2024-09-10 08:02:49 --> Config Class Initialized
INFO - 2024-09-10 08:02:49 --> Loader Class Initialized
INFO - 2024-09-10 08:02:49 --> Helper loaded: url_helper
INFO - 2024-09-10 08:02:49 --> Helper loaded: file_helper
INFO - 2024-09-10 08:02:49 --> Helper loaded: form_helper
INFO - 2024-09-10 08:02:49 --> Helper loaded: my_helper
INFO - 2024-09-10 08:02:49 --> Database Driver Class Initialized
INFO - 2024-09-10 08:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 08:02:49 --> Controller Class Initialized
INFO - 2024-09-10 08:02:49 --> Helper loaded: cookie_helper
INFO - 2024-09-10 08:02:49 --> Config Class Initialized
INFO - 2024-09-10 08:02:49 --> Hooks Class Initialized
DEBUG - 2024-09-10 08:02:49 --> UTF-8 Support Enabled
INFO - 2024-09-10 08:02:49 --> Utf8 Class Initialized
INFO - 2024-09-10 08:02:49 --> URI Class Initialized
INFO - 2024-09-10 08:02:49 --> Router Class Initialized
INFO - 2024-09-10 08:02:49 --> Output Class Initialized
INFO - 2024-09-10 08:02:49 --> Security Class Initialized
DEBUG - 2024-09-10 08:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 08:02:49 --> Input Class Initialized
INFO - 2024-09-10 08:02:49 --> Language Class Initialized
INFO - 2024-09-10 08:02:49 --> Language Class Initialized
INFO - 2024-09-10 08:02:49 --> Config Class Initialized
INFO - 2024-09-10 08:02:49 --> Loader Class Initialized
INFO - 2024-09-10 08:02:49 --> Helper loaded: url_helper
INFO - 2024-09-10 08:02:49 --> Helper loaded: file_helper
INFO - 2024-09-10 08:02:49 --> Helper loaded: form_helper
INFO - 2024-09-10 08:02:49 --> Helper loaded: my_helper
INFO - 2024-09-10 08:02:49 --> Database Driver Class Initialized
INFO - 2024-09-10 08:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 08:02:49 --> Controller Class Initialized
DEBUG - 2024-09-10 08:02:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-10 08:02:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-10 08:02:49 --> Final output sent to browser
DEBUG - 2024-09-10 08:02:49 --> Total execution time: 0.0395
INFO - 2024-09-10 12:08:20 --> Config Class Initialized
INFO - 2024-09-10 12:08:20 --> Hooks Class Initialized
DEBUG - 2024-09-10 12:08:20 --> UTF-8 Support Enabled
INFO - 2024-09-10 12:08:20 --> Utf8 Class Initialized
INFO - 2024-09-10 12:08:20 --> URI Class Initialized
INFO - 2024-09-10 12:08:20 --> Router Class Initialized
INFO - 2024-09-10 12:08:20 --> Output Class Initialized
INFO - 2024-09-10 12:08:20 --> Security Class Initialized
DEBUG - 2024-09-10 12:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 12:08:20 --> Input Class Initialized
INFO - 2024-09-10 12:08:20 --> Language Class Initialized
INFO - 2024-09-10 12:08:20 --> Language Class Initialized
INFO - 2024-09-10 12:08:20 --> Config Class Initialized
INFO - 2024-09-10 12:08:20 --> Loader Class Initialized
INFO - 2024-09-10 12:08:20 --> Helper loaded: url_helper
INFO - 2024-09-10 12:08:20 --> Helper loaded: file_helper
INFO - 2024-09-10 12:08:20 --> Helper loaded: form_helper
INFO - 2024-09-10 12:08:20 --> Helper loaded: my_helper
INFO - 2024-09-10 12:08:20 --> Database Driver Class Initialized
INFO - 2024-09-10 12:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 12:08:20 --> Controller Class Initialized
INFO - 2024-09-10 12:08:20 --> Helper loaded: cookie_helper
INFO - 2024-09-10 12:08:20 --> Final output sent to browser
DEBUG - 2024-09-10 12:08:20 --> Total execution time: 0.0559
INFO - 2024-09-10 12:08:22 --> Config Class Initialized
INFO - 2024-09-10 12:08:22 --> Hooks Class Initialized
DEBUG - 2024-09-10 12:08:22 --> UTF-8 Support Enabled
INFO - 2024-09-10 12:08:22 --> Utf8 Class Initialized
INFO - 2024-09-10 12:08:22 --> URI Class Initialized
INFO - 2024-09-10 12:08:22 --> Router Class Initialized
INFO - 2024-09-10 12:08:22 --> Output Class Initialized
INFO - 2024-09-10 12:08:22 --> Security Class Initialized
DEBUG - 2024-09-10 12:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 12:08:22 --> Input Class Initialized
INFO - 2024-09-10 12:08:22 --> Language Class Initialized
INFO - 2024-09-10 12:08:22 --> Language Class Initialized
INFO - 2024-09-10 12:08:22 --> Config Class Initialized
INFO - 2024-09-10 12:08:22 --> Loader Class Initialized
INFO - 2024-09-10 12:08:22 --> Helper loaded: url_helper
INFO - 2024-09-10 12:08:22 --> Helper loaded: file_helper
INFO - 2024-09-10 12:08:22 --> Helper loaded: form_helper
INFO - 2024-09-10 12:08:22 --> Helper loaded: my_helper
INFO - 2024-09-10 12:08:22 --> Database Driver Class Initialized
INFO - 2024-09-10 12:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 12:08:22 --> Controller Class Initialized
INFO - 2024-09-10 12:08:22 --> Helper loaded: cookie_helper
INFO - 2024-09-10 12:08:22 --> Config Class Initialized
INFO - 2024-09-10 12:08:22 --> Hooks Class Initialized
DEBUG - 2024-09-10 12:08:22 --> UTF-8 Support Enabled
INFO - 2024-09-10 12:08:22 --> Utf8 Class Initialized
INFO - 2024-09-10 12:08:22 --> URI Class Initialized
INFO - 2024-09-10 12:08:22 --> Router Class Initialized
INFO - 2024-09-10 12:08:22 --> Output Class Initialized
INFO - 2024-09-10 12:08:22 --> Security Class Initialized
DEBUG - 2024-09-10 12:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 12:08:22 --> Input Class Initialized
INFO - 2024-09-10 12:08:22 --> Language Class Initialized
INFO - 2024-09-10 12:08:22 --> Language Class Initialized
INFO - 2024-09-10 12:08:22 --> Config Class Initialized
INFO - 2024-09-10 12:08:22 --> Loader Class Initialized
INFO - 2024-09-10 12:08:22 --> Helper loaded: url_helper
INFO - 2024-09-10 12:08:22 --> Helper loaded: file_helper
INFO - 2024-09-10 12:08:22 --> Helper loaded: form_helper
INFO - 2024-09-10 12:08:22 --> Helper loaded: my_helper
INFO - 2024-09-10 12:08:22 --> Database Driver Class Initialized
INFO - 2024-09-10 12:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 12:08:22 --> Controller Class Initialized
DEBUG - 2024-09-10 12:08:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-10 12:08:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-10 12:08:22 --> Final output sent to browser
DEBUG - 2024-09-10 12:08:22 --> Total execution time: 0.0421
INFO - 2024-09-10 12:08:37 --> Config Class Initialized
INFO - 2024-09-10 12:08:37 --> Hooks Class Initialized
DEBUG - 2024-09-10 12:08:37 --> UTF-8 Support Enabled
INFO - 2024-09-10 12:08:37 --> Utf8 Class Initialized
INFO - 2024-09-10 12:08:37 --> URI Class Initialized
INFO - 2024-09-10 12:08:37 --> Router Class Initialized
INFO - 2024-09-10 12:08:37 --> Output Class Initialized
INFO - 2024-09-10 12:08:37 --> Security Class Initialized
DEBUG - 2024-09-10 12:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 12:08:37 --> Input Class Initialized
INFO - 2024-09-10 12:08:37 --> Language Class Initialized
INFO - 2024-09-10 12:08:37 --> Language Class Initialized
INFO - 2024-09-10 12:08:37 --> Config Class Initialized
INFO - 2024-09-10 12:08:37 --> Loader Class Initialized
INFO - 2024-09-10 12:08:37 --> Helper loaded: url_helper
INFO - 2024-09-10 12:08:37 --> Helper loaded: file_helper
INFO - 2024-09-10 12:08:37 --> Helper loaded: form_helper
INFO - 2024-09-10 12:08:37 --> Helper loaded: my_helper
INFO - 2024-09-10 12:08:37 --> Database Driver Class Initialized
INFO - 2024-09-10 12:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 12:08:37 --> Controller Class Initialized
DEBUG - 2024-09-10 12:08:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-09-10 12:08:40 --> Final output sent to browser
DEBUG - 2024-09-10 12:08:40 --> Total execution time: 3.4643
INFO - 2024-09-10 12:08:40 --> Config Class Initialized
INFO - 2024-09-10 12:08:40 --> Hooks Class Initialized
DEBUG - 2024-09-10 12:08:40 --> UTF-8 Support Enabled
INFO - 2024-09-10 12:08:40 --> Utf8 Class Initialized
INFO - 2024-09-10 12:08:40 --> URI Class Initialized
INFO - 2024-09-10 12:08:40 --> Router Class Initialized
INFO - 2024-09-10 12:08:40 --> Output Class Initialized
INFO - 2024-09-10 12:08:40 --> Security Class Initialized
DEBUG - 2024-09-10 12:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 12:08:40 --> Input Class Initialized
INFO - 2024-09-10 12:08:40 --> Language Class Initialized
INFO - 2024-09-10 12:08:40 --> Language Class Initialized
INFO - 2024-09-10 12:08:40 --> Config Class Initialized
INFO - 2024-09-10 12:08:40 --> Loader Class Initialized
INFO - 2024-09-10 12:08:40 --> Helper loaded: url_helper
INFO - 2024-09-10 12:08:40 --> Helper loaded: file_helper
INFO - 2024-09-10 12:08:40 --> Helper loaded: form_helper
INFO - 2024-09-10 12:08:40 --> Helper loaded: my_helper
INFO - 2024-09-10 12:08:40 --> Database Driver Class Initialized
INFO - 2024-09-10 12:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 12:08:40 --> Controller Class Initialized
DEBUG - 2024-09-10 12:08:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-09-10 12:08:44 --> Final output sent to browser
DEBUG - 2024-09-10 12:08:44 --> Total execution time: 3.4902
INFO - 2024-09-10 12:08:44 --> Config Class Initialized
INFO - 2024-09-10 12:08:44 --> Hooks Class Initialized
DEBUG - 2024-09-10 12:08:44 --> UTF-8 Support Enabled
INFO - 2024-09-10 12:08:44 --> Utf8 Class Initialized
INFO - 2024-09-10 12:08:44 --> URI Class Initialized
INFO - 2024-09-10 12:08:44 --> Router Class Initialized
INFO - 2024-09-10 12:08:44 --> Output Class Initialized
INFO - 2024-09-10 12:08:44 --> Security Class Initialized
DEBUG - 2024-09-10 12:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 12:08:44 --> Input Class Initialized
INFO - 2024-09-10 12:08:44 --> Language Class Initialized
INFO - 2024-09-10 12:08:44 --> Language Class Initialized
INFO - 2024-09-10 12:08:44 --> Config Class Initialized
INFO - 2024-09-10 12:08:44 --> Loader Class Initialized
INFO - 2024-09-10 12:08:44 --> Helper loaded: url_helper
INFO - 2024-09-10 12:08:44 --> Helper loaded: file_helper
INFO - 2024-09-10 12:08:44 --> Helper loaded: form_helper
INFO - 2024-09-10 12:08:44 --> Helper loaded: my_helper
INFO - 2024-09-10 12:08:44 --> Database Driver Class Initialized
INFO - 2024-09-10 12:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 12:08:44 --> Controller Class Initialized
DEBUG - 2024-09-10 12:08:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-09-10 12:08:47 --> Final output sent to browser
DEBUG - 2024-09-10 12:08:47 --> Total execution time: 3.4048
INFO - 2024-09-10 12:08:47 --> Config Class Initialized
INFO - 2024-09-10 12:08:47 --> Hooks Class Initialized
DEBUG - 2024-09-10 12:08:47 --> UTF-8 Support Enabled
INFO - 2024-09-10 12:08:47 --> Utf8 Class Initialized
INFO - 2024-09-10 12:08:47 --> URI Class Initialized
INFO - 2024-09-10 12:08:47 --> Router Class Initialized
INFO - 2024-09-10 12:08:47 --> Output Class Initialized
INFO - 2024-09-10 12:08:47 --> Security Class Initialized
DEBUG - 2024-09-10 12:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 12:08:47 --> Input Class Initialized
INFO - 2024-09-10 12:08:47 --> Language Class Initialized
INFO - 2024-09-10 12:08:47 --> Language Class Initialized
INFO - 2024-09-10 12:08:47 --> Config Class Initialized
INFO - 2024-09-10 12:08:47 --> Loader Class Initialized
INFO - 2024-09-10 12:08:47 --> Helper loaded: url_helper
INFO - 2024-09-10 12:08:47 --> Helper loaded: file_helper
INFO - 2024-09-10 12:08:47 --> Helper loaded: form_helper
INFO - 2024-09-10 12:08:47 --> Helper loaded: my_helper
INFO - 2024-09-10 12:08:47 --> Database Driver Class Initialized
INFO - 2024-09-10 12:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 12:08:47 --> Controller Class Initialized
DEBUG - 2024-09-10 12:08:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-09-10 12:08:51 --> Final output sent to browser
DEBUG - 2024-09-10 12:08:51 --> Total execution time: 3.7545
INFO - 2024-09-10 12:08:51 --> Config Class Initialized
INFO - 2024-09-10 12:08:51 --> Hooks Class Initialized
DEBUG - 2024-09-10 12:08:51 --> UTF-8 Support Enabled
INFO - 2024-09-10 12:08:51 --> Utf8 Class Initialized
INFO - 2024-09-10 12:08:51 --> URI Class Initialized
INFO - 2024-09-10 12:08:51 --> Router Class Initialized
INFO - 2024-09-10 12:08:51 --> Output Class Initialized
INFO - 2024-09-10 12:08:51 --> Security Class Initialized
DEBUG - 2024-09-10 12:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 12:08:51 --> Input Class Initialized
INFO - 2024-09-10 12:08:51 --> Language Class Initialized
INFO - 2024-09-10 12:08:51 --> Language Class Initialized
INFO - 2024-09-10 12:08:51 --> Config Class Initialized
INFO - 2024-09-10 12:08:51 --> Loader Class Initialized
INFO - 2024-09-10 12:08:51 --> Helper loaded: url_helper
INFO - 2024-09-10 12:08:51 --> Helper loaded: file_helper
INFO - 2024-09-10 12:08:51 --> Helper loaded: form_helper
INFO - 2024-09-10 12:08:51 --> Helper loaded: my_helper
INFO - 2024-09-10 12:08:51 --> Database Driver Class Initialized
INFO - 2024-09-10 12:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 12:08:51 --> Controller Class Initialized
DEBUG - 2024-09-10 12:08:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-09-10 12:08:54 --> Final output sent to browser
DEBUG - 2024-09-10 12:08:54 --> Total execution time: 3.2375
INFO - 2024-09-10 12:08:55 --> Config Class Initialized
INFO - 2024-09-10 12:08:55 --> Hooks Class Initialized
DEBUG - 2024-09-10 12:08:55 --> UTF-8 Support Enabled
INFO - 2024-09-10 12:08:55 --> Utf8 Class Initialized
INFO - 2024-09-10 12:08:55 --> URI Class Initialized
INFO - 2024-09-10 12:08:55 --> Router Class Initialized
INFO - 2024-09-10 12:08:55 --> Output Class Initialized
INFO - 2024-09-10 12:08:55 --> Security Class Initialized
DEBUG - 2024-09-10 12:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 12:08:55 --> Input Class Initialized
INFO - 2024-09-10 12:08:55 --> Language Class Initialized
INFO - 2024-09-10 12:08:55 --> Language Class Initialized
INFO - 2024-09-10 12:08:55 --> Config Class Initialized
INFO - 2024-09-10 12:08:55 --> Loader Class Initialized
INFO - 2024-09-10 12:08:55 --> Helper loaded: url_helper
INFO - 2024-09-10 12:08:55 --> Helper loaded: file_helper
INFO - 2024-09-10 12:08:55 --> Helper loaded: form_helper
INFO - 2024-09-10 12:08:55 --> Helper loaded: my_helper
INFO - 2024-09-10 12:08:55 --> Database Driver Class Initialized
INFO - 2024-09-10 12:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 12:08:55 --> Controller Class Initialized
DEBUG - 2024-09-10 12:08:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-09-10 12:08:58 --> Final output sent to browser
DEBUG - 2024-09-10 12:08:58 --> Total execution time: 3.8472
INFO - 2024-09-10 12:08:59 --> Config Class Initialized
INFO - 2024-09-10 12:08:59 --> Hooks Class Initialized
DEBUG - 2024-09-10 12:08:59 --> UTF-8 Support Enabled
INFO - 2024-09-10 12:08:59 --> Utf8 Class Initialized
INFO - 2024-09-10 12:08:59 --> URI Class Initialized
INFO - 2024-09-10 12:08:59 --> Router Class Initialized
INFO - 2024-09-10 12:08:59 --> Output Class Initialized
INFO - 2024-09-10 12:08:59 --> Security Class Initialized
DEBUG - 2024-09-10 12:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 12:08:59 --> Input Class Initialized
INFO - 2024-09-10 12:08:59 --> Language Class Initialized
INFO - 2024-09-10 12:08:59 --> Language Class Initialized
INFO - 2024-09-10 12:08:59 --> Config Class Initialized
INFO - 2024-09-10 12:08:59 --> Loader Class Initialized
INFO - 2024-09-10 12:08:59 --> Helper loaded: url_helper
INFO - 2024-09-10 12:08:59 --> Helper loaded: file_helper
INFO - 2024-09-10 12:08:59 --> Helper loaded: form_helper
INFO - 2024-09-10 12:08:59 --> Helper loaded: my_helper
INFO - 2024-09-10 12:08:59 --> Database Driver Class Initialized
INFO - 2024-09-10 12:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 12:08:59 --> Controller Class Initialized
DEBUG - 2024-09-10 12:08:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-09-10 12:28:50 --> Config Class Initialized
INFO - 2024-09-10 12:28:50 --> Hooks Class Initialized
DEBUG - 2024-09-10 12:28:50 --> UTF-8 Support Enabled
INFO - 2024-09-10 12:28:50 --> Utf8 Class Initialized
INFO - 2024-09-10 12:28:50 --> URI Class Initialized
INFO - 2024-09-10 12:28:50 --> Router Class Initialized
INFO - 2024-09-10 12:28:50 --> Output Class Initialized
INFO - 2024-09-10 12:28:50 --> Security Class Initialized
DEBUG - 2024-09-10 12:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 12:28:50 --> Input Class Initialized
INFO - 2024-09-10 12:28:50 --> Language Class Initialized
INFO - 2024-09-10 12:28:50 --> Language Class Initialized
INFO - 2024-09-10 12:28:50 --> Config Class Initialized
INFO - 2024-09-10 12:28:50 --> Loader Class Initialized
INFO - 2024-09-10 12:28:50 --> Helper loaded: url_helper
INFO - 2024-09-10 12:28:50 --> Helper loaded: file_helper
INFO - 2024-09-10 12:28:50 --> Helper loaded: form_helper
INFO - 2024-09-10 12:28:50 --> Helper loaded: my_helper
INFO - 2024-09-10 12:28:50 --> Database Driver Class Initialized
INFO - 2024-09-10 12:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 12:28:50 --> Controller Class Initialized
INFO - 2024-09-10 12:28:50 --> Helper loaded: cookie_helper
INFO - 2024-09-10 12:28:50 --> Final output sent to browser
DEBUG - 2024-09-10 12:28:50 --> Total execution time: 0.0737
INFO - 2024-09-10 12:28:51 --> Config Class Initialized
INFO - 2024-09-10 12:28:51 --> Hooks Class Initialized
DEBUG - 2024-09-10 12:28:51 --> UTF-8 Support Enabled
INFO - 2024-09-10 12:28:51 --> Utf8 Class Initialized
INFO - 2024-09-10 12:28:51 --> URI Class Initialized
INFO - 2024-09-10 12:28:51 --> Router Class Initialized
INFO - 2024-09-10 12:28:51 --> Output Class Initialized
INFO - 2024-09-10 12:28:51 --> Security Class Initialized
DEBUG - 2024-09-10 12:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 12:28:51 --> Input Class Initialized
INFO - 2024-09-10 12:28:51 --> Language Class Initialized
INFO - 2024-09-10 12:28:51 --> Language Class Initialized
INFO - 2024-09-10 12:28:51 --> Config Class Initialized
INFO - 2024-09-10 12:28:51 --> Loader Class Initialized
INFO - 2024-09-10 12:28:51 --> Helper loaded: url_helper
INFO - 2024-09-10 12:28:51 --> Helper loaded: file_helper
INFO - 2024-09-10 12:28:51 --> Helper loaded: form_helper
INFO - 2024-09-10 12:28:51 --> Helper loaded: my_helper
INFO - 2024-09-10 12:28:51 --> Database Driver Class Initialized
INFO - 2024-09-10 12:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 12:28:51 --> Controller Class Initialized
INFO - 2024-09-10 12:28:51 --> Helper loaded: cookie_helper
INFO - 2024-09-10 12:28:51 --> Config Class Initialized
INFO - 2024-09-10 12:28:51 --> Hooks Class Initialized
DEBUG - 2024-09-10 12:28:51 --> UTF-8 Support Enabled
INFO - 2024-09-10 12:28:51 --> Utf8 Class Initialized
INFO - 2024-09-10 12:28:51 --> URI Class Initialized
INFO - 2024-09-10 12:28:51 --> Router Class Initialized
INFO - 2024-09-10 12:28:51 --> Output Class Initialized
INFO - 2024-09-10 12:28:51 --> Security Class Initialized
DEBUG - 2024-09-10 12:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 12:28:51 --> Input Class Initialized
INFO - 2024-09-10 12:28:51 --> Language Class Initialized
INFO - 2024-09-10 12:28:51 --> Language Class Initialized
INFO - 2024-09-10 12:28:51 --> Config Class Initialized
INFO - 2024-09-10 12:28:51 --> Loader Class Initialized
INFO - 2024-09-10 12:28:51 --> Helper loaded: url_helper
INFO - 2024-09-10 12:28:51 --> Helper loaded: file_helper
INFO - 2024-09-10 12:28:51 --> Helper loaded: form_helper
INFO - 2024-09-10 12:28:51 --> Helper loaded: my_helper
INFO - 2024-09-10 12:28:51 --> Database Driver Class Initialized
INFO - 2024-09-10 12:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 12:28:51 --> Controller Class Initialized
DEBUG - 2024-09-10 12:28:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-10 12:28:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-10 12:28:51 --> Final output sent to browser
DEBUG - 2024-09-10 12:28:51 --> Total execution time: 0.0290
INFO - 2024-09-10 12:54:08 --> Config Class Initialized
INFO - 2024-09-10 12:54:08 --> Hooks Class Initialized
DEBUG - 2024-09-10 12:54:08 --> UTF-8 Support Enabled
INFO - 2024-09-10 12:54:08 --> Utf8 Class Initialized
INFO - 2024-09-10 12:54:08 --> URI Class Initialized
INFO - 2024-09-10 12:54:08 --> Router Class Initialized
INFO - 2024-09-10 12:54:08 --> Output Class Initialized
INFO - 2024-09-10 12:54:08 --> Security Class Initialized
DEBUG - 2024-09-10 12:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 12:54:08 --> Input Class Initialized
INFO - 2024-09-10 12:54:08 --> Language Class Initialized
INFO - 2024-09-10 12:54:08 --> Language Class Initialized
INFO - 2024-09-10 12:54:08 --> Config Class Initialized
INFO - 2024-09-10 12:54:08 --> Loader Class Initialized
INFO - 2024-09-10 12:54:08 --> Helper loaded: url_helper
INFO - 2024-09-10 12:54:08 --> Helper loaded: file_helper
INFO - 2024-09-10 12:54:08 --> Helper loaded: form_helper
INFO - 2024-09-10 12:54:08 --> Helper loaded: my_helper
INFO - 2024-09-10 12:54:08 --> Database Driver Class Initialized
INFO - 2024-09-10 12:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 12:54:08 --> Controller Class Initialized
INFO - 2024-09-10 12:54:08 --> Helper loaded: cookie_helper
INFO - 2024-09-10 12:54:08 --> Final output sent to browser
DEBUG - 2024-09-10 12:54:08 --> Total execution time: 0.1219
INFO - 2024-09-10 12:54:09 --> Config Class Initialized
INFO - 2024-09-10 12:54:09 --> Hooks Class Initialized
DEBUG - 2024-09-10 12:54:09 --> UTF-8 Support Enabled
INFO - 2024-09-10 12:54:09 --> Utf8 Class Initialized
INFO - 2024-09-10 12:54:09 --> URI Class Initialized
INFO - 2024-09-10 12:54:09 --> Router Class Initialized
INFO - 2024-09-10 12:54:09 --> Output Class Initialized
INFO - 2024-09-10 12:54:09 --> Security Class Initialized
DEBUG - 2024-09-10 12:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 12:54:09 --> Input Class Initialized
INFO - 2024-09-10 12:54:09 --> Language Class Initialized
INFO - 2024-09-10 12:54:09 --> Language Class Initialized
INFO - 2024-09-10 12:54:09 --> Config Class Initialized
INFO - 2024-09-10 12:54:09 --> Loader Class Initialized
INFO - 2024-09-10 12:54:09 --> Helper loaded: url_helper
INFO - 2024-09-10 12:54:09 --> Helper loaded: file_helper
INFO - 2024-09-10 12:54:09 --> Helper loaded: form_helper
INFO - 2024-09-10 12:54:09 --> Helper loaded: my_helper
INFO - 2024-09-10 12:54:09 --> Database Driver Class Initialized
INFO - 2024-09-10 12:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 12:54:09 --> Controller Class Initialized
INFO - 2024-09-10 12:54:09 --> Helper loaded: cookie_helper
INFO - 2024-09-10 12:54:09 --> Config Class Initialized
INFO - 2024-09-10 12:54:09 --> Hooks Class Initialized
DEBUG - 2024-09-10 12:54:09 --> UTF-8 Support Enabled
INFO - 2024-09-10 12:54:09 --> Utf8 Class Initialized
INFO - 2024-09-10 12:54:09 --> URI Class Initialized
INFO - 2024-09-10 12:54:09 --> Router Class Initialized
INFO - 2024-09-10 12:54:09 --> Output Class Initialized
INFO - 2024-09-10 12:54:09 --> Security Class Initialized
DEBUG - 2024-09-10 12:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 12:54:09 --> Input Class Initialized
INFO - 2024-09-10 12:54:09 --> Language Class Initialized
INFO - 2024-09-10 12:54:09 --> Language Class Initialized
INFO - 2024-09-10 12:54:09 --> Config Class Initialized
INFO - 2024-09-10 12:54:09 --> Loader Class Initialized
INFO - 2024-09-10 12:54:09 --> Helper loaded: url_helper
INFO - 2024-09-10 12:54:09 --> Helper loaded: file_helper
INFO - 2024-09-10 12:54:09 --> Helper loaded: form_helper
INFO - 2024-09-10 12:54:09 --> Helper loaded: my_helper
INFO - 2024-09-10 12:54:09 --> Database Driver Class Initialized
INFO - 2024-09-10 12:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 12:54:09 --> Controller Class Initialized
DEBUG - 2024-09-10 12:54:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-10 12:54:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-10 12:54:09 --> Final output sent to browser
DEBUG - 2024-09-10 12:54:09 --> Total execution time: 0.0444
INFO - 2024-09-10 17:11:06 --> Config Class Initialized
INFO - 2024-09-10 17:11:06 --> Hooks Class Initialized
DEBUG - 2024-09-10 17:11:06 --> UTF-8 Support Enabled
INFO - 2024-09-10 17:11:06 --> Utf8 Class Initialized
INFO - 2024-09-10 17:11:06 --> URI Class Initialized
INFO - 2024-09-10 17:11:06 --> Router Class Initialized
INFO - 2024-09-10 17:11:06 --> Output Class Initialized
INFO - 2024-09-10 17:11:06 --> Security Class Initialized
DEBUG - 2024-09-10 17:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 17:11:06 --> Input Class Initialized
INFO - 2024-09-10 17:11:06 --> Language Class Initialized
INFO - 2024-09-10 17:11:06 --> Language Class Initialized
INFO - 2024-09-10 17:11:06 --> Config Class Initialized
INFO - 2024-09-10 17:11:06 --> Loader Class Initialized
INFO - 2024-09-10 17:11:06 --> Helper loaded: url_helper
INFO - 2024-09-10 17:11:06 --> Helper loaded: file_helper
INFO - 2024-09-10 17:11:06 --> Helper loaded: form_helper
INFO - 2024-09-10 17:11:06 --> Helper loaded: my_helper
INFO - 2024-09-10 17:11:06 --> Database Driver Class Initialized
INFO - 2024-09-10 17:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 17:11:06 --> Controller Class Initialized
INFO - 2024-09-10 17:11:06 --> Helper loaded: cookie_helper
INFO - 2024-09-10 17:11:06 --> Final output sent to browser
DEBUG - 2024-09-10 17:11:06 --> Total execution time: 0.0553
INFO - 2024-09-10 17:11:07 --> Config Class Initialized
INFO - 2024-09-10 17:11:07 --> Hooks Class Initialized
DEBUG - 2024-09-10 17:11:07 --> UTF-8 Support Enabled
INFO - 2024-09-10 17:11:07 --> Utf8 Class Initialized
INFO - 2024-09-10 17:11:07 --> URI Class Initialized
INFO - 2024-09-10 17:11:07 --> Router Class Initialized
INFO - 2024-09-10 17:11:07 --> Output Class Initialized
INFO - 2024-09-10 17:11:07 --> Security Class Initialized
DEBUG - 2024-09-10 17:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 17:11:07 --> Input Class Initialized
INFO - 2024-09-10 17:11:07 --> Language Class Initialized
INFO - 2024-09-10 17:11:07 --> Language Class Initialized
INFO - 2024-09-10 17:11:07 --> Config Class Initialized
INFO - 2024-09-10 17:11:07 --> Loader Class Initialized
INFO - 2024-09-10 17:11:07 --> Helper loaded: url_helper
INFO - 2024-09-10 17:11:07 --> Helper loaded: file_helper
INFO - 2024-09-10 17:11:07 --> Helper loaded: form_helper
INFO - 2024-09-10 17:11:07 --> Helper loaded: my_helper
INFO - 2024-09-10 17:11:07 --> Database Driver Class Initialized
INFO - 2024-09-10 17:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 17:11:07 --> Controller Class Initialized
INFO - 2024-09-10 17:11:07 --> Helper loaded: cookie_helper
INFO - 2024-09-10 17:11:07 --> Config Class Initialized
INFO - 2024-09-10 17:11:07 --> Hooks Class Initialized
DEBUG - 2024-09-10 17:11:07 --> UTF-8 Support Enabled
INFO - 2024-09-10 17:11:07 --> Utf8 Class Initialized
INFO - 2024-09-10 17:11:07 --> URI Class Initialized
INFO - 2024-09-10 17:11:07 --> Router Class Initialized
INFO - 2024-09-10 17:11:07 --> Output Class Initialized
INFO - 2024-09-10 17:11:07 --> Security Class Initialized
DEBUG - 2024-09-10 17:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 17:11:07 --> Input Class Initialized
INFO - 2024-09-10 17:11:07 --> Language Class Initialized
INFO - 2024-09-10 17:11:07 --> Language Class Initialized
INFO - 2024-09-10 17:11:07 --> Config Class Initialized
INFO - 2024-09-10 17:11:07 --> Loader Class Initialized
INFO - 2024-09-10 17:11:07 --> Helper loaded: url_helper
INFO - 2024-09-10 17:11:07 --> Helper loaded: file_helper
INFO - 2024-09-10 17:11:07 --> Helper loaded: form_helper
INFO - 2024-09-10 17:11:07 --> Helper loaded: my_helper
INFO - 2024-09-10 17:11:07 --> Database Driver Class Initialized
INFO - 2024-09-10 17:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 17:11:07 --> Controller Class Initialized
DEBUG - 2024-09-10 17:11:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-10 17:11:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-10 17:11:07 --> Final output sent to browser
DEBUG - 2024-09-10 17:11:07 --> Total execution time: 0.0375
INFO - 2024-09-10 17:11:13 --> Config Class Initialized
INFO - 2024-09-10 17:11:13 --> Hooks Class Initialized
DEBUG - 2024-09-10 17:11:13 --> UTF-8 Support Enabled
INFO - 2024-09-10 17:11:13 --> Utf8 Class Initialized
INFO - 2024-09-10 17:11:13 --> URI Class Initialized
INFO - 2024-09-10 17:11:13 --> Router Class Initialized
INFO - 2024-09-10 17:11:13 --> Output Class Initialized
INFO - 2024-09-10 17:11:13 --> Security Class Initialized
DEBUG - 2024-09-10 17:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 17:11:13 --> Input Class Initialized
INFO - 2024-09-10 17:11:13 --> Language Class Initialized
INFO - 2024-09-10 17:11:13 --> Language Class Initialized
INFO - 2024-09-10 17:11:13 --> Config Class Initialized
INFO - 2024-09-10 17:11:13 --> Loader Class Initialized
INFO - 2024-09-10 17:11:13 --> Helper loaded: url_helper
INFO - 2024-09-10 17:11:13 --> Helper loaded: file_helper
INFO - 2024-09-10 17:11:13 --> Helper loaded: form_helper
INFO - 2024-09-10 17:11:13 --> Helper loaded: my_helper
INFO - 2024-09-10 17:11:13 --> Database Driver Class Initialized
INFO - 2024-09-10 17:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 17:11:13 --> Controller Class Initialized
DEBUG - 2024-09-10 17:11:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-09-10 17:11:16 --> Config Class Initialized
INFO - 2024-09-10 17:11:16 --> Hooks Class Initialized
DEBUG - 2024-09-10 17:11:16 --> UTF-8 Support Enabled
INFO - 2024-09-10 17:11:16 --> Utf8 Class Initialized
INFO - 2024-09-10 17:11:16 --> URI Class Initialized
INFO - 2024-09-10 17:11:16 --> Router Class Initialized
INFO - 2024-09-10 17:11:16 --> Output Class Initialized
INFO - 2024-09-10 17:11:16 --> Security Class Initialized
DEBUG - 2024-09-10 17:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 17:11:16 --> Input Class Initialized
INFO - 2024-09-10 17:11:16 --> Language Class Initialized
INFO - 2024-09-10 17:11:16 --> Language Class Initialized
INFO - 2024-09-10 17:11:16 --> Config Class Initialized
INFO - 2024-09-10 17:11:16 --> Loader Class Initialized
INFO - 2024-09-10 17:11:16 --> Helper loaded: url_helper
INFO - 2024-09-10 17:11:16 --> Helper loaded: file_helper
INFO - 2024-09-10 17:11:16 --> Helper loaded: form_helper
INFO - 2024-09-10 17:11:16 --> Helper loaded: my_helper
INFO - 2024-09-10 17:11:16 --> Database Driver Class Initialized
INFO - 2024-09-10 17:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 17:11:17 --> Controller Class Initialized
ERROR - 2024-09-10 17:11:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1797
ERROR - 2024-09-10 17:11:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1804
ERROR - 2024-09-10 17:11:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-09-10 17:11:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-09-10 17:11:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-09-10 17:11:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 86
ERROR - 2024-09-10 17:11:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-09-10 17:11:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-09-10 17:11:17 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-09-10 17:11:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-09-10 17:11:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-09-10 17:11:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
ERROR - 2024-09-10 17:11:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
ERROR - 2024-09-10 17:11:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
INFO - 2024-09-10 17:11:20 --> Final output sent to browser
DEBUG - 2024-09-10 17:11:20 --> Total execution time: 4.7611
INFO - 2024-09-10 17:11:20 --> Config Class Initialized
INFO - 2024-09-10 17:11:20 --> Hooks Class Initialized
DEBUG - 2024-09-10 17:11:20 --> UTF-8 Support Enabled
INFO - 2024-09-10 17:11:20 --> Utf8 Class Initialized
INFO - 2024-09-10 17:11:20 --> URI Class Initialized
INFO - 2024-09-10 17:11:20 --> Router Class Initialized
INFO - 2024-09-10 17:11:20 --> Output Class Initialized
INFO - 2024-09-10 17:11:20 --> Security Class Initialized
DEBUG - 2024-09-10 17:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 17:11:20 --> Input Class Initialized
INFO - 2024-09-10 17:11:20 --> Language Class Initialized
INFO - 2024-09-10 17:11:20 --> Language Class Initialized
INFO - 2024-09-10 17:11:20 --> Config Class Initialized
INFO - 2024-09-10 17:11:20 --> Loader Class Initialized
INFO - 2024-09-10 17:11:20 --> Helper loaded: url_helper
INFO - 2024-09-10 17:11:20 --> Helper loaded: file_helper
INFO - 2024-09-10 17:11:20 --> Helper loaded: form_helper
INFO - 2024-09-10 17:11:20 --> Helper loaded: my_helper
INFO - 2024-09-10 17:11:21 --> Database Driver Class Initialized
INFO - 2024-09-10 17:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 17:11:21 --> Controller Class Initialized
ERROR - 2024-09-10 17:11:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1797
ERROR - 2024-09-10 17:11:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1804
ERROR - 2024-09-10 17:11:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-09-10 17:11:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-09-10 17:11:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-09-10 17:11:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 86
ERROR - 2024-09-10 17:11:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-09-10 17:11:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-09-10 17:11:21 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-09-10 17:11:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-09-10 17:11:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-09-10 17:11:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
ERROR - 2024-09-10 17:11:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
ERROR - 2024-09-10 17:11:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
INFO - 2024-09-10 17:11:24 --> Final output sent to browser
DEBUG - 2024-09-10 17:11:24 --> Total execution time: 3.6112
INFO - 2024-09-10 17:11:24 --> Config Class Initialized
INFO - 2024-09-10 17:11:24 --> Hooks Class Initialized
DEBUG - 2024-09-10 17:11:24 --> UTF-8 Support Enabled
INFO - 2024-09-10 17:11:24 --> Utf8 Class Initialized
INFO - 2024-09-10 17:11:24 --> URI Class Initialized
INFO - 2024-09-10 17:11:24 --> Router Class Initialized
INFO - 2024-09-10 17:11:24 --> Output Class Initialized
INFO - 2024-09-10 17:11:24 --> Security Class Initialized
DEBUG - 2024-09-10 17:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 17:11:24 --> Input Class Initialized
INFO - 2024-09-10 17:11:24 --> Language Class Initialized
INFO - 2024-09-10 17:11:24 --> Language Class Initialized
INFO - 2024-09-10 17:11:24 --> Config Class Initialized
INFO - 2024-09-10 17:11:24 --> Loader Class Initialized
INFO - 2024-09-10 17:11:24 --> Helper loaded: url_helper
INFO - 2024-09-10 17:11:24 --> Helper loaded: file_helper
INFO - 2024-09-10 17:11:24 --> Helper loaded: form_helper
INFO - 2024-09-10 17:11:24 --> Helper loaded: my_helper
INFO - 2024-09-10 17:11:24 --> Database Driver Class Initialized
INFO - 2024-09-10 17:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 17:11:24 --> Controller Class Initialized
ERROR - 2024-09-10 17:11:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1797
ERROR - 2024-09-10 17:11:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1804
ERROR - 2024-09-10 17:11:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-09-10 17:11:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-09-10 17:11:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-09-10 17:11:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 86
ERROR - 2024-09-10 17:11:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-09-10 17:11:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-09-10 17:11:24 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-09-10 17:11:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-09-10 17:11:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-09-10 17:11:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
ERROR - 2024-09-10 17:11:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
ERROR - 2024-09-10 17:11:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
INFO - 2024-09-10 17:47:19 --> Config Class Initialized
INFO - 2024-09-10 17:47:19 --> Hooks Class Initialized
DEBUG - 2024-09-10 17:47:19 --> UTF-8 Support Enabled
INFO - 2024-09-10 17:47:19 --> Utf8 Class Initialized
INFO - 2024-09-10 17:47:19 --> URI Class Initialized
INFO - 2024-09-10 17:47:19 --> Router Class Initialized
INFO - 2024-09-10 17:47:19 --> Output Class Initialized
INFO - 2024-09-10 17:47:19 --> Security Class Initialized
DEBUG - 2024-09-10 17:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 17:47:19 --> Input Class Initialized
INFO - 2024-09-10 17:47:19 --> Language Class Initialized
INFO - 2024-09-10 17:47:19 --> Language Class Initialized
INFO - 2024-09-10 17:47:19 --> Config Class Initialized
INFO - 2024-09-10 17:47:19 --> Loader Class Initialized
INFO - 2024-09-10 17:47:19 --> Helper loaded: url_helper
INFO - 2024-09-10 17:47:19 --> Helper loaded: file_helper
INFO - 2024-09-10 17:47:19 --> Helper loaded: form_helper
INFO - 2024-09-10 17:47:19 --> Helper loaded: my_helper
INFO - 2024-09-10 17:47:19 --> Database Driver Class Initialized
INFO - 2024-09-10 17:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 17:47:19 --> Controller Class Initialized
INFO - 2024-09-10 17:47:19 --> Helper loaded: cookie_helper
INFO - 2024-09-10 17:47:19 --> Final output sent to browser
DEBUG - 2024-09-10 17:47:19 --> Total execution time: 0.0527
INFO - 2024-09-10 17:47:20 --> Config Class Initialized
INFO - 2024-09-10 17:47:20 --> Hooks Class Initialized
DEBUG - 2024-09-10 17:47:20 --> UTF-8 Support Enabled
INFO - 2024-09-10 17:47:20 --> Utf8 Class Initialized
INFO - 2024-09-10 17:47:20 --> URI Class Initialized
INFO - 2024-09-10 17:47:20 --> Router Class Initialized
INFO - 2024-09-10 17:47:20 --> Output Class Initialized
INFO - 2024-09-10 17:47:20 --> Security Class Initialized
DEBUG - 2024-09-10 17:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 17:47:20 --> Input Class Initialized
INFO - 2024-09-10 17:47:20 --> Language Class Initialized
INFO - 2024-09-10 17:47:20 --> Language Class Initialized
INFO - 2024-09-10 17:47:20 --> Config Class Initialized
INFO - 2024-09-10 17:47:20 --> Loader Class Initialized
INFO - 2024-09-10 17:47:20 --> Helper loaded: url_helper
INFO - 2024-09-10 17:47:20 --> Helper loaded: file_helper
INFO - 2024-09-10 17:47:20 --> Helper loaded: form_helper
INFO - 2024-09-10 17:47:20 --> Helper loaded: my_helper
INFO - 2024-09-10 17:47:20 --> Database Driver Class Initialized
INFO - 2024-09-10 17:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 17:47:20 --> Controller Class Initialized
INFO - 2024-09-10 17:47:20 --> Helper loaded: cookie_helper
INFO - 2024-09-10 17:47:20 --> Config Class Initialized
INFO - 2024-09-10 17:47:20 --> Hooks Class Initialized
DEBUG - 2024-09-10 17:47:20 --> UTF-8 Support Enabled
INFO - 2024-09-10 17:47:20 --> Utf8 Class Initialized
INFO - 2024-09-10 17:47:20 --> URI Class Initialized
INFO - 2024-09-10 17:47:20 --> Router Class Initialized
INFO - 2024-09-10 17:47:20 --> Output Class Initialized
INFO - 2024-09-10 17:47:20 --> Security Class Initialized
DEBUG - 2024-09-10 17:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 17:47:20 --> Input Class Initialized
INFO - 2024-09-10 17:47:20 --> Language Class Initialized
INFO - 2024-09-10 17:47:20 --> Language Class Initialized
INFO - 2024-09-10 17:47:20 --> Config Class Initialized
INFO - 2024-09-10 17:47:20 --> Loader Class Initialized
INFO - 2024-09-10 17:47:20 --> Helper loaded: url_helper
INFO - 2024-09-10 17:47:20 --> Helper loaded: file_helper
INFO - 2024-09-10 17:47:20 --> Helper loaded: form_helper
INFO - 2024-09-10 17:47:20 --> Helper loaded: my_helper
INFO - 2024-09-10 17:47:20 --> Database Driver Class Initialized
INFO - 2024-09-10 17:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 17:47:20 --> Controller Class Initialized
DEBUG - 2024-09-10 17:47:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-10 17:47:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-10 17:47:20 --> Final output sent to browser
DEBUG - 2024-09-10 17:47:20 --> Total execution time: 0.1166
