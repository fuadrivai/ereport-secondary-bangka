<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-03-01 19:24:11 --> Config Class Initialized
INFO - 2024-03-01 19:24:11 --> Hooks Class Initialized
DEBUG - 2024-03-01 19:24:11 --> UTF-8 Support Enabled
INFO - 2024-03-01 19:24:11 --> Utf8 Class Initialized
INFO - 2024-03-01 19:24:11 --> URI Class Initialized
INFO - 2024-03-01 19:24:11 --> Router Class Initialized
INFO - 2024-03-01 19:24:11 --> Output Class Initialized
INFO - 2024-03-01 19:24:11 --> Security Class Initialized
DEBUG - 2024-03-01 19:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-01 19:24:11 --> Input Class Initialized
INFO - 2024-03-01 19:24:11 --> Language Class Initialized
INFO - 2024-03-01 19:24:11 --> Language Class Initialized
INFO - 2024-03-01 19:24:11 --> Config Class Initialized
INFO - 2024-03-01 19:24:11 --> Loader Class Initialized
INFO - 2024-03-01 19:24:11 --> Helper loaded: url_helper
INFO - 2024-03-01 19:24:11 --> Helper loaded: file_helper
INFO - 2024-03-01 19:24:11 --> Helper loaded: form_helper
INFO - 2024-03-01 19:24:11 --> Helper loaded: my_helper
INFO - 2024-03-01 19:24:11 --> Database Driver Class Initialized
INFO - 2024-03-01 19:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-01 19:24:11 --> Controller Class Initialized
INFO - 2024-03-01 19:24:11 --> Helper loaded: cookie_helper
INFO - 2024-03-01 19:24:11 --> Final output sent to browser
DEBUG - 2024-03-01 19:24:11 --> Total execution time: 0.1706
INFO - 2024-03-01 19:24:11 --> Config Class Initialized
INFO - 2024-03-01 19:24:11 --> Hooks Class Initialized
DEBUG - 2024-03-01 19:24:11 --> UTF-8 Support Enabled
INFO - 2024-03-01 19:24:11 --> Utf8 Class Initialized
INFO - 2024-03-01 19:24:11 --> URI Class Initialized
INFO - 2024-03-01 19:24:11 --> Router Class Initialized
INFO - 2024-03-01 19:24:11 --> Output Class Initialized
INFO - 2024-03-01 19:24:11 --> Security Class Initialized
DEBUG - 2024-03-01 19:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-01 19:24:11 --> Input Class Initialized
INFO - 2024-03-01 19:24:11 --> Language Class Initialized
INFO - 2024-03-01 19:24:11 --> Language Class Initialized
INFO - 2024-03-01 19:24:11 --> Config Class Initialized
INFO - 2024-03-01 19:24:11 --> Loader Class Initialized
INFO - 2024-03-01 19:24:11 --> Helper loaded: url_helper
INFO - 2024-03-01 19:24:11 --> Helper loaded: file_helper
INFO - 2024-03-01 19:24:11 --> Helper loaded: form_helper
INFO - 2024-03-01 19:24:11 --> Helper loaded: my_helper
INFO - 2024-03-01 19:24:11 --> Database Driver Class Initialized
INFO - 2024-03-01 19:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-01 19:24:11 --> Controller Class Initialized
INFO - 2024-03-01 19:24:11 --> Helper loaded: cookie_helper
INFO - 2024-03-01 19:24:11 --> Final output sent to browser
DEBUG - 2024-03-01 19:24:11 --> Total execution time: 0.0693
INFO - 2024-03-01 19:24:11 --> Config Class Initialized
INFO - 2024-03-01 19:24:11 --> Hooks Class Initialized
DEBUG - 2024-03-01 19:24:11 --> UTF-8 Support Enabled
INFO - 2024-03-01 19:24:11 --> Utf8 Class Initialized
INFO - 2024-03-01 19:24:11 --> URI Class Initialized
INFO - 2024-03-01 19:24:11 --> Router Class Initialized
INFO - 2024-03-01 19:24:11 --> Output Class Initialized
INFO - 2024-03-01 19:24:11 --> Security Class Initialized
DEBUG - 2024-03-01 19:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-01 19:24:11 --> Input Class Initialized
INFO - 2024-03-01 19:24:11 --> Language Class Initialized
INFO - 2024-03-01 19:24:11 --> Language Class Initialized
INFO - 2024-03-01 19:24:11 --> Config Class Initialized
INFO - 2024-03-01 19:24:11 --> Loader Class Initialized
INFO - 2024-03-01 19:24:11 --> Helper loaded: url_helper
INFO - 2024-03-01 19:24:11 --> Helper loaded: file_helper
INFO - 2024-03-01 19:24:11 --> Helper loaded: form_helper
INFO - 2024-03-01 19:24:11 --> Helper loaded: my_helper
INFO - 2024-03-01 19:24:11 --> Database Driver Class Initialized
INFO - 2024-03-01 19:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-01 19:24:11 --> Controller Class Initialized
INFO - 2024-03-01 19:24:11 --> Helper loaded: cookie_helper
INFO - 2024-03-01 19:24:11 --> Config Class Initialized
INFO - 2024-03-01 19:24:11 --> Hooks Class Initialized
DEBUG - 2024-03-01 19:24:11 --> UTF-8 Support Enabled
INFO - 2024-03-01 19:24:11 --> Utf8 Class Initialized
INFO - 2024-03-01 19:24:11 --> URI Class Initialized
INFO - 2024-03-01 19:24:11 --> Router Class Initialized
INFO - 2024-03-01 19:24:11 --> Output Class Initialized
INFO - 2024-03-01 19:24:11 --> Security Class Initialized
DEBUG - 2024-03-01 19:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-01 19:24:11 --> Input Class Initialized
INFO - 2024-03-01 19:24:11 --> Language Class Initialized
INFO - 2024-03-01 19:24:11 --> Language Class Initialized
INFO - 2024-03-01 19:24:11 --> Config Class Initialized
INFO - 2024-03-01 19:24:11 --> Loader Class Initialized
INFO - 2024-03-01 19:24:11 --> Helper loaded: url_helper
INFO - 2024-03-01 19:24:12 --> Helper loaded: file_helper
INFO - 2024-03-01 19:24:12 --> Helper loaded: form_helper
INFO - 2024-03-01 19:24:12 --> Helper loaded: my_helper
INFO - 2024-03-01 19:24:12 --> Database Driver Class Initialized
INFO - 2024-03-01 19:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-01 19:24:12 --> Controller Class Initialized
INFO - 2024-03-01 19:24:12 --> Config Class Initialized
INFO - 2024-03-01 19:24:12 --> Hooks Class Initialized
DEBUG - 2024-03-01 19:24:12 --> UTF-8 Support Enabled
INFO - 2024-03-01 19:24:12 --> Utf8 Class Initialized
INFO - 2024-03-01 19:24:12 --> Config Class Initialized
INFO - 2024-03-01 19:24:12 --> Hooks Class Initialized
DEBUG - 2024-03-01 19:24:12 --> UTF-8 Support Enabled
INFO - 2024-03-01 19:24:12 --> Utf8 Class Initialized
INFO - 2024-03-01 19:24:12 --> URI Class Initialized
INFO - 2024-03-01 19:24:12 --> Router Class Initialized
INFO - 2024-03-01 19:24:12 --> URI Class Initialized
INFO - 2024-03-01 19:24:12 --> Output Class Initialized
DEBUG - 2024-03-01 19:24:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-03-01 19:24:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-01 19:24:12 --> Final output sent to browser
DEBUG - 2024-03-01 19:24:12 --> Total execution time: 0.0862
INFO - 2024-03-01 19:24:12 --> Router Class Initialized
INFO - 2024-03-01 19:24:12 --> Security Class Initialized
INFO - 2024-03-01 19:24:12 --> Output Class Initialized
DEBUG - 2024-03-01 19:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-01 19:24:12 --> Input Class Initialized
INFO - 2024-03-01 19:24:12 --> Language Class Initialized
INFO - 2024-03-01 19:24:12 --> Language Class Initialized
INFO - 2024-03-01 19:24:12 --> Config Class Initialized
INFO - 2024-03-01 19:24:12 --> Loader Class Initialized
INFO - 2024-03-01 19:24:12 --> Helper loaded: url_helper
INFO - 2024-03-01 19:24:12 --> Helper loaded: file_helper
INFO - 2024-03-01 19:24:12 --> Security Class Initialized
INFO - 2024-03-01 19:24:12 --> Config Class Initialized
INFO - 2024-03-01 19:24:12 --> Hooks Class Initialized
DEBUG - 2024-03-01 19:24:12 --> UTF-8 Support Enabled
INFO - 2024-03-01 19:24:12 --> Utf8 Class Initialized
INFO - 2024-03-01 19:24:12 --> Helper loaded: form_helper
INFO - 2024-03-01 19:24:12 --> URI Class Initialized
INFO - 2024-03-01 19:24:12 --> Router Class Initialized
INFO - 2024-03-01 19:24:12 --> Output Class Initialized
INFO - 2024-03-01 19:24:12 --> Security Class Initialized
INFO - 2024-03-01 19:24:12 --> Helper loaded: my_helper
DEBUG - 2024-03-01 19:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-01 19:24:12 --> Input Class Initialized
INFO - 2024-03-01 19:24:12 --> Language Class Initialized
INFO - 2024-03-01 19:24:12 --> Language Class Initialized
INFO - 2024-03-01 19:24:12 --> Config Class Initialized
INFO - 2024-03-01 19:24:12 --> Loader Class Initialized
DEBUG - 2024-03-01 19:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-01 19:24:12 --> Input Class Initialized
INFO - 2024-03-01 19:24:12 --> Helper loaded: url_helper
INFO - 2024-03-01 19:24:12 --> Helper loaded: file_helper
INFO - 2024-03-01 19:24:12 --> Helper loaded: form_helper
INFO - 2024-03-01 19:24:12 --> Helper loaded: my_helper
INFO - 2024-03-01 19:24:12 --> Database Driver Class Initialized
INFO - 2024-03-01 19:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-01 19:24:12 --> Controller Class Initialized
INFO - 2024-03-01 19:24:12 --> Database Driver Class Initialized
INFO - 2024-03-01 19:24:12 --> Language Class Initialized
INFO - 2024-03-01 19:24:12 --> Helper loaded: cookie_helper
INFO - 2024-03-01 19:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-01 19:24:12 --> Controller Class Initialized
INFO - 2024-03-01 19:24:12 --> Helper loaded: cookie_helper
INFO - 2024-03-01 19:24:12 --> Language Class Initialized
INFO - 2024-03-01 19:24:12 --> Config Class Initialized
INFO - 2024-03-01 19:24:12 --> Loader Class Initialized
INFO - 2024-03-01 19:24:12 --> Helper loaded: url_helper
INFO - 2024-03-01 19:24:12 --> Config Class Initialized
INFO - 2024-03-01 19:24:12 --> Hooks Class Initialized
DEBUG - 2024-03-01 19:24:12 --> UTF-8 Support Enabled
INFO - 2024-03-01 19:24:12 --> Utf8 Class Initialized
INFO - 2024-03-01 19:24:12 --> Helper loaded: file_helper
INFO - 2024-03-01 19:24:12 --> URI Class Initialized
INFO - 2024-03-01 19:24:12 --> Router Class Initialized
INFO - 2024-03-01 19:24:12 --> Output Class Initialized
INFO - 2024-03-01 19:24:12 --> Security Class Initialized
DEBUG - 2024-03-01 19:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-01 19:24:12 --> Input Class Initialized
INFO - 2024-03-01 19:24:12 --> Language Class Initialized
INFO - 2024-03-01 19:24:12 --> Language Class Initialized
INFO - 2024-03-01 19:24:12 --> Config Class Initialized
INFO - 2024-03-01 19:24:12 --> Loader Class Initialized
INFO - 2024-03-01 19:24:12 --> Helper loaded: url_helper
INFO - 2024-03-01 19:24:12 --> Helper loaded: file_helper
INFO - 2024-03-01 19:24:12 --> Helper loaded: form_helper
INFO - 2024-03-01 19:24:12 --> Helper loaded: my_helper
INFO - 2024-03-01 19:24:12 --> Database Driver Class Initialized
INFO - 2024-03-01 19:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-01 19:24:12 --> Controller Class Initialized
INFO - 2024-03-01 19:24:12 --> Config Class Initialized
INFO - 2024-03-01 19:24:12 --> Hooks Class Initialized
DEBUG - 2024-03-01 19:24:12 --> UTF-8 Support Enabled
INFO - 2024-03-01 19:24:12 --> Utf8 Class Initialized
INFO - 2024-03-01 19:24:12 --> URI Class Initialized
DEBUG - 2024-03-01 19:24:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-03-01 19:24:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-01 19:24:12 --> Final output sent to browser
DEBUG - 2024-03-01 19:24:12 --> Total execution time: 0.1517
INFO - 2024-03-01 19:24:12 --> Router Class Initialized
INFO - 2024-03-01 19:24:12 --> Output Class Initialized
INFO - 2024-03-01 19:24:12 --> Security Class Initialized
DEBUG - 2024-03-01 19:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-01 19:24:12 --> Input Class Initialized
INFO - 2024-03-01 19:24:12 --> Language Class Initialized
INFO - 2024-03-01 19:24:12 --> Language Class Initialized
INFO - 2024-03-01 19:24:12 --> Config Class Initialized
INFO - 2024-03-01 19:24:12 --> Loader Class Initialized
INFO - 2024-03-01 19:24:12 --> Helper loaded: url_helper
INFO - 2024-03-01 19:24:12 --> Helper loaded: file_helper
INFO - 2024-03-01 19:24:12 --> Helper loaded: form_helper
INFO - 2024-03-01 19:24:12 --> Helper loaded: my_helper
INFO - 2024-03-01 19:24:12 --> Database Driver Class Initialized
INFO - 2024-03-01 19:24:12 --> Helper loaded: form_helper
INFO - 2024-03-01 19:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-01 19:24:12 --> Controller Class Initialized
INFO - 2024-03-01 19:24:12 --> Helper loaded: my_helper
INFO - 2024-03-01 19:24:12 --> Helper loaded: cookie_helper
INFO - 2024-03-01 19:24:12 --> Final output sent to browser
DEBUG - 2024-03-01 19:24:12 --> Total execution time: 0.2236
INFO - 2024-03-01 19:24:12 --> Database Driver Class Initialized
INFO - 2024-03-01 19:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-01 19:24:12 --> Controller Class Initialized
INFO - 2024-03-01 19:24:12 --> Helper loaded: cookie_helper
INFO - 2024-03-01 19:24:12 --> Final output sent to browser
DEBUG - 2024-03-01 19:24:12 --> Total execution time: 0.7930
INFO - 2024-03-01 19:24:12 --> Config Class Initialized
INFO - 2024-03-01 19:24:12 --> Hooks Class Initialized
DEBUG - 2024-03-01 19:24:12 --> UTF-8 Support Enabled
INFO - 2024-03-01 19:24:12 --> Utf8 Class Initialized
INFO - 2024-03-01 19:24:12 --> URI Class Initialized
INFO - 2024-03-01 19:24:12 --> Router Class Initialized
INFO - 2024-03-01 19:24:12 --> Output Class Initialized
INFO - 2024-03-01 19:24:12 --> Security Class Initialized
DEBUG - 2024-03-01 19:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-01 19:24:12 --> Input Class Initialized
INFO - 2024-03-01 19:24:12 --> Language Class Initialized
INFO - 2024-03-01 19:24:13 --> Language Class Initialized
INFO - 2024-03-01 19:24:13 --> Config Class Initialized
INFO - 2024-03-01 19:24:13 --> Loader Class Initialized
INFO - 2024-03-01 19:24:13 --> Helper loaded: url_helper
INFO - 2024-03-01 19:24:13 --> Helper loaded: file_helper
INFO - 2024-03-01 19:24:13 --> Helper loaded: form_helper
INFO - 2024-03-01 19:24:13 --> Helper loaded: my_helper
INFO - 2024-03-01 19:24:13 --> Database Driver Class Initialized
INFO - 2024-03-01 19:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-01 19:24:13 --> Controller Class Initialized
INFO - 2024-03-01 19:24:13 --> Helper loaded: cookie_helper
INFO - 2024-03-01 19:24:13 --> Config Class Initialized
INFO - 2024-03-01 19:24:13 --> Hooks Class Initialized
DEBUG - 2024-03-01 19:24:13 --> UTF-8 Support Enabled
INFO - 2024-03-01 19:24:13 --> Utf8 Class Initialized
INFO - 2024-03-01 19:24:13 --> URI Class Initialized
INFO - 2024-03-01 19:24:13 --> Router Class Initialized
INFO - 2024-03-01 19:24:13 --> Output Class Initialized
INFO - 2024-03-01 19:24:13 --> Security Class Initialized
DEBUG - 2024-03-01 19:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-01 19:24:13 --> Input Class Initialized
INFO - 2024-03-01 19:24:13 --> Language Class Initialized
INFO - 2024-03-01 19:24:13 --> Language Class Initialized
INFO - 2024-03-01 19:24:13 --> Config Class Initialized
INFO - 2024-03-01 19:24:13 --> Loader Class Initialized
INFO - 2024-03-01 19:24:13 --> Helper loaded: url_helper
INFO - 2024-03-01 19:24:13 --> Helper loaded: file_helper
INFO - 2024-03-01 19:24:13 --> Helper loaded: form_helper
INFO - 2024-03-01 19:24:13 --> Helper loaded: my_helper
INFO - 2024-03-01 19:24:13 --> Database Driver Class Initialized
INFO - 2024-03-01 19:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-01 19:24:13 --> Controller Class Initialized
INFO - 2024-03-01 19:24:13 --> Config Class Initialized
INFO - 2024-03-01 19:24:13 --> Hooks Class Initialized
DEBUG - 2024-03-01 19:24:13 --> UTF-8 Support Enabled
INFO - 2024-03-01 19:24:13 --> Utf8 Class Initialized
INFO - 2024-03-01 19:24:13 --> URI Class Initialized
INFO - 2024-03-01 19:24:13 --> Router Class Initialized
INFO - 2024-03-01 19:24:13 --> Output Class Initialized
INFO - 2024-03-01 19:24:13 --> Security Class Initialized
DEBUG - 2024-03-01 19:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-01 19:24:13 --> Input Class Initialized
INFO - 2024-03-01 19:24:13 --> Language Class Initialized
INFO - 2024-03-01 19:24:13 --> Language Class Initialized
INFO - 2024-03-01 19:24:13 --> Config Class Initialized
INFO - 2024-03-01 19:24:13 --> Loader Class Initialized
INFO - 2024-03-01 19:24:13 --> Helper loaded: url_helper
INFO - 2024-03-01 19:24:13 --> Helper loaded: file_helper
INFO - 2024-03-01 19:24:13 --> Helper loaded: form_helper
INFO - 2024-03-01 19:24:13 --> Helper loaded: my_helper
INFO - 2024-03-01 19:24:13 --> Database Driver Class Initialized
INFO - 2024-03-01 19:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-01 19:24:13 --> Controller Class Initialized
INFO - 2024-03-01 19:24:13 --> Helper loaded: cookie_helper
INFO - 2024-03-01 19:24:13 --> Final output sent to browser
DEBUG - 2024-03-01 19:24:13 --> Total execution time: 0.0747
INFO - 2024-03-01 19:24:13 --> Helper loaded: cookie_helper
INFO - 2024-03-01 19:24:13 --> Config Class Initialized
INFO - 2024-03-01 19:24:13 --> Hooks Class Initialized
DEBUG - 2024-03-01 19:24:13 --> UTF-8 Support Enabled
INFO - 2024-03-01 19:24:13 --> Utf8 Class Initialized
INFO - 2024-03-01 19:24:13 --> Config Class Initialized
INFO - 2024-03-01 19:24:13 --> Hooks Class Initialized
DEBUG - 2024-03-01 19:24:13 --> UTF-8 Support Enabled
INFO - 2024-03-01 19:24:13 --> Utf8 Class Initialized
INFO - 2024-03-01 19:24:13 --> URI Class Initialized
INFO - 2024-03-01 19:24:13 --> Router Class Initialized
INFO - 2024-03-01 19:24:13 --> Output Class Initialized
INFO - 2024-03-01 19:24:13 --> Security Class Initialized
DEBUG - 2024-03-01 19:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-01 19:24:13 --> Input Class Initialized
INFO - 2024-03-01 19:24:13 --> Language Class Initialized
INFO - 2024-03-01 19:24:13 --> URI Class Initialized
INFO - 2024-03-01 19:24:13 --> Router Class Initialized
INFO - 2024-03-01 19:24:13 --> Output Class Initialized
INFO - 2024-03-01 19:24:13 --> Security Class Initialized
INFO - 2024-03-01 19:24:13 --> Language Class Initialized
INFO - 2024-03-01 19:24:13 --> Config Class Initialized
INFO - 2024-03-01 19:24:13 --> Loader Class Initialized
INFO - 2024-03-01 19:24:13 --> Helper loaded: url_helper
INFO - 2024-03-01 19:24:13 --> Helper loaded: file_helper
INFO - 2024-03-01 19:24:13 --> Helper loaded: form_helper
INFO - 2024-03-01 19:24:13 --> Helper loaded: my_helper
DEBUG - 2024-03-01 19:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-01 19:24:13 --> Input Class Initialized
INFO - 2024-03-01 19:24:13 --> Language Class Initialized
INFO - 2024-03-01 19:24:13 --> Language Class Initialized
INFO - 2024-03-01 19:24:13 --> Config Class Initialized
INFO - 2024-03-01 19:24:13 --> Loader Class Initialized
INFO - 2024-03-01 19:24:13 --> Database Driver Class Initialized
INFO - 2024-03-01 19:24:13 --> Helper loaded: url_helper
INFO - 2024-03-01 19:24:13 --> Helper loaded: file_helper
INFO - 2024-03-01 19:24:13 --> Helper loaded: form_helper
INFO - 2024-03-01 19:24:13 --> Helper loaded: my_helper
INFO - 2024-03-01 19:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-01 19:24:13 --> Controller Class Initialized
INFO - 2024-03-01 19:24:13 --> Database Driver Class Initialized
INFO - 2024-03-01 19:24:13 --> Helper loaded: cookie_helper
INFO - 2024-03-01 19:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-01 19:24:13 --> Controller Class Initialized
DEBUG - 2024-03-01 19:24:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-03-01 19:24:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-01 19:24:13 --> Final output sent to browser
DEBUG - 2024-03-01 19:24:13 --> Total execution time: 0.1282
INFO - 2024-03-01 19:24:13 --> Config Class Initialized
INFO - 2024-03-01 19:24:13 --> Hooks Class Initialized
DEBUG - 2024-03-01 19:24:13 --> UTF-8 Support Enabled
INFO - 2024-03-01 19:24:13 --> Utf8 Class Initialized
INFO - 2024-03-01 19:24:13 --> URI Class Initialized
INFO - 2024-03-01 19:24:13 --> Router Class Initialized
INFO - 2024-03-01 19:24:13 --> Output Class Initialized
INFO - 2024-03-01 19:24:13 --> Security Class Initialized
DEBUG - 2024-03-01 19:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-01 19:24:13 --> Input Class Initialized
INFO - 2024-03-01 19:24:13 --> Language Class Initialized
INFO - 2024-03-01 19:24:13 --> Language Class Initialized
INFO - 2024-03-01 19:24:13 --> Config Class Initialized
INFO - 2024-03-01 19:24:13 --> Loader Class Initialized
INFO - 2024-03-01 19:24:13 --> Helper loaded: url_helper
INFO - 2024-03-01 19:24:13 --> Helper loaded: file_helper
INFO - 2024-03-01 19:24:13 --> Helper loaded: form_helper
INFO - 2024-03-01 19:24:13 --> Helper loaded: my_helper
INFO - 2024-03-01 19:24:13 --> Database Driver Class Initialized
INFO - 2024-03-01 19:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-01 19:24:13 --> Controller Class Initialized
INFO - 2024-03-01 19:24:13 --> Helper loaded: cookie_helper
INFO - 2024-03-01 19:24:13 --> Config Class Initialized
INFO - 2024-03-01 19:24:13 --> Hooks Class Initialized
DEBUG - 2024-03-01 19:24:13 --> UTF-8 Support Enabled
INFO - 2024-03-01 19:24:13 --> Utf8 Class Initialized
INFO - 2024-03-01 19:24:13 --> URI Class Initialized
INFO - 2024-03-01 19:24:13 --> Router Class Initialized
INFO - 2024-03-01 19:24:13 --> Output Class Initialized
INFO - 2024-03-01 19:24:13 --> Security Class Initialized
DEBUG - 2024-03-01 19:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-01 19:24:13 --> Input Class Initialized
INFO - 2024-03-01 19:24:13 --> Language Class Initialized
INFO - 2024-03-01 19:24:13 --> Language Class Initialized
INFO - 2024-03-01 19:24:13 --> Config Class Initialized
INFO - 2024-03-01 19:24:13 --> Loader Class Initialized
INFO - 2024-03-01 19:24:13 --> Helper loaded: url_helper
INFO - 2024-03-01 19:24:13 --> Helper loaded: file_helper
INFO - 2024-03-01 19:24:13 --> Helper loaded: form_helper
INFO - 2024-03-01 19:24:13 --> Helper loaded: my_helper
INFO - 2024-03-01 19:24:13 --> Database Driver Class Initialized
INFO - 2024-03-01 19:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-01 19:24:13 --> Controller Class Initialized
DEBUG - 2024-03-01 19:24:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-03-01 19:24:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-01 19:24:13 --> Final output sent to browser
DEBUG - 2024-03-01 19:24:13 --> Total execution time: 0.0353
INFO - 2024-03-01 19:24:14 --> Config Class Initialized
INFO - 2024-03-01 19:24:14 --> Hooks Class Initialized
DEBUG - 2024-03-01 19:24:14 --> UTF-8 Support Enabled
INFO - 2024-03-01 19:24:14 --> Utf8 Class Initialized
INFO - 2024-03-01 19:24:14 --> URI Class Initialized
INFO - 2024-03-01 19:24:14 --> Router Class Initialized
INFO - 2024-03-01 19:24:14 --> Output Class Initialized
INFO - 2024-03-01 19:24:14 --> Security Class Initialized
DEBUG - 2024-03-01 19:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-01 19:24:14 --> Input Class Initialized
INFO - 2024-03-01 19:24:14 --> Language Class Initialized
INFO - 2024-03-01 19:24:14 --> Language Class Initialized
INFO - 2024-03-01 19:24:14 --> Config Class Initialized
INFO - 2024-03-01 19:24:14 --> Loader Class Initialized
INFO - 2024-03-01 19:24:14 --> Helper loaded: url_helper
INFO - 2024-03-01 19:24:14 --> Helper loaded: file_helper
INFO - 2024-03-01 19:24:14 --> Helper loaded: form_helper
INFO - 2024-03-01 19:24:14 --> Helper loaded: my_helper
INFO - 2024-03-01 19:24:14 --> Database Driver Class Initialized
INFO - 2024-03-01 19:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-01 19:24:14 --> Controller Class Initialized
DEBUG - 2024-03-01 19:24:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-03-01 19:24:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-01 19:24:14 --> Final output sent to browser
DEBUG - 2024-03-01 19:24:14 --> Total execution time: 0.0509
INFO - 2024-03-01 19:24:23 --> Config Class Initialized
INFO - 2024-03-01 19:24:23 --> Hooks Class Initialized
DEBUG - 2024-03-01 19:24:23 --> UTF-8 Support Enabled
INFO - 2024-03-01 19:24:23 --> Utf8 Class Initialized
INFO - 2024-03-01 19:24:23 --> URI Class Initialized
INFO - 2024-03-01 19:24:23 --> Router Class Initialized
INFO - 2024-03-01 19:24:23 --> Output Class Initialized
INFO - 2024-03-01 19:24:23 --> Security Class Initialized
DEBUG - 2024-03-01 19:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-01 19:24:23 --> Input Class Initialized
INFO - 2024-03-01 19:24:23 --> Language Class Initialized
INFO - 2024-03-01 19:24:23 --> Language Class Initialized
INFO - 2024-03-01 19:24:23 --> Config Class Initialized
INFO - 2024-03-01 19:24:23 --> Loader Class Initialized
INFO - 2024-03-01 19:24:23 --> Helper loaded: url_helper
INFO - 2024-03-01 19:24:23 --> Helper loaded: file_helper
INFO - 2024-03-01 19:24:23 --> Helper loaded: form_helper
INFO - 2024-03-01 19:24:23 --> Helper loaded: my_helper
INFO - 2024-03-01 19:24:23 --> Database Driver Class Initialized
INFO - 2024-03-01 19:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-01 19:24:23 --> Controller Class Initialized
DEBUG - 2024-03-01 19:24:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-01 19:24:27 --> Final output sent to browser
DEBUG - 2024-03-01 19:24:27 --> Total execution time: 4.3371
INFO - 2024-03-01 19:25:49 --> Config Class Initialized
INFO - 2024-03-01 19:25:49 --> Hooks Class Initialized
DEBUG - 2024-03-01 19:25:49 --> UTF-8 Support Enabled
INFO - 2024-03-01 19:25:49 --> Utf8 Class Initialized
INFO - 2024-03-01 19:25:49 --> URI Class Initialized
INFO - 2024-03-01 19:25:49 --> Router Class Initialized
INFO - 2024-03-01 19:25:49 --> Output Class Initialized
INFO - 2024-03-01 19:25:49 --> Security Class Initialized
DEBUG - 2024-03-01 19:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-01 19:25:49 --> Input Class Initialized
INFO - 2024-03-01 19:25:49 --> Language Class Initialized
INFO - 2024-03-01 19:25:49 --> Language Class Initialized
INFO - 2024-03-01 19:25:49 --> Config Class Initialized
INFO - 2024-03-01 19:25:49 --> Loader Class Initialized
INFO - 2024-03-01 19:25:49 --> Helper loaded: url_helper
INFO - 2024-03-01 19:25:49 --> Helper loaded: file_helper
INFO - 2024-03-01 19:25:49 --> Helper loaded: form_helper
INFO - 2024-03-01 19:25:49 --> Helper loaded: my_helper
INFO - 2024-03-01 19:25:49 --> Database Driver Class Initialized
INFO - 2024-03-01 19:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-01 19:25:49 --> Controller Class Initialized
DEBUG - 2024-03-01 19:25:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-03-01 19:25:52 --> Final output sent to browser
DEBUG - 2024-03-01 19:25:52 --> Total execution time: 2.7133
INFO - 2024-03-01 19:26:27 --> Config Class Initialized
INFO - 2024-03-01 19:26:27 --> Hooks Class Initialized
DEBUG - 2024-03-01 19:26:27 --> UTF-8 Support Enabled
INFO - 2024-03-01 19:26:27 --> Utf8 Class Initialized
INFO - 2024-03-01 19:26:27 --> URI Class Initialized
INFO - 2024-03-01 19:26:27 --> Router Class Initialized
INFO - 2024-03-01 19:26:27 --> Output Class Initialized
INFO - 2024-03-01 19:26:27 --> Security Class Initialized
DEBUG - 2024-03-01 19:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-01 19:26:27 --> Input Class Initialized
INFO - 2024-03-01 19:26:27 --> Language Class Initialized
INFO - 2024-03-01 19:26:27 --> Language Class Initialized
INFO - 2024-03-01 19:26:27 --> Config Class Initialized
INFO - 2024-03-01 19:26:27 --> Loader Class Initialized
INFO - 2024-03-01 19:26:27 --> Helper loaded: url_helper
INFO - 2024-03-01 19:26:27 --> Helper loaded: file_helper
INFO - 2024-03-01 19:26:27 --> Helper loaded: form_helper
INFO - 2024-03-01 19:26:27 --> Helper loaded: my_helper
INFO - 2024-03-01 19:26:27 --> Database Driver Class Initialized
INFO - 2024-03-01 19:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-01 19:26:27 --> Controller Class Initialized
DEBUG - 2024-03-01 19:26:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-03-01 19:26:35 --> Final output sent to browser
DEBUG - 2024-03-01 19:26:35 --> Total execution time: 7.5317
