<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-11 08:26:07 --> Config Class Initialized
INFO - 2024-06-11 08:26:07 --> Hooks Class Initialized
DEBUG - 2024-06-11 08:26:07 --> UTF-8 Support Enabled
INFO - 2024-06-11 08:26:07 --> Utf8 Class Initialized
INFO - 2024-06-11 08:26:07 --> URI Class Initialized
INFO - 2024-06-11 08:26:07 --> Router Class Initialized
INFO - 2024-06-11 08:26:07 --> Output Class Initialized
INFO - 2024-06-11 08:26:07 --> Security Class Initialized
DEBUG - 2024-06-11 08:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 08:26:07 --> Input Class Initialized
INFO - 2024-06-11 08:26:07 --> Language Class Initialized
INFO - 2024-06-11 08:26:07 --> Language Class Initialized
INFO - 2024-06-11 08:26:07 --> Config Class Initialized
INFO - 2024-06-11 08:26:07 --> Loader Class Initialized
INFO - 2024-06-11 08:26:07 --> Helper loaded: url_helper
INFO - 2024-06-11 08:26:07 --> Helper loaded: file_helper
INFO - 2024-06-11 08:26:07 --> Helper loaded: form_helper
INFO - 2024-06-11 08:26:07 --> Helper loaded: my_helper
INFO - 2024-06-11 08:26:07 --> Database Driver Class Initialized
INFO - 2024-06-11 08:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 08:26:07 --> Controller Class Initialized
INFO - 2024-06-11 08:26:07 --> Config Class Initialized
INFO - 2024-06-11 08:26:07 --> Hooks Class Initialized
DEBUG - 2024-06-11 08:26:07 --> UTF-8 Support Enabled
INFO - 2024-06-11 08:26:07 --> Utf8 Class Initialized
INFO - 2024-06-11 08:26:07 --> URI Class Initialized
INFO - 2024-06-11 08:26:07 --> Router Class Initialized
INFO - 2024-06-11 08:26:07 --> Output Class Initialized
INFO - 2024-06-11 08:26:07 --> Security Class Initialized
DEBUG - 2024-06-11 08:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 08:26:07 --> Input Class Initialized
INFO - 2024-06-11 08:26:07 --> Language Class Initialized
INFO - 2024-06-11 08:26:07 --> Language Class Initialized
INFO - 2024-06-11 08:26:07 --> Config Class Initialized
INFO - 2024-06-11 08:26:07 --> Loader Class Initialized
INFO - 2024-06-11 08:26:07 --> Helper loaded: url_helper
INFO - 2024-06-11 08:26:07 --> Helper loaded: file_helper
INFO - 2024-06-11 08:26:07 --> Helper loaded: form_helper
INFO - 2024-06-11 08:26:07 --> Helper loaded: my_helper
INFO - 2024-06-11 08:26:07 --> Database Driver Class Initialized
INFO - 2024-06-11 08:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 08:26:07 --> Controller Class Initialized
DEBUG - 2024-06-11 08:26:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-11 08:26:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 08:26:07 --> Final output sent to browser
DEBUG - 2024-06-11 08:26:07 --> Total execution time: 0.0370
INFO - 2024-06-11 08:26:12 --> Config Class Initialized
INFO - 2024-06-11 08:26:12 --> Hooks Class Initialized
DEBUG - 2024-06-11 08:26:12 --> UTF-8 Support Enabled
INFO - 2024-06-11 08:26:12 --> Utf8 Class Initialized
INFO - 2024-06-11 08:26:12 --> URI Class Initialized
INFO - 2024-06-11 08:26:12 --> Router Class Initialized
INFO - 2024-06-11 08:26:12 --> Output Class Initialized
INFO - 2024-06-11 08:26:12 --> Security Class Initialized
DEBUG - 2024-06-11 08:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 08:26:12 --> Input Class Initialized
INFO - 2024-06-11 08:26:12 --> Language Class Initialized
INFO - 2024-06-11 08:26:12 --> Language Class Initialized
INFO - 2024-06-11 08:26:12 --> Config Class Initialized
INFO - 2024-06-11 08:26:12 --> Loader Class Initialized
INFO - 2024-06-11 08:26:12 --> Helper loaded: url_helper
INFO - 2024-06-11 08:26:12 --> Helper loaded: file_helper
INFO - 2024-06-11 08:26:12 --> Helper loaded: form_helper
INFO - 2024-06-11 08:26:12 --> Helper loaded: my_helper
INFO - 2024-06-11 08:26:13 --> Database Driver Class Initialized
INFO - 2024-06-11 08:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 08:26:13 --> Controller Class Initialized
INFO - 2024-06-11 08:26:13 --> Helper loaded: cookie_helper
INFO - 2024-06-11 08:26:13 --> Final output sent to browser
DEBUG - 2024-06-11 08:26:13 --> Total execution time: 0.0486
INFO - 2024-06-11 08:26:13 --> Config Class Initialized
INFO - 2024-06-11 08:26:13 --> Hooks Class Initialized
DEBUG - 2024-06-11 08:26:13 --> UTF-8 Support Enabled
INFO - 2024-06-11 08:26:13 --> Utf8 Class Initialized
INFO - 2024-06-11 08:26:13 --> URI Class Initialized
INFO - 2024-06-11 08:26:13 --> Router Class Initialized
INFO - 2024-06-11 08:26:13 --> Output Class Initialized
INFO - 2024-06-11 08:26:13 --> Security Class Initialized
DEBUG - 2024-06-11 08:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 08:26:13 --> Input Class Initialized
INFO - 2024-06-11 08:26:13 --> Language Class Initialized
INFO - 2024-06-11 08:26:13 --> Language Class Initialized
INFO - 2024-06-11 08:26:13 --> Config Class Initialized
INFO - 2024-06-11 08:26:13 --> Loader Class Initialized
INFO - 2024-06-11 08:26:13 --> Helper loaded: url_helper
INFO - 2024-06-11 08:26:13 --> Helper loaded: file_helper
INFO - 2024-06-11 08:26:13 --> Helper loaded: form_helper
INFO - 2024-06-11 08:26:13 --> Helper loaded: my_helper
INFO - 2024-06-11 08:26:13 --> Database Driver Class Initialized
INFO - 2024-06-11 08:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 08:26:13 --> Controller Class Initialized
DEBUG - 2024-06-11 08:26:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-11 08:26:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 08:26:13 --> Final output sent to browser
DEBUG - 2024-06-11 08:26:13 --> Total execution time: 0.0401
INFO - 2024-06-11 08:26:15 --> Config Class Initialized
INFO - 2024-06-11 08:26:15 --> Hooks Class Initialized
DEBUG - 2024-06-11 08:26:15 --> UTF-8 Support Enabled
INFO - 2024-06-11 08:26:15 --> Utf8 Class Initialized
INFO - 2024-06-11 08:26:15 --> URI Class Initialized
INFO - 2024-06-11 08:26:15 --> Router Class Initialized
INFO - 2024-06-11 08:26:15 --> Output Class Initialized
INFO - 2024-06-11 08:26:15 --> Security Class Initialized
DEBUG - 2024-06-11 08:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 08:26:15 --> Input Class Initialized
INFO - 2024-06-11 08:26:15 --> Language Class Initialized
INFO - 2024-06-11 08:26:15 --> Language Class Initialized
INFO - 2024-06-11 08:26:15 --> Config Class Initialized
INFO - 2024-06-11 08:26:15 --> Loader Class Initialized
INFO - 2024-06-11 08:26:15 --> Helper loaded: url_helper
INFO - 2024-06-11 08:26:15 --> Helper loaded: file_helper
INFO - 2024-06-11 08:26:15 --> Helper loaded: form_helper
INFO - 2024-06-11 08:26:15 --> Helper loaded: my_helper
INFO - 2024-06-11 08:26:15 --> Database Driver Class Initialized
INFO - 2024-06-11 08:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 08:26:15 --> Controller Class Initialized
DEBUG - 2024-06-11 08:26:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-11 08:26:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 08:26:15 --> Final output sent to browser
DEBUG - 2024-06-11 08:26:15 --> Total execution time: 0.0306
INFO - 2024-06-11 08:27:24 --> Config Class Initialized
INFO - 2024-06-11 08:27:24 --> Hooks Class Initialized
DEBUG - 2024-06-11 08:27:24 --> UTF-8 Support Enabled
INFO - 2024-06-11 08:27:24 --> Utf8 Class Initialized
INFO - 2024-06-11 08:27:24 --> URI Class Initialized
INFO - 2024-06-11 08:27:24 --> Router Class Initialized
INFO - 2024-06-11 08:27:24 --> Output Class Initialized
INFO - 2024-06-11 08:27:24 --> Security Class Initialized
DEBUG - 2024-06-11 08:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 08:27:24 --> Input Class Initialized
INFO - 2024-06-11 08:27:24 --> Language Class Initialized
INFO - 2024-06-11 08:27:24 --> Language Class Initialized
INFO - 2024-06-11 08:27:24 --> Config Class Initialized
INFO - 2024-06-11 08:27:24 --> Loader Class Initialized
INFO - 2024-06-11 08:27:24 --> Helper loaded: url_helper
INFO - 2024-06-11 08:27:24 --> Helper loaded: file_helper
INFO - 2024-06-11 08:27:24 --> Helper loaded: form_helper
INFO - 2024-06-11 08:27:24 --> Helper loaded: my_helper
INFO - 2024-06-11 08:27:24 --> Database Driver Class Initialized
INFO - 2024-06-11 08:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 08:27:24 --> Controller Class Initialized
DEBUG - 2024-06-11 08:27:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-11 08:27:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 08:27:24 --> Final output sent to browser
DEBUG - 2024-06-11 08:27:24 --> Total execution time: 0.0571
INFO - 2024-06-11 08:27:24 --> Config Class Initialized
INFO - 2024-06-11 08:27:24 --> Hooks Class Initialized
DEBUG - 2024-06-11 08:27:24 --> UTF-8 Support Enabled
INFO - 2024-06-11 08:27:24 --> Utf8 Class Initialized
INFO - 2024-06-11 08:27:24 --> URI Class Initialized
INFO - 2024-06-11 08:27:24 --> Router Class Initialized
INFO - 2024-06-11 08:27:24 --> Output Class Initialized
INFO - 2024-06-11 08:27:24 --> Security Class Initialized
DEBUG - 2024-06-11 08:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 08:27:24 --> Input Class Initialized
INFO - 2024-06-11 08:27:24 --> Language Class Initialized
INFO - 2024-06-11 08:27:24 --> Language Class Initialized
INFO - 2024-06-11 08:27:24 --> Config Class Initialized
INFO - 2024-06-11 08:27:24 --> Loader Class Initialized
INFO - 2024-06-11 08:27:24 --> Helper loaded: url_helper
INFO - 2024-06-11 08:27:24 --> Helper loaded: file_helper
INFO - 2024-06-11 08:27:24 --> Helper loaded: form_helper
INFO - 2024-06-11 08:27:24 --> Helper loaded: my_helper
INFO - 2024-06-11 08:27:24 --> Database Driver Class Initialized
INFO - 2024-06-11 08:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 08:27:24 --> Controller Class Initialized
INFO - 2024-06-11 08:27:29 --> Config Class Initialized
INFO - 2024-06-11 08:27:29 --> Hooks Class Initialized
DEBUG - 2024-06-11 08:27:29 --> UTF-8 Support Enabled
INFO - 2024-06-11 08:27:29 --> Utf8 Class Initialized
INFO - 2024-06-11 08:27:29 --> URI Class Initialized
INFO - 2024-06-11 08:27:29 --> Router Class Initialized
INFO - 2024-06-11 08:27:29 --> Output Class Initialized
INFO - 2024-06-11 08:27:29 --> Security Class Initialized
DEBUG - 2024-06-11 08:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 08:27:29 --> Input Class Initialized
INFO - 2024-06-11 08:27:29 --> Language Class Initialized
INFO - 2024-06-11 08:27:29 --> Language Class Initialized
INFO - 2024-06-11 08:27:29 --> Config Class Initialized
INFO - 2024-06-11 08:27:29 --> Loader Class Initialized
INFO - 2024-06-11 08:27:29 --> Helper loaded: url_helper
INFO - 2024-06-11 08:27:29 --> Helper loaded: file_helper
INFO - 2024-06-11 08:27:29 --> Helper loaded: form_helper
INFO - 2024-06-11 08:27:29 --> Helper loaded: my_helper
INFO - 2024-06-11 08:27:29 --> Database Driver Class Initialized
INFO - 2024-06-11 08:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 08:27:30 --> Controller Class Initialized
DEBUG - 2024-06-11 08:27:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2024-06-11 08:27:30 --> Final output sent to browser
DEBUG - 2024-06-11 08:27:30 --> Total execution time: 0.2899
INFO - 2024-06-11 08:28:12 --> Config Class Initialized
INFO - 2024-06-11 08:28:12 --> Hooks Class Initialized
DEBUG - 2024-06-11 08:28:12 --> UTF-8 Support Enabled
INFO - 2024-06-11 08:28:12 --> Utf8 Class Initialized
INFO - 2024-06-11 08:28:12 --> URI Class Initialized
INFO - 2024-06-11 08:28:12 --> Router Class Initialized
INFO - 2024-06-11 08:28:12 --> Output Class Initialized
INFO - 2024-06-11 08:28:12 --> Security Class Initialized
DEBUG - 2024-06-11 08:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 08:28:12 --> Input Class Initialized
INFO - 2024-06-11 08:28:12 --> Language Class Initialized
INFO - 2024-06-11 08:28:12 --> Language Class Initialized
INFO - 2024-06-11 08:28:12 --> Config Class Initialized
INFO - 2024-06-11 08:28:12 --> Loader Class Initialized
INFO - 2024-06-11 08:28:12 --> Helper loaded: url_helper
INFO - 2024-06-11 08:28:12 --> Helper loaded: file_helper
INFO - 2024-06-11 08:28:12 --> Helper loaded: form_helper
INFO - 2024-06-11 08:28:12 --> Helper loaded: my_helper
INFO - 2024-06-11 08:28:12 --> Database Driver Class Initialized
INFO - 2024-06-11 08:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 08:28:12 --> Controller Class Initialized
INFO - 2024-06-11 08:49:23 --> Config Class Initialized
INFO - 2024-06-11 08:49:23 --> Hooks Class Initialized
DEBUG - 2024-06-11 08:49:23 --> UTF-8 Support Enabled
INFO - 2024-06-11 08:49:23 --> Utf8 Class Initialized
INFO - 2024-06-11 08:49:23 --> URI Class Initialized
INFO - 2024-06-11 08:49:23 --> Router Class Initialized
INFO - 2024-06-11 08:49:23 --> Output Class Initialized
INFO - 2024-06-11 08:49:23 --> Security Class Initialized
DEBUG - 2024-06-11 08:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 08:49:23 --> Input Class Initialized
INFO - 2024-06-11 08:49:23 --> Language Class Initialized
INFO - 2024-06-11 08:49:23 --> Language Class Initialized
INFO - 2024-06-11 08:49:23 --> Config Class Initialized
INFO - 2024-06-11 08:49:23 --> Loader Class Initialized
INFO - 2024-06-11 08:49:23 --> Helper loaded: url_helper
INFO - 2024-06-11 08:49:23 --> Helper loaded: file_helper
INFO - 2024-06-11 08:49:23 --> Helper loaded: form_helper
INFO - 2024-06-11 08:49:23 --> Helper loaded: my_helper
INFO - 2024-06-11 08:49:23 --> Database Driver Class Initialized
INFO - 2024-06-11 08:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 08:49:23 --> Controller Class Initialized
DEBUG - 2024-06-11 08:49:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-11 08:49:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 08:49:23 --> Final output sent to browser
DEBUG - 2024-06-11 08:49:23 --> Total execution time: 0.0910
INFO - 2024-06-11 09:32:37 --> Config Class Initialized
INFO - 2024-06-11 09:32:37 --> Hooks Class Initialized
DEBUG - 2024-06-11 09:32:37 --> UTF-8 Support Enabled
INFO - 2024-06-11 09:32:37 --> Utf8 Class Initialized
INFO - 2024-06-11 09:32:37 --> URI Class Initialized
INFO - 2024-06-11 09:32:37 --> Router Class Initialized
INFO - 2024-06-11 09:32:38 --> Output Class Initialized
INFO - 2024-06-11 09:32:38 --> Security Class Initialized
DEBUG - 2024-06-11 09:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 09:32:38 --> Input Class Initialized
INFO - 2024-06-11 09:32:38 --> Language Class Initialized
INFO - 2024-06-11 09:32:38 --> Language Class Initialized
INFO - 2024-06-11 09:32:38 --> Config Class Initialized
INFO - 2024-06-11 09:32:38 --> Loader Class Initialized
INFO - 2024-06-11 09:32:38 --> Helper loaded: url_helper
INFO - 2024-06-11 09:32:38 --> Helper loaded: file_helper
INFO - 2024-06-11 09:32:38 --> Helper loaded: form_helper
INFO - 2024-06-11 09:32:38 --> Helper loaded: my_helper
INFO - 2024-06-11 09:32:38 --> Database Driver Class Initialized
INFO - 2024-06-11 09:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 09:32:38 --> Controller Class Initialized
DEBUG - 2024-06-11 09:32:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-11 09:32:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 09:32:38 --> Final output sent to browser
DEBUG - 2024-06-11 09:32:38 --> Total execution time: 1.0106
INFO - 2024-06-11 09:50:07 --> Config Class Initialized
INFO - 2024-06-11 09:50:07 --> Hooks Class Initialized
DEBUG - 2024-06-11 09:50:07 --> UTF-8 Support Enabled
INFO - 2024-06-11 09:50:07 --> Utf8 Class Initialized
INFO - 2024-06-11 09:50:07 --> URI Class Initialized
INFO - 2024-06-11 09:50:07 --> Router Class Initialized
INFO - 2024-06-11 09:50:07 --> Output Class Initialized
INFO - 2024-06-11 09:50:07 --> Security Class Initialized
DEBUG - 2024-06-11 09:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 09:50:07 --> Input Class Initialized
INFO - 2024-06-11 09:50:07 --> Language Class Initialized
INFO - 2024-06-11 09:50:07 --> Language Class Initialized
INFO - 2024-06-11 09:50:07 --> Config Class Initialized
INFO - 2024-06-11 09:50:07 --> Loader Class Initialized
INFO - 2024-06-11 09:50:07 --> Helper loaded: url_helper
INFO - 2024-06-11 09:50:07 --> Helper loaded: file_helper
INFO - 2024-06-11 09:50:07 --> Helper loaded: form_helper
INFO - 2024-06-11 09:50:07 --> Helper loaded: my_helper
INFO - 2024-06-11 09:50:07 --> Database Driver Class Initialized
INFO - 2024-06-11 09:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 09:50:07 --> Controller Class Initialized
DEBUG - 2024-06-11 09:50:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-11 09:50:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 09:50:08 --> Final output sent to browser
DEBUG - 2024-06-11 09:50:08 --> Total execution time: 1.4548
INFO - 2024-06-11 09:50:08 --> Config Class Initialized
INFO - 2024-06-11 09:50:08 --> Hooks Class Initialized
DEBUG - 2024-06-11 09:50:09 --> UTF-8 Support Enabled
INFO - 2024-06-11 09:50:09 --> Utf8 Class Initialized
INFO - 2024-06-11 09:50:09 --> URI Class Initialized
INFO - 2024-06-11 09:50:09 --> Router Class Initialized
INFO - 2024-06-11 09:50:09 --> Output Class Initialized
INFO - 2024-06-11 09:50:09 --> Security Class Initialized
DEBUG - 2024-06-11 09:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 09:50:09 --> Input Class Initialized
INFO - 2024-06-11 09:50:09 --> Language Class Initialized
INFO - 2024-06-11 09:50:09 --> Language Class Initialized
INFO - 2024-06-11 09:50:09 --> Config Class Initialized
INFO - 2024-06-11 09:50:09 --> Loader Class Initialized
INFO - 2024-06-11 09:50:09 --> Helper loaded: url_helper
INFO - 2024-06-11 09:50:09 --> Helper loaded: file_helper
INFO - 2024-06-11 09:50:09 --> Helper loaded: form_helper
INFO - 2024-06-11 09:50:09 --> Helper loaded: my_helper
INFO - 2024-06-11 09:50:09 --> Database Driver Class Initialized
INFO - 2024-06-11 09:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 09:50:10 --> Controller Class Initialized
INFO - 2024-06-11 10:24:22 --> Config Class Initialized
INFO - 2024-06-11 10:24:22 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:24:22 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:24:22 --> Utf8 Class Initialized
INFO - 2024-06-11 10:24:22 --> URI Class Initialized
INFO - 2024-06-11 10:24:22 --> Router Class Initialized
INFO - 2024-06-11 10:24:22 --> Output Class Initialized
INFO - 2024-06-11 10:24:22 --> Security Class Initialized
DEBUG - 2024-06-11 10:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:24:22 --> Input Class Initialized
INFO - 2024-06-11 10:24:22 --> Language Class Initialized
INFO - 2024-06-11 10:24:22 --> Language Class Initialized
INFO - 2024-06-11 10:24:22 --> Config Class Initialized
INFO - 2024-06-11 10:24:22 --> Loader Class Initialized
INFO - 2024-06-11 10:24:22 --> Helper loaded: url_helper
INFO - 2024-06-11 10:24:22 --> Helper loaded: file_helper
INFO - 2024-06-11 10:24:22 --> Helper loaded: form_helper
INFO - 2024-06-11 10:24:22 --> Helper loaded: my_helper
INFO - 2024-06-11 10:24:22 --> Database Driver Class Initialized
INFO - 2024-06-11 10:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:24:22 --> Controller Class Initialized
DEBUG - 2024-06-11 10:24:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-11 10:24:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 10:24:23 --> Final output sent to browser
DEBUG - 2024-06-11 10:24:23 --> Total execution time: 0.8252
INFO - 2024-06-11 10:24:28 --> Config Class Initialized
INFO - 2024-06-11 10:24:28 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:24:28 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:24:28 --> Utf8 Class Initialized
INFO - 2024-06-11 10:24:28 --> URI Class Initialized
DEBUG - 2024-06-11 10:24:28 --> No URI present. Default controller set.
INFO - 2024-06-11 10:24:28 --> Router Class Initialized
INFO - 2024-06-11 10:24:28 --> Output Class Initialized
INFO - 2024-06-11 10:24:28 --> Security Class Initialized
DEBUG - 2024-06-11 10:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:24:28 --> Input Class Initialized
INFO - 2024-06-11 10:24:28 --> Language Class Initialized
INFO - 2024-06-11 10:24:28 --> Language Class Initialized
INFO - 2024-06-11 10:24:28 --> Config Class Initialized
INFO - 2024-06-11 10:24:28 --> Loader Class Initialized
INFO - 2024-06-11 10:24:28 --> Helper loaded: url_helper
INFO - 2024-06-11 10:24:28 --> Helper loaded: file_helper
INFO - 2024-06-11 10:24:28 --> Helper loaded: form_helper
INFO - 2024-06-11 10:24:28 --> Helper loaded: my_helper
INFO - 2024-06-11 10:24:28 --> Database Driver Class Initialized
INFO - 2024-06-11 10:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:24:28 --> Controller Class Initialized
DEBUG - 2024-06-11 10:24:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-11 10:24:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 10:24:29 --> Final output sent to browser
DEBUG - 2024-06-11 10:24:29 --> Total execution time: 0.7759
INFO - 2024-06-11 10:24:33 --> Config Class Initialized
INFO - 2024-06-11 10:24:33 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:24:33 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:24:33 --> Utf8 Class Initialized
INFO - 2024-06-11 10:24:33 --> URI Class Initialized
INFO - 2024-06-11 10:24:33 --> Router Class Initialized
INFO - 2024-06-11 10:24:33 --> Output Class Initialized
INFO - 2024-06-11 10:24:33 --> Security Class Initialized
DEBUG - 2024-06-11 10:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:24:33 --> Input Class Initialized
INFO - 2024-06-11 10:24:33 --> Language Class Initialized
INFO - 2024-06-11 10:24:33 --> Language Class Initialized
INFO - 2024-06-11 10:24:33 --> Config Class Initialized
INFO - 2024-06-11 10:24:33 --> Loader Class Initialized
INFO - 2024-06-11 10:24:33 --> Helper loaded: url_helper
INFO - 2024-06-11 10:24:33 --> Helper loaded: file_helper
INFO - 2024-06-11 10:24:33 --> Helper loaded: form_helper
INFO - 2024-06-11 10:24:33 --> Helper loaded: my_helper
INFO - 2024-06-11 10:24:33 --> Database Driver Class Initialized
INFO - 2024-06-11 10:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:24:33 --> Controller Class Initialized
INFO - 2024-06-11 10:24:33 --> Helper loaded: cookie_helper
INFO - 2024-06-11 10:24:33 --> Config Class Initialized
INFO - 2024-06-11 10:24:33 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:24:33 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:24:33 --> Utf8 Class Initialized
INFO - 2024-06-11 10:24:33 --> URI Class Initialized
INFO - 2024-06-11 10:24:33 --> Router Class Initialized
INFO - 2024-06-11 10:24:33 --> Output Class Initialized
INFO - 2024-06-11 10:24:33 --> Security Class Initialized
DEBUG - 2024-06-11 10:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:24:33 --> Input Class Initialized
INFO - 2024-06-11 10:24:33 --> Language Class Initialized
INFO - 2024-06-11 10:24:33 --> Language Class Initialized
INFO - 2024-06-11 10:24:33 --> Config Class Initialized
INFO - 2024-06-11 10:24:33 --> Loader Class Initialized
INFO - 2024-06-11 10:24:33 --> Helper loaded: url_helper
INFO - 2024-06-11 10:24:33 --> Helper loaded: file_helper
INFO - 2024-06-11 10:24:33 --> Helper loaded: form_helper
INFO - 2024-06-11 10:24:33 --> Helper loaded: my_helper
INFO - 2024-06-11 10:24:33 --> Database Driver Class Initialized
INFO - 2024-06-11 10:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:24:33 --> Controller Class Initialized
INFO - 2024-06-11 10:24:34 --> Config Class Initialized
INFO - 2024-06-11 10:24:34 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:24:34 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:24:34 --> Utf8 Class Initialized
INFO - 2024-06-11 10:24:34 --> URI Class Initialized
INFO - 2024-06-11 10:24:34 --> Router Class Initialized
INFO - 2024-06-11 10:24:34 --> Output Class Initialized
INFO - 2024-06-11 10:24:34 --> Security Class Initialized
DEBUG - 2024-06-11 10:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:24:34 --> Input Class Initialized
INFO - 2024-06-11 10:24:34 --> Language Class Initialized
INFO - 2024-06-11 10:24:34 --> Language Class Initialized
INFO - 2024-06-11 10:24:34 --> Config Class Initialized
INFO - 2024-06-11 10:24:34 --> Loader Class Initialized
INFO - 2024-06-11 10:24:34 --> Helper loaded: url_helper
INFO - 2024-06-11 10:24:34 --> Helper loaded: file_helper
INFO - 2024-06-11 10:24:35 --> Helper loaded: form_helper
INFO - 2024-06-11 10:24:35 --> Helper loaded: my_helper
INFO - 2024-06-11 10:24:35 --> Database Driver Class Initialized
INFO - 2024-06-11 10:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:24:35 --> Controller Class Initialized
DEBUG - 2024-06-11 10:24:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-11 10:24:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 10:24:35 --> Final output sent to browser
DEBUG - 2024-06-11 10:24:35 --> Total execution time: 1.5441
INFO - 2024-06-11 10:24:37 --> Config Class Initialized
INFO - 2024-06-11 10:24:37 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:24:37 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:24:37 --> Utf8 Class Initialized
INFO - 2024-06-11 10:24:37 --> URI Class Initialized
INFO - 2024-06-11 10:24:37 --> Router Class Initialized
INFO - 2024-06-11 10:24:37 --> Output Class Initialized
INFO - 2024-06-11 10:24:37 --> Security Class Initialized
DEBUG - 2024-06-11 10:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:24:37 --> Input Class Initialized
INFO - 2024-06-11 10:24:37 --> Language Class Initialized
INFO - 2024-06-11 10:24:37 --> Language Class Initialized
INFO - 2024-06-11 10:24:37 --> Config Class Initialized
INFO - 2024-06-11 10:24:37 --> Loader Class Initialized
INFO - 2024-06-11 10:24:37 --> Helper loaded: url_helper
INFO - 2024-06-11 10:24:37 --> Helper loaded: file_helper
INFO - 2024-06-11 10:24:37 --> Helper loaded: form_helper
INFO - 2024-06-11 10:24:37 --> Helper loaded: my_helper
INFO - 2024-06-11 10:24:37 --> Database Driver Class Initialized
INFO - 2024-06-11 10:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:24:37 --> Controller Class Initialized
INFO - 2024-06-11 10:24:38 --> Helper loaded: cookie_helper
INFO - 2024-06-11 10:24:38 --> Final output sent to browser
DEBUG - 2024-06-11 10:24:38 --> Total execution time: 1.0962
INFO - 2024-06-11 10:24:38 --> Config Class Initialized
INFO - 2024-06-11 10:24:38 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:24:38 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:24:38 --> Utf8 Class Initialized
INFO - 2024-06-11 10:24:38 --> URI Class Initialized
INFO - 2024-06-11 10:24:38 --> Router Class Initialized
INFO - 2024-06-11 10:24:38 --> Output Class Initialized
INFO - 2024-06-11 10:24:38 --> Security Class Initialized
DEBUG - 2024-06-11 10:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:24:38 --> Input Class Initialized
INFO - 2024-06-11 10:24:38 --> Language Class Initialized
INFO - 2024-06-11 10:24:38 --> Language Class Initialized
INFO - 2024-06-11 10:24:38 --> Config Class Initialized
INFO - 2024-06-11 10:24:38 --> Loader Class Initialized
INFO - 2024-06-11 10:24:38 --> Helper loaded: url_helper
INFO - 2024-06-11 10:24:38 --> Helper loaded: file_helper
INFO - 2024-06-11 10:24:38 --> Helper loaded: form_helper
INFO - 2024-06-11 10:24:38 --> Helper loaded: my_helper
INFO - 2024-06-11 10:24:38 --> Database Driver Class Initialized
INFO - 2024-06-11 10:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:24:38 --> Controller Class Initialized
DEBUG - 2024-06-11 10:24:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-11 10:24:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 10:24:38 --> Final output sent to browser
DEBUG - 2024-06-11 10:24:38 --> Total execution time: 0.3540
INFO - 2024-06-11 10:24:53 --> Config Class Initialized
INFO - 2024-06-11 10:24:53 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:24:53 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:24:53 --> Utf8 Class Initialized
INFO - 2024-06-11 10:24:53 --> URI Class Initialized
INFO - 2024-06-11 10:24:53 --> Router Class Initialized
INFO - 2024-06-11 10:24:53 --> Output Class Initialized
INFO - 2024-06-11 10:24:53 --> Security Class Initialized
DEBUG - 2024-06-11 10:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:24:53 --> Input Class Initialized
INFO - 2024-06-11 10:24:53 --> Language Class Initialized
INFO - 2024-06-11 10:24:53 --> Language Class Initialized
INFO - 2024-06-11 10:24:53 --> Config Class Initialized
INFO - 2024-06-11 10:24:53 --> Loader Class Initialized
INFO - 2024-06-11 10:24:53 --> Helper loaded: url_helper
INFO - 2024-06-11 10:24:53 --> Helper loaded: file_helper
INFO - 2024-06-11 10:24:53 --> Helper loaded: form_helper
INFO - 2024-06-11 10:24:53 --> Helper loaded: my_helper
INFO - 2024-06-11 10:24:53 --> Database Driver Class Initialized
INFO - 2024-06-11 10:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:24:53 --> Controller Class Initialized
DEBUG - 2024-06-11 10:24:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-11 10:24:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 10:24:53 --> Final output sent to browser
DEBUG - 2024-06-11 10:24:53 --> Total execution time: 0.4811
INFO - 2024-06-11 10:24:57 --> Config Class Initialized
INFO - 2024-06-11 10:24:57 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:24:57 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:24:57 --> Utf8 Class Initialized
INFO - 2024-06-11 10:24:57 --> URI Class Initialized
INFO - 2024-06-11 10:24:57 --> Router Class Initialized
INFO - 2024-06-11 10:24:57 --> Output Class Initialized
INFO - 2024-06-11 10:24:57 --> Security Class Initialized
DEBUG - 2024-06-11 10:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:24:57 --> Input Class Initialized
INFO - 2024-06-11 10:24:57 --> Language Class Initialized
INFO - 2024-06-11 10:24:57 --> Language Class Initialized
INFO - 2024-06-11 10:24:57 --> Config Class Initialized
INFO - 2024-06-11 10:24:57 --> Loader Class Initialized
INFO - 2024-06-11 10:24:57 --> Helper loaded: url_helper
INFO - 2024-06-11 10:24:57 --> Helper loaded: file_helper
INFO - 2024-06-11 10:24:57 --> Helper loaded: form_helper
INFO - 2024-06-11 10:24:57 --> Helper loaded: my_helper
INFO - 2024-06-11 10:24:57 --> Database Driver Class Initialized
INFO - 2024-06-11 10:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:24:57 --> Controller Class Initialized
DEBUG - 2024-06-11 10:24:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-11 10:24:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 10:24:57 --> Final output sent to browser
DEBUG - 2024-06-11 10:24:57 --> Total execution time: 0.3583
INFO - 2024-06-11 10:24:58 --> Config Class Initialized
INFO - 2024-06-11 10:24:58 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:24:58 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:24:58 --> Utf8 Class Initialized
INFO - 2024-06-11 10:24:58 --> URI Class Initialized
INFO - 2024-06-11 10:24:58 --> Router Class Initialized
INFO - 2024-06-11 10:24:58 --> Output Class Initialized
INFO - 2024-06-11 10:24:58 --> Security Class Initialized
DEBUG - 2024-06-11 10:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:24:58 --> Input Class Initialized
INFO - 2024-06-11 10:24:58 --> Language Class Initialized
INFO - 2024-06-11 10:24:58 --> Language Class Initialized
INFO - 2024-06-11 10:24:58 --> Config Class Initialized
INFO - 2024-06-11 10:24:58 --> Loader Class Initialized
INFO - 2024-06-11 10:24:58 --> Helper loaded: url_helper
INFO - 2024-06-11 10:24:58 --> Helper loaded: file_helper
INFO - 2024-06-11 10:24:58 --> Helper loaded: form_helper
INFO - 2024-06-11 10:24:58 --> Helper loaded: my_helper
INFO - 2024-06-11 10:24:58 --> Database Driver Class Initialized
INFO - 2024-06-11 10:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:24:58 --> Controller Class Initialized
INFO - 2024-06-11 10:25:38 --> Config Class Initialized
INFO - 2024-06-11 10:25:38 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:25:38 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:25:38 --> Utf8 Class Initialized
INFO - 2024-06-11 10:25:38 --> URI Class Initialized
INFO - 2024-06-11 10:25:38 --> Router Class Initialized
INFO - 2024-06-11 10:25:38 --> Output Class Initialized
INFO - 2024-06-11 10:25:38 --> Security Class Initialized
DEBUG - 2024-06-11 10:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:25:38 --> Input Class Initialized
INFO - 2024-06-11 10:25:38 --> Language Class Initialized
INFO - 2024-06-11 10:25:39 --> Language Class Initialized
INFO - 2024-06-11 10:25:39 --> Config Class Initialized
INFO - 2024-06-11 10:25:39 --> Loader Class Initialized
INFO - 2024-06-11 10:25:39 --> Helper loaded: url_helper
INFO - 2024-06-11 10:25:39 --> Helper loaded: file_helper
INFO - 2024-06-11 10:25:39 --> Helper loaded: form_helper
INFO - 2024-06-11 10:25:39 --> Helper loaded: my_helper
INFO - 2024-06-11 10:25:39 --> Database Driver Class Initialized
INFO - 2024-06-11 10:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:25:39 --> Controller Class Initialized
INFO - 2024-06-11 10:25:39 --> Final output sent to browser
DEBUG - 2024-06-11 10:25:39 --> Total execution time: 0.3942
INFO - 2024-06-11 10:25:51 --> Config Class Initialized
INFO - 2024-06-11 10:25:51 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:25:51 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:25:51 --> Utf8 Class Initialized
INFO - 2024-06-11 10:25:51 --> URI Class Initialized
INFO - 2024-06-11 10:25:51 --> Router Class Initialized
INFO - 2024-06-11 10:25:51 --> Output Class Initialized
INFO - 2024-06-11 10:25:51 --> Security Class Initialized
DEBUG - 2024-06-11 10:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:25:51 --> Input Class Initialized
INFO - 2024-06-11 10:25:51 --> Language Class Initialized
INFO - 2024-06-11 10:25:51 --> Language Class Initialized
INFO - 2024-06-11 10:25:51 --> Config Class Initialized
INFO - 2024-06-11 10:25:51 --> Loader Class Initialized
INFO - 2024-06-11 10:25:51 --> Helper loaded: url_helper
INFO - 2024-06-11 10:25:51 --> Helper loaded: file_helper
INFO - 2024-06-11 10:25:51 --> Helper loaded: form_helper
INFO - 2024-06-11 10:25:51 --> Helper loaded: my_helper
INFO - 2024-06-11 10:25:51 --> Database Driver Class Initialized
INFO - 2024-06-11 10:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:25:52 --> Controller Class Initialized
INFO - 2024-06-11 10:25:52 --> Final output sent to browser
DEBUG - 2024-06-11 10:25:52 --> Total execution time: 0.2663
INFO - 2024-06-11 10:25:52 --> Config Class Initialized
INFO - 2024-06-11 10:25:52 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:25:52 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:25:52 --> Utf8 Class Initialized
INFO - 2024-06-11 10:25:52 --> URI Class Initialized
INFO - 2024-06-11 10:25:52 --> Router Class Initialized
INFO - 2024-06-11 10:25:52 --> Output Class Initialized
INFO - 2024-06-11 10:25:52 --> Security Class Initialized
DEBUG - 2024-06-11 10:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:25:52 --> Input Class Initialized
INFO - 2024-06-11 10:25:52 --> Language Class Initialized
INFO - 2024-06-11 10:25:52 --> Language Class Initialized
INFO - 2024-06-11 10:25:52 --> Config Class Initialized
INFO - 2024-06-11 10:25:52 --> Loader Class Initialized
INFO - 2024-06-11 10:25:52 --> Helper loaded: url_helper
INFO - 2024-06-11 10:25:52 --> Helper loaded: file_helper
INFO - 2024-06-11 10:25:52 --> Helper loaded: form_helper
INFO - 2024-06-11 10:25:52 --> Helper loaded: my_helper
INFO - 2024-06-11 10:25:52 --> Database Driver Class Initialized
INFO - 2024-06-11 10:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:25:52 --> Controller Class Initialized
INFO - 2024-06-11 10:26:00 --> Config Class Initialized
INFO - 2024-06-11 10:26:00 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:26:00 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:26:00 --> Utf8 Class Initialized
INFO - 2024-06-11 10:26:00 --> URI Class Initialized
INFO - 2024-06-11 10:26:00 --> Router Class Initialized
INFO - 2024-06-11 10:26:00 --> Output Class Initialized
INFO - 2024-06-11 10:26:00 --> Security Class Initialized
DEBUG - 2024-06-11 10:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:26:00 --> Input Class Initialized
INFO - 2024-06-11 10:26:00 --> Language Class Initialized
INFO - 2024-06-11 10:26:01 --> Language Class Initialized
INFO - 2024-06-11 10:26:01 --> Config Class Initialized
INFO - 2024-06-11 10:26:01 --> Loader Class Initialized
INFO - 2024-06-11 10:26:01 --> Helper loaded: url_helper
INFO - 2024-06-11 10:26:01 --> Helper loaded: file_helper
INFO - 2024-06-11 10:26:01 --> Helper loaded: form_helper
INFO - 2024-06-11 10:26:01 --> Helper loaded: my_helper
INFO - 2024-06-11 10:26:01 --> Database Driver Class Initialized
INFO - 2024-06-11 10:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:26:01 --> Controller Class Initialized
INFO - 2024-06-11 10:26:01 --> Final output sent to browser
DEBUG - 2024-06-11 10:26:01 --> Total execution time: 0.2834
INFO - 2024-06-11 10:26:12 --> Config Class Initialized
INFO - 2024-06-11 10:26:12 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:26:12 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:26:12 --> Utf8 Class Initialized
INFO - 2024-06-11 10:26:12 --> URI Class Initialized
INFO - 2024-06-11 10:26:12 --> Router Class Initialized
INFO - 2024-06-11 10:26:12 --> Output Class Initialized
INFO - 2024-06-11 10:26:12 --> Security Class Initialized
DEBUG - 2024-06-11 10:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:26:12 --> Input Class Initialized
INFO - 2024-06-11 10:26:12 --> Language Class Initialized
INFO - 2024-06-11 10:26:12 --> Language Class Initialized
INFO - 2024-06-11 10:26:12 --> Config Class Initialized
INFO - 2024-06-11 10:26:12 --> Loader Class Initialized
INFO - 2024-06-11 10:26:12 --> Helper loaded: url_helper
INFO - 2024-06-11 10:26:12 --> Helper loaded: file_helper
INFO - 2024-06-11 10:26:12 --> Helper loaded: form_helper
INFO - 2024-06-11 10:26:12 --> Helper loaded: my_helper
INFO - 2024-06-11 10:26:12 --> Database Driver Class Initialized
INFO - 2024-06-11 10:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:26:13 --> Controller Class Initialized
INFO - 2024-06-11 10:26:13 --> Final output sent to browser
DEBUG - 2024-06-11 10:26:13 --> Total execution time: 0.2964
INFO - 2024-06-11 10:26:13 --> Config Class Initialized
INFO - 2024-06-11 10:26:13 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:26:13 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:26:13 --> Utf8 Class Initialized
INFO - 2024-06-11 10:26:13 --> URI Class Initialized
INFO - 2024-06-11 10:26:13 --> Router Class Initialized
INFO - 2024-06-11 10:26:13 --> Output Class Initialized
INFO - 2024-06-11 10:26:13 --> Security Class Initialized
DEBUG - 2024-06-11 10:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:26:13 --> Input Class Initialized
INFO - 2024-06-11 10:26:13 --> Language Class Initialized
INFO - 2024-06-11 10:26:13 --> Language Class Initialized
INFO - 2024-06-11 10:26:13 --> Config Class Initialized
INFO - 2024-06-11 10:26:13 --> Loader Class Initialized
INFO - 2024-06-11 10:26:13 --> Helper loaded: url_helper
INFO - 2024-06-11 10:26:13 --> Helper loaded: file_helper
INFO - 2024-06-11 10:26:13 --> Helper loaded: form_helper
INFO - 2024-06-11 10:26:13 --> Helper loaded: my_helper
INFO - 2024-06-11 10:26:13 --> Database Driver Class Initialized
INFO - 2024-06-11 10:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:26:13 --> Controller Class Initialized
INFO - 2024-06-11 10:26:22 --> Config Class Initialized
INFO - 2024-06-11 10:26:22 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:26:22 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:26:22 --> Utf8 Class Initialized
INFO - 2024-06-11 10:26:22 --> URI Class Initialized
INFO - 2024-06-11 10:26:22 --> Router Class Initialized
INFO - 2024-06-11 10:26:22 --> Output Class Initialized
INFO - 2024-06-11 10:26:22 --> Security Class Initialized
DEBUG - 2024-06-11 10:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:26:22 --> Input Class Initialized
INFO - 2024-06-11 10:26:22 --> Language Class Initialized
INFO - 2024-06-11 10:26:22 --> Language Class Initialized
INFO - 2024-06-11 10:26:22 --> Config Class Initialized
INFO - 2024-06-11 10:26:22 --> Loader Class Initialized
INFO - 2024-06-11 10:26:22 --> Helper loaded: url_helper
INFO - 2024-06-11 10:26:22 --> Helper loaded: file_helper
INFO - 2024-06-11 10:26:22 --> Helper loaded: form_helper
INFO - 2024-06-11 10:26:22 --> Helper loaded: my_helper
INFO - 2024-06-11 10:26:22 --> Database Driver Class Initialized
INFO - 2024-06-11 10:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:26:22 --> Controller Class Initialized
INFO - 2024-06-11 10:26:22 --> Final output sent to browser
DEBUG - 2024-06-11 10:26:22 --> Total execution time: 0.1668
INFO - 2024-06-11 10:26:30 --> Config Class Initialized
INFO - 2024-06-11 10:26:30 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:26:30 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:26:30 --> Utf8 Class Initialized
INFO - 2024-06-11 10:26:30 --> URI Class Initialized
INFO - 2024-06-11 10:26:30 --> Router Class Initialized
INFO - 2024-06-11 10:26:30 --> Output Class Initialized
INFO - 2024-06-11 10:26:30 --> Security Class Initialized
DEBUG - 2024-06-11 10:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:26:30 --> Input Class Initialized
INFO - 2024-06-11 10:26:30 --> Language Class Initialized
INFO - 2024-06-11 10:26:30 --> Language Class Initialized
INFO - 2024-06-11 10:26:30 --> Config Class Initialized
INFO - 2024-06-11 10:26:30 --> Loader Class Initialized
INFO - 2024-06-11 10:26:30 --> Helper loaded: url_helper
INFO - 2024-06-11 10:26:30 --> Helper loaded: file_helper
INFO - 2024-06-11 10:26:30 --> Helper loaded: form_helper
INFO - 2024-06-11 10:26:30 --> Helper loaded: my_helper
INFO - 2024-06-11 10:26:31 --> Database Driver Class Initialized
INFO - 2024-06-11 10:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:26:31 --> Controller Class Initialized
INFO - 2024-06-11 10:26:31 --> Final output sent to browser
DEBUG - 2024-06-11 10:26:31 --> Total execution time: 0.8302
INFO - 2024-06-11 10:26:31 --> Config Class Initialized
INFO - 2024-06-11 10:26:31 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:26:31 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:26:31 --> Utf8 Class Initialized
INFO - 2024-06-11 10:26:32 --> URI Class Initialized
INFO - 2024-06-11 10:26:32 --> Router Class Initialized
INFO - 2024-06-11 10:26:32 --> Output Class Initialized
INFO - 2024-06-11 10:26:32 --> Security Class Initialized
DEBUG - 2024-06-11 10:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:26:32 --> Input Class Initialized
INFO - 2024-06-11 10:26:32 --> Language Class Initialized
INFO - 2024-06-11 10:26:32 --> Language Class Initialized
INFO - 2024-06-11 10:26:32 --> Config Class Initialized
INFO - 2024-06-11 10:26:32 --> Loader Class Initialized
INFO - 2024-06-11 10:26:32 --> Helper loaded: url_helper
INFO - 2024-06-11 10:26:32 --> Helper loaded: file_helper
INFO - 2024-06-11 10:26:32 --> Helper loaded: form_helper
INFO - 2024-06-11 10:26:32 --> Helper loaded: my_helper
INFO - 2024-06-11 10:26:32 --> Database Driver Class Initialized
INFO - 2024-06-11 10:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:26:32 --> Controller Class Initialized
INFO - 2024-06-11 10:26:36 --> Config Class Initialized
INFO - 2024-06-11 10:26:36 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:26:36 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:26:36 --> Utf8 Class Initialized
INFO - 2024-06-11 10:26:36 --> URI Class Initialized
INFO - 2024-06-11 10:26:36 --> Router Class Initialized
INFO - 2024-06-11 10:26:36 --> Output Class Initialized
INFO - 2024-06-11 10:26:36 --> Security Class Initialized
DEBUG - 2024-06-11 10:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:26:36 --> Input Class Initialized
INFO - 2024-06-11 10:26:36 --> Language Class Initialized
INFO - 2024-06-11 10:26:36 --> Language Class Initialized
INFO - 2024-06-11 10:26:36 --> Config Class Initialized
INFO - 2024-06-11 10:26:36 --> Loader Class Initialized
INFO - 2024-06-11 10:26:36 --> Helper loaded: url_helper
INFO - 2024-06-11 10:26:36 --> Helper loaded: file_helper
INFO - 2024-06-11 10:26:36 --> Helper loaded: form_helper
INFO - 2024-06-11 10:26:36 --> Helper loaded: my_helper
INFO - 2024-06-11 10:26:36 --> Database Driver Class Initialized
INFO - 2024-06-11 10:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:26:36 --> Controller Class Initialized
INFO - 2024-06-11 10:26:42 --> Config Class Initialized
INFO - 2024-06-11 10:26:42 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:26:42 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:26:42 --> Utf8 Class Initialized
INFO - 2024-06-11 10:26:42 --> URI Class Initialized
INFO - 2024-06-11 10:26:42 --> Router Class Initialized
INFO - 2024-06-11 10:26:42 --> Output Class Initialized
INFO - 2024-06-11 10:26:42 --> Security Class Initialized
DEBUG - 2024-06-11 10:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:26:42 --> Input Class Initialized
INFO - 2024-06-11 10:26:42 --> Language Class Initialized
INFO - 2024-06-11 10:26:42 --> Language Class Initialized
INFO - 2024-06-11 10:26:42 --> Config Class Initialized
INFO - 2024-06-11 10:26:42 --> Loader Class Initialized
INFO - 2024-06-11 10:26:42 --> Helper loaded: url_helper
INFO - 2024-06-11 10:26:42 --> Helper loaded: file_helper
INFO - 2024-06-11 10:26:42 --> Helper loaded: form_helper
INFO - 2024-06-11 10:26:42 --> Helper loaded: my_helper
INFO - 2024-06-11 10:26:42 --> Database Driver Class Initialized
INFO - 2024-06-11 10:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:26:42 --> Controller Class Initialized
INFO - 2024-06-11 10:26:43 --> Final output sent to browser
DEBUG - 2024-06-11 10:26:43 --> Total execution time: 0.5933
INFO - 2024-06-11 10:34:32 --> Config Class Initialized
INFO - 2024-06-11 10:34:32 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:34:32 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:34:32 --> Utf8 Class Initialized
INFO - 2024-06-11 10:34:32 --> URI Class Initialized
INFO - 2024-06-11 10:34:32 --> Router Class Initialized
INFO - 2024-06-11 10:34:32 --> Output Class Initialized
INFO - 2024-06-11 10:34:32 --> Security Class Initialized
DEBUG - 2024-06-11 10:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:34:32 --> Input Class Initialized
INFO - 2024-06-11 10:34:32 --> Language Class Initialized
INFO - 2024-06-11 10:34:32 --> Language Class Initialized
INFO - 2024-06-11 10:34:32 --> Config Class Initialized
INFO - 2024-06-11 10:34:32 --> Loader Class Initialized
INFO - 2024-06-11 10:34:32 --> Helper loaded: url_helper
INFO - 2024-06-11 10:34:32 --> Helper loaded: file_helper
INFO - 2024-06-11 10:34:32 --> Helper loaded: form_helper
INFO - 2024-06-11 10:34:32 --> Helper loaded: my_helper
INFO - 2024-06-11 10:34:33 --> Database Driver Class Initialized
INFO - 2024-06-11 10:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:34:33 --> Controller Class Initialized
DEBUG - 2024-06-11 10:34:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-11 10:34:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 10:34:33 --> Final output sent to browser
DEBUG - 2024-06-11 10:34:33 --> Total execution time: 0.2685
INFO - 2024-06-11 10:34:38 --> Config Class Initialized
INFO - 2024-06-11 10:34:38 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:34:38 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:34:38 --> Utf8 Class Initialized
INFO - 2024-06-11 10:34:38 --> URI Class Initialized
INFO - 2024-06-11 10:34:38 --> Router Class Initialized
INFO - 2024-06-11 10:34:38 --> Output Class Initialized
INFO - 2024-06-11 10:34:38 --> Security Class Initialized
DEBUG - 2024-06-11 10:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:34:38 --> Input Class Initialized
INFO - 2024-06-11 10:34:38 --> Language Class Initialized
INFO - 2024-06-11 10:34:38 --> Language Class Initialized
INFO - 2024-06-11 10:34:38 --> Config Class Initialized
INFO - 2024-06-11 10:34:38 --> Loader Class Initialized
INFO - 2024-06-11 10:34:38 --> Helper loaded: url_helper
INFO - 2024-06-11 10:34:38 --> Helper loaded: file_helper
INFO - 2024-06-11 10:34:38 --> Helper loaded: form_helper
INFO - 2024-06-11 10:34:38 --> Helper loaded: my_helper
INFO - 2024-06-11 10:34:39 --> Database Driver Class Initialized
INFO - 2024-06-11 10:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:34:39 --> Controller Class Initialized
DEBUG - 2024-06-11 10:34:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2024-06-11 10:34:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 10:34:39 --> Final output sent to browser
DEBUG - 2024-06-11 10:34:39 --> Total execution time: 0.7900
INFO - 2024-06-11 10:34:43 --> Config Class Initialized
INFO - 2024-06-11 10:34:43 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:34:43 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:34:43 --> Utf8 Class Initialized
INFO - 2024-06-11 10:34:43 --> URI Class Initialized
INFO - 2024-06-11 10:34:43 --> Router Class Initialized
INFO - 2024-06-11 10:34:43 --> Output Class Initialized
INFO - 2024-06-11 10:34:43 --> Security Class Initialized
DEBUG - 2024-06-11 10:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:34:43 --> Input Class Initialized
INFO - 2024-06-11 10:34:43 --> Language Class Initialized
INFO - 2024-06-11 10:34:43 --> Language Class Initialized
INFO - 2024-06-11 10:34:43 --> Config Class Initialized
INFO - 2024-06-11 10:34:43 --> Loader Class Initialized
INFO - 2024-06-11 10:34:43 --> Helper loaded: url_helper
INFO - 2024-06-11 10:34:43 --> Helper loaded: file_helper
INFO - 2024-06-11 10:34:43 --> Helper loaded: form_helper
INFO - 2024-06-11 10:34:43 --> Helper loaded: my_helper
INFO - 2024-06-11 10:34:43 --> Database Driver Class Initialized
INFO - 2024-06-11 10:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:34:43 --> Controller Class Initialized
ERROR - 2024-06-11 10:34:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:34:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:34:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:34:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:34:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:34:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:34:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:34:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:34:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:34:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:34:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:34:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:34:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:34:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:34:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:34:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
DEBUG - 2024-06-11 10:34:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2024-06-11 10:34:45 --> Final output sent to browser
DEBUG - 2024-06-11 10:34:45 --> Total execution time: 1.9691
INFO - 2024-06-11 10:34:58 --> Config Class Initialized
INFO - 2024-06-11 10:34:58 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:34:58 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:34:58 --> Utf8 Class Initialized
INFO - 2024-06-11 10:34:58 --> URI Class Initialized
INFO - 2024-06-11 10:34:58 --> Router Class Initialized
INFO - 2024-06-11 10:34:58 --> Output Class Initialized
INFO - 2024-06-11 10:34:58 --> Security Class Initialized
DEBUG - 2024-06-11 10:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:34:58 --> Input Class Initialized
INFO - 2024-06-11 10:34:58 --> Language Class Initialized
INFO - 2024-06-11 10:34:58 --> Language Class Initialized
INFO - 2024-06-11 10:34:58 --> Config Class Initialized
INFO - 2024-06-11 10:34:58 --> Loader Class Initialized
INFO - 2024-06-11 10:34:58 --> Helper loaded: url_helper
INFO - 2024-06-11 10:34:58 --> Helper loaded: file_helper
INFO - 2024-06-11 10:34:58 --> Helper loaded: form_helper
INFO - 2024-06-11 10:34:58 --> Helper loaded: my_helper
INFO - 2024-06-11 10:34:58 --> Database Driver Class Initialized
INFO - 2024-06-11 10:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:34:59 --> Controller Class Initialized
ERROR - 2024-06-11 10:34:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:34:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:34:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:34:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:34:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:34:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:34:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:34:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:34:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:34:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:34:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:34:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:34:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:34:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:34:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:34:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
DEBUG - 2024-06-11 10:34:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2024-06-11 10:34:59 --> Final output sent to browser
DEBUG - 2024-06-11 10:34:59 --> Total execution time: 0.6143
INFO - 2024-06-11 10:35:03 --> Config Class Initialized
INFO - 2024-06-11 10:35:03 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:35:03 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:35:03 --> Utf8 Class Initialized
INFO - 2024-06-11 10:35:03 --> URI Class Initialized
INFO - 2024-06-11 10:35:03 --> Router Class Initialized
INFO - 2024-06-11 10:35:03 --> Output Class Initialized
INFO - 2024-06-11 10:35:03 --> Security Class Initialized
DEBUG - 2024-06-11 10:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:35:03 --> Input Class Initialized
INFO - 2024-06-11 10:35:03 --> Language Class Initialized
INFO - 2024-06-11 10:35:03 --> Language Class Initialized
INFO - 2024-06-11 10:35:03 --> Config Class Initialized
INFO - 2024-06-11 10:35:03 --> Loader Class Initialized
INFO - 2024-06-11 10:35:03 --> Helper loaded: url_helper
INFO - 2024-06-11 10:35:03 --> Helper loaded: file_helper
INFO - 2024-06-11 10:35:03 --> Helper loaded: form_helper
INFO - 2024-06-11 10:35:03 --> Helper loaded: my_helper
INFO - 2024-06-11 10:35:03 --> Database Driver Class Initialized
INFO - 2024-06-11 10:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:35:03 --> Controller Class Initialized
DEBUG - 2024-06-11 10:35:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_keterampilan/views/cetak.php
INFO - 2024-06-11 10:35:04 --> Final output sent to browser
DEBUG - 2024-06-11 10:35:04 --> Total execution time: 0.7531
INFO - 2024-06-11 10:35:09 --> Config Class Initialized
INFO - 2024-06-11 10:35:09 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:35:09 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:35:09 --> Utf8 Class Initialized
INFO - 2024-06-11 10:35:09 --> URI Class Initialized
INFO - 2024-06-11 10:35:09 --> Router Class Initialized
INFO - 2024-06-11 10:35:09 --> Output Class Initialized
INFO - 2024-06-11 10:35:09 --> Security Class Initialized
DEBUG - 2024-06-11 10:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:35:09 --> Input Class Initialized
INFO - 2024-06-11 10:35:09 --> Language Class Initialized
INFO - 2024-06-11 10:35:09 --> Language Class Initialized
INFO - 2024-06-11 10:35:09 --> Config Class Initialized
INFO - 2024-06-11 10:35:09 --> Loader Class Initialized
INFO - 2024-06-11 10:35:09 --> Helper loaded: url_helper
INFO - 2024-06-11 10:35:09 --> Helper loaded: file_helper
INFO - 2024-06-11 10:35:09 --> Helper loaded: form_helper
INFO - 2024-06-11 10:35:09 --> Helper loaded: my_helper
INFO - 2024-06-11 10:35:09 --> Database Driver Class Initialized
INFO - 2024-06-11 10:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:35:09 --> Controller Class Initialized
DEBUG - 2024-06-11 10:35:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2024-06-11 10:35:09 --> Final output sent to browser
DEBUG - 2024-06-11 10:35:09 --> Total execution time: 0.9858
INFO - 2024-06-11 10:35:15 --> Config Class Initialized
INFO - 2024-06-11 10:35:15 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:35:15 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:35:15 --> Utf8 Class Initialized
INFO - 2024-06-11 10:35:15 --> URI Class Initialized
INFO - 2024-06-11 10:35:15 --> Router Class Initialized
INFO - 2024-06-11 10:35:15 --> Output Class Initialized
INFO - 2024-06-11 10:35:15 --> Security Class Initialized
DEBUG - 2024-06-11 10:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:35:15 --> Input Class Initialized
INFO - 2024-06-11 10:35:15 --> Language Class Initialized
INFO - 2024-06-11 10:35:15 --> Language Class Initialized
INFO - 2024-06-11 10:35:15 --> Config Class Initialized
INFO - 2024-06-11 10:35:15 --> Loader Class Initialized
INFO - 2024-06-11 10:35:15 --> Helper loaded: url_helper
INFO - 2024-06-11 10:35:15 --> Helper loaded: file_helper
INFO - 2024-06-11 10:35:15 --> Helper loaded: form_helper
INFO - 2024-06-11 10:35:15 --> Helper loaded: my_helper
INFO - 2024-06-11 10:35:15 --> Database Driver Class Initialized
INFO - 2024-06-11 10:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:35:15 --> Controller Class Initialized
ERROR - 2024-06-11 10:35:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:35:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:35:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:35:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:35:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:35:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:35:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:35:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:35:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:35:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:35:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:35:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:35:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:35:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:35:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2024-06-11 10:35:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
DEBUG - 2024-06-11 10:35:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2024-06-11 10:35:15 --> Final output sent to browser
DEBUG - 2024-06-11 10:35:15 --> Total execution time: 0.2774
INFO - 2024-06-11 10:35:36 --> Config Class Initialized
INFO - 2024-06-11 10:35:36 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:35:36 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:35:36 --> Utf8 Class Initialized
INFO - 2024-06-11 10:35:36 --> URI Class Initialized
INFO - 2024-06-11 10:35:36 --> Router Class Initialized
INFO - 2024-06-11 10:35:36 --> Output Class Initialized
INFO - 2024-06-11 10:35:36 --> Security Class Initialized
DEBUG - 2024-06-11 10:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:35:36 --> Input Class Initialized
INFO - 2024-06-11 10:35:36 --> Language Class Initialized
INFO - 2024-06-11 10:35:36 --> Language Class Initialized
INFO - 2024-06-11 10:35:36 --> Config Class Initialized
INFO - 2024-06-11 10:35:36 --> Loader Class Initialized
INFO - 2024-06-11 10:35:36 --> Helper loaded: url_helper
INFO - 2024-06-11 10:35:36 --> Helper loaded: file_helper
INFO - 2024-06-11 10:35:37 --> Helper loaded: form_helper
INFO - 2024-06-11 10:35:37 --> Helper loaded: my_helper
INFO - 2024-06-11 10:35:37 --> Database Driver Class Initialized
INFO - 2024-06-11 10:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:35:37 --> Controller Class Initialized
DEBUG - 2024-06-11 10:35:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2024-06-11 10:35:37 --> Final output sent to browser
DEBUG - 2024-06-11 10:35:37 --> Total execution time: 1.3208
INFO - 2024-06-11 10:45:26 --> Config Class Initialized
INFO - 2024-06-11 10:45:26 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:45:26 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:45:26 --> Utf8 Class Initialized
INFO - 2024-06-11 10:45:26 --> URI Class Initialized
INFO - 2024-06-11 10:45:26 --> Router Class Initialized
INFO - 2024-06-11 10:45:26 --> Output Class Initialized
INFO - 2024-06-11 10:45:26 --> Security Class Initialized
DEBUG - 2024-06-11 10:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:45:26 --> Input Class Initialized
INFO - 2024-06-11 10:45:26 --> Language Class Initialized
INFO - 2024-06-11 10:45:26 --> Language Class Initialized
INFO - 2024-06-11 10:45:26 --> Config Class Initialized
INFO - 2024-06-11 10:45:26 --> Loader Class Initialized
INFO - 2024-06-11 10:45:26 --> Helper loaded: url_helper
INFO - 2024-06-11 10:45:26 --> Helper loaded: file_helper
INFO - 2024-06-11 10:45:26 --> Helper loaded: form_helper
INFO - 2024-06-11 10:45:26 --> Helper loaded: my_helper
INFO - 2024-06-11 10:45:26 --> Database Driver Class Initialized
INFO - 2024-06-11 10:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:45:27 --> Controller Class Initialized
DEBUG - 2024-06-11 10:45:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-11 10:45:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 10:45:27 --> Final output sent to browser
DEBUG - 2024-06-11 10:45:27 --> Total execution time: 0.8290
INFO - 2024-06-11 10:45:30 --> Config Class Initialized
INFO - 2024-06-11 10:45:30 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:45:30 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:45:30 --> Utf8 Class Initialized
INFO - 2024-06-11 10:45:30 --> URI Class Initialized
INFO - 2024-06-11 10:45:30 --> Router Class Initialized
INFO - 2024-06-11 10:45:30 --> Output Class Initialized
INFO - 2024-06-11 10:45:30 --> Security Class Initialized
DEBUG - 2024-06-11 10:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:45:30 --> Input Class Initialized
INFO - 2024-06-11 10:45:30 --> Language Class Initialized
INFO - 2024-06-11 10:45:30 --> Language Class Initialized
INFO - 2024-06-11 10:45:30 --> Config Class Initialized
INFO - 2024-06-11 10:45:30 --> Loader Class Initialized
INFO - 2024-06-11 10:45:30 --> Helper loaded: url_helper
INFO - 2024-06-11 10:45:30 --> Helper loaded: file_helper
INFO - 2024-06-11 10:45:30 --> Helper loaded: form_helper
INFO - 2024-06-11 10:45:30 --> Helper loaded: my_helper
INFO - 2024-06-11 10:45:31 --> Database Driver Class Initialized
INFO - 2024-06-11 10:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:45:31 --> Controller Class Initialized
DEBUG - 2024-06-11 10:45:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-11 10:45:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 10:45:31 --> Final output sent to browser
DEBUG - 2024-06-11 10:45:31 --> Total execution time: 0.2621
INFO - 2024-06-11 10:45:31 --> Config Class Initialized
INFO - 2024-06-11 10:45:31 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:45:31 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:45:31 --> Utf8 Class Initialized
INFO - 2024-06-11 10:45:31 --> URI Class Initialized
INFO - 2024-06-11 10:45:31 --> Router Class Initialized
INFO - 2024-06-11 10:45:32 --> Output Class Initialized
INFO - 2024-06-11 10:45:32 --> Security Class Initialized
DEBUG - 2024-06-11 10:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:45:32 --> Input Class Initialized
INFO - 2024-06-11 10:45:32 --> Language Class Initialized
INFO - 2024-06-11 10:45:32 --> Language Class Initialized
INFO - 2024-06-11 10:45:32 --> Config Class Initialized
INFO - 2024-06-11 10:45:32 --> Loader Class Initialized
INFO - 2024-06-11 10:45:32 --> Helper loaded: url_helper
INFO - 2024-06-11 10:45:32 --> Helper loaded: file_helper
INFO - 2024-06-11 10:45:32 --> Helper loaded: form_helper
INFO - 2024-06-11 10:45:32 --> Helper loaded: my_helper
INFO - 2024-06-11 10:45:32 --> Database Driver Class Initialized
INFO - 2024-06-11 10:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:45:32 --> Controller Class Initialized
INFO - 2024-06-11 10:45:43 --> Config Class Initialized
INFO - 2024-06-11 10:45:43 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:45:43 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:45:43 --> Utf8 Class Initialized
INFO - 2024-06-11 10:45:43 --> URI Class Initialized
INFO - 2024-06-11 10:45:43 --> Router Class Initialized
INFO - 2024-06-11 10:45:43 --> Output Class Initialized
INFO - 2024-06-11 10:45:43 --> Security Class Initialized
DEBUG - 2024-06-11 10:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:45:43 --> Input Class Initialized
INFO - 2024-06-11 10:45:43 --> Language Class Initialized
INFO - 2024-06-11 10:45:43 --> Language Class Initialized
INFO - 2024-06-11 10:45:43 --> Config Class Initialized
INFO - 2024-06-11 10:45:43 --> Loader Class Initialized
INFO - 2024-06-11 10:45:43 --> Helper loaded: url_helper
INFO - 2024-06-11 10:45:43 --> Helper loaded: file_helper
INFO - 2024-06-11 10:45:43 --> Helper loaded: form_helper
INFO - 2024-06-11 10:45:43 --> Helper loaded: my_helper
INFO - 2024-06-11 10:45:43 --> Database Driver Class Initialized
INFO - 2024-06-11 10:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:45:43 --> Controller Class Initialized
DEBUG - 2024-06-11 10:45:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-06-11 10:45:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 10:45:43 --> Final output sent to browser
DEBUG - 2024-06-11 10:45:43 --> Total execution time: 0.8169
INFO - 2024-06-11 10:46:22 --> Config Class Initialized
INFO - 2024-06-11 10:46:22 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:46:22 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:46:22 --> Utf8 Class Initialized
INFO - 2024-06-11 10:46:22 --> URI Class Initialized
INFO - 2024-06-11 10:46:22 --> Router Class Initialized
INFO - 2024-06-11 10:46:22 --> Output Class Initialized
INFO - 2024-06-11 10:46:22 --> Security Class Initialized
DEBUG - 2024-06-11 10:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:46:22 --> Input Class Initialized
INFO - 2024-06-11 10:46:22 --> Language Class Initialized
INFO - 2024-06-11 10:46:22 --> Language Class Initialized
INFO - 2024-06-11 10:46:22 --> Config Class Initialized
INFO - 2024-06-11 10:46:22 --> Loader Class Initialized
INFO - 2024-06-11 10:46:22 --> Helper loaded: url_helper
INFO - 2024-06-11 10:46:22 --> Helper loaded: file_helper
INFO - 2024-06-11 10:46:22 --> Helper loaded: form_helper
INFO - 2024-06-11 10:46:22 --> Helper loaded: my_helper
INFO - 2024-06-11 10:46:22 --> Database Driver Class Initialized
INFO - 2024-06-11 10:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:46:22 --> Controller Class Initialized
INFO - 2024-06-11 10:46:23 --> Config Class Initialized
INFO - 2024-06-11 10:46:23 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:46:23 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:46:23 --> Utf8 Class Initialized
INFO - 2024-06-11 10:46:23 --> URI Class Initialized
INFO - 2024-06-11 10:46:23 --> Router Class Initialized
INFO - 2024-06-11 10:46:23 --> Output Class Initialized
INFO - 2024-06-11 10:46:23 --> Security Class Initialized
DEBUG - 2024-06-11 10:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:46:23 --> Input Class Initialized
INFO - 2024-06-11 10:46:23 --> Language Class Initialized
INFO - 2024-06-11 10:46:23 --> Language Class Initialized
INFO - 2024-06-11 10:46:23 --> Config Class Initialized
INFO - 2024-06-11 10:46:23 --> Loader Class Initialized
INFO - 2024-06-11 10:46:23 --> Helper loaded: url_helper
INFO - 2024-06-11 10:46:23 --> Helper loaded: file_helper
INFO - 2024-06-11 10:46:23 --> Helper loaded: form_helper
INFO - 2024-06-11 10:46:23 --> Helper loaded: my_helper
INFO - 2024-06-11 10:46:23 --> Database Driver Class Initialized
INFO - 2024-06-11 10:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:46:23 --> Controller Class Initialized
DEBUG - 2024-06-11 10:46:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-11 10:46:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 10:46:23 --> Final output sent to browser
DEBUG - 2024-06-11 10:46:23 --> Total execution time: 0.1420
INFO - 2024-06-11 10:46:23 --> Config Class Initialized
INFO - 2024-06-11 10:46:23 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:46:23 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:46:23 --> Utf8 Class Initialized
INFO - 2024-06-11 10:46:23 --> URI Class Initialized
INFO - 2024-06-11 10:46:23 --> Router Class Initialized
INFO - 2024-06-11 10:46:23 --> Output Class Initialized
INFO - 2024-06-11 10:46:23 --> Security Class Initialized
DEBUG - 2024-06-11 10:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:46:23 --> Input Class Initialized
INFO - 2024-06-11 10:46:23 --> Language Class Initialized
INFO - 2024-06-11 10:46:23 --> Language Class Initialized
INFO - 2024-06-11 10:46:23 --> Config Class Initialized
INFO - 2024-06-11 10:46:23 --> Loader Class Initialized
INFO - 2024-06-11 10:46:23 --> Helper loaded: url_helper
INFO - 2024-06-11 10:46:23 --> Helper loaded: file_helper
INFO - 2024-06-11 10:46:23 --> Helper loaded: form_helper
INFO - 2024-06-11 10:46:23 --> Helper loaded: my_helper
INFO - 2024-06-11 10:46:23 --> Database Driver Class Initialized
INFO - 2024-06-11 10:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:46:23 --> Controller Class Initialized
INFO - 2024-06-11 10:46:44 --> Config Class Initialized
INFO - 2024-06-11 10:46:44 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:46:44 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:46:44 --> Utf8 Class Initialized
INFO - 2024-06-11 10:46:44 --> URI Class Initialized
INFO - 2024-06-11 10:46:44 --> Router Class Initialized
INFO - 2024-06-11 10:46:44 --> Output Class Initialized
INFO - 2024-06-11 10:46:44 --> Security Class Initialized
DEBUG - 2024-06-11 10:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:46:44 --> Input Class Initialized
INFO - 2024-06-11 10:46:44 --> Language Class Initialized
INFO - 2024-06-11 10:46:44 --> Language Class Initialized
INFO - 2024-06-11 10:46:44 --> Config Class Initialized
INFO - 2024-06-11 10:46:44 --> Loader Class Initialized
INFO - 2024-06-11 10:46:44 --> Helper loaded: url_helper
INFO - 2024-06-11 10:46:44 --> Helper loaded: file_helper
INFO - 2024-06-11 10:46:44 --> Helper loaded: form_helper
INFO - 2024-06-11 10:46:44 --> Helper loaded: my_helper
INFO - 2024-06-11 10:46:44 --> Database Driver Class Initialized
INFO - 2024-06-11 10:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:46:44 --> Controller Class Initialized
INFO - 2024-06-11 10:46:44 --> Final output sent to browser
DEBUG - 2024-06-11 10:46:44 --> Total execution time: 0.2682
INFO - 2024-06-11 10:46:50 --> Config Class Initialized
INFO - 2024-06-11 10:46:50 --> Hooks Class Initialized
DEBUG - 2024-06-11 10:46:50 --> UTF-8 Support Enabled
INFO - 2024-06-11 10:46:50 --> Utf8 Class Initialized
INFO - 2024-06-11 10:46:50 --> URI Class Initialized
INFO - 2024-06-11 10:46:50 --> Router Class Initialized
INFO - 2024-06-11 10:46:50 --> Output Class Initialized
INFO - 2024-06-11 10:46:50 --> Security Class Initialized
DEBUG - 2024-06-11 10:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 10:46:50 --> Input Class Initialized
INFO - 2024-06-11 10:46:50 --> Language Class Initialized
INFO - 2024-06-11 10:46:50 --> Language Class Initialized
INFO - 2024-06-11 10:46:50 --> Config Class Initialized
INFO - 2024-06-11 10:46:50 --> Loader Class Initialized
INFO - 2024-06-11 10:46:50 --> Helper loaded: url_helper
INFO - 2024-06-11 10:46:50 --> Helper loaded: file_helper
INFO - 2024-06-11 10:46:50 --> Helper loaded: form_helper
INFO - 2024-06-11 10:46:50 --> Helper loaded: my_helper
INFO - 2024-06-11 10:46:50 --> Database Driver Class Initialized
INFO - 2024-06-11 10:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 10:46:50 --> Controller Class Initialized
DEBUG - 2024-06-11 10:46:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2024-06-11 10:46:50 --> Final output sent to browser
DEBUG - 2024-06-11 10:46:50 --> Total execution time: 0.5108
INFO - 2024-06-11 11:49:49 --> Config Class Initialized
INFO - 2024-06-11 11:49:49 --> Hooks Class Initialized
DEBUG - 2024-06-11 11:49:49 --> UTF-8 Support Enabled
INFO - 2024-06-11 11:49:49 --> Utf8 Class Initialized
INFO - 2024-06-11 11:49:49 --> URI Class Initialized
DEBUG - 2024-06-11 11:49:49 --> No URI present. Default controller set.
INFO - 2024-06-11 11:49:49 --> Router Class Initialized
INFO - 2024-06-11 11:49:49 --> Output Class Initialized
INFO - 2024-06-11 11:49:49 --> Security Class Initialized
DEBUG - 2024-06-11 11:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 11:49:49 --> Input Class Initialized
INFO - 2024-06-11 11:49:49 --> Language Class Initialized
INFO - 2024-06-11 11:49:49 --> Language Class Initialized
INFO - 2024-06-11 11:49:49 --> Config Class Initialized
INFO - 2024-06-11 11:49:49 --> Loader Class Initialized
INFO - 2024-06-11 11:49:49 --> Helper loaded: url_helper
INFO - 2024-06-11 11:49:49 --> Helper loaded: file_helper
INFO - 2024-06-11 11:49:49 --> Helper loaded: form_helper
INFO - 2024-06-11 11:49:49 --> Helper loaded: my_helper
INFO - 2024-06-11 11:49:49 --> Database Driver Class Initialized
INFO - 2024-06-11 11:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 11:49:49 --> Controller Class Initialized
DEBUG - 2024-06-11 11:49:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-11 11:49:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 11:49:50 --> Final output sent to browser
DEBUG - 2024-06-11 11:49:50 --> Total execution time: 0.8509
INFO - 2024-06-11 11:49:56 --> Config Class Initialized
INFO - 2024-06-11 11:49:56 --> Hooks Class Initialized
DEBUG - 2024-06-11 11:49:56 --> UTF-8 Support Enabled
INFO - 2024-06-11 11:49:56 --> Utf8 Class Initialized
INFO - 2024-06-11 11:49:57 --> URI Class Initialized
INFO - 2024-06-11 11:49:57 --> Router Class Initialized
INFO - 2024-06-11 11:49:57 --> Output Class Initialized
INFO - 2024-06-11 11:49:57 --> Security Class Initialized
DEBUG - 2024-06-11 11:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 11:49:57 --> Input Class Initialized
INFO - 2024-06-11 11:49:57 --> Language Class Initialized
INFO - 2024-06-11 11:49:57 --> Language Class Initialized
INFO - 2024-06-11 11:49:57 --> Config Class Initialized
INFO - 2024-06-11 11:49:57 --> Loader Class Initialized
INFO - 2024-06-11 11:49:57 --> Helper loaded: url_helper
INFO - 2024-06-11 11:49:57 --> Helper loaded: file_helper
INFO - 2024-06-11 11:49:57 --> Helper loaded: form_helper
INFO - 2024-06-11 11:49:57 --> Helper loaded: my_helper
INFO - 2024-06-11 11:49:57 --> Database Driver Class Initialized
INFO - 2024-06-11 11:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 11:49:57 --> Controller Class Initialized
DEBUG - 2024-06-11 11:49:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-11 11:49:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 11:49:57 --> Final output sent to browser
DEBUG - 2024-06-11 11:49:57 --> Total execution time: 0.5168
INFO - 2024-06-11 11:50:01 --> Config Class Initialized
INFO - 2024-06-11 11:50:01 --> Hooks Class Initialized
DEBUG - 2024-06-11 11:50:01 --> UTF-8 Support Enabled
INFO - 2024-06-11 11:50:01 --> Utf8 Class Initialized
INFO - 2024-06-11 11:50:01 --> URI Class Initialized
INFO - 2024-06-11 11:50:01 --> Router Class Initialized
INFO - 2024-06-11 11:50:01 --> Output Class Initialized
INFO - 2024-06-11 11:50:01 --> Security Class Initialized
DEBUG - 2024-06-11 11:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 11:50:01 --> Input Class Initialized
INFO - 2024-06-11 11:50:01 --> Language Class Initialized
INFO - 2024-06-11 11:50:01 --> Language Class Initialized
INFO - 2024-06-11 11:50:01 --> Config Class Initialized
INFO - 2024-06-11 11:50:01 --> Loader Class Initialized
INFO - 2024-06-11 11:50:01 --> Helper loaded: url_helper
INFO - 2024-06-11 11:50:01 --> Helper loaded: file_helper
INFO - 2024-06-11 11:50:01 --> Helper loaded: form_helper
INFO - 2024-06-11 11:50:01 --> Helper loaded: my_helper
INFO - 2024-06-11 11:50:01 --> Database Driver Class Initialized
INFO - 2024-06-11 11:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 11:50:01 --> Controller Class Initialized
DEBUG - 2024-06-11 11:50:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-11 11:50:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 11:50:02 --> Final output sent to browser
DEBUG - 2024-06-11 11:50:02 --> Total execution time: 1.0416
INFO - 2024-06-11 11:50:02 --> Config Class Initialized
INFO - 2024-06-11 11:50:02 --> Hooks Class Initialized
DEBUG - 2024-06-11 11:50:02 --> UTF-8 Support Enabled
INFO - 2024-06-11 11:50:02 --> Utf8 Class Initialized
INFO - 2024-06-11 11:50:02 --> URI Class Initialized
INFO - 2024-06-11 11:50:02 --> Router Class Initialized
INFO - 2024-06-11 11:50:02 --> Output Class Initialized
INFO - 2024-06-11 11:50:02 --> Security Class Initialized
DEBUG - 2024-06-11 11:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 11:50:02 --> Input Class Initialized
INFO - 2024-06-11 11:50:02 --> Language Class Initialized
INFO - 2024-06-11 11:50:02 --> Language Class Initialized
INFO - 2024-06-11 11:50:02 --> Config Class Initialized
INFO - 2024-06-11 11:50:02 --> Loader Class Initialized
INFO - 2024-06-11 11:50:02 --> Helper loaded: url_helper
INFO - 2024-06-11 11:50:02 --> Helper loaded: file_helper
INFO - 2024-06-11 11:50:02 --> Helper loaded: form_helper
INFO - 2024-06-11 11:50:02 --> Helper loaded: my_helper
INFO - 2024-06-11 11:50:03 --> Database Driver Class Initialized
INFO - 2024-06-11 11:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 11:50:03 --> Controller Class Initialized
INFO - 2024-06-11 11:50:20 --> Config Class Initialized
INFO - 2024-06-11 11:50:20 --> Hooks Class Initialized
DEBUG - 2024-06-11 11:50:20 --> UTF-8 Support Enabled
INFO - 2024-06-11 11:50:20 --> Utf8 Class Initialized
INFO - 2024-06-11 11:50:20 --> URI Class Initialized
INFO - 2024-06-11 11:50:20 --> Router Class Initialized
INFO - 2024-06-11 11:50:20 --> Output Class Initialized
INFO - 2024-06-11 11:50:20 --> Security Class Initialized
DEBUG - 2024-06-11 11:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 11:50:20 --> Input Class Initialized
INFO - 2024-06-11 11:50:20 --> Language Class Initialized
INFO - 2024-06-11 11:50:20 --> Language Class Initialized
INFO - 2024-06-11 11:50:20 --> Config Class Initialized
INFO - 2024-06-11 11:50:20 --> Loader Class Initialized
INFO - 2024-06-11 11:50:20 --> Helper loaded: url_helper
INFO - 2024-06-11 11:50:20 --> Helper loaded: file_helper
INFO - 2024-06-11 11:50:20 --> Helper loaded: form_helper
INFO - 2024-06-11 11:50:20 --> Helper loaded: my_helper
INFO - 2024-06-11 11:50:20 --> Database Driver Class Initialized
INFO - 2024-06-11 11:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 11:50:20 --> Controller Class Initialized
DEBUG - 2024-06-11 11:50:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-11 11:50:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 11:50:20 --> Final output sent to browser
DEBUG - 2024-06-11 11:50:20 --> Total execution time: 0.3964
INFO - 2024-06-11 11:52:30 --> Config Class Initialized
INFO - 2024-06-11 11:52:30 --> Hooks Class Initialized
DEBUG - 2024-06-11 11:52:30 --> UTF-8 Support Enabled
INFO - 2024-06-11 11:52:30 --> Utf8 Class Initialized
INFO - 2024-06-11 11:52:30 --> URI Class Initialized
INFO - 2024-06-11 11:52:30 --> Router Class Initialized
INFO - 2024-06-11 11:52:30 --> Output Class Initialized
INFO - 2024-06-11 11:52:30 --> Security Class Initialized
DEBUG - 2024-06-11 11:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 11:52:30 --> Input Class Initialized
INFO - 2024-06-11 11:52:30 --> Language Class Initialized
INFO - 2024-06-11 11:52:30 --> Language Class Initialized
INFO - 2024-06-11 11:52:30 --> Config Class Initialized
INFO - 2024-06-11 11:52:30 --> Loader Class Initialized
INFO - 2024-06-11 11:52:30 --> Helper loaded: url_helper
INFO - 2024-06-11 11:52:30 --> Helper loaded: file_helper
INFO - 2024-06-11 11:52:30 --> Helper loaded: form_helper
INFO - 2024-06-11 11:52:30 --> Helper loaded: my_helper
INFO - 2024-06-11 11:52:31 --> Database Driver Class Initialized
INFO - 2024-06-11 11:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 11:52:31 --> Controller Class Initialized
DEBUG - 2024-06-11 11:52:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-11 11:52:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 11:52:31 --> Final output sent to browser
DEBUG - 2024-06-11 11:52:31 --> Total execution time: 0.9655
INFO - 2024-06-11 11:52:45 --> Config Class Initialized
INFO - 2024-06-11 11:52:45 --> Hooks Class Initialized
DEBUG - 2024-06-11 11:52:45 --> UTF-8 Support Enabled
INFO - 2024-06-11 11:52:45 --> Utf8 Class Initialized
INFO - 2024-06-11 11:52:45 --> URI Class Initialized
INFO - 2024-06-11 11:52:45 --> Router Class Initialized
INFO - 2024-06-11 11:52:45 --> Output Class Initialized
INFO - 2024-06-11 11:52:45 --> Security Class Initialized
DEBUG - 2024-06-11 11:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 11:52:45 --> Input Class Initialized
INFO - 2024-06-11 11:52:45 --> Language Class Initialized
INFO - 2024-06-11 11:52:45 --> Language Class Initialized
INFO - 2024-06-11 11:52:45 --> Config Class Initialized
INFO - 2024-06-11 11:52:45 --> Loader Class Initialized
INFO - 2024-06-11 11:52:45 --> Helper loaded: url_helper
INFO - 2024-06-11 11:52:45 --> Helper loaded: file_helper
INFO - 2024-06-11 11:52:45 --> Helper loaded: form_helper
INFO - 2024-06-11 11:52:45 --> Helper loaded: my_helper
INFO - 2024-06-11 11:52:45 --> Database Driver Class Initialized
INFO - 2024-06-11 11:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 11:52:45 --> Controller Class Initialized
INFO - 2024-06-11 11:52:45 --> Helper loaded: cookie_helper
INFO - 2024-06-11 11:52:45 --> Final output sent to browser
DEBUG - 2024-06-11 11:52:45 --> Total execution time: 0.5715
INFO - 2024-06-11 11:52:45 --> Config Class Initialized
INFO - 2024-06-11 11:52:45 --> Hooks Class Initialized
DEBUG - 2024-06-11 11:52:45 --> UTF-8 Support Enabled
INFO - 2024-06-11 11:52:45 --> Utf8 Class Initialized
INFO - 2024-06-11 11:52:45 --> URI Class Initialized
INFO - 2024-06-11 11:52:45 --> Router Class Initialized
INFO - 2024-06-11 11:52:45 --> Output Class Initialized
INFO - 2024-06-11 11:52:45 --> Security Class Initialized
DEBUG - 2024-06-11 11:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 11:52:45 --> Input Class Initialized
INFO - 2024-06-11 11:52:45 --> Language Class Initialized
INFO - 2024-06-11 11:52:45 --> Language Class Initialized
INFO - 2024-06-11 11:52:45 --> Config Class Initialized
INFO - 2024-06-11 11:52:45 --> Loader Class Initialized
INFO - 2024-06-11 11:52:45 --> Helper loaded: url_helper
INFO - 2024-06-11 11:52:45 --> Helper loaded: file_helper
INFO - 2024-06-11 11:52:45 --> Helper loaded: form_helper
INFO - 2024-06-11 11:52:45 --> Helper loaded: my_helper
INFO - 2024-06-11 11:52:46 --> Database Driver Class Initialized
INFO - 2024-06-11 11:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 11:52:46 --> Controller Class Initialized
DEBUG - 2024-06-11 11:52:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-06-11 11:52:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 11:52:46 --> Final output sent to browser
DEBUG - 2024-06-11 11:52:46 --> Total execution time: 0.4904
INFO - 2024-06-11 11:52:57 --> Config Class Initialized
INFO - 2024-06-11 11:52:57 --> Hooks Class Initialized
DEBUG - 2024-06-11 11:52:57 --> UTF-8 Support Enabled
INFO - 2024-06-11 11:52:57 --> Utf8 Class Initialized
INFO - 2024-06-11 11:52:57 --> URI Class Initialized
INFO - 2024-06-11 11:52:57 --> Router Class Initialized
INFO - 2024-06-11 11:52:58 --> Output Class Initialized
INFO - 2024-06-11 11:52:58 --> Security Class Initialized
DEBUG - 2024-06-11 11:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 11:52:58 --> Input Class Initialized
INFO - 2024-06-11 11:52:58 --> Language Class Initialized
INFO - 2024-06-11 11:52:58 --> Language Class Initialized
INFO - 2024-06-11 11:52:58 --> Config Class Initialized
INFO - 2024-06-11 11:52:58 --> Loader Class Initialized
INFO - 2024-06-11 11:52:58 --> Helper loaded: url_helper
INFO - 2024-06-11 11:52:59 --> Helper loaded: file_helper
INFO - 2024-06-11 11:52:59 --> Helper loaded: form_helper
INFO - 2024-06-11 11:52:59 --> Helper loaded: my_helper
INFO - 2024-06-11 11:52:59 --> Database Driver Class Initialized
INFO - 2024-06-11 11:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 11:52:59 --> Controller Class Initialized
DEBUG - 2024-06-11 11:52:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2024-06-11 11:52:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 11:52:59 --> Final output sent to browser
DEBUG - 2024-06-11 11:52:59 --> Total execution time: 2.5047
INFO - 2024-06-11 11:52:59 --> Config Class Initialized
INFO - 2024-06-11 11:52:59 --> Hooks Class Initialized
DEBUG - 2024-06-11 11:52:59 --> UTF-8 Support Enabled
INFO - 2024-06-11 11:52:59 --> Utf8 Class Initialized
INFO - 2024-06-11 11:52:59 --> URI Class Initialized
INFO - 2024-06-11 11:52:59 --> Router Class Initialized
INFO - 2024-06-11 11:52:59 --> Output Class Initialized
INFO - 2024-06-11 11:52:59 --> Security Class Initialized
DEBUG - 2024-06-11 11:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 11:52:59 --> Input Class Initialized
INFO - 2024-06-11 11:52:59 --> Language Class Initialized
ERROR - 2024-06-11 11:52:59 --> 404 Page Not Found: /index
INFO - 2024-06-11 11:53:00 --> Config Class Initialized
INFO - 2024-06-11 11:53:00 --> Hooks Class Initialized
DEBUG - 2024-06-11 11:53:00 --> UTF-8 Support Enabled
INFO - 2024-06-11 11:53:00 --> Utf8 Class Initialized
INFO - 2024-06-11 11:53:00 --> URI Class Initialized
INFO - 2024-06-11 11:53:00 --> Router Class Initialized
INFO - 2024-06-11 11:53:00 --> Output Class Initialized
INFO - 2024-06-11 11:53:00 --> Security Class Initialized
DEBUG - 2024-06-11 11:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 11:53:00 --> Input Class Initialized
INFO - 2024-06-11 11:53:00 --> Language Class Initialized
INFO - 2024-06-11 11:53:00 --> Language Class Initialized
INFO - 2024-06-11 11:53:00 --> Config Class Initialized
INFO - 2024-06-11 11:53:00 --> Loader Class Initialized
INFO - 2024-06-11 11:53:00 --> Helper loaded: url_helper
INFO - 2024-06-11 11:53:00 --> Helper loaded: file_helper
INFO - 2024-06-11 11:53:00 --> Helper loaded: form_helper
INFO - 2024-06-11 11:53:00 --> Helper loaded: my_helper
INFO - 2024-06-11 11:53:00 --> Database Driver Class Initialized
INFO - 2024-06-11 11:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 11:53:00 --> Controller Class Initialized
INFO - 2024-06-11 11:53:04 --> Config Class Initialized
INFO - 2024-06-11 11:53:04 --> Hooks Class Initialized
DEBUG - 2024-06-11 11:53:04 --> UTF-8 Support Enabled
INFO - 2024-06-11 11:53:04 --> Utf8 Class Initialized
INFO - 2024-06-11 11:53:04 --> URI Class Initialized
INFO - 2024-06-11 11:53:04 --> Router Class Initialized
INFO - 2024-06-11 11:53:04 --> Output Class Initialized
INFO - 2024-06-11 11:53:04 --> Security Class Initialized
DEBUG - 2024-06-11 11:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 11:53:04 --> Input Class Initialized
INFO - 2024-06-11 11:53:04 --> Language Class Initialized
INFO - 2024-06-11 11:53:04 --> Language Class Initialized
INFO - 2024-06-11 11:53:04 --> Config Class Initialized
INFO - 2024-06-11 11:53:04 --> Loader Class Initialized
INFO - 2024-06-11 11:53:04 --> Helper loaded: url_helper
INFO - 2024-06-11 11:53:04 --> Helper loaded: file_helper
INFO - 2024-06-11 11:53:04 --> Helper loaded: form_helper
INFO - 2024-06-11 11:53:04 --> Helper loaded: my_helper
INFO - 2024-06-11 11:53:04 --> Database Driver Class Initialized
INFO - 2024-06-11 11:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 11:53:04 --> Controller Class Initialized
INFO - 2024-06-11 11:53:10 --> Config Class Initialized
INFO - 2024-06-11 11:53:10 --> Hooks Class Initialized
DEBUG - 2024-06-11 11:53:10 --> UTF-8 Support Enabled
INFO - 2024-06-11 11:53:10 --> Utf8 Class Initialized
INFO - 2024-06-11 11:53:10 --> URI Class Initialized
INFO - 2024-06-11 11:53:10 --> Router Class Initialized
INFO - 2024-06-11 11:53:10 --> Output Class Initialized
INFO - 2024-06-11 11:53:10 --> Security Class Initialized
DEBUG - 2024-06-11 11:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 11:53:10 --> Input Class Initialized
INFO - 2024-06-11 11:53:10 --> Language Class Initialized
INFO - 2024-06-11 11:53:10 --> Language Class Initialized
INFO - 2024-06-11 11:53:10 --> Config Class Initialized
INFO - 2024-06-11 11:53:10 --> Loader Class Initialized
INFO - 2024-06-11 11:53:10 --> Helper loaded: url_helper
INFO - 2024-06-11 11:53:10 --> Helper loaded: file_helper
INFO - 2024-06-11 11:53:10 --> Helper loaded: form_helper
INFO - 2024-06-11 11:53:10 --> Helper loaded: my_helper
INFO - 2024-06-11 11:53:10 --> Database Driver Class Initialized
INFO - 2024-06-11 11:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 11:53:10 --> Controller Class Initialized
DEBUG - 2024-06-11 11:53:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-06-11 11:53:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 11:53:10 --> Final output sent to browser
DEBUG - 2024-06-11 11:53:10 --> Total execution time: 0.2054
INFO - 2024-06-11 11:53:10 --> Config Class Initialized
INFO - 2024-06-11 11:53:10 --> Hooks Class Initialized
DEBUG - 2024-06-11 11:53:10 --> UTF-8 Support Enabled
INFO - 2024-06-11 11:53:10 --> Utf8 Class Initialized
INFO - 2024-06-11 11:53:10 --> URI Class Initialized
INFO - 2024-06-11 11:53:10 --> Router Class Initialized
INFO - 2024-06-11 11:53:10 --> Output Class Initialized
INFO - 2024-06-11 11:53:10 --> Security Class Initialized
DEBUG - 2024-06-11 11:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 11:53:10 --> Input Class Initialized
INFO - 2024-06-11 11:53:10 --> Language Class Initialized
ERROR - 2024-06-11 11:53:10 --> 404 Page Not Found: /index
INFO - 2024-06-11 11:53:10 --> Config Class Initialized
INFO - 2024-06-11 11:53:10 --> Hooks Class Initialized
DEBUG - 2024-06-11 11:53:10 --> UTF-8 Support Enabled
INFO - 2024-06-11 11:53:10 --> Utf8 Class Initialized
INFO - 2024-06-11 11:53:10 --> URI Class Initialized
INFO - 2024-06-11 11:53:10 --> Router Class Initialized
INFO - 2024-06-11 11:53:10 --> Output Class Initialized
INFO - 2024-06-11 11:53:10 --> Security Class Initialized
DEBUG - 2024-06-11 11:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 11:53:10 --> Input Class Initialized
INFO - 2024-06-11 11:53:10 --> Language Class Initialized
INFO - 2024-06-11 11:53:10 --> Language Class Initialized
INFO - 2024-06-11 11:53:10 --> Config Class Initialized
INFO - 2024-06-11 11:53:10 --> Loader Class Initialized
INFO - 2024-06-11 11:53:10 --> Helper loaded: url_helper
INFO - 2024-06-11 11:53:10 --> Helper loaded: file_helper
INFO - 2024-06-11 11:53:10 --> Helper loaded: form_helper
INFO - 2024-06-11 11:53:10 --> Helper loaded: my_helper
INFO - 2024-06-11 11:53:10 --> Database Driver Class Initialized
INFO - 2024-06-11 11:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 11:53:10 --> Controller Class Initialized
INFO - 2024-06-11 11:53:16 --> Config Class Initialized
INFO - 2024-06-11 11:53:16 --> Hooks Class Initialized
DEBUG - 2024-06-11 11:53:16 --> UTF-8 Support Enabled
INFO - 2024-06-11 11:53:16 --> Utf8 Class Initialized
INFO - 2024-06-11 11:53:16 --> URI Class Initialized
INFO - 2024-06-11 11:53:16 --> Router Class Initialized
INFO - 2024-06-11 11:53:16 --> Output Class Initialized
INFO - 2024-06-11 11:53:16 --> Security Class Initialized
DEBUG - 2024-06-11 11:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 11:53:17 --> Input Class Initialized
INFO - 2024-06-11 11:53:17 --> Language Class Initialized
INFO - 2024-06-11 11:53:17 --> Language Class Initialized
INFO - 2024-06-11 11:53:17 --> Config Class Initialized
INFO - 2024-06-11 11:53:17 --> Loader Class Initialized
INFO - 2024-06-11 11:53:17 --> Helper loaded: url_helper
INFO - 2024-06-11 11:53:17 --> Helper loaded: file_helper
INFO - 2024-06-11 11:53:17 --> Helper loaded: form_helper
INFO - 2024-06-11 11:53:17 --> Helper loaded: my_helper
INFO - 2024-06-11 11:53:17 --> Database Driver Class Initialized
INFO - 2024-06-11 11:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 11:53:17 --> Controller Class Initialized
INFO - 2024-06-11 12:16:15 --> Config Class Initialized
INFO - 2024-06-11 12:16:15 --> Hooks Class Initialized
DEBUG - 2024-06-11 12:16:15 --> UTF-8 Support Enabled
INFO - 2024-06-11 12:16:15 --> Utf8 Class Initialized
INFO - 2024-06-11 12:16:15 --> URI Class Initialized
INFO - 2024-06-11 12:16:15 --> Router Class Initialized
INFO - 2024-06-11 12:16:15 --> Output Class Initialized
INFO - 2024-06-11 12:16:15 --> Security Class Initialized
DEBUG - 2024-06-11 12:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 12:16:15 --> Input Class Initialized
INFO - 2024-06-11 12:16:15 --> Language Class Initialized
INFO - 2024-06-11 12:16:15 --> Language Class Initialized
INFO - 2024-06-11 12:16:15 --> Config Class Initialized
INFO - 2024-06-11 12:16:15 --> Loader Class Initialized
INFO - 2024-06-11 12:16:15 --> Helper loaded: url_helper
INFO - 2024-06-11 12:16:15 --> Helper loaded: file_helper
INFO - 2024-06-11 12:16:15 --> Helper loaded: form_helper
INFO - 2024-06-11 12:16:15 --> Helper loaded: my_helper
INFO - 2024-06-11 12:16:15 --> Database Driver Class Initialized
INFO - 2024-06-11 12:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 12:16:15 --> Controller Class Initialized
DEBUG - 2024-06-11 12:16:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-06-11 12:16:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 12:16:15 --> Final output sent to browser
DEBUG - 2024-06-11 12:16:15 --> Total execution time: 0.1416
INFO - 2024-06-11 12:16:15 --> Config Class Initialized
INFO - 2024-06-11 12:16:15 --> Hooks Class Initialized
DEBUG - 2024-06-11 12:16:15 --> UTF-8 Support Enabled
INFO - 2024-06-11 12:16:15 --> Utf8 Class Initialized
INFO - 2024-06-11 12:16:15 --> URI Class Initialized
INFO - 2024-06-11 12:16:15 --> Router Class Initialized
INFO - 2024-06-11 12:16:15 --> Output Class Initialized
INFO - 2024-06-11 12:16:15 --> Security Class Initialized
DEBUG - 2024-06-11 12:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 12:16:15 --> Input Class Initialized
INFO - 2024-06-11 12:16:15 --> Language Class Initialized
ERROR - 2024-06-11 12:16:15 --> 404 Page Not Found: /index
INFO - 2024-06-11 12:16:15 --> Config Class Initialized
INFO - 2024-06-11 12:16:15 --> Hooks Class Initialized
DEBUG - 2024-06-11 12:16:15 --> UTF-8 Support Enabled
INFO - 2024-06-11 12:16:15 --> Utf8 Class Initialized
INFO - 2024-06-11 12:16:15 --> URI Class Initialized
INFO - 2024-06-11 12:16:15 --> Router Class Initialized
INFO - 2024-06-11 12:16:15 --> Output Class Initialized
INFO - 2024-06-11 12:16:15 --> Security Class Initialized
DEBUG - 2024-06-11 12:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 12:16:15 --> Input Class Initialized
INFO - 2024-06-11 12:16:15 --> Language Class Initialized
INFO - 2024-06-11 12:16:15 --> Language Class Initialized
INFO - 2024-06-11 12:16:15 --> Config Class Initialized
INFO - 2024-06-11 12:16:15 --> Loader Class Initialized
INFO - 2024-06-11 12:16:15 --> Helper loaded: url_helper
INFO - 2024-06-11 12:16:15 --> Helper loaded: file_helper
INFO - 2024-06-11 12:16:15 --> Helper loaded: form_helper
INFO - 2024-06-11 12:16:15 --> Helper loaded: my_helper
INFO - 2024-06-11 12:16:15 --> Database Driver Class Initialized
INFO - 2024-06-11 12:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 12:16:15 --> Controller Class Initialized
INFO - 2024-06-11 12:16:24 --> Config Class Initialized
INFO - 2024-06-11 12:16:24 --> Hooks Class Initialized
DEBUG - 2024-06-11 12:16:24 --> UTF-8 Support Enabled
INFO - 2024-06-11 12:16:24 --> Utf8 Class Initialized
INFO - 2024-06-11 12:16:24 --> URI Class Initialized
INFO - 2024-06-11 12:16:24 --> Router Class Initialized
INFO - 2024-06-11 12:16:24 --> Output Class Initialized
INFO - 2024-06-11 12:16:24 --> Security Class Initialized
DEBUG - 2024-06-11 12:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 12:16:24 --> Input Class Initialized
INFO - 2024-06-11 12:16:24 --> Language Class Initialized
INFO - 2024-06-11 12:16:24 --> Language Class Initialized
INFO - 2024-06-11 12:16:24 --> Config Class Initialized
INFO - 2024-06-11 12:16:24 --> Loader Class Initialized
INFO - 2024-06-11 12:16:24 --> Helper loaded: url_helper
INFO - 2024-06-11 12:16:24 --> Helper loaded: file_helper
INFO - 2024-06-11 12:16:24 --> Helper loaded: form_helper
INFO - 2024-06-11 12:16:24 --> Helper loaded: my_helper
INFO - 2024-06-11 12:16:24 --> Database Driver Class Initialized
INFO - 2024-06-11 12:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 12:16:24 --> Controller Class Initialized
DEBUG - 2024-06-11 12:16:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_ekstra/views/list.php
DEBUG - 2024-06-11 12:16:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 12:16:24 --> Final output sent to browser
DEBUG - 2024-06-11 12:16:24 --> Total execution time: 0.1989
INFO - 2024-06-11 12:16:24 --> Config Class Initialized
INFO - 2024-06-11 12:16:24 --> Hooks Class Initialized
DEBUG - 2024-06-11 12:16:24 --> UTF-8 Support Enabled
INFO - 2024-06-11 12:16:24 --> Utf8 Class Initialized
INFO - 2024-06-11 12:16:24 --> URI Class Initialized
INFO - 2024-06-11 12:16:24 --> Router Class Initialized
INFO - 2024-06-11 12:16:24 --> Output Class Initialized
INFO - 2024-06-11 12:16:24 --> Security Class Initialized
DEBUG - 2024-06-11 12:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 12:16:24 --> Input Class Initialized
INFO - 2024-06-11 12:16:24 --> Language Class Initialized
ERROR - 2024-06-11 12:16:24 --> 404 Page Not Found: /index
INFO - 2024-06-11 12:16:24 --> Config Class Initialized
INFO - 2024-06-11 12:16:24 --> Hooks Class Initialized
DEBUG - 2024-06-11 12:16:24 --> UTF-8 Support Enabled
INFO - 2024-06-11 12:16:24 --> Utf8 Class Initialized
INFO - 2024-06-11 12:16:24 --> URI Class Initialized
INFO - 2024-06-11 12:16:24 --> Router Class Initialized
INFO - 2024-06-11 12:16:24 --> Output Class Initialized
INFO - 2024-06-11 12:16:24 --> Security Class Initialized
DEBUG - 2024-06-11 12:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 12:16:24 --> Input Class Initialized
INFO - 2024-06-11 12:16:24 --> Language Class Initialized
INFO - 2024-06-11 12:16:24 --> Language Class Initialized
INFO - 2024-06-11 12:16:24 --> Config Class Initialized
INFO - 2024-06-11 12:16:24 --> Loader Class Initialized
INFO - 2024-06-11 12:16:24 --> Helper loaded: url_helper
INFO - 2024-06-11 12:16:24 --> Helper loaded: file_helper
INFO - 2024-06-11 12:16:24 --> Helper loaded: form_helper
INFO - 2024-06-11 12:16:24 --> Helper loaded: my_helper
INFO - 2024-06-11 12:16:24 --> Database Driver Class Initialized
INFO - 2024-06-11 12:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 12:16:25 --> Controller Class Initialized
INFO - 2024-06-11 12:30:23 --> Config Class Initialized
INFO - 2024-06-11 12:30:23 --> Hooks Class Initialized
DEBUG - 2024-06-11 12:30:23 --> UTF-8 Support Enabled
INFO - 2024-06-11 12:30:23 --> Utf8 Class Initialized
INFO - 2024-06-11 12:30:23 --> URI Class Initialized
INFO - 2024-06-11 12:30:23 --> Router Class Initialized
INFO - 2024-06-11 12:30:23 --> Output Class Initialized
INFO - 2024-06-11 12:30:23 --> Security Class Initialized
DEBUG - 2024-06-11 12:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 12:30:24 --> Input Class Initialized
INFO - 2024-06-11 12:30:24 --> Language Class Initialized
INFO - 2024-06-11 12:30:24 --> Language Class Initialized
INFO - 2024-06-11 12:30:24 --> Config Class Initialized
INFO - 2024-06-11 12:30:24 --> Loader Class Initialized
INFO - 2024-06-11 12:30:24 --> Helper loaded: url_helper
INFO - 2024-06-11 12:30:24 --> Helper loaded: file_helper
INFO - 2024-06-11 12:30:24 --> Helper loaded: form_helper
INFO - 2024-06-11 12:30:24 --> Helper loaded: my_helper
INFO - 2024-06-11 12:30:24 --> Database Driver Class Initialized
INFO - 2024-06-11 12:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 12:30:24 --> Controller Class Initialized
DEBUG - 2024-06-11 12:30:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-11 12:30:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 12:30:24 --> Final output sent to browser
DEBUG - 2024-06-11 12:30:24 --> Total execution time: 1.1487
INFO - 2024-06-11 12:30:25 --> Config Class Initialized
INFO - 2024-06-11 12:30:25 --> Hooks Class Initialized
DEBUG - 2024-06-11 12:30:25 --> UTF-8 Support Enabled
INFO - 2024-06-11 12:30:25 --> Utf8 Class Initialized
INFO - 2024-06-11 12:30:25 --> URI Class Initialized
INFO - 2024-06-11 12:30:25 --> Router Class Initialized
INFO - 2024-06-11 12:30:25 --> Output Class Initialized
INFO - 2024-06-11 12:30:25 --> Security Class Initialized
DEBUG - 2024-06-11 12:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 12:30:25 --> Input Class Initialized
INFO - 2024-06-11 12:30:25 --> Language Class Initialized
INFO - 2024-06-11 12:30:25 --> Language Class Initialized
INFO - 2024-06-11 12:30:25 --> Config Class Initialized
INFO - 2024-06-11 12:30:25 --> Loader Class Initialized
INFO - 2024-06-11 12:30:25 --> Helper loaded: url_helper
INFO - 2024-06-11 12:30:25 --> Helper loaded: file_helper
INFO - 2024-06-11 12:30:25 --> Helper loaded: form_helper
INFO - 2024-06-11 12:30:25 --> Helper loaded: my_helper
INFO - 2024-06-11 12:30:25 --> Database Driver Class Initialized
INFO - 2024-06-11 12:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 12:30:25 --> Controller Class Initialized
INFO - 2024-06-11 13:27:38 --> Config Class Initialized
INFO - 2024-06-11 13:27:38 --> Hooks Class Initialized
DEBUG - 2024-06-11 13:27:38 --> UTF-8 Support Enabled
INFO - 2024-06-11 13:27:38 --> Utf8 Class Initialized
INFO - 2024-06-11 13:27:38 --> URI Class Initialized
INFO - 2024-06-11 13:27:38 --> Router Class Initialized
INFO - 2024-06-11 13:27:38 --> Output Class Initialized
INFO - 2024-06-11 13:27:38 --> Security Class Initialized
DEBUG - 2024-06-11 13:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 13:27:38 --> Input Class Initialized
INFO - 2024-06-11 13:27:38 --> Language Class Initialized
INFO - 2024-06-11 13:27:38 --> Language Class Initialized
INFO - 2024-06-11 13:27:38 --> Config Class Initialized
INFO - 2024-06-11 13:27:38 --> Loader Class Initialized
INFO - 2024-06-11 13:27:38 --> Helper loaded: url_helper
INFO - 2024-06-11 13:27:38 --> Helper loaded: file_helper
INFO - 2024-06-11 13:27:38 --> Helper loaded: form_helper
INFO - 2024-06-11 13:27:38 --> Helper loaded: my_helper
INFO - 2024-06-11 13:27:38 --> Database Driver Class Initialized
INFO - 2024-06-11 13:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 13:27:38 --> Controller Class Initialized
DEBUG - 2024-06-11 13:27:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_ekstra/views/list.php
DEBUG - 2024-06-11 13:27:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 13:27:38 --> Final output sent to browser
DEBUG - 2024-06-11 13:27:38 --> Total execution time: 0.3484
INFO - 2024-06-11 13:27:39 --> Config Class Initialized
INFO - 2024-06-11 13:27:39 --> Hooks Class Initialized
DEBUG - 2024-06-11 13:27:39 --> UTF-8 Support Enabled
INFO - 2024-06-11 13:27:39 --> Utf8 Class Initialized
INFO - 2024-06-11 13:27:39 --> URI Class Initialized
INFO - 2024-06-11 13:27:39 --> Router Class Initialized
INFO - 2024-06-11 13:27:39 --> Output Class Initialized
INFO - 2024-06-11 13:27:39 --> Security Class Initialized
DEBUG - 2024-06-11 13:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 13:27:39 --> Input Class Initialized
INFO - 2024-06-11 13:27:39 --> Language Class Initialized
ERROR - 2024-06-11 13:27:39 --> 404 Page Not Found: /index
INFO - 2024-06-11 13:27:39 --> Config Class Initialized
INFO - 2024-06-11 13:27:39 --> Hooks Class Initialized
DEBUG - 2024-06-11 13:27:39 --> UTF-8 Support Enabled
INFO - 2024-06-11 13:27:39 --> Utf8 Class Initialized
INFO - 2024-06-11 13:27:39 --> URI Class Initialized
INFO - 2024-06-11 13:27:39 --> Router Class Initialized
INFO - 2024-06-11 13:27:39 --> Output Class Initialized
INFO - 2024-06-11 13:27:39 --> Security Class Initialized
DEBUG - 2024-06-11 13:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 13:27:39 --> Input Class Initialized
INFO - 2024-06-11 13:27:39 --> Language Class Initialized
INFO - 2024-06-11 13:27:39 --> Language Class Initialized
INFO - 2024-06-11 13:27:39 --> Config Class Initialized
INFO - 2024-06-11 13:27:39 --> Loader Class Initialized
INFO - 2024-06-11 13:27:39 --> Helper loaded: url_helper
INFO - 2024-06-11 13:27:39 --> Helper loaded: file_helper
INFO - 2024-06-11 13:27:39 --> Helper loaded: form_helper
INFO - 2024-06-11 13:27:39 --> Helper loaded: my_helper
INFO - 2024-06-11 13:27:39 --> Database Driver Class Initialized
INFO - 2024-06-11 13:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 13:27:39 --> Controller Class Initialized
INFO - 2024-06-11 14:04:06 --> Config Class Initialized
INFO - 2024-06-11 14:04:06 --> Hooks Class Initialized
DEBUG - 2024-06-11 14:04:06 --> UTF-8 Support Enabled
INFO - 2024-06-11 14:04:06 --> Utf8 Class Initialized
INFO - 2024-06-11 14:04:06 --> URI Class Initialized
INFO - 2024-06-11 14:04:06 --> Router Class Initialized
INFO - 2024-06-11 14:04:06 --> Output Class Initialized
INFO - 2024-06-11 14:04:06 --> Security Class Initialized
DEBUG - 2024-06-11 14:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 14:04:06 --> Input Class Initialized
INFO - 2024-06-11 14:04:06 --> Language Class Initialized
INFO - 2024-06-11 14:04:06 --> Language Class Initialized
INFO - 2024-06-11 14:04:06 --> Config Class Initialized
INFO - 2024-06-11 14:04:06 --> Loader Class Initialized
INFO - 2024-06-11 14:04:06 --> Helper loaded: url_helper
INFO - 2024-06-11 14:04:06 --> Helper loaded: file_helper
INFO - 2024-06-11 14:04:06 --> Helper loaded: form_helper
INFO - 2024-06-11 14:04:06 --> Helper loaded: my_helper
INFO - 2024-06-11 14:04:06 --> Database Driver Class Initialized
INFO - 2024-06-11 14:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 14:04:06 --> Controller Class Initialized
DEBUG - 2024-06-11 14:04:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-11 14:04:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 14:04:06 --> Final output sent to browser
DEBUG - 2024-06-11 14:04:06 --> Total execution time: 0.1969
INFO - 2024-06-11 14:04:09 --> Config Class Initialized
INFO - 2024-06-11 14:04:09 --> Hooks Class Initialized
DEBUG - 2024-06-11 14:04:09 --> UTF-8 Support Enabled
INFO - 2024-06-11 14:04:09 --> Utf8 Class Initialized
INFO - 2024-06-11 14:04:09 --> URI Class Initialized
INFO - 2024-06-11 14:04:09 --> Router Class Initialized
INFO - 2024-06-11 14:04:09 --> Output Class Initialized
INFO - 2024-06-11 14:04:09 --> Security Class Initialized
DEBUG - 2024-06-11 14:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 14:04:09 --> Input Class Initialized
INFO - 2024-06-11 14:04:09 --> Language Class Initialized
INFO - 2024-06-11 14:04:09 --> Language Class Initialized
INFO - 2024-06-11 14:04:09 --> Config Class Initialized
INFO - 2024-06-11 14:04:09 --> Loader Class Initialized
INFO - 2024-06-11 14:04:09 --> Helper loaded: url_helper
INFO - 2024-06-11 14:04:09 --> Helper loaded: file_helper
INFO - 2024-06-11 14:04:09 --> Helper loaded: form_helper
INFO - 2024-06-11 14:04:09 --> Helper loaded: my_helper
INFO - 2024-06-11 14:04:09 --> Database Driver Class Initialized
INFO - 2024-06-11 14:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 14:04:09 --> Controller Class Initialized
INFO - 2024-06-11 14:04:09 --> Helper loaded: cookie_helper
INFO - 2024-06-11 14:04:09 --> Final output sent to browser
DEBUG - 2024-06-11 14:04:09 --> Total execution time: 0.8433
INFO - 2024-06-11 14:04:10 --> Config Class Initialized
INFO - 2024-06-11 14:04:10 --> Hooks Class Initialized
DEBUG - 2024-06-11 14:04:10 --> UTF-8 Support Enabled
INFO - 2024-06-11 14:04:10 --> Utf8 Class Initialized
INFO - 2024-06-11 14:04:10 --> URI Class Initialized
INFO - 2024-06-11 14:04:10 --> Router Class Initialized
INFO - 2024-06-11 14:04:10 --> Output Class Initialized
INFO - 2024-06-11 14:04:10 --> Security Class Initialized
DEBUG - 2024-06-11 14:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 14:04:10 --> Input Class Initialized
INFO - 2024-06-11 14:04:10 --> Language Class Initialized
INFO - 2024-06-11 14:04:10 --> Language Class Initialized
INFO - 2024-06-11 14:04:10 --> Config Class Initialized
INFO - 2024-06-11 14:04:10 --> Loader Class Initialized
INFO - 2024-06-11 14:04:10 --> Helper loaded: url_helper
INFO - 2024-06-11 14:04:10 --> Helper loaded: file_helper
INFO - 2024-06-11 14:04:10 --> Helper loaded: form_helper
INFO - 2024-06-11 14:04:10 --> Helper loaded: my_helper
INFO - 2024-06-11 14:04:10 --> Database Driver Class Initialized
INFO - 2024-06-11 14:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 14:04:10 --> Controller Class Initialized
DEBUG - 2024-06-11 14:04:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-11 14:04:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 14:04:10 --> Final output sent to browser
DEBUG - 2024-06-11 14:04:10 --> Total execution time: 0.5227
INFO - 2024-06-11 14:04:12 --> Config Class Initialized
INFO - 2024-06-11 14:04:12 --> Hooks Class Initialized
DEBUG - 2024-06-11 14:04:12 --> UTF-8 Support Enabled
INFO - 2024-06-11 14:04:12 --> Utf8 Class Initialized
INFO - 2024-06-11 14:04:12 --> URI Class Initialized
INFO - 2024-06-11 14:04:12 --> Router Class Initialized
INFO - 2024-06-11 14:04:12 --> Output Class Initialized
INFO - 2024-06-11 14:04:12 --> Security Class Initialized
DEBUG - 2024-06-11 14:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 14:04:12 --> Input Class Initialized
INFO - 2024-06-11 14:04:12 --> Language Class Initialized
INFO - 2024-06-11 14:04:12 --> Language Class Initialized
INFO - 2024-06-11 14:04:12 --> Config Class Initialized
INFO - 2024-06-11 14:04:12 --> Loader Class Initialized
INFO - 2024-06-11 14:04:12 --> Helper loaded: url_helper
INFO - 2024-06-11 14:04:12 --> Helper loaded: file_helper
INFO - 2024-06-11 14:04:12 --> Helper loaded: form_helper
INFO - 2024-06-11 14:04:12 --> Helper loaded: my_helper
INFO - 2024-06-11 14:04:12 --> Database Driver Class Initialized
INFO - 2024-06-11 14:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 14:04:12 --> Controller Class Initialized
DEBUG - 2024-06-11 14:04:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-11 14:04:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 14:04:12 --> Final output sent to browser
DEBUG - 2024-06-11 14:04:12 --> Total execution time: 0.4553
INFO - 2024-06-11 14:04:16 --> Config Class Initialized
INFO - 2024-06-11 14:04:16 --> Hooks Class Initialized
DEBUG - 2024-06-11 14:04:16 --> UTF-8 Support Enabled
INFO - 2024-06-11 14:04:16 --> Utf8 Class Initialized
INFO - 2024-06-11 14:04:16 --> URI Class Initialized
INFO - 2024-06-11 14:04:16 --> Router Class Initialized
INFO - 2024-06-11 14:04:16 --> Output Class Initialized
INFO - 2024-06-11 14:04:16 --> Security Class Initialized
DEBUG - 2024-06-11 14:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 14:04:16 --> Input Class Initialized
INFO - 2024-06-11 14:04:16 --> Language Class Initialized
INFO - 2024-06-11 14:04:16 --> Language Class Initialized
INFO - 2024-06-11 14:04:16 --> Config Class Initialized
INFO - 2024-06-11 14:04:16 --> Loader Class Initialized
INFO - 2024-06-11 14:04:16 --> Helper loaded: url_helper
INFO - 2024-06-11 14:04:16 --> Helper loaded: file_helper
INFO - 2024-06-11 14:04:16 --> Helper loaded: form_helper
INFO - 2024-06-11 14:04:16 --> Helper loaded: my_helper
INFO - 2024-06-11 14:04:16 --> Database Driver Class Initialized
INFO - 2024-06-11 14:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 14:04:16 --> Controller Class Initialized
DEBUG - 2024-06-11 14:04:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-11 14:04:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 14:04:16 --> Final output sent to browser
DEBUG - 2024-06-11 14:04:16 --> Total execution time: 0.4981
INFO - 2024-06-11 14:04:16 --> Config Class Initialized
INFO - 2024-06-11 14:04:16 --> Hooks Class Initialized
DEBUG - 2024-06-11 14:04:16 --> UTF-8 Support Enabled
INFO - 2024-06-11 14:04:16 --> Utf8 Class Initialized
INFO - 2024-06-11 14:04:16 --> URI Class Initialized
INFO - 2024-06-11 14:04:16 --> Router Class Initialized
INFO - 2024-06-11 14:04:16 --> Output Class Initialized
INFO - 2024-06-11 14:04:16 --> Security Class Initialized
DEBUG - 2024-06-11 14:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 14:04:16 --> Input Class Initialized
INFO - 2024-06-11 14:04:16 --> Language Class Initialized
INFO - 2024-06-11 14:04:16 --> Language Class Initialized
INFO - 2024-06-11 14:04:16 --> Config Class Initialized
INFO - 2024-06-11 14:04:16 --> Loader Class Initialized
INFO - 2024-06-11 14:04:16 --> Helper loaded: url_helper
INFO - 2024-06-11 14:04:16 --> Helper loaded: file_helper
INFO - 2024-06-11 14:04:16 --> Helper loaded: form_helper
INFO - 2024-06-11 14:04:16 --> Helper loaded: my_helper
INFO - 2024-06-11 14:04:16 --> Database Driver Class Initialized
INFO - 2024-06-11 14:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 14:04:17 --> Controller Class Initialized
INFO - 2024-06-11 14:14:10 --> Config Class Initialized
INFO - 2024-06-11 14:14:10 --> Hooks Class Initialized
DEBUG - 2024-06-11 14:14:10 --> UTF-8 Support Enabled
INFO - 2024-06-11 14:14:10 --> Utf8 Class Initialized
INFO - 2024-06-11 14:14:10 --> URI Class Initialized
INFO - 2024-06-11 14:14:10 --> Router Class Initialized
INFO - 2024-06-11 14:14:10 --> Output Class Initialized
INFO - 2024-06-11 14:14:10 --> Security Class Initialized
DEBUG - 2024-06-11 14:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 14:14:10 --> Input Class Initialized
INFO - 2024-06-11 14:14:10 --> Language Class Initialized
INFO - 2024-06-11 14:14:10 --> Language Class Initialized
INFO - 2024-06-11 14:14:10 --> Config Class Initialized
INFO - 2024-06-11 14:14:10 --> Loader Class Initialized
INFO - 2024-06-11 14:14:10 --> Helper loaded: url_helper
INFO - 2024-06-11 14:14:10 --> Helper loaded: file_helper
INFO - 2024-06-11 14:14:10 --> Helper loaded: form_helper
INFO - 2024-06-11 14:14:10 --> Helper loaded: my_helper
INFO - 2024-06-11 14:14:10 --> Database Driver Class Initialized
INFO - 2024-06-11 14:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 14:14:10 --> Controller Class Initialized
DEBUG - 2024-06-11 14:14:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_ekstra/views/list.php
DEBUG - 2024-06-11 14:14:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 14:14:10 --> Final output sent to browser
DEBUG - 2024-06-11 14:14:10 --> Total execution time: 0.4303
INFO - 2024-06-11 14:14:11 --> Config Class Initialized
INFO - 2024-06-11 14:14:11 --> Hooks Class Initialized
DEBUG - 2024-06-11 14:14:11 --> UTF-8 Support Enabled
INFO - 2024-06-11 14:14:11 --> Utf8 Class Initialized
INFO - 2024-06-11 14:14:11 --> URI Class Initialized
INFO - 2024-06-11 14:14:11 --> Router Class Initialized
INFO - 2024-06-11 14:14:11 --> Output Class Initialized
INFO - 2024-06-11 14:14:11 --> Security Class Initialized
DEBUG - 2024-06-11 14:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 14:14:11 --> Input Class Initialized
INFO - 2024-06-11 14:14:11 --> Language Class Initialized
ERROR - 2024-06-11 14:14:11 --> 404 Page Not Found: /index
INFO - 2024-06-11 14:14:11 --> Config Class Initialized
INFO - 2024-06-11 14:14:11 --> Hooks Class Initialized
DEBUG - 2024-06-11 14:14:11 --> UTF-8 Support Enabled
INFO - 2024-06-11 14:14:11 --> Utf8 Class Initialized
INFO - 2024-06-11 14:14:11 --> URI Class Initialized
INFO - 2024-06-11 14:14:11 --> Router Class Initialized
INFO - 2024-06-11 14:14:11 --> Output Class Initialized
INFO - 2024-06-11 14:14:11 --> Security Class Initialized
DEBUG - 2024-06-11 14:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 14:14:11 --> Input Class Initialized
INFO - 2024-06-11 14:14:11 --> Language Class Initialized
INFO - 2024-06-11 14:14:11 --> Language Class Initialized
INFO - 2024-06-11 14:14:11 --> Config Class Initialized
INFO - 2024-06-11 14:14:11 --> Loader Class Initialized
INFO - 2024-06-11 14:14:11 --> Helper loaded: url_helper
INFO - 2024-06-11 14:14:11 --> Helper loaded: file_helper
INFO - 2024-06-11 14:14:11 --> Helper loaded: form_helper
INFO - 2024-06-11 14:14:11 --> Helper loaded: my_helper
INFO - 2024-06-11 14:14:11 --> Database Driver Class Initialized
INFO - 2024-06-11 14:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 14:14:11 --> Controller Class Initialized
INFO - 2024-06-11 15:34:08 --> Config Class Initialized
INFO - 2024-06-11 15:34:08 --> Hooks Class Initialized
DEBUG - 2024-06-11 15:34:08 --> UTF-8 Support Enabled
INFO - 2024-06-11 15:34:08 --> Utf8 Class Initialized
INFO - 2024-06-11 15:34:08 --> URI Class Initialized
DEBUG - 2024-06-11 15:34:08 --> No URI present. Default controller set.
INFO - 2024-06-11 15:34:08 --> Router Class Initialized
INFO - 2024-06-11 15:34:08 --> Output Class Initialized
INFO - 2024-06-11 15:34:08 --> Security Class Initialized
DEBUG - 2024-06-11 15:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 15:34:08 --> Input Class Initialized
INFO - 2024-06-11 15:34:08 --> Language Class Initialized
INFO - 2024-06-11 15:34:08 --> Language Class Initialized
INFO - 2024-06-11 15:34:08 --> Config Class Initialized
INFO - 2024-06-11 15:34:08 --> Loader Class Initialized
INFO - 2024-06-11 15:34:08 --> Helper loaded: url_helper
INFO - 2024-06-11 15:34:08 --> Helper loaded: file_helper
INFO - 2024-06-11 15:34:08 --> Helper loaded: form_helper
INFO - 2024-06-11 15:34:08 --> Helper loaded: my_helper
INFO - 2024-06-11 15:34:08 --> Database Driver Class Initialized
INFO - 2024-06-11 15:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 15:34:08 --> Controller Class Initialized
INFO - 2024-06-11 15:34:09 --> Config Class Initialized
INFO - 2024-06-11 15:34:09 --> Hooks Class Initialized
DEBUG - 2024-06-11 15:34:09 --> UTF-8 Support Enabled
INFO - 2024-06-11 15:34:09 --> Utf8 Class Initialized
INFO - 2024-06-11 15:34:09 --> URI Class Initialized
INFO - 2024-06-11 15:34:09 --> Router Class Initialized
INFO - 2024-06-11 15:34:09 --> Output Class Initialized
INFO - 2024-06-11 15:34:09 --> Security Class Initialized
DEBUG - 2024-06-11 15:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 15:34:09 --> Input Class Initialized
INFO - 2024-06-11 15:34:09 --> Language Class Initialized
INFO - 2024-06-11 15:34:09 --> Language Class Initialized
INFO - 2024-06-11 15:34:09 --> Config Class Initialized
INFO - 2024-06-11 15:34:09 --> Loader Class Initialized
INFO - 2024-06-11 15:34:09 --> Helper loaded: url_helper
INFO - 2024-06-11 15:34:09 --> Helper loaded: file_helper
INFO - 2024-06-11 15:34:09 --> Helper loaded: form_helper
INFO - 2024-06-11 15:34:09 --> Helper loaded: my_helper
INFO - 2024-06-11 15:34:09 --> Database Driver Class Initialized
INFO - 2024-06-11 15:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 15:34:09 --> Controller Class Initialized
DEBUG - 2024-06-11 15:34:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-11 15:34:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 15:34:09 --> Final output sent to browser
DEBUG - 2024-06-11 15:34:09 --> Total execution time: 0.2931
INFO - 2024-06-11 15:34:10 --> Config Class Initialized
INFO - 2024-06-11 15:34:10 --> Hooks Class Initialized
DEBUG - 2024-06-11 15:34:10 --> UTF-8 Support Enabled
INFO - 2024-06-11 15:34:10 --> Utf8 Class Initialized
INFO - 2024-06-11 15:34:10 --> URI Class Initialized
DEBUG - 2024-06-11 15:34:10 --> No URI present. Default controller set.
INFO - 2024-06-11 15:34:10 --> Router Class Initialized
INFO - 2024-06-11 15:34:10 --> Output Class Initialized
INFO - 2024-06-11 15:34:10 --> Security Class Initialized
DEBUG - 2024-06-11 15:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 15:34:10 --> Input Class Initialized
INFO - 2024-06-11 15:34:10 --> Language Class Initialized
INFO - 2024-06-11 15:34:10 --> Language Class Initialized
INFO - 2024-06-11 15:34:10 --> Config Class Initialized
INFO - 2024-06-11 15:34:10 --> Loader Class Initialized
INFO - 2024-06-11 15:34:10 --> Helper loaded: url_helper
INFO - 2024-06-11 15:34:10 --> Helper loaded: file_helper
INFO - 2024-06-11 15:34:10 --> Helper loaded: form_helper
INFO - 2024-06-11 15:34:10 --> Helper loaded: my_helper
INFO - 2024-06-11 15:34:10 --> Database Driver Class Initialized
INFO - 2024-06-11 15:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 15:34:10 --> Controller Class Initialized
INFO - 2024-06-11 15:34:11 --> Config Class Initialized
INFO - 2024-06-11 15:34:11 --> Hooks Class Initialized
DEBUG - 2024-06-11 15:34:11 --> UTF-8 Support Enabled
INFO - 2024-06-11 15:34:11 --> Utf8 Class Initialized
INFO - 2024-06-11 15:34:11 --> URI Class Initialized
INFO - 2024-06-11 15:34:11 --> Router Class Initialized
INFO - 2024-06-11 15:34:11 --> Output Class Initialized
INFO - 2024-06-11 15:34:11 --> Security Class Initialized
DEBUG - 2024-06-11 15:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 15:34:11 --> Input Class Initialized
INFO - 2024-06-11 15:34:11 --> Language Class Initialized
INFO - 2024-06-11 15:34:11 --> Language Class Initialized
INFO - 2024-06-11 15:34:11 --> Config Class Initialized
INFO - 2024-06-11 15:34:11 --> Loader Class Initialized
INFO - 2024-06-11 15:34:11 --> Helper loaded: url_helper
INFO - 2024-06-11 15:34:11 --> Helper loaded: file_helper
INFO - 2024-06-11 15:34:11 --> Helper loaded: form_helper
INFO - 2024-06-11 15:34:11 --> Helper loaded: my_helper
INFO - 2024-06-11 15:34:11 --> Database Driver Class Initialized
INFO - 2024-06-11 15:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 15:34:11 --> Controller Class Initialized
DEBUG - 2024-06-11 15:34:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-11 15:34:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 15:34:11 --> Final output sent to browser
DEBUG - 2024-06-11 15:34:11 --> Total execution time: 0.1603
INFO - 2024-06-11 15:34:11 --> Config Class Initialized
INFO - 2024-06-11 15:34:11 --> Hooks Class Initialized
DEBUG - 2024-06-11 15:34:11 --> UTF-8 Support Enabled
INFO - 2024-06-11 15:34:11 --> Utf8 Class Initialized
INFO - 2024-06-11 15:34:11 --> URI Class Initialized
INFO - 2024-06-11 15:34:11 --> Router Class Initialized
INFO - 2024-06-11 15:34:11 --> Output Class Initialized
INFO - 2024-06-11 15:34:11 --> Security Class Initialized
DEBUG - 2024-06-11 15:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 15:34:11 --> Input Class Initialized
INFO - 2024-06-11 15:34:11 --> Language Class Initialized
INFO - 2024-06-11 15:34:11 --> Language Class Initialized
INFO - 2024-06-11 15:34:11 --> Config Class Initialized
INFO - 2024-06-11 15:34:11 --> Loader Class Initialized
INFO - 2024-06-11 15:34:11 --> Helper loaded: url_helper
INFO - 2024-06-11 15:34:11 --> Helper loaded: file_helper
INFO - 2024-06-11 15:34:11 --> Helper loaded: form_helper
INFO - 2024-06-11 15:34:11 --> Helper loaded: my_helper
INFO - 2024-06-11 15:34:11 --> Database Driver Class Initialized
INFO - 2024-06-11 15:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 15:34:11 --> Controller Class Initialized
DEBUG - 2024-06-11 15:34:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-11 15:34:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 15:34:11 --> Final output sent to browser
DEBUG - 2024-06-11 15:34:11 --> Total execution time: 0.1741
INFO - 2024-06-11 15:34:13 --> Config Class Initialized
INFO - 2024-06-11 15:34:13 --> Hooks Class Initialized
DEBUG - 2024-06-11 15:34:13 --> UTF-8 Support Enabled
INFO - 2024-06-11 15:34:13 --> Utf8 Class Initialized
INFO - 2024-06-11 15:34:13 --> URI Class Initialized
INFO - 2024-06-11 15:34:13 --> Router Class Initialized
INFO - 2024-06-11 15:34:13 --> Output Class Initialized
INFO - 2024-06-11 15:34:13 --> Security Class Initialized
DEBUG - 2024-06-11 15:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 15:34:13 --> Input Class Initialized
INFO - 2024-06-11 15:34:13 --> Language Class Initialized
INFO - 2024-06-11 15:34:13 --> Language Class Initialized
INFO - 2024-06-11 15:34:13 --> Config Class Initialized
INFO - 2024-06-11 15:34:13 --> Loader Class Initialized
INFO - 2024-06-11 15:34:13 --> Helper loaded: url_helper
INFO - 2024-06-11 15:34:13 --> Helper loaded: file_helper
INFO - 2024-06-11 15:34:13 --> Helper loaded: form_helper
INFO - 2024-06-11 15:34:13 --> Helper loaded: my_helper
INFO - 2024-06-11 15:34:13 --> Database Driver Class Initialized
INFO - 2024-06-11 15:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 15:34:13 --> Controller Class Initialized
INFO - 2024-06-11 15:34:13 --> Helper loaded: cookie_helper
INFO - 2024-06-11 15:34:13 --> Final output sent to browser
DEBUG - 2024-06-11 15:34:13 --> Total execution time: 0.4402
INFO - 2024-06-11 15:34:13 --> Config Class Initialized
INFO - 2024-06-11 15:34:13 --> Hooks Class Initialized
DEBUG - 2024-06-11 15:34:13 --> UTF-8 Support Enabled
INFO - 2024-06-11 15:34:13 --> Utf8 Class Initialized
INFO - 2024-06-11 15:34:13 --> URI Class Initialized
INFO - 2024-06-11 15:34:13 --> Router Class Initialized
INFO - 2024-06-11 15:34:13 --> Output Class Initialized
INFO - 2024-06-11 15:34:13 --> Security Class Initialized
DEBUG - 2024-06-11 15:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 15:34:13 --> Input Class Initialized
INFO - 2024-06-11 15:34:13 --> Language Class Initialized
INFO - 2024-06-11 15:34:13 --> Language Class Initialized
INFO - 2024-06-11 15:34:13 --> Config Class Initialized
INFO - 2024-06-11 15:34:13 --> Loader Class Initialized
INFO - 2024-06-11 15:34:13 --> Helper loaded: url_helper
INFO - 2024-06-11 15:34:13 --> Helper loaded: file_helper
INFO - 2024-06-11 15:34:13 --> Helper loaded: form_helper
INFO - 2024-06-11 15:34:13 --> Helper loaded: my_helper
INFO - 2024-06-11 15:34:13 --> Database Driver Class Initialized
INFO - 2024-06-11 15:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 15:34:13 --> Controller Class Initialized
DEBUG - 2024-06-11 15:34:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-11 15:34:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 15:34:14 --> Final output sent to browser
DEBUG - 2024-06-11 15:34:14 --> Total execution time: 0.2465
INFO - 2024-06-11 15:34:18 --> Config Class Initialized
INFO - 2024-06-11 15:34:18 --> Hooks Class Initialized
DEBUG - 2024-06-11 15:34:18 --> UTF-8 Support Enabled
INFO - 2024-06-11 15:34:18 --> Utf8 Class Initialized
INFO - 2024-06-11 15:34:18 --> URI Class Initialized
INFO - 2024-06-11 15:34:18 --> Router Class Initialized
INFO - 2024-06-11 15:34:18 --> Output Class Initialized
INFO - 2024-06-11 15:34:18 --> Security Class Initialized
DEBUG - 2024-06-11 15:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 15:34:18 --> Input Class Initialized
INFO - 2024-06-11 15:34:18 --> Language Class Initialized
INFO - 2024-06-11 15:34:18 --> Language Class Initialized
INFO - 2024-06-11 15:34:18 --> Config Class Initialized
INFO - 2024-06-11 15:34:18 --> Loader Class Initialized
INFO - 2024-06-11 15:34:18 --> Helper loaded: url_helper
INFO - 2024-06-11 15:34:18 --> Helper loaded: file_helper
INFO - 2024-06-11 15:34:18 --> Helper loaded: form_helper
INFO - 2024-06-11 15:34:18 --> Helper loaded: my_helper
INFO - 2024-06-11 15:34:18 --> Database Driver Class Initialized
INFO - 2024-06-11 15:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 15:34:18 --> Controller Class Initialized
DEBUG - 2024-06-11 15:34:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-11 15:34:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 15:34:19 --> Final output sent to browser
DEBUG - 2024-06-11 15:34:19 --> Total execution time: 0.4140
INFO - 2024-06-11 15:34:23 --> Config Class Initialized
INFO - 2024-06-11 15:34:23 --> Hooks Class Initialized
DEBUG - 2024-06-11 15:34:23 --> UTF-8 Support Enabled
INFO - 2024-06-11 15:34:23 --> Utf8 Class Initialized
INFO - 2024-06-11 15:34:23 --> URI Class Initialized
INFO - 2024-06-11 15:34:23 --> Router Class Initialized
INFO - 2024-06-11 15:34:23 --> Output Class Initialized
INFO - 2024-06-11 15:34:23 --> Security Class Initialized
DEBUG - 2024-06-11 15:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 15:34:23 --> Input Class Initialized
INFO - 2024-06-11 15:34:23 --> Language Class Initialized
INFO - 2024-06-11 15:34:23 --> Language Class Initialized
INFO - 2024-06-11 15:34:23 --> Config Class Initialized
INFO - 2024-06-11 15:34:23 --> Loader Class Initialized
INFO - 2024-06-11 15:34:23 --> Helper loaded: url_helper
INFO - 2024-06-11 15:34:23 --> Helper loaded: file_helper
INFO - 2024-06-11 15:34:23 --> Helper loaded: form_helper
INFO - 2024-06-11 15:34:23 --> Helper loaded: my_helper
INFO - 2024-06-11 15:34:23 --> Database Driver Class Initialized
INFO - 2024-06-11 15:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 15:34:24 --> Controller Class Initialized
DEBUG - 2024-06-11 15:34:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-11 15:34:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 15:34:24 --> Final output sent to browser
DEBUG - 2024-06-11 15:34:24 --> Total execution time: 0.5160
INFO - 2024-06-11 15:34:24 --> Config Class Initialized
INFO - 2024-06-11 15:34:24 --> Hooks Class Initialized
DEBUG - 2024-06-11 15:34:24 --> UTF-8 Support Enabled
INFO - 2024-06-11 15:34:24 --> Utf8 Class Initialized
INFO - 2024-06-11 15:34:24 --> URI Class Initialized
INFO - 2024-06-11 15:34:24 --> Router Class Initialized
INFO - 2024-06-11 15:34:24 --> Output Class Initialized
INFO - 2024-06-11 15:34:24 --> Security Class Initialized
DEBUG - 2024-06-11 15:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 15:34:24 --> Input Class Initialized
INFO - 2024-06-11 15:34:24 --> Language Class Initialized
INFO - 2024-06-11 15:34:24 --> Language Class Initialized
INFO - 2024-06-11 15:34:24 --> Config Class Initialized
INFO - 2024-06-11 15:34:24 --> Loader Class Initialized
INFO - 2024-06-11 15:34:24 --> Helper loaded: url_helper
INFO - 2024-06-11 15:34:24 --> Helper loaded: file_helper
INFO - 2024-06-11 15:34:24 --> Helper loaded: form_helper
INFO - 2024-06-11 15:34:24 --> Helper loaded: my_helper
INFO - 2024-06-11 15:34:24 --> Database Driver Class Initialized
INFO - 2024-06-11 15:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 15:34:24 --> Controller Class Initialized
INFO - 2024-06-11 15:35:11 --> Config Class Initialized
INFO - 2024-06-11 15:35:11 --> Hooks Class Initialized
DEBUG - 2024-06-11 15:35:11 --> UTF-8 Support Enabled
INFO - 2024-06-11 15:35:11 --> Utf8 Class Initialized
INFO - 2024-06-11 15:35:11 --> URI Class Initialized
INFO - 2024-06-11 15:35:11 --> Router Class Initialized
INFO - 2024-06-11 15:35:11 --> Output Class Initialized
INFO - 2024-06-11 15:35:11 --> Security Class Initialized
DEBUG - 2024-06-11 15:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 15:35:11 --> Input Class Initialized
INFO - 2024-06-11 15:35:11 --> Language Class Initialized
INFO - 2024-06-11 15:35:11 --> Language Class Initialized
INFO - 2024-06-11 15:35:11 --> Config Class Initialized
INFO - 2024-06-11 15:35:11 --> Loader Class Initialized
INFO - 2024-06-11 15:35:11 --> Helper loaded: url_helper
INFO - 2024-06-11 15:35:11 --> Helper loaded: file_helper
INFO - 2024-06-11 15:35:11 --> Helper loaded: form_helper
INFO - 2024-06-11 15:35:11 --> Helper loaded: my_helper
INFO - 2024-06-11 15:35:11 --> Database Driver Class Initialized
INFO - 2024-06-11 15:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 15:35:11 --> Controller Class Initialized
INFO - 2024-06-11 15:35:12 --> Final output sent to browser
DEBUG - 2024-06-11 15:35:12 --> Total execution time: 0.5837
INFO - 2024-06-11 15:35:24 --> Config Class Initialized
INFO - 2024-06-11 15:35:24 --> Hooks Class Initialized
DEBUG - 2024-06-11 15:35:24 --> UTF-8 Support Enabled
INFO - 2024-06-11 15:35:24 --> Utf8 Class Initialized
INFO - 2024-06-11 15:35:24 --> URI Class Initialized
INFO - 2024-06-11 15:35:24 --> Router Class Initialized
INFO - 2024-06-11 15:35:24 --> Output Class Initialized
INFO - 2024-06-11 15:35:24 --> Security Class Initialized
DEBUG - 2024-06-11 15:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 15:35:24 --> Input Class Initialized
INFO - 2024-06-11 15:35:24 --> Language Class Initialized
INFO - 2024-06-11 15:35:24 --> Language Class Initialized
INFO - 2024-06-11 15:35:24 --> Config Class Initialized
INFO - 2024-06-11 15:35:24 --> Loader Class Initialized
INFO - 2024-06-11 15:35:24 --> Helper loaded: url_helper
INFO - 2024-06-11 15:35:24 --> Helper loaded: file_helper
INFO - 2024-06-11 15:35:24 --> Helper loaded: form_helper
INFO - 2024-06-11 15:35:24 --> Helper loaded: my_helper
INFO - 2024-06-11 15:35:24 --> Database Driver Class Initialized
INFO - 2024-06-11 15:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 15:35:24 --> Controller Class Initialized
INFO - 2024-06-11 15:35:24 --> Final output sent to browser
DEBUG - 2024-06-11 15:35:24 --> Total execution time: 0.3645
INFO - 2024-06-11 15:35:24 --> Config Class Initialized
INFO - 2024-06-11 15:35:24 --> Hooks Class Initialized
DEBUG - 2024-06-11 15:35:24 --> UTF-8 Support Enabled
INFO - 2024-06-11 15:35:24 --> Utf8 Class Initialized
INFO - 2024-06-11 15:35:24 --> URI Class Initialized
INFO - 2024-06-11 15:35:24 --> Router Class Initialized
INFO - 2024-06-11 15:35:24 --> Output Class Initialized
INFO - 2024-06-11 15:35:24 --> Security Class Initialized
DEBUG - 2024-06-11 15:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 15:35:24 --> Input Class Initialized
INFO - 2024-06-11 15:35:24 --> Language Class Initialized
INFO - 2024-06-11 15:35:24 --> Language Class Initialized
INFO - 2024-06-11 15:35:24 --> Config Class Initialized
INFO - 2024-06-11 15:35:24 --> Loader Class Initialized
INFO - 2024-06-11 15:35:24 --> Helper loaded: url_helper
INFO - 2024-06-11 15:35:24 --> Helper loaded: file_helper
INFO - 2024-06-11 15:35:24 --> Helper loaded: form_helper
INFO - 2024-06-11 15:35:24 --> Helper loaded: my_helper
INFO - 2024-06-11 15:35:24 --> Database Driver Class Initialized
INFO - 2024-06-11 15:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 15:35:24 --> Controller Class Initialized
INFO - 2024-06-11 15:35:26 --> Config Class Initialized
INFO - 2024-06-11 15:35:26 --> Hooks Class Initialized
DEBUG - 2024-06-11 15:35:26 --> UTF-8 Support Enabled
INFO - 2024-06-11 15:35:26 --> Utf8 Class Initialized
INFO - 2024-06-11 15:35:26 --> URI Class Initialized
INFO - 2024-06-11 15:35:26 --> Router Class Initialized
INFO - 2024-06-11 15:35:26 --> Output Class Initialized
INFO - 2024-06-11 15:35:26 --> Security Class Initialized
DEBUG - 2024-06-11 15:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 15:35:26 --> Input Class Initialized
INFO - 2024-06-11 15:35:26 --> Language Class Initialized
INFO - 2024-06-11 15:35:26 --> Language Class Initialized
INFO - 2024-06-11 15:35:26 --> Config Class Initialized
INFO - 2024-06-11 15:35:26 --> Loader Class Initialized
INFO - 2024-06-11 15:35:26 --> Helper loaded: url_helper
INFO - 2024-06-11 15:35:26 --> Helper loaded: file_helper
INFO - 2024-06-11 15:35:26 --> Helper loaded: form_helper
INFO - 2024-06-11 15:35:26 --> Helper loaded: my_helper
INFO - 2024-06-11 15:35:26 --> Database Driver Class Initialized
INFO - 2024-06-11 15:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 15:35:26 --> Controller Class Initialized
INFO - 2024-06-11 15:35:26 --> Final output sent to browser
DEBUG - 2024-06-11 15:35:26 --> Total execution time: 0.1100
INFO - 2024-06-11 15:35:59 --> Config Class Initialized
INFO - 2024-06-11 15:35:59 --> Hooks Class Initialized
DEBUG - 2024-06-11 15:35:59 --> UTF-8 Support Enabled
INFO - 2024-06-11 15:35:59 --> Utf8 Class Initialized
INFO - 2024-06-11 15:35:59 --> URI Class Initialized
INFO - 2024-06-11 15:35:59 --> Router Class Initialized
INFO - 2024-06-11 15:35:59 --> Output Class Initialized
INFO - 2024-06-11 15:35:59 --> Security Class Initialized
DEBUG - 2024-06-11 15:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 15:35:59 --> Input Class Initialized
INFO - 2024-06-11 15:35:59 --> Language Class Initialized
INFO - 2024-06-11 15:35:59 --> Language Class Initialized
INFO - 2024-06-11 15:35:59 --> Config Class Initialized
INFO - 2024-06-11 15:35:59 --> Loader Class Initialized
INFO - 2024-06-11 15:35:59 --> Helper loaded: url_helper
INFO - 2024-06-11 15:36:00 --> Helper loaded: file_helper
INFO - 2024-06-11 15:36:00 --> Helper loaded: form_helper
INFO - 2024-06-11 15:36:00 --> Helper loaded: my_helper
INFO - 2024-06-11 15:36:00 --> Database Driver Class Initialized
INFO - 2024-06-11 15:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 15:36:00 --> Controller Class Initialized
INFO - 2024-06-11 15:36:00 --> Final output sent to browser
DEBUG - 2024-06-11 15:36:00 --> Total execution time: 0.2405
INFO - 2024-06-11 15:36:00 --> Config Class Initialized
INFO - 2024-06-11 15:36:00 --> Hooks Class Initialized
DEBUG - 2024-06-11 15:36:00 --> UTF-8 Support Enabled
INFO - 2024-06-11 15:36:00 --> Utf8 Class Initialized
INFO - 2024-06-11 15:36:00 --> URI Class Initialized
INFO - 2024-06-11 15:36:00 --> Router Class Initialized
INFO - 2024-06-11 15:36:00 --> Output Class Initialized
INFO - 2024-06-11 15:36:00 --> Security Class Initialized
DEBUG - 2024-06-11 15:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 15:36:00 --> Input Class Initialized
INFO - 2024-06-11 15:36:00 --> Language Class Initialized
INFO - 2024-06-11 15:36:00 --> Language Class Initialized
INFO - 2024-06-11 15:36:00 --> Config Class Initialized
INFO - 2024-06-11 15:36:00 --> Loader Class Initialized
INFO - 2024-06-11 15:36:01 --> Helper loaded: url_helper
INFO - 2024-06-11 15:36:01 --> Helper loaded: file_helper
INFO - 2024-06-11 15:36:01 --> Helper loaded: form_helper
INFO - 2024-06-11 15:36:01 --> Helper loaded: my_helper
INFO - 2024-06-11 15:36:01 --> Database Driver Class Initialized
INFO - 2024-06-11 15:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 15:36:01 --> Controller Class Initialized
INFO - 2024-06-11 15:36:03 --> Config Class Initialized
INFO - 2024-06-11 15:36:03 --> Hooks Class Initialized
DEBUG - 2024-06-11 15:36:03 --> UTF-8 Support Enabled
INFO - 2024-06-11 15:36:03 --> Utf8 Class Initialized
INFO - 2024-06-11 15:36:03 --> URI Class Initialized
INFO - 2024-06-11 15:36:03 --> Router Class Initialized
INFO - 2024-06-11 15:36:03 --> Output Class Initialized
INFO - 2024-06-11 15:36:03 --> Security Class Initialized
DEBUG - 2024-06-11 15:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 15:36:03 --> Input Class Initialized
INFO - 2024-06-11 15:36:03 --> Language Class Initialized
INFO - 2024-06-11 15:36:03 --> Language Class Initialized
INFO - 2024-06-11 15:36:03 --> Config Class Initialized
INFO - 2024-06-11 15:36:03 --> Loader Class Initialized
INFO - 2024-06-11 15:36:03 --> Helper loaded: url_helper
INFO - 2024-06-11 15:36:03 --> Helper loaded: file_helper
INFO - 2024-06-11 15:36:03 --> Helper loaded: form_helper
INFO - 2024-06-11 15:36:03 --> Helper loaded: my_helper
INFO - 2024-06-11 15:36:03 --> Database Driver Class Initialized
INFO - 2024-06-11 15:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 15:36:03 --> Controller Class Initialized
INFO - 2024-06-11 15:36:03 --> Final output sent to browser
DEBUG - 2024-06-11 15:36:03 --> Total execution time: 0.2208
INFO - 2024-06-11 15:36:38 --> Config Class Initialized
INFO - 2024-06-11 15:36:38 --> Hooks Class Initialized
DEBUG - 2024-06-11 15:36:38 --> UTF-8 Support Enabled
INFO - 2024-06-11 15:36:38 --> Utf8 Class Initialized
INFO - 2024-06-11 15:36:38 --> URI Class Initialized
INFO - 2024-06-11 15:36:38 --> Router Class Initialized
INFO - 2024-06-11 15:36:38 --> Output Class Initialized
INFO - 2024-06-11 15:36:38 --> Security Class Initialized
DEBUG - 2024-06-11 15:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 15:36:38 --> Input Class Initialized
INFO - 2024-06-11 15:36:38 --> Language Class Initialized
INFO - 2024-06-11 15:36:38 --> Language Class Initialized
INFO - 2024-06-11 15:36:38 --> Config Class Initialized
INFO - 2024-06-11 15:36:38 --> Loader Class Initialized
INFO - 2024-06-11 15:36:38 --> Helper loaded: url_helper
INFO - 2024-06-11 15:36:38 --> Helper loaded: file_helper
INFO - 2024-06-11 15:36:38 --> Helper loaded: form_helper
INFO - 2024-06-11 15:36:38 --> Helper loaded: my_helper
INFO - 2024-06-11 15:36:38 --> Database Driver Class Initialized
INFO - 2024-06-11 15:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 15:36:39 --> Controller Class Initialized
INFO - 2024-06-11 15:36:39 --> Final output sent to browser
DEBUG - 2024-06-11 15:36:39 --> Total execution time: 0.2816
INFO - 2024-06-11 15:36:39 --> Config Class Initialized
INFO - 2024-06-11 15:36:39 --> Hooks Class Initialized
DEBUG - 2024-06-11 15:36:39 --> UTF-8 Support Enabled
INFO - 2024-06-11 15:36:39 --> Utf8 Class Initialized
INFO - 2024-06-11 15:36:39 --> URI Class Initialized
INFO - 2024-06-11 15:36:39 --> Router Class Initialized
INFO - 2024-06-11 15:36:39 --> Output Class Initialized
INFO - 2024-06-11 15:36:39 --> Security Class Initialized
DEBUG - 2024-06-11 15:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 15:36:39 --> Input Class Initialized
INFO - 2024-06-11 15:36:39 --> Language Class Initialized
INFO - 2024-06-11 15:36:39 --> Language Class Initialized
INFO - 2024-06-11 15:36:39 --> Config Class Initialized
INFO - 2024-06-11 15:36:39 --> Loader Class Initialized
INFO - 2024-06-11 15:36:39 --> Helper loaded: url_helper
INFO - 2024-06-11 15:36:39 --> Helper loaded: file_helper
INFO - 2024-06-11 15:36:39 --> Helper loaded: form_helper
INFO - 2024-06-11 15:36:39 --> Helper loaded: my_helper
INFO - 2024-06-11 15:36:39 --> Database Driver Class Initialized
INFO - 2024-06-11 15:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 15:36:39 --> Controller Class Initialized
INFO - 2024-06-11 15:37:13 --> Config Class Initialized
INFO - 2024-06-11 15:37:13 --> Hooks Class Initialized
DEBUG - 2024-06-11 15:37:13 --> UTF-8 Support Enabled
INFO - 2024-06-11 15:37:13 --> Utf8 Class Initialized
INFO - 2024-06-11 15:37:13 --> URI Class Initialized
INFO - 2024-06-11 15:37:13 --> Router Class Initialized
INFO - 2024-06-11 15:37:13 --> Output Class Initialized
INFO - 2024-06-11 15:37:13 --> Security Class Initialized
DEBUG - 2024-06-11 15:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 15:37:13 --> Input Class Initialized
INFO - 2024-06-11 15:37:13 --> Language Class Initialized
INFO - 2024-06-11 15:37:13 --> Language Class Initialized
INFO - 2024-06-11 15:37:13 --> Config Class Initialized
INFO - 2024-06-11 15:37:13 --> Loader Class Initialized
INFO - 2024-06-11 15:37:13 --> Helper loaded: url_helper
INFO - 2024-06-11 15:37:13 --> Helper loaded: file_helper
INFO - 2024-06-11 15:37:13 --> Helper loaded: form_helper
INFO - 2024-06-11 15:37:13 --> Helper loaded: my_helper
INFO - 2024-06-11 15:37:13 --> Database Driver Class Initialized
INFO - 2024-06-11 15:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 15:37:13 --> Controller Class Initialized
INFO - 2024-06-11 15:37:13 --> Final output sent to browser
DEBUG - 2024-06-11 15:37:13 --> Total execution time: 0.6332
INFO - 2024-06-11 15:39:31 --> Config Class Initialized
INFO - 2024-06-11 15:39:31 --> Hooks Class Initialized
DEBUG - 2024-06-11 15:39:31 --> UTF-8 Support Enabled
INFO - 2024-06-11 15:39:31 --> Utf8 Class Initialized
INFO - 2024-06-11 15:39:31 --> URI Class Initialized
INFO - 2024-06-11 15:39:31 --> Router Class Initialized
INFO - 2024-06-11 15:39:31 --> Output Class Initialized
INFO - 2024-06-11 15:39:31 --> Security Class Initialized
DEBUG - 2024-06-11 15:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 15:39:31 --> Input Class Initialized
INFO - 2024-06-11 15:39:31 --> Language Class Initialized
INFO - 2024-06-11 15:39:31 --> Language Class Initialized
INFO - 2024-06-11 15:39:31 --> Config Class Initialized
INFO - 2024-06-11 15:39:31 --> Loader Class Initialized
INFO - 2024-06-11 15:39:31 --> Helper loaded: url_helper
INFO - 2024-06-11 15:39:31 --> Helper loaded: file_helper
INFO - 2024-06-11 15:39:31 --> Helper loaded: form_helper
INFO - 2024-06-11 15:39:31 --> Helper loaded: my_helper
INFO - 2024-06-11 15:39:31 --> Database Driver Class Initialized
INFO - 2024-06-11 15:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 15:39:31 --> Controller Class Initialized
INFO - 2024-06-11 15:39:32 --> Final output sent to browser
DEBUG - 2024-06-11 15:39:32 --> Total execution time: 1.3279
INFO - 2024-06-11 15:39:37 --> Config Class Initialized
INFO - 2024-06-11 15:39:37 --> Hooks Class Initialized
DEBUG - 2024-06-11 15:39:38 --> UTF-8 Support Enabled
INFO - 2024-06-11 15:39:38 --> Utf8 Class Initialized
INFO - 2024-06-11 15:39:38 --> URI Class Initialized
INFO - 2024-06-11 15:39:38 --> Router Class Initialized
INFO - 2024-06-11 15:39:38 --> Output Class Initialized
INFO - 2024-06-11 15:39:38 --> Security Class Initialized
DEBUG - 2024-06-11 15:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 15:39:38 --> Input Class Initialized
INFO - 2024-06-11 15:39:38 --> Language Class Initialized
INFO - 2024-06-11 15:39:38 --> Language Class Initialized
INFO - 2024-06-11 15:39:38 --> Config Class Initialized
INFO - 2024-06-11 15:39:38 --> Loader Class Initialized
INFO - 2024-06-11 15:39:38 --> Helper loaded: url_helper
INFO - 2024-06-11 15:39:38 --> Helper loaded: file_helper
INFO - 2024-06-11 15:39:38 --> Helper loaded: form_helper
INFO - 2024-06-11 15:39:38 --> Helper loaded: my_helper
INFO - 2024-06-11 15:39:38 --> Database Driver Class Initialized
INFO - 2024-06-11 15:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 15:39:38 --> Controller Class Initialized
INFO - 2024-06-11 15:39:39 --> Final output sent to browser
DEBUG - 2024-06-11 15:39:39 --> Total execution time: 1.2988
INFO - 2024-06-11 15:41:31 --> Config Class Initialized
INFO - 2024-06-11 15:41:31 --> Hooks Class Initialized
DEBUG - 2024-06-11 15:41:31 --> UTF-8 Support Enabled
INFO - 2024-06-11 15:41:31 --> Utf8 Class Initialized
INFO - 2024-06-11 15:41:31 --> URI Class Initialized
INFO - 2024-06-11 15:41:31 --> Router Class Initialized
INFO - 2024-06-11 15:41:31 --> Output Class Initialized
INFO - 2024-06-11 15:41:31 --> Security Class Initialized
DEBUG - 2024-06-11 15:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 15:41:31 --> Input Class Initialized
INFO - 2024-06-11 15:41:31 --> Language Class Initialized
INFO - 2024-06-11 15:41:31 --> Language Class Initialized
INFO - 2024-06-11 15:41:31 --> Config Class Initialized
INFO - 2024-06-11 15:41:31 --> Loader Class Initialized
INFO - 2024-06-11 15:41:31 --> Helper loaded: url_helper
INFO - 2024-06-11 15:41:31 --> Helper loaded: file_helper
INFO - 2024-06-11 15:41:31 --> Helper loaded: form_helper
INFO - 2024-06-11 15:41:31 --> Helper loaded: my_helper
INFO - 2024-06-11 15:41:31 --> Database Driver Class Initialized
INFO - 2024-06-11 15:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 15:41:31 --> Controller Class Initialized
INFO - 2024-06-11 15:41:31 --> Final output sent to browser
DEBUG - 2024-06-11 15:41:31 --> Total execution time: 0.3796
INFO - 2024-06-11 15:41:39 --> Config Class Initialized
INFO - 2024-06-11 15:41:39 --> Hooks Class Initialized
DEBUG - 2024-06-11 15:41:39 --> UTF-8 Support Enabled
INFO - 2024-06-11 15:41:39 --> Utf8 Class Initialized
INFO - 2024-06-11 15:41:39 --> URI Class Initialized
INFO - 2024-06-11 15:41:39 --> Router Class Initialized
INFO - 2024-06-11 15:41:39 --> Output Class Initialized
INFO - 2024-06-11 15:41:39 --> Security Class Initialized
DEBUG - 2024-06-11 15:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 15:41:39 --> Input Class Initialized
INFO - 2024-06-11 15:41:39 --> Language Class Initialized
INFO - 2024-06-11 15:41:39 --> Language Class Initialized
INFO - 2024-06-11 15:41:39 --> Config Class Initialized
INFO - 2024-06-11 15:41:39 --> Loader Class Initialized
INFO - 2024-06-11 15:41:39 --> Helper loaded: url_helper
INFO - 2024-06-11 15:41:39 --> Helper loaded: file_helper
INFO - 2024-06-11 15:41:39 --> Helper loaded: form_helper
INFO - 2024-06-11 15:41:39 --> Helper loaded: my_helper
INFO - 2024-06-11 15:41:39 --> Database Driver Class Initialized
INFO - 2024-06-11 15:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 15:41:39 --> Controller Class Initialized
INFO - 2024-06-11 15:41:40 --> Final output sent to browser
DEBUG - 2024-06-11 15:41:40 --> Total execution time: 1.4937
INFO - 2024-06-11 15:41:44 --> Config Class Initialized
INFO - 2024-06-11 15:41:44 --> Hooks Class Initialized
DEBUG - 2024-06-11 15:41:44 --> UTF-8 Support Enabled
INFO - 2024-06-11 15:41:44 --> Utf8 Class Initialized
INFO - 2024-06-11 15:41:44 --> URI Class Initialized
INFO - 2024-06-11 15:41:44 --> Router Class Initialized
INFO - 2024-06-11 15:41:44 --> Output Class Initialized
INFO - 2024-06-11 15:41:44 --> Security Class Initialized
DEBUG - 2024-06-11 15:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 15:41:44 --> Input Class Initialized
INFO - 2024-06-11 15:41:44 --> Language Class Initialized
INFO - 2024-06-11 15:41:44 --> Language Class Initialized
INFO - 2024-06-11 15:41:44 --> Config Class Initialized
INFO - 2024-06-11 15:41:44 --> Loader Class Initialized
INFO - 2024-06-11 15:41:44 --> Helper loaded: url_helper
INFO - 2024-06-11 15:41:44 --> Helper loaded: file_helper
INFO - 2024-06-11 15:41:44 --> Helper loaded: form_helper
INFO - 2024-06-11 15:41:44 --> Helper loaded: my_helper
INFO - 2024-06-11 15:41:44 --> Database Driver Class Initialized
INFO - 2024-06-11 15:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 15:41:44 --> Controller Class Initialized
INFO - 2024-06-11 15:41:45 --> Final output sent to browser
DEBUG - 2024-06-11 15:41:45 --> Total execution time: 0.9404
INFO - 2024-06-11 15:43:42 --> Config Class Initialized
INFO - 2024-06-11 15:43:42 --> Hooks Class Initialized
DEBUG - 2024-06-11 15:43:42 --> UTF-8 Support Enabled
INFO - 2024-06-11 15:43:42 --> Utf8 Class Initialized
INFO - 2024-06-11 15:43:42 --> URI Class Initialized
INFO - 2024-06-11 15:43:42 --> Router Class Initialized
INFO - 2024-06-11 15:43:42 --> Output Class Initialized
INFO - 2024-06-11 15:43:42 --> Security Class Initialized
DEBUG - 2024-06-11 15:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 15:43:42 --> Input Class Initialized
INFO - 2024-06-11 15:43:42 --> Language Class Initialized
INFO - 2024-06-11 15:43:42 --> Language Class Initialized
INFO - 2024-06-11 15:43:42 --> Config Class Initialized
INFO - 2024-06-11 15:43:42 --> Loader Class Initialized
INFO - 2024-06-11 15:43:42 --> Helper loaded: url_helper
INFO - 2024-06-11 15:43:42 --> Helper loaded: file_helper
INFO - 2024-06-11 15:43:42 --> Helper loaded: form_helper
INFO - 2024-06-11 15:43:42 --> Helper loaded: my_helper
INFO - 2024-06-11 15:43:42 --> Database Driver Class Initialized
INFO - 2024-06-11 15:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 15:43:42 --> Controller Class Initialized
INFO - 2024-06-11 15:43:42 --> Final output sent to browser
DEBUG - 2024-06-11 15:43:42 --> Total execution time: 0.3175
INFO - 2024-06-11 15:43:48 --> Config Class Initialized
INFO - 2024-06-11 15:43:48 --> Hooks Class Initialized
DEBUG - 2024-06-11 15:43:48 --> UTF-8 Support Enabled
INFO - 2024-06-11 15:43:48 --> Utf8 Class Initialized
INFO - 2024-06-11 15:43:48 --> URI Class Initialized
INFO - 2024-06-11 15:43:48 --> Router Class Initialized
INFO - 2024-06-11 15:43:48 --> Output Class Initialized
INFO - 2024-06-11 15:43:48 --> Security Class Initialized
DEBUG - 2024-06-11 15:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 15:43:48 --> Input Class Initialized
INFO - 2024-06-11 15:43:48 --> Language Class Initialized
INFO - 2024-06-11 15:43:48 --> Language Class Initialized
INFO - 2024-06-11 15:43:48 --> Config Class Initialized
INFO - 2024-06-11 15:43:48 --> Loader Class Initialized
INFO - 2024-06-11 15:43:48 --> Helper loaded: url_helper
INFO - 2024-06-11 15:43:48 --> Helper loaded: file_helper
INFO - 2024-06-11 15:43:48 --> Helper loaded: form_helper
INFO - 2024-06-11 15:43:48 --> Helper loaded: my_helper
INFO - 2024-06-11 15:43:48 --> Database Driver Class Initialized
INFO - 2024-06-11 15:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 15:43:48 --> Controller Class Initialized
INFO - 2024-06-11 15:43:49 --> Final output sent to browser
DEBUG - 2024-06-11 15:43:49 --> Total execution time: 1.1392
INFO - 2024-06-11 15:43:52 --> Config Class Initialized
INFO - 2024-06-11 15:43:52 --> Hooks Class Initialized
DEBUG - 2024-06-11 15:43:52 --> UTF-8 Support Enabled
INFO - 2024-06-11 15:43:52 --> Utf8 Class Initialized
INFO - 2024-06-11 15:43:52 --> URI Class Initialized
INFO - 2024-06-11 15:43:52 --> Router Class Initialized
INFO - 2024-06-11 15:43:52 --> Output Class Initialized
INFO - 2024-06-11 15:43:52 --> Security Class Initialized
DEBUG - 2024-06-11 15:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 15:43:52 --> Input Class Initialized
INFO - 2024-06-11 15:43:52 --> Language Class Initialized
INFO - 2024-06-11 15:43:52 --> Language Class Initialized
INFO - 2024-06-11 15:43:52 --> Config Class Initialized
INFO - 2024-06-11 15:43:52 --> Loader Class Initialized
INFO - 2024-06-11 15:43:52 --> Helper loaded: url_helper
INFO - 2024-06-11 15:43:52 --> Helper loaded: file_helper
INFO - 2024-06-11 15:43:52 --> Helper loaded: form_helper
INFO - 2024-06-11 15:43:52 --> Helper loaded: my_helper
INFO - 2024-06-11 15:43:52 --> Database Driver Class Initialized
INFO - 2024-06-11 15:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 15:43:52 --> Controller Class Initialized
INFO - 2024-06-11 15:43:53 --> Final output sent to browser
DEBUG - 2024-06-11 15:43:53 --> Total execution time: 0.8588
INFO - 2024-06-11 15:45:12 --> Config Class Initialized
INFO - 2024-06-11 15:45:12 --> Hooks Class Initialized
DEBUG - 2024-06-11 15:45:12 --> UTF-8 Support Enabled
INFO - 2024-06-11 15:45:12 --> Utf8 Class Initialized
INFO - 2024-06-11 15:45:12 --> URI Class Initialized
INFO - 2024-06-11 15:45:13 --> Router Class Initialized
INFO - 2024-06-11 15:45:13 --> Output Class Initialized
INFO - 2024-06-11 15:45:13 --> Security Class Initialized
DEBUG - 2024-06-11 15:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 15:45:13 --> Input Class Initialized
INFO - 2024-06-11 15:45:13 --> Language Class Initialized
INFO - 2024-06-11 15:45:13 --> Language Class Initialized
INFO - 2024-06-11 15:45:13 --> Config Class Initialized
INFO - 2024-06-11 15:45:13 --> Loader Class Initialized
INFO - 2024-06-11 15:45:13 --> Helper loaded: url_helper
INFO - 2024-06-11 15:45:13 --> Helper loaded: file_helper
INFO - 2024-06-11 15:45:13 --> Helper loaded: form_helper
INFO - 2024-06-11 15:45:13 --> Helper loaded: my_helper
INFO - 2024-06-11 15:45:13 --> Database Driver Class Initialized
INFO - 2024-06-11 15:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 15:45:13 --> Controller Class Initialized
INFO - 2024-06-11 15:45:14 --> Final output sent to browser
DEBUG - 2024-06-11 15:45:14 --> Total execution time: 1.6370
INFO - 2024-06-11 15:45:24 --> Config Class Initialized
INFO - 2024-06-11 15:45:24 --> Hooks Class Initialized
DEBUG - 2024-06-11 15:45:24 --> UTF-8 Support Enabled
INFO - 2024-06-11 15:45:24 --> Utf8 Class Initialized
INFO - 2024-06-11 15:45:24 --> URI Class Initialized
INFO - 2024-06-11 15:45:24 --> Router Class Initialized
INFO - 2024-06-11 15:45:24 --> Output Class Initialized
INFO - 2024-06-11 15:45:24 --> Security Class Initialized
DEBUG - 2024-06-11 15:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 15:45:24 --> Input Class Initialized
INFO - 2024-06-11 15:45:24 --> Language Class Initialized
INFO - 2024-06-11 15:45:24 --> Language Class Initialized
INFO - 2024-06-11 15:45:24 --> Config Class Initialized
INFO - 2024-06-11 15:45:24 --> Loader Class Initialized
INFO - 2024-06-11 15:45:24 --> Helper loaded: url_helper
INFO - 2024-06-11 15:45:24 --> Helper loaded: file_helper
INFO - 2024-06-11 15:45:24 --> Helper loaded: form_helper
INFO - 2024-06-11 15:45:24 --> Helper loaded: my_helper
INFO - 2024-06-11 15:45:24 --> Database Driver Class Initialized
INFO - 2024-06-11 15:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 15:45:25 --> Controller Class Initialized
DEBUG - 2024-06-11 15:45:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-11 15:45:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 15:45:25 --> Final output sent to browser
DEBUG - 2024-06-11 15:45:25 --> Total execution time: 0.4802
INFO - 2024-06-11 15:45:27 --> Config Class Initialized
INFO - 2024-06-11 15:45:27 --> Hooks Class Initialized
DEBUG - 2024-06-11 15:45:27 --> UTF-8 Support Enabled
INFO - 2024-06-11 15:45:27 --> Utf8 Class Initialized
INFO - 2024-06-11 15:45:27 --> URI Class Initialized
INFO - 2024-06-11 15:45:27 --> Router Class Initialized
INFO - 2024-06-11 15:45:27 --> Output Class Initialized
INFO - 2024-06-11 15:45:27 --> Security Class Initialized
DEBUG - 2024-06-11 15:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 15:45:27 --> Input Class Initialized
INFO - 2024-06-11 15:45:27 --> Language Class Initialized
INFO - 2024-06-11 15:45:27 --> Language Class Initialized
INFO - 2024-06-11 15:45:27 --> Config Class Initialized
INFO - 2024-06-11 15:45:27 --> Loader Class Initialized
INFO - 2024-06-11 15:45:27 --> Helper loaded: url_helper
INFO - 2024-06-11 15:45:27 --> Helper loaded: file_helper
INFO - 2024-06-11 15:45:27 --> Helper loaded: form_helper
INFO - 2024-06-11 15:45:27 --> Helper loaded: my_helper
INFO - 2024-06-11 15:45:27 --> Database Driver Class Initialized
INFO - 2024-06-11 15:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 15:45:27 --> Controller Class Initialized
DEBUG - 2024-06-11 15:45:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-06-11 15:45:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 15:45:27 --> Final output sent to browser
DEBUG - 2024-06-11 15:45:27 --> Total execution time: 0.4420
INFO - 2024-06-11 15:45:31 --> Config Class Initialized
INFO - 2024-06-11 15:45:31 --> Hooks Class Initialized
DEBUG - 2024-06-11 15:45:31 --> UTF-8 Support Enabled
INFO - 2024-06-11 15:45:31 --> Utf8 Class Initialized
INFO - 2024-06-11 15:45:31 --> URI Class Initialized
INFO - 2024-06-11 15:45:31 --> Router Class Initialized
INFO - 2024-06-11 15:45:31 --> Output Class Initialized
INFO - 2024-06-11 15:45:31 --> Security Class Initialized
DEBUG - 2024-06-11 15:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 15:45:31 --> Input Class Initialized
INFO - 2024-06-11 15:45:31 --> Language Class Initialized
INFO - 2024-06-11 15:45:31 --> Language Class Initialized
INFO - 2024-06-11 15:45:31 --> Config Class Initialized
INFO - 2024-06-11 15:45:31 --> Loader Class Initialized
INFO - 2024-06-11 15:45:31 --> Helper loaded: url_helper
INFO - 2024-06-11 15:45:31 --> Helper loaded: file_helper
INFO - 2024-06-11 15:45:31 --> Helper loaded: form_helper
INFO - 2024-06-11 15:45:31 --> Helper loaded: my_helper
INFO - 2024-06-11 15:45:31 --> Database Driver Class Initialized
INFO - 2024-06-11 15:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 15:45:31 --> Controller Class Initialized
INFO - 2024-06-11 15:45:32 --> Final output sent to browser
DEBUG - 2024-06-11 15:45:32 --> Total execution time: 0.8892
INFO - 2024-06-11 15:45:46 --> Config Class Initialized
INFO - 2024-06-11 15:45:46 --> Hooks Class Initialized
DEBUG - 2024-06-11 15:45:46 --> UTF-8 Support Enabled
INFO - 2024-06-11 15:45:46 --> Utf8 Class Initialized
INFO - 2024-06-11 15:45:46 --> URI Class Initialized
INFO - 2024-06-11 15:45:46 --> Router Class Initialized
INFO - 2024-06-11 15:45:46 --> Output Class Initialized
INFO - 2024-06-11 15:45:46 --> Security Class Initialized
DEBUG - 2024-06-11 15:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 15:45:46 --> Input Class Initialized
INFO - 2024-06-11 15:45:46 --> Language Class Initialized
INFO - 2024-06-11 15:45:46 --> Language Class Initialized
INFO - 2024-06-11 15:45:46 --> Config Class Initialized
INFO - 2024-06-11 15:45:46 --> Loader Class Initialized
INFO - 2024-06-11 15:45:46 --> Helper loaded: url_helper
INFO - 2024-06-11 15:45:46 --> Helper loaded: file_helper
INFO - 2024-06-11 15:45:46 --> Helper loaded: form_helper
INFO - 2024-06-11 15:45:46 --> Helper loaded: my_helper
INFO - 2024-06-11 15:45:46 --> Database Driver Class Initialized
INFO - 2024-06-11 15:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 15:45:46 --> Controller Class Initialized
DEBUG - 2024-06-11 15:45:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-11 15:45:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 15:45:46 --> Final output sent to browser
DEBUG - 2024-06-11 15:45:46 --> Total execution time: 0.2416
INFO - 2024-06-11 17:27:18 --> Config Class Initialized
INFO - 2024-06-11 17:27:18 --> Hooks Class Initialized
DEBUG - 2024-06-11 17:27:18 --> UTF-8 Support Enabled
INFO - 2024-06-11 17:27:18 --> Utf8 Class Initialized
INFO - 2024-06-11 17:27:18 --> URI Class Initialized
INFO - 2024-06-11 17:27:18 --> Router Class Initialized
INFO - 2024-06-11 17:27:18 --> Output Class Initialized
INFO - 2024-06-11 17:27:18 --> Security Class Initialized
DEBUG - 2024-06-11 17:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 17:27:18 --> Input Class Initialized
INFO - 2024-06-11 17:27:18 --> Language Class Initialized
INFO - 2024-06-11 17:27:18 --> Language Class Initialized
INFO - 2024-06-11 17:27:18 --> Config Class Initialized
INFO - 2024-06-11 17:27:18 --> Loader Class Initialized
INFO - 2024-06-11 17:27:18 --> Helper loaded: url_helper
INFO - 2024-06-11 17:27:18 --> Helper loaded: file_helper
INFO - 2024-06-11 17:27:18 --> Helper loaded: form_helper
INFO - 2024-06-11 17:27:19 --> Config Class Initialized
INFO - 2024-06-11 17:27:19 --> Hooks Class Initialized
DEBUG - 2024-06-11 17:27:19 --> UTF-8 Support Enabled
INFO - 2024-06-11 17:27:19 --> Utf8 Class Initialized
INFO - 2024-06-11 17:27:19 --> URI Class Initialized
INFO - 2024-06-11 17:27:19 --> Router Class Initialized
INFO - 2024-06-11 17:27:19 --> Output Class Initialized
INFO - 2024-06-11 17:27:19 --> Helper loaded: my_helper
INFO - 2024-06-11 17:27:19 --> Security Class Initialized
DEBUG - 2024-06-11 17:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 17:27:19 --> Input Class Initialized
INFO - 2024-06-11 17:27:19 --> Language Class Initialized
INFO - 2024-06-11 17:27:19 --> Language Class Initialized
INFO - 2024-06-11 17:27:19 --> Config Class Initialized
INFO - 2024-06-11 17:27:19 --> Loader Class Initialized
INFO - 2024-06-11 17:27:19 --> Helper loaded: url_helper
INFO - 2024-06-11 17:27:19 --> Helper loaded: file_helper
INFO - 2024-06-11 17:27:19 --> Helper loaded: form_helper
INFO - 2024-06-11 17:27:19 --> Helper loaded: my_helper
INFO - 2024-06-11 17:27:19 --> Database Driver Class Initialized
INFO - 2024-06-11 17:27:19 --> Database Driver Class Initialized
INFO - 2024-06-11 17:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 17:27:19 --> Controller Class Initialized
INFO - 2024-06-11 17:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 17:27:19 --> Controller Class Initialized
INFO - 2024-06-11 17:27:19 --> Helper loaded: cookie_helper
INFO - 2024-06-11 17:27:19 --> Final output sent to browser
DEBUG - 2024-06-11 17:27:19 --> Total execution time: 0.5808
INFO - 2024-06-11 17:27:19 --> Helper loaded: cookie_helper
INFO - 2024-06-11 17:27:19 --> Final output sent to browser
DEBUG - 2024-06-11 17:27:19 --> Total execution time: 1.0514
INFO - 2024-06-11 17:27:19 --> Config Class Initialized
INFO - 2024-06-11 17:27:19 --> Hooks Class Initialized
DEBUG - 2024-06-11 17:27:19 --> UTF-8 Support Enabled
INFO - 2024-06-11 17:27:19 --> Utf8 Class Initialized
INFO - 2024-06-11 17:27:19 --> URI Class Initialized
INFO - 2024-06-11 17:27:19 --> Router Class Initialized
INFO - 2024-06-11 17:27:19 --> Output Class Initialized
INFO - 2024-06-11 17:27:19 --> Security Class Initialized
DEBUG - 2024-06-11 17:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 17:27:19 --> Input Class Initialized
INFO - 2024-06-11 17:27:19 --> Language Class Initialized
INFO - 2024-06-11 17:27:19 --> Language Class Initialized
INFO - 2024-06-11 17:27:19 --> Config Class Initialized
INFO - 2024-06-11 17:27:19 --> Loader Class Initialized
INFO - 2024-06-11 17:27:19 --> Helper loaded: url_helper
INFO - 2024-06-11 17:27:19 --> Helper loaded: file_helper
INFO - 2024-06-11 17:27:19 --> Helper loaded: form_helper
INFO - 2024-06-11 17:27:19 --> Helper loaded: my_helper
INFO - 2024-06-11 17:27:19 --> Database Driver Class Initialized
INFO - 2024-06-11 17:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 17:27:19 --> Controller Class Initialized
INFO - 2024-06-11 17:27:19 --> Helper loaded: cookie_helper
INFO - 2024-06-11 17:27:19 --> Final output sent to browser
DEBUG - 2024-06-11 17:27:19 --> Total execution time: 0.2697
INFO - 2024-06-11 17:27:20 --> Config Class Initialized
INFO - 2024-06-11 17:27:20 --> Hooks Class Initialized
DEBUG - 2024-06-11 17:27:20 --> UTF-8 Support Enabled
INFO - 2024-06-11 17:27:20 --> Utf8 Class Initialized
INFO - 2024-06-11 17:27:20 --> URI Class Initialized
INFO - 2024-06-11 17:27:20 --> Router Class Initialized
INFO - 2024-06-11 17:27:20 --> Output Class Initialized
INFO - 2024-06-11 17:27:20 --> Security Class Initialized
DEBUG - 2024-06-11 17:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 17:27:20 --> Input Class Initialized
INFO - 2024-06-11 17:27:20 --> Language Class Initialized
INFO - 2024-06-11 17:27:20 --> Language Class Initialized
INFO - 2024-06-11 17:27:20 --> Config Class Initialized
INFO - 2024-06-11 17:27:20 --> Loader Class Initialized
INFO - 2024-06-11 17:27:20 --> Helper loaded: url_helper
INFO - 2024-06-11 17:27:20 --> Helper loaded: file_helper
INFO - 2024-06-11 17:27:20 --> Helper loaded: form_helper
INFO - 2024-06-11 17:27:20 --> Helper loaded: my_helper
INFO - 2024-06-11 17:27:20 --> Config Class Initialized
INFO - 2024-06-11 17:27:20 --> Hooks Class Initialized
DEBUG - 2024-06-11 17:27:20 --> UTF-8 Support Enabled
INFO - 2024-06-11 17:27:20 --> Utf8 Class Initialized
INFO - 2024-06-11 17:27:20 --> URI Class Initialized
INFO - 2024-06-11 17:27:20 --> Router Class Initialized
INFO - 2024-06-11 17:27:20 --> Output Class Initialized
INFO - 2024-06-11 17:27:20 --> Security Class Initialized
DEBUG - 2024-06-11 17:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 17:27:20 --> Input Class Initialized
INFO - 2024-06-11 17:27:20 --> Language Class Initialized
INFO - 2024-06-11 17:27:20 --> Language Class Initialized
INFO - 2024-06-11 17:27:20 --> Config Class Initialized
INFO - 2024-06-11 17:27:20 --> Loader Class Initialized
INFO - 2024-06-11 17:27:20 --> Config Class Initialized
INFO - 2024-06-11 17:27:20 --> Hooks Class Initialized
DEBUG - 2024-06-11 17:27:20 --> UTF-8 Support Enabled
INFO - 2024-06-11 17:27:20 --> Utf8 Class Initialized
INFO - 2024-06-11 17:27:20 --> Config Class Initialized
INFO - 2024-06-11 17:27:20 --> Hooks Class Initialized
DEBUG - 2024-06-11 17:27:20 --> UTF-8 Support Enabled
INFO - 2024-06-11 17:27:20 --> Utf8 Class Initialized
INFO - 2024-06-11 17:27:20 --> URI Class Initialized
INFO - 2024-06-11 17:27:20 --> Router Class Initialized
INFO - 2024-06-11 17:27:20 --> Output Class Initialized
INFO - 2024-06-11 17:27:20 --> Database Driver Class Initialized
INFO - 2024-06-11 17:27:20 --> URI Class Initialized
INFO - 2024-06-11 17:27:20 --> Router Class Initialized
INFO - 2024-06-11 17:27:20 --> Output Class Initialized
INFO - 2024-06-11 17:27:20 --> Security Class Initialized
DEBUG - 2024-06-11 17:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 17:27:20 --> Input Class Initialized
INFO - 2024-06-11 17:27:20 --> Language Class Initialized
INFO - 2024-06-11 17:27:20 --> Language Class Initialized
INFO - 2024-06-11 17:27:20 --> Config Class Initialized
INFO - 2024-06-11 17:27:20 --> Loader Class Initialized
INFO - 2024-06-11 17:27:20 --> Helper loaded: url_helper
INFO - 2024-06-11 17:27:20 --> Helper loaded: file_helper
INFO - 2024-06-11 17:27:20 --> Helper loaded: form_helper
INFO - 2024-06-11 17:27:20 --> Helper loaded: my_helper
INFO - 2024-06-11 17:27:20 --> Database Driver Class Initialized
INFO - 2024-06-11 17:27:20 --> Security Class Initialized
DEBUG - 2024-06-11 17:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 17:27:20 --> Input Class Initialized
INFO - 2024-06-11 17:27:20 --> Language Class Initialized
INFO - 2024-06-11 17:27:20 --> Language Class Initialized
INFO - 2024-06-11 17:27:20 --> Config Class Initialized
INFO - 2024-06-11 17:27:20 --> Loader Class Initialized
INFO - 2024-06-11 17:27:20 --> Helper loaded: url_helper
INFO - 2024-06-11 17:27:20 --> Helper loaded: file_helper
INFO - 2024-06-11 17:27:20 --> Helper loaded: form_helper
INFO - 2024-06-11 17:27:20 --> Helper loaded: my_helper
INFO - 2024-06-11 17:27:20 --> Helper loaded: url_helper
INFO - 2024-06-11 17:27:20 --> Helper loaded: file_helper
INFO - 2024-06-11 17:27:20 --> Helper loaded: form_helper
INFO - 2024-06-11 17:27:20 --> Helper loaded: my_helper
INFO - 2024-06-11 17:27:20 --> Database Driver Class Initialized
INFO - 2024-06-11 17:27:20 --> Database Driver Class Initialized
INFO - 2024-06-11 17:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 17:27:20 --> Controller Class Initialized
INFO - 2024-06-11 17:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 17:27:20 --> Controller Class Initialized
INFO - 2024-06-11 17:27:20 --> Helper loaded: cookie_helper
INFO - 2024-06-11 17:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 17:27:20 --> Controller Class Initialized
INFO - 2024-06-11 17:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 17:27:20 --> Controller Class Initialized
INFO - 2024-06-11 17:27:20 --> Helper loaded: cookie_helper
INFO - 2024-06-11 17:27:20 --> Helper loaded: cookie_helper
INFO - 2024-06-11 17:27:20 --> Helper loaded: cookie_helper
INFO - 2024-06-11 17:27:20 --> Config Class Initialized
INFO - 2024-06-11 17:27:20 --> Hooks Class Initialized
DEBUG - 2024-06-11 17:27:20 --> UTF-8 Support Enabled
INFO - 2024-06-11 17:27:20 --> Utf8 Class Initialized
INFO - 2024-06-11 17:27:20 --> URI Class Initialized
INFO - 2024-06-11 17:27:20 --> Router Class Initialized
INFO - 2024-06-11 17:27:20 --> Output Class Initialized
INFO - 2024-06-11 17:27:20 --> Security Class Initialized
DEBUG - 2024-06-11 17:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 17:27:20 --> Input Class Initialized
INFO - 2024-06-11 17:27:20 --> Language Class Initialized
INFO - 2024-06-11 17:27:20 --> Language Class Initialized
INFO - 2024-06-11 17:27:20 --> Config Class Initialized
INFO - 2024-06-11 17:27:20 --> Loader Class Initialized
INFO - 2024-06-11 17:27:20 --> Helper loaded: url_helper
INFO - 2024-06-11 17:27:20 --> Helper loaded: file_helper
INFO - 2024-06-11 17:27:20 --> Helper loaded: form_helper
INFO - 2024-06-11 17:27:20 --> Helper loaded: my_helper
INFO - 2024-06-11 17:27:20 --> Database Driver Class Initialized
INFO - 2024-06-11 17:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 17:27:20 --> Controller Class Initialized
DEBUG - 2024-06-11 17:27:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-06-11 17:27:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 17:27:21 --> Final output sent to browser
DEBUG - 2024-06-11 17:27:21 --> Total execution time: 0.7408
INFO - 2024-06-11 17:27:21 --> Config Class Initialized
INFO - 2024-06-11 17:27:21 --> Hooks Class Initialized
DEBUG - 2024-06-11 17:27:21 --> UTF-8 Support Enabled
INFO - 2024-06-11 17:27:21 --> Utf8 Class Initialized
INFO - 2024-06-11 17:27:21 --> URI Class Initialized
INFO - 2024-06-11 17:27:21 --> Router Class Initialized
INFO - 2024-06-11 17:27:21 --> Output Class Initialized
INFO - 2024-06-11 17:27:21 --> Security Class Initialized
DEBUG - 2024-06-11 17:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 17:27:21 --> Input Class Initialized
INFO - 2024-06-11 17:27:21 --> Language Class Initialized
INFO - 2024-06-11 17:27:21 --> Language Class Initialized
INFO - 2024-06-11 17:27:21 --> Config Class Initialized
INFO - 2024-06-11 17:27:21 --> Loader Class Initialized
INFO - 2024-06-11 17:27:21 --> Helper loaded: url_helper
INFO - 2024-06-11 17:27:21 --> Helper loaded: file_helper
INFO - 2024-06-11 17:27:21 --> Helper loaded: form_helper
INFO - 2024-06-11 17:27:21 --> Helper loaded: my_helper
INFO - 2024-06-11 17:27:21 --> Database Driver Class Initialized
INFO - 2024-06-11 17:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 17:27:21 --> Controller Class Initialized
DEBUG - 2024-06-11 17:27:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-06-11 17:27:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 17:27:21 --> Final output sent to browser
DEBUG - 2024-06-11 17:27:21 --> Total execution time: 0.2005
INFO - 2024-06-11 17:27:22 --> Config Class Initialized
INFO - 2024-06-11 17:27:22 --> Hooks Class Initialized
DEBUG - 2024-06-11 17:27:22 --> UTF-8 Support Enabled
INFO - 2024-06-11 17:27:22 --> Utf8 Class Initialized
INFO - 2024-06-11 17:27:22 --> URI Class Initialized
INFO - 2024-06-11 17:27:22 --> Router Class Initialized
INFO - 2024-06-11 17:27:22 --> Output Class Initialized
INFO - 2024-06-11 17:27:22 --> Security Class Initialized
DEBUG - 2024-06-11 17:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 17:27:22 --> Input Class Initialized
INFO - 2024-06-11 17:27:22 --> Language Class Initialized
INFO - 2024-06-11 17:27:22 --> Language Class Initialized
INFO - 2024-06-11 17:27:22 --> Config Class Initialized
INFO - 2024-06-11 17:27:22 --> Loader Class Initialized
INFO - 2024-06-11 17:27:22 --> Helper loaded: url_helper
INFO - 2024-06-11 17:27:22 --> Helper loaded: file_helper
INFO - 2024-06-11 17:27:22 --> Helper loaded: form_helper
INFO - 2024-06-11 17:27:22 --> Helper loaded: my_helper
INFO - 2024-06-11 17:27:22 --> Database Driver Class Initialized
INFO - 2024-06-11 17:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 17:27:22 --> Controller Class Initialized
DEBUG - 2024-06-11 17:27:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-06-11 17:27:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 17:27:22 --> Final output sent to browser
DEBUG - 2024-06-11 17:27:22 --> Total execution time: 0.1878
INFO - 2024-06-11 21:38:55 --> Config Class Initialized
INFO - 2024-06-11 21:38:55 --> Hooks Class Initialized
DEBUG - 2024-06-11 21:38:55 --> UTF-8 Support Enabled
INFO - 2024-06-11 21:38:55 --> Utf8 Class Initialized
INFO - 2024-06-11 21:38:55 --> URI Class Initialized
INFO - 2024-06-11 21:38:55 --> Router Class Initialized
INFO - 2024-06-11 21:38:55 --> Output Class Initialized
INFO - 2024-06-11 21:38:55 --> Security Class Initialized
DEBUG - 2024-06-11 21:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 21:38:55 --> Input Class Initialized
INFO - 2024-06-11 21:38:55 --> Language Class Initialized
INFO - 2024-06-11 21:38:55 --> Language Class Initialized
INFO - 2024-06-11 21:38:55 --> Config Class Initialized
INFO - 2024-06-11 21:38:55 --> Loader Class Initialized
INFO - 2024-06-11 21:38:56 --> Helper loaded: url_helper
INFO - 2024-06-11 21:38:56 --> Helper loaded: file_helper
INFO - 2024-06-11 21:38:56 --> Helper loaded: form_helper
INFO - 2024-06-11 21:38:56 --> Helper loaded: my_helper
INFO - 2024-06-11 21:38:56 --> Database Driver Class Initialized
INFO - 2024-06-11 21:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 21:38:56 --> Controller Class Initialized
DEBUG - 2024-06-11 21:38:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-11 21:38:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-11 21:38:56 --> Final output sent to browser
DEBUG - 2024-06-11 21:38:56 --> Total execution time: 0.5587
INFO - 2024-06-11 21:38:56 --> Config Class Initialized
INFO - 2024-06-11 21:38:56 --> Hooks Class Initialized
DEBUG - 2024-06-11 21:38:56 --> UTF-8 Support Enabled
INFO - 2024-06-11 21:38:56 --> Utf8 Class Initialized
INFO - 2024-06-11 21:38:56 --> URI Class Initialized
INFO - 2024-06-11 21:38:56 --> Router Class Initialized
INFO - 2024-06-11 21:38:56 --> Output Class Initialized
INFO - 2024-06-11 21:38:56 --> Security Class Initialized
DEBUG - 2024-06-11 21:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-11 21:38:56 --> Input Class Initialized
INFO - 2024-06-11 21:38:56 --> Language Class Initialized
INFO - 2024-06-11 21:38:56 --> Language Class Initialized
INFO - 2024-06-11 21:38:56 --> Config Class Initialized
INFO - 2024-06-11 21:38:56 --> Loader Class Initialized
INFO - 2024-06-11 21:38:56 --> Helper loaded: url_helper
INFO - 2024-06-11 21:38:56 --> Helper loaded: file_helper
INFO - 2024-06-11 21:38:56 --> Helper loaded: form_helper
INFO - 2024-06-11 21:38:56 --> Helper loaded: my_helper
INFO - 2024-06-11 21:38:57 --> Database Driver Class Initialized
INFO - 2024-06-11 21:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-11 21:38:57 --> Controller Class Initialized
