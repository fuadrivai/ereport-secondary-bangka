<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-24 08:49:46 --> Config Class Initialized
INFO - 2024-10-24 08:49:46 --> Hooks Class Initialized
DEBUG - 2024-10-24 08:49:46 --> UTF-8 Support Enabled
INFO - 2024-10-24 08:49:46 --> Utf8 Class Initialized
INFO - 2024-10-24 08:49:46 --> URI Class Initialized
INFO - 2024-10-24 08:49:46 --> Router Class Initialized
INFO - 2024-10-24 08:49:46 --> Output Class Initialized
INFO - 2024-10-24 08:49:46 --> Security Class Initialized
DEBUG - 2024-10-24 08:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 08:49:46 --> Input Class Initialized
INFO - 2024-10-24 08:49:46 --> Language Class Initialized
INFO - 2024-10-24 08:49:46 --> Language Class Initialized
INFO - 2024-10-24 08:49:46 --> Config Class Initialized
INFO - 2024-10-24 08:49:46 --> Loader Class Initialized
INFO - 2024-10-24 08:49:46 --> Helper loaded: url_helper
INFO - 2024-10-24 08:49:46 --> Helper loaded: file_helper
INFO - 2024-10-24 08:49:46 --> Helper loaded: form_helper
INFO - 2024-10-24 08:49:46 --> Helper loaded: my_helper
INFO - 2024-10-24 08:49:46 --> Database Driver Class Initialized
INFO - 2024-10-24 08:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 08:49:46 --> Controller Class Initialized
DEBUG - 2024-10-24 08:49:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-24 08:49:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 08:49:46 --> Final output sent to browser
DEBUG - 2024-10-24 08:49:46 --> Total execution time: 0.0643
INFO - 2024-10-24 08:49:46 --> Config Class Initialized
INFO - 2024-10-24 08:49:46 --> Hooks Class Initialized
DEBUG - 2024-10-24 08:49:46 --> UTF-8 Support Enabled
INFO - 2024-10-24 08:49:46 --> Utf8 Class Initialized
INFO - 2024-10-24 08:49:46 --> URI Class Initialized
INFO - 2024-10-24 08:49:46 --> Router Class Initialized
INFO - 2024-10-24 08:49:46 --> Output Class Initialized
INFO - 2024-10-24 08:49:46 --> Security Class Initialized
DEBUG - 2024-10-24 08:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 08:49:46 --> Input Class Initialized
INFO - 2024-10-24 08:49:46 --> Language Class Initialized
INFO - 2024-10-24 08:49:46 --> Language Class Initialized
INFO - 2024-10-24 08:49:46 --> Config Class Initialized
INFO - 2024-10-24 08:49:46 --> Loader Class Initialized
INFO - 2024-10-24 08:49:46 --> Helper loaded: url_helper
INFO - 2024-10-24 08:49:46 --> Helper loaded: file_helper
INFO - 2024-10-24 08:49:46 --> Helper loaded: form_helper
INFO - 2024-10-24 08:49:46 --> Helper loaded: my_helper
INFO - 2024-10-24 08:49:46 --> Database Driver Class Initialized
INFO - 2024-10-24 08:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 08:49:46 --> Controller Class Initialized
DEBUG - 2024-10-24 08:49:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-24 08:49:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 08:49:46 --> Final output sent to browser
DEBUG - 2024-10-24 08:49:46 --> Total execution time: 0.0340
INFO - 2024-10-24 08:52:36 --> Config Class Initialized
INFO - 2024-10-24 08:52:36 --> Hooks Class Initialized
DEBUG - 2024-10-24 08:52:36 --> UTF-8 Support Enabled
INFO - 2024-10-24 08:52:36 --> Utf8 Class Initialized
INFO - 2024-10-24 08:52:36 --> URI Class Initialized
INFO - 2024-10-24 08:52:36 --> Router Class Initialized
INFO - 2024-10-24 08:52:36 --> Output Class Initialized
INFO - 2024-10-24 08:52:36 --> Security Class Initialized
DEBUG - 2024-10-24 08:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 08:52:36 --> Input Class Initialized
INFO - 2024-10-24 08:52:36 --> Language Class Initialized
INFO - 2024-10-24 08:52:36 --> Language Class Initialized
INFO - 2024-10-24 08:52:36 --> Config Class Initialized
INFO - 2024-10-24 08:52:36 --> Loader Class Initialized
INFO - 2024-10-24 08:52:36 --> Helper loaded: url_helper
INFO - 2024-10-24 08:52:36 --> Helper loaded: file_helper
INFO - 2024-10-24 08:52:36 --> Helper loaded: form_helper
INFO - 2024-10-24 08:52:36 --> Helper loaded: my_helper
INFO - 2024-10-24 08:52:36 --> Database Driver Class Initialized
INFO - 2024-10-24 08:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 08:52:36 --> Controller Class Initialized
INFO - 2024-10-24 08:52:36 --> Helper loaded: cookie_helper
INFO - 2024-10-24 08:52:36 --> Final output sent to browser
DEBUG - 2024-10-24 08:52:36 --> Total execution time: 0.2941
INFO - 2024-10-24 08:52:36 --> Config Class Initialized
INFO - 2024-10-24 08:52:36 --> Hooks Class Initialized
DEBUG - 2024-10-24 08:52:36 --> UTF-8 Support Enabled
INFO - 2024-10-24 08:52:36 --> Utf8 Class Initialized
INFO - 2024-10-24 08:52:36 --> URI Class Initialized
INFO - 2024-10-24 08:52:36 --> Router Class Initialized
INFO - 2024-10-24 08:52:36 --> Output Class Initialized
INFO - 2024-10-24 08:52:36 --> Security Class Initialized
DEBUG - 2024-10-24 08:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 08:52:36 --> Input Class Initialized
INFO - 2024-10-24 08:52:36 --> Language Class Initialized
INFO - 2024-10-24 08:52:36 --> Language Class Initialized
INFO - 2024-10-24 08:52:36 --> Config Class Initialized
INFO - 2024-10-24 08:52:36 --> Loader Class Initialized
INFO - 2024-10-24 08:52:36 --> Helper loaded: url_helper
INFO - 2024-10-24 08:52:36 --> Helper loaded: file_helper
INFO - 2024-10-24 08:52:36 --> Helper loaded: form_helper
INFO - 2024-10-24 08:52:36 --> Helper loaded: my_helper
INFO - 2024-10-24 08:52:36 --> Database Driver Class Initialized
INFO - 2024-10-24 08:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 08:52:36 --> Controller Class Initialized
DEBUG - 2024-10-24 08:52:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-24 08:52:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 08:52:37 --> Final output sent to browser
DEBUG - 2024-10-24 08:52:37 --> Total execution time: 0.2729
INFO - 2024-10-24 08:52:42 --> Config Class Initialized
INFO - 2024-10-24 08:52:42 --> Hooks Class Initialized
DEBUG - 2024-10-24 08:52:42 --> UTF-8 Support Enabled
INFO - 2024-10-24 08:52:42 --> Utf8 Class Initialized
INFO - 2024-10-24 08:52:42 --> URI Class Initialized
INFO - 2024-10-24 08:52:42 --> Router Class Initialized
INFO - 2024-10-24 08:52:42 --> Output Class Initialized
INFO - 2024-10-24 08:52:42 --> Security Class Initialized
DEBUG - 2024-10-24 08:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 08:52:42 --> Input Class Initialized
INFO - 2024-10-24 08:52:42 --> Language Class Initialized
INFO - 2024-10-24 08:52:42 --> Language Class Initialized
INFO - 2024-10-24 08:52:42 --> Config Class Initialized
INFO - 2024-10-24 08:52:42 --> Loader Class Initialized
INFO - 2024-10-24 08:52:42 --> Helper loaded: url_helper
INFO - 2024-10-24 08:52:42 --> Helper loaded: file_helper
INFO - 2024-10-24 08:52:42 --> Helper loaded: form_helper
INFO - 2024-10-24 08:52:42 --> Helper loaded: my_helper
INFO - 2024-10-24 08:52:42 --> Database Driver Class Initialized
INFO - 2024-10-24 08:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 08:52:42 --> Controller Class Initialized
DEBUG - 2024-10-24 08:52:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-24 08:52:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 08:52:42 --> Final output sent to browser
DEBUG - 2024-10-24 08:52:42 --> Total execution time: 0.0685
INFO - 2024-10-24 08:52:45 --> Config Class Initialized
INFO - 2024-10-24 08:52:45 --> Hooks Class Initialized
DEBUG - 2024-10-24 08:52:45 --> UTF-8 Support Enabled
INFO - 2024-10-24 08:52:45 --> Utf8 Class Initialized
INFO - 2024-10-24 08:52:45 --> URI Class Initialized
INFO - 2024-10-24 08:52:45 --> Router Class Initialized
INFO - 2024-10-24 08:52:45 --> Output Class Initialized
INFO - 2024-10-24 08:52:45 --> Security Class Initialized
DEBUG - 2024-10-24 08:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 08:52:45 --> Input Class Initialized
INFO - 2024-10-24 08:52:45 --> Language Class Initialized
INFO - 2024-10-24 08:52:45 --> Language Class Initialized
INFO - 2024-10-24 08:52:45 --> Config Class Initialized
INFO - 2024-10-24 08:52:45 --> Loader Class Initialized
INFO - 2024-10-24 08:52:45 --> Helper loaded: url_helper
INFO - 2024-10-24 08:52:45 --> Helper loaded: file_helper
INFO - 2024-10-24 08:52:45 --> Helper loaded: form_helper
INFO - 2024-10-24 08:52:45 --> Helper loaded: my_helper
INFO - 2024-10-24 08:52:45 --> Database Driver Class Initialized
INFO - 2024-10-24 08:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 08:52:45 --> Controller Class Initialized
DEBUG - 2024-10-24 08:52:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-24 08:52:48 --> Final output sent to browser
DEBUG - 2024-10-24 08:52:48 --> Total execution time: 3.2935
INFO - 2024-10-24 10:16:11 --> Config Class Initialized
INFO - 2024-10-24 10:16:11 --> Hooks Class Initialized
DEBUG - 2024-10-24 10:16:11 --> UTF-8 Support Enabled
INFO - 2024-10-24 10:16:11 --> Utf8 Class Initialized
INFO - 2024-10-24 10:16:11 --> URI Class Initialized
INFO - 2024-10-24 10:16:11 --> Router Class Initialized
INFO - 2024-10-24 10:16:11 --> Output Class Initialized
INFO - 2024-10-24 10:16:11 --> Security Class Initialized
DEBUG - 2024-10-24 10:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 10:16:11 --> Input Class Initialized
INFO - 2024-10-24 10:16:11 --> Language Class Initialized
INFO - 2024-10-24 10:16:11 --> Language Class Initialized
INFO - 2024-10-24 10:16:11 --> Config Class Initialized
INFO - 2024-10-24 10:16:11 --> Loader Class Initialized
INFO - 2024-10-24 10:16:11 --> Helper loaded: url_helper
INFO - 2024-10-24 10:16:11 --> Helper loaded: file_helper
INFO - 2024-10-24 10:16:11 --> Helper loaded: form_helper
INFO - 2024-10-24 10:16:11 --> Helper loaded: my_helper
INFO - 2024-10-24 10:16:11 --> Database Driver Class Initialized
INFO - 2024-10-24 10:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 10:16:11 --> Controller Class Initialized
DEBUG - 2024-10-24 10:16:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-24 10:16:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 10:16:11 --> Final output sent to browser
DEBUG - 2024-10-24 10:16:11 --> Total execution time: 0.0682
INFO - 2024-10-24 12:52:16 --> Config Class Initialized
INFO - 2024-10-24 12:52:16 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:52:16 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:52:16 --> Utf8 Class Initialized
INFO - 2024-10-24 12:52:16 --> URI Class Initialized
INFO - 2024-10-24 12:52:16 --> Router Class Initialized
INFO - 2024-10-24 12:52:16 --> Output Class Initialized
INFO - 2024-10-24 12:52:16 --> Security Class Initialized
DEBUG - 2024-10-24 12:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:52:16 --> Input Class Initialized
INFO - 2024-10-24 12:52:16 --> Language Class Initialized
INFO - 2024-10-24 12:52:16 --> Language Class Initialized
INFO - 2024-10-24 12:52:16 --> Config Class Initialized
INFO - 2024-10-24 12:52:16 --> Loader Class Initialized
INFO - 2024-10-24 12:52:16 --> Helper loaded: url_helper
INFO - 2024-10-24 12:52:16 --> Helper loaded: file_helper
INFO - 2024-10-24 12:52:16 --> Helper loaded: form_helper
INFO - 2024-10-24 12:52:16 --> Helper loaded: my_helper
INFO - 2024-10-24 12:52:16 --> Database Driver Class Initialized
INFO - 2024-10-24 12:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:52:16 --> Controller Class Initialized
ERROR - 2024-10-24 12:52:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2392
DEBUG - 2024-10-24 12:52:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-24 12:52:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 12:52:16 --> Final output sent to browser
DEBUG - 2024-10-24 12:52:16 --> Total execution time: 0.0605
INFO - 2024-10-24 12:52:18 --> Config Class Initialized
INFO - 2024-10-24 12:52:18 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:52:18 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:52:18 --> Utf8 Class Initialized
INFO - 2024-10-24 12:52:18 --> URI Class Initialized
INFO - 2024-10-24 12:52:18 --> Router Class Initialized
INFO - 2024-10-24 12:52:18 --> Output Class Initialized
INFO - 2024-10-24 12:52:18 --> Security Class Initialized
DEBUG - 2024-10-24 12:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:52:18 --> Input Class Initialized
INFO - 2024-10-24 12:52:18 --> Language Class Initialized
INFO - 2024-10-24 12:52:18 --> Language Class Initialized
INFO - 2024-10-24 12:52:18 --> Config Class Initialized
INFO - 2024-10-24 12:52:18 --> Loader Class Initialized
INFO - 2024-10-24 12:52:18 --> Helper loaded: url_helper
INFO - 2024-10-24 12:52:18 --> Helper loaded: file_helper
INFO - 2024-10-24 12:52:18 --> Helper loaded: form_helper
INFO - 2024-10-24 12:52:18 --> Helper loaded: my_helper
INFO - 2024-10-24 12:52:18 --> Database Driver Class Initialized
INFO - 2024-10-24 12:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:52:18 --> Controller Class Initialized
ERROR - 2024-10-24 12:52:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2392
DEBUG - 2024-10-24 12:52:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-24 12:52:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 12:52:18 --> Final output sent to browser
DEBUG - 2024-10-24 12:52:18 --> Total execution time: 0.0550
INFO - 2024-10-24 12:52:19 --> Config Class Initialized
INFO - 2024-10-24 12:52:19 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:52:19 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:52:19 --> Utf8 Class Initialized
INFO - 2024-10-24 12:52:19 --> URI Class Initialized
INFO - 2024-10-24 12:52:19 --> Router Class Initialized
INFO - 2024-10-24 12:52:19 --> Output Class Initialized
INFO - 2024-10-24 12:52:19 --> Security Class Initialized
DEBUG - 2024-10-24 12:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:52:19 --> Input Class Initialized
INFO - 2024-10-24 12:52:19 --> Language Class Initialized
INFO - 2024-10-24 12:52:19 --> Language Class Initialized
INFO - 2024-10-24 12:52:19 --> Config Class Initialized
INFO - 2024-10-24 12:52:19 --> Loader Class Initialized
INFO - 2024-10-24 12:52:19 --> Helper loaded: url_helper
INFO - 2024-10-24 12:52:19 --> Helper loaded: file_helper
INFO - 2024-10-24 12:52:19 --> Helper loaded: form_helper
INFO - 2024-10-24 12:52:19 --> Helper loaded: my_helper
INFO - 2024-10-24 12:52:19 --> Database Driver Class Initialized
INFO - 2024-10-24 12:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:52:19 --> Controller Class Initialized
ERROR - 2024-10-24 12:52:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2392
DEBUG - 2024-10-24 12:52:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-24 12:52:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 12:52:19 --> Final output sent to browser
DEBUG - 2024-10-24 12:52:19 --> Total execution time: 0.0466
INFO - 2024-10-24 13:53:17 --> Config Class Initialized
INFO - 2024-10-24 13:53:17 --> Hooks Class Initialized
DEBUG - 2024-10-24 13:53:17 --> UTF-8 Support Enabled
INFO - 2024-10-24 13:53:17 --> Utf8 Class Initialized
INFO - 2024-10-24 13:53:17 --> URI Class Initialized
INFO - 2024-10-24 13:53:17 --> Router Class Initialized
INFO - 2024-10-24 13:53:17 --> Output Class Initialized
INFO - 2024-10-24 13:53:17 --> Security Class Initialized
DEBUG - 2024-10-24 13:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 13:53:17 --> Input Class Initialized
INFO - 2024-10-24 13:53:17 --> Language Class Initialized
INFO - 2024-10-24 13:53:17 --> Language Class Initialized
INFO - 2024-10-24 13:53:17 --> Config Class Initialized
INFO - 2024-10-24 13:53:17 --> Loader Class Initialized
INFO - 2024-10-24 13:53:17 --> Helper loaded: url_helper
INFO - 2024-10-24 13:53:17 --> Helper loaded: file_helper
INFO - 2024-10-24 13:53:17 --> Helper loaded: form_helper
INFO - 2024-10-24 13:53:17 --> Helper loaded: my_helper
INFO - 2024-10-24 13:53:17 --> Database Driver Class Initialized
INFO - 2024-10-24 13:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 13:53:17 --> Controller Class Initialized
DEBUG - 2024-10-24 13:53:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-24 13:53:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 13:53:17 --> Final output sent to browser
DEBUG - 2024-10-24 13:53:17 --> Total execution time: 0.0590
INFO - 2024-10-24 13:57:54 --> Config Class Initialized
INFO - 2024-10-24 13:57:54 --> Hooks Class Initialized
DEBUG - 2024-10-24 13:57:54 --> UTF-8 Support Enabled
INFO - 2024-10-24 13:57:54 --> Utf8 Class Initialized
INFO - 2024-10-24 13:57:54 --> URI Class Initialized
INFO - 2024-10-24 13:57:54 --> Router Class Initialized
INFO - 2024-10-24 13:57:54 --> Output Class Initialized
INFO - 2024-10-24 13:57:54 --> Security Class Initialized
DEBUG - 2024-10-24 13:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 13:57:54 --> Input Class Initialized
INFO - 2024-10-24 13:57:54 --> Language Class Initialized
INFO - 2024-10-24 13:57:54 --> Language Class Initialized
INFO - 2024-10-24 13:57:54 --> Config Class Initialized
INFO - 2024-10-24 13:57:54 --> Loader Class Initialized
INFO - 2024-10-24 13:57:54 --> Helper loaded: url_helper
INFO - 2024-10-24 13:57:54 --> Helper loaded: file_helper
INFO - 2024-10-24 13:57:54 --> Helper loaded: form_helper
INFO - 2024-10-24 13:57:54 --> Helper loaded: my_helper
INFO - 2024-10-24 13:57:54 --> Database Driver Class Initialized
INFO - 2024-10-24 13:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 13:57:55 --> Controller Class Initialized
DEBUG - 2024-10-24 13:57:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-24 13:57:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 13:57:55 --> Final output sent to browser
DEBUG - 2024-10-24 13:57:55 --> Total execution time: 0.0322
INFO - 2024-10-24 13:57:57 --> Config Class Initialized
INFO - 2024-10-24 13:57:57 --> Hooks Class Initialized
DEBUG - 2024-10-24 13:57:57 --> UTF-8 Support Enabled
INFO - 2024-10-24 13:57:57 --> Utf8 Class Initialized
INFO - 2024-10-24 13:57:57 --> URI Class Initialized
INFO - 2024-10-24 13:57:57 --> Router Class Initialized
INFO - 2024-10-24 13:57:57 --> Output Class Initialized
INFO - 2024-10-24 13:57:57 --> Security Class Initialized
DEBUG - 2024-10-24 13:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 13:57:57 --> Input Class Initialized
INFO - 2024-10-24 13:57:57 --> Language Class Initialized
INFO - 2024-10-24 13:57:57 --> Language Class Initialized
INFO - 2024-10-24 13:57:57 --> Config Class Initialized
INFO - 2024-10-24 13:57:57 --> Loader Class Initialized
INFO - 2024-10-24 13:57:57 --> Helper loaded: url_helper
INFO - 2024-10-24 13:57:57 --> Helper loaded: file_helper
INFO - 2024-10-24 13:57:57 --> Helper loaded: form_helper
INFO - 2024-10-24 13:57:57 --> Helper loaded: my_helper
INFO - 2024-10-24 13:57:57 --> Database Driver Class Initialized
INFO - 2024-10-24 13:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 13:57:57 --> Controller Class Initialized
INFO - 2024-10-24 13:57:57 --> Helper loaded: cookie_helper
INFO - 2024-10-24 13:57:57 --> Final output sent to browser
DEBUG - 2024-10-24 13:57:57 --> Total execution time: 0.0878
INFO - 2024-10-24 13:57:58 --> Config Class Initialized
INFO - 2024-10-24 13:57:58 --> Hooks Class Initialized
DEBUG - 2024-10-24 13:57:58 --> UTF-8 Support Enabled
INFO - 2024-10-24 13:57:58 --> Utf8 Class Initialized
INFO - 2024-10-24 13:57:58 --> URI Class Initialized
INFO - 2024-10-24 13:57:58 --> Router Class Initialized
INFO - 2024-10-24 13:57:58 --> Output Class Initialized
INFO - 2024-10-24 13:57:58 --> Security Class Initialized
DEBUG - 2024-10-24 13:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 13:57:58 --> Input Class Initialized
INFO - 2024-10-24 13:57:58 --> Language Class Initialized
INFO - 2024-10-24 13:57:58 --> Language Class Initialized
INFO - 2024-10-24 13:57:58 --> Config Class Initialized
INFO - 2024-10-24 13:57:58 --> Loader Class Initialized
INFO - 2024-10-24 13:57:58 --> Helper loaded: url_helper
INFO - 2024-10-24 13:57:58 --> Helper loaded: file_helper
INFO - 2024-10-24 13:57:58 --> Helper loaded: form_helper
INFO - 2024-10-24 13:57:58 --> Helper loaded: my_helper
INFO - 2024-10-24 13:57:58 --> Database Driver Class Initialized
INFO - 2024-10-24 13:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 13:57:58 --> Controller Class Initialized
DEBUG - 2024-10-24 13:57:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-24 13:57:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 13:57:58 --> Final output sent to browser
DEBUG - 2024-10-24 13:57:58 --> Total execution time: 0.1436
INFO - 2024-10-24 13:58:04 --> Config Class Initialized
INFO - 2024-10-24 13:58:04 --> Hooks Class Initialized
DEBUG - 2024-10-24 13:58:04 --> UTF-8 Support Enabled
INFO - 2024-10-24 13:58:04 --> Utf8 Class Initialized
INFO - 2024-10-24 13:58:04 --> URI Class Initialized
INFO - 2024-10-24 13:58:04 --> Router Class Initialized
INFO - 2024-10-24 13:58:04 --> Output Class Initialized
INFO - 2024-10-24 13:58:04 --> Security Class Initialized
DEBUG - 2024-10-24 13:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 13:58:04 --> Input Class Initialized
INFO - 2024-10-24 13:58:04 --> Language Class Initialized
INFO - 2024-10-24 13:58:04 --> Language Class Initialized
INFO - 2024-10-24 13:58:04 --> Config Class Initialized
INFO - 2024-10-24 13:58:04 --> Loader Class Initialized
INFO - 2024-10-24 13:58:04 --> Helper loaded: url_helper
INFO - 2024-10-24 13:58:04 --> Helper loaded: file_helper
INFO - 2024-10-24 13:58:04 --> Helper loaded: form_helper
INFO - 2024-10-24 13:58:04 --> Helper loaded: my_helper
INFO - 2024-10-24 13:58:04 --> Database Driver Class Initialized
INFO - 2024-10-24 13:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 13:58:04 --> Controller Class Initialized
DEBUG - 2024-10-24 13:58:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-24 13:58:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 13:58:04 --> Final output sent to browser
DEBUG - 2024-10-24 13:58:04 --> Total execution time: 0.0558
INFO - 2024-10-24 14:04:55 --> Config Class Initialized
INFO - 2024-10-24 14:04:55 --> Hooks Class Initialized
DEBUG - 2024-10-24 14:04:55 --> UTF-8 Support Enabled
INFO - 2024-10-24 14:04:55 --> Utf8 Class Initialized
INFO - 2024-10-24 14:04:55 --> URI Class Initialized
INFO - 2024-10-24 14:04:55 --> Router Class Initialized
INFO - 2024-10-24 14:04:55 --> Output Class Initialized
INFO - 2024-10-24 14:04:55 --> Security Class Initialized
DEBUG - 2024-10-24 14:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 14:04:55 --> Input Class Initialized
INFO - 2024-10-24 14:04:55 --> Language Class Initialized
INFO - 2024-10-24 14:04:55 --> Language Class Initialized
INFO - 2024-10-24 14:04:55 --> Config Class Initialized
INFO - 2024-10-24 14:04:55 --> Loader Class Initialized
INFO - 2024-10-24 14:04:55 --> Helper loaded: url_helper
INFO - 2024-10-24 14:04:55 --> Helper loaded: file_helper
INFO - 2024-10-24 14:04:55 --> Helper loaded: form_helper
INFO - 2024-10-24 14:04:55 --> Helper loaded: my_helper
INFO - 2024-10-24 14:04:55 --> Database Driver Class Initialized
INFO - 2024-10-24 14:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 14:04:55 --> Controller Class Initialized
DEBUG - 2024-10-24 14:04:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-24 14:04:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 14:04:55 --> Final output sent to browser
DEBUG - 2024-10-24 14:04:55 --> Total execution time: 0.0439
INFO - 2024-10-24 14:39:57 --> Config Class Initialized
INFO - 2024-10-24 14:39:57 --> Hooks Class Initialized
DEBUG - 2024-10-24 14:39:57 --> UTF-8 Support Enabled
INFO - 2024-10-24 14:39:57 --> Utf8 Class Initialized
INFO - 2024-10-24 14:39:57 --> URI Class Initialized
INFO - 2024-10-24 14:39:57 --> Router Class Initialized
INFO - 2024-10-24 14:39:57 --> Output Class Initialized
INFO - 2024-10-24 14:39:57 --> Security Class Initialized
DEBUG - 2024-10-24 14:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 14:39:57 --> Input Class Initialized
INFO - 2024-10-24 14:39:57 --> Language Class Initialized
INFO - 2024-10-24 14:39:57 --> Language Class Initialized
INFO - 2024-10-24 14:39:57 --> Config Class Initialized
INFO - 2024-10-24 14:39:57 --> Loader Class Initialized
INFO - 2024-10-24 14:39:57 --> Helper loaded: url_helper
INFO - 2024-10-24 14:39:57 --> Helper loaded: file_helper
INFO - 2024-10-24 14:39:57 --> Helper loaded: form_helper
INFO - 2024-10-24 14:39:57 --> Helper loaded: my_helper
INFO - 2024-10-24 14:39:57 --> Database Driver Class Initialized
INFO - 2024-10-24 14:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 14:39:57 --> Controller Class Initialized
DEBUG - 2024-10-24 14:39:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-24 14:39:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 14:39:57 --> Final output sent to browser
DEBUG - 2024-10-24 14:39:57 --> Total execution time: 0.1535
INFO - 2024-10-24 14:54:23 --> Config Class Initialized
INFO - 2024-10-24 14:54:23 --> Hooks Class Initialized
DEBUG - 2024-10-24 14:54:23 --> UTF-8 Support Enabled
INFO - 2024-10-24 14:54:23 --> Utf8 Class Initialized
INFO - 2024-10-24 14:54:23 --> URI Class Initialized
INFO - 2024-10-24 14:54:24 --> Router Class Initialized
INFO - 2024-10-24 14:54:24 --> Output Class Initialized
INFO - 2024-10-24 14:54:24 --> Security Class Initialized
DEBUG - 2024-10-24 14:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 14:54:24 --> Input Class Initialized
INFO - 2024-10-24 14:54:24 --> Language Class Initialized
INFO - 2024-10-24 14:54:24 --> Language Class Initialized
INFO - 2024-10-24 14:54:24 --> Config Class Initialized
INFO - 2024-10-24 14:54:24 --> Loader Class Initialized
INFO - 2024-10-24 14:54:24 --> Helper loaded: url_helper
INFO - 2024-10-24 14:54:24 --> Helper loaded: file_helper
INFO - 2024-10-24 14:54:24 --> Helper loaded: form_helper
INFO - 2024-10-24 14:54:24 --> Helper loaded: my_helper
INFO - 2024-10-24 14:54:24 --> Database Driver Class Initialized
INFO - 2024-10-24 14:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 14:54:24 --> Controller Class Initialized
INFO - 2024-10-24 14:54:24 --> Final output sent to browser
DEBUG - 2024-10-24 14:54:24 --> Total execution time: 0.7331
INFO - 2024-10-24 14:54:29 --> Config Class Initialized
INFO - 2024-10-24 14:54:29 --> Hooks Class Initialized
DEBUG - 2024-10-24 14:54:29 --> UTF-8 Support Enabled
INFO - 2024-10-24 14:54:29 --> Utf8 Class Initialized
INFO - 2024-10-24 14:54:29 --> URI Class Initialized
INFO - 2024-10-24 14:54:29 --> Router Class Initialized
INFO - 2024-10-24 14:54:29 --> Output Class Initialized
INFO - 2024-10-24 14:54:29 --> Security Class Initialized
DEBUG - 2024-10-24 14:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 14:54:29 --> Input Class Initialized
INFO - 2024-10-24 14:54:29 --> Language Class Initialized
INFO - 2024-10-24 14:54:29 --> Language Class Initialized
INFO - 2024-10-24 14:54:29 --> Config Class Initialized
INFO - 2024-10-24 14:54:29 --> Loader Class Initialized
INFO - 2024-10-24 14:54:29 --> Helper loaded: url_helper
INFO - 2024-10-24 14:54:29 --> Helper loaded: file_helper
INFO - 2024-10-24 14:54:29 --> Helper loaded: form_helper
INFO - 2024-10-24 14:54:29 --> Helper loaded: my_helper
INFO - 2024-10-24 14:54:29 --> Database Driver Class Initialized
INFO - 2024-10-24 14:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 14:54:29 --> Controller Class Initialized
INFO - 2024-10-24 14:54:29 --> Helper loaded: cookie_helper
INFO - 2024-10-24 14:54:29 --> Final output sent to browser
DEBUG - 2024-10-24 14:54:29 --> Total execution time: 0.0863
INFO - 2024-10-24 14:54:30 --> Config Class Initialized
INFO - 2024-10-24 14:54:30 --> Hooks Class Initialized
DEBUG - 2024-10-24 14:54:30 --> UTF-8 Support Enabled
INFO - 2024-10-24 14:54:30 --> Utf8 Class Initialized
INFO - 2024-10-24 14:54:30 --> URI Class Initialized
INFO - 2024-10-24 14:54:30 --> Router Class Initialized
INFO - 2024-10-24 14:54:30 --> Output Class Initialized
INFO - 2024-10-24 14:54:30 --> Security Class Initialized
DEBUG - 2024-10-24 14:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 14:54:30 --> Input Class Initialized
INFO - 2024-10-24 14:54:30 --> Language Class Initialized
INFO - 2024-10-24 14:54:30 --> Language Class Initialized
INFO - 2024-10-24 14:54:30 --> Config Class Initialized
INFO - 2024-10-24 14:54:30 --> Loader Class Initialized
INFO - 2024-10-24 14:54:30 --> Helper loaded: url_helper
INFO - 2024-10-24 14:54:30 --> Helper loaded: file_helper
INFO - 2024-10-24 14:54:30 --> Helper loaded: form_helper
INFO - 2024-10-24 14:54:30 --> Helper loaded: my_helper
INFO - 2024-10-24 14:54:30 --> Database Driver Class Initialized
INFO - 2024-10-24 14:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 14:54:30 --> Controller Class Initialized
DEBUG - 2024-10-24 14:54:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-10-24 14:54:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 14:54:30 --> Final output sent to browser
DEBUG - 2024-10-24 14:54:30 --> Total execution time: 0.0570
INFO - 2024-10-24 14:54:36 --> Config Class Initialized
INFO - 2024-10-24 14:54:36 --> Hooks Class Initialized
DEBUG - 2024-10-24 14:54:36 --> UTF-8 Support Enabled
INFO - 2024-10-24 14:54:36 --> Utf8 Class Initialized
INFO - 2024-10-24 14:54:36 --> URI Class Initialized
INFO - 2024-10-24 14:54:36 --> Router Class Initialized
INFO - 2024-10-24 14:54:36 --> Output Class Initialized
INFO - 2024-10-24 14:54:36 --> Security Class Initialized
DEBUG - 2024-10-24 14:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 14:54:36 --> Input Class Initialized
INFO - 2024-10-24 14:54:36 --> Language Class Initialized
INFO - 2024-10-24 14:54:36 --> Language Class Initialized
INFO - 2024-10-24 14:54:36 --> Config Class Initialized
INFO - 2024-10-24 14:54:36 --> Loader Class Initialized
INFO - 2024-10-24 14:54:36 --> Helper loaded: url_helper
INFO - 2024-10-24 14:54:36 --> Helper loaded: file_helper
INFO - 2024-10-24 14:54:36 --> Helper loaded: form_helper
INFO - 2024-10-24 14:54:36 --> Helper loaded: my_helper
INFO - 2024-10-24 14:54:36 --> Database Driver Class Initialized
INFO - 2024-10-24 14:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 14:54:36 --> Controller Class Initialized
DEBUG - 2024-10-24 14:54:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-10-24 14:54:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 14:54:36 --> Final output sent to browser
DEBUG - 2024-10-24 14:54:36 --> Total execution time: 0.0372
INFO - 2024-10-24 14:54:37 --> Config Class Initialized
INFO - 2024-10-24 14:54:37 --> Hooks Class Initialized
DEBUG - 2024-10-24 14:54:37 --> UTF-8 Support Enabled
INFO - 2024-10-24 14:54:37 --> Utf8 Class Initialized
INFO - 2024-10-24 14:54:37 --> URI Class Initialized
INFO - 2024-10-24 14:54:37 --> Router Class Initialized
INFO - 2024-10-24 14:54:37 --> Output Class Initialized
INFO - 2024-10-24 14:54:37 --> Security Class Initialized
DEBUG - 2024-10-24 14:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 14:54:37 --> Input Class Initialized
INFO - 2024-10-24 14:54:37 --> Language Class Initialized
ERROR - 2024-10-24 14:54:37 --> 404 Page Not Found: /index
INFO - 2024-10-24 14:54:37 --> Config Class Initialized
INFO - 2024-10-24 14:54:37 --> Hooks Class Initialized
DEBUG - 2024-10-24 14:54:37 --> UTF-8 Support Enabled
INFO - 2024-10-24 14:54:37 --> Utf8 Class Initialized
INFO - 2024-10-24 14:54:37 --> URI Class Initialized
INFO - 2024-10-24 14:54:37 --> Router Class Initialized
INFO - 2024-10-24 14:54:37 --> Output Class Initialized
INFO - 2024-10-24 14:54:37 --> Security Class Initialized
DEBUG - 2024-10-24 14:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 14:54:37 --> Input Class Initialized
INFO - 2024-10-24 14:54:37 --> Language Class Initialized
INFO - 2024-10-24 14:54:37 --> Language Class Initialized
INFO - 2024-10-24 14:54:37 --> Config Class Initialized
INFO - 2024-10-24 14:54:37 --> Loader Class Initialized
INFO - 2024-10-24 14:54:37 --> Helper loaded: url_helper
INFO - 2024-10-24 14:54:37 --> Helper loaded: file_helper
INFO - 2024-10-24 14:54:37 --> Helper loaded: form_helper
INFO - 2024-10-24 14:54:37 --> Helper loaded: my_helper
INFO - 2024-10-24 14:54:37 --> Database Driver Class Initialized
INFO - 2024-10-24 14:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 14:54:37 --> Controller Class Initialized
INFO - 2024-10-24 14:54:38 --> Config Class Initialized
INFO - 2024-10-24 14:54:38 --> Hooks Class Initialized
DEBUG - 2024-10-24 14:54:38 --> UTF-8 Support Enabled
INFO - 2024-10-24 14:54:38 --> Utf8 Class Initialized
INFO - 2024-10-24 14:54:38 --> URI Class Initialized
INFO - 2024-10-24 14:54:38 --> Router Class Initialized
INFO - 2024-10-24 14:54:38 --> Output Class Initialized
INFO - 2024-10-24 14:54:38 --> Security Class Initialized
DEBUG - 2024-10-24 14:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 14:54:38 --> Input Class Initialized
INFO - 2024-10-24 14:54:38 --> Language Class Initialized
INFO - 2024-10-24 14:54:38 --> Language Class Initialized
INFO - 2024-10-24 14:54:38 --> Config Class Initialized
INFO - 2024-10-24 14:54:38 --> Loader Class Initialized
INFO - 2024-10-24 14:54:38 --> Helper loaded: url_helper
INFO - 2024-10-24 14:54:38 --> Helper loaded: file_helper
INFO - 2024-10-24 14:54:38 --> Helper loaded: form_helper
INFO - 2024-10-24 14:54:38 --> Helper loaded: my_helper
INFO - 2024-10-24 14:54:38 --> Database Driver Class Initialized
INFO - 2024-10-24 14:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 14:54:38 --> Controller Class Initialized
DEBUG - 2024-10-24 14:54:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2024-10-24 14:54:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 14:54:38 --> Final output sent to browser
DEBUG - 2024-10-24 14:54:38 --> Total execution time: 0.0745
INFO - 2024-10-24 14:54:38 --> Config Class Initialized
INFO - 2024-10-24 14:54:38 --> Hooks Class Initialized
DEBUG - 2024-10-24 14:54:38 --> UTF-8 Support Enabled
INFO - 2024-10-24 14:54:38 --> Utf8 Class Initialized
INFO - 2024-10-24 14:54:38 --> URI Class Initialized
INFO - 2024-10-24 14:54:38 --> Router Class Initialized
INFO - 2024-10-24 14:54:38 --> Output Class Initialized
INFO - 2024-10-24 14:54:38 --> Security Class Initialized
DEBUG - 2024-10-24 14:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 14:54:38 --> Input Class Initialized
INFO - 2024-10-24 14:54:38 --> Language Class Initialized
ERROR - 2024-10-24 14:54:38 --> 404 Page Not Found: /index
INFO - 2024-10-24 14:54:39 --> Config Class Initialized
INFO - 2024-10-24 14:54:39 --> Hooks Class Initialized
DEBUG - 2024-10-24 14:54:39 --> UTF-8 Support Enabled
INFO - 2024-10-24 14:54:39 --> Utf8 Class Initialized
INFO - 2024-10-24 14:54:39 --> URI Class Initialized
INFO - 2024-10-24 14:54:39 --> Router Class Initialized
INFO - 2024-10-24 14:54:39 --> Output Class Initialized
INFO - 2024-10-24 14:54:39 --> Security Class Initialized
DEBUG - 2024-10-24 14:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 14:54:39 --> Input Class Initialized
INFO - 2024-10-24 14:54:39 --> Language Class Initialized
INFO - 2024-10-24 14:54:39 --> Language Class Initialized
INFO - 2024-10-24 14:54:39 --> Config Class Initialized
INFO - 2024-10-24 14:54:39 --> Loader Class Initialized
INFO - 2024-10-24 14:54:39 --> Helper loaded: url_helper
INFO - 2024-10-24 14:54:39 --> Helper loaded: file_helper
INFO - 2024-10-24 14:54:39 --> Helper loaded: form_helper
INFO - 2024-10-24 14:54:39 --> Helper loaded: my_helper
INFO - 2024-10-24 14:54:39 --> Database Driver Class Initialized
INFO - 2024-10-24 14:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 14:54:39 --> Controller Class Initialized
INFO - 2024-10-24 14:54:43 --> Config Class Initialized
INFO - 2024-10-24 14:54:43 --> Hooks Class Initialized
DEBUG - 2024-10-24 14:54:43 --> UTF-8 Support Enabled
INFO - 2024-10-24 14:54:43 --> Utf8 Class Initialized
INFO - 2024-10-24 14:54:43 --> URI Class Initialized
INFO - 2024-10-24 14:54:43 --> Router Class Initialized
INFO - 2024-10-24 14:54:43 --> Output Class Initialized
INFO - 2024-10-24 14:54:43 --> Security Class Initialized
DEBUG - 2024-10-24 14:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 14:54:43 --> Input Class Initialized
INFO - 2024-10-24 14:54:43 --> Language Class Initialized
INFO - 2024-10-24 14:54:43 --> Language Class Initialized
INFO - 2024-10-24 14:54:43 --> Config Class Initialized
INFO - 2024-10-24 14:54:43 --> Loader Class Initialized
INFO - 2024-10-24 14:54:43 --> Helper loaded: url_helper
INFO - 2024-10-24 14:54:43 --> Helper loaded: file_helper
INFO - 2024-10-24 14:54:43 --> Helper loaded: form_helper
INFO - 2024-10-24 14:54:43 --> Helper loaded: my_helper
INFO - 2024-10-24 14:54:43 --> Database Driver Class Initialized
INFO - 2024-10-24 14:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 14:54:43 --> Controller Class Initialized
DEBUG - 2024-10-24 14:54:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-24 14:54:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 14:54:43 --> Final output sent to browser
DEBUG - 2024-10-24 14:54:43 --> Total execution time: 0.0674
INFO - 2024-10-24 14:54:43 --> Config Class Initialized
INFO - 2024-10-24 14:54:43 --> Hooks Class Initialized
DEBUG - 2024-10-24 14:54:43 --> UTF-8 Support Enabled
INFO - 2024-10-24 14:54:43 --> Utf8 Class Initialized
INFO - 2024-10-24 14:54:43 --> URI Class Initialized
INFO - 2024-10-24 14:54:43 --> Router Class Initialized
INFO - 2024-10-24 14:54:43 --> Output Class Initialized
INFO - 2024-10-24 14:54:43 --> Security Class Initialized
DEBUG - 2024-10-24 14:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 14:54:43 --> Input Class Initialized
INFO - 2024-10-24 14:54:43 --> Language Class Initialized
ERROR - 2024-10-24 14:54:43 --> 404 Page Not Found: /index
INFO - 2024-10-24 14:54:43 --> Config Class Initialized
INFO - 2024-10-24 14:54:43 --> Hooks Class Initialized
DEBUG - 2024-10-24 14:54:43 --> UTF-8 Support Enabled
INFO - 2024-10-24 14:54:43 --> Utf8 Class Initialized
INFO - 2024-10-24 14:54:43 --> URI Class Initialized
INFO - 2024-10-24 14:54:43 --> Router Class Initialized
INFO - 2024-10-24 14:54:43 --> Output Class Initialized
INFO - 2024-10-24 14:54:43 --> Security Class Initialized
DEBUG - 2024-10-24 14:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 14:54:43 --> Input Class Initialized
INFO - 2024-10-24 14:54:43 --> Language Class Initialized
INFO - 2024-10-24 14:54:43 --> Language Class Initialized
INFO - 2024-10-24 14:54:43 --> Config Class Initialized
INFO - 2024-10-24 14:54:43 --> Loader Class Initialized
INFO - 2024-10-24 14:54:43 --> Helper loaded: url_helper
INFO - 2024-10-24 14:54:43 --> Helper loaded: file_helper
INFO - 2024-10-24 14:54:43 --> Helper loaded: form_helper
INFO - 2024-10-24 14:54:43 --> Helper loaded: my_helper
INFO - 2024-10-24 14:54:43 --> Database Driver Class Initialized
INFO - 2024-10-24 14:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 14:54:43 --> Controller Class Initialized
INFO - 2024-10-24 14:54:55 --> Config Class Initialized
INFO - 2024-10-24 14:54:55 --> Hooks Class Initialized
DEBUG - 2024-10-24 14:54:55 --> UTF-8 Support Enabled
INFO - 2024-10-24 14:54:55 --> Utf8 Class Initialized
INFO - 2024-10-24 14:54:55 --> URI Class Initialized
INFO - 2024-10-24 14:54:55 --> Router Class Initialized
INFO - 2024-10-24 14:54:55 --> Output Class Initialized
INFO - 2024-10-24 14:54:55 --> Security Class Initialized
DEBUG - 2024-10-24 14:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 14:54:55 --> Input Class Initialized
INFO - 2024-10-24 14:54:55 --> Language Class Initialized
INFO - 2024-10-24 14:54:55 --> Language Class Initialized
INFO - 2024-10-24 14:54:55 --> Config Class Initialized
INFO - 2024-10-24 14:54:55 --> Loader Class Initialized
INFO - 2024-10-24 14:54:55 --> Helper loaded: url_helper
INFO - 2024-10-24 14:54:55 --> Helper loaded: file_helper
INFO - 2024-10-24 14:54:55 --> Helper loaded: form_helper
INFO - 2024-10-24 14:54:55 --> Helper loaded: my_helper
INFO - 2024-10-24 14:54:55 --> Database Driver Class Initialized
INFO - 2024-10-24 14:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 14:54:55 --> Controller Class Initialized
INFO - 2024-10-24 14:54:56 --> Config Class Initialized
INFO - 2024-10-24 14:54:56 --> Hooks Class Initialized
DEBUG - 2024-10-24 14:54:56 --> UTF-8 Support Enabled
INFO - 2024-10-24 14:54:56 --> Utf8 Class Initialized
INFO - 2024-10-24 14:54:56 --> URI Class Initialized
INFO - 2024-10-24 14:54:56 --> Router Class Initialized
INFO - 2024-10-24 14:54:56 --> Output Class Initialized
INFO - 2024-10-24 14:54:56 --> Security Class Initialized
DEBUG - 2024-10-24 14:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 14:54:56 --> Input Class Initialized
INFO - 2024-10-24 14:54:56 --> Language Class Initialized
INFO - 2024-10-24 14:54:56 --> Language Class Initialized
INFO - 2024-10-24 14:54:56 --> Config Class Initialized
INFO - 2024-10-24 14:54:56 --> Loader Class Initialized
INFO - 2024-10-24 14:54:56 --> Helper loaded: url_helper
INFO - 2024-10-24 14:54:56 --> Helper loaded: file_helper
INFO - 2024-10-24 14:54:56 --> Helper loaded: form_helper
INFO - 2024-10-24 14:54:56 --> Helper loaded: my_helper
INFO - 2024-10-24 14:54:56 --> Database Driver Class Initialized
INFO - 2024-10-24 14:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 14:54:56 --> Controller Class Initialized
INFO - 2024-10-24 14:54:56 --> Config Class Initialized
INFO - 2024-10-24 14:54:56 --> Hooks Class Initialized
DEBUG - 2024-10-24 14:54:56 --> UTF-8 Support Enabled
INFO - 2024-10-24 14:54:56 --> Utf8 Class Initialized
INFO - 2024-10-24 14:54:56 --> URI Class Initialized
INFO - 2024-10-24 14:54:56 --> Router Class Initialized
INFO - 2024-10-24 14:54:56 --> Output Class Initialized
INFO - 2024-10-24 14:54:56 --> Security Class Initialized
DEBUG - 2024-10-24 14:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 14:54:56 --> Input Class Initialized
INFO - 2024-10-24 14:54:56 --> Language Class Initialized
INFO - 2024-10-24 14:54:56 --> Language Class Initialized
INFO - 2024-10-24 14:54:56 --> Config Class Initialized
INFO - 2024-10-24 14:54:56 --> Loader Class Initialized
INFO - 2024-10-24 14:54:56 --> Helper loaded: url_helper
INFO - 2024-10-24 14:54:56 --> Helper loaded: file_helper
INFO - 2024-10-24 14:54:56 --> Helper loaded: form_helper
INFO - 2024-10-24 14:54:56 --> Helper loaded: my_helper
INFO - 2024-10-24 14:54:56 --> Database Driver Class Initialized
INFO - 2024-10-24 14:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 14:54:56 --> Controller Class Initialized
INFO - 2024-10-24 14:55:03 --> Config Class Initialized
INFO - 2024-10-24 14:55:03 --> Hooks Class Initialized
DEBUG - 2024-10-24 14:55:03 --> UTF-8 Support Enabled
INFO - 2024-10-24 14:55:03 --> Utf8 Class Initialized
INFO - 2024-10-24 14:55:03 --> URI Class Initialized
INFO - 2024-10-24 14:55:03 --> Router Class Initialized
INFO - 2024-10-24 14:55:03 --> Output Class Initialized
INFO - 2024-10-24 14:55:03 --> Security Class Initialized
DEBUG - 2024-10-24 14:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 14:55:03 --> Input Class Initialized
INFO - 2024-10-24 14:55:03 --> Language Class Initialized
INFO - 2024-10-24 14:55:03 --> Language Class Initialized
INFO - 2024-10-24 14:55:03 --> Config Class Initialized
INFO - 2024-10-24 14:55:03 --> Loader Class Initialized
INFO - 2024-10-24 14:55:03 --> Helper loaded: url_helper
INFO - 2024-10-24 14:55:03 --> Helper loaded: file_helper
INFO - 2024-10-24 14:55:03 --> Helper loaded: form_helper
INFO - 2024-10-24 14:55:03 --> Helper loaded: my_helper
INFO - 2024-10-24 14:55:03 --> Database Driver Class Initialized
INFO - 2024-10-24 14:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 14:55:03 --> Controller Class Initialized
DEBUG - 2024-10-24 14:55:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-10-24 14:55:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 14:55:03 --> Final output sent to browser
DEBUG - 2024-10-24 14:55:03 --> Total execution time: 0.0527
INFO - 2024-10-24 14:55:04 --> Config Class Initialized
INFO - 2024-10-24 14:55:04 --> Hooks Class Initialized
DEBUG - 2024-10-24 14:55:04 --> UTF-8 Support Enabled
INFO - 2024-10-24 14:55:04 --> Utf8 Class Initialized
INFO - 2024-10-24 14:55:04 --> URI Class Initialized
INFO - 2024-10-24 14:55:04 --> Router Class Initialized
INFO - 2024-10-24 14:55:04 --> Output Class Initialized
INFO - 2024-10-24 14:55:04 --> Security Class Initialized
DEBUG - 2024-10-24 14:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 14:55:04 --> Input Class Initialized
INFO - 2024-10-24 14:55:04 --> Language Class Initialized
ERROR - 2024-10-24 14:55:04 --> 404 Page Not Found: /index
INFO - 2024-10-24 14:55:04 --> Config Class Initialized
INFO - 2024-10-24 14:55:04 --> Hooks Class Initialized
DEBUG - 2024-10-24 14:55:04 --> UTF-8 Support Enabled
INFO - 2024-10-24 14:55:04 --> Utf8 Class Initialized
INFO - 2024-10-24 14:55:04 --> URI Class Initialized
INFO - 2024-10-24 14:55:04 --> Router Class Initialized
INFO - 2024-10-24 14:55:04 --> Output Class Initialized
INFO - 2024-10-24 14:55:04 --> Security Class Initialized
DEBUG - 2024-10-24 14:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 14:55:04 --> Input Class Initialized
INFO - 2024-10-24 14:55:04 --> Language Class Initialized
INFO - 2024-10-24 14:55:04 --> Language Class Initialized
INFO - 2024-10-24 14:55:04 --> Config Class Initialized
INFO - 2024-10-24 14:55:04 --> Loader Class Initialized
INFO - 2024-10-24 14:55:04 --> Helper loaded: url_helper
INFO - 2024-10-24 14:55:04 --> Helper loaded: file_helper
INFO - 2024-10-24 14:55:04 --> Helper loaded: form_helper
INFO - 2024-10-24 14:55:04 --> Helper loaded: my_helper
INFO - 2024-10-24 14:55:04 --> Database Driver Class Initialized
INFO - 2024-10-24 14:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 14:55:04 --> Controller Class Initialized
INFO - 2024-10-24 14:55:10 --> Config Class Initialized
INFO - 2024-10-24 14:55:10 --> Hooks Class Initialized
DEBUG - 2024-10-24 14:55:10 --> UTF-8 Support Enabled
INFO - 2024-10-24 14:55:10 --> Utf8 Class Initialized
INFO - 2024-10-24 14:55:10 --> URI Class Initialized
INFO - 2024-10-24 14:55:10 --> Router Class Initialized
INFO - 2024-10-24 14:55:10 --> Output Class Initialized
INFO - 2024-10-24 14:55:10 --> Security Class Initialized
DEBUG - 2024-10-24 14:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 14:55:10 --> Input Class Initialized
INFO - 2024-10-24 14:55:10 --> Language Class Initialized
INFO - 2024-10-24 14:55:10 --> Language Class Initialized
INFO - 2024-10-24 14:55:10 --> Config Class Initialized
INFO - 2024-10-24 14:55:10 --> Loader Class Initialized
INFO - 2024-10-24 14:55:10 --> Helper loaded: url_helper
INFO - 2024-10-24 14:55:10 --> Helper loaded: file_helper
INFO - 2024-10-24 14:55:10 --> Helper loaded: form_helper
INFO - 2024-10-24 14:55:10 --> Helper loaded: my_helper
INFO - 2024-10-24 14:55:10 --> Database Driver Class Initialized
INFO - 2024-10-24 14:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 14:55:10 --> Controller Class Initialized
DEBUG - 2024-10-24 14:55:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-10-24 14:55:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 14:55:10 --> Final output sent to browser
DEBUG - 2024-10-24 14:55:10 --> Total execution time: 0.0394
INFO - 2024-10-24 14:55:12 --> Config Class Initialized
INFO - 2024-10-24 14:55:12 --> Hooks Class Initialized
DEBUG - 2024-10-24 14:55:12 --> UTF-8 Support Enabled
INFO - 2024-10-24 14:55:12 --> Utf8 Class Initialized
INFO - 2024-10-24 14:55:12 --> URI Class Initialized
INFO - 2024-10-24 14:55:12 --> Router Class Initialized
INFO - 2024-10-24 14:55:12 --> Output Class Initialized
INFO - 2024-10-24 14:55:12 --> Security Class Initialized
DEBUG - 2024-10-24 14:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 14:55:12 --> Input Class Initialized
INFO - 2024-10-24 14:55:12 --> Language Class Initialized
INFO - 2024-10-24 14:55:12 --> Language Class Initialized
INFO - 2024-10-24 14:55:12 --> Config Class Initialized
INFO - 2024-10-24 14:55:12 --> Loader Class Initialized
INFO - 2024-10-24 14:55:12 --> Helper loaded: url_helper
INFO - 2024-10-24 14:55:12 --> Helper loaded: file_helper
INFO - 2024-10-24 14:55:12 --> Helper loaded: form_helper
INFO - 2024-10-24 14:55:12 --> Helper loaded: my_helper
INFO - 2024-10-24 14:55:12 --> Database Driver Class Initialized
INFO - 2024-10-24 14:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 14:55:12 --> Controller Class Initialized
INFO - 2024-10-24 14:55:12 --> Database Driver Class Initialized
INFO - 2024-10-24 14:55:12 --> Config Class Initialized
INFO - 2024-10-24 14:55:12 --> Hooks Class Initialized
DEBUG - 2024-10-24 14:55:12 --> UTF-8 Support Enabled
INFO - 2024-10-24 14:55:12 --> Utf8 Class Initialized
INFO - 2024-10-24 14:55:12 --> URI Class Initialized
INFO - 2024-10-24 14:55:12 --> Router Class Initialized
INFO - 2024-10-24 14:55:12 --> Output Class Initialized
INFO - 2024-10-24 14:55:12 --> Security Class Initialized
DEBUG - 2024-10-24 14:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 14:55:12 --> Input Class Initialized
INFO - 2024-10-24 14:55:12 --> Language Class Initialized
INFO - 2024-10-24 14:55:12 --> Language Class Initialized
INFO - 2024-10-24 14:55:12 --> Config Class Initialized
INFO - 2024-10-24 14:55:12 --> Loader Class Initialized
INFO - 2024-10-24 14:55:12 --> Helper loaded: url_helper
INFO - 2024-10-24 14:55:12 --> Helper loaded: file_helper
INFO - 2024-10-24 14:55:12 --> Helper loaded: form_helper
INFO - 2024-10-24 14:55:12 --> Helper loaded: my_helper
INFO - 2024-10-24 14:55:12 --> Database Driver Class Initialized
INFO - 2024-10-24 14:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 14:55:12 --> Controller Class Initialized
DEBUG - 2024-10-24 14:55:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-10-24 14:55:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 14:55:12 --> Final output sent to browser
DEBUG - 2024-10-24 14:55:12 --> Total execution time: 0.0291
INFO - 2024-10-24 14:57:06 --> Config Class Initialized
INFO - 2024-10-24 14:57:06 --> Hooks Class Initialized
DEBUG - 2024-10-24 14:57:06 --> UTF-8 Support Enabled
INFO - 2024-10-24 14:57:06 --> Utf8 Class Initialized
INFO - 2024-10-24 14:57:06 --> URI Class Initialized
DEBUG - 2024-10-24 14:57:06 --> No URI present. Default controller set.
INFO - 2024-10-24 14:57:06 --> Router Class Initialized
INFO - 2024-10-24 14:57:06 --> Output Class Initialized
INFO - 2024-10-24 14:57:06 --> Security Class Initialized
DEBUG - 2024-10-24 14:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 14:57:06 --> Input Class Initialized
INFO - 2024-10-24 14:57:06 --> Language Class Initialized
INFO - 2024-10-24 14:57:06 --> Language Class Initialized
INFO - 2024-10-24 14:57:06 --> Config Class Initialized
INFO - 2024-10-24 14:57:06 --> Loader Class Initialized
INFO - 2024-10-24 14:57:06 --> Helper loaded: url_helper
INFO - 2024-10-24 14:57:06 --> Helper loaded: file_helper
INFO - 2024-10-24 14:57:06 --> Helper loaded: form_helper
INFO - 2024-10-24 14:57:06 --> Helper loaded: my_helper
INFO - 2024-10-24 14:57:06 --> Database Driver Class Initialized
INFO - 2024-10-24 14:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 14:57:06 --> Controller Class Initialized
DEBUG - 2024-10-24 14:57:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-10-24 14:57:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 14:57:06 --> Final output sent to browser
DEBUG - 2024-10-24 14:57:06 --> Total execution time: 0.1356
INFO - 2024-10-24 14:57:08 --> Config Class Initialized
INFO - 2024-10-24 14:57:08 --> Hooks Class Initialized
DEBUG - 2024-10-24 14:57:08 --> UTF-8 Support Enabled
INFO - 2024-10-24 14:57:08 --> Utf8 Class Initialized
INFO - 2024-10-24 14:57:08 --> URI Class Initialized
INFO - 2024-10-24 14:57:08 --> Router Class Initialized
INFO - 2024-10-24 14:57:08 --> Output Class Initialized
INFO - 2024-10-24 14:57:08 --> Security Class Initialized
DEBUG - 2024-10-24 14:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 14:57:08 --> Input Class Initialized
INFO - 2024-10-24 14:57:08 --> Language Class Initialized
INFO - 2024-10-24 14:57:08 --> Language Class Initialized
INFO - 2024-10-24 14:57:08 --> Config Class Initialized
INFO - 2024-10-24 14:57:08 --> Loader Class Initialized
INFO - 2024-10-24 14:57:08 --> Helper loaded: url_helper
INFO - 2024-10-24 14:57:08 --> Helper loaded: file_helper
INFO - 2024-10-24 14:57:08 --> Helper loaded: form_helper
INFO - 2024-10-24 14:57:08 --> Helper loaded: my_helper
INFO - 2024-10-24 14:57:08 --> Database Driver Class Initialized
INFO - 2024-10-24 14:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 14:57:08 --> Controller Class Initialized
DEBUG - 2024-10-24 14:57:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-10-24 14:57:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 14:57:08 --> Final output sent to browser
DEBUG - 2024-10-24 14:57:08 --> Total execution time: 0.0329
INFO - 2024-10-24 14:57:15 --> Config Class Initialized
INFO - 2024-10-24 14:57:15 --> Hooks Class Initialized
DEBUG - 2024-10-24 14:57:15 --> UTF-8 Support Enabled
INFO - 2024-10-24 14:57:15 --> Utf8 Class Initialized
INFO - 2024-10-24 14:57:15 --> URI Class Initialized
INFO - 2024-10-24 14:57:15 --> Router Class Initialized
INFO - 2024-10-24 14:57:15 --> Output Class Initialized
INFO - 2024-10-24 14:57:15 --> Security Class Initialized
DEBUG - 2024-10-24 14:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 14:57:15 --> Input Class Initialized
INFO - 2024-10-24 14:57:15 --> Language Class Initialized
INFO - 2024-10-24 14:57:15 --> Language Class Initialized
INFO - 2024-10-24 14:57:15 --> Config Class Initialized
INFO - 2024-10-24 14:57:15 --> Loader Class Initialized
INFO - 2024-10-24 14:57:15 --> Helper loaded: url_helper
INFO - 2024-10-24 14:57:15 --> Helper loaded: file_helper
INFO - 2024-10-24 14:57:15 --> Helper loaded: form_helper
INFO - 2024-10-24 14:57:15 --> Helper loaded: my_helper
INFO - 2024-10-24 14:57:15 --> Database Driver Class Initialized
INFO - 2024-10-24 14:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 14:57:15 --> Controller Class Initialized
INFO - 2024-10-24 14:57:15 --> Database Driver Class Initialized
INFO - 2024-10-24 14:57:15 --> Config Class Initialized
INFO - 2024-10-24 14:57:15 --> Hooks Class Initialized
DEBUG - 2024-10-24 14:57:15 --> UTF-8 Support Enabled
INFO - 2024-10-24 14:57:15 --> Utf8 Class Initialized
INFO - 2024-10-24 14:57:15 --> URI Class Initialized
INFO - 2024-10-24 14:57:15 --> Router Class Initialized
INFO - 2024-10-24 14:57:15 --> Output Class Initialized
INFO - 2024-10-24 14:57:15 --> Security Class Initialized
DEBUG - 2024-10-24 14:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 14:57:15 --> Input Class Initialized
INFO - 2024-10-24 14:57:15 --> Language Class Initialized
INFO - 2024-10-24 14:57:15 --> Language Class Initialized
INFO - 2024-10-24 14:57:15 --> Config Class Initialized
INFO - 2024-10-24 14:57:15 --> Loader Class Initialized
INFO - 2024-10-24 14:57:15 --> Helper loaded: url_helper
INFO - 2024-10-24 14:57:15 --> Helper loaded: file_helper
INFO - 2024-10-24 14:57:15 --> Helper loaded: form_helper
INFO - 2024-10-24 14:57:15 --> Helper loaded: my_helper
INFO - 2024-10-24 14:57:16 --> Database Driver Class Initialized
INFO - 2024-10-24 14:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 14:57:16 --> Controller Class Initialized
DEBUG - 2024-10-24 14:57:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-10-24 14:57:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 14:57:16 --> Final output sent to browser
DEBUG - 2024-10-24 14:57:16 --> Total execution time: 0.0574
INFO - 2024-10-24 14:59:55 --> Config Class Initialized
INFO - 2024-10-24 14:59:55 --> Hooks Class Initialized
DEBUG - 2024-10-24 14:59:55 --> UTF-8 Support Enabled
INFO - 2024-10-24 14:59:55 --> Utf8 Class Initialized
INFO - 2024-10-24 14:59:55 --> URI Class Initialized
INFO - 2024-10-24 14:59:55 --> Router Class Initialized
INFO - 2024-10-24 14:59:55 --> Output Class Initialized
INFO - 2024-10-24 14:59:55 --> Security Class Initialized
DEBUG - 2024-10-24 14:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 14:59:55 --> Input Class Initialized
INFO - 2024-10-24 14:59:55 --> Language Class Initialized
INFO - 2024-10-24 14:59:55 --> Language Class Initialized
INFO - 2024-10-24 14:59:55 --> Config Class Initialized
INFO - 2024-10-24 14:59:55 --> Loader Class Initialized
INFO - 2024-10-24 14:59:55 --> Helper loaded: url_helper
INFO - 2024-10-24 14:59:55 --> Helper loaded: file_helper
INFO - 2024-10-24 14:59:55 --> Helper loaded: form_helper
INFO - 2024-10-24 14:59:55 --> Helper loaded: my_helper
INFO - 2024-10-24 14:59:55 --> Database Driver Class Initialized
INFO - 2024-10-24 14:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 14:59:55 --> Controller Class Initialized
DEBUG - 2024-10-24 14:59:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-24 14:59:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 14:59:55 --> Final output sent to browser
DEBUG - 2024-10-24 14:59:55 --> Total execution time: 0.0445
INFO - 2024-10-24 15:00:02 --> Config Class Initialized
INFO - 2024-10-24 15:00:02 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:00:02 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:00:02 --> Utf8 Class Initialized
INFO - 2024-10-24 15:00:02 --> URI Class Initialized
INFO - 2024-10-24 15:00:02 --> Router Class Initialized
INFO - 2024-10-24 15:00:02 --> Output Class Initialized
INFO - 2024-10-24 15:00:02 --> Security Class Initialized
DEBUG - 2024-10-24 15:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:00:02 --> Input Class Initialized
INFO - 2024-10-24 15:00:02 --> Language Class Initialized
INFO - 2024-10-24 15:00:02 --> Language Class Initialized
INFO - 2024-10-24 15:00:02 --> Config Class Initialized
INFO - 2024-10-24 15:00:02 --> Loader Class Initialized
INFO - 2024-10-24 15:00:02 --> Helper loaded: url_helper
INFO - 2024-10-24 15:00:02 --> Helper loaded: file_helper
INFO - 2024-10-24 15:00:02 --> Helper loaded: form_helper
INFO - 2024-10-24 15:00:02 --> Helper loaded: my_helper
INFO - 2024-10-24 15:00:02 --> Database Driver Class Initialized
INFO - 2024-10-24 15:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:00:02 --> Controller Class Initialized
INFO - 2024-10-24 15:00:02 --> Helper loaded: cookie_helper
INFO - 2024-10-24 15:00:02 --> Final output sent to browser
DEBUG - 2024-10-24 15:00:02 --> Total execution time: 0.1132
INFO - 2024-10-24 15:00:02 --> Config Class Initialized
INFO - 2024-10-24 15:00:02 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:00:02 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:00:02 --> Utf8 Class Initialized
INFO - 2024-10-24 15:00:02 --> URI Class Initialized
INFO - 2024-10-24 15:00:02 --> Router Class Initialized
INFO - 2024-10-24 15:00:02 --> Output Class Initialized
INFO - 2024-10-24 15:00:02 --> Security Class Initialized
DEBUG - 2024-10-24 15:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:00:02 --> Input Class Initialized
INFO - 2024-10-24 15:00:02 --> Language Class Initialized
INFO - 2024-10-24 15:00:02 --> Language Class Initialized
INFO - 2024-10-24 15:00:02 --> Config Class Initialized
INFO - 2024-10-24 15:00:02 --> Loader Class Initialized
INFO - 2024-10-24 15:00:02 --> Helper loaded: url_helper
INFO - 2024-10-24 15:00:02 --> Helper loaded: file_helper
INFO - 2024-10-24 15:00:02 --> Helper loaded: form_helper
INFO - 2024-10-24 15:00:02 --> Helper loaded: my_helper
INFO - 2024-10-24 15:00:02 --> Database Driver Class Initialized
INFO - 2024-10-24 15:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:00:02 --> Controller Class Initialized
DEBUG - 2024-10-24 15:00:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-10-24 15:00:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 15:00:02 --> Final output sent to browser
DEBUG - 2024-10-24 15:00:02 --> Total execution time: 0.0600
INFO - 2024-10-24 15:00:04 --> Config Class Initialized
INFO - 2024-10-24 15:00:04 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:00:04 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:00:04 --> Utf8 Class Initialized
INFO - 2024-10-24 15:00:04 --> URI Class Initialized
INFO - 2024-10-24 15:00:04 --> Router Class Initialized
INFO - 2024-10-24 15:00:04 --> Output Class Initialized
INFO - 2024-10-24 15:00:04 --> Security Class Initialized
DEBUG - 2024-10-24 15:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:00:04 --> Input Class Initialized
INFO - 2024-10-24 15:00:04 --> Language Class Initialized
INFO - 2024-10-24 15:00:04 --> Language Class Initialized
INFO - 2024-10-24 15:00:04 --> Config Class Initialized
INFO - 2024-10-24 15:00:04 --> Loader Class Initialized
INFO - 2024-10-24 15:00:04 --> Helper loaded: url_helper
INFO - 2024-10-24 15:00:04 --> Helper loaded: file_helper
INFO - 2024-10-24 15:00:04 --> Helper loaded: form_helper
INFO - 2024-10-24 15:00:04 --> Helper loaded: my_helper
INFO - 2024-10-24 15:00:04 --> Database Driver Class Initialized
INFO - 2024-10-24 15:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:00:04 --> Controller Class Initialized
DEBUG - 2024-10-24 15:00:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2024-10-24 15:00:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 15:00:04 --> Final output sent to browser
DEBUG - 2024-10-24 15:00:04 --> Total execution time: 0.0781
INFO - 2024-10-24 15:00:04 --> Config Class Initialized
INFO - 2024-10-24 15:00:04 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:00:04 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:00:04 --> Utf8 Class Initialized
INFO - 2024-10-24 15:00:04 --> URI Class Initialized
INFO - 2024-10-24 15:00:04 --> Router Class Initialized
INFO - 2024-10-24 15:00:04 --> Output Class Initialized
INFO - 2024-10-24 15:00:04 --> Security Class Initialized
DEBUG - 2024-10-24 15:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:00:04 --> Input Class Initialized
INFO - 2024-10-24 15:00:04 --> Language Class Initialized
ERROR - 2024-10-24 15:00:04 --> 404 Page Not Found: /index
INFO - 2024-10-24 15:00:04 --> Config Class Initialized
INFO - 2024-10-24 15:00:04 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:00:04 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:00:04 --> Utf8 Class Initialized
INFO - 2024-10-24 15:00:04 --> URI Class Initialized
INFO - 2024-10-24 15:00:04 --> Router Class Initialized
INFO - 2024-10-24 15:00:04 --> Output Class Initialized
INFO - 2024-10-24 15:00:04 --> Security Class Initialized
DEBUG - 2024-10-24 15:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:00:04 --> Input Class Initialized
INFO - 2024-10-24 15:00:04 --> Language Class Initialized
INFO - 2024-10-24 15:00:04 --> Language Class Initialized
INFO - 2024-10-24 15:00:04 --> Config Class Initialized
INFO - 2024-10-24 15:00:04 --> Loader Class Initialized
INFO - 2024-10-24 15:00:04 --> Helper loaded: url_helper
INFO - 2024-10-24 15:00:04 --> Helper loaded: file_helper
INFO - 2024-10-24 15:00:04 --> Helper loaded: form_helper
INFO - 2024-10-24 15:00:04 --> Helper loaded: my_helper
INFO - 2024-10-24 15:00:04 --> Database Driver Class Initialized
INFO - 2024-10-24 15:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:00:04 --> Controller Class Initialized
INFO - 2024-10-24 15:00:08 --> Config Class Initialized
INFO - 2024-10-24 15:00:08 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:00:08 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:00:08 --> Utf8 Class Initialized
INFO - 2024-10-24 15:00:08 --> URI Class Initialized
INFO - 2024-10-24 15:00:08 --> Router Class Initialized
INFO - 2024-10-24 15:00:08 --> Output Class Initialized
INFO - 2024-10-24 15:00:08 --> Security Class Initialized
DEBUG - 2024-10-24 15:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:00:08 --> Input Class Initialized
INFO - 2024-10-24 15:00:08 --> Language Class Initialized
INFO - 2024-10-24 15:00:08 --> Language Class Initialized
INFO - 2024-10-24 15:00:08 --> Config Class Initialized
INFO - 2024-10-24 15:00:08 --> Loader Class Initialized
INFO - 2024-10-24 15:00:08 --> Helper loaded: url_helper
INFO - 2024-10-24 15:00:08 --> Helper loaded: file_helper
INFO - 2024-10-24 15:00:08 --> Helper loaded: form_helper
INFO - 2024-10-24 15:00:08 --> Helper loaded: my_helper
INFO - 2024-10-24 15:00:08 --> Database Driver Class Initialized
INFO - 2024-10-24 15:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:00:08 --> Controller Class Initialized
DEBUG - 2024-10-24 15:00:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-10-24 15:00:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 15:00:08 --> Final output sent to browser
DEBUG - 2024-10-24 15:00:08 --> Total execution time: 0.1026
INFO - 2024-10-24 15:00:17 --> Config Class Initialized
INFO - 2024-10-24 15:00:17 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:00:17 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:00:17 --> Utf8 Class Initialized
INFO - 2024-10-24 15:00:17 --> URI Class Initialized
INFO - 2024-10-24 15:00:17 --> Router Class Initialized
INFO - 2024-10-24 15:00:17 --> Output Class Initialized
INFO - 2024-10-24 15:00:17 --> Security Class Initialized
DEBUG - 2024-10-24 15:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:00:17 --> Input Class Initialized
INFO - 2024-10-24 15:00:17 --> Language Class Initialized
INFO - 2024-10-24 15:00:17 --> Language Class Initialized
INFO - 2024-10-24 15:00:17 --> Config Class Initialized
INFO - 2024-10-24 15:00:17 --> Loader Class Initialized
INFO - 2024-10-24 15:00:17 --> Helper loaded: url_helper
INFO - 2024-10-24 15:00:17 --> Helper loaded: file_helper
INFO - 2024-10-24 15:00:17 --> Helper loaded: form_helper
INFO - 2024-10-24 15:00:17 --> Helper loaded: my_helper
INFO - 2024-10-24 15:00:17 --> Database Driver Class Initialized
INFO - 2024-10-24 15:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:00:17 --> Controller Class Initialized
INFO - 2024-10-24 15:00:17 --> Database Driver Class Initialized
INFO - 2024-10-24 15:00:18 --> Config Class Initialized
INFO - 2024-10-24 15:00:18 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:00:18 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:00:18 --> Utf8 Class Initialized
INFO - 2024-10-24 15:00:18 --> URI Class Initialized
INFO - 2024-10-24 15:00:18 --> Router Class Initialized
INFO - 2024-10-24 15:00:18 --> Output Class Initialized
INFO - 2024-10-24 15:00:18 --> Security Class Initialized
DEBUG - 2024-10-24 15:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:00:18 --> Input Class Initialized
INFO - 2024-10-24 15:00:18 --> Language Class Initialized
INFO - 2024-10-24 15:00:18 --> Language Class Initialized
INFO - 2024-10-24 15:00:18 --> Config Class Initialized
INFO - 2024-10-24 15:00:18 --> Loader Class Initialized
INFO - 2024-10-24 15:00:18 --> Helper loaded: url_helper
INFO - 2024-10-24 15:00:18 --> Helper loaded: file_helper
INFO - 2024-10-24 15:00:18 --> Helper loaded: form_helper
INFO - 2024-10-24 15:00:18 --> Helper loaded: my_helper
INFO - 2024-10-24 15:00:18 --> Database Driver Class Initialized
INFO - 2024-10-24 15:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:00:18 --> Controller Class Initialized
DEBUG - 2024-10-24 15:00:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-10-24 15:00:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 15:00:18 --> Final output sent to browser
DEBUG - 2024-10-24 15:00:18 --> Total execution time: 0.0506
INFO - 2024-10-24 15:00:22 --> Config Class Initialized
INFO - 2024-10-24 15:00:22 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:00:22 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:00:22 --> Utf8 Class Initialized
INFO - 2024-10-24 15:00:22 --> URI Class Initialized
INFO - 2024-10-24 15:00:22 --> Router Class Initialized
INFO - 2024-10-24 15:00:22 --> Output Class Initialized
INFO - 2024-10-24 15:00:22 --> Security Class Initialized
DEBUG - 2024-10-24 15:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:00:22 --> Input Class Initialized
INFO - 2024-10-24 15:00:22 --> Language Class Initialized
INFO - 2024-10-24 15:00:22 --> Language Class Initialized
INFO - 2024-10-24 15:00:22 --> Config Class Initialized
INFO - 2024-10-24 15:00:22 --> Loader Class Initialized
INFO - 2024-10-24 15:00:22 --> Helper loaded: url_helper
INFO - 2024-10-24 15:00:22 --> Helper loaded: file_helper
INFO - 2024-10-24 15:00:22 --> Helper loaded: form_helper
INFO - 2024-10-24 15:00:22 --> Helper loaded: my_helper
INFO - 2024-10-24 15:00:22 --> Database Driver Class Initialized
INFO - 2024-10-24 15:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:00:22 --> Controller Class Initialized
DEBUG - 2024-10-24 15:00:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-24 15:00:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 15:00:22 --> Final output sent to browser
DEBUG - 2024-10-24 15:00:22 --> Total execution time: 0.1069
INFO - 2024-10-24 15:00:22 --> Config Class Initialized
INFO - 2024-10-24 15:00:22 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:00:22 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:00:22 --> Utf8 Class Initialized
INFO - 2024-10-24 15:00:22 --> URI Class Initialized
INFO - 2024-10-24 15:00:22 --> Router Class Initialized
INFO - 2024-10-24 15:00:22 --> Output Class Initialized
INFO - 2024-10-24 15:00:22 --> Security Class Initialized
DEBUG - 2024-10-24 15:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:00:22 --> Input Class Initialized
INFO - 2024-10-24 15:00:22 --> Language Class Initialized
ERROR - 2024-10-24 15:00:22 --> 404 Page Not Found: /index
INFO - 2024-10-24 15:00:22 --> Config Class Initialized
INFO - 2024-10-24 15:00:22 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:00:22 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:00:22 --> Utf8 Class Initialized
INFO - 2024-10-24 15:00:22 --> URI Class Initialized
INFO - 2024-10-24 15:00:22 --> Router Class Initialized
INFO - 2024-10-24 15:00:22 --> Output Class Initialized
INFO - 2024-10-24 15:00:22 --> Security Class Initialized
DEBUG - 2024-10-24 15:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:00:22 --> Input Class Initialized
INFO - 2024-10-24 15:00:22 --> Language Class Initialized
INFO - 2024-10-24 15:00:22 --> Language Class Initialized
INFO - 2024-10-24 15:00:22 --> Config Class Initialized
INFO - 2024-10-24 15:00:22 --> Loader Class Initialized
INFO - 2024-10-24 15:00:22 --> Helper loaded: url_helper
INFO - 2024-10-24 15:00:22 --> Helper loaded: file_helper
INFO - 2024-10-24 15:00:22 --> Helper loaded: form_helper
INFO - 2024-10-24 15:00:22 --> Helper loaded: my_helper
INFO - 2024-10-24 15:00:22 --> Database Driver Class Initialized
INFO - 2024-10-24 15:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:00:22 --> Controller Class Initialized
INFO - 2024-10-24 15:00:25 --> Config Class Initialized
INFO - 2024-10-24 15:00:25 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:00:25 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:00:25 --> Utf8 Class Initialized
INFO - 2024-10-24 15:00:25 --> URI Class Initialized
INFO - 2024-10-24 15:00:25 --> Router Class Initialized
INFO - 2024-10-24 15:00:25 --> Output Class Initialized
INFO - 2024-10-24 15:00:25 --> Security Class Initialized
DEBUG - 2024-10-24 15:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:00:25 --> Input Class Initialized
INFO - 2024-10-24 15:00:25 --> Language Class Initialized
INFO - 2024-10-24 15:00:25 --> Language Class Initialized
INFO - 2024-10-24 15:00:25 --> Config Class Initialized
INFO - 2024-10-24 15:00:25 --> Loader Class Initialized
INFO - 2024-10-24 15:00:25 --> Helper loaded: url_helper
INFO - 2024-10-24 15:00:25 --> Helper loaded: file_helper
INFO - 2024-10-24 15:00:25 --> Helper loaded: form_helper
INFO - 2024-10-24 15:00:25 --> Helper loaded: my_helper
INFO - 2024-10-24 15:00:25 --> Database Driver Class Initialized
INFO - 2024-10-24 15:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:00:25 --> Controller Class Initialized
INFO - 2024-10-24 15:00:25 --> Config Class Initialized
INFO - 2024-10-24 15:00:25 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:00:25 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:00:25 --> Utf8 Class Initialized
INFO - 2024-10-24 15:00:25 --> URI Class Initialized
INFO - 2024-10-24 15:00:25 --> Router Class Initialized
INFO - 2024-10-24 15:00:25 --> Output Class Initialized
INFO - 2024-10-24 15:00:25 --> Security Class Initialized
DEBUG - 2024-10-24 15:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:00:25 --> Input Class Initialized
INFO - 2024-10-24 15:00:25 --> Language Class Initialized
INFO - 2024-10-24 15:00:25 --> Language Class Initialized
INFO - 2024-10-24 15:00:25 --> Config Class Initialized
INFO - 2024-10-24 15:00:25 --> Loader Class Initialized
INFO - 2024-10-24 15:00:25 --> Helper loaded: url_helper
INFO - 2024-10-24 15:00:25 --> Helper loaded: file_helper
INFO - 2024-10-24 15:00:25 --> Helper loaded: form_helper
INFO - 2024-10-24 15:00:25 --> Helper loaded: my_helper
INFO - 2024-10-24 15:00:25 --> Database Driver Class Initialized
INFO - 2024-10-24 15:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:00:25 --> Controller Class Initialized
INFO - 2024-10-24 15:00:26 --> Config Class Initialized
INFO - 2024-10-24 15:00:26 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:00:26 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:00:26 --> Utf8 Class Initialized
INFO - 2024-10-24 15:00:26 --> URI Class Initialized
INFO - 2024-10-24 15:00:26 --> Router Class Initialized
INFO - 2024-10-24 15:00:26 --> Output Class Initialized
INFO - 2024-10-24 15:00:26 --> Security Class Initialized
DEBUG - 2024-10-24 15:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:00:26 --> Input Class Initialized
INFO - 2024-10-24 15:00:26 --> Language Class Initialized
INFO - 2024-10-24 15:00:26 --> Language Class Initialized
INFO - 2024-10-24 15:00:26 --> Config Class Initialized
INFO - 2024-10-24 15:00:26 --> Loader Class Initialized
INFO - 2024-10-24 15:00:26 --> Helper loaded: url_helper
INFO - 2024-10-24 15:00:26 --> Helper loaded: file_helper
INFO - 2024-10-24 15:00:26 --> Helper loaded: form_helper
INFO - 2024-10-24 15:00:26 --> Helper loaded: my_helper
INFO - 2024-10-24 15:00:26 --> Database Driver Class Initialized
INFO - 2024-10-24 15:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:00:26 --> Controller Class Initialized
INFO - 2024-10-24 15:01:47 --> Config Class Initialized
INFO - 2024-10-24 15:01:47 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:01:47 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:01:47 --> Utf8 Class Initialized
INFO - 2024-10-24 15:01:47 --> URI Class Initialized
INFO - 2024-10-24 15:01:47 --> Router Class Initialized
INFO - 2024-10-24 15:01:47 --> Output Class Initialized
INFO - 2024-10-24 15:01:47 --> Security Class Initialized
DEBUG - 2024-10-24 15:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:01:47 --> Input Class Initialized
INFO - 2024-10-24 15:01:47 --> Language Class Initialized
INFO - 2024-10-24 15:01:47 --> Language Class Initialized
INFO - 2024-10-24 15:01:47 --> Config Class Initialized
INFO - 2024-10-24 15:01:47 --> Loader Class Initialized
INFO - 2024-10-24 15:01:47 --> Helper loaded: url_helper
INFO - 2024-10-24 15:01:47 --> Helper loaded: file_helper
INFO - 2024-10-24 15:01:47 --> Helper loaded: form_helper
INFO - 2024-10-24 15:01:47 --> Helper loaded: my_helper
INFO - 2024-10-24 15:01:48 --> Database Driver Class Initialized
INFO - 2024-10-24 15:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:01:48 --> Controller Class Initialized
DEBUG - 2024-10-24 15:01:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-24 15:01:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 15:01:48 --> Final output sent to browser
DEBUG - 2024-10-24 15:01:48 --> Total execution time: 0.3793
INFO - 2024-10-24 15:01:56 --> Config Class Initialized
INFO - 2024-10-24 15:01:56 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:01:56 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:01:56 --> Utf8 Class Initialized
INFO - 2024-10-24 15:01:56 --> URI Class Initialized
INFO - 2024-10-24 15:01:56 --> Router Class Initialized
INFO - 2024-10-24 15:01:56 --> Output Class Initialized
INFO - 2024-10-24 15:01:56 --> Security Class Initialized
DEBUG - 2024-10-24 15:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:01:56 --> Input Class Initialized
INFO - 2024-10-24 15:01:56 --> Language Class Initialized
INFO - 2024-10-24 15:01:56 --> Language Class Initialized
INFO - 2024-10-24 15:01:56 --> Config Class Initialized
INFO - 2024-10-24 15:01:56 --> Loader Class Initialized
INFO - 2024-10-24 15:01:56 --> Helper loaded: url_helper
INFO - 2024-10-24 15:01:56 --> Helper loaded: file_helper
INFO - 2024-10-24 15:01:56 --> Helper loaded: form_helper
INFO - 2024-10-24 15:01:56 --> Helper loaded: my_helper
INFO - 2024-10-24 15:01:56 --> Database Driver Class Initialized
INFO - 2024-10-24 15:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:01:56 --> Controller Class Initialized
INFO - 2024-10-24 15:01:56 --> Helper loaded: cookie_helper
INFO - 2024-10-24 15:01:56 --> Final output sent to browser
DEBUG - 2024-10-24 15:01:56 --> Total execution time: 0.0308
INFO - 2024-10-24 15:01:56 --> Config Class Initialized
INFO - 2024-10-24 15:01:56 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:01:56 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:01:56 --> Utf8 Class Initialized
INFO - 2024-10-24 15:01:56 --> URI Class Initialized
INFO - 2024-10-24 15:01:56 --> Router Class Initialized
INFO - 2024-10-24 15:01:56 --> Output Class Initialized
INFO - 2024-10-24 15:01:56 --> Security Class Initialized
DEBUG - 2024-10-24 15:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:01:56 --> Input Class Initialized
INFO - 2024-10-24 15:01:56 --> Language Class Initialized
INFO - 2024-10-24 15:01:56 --> Language Class Initialized
INFO - 2024-10-24 15:01:56 --> Config Class Initialized
INFO - 2024-10-24 15:01:56 --> Loader Class Initialized
INFO - 2024-10-24 15:01:57 --> Helper loaded: url_helper
INFO - 2024-10-24 15:01:57 --> Helper loaded: file_helper
INFO - 2024-10-24 15:01:57 --> Helper loaded: form_helper
INFO - 2024-10-24 15:01:57 --> Helper loaded: my_helper
INFO - 2024-10-24 15:01:57 --> Database Driver Class Initialized
INFO - 2024-10-24 15:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:01:57 --> Controller Class Initialized
DEBUG - 2024-10-24 15:01:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-10-24 15:01:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 15:01:57 --> Final output sent to browser
DEBUG - 2024-10-24 15:01:57 --> Total execution time: 0.0636
INFO - 2024-10-24 15:01:59 --> Config Class Initialized
INFO - 2024-10-24 15:01:59 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:01:59 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:01:59 --> Utf8 Class Initialized
INFO - 2024-10-24 15:01:59 --> URI Class Initialized
INFO - 2024-10-24 15:01:59 --> Router Class Initialized
INFO - 2024-10-24 15:01:59 --> Output Class Initialized
INFO - 2024-10-24 15:01:59 --> Security Class Initialized
DEBUG - 2024-10-24 15:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:01:59 --> Input Class Initialized
INFO - 2024-10-24 15:01:59 --> Language Class Initialized
INFO - 2024-10-24 15:01:59 --> Language Class Initialized
INFO - 2024-10-24 15:01:59 --> Config Class Initialized
INFO - 2024-10-24 15:01:59 --> Loader Class Initialized
INFO - 2024-10-24 15:01:59 --> Helper loaded: url_helper
INFO - 2024-10-24 15:01:59 --> Helper loaded: file_helper
INFO - 2024-10-24 15:01:59 --> Helper loaded: form_helper
INFO - 2024-10-24 15:01:59 --> Helper loaded: my_helper
INFO - 2024-10-24 15:01:59 --> Database Driver Class Initialized
INFO - 2024-10-24 15:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:01:59 --> Controller Class Initialized
DEBUG - 2024-10-24 15:01:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-24 15:01:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 15:01:59 --> Final output sent to browser
DEBUG - 2024-10-24 15:01:59 --> Total execution time: 0.0648
INFO - 2024-10-24 15:01:59 --> Config Class Initialized
INFO - 2024-10-24 15:01:59 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:01:59 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:01:59 --> Utf8 Class Initialized
INFO - 2024-10-24 15:01:59 --> URI Class Initialized
INFO - 2024-10-24 15:01:59 --> Router Class Initialized
INFO - 2024-10-24 15:01:59 --> Output Class Initialized
INFO - 2024-10-24 15:01:59 --> Security Class Initialized
DEBUG - 2024-10-24 15:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:01:59 --> Input Class Initialized
INFO - 2024-10-24 15:01:59 --> Language Class Initialized
ERROR - 2024-10-24 15:01:59 --> 404 Page Not Found: /index
INFO - 2024-10-24 15:02:00 --> Config Class Initialized
INFO - 2024-10-24 15:02:00 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:02:00 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:02:00 --> Utf8 Class Initialized
INFO - 2024-10-24 15:02:00 --> URI Class Initialized
INFO - 2024-10-24 15:02:00 --> Router Class Initialized
INFO - 2024-10-24 15:02:00 --> Output Class Initialized
INFO - 2024-10-24 15:02:00 --> Security Class Initialized
DEBUG - 2024-10-24 15:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:02:00 --> Input Class Initialized
INFO - 2024-10-24 15:02:00 --> Language Class Initialized
INFO - 2024-10-24 15:02:00 --> Language Class Initialized
INFO - 2024-10-24 15:02:00 --> Config Class Initialized
INFO - 2024-10-24 15:02:00 --> Loader Class Initialized
INFO - 2024-10-24 15:02:00 --> Helper loaded: url_helper
INFO - 2024-10-24 15:02:00 --> Helper loaded: file_helper
INFO - 2024-10-24 15:02:00 --> Helper loaded: form_helper
INFO - 2024-10-24 15:02:00 --> Helper loaded: my_helper
INFO - 2024-10-24 15:02:00 --> Database Driver Class Initialized
INFO - 2024-10-24 15:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:02:00 --> Controller Class Initialized
INFO - 2024-10-24 15:02:05 --> Config Class Initialized
INFO - 2024-10-24 15:02:05 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:02:05 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:02:05 --> Utf8 Class Initialized
INFO - 2024-10-24 15:02:05 --> URI Class Initialized
INFO - 2024-10-24 15:02:05 --> Router Class Initialized
INFO - 2024-10-24 15:02:05 --> Output Class Initialized
INFO - 2024-10-24 15:02:05 --> Security Class Initialized
DEBUG - 2024-10-24 15:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:02:05 --> Input Class Initialized
INFO - 2024-10-24 15:02:05 --> Language Class Initialized
INFO - 2024-10-24 15:02:05 --> Language Class Initialized
INFO - 2024-10-24 15:02:05 --> Config Class Initialized
INFO - 2024-10-24 15:02:05 --> Loader Class Initialized
INFO - 2024-10-24 15:02:05 --> Helper loaded: url_helper
INFO - 2024-10-24 15:02:05 --> Helper loaded: file_helper
INFO - 2024-10-24 15:02:05 --> Helper loaded: form_helper
INFO - 2024-10-24 15:02:05 --> Helper loaded: my_helper
INFO - 2024-10-24 15:02:05 --> Database Driver Class Initialized
INFO - 2024-10-24 15:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:02:05 --> Controller Class Initialized
INFO - 2024-10-24 15:02:10 --> Config Class Initialized
INFO - 2024-10-24 15:02:10 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:02:10 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:02:10 --> Utf8 Class Initialized
INFO - 2024-10-24 15:02:10 --> URI Class Initialized
INFO - 2024-10-24 15:02:10 --> Router Class Initialized
INFO - 2024-10-24 15:02:10 --> Output Class Initialized
INFO - 2024-10-24 15:02:10 --> Security Class Initialized
DEBUG - 2024-10-24 15:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:02:10 --> Input Class Initialized
INFO - 2024-10-24 15:02:10 --> Language Class Initialized
INFO - 2024-10-24 15:02:10 --> Language Class Initialized
INFO - 2024-10-24 15:02:10 --> Config Class Initialized
INFO - 2024-10-24 15:02:10 --> Loader Class Initialized
INFO - 2024-10-24 15:02:10 --> Helper loaded: url_helper
INFO - 2024-10-24 15:02:10 --> Helper loaded: file_helper
INFO - 2024-10-24 15:02:10 --> Helper loaded: form_helper
INFO - 2024-10-24 15:02:10 --> Helper loaded: my_helper
INFO - 2024-10-24 15:02:10 --> Database Driver Class Initialized
INFO - 2024-10-24 15:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:02:10 --> Controller Class Initialized
INFO - 2024-10-24 15:02:11 --> Config Class Initialized
INFO - 2024-10-24 15:02:11 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:02:11 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:02:11 --> Utf8 Class Initialized
INFO - 2024-10-24 15:02:11 --> URI Class Initialized
INFO - 2024-10-24 15:02:11 --> Router Class Initialized
INFO - 2024-10-24 15:02:11 --> Output Class Initialized
INFO - 2024-10-24 15:02:11 --> Security Class Initialized
DEBUG - 2024-10-24 15:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:02:11 --> Input Class Initialized
INFO - 2024-10-24 15:02:11 --> Language Class Initialized
INFO - 2024-10-24 15:02:11 --> Language Class Initialized
INFO - 2024-10-24 15:02:11 --> Config Class Initialized
INFO - 2024-10-24 15:02:11 --> Loader Class Initialized
INFO - 2024-10-24 15:02:11 --> Helper loaded: url_helper
INFO - 2024-10-24 15:02:11 --> Helper loaded: file_helper
INFO - 2024-10-24 15:02:11 --> Helper loaded: form_helper
INFO - 2024-10-24 15:02:11 --> Helper loaded: my_helper
INFO - 2024-10-24 15:02:11 --> Database Driver Class Initialized
INFO - 2024-10-24 15:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:02:11 --> Controller Class Initialized
INFO - 2024-10-24 15:02:11 --> Config Class Initialized
INFO - 2024-10-24 15:02:11 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:02:11 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:02:11 --> Utf8 Class Initialized
INFO - 2024-10-24 15:02:11 --> URI Class Initialized
INFO - 2024-10-24 15:02:11 --> Router Class Initialized
INFO - 2024-10-24 15:02:11 --> Output Class Initialized
INFO - 2024-10-24 15:02:11 --> Security Class Initialized
DEBUG - 2024-10-24 15:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:02:11 --> Input Class Initialized
INFO - 2024-10-24 15:02:11 --> Language Class Initialized
INFO - 2024-10-24 15:02:11 --> Language Class Initialized
INFO - 2024-10-24 15:02:11 --> Config Class Initialized
INFO - 2024-10-24 15:02:11 --> Loader Class Initialized
INFO - 2024-10-24 15:02:11 --> Helper loaded: url_helper
INFO - 2024-10-24 15:02:11 --> Helper loaded: file_helper
INFO - 2024-10-24 15:02:11 --> Helper loaded: form_helper
INFO - 2024-10-24 15:02:11 --> Helper loaded: my_helper
INFO - 2024-10-24 15:02:11 --> Database Driver Class Initialized
INFO - 2024-10-24 15:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:02:11 --> Controller Class Initialized
INFO - 2024-10-24 15:02:13 --> Config Class Initialized
INFO - 2024-10-24 15:02:13 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:02:13 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:02:13 --> Utf8 Class Initialized
INFO - 2024-10-24 15:02:13 --> URI Class Initialized
INFO - 2024-10-24 15:02:13 --> Router Class Initialized
INFO - 2024-10-24 15:02:13 --> Output Class Initialized
INFO - 2024-10-24 15:02:13 --> Security Class Initialized
DEBUG - 2024-10-24 15:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:02:13 --> Input Class Initialized
INFO - 2024-10-24 15:02:13 --> Language Class Initialized
INFO - 2024-10-24 15:02:13 --> Language Class Initialized
INFO - 2024-10-24 15:02:13 --> Config Class Initialized
INFO - 2024-10-24 15:02:13 --> Loader Class Initialized
INFO - 2024-10-24 15:02:13 --> Helper loaded: url_helper
INFO - 2024-10-24 15:02:13 --> Helper loaded: file_helper
INFO - 2024-10-24 15:02:13 --> Helper loaded: form_helper
INFO - 2024-10-24 15:02:13 --> Helper loaded: my_helper
INFO - 2024-10-24 15:02:13 --> Database Driver Class Initialized
INFO - 2024-10-24 15:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:02:13 --> Controller Class Initialized
ERROR - 2024-10-24 15:02:13 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-24 15:02:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-24 15:02:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 15:02:13 --> Final output sent to browser
DEBUG - 2024-10-24 15:02:13 --> Total execution time: 0.0367
INFO - 2024-10-24 15:02:30 --> Config Class Initialized
INFO - 2024-10-24 15:02:30 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:02:30 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:02:30 --> Utf8 Class Initialized
INFO - 2024-10-24 15:02:30 --> URI Class Initialized
INFO - 2024-10-24 15:02:30 --> Router Class Initialized
INFO - 2024-10-24 15:02:30 --> Output Class Initialized
INFO - 2024-10-24 15:02:30 --> Security Class Initialized
DEBUG - 2024-10-24 15:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:02:30 --> Input Class Initialized
INFO - 2024-10-24 15:02:30 --> Language Class Initialized
INFO - 2024-10-24 15:02:30 --> Language Class Initialized
INFO - 2024-10-24 15:02:30 --> Config Class Initialized
INFO - 2024-10-24 15:02:30 --> Loader Class Initialized
INFO - 2024-10-24 15:02:30 --> Helper loaded: url_helper
INFO - 2024-10-24 15:02:30 --> Helper loaded: file_helper
INFO - 2024-10-24 15:02:30 --> Helper loaded: form_helper
INFO - 2024-10-24 15:02:30 --> Helper loaded: my_helper
INFO - 2024-10-24 15:02:30 --> Database Driver Class Initialized
INFO - 2024-10-24 15:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:02:30 --> Controller Class Initialized
INFO - 2024-10-24 15:02:30 --> Upload Class Initialized
INFO - 2024-10-24 15:02:30 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-24 15:02:30 --> The upload path does not appear to be valid.
INFO - 2024-10-24 15:02:30 --> Config Class Initialized
INFO - 2024-10-24 15:02:30 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:02:30 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:02:30 --> Utf8 Class Initialized
INFO - 2024-10-24 15:02:30 --> URI Class Initialized
INFO - 2024-10-24 15:02:30 --> Router Class Initialized
INFO - 2024-10-24 15:02:30 --> Output Class Initialized
INFO - 2024-10-24 15:02:30 --> Security Class Initialized
DEBUG - 2024-10-24 15:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:02:30 --> Input Class Initialized
INFO - 2024-10-24 15:02:30 --> Language Class Initialized
INFO - 2024-10-24 15:02:30 --> Language Class Initialized
INFO - 2024-10-24 15:02:30 --> Config Class Initialized
INFO - 2024-10-24 15:02:30 --> Loader Class Initialized
INFO - 2024-10-24 15:02:30 --> Helper loaded: url_helper
INFO - 2024-10-24 15:02:30 --> Helper loaded: file_helper
INFO - 2024-10-24 15:02:30 --> Helper loaded: form_helper
INFO - 2024-10-24 15:02:30 --> Helper loaded: my_helper
INFO - 2024-10-24 15:02:30 --> Database Driver Class Initialized
INFO - 2024-10-24 15:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:02:30 --> Controller Class Initialized
DEBUG - 2024-10-24 15:02:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-24 15:02:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 15:02:30 --> Final output sent to browser
DEBUG - 2024-10-24 15:02:30 --> Total execution time: 0.0316
INFO - 2024-10-24 15:02:30 --> Config Class Initialized
INFO - 2024-10-24 15:02:30 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:02:30 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:02:30 --> Utf8 Class Initialized
INFO - 2024-10-24 15:02:30 --> URI Class Initialized
INFO - 2024-10-24 15:02:30 --> Router Class Initialized
INFO - 2024-10-24 15:02:30 --> Output Class Initialized
INFO - 2024-10-24 15:02:30 --> Security Class Initialized
DEBUG - 2024-10-24 15:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:02:30 --> Input Class Initialized
INFO - 2024-10-24 15:02:30 --> Language Class Initialized
ERROR - 2024-10-24 15:02:30 --> 404 Page Not Found: /index
INFO - 2024-10-24 15:02:30 --> Config Class Initialized
INFO - 2024-10-24 15:02:30 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:02:30 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:02:30 --> Utf8 Class Initialized
INFO - 2024-10-24 15:02:30 --> URI Class Initialized
INFO - 2024-10-24 15:02:30 --> Router Class Initialized
INFO - 2024-10-24 15:02:30 --> Output Class Initialized
INFO - 2024-10-24 15:02:30 --> Security Class Initialized
DEBUG - 2024-10-24 15:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:02:30 --> Input Class Initialized
INFO - 2024-10-24 15:02:30 --> Language Class Initialized
INFO - 2024-10-24 15:02:30 --> Language Class Initialized
INFO - 2024-10-24 15:02:30 --> Config Class Initialized
INFO - 2024-10-24 15:02:30 --> Loader Class Initialized
INFO - 2024-10-24 15:02:30 --> Helper loaded: url_helper
INFO - 2024-10-24 15:02:30 --> Helper loaded: file_helper
INFO - 2024-10-24 15:02:30 --> Helper loaded: form_helper
INFO - 2024-10-24 15:02:30 --> Helper loaded: my_helper
INFO - 2024-10-24 15:02:30 --> Database Driver Class Initialized
INFO - 2024-10-24 15:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:02:30 --> Controller Class Initialized
INFO - 2024-10-24 15:12:35 --> Config Class Initialized
INFO - 2024-10-24 15:12:35 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:12:35 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:12:35 --> Utf8 Class Initialized
INFO - 2024-10-24 15:12:35 --> URI Class Initialized
INFO - 2024-10-24 15:12:35 --> Router Class Initialized
INFO - 2024-10-24 15:12:35 --> Output Class Initialized
INFO - 2024-10-24 15:12:35 --> Security Class Initialized
DEBUG - 2024-10-24 15:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:12:35 --> Input Class Initialized
INFO - 2024-10-24 15:12:35 --> Language Class Initialized
INFO - 2024-10-24 15:12:35 --> Language Class Initialized
INFO - 2024-10-24 15:12:35 --> Config Class Initialized
INFO - 2024-10-24 15:12:35 --> Loader Class Initialized
INFO - 2024-10-24 15:12:35 --> Helper loaded: url_helper
INFO - 2024-10-24 15:12:35 --> Helper loaded: file_helper
INFO - 2024-10-24 15:12:35 --> Helper loaded: form_helper
INFO - 2024-10-24 15:12:35 --> Helper loaded: my_helper
INFO - 2024-10-24 15:12:36 --> Database Driver Class Initialized
INFO - 2024-10-24 15:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:12:36 --> Controller Class Initialized
DEBUG - 2024-10-24 15:12:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-24 15:12:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 15:12:36 --> Final output sent to browser
DEBUG - 2024-10-24 15:12:36 --> Total execution time: 0.0574
INFO - 2024-10-24 15:12:36 --> Config Class Initialized
INFO - 2024-10-24 15:12:36 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:12:36 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:12:36 --> Utf8 Class Initialized
INFO - 2024-10-24 15:12:36 --> URI Class Initialized
INFO - 2024-10-24 15:12:36 --> Router Class Initialized
INFO - 2024-10-24 15:12:36 --> Output Class Initialized
INFO - 2024-10-24 15:12:36 --> Security Class Initialized
DEBUG - 2024-10-24 15:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:12:36 --> Input Class Initialized
INFO - 2024-10-24 15:12:36 --> Language Class Initialized
ERROR - 2024-10-24 15:12:36 --> 404 Page Not Found: /index
INFO - 2024-10-24 15:12:36 --> Config Class Initialized
INFO - 2024-10-24 15:12:36 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:12:36 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:12:36 --> Utf8 Class Initialized
INFO - 2024-10-24 15:12:36 --> URI Class Initialized
INFO - 2024-10-24 15:12:36 --> Router Class Initialized
INFO - 2024-10-24 15:12:36 --> Output Class Initialized
INFO - 2024-10-24 15:12:36 --> Security Class Initialized
DEBUG - 2024-10-24 15:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:12:36 --> Input Class Initialized
INFO - 2024-10-24 15:12:36 --> Language Class Initialized
INFO - 2024-10-24 15:12:36 --> Language Class Initialized
INFO - 2024-10-24 15:12:36 --> Config Class Initialized
INFO - 2024-10-24 15:12:36 --> Loader Class Initialized
INFO - 2024-10-24 15:12:36 --> Helper loaded: url_helper
INFO - 2024-10-24 15:12:36 --> Helper loaded: file_helper
INFO - 2024-10-24 15:12:36 --> Helper loaded: form_helper
INFO - 2024-10-24 15:12:36 --> Helper loaded: my_helper
INFO - 2024-10-24 15:12:36 --> Database Driver Class Initialized
INFO - 2024-10-24 15:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:12:36 --> Controller Class Initialized
INFO - 2024-10-24 15:12:38 --> Config Class Initialized
INFO - 2024-10-24 15:12:38 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:12:38 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:12:38 --> Utf8 Class Initialized
INFO - 2024-10-24 15:12:38 --> URI Class Initialized
INFO - 2024-10-24 15:12:38 --> Router Class Initialized
INFO - 2024-10-24 15:12:38 --> Output Class Initialized
INFO - 2024-10-24 15:12:38 --> Security Class Initialized
DEBUG - 2024-10-24 15:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:12:38 --> Input Class Initialized
INFO - 2024-10-24 15:12:38 --> Language Class Initialized
INFO - 2024-10-24 15:12:38 --> Language Class Initialized
INFO - 2024-10-24 15:12:38 --> Config Class Initialized
INFO - 2024-10-24 15:12:38 --> Loader Class Initialized
INFO - 2024-10-24 15:12:38 --> Helper loaded: url_helper
INFO - 2024-10-24 15:12:38 --> Helper loaded: file_helper
INFO - 2024-10-24 15:12:38 --> Helper loaded: form_helper
INFO - 2024-10-24 15:12:38 --> Helper loaded: my_helper
INFO - 2024-10-24 15:12:38 --> Database Driver Class Initialized
INFO - 2024-10-24 15:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:12:38 --> Controller Class Initialized
INFO - 2024-10-24 15:12:38 --> Config Class Initialized
INFO - 2024-10-24 15:12:38 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:12:38 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:12:38 --> Utf8 Class Initialized
INFO - 2024-10-24 15:12:38 --> URI Class Initialized
INFO - 2024-10-24 15:12:38 --> Router Class Initialized
INFO - 2024-10-24 15:12:38 --> Output Class Initialized
INFO - 2024-10-24 15:12:38 --> Security Class Initialized
DEBUG - 2024-10-24 15:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:12:38 --> Input Class Initialized
INFO - 2024-10-24 15:12:38 --> Language Class Initialized
INFO - 2024-10-24 15:12:38 --> Language Class Initialized
INFO - 2024-10-24 15:12:38 --> Config Class Initialized
INFO - 2024-10-24 15:12:38 --> Loader Class Initialized
INFO - 2024-10-24 15:12:38 --> Helper loaded: url_helper
INFO - 2024-10-24 15:12:38 --> Helper loaded: file_helper
INFO - 2024-10-24 15:12:38 --> Helper loaded: form_helper
INFO - 2024-10-24 15:12:38 --> Helper loaded: my_helper
INFO - 2024-10-24 15:12:38 --> Database Driver Class Initialized
INFO - 2024-10-24 15:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:12:38 --> Controller Class Initialized
INFO - 2024-10-24 15:12:39 --> Config Class Initialized
INFO - 2024-10-24 15:12:39 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:12:39 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:12:39 --> Utf8 Class Initialized
INFO - 2024-10-24 15:12:39 --> URI Class Initialized
INFO - 2024-10-24 15:12:39 --> Router Class Initialized
INFO - 2024-10-24 15:12:39 --> Output Class Initialized
INFO - 2024-10-24 15:12:39 --> Security Class Initialized
DEBUG - 2024-10-24 15:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:12:39 --> Input Class Initialized
INFO - 2024-10-24 15:12:39 --> Language Class Initialized
INFO - 2024-10-24 15:12:39 --> Language Class Initialized
INFO - 2024-10-24 15:12:39 --> Config Class Initialized
INFO - 2024-10-24 15:12:39 --> Loader Class Initialized
INFO - 2024-10-24 15:12:39 --> Helper loaded: url_helper
INFO - 2024-10-24 15:12:39 --> Helper loaded: file_helper
INFO - 2024-10-24 15:12:39 --> Helper loaded: form_helper
INFO - 2024-10-24 15:12:39 --> Helper loaded: my_helper
INFO - 2024-10-24 15:12:39 --> Database Driver Class Initialized
INFO - 2024-10-24 15:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:12:39 --> Controller Class Initialized
INFO - 2024-10-24 15:12:59 --> Config Class Initialized
INFO - 2024-10-24 15:12:59 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:12:59 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:12:59 --> Utf8 Class Initialized
INFO - 2024-10-24 15:12:59 --> URI Class Initialized
INFO - 2024-10-24 15:12:59 --> Router Class Initialized
INFO - 2024-10-24 15:12:59 --> Output Class Initialized
INFO - 2024-10-24 15:12:59 --> Security Class Initialized
DEBUG - 2024-10-24 15:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:12:59 --> Input Class Initialized
INFO - 2024-10-24 15:12:59 --> Language Class Initialized
INFO - 2024-10-24 15:12:59 --> Language Class Initialized
INFO - 2024-10-24 15:12:59 --> Config Class Initialized
INFO - 2024-10-24 15:12:59 --> Loader Class Initialized
INFO - 2024-10-24 15:12:59 --> Helper loaded: url_helper
INFO - 2024-10-24 15:12:59 --> Helper loaded: file_helper
INFO - 2024-10-24 15:12:59 --> Helper loaded: form_helper
INFO - 2024-10-24 15:12:59 --> Helper loaded: my_helper
INFO - 2024-10-24 15:12:59 --> Database Driver Class Initialized
INFO - 2024-10-24 15:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:12:59 --> Controller Class Initialized
INFO - 2024-10-24 15:12:59 --> Config Class Initialized
INFO - 2024-10-24 15:12:59 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:12:59 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:12:59 --> Utf8 Class Initialized
INFO - 2024-10-24 15:12:59 --> URI Class Initialized
INFO - 2024-10-24 15:12:59 --> Router Class Initialized
INFO - 2024-10-24 15:12:59 --> Output Class Initialized
INFO - 2024-10-24 15:12:59 --> Security Class Initialized
DEBUG - 2024-10-24 15:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:12:59 --> Input Class Initialized
INFO - 2024-10-24 15:12:59 --> Language Class Initialized
INFO - 2024-10-24 15:12:59 --> Language Class Initialized
INFO - 2024-10-24 15:12:59 --> Config Class Initialized
INFO - 2024-10-24 15:12:59 --> Loader Class Initialized
INFO - 2024-10-24 15:12:59 --> Helper loaded: url_helper
INFO - 2024-10-24 15:12:59 --> Helper loaded: file_helper
INFO - 2024-10-24 15:12:59 --> Helper loaded: form_helper
INFO - 2024-10-24 15:12:59 --> Helper loaded: my_helper
INFO - 2024-10-24 15:12:59 --> Database Driver Class Initialized
INFO - 2024-10-24 15:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:12:59 --> Controller Class Initialized
INFO - 2024-10-24 15:13:00 --> Config Class Initialized
INFO - 2024-10-24 15:13:00 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:13:00 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:13:00 --> Utf8 Class Initialized
INFO - 2024-10-24 15:13:00 --> URI Class Initialized
INFO - 2024-10-24 15:13:00 --> Router Class Initialized
INFO - 2024-10-24 15:13:00 --> Output Class Initialized
INFO - 2024-10-24 15:13:00 --> Security Class Initialized
DEBUG - 2024-10-24 15:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:13:00 --> Input Class Initialized
INFO - 2024-10-24 15:13:00 --> Language Class Initialized
INFO - 2024-10-24 15:13:00 --> Language Class Initialized
INFO - 2024-10-24 15:13:00 --> Config Class Initialized
INFO - 2024-10-24 15:13:00 --> Loader Class Initialized
INFO - 2024-10-24 15:13:00 --> Helper loaded: url_helper
INFO - 2024-10-24 15:13:00 --> Helper loaded: file_helper
INFO - 2024-10-24 15:13:00 --> Helper loaded: form_helper
INFO - 2024-10-24 15:13:00 --> Helper loaded: my_helper
INFO - 2024-10-24 15:13:00 --> Database Driver Class Initialized
INFO - 2024-10-24 15:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:13:00 --> Controller Class Initialized
INFO - 2024-10-24 15:13:00 --> Config Class Initialized
INFO - 2024-10-24 15:13:00 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:13:00 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:13:00 --> Utf8 Class Initialized
INFO - 2024-10-24 15:13:00 --> URI Class Initialized
INFO - 2024-10-24 15:13:00 --> Router Class Initialized
INFO - 2024-10-24 15:13:00 --> Output Class Initialized
INFO - 2024-10-24 15:13:00 --> Security Class Initialized
DEBUG - 2024-10-24 15:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:13:00 --> Input Class Initialized
INFO - 2024-10-24 15:13:00 --> Language Class Initialized
INFO - 2024-10-24 15:13:00 --> Language Class Initialized
INFO - 2024-10-24 15:13:00 --> Config Class Initialized
INFO - 2024-10-24 15:13:00 --> Loader Class Initialized
INFO - 2024-10-24 15:13:00 --> Helper loaded: url_helper
INFO - 2024-10-24 15:13:00 --> Helper loaded: file_helper
INFO - 2024-10-24 15:13:00 --> Helper loaded: form_helper
INFO - 2024-10-24 15:13:00 --> Helper loaded: my_helper
INFO - 2024-10-24 15:13:00 --> Database Driver Class Initialized
INFO - 2024-10-24 15:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:13:00 --> Controller Class Initialized
INFO - 2024-10-24 15:13:03 --> Config Class Initialized
INFO - 2024-10-24 15:13:03 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:13:03 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:13:03 --> Utf8 Class Initialized
INFO - 2024-10-24 15:13:03 --> URI Class Initialized
INFO - 2024-10-24 15:13:03 --> Router Class Initialized
INFO - 2024-10-24 15:13:03 --> Output Class Initialized
INFO - 2024-10-24 15:13:03 --> Security Class Initialized
DEBUG - 2024-10-24 15:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:13:03 --> Input Class Initialized
INFO - 2024-10-24 15:13:03 --> Language Class Initialized
INFO - 2024-10-24 15:13:03 --> Language Class Initialized
INFO - 2024-10-24 15:13:03 --> Config Class Initialized
INFO - 2024-10-24 15:13:03 --> Loader Class Initialized
INFO - 2024-10-24 15:13:03 --> Helper loaded: url_helper
INFO - 2024-10-24 15:13:03 --> Helper loaded: file_helper
INFO - 2024-10-24 15:13:03 --> Helper loaded: form_helper
INFO - 2024-10-24 15:13:03 --> Helper loaded: my_helper
INFO - 2024-10-24 15:13:03 --> Database Driver Class Initialized
INFO - 2024-10-24 15:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:13:03 --> Controller Class Initialized
DEBUG - 2024-10-24 15:13:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-24 15:13:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 15:13:03 --> Final output sent to browser
DEBUG - 2024-10-24 15:13:03 --> Total execution time: 0.0576
INFO - 2024-10-24 15:13:04 --> Config Class Initialized
INFO - 2024-10-24 15:13:04 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:13:04 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:13:04 --> Utf8 Class Initialized
INFO - 2024-10-24 15:13:04 --> URI Class Initialized
INFO - 2024-10-24 15:13:04 --> Router Class Initialized
INFO - 2024-10-24 15:13:04 --> Output Class Initialized
INFO - 2024-10-24 15:13:04 --> Security Class Initialized
DEBUG - 2024-10-24 15:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:13:04 --> Input Class Initialized
INFO - 2024-10-24 15:13:04 --> Language Class Initialized
ERROR - 2024-10-24 15:13:04 --> 404 Page Not Found: /index
INFO - 2024-10-24 15:13:04 --> Config Class Initialized
INFO - 2024-10-24 15:13:04 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:13:04 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:13:04 --> Utf8 Class Initialized
INFO - 2024-10-24 15:13:04 --> URI Class Initialized
INFO - 2024-10-24 15:13:04 --> Router Class Initialized
INFO - 2024-10-24 15:13:04 --> Output Class Initialized
INFO - 2024-10-24 15:13:04 --> Security Class Initialized
DEBUG - 2024-10-24 15:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:13:04 --> Input Class Initialized
INFO - 2024-10-24 15:13:04 --> Language Class Initialized
INFO - 2024-10-24 15:13:04 --> Language Class Initialized
INFO - 2024-10-24 15:13:04 --> Config Class Initialized
INFO - 2024-10-24 15:13:04 --> Loader Class Initialized
INFO - 2024-10-24 15:13:04 --> Helper loaded: url_helper
INFO - 2024-10-24 15:13:04 --> Helper loaded: file_helper
INFO - 2024-10-24 15:13:04 --> Helper loaded: form_helper
INFO - 2024-10-24 15:13:04 --> Helper loaded: my_helper
INFO - 2024-10-24 15:13:04 --> Database Driver Class Initialized
INFO - 2024-10-24 15:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:13:04 --> Controller Class Initialized
INFO - 2024-10-24 15:13:05 --> Config Class Initialized
INFO - 2024-10-24 15:13:05 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:13:05 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:13:05 --> Utf8 Class Initialized
INFO - 2024-10-24 15:13:05 --> URI Class Initialized
INFO - 2024-10-24 15:13:05 --> Router Class Initialized
INFO - 2024-10-24 15:13:05 --> Output Class Initialized
INFO - 2024-10-24 15:13:05 --> Security Class Initialized
DEBUG - 2024-10-24 15:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:13:05 --> Input Class Initialized
INFO - 2024-10-24 15:13:05 --> Language Class Initialized
INFO - 2024-10-24 15:13:05 --> Language Class Initialized
INFO - 2024-10-24 15:13:05 --> Config Class Initialized
INFO - 2024-10-24 15:13:05 --> Loader Class Initialized
INFO - 2024-10-24 15:13:05 --> Helper loaded: url_helper
INFO - 2024-10-24 15:13:05 --> Helper loaded: file_helper
INFO - 2024-10-24 15:13:05 --> Helper loaded: form_helper
INFO - 2024-10-24 15:13:05 --> Helper loaded: my_helper
INFO - 2024-10-24 15:13:05 --> Database Driver Class Initialized
INFO - 2024-10-24 15:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:13:05 --> Controller Class Initialized
INFO - 2024-10-24 15:13:06 --> Config Class Initialized
INFO - 2024-10-24 15:13:06 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:13:06 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:13:06 --> Utf8 Class Initialized
INFO - 2024-10-24 15:13:06 --> URI Class Initialized
INFO - 2024-10-24 15:13:06 --> Router Class Initialized
INFO - 2024-10-24 15:13:06 --> Output Class Initialized
INFO - 2024-10-24 15:13:06 --> Security Class Initialized
DEBUG - 2024-10-24 15:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:13:06 --> Input Class Initialized
INFO - 2024-10-24 15:13:06 --> Language Class Initialized
INFO - 2024-10-24 15:13:06 --> Language Class Initialized
INFO - 2024-10-24 15:13:06 --> Config Class Initialized
INFO - 2024-10-24 15:13:06 --> Loader Class Initialized
INFO - 2024-10-24 15:13:06 --> Helper loaded: url_helper
INFO - 2024-10-24 15:13:06 --> Helper loaded: file_helper
INFO - 2024-10-24 15:13:06 --> Helper loaded: form_helper
INFO - 2024-10-24 15:13:06 --> Helper loaded: my_helper
INFO - 2024-10-24 15:13:06 --> Database Driver Class Initialized
INFO - 2024-10-24 15:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:13:06 --> Controller Class Initialized
INFO - 2024-10-24 15:13:06 --> Config Class Initialized
INFO - 2024-10-24 15:13:06 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:13:06 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:13:06 --> Utf8 Class Initialized
INFO - 2024-10-24 15:13:06 --> URI Class Initialized
INFO - 2024-10-24 15:13:06 --> Router Class Initialized
INFO - 2024-10-24 15:13:06 --> Output Class Initialized
INFO - 2024-10-24 15:13:06 --> Security Class Initialized
DEBUG - 2024-10-24 15:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:13:06 --> Input Class Initialized
INFO - 2024-10-24 15:13:06 --> Language Class Initialized
INFO - 2024-10-24 15:13:06 --> Language Class Initialized
INFO - 2024-10-24 15:13:06 --> Config Class Initialized
INFO - 2024-10-24 15:13:06 --> Loader Class Initialized
INFO - 2024-10-24 15:13:06 --> Helper loaded: url_helper
INFO - 2024-10-24 15:13:06 --> Helper loaded: file_helper
INFO - 2024-10-24 15:13:06 --> Helper loaded: form_helper
INFO - 2024-10-24 15:13:06 --> Helper loaded: my_helper
INFO - 2024-10-24 15:13:06 --> Database Driver Class Initialized
INFO - 2024-10-24 15:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:13:06 --> Controller Class Initialized
INFO - 2024-10-24 15:13:09 --> Config Class Initialized
INFO - 2024-10-24 15:13:09 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:13:09 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:13:09 --> Utf8 Class Initialized
INFO - 2024-10-24 15:13:09 --> URI Class Initialized
INFO - 2024-10-24 15:13:09 --> Router Class Initialized
INFO - 2024-10-24 15:13:09 --> Output Class Initialized
INFO - 2024-10-24 15:13:09 --> Security Class Initialized
DEBUG - 2024-10-24 15:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:13:09 --> Input Class Initialized
INFO - 2024-10-24 15:13:09 --> Language Class Initialized
INFO - 2024-10-24 15:13:09 --> Language Class Initialized
INFO - 2024-10-24 15:13:09 --> Config Class Initialized
INFO - 2024-10-24 15:13:09 --> Loader Class Initialized
INFO - 2024-10-24 15:13:09 --> Helper loaded: url_helper
INFO - 2024-10-24 15:13:09 --> Helper loaded: file_helper
INFO - 2024-10-24 15:13:09 --> Helper loaded: form_helper
INFO - 2024-10-24 15:13:09 --> Helper loaded: my_helper
INFO - 2024-10-24 15:13:09 --> Database Driver Class Initialized
INFO - 2024-10-24 15:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:13:09 --> Controller Class Initialized
INFO - 2024-10-24 15:13:09 --> Config Class Initialized
INFO - 2024-10-24 15:13:09 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:13:09 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:13:09 --> Utf8 Class Initialized
INFO - 2024-10-24 15:13:09 --> URI Class Initialized
INFO - 2024-10-24 15:13:09 --> Router Class Initialized
INFO - 2024-10-24 15:13:09 --> Output Class Initialized
INFO - 2024-10-24 15:13:09 --> Security Class Initialized
DEBUG - 2024-10-24 15:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:13:09 --> Input Class Initialized
INFO - 2024-10-24 15:13:09 --> Language Class Initialized
INFO - 2024-10-24 15:13:09 --> Language Class Initialized
INFO - 2024-10-24 15:13:09 --> Config Class Initialized
INFO - 2024-10-24 15:13:09 --> Loader Class Initialized
INFO - 2024-10-24 15:13:09 --> Helper loaded: url_helper
INFO - 2024-10-24 15:13:09 --> Helper loaded: file_helper
INFO - 2024-10-24 15:13:09 --> Helper loaded: form_helper
INFO - 2024-10-24 15:13:09 --> Helper loaded: my_helper
INFO - 2024-10-24 15:13:09 --> Database Driver Class Initialized
INFO - 2024-10-24 15:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:13:09 --> Controller Class Initialized
INFO - 2024-10-24 15:13:10 --> Config Class Initialized
INFO - 2024-10-24 15:13:10 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:13:10 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:13:10 --> Utf8 Class Initialized
INFO - 2024-10-24 15:13:10 --> URI Class Initialized
INFO - 2024-10-24 15:13:10 --> Router Class Initialized
INFO - 2024-10-24 15:13:10 --> Output Class Initialized
INFO - 2024-10-24 15:13:10 --> Security Class Initialized
DEBUG - 2024-10-24 15:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:13:10 --> Input Class Initialized
INFO - 2024-10-24 15:13:10 --> Language Class Initialized
INFO - 2024-10-24 15:13:10 --> Language Class Initialized
INFO - 2024-10-24 15:13:10 --> Config Class Initialized
INFO - 2024-10-24 15:13:10 --> Loader Class Initialized
INFO - 2024-10-24 15:13:10 --> Helper loaded: url_helper
INFO - 2024-10-24 15:13:10 --> Helper loaded: file_helper
INFO - 2024-10-24 15:13:10 --> Helper loaded: form_helper
INFO - 2024-10-24 15:13:10 --> Helper loaded: my_helper
INFO - 2024-10-24 15:13:10 --> Database Driver Class Initialized
INFO - 2024-10-24 15:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:13:10 --> Controller Class Initialized
INFO - 2024-10-24 15:13:27 --> Config Class Initialized
INFO - 2024-10-24 15:13:27 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:13:27 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:13:27 --> Utf8 Class Initialized
INFO - 2024-10-24 15:13:27 --> URI Class Initialized
INFO - 2024-10-24 15:13:27 --> Router Class Initialized
INFO - 2024-10-24 15:13:27 --> Output Class Initialized
INFO - 2024-10-24 15:13:27 --> Security Class Initialized
DEBUG - 2024-10-24 15:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:13:27 --> Input Class Initialized
INFO - 2024-10-24 15:13:27 --> Language Class Initialized
INFO - 2024-10-24 15:13:27 --> Language Class Initialized
INFO - 2024-10-24 15:13:27 --> Config Class Initialized
INFO - 2024-10-24 15:13:27 --> Loader Class Initialized
INFO - 2024-10-24 15:13:27 --> Helper loaded: url_helper
INFO - 2024-10-24 15:13:27 --> Helper loaded: file_helper
INFO - 2024-10-24 15:13:27 --> Helper loaded: form_helper
INFO - 2024-10-24 15:13:27 --> Helper loaded: my_helper
INFO - 2024-10-24 15:13:27 --> Database Driver Class Initialized
INFO - 2024-10-24 15:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:13:27 --> Controller Class Initialized
INFO - 2024-10-24 15:13:28 --> Config Class Initialized
INFO - 2024-10-24 15:13:28 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:13:28 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:13:28 --> Utf8 Class Initialized
INFO - 2024-10-24 15:13:28 --> URI Class Initialized
INFO - 2024-10-24 15:13:28 --> Router Class Initialized
INFO - 2024-10-24 15:13:28 --> Output Class Initialized
INFO - 2024-10-24 15:13:28 --> Security Class Initialized
DEBUG - 2024-10-24 15:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:13:28 --> Input Class Initialized
INFO - 2024-10-24 15:13:28 --> Language Class Initialized
INFO - 2024-10-24 15:13:28 --> Language Class Initialized
INFO - 2024-10-24 15:13:28 --> Config Class Initialized
INFO - 2024-10-24 15:13:28 --> Loader Class Initialized
INFO - 2024-10-24 15:13:28 --> Helper loaded: url_helper
INFO - 2024-10-24 15:13:28 --> Helper loaded: file_helper
INFO - 2024-10-24 15:13:28 --> Helper loaded: form_helper
INFO - 2024-10-24 15:13:28 --> Helper loaded: my_helper
INFO - 2024-10-24 15:13:28 --> Database Driver Class Initialized
INFO - 2024-10-24 15:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:13:28 --> Controller Class Initialized
INFO - 2024-10-24 15:13:28 --> Config Class Initialized
INFO - 2024-10-24 15:13:28 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:13:28 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:13:28 --> Utf8 Class Initialized
INFO - 2024-10-24 15:13:28 --> URI Class Initialized
INFO - 2024-10-24 15:13:28 --> Router Class Initialized
INFO - 2024-10-24 15:13:28 --> Output Class Initialized
INFO - 2024-10-24 15:13:28 --> Security Class Initialized
DEBUG - 2024-10-24 15:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:13:28 --> Input Class Initialized
INFO - 2024-10-24 15:13:28 --> Language Class Initialized
INFO - 2024-10-24 15:13:28 --> Language Class Initialized
INFO - 2024-10-24 15:13:28 --> Config Class Initialized
INFO - 2024-10-24 15:13:28 --> Loader Class Initialized
INFO - 2024-10-24 15:13:28 --> Helper loaded: url_helper
INFO - 2024-10-24 15:13:28 --> Helper loaded: file_helper
INFO - 2024-10-24 15:13:28 --> Helper loaded: form_helper
INFO - 2024-10-24 15:13:28 --> Helper loaded: my_helper
INFO - 2024-10-24 15:13:28 --> Database Driver Class Initialized
INFO - 2024-10-24 15:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:13:28 --> Controller Class Initialized
INFO - 2024-10-24 15:22:57 --> Config Class Initialized
INFO - 2024-10-24 15:22:57 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:22:57 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:22:57 --> Utf8 Class Initialized
INFO - 2024-10-24 15:22:57 --> URI Class Initialized
INFO - 2024-10-24 15:22:57 --> Router Class Initialized
INFO - 2024-10-24 15:22:57 --> Output Class Initialized
INFO - 2024-10-24 15:22:57 --> Security Class Initialized
DEBUG - 2024-10-24 15:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:22:57 --> Input Class Initialized
INFO - 2024-10-24 15:22:57 --> Language Class Initialized
INFO - 2024-10-24 15:22:57 --> Language Class Initialized
INFO - 2024-10-24 15:22:57 --> Config Class Initialized
INFO - 2024-10-24 15:22:57 --> Loader Class Initialized
INFO - 2024-10-24 15:22:57 --> Helper loaded: url_helper
INFO - 2024-10-24 15:22:57 --> Helper loaded: file_helper
INFO - 2024-10-24 15:22:57 --> Helper loaded: form_helper
INFO - 2024-10-24 15:22:57 --> Helper loaded: my_helper
INFO - 2024-10-24 15:22:58 --> Database Driver Class Initialized
INFO - 2024-10-24 15:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:22:58 --> Controller Class Initialized
DEBUG - 2024-10-24 15:22:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-24 15:22:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 15:22:58 --> Final output sent to browser
DEBUG - 2024-10-24 15:22:58 --> Total execution time: 0.0587
INFO - 2024-10-24 15:22:58 --> Config Class Initialized
INFO - 2024-10-24 15:22:58 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:22:58 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:22:58 --> Utf8 Class Initialized
INFO - 2024-10-24 15:22:58 --> URI Class Initialized
INFO - 2024-10-24 15:22:58 --> Router Class Initialized
INFO - 2024-10-24 15:22:58 --> Output Class Initialized
INFO - 2024-10-24 15:22:58 --> Security Class Initialized
DEBUG - 2024-10-24 15:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:22:58 --> Input Class Initialized
INFO - 2024-10-24 15:22:58 --> Language Class Initialized
ERROR - 2024-10-24 15:22:58 --> 404 Page Not Found: /index
INFO - 2024-10-24 15:22:58 --> Config Class Initialized
INFO - 2024-10-24 15:22:58 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:22:58 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:22:58 --> Utf8 Class Initialized
INFO - 2024-10-24 15:22:58 --> URI Class Initialized
INFO - 2024-10-24 15:22:58 --> Router Class Initialized
INFO - 2024-10-24 15:22:58 --> Output Class Initialized
INFO - 2024-10-24 15:22:58 --> Security Class Initialized
DEBUG - 2024-10-24 15:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:22:58 --> Input Class Initialized
INFO - 2024-10-24 15:22:58 --> Language Class Initialized
INFO - 2024-10-24 15:22:58 --> Language Class Initialized
INFO - 2024-10-24 15:22:58 --> Config Class Initialized
INFO - 2024-10-24 15:22:58 --> Loader Class Initialized
INFO - 2024-10-24 15:22:58 --> Helper loaded: url_helper
INFO - 2024-10-24 15:22:58 --> Helper loaded: file_helper
INFO - 2024-10-24 15:22:58 --> Helper loaded: form_helper
INFO - 2024-10-24 15:22:58 --> Helper loaded: my_helper
INFO - 2024-10-24 15:22:58 --> Database Driver Class Initialized
INFO - 2024-10-24 15:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:22:58 --> Controller Class Initialized
INFO - 2024-10-24 15:22:59 --> Config Class Initialized
INFO - 2024-10-24 15:22:59 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:22:59 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:22:59 --> Utf8 Class Initialized
INFO - 2024-10-24 15:22:59 --> URI Class Initialized
INFO - 2024-10-24 15:22:59 --> Router Class Initialized
INFO - 2024-10-24 15:22:59 --> Output Class Initialized
INFO - 2024-10-24 15:22:59 --> Security Class Initialized
DEBUG - 2024-10-24 15:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:22:59 --> Input Class Initialized
INFO - 2024-10-24 15:22:59 --> Language Class Initialized
INFO - 2024-10-24 15:22:59 --> Language Class Initialized
INFO - 2024-10-24 15:22:59 --> Config Class Initialized
INFO - 2024-10-24 15:22:59 --> Loader Class Initialized
INFO - 2024-10-24 15:22:59 --> Helper loaded: url_helper
INFO - 2024-10-24 15:22:59 --> Helper loaded: file_helper
INFO - 2024-10-24 15:22:59 --> Helper loaded: form_helper
INFO - 2024-10-24 15:22:59 --> Helper loaded: my_helper
INFO - 2024-10-24 15:22:59 --> Database Driver Class Initialized
INFO - 2024-10-24 15:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:22:59 --> Controller Class Initialized
INFO - 2024-10-24 15:22:59 --> Helper loaded: cookie_helper
INFO - 2024-10-24 15:22:59 --> Config Class Initialized
INFO - 2024-10-24 15:22:59 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:22:59 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:22:59 --> Utf8 Class Initialized
INFO - 2024-10-24 15:22:59 --> URI Class Initialized
INFO - 2024-10-24 15:22:59 --> Router Class Initialized
INFO - 2024-10-24 15:22:59 --> Output Class Initialized
INFO - 2024-10-24 15:22:59 --> Security Class Initialized
DEBUG - 2024-10-24 15:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:22:59 --> Input Class Initialized
INFO - 2024-10-24 15:22:59 --> Language Class Initialized
INFO - 2024-10-24 15:22:59 --> Language Class Initialized
INFO - 2024-10-24 15:22:59 --> Config Class Initialized
INFO - 2024-10-24 15:22:59 --> Loader Class Initialized
INFO - 2024-10-24 15:22:59 --> Helper loaded: url_helper
INFO - 2024-10-24 15:22:59 --> Helper loaded: file_helper
INFO - 2024-10-24 15:22:59 --> Helper loaded: form_helper
INFO - 2024-10-24 15:22:59 --> Helper loaded: my_helper
INFO - 2024-10-24 15:22:59 --> Database Driver Class Initialized
INFO - 2024-10-24 15:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:22:59 --> Controller Class Initialized
INFO - 2024-10-24 15:22:59 --> Config Class Initialized
INFO - 2024-10-24 15:22:59 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:22:59 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:22:59 --> Utf8 Class Initialized
INFO - 2024-10-24 15:22:59 --> URI Class Initialized
INFO - 2024-10-24 15:22:59 --> Router Class Initialized
INFO - 2024-10-24 15:22:59 --> Output Class Initialized
INFO - 2024-10-24 15:22:59 --> Security Class Initialized
DEBUG - 2024-10-24 15:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:22:59 --> Input Class Initialized
INFO - 2024-10-24 15:22:59 --> Language Class Initialized
INFO - 2024-10-24 15:22:59 --> Language Class Initialized
INFO - 2024-10-24 15:22:59 --> Config Class Initialized
INFO - 2024-10-24 15:22:59 --> Loader Class Initialized
INFO - 2024-10-24 15:22:59 --> Helper loaded: url_helper
INFO - 2024-10-24 15:22:59 --> Helper loaded: file_helper
INFO - 2024-10-24 15:22:59 --> Helper loaded: form_helper
INFO - 2024-10-24 15:22:59 --> Helper loaded: my_helper
INFO - 2024-10-24 15:22:59 --> Database Driver Class Initialized
INFO - 2024-10-24 15:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:22:59 --> Controller Class Initialized
DEBUG - 2024-10-24 15:22:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-24 15:22:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 15:22:59 --> Final output sent to browser
DEBUG - 2024-10-24 15:22:59 --> Total execution time: 0.0396
INFO - 2024-10-24 15:23:05 --> Config Class Initialized
INFO - 2024-10-24 15:23:05 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:23:05 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:23:05 --> Utf8 Class Initialized
INFO - 2024-10-24 15:23:05 --> URI Class Initialized
INFO - 2024-10-24 15:23:05 --> Router Class Initialized
INFO - 2024-10-24 15:23:05 --> Output Class Initialized
INFO - 2024-10-24 15:23:05 --> Security Class Initialized
DEBUG - 2024-10-24 15:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:23:05 --> Input Class Initialized
INFO - 2024-10-24 15:23:05 --> Language Class Initialized
INFO - 2024-10-24 15:23:05 --> Language Class Initialized
INFO - 2024-10-24 15:23:05 --> Config Class Initialized
INFO - 2024-10-24 15:23:05 --> Loader Class Initialized
INFO - 2024-10-24 15:23:05 --> Helper loaded: url_helper
INFO - 2024-10-24 15:23:05 --> Helper loaded: file_helper
INFO - 2024-10-24 15:23:05 --> Helper loaded: form_helper
INFO - 2024-10-24 15:23:05 --> Helper loaded: my_helper
INFO - 2024-10-24 15:23:05 --> Database Driver Class Initialized
INFO - 2024-10-24 15:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:23:05 --> Controller Class Initialized
INFO - 2024-10-24 15:23:05 --> Helper loaded: cookie_helper
INFO - 2024-10-24 15:23:05 --> Final output sent to browser
DEBUG - 2024-10-24 15:23:05 --> Total execution time: 0.0643
INFO - 2024-10-24 15:23:06 --> Config Class Initialized
INFO - 2024-10-24 15:23:06 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:23:06 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:23:06 --> Utf8 Class Initialized
INFO - 2024-10-24 15:23:06 --> URI Class Initialized
INFO - 2024-10-24 15:23:06 --> Router Class Initialized
INFO - 2024-10-24 15:23:06 --> Output Class Initialized
INFO - 2024-10-24 15:23:06 --> Security Class Initialized
DEBUG - 2024-10-24 15:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:23:06 --> Input Class Initialized
INFO - 2024-10-24 15:23:06 --> Language Class Initialized
INFO - 2024-10-24 15:23:06 --> Language Class Initialized
INFO - 2024-10-24 15:23:06 --> Config Class Initialized
INFO - 2024-10-24 15:23:06 --> Loader Class Initialized
INFO - 2024-10-24 15:23:06 --> Helper loaded: url_helper
INFO - 2024-10-24 15:23:06 --> Helper loaded: file_helper
INFO - 2024-10-24 15:23:06 --> Helper loaded: form_helper
INFO - 2024-10-24 15:23:06 --> Helper loaded: my_helper
INFO - 2024-10-24 15:23:06 --> Database Driver Class Initialized
INFO - 2024-10-24 15:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:23:06 --> Controller Class Initialized
DEBUG - 2024-10-24 15:23:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-10-24 15:23:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 15:23:06 --> Final output sent to browser
DEBUG - 2024-10-24 15:23:06 --> Total execution time: 0.0395
INFO - 2024-10-24 15:23:07 --> Config Class Initialized
INFO - 2024-10-24 15:23:07 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:23:07 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:23:07 --> Utf8 Class Initialized
INFO - 2024-10-24 15:23:07 --> URI Class Initialized
INFO - 2024-10-24 15:23:07 --> Router Class Initialized
INFO - 2024-10-24 15:23:07 --> Output Class Initialized
INFO - 2024-10-24 15:23:07 --> Security Class Initialized
DEBUG - 2024-10-24 15:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:23:07 --> Input Class Initialized
INFO - 2024-10-24 15:23:07 --> Language Class Initialized
INFO - 2024-10-24 15:23:07 --> Language Class Initialized
INFO - 2024-10-24 15:23:07 --> Config Class Initialized
INFO - 2024-10-24 15:23:07 --> Loader Class Initialized
INFO - 2024-10-24 15:23:07 --> Helper loaded: url_helper
INFO - 2024-10-24 15:23:07 --> Helper loaded: file_helper
INFO - 2024-10-24 15:23:07 --> Helper loaded: form_helper
INFO - 2024-10-24 15:23:07 --> Helper loaded: my_helper
INFO - 2024-10-24 15:23:07 --> Database Driver Class Initialized
INFO - 2024-10-24 15:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:23:07 --> Controller Class Initialized
DEBUG - 2024-10-24 15:23:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-24 15:23:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 15:23:07 --> Final output sent to browser
DEBUG - 2024-10-24 15:23:07 --> Total execution time: 0.0512
INFO - 2024-10-24 15:23:08 --> Config Class Initialized
INFO - 2024-10-24 15:23:08 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:23:08 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:23:08 --> Utf8 Class Initialized
INFO - 2024-10-24 15:23:08 --> URI Class Initialized
INFO - 2024-10-24 15:23:08 --> Router Class Initialized
INFO - 2024-10-24 15:23:08 --> Output Class Initialized
INFO - 2024-10-24 15:23:08 --> Security Class Initialized
DEBUG - 2024-10-24 15:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:23:08 --> Input Class Initialized
INFO - 2024-10-24 15:23:08 --> Language Class Initialized
ERROR - 2024-10-24 15:23:08 --> 404 Page Not Found: /index
INFO - 2024-10-24 15:23:09 --> Config Class Initialized
INFO - 2024-10-24 15:23:09 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:23:09 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:23:09 --> Utf8 Class Initialized
INFO - 2024-10-24 15:23:09 --> URI Class Initialized
INFO - 2024-10-24 15:23:09 --> Router Class Initialized
INFO - 2024-10-24 15:23:09 --> Output Class Initialized
INFO - 2024-10-24 15:23:09 --> Security Class Initialized
DEBUG - 2024-10-24 15:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:23:09 --> Input Class Initialized
INFO - 2024-10-24 15:23:09 --> Language Class Initialized
INFO - 2024-10-24 15:23:09 --> Language Class Initialized
INFO - 2024-10-24 15:23:09 --> Config Class Initialized
INFO - 2024-10-24 15:23:09 --> Loader Class Initialized
INFO - 2024-10-24 15:23:09 --> Helper loaded: url_helper
INFO - 2024-10-24 15:23:09 --> Helper loaded: file_helper
INFO - 2024-10-24 15:23:09 --> Helper loaded: form_helper
INFO - 2024-10-24 15:23:09 --> Helper loaded: my_helper
INFO - 2024-10-24 15:23:09 --> Database Driver Class Initialized
INFO - 2024-10-24 15:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:23:09 --> Controller Class Initialized
INFO - 2024-10-24 15:23:11 --> Config Class Initialized
INFO - 2024-10-24 15:23:11 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:23:11 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:23:11 --> Utf8 Class Initialized
INFO - 2024-10-24 15:23:11 --> URI Class Initialized
INFO - 2024-10-24 15:23:11 --> Router Class Initialized
INFO - 2024-10-24 15:23:11 --> Output Class Initialized
INFO - 2024-10-24 15:23:11 --> Security Class Initialized
DEBUG - 2024-10-24 15:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:23:11 --> Input Class Initialized
INFO - 2024-10-24 15:23:11 --> Language Class Initialized
INFO - 2024-10-24 15:23:11 --> Language Class Initialized
INFO - 2024-10-24 15:23:11 --> Config Class Initialized
INFO - 2024-10-24 15:23:11 --> Loader Class Initialized
INFO - 2024-10-24 15:23:11 --> Helper loaded: url_helper
INFO - 2024-10-24 15:23:11 --> Helper loaded: file_helper
INFO - 2024-10-24 15:23:11 --> Helper loaded: form_helper
INFO - 2024-10-24 15:23:11 --> Helper loaded: my_helper
INFO - 2024-10-24 15:23:11 --> Database Driver Class Initialized
INFO - 2024-10-24 15:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:23:11 --> Controller Class Initialized
INFO - 2024-10-24 15:23:11 --> Config Class Initialized
INFO - 2024-10-24 15:23:11 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:23:11 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:23:11 --> Utf8 Class Initialized
INFO - 2024-10-24 15:23:11 --> URI Class Initialized
INFO - 2024-10-24 15:23:11 --> Router Class Initialized
INFO - 2024-10-24 15:23:11 --> Output Class Initialized
INFO - 2024-10-24 15:23:11 --> Security Class Initialized
DEBUG - 2024-10-24 15:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:23:11 --> Input Class Initialized
INFO - 2024-10-24 15:23:11 --> Language Class Initialized
INFO - 2024-10-24 15:23:11 --> Language Class Initialized
INFO - 2024-10-24 15:23:11 --> Config Class Initialized
INFO - 2024-10-24 15:23:11 --> Loader Class Initialized
INFO - 2024-10-24 15:23:11 --> Helper loaded: url_helper
INFO - 2024-10-24 15:23:11 --> Helper loaded: file_helper
INFO - 2024-10-24 15:23:11 --> Helper loaded: form_helper
INFO - 2024-10-24 15:23:11 --> Helper loaded: my_helper
INFO - 2024-10-24 15:23:11 --> Database Driver Class Initialized
INFO - 2024-10-24 15:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:23:11 --> Controller Class Initialized
INFO - 2024-10-24 15:23:12 --> Config Class Initialized
INFO - 2024-10-24 15:23:12 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:23:12 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:23:12 --> Utf8 Class Initialized
INFO - 2024-10-24 15:23:12 --> URI Class Initialized
INFO - 2024-10-24 15:23:12 --> Router Class Initialized
INFO - 2024-10-24 15:23:12 --> Output Class Initialized
INFO - 2024-10-24 15:23:12 --> Security Class Initialized
DEBUG - 2024-10-24 15:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:23:12 --> Input Class Initialized
INFO - 2024-10-24 15:23:12 --> Language Class Initialized
INFO - 2024-10-24 15:23:12 --> Language Class Initialized
INFO - 2024-10-24 15:23:12 --> Config Class Initialized
INFO - 2024-10-24 15:23:12 --> Loader Class Initialized
INFO - 2024-10-24 15:23:12 --> Helper loaded: url_helper
INFO - 2024-10-24 15:23:12 --> Helper loaded: file_helper
INFO - 2024-10-24 15:23:12 --> Helper loaded: form_helper
INFO - 2024-10-24 15:23:12 --> Helper loaded: my_helper
INFO - 2024-10-24 15:23:12 --> Database Driver Class Initialized
INFO - 2024-10-24 15:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:23:12 --> Controller Class Initialized
INFO - 2024-10-24 15:23:14 --> Config Class Initialized
INFO - 2024-10-24 15:23:14 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:23:14 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:23:14 --> Utf8 Class Initialized
INFO - 2024-10-24 15:23:14 --> URI Class Initialized
INFO - 2024-10-24 15:23:14 --> Router Class Initialized
INFO - 2024-10-24 15:23:14 --> Output Class Initialized
INFO - 2024-10-24 15:23:14 --> Security Class Initialized
DEBUG - 2024-10-24 15:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:23:14 --> Input Class Initialized
INFO - 2024-10-24 15:23:14 --> Language Class Initialized
INFO - 2024-10-24 15:23:14 --> Language Class Initialized
INFO - 2024-10-24 15:23:14 --> Config Class Initialized
INFO - 2024-10-24 15:23:14 --> Loader Class Initialized
INFO - 2024-10-24 15:23:14 --> Helper loaded: url_helper
INFO - 2024-10-24 15:23:14 --> Helper loaded: file_helper
INFO - 2024-10-24 15:23:14 --> Helper loaded: form_helper
INFO - 2024-10-24 15:23:14 --> Helper loaded: my_helper
INFO - 2024-10-24 15:23:14 --> Database Driver Class Initialized
INFO - 2024-10-24 15:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:23:14 --> Controller Class Initialized
INFO - 2024-10-24 15:23:15 --> Config Class Initialized
INFO - 2024-10-24 15:23:15 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:23:15 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:23:15 --> Utf8 Class Initialized
INFO - 2024-10-24 15:23:15 --> URI Class Initialized
INFO - 2024-10-24 15:23:15 --> Router Class Initialized
INFO - 2024-10-24 15:23:15 --> Output Class Initialized
INFO - 2024-10-24 15:23:15 --> Security Class Initialized
DEBUG - 2024-10-24 15:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:23:15 --> Input Class Initialized
INFO - 2024-10-24 15:23:15 --> Language Class Initialized
INFO - 2024-10-24 15:23:15 --> Language Class Initialized
INFO - 2024-10-24 15:23:15 --> Config Class Initialized
INFO - 2024-10-24 15:23:15 --> Loader Class Initialized
INFO - 2024-10-24 15:23:15 --> Helper loaded: url_helper
INFO - 2024-10-24 15:23:15 --> Helper loaded: file_helper
INFO - 2024-10-24 15:23:15 --> Helper loaded: form_helper
INFO - 2024-10-24 15:23:15 --> Helper loaded: my_helper
INFO - 2024-10-24 15:23:15 --> Database Driver Class Initialized
INFO - 2024-10-24 15:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:23:15 --> Controller Class Initialized
INFO - 2024-10-24 15:23:15 --> Config Class Initialized
INFO - 2024-10-24 15:23:15 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:23:15 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:23:15 --> Utf8 Class Initialized
INFO - 2024-10-24 15:23:15 --> URI Class Initialized
INFO - 2024-10-24 15:23:15 --> Router Class Initialized
INFO - 2024-10-24 15:23:15 --> Output Class Initialized
INFO - 2024-10-24 15:23:15 --> Security Class Initialized
DEBUG - 2024-10-24 15:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:23:15 --> Input Class Initialized
INFO - 2024-10-24 15:23:15 --> Language Class Initialized
INFO - 2024-10-24 15:23:15 --> Language Class Initialized
INFO - 2024-10-24 15:23:15 --> Config Class Initialized
INFO - 2024-10-24 15:23:15 --> Loader Class Initialized
INFO - 2024-10-24 15:23:15 --> Helper loaded: url_helper
INFO - 2024-10-24 15:23:15 --> Helper loaded: file_helper
INFO - 2024-10-24 15:23:15 --> Helper loaded: form_helper
INFO - 2024-10-24 15:23:15 --> Helper loaded: my_helper
INFO - 2024-10-24 15:23:15 --> Database Driver Class Initialized
INFO - 2024-10-24 15:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:23:15 --> Controller Class Initialized
INFO - 2024-10-24 15:23:19 --> Config Class Initialized
INFO - 2024-10-24 15:23:19 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:23:19 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:23:19 --> Utf8 Class Initialized
INFO - 2024-10-24 15:23:19 --> URI Class Initialized
INFO - 2024-10-24 15:23:19 --> Router Class Initialized
INFO - 2024-10-24 15:23:19 --> Output Class Initialized
INFO - 2024-10-24 15:23:19 --> Security Class Initialized
DEBUG - 2024-10-24 15:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:23:19 --> Input Class Initialized
INFO - 2024-10-24 15:23:19 --> Language Class Initialized
INFO - 2024-10-24 15:23:19 --> Language Class Initialized
INFO - 2024-10-24 15:23:19 --> Config Class Initialized
INFO - 2024-10-24 15:23:19 --> Loader Class Initialized
INFO - 2024-10-24 15:23:19 --> Helper loaded: url_helper
INFO - 2024-10-24 15:23:19 --> Helper loaded: file_helper
INFO - 2024-10-24 15:23:19 --> Helper loaded: form_helper
INFO - 2024-10-24 15:23:19 --> Helper loaded: my_helper
INFO - 2024-10-24 15:23:19 --> Database Driver Class Initialized
INFO - 2024-10-24 15:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:23:19 --> Controller Class Initialized
INFO - 2024-10-24 15:23:24 --> Config Class Initialized
INFO - 2024-10-24 15:23:24 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:23:24 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:23:24 --> Utf8 Class Initialized
INFO - 2024-10-24 15:23:24 --> URI Class Initialized
INFO - 2024-10-24 15:23:24 --> Router Class Initialized
INFO - 2024-10-24 15:23:24 --> Output Class Initialized
INFO - 2024-10-24 15:23:24 --> Security Class Initialized
DEBUG - 2024-10-24 15:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:23:24 --> Input Class Initialized
INFO - 2024-10-24 15:23:24 --> Language Class Initialized
INFO - 2024-10-24 15:23:24 --> Language Class Initialized
INFO - 2024-10-24 15:23:24 --> Config Class Initialized
INFO - 2024-10-24 15:23:24 --> Loader Class Initialized
INFO - 2024-10-24 15:23:24 --> Helper loaded: url_helper
INFO - 2024-10-24 15:23:24 --> Helper loaded: file_helper
INFO - 2024-10-24 15:23:24 --> Helper loaded: form_helper
INFO - 2024-10-24 15:23:24 --> Helper loaded: my_helper
INFO - 2024-10-24 15:23:24 --> Database Driver Class Initialized
INFO - 2024-10-24 15:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:23:24 --> Controller Class Initialized
INFO - 2024-10-24 15:24:46 --> Config Class Initialized
INFO - 2024-10-24 15:24:46 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:24:46 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:24:46 --> Utf8 Class Initialized
INFO - 2024-10-24 15:24:46 --> URI Class Initialized
INFO - 2024-10-24 15:24:46 --> Router Class Initialized
INFO - 2024-10-24 15:24:46 --> Output Class Initialized
INFO - 2024-10-24 15:24:46 --> Security Class Initialized
DEBUG - 2024-10-24 15:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:24:46 --> Input Class Initialized
INFO - 2024-10-24 15:24:46 --> Language Class Initialized
INFO - 2024-10-24 15:24:46 --> Language Class Initialized
INFO - 2024-10-24 15:24:46 --> Config Class Initialized
INFO - 2024-10-24 15:24:46 --> Loader Class Initialized
INFO - 2024-10-24 15:24:46 --> Helper loaded: url_helper
INFO - 2024-10-24 15:24:46 --> Helper loaded: file_helper
INFO - 2024-10-24 15:24:46 --> Helper loaded: form_helper
INFO - 2024-10-24 15:24:46 --> Helper loaded: my_helper
INFO - 2024-10-24 15:24:46 --> Database Driver Class Initialized
INFO - 2024-10-24 15:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:24:46 --> Controller Class Initialized
ERROR - 2024-10-24 15:24:46 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-24 15:24:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-24 15:24:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 15:24:46 --> Final output sent to browser
DEBUG - 2024-10-24 15:24:46 --> Total execution time: 0.0490
INFO - 2024-10-24 15:24:52 --> Config Class Initialized
INFO - 2024-10-24 15:24:52 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:24:52 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:24:52 --> Utf8 Class Initialized
INFO - 2024-10-24 15:24:52 --> URI Class Initialized
INFO - 2024-10-24 15:24:52 --> Router Class Initialized
INFO - 2024-10-24 15:24:52 --> Output Class Initialized
INFO - 2024-10-24 15:24:52 --> Security Class Initialized
DEBUG - 2024-10-24 15:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:24:52 --> Input Class Initialized
INFO - 2024-10-24 15:24:52 --> Language Class Initialized
INFO - 2024-10-24 15:24:52 --> Language Class Initialized
INFO - 2024-10-24 15:24:52 --> Config Class Initialized
INFO - 2024-10-24 15:24:52 --> Loader Class Initialized
INFO - 2024-10-24 15:24:52 --> Helper loaded: url_helper
INFO - 2024-10-24 15:24:52 --> Helper loaded: file_helper
INFO - 2024-10-24 15:24:52 --> Helper loaded: form_helper
INFO - 2024-10-24 15:24:52 --> Helper loaded: my_helper
INFO - 2024-10-24 15:24:52 --> Database Driver Class Initialized
INFO - 2024-10-24 15:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:24:52 --> Controller Class Initialized
INFO - 2024-10-24 15:24:52 --> Upload Class Initialized
INFO - 2024-10-24 15:24:52 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-24 15:24:52 --> The upload path does not appear to be valid.
INFO - 2024-10-24 15:24:52 --> Config Class Initialized
INFO - 2024-10-24 15:24:52 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:24:52 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:24:52 --> Utf8 Class Initialized
INFO - 2024-10-24 15:24:52 --> URI Class Initialized
INFO - 2024-10-24 15:24:52 --> Router Class Initialized
INFO - 2024-10-24 15:24:52 --> Output Class Initialized
INFO - 2024-10-24 15:24:52 --> Security Class Initialized
DEBUG - 2024-10-24 15:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:24:52 --> Input Class Initialized
INFO - 2024-10-24 15:24:52 --> Language Class Initialized
INFO - 2024-10-24 15:24:52 --> Language Class Initialized
INFO - 2024-10-24 15:24:52 --> Config Class Initialized
INFO - 2024-10-24 15:24:52 --> Loader Class Initialized
INFO - 2024-10-24 15:24:52 --> Helper loaded: url_helper
INFO - 2024-10-24 15:24:52 --> Helper loaded: file_helper
INFO - 2024-10-24 15:24:52 --> Helper loaded: form_helper
INFO - 2024-10-24 15:24:52 --> Helper loaded: my_helper
INFO - 2024-10-24 15:24:52 --> Database Driver Class Initialized
INFO - 2024-10-24 15:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:24:52 --> Controller Class Initialized
DEBUG - 2024-10-24 15:24:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-24 15:24:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 15:24:52 --> Final output sent to browser
DEBUG - 2024-10-24 15:24:52 --> Total execution time: 0.0518
INFO - 2024-10-24 15:24:52 --> Config Class Initialized
INFO - 2024-10-24 15:24:52 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:24:52 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:24:52 --> Utf8 Class Initialized
INFO - 2024-10-24 15:24:52 --> URI Class Initialized
INFO - 2024-10-24 15:24:52 --> Router Class Initialized
INFO - 2024-10-24 15:24:52 --> Output Class Initialized
INFO - 2024-10-24 15:24:52 --> Security Class Initialized
DEBUG - 2024-10-24 15:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:24:52 --> Input Class Initialized
INFO - 2024-10-24 15:24:52 --> Language Class Initialized
ERROR - 2024-10-24 15:24:52 --> 404 Page Not Found: /index
INFO - 2024-10-24 15:24:52 --> Config Class Initialized
INFO - 2024-10-24 15:24:52 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:24:52 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:24:52 --> Utf8 Class Initialized
INFO - 2024-10-24 15:24:52 --> URI Class Initialized
INFO - 2024-10-24 15:24:52 --> Router Class Initialized
INFO - 2024-10-24 15:24:52 --> Output Class Initialized
INFO - 2024-10-24 15:24:52 --> Security Class Initialized
DEBUG - 2024-10-24 15:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:24:52 --> Input Class Initialized
INFO - 2024-10-24 15:24:52 --> Language Class Initialized
INFO - 2024-10-24 15:24:52 --> Language Class Initialized
INFO - 2024-10-24 15:24:52 --> Config Class Initialized
INFO - 2024-10-24 15:24:52 --> Loader Class Initialized
INFO - 2024-10-24 15:24:52 --> Helper loaded: url_helper
INFO - 2024-10-24 15:24:52 --> Helper loaded: file_helper
INFO - 2024-10-24 15:24:52 --> Helper loaded: form_helper
INFO - 2024-10-24 15:24:52 --> Helper loaded: my_helper
INFO - 2024-10-24 15:24:52 --> Database Driver Class Initialized
INFO - 2024-10-24 15:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:24:52 --> Controller Class Initialized
INFO - 2024-10-24 15:24:56 --> Config Class Initialized
INFO - 2024-10-24 15:24:56 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:24:56 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:24:56 --> Utf8 Class Initialized
INFO - 2024-10-24 15:24:56 --> URI Class Initialized
INFO - 2024-10-24 15:24:56 --> Router Class Initialized
INFO - 2024-10-24 15:24:56 --> Output Class Initialized
INFO - 2024-10-24 15:24:56 --> Security Class Initialized
DEBUG - 2024-10-24 15:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:24:56 --> Input Class Initialized
INFO - 2024-10-24 15:24:56 --> Language Class Initialized
INFO - 2024-10-24 15:24:57 --> Language Class Initialized
INFO - 2024-10-24 15:24:57 --> Config Class Initialized
INFO - 2024-10-24 15:24:57 --> Loader Class Initialized
INFO - 2024-10-24 15:24:57 --> Helper loaded: url_helper
INFO - 2024-10-24 15:24:57 --> Helper loaded: file_helper
INFO - 2024-10-24 15:24:57 --> Helper loaded: form_helper
INFO - 2024-10-24 15:24:57 --> Helper loaded: my_helper
INFO - 2024-10-24 15:24:57 --> Database Driver Class Initialized
INFO - 2024-10-24 15:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:24:57 --> Controller Class Initialized
INFO - 2024-10-24 15:26:51 --> Config Class Initialized
INFO - 2024-10-24 15:26:51 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:26:51 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:26:51 --> Utf8 Class Initialized
INFO - 2024-10-24 15:26:51 --> URI Class Initialized
INFO - 2024-10-24 15:26:51 --> Router Class Initialized
INFO - 2024-10-24 15:26:51 --> Output Class Initialized
INFO - 2024-10-24 15:26:51 --> Security Class Initialized
DEBUG - 2024-10-24 15:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:26:51 --> Input Class Initialized
INFO - 2024-10-24 15:26:51 --> Language Class Initialized
INFO - 2024-10-24 15:26:51 --> Language Class Initialized
INFO - 2024-10-24 15:26:51 --> Config Class Initialized
INFO - 2024-10-24 15:26:51 --> Loader Class Initialized
INFO - 2024-10-24 15:26:51 --> Helper loaded: url_helper
INFO - 2024-10-24 15:26:51 --> Helper loaded: file_helper
INFO - 2024-10-24 15:26:51 --> Helper loaded: form_helper
INFO - 2024-10-24 15:26:51 --> Helper loaded: my_helper
INFO - 2024-10-24 15:26:51 --> Database Driver Class Initialized
INFO - 2024-10-24 15:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:26:51 --> Controller Class Initialized
DEBUG - 2024-10-24 15:26:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-10-24 15:26:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 15:26:51 --> Final output sent to browser
DEBUG - 2024-10-24 15:26:51 --> Total execution time: 0.0487
INFO - 2024-10-24 15:26:52 --> Config Class Initialized
INFO - 2024-10-24 15:26:52 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:26:52 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:26:52 --> Utf8 Class Initialized
INFO - 2024-10-24 15:26:52 --> URI Class Initialized
INFO - 2024-10-24 15:26:52 --> Router Class Initialized
INFO - 2024-10-24 15:26:52 --> Output Class Initialized
INFO - 2024-10-24 15:26:52 --> Security Class Initialized
DEBUG - 2024-10-24 15:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:26:52 --> Input Class Initialized
INFO - 2024-10-24 15:26:52 --> Language Class Initialized
INFO - 2024-10-24 15:26:52 --> Language Class Initialized
INFO - 2024-10-24 15:26:52 --> Config Class Initialized
INFO - 2024-10-24 15:26:52 --> Loader Class Initialized
INFO - 2024-10-24 15:26:52 --> Helper loaded: url_helper
INFO - 2024-10-24 15:26:52 --> Helper loaded: file_helper
INFO - 2024-10-24 15:26:52 --> Helper loaded: form_helper
INFO - 2024-10-24 15:26:52 --> Helper loaded: my_helper
INFO - 2024-10-24 15:26:52 --> Database Driver Class Initialized
INFO - 2024-10-24 15:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:26:52 --> Controller Class Initialized
INFO - 2024-10-24 15:26:52 --> Database Driver Class Initialized
INFO - 2024-10-24 15:26:52 --> Config Class Initialized
INFO - 2024-10-24 15:26:52 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:26:52 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:26:52 --> Utf8 Class Initialized
INFO - 2024-10-24 15:26:52 --> URI Class Initialized
INFO - 2024-10-24 15:26:52 --> Router Class Initialized
INFO - 2024-10-24 15:26:52 --> Output Class Initialized
INFO - 2024-10-24 15:26:52 --> Security Class Initialized
DEBUG - 2024-10-24 15:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:26:52 --> Input Class Initialized
INFO - 2024-10-24 15:26:52 --> Language Class Initialized
INFO - 2024-10-24 15:26:52 --> Language Class Initialized
INFO - 2024-10-24 15:26:52 --> Config Class Initialized
INFO - 2024-10-24 15:26:52 --> Loader Class Initialized
INFO - 2024-10-24 15:26:52 --> Helper loaded: url_helper
INFO - 2024-10-24 15:26:52 --> Helper loaded: file_helper
INFO - 2024-10-24 15:26:52 --> Helper loaded: form_helper
INFO - 2024-10-24 15:26:52 --> Helper loaded: my_helper
INFO - 2024-10-24 15:26:52 --> Database Driver Class Initialized
INFO - 2024-10-24 15:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:26:52 --> Controller Class Initialized
DEBUG - 2024-10-24 15:26:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-10-24 15:26:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 15:26:52 --> Final output sent to browser
DEBUG - 2024-10-24 15:26:52 --> Total execution time: 0.0505
INFO - 2024-10-24 15:51:23 --> Config Class Initialized
INFO - 2024-10-24 15:51:23 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:51:23 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:51:23 --> Utf8 Class Initialized
INFO - 2024-10-24 15:51:23 --> URI Class Initialized
INFO - 2024-10-24 15:51:23 --> Router Class Initialized
INFO - 2024-10-24 15:51:23 --> Output Class Initialized
INFO - 2024-10-24 15:51:23 --> Security Class Initialized
DEBUG - 2024-10-24 15:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:51:23 --> Input Class Initialized
INFO - 2024-10-24 15:51:23 --> Language Class Initialized
INFO - 2024-10-24 15:51:24 --> Language Class Initialized
INFO - 2024-10-24 15:51:24 --> Config Class Initialized
INFO - 2024-10-24 15:51:24 --> Loader Class Initialized
INFO - 2024-10-24 15:51:24 --> Helper loaded: url_helper
INFO - 2024-10-24 15:51:24 --> Helper loaded: file_helper
INFO - 2024-10-24 15:51:24 --> Helper loaded: form_helper
INFO - 2024-10-24 15:51:24 --> Helper loaded: my_helper
INFO - 2024-10-24 15:51:24 --> Database Driver Class Initialized
INFO - 2024-10-24 15:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:51:24 --> Controller Class Initialized
DEBUG - 2024-10-24 15:51:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-10-24 15:51:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 15:51:24 --> Final output sent to browser
DEBUG - 2024-10-24 15:51:24 --> Total execution time: 0.0949
INFO - 2024-10-24 18:20:17 --> Config Class Initialized
INFO - 2024-10-24 18:20:17 --> Hooks Class Initialized
DEBUG - 2024-10-24 18:20:17 --> UTF-8 Support Enabled
INFO - 2024-10-24 18:20:17 --> Utf8 Class Initialized
INFO - 2024-10-24 18:20:17 --> URI Class Initialized
INFO - 2024-10-24 18:20:17 --> Router Class Initialized
INFO - 2024-10-24 18:20:17 --> Output Class Initialized
INFO - 2024-10-24 18:20:17 --> Security Class Initialized
DEBUG - 2024-10-24 18:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 18:20:17 --> Input Class Initialized
INFO - 2024-10-24 18:20:17 --> Language Class Initialized
INFO - 2024-10-24 18:20:17 --> Language Class Initialized
INFO - 2024-10-24 18:20:17 --> Config Class Initialized
INFO - 2024-10-24 18:20:17 --> Loader Class Initialized
INFO - 2024-10-24 18:20:17 --> Helper loaded: url_helper
INFO - 2024-10-24 18:20:17 --> Helper loaded: file_helper
INFO - 2024-10-24 18:20:17 --> Helper loaded: form_helper
INFO - 2024-10-24 18:20:17 --> Helper loaded: my_helper
INFO - 2024-10-24 18:20:17 --> Database Driver Class Initialized
INFO - 2024-10-24 18:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 18:20:17 --> Controller Class Initialized
INFO - 2024-10-24 18:20:17 --> Final output sent to browser
DEBUG - 2024-10-24 18:20:17 --> Total execution time: 0.1392
INFO - 2024-10-24 23:17:04 --> Config Class Initialized
INFO - 2024-10-24 23:17:04 --> Hooks Class Initialized
DEBUG - 2024-10-24 23:17:04 --> UTF-8 Support Enabled
INFO - 2024-10-24 23:17:04 --> Utf8 Class Initialized
INFO - 2024-10-24 23:17:04 --> URI Class Initialized
INFO - 2024-10-24 23:17:04 --> Router Class Initialized
INFO - 2024-10-24 23:17:04 --> Output Class Initialized
INFO - 2024-10-24 23:17:04 --> Security Class Initialized
DEBUG - 2024-10-24 23:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 23:17:04 --> Input Class Initialized
INFO - 2024-10-24 23:17:04 --> Language Class Initialized
INFO - 2024-10-24 23:17:04 --> Language Class Initialized
INFO - 2024-10-24 23:17:04 --> Config Class Initialized
INFO - 2024-10-24 23:17:04 --> Loader Class Initialized
INFO - 2024-10-24 23:17:04 --> Helper loaded: url_helper
INFO - 2024-10-24 23:17:04 --> Helper loaded: file_helper
INFO - 2024-10-24 23:17:04 --> Helper loaded: form_helper
INFO - 2024-10-24 23:17:04 --> Helper loaded: my_helper
INFO - 2024-10-24 23:17:04 --> Database Driver Class Initialized
INFO - 2024-10-24 23:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 23:17:04 --> Controller Class Initialized
INFO - 2024-10-24 23:17:04 --> Helper loaded: cookie_helper
INFO - 2024-10-24 23:17:04 --> Final output sent to browser
DEBUG - 2024-10-24 23:17:04 --> Total execution time: 0.0797
INFO - 2024-10-24 23:17:04 --> Config Class Initialized
INFO - 2024-10-24 23:17:04 --> Hooks Class Initialized
DEBUG - 2024-10-24 23:17:04 --> UTF-8 Support Enabled
INFO - 2024-10-24 23:17:04 --> Utf8 Class Initialized
INFO - 2024-10-24 23:17:04 --> URI Class Initialized
INFO - 2024-10-24 23:17:04 --> Router Class Initialized
INFO - 2024-10-24 23:17:04 --> Output Class Initialized
INFO - 2024-10-24 23:17:04 --> Security Class Initialized
DEBUG - 2024-10-24 23:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 23:17:04 --> Input Class Initialized
INFO - 2024-10-24 23:17:04 --> Language Class Initialized
INFO - 2024-10-24 23:17:04 --> Language Class Initialized
INFO - 2024-10-24 23:17:04 --> Config Class Initialized
INFO - 2024-10-24 23:17:04 --> Loader Class Initialized
INFO - 2024-10-24 23:17:04 --> Helper loaded: url_helper
INFO - 2024-10-24 23:17:04 --> Helper loaded: file_helper
INFO - 2024-10-24 23:17:04 --> Helper loaded: form_helper
INFO - 2024-10-24 23:17:04 --> Helper loaded: my_helper
INFO - 2024-10-24 23:17:04 --> Database Driver Class Initialized
INFO - 2024-10-24 23:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 23:17:04 --> Controller Class Initialized
INFO - 2024-10-24 23:17:05 --> Helper loaded: cookie_helper
INFO - 2024-10-24 23:17:05 --> Config Class Initialized
INFO - 2024-10-24 23:17:05 --> Hooks Class Initialized
DEBUG - 2024-10-24 23:17:05 --> UTF-8 Support Enabled
INFO - 2024-10-24 23:17:05 --> Utf8 Class Initialized
INFO - 2024-10-24 23:17:05 --> URI Class Initialized
INFO - 2024-10-24 23:17:05 --> Router Class Initialized
INFO - 2024-10-24 23:17:05 --> Output Class Initialized
INFO - 2024-10-24 23:17:05 --> Security Class Initialized
DEBUG - 2024-10-24 23:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 23:17:05 --> Input Class Initialized
INFO - 2024-10-24 23:17:05 --> Language Class Initialized
INFO - 2024-10-24 23:17:05 --> Language Class Initialized
INFO - 2024-10-24 23:17:05 --> Config Class Initialized
INFO - 2024-10-24 23:17:05 --> Loader Class Initialized
INFO - 2024-10-24 23:17:05 --> Helper loaded: url_helper
INFO - 2024-10-24 23:17:05 --> Helper loaded: file_helper
INFO - 2024-10-24 23:17:05 --> Helper loaded: form_helper
INFO - 2024-10-24 23:17:05 --> Helper loaded: my_helper
INFO - 2024-10-24 23:17:05 --> Database Driver Class Initialized
INFO - 2024-10-24 23:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 23:17:05 --> Controller Class Initialized
DEBUG - 2024-10-24 23:17:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-24 23:17:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-24 23:17:05 --> Final output sent to browser
DEBUG - 2024-10-24 23:17:05 --> Total execution time: 0.0396
INFO - 2024-10-24 23:17:12 --> Config Class Initialized
INFO - 2024-10-24 23:17:12 --> Hooks Class Initialized
DEBUG - 2024-10-24 23:17:12 --> UTF-8 Support Enabled
INFO - 2024-10-24 23:17:12 --> Utf8 Class Initialized
INFO - 2024-10-24 23:17:12 --> URI Class Initialized
INFO - 2024-10-24 23:17:12 --> Router Class Initialized
INFO - 2024-10-24 23:17:12 --> Output Class Initialized
INFO - 2024-10-24 23:17:12 --> Security Class Initialized
DEBUG - 2024-10-24 23:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 23:17:12 --> Input Class Initialized
INFO - 2024-10-24 23:17:12 --> Language Class Initialized
INFO - 2024-10-24 23:17:12 --> Language Class Initialized
INFO - 2024-10-24 23:17:12 --> Config Class Initialized
INFO - 2024-10-24 23:17:12 --> Loader Class Initialized
INFO - 2024-10-24 23:17:12 --> Helper loaded: url_helper
INFO - 2024-10-24 23:17:12 --> Helper loaded: file_helper
INFO - 2024-10-24 23:17:12 --> Helper loaded: form_helper
INFO - 2024-10-24 23:17:12 --> Helper loaded: my_helper
INFO - 2024-10-24 23:17:12 --> Database Driver Class Initialized
INFO - 2024-10-24 23:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 23:17:12 --> Controller Class Initialized
DEBUG - 2024-10-24 23:17:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-24 23:17:15 --> Final output sent to browser
DEBUG - 2024-10-24 23:17:15 --> Total execution time: 3.2006
