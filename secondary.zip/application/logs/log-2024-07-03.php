<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-03 08:59:35 --> Config Class Initialized
INFO - 2024-07-03 08:59:35 --> Hooks Class Initialized
DEBUG - 2024-07-03 08:59:35 --> UTF-8 Support Enabled
INFO - 2024-07-03 08:59:35 --> Utf8 Class Initialized
INFO - 2024-07-03 08:59:35 --> URI Class Initialized
DEBUG - 2024-07-03 08:59:35 --> No URI present. Default controller set.
INFO - 2024-07-03 08:59:35 --> Router Class Initialized
INFO - 2024-07-03 08:59:35 --> Output Class Initialized
INFO - 2024-07-03 08:59:35 --> Security Class Initialized
DEBUG - 2024-07-03 08:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-03 08:59:35 --> Input Class Initialized
INFO - 2024-07-03 08:59:35 --> Language Class Initialized
INFO - 2024-07-03 08:59:35 --> Language Class Initialized
INFO - 2024-07-03 08:59:35 --> Config Class Initialized
INFO - 2024-07-03 08:59:35 --> Loader Class Initialized
INFO - 2024-07-03 08:59:35 --> Helper loaded: url_helper
INFO - 2024-07-03 08:59:35 --> Helper loaded: file_helper
INFO - 2024-07-03 08:59:35 --> Helper loaded: form_helper
INFO - 2024-07-03 08:59:35 --> Helper loaded: my_helper
INFO - 2024-07-03 08:59:35 --> Database Driver Class Initialized
INFO - 2024-07-03 08:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-03 08:59:35 --> Controller Class Initialized
DEBUG - 2024-07-03 08:59:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-07-03 08:59:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-03 08:59:35 --> Final output sent to browser
DEBUG - 2024-07-03 08:59:35 --> Total execution time: 0.0689
INFO - 2024-07-03 08:59:37 --> Config Class Initialized
INFO - 2024-07-03 08:59:37 --> Hooks Class Initialized
DEBUG - 2024-07-03 08:59:37 --> UTF-8 Support Enabled
INFO - 2024-07-03 08:59:37 --> Utf8 Class Initialized
INFO - 2024-07-03 08:59:37 --> URI Class Initialized
INFO - 2024-07-03 08:59:37 --> Router Class Initialized
INFO - 2024-07-03 08:59:37 --> Output Class Initialized
INFO - 2024-07-03 08:59:37 --> Security Class Initialized
DEBUG - 2024-07-03 08:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-03 08:59:37 --> Input Class Initialized
INFO - 2024-07-03 08:59:37 --> Language Class Initialized
INFO - 2024-07-03 08:59:37 --> Language Class Initialized
INFO - 2024-07-03 08:59:37 --> Config Class Initialized
INFO - 2024-07-03 08:59:37 --> Loader Class Initialized
INFO - 2024-07-03 08:59:37 --> Helper loaded: url_helper
INFO - 2024-07-03 08:59:37 --> Helper loaded: file_helper
INFO - 2024-07-03 08:59:37 --> Helper loaded: form_helper
INFO - 2024-07-03 08:59:37 --> Helper loaded: my_helper
INFO - 2024-07-03 08:59:37 --> Database Driver Class Initialized
INFO - 2024-07-03 08:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-03 08:59:37 --> Controller Class Initialized
DEBUG - 2024-07-03 08:59:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-07-03 08:59:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-03 08:59:37 --> Final output sent to browser
DEBUG - 2024-07-03 08:59:37 --> Total execution time: 0.0299
INFO - 2024-07-03 08:59:37 --> Config Class Initialized
INFO - 2024-07-03 08:59:37 --> Hooks Class Initialized
DEBUG - 2024-07-03 08:59:37 --> UTF-8 Support Enabled
INFO - 2024-07-03 08:59:37 --> Utf8 Class Initialized
INFO - 2024-07-03 08:59:37 --> URI Class Initialized
INFO - 2024-07-03 08:59:37 --> Router Class Initialized
INFO - 2024-07-03 08:59:37 --> Output Class Initialized
INFO - 2024-07-03 08:59:37 --> Security Class Initialized
DEBUG - 2024-07-03 08:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-03 08:59:37 --> Input Class Initialized
INFO - 2024-07-03 08:59:37 --> Language Class Initialized
ERROR - 2024-07-03 08:59:37 --> 404 Page Not Found: /index
INFO - 2024-07-03 08:59:37 --> Config Class Initialized
INFO - 2024-07-03 08:59:37 --> Hooks Class Initialized
DEBUG - 2024-07-03 08:59:37 --> UTF-8 Support Enabled
INFO - 2024-07-03 08:59:37 --> Utf8 Class Initialized
INFO - 2024-07-03 08:59:37 --> URI Class Initialized
INFO - 2024-07-03 08:59:37 --> Router Class Initialized
INFO - 2024-07-03 08:59:37 --> Output Class Initialized
INFO - 2024-07-03 08:59:37 --> Security Class Initialized
DEBUG - 2024-07-03 08:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-03 08:59:37 --> Input Class Initialized
INFO - 2024-07-03 08:59:37 --> Language Class Initialized
INFO - 2024-07-03 08:59:37 --> Language Class Initialized
INFO - 2024-07-03 08:59:37 --> Config Class Initialized
INFO - 2024-07-03 08:59:37 --> Loader Class Initialized
INFO - 2024-07-03 08:59:37 --> Helper loaded: url_helper
INFO - 2024-07-03 08:59:37 --> Helper loaded: file_helper
INFO - 2024-07-03 08:59:37 --> Helper loaded: form_helper
INFO - 2024-07-03 08:59:37 --> Helper loaded: my_helper
INFO - 2024-07-03 08:59:37 --> Database Driver Class Initialized
INFO - 2024-07-03 08:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-03 08:59:37 --> Controller Class Initialized
INFO - 2024-07-03 08:59:40 --> Config Class Initialized
INFO - 2024-07-03 08:59:40 --> Hooks Class Initialized
DEBUG - 2024-07-03 08:59:40 --> UTF-8 Support Enabled
INFO - 2024-07-03 08:59:40 --> Utf8 Class Initialized
INFO - 2024-07-03 08:59:40 --> URI Class Initialized
INFO - 2024-07-03 08:59:40 --> Router Class Initialized
INFO - 2024-07-03 08:59:40 --> Output Class Initialized
INFO - 2024-07-03 08:59:40 --> Security Class Initialized
DEBUG - 2024-07-03 08:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-03 08:59:40 --> Input Class Initialized
INFO - 2024-07-03 08:59:40 --> Language Class Initialized
INFO - 2024-07-03 08:59:40 --> Language Class Initialized
INFO - 2024-07-03 08:59:40 --> Config Class Initialized
INFO - 2024-07-03 08:59:40 --> Loader Class Initialized
INFO - 2024-07-03 08:59:40 --> Helper loaded: url_helper
INFO - 2024-07-03 08:59:40 --> Helper loaded: file_helper
INFO - 2024-07-03 08:59:40 --> Helper loaded: form_helper
INFO - 2024-07-03 08:59:40 --> Helper loaded: my_helper
INFO - 2024-07-03 08:59:40 --> Database Driver Class Initialized
INFO - 2024-07-03 08:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-03 08:59:40 --> Controller Class Initialized
DEBUG - 2024-07-03 08:59:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-03 08:59:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-03 08:59:40 --> Final output sent to browser
DEBUG - 2024-07-03 08:59:40 --> Total execution time: 0.0382
INFO - 2024-07-03 08:59:42 --> Config Class Initialized
INFO - 2024-07-03 08:59:42 --> Hooks Class Initialized
DEBUG - 2024-07-03 08:59:42 --> UTF-8 Support Enabled
INFO - 2024-07-03 08:59:42 --> Utf8 Class Initialized
INFO - 2024-07-03 08:59:42 --> URI Class Initialized
INFO - 2024-07-03 08:59:42 --> Router Class Initialized
INFO - 2024-07-03 08:59:42 --> Output Class Initialized
INFO - 2024-07-03 08:59:42 --> Security Class Initialized
DEBUG - 2024-07-03 08:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-03 08:59:42 --> Input Class Initialized
INFO - 2024-07-03 08:59:42 --> Language Class Initialized
INFO - 2024-07-03 08:59:42 --> Language Class Initialized
INFO - 2024-07-03 08:59:42 --> Config Class Initialized
INFO - 2024-07-03 08:59:42 --> Loader Class Initialized
INFO - 2024-07-03 08:59:42 --> Helper loaded: url_helper
INFO - 2024-07-03 08:59:42 --> Helper loaded: file_helper
INFO - 2024-07-03 08:59:42 --> Helper loaded: form_helper
INFO - 2024-07-03 08:59:42 --> Helper loaded: my_helper
INFO - 2024-07-03 08:59:42 --> Database Driver Class Initialized
INFO - 2024-07-03 08:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-03 08:59:42 --> Controller Class Initialized
DEBUG - 2024-07-03 08:59:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php
DEBUG - 2024-07-03 08:59:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-03 08:59:42 --> Final output sent to browser
DEBUG - 2024-07-03 08:59:42 --> Total execution time: 0.0323
INFO - 2024-07-03 11:48:13 --> Config Class Initialized
INFO - 2024-07-03 11:48:13 --> Hooks Class Initialized
DEBUG - 2024-07-03 11:48:13 --> UTF-8 Support Enabled
INFO - 2024-07-03 11:48:13 --> Utf8 Class Initialized
INFO - 2024-07-03 11:48:13 --> URI Class Initialized
INFO - 2024-07-03 11:48:13 --> Router Class Initialized
INFO - 2024-07-03 11:48:13 --> Output Class Initialized
INFO - 2024-07-03 11:48:13 --> Security Class Initialized
DEBUG - 2024-07-03 11:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-03 11:48:13 --> Input Class Initialized
INFO - 2024-07-03 11:48:13 --> Language Class Initialized
INFO - 2024-07-03 11:48:13 --> Language Class Initialized
INFO - 2024-07-03 11:48:13 --> Config Class Initialized
INFO - 2024-07-03 11:48:13 --> Loader Class Initialized
INFO - 2024-07-03 11:48:13 --> Helper loaded: url_helper
INFO - 2024-07-03 11:48:13 --> Helper loaded: file_helper
INFO - 2024-07-03 11:48:13 --> Helper loaded: form_helper
INFO - 2024-07-03 11:48:13 --> Helper loaded: my_helper
INFO - 2024-07-03 11:48:13 --> Database Driver Class Initialized
INFO - 2024-07-03 11:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-03 11:48:13 --> Controller Class Initialized
DEBUG - 2024-07-03 11:48:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-03 11:48:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-03 11:48:13 --> Final output sent to browser
DEBUG - 2024-07-03 11:48:13 --> Total execution time: 0.0554
INFO - 2024-07-03 11:48:15 --> Config Class Initialized
INFO - 2024-07-03 11:48:15 --> Hooks Class Initialized
DEBUG - 2024-07-03 11:48:15 --> UTF-8 Support Enabled
INFO - 2024-07-03 11:48:15 --> Utf8 Class Initialized
INFO - 2024-07-03 11:48:15 --> URI Class Initialized
INFO - 2024-07-03 11:48:15 --> Router Class Initialized
INFO - 2024-07-03 11:48:15 --> Output Class Initialized
INFO - 2024-07-03 11:48:15 --> Security Class Initialized
DEBUG - 2024-07-03 11:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-03 11:48:15 --> Input Class Initialized
INFO - 2024-07-03 11:48:15 --> Language Class Initialized
INFO - 2024-07-03 11:48:15 --> Language Class Initialized
INFO - 2024-07-03 11:48:15 --> Config Class Initialized
INFO - 2024-07-03 11:48:15 --> Loader Class Initialized
INFO - 2024-07-03 11:48:15 --> Helper loaded: url_helper
INFO - 2024-07-03 11:48:15 --> Helper loaded: file_helper
INFO - 2024-07-03 11:48:15 --> Helper loaded: form_helper
INFO - 2024-07-03 11:48:15 --> Helper loaded: my_helper
INFO - 2024-07-03 11:48:15 --> Database Driver Class Initialized
INFO - 2024-07-03 11:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-03 11:48:15 --> Controller Class Initialized
DEBUG - 2024-07-03 11:48:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-07-03 11:48:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-03 11:48:16 --> Final output sent to browser
DEBUG - 2024-07-03 11:48:16 --> Total execution time: 0.0385
INFO - 2024-07-03 11:48:16 --> Config Class Initialized
INFO - 2024-07-03 11:48:16 --> Hooks Class Initialized
DEBUG - 2024-07-03 11:48:16 --> UTF-8 Support Enabled
INFO - 2024-07-03 11:48:16 --> Utf8 Class Initialized
INFO - 2024-07-03 11:48:16 --> URI Class Initialized
INFO - 2024-07-03 11:48:16 --> Router Class Initialized
INFO - 2024-07-03 11:48:16 --> Output Class Initialized
INFO - 2024-07-03 11:48:16 --> Security Class Initialized
DEBUG - 2024-07-03 11:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-03 11:48:16 --> Input Class Initialized
INFO - 2024-07-03 11:48:16 --> Language Class Initialized
ERROR - 2024-07-03 11:48:16 --> 404 Page Not Found: /index
INFO - 2024-07-03 11:48:16 --> Config Class Initialized
INFO - 2024-07-03 11:48:16 --> Hooks Class Initialized
DEBUG - 2024-07-03 11:48:16 --> UTF-8 Support Enabled
INFO - 2024-07-03 11:48:16 --> Utf8 Class Initialized
INFO - 2024-07-03 11:48:16 --> URI Class Initialized
INFO - 2024-07-03 11:48:16 --> Router Class Initialized
INFO - 2024-07-03 11:48:16 --> Output Class Initialized
INFO - 2024-07-03 11:48:16 --> Security Class Initialized
DEBUG - 2024-07-03 11:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-03 11:48:16 --> Input Class Initialized
INFO - 2024-07-03 11:48:16 --> Language Class Initialized
INFO - 2024-07-03 11:48:16 --> Language Class Initialized
INFO - 2024-07-03 11:48:16 --> Config Class Initialized
INFO - 2024-07-03 11:48:16 --> Loader Class Initialized
INFO - 2024-07-03 11:48:16 --> Helper loaded: url_helper
INFO - 2024-07-03 11:48:16 --> Helper loaded: file_helper
INFO - 2024-07-03 11:48:16 --> Helper loaded: form_helper
INFO - 2024-07-03 11:48:16 --> Helper loaded: my_helper
INFO - 2024-07-03 11:48:16 --> Database Driver Class Initialized
INFO - 2024-07-03 11:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-03 11:48:16 --> Controller Class Initialized
