<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-30 09:52:51 --> Config Class Initialized
INFO - 2024-07-30 09:52:51 --> Hooks Class Initialized
DEBUG - 2024-07-30 09:52:51 --> UTF-8 Support Enabled
INFO - 2024-07-30 09:52:51 --> Utf8 Class Initialized
INFO - 2024-07-30 09:52:51 --> URI Class Initialized
INFO - 2024-07-30 09:52:51 --> Router Class Initialized
INFO - 2024-07-30 09:52:51 --> Output Class Initialized
INFO - 2024-07-30 09:52:51 --> Security Class Initialized
DEBUG - 2024-07-30 09:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 09:52:51 --> Input Class Initialized
INFO - 2024-07-30 09:52:51 --> Language Class Initialized
INFO - 2024-07-30 09:52:51 --> Language Class Initialized
INFO - 2024-07-30 09:52:51 --> Config Class Initialized
INFO - 2024-07-30 09:52:51 --> Loader Class Initialized
INFO - 2024-07-30 09:52:51 --> Helper loaded: url_helper
INFO - 2024-07-30 09:52:51 --> Helper loaded: file_helper
INFO - 2024-07-30 09:52:51 --> Helper loaded: form_helper
INFO - 2024-07-30 09:52:51 --> Helper loaded: my_helper
INFO - 2024-07-30 09:52:51 --> Database Driver Class Initialized
INFO - 2024-07-30 09:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 09:52:51 --> Controller Class Initialized
INFO - 2024-07-30 09:52:51 --> Helper loaded: cookie_helper
INFO - 2024-07-30 09:52:51 --> Final output sent to browser
DEBUG - 2024-07-30 09:52:51 --> Total execution time: 0.0542
INFO - 2024-07-30 09:52:52 --> Config Class Initialized
INFO - 2024-07-30 09:52:52 --> Hooks Class Initialized
DEBUG - 2024-07-30 09:52:52 --> UTF-8 Support Enabled
INFO - 2024-07-30 09:52:52 --> Utf8 Class Initialized
INFO - 2024-07-30 09:52:52 --> URI Class Initialized
INFO - 2024-07-30 09:52:52 --> Router Class Initialized
INFO - 2024-07-30 09:52:52 --> Output Class Initialized
INFO - 2024-07-30 09:52:52 --> Security Class Initialized
DEBUG - 2024-07-30 09:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 09:52:52 --> Input Class Initialized
INFO - 2024-07-30 09:52:52 --> Language Class Initialized
INFO - 2024-07-30 09:52:52 --> Language Class Initialized
INFO - 2024-07-30 09:52:52 --> Config Class Initialized
INFO - 2024-07-30 09:52:52 --> Loader Class Initialized
INFO - 2024-07-30 09:52:52 --> Helper loaded: url_helper
INFO - 2024-07-30 09:52:52 --> Helper loaded: file_helper
INFO - 2024-07-30 09:52:52 --> Helper loaded: form_helper
INFO - 2024-07-30 09:52:52 --> Helper loaded: my_helper
INFO - 2024-07-30 09:52:52 --> Database Driver Class Initialized
INFO - 2024-07-30 09:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 09:52:52 --> Controller Class Initialized
INFO - 2024-07-30 09:52:52 --> Helper loaded: cookie_helper
INFO - 2024-07-30 09:52:52 --> Config Class Initialized
INFO - 2024-07-30 09:52:52 --> Hooks Class Initialized
DEBUG - 2024-07-30 09:52:52 --> UTF-8 Support Enabled
INFO - 2024-07-30 09:52:52 --> Utf8 Class Initialized
INFO - 2024-07-30 09:52:52 --> URI Class Initialized
INFO - 2024-07-30 09:52:52 --> Router Class Initialized
INFO - 2024-07-30 09:52:52 --> Output Class Initialized
INFO - 2024-07-30 09:52:52 --> Security Class Initialized
DEBUG - 2024-07-30 09:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 09:52:52 --> Input Class Initialized
INFO - 2024-07-30 09:52:52 --> Language Class Initialized
INFO - 2024-07-30 09:52:52 --> Language Class Initialized
INFO - 2024-07-30 09:52:52 --> Config Class Initialized
INFO - 2024-07-30 09:52:52 --> Loader Class Initialized
INFO - 2024-07-30 09:52:52 --> Helper loaded: url_helper
INFO - 2024-07-30 09:52:52 --> Helper loaded: file_helper
INFO - 2024-07-30 09:52:52 --> Helper loaded: form_helper
INFO - 2024-07-30 09:52:52 --> Helper loaded: my_helper
INFO - 2024-07-30 09:52:52 --> Database Driver Class Initialized
INFO - 2024-07-30 09:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 09:52:52 --> Controller Class Initialized
DEBUG - 2024-07-30 09:52:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-30 09:52:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-30 09:52:52 --> Final output sent to browser
DEBUG - 2024-07-30 09:52:52 --> Total execution time: 0.0495
INFO - 2024-07-30 09:52:59 --> Config Class Initialized
INFO - 2024-07-30 09:52:59 --> Hooks Class Initialized
DEBUG - 2024-07-30 09:52:59 --> UTF-8 Support Enabled
INFO - 2024-07-30 09:52:59 --> Utf8 Class Initialized
INFO - 2024-07-30 09:52:59 --> URI Class Initialized
INFO - 2024-07-30 09:52:59 --> Router Class Initialized
INFO - 2024-07-30 09:52:59 --> Output Class Initialized
INFO - 2024-07-30 09:52:59 --> Security Class Initialized
DEBUG - 2024-07-30 09:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 09:52:59 --> Input Class Initialized
INFO - 2024-07-30 09:52:59 --> Language Class Initialized
INFO - 2024-07-30 09:52:59 --> Language Class Initialized
INFO - 2024-07-30 09:52:59 --> Config Class Initialized
INFO - 2024-07-30 09:52:59 --> Loader Class Initialized
INFO - 2024-07-30 09:52:59 --> Helper loaded: url_helper
INFO - 2024-07-30 09:52:59 --> Helper loaded: file_helper
INFO - 2024-07-30 09:52:59 --> Helper loaded: form_helper
INFO - 2024-07-30 09:52:59 --> Helper loaded: my_helper
INFO - 2024-07-30 09:52:59 --> Database Driver Class Initialized
INFO - 2024-07-30 09:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 09:52:59 --> Controller Class Initialized
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 97
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 614
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 614
ERROR - 2024-07-30 09:52:59 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 614
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 651
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 651
ERROR - 2024-07-30 09:52:59 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 651
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Undefined offset: 17 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 689
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 689
ERROR - 2024-07-30 09:52:59 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 689
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 905
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-30 09:52:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-30 09:52:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-07-30 09:53:02 --> Config Class Initialized
INFO - 2024-07-30 09:53:02 --> Hooks Class Initialized
DEBUG - 2024-07-30 09:53:02 --> UTF-8 Support Enabled
INFO - 2024-07-30 09:53:02 --> Utf8 Class Initialized
INFO - 2024-07-30 09:53:02 --> URI Class Initialized
INFO - 2024-07-30 09:53:02 --> Router Class Initialized
INFO - 2024-07-30 09:53:02 --> Output Class Initialized
INFO - 2024-07-30 09:53:02 --> Security Class Initialized
DEBUG - 2024-07-30 09:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 09:53:02 --> Input Class Initialized
INFO - 2024-07-30 09:53:02 --> Language Class Initialized
INFO - 2024-07-30 09:53:02 --> Language Class Initialized
INFO - 2024-07-30 09:53:02 --> Config Class Initialized
INFO - 2024-07-30 09:53:02 --> Loader Class Initialized
INFO - 2024-07-30 09:53:02 --> Helper loaded: url_helper
INFO - 2024-07-30 09:53:02 --> Helper loaded: file_helper
INFO - 2024-07-30 09:53:02 --> Helper loaded: form_helper
INFO - 2024-07-30 09:53:02 --> Helper loaded: my_helper
INFO - 2024-07-30 09:53:02 --> Database Driver Class Initialized
ERROR - 2024-07-30 09:53:03 --> Severity: error --> Exception: The content of the TD tag does not fit on only one page /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/spipu/html2pdf/src/Html2Pdf.php 5680
ERROR - 2024-07-30 09:53:03 --> Severity: Warning --> unlink(/tmp/__tcpdf_87f4c6293b04eb0af156cf158b34551a_imgmask_alpha_5c8c5820de2d21abc04c055a7edbdf01): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/tecnickcom/tcpdf/tcpdf.php 7801
ERROR - 2024-07-30 09:53:03 --> Severity: Warning --> unlink(/tmp/__tcpdf_87f4c6293b04eb0af156cf158b34551a_imgmask_plain_5c8c5820de2d21abc04c055a7edbdf01): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/tecnickcom/tcpdf/tcpdf.php 7801
ERROR - 2024-07-30 09:53:03 --> Severity: Warning --> unlink(/tmp/__tcpdf_87f4c6293b04eb0af156cf158b34551a_imgmask_alpha_9b9826062a8f1eb306f7a4635f009d01): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/tecnickcom/tcpdf/tcpdf.php 7801
ERROR - 2024-07-30 09:53:03 --> Severity: Warning --> unlink(/tmp/__tcpdf_87f4c6293b04eb0af156cf158b34551a_imgmask_plain_9b9826062a8f1eb306f7a4635f009d01): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/tecnickcom/tcpdf/tcpdf.php 7801
INFO - 2024-07-30 09:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 09:53:03 --> Controller Class Initialized
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 97
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 614
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 614
ERROR - 2024-07-30 09:53:03 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 614
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 651
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 651
ERROR - 2024-07-30 09:53:03 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 651
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Undefined offset: 17 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 689
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 689
ERROR - 2024-07-30 09:53:03 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 689
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 905
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-30 09:53:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-30 09:53:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
ERROR - 2024-07-30 09:53:08 --> Severity: error --> Exception: The content of the TD tag does not fit on only one page /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/spipu/html2pdf/src/Html2Pdf.php 5680
ERROR - 2024-07-30 09:53:08 --> Severity: Warning --> unlink(/tmp/__tcpdf_24d2c29728e23a5c0f24b15dd7ad59f1_imgmask_alpha_5c8c5820de2d21abc04c055a7edbdf01): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/tecnickcom/tcpdf/tcpdf.php 7801
ERROR - 2024-07-30 09:53:08 --> Severity: Warning --> unlink(/tmp/__tcpdf_24d2c29728e23a5c0f24b15dd7ad59f1_imgmask_plain_5c8c5820de2d21abc04c055a7edbdf01): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/tecnickcom/tcpdf/tcpdf.php 7801
ERROR - 2024-07-30 09:53:08 --> Severity: Warning --> unlink(/tmp/__tcpdf_24d2c29728e23a5c0f24b15dd7ad59f1_imgmask_alpha_9b9826062a8f1eb306f7a4635f009d01): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/tecnickcom/tcpdf/tcpdf.php 7801
ERROR - 2024-07-30 09:53:08 --> Severity: Warning --> unlink(/tmp/__tcpdf_24d2c29728e23a5c0f24b15dd7ad59f1_imgmask_plain_9b9826062a8f1eb306f7a4635f009d01): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/tecnickcom/tcpdf/tcpdf.php 7801
INFO - 2024-07-30 10:17:01 --> Config Class Initialized
INFO - 2024-07-30 10:17:01 --> Hooks Class Initialized
DEBUG - 2024-07-30 10:17:01 --> UTF-8 Support Enabled
INFO - 2024-07-30 10:17:01 --> Utf8 Class Initialized
INFO - 2024-07-30 10:17:01 --> URI Class Initialized
INFO - 2024-07-30 10:17:01 --> Router Class Initialized
INFO - 2024-07-30 10:17:01 --> Output Class Initialized
INFO - 2024-07-30 10:17:01 --> Security Class Initialized
DEBUG - 2024-07-30 10:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 10:17:01 --> Input Class Initialized
INFO - 2024-07-30 10:17:01 --> Language Class Initialized
INFO - 2024-07-30 10:17:01 --> Language Class Initialized
INFO - 2024-07-30 10:17:01 --> Config Class Initialized
INFO - 2024-07-30 10:17:01 --> Loader Class Initialized
INFO - 2024-07-30 10:17:01 --> Helper loaded: url_helper
INFO - 2024-07-30 10:17:01 --> Helper loaded: file_helper
INFO - 2024-07-30 10:17:01 --> Helper loaded: form_helper
INFO - 2024-07-30 10:17:01 --> Helper loaded: my_helper
INFO - 2024-07-30 10:17:01 --> Database Driver Class Initialized
INFO - 2024-07-30 10:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 10:17:01 --> Controller Class Initialized
INFO - 2024-07-30 10:17:01 --> Helper loaded: cookie_helper
INFO - 2024-07-30 10:17:01 --> Final output sent to browser
DEBUG - 2024-07-30 10:17:01 --> Total execution time: 0.0797
INFO - 2024-07-30 10:17:01 --> Config Class Initialized
INFO - 2024-07-30 10:17:01 --> Hooks Class Initialized
DEBUG - 2024-07-30 10:17:01 --> UTF-8 Support Enabled
INFO - 2024-07-30 10:17:01 --> Utf8 Class Initialized
INFO - 2024-07-30 10:17:01 --> URI Class Initialized
INFO - 2024-07-30 10:17:01 --> Router Class Initialized
INFO - 2024-07-30 10:17:01 --> Output Class Initialized
INFO - 2024-07-30 10:17:01 --> Security Class Initialized
DEBUG - 2024-07-30 10:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 10:17:01 --> Input Class Initialized
INFO - 2024-07-30 10:17:01 --> Language Class Initialized
INFO - 2024-07-30 10:17:01 --> Language Class Initialized
INFO - 2024-07-30 10:17:01 --> Config Class Initialized
INFO - 2024-07-30 10:17:01 --> Loader Class Initialized
INFO - 2024-07-30 10:17:01 --> Helper loaded: url_helper
INFO - 2024-07-30 10:17:01 --> Helper loaded: file_helper
INFO - 2024-07-30 10:17:01 --> Helper loaded: form_helper
INFO - 2024-07-30 10:17:01 --> Helper loaded: my_helper
INFO - 2024-07-30 10:17:01 --> Database Driver Class Initialized
INFO - 2024-07-30 10:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 10:17:01 --> Controller Class Initialized
INFO - 2024-07-30 10:17:01 --> Helper loaded: cookie_helper
INFO - 2024-07-30 10:17:01 --> Config Class Initialized
INFO - 2024-07-30 10:17:01 --> Hooks Class Initialized
DEBUG - 2024-07-30 10:17:01 --> UTF-8 Support Enabled
INFO - 2024-07-30 10:17:01 --> Utf8 Class Initialized
INFO - 2024-07-30 10:17:01 --> URI Class Initialized
INFO - 2024-07-30 10:17:01 --> Router Class Initialized
INFO - 2024-07-30 10:17:01 --> Output Class Initialized
INFO - 2024-07-30 10:17:01 --> Security Class Initialized
DEBUG - 2024-07-30 10:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 10:17:01 --> Input Class Initialized
INFO - 2024-07-30 10:17:01 --> Language Class Initialized
INFO - 2024-07-30 10:17:01 --> Language Class Initialized
INFO - 2024-07-30 10:17:01 --> Config Class Initialized
INFO - 2024-07-30 10:17:01 --> Loader Class Initialized
INFO - 2024-07-30 10:17:01 --> Helper loaded: url_helper
INFO - 2024-07-30 10:17:01 --> Helper loaded: file_helper
INFO - 2024-07-30 10:17:01 --> Helper loaded: form_helper
INFO - 2024-07-30 10:17:01 --> Helper loaded: my_helper
INFO - 2024-07-30 10:17:01 --> Database Driver Class Initialized
INFO - 2024-07-30 10:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 10:17:01 --> Controller Class Initialized
DEBUG - 2024-07-30 10:17:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-30 10:17:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-30 10:17:01 --> Final output sent to browser
DEBUG - 2024-07-30 10:17:01 --> Total execution time: 0.0435
INFO - 2024-07-30 12:22:01 --> Config Class Initialized
INFO - 2024-07-30 12:22:01 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:22:01 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:22:01 --> Utf8 Class Initialized
INFO - 2024-07-30 12:22:01 --> URI Class Initialized
INFO - 2024-07-30 12:22:01 --> Router Class Initialized
INFO - 2024-07-30 12:22:01 --> Output Class Initialized
INFO - 2024-07-30 12:22:01 --> Security Class Initialized
DEBUG - 2024-07-30 12:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:22:01 --> Input Class Initialized
INFO - 2024-07-30 12:22:01 --> Language Class Initialized
INFO - 2024-07-30 12:22:01 --> Language Class Initialized
INFO - 2024-07-30 12:22:01 --> Config Class Initialized
INFO - 2024-07-30 12:22:01 --> Loader Class Initialized
INFO - 2024-07-30 12:22:01 --> Helper loaded: url_helper
INFO - 2024-07-30 12:22:01 --> Helper loaded: file_helper
INFO - 2024-07-30 12:22:01 --> Helper loaded: form_helper
INFO - 2024-07-30 12:22:01 --> Helper loaded: my_helper
INFO - 2024-07-30 12:22:01 --> Database Driver Class Initialized
INFO - 2024-07-30 12:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:22:01 --> Controller Class Initialized
DEBUG - 2024-07-30 12:22:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-07-30 12:22:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-30 12:22:01 --> Final output sent to browser
DEBUG - 2024-07-30 12:22:01 --> Total execution time: 0.0876
INFO - 2024-07-30 12:33:28 --> Config Class Initialized
INFO - 2024-07-30 12:33:28 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:33:28 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:33:28 --> Utf8 Class Initialized
INFO - 2024-07-30 12:33:28 --> URI Class Initialized
INFO - 2024-07-30 12:33:28 --> Router Class Initialized
INFO - 2024-07-30 12:33:28 --> Output Class Initialized
INFO - 2024-07-30 12:33:28 --> Security Class Initialized
DEBUG - 2024-07-30 12:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:33:28 --> Input Class Initialized
INFO - 2024-07-30 12:33:28 --> Language Class Initialized
INFO - 2024-07-30 12:33:28 --> Language Class Initialized
INFO - 2024-07-30 12:33:28 --> Config Class Initialized
INFO - 2024-07-30 12:33:28 --> Loader Class Initialized
INFO - 2024-07-30 12:33:28 --> Helper loaded: url_helper
INFO - 2024-07-30 12:33:28 --> Helper loaded: file_helper
INFO - 2024-07-30 12:33:28 --> Helper loaded: form_helper
INFO - 2024-07-30 12:33:28 --> Helper loaded: my_helper
INFO - 2024-07-30 12:33:28 --> Database Driver Class Initialized
INFO - 2024-07-30 12:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:33:28 --> Controller Class Initialized
INFO - 2024-07-30 12:33:28 --> Helper loaded: cookie_helper
INFO - 2024-07-30 12:33:28 --> Final output sent to browser
DEBUG - 2024-07-30 12:33:28 --> Total execution time: 0.0665
INFO - 2024-07-30 12:33:28 --> Config Class Initialized
INFO - 2024-07-30 12:33:28 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:33:28 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:33:28 --> Utf8 Class Initialized
INFO - 2024-07-30 12:33:28 --> URI Class Initialized
INFO - 2024-07-30 12:33:28 --> Router Class Initialized
INFO - 2024-07-30 12:33:28 --> Output Class Initialized
INFO - 2024-07-30 12:33:28 --> Security Class Initialized
DEBUG - 2024-07-30 12:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:33:28 --> Input Class Initialized
INFO - 2024-07-30 12:33:28 --> Language Class Initialized
INFO - 2024-07-30 12:33:28 --> Language Class Initialized
INFO - 2024-07-30 12:33:28 --> Config Class Initialized
INFO - 2024-07-30 12:33:28 --> Loader Class Initialized
INFO - 2024-07-30 12:33:28 --> Helper loaded: url_helper
INFO - 2024-07-30 12:33:28 --> Helper loaded: file_helper
INFO - 2024-07-30 12:33:28 --> Helper loaded: form_helper
INFO - 2024-07-30 12:33:28 --> Helper loaded: my_helper
INFO - 2024-07-30 12:33:28 --> Database Driver Class Initialized
INFO - 2024-07-30 12:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:33:28 --> Controller Class Initialized
INFO - 2024-07-30 12:33:28 --> Helper loaded: cookie_helper
INFO - 2024-07-30 12:33:28 --> Config Class Initialized
INFO - 2024-07-30 12:33:28 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:33:28 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:33:28 --> Utf8 Class Initialized
INFO - 2024-07-30 12:33:28 --> URI Class Initialized
INFO - 2024-07-30 12:33:28 --> Router Class Initialized
INFO - 2024-07-30 12:33:28 --> Output Class Initialized
INFO - 2024-07-30 12:33:28 --> Security Class Initialized
DEBUG - 2024-07-30 12:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:33:28 --> Input Class Initialized
INFO - 2024-07-30 12:33:28 --> Language Class Initialized
INFO - 2024-07-30 12:33:28 --> Language Class Initialized
INFO - 2024-07-30 12:33:28 --> Config Class Initialized
INFO - 2024-07-30 12:33:28 --> Loader Class Initialized
INFO - 2024-07-30 12:33:28 --> Helper loaded: url_helper
INFO - 2024-07-30 12:33:28 --> Helper loaded: file_helper
INFO - 2024-07-30 12:33:28 --> Helper loaded: form_helper
INFO - 2024-07-30 12:33:28 --> Helper loaded: my_helper
INFO - 2024-07-30 12:33:28 --> Database Driver Class Initialized
INFO - 2024-07-30 12:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:33:28 --> Controller Class Initialized
DEBUG - 2024-07-30 12:33:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-30 12:33:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-30 12:33:28 --> Final output sent to browser
DEBUG - 2024-07-30 12:33:28 --> Total execution time: 0.0744
INFO - 2024-07-30 12:33:41 --> Config Class Initialized
INFO - 2024-07-30 12:33:41 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:33:41 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:33:41 --> Utf8 Class Initialized
INFO - 2024-07-30 12:33:41 --> URI Class Initialized
INFO - 2024-07-30 12:33:41 --> Router Class Initialized
INFO - 2024-07-30 12:33:41 --> Output Class Initialized
INFO - 2024-07-30 12:33:41 --> Security Class Initialized
DEBUG - 2024-07-30 12:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:33:41 --> Input Class Initialized
INFO - 2024-07-30 12:33:41 --> Language Class Initialized
INFO - 2024-07-30 12:33:41 --> Language Class Initialized
INFO - 2024-07-30 12:33:41 --> Config Class Initialized
INFO - 2024-07-30 12:33:41 --> Loader Class Initialized
INFO - 2024-07-30 12:33:41 --> Helper loaded: url_helper
INFO - 2024-07-30 12:33:41 --> Helper loaded: file_helper
INFO - 2024-07-30 12:33:41 --> Helper loaded: form_helper
INFO - 2024-07-30 12:33:41 --> Helper loaded: my_helper
INFO - 2024-07-30 12:33:41 --> Database Driver Class Initialized
INFO - 2024-07-30 12:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:33:41 --> Controller Class Initialized
ERROR - 2024-07-30 12:33:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1156
ERROR - 2024-07-30 12:33:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1688
ERROR - 2024-07-30 12:33:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1725
ERROR - 2024-07-30 12:33:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1763
ERROR - 2024-07-30 12:33:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1802
ERROR - 2024-07-30 12:33:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1879
ERROR - 2024-07-30 12:33:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1958
ERROR - 2024-07-30 12:33:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2038
ERROR - 2024-07-30 12:33:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2118
ERROR - 2024-07-30 12:33:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2198
ERROR - 2024-07-30 12:33:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2273
ERROR - 2024-07-30 12:33:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-07-30 12:33:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 12:33:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 12:33:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-30 12:33:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-07-30 12:33:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-30 12:33:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-30 12:33:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-07-30 12:33:42 --> Config Class Initialized
INFO - 2024-07-30 12:33:42 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:33:42 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:33:42 --> Utf8 Class Initialized
INFO - 2024-07-30 12:33:42 --> URI Class Initialized
INFO - 2024-07-30 12:33:42 --> Router Class Initialized
INFO - 2024-07-30 12:33:42 --> Output Class Initialized
INFO - 2024-07-30 12:33:42 --> Security Class Initialized
DEBUG - 2024-07-30 12:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:33:42 --> Input Class Initialized
INFO - 2024-07-30 12:33:42 --> Language Class Initialized
INFO - 2024-07-30 12:33:42 --> Language Class Initialized
INFO - 2024-07-30 12:33:42 --> Config Class Initialized
INFO - 2024-07-30 12:33:42 --> Loader Class Initialized
INFO - 2024-07-30 12:33:42 --> Helper loaded: url_helper
INFO - 2024-07-30 12:33:42 --> Helper loaded: file_helper
INFO - 2024-07-30 12:33:42 --> Helper loaded: form_helper
INFO - 2024-07-30 12:33:42 --> Helper loaded: my_helper
INFO - 2024-07-30 12:33:42 --> Database Driver Class Initialized
INFO - 2024-07-30 12:33:42 --> Config Class Initialized
INFO - 2024-07-30 12:33:42 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:33:42 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:33:42 --> Utf8 Class Initialized
INFO - 2024-07-30 12:33:42 --> URI Class Initialized
INFO - 2024-07-30 12:33:42 --> Router Class Initialized
INFO - 2024-07-30 12:33:43 --> Output Class Initialized
INFO - 2024-07-30 12:33:43 --> Security Class Initialized
DEBUG - 2024-07-30 12:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:33:43 --> Input Class Initialized
INFO - 2024-07-30 12:33:43 --> Language Class Initialized
INFO - 2024-07-30 12:33:43 --> Language Class Initialized
INFO - 2024-07-30 12:33:43 --> Config Class Initialized
INFO - 2024-07-30 12:33:43 --> Loader Class Initialized
INFO - 2024-07-30 12:33:43 --> Helper loaded: url_helper
INFO - 2024-07-30 12:33:43 --> Helper loaded: file_helper
INFO - 2024-07-30 12:33:43 --> Helper loaded: form_helper
INFO - 2024-07-30 12:33:43 --> Helper loaded: my_helper
INFO - 2024-07-30 12:33:43 --> Database Driver Class Initialized
INFO - 2024-07-30 12:33:45 --> Final output sent to browser
DEBUG - 2024-07-30 12:33:45 --> Total execution time: 4.0808
INFO - 2024-07-30 12:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:33:45 --> Controller Class Initialized
ERROR - 2024-07-30 12:33:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1156
ERROR - 2024-07-30 12:33:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1688
ERROR - 2024-07-30 12:33:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1725
ERROR - 2024-07-30 12:33:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1763
ERROR - 2024-07-30 12:33:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1802
ERROR - 2024-07-30 12:33:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1879
ERROR - 2024-07-30 12:33:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1958
ERROR - 2024-07-30 12:33:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2038
ERROR - 2024-07-30 12:33:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2118
ERROR - 2024-07-30 12:33:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2198
ERROR - 2024-07-30 12:33:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2273
ERROR - 2024-07-30 12:33:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-07-30 12:33:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 12:33:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 12:33:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-30 12:33:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-07-30 12:33:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-30 12:33:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-30 12:33:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-07-30 12:33:46 --> Config Class Initialized
INFO - 2024-07-30 12:33:46 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:33:46 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:33:46 --> Utf8 Class Initialized
INFO - 2024-07-30 12:33:46 --> URI Class Initialized
INFO - 2024-07-30 12:33:46 --> Router Class Initialized
INFO - 2024-07-30 12:33:46 --> Output Class Initialized
INFO - 2024-07-30 12:33:46 --> Security Class Initialized
DEBUG - 2024-07-30 12:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:33:46 --> Input Class Initialized
INFO - 2024-07-30 12:33:46 --> Language Class Initialized
INFO - 2024-07-30 12:33:46 --> Language Class Initialized
INFO - 2024-07-30 12:33:46 --> Config Class Initialized
INFO - 2024-07-30 12:33:46 --> Loader Class Initialized
INFO - 2024-07-30 12:33:46 --> Helper loaded: url_helper
INFO - 2024-07-30 12:33:46 --> Helper loaded: file_helper
INFO - 2024-07-30 12:33:46 --> Helper loaded: form_helper
INFO - 2024-07-30 12:33:46 --> Helper loaded: my_helper
INFO - 2024-07-30 12:33:46 --> Database Driver Class Initialized
INFO - 2024-07-30 12:33:48 --> Final output sent to browser
DEBUG - 2024-07-30 12:33:48 --> Total execution time: 6.4238
INFO - 2024-07-30 12:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:33:48 --> Controller Class Initialized
ERROR - 2024-07-30 12:33:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1156
ERROR - 2024-07-30 12:33:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1688
ERROR - 2024-07-30 12:33:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1725
ERROR - 2024-07-30 12:33:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1763
ERROR - 2024-07-30 12:33:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1802
ERROR - 2024-07-30 12:33:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1879
ERROR - 2024-07-30 12:33:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1958
ERROR - 2024-07-30 12:33:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2038
ERROR - 2024-07-30 12:33:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2118
ERROR - 2024-07-30 12:33:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2198
ERROR - 2024-07-30 12:33:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2273
ERROR - 2024-07-30 12:33:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-07-30 12:33:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 12:33:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 12:33:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-30 12:33:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-07-30 12:33:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-30 12:33:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-30 12:33:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-07-30 12:33:53 --> Final output sent to browser
DEBUG - 2024-07-30 12:33:53 --> Total execution time: 10.3911
INFO - 2024-07-30 12:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:33:53 --> Controller Class Initialized
INFO - 2024-07-30 12:33:53 --> Config Class Initialized
INFO - 2024-07-30 12:33:53 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:33:53 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:33:53 --> Utf8 Class Initialized
INFO - 2024-07-30 12:33:53 --> URI Class Initialized
INFO - 2024-07-30 12:33:53 --> Router Class Initialized
INFO - 2024-07-30 12:33:53 --> Output Class Initialized
ERROR - 2024-07-30 12:33:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1156
ERROR - 2024-07-30 12:33:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1688
ERROR - 2024-07-30 12:33:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1725
ERROR - 2024-07-30 12:33:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1763
ERROR - 2024-07-30 12:33:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1802
ERROR - 2024-07-30 12:33:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1879
ERROR - 2024-07-30 12:33:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1958
ERROR - 2024-07-30 12:33:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2038
INFO - 2024-07-30 12:33:53 --> Security Class Initialized
DEBUG - 2024-07-30 12:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:33:53 --> Input Class Initialized
INFO - 2024-07-30 12:33:53 --> Language Class Initialized
INFO - 2024-07-30 12:33:53 --> Language Class Initialized
INFO - 2024-07-30 12:33:53 --> Config Class Initialized
INFO - 2024-07-30 12:33:53 --> Loader Class Initialized
INFO - 2024-07-30 12:33:53 --> Helper loaded: url_helper
INFO - 2024-07-30 12:33:53 --> Helper loaded: file_helper
INFO - 2024-07-30 12:33:53 --> Helper loaded: form_helper
INFO - 2024-07-30 12:33:53 --> Helper loaded: my_helper
INFO - 2024-07-30 12:33:53 --> Database Driver Class Initialized
ERROR - 2024-07-30 12:33:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2118
ERROR - 2024-07-30 12:33:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2198
ERROR - 2024-07-30 12:33:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2273
ERROR - 2024-07-30 12:33:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-07-30 12:33:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 12:33:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 12:33:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-30 12:33:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-07-30 12:33:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-30 12:33:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-30 12:33:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-07-30 12:33:59 --> Final output sent to browser
DEBUG - 2024-07-30 12:33:59 --> Total execution time: 13.6337
INFO - 2024-07-30 12:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:33:59 --> Controller Class Initialized
ERROR - 2024-07-30 12:33:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1156
ERROR - 2024-07-30 12:33:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1688
ERROR - 2024-07-30 12:33:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1725
ERROR - 2024-07-30 12:33:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1763
ERROR - 2024-07-30 12:33:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1802
ERROR - 2024-07-30 12:33:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1879
ERROR - 2024-07-30 12:33:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1958
ERROR - 2024-07-30 12:33:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2038
ERROR - 2024-07-30 12:33:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2118
ERROR - 2024-07-30 12:33:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2198
ERROR - 2024-07-30 12:33:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2273
ERROR - 2024-07-30 12:33:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-07-30 12:33:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 12:33:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 12:33:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-30 12:33:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-07-30 12:33:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-30 12:33:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-30 12:33:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-07-30 12:34:06 --> Final output sent to browser
DEBUG - 2024-07-30 12:34:06 --> Total execution time: 13.1630
INFO - 2024-07-30 12:39:26 --> Config Class Initialized
INFO - 2024-07-30 12:39:26 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:39:26 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:39:26 --> Utf8 Class Initialized
INFO - 2024-07-30 12:39:26 --> URI Class Initialized
DEBUG - 2024-07-30 12:39:26 --> No URI present. Default controller set.
INFO - 2024-07-30 12:39:26 --> Router Class Initialized
INFO - 2024-07-30 12:39:26 --> Output Class Initialized
INFO - 2024-07-30 12:39:26 --> Security Class Initialized
DEBUG - 2024-07-30 12:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:39:26 --> Input Class Initialized
INFO - 2024-07-30 12:39:26 --> Language Class Initialized
INFO - 2024-07-30 12:39:26 --> Language Class Initialized
INFO - 2024-07-30 12:39:26 --> Config Class Initialized
INFO - 2024-07-30 12:39:26 --> Loader Class Initialized
INFO - 2024-07-30 12:39:26 --> Helper loaded: url_helper
INFO - 2024-07-30 12:39:26 --> Helper loaded: file_helper
INFO - 2024-07-30 12:39:26 --> Helper loaded: form_helper
INFO - 2024-07-30 12:39:26 --> Helper loaded: my_helper
INFO - 2024-07-30 12:39:26 --> Database Driver Class Initialized
INFO - 2024-07-30 12:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:39:26 --> Controller Class Initialized
INFO - 2024-07-30 12:39:26 --> Config Class Initialized
INFO - 2024-07-30 12:39:26 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:39:26 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:39:26 --> Utf8 Class Initialized
INFO - 2024-07-30 12:39:26 --> URI Class Initialized
INFO - 2024-07-30 12:39:26 --> Router Class Initialized
INFO - 2024-07-30 12:39:26 --> Output Class Initialized
INFO - 2024-07-30 12:39:26 --> Security Class Initialized
DEBUG - 2024-07-30 12:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:39:26 --> Input Class Initialized
INFO - 2024-07-30 12:39:26 --> Language Class Initialized
INFO - 2024-07-30 12:39:26 --> Language Class Initialized
INFO - 2024-07-30 12:39:26 --> Config Class Initialized
INFO - 2024-07-30 12:39:26 --> Loader Class Initialized
INFO - 2024-07-30 12:39:26 --> Helper loaded: url_helper
INFO - 2024-07-30 12:39:26 --> Helper loaded: file_helper
INFO - 2024-07-30 12:39:26 --> Helper loaded: form_helper
INFO - 2024-07-30 12:39:26 --> Helper loaded: my_helper
INFO - 2024-07-30 12:39:26 --> Database Driver Class Initialized
INFO - 2024-07-30 12:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:39:26 --> Controller Class Initialized
DEBUG - 2024-07-30 12:39:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-07-30 12:39:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-30 12:39:26 --> Final output sent to browser
DEBUG - 2024-07-30 12:39:26 --> Total execution time: 0.0342
INFO - 2024-07-30 12:40:26 --> Config Class Initialized
INFO - 2024-07-30 12:40:26 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:40:26 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:40:26 --> Utf8 Class Initialized
INFO - 2024-07-30 12:40:26 --> URI Class Initialized
DEBUG - 2024-07-30 12:40:26 --> No URI present. Default controller set.
INFO - 2024-07-30 12:40:26 --> Router Class Initialized
INFO - 2024-07-30 12:40:26 --> Output Class Initialized
INFO - 2024-07-30 12:40:26 --> Security Class Initialized
DEBUG - 2024-07-30 12:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:40:26 --> Input Class Initialized
INFO - 2024-07-30 12:40:26 --> Language Class Initialized
INFO - 2024-07-30 12:40:26 --> Language Class Initialized
INFO - 2024-07-30 12:40:26 --> Config Class Initialized
INFO - 2024-07-30 12:40:26 --> Loader Class Initialized
INFO - 2024-07-30 12:40:26 --> Helper loaded: url_helper
INFO - 2024-07-30 12:40:26 --> Helper loaded: file_helper
INFO - 2024-07-30 12:40:26 --> Helper loaded: form_helper
INFO - 2024-07-30 12:40:26 --> Helper loaded: my_helper
INFO - 2024-07-30 12:40:26 --> Database Driver Class Initialized
INFO - 2024-07-30 12:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:40:26 --> Controller Class Initialized
INFO - 2024-07-30 12:40:26 --> Config Class Initialized
INFO - 2024-07-30 12:40:26 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:40:26 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:40:26 --> Utf8 Class Initialized
INFO - 2024-07-30 12:40:26 --> URI Class Initialized
INFO - 2024-07-30 12:40:26 --> Router Class Initialized
INFO - 2024-07-30 12:40:26 --> Output Class Initialized
INFO - 2024-07-30 12:40:26 --> Security Class Initialized
DEBUG - 2024-07-30 12:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:40:26 --> Input Class Initialized
INFO - 2024-07-30 12:40:26 --> Language Class Initialized
INFO - 2024-07-30 12:40:26 --> Language Class Initialized
INFO - 2024-07-30 12:40:26 --> Config Class Initialized
INFO - 2024-07-30 12:40:26 --> Loader Class Initialized
INFO - 2024-07-30 12:40:26 --> Helper loaded: url_helper
INFO - 2024-07-30 12:40:26 --> Helper loaded: file_helper
INFO - 2024-07-30 12:40:26 --> Helper loaded: form_helper
INFO - 2024-07-30 12:40:26 --> Helper loaded: my_helper
INFO - 2024-07-30 12:40:26 --> Database Driver Class Initialized
INFO - 2024-07-30 12:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:40:27 --> Controller Class Initialized
DEBUG - 2024-07-30 12:40:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-07-30 12:40:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-30 12:40:27 --> Final output sent to browser
DEBUG - 2024-07-30 12:40:27 --> Total execution time: 0.1163
INFO - 2024-07-30 12:40:31 --> Config Class Initialized
INFO - 2024-07-30 12:40:31 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:40:31 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:40:31 --> Utf8 Class Initialized
INFO - 2024-07-30 12:40:31 --> URI Class Initialized
INFO - 2024-07-30 12:40:31 --> Router Class Initialized
INFO - 2024-07-30 12:40:31 --> Output Class Initialized
INFO - 2024-07-30 12:40:31 --> Security Class Initialized
DEBUG - 2024-07-30 12:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:40:31 --> Input Class Initialized
INFO - 2024-07-30 12:40:31 --> Language Class Initialized
INFO - 2024-07-30 12:40:31 --> Language Class Initialized
INFO - 2024-07-30 12:40:31 --> Config Class Initialized
INFO - 2024-07-30 12:40:31 --> Loader Class Initialized
INFO - 2024-07-30 12:40:31 --> Helper loaded: url_helper
INFO - 2024-07-30 12:40:31 --> Helper loaded: file_helper
INFO - 2024-07-30 12:40:31 --> Helper loaded: form_helper
INFO - 2024-07-30 12:40:31 --> Helper loaded: my_helper
INFO - 2024-07-30 12:40:31 --> Database Driver Class Initialized
INFO - 2024-07-30 12:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:40:31 --> Controller Class Initialized
INFO - 2024-07-30 12:40:31 --> Helper loaded: cookie_helper
INFO - 2024-07-30 12:40:31 --> Final output sent to browser
DEBUG - 2024-07-30 12:40:31 --> Total execution time: 0.2095
INFO - 2024-07-30 12:40:31 --> Config Class Initialized
INFO - 2024-07-30 12:40:31 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:40:31 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:40:31 --> Utf8 Class Initialized
INFO - 2024-07-30 12:40:31 --> URI Class Initialized
INFO - 2024-07-30 12:40:31 --> Router Class Initialized
INFO - 2024-07-30 12:40:31 --> Output Class Initialized
INFO - 2024-07-30 12:40:31 --> Security Class Initialized
DEBUG - 2024-07-30 12:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:40:31 --> Input Class Initialized
INFO - 2024-07-30 12:40:31 --> Language Class Initialized
INFO - 2024-07-30 12:40:31 --> Language Class Initialized
INFO - 2024-07-30 12:40:31 --> Config Class Initialized
INFO - 2024-07-30 12:40:31 --> Loader Class Initialized
INFO - 2024-07-30 12:40:31 --> Helper loaded: url_helper
INFO - 2024-07-30 12:40:31 --> Helper loaded: file_helper
INFO - 2024-07-30 12:40:31 --> Helper loaded: form_helper
INFO - 2024-07-30 12:40:31 --> Helper loaded: my_helper
INFO - 2024-07-30 12:40:31 --> Database Driver Class Initialized
INFO - 2024-07-30 12:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:40:31 --> Controller Class Initialized
DEBUG - 2024-07-30 12:40:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-07-30 12:40:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-30 12:40:31 --> Final output sent to browser
DEBUG - 2024-07-30 12:40:31 --> Total execution time: 0.0358
INFO - 2024-07-30 12:40:34 --> Config Class Initialized
INFO - 2024-07-30 12:40:34 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:40:34 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:40:34 --> Utf8 Class Initialized
INFO - 2024-07-30 12:40:34 --> URI Class Initialized
INFO - 2024-07-30 12:40:34 --> Router Class Initialized
INFO - 2024-07-30 12:40:34 --> Output Class Initialized
INFO - 2024-07-30 12:40:34 --> Security Class Initialized
DEBUG - 2024-07-30 12:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:40:34 --> Input Class Initialized
INFO - 2024-07-30 12:40:34 --> Language Class Initialized
INFO - 2024-07-30 12:40:34 --> Language Class Initialized
INFO - 2024-07-30 12:40:34 --> Config Class Initialized
INFO - 2024-07-30 12:40:34 --> Loader Class Initialized
INFO - 2024-07-30 12:40:34 --> Helper loaded: url_helper
INFO - 2024-07-30 12:40:34 --> Helper loaded: file_helper
INFO - 2024-07-30 12:40:34 --> Helper loaded: form_helper
INFO - 2024-07-30 12:40:34 --> Helper loaded: my_helper
INFO - 2024-07-30 12:40:34 --> Database Driver Class Initialized
INFO - 2024-07-30 12:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:40:34 --> Controller Class Initialized
DEBUG - 2024-07-30 12:40:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-30 12:40:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-30 12:40:34 --> Final output sent to browser
DEBUG - 2024-07-30 12:40:34 --> Total execution time: 0.0366
INFO - 2024-07-30 12:40:34 --> Config Class Initialized
INFO - 2024-07-30 12:40:34 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:40:34 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:40:34 --> Utf8 Class Initialized
INFO - 2024-07-30 12:40:34 --> URI Class Initialized
INFO - 2024-07-30 12:40:34 --> Router Class Initialized
INFO - 2024-07-30 12:40:34 --> Output Class Initialized
INFO - 2024-07-30 12:40:34 --> Security Class Initialized
DEBUG - 2024-07-30 12:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:40:34 --> Input Class Initialized
INFO - 2024-07-30 12:40:34 --> Language Class Initialized
ERROR - 2024-07-30 12:40:34 --> 404 Page Not Found: /index
INFO - 2024-07-30 12:40:34 --> Config Class Initialized
INFO - 2024-07-30 12:40:34 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:40:34 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:40:34 --> Utf8 Class Initialized
INFO - 2024-07-30 12:40:34 --> URI Class Initialized
INFO - 2024-07-30 12:40:34 --> Router Class Initialized
INFO - 2024-07-30 12:40:34 --> Output Class Initialized
INFO - 2024-07-30 12:40:34 --> Security Class Initialized
DEBUG - 2024-07-30 12:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:40:34 --> Input Class Initialized
INFO - 2024-07-30 12:40:34 --> Language Class Initialized
INFO - 2024-07-30 12:40:34 --> Language Class Initialized
INFO - 2024-07-30 12:40:34 --> Config Class Initialized
INFO - 2024-07-30 12:40:34 --> Loader Class Initialized
INFO - 2024-07-30 12:40:34 --> Helper loaded: url_helper
INFO - 2024-07-30 12:40:34 --> Helper loaded: file_helper
INFO - 2024-07-30 12:40:34 --> Helper loaded: form_helper
INFO - 2024-07-30 12:40:34 --> Helper loaded: my_helper
INFO - 2024-07-30 12:40:34 --> Database Driver Class Initialized
INFO - 2024-07-30 12:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:40:34 --> Controller Class Initialized
INFO - 2024-07-30 12:40:36 --> Config Class Initialized
INFO - 2024-07-30 12:40:36 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:40:36 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:40:36 --> Utf8 Class Initialized
INFO - 2024-07-30 12:40:36 --> URI Class Initialized
INFO - 2024-07-30 12:40:36 --> Router Class Initialized
INFO - 2024-07-30 12:40:36 --> Output Class Initialized
INFO - 2024-07-30 12:40:36 --> Security Class Initialized
DEBUG - 2024-07-30 12:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:40:36 --> Input Class Initialized
INFO - 2024-07-30 12:40:36 --> Language Class Initialized
INFO - 2024-07-30 12:40:36 --> Language Class Initialized
INFO - 2024-07-30 12:40:36 --> Config Class Initialized
INFO - 2024-07-30 12:40:36 --> Loader Class Initialized
INFO - 2024-07-30 12:40:36 --> Helper loaded: url_helper
INFO - 2024-07-30 12:40:36 --> Helper loaded: file_helper
INFO - 2024-07-30 12:40:36 --> Helper loaded: form_helper
INFO - 2024-07-30 12:40:36 --> Helper loaded: my_helper
INFO - 2024-07-30 12:40:36 --> Database Driver Class Initialized
INFO - 2024-07-30 12:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:40:36 --> Controller Class Initialized
INFO - 2024-07-30 12:40:36 --> Config Class Initialized
INFO - 2024-07-30 12:40:36 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:40:36 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:40:36 --> Utf8 Class Initialized
INFO - 2024-07-30 12:40:36 --> URI Class Initialized
INFO - 2024-07-30 12:40:36 --> Router Class Initialized
INFO - 2024-07-30 12:40:36 --> Output Class Initialized
INFO - 2024-07-30 12:40:36 --> Security Class Initialized
DEBUG - 2024-07-30 12:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:40:36 --> Input Class Initialized
INFO - 2024-07-30 12:40:36 --> Language Class Initialized
INFO - 2024-07-30 12:40:36 --> Language Class Initialized
INFO - 2024-07-30 12:40:36 --> Config Class Initialized
INFO - 2024-07-30 12:40:36 --> Loader Class Initialized
INFO - 2024-07-30 12:40:36 --> Helper loaded: url_helper
INFO - 2024-07-30 12:40:36 --> Helper loaded: file_helper
INFO - 2024-07-30 12:40:36 --> Helper loaded: form_helper
INFO - 2024-07-30 12:40:36 --> Helper loaded: my_helper
INFO - 2024-07-30 12:40:36 --> Database Driver Class Initialized
INFO - 2024-07-30 12:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:40:36 --> Controller Class Initialized
INFO - 2024-07-30 12:40:37 --> Config Class Initialized
INFO - 2024-07-30 12:40:37 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:40:37 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:40:37 --> Utf8 Class Initialized
INFO - 2024-07-30 12:40:37 --> URI Class Initialized
INFO - 2024-07-30 12:40:37 --> Router Class Initialized
INFO - 2024-07-30 12:40:37 --> Output Class Initialized
INFO - 2024-07-30 12:40:37 --> Security Class Initialized
DEBUG - 2024-07-30 12:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:40:37 --> Input Class Initialized
INFO - 2024-07-30 12:40:37 --> Language Class Initialized
INFO - 2024-07-30 12:40:37 --> Language Class Initialized
INFO - 2024-07-30 12:40:37 --> Config Class Initialized
INFO - 2024-07-30 12:40:37 --> Loader Class Initialized
INFO - 2024-07-30 12:40:37 --> Helper loaded: url_helper
INFO - 2024-07-30 12:40:37 --> Helper loaded: file_helper
INFO - 2024-07-30 12:40:37 --> Helper loaded: form_helper
INFO - 2024-07-30 12:40:37 --> Helper loaded: my_helper
INFO - 2024-07-30 12:40:37 --> Database Driver Class Initialized
INFO - 2024-07-30 12:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:40:37 --> Controller Class Initialized
INFO - 2024-07-30 12:40:37 --> Config Class Initialized
INFO - 2024-07-30 12:40:37 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:40:37 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:40:37 --> Utf8 Class Initialized
INFO - 2024-07-30 12:40:37 --> URI Class Initialized
INFO - 2024-07-30 12:40:37 --> Router Class Initialized
INFO - 2024-07-30 12:40:37 --> Output Class Initialized
INFO - 2024-07-30 12:40:37 --> Security Class Initialized
DEBUG - 2024-07-30 12:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:40:37 --> Input Class Initialized
INFO - 2024-07-30 12:40:37 --> Language Class Initialized
INFO - 2024-07-30 12:40:37 --> Language Class Initialized
INFO - 2024-07-30 12:40:37 --> Config Class Initialized
INFO - 2024-07-30 12:40:37 --> Loader Class Initialized
INFO - 2024-07-30 12:40:37 --> Helper loaded: url_helper
INFO - 2024-07-30 12:40:37 --> Helper loaded: file_helper
INFO - 2024-07-30 12:40:38 --> Helper loaded: form_helper
INFO - 2024-07-30 12:40:38 --> Helper loaded: my_helper
INFO - 2024-07-30 12:40:38 --> Database Driver Class Initialized
INFO - 2024-07-30 12:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:40:38 --> Controller Class Initialized
INFO - 2024-07-30 12:40:39 --> Config Class Initialized
INFO - 2024-07-30 12:40:39 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:40:39 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:40:39 --> Utf8 Class Initialized
INFO - 2024-07-30 12:40:39 --> URI Class Initialized
INFO - 2024-07-30 12:40:39 --> Router Class Initialized
INFO - 2024-07-30 12:40:39 --> Output Class Initialized
INFO - 2024-07-30 12:40:39 --> Security Class Initialized
DEBUG - 2024-07-30 12:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:40:39 --> Input Class Initialized
INFO - 2024-07-30 12:40:39 --> Language Class Initialized
INFO - 2024-07-30 12:40:39 --> Language Class Initialized
INFO - 2024-07-30 12:40:39 --> Config Class Initialized
INFO - 2024-07-30 12:40:39 --> Loader Class Initialized
INFO - 2024-07-30 12:40:39 --> Helper loaded: url_helper
INFO - 2024-07-30 12:40:39 --> Helper loaded: file_helper
INFO - 2024-07-30 12:40:39 --> Helper loaded: form_helper
INFO - 2024-07-30 12:40:39 --> Helper loaded: my_helper
INFO - 2024-07-30 12:40:39 --> Database Driver Class Initialized
INFO - 2024-07-30 12:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:40:39 --> Controller Class Initialized
ERROR - 2024-07-30 12:40:39 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-07-30 12:40:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-07-30 12:40:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-30 12:40:39 --> Final output sent to browser
DEBUG - 2024-07-30 12:40:39 --> Total execution time: 0.0453
INFO - 2024-07-30 12:43:33 --> Config Class Initialized
INFO - 2024-07-30 12:43:33 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:43:33 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:43:33 --> Utf8 Class Initialized
INFO - 2024-07-30 12:43:33 --> URI Class Initialized
INFO - 2024-07-30 12:43:33 --> Router Class Initialized
INFO - 2024-07-30 12:43:33 --> Output Class Initialized
INFO - 2024-07-30 12:43:33 --> Security Class Initialized
DEBUG - 2024-07-30 12:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:43:33 --> Input Class Initialized
INFO - 2024-07-30 12:43:33 --> Language Class Initialized
INFO - 2024-07-30 12:43:33 --> Language Class Initialized
INFO - 2024-07-30 12:43:33 --> Config Class Initialized
INFO - 2024-07-30 12:43:33 --> Loader Class Initialized
INFO - 2024-07-30 12:43:33 --> Helper loaded: url_helper
INFO - 2024-07-30 12:43:33 --> Helper loaded: file_helper
INFO - 2024-07-30 12:43:33 --> Helper loaded: form_helper
INFO - 2024-07-30 12:43:33 --> Helper loaded: my_helper
INFO - 2024-07-30 12:43:33 --> Database Driver Class Initialized
INFO - 2024-07-30 12:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:43:33 --> Controller Class Initialized
INFO - 2024-07-30 12:43:33 --> Helper loaded: cookie_helper
INFO - 2024-07-30 12:43:33 --> Final output sent to browser
DEBUG - 2024-07-30 12:43:33 --> Total execution time: 0.0906
INFO - 2024-07-30 12:43:33 --> Config Class Initialized
INFO - 2024-07-30 12:43:33 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:43:33 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:43:33 --> Utf8 Class Initialized
INFO - 2024-07-30 12:43:33 --> URI Class Initialized
INFO - 2024-07-30 12:43:33 --> Router Class Initialized
INFO - 2024-07-30 12:43:34 --> Output Class Initialized
INFO - 2024-07-30 12:43:34 --> Security Class Initialized
DEBUG - 2024-07-30 12:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:43:34 --> Input Class Initialized
INFO - 2024-07-30 12:43:34 --> Language Class Initialized
INFO - 2024-07-30 12:43:34 --> Language Class Initialized
INFO - 2024-07-30 12:43:34 --> Config Class Initialized
INFO - 2024-07-30 12:43:34 --> Loader Class Initialized
INFO - 2024-07-30 12:43:34 --> Helper loaded: url_helper
INFO - 2024-07-30 12:43:34 --> Helper loaded: file_helper
INFO - 2024-07-30 12:43:34 --> Helper loaded: form_helper
INFO - 2024-07-30 12:43:34 --> Helper loaded: my_helper
INFO - 2024-07-30 12:43:34 --> Database Driver Class Initialized
INFO - 2024-07-30 12:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:43:34 --> Controller Class Initialized
INFO - 2024-07-30 12:43:34 --> Helper loaded: cookie_helper
INFO - 2024-07-30 12:43:34 --> Config Class Initialized
INFO - 2024-07-30 12:43:34 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:43:34 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:43:34 --> Utf8 Class Initialized
INFO - 2024-07-30 12:43:34 --> URI Class Initialized
INFO - 2024-07-30 12:43:34 --> Router Class Initialized
INFO - 2024-07-30 12:43:34 --> Output Class Initialized
INFO - 2024-07-30 12:43:34 --> Security Class Initialized
DEBUG - 2024-07-30 12:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:43:34 --> Input Class Initialized
INFO - 2024-07-30 12:43:34 --> Language Class Initialized
INFO - 2024-07-30 12:43:34 --> Language Class Initialized
INFO - 2024-07-30 12:43:34 --> Config Class Initialized
INFO - 2024-07-30 12:43:34 --> Loader Class Initialized
INFO - 2024-07-30 12:43:34 --> Helper loaded: url_helper
INFO - 2024-07-30 12:43:34 --> Helper loaded: file_helper
INFO - 2024-07-30 12:43:34 --> Helper loaded: form_helper
INFO - 2024-07-30 12:43:34 --> Helper loaded: my_helper
INFO - 2024-07-30 12:43:34 --> Database Driver Class Initialized
INFO - 2024-07-30 12:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:43:34 --> Controller Class Initialized
DEBUG - 2024-07-30 12:43:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-30 12:43:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-30 12:43:34 --> Final output sent to browser
DEBUG - 2024-07-30 12:43:34 --> Total execution time: 0.0552
INFO - 2024-07-30 12:43:52 --> Config Class Initialized
INFO - 2024-07-30 12:43:52 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:43:52 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:43:52 --> Utf8 Class Initialized
INFO - 2024-07-30 12:43:52 --> URI Class Initialized
INFO - 2024-07-30 12:43:52 --> Router Class Initialized
INFO - 2024-07-30 12:43:52 --> Output Class Initialized
INFO - 2024-07-30 12:43:52 --> Security Class Initialized
DEBUG - 2024-07-30 12:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:43:52 --> Input Class Initialized
INFO - 2024-07-30 12:43:52 --> Language Class Initialized
INFO - 2024-07-30 12:43:52 --> Language Class Initialized
INFO - 2024-07-30 12:43:52 --> Config Class Initialized
INFO - 2024-07-30 12:43:52 --> Loader Class Initialized
INFO - 2024-07-30 12:43:52 --> Helper loaded: url_helper
INFO - 2024-07-30 12:43:52 --> Helper loaded: file_helper
INFO - 2024-07-30 12:43:52 --> Helper loaded: form_helper
INFO - 2024-07-30 12:43:52 --> Helper loaded: my_helper
INFO - 2024-07-30 12:43:52 --> Database Driver Class Initialized
INFO - 2024-07-30 12:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:43:52 --> Controller Class Initialized
ERROR - 2024-07-30 12:43:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1156
ERROR - 2024-07-30 12:43:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1688
ERROR - 2024-07-30 12:43:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1725
ERROR - 2024-07-30 12:43:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1763
ERROR - 2024-07-30 12:43:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1802
ERROR - 2024-07-30 12:43:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1879
ERROR - 2024-07-30 12:43:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1958
ERROR - 2024-07-30 12:43:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2038
ERROR - 2024-07-30 12:43:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2118
ERROR - 2024-07-30 12:43:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2198
ERROR - 2024-07-30 12:43:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2273
ERROR - 2024-07-30 12:43:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-07-30 12:43:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 12:43:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 12:43:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-30 12:43:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-07-30 12:43:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-30 12:43:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-30 12:43:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-07-30 12:43:53 --> Config Class Initialized
INFO - 2024-07-30 12:43:53 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:43:53 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:43:53 --> Utf8 Class Initialized
INFO - 2024-07-30 12:43:53 --> URI Class Initialized
INFO - 2024-07-30 12:43:53 --> Router Class Initialized
INFO - 2024-07-30 12:43:53 --> Output Class Initialized
INFO - 2024-07-30 12:43:53 --> Security Class Initialized
DEBUG - 2024-07-30 12:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:43:54 --> Input Class Initialized
INFO - 2024-07-30 12:43:54 --> Language Class Initialized
INFO - 2024-07-30 12:43:54 --> Language Class Initialized
INFO - 2024-07-30 12:43:54 --> Config Class Initialized
INFO - 2024-07-30 12:43:54 --> Loader Class Initialized
INFO - 2024-07-30 12:43:54 --> Helper loaded: url_helper
INFO - 2024-07-30 12:43:54 --> Helper loaded: file_helper
INFO - 2024-07-30 12:43:54 --> Helper loaded: form_helper
INFO - 2024-07-30 12:43:54 --> Helper loaded: my_helper
INFO - 2024-07-30 12:43:54 --> Database Driver Class Initialized
INFO - 2024-07-30 12:43:54 --> Config Class Initialized
INFO - 2024-07-30 12:43:54 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:43:54 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:43:54 --> Utf8 Class Initialized
INFO - 2024-07-30 12:43:54 --> URI Class Initialized
INFO - 2024-07-30 12:43:54 --> Router Class Initialized
INFO - 2024-07-30 12:43:54 --> Output Class Initialized
INFO - 2024-07-30 12:43:54 --> Security Class Initialized
DEBUG - 2024-07-30 12:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:43:54 --> Input Class Initialized
INFO - 2024-07-30 12:43:54 --> Language Class Initialized
INFO - 2024-07-30 12:43:54 --> Language Class Initialized
INFO - 2024-07-30 12:43:54 --> Config Class Initialized
INFO - 2024-07-30 12:43:54 --> Loader Class Initialized
INFO - 2024-07-30 12:43:54 --> Helper loaded: url_helper
INFO - 2024-07-30 12:43:54 --> Helper loaded: file_helper
INFO - 2024-07-30 12:43:54 --> Helper loaded: form_helper
INFO - 2024-07-30 12:43:54 --> Helper loaded: my_helper
INFO - 2024-07-30 12:43:54 --> Database Driver Class Initialized
INFO - 2024-07-30 12:43:55 --> Final output sent to browser
DEBUG - 2024-07-30 12:43:55 --> Total execution time: 3.0603
INFO - 2024-07-30 12:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:43:55 --> Controller Class Initialized
ERROR - 2024-07-30 12:43:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1156
ERROR - 2024-07-30 12:43:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1688
ERROR - 2024-07-30 12:43:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1725
ERROR - 2024-07-30 12:43:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1763
ERROR - 2024-07-30 12:43:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1802
ERROR - 2024-07-30 12:43:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1879
ERROR - 2024-07-30 12:43:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1958
ERROR - 2024-07-30 12:43:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2038
ERROR - 2024-07-30 12:43:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2118
ERROR - 2024-07-30 12:43:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2198
ERROR - 2024-07-30 12:43:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2273
ERROR - 2024-07-30 12:43:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-07-30 12:43:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 12:43:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 12:43:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-30 12:43:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-07-30 12:43:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-30 12:43:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-30 12:43:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-07-30 12:43:56 --> Config Class Initialized
INFO - 2024-07-30 12:43:56 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:43:56 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:43:56 --> Utf8 Class Initialized
INFO - 2024-07-30 12:43:56 --> URI Class Initialized
INFO - 2024-07-30 12:43:56 --> Router Class Initialized
INFO - 2024-07-30 12:43:56 --> Output Class Initialized
INFO - 2024-07-30 12:43:56 --> Security Class Initialized
DEBUG - 2024-07-30 12:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:43:56 --> Input Class Initialized
INFO - 2024-07-30 12:43:56 --> Language Class Initialized
INFO - 2024-07-30 12:43:56 --> Language Class Initialized
INFO - 2024-07-30 12:43:56 --> Config Class Initialized
INFO - 2024-07-30 12:43:56 --> Loader Class Initialized
INFO - 2024-07-30 12:43:56 --> Helper loaded: url_helper
INFO - 2024-07-30 12:43:56 --> Helper loaded: file_helper
INFO - 2024-07-30 12:43:56 --> Helper loaded: form_helper
INFO - 2024-07-30 12:43:56 --> Helper loaded: my_helper
INFO - 2024-07-30 12:43:56 --> Database Driver Class Initialized
INFO - 2024-07-30 12:43:58 --> Final output sent to browser
DEBUG - 2024-07-30 12:43:58 --> Total execution time: 5.0423
INFO - 2024-07-30 12:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:43:58 --> Controller Class Initialized
ERROR - 2024-07-30 12:43:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1156
ERROR - 2024-07-30 12:43:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1688
ERROR - 2024-07-30 12:43:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1725
ERROR - 2024-07-30 12:43:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1763
ERROR - 2024-07-30 12:43:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1802
ERROR - 2024-07-30 12:43:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1879
ERROR - 2024-07-30 12:43:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1958
ERROR - 2024-07-30 12:43:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2038
ERROR - 2024-07-30 12:43:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2118
ERROR - 2024-07-30 12:43:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2198
ERROR - 2024-07-30 12:43:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2273
ERROR - 2024-07-30 12:43:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-07-30 12:43:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 12:43:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 12:43:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-30 12:43:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-07-30 12:43:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-30 12:43:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-30 12:43:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-07-30 12:44:02 --> Final output sent to browser
DEBUG - 2024-07-30 12:44:02 --> Total execution time: 7.9445
INFO - 2024-07-30 12:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:44:02 --> Controller Class Initialized
ERROR - 2024-07-30 12:44:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1156
INFO - 2024-07-30 12:44:02 --> Config Class Initialized
INFO - 2024-07-30 12:44:02 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:44:02 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:44:02 --> Utf8 Class Initialized
INFO - 2024-07-30 12:44:02 --> URI Class Initialized
INFO - 2024-07-30 12:44:02 --> Router Class Initialized
INFO - 2024-07-30 12:44:02 --> Output Class Initialized
ERROR - 2024-07-30 12:44:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1688
ERROR - 2024-07-30 12:44:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1725
ERROR - 2024-07-30 12:44:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1763
ERROR - 2024-07-30 12:44:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1802
ERROR - 2024-07-30 12:44:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1879
ERROR - 2024-07-30 12:44:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1958
ERROR - 2024-07-30 12:44:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2038
ERROR - 2024-07-30 12:44:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2118
ERROR - 2024-07-30 12:44:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2198
ERROR - 2024-07-30 12:44:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2273
ERROR - 2024-07-30 12:44:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-07-30 12:44:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 12:44:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 12:44:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-30 12:44:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-07-30 12:44:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-30 12:44:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-30 12:44:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-07-30 12:44:02 --> Security Class Initialized
DEBUG - 2024-07-30 12:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:44:02 --> Input Class Initialized
INFO - 2024-07-30 12:44:02 --> Language Class Initialized
INFO - 2024-07-30 12:44:02 --> Language Class Initialized
INFO - 2024-07-30 12:44:02 --> Config Class Initialized
INFO - 2024-07-30 12:44:02 --> Loader Class Initialized
INFO - 2024-07-30 12:44:02 --> Helper loaded: url_helper
INFO - 2024-07-30 12:44:02 --> Helper loaded: file_helper
INFO - 2024-07-30 12:44:02 --> Helper loaded: form_helper
INFO - 2024-07-30 12:44:02 --> Helper loaded: my_helper
INFO - 2024-07-30 12:44:02 --> Database Driver Class Initialized
INFO - 2024-07-30 12:44:04 --> Config Class Initialized
INFO - 2024-07-30 12:44:04 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:44:04 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:44:04 --> Utf8 Class Initialized
INFO - 2024-07-30 12:44:04 --> URI Class Initialized
INFO - 2024-07-30 12:44:04 --> Router Class Initialized
INFO - 2024-07-30 12:44:04 --> Output Class Initialized
INFO - 2024-07-30 12:44:04 --> Security Class Initialized
DEBUG - 2024-07-30 12:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:44:04 --> Input Class Initialized
INFO - 2024-07-30 12:44:04 --> Language Class Initialized
INFO - 2024-07-30 12:44:04 --> Language Class Initialized
INFO - 2024-07-30 12:44:04 --> Config Class Initialized
INFO - 2024-07-30 12:44:04 --> Loader Class Initialized
INFO - 2024-07-30 12:44:04 --> Helper loaded: url_helper
INFO - 2024-07-30 12:44:04 --> Helper loaded: file_helper
INFO - 2024-07-30 12:44:04 --> Helper loaded: form_helper
INFO - 2024-07-30 12:44:04 --> Helper loaded: my_helper
INFO - 2024-07-30 12:44:04 --> Database Driver Class Initialized
INFO - 2024-07-30 12:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:44:04 --> Controller Class Initialized
INFO - 2024-07-30 12:44:04 --> Helper loaded: cookie_helper
INFO - 2024-07-30 12:44:04 --> Final output sent to browser
DEBUG - 2024-07-30 12:44:04 --> Total execution time: 0.0716
INFO - 2024-07-30 12:44:06 --> Final output sent to browser
DEBUG - 2024-07-30 12:44:06 --> Total execution time: 9.2856
INFO - 2024-07-30 12:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:44:06 --> Controller Class Initialized
ERROR - 2024-07-30 12:44:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1156
INFO - 2024-07-30 12:44:06 --> Config Class Initialized
INFO - 2024-07-30 12:44:06 --> Hooks Class Initialized
ERROR - 2024-07-30 12:44:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1688
ERROR - 2024-07-30 12:44:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1725
ERROR - 2024-07-30 12:44:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1763
DEBUG - 2024-07-30 12:44:06 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:44:06 --> Utf8 Class Initialized
ERROR - 2024-07-30 12:44:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1802
ERROR - 2024-07-30 12:44:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1879
ERROR - 2024-07-30 12:44:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1958
ERROR - 2024-07-30 12:44:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2038
ERROR - 2024-07-30 12:44:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2118
ERROR - 2024-07-30 12:44:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2198
ERROR - 2024-07-30 12:44:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2273
INFO - 2024-07-30 12:44:06 --> URI Class Initialized
INFO - 2024-07-30 12:44:06 --> Router Class Initialized
INFO - 2024-07-30 12:44:06 --> Output Class Initialized
INFO - 2024-07-30 12:44:06 --> Security Class Initialized
DEBUG - 2024-07-30 12:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:44:06 --> Input Class Initialized
INFO - 2024-07-30 12:44:06 --> Language Class Initialized
INFO - 2024-07-30 12:44:06 --> Language Class Initialized
INFO - 2024-07-30 12:44:06 --> Config Class Initialized
INFO - 2024-07-30 12:44:06 --> Loader Class Initialized
ERROR - 2024-07-30 12:44:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-07-30 12:44:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 12:44:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 12:44:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-30 12:44:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-07-30 12:44:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-30 12:44:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-30 12:44:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-07-30 12:44:06 --> Helper loaded: url_helper
INFO - 2024-07-30 12:44:06 --> Helper loaded: file_helper
INFO - 2024-07-30 12:44:06 --> Helper loaded: form_helper
INFO - 2024-07-30 12:44:06 --> Helper loaded: my_helper
INFO - 2024-07-30 12:44:06 --> Database Driver Class Initialized
INFO - 2024-07-30 12:44:10 --> Final output sent to browser
DEBUG - 2024-07-30 12:44:10 --> Total execution time: 8.4760
INFO - 2024-07-30 12:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:44:10 --> Controller Class Initialized
INFO - 2024-07-30 12:44:10 --> Helper loaded: cookie_helper
INFO - 2024-07-30 12:44:10 --> Config Class Initialized
INFO - 2024-07-30 12:44:10 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:44:10 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:44:10 --> Utf8 Class Initialized
INFO - 2024-07-30 12:44:10 --> URI Class Initialized
INFO - 2024-07-30 12:44:10 --> Router Class Initialized
INFO - 2024-07-30 12:44:10 --> Output Class Initialized
INFO - 2024-07-30 12:44:10 --> Security Class Initialized
DEBUG - 2024-07-30 12:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:44:10 --> Input Class Initialized
INFO - 2024-07-30 12:44:10 --> Language Class Initialized
INFO - 2024-07-30 12:44:10 --> Language Class Initialized
INFO - 2024-07-30 12:44:10 --> Config Class Initialized
INFO - 2024-07-30 12:44:10 --> Loader Class Initialized
INFO - 2024-07-30 12:44:10 --> Helper loaded: url_helper
INFO - 2024-07-30 12:44:10 --> Helper loaded: file_helper
INFO - 2024-07-30 12:44:10 --> Helper loaded: form_helper
INFO - 2024-07-30 12:44:10 --> Helper loaded: my_helper
INFO - 2024-07-30 12:44:10 --> Database Driver Class Initialized
INFO - 2024-07-30 12:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:44:10 --> Controller Class Initialized
DEBUG - 2024-07-30 12:44:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-30 12:44:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-30 12:44:10 --> Final output sent to browser
DEBUG - 2024-07-30 12:44:10 --> Total execution time: 0.0306
INFO - 2024-07-30 12:45:43 --> Config Class Initialized
INFO - 2024-07-30 12:45:43 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:45:43 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:45:43 --> Utf8 Class Initialized
INFO - 2024-07-30 12:45:43 --> URI Class Initialized
INFO - 2024-07-30 12:45:43 --> Router Class Initialized
INFO - 2024-07-30 12:45:43 --> Output Class Initialized
INFO - 2024-07-30 12:45:43 --> Security Class Initialized
DEBUG - 2024-07-30 12:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:45:43 --> Input Class Initialized
INFO - 2024-07-30 12:45:43 --> Language Class Initialized
INFO - 2024-07-30 12:45:43 --> Language Class Initialized
INFO - 2024-07-30 12:45:43 --> Config Class Initialized
INFO - 2024-07-30 12:45:43 --> Loader Class Initialized
INFO - 2024-07-30 12:45:43 --> Helper loaded: url_helper
INFO - 2024-07-30 12:45:43 --> Helper loaded: file_helper
INFO - 2024-07-30 12:45:43 --> Helper loaded: form_helper
INFO - 2024-07-30 12:45:43 --> Helper loaded: my_helper
INFO - 2024-07-30 12:45:43 --> Database Driver Class Initialized
INFO - 2024-07-30 12:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:45:43 --> Controller Class Initialized
DEBUG - 2024-07-30 12:45:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-30 12:45:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-30 12:45:43 --> Final output sent to browser
DEBUG - 2024-07-30 12:45:43 --> Total execution time: 0.0539
INFO - 2024-07-30 12:45:48 --> Config Class Initialized
INFO - 2024-07-30 12:45:48 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:45:48 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:45:48 --> Utf8 Class Initialized
INFO - 2024-07-30 12:45:48 --> URI Class Initialized
INFO - 2024-07-30 12:45:48 --> Router Class Initialized
INFO - 2024-07-30 12:45:48 --> Output Class Initialized
INFO - 2024-07-30 12:45:48 --> Security Class Initialized
DEBUG - 2024-07-30 12:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:45:48 --> Input Class Initialized
INFO - 2024-07-30 12:45:48 --> Language Class Initialized
INFO - 2024-07-30 12:45:48 --> Language Class Initialized
INFO - 2024-07-30 12:45:48 --> Config Class Initialized
INFO - 2024-07-30 12:45:48 --> Loader Class Initialized
INFO - 2024-07-30 12:45:48 --> Helper loaded: url_helper
INFO - 2024-07-30 12:45:48 --> Helper loaded: file_helper
INFO - 2024-07-30 12:45:48 --> Helper loaded: form_helper
INFO - 2024-07-30 12:45:48 --> Helper loaded: my_helper
INFO - 2024-07-30 12:45:48 --> Database Driver Class Initialized
INFO - 2024-07-30 12:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:45:48 --> Controller Class Initialized
INFO - 2024-07-30 12:45:48 --> Database Driver Class Initialized
INFO - 2024-07-30 12:45:48 --> Config Class Initialized
INFO - 2024-07-30 12:45:48 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:45:48 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:45:48 --> Utf8 Class Initialized
INFO - 2024-07-30 12:45:48 --> URI Class Initialized
INFO - 2024-07-30 12:45:48 --> Router Class Initialized
INFO - 2024-07-30 12:45:48 --> Output Class Initialized
INFO - 2024-07-30 12:45:48 --> Security Class Initialized
DEBUG - 2024-07-30 12:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:45:48 --> Input Class Initialized
INFO - 2024-07-30 12:45:48 --> Language Class Initialized
INFO - 2024-07-30 12:45:48 --> Language Class Initialized
INFO - 2024-07-30 12:45:48 --> Config Class Initialized
INFO - 2024-07-30 12:45:48 --> Loader Class Initialized
INFO - 2024-07-30 12:45:48 --> Helper loaded: url_helper
INFO - 2024-07-30 12:45:48 --> Helper loaded: file_helper
INFO - 2024-07-30 12:45:48 --> Helper loaded: form_helper
INFO - 2024-07-30 12:45:48 --> Helper loaded: my_helper
INFO - 2024-07-30 12:45:48 --> Database Driver Class Initialized
INFO - 2024-07-30 12:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:45:48 --> Controller Class Initialized
DEBUG - 2024-07-30 12:45:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-30 12:45:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-30 12:45:48 --> Final output sent to browser
DEBUG - 2024-07-30 12:45:48 --> Total execution time: 0.0313
INFO - 2024-07-30 12:48:50 --> Config Class Initialized
INFO - 2024-07-30 12:48:50 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:48:51 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:48:51 --> Utf8 Class Initialized
INFO - 2024-07-30 12:48:51 --> URI Class Initialized
INFO - 2024-07-30 12:48:51 --> Router Class Initialized
INFO - 2024-07-30 12:48:51 --> Output Class Initialized
INFO - 2024-07-30 12:48:51 --> Security Class Initialized
DEBUG - 2024-07-30 12:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:48:51 --> Input Class Initialized
INFO - 2024-07-30 12:48:51 --> Language Class Initialized
INFO - 2024-07-30 12:48:51 --> Language Class Initialized
INFO - 2024-07-30 12:48:51 --> Config Class Initialized
INFO - 2024-07-30 12:48:51 --> Loader Class Initialized
INFO - 2024-07-30 12:48:51 --> Helper loaded: url_helper
INFO - 2024-07-30 12:48:51 --> Helper loaded: file_helper
INFO - 2024-07-30 12:48:51 --> Helper loaded: form_helper
INFO - 2024-07-30 12:48:51 --> Helper loaded: my_helper
INFO - 2024-07-30 12:48:51 --> Database Driver Class Initialized
INFO - 2024-07-30 12:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:48:51 --> Controller Class Initialized
INFO - 2024-07-30 12:48:51 --> Helper loaded: cookie_helper
INFO - 2024-07-30 12:48:51 --> Final output sent to browser
DEBUG - 2024-07-30 12:48:51 --> Total execution time: 0.2559
INFO - 2024-07-30 12:48:51 --> Config Class Initialized
INFO - 2024-07-30 12:48:51 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:48:51 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:48:51 --> Utf8 Class Initialized
INFO - 2024-07-30 12:48:51 --> URI Class Initialized
INFO - 2024-07-30 12:48:51 --> Router Class Initialized
INFO - 2024-07-30 12:48:51 --> Output Class Initialized
INFO - 2024-07-30 12:48:51 --> Security Class Initialized
DEBUG - 2024-07-30 12:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:48:51 --> Input Class Initialized
INFO - 2024-07-30 12:48:51 --> Language Class Initialized
INFO - 2024-07-30 12:48:51 --> Language Class Initialized
INFO - 2024-07-30 12:48:51 --> Config Class Initialized
INFO - 2024-07-30 12:48:51 --> Loader Class Initialized
INFO - 2024-07-30 12:48:51 --> Helper loaded: url_helper
INFO - 2024-07-30 12:48:51 --> Helper loaded: file_helper
INFO - 2024-07-30 12:48:51 --> Helper loaded: form_helper
INFO - 2024-07-30 12:48:51 --> Helper loaded: my_helper
INFO - 2024-07-30 12:48:51 --> Database Driver Class Initialized
INFO - 2024-07-30 12:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:48:51 --> Controller Class Initialized
INFO - 2024-07-30 12:48:51 --> Helper loaded: cookie_helper
INFO - 2024-07-30 12:48:51 --> Config Class Initialized
INFO - 2024-07-30 12:48:51 --> Hooks Class Initialized
DEBUG - 2024-07-30 12:48:51 --> UTF-8 Support Enabled
INFO - 2024-07-30 12:48:51 --> Utf8 Class Initialized
INFO - 2024-07-30 12:48:51 --> URI Class Initialized
INFO - 2024-07-30 12:48:51 --> Router Class Initialized
INFO - 2024-07-30 12:48:51 --> Output Class Initialized
INFO - 2024-07-30 12:48:51 --> Security Class Initialized
DEBUG - 2024-07-30 12:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 12:48:51 --> Input Class Initialized
INFO - 2024-07-30 12:48:51 --> Language Class Initialized
INFO - 2024-07-30 12:48:51 --> Language Class Initialized
INFO - 2024-07-30 12:48:51 --> Config Class Initialized
INFO - 2024-07-30 12:48:51 --> Loader Class Initialized
INFO - 2024-07-30 12:48:51 --> Helper loaded: url_helper
INFO - 2024-07-30 12:48:51 --> Helper loaded: file_helper
INFO - 2024-07-30 12:48:51 --> Helper loaded: form_helper
INFO - 2024-07-30 12:48:51 --> Helper loaded: my_helper
INFO - 2024-07-30 12:48:51 --> Database Driver Class Initialized
INFO - 2024-07-30 12:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 12:48:51 --> Controller Class Initialized
DEBUG - 2024-07-30 12:48:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-30 12:48:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-30 12:48:51 --> Final output sent to browser
DEBUG - 2024-07-30 12:48:51 --> Total execution time: 0.0291
INFO - 2024-07-30 13:51:53 --> Config Class Initialized
INFO - 2024-07-30 13:51:53 --> Hooks Class Initialized
DEBUG - 2024-07-30 13:51:53 --> UTF-8 Support Enabled
INFO - 2024-07-30 13:51:53 --> Utf8 Class Initialized
INFO - 2024-07-30 13:51:53 --> URI Class Initialized
INFO - 2024-07-30 13:51:53 --> Router Class Initialized
INFO - 2024-07-30 13:51:53 --> Output Class Initialized
INFO - 2024-07-30 13:51:53 --> Security Class Initialized
DEBUG - 2024-07-30 13:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 13:51:53 --> Input Class Initialized
INFO - 2024-07-30 13:51:53 --> Language Class Initialized
INFO - 2024-07-30 13:51:53 --> Language Class Initialized
INFO - 2024-07-30 13:51:53 --> Config Class Initialized
INFO - 2024-07-30 13:51:53 --> Loader Class Initialized
INFO - 2024-07-30 13:51:53 --> Helper loaded: url_helper
INFO - 2024-07-30 13:51:53 --> Helper loaded: file_helper
INFO - 2024-07-30 13:51:53 --> Helper loaded: form_helper
INFO - 2024-07-30 13:51:53 --> Helper loaded: my_helper
INFO - 2024-07-30 13:51:53 --> Database Driver Class Initialized
INFO - 2024-07-30 13:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 13:51:53 --> Controller Class Initialized
INFO - 2024-07-30 13:51:53 --> Helper loaded: cookie_helper
INFO - 2024-07-30 13:51:53 --> Final output sent to browser
DEBUG - 2024-07-30 13:51:53 --> Total execution time: 0.0789
INFO - 2024-07-30 13:51:54 --> Config Class Initialized
INFO - 2024-07-30 13:51:54 --> Hooks Class Initialized
DEBUG - 2024-07-30 13:51:54 --> UTF-8 Support Enabled
INFO - 2024-07-30 13:51:54 --> Utf8 Class Initialized
INFO - 2024-07-30 13:51:54 --> URI Class Initialized
INFO - 2024-07-30 13:51:54 --> Router Class Initialized
INFO - 2024-07-30 13:51:54 --> Output Class Initialized
INFO - 2024-07-30 13:51:54 --> Security Class Initialized
DEBUG - 2024-07-30 13:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 13:51:54 --> Input Class Initialized
INFO - 2024-07-30 13:51:54 --> Language Class Initialized
INFO - 2024-07-30 13:51:54 --> Language Class Initialized
INFO - 2024-07-30 13:51:54 --> Config Class Initialized
INFO - 2024-07-30 13:51:54 --> Loader Class Initialized
INFO - 2024-07-30 13:51:54 --> Helper loaded: url_helper
INFO - 2024-07-30 13:51:54 --> Helper loaded: file_helper
INFO - 2024-07-30 13:51:54 --> Helper loaded: form_helper
INFO - 2024-07-30 13:51:54 --> Helper loaded: my_helper
INFO - 2024-07-30 13:51:54 --> Database Driver Class Initialized
INFO - 2024-07-30 13:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 13:51:54 --> Controller Class Initialized
INFO - 2024-07-30 13:51:54 --> Helper loaded: cookie_helper
INFO - 2024-07-30 13:51:54 --> Config Class Initialized
INFO - 2024-07-30 13:51:54 --> Hooks Class Initialized
DEBUG - 2024-07-30 13:51:54 --> UTF-8 Support Enabled
INFO - 2024-07-30 13:51:54 --> Utf8 Class Initialized
INFO - 2024-07-30 13:51:54 --> URI Class Initialized
INFO - 2024-07-30 13:51:54 --> Router Class Initialized
INFO - 2024-07-30 13:51:54 --> Output Class Initialized
INFO - 2024-07-30 13:51:54 --> Security Class Initialized
DEBUG - 2024-07-30 13:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 13:51:54 --> Input Class Initialized
INFO - 2024-07-30 13:51:54 --> Language Class Initialized
INFO - 2024-07-30 13:51:54 --> Language Class Initialized
INFO - 2024-07-30 13:51:54 --> Config Class Initialized
INFO - 2024-07-30 13:51:54 --> Loader Class Initialized
INFO - 2024-07-30 13:51:54 --> Helper loaded: url_helper
INFO - 2024-07-30 13:51:54 --> Helper loaded: file_helper
INFO - 2024-07-30 13:51:54 --> Helper loaded: form_helper
INFO - 2024-07-30 13:51:54 --> Helper loaded: my_helper
INFO - 2024-07-30 13:51:54 --> Database Driver Class Initialized
INFO - 2024-07-30 13:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 13:51:54 --> Controller Class Initialized
DEBUG - 2024-07-30 13:51:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-30 13:51:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-30 13:51:54 --> Final output sent to browser
DEBUG - 2024-07-30 13:51:54 --> Total execution time: 0.0369
INFO - 2024-07-30 13:52:06 --> Config Class Initialized
INFO - 2024-07-30 13:52:06 --> Hooks Class Initialized
DEBUG - 2024-07-30 13:52:06 --> UTF-8 Support Enabled
INFO - 2024-07-30 13:52:06 --> Utf8 Class Initialized
INFO - 2024-07-30 13:52:06 --> URI Class Initialized
INFO - 2024-07-30 13:52:06 --> Router Class Initialized
INFO - 2024-07-30 13:52:06 --> Output Class Initialized
INFO - 2024-07-30 13:52:06 --> Security Class Initialized
DEBUG - 2024-07-30 13:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 13:52:06 --> Input Class Initialized
INFO - 2024-07-30 13:52:06 --> Language Class Initialized
INFO - 2024-07-30 13:52:06 --> Language Class Initialized
INFO - 2024-07-30 13:52:06 --> Config Class Initialized
INFO - 2024-07-30 13:52:06 --> Loader Class Initialized
INFO - 2024-07-30 13:52:06 --> Helper loaded: url_helper
INFO - 2024-07-30 13:52:06 --> Helper loaded: file_helper
INFO - 2024-07-30 13:52:06 --> Helper loaded: form_helper
INFO - 2024-07-30 13:52:06 --> Helper loaded: my_helper
INFO - 2024-07-30 13:52:06 --> Database Driver Class Initialized
INFO - 2024-07-30 13:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 13:52:06 --> Controller Class Initialized
ERROR - 2024-07-30 13:52:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1156
ERROR - 2024-07-30 13:52:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1688
ERROR - 2024-07-30 13:52:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1725
ERROR - 2024-07-30 13:52:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1763
ERROR - 2024-07-30 13:52:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1802
ERROR - 2024-07-30 13:52:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1879
ERROR - 2024-07-30 13:52:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1958
ERROR - 2024-07-30 13:52:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2038
ERROR - 2024-07-30 13:52:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2118
ERROR - 2024-07-30 13:52:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2198
ERROR - 2024-07-30 13:52:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2273
ERROR - 2024-07-30 13:52:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-07-30 13:52:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 13:52:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 13:52:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-30 13:52:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-07-30 13:52:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-30 13:52:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-30 13:52:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-07-30 13:52:07 --> Config Class Initialized
INFO - 2024-07-30 13:52:07 --> Hooks Class Initialized
DEBUG - 2024-07-30 13:52:07 --> UTF-8 Support Enabled
INFO - 2024-07-30 13:52:07 --> Utf8 Class Initialized
INFO - 2024-07-30 13:52:07 --> URI Class Initialized
INFO - 2024-07-30 13:52:07 --> Router Class Initialized
INFO - 2024-07-30 13:52:07 --> Output Class Initialized
INFO - 2024-07-30 13:52:07 --> Security Class Initialized
DEBUG - 2024-07-30 13:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 13:52:07 --> Input Class Initialized
INFO - 2024-07-30 13:52:07 --> Language Class Initialized
INFO - 2024-07-30 13:52:07 --> Language Class Initialized
INFO - 2024-07-30 13:52:07 --> Config Class Initialized
INFO - 2024-07-30 13:52:07 --> Loader Class Initialized
INFO - 2024-07-30 13:52:07 --> Helper loaded: url_helper
INFO - 2024-07-30 13:52:07 --> Helper loaded: file_helper
INFO - 2024-07-30 13:52:07 --> Helper loaded: form_helper
INFO - 2024-07-30 13:52:07 --> Helper loaded: my_helper
INFO - 2024-07-30 13:52:07 --> Database Driver Class Initialized
INFO - 2024-07-30 13:52:10 --> Final output sent to browser
DEBUG - 2024-07-30 13:52:10 --> Total execution time: 3.9112
INFO - 2024-07-30 13:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 13:52:10 --> Controller Class Initialized
ERROR - 2024-07-30 13:52:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1156
ERROR - 2024-07-30 13:52:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1688
ERROR - 2024-07-30 13:52:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1725
ERROR - 2024-07-30 13:52:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1763
ERROR - 2024-07-30 13:52:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1802
ERROR - 2024-07-30 13:52:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1879
ERROR - 2024-07-30 13:52:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1958
ERROR - 2024-07-30 13:52:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2038
ERROR - 2024-07-30 13:52:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2118
ERROR - 2024-07-30 13:52:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2198
ERROR - 2024-07-30 13:52:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2273
ERROR - 2024-07-30 13:52:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-07-30 13:52:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 13:52:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 13:52:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-30 13:52:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-07-30 13:52:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-30 13:52:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-30 13:52:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-07-30 13:52:13 --> Final output sent to browser
DEBUG - 2024-07-30 13:52:13 --> Total execution time: 5.4665
INFO - 2024-07-30 14:02:44 --> Config Class Initialized
INFO - 2024-07-30 14:02:44 --> Hooks Class Initialized
DEBUG - 2024-07-30 14:02:44 --> UTF-8 Support Enabled
INFO - 2024-07-30 14:02:44 --> Utf8 Class Initialized
INFO - 2024-07-30 14:02:44 --> URI Class Initialized
INFO - 2024-07-30 14:02:44 --> Router Class Initialized
INFO - 2024-07-30 14:02:44 --> Output Class Initialized
INFO - 2024-07-30 14:02:44 --> Security Class Initialized
DEBUG - 2024-07-30 14:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 14:02:44 --> Input Class Initialized
INFO - 2024-07-30 14:02:44 --> Language Class Initialized
INFO - 2024-07-30 14:02:44 --> Language Class Initialized
INFO - 2024-07-30 14:02:44 --> Config Class Initialized
INFO - 2024-07-30 14:02:44 --> Loader Class Initialized
INFO - 2024-07-30 14:02:44 --> Helper loaded: url_helper
INFO - 2024-07-30 14:02:44 --> Helper loaded: file_helper
INFO - 2024-07-30 14:02:44 --> Helper loaded: form_helper
INFO - 2024-07-30 14:02:44 --> Helper loaded: my_helper
INFO - 2024-07-30 14:02:44 --> Database Driver Class Initialized
INFO - 2024-07-30 14:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 14:02:44 --> Controller Class Initialized
INFO - 2024-07-30 14:02:44 --> Helper loaded: cookie_helper
INFO - 2024-07-30 14:02:44 --> Final output sent to browser
DEBUG - 2024-07-30 14:02:44 --> Total execution time: 0.0563
INFO - 2024-07-30 14:02:55 --> Config Class Initialized
INFO - 2024-07-30 14:02:55 --> Hooks Class Initialized
DEBUG - 2024-07-30 14:02:55 --> UTF-8 Support Enabled
INFO - 2024-07-30 14:02:55 --> Utf8 Class Initialized
INFO - 2024-07-30 14:02:55 --> URI Class Initialized
INFO - 2024-07-30 14:02:55 --> Router Class Initialized
INFO - 2024-07-30 14:02:55 --> Output Class Initialized
INFO - 2024-07-30 14:02:55 --> Security Class Initialized
DEBUG - 2024-07-30 14:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 14:02:55 --> Input Class Initialized
INFO - 2024-07-30 14:02:55 --> Language Class Initialized
INFO - 2024-07-30 14:02:55 --> Language Class Initialized
INFO - 2024-07-30 14:02:55 --> Config Class Initialized
INFO - 2024-07-30 14:02:55 --> Loader Class Initialized
INFO - 2024-07-30 14:02:55 --> Helper loaded: url_helper
INFO - 2024-07-30 14:02:55 --> Helper loaded: file_helper
INFO - 2024-07-30 14:02:55 --> Helper loaded: form_helper
INFO - 2024-07-30 14:02:55 --> Helper loaded: my_helper
INFO - 2024-07-30 14:02:55 --> Database Driver Class Initialized
INFO - 2024-07-30 14:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 14:02:55 --> Controller Class Initialized
INFO - 2024-07-30 14:02:55 --> Helper loaded: cookie_helper
INFO - 2024-07-30 14:02:55 --> Final output sent to browser
DEBUG - 2024-07-30 14:02:55 --> Total execution time: 0.0366
INFO - 2024-07-30 14:02:55 --> Config Class Initialized
INFO - 2024-07-30 14:02:55 --> Hooks Class Initialized
DEBUG - 2024-07-30 14:02:55 --> UTF-8 Support Enabled
INFO - 2024-07-30 14:02:55 --> Utf8 Class Initialized
INFO - 2024-07-30 14:02:55 --> URI Class Initialized
INFO - 2024-07-30 14:02:55 --> Router Class Initialized
INFO - 2024-07-30 14:02:55 --> Output Class Initialized
INFO - 2024-07-30 14:02:55 --> Security Class Initialized
DEBUG - 2024-07-30 14:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 14:02:55 --> Input Class Initialized
INFO - 2024-07-30 14:02:55 --> Language Class Initialized
INFO - 2024-07-30 14:02:55 --> Language Class Initialized
INFO - 2024-07-30 14:02:55 --> Config Class Initialized
INFO - 2024-07-30 14:02:55 --> Loader Class Initialized
INFO - 2024-07-30 14:02:55 --> Helper loaded: url_helper
INFO - 2024-07-30 14:02:55 --> Helper loaded: file_helper
INFO - 2024-07-30 14:02:55 --> Helper loaded: form_helper
INFO - 2024-07-30 14:02:55 --> Helper loaded: my_helper
INFO - 2024-07-30 14:02:55 --> Database Driver Class Initialized
INFO - 2024-07-30 14:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 14:02:55 --> Controller Class Initialized
INFO - 2024-07-30 14:02:55 --> Helper loaded: cookie_helper
INFO - 2024-07-30 14:02:55 --> Final output sent to browser
DEBUG - 2024-07-30 14:02:55 --> Total execution time: 0.0354
INFO - 2024-07-30 14:14:08 --> Config Class Initialized
INFO - 2024-07-30 14:14:08 --> Hooks Class Initialized
DEBUG - 2024-07-30 14:14:08 --> UTF-8 Support Enabled
INFO - 2024-07-30 14:14:08 --> Utf8 Class Initialized
INFO - 2024-07-30 14:14:08 --> URI Class Initialized
INFO - 2024-07-30 14:14:08 --> Router Class Initialized
INFO - 2024-07-30 14:14:08 --> Output Class Initialized
INFO - 2024-07-30 14:14:08 --> Security Class Initialized
DEBUG - 2024-07-30 14:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 14:14:08 --> Input Class Initialized
INFO - 2024-07-30 14:14:08 --> Language Class Initialized
INFO - 2024-07-30 14:14:08 --> Language Class Initialized
INFO - 2024-07-30 14:14:08 --> Config Class Initialized
INFO - 2024-07-30 14:14:08 --> Loader Class Initialized
INFO - 2024-07-30 14:14:08 --> Helper loaded: url_helper
INFO - 2024-07-30 14:14:08 --> Helper loaded: file_helper
INFO - 2024-07-30 14:14:08 --> Helper loaded: form_helper
INFO - 2024-07-30 14:14:08 --> Helper loaded: my_helper
INFO - 2024-07-30 14:14:08 --> Database Driver Class Initialized
INFO - 2024-07-30 14:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 14:14:08 --> Controller Class Initialized
DEBUG - 2024-07-30 14:14:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-07-30 14:14:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-30 14:14:08 --> Final output sent to browser
DEBUG - 2024-07-30 14:14:08 --> Total execution time: 0.1081
INFO - 2024-07-30 15:26:34 --> Config Class Initialized
INFO - 2024-07-30 15:26:34 --> Hooks Class Initialized
DEBUG - 2024-07-30 15:26:34 --> UTF-8 Support Enabled
INFO - 2024-07-30 15:26:34 --> Utf8 Class Initialized
INFO - 2024-07-30 15:26:34 --> URI Class Initialized
INFO - 2024-07-30 15:26:34 --> Router Class Initialized
INFO - 2024-07-30 15:26:34 --> Output Class Initialized
INFO - 2024-07-30 15:26:34 --> Security Class Initialized
DEBUG - 2024-07-30 15:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 15:26:34 --> Input Class Initialized
INFO - 2024-07-30 15:26:34 --> Language Class Initialized
INFO - 2024-07-30 15:26:34 --> Language Class Initialized
INFO - 2024-07-30 15:26:34 --> Config Class Initialized
INFO - 2024-07-30 15:26:34 --> Loader Class Initialized
INFO - 2024-07-30 15:26:34 --> Helper loaded: url_helper
INFO - 2024-07-30 15:26:34 --> Helper loaded: file_helper
INFO - 2024-07-30 15:26:34 --> Helper loaded: form_helper
INFO - 2024-07-30 15:26:34 --> Helper loaded: my_helper
INFO - 2024-07-30 15:26:34 --> Database Driver Class Initialized
INFO - 2024-07-30 15:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 15:26:34 --> Controller Class Initialized
INFO - 2024-07-30 15:26:34 --> Helper loaded: cookie_helper
INFO - 2024-07-30 15:26:34 --> Final output sent to browser
DEBUG - 2024-07-30 15:26:34 --> Total execution time: 0.3018
INFO - 2024-07-30 15:26:35 --> Config Class Initialized
INFO - 2024-07-30 15:26:35 --> Hooks Class Initialized
DEBUG - 2024-07-30 15:26:35 --> UTF-8 Support Enabled
INFO - 2024-07-30 15:26:35 --> Utf8 Class Initialized
INFO - 2024-07-30 15:26:35 --> URI Class Initialized
INFO - 2024-07-30 15:26:35 --> Router Class Initialized
INFO - 2024-07-30 15:26:35 --> Output Class Initialized
INFO - 2024-07-30 15:26:35 --> Security Class Initialized
DEBUG - 2024-07-30 15:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 15:26:35 --> Input Class Initialized
INFO - 2024-07-30 15:26:35 --> Language Class Initialized
INFO - 2024-07-30 15:26:35 --> Language Class Initialized
INFO - 2024-07-30 15:26:35 --> Config Class Initialized
INFO - 2024-07-30 15:26:35 --> Loader Class Initialized
INFO - 2024-07-30 15:26:35 --> Helper loaded: url_helper
INFO - 2024-07-30 15:26:35 --> Helper loaded: file_helper
INFO - 2024-07-30 15:26:35 --> Helper loaded: form_helper
INFO - 2024-07-30 15:26:35 --> Helper loaded: my_helper
INFO - 2024-07-30 15:26:35 --> Database Driver Class Initialized
INFO - 2024-07-30 15:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 15:26:35 --> Controller Class Initialized
INFO - 2024-07-30 15:26:35 --> Helper loaded: cookie_helper
INFO - 2024-07-30 15:26:35 --> Config Class Initialized
INFO - 2024-07-30 15:26:35 --> Hooks Class Initialized
DEBUG - 2024-07-30 15:26:35 --> UTF-8 Support Enabled
INFO - 2024-07-30 15:26:35 --> Utf8 Class Initialized
INFO - 2024-07-30 15:26:35 --> URI Class Initialized
INFO - 2024-07-30 15:26:35 --> Router Class Initialized
INFO - 2024-07-30 15:26:35 --> Output Class Initialized
INFO - 2024-07-30 15:26:35 --> Security Class Initialized
DEBUG - 2024-07-30 15:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 15:26:35 --> Input Class Initialized
INFO - 2024-07-30 15:26:35 --> Language Class Initialized
INFO - 2024-07-30 15:26:35 --> Language Class Initialized
INFO - 2024-07-30 15:26:35 --> Config Class Initialized
INFO - 2024-07-30 15:26:35 --> Loader Class Initialized
INFO - 2024-07-30 15:26:35 --> Helper loaded: url_helper
INFO - 2024-07-30 15:26:35 --> Helper loaded: file_helper
INFO - 2024-07-30 15:26:35 --> Helper loaded: form_helper
INFO - 2024-07-30 15:26:35 --> Helper loaded: my_helper
INFO - 2024-07-30 15:26:35 --> Database Driver Class Initialized
INFO - 2024-07-30 15:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 15:26:35 --> Controller Class Initialized
DEBUG - 2024-07-30 15:26:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-30 15:26:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-30 15:26:35 --> Final output sent to browser
DEBUG - 2024-07-30 15:26:35 --> Total execution time: 0.0401
INFO - 2024-07-30 17:26:24 --> Config Class Initialized
INFO - 2024-07-30 17:26:24 --> Hooks Class Initialized
DEBUG - 2024-07-30 17:26:24 --> UTF-8 Support Enabled
INFO - 2024-07-30 17:26:24 --> Utf8 Class Initialized
INFO - 2024-07-30 17:26:24 --> URI Class Initialized
INFO - 2024-07-30 17:26:24 --> Router Class Initialized
INFO - 2024-07-30 17:26:24 --> Output Class Initialized
INFO - 2024-07-30 17:26:24 --> Security Class Initialized
DEBUG - 2024-07-30 17:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 17:26:24 --> Input Class Initialized
INFO - 2024-07-30 17:26:24 --> Language Class Initialized
INFO - 2024-07-30 17:26:24 --> Language Class Initialized
INFO - 2024-07-30 17:26:24 --> Config Class Initialized
INFO - 2024-07-30 17:26:24 --> Loader Class Initialized
INFO - 2024-07-30 17:26:24 --> Helper loaded: url_helper
INFO - 2024-07-30 17:26:24 --> Helper loaded: file_helper
INFO - 2024-07-30 17:26:24 --> Helper loaded: form_helper
INFO - 2024-07-30 17:26:24 --> Helper loaded: my_helper
INFO - 2024-07-30 17:26:24 --> Database Driver Class Initialized
INFO - 2024-07-30 17:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 17:26:24 --> Controller Class Initialized
INFO - 2024-07-30 17:26:24 --> Helper loaded: cookie_helper
INFO - 2024-07-30 17:26:24 --> Final output sent to browser
DEBUG - 2024-07-30 17:26:24 --> Total execution time: 0.0668
INFO - 2024-07-30 17:26:24 --> Config Class Initialized
INFO - 2024-07-30 17:26:24 --> Hooks Class Initialized
DEBUG - 2024-07-30 17:26:24 --> UTF-8 Support Enabled
INFO - 2024-07-30 17:26:24 --> Utf8 Class Initialized
INFO - 2024-07-30 17:26:24 --> URI Class Initialized
INFO - 2024-07-30 17:26:24 --> Router Class Initialized
INFO - 2024-07-30 17:26:24 --> Output Class Initialized
INFO - 2024-07-30 17:26:24 --> Security Class Initialized
DEBUG - 2024-07-30 17:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 17:26:24 --> Input Class Initialized
INFO - 2024-07-30 17:26:24 --> Language Class Initialized
INFO - 2024-07-30 17:26:24 --> Language Class Initialized
INFO - 2024-07-30 17:26:24 --> Config Class Initialized
INFO - 2024-07-30 17:26:24 --> Loader Class Initialized
INFO - 2024-07-30 17:26:24 --> Helper loaded: url_helper
INFO - 2024-07-30 17:26:24 --> Helper loaded: file_helper
INFO - 2024-07-30 17:26:24 --> Helper loaded: form_helper
INFO - 2024-07-30 17:26:24 --> Helper loaded: my_helper
INFO - 2024-07-30 17:26:24 --> Database Driver Class Initialized
INFO - 2024-07-30 17:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 17:26:24 --> Controller Class Initialized
INFO - 2024-07-30 17:26:24 --> Helper loaded: cookie_helper
INFO - 2024-07-30 17:26:24 --> Config Class Initialized
INFO - 2024-07-30 17:26:24 --> Hooks Class Initialized
DEBUG - 2024-07-30 17:26:24 --> UTF-8 Support Enabled
INFO - 2024-07-30 17:26:24 --> Utf8 Class Initialized
INFO - 2024-07-30 17:26:24 --> URI Class Initialized
INFO - 2024-07-30 17:26:24 --> Router Class Initialized
INFO - 2024-07-30 17:26:24 --> Output Class Initialized
INFO - 2024-07-30 17:26:24 --> Security Class Initialized
DEBUG - 2024-07-30 17:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 17:26:24 --> Input Class Initialized
INFO - 2024-07-30 17:26:24 --> Language Class Initialized
INFO - 2024-07-30 17:26:25 --> Language Class Initialized
INFO - 2024-07-30 17:26:25 --> Config Class Initialized
INFO - 2024-07-30 17:26:25 --> Loader Class Initialized
INFO - 2024-07-30 17:26:25 --> Helper loaded: url_helper
INFO - 2024-07-30 17:26:25 --> Helper loaded: file_helper
INFO - 2024-07-30 17:26:25 --> Helper loaded: form_helper
INFO - 2024-07-30 17:26:25 --> Helper loaded: my_helper
INFO - 2024-07-30 17:26:25 --> Database Driver Class Initialized
INFO - 2024-07-30 17:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 17:26:25 --> Controller Class Initialized
DEBUG - 2024-07-30 17:26:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-30 17:26:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-30 17:26:25 --> Final output sent to browser
DEBUG - 2024-07-30 17:26:25 --> Total execution time: 0.0450
INFO - 2024-07-30 17:26:31 --> Config Class Initialized
INFO - 2024-07-30 17:26:31 --> Hooks Class Initialized
DEBUG - 2024-07-30 17:26:31 --> UTF-8 Support Enabled
INFO - 2024-07-30 17:26:31 --> Utf8 Class Initialized
INFO - 2024-07-30 17:26:31 --> URI Class Initialized
INFO - 2024-07-30 17:26:31 --> Router Class Initialized
INFO - 2024-07-30 17:26:31 --> Output Class Initialized
INFO - 2024-07-30 17:26:31 --> Security Class Initialized
DEBUG - 2024-07-30 17:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 17:26:31 --> Input Class Initialized
INFO - 2024-07-30 17:26:31 --> Language Class Initialized
INFO - 2024-07-30 17:26:31 --> Language Class Initialized
INFO - 2024-07-30 17:26:31 --> Config Class Initialized
INFO - 2024-07-30 17:26:31 --> Loader Class Initialized
INFO - 2024-07-30 17:26:31 --> Helper loaded: url_helper
INFO - 2024-07-30 17:26:31 --> Helper loaded: file_helper
INFO - 2024-07-30 17:26:31 --> Helper loaded: form_helper
INFO - 2024-07-30 17:26:31 --> Helper loaded: my_helper
INFO - 2024-07-30 17:26:31 --> Database Driver Class Initialized
INFO - 2024-07-30 17:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 17:26:31 --> Controller Class Initialized
ERROR - 2024-07-30 17:26:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1156
ERROR - 2024-07-30 17:26:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1688
ERROR - 2024-07-30 17:26:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1725
ERROR - 2024-07-30 17:26:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1763
ERROR - 2024-07-30 17:26:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1802
ERROR - 2024-07-30 17:26:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1879
ERROR - 2024-07-30 17:26:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1958
ERROR - 2024-07-30 17:26:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2038
ERROR - 2024-07-30 17:26:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2118
ERROR - 2024-07-30 17:26:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2198
ERROR - 2024-07-30 17:26:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2273
ERROR - 2024-07-30 17:26:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-07-30 17:26:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 17:26:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 17:26:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-30 17:26:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-07-30 17:26:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-30 17:26:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-30 17:26:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-07-30 17:26:32 --> Config Class Initialized
INFO - 2024-07-30 17:26:32 --> Hooks Class Initialized
DEBUG - 2024-07-30 17:26:32 --> UTF-8 Support Enabled
INFO - 2024-07-30 17:26:32 --> Utf8 Class Initialized
INFO - 2024-07-30 17:26:32 --> URI Class Initialized
INFO - 2024-07-30 17:26:32 --> Router Class Initialized
INFO - 2024-07-30 17:26:32 --> Output Class Initialized
INFO - 2024-07-30 17:26:32 --> Security Class Initialized
DEBUG - 2024-07-30 17:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 17:26:32 --> Input Class Initialized
INFO - 2024-07-30 17:26:32 --> Language Class Initialized
INFO - 2024-07-30 17:26:32 --> Language Class Initialized
INFO - 2024-07-30 17:26:32 --> Config Class Initialized
INFO - 2024-07-30 17:26:32 --> Loader Class Initialized
INFO - 2024-07-30 17:26:32 --> Helper loaded: url_helper
INFO - 2024-07-30 17:26:32 --> Helper loaded: file_helper
INFO - 2024-07-30 17:26:32 --> Helper loaded: form_helper
INFO - 2024-07-30 17:26:32 --> Helper loaded: my_helper
INFO - 2024-07-30 17:26:32 --> Database Driver Class Initialized
INFO - 2024-07-30 17:26:35 --> Final output sent to browser
DEBUG - 2024-07-30 17:26:35 --> Total execution time: 3.5523
INFO - 2024-07-30 17:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 17:26:35 --> Controller Class Initialized
ERROR - 2024-07-30 17:26:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1156
ERROR - 2024-07-30 17:26:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1688
ERROR - 2024-07-30 17:26:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1725
ERROR - 2024-07-30 17:26:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1763
ERROR - 2024-07-30 17:26:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1802
ERROR - 2024-07-30 17:26:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1879
ERROR - 2024-07-30 17:26:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1958
ERROR - 2024-07-30 17:26:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2038
ERROR - 2024-07-30 17:26:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2118
ERROR - 2024-07-30 17:26:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2198
ERROR - 2024-07-30 17:26:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2273
ERROR - 2024-07-30 17:26:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-07-30 17:26:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 17:26:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 17:26:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-30 17:26:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-07-30 17:26:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-30 17:26:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-30 17:26:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-07-30 17:26:38 --> Final output sent to browser
DEBUG - 2024-07-30 17:26:38 --> Total execution time: 6.0094
INFO - 2024-07-30 17:46:09 --> Config Class Initialized
INFO - 2024-07-30 17:46:09 --> Hooks Class Initialized
DEBUG - 2024-07-30 17:46:09 --> UTF-8 Support Enabled
INFO - 2024-07-30 17:46:09 --> Utf8 Class Initialized
INFO - 2024-07-30 17:46:09 --> URI Class Initialized
INFO - 2024-07-30 17:46:09 --> Router Class Initialized
INFO - 2024-07-30 17:46:09 --> Output Class Initialized
INFO - 2024-07-30 17:46:09 --> Security Class Initialized
DEBUG - 2024-07-30 17:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 17:46:09 --> Input Class Initialized
INFO - 2024-07-30 17:46:09 --> Language Class Initialized
INFO - 2024-07-30 17:46:09 --> Language Class Initialized
INFO - 2024-07-30 17:46:09 --> Config Class Initialized
INFO - 2024-07-30 17:46:09 --> Loader Class Initialized
INFO - 2024-07-30 17:46:09 --> Helper loaded: url_helper
INFO - 2024-07-30 17:46:09 --> Helper loaded: file_helper
INFO - 2024-07-30 17:46:09 --> Helper loaded: form_helper
INFO - 2024-07-30 17:46:09 --> Helper loaded: my_helper
INFO - 2024-07-30 17:46:09 --> Database Driver Class Initialized
INFO - 2024-07-30 17:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 17:46:09 --> Controller Class Initialized
INFO - 2024-07-30 17:46:10 --> Helper loaded: cookie_helper
INFO - 2024-07-30 17:46:10 --> Final output sent to browser
DEBUG - 2024-07-30 17:46:10 --> Total execution time: 0.3870
INFO - 2024-07-30 17:46:10 --> Config Class Initialized
INFO - 2024-07-30 17:46:10 --> Hooks Class Initialized
DEBUG - 2024-07-30 17:46:10 --> UTF-8 Support Enabled
INFO - 2024-07-30 17:46:10 --> Utf8 Class Initialized
INFO - 2024-07-30 17:46:10 --> URI Class Initialized
INFO - 2024-07-30 17:46:10 --> Router Class Initialized
INFO - 2024-07-30 17:46:10 --> Output Class Initialized
INFO - 2024-07-30 17:46:10 --> Security Class Initialized
DEBUG - 2024-07-30 17:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 17:46:10 --> Input Class Initialized
INFO - 2024-07-30 17:46:10 --> Language Class Initialized
INFO - 2024-07-30 17:46:10 --> Language Class Initialized
INFO - 2024-07-30 17:46:10 --> Config Class Initialized
INFO - 2024-07-30 17:46:10 --> Loader Class Initialized
INFO - 2024-07-30 17:46:10 --> Helper loaded: url_helper
INFO - 2024-07-30 17:46:10 --> Helper loaded: file_helper
INFO - 2024-07-30 17:46:10 --> Helper loaded: form_helper
INFO - 2024-07-30 17:46:10 --> Helper loaded: my_helper
INFO - 2024-07-30 17:46:10 --> Database Driver Class Initialized
INFO - 2024-07-30 17:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 17:46:10 --> Controller Class Initialized
INFO - 2024-07-30 17:46:11 --> Helper loaded: cookie_helper
INFO - 2024-07-30 17:46:11 --> Config Class Initialized
INFO - 2024-07-30 17:46:11 --> Hooks Class Initialized
DEBUG - 2024-07-30 17:46:11 --> UTF-8 Support Enabled
INFO - 2024-07-30 17:46:11 --> Utf8 Class Initialized
INFO - 2024-07-30 17:46:11 --> URI Class Initialized
INFO - 2024-07-30 17:46:11 --> Router Class Initialized
INFO - 2024-07-30 17:46:11 --> Output Class Initialized
INFO - 2024-07-30 17:46:11 --> Security Class Initialized
DEBUG - 2024-07-30 17:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 17:46:11 --> Input Class Initialized
INFO - 2024-07-30 17:46:11 --> Language Class Initialized
INFO - 2024-07-30 17:46:11 --> Language Class Initialized
INFO - 2024-07-30 17:46:11 --> Config Class Initialized
INFO - 2024-07-30 17:46:11 --> Loader Class Initialized
INFO - 2024-07-30 17:46:11 --> Helper loaded: url_helper
INFO - 2024-07-30 17:46:11 --> Helper loaded: file_helper
INFO - 2024-07-30 17:46:11 --> Helper loaded: form_helper
INFO - 2024-07-30 17:46:11 --> Helper loaded: my_helper
INFO - 2024-07-30 17:46:11 --> Database Driver Class Initialized
INFO - 2024-07-30 17:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 17:46:11 --> Controller Class Initialized
DEBUG - 2024-07-30 17:46:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-30 17:46:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-30 17:46:11 --> Final output sent to browser
DEBUG - 2024-07-30 17:46:11 --> Total execution time: 0.0702
INFO - 2024-07-30 19:26:39 --> Config Class Initialized
INFO - 2024-07-30 19:26:39 --> Hooks Class Initialized
DEBUG - 2024-07-30 19:26:39 --> UTF-8 Support Enabled
INFO - 2024-07-30 19:26:39 --> Utf8 Class Initialized
INFO - 2024-07-30 19:26:39 --> URI Class Initialized
INFO - 2024-07-30 19:26:39 --> Router Class Initialized
INFO - 2024-07-30 19:26:39 --> Output Class Initialized
INFO - 2024-07-30 19:26:39 --> Security Class Initialized
DEBUG - 2024-07-30 19:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 19:26:39 --> Input Class Initialized
INFO - 2024-07-30 19:26:39 --> Language Class Initialized
INFO - 2024-07-30 19:26:39 --> Language Class Initialized
INFO - 2024-07-30 19:26:39 --> Config Class Initialized
INFO - 2024-07-30 19:26:39 --> Loader Class Initialized
INFO - 2024-07-30 19:26:39 --> Helper loaded: url_helper
INFO - 2024-07-30 19:26:39 --> Helper loaded: file_helper
INFO - 2024-07-30 19:26:39 --> Helper loaded: form_helper
INFO - 2024-07-30 19:26:39 --> Helper loaded: my_helper
INFO - 2024-07-30 19:26:39 --> Database Driver Class Initialized
INFO - 2024-07-30 19:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 19:26:39 --> Controller Class Initialized
INFO - 2024-07-30 19:26:39 --> Helper loaded: cookie_helper
INFO - 2024-07-30 19:26:39 --> Final output sent to browser
DEBUG - 2024-07-30 19:26:39 --> Total execution time: 0.0667
INFO - 2024-07-30 19:26:39 --> Config Class Initialized
INFO - 2024-07-30 19:26:39 --> Hooks Class Initialized
DEBUG - 2024-07-30 19:26:39 --> UTF-8 Support Enabled
INFO - 2024-07-30 19:26:39 --> Utf8 Class Initialized
INFO - 2024-07-30 19:26:39 --> URI Class Initialized
INFO - 2024-07-30 19:26:39 --> Router Class Initialized
INFO - 2024-07-30 19:26:39 --> Output Class Initialized
INFO - 2024-07-30 19:26:39 --> Security Class Initialized
DEBUG - 2024-07-30 19:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 19:26:39 --> Input Class Initialized
INFO - 2024-07-30 19:26:39 --> Language Class Initialized
INFO - 2024-07-30 19:26:39 --> Language Class Initialized
INFO - 2024-07-30 19:26:39 --> Config Class Initialized
INFO - 2024-07-30 19:26:39 --> Loader Class Initialized
INFO - 2024-07-30 19:26:39 --> Helper loaded: url_helper
INFO - 2024-07-30 19:26:39 --> Helper loaded: file_helper
INFO - 2024-07-30 19:26:39 --> Helper loaded: form_helper
INFO - 2024-07-30 19:26:39 --> Helper loaded: my_helper
INFO - 2024-07-30 19:26:39 --> Database Driver Class Initialized
INFO - 2024-07-30 19:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 19:26:39 --> Controller Class Initialized
INFO - 2024-07-30 19:26:39 --> Helper loaded: cookie_helper
INFO - 2024-07-30 19:26:39 --> Config Class Initialized
INFO - 2024-07-30 19:26:39 --> Hooks Class Initialized
DEBUG - 2024-07-30 19:26:39 --> UTF-8 Support Enabled
INFO - 2024-07-30 19:26:39 --> Utf8 Class Initialized
INFO - 2024-07-30 19:26:39 --> URI Class Initialized
INFO - 2024-07-30 19:26:39 --> Router Class Initialized
INFO - 2024-07-30 19:26:39 --> Output Class Initialized
INFO - 2024-07-30 19:26:39 --> Security Class Initialized
DEBUG - 2024-07-30 19:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 19:26:39 --> Input Class Initialized
INFO - 2024-07-30 19:26:39 --> Language Class Initialized
INFO - 2024-07-30 19:26:39 --> Language Class Initialized
INFO - 2024-07-30 19:26:39 --> Config Class Initialized
INFO - 2024-07-30 19:26:39 --> Loader Class Initialized
INFO - 2024-07-30 19:26:39 --> Helper loaded: url_helper
INFO - 2024-07-30 19:26:39 --> Helper loaded: file_helper
INFO - 2024-07-30 19:26:39 --> Helper loaded: form_helper
INFO - 2024-07-30 19:26:39 --> Helper loaded: my_helper
INFO - 2024-07-30 19:26:39 --> Database Driver Class Initialized
INFO - 2024-07-30 19:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 19:26:39 --> Controller Class Initialized
DEBUG - 2024-07-30 19:26:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-30 19:26:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-30 19:26:39 --> Final output sent to browser
DEBUG - 2024-07-30 19:26:39 --> Total execution time: 0.0454
INFO - 2024-07-30 20:54:54 --> Config Class Initialized
INFO - 2024-07-30 20:54:54 --> Hooks Class Initialized
DEBUG - 2024-07-30 20:54:54 --> UTF-8 Support Enabled
INFO - 2024-07-30 20:54:54 --> Utf8 Class Initialized
INFO - 2024-07-30 20:54:54 --> URI Class Initialized
INFO - 2024-07-30 20:54:54 --> Router Class Initialized
INFO - 2024-07-30 20:54:54 --> Output Class Initialized
INFO - 2024-07-30 20:54:54 --> Security Class Initialized
DEBUG - 2024-07-30 20:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 20:54:54 --> Input Class Initialized
INFO - 2024-07-30 20:54:54 --> Language Class Initialized
INFO - 2024-07-30 20:54:54 --> Language Class Initialized
INFO - 2024-07-30 20:54:54 --> Config Class Initialized
INFO - 2024-07-30 20:54:54 --> Loader Class Initialized
INFO - 2024-07-30 20:54:54 --> Helper loaded: url_helper
INFO - 2024-07-30 20:54:54 --> Helper loaded: file_helper
INFO - 2024-07-30 20:54:54 --> Helper loaded: form_helper
INFO - 2024-07-30 20:54:54 --> Helper loaded: my_helper
INFO - 2024-07-30 20:54:54 --> Database Driver Class Initialized
INFO - 2024-07-30 20:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 20:54:54 --> Controller Class Initialized
INFO - 2024-07-30 20:54:54 --> Helper loaded: cookie_helper
INFO - 2024-07-30 20:54:54 --> Final output sent to browser
DEBUG - 2024-07-30 20:54:54 --> Total execution time: 0.1827
INFO - 2024-07-30 20:54:55 --> Config Class Initialized
INFO - 2024-07-30 20:54:55 --> Hooks Class Initialized
DEBUG - 2024-07-30 20:54:55 --> UTF-8 Support Enabled
INFO - 2024-07-30 20:54:55 --> Utf8 Class Initialized
INFO - 2024-07-30 20:54:55 --> URI Class Initialized
INFO - 2024-07-30 20:54:55 --> Router Class Initialized
INFO - 2024-07-30 20:54:55 --> Output Class Initialized
INFO - 2024-07-30 20:54:55 --> Security Class Initialized
DEBUG - 2024-07-30 20:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 20:54:55 --> Input Class Initialized
INFO - 2024-07-30 20:54:55 --> Language Class Initialized
INFO - 2024-07-30 20:54:55 --> Language Class Initialized
INFO - 2024-07-30 20:54:55 --> Config Class Initialized
INFO - 2024-07-30 20:54:55 --> Loader Class Initialized
INFO - 2024-07-30 20:54:55 --> Helper loaded: url_helper
INFO - 2024-07-30 20:54:55 --> Helper loaded: file_helper
INFO - 2024-07-30 20:54:55 --> Helper loaded: form_helper
INFO - 2024-07-30 20:54:55 --> Helper loaded: my_helper
INFO - 2024-07-30 20:54:55 --> Database Driver Class Initialized
INFO - 2024-07-30 20:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 20:54:55 --> Controller Class Initialized
INFO - 2024-07-30 20:54:55 --> Helper loaded: cookie_helper
INFO - 2024-07-30 20:54:55 --> Config Class Initialized
INFO - 2024-07-30 20:54:55 --> Hooks Class Initialized
DEBUG - 2024-07-30 20:54:55 --> UTF-8 Support Enabled
INFO - 2024-07-30 20:54:55 --> Utf8 Class Initialized
INFO - 2024-07-30 20:54:55 --> URI Class Initialized
INFO - 2024-07-30 20:54:55 --> Router Class Initialized
INFO - 2024-07-30 20:54:55 --> Output Class Initialized
INFO - 2024-07-30 20:54:55 --> Security Class Initialized
DEBUG - 2024-07-30 20:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 20:54:55 --> Input Class Initialized
INFO - 2024-07-30 20:54:55 --> Language Class Initialized
INFO - 2024-07-30 20:54:55 --> Language Class Initialized
INFO - 2024-07-30 20:54:55 --> Config Class Initialized
INFO - 2024-07-30 20:54:55 --> Loader Class Initialized
INFO - 2024-07-30 20:54:55 --> Helper loaded: url_helper
INFO - 2024-07-30 20:54:55 --> Helper loaded: file_helper
INFO - 2024-07-30 20:54:55 --> Helper loaded: form_helper
INFO - 2024-07-30 20:54:55 --> Helper loaded: my_helper
INFO - 2024-07-30 20:54:55 --> Database Driver Class Initialized
INFO - 2024-07-30 20:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 20:54:55 --> Controller Class Initialized
DEBUG - 2024-07-30 20:54:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-30 20:54:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-30 20:54:55 --> Final output sent to browser
DEBUG - 2024-07-30 20:54:55 --> Total execution time: 0.0587
INFO - 2024-07-30 20:55:00 --> Config Class Initialized
INFO - 2024-07-30 20:55:00 --> Hooks Class Initialized
DEBUG - 2024-07-30 20:55:00 --> UTF-8 Support Enabled
INFO - 2024-07-30 20:55:00 --> Utf8 Class Initialized
INFO - 2024-07-30 20:55:00 --> URI Class Initialized
INFO - 2024-07-30 20:55:00 --> Router Class Initialized
INFO - 2024-07-30 20:55:00 --> Output Class Initialized
INFO - 2024-07-30 20:55:00 --> Security Class Initialized
DEBUG - 2024-07-30 20:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 20:55:00 --> Input Class Initialized
INFO - 2024-07-30 20:55:00 --> Language Class Initialized
INFO - 2024-07-30 20:55:00 --> Language Class Initialized
INFO - 2024-07-30 20:55:00 --> Config Class Initialized
INFO - 2024-07-30 20:55:00 --> Loader Class Initialized
INFO - 2024-07-30 20:55:00 --> Helper loaded: url_helper
INFO - 2024-07-30 20:55:00 --> Helper loaded: file_helper
INFO - 2024-07-30 20:55:00 --> Helper loaded: form_helper
INFO - 2024-07-30 20:55:00 --> Helper loaded: my_helper
INFO - 2024-07-30 20:55:00 --> Database Driver Class Initialized
INFO - 2024-07-30 20:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 20:55:00 --> Controller Class Initialized
DEBUG - 2024-07-30 20:55:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-07-30 20:55:01 --> Config Class Initialized
INFO - 2024-07-30 20:55:01 --> Hooks Class Initialized
DEBUG - 2024-07-30 20:55:01 --> UTF-8 Support Enabled
INFO - 2024-07-30 20:55:01 --> Utf8 Class Initialized
INFO - 2024-07-30 20:55:01 --> URI Class Initialized
INFO - 2024-07-30 20:55:01 --> Router Class Initialized
INFO - 2024-07-30 20:55:01 --> Output Class Initialized
INFO - 2024-07-30 20:55:01 --> Security Class Initialized
DEBUG - 2024-07-30 20:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 20:55:01 --> Input Class Initialized
INFO - 2024-07-30 20:55:01 --> Language Class Initialized
INFO - 2024-07-30 20:55:01 --> Language Class Initialized
INFO - 2024-07-30 20:55:01 --> Config Class Initialized
INFO - 2024-07-30 20:55:01 --> Loader Class Initialized
INFO - 2024-07-30 20:55:01 --> Helper loaded: url_helper
INFO - 2024-07-30 20:55:01 --> Helper loaded: file_helper
INFO - 2024-07-30 20:55:01 --> Helper loaded: form_helper
INFO - 2024-07-30 20:55:01 --> Helper loaded: my_helper
INFO - 2024-07-30 20:55:01 --> Database Driver Class Initialized
INFO - 2024-07-30 20:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 20:55:05 --> Controller Class Initialized
DEBUG - 2024-07-30 20:55:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-07-30 20:55:06 --> Config Class Initialized
INFO - 2024-07-30 20:55:06 --> Hooks Class Initialized
DEBUG - 2024-07-30 20:55:06 --> UTF-8 Support Enabled
INFO - 2024-07-30 20:55:06 --> Utf8 Class Initialized
INFO - 2024-07-30 20:55:06 --> URI Class Initialized
INFO - 2024-07-30 20:55:06 --> Router Class Initialized
INFO - 2024-07-30 20:55:06 --> Output Class Initialized
INFO - 2024-07-30 20:55:06 --> Security Class Initialized
DEBUG - 2024-07-30 20:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 20:55:06 --> Input Class Initialized
INFO - 2024-07-30 20:55:06 --> Language Class Initialized
INFO - 2024-07-30 20:55:06 --> Language Class Initialized
INFO - 2024-07-30 20:55:06 --> Config Class Initialized
INFO - 2024-07-30 20:55:06 --> Loader Class Initialized
INFO - 2024-07-30 20:55:06 --> Helper loaded: url_helper
INFO - 2024-07-30 20:55:06 --> Helper loaded: file_helper
INFO - 2024-07-30 20:55:06 --> Helper loaded: form_helper
INFO - 2024-07-30 20:55:06 --> Helper loaded: my_helper
INFO - 2024-07-30 20:55:06 --> Database Driver Class Initialized
INFO - 2024-07-30 20:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 20:55:09 --> Controller Class Initialized
ERROR - 2024-07-30 20:55:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1156
ERROR - 2024-07-30 20:55:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1688
ERROR - 2024-07-30 20:55:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1725
ERROR - 2024-07-30 20:55:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1763
ERROR - 2024-07-30 20:55:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1802
ERROR - 2024-07-30 20:55:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1879
ERROR - 2024-07-30 20:55:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1958
ERROR - 2024-07-30 20:55:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2038
ERROR - 2024-07-30 20:55:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2118
ERROR - 2024-07-30 20:55:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2198
ERROR - 2024-07-30 20:55:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2273
ERROR - 2024-07-30 20:55:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-07-30 20:55:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 20:55:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 20:55:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-30 20:55:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-07-30 20:55:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-30 20:55:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-30 20:55:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-07-30 20:55:13 --> Final output sent to browser
DEBUG - 2024-07-30 20:55:13 --> Total execution time: 7.0474
INFO - 2024-07-30 20:55:25 --> Config Class Initialized
INFO - 2024-07-30 20:55:25 --> Hooks Class Initialized
DEBUG - 2024-07-30 20:55:25 --> UTF-8 Support Enabled
INFO - 2024-07-30 20:55:25 --> Utf8 Class Initialized
INFO - 2024-07-30 20:55:25 --> URI Class Initialized
INFO - 2024-07-30 20:55:25 --> Router Class Initialized
INFO - 2024-07-30 20:55:25 --> Output Class Initialized
INFO - 2024-07-30 20:55:25 --> Security Class Initialized
DEBUG - 2024-07-30 20:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 20:55:25 --> Input Class Initialized
INFO - 2024-07-30 20:55:25 --> Language Class Initialized
INFO - 2024-07-30 20:55:25 --> Language Class Initialized
INFO - 2024-07-30 20:55:25 --> Config Class Initialized
INFO - 2024-07-30 20:55:25 --> Loader Class Initialized
INFO - 2024-07-30 20:55:25 --> Helper loaded: url_helper
INFO - 2024-07-30 20:55:25 --> Helper loaded: file_helper
INFO - 2024-07-30 20:55:25 --> Helper loaded: form_helper
INFO - 2024-07-30 20:55:25 --> Helper loaded: my_helper
INFO - 2024-07-30 20:55:25 --> Database Driver Class Initialized
INFO - 2024-07-30 20:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 20:55:25 --> Controller Class Initialized
INFO - 2024-07-30 20:55:25 --> Helper loaded: cookie_helper
INFO - 2024-07-30 20:55:25 --> Final output sent to browser
DEBUG - 2024-07-30 20:55:25 --> Total execution time: 0.0356
INFO - 2024-07-30 20:55:26 --> Config Class Initialized
INFO - 2024-07-30 20:55:26 --> Hooks Class Initialized
DEBUG - 2024-07-30 20:55:26 --> UTF-8 Support Enabled
INFO - 2024-07-30 20:55:26 --> Utf8 Class Initialized
INFO - 2024-07-30 20:55:26 --> URI Class Initialized
INFO - 2024-07-30 20:55:26 --> Router Class Initialized
INFO - 2024-07-30 20:55:26 --> Output Class Initialized
INFO - 2024-07-30 20:55:26 --> Security Class Initialized
DEBUG - 2024-07-30 20:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 20:55:26 --> Input Class Initialized
INFO - 2024-07-30 20:55:26 --> Language Class Initialized
INFO - 2024-07-30 20:55:26 --> Language Class Initialized
INFO - 2024-07-30 20:55:26 --> Config Class Initialized
INFO - 2024-07-30 20:55:26 --> Loader Class Initialized
INFO - 2024-07-30 20:55:26 --> Helper loaded: url_helper
INFO - 2024-07-30 20:55:26 --> Helper loaded: file_helper
INFO - 2024-07-30 20:55:26 --> Helper loaded: form_helper
INFO - 2024-07-30 20:55:26 --> Helper loaded: my_helper
INFO - 2024-07-30 20:55:26 --> Database Driver Class Initialized
INFO - 2024-07-30 20:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 20:55:26 --> Controller Class Initialized
INFO - 2024-07-30 20:55:26 --> Helper loaded: cookie_helper
INFO - 2024-07-30 20:55:26 --> Config Class Initialized
INFO - 2024-07-30 20:55:26 --> Hooks Class Initialized
DEBUG - 2024-07-30 20:55:26 --> UTF-8 Support Enabled
INFO - 2024-07-30 20:55:26 --> Utf8 Class Initialized
INFO - 2024-07-30 20:55:26 --> URI Class Initialized
INFO - 2024-07-30 20:55:26 --> Router Class Initialized
INFO - 2024-07-30 20:55:26 --> Output Class Initialized
INFO - 2024-07-30 20:55:26 --> Security Class Initialized
DEBUG - 2024-07-30 20:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 20:55:26 --> Input Class Initialized
INFO - 2024-07-30 20:55:26 --> Language Class Initialized
INFO - 2024-07-30 20:55:26 --> Language Class Initialized
INFO - 2024-07-30 20:55:26 --> Config Class Initialized
INFO - 2024-07-30 20:55:26 --> Loader Class Initialized
INFO - 2024-07-30 20:55:26 --> Helper loaded: url_helper
INFO - 2024-07-30 20:55:26 --> Helper loaded: file_helper
INFO - 2024-07-30 20:55:26 --> Helper loaded: form_helper
INFO - 2024-07-30 20:55:26 --> Helper loaded: my_helper
INFO - 2024-07-30 20:55:26 --> Database Driver Class Initialized
INFO - 2024-07-30 20:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 20:55:26 --> Controller Class Initialized
DEBUG - 2024-07-30 20:55:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-30 20:55:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-30 20:55:26 --> Final output sent to browser
DEBUG - 2024-07-30 20:55:26 --> Total execution time: 0.0258
INFO - 2024-07-30 20:55:30 --> Config Class Initialized
INFO - 2024-07-30 20:55:30 --> Hooks Class Initialized
DEBUG - 2024-07-30 20:55:30 --> UTF-8 Support Enabled
INFO - 2024-07-30 20:55:30 --> Utf8 Class Initialized
INFO - 2024-07-30 20:55:30 --> URI Class Initialized
INFO - 2024-07-30 20:55:30 --> Router Class Initialized
INFO - 2024-07-30 20:55:30 --> Output Class Initialized
INFO - 2024-07-30 20:55:30 --> Security Class Initialized
DEBUG - 2024-07-30 20:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 20:55:30 --> Input Class Initialized
INFO - 2024-07-30 20:55:30 --> Language Class Initialized
INFO - 2024-07-30 20:55:30 --> Language Class Initialized
INFO - 2024-07-30 20:55:30 --> Config Class Initialized
INFO - 2024-07-30 20:55:30 --> Loader Class Initialized
INFO - 2024-07-30 20:55:30 --> Helper loaded: url_helper
INFO - 2024-07-30 20:55:30 --> Helper loaded: file_helper
INFO - 2024-07-30 20:55:30 --> Helper loaded: form_helper
INFO - 2024-07-30 20:55:30 --> Helper loaded: my_helper
INFO - 2024-07-30 20:55:30 --> Database Driver Class Initialized
INFO - 2024-07-30 20:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 20:55:30 --> Controller Class Initialized
ERROR - 2024-07-30 20:55:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1791
ERROR - 2024-07-30 20:55:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1798
ERROR - 2024-07-30 20:55:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2016
ERROR - 2024-07-30 20:55:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2016
ERROR - 2024-07-30 20:55:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-07-30 20:55:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 86
ERROR - 2024-07-30 20:55:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-07-30 20:55:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-07-30 20:55:30 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-07-30 20:55:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-07-30 20:55:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-07-30 20:55:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
ERROR - 2024-07-30 20:55:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2031
ERROR - 2024-07-30 20:55:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2031
INFO - 2024-07-30 20:55:33 --> Final output sent to browser
DEBUG - 2024-07-30 20:55:33 --> Total execution time: 3.0975
INFO - 2024-07-30 23:13:10 --> Config Class Initialized
INFO - 2024-07-30 23:13:10 --> Hooks Class Initialized
DEBUG - 2024-07-30 23:13:10 --> UTF-8 Support Enabled
INFO - 2024-07-30 23:13:10 --> Utf8 Class Initialized
INFO - 2024-07-30 23:13:10 --> URI Class Initialized
INFO - 2024-07-30 23:13:10 --> Router Class Initialized
INFO - 2024-07-30 23:13:10 --> Output Class Initialized
INFO - 2024-07-30 23:13:10 --> Security Class Initialized
DEBUG - 2024-07-30 23:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 23:13:10 --> Input Class Initialized
INFO - 2024-07-30 23:13:10 --> Language Class Initialized
INFO - 2024-07-30 23:13:10 --> Language Class Initialized
INFO - 2024-07-30 23:13:10 --> Config Class Initialized
INFO - 2024-07-30 23:13:10 --> Loader Class Initialized
INFO - 2024-07-30 23:13:10 --> Helper loaded: url_helper
INFO - 2024-07-30 23:13:10 --> Helper loaded: file_helper
INFO - 2024-07-30 23:13:10 --> Helper loaded: form_helper
INFO - 2024-07-30 23:13:10 --> Helper loaded: my_helper
INFO - 2024-07-30 23:13:10 --> Database Driver Class Initialized
INFO - 2024-07-30 23:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 23:13:10 --> Controller Class Initialized
INFO - 2024-07-30 23:13:10 --> Helper loaded: cookie_helper
INFO - 2024-07-30 23:13:10 --> Final output sent to browser
DEBUG - 2024-07-30 23:13:10 --> Total execution time: 0.0594
INFO - 2024-07-30 23:13:11 --> Config Class Initialized
INFO - 2024-07-30 23:13:11 --> Hooks Class Initialized
DEBUG - 2024-07-30 23:13:11 --> UTF-8 Support Enabled
INFO - 2024-07-30 23:13:11 --> Utf8 Class Initialized
INFO - 2024-07-30 23:13:11 --> URI Class Initialized
INFO - 2024-07-30 23:13:11 --> Router Class Initialized
INFO - 2024-07-30 23:13:11 --> Output Class Initialized
INFO - 2024-07-30 23:13:11 --> Security Class Initialized
DEBUG - 2024-07-30 23:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 23:13:11 --> Input Class Initialized
INFO - 2024-07-30 23:13:11 --> Language Class Initialized
INFO - 2024-07-30 23:13:11 --> Language Class Initialized
INFO - 2024-07-30 23:13:11 --> Config Class Initialized
INFO - 2024-07-30 23:13:11 --> Loader Class Initialized
INFO - 2024-07-30 23:13:11 --> Helper loaded: url_helper
INFO - 2024-07-30 23:13:11 --> Helper loaded: file_helper
INFO - 2024-07-30 23:13:11 --> Helper loaded: form_helper
INFO - 2024-07-30 23:13:11 --> Helper loaded: my_helper
INFO - 2024-07-30 23:13:11 --> Database Driver Class Initialized
INFO - 2024-07-30 23:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 23:13:11 --> Controller Class Initialized
INFO - 2024-07-30 23:13:11 --> Helper loaded: cookie_helper
INFO - 2024-07-30 23:13:11 --> Config Class Initialized
INFO - 2024-07-30 23:13:11 --> Hooks Class Initialized
DEBUG - 2024-07-30 23:13:11 --> UTF-8 Support Enabled
INFO - 2024-07-30 23:13:11 --> Utf8 Class Initialized
INFO - 2024-07-30 23:13:11 --> URI Class Initialized
INFO - 2024-07-30 23:13:11 --> Router Class Initialized
INFO - 2024-07-30 23:13:11 --> Output Class Initialized
INFO - 2024-07-30 23:13:11 --> Security Class Initialized
DEBUG - 2024-07-30 23:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 23:13:11 --> Input Class Initialized
INFO - 2024-07-30 23:13:11 --> Language Class Initialized
INFO - 2024-07-30 23:13:11 --> Language Class Initialized
INFO - 2024-07-30 23:13:11 --> Config Class Initialized
INFO - 2024-07-30 23:13:11 --> Loader Class Initialized
INFO - 2024-07-30 23:13:11 --> Helper loaded: url_helper
INFO - 2024-07-30 23:13:11 --> Helper loaded: file_helper
INFO - 2024-07-30 23:13:11 --> Helper loaded: form_helper
INFO - 2024-07-30 23:13:11 --> Helper loaded: my_helper
INFO - 2024-07-30 23:13:11 --> Database Driver Class Initialized
INFO - 2024-07-30 23:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 23:13:11 --> Controller Class Initialized
DEBUG - 2024-07-30 23:13:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-30 23:13:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-30 23:13:11 --> Final output sent to browser
DEBUG - 2024-07-30 23:13:11 --> Total execution time: 0.1491
INFO - 2024-07-30 23:13:18 --> Config Class Initialized
INFO - 2024-07-30 23:13:18 --> Hooks Class Initialized
DEBUG - 2024-07-30 23:13:18 --> UTF-8 Support Enabled
INFO - 2024-07-30 23:13:18 --> Utf8 Class Initialized
INFO - 2024-07-30 23:13:18 --> URI Class Initialized
INFO - 2024-07-30 23:13:18 --> Router Class Initialized
INFO - 2024-07-30 23:13:18 --> Output Class Initialized
INFO - 2024-07-30 23:13:18 --> Security Class Initialized
DEBUG - 2024-07-30 23:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-30 23:13:18 --> Input Class Initialized
INFO - 2024-07-30 23:13:18 --> Language Class Initialized
INFO - 2024-07-30 23:13:18 --> Language Class Initialized
INFO - 2024-07-30 23:13:18 --> Config Class Initialized
INFO - 2024-07-30 23:13:18 --> Loader Class Initialized
INFO - 2024-07-30 23:13:18 --> Helper loaded: url_helper
INFO - 2024-07-30 23:13:18 --> Helper loaded: file_helper
INFO - 2024-07-30 23:13:18 --> Helper loaded: form_helper
INFO - 2024-07-30 23:13:18 --> Helper loaded: my_helper
INFO - 2024-07-30 23:13:18 --> Database Driver Class Initialized
INFO - 2024-07-30 23:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-30 23:13:18 --> Controller Class Initialized
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 97
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 614
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 614
ERROR - 2024-07-30 23:13:18 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 614
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 651
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 651
ERROR - 2024-07-30 23:13:18 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 651
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Undefined offset: 17 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 689
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 689
ERROR - 2024-07-30 23:13:18 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 689
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 905
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-30 23:13:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-30 23:13:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
ERROR - 2024-07-30 23:13:22 --> Severity: error --> Exception: The content of the TD tag does not fit on only one page /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/spipu/html2pdf/src/Html2Pdf.php 5680
ERROR - 2024-07-30 23:13:22 --> Severity: Warning --> unlink(/tmp/__tcpdf_47e4fd7c9ef8b90837fa0113dde19e30_imgmask_alpha_5c8c5820de2d21abc04c055a7edbdf01): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/tecnickcom/tcpdf/tcpdf.php 7801
ERROR - 2024-07-30 23:13:22 --> Severity: Warning --> unlink(/tmp/__tcpdf_47e4fd7c9ef8b90837fa0113dde19e30_imgmask_plain_5c8c5820de2d21abc04c055a7edbdf01): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/tecnickcom/tcpdf/tcpdf.php 7801
ERROR - 2024-07-30 23:13:22 --> Severity: Warning --> unlink(/tmp/__tcpdf_47e4fd7c9ef8b90837fa0113dde19e30_imgmask_alpha_9b9826062a8f1eb306f7a4635f009d01): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/tecnickcom/tcpdf/tcpdf.php 7801
ERROR - 2024-07-30 23:13:22 --> Severity: Warning --> unlink(/tmp/__tcpdf_47e4fd7c9ef8b90837fa0113dde19e30_imgmask_plain_9b9826062a8f1eb306f7a4635f009d01): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/tecnickcom/tcpdf/tcpdf.php 7801
