<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-01 09:38:53 --> Config Class Initialized
INFO - 2024-08-01 09:38:53 --> Hooks Class Initialized
DEBUG - 2024-08-01 09:38:53 --> UTF-8 Support Enabled
INFO - 2024-08-01 09:38:53 --> Utf8 Class Initialized
INFO - 2024-08-01 09:38:53 --> URI Class Initialized
INFO - 2024-08-01 09:38:53 --> Router Class Initialized
INFO - 2024-08-01 09:38:53 --> Output Class Initialized
INFO - 2024-08-01 09:38:53 --> Security Class Initialized
DEBUG - 2024-08-01 09:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 09:38:53 --> Input Class Initialized
INFO - 2024-08-01 09:38:53 --> Language Class Initialized
INFO - 2024-08-01 09:38:53 --> Language Class Initialized
INFO - 2024-08-01 09:38:53 --> Config Class Initialized
INFO - 2024-08-01 09:38:53 --> Loader Class Initialized
INFO - 2024-08-01 09:38:53 --> Helper loaded: url_helper
INFO - 2024-08-01 09:38:53 --> Helper loaded: file_helper
INFO - 2024-08-01 09:38:53 --> Helper loaded: form_helper
INFO - 2024-08-01 09:38:53 --> Helper loaded: my_helper
INFO - 2024-08-01 09:38:53 --> Database Driver Class Initialized
INFO - 2024-08-01 09:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 09:38:53 --> Controller Class Initialized
INFO - 2024-08-01 09:38:53 --> Helper loaded: cookie_helper
INFO - 2024-08-01 09:38:53 --> Final output sent to browser
DEBUG - 2024-08-01 09:38:53 --> Total execution time: 0.0715
INFO - 2024-08-01 09:38:54 --> Config Class Initialized
INFO - 2024-08-01 09:38:54 --> Hooks Class Initialized
DEBUG - 2024-08-01 09:38:54 --> UTF-8 Support Enabled
INFO - 2024-08-01 09:38:54 --> Utf8 Class Initialized
INFO - 2024-08-01 09:38:54 --> URI Class Initialized
INFO - 2024-08-01 09:38:54 --> Router Class Initialized
INFO - 2024-08-01 09:38:54 --> Output Class Initialized
INFO - 2024-08-01 09:38:54 --> Security Class Initialized
DEBUG - 2024-08-01 09:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 09:38:54 --> Input Class Initialized
INFO - 2024-08-01 09:38:54 --> Language Class Initialized
INFO - 2024-08-01 09:38:54 --> Language Class Initialized
INFO - 2024-08-01 09:38:54 --> Config Class Initialized
INFO - 2024-08-01 09:38:54 --> Loader Class Initialized
INFO - 2024-08-01 09:38:54 --> Helper loaded: url_helper
INFO - 2024-08-01 09:38:54 --> Helper loaded: file_helper
INFO - 2024-08-01 09:38:54 --> Helper loaded: form_helper
INFO - 2024-08-01 09:38:54 --> Helper loaded: my_helper
INFO - 2024-08-01 09:38:54 --> Database Driver Class Initialized
INFO - 2024-08-01 09:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 09:38:54 --> Controller Class Initialized
INFO - 2024-08-01 09:38:54 --> Helper loaded: cookie_helper
INFO - 2024-08-01 09:38:54 --> Config Class Initialized
INFO - 2024-08-01 09:38:54 --> Hooks Class Initialized
DEBUG - 2024-08-01 09:38:54 --> UTF-8 Support Enabled
INFO - 2024-08-01 09:38:54 --> Utf8 Class Initialized
INFO - 2024-08-01 09:38:54 --> URI Class Initialized
INFO - 2024-08-01 09:38:54 --> Router Class Initialized
INFO - 2024-08-01 09:38:54 --> Output Class Initialized
INFO - 2024-08-01 09:38:54 --> Security Class Initialized
DEBUG - 2024-08-01 09:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 09:38:54 --> Input Class Initialized
INFO - 2024-08-01 09:38:54 --> Language Class Initialized
INFO - 2024-08-01 09:38:54 --> Language Class Initialized
INFO - 2024-08-01 09:38:54 --> Config Class Initialized
INFO - 2024-08-01 09:38:54 --> Loader Class Initialized
INFO - 2024-08-01 09:38:54 --> Helper loaded: url_helper
INFO - 2024-08-01 09:38:54 --> Helper loaded: file_helper
INFO - 2024-08-01 09:38:54 --> Helper loaded: form_helper
INFO - 2024-08-01 09:38:54 --> Helper loaded: my_helper
INFO - 2024-08-01 09:38:54 --> Database Driver Class Initialized
INFO - 2024-08-01 09:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 09:38:54 --> Controller Class Initialized
DEBUG - 2024-08-01 09:38:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-01 09:38:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 09:38:54 --> Final output sent to browser
DEBUG - 2024-08-01 09:38:54 --> Total execution time: 0.0497
INFO - 2024-08-01 09:39:00 --> Config Class Initialized
INFO - 2024-08-01 09:39:00 --> Hooks Class Initialized
DEBUG - 2024-08-01 09:39:00 --> UTF-8 Support Enabled
INFO - 2024-08-01 09:39:00 --> Utf8 Class Initialized
INFO - 2024-08-01 09:39:00 --> URI Class Initialized
INFO - 2024-08-01 09:39:00 --> Router Class Initialized
INFO - 2024-08-01 09:39:00 --> Output Class Initialized
INFO - 2024-08-01 09:39:00 --> Security Class Initialized
DEBUG - 2024-08-01 09:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 09:39:00 --> Input Class Initialized
INFO - 2024-08-01 09:39:00 --> Language Class Initialized
INFO - 2024-08-01 09:39:00 --> Language Class Initialized
INFO - 2024-08-01 09:39:00 --> Config Class Initialized
INFO - 2024-08-01 09:39:00 --> Loader Class Initialized
INFO - 2024-08-01 09:39:00 --> Helper loaded: url_helper
INFO - 2024-08-01 09:39:00 --> Helper loaded: file_helper
INFO - 2024-08-01 09:39:00 --> Helper loaded: form_helper
INFO - 2024-08-01 09:39:00 --> Helper loaded: my_helper
INFO - 2024-08-01 09:39:00 --> Database Driver Class Initialized
INFO - 2024-08-01 09:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 09:39:00 --> Controller Class Initialized
DEBUG - 2024-08-01 09:39:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-01 09:39:03 --> Config Class Initialized
INFO - 2024-08-01 09:39:03 --> Hooks Class Initialized
DEBUG - 2024-08-01 09:39:03 --> UTF-8 Support Enabled
INFO - 2024-08-01 09:39:03 --> Utf8 Class Initialized
INFO - 2024-08-01 09:39:03 --> URI Class Initialized
INFO - 2024-08-01 09:39:03 --> Router Class Initialized
INFO - 2024-08-01 09:39:03 --> Output Class Initialized
INFO - 2024-08-01 09:39:03 --> Security Class Initialized
DEBUG - 2024-08-01 09:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 09:39:03 --> Input Class Initialized
INFO - 2024-08-01 09:39:03 --> Language Class Initialized
INFO - 2024-08-01 09:39:03 --> Language Class Initialized
INFO - 2024-08-01 09:39:03 --> Config Class Initialized
INFO - 2024-08-01 09:39:03 --> Loader Class Initialized
INFO - 2024-08-01 09:39:03 --> Helper loaded: url_helper
INFO - 2024-08-01 09:39:03 --> Helper loaded: file_helper
INFO - 2024-08-01 09:39:03 --> Helper loaded: form_helper
INFO - 2024-08-01 09:39:03 --> Helper loaded: my_helper
INFO - 2024-08-01 09:39:03 --> Database Driver Class Initialized
INFO - 2024-08-01 09:39:04 --> Config Class Initialized
INFO - 2024-08-01 09:39:04 --> Hooks Class Initialized
DEBUG - 2024-08-01 09:39:04 --> UTF-8 Support Enabled
INFO - 2024-08-01 09:39:04 --> Utf8 Class Initialized
INFO - 2024-08-01 09:39:04 --> URI Class Initialized
INFO - 2024-08-01 09:39:04 --> Router Class Initialized
INFO - 2024-08-01 09:39:04 --> Output Class Initialized
INFO - 2024-08-01 09:39:04 --> Security Class Initialized
DEBUG - 2024-08-01 09:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 09:39:04 --> Input Class Initialized
INFO - 2024-08-01 09:39:04 --> Language Class Initialized
INFO - 2024-08-01 09:39:04 --> Language Class Initialized
INFO - 2024-08-01 09:39:04 --> Config Class Initialized
INFO - 2024-08-01 09:39:04 --> Loader Class Initialized
INFO - 2024-08-01 09:39:04 --> Helper loaded: url_helper
INFO - 2024-08-01 09:39:04 --> Helper loaded: file_helper
INFO - 2024-08-01 09:39:04 --> Helper loaded: form_helper
INFO - 2024-08-01 09:39:04 --> Helper loaded: my_helper
INFO - 2024-08-01 09:39:04 --> Database Driver Class Initialized
INFO - 2024-08-01 09:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 09:39:06 --> Controller Class Initialized
DEBUG - 2024-08-01 09:39:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-01 09:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 09:39:10 --> Controller Class Initialized
DEBUG - 2024-08-01 09:39:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-01 09:39:14 --> Final output sent to browser
DEBUG - 2024-08-01 09:39:14 --> Total execution time: 10.0667
INFO - 2024-08-01 12:23:08 --> Config Class Initialized
INFO - 2024-08-01 12:23:08 --> Hooks Class Initialized
DEBUG - 2024-08-01 12:23:08 --> UTF-8 Support Enabled
INFO - 2024-08-01 12:23:08 --> Utf8 Class Initialized
INFO - 2024-08-01 12:23:08 --> URI Class Initialized
INFO - 2024-08-01 12:23:08 --> Router Class Initialized
INFO - 2024-08-01 12:23:08 --> Output Class Initialized
INFO - 2024-08-01 12:23:08 --> Security Class Initialized
DEBUG - 2024-08-01 12:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 12:23:08 --> Input Class Initialized
INFO - 2024-08-01 12:23:08 --> Language Class Initialized
INFO - 2024-08-01 12:23:08 --> Language Class Initialized
INFO - 2024-08-01 12:23:08 --> Config Class Initialized
INFO - 2024-08-01 12:23:08 --> Loader Class Initialized
INFO - 2024-08-01 12:23:08 --> Helper loaded: url_helper
INFO - 2024-08-01 12:23:08 --> Helper loaded: file_helper
INFO - 2024-08-01 12:23:08 --> Helper loaded: form_helper
INFO - 2024-08-01 12:23:08 --> Helper loaded: my_helper
INFO - 2024-08-01 12:23:08 --> Database Driver Class Initialized
INFO - 2024-08-01 12:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 12:23:08 --> Controller Class Initialized
INFO - 2024-08-01 12:23:08 --> Helper loaded: cookie_helper
INFO - 2024-08-01 12:23:08 --> Final output sent to browser
DEBUG - 2024-08-01 12:23:08 --> Total execution time: 0.0638
INFO - 2024-08-01 12:23:10 --> Config Class Initialized
INFO - 2024-08-01 12:23:10 --> Hooks Class Initialized
DEBUG - 2024-08-01 12:23:10 --> UTF-8 Support Enabled
INFO - 2024-08-01 12:23:10 --> Utf8 Class Initialized
INFO - 2024-08-01 12:23:10 --> URI Class Initialized
INFO - 2024-08-01 12:23:10 --> Router Class Initialized
INFO - 2024-08-01 12:23:10 --> Output Class Initialized
INFO - 2024-08-01 12:23:10 --> Security Class Initialized
DEBUG - 2024-08-01 12:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 12:23:10 --> Input Class Initialized
INFO - 2024-08-01 12:23:10 --> Language Class Initialized
INFO - 2024-08-01 12:23:10 --> Language Class Initialized
INFO - 2024-08-01 12:23:10 --> Config Class Initialized
INFO - 2024-08-01 12:23:10 --> Loader Class Initialized
INFO - 2024-08-01 12:23:10 --> Helper loaded: url_helper
INFO - 2024-08-01 12:23:10 --> Helper loaded: file_helper
INFO - 2024-08-01 12:23:10 --> Helper loaded: form_helper
INFO - 2024-08-01 12:23:10 --> Helper loaded: my_helper
INFO - 2024-08-01 12:23:10 --> Database Driver Class Initialized
INFO - 2024-08-01 12:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 12:23:10 --> Controller Class Initialized
INFO - 2024-08-01 12:23:10 --> Helper loaded: cookie_helper
INFO - 2024-08-01 12:23:10 --> Config Class Initialized
INFO - 2024-08-01 12:23:10 --> Hooks Class Initialized
DEBUG - 2024-08-01 12:23:10 --> UTF-8 Support Enabled
INFO - 2024-08-01 12:23:10 --> Utf8 Class Initialized
INFO - 2024-08-01 12:23:10 --> URI Class Initialized
INFO - 2024-08-01 12:23:10 --> Router Class Initialized
INFO - 2024-08-01 12:23:10 --> Output Class Initialized
INFO - 2024-08-01 12:23:10 --> Security Class Initialized
DEBUG - 2024-08-01 12:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 12:23:10 --> Input Class Initialized
INFO - 2024-08-01 12:23:10 --> Language Class Initialized
INFO - 2024-08-01 12:23:10 --> Language Class Initialized
INFO - 2024-08-01 12:23:10 --> Config Class Initialized
INFO - 2024-08-01 12:23:10 --> Loader Class Initialized
INFO - 2024-08-01 12:23:10 --> Helper loaded: url_helper
INFO - 2024-08-01 12:23:10 --> Helper loaded: file_helper
INFO - 2024-08-01 12:23:10 --> Helper loaded: form_helper
INFO - 2024-08-01 12:23:10 --> Helper loaded: my_helper
INFO - 2024-08-01 12:23:10 --> Database Driver Class Initialized
INFO - 2024-08-01 12:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 12:23:10 --> Controller Class Initialized
DEBUG - 2024-08-01 12:23:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-01 12:23:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 12:23:10 --> Final output sent to browser
DEBUG - 2024-08-01 12:23:10 --> Total execution time: 0.0758
INFO - 2024-08-01 14:42:11 --> Config Class Initialized
INFO - 2024-08-01 14:42:11 --> Hooks Class Initialized
DEBUG - 2024-08-01 14:42:11 --> UTF-8 Support Enabled
INFO - 2024-08-01 14:42:11 --> Utf8 Class Initialized
INFO - 2024-08-01 14:42:11 --> URI Class Initialized
INFO - 2024-08-01 14:42:11 --> Router Class Initialized
INFO - 2024-08-01 14:42:11 --> Output Class Initialized
INFO - 2024-08-01 14:42:11 --> Security Class Initialized
DEBUG - 2024-08-01 14:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 14:42:11 --> Input Class Initialized
INFO - 2024-08-01 14:42:11 --> Language Class Initialized
INFO - 2024-08-01 14:42:11 --> Language Class Initialized
INFO - 2024-08-01 14:42:11 --> Config Class Initialized
INFO - 2024-08-01 14:42:11 --> Loader Class Initialized
INFO - 2024-08-01 14:42:11 --> Helper loaded: url_helper
INFO - 2024-08-01 14:42:11 --> Helper loaded: file_helper
INFO - 2024-08-01 14:42:11 --> Helper loaded: form_helper
INFO - 2024-08-01 14:42:11 --> Helper loaded: my_helper
INFO - 2024-08-01 14:42:11 --> Database Driver Class Initialized
INFO - 2024-08-01 14:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 14:42:11 --> Controller Class Initialized
INFO - 2024-08-01 14:42:11 --> Helper loaded: cookie_helper
INFO - 2024-08-01 14:42:11 --> Final output sent to browser
DEBUG - 2024-08-01 14:42:11 --> Total execution time: 0.0517
INFO - 2024-08-01 14:42:11 --> Config Class Initialized
INFO - 2024-08-01 14:42:11 --> Hooks Class Initialized
DEBUG - 2024-08-01 14:42:11 --> UTF-8 Support Enabled
INFO - 2024-08-01 14:42:11 --> Utf8 Class Initialized
INFO - 2024-08-01 14:42:11 --> URI Class Initialized
INFO - 2024-08-01 14:42:11 --> Router Class Initialized
INFO - 2024-08-01 14:42:11 --> Output Class Initialized
INFO - 2024-08-01 14:42:11 --> Security Class Initialized
DEBUG - 2024-08-01 14:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 14:42:11 --> Input Class Initialized
INFO - 2024-08-01 14:42:11 --> Language Class Initialized
INFO - 2024-08-01 14:42:11 --> Language Class Initialized
INFO - 2024-08-01 14:42:11 --> Config Class Initialized
INFO - 2024-08-01 14:42:11 --> Loader Class Initialized
INFO - 2024-08-01 14:42:11 --> Helper loaded: url_helper
INFO - 2024-08-01 14:42:11 --> Helper loaded: file_helper
INFO - 2024-08-01 14:42:11 --> Helper loaded: form_helper
INFO - 2024-08-01 14:42:11 --> Helper loaded: my_helper
INFO - 2024-08-01 14:42:11 --> Database Driver Class Initialized
INFO - 2024-08-01 14:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 14:42:11 --> Controller Class Initialized
INFO - 2024-08-01 14:42:11 --> Helper loaded: cookie_helper
INFO - 2024-08-01 14:42:12 --> Config Class Initialized
INFO - 2024-08-01 14:42:12 --> Hooks Class Initialized
DEBUG - 2024-08-01 14:42:12 --> UTF-8 Support Enabled
INFO - 2024-08-01 14:42:12 --> Utf8 Class Initialized
INFO - 2024-08-01 14:42:12 --> URI Class Initialized
INFO - 2024-08-01 14:42:12 --> Router Class Initialized
INFO - 2024-08-01 14:42:12 --> Output Class Initialized
INFO - 2024-08-01 14:42:12 --> Security Class Initialized
DEBUG - 2024-08-01 14:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 14:42:12 --> Input Class Initialized
INFO - 2024-08-01 14:42:12 --> Language Class Initialized
INFO - 2024-08-01 14:42:12 --> Language Class Initialized
INFO - 2024-08-01 14:42:12 --> Config Class Initialized
INFO - 2024-08-01 14:42:12 --> Loader Class Initialized
INFO - 2024-08-01 14:42:12 --> Helper loaded: url_helper
INFO - 2024-08-01 14:42:12 --> Helper loaded: file_helper
INFO - 2024-08-01 14:42:12 --> Helper loaded: form_helper
INFO - 2024-08-01 14:42:12 --> Helper loaded: my_helper
INFO - 2024-08-01 14:42:12 --> Database Driver Class Initialized
INFO - 2024-08-01 14:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 14:42:12 --> Controller Class Initialized
DEBUG - 2024-08-01 14:42:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-01 14:42:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 14:42:12 --> Final output sent to browser
DEBUG - 2024-08-01 14:42:12 --> Total execution time: 0.0482
INFO - 2024-08-01 14:42:17 --> Config Class Initialized
INFO - 2024-08-01 14:42:17 --> Hooks Class Initialized
DEBUG - 2024-08-01 14:42:17 --> UTF-8 Support Enabled
INFO - 2024-08-01 14:42:17 --> Utf8 Class Initialized
INFO - 2024-08-01 14:42:17 --> URI Class Initialized
INFO - 2024-08-01 14:42:17 --> Router Class Initialized
INFO - 2024-08-01 14:42:17 --> Output Class Initialized
INFO - 2024-08-01 14:42:17 --> Security Class Initialized
DEBUG - 2024-08-01 14:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 14:42:17 --> Input Class Initialized
INFO - 2024-08-01 14:42:17 --> Language Class Initialized
INFO - 2024-08-01 14:42:17 --> Language Class Initialized
INFO - 2024-08-01 14:42:17 --> Config Class Initialized
INFO - 2024-08-01 14:42:17 --> Loader Class Initialized
INFO - 2024-08-01 14:42:17 --> Helper loaded: url_helper
INFO - 2024-08-01 14:42:17 --> Helper loaded: file_helper
INFO - 2024-08-01 14:42:17 --> Helper loaded: form_helper
INFO - 2024-08-01 14:42:17 --> Helper loaded: my_helper
INFO - 2024-08-01 14:42:17 --> Database Driver Class Initialized
INFO - 2024-08-01 14:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 14:42:17 --> Controller Class Initialized
ERROR - 2024-08-01 14:42:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1156
ERROR - 2024-08-01 14:42:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1688
ERROR - 2024-08-01 14:42:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1725
ERROR - 2024-08-01 14:42:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1763
ERROR - 2024-08-01 14:42:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1802
ERROR - 2024-08-01 14:42:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1879
ERROR - 2024-08-01 14:42:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1958
ERROR - 2024-08-01 14:42:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2038
ERROR - 2024-08-01 14:42:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2118
ERROR - 2024-08-01 14:42:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2198
ERROR - 2024-08-01 14:42:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2273
ERROR - 2024-08-01 14:42:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-08-01 14:42:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-01 14:42:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-01 14:42:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-08-01 14:42:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-08-01 14:42:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-08-01 14:42:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-08-01 14:42:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 14:42:20 --> Config Class Initialized
INFO - 2024-08-01 14:42:20 --> Hooks Class Initialized
DEBUG - 2024-08-01 14:42:20 --> UTF-8 Support Enabled
INFO - 2024-08-01 14:42:20 --> Utf8 Class Initialized
INFO - 2024-08-01 14:42:20 --> URI Class Initialized
INFO - 2024-08-01 14:42:20 --> Router Class Initialized
INFO - 2024-08-01 14:42:20 --> Output Class Initialized
INFO - 2024-08-01 14:42:20 --> Security Class Initialized
DEBUG - 2024-08-01 14:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 14:42:20 --> Input Class Initialized
INFO - 2024-08-01 14:42:20 --> Language Class Initialized
INFO - 2024-08-01 14:42:20 --> Language Class Initialized
INFO - 2024-08-01 14:42:20 --> Config Class Initialized
INFO - 2024-08-01 14:42:20 --> Loader Class Initialized
INFO - 2024-08-01 14:42:20 --> Helper loaded: url_helper
INFO - 2024-08-01 14:42:20 --> Helper loaded: file_helper
INFO - 2024-08-01 14:42:20 --> Helper loaded: form_helper
INFO - 2024-08-01 14:42:20 --> Helper loaded: my_helper
INFO - 2024-08-01 14:42:20 --> Database Driver Class Initialized
INFO - 2024-08-01 14:42:21 --> Final output sent to browser
DEBUG - 2024-08-01 14:42:21 --> Total execution time: 3.2732
INFO - 2024-08-01 14:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 14:42:21 --> Controller Class Initialized
ERROR - 2024-08-01 14:42:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1156
ERROR - 2024-08-01 14:42:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1688
ERROR - 2024-08-01 14:42:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1725
ERROR - 2024-08-01 14:42:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1763
ERROR - 2024-08-01 14:42:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1802
ERROR - 2024-08-01 14:42:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1879
ERROR - 2024-08-01 14:42:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1958
ERROR - 2024-08-01 14:42:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2038
ERROR - 2024-08-01 14:42:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2118
ERROR - 2024-08-01 14:42:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2198
ERROR - 2024-08-01 14:42:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2273
ERROR - 2024-08-01 14:42:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-08-01 14:42:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-01 14:42:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-01 14:42:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-08-01 14:42:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-08-01 14:42:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-08-01 14:42:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-08-01 14:42:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 14:42:24 --> Final output sent to browser
DEBUG - 2024-08-01 14:42:24 --> Total execution time: 4.4926
INFO - 2024-08-01 14:42:24 --> Config Class Initialized
INFO - 2024-08-01 14:42:24 --> Hooks Class Initialized
DEBUG - 2024-08-01 14:42:24 --> UTF-8 Support Enabled
INFO - 2024-08-01 14:42:24 --> Utf8 Class Initialized
INFO - 2024-08-01 14:42:24 --> URI Class Initialized
INFO - 2024-08-01 14:42:24 --> Router Class Initialized
INFO - 2024-08-01 14:42:24 --> Output Class Initialized
INFO - 2024-08-01 14:42:24 --> Security Class Initialized
DEBUG - 2024-08-01 14:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 14:42:24 --> Input Class Initialized
INFO - 2024-08-01 14:42:24 --> Language Class Initialized
INFO - 2024-08-01 14:42:24 --> Language Class Initialized
INFO - 2024-08-01 14:42:24 --> Config Class Initialized
INFO - 2024-08-01 14:42:24 --> Loader Class Initialized
INFO - 2024-08-01 14:42:24 --> Helper loaded: url_helper
INFO - 2024-08-01 14:42:24 --> Helper loaded: file_helper
INFO - 2024-08-01 14:42:24 --> Helper loaded: form_helper
INFO - 2024-08-01 14:42:24 --> Helper loaded: my_helper
INFO - 2024-08-01 14:42:24 --> Database Driver Class Initialized
INFO - 2024-08-01 14:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 14:42:24 --> Controller Class Initialized
ERROR - 2024-08-01 14:42:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1156
ERROR - 2024-08-01 14:42:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1688
ERROR - 2024-08-01 14:42:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1725
ERROR - 2024-08-01 14:42:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1763
ERROR - 2024-08-01 14:42:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1802
ERROR - 2024-08-01 14:42:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1879
ERROR - 2024-08-01 14:42:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1958
ERROR - 2024-08-01 14:42:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2038
ERROR - 2024-08-01 14:42:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2118
ERROR - 2024-08-01 14:42:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2198
ERROR - 2024-08-01 14:42:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2273
ERROR - 2024-08-01 14:42:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-08-01 14:42:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-01 14:42:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-01 14:42:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-08-01 14:42:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-08-01 14:42:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-08-01 14:42:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-08-01 14:42:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 14:42:28 --> Final output sent to browser
DEBUG - 2024-08-01 14:42:28 --> Total execution time: 3.2805
INFO - 2024-08-01 14:54:43 --> Config Class Initialized
INFO - 2024-08-01 14:54:43 --> Hooks Class Initialized
DEBUG - 2024-08-01 14:54:43 --> UTF-8 Support Enabled
INFO - 2024-08-01 14:54:43 --> Utf8 Class Initialized
INFO - 2024-08-01 14:54:43 --> URI Class Initialized
DEBUG - 2024-08-01 14:54:43 --> No URI present. Default controller set.
INFO - 2024-08-01 14:54:43 --> Router Class Initialized
INFO - 2024-08-01 14:54:43 --> Output Class Initialized
INFO - 2024-08-01 14:54:43 --> Security Class Initialized
DEBUG - 2024-08-01 14:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 14:54:43 --> Input Class Initialized
INFO - 2024-08-01 14:54:43 --> Language Class Initialized
INFO - 2024-08-01 14:54:43 --> Language Class Initialized
INFO - 2024-08-01 14:54:43 --> Config Class Initialized
INFO - 2024-08-01 14:54:43 --> Loader Class Initialized
INFO - 2024-08-01 14:54:43 --> Helper loaded: url_helper
INFO - 2024-08-01 14:54:43 --> Helper loaded: file_helper
INFO - 2024-08-01 14:54:43 --> Helper loaded: form_helper
INFO - 2024-08-01 14:54:43 --> Helper loaded: my_helper
INFO - 2024-08-01 14:54:43 --> Database Driver Class Initialized
INFO - 2024-08-01 14:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 14:54:43 --> Controller Class Initialized
INFO - 2024-08-01 14:54:43 --> Config Class Initialized
INFO - 2024-08-01 14:54:43 --> Hooks Class Initialized
DEBUG - 2024-08-01 14:54:43 --> UTF-8 Support Enabled
INFO - 2024-08-01 14:54:43 --> Utf8 Class Initialized
INFO - 2024-08-01 14:54:43 --> URI Class Initialized
INFO - 2024-08-01 14:54:43 --> Router Class Initialized
INFO - 2024-08-01 14:54:43 --> Output Class Initialized
INFO - 2024-08-01 14:54:43 --> Security Class Initialized
DEBUG - 2024-08-01 14:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 14:54:43 --> Input Class Initialized
INFO - 2024-08-01 14:54:43 --> Language Class Initialized
INFO - 2024-08-01 14:54:43 --> Language Class Initialized
INFO - 2024-08-01 14:54:43 --> Config Class Initialized
INFO - 2024-08-01 14:54:43 --> Loader Class Initialized
INFO - 2024-08-01 14:54:43 --> Helper loaded: url_helper
INFO - 2024-08-01 14:54:43 --> Helper loaded: file_helper
INFO - 2024-08-01 14:54:43 --> Helper loaded: form_helper
INFO - 2024-08-01 14:54:43 --> Helper loaded: my_helper
INFO - 2024-08-01 14:54:43 --> Database Driver Class Initialized
INFO - 2024-08-01 14:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 14:54:43 --> Controller Class Initialized
DEBUG - 2024-08-01 14:54:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-08-01 14:54:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 14:54:43 --> Final output sent to browser
DEBUG - 2024-08-01 14:54:43 --> Total execution time: 0.0363
INFO - 2024-08-01 14:54:51 --> Config Class Initialized
INFO - 2024-08-01 14:54:51 --> Hooks Class Initialized
DEBUG - 2024-08-01 14:54:51 --> UTF-8 Support Enabled
INFO - 2024-08-01 14:54:51 --> Utf8 Class Initialized
INFO - 2024-08-01 14:54:51 --> URI Class Initialized
INFO - 2024-08-01 14:54:51 --> Router Class Initialized
INFO - 2024-08-01 14:54:51 --> Output Class Initialized
INFO - 2024-08-01 14:54:51 --> Security Class Initialized
DEBUG - 2024-08-01 14:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 14:54:51 --> Input Class Initialized
INFO - 2024-08-01 14:54:51 --> Language Class Initialized
INFO - 2024-08-01 14:54:51 --> Language Class Initialized
INFO - 2024-08-01 14:54:51 --> Config Class Initialized
INFO - 2024-08-01 14:54:51 --> Loader Class Initialized
INFO - 2024-08-01 14:54:51 --> Helper loaded: url_helper
INFO - 2024-08-01 14:54:51 --> Helper loaded: file_helper
INFO - 2024-08-01 14:54:51 --> Helper loaded: form_helper
INFO - 2024-08-01 14:54:51 --> Helper loaded: my_helper
INFO - 2024-08-01 14:54:51 --> Database Driver Class Initialized
INFO - 2024-08-01 14:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 14:54:51 --> Controller Class Initialized
INFO - 2024-08-01 14:54:51 --> Helper loaded: cookie_helper
INFO - 2024-08-01 14:54:51 --> Final output sent to browser
DEBUG - 2024-08-01 14:54:51 --> Total execution time: 0.0407
INFO - 2024-08-01 14:54:51 --> Config Class Initialized
INFO - 2024-08-01 14:54:51 --> Hooks Class Initialized
DEBUG - 2024-08-01 14:54:51 --> UTF-8 Support Enabled
INFO - 2024-08-01 14:54:51 --> Utf8 Class Initialized
INFO - 2024-08-01 14:54:51 --> URI Class Initialized
INFO - 2024-08-01 14:54:51 --> Router Class Initialized
INFO - 2024-08-01 14:54:51 --> Output Class Initialized
INFO - 2024-08-01 14:54:51 --> Security Class Initialized
DEBUG - 2024-08-01 14:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 14:54:51 --> Input Class Initialized
INFO - 2024-08-01 14:54:51 --> Language Class Initialized
INFO - 2024-08-01 14:54:51 --> Language Class Initialized
INFO - 2024-08-01 14:54:51 --> Config Class Initialized
INFO - 2024-08-01 14:54:51 --> Loader Class Initialized
INFO - 2024-08-01 14:54:51 --> Helper loaded: url_helper
INFO - 2024-08-01 14:54:51 --> Helper loaded: file_helper
INFO - 2024-08-01 14:54:51 --> Helper loaded: form_helper
INFO - 2024-08-01 14:54:51 --> Helper loaded: my_helper
INFO - 2024-08-01 14:54:51 --> Database Driver Class Initialized
INFO - 2024-08-01 14:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 14:54:51 --> Controller Class Initialized
DEBUG - 2024-08-01 14:54:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-08-01 14:54:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 14:54:51 --> Final output sent to browser
DEBUG - 2024-08-01 14:54:51 --> Total execution time: 0.0462
INFO - 2024-08-01 14:54:53 --> Config Class Initialized
INFO - 2024-08-01 14:54:53 --> Hooks Class Initialized
DEBUG - 2024-08-01 14:54:53 --> UTF-8 Support Enabled
INFO - 2024-08-01 14:54:53 --> Utf8 Class Initialized
INFO - 2024-08-01 14:54:53 --> URI Class Initialized
INFO - 2024-08-01 14:54:53 --> Router Class Initialized
INFO - 2024-08-01 14:54:53 --> Output Class Initialized
INFO - 2024-08-01 14:54:53 --> Security Class Initialized
DEBUG - 2024-08-01 14:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 14:54:53 --> Input Class Initialized
INFO - 2024-08-01 14:54:53 --> Language Class Initialized
INFO - 2024-08-01 14:54:53 --> Language Class Initialized
INFO - 2024-08-01 14:54:53 --> Config Class Initialized
INFO - 2024-08-01 14:54:53 --> Loader Class Initialized
INFO - 2024-08-01 14:54:53 --> Helper loaded: url_helper
INFO - 2024-08-01 14:54:53 --> Helper loaded: file_helper
INFO - 2024-08-01 14:54:53 --> Helper loaded: form_helper
INFO - 2024-08-01 14:54:53 --> Helper loaded: my_helper
INFO - 2024-08-01 14:54:53 --> Database Driver Class Initialized
INFO - 2024-08-01 14:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 14:54:53 --> Controller Class Initialized
DEBUG - 2024-08-01 14:54:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2024-08-01 14:54:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 14:54:53 --> Final output sent to browser
DEBUG - 2024-08-01 14:54:53 --> Total execution time: 0.0283
INFO - 2024-08-01 14:54:53 --> Config Class Initialized
INFO - 2024-08-01 14:54:53 --> Hooks Class Initialized
DEBUG - 2024-08-01 14:54:53 --> UTF-8 Support Enabled
INFO - 2024-08-01 14:54:53 --> Utf8 Class Initialized
INFO - 2024-08-01 14:54:53 --> URI Class Initialized
INFO - 2024-08-01 14:54:53 --> Router Class Initialized
INFO - 2024-08-01 14:54:53 --> Output Class Initialized
INFO - 2024-08-01 14:54:53 --> Security Class Initialized
DEBUG - 2024-08-01 14:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 14:54:53 --> Input Class Initialized
INFO - 2024-08-01 14:54:53 --> Language Class Initialized
ERROR - 2024-08-01 14:54:53 --> 404 Page Not Found: /index
INFO - 2024-08-01 14:54:54 --> Config Class Initialized
INFO - 2024-08-01 14:54:54 --> Hooks Class Initialized
DEBUG - 2024-08-01 14:54:54 --> UTF-8 Support Enabled
INFO - 2024-08-01 14:54:54 --> Utf8 Class Initialized
INFO - 2024-08-01 14:54:54 --> URI Class Initialized
INFO - 2024-08-01 14:54:54 --> Router Class Initialized
INFO - 2024-08-01 14:54:54 --> Output Class Initialized
INFO - 2024-08-01 14:54:54 --> Security Class Initialized
DEBUG - 2024-08-01 14:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 14:54:54 --> Input Class Initialized
INFO - 2024-08-01 14:54:54 --> Language Class Initialized
INFO - 2024-08-01 14:54:54 --> Language Class Initialized
INFO - 2024-08-01 14:54:54 --> Config Class Initialized
INFO - 2024-08-01 14:54:54 --> Loader Class Initialized
INFO - 2024-08-01 14:54:54 --> Helper loaded: url_helper
INFO - 2024-08-01 14:54:54 --> Helper loaded: file_helper
INFO - 2024-08-01 14:54:54 --> Helper loaded: form_helper
INFO - 2024-08-01 14:54:54 --> Helper loaded: my_helper
INFO - 2024-08-01 14:54:54 --> Database Driver Class Initialized
INFO - 2024-08-01 14:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 14:54:54 --> Controller Class Initialized
INFO - 2024-08-01 14:54:56 --> Config Class Initialized
INFO - 2024-08-01 14:54:56 --> Hooks Class Initialized
DEBUG - 2024-08-01 14:54:56 --> UTF-8 Support Enabled
INFO - 2024-08-01 14:54:56 --> Utf8 Class Initialized
INFO - 2024-08-01 14:54:56 --> URI Class Initialized
INFO - 2024-08-01 14:54:56 --> Router Class Initialized
INFO - 2024-08-01 14:54:56 --> Output Class Initialized
INFO - 2024-08-01 14:54:56 --> Security Class Initialized
DEBUG - 2024-08-01 14:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 14:54:56 --> Input Class Initialized
INFO - 2024-08-01 14:54:56 --> Language Class Initialized
INFO - 2024-08-01 14:54:56 --> Language Class Initialized
INFO - 2024-08-01 14:54:56 --> Config Class Initialized
INFO - 2024-08-01 14:54:56 --> Loader Class Initialized
INFO - 2024-08-01 14:54:56 --> Helper loaded: url_helper
INFO - 2024-08-01 14:54:56 --> Helper loaded: file_helper
INFO - 2024-08-01 14:54:56 --> Helper loaded: form_helper
INFO - 2024-08-01 14:54:56 --> Helper loaded: my_helper
INFO - 2024-08-01 14:54:56 --> Database Driver Class Initialized
INFO - 2024-08-01 14:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 14:54:56 --> Controller Class Initialized
DEBUG - 2024-08-01 14:54:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-08-01 14:54:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 14:54:56 --> Final output sent to browser
DEBUG - 2024-08-01 14:54:56 --> Total execution time: 0.0302
INFO - 2024-08-01 14:54:56 --> Config Class Initialized
INFO - 2024-08-01 14:54:56 --> Hooks Class Initialized
DEBUG - 2024-08-01 14:54:56 --> UTF-8 Support Enabled
INFO - 2024-08-01 14:54:56 --> Utf8 Class Initialized
INFO - 2024-08-01 14:54:56 --> URI Class Initialized
INFO - 2024-08-01 14:54:56 --> Router Class Initialized
INFO - 2024-08-01 14:54:56 --> Output Class Initialized
INFO - 2024-08-01 14:54:56 --> Security Class Initialized
DEBUG - 2024-08-01 14:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 14:54:56 --> Input Class Initialized
INFO - 2024-08-01 14:54:56 --> Language Class Initialized
ERROR - 2024-08-01 14:54:56 --> 404 Page Not Found: /index
INFO - 2024-08-01 14:54:56 --> Config Class Initialized
INFO - 2024-08-01 14:54:56 --> Hooks Class Initialized
DEBUG - 2024-08-01 14:54:56 --> UTF-8 Support Enabled
INFO - 2024-08-01 14:54:56 --> Utf8 Class Initialized
INFO - 2024-08-01 14:54:56 --> URI Class Initialized
INFO - 2024-08-01 14:54:56 --> Router Class Initialized
INFO - 2024-08-01 14:54:56 --> Output Class Initialized
INFO - 2024-08-01 14:54:56 --> Security Class Initialized
DEBUG - 2024-08-01 14:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 14:54:56 --> Input Class Initialized
INFO - 2024-08-01 14:54:56 --> Language Class Initialized
INFO - 2024-08-01 14:54:56 --> Language Class Initialized
INFO - 2024-08-01 14:54:56 --> Config Class Initialized
INFO - 2024-08-01 14:54:56 --> Loader Class Initialized
INFO - 2024-08-01 14:54:56 --> Helper loaded: url_helper
INFO - 2024-08-01 14:54:56 --> Helper loaded: file_helper
INFO - 2024-08-01 14:54:56 --> Helper loaded: form_helper
INFO - 2024-08-01 14:54:56 --> Helper loaded: my_helper
INFO - 2024-08-01 14:54:56 --> Database Driver Class Initialized
INFO - 2024-08-01 14:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 14:54:56 --> Controller Class Initialized
INFO - 2024-08-01 14:55:11 --> Config Class Initialized
INFO - 2024-08-01 14:55:11 --> Hooks Class Initialized
DEBUG - 2024-08-01 14:55:11 --> UTF-8 Support Enabled
INFO - 2024-08-01 14:55:11 --> Utf8 Class Initialized
INFO - 2024-08-01 14:55:11 --> URI Class Initialized
DEBUG - 2024-08-01 14:55:11 --> No URI present. Default controller set.
INFO - 2024-08-01 14:55:11 --> Router Class Initialized
INFO - 2024-08-01 14:55:11 --> Output Class Initialized
INFO - 2024-08-01 14:55:11 --> Security Class Initialized
DEBUG - 2024-08-01 14:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 14:55:11 --> Input Class Initialized
INFO - 2024-08-01 14:55:11 --> Language Class Initialized
INFO - 2024-08-01 14:55:11 --> Language Class Initialized
INFO - 2024-08-01 14:55:11 --> Config Class Initialized
INFO - 2024-08-01 14:55:11 --> Loader Class Initialized
INFO - 2024-08-01 14:55:11 --> Helper loaded: url_helper
INFO - 2024-08-01 14:55:11 --> Helper loaded: file_helper
INFO - 2024-08-01 14:55:11 --> Helper loaded: form_helper
INFO - 2024-08-01 14:55:11 --> Helper loaded: my_helper
INFO - 2024-08-01 14:55:11 --> Database Driver Class Initialized
INFO - 2024-08-01 14:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 14:55:11 --> Controller Class Initialized
INFO - 2024-08-01 14:55:11 --> Config Class Initialized
INFO - 2024-08-01 14:55:11 --> Hooks Class Initialized
DEBUG - 2024-08-01 14:55:11 --> UTF-8 Support Enabled
INFO - 2024-08-01 14:55:11 --> Utf8 Class Initialized
INFO - 2024-08-01 14:55:11 --> URI Class Initialized
INFO - 2024-08-01 14:55:11 --> Router Class Initialized
INFO - 2024-08-01 14:55:11 --> Output Class Initialized
INFO - 2024-08-01 14:55:11 --> Security Class Initialized
DEBUG - 2024-08-01 14:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 14:55:11 --> Input Class Initialized
INFO - 2024-08-01 14:55:11 --> Language Class Initialized
INFO - 2024-08-01 14:55:11 --> Language Class Initialized
INFO - 2024-08-01 14:55:11 --> Config Class Initialized
INFO - 2024-08-01 14:55:11 --> Loader Class Initialized
INFO - 2024-08-01 14:55:11 --> Helper loaded: url_helper
INFO - 2024-08-01 14:55:11 --> Helper loaded: file_helper
INFO - 2024-08-01 14:55:11 --> Helper loaded: form_helper
INFO - 2024-08-01 14:55:11 --> Helper loaded: my_helper
INFO - 2024-08-01 14:55:11 --> Database Driver Class Initialized
INFO - 2024-08-01 14:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 14:55:11 --> Controller Class Initialized
DEBUG - 2024-08-01 14:55:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-08-01 14:55:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 14:55:11 --> Final output sent to browser
DEBUG - 2024-08-01 14:55:11 --> Total execution time: 0.0504
INFO - 2024-08-01 14:55:16 --> Config Class Initialized
INFO - 2024-08-01 14:55:16 --> Hooks Class Initialized
DEBUG - 2024-08-01 14:55:16 --> UTF-8 Support Enabled
INFO - 2024-08-01 14:55:16 --> Utf8 Class Initialized
INFO - 2024-08-01 14:55:16 --> URI Class Initialized
INFO - 2024-08-01 14:55:16 --> Router Class Initialized
INFO - 2024-08-01 14:55:16 --> Output Class Initialized
INFO - 2024-08-01 14:55:16 --> Security Class Initialized
DEBUG - 2024-08-01 14:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 14:55:16 --> Input Class Initialized
INFO - 2024-08-01 14:55:16 --> Language Class Initialized
INFO - 2024-08-01 14:55:16 --> Language Class Initialized
INFO - 2024-08-01 14:55:16 --> Config Class Initialized
INFO - 2024-08-01 14:55:16 --> Loader Class Initialized
INFO - 2024-08-01 14:55:16 --> Helper loaded: url_helper
INFO - 2024-08-01 14:55:16 --> Helper loaded: file_helper
INFO - 2024-08-01 14:55:16 --> Helper loaded: form_helper
INFO - 2024-08-01 14:55:16 --> Helper loaded: my_helper
INFO - 2024-08-01 14:55:16 --> Database Driver Class Initialized
INFO - 2024-08-01 14:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 14:55:16 --> Controller Class Initialized
INFO - 2024-08-01 14:55:16 --> Helper loaded: cookie_helper
INFO - 2024-08-01 14:55:16 --> Final output sent to browser
DEBUG - 2024-08-01 14:55:16 --> Total execution time: 0.0386
INFO - 2024-08-01 14:55:16 --> Config Class Initialized
INFO - 2024-08-01 14:55:16 --> Hooks Class Initialized
DEBUG - 2024-08-01 14:55:16 --> UTF-8 Support Enabled
INFO - 2024-08-01 14:55:16 --> Utf8 Class Initialized
INFO - 2024-08-01 14:55:16 --> URI Class Initialized
INFO - 2024-08-01 14:55:16 --> Router Class Initialized
INFO - 2024-08-01 14:55:16 --> Output Class Initialized
INFO - 2024-08-01 14:55:16 --> Security Class Initialized
DEBUG - 2024-08-01 14:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 14:55:16 --> Input Class Initialized
INFO - 2024-08-01 14:55:16 --> Language Class Initialized
INFO - 2024-08-01 14:55:16 --> Language Class Initialized
INFO - 2024-08-01 14:55:16 --> Config Class Initialized
INFO - 2024-08-01 14:55:16 --> Loader Class Initialized
INFO - 2024-08-01 14:55:16 --> Helper loaded: url_helper
INFO - 2024-08-01 14:55:16 --> Helper loaded: file_helper
INFO - 2024-08-01 14:55:16 --> Helper loaded: form_helper
INFO - 2024-08-01 14:55:16 --> Helper loaded: my_helper
INFO - 2024-08-01 14:55:16 --> Database Driver Class Initialized
INFO - 2024-08-01 14:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 14:55:16 --> Controller Class Initialized
DEBUG - 2024-08-01 14:55:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-08-01 14:55:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 14:55:16 --> Final output sent to browser
DEBUG - 2024-08-01 14:55:16 --> Total execution time: 0.0295
INFO - 2024-08-01 14:55:18 --> Config Class Initialized
INFO - 2024-08-01 14:55:18 --> Hooks Class Initialized
DEBUG - 2024-08-01 14:55:18 --> UTF-8 Support Enabled
INFO - 2024-08-01 14:55:18 --> Utf8 Class Initialized
INFO - 2024-08-01 14:55:18 --> URI Class Initialized
INFO - 2024-08-01 14:55:18 --> Router Class Initialized
INFO - 2024-08-01 14:55:18 --> Output Class Initialized
INFO - 2024-08-01 14:55:18 --> Security Class Initialized
DEBUG - 2024-08-01 14:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 14:55:18 --> Input Class Initialized
INFO - 2024-08-01 14:55:18 --> Language Class Initialized
INFO - 2024-08-01 14:55:18 --> Language Class Initialized
INFO - 2024-08-01 14:55:18 --> Config Class Initialized
INFO - 2024-08-01 14:55:18 --> Loader Class Initialized
INFO - 2024-08-01 14:55:18 --> Helper loaded: url_helper
INFO - 2024-08-01 14:55:18 --> Helper loaded: file_helper
INFO - 2024-08-01 14:55:18 --> Helper loaded: form_helper
INFO - 2024-08-01 14:55:18 --> Helper loaded: my_helper
INFO - 2024-08-01 14:55:18 --> Database Driver Class Initialized
INFO - 2024-08-01 14:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 14:55:18 --> Controller Class Initialized
DEBUG - 2024-08-01 14:55:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-01 14:55:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 14:55:18 --> Final output sent to browser
DEBUG - 2024-08-01 14:55:18 --> Total execution time: 0.0752
INFO - 2024-08-01 14:57:03 --> Config Class Initialized
INFO - 2024-08-01 14:57:03 --> Hooks Class Initialized
DEBUG - 2024-08-01 14:57:03 --> UTF-8 Support Enabled
INFO - 2024-08-01 14:57:03 --> Utf8 Class Initialized
INFO - 2024-08-01 14:57:03 --> URI Class Initialized
INFO - 2024-08-01 14:57:03 --> Router Class Initialized
INFO - 2024-08-01 14:57:03 --> Output Class Initialized
INFO - 2024-08-01 14:57:03 --> Security Class Initialized
DEBUG - 2024-08-01 14:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 14:57:03 --> Input Class Initialized
INFO - 2024-08-01 14:57:03 --> Language Class Initialized
INFO - 2024-08-01 14:57:03 --> Language Class Initialized
INFO - 2024-08-01 14:57:03 --> Config Class Initialized
INFO - 2024-08-01 14:57:03 --> Loader Class Initialized
INFO - 2024-08-01 14:57:03 --> Helper loaded: url_helper
INFO - 2024-08-01 14:57:03 --> Helper loaded: file_helper
INFO - 2024-08-01 14:57:03 --> Helper loaded: form_helper
INFO - 2024-08-01 14:57:03 --> Helper loaded: my_helper
INFO - 2024-08-01 14:57:03 --> Database Driver Class Initialized
INFO - 2024-08-01 14:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 14:57:03 --> Controller Class Initialized
DEBUG - 2024-08-01 14:57:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-01 14:57:05 --> Config Class Initialized
INFO - 2024-08-01 14:57:05 --> Hooks Class Initialized
DEBUG - 2024-08-01 14:57:05 --> UTF-8 Support Enabled
INFO - 2024-08-01 14:57:05 --> Utf8 Class Initialized
INFO - 2024-08-01 14:57:05 --> URI Class Initialized
INFO - 2024-08-01 14:57:05 --> Router Class Initialized
INFO - 2024-08-01 14:57:05 --> Output Class Initialized
INFO - 2024-08-01 14:57:05 --> Security Class Initialized
DEBUG - 2024-08-01 14:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 14:57:05 --> Input Class Initialized
INFO - 2024-08-01 14:57:05 --> Language Class Initialized
INFO - 2024-08-01 14:57:06 --> Language Class Initialized
INFO - 2024-08-01 14:57:06 --> Config Class Initialized
INFO - 2024-08-01 14:57:06 --> Loader Class Initialized
INFO - 2024-08-01 14:57:06 --> Helper loaded: url_helper
INFO - 2024-08-01 14:57:06 --> Helper loaded: file_helper
INFO - 2024-08-01 14:57:06 --> Helper loaded: form_helper
INFO - 2024-08-01 14:57:06 --> Helper loaded: my_helper
INFO - 2024-08-01 14:57:06 --> Database Driver Class Initialized
INFO - 2024-08-01 14:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 14:57:06 --> Controller Class Initialized
DEBUG - 2024-08-01 14:57:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-08-01 14:57:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 14:57:06 --> Final output sent to browser
DEBUG - 2024-08-01 14:57:06 --> Total execution time: 0.0635
INFO - 2024-08-01 14:57:06 --> Config Class Initialized
INFO - 2024-08-01 14:57:06 --> Hooks Class Initialized
DEBUG - 2024-08-01 14:57:06 --> UTF-8 Support Enabled
INFO - 2024-08-01 14:57:06 --> Utf8 Class Initialized
INFO - 2024-08-01 14:57:06 --> URI Class Initialized
INFO - 2024-08-01 14:57:06 --> Router Class Initialized
INFO - 2024-08-01 14:57:06 --> Output Class Initialized
INFO - 2024-08-01 14:57:06 --> Security Class Initialized
DEBUG - 2024-08-01 14:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 14:57:06 --> Input Class Initialized
INFO - 2024-08-01 14:57:06 --> Language Class Initialized
ERROR - 2024-08-01 14:57:06 --> 404 Page Not Found: /index
INFO - 2024-08-01 14:57:06 --> Config Class Initialized
INFO - 2024-08-01 14:57:06 --> Hooks Class Initialized
DEBUG - 2024-08-01 14:57:06 --> UTF-8 Support Enabled
INFO - 2024-08-01 14:57:06 --> Utf8 Class Initialized
INFO - 2024-08-01 14:57:06 --> URI Class Initialized
INFO - 2024-08-01 14:57:06 --> Router Class Initialized
INFO - 2024-08-01 14:57:06 --> Output Class Initialized
INFO - 2024-08-01 14:57:06 --> Security Class Initialized
DEBUG - 2024-08-01 14:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 14:57:06 --> Input Class Initialized
INFO - 2024-08-01 14:57:06 --> Language Class Initialized
INFO - 2024-08-01 14:57:06 --> Language Class Initialized
INFO - 2024-08-01 14:57:06 --> Config Class Initialized
INFO - 2024-08-01 14:57:06 --> Loader Class Initialized
INFO - 2024-08-01 14:57:06 --> Helper loaded: url_helper
INFO - 2024-08-01 14:57:06 --> Helper loaded: file_helper
INFO - 2024-08-01 14:57:06 --> Helper loaded: form_helper
INFO - 2024-08-01 14:57:06 --> Helper loaded: my_helper
INFO - 2024-08-01 14:57:06 --> Database Driver Class Initialized
INFO - 2024-08-01 14:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 14:57:06 --> Controller Class Initialized
INFO - 2024-08-01 14:57:07 --> Final output sent to browser
DEBUG - 2024-08-01 14:57:07 --> Total execution time: 4.3915
INFO - 2024-08-01 15:00:33 --> Config Class Initialized
INFO - 2024-08-01 15:00:33 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:00:33 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:00:33 --> Utf8 Class Initialized
INFO - 2024-08-01 15:00:33 --> URI Class Initialized
INFO - 2024-08-01 15:00:33 --> Router Class Initialized
INFO - 2024-08-01 15:00:33 --> Output Class Initialized
INFO - 2024-08-01 15:00:33 --> Security Class Initialized
DEBUG - 2024-08-01 15:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:00:33 --> Input Class Initialized
INFO - 2024-08-01 15:00:33 --> Language Class Initialized
INFO - 2024-08-01 15:00:33 --> Language Class Initialized
INFO - 2024-08-01 15:00:33 --> Config Class Initialized
INFO - 2024-08-01 15:00:33 --> Loader Class Initialized
INFO - 2024-08-01 15:00:33 --> Helper loaded: url_helper
INFO - 2024-08-01 15:00:33 --> Helper loaded: file_helper
INFO - 2024-08-01 15:00:33 --> Helper loaded: form_helper
INFO - 2024-08-01 15:00:33 --> Helper loaded: my_helper
INFO - 2024-08-01 15:00:33 --> Database Driver Class Initialized
INFO - 2024-08-01 15:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:00:33 --> Controller Class Initialized
DEBUG - 2024-08-01 15:00:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-01 15:00:37 --> Final output sent to browser
DEBUG - 2024-08-01 15:00:37 --> Total execution time: 3.7519
INFO - 2024-08-01 15:01:19 --> Config Class Initialized
INFO - 2024-08-01 15:01:19 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:01:19 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:01:19 --> Utf8 Class Initialized
INFO - 2024-08-01 15:01:19 --> URI Class Initialized
INFO - 2024-08-01 15:01:19 --> Router Class Initialized
INFO - 2024-08-01 15:01:19 --> Output Class Initialized
INFO - 2024-08-01 15:01:19 --> Security Class Initialized
DEBUG - 2024-08-01 15:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:01:19 --> Input Class Initialized
INFO - 2024-08-01 15:01:19 --> Language Class Initialized
INFO - 2024-08-01 15:01:19 --> Language Class Initialized
INFO - 2024-08-01 15:01:19 --> Config Class Initialized
INFO - 2024-08-01 15:01:19 --> Loader Class Initialized
INFO - 2024-08-01 15:01:19 --> Helper loaded: url_helper
INFO - 2024-08-01 15:01:19 --> Helper loaded: file_helper
INFO - 2024-08-01 15:01:19 --> Helper loaded: form_helper
INFO - 2024-08-01 15:01:19 --> Helper loaded: my_helper
INFO - 2024-08-01 15:01:19 --> Database Driver Class Initialized
INFO - 2024-08-01 15:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:01:19 --> Controller Class Initialized
DEBUG - 2024-08-01 15:01:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-01 15:01:23 --> Final output sent to browser
DEBUG - 2024-08-01 15:01:23 --> Total execution time: 3.9610
INFO - 2024-08-01 15:01:35 --> Config Class Initialized
INFO - 2024-08-01 15:01:35 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:01:35 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:01:35 --> Utf8 Class Initialized
INFO - 2024-08-01 15:01:35 --> URI Class Initialized
INFO - 2024-08-01 15:01:35 --> Router Class Initialized
INFO - 2024-08-01 15:01:35 --> Output Class Initialized
INFO - 2024-08-01 15:01:35 --> Security Class Initialized
DEBUG - 2024-08-01 15:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:01:35 --> Input Class Initialized
INFO - 2024-08-01 15:01:35 --> Language Class Initialized
INFO - 2024-08-01 15:01:35 --> Language Class Initialized
INFO - 2024-08-01 15:01:35 --> Config Class Initialized
INFO - 2024-08-01 15:01:35 --> Loader Class Initialized
INFO - 2024-08-01 15:01:35 --> Helper loaded: url_helper
INFO - 2024-08-01 15:01:35 --> Helper loaded: file_helper
INFO - 2024-08-01 15:01:35 --> Helper loaded: form_helper
INFO - 2024-08-01 15:01:35 --> Helper loaded: my_helper
INFO - 2024-08-01 15:01:35 --> Database Driver Class Initialized
INFO - 2024-08-01 15:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:01:35 --> Controller Class Initialized
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-08-01 15:01:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-08-01 15:01:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
ERROR - 2024-08-01 15:01:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2031
INFO - 2024-08-01 15:01:40 --> Final output sent to browser
DEBUG - 2024-08-01 15:01:40 --> Total execution time: 5.3086
INFO - 2024-08-01 15:03:46 --> Config Class Initialized
INFO - 2024-08-01 15:03:46 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:03:46 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:03:46 --> Utf8 Class Initialized
INFO - 2024-08-01 15:03:46 --> URI Class Initialized
INFO - 2024-08-01 15:03:46 --> Router Class Initialized
INFO - 2024-08-01 15:03:46 --> Output Class Initialized
INFO - 2024-08-01 15:03:46 --> Security Class Initialized
DEBUG - 2024-08-01 15:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:03:46 --> Input Class Initialized
INFO - 2024-08-01 15:03:46 --> Language Class Initialized
INFO - 2024-08-01 15:03:46 --> Language Class Initialized
INFO - 2024-08-01 15:03:46 --> Config Class Initialized
INFO - 2024-08-01 15:03:46 --> Loader Class Initialized
INFO - 2024-08-01 15:03:46 --> Helper loaded: url_helper
INFO - 2024-08-01 15:03:46 --> Helper loaded: file_helper
INFO - 2024-08-01 15:03:46 --> Helper loaded: form_helper
INFO - 2024-08-01 15:03:46 --> Helper loaded: my_helper
INFO - 2024-08-01 15:03:46 --> Database Driver Class Initialized
INFO - 2024-08-01 15:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:03:46 --> Controller Class Initialized
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1838
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
ERROR - 2024-08-01 15:03:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1856
DEBUG - 2024-08-01 15:03:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-08-01 15:03:51 --> Final output sent to browser
DEBUG - 2024-08-01 15:03:51 --> Total execution time: 5.5275
INFO - 2024-08-01 15:04:06 --> Config Class Initialized
INFO - 2024-08-01 15:04:06 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:04:06 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:04:06 --> Utf8 Class Initialized
INFO - 2024-08-01 15:04:06 --> URI Class Initialized
INFO - 2024-08-01 15:04:06 --> Router Class Initialized
INFO - 2024-08-01 15:04:06 --> Output Class Initialized
INFO - 2024-08-01 15:04:06 --> Security Class Initialized
DEBUG - 2024-08-01 15:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:04:06 --> Input Class Initialized
INFO - 2024-08-01 15:04:06 --> Language Class Initialized
INFO - 2024-08-01 15:04:06 --> Language Class Initialized
INFO - 2024-08-01 15:04:06 --> Config Class Initialized
INFO - 2024-08-01 15:04:06 --> Loader Class Initialized
INFO - 2024-08-01 15:04:06 --> Helper loaded: url_helper
INFO - 2024-08-01 15:04:06 --> Helper loaded: file_helper
INFO - 2024-08-01 15:04:06 --> Helper loaded: form_helper
INFO - 2024-08-01 15:04:06 --> Helper loaded: my_helper
INFO - 2024-08-01 15:04:06 --> Database Driver Class Initialized
INFO - 2024-08-01 15:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:04:06 --> Controller Class Initialized
ERROR - 2024-08-01 15:04:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 48
ERROR - 2024-08-01 15:04:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 143
ERROR - 2024-08-01 15:04:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 150
DEBUG - 2024-08-01 15:04:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
ERROR - 2024-08-01 15:04:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3877
ERROR - 2024-08-01 15:04:11 --> Severity: error --> Exception: TCPDF ERROR: Some data has already been output, can't send PDF file /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/tecnickcom/tcpdf/tcpdf.php 2950
INFO - 2024-08-01 15:04:51 --> Config Class Initialized
INFO - 2024-08-01 15:04:51 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:04:51 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:04:51 --> Utf8 Class Initialized
INFO - 2024-08-01 15:04:51 --> URI Class Initialized
INFO - 2024-08-01 15:04:51 --> Router Class Initialized
INFO - 2024-08-01 15:04:51 --> Output Class Initialized
INFO - 2024-08-01 15:04:51 --> Security Class Initialized
DEBUG - 2024-08-01 15:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:04:51 --> Input Class Initialized
INFO - 2024-08-01 15:04:51 --> Language Class Initialized
INFO - 2024-08-01 15:04:51 --> Language Class Initialized
INFO - 2024-08-01 15:04:51 --> Config Class Initialized
INFO - 2024-08-01 15:04:51 --> Loader Class Initialized
INFO - 2024-08-01 15:04:51 --> Helper loaded: url_helper
INFO - 2024-08-01 15:04:51 --> Helper loaded: file_helper
INFO - 2024-08-01 15:04:51 --> Helper loaded: form_helper
INFO - 2024-08-01 15:04:51 --> Helper loaded: my_helper
INFO - 2024-08-01 15:04:51 --> Database Driver Class Initialized
INFO - 2024-08-01 15:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:04:51 --> Controller Class Initialized
DEBUG - 2024-08-01 15:04:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-01 15:04:55 --> Final output sent to browser
DEBUG - 2024-08-01 15:04:55 --> Total execution time: 4.3457
INFO - 2024-08-01 15:05:27 --> Config Class Initialized
INFO - 2024-08-01 15:05:27 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:05:27 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:05:27 --> Utf8 Class Initialized
INFO - 2024-08-01 15:05:27 --> URI Class Initialized
INFO - 2024-08-01 15:05:27 --> Router Class Initialized
INFO - 2024-08-01 15:05:27 --> Output Class Initialized
INFO - 2024-08-01 15:05:27 --> Security Class Initialized
DEBUG - 2024-08-01 15:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:05:27 --> Input Class Initialized
INFO - 2024-08-01 15:05:27 --> Language Class Initialized
INFO - 2024-08-01 15:05:27 --> Language Class Initialized
INFO - 2024-08-01 15:05:27 --> Config Class Initialized
INFO - 2024-08-01 15:05:27 --> Loader Class Initialized
INFO - 2024-08-01 15:05:27 --> Helper loaded: url_helper
INFO - 2024-08-01 15:05:27 --> Helper loaded: file_helper
INFO - 2024-08-01 15:05:27 --> Helper loaded: form_helper
INFO - 2024-08-01 15:05:27 --> Helper loaded: my_helper
INFO - 2024-08-01 15:05:27 --> Database Driver Class Initialized
INFO - 2024-08-01 15:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:05:27 --> Controller Class Initialized
ERROR - 2024-08-01 15:05:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php 64
ERROR - 2024-08-01 15:05:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php 307
ERROR - 2024-08-01 15:05:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php 317
DEBUG - 2024-08-01 15:05:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
ERROR - 2024-08-01 15:05:28 --> Severity: error --> Exception: The content of the TD tag does not fit on only one page /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/spipu/html2pdf/src/Html2Pdf.php 5680
ERROR - 2024-08-01 15:05:28 --> Severity: Warning --> unlink(/tmp/__tcpdf_efcbcb0d02b9c73fdb78c2b7a546b235_imgmask_alpha_5c8c5820de2d21abc04c055a7edbdf01): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/tecnickcom/tcpdf/tcpdf.php 7801
ERROR - 2024-08-01 15:05:28 --> Severity: Warning --> unlink(/tmp/__tcpdf_efcbcb0d02b9c73fdb78c2b7a546b235_imgmask_plain_5c8c5820de2d21abc04c055a7edbdf01): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/tecnickcom/tcpdf/tcpdf.php 7801
INFO - 2024-08-01 15:06:16 --> Config Class Initialized
INFO - 2024-08-01 15:06:16 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:06:16 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:06:16 --> Utf8 Class Initialized
INFO - 2024-08-01 15:06:16 --> URI Class Initialized
INFO - 2024-08-01 15:06:16 --> Router Class Initialized
INFO - 2024-08-01 15:06:16 --> Output Class Initialized
INFO - 2024-08-01 15:06:16 --> Security Class Initialized
DEBUG - 2024-08-01 15:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:06:16 --> Input Class Initialized
INFO - 2024-08-01 15:06:16 --> Language Class Initialized
INFO - 2024-08-01 15:06:16 --> Language Class Initialized
INFO - 2024-08-01 15:06:16 --> Config Class Initialized
INFO - 2024-08-01 15:06:16 --> Loader Class Initialized
INFO - 2024-08-01 15:06:16 --> Helper loaded: url_helper
INFO - 2024-08-01 15:06:16 --> Helper loaded: file_helper
INFO - 2024-08-01 15:06:16 --> Helper loaded: form_helper
INFO - 2024-08-01 15:06:16 --> Helper loaded: my_helper
INFO - 2024-08-01 15:06:16 --> Database Driver Class Initialized
INFO - 2024-08-01 15:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:06:16 --> Controller Class Initialized
DEBUG - 2024-08-01 15:06:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-08-01 15:06:18 --> Final output sent to browser
DEBUG - 2024-08-01 15:06:18 --> Total execution time: 2.0421
INFO - 2024-08-01 15:07:00 --> Config Class Initialized
INFO - 2024-08-01 15:07:00 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:07:00 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:07:00 --> Utf8 Class Initialized
INFO - 2024-08-01 15:07:00 --> URI Class Initialized
INFO - 2024-08-01 15:07:00 --> Router Class Initialized
INFO - 2024-08-01 15:07:00 --> Output Class Initialized
INFO - 2024-08-01 15:07:00 --> Security Class Initialized
DEBUG - 2024-08-01 15:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:07:00 --> Input Class Initialized
INFO - 2024-08-01 15:07:00 --> Language Class Initialized
INFO - 2024-08-01 15:07:00 --> Language Class Initialized
INFO - 2024-08-01 15:07:00 --> Config Class Initialized
INFO - 2024-08-01 15:07:00 --> Loader Class Initialized
INFO - 2024-08-01 15:07:00 --> Helper loaded: url_helper
INFO - 2024-08-01 15:07:00 --> Helper loaded: file_helper
INFO - 2024-08-01 15:07:00 --> Helper loaded: form_helper
INFO - 2024-08-01 15:07:00 --> Helper loaded: my_helper
INFO - 2024-08-01 15:07:00 --> Database Driver Class Initialized
INFO - 2024-08-01 15:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:07:00 --> Controller Class Initialized
ERROR - 2024-08-01 15:07:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-08-01 15:07:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-08-01 15:07:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-08-01 15:07:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 15:07:03 --> Final output sent to browser
DEBUG - 2024-08-01 15:07:03 --> Total execution time: 3.4774
INFO - 2024-08-01 15:08:01 --> Config Class Initialized
INFO - 2024-08-01 15:08:01 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:08:01 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:08:01 --> Utf8 Class Initialized
INFO - 2024-08-01 15:08:01 --> URI Class Initialized
INFO - 2024-08-01 15:08:01 --> Router Class Initialized
INFO - 2024-08-01 15:08:01 --> Output Class Initialized
INFO - 2024-08-01 15:08:01 --> Security Class Initialized
DEBUG - 2024-08-01 15:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:08:01 --> Input Class Initialized
INFO - 2024-08-01 15:08:01 --> Language Class Initialized
INFO - 2024-08-01 15:08:01 --> Language Class Initialized
INFO - 2024-08-01 15:08:01 --> Config Class Initialized
INFO - 2024-08-01 15:08:01 --> Loader Class Initialized
INFO - 2024-08-01 15:08:01 --> Helper loaded: url_helper
INFO - 2024-08-01 15:08:01 --> Helper loaded: file_helper
INFO - 2024-08-01 15:08:01 --> Helper loaded: form_helper
INFO - 2024-08-01 15:08:01 --> Helper loaded: my_helper
INFO - 2024-08-01 15:08:01 --> Database Driver Class Initialized
INFO - 2024-08-01 15:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:08:01 --> Controller Class Initialized
DEBUG - 2024-08-01 15:08:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 15:08:04 --> Final output sent to browser
DEBUG - 2024-08-01 15:08:04 --> Total execution time: 3.5213
INFO - 2024-08-01 15:08:20 --> Config Class Initialized
INFO - 2024-08-01 15:08:20 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:08:20 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:08:20 --> Utf8 Class Initialized
INFO - 2024-08-01 15:08:20 --> URI Class Initialized
INFO - 2024-08-01 15:08:20 --> Router Class Initialized
INFO - 2024-08-01 15:08:20 --> Output Class Initialized
INFO - 2024-08-01 15:08:20 --> Security Class Initialized
DEBUG - 2024-08-01 15:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:08:20 --> Input Class Initialized
INFO - 2024-08-01 15:08:20 --> Language Class Initialized
INFO - 2024-08-01 15:08:20 --> Language Class Initialized
INFO - 2024-08-01 15:08:20 --> Config Class Initialized
INFO - 2024-08-01 15:08:20 --> Loader Class Initialized
INFO - 2024-08-01 15:08:20 --> Helper loaded: url_helper
INFO - 2024-08-01 15:08:20 --> Helper loaded: file_helper
INFO - 2024-08-01 15:08:20 --> Helper loaded: form_helper
INFO - 2024-08-01 15:08:20 --> Helper loaded: my_helper
INFO - 2024-08-01 15:08:20 --> Database Driver Class Initialized
INFO - 2024-08-01 15:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:08:20 --> Controller Class Initialized
DEBUG - 2024-08-01 15:08:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-01 15:08:24 --> Config Class Initialized
INFO - 2024-08-01 15:08:24 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:08:24 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:08:24 --> Utf8 Class Initialized
INFO - 2024-08-01 15:08:24 --> URI Class Initialized
INFO - 2024-08-01 15:08:24 --> Router Class Initialized
INFO - 2024-08-01 15:08:24 --> Output Class Initialized
INFO - 2024-08-01 15:08:24 --> Security Class Initialized
DEBUG - 2024-08-01 15:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:08:24 --> Input Class Initialized
INFO - 2024-08-01 15:08:24 --> Language Class Initialized
INFO - 2024-08-01 15:08:24 --> Language Class Initialized
INFO - 2024-08-01 15:08:24 --> Config Class Initialized
INFO - 2024-08-01 15:08:24 --> Loader Class Initialized
INFO - 2024-08-01 15:08:24 --> Helper loaded: url_helper
INFO - 2024-08-01 15:08:24 --> Helper loaded: file_helper
INFO - 2024-08-01 15:08:24 --> Helper loaded: form_helper
INFO - 2024-08-01 15:08:24 --> Helper loaded: my_helper
INFO - 2024-08-01 15:08:24 --> Database Driver Class Initialized
INFO - 2024-08-01 15:08:25 --> Final output sent to browser
DEBUG - 2024-08-01 15:08:25 --> Total execution time: 4.4402
INFO - 2024-08-01 15:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:08:25 --> Controller Class Initialized
ERROR - 2024-08-01 15:08:25 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-08-01 15:08:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-08-01 15:08:27 --> Config Class Initialized
INFO - 2024-08-01 15:08:27 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:08:27 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:08:27 --> Utf8 Class Initialized
INFO - 2024-08-01 15:08:27 --> URI Class Initialized
INFO - 2024-08-01 15:08:27 --> Router Class Initialized
INFO - 2024-08-01 15:08:27 --> Output Class Initialized
INFO - 2024-08-01 15:08:27 --> Security Class Initialized
DEBUG - 2024-08-01 15:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:08:27 --> Input Class Initialized
INFO - 2024-08-01 15:08:27 --> Language Class Initialized
INFO - 2024-08-01 15:08:27 --> Language Class Initialized
INFO - 2024-08-01 15:08:27 --> Config Class Initialized
INFO - 2024-08-01 15:08:27 --> Loader Class Initialized
INFO - 2024-08-01 15:08:27 --> Helper loaded: url_helper
INFO - 2024-08-01 15:08:27 --> Helper loaded: file_helper
INFO - 2024-08-01 15:08:27 --> Helper loaded: form_helper
INFO - 2024-08-01 15:08:27 --> Helper loaded: my_helper
INFO - 2024-08-01 15:08:27 --> Database Driver Class Initialized
INFO - 2024-08-01 15:08:28 --> Final output sent to browser
DEBUG - 2024-08-01 15:08:28 --> Total execution time: 4.6754
INFO - 2024-08-01 15:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:08:28 --> Controller Class Initialized
DEBUG - 2024-08-01 15:08:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-01 15:08:30 --> Config Class Initialized
INFO - 2024-08-01 15:08:30 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:08:30 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:08:30 --> Utf8 Class Initialized
INFO - 2024-08-01 15:08:30 --> URI Class Initialized
INFO - 2024-08-01 15:08:30 --> Router Class Initialized
INFO - 2024-08-01 15:08:30 --> Output Class Initialized
INFO - 2024-08-01 15:08:30 --> Security Class Initialized
DEBUG - 2024-08-01 15:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:08:30 --> Input Class Initialized
INFO - 2024-08-01 15:08:30 --> Language Class Initialized
INFO - 2024-08-01 15:08:30 --> Language Class Initialized
INFO - 2024-08-01 15:08:30 --> Config Class Initialized
INFO - 2024-08-01 15:08:30 --> Loader Class Initialized
INFO - 2024-08-01 15:08:30 --> Helper loaded: url_helper
INFO - 2024-08-01 15:08:30 --> Helper loaded: file_helper
INFO - 2024-08-01 15:08:30 --> Helper loaded: form_helper
INFO - 2024-08-01 15:08:30 --> Helper loaded: my_helper
INFO - 2024-08-01 15:08:30 --> Database Driver Class Initialized
INFO - 2024-08-01 15:08:33 --> Final output sent to browser
DEBUG - 2024-08-01 15:08:33 --> Total execution time: 6.1658
INFO - 2024-08-01 15:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:08:33 --> Controller Class Initialized
DEBUG - 2024-08-01 15:08:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-08-01 15:08:34 --> Config Class Initialized
INFO - 2024-08-01 15:08:34 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:08:34 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:08:34 --> Utf8 Class Initialized
INFO - 2024-08-01 15:08:34 --> URI Class Initialized
INFO - 2024-08-01 15:08:34 --> Router Class Initialized
INFO - 2024-08-01 15:08:34 --> Output Class Initialized
INFO - 2024-08-01 15:08:34 --> Security Class Initialized
DEBUG - 2024-08-01 15:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:08:34 --> Input Class Initialized
INFO - 2024-08-01 15:08:34 --> Language Class Initialized
INFO - 2024-08-01 15:08:34 --> Language Class Initialized
INFO - 2024-08-01 15:08:34 --> Config Class Initialized
INFO - 2024-08-01 15:08:34 --> Loader Class Initialized
INFO - 2024-08-01 15:08:34 --> Helper loaded: url_helper
INFO - 2024-08-01 15:08:34 --> Helper loaded: file_helper
INFO - 2024-08-01 15:08:34 --> Helper loaded: form_helper
INFO - 2024-08-01 15:08:34 --> Helper loaded: my_helper
INFO - 2024-08-01 15:08:34 --> Database Driver Class Initialized
INFO - 2024-08-01 15:08:35 --> Final output sent to browser
DEBUG - 2024-08-01 15:08:35 --> Total execution time: 5.0023
INFO - 2024-08-01 15:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:08:35 --> Controller Class Initialized
DEBUG - 2024-08-01 15:08:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 15:08:38 --> Final output sent to browser
DEBUG - 2024-08-01 15:08:38 --> Total execution time: 4.7985
INFO - 2024-08-01 15:08:58 --> Config Class Initialized
INFO - 2024-08-01 15:08:58 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:08:58 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:08:58 --> Utf8 Class Initialized
INFO - 2024-08-01 15:08:58 --> URI Class Initialized
INFO - 2024-08-01 15:08:58 --> Router Class Initialized
INFO - 2024-08-01 15:08:58 --> Output Class Initialized
INFO - 2024-08-01 15:08:58 --> Security Class Initialized
DEBUG - 2024-08-01 15:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:08:58 --> Input Class Initialized
INFO - 2024-08-01 15:08:58 --> Language Class Initialized
INFO - 2024-08-01 15:08:58 --> Language Class Initialized
INFO - 2024-08-01 15:08:58 --> Config Class Initialized
INFO - 2024-08-01 15:08:58 --> Loader Class Initialized
INFO - 2024-08-01 15:08:58 --> Helper loaded: url_helper
INFO - 2024-08-01 15:08:58 --> Helper loaded: file_helper
INFO - 2024-08-01 15:08:58 --> Helper loaded: form_helper
INFO - 2024-08-01 15:08:58 --> Helper loaded: my_helper
INFO - 2024-08-01 15:08:58 --> Database Driver Class Initialized
INFO - 2024-08-01 15:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:08:58 --> Controller Class Initialized
ERROR - 2024-08-01 15:08:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-08-01 15:08:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-08-01 15:08:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-08-01 15:08:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-08-01 15:08:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 15:09:00 --> Final output sent to browser
DEBUG - 2024-08-01 15:09:00 --> Total execution time: 2.4450
INFO - 2024-08-01 15:09:04 --> Config Class Initialized
INFO - 2024-08-01 15:09:04 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:09:04 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:09:04 --> Utf8 Class Initialized
INFO - 2024-08-01 15:09:04 --> URI Class Initialized
INFO - 2024-08-01 15:09:04 --> Router Class Initialized
INFO - 2024-08-01 15:09:04 --> Output Class Initialized
INFO - 2024-08-01 15:09:04 --> Security Class Initialized
DEBUG - 2024-08-01 15:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:09:04 --> Input Class Initialized
INFO - 2024-08-01 15:09:04 --> Language Class Initialized
INFO - 2024-08-01 15:09:04 --> Language Class Initialized
INFO - 2024-08-01 15:09:04 --> Config Class Initialized
INFO - 2024-08-01 15:09:04 --> Loader Class Initialized
INFO - 2024-08-01 15:09:04 --> Helper loaded: url_helper
INFO - 2024-08-01 15:09:04 --> Helper loaded: file_helper
INFO - 2024-08-01 15:09:04 --> Helper loaded: form_helper
INFO - 2024-08-01 15:09:04 --> Helper loaded: my_helper
INFO - 2024-08-01 15:09:04 --> Database Driver Class Initialized
INFO - 2024-08-01 15:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:09:04 --> Controller Class Initialized
ERROR - 2024-08-01 15:09:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 64
ERROR - 2024-08-01 15:09:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 490
ERROR - 2024-08-01 15:09:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 500
ERROR - 2024-08-01 15:09:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 510
DEBUG - 2024-08-01 15:09:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
ERROR - 2024-08-01 15:09:06 --> Severity: error --> Exception: The content of the TD tag does not fit on only one page /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/spipu/html2pdf/src/Html2Pdf.php 5680
ERROR - 2024-08-01 15:09:06 --> Severity: Warning --> unlink(/tmp/__tcpdf_ecf11671a4c154780c9f3648e4f3dbc2_imgmask_alpha_5c8c5820de2d21abc04c055a7edbdf01): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/tecnickcom/tcpdf/tcpdf.php 7801
ERROR - 2024-08-01 15:09:06 --> Severity: Warning --> unlink(/tmp/__tcpdf_ecf11671a4c154780c9f3648e4f3dbc2_imgmask_plain_5c8c5820de2d21abc04c055a7edbdf01): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/tecnickcom/tcpdf/tcpdf.php 7801
INFO - 2024-08-01 15:09:10 --> Config Class Initialized
INFO - 2024-08-01 15:09:10 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:09:10 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:09:10 --> Utf8 Class Initialized
INFO - 2024-08-01 15:09:10 --> URI Class Initialized
INFO - 2024-08-01 15:09:10 --> Router Class Initialized
INFO - 2024-08-01 15:09:10 --> Output Class Initialized
INFO - 2024-08-01 15:09:10 --> Security Class Initialized
DEBUG - 2024-08-01 15:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:09:10 --> Input Class Initialized
INFO - 2024-08-01 15:09:10 --> Language Class Initialized
INFO - 2024-08-01 15:09:10 --> Language Class Initialized
INFO - 2024-08-01 15:09:10 --> Config Class Initialized
INFO - 2024-08-01 15:09:10 --> Loader Class Initialized
INFO - 2024-08-01 15:09:10 --> Helper loaded: url_helper
INFO - 2024-08-01 15:09:10 --> Helper loaded: file_helper
INFO - 2024-08-01 15:09:10 --> Helper loaded: form_helper
INFO - 2024-08-01 15:09:10 --> Helper loaded: my_helper
INFO - 2024-08-01 15:09:10 --> Database Driver Class Initialized
INFO - 2024-08-01 15:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:09:10 --> Controller Class Initialized
ERROR - 2024-08-01 15:09:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 48
ERROR - 2024-08-01 15:09:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 134
ERROR - 2024-08-01 15:09:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 143
ERROR - 2024-08-01 15:09:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 150
DEBUG - 2024-08-01 15:09:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
ERROR - 2024-08-01 15:09:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3879
ERROR - 2024-08-01 15:09:15 --> Severity: error --> Exception: TCPDF ERROR: Some data has already been output, can't send PDF file /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/tecnickcom/tcpdf/tcpdf.php 2950
INFO - 2024-08-01 15:09:16 --> Config Class Initialized
INFO - 2024-08-01 15:09:16 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:09:16 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:09:16 --> Utf8 Class Initialized
INFO - 2024-08-01 15:09:16 --> URI Class Initialized
INFO - 2024-08-01 15:09:16 --> Router Class Initialized
INFO - 2024-08-01 15:09:16 --> Output Class Initialized
INFO - 2024-08-01 15:09:16 --> Security Class Initialized
DEBUG - 2024-08-01 15:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:09:16 --> Input Class Initialized
INFO - 2024-08-01 15:09:16 --> Language Class Initialized
INFO - 2024-08-01 15:09:16 --> Language Class Initialized
INFO - 2024-08-01 15:09:16 --> Config Class Initialized
INFO - 2024-08-01 15:09:16 --> Loader Class Initialized
INFO - 2024-08-01 15:09:16 --> Helper loaded: url_helper
INFO - 2024-08-01 15:09:16 --> Helper loaded: file_helper
INFO - 2024-08-01 15:09:16 --> Helper loaded: form_helper
INFO - 2024-08-01 15:09:16 --> Helper loaded: my_helper
INFO - 2024-08-01 15:09:16 --> Database Driver Class Initialized
INFO - 2024-08-01 15:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:09:16 --> Controller Class Initialized
ERROR - 2024-08-01 15:09:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-08-01 15:09:16 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-08-01 15:09:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-08-01 15:09:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-08-01 15:09:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
ERROR - 2024-08-01 15:09:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2033
INFO - 2024-08-01 15:09:20 --> Final output sent to browser
DEBUG - 2024-08-01 15:09:20 --> Total execution time: 3.8538
INFO - 2024-08-01 15:09:23 --> Config Class Initialized
INFO - 2024-08-01 15:09:23 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:09:23 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:09:23 --> Utf8 Class Initialized
INFO - 2024-08-01 15:09:23 --> URI Class Initialized
INFO - 2024-08-01 15:09:23 --> Router Class Initialized
INFO - 2024-08-01 15:09:23 --> Output Class Initialized
INFO - 2024-08-01 15:09:23 --> Security Class Initialized
DEBUG - 2024-08-01 15:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:09:23 --> Input Class Initialized
INFO - 2024-08-01 15:09:23 --> Language Class Initialized
INFO - 2024-08-01 15:09:23 --> Language Class Initialized
INFO - 2024-08-01 15:09:23 --> Config Class Initialized
INFO - 2024-08-01 15:09:23 --> Loader Class Initialized
INFO - 2024-08-01 15:09:23 --> Helper loaded: url_helper
INFO - 2024-08-01 15:09:23 --> Helper loaded: file_helper
INFO - 2024-08-01 15:09:23 --> Helper loaded: form_helper
INFO - 2024-08-01 15:09:23 --> Helper loaded: my_helper
INFO - 2024-08-01 15:09:23 --> Database Driver Class Initialized
INFO - 2024-08-01 15:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:09:23 --> Controller Class Initialized
DEBUG - 2024-08-01 15:09:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-01 15:09:27 --> Final output sent to browser
DEBUG - 2024-08-01 15:09:27 --> Total execution time: 4.1025
INFO - 2024-08-01 15:11:47 --> Config Class Initialized
INFO - 2024-08-01 15:11:47 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:11:47 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:11:47 --> Utf8 Class Initialized
INFO - 2024-08-01 15:11:47 --> URI Class Initialized
INFO - 2024-08-01 15:11:47 --> Router Class Initialized
INFO - 2024-08-01 15:11:47 --> Output Class Initialized
INFO - 2024-08-01 15:11:47 --> Security Class Initialized
DEBUG - 2024-08-01 15:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:11:47 --> Input Class Initialized
INFO - 2024-08-01 15:11:47 --> Language Class Initialized
INFO - 2024-08-01 15:11:47 --> Language Class Initialized
INFO - 2024-08-01 15:11:47 --> Config Class Initialized
INFO - 2024-08-01 15:11:47 --> Loader Class Initialized
INFO - 2024-08-01 15:11:47 --> Helper loaded: url_helper
INFO - 2024-08-01 15:11:47 --> Helper loaded: file_helper
INFO - 2024-08-01 15:11:47 --> Helper loaded: form_helper
INFO - 2024-08-01 15:11:47 --> Helper loaded: my_helper
INFO - 2024-08-01 15:11:47 --> Database Driver Class Initialized
INFO - 2024-08-01 15:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:11:47 --> Controller Class Initialized
ERROR - 2024-08-01 15:11:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 64
ERROR - 2024-08-01 15:11:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 490
ERROR - 2024-08-01 15:11:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 500
ERROR - 2024-08-01 15:11:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 510
DEBUG - 2024-08-01 15:11:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-08-01 15:11:49 --> Final output sent to browser
DEBUG - 2024-08-01 15:11:49 --> Total execution time: 1.9550
INFO - 2024-08-01 15:13:25 --> Config Class Initialized
INFO - 2024-08-01 15:13:25 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:13:25 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:13:25 --> Utf8 Class Initialized
INFO - 2024-08-01 15:13:25 --> URI Class Initialized
INFO - 2024-08-01 15:13:25 --> Router Class Initialized
INFO - 2024-08-01 15:13:25 --> Output Class Initialized
INFO - 2024-08-01 15:13:25 --> Security Class Initialized
DEBUG - 2024-08-01 15:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:13:25 --> Input Class Initialized
INFO - 2024-08-01 15:13:25 --> Language Class Initialized
INFO - 2024-08-01 15:13:25 --> Language Class Initialized
INFO - 2024-08-01 15:13:25 --> Config Class Initialized
INFO - 2024-08-01 15:13:25 --> Loader Class Initialized
INFO - 2024-08-01 15:13:25 --> Helper loaded: url_helper
INFO - 2024-08-01 15:13:25 --> Helper loaded: file_helper
INFO - 2024-08-01 15:13:25 --> Helper loaded: form_helper
INFO - 2024-08-01 15:13:25 --> Helper loaded: my_helper
INFO - 2024-08-01 15:13:25 --> Database Driver Class Initialized
INFO - 2024-08-01 15:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:13:25 --> Controller Class Initialized
ERROR - 2024-08-01 15:13:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 64
ERROR - 2024-08-01 15:13:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 500
ERROR - 2024-08-01 15:13:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 510
DEBUG - 2024-08-01 15:13:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-08-01 15:13:27 --> Final output sent to browser
DEBUG - 2024-08-01 15:13:27 --> Total execution time: 2.0302
INFO - 2024-08-01 15:13:46 --> Config Class Initialized
INFO - 2024-08-01 15:13:46 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:13:46 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:13:46 --> Utf8 Class Initialized
INFO - 2024-08-01 15:13:46 --> URI Class Initialized
INFO - 2024-08-01 15:13:46 --> Router Class Initialized
INFO - 2024-08-01 15:13:46 --> Output Class Initialized
INFO - 2024-08-01 15:13:46 --> Security Class Initialized
DEBUG - 2024-08-01 15:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:13:46 --> Input Class Initialized
INFO - 2024-08-01 15:13:46 --> Language Class Initialized
INFO - 2024-08-01 15:13:46 --> Language Class Initialized
INFO - 2024-08-01 15:13:46 --> Config Class Initialized
INFO - 2024-08-01 15:13:46 --> Loader Class Initialized
INFO - 2024-08-01 15:13:46 --> Helper loaded: url_helper
INFO - 2024-08-01 15:13:46 --> Helper loaded: file_helper
INFO - 2024-08-01 15:13:46 --> Helper loaded: form_helper
INFO - 2024-08-01 15:13:46 --> Helper loaded: my_helper
INFO - 2024-08-01 15:13:46 --> Database Driver Class Initialized
INFO - 2024-08-01 15:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:13:46 --> Controller Class Initialized
ERROR - 2024-08-01 15:13:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 64
ERROR - 2024-08-01 15:13:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 510
DEBUG - 2024-08-01 15:13:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-08-01 15:13:48 --> Final output sent to browser
DEBUG - 2024-08-01 15:13:48 --> Total execution time: 1.8021
INFO - 2024-08-01 15:14:27 --> Config Class Initialized
INFO - 2024-08-01 15:14:27 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:14:27 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:14:27 --> Utf8 Class Initialized
INFO - 2024-08-01 15:14:27 --> URI Class Initialized
INFO - 2024-08-01 15:14:27 --> Router Class Initialized
INFO - 2024-08-01 15:14:27 --> Output Class Initialized
INFO - 2024-08-01 15:14:27 --> Security Class Initialized
DEBUG - 2024-08-01 15:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:14:27 --> Input Class Initialized
INFO - 2024-08-01 15:14:27 --> Language Class Initialized
INFO - 2024-08-01 15:14:27 --> Language Class Initialized
INFO - 2024-08-01 15:14:27 --> Config Class Initialized
INFO - 2024-08-01 15:14:27 --> Loader Class Initialized
INFO - 2024-08-01 15:14:27 --> Helper loaded: url_helper
INFO - 2024-08-01 15:14:27 --> Helper loaded: file_helper
INFO - 2024-08-01 15:14:27 --> Helper loaded: form_helper
INFO - 2024-08-01 15:14:27 --> Helper loaded: my_helper
INFO - 2024-08-01 15:14:27 --> Database Driver Class Initialized
INFO - 2024-08-01 15:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:14:27 --> Controller Class Initialized
DEBUG - 2024-08-01 15:14:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-08-01 15:14:29 --> Final output sent to browser
DEBUG - 2024-08-01 15:14:29 --> Total execution time: 1.3130
INFO - 2024-08-01 15:15:31 --> Config Class Initialized
INFO - 2024-08-01 15:15:31 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:15:31 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:15:31 --> Utf8 Class Initialized
INFO - 2024-08-01 15:15:31 --> URI Class Initialized
INFO - 2024-08-01 15:15:31 --> Router Class Initialized
INFO - 2024-08-01 15:15:31 --> Output Class Initialized
INFO - 2024-08-01 15:15:31 --> Security Class Initialized
DEBUG - 2024-08-01 15:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:15:31 --> Input Class Initialized
INFO - 2024-08-01 15:15:31 --> Language Class Initialized
INFO - 2024-08-01 15:15:31 --> Language Class Initialized
INFO - 2024-08-01 15:15:31 --> Config Class Initialized
INFO - 2024-08-01 15:15:31 --> Loader Class Initialized
INFO - 2024-08-01 15:15:31 --> Helper loaded: url_helper
INFO - 2024-08-01 15:15:31 --> Helper loaded: file_helper
INFO - 2024-08-01 15:15:31 --> Helper loaded: form_helper
INFO - 2024-08-01 15:15:31 --> Helper loaded: my_helper
INFO - 2024-08-01 15:15:31 --> Database Driver Class Initialized
INFO - 2024-08-01 15:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:15:31 --> Controller Class Initialized
ERROR - 2024-08-01 15:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-08-01 15:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-08-01 15:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-08-01 15:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-08-01 15:15:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 15:15:34 --> Final output sent to browser
DEBUG - 2024-08-01 15:15:34 --> Total execution time: 2.8994
INFO - 2024-08-01 15:16:31 --> Config Class Initialized
INFO - 2024-08-01 15:16:31 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:16:31 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:16:31 --> Utf8 Class Initialized
INFO - 2024-08-01 15:16:31 --> URI Class Initialized
INFO - 2024-08-01 15:16:31 --> Router Class Initialized
INFO - 2024-08-01 15:16:31 --> Output Class Initialized
INFO - 2024-08-01 15:16:31 --> Security Class Initialized
DEBUG - 2024-08-01 15:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:16:31 --> Input Class Initialized
INFO - 2024-08-01 15:16:31 --> Language Class Initialized
INFO - 2024-08-01 15:16:31 --> Language Class Initialized
INFO - 2024-08-01 15:16:31 --> Config Class Initialized
INFO - 2024-08-01 15:16:31 --> Loader Class Initialized
INFO - 2024-08-01 15:16:31 --> Helper loaded: url_helper
INFO - 2024-08-01 15:16:31 --> Helper loaded: file_helper
INFO - 2024-08-01 15:16:31 --> Helper loaded: form_helper
INFO - 2024-08-01 15:16:31 --> Helper loaded: my_helper
INFO - 2024-08-01 15:16:31 --> Database Driver Class Initialized
INFO - 2024-08-01 15:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:16:31 --> Controller Class Initialized
ERROR - 2024-08-01 15:16:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-08-01 15:16:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-08-01 15:16:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-08-01 15:16:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 15:16:34 --> Final output sent to browser
DEBUG - 2024-08-01 15:16:34 --> Total execution time: 2.4247
INFO - 2024-08-01 15:17:08 --> Config Class Initialized
INFO - 2024-08-01 15:17:08 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:17:08 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:17:08 --> Utf8 Class Initialized
INFO - 2024-08-01 15:17:08 --> URI Class Initialized
INFO - 2024-08-01 15:17:08 --> Router Class Initialized
INFO - 2024-08-01 15:17:08 --> Output Class Initialized
INFO - 2024-08-01 15:17:08 --> Security Class Initialized
DEBUG - 2024-08-01 15:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:17:08 --> Input Class Initialized
INFO - 2024-08-01 15:17:08 --> Language Class Initialized
INFO - 2024-08-01 15:17:08 --> Language Class Initialized
INFO - 2024-08-01 15:17:08 --> Config Class Initialized
INFO - 2024-08-01 15:17:08 --> Loader Class Initialized
INFO - 2024-08-01 15:17:08 --> Helper loaded: url_helper
INFO - 2024-08-01 15:17:08 --> Helper loaded: file_helper
INFO - 2024-08-01 15:17:08 --> Helper loaded: form_helper
INFO - 2024-08-01 15:17:08 --> Helper loaded: my_helper
INFO - 2024-08-01 15:17:08 --> Database Driver Class Initialized
INFO - 2024-08-01 15:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:17:08 --> Controller Class Initialized
ERROR - 2024-08-01 15:17:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-08-01 15:17:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-08-01 15:17:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 15:17:11 --> Final output sent to browser
DEBUG - 2024-08-01 15:17:11 --> Total execution time: 2.4799
INFO - 2024-08-01 15:18:04 --> Config Class Initialized
INFO - 2024-08-01 15:18:04 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:18:04 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:18:04 --> Utf8 Class Initialized
INFO - 2024-08-01 15:18:04 --> URI Class Initialized
INFO - 2024-08-01 15:18:04 --> Router Class Initialized
INFO - 2024-08-01 15:18:04 --> Output Class Initialized
INFO - 2024-08-01 15:18:04 --> Security Class Initialized
DEBUG - 2024-08-01 15:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:18:04 --> Input Class Initialized
INFO - 2024-08-01 15:18:04 --> Language Class Initialized
INFO - 2024-08-01 15:18:04 --> Language Class Initialized
INFO - 2024-08-01 15:18:04 --> Config Class Initialized
INFO - 2024-08-01 15:18:04 --> Loader Class Initialized
INFO - 2024-08-01 15:18:04 --> Helper loaded: url_helper
INFO - 2024-08-01 15:18:04 --> Helper loaded: file_helper
INFO - 2024-08-01 15:18:04 --> Helper loaded: form_helper
INFO - 2024-08-01 15:18:04 --> Helper loaded: my_helper
INFO - 2024-08-01 15:18:04 --> Database Driver Class Initialized
INFO - 2024-08-01 15:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:18:04 --> Controller Class Initialized
ERROR - 2024-08-01 15:18:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-08-01 15:18:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-08-01 15:18:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 15:18:06 --> Final output sent to browser
DEBUG - 2024-08-01 15:18:06 --> Total execution time: 2.9012
INFO - 2024-08-01 15:19:39 --> Config Class Initialized
INFO - 2024-08-01 15:19:39 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:19:39 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:19:39 --> Utf8 Class Initialized
INFO - 2024-08-01 15:19:39 --> URI Class Initialized
INFO - 2024-08-01 15:19:39 --> Router Class Initialized
INFO - 2024-08-01 15:19:39 --> Output Class Initialized
INFO - 2024-08-01 15:19:39 --> Security Class Initialized
DEBUG - 2024-08-01 15:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:19:39 --> Input Class Initialized
INFO - 2024-08-01 15:19:39 --> Language Class Initialized
INFO - 2024-08-01 15:19:39 --> Language Class Initialized
INFO - 2024-08-01 15:19:39 --> Config Class Initialized
INFO - 2024-08-01 15:19:39 --> Loader Class Initialized
INFO - 2024-08-01 15:19:39 --> Helper loaded: url_helper
INFO - 2024-08-01 15:19:39 --> Helper loaded: file_helper
INFO - 2024-08-01 15:19:39 --> Helper loaded: form_helper
INFO - 2024-08-01 15:19:39 --> Helper loaded: my_helper
INFO - 2024-08-01 15:19:39 --> Database Driver Class Initialized
INFO - 2024-08-01 15:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:19:39 --> Controller Class Initialized
ERROR - 2024-08-01 15:19:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
DEBUG - 2024-08-01 15:19:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 15:19:41 --> Final output sent to browser
DEBUG - 2024-08-01 15:19:41 --> Total execution time: 1.8745
INFO - 2024-08-01 15:20:00 --> Config Class Initialized
INFO - 2024-08-01 15:20:00 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:20:00 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:20:00 --> Utf8 Class Initialized
INFO - 2024-08-01 15:20:00 --> URI Class Initialized
INFO - 2024-08-01 15:20:00 --> Router Class Initialized
INFO - 2024-08-01 15:20:00 --> Output Class Initialized
INFO - 2024-08-01 15:20:00 --> Security Class Initialized
DEBUG - 2024-08-01 15:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:20:00 --> Input Class Initialized
INFO - 2024-08-01 15:20:00 --> Language Class Initialized
INFO - 2024-08-01 15:20:00 --> Language Class Initialized
INFO - 2024-08-01 15:20:00 --> Config Class Initialized
INFO - 2024-08-01 15:20:00 --> Loader Class Initialized
INFO - 2024-08-01 15:20:00 --> Helper loaded: url_helper
INFO - 2024-08-01 15:20:00 --> Helper loaded: file_helper
INFO - 2024-08-01 15:20:00 --> Helper loaded: form_helper
INFO - 2024-08-01 15:20:00 --> Helper loaded: my_helper
INFO - 2024-08-01 15:20:00 --> Database Driver Class Initialized
INFO - 2024-08-01 15:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:20:00 --> Controller Class Initialized
DEBUG - 2024-08-01 15:20:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 15:20:04 --> Final output sent to browser
DEBUG - 2024-08-01 15:20:04 --> Total execution time: 3.1743
INFO - 2024-08-01 15:20:12 --> Config Class Initialized
INFO - 2024-08-01 15:20:12 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:20:12 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:20:12 --> Utf8 Class Initialized
INFO - 2024-08-01 15:20:12 --> URI Class Initialized
INFO - 2024-08-01 15:20:12 --> Router Class Initialized
INFO - 2024-08-01 15:20:12 --> Output Class Initialized
INFO - 2024-08-01 15:20:12 --> Security Class Initialized
DEBUG - 2024-08-01 15:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:20:12 --> Input Class Initialized
INFO - 2024-08-01 15:20:12 --> Language Class Initialized
INFO - 2024-08-01 15:20:12 --> Language Class Initialized
INFO - 2024-08-01 15:20:12 --> Config Class Initialized
INFO - 2024-08-01 15:20:12 --> Loader Class Initialized
INFO - 2024-08-01 15:20:12 --> Helper loaded: url_helper
INFO - 2024-08-01 15:20:12 --> Helper loaded: file_helper
INFO - 2024-08-01 15:20:12 --> Helper loaded: form_helper
INFO - 2024-08-01 15:20:12 --> Helper loaded: my_helper
INFO - 2024-08-01 15:20:12 --> Database Driver Class Initialized
INFO - 2024-08-01 15:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:20:12 --> Controller Class Initialized
ERROR - 2024-08-01 15:20:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 48
ERROR - 2024-08-01 15:20:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 134
ERROR - 2024-08-01 15:20:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 143
ERROR - 2024-08-01 15:20:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 150
DEBUG - 2024-08-01 15:20:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
ERROR - 2024-08-01 15:20:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3883
ERROR - 2024-08-01 15:20:16 --> Severity: error --> Exception: TCPDF ERROR: Some data has already been output, can't send PDF file /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/tecnickcom/tcpdf/tcpdf.php 2950
INFO - 2024-08-01 15:21:14 --> Config Class Initialized
INFO - 2024-08-01 15:21:14 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:21:14 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:21:14 --> Utf8 Class Initialized
INFO - 2024-08-01 15:21:14 --> URI Class Initialized
INFO - 2024-08-01 15:21:14 --> Router Class Initialized
INFO - 2024-08-01 15:21:14 --> Output Class Initialized
INFO - 2024-08-01 15:21:14 --> Security Class Initialized
DEBUG - 2024-08-01 15:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:21:14 --> Input Class Initialized
INFO - 2024-08-01 15:21:14 --> Language Class Initialized
INFO - 2024-08-01 15:21:14 --> Language Class Initialized
INFO - 2024-08-01 15:21:14 --> Config Class Initialized
INFO - 2024-08-01 15:21:14 --> Loader Class Initialized
INFO - 2024-08-01 15:21:14 --> Helper loaded: url_helper
INFO - 2024-08-01 15:21:14 --> Helper loaded: file_helper
INFO - 2024-08-01 15:21:14 --> Helper loaded: form_helper
INFO - 2024-08-01 15:21:14 --> Helper loaded: my_helper
INFO - 2024-08-01 15:21:14 --> Database Driver Class Initialized
INFO - 2024-08-01 15:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:21:14 --> Controller Class Initialized
ERROR - 2024-08-01 15:21:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 48
ERROR - 2024-08-01 15:21:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 134
ERROR - 2024-08-01 15:21:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 143
ERROR - 2024-08-01 15:21:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 150
DEBUG - 2024-08-01 15:21:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-01 15:21:18 --> Final output sent to browser
DEBUG - 2024-08-01 15:21:18 --> Total execution time: 3.7022
INFO - 2024-08-01 15:23:45 --> Config Class Initialized
INFO - 2024-08-01 15:23:45 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:23:45 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:23:45 --> Utf8 Class Initialized
INFO - 2024-08-01 15:23:45 --> URI Class Initialized
INFO - 2024-08-01 15:23:45 --> Router Class Initialized
INFO - 2024-08-01 15:23:45 --> Output Class Initialized
INFO - 2024-08-01 15:23:45 --> Security Class Initialized
DEBUG - 2024-08-01 15:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:23:45 --> Input Class Initialized
INFO - 2024-08-01 15:23:45 --> Language Class Initialized
INFO - 2024-08-01 15:23:45 --> Language Class Initialized
INFO - 2024-08-01 15:23:45 --> Config Class Initialized
INFO - 2024-08-01 15:23:45 --> Loader Class Initialized
INFO - 2024-08-01 15:23:45 --> Helper loaded: url_helper
INFO - 2024-08-01 15:23:45 --> Helper loaded: file_helper
INFO - 2024-08-01 15:23:45 --> Helper loaded: form_helper
INFO - 2024-08-01 15:23:45 --> Helper loaded: my_helper
INFO - 2024-08-01 15:23:45 --> Database Driver Class Initialized
INFO - 2024-08-01 15:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:23:45 --> Controller Class Initialized
ERROR - 2024-08-01 15:23:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 134
ERROR - 2024-08-01 15:23:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 143
ERROR - 2024-08-01 15:23:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 150
DEBUG - 2024-08-01 15:23:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-01 15:23:49 --> Final output sent to browser
DEBUG - 2024-08-01 15:23:49 --> Total execution time: 3.7845
INFO - 2024-08-01 15:24:11 --> Config Class Initialized
INFO - 2024-08-01 15:24:11 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:24:11 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:24:11 --> Utf8 Class Initialized
INFO - 2024-08-01 15:24:11 --> URI Class Initialized
INFO - 2024-08-01 15:24:11 --> Router Class Initialized
INFO - 2024-08-01 15:24:11 --> Output Class Initialized
INFO - 2024-08-01 15:24:11 --> Security Class Initialized
DEBUG - 2024-08-01 15:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:24:11 --> Input Class Initialized
INFO - 2024-08-01 15:24:11 --> Language Class Initialized
INFO - 2024-08-01 15:24:11 --> Language Class Initialized
INFO - 2024-08-01 15:24:11 --> Config Class Initialized
INFO - 2024-08-01 15:24:11 --> Loader Class Initialized
INFO - 2024-08-01 15:24:11 --> Helper loaded: url_helper
INFO - 2024-08-01 15:24:11 --> Helper loaded: file_helper
INFO - 2024-08-01 15:24:11 --> Helper loaded: form_helper
INFO - 2024-08-01 15:24:11 --> Helper loaded: my_helper
INFO - 2024-08-01 15:24:11 --> Database Driver Class Initialized
INFO - 2024-08-01 15:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:24:11 --> Controller Class Initialized
ERROR - 2024-08-01 15:24:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 143
ERROR - 2024-08-01 15:24:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 150
DEBUG - 2024-08-01 15:24:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-01 15:24:15 --> Final output sent to browser
DEBUG - 2024-08-01 15:24:15 --> Total execution time: 4.0002
INFO - 2024-08-01 15:24:27 --> Config Class Initialized
INFO - 2024-08-01 15:24:27 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:24:27 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:24:27 --> Utf8 Class Initialized
INFO - 2024-08-01 15:24:27 --> URI Class Initialized
INFO - 2024-08-01 15:24:27 --> Router Class Initialized
INFO - 2024-08-01 15:24:27 --> Output Class Initialized
INFO - 2024-08-01 15:24:27 --> Security Class Initialized
DEBUG - 2024-08-01 15:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:24:27 --> Input Class Initialized
INFO - 2024-08-01 15:24:27 --> Language Class Initialized
INFO - 2024-08-01 15:24:27 --> Language Class Initialized
INFO - 2024-08-01 15:24:27 --> Config Class Initialized
INFO - 2024-08-01 15:24:27 --> Loader Class Initialized
INFO - 2024-08-01 15:24:27 --> Helper loaded: url_helper
INFO - 2024-08-01 15:24:27 --> Helper loaded: file_helper
INFO - 2024-08-01 15:24:27 --> Helper loaded: form_helper
INFO - 2024-08-01 15:24:27 --> Helper loaded: my_helper
INFO - 2024-08-01 15:24:27 --> Database Driver Class Initialized
INFO - 2024-08-01 15:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:24:27 --> Controller Class Initialized
ERROR - 2024-08-01 15:24:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 143
DEBUG - 2024-08-01 15:24:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-01 15:24:31 --> Final output sent to browser
DEBUG - 2024-08-01 15:24:31 --> Total execution time: 3.9464
INFO - 2024-08-01 15:24:50 --> Config Class Initialized
INFO - 2024-08-01 15:24:50 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:24:50 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:24:50 --> Utf8 Class Initialized
INFO - 2024-08-01 15:24:50 --> URI Class Initialized
INFO - 2024-08-01 15:24:50 --> Router Class Initialized
INFO - 2024-08-01 15:24:50 --> Output Class Initialized
INFO - 2024-08-01 15:24:50 --> Security Class Initialized
DEBUG - 2024-08-01 15:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:24:50 --> Input Class Initialized
INFO - 2024-08-01 15:24:50 --> Language Class Initialized
INFO - 2024-08-01 15:24:50 --> Language Class Initialized
INFO - 2024-08-01 15:24:50 --> Config Class Initialized
INFO - 2024-08-01 15:24:50 --> Loader Class Initialized
INFO - 2024-08-01 15:24:50 --> Helper loaded: url_helper
INFO - 2024-08-01 15:24:50 --> Helper loaded: file_helper
INFO - 2024-08-01 15:24:50 --> Helper loaded: form_helper
INFO - 2024-08-01 15:24:50 --> Helper loaded: my_helper
INFO - 2024-08-01 15:24:50 --> Database Driver Class Initialized
INFO - 2024-08-01 15:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:24:50 --> Controller Class Initialized
DEBUG - 2024-08-01 15:24:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-01 15:24:53 --> Final output sent to browser
DEBUG - 2024-08-01 15:24:53 --> Total execution time: 3.5603
INFO - 2024-08-01 15:25:03 --> Config Class Initialized
INFO - 2024-08-01 15:25:03 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:25:03 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:25:03 --> Utf8 Class Initialized
INFO - 2024-08-01 15:25:03 --> URI Class Initialized
INFO - 2024-08-01 15:25:03 --> Router Class Initialized
INFO - 2024-08-01 15:25:03 --> Output Class Initialized
INFO - 2024-08-01 15:25:03 --> Security Class Initialized
DEBUG - 2024-08-01 15:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:25:03 --> Input Class Initialized
INFO - 2024-08-01 15:25:03 --> Language Class Initialized
INFO - 2024-08-01 15:25:03 --> Language Class Initialized
INFO - 2024-08-01 15:25:03 --> Config Class Initialized
INFO - 2024-08-01 15:25:03 --> Loader Class Initialized
INFO - 2024-08-01 15:25:03 --> Helper loaded: url_helper
INFO - 2024-08-01 15:25:03 --> Helper loaded: file_helper
INFO - 2024-08-01 15:25:03 --> Helper loaded: form_helper
INFO - 2024-08-01 15:25:03 --> Helper loaded: my_helper
INFO - 2024-08-01 15:25:03 --> Database Driver Class Initialized
INFO - 2024-08-01 15:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:25:03 --> Controller Class Initialized
ERROR - 2024-08-01 15:25:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-08-01 15:25:03 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-08-01 15:25:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-08-01 15:25:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-08-01 15:25:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
ERROR - 2024-08-01 15:25:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
INFO - 2024-08-01 15:25:07 --> Config Class Initialized
INFO - 2024-08-01 15:25:07 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:25:07 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:25:07 --> Utf8 Class Initialized
INFO - 2024-08-01 15:25:07 --> URI Class Initialized
INFO - 2024-08-01 15:25:07 --> Router Class Initialized
INFO - 2024-08-01 15:25:07 --> Output Class Initialized
INFO - 2024-08-01 15:25:07 --> Final output sent to browser
DEBUG - 2024-08-01 15:25:07 --> Total execution time: 4.3060
INFO - 2024-08-01 15:25:07 --> Security Class Initialized
DEBUG - 2024-08-01 15:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:25:07 --> Input Class Initialized
INFO - 2024-08-01 15:25:07 --> Language Class Initialized
INFO - 2024-08-01 15:25:07 --> Language Class Initialized
INFO - 2024-08-01 15:25:07 --> Config Class Initialized
INFO - 2024-08-01 15:25:07 --> Loader Class Initialized
INFO - 2024-08-01 15:25:07 --> Helper loaded: url_helper
INFO - 2024-08-01 15:25:07 --> Helper loaded: file_helper
INFO - 2024-08-01 15:25:07 --> Helper loaded: form_helper
INFO - 2024-08-01 15:25:07 --> Helper loaded: my_helper
INFO - 2024-08-01 15:25:07 --> Database Driver Class Initialized
INFO - 2024-08-01 15:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:25:07 --> Controller Class Initialized
DEBUG - 2024-08-01 15:25:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-01 15:25:11 --> Final output sent to browser
DEBUG - 2024-08-01 15:25:11 --> Total execution time: 3.8148
INFO - 2024-08-01 15:25:19 --> Config Class Initialized
INFO - 2024-08-01 15:25:19 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:25:19 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:25:19 --> Utf8 Class Initialized
INFO - 2024-08-01 15:25:19 --> URI Class Initialized
INFO - 2024-08-01 15:25:19 --> Router Class Initialized
INFO - 2024-08-01 15:25:19 --> Output Class Initialized
INFO - 2024-08-01 15:25:19 --> Security Class Initialized
DEBUG - 2024-08-01 15:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:25:19 --> Input Class Initialized
INFO - 2024-08-01 15:25:19 --> Language Class Initialized
INFO - 2024-08-01 15:25:19 --> Language Class Initialized
INFO - 2024-08-01 15:25:19 --> Config Class Initialized
INFO - 2024-08-01 15:25:19 --> Loader Class Initialized
INFO - 2024-08-01 15:25:19 --> Helper loaded: url_helper
INFO - 2024-08-01 15:25:19 --> Helper loaded: file_helper
INFO - 2024-08-01 15:25:19 --> Helper loaded: form_helper
INFO - 2024-08-01 15:25:19 --> Helper loaded: my_helper
INFO - 2024-08-01 15:25:20 --> Database Driver Class Initialized
INFO - 2024-08-01 15:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:25:20 --> Controller Class Initialized
DEBUG - 2024-08-01 15:25:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-01 15:25:22 --> Config Class Initialized
INFO - 2024-08-01 15:25:22 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:25:22 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:25:22 --> Utf8 Class Initialized
INFO - 2024-08-01 15:25:22 --> URI Class Initialized
INFO - 2024-08-01 15:25:22 --> Router Class Initialized
INFO - 2024-08-01 15:25:22 --> Output Class Initialized
INFO - 2024-08-01 15:25:22 --> Security Class Initialized
DEBUG - 2024-08-01 15:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:25:22 --> Input Class Initialized
INFO - 2024-08-01 15:25:22 --> Language Class Initialized
INFO - 2024-08-01 15:25:22 --> Language Class Initialized
INFO - 2024-08-01 15:25:22 --> Config Class Initialized
INFO - 2024-08-01 15:25:22 --> Loader Class Initialized
INFO - 2024-08-01 15:25:22 --> Helper loaded: url_helper
INFO - 2024-08-01 15:25:22 --> Helper loaded: file_helper
INFO - 2024-08-01 15:25:22 --> Helper loaded: form_helper
INFO - 2024-08-01 15:25:22 --> Helper loaded: my_helper
INFO - 2024-08-01 15:25:22 --> Database Driver Class Initialized
INFO - 2024-08-01 15:25:24 --> Final output sent to browser
DEBUG - 2024-08-01 15:25:24 --> Total execution time: 4.1414
INFO - 2024-08-01 15:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:25:24 --> Controller Class Initialized
DEBUG - 2024-08-01 15:25:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-08-01 15:25:24 --> Config Class Initialized
INFO - 2024-08-01 15:25:24 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:25:24 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:25:24 --> Utf8 Class Initialized
INFO - 2024-08-01 15:25:24 --> URI Class Initialized
INFO - 2024-08-01 15:25:24 --> Router Class Initialized
INFO - 2024-08-01 15:25:24 --> Output Class Initialized
INFO - 2024-08-01 15:25:24 --> Security Class Initialized
DEBUG - 2024-08-01 15:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:25:24 --> Input Class Initialized
INFO - 2024-08-01 15:25:24 --> Language Class Initialized
INFO - 2024-08-01 15:25:24 --> Language Class Initialized
INFO - 2024-08-01 15:25:24 --> Config Class Initialized
INFO - 2024-08-01 15:25:24 --> Loader Class Initialized
INFO - 2024-08-01 15:25:24 --> Helper loaded: url_helper
INFO - 2024-08-01 15:25:24 --> Helper loaded: file_helper
INFO - 2024-08-01 15:25:24 --> Helper loaded: form_helper
INFO - 2024-08-01 15:25:24 --> Helper loaded: my_helper
INFO - 2024-08-01 15:25:24 --> Database Driver Class Initialized
INFO - 2024-08-01 15:25:25 --> Final output sent to browser
DEBUG - 2024-08-01 15:25:25 --> Total execution time: 3.2329
INFO - 2024-08-01 15:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:25:25 --> Controller Class Initialized
DEBUG - 2024-08-01 15:25:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 15:25:28 --> Final output sent to browser
DEBUG - 2024-08-01 15:25:28 --> Total execution time: 3.7100
INFO - 2024-08-01 15:25:36 --> Config Class Initialized
INFO - 2024-08-01 15:25:36 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:25:36 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:25:36 --> Utf8 Class Initialized
INFO - 2024-08-01 15:25:36 --> URI Class Initialized
INFO - 2024-08-01 15:25:36 --> Router Class Initialized
INFO - 2024-08-01 15:25:36 --> Output Class Initialized
INFO - 2024-08-01 15:25:36 --> Security Class Initialized
DEBUG - 2024-08-01 15:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:25:36 --> Input Class Initialized
INFO - 2024-08-01 15:25:36 --> Language Class Initialized
INFO - 2024-08-01 15:25:36 --> Language Class Initialized
INFO - 2024-08-01 15:25:36 --> Config Class Initialized
INFO - 2024-08-01 15:25:36 --> Loader Class Initialized
INFO - 2024-08-01 15:25:36 --> Helper loaded: url_helper
INFO - 2024-08-01 15:25:36 --> Helper loaded: file_helper
INFO - 2024-08-01 15:25:36 --> Helper loaded: form_helper
INFO - 2024-08-01 15:25:36 --> Helper loaded: my_helper
INFO - 2024-08-01 15:25:36 --> Database Driver Class Initialized
INFO - 2024-08-01 15:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:25:36 --> Controller Class Initialized
ERROR - 2024-08-01 15:25:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 121
ERROR - 2024-08-01 15:25:37 --> Severity: Notice --> Undefined offset: 2 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 218
ERROR - 2024-08-01 15:25:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 219
ERROR - 2024-08-01 15:25:37 --> Severity: Notice --> Undefined offset: -1 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 228
ERROR - 2024-08-01 15:25:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 135
DEBUG - 2024-08-01 15:25:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 15:25:39 --> Final output sent to browser
DEBUG - 2024-08-01 15:25:39 --> Total execution time: 2.6556
INFO - 2024-08-01 15:25:40 --> Config Class Initialized
INFO - 2024-08-01 15:25:40 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:25:40 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:25:40 --> Utf8 Class Initialized
INFO - 2024-08-01 15:25:40 --> URI Class Initialized
INFO - 2024-08-01 15:25:40 --> Router Class Initialized
INFO - 2024-08-01 15:25:40 --> Output Class Initialized
INFO - 2024-08-01 15:25:40 --> Security Class Initialized
DEBUG - 2024-08-01 15:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:25:40 --> Input Class Initialized
INFO - 2024-08-01 15:25:40 --> Language Class Initialized
INFO - 2024-08-01 15:25:40 --> Language Class Initialized
INFO - 2024-08-01 15:25:40 --> Config Class Initialized
INFO - 2024-08-01 15:25:40 --> Loader Class Initialized
INFO - 2024-08-01 15:25:40 --> Helper loaded: url_helper
INFO - 2024-08-01 15:25:40 --> Helper loaded: file_helper
INFO - 2024-08-01 15:25:40 --> Helper loaded: form_helper
INFO - 2024-08-01 15:25:40 --> Helper loaded: my_helper
INFO - 2024-08-01 15:25:40 --> Database Driver Class Initialized
INFO - 2024-08-01 15:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:25:40 --> Controller Class Initialized
ERROR - 2024-08-01 15:25:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 380
ERROR - 2024-08-01 15:25:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 386
ERROR - 2024-08-01 15:25:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 392
ERROR - 2024-08-01 15:25:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 413
ERROR - 2024-08-01 15:25:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 441
ERROR - 2024-08-01 15:25:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 493
ERROR - 2024-08-01 15:25:40 --> Severity: Notice --> Undefined offset: 2 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 218
ERROR - 2024-08-01 15:25:40 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 219
ERROR - 2024-08-01 15:25:40 --> Severity: Notice --> Undefined offset: -1 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 228
ERROR - 2024-08-01 15:25:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 513
ERROR - 2024-08-01 15:25:40 --> Severity: Notice --> Undefined offset: 2 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 218
ERROR - 2024-08-01 15:25:40 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 219
ERROR - 2024-08-01 15:25:40 --> Severity: Notice --> Undefined offset: -1 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 228
ERROR - 2024-08-01 15:25:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 520
DEBUG - 2024-08-01 15:25:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-08-01 15:25:44 --> Final output sent to browser
DEBUG - 2024-08-01 15:25:44 --> Total execution time: 3.5122
INFO - 2024-08-01 15:25:50 --> Config Class Initialized
INFO - 2024-08-01 15:25:50 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:25:50 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:25:50 --> Utf8 Class Initialized
INFO - 2024-08-01 15:25:50 --> URI Class Initialized
INFO - 2024-08-01 15:25:50 --> Router Class Initialized
INFO - 2024-08-01 15:25:50 --> Output Class Initialized
INFO - 2024-08-01 15:25:50 --> Security Class Initialized
DEBUG - 2024-08-01 15:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:25:50 --> Input Class Initialized
INFO - 2024-08-01 15:25:50 --> Language Class Initialized
INFO - 2024-08-01 15:25:50 --> Language Class Initialized
INFO - 2024-08-01 15:25:50 --> Config Class Initialized
INFO - 2024-08-01 15:25:50 --> Loader Class Initialized
INFO - 2024-08-01 15:25:50 --> Helper loaded: url_helper
INFO - 2024-08-01 15:25:50 --> Helper loaded: file_helper
INFO - 2024-08-01 15:25:50 --> Helper loaded: form_helper
INFO - 2024-08-01 15:25:50 --> Helper loaded: my_helper
INFO - 2024-08-01 15:25:50 --> Database Driver Class Initialized
INFO - 2024-08-01 15:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:25:50 --> Controller Class Initialized
DEBUG - 2024-08-01 15:25:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-01 15:25:52 --> Config Class Initialized
INFO - 2024-08-01 15:25:52 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:25:52 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:25:52 --> Utf8 Class Initialized
INFO - 2024-08-01 15:25:52 --> URI Class Initialized
INFO - 2024-08-01 15:25:52 --> Router Class Initialized
INFO - 2024-08-01 15:25:52 --> Output Class Initialized
INFO - 2024-08-01 15:25:52 --> Security Class Initialized
DEBUG - 2024-08-01 15:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:25:52 --> Input Class Initialized
INFO - 2024-08-01 15:25:52 --> Language Class Initialized
INFO - 2024-08-01 15:25:52 --> Language Class Initialized
INFO - 2024-08-01 15:25:52 --> Config Class Initialized
INFO - 2024-08-01 15:25:52 --> Loader Class Initialized
INFO - 2024-08-01 15:25:52 --> Helper loaded: url_helper
INFO - 2024-08-01 15:25:52 --> Helper loaded: file_helper
INFO - 2024-08-01 15:25:52 --> Helper loaded: form_helper
INFO - 2024-08-01 15:25:52 --> Helper loaded: my_helper
INFO - 2024-08-01 15:25:52 --> Database Driver Class Initialized
INFO - 2024-08-01 15:25:54 --> Config Class Initialized
INFO - 2024-08-01 15:25:54 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:25:54 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:25:54 --> Utf8 Class Initialized
INFO - 2024-08-01 15:25:54 --> URI Class Initialized
INFO - 2024-08-01 15:25:54 --> Router Class Initialized
INFO - 2024-08-01 15:25:54 --> Output Class Initialized
INFO - 2024-08-01 15:25:54 --> Security Class Initialized
DEBUG - 2024-08-01 15:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:25:54 --> Input Class Initialized
INFO - 2024-08-01 15:25:54 --> Language Class Initialized
INFO - 2024-08-01 15:25:54 --> Final output sent to browser
DEBUG - 2024-08-01 15:25:54 --> Total execution time: 3.8175
INFO - 2024-08-01 15:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:25:54 --> Controller Class Initialized
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1843
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 15:25:54 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
INFO - 2024-08-01 15:25:54 --> Language Class Initialized
INFO - 2024-08-01 15:25:54 --> Config Class Initialized
INFO - 2024-08-01 15:25:54 --> Loader Class Initialized
INFO - 2024-08-01 15:25:54 --> Helper loaded: url_helper
INFO - 2024-08-01 15:25:54 --> Helper loaded: file_helper
INFO - 2024-08-01 15:25:54 --> Helper loaded: form_helper
INFO - 2024-08-01 15:25:54 --> Helper loaded: my_helper
DEBUG - 2024-08-01 15:25:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-08-01 15:25:54 --> Database Driver Class Initialized
INFO - 2024-08-01 15:25:56 --> Config Class Initialized
INFO - 2024-08-01 15:25:56 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:25:56 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:25:56 --> Utf8 Class Initialized
INFO - 2024-08-01 15:25:56 --> URI Class Initialized
INFO - 2024-08-01 15:25:56 --> Router Class Initialized
INFO - 2024-08-01 15:25:56 --> Output Class Initialized
INFO - 2024-08-01 15:25:56 --> Security Class Initialized
DEBUG - 2024-08-01 15:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:25:56 --> Input Class Initialized
INFO - 2024-08-01 15:25:56 --> Language Class Initialized
INFO - 2024-08-01 15:25:56 --> Language Class Initialized
INFO - 2024-08-01 15:25:56 --> Config Class Initialized
INFO - 2024-08-01 15:25:56 --> Loader Class Initialized
INFO - 2024-08-01 15:25:56 --> Helper loaded: url_helper
INFO - 2024-08-01 15:25:56 --> Helper loaded: file_helper
INFO - 2024-08-01 15:25:56 --> Helper loaded: form_helper
INFO - 2024-08-01 15:25:56 --> Helper loaded: my_helper
INFO - 2024-08-01 15:25:56 --> Database Driver Class Initialized
INFO - 2024-08-01 15:25:58 --> Config Class Initialized
INFO - 2024-08-01 15:25:58 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:25:58 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:25:58 --> Utf8 Class Initialized
INFO - 2024-08-01 15:25:58 --> URI Class Initialized
INFO - 2024-08-01 15:25:58 --> Router Class Initialized
INFO - 2024-08-01 15:25:58 --> Output Class Initialized
INFO - 2024-08-01 15:25:58 --> Security Class Initialized
DEBUG - 2024-08-01 15:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:25:58 --> Input Class Initialized
INFO - 2024-08-01 15:25:58 --> Language Class Initialized
INFO - 2024-08-01 15:25:58 --> Language Class Initialized
INFO - 2024-08-01 15:25:58 --> Config Class Initialized
INFO - 2024-08-01 15:25:58 --> Loader Class Initialized
INFO - 2024-08-01 15:25:58 --> Helper loaded: url_helper
INFO - 2024-08-01 15:25:58 --> Helper loaded: file_helper
INFO - 2024-08-01 15:25:58 --> Helper loaded: form_helper
INFO - 2024-08-01 15:25:58 --> Helper loaded: my_helper
INFO - 2024-08-01 15:25:58 --> Database Driver Class Initialized
INFO - 2024-08-01 15:25:59 --> Final output sent to browser
DEBUG - 2024-08-01 15:25:59 --> Total execution time: 7.2607
INFO - 2024-08-01 15:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:25:59 --> Controller Class Initialized
DEBUG - 2024-08-01 15:25:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-01 15:26:04 --> Config Class Initialized
INFO - 2024-08-01 15:26:04 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:26:04 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:26:04 --> Utf8 Class Initialized
INFO - 2024-08-01 15:26:04 --> URI Class Initialized
INFO - 2024-08-01 15:26:04 --> Router Class Initialized
INFO - 2024-08-01 15:26:04 --> Output Class Initialized
INFO - 2024-08-01 15:26:04 --> Security Class Initialized
DEBUG - 2024-08-01 15:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:26:04 --> Input Class Initialized
INFO - 2024-08-01 15:26:04 --> Language Class Initialized
INFO - 2024-08-01 15:26:04 --> Language Class Initialized
INFO - 2024-08-01 15:26:04 --> Config Class Initialized
INFO - 2024-08-01 15:26:04 --> Loader Class Initialized
INFO - 2024-08-01 15:26:04 --> Helper loaded: url_helper
INFO - 2024-08-01 15:26:04 --> Helper loaded: file_helper
INFO - 2024-08-01 15:26:04 --> Helper loaded: form_helper
INFO - 2024-08-01 15:26:04 --> Helper loaded: my_helper
INFO - 2024-08-01 15:26:04 --> Database Driver Class Initialized
INFO - 2024-08-01 15:26:05 --> Final output sent to browser
DEBUG - 2024-08-01 15:26:05 --> Total execution time: 10.8079
INFO - 2024-08-01 15:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:26:05 --> Controller Class Initialized
DEBUG - 2024-08-01 15:26:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-08-01 15:26:06 --> Final output sent to browser
DEBUG - 2024-08-01 15:26:06 --> Total execution time: 10.6592
INFO - 2024-08-01 15:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:26:06 --> Controller Class Initialized
DEBUG - 2024-08-01 15:26:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 15:26:10 --> Final output sent to browser
DEBUG - 2024-08-01 15:26:10 --> Total execution time: 12.2985
INFO - 2024-08-01 15:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:26:10 --> Controller Class Initialized
DEBUG - 2024-08-01 15:26:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-01 15:26:10 --> Config Class Initialized
INFO - 2024-08-01 15:26:10 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:26:10 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:26:10 --> Utf8 Class Initialized
INFO - 2024-08-01 15:26:10 --> URI Class Initialized
INFO - 2024-08-01 15:26:10 --> Router Class Initialized
INFO - 2024-08-01 15:26:10 --> Output Class Initialized
INFO - 2024-08-01 15:26:10 --> Security Class Initialized
DEBUG - 2024-08-01 15:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:26:10 --> Input Class Initialized
INFO - 2024-08-01 15:26:10 --> Language Class Initialized
INFO - 2024-08-01 15:26:10 --> Language Class Initialized
INFO - 2024-08-01 15:26:10 --> Config Class Initialized
INFO - 2024-08-01 15:26:10 --> Loader Class Initialized
INFO - 2024-08-01 15:26:10 --> Helper loaded: url_helper
INFO - 2024-08-01 15:26:10 --> Helper loaded: file_helper
INFO - 2024-08-01 15:26:10 --> Helper loaded: form_helper
INFO - 2024-08-01 15:26:10 --> Helper loaded: my_helper
INFO - 2024-08-01 15:26:10 --> Database Driver Class Initialized
INFO - 2024-08-01 15:26:13 --> Final output sent to browser
DEBUG - 2024-08-01 15:26:13 --> Total execution time: 8.9201
INFO - 2024-08-01 15:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:26:13 --> Controller Class Initialized
ERROR - 2024-08-01 15:26:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-08-01 15:26:13 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-08-01 15:26:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 235
ERROR - 2024-08-01 15:26:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 286
ERROR - 2024-08-01 15:26:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-08-01 15:26:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 300
ERROR - 2024-08-01 15:26:13 --> Severity: Notice --> Undefined offset: 2 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 218
ERROR - 2024-08-01 15:26:13 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 219
ERROR - 2024-08-01 15:26:13 --> Severity: Notice --> Undefined offset: -1 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 228
ERROR - 2024-08-01 15:26:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-08-01 15:26:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-08-01 15:26:15 --> Config Class Initialized
INFO - 2024-08-01 15:26:15 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:26:15 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:26:15 --> Utf8 Class Initialized
INFO - 2024-08-01 15:26:15 --> URI Class Initialized
INFO - 2024-08-01 15:26:15 --> Router Class Initialized
INFO - 2024-08-01 15:26:15 --> Output Class Initialized
INFO - 2024-08-01 15:26:15 --> Security Class Initialized
DEBUG - 2024-08-01 15:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:26:15 --> Input Class Initialized
INFO - 2024-08-01 15:26:15 --> Language Class Initialized
INFO - 2024-08-01 15:26:15 --> Language Class Initialized
INFO - 2024-08-01 15:26:15 --> Config Class Initialized
INFO - 2024-08-01 15:26:15 --> Loader Class Initialized
INFO - 2024-08-01 15:26:15 --> Helper loaded: url_helper
INFO - 2024-08-01 15:26:15 --> Helper loaded: file_helper
INFO - 2024-08-01 15:26:15 --> Helper loaded: form_helper
INFO - 2024-08-01 15:26:15 --> Helper loaded: my_helper
INFO - 2024-08-01 15:26:15 --> Database Driver Class Initialized
ERROR - 2024-08-01 15:26:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
INFO - 2024-08-01 15:26:17 --> Final output sent to browser
DEBUG - 2024-08-01 15:26:17 --> Total execution time: 6.5799
INFO - 2024-08-01 15:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:26:17 --> Controller Class Initialized
ERROR - 2024-08-01 15:26:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 145
ERROR - 2024-08-01 15:26:17 --> Severity: Notice --> Undefined offset: 2 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 218
ERROR - 2024-08-01 15:26:17 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 219
ERROR - 2024-08-01 15:26:17 --> Severity: Notice --> Undefined offset: -1 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 228
ERROR - 2024-08-01 15:26:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 159
DEBUG - 2024-08-01 15:26:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-01 15:26:21 --> Config Class Initialized
INFO - 2024-08-01 15:26:21 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:26:21 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:26:21 --> Utf8 Class Initialized
INFO - 2024-08-01 15:26:21 --> URI Class Initialized
INFO - 2024-08-01 15:26:21 --> Router Class Initialized
INFO - 2024-08-01 15:26:21 --> Output Class Initialized
INFO - 2024-08-01 15:26:21 --> Security Class Initialized
DEBUG - 2024-08-01 15:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:26:21 --> Input Class Initialized
INFO - 2024-08-01 15:26:21 --> Language Class Initialized
INFO - 2024-08-01 15:26:21 --> Language Class Initialized
INFO - 2024-08-01 15:26:21 --> Config Class Initialized
INFO - 2024-08-01 15:26:21 --> Loader Class Initialized
INFO - 2024-08-01 15:26:21 --> Helper loaded: url_helper
INFO - 2024-08-01 15:26:21 --> Helper loaded: file_helper
INFO - 2024-08-01 15:26:21 --> Helper loaded: form_helper
INFO - 2024-08-01 15:26:21 --> Helper loaded: my_helper
INFO - 2024-08-01 15:26:21 --> Database Driver Class Initialized
INFO - 2024-08-01 15:26:21 --> Final output sent to browser
DEBUG - 2024-08-01 15:26:21 --> Total execution time: 6.3208
INFO - 2024-08-01 15:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:26:21 --> Controller Class Initialized
ERROR - 2024-08-01 15:26:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 380
ERROR - 2024-08-01 15:26:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 386
ERROR - 2024-08-01 15:26:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 392
ERROR - 2024-08-01 15:26:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 413
ERROR - 2024-08-01 15:26:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 441
ERROR - 2024-08-01 15:26:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 493
ERROR - 2024-08-01 15:26:21 --> Severity: Notice --> Undefined offset: 2 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 218
ERROR - 2024-08-01 15:26:21 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 219
ERROR - 2024-08-01 15:26:21 --> Severity: Notice --> Undefined offset: -1 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 228
ERROR - 2024-08-01 15:26:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 513
ERROR - 2024-08-01 15:26:21 --> Severity: Notice --> Undefined offset: 2 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 218
ERROR - 2024-08-01 15:26:21 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 219
ERROR - 2024-08-01 15:26:21 --> Severity: Notice --> Undefined offset: -1 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 228
ERROR - 2024-08-01 15:26:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 520
DEBUG - 2024-08-01 15:26:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-08-01 15:26:25 --> Final output sent to browser
DEBUG - 2024-08-01 15:26:25 --> Total execution time: 4.4372
INFO - 2024-08-01 15:26:28 --> Config Class Initialized
INFO - 2024-08-01 15:26:28 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:26:28 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:26:28 --> Utf8 Class Initialized
INFO - 2024-08-01 15:26:28 --> URI Class Initialized
INFO - 2024-08-01 15:26:28 --> Router Class Initialized
INFO - 2024-08-01 15:26:28 --> Output Class Initialized
INFO - 2024-08-01 15:26:28 --> Security Class Initialized
DEBUG - 2024-08-01 15:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:26:28 --> Input Class Initialized
INFO - 2024-08-01 15:26:28 --> Language Class Initialized
INFO - 2024-08-01 15:26:28 --> Language Class Initialized
INFO - 2024-08-01 15:26:28 --> Config Class Initialized
INFO - 2024-08-01 15:26:28 --> Loader Class Initialized
INFO - 2024-08-01 15:26:28 --> Helper loaded: url_helper
INFO - 2024-08-01 15:26:28 --> Helper loaded: file_helper
INFO - 2024-08-01 15:26:28 --> Helper loaded: form_helper
INFO - 2024-08-01 15:26:28 --> Helper loaded: my_helper
INFO - 2024-08-01 15:26:28 --> Database Driver Class Initialized
INFO - 2024-08-01 15:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:26:28 --> Controller Class Initialized
ERROR - 2024-08-01 15:26:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 121
ERROR - 2024-08-01 15:26:28 --> Severity: Notice --> Undefined offset: 2 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 218
ERROR - 2024-08-01 15:26:28 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 219
ERROR - 2024-08-01 15:26:28 --> Severity: Notice --> Undefined offset: -1 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 228
ERROR - 2024-08-01 15:26:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 135
DEBUG - 2024-08-01 15:26:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 15:26:31 --> Final output sent to browser
DEBUG - 2024-08-01 15:26:31 --> Total execution time: 2.4620
INFO - 2024-08-01 15:27:30 --> Config Class Initialized
INFO - 2024-08-01 15:27:30 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:27:30 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:27:30 --> Utf8 Class Initialized
INFO - 2024-08-01 15:27:30 --> URI Class Initialized
INFO - 2024-08-01 15:27:30 --> Router Class Initialized
INFO - 2024-08-01 15:27:30 --> Output Class Initialized
INFO - 2024-08-01 15:27:30 --> Security Class Initialized
DEBUG - 2024-08-01 15:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:27:30 --> Input Class Initialized
INFO - 2024-08-01 15:27:30 --> Language Class Initialized
INFO - 2024-08-01 15:27:30 --> Language Class Initialized
INFO - 2024-08-01 15:27:30 --> Config Class Initialized
INFO - 2024-08-01 15:27:30 --> Loader Class Initialized
INFO - 2024-08-01 15:27:30 --> Helper loaded: url_helper
INFO - 2024-08-01 15:27:30 --> Helper loaded: file_helper
INFO - 2024-08-01 15:27:30 --> Helper loaded: form_helper
INFO - 2024-08-01 15:27:30 --> Helper loaded: my_helper
INFO - 2024-08-01 15:27:30 --> Database Driver Class Initialized
INFO - 2024-08-01 15:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:27:30 --> Controller Class Initialized
ERROR - 2024-08-01 15:27:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 159
DEBUG - 2024-08-01 15:27:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-01 15:27:33 --> Final output sent to browser
DEBUG - 2024-08-01 15:27:33 --> Total execution time: 3.4787
INFO - 2024-08-01 15:27:48 --> Config Class Initialized
INFO - 2024-08-01 15:27:48 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:27:48 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:27:48 --> Utf8 Class Initialized
INFO - 2024-08-01 15:27:48 --> URI Class Initialized
INFO - 2024-08-01 15:27:48 --> Router Class Initialized
INFO - 2024-08-01 15:27:48 --> Output Class Initialized
INFO - 2024-08-01 15:27:48 --> Security Class Initialized
DEBUG - 2024-08-01 15:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:27:48 --> Input Class Initialized
INFO - 2024-08-01 15:27:48 --> Language Class Initialized
INFO - 2024-08-01 15:27:48 --> Language Class Initialized
INFO - 2024-08-01 15:27:48 --> Config Class Initialized
INFO - 2024-08-01 15:27:48 --> Loader Class Initialized
INFO - 2024-08-01 15:27:48 --> Helper loaded: url_helper
INFO - 2024-08-01 15:27:48 --> Helper loaded: file_helper
INFO - 2024-08-01 15:27:48 --> Helper loaded: form_helper
INFO - 2024-08-01 15:27:48 --> Helper loaded: my_helper
INFO - 2024-08-01 15:27:48 --> Database Driver Class Initialized
INFO - 2024-08-01 15:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:27:48 --> Controller Class Initialized
DEBUG - 2024-08-01 15:27:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-01 15:27:52 --> Final output sent to browser
DEBUG - 2024-08-01 15:27:52 --> Total execution time: 3.6486
INFO - 2024-08-01 15:28:54 --> Config Class Initialized
INFO - 2024-08-01 15:28:54 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:28:54 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:28:54 --> Utf8 Class Initialized
INFO - 2024-08-01 15:28:54 --> URI Class Initialized
INFO - 2024-08-01 15:28:54 --> Router Class Initialized
INFO - 2024-08-01 15:28:54 --> Output Class Initialized
INFO - 2024-08-01 15:28:54 --> Security Class Initialized
DEBUG - 2024-08-01 15:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:28:54 --> Input Class Initialized
INFO - 2024-08-01 15:28:54 --> Language Class Initialized
INFO - 2024-08-01 15:28:54 --> Language Class Initialized
INFO - 2024-08-01 15:28:54 --> Config Class Initialized
INFO - 2024-08-01 15:28:54 --> Loader Class Initialized
INFO - 2024-08-01 15:28:54 --> Helper loaded: url_helper
INFO - 2024-08-01 15:28:54 --> Helper loaded: file_helper
INFO - 2024-08-01 15:28:54 --> Helper loaded: form_helper
INFO - 2024-08-01 15:28:54 --> Helper loaded: my_helper
INFO - 2024-08-01 15:28:54 --> Database Driver Class Initialized
INFO - 2024-08-01 15:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:28:54 --> Controller Class Initialized
ERROR - 2024-08-01 15:28:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 413
ERROR - 2024-08-01 15:28:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 441
ERROR - 2024-08-01 15:28:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 493
ERROR - 2024-08-01 15:28:54 --> Severity: Notice --> Undefined offset: 2 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 218
ERROR - 2024-08-01 15:28:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 219
ERROR - 2024-08-01 15:28:54 --> Severity: Notice --> Undefined offset: -1 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 228
ERROR - 2024-08-01 15:28:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 513
ERROR - 2024-08-01 15:28:54 --> Severity: Notice --> Undefined offset: 2 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 218
ERROR - 2024-08-01 15:28:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 219
ERROR - 2024-08-01 15:28:54 --> Severity: Notice --> Undefined offset: -1 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 228
ERROR - 2024-08-01 15:28:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 520
DEBUG - 2024-08-01 15:28:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-08-01 15:28:57 --> Final output sent to browser
DEBUG - 2024-08-01 15:28:57 --> Total execution time: 2.9474
INFO - 2024-08-01 15:29:31 --> Config Class Initialized
INFO - 2024-08-01 15:29:31 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:29:31 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:29:31 --> Utf8 Class Initialized
INFO - 2024-08-01 15:29:31 --> URI Class Initialized
INFO - 2024-08-01 15:29:31 --> Router Class Initialized
INFO - 2024-08-01 15:29:31 --> Output Class Initialized
INFO - 2024-08-01 15:29:31 --> Security Class Initialized
DEBUG - 2024-08-01 15:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:29:31 --> Input Class Initialized
INFO - 2024-08-01 15:29:31 --> Language Class Initialized
INFO - 2024-08-01 15:29:31 --> Language Class Initialized
INFO - 2024-08-01 15:29:31 --> Config Class Initialized
INFO - 2024-08-01 15:29:31 --> Loader Class Initialized
INFO - 2024-08-01 15:29:31 --> Helper loaded: url_helper
INFO - 2024-08-01 15:29:31 --> Helper loaded: file_helper
INFO - 2024-08-01 15:29:31 --> Helper loaded: form_helper
INFO - 2024-08-01 15:29:31 --> Helper loaded: my_helper
INFO - 2024-08-01 15:29:31 --> Database Driver Class Initialized
INFO - 2024-08-01 15:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:29:31 --> Controller Class Initialized
ERROR - 2024-08-01 15:29:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 493
ERROR - 2024-08-01 15:29:31 --> Severity: Notice --> Undefined offset: 2 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 218
ERROR - 2024-08-01 15:29:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 219
ERROR - 2024-08-01 15:29:31 --> Severity: Notice --> Undefined offset: -1 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 228
ERROR - 2024-08-01 15:29:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 513
ERROR - 2024-08-01 15:29:31 --> Severity: Notice --> Undefined offset: 2 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 218
ERROR - 2024-08-01 15:29:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 219
ERROR - 2024-08-01 15:29:31 --> Severity: Notice --> Undefined offset: -1 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 228
ERROR - 2024-08-01 15:29:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 520
DEBUG - 2024-08-01 15:29:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-08-01 15:29:34 --> Final output sent to browser
DEBUG - 2024-08-01 15:29:34 --> Total execution time: 2.8571
INFO - 2024-08-01 15:30:14 --> Config Class Initialized
INFO - 2024-08-01 15:30:14 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:30:14 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:30:14 --> Utf8 Class Initialized
INFO - 2024-08-01 15:30:14 --> URI Class Initialized
INFO - 2024-08-01 15:30:14 --> Router Class Initialized
INFO - 2024-08-01 15:30:14 --> Output Class Initialized
INFO - 2024-08-01 15:30:14 --> Security Class Initialized
DEBUG - 2024-08-01 15:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:30:14 --> Input Class Initialized
INFO - 2024-08-01 15:30:14 --> Language Class Initialized
INFO - 2024-08-01 15:30:14 --> Language Class Initialized
INFO - 2024-08-01 15:30:14 --> Config Class Initialized
INFO - 2024-08-01 15:30:14 --> Loader Class Initialized
INFO - 2024-08-01 15:30:14 --> Helper loaded: url_helper
INFO - 2024-08-01 15:30:14 --> Helper loaded: file_helper
INFO - 2024-08-01 15:30:14 --> Helper loaded: form_helper
INFO - 2024-08-01 15:30:14 --> Helper loaded: my_helper
INFO - 2024-08-01 15:30:14 --> Database Driver Class Initialized
INFO - 2024-08-01 15:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:30:14 --> Controller Class Initialized
ERROR - 2024-08-01 15:30:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 513
ERROR - 2024-08-01 15:30:14 --> Severity: Notice --> Undefined offset: 2 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 218
ERROR - 2024-08-01 15:30:14 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 219
ERROR - 2024-08-01 15:30:14 --> Severity: Notice --> Undefined offset: -1 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 228
ERROR - 2024-08-01 15:30:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 520
DEBUG - 2024-08-01 15:30:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-08-01 15:30:16 --> Final output sent to browser
DEBUG - 2024-08-01 15:30:16 --> Total execution time: 2.2029
INFO - 2024-08-01 15:31:10 --> Config Class Initialized
INFO - 2024-08-01 15:31:10 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:31:10 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:31:10 --> Utf8 Class Initialized
INFO - 2024-08-01 15:31:10 --> URI Class Initialized
INFO - 2024-08-01 15:31:10 --> Router Class Initialized
INFO - 2024-08-01 15:31:10 --> Output Class Initialized
INFO - 2024-08-01 15:31:10 --> Security Class Initialized
DEBUG - 2024-08-01 15:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:31:10 --> Input Class Initialized
INFO - 2024-08-01 15:31:10 --> Language Class Initialized
INFO - 2024-08-01 15:31:10 --> Language Class Initialized
INFO - 2024-08-01 15:31:10 --> Config Class Initialized
INFO - 2024-08-01 15:31:10 --> Loader Class Initialized
INFO - 2024-08-01 15:31:10 --> Helper loaded: url_helper
INFO - 2024-08-01 15:31:10 --> Helper loaded: file_helper
INFO - 2024-08-01 15:31:10 --> Helper loaded: form_helper
INFO - 2024-08-01 15:31:10 --> Helper loaded: my_helper
INFO - 2024-08-01 15:31:10 --> Database Driver Class Initialized
INFO - 2024-08-01 15:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:31:10 --> Controller Class Initialized
ERROR - 2024-08-01 15:31:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 520
DEBUG - 2024-08-01 15:31:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-08-01 15:31:12 --> Final output sent to browser
DEBUG - 2024-08-01 15:31:12 --> Total execution time: 2.1748
INFO - 2024-08-01 15:32:08 --> Config Class Initialized
INFO - 2024-08-01 15:32:08 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:32:08 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:32:08 --> Utf8 Class Initialized
INFO - 2024-08-01 15:32:08 --> URI Class Initialized
INFO - 2024-08-01 15:32:08 --> Router Class Initialized
INFO - 2024-08-01 15:32:08 --> Output Class Initialized
INFO - 2024-08-01 15:32:08 --> Security Class Initialized
DEBUG - 2024-08-01 15:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:32:08 --> Input Class Initialized
INFO - 2024-08-01 15:32:08 --> Language Class Initialized
INFO - 2024-08-01 15:32:08 --> Language Class Initialized
INFO - 2024-08-01 15:32:08 --> Config Class Initialized
INFO - 2024-08-01 15:32:08 --> Loader Class Initialized
INFO - 2024-08-01 15:32:08 --> Helper loaded: url_helper
INFO - 2024-08-01 15:32:08 --> Helper loaded: file_helper
INFO - 2024-08-01 15:32:08 --> Helper loaded: form_helper
INFO - 2024-08-01 15:32:08 --> Helper loaded: my_helper
INFO - 2024-08-01 15:32:08 --> Database Driver Class Initialized
INFO - 2024-08-01 15:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:32:08 --> Controller Class Initialized
DEBUG - 2024-08-01 15:32:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-08-01 15:32:10 --> Final output sent to browser
DEBUG - 2024-08-01 15:32:10 --> Total execution time: 1.9976
INFO - 2024-08-01 15:33:06 --> Config Class Initialized
INFO - 2024-08-01 15:33:06 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:33:06 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:33:06 --> Utf8 Class Initialized
INFO - 2024-08-01 15:33:06 --> URI Class Initialized
INFO - 2024-08-01 15:33:07 --> Router Class Initialized
INFO - 2024-08-01 15:33:07 --> Output Class Initialized
INFO - 2024-08-01 15:33:07 --> Security Class Initialized
DEBUG - 2024-08-01 15:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:33:07 --> Input Class Initialized
INFO - 2024-08-01 15:33:07 --> Language Class Initialized
INFO - 2024-08-01 15:33:07 --> Language Class Initialized
INFO - 2024-08-01 15:33:07 --> Config Class Initialized
INFO - 2024-08-01 15:33:07 --> Loader Class Initialized
INFO - 2024-08-01 15:33:07 --> Helper loaded: url_helper
INFO - 2024-08-01 15:33:07 --> Helper loaded: file_helper
INFO - 2024-08-01 15:33:07 --> Helper loaded: form_helper
INFO - 2024-08-01 15:33:07 --> Helper loaded: my_helper
INFO - 2024-08-01 15:33:07 --> Database Driver Class Initialized
INFO - 2024-08-01 15:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:33:07 --> Controller Class Initialized
ERROR - 2024-08-01 15:33:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 135
DEBUG - 2024-08-01 15:33:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 15:33:09 --> Final output sent to browser
DEBUG - 2024-08-01 15:33:09 --> Total execution time: 2.7363
INFO - 2024-08-01 15:33:23 --> Config Class Initialized
INFO - 2024-08-01 15:33:23 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:33:23 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:33:23 --> Utf8 Class Initialized
INFO - 2024-08-01 15:33:23 --> URI Class Initialized
INFO - 2024-08-01 15:33:23 --> Router Class Initialized
INFO - 2024-08-01 15:33:23 --> Output Class Initialized
INFO - 2024-08-01 15:33:23 --> Security Class Initialized
DEBUG - 2024-08-01 15:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:33:23 --> Input Class Initialized
INFO - 2024-08-01 15:33:23 --> Language Class Initialized
INFO - 2024-08-01 15:33:23 --> Language Class Initialized
INFO - 2024-08-01 15:33:23 --> Config Class Initialized
INFO - 2024-08-01 15:33:23 --> Loader Class Initialized
INFO - 2024-08-01 15:33:23 --> Helper loaded: url_helper
INFO - 2024-08-01 15:33:23 --> Helper loaded: file_helper
INFO - 2024-08-01 15:33:23 --> Helper loaded: form_helper
INFO - 2024-08-01 15:33:23 --> Helper loaded: my_helper
INFO - 2024-08-01 15:33:23 --> Database Driver Class Initialized
INFO - 2024-08-01 15:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:33:23 --> Controller Class Initialized
DEBUG - 2024-08-01 15:33:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 15:33:26 --> Final output sent to browser
DEBUG - 2024-08-01 15:33:26 --> Total execution time: 3.4459
INFO - 2024-08-01 15:33:37 --> Config Class Initialized
INFO - 2024-08-01 15:33:37 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:33:37 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:33:37 --> Utf8 Class Initialized
INFO - 2024-08-01 15:33:37 --> URI Class Initialized
INFO - 2024-08-01 15:33:37 --> Router Class Initialized
INFO - 2024-08-01 15:33:37 --> Output Class Initialized
INFO - 2024-08-01 15:33:37 --> Security Class Initialized
DEBUG - 2024-08-01 15:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:33:37 --> Input Class Initialized
INFO - 2024-08-01 15:33:37 --> Language Class Initialized
INFO - 2024-08-01 15:33:37 --> Language Class Initialized
INFO - 2024-08-01 15:33:37 --> Config Class Initialized
INFO - 2024-08-01 15:33:37 --> Loader Class Initialized
INFO - 2024-08-01 15:33:37 --> Helper loaded: url_helper
INFO - 2024-08-01 15:33:37 --> Helper loaded: file_helper
INFO - 2024-08-01 15:33:37 --> Helper loaded: form_helper
INFO - 2024-08-01 15:33:37 --> Helper loaded: my_helper
INFO - 2024-08-01 15:33:37 --> Database Driver Class Initialized
INFO - 2024-08-01 15:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:33:37 --> Controller Class Initialized
DEBUG - 2024-08-01 15:33:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 15:33:41 --> Final output sent to browser
DEBUG - 2024-08-01 15:33:41 --> Total execution time: 3.9891
INFO - 2024-08-01 15:35:02 --> Config Class Initialized
INFO - 2024-08-01 15:35:02 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:35:02 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:35:02 --> Utf8 Class Initialized
INFO - 2024-08-01 15:35:02 --> URI Class Initialized
INFO - 2024-08-01 15:35:02 --> Router Class Initialized
INFO - 2024-08-01 15:35:02 --> Output Class Initialized
INFO - 2024-08-01 15:35:02 --> Security Class Initialized
DEBUG - 2024-08-01 15:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:35:02 --> Input Class Initialized
INFO - 2024-08-01 15:35:02 --> Language Class Initialized
INFO - 2024-08-01 15:35:02 --> Language Class Initialized
INFO - 2024-08-01 15:35:02 --> Config Class Initialized
INFO - 2024-08-01 15:35:02 --> Loader Class Initialized
INFO - 2024-08-01 15:35:02 --> Helper loaded: url_helper
INFO - 2024-08-01 15:35:02 --> Helper loaded: file_helper
INFO - 2024-08-01 15:35:02 --> Helper loaded: form_helper
INFO - 2024-08-01 15:35:02 --> Helper loaded: my_helper
INFO - 2024-08-01 15:35:02 --> Database Driver Class Initialized
INFO - 2024-08-01 15:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:35:02 --> Controller Class Initialized
DEBUG - 2024-08-01 15:35:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 15:35:06 --> Final output sent to browser
DEBUG - 2024-08-01 15:35:06 --> Total execution time: 4.3637
INFO - 2024-08-01 15:36:47 --> Config Class Initialized
INFO - 2024-08-01 15:36:47 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:36:47 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:36:47 --> Utf8 Class Initialized
INFO - 2024-08-01 15:36:47 --> URI Class Initialized
INFO - 2024-08-01 15:36:47 --> Router Class Initialized
INFO - 2024-08-01 15:36:47 --> Output Class Initialized
INFO - 2024-08-01 15:36:47 --> Security Class Initialized
DEBUG - 2024-08-01 15:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:36:47 --> Input Class Initialized
INFO - 2024-08-01 15:36:47 --> Language Class Initialized
INFO - 2024-08-01 15:36:47 --> Language Class Initialized
INFO - 2024-08-01 15:36:47 --> Config Class Initialized
INFO - 2024-08-01 15:36:47 --> Loader Class Initialized
INFO - 2024-08-01 15:36:47 --> Helper loaded: url_helper
INFO - 2024-08-01 15:36:47 --> Helper loaded: file_helper
INFO - 2024-08-01 15:36:47 --> Helper loaded: form_helper
INFO - 2024-08-01 15:36:47 --> Helper loaded: my_helper
INFO - 2024-08-01 15:36:47 --> Database Driver Class Initialized
INFO - 2024-08-01 15:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:36:47 --> Controller Class Initialized
DEBUG - 2024-08-01 15:36:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 15:36:51 --> Final output sent to browser
DEBUG - 2024-08-01 15:36:51 --> Total execution time: 4.3972
INFO - 2024-08-01 15:37:26 --> Config Class Initialized
INFO - 2024-08-01 15:37:26 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:37:26 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:37:26 --> Utf8 Class Initialized
INFO - 2024-08-01 15:37:26 --> URI Class Initialized
INFO - 2024-08-01 15:37:26 --> Router Class Initialized
INFO - 2024-08-01 15:37:26 --> Output Class Initialized
INFO - 2024-08-01 15:37:26 --> Security Class Initialized
DEBUG - 2024-08-01 15:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:37:26 --> Input Class Initialized
INFO - 2024-08-01 15:37:26 --> Language Class Initialized
INFO - 2024-08-01 15:37:26 --> Language Class Initialized
INFO - 2024-08-01 15:37:26 --> Config Class Initialized
INFO - 2024-08-01 15:37:26 --> Loader Class Initialized
INFO - 2024-08-01 15:37:26 --> Helper loaded: url_helper
INFO - 2024-08-01 15:37:26 --> Helper loaded: file_helper
INFO - 2024-08-01 15:37:26 --> Helper loaded: form_helper
INFO - 2024-08-01 15:37:26 --> Helper loaded: my_helper
INFO - 2024-08-01 15:37:26 --> Database Driver Class Initialized
INFO - 2024-08-01 15:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:37:26 --> Controller Class Initialized
DEBUG - 2024-08-01 15:37:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 15:37:30 --> Final output sent to browser
DEBUG - 2024-08-01 15:37:30 --> Total execution time: 4.0290
INFO - 2024-08-01 15:37:38 --> Config Class Initialized
INFO - 2024-08-01 15:37:38 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:37:38 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:37:38 --> Utf8 Class Initialized
INFO - 2024-08-01 15:37:38 --> URI Class Initialized
INFO - 2024-08-01 15:37:38 --> Router Class Initialized
INFO - 2024-08-01 15:37:38 --> Output Class Initialized
INFO - 2024-08-01 15:37:38 --> Security Class Initialized
DEBUG - 2024-08-01 15:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:37:38 --> Input Class Initialized
INFO - 2024-08-01 15:37:38 --> Language Class Initialized
INFO - 2024-08-01 15:37:38 --> Language Class Initialized
INFO - 2024-08-01 15:37:38 --> Config Class Initialized
INFO - 2024-08-01 15:37:38 --> Loader Class Initialized
INFO - 2024-08-01 15:37:38 --> Helper loaded: url_helper
INFO - 2024-08-01 15:37:38 --> Helper loaded: file_helper
INFO - 2024-08-01 15:37:38 --> Helper loaded: form_helper
INFO - 2024-08-01 15:37:38 --> Helper loaded: my_helper
INFO - 2024-08-01 15:37:38 --> Database Driver Class Initialized
INFO - 2024-08-01 15:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:37:38 --> Controller Class Initialized
DEBUG - 2024-08-01 15:37:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 15:37:42 --> Final output sent to browser
DEBUG - 2024-08-01 15:37:42 --> Total execution time: 3.9864
INFO - 2024-08-01 15:37:51 --> Config Class Initialized
INFO - 2024-08-01 15:37:51 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:37:51 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:37:51 --> Utf8 Class Initialized
INFO - 2024-08-01 15:37:51 --> URI Class Initialized
INFO - 2024-08-01 15:37:51 --> Router Class Initialized
INFO - 2024-08-01 15:37:51 --> Output Class Initialized
INFO - 2024-08-01 15:37:51 --> Security Class Initialized
DEBUG - 2024-08-01 15:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:37:51 --> Input Class Initialized
INFO - 2024-08-01 15:37:51 --> Language Class Initialized
INFO - 2024-08-01 15:37:51 --> Language Class Initialized
INFO - 2024-08-01 15:37:51 --> Config Class Initialized
INFO - 2024-08-01 15:37:51 --> Loader Class Initialized
INFO - 2024-08-01 15:37:51 --> Helper loaded: url_helper
INFO - 2024-08-01 15:37:51 --> Helper loaded: file_helper
INFO - 2024-08-01 15:37:51 --> Helper loaded: form_helper
INFO - 2024-08-01 15:37:51 --> Helper loaded: my_helper
INFO - 2024-08-01 15:37:51 --> Database Driver Class Initialized
INFO - 2024-08-01 15:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:37:51 --> Controller Class Initialized
DEBUG - 2024-08-01 15:37:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 15:37:56 --> Final output sent to browser
DEBUG - 2024-08-01 15:37:56 --> Total execution time: 4.4024
INFO - 2024-08-01 15:38:10 --> Config Class Initialized
INFO - 2024-08-01 15:38:10 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:38:10 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:38:10 --> Utf8 Class Initialized
INFO - 2024-08-01 15:38:10 --> URI Class Initialized
INFO - 2024-08-01 15:38:10 --> Router Class Initialized
INFO - 2024-08-01 15:38:10 --> Output Class Initialized
INFO - 2024-08-01 15:38:10 --> Security Class Initialized
DEBUG - 2024-08-01 15:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:38:10 --> Input Class Initialized
INFO - 2024-08-01 15:38:10 --> Language Class Initialized
INFO - 2024-08-01 15:38:10 --> Language Class Initialized
INFO - 2024-08-01 15:38:10 --> Config Class Initialized
INFO - 2024-08-01 15:38:10 --> Loader Class Initialized
INFO - 2024-08-01 15:38:10 --> Helper loaded: url_helper
INFO - 2024-08-01 15:38:10 --> Helper loaded: file_helper
INFO - 2024-08-01 15:38:10 --> Helper loaded: form_helper
INFO - 2024-08-01 15:38:10 --> Helper loaded: my_helper
INFO - 2024-08-01 15:38:10 --> Database Driver Class Initialized
INFO - 2024-08-01 15:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:38:10 --> Controller Class Initialized
DEBUG - 2024-08-01 15:38:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 15:38:15 --> Final output sent to browser
DEBUG - 2024-08-01 15:38:15 --> Total execution time: 5.1302
INFO - 2024-08-01 15:38:25 --> Config Class Initialized
INFO - 2024-08-01 15:38:25 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:38:25 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:38:25 --> Utf8 Class Initialized
INFO - 2024-08-01 15:38:25 --> URI Class Initialized
INFO - 2024-08-01 15:38:25 --> Router Class Initialized
INFO - 2024-08-01 15:38:25 --> Output Class Initialized
INFO - 2024-08-01 15:38:25 --> Security Class Initialized
DEBUG - 2024-08-01 15:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:38:25 --> Input Class Initialized
INFO - 2024-08-01 15:38:25 --> Language Class Initialized
INFO - 2024-08-01 15:38:25 --> Language Class Initialized
INFO - 2024-08-01 15:38:25 --> Config Class Initialized
INFO - 2024-08-01 15:38:25 --> Loader Class Initialized
INFO - 2024-08-01 15:38:25 --> Helper loaded: url_helper
INFO - 2024-08-01 15:38:25 --> Helper loaded: file_helper
INFO - 2024-08-01 15:38:25 --> Helper loaded: form_helper
INFO - 2024-08-01 15:38:25 --> Helper loaded: my_helper
INFO - 2024-08-01 15:38:25 --> Database Driver Class Initialized
INFO - 2024-08-01 15:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:38:25 --> Controller Class Initialized
DEBUG - 2024-08-01 15:38:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 15:38:29 --> Final output sent to browser
DEBUG - 2024-08-01 15:38:29 --> Total execution time: 3.9780
INFO - 2024-08-01 15:39:14 --> Config Class Initialized
INFO - 2024-08-01 15:39:14 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:39:14 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:39:14 --> Utf8 Class Initialized
INFO - 2024-08-01 15:39:14 --> URI Class Initialized
INFO - 2024-08-01 15:39:14 --> Router Class Initialized
INFO - 2024-08-01 15:39:14 --> Output Class Initialized
INFO - 2024-08-01 15:39:14 --> Security Class Initialized
DEBUG - 2024-08-01 15:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:39:14 --> Input Class Initialized
INFO - 2024-08-01 15:39:14 --> Language Class Initialized
INFO - 2024-08-01 15:39:14 --> Language Class Initialized
INFO - 2024-08-01 15:39:14 --> Config Class Initialized
INFO - 2024-08-01 15:39:14 --> Loader Class Initialized
INFO - 2024-08-01 15:39:14 --> Helper loaded: url_helper
INFO - 2024-08-01 15:39:14 --> Helper loaded: file_helper
INFO - 2024-08-01 15:39:14 --> Helper loaded: form_helper
INFO - 2024-08-01 15:39:14 --> Helper loaded: my_helper
INFO - 2024-08-01 15:39:14 --> Database Driver Class Initialized
INFO - 2024-08-01 15:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:39:14 --> Controller Class Initialized
ERROR - 2024-08-01 15:39:15 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 614
ERROR - 2024-08-01 15:39:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 614
ERROR - 2024-08-01 15:39:15 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 614
ERROR - 2024-08-01 15:39:15 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 651
ERROR - 2024-08-01 15:39:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 651
ERROR - 2024-08-01 15:39:15 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 651
ERROR - 2024-08-01 15:39:15 --> Severity: Notice --> Undefined offset: 17 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 689
ERROR - 2024-08-01 15:39:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 689
ERROR - 2024-08-01 15:39:15 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 689
DEBUG - 2024-08-01 15:39:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 15:39:19 --> Final output sent to browser
DEBUG - 2024-08-01 15:39:19 --> Total execution time: 4.3792
INFO - 2024-08-01 15:40:04 --> Config Class Initialized
INFO - 2024-08-01 15:40:04 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:40:04 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:40:04 --> Utf8 Class Initialized
INFO - 2024-08-01 15:40:04 --> URI Class Initialized
INFO - 2024-08-01 15:40:04 --> Router Class Initialized
INFO - 2024-08-01 15:40:04 --> Output Class Initialized
INFO - 2024-08-01 15:40:04 --> Security Class Initialized
DEBUG - 2024-08-01 15:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:40:04 --> Input Class Initialized
INFO - 2024-08-01 15:40:04 --> Language Class Initialized
INFO - 2024-08-01 15:40:04 --> Language Class Initialized
INFO - 2024-08-01 15:40:04 --> Config Class Initialized
INFO - 2024-08-01 15:40:04 --> Loader Class Initialized
INFO - 2024-08-01 15:40:04 --> Helper loaded: url_helper
INFO - 2024-08-01 15:40:04 --> Helper loaded: file_helper
INFO - 2024-08-01 15:40:04 --> Helper loaded: form_helper
INFO - 2024-08-01 15:40:04 --> Helper loaded: my_helper
INFO - 2024-08-01 15:40:04 --> Database Driver Class Initialized
INFO - 2024-08-01 15:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:40:04 --> Controller Class Initialized
ERROR - 2024-08-01 15:40:04 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 651
ERROR - 2024-08-01 15:40:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 651
ERROR - 2024-08-01 15:40:04 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 651
ERROR - 2024-08-01 15:40:04 --> Severity: Notice --> Undefined offset: 17 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 689
ERROR - 2024-08-01 15:40:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 689
ERROR - 2024-08-01 15:40:04 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 689
DEBUG - 2024-08-01 15:40:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 15:40:10 --> Final output sent to browser
DEBUG - 2024-08-01 15:40:10 --> Total execution time: 5.1801
INFO - 2024-08-01 15:40:29 --> Config Class Initialized
INFO - 2024-08-01 15:40:29 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:40:29 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:40:29 --> Utf8 Class Initialized
INFO - 2024-08-01 15:40:29 --> URI Class Initialized
INFO - 2024-08-01 15:40:29 --> Router Class Initialized
INFO - 2024-08-01 15:40:29 --> Output Class Initialized
INFO - 2024-08-01 15:40:29 --> Security Class Initialized
DEBUG - 2024-08-01 15:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:40:29 --> Input Class Initialized
INFO - 2024-08-01 15:40:29 --> Language Class Initialized
INFO - 2024-08-01 15:40:29 --> Language Class Initialized
INFO - 2024-08-01 15:40:29 --> Config Class Initialized
INFO - 2024-08-01 15:40:29 --> Loader Class Initialized
INFO - 2024-08-01 15:40:29 --> Helper loaded: url_helper
INFO - 2024-08-01 15:40:29 --> Helper loaded: file_helper
INFO - 2024-08-01 15:40:29 --> Helper loaded: form_helper
INFO - 2024-08-01 15:40:29 --> Helper loaded: my_helper
INFO - 2024-08-01 15:40:29 --> Database Driver Class Initialized
INFO - 2024-08-01 15:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:40:29 --> Controller Class Initialized
ERROR - 2024-08-01 15:40:29 --> Severity: Notice --> Undefined offset: 17 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 689
ERROR - 2024-08-01 15:40:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 689
ERROR - 2024-08-01 15:40:29 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 689
DEBUG - 2024-08-01 15:40:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 15:40:32 --> Final output sent to browser
DEBUG - 2024-08-01 15:40:32 --> Total execution time: 3.6486
INFO - 2024-08-01 15:40:53 --> Config Class Initialized
INFO - 2024-08-01 15:40:53 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:40:53 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:40:53 --> Utf8 Class Initialized
INFO - 2024-08-01 15:40:53 --> URI Class Initialized
INFO - 2024-08-01 15:40:53 --> Router Class Initialized
INFO - 2024-08-01 15:40:53 --> Output Class Initialized
INFO - 2024-08-01 15:40:53 --> Security Class Initialized
DEBUG - 2024-08-01 15:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:40:53 --> Input Class Initialized
INFO - 2024-08-01 15:40:53 --> Language Class Initialized
INFO - 2024-08-01 15:40:53 --> Language Class Initialized
INFO - 2024-08-01 15:40:53 --> Config Class Initialized
INFO - 2024-08-01 15:40:53 --> Loader Class Initialized
INFO - 2024-08-01 15:40:53 --> Helper loaded: url_helper
INFO - 2024-08-01 15:40:53 --> Helper loaded: file_helper
INFO - 2024-08-01 15:40:53 --> Helper loaded: form_helper
INFO - 2024-08-01 15:40:53 --> Helper loaded: my_helper
INFO - 2024-08-01 15:40:53 --> Database Driver Class Initialized
INFO - 2024-08-01 15:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:40:53 --> Controller Class Initialized
DEBUG - 2024-08-01 15:40:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 15:40:56 --> Final output sent to browser
DEBUG - 2024-08-01 15:40:56 --> Total execution time: 3.6040
INFO - 2024-08-01 15:49:54 --> Config Class Initialized
INFO - 2024-08-01 15:49:54 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:49:54 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:49:54 --> Utf8 Class Initialized
INFO - 2024-08-01 15:49:54 --> URI Class Initialized
INFO - 2024-08-01 15:49:54 --> Router Class Initialized
INFO - 2024-08-01 15:49:54 --> Output Class Initialized
INFO - 2024-08-01 15:49:54 --> Security Class Initialized
DEBUG - 2024-08-01 15:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:49:54 --> Input Class Initialized
INFO - 2024-08-01 15:49:54 --> Language Class Initialized
INFO - 2024-08-01 15:49:54 --> Language Class Initialized
INFO - 2024-08-01 15:49:54 --> Config Class Initialized
INFO - 2024-08-01 15:49:54 --> Loader Class Initialized
INFO - 2024-08-01 15:49:54 --> Helper loaded: url_helper
INFO - 2024-08-01 15:49:54 --> Helper loaded: file_helper
INFO - 2024-08-01 15:49:54 --> Helper loaded: form_helper
INFO - 2024-08-01 15:49:54 --> Helper loaded: my_helper
INFO - 2024-08-01 15:49:54 --> Database Driver Class Initialized
INFO - 2024-08-01 15:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:49:54 --> Controller Class Initialized
DEBUG - 2024-08-01 15:49:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 15:49:58 --> Final output sent to browser
DEBUG - 2024-08-01 15:49:58 --> Total execution time: 4.1600
INFO - 2024-08-01 15:54:17 --> Config Class Initialized
INFO - 2024-08-01 15:54:17 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:54:17 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:54:17 --> Utf8 Class Initialized
INFO - 2024-08-01 15:54:17 --> URI Class Initialized
INFO - 2024-08-01 15:54:17 --> Router Class Initialized
INFO - 2024-08-01 15:54:17 --> Output Class Initialized
INFO - 2024-08-01 15:54:17 --> Security Class Initialized
DEBUG - 2024-08-01 15:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:54:17 --> Input Class Initialized
INFO - 2024-08-01 15:54:17 --> Language Class Initialized
INFO - 2024-08-01 15:54:17 --> Language Class Initialized
INFO - 2024-08-01 15:54:17 --> Config Class Initialized
INFO - 2024-08-01 15:54:17 --> Loader Class Initialized
INFO - 2024-08-01 15:54:17 --> Helper loaded: url_helper
INFO - 2024-08-01 15:54:17 --> Helper loaded: file_helper
INFO - 2024-08-01 15:54:17 --> Helper loaded: form_helper
INFO - 2024-08-01 15:54:17 --> Helper loaded: my_helper
INFO - 2024-08-01 15:54:17 --> Database Driver Class Initialized
INFO - 2024-08-01 15:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:54:17 --> Controller Class Initialized
INFO - 2024-08-01 15:54:17 --> Helper loaded: cookie_helper
INFO - 2024-08-01 15:54:17 --> Config Class Initialized
INFO - 2024-08-01 15:54:17 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:54:17 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:54:17 --> Utf8 Class Initialized
INFO - 2024-08-01 15:54:17 --> URI Class Initialized
INFO - 2024-08-01 15:54:17 --> Router Class Initialized
INFO - 2024-08-01 15:54:17 --> Output Class Initialized
INFO - 2024-08-01 15:54:17 --> Security Class Initialized
DEBUG - 2024-08-01 15:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:54:17 --> Input Class Initialized
INFO - 2024-08-01 15:54:17 --> Language Class Initialized
INFO - 2024-08-01 15:54:17 --> Language Class Initialized
INFO - 2024-08-01 15:54:17 --> Config Class Initialized
INFO - 2024-08-01 15:54:17 --> Loader Class Initialized
INFO - 2024-08-01 15:54:17 --> Helper loaded: url_helper
INFO - 2024-08-01 15:54:17 --> Helper loaded: file_helper
INFO - 2024-08-01 15:54:17 --> Helper loaded: form_helper
INFO - 2024-08-01 15:54:17 --> Helper loaded: my_helper
INFO - 2024-08-01 15:54:17 --> Database Driver Class Initialized
INFO - 2024-08-01 15:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:54:17 --> Controller Class Initialized
INFO - 2024-08-01 15:54:17 --> Config Class Initialized
INFO - 2024-08-01 15:54:17 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:54:17 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:54:17 --> Utf8 Class Initialized
INFO - 2024-08-01 15:54:17 --> URI Class Initialized
INFO - 2024-08-01 15:54:17 --> Router Class Initialized
INFO - 2024-08-01 15:54:17 --> Output Class Initialized
INFO - 2024-08-01 15:54:17 --> Security Class Initialized
DEBUG - 2024-08-01 15:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:54:17 --> Input Class Initialized
INFO - 2024-08-01 15:54:17 --> Language Class Initialized
INFO - 2024-08-01 15:54:17 --> Language Class Initialized
INFO - 2024-08-01 15:54:17 --> Config Class Initialized
INFO - 2024-08-01 15:54:17 --> Loader Class Initialized
INFO - 2024-08-01 15:54:17 --> Helper loaded: url_helper
INFO - 2024-08-01 15:54:17 --> Helper loaded: file_helper
INFO - 2024-08-01 15:54:17 --> Helper loaded: form_helper
INFO - 2024-08-01 15:54:17 --> Helper loaded: my_helper
INFO - 2024-08-01 15:54:17 --> Database Driver Class Initialized
INFO - 2024-08-01 15:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:54:17 --> Controller Class Initialized
DEBUG - 2024-08-01 15:54:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-08-01 15:54:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 15:54:17 --> Final output sent to browser
DEBUG - 2024-08-01 15:54:17 --> Total execution time: 0.0859
INFO - 2024-08-01 15:54:28 --> Config Class Initialized
INFO - 2024-08-01 15:54:28 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:54:28 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:54:28 --> Utf8 Class Initialized
INFO - 2024-08-01 15:54:28 --> URI Class Initialized
INFO - 2024-08-01 15:54:28 --> Router Class Initialized
INFO - 2024-08-01 15:54:28 --> Output Class Initialized
INFO - 2024-08-01 15:54:28 --> Security Class Initialized
DEBUG - 2024-08-01 15:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:54:28 --> Input Class Initialized
INFO - 2024-08-01 15:54:28 --> Language Class Initialized
INFO - 2024-08-01 15:54:28 --> Language Class Initialized
INFO - 2024-08-01 15:54:28 --> Config Class Initialized
INFO - 2024-08-01 15:54:28 --> Loader Class Initialized
INFO - 2024-08-01 15:54:28 --> Helper loaded: url_helper
INFO - 2024-08-01 15:54:28 --> Helper loaded: file_helper
INFO - 2024-08-01 15:54:28 --> Helper loaded: form_helper
INFO - 2024-08-01 15:54:28 --> Helper loaded: my_helper
INFO - 2024-08-01 15:54:28 --> Database Driver Class Initialized
INFO - 2024-08-01 15:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:54:28 --> Controller Class Initialized
DEBUG - 2024-08-01 15:54:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-08-01 15:54:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 15:54:28 --> Final output sent to browser
DEBUG - 2024-08-01 15:54:28 --> Total execution time: 0.0312
INFO - 2024-08-01 15:54:28 --> Config Class Initialized
INFO - 2024-08-01 15:54:28 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:54:28 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:54:28 --> Utf8 Class Initialized
INFO - 2024-08-01 15:54:28 --> URI Class Initialized
INFO - 2024-08-01 15:54:28 --> Router Class Initialized
INFO - 2024-08-01 15:54:28 --> Output Class Initialized
INFO - 2024-08-01 15:54:28 --> Security Class Initialized
DEBUG - 2024-08-01 15:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:54:28 --> Input Class Initialized
INFO - 2024-08-01 15:54:28 --> Language Class Initialized
ERROR - 2024-08-01 15:54:28 --> 404 Page Not Found: /index
INFO - 2024-08-01 15:54:28 --> Config Class Initialized
INFO - 2024-08-01 15:54:28 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:54:28 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:54:28 --> Utf8 Class Initialized
INFO - 2024-08-01 15:54:28 --> URI Class Initialized
INFO - 2024-08-01 15:54:28 --> Router Class Initialized
INFO - 2024-08-01 15:54:28 --> Output Class Initialized
INFO - 2024-08-01 15:54:28 --> Security Class Initialized
DEBUG - 2024-08-01 15:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:54:28 --> Input Class Initialized
INFO - 2024-08-01 15:54:28 --> Language Class Initialized
INFO - 2024-08-01 15:54:28 --> Language Class Initialized
INFO - 2024-08-01 15:54:28 --> Config Class Initialized
INFO - 2024-08-01 15:54:28 --> Loader Class Initialized
INFO - 2024-08-01 15:54:28 --> Helper loaded: url_helper
INFO - 2024-08-01 15:54:28 --> Helper loaded: file_helper
INFO - 2024-08-01 15:54:28 --> Helper loaded: form_helper
INFO - 2024-08-01 15:54:28 --> Helper loaded: my_helper
INFO - 2024-08-01 15:54:28 --> Database Driver Class Initialized
INFO - 2024-08-01 15:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:54:28 --> Controller Class Initialized
INFO - 2024-08-01 15:54:30 --> Config Class Initialized
INFO - 2024-08-01 15:54:30 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:54:30 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:54:30 --> Utf8 Class Initialized
INFO - 2024-08-01 15:54:30 --> URI Class Initialized
INFO - 2024-08-01 15:54:30 --> Router Class Initialized
INFO - 2024-08-01 15:54:30 --> Output Class Initialized
INFO - 2024-08-01 15:54:30 --> Security Class Initialized
DEBUG - 2024-08-01 15:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:54:30 --> Input Class Initialized
INFO - 2024-08-01 15:54:30 --> Language Class Initialized
INFO - 2024-08-01 15:54:30 --> Language Class Initialized
INFO - 2024-08-01 15:54:30 --> Config Class Initialized
INFO - 2024-08-01 15:54:30 --> Loader Class Initialized
INFO - 2024-08-01 15:54:30 --> Helper loaded: url_helper
INFO - 2024-08-01 15:54:30 --> Helper loaded: file_helper
INFO - 2024-08-01 15:54:30 --> Helper loaded: form_helper
INFO - 2024-08-01 15:54:30 --> Helper loaded: my_helper
INFO - 2024-08-01 15:54:30 --> Database Driver Class Initialized
INFO - 2024-08-01 15:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:54:30 --> Controller Class Initialized
INFO - 2024-08-01 15:54:34 --> Config Class Initialized
INFO - 2024-08-01 15:54:34 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:54:34 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:54:34 --> Utf8 Class Initialized
INFO - 2024-08-01 15:54:34 --> URI Class Initialized
INFO - 2024-08-01 15:54:34 --> Router Class Initialized
INFO - 2024-08-01 15:54:34 --> Output Class Initialized
INFO - 2024-08-01 15:54:34 --> Security Class Initialized
DEBUG - 2024-08-01 15:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:54:34 --> Input Class Initialized
INFO - 2024-08-01 15:54:34 --> Language Class Initialized
INFO - 2024-08-01 15:54:34 --> Language Class Initialized
INFO - 2024-08-01 15:54:34 --> Config Class Initialized
INFO - 2024-08-01 15:54:34 --> Loader Class Initialized
INFO - 2024-08-01 15:54:34 --> Helper loaded: url_helper
INFO - 2024-08-01 15:54:34 --> Helper loaded: file_helper
INFO - 2024-08-01 15:54:34 --> Helper loaded: form_helper
INFO - 2024-08-01 15:54:34 --> Helper loaded: my_helper
INFO - 2024-08-01 15:54:34 --> Database Driver Class Initialized
INFO - 2024-08-01 15:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:54:34 --> Controller Class Initialized
INFO - 2024-08-01 15:54:36 --> Config Class Initialized
INFO - 2024-08-01 15:54:36 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:54:36 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:54:36 --> Utf8 Class Initialized
INFO - 2024-08-01 15:54:36 --> URI Class Initialized
INFO - 2024-08-01 15:54:36 --> Router Class Initialized
INFO - 2024-08-01 15:54:36 --> Output Class Initialized
INFO - 2024-08-01 15:54:36 --> Security Class Initialized
DEBUG - 2024-08-01 15:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:54:36 --> Input Class Initialized
INFO - 2024-08-01 15:54:36 --> Language Class Initialized
INFO - 2024-08-01 15:54:36 --> Language Class Initialized
INFO - 2024-08-01 15:54:36 --> Config Class Initialized
INFO - 2024-08-01 15:54:36 --> Loader Class Initialized
INFO - 2024-08-01 15:54:36 --> Helper loaded: url_helper
INFO - 2024-08-01 15:54:36 --> Helper loaded: file_helper
INFO - 2024-08-01 15:54:36 --> Helper loaded: form_helper
INFO - 2024-08-01 15:54:36 --> Helper loaded: my_helper
INFO - 2024-08-01 15:54:36 --> Database Driver Class Initialized
INFO - 2024-08-01 15:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:54:36 --> Controller Class Initialized
INFO - 2024-08-01 15:54:45 --> Config Class Initialized
INFO - 2024-08-01 15:54:45 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:54:45 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:54:45 --> Utf8 Class Initialized
INFO - 2024-08-01 15:54:45 --> URI Class Initialized
INFO - 2024-08-01 15:54:45 --> Router Class Initialized
INFO - 2024-08-01 15:54:45 --> Output Class Initialized
INFO - 2024-08-01 15:54:45 --> Security Class Initialized
DEBUG - 2024-08-01 15:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:54:45 --> Input Class Initialized
INFO - 2024-08-01 15:54:45 --> Language Class Initialized
INFO - 2024-08-01 15:54:45 --> Language Class Initialized
INFO - 2024-08-01 15:54:45 --> Config Class Initialized
INFO - 2024-08-01 15:54:45 --> Loader Class Initialized
INFO - 2024-08-01 15:54:45 --> Helper loaded: url_helper
INFO - 2024-08-01 15:54:45 --> Helper loaded: file_helper
INFO - 2024-08-01 15:54:45 --> Helper loaded: form_helper
INFO - 2024-08-01 15:54:45 --> Helper loaded: my_helper
INFO - 2024-08-01 15:54:45 --> Database Driver Class Initialized
INFO - 2024-08-01 15:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:54:45 --> Controller Class Initialized
INFO - 2024-08-01 15:54:45 --> Helper loaded: cookie_helper
INFO - 2024-08-01 15:54:45 --> Final output sent to browser
DEBUG - 2024-08-01 15:54:45 --> Total execution time: 0.0316
INFO - 2024-08-01 15:54:45 --> Config Class Initialized
INFO - 2024-08-01 15:54:45 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:54:45 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:54:45 --> Utf8 Class Initialized
INFO - 2024-08-01 15:54:45 --> URI Class Initialized
INFO - 2024-08-01 15:54:45 --> Router Class Initialized
INFO - 2024-08-01 15:54:45 --> Output Class Initialized
INFO - 2024-08-01 15:54:45 --> Security Class Initialized
DEBUG - 2024-08-01 15:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:54:45 --> Input Class Initialized
INFO - 2024-08-01 15:54:45 --> Language Class Initialized
INFO - 2024-08-01 15:54:45 --> Language Class Initialized
INFO - 2024-08-01 15:54:45 --> Config Class Initialized
INFO - 2024-08-01 15:54:45 --> Loader Class Initialized
INFO - 2024-08-01 15:54:45 --> Helper loaded: url_helper
INFO - 2024-08-01 15:54:45 --> Helper loaded: file_helper
INFO - 2024-08-01 15:54:45 --> Helper loaded: form_helper
INFO - 2024-08-01 15:54:45 --> Helper loaded: my_helper
INFO - 2024-08-01 15:54:45 --> Database Driver Class Initialized
INFO - 2024-08-01 15:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:54:45 --> Controller Class Initialized
DEBUG - 2024-08-01 15:54:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-08-01 15:54:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 15:54:45 --> Final output sent to browser
DEBUG - 2024-08-01 15:54:45 --> Total execution time: 0.0361
INFO - 2024-08-01 15:54:46 --> Config Class Initialized
INFO - 2024-08-01 15:54:46 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:54:46 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:54:46 --> Utf8 Class Initialized
INFO - 2024-08-01 15:54:46 --> URI Class Initialized
INFO - 2024-08-01 15:54:46 --> Router Class Initialized
INFO - 2024-08-01 15:54:46 --> Output Class Initialized
INFO - 2024-08-01 15:54:46 --> Security Class Initialized
DEBUG - 2024-08-01 15:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:54:46 --> Input Class Initialized
INFO - 2024-08-01 15:54:46 --> Language Class Initialized
INFO - 2024-08-01 15:54:46 --> Language Class Initialized
INFO - 2024-08-01 15:54:46 --> Config Class Initialized
INFO - 2024-08-01 15:54:46 --> Loader Class Initialized
INFO - 2024-08-01 15:54:46 --> Helper loaded: url_helper
INFO - 2024-08-01 15:54:46 --> Helper loaded: file_helper
INFO - 2024-08-01 15:54:46 --> Helper loaded: form_helper
INFO - 2024-08-01 15:54:46 --> Helper loaded: my_helper
INFO - 2024-08-01 15:54:46 --> Database Driver Class Initialized
INFO - 2024-08-01 15:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:54:46 --> Controller Class Initialized
DEBUG - 2024-08-01 15:54:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-01 15:54:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 15:54:46 --> Final output sent to browser
DEBUG - 2024-08-01 15:54:46 --> Total execution time: 0.0376
INFO - 2024-08-01 15:54:49 --> Config Class Initialized
INFO - 2024-08-01 15:54:49 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:54:49 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:54:49 --> Utf8 Class Initialized
INFO - 2024-08-01 15:54:49 --> URI Class Initialized
INFO - 2024-08-01 15:54:49 --> Router Class Initialized
INFO - 2024-08-01 15:54:49 --> Output Class Initialized
INFO - 2024-08-01 15:54:49 --> Security Class Initialized
DEBUG - 2024-08-01 15:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:54:49 --> Input Class Initialized
INFO - 2024-08-01 15:54:49 --> Language Class Initialized
INFO - 2024-08-01 15:54:49 --> Language Class Initialized
INFO - 2024-08-01 15:54:49 --> Config Class Initialized
INFO - 2024-08-01 15:54:49 --> Loader Class Initialized
INFO - 2024-08-01 15:54:49 --> Helper loaded: url_helper
INFO - 2024-08-01 15:54:49 --> Helper loaded: file_helper
INFO - 2024-08-01 15:54:49 --> Helper loaded: form_helper
INFO - 2024-08-01 15:54:49 --> Helper loaded: my_helper
INFO - 2024-08-01 15:54:49 --> Database Driver Class Initialized
INFO - 2024-08-01 15:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:54:49 --> Controller Class Initialized
DEBUG - 2024-08-01 15:54:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-01 15:54:51 --> Config Class Initialized
INFO - 2024-08-01 15:54:51 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:54:51 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:54:51 --> Utf8 Class Initialized
INFO - 2024-08-01 15:54:51 --> URI Class Initialized
INFO - 2024-08-01 15:54:51 --> Router Class Initialized
INFO - 2024-08-01 15:54:51 --> Output Class Initialized
INFO - 2024-08-01 15:54:51 --> Security Class Initialized
DEBUG - 2024-08-01 15:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:54:51 --> Input Class Initialized
INFO - 2024-08-01 15:54:51 --> Language Class Initialized
INFO - 2024-08-01 15:54:51 --> Language Class Initialized
INFO - 2024-08-01 15:54:51 --> Config Class Initialized
INFO - 2024-08-01 15:54:51 --> Loader Class Initialized
INFO - 2024-08-01 15:54:51 --> Helper loaded: url_helper
INFO - 2024-08-01 15:54:51 --> Helper loaded: file_helper
INFO - 2024-08-01 15:54:51 --> Helper loaded: form_helper
INFO - 2024-08-01 15:54:51 --> Helper loaded: my_helper
INFO - 2024-08-01 15:54:51 --> Database Driver Class Initialized
INFO - 2024-08-01 15:54:52 --> Final output sent to browser
DEBUG - 2024-08-01 15:54:52 --> Total execution time: 3.6611
INFO - 2024-08-01 15:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:54:52 --> Controller Class Initialized
ERROR - 2024-08-01 15:54:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1797
ERROR - 2024-08-01 15:54:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1804
ERROR - 2024-08-01 15:54:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-08-01 15:54:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-08-01 15:54:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-08-01 15:54:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 86
ERROR - 2024-08-01 15:54:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-08-01 15:54:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-08-01 15:54:52 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-08-01 15:54:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-08-01 15:54:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-08-01 15:54:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-08-01 15:54:53 --> Config Class Initialized
INFO - 2024-08-01 15:54:53 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:54:53 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:54:53 --> Utf8 Class Initialized
INFO - 2024-08-01 15:54:53 --> URI Class Initialized
INFO - 2024-08-01 15:54:53 --> Router Class Initialized
INFO - 2024-08-01 15:54:53 --> Output Class Initialized
INFO - 2024-08-01 15:54:53 --> Security Class Initialized
DEBUG - 2024-08-01 15:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:54:53 --> Input Class Initialized
INFO - 2024-08-01 15:54:53 --> Language Class Initialized
INFO - 2024-08-01 15:54:53 --> Language Class Initialized
INFO - 2024-08-01 15:54:53 --> Config Class Initialized
INFO - 2024-08-01 15:54:53 --> Loader Class Initialized
INFO - 2024-08-01 15:54:53 --> Helper loaded: url_helper
INFO - 2024-08-01 15:54:53 --> Helper loaded: file_helper
INFO - 2024-08-01 15:54:53 --> Helper loaded: form_helper
INFO - 2024-08-01 15:54:53 --> Helper loaded: my_helper
INFO - 2024-08-01 15:54:53 --> Database Driver Class Initialized
INFO - 2024-08-01 15:54:55 --> Config Class Initialized
INFO - 2024-08-01 15:54:55 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:54:55 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:54:55 --> Utf8 Class Initialized
INFO - 2024-08-01 15:54:55 --> URI Class Initialized
INFO - 2024-08-01 15:54:55 --> Router Class Initialized
INFO - 2024-08-01 15:54:55 --> Output Class Initialized
INFO - 2024-08-01 15:54:55 --> Security Class Initialized
DEBUG - 2024-08-01 15:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:54:55 --> Input Class Initialized
INFO - 2024-08-01 15:54:55 --> Language Class Initialized
INFO - 2024-08-01 15:54:55 --> Language Class Initialized
INFO - 2024-08-01 15:54:55 --> Config Class Initialized
INFO - 2024-08-01 15:54:55 --> Loader Class Initialized
INFO - 2024-08-01 15:54:55 --> Helper loaded: url_helper
INFO - 2024-08-01 15:54:55 --> Helper loaded: file_helper
INFO - 2024-08-01 15:54:55 --> Helper loaded: form_helper
INFO - 2024-08-01 15:54:55 --> Helper loaded: my_helper
INFO - 2024-08-01 15:54:55 --> Database Driver Class Initialized
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
INFO - 2024-08-01 15:54:56 --> Final output sent to browser
DEBUG - 2024-08-01 15:54:56 --> Total execution time: 5.8055
INFO - 2024-08-01 15:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:54:56 --> Controller Class Initialized
INFO - 2024-08-01 15:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:54:56 --> Controller Class Initialized
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2591
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3156
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3194
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3232
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3271
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3388
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3507
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3626
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3745
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-08-01 15:54:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 40
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
ERROR - 2024-08-01 15:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
DEBUG - 2024-08-01 15:54:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-01 15:54:57 --> Config Class Initialized
INFO - 2024-08-01 15:54:57 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:54:57 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:54:57 --> Utf8 Class Initialized
INFO - 2024-08-01 15:54:57 --> URI Class Initialized
INFO - 2024-08-01 15:54:57 --> Router Class Initialized
INFO - 2024-08-01 15:54:57 --> Output Class Initialized
INFO - 2024-08-01 15:54:57 --> Security Class Initialized
DEBUG - 2024-08-01 15:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:54:57 --> Input Class Initialized
INFO - 2024-08-01 15:54:57 --> Language Class Initialized
INFO - 2024-08-01 15:54:57 --> Language Class Initialized
INFO - 2024-08-01 15:54:57 --> Config Class Initialized
INFO - 2024-08-01 15:54:57 --> Loader Class Initialized
INFO - 2024-08-01 15:54:57 --> Helper loaded: url_helper
INFO - 2024-08-01 15:54:57 --> Helper loaded: file_helper
INFO - 2024-08-01 15:54:57 --> Helper loaded: form_helper
INFO - 2024-08-01 15:54:57 --> Helper loaded: my_helper
INFO - 2024-08-01 15:54:57 --> Database Driver Class Initialized
INFO - 2024-08-01 15:55:02 --> Final output sent to browser
DEBUG - 2024-08-01 15:55:02 --> Total execution time: 7.2246
INFO - 2024-08-01 15:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:55:02 --> Controller Class Initialized
ERROR - 2024-08-01 15:55:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-01 15:55:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-01 15:55:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-01 15:55:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-01 15:55:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-01 15:55:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-01 15:55:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-01 15:55:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-01 15:55:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-01 15:55:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-01 15:55:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-01 15:55:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-01 15:55:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-01 15:55:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 15:55:08 --> Final output sent to browser
DEBUG - 2024-08-01 15:55:08 --> Total execution time: 11.1820
INFO - 2024-08-01 15:57:14 --> Config Class Initialized
INFO - 2024-08-01 15:57:14 --> Hooks Class Initialized
DEBUG - 2024-08-01 15:57:14 --> UTF-8 Support Enabled
INFO - 2024-08-01 15:57:14 --> Utf8 Class Initialized
INFO - 2024-08-01 15:57:14 --> URI Class Initialized
INFO - 2024-08-01 15:57:14 --> Router Class Initialized
INFO - 2024-08-01 15:57:14 --> Output Class Initialized
INFO - 2024-08-01 15:57:14 --> Security Class Initialized
DEBUG - 2024-08-01 15:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 15:57:14 --> Input Class Initialized
INFO - 2024-08-01 15:57:14 --> Language Class Initialized
INFO - 2024-08-01 15:57:14 --> Language Class Initialized
INFO - 2024-08-01 15:57:14 --> Config Class Initialized
INFO - 2024-08-01 15:57:14 --> Loader Class Initialized
INFO - 2024-08-01 15:57:14 --> Helper loaded: url_helper
INFO - 2024-08-01 15:57:14 --> Helper loaded: file_helper
INFO - 2024-08-01 15:57:14 --> Helper loaded: form_helper
INFO - 2024-08-01 15:57:14 --> Helper loaded: my_helper
INFO - 2024-08-01 15:57:14 --> Database Driver Class Initialized
INFO - 2024-08-01 15:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 15:57:14 --> Controller Class Initialized
DEBUG - 2024-08-01 15:57:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-01 15:57:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 15:57:14 --> Final output sent to browser
DEBUG - 2024-08-01 15:57:14 --> Total execution time: 0.3855
ERROR - 2024-08-01 15:58:40 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 262144 bytes) /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/tecnickcom/tcpdf/tcpdf.php 2226
INFO - 2024-08-01 16:00:49 --> Config Class Initialized
INFO - 2024-08-01 16:00:49 --> Hooks Class Initialized
DEBUG - 2024-08-01 16:00:49 --> UTF-8 Support Enabled
INFO - 2024-08-01 16:00:49 --> Utf8 Class Initialized
INFO - 2024-08-01 16:00:49 --> URI Class Initialized
INFO - 2024-08-01 16:00:49 --> Router Class Initialized
INFO - 2024-08-01 16:00:49 --> Output Class Initialized
INFO - 2024-08-01 16:00:49 --> Security Class Initialized
DEBUG - 2024-08-01 16:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 16:00:49 --> Input Class Initialized
INFO - 2024-08-01 16:00:49 --> Language Class Initialized
INFO - 2024-08-01 16:00:49 --> Language Class Initialized
INFO - 2024-08-01 16:00:49 --> Config Class Initialized
INFO - 2024-08-01 16:00:49 --> Loader Class Initialized
INFO - 2024-08-01 16:00:49 --> Helper loaded: url_helper
INFO - 2024-08-01 16:00:49 --> Helper loaded: file_helper
INFO - 2024-08-01 16:00:49 --> Helper loaded: form_helper
INFO - 2024-08-01 16:00:49 --> Helper loaded: my_helper
INFO - 2024-08-01 16:00:49 --> Database Driver Class Initialized
INFO - 2024-08-01 16:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 16:00:49 --> Controller Class Initialized
DEBUG - 2024-08-01 16:00:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-01 16:00:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 16:00:49 --> Final output sent to browser
DEBUG - 2024-08-01 16:00:49 --> Total execution time: 0.0396
INFO - 2024-08-01 16:00:51 --> Config Class Initialized
INFO - 2024-08-01 16:00:51 --> Hooks Class Initialized
DEBUG - 2024-08-01 16:00:51 --> UTF-8 Support Enabled
INFO - 2024-08-01 16:00:51 --> Utf8 Class Initialized
INFO - 2024-08-01 16:00:51 --> URI Class Initialized
DEBUG - 2024-08-01 16:00:51 --> No URI present. Default controller set.
INFO - 2024-08-01 16:00:51 --> Router Class Initialized
INFO - 2024-08-01 16:00:51 --> Output Class Initialized
INFO - 2024-08-01 16:00:51 --> Security Class Initialized
DEBUG - 2024-08-01 16:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 16:00:51 --> Input Class Initialized
INFO - 2024-08-01 16:00:51 --> Language Class Initialized
INFO - 2024-08-01 16:00:51 --> Language Class Initialized
INFO - 2024-08-01 16:00:51 --> Config Class Initialized
INFO - 2024-08-01 16:00:51 --> Loader Class Initialized
INFO - 2024-08-01 16:00:51 --> Helper loaded: url_helper
INFO - 2024-08-01 16:00:51 --> Helper loaded: file_helper
INFO - 2024-08-01 16:00:51 --> Helper loaded: form_helper
INFO - 2024-08-01 16:00:51 --> Helper loaded: my_helper
INFO - 2024-08-01 16:00:51 --> Database Driver Class Initialized
INFO - 2024-08-01 16:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 16:00:51 --> Controller Class Initialized
DEBUG - 2024-08-01 16:00:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-08-01 16:00:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 16:00:51 --> Final output sent to browser
DEBUG - 2024-08-01 16:00:51 --> Total execution time: 0.0264
INFO - 2024-08-01 16:00:52 --> Config Class Initialized
INFO - 2024-08-01 16:00:52 --> Hooks Class Initialized
DEBUG - 2024-08-01 16:00:52 --> UTF-8 Support Enabled
INFO - 2024-08-01 16:00:52 --> Utf8 Class Initialized
INFO - 2024-08-01 16:00:52 --> URI Class Initialized
INFO - 2024-08-01 16:00:52 --> Router Class Initialized
INFO - 2024-08-01 16:00:52 --> Output Class Initialized
INFO - 2024-08-01 16:00:52 --> Security Class Initialized
DEBUG - 2024-08-01 16:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 16:00:52 --> Input Class Initialized
INFO - 2024-08-01 16:00:52 --> Language Class Initialized
INFO - 2024-08-01 16:00:52 --> Language Class Initialized
INFO - 2024-08-01 16:00:52 --> Config Class Initialized
INFO - 2024-08-01 16:00:52 --> Loader Class Initialized
INFO - 2024-08-01 16:00:52 --> Helper loaded: url_helper
INFO - 2024-08-01 16:00:52 --> Helper loaded: file_helper
INFO - 2024-08-01 16:00:52 --> Helper loaded: form_helper
INFO - 2024-08-01 16:00:52 --> Helper loaded: my_helper
INFO - 2024-08-01 16:00:52 --> Database Driver Class Initialized
INFO - 2024-08-01 16:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 16:00:52 --> Controller Class Initialized
DEBUG - 2024-08-01 16:00:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-01 16:00:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 16:00:52 --> Final output sent to browser
DEBUG - 2024-08-01 16:00:52 --> Total execution time: 0.0547
INFO - 2024-08-01 16:00:54 --> Config Class Initialized
INFO - 2024-08-01 16:00:54 --> Hooks Class Initialized
DEBUG - 2024-08-01 16:00:54 --> UTF-8 Support Enabled
INFO - 2024-08-01 16:00:54 --> Utf8 Class Initialized
INFO - 2024-08-01 16:00:54 --> URI Class Initialized
INFO - 2024-08-01 16:00:54 --> Router Class Initialized
INFO - 2024-08-01 16:00:54 --> Output Class Initialized
INFO - 2024-08-01 16:00:54 --> Security Class Initialized
DEBUG - 2024-08-01 16:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 16:00:54 --> Input Class Initialized
INFO - 2024-08-01 16:00:54 --> Language Class Initialized
INFO - 2024-08-01 16:00:54 --> Language Class Initialized
INFO - 2024-08-01 16:00:54 --> Config Class Initialized
INFO - 2024-08-01 16:00:54 --> Loader Class Initialized
INFO - 2024-08-01 16:00:54 --> Helper loaded: url_helper
INFO - 2024-08-01 16:00:54 --> Helper loaded: file_helper
INFO - 2024-08-01 16:00:54 --> Helper loaded: form_helper
INFO - 2024-08-01 16:00:54 --> Helper loaded: my_helper
INFO - 2024-08-01 16:00:54 --> Database Driver Class Initialized
INFO - 2024-08-01 16:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 16:00:54 --> Controller Class Initialized
DEBUG - 2024-08-01 16:00:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-01 16:00:56 --> Config Class Initialized
INFO - 2024-08-01 16:00:56 --> Hooks Class Initialized
DEBUG - 2024-08-01 16:00:56 --> UTF-8 Support Enabled
INFO - 2024-08-01 16:00:56 --> Utf8 Class Initialized
INFO - 2024-08-01 16:00:56 --> URI Class Initialized
INFO - 2024-08-01 16:00:56 --> Router Class Initialized
INFO - 2024-08-01 16:00:56 --> Output Class Initialized
INFO - 2024-08-01 16:00:56 --> Security Class Initialized
DEBUG - 2024-08-01 16:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 16:00:56 --> Input Class Initialized
INFO - 2024-08-01 16:00:56 --> Language Class Initialized
INFO - 2024-08-01 16:00:56 --> Language Class Initialized
INFO - 2024-08-01 16:00:56 --> Config Class Initialized
INFO - 2024-08-01 16:00:56 --> Loader Class Initialized
INFO - 2024-08-01 16:00:56 --> Helper loaded: url_helper
INFO - 2024-08-01 16:00:56 --> Helper loaded: file_helper
INFO - 2024-08-01 16:00:56 --> Helper loaded: form_helper
INFO - 2024-08-01 16:00:56 --> Helper loaded: my_helper
INFO - 2024-08-01 16:00:56 --> Database Driver Class Initialized
INFO - 2024-08-01 16:00:58 --> Config Class Initialized
INFO - 2024-08-01 16:00:58 --> Hooks Class Initialized
DEBUG - 2024-08-01 16:00:58 --> UTF-8 Support Enabled
INFO - 2024-08-01 16:00:58 --> Utf8 Class Initialized
INFO - 2024-08-01 16:00:58 --> URI Class Initialized
INFO - 2024-08-01 16:00:58 --> Router Class Initialized
INFO - 2024-08-01 16:00:58 --> Output Class Initialized
INFO - 2024-08-01 16:00:58 --> Security Class Initialized
DEBUG - 2024-08-01 16:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 16:00:58 --> Input Class Initialized
INFO - 2024-08-01 16:00:58 --> Language Class Initialized
INFO - 2024-08-01 16:00:58 --> Language Class Initialized
INFO - 2024-08-01 16:00:58 --> Config Class Initialized
INFO - 2024-08-01 16:00:58 --> Loader Class Initialized
INFO - 2024-08-01 16:00:58 --> Helper loaded: url_helper
INFO - 2024-08-01 16:00:58 --> Helper loaded: file_helper
INFO - 2024-08-01 16:00:58 --> Helper loaded: form_helper
INFO - 2024-08-01 16:00:58 --> Helper loaded: my_helper
INFO - 2024-08-01 16:00:58 --> Database Driver Class Initialized
INFO - 2024-08-01 16:00:59 --> Final output sent to browser
DEBUG - 2024-08-01 16:00:59 --> Total execution time: 4.4025
INFO - 2024-08-01 16:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 16:00:59 --> Controller Class Initialized
ERROR - 2024-08-01 16:00:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1797
ERROR - 2024-08-01 16:00:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1804
ERROR - 2024-08-01 16:00:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-08-01 16:00:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-08-01 16:00:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-08-01 16:00:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 86
ERROR - 2024-08-01 16:00:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-08-01 16:00:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-08-01 16:00:59 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-08-01 16:00:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-08-01 16:00:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-08-01 16:00:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-08-01 16:00:59 --> Config Class Initialized
INFO - 2024-08-01 16:00:59 --> Hooks Class Initialized
DEBUG - 2024-08-01 16:00:59 --> UTF-8 Support Enabled
INFO - 2024-08-01 16:00:59 --> Utf8 Class Initialized
INFO - 2024-08-01 16:00:59 --> URI Class Initialized
INFO - 2024-08-01 16:00:59 --> Router Class Initialized
INFO - 2024-08-01 16:00:59 --> Output Class Initialized
INFO - 2024-08-01 16:00:59 --> Security Class Initialized
DEBUG - 2024-08-01 16:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 16:00:59 --> Input Class Initialized
INFO - 2024-08-01 16:00:59 --> Language Class Initialized
INFO - 2024-08-01 16:00:59 --> Language Class Initialized
INFO - 2024-08-01 16:00:59 --> Config Class Initialized
INFO - 2024-08-01 16:00:59 --> Loader Class Initialized
INFO - 2024-08-01 16:00:59 --> Helper loaded: url_helper
INFO - 2024-08-01 16:00:59 --> Helper loaded: file_helper
INFO - 2024-08-01 16:00:59 --> Helper loaded: form_helper
INFO - 2024-08-01 16:00:59 --> Helper loaded: my_helper
INFO - 2024-08-01 16:00:59 --> Database Driver Class Initialized
INFO - 2024-08-01 16:01:01 --> Config Class Initialized
INFO - 2024-08-01 16:01:01 --> Hooks Class Initialized
DEBUG - 2024-08-01 16:01:01 --> UTF-8 Support Enabled
INFO - 2024-08-01 16:01:01 --> Utf8 Class Initialized
INFO - 2024-08-01 16:01:01 --> URI Class Initialized
INFO - 2024-08-01 16:01:01 --> Router Class Initialized
INFO - 2024-08-01 16:01:01 --> Output Class Initialized
INFO - 2024-08-01 16:01:01 --> Security Class Initialized
DEBUG - 2024-08-01 16:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 16:01:01 --> Input Class Initialized
INFO - 2024-08-01 16:01:01 --> Language Class Initialized
INFO - 2024-08-01 16:01:01 --> Language Class Initialized
INFO - 2024-08-01 16:01:01 --> Config Class Initialized
INFO - 2024-08-01 16:01:01 --> Loader Class Initialized
INFO - 2024-08-01 16:01:01 --> Helper loaded: url_helper
INFO - 2024-08-01 16:01:01 --> Helper loaded: file_helper
INFO - 2024-08-01 16:01:01 --> Helper loaded: form_helper
INFO - 2024-08-01 16:01:01 --> Helper loaded: my_helper
INFO - 2024-08-01 16:01:01 --> Database Driver Class Initialized
ERROR - 2024-08-01 16:01:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
ERROR - 2024-08-01 16:01:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
INFO - 2024-08-01 16:01:03 --> Final output sent to browser
DEBUG - 2024-08-01 16:01:03 --> Total execution time: 6.9304
INFO - 2024-08-01 16:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 16:01:03 --> Controller Class Initialized
ERROR - 2024-08-01 16:01:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2591
ERROR - 2024-08-01 16:01:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3156
ERROR - 2024-08-01 16:01:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3194
ERROR - 2024-08-01 16:01:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3232
ERROR - 2024-08-01 16:01:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3271
ERROR - 2024-08-01 16:01:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3388
ERROR - 2024-08-01 16:01:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3507
ERROR - 2024-08-01 16:01:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3626
ERROR - 2024-08-01 16:01:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3745
ERROR - 2024-08-01 16:01:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-08-01 16:01:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-08-01 16:01:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 40
ERROR - 2024-08-01 16:01:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-08-01 16:01:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-08-01 16:01:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
ERROR - 2024-08-01 16:01:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
DEBUG - 2024-08-01 16:01:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-01 16:02:26 --> Config Class Initialized
INFO - 2024-08-01 16:02:26 --> Hooks Class Initialized
DEBUG - 2024-08-01 16:02:26 --> UTF-8 Support Enabled
INFO - 2024-08-01 16:02:26 --> Utf8 Class Initialized
INFO - 2024-08-01 16:02:26 --> URI Class Initialized
INFO - 2024-08-01 16:02:26 --> Router Class Initialized
INFO - 2024-08-01 16:02:26 --> Output Class Initialized
INFO - 2024-08-01 16:02:26 --> Security Class Initialized
DEBUG - 2024-08-01 16:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 16:02:26 --> Input Class Initialized
INFO - 2024-08-01 16:02:26 --> Language Class Initialized
INFO - 2024-08-01 16:02:26 --> Language Class Initialized
INFO - 2024-08-01 16:02:26 --> Config Class Initialized
INFO - 2024-08-01 16:02:26 --> Loader Class Initialized
INFO - 2024-08-01 16:02:26 --> Helper loaded: url_helper
INFO - 2024-08-01 16:02:26 --> Helper loaded: file_helper
INFO - 2024-08-01 16:02:26 --> Helper loaded: form_helper
INFO - 2024-08-01 16:02:26 --> Helper loaded: my_helper
INFO - 2024-08-01 16:02:26 --> Database Driver Class Initialized
INFO - 2024-08-01 16:02:28 --> Config Class Initialized
INFO - 2024-08-01 16:02:28 --> Hooks Class Initialized
DEBUG - 2024-08-01 16:02:28 --> UTF-8 Support Enabled
INFO - 2024-08-01 16:02:28 --> Utf8 Class Initialized
INFO - 2024-08-01 16:02:28 --> URI Class Initialized
INFO - 2024-08-01 16:02:28 --> Router Class Initialized
INFO - 2024-08-01 16:02:28 --> Output Class Initialized
INFO - 2024-08-01 16:02:28 --> Security Class Initialized
DEBUG - 2024-08-01 16:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 16:02:28 --> Input Class Initialized
INFO - 2024-08-01 16:02:28 --> Language Class Initialized
INFO - 2024-08-01 16:02:28 --> Language Class Initialized
INFO - 2024-08-01 16:02:28 --> Config Class Initialized
INFO - 2024-08-01 16:02:28 --> Loader Class Initialized
INFO - 2024-08-01 16:02:28 --> Helper loaded: url_helper
INFO - 2024-08-01 16:02:28 --> Helper loaded: file_helper
INFO - 2024-08-01 16:02:28 --> Helper loaded: form_helper
INFO - 2024-08-01 16:02:28 --> Helper loaded: my_helper
INFO - 2024-08-01 16:02:28 --> Database Driver Class Initialized
INFO - 2024-08-01 16:04:24 --> Config Class Initialized
INFO - 2024-08-01 16:04:24 --> Hooks Class Initialized
INFO - 2024-08-01 16:04:24 --> Config Class Initialized
INFO - 2024-08-01 16:04:24 --> Hooks Class Initialized
INFO - 2024-08-01 16:04:24 --> Config Class Initialized
INFO - 2024-08-01 16:04:24 --> Hooks Class Initialized
INFO - 2024-08-01 16:04:24 --> Config Class Initialized
INFO - 2024-08-01 16:04:24 --> Hooks Class Initialized
INFO - 2024-08-01 16:04:24 --> Config Class Initialized
INFO - 2024-08-01 16:04:24 --> Hooks Class Initialized
INFO - 2024-08-01 16:04:24 --> Config Class Initialized
INFO - 2024-08-01 16:04:24 --> Hooks Class Initialized
DEBUG - 2024-08-01 16:04:24 --> UTF-8 Support Enabled
INFO - 2024-08-01 16:04:24 --> Utf8 Class Initialized
DEBUG - 2024-08-01 16:04:24 --> UTF-8 Support Enabled
INFO - 2024-08-01 16:04:24 --> Utf8 Class Initialized
INFO - 2024-08-01 16:04:24 --> URI Class Initialized
DEBUG - 2024-08-01 16:04:24 --> UTF-8 Support Enabled
INFO - 2024-08-01 16:04:24 --> Utf8 Class Initialized
INFO - 2024-08-01 16:04:24 --> URI Class Initialized
DEBUG - 2024-08-01 16:04:24 --> UTF-8 Support Enabled
INFO - 2024-08-01 16:04:24 --> Utf8 Class Initialized
INFO - 2024-08-01 16:04:24 --> URI Class Initialized
DEBUG - 2024-08-01 16:04:24 --> UTF-8 Support Enabled
INFO - 2024-08-01 16:04:24 --> Utf8 Class Initialized
INFO - 2024-08-01 16:04:24 --> URI Class Initialized
DEBUG - 2024-08-01 16:04:24 --> UTF-8 Support Enabled
INFO - 2024-08-01 16:04:24 --> Utf8 Class Initialized
INFO - 2024-08-01 16:04:24 --> URI Class Initialized
INFO - 2024-08-01 16:04:24 --> URI Class Initialized
INFO - 2024-08-01 16:04:24 --> Router Class Initialized
INFO - 2024-08-01 16:04:24 --> Router Class Initialized
INFO - 2024-08-01 16:04:24 --> Router Class Initialized
INFO - 2024-08-01 16:04:24 --> Output Class Initialized
INFO - 2024-08-01 16:04:24 --> Router Class Initialized
INFO - 2024-08-01 16:04:24 --> Output Class Initialized
INFO - 2024-08-01 16:04:24 --> Security Class Initialized
INFO - 2024-08-01 16:04:24 --> Router Class Initialized
INFO - 2024-08-01 16:04:24 --> Output Class Initialized
INFO - 2024-08-01 16:04:24 --> Security Class Initialized
DEBUG - 2024-08-01 16:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 16:04:24 --> Input Class Initialized
INFO - 2024-08-01 16:04:24 --> Output Class Initialized
INFO - 2024-08-01 16:04:24 --> Security Class Initialized
DEBUG - 2024-08-01 16:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 16:04:24 --> Input Class Initialized
INFO - 2024-08-01 16:04:24 --> Language Class Initialized
INFO - 2024-08-01 16:04:24 --> Router Class Initialized
INFO - 2024-08-01 16:04:24 --> Output Class Initialized
INFO - 2024-08-01 16:04:24 --> Security Class Initialized
DEBUG - 2024-08-01 16:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 16:04:24 --> Input Class Initialized
INFO - 2024-08-01 16:04:24 --> Language Class Initialized
INFO - 2024-08-01 16:04:24 --> Output Class Initialized
INFO - 2024-08-01 16:04:24 --> Security Class Initialized
DEBUG - 2024-08-01 16:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 16:04:24 --> Input Class Initialized
INFO - 2024-08-01 16:04:24 --> Language Class Initialized
INFO - 2024-08-01 16:04:24 --> Security Class Initialized
DEBUG - 2024-08-01 16:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 16:04:24 --> Input Class Initialized
INFO - 2024-08-01 16:04:24 --> Language Class Initialized
DEBUG - 2024-08-01 16:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 16:04:24 --> Input Class Initialized
INFO - 2024-08-01 16:04:24 --> Language Class Initialized
INFO - 2024-08-01 16:04:24 --> Language Class Initialized
INFO - 2024-08-01 16:04:24 --> Language Class Initialized
INFO - 2024-08-01 16:04:24 --> Config Class Initialized
INFO - 2024-08-01 16:04:24 --> Loader Class Initialized
INFO - 2024-08-01 16:04:24 --> Language Class Initialized
INFO - 2024-08-01 16:04:24 --> Config Class Initialized
INFO - 2024-08-01 16:04:24 --> Loader Class Initialized
INFO - 2024-08-01 16:04:24 --> Helper loaded: url_helper
INFO - 2024-08-01 16:04:24 --> Helper loaded: url_helper
INFO - 2024-08-01 16:04:24 --> Helper loaded: file_helper
INFO - 2024-08-01 16:04:24 --> Language Class Initialized
INFO - 2024-08-01 16:04:24 --> Config Class Initialized
INFO - 2024-08-01 16:04:24 --> Loader Class Initialized
INFO - 2024-08-01 16:04:24 --> Helper loaded: url_helper
INFO - 2024-08-01 16:04:24 --> Helper loaded: file_helper
INFO - 2024-08-01 16:04:24 --> Helper loaded: form_helper
INFO - 2024-08-01 16:04:24 --> Helper loaded: form_helper
INFO - 2024-08-01 16:04:24 --> Helper loaded: my_helper
INFO - 2024-08-01 16:04:24 --> Language Class Initialized
INFO - 2024-08-01 16:04:24 --> Config Class Initialized
INFO - 2024-08-01 16:04:24 --> Loader Class Initialized
INFO - 2024-08-01 16:04:24 --> Helper loaded: url_helper
INFO - 2024-08-01 16:04:24 --> Helper loaded: file_helper
INFO - 2024-08-01 16:04:24 --> Helper loaded: form_helper
INFO - 2024-08-01 16:04:24 --> Helper loaded: my_helper
INFO - 2024-08-01 16:04:24 --> Language Class Initialized
INFO - 2024-08-01 16:04:24 --> Config Class Initialized
INFO - 2024-08-01 16:04:24 --> Loader Class Initialized
INFO - 2024-08-01 16:04:24 --> Helper loaded: url_helper
INFO - 2024-08-01 16:04:24 --> Helper loaded: file_helper
INFO - 2024-08-01 16:04:24 --> Helper loaded: form_helper
INFO - 2024-08-01 16:04:24 --> Helper loaded: my_helper
INFO - 2024-08-01 16:04:24 --> Language Class Initialized
INFO - 2024-08-01 16:04:24 --> Config Class Initialized
INFO - 2024-08-01 16:04:24 --> Loader Class Initialized
INFO - 2024-08-01 16:04:24 --> Helper loaded: url_helper
INFO - 2024-08-01 16:04:24 --> Helper loaded: file_helper
INFO - 2024-08-01 16:04:24 --> Helper loaded: form_helper
INFO - 2024-08-01 16:04:24 --> Helper loaded: my_helper
INFO - 2024-08-01 16:04:24 --> Helper loaded: file_helper
INFO - 2024-08-01 16:04:24 --> Helper loaded: form_helper
INFO - 2024-08-01 16:04:24 --> Helper loaded: my_helper
INFO - 2024-08-01 16:04:24 --> Helper loaded: my_helper
INFO - 2024-08-01 16:04:24 --> Database Driver Class Initialized
INFO - 2024-08-01 16:04:24 --> Database Driver Class Initialized
INFO - 2024-08-01 16:04:24 --> Database Driver Class Initialized
INFO - 2024-08-01 16:04:24 --> Database Driver Class Initialized
INFO - 2024-08-01 16:04:24 --> Database Driver Class Initialized
INFO - 2024-08-01 16:04:24 --> Database Driver Class Initialized
INFO - 2024-08-01 16:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 16:04:30 --> Controller Class Initialized
ERROR - 2024-08-01 16:04:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-08-01 16:04:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-01 16:04:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-01 16:04:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-08-01 16:04:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-01 16:04:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-01 16:04:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-08-01 16:04:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-08-01 16:04:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-01 16:04:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-01 16:04:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-08-01 16:04:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-01 16:04:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-01 16:04:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-08-01 16:04:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-01 16:04:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-01 16:04:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-08-01 16:04:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-08-01 16:04:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-08-01 16:04:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-08-01 16:04:33 --> Final output sent to browser
DEBUG - 2024-08-01 16:04:33 --> Total execution time: 213.4735
INFO - 2024-08-01 16:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 16:04:33 --> Controller Class Initialized
INFO - 2024-08-01 16:04:33 --> Config Class Initialized
INFO - 2024-08-01 16:04:33 --> Hooks Class Initialized
DEBUG - 2024-08-01 16:04:33 --> UTF-8 Support Enabled
INFO - 2024-08-01 16:04:33 --> Utf8 Class Initialized
INFO - 2024-08-01 16:04:33 --> URI Class Initialized
INFO - 2024-08-01 16:04:33 --> Router Class Initialized
INFO - 2024-08-01 16:04:33 --> Output Class Initialized
ERROR - 2024-08-01 16:04:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-01 16:04:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-01 16:04:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-01 16:04:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-01 16:04:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-01 16:04:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-01 16:04:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-01 16:04:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-01 16:04:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-01 16:04:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-01 16:04:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-01 16:04:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-01 16:04:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-01 16:04:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 16:04:33 --> Security Class Initialized
DEBUG - 2024-08-01 16:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 16:04:33 --> Input Class Initialized
INFO - 2024-08-01 16:04:33 --> Language Class Initialized
INFO - 2024-08-01 16:04:33 --> Language Class Initialized
INFO - 2024-08-01 16:04:33 --> Config Class Initialized
INFO - 2024-08-01 16:04:33 --> Loader Class Initialized
INFO - 2024-08-01 16:04:33 --> Helper loaded: url_helper
INFO - 2024-08-01 16:04:33 --> Helper loaded: file_helper
INFO - 2024-08-01 16:04:33 --> Helper loaded: form_helper
INFO - 2024-08-01 16:04:33 --> Helper loaded: my_helper
INFO - 2024-08-01 16:04:33 --> Database Driver Class Initialized
INFO - 2024-08-01 16:04:36 --> Final output sent to browser
DEBUG - 2024-08-01 16:04:36 --> Total execution time: 215.1913
INFO - 2024-08-01 16:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 16:04:36 --> Controller Class Initialized
INFO - 2024-08-01 16:04:36 --> Config Class Initialized
INFO - 2024-08-01 16:04:36 --> Hooks Class Initialized
DEBUG - 2024-08-01 16:04:36 --> UTF-8 Support Enabled
INFO - 2024-08-01 16:04:36 --> Utf8 Class Initialized
INFO - 2024-08-01 16:04:36 --> URI Class Initialized
INFO - 2024-08-01 16:04:36 --> Router Class Initialized
INFO - 2024-08-01 16:04:36 --> Output Class Initialized
ERROR - 2024-08-01 16:04:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-01 16:04:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-01 16:04:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-01 16:04:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-01 16:04:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-01 16:04:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-01 16:04:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-01 16:04:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-01 16:04:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-01 16:04:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-01 16:04:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-01 16:04:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-01 16:04:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-01 16:04:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 16:04:36 --> Security Class Initialized
DEBUG - 2024-08-01 16:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 16:04:36 --> Input Class Initialized
INFO - 2024-08-01 16:04:36 --> Language Class Initialized
INFO - 2024-08-01 16:04:36 --> Language Class Initialized
INFO - 2024-08-01 16:04:36 --> Config Class Initialized
INFO - 2024-08-01 16:04:36 --> Loader Class Initialized
INFO - 2024-08-01 16:04:36 --> Helper loaded: url_helper
INFO - 2024-08-01 16:04:36 --> Helper loaded: file_helper
INFO - 2024-08-01 16:04:36 --> Helper loaded: form_helper
INFO - 2024-08-01 16:04:36 --> Helper loaded: my_helper
INFO - 2024-08-01 16:04:36 --> Database Driver Class Initialized
INFO - 2024-08-01 16:04:39 --> Final output sent to browser
DEBUG - 2024-08-01 16:04:39 --> Total execution time: 132.7154
INFO - 2024-08-01 16:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 16:04:39 --> Controller Class Initialized
ERROR - 2024-08-01 16:04:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-08-01 16:04:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-01 16:04:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-01 16:04:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-08-01 16:04:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-01 16:04:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-01 16:04:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-08-01 16:04:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-08-01 16:04:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-01 16:04:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-01 16:04:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-08-01 16:04:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-01 16:04:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-01 16:04:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
INFO - 2024-08-01 16:04:39 --> Config Class Initialized
INFO - 2024-08-01 16:04:39 --> Hooks Class Initialized
DEBUG - 2024-08-01 16:04:39 --> UTF-8 Support Enabled
INFO - 2024-08-01 16:04:39 --> Utf8 Class Initialized
INFO - 2024-08-01 16:04:39 --> URI Class Initialized
INFO - 2024-08-01 16:04:39 --> Router Class Initialized
INFO - 2024-08-01 16:04:39 --> Output Class Initialized
ERROR - 2024-08-01 16:04:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-01 16:04:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-01 16:04:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-08-01 16:04:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-08-01 16:04:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-08-01 16:04:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-08-01 16:04:39 --> Security Class Initialized
DEBUG - 2024-08-01 16:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 16:04:39 --> Input Class Initialized
INFO - 2024-08-01 16:04:39 --> Language Class Initialized
INFO - 2024-08-01 16:04:39 --> Language Class Initialized
INFO - 2024-08-01 16:04:39 --> Config Class Initialized
INFO - 2024-08-01 16:04:39 --> Loader Class Initialized
INFO - 2024-08-01 16:04:39 --> Helper loaded: url_helper
INFO - 2024-08-01 16:04:39 --> Helper loaded: file_helper
INFO - 2024-08-01 16:04:39 --> Helper loaded: form_helper
INFO - 2024-08-01 16:04:39 --> Helper loaded: my_helper
INFO - 2024-08-01 16:04:39 --> Database Driver Class Initialized
INFO - 2024-08-01 16:04:41 --> Final output sent to browser
DEBUG - 2024-08-01 16:04:41 --> Total execution time: 133.0569
INFO - 2024-08-01 16:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 16:04:41 --> Controller Class Initialized
DEBUG - 2024-08-01 16:04:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-01 16:04:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 16:04:41 --> Final output sent to browser
DEBUG - 2024-08-01 16:04:41 --> Total execution time: 17.6315
INFO - 2024-08-01 16:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 16:04:41 --> Controller Class Initialized
DEBUG - 2024-08-01 16:04:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-01 16:05:09 --> Config Class Initialized
INFO - 2024-08-01 16:05:09 --> Hooks Class Initialized
DEBUG - 2024-08-01 16:05:09 --> UTF-8 Support Enabled
INFO - 2024-08-01 16:05:09 --> Utf8 Class Initialized
INFO - 2024-08-01 16:05:09 --> URI Class Initialized
INFO - 2024-08-01 16:05:09 --> Router Class Initialized
INFO - 2024-08-01 16:05:09 --> Output Class Initialized
INFO - 2024-08-01 16:05:09 --> Security Class Initialized
DEBUG - 2024-08-01 16:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 16:05:09 --> Input Class Initialized
INFO - 2024-08-01 16:05:09 --> Language Class Initialized
INFO - 2024-08-01 16:05:09 --> Language Class Initialized
INFO - 2024-08-01 16:05:09 --> Config Class Initialized
INFO - 2024-08-01 16:05:09 --> Loader Class Initialized
INFO - 2024-08-01 16:05:09 --> Helper loaded: url_helper
INFO - 2024-08-01 16:05:09 --> Helper loaded: file_helper
INFO - 2024-08-01 16:05:09 --> Helper loaded: form_helper
INFO - 2024-08-01 16:05:09 --> Helper loaded: my_helper
INFO - 2024-08-01 16:05:09 --> Database Driver Class Initialized
INFO - 2024-08-01 16:05:11 --> Config Class Initialized
INFO - 2024-08-01 16:05:11 --> Hooks Class Initialized
DEBUG - 2024-08-01 16:05:11 --> UTF-8 Support Enabled
INFO - 2024-08-01 16:05:11 --> Utf8 Class Initialized
INFO - 2024-08-01 16:05:11 --> URI Class Initialized
INFO - 2024-08-01 16:05:11 --> Router Class Initialized
INFO - 2024-08-01 16:05:11 --> Output Class Initialized
INFO - 2024-08-01 16:05:11 --> Security Class Initialized
DEBUG - 2024-08-01 16:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 16:05:11 --> Input Class Initialized
INFO - 2024-08-01 16:05:11 --> Language Class Initialized
INFO - 2024-08-01 16:05:11 --> Language Class Initialized
INFO - 2024-08-01 16:05:11 --> Config Class Initialized
INFO - 2024-08-01 16:05:11 --> Loader Class Initialized
INFO - 2024-08-01 16:05:11 --> Helper loaded: url_helper
INFO - 2024-08-01 16:05:11 --> Helper loaded: file_helper
INFO - 2024-08-01 16:05:11 --> Helper loaded: form_helper
INFO - 2024-08-01 16:05:11 --> Helper loaded: my_helper
INFO - 2024-08-01 16:05:11 --> Database Driver Class Initialized
INFO - 2024-08-01 16:05:13 --> Config Class Initialized
INFO - 2024-08-01 16:05:13 --> Hooks Class Initialized
DEBUG - 2024-08-01 16:05:13 --> UTF-8 Support Enabled
INFO - 2024-08-01 16:05:13 --> Utf8 Class Initialized
INFO - 2024-08-01 16:05:13 --> URI Class Initialized
INFO - 2024-08-01 16:05:13 --> Router Class Initialized
INFO - 2024-08-01 16:05:13 --> Output Class Initialized
INFO - 2024-08-01 16:05:13 --> Security Class Initialized
DEBUG - 2024-08-01 16:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 16:05:13 --> Input Class Initialized
INFO - 2024-08-01 16:05:13 --> Language Class Initialized
INFO - 2024-08-01 16:05:13 --> Language Class Initialized
INFO - 2024-08-01 16:05:13 --> Config Class Initialized
INFO - 2024-08-01 16:05:13 --> Loader Class Initialized
INFO - 2024-08-01 16:05:13 --> Helper loaded: url_helper
INFO - 2024-08-01 16:05:13 --> Helper loaded: file_helper
INFO - 2024-08-01 16:05:13 --> Helper loaded: form_helper
INFO - 2024-08-01 16:05:13 --> Helper loaded: my_helper
INFO - 2024-08-01 16:05:13 --> Database Driver Class Initialized
INFO - 2024-08-01 16:05:16 --> Config Class Initialized
INFO - 2024-08-01 16:05:16 --> Hooks Class Initialized
DEBUG - 2024-08-01 16:05:16 --> UTF-8 Support Enabled
INFO - 2024-08-01 16:05:16 --> Utf8 Class Initialized
INFO - 2024-08-01 16:05:16 --> URI Class Initialized
INFO - 2024-08-01 16:05:16 --> Router Class Initialized
INFO - 2024-08-01 16:05:16 --> Output Class Initialized
INFO - 2024-08-01 16:05:16 --> Security Class Initialized
DEBUG - 2024-08-01 16:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 16:05:16 --> Input Class Initialized
INFO - 2024-08-01 16:05:16 --> Language Class Initialized
INFO - 2024-08-01 16:05:16 --> Language Class Initialized
INFO - 2024-08-01 16:05:16 --> Config Class Initialized
INFO - 2024-08-01 16:05:16 --> Loader Class Initialized
INFO - 2024-08-01 16:05:16 --> Helper loaded: url_helper
INFO - 2024-08-01 16:05:16 --> Helper loaded: file_helper
INFO - 2024-08-01 16:05:16 --> Helper loaded: form_helper
INFO - 2024-08-01 16:05:16 --> Helper loaded: my_helper
INFO - 2024-08-01 16:05:16 --> Database Driver Class Initialized
INFO - 2024-08-01 16:05:18 --> Config Class Initialized
INFO - 2024-08-01 16:05:18 --> Hooks Class Initialized
DEBUG - 2024-08-01 16:05:18 --> UTF-8 Support Enabled
INFO - 2024-08-01 16:05:18 --> Utf8 Class Initialized
INFO - 2024-08-01 16:05:18 --> URI Class Initialized
INFO - 2024-08-01 16:05:18 --> Router Class Initialized
INFO - 2024-08-01 16:05:18 --> Output Class Initialized
INFO - 2024-08-01 16:05:18 --> Security Class Initialized
DEBUG - 2024-08-01 16:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 16:05:18 --> Input Class Initialized
INFO - 2024-08-01 16:05:18 --> Language Class Initialized
INFO - 2024-08-01 16:05:18 --> Language Class Initialized
INFO - 2024-08-01 16:05:18 --> Config Class Initialized
INFO - 2024-08-01 16:05:18 --> Loader Class Initialized
INFO - 2024-08-01 16:05:18 --> Helper loaded: url_helper
INFO - 2024-08-01 16:05:18 --> Helper loaded: file_helper
INFO - 2024-08-01 16:05:18 --> Helper loaded: form_helper
INFO - 2024-08-01 16:05:18 --> Helper loaded: my_helper
INFO - 2024-08-01 16:05:18 --> Database Driver Class Initialized
INFO - 2024-08-01 16:06:14 --> Config Class Initialized
INFO - 2024-08-01 16:06:14 --> Hooks Class Initialized
DEBUG - 2024-08-01 16:06:14 --> UTF-8 Support Enabled
INFO - 2024-08-01 16:06:14 --> Utf8 Class Initialized
INFO - 2024-08-01 16:06:14 --> URI Class Initialized
INFO - 2024-08-01 16:06:14 --> Router Class Initialized
INFO - 2024-08-01 16:06:14 --> Output Class Initialized
INFO - 2024-08-01 16:06:14 --> Security Class Initialized
DEBUG - 2024-08-01 16:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 16:06:14 --> Input Class Initialized
INFO - 2024-08-01 16:06:14 --> Language Class Initialized
INFO - 2024-08-01 16:06:14 --> Language Class Initialized
INFO - 2024-08-01 16:06:14 --> Config Class Initialized
INFO - 2024-08-01 16:06:14 --> Loader Class Initialized
INFO - 2024-08-01 16:06:14 --> Helper loaded: url_helper
INFO - 2024-08-01 16:06:14 --> Helper loaded: file_helper
INFO - 2024-08-01 16:06:14 --> Helper loaded: form_helper
INFO - 2024-08-01 16:06:14 --> Helper loaded: my_helper
INFO - 2024-08-01 16:06:14 --> Database Driver Class Initialized
INFO - 2024-08-01 16:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 16:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 16:13:01 --> Controller Class Initialized
INFO - 2024-08-01 16:13:01 --> Controller Class Initialized
ERROR - 2024-08-01 16:13:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1797
ERROR - 2024-08-01 16:13:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1804
DEBUG - 2024-08-01 16:13:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-01 16:13:01 --> Config Class Initialized
INFO - 2024-08-01 16:13:01 --> Hooks Class Initialized
ERROR - 2024-08-01 16:13:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-08-01 16:13:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-08-01 16:13:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-08-01 16:13:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 86
ERROR - 2024-08-01 16:13:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-08-01 16:13:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-08-01 16:13:01 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-08-01 16:13:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-08-01 16:13:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-08-01 16:13:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
DEBUG - 2024-08-01 16:13:01 --> UTF-8 Support Enabled
INFO - 2024-08-01 16:13:01 --> Utf8 Class Initialized
INFO - 2024-08-01 16:13:01 --> URI Class Initialized
INFO - 2024-08-01 16:13:01 --> Router Class Initialized
INFO - 2024-08-01 16:13:01 --> Output Class Initialized
INFO - 2024-08-01 16:13:01 --> Security Class Initialized
DEBUG - 2024-08-01 16:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 16:13:01 --> Input Class Initialized
INFO - 2024-08-01 16:13:01 --> Language Class Initialized
INFO - 2024-08-01 16:13:01 --> Language Class Initialized
INFO - 2024-08-01 16:13:01 --> Config Class Initialized
INFO - 2024-08-01 16:13:01 --> Loader Class Initialized
INFO - 2024-08-01 16:13:01 --> Helper loaded: url_helper
INFO - 2024-08-01 16:13:01 --> Helper loaded: file_helper
INFO - 2024-08-01 16:13:01 --> Helper loaded: form_helper
INFO - 2024-08-01 16:13:01 --> Helper loaded: my_helper
INFO - 2024-08-01 16:13:01 --> Database Driver Class Initialized
ERROR - 2024-08-01 16:13:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
ERROR - 2024-08-01 16:13:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
INFO - 2024-08-01 16:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 16:13:08 --> Controller Class Initialized
ERROR - 2024-08-01 16:13:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-01 16:13:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-01 16:13:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-01 16:13:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-01 16:13:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-01 16:13:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-01 16:13:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-01 16:13:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-01 16:13:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-01 16:13:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-01 16:13:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-01 16:13:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-01 16:13:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-01 16:13:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 16:13:11 --> Final output sent to browser
DEBUG - 2024-08-01 16:13:11 --> Total execution time: 472.4717
INFO - 2024-08-01 16:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 16:13:11 --> Controller Class Initialized
DEBUG - 2024-08-01 16:13:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-01 16:13:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 16:13:11 --> Final output sent to browser
DEBUG - 2024-08-01 16:13:11 --> Total execution time: 417.3905
INFO - 2024-08-01 16:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 16:13:11 --> Controller Class Initialized
ERROR - 2024-08-01 16:13:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2591
ERROR - 2024-08-01 16:13:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3156
ERROR - 2024-08-01 16:13:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3194
ERROR - 2024-08-01 16:13:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3232
ERROR - 2024-08-01 16:13:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3271
ERROR - 2024-08-01 16:13:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3388
ERROR - 2024-08-01 16:13:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3507
ERROR - 2024-08-01 16:13:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3626
ERROR - 2024-08-01 16:13:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3745
ERROR - 2024-08-01 16:13:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-08-01 16:13:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-08-01 16:13:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 40
ERROR - 2024-08-01 16:13:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-08-01 16:13:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-08-01 16:13:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
ERROR - 2024-08-01 16:13:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
DEBUG - 2024-08-01 16:13:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-01 16:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 16:13:41 --> Controller Class Initialized
DEBUG - 2024-08-01 16:13:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-01 16:13:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 16:13:41 --> Final output sent to browser
DEBUG - 2024-08-01 16:13:41 --> Total execution time: 39.9986
INFO - 2024-08-01 16:19:34 --> Config Class Initialized
INFO - 2024-08-01 16:19:34 --> Hooks Class Initialized
DEBUG - 2024-08-01 16:19:34 --> UTF-8 Support Enabled
INFO - 2024-08-01 16:19:34 --> Utf8 Class Initialized
INFO - 2024-08-01 16:19:34 --> URI Class Initialized
INFO - 2024-08-01 16:19:34 --> Router Class Initialized
INFO - 2024-08-01 16:19:34 --> Output Class Initialized
INFO - 2024-08-01 16:19:34 --> Security Class Initialized
DEBUG - 2024-08-01 16:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 16:19:34 --> Input Class Initialized
INFO - 2024-08-01 16:19:34 --> Language Class Initialized
INFO - 2024-08-01 16:19:34 --> Language Class Initialized
INFO - 2024-08-01 16:19:34 --> Config Class Initialized
INFO - 2024-08-01 16:19:34 --> Loader Class Initialized
INFO - 2024-08-01 16:19:34 --> Helper loaded: url_helper
INFO - 2024-08-01 16:19:34 --> Helper loaded: file_helper
INFO - 2024-08-01 16:19:34 --> Helper loaded: form_helper
INFO - 2024-08-01 16:19:34 --> Helper loaded: my_helper
INFO - 2024-08-01 16:19:34 --> Database Driver Class Initialized
INFO - 2024-08-01 16:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 16:19:34 --> Controller Class Initialized
DEBUG - 2024-08-01 16:19:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-08-01 16:19:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 16:19:34 --> Final output sent to browser
DEBUG - 2024-08-01 16:19:34 --> Total execution time: 0.0303
INFO - 2024-08-01 16:19:34 --> Config Class Initialized
INFO - 2024-08-01 16:19:34 --> Hooks Class Initialized
DEBUG - 2024-08-01 16:19:34 --> UTF-8 Support Enabled
INFO - 2024-08-01 16:19:34 --> Utf8 Class Initialized
INFO - 2024-08-01 16:19:34 --> URI Class Initialized
INFO - 2024-08-01 16:19:34 --> Router Class Initialized
INFO - 2024-08-01 16:19:34 --> Output Class Initialized
INFO - 2024-08-01 16:19:34 --> Security Class Initialized
DEBUG - 2024-08-01 16:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 16:19:34 --> Input Class Initialized
INFO - 2024-08-01 16:19:34 --> Language Class Initialized
ERROR - 2024-08-01 16:19:34 --> 404 Page Not Found: /index
INFO - 2024-08-01 16:19:34 --> Config Class Initialized
INFO - 2024-08-01 16:19:34 --> Hooks Class Initialized
DEBUG - 2024-08-01 16:19:34 --> UTF-8 Support Enabled
INFO - 2024-08-01 16:19:34 --> Utf8 Class Initialized
INFO - 2024-08-01 16:19:34 --> URI Class Initialized
INFO - 2024-08-01 16:19:34 --> Router Class Initialized
INFO - 2024-08-01 16:19:34 --> Output Class Initialized
INFO - 2024-08-01 16:19:34 --> Security Class Initialized
DEBUG - 2024-08-01 16:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 16:19:34 --> Input Class Initialized
INFO - 2024-08-01 16:19:34 --> Language Class Initialized
INFO - 2024-08-01 16:19:34 --> Language Class Initialized
INFO - 2024-08-01 16:19:34 --> Config Class Initialized
INFO - 2024-08-01 16:19:34 --> Loader Class Initialized
INFO - 2024-08-01 16:19:34 --> Helper loaded: url_helper
INFO - 2024-08-01 16:19:34 --> Helper loaded: file_helper
INFO - 2024-08-01 16:19:34 --> Helper loaded: form_helper
INFO - 2024-08-01 16:19:34 --> Helper loaded: my_helper
INFO - 2024-08-01 16:19:34 --> Database Driver Class Initialized
INFO - 2024-08-01 16:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 16:19:34 --> Controller Class Initialized
INFO - 2024-08-01 16:31:26 --> Config Class Initialized
INFO - 2024-08-01 16:31:26 --> Hooks Class Initialized
DEBUG - 2024-08-01 16:31:26 --> UTF-8 Support Enabled
INFO - 2024-08-01 16:31:26 --> Utf8 Class Initialized
INFO - 2024-08-01 16:31:26 --> URI Class Initialized
INFO - 2024-08-01 16:31:26 --> Router Class Initialized
INFO - 2024-08-01 16:31:26 --> Output Class Initialized
INFO - 2024-08-01 16:31:26 --> Security Class Initialized
DEBUG - 2024-08-01 16:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 16:31:26 --> Input Class Initialized
INFO - 2024-08-01 16:31:26 --> Language Class Initialized
INFO - 2024-08-01 16:31:26 --> Language Class Initialized
INFO - 2024-08-01 16:31:26 --> Config Class Initialized
INFO - 2024-08-01 16:31:26 --> Loader Class Initialized
INFO - 2024-08-01 16:31:26 --> Helper loaded: url_helper
INFO - 2024-08-01 16:31:26 --> Helper loaded: file_helper
INFO - 2024-08-01 16:31:26 --> Helper loaded: form_helper
INFO - 2024-08-01 16:31:26 --> Helper loaded: my_helper
INFO - 2024-08-01 16:31:26 --> Database Driver Class Initialized
INFO - 2024-08-01 16:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 16:31:26 --> Controller Class Initialized
INFO - 2024-08-01 16:31:26 --> Helper loaded: cookie_helper
INFO - 2024-08-01 16:31:26 --> Config Class Initialized
INFO - 2024-08-01 16:31:26 --> Hooks Class Initialized
DEBUG - 2024-08-01 16:31:26 --> UTF-8 Support Enabled
INFO - 2024-08-01 16:31:26 --> Utf8 Class Initialized
INFO - 2024-08-01 16:31:26 --> URI Class Initialized
INFO - 2024-08-01 16:31:26 --> Router Class Initialized
INFO - 2024-08-01 16:31:26 --> Output Class Initialized
INFO - 2024-08-01 16:31:26 --> Security Class Initialized
DEBUG - 2024-08-01 16:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 16:31:26 --> Input Class Initialized
INFO - 2024-08-01 16:31:26 --> Language Class Initialized
INFO - 2024-08-01 16:31:26 --> Language Class Initialized
INFO - 2024-08-01 16:31:26 --> Config Class Initialized
INFO - 2024-08-01 16:31:26 --> Loader Class Initialized
INFO - 2024-08-01 16:31:26 --> Helper loaded: url_helper
INFO - 2024-08-01 16:31:26 --> Helper loaded: file_helper
INFO - 2024-08-01 16:31:26 --> Helper loaded: form_helper
INFO - 2024-08-01 16:31:26 --> Helper loaded: my_helper
INFO - 2024-08-01 16:31:26 --> Database Driver Class Initialized
INFO - 2024-08-01 16:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 16:31:26 --> Controller Class Initialized
INFO - 2024-08-01 16:31:26 --> Config Class Initialized
INFO - 2024-08-01 16:31:26 --> Hooks Class Initialized
DEBUG - 2024-08-01 16:31:26 --> UTF-8 Support Enabled
INFO - 2024-08-01 16:31:26 --> Utf8 Class Initialized
INFO - 2024-08-01 16:31:26 --> URI Class Initialized
INFO - 2024-08-01 16:31:26 --> Router Class Initialized
INFO - 2024-08-01 16:31:26 --> Output Class Initialized
INFO - 2024-08-01 16:31:26 --> Security Class Initialized
DEBUG - 2024-08-01 16:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 16:31:26 --> Input Class Initialized
INFO - 2024-08-01 16:31:26 --> Language Class Initialized
INFO - 2024-08-01 16:31:26 --> Language Class Initialized
INFO - 2024-08-01 16:31:26 --> Config Class Initialized
INFO - 2024-08-01 16:31:26 --> Loader Class Initialized
INFO - 2024-08-01 16:31:26 --> Helper loaded: url_helper
INFO - 2024-08-01 16:31:26 --> Helper loaded: file_helper
INFO - 2024-08-01 16:31:26 --> Helper loaded: form_helper
INFO - 2024-08-01 16:31:26 --> Helper loaded: my_helper
INFO - 2024-08-01 16:31:26 --> Database Driver Class Initialized
INFO - 2024-08-01 16:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 16:31:26 --> Controller Class Initialized
DEBUG - 2024-08-01 16:31:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-08-01 16:31:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 16:31:26 --> Final output sent to browser
DEBUG - 2024-08-01 16:31:26 --> Total execution time: 0.0398
INFO - 2024-08-01 17:27:44 --> Config Class Initialized
INFO - 2024-08-01 17:27:44 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:27:44 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:27:44 --> Utf8 Class Initialized
INFO - 2024-08-01 17:27:44 --> URI Class Initialized
DEBUG - 2024-08-01 17:27:44 --> No URI present. Default controller set.
INFO - 2024-08-01 17:27:44 --> Router Class Initialized
INFO - 2024-08-01 17:27:44 --> Output Class Initialized
INFO - 2024-08-01 17:27:44 --> Security Class Initialized
DEBUG - 2024-08-01 17:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:27:44 --> Input Class Initialized
INFO - 2024-08-01 17:27:44 --> Language Class Initialized
INFO - 2024-08-01 17:27:44 --> Language Class Initialized
INFO - 2024-08-01 17:27:44 --> Config Class Initialized
INFO - 2024-08-01 17:27:44 --> Loader Class Initialized
INFO - 2024-08-01 17:27:44 --> Helper loaded: url_helper
INFO - 2024-08-01 17:27:44 --> Helper loaded: file_helper
INFO - 2024-08-01 17:27:44 --> Helper loaded: form_helper
INFO - 2024-08-01 17:27:44 --> Helper loaded: my_helper
INFO - 2024-08-01 17:27:44 --> Database Driver Class Initialized
INFO - 2024-08-01 17:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:27:44 --> Controller Class Initialized
INFO - 2024-08-01 17:27:44 --> Config Class Initialized
INFO - 2024-08-01 17:27:44 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:27:44 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:27:44 --> Utf8 Class Initialized
INFO - 2024-08-01 17:27:44 --> URI Class Initialized
INFO - 2024-08-01 17:27:44 --> Router Class Initialized
INFO - 2024-08-01 17:27:44 --> Output Class Initialized
INFO - 2024-08-01 17:27:44 --> Security Class Initialized
DEBUG - 2024-08-01 17:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:27:44 --> Input Class Initialized
INFO - 2024-08-01 17:27:44 --> Language Class Initialized
INFO - 2024-08-01 17:27:44 --> Language Class Initialized
INFO - 2024-08-01 17:27:44 --> Config Class Initialized
INFO - 2024-08-01 17:27:44 --> Loader Class Initialized
INFO - 2024-08-01 17:27:44 --> Helper loaded: url_helper
INFO - 2024-08-01 17:27:44 --> Helper loaded: file_helper
INFO - 2024-08-01 17:27:44 --> Helper loaded: form_helper
INFO - 2024-08-01 17:27:44 --> Helper loaded: my_helper
INFO - 2024-08-01 17:27:44 --> Database Driver Class Initialized
INFO - 2024-08-01 17:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:27:44 --> Controller Class Initialized
DEBUG - 2024-08-01 17:27:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-08-01 17:27:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 17:27:44 --> Final output sent to browser
DEBUG - 2024-08-01 17:27:44 --> Total execution time: 0.0327
INFO - 2024-08-01 17:27:50 --> Config Class Initialized
INFO - 2024-08-01 17:27:50 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:27:50 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:27:50 --> Utf8 Class Initialized
INFO - 2024-08-01 17:27:50 --> URI Class Initialized
INFO - 2024-08-01 17:27:50 --> Router Class Initialized
INFO - 2024-08-01 17:27:50 --> Output Class Initialized
INFO - 2024-08-01 17:27:50 --> Security Class Initialized
DEBUG - 2024-08-01 17:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:27:50 --> Input Class Initialized
INFO - 2024-08-01 17:27:50 --> Language Class Initialized
INFO - 2024-08-01 17:27:50 --> Language Class Initialized
INFO - 2024-08-01 17:27:50 --> Config Class Initialized
INFO - 2024-08-01 17:27:50 --> Loader Class Initialized
INFO - 2024-08-01 17:27:50 --> Helper loaded: url_helper
INFO - 2024-08-01 17:27:50 --> Helper loaded: file_helper
INFO - 2024-08-01 17:27:50 --> Helper loaded: form_helper
INFO - 2024-08-01 17:27:50 --> Helper loaded: my_helper
INFO - 2024-08-01 17:27:50 --> Database Driver Class Initialized
INFO - 2024-08-01 17:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:27:50 --> Controller Class Initialized
INFO - 2024-08-01 17:27:50 --> Helper loaded: cookie_helper
INFO - 2024-08-01 17:27:50 --> Final output sent to browser
DEBUG - 2024-08-01 17:27:50 --> Total execution time: 0.0733
INFO - 2024-08-01 17:27:50 --> Config Class Initialized
INFO - 2024-08-01 17:27:50 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:27:50 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:27:50 --> Utf8 Class Initialized
INFO - 2024-08-01 17:27:50 --> URI Class Initialized
INFO - 2024-08-01 17:27:50 --> Router Class Initialized
INFO - 2024-08-01 17:27:50 --> Output Class Initialized
INFO - 2024-08-01 17:27:50 --> Security Class Initialized
DEBUG - 2024-08-01 17:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:27:50 --> Input Class Initialized
INFO - 2024-08-01 17:27:50 --> Language Class Initialized
INFO - 2024-08-01 17:27:50 --> Language Class Initialized
INFO - 2024-08-01 17:27:50 --> Config Class Initialized
INFO - 2024-08-01 17:27:50 --> Loader Class Initialized
INFO - 2024-08-01 17:27:50 --> Helper loaded: url_helper
INFO - 2024-08-01 17:27:50 --> Helper loaded: file_helper
INFO - 2024-08-01 17:27:50 --> Helper loaded: form_helper
INFO - 2024-08-01 17:27:50 --> Helper loaded: my_helper
INFO - 2024-08-01 17:27:50 --> Database Driver Class Initialized
INFO - 2024-08-01 17:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:27:50 --> Controller Class Initialized
DEBUG - 2024-08-01 17:27:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-08-01 17:27:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 17:27:50 --> Final output sent to browser
DEBUG - 2024-08-01 17:27:50 --> Total execution time: 0.0873
INFO - 2024-08-01 17:27:53 --> Config Class Initialized
INFO - 2024-08-01 17:27:53 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:27:53 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:27:53 --> Utf8 Class Initialized
INFO - 2024-08-01 17:27:53 --> URI Class Initialized
INFO - 2024-08-01 17:27:53 --> Router Class Initialized
INFO - 2024-08-01 17:27:53 --> Output Class Initialized
INFO - 2024-08-01 17:27:53 --> Security Class Initialized
DEBUG - 2024-08-01 17:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:27:53 --> Input Class Initialized
INFO - 2024-08-01 17:27:53 --> Language Class Initialized
INFO - 2024-08-01 17:27:53 --> Language Class Initialized
INFO - 2024-08-01 17:27:53 --> Config Class Initialized
INFO - 2024-08-01 17:27:53 --> Loader Class Initialized
INFO - 2024-08-01 17:27:53 --> Helper loaded: url_helper
INFO - 2024-08-01 17:27:53 --> Helper loaded: file_helper
INFO - 2024-08-01 17:27:53 --> Helper loaded: form_helper
INFO - 2024-08-01 17:27:53 --> Helper loaded: my_helper
INFO - 2024-08-01 17:27:53 --> Database Driver Class Initialized
INFO - 2024-08-01 17:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:27:53 --> Controller Class Initialized
DEBUG - 2024-08-01 17:27:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-08-01 17:27:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 17:27:53 --> Final output sent to browser
DEBUG - 2024-08-01 17:27:53 --> Total execution time: 0.0395
INFO - 2024-08-01 17:27:53 --> Config Class Initialized
INFO - 2024-08-01 17:27:53 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:27:53 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:27:53 --> Utf8 Class Initialized
INFO - 2024-08-01 17:27:53 --> URI Class Initialized
INFO - 2024-08-01 17:27:53 --> Router Class Initialized
INFO - 2024-08-01 17:27:53 --> Output Class Initialized
INFO - 2024-08-01 17:27:53 --> Security Class Initialized
DEBUG - 2024-08-01 17:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:27:53 --> Input Class Initialized
INFO - 2024-08-01 17:27:53 --> Language Class Initialized
ERROR - 2024-08-01 17:27:53 --> 404 Page Not Found: /index
INFO - 2024-08-01 17:27:53 --> Config Class Initialized
INFO - 2024-08-01 17:27:53 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:27:53 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:27:53 --> Utf8 Class Initialized
INFO - 2024-08-01 17:27:53 --> URI Class Initialized
INFO - 2024-08-01 17:27:53 --> Router Class Initialized
INFO - 2024-08-01 17:27:53 --> Output Class Initialized
INFO - 2024-08-01 17:27:53 --> Security Class Initialized
DEBUG - 2024-08-01 17:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:27:54 --> Input Class Initialized
INFO - 2024-08-01 17:27:54 --> Language Class Initialized
INFO - 2024-08-01 17:27:54 --> Language Class Initialized
INFO - 2024-08-01 17:27:54 --> Config Class Initialized
INFO - 2024-08-01 17:27:54 --> Loader Class Initialized
INFO - 2024-08-01 17:27:54 --> Helper loaded: url_helper
INFO - 2024-08-01 17:27:54 --> Helper loaded: file_helper
INFO - 2024-08-01 17:27:54 --> Helper loaded: form_helper
INFO - 2024-08-01 17:27:54 --> Helper loaded: my_helper
INFO - 2024-08-01 17:27:54 --> Database Driver Class Initialized
INFO - 2024-08-01 17:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:27:54 --> Controller Class Initialized
INFO - 2024-08-01 17:35:22 --> Config Class Initialized
INFO - 2024-08-01 17:35:22 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:35:22 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:35:22 --> Utf8 Class Initialized
INFO - 2024-08-01 17:35:22 --> URI Class Initialized
DEBUG - 2024-08-01 17:35:22 --> No URI present. Default controller set.
INFO - 2024-08-01 17:35:22 --> Router Class Initialized
INFO - 2024-08-01 17:35:22 --> Output Class Initialized
INFO - 2024-08-01 17:35:22 --> Security Class Initialized
DEBUG - 2024-08-01 17:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:35:22 --> Input Class Initialized
INFO - 2024-08-01 17:35:22 --> Language Class Initialized
INFO - 2024-08-01 17:35:22 --> Language Class Initialized
INFO - 2024-08-01 17:35:22 --> Config Class Initialized
INFO - 2024-08-01 17:35:22 --> Loader Class Initialized
INFO - 2024-08-01 17:35:22 --> Helper loaded: url_helper
INFO - 2024-08-01 17:35:22 --> Helper loaded: file_helper
INFO - 2024-08-01 17:35:22 --> Helper loaded: form_helper
INFO - 2024-08-01 17:35:22 --> Helper loaded: my_helper
INFO - 2024-08-01 17:35:22 --> Database Driver Class Initialized
INFO - 2024-08-01 17:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:35:22 --> Controller Class Initialized
INFO - 2024-08-01 17:35:22 --> Config Class Initialized
INFO - 2024-08-01 17:35:22 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:35:22 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:35:22 --> Utf8 Class Initialized
INFO - 2024-08-01 17:35:22 --> URI Class Initialized
INFO - 2024-08-01 17:35:22 --> Router Class Initialized
INFO - 2024-08-01 17:35:22 --> Output Class Initialized
INFO - 2024-08-01 17:35:22 --> Security Class Initialized
DEBUG - 2024-08-01 17:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:35:22 --> Input Class Initialized
INFO - 2024-08-01 17:35:22 --> Language Class Initialized
INFO - 2024-08-01 17:35:22 --> Language Class Initialized
INFO - 2024-08-01 17:35:22 --> Config Class Initialized
INFO - 2024-08-01 17:35:22 --> Loader Class Initialized
INFO - 2024-08-01 17:35:22 --> Helper loaded: url_helper
INFO - 2024-08-01 17:35:22 --> Helper loaded: file_helper
INFO - 2024-08-01 17:35:22 --> Helper loaded: form_helper
INFO - 2024-08-01 17:35:22 --> Helper loaded: my_helper
INFO - 2024-08-01 17:35:22 --> Database Driver Class Initialized
INFO - 2024-08-01 17:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:35:22 --> Controller Class Initialized
DEBUG - 2024-08-01 17:35:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-08-01 17:35:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 17:35:22 --> Final output sent to browser
DEBUG - 2024-08-01 17:35:22 --> Total execution time: 0.0287
INFO - 2024-08-01 17:35:30 --> Config Class Initialized
INFO - 2024-08-01 17:35:30 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:35:30 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:35:30 --> Utf8 Class Initialized
INFO - 2024-08-01 17:35:30 --> URI Class Initialized
INFO - 2024-08-01 17:35:30 --> Router Class Initialized
INFO - 2024-08-01 17:35:30 --> Output Class Initialized
INFO - 2024-08-01 17:35:30 --> Security Class Initialized
DEBUG - 2024-08-01 17:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:35:30 --> Input Class Initialized
INFO - 2024-08-01 17:35:30 --> Language Class Initialized
INFO - 2024-08-01 17:35:30 --> Language Class Initialized
INFO - 2024-08-01 17:35:30 --> Config Class Initialized
INFO - 2024-08-01 17:35:30 --> Loader Class Initialized
INFO - 2024-08-01 17:35:30 --> Helper loaded: url_helper
INFO - 2024-08-01 17:35:30 --> Helper loaded: file_helper
INFO - 2024-08-01 17:35:30 --> Helper loaded: form_helper
INFO - 2024-08-01 17:35:30 --> Helper loaded: my_helper
INFO - 2024-08-01 17:35:30 --> Database Driver Class Initialized
INFO - 2024-08-01 17:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:35:30 --> Controller Class Initialized
INFO - 2024-08-01 17:35:30 --> Helper loaded: cookie_helper
INFO - 2024-08-01 17:35:30 --> Final output sent to browser
DEBUG - 2024-08-01 17:35:30 --> Total execution time: 0.0352
INFO - 2024-08-01 17:35:30 --> Config Class Initialized
INFO - 2024-08-01 17:35:30 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:35:30 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:35:30 --> Utf8 Class Initialized
INFO - 2024-08-01 17:35:30 --> URI Class Initialized
INFO - 2024-08-01 17:35:30 --> Router Class Initialized
INFO - 2024-08-01 17:35:30 --> Output Class Initialized
INFO - 2024-08-01 17:35:30 --> Security Class Initialized
DEBUG - 2024-08-01 17:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:35:30 --> Input Class Initialized
INFO - 2024-08-01 17:35:30 --> Language Class Initialized
INFO - 2024-08-01 17:35:30 --> Language Class Initialized
INFO - 2024-08-01 17:35:30 --> Config Class Initialized
INFO - 2024-08-01 17:35:30 --> Loader Class Initialized
INFO - 2024-08-01 17:35:30 --> Helper loaded: url_helper
INFO - 2024-08-01 17:35:30 --> Helper loaded: file_helper
INFO - 2024-08-01 17:35:30 --> Helper loaded: form_helper
INFO - 2024-08-01 17:35:30 --> Helper loaded: my_helper
INFO - 2024-08-01 17:35:30 --> Database Driver Class Initialized
INFO - 2024-08-01 17:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:35:30 --> Controller Class Initialized
DEBUG - 2024-08-01 17:35:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-08-01 17:35:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 17:35:30 --> Final output sent to browser
DEBUG - 2024-08-01 17:35:30 --> Total execution time: 0.0308
INFO - 2024-08-01 17:35:32 --> Config Class Initialized
INFO - 2024-08-01 17:35:32 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:35:32 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:35:32 --> Utf8 Class Initialized
INFO - 2024-08-01 17:35:32 --> URI Class Initialized
INFO - 2024-08-01 17:35:32 --> Router Class Initialized
INFO - 2024-08-01 17:35:32 --> Output Class Initialized
INFO - 2024-08-01 17:35:32 --> Security Class Initialized
DEBUG - 2024-08-01 17:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:35:32 --> Input Class Initialized
INFO - 2024-08-01 17:35:32 --> Language Class Initialized
INFO - 2024-08-01 17:35:32 --> Language Class Initialized
INFO - 2024-08-01 17:35:32 --> Config Class Initialized
INFO - 2024-08-01 17:35:32 --> Loader Class Initialized
INFO - 2024-08-01 17:35:32 --> Helper loaded: url_helper
INFO - 2024-08-01 17:35:32 --> Helper loaded: file_helper
INFO - 2024-08-01 17:35:32 --> Helper loaded: form_helper
INFO - 2024-08-01 17:35:32 --> Helper loaded: my_helper
INFO - 2024-08-01 17:35:32 --> Database Driver Class Initialized
INFO - 2024-08-01 17:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:35:32 --> Controller Class Initialized
DEBUG - 2024-08-01 17:35:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-01 17:35:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 17:35:32 --> Final output sent to browser
DEBUG - 2024-08-01 17:35:32 --> Total execution time: 0.0464
INFO - 2024-08-01 17:35:38 --> Config Class Initialized
INFO - 2024-08-01 17:35:38 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:35:38 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:35:38 --> Utf8 Class Initialized
INFO - 2024-08-01 17:35:38 --> URI Class Initialized
INFO - 2024-08-01 17:35:38 --> Router Class Initialized
INFO - 2024-08-01 17:35:38 --> Output Class Initialized
INFO - 2024-08-01 17:35:38 --> Security Class Initialized
DEBUG - 2024-08-01 17:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:35:38 --> Input Class Initialized
INFO - 2024-08-01 17:35:38 --> Language Class Initialized
INFO - 2024-08-01 17:35:38 --> Language Class Initialized
INFO - 2024-08-01 17:35:38 --> Config Class Initialized
INFO - 2024-08-01 17:35:38 --> Loader Class Initialized
INFO - 2024-08-01 17:35:38 --> Helper loaded: url_helper
INFO - 2024-08-01 17:35:38 --> Helper loaded: file_helper
INFO - 2024-08-01 17:35:38 --> Helper loaded: form_helper
INFO - 2024-08-01 17:35:38 --> Helper loaded: my_helper
INFO - 2024-08-01 17:35:38 --> Database Driver Class Initialized
INFO - 2024-08-01 17:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:35:38 --> Controller Class Initialized
DEBUG - 2024-08-01 17:35:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-01 17:35:40 --> Config Class Initialized
INFO - 2024-08-01 17:35:40 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:35:40 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:35:40 --> Utf8 Class Initialized
INFO - 2024-08-01 17:35:40 --> URI Class Initialized
INFO - 2024-08-01 17:35:40 --> Router Class Initialized
INFO - 2024-08-01 17:35:40 --> Output Class Initialized
INFO - 2024-08-01 17:35:40 --> Security Class Initialized
DEBUG - 2024-08-01 17:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:35:40 --> Input Class Initialized
INFO - 2024-08-01 17:35:40 --> Language Class Initialized
INFO - 2024-08-01 17:35:40 --> Language Class Initialized
INFO - 2024-08-01 17:35:40 --> Config Class Initialized
INFO - 2024-08-01 17:35:40 --> Loader Class Initialized
INFO - 2024-08-01 17:35:40 --> Helper loaded: url_helper
INFO - 2024-08-01 17:35:40 --> Helper loaded: file_helper
INFO - 2024-08-01 17:35:40 --> Helper loaded: form_helper
INFO - 2024-08-01 17:35:40 --> Helper loaded: my_helper
INFO - 2024-08-01 17:35:40 --> Database Driver Class Initialized
INFO - 2024-08-01 17:35:41 --> Config Class Initialized
INFO - 2024-08-01 17:35:41 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:35:41 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:35:41 --> Utf8 Class Initialized
INFO - 2024-08-01 17:35:41 --> URI Class Initialized
INFO - 2024-08-01 17:35:41 --> Router Class Initialized
INFO - 2024-08-01 17:35:41 --> Output Class Initialized
INFO - 2024-08-01 17:35:41 --> Security Class Initialized
DEBUG - 2024-08-01 17:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:35:41 --> Input Class Initialized
INFO - 2024-08-01 17:35:41 --> Language Class Initialized
INFO - 2024-08-01 17:35:41 --> Language Class Initialized
INFO - 2024-08-01 17:35:41 --> Config Class Initialized
INFO - 2024-08-01 17:35:41 --> Loader Class Initialized
INFO - 2024-08-01 17:35:41 --> Helper loaded: url_helper
INFO - 2024-08-01 17:35:41 --> Helper loaded: file_helper
INFO - 2024-08-01 17:35:41 --> Helper loaded: form_helper
INFO - 2024-08-01 17:35:41 --> Helper loaded: my_helper
INFO - 2024-08-01 17:35:41 --> Database Driver Class Initialized
INFO - 2024-08-01 17:35:43 --> Config Class Initialized
INFO - 2024-08-01 17:35:43 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:35:43 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:35:43 --> Utf8 Class Initialized
INFO - 2024-08-01 17:35:43 --> URI Class Initialized
INFO - 2024-08-01 17:35:43 --> Router Class Initialized
INFO - 2024-08-01 17:35:43 --> Output Class Initialized
INFO - 2024-08-01 17:35:43 --> Security Class Initialized
DEBUG - 2024-08-01 17:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:35:43 --> Input Class Initialized
INFO - 2024-08-01 17:35:43 --> Language Class Initialized
INFO - 2024-08-01 17:35:43 --> Language Class Initialized
INFO - 2024-08-01 17:35:43 --> Config Class Initialized
INFO - 2024-08-01 17:35:43 --> Loader Class Initialized
INFO - 2024-08-01 17:35:43 --> Helper loaded: url_helper
INFO - 2024-08-01 17:35:43 --> Helper loaded: file_helper
INFO - 2024-08-01 17:35:43 --> Helper loaded: form_helper
INFO - 2024-08-01 17:35:43 --> Helper loaded: my_helper
INFO - 2024-08-01 17:35:43 --> Database Driver Class Initialized
INFO - 2024-08-01 17:35:44 --> Config Class Initialized
INFO - 2024-08-01 17:35:44 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:35:44 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:35:44 --> Utf8 Class Initialized
INFO - 2024-08-01 17:35:44 --> URI Class Initialized
INFO - 2024-08-01 17:35:44 --> Router Class Initialized
INFO - 2024-08-01 17:35:44 --> Output Class Initialized
INFO - 2024-08-01 17:35:44 --> Security Class Initialized
DEBUG - 2024-08-01 17:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:35:44 --> Input Class Initialized
INFO - 2024-08-01 17:35:44 --> Language Class Initialized
INFO - 2024-08-01 17:35:44 --> Language Class Initialized
INFO - 2024-08-01 17:35:44 --> Config Class Initialized
INFO - 2024-08-01 17:35:44 --> Loader Class Initialized
INFO - 2024-08-01 17:35:44 --> Final output sent to browser
DEBUG - 2024-08-01 17:35:44 --> Total execution time: 6.1045
INFO - 2024-08-01 17:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:35:44 --> Controller Class Initialized
INFO - 2024-08-01 17:35:44 --> Helper loaded: url_helper
INFO - 2024-08-01 17:35:44 --> Helper loaded: file_helper
INFO - 2024-08-01 17:35:44 --> Helper loaded: form_helper
INFO - 2024-08-01 17:35:44 --> Helper loaded: my_helper
INFO - 2024-08-01 17:35:44 --> Database Driver Class Initialized
ERROR - 2024-08-01 17:35:44 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-08-01 17:35:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-08-01 17:35:48 --> Final output sent to browser
DEBUG - 2024-08-01 17:35:48 --> Total execution time: 8.3551
INFO - 2024-08-01 17:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:35:48 --> Controller Class Initialized
DEBUG - 2024-08-01 17:35:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-01 17:35:53 --> Final output sent to browser
DEBUG - 2024-08-01 17:35:53 --> Total execution time: 11.3422
INFO - 2024-08-01 17:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:35:53 --> Controller Class Initialized
DEBUG - 2024-08-01 17:35:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-08-01 17:35:54 --> Final output sent to browser
DEBUG - 2024-08-01 17:35:54 --> Total execution time: 11.6868
INFO - 2024-08-01 17:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:35:54 --> Controller Class Initialized
DEBUG - 2024-08-01 17:35:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 17:35:58 --> Final output sent to browser
DEBUG - 2024-08-01 17:35:58 --> Total execution time: 13.4201
INFO - 2024-08-01 17:36:18 --> Config Class Initialized
INFO - 2024-08-01 17:36:18 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:36:18 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:36:18 --> Utf8 Class Initialized
INFO - 2024-08-01 17:36:18 --> URI Class Initialized
INFO - 2024-08-01 17:36:18 --> Router Class Initialized
INFO - 2024-08-01 17:36:18 --> Output Class Initialized
INFO - 2024-08-01 17:36:18 --> Security Class Initialized
DEBUG - 2024-08-01 17:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:36:18 --> Input Class Initialized
INFO - 2024-08-01 17:36:18 --> Language Class Initialized
INFO - 2024-08-01 17:36:18 --> Language Class Initialized
INFO - 2024-08-01 17:36:18 --> Config Class Initialized
INFO - 2024-08-01 17:36:18 --> Loader Class Initialized
INFO - 2024-08-01 17:36:18 --> Helper loaded: url_helper
INFO - 2024-08-01 17:36:18 --> Helper loaded: file_helper
INFO - 2024-08-01 17:36:18 --> Helper loaded: form_helper
INFO - 2024-08-01 17:36:18 --> Helper loaded: my_helper
INFO - 2024-08-01 17:36:18 --> Database Driver Class Initialized
INFO - 2024-08-01 17:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:36:18 --> Controller Class Initialized
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1843
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:36:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
DEBUG - 2024-08-01 17:36:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-08-01 17:36:20 --> Config Class Initialized
INFO - 2024-08-01 17:36:20 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:36:20 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:36:20 --> Utf8 Class Initialized
INFO - 2024-08-01 17:36:20 --> URI Class Initialized
INFO - 2024-08-01 17:36:20 --> Router Class Initialized
INFO - 2024-08-01 17:36:20 --> Output Class Initialized
INFO - 2024-08-01 17:36:20 --> Security Class Initialized
DEBUG - 2024-08-01 17:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:36:20 --> Input Class Initialized
INFO - 2024-08-01 17:36:20 --> Language Class Initialized
INFO - 2024-08-01 17:36:20 --> Language Class Initialized
INFO - 2024-08-01 17:36:20 --> Config Class Initialized
INFO - 2024-08-01 17:36:20 --> Loader Class Initialized
INFO - 2024-08-01 17:36:20 --> Helper loaded: url_helper
INFO - 2024-08-01 17:36:20 --> Helper loaded: file_helper
INFO - 2024-08-01 17:36:20 --> Helper loaded: form_helper
INFO - 2024-08-01 17:36:20 --> Helper loaded: my_helper
INFO - 2024-08-01 17:36:21 --> Database Driver Class Initialized
INFO - 2024-08-01 17:36:22 --> Config Class Initialized
INFO - 2024-08-01 17:36:22 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:36:22 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:36:22 --> Utf8 Class Initialized
INFO - 2024-08-01 17:36:22 --> URI Class Initialized
INFO - 2024-08-01 17:36:22 --> Router Class Initialized
INFO - 2024-08-01 17:36:22 --> Output Class Initialized
INFO - 2024-08-01 17:36:22 --> Security Class Initialized
DEBUG - 2024-08-01 17:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:36:22 --> Input Class Initialized
INFO - 2024-08-01 17:36:22 --> Language Class Initialized
INFO - 2024-08-01 17:36:22 --> Language Class Initialized
INFO - 2024-08-01 17:36:22 --> Config Class Initialized
INFO - 2024-08-01 17:36:22 --> Loader Class Initialized
INFO - 2024-08-01 17:36:22 --> Helper loaded: url_helper
INFO - 2024-08-01 17:36:22 --> Helper loaded: file_helper
INFO - 2024-08-01 17:36:22 --> Helper loaded: form_helper
INFO - 2024-08-01 17:36:22 --> Helper loaded: my_helper
INFO - 2024-08-01 17:36:22 --> Database Driver Class Initialized
INFO - 2024-08-01 17:36:24 --> Final output sent to browser
DEBUG - 2024-08-01 17:36:24 --> Total execution time: 5.7699
INFO - 2024-08-01 17:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:36:24 --> Controller Class Initialized
DEBUG - 2024-08-01 17:36:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-01 17:36:24 --> Config Class Initialized
INFO - 2024-08-01 17:36:24 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:36:24 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:36:24 --> Utf8 Class Initialized
INFO - 2024-08-01 17:36:24 --> URI Class Initialized
INFO - 2024-08-01 17:36:24 --> Router Class Initialized
INFO - 2024-08-01 17:36:24 --> Output Class Initialized
INFO - 2024-08-01 17:36:24 --> Security Class Initialized
DEBUG - 2024-08-01 17:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:36:24 --> Input Class Initialized
INFO - 2024-08-01 17:36:24 --> Language Class Initialized
INFO - 2024-08-01 17:36:24 --> Language Class Initialized
INFO - 2024-08-01 17:36:24 --> Config Class Initialized
INFO - 2024-08-01 17:36:24 --> Loader Class Initialized
INFO - 2024-08-01 17:36:24 --> Helper loaded: url_helper
INFO - 2024-08-01 17:36:24 --> Helper loaded: file_helper
INFO - 2024-08-01 17:36:24 --> Helper loaded: form_helper
INFO - 2024-08-01 17:36:24 --> Helper loaded: my_helper
INFO - 2024-08-01 17:36:24 --> Database Driver Class Initialized
INFO - 2024-08-01 17:36:26 --> Config Class Initialized
INFO - 2024-08-01 17:36:26 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:36:26 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:36:26 --> Utf8 Class Initialized
INFO - 2024-08-01 17:36:26 --> URI Class Initialized
INFO - 2024-08-01 17:36:26 --> Router Class Initialized
INFO - 2024-08-01 17:36:26 --> Output Class Initialized
INFO - 2024-08-01 17:36:26 --> Security Class Initialized
DEBUG - 2024-08-01 17:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:36:26 --> Input Class Initialized
INFO - 2024-08-01 17:36:26 --> Language Class Initialized
INFO - 2024-08-01 17:36:26 --> Language Class Initialized
INFO - 2024-08-01 17:36:26 --> Config Class Initialized
INFO - 2024-08-01 17:36:26 --> Loader Class Initialized
INFO - 2024-08-01 17:36:26 --> Helper loaded: url_helper
INFO - 2024-08-01 17:36:26 --> Helper loaded: file_helper
INFO - 2024-08-01 17:36:26 --> Helper loaded: form_helper
INFO - 2024-08-01 17:36:26 --> Helper loaded: my_helper
INFO - 2024-08-01 17:36:26 --> Database Driver Class Initialized
INFO - 2024-08-01 17:36:28 --> Final output sent to browser
DEBUG - 2024-08-01 17:36:28 --> Total execution time: 7.4519
INFO - 2024-08-01 17:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:36:28 --> Controller Class Initialized
DEBUG - 2024-08-01 17:36:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-08-01 17:36:30 --> Final output sent to browser
DEBUG - 2024-08-01 17:36:30 --> Total execution time: 7.6307
INFO - 2024-08-01 17:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:36:30 --> Controller Class Initialized
DEBUG - 2024-08-01 17:36:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 17:36:32 --> Final output sent to browser
DEBUG - 2024-08-01 17:36:32 --> Total execution time: 8.7087
INFO - 2024-08-01 17:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:36:32 --> Controller Class Initialized
DEBUG - 2024-08-01 17:36:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-01 17:36:36 --> Final output sent to browser
DEBUG - 2024-08-01 17:36:36 --> Total execution time: 10.7552
INFO - 2024-08-01 17:37:11 --> Config Class Initialized
INFO - 2024-08-01 17:37:11 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:37:11 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:37:11 --> Utf8 Class Initialized
INFO - 2024-08-01 17:37:11 --> URI Class Initialized
INFO - 2024-08-01 17:37:11 --> Router Class Initialized
INFO - 2024-08-01 17:37:11 --> Output Class Initialized
INFO - 2024-08-01 17:37:11 --> Security Class Initialized
DEBUG - 2024-08-01 17:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:37:11 --> Input Class Initialized
INFO - 2024-08-01 17:37:11 --> Language Class Initialized
INFO - 2024-08-01 17:37:11 --> Language Class Initialized
INFO - 2024-08-01 17:37:11 --> Config Class Initialized
INFO - 2024-08-01 17:37:11 --> Loader Class Initialized
INFO - 2024-08-01 17:37:11 --> Helper loaded: url_helper
INFO - 2024-08-01 17:37:11 --> Helper loaded: file_helper
INFO - 2024-08-01 17:37:11 --> Helper loaded: form_helper
INFO - 2024-08-01 17:37:11 --> Helper loaded: my_helper
INFO - 2024-08-01 17:37:11 --> Database Driver Class Initialized
INFO - 2024-08-01 17:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:37:11 --> Controller Class Initialized
DEBUG - 2024-08-01 17:37:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 17:37:14 --> Config Class Initialized
INFO - 2024-08-01 17:37:14 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:37:14 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:37:14 --> Utf8 Class Initialized
INFO - 2024-08-01 17:37:14 --> URI Class Initialized
INFO - 2024-08-01 17:37:14 --> Router Class Initialized
INFO - 2024-08-01 17:37:14 --> Output Class Initialized
INFO - 2024-08-01 17:37:14 --> Security Class Initialized
DEBUG - 2024-08-01 17:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:37:14 --> Input Class Initialized
INFO - 2024-08-01 17:37:14 --> Language Class Initialized
INFO - 2024-08-01 17:37:14 --> Language Class Initialized
INFO - 2024-08-01 17:37:14 --> Config Class Initialized
INFO - 2024-08-01 17:37:14 --> Loader Class Initialized
INFO - 2024-08-01 17:37:14 --> Helper loaded: url_helper
INFO - 2024-08-01 17:37:14 --> Helper loaded: file_helper
INFO - 2024-08-01 17:37:14 --> Helper loaded: form_helper
INFO - 2024-08-01 17:37:14 --> Helper loaded: my_helper
INFO - 2024-08-01 17:37:14 --> Database Driver Class Initialized
INFO - 2024-08-01 17:37:14 --> Final output sent to browser
DEBUG - 2024-08-01 17:37:14 --> Total execution time: 2.8617
INFO - 2024-08-01 17:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:37:14 --> Controller Class Initialized
DEBUG - 2024-08-01 17:37:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-08-01 17:37:15 --> Config Class Initialized
INFO - 2024-08-01 17:37:15 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:37:15 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:37:15 --> Utf8 Class Initialized
INFO - 2024-08-01 17:37:15 --> URI Class Initialized
INFO - 2024-08-01 17:37:15 --> Router Class Initialized
INFO - 2024-08-01 17:37:15 --> Output Class Initialized
INFO - 2024-08-01 17:37:15 --> Security Class Initialized
DEBUG - 2024-08-01 17:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:37:15 --> Input Class Initialized
INFO - 2024-08-01 17:37:15 --> Language Class Initialized
INFO - 2024-08-01 17:37:15 --> Language Class Initialized
INFO - 2024-08-01 17:37:15 --> Config Class Initialized
INFO - 2024-08-01 17:37:15 --> Loader Class Initialized
INFO - 2024-08-01 17:37:15 --> Helper loaded: url_helper
INFO - 2024-08-01 17:37:15 --> Helper loaded: file_helper
INFO - 2024-08-01 17:37:15 --> Helper loaded: form_helper
INFO - 2024-08-01 17:37:15 --> Helper loaded: my_helper
INFO - 2024-08-01 17:37:15 --> Database Driver Class Initialized
INFO - 2024-08-01 17:37:16 --> Final output sent to browser
DEBUG - 2024-08-01 17:37:16 --> Total execution time: 2.2522
INFO - 2024-08-01 17:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:37:16 --> Controller Class Initialized
DEBUG - 2024-08-01 17:37:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-01 17:37:17 --> Config Class Initialized
INFO - 2024-08-01 17:37:17 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:37:17 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:37:17 --> Utf8 Class Initialized
INFO - 2024-08-01 17:37:17 --> URI Class Initialized
INFO - 2024-08-01 17:37:17 --> Router Class Initialized
INFO - 2024-08-01 17:37:17 --> Output Class Initialized
INFO - 2024-08-01 17:37:17 --> Security Class Initialized
DEBUG - 2024-08-01 17:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:37:17 --> Input Class Initialized
INFO - 2024-08-01 17:37:17 --> Language Class Initialized
INFO - 2024-08-01 17:37:17 --> Language Class Initialized
INFO - 2024-08-01 17:37:17 --> Config Class Initialized
INFO - 2024-08-01 17:37:17 --> Loader Class Initialized
INFO - 2024-08-01 17:37:17 --> Helper loaded: url_helper
INFO - 2024-08-01 17:37:17 --> Helper loaded: file_helper
INFO - 2024-08-01 17:37:17 --> Helper loaded: form_helper
INFO - 2024-08-01 17:37:17 --> Helper loaded: my_helper
INFO - 2024-08-01 17:37:17 --> Database Driver Class Initialized
INFO - 2024-08-01 17:37:19 --> Config Class Initialized
INFO - 2024-08-01 17:37:19 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:37:19 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:37:19 --> Utf8 Class Initialized
INFO - 2024-08-01 17:37:19 --> URI Class Initialized
INFO - 2024-08-01 17:37:19 --> Router Class Initialized
INFO - 2024-08-01 17:37:19 --> Output Class Initialized
INFO - 2024-08-01 17:37:19 --> Security Class Initialized
DEBUG - 2024-08-01 17:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:37:19 --> Input Class Initialized
INFO - 2024-08-01 17:37:19 --> Language Class Initialized
INFO - 2024-08-01 17:37:19 --> Language Class Initialized
INFO - 2024-08-01 17:37:19 --> Config Class Initialized
INFO - 2024-08-01 17:37:19 --> Loader Class Initialized
INFO - 2024-08-01 17:37:19 --> Helper loaded: url_helper
INFO - 2024-08-01 17:37:19 --> Helper loaded: file_helper
INFO - 2024-08-01 17:37:19 --> Helper loaded: form_helper
INFO - 2024-08-01 17:37:19 --> Helper loaded: my_helper
INFO - 2024-08-01 17:37:19 --> Database Driver Class Initialized
INFO - 2024-08-01 17:37:20 --> Final output sent to browser
DEBUG - 2024-08-01 17:37:20 --> Total execution time: 4.9999
INFO - 2024-08-01 17:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:37:20 --> Controller Class Initialized
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1843
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
ERROR - 2024-08-01 17:37:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1861
DEBUG - 2024-08-01 17:37:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-08-01 17:37:26 --> Final output sent to browser
DEBUG - 2024-08-01 17:37:26 --> Total execution time: 8.7181
INFO - 2024-08-01 17:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:37:26 --> Controller Class Initialized
DEBUG - 2024-08-01 17:37:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-01 17:37:29 --> Final output sent to browser
DEBUG - 2024-08-01 17:37:29 --> Total execution time: 10.3225
INFO - 2024-08-01 17:37:38 --> Config Class Initialized
INFO - 2024-08-01 17:37:38 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:37:38 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:37:38 --> Utf8 Class Initialized
INFO - 2024-08-01 17:37:38 --> URI Class Initialized
INFO - 2024-08-01 17:37:38 --> Router Class Initialized
INFO - 2024-08-01 17:37:38 --> Output Class Initialized
INFO - 2024-08-01 17:37:38 --> Security Class Initialized
DEBUG - 2024-08-01 17:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:37:38 --> Input Class Initialized
INFO - 2024-08-01 17:37:38 --> Language Class Initialized
INFO - 2024-08-01 17:37:38 --> Language Class Initialized
INFO - 2024-08-01 17:37:38 --> Config Class Initialized
INFO - 2024-08-01 17:37:38 --> Loader Class Initialized
INFO - 2024-08-01 17:37:38 --> Helper loaded: url_helper
INFO - 2024-08-01 17:37:38 --> Helper loaded: file_helper
INFO - 2024-08-01 17:37:38 --> Helper loaded: form_helper
INFO - 2024-08-01 17:37:38 --> Helper loaded: my_helper
INFO - 2024-08-01 17:37:38 --> Database Driver Class Initialized
INFO - 2024-08-01 17:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:37:38 --> Controller Class Initialized
INFO - 2024-08-01 17:37:38 --> Helper loaded: cookie_helper
INFO - 2024-08-01 17:37:38 --> Config Class Initialized
INFO - 2024-08-01 17:37:38 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:37:38 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:37:38 --> Utf8 Class Initialized
INFO - 2024-08-01 17:37:38 --> URI Class Initialized
INFO - 2024-08-01 17:37:38 --> Router Class Initialized
INFO - 2024-08-01 17:37:38 --> Output Class Initialized
INFO - 2024-08-01 17:37:38 --> Security Class Initialized
DEBUG - 2024-08-01 17:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:37:38 --> Input Class Initialized
INFO - 2024-08-01 17:37:38 --> Language Class Initialized
INFO - 2024-08-01 17:37:38 --> Language Class Initialized
INFO - 2024-08-01 17:37:38 --> Config Class Initialized
INFO - 2024-08-01 17:37:38 --> Loader Class Initialized
INFO - 2024-08-01 17:37:38 --> Helper loaded: url_helper
INFO - 2024-08-01 17:37:38 --> Helper loaded: file_helper
INFO - 2024-08-01 17:37:38 --> Helper loaded: form_helper
INFO - 2024-08-01 17:37:38 --> Helper loaded: my_helper
INFO - 2024-08-01 17:37:38 --> Database Driver Class Initialized
INFO - 2024-08-01 17:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:37:38 --> Controller Class Initialized
INFO - 2024-08-01 17:37:39 --> Config Class Initialized
INFO - 2024-08-01 17:37:39 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:37:39 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:37:39 --> Utf8 Class Initialized
INFO - 2024-08-01 17:37:39 --> URI Class Initialized
INFO - 2024-08-01 17:37:39 --> Router Class Initialized
INFO - 2024-08-01 17:37:39 --> Output Class Initialized
INFO - 2024-08-01 17:37:39 --> Security Class Initialized
DEBUG - 2024-08-01 17:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:37:39 --> Input Class Initialized
INFO - 2024-08-01 17:37:39 --> Language Class Initialized
INFO - 2024-08-01 17:37:39 --> Language Class Initialized
INFO - 2024-08-01 17:37:39 --> Config Class Initialized
INFO - 2024-08-01 17:37:39 --> Loader Class Initialized
INFO - 2024-08-01 17:37:39 --> Helper loaded: url_helper
INFO - 2024-08-01 17:37:39 --> Helper loaded: file_helper
INFO - 2024-08-01 17:37:39 --> Helper loaded: form_helper
INFO - 2024-08-01 17:37:39 --> Helper loaded: my_helper
INFO - 2024-08-01 17:37:39 --> Database Driver Class Initialized
INFO - 2024-08-01 17:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:37:39 --> Controller Class Initialized
DEBUG - 2024-08-01 17:37:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-08-01 17:37:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 17:37:39 --> Final output sent to browser
DEBUG - 2024-08-01 17:37:39 --> Total execution time: 0.0477
INFO - 2024-08-01 17:42:33 --> Config Class Initialized
INFO - 2024-08-01 17:42:33 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:42:33 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:42:33 --> Utf8 Class Initialized
INFO - 2024-08-01 17:42:33 --> URI Class Initialized
INFO - 2024-08-01 17:42:33 --> Router Class Initialized
INFO - 2024-08-01 17:42:33 --> Output Class Initialized
INFO - 2024-08-01 17:42:33 --> Security Class Initialized
DEBUG - 2024-08-01 17:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:42:33 --> Input Class Initialized
INFO - 2024-08-01 17:42:33 --> Language Class Initialized
INFO - 2024-08-01 17:42:33 --> Language Class Initialized
INFO - 2024-08-01 17:42:33 --> Config Class Initialized
INFO - 2024-08-01 17:42:33 --> Loader Class Initialized
INFO - 2024-08-01 17:42:33 --> Helper loaded: url_helper
INFO - 2024-08-01 17:42:33 --> Helper loaded: file_helper
INFO - 2024-08-01 17:42:33 --> Helper loaded: form_helper
INFO - 2024-08-01 17:42:33 --> Helper loaded: my_helper
INFO - 2024-08-01 17:42:33 --> Database Driver Class Initialized
INFO - 2024-08-01 17:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:42:33 --> Controller Class Initialized
DEBUG - 2024-08-01 17:42:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-01 17:42:37 --> Final output sent to browser
DEBUG - 2024-08-01 17:42:37 --> Total execution time: 3.8842
INFO - 2024-08-01 17:42:38 --> Config Class Initialized
INFO - 2024-08-01 17:42:38 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:42:38 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:42:38 --> Utf8 Class Initialized
INFO - 2024-08-01 17:42:38 --> URI Class Initialized
INFO - 2024-08-01 17:42:38 --> Router Class Initialized
INFO - 2024-08-01 17:42:38 --> Output Class Initialized
INFO - 2024-08-01 17:42:38 --> Security Class Initialized
DEBUG - 2024-08-01 17:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:42:38 --> Input Class Initialized
INFO - 2024-08-01 17:42:38 --> Language Class Initialized
INFO - 2024-08-01 17:42:38 --> Language Class Initialized
INFO - 2024-08-01 17:42:38 --> Config Class Initialized
INFO - 2024-08-01 17:42:38 --> Loader Class Initialized
INFO - 2024-08-01 17:42:38 --> Helper loaded: url_helper
INFO - 2024-08-01 17:42:38 --> Helper loaded: file_helper
INFO - 2024-08-01 17:42:38 --> Helper loaded: form_helper
INFO - 2024-08-01 17:42:38 --> Helper loaded: my_helper
INFO - 2024-08-01 17:42:38 --> Database Driver Class Initialized
INFO - 2024-08-01 17:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:42:38 --> Controller Class Initialized
ERROR - 2024-08-01 17:42:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1797
ERROR - 2024-08-01 17:42:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1804
ERROR - 2024-08-01 17:42:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-08-01 17:42:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-08-01 17:42:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-08-01 17:42:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 86
ERROR - 2024-08-01 17:42:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-08-01 17:42:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-08-01 17:42:38 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-08-01 17:42:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 230
ERROR - 2024-08-01 17:42:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 231
ERROR - 2024-08-01 17:42:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 235
ERROR - 2024-08-01 17:42:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 286
ERROR - 2024-08-01 17:42:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-08-01 17:42:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 300
ERROR - 2024-08-01 17:42:38 --> Severity: Notice --> Undefined offset: 2 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 218
ERROR - 2024-08-01 17:42:38 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 219
ERROR - 2024-08-01 17:42:38 --> Severity: Notice --> Undefined offset: -1 /www/wwwroot/report.mhis.link/bangka/secondary/application/helpers/my_helper.php 228
ERROR - 2024-08-01 17:42:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-08-01 17:42:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
ERROR - 2024-08-01 17:42:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
ERROR - 2024-08-01 17:42:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
INFO - 2024-08-01 17:42:41 --> Final output sent to browser
DEBUG - 2024-08-01 17:42:41 --> Total execution time: 3.4154
INFO - 2024-08-01 17:42:43 --> Config Class Initialized
INFO - 2024-08-01 17:42:43 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:42:43 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:42:43 --> Utf8 Class Initialized
INFO - 2024-08-01 17:42:43 --> URI Class Initialized
INFO - 2024-08-01 17:42:43 --> Router Class Initialized
INFO - 2024-08-01 17:42:43 --> Output Class Initialized
INFO - 2024-08-01 17:42:43 --> Security Class Initialized
DEBUG - 2024-08-01 17:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:42:43 --> Input Class Initialized
INFO - 2024-08-01 17:42:43 --> Language Class Initialized
INFO - 2024-08-01 17:42:43 --> Language Class Initialized
INFO - 2024-08-01 17:42:43 --> Config Class Initialized
INFO - 2024-08-01 17:42:43 --> Loader Class Initialized
INFO - 2024-08-01 17:42:43 --> Helper loaded: url_helper
INFO - 2024-08-01 17:42:43 --> Helper loaded: file_helper
INFO - 2024-08-01 17:42:43 --> Helper loaded: form_helper
INFO - 2024-08-01 17:42:43 --> Helper loaded: my_helper
INFO - 2024-08-01 17:42:43 --> Database Driver Class Initialized
INFO - 2024-08-01 17:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:42:43 --> Controller Class Initialized
ERROR - 2024-08-01 17:42:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2591
ERROR - 2024-08-01 17:42:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3156
ERROR - 2024-08-01 17:42:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3194
ERROR - 2024-08-01 17:42:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3232
ERROR - 2024-08-01 17:42:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3271
ERROR - 2024-08-01 17:42:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3388
ERROR - 2024-08-01 17:42:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3507
ERROR - 2024-08-01 17:42:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3626
ERROR - 2024-08-01 17:42:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3745
ERROR - 2024-08-01 17:42:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-08-01 17:42:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-08-01 17:42:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 40
ERROR - 2024-08-01 17:42:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-08-01 17:42:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-08-01 17:42:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
ERROR - 2024-08-01 17:42:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
DEBUG - 2024-08-01 17:42:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-01 17:42:51 --> Config Class Initialized
INFO - 2024-08-01 17:42:51 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:42:51 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:42:51 --> Utf8 Class Initialized
INFO - 2024-08-01 17:42:51 --> URI Class Initialized
INFO - 2024-08-01 17:42:51 --> Router Class Initialized
INFO - 2024-08-01 17:42:51 --> Output Class Initialized
INFO - 2024-08-01 17:42:51 --> Security Class Initialized
DEBUG - 2024-08-01 17:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:42:51 --> Input Class Initialized
INFO - 2024-08-01 17:42:51 --> Language Class Initialized
INFO - 2024-08-01 17:42:51 --> Language Class Initialized
INFO - 2024-08-01 17:42:51 --> Config Class Initialized
INFO - 2024-08-01 17:42:51 --> Loader Class Initialized
INFO - 2024-08-01 17:42:51 --> Helper loaded: url_helper
INFO - 2024-08-01 17:42:51 --> Helper loaded: file_helper
INFO - 2024-08-01 17:42:51 --> Helper loaded: form_helper
INFO - 2024-08-01 17:42:51 --> Helper loaded: my_helper
INFO - 2024-08-01 17:42:51 --> Database Driver Class Initialized
INFO - 2024-08-01 17:42:57 --> Config Class Initialized
INFO - 2024-08-01 17:42:57 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:42:57 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:42:57 --> Utf8 Class Initialized
INFO - 2024-08-01 17:42:57 --> URI Class Initialized
INFO - 2024-08-01 17:42:57 --> Router Class Initialized
INFO - 2024-08-01 17:42:57 --> Output Class Initialized
INFO - 2024-08-01 17:42:57 --> Security Class Initialized
DEBUG - 2024-08-01 17:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:42:57 --> Input Class Initialized
INFO - 2024-08-01 17:42:57 --> Language Class Initialized
INFO - 2024-08-01 17:42:57 --> Language Class Initialized
INFO - 2024-08-01 17:42:57 --> Config Class Initialized
INFO - 2024-08-01 17:42:57 --> Loader Class Initialized
INFO - 2024-08-01 17:42:57 --> Helper loaded: url_helper
INFO - 2024-08-01 17:42:57 --> Helper loaded: file_helper
INFO - 2024-08-01 17:42:57 --> Helper loaded: form_helper
INFO - 2024-08-01 17:42:57 --> Helper loaded: my_helper
INFO - 2024-08-01 17:42:57 --> Database Driver Class Initialized
INFO - 2024-08-01 17:43:22 --> Config Class Initialized
INFO - 2024-08-01 17:43:22 --> Hooks Class Initialized
DEBUG - 2024-08-01 17:43:22 --> UTF-8 Support Enabled
INFO - 2024-08-01 17:43:22 --> Utf8 Class Initialized
INFO - 2024-08-01 17:43:22 --> URI Class Initialized
INFO - 2024-08-01 17:43:22 --> Router Class Initialized
INFO - 2024-08-01 17:43:22 --> Output Class Initialized
INFO - 2024-08-01 17:43:22 --> Security Class Initialized
DEBUG - 2024-08-01 17:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 17:43:22 --> Input Class Initialized
INFO - 2024-08-01 17:43:22 --> Language Class Initialized
INFO - 2024-08-01 17:43:22 --> Language Class Initialized
INFO - 2024-08-01 17:43:22 --> Config Class Initialized
INFO - 2024-08-01 17:43:22 --> Loader Class Initialized
INFO - 2024-08-01 17:43:22 --> Helper loaded: url_helper
INFO - 2024-08-01 17:43:22 --> Helper loaded: file_helper
INFO - 2024-08-01 17:43:22 --> Helper loaded: form_helper
INFO - 2024-08-01 17:43:22 --> Helper loaded: my_helper
INFO - 2024-08-01 17:43:22 --> Database Driver Class Initialized
INFO - 2024-08-01 17:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:46:59 --> Controller Class Initialized
ERROR - 2024-08-01 17:46:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-08-01 17:46:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-01 17:46:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-01 17:46:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-08-01 17:46:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-01 17:46:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-01 17:46:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-08-01 17:46:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-08-01 17:46:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-01 17:46:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-01 17:46:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-08-01 17:46:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-01 17:46:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-01 17:46:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-08-01 17:46:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-01 17:46:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-01 17:46:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-08-01 17:46:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-08-01 17:46:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-08-01 17:46:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 436
ERROR - 2024-08-01 17:46:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 437
DEBUG - 2024-08-01 17:46:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-08-01 17:47:03 --> Final output sent to browser
DEBUG - 2024-08-01 17:47:03 --> Total execution time: 251.4910
INFO - 2024-08-01 17:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:47:03 --> Controller Class Initialized
ERROR - 2024-08-01 17:47:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-01 17:47:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-01 17:47:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-01 17:47:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-01 17:47:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-01 17:47:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-01 17:47:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-01 17:47:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-01 17:47:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-01 17:47:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-01 17:47:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-01 17:47:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-01 17:47:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-01 17:47:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-01 17:47:06 --> Final output sent to browser
DEBUG - 2024-08-01 17:47:06 --> Total execution time: 248.3340
INFO - 2024-08-01 17:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 17:47:06 --> Controller Class Initialized
INFO - 2024-08-01 17:47:06 --> Helper loaded: cookie_helper
INFO - 2024-08-01 18:18:12 --> Config Class Initialized
INFO - 2024-08-01 18:18:12 --> Hooks Class Initialized
DEBUG - 2024-08-01 18:18:12 --> UTF-8 Support Enabled
INFO - 2024-08-01 18:18:12 --> Utf8 Class Initialized
INFO - 2024-08-01 18:18:12 --> URI Class Initialized
INFO - 2024-08-01 18:18:12 --> Router Class Initialized
INFO - 2024-08-01 18:18:12 --> Output Class Initialized
INFO - 2024-08-01 18:18:12 --> Security Class Initialized
DEBUG - 2024-08-01 18:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 18:18:12 --> Input Class Initialized
INFO - 2024-08-01 18:18:12 --> Language Class Initialized
INFO - 2024-08-01 18:18:12 --> Language Class Initialized
INFO - 2024-08-01 18:18:12 --> Config Class Initialized
INFO - 2024-08-01 18:18:12 --> Loader Class Initialized
INFO - 2024-08-01 18:18:12 --> Helper loaded: url_helper
INFO - 2024-08-01 18:18:12 --> Helper loaded: file_helper
INFO - 2024-08-01 18:18:12 --> Helper loaded: form_helper
INFO - 2024-08-01 18:18:12 --> Helper loaded: my_helper
INFO - 2024-08-01 18:18:12 --> Database Driver Class Initialized
INFO - 2024-08-01 18:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 18:18:12 --> Controller Class Initialized
INFO - 2024-08-01 18:18:12 --> Helper loaded: cookie_helper
INFO - 2024-08-01 18:18:12 --> Final output sent to browser
DEBUG - 2024-08-01 18:18:12 --> Total execution time: 0.0436
INFO - 2024-08-01 18:18:13 --> Config Class Initialized
INFO - 2024-08-01 18:18:13 --> Hooks Class Initialized
DEBUG - 2024-08-01 18:18:13 --> UTF-8 Support Enabled
INFO - 2024-08-01 18:18:13 --> Utf8 Class Initialized
INFO - 2024-08-01 18:18:13 --> URI Class Initialized
INFO - 2024-08-01 18:18:13 --> Router Class Initialized
INFO - 2024-08-01 18:18:13 --> Output Class Initialized
INFO - 2024-08-01 18:18:13 --> Security Class Initialized
DEBUG - 2024-08-01 18:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 18:18:13 --> Input Class Initialized
INFO - 2024-08-01 18:18:13 --> Language Class Initialized
INFO - 2024-08-01 18:18:13 --> Language Class Initialized
INFO - 2024-08-01 18:18:13 --> Config Class Initialized
INFO - 2024-08-01 18:18:13 --> Loader Class Initialized
INFO - 2024-08-01 18:18:13 --> Helper loaded: url_helper
INFO - 2024-08-01 18:18:13 --> Helper loaded: file_helper
INFO - 2024-08-01 18:18:13 --> Helper loaded: form_helper
INFO - 2024-08-01 18:18:13 --> Helper loaded: my_helper
INFO - 2024-08-01 18:18:13 --> Database Driver Class Initialized
INFO - 2024-08-01 18:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 18:18:13 --> Controller Class Initialized
INFO - 2024-08-01 18:18:13 --> Helper loaded: cookie_helper
INFO - 2024-08-01 18:18:13 --> Config Class Initialized
INFO - 2024-08-01 18:18:13 --> Hooks Class Initialized
DEBUG - 2024-08-01 18:18:13 --> UTF-8 Support Enabled
INFO - 2024-08-01 18:18:13 --> Utf8 Class Initialized
INFO - 2024-08-01 18:18:13 --> URI Class Initialized
INFO - 2024-08-01 18:18:13 --> Router Class Initialized
INFO - 2024-08-01 18:18:13 --> Output Class Initialized
INFO - 2024-08-01 18:18:13 --> Security Class Initialized
DEBUG - 2024-08-01 18:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 18:18:13 --> Input Class Initialized
INFO - 2024-08-01 18:18:13 --> Language Class Initialized
INFO - 2024-08-01 18:18:13 --> Language Class Initialized
INFO - 2024-08-01 18:18:13 --> Config Class Initialized
INFO - 2024-08-01 18:18:13 --> Loader Class Initialized
INFO - 2024-08-01 18:18:13 --> Helper loaded: url_helper
INFO - 2024-08-01 18:18:13 --> Helper loaded: file_helper
INFO - 2024-08-01 18:18:13 --> Helper loaded: form_helper
INFO - 2024-08-01 18:18:13 --> Helper loaded: my_helper
INFO - 2024-08-01 18:18:13 --> Database Driver Class Initialized
INFO - 2024-08-01 18:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 18:18:13 --> Controller Class Initialized
DEBUG - 2024-08-01 18:18:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-01 18:18:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 18:18:13 --> Final output sent to browser
DEBUG - 2024-08-01 18:18:13 --> Total execution time: 0.0483
INFO - 2024-08-01 19:56:51 --> Config Class Initialized
INFO - 2024-08-01 19:56:51 --> Hooks Class Initialized
DEBUG - 2024-08-01 19:56:51 --> UTF-8 Support Enabled
INFO - 2024-08-01 19:56:51 --> Utf8 Class Initialized
INFO - 2024-08-01 19:56:51 --> URI Class Initialized
INFO - 2024-08-01 19:56:51 --> Router Class Initialized
INFO - 2024-08-01 19:56:51 --> Output Class Initialized
INFO - 2024-08-01 19:56:51 --> Security Class Initialized
DEBUG - 2024-08-01 19:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 19:56:51 --> Input Class Initialized
INFO - 2024-08-01 19:56:51 --> Language Class Initialized
INFO - 2024-08-01 19:56:51 --> Language Class Initialized
INFO - 2024-08-01 19:56:51 --> Config Class Initialized
INFO - 2024-08-01 19:56:51 --> Loader Class Initialized
INFO - 2024-08-01 19:56:51 --> Helper loaded: url_helper
INFO - 2024-08-01 19:56:51 --> Helper loaded: file_helper
INFO - 2024-08-01 19:56:51 --> Helper loaded: form_helper
INFO - 2024-08-01 19:56:51 --> Helper loaded: my_helper
INFO - 2024-08-01 19:56:51 --> Database Driver Class Initialized
INFO - 2024-08-01 19:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 19:56:51 --> Controller Class Initialized
INFO - 2024-08-01 19:56:51 --> Helper loaded: cookie_helper
INFO - 2024-08-01 19:56:51 --> Final output sent to browser
DEBUG - 2024-08-01 19:56:51 --> Total execution time: 0.0595
INFO - 2024-08-01 19:56:52 --> Config Class Initialized
INFO - 2024-08-01 19:56:52 --> Hooks Class Initialized
DEBUG - 2024-08-01 19:56:52 --> UTF-8 Support Enabled
INFO - 2024-08-01 19:56:52 --> Utf8 Class Initialized
INFO - 2024-08-01 19:56:52 --> URI Class Initialized
INFO - 2024-08-01 19:56:52 --> Router Class Initialized
INFO - 2024-08-01 19:56:52 --> Output Class Initialized
INFO - 2024-08-01 19:56:52 --> Security Class Initialized
DEBUG - 2024-08-01 19:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 19:56:52 --> Input Class Initialized
INFO - 2024-08-01 19:56:52 --> Language Class Initialized
INFO - 2024-08-01 19:56:52 --> Language Class Initialized
INFO - 2024-08-01 19:56:52 --> Config Class Initialized
INFO - 2024-08-01 19:56:52 --> Loader Class Initialized
INFO - 2024-08-01 19:56:52 --> Helper loaded: url_helper
INFO - 2024-08-01 19:56:52 --> Helper loaded: file_helper
INFO - 2024-08-01 19:56:52 --> Helper loaded: form_helper
INFO - 2024-08-01 19:56:52 --> Helper loaded: my_helper
INFO - 2024-08-01 19:56:52 --> Database Driver Class Initialized
INFO - 2024-08-01 19:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 19:56:52 --> Controller Class Initialized
INFO - 2024-08-01 19:56:52 --> Helper loaded: cookie_helper
INFO - 2024-08-01 19:56:52 --> Config Class Initialized
INFO - 2024-08-01 19:56:52 --> Hooks Class Initialized
DEBUG - 2024-08-01 19:56:52 --> UTF-8 Support Enabled
INFO - 2024-08-01 19:56:52 --> Utf8 Class Initialized
INFO - 2024-08-01 19:56:52 --> URI Class Initialized
INFO - 2024-08-01 19:56:52 --> Router Class Initialized
INFO - 2024-08-01 19:56:52 --> Output Class Initialized
INFO - 2024-08-01 19:56:52 --> Security Class Initialized
DEBUG - 2024-08-01 19:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 19:56:52 --> Input Class Initialized
INFO - 2024-08-01 19:56:52 --> Language Class Initialized
INFO - 2024-08-01 19:56:52 --> Language Class Initialized
INFO - 2024-08-01 19:56:52 --> Config Class Initialized
INFO - 2024-08-01 19:56:52 --> Loader Class Initialized
INFO - 2024-08-01 19:56:52 --> Helper loaded: url_helper
INFO - 2024-08-01 19:56:52 --> Helper loaded: file_helper
INFO - 2024-08-01 19:56:52 --> Helper loaded: form_helper
INFO - 2024-08-01 19:56:52 --> Helper loaded: my_helper
INFO - 2024-08-01 19:56:52 --> Database Driver Class Initialized
INFO - 2024-08-01 19:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 19:56:52 --> Controller Class Initialized
DEBUG - 2024-08-01 19:56:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-01 19:56:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 19:56:52 --> Final output sent to browser
DEBUG - 2024-08-01 19:56:52 --> Total execution time: 0.0408
INFO - 2024-08-01 19:57:22 --> Config Class Initialized
INFO - 2024-08-01 19:57:22 --> Hooks Class Initialized
DEBUG - 2024-08-01 19:57:22 --> UTF-8 Support Enabled
INFO - 2024-08-01 19:57:22 --> Utf8 Class Initialized
INFO - 2024-08-01 19:57:22 --> URI Class Initialized
INFO - 2024-08-01 19:57:22 --> Router Class Initialized
INFO - 2024-08-01 19:57:22 --> Output Class Initialized
INFO - 2024-08-01 19:57:22 --> Security Class Initialized
DEBUG - 2024-08-01 19:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 19:57:22 --> Input Class Initialized
INFO - 2024-08-01 19:57:22 --> Language Class Initialized
INFO - 2024-08-01 19:57:22 --> Language Class Initialized
INFO - 2024-08-01 19:57:22 --> Config Class Initialized
INFO - 2024-08-01 19:57:22 --> Loader Class Initialized
INFO - 2024-08-01 19:57:22 --> Helper loaded: url_helper
INFO - 2024-08-01 19:57:22 --> Helper loaded: file_helper
INFO - 2024-08-01 19:57:22 --> Helper loaded: form_helper
INFO - 2024-08-01 19:57:22 --> Helper loaded: my_helper
INFO - 2024-08-01 19:57:22 --> Database Driver Class Initialized
INFO - 2024-08-01 19:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 19:57:22 --> Controller Class Initialized
INFO - 2024-08-01 19:57:22 --> Helper loaded: cookie_helper
INFO - 2024-08-01 19:57:22 --> Final output sent to browser
DEBUG - 2024-08-01 19:57:22 --> Total execution time: 0.0288
INFO - 2024-08-01 19:57:22 --> Config Class Initialized
INFO - 2024-08-01 19:57:22 --> Hooks Class Initialized
DEBUG - 2024-08-01 19:57:22 --> UTF-8 Support Enabled
INFO - 2024-08-01 19:57:22 --> Utf8 Class Initialized
INFO - 2024-08-01 19:57:23 --> URI Class Initialized
INFO - 2024-08-01 19:57:23 --> Router Class Initialized
INFO - 2024-08-01 19:57:23 --> Output Class Initialized
INFO - 2024-08-01 19:57:23 --> Security Class Initialized
DEBUG - 2024-08-01 19:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 19:57:23 --> Input Class Initialized
INFO - 2024-08-01 19:57:23 --> Language Class Initialized
INFO - 2024-08-01 19:57:23 --> Language Class Initialized
INFO - 2024-08-01 19:57:23 --> Config Class Initialized
INFO - 2024-08-01 19:57:23 --> Loader Class Initialized
INFO - 2024-08-01 19:57:23 --> Helper loaded: url_helper
INFO - 2024-08-01 19:57:23 --> Helper loaded: file_helper
INFO - 2024-08-01 19:57:23 --> Helper loaded: form_helper
INFO - 2024-08-01 19:57:23 --> Helper loaded: my_helper
INFO - 2024-08-01 19:57:23 --> Database Driver Class Initialized
INFO - 2024-08-01 19:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 19:57:23 --> Controller Class Initialized
INFO - 2024-08-01 19:57:23 --> Helper loaded: cookie_helper
INFO - 2024-08-01 19:57:23 --> Config Class Initialized
INFO - 2024-08-01 19:57:23 --> Hooks Class Initialized
DEBUG - 2024-08-01 19:57:23 --> UTF-8 Support Enabled
INFO - 2024-08-01 19:57:23 --> Utf8 Class Initialized
INFO - 2024-08-01 19:57:23 --> URI Class Initialized
INFO - 2024-08-01 19:57:23 --> Router Class Initialized
INFO - 2024-08-01 19:57:23 --> Output Class Initialized
INFO - 2024-08-01 19:57:23 --> Security Class Initialized
DEBUG - 2024-08-01 19:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 19:57:23 --> Input Class Initialized
INFO - 2024-08-01 19:57:23 --> Language Class Initialized
INFO - 2024-08-01 19:57:23 --> Language Class Initialized
INFO - 2024-08-01 19:57:23 --> Config Class Initialized
INFO - 2024-08-01 19:57:23 --> Loader Class Initialized
INFO - 2024-08-01 19:57:23 --> Helper loaded: url_helper
INFO - 2024-08-01 19:57:23 --> Helper loaded: file_helper
INFO - 2024-08-01 19:57:23 --> Helper loaded: form_helper
INFO - 2024-08-01 19:57:23 --> Helper loaded: my_helper
INFO - 2024-08-01 19:57:23 --> Database Driver Class Initialized
INFO - 2024-08-01 19:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 19:57:23 --> Controller Class Initialized
DEBUG - 2024-08-01 19:57:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-01 19:57:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 19:57:23 --> Final output sent to browser
DEBUG - 2024-08-01 19:57:23 --> Total execution time: 0.0944
INFO - 2024-08-01 21:44:39 --> Config Class Initialized
INFO - 2024-08-01 21:44:39 --> Hooks Class Initialized
DEBUG - 2024-08-01 21:44:39 --> UTF-8 Support Enabled
INFO - 2024-08-01 21:44:39 --> Utf8 Class Initialized
INFO - 2024-08-01 21:44:39 --> URI Class Initialized
INFO - 2024-08-01 21:44:39 --> Router Class Initialized
INFO - 2024-08-01 21:44:39 --> Output Class Initialized
INFO - 2024-08-01 21:44:39 --> Security Class Initialized
DEBUG - 2024-08-01 21:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 21:44:39 --> Input Class Initialized
INFO - 2024-08-01 21:44:39 --> Language Class Initialized
INFO - 2024-08-01 21:44:39 --> Language Class Initialized
INFO - 2024-08-01 21:44:39 --> Config Class Initialized
INFO - 2024-08-01 21:44:39 --> Loader Class Initialized
INFO - 2024-08-01 21:44:39 --> Helper loaded: url_helper
INFO - 2024-08-01 21:44:39 --> Helper loaded: file_helper
INFO - 2024-08-01 21:44:39 --> Helper loaded: form_helper
INFO - 2024-08-01 21:44:39 --> Helper loaded: my_helper
INFO - 2024-08-01 21:44:39 --> Database Driver Class Initialized
INFO - 2024-08-01 21:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 21:44:39 --> Controller Class Initialized
INFO - 2024-08-01 21:44:39 --> Helper loaded: cookie_helper
INFO - 2024-08-01 21:44:39 --> Final output sent to browser
DEBUG - 2024-08-01 21:44:39 --> Total execution time: 0.0877
INFO - 2024-08-01 21:44:40 --> Config Class Initialized
INFO - 2024-08-01 21:44:40 --> Hooks Class Initialized
DEBUG - 2024-08-01 21:44:40 --> UTF-8 Support Enabled
INFO - 2024-08-01 21:44:40 --> Utf8 Class Initialized
INFO - 2024-08-01 21:44:40 --> URI Class Initialized
INFO - 2024-08-01 21:44:40 --> Router Class Initialized
INFO - 2024-08-01 21:44:40 --> Output Class Initialized
INFO - 2024-08-01 21:44:40 --> Security Class Initialized
DEBUG - 2024-08-01 21:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 21:44:40 --> Input Class Initialized
INFO - 2024-08-01 21:44:40 --> Language Class Initialized
INFO - 2024-08-01 21:44:40 --> Language Class Initialized
INFO - 2024-08-01 21:44:40 --> Config Class Initialized
INFO - 2024-08-01 21:44:40 --> Loader Class Initialized
INFO - 2024-08-01 21:44:40 --> Helper loaded: url_helper
INFO - 2024-08-01 21:44:40 --> Helper loaded: file_helper
INFO - 2024-08-01 21:44:40 --> Helper loaded: form_helper
INFO - 2024-08-01 21:44:40 --> Helper loaded: my_helper
INFO - 2024-08-01 21:44:40 --> Database Driver Class Initialized
INFO - 2024-08-01 21:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 21:44:40 --> Controller Class Initialized
INFO - 2024-08-01 21:44:40 --> Helper loaded: cookie_helper
INFO - 2024-08-01 21:44:40 --> Config Class Initialized
INFO - 2024-08-01 21:44:40 --> Hooks Class Initialized
DEBUG - 2024-08-01 21:44:40 --> UTF-8 Support Enabled
INFO - 2024-08-01 21:44:40 --> Utf8 Class Initialized
INFO - 2024-08-01 21:44:40 --> URI Class Initialized
INFO - 2024-08-01 21:44:40 --> Router Class Initialized
INFO - 2024-08-01 21:44:40 --> Output Class Initialized
INFO - 2024-08-01 21:44:40 --> Security Class Initialized
DEBUG - 2024-08-01 21:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-01 21:44:40 --> Input Class Initialized
INFO - 2024-08-01 21:44:40 --> Language Class Initialized
INFO - 2024-08-01 21:44:40 --> Language Class Initialized
INFO - 2024-08-01 21:44:40 --> Config Class Initialized
INFO - 2024-08-01 21:44:40 --> Loader Class Initialized
INFO - 2024-08-01 21:44:40 --> Helper loaded: url_helper
INFO - 2024-08-01 21:44:40 --> Helper loaded: file_helper
INFO - 2024-08-01 21:44:40 --> Helper loaded: form_helper
INFO - 2024-08-01 21:44:40 --> Helper loaded: my_helper
INFO - 2024-08-01 21:44:40 --> Database Driver Class Initialized
INFO - 2024-08-01 21:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-01 21:44:40 --> Controller Class Initialized
DEBUG - 2024-08-01 21:44:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-01 21:44:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-01 21:44:40 --> Final output sent to browser
DEBUG - 2024-08-01 21:44:40 --> Total execution time: 0.0359
