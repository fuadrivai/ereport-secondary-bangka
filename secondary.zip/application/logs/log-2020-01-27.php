<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-01-27 02:41:19 --> Config Class Initialized
INFO - 2020-01-27 02:41:19 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:41:19 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:41:19 --> Utf8 Class Initialized
INFO - 2020-01-27 02:41:19 --> URI Class Initialized
INFO - 2020-01-27 02:41:19 --> Router Class Initialized
INFO - 2020-01-27 02:41:19 --> Output Class Initialized
INFO - 2020-01-27 02:41:19 --> Security Class Initialized
DEBUG - 2020-01-27 02:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:41:19 --> Input Class Initialized
INFO - 2020-01-27 02:41:19 --> Language Class Initialized
INFO - 2020-01-27 02:41:19 --> Language Class Initialized
INFO - 2020-01-27 02:41:19 --> Config Class Initialized
INFO - 2020-01-27 02:41:19 --> Loader Class Initialized
INFO - 2020-01-27 02:41:20 --> Helper loaded: url_helper
INFO - 2020-01-27 02:41:20 --> Helper loaded: file_helper
INFO - 2020-01-27 02:41:20 --> Helper loaded: form_helper
INFO - 2020-01-27 02:41:20 --> Helper loaded: my_helper
INFO - 2020-01-27 02:41:20 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:41:20 --> Controller Class Initialized
INFO - 2020-01-27 02:41:20 --> Config Class Initialized
INFO - 2020-01-27 02:41:20 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:41:20 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:41:20 --> Utf8 Class Initialized
INFO - 2020-01-27 02:41:20 --> URI Class Initialized
INFO - 2020-01-27 02:41:20 --> Router Class Initialized
INFO - 2020-01-27 02:41:20 --> Output Class Initialized
INFO - 2020-01-27 02:41:20 --> Security Class Initialized
DEBUG - 2020-01-27 02:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:41:20 --> Input Class Initialized
INFO - 2020-01-27 02:41:20 --> Language Class Initialized
INFO - 2020-01-27 02:41:20 --> Language Class Initialized
INFO - 2020-01-27 02:41:20 --> Config Class Initialized
INFO - 2020-01-27 02:41:20 --> Loader Class Initialized
INFO - 2020-01-27 02:41:20 --> Helper loaded: url_helper
INFO - 2020-01-27 02:41:20 --> Helper loaded: file_helper
INFO - 2020-01-27 02:41:20 --> Helper loaded: form_helper
INFO - 2020-01-27 02:41:20 --> Helper loaded: my_helper
INFO - 2020-01-27 02:41:20 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:41:20 --> Controller Class Initialized
DEBUG - 2020-01-27 02:41:20 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-27 02:41:20 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 02:41:20 --> Final output sent to browser
DEBUG - 2020-01-27 02:41:20 --> Total execution time: 0.3451
INFO - 2020-01-27 02:41:38 --> Config Class Initialized
INFO - 2020-01-27 02:41:38 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:41:38 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:41:38 --> Utf8 Class Initialized
INFO - 2020-01-27 02:41:38 --> URI Class Initialized
INFO - 2020-01-27 02:41:38 --> Router Class Initialized
INFO - 2020-01-27 02:41:38 --> Output Class Initialized
INFO - 2020-01-27 02:41:38 --> Security Class Initialized
DEBUG - 2020-01-27 02:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:41:38 --> Input Class Initialized
INFO - 2020-01-27 02:41:38 --> Language Class Initialized
INFO - 2020-01-27 02:41:38 --> Language Class Initialized
INFO - 2020-01-27 02:41:38 --> Config Class Initialized
INFO - 2020-01-27 02:41:38 --> Loader Class Initialized
INFO - 2020-01-27 02:41:38 --> Helper loaded: url_helper
INFO - 2020-01-27 02:41:38 --> Helper loaded: file_helper
INFO - 2020-01-27 02:41:38 --> Helper loaded: form_helper
INFO - 2020-01-27 02:41:38 --> Helper loaded: my_helper
INFO - 2020-01-27 02:41:38 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:41:38 --> Controller Class Initialized
INFO - 2020-01-27 02:41:38 --> Final output sent to browser
DEBUG - 2020-01-27 02:41:38 --> Total execution time: 0.3112
INFO - 2020-01-27 02:41:43 --> Config Class Initialized
INFO - 2020-01-27 02:41:43 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:41:43 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:41:43 --> Utf8 Class Initialized
INFO - 2020-01-27 02:41:43 --> URI Class Initialized
INFO - 2020-01-27 02:41:43 --> Router Class Initialized
INFO - 2020-01-27 02:41:43 --> Output Class Initialized
INFO - 2020-01-27 02:41:43 --> Security Class Initialized
DEBUG - 2020-01-27 02:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:41:43 --> Input Class Initialized
INFO - 2020-01-27 02:41:43 --> Language Class Initialized
INFO - 2020-01-27 02:41:43 --> Language Class Initialized
INFO - 2020-01-27 02:41:43 --> Config Class Initialized
INFO - 2020-01-27 02:41:43 --> Loader Class Initialized
INFO - 2020-01-27 02:41:43 --> Helper loaded: url_helper
INFO - 2020-01-27 02:41:43 --> Helper loaded: file_helper
INFO - 2020-01-27 02:41:43 --> Helper loaded: form_helper
INFO - 2020-01-27 02:41:43 --> Helper loaded: my_helper
INFO - 2020-01-27 02:41:43 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:41:43 --> Controller Class Initialized
INFO - 2020-01-27 02:41:44 --> Helper loaded: cookie_helper
INFO - 2020-01-27 02:41:44 --> Final output sent to browser
DEBUG - 2020-01-27 02:41:44 --> Total execution time: 0.3109
INFO - 2020-01-27 02:41:46 --> Config Class Initialized
INFO - 2020-01-27 02:41:46 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:41:46 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:41:46 --> Utf8 Class Initialized
INFO - 2020-01-27 02:41:46 --> URI Class Initialized
INFO - 2020-01-27 02:41:46 --> Router Class Initialized
INFO - 2020-01-27 02:41:46 --> Output Class Initialized
INFO - 2020-01-27 02:41:46 --> Security Class Initialized
DEBUG - 2020-01-27 02:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:41:46 --> Input Class Initialized
INFO - 2020-01-27 02:41:46 --> Language Class Initialized
INFO - 2020-01-27 02:41:46 --> Language Class Initialized
INFO - 2020-01-27 02:41:46 --> Config Class Initialized
INFO - 2020-01-27 02:41:46 --> Loader Class Initialized
INFO - 2020-01-27 02:41:46 --> Helper loaded: url_helper
INFO - 2020-01-27 02:41:46 --> Helper loaded: file_helper
INFO - 2020-01-27 02:41:46 --> Helper loaded: form_helper
INFO - 2020-01-27 02:41:46 --> Helper loaded: my_helper
INFO - 2020-01-27 02:41:46 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:41:46 --> Controller Class Initialized
DEBUG - 2020-01-27 02:41:46 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-27 02:41:46 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 02:41:46 --> Final output sent to browser
DEBUG - 2020-01-27 02:41:46 --> Total execution time: 0.4114
INFO - 2020-01-27 02:41:49 --> Config Class Initialized
INFO - 2020-01-27 02:41:49 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:41:49 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:41:49 --> Utf8 Class Initialized
INFO - 2020-01-27 02:41:49 --> URI Class Initialized
INFO - 2020-01-27 02:41:49 --> Router Class Initialized
INFO - 2020-01-27 02:41:49 --> Output Class Initialized
INFO - 2020-01-27 02:41:49 --> Security Class Initialized
DEBUG - 2020-01-27 02:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:41:49 --> Input Class Initialized
INFO - 2020-01-27 02:41:49 --> Language Class Initialized
INFO - 2020-01-27 02:41:49 --> Language Class Initialized
INFO - 2020-01-27 02:41:49 --> Config Class Initialized
INFO - 2020-01-27 02:41:49 --> Loader Class Initialized
INFO - 2020-01-27 02:41:49 --> Helper loaded: url_helper
INFO - 2020-01-27 02:41:49 --> Helper loaded: file_helper
INFO - 2020-01-27 02:41:49 --> Helper loaded: form_helper
INFO - 2020-01-27 02:41:49 --> Helper loaded: my_helper
INFO - 2020-01-27 02:41:49 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:41:49 --> Controller Class Initialized
DEBUG - 2020-01-27 02:41:49 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_guru/views/list.php
DEBUG - 2020-01-27 02:41:49 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 02:41:49 --> Final output sent to browser
DEBUG - 2020-01-27 02:41:49 --> Total execution time: 0.3098
INFO - 2020-01-27 02:41:49 --> Config Class Initialized
INFO - 2020-01-27 02:41:49 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:41:49 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:41:49 --> Utf8 Class Initialized
INFO - 2020-01-27 02:41:49 --> URI Class Initialized
INFO - 2020-01-27 02:41:49 --> Router Class Initialized
INFO - 2020-01-27 02:41:49 --> Output Class Initialized
INFO - 2020-01-27 02:41:49 --> Security Class Initialized
DEBUG - 2020-01-27 02:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:41:49 --> Input Class Initialized
INFO - 2020-01-27 02:41:49 --> Language Class Initialized
INFO - 2020-01-27 02:41:49 --> Language Class Initialized
INFO - 2020-01-27 02:41:49 --> Config Class Initialized
INFO - 2020-01-27 02:41:49 --> Loader Class Initialized
INFO - 2020-01-27 02:41:49 --> Helper loaded: url_helper
INFO - 2020-01-27 02:41:49 --> Helper loaded: file_helper
INFO - 2020-01-27 02:41:49 --> Helper loaded: form_helper
INFO - 2020-01-27 02:41:49 --> Helper loaded: my_helper
INFO - 2020-01-27 02:41:49 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:41:49 --> Controller Class Initialized
INFO - 2020-01-27 02:41:58 --> Config Class Initialized
INFO - 2020-01-27 02:41:58 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:41:58 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:41:58 --> Utf8 Class Initialized
INFO - 2020-01-27 02:41:58 --> URI Class Initialized
INFO - 2020-01-27 02:41:58 --> Router Class Initialized
INFO - 2020-01-27 02:41:58 --> Output Class Initialized
INFO - 2020-01-27 02:41:58 --> Security Class Initialized
DEBUG - 2020-01-27 02:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:41:58 --> Input Class Initialized
INFO - 2020-01-27 02:41:58 --> Language Class Initialized
INFO - 2020-01-27 02:41:58 --> Language Class Initialized
INFO - 2020-01-27 02:41:58 --> Config Class Initialized
INFO - 2020-01-27 02:41:58 --> Loader Class Initialized
INFO - 2020-01-27 02:41:58 --> Helper loaded: url_helper
INFO - 2020-01-27 02:41:58 --> Helper loaded: file_helper
INFO - 2020-01-27 02:41:58 --> Helper loaded: form_helper
INFO - 2020-01-27 02:41:58 --> Helper loaded: my_helper
INFO - 2020-01-27 02:41:58 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:41:58 --> Controller Class Initialized
INFO - 2020-01-27 02:41:58 --> Helper loaded: cookie_helper
INFO - 2020-01-27 02:41:58 --> Config Class Initialized
INFO - 2020-01-27 02:41:58 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:41:58 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:41:58 --> Utf8 Class Initialized
INFO - 2020-01-27 02:41:58 --> URI Class Initialized
INFO - 2020-01-27 02:41:58 --> Router Class Initialized
INFO - 2020-01-27 02:41:58 --> Output Class Initialized
INFO - 2020-01-27 02:41:58 --> Security Class Initialized
DEBUG - 2020-01-27 02:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:41:58 --> Input Class Initialized
INFO - 2020-01-27 02:41:58 --> Language Class Initialized
INFO - 2020-01-27 02:41:58 --> Language Class Initialized
INFO - 2020-01-27 02:41:58 --> Config Class Initialized
INFO - 2020-01-27 02:41:58 --> Loader Class Initialized
INFO - 2020-01-27 02:41:58 --> Helper loaded: url_helper
INFO - 2020-01-27 02:41:58 --> Helper loaded: file_helper
INFO - 2020-01-27 02:41:58 --> Helper loaded: form_helper
INFO - 2020-01-27 02:41:58 --> Helper loaded: my_helper
INFO - 2020-01-27 02:41:58 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:41:58 --> Controller Class Initialized
INFO - 2020-01-27 02:41:58 --> Config Class Initialized
INFO - 2020-01-27 02:41:58 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:41:58 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:41:58 --> Utf8 Class Initialized
INFO - 2020-01-27 02:41:58 --> URI Class Initialized
INFO - 2020-01-27 02:41:58 --> Router Class Initialized
INFO - 2020-01-27 02:41:58 --> Output Class Initialized
INFO - 2020-01-27 02:41:58 --> Security Class Initialized
DEBUG - 2020-01-27 02:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:41:58 --> Input Class Initialized
INFO - 2020-01-27 02:41:58 --> Language Class Initialized
INFO - 2020-01-27 02:41:58 --> Language Class Initialized
INFO - 2020-01-27 02:41:58 --> Config Class Initialized
INFO - 2020-01-27 02:41:58 --> Loader Class Initialized
INFO - 2020-01-27 02:41:58 --> Helper loaded: url_helper
INFO - 2020-01-27 02:41:58 --> Helper loaded: file_helper
INFO - 2020-01-27 02:41:58 --> Helper loaded: form_helper
INFO - 2020-01-27 02:41:58 --> Helper loaded: my_helper
INFO - 2020-01-27 02:41:58 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:41:58 --> Controller Class Initialized
DEBUG - 2020-01-27 02:41:58 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-27 02:41:59 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 02:41:59 --> Final output sent to browser
DEBUG - 2020-01-27 02:41:59 --> Total execution time: 0.3049
INFO - 2020-01-27 02:42:04 --> Config Class Initialized
INFO - 2020-01-27 02:42:04 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:42:04 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:42:04 --> Utf8 Class Initialized
INFO - 2020-01-27 02:42:04 --> URI Class Initialized
INFO - 2020-01-27 02:42:04 --> Router Class Initialized
INFO - 2020-01-27 02:42:04 --> Output Class Initialized
INFO - 2020-01-27 02:42:04 --> Security Class Initialized
DEBUG - 2020-01-27 02:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:42:04 --> Input Class Initialized
INFO - 2020-01-27 02:42:04 --> Language Class Initialized
INFO - 2020-01-27 02:42:04 --> Language Class Initialized
INFO - 2020-01-27 02:42:04 --> Config Class Initialized
INFO - 2020-01-27 02:42:04 --> Loader Class Initialized
INFO - 2020-01-27 02:42:04 --> Helper loaded: url_helper
INFO - 2020-01-27 02:42:04 --> Helper loaded: file_helper
INFO - 2020-01-27 02:42:04 --> Helper loaded: form_helper
INFO - 2020-01-27 02:42:04 --> Helper loaded: my_helper
INFO - 2020-01-27 02:42:05 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:42:05 --> Controller Class Initialized
INFO - 2020-01-27 02:42:05 --> Helper loaded: cookie_helper
INFO - 2020-01-27 02:42:05 --> Final output sent to browser
DEBUG - 2020-01-27 02:42:05 --> Total execution time: 0.3246
INFO - 2020-01-27 02:42:06 --> Config Class Initialized
INFO - 2020-01-27 02:42:06 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:42:06 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:42:06 --> Utf8 Class Initialized
INFO - 2020-01-27 02:42:06 --> URI Class Initialized
INFO - 2020-01-27 02:42:06 --> Router Class Initialized
INFO - 2020-01-27 02:42:06 --> Output Class Initialized
INFO - 2020-01-27 02:42:06 --> Security Class Initialized
DEBUG - 2020-01-27 02:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:42:06 --> Input Class Initialized
INFO - 2020-01-27 02:42:06 --> Language Class Initialized
INFO - 2020-01-27 02:42:06 --> Language Class Initialized
INFO - 2020-01-27 02:42:06 --> Config Class Initialized
INFO - 2020-01-27 02:42:06 --> Loader Class Initialized
INFO - 2020-01-27 02:42:06 --> Helper loaded: url_helper
INFO - 2020-01-27 02:42:06 --> Helper loaded: file_helper
INFO - 2020-01-27 02:42:06 --> Helper loaded: form_helper
INFO - 2020-01-27 02:42:06 --> Helper loaded: my_helper
INFO - 2020-01-27 02:42:06 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:42:06 --> Controller Class Initialized
DEBUG - 2020-01-27 02:42:06 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-27 02:42:06 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 02:42:06 --> Final output sent to browser
DEBUG - 2020-01-27 02:42:06 --> Total execution time: 0.3550
INFO - 2020-01-27 02:42:09 --> Config Class Initialized
INFO - 2020-01-27 02:42:09 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:42:09 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:42:09 --> Utf8 Class Initialized
INFO - 2020-01-27 02:42:09 --> URI Class Initialized
INFO - 2020-01-27 02:42:09 --> Router Class Initialized
INFO - 2020-01-27 02:42:09 --> Output Class Initialized
INFO - 2020-01-27 02:42:09 --> Security Class Initialized
DEBUG - 2020-01-27 02:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:42:09 --> Input Class Initialized
INFO - 2020-01-27 02:42:09 --> Language Class Initialized
INFO - 2020-01-27 02:42:09 --> Language Class Initialized
INFO - 2020-01-27 02:42:09 --> Config Class Initialized
INFO - 2020-01-27 02:42:09 --> Loader Class Initialized
INFO - 2020-01-27 02:42:09 --> Helper loaded: url_helper
INFO - 2020-01-27 02:42:09 --> Helper loaded: file_helper
INFO - 2020-01-27 02:42:09 --> Helper loaded: form_helper
INFO - 2020-01-27 02:42:09 --> Helper loaded: my_helper
INFO - 2020-01-27 02:42:09 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:42:09 --> Controller Class Initialized
DEBUG - 2020-01-27 02:42:09 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-01-27 02:42:09 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 02:42:09 --> Final output sent to browser
DEBUG - 2020-01-27 02:42:09 --> Total execution time: 0.3733
INFO - 2020-01-27 02:42:15 --> Config Class Initialized
INFO - 2020-01-27 02:42:15 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:42:15 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:42:15 --> Utf8 Class Initialized
INFO - 2020-01-27 02:42:15 --> URI Class Initialized
INFO - 2020-01-27 02:42:15 --> Router Class Initialized
INFO - 2020-01-27 02:42:15 --> Output Class Initialized
INFO - 2020-01-27 02:42:15 --> Security Class Initialized
DEBUG - 2020-01-27 02:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:42:15 --> Input Class Initialized
INFO - 2020-01-27 02:42:15 --> Language Class Initialized
INFO - 2020-01-27 02:42:15 --> Language Class Initialized
INFO - 2020-01-27 02:42:15 --> Config Class Initialized
INFO - 2020-01-27 02:42:15 --> Loader Class Initialized
INFO - 2020-01-27 02:42:15 --> Helper loaded: url_helper
INFO - 2020-01-27 02:42:16 --> Helper loaded: file_helper
INFO - 2020-01-27 02:42:16 --> Helper loaded: form_helper
INFO - 2020-01-27 02:42:16 --> Helper loaded: my_helper
INFO - 2020-01-27 02:42:16 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:42:16 --> Controller Class Initialized
DEBUG - 2020-01-27 02:42:16 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-01-27 02:42:16 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 02:42:16 --> Final output sent to browser
DEBUG - 2020-01-27 02:42:16 --> Total execution time: 0.3789
INFO - 2020-01-27 02:42:40 --> Config Class Initialized
INFO - 2020-01-27 02:42:40 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:42:40 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:42:40 --> Utf8 Class Initialized
INFO - 2020-01-27 02:42:40 --> URI Class Initialized
INFO - 2020-01-27 02:42:40 --> Router Class Initialized
INFO - 2020-01-27 02:42:40 --> Output Class Initialized
INFO - 2020-01-27 02:42:40 --> Security Class Initialized
DEBUG - 2020-01-27 02:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:42:40 --> Input Class Initialized
INFO - 2020-01-27 02:42:40 --> Language Class Initialized
INFO - 2020-01-27 02:42:40 --> Language Class Initialized
INFO - 2020-01-27 02:42:40 --> Config Class Initialized
INFO - 2020-01-27 02:42:40 --> Loader Class Initialized
INFO - 2020-01-27 02:42:40 --> Helper loaded: url_helper
INFO - 2020-01-27 02:42:40 --> Helper loaded: file_helper
INFO - 2020-01-27 02:42:40 --> Helper loaded: form_helper
INFO - 2020-01-27 02:42:40 --> Helper loaded: my_helper
INFO - 2020-01-27 02:42:40 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:42:40 --> Controller Class Initialized
DEBUG - 2020-01-27 02:42:40 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-01-27 02:42:40 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 02:42:40 --> Final output sent to browser
DEBUG - 2020-01-27 02:42:40 --> Total execution time: 0.3677
INFO - 2020-01-27 02:42:59 --> Config Class Initialized
INFO - 2020-01-27 02:42:59 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:42:59 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:42:59 --> Utf8 Class Initialized
INFO - 2020-01-27 02:42:59 --> URI Class Initialized
INFO - 2020-01-27 02:42:59 --> Router Class Initialized
INFO - 2020-01-27 02:42:59 --> Output Class Initialized
INFO - 2020-01-27 02:42:59 --> Security Class Initialized
DEBUG - 2020-01-27 02:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:42:59 --> Input Class Initialized
INFO - 2020-01-27 02:42:59 --> Language Class Initialized
INFO - 2020-01-27 02:42:59 --> Language Class Initialized
INFO - 2020-01-27 02:42:59 --> Config Class Initialized
INFO - 2020-01-27 02:42:59 --> Loader Class Initialized
INFO - 2020-01-27 02:42:59 --> Helper loaded: url_helper
INFO - 2020-01-27 02:42:59 --> Helper loaded: file_helper
INFO - 2020-01-27 02:42:59 --> Helper loaded: form_helper
INFO - 2020-01-27 02:42:59 --> Helper loaded: my_helper
INFO - 2020-01-27 02:42:59 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:42:59 --> Controller Class Initialized
INFO - 2020-01-27 02:42:59 --> Final output sent to browser
DEBUG - 2020-01-27 02:42:59 --> Total execution time: 0.3036
INFO - 2020-01-27 02:43:31 --> Config Class Initialized
INFO - 2020-01-27 02:43:31 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:43:31 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:43:31 --> Utf8 Class Initialized
INFO - 2020-01-27 02:43:31 --> URI Class Initialized
INFO - 2020-01-27 02:43:31 --> Router Class Initialized
INFO - 2020-01-27 02:43:31 --> Output Class Initialized
INFO - 2020-01-27 02:43:31 --> Security Class Initialized
DEBUG - 2020-01-27 02:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:43:31 --> Input Class Initialized
INFO - 2020-01-27 02:43:31 --> Language Class Initialized
INFO - 2020-01-27 02:43:31 --> Language Class Initialized
INFO - 2020-01-27 02:43:31 --> Config Class Initialized
INFO - 2020-01-27 02:43:31 --> Loader Class Initialized
INFO - 2020-01-27 02:43:31 --> Helper loaded: url_helper
INFO - 2020-01-27 02:43:31 --> Helper loaded: file_helper
INFO - 2020-01-27 02:43:31 --> Helper loaded: form_helper
INFO - 2020-01-27 02:43:31 --> Helper loaded: my_helper
INFO - 2020-01-27 02:43:31 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:43:31 --> Controller Class Initialized
INFO - 2020-01-27 02:43:31 --> Final output sent to browser
DEBUG - 2020-01-27 02:43:31 --> Total execution time: 0.2831
INFO - 2020-01-27 02:43:39 --> Config Class Initialized
INFO - 2020-01-27 02:43:39 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:43:39 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:43:39 --> Utf8 Class Initialized
INFO - 2020-01-27 02:43:39 --> URI Class Initialized
INFO - 2020-01-27 02:43:39 --> Router Class Initialized
INFO - 2020-01-27 02:43:39 --> Output Class Initialized
INFO - 2020-01-27 02:43:39 --> Security Class Initialized
DEBUG - 2020-01-27 02:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:43:39 --> Input Class Initialized
INFO - 2020-01-27 02:43:39 --> Language Class Initialized
INFO - 2020-01-27 02:43:39 --> Language Class Initialized
INFO - 2020-01-27 02:43:39 --> Config Class Initialized
INFO - 2020-01-27 02:43:39 --> Loader Class Initialized
INFO - 2020-01-27 02:43:39 --> Helper loaded: url_helper
INFO - 2020-01-27 02:43:39 --> Helper loaded: file_helper
INFO - 2020-01-27 02:43:39 --> Helper loaded: form_helper
INFO - 2020-01-27 02:43:39 --> Helper loaded: my_helper
INFO - 2020-01-27 02:43:39 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:43:39 --> Controller Class Initialized
DEBUG - 2020-01-27 02:43:39 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_absensi/views/list.php
DEBUG - 2020-01-27 02:43:39 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 02:43:39 --> Final output sent to browser
DEBUG - 2020-01-27 02:43:39 --> Total execution time: 0.4200
INFO - 2020-01-27 02:43:40 --> Config Class Initialized
INFO - 2020-01-27 02:43:40 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:43:40 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:43:40 --> Utf8 Class Initialized
INFO - 2020-01-27 02:43:40 --> URI Class Initialized
INFO - 2020-01-27 02:43:40 --> Router Class Initialized
INFO - 2020-01-27 02:43:40 --> Output Class Initialized
INFO - 2020-01-27 02:43:40 --> Security Class Initialized
DEBUG - 2020-01-27 02:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:43:40 --> Input Class Initialized
INFO - 2020-01-27 02:43:40 --> Language Class Initialized
INFO - 2020-01-27 02:43:40 --> Language Class Initialized
INFO - 2020-01-27 02:43:40 --> Config Class Initialized
INFO - 2020-01-27 02:43:40 --> Loader Class Initialized
INFO - 2020-01-27 02:43:40 --> Helper loaded: url_helper
INFO - 2020-01-27 02:43:40 --> Helper loaded: file_helper
INFO - 2020-01-27 02:43:40 --> Helper loaded: form_helper
INFO - 2020-01-27 02:43:40 --> Helper loaded: my_helper
INFO - 2020-01-27 02:43:40 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:43:40 --> Controller Class Initialized
DEBUG - 2020-01-27 02:43:40 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_ekstra/views/list.php
DEBUG - 2020-01-27 02:43:40 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 02:43:40 --> Final output sent to browser
DEBUG - 2020-01-27 02:43:40 --> Total execution time: 0.3910
INFO - 2020-01-27 02:43:43 --> Config Class Initialized
INFO - 2020-01-27 02:43:43 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:43:43 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:43:43 --> Utf8 Class Initialized
INFO - 2020-01-27 02:43:43 --> URI Class Initialized
INFO - 2020-01-27 02:43:43 --> Router Class Initialized
INFO - 2020-01-27 02:43:43 --> Output Class Initialized
INFO - 2020-01-27 02:43:43 --> Security Class Initialized
DEBUG - 2020-01-27 02:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:43:43 --> Input Class Initialized
INFO - 2020-01-27 02:43:43 --> Language Class Initialized
INFO - 2020-01-27 02:43:43 --> Language Class Initialized
INFO - 2020-01-27 02:43:43 --> Config Class Initialized
INFO - 2020-01-27 02:43:43 --> Loader Class Initialized
INFO - 2020-01-27 02:43:43 --> Helper loaded: url_helper
INFO - 2020-01-27 02:43:43 --> Helper loaded: file_helper
INFO - 2020-01-27 02:43:43 --> Helper loaded: form_helper
INFO - 2020-01-27 02:43:43 --> Helper loaded: my_helper
INFO - 2020-01-27 02:43:43 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:43:43 --> Controller Class Initialized
DEBUG - 2020-01-27 02:43:43 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/list.php
DEBUG - 2020-01-27 02:43:43 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 02:43:43 --> Final output sent to browser
DEBUG - 2020-01-27 02:43:43 --> Total execution time: 0.3212
INFO - 2020-01-27 02:43:45 --> Config Class Initialized
INFO - 2020-01-27 02:43:45 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:43:45 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:43:45 --> Utf8 Class Initialized
INFO - 2020-01-27 02:43:45 --> URI Class Initialized
INFO - 2020-01-27 02:43:45 --> Router Class Initialized
INFO - 2020-01-27 02:43:45 --> Output Class Initialized
INFO - 2020-01-27 02:43:45 --> Security Class Initialized
DEBUG - 2020-01-27 02:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:43:45 --> Input Class Initialized
INFO - 2020-01-27 02:43:46 --> Language Class Initialized
INFO - 2020-01-27 02:43:46 --> Language Class Initialized
INFO - 2020-01-27 02:43:46 --> Config Class Initialized
INFO - 2020-01-27 02:43:46 --> Loader Class Initialized
INFO - 2020-01-27 02:43:46 --> Helper loaded: url_helper
INFO - 2020-01-27 02:43:46 --> Helper loaded: file_helper
INFO - 2020-01-27 02:43:46 --> Helper loaded: form_helper
INFO - 2020-01-27 02:43:46 --> Helper loaded: my_helper
INFO - 2020-01-27 02:43:46 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:43:46 --> Controller Class Initialized
DEBUG - 2020-01-27 02:43:46 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2020-01-27 02:43:46 --> Final output sent to browser
DEBUG - 2020-01-27 02:43:46 --> Total execution time: 0.3500
INFO - 2020-01-27 02:43:49 --> Config Class Initialized
INFO - 2020-01-27 02:43:49 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:43:49 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:43:49 --> Utf8 Class Initialized
INFO - 2020-01-27 02:43:49 --> URI Class Initialized
INFO - 2020-01-27 02:43:49 --> Router Class Initialized
INFO - 2020-01-27 02:43:49 --> Output Class Initialized
INFO - 2020-01-27 02:43:49 --> Security Class Initialized
DEBUG - 2020-01-27 02:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:43:49 --> Input Class Initialized
INFO - 2020-01-27 02:43:49 --> Language Class Initialized
INFO - 2020-01-27 02:43:49 --> Language Class Initialized
INFO - 2020-01-27 02:43:49 --> Config Class Initialized
INFO - 2020-01-27 02:43:49 --> Loader Class Initialized
INFO - 2020-01-27 02:43:49 --> Helper loaded: url_helper
INFO - 2020-01-27 02:43:49 --> Helper loaded: file_helper
INFO - 2020-01-27 02:43:49 --> Helper loaded: form_helper
INFO - 2020-01-27 02:43:49 --> Helper loaded: my_helper
INFO - 2020-01-27 02:43:49 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:43:49 --> Controller Class Initialized
DEBUG - 2020-01-27 02:43:50 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2020-01-27 02:43:50 --> Final output sent to browser
DEBUG - 2020-01-27 02:43:50 --> Total execution time: 0.3107
INFO - 2020-01-27 02:43:53 --> Config Class Initialized
INFO - 2020-01-27 02:43:53 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:43:53 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:43:53 --> Utf8 Class Initialized
INFO - 2020-01-27 02:43:53 --> URI Class Initialized
INFO - 2020-01-27 02:43:53 --> Router Class Initialized
INFO - 2020-01-27 02:43:53 --> Output Class Initialized
INFO - 2020-01-27 02:43:53 --> Security Class Initialized
DEBUG - 2020-01-27 02:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:43:53 --> Input Class Initialized
INFO - 2020-01-27 02:43:53 --> Language Class Initialized
INFO - 2020-01-27 02:43:53 --> Language Class Initialized
INFO - 2020-01-27 02:43:53 --> Config Class Initialized
INFO - 2020-01-27 02:43:53 --> Loader Class Initialized
INFO - 2020-01-27 02:43:53 --> Helper loaded: url_helper
INFO - 2020-01-27 02:43:54 --> Helper loaded: file_helper
INFO - 2020-01-27 02:43:54 --> Helper loaded: form_helper
INFO - 2020-01-27 02:43:54 --> Helper loaded: my_helper
INFO - 2020-01-27 02:43:54 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:43:54 --> Controller Class Initialized
DEBUG - 2020-01-27 02:43:54 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2020-01-27 02:43:54 --> Final output sent to browser
DEBUG - 2020-01-27 02:43:54 --> Total execution time: 0.3220
INFO - 2020-01-27 02:43:58 --> Config Class Initialized
INFO - 2020-01-27 02:43:58 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:43:58 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:43:58 --> Utf8 Class Initialized
INFO - 2020-01-27 02:43:58 --> URI Class Initialized
INFO - 2020-01-27 02:43:58 --> Router Class Initialized
INFO - 2020-01-27 02:43:58 --> Output Class Initialized
INFO - 2020-01-27 02:43:58 --> Security Class Initialized
DEBUG - 2020-01-27 02:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:43:58 --> Input Class Initialized
INFO - 2020-01-27 02:43:58 --> Language Class Initialized
INFO - 2020-01-27 02:43:58 --> Language Class Initialized
INFO - 2020-01-27 02:43:58 --> Config Class Initialized
INFO - 2020-01-27 02:43:58 --> Loader Class Initialized
INFO - 2020-01-27 02:43:58 --> Helper loaded: url_helper
INFO - 2020-01-27 02:43:58 --> Helper loaded: file_helper
INFO - 2020-01-27 02:43:58 --> Helper loaded: form_helper
INFO - 2020-01-27 02:43:58 --> Helper loaded: my_helper
INFO - 2020-01-27 02:43:58 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:43:58 --> Controller Class Initialized
DEBUG - 2020-01-27 02:43:58 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-01-27 02:43:58 --> Final output sent to browser
DEBUG - 2020-01-27 02:43:58 --> Total execution time: 0.3929
INFO - 2020-01-27 02:44:44 --> Config Class Initialized
INFO - 2020-01-27 02:44:44 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:44:44 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:44:44 --> Utf8 Class Initialized
INFO - 2020-01-27 02:44:44 --> URI Class Initialized
INFO - 2020-01-27 02:44:44 --> Router Class Initialized
INFO - 2020-01-27 02:44:44 --> Output Class Initialized
INFO - 2020-01-27 02:44:44 --> Security Class Initialized
DEBUG - 2020-01-27 02:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:44:44 --> Input Class Initialized
INFO - 2020-01-27 02:44:44 --> Language Class Initialized
INFO - 2020-01-27 02:44:45 --> Language Class Initialized
INFO - 2020-01-27 02:44:45 --> Config Class Initialized
INFO - 2020-01-27 02:44:45 --> Loader Class Initialized
INFO - 2020-01-27 02:44:45 --> Helper loaded: url_helper
INFO - 2020-01-27 02:44:45 --> Helper loaded: file_helper
INFO - 2020-01-27 02:44:45 --> Helper loaded: form_helper
INFO - 2020-01-27 02:44:45 --> Helper loaded: my_helper
INFO - 2020-01-27 02:44:45 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:44:45 --> Controller Class Initialized
DEBUG - 2020-01-27 02:44:45 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/cetak_prestasi.php
INFO - 2020-01-27 02:44:45 --> Final output sent to browser
DEBUG - 2020-01-27 02:44:45 --> Total execution time: 0.4215
INFO - 2020-01-27 02:44:55 --> Config Class Initialized
INFO - 2020-01-27 02:44:55 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:44:55 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:44:55 --> Utf8 Class Initialized
INFO - 2020-01-27 02:44:55 --> URI Class Initialized
INFO - 2020-01-27 02:44:55 --> Router Class Initialized
INFO - 2020-01-27 02:44:55 --> Output Class Initialized
INFO - 2020-01-27 02:44:55 --> Security Class Initialized
DEBUG - 2020-01-27 02:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:44:55 --> Input Class Initialized
INFO - 2020-01-27 02:44:55 --> Language Class Initialized
INFO - 2020-01-27 02:44:55 --> Language Class Initialized
INFO - 2020-01-27 02:44:55 --> Config Class Initialized
INFO - 2020-01-27 02:44:55 --> Loader Class Initialized
INFO - 2020-01-27 02:44:55 --> Helper loaded: url_helper
INFO - 2020-01-27 02:44:55 --> Helper loaded: file_helper
INFO - 2020-01-27 02:44:55 --> Helper loaded: form_helper
INFO - 2020-01-27 02:44:55 --> Helper loaded: my_helper
INFO - 2020-01-27 02:44:55 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:44:55 --> Controller Class Initialized
DEBUG - 2020-01-27 02:44:55 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-01-27 02:44:55 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 02:44:55 --> Final output sent to browser
DEBUG - 2020-01-27 02:44:55 --> Total execution time: 0.3384
INFO - 2020-01-27 02:44:57 --> Config Class Initialized
INFO - 2020-01-27 02:44:57 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:44:57 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:44:57 --> Utf8 Class Initialized
INFO - 2020-01-27 02:44:57 --> URI Class Initialized
INFO - 2020-01-27 02:44:57 --> Router Class Initialized
INFO - 2020-01-27 02:44:57 --> Output Class Initialized
INFO - 2020-01-27 02:44:57 --> Security Class Initialized
DEBUG - 2020-01-27 02:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:44:57 --> Input Class Initialized
INFO - 2020-01-27 02:44:57 --> Language Class Initialized
INFO - 2020-01-27 02:44:57 --> Language Class Initialized
INFO - 2020-01-27 02:44:57 --> Config Class Initialized
INFO - 2020-01-27 02:44:57 --> Loader Class Initialized
INFO - 2020-01-27 02:44:57 --> Helper loaded: url_helper
INFO - 2020-01-27 02:44:57 --> Helper loaded: file_helper
INFO - 2020-01-27 02:44:57 --> Helper loaded: form_helper
INFO - 2020-01-27 02:44:57 --> Helper loaded: my_helper
INFO - 2020-01-27 02:44:57 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:44:57 --> Controller Class Initialized
DEBUG - 2020-01-27 02:44:57 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_leger/views/cetak.php
INFO - 2020-01-27 02:44:57 --> Final output sent to browser
DEBUG - 2020-01-27 02:44:57 --> Total execution time: 0.3055
INFO - 2020-01-27 02:45:17 --> Config Class Initialized
INFO - 2020-01-27 02:45:17 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:45:17 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:45:17 --> Utf8 Class Initialized
INFO - 2020-01-27 02:45:17 --> URI Class Initialized
INFO - 2020-01-27 02:45:17 --> Router Class Initialized
INFO - 2020-01-27 02:45:17 --> Output Class Initialized
INFO - 2020-01-27 02:45:17 --> Security Class Initialized
DEBUG - 2020-01-27 02:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:45:17 --> Input Class Initialized
INFO - 2020-01-27 02:45:17 --> Language Class Initialized
INFO - 2020-01-27 02:45:17 --> Language Class Initialized
INFO - 2020-01-27 02:45:17 --> Config Class Initialized
INFO - 2020-01-27 02:45:17 --> Loader Class Initialized
INFO - 2020-01-27 02:45:17 --> Helper loaded: url_helper
INFO - 2020-01-27 02:45:17 --> Helper loaded: file_helper
INFO - 2020-01-27 02:45:17 --> Helper loaded: form_helper
INFO - 2020-01-27 02:45:17 --> Helper loaded: my_helper
INFO - 2020-01-27 02:45:17 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:45:17 --> Controller Class Initialized
DEBUG - 2020-01-27 02:45:17 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_leger/views/cetak_ekstra.php
INFO - 2020-01-27 02:45:17 --> Final output sent to browser
DEBUG - 2020-01-27 02:45:17 --> Total execution time: 0.9953
INFO - 2020-01-27 02:45:21 --> Config Class Initialized
INFO - 2020-01-27 02:45:21 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:45:21 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:45:21 --> Utf8 Class Initialized
INFO - 2020-01-27 02:45:21 --> URI Class Initialized
INFO - 2020-01-27 02:45:21 --> Router Class Initialized
INFO - 2020-01-27 02:45:21 --> Output Class Initialized
INFO - 2020-01-27 02:45:22 --> Security Class Initialized
DEBUG - 2020-01-27 02:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:45:22 --> Input Class Initialized
INFO - 2020-01-27 02:45:22 --> Language Class Initialized
INFO - 2020-01-27 02:45:22 --> Language Class Initialized
INFO - 2020-01-27 02:45:22 --> Config Class Initialized
INFO - 2020-01-27 02:45:22 --> Loader Class Initialized
INFO - 2020-01-27 02:45:22 --> Helper loaded: url_helper
INFO - 2020-01-27 02:45:22 --> Helper loaded: file_helper
INFO - 2020-01-27 02:45:22 --> Helper loaded: form_helper
INFO - 2020-01-27 02:45:22 --> Helper loaded: my_helper
INFO - 2020-01-27 02:45:22 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:45:22 --> Controller Class Initialized
DEBUG - 2020-01-27 02:45:22 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/list.php
DEBUG - 2020-01-27 02:45:22 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 02:45:22 --> Final output sent to browser
DEBUG - 2020-01-27 02:45:22 --> Total execution time: 0.3772
INFO - 2020-01-27 02:45:23 --> Config Class Initialized
INFO - 2020-01-27 02:45:23 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:45:23 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:45:23 --> Utf8 Class Initialized
INFO - 2020-01-27 02:45:23 --> URI Class Initialized
INFO - 2020-01-27 02:45:23 --> Router Class Initialized
INFO - 2020-01-27 02:45:24 --> Output Class Initialized
INFO - 2020-01-27 02:45:24 --> Security Class Initialized
DEBUG - 2020-01-27 02:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:45:24 --> Input Class Initialized
INFO - 2020-01-27 02:45:24 --> Language Class Initialized
INFO - 2020-01-27 02:45:24 --> Language Class Initialized
INFO - 2020-01-27 02:45:24 --> Config Class Initialized
INFO - 2020-01-27 02:45:24 --> Loader Class Initialized
INFO - 2020-01-27 02:45:24 --> Helper loaded: url_helper
INFO - 2020-01-27 02:45:24 --> Helper loaded: file_helper
INFO - 2020-01-27 02:45:24 --> Helper loaded: form_helper
INFO - 2020-01-27 02:45:24 --> Helper loaded: my_helper
INFO - 2020-01-27 02:45:24 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:45:24 --> Controller Class Initialized
DEBUG - 2020-01-27 02:45:24 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-01-27 02:45:24 --> Final output sent to browser
DEBUG - 2020-01-27 02:45:24 --> Total execution time: 0.3812
INFO - 2020-01-27 02:49:05 --> Config Class Initialized
INFO - 2020-01-27 02:49:05 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:49:05 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:49:05 --> Utf8 Class Initialized
INFO - 2020-01-27 02:49:05 --> URI Class Initialized
INFO - 2020-01-27 02:49:05 --> Router Class Initialized
INFO - 2020-01-27 02:49:05 --> Output Class Initialized
INFO - 2020-01-27 02:49:05 --> Security Class Initialized
DEBUG - 2020-01-27 02:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:49:05 --> Input Class Initialized
INFO - 2020-01-27 02:49:05 --> Language Class Initialized
INFO - 2020-01-27 02:49:05 --> Language Class Initialized
INFO - 2020-01-27 02:49:05 --> Config Class Initialized
INFO - 2020-01-27 02:49:05 --> Loader Class Initialized
INFO - 2020-01-27 02:49:05 --> Helper loaded: url_helper
INFO - 2020-01-27 02:49:05 --> Helper loaded: file_helper
INFO - 2020-01-27 02:49:05 --> Helper loaded: form_helper
INFO - 2020-01-27 02:49:05 --> Helper loaded: my_helper
INFO - 2020-01-27 02:49:05 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:49:05 --> Controller Class Initialized
DEBUG - 2020-01-27 02:49:05 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-01-27 02:49:05 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 02:49:05 --> Final output sent to browser
DEBUG - 2020-01-27 02:49:05 --> Total execution time: 0.3842
INFO - 2020-01-27 02:49:18 --> Config Class Initialized
INFO - 2020-01-27 02:49:18 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:49:18 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:49:18 --> Utf8 Class Initialized
INFO - 2020-01-27 02:49:18 --> URI Class Initialized
INFO - 2020-01-27 02:49:18 --> Router Class Initialized
INFO - 2020-01-27 02:49:18 --> Output Class Initialized
INFO - 2020-01-27 02:49:18 --> Security Class Initialized
DEBUG - 2020-01-27 02:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:49:18 --> Input Class Initialized
INFO - 2020-01-27 02:49:18 --> Language Class Initialized
INFO - 2020-01-27 02:49:18 --> Language Class Initialized
INFO - 2020-01-27 02:49:18 --> Config Class Initialized
INFO - 2020-01-27 02:49:18 --> Loader Class Initialized
INFO - 2020-01-27 02:49:18 --> Helper loaded: url_helper
INFO - 2020-01-27 02:49:18 --> Helper loaded: file_helper
INFO - 2020-01-27 02:49:18 --> Helper loaded: form_helper
INFO - 2020-01-27 02:49:18 --> Helper loaded: my_helper
INFO - 2020-01-27 02:49:18 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:49:18 --> Controller Class Initialized
DEBUG - 2020-01-27 02:49:18 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_sikap_sp/views/cetak.php
INFO - 2020-01-27 02:49:18 --> Final output sent to browser
DEBUG - 2020-01-27 02:49:18 --> Total execution time: 0.3207
INFO - 2020-01-27 02:51:34 --> Config Class Initialized
INFO - 2020-01-27 02:51:34 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:51:34 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:51:34 --> Utf8 Class Initialized
INFO - 2020-01-27 02:51:34 --> URI Class Initialized
INFO - 2020-01-27 02:51:34 --> Router Class Initialized
INFO - 2020-01-27 02:51:34 --> Output Class Initialized
INFO - 2020-01-27 02:51:34 --> Security Class Initialized
DEBUG - 2020-01-27 02:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:51:34 --> Input Class Initialized
INFO - 2020-01-27 02:51:34 --> Language Class Initialized
INFO - 2020-01-27 02:51:34 --> Language Class Initialized
INFO - 2020-01-27 02:51:34 --> Config Class Initialized
INFO - 2020-01-27 02:51:34 --> Loader Class Initialized
INFO - 2020-01-27 02:51:34 --> Helper loaded: url_helper
INFO - 2020-01-27 02:51:34 --> Helper loaded: file_helper
INFO - 2020-01-27 02:51:34 --> Helper loaded: form_helper
INFO - 2020-01-27 02:51:34 --> Helper loaded: my_helper
INFO - 2020-01-27 02:51:35 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:51:35 --> Controller Class Initialized
INFO - 2020-01-27 02:51:35 --> Final output sent to browser
DEBUG - 2020-01-27 02:51:35 --> Total execution time: 0.2923
INFO - 2020-01-27 02:51:38 --> Config Class Initialized
INFO - 2020-01-27 02:51:38 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:51:38 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:51:38 --> Utf8 Class Initialized
INFO - 2020-01-27 02:51:38 --> URI Class Initialized
INFO - 2020-01-27 02:51:38 --> Router Class Initialized
INFO - 2020-01-27 02:51:38 --> Output Class Initialized
INFO - 2020-01-27 02:51:38 --> Security Class Initialized
DEBUG - 2020-01-27 02:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:51:38 --> Input Class Initialized
INFO - 2020-01-27 02:51:38 --> Language Class Initialized
INFO - 2020-01-27 02:51:38 --> Language Class Initialized
INFO - 2020-01-27 02:51:38 --> Config Class Initialized
INFO - 2020-01-27 02:51:38 --> Loader Class Initialized
INFO - 2020-01-27 02:51:38 --> Helper loaded: url_helper
INFO - 2020-01-27 02:51:38 --> Helper loaded: file_helper
INFO - 2020-01-27 02:51:38 --> Helper loaded: form_helper
INFO - 2020-01-27 02:51:38 --> Helper loaded: my_helper
INFO - 2020-01-27 02:51:38 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:51:38 --> Controller Class Initialized
DEBUG - 2020-01-27 02:51:38 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_sikap_sp/views/cetak.php
INFO - 2020-01-27 02:51:38 --> Final output sent to browser
DEBUG - 2020-01-27 02:51:38 --> Total execution time: 0.3256
INFO - 2020-01-27 02:51:41 --> Config Class Initialized
INFO - 2020-01-27 02:51:41 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:51:41 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:51:41 --> Utf8 Class Initialized
INFO - 2020-01-27 02:51:41 --> URI Class Initialized
INFO - 2020-01-27 02:51:41 --> Router Class Initialized
INFO - 2020-01-27 02:51:41 --> Output Class Initialized
INFO - 2020-01-27 02:51:41 --> Security Class Initialized
DEBUG - 2020-01-27 02:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:51:41 --> Input Class Initialized
INFO - 2020-01-27 02:51:41 --> Language Class Initialized
INFO - 2020-01-27 02:51:41 --> Language Class Initialized
INFO - 2020-01-27 02:51:41 --> Config Class Initialized
INFO - 2020-01-27 02:51:41 --> Loader Class Initialized
INFO - 2020-01-27 02:51:41 --> Helper loaded: url_helper
INFO - 2020-01-27 02:51:41 --> Helper loaded: file_helper
INFO - 2020-01-27 02:51:41 --> Helper loaded: form_helper
INFO - 2020-01-27 02:51:41 --> Helper loaded: my_helper
INFO - 2020-01-27 02:51:41 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:51:41 --> Controller Class Initialized
DEBUG - 2020-01-27 02:51:41 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-01-27 02:51:41 --> Final output sent to browser
DEBUG - 2020-01-27 02:51:41 --> Total execution time: 0.3331
INFO - 2020-01-27 02:53:21 --> Config Class Initialized
INFO - 2020-01-27 02:53:21 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:53:21 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:53:21 --> Utf8 Class Initialized
INFO - 2020-01-27 02:53:21 --> URI Class Initialized
INFO - 2020-01-27 02:53:21 --> Router Class Initialized
INFO - 2020-01-27 02:53:21 --> Output Class Initialized
INFO - 2020-01-27 02:53:21 --> Security Class Initialized
DEBUG - 2020-01-27 02:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:53:21 --> Input Class Initialized
INFO - 2020-01-27 02:53:21 --> Language Class Initialized
INFO - 2020-01-27 02:53:21 --> Language Class Initialized
INFO - 2020-01-27 02:53:21 --> Config Class Initialized
INFO - 2020-01-27 02:53:21 --> Loader Class Initialized
INFO - 2020-01-27 02:53:21 --> Helper loaded: url_helper
INFO - 2020-01-27 02:53:21 --> Helper loaded: file_helper
INFO - 2020-01-27 02:53:21 --> Helper loaded: form_helper
INFO - 2020-01-27 02:53:21 --> Helper loaded: my_helper
INFO - 2020-01-27 02:53:21 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:53:21 --> Controller Class Initialized
DEBUG - 2020-01-27 02:53:21 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-01-27 02:53:21 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 02:53:21 --> Final output sent to browser
DEBUG - 2020-01-27 02:53:21 --> Total execution time: 0.3307
INFO - 2020-01-27 02:53:23 --> Config Class Initialized
INFO - 2020-01-27 02:53:23 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:53:23 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:53:23 --> Utf8 Class Initialized
INFO - 2020-01-27 02:53:23 --> URI Class Initialized
INFO - 2020-01-27 02:53:23 --> Router Class Initialized
INFO - 2020-01-27 02:53:23 --> Output Class Initialized
INFO - 2020-01-27 02:53:23 --> Security Class Initialized
DEBUG - 2020-01-27 02:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:53:23 --> Input Class Initialized
INFO - 2020-01-27 02:53:23 --> Language Class Initialized
INFO - 2020-01-27 02:53:23 --> Language Class Initialized
INFO - 2020-01-27 02:53:23 --> Config Class Initialized
INFO - 2020-01-27 02:53:23 --> Loader Class Initialized
INFO - 2020-01-27 02:53:23 --> Helper loaded: url_helper
INFO - 2020-01-27 02:53:23 --> Helper loaded: file_helper
INFO - 2020-01-27 02:53:23 --> Helper loaded: form_helper
INFO - 2020-01-27 02:53:23 --> Helper loaded: my_helper
INFO - 2020-01-27 02:53:23 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:53:23 --> Controller Class Initialized
DEBUG - 2020-01-27 02:53:23 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-01-27 02:53:23 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 02:53:23 --> Final output sent to browser
DEBUG - 2020-01-27 02:53:23 --> Total execution time: 0.3564
INFO - 2020-01-27 02:53:23 --> Config Class Initialized
INFO - 2020-01-27 02:53:23 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:53:23 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:53:24 --> Utf8 Class Initialized
INFO - 2020-01-27 02:53:24 --> URI Class Initialized
INFO - 2020-01-27 02:53:24 --> Router Class Initialized
INFO - 2020-01-27 02:53:24 --> Output Class Initialized
INFO - 2020-01-27 02:53:24 --> Security Class Initialized
DEBUG - 2020-01-27 02:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:53:24 --> Input Class Initialized
INFO - 2020-01-27 02:53:24 --> Language Class Initialized
INFO - 2020-01-27 02:53:24 --> Language Class Initialized
INFO - 2020-01-27 02:53:24 --> Config Class Initialized
INFO - 2020-01-27 02:53:24 --> Loader Class Initialized
INFO - 2020-01-27 02:53:24 --> Helper loaded: url_helper
INFO - 2020-01-27 02:53:24 --> Helper loaded: file_helper
INFO - 2020-01-27 02:53:24 --> Helper loaded: form_helper
INFO - 2020-01-27 02:53:24 --> Helper loaded: my_helper
INFO - 2020-01-27 02:53:24 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:53:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:53:24 --> Controller Class Initialized
INFO - 2020-01-27 02:55:16 --> Config Class Initialized
INFO - 2020-01-27 02:55:16 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:55:16 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:55:16 --> Utf8 Class Initialized
INFO - 2020-01-27 02:55:16 --> URI Class Initialized
INFO - 2020-01-27 02:55:16 --> Router Class Initialized
INFO - 2020-01-27 02:55:16 --> Output Class Initialized
INFO - 2020-01-27 02:55:16 --> Security Class Initialized
DEBUG - 2020-01-27 02:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:55:16 --> Input Class Initialized
INFO - 2020-01-27 02:55:16 --> Language Class Initialized
INFO - 2020-01-27 02:55:16 --> Language Class Initialized
INFO - 2020-01-27 02:55:16 --> Config Class Initialized
INFO - 2020-01-27 02:55:16 --> Loader Class Initialized
INFO - 2020-01-27 02:55:16 --> Helper loaded: url_helper
INFO - 2020-01-27 02:55:16 --> Helper loaded: file_helper
INFO - 2020-01-27 02:55:17 --> Helper loaded: form_helper
INFO - 2020-01-27 02:55:17 --> Helper loaded: my_helper
INFO - 2020-01-27 02:55:17 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:55:17 --> Controller Class Initialized
INFO - 2020-01-27 02:55:17 --> Final output sent to browser
DEBUG - 2020-01-27 02:55:17 --> Total execution time: 0.2835
INFO - 2020-01-27 02:55:18 --> Config Class Initialized
INFO - 2020-01-27 02:55:18 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:55:18 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:55:18 --> Utf8 Class Initialized
INFO - 2020-01-27 02:55:18 --> URI Class Initialized
INFO - 2020-01-27 02:55:18 --> Router Class Initialized
INFO - 2020-01-27 02:55:18 --> Output Class Initialized
INFO - 2020-01-27 02:55:18 --> Security Class Initialized
DEBUG - 2020-01-27 02:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:55:18 --> Input Class Initialized
INFO - 2020-01-27 02:55:18 --> Language Class Initialized
INFO - 2020-01-27 02:55:18 --> Language Class Initialized
INFO - 2020-01-27 02:55:18 --> Config Class Initialized
INFO - 2020-01-27 02:55:18 --> Loader Class Initialized
INFO - 2020-01-27 02:55:18 --> Helper loaded: url_helper
INFO - 2020-01-27 02:55:18 --> Helper loaded: file_helper
INFO - 2020-01-27 02:55:18 --> Helper loaded: form_helper
INFO - 2020-01-27 02:55:18 --> Helper loaded: my_helper
INFO - 2020-01-27 02:55:18 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:55:18 --> Controller Class Initialized
INFO - 2020-01-27 02:55:18 --> Final output sent to browser
DEBUG - 2020-01-27 02:55:18 --> Total execution time: 0.2529
INFO - 2020-01-27 02:55:19 --> Config Class Initialized
INFO - 2020-01-27 02:55:19 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:55:19 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:55:19 --> Utf8 Class Initialized
INFO - 2020-01-27 02:55:19 --> URI Class Initialized
INFO - 2020-01-27 02:55:19 --> Router Class Initialized
INFO - 2020-01-27 02:55:19 --> Output Class Initialized
INFO - 2020-01-27 02:55:19 --> Security Class Initialized
DEBUG - 2020-01-27 02:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:55:19 --> Input Class Initialized
INFO - 2020-01-27 02:55:19 --> Language Class Initialized
INFO - 2020-01-27 02:55:19 --> Language Class Initialized
INFO - 2020-01-27 02:55:19 --> Config Class Initialized
INFO - 2020-01-27 02:55:19 --> Loader Class Initialized
INFO - 2020-01-27 02:55:19 --> Helper loaded: url_helper
INFO - 2020-01-27 02:55:19 --> Helper loaded: file_helper
INFO - 2020-01-27 02:55:19 --> Helper loaded: form_helper
INFO - 2020-01-27 02:55:19 --> Helper loaded: my_helper
INFO - 2020-01-27 02:55:19 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:55:19 --> Controller Class Initialized
INFO - 2020-01-27 02:55:19 --> Final output sent to browser
DEBUG - 2020-01-27 02:55:19 --> Total execution time: 0.2826
INFO - 2020-01-27 02:55:21 --> Config Class Initialized
INFO - 2020-01-27 02:55:21 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:55:21 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:55:21 --> Utf8 Class Initialized
INFO - 2020-01-27 02:55:21 --> URI Class Initialized
INFO - 2020-01-27 02:55:21 --> Router Class Initialized
INFO - 2020-01-27 02:55:21 --> Output Class Initialized
INFO - 2020-01-27 02:55:21 --> Security Class Initialized
DEBUG - 2020-01-27 02:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:55:21 --> Input Class Initialized
INFO - 2020-01-27 02:55:21 --> Language Class Initialized
INFO - 2020-01-27 02:55:21 --> Language Class Initialized
INFO - 2020-01-27 02:55:21 --> Config Class Initialized
INFO - 2020-01-27 02:55:21 --> Loader Class Initialized
INFO - 2020-01-27 02:55:21 --> Helper loaded: url_helper
INFO - 2020-01-27 02:55:21 --> Helper loaded: file_helper
INFO - 2020-01-27 02:55:21 --> Helper loaded: form_helper
INFO - 2020-01-27 02:55:21 --> Helper loaded: my_helper
INFO - 2020-01-27 02:55:21 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:55:21 --> Controller Class Initialized
INFO - 2020-01-27 02:55:21 --> Final output sent to browser
DEBUG - 2020-01-27 02:55:21 --> Total execution time: 0.2826
INFO - 2020-01-27 02:55:41 --> Config Class Initialized
INFO - 2020-01-27 02:55:41 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:55:42 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:55:42 --> Utf8 Class Initialized
INFO - 2020-01-27 02:55:42 --> URI Class Initialized
INFO - 2020-01-27 02:55:42 --> Router Class Initialized
INFO - 2020-01-27 02:55:42 --> Output Class Initialized
INFO - 2020-01-27 02:55:42 --> Security Class Initialized
DEBUG - 2020-01-27 02:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:55:42 --> Input Class Initialized
INFO - 2020-01-27 02:55:42 --> Language Class Initialized
INFO - 2020-01-27 02:55:42 --> Language Class Initialized
INFO - 2020-01-27 02:55:42 --> Config Class Initialized
INFO - 2020-01-27 02:55:42 --> Loader Class Initialized
INFO - 2020-01-27 02:55:42 --> Helper loaded: url_helper
INFO - 2020-01-27 02:55:42 --> Helper loaded: file_helper
INFO - 2020-01-27 02:55:42 --> Helper loaded: form_helper
INFO - 2020-01-27 02:55:42 --> Helper loaded: my_helper
INFO - 2020-01-27 02:55:42 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:55:42 --> Controller Class Initialized
INFO - 2020-01-27 02:55:42 --> Final output sent to browser
DEBUG - 2020-01-27 02:55:42 --> Total execution time: 0.3498
INFO - 2020-01-27 02:56:48 --> Config Class Initialized
INFO - 2020-01-27 02:56:48 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:56:48 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:56:48 --> Utf8 Class Initialized
INFO - 2020-01-27 02:56:48 --> URI Class Initialized
INFO - 2020-01-27 02:56:48 --> Router Class Initialized
INFO - 2020-01-27 02:56:48 --> Output Class Initialized
INFO - 2020-01-27 02:56:48 --> Security Class Initialized
DEBUG - 2020-01-27 02:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:56:48 --> Input Class Initialized
INFO - 2020-01-27 02:56:48 --> Language Class Initialized
INFO - 2020-01-27 02:56:49 --> Language Class Initialized
INFO - 2020-01-27 02:56:49 --> Config Class Initialized
INFO - 2020-01-27 02:56:49 --> Loader Class Initialized
INFO - 2020-01-27 02:56:49 --> Helper loaded: url_helper
INFO - 2020-01-27 02:56:49 --> Helper loaded: file_helper
INFO - 2020-01-27 02:56:49 --> Helper loaded: form_helper
INFO - 2020-01-27 02:56:49 --> Helper loaded: my_helper
INFO - 2020-01-27 02:56:49 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:56:49 --> Controller Class Initialized
INFO - 2020-01-27 02:56:49 --> Final output sent to browser
DEBUG - 2020-01-27 02:56:49 --> Total execution time: 0.3207
INFO - 2020-01-27 02:56:49 --> Config Class Initialized
INFO - 2020-01-27 02:56:49 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:56:49 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:56:49 --> Utf8 Class Initialized
INFO - 2020-01-27 02:56:49 --> URI Class Initialized
INFO - 2020-01-27 02:56:49 --> Router Class Initialized
INFO - 2020-01-27 02:56:49 --> Output Class Initialized
INFO - 2020-01-27 02:56:49 --> Security Class Initialized
DEBUG - 2020-01-27 02:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:56:49 --> Input Class Initialized
INFO - 2020-01-27 02:56:49 --> Language Class Initialized
INFO - 2020-01-27 02:56:49 --> Language Class Initialized
INFO - 2020-01-27 02:56:49 --> Config Class Initialized
INFO - 2020-01-27 02:56:49 --> Loader Class Initialized
INFO - 2020-01-27 02:56:49 --> Helper loaded: url_helper
INFO - 2020-01-27 02:56:49 --> Helper loaded: file_helper
INFO - 2020-01-27 02:56:49 --> Helper loaded: form_helper
INFO - 2020-01-27 02:56:49 --> Helper loaded: my_helper
INFO - 2020-01-27 02:56:49 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:56:49 --> Controller Class Initialized
INFO - 2020-01-27 02:56:51 --> Config Class Initialized
INFO - 2020-01-27 02:56:51 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:56:51 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:56:51 --> Utf8 Class Initialized
INFO - 2020-01-27 02:56:51 --> URI Class Initialized
INFO - 2020-01-27 02:56:51 --> Router Class Initialized
INFO - 2020-01-27 02:56:51 --> Output Class Initialized
INFO - 2020-01-27 02:56:51 --> Security Class Initialized
DEBUG - 2020-01-27 02:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:56:51 --> Input Class Initialized
INFO - 2020-01-27 02:56:51 --> Language Class Initialized
INFO - 2020-01-27 02:56:51 --> Language Class Initialized
INFO - 2020-01-27 02:56:51 --> Config Class Initialized
INFO - 2020-01-27 02:56:51 --> Loader Class Initialized
INFO - 2020-01-27 02:56:51 --> Helper loaded: url_helper
INFO - 2020-01-27 02:56:51 --> Helper loaded: file_helper
INFO - 2020-01-27 02:56:51 --> Helper loaded: form_helper
INFO - 2020-01-27 02:56:51 --> Helper loaded: my_helper
INFO - 2020-01-27 02:56:51 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:56:51 --> Controller Class Initialized
INFO - 2020-01-27 02:56:51 --> Final output sent to browser
DEBUG - 2020-01-27 02:56:51 --> Total execution time: 0.3141
INFO - 2020-01-27 02:56:55 --> Config Class Initialized
INFO - 2020-01-27 02:56:55 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:56:55 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:56:55 --> Utf8 Class Initialized
INFO - 2020-01-27 02:56:55 --> URI Class Initialized
INFO - 2020-01-27 02:56:55 --> Router Class Initialized
INFO - 2020-01-27 02:56:55 --> Output Class Initialized
INFO - 2020-01-27 02:56:55 --> Security Class Initialized
DEBUG - 2020-01-27 02:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:56:55 --> Input Class Initialized
INFO - 2020-01-27 02:56:55 --> Language Class Initialized
INFO - 2020-01-27 02:56:55 --> Language Class Initialized
INFO - 2020-01-27 02:56:55 --> Config Class Initialized
INFO - 2020-01-27 02:56:55 --> Loader Class Initialized
INFO - 2020-01-27 02:56:55 --> Helper loaded: url_helper
INFO - 2020-01-27 02:56:55 --> Helper loaded: file_helper
INFO - 2020-01-27 02:56:55 --> Helper loaded: form_helper
INFO - 2020-01-27 02:56:55 --> Helper loaded: my_helper
INFO - 2020-01-27 02:56:55 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:56:55 --> Controller Class Initialized
INFO - 2020-01-27 02:56:55 --> Final output sent to browser
DEBUG - 2020-01-27 02:56:55 --> Total execution time: 0.3104
INFO - 2020-01-27 02:56:56 --> Config Class Initialized
INFO - 2020-01-27 02:56:56 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:56:56 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:56:56 --> Utf8 Class Initialized
INFO - 2020-01-27 02:56:56 --> URI Class Initialized
INFO - 2020-01-27 02:56:56 --> Router Class Initialized
INFO - 2020-01-27 02:56:56 --> Output Class Initialized
INFO - 2020-01-27 02:56:56 --> Security Class Initialized
DEBUG - 2020-01-27 02:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:56:56 --> Input Class Initialized
INFO - 2020-01-27 02:56:56 --> Language Class Initialized
INFO - 2020-01-27 02:56:56 --> Language Class Initialized
INFO - 2020-01-27 02:56:56 --> Config Class Initialized
INFO - 2020-01-27 02:56:56 --> Loader Class Initialized
INFO - 2020-01-27 02:56:56 --> Helper loaded: url_helper
INFO - 2020-01-27 02:56:56 --> Helper loaded: file_helper
INFO - 2020-01-27 02:56:56 --> Helper loaded: form_helper
INFO - 2020-01-27 02:56:56 --> Helper loaded: my_helper
INFO - 2020-01-27 02:56:56 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:56:56 --> Controller Class Initialized
INFO - 2020-01-27 02:56:56 --> Final output sent to browser
DEBUG - 2020-01-27 02:56:56 --> Total execution time: 0.2645
INFO - 2020-01-27 02:56:59 --> Config Class Initialized
INFO - 2020-01-27 02:56:59 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:56:59 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:56:59 --> Utf8 Class Initialized
INFO - 2020-01-27 02:56:59 --> URI Class Initialized
INFO - 2020-01-27 02:56:59 --> Router Class Initialized
INFO - 2020-01-27 02:56:59 --> Output Class Initialized
INFO - 2020-01-27 02:56:59 --> Security Class Initialized
DEBUG - 2020-01-27 02:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:56:59 --> Input Class Initialized
INFO - 2020-01-27 02:56:59 --> Language Class Initialized
INFO - 2020-01-27 02:56:59 --> Language Class Initialized
INFO - 2020-01-27 02:56:59 --> Config Class Initialized
INFO - 2020-01-27 02:56:59 --> Loader Class Initialized
INFO - 2020-01-27 02:56:59 --> Helper loaded: url_helper
INFO - 2020-01-27 02:56:59 --> Helper loaded: file_helper
INFO - 2020-01-27 02:56:59 --> Helper loaded: form_helper
INFO - 2020-01-27 02:56:59 --> Helper loaded: my_helper
INFO - 2020-01-27 02:56:59 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:56:59 --> Controller Class Initialized
INFO - 2020-01-27 02:56:59 --> Final output sent to browser
DEBUG - 2020-01-27 02:56:59 --> Total execution time: 0.2590
INFO - 2020-01-27 02:57:05 --> Config Class Initialized
INFO - 2020-01-27 02:57:05 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:57:05 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:57:05 --> Utf8 Class Initialized
INFO - 2020-01-27 02:57:05 --> URI Class Initialized
INFO - 2020-01-27 02:57:05 --> Router Class Initialized
INFO - 2020-01-27 02:57:05 --> Output Class Initialized
INFO - 2020-01-27 02:57:05 --> Security Class Initialized
DEBUG - 2020-01-27 02:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:57:05 --> Input Class Initialized
INFO - 2020-01-27 02:57:05 --> Language Class Initialized
INFO - 2020-01-27 02:57:05 --> Language Class Initialized
INFO - 2020-01-27 02:57:05 --> Config Class Initialized
INFO - 2020-01-27 02:57:05 --> Loader Class Initialized
INFO - 2020-01-27 02:57:05 --> Helper loaded: url_helper
INFO - 2020-01-27 02:57:05 --> Helper loaded: file_helper
INFO - 2020-01-27 02:57:05 --> Helper loaded: form_helper
INFO - 2020-01-27 02:57:05 --> Helper loaded: my_helper
INFO - 2020-01-27 02:57:05 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:57:05 --> Controller Class Initialized
INFO - 2020-01-27 02:57:05 --> Final output sent to browser
DEBUG - 2020-01-27 02:57:05 --> Total execution time: 0.3301
INFO - 2020-01-27 02:57:11 --> Config Class Initialized
INFO - 2020-01-27 02:57:11 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:57:11 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:57:11 --> Utf8 Class Initialized
INFO - 2020-01-27 02:57:11 --> URI Class Initialized
INFO - 2020-01-27 02:57:11 --> Router Class Initialized
INFO - 2020-01-27 02:57:11 --> Output Class Initialized
INFO - 2020-01-27 02:57:11 --> Security Class Initialized
DEBUG - 2020-01-27 02:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:57:11 --> Input Class Initialized
INFO - 2020-01-27 02:57:11 --> Language Class Initialized
INFO - 2020-01-27 02:57:11 --> Language Class Initialized
INFO - 2020-01-27 02:57:11 --> Config Class Initialized
INFO - 2020-01-27 02:57:11 --> Loader Class Initialized
INFO - 2020-01-27 02:57:11 --> Helper loaded: url_helper
INFO - 2020-01-27 02:57:11 --> Helper loaded: file_helper
INFO - 2020-01-27 02:57:11 --> Helper loaded: form_helper
INFO - 2020-01-27 02:57:11 --> Helper loaded: my_helper
INFO - 2020-01-27 02:57:11 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:57:11 --> Controller Class Initialized
INFO - 2020-01-27 02:57:11 --> Final output sent to browser
DEBUG - 2020-01-27 02:57:11 --> Total execution time: 0.3395
INFO - 2020-01-27 02:57:13 --> Config Class Initialized
INFO - 2020-01-27 02:57:13 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:57:13 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:57:13 --> Utf8 Class Initialized
INFO - 2020-01-27 02:57:13 --> URI Class Initialized
INFO - 2020-01-27 02:57:13 --> Router Class Initialized
INFO - 2020-01-27 02:57:13 --> Output Class Initialized
INFO - 2020-01-27 02:57:13 --> Security Class Initialized
DEBUG - 2020-01-27 02:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:57:13 --> Input Class Initialized
INFO - 2020-01-27 02:57:13 --> Language Class Initialized
INFO - 2020-01-27 02:57:13 --> Language Class Initialized
INFO - 2020-01-27 02:57:13 --> Config Class Initialized
INFO - 2020-01-27 02:57:13 --> Loader Class Initialized
INFO - 2020-01-27 02:57:13 --> Helper loaded: url_helper
INFO - 2020-01-27 02:57:13 --> Helper loaded: file_helper
INFO - 2020-01-27 02:57:13 --> Helper loaded: form_helper
INFO - 2020-01-27 02:57:13 --> Helper loaded: my_helper
INFO - 2020-01-27 02:57:13 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:57:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:57:13 --> Controller Class Initialized
INFO - 2020-01-27 02:57:13 --> Final output sent to browser
DEBUG - 2020-01-27 02:57:13 --> Total execution time: 0.2895
INFO - 2020-01-27 02:57:19 --> Config Class Initialized
INFO - 2020-01-27 02:57:19 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:57:19 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:57:19 --> Utf8 Class Initialized
INFO - 2020-01-27 02:57:19 --> URI Class Initialized
INFO - 2020-01-27 02:57:19 --> Router Class Initialized
INFO - 2020-01-27 02:57:19 --> Output Class Initialized
INFO - 2020-01-27 02:57:19 --> Security Class Initialized
DEBUG - 2020-01-27 02:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:57:19 --> Input Class Initialized
INFO - 2020-01-27 02:57:19 --> Language Class Initialized
INFO - 2020-01-27 02:57:19 --> Language Class Initialized
INFO - 2020-01-27 02:57:19 --> Config Class Initialized
INFO - 2020-01-27 02:57:19 --> Loader Class Initialized
INFO - 2020-01-27 02:57:19 --> Helper loaded: url_helper
INFO - 2020-01-27 02:57:19 --> Helper loaded: file_helper
INFO - 2020-01-27 02:57:19 --> Helper loaded: form_helper
INFO - 2020-01-27 02:57:19 --> Helper loaded: my_helper
INFO - 2020-01-27 02:57:19 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:57:19 --> Controller Class Initialized
DEBUG - 2020-01-27 02:57:19 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-01-27 02:57:19 --> Final output sent to browser
DEBUG - 2020-01-27 02:57:19 --> Total execution time: 0.3603
INFO - 2020-01-27 02:57:56 --> Config Class Initialized
INFO - 2020-01-27 02:57:56 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:57:56 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:57:56 --> Utf8 Class Initialized
INFO - 2020-01-27 02:57:56 --> URI Class Initialized
INFO - 2020-01-27 02:57:56 --> Router Class Initialized
INFO - 2020-01-27 02:57:56 --> Output Class Initialized
INFO - 2020-01-27 02:57:56 --> Security Class Initialized
DEBUG - 2020-01-27 02:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:57:56 --> Input Class Initialized
INFO - 2020-01-27 02:57:56 --> Language Class Initialized
INFO - 2020-01-27 02:57:56 --> Language Class Initialized
INFO - 2020-01-27 02:57:56 --> Config Class Initialized
INFO - 2020-01-27 02:57:56 --> Loader Class Initialized
INFO - 2020-01-27 02:57:56 --> Helper loaded: url_helper
INFO - 2020-01-27 02:57:56 --> Helper loaded: file_helper
INFO - 2020-01-27 02:57:56 --> Helper loaded: form_helper
INFO - 2020-01-27 02:57:56 --> Helper loaded: my_helper
INFO - 2020-01-27 02:57:56 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:57:56 --> Controller Class Initialized
DEBUG - 2020-01-27 02:57:56 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-01-27 02:57:56 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 02:57:56 --> Final output sent to browser
DEBUG - 2020-01-27 02:57:56 --> Total execution time: 0.3745
INFO - 2020-01-27 02:57:59 --> Config Class Initialized
INFO - 2020-01-27 02:57:59 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:57:59 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:57:59 --> Utf8 Class Initialized
INFO - 2020-01-27 02:57:59 --> URI Class Initialized
INFO - 2020-01-27 02:57:59 --> Router Class Initialized
INFO - 2020-01-27 02:57:59 --> Output Class Initialized
INFO - 2020-01-27 02:58:00 --> Security Class Initialized
DEBUG - 2020-01-27 02:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:58:00 --> Input Class Initialized
INFO - 2020-01-27 02:58:00 --> Language Class Initialized
INFO - 2020-01-27 02:58:00 --> Language Class Initialized
INFO - 2020-01-27 02:58:00 --> Config Class Initialized
INFO - 2020-01-27 02:58:00 --> Loader Class Initialized
INFO - 2020-01-27 02:58:00 --> Helper loaded: url_helper
INFO - 2020-01-27 02:58:00 --> Helper loaded: file_helper
INFO - 2020-01-27 02:58:00 --> Helper loaded: form_helper
INFO - 2020-01-27 02:58:00 --> Helper loaded: my_helper
INFO - 2020-01-27 02:58:00 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:58:00 --> Controller Class Initialized
DEBUG - 2020-01-27 02:58:00 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-01-27 02:58:00 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 02:58:00 --> Final output sent to browser
DEBUG - 2020-01-27 02:58:00 --> Total execution time: 0.3762
INFO - 2020-01-27 02:58:30 --> Config Class Initialized
INFO - 2020-01-27 02:58:30 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:58:30 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:58:30 --> Utf8 Class Initialized
INFO - 2020-01-27 02:58:30 --> URI Class Initialized
INFO - 2020-01-27 02:58:30 --> Router Class Initialized
INFO - 2020-01-27 02:58:30 --> Output Class Initialized
INFO - 2020-01-27 02:58:30 --> Security Class Initialized
DEBUG - 2020-01-27 02:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:58:30 --> Input Class Initialized
INFO - 2020-01-27 02:58:30 --> Language Class Initialized
INFO - 2020-01-27 02:58:30 --> Language Class Initialized
INFO - 2020-01-27 02:58:30 --> Config Class Initialized
INFO - 2020-01-27 02:58:30 --> Loader Class Initialized
INFO - 2020-01-27 02:58:31 --> Helper loaded: url_helper
INFO - 2020-01-27 02:58:31 --> Helper loaded: file_helper
INFO - 2020-01-27 02:58:31 --> Helper loaded: form_helper
INFO - 2020-01-27 02:58:31 --> Helper loaded: my_helper
INFO - 2020-01-27 02:58:31 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:58:31 --> Controller Class Initialized
INFO - 2020-01-27 02:58:31 --> Final output sent to browser
DEBUG - 2020-01-27 02:58:31 --> Total execution time: 0.3585
INFO - 2020-01-27 02:58:35 --> Config Class Initialized
INFO - 2020-01-27 02:58:35 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:58:35 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:58:35 --> Utf8 Class Initialized
INFO - 2020-01-27 02:58:35 --> URI Class Initialized
INFO - 2020-01-27 02:58:35 --> Router Class Initialized
INFO - 2020-01-27 02:58:35 --> Output Class Initialized
INFO - 2020-01-27 02:58:35 --> Security Class Initialized
DEBUG - 2020-01-27 02:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:58:35 --> Input Class Initialized
INFO - 2020-01-27 02:58:35 --> Language Class Initialized
INFO - 2020-01-27 02:58:35 --> Language Class Initialized
INFO - 2020-01-27 02:58:35 --> Config Class Initialized
INFO - 2020-01-27 02:58:35 --> Loader Class Initialized
INFO - 2020-01-27 02:58:35 --> Helper loaded: url_helper
INFO - 2020-01-27 02:58:35 --> Helper loaded: file_helper
INFO - 2020-01-27 02:58:35 --> Helper loaded: form_helper
INFO - 2020-01-27 02:58:35 --> Helper loaded: my_helper
INFO - 2020-01-27 02:58:35 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:58:36 --> Controller Class Initialized
DEBUG - 2020-01-27 02:58:36 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-01-27 02:58:36 --> Final output sent to browser
DEBUG - 2020-01-27 02:58:36 --> Total execution time: 0.3636
INFO - 2020-01-27 02:59:01 --> Config Class Initialized
INFO - 2020-01-27 02:59:01 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:59:01 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:59:01 --> Utf8 Class Initialized
INFO - 2020-01-27 02:59:01 --> URI Class Initialized
INFO - 2020-01-27 02:59:01 --> Router Class Initialized
INFO - 2020-01-27 02:59:01 --> Output Class Initialized
INFO - 2020-01-27 02:59:01 --> Security Class Initialized
DEBUG - 2020-01-27 02:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:59:01 --> Input Class Initialized
INFO - 2020-01-27 02:59:01 --> Language Class Initialized
INFO - 2020-01-27 02:59:01 --> Language Class Initialized
INFO - 2020-01-27 02:59:01 --> Config Class Initialized
INFO - 2020-01-27 02:59:01 --> Loader Class Initialized
INFO - 2020-01-27 02:59:01 --> Helper loaded: url_helper
INFO - 2020-01-27 02:59:01 --> Helper loaded: file_helper
INFO - 2020-01-27 02:59:01 --> Helper loaded: form_helper
INFO - 2020-01-27 02:59:01 --> Helper loaded: my_helper
INFO - 2020-01-27 02:59:01 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:59:01 --> Controller Class Initialized
DEBUG - 2020-01-27 02:59:01 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-01-27 02:59:01 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 02:59:01 --> Final output sent to browser
DEBUG - 2020-01-27 02:59:01 --> Total execution time: 0.3560
INFO - 2020-01-27 02:59:03 --> Config Class Initialized
INFO - 2020-01-27 02:59:03 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:59:03 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:59:03 --> Utf8 Class Initialized
INFO - 2020-01-27 02:59:03 --> URI Class Initialized
INFO - 2020-01-27 02:59:03 --> Router Class Initialized
INFO - 2020-01-27 02:59:03 --> Output Class Initialized
INFO - 2020-01-27 02:59:03 --> Security Class Initialized
DEBUG - 2020-01-27 02:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:59:03 --> Input Class Initialized
INFO - 2020-01-27 02:59:03 --> Language Class Initialized
INFO - 2020-01-27 02:59:03 --> Language Class Initialized
INFO - 2020-01-27 02:59:03 --> Config Class Initialized
INFO - 2020-01-27 02:59:03 --> Loader Class Initialized
INFO - 2020-01-27 02:59:03 --> Helper loaded: url_helper
INFO - 2020-01-27 02:59:03 --> Helper loaded: file_helper
INFO - 2020-01-27 02:59:03 --> Helper loaded: form_helper
INFO - 2020-01-27 02:59:03 --> Helper loaded: my_helper
INFO - 2020-01-27 02:59:04 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:59:04 --> Controller Class Initialized
DEBUG - 2020-01-27 02:59:04 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-01-27 02:59:04 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 02:59:04 --> Final output sent to browser
DEBUG - 2020-01-27 02:59:04 --> Total execution time: 0.3798
INFO - 2020-01-27 02:59:06 --> Config Class Initialized
INFO - 2020-01-27 02:59:06 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:59:06 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:59:06 --> Utf8 Class Initialized
INFO - 2020-01-27 02:59:06 --> URI Class Initialized
INFO - 2020-01-27 02:59:06 --> Router Class Initialized
INFO - 2020-01-27 02:59:06 --> Output Class Initialized
INFO - 2020-01-27 02:59:06 --> Security Class Initialized
DEBUG - 2020-01-27 02:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:59:06 --> Input Class Initialized
INFO - 2020-01-27 02:59:06 --> Language Class Initialized
INFO - 2020-01-27 02:59:06 --> Language Class Initialized
INFO - 2020-01-27 02:59:06 --> Config Class Initialized
INFO - 2020-01-27 02:59:06 --> Loader Class Initialized
INFO - 2020-01-27 02:59:06 --> Helper loaded: url_helper
INFO - 2020-01-27 02:59:06 --> Helper loaded: file_helper
INFO - 2020-01-27 02:59:06 --> Helper loaded: form_helper
INFO - 2020-01-27 02:59:06 --> Helper loaded: my_helper
INFO - 2020-01-27 02:59:06 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:59:06 --> Controller Class Initialized
DEBUG - 2020-01-27 02:59:06 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-01-27 02:59:06 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 02:59:06 --> Final output sent to browser
DEBUG - 2020-01-27 02:59:06 --> Total execution time: 0.4094
INFO - 2020-01-27 02:59:09 --> Config Class Initialized
INFO - 2020-01-27 02:59:09 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:59:09 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:59:09 --> Utf8 Class Initialized
INFO - 2020-01-27 02:59:09 --> URI Class Initialized
INFO - 2020-01-27 02:59:09 --> Router Class Initialized
INFO - 2020-01-27 02:59:09 --> Output Class Initialized
INFO - 2020-01-27 02:59:09 --> Security Class Initialized
DEBUG - 2020-01-27 02:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:59:09 --> Input Class Initialized
INFO - 2020-01-27 02:59:09 --> Language Class Initialized
INFO - 2020-01-27 02:59:09 --> Language Class Initialized
INFO - 2020-01-27 02:59:09 --> Config Class Initialized
INFO - 2020-01-27 02:59:09 --> Loader Class Initialized
INFO - 2020-01-27 02:59:09 --> Helper loaded: url_helper
INFO - 2020-01-27 02:59:09 --> Helper loaded: file_helper
INFO - 2020-01-27 02:59:09 --> Helper loaded: form_helper
INFO - 2020-01-27 02:59:09 --> Helper loaded: my_helper
INFO - 2020-01-27 02:59:09 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:59:09 --> Controller Class Initialized
INFO - 2020-01-27 02:59:09 --> Final output sent to browser
DEBUG - 2020-01-27 02:59:09 --> Total execution time: 0.3354
INFO - 2020-01-27 02:59:35 --> Config Class Initialized
INFO - 2020-01-27 02:59:35 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:59:35 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:59:36 --> Utf8 Class Initialized
INFO - 2020-01-27 02:59:36 --> URI Class Initialized
INFO - 2020-01-27 02:59:36 --> Router Class Initialized
INFO - 2020-01-27 02:59:36 --> Output Class Initialized
INFO - 2020-01-27 02:59:36 --> Security Class Initialized
DEBUG - 2020-01-27 02:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:59:36 --> Input Class Initialized
INFO - 2020-01-27 02:59:36 --> Language Class Initialized
INFO - 2020-01-27 02:59:36 --> Language Class Initialized
INFO - 2020-01-27 02:59:36 --> Config Class Initialized
INFO - 2020-01-27 02:59:36 --> Loader Class Initialized
INFO - 2020-01-27 02:59:36 --> Helper loaded: url_helper
INFO - 2020-01-27 02:59:36 --> Helper loaded: file_helper
INFO - 2020-01-27 02:59:36 --> Helper loaded: form_helper
INFO - 2020-01-27 02:59:36 --> Helper loaded: my_helper
INFO - 2020-01-27 02:59:36 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:59:36 --> Controller Class Initialized
INFO - 2020-01-27 02:59:36 --> Final output sent to browser
DEBUG - 2020-01-27 02:59:36 --> Total execution time: 0.3225
INFO - 2020-01-27 02:59:36 --> Config Class Initialized
INFO - 2020-01-27 02:59:36 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:59:36 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:59:36 --> Utf8 Class Initialized
INFO - 2020-01-27 02:59:36 --> URI Class Initialized
INFO - 2020-01-27 02:59:36 --> Router Class Initialized
INFO - 2020-01-27 02:59:36 --> Output Class Initialized
INFO - 2020-01-27 02:59:36 --> Security Class Initialized
DEBUG - 2020-01-27 02:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:59:36 --> Input Class Initialized
INFO - 2020-01-27 02:59:36 --> Language Class Initialized
INFO - 2020-01-27 02:59:36 --> Language Class Initialized
INFO - 2020-01-27 02:59:36 --> Config Class Initialized
INFO - 2020-01-27 02:59:36 --> Loader Class Initialized
INFO - 2020-01-27 02:59:36 --> Helper loaded: url_helper
INFO - 2020-01-27 02:59:36 --> Helper loaded: file_helper
INFO - 2020-01-27 02:59:36 --> Helper loaded: form_helper
INFO - 2020-01-27 02:59:36 --> Helper loaded: my_helper
INFO - 2020-01-27 02:59:36 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:59:36 --> Controller Class Initialized
DEBUG - 2020-01-27 02:59:36 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-01-27 02:59:36 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 02:59:36 --> Final output sent to browser
DEBUG - 2020-01-27 02:59:36 --> Total execution time: 0.3462
INFO - 2020-01-27 02:59:44 --> Config Class Initialized
INFO - 2020-01-27 02:59:44 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:59:44 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:59:44 --> Utf8 Class Initialized
INFO - 2020-01-27 02:59:44 --> URI Class Initialized
INFO - 2020-01-27 02:59:44 --> Router Class Initialized
INFO - 2020-01-27 02:59:44 --> Output Class Initialized
INFO - 2020-01-27 02:59:44 --> Security Class Initialized
DEBUG - 2020-01-27 02:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:59:44 --> Input Class Initialized
INFO - 2020-01-27 02:59:44 --> Language Class Initialized
INFO - 2020-01-27 02:59:44 --> Language Class Initialized
INFO - 2020-01-27 02:59:44 --> Config Class Initialized
INFO - 2020-01-27 02:59:44 --> Loader Class Initialized
INFO - 2020-01-27 02:59:44 --> Helper loaded: url_helper
INFO - 2020-01-27 02:59:44 --> Helper loaded: file_helper
INFO - 2020-01-27 02:59:44 --> Helper loaded: form_helper
INFO - 2020-01-27 02:59:44 --> Helper loaded: my_helper
INFO - 2020-01-27 02:59:45 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:59:45 --> Controller Class Initialized
INFO - 2020-01-27 02:59:45 --> Final output sent to browser
DEBUG - 2020-01-27 02:59:45 --> Total execution time: 0.2886
INFO - 2020-01-27 02:59:52 --> Config Class Initialized
INFO - 2020-01-27 02:59:52 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:59:52 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:59:52 --> Utf8 Class Initialized
INFO - 2020-01-27 02:59:52 --> URI Class Initialized
INFO - 2020-01-27 02:59:52 --> Router Class Initialized
INFO - 2020-01-27 02:59:52 --> Output Class Initialized
INFO - 2020-01-27 02:59:52 --> Security Class Initialized
DEBUG - 2020-01-27 02:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:59:52 --> Input Class Initialized
INFO - 2020-01-27 02:59:52 --> Language Class Initialized
INFO - 2020-01-27 02:59:52 --> Language Class Initialized
INFO - 2020-01-27 02:59:52 --> Config Class Initialized
INFO - 2020-01-27 02:59:52 --> Loader Class Initialized
INFO - 2020-01-27 02:59:52 --> Helper loaded: url_helper
INFO - 2020-01-27 02:59:52 --> Helper loaded: file_helper
INFO - 2020-01-27 02:59:52 --> Helper loaded: form_helper
INFO - 2020-01-27 02:59:52 --> Helper loaded: my_helper
INFO - 2020-01-27 02:59:52 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:59:52 --> Controller Class Initialized
INFO - 2020-01-27 02:59:52 --> Final output sent to browser
DEBUG - 2020-01-27 02:59:52 --> Total execution time: 0.3937
INFO - 2020-01-27 02:59:57 --> Config Class Initialized
INFO - 2020-01-27 02:59:57 --> Hooks Class Initialized
DEBUG - 2020-01-27 02:59:57 --> UTF-8 Support Enabled
INFO - 2020-01-27 02:59:57 --> Utf8 Class Initialized
INFO - 2020-01-27 02:59:57 --> URI Class Initialized
INFO - 2020-01-27 02:59:57 --> Router Class Initialized
INFO - 2020-01-27 02:59:57 --> Output Class Initialized
INFO - 2020-01-27 02:59:57 --> Security Class Initialized
DEBUG - 2020-01-27 02:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 02:59:57 --> Input Class Initialized
INFO - 2020-01-27 02:59:57 --> Language Class Initialized
INFO - 2020-01-27 02:59:57 --> Language Class Initialized
INFO - 2020-01-27 02:59:57 --> Config Class Initialized
INFO - 2020-01-27 02:59:57 --> Loader Class Initialized
INFO - 2020-01-27 02:59:57 --> Helper loaded: url_helper
INFO - 2020-01-27 02:59:57 --> Helper loaded: file_helper
INFO - 2020-01-27 02:59:57 --> Helper loaded: form_helper
INFO - 2020-01-27 02:59:57 --> Helper loaded: my_helper
INFO - 2020-01-27 02:59:57 --> Database Driver Class Initialized
DEBUG - 2020-01-27 02:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 02:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 02:59:57 --> Controller Class Initialized
DEBUG - 2020-01-27 02:59:57 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-01-27 02:59:57 --> Final output sent to browser
DEBUG - 2020-01-27 02:59:57 --> Total execution time: 0.3692
INFO - 2020-01-27 03:00:08 --> Config Class Initialized
INFO - 2020-01-27 03:00:08 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:00:08 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:00:08 --> Utf8 Class Initialized
INFO - 2020-01-27 03:00:08 --> URI Class Initialized
INFO - 2020-01-27 03:00:08 --> Router Class Initialized
INFO - 2020-01-27 03:00:08 --> Output Class Initialized
INFO - 2020-01-27 03:00:08 --> Security Class Initialized
DEBUG - 2020-01-27 03:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:00:09 --> Input Class Initialized
INFO - 2020-01-27 03:00:09 --> Language Class Initialized
INFO - 2020-01-27 03:00:09 --> Language Class Initialized
INFO - 2020-01-27 03:00:09 --> Config Class Initialized
INFO - 2020-01-27 03:00:09 --> Loader Class Initialized
INFO - 2020-01-27 03:00:09 --> Helper loaded: url_helper
INFO - 2020-01-27 03:00:09 --> Helper loaded: file_helper
INFO - 2020-01-27 03:00:09 --> Helper loaded: form_helper
INFO - 2020-01-27 03:00:09 --> Helper loaded: my_helper
INFO - 2020-01-27 03:00:09 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:00:09 --> Controller Class Initialized
INFO - 2020-01-27 03:00:09 --> Final output sent to browser
DEBUG - 2020-01-27 03:00:09 --> Total execution time: 0.2962
INFO - 2020-01-27 03:00:18 --> Config Class Initialized
INFO - 2020-01-27 03:00:18 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:00:18 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:00:18 --> Utf8 Class Initialized
INFO - 2020-01-27 03:00:18 --> URI Class Initialized
INFO - 2020-01-27 03:00:18 --> Router Class Initialized
INFO - 2020-01-27 03:00:18 --> Output Class Initialized
INFO - 2020-01-27 03:00:18 --> Security Class Initialized
DEBUG - 2020-01-27 03:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:00:18 --> Input Class Initialized
INFO - 2020-01-27 03:00:18 --> Language Class Initialized
INFO - 2020-01-27 03:00:18 --> Language Class Initialized
INFO - 2020-01-27 03:00:18 --> Config Class Initialized
INFO - 2020-01-27 03:00:18 --> Loader Class Initialized
INFO - 2020-01-27 03:00:18 --> Helper loaded: url_helper
INFO - 2020-01-27 03:00:18 --> Helper loaded: file_helper
INFO - 2020-01-27 03:00:18 --> Helper loaded: form_helper
INFO - 2020-01-27 03:00:18 --> Helper loaded: my_helper
INFO - 2020-01-27 03:00:18 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:00:18 --> Controller Class Initialized
INFO - 2020-01-27 03:00:18 --> Final output sent to browser
DEBUG - 2020-01-27 03:00:18 --> Total execution time: 0.3379
INFO - 2020-01-27 03:00:26 --> Config Class Initialized
INFO - 2020-01-27 03:00:26 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:00:26 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:00:26 --> Utf8 Class Initialized
INFO - 2020-01-27 03:00:26 --> URI Class Initialized
INFO - 2020-01-27 03:00:26 --> Router Class Initialized
INFO - 2020-01-27 03:00:26 --> Output Class Initialized
INFO - 2020-01-27 03:00:26 --> Security Class Initialized
DEBUG - 2020-01-27 03:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:00:26 --> Input Class Initialized
INFO - 2020-01-27 03:00:26 --> Language Class Initialized
INFO - 2020-01-27 03:00:26 --> Language Class Initialized
INFO - 2020-01-27 03:00:26 --> Config Class Initialized
INFO - 2020-01-27 03:00:26 --> Loader Class Initialized
INFO - 2020-01-27 03:00:26 --> Helper loaded: url_helper
INFO - 2020-01-27 03:00:26 --> Helper loaded: file_helper
INFO - 2020-01-27 03:00:26 --> Helper loaded: form_helper
INFO - 2020-01-27 03:00:26 --> Helper loaded: my_helper
INFO - 2020-01-27 03:00:26 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:00:26 --> Controller Class Initialized
INFO - 2020-01-27 03:00:26 --> Final output sent to browser
DEBUG - 2020-01-27 03:00:26 --> Total execution time: 0.3211
INFO - 2020-01-27 03:00:26 --> Config Class Initialized
INFO - 2020-01-27 03:00:26 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:00:26 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:00:26 --> Utf8 Class Initialized
INFO - 2020-01-27 03:00:26 --> URI Class Initialized
INFO - 2020-01-27 03:00:26 --> Router Class Initialized
INFO - 2020-01-27 03:00:26 --> Output Class Initialized
INFO - 2020-01-27 03:00:26 --> Security Class Initialized
DEBUG - 2020-01-27 03:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:00:26 --> Input Class Initialized
INFO - 2020-01-27 03:00:26 --> Language Class Initialized
INFO - 2020-01-27 03:00:26 --> Language Class Initialized
INFO - 2020-01-27 03:00:27 --> Config Class Initialized
INFO - 2020-01-27 03:00:27 --> Loader Class Initialized
INFO - 2020-01-27 03:00:27 --> Helper loaded: url_helper
INFO - 2020-01-27 03:00:27 --> Helper loaded: file_helper
INFO - 2020-01-27 03:00:27 --> Helper loaded: form_helper
INFO - 2020-01-27 03:00:27 --> Helper loaded: my_helper
INFO - 2020-01-27 03:00:27 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:00:27 --> Controller Class Initialized
DEBUG - 2020-01-27 03:00:27 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-01-27 03:00:27 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 03:00:27 --> Final output sent to browser
DEBUG - 2020-01-27 03:00:27 --> Total execution time: 0.3245
INFO - 2020-01-27 03:00:30 --> Config Class Initialized
INFO - 2020-01-27 03:00:30 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:00:30 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:00:30 --> Utf8 Class Initialized
INFO - 2020-01-27 03:00:30 --> URI Class Initialized
INFO - 2020-01-27 03:00:30 --> Router Class Initialized
INFO - 2020-01-27 03:00:30 --> Output Class Initialized
INFO - 2020-01-27 03:00:30 --> Security Class Initialized
DEBUG - 2020-01-27 03:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:00:30 --> Input Class Initialized
INFO - 2020-01-27 03:00:30 --> Language Class Initialized
INFO - 2020-01-27 03:00:30 --> Language Class Initialized
INFO - 2020-01-27 03:00:30 --> Config Class Initialized
INFO - 2020-01-27 03:00:30 --> Loader Class Initialized
INFO - 2020-01-27 03:00:30 --> Helper loaded: url_helper
INFO - 2020-01-27 03:00:30 --> Helper loaded: file_helper
INFO - 2020-01-27 03:00:30 --> Helper loaded: form_helper
INFO - 2020-01-27 03:00:30 --> Helper loaded: my_helper
INFO - 2020-01-27 03:00:30 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:00:30 --> Controller Class Initialized
INFO - 2020-01-27 03:00:30 --> Final output sent to browser
DEBUG - 2020-01-27 03:00:30 --> Total execution time: 0.3245
INFO - 2020-01-27 03:00:35 --> Config Class Initialized
INFO - 2020-01-27 03:00:35 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:00:35 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:00:35 --> Utf8 Class Initialized
INFO - 2020-01-27 03:00:35 --> URI Class Initialized
INFO - 2020-01-27 03:00:35 --> Router Class Initialized
INFO - 2020-01-27 03:00:35 --> Output Class Initialized
INFO - 2020-01-27 03:00:35 --> Security Class Initialized
DEBUG - 2020-01-27 03:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:00:35 --> Input Class Initialized
INFO - 2020-01-27 03:00:35 --> Language Class Initialized
INFO - 2020-01-27 03:00:35 --> Language Class Initialized
INFO - 2020-01-27 03:00:35 --> Config Class Initialized
INFO - 2020-01-27 03:00:35 --> Loader Class Initialized
INFO - 2020-01-27 03:00:35 --> Helper loaded: url_helper
INFO - 2020-01-27 03:00:35 --> Helper loaded: file_helper
INFO - 2020-01-27 03:00:35 --> Helper loaded: form_helper
INFO - 2020-01-27 03:00:35 --> Helper loaded: my_helper
INFO - 2020-01-27 03:00:35 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:00:35 --> Controller Class Initialized
INFO - 2020-01-27 03:00:35 --> Final output sent to browser
DEBUG - 2020-01-27 03:00:35 --> Total execution time: 0.3484
INFO - 2020-01-27 03:00:39 --> Config Class Initialized
INFO - 2020-01-27 03:00:40 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:00:40 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:00:40 --> Utf8 Class Initialized
INFO - 2020-01-27 03:00:40 --> URI Class Initialized
INFO - 2020-01-27 03:00:40 --> Router Class Initialized
INFO - 2020-01-27 03:00:40 --> Output Class Initialized
INFO - 2020-01-27 03:00:40 --> Security Class Initialized
DEBUG - 2020-01-27 03:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:00:40 --> Input Class Initialized
INFO - 2020-01-27 03:00:40 --> Language Class Initialized
INFO - 2020-01-27 03:00:40 --> Language Class Initialized
INFO - 2020-01-27 03:00:40 --> Config Class Initialized
INFO - 2020-01-27 03:00:40 --> Loader Class Initialized
INFO - 2020-01-27 03:00:40 --> Helper loaded: url_helper
INFO - 2020-01-27 03:00:40 --> Helper loaded: file_helper
INFO - 2020-01-27 03:00:40 --> Helper loaded: form_helper
INFO - 2020-01-27 03:00:40 --> Helper loaded: my_helper
INFO - 2020-01-27 03:00:40 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:00:40 --> Controller Class Initialized
DEBUG - 2020-01-27 03:00:40 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-01-27 03:00:40 --> Final output sent to browser
DEBUG - 2020-01-27 03:00:40 --> Total execution time: 0.3667
INFO - 2020-01-27 03:02:01 --> Config Class Initialized
INFO - 2020-01-27 03:02:01 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:02:01 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:02:01 --> Utf8 Class Initialized
INFO - 2020-01-27 03:02:01 --> URI Class Initialized
DEBUG - 2020-01-27 03:02:01 --> No URI present. Default controller set.
INFO - 2020-01-27 03:02:01 --> Router Class Initialized
INFO - 2020-01-27 03:02:01 --> Output Class Initialized
INFO - 2020-01-27 03:02:01 --> Security Class Initialized
DEBUG - 2020-01-27 03:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:02:01 --> Input Class Initialized
INFO - 2020-01-27 03:02:01 --> Language Class Initialized
INFO - 2020-01-27 03:02:01 --> Language Class Initialized
INFO - 2020-01-27 03:02:01 --> Config Class Initialized
INFO - 2020-01-27 03:02:01 --> Loader Class Initialized
INFO - 2020-01-27 03:02:01 --> Helper loaded: url_helper
INFO - 2020-01-27 03:02:01 --> Helper loaded: file_helper
INFO - 2020-01-27 03:02:01 --> Helper loaded: form_helper
INFO - 2020-01-27 03:02:01 --> Helper loaded: my_helper
INFO - 2020-01-27 03:02:01 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:02:01 --> Controller Class Initialized
INFO - 2020-01-27 03:02:01 --> Config Class Initialized
INFO - 2020-01-27 03:02:01 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:02:01 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:02:01 --> Utf8 Class Initialized
INFO - 2020-01-27 03:02:01 --> URI Class Initialized
INFO - 2020-01-27 03:02:01 --> Router Class Initialized
INFO - 2020-01-27 03:02:01 --> Output Class Initialized
INFO - 2020-01-27 03:02:01 --> Security Class Initialized
DEBUG - 2020-01-27 03:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:02:01 --> Input Class Initialized
INFO - 2020-01-27 03:02:01 --> Language Class Initialized
INFO - 2020-01-27 03:02:02 --> Language Class Initialized
INFO - 2020-01-27 03:02:02 --> Config Class Initialized
INFO - 2020-01-27 03:02:02 --> Loader Class Initialized
INFO - 2020-01-27 03:02:02 --> Helper loaded: url_helper
INFO - 2020-01-27 03:02:02 --> Helper loaded: file_helper
INFO - 2020-01-27 03:02:02 --> Helper loaded: form_helper
INFO - 2020-01-27 03:02:02 --> Helper loaded: my_helper
INFO - 2020-01-27 03:02:02 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:02:02 --> Controller Class Initialized
DEBUG - 2020-01-27 03:02:02 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-27 03:02:02 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 03:02:02 --> Final output sent to browser
DEBUG - 2020-01-27 03:02:02 --> Total execution time: 0.3315
INFO - 2020-01-27 03:02:07 --> Config Class Initialized
INFO - 2020-01-27 03:02:07 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:02:08 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:02:08 --> Utf8 Class Initialized
INFO - 2020-01-27 03:02:08 --> URI Class Initialized
INFO - 2020-01-27 03:02:08 --> Router Class Initialized
INFO - 2020-01-27 03:02:08 --> Output Class Initialized
INFO - 2020-01-27 03:02:08 --> Security Class Initialized
DEBUG - 2020-01-27 03:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:02:08 --> Input Class Initialized
INFO - 2020-01-27 03:02:08 --> Language Class Initialized
INFO - 2020-01-27 03:02:08 --> Language Class Initialized
INFO - 2020-01-27 03:02:08 --> Config Class Initialized
INFO - 2020-01-27 03:02:08 --> Loader Class Initialized
INFO - 2020-01-27 03:02:08 --> Helper loaded: url_helper
INFO - 2020-01-27 03:02:08 --> Helper loaded: file_helper
INFO - 2020-01-27 03:02:08 --> Helper loaded: form_helper
INFO - 2020-01-27 03:02:08 --> Helper loaded: my_helper
INFO - 2020-01-27 03:02:08 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:02:08 --> Controller Class Initialized
INFO - 2020-01-27 03:02:08 --> Helper loaded: cookie_helper
INFO - 2020-01-27 03:02:08 --> Final output sent to browser
DEBUG - 2020-01-27 03:02:08 --> Total execution time: 0.3564
INFO - 2020-01-27 03:02:09 --> Config Class Initialized
INFO - 2020-01-27 03:02:09 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:02:09 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:02:09 --> Utf8 Class Initialized
INFO - 2020-01-27 03:02:09 --> URI Class Initialized
INFO - 2020-01-27 03:02:09 --> Router Class Initialized
INFO - 2020-01-27 03:02:09 --> Output Class Initialized
INFO - 2020-01-27 03:02:09 --> Security Class Initialized
DEBUG - 2020-01-27 03:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:02:09 --> Input Class Initialized
INFO - 2020-01-27 03:02:09 --> Language Class Initialized
INFO - 2020-01-27 03:02:09 --> Language Class Initialized
INFO - 2020-01-27 03:02:09 --> Config Class Initialized
INFO - 2020-01-27 03:02:09 --> Loader Class Initialized
INFO - 2020-01-27 03:02:09 --> Helper loaded: url_helper
INFO - 2020-01-27 03:02:09 --> Helper loaded: file_helper
INFO - 2020-01-27 03:02:09 --> Helper loaded: form_helper
INFO - 2020-01-27 03:02:09 --> Helper loaded: my_helper
INFO - 2020-01-27 03:02:09 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:02:10 --> Controller Class Initialized
DEBUG - 2020-01-27 03:02:10 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-27 03:02:10 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 03:02:10 --> Final output sent to browser
DEBUG - 2020-01-27 03:02:10 --> Total execution time: 0.4767
INFO - 2020-01-27 03:02:23 --> Config Class Initialized
INFO - 2020-01-27 03:02:23 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:02:23 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:02:23 --> Utf8 Class Initialized
INFO - 2020-01-27 03:02:23 --> URI Class Initialized
DEBUG - 2020-01-27 03:02:23 --> No URI present. Default controller set.
INFO - 2020-01-27 03:02:23 --> Router Class Initialized
INFO - 2020-01-27 03:02:23 --> Output Class Initialized
INFO - 2020-01-27 03:02:23 --> Security Class Initialized
DEBUG - 2020-01-27 03:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:02:23 --> Input Class Initialized
INFO - 2020-01-27 03:02:23 --> Language Class Initialized
INFO - 2020-01-27 03:02:23 --> Language Class Initialized
INFO - 2020-01-27 03:02:23 --> Config Class Initialized
INFO - 2020-01-27 03:02:23 --> Loader Class Initialized
INFO - 2020-01-27 03:02:23 --> Helper loaded: url_helper
INFO - 2020-01-27 03:02:23 --> Helper loaded: file_helper
INFO - 2020-01-27 03:02:23 --> Helper loaded: form_helper
INFO - 2020-01-27 03:02:23 --> Helper loaded: my_helper
INFO - 2020-01-27 03:02:23 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:02:23 --> Controller Class Initialized
DEBUG - 2020-01-27 03:02:23 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-27 03:02:23 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 03:02:23 --> Final output sent to browser
DEBUG - 2020-01-27 03:02:23 --> Total execution time: 0.3893
INFO - 2020-01-27 03:02:26 --> Config Class Initialized
INFO - 2020-01-27 03:02:26 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:02:26 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:02:26 --> Utf8 Class Initialized
INFO - 2020-01-27 03:02:26 --> URI Class Initialized
INFO - 2020-01-27 03:02:26 --> Router Class Initialized
INFO - 2020-01-27 03:02:26 --> Output Class Initialized
INFO - 2020-01-27 03:02:26 --> Security Class Initialized
DEBUG - 2020-01-27 03:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:02:26 --> Input Class Initialized
INFO - 2020-01-27 03:02:26 --> Language Class Initialized
INFO - 2020-01-27 03:02:27 --> Language Class Initialized
INFO - 2020-01-27 03:02:27 --> Config Class Initialized
INFO - 2020-01-27 03:02:27 --> Loader Class Initialized
INFO - 2020-01-27 03:02:27 --> Helper loaded: url_helper
INFO - 2020-01-27 03:02:27 --> Helper loaded: file_helper
INFO - 2020-01-27 03:02:27 --> Helper loaded: form_helper
INFO - 2020-01-27 03:02:27 --> Helper loaded: my_helper
INFO - 2020-01-27 03:02:27 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:02:27 --> Controller Class Initialized
DEBUG - 2020-01-27 03:02:27 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_guru/views/list.php
DEBUG - 2020-01-27 03:02:27 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 03:02:27 --> Final output sent to browser
DEBUG - 2020-01-27 03:02:27 --> Total execution time: 0.3896
INFO - 2020-01-27 03:02:27 --> Config Class Initialized
INFO - 2020-01-27 03:02:27 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:02:27 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:02:27 --> Utf8 Class Initialized
INFO - 2020-01-27 03:02:27 --> URI Class Initialized
INFO - 2020-01-27 03:02:27 --> Router Class Initialized
INFO - 2020-01-27 03:02:27 --> Output Class Initialized
INFO - 2020-01-27 03:02:27 --> Security Class Initialized
DEBUG - 2020-01-27 03:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:02:27 --> Input Class Initialized
INFO - 2020-01-27 03:02:27 --> Language Class Initialized
INFO - 2020-01-27 03:02:27 --> Language Class Initialized
INFO - 2020-01-27 03:02:27 --> Config Class Initialized
INFO - 2020-01-27 03:02:27 --> Loader Class Initialized
INFO - 2020-01-27 03:02:27 --> Helper loaded: url_helper
INFO - 2020-01-27 03:02:27 --> Helper loaded: file_helper
INFO - 2020-01-27 03:02:27 --> Helper loaded: form_helper
INFO - 2020-01-27 03:02:27 --> Helper loaded: my_helper
INFO - 2020-01-27 03:02:27 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:02:27 --> Controller Class Initialized
INFO - 2020-01-27 03:02:29 --> Config Class Initialized
INFO - 2020-01-27 03:02:29 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:02:29 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:02:29 --> Utf8 Class Initialized
INFO - 2020-01-27 03:02:29 --> URI Class Initialized
DEBUG - 2020-01-27 03:02:29 --> No URI present. Default controller set.
INFO - 2020-01-27 03:02:29 --> Router Class Initialized
INFO - 2020-01-27 03:02:29 --> Output Class Initialized
INFO - 2020-01-27 03:02:29 --> Security Class Initialized
DEBUG - 2020-01-27 03:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:02:29 --> Input Class Initialized
INFO - 2020-01-27 03:02:29 --> Language Class Initialized
INFO - 2020-01-27 03:02:29 --> Language Class Initialized
INFO - 2020-01-27 03:02:29 --> Config Class Initialized
INFO - 2020-01-27 03:02:29 --> Loader Class Initialized
INFO - 2020-01-27 03:02:29 --> Helper loaded: url_helper
INFO - 2020-01-27 03:02:29 --> Helper loaded: file_helper
INFO - 2020-01-27 03:02:29 --> Helper loaded: form_helper
INFO - 2020-01-27 03:02:29 --> Helper loaded: my_helper
INFO - 2020-01-27 03:02:29 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:02:29 --> Controller Class Initialized
DEBUG - 2020-01-27 03:02:29 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-27 03:02:29 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 03:02:29 --> Final output sent to browser
DEBUG - 2020-01-27 03:02:30 --> Total execution time: 0.3798
INFO - 2020-01-27 03:02:31 --> Config Class Initialized
INFO - 2020-01-27 03:02:31 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:02:31 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:02:31 --> Utf8 Class Initialized
INFO - 2020-01-27 03:02:31 --> URI Class Initialized
INFO - 2020-01-27 03:02:31 --> Router Class Initialized
INFO - 2020-01-27 03:02:31 --> Output Class Initialized
INFO - 2020-01-27 03:02:31 --> Security Class Initialized
DEBUG - 2020-01-27 03:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:02:31 --> Input Class Initialized
INFO - 2020-01-27 03:02:31 --> Language Class Initialized
INFO - 2020-01-27 03:02:32 --> Language Class Initialized
INFO - 2020-01-27 03:02:32 --> Config Class Initialized
INFO - 2020-01-27 03:02:32 --> Loader Class Initialized
INFO - 2020-01-27 03:02:32 --> Helper loaded: url_helper
INFO - 2020-01-27 03:02:32 --> Helper loaded: file_helper
INFO - 2020-01-27 03:02:32 --> Helper loaded: form_helper
INFO - 2020-01-27 03:02:32 --> Helper loaded: my_helper
INFO - 2020-01-27 03:02:32 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:02:32 --> Controller Class Initialized
DEBUG - 2020-01-27 03:02:32 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_ekstra/views/list.php
DEBUG - 2020-01-27 03:02:32 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 03:02:32 --> Final output sent to browser
DEBUG - 2020-01-27 03:02:32 --> Total execution time: 0.3984
INFO - 2020-01-27 03:02:32 --> Config Class Initialized
INFO - 2020-01-27 03:02:32 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:02:32 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:02:32 --> Utf8 Class Initialized
INFO - 2020-01-27 03:02:32 --> URI Class Initialized
INFO - 2020-01-27 03:02:32 --> Router Class Initialized
INFO - 2020-01-27 03:02:32 --> Output Class Initialized
INFO - 2020-01-27 03:02:32 --> Security Class Initialized
DEBUG - 2020-01-27 03:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:02:32 --> Input Class Initialized
INFO - 2020-01-27 03:02:32 --> Language Class Initialized
INFO - 2020-01-27 03:02:32 --> Language Class Initialized
INFO - 2020-01-27 03:02:32 --> Config Class Initialized
INFO - 2020-01-27 03:02:32 --> Loader Class Initialized
INFO - 2020-01-27 03:02:32 --> Helper loaded: url_helper
INFO - 2020-01-27 03:02:32 --> Helper loaded: file_helper
INFO - 2020-01-27 03:02:32 --> Helper loaded: form_helper
INFO - 2020-01-27 03:02:32 --> Helper loaded: my_helper
INFO - 2020-01-27 03:02:32 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:02:32 --> Controller Class Initialized
INFO - 2020-01-27 03:02:36 --> Config Class Initialized
INFO - 2020-01-27 03:02:36 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:02:36 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:02:36 --> Utf8 Class Initialized
INFO - 2020-01-27 03:02:36 --> URI Class Initialized
DEBUG - 2020-01-27 03:02:36 --> No URI present. Default controller set.
INFO - 2020-01-27 03:02:36 --> Router Class Initialized
INFO - 2020-01-27 03:02:36 --> Output Class Initialized
INFO - 2020-01-27 03:02:36 --> Security Class Initialized
DEBUG - 2020-01-27 03:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:02:36 --> Input Class Initialized
INFO - 2020-01-27 03:02:36 --> Language Class Initialized
INFO - 2020-01-27 03:02:36 --> Language Class Initialized
INFO - 2020-01-27 03:02:36 --> Config Class Initialized
INFO - 2020-01-27 03:02:36 --> Loader Class Initialized
INFO - 2020-01-27 03:02:36 --> Helper loaded: url_helper
INFO - 2020-01-27 03:02:36 --> Helper loaded: file_helper
INFO - 2020-01-27 03:02:36 --> Helper loaded: form_helper
INFO - 2020-01-27 03:02:36 --> Helper loaded: my_helper
INFO - 2020-01-27 03:02:36 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:02:36 --> Controller Class Initialized
DEBUG - 2020-01-27 03:02:36 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-27 03:02:36 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 03:02:36 --> Final output sent to browser
DEBUG - 2020-01-27 03:02:36 --> Total execution time: 0.4138
INFO - 2020-01-27 03:06:16 --> Config Class Initialized
INFO - 2020-01-27 03:06:16 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:06:16 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:06:16 --> Utf8 Class Initialized
INFO - 2020-01-27 03:06:16 --> URI Class Initialized
DEBUG - 2020-01-27 03:06:16 --> No URI present. Default controller set.
INFO - 2020-01-27 03:06:16 --> Router Class Initialized
INFO - 2020-01-27 03:06:16 --> Output Class Initialized
INFO - 2020-01-27 03:06:16 --> Security Class Initialized
DEBUG - 2020-01-27 03:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:06:16 --> Input Class Initialized
INFO - 2020-01-27 03:06:16 --> Language Class Initialized
INFO - 2020-01-27 03:06:16 --> Language Class Initialized
INFO - 2020-01-27 03:06:16 --> Config Class Initialized
INFO - 2020-01-27 03:06:16 --> Loader Class Initialized
INFO - 2020-01-27 03:06:16 --> Helper loaded: url_helper
INFO - 2020-01-27 03:06:16 --> Helper loaded: file_helper
INFO - 2020-01-27 03:06:16 --> Helper loaded: form_helper
INFO - 2020-01-27 03:06:16 --> Helper loaded: my_helper
INFO - 2020-01-27 03:06:16 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:06:16 --> Controller Class Initialized
DEBUG - 2020-01-27 03:06:16 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-27 03:06:16 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 03:06:16 --> Final output sent to browser
DEBUG - 2020-01-27 03:06:17 --> Total execution time: 0.3682
INFO - 2020-01-27 03:06:24 --> Config Class Initialized
INFO - 2020-01-27 03:06:24 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:06:24 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:06:24 --> Utf8 Class Initialized
INFO - 2020-01-27 03:06:24 --> URI Class Initialized
INFO - 2020-01-27 03:06:24 --> Router Class Initialized
INFO - 2020-01-27 03:06:24 --> Output Class Initialized
INFO - 2020-01-27 03:06:24 --> Security Class Initialized
DEBUG - 2020-01-27 03:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:06:24 --> Input Class Initialized
INFO - 2020-01-27 03:06:24 --> Language Class Initialized
INFO - 2020-01-27 03:06:24 --> Language Class Initialized
INFO - 2020-01-27 03:06:24 --> Config Class Initialized
INFO - 2020-01-27 03:06:24 --> Loader Class Initialized
INFO - 2020-01-27 03:06:24 --> Helper loaded: url_helper
INFO - 2020-01-27 03:06:24 --> Helper loaded: file_helper
INFO - 2020-01-27 03:06:24 --> Helper loaded: form_helper
INFO - 2020-01-27 03:06:25 --> Helper loaded: my_helper
INFO - 2020-01-27 03:06:25 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:06:25 --> Controller Class Initialized
DEBUG - 2020-01-27 03:06:25 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_guru/views/list.php
DEBUG - 2020-01-27 03:06:25 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 03:06:25 --> Final output sent to browser
DEBUG - 2020-01-27 03:06:25 --> Total execution time: 0.3942
INFO - 2020-01-27 03:06:25 --> Config Class Initialized
INFO - 2020-01-27 03:06:25 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:06:25 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:06:25 --> Utf8 Class Initialized
INFO - 2020-01-27 03:06:25 --> URI Class Initialized
INFO - 2020-01-27 03:06:25 --> Router Class Initialized
INFO - 2020-01-27 03:06:25 --> Output Class Initialized
INFO - 2020-01-27 03:06:25 --> Security Class Initialized
DEBUG - 2020-01-27 03:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:06:25 --> Input Class Initialized
INFO - 2020-01-27 03:06:25 --> Language Class Initialized
INFO - 2020-01-27 03:06:25 --> Language Class Initialized
INFO - 2020-01-27 03:06:25 --> Config Class Initialized
INFO - 2020-01-27 03:06:25 --> Loader Class Initialized
INFO - 2020-01-27 03:06:25 --> Helper loaded: url_helper
INFO - 2020-01-27 03:06:25 --> Helper loaded: file_helper
INFO - 2020-01-27 03:06:25 --> Helper loaded: form_helper
INFO - 2020-01-27 03:06:25 --> Helper loaded: my_helper
INFO - 2020-01-27 03:06:25 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:06:25 --> Controller Class Initialized
INFO - 2020-01-27 03:06:32 --> Config Class Initialized
INFO - 2020-01-27 03:06:32 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:06:32 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:06:32 --> Utf8 Class Initialized
INFO - 2020-01-27 03:06:32 --> URI Class Initialized
INFO - 2020-01-27 03:06:32 --> Router Class Initialized
INFO - 2020-01-27 03:06:32 --> Output Class Initialized
INFO - 2020-01-27 03:06:32 --> Security Class Initialized
DEBUG - 2020-01-27 03:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:06:32 --> Input Class Initialized
INFO - 2020-01-27 03:06:32 --> Language Class Initialized
INFO - 2020-01-27 03:06:32 --> Language Class Initialized
INFO - 2020-01-27 03:06:32 --> Config Class Initialized
INFO - 2020-01-27 03:06:32 --> Loader Class Initialized
INFO - 2020-01-27 03:06:32 --> Helper loaded: url_helper
INFO - 2020-01-27 03:06:32 --> Helper loaded: file_helper
INFO - 2020-01-27 03:06:32 --> Helper loaded: form_helper
INFO - 2020-01-27 03:06:32 --> Helper loaded: my_helper
INFO - 2020-01-27 03:06:32 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:06:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:06:32 --> Controller Class Initialized
DEBUG - 2020-01-27 03:06:32 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/tahun/views/list.php
DEBUG - 2020-01-27 03:06:32 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 03:06:32 --> Final output sent to browser
DEBUG - 2020-01-27 03:06:32 --> Total execution time: 0.3851
INFO - 2020-01-27 03:06:32 --> Config Class Initialized
INFO - 2020-01-27 03:06:32 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:06:32 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:06:32 --> Utf8 Class Initialized
INFO - 2020-01-27 03:06:32 --> URI Class Initialized
INFO - 2020-01-27 03:06:32 --> Router Class Initialized
INFO - 2020-01-27 03:06:32 --> Output Class Initialized
INFO - 2020-01-27 03:06:32 --> Security Class Initialized
DEBUG - 2020-01-27 03:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:06:32 --> Input Class Initialized
INFO - 2020-01-27 03:06:32 --> Language Class Initialized
INFO - 2020-01-27 03:06:32 --> Language Class Initialized
INFO - 2020-01-27 03:06:32 --> Config Class Initialized
INFO - 2020-01-27 03:06:32 --> Loader Class Initialized
INFO - 2020-01-27 03:06:32 --> Helper loaded: url_helper
INFO - 2020-01-27 03:06:33 --> Helper loaded: file_helper
INFO - 2020-01-27 03:06:33 --> Helper loaded: form_helper
INFO - 2020-01-27 03:06:33 --> Helper loaded: my_helper
INFO - 2020-01-27 03:06:33 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:06:33 --> Controller Class Initialized
INFO - 2020-01-27 03:07:02 --> Config Class Initialized
INFO - 2020-01-27 03:07:02 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:07:02 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:07:02 --> Utf8 Class Initialized
INFO - 2020-01-27 03:07:02 --> URI Class Initialized
INFO - 2020-01-27 03:07:02 --> Router Class Initialized
INFO - 2020-01-27 03:07:02 --> Output Class Initialized
INFO - 2020-01-27 03:07:02 --> Security Class Initialized
DEBUG - 2020-01-27 03:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:07:02 --> Input Class Initialized
INFO - 2020-01-27 03:07:02 --> Language Class Initialized
INFO - 2020-01-27 03:07:02 --> Language Class Initialized
INFO - 2020-01-27 03:07:02 --> Config Class Initialized
INFO - 2020-01-27 03:07:02 --> Loader Class Initialized
INFO - 2020-01-27 03:07:02 --> Helper loaded: url_helper
INFO - 2020-01-27 03:07:02 --> Helper loaded: file_helper
INFO - 2020-01-27 03:07:02 --> Helper loaded: form_helper
INFO - 2020-01-27 03:07:02 --> Helper loaded: my_helper
INFO - 2020-01-27 03:07:02 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:07:02 --> Controller Class Initialized
DEBUG - 2020-01-27 03:07:02 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_catatan/views/list.php
DEBUG - 2020-01-27 03:07:02 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 03:07:02 --> Final output sent to browser
DEBUG - 2020-01-27 03:07:02 --> Total execution time: 0.4287
INFO - 2020-01-27 03:07:19 --> Config Class Initialized
INFO - 2020-01-27 03:07:19 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:07:19 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:07:19 --> Utf8 Class Initialized
INFO - 2020-01-27 03:07:19 --> URI Class Initialized
INFO - 2020-01-27 03:07:19 --> Router Class Initialized
INFO - 2020-01-27 03:07:19 --> Output Class Initialized
INFO - 2020-01-27 03:07:19 --> Security Class Initialized
DEBUG - 2020-01-27 03:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:07:19 --> Input Class Initialized
INFO - 2020-01-27 03:07:19 --> Language Class Initialized
INFO - 2020-01-27 03:07:19 --> Language Class Initialized
INFO - 2020-01-27 03:07:19 --> Config Class Initialized
INFO - 2020-01-27 03:07:19 --> Loader Class Initialized
INFO - 2020-01-27 03:07:20 --> Helper loaded: url_helper
INFO - 2020-01-27 03:07:20 --> Helper loaded: file_helper
INFO - 2020-01-27 03:07:20 --> Helper loaded: form_helper
INFO - 2020-01-27 03:07:20 --> Helper loaded: my_helper
INFO - 2020-01-27 03:07:20 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:07:20 --> Controller Class Initialized
DEBUG - 2020-01-27 03:07:20 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_ekstra/views/list.php
DEBUG - 2020-01-27 03:07:20 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 03:07:20 --> Final output sent to browser
DEBUG - 2020-01-27 03:07:20 --> Total execution time: 0.4191
INFO - 2020-01-27 03:07:22 --> Config Class Initialized
INFO - 2020-01-27 03:07:22 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:07:22 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:07:22 --> Utf8 Class Initialized
INFO - 2020-01-27 03:07:22 --> URI Class Initialized
INFO - 2020-01-27 03:07:22 --> Router Class Initialized
INFO - 2020-01-27 03:07:22 --> Output Class Initialized
INFO - 2020-01-27 03:07:22 --> Security Class Initialized
DEBUG - 2020-01-27 03:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:07:22 --> Input Class Initialized
INFO - 2020-01-27 03:07:22 --> Language Class Initialized
INFO - 2020-01-27 03:07:22 --> Language Class Initialized
INFO - 2020-01-27 03:07:22 --> Config Class Initialized
INFO - 2020-01-27 03:07:22 --> Loader Class Initialized
INFO - 2020-01-27 03:07:22 --> Helper loaded: url_helper
INFO - 2020-01-27 03:07:22 --> Helper loaded: file_helper
INFO - 2020-01-27 03:07:22 --> Helper loaded: form_helper
INFO - 2020-01-27 03:07:22 --> Helper loaded: my_helper
INFO - 2020-01-27 03:07:22 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:07:22 --> Controller Class Initialized
INFO - 2020-01-27 03:07:22 --> Final output sent to browser
DEBUG - 2020-01-27 03:07:22 --> Total execution time: 0.3156
INFO - 2020-01-27 03:07:36 --> Config Class Initialized
INFO - 2020-01-27 03:07:36 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:07:36 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:07:36 --> Utf8 Class Initialized
INFO - 2020-01-27 03:07:36 --> URI Class Initialized
INFO - 2020-01-27 03:07:36 --> Router Class Initialized
INFO - 2020-01-27 03:07:36 --> Output Class Initialized
INFO - 2020-01-27 03:07:36 --> Security Class Initialized
DEBUG - 2020-01-27 03:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:07:36 --> Input Class Initialized
INFO - 2020-01-27 03:07:36 --> Language Class Initialized
INFO - 2020-01-27 03:07:36 --> Language Class Initialized
INFO - 2020-01-27 03:07:36 --> Config Class Initialized
INFO - 2020-01-27 03:07:36 --> Loader Class Initialized
INFO - 2020-01-27 03:07:36 --> Helper loaded: url_helper
INFO - 2020-01-27 03:07:36 --> Helper loaded: file_helper
INFO - 2020-01-27 03:07:36 --> Helper loaded: form_helper
INFO - 2020-01-27 03:07:36 --> Helper loaded: my_helper
INFO - 2020-01-27 03:07:36 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:07:36 --> Controller Class Initialized
INFO - 2020-01-27 03:07:36 --> Final output sent to browser
DEBUG - 2020-01-27 03:07:36 --> Total execution time: 0.3621
INFO - 2020-01-27 03:07:38 --> Config Class Initialized
INFO - 2020-01-27 03:07:38 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:07:38 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:07:38 --> Utf8 Class Initialized
INFO - 2020-01-27 03:07:38 --> URI Class Initialized
INFO - 2020-01-27 03:07:38 --> Router Class Initialized
INFO - 2020-01-27 03:07:38 --> Output Class Initialized
INFO - 2020-01-27 03:07:38 --> Security Class Initialized
DEBUG - 2020-01-27 03:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:07:38 --> Input Class Initialized
INFO - 2020-01-27 03:07:38 --> Language Class Initialized
INFO - 2020-01-27 03:07:38 --> Language Class Initialized
INFO - 2020-01-27 03:07:38 --> Config Class Initialized
INFO - 2020-01-27 03:07:38 --> Loader Class Initialized
INFO - 2020-01-27 03:07:38 --> Helper loaded: url_helper
INFO - 2020-01-27 03:07:38 --> Helper loaded: file_helper
INFO - 2020-01-27 03:07:38 --> Helper loaded: form_helper
INFO - 2020-01-27 03:07:38 --> Helper loaded: my_helper
INFO - 2020-01-27 03:07:39 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:07:39 --> Controller Class Initialized
INFO - 2020-01-27 03:07:39 --> Final output sent to browser
DEBUG - 2020-01-27 03:07:39 --> Total execution time: 0.3424
INFO - 2020-01-27 03:07:48 --> Config Class Initialized
INFO - 2020-01-27 03:07:48 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:07:48 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:07:48 --> Utf8 Class Initialized
INFO - 2020-01-27 03:07:48 --> URI Class Initialized
INFO - 2020-01-27 03:07:48 --> Router Class Initialized
INFO - 2020-01-27 03:07:48 --> Output Class Initialized
INFO - 2020-01-27 03:07:49 --> Security Class Initialized
DEBUG - 2020-01-27 03:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:07:49 --> Input Class Initialized
INFO - 2020-01-27 03:07:49 --> Language Class Initialized
INFO - 2020-01-27 03:07:49 --> Language Class Initialized
INFO - 2020-01-27 03:07:49 --> Config Class Initialized
INFO - 2020-01-27 03:07:49 --> Loader Class Initialized
INFO - 2020-01-27 03:07:49 --> Helper loaded: url_helper
INFO - 2020-01-27 03:07:49 --> Helper loaded: file_helper
INFO - 2020-01-27 03:07:49 --> Helper loaded: form_helper
INFO - 2020-01-27 03:07:49 --> Helper loaded: my_helper
INFO - 2020-01-27 03:07:49 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:07:49 --> Controller Class Initialized
INFO - 2020-01-27 03:07:49 --> Final output sent to browser
DEBUG - 2020-01-27 03:07:49 --> Total execution time: 0.4029
INFO - 2020-01-27 03:07:50 --> Config Class Initialized
INFO - 2020-01-27 03:07:50 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:07:50 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:07:50 --> Utf8 Class Initialized
INFO - 2020-01-27 03:07:50 --> URI Class Initialized
INFO - 2020-01-27 03:07:50 --> Router Class Initialized
INFO - 2020-01-27 03:07:50 --> Output Class Initialized
INFO - 2020-01-27 03:07:50 --> Security Class Initialized
DEBUG - 2020-01-27 03:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:07:50 --> Input Class Initialized
INFO - 2020-01-27 03:07:50 --> Language Class Initialized
INFO - 2020-01-27 03:07:50 --> Language Class Initialized
INFO - 2020-01-27 03:07:50 --> Config Class Initialized
INFO - 2020-01-27 03:07:50 --> Loader Class Initialized
INFO - 2020-01-27 03:07:50 --> Helper loaded: url_helper
INFO - 2020-01-27 03:07:50 --> Helper loaded: file_helper
INFO - 2020-01-27 03:07:50 --> Helper loaded: form_helper
INFO - 2020-01-27 03:07:50 --> Helper loaded: my_helper
INFO - 2020-01-27 03:07:50 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:07:50 --> Controller Class Initialized
INFO - 2020-01-27 03:07:50 --> Final output sent to browser
DEBUG - 2020-01-27 03:07:50 --> Total execution time: 0.3768
INFO - 2020-01-27 03:07:57 --> Config Class Initialized
INFO - 2020-01-27 03:07:57 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:07:57 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:07:57 --> Utf8 Class Initialized
INFO - 2020-01-27 03:07:57 --> URI Class Initialized
INFO - 2020-01-27 03:07:57 --> Router Class Initialized
INFO - 2020-01-27 03:07:57 --> Output Class Initialized
INFO - 2020-01-27 03:07:57 --> Security Class Initialized
DEBUG - 2020-01-27 03:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:07:57 --> Input Class Initialized
INFO - 2020-01-27 03:07:57 --> Language Class Initialized
INFO - 2020-01-27 03:07:57 --> Language Class Initialized
INFO - 2020-01-27 03:07:57 --> Config Class Initialized
INFO - 2020-01-27 03:07:57 --> Loader Class Initialized
INFO - 2020-01-27 03:07:57 --> Helper loaded: url_helper
INFO - 2020-01-27 03:07:57 --> Helper loaded: file_helper
INFO - 2020-01-27 03:07:57 --> Helper loaded: form_helper
INFO - 2020-01-27 03:07:57 --> Helper loaded: my_helper
INFO - 2020-01-27 03:07:58 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:07:58 --> Controller Class Initialized
INFO - 2020-01-27 03:07:58 --> Final output sent to browser
DEBUG - 2020-01-27 03:07:58 --> Total execution time: 0.4227
INFO - 2020-01-27 03:08:01 --> Config Class Initialized
INFO - 2020-01-27 03:08:01 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:08:01 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:08:01 --> Utf8 Class Initialized
INFO - 2020-01-27 03:08:01 --> URI Class Initialized
INFO - 2020-01-27 03:08:01 --> Router Class Initialized
INFO - 2020-01-27 03:08:01 --> Output Class Initialized
INFO - 2020-01-27 03:08:01 --> Security Class Initialized
DEBUG - 2020-01-27 03:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:08:01 --> Input Class Initialized
INFO - 2020-01-27 03:08:01 --> Language Class Initialized
INFO - 2020-01-27 03:08:01 --> Language Class Initialized
INFO - 2020-01-27 03:08:01 --> Config Class Initialized
INFO - 2020-01-27 03:08:01 --> Loader Class Initialized
INFO - 2020-01-27 03:08:02 --> Helper loaded: url_helper
INFO - 2020-01-27 03:08:02 --> Helper loaded: file_helper
INFO - 2020-01-27 03:08:02 --> Helper loaded: form_helper
INFO - 2020-01-27 03:08:02 --> Helper loaded: my_helper
INFO - 2020-01-27 03:08:02 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:08:02 --> Controller Class Initialized
DEBUG - 2020-01-27 03:08:02 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-01-27 03:08:02 --> Final output sent to browser
DEBUG - 2020-01-27 03:08:02 --> Total execution time: 0.4003
INFO - 2020-01-27 03:09:53 --> Config Class Initialized
INFO - 2020-01-27 03:09:53 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:09:53 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:09:53 --> Utf8 Class Initialized
INFO - 2020-01-27 03:09:53 --> URI Class Initialized
INFO - 2020-01-27 03:09:53 --> Router Class Initialized
INFO - 2020-01-27 03:09:53 --> Output Class Initialized
INFO - 2020-01-27 03:09:53 --> Security Class Initialized
DEBUG - 2020-01-27 03:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:09:53 --> Input Class Initialized
INFO - 2020-01-27 03:09:53 --> Language Class Initialized
INFO - 2020-01-27 03:09:53 --> Language Class Initialized
INFO - 2020-01-27 03:09:53 --> Config Class Initialized
INFO - 2020-01-27 03:09:53 --> Loader Class Initialized
INFO - 2020-01-27 03:09:53 --> Helper loaded: url_helper
INFO - 2020-01-27 03:09:53 --> Helper loaded: file_helper
INFO - 2020-01-27 03:09:53 --> Helper loaded: form_helper
INFO - 2020-01-27 03:09:53 --> Helper loaded: my_helper
INFO - 2020-01-27 03:09:53 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:09:53 --> Controller Class Initialized
DEBUG - 2020-01-27 03:09:53 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_absensi/views/list.php
DEBUG - 2020-01-27 03:09:53 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 03:09:53 --> Final output sent to browser
DEBUG - 2020-01-27 03:09:53 --> Total execution time: 0.4227
INFO - 2020-01-27 03:10:27 --> Config Class Initialized
INFO - 2020-01-27 03:10:27 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:10:27 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:10:27 --> Utf8 Class Initialized
INFO - 2020-01-27 03:10:27 --> URI Class Initialized
INFO - 2020-01-27 03:10:27 --> Router Class Initialized
INFO - 2020-01-27 03:10:27 --> Output Class Initialized
INFO - 2020-01-27 03:10:27 --> Security Class Initialized
DEBUG - 2020-01-27 03:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:10:28 --> Input Class Initialized
INFO - 2020-01-27 03:10:28 --> Language Class Initialized
INFO - 2020-01-27 03:10:28 --> Language Class Initialized
INFO - 2020-01-27 03:10:28 --> Config Class Initialized
INFO - 2020-01-27 03:10:28 --> Loader Class Initialized
INFO - 2020-01-27 03:10:28 --> Helper loaded: url_helper
INFO - 2020-01-27 03:10:28 --> Helper loaded: file_helper
INFO - 2020-01-27 03:10:28 --> Helper loaded: form_helper
INFO - 2020-01-27 03:10:28 --> Helper loaded: my_helper
INFO - 2020-01-27 03:10:28 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:10:28 --> Controller Class Initialized
INFO - 2020-01-27 03:10:28 --> Final output sent to browser
DEBUG - 2020-01-27 03:10:28 --> Total execution time: 0.3810
INFO - 2020-01-27 03:10:33 --> Config Class Initialized
INFO - 2020-01-27 03:10:33 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:10:33 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:10:33 --> Utf8 Class Initialized
INFO - 2020-01-27 03:10:33 --> URI Class Initialized
INFO - 2020-01-27 03:10:33 --> Router Class Initialized
INFO - 2020-01-27 03:10:33 --> Output Class Initialized
INFO - 2020-01-27 03:10:34 --> Security Class Initialized
DEBUG - 2020-01-27 03:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:10:34 --> Input Class Initialized
INFO - 2020-01-27 03:10:34 --> Language Class Initialized
INFO - 2020-01-27 03:10:34 --> Language Class Initialized
INFO - 2020-01-27 03:10:34 --> Config Class Initialized
INFO - 2020-01-27 03:10:34 --> Loader Class Initialized
INFO - 2020-01-27 03:10:34 --> Helper loaded: url_helper
INFO - 2020-01-27 03:10:34 --> Helper loaded: file_helper
INFO - 2020-01-27 03:10:34 --> Helper loaded: form_helper
INFO - 2020-01-27 03:10:34 --> Helper loaded: my_helper
INFO - 2020-01-27 03:10:34 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:10:34 --> Controller Class Initialized
DEBUG - 2020-01-27 03:10:34 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-01-27 03:10:34 --> Final output sent to browser
DEBUG - 2020-01-27 03:10:34 --> Total execution time: 0.4093
INFO - 2020-01-27 03:37:20 --> Config Class Initialized
INFO - 2020-01-27 03:37:20 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:37:20 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:37:20 --> Utf8 Class Initialized
INFO - 2020-01-27 03:37:20 --> URI Class Initialized
INFO - 2020-01-27 03:37:20 --> Router Class Initialized
INFO - 2020-01-27 03:37:20 --> Output Class Initialized
INFO - 2020-01-27 03:37:20 --> Security Class Initialized
DEBUG - 2020-01-27 03:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:37:20 --> Input Class Initialized
INFO - 2020-01-27 03:37:20 --> Language Class Initialized
INFO - 2020-01-27 03:37:20 --> Language Class Initialized
INFO - 2020-01-27 03:37:20 --> Config Class Initialized
INFO - 2020-01-27 03:37:20 --> Loader Class Initialized
INFO - 2020-01-27 03:37:20 --> Helper loaded: url_helper
INFO - 2020-01-27 03:37:20 --> Helper loaded: file_helper
INFO - 2020-01-27 03:37:20 --> Helper loaded: form_helper
INFO - 2020-01-27 03:37:20 --> Helper loaded: my_helper
INFO - 2020-01-27 03:37:20 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:37:20 --> Controller Class Initialized
DEBUG - 2020-01-27 03:37:20 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_mapel/views/list.php
DEBUG - 2020-01-27 03:37:20 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 03:37:20 --> Final output sent to browser
DEBUG - 2020-01-27 03:37:20 --> Total execution time: 0.4158
INFO - 2020-01-27 03:37:20 --> Config Class Initialized
INFO - 2020-01-27 03:37:20 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:37:20 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:37:20 --> Utf8 Class Initialized
INFO - 2020-01-27 03:37:20 --> URI Class Initialized
INFO - 2020-01-27 03:37:20 --> Router Class Initialized
INFO - 2020-01-27 03:37:20 --> Output Class Initialized
INFO - 2020-01-27 03:37:20 --> Security Class Initialized
DEBUG - 2020-01-27 03:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:37:20 --> Input Class Initialized
INFO - 2020-01-27 03:37:20 --> Language Class Initialized
INFO - 2020-01-27 03:37:20 --> Language Class Initialized
INFO - 2020-01-27 03:37:20 --> Config Class Initialized
INFO - 2020-01-27 03:37:20 --> Loader Class Initialized
INFO - 2020-01-27 03:37:20 --> Helper loaded: url_helper
INFO - 2020-01-27 03:37:20 --> Helper loaded: file_helper
INFO - 2020-01-27 03:37:20 --> Helper loaded: form_helper
INFO - 2020-01-27 03:37:20 --> Helper loaded: my_helper
INFO - 2020-01-27 03:37:20 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:37:20 --> Controller Class Initialized
INFO - 2020-01-27 03:37:28 --> Config Class Initialized
INFO - 2020-01-27 03:37:28 --> Hooks Class Initialized
DEBUG - 2020-01-27 03:37:28 --> UTF-8 Support Enabled
INFO - 2020-01-27 03:37:28 --> Utf8 Class Initialized
INFO - 2020-01-27 03:37:28 --> URI Class Initialized
INFO - 2020-01-27 03:37:28 --> Router Class Initialized
INFO - 2020-01-27 03:37:28 --> Output Class Initialized
INFO - 2020-01-27 03:37:28 --> Security Class Initialized
DEBUG - 2020-01-27 03:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 03:37:28 --> Input Class Initialized
INFO - 2020-01-27 03:37:28 --> Language Class Initialized
INFO - 2020-01-27 03:37:28 --> Language Class Initialized
INFO - 2020-01-27 03:37:28 --> Config Class Initialized
INFO - 2020-01-27 03:37:28 --> Loader Class Initialized
INFO - 2020-01-27 03:37:28 --> Helper loaded: url_helper
INFO - 2020-01-27 03:37:28 --> Helper loaded: file_helper
INFO - 2020-01-27 03:37:28 --> Helper loaded: form_helper
INFO - 2020-01-27 03:37:28 --> Helper loaded: my_helper
INFO - 2020-01-27 03:37:28 --> Database Driver Class Initialized
DEBUG - 2020-01-27 03:37:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 03:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 03:37:28 --> Controller Class Initialized
INFO - 2020-01-27 03:37:28 --> Final output sent to browser
DEBUG - 2020-01-27 03:37:29 --> Total execution time: 0.3437
INFO - 2020-01-27 06:47:28 --> Config Class Initialized
INFO - 2020-01-27 06:47:28 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:47:28 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:47:28 --> Utf8 Class Initialized
INFO - 2020-01-27 06:47:28 --> URI Class Initialized
DEBUG - 2020-01-27 06:47:28 --> No URI present. Default controller set.
INFO - 2020-01-27 06:47:28 --> Router Class Initialized
INFO - 2020-01-27 06:47:28 --> Output Class Initialized
INFO - 2020-01-27 06:47:28 --> Security Class Initialized
DEBUG - 2020-01-27 06:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:47:28 --> Input Class Initialized
INFO - 2020-01-27 06:47:28 --> Language Class Initialized
INFO - 2020-01-27 06:47:29 --> Language Class Initialized
INFO - 2020-01-27 06:47:29 --> Config Class Initialized
INFO - 2020-01-27 06:47:29 --> Loader Class Initialized
INFO - 2020-01-27 06:47:29 --> Helper loaded: url_helper
INFO - 2020-01-27 06:47:29 --> Helper loaded: file_helper
INFO - 2020-01-27 06:47:29 --> Helper loaded: form_helper
INFO - 2020-01-27 06:47:29 --> Helper loaded: my_helper
INFO - 2020-01-27 06:47:29 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:47:29 --> Controller Class Initialized
INFO - 2020-01-27 06:47:29 --> Config Class Initialized
INFO - 2020-01-27 06:47:29 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:47:29 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:47:29 --> Utf8 Class Initialized
INFO - 2020-01-27 06:47:29 --> URI Class Initialized
INFO - 2020-01-27 06:47:29 --> Router Class Initialized
INFO - 2020-01-27 06:47:29 --> Output Class Initialized
INFO - 2020-01-27 06:47:29 --> Security Class Initialized
DEBUG - 2020-01-27 06:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:47:29 --> Input Class Initialized
INFO - 2020-01-27 06:47:29 --> Language Class Initialized
INFO - 2020-01-27 06:47:29 --> Language Class Initialized
INFO - 2020-01-27 06:47:29 --> Config Class Initialized
INFO - 2020-01-27 06:47:29 --> Loader Class Initialized
INFO - 2020-01-27 06:47:29 --> Helper loaded: url_helper
INFO - 2020-01-27 06:47:29 --> Helper loaded: file_helper
INFO - 2020-01-27 06:47:29 --> Helper loaded: form_helper
INFO - 2020-01-27 06:47:29 --> Helper loaded: my_helper
INFO - 2020-01-27 06:47:29 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:47:29 --> Controller Class Initialized
DEBUG - 2020-01-27 06:47:29 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-27 06:47:29 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 06:47:29 --> Final output sent to browser
DEBUG - 2020-01-27 06:47:30 --> Total execution time: 0.4400
INFO - 2020-01-27 06:47:38 --> Config Class Initialized
INFO - 2020-01-27 06:47:38 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:47:38 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:47:38 --> Utf8 Class Initialized
INFO - 2020-01-27 06:47:38 --> URI Class Initialized
INFO - 2020-01-27 06:47:38 --> Router Class Initialized
INFO - 2020-01-27 06:47:38 --> Output Class Initialized
INFO - 2020-01-27 06:47:38 --> Security Class Initialized
DEBUG - 2020-01-27 06:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:47:38 --> Input Class Initialized
INFO - 2020-01-27 06:47:38 --> Language Class Initialized
INFO - 2020-01-27 06:47:38 --> Language Class Initialized
INFO - 2020-01-27 06:47:38 --> Config Class Initialized
INFO - 2020-01-27 06:47:38 --> Loader Class Initialized
INFO - 2020-01-27 06:47:38 --> Helper loaded: url_helper
INFO - 2020-01-27 06:47:38 --> Helper loaded: file_helper
INFO - 2020-01-27 06:47:38 --> Helper loaded: form_helper
INFO - 2020-01-27 06:47:38 --> Helper loaded: my_helper
INFO - 2020-01-27 06:47:38 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:47:38 --> Controller Class Initialized
INFO - 2020-01-27 06:47:38 --> Final output sent to browser
DEBUG - 2020-01-27 06:47:38 --> Total execution time: 0.3585
INFO - 2020-01-27 06:47:43 --> Config Class Initialized
INFO - 2020-01-27 06:47:43 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:47:43 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:47:43 --> Utf8 Class Initialized
INFO - 2020-01-27 06:47:43 --> URI Class Initialized
INFO - 2020-01-27 06:47:43 --> Router Class Initialized
INFO - 2020-01-27 06:47:43 --> Output Class Initialized
INFO - 2020-01-27 06:47:43 --> Security Class Initialized
DEBUG - 2020-01-27 06:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:47:43 --> Input Class Initialized
INFO - 2020-01-27 06:47:43 --> Language Class Initialized
INFO - 2020-01-27 06:47:43 --> Language Class Initialized
INFO - 2020-01-27 06:47:43 --> Config Class Initialized
INFO - 2020-01-27 06:47:43 --> Loader Class Initialized
INFO - 2020-01-27 06:47:43 --> Helper loaded: url_helper
INFO - 2020-01-27 06:47:43 --> Helper loaded: file_helper
INFO - 2020-01-27 06:47:43 --> Helper loaded: form_helper
INFO - 2020-01-27 06:47:43 --> Helper loaded: my_helper
INFO - 2020-01-27 06:47:43 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:47:43 --> Controller Class Initialized
INFO - 2020-01-27 06:47:43 --> Helper loaded: cookie_helper
INFO - 2020-01-27 06:47:43 --> Final output sent to browser
DEBUG - 2020-01-27 06:47:43 --> Total execution time: 0.3698
INFO - 2020-01-27 06:47:44 --> Config Class Initialized
INFO - 2020-01-27 06:47:44 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:47:44 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:47:44 --> Utf8 Class Initialized
INFO - 2020-01-27 06:47:44 --> URI Class Initialized
INFO - 2020-01-27 06:47:44 --> Router Class Initialized
INFO - 2020-01-27 06:47:44 --> Output Class Initialized
INFO - 2020-01-27 06:47:44 --> Security Class Initialized
DEBUG - 2020-01-27 06:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:47:44 --> Input Class Initialized
INFO - 2020-01-27 06:47:44 --> Language Class Initialized
INFO - 2020-01-27 06:47:44 --> Language Class Initialized
INFO - 2020-01-27 06:47:44 --> Config Class Initialized
INFO - 2020-01-27 06:47:44 --> Loader Class Initialized
INFO - 2020-01-27 06:47:44 --> Helper loaded: url_helper
INFO - 2020-01-27 06:47:44 --> Helper loaded: file_helper
INFO - 2020-01-27 06:47:44 --> Helper loaded: form_helper
INFO - 2020-01-27 06:47:44 --> Helper loaded: my_helper
INFO - 2020-01-27 06:47:44 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:47:45 --> Controller Class Initialized
DEBUG - 2020-01-27 06:47:45 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-27 06:47:45 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 06:47:45 --> Final output sent to browser
DEBUG - 2020-01-27 06:47:45 --> Total execution time: 0.5071
INFO - 2020-01-27 06:47:57 --> Config Class Initialized
INFO - 2020-01-27 06:47:57 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:47:57 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:47:57 --> Utf8 Class Initialized
INFO - 2020-01-27 06:47:57 --> URI Class Initialized
INFO - 2020-01-27 06:47:57 --> Router Class Initialized
INFO - 2020-01-27 06:47:57 --> Output Class Initialized
INFO - 2020-01-27 06:47:57 --> Security Class Initialized
DEBUG - 2020-01-27 06:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:47:57 --> Input Class Initialized
INFO - 2020-01-27 06:47:57 --> Language Class Initialized
INFO - 2020-01-27 06:47:57 --> Language Class Initialized
INFO - 2020-01-27 06:47:57 --> Config Class Initialized
INFO - 2020-01-27 06:47:57 --> Loader Class Initialized
INFO - 2020-01-27 06:47:57 --> Helper loaded: url_helper
INFO - 2020-01-27 06:47:57 --> Helper loaded: file_helper
INFO - 2020-01-27 06:47:57 --> Helper loaded: form_helper
INFO - 2020-01-27 06:47:57 --> Helper loaded: my_helper
INFO - 2020-01-27 06:47:57 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:47:57 --> Controller Class Initialized
DEBUG - 2020-01-27 06:47:57 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_guru/views/list.php
DEBUG - 2020-01-27 06:47:57 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 06:47:57 --> Final output sent to browser
DEBUG - 2020-01-27 06:47:57 --> Total execution time: 0.3923
INFO - 2020-01-27 06:47:58 --> Config Class Initialized
INFO - 2020-01-27 06:47:58 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:47:58 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:47:58 --> Utf8 Class Initialized
INFO - 2020-01-27 06:47:58 --> URI Class Initialized
INFO - 2020-01-27 06:47:58 --> Router Class Initialized
INFO - 2020-01-27 06:47:58 --> Output Class Initialized
INFO - 2020-01-27 06:47:58 --> Security Class Initialized
DEBUG - 2020-01-27 06:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:47:58 --> Input Class Initialized
INFO - 2020-01-27 06:47:58 --> Language Class Initialized
INFO - 2020-01-27 06:47:58 --> Language Class Initialized
INFO - 2020-01-27 06:47:58 --> Config Class Initialized
INFO - 2020-01-27 06:47:58 --> Loader Class Initialized
INFO - 2020-01-27 06:47:58 --> Helper loaded: url_helper
INFO - 2020-01-27 06:47:58 --> Helper loaded: file_helper
INFO - 2020-01-27 06:47:58 --> Helper loaded: form_helper
INFO - 2020-01-27 06:47:58 --> Helper loaded: my_helper
INFO - 2020-01-27 06:47:58 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:47:58 --> Controller Class Initialized
INFO - 2020-01-27 06:48:00 --> Config Class Initialized
INFO - 2020-01-27 06:48:00 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:48:00 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:48:00 --> Utf8 Class Initialized
INFO - 2020-01-27 06:48:00 --> URI Class Initialized
INFO - 2020-01-27 06:48:00 --> Router Class Initialized
INFO - 2020-01-27 06:48:00 --> Output Class Initialized
INFO - 2020-01-27 06:48:00 --> Security Class Initialized
DEBUG - 2020-01-27 06:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:48:00 --> Input Class Initialized
INFO - 2020-01-27 06:48:00 --> Language Class Initialized
INFO - 2020-01-27 06:48:00 --> Language Class Initialized
INFO - 2020-01-27 06:48:00 --> Config Class Initialized
INFO - 2020-01-27 06:48:00 --> Loader Class Initialized
INFO - 2020-01-27 06:48:00 --> Helper loaded: url_helper
INFO - 2020-01-27 06:48:00 --> Helper loaded: file_helper
INFO - 2020-01-27 06:48:00 --> Helper loaded: form_helper
INFO - 2020-01-27 06:48:00 --> Helper loaded: my_helper
INFO - 2020-01-27 06:48:00 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:48:00 --> Controller Class Initialized
DEBUG - 2020-01-27 06:48:01 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_siswa/views/list.php
DEBUG - 2020-01-27 06:48:01 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 06:48:01 --> Final output sent to browser
DEBUG - 2020-01-27 06:48:01 --> Total execution time: 0.7351
INFO - 2020-01-27 06:48:01 --> Config Class Initialized
INFO - 2020-01-27 06:48:01 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:48:01 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:48:01 --> Utf8 Class Initialized
INFO - 2020-01-27 06:48:01 --> URI Class Initialized
INFO - 2020-01-27 06:48:01 --> Router Class Initialized
INFO - 2020-01-27 06:48:01 --> Output Class Initialized
INFO - 2020-01-27 06:48:01 --> Security Class Initialized
DEBUG - 2020-01-27 06:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:48:01 --> Input Class Initialized
INFO - 2020-01-27 06:48:01 --> Language Class Initialized
INFO - 2020-01-27 06:48:01 --> Language Class Initialized
INFO - 2020-01-27 06:48:01 --> Config Class Initialized
INFO - 2020-01-27 06:48:01 --> Loader Class Initialized
INFO - 2020-01-27 06:48:01 --> Helper loaded: url_helper
INFO - 2020-01-27 06:48:01 --> Helper loaded: file_helper
INFO - 2020-01-27 06:48:01 --> Helper loaded: form_helper
INFO - 2020-01-27 06:48:01 --> Helper loaded: my_helper
INFO - 2020-01-27 06:48:01 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:48:01 --> Controller Class Initialized
INFO - 2020-01-27 06:48:05 --> Config Class Initialized
INFO - 2020-01-27 06:48:05 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:48:05 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:48:05 --> Utf8 Class Initialized
INFO - 2020-01-27 06:48:05 --> URI Class Initialized
INFO - 2020-01-27 06:48:05 --> Router Class Initialized
INFO - 2020-01-27 06:48:05 --> Output Class Initialized
INFO - 2020-01-27 06:48:05 --> Security Class Initialized
DEBUG - 2020-01-27 06:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:48:05 --> Input Class Initialized
INFO - 2020-01-27 06:48:05 --> Language Class Initialized
INFO - 2020-01-27 06:48:05 --> Language Class Initialized
INFO - 2020-01-27 06:48:05 --> Config Class Initialized
INFO - 2020-01-27 06:48:05 --> Loader Class Initialized
INFO - 2020-01-27 06:48:05 --> Helper loaded: url_helper
INFO - 2020-01-27 06:48:05 --> Helper loaded: file_helper
INFO - 2020-01-27 06:48:05 --> Helper loaded: form_helper
INFO - 2020-01-27 06:48:05 --> Helper loaded: my_helper
INFO - 2020-01-27 06:48:05 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:48:05 --> Controller Class Initialized
DEBUG - 2020-01-27 06:48:05 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_kelas/views/list.php
DEBUG - 2020-01-27 06:48:05 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 06:48:05 --> Final output sent to browser
DEBUG - 2020-01-27 06:48:05 --> Total execution time: 0.4129
INFO - 2020-01-27 06:48:06 --> Config Class Initialized
INFO - 2020-01-27 06:48:06 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:48:06 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:48:06 --> Utf8 Class Initialized
INFO - 2020-01-27 06:48:06 --> URI Class Initialized
INFO - 2020-01-27 06:48:06 --> Router Class Initialized
INFO - 2020-01-27 06:48:06 --> Output Class Initialized
INFO - 2020-01-27 06:48:06 --> Security Class Initialized
DEBUG - 2020-01-27 06:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:48:06 --> Input Class Initialized
INFO - 2020-01-27 06:48:06 --> Language Class Initialized
INFO - 2020-01-27 06:48:06 --> Language Class Initialized
INFO - 2020-01-27 06:48:06 --> Config Class Initialized
INFO - 2020-01-27 06:48:06 --> Loader Class Initialized
INFO - 2020-01-27 06:48:06 --> Helper loaded: url_helper
INFO - 2020-01-27 06:48:06 --> Helper loaded: file_helper
INFO - 2020-01-27 06:48:06 --> Helper loaded: form_helper
INFO - 2020-01-27 06:48:06 --> Helper loaded: my_helper
INFO - 2020-01-27 06:48:06 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:48:06 --> Controller Class Initialized
INFO - 2020-01-27 06:48:07 --> Config Class Initialized
INFO - 2020-01-27 06:48:07 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:48:07 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:48:07 --> Utf8 Class Initialized
INFO - 2020-01-27 06:48:07 --> URI Class Initialized
INFO - 2020-01-27 06:48:07 --> Router Class Initialized
INFO - 2020-01-27 06:48:07 --> Output Class Initialized
INFO - 2020-01-27 06:48:07 --> Security Class Initialized
DEBUG - 2020-01-27 06:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:48:07 --> Input Class Initialized
INFO - 2020-01-27 06:48:07 --> Language Class Initialized
INFO - 2020-01-27 06:48:07 --> Language Class Initialized
INFO - 2020-01-27 06:48:07 --> Config Class Initialized
INFO - 2020-01-27 06:48:07 --> Loader Class Initialized
INFO - 2020-01-27 06:48:07 --> Helper loaded: url_helper
INFO - 2020-01-27 06:48:08 --> Helper loaded: file_helper
INFO - 2020-01-27 06:48:08 --> Helper loaded: form_helper
INFO - 2020-01-27 06:48:08 --> Helper loaded: my_helper
INFO - 2020-01-27 06:48:08 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:48:08 --> Controller Class Initialized
DEBUG - 2020-01-27 06:48:08 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_mapel/views/list.php
DEBUG - 2020-01-27 06:48:08 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 06:48:08 --> Final output sent to browser
DEBUG - 2020-01-27 06:48:08 --> Total execution time: 0.3780
INFO - 2020-01-27 06:48:08 --> Config Class Initialized
INFO - 2020-01-27 06:48:08 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:48:08 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:48:08 --> Utf8 Class Initialized
INFO - 2020-01-27 06:48:08 --> URI Class Initialized
INFO - 2020-01-27 06:48:08 --> Router Class Initialized
INFO - 2020-01-27 06:48:08 --> Output Class Initialized
INFO - 2020-01-27 06:48:08 --> Security Class Initialized
DEBUG - 2020-01-27 06:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:48:08 --> Input Class Initialized
INFO - 2020-01-27 06:48:08 --> Language Class Initialized
INFO - 2020-01-27 06:48:08 --> Language Class Initialized
INFO - 2020-01-27 06:48:08 --> Config Class Initialized
INFO - 2020-01-27 06:48:08 --> Loader Class Initialized
INFO - 2020-01-27 06:48:08 --> Helper loaded: url_helper
INFO - 2020-01-27 06:48:08 --> Helper loaded: file_helper
INFO - 2020-01-27 06:48:08 --> Helper loaded: form_helper
INFO - 2020-01-27 06:48:08 --> Helper loaded: my_helper
INFO - 2020-01-27 06:48:08 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:48:08 --> Controller Class Initialized
INFO - 2020-01-27 06:48:16 --> Config Class Initialized
INFO - 2020-01-27 06:48:16 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:48:16 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:48:16 --> Utf8 Class Initialized
INFO - 2020-01-27 06:48:16 --> URI Class Initialized
INFO - 2020-01-27 06:48:16 --> Router Class Initialized
INFO - 2020-01-27 06:48:16 --> Output Class Initialized
INFO - 2020-01-27 06:48:16 --> Security Class Initialized
DEBUG - 2020-01-27 06:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:48:16 --> Input Class Initialized
INFO - 2020-01-27 06:48:16 --> Language Class Initialized
INFO - 2020-01-27 06:48:16 --> Language Class Initialized
INFO - 2020-01-27 06:48:16 --> Config Class Initialized
INFO - 2020-01-27 06:48:16 --> Loader Class Initialized
INFO - 2020-01-27 06:48:16 --> Helper loaded: url_helper
INFO - 2020-01-27 06:48:16 --> Helper loaded: file_helper
INFO - 2020-01-27 06:48:16 --> Helper loaded: form_helper
INFO - 2020-01-27 06:48:16 --> Helper loaded: my_helper
INFO - 2020-01-27 06:48:16 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:48:16 --> Controller Class Initialized
DEBUG - 2020-01-27 06:48:16 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_ekstra/views/list.php
DEBUG - 2020-01-27 06:48:16 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 06:48:16 --> Final output sent to browser
DEBUG - 2020-01-27 06:48:16 --> Total execution time: 0.3912
INFO - 2020-01-27 06:48:16 --> Config Class Initialized
INFO - 2020-01-27 06:48:16 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:48:16 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:48:16 --> Utf8 Class Initialized
INFO - 2020-01-27 06:48:16 --> URI Class Initialized
INFO - 2020-01-27 06:48:16 --> Router Class Initialized
INFO - 2020-01-27 06:48:16 --> Output Class Initialized
INFO - 2020-01-27 06:48:16 --> Security Class Initialized
DEBUG - 2020-01-27 06:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:48:16 --> Input Class Initialized
INFO - 2020-01-27 06:48:16 --> Language Class Initialized
INFO - 2020-01-27 06:48:16 --> Language Class Initialized
INFO - 2020-01-27 06:48:16 --> Config Class Initialized
INFO - 2020-01-27 06:48:16 --> Loader Class Initialized
INFO - 2020-01-27 06:48:16 --> Helper loaded: url_helper
INFO - 2020-01-27 06:48:16 --> Helper loaded: file_helper
INFO - 2020-01-27 06:48:16 --> Helper loaded: form_helper
INFO - 2020-01-27 06:48:16 --> Helper loaded: my_helper
INFO - 2020-01-27 06:48:16 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:48:16 --> Controller Class Initialized
INFO - 2020-01-27 06:48:29 --> Config Class Initialized
INFO - 2020-01-27 06:48:29 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:48:29 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:48:29 --> Utf8 Class Initialized
INFO - 2020-01-27 06:48:29 --> URI Class Initialized
INFO - 2020-01-27 06:48:29 --> Router Class Initialized
INFO - 2020-01-27 06:48:29 --> Output Class Initialized
INFO - 2020-01-27 06:48:29 --> Security Class Initialized
DEBUG - 2020-01-27 06:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:48:29 --> Input Class Initialized
INFO - 2020-01-27 06:48:29 --> Language Class Initialized
INFO - 2020-01-27 06:48:29 --> Language Class Initialized
INFO - 2020-01-27 06:48:29 --> Config Class Initialized
INFO - 2020-01-27 06:48:29 --> Loader Class Initialized
INFO - 2020-01-27 06:48:29 --> Helper loaded: url_helper
INFO - 2020-01-27 06:48:29 --> Helper loaded: file_helper
INFO - 2020-01-27 06:48:29 --> Helper loaded: form_helper
INFO - 2020-01-27 06:48:29 --> Helper loaded: my_helper
INFO - 2020-01-27 06:48:29 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:48:29 --> Controller Class Initialized
INFO - 2020-01-27 06:48:29 --> Helper loaded: cookie_helper
INFO - 2020-01-27 06:48:29 --> Config Class Initialized
INFO - 2020-01-27 06:48:29 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:48:29 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:48:29 --> Utf8 Class Initialized
INFO - 2020-01-27 06:48:29 --> URI Class Initialized
INFO - 2020-01-27 06:48:29 --> Router Class Initialized
INFO - 2020-01-27 06:48:29 --> Output Class Initialized
INFO - 2020-01-27 06:48:29 --> Security Class Initialized
DEBUG - 2020-01-27 06:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:48:29 --> Input Class Initialized
INFO - 2020-01-27 06:48:29 --> Language Class Initialized
INFO - 2020-01-27 06:48:29 --> Language Class Initialized
INFO - 2020-01-27 06:48:29 --> Config Class Initialized
INFO - 2020-01-27 06:48:29 --> Loader Class Initialized
INFO - 2020-01-27 06:48:29 --> Helper loaded: url_helper
INFO - 2020-01-27 06:48:29 --> Helper loaded: file_helper
INFO - 2020-01-27 06:48:29 --> Helper loaded: form_helper
INFO - 2020-01-27 06:48:29 --> Helper loaded: my_helper
INFO - 2020-01-27 06:48:29 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:48:29 --> Controller Class Initialized
INFO - 2020-01-27 06:48:29 --> Config Class Initialized
INFO - 2020-01-27 06:48:29 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:48:29 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:48:30 --> Utf8 Class Initialized
INFO - 2020-01-27 06:48:30 --> URI Class Initialized
INFO - 2020-01-27 06:48:30 --> Router Class Initialized
INFO - 2020-01-27 06:48:30 --> Output Class Initialized
INFO - 2020-01-27 06:48:30 --> Security Class Initialized
DEBUG - 2020-01-27 06:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:48:30 --> Input Class Initialized
INFO - 2020-01-27 06:48:30 --> Language Class Initialized
INFO - 2020-01-27 06:48:30 --> Language Class Initialized
INFO - 2020-01-27 06:48:30 --> Config Class Initialized
INFO - 2020-01-27 06:48:30 --> Loader Class Initialized
INFO - 2020-01-27 06:48:30 --> Helper loaded: url_helper
INFO - 2020-01-27 06:48:30 --> Helper loaded: file_helper
INFO - 2020-01-27 06:48:30 --> Helper loaded: form_helper
INFO - 2020-01-27 06:48:30 --> Helper loaded: my_helper
INFO - 2020-01-27 06:48:30 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:48:30 --> Controller Class Initialized
DEBUG - 2020-01-27 06:48:30 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-27 06:48:30 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 06:48:30 --> Final output sent to browser
DEBUG - 2020-01-27 06:48:30 --> Total execution time: 0.3416
INFO - 2020-01-27 06:48:36 --> Config Class Initialized
INFO - 2020-01-27 06:48:36 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:48:36 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:48:36 --> Utf8 Class Initialized
INFO - 2020-01-27 06:48:36 --> URI Class Initialized
INFO - 2020-01-27 06:48:36 --> Router Class Initialized
INFO - 2020-01-27 06:48:36 --> Output Class Initialized
INFO - 2020-01-27 06:48:36 --> Security Class Initialized
DEBUG - 2020-01-27 06:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:48:36 --> Input Class Initialized
INFO - 2020-01-27 06:48:36 --> Language Class Initialized
INFO - 2020-01-27 06:48:36 --> Language Class Initialized
INFO - 2020-01-27 06:48:36 --> Config Class Initialized
INFO - 2020-01-27 06:48:36 --> Loader Class Initialized
INFO - 2020-01-27 06:48:36 --> Helper loaded: url_helper
INFO - 2020-01-27 06:48:36 --> Helper loaded: file_helper
INFO - 2020-01-27 06:48:36 --> Helper loaded: form_helper
INFO - 2020-01-27 06:48:36 --> Helper loaded: my_helper
INFO - 2020-01-27 06:48:36 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:48:36 --> Controller Class Initialized
DEBUG - 2020-01-27 06:48:36 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-27 06:48:36 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 06:48:36 --> Final output sent to browser
DEBUG - 2020-01-27 06:48:36 --> Total execution time: 0.4079
INFO - 2020-01-27 06:48:41 --> Config Class Initialized
INFO - 2020-01-27 06:48:41 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:48:41 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:48:41 --> Utf8 Class Initialized
INFO - 2020-01-27 06:48:41 --> URI Class Initialized
INFO - 2020-01-27 06:48:41 --> Router Class Initialized
INFO - 2020-01-27 06:48:41 --> Output Class Initialized
INFO - 2020-01-27 06:48:41 --> Security Class Initialized
DEBUG - 2020-01-27 06:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:48:41 --> Input Class Initialized
INFO - 2020-01-27 06:48:41 --> Language Class Initialized
INFO - 2020-01-27 06:48:41 --> Language Class Initialized
INFO - 2020-01-27 06:48:41 --> Config Class Initialized
INFO - 2020-01-27 06:48:41 --> Loader Class Initialized
INFO - 2020-01-27 06:48:41 --> Helper loaded: url_helper
INFO - 2020-01-27 06:48:41 --> Helper loaded: file_helper
INFO - 2020-01-27 06:48:41 --> Helper loaded: form_helper
INFO - 2020-01-27 06:48:41 --> Helper loaded: my_helper
INFO - 2020-01-27 06:48:41 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:48:41 --> Controller Class Initialized
INFO - 2020-01-27 06:48:41 --> Helper loaded: cookie_helper
INFO - 2020-01-27 06:48:41 --> Final output sent to browser
DEBUG - 2020-01-27 06:48:41 --> Total execution time: 0.3776
INFO - 2020-01-27 06:48:43 --> Config Class Initialized
INFO - 2020-01-27 06:48:43 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:48:43 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:48:43 --> Utf8 Class Initialized
INFO - 2020-01-27 06:48:43 --> URI Class Initialized
INFO - 2020-01-27 06:48:43 --> Router Class Initialized
INFO - 2020-01-27 06:48:43 --> Output Class Initialized
INFO - 2020-01-27 06:48:43 --> Security Class Initialized
DEBUG - 2020-01-27 06:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:48:43 --> Input Class Initialized
INFO - 2020-01-27 06:48:43 --> Language Class Initialized
INFO - 2020-01-27 06:48:43 --> Language Class Initialized
INFO - 2020-01-27 06:48:43 --> Config Class Initialized
INFO - 2020-01-27 06:48:43 --> Loader Class Initialized
INFO - 2020-01-27 06:48:43 --> Helper loaded: url_helper
INFO - 2020-01-27 06:48:43 --> Helper loaded: file_helper
INFO - 2020-01-27 06:48:43 --> Helper loaded: form_helper
INFO - 2020-01-27 06:48:43 --> Helper loaded: my_helper
INFO - 2020-01-27 06:48:43 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:48:43 --> Controller Class Initialized
DEBUG - 2020-01-27 06:48:43 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-27 06:48:43 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 06:48:43 --> Final output sent to browser
DEBUG - 2020-01-27 06:48:43 --> Total execution time: 0.4511
INFO - 2020-01-27 06:48:53 --> Config Class Initialized
INFO - 2020-01-27 06:48:53 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:48:53 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:48:53 --> Utf8 Class Initialized
INFO - 2020-01-27 06:48:53 --> URI Class Initialized
INFO - 2020-01-27 06:48:53 --> Router Class Initialized
INFO - 2020-01-27 06:48:53 --> Output Class Initialized
INFO - 2020-01-27 06:48:53 --> Security Class Initialized
DEBUG - 2020-01-27 06:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:48:53 --> Input Class Initialized
INFO - 2020-01-27 06:48:53 --> Language Class Initialized
INFO - 2020-01-27 06:48:53 --> Language Class Initialized
INFO - 2020-01-27 06:48:53 --> Config Class Initialized
INFO - 2020-01-27 06:48:53 --> Loader Class Initialized
INFO - 2020-01-27 06:48:53 --> Helper loaded: url_helper
INFO - 2020-01-27 06:48:53 --> Helper loaded: file_helper
INFO - 2020-01-27 06:48:53 --> Helper loaded: form_helper
INFO - 2020-01-27 06:48:53 --> Helper loaded: my_helper
INFO - 2020-01-27 06:48:53 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:48:53 --> Controller Class Initialized
INFO - 2020-01-27 06:48:53 --> Helper loaded: cookie_helper
INFO - 2020-01-27 06:48:53 --> Final output sent to browser
DEBUG - 2020-01-27 06:48:53 --> Total execution time: 0.3912
INFO - 2020-01-27 06:48:55 --> Config Class Initialized
INFO - 2020-01-27 06:48:55 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:48:55 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:48:55 --> Utf8 Class Initialized
INFO - 2020-01-27 06:48:55 --> URI Class Initialized
INFO - 2020-01-27 06:48:55 --> Router Class Initialized
INFO - 2020-01-27 06:48:55 --> Output Class Initialized
INFO - 2020-01-27 06:48:55 --> Security Class Initialized
DEBUG - 2020-01-27 06:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:48:55 --> Input Class Initialized
INFO - 2020-01-27 06:48:55 --> Language Class Initialized
INFO - 2020-01-27 06:48:55 --> Language Class Initialized
INFO - 2020-01-27 06:48:55 --> Config Class Initialized
INFO - 2020-01-27 06:48:55 --> Loader Class Initialized
INFO - 2020-01-27 06:48:55 --> Helper loaded: url_helper
INFO - 2020-01-27 06:48:55 --> Helper loaded: file_helper
INFO - 2020-01-27 06:48:55 --> Helper loaded: form_helper
INFO - 2020-01-27 06:48:55 --> Helper loaded: my_helper
INFO - 2020-01-27 06:48:55 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:48:55 --> Controller Class Initialized
DEBUG - 2020-01-27 06:48:55 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-27 06:48:55 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 06:48:55 --> Final output sent to browser
DEBUG - 2020-01-27 06:48:55 --> Total execution time: 0.4427
INFO - 2020-01-27 06:48:59 --> Config Class Initialized
INFO - 2020-01-27 06:48:59 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:48:59 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:48:59 --> Utf8 Class Initialized
INFO - 2020-01-27 06:48:59 --> URI Class Initialized
INFO - 2020-01-27 06:48:59 --> Router Class Initialized
INFO - 2020-01-27 06:48:59 --> Output Class Initialized
INFO - 2020-01-27 06:48:59 --> Security Class Initialized
DEBUG - 2020-01-27 06:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:48:59 --> Input Class Initialized
INFO - 2020-01-27 06:48:59 --> Language Class Initialized
INFO - 2020-01-27 06:48:59 --> Language Class Initialized
INFO - 2020-01-27 06:48:59 --> Config Class Initialized
INFO - 2020-01-27 06:48:59 --> Loader Class Initialized
INFO - 2020-01-27 06:48:59 --> Helper loaded: url_helper
INFO - 2020-01-27 06:48:59 --> Helper loaded: file_helper
INFO - 2020-01-27 06:48:59 --> Helper loaded: form_helper
INFO - 2020-01-27 06:48:59 --> Helper loaded: my_helper
INFO - 2020-01-27 06:48:59 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:48:59 --> Controller Class Initialized
DEBUG - 2020-01-27 06:48:59 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-01-27 06:48:59 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 06:48:59 --> Final output sent to browser
DEBUG - 2020-01-27 06:48:59 --> Total execution time: 0.3946
INFO - 2020-01-27 06:49:02 --> Config Class Initialized
INFO - 2020-01-27 06:49:02 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:49:02 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:49:02 --> Utf8 Class Initialized
INFO - 2020-01-27 06:49:02 --> URI Class Initialized
INFO - 2020-01-27 06:49:02 --> Router Class Initialized
INFO - 2020-01-27 06:49:02 --> Output Class Initialized
INFO - 2020-01-27 06:49:02 --> Security Class Initialized
DEBUG - 2020-01-27 06:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:49:02 --> Input Class Initialized
INFO - 2020-01-27 06:49:02 --> Language Class Initialized
INFO - 2020-01-27 06:49:02 --> Language Class Initialized
INFO - 2020-01-27 06:49:02 --> Config Class Initialized
INFO - 2020-01-27 06:49:02 --> Loader Class Initialized
INFO - 2020-01-27 06:49:02 --> Helper loaded: url_helper
INFO - 2020-01-27 06:49:02 --> Helper loaded: file_helper
INFO - 2020-01-27 06:49:02 --> Helper loaded: form_helper
INFO - 2020-01-27 06:49:02 --> Helper loaded: my_helper
INFO - 2020-01-27 06:49:02 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:49:02 --> Controller Class Initialized
DEBUG - 2020-01-27 06:49:02 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-01-27 06:49:02 --> Final output sent to browser
DEBUG - 2020-01-27 06:49:02 --> Total execution time: 0.5056
INFO - 2020-01-27 06:49:12 --> Config Class Initialized
INFO - 2020-01-27 06:49:12 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:49:12 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:49:12 --> Utf8 Class Initialized
INFO - 2020-01-27 06:49:12 --> URI Class Initialized
INFO - 2020-01-27 06:49:12 --> Router Class Initialized
INFO - 2020-01-27 06:49:12 --> Output Class Initialized
INFO - 2020-01-27 06:49:12 --> Security Class Initialized
DEBUG - 2020-01-27 06:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:49:12 --> Input Class Initialized
INFO - 2020-01-27 06:49:13 --> Language Class Initialized
INFO - 2020-01-27 06:49:13 --> Language Class Initialized
INFO - 2020-01-27 06:49:13 --> Config Class Initialized
INFO - 2020-01-27 06:49:13 --> Loader Class Initialized
INFO - 2020-01-27 06:49:13 --> Helper loaded: url_helper
INFO - 2020-01-27 06:49:13 --> Helper loaded: file_helper
INFO - 2020-01-27 06:49:13 --> Helper loaded: form_helper
INFO - 2020-01-27 06:49:13 --> Helper loaded: my_helper
INFO - 2020-01-27 06:49:13 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:49:13 --> Controller Class Initialized
ERROR - 2020-01-27 06:49:13 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 06:49:13 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 06:49:13 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 06:49:13 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 06:49:13 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 06:49:13 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 06:49:13 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 06:49:13 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 06:49:13 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 06:49:13 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 06:49:13 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 06:49:13 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 06:49:13 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 06:49:13 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 06:49:13 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 06:49:13 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 06:49:13 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 06:49:13 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 06:49:13 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 06:49:13 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
DEBUG - 2020-01-27 06:49:13 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 06:49:13 --> Final output sent to browser
DEBUG - 2020-01-27 06:49:13 --> Total execution time: 0.8456
INFO - 2020-01-27 06:49:19 --> Config Class Initialized
INFO - 2020-01-27 06:49:19 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:49:19 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:49:19 --> Utf8 Class Initialized
INFO - 2020-01-27 06:49:19 --> URI Class Initialized
INFO - 2020-01-27 06:49:19 --> Router Class Initialized
INFO - 2020-01-27 06:49:19 --> Output Class Initialized
INFO - 2020-01-27 06:49:19 --> Security Class Initialized
DEBUG - 2020-01-27 06:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:49:19 --> Input Class Initialized
INFO - 2020-01-27 06:49:19 --> Language Class Initialized
INFO - 2020-01-27 06:49:19 --> Language Class Initialized
INFO - 2020-01-27 06:49:19 --> Config Class Initialized
INFO - 2020-01-27 06:49:19 --> Loader Class Initialized
INFO - 2020-01-27 06:49:19 --> Helper loaded: url_helper
INFO - 2020-01-27 06:49:19 --> Helper loaded: file_helper
INFO - 2020-01-27 06:49:19 --> Helper loaded: form_helper
INFO - 2020-01-27 06:49:19 --> Helper loaded: my_helper
INFO - 2020-01-27 06:49:19 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:49:20 --> Controller Class Initialized
DEBUG - 2020-01-27 06:49:20 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-01-27 06:49:20 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 06:49:20 --> Final output sent to browser
DEBUG - 2020-01-27 06:49:20 --> Total execution time: 0.3795
INFO - 2020-01-27 06:49:22 --> Config Class Initialized
INFO - 2020-01-27 06:49:22 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:49:22 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:49:22 --> Utf8 Class Initialized
INFO - 2020-01-27 06:49:22 --> URI Class Initialized
INFO - 2020-01-27 06:49:22 --> Router Class Initialized
INFO - 2020-01-27 06:49:22 --> Output Class Initialized
INFO - 2020-01-27 06:49:22 --> Security Class Initialized
DEBUG - 2020-01-27 06:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:49:22 --> Input Class Initialized
INFO - 2020-01-27 06:49:22 --> Language Class Initialized
INFO - 2020-01-27 06:49:22 --> Language Class Initialized
INFO - 2020-01-27 06:49:22 --> Config Class Initialized
INFO - 2020-01-27 06:49:22 --> Loader Class Initialized
INFO - 2020-01-27 06:49:22 --> Helper loaded: url_helper
INFO - 2020-01-27 06:49:22 --> Helper loaded: file_helper
INFO - 2020-01-27 06:49:22 --> Helper loaded: form_helper
INFO - 2020-01-27 06:49:22 --> Helper loaded: my_helper
INFO - 2020-01-27 06:49:22 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:49:22 --> Controller Class Initialized
DEBUG - 2020-01-27 06:49:22 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-01-27 06:49:22 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 06:49:22 --> Final output sent to browser
DEBUG - 2020-01-27 06:49:22 --> Total execution time: 0.4187
INFO - 2020-01-27 06:49:29 --> Config Class Initialized
INFO - 2020-01-27 06:49:29 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:49:29 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:49:29 --> Utf8 Class Initialized
INFO - 2020-01-27 06:49:29 --> URI Class Initialized
INFO - 2020-01-27 06:49:29 --> Router Class Initialized
INFO - 2020-01-27 06:49:29 --> Output Class Initialized
INFO - 2020-01-27 06:49:29 --> Security Class Initialized
DEBUG - 2020-01-27 06:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:49:29 --> Input Class Initialized
INFO - 2020-01-27 06:49:29 --> Language Class Initialized
INFO - 2020-01-27 06:49:29 --> Language Class Initialized
INFO - 2020-01-27 06:49:29 --> Config Class Initialized
INFO - 2020-01-27 06:49:29 --> Loader Class Initialized
INFO - 2020-01-27 06:49:29 --> Helper loaded: url_helper
INFO - 2020-01-27 06:49:29 --> Helper loaded: file_helper
INFO - 2020-01-27 06:49:29 --> Helper loaded: form_helper
INFO - 2020-01-27 06:49:29 --> Helper loaded: my_helper
INFO - 2020-01-27 06:49:29 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:49:29 --> Controller Class Initialized
DEBUG - 2020-01-27 06:49:29 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-01-27 06:49:30 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 06:49:30 --> Final output sent to browser
DEBUG - 2020-01-27 06:49:30 --> Total execution time: 0.4063
INFO - 2020-01-27 06:49:30 --> Config Class Initialized
INFO - 2020-01-27 06:49:30 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:49:30 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:49:30 --> Utf8 Class Initialized
INFO - 2020-01-27 06:49:30 --> URI Class Initialized
INFO - 2020-01-27 06:49:30 --> Router Class Initialized
INFO - 2020-01-27 06:49:30 --> Output Class Initialized
INFO - 2020-01-27 06:49:30 --> Security Class Initialized
DEBUG - 2020-01-27 06:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:49:30 --> Input Class Initialized
INFO - 2020-01-27 06:49:30 --> Language Class Initialized
INFO - 2020-01-27 06:49:30 --> Language Class Initialized
INFO - 2020-01-27 06:49:30 --> Config Class Initialized
INFO - 2020-01-27 06:49:30 --> Loader Class Initialized
INFO - 2020-01-27 06:49:30 --> Helper loaded: url_helper
INFO - 2020-01-27 06:49:30 --> Helper loaded: file_helper
INFO - 2020-01-27 06:49:30 --> Helper loaded: form_helper
INFO - 2020-01-27 06:49:30 --> Helper loaded: my_helper
INFO - 2020-01-27 06:49:30 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:49:30 --> Controller Class Initialized
INFO - 2020-01-27 06:49:34 --> Config Class Initialized
INFO - 2020-01-27 06:49:34 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:49:34 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:49:34 --> Utf8 Class Initialized
INFO - 2020-01-27 06:49:34 --> URI Class Initialized
INFO - 2020-01-27 06:49:34 --> Router Class Initialized
INFO - 2020-01-27 06:49:34 --> Output Class Initialized
INFO - 2020-01-27 06:49:34 --> Security Class Initialized
DEBUG - 2020-01-27 06:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:49:34 --> Input Class Initialized
INFO - 2020-01-27 06:49:34 --> Language Class Initialized
INFO - 2020-01-27 06:49:34 --> Language Class Initialized
INFO - 2020-01-27 06:49:34 --> Config Class Initialized
INFO - 2020-01-27 06:49:34 --> Loader Class Initialized
INFO - 2020-01-27 06:49:34 --> Helper loaded: url_helper
INFO - 2020-01-27 06:49:34 --> Helper loaded: file_helper
INFO - 2020-01-27 06:49:34 --> Helper loaded: form_helper
INFO - 2020-01-27 06:49:34 --> Helper loaded: my_helper
INFO - 2020-01-27 06:49:34 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:49:34 --> Controller Class Initialized
DEBUG - 2020-01-27 06:49:34 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/list.php
DEBUG - 2020-01-27 06:49:34 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 06:49:34 --> Final output sent to browser
DEBUG - 2020-01-27 06:49:34 --> Total execution time: 0.4405
INFO - 2020-01-27 06:49:37 --> Config Class Initialized
INFO - 2020-01-27 06:49:37 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:49:38 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:49:38 --> Utf8 Class Initialized
INFO - 2020-01-27 06:49:38 --> URI Class Initialized
INFO - 2020-01-27 06:49:38 --> Router Class Initialized
INFO - 2020-01-27 06:49:38 --> Output Class Initialized
INFO - 2020-01-27 06:49:38 --> Security Class Initialized
DEBUG - 2020-01-27 06:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:49:38 --> Input Class Initialized
INFO - 2020-01-27 06:49:38 --> Language Class Initialized
INFO - 2020-01-27 06:49:38 --> Language Class Initialized
INFO - 2020-01-27 06:49:38 --> Config Class Initialized
INFO - 2020-01-27 06:49:38 --> Loader Class Initialized
INFO - 2020-01-27 06:49:38 --> Helper loaded: url_helper
INFO - 2020-01-27 06:49:38 --> Helper loaded: file_helper
INFO - 2020-01-27 06:49:38 --> Helper loaded: form_helper
INFO - 2020-01-27 06:49:38 --> Helper loaded: my_helper
INFO - 2020-01-27 06:49:38 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:49:38 --> Controller Class Initialized
DEBUG - 2020-01-27 06:49:38 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-01-27 06:49:38 --> Final output sent to browser
DEBUG - 2020-01-27 06:49:38 --> Total execution time: 0.5364
INFO - 2020-01-27 06:52:50 --> Config Class Initialized
INFO - 2020-01-27 06:52:50 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:52:50 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:52:50 --> Utf8 Class Initialized
INFO - 2020-01-27 06:52:50 --> URI Class Initialized
INFO - 2020-01-27 06:52:50 --> Router Class Initialized
INFO - 2020-01-27 06:52:50 --> Output Class Initialized
INFO - 2020-01-27 06:52:50 --> Security Class Initialized
DEBUG - 2020-01-27 06:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:52:50 --> Input Class Initialized
INFO - 2020-01-27 06:52:50 --> Language Class Initialized
INFO - 2020-01-27 06:52:50 --> Language Class Initialized
INFO - 2020-01-27 06:52:50 --> Config Class Initialized
INFO - 2020-01-27 06:52:50 --> Loader Class Initialized
INFO - 2020-01-27 06:52:50 --> Helper loaded: url_helper
INFO - 2020-01-27 06:52:50 --> Helper loaded: file_helper
INFO - 2020-01-27 06:52:50 --> Helper loaded: form_helper
INFO - 2020-01-27 06:52:50 --> Helper loaded: my_helper
INFO - 2020-01-27 06:52:50 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:52:50 --> Controller Class Initialized
DEBUG - 2020-01-27 06:52:50 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_mapel/views/list.php
DEBUG - 2020-01-27 06:52:50 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 06:52:50 --> Final output sent to browser
DEBUG - 2020-01-27 06:52:50 --> Total execution time: 0.3769
INFO - 2020-01-27 06:52:51 --> Config Class Initialized
INFO - 2020-01-27 06:52:51 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:52:51 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:52:51 --> Utf8 Class Initialized
INFO - 2020-01-27 06:52:51 --> URI Class Initialized
INFO - 2020-01-27 06:52:51 --> Router Class Initialized
INFO - 2020-01-27 06:52:51 --> Output Class Initialized
INFO - 2020-01-27 06:52:51 --> Security Class Initialized
DEBUG - 2020-01-27 06:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:52:51 --> Input Class Initialized
INFO - 2020-01-27 06:52:51 --> Language Class Initialized
INFO - 2020-01-27 06:52:51 --> Language Class Initialized
INFO - 2020-01-27 06:52:51 --> Config Class Initialized
INFO - 2020-01-27 06:52:51 --> Loader Class Initialized
INFO - 2020-01-27 06:52:51 --> Helper loaded: url_helper
INFO - 2020-01-27 06:52:51 --> Helper loaded: file_helper
INFO - 2020-01-27 06:52:51 --> Helper loaded: form_helper
INFO - 2020-01-27 06:52:51 --> Helper loaded: my_helper
INFO - 2020-01-27 06:52:51 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:52:51 --> Controller Class Initialized
INFO - 2020-01-27 06:52:53 --> Config Class Initialized
INFO - 2020-01-27 06:52:53 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:52:54 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:52:54 --> Utf8 Class Initialized
INFO - 2020-01-27 06:52:54 --> URI Class Initialized
INFO - 2020-01-27 06:52:54 --> Router Class Initialized
INFO - 2020-01-27 06:52:54 --> Output Class Initialized
INFO - 2020-01-27 06:52:54 --> Security Class Initialized
DEBUG - 2020-01-27 06:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:52:54 --> Input Class Initialized
INFO - 2020-01-27 06:52:54 --> Language Class Initialized
INFO - 2020-01-27 06:52:54 --> Language Class Initialized
INFO - 2020-01-27 06:52:54 --> Config Class Initialized
INFO - 2020-01-27 06:52:54 --> Loader Class Initialized
INFO - 2020-01-27 06:52:54 --> Helper loaded: url_helper
INFO - 2020-01-27 06:52:54 --> Helper loaded: file_helper
INFO - 2020-01-27 06:52:54 --> Helper loaded: form_helper
INFO - 2020-01-27 06:52:54 --> Helper loaded: my_helper
INFO - 2020-01-27 06:52:54 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:52:54 --> Controller Class Initialized
INFO - 2020-01-27 06:52:54 --> Final output sent to browser
DEBUG - 2020-01-27 06:52:54 --> Total execution time: 0.3916
INFO - 2020-01-27 06:53:51 --> Config Class Initialized
INFO - 2020-01-27 06:53:51 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:53:51 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:53:51 --> Utf8 Class Initialized
INFO - 2020-01-27 06:53:51 --> URI Class Initialized
INFO - 2020-01-27 06:53:51 --> Router Class Initialized
INFO - 2020-01-27 06:53:51 --> Output Class Initialized
INFO - 2020-01-27 06:53:51 --> Security Class Initialized
DEBUG - 2020-01-27 06:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:53:51 --> Input Class Initialized
INFO - 2020-01-27 06:53:51 --> Language Class Initialized
INFO - 2020-01-27 06:53:51 --> Language Class Initialized
INFO - 2020-01-27 06:53:51 --> Config Class Initialized
INFO - 2020-01-27 06:53:51 --> Loader Class Initialized
INFO - 2020-01-27 06:53:51 --> Helper loaded: url_helper
INFO - 2020-01-27 06:53:51 --> Helper loaded: file_helper
INFO - 2020-01-27 06:53:51 --> Helper loaded: form_helper
INFO - 2020-01-27 06:53:52 --> Helper loaded: my_helper
INFO - 2020-01-27 06:53:52 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:53:52 --> Controller Class Initialized
DEBUG - 2020-01-27 06:53:52 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_mapel/views/list.php
DEBUG - 2020-01-27 06:53:52 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 06:53:52 --> Final output sent to browser
DEBUG - 2020-01-27 06:53:52 --> Total execution time: 0.3996
INFO - 2020-01-27 06:53:52 --> Config Class Initialized
INFO - 2020-01-27 06:53:52 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:53:52 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:53:52 --> Utf8 Class Initialized
INFO - 2020-01-27 06:53:52 --> URI Class Initialized
INFO - 2020-01-27 06:53:52 --> Router Class Initialized
INFO - 2020-01-27 06:53:52 --> Output Class Initialized
INFO - 2020-01-27 06:53:52 --> Security Class Initialized
DEBUG - 2020-01-27 06:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:53:52 --> Input Class Initialized
INFO - 2020-01-27 06:53:52 --> Language Class Initialized
INFO - 2020-01-27 06:53:52 --> Language Class Initialized
INFO - 2020-01-27 06:53:52 --> Config Class Initialized
INFO - 2020-01-27 06:53:52 --> Loader Class Initialized
INFO - 2020-01-27 06:53:52 --> Helper loaded: url_helper
INFO - 2020-01-27 06:53:52 --> Helper loaded: file_helper
INFO - 2020-01-27 06:53:52 --> Helper loaded: form_helper
INFO - 2020-01-27 06:53:52 --> Helper loaded: my_helper
INFO - 2020-01-27 06:53:52 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:53:52 --> Controller Class Initialized
INFO - 2020-01-27 06:54:17 --> Config Class Initialized
INFO - 2020-01-27 06:54:17 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:54:17 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:54:17 --> Utf8 Class Initialized
INFO - 2020-01-27 06:54:17 --> URI Class Initialized
INFO - 2020-01-27 06:54:17 --> Router Class Initialized
INFO - 2020-01-27 06:54:17 --> Output Class Initialized
INFO - 2020-01-27 06:54:17 --> Security Class Initialized
DEBUG - 2020-01-27 06:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:54:17 --> Input Class Initialized
INFO - 2020-01-27 06:54:17 --> Language Class Initialized
INFO - 2020-01-27 06:54:17 --> Language Class Initialized
INFO - 2020-01-27 06:54:17 --> Config Class Initialized
INFO - 2020-01-27 06:54:17 --> Loader Class Initialized
INFO - 2020-01-27 06:54:17 --> Helper loaded: url_helper
INFO - 2020-01-27 06:54:17 --> Helper loaded: file_helper
INFO - 2020-01-27 06:54:17 --> Helper loaded: form_helper
INFO - 2020-01-27 06:54:18 --> Helper loaded: my_helper
INFO - 2020-01-27 06:54:18 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:54:18 --> Controller Class Initialized
DEBUG - 2020-01-27 06:54:18 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_mapel/views/list.php
DEBUG - 2020-01-27 06:54:18 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 06:54:18 --> Final output sent to browser
DEBUG - 2020-01-27 06:54:18 --> Total execution time: 0.4386
INFO - 2020-01-27 06:54:18 --> Config Class Initialized
INFO - 2020-01-27 06:54:18 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:54:18 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:54:18 --> Utf8 Class Initialized
INFO - 2020-01-27 06:54:18 --> URI Class Initialized
INFO - 2020-01-27 06:54:18 --> Router Class Initialized
INFO - 2020-01-27 06:54:18 --> Output Class Initialized
INFO - 2020-01-27 06:54:18 --> Security Class Initialized
DEBUG - 2020-01-27 06:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:54:18 --> Input Class Initialized
INFO - 2020-01-27 06:54:18 --> Language Class Initialized
INFO - 2020-01-27 06:54:18 --> Language Class Initialized
INFO - 2020-01-27 06:54:18 --> Config Class Initialized
INFO - 2020-01-27 06:54:18 --> Loader Class Initialized
INFO - 2020-01-27 06:54:18 --> Helper loaded: url_helper
INFO - 2020-01-27 06:54:18 --> Helper loaded: file_helper
INFO - 2020-01-27 06:54:18 --> Helper loaded: form_helper
INFO - 2020-01-27 06:54:18 --> Helper loaded: my_helper
INFO - 2020-01-27 06:54:18 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:54:18 --> Controller Class Initialized
INFO - 2020-01-27 06:54:20 --> Config Class Initialized
INFO - 2020-01-27 06:54:20 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:54:20 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:54:20 --> Utf8 Class Initialized
INFO - 2020-01-27 06:54:20 --> URI Class Initialized
INFO - 2020-01-27 06:54:20 --> Router Class Initialized
INFO - 2020-01-27 06:54:20 --> Output Class Initialized
INFO - 2020-01-27 06:54:20 --> Security Class Initialized
DEBUG - 2020-01-27 06:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:54:20 --> Input Class Initialized
INFO - 2020-01-27 06:54:20 --> Language Class Initialized
INFO - 2020-01-27 06:54:20 --> Language Class Initialized
INFO - 2020-01-27 06:54:20 --> Config Class Initialized
INFO - 2020-01-27 06:54:21 --> Loader Class Initialized
INFO - 2020-01-27 06:54:21 --> Helper loaded: url_helper
INFO - 2020-01-27 06:54:21 --> Helper loaded: file_helper
INFO - 2020-01-27 06:54:21 --> Helper loaded: form_helper
INFO - 2020-01-27 06:54:21 --> Helper loaded: my_helper
INFO - 2020-01-27 06:54:21 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:54:21 --> Controller Class Initialized
INFO - 2020-01-27 06:54:21 --> Final output sent to browser
DEBUG - 2020-01-27 06:54:21 --> Total execution time: 0.3806
INFO - 2020-01-27 06:55:09 --> Config Class Initialized
INFO - 2020-01-27 06:55:09 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:55:09 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:55:09 --> Utf8 Class Initialized
INFO - 2020-01-27 06:55:09 --> URI Class Initialized
INFO - 2020-01-27 06:55:09 --> Router Class Initialized
INFO - 2020-01-27 06:55:09 --> Output Class Initialized
INFO - 2020-01-27 06:55:09 --> Security Class Initialized
DEBUG - 2020-01-27 06:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:55:09 --> Input Class Initialized
INFO - 2020-01-27 06:55:09 --> Language Class Initialized
INFO - 2020-01-27 06:55:09 --> Language Class Initialized
INFO - 2020-01-27 06:55:09 --> Config Class Initialized
INFO - 2020-01-27 06:55:09 --> Loader Class Initialized
INFO - 2020-01-27 06:55:09 --> Helper loaded: url_helper
INFO - 2020-01-27 06:55:09 --> Helper loaded: file_helper
INFO - 2020-01-27 06:55:09 --> Helper loaded: form_helper
INFO - 2020-01-27 06:55:09 --> Helper loaded: my_helper
INFO - 2020-01-27 06:55:09 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:55:09 --> Controller Class Initialized
DEBUG - 2020-01-27 06:55:09 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_mapel/views/list.php
DEBUG - 2020-01-27 06:55:09 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 06:55:09 --> Final output sent to browser
DEBUG - 2020-01-27 06:55:09 --> Total execution time: 0.3942
INFO - 2020-01-27 06:55:09 --> Config Class Initialized
INFO - 2020-01-27 06:55:09 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:55:09 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:55:09 --> Utf8 Class Initialized
INFO - 2020-01-27 06:55:09 --> URI Class Initialized
INFO - 2020-01-27 06:55:09 --> Router Class Initialized
INFO - 2020-01-27 06:55:09 --> Output Class Initialized
INFO - 2020-01-27 06:55:09 --> Security Class Initialized
DEBUG - 2020-01-27 06:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:55:10 --> Input Class Initialized
INFO - 2020-01-27 06:55:10 --> Language Class Initialized
INFO - 2020-01-27 06:55:10 --> Language Class Initialized
INFO - 2020-01-27 06:55:10 --> Config Class Initialized
INFO - 2020-01-27 06:55:10 --> Loader Class Initialized
INFO - 2020-01-27 06:55:10 --> Helper loaded: url_helper
INFO - 2020-01-27 06:55:10 --> Helper loaded: file_helper
INFO - 2020-01-27 06:55:10 --> Helper loaded: form_helper
INFO - 2020-01-27 06:55:10 --> Helper loaded: my_helper
INFO - 2020-01-27 06:55:10 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:55:10 --> Controller Class Initialized
INFO - 2020-01-27 06:55:29 --> Config Class Initialized
INFO - 2020-01-27 06:55:29 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:55:29 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:55:29 --> Utf8 Class Initialized
INFO - 2020-01-27 06:55:29 --> URI Class Initialized
INFO - 2020-01-27 06:55:29 --> Router Class Initialized
INFO - 2020-01-27 06:55:29 --> Output Class Initialized
INFO - 2020-01-27 06:55:29 --> Security Class Initialized
DEBUG - 2020-01-27 06:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:55:29 --> Input Class Initialized
INFO - 2020-01-27 06:55:29 --> Language Class Initialized
INFO - 2020-01-27 06:55:29 --> Language Class Initialized
INFO - 2020-01-27 06:55:29 --> Config Class Initialized
INFO - 2020-01-27 06:55:29 --> Loader Class Initialized
INFO - 2020-01-27 06:55:29 --> Helper loaded: url_helper
INFO - 2020-01-27 06:55:30 --> Helper loaded: file_helper
INFO - 2020-01-27 06:55:30 --> Helper loaded: form_helper
INFO - 2020-01-27 06:55:30 --> Helper loaded: my_helper
INFO - 2020-01-27 06:55:30 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:55:30 --> Controller Class Initialized
DEBUG - 2020-01-27 06:55:30 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_mapel/views/list.php
DEBUG - 2020-01-27 06:55:30 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 06:55:30 --> Final output sent to browser
DEBUG - 2020-01-27 06:55:30 --> Total execution time: 0.4137
INFO - 2020-01-27 06:55:30 --> Config Class Initialized
INFO - 2020-01-27 06:55:30 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:55:30 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:55:30 --> Utf8 Class Initialized
INFO - 2020-01-27 06:55:30 --> URI Class Initialized
INFO - 2020-01-27 06:55:30 --> Router Class Initialized
INFO - 2020-01-27 06:55:30 --> Output Class Initialized
INFO - 2020-01-27 06:55:30 --> Security Class Initialized
DEBUG - 2020-01-27 06:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:55:30 --> Input Class Initialized
INFO - 2020-01-27 06:55:30 --> Language Class Initialized
INFO - 2020-01-27 06:55:30 --> Language Class Initialized
INFO - 2020-01-27 06:55:30 --> Config Class Initialized
INFO - 2020-01-27 06:55:30 --> Loader Class Initialized
INFO - 2020-01-27 06:55:30 --> Helper loaded: url_helper
INFO - 2020-01-27 06:55:30 --> Helper loaded: file_helper
INFO - 2020-01-27 06:55:30 --> Helper loaded: form_helper
INFO - 2020-01-27 06:55:30 --> Helper loaded: my_helper
INFO - 2020-01-27 06:55:30 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:55:30 --> Controller Class Initialized
INFO - 2020-01-27 06:55:43 --> Config Class Initialized
INFO - 2020-01-27 06:55:43 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:55:43 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:55:43 --> Utf8 Class Initialized
INFO - 2020-01-27 06:55:43 --> URI Class Initialized
INFO - 2020-01-27 06:55:43 --> Router Class Initialized
INFO - 2020-01-27 06:55:43 --> Output Class Initialized
INFO - 2020-01-27 06:55:43 --> Security Class Initialized
DEBUG - 2020-01-27 06:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:55:43 --> Input Class Initialized
INFO - 2020-01-27 06:55:43 --> Language Class Initialized
INFO - 2020-01-27 06:55:43 --> Language Class Initialized
INFO - 2020-01-27 06:55:43 --> Config Class Initialized
INFO - 2020-01-27 06:55:43 --> Loader Class Initialized
INFO - 2020-01-27 06:55:43 --> Helper loaded: url_helper
INFO - 2020-01-27 06:55:43 --> Helper loaded: file_helper
INFO - 2020-01-27 06:55:43 --> Helper loaded: form_helper
INFO - 2020-01-27 06:55:43 --> Helper loaded: my_helper
INFO - 2020-01-27 06:55:43 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:55:43 --> Controller Class Initialized
DEBUG - 2020-01-27 06:55:43 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_mapel/views/list.php
DEBUG - 2020-01-27 06:55:43 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 06:55:43 --> Final output sent to browser
DEBUG - 2020-01-27 06:55:44 --> Total execution time: 0.3901
INFO - 2020-01-27 06:55:44 --> Config Class Initialized
INFO - 2020-01-27 06:55:44 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:55:44 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:55:44 --> Utf8 Class Initialized
INFO - 2020-01-27 06:55:44 --> URI Class Initialized
INFO - 2020-01-27 06:55:44 --> Router Class Initialized
INFO - 2020-01-27 06:55:44 --> Output Class Initialized
INFO - 2020-01-27 06:55:44 --> Security Class Initialized
DEBUG - 2020-01-27 06:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:55:44 --> Input Class Initialized
INFO - 2020-01-27 06:55:44 --> Language Class Initialized
INFO - 2020-01-27 06:55:44 --> Language Class Initialized
INFO - 2020-01-27 06:55:44 --> Config Class Initialized
INFO - 2020-01-27 06:55:44 --> Loader Class Initialized
INFO - 2020-01-27 06:55:44 --> Helper loaded: url_helper
INFO - 2020-01-27 06:55:44 --> Helper loaded: file_helper
INFO - 2020-01-27 06:55:44 --> Helper loaded: form_helper
INFO - 2020-01-27 06:55:44 --> Helper loaded: my_helper
INFO - 2020-01-27 06:55:44 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:55:44 --> Controller Class Initialized
INFO - 2020-01-27 06:55:51 --> Config Class Initialized
INFO - 2020-01-27 06:55:51 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:55:51 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:55:51 --> Utf8 Class Initialized
INFO - 2020-01-27 06:55:51 --> URI Class Initialized
INFO - 2020-01-27 06:55:51 --> Router Class Initialized
INFO - 2020-01-27 06:55:51 --> Output Class Initialized
INFO - 2020-01-27 06:55:52 --> Security Class Initialized
DEBUG - 2020-01-27 06:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:55:52 --> Input Class Initialized
INFO - 2020-01-27 06:55:52 --> Language Class Initialized
INFO - 2020-01-27 06:55:52 --> Language Class Initialized
INFO - 2020-01-27 06:55:52 --> Config Class Initialized
INFO - 2020-01-27 06:55:52 --> Loader Class Initialized
INFO - 2020-01-27 06:55:52 --> Helper loaded: url_helper
INFO - 2020-01-27 06:55:52 --> Helper loaded: file_helper
INFO - 2020-01-27 06:55:52 --> Helper loaded: form_helper
INFO - 2020-01-27 06:55:52 --> Helper loaded: my_helper
INFO - 2020-01-27 06:55:52 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:55:52 --> Controller Class Initialized
DEBUG - 2020-01-27 06:55:52 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_mapel/views/list.php
DEBUG - 2020-01-27 06:55:52 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 06:55:52 --> Final output sent to browser
DEBUG - 2020-01-27 06:55:52 --> Total execution time: 0.4137
INFO - 2020-01-27 06:55:52 --> Config Class Initialized
INFO - 2020-01-27 06:55:52 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:55:52 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:55:52 --> Utf8 Class Initialized
INFO - 2020-01-27 06:55:52 --> URI Class Initialized
INFO - 2020-01-27 06:55:52 --> Router Class Initialized
INFO - 2020-01-27 06:55:52 --> Output Class Initialized
INFO - 2020-01-27 06:55:52 --> Security Class Initialized
DEBUG - 2020-01-27 06:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:55:52 --> Input Class Initialized
INFO - 2020-01-27 06:55:52 --> Language Class Initialized
INFO - 2020-01-27 06:55:52 --> Language Class Initialized
INFO - 2020-01-27 06:55:52 --> Config Class Initialized
INFO - 2020-01-27 06:55:52 --> Loader Class Initialized
INFO - 2020-01-27 06:55:52 --> Helper loaded: url_helper
INFO - 2020-01-27 06:55:52 --> Helper loaded: file_helper
INFO - 2020-01-27 06:55:52 --> Helper loaded: form_helper
INFO - 2020-01-27 06:55:52 --> Helper loaded: my_helper
INFO - 2020-01-27 06:55:52 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:55:52 --> Controller Class Initialized
INFO - 2020-01-27 06:56:00 --> Config Class Initialized
INFO - 2020-01-27 06:56:00 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:56:00 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:56:00 --> Utf8 Class Initialized
INFO - 2020-01-27 06:56:00 --> URI Class Initialized
INFO - 2020-01-27 06:56:00 --> Router Class Initialized
INFO - 2020-01-27 06:56:00 --> Output Class Initialized
INFO - 2020-01-27 06:56:00 --> Security Class Initialized
DEBUG - 2020-01-27 06:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:56:00 --> Input Class Initialized
INFO - 2020-01-27 06:56:00 --> Language Class Initialized
INFO - 2020-01-27 06:56:00 --> Language Class Initialized
INFO - 2020-01-27 06:56:00 --> Config Class Initialized
INFO - 2020-01-27 06:56:00 --> Loader Class Initialized
INFO - 2020-01-27 06:56:00 --> Helper loaded: url_helper
INFO - 2020-01-27 06:56:00 --> Helper loaded: file_helper
INFO - 2020-01-27 06:56:00 --> Helper loaded: form_helper
INFO - 2020-01-27 06:56:00 --> Helper loaded: my_helper
INFO - 2020-01-27 06:56:00 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:56:01 --> Controller Class Initialized
DEBUG - 2020-01-27 06:56:01 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_mapel/views/list.php
DEBUG - 2020-01-27 06:56:01 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 06:56:01 --> Final output sent to browser
DEBUG - 2020-01-27 06:56:01 --> Total execution time: 0.4066
INFO - 2020-01-27 06:56:01 --> Config Class Initialized
INFO - 2020-01-27 06:56:01 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:56:01 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:56:01 --> Utf8 Class Initialized
INFO - 2020-01-27 06:56:01 --> URI Class Initialized
INFO - 2020-01-27 06:56:01 --> Router Class Initialized
INFO - 2020-01-27 06:56:01 --> Output Class Initialized
INFO - 2020-01-27 06:56:01 --> Security Class Initialized
DEBUG - 2020-01-27 06:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:56:01 --> Input Class Initialized
INFO - 2020-01-27 06:56:01 --> Language Class Initialized
INFO - 2020-01-27 06:56:01 --> Language Class Initialized
INFO - 2020-01-27 06:56:01 --> Config Class Initialized
INFO - 2020-01-27 06:56:01 --> Loader Class Initialized
INFO - 2020-01-27 06:56:01 --> Helper loaded: url_helper
INFO - 2020-01-27 06:56:01 --> Helper loaded: file_helper
INFO - 2020-01-27 06:56:01 --> Helper loaded: form_helper
INFO - 2020-01-27 06:56:01 --> Helper loaded: my_helper
INFO - 2020-01-27 06:56:01 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:56:01 --> Controller Class Initialized
INFO - 2020-01-27 06:57:19 --> Config Class Initialized
INFO - 2020-01-27 06:57:19 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:57:19 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:57:19 --> Utf8 Class Initialized
INFO - 2020-01-27 06:57:19 --> URI Class Initialized
INFO - 2020-01-27 06:57:19 --> Router Class Initialized
INFO - 2020-01-27 06:57:19 --> Output Class Initialized
INFO - 2020-01-27 06:57:19 --> Security Class Initialized
DEBUG - 2020-01-27 06:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:57:19 --> Input Class Initialized
INFO - 2020-01-27 06:57:19 --> Language Class Initialized
INFO - 2020-01-27 06:57:20 --> Language Class Initialized
INFO - 2020-01-27 06:57:20 --> Config Class Initialized
INFO - 2020-01-27 06:57:20 --> Loader Class Initialized
INFO - 2020-01-27 06:57:20 --> Helper loaded: url_helper
INFO - 2020-01-27 06:57:20 --> Helper loaded: file_helper
INFO - 2020-01-27 06:57:20 --> Helper loaded: form_helper
INFO - 2020-01-27 06:57:20 --> Helper loaded: my_helper
INFO - 2020-01-27 06:57:20 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:57:20 --> Controller Class Initialized
DEBUG - 2020-01-27 06:57:20 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_mapel/views/list.php
DEBUG - 2020-01-27 06:57:20 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 06:57:20 --> Final output sent to browser
DEBUG - 2020-01-27 06:57:20 --> Total execution time: 0.4127
INFO - 2020-01-27 06:57:20 --> Config Class Initialized
INFO - 2020-01-27 06:57:20 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:57:20 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:57:20 --> Utf8 Class Initialized
INFO - 2020-01-27 06:57:20 --> URI Class Initialized
INFO - 2020-01-27 06:57:20 --> Router Class Initialized
INFO - 2020-01-27 06:57:20 --> Output Class Initialized
INFO - 2020-01-27 06:57:20 --> Security Class Initialized
DEBUG - 2020-01-27 06:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:57:20 --> Input Class Initialized
INFO - 2020-01-27 06:57:20 --> Language Class Initialized
INFO - 2020-01-27 06:57:20 --> Language Class Initialized
INFO - 2020-01-27 06:57:20 --> Config Class Initialized
INFO - 2020-01-27 06:57:20 --> Loader Class Initialized
INFO - 2020-01-27 06:57:20 --> Helper loaded: url_helper
INFO - 2020-01-27 06:57:20 --> Helper loaded: file_helper
INFO - 2020-01-27 06:57:20 --> Helper loaded: form_helper
INFO - 2020-01-27 06:57:20 --> Helper loaded: my_helper
INFO - 2020-01-27 06:57:20 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:57:20 --> Controller Class Initialized
INFO - 2020-01-27 06:57:22 --> Config Class Initialized
INFO - 2020-01-27 06:57:22 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:57:22 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:57:22 --> Utf8 Class Initialized
INFO - 2020-01-27 06:57:22 --> URI Class Initialized
INFO - 2020-01-27 06:57:22 --> Router Class Initialized
INFO - 2020-01-27 06:57:22 --> Output Class Initialized
INFO - 2020-01-27 06:57:22 --> Security Class Initialized
DEBUG - 2020-01-27 06:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:57:22 --> Input Class Initialized
INFO - 2020-01-27 06:57:22 --> Language Class Initialized
INFO - 2020-01-27 06:57:22 --> Language Class Initialized
INFO - 2020-01-27 06:57:22 --> Config Class Initialized
INFO - 2020-01-27 06:57:22 --> Loader Class Initialized
INFO - 2020-01-27 06:57:22 --> Helper loaded: url_helper
INFO - 2020-01-27 06:57:22 --> Helper loaded: file_helper
INFO - 2020-01-27 06:57:22 --> Helper loaded: form_helper
INFO - 2020-01-27 06:57:22 --> Helper loaded: my_helper
INFO - 2020-01-27 06:57:22 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:57:22 --> Controller Class Initialized
INFO - 2020-01-27 06:57:22 --> Final output sent to browser
DEBUG - 2020-01-27 06:57:22 --> Total execution time: 0.4046
INFO - 2020-01-27 06:57:24 --> Config Class Initialized
INFO - 2020-01-27 06:57:24 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:57:24 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:57:24 --> Utf8 Class Initialized
INFO - 2020-01-27 06:57:24 --> URI Class Initialized
INFO - 2020-01-27 06:57:24 --> Router Class Initialized
INFO - 2020-01-27 06:57:24 --> Output Class Initialized
INFO - 2020-01-27 06:57:24 --> Security Class Initialized
DEBUG - 2020-01-27 06:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:57:24 --> Input Class Initialized
INFO - 2020-01-27 06:57:24 --> Language Class Initialized
INFO - 2020-01-27 06:57:24 --> Language Class Initialized
INFO - 2020-01-27 06:57:24 --> Config Class Initialized
INFO - 2020-01-27 06:57:24 --> Loader Class Initialized
INFO - 2020-01-27 06:57:24 --> Helper loaded: url_helper
INFO - 2020-01-27 06:57:24 --> Helper loaded: file_helper
INFO - 2020-01-27 06:57:24 --> Helper loaded: form_helper
INFO - 2020-01-27 06:57:24 --> Helper loaded: my_helper
INFO - 2020-01-27 06:57:24 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:57:24 --> Controller Class Initialized
INFO - 2020-01-27 06:57:24 --> Final output sent to browser
DEBUG - 2020-01-27 06:57:24 --> Total execution time: 0.5264
INFO - 2020-01-27 06:57:28 --> Config Class Initialized
INFO - 2020-01-27 06:57:28 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:57:28 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:57:28 --> Utf8 Class Initialized
INFO - 2020-01-27 06:57:28 --> URI Class Initialized
INFO - 2020-01-27 06:57:28 --> Router Class Initialized
INFO - 2020-01-27 06:57:29 --> Output Class Initialized
INFO - 2020-01-27 06:57:29 --> Security Class Initialized
DEBUG - 2020-01-27 06:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:57:29 --> Input Class Initialized
INFO - 2020-01-27 06:57:29 --> Language Class Initialized
INFO - 2020-01-27 06:57:29 --> Language Class Initialized
INFO - 2020-01-27 06:57:29 --> Config Class Initialized
INFO - 2020-01-27 06:57:29 --> Loader Class Initialized
INFO - 2020-01-27 06:57:29 --> Helper loaded: url_helper
INFO - 2020-01-27 06:57:29 --> Helper loaded: file_helper
INFO - 2020-01-27 06:57:29 --> Helper loaded: form_helper
INFO - 2020-01-27 06:57:29 --> Helper loaded: my_helper
INFO - 2020-01-27 06:57:29 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:57:29 --> Controller Class Initialized
INFO - 2020-01-27 06:57:29 --> Final output sent to browser
DEBUG - 2020-01-27 06:57:29 --> Total execution time: 0.3848
INFO - 2020-01-27 06:57:29 --> Config Class Initialized
INFO - 2020-01-27 06:57:29 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:57:29 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:57:29 --> Utf8 Class Initialized
INFO - 2020-01-27 06:57:29 --> URI Class Initialized
INFO - 2020-01-27 06:57:29 --> Router Class Initialized
INFO - 2020-01-27 06:57:29 --> Output Class Initialized
INFO - 2020-01-27 06:57:29 --> Security Class Initialized
DEBUG - 2020-01-27 06:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:57:29 --> Input Class Initialized
INFO - 2020-01-27 06:57:29 --> Language Class Initialized
INFO - 2020-01-27 06:57:29 --> Language Class Initialized
INFO - 2020-01-27 06:57:29 --> Config Class Initialized
INFO - 2020-01-27 06:57:29 --> Loader Class Initialized
INFO - 2020-01-27 06:57:29 --> Helper loaded: url_helper
INFO - 2020-01-27 06:57:29 --> Helper loaded: file_helper
INFO - 2020-01-27 06:57:29 --> Helper loaded: form_helper
INFO - 2020-01-27 06:57:29 --> Helper loaded: my_helper
INFO - 2020-01-27 06:57:29 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:57:29 --> Controller Class Initialized
INFO - 2020-01-27 06:57:31 --> Config Class Initialized
INFO - 2020-01-27 06:57:31 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:57:32 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:57:32 --> Utf8 Class Initialized
INFO - 2020-01-27 06:57:32 --> URI Class Initialized
INFO - 2020-01-27 06:57:32 --> Router Class Initialized
INFO - 2020-01-27 06:57:32 --> Output Class Initialized
INFO - 2020-01-27 06:57:32 --> Security Class Initialized
DEBUG - 2020-01-27 06:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:57:32 --> Input Class Initialized
INFO - 2020-01-27 06:57:32 --> Language Class Initialized
INFO - 2020-01-27 06:57:32 --> Language Class Initialized
INFO - 2020-01-27 06:57:32 --> Config Class Initialized
INFO - 2020-01-27 06:57:32 --> Loader Class Initialized
INFO - 2020-01-27 06:57:32 --> Helper loaded: url_helper
INFO - 2020-01-27 06:57:32 --> Helper loaded: file_helper
INFO - 2020-01-27 06:57:32 --> Helper loaded: form_helper
INFO - 2020-01-27 06:57:32 --> Helper loaded: my_helper
INFO - 2020-01-27 06:57:32 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:57:32 --> Controller Class Initialized
INFO - 2020-01-27 06:57:32 --> Final output sent to browser
DEBUG - 2020-01-27 06:57:32 --> Total execution time: 0.3943
INFO - 2020-01-27 06:58:02 --> Config Class Initialized
INFO - 2020-01-27 06:58:02 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:58:02 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:58:02 --> Utf8 Class Initialized
INFO - 2020-01-27 06:58:02 --> URI Class Initialized
INFO - 2020-01-27 06:58:02 --> Router Class Initialized
INFO - 2020-01-27 06:58:02 --> Output Class Initialized
INFO - 2020-01-27 06:58:02 --> Security Class Initialized
DEBUG - 2020-01-27 06:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:58:02 --> Input Class Initialized
INFO - 2020-01-27 06:58:02 --> Language Class Initialized
INFO - 2020-01-27 06:58:02 --> Language Class Initialized
INFO - 2020-01-27 06:58:02 --> Config Class Initialized
INFO - 2020-01-27 06:58:02 --> Loader Class Initialized
INFO - 2020-01-27 06:58:03 --> Helper loaded: url_helper
INFO - 2020-01-27 06:58:03 --> Helper loaded: file_helper
INFO - 2020-01-27 06:58:03 --> Helper loaded: form_helper
INFO - 2020-01-27 06:58:03 --> Helper loaded: my_helper
INFO - 2020-01-27 06:58:03 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:58:03 --> Controller Class Initialized
INFO - 2020-01-27 06:58:38 --> Config Class Initialized
INFO - 2020-01-27 06:58:38 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:58:38 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:58:38 --> Utf8 Class Initialized
INFO - 2020-01-27 06:58:38 --> URI Class Initialized
INFO - 2020-01-27 06:58:38 --> Router Class Initialized
INFO - 2020-01-27 06:58:38 --> Output Class Initialized
INFO - 2020-01-27 06:58:38 --> Security Class Initialized
DEBUG - 2020-01-27 06:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:58:38 --> Input Class Initialized
INFO - 2020-01-27 06:58:38 --> Language Class Initialized
INFO - 2020-01-27 06:58:38 --> Language Class Initialized
INFO - 2020-01-27 06:58:38 --> Config Class Initialized
INFO - 2020-01-27 06:58:38 --> Loader Class Initialized
INFO - 2020-01-27 06:58:38 --> Helper loaded: url_helper
INFO - 2020-01-27 06:58:38 --> Helper loaded: file_helper
INFO - 2020-01-27 06:58:38 --> Helper loaded: form_helper
INFO - 2020-01-27 06:58:38 --> Helper loaded: my_helper
INFO - 2020-01-27 06:58:38 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:58:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:58:38 --> Controller Class Initialized
INFO - 2020-01-27 06:58:38 --> Final output sent to browser
DEBUG - 2020-01-27 06:58:38 --> Total execution time: 0.3589
INFO - 2020-01-27 06:58:38 --> Config Class Initialized
INFO - 2020-01-27 06:58:38 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:58:38 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:58:38 --> Utf8 Class Initialized
INFO - 2020-01-27 06:58:38 --> URI Class Initialized
INFO - 2020-01-27 06:58:38 --> Router Class Initialized
INFO - 2020-01-27 06:58:38 --> Output Class Initialized
INFO - 2020-01-27 06:58:38 --> Security Class Initialized
DEBUG - 2020-01-27 06:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:58:38 --> Input Class Initialized
INFO - 2020-01-27 06:58:38 --> Language Class Initialized
INFO - 2020-01-27 06:58:38 --> Language Class Initialized
INFO - 2020-01-27 06:58:38 --> Config Class Initialized
INFO - 2020-01-27 06:58:38 --> Loader Class Initialized
INFO - 2020-01-27 06:58:38 --> Helper loaded: url_helper
INFO - 2020-01-27 06:58:38 --> Helper loaded: file_helper
INFO - 2020-01-27 06:58:39 --> Helper loaded: form_helper
INFO - 2020-01-27 06:58:39 --> Helper loaded: my_helper
INFO - 2020-01-27 06:58:39 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:58:39 --> Controller Class Initialized
INFO - 2020-01-27 06:58:41 --> Config Class Initialized
INFO - 2020-01-27 06:58:41 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:58:41 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:58:41 --> Utf8 Class Initialized
INFO - 2020-01-27 06:58:42 --> URI Class Initialized
INFO - 2020-01-27 06:58:42 --> Router Class Initialized
INFO - 2020-01-27 06:58:42 --> Output Class Initialized
INFO - 2020-01-27 06:58:42 --> Security Class Initialized
DEBUG - 2020-01-27 06:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:58:42 --> Input Class Initialized
INFO - 2020-01-27 06:58:42 --> Language Class Initialized
INFO - 2020-01-27 06:58:42 --> Language Class Initialized
INFO - 2020-01-27 06:58:42 --> Config Class Initialized
INFO - 2020-01-27 06:58:42 --> Loader Class Initialized
INFO - 2020-01-27 06:58:42 --> Helper loaded: url_helper
INFO - 2020-01-27 06:58:42 --> Helper loaded: file_helper
INFO - 2020-01-27 06:58:42 --> Helper loaded: form_helper
INFO - 2020-01-27 06:58:42 --> Helper loaded: my_helper
INFO - 2020-01-27 06:58:42 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:58:42 --> Controller Class Initialized
INFO - 2020-01-27 06:58:45 --> Config Class Initialized
INFO - 2020-01-27 06:58:45 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:58:45 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:58:45 --> Utf8 Class Initialized
INFO - 2020-01-27 06:58:45 --> URI Class Initialized
INFO - 2020-01-27 06:58:45 --> Router Class Initialized
INFO - 2020-01-27 06:58:45 --> Output Class Initialized
INFO - 2020-01-27 06:58:45 --> Security Class Initialized
DEBUG - 2020-01-27 06:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:58:45 --> Input Class Initialized
INFO - 2020-01-27 06:58:45 --> Language Class Initialized
INFO - 2020-01-27 06:58:45 --> Language Class Initialized
INFO - 2020-01-27 06:58:45 --> Config Class Initialized
INFO - 2020-01-27 06:58:45 --> Loader Class Initialized
INFO - 2020-01-27 06:58:45 --> Helper loaded: url_helper
INFO - 2020-01-27 06:58:45 --> Helper loaded: file_helper
INFO - 2020-01-27 06:58:45 --> Helper loaded: form_helper
INFO - 2020-01-27 06:58:45 --> Helper loaded: my_helper
INFO - 2020-01-27 06:58:45 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:58:45 --> Controller Class Initialized
DEBUG - 2020-01-27 06:58:45 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-01-27 06:58:45 --> Final output sent to browser
DEBUG - 2020-01-27 06:58:45 --> Total execution time: 0.4342
INFO - 2020-01-27 06:59:29 --> Config Class Initialized
INFO - 2020-01-27 06:59:29 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:59:29 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:59:29 --> Utf8 Class Initialized
INFO - 2020-01-27 06:59:29 --> URI Class Initialized
INFO - 2020-01-27 06:59:29 --> Router Class Initialized
INFO - 2020-01-27 06:59:29 --> Output Class Initialized
INFO - 2020-01-27 06:59:29 --> Security Class Initialized
DEBUG - 2020-01-27 06:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:59:29 --> Input Class Initialized
INFO - 2020-01-27 06:59:30 --> Language Class Initialized
INFO - 2020-01-27 06:59:30 --> Language Class Initialized
INFO - 2020-01-27 06:59:30 --> Config Class Initialized
INFO - 2020-01-27 06:59:30 --> Loader Class Initialized
INFO - 2020-01-27 06:59:30 --> Helper loaded: url_helper
INFO - 2020-01-27 06:59:30 --> Helper loaded: file_helper
INFO - 2020-01-27 06:59:30 --> Helper loaded: form_helper
INFO - 2020-01-27 06:59:30 --> Helper loaded: my_helper
INFO - 2020-01-27 06:59:30 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:59:30 --> Controller Class Initialized
INFO - 2020-01-27 06:59:34 --> Config Class Initialized
INFO - 2020-01-27 06:59:34 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:59:34 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:59:34 --> Utf8 Class Initialized
INFO - 2020-01-27 06:59:34 --> URI Class Initialized
INFO - 2020-01-27 06:59:34 --> Router Class Initialized
INFO - 2020-01-27 06:59:34 --> Output Class Initialized
INFO - 2020-01-27 06:59:34 --> Security Class Initialized
DEBUG - 2020-01-27 06:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:59:34 --> Input Class Initialized
INFO - 2020-01-27 06:59:34 --> Language Class Initialized
INFO - 2020-01-27 06:59:34 --> Language Class Initialized
INFO - 2020-01-27 06:59:34 --> Config Class Initialized
INFO - 2020-01-27 06:59:34 --> Loader Class Initialized
INFO - 2020-01-27 06:59:34 --> Helper loaded: url_helper
INFO - 2020-01-27 06:59:34 --> Helper loaded: file_helper
INFO - 2020-01-27 06:59:34 --> Helper loaded: form_helper
INFO - 2020-01-27 06:59:34 --> Helper loaded: my_helper
INFO - 2020-01-27 06:59:34 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:59:34 --> Controller Class Initialized
INFO - 2020-01-27 06:59:34 --> Final output sent to browser
DEBUG - 2020-01-27 06:59:34 --> Total execution time: 0.3739
INFO - 2020-01-27 06:59:34 --> Config Class Initialized
INFO - 2020-01-27 06:59:34 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:59:34 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:59:34 --> Utf8 Class Initialized
INFO - 2020-01-27 06:59:34 --> URI Class Initialized
INFO - 2020-01-27 06:59:34 --> Router Class Initialized
INFO - 2020-01-27 06:59:34 --> Output Class Initialized
INFO - 2020-01-27 06:59:34 --> Security Class Initialized
DEBUG - 2020-01-27 06:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:59:34 --> Input Class Initialized
INFO - 2020-01-27 06:59:34 --> Language Class Initialized
INFO - 2020-01-27 06:59:34 --> Language Class Initialized
INFO - 2020-01-27 06:59:34 --> Config Class Initialized
INFO - 2020-01-27 06:59:34 --> Loader Class Initialized
INFO - 2020-01-27 06:59:34 --> Helper loaded: url_helper
INFO - 2020-01-27 06:59:34 --> Helper loaded: file_helper
INFO - 2020-01-27 06:59:34 --> Helper loaded: form_helper
INFO - 2020-01-27 06:59:34 --> Helper loaded: my_helper
INFO - 2020-01-27 06:59:34 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:59:35 --> Controller Class Initialized
INFO - 2020-01-27 06:59:38 --> Config Class Initialized
INFO - 2020-01-27 06:59:38 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:59:38 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:59:38 --> Utf8 Class Initialized
INFO - 2020-01-27 06:59:38 --> URI Class Initialized
INFO - 2020-01-27 06:59:38 --> Router Class Initialized
INFO - 2020-01-27 06:59:38 --> Output Class Initialized
INFO - 2020-01-27 06:59:38 --> Security Class Initialized
DEBUG - 2020-01-27 06:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:59:38 --> Input Class Initialized
INFO - 2020-01-27 06:59:38 --> Language Class Initialized
INFO - 2020-01-27 06:59:38 --> Language Class Initialized
INFO - 2020-01-27 06:59:38 --> Config Class Initialized
INFO - 2020-01-27 06:59:38 --> Loader Class Initialized
INFO - 2020-01-27 06:59:38 --> Helper loaded: url_helper
INFO - 2020-01-27 06:59:38 --> Helper loaded: file_helper
INFO - 2020-01-27 06:59:38 --> Helper loaded: form_helper
INFO - 2020-01-27 06:59:38 --> Helper loaded: my_helper
INFO - 2020-01-27 06:59:38 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:59:38 --> Controller Class Initialized
INFO - 2020-01-27 06:59:38 --> Final output sent to browser
DEBUG - 2020-01-27 06:59:38 --> Total execution time: 0.3886
INFO - 2020-01-27 06:59:38 --> Config Class Initialized
INFO - 2020-01-27 06:59:39 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:59:39 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:59:39 --> Utf8 Class Initialized
INFO - 2020-01-27 06:59:39 --> URI Class Initialized
INFO - 2020-01-27 06:59:39 --> Router Class Initialized
INFO - 2020-01-27 06:59:39 --> Output Class Initialized
INFO - 2020-01-27 06:59:39 --> Security Class Initialized
DEBUG - 2020-01-27 06:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:59:39 --> Input Class Initialized
INFO - 2020-01-27 06:59:39 --> Language Class Initialized
INFO - 2020-01-27 06:59:39 --> Language Class Initialized
INFO - 2020-01-27 06:59:39 --> Config Class Initialized
INFO - 2020-01-27 06:59:39 --> Loader Class Initialized
INFO - 2020-01-27 06:59:39 --> Helper loaded: url_helper
INFO - 2020-01-27 06:59:39 --> Helper loaded: file_helper
INFO - 2020-01-27 06:59:39 --> Helper loaded: form_helper
INFO - 2020-01-27 06:59:39 --> Helper loaded: my_helper
INFO - 2020-01-27 06:59:39 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:59:39 --> Controller Class Initialized
INFO - 2020-01-27 06:59:49 --> Config Class Initialized
INFO - 2020-01-27 06:59:49 --> Hooks Class Initialized
DEBUG - 2020-01-27 06:59:49 --> UTF-8 Support Enabled
INFO - 2020-01-27 06:59:49 --> Utf8 Class Initialized
INFO - 2020-01-27 06:59:49 --> URI Class Initialized
INFO - 2020-01-27 06:59:49 --> Router Class Initialized
INFO - 2020-01-27 06:59:49 --> Output Class Initialized
INFO - 2020-01-27 06:59:49 --> Security Class Initialized
DEBUG - 2020-01-27 06:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 06:59:49 --> Input Class Initialized
INFO - 2020-01-27 06:59:49 --> Language Class Initialized
INFO - 2020-01-27 06:59:49 --> Language Class Initialized
INFO - 2020-01-27 06:59:49 --> Config Class Initialized
INFO - 2020-01-27 06:59:49 --> Loader Class Initialized
INFO - 2020-01-27 06:59:49 --> Helper loaded: url_helper
INFO - 2020-01-27 06:59:49 --> Helper loaded: file_helper
INFO - 2020-01-27 06:59:49 --> Helper loaded: form_helper
INFO - 2020-01-27 06:59:49 --> Helper loaded: my_helper
INFO - 2020-01-27 06:59:49 --> Database Driver Class Initialized
DEBUG - 2020-01-27 06:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 06:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 06:59:49 --> Controller Class Initialized
DEBUG - 2020-01-27 06:59:49 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-01-27 06:59:49 --> Final output sent to browser
DEBUG - 2020-01-27 06:59:49 --> Total execution time: 0.4233
INFO - 2020-01-27 07:00:47 --> Config Class Initialized
INFO - 2020-01-27 07:00:47 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:00:47 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:00:47 --> Utf8 Class Initialized
INFO - 2020-01-27 07:00:47 --> URI Class Initialized
INFO - 2020-01-27 07:00:47 --> Router Class Initialized
INFO - 2020-01-27 07:00:47 --> Output Class Initialized
INFO - 2020-01-27 07:00:47 --> Security Class Initialized
DEBUG - 2020-01-27 07:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:00:47 --> Input Class Initialized
INFO - 2020-01-27 07:00:47 --> Language Class Initialized
INFO - 2020-01-27 07:00:47 --> Language Class Initialized
INFO - 2020-01-27 07:00:47 --> Config Class Initialized
INFO - 2020-01-27 07:00:47 --> Loader Class Initialized
INFO - 2020-01-27 07:00:47 --> Helper loaded: url_helper
INFO - 2020-01-27 07:00:48 --> Helper loaded: file_helper
INFO - 2020-01-27 07:00:48 --> Helper loaded: form_helper
INFO - 2020-01-27 07:00:48 --> Helper loaded: my_helper
INFO - 2020-01-27 07:00:48 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:00:48 --> Controller Class Initialized
INFO - 2020-01-27 07:00:48 --> Final output sent to browser
DEBUG - 2020-01-27 07:00:48 --> Total execution time: 0.3762
INFO - 2020-01-27 07:00:48 --> Config Class Initialized
INFO - 2020-01-27 07:00:48 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:00:48 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:00:48 --> Utf8 Class Initialized
INFO - 2020-01-27 07:00:48 --> URI Class Initialized
INFO - 2020-01-27 07:00:48 --> Router Class Initialized
INFO - 2020-01-27 07:00:48 --> Output Class Initialized
INFO - 2020-01-27 07:00:48 --> Security Class Initialized
DEBUG - 2020-01-27 07:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:00:48 --> Input Class Initialized
INFO - 2020-01-27 07:00:48 --> Language Class Initialized
INFO - 2020-01-27 07:00:48 --> Language Class Initialized
INFO - 2020-01-27 07:00:48 --> Config Class Initialized
INFO - 2020-01-27 07:00:48 --> Loader Class Initialized
INFO - 2020-01-27 07:00:48 --> Helper loaded: url_helper
INFO - 2020-01-27 07:00:48 --> Helper loaded: file_helper
INFO - 2020-01-27 07:00:48 --> Helper loaded: form_helper
INFO - 2020-01-27 07:00:48 --> Helper loaded: my_helper
INFO - 2020-01-27 07:00:48 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:00:48 --> Controller Class Initialized
INFO - 2020-01-27 07:00:50 --> Config Class Initialized
INFO - 2020-01-27 07:00:50 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:00:50 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:00:50 --> Utf8 Class Initialized
INFO - 2020-01-27 07:00:50 --> URI Class Initialized
INFO - 2020-01-27 07:00:50 --> Router Class Initialized
INFO - 2020-01-27 07:00:50 --> Output Class Initialized
INFO - 2020-01-27 07:00:50 --> Security Class Initialized
DEBUG - 2020-01-27 07:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:00:50 --> Input Class Initialized
INFO - 2020-01-27 07:00:50 --> Language Class Initialized
INFO - 2020-01-27 07:00:50 --> Language Class Initialized
INFO - 2020-01-27 07:00:50 --> Config Class Initialized
INFO - 2020-01-27 07:00:50 --> Loader Class Initialized
INFO - 2020-01-27 07:00:50 --> Helper loaded: url_helper
INFO - 2020-01-27 07:00:50 --> Helper loaded: file_helper
INFO - 2020-01-27 07:00:50 --> Helper loaded: form_helper
INFO - 2020-01-27 07:00:50 --> Helper loaded: my_helper
INFO - 2020-01-27 07:00:50 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:00:51 --> Controller Class Initialized
DEBUG - 2020-01-27 07:00:51 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-01-27 07:00:51 --> Final output sent to browser
DEBUG - 2020-01-27 07:00:51 --> Total execution time: 0.4465
INFO - 2020-01-27 07:01:13 --> Config Class Initialized
INFO - 2020-01-27 07:01:13 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:01:13 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:01:13 --> Utf8 Class Initialized
INFO - 2020-01-27 07:01:13 --> URI Class Initialized
INFO - 2020-01-27 07:01:13 --> Router Class Initialized
INFO - 2020-01-27 07:01:13 --> Output Class Initialized
INFO - 2020-01-27 07:01:13 --> Security Class Initialized
DEBUG - 2020-01-27 07:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:01:13 --> Input Class Initialized
INFO - 2020-01-27 07:01:13 --> Language Class Initialized
INFO - 2020-01-27 07:01:13 --> Language Class Initialized
INFO - 2020-01-27 07:01:13 --> Config Class Initialized
INFO - 2020-01-27 07:01:13 --> Loader Class Initialized
INFO - 2020-01-27 07:01:13 --> Helper loaded: url_helper
INFO - 2020-01-27 07:01:13 --> Helper loaded: file_helper
INFO - 2020-01-27 07:01:13 --> Helper loaded: form_helper
INFO - 2020-01-27 07:01:13 --> Helper loaded: my_helper
INFO - 2020-01-27 07:01:13 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:01:13 --> Controller Class Initialized
INFO - 2020-01-27 07:01:13 --> Final output sent to browser
DEBUG - 2020-01-27 07:01:13 --> Total execution time: 0.3747
INFO - 2020-01-27 07:01:18 --> Config Class Initialized
INFO - 2020-01-27 07:01:18 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:01:18 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:01:18 --> Utf8 Class Initialized
INFO - 2020-01-27 07:01:18 --> URI Class Initialized
INFO - 2020-01-27 07:01:18 --> Router Class Initialized
INFO - 2020-01-27 07:01:18 --> Output Class Initialized
INFO - 2020-01-27 07:01:18 --> Security Class Initialized
DEBUG - 2020-01-27 07:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:01:18 --> Input Class Initialized
INFO - 2020-01-27 07:01:18 --> Language Class Initialized
INFO - 2020-01-27 07:01:18 --> Language Class Initialized
INFO - 2020-01-27 07:01:18 --> Config Class Initialized
INFO - 2020-01-27 07:01:18 --> Loader Class Initialized
INFO - 2020-01-27 07:01:18 --> Helper loaded: url_helper
INFO - 2020-01-27 07:01:18 --> Helper loaded: file_helper
INFO - 2020-01-27 07:01:19 --> Helper loaded: form_helper
INFO - 2020-01-27 07:01:19 --> Helper loaded: my_helper
INFO - 2020-01-27 07:01:19 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:01:19 --> Controller Class Initialized
INFO - 2020-01-27 07:01:19 --> Final output sent to browser
DEBUG - 2020-01-27 07:01:19 --> Total execution time: 0.3543
INFO - 2020-01-27 07:01:19 --> Config Class Initialized
INFO - 2020-01-27 07:01:19 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:01:19 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:01:19 --> Utf8 Class Initialized
INFO - 2020-01-27 07:01:19 --> URI Class Initialized
INFO - 2020-01-27 07:01:19 --> Router Class Initialized
INFO - 2020-01-27 07:01:19 --> Output Class Initialized
INFO - 2020-01-27 07:01:19 --> Security Class Initialized
DEBUG - 2020-01-27 07:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:01:19 --> Input Class Initialized
INFO - 2020-01-27 07:01:19 --> Language Class Initialized
INFO - 2020-01-27 07:01:19 --> Language Class Initialized
INFO - 2020-01-27 07:01:19 --> Config Class Initialized
INFO - 2020-01-27 07:01:19 --> Loader Class Initialized
INFO - 2020-01-27 07:01:19 --> Helper loaded: url_helper
INFO - 2020-01-27 07:01:19 --> Helper loaded: file_helper
INFO - 2020-01-27 07:01:19 --> Helper loaded: form_helper
INFO - 2020-01-27 07:01:19 --> Helper loaded: my_helper
INFO - 2020-01-27 07:01:19 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:01:19 --> Controller Class Initialized
INFO - 2020-01-27 07:01:24 --> Config Class Initialized
INFO - 2020-01-27 07:01:24 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:01:24 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:01:24 --> Utf8 Class Initialized
INFO - 2020-01-27 07:01:24 --> URI Class Initialized
INFO - 2020-01-27 07:01:24 --> Router Class Initialized
INFO - 2020-01-27 07:01:24 --> Output Class Initialized
INFO - 2020-01-27 07:01:24 --> Security Class Initialized
DEBUG - 2020-01-27 07:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:01:24 --> Input Class Initialized
INFO - 2020-01-27 07:01:24 --> Language Class Initialized
INFO - 2020-01-27 07:01:24 --> Language Class Initialized
INFO - 2020-01-27 07:01:24 --> Config Class Initialized
INFO - 2020-01-27 07:01:24 --> Loader Class Initialized
INFO - 2020-01-27 07:01:24 --> Helper loaded: url_helper
INFO - 2020-01-27 07:01:24 --> Helper loaded: file_helper
INFO - 2020-01-27 07:01:24 --> Helper loaded: form_helper
INFO - 2020-01-27 07:01:24 --> Helper loaded: my_helper
INFO - 2020-01-27 07:01:24 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:01:25 --> Controller Class Initialized
DEBUG - 2020-01-27 07:01:25 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-01-27 07:01:25 --> Final output sent to browser
DEBUG - 2020-01-27 07:01:25 --> Total execution time: 0.4200
INFO - 2020-01-27 07:01:47 --> Config Class Initialized
INFO - 2020-01-27 07:01:47 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:01:47 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:01:47 --> Utf8 Class Initialized
INFO - 2020-01-27 07:01:47 --> URI Class Initialized
INFO - 2020-01-27 07:01:47 --> Router Class Initialized
INFO - 2020-01-27 07:01:47 --> Output Class Initialized
INFO - 2020-01-27 07:01:47 --> Security Class Initialized
DEBUG - 2020-01-27 07:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:01:47 --> Input Class Initialized
INFO - 2020-01-27 07:01:47 --> Language Class Initialized
INFO - 2020-01-27 07:01:47 --> Language Class Initialized
INFO - 2020-01-27 07:01:47 --> Config Class Initialized
INFO - 2020-01-27 07:01:47 --> Loader Class Initialized
INFO - 2020-01-27 07:01:47 --> Helper loaded: url_helper
INFO - 2020-01-27 07:01:47 --> Helper loaded: file_helper
INFO - 2020-01-27 07:01:47 --> Helper loaded: form_helper
INFO - 2020-01-27 07:01:47 --> Helper loaded: my_helper
INFO - 2020-01-27 07:01:47 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:01:47 --> Controller Class Initialized
INFO - 2020-01-27 07:01:47 --> Final output sent to browser
DEBUG - 2020-01-27 07:01:47 --> Total execution time: 0.3820
INFO - 2020-01-27 07:01:47 --> Config Class Initialized
INFO - 2020-01-27 07:01:47 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:01:47 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:01:47 --> Utf8 Class Initialized
INFO - 2020-01-27 07:01:47 --> URI Class Initialized
INFO - 2020-01-27 07:01:47 --> Router Class Initialized
INFO - 2020-01-27 07:01:47 --> Output Class Initialized
INFO - 2020-01-27 07:01:47 --> Security Class Initialized
DEBUG - 2020-01-27 07:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:01:47 --> Input Class Initialized
INFO - 2020-01-27 07:01:47 --> Language Class Initialized
INFO - 2020-01-27 07:01:47 --> Language Class Initialized
INFO - 2020-01-27 07:01:47 --> Config Class Initialized
INFO - 2020-01-27 07:01:47 --> Loader Class Initialized
INFO - 2020-01-27 07:01:47 --> Helper loaded: url_helper
INFO - 2020-01-27 07:01:47 --> Helper loaded: file_helper
INFO - 2020-01-27 07:01:48 --> Helper loaded: form_helper
INFO - 2020-01-27 07:01:48 --> Helper loaded: my_helper
INFO - 2020-01-27 07:01:48 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:01:48 --> Controller Class Initialized
INFO - 2020-01-27 07:01:51 --> Config Class Initialized
INFO - 2020-01-27 07:01:51 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:01:51 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:01:51 --> Utf8 Class Initialized
INFO - 2020-01-27 07:01:51 --> URI Class Initialized
INFO - 2020-01-27 07:01:51 --> Router Class Initialized
INFO - 2020-01-27 07:01:51 --> Output Class Initialized
INFO - 2020-01-27 07:01:51 --> Security Class Initialized
DEBUG - 2020-01-27 07:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:01:51 --> Input Class Initialized
INFO - 2020-01-27 07:01:51 --> Language Class Initialized
INFO - 2020-01-27 07:01:51 --> Language Class Initialized
INFO - 2020-01-27 07:01:51 --> Config Class Initialized
INFO - 2020-01-27 07:01:51 --> Loader Class Initialized
INFO - 2020-01-27 07:01:51 --> Helper loaded: url_helper
INFO - 2020-01-27 07:01:51 --> Helper loaded: file_helper
INFO - 2020-01-27 07:01:51 --> Helper loaded: form_helper
INFO - 2020-01-27 07:01:51 --> Helper loaded: my_helper
INFO - 2020-01-27 07:01:51 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:01:51 --> Controller Class Initialized
DEBUG - 2020-01-27 07:01:51 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-01-27 07:01:51 --> Final output sent to browser
DEBUG - 2020-01-27 07:01:51 --> Total execution time: 0.4419
INFO - 2020-01-27 07:02:15 --> Config Class Initialized
INFO - 2020-01-27 07:02:15 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:02:15 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:02:15 --> Utf8 Class Initialized
INFO - 2020-01-27 07:02:15 --> URI Class Initialized
INFO - 2020-01-27 07:02:15 --> Router Class Initialized
INFO - 2020-01-27 07:02:15 --> Output Class Initialized
INFO - 2020-01-27 07:02:15 --> Security Class Initialized
DEBUG - 2020-01-27 07:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:02:15 --> Input Class Initialized
INFO - 2020-01-27 07:02:15 --> Language Class Initialized
INFO - 2020-01-27 07:02:15 --> Language Class Initialized
INFO - 2020-01-27 07:02:15 --> Config Class Initialized
INFO - 2020-01-27 07:02:15 --> Loader Class Initialized
INFO - 2020-01-27 07:02:15 --> Helper loaded: url_helper
INFO - 2020-01-27 07:02:15 --> Helper loaded: file_helper
INFO - 2020-01-27 07:02:15 --> Helper loaded: form_helper
INFO - 2020-01-27 07:02:15 --> Helper loaded: my_helper
INFO - 2020-01-27 07:02:15 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:02:15 --> Controller Class Initialized
INFO - 2020-01-27 07:02:15 --> Final output sent to browser
DEBUG - 2020-01-27 07:02:15 --> Total execution time: 0.4042
INFO - 2020-01-27 07:02:43 --> Config Class Initialized
INFO - 2020-01-27 07:02:43 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:02:43 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:02:43 --> Utf8 Class Initialized
INFO - 2020-01-27 07:02:43 --> URI Class Initialized
INFO - 2020-01-27 07:02:43 --> Router Class Initialized
INFO - 2020-01-27 07:02:43 --> Output Class Initialized
INFO - 2020-01-27 07:02:43 --> Security Class Initialized
DEBUG - 2020-01-27 07:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:02:43 --> Input Class Initialized
INFO - 2020-01-27 07:02:43 --> Language Class Initialized
INFO - 2020-01-27 07:02:43 --> Language Class Initialized
INFO - 2020-01-27 07:02:43 --> Config Class Initialized
INFO - 2020-01-27 07:02:43 --> Loader Class Initialized
INFO - 2020-01-27 07:02:43 --> Helper loaded: url_helper
INFO - 2020-01-27 07:02:43 --> Helper loaded: file_helper
INFO - 2020-01-27 07:02:43 --> Helper loaded: form_helper
INFO - 2020-01-27 07:02:43 --> Helper loaded: my_helper
INFO - 2020-01-27 07:02:44 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:02:44 --> Controller Class Initialized
INFO - 2020-01-27 07:02:44 --> Final output sent to browser
DEBUG - 2020-01-27 07:02:44 --> Total execution time: 0.3535
INFO - 2020-01-27 07:02:44 --> Config Class Initialized
INFO - 2020-01-27 07:02:44 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:02:44 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:02:44 --> Utf8 Class Initialized
INFO - 2020-01-27 07:02:44 --> URI Class Initialized
INFO - 2020-01-27 07:02:44 --> Router Class Initialized
INFO - 2020-01-27 07:02:44 --> Output Class Initialized
INFO - 2020-01-27 07:02:44 --> Security Class Initialized
DEBUG - 2020-01-27 07:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:02:44 --> Input Class Initialized
INFO - 2020-01-27 07:02:44 --> Language Class Initialized
INFO - 2020-01-27 07:02:44 --> Language Class Initialized
INFO - 2020-01-27 07:02:44 --> Config Class Initialized
INFO - 2020-01-27 07:02:44 --> Loader Class Initialized
INFO - 2020-01-27 07:02:44 --> Helper loaded: url_helper
INFO - 2020-01-27 07:02:44 --> Helper loaded: file_helper
INFO - 2020-01-27 07:02:44 --> Helper loaded: form_helper
INFO - 2020-01-27 07:02:44 --> Helper loaded: my_helper
INFO - 2020-01-27 07:02:44 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:02:44 --> Controller Class Initialized
INFO - 2020-01-27 07:02:49 --> Config Class Initialized
INFO - 2020-01-27 07:02:49 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:02:49 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:02:49 --> Utf8 Class Initialized
INFO - 2020-01-27 07:02:49 --> URI Class Initialized
INFO - 2020-01-27 07:02:49 --> Router Class Initialized
INFO - 2020-01-27 07:02:49 --> Output Class Initialized
INFO - 2020-01-27 07:02:49 --> Security Class Initialized
DEBUG - 2020-01-27 07:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:02:49 --> Input Class Initialized
INFO - 2020-01-27 07:02:49 --> Language Class Initialized
INFO - 2020-01-27 07:02:49 --> Language Class Initialized
INFO - 2020-01-27 07:02:49 --> Config Class Initialized
INFO - 2020-01-27 07:02:49 --> Loader Class Initialized
INFO - 2020-01-27 07:02:49 --> Helper loaded: url_helper
INFO - 2020-01-27 07:02:49 --> Helper loaded: file_helper
INFO - 2020-01-27 07:02:49 --> Helper loaded: form_helper
INFO - 2020-01-27 07:02:49 --> Helper loaded: my_helper
INFO - 2020-01-27 07:02:49 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:02:49 --> Controller Class Initialized
INFO - 2020-01-27 07:02:49 --> Final output sent to browser
DEBUG - 2020-01-27 07:02:49 --> Total execution time: 0.3743
INFO - 2020-01-27 07:03:13 --> Config Class Initialized
INFO - 2020-01-27 07:03:13 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:03:13 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:03:13 --> Utf8 Class Initialized
INFO - 2020-01-27 07:03:13 --> URI Class Initialized
INFO - 2020-01-27 07:03:13 --> Router Class Initialized
INFO - 2020-01-27 07:03:13 --> Output Class Initialized
INFO - 2020-01-27 07:03:13 --> Security Class Initialized
DEBUG - 2020-01-27 07:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:03:13 --> Input Class Initialized
INFO - 2020-01-27 07:03:13 --> Language Class Initialized
INFO - 2020-01-27 07:03:13 --> Language Class Initialized
INFO - 2020-01-27 07:03:13 --> Config Class Initialized
INFO - 2020-01-27 07:03:13 --> Loader Class Initialized
INFO - 2020-01-27 07:03:14 --> Helper loaded: url_helper
INFO - 2020-01-27 07:03:14 --> Helper loaded: file_helper
INFO - 2020-01-27 07:03:14 --> Helper loaded: form_helper
INFO - 2020-01-27 07:03:14 --> Helper loaded: my_helper
INFO - 2020-01-27 07:03:14 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:03:14 --> Controller Class Initialized
ERROR - 2020-01-27 07:03:14 --> Severity: Notice --> Undefined index: kode_singkat E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\data_mapel\controllers\Data_mapel.php 77
ERROR - 2020-01-27 07:03:14 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO m_mapel (kelompok, nama, kd_singkat,kkm) VALUES ('Bahasa Inggris', '','70')
INFO - 2020-01-27 07:03:14 --> Language file loaded: language/english/db_lang.php
INFO - 2020-01-27 07:03:20 --> Config Class Initialized
INFO - 2020-01-27 07:03:20 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:03:20 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:03:20 --> Utf8 Class Initialized
INFO - 2020-01-27 07:03:20 --> URI Class Initialized
INFO - 2020-01-27 07:03:20 --> Router Class Initialized
INFO - 2020-01-27 07:03:20 --> Output Class Initialized
INFO - 2020-01-27 07:03:20 --> Security Class Initialized
DEBUG - 2020-01-27 07:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:03:20 --> Input Class Initialized
INFO - 2020-01-27 07:03:20 --> Language Class Initialized
INFO - 2020-01-27 07:03:20 --> Language Class Initialized
INFO - 2020-01-27 07:03:20 --> Config Class Initialized
INFO - 2020-01-27 07:03:20 --> Loader Class Initialized
INFO - 2020-01-27 07:03:20 --> Helper loaded: url_helper
INFO - 2020-01-27 07:03:20 --> Helper loaded: file_helper
INFO - 2020-01-27 07:03:20 --> Helper loaded: form_helper
INFO - 2020-01-27 07:03:20 --> Helper loaded: my_helper
INFO - 2020-01-27 07:03:20 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:03:20 --> Controller Class Initialized
ERROR - 2020-01-27 07:03:20 --> Severity: Notice --> Undefined index: kode_singkat E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\data_mapel\controllers\Data_mapel.php 77
ERROR - 2020-01-27 07:03:20 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO m_mapel (kelompok, nama, kd_singkat,kkm) VALUES ('Bahasa Inggris', '','70')
INFO - 2020-01-27 07:03:20 --> Language file loaded: language/english/db_lang.php
INFO - 2020-01-27 07:03:27 --> Config Class Initialized
INFO - 2020-01-27 07:03:27 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:03:27 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:03:27 --> Utf8 Class Initialized
INFO - 2020-01-27 07:03:27 --> URI Class Initialized
INFO - 2020-01-27 07:03:27 --> Router Class Initialized
INFO - 2020-01-27 07:03:27 --> Output Class Initialized
INFO - 2020-01-27 07:03:27 --> Security Class Initialized
DEBUG - 2020-01-27 07:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:03:27 --> Input Class Initialized
INFO - 2020-01-27 07:03:27 --> Language Class Initialized
INFO - 2020-01-27 07:03:27 --> Language Class Initialized
INFO - 2020-01-27 07:03:27 --> Config Class Initialized
INFO - 2020-01-27 07:03:27 --> Loader Class Initialized
INFO - 2020-01-27 07:03:27 --> Helper loaded: url_helper
INFO - 2020-01-27 07:03:27 --> Helper loaded: file_helper
INFO - 2020-01-27 07:03:27 --> Helper loaded: form_helper
INFO - 2020-01-27 07:03:27 --> Helper loaded: my_helper
INFO - 2020-01-27 07:03:27 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:03:28 --> Controller Class Initialized
DEBUG - 2020-01-27 07:03:28 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_mapel/views/list.php
DEBUG - 2020-01-27 07:03:28 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 07:03:28 --> Final output sent to browser
DEBUG - 2020-01-27 07:03:28 --> Total execution time: 0.4352
INFO - 2020-01-27 07:03:28 --> Config Class Initialized
INFO - 2020-01-27 07:03:28 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:03:28 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:03:28 --> Utf8 Class Initialized
INFO - 2020-01-27 07:03:28 --> URI Class Initialized
INFO - 2020-01-27 07:03:28 --> Router Class Initialized
INFO - 2020-01-27 07:03:28 --> Output Class Initialized
INFO - 2020-01-27 07:03:28 --> Security Class Initialized
DEBUG - 2020-01-27 07:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:03:28 --> Input Class Initialized
INFO - 2020-01-27 07:03:28 --> Language Class Initialized
INFO - 2020-01-27 07:03:28 --> Language Class Initialized
INFO - 2020-01-27 07:03:28 --> Config Class Initialized
INFO - 2020-01-27 07:03:28 --> Loader Class Initialized
INFO - 2020-01-27 07:03:28 --> Helper loaded: url_helper
INFO - 2020-01-27 07:03:28 --> Helper loaded: file_helper
INFO - 2020-01-27 07:03:28 --> Helper loaded: form_helper
INFO - 2020-01-27 07:03:28 --> Helper loaded: my_helper
INFO - 2020-01-27 07:03:28 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:03:28 --> Controller Class Initialized
INFO - 2020-01-27 07:03:32 --> Config Class Initialized
INFO - 2020-01-27 07:03:32 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:03:32 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:03:32 --> Utf8 Class Initialized
INFO - 2020-01-27 07:03:32 --> URI Class Initialized
INFO - 2020-01-27 07:03:32 --> Router Class Initialized
INFO - 2020-01-27 07:03:32 --> Output Class Initialized
INFO - 2020-01-27 07:03:32 --> Security Class Initialized
DEBUG - 2020-01-27 07:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:03:32 --> Input Class Initialized
INFO - 2020-01-27 07:03:32 --> Language Class Initialized
INFO - 2020-01-27 07:03:32 --> Language Class Initialized
INFO - 2020-01-27 07:03:32 --> Config Class Initialized
INFO - 2020-01-27 07:03:32 --> Loader Class Initialized
INFO - 2020-01-27 07:03:32 --> Helper loaded: url_helper
INFO - 2020-01-27 07:03:32 --> Helper loaded: file_helper
INFO - 2020-01-27 07:03:32 --> Helper loaded: form_helper
INFO - 2020-01-27 07:03:32 --> Helper loaded: my_helper
INFO - 2020-01-27 07:03:32 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:03:32 --> Controller Class Initialized
INFO - 2020-01-27 07:03:34 --> Config Class Initialized
INFO - 2020-01-27 07:03:34 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:03:34 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:03:34 --> Utf8 Class Initialized
INFO - 2020-01-27 07:03:34 --> URI Class Initialized
INFO - 2020-01-27 07:03:34 --> Router Class Initialized
INFO - 2020-01-27 07:03:34 --> Output Class Initialized
INFO - 2020-01-27 07:03:34 --> Security Class Initialized
DEBUG - 2020-01-27 07:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:03:34 --> Input Class Initialized
INFO - 2020-01-27 07:03:34 --> Language Class Initialized
INFO - 2020-01-27 07:03:34 --> Language Class Initialized
INFO - 2020-01-27 07:03:34 --> Config Class Initialized
INFO - 2020-01-27 07:03:34 --> Loader Class Initialized
INFO - 2020-01-27 07:03:34 --> Helper loaded: url_helper
INFO - 2020-01-27 07:03:34 --> Helper loaded: file_helper
INFO - 2020-01-27 07:03:34 --> Helper loaded: form_helper
INFO - 2020-01-27 07:03:34 --> Helper loaded: my_helper
INFO - 2020-01-27 07:03:34 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:03:34 --> Controller Class Initialized
INFO - 2020-01-27 07:03:35 --> Config Class Initialized
INFO - 2020-01-27 07:03:35 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:03:35 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:03:35 --> Utf8 Class Initialized
INFO - 2020-01-27 07:03:35 --> URI Class Initialized
INFO - 2020-01-27 07:03:35 --> Router Class Initialized
INFO - 2020-01-27 07:03:35 --> Output Class Initialized
INFO - 2020-01-27 07:03:35 --> Security Class Initialized
DEBUG - 2020-01-27 07:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:03:35 --> Input Class Initialized
INFO - 2020-01-27 07:03:35 --> Language Class Initialized
INFO - 2020-01-27 07:03:35 --> Language Class Initialized
INFO - 2020-01-27 07:03:35 --> Config Class Initialized
INFO - 2020-01-27 07:03:35 --> Loader Class Initialized
INFO - 2020-01-27 07:03:35 --> Helper loaded: url_helper
INFO - 2020-01-27 07:03:35 --> Helper loaded: file_helper
INFO - 2020-01-27 07:03:35 --> Helper loaded: form_helper
INFO - 2020-01-27 07:03:35 --> Helper loaded: my_helper
INFO - 2020-01-27 07:03:36 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:03:36 --> Controller Class Initialized
INFO - 2020-01-27 07:03:36 --> Final output sent to browser
DEBUG - 2020-01-27 07:03:36 --> Total execution time: 0.3708
INFO - 2020-01-27 07:03:47 --> Config Class Initialized
INFO - 2020-01-27 07:03:47 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:03:47 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:03:47 --> Utf8 Class Initialized
INFO - 2020-01-27 07:03:47 --> URI Class Initialized
INFO - 2020-01-27 07:03:47 --> Router Class Initialized
INFO - 2020-01-27 07:03:47 --> Output Class Initialized
INFO - 2020-01-27 07:03:47 --> Security Class Initialized
DEBUG - 2020-01-27 07:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:03:47 --> Input Class Initialized
INFO - 2020-01-27 07:03:47 --> Language Class Initialized
INFO - 2020-01-27 07:03:47 --> Language Class Initialized
INFO - 2020-01-27 07:03:47 --> Config Class Initialized
INFO - 2020-01-27 07:03:47 --> Loader Class Initialized
INFO - 2020-01-27 07:03:47 --> Helper loaded: url_helper
INFO - 2020-01-27 07:03:47 --> Helper loaded: file_helper
INFO - 2020-01-27 07:03:47 --> Helper loaded: form_helper
INFO - 2020-01-27 07:03:47 --> Helper loaded: my_helper
INFO - 2020-01-27 07:03:47 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:03:47 --> Controller Class Initialized
ERROR - 2020-01-27 07:03:47 --> Severity: Notice --> Undefined index: kode_singkat E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\data_mapel\controllers\Data_mapel.php 77
ERROR - 2020-01-27 07:03:47 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO m_mapel (kelompok, nama, kd_singkat,kkm) VALUES ('Bahasa Inggris', '','70')
INFO - 2020-01-27 07:03:47 --> Language file loaded: language/english/db_lang.php
INFO - 2020-01-27 07:03:58 --> Config Class Initialized
INFO - 2020-01-27 07:03:58 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:03:58 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:03:58 --> Utf8 Class Initialized
INFO - 2020-01-27 07:03:58 --> URI Class Initialized
INFO - 2020-01-27 07:03:58 --> Router Class Initialized
INFO - 2020-01-27 07:03:58 --> Output Class Initialized
INFO - 2020-01-27 07:03:58 --> Security Class Initialized
DEBUG - 2020-01-27 07:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:03:58 --> Input Class Initialized
INFO - 2020-01-27 07:03:58 --> Language Class Initialized
INFO - 2020-01-27 07:03:58 --> Language Class Initialized
INFO - 2020-01-27 07:03:58 --> Config Class Initialized
INFO - 2020-01-27 07:03:58 --> Loader Class Initialized
INFO - 2020-01-27 07:03:58 --> Helper loaded: url_helper
INFO - 2020-01-27 07:03:58 --> Helper loaded: file_helper
INFO - 2020-01-27 07:03:58 --> Helper loaded: form_helper
INFO - 2020-01-27 07:03:58 --> Helper loaded: my_helper
INFO - 2020-01-27 07:03:58 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:03:58 --> Controller Class Initialized
ERROR - 2020-01-27 07:03:58 --> Severity: Notice --> Undefined index: kode_singkat E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\data_mapel\controllers\Data_mapel.php 77
ERROR - 2020-01-27 07:03:58 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO m_mapel (kelompok, nama, kd_singkat,kkm) VALUES ('Bahasa Inggris', '','70')
INFO - 2020-01-27 07:03:58 --> Language file loaded: language/english/db_lang.php
INFO - 2020-01-27 07:03:59 --> Config Class Initialized
INFO - 2020-01-27 07:03:59 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:03:59 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:03:59 --> Utf8 Class Initialized
INFO - 2020-01-27 07:03:59 --> URI Class Initialized
INFO - 2020-01-27 07:03:59 --> Router Class Initialized
INFO - 2020-01-27 07:03:59 --> Output Class Initialized
INFO - 2020-01-27 07:03:59 --> Security Class Initialized
DEBUG - 2020-01-27 07:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:03:59 --> Input Class Initialized
INFO - 2020-01-27 07:03:59 --> Language Class Initialized
INFO - 2020-01-27 07:03:59 --> Config Class Initialized
INFO - 2020-01-27 07:03:59 --> Hooks Class Initialized
INFO - 2020-01-27 07:03:59 --> Language Class Initialized
INFO - 2020-01-27 07:03:59 --> Config Class Initialized
DEBUG - 2020-01-27 07:03:59 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:03:59 --> Utf8 Class Initialized
INFO - 2020-01-27 07:03:59 --> Loader Class Initialized
INFO - 2020-01-27 07:03:59 --> URI Class Initialized
INFO - 2020-01-27 07:03:59 --> Helper loaded: url_helper
INFO - 2020-01-27 07:03:59 --> Helper loaded: file_helper
INFO - 2020-01-27 07:03:59 --> Router Class Initialized
INFO - 2020-01-27 07:04:00 --> Helper loaded: form_helper
INFO - 2020-01-27 07:04:00 --> Output Class Initialized
INFO - 2020-01-27 07:04:00 --> Helper loaded: my_helper
INFO - 2020-01-27 07:04:00 --> Security Class Initialized
DEBUG - 2020-01-27 07:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:04:00 --> Database Driver Class Initialized
INFO - 2020-01-27 07:04:00 --> Input Class Initialized
DEBUG - 2020-01-27 07:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:04:00 --> Language Class Initialized
INFO - 2020-01-27 07:04:00 --> Controller Class Initialized
INFO - 2020-01-27 07:04:00 --> Language Class Initialized
INFO - 2020-01-27 07:04:00 --> Config Class Initialized
ERROR - 2020-01-27 07:04:00 --> Severity: Notice --> Undefined index: kode_singkat E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\data_mapel\controllers\Data_mapel.php 77
INFO - 2020-01-27 07:04:00 --> Loader Class Initialized
ERROR - 2020-01-27 07:04:00 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO m_mapel (kelompok, nama, kd_singkat,kkm) VALUES ('Bahasa Inggris', '','70')
INFO - 2020-01-27 07:04:00 --> Language file loaded: language/english/db_lang.php
INFO - 2020-01-27 07:04:00 --> Helper loaded: url_helper
INFO - 2020-01-27 07:04:00 --> Helper loaded: file_helper
INFO - 2020-01-27 07:04:00 --> Helper loaded: form_helper
INFO - 2020-01-27 07:04:00 --> Helper loaded: my_helper
INFO - 2020-01-27 07:04:00 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:04:00 --> Controller Class Initialized
ERROR - 2020-01-27 07:04:00 --> Severity: Notice --> Undefined index: kode_singkat E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\data_mapel\controllers\Data_mapel.php 77
ERROR - 2020-01-27 07:04:00 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO m_mapel (kelompok, nama, kd_singkat,kkm) VALUES ('Bahasa Inggris', '','70')
INFO - 2020-01-27 07:04:00 --> Language file loaded: language/english/db_lang.php
INFO - 2020-01-27 07:04:05 --> Config Class Initialized
INFO - 2020-01-27 07:04:05 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:04:05 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:04:05 --> Utf8 Class Initialized
INFO - 2020-01-27 07:04:05 --> URI Class Initialized
INFO - 2020-01-27 07:04:05 --> Router Class Initialized
INFO - 2020-01-27 07:04:05 --> Output Class Initialized
INFO - 2020-01-27 07:04:05 --> Security Class Initialized
DEBUG - 2020-01-27 07:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:04:05 --> Input Class Initialized
INFO - 2020-01-27 07:04:05 --> Language Class Initialized
ERROR - 2020-01-27 07:04:05 --> 404 Page Not Found: /index
INFO - 2020-01-27 07:04:06 --> Config Class Initialized
INFO - 2020-01-27 07:04:06 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:04:06 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:04:06 --> Utf8 Class Initialized
INFO - 2020-01-27 07:04:06 --> URI Class Initialized
INFO - 2020-01-27 07:04:06 --> Router Class Initialized
INFO - 2020-01-27 07:04:06 --> Output Class Initialized
INFO - 2020-01-27 07:04:06 --> Security Class Initialized
DEBUG - 2020-01-27 07:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:04:06 --> Input Class Initialized
INFO - 2020-01-27 07:04:06 --> Language Class Initialized
INFO - 2020-01-27 07:04:06 --> Language Class Initialized
INFO - 2020-01-27 07:04:06 --> Config Class Initialized
INFO - 2020-01-27 07:04:06 --> Loader Class Initialized
INFO - 2020-01-27 07:04:06 --> Helper loaded: url_helper
INFO - 2020-01-27 07:04:06 --> Helper loaded: file_helper
INFO - 2020-01-27 07:04:06 --> Helper loaded: form_helper
INFO - 2020-01-27 07:04:06 --> Helper loaded: my_helper
INFO - 2020-01-27 07:04:06 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:04:06 --> Controller Class Initialized
ERROR - 2020-01-27 07:04:06 --> Severity: Notice --> Undefined index: kode_singkat E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\data_mapel\controllers\Data_mapel.php 77
ERROR - 2020-01-27 07:04:06 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO m_mapel (kelompok, nama, kd_singkat,kkm) VALUES ('Bahasa Inggris', '','70')
INFO - 2020-01-27 07:04:06 --> Language file loaded: language/english/db_lang.php
INFO - 2020-01-27 07:04:07 --> Config Class Initialized
INFO - 2020-01-27 07:04:07 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:04:07 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:04:07 --> Utf8 Class Initialized
INFO - 2020-01-27 07:04:07 --> URI Class Initialized
INFO - 2020-01-27 07:04:07 --> Router Class Initialized
INFO - 2020-01-27 07:04:07 --> Output Class Initialized
INFO - 2020-01-27 07:04:07 --> Security Class Initialized
DEBUG - 2020-01-27 07:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:04:07 --> Input Class Initialized
INFO - 2020-01-27 07:04:07 --> Language Class Initialized
INFO - 2020-01-27 07:04:07 --> Language Class Initialized
INFO - 2020-01-27 07:04:07 --> Config Class Initialized
INFO - 2020-01-27 07:04:07 --> Loader Class Initialized
INFO - 2020-01-27 07:04:07 --> Helper loaded: url_helper
INFO - 2020-01-27 07:04:07 --> Helper loaded: file_helper
INFO - 2020-01-27 07:04:07 --> Helper loaded: form_helper
INFO - 2020-01-27 07:04:07 --> Helper loaded: my_helper
INFO - 2020-01-27 07:04:07 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:04:07 --> Controller Class Initialized
ERROR - 2020-01-27 07:04:07 --> Severity: Notice --> Undefined index: kode_singkat E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\data_mapel\controllers\Data_mapel.php 77
ERROR - 2020-01-27 07:04:07 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO m_mapel (kelompok, nama, kd_singkat,kkm) VALUES ('Bahasa Inggris', '','70')
INFO - 2020-01-27 07:04:07 --> Language file loaded: language/english/db_lang.php
INFO - 2020-01-27 07:04:11 --> Config Class Initialized
INFO - 2020-01-27 07:04:11 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:04:11 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:04:11 --> Utf8 Class Initialized
INFO - 2020-01-27 07:04:11 --> URI Class Initialized
INFO - 2020-01-27 07:04:11 --> Router Class Initialized
INFO - 2020-01-27 07:04:11 --> Output Class Initialized
INFO - 2020-01-27 07:04:11 --> Security Class Initialized
DEBUG - 2020-01-27 07:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:04:11 --> Input Class Initialized
INFO - 2020-01-27 07:04:11 --> Language Class Initialized
INFO - 2020-01-27 07:04:11 --> Language Class Initialized
INFO - 2020-01-27 07:04:11 --> Config Class Initialized
INFO - 2020-01-27 07:04:11 --> Loader Class Initialized
INFO - 2020-01-27 07:04:11 --> Helper loaded: url_helper
INFO - 2020-01-27 07:04:11 --> Helper loaded: file_helper
INFO - 2020-01-27 07:04:11 --> Helper loaded: form_helper
INFO - 2020-01-27 07:04:11 --> Helper loaded: my_helper
INFO - 2020-01-27 07:04:11 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:04:11 --> Controller Class Initialized
ERROR - 2020-01-27 07:04:11 --> Severity: Notice --> Undefined index: kode_singkat E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\data_mapel\controllers\Data_mapel.php 77
ERROR - 2020-01-27 07:04:11 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO m_mapel (kelompok, nama, kd_singkat,kkm) VALUES ('Bahasa Inggris', '','70')
INFO - 2020-01-27 07:04:11 --> Language file loaded: language/english/db_lang.php
INFO - 2020-01-27 07:04:41 --> Config Class Initialized
INFO - 2020-01-27 07:04:41 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:04:41 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:04:41 --> Utf8 Class Initialized
INFO - 2020-01-27 07:04:41 --> URI Class Initialized
INFO - 2020-01-27 07:04:41 --> Router Class Initialized
INFO - 2020-01-27 07:04:41 --> Output Class Initialized
INFO - 2020-01-27 07:04:41 --> Security Class Initialized
DEBUG - 2020-01-27 07:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:04:42 --> Input Class Initialized
INFO - 2020-01-27 07:04:42 --> Language Class Initialized
INFO - 2020-01-27 07:04:42 --> Language Class Initialized
INFO - 2020-01-27 07:04:42 --> Config Class Initialized
INFO - 2020-01-27 07:04:42 --> Loader Class Initialized
INFO - 2020-01-27 07:04:42 --> Helper loaded: url_helper
INFO - 2020-01-27 07:04:42 --> Helper loaded: file_helper
INFO - 2020-01-27 07:04:42 --> Helper loaded: form_helper
INFO - 2020-01-27 07:04:42 --> Helper loaded: my_helper
INFO - 2020-01-27 07:04:42 --> Config Class Initialized
INFO - 2020-01-27 07:04:42 --> Hooks Class Initialized
INFO - 2020-01-27 07:04:42 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:04:42 --> UTF-8 Support Enabled
DEBUG - 2020-01-27 07:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:04:42 --> Utf8 Class Initialized
INFO - 2020-01-27 07:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:04:42 --> Controller Class Initialized
INFO - 2020-01-27 07:04:42 --> URI Class Initialized
ERROR - 2020-01-27 07:04:42 --> Severity: Notice --> Undefined index: kode_singkat E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\data_mapel\controllers\Data_mapel.php 77
INFO - 2020-01-27 07:04:42 --> Router Class Initialized
ERROR - 2020-01-27 07:04:42 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO m_mapel (kelompok, nama, kd_singkat,kkm) VALUES ('Bahasa Inggris', '','70')
INFO - 2020-01-27 07:04:42 --> Output Class Initialized
INFO - 2020-01-27 07:04:42 --> Language file loaded: language/english/db_lang.php
INFO - 2020-01-27 07:04:42 --> Security Class Initialized
DEBUG - 2020-01-27 07:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:04:42 --> Input Class Initialized
INFO - 2020-01-27 07:04:42 --> Language Class Initialized
INFO - 2020-01-27 07:04:42 --> Language Class Initialized
INFO - 2020-01-27 07:04:42 --> Config Class Initialized
INFO - 2020-01-27 07:04:42 --> Hooks Class Initialized
INFO - 2020-01-27 07:04:42 --> Config Class Initialized
INFO - 2020-01-27 07:04:42 --> Loader Class Initialized
DEBUG - 2020-01-27 07:04:42 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:04:42 --> Utf8 Class Initialized
INFO - 2020-01-27 07:04:42 --> Helper loaded: url_helper
INFO - 2020-01-27 07:04:42 --> Helper loaded: file_helper
INFO - 2020-01-27 07:04:42 --> URI Class Initialized
INFO - 2020-01-27 07:04:42 --> Helper loaded: form_helper
INFO - 2020-01-27 07:04:42 --> Router Class Initialized
INFO - 2020-01-27 07:04:42 --> Helper loaded: my_helper
INFO - 2020-01-27 07:04:42 --> Output Class Initialized
INFO - 2020-01-27 07:04:42 --> Security Class Initialized
INFO - 2020-01-27 07:04:42 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-27 07:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:04:42 --> Input Class Initialized
INFO - 2020-01-27 07:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:04:42 --> Controller Class Initialized
INFO - 2020-01-27 07:04:42 --> Language Class Initialized
ERROR - 2020-01-27 07:04:42 --> Severity: Notice --> Undefined index: kode_singkat E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\data_mapel\controllers\Data_mapel.php 77
INFO - 2020-01-27 07:04:42 --> Language Class Initialized
INFO - 2020-01-27 07:04:42 --> Config Class Initialized
ERROR - 2020-01-27 07:04:42 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO m_mapel (kelompok, nama, kd_singkat,kkm) VALUES ('Bahasa Inggris', '','70')
INFO - 2020-01-27 07:04:42 --> Loader Class Initialized
INFO - 2020-01-27 07:04:42 --> Language file loaded: language/english/db_lang.php
INFO - 2020-01-27 07:04:42 --> Helper loaded: url_helper
INFO - 2020-01-27 07:04:42 --> Helper loaded: file_helper
INFO - 2020-01-27 07:04:42 --> Helper loaded: form_helper
INFO - 2020-01-27 07:04:42 --> Helper loaded: my_helper
INFO - 2020-01-27 07:04:42 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:04:42 --> Controller Class Initialized
ERROR - 2020-01-27 07:04:42 --> Severity: Notice --> Undefined index: kode_singkat E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\data_mapel\controllers\Data_mapel.php 77
ERROR - 2020-01-27 07:04:42 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO m_mapel (kelompok, nama, kd_singkat,kkm) VALUES ('Bahasa Inggris', '','70')
INFO - 2020-01-27 07:04:42 --> Language file loaded: language/english/db_lang.php
INFO - 2020-01-27 07:04:53 --> Config Class Initialized
INFO - 2020-01-27 07:04:53 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:04:53 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:04:53 --> Utf8 Class Initialized
INFO - 2020-01-27 07:04:53 --> URI Class Initialized
INFO - 2020-01-27 07:04:53 --> Router Class Initialized
INFO - 2020-01-27 07:04:53 --> Output Class Initialized
INFO - 2020-01-27 07:04:53 --> Security Class Initialized
DEBUG - 2020-01-27 07:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:04:53 --> Input Class Initialized
INFO - 2020-01-27 07:04:54 --> Language Class Initialized
INFO - 2020-01-27 07:04:54 --> Language Class Initialized
INFO - 2020-01-27 07:04:54 --> Config Class Initialized
INFO - 2020-01-27 07:04:54 --> Loader Class Initialized
INFO - 2020-01-27 07:04:54 --> Helper loaded: url_helper
INFO - 2020-01-27 07:04:54 --> Helper loaded: file_helper
INFO - 2020-01-27 07:04:54 --> Helper loaded: form_helper
INFO - 2020-01-27 07:04:54 --> Helper loaded: my_helper
INFO - 2020-01-27 07:04:54 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:04:54 --> Controller Class Initialized
INFO - 2020-01-27 07:04:54 --> Final output sent to browser
DEBUG - 2020-01-27 07:04:54 --> Total execution time: 0.4177
INFO - 2020-01-27 07:04:59 --> Config Class Initialized
INFO - 2020-01-27 07:04:59 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:04:59 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:04:59 --> Utf8 Class Initialized
INFO - 2020-01-27 07:04:59 --> URI Class Initialized
INFO - 2020-01-27 07:04:59 --> Router Class Initialized
INFO - 2020-01-27 07:04:59 --> Output Class Initialized
INFO - 2020-01-27 07:04:59 --> Security Class Initialized
DEBUG - 2020-01-27 07:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:04:59 --> Input Class Initialized
INFO - 2020-01-27 07:04:59 --> Language Class Initialized
INFO - 2020-01-27 07:04:59 --> Language Class Initialized
INFO - 2020-01-27 07:04:59 --> Config Class Initialized
INFO - 2020-01-27 07:04:59 --> Loader Class Initialized
INFO - 2020-01-27 07:04:59 --> Helper loaded: url_helper
INFO - 2020-01-27 07:04:59 --> Helper loaded: file_helper
INFO - 2020-01-27 07:04:59 --> Helper loaded: form_helper
INFO - 2020-01-27 07:04:59 --> Helper loaded: my_helper
INFO - 2020-01-27 07:04:59 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:04:59 --> Controller Class Initialized
INFO - 2020-01-27 07:04:59 --> Final output sent to browser
DEBUG - 2020-01-27 07:04:59 --> Total execution time: 0.3922
INFO - 2020-01-27 07:05:00 --> Config Class Initialized
INFO - 2020-01-27 07:05:00 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:05:00 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:05:00 --> Utf8 Class Initialized
INFO - 2020-01-27 07:05:00 --> URI Class Initialized
INFO - 2020-01-27 07:05:00 --> Router Class Initialized
INFO - 2020-01-27 07:05:00 --> Output Class Initialized
INFO - 2020-01-27 07:05:00 --> Security Class Initialized
DEBUG - 2020-01-27 07:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:05:00 --> Input Class Initialized
INFO - 2020-01-27 07:05:00 --> Language Class Initialized
INFO - 2020-01-27 07:05:00 --> Language Class Initialized
INFO - 2020-01-27 07:05:00 --> Config Class Initialized
INFO - 2020-01-27 07:05:00 --> Loader Class Initialized
INFO - 2020-01-27 07:05:00 --> Helper loaded: url_helper
INFO - 2020-01-27 07:05:00 --> Helper loaded: file_helper
INFO - 2020-01-27 07:05:00 --> Helper loaded: form_helper
INFO - 2020-01-27 07:05:00 --> Helper loaded: my_helper
INFO - 2020-01-27 07:05:00 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:05:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:05:00 --> Controller Class Initialized
INFO - 2020-01-27 07:05:03 --> Config Class Initialized
INFO - 2020-01-27 07:05:03 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:05:03 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:05:03 --> Utf8 Class Initialized
INFO - 2020-01-27 07:05:03 --> URI Class Initialized
INFO - 2020-01-27 07:05:03 --> Router Class Initialized
INFO - 2020-01-27 07:05:03 --> Output Class Initialized
INFO - 2020-01-27 07:05:03 --> Security Class Initialized
DEBUG - 2020-01-27 07:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:05:03 --> Input Class Initialized
INFO - 2020-01-27 07:05:03 --> Language Class Initialized
INFO - 2020-01-27 07:05:03 --> Language Class Initialized
INFO - 2020-01-27 07:05:03 --> Config Class Initialized
INFO - 2020-01-27 07:05:03 --> Loader Class Initialized
INFO - 2020-01-27 07:05:03 --> Helper loaded: url_helper
INFO - 2020-01-27 07:05:03 --> Helper loaded: file_helper
INFO - 2020-01-27 07:05:03 --> Helper loaded: form_helper
INFO - 2020-01-27 07:05:03 --> Helper loaded: my_helper
INFO - 2020-01-27 07:05:03 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:05:03 --> Controller Class Initialized
INFO - 2020-01-27 07:05:03 --> Final output sent to browser
DEBUG - 2020-01-27 07:05:03 --> Total execution time: 0.4402
INFO - 2020-01-27 07:05:14 --> Config Class Initialized
INFO - 2020-01-27 07:05:14 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:05:14 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:05:14 --> Utf8 Class Initialized
INFO - 2020-01-27 07:05:14 --> URI Class Initialized
INFO - 2020-01-27 07:05:14 --> Router Class Initialized
INFO - 2020-01-27 07:05:14 --> Output Class Initialized
INFO - 2020-01-27 07:05:14 --> Security Class Initialized
DEBUG - 2020-01-27 07:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:05:14 --> Input Class Initialized
INFO - 2020-01-27 07:05:14 --> Language Class Initialized
INFO - 2020-01-27 07:05:14 --> Language Class Initialized
INFO - 2020-01-27 07:05:14 --> Config Class Initialized
INFO - 2020-01-27 07:05:14 --> Loader Class Initialized
INFO - 2020-01-27 07:05:14 --> Helper loaded: url_helper
INFO - 2020-01-27 07:05:14 --> Helper loaded: file_helper
INFO - 2020-01-27 07:05:14 --> Helper loaded: form_helper
INFO - 2020-01-27 07:05:14 --> Helper loaded: my_helper
INFO - 2020-01-27 07:05:14 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:05:14 --> Controller Class Initialized
ERROR - 2020-01-27 07:05:14 --> Severity: Notice --> Undefined index: kode_singkat E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\data_mapel\controllers\Data_mapel.php 77
ERROR - 2020-01-27 07:05:14 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO m_mapel (kelompok, nama, kd_singkat,kkm) VALUES ('r', '','60')
INFO - 2020-01-27 07:05:14 --> Language file loaded: language/english/db_lang.php
INFO - 2020-01-27 07:05:53 --> Config Class Initialized
INFO - 2020-01-27 07:05:53 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:05:53 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:05:53 --> Utf8 Class Initialized
INFO - 2020-01-27 07:05:53 --> URI Class Initialized
INFO - 2020-01-27 07:05:53 --> Router Class Initialized
INFO - 2020-01-27 07:05:53 --> Output Class Initialized
INFO - 2020-01-27 07:05:53 --> Security Class Initialized
DEBUG - 2020-01-27 07:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:05:53 --> Input Class Initialized
INFO - 2020-01-27 07:05:53 --> Language Class Initialized
INFO - 2020-01-27 07:05:53 --> Language Class Initialized
INFO - 2020-01-27 07:05:53 --> Config Class Initialized
INFO - 2020-01-27 07:05:53 --> Loader Class Initialized
INFO - 2020-01-27 07:05:53 --> Helper loaded: url_helper
INFO - 2020-01-27 07:05:53 --> Helper loaded: file_helper
INFO - 2020-01-27 07:05:53 --> Helper loaded: form_helper
INFO - 2020-01-27 07:05:53 --> Helper loaded: my_helper
INFO - 2020-01-27 07:05:53 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:05:53 --> Controller Class Initialized
INFO - 2020-01-27 07:05:53 --> Final output sent to browser
DEBUG - 2020-01-27 07:05:53 --> Total execution time: 0.4120
INFO - 2020-01-27 07:08:58 --> Config Class Initialized
INFO - 2020-01-27 07:08:59 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:08:59 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:08:59 --> Utf8 Class Initialized
INFO - 2020-01-27 07:08:59 --> URI Class Initialized
INFO - 2020-01-27 07:08:59 --> Router Class Initialized
INFO - 2020-01-27 07:08:59 --> Output Class Initialized
INFO - 2020-01-27 07:08:59 --> Security Class Initialized
DEBUG - 2020-01-27 07:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:08:59 --> Input Class Initialized
INFO - 2020-01-27 07:08:59 --> Language Class Initialized
INFO - 2020-01-27 07:08:59 --> Language Class Initialized
INFO - 2020-01-27 07:08:59 --> Config Class Initialized
INFO - 2020-01-27 07:08:59 --> Loader Class Initialized
INFO - 2020-01-27 07:08:59 --> Helper loaded: url_helper
INFO - 2020-01-27 07:08:59 --> Helper loaded: file_helper
INFO - 2020-01-27 07:08:59 --> Helper loaded: form_helper
INFO - 2020-01-27 07:08:59 --> Helper loaded: my_helper
INFO - 2020-01-27 07:08:59 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:08:59 --> Controller Class Initialized
DEBUG - 2020-01-27 07:08:59 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_mapel/views/list.php
DEBUG - 2020-01-27 07:08:59 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 07:08:59 --> Final output sent to browser
DEBUG - 2020-01-27 07:08:59 --> Total execution time: 0.4608
INFO - 2020-01-27 07:08:59 --> Config Class Initialized
INFO - 2020-01-27 07:08:59 --> Hooks Class Initialized
INFO - 2020-01-27 07:08:59 --> Config Class Initialized
INFO - 2020-01-27 07:09:00 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:09:00 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:09:00 --> Utf8 Class Initialized
DEBUG - 2020-01-27 07:09:00 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:09:00 --> Utf8 Class Initialized
INFO - 2020-01-27 07:09:00 --> URI Class Initialized
INFO - 2020-01-27 07:09:00 --> URI Class Initialized
INFO - 2020-01-27 07:09:00 --> Router Class Initialized
INFO - 2020-01-27 07:09:00 --> Output Class Initialized
INFO - 2020-01-27 07:09:00 --> Router Class Initialized
INFO - 2020-01-27 07:09:00 --> Security Class Initialized
INFO - 2020-01-27 07:09:00 --> Output Class Initialized
DEBUG - 2020-01-27 07:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:09:00 --> Security Class Initialized
INFO - 2020-01-27 07:09:00 --> Input Class Initialized
DEBUG - 2020-01-27 07:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:09:00 --> Input Class Initialized
INFO - 2020-01-27 07:09:00 --> Language Class Initialized
INFO - 2020-01-27 07:09:00 --> Language Class Initialized
ERROR - 2020-01-27 07:09:00 --> 404 Page Not Found: /index
INFO - 2020-01-27 07:09:00 --> Language Class Initialized
INFO - 2020-01-27 07:09:00 --> Config Class Initialized
INFO - 2020-01-27 07:09:00 --> Loader Class Initialized
INFO - 2020-01-27 07:09:00 --> Helper loaded: url_helper
INFO - 2020-01-27 07:09:00 --> Helper loaded: file_helper
INFO - 2020-01-27 07:09:00 --> Helper loaded: form_helper
INFO - 2020-01-27 07:09:00 --> Helper loaded: my_helper
INFO - 2020-01-27 07:09:00 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:09:00 --> Controller Class Initialized
INFO - 2020-01-27 07:09:03 --> Config Class Initialized
INFO - 2020-01-27 07:09:03 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:09:03 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:09:03 --> Utf8 Class Initialized
INFO - 2020-01-27 07:09:03 --> URI Class Initialized
INFO - 2020-01-27 07:09:03 --> Router Class Initialized
INFO - 2020-01-27 07:09:03 --> Output Class Initialized
INFO - 2020-01-27 07:09:03 --> Security Class Initialized
DEBUG - 2020-01-27 07:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:09:03 --> Input Class Initialized
INFO - 2020-01-27 07:09:03 --> Language Class Initialized
INFO - 2020-01-27 07:09:03 --> Language Class Initialized
INFO - 2020-01-27 07:09:03 --> Config Class Initialized
INFO - 2020-01-27 07:09:03 --> Loader Class Initialized
INFO - 2020-01-27 07:09:03 --> Helper loaded: url_helper
INFO - 2020-01-27 07:09:03 --> Helper loaded: file_helper
INFO - 2020-01-27 07:09:03 --> Helper loaded: form_helper
INFO - 2020-01-27 07:09:03 --> Helper loaded: my_helper
INFO - 2020-01-27 07:09:03 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:09:03 --> Controller Class Initialized
INFO - 2020-01-27 07:09:03 --> Final output sent to browser
DEBUG - 2020-01-27 07:09:03 --> Total execution time: 0.4527
INFO - 2020-01-27 07:09:09 --> Config Class Initialized
INFO - 2020-01-27 07:09:09 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:09:09 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:09:09 --> Utf8 Class Initialized
INFO - 2020-01-27 07:09:09 --> URI Class Initialized
INFO - 2020-01-27 07:09:09 --> Router Class Initialized
INFO - 2020-01-27 07:09:09 --> Output Class Initialized
INFO - 2020-01-27 07:09:09 --> Security Class Initialized
DEBUG - 2020-01-27 07:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:09:09 --> Input Class Initialized
INFO - 2020-01-27 07:09:09 --> Language Class Initialized
INFO - 2020-01-27 07:09:09 --> Language Class Initialized
INFO - 2020-01-27 07:09:09 --> Config Class Initialized
INFO - 2020-01-27 07:09:09 --> Loader Class Initialized
INFO - 2020-01-27 07:09:09 --> Helper loaded: url_helper
INFO - 2020-01-27 07:09:09 --> Helper loaded: file_helper
INFO - 2020-01-27 07:09:09 --> Helper loaded: form_helper
INFO - 2020-01-27 07:09:09 --> Helper loaded: my_helper
INFO - 2020-01-27 07:09:09 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:09:10 --> Controller Class Initialized
ERROR - 2020-01-27 07:09:10 --> Severity: Notice --> Undefined index: kode_singkat E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\data_mapel\controllers\Data_mapel.php 77
INFO - 2020-01-27 07:09:10 --> Config Class Initialized
INFO - 2020-01-27 07:09:10 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:09:10 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:09:10 --> Utf8 Class Initialized
INFO - 2020-01-27 07:09:10 --> URI Class Initialized
INFO - 2020-01-27 07:09:10 --> Router Class Initialized
INFO - 2020-01-27 07:09:10 --> Output Class Initialized
INFO - 2020-01-27 07:09:10 --> Security Class Initialized
DEBUG - 2020-01-27 07:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:09:10 --> Input Class Initialized
INFO - 2020-01-27 07:09:10 --> Language Class Initialized
INFO - 2020-01-27 07:09:10 --> Language Class Initialized
INFO - 2020-01-27 07:09:10 --> Config Class Initialized
INFO - 2020-01-27 07:09:10 --> Loader Class Initialized
INFO - 2020-01-27 07:09:10 --> Helper loaded: url_helper
INFO - 2020-01-27 07:09:10 --> Helper loaded: file_helper
INFO - 2020-01-27 07:09:10 --> Helper loaded: form_helper
INFO - 2020-01-27 07:09:10 --> Helper loaded: my_helper
INFO - 2020-01-27 07:09:10 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:09:10 --> Controller Class Initialized
INFO - 2020-01-27 07:09:25 --> Config Class Initialized
INFO - 2020-01-27 07:09:25 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:09:25 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:09:25 --> Utf8 Class Initialized
INFO - 2020-01-27 07:09:25 --> URI Class Initialized
INFO - 2020-01-27 07:09:25 --> Router Class Initialized
INFO - 2020-01-27 07:09:25 --> Output Class Initialized
INFO - 2020-01-27 07:09:25 --> Security Class Initialized
DEBUG - 2020-01-27 07:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:09:25 --> Input Class Initialized
INFO - 2020-01-27 07:09:25 --> Language Class Initialized
INFO - 2020-01-27 07:09:25 --> Language Class Initialized
INFO - 2020-01-27 07:09:25 --> Config Class Initialized
INFO - 2020-01-27 07:09:25 --> Loader Class Initialized
INFO - 2020-01-27 07:09:25 --> Helper loaded: url_helper
INFO - 2020-01-27 07:09:25 --> Helper loaded: file_helper
INFO - 2020-01-27 07:09:25 --> Helper loaded: form_helper
INFO - 2020-01-27 07:09:26 --> Helper loaded: my_helper
INFO - 2020-01-27 07:09:26 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:09:26 --> Controller Class Initialized
INFO - 2020-01-27 07:09:28 --> Config Class Initialized
INFO - 2020-01-27 07:09:28 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:09:28 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:09:28 --> Utf8 Class Initialized
INFO - 2020-01-27 07:09:28 --> URI Class Initialized
INFO - 2020-01-27 07:09:28 --> Router Class Initialized
INFO - 2020-01-27 07:09:28 --> Output Class Initialized
INFO - 2020-01-27 07:09:28 --> Security Class Initialized
DEBUG - 2020-01-27 07:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:09:28 --> Input Class Initialized
INFO - 2020-01-27 07:09:28 --> Language Class Initialized
INFO - 2020-01-27 07:09:28 --> Language Class Initialized
INFO - 2020-01-27 07:09:28 --> Config Class Initialized
INFO - 2020-01-27 07:09:28 --> Loader Class Initialized
INFO - 2020-01-27 07:09:28 --> Helper loaded: url_helper
INFO - 2020-01-27 07:09:28 --> Helper loaded: file_helper
INFO - 2020-01-27 07:09:28 --> Helper loaded: form_helper
INFO - 2020-01-27 07:09:28 --> Helper loaded: my_helper
INFO - 2020-01-27 07:09:28 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:09:28 --> Controller Class Initialized
INFO - 2020-01-27 07:09:30 --> Config Class Initialized
INFO - 2020-01-27 07:09:30 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:09:30 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:09:30 --> Utf8 Class Initialized
INFO - 2020-01-27 07:09:30 --> URI Class Initialized
INFO - 2020-01-27 07:09:30 --> Router Class Initialized
INFO - 2020-01-27 07:09:30 --> Output Class Initialized
INFO - 2020-01-27 07:09:30 --> Security Class Initialized
DEBUG - 2020-01-27 07:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:09:30 --> Input Class Initialized
INFO - 2020-01-27 07:09:30 --> Language Class Initialized
INFO - 2020-01-27 07:09:30 --> Language Class Initialized
INFO - 2020-01-27 07:09:30 --> Config Class Initialized
INFO - 2020-01-27 07:09:30 --> Loader Class Initialized
INFO - 2020-01-27 07:09:30 --> Helper loaded: url_helper
INFO - 2020-01-27 07:09:30 --> Helper loaded: file_helper
INFO - 2020-01-27 07:09:30 --> Helper loaded: form_helper
INFO - 2020-01-27 07:09:30 --> Helper loaded: my_helper
INFO - 2020-01-27 07:09:30 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:09:30 --> Controller Class Initialized
INFO - 2020-01-27 07:09:30 --> Final output sent to browser
DEBUG - 2020-01-27 07:09:30 --> Total execution time: 0.4463
INFO - 2020-01-27 07:09:37 --> Config Class Initialized
INFO - 2020-01-27 07:09:37 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:09:37 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:09:37 --> Utf8 Class Initialized
INFO - 2020-01-27 07:09:37 --> URI Class Initialized
INFO - 2020-01-27 07:09:37 --> Router Class Initialized
INFO - 2020-01-27 07:09:37 --> Output Class Initialized
INFO - 2020-01-27 07:09:37 --> Security Class Initialized
DEBUG - 2020-01-27 07:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:09:37 --> Input Class Initialized
INFO - 2020-01-27 07:09:37 --> Language Class Initialized
INFO - 2020-01-27 07:09:37 --> Language Class Initialized
INFO - 2020-01-27 07:09:37 --> Config Class Initialized
INFO - 2020-01-27 07:09:37 --> Loader Class Initialized
INFO - 2020-01-27 07:09:37 --> Helper loaded: url_helper
INFO - 2020-01-27 07:09:37 --> Helper loaded: file_helper
INFO - 2020-01-27 07:09:37 --> Helper loaded: form_helper
INFO - 2020-01-27 07:09:37 --> Helper loaded: my_helper
INFO - 2020-01-27 07:09:37 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:09:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:09:37 --> Controller Class Initialized
ERROR - 2020-01-27 07:09:37 --> Severity: Notice --> Undefined index: kode_singkat E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\data_mapel\controllers\Data_mapel.php 77
INFO - 2020-01-27 07:09:37 --> Config Class Initialized
INFO - 2020-01-27 07:09:37 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:09:37 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:09:37 --> Utf8 Class Initialized
INFO - 2020-01-27 07:09:37 --> URI Class Initialized
INFO - 2020-01-27 07:09:37 --> Router Class Initialized
INFO - 2020-01-27 07:09:37 --> Output Class Initialized
INFO - 2020-01-27 07:09:37 --> Security Class Initialized
DEBUG - 2020-01-27 07:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:09:37 --> Input Class Initialized
INFO - 2020-01-27 07:09:37 --> Language Class Initialized
INFO - 2020-01-27 07:09:37 --> Language Class Initialized
INFO - 2020-01-27 07:09:37 --> Config Class Initialized
INFO - 2020-01-27 07:09:37 --> Loader Class Initialized
INFO - 2020-01-27 07:09:37 --> Helper loaded: url_helper
INFO - 2020-01-27 07:09:37 --> Helper loaded: file_helper
INFO - 2020-01-27 07:09:37 --> Helper loaded: form_helper
INFO - 2020-01-27 07:09:37 --> Helper loaded: my_helper
INFO - 2020-01-27 07:09:37 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:09:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:09:37 --> Controller Class Initialized
INFO - 2020-01-27 07:10:30 --> Config Class Initialized
INFO - 2020-01-27 07:10:30 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:10:30 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:10:30 --> Utf8 Class Initialized
INFO - 2020-01-27 07:10:30 --> URI Class Initialized
INFO - 2020-01-27 07:10:30 --> Router Class Initialized
INFO - 2020-01-27 07:10:30 --> Output Class Initialized
INFO - 2020-01-27 07:10:30 --> Security Class Initialized
DEBUG - 2020-01-27 07:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:10:30 --> Input Class Initialized
INFO - 2020-01-27 07:10:30 --> Language Class Initialized
INFO - 2020-01-27 07:10:30 --> Language Class Initialized
INFO - 2020-01-27 07:10:30 --> Config Class Initialized
INFO - 2020-01-27 07:10:30 --> Loader Class Initialized
INFO - 2020-01-27 07:10:30 --> Helper loaded: url_helper
INFO - 2020-01-27 07:10:30 --> Helper loaded: file_helper
INFO - 2020-01-27 07:10:30 --> Helper loaded: form_helper
INFO - 2020-01-27 07:10:30 --> Helper loaded: my_helper
INFO - 2020-01-27 07:10:30 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:10:30 --> Controller Class Initialized
INFO - 2020-01-27 07:10:30 --> Final output sent to browser
DEBUG - 2020-01-27 07:10:30 --> Total execution time: 0.4322
INFO - 2020-01-27 07:10:34 --> Config Class Initialized
INFO - 2020-01-27 07:10:34 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:10:34 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:10:34 --> Utf8 Class Initialized
INFO - 2020-01-27 07:10:34 --> URI Class Initialized
INFO - 2020-01-27 07:10:34 --> Router Class Initialized
INFO - 2020-01-27 07:10:34 --> Output Class Initialized
INFO - 2020-01-27 07:10:34 --> Security Class Initialized
DEBUG - 2020-01-27 07:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:10:34 --> Input Class Initialized
INFO - 2020-01-27 07:10:34 --> Language Class Initialized
INFO - 2020-01-27 07:10:35 --> Language Class Initialized
INFO - 2020-01-27 07:10:35 --> Config Class Initialized
INFO - 2020-01-27 07:10:35 --> Loader Class Initialized
INFO - 2020-01-27 07:10:35 --> Helper loaded: url_helper
INFO - 2020-01-27 07:10:35 --> Helper loaded: file_helper
INFO - 2020-01-27 07:10:35 --> Helper loaded: form_helper
INFO - 2020-01-27 07:10:35 --> Helper loaded: my_helper
INFO - 2020-01-27 07:10:35 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:10:35 --> Controller Class Initialized
INFO - 2020-01-27 07:10:35 --> Final output sent to browser
DEBUG - 2020-01-27 07:10:35 --> Total execution time: 0.4042
INFO - 2020-01-27 07:10:35 --> Config Class Initialized
INFO - 2020-01-27 07:10:35 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:10:35 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:10:35 --> Utf8 Class Initialized
INFO - 2020-01-27 07:10:35 --> URI Class Initialized
INFO - 2020-01-27 07:10:35 --> Router Class Initialized
INFO - 2020-01-27 07:10:35 --> Output Class Initialized
INFO - 2020-01-27 07:10:35 --> Security Class Initialized
DEBUG - 2020-01-27 07:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:10:35 --> Input Class Initialized
INFO - 2020-01-27 07:10:35 --> Language Class Initialized
INFO - 2020-01-27 07:10:35 --> Language Class Initialized
INFO - 2020-01-27 07:10:35 --> Config Class Initialized
INFO - 2020-01-27 07:10:35 --> Loader Class Initialized
INFO - 2020-01-27 07:10:35 --> Helper loaded: url_helper
INFO - 2020-01-27 07:10:35 --> Helper loaded: file_helper
INFO - 2020-01-27 07:10:35 --> Helper loaded: form_helper
INFO - 2020-01-27 07:10:35 --> Helper loaded: my_helper
INFO - 2020-01-27 07:10:35 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:10:35 --> Controller Class Initialized
INFO - 2020-01-27 07:11:54 --> Config Class Initialized
INFO - 2020-01-27 07:11:54 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:11:54 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:11:54 --> Utf8 Class Initialized
INFO - 2020-01-27 07:11:54 --> URI Class Initialized
INFO - 2020-01-27 07:11:54 --> Router Class Initialized
INFO - 2020-01-27 07:11:54 --> Output Class Initialized
INFO - 2020-01-27 07:11:54 --> Security Class Initialized
DEBUG - 2020-01-27 07:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:11:54 --> Input Class Initialized
INFO - 2020-01-27 07:11:54 --> Language Class Initialized
INFO - 2020-01-27 07:11:54 --> Language Class Initialized
INFO - 2020-01-27 07:11:54 --> Config Class Initialized
INFO - 2020-01-27 07:11:54 --> Loader Class Initialized
INFO - 2020-01-27 07:11:54 --> Helper loaded: url_helper
INFO - 2020-01-27 07:11:54 --> Helper loaded: file_helper
INFO - 2020-01-27 07:11:54 --> Helper loaded: form_helper
INFO - 2020-01-27 07:11:55 --> Helper loaded: my_helper
INFO - 2020-01-27 07:11:55 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:11:55 --> Controller Class Initialized
INFO - 2020-01-27 07:11:55 --> Helper loaded: cookie_helper
INFO - 2020-01-27 07:11:55 --> Config Class Initialized
INFO - 2020-01-27 07:11:55 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:11:55 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:11:55 --> Utf8 Class Initialized
INFO - 2020-01-27 07:11:55 --> URI Class Initialized
INFO - 2020-01-27 07:11:55 --> Router Class Initialized
INFO - 2020-01-27 07:11:55 --> Output Class Initialized
INFO - 2020-01-27 07:11:55 --> Security Class Initialized
DEBUG - 2020-01-27 07:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:11:55 --> Input Class Initialized
INFO - 2020-01-27 07:11:55 --> Language Class Initialized
INFO - 2020-01-27 07:11:55 --> Language Class Initialized
INFO - 2020-01-27 07:11:55 --> Config Class Initialized
INFO - 2020-01-27 07:11:55 --> Loader Class Initialized
INFO - 2020-01-27 07:11:55 --> Helper loaded: url_helper
INFO - 2020-01-27 07:11:55 --> Helper loaded: file_helper
INFO - 2020-01-27 07:11:55 --> Helper loaded: form_helper
INFO - 2020-01-27 07:11:55 --> Helper loaded: my_helper
INFO - 2020-01-27 07:11:55 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:11:55 --> Controller Class Initialized
INFO - 2020-01-27 07:11:55 --> Config Class Initialized
INFO - 2020-01-27 07:11:55 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:11:55 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:11:55 --> Utf8 Class Initialized
INFO - 2020-01-27 07:11:55 --> URI Class Initialized
INFO - 2020-01-27 07:11:55 --> Router Class Initialized
INFO - 2020-01-27 07:11:55 --> Output Class Initialized
INFO - 2020-01-27 07:11:55 --> Security Class Initialized
DEBUG - 2020-01-27 07:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:11:55 --> Input Class Initialized
INFO - 2020-01-27 07:11:55 --> Language Class Initialized
INFO - 2020-01-27 07:11:55 --> Language Class Initialized
INFO - 2020-01-27 07:11:55 --> Config Class Initialized
INFO - 2020-01-27 07:11:55 --> Loader Class Initialized
INFO - 2020-01-27 07:11:55 --> Helper loaded: url_helper
INFO - 2020-01-27 07:11:55 --> Helper loaded: file_helper
INFO - 2020-01-27 07:11:55 --> Helper loaded: form_helper
INFO - 2020-01-27 07:11:55 --> Helper loaded: my_helper
INFO - 2020-01-27 07:11:55 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:11:55 --> Controller Class Initialized
DEBUG - 2020-01-27 07:11:55 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-27 07:11:55 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 07:11:56 --> Final output sent to browser
DEBUG - 2020-01-27 07:11:56 --> Total execution time: 0.4113
INFO - 2020-01-27 07:12:00 --> Config Class Initialized
INFO - 2020-01-27 07:12:00 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:12:00 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:12:00 --> Utf8 Class Initialized
INFO - 2020-01-27 07:12:00 --> URI Class Initialized
INFO - 2020-01-27 07:12:00 --> Router Class Initialized
INFO - 2020-01-27 07:12:00 --> Output Class Initialized
INFO - 2020-01-27 07:12:00 --> Security Class Initialized
DEBUG - 2020-01-27 07:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:12:00 --> Input Class Initialized
INFO - 2020-01-27 07:12:00 --> Language Class Initialized
INFO - 2020-01-27 07:12:00 --> Language Class Initialized
INFO - 2020-01-27 07:12:00 --> Config Class Initialized
INFO - 2020-01-27 07:12:00 --> Loader Class Initialized
INFO - 2020-01-27 07:12:00 --> Helper loaded: url_helper
INFO - 2020-01-27 07:12:00 --> Helper loaded: file_helper
INFO - 2020-01-27 07:12:00 --> Helper loaded: form_helper
INFO - 2020-01-27 07:12:00 --> Helper loaded: my_helper
INFO - 2020-01-27 07:12:00 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:12:00 --> Controller Class Initialized
INFO - 2020-01-27 07:12:00 --> Helper loaded: cookie_helper
INFO - 2020-01-27 07:12:00 --> Final output sent to browser
DEBUG - 2020-01-27 07:12:00 --> Total execution time: 0.4457
INFO - 2020-01-27 07:12:02 --> Config Class Initialized
INFO - 2020-01-27 07:12:02 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:12:02 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:12:02 --> Utf8 Class Initialized
INFO - 2020-01-27 07:12:02 --> URI Class Initialized
INFO - 2020-01-27 07:12:02 --> Router Class Initialized
INFO - 2020-01-27 07:12:02 --> Output Class Initialized
INFO - 2020-01-27 07:12:02 --> Security Class Initialized
DEBUG - 2020-01-27 07:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:12:02 --> Input Class Initialized
INFO - 2020-01-27 07:12:02 --> Language Class Initialized
INFO - 2020-01-27 07:12:02 --> Language Class Initialized
INFO - 2020-01-27 07:12:02 --> Config Class Initialized
INFO - 2020-01-27 07:12:02 --> Loader Class Initialized
INFO - 2020-01-27 07:12:02 --> Helper loaded: url_helper
INFO - 2020-01-27 07:12:02 --> Helper loaded: file_helper
INFO - 2020-01-27 07:12:02 --> Helper loaded: form_helper
INFO - 2020-01-27 07:12:02 --> Helper loaded: my_helper
INFO - 2020-01-27 07:12:02 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:12:02 --> Controller Class Initialized
DEBUG - 2020-01-27 07:12:02 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-27 07:12:02 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 07:12:02 --> Final output sent to browser
DEBUG - 2020-01-27 07:12:02 --> Total execution time: 0.5308
INFO - 2020-01-27 07:12:04 --> Config Class Initialized
INFO - 2020-01-27 07:12:04 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:12:04 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:12:04 --> Utf8 Class Initialized
INFO - 2020-01-27 07:12:04 --> URI Class Initialized
INFO - 2020-01-27 07:12:04 --> Router Class Initialized
INFO - 2020-01-27 07:12:04 --> Output Class Initialized
INFO - 2020-01-27 07:12:04 --> Security Class Initialized
DEBUG - 2020-01-27 07:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:12:04 --> Input Class Initialized
INFO - 2020-01-27 07:12:04 --> Language Class Initialized
INFO - 2020-01-27 07:12:04 --> Language Class Initialized
INFO - 2020-01-27 07:12:04 --> Config Class Initialized
INFO - 2020-01-27 07:12:04 --> Loader Class Initialized
INFO - 2020-01-27 07:12:04 --> Helper loaded: url_helper
INFO - 2020-01-27 07:12:04 --> Helper loaded: file_helper
INFO - 2020-01-27 07:12:04 --> Helper loaded: form_helper
INFO - 2020-01-27 07:12:04 --> Helper loaded: my_helper
INFO - 2020-01-27 07:12:04 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:12:04 --> Controller Class Initialized
DEBUG - 2020-01-27 07:12:04 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_mapel/views/list.php
DEBUG - 2020-01-27 07:12:04 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 07:12:04 --> Final output sent to browser
DEBUG - 2020-01-27 07:12:04 --> Total execution time: 0.4760
INFO - 2020-01-27 07:12:04 --> Config Class Initialized
INFO - 2020-01-27 07:12:04 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:12:04 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:12:04 --> Utf8 Class Initialized
INFO - 2020-01-27 07:12:04 --> URI Class Initialized
INFO - 2020-01-27 07:12:04 --> Router Class Initialized
INFO - 2020-01-27 07:12:04 --> Output Class Initialized
INFO - 2020-01-27 07:12:04 --> Security Class Initialized
DEBUG - 2020-01-27 07:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:12:04 --> Input Class Initialized
INFO - 2020-01-27 07:12:04 --> Language Class Initialized
INFO - 2020-01-27 07:12:04 --> Language Class Initialized
INFO - 2020-01-27 07:12:04 --> Config Class Initialized
INFO - 2020-01-27 07:12:04 --> Loader Class Initialized
INFO - 2020-01-27 07:12:04 --> Helper loaded: url_helper
INFO - 2020-01-27 07:12:04 --> Helper loaded: file_helper
INFO - 2020-01-27 07:12:05 --> Helper loaded: form_helper
INFO - 2020-01-27 07:12:05 --> Helper loaded: my_helper
INFO - 2020-01-27 07:12:05 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:12:05 --> Controller Class Initialized
INFO - 2020-01-27 07:12:07 --> Config Class Initialized
INFO - 2020-01-27 07:12:07 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:12:07 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:12:07 --> Utf8 Class Initialized
INFO - 2020-01-27 07:12:07 --> URI Class Initialized
INFO - 2020-01-27 07:12:07 --> Router Class Initialized
INFO - 2020-01-27 07:12:07 --> Output Class Initialized
INFO - 2020-01-27 07:12:07 --> Security Class Initialized
DEBUG - 2020-01-27 07:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:12:07 --> Input Class Initialized
INFO - 2020-01-27 07:12:07 --> Language Class Initialized
INFO - 2020-01-27 07:12:07 --> Language Class Initialized
INFO - 2020-01-27 07:12:07 --> Config Class Initialized
INFO - 2020-01-27 07:12:07 --> Loader Class Initialized
INFO - 2020-01-27 07:12:07 --> Helper loaded: url_helper
INFO - 2020-01-27 07:12:07 --> Helper loaded: file_helper
INFO - 2020-01-27 07:12:07 --> Helper loaded: form_helper
INFO - 2020-01-27 07:12:07 --> Helper loaded: my_helper
INFO - 2020-01-27 07:12:07 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:12:07 --> Controller Class Initialized
INFO - 2020-01-27 07:12:07 --> Final output sent to browser
DEBUG - 2020-01-27 07:12:07 --> Total execution time: 0.4907
INFO - 2020-01-27 07:12:10 --> Config Class Initialized
INFO - 2020-01-27 07:12:10 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:12:10 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:12:10 --> Utf8 Class Initialized
INFO - 2020-01-27 07:12:10 --> URI Class Initialized
INFO - 2020-01-27 07:12:10 --> Router Class Initialized
INFO - 2020-01-27 07:12:10 --> Output Class Initialized
INFO - 2020-01-27 07:12:10 --> Security Class Initialized
DEBUG - 2020-01-27 07:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:12:10 --> Input Class Initialized
INFO - 2020-01-27 07:12:10 --> Language Class Initialized
ERROR - 2020-01-27 07:12:10 --> 404 Page Not Found: /index
INFO - 2020-01-27 07:12:14 --> Config Class Initialized
INFO - 2020-01-27 07:12:14 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:12:14 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:12:14 --> Utf8 Class Initialized
INFO - 2020-01-27 07:12:14 --> URI Class Initialized
INFO - 2020-01-27 07:12:14 --> Router Class Initialized
INFO - 2020-01-27 07:12:14 --> Output Class Initialized
INFO - 2020-01-27 07:12:14 --> Security Class Initialized
DEBUG - 2020-01-27 07:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:12:14 --> Input Class Initialized
INFO - 2020-01-27 07:12:14 --> Language Class Initialized
INFO - 2020-01-27 07:12:14 --> Language Class Initialized
INFO - 2020-01-27 07:12:14 --> Config Class Initialized
INFO - 2020-01-27 07:12:14 --> Loader Class Initialized
INFO - 2020-01-27 07:12:14 --> Helper loaded: url_helper
INFO - 2020-01-27 07:12:14 --> Helper loaded: file_helper
INFO - 2020-01-27 07:12:14 --> Helper loaded: form_helper
INFO - 2020-01-27 07:12:14 --> Helper loaded: my_helper
INFO - 2020-01-27 07:12:14 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:12:14 --> Controller Class Initialized
INFO - 2020-01-27 07:12:14 --> Final output sent to browser
DEBUG - 2020-01-27 07:12:14 --> Total execution time: 0.4481
INFO - 2020-01-27 07:12:23 --> Config Class Initialized
INFO - 2020-01-27 07:12:23 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:12:23 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:12:23 --> Utf8 Class Initialized
INFO - 2020-01-27 07:12:23 --> URI Class Initialized
INFO - 2020-01-27 07:12:23 --> Router Class Initialized
INFO - 2020-01-27 07:12:23 --> Output Class Initialized
INFO - 2020-01-27 07:12:23 --> Security Class Initialized
DEBUG - 2020-01-27 07:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:12:24 --> Input Class Initialized
INFO - 2020-01-27 07:12:24 --> Language Class Initialized
INFO - 2020-01-27 07:12:24 --> Language Class Initialized
INFO - 2020-01-27 07:12:24 --> Config Class Initialized
INFO - 2020-01-27 07:12:24 --> Loader Class Initialized
INFO - 2020-01-27 07:12:24 --> Helper loaded: url_helper
INFO - 2020-01-27 07:12:24 --> Helper loaded: file_helper
INFO - 2020-01-27 07:12:24 --> Helper loaded: form_helper
INFO - 2020-01-27 07:12:24 --> Helper loaded: my_helper
INFO - 2020-01-27 07:12:24 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:12:24 --> Controller Class Initialized
ERROR - 2020-01-27 07:12:24 --> Severity: Notice --> Undefined index: kode_singkat E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\data_mapel\controllers\Data_mapel.php 78
ERROR - 2020-01-27 07:12:24 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO m_mapel (kelompok, nama, kd_singkat,kkm) VALUES ('sd', '','70')
INFO - 2020-01-27 07:12:24 --> Language file loaded: language/english/db_lang.php
INFO - 2020-01-27 07:14:53 --> Config Class Initialized
INFO - 2020-01-27 07:14:53 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:14:53 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:14:53 --> Utf8 Class Initialized
INFO - 2020-01-27 07:14:53 --> URI Class Initialized
INFO - 2020-01-27 07:14:53 --> Router Class Initialized
INFO - 2020-01-27 07:14:53 --> Output Class Initialized
INFO - 2020-01-27 07:14:53 --> Security Class Initialized
DEBUG - 2020-01-27 07:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:14:53 --> Input Class Initialized
INFO - 2020-01-27 07:14:53 --> Language Class Initialized
INFO - 2020-01-27 07:14:53 --> Language Class Initialized
INFO - 2020-01-27 07:14:53 --> Config Class Initialized
INFO - 2020-01-27 07:14:53 --> Loader Class Initialized
INFO - 2020-01-27 07:14:53 --> Helper loaded: url_helper
INFO - 2020-01-27 07:14:53 --> Helper loaded: file_helper
INFO - 2020-01-27 07:14:53 --> Helper loaded: form_helper
INFO - 2020-01-27 07:14:53 --> Helper loaded: my_helper
INFO - 2020-01-27 07:14:53 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:14:53 --> Controller Class Initialized
ERROR - 2020-01-27 07:14:53 --> Severity: Notice --> Undefined index: kode_singkat E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\data_mapel\controllers\Data_mapel.php 78
INFO - 2020-01-27 07:14:53 --> Final output sent to browser
DEBUG - 2020-01-27 07:14:53 --> Total execution time: 0.4527
INFO - 2020-01-27 07:14:56 --> Config Class Initialized
INFO - 2020-01-27 07:14:56 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:14:56 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:14:56 --> Utf8 Class Initialized
INFO - 2020-01-27 07:14:56 --> URI Class Initialized
INFO - 2020-01-27 07:14:56 --> Router Class Initialized
INFO - 2020-01-27 07:14:56 --> Output Class Initialized
INFO - 2020-01-27 07:14:56 --> Security Class Initialized
DEBUG - 2020-01-27 07:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:14:56 --> Input Class Initialized
INFO - 2020-01-27 07:14:56 --> Language Class Initialized
INFO - 2020-01-27 07:14:56 --> Language Class Initialized
INFO - 2020-01-27 07:14:56 --> Config Class Initialized
INFO - 2020-01-27 07:14:56 --> Loader Class Initialized
INFO - 2020-01-27 07:14:56 --> Helper loaded: url_helper
INFO - 2020-01-27 07:14:56 --> Helper loaded: file_helper
INFO - 2020-01-27 07:14:56 --> Helper loaded: form_helper
INFO - 2020-01-27 07:14:56 --> Helper loaded: my_helper
INFO - 2020-01-27 07:14:56 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:14:56 --> Controller Class Initialized
DEBUG - 2020-01-27 07:14:56 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_mapel/views/list.php
DEBUG - 2020-01-27 07:14:56 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 07:14:56 --> Final output sent to browser
DEBUG - 2020-01-27 07:14:56 --> Total execution time: 0.5981
INFO - 2020-01-27 07:14:57 --> Config Class Initialized
INFO - 2020-01-27 07:14:57 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:14:57 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:14:57 --> Utf8 Class Initialized
INFO - 2020-01-27 07:14:57 --> Config Class Initialized
INFO - 2020-01-27 07:14:57 --> Hooks Class Initialized
INFO - 2020-01-27 07:14:57 --> URI Class Initialized
DEBUG - 2020-01-27 07:14:57 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:14:57 --> Router Class Initialized
INFO - 2020-01-27 07:14:57 --> Utf8 Class Initialized
INFO - 2020-01-27 07:14:57 --> Output Class Initialized
INFO - 2020-01-27 07:14:57 --> URI Class Initialized
INFO - 2020-01-27 07:14:57 --> Security Class Initialized
DEBUG - 2020-01-27 07:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:14:57 --> Router Class Initialized
INFO - 2020-01-27 07:14:57 --> Input Class Initialized
INFO - 2020-01-27 07:14:57 --> Output Class Initialized
INFO - 2020-01-27 07:14:57 --> Language Class Initialized
INFO - 2020-01-27 07:14:57 --> Security Class Initialized
ERROR - 2020-01-27 07:14:57 --> 404 Page Not Found: /index
DEBUG - 2020-01-27 07:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:14:57 --> Input Class Initialized
INFO - 2020-01-27 07:14:57 --> Language Class Initialized
INFO - 2020-01-27 07:14:57 --> Language Class Initialized
INFO - 2020-01-27 07:14:57 --> Config Class Initialized
INFO - 2020-01-27 07:14:57 --> Loader Class Initialized
INFO - 2020-01-27 07:14:57 --> Helper loaded: url_helper
INFO - 2020-01-27 07:14:57 --> Helper loaded: file_helper
INFO - 2020-01-27 07:14:57 --> Helper loaded: form_helper
INFO - 2020-01-27 07:14:57 --> Helper loaded: my_helper
INFO - 2020-01-27 07:14:57 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:14:57 --> Controller Class Initialized
INFO - 2020-01-27 07:14:58 --> Config Class Initialized
INFO - 2020-01-27 07:14:58 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:14:58 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:14:58 --> Utf8 Class Initialized
INFO - 2020-01-27 07:14:58 --> URI Class Initialized
INFO - 2020-01-27 07:14:58 --> Router Class Initialized
INFO - 2020-01-27 07:14:58 --> Output Class Initialized
INFO - 2020-01-27 07:14:58 --> Security Class Initialized
DEBUG - 2020-01-27 07:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:14:58 --> Input Class Initialized
INFO - 2020-01-27 07:14:58 --> Language Class Initialized
INFO - 2020-01-27 07:14:58 --> Language Class Initialized
INFO - 2020-01-27 07:14:58 --> Config Class Initialized
INFO - 2020-01-27 07:14:58 --> Loader Class Initialized
INFO - 2020-01-27 07:14:58 --> Helper loaded: url_helper
INFO - 2020-01-27 07:14:58 --> Helper loaded: file_helper
INFO - 2020-01-27 07:14:58 --> Helper loaded: form_helper
INFO - 2020-01-27 07:14:58 --> Helper loaded: my_helper
INFO - 2020-01-27 07:14:58 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:14:58 --> Controller Class Initialized
INFO - 2020-01-27 07:14:58 --> Final output sent to browser
DEBUG - 2020-01-27 07:14:58 --> Total execution time: 0.4228
INFO - 2020-01-27 07:15:06 --> Config Class Initialized
INFO - 2020-01-27 07:15:06 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:15:06 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:15:06 --> Utf8 Class Initialized
INFO - 2020-01-27 07:15:06 --> URI Class Initialized
INFO - 2020-01-27 07:15:06 --> Router Class Initialized
INFO - 2020-01-27 07:15:06 --> Output Class Initialized
INFO - 2020-01-27 07:15:06 --> Security Class Initialized
DEBUG - 2020-01-27 07:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:15:06 --> Input Class Initialized
INFO - 2020-01-27 07:15:06 --> Language Class Initialized
INFO - 2020-01-27 07:15:06 --> Language Class Initialized
INFO - 2020-01-27 07:15:06 --> Config Class Initialized
INFO - 2020-01-27 07:15:06 --> Loader Class Initialized
INFO - 2020-01-27 07:15:06 --> Helper loaded: url_helper
INFO - 2020-01-27 07:15:06 --> Helper loaded: file_helper
INFO - 2020-01-27 07:15:06 --> Helper loaded: form_helper
INFO - 2020-01-27 07:15:06 --> Helper loaded: my_helper
INFO - 2020-01-27 07:15:06 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:15:06 --> Controller Class Initialized
ERROR - 2020-01-27 07:15:06 --> Severity: Notice --> Undefined index: kode_singkat E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\data_mapel\controllers\Data_mapel.php 78
INFO - 2020-01-27 07:15:06 --> Final output sent to browser
DEBUG - 2020-01-27 07:15:06 --> Total execution time: 0.4567
INFO - 2020-01-27 07:19:45 --> Config Class Initialized
INFO - 2020-01-27 07:19:45 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:19:45 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:19:45 --> Utf8 Class Initialized
INFO - 2020-01-27 07:19:45 --> URI Class Initialized
INFO - 2020-01-27 07:19:45 --> Router Class Initialized
INFO - 2020-01-27 07:19:45 --> Output Class Initialized
INFO - 2020-01-27 07:19:45 --> Security Class Initialized
DEBUG - 2020-01-27 07:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:19:45 --> Input Class Initialized
INFO - 2020-01-27 07:19:46 --> Language Class Initialized
INFO - 2020-01-27 07:19:46 --> Language Class Initialized
INFO - 2020-01-27 07:19:46 --> Config Class Initialized
INFO - 2020-01-27 07:19:46 --> Loader Class Initialized
INFO - 2020-01-27 07:19:46 --> Helper loaded: url_helper
INFO - 2020-01-27 07:19:46 --> Helper loaded: file_helper
INFO - 2020-01-27 07:19:46 --> Helper loaded: form_helper
INFO - 2020-01-27 07:19:46 --> Helper loaded: my_helper
INFO - 2020-01-27 07:19:46 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:19:46 --> Controller Class Initialized
DEBUG - 2020-01-27 07:19:46 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_mapel/views/list.php
DEBUG - 2020-01-27 07:19:46 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 07:19:46 --> Final output sent to browser
DEBUG - 2020-01-27 07:19:46 --> Total execution time: 0.5286
INFO - 2020-01-27 07:19:46 --> Config Class Initialized
INFO - 2020-01-27 07:19:46 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:19:46 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:19:46 --> Utf8 Class Initialized
INFO - 2020-01-27 07:19:46 --> URI Class Initialized
INFO - 2020-01-27 07:19:46 --> Router Class Initialized
INFO - 2020-01-27 07:19:46 --> Output Class Initialized
INFO - 2020-01-27 07:19:46 --> Security Class Initialized
DEBUG - 2020-01-27 07:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:19:46 --> Input Class Initialized
INFO - 2020-01-27 07:19:46 --> Language Class Initialized
INFO - 2020-01-27 07:19:46 --> Language Class Initialized
INFO - 2020-01-27 07:19:46 --> Config Class Initialized
INFO - 2020-01-27 07:19:46 --> Loader Class Initialized
INFO - 2020-01-27 07:19:46 --> Helper loaded: url_helper
INFO - 2020-01-27 07:19:46 --> Helper loaded: file_helper
INFO - 2020-01-27 07:19:46 --> Helper loaded: form_helper
INFO - 2020-01-27 07:19:46 --> Helper loaded: my_helper
INFO - 2020-01-27 07:19:47 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:19:47 --> Controller Class Initialized
INFO - 2020-01-27 07:19:47 --> Config Class Initialized
INFO - 2020-01-27 07:19:47 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:19:47 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:19:47 --> Utf8 Class Initialized
INFO - 2020-01-27 07:19:47 --> URI Class Initialized
INFO - 2020-01-27 07:19:47 --> Router Class Initialized
INFO - 2020-01-27 07:19:47 --> Output Class Initialized
INFO - 2020-01-27 07:19:47 --> Security Class Initialized
DEBUG - 2020-01-27 07:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:19:47 --> Input Class Initialized
INFO - 2020-01-27 07:19:47 --> Language Class Initialized
INFO - 2020-01-27 07:19:47 --> Language Class Initialized
INFO - 2020-01-27 07:19:47 --> Config Class Initialized
INFO - 2020-01-27 07:19:47 --> Loader Class Initialized
INFO - 2020-01-27 07:19:47 --> Helper loaded: url_helper
INFO - 2020-01-27 07:19:47 --> Helper loaded: file_helper
INFO - 2020-01-27 07:19:47 --> Helper loaded: form_helper
INFO - 2020-01-27 07:19:47 --> Helper loaded: my_helper
INFO - 2020-01-27 07:19:47 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:19:47 --> Controller Class Initialized
INFO - 2020-01-27 07:19:47 --> Final output sent to browser
DEBUG - 2020-01-27 07:19:47 --> Total execution time: 0.4074
INFO - 2020-01-27 07:21:37 --> Config Class Initialized
INFO - 2020-01-27 07:21:37 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:21:37 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:21:37 --> Utf8 Class Initialized
INFO - 2020-01-27 07:21:37 --> URI Class Initialized
INFO - 2020-01-27 07:21:37 --> Router Class Initialized
INFO - 2020-01-27 07:21:37 --> Output Class Initialized
INFO - 2020-01-27 07:21:37 --> Security Class Initialized
DEBUG - 2020-01-27 07:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:21:37 --> Input Class Initialized
INFO - 2020-01-27 07:21:37 --> Language Class Initialized
INFO - 2020-01-27 07:21:38 --> Language Class Initialized
INFO - 2020-01-27 07:21:38 --> Config Class Initialized
INFO - 2020-01-27 07:21:38 --> Loader Class Initialized
INFO - 2020-01-27 07:21:38 --> Helper loaded: url_helper
INFO - 2020-01-27 07:21:38 --> Helper loaded: file_helper
INFO - 2020-01-27 07:21:38 --> Helper loaded: form_helper
INFO - 2020-01-27 07:21:38 --> Helper loaded: my_helper
INFO - 2020-01-27 07:21:38 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:21:38 --> Controller Class Initialized
DEBUG - 2020-01-27 07:21:38 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_mapel/views/list.php
DEBUG - 2020-01-27 07:21:38 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 07:21:38 --> Final output sent to browser
DEBUG - 2020-01-27 07:21:38 --> Total execution time: 0.4969
INFO - 2020-01-27 07:21:38 --> Config Class Initialized
INFO - 2020-01-27 07:21:38 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:21:38 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:21:38 --> Utf8 Class Initialized
INFO - 2020-01-27 07:21:38 --> URI Class Initialized
INFO - 2020-01-27 07:21:38 --> Router Class Initialized
INFO - 2020-01-27 07:21:38 --> Output Class Initialized
INFO - 2020-01-27 07:21:38 --> Security Class Initialized
DEBUG - 2020-01-27 07:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:21:38 --> Input Class Initialized
INFO - 2020-01-27 07:21:38 --> Language Class Initialized
INFO - 2020-01-27 07:21:38 --> Language Class Initialized
INFO - 2020-01-27 07:21:38 --> Config Class Initialized
INFO - 2020-01-27 07:21:38 --> Loader Class Initialized
INFO - 2020-01-27 07:21:38 --> Helper loaded: url_helper
INFO - 2020-01-27 07:21:38 --> Helper loaded: file_helper
INFO - 2020-01-27 07:21:38 --> Helper loaded: form_helper
INFO - 2020-01-27 07:21:38 --> Helper loaded: my_helper
INFO - 2020-01-27 07:21:38 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:21:39 --> Controller Class Initialized
INFO - 2020-01-27 07:21:39 --> Config Class Initialized
INFO - 2020-01-27 07:21:39 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:21:39 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:21:39 --> Utf8 Class Initialized
INFO - 2020-01-27 07:21:39 --> URI Class Initialized
INFO - 2020-01-27 07:21:39 --> Router Class Initialized
INFO - 2020-01-27 07:21:39 --> Output Class Initialized
INFO - 2020-01-27 07:21:39 --> Security Class Initialized
DEBUG - 2020-01-27 07:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:21:39 --> Input Class Initialized
INFO - 2020-01-27 07:21:39 --> Language Class Initialized
INFO - 2020-01-27 07:21:39 --> Language Class Initialized
INFO - 2020-01-27 07:21:39 --> Config Class Initialized
INFO - 2020-01-27 07:21:39 --> Loader Class Initialized
INFO - 2020-01-27 07:21:39 --> Helper loaded: url_helper
INFO - 2020-01-27 07:21:39 --> Helper loaded: file_helper
INFO - 2020-01-27 07:21:40 --> Helper loaded: form_helper
INFO - 2020-01-27 07:21:40 --> Helper loaded: my_helper
INFO - 2020-01-27 07:21:40 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:21:40 --> Controller Class Initialized
INFO - 2020-01-27 07:21:40 --> Final output sent to browser
DEBUG - 2020-01-27 07:21:40 --> Total execution time: 0.4020
INFO - 2020-01-27 07:21:44 --> Config Class Initialized
INFO - 2020-01-27 07:21:44 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:21:44 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:21:44 --> Utf8 Class Initialized
INFO - 2020-01-27 07:21:45 --> URI Class Initialized
INFO - 2020-01-27 07:21:45 --> Router Class Initialized
INFO - 2020-01-27 07:21:45 --> Output Class Initialized
INFO - 2020-01-27 07:21:45 --> Security Class Initialized
DEBUG - 2020-01-27 07:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:21:45 --> Input Class Initialized
INFO - 2020-01-27 07:21:45 --> Language Class Initialized
INFO - 2020-01-27 07:21:45 --> Language Class Initialized
INFO - 2020-01-27 07:21:45 --> Config Class Initialized
INFO - 2020-01-27 07:21:45 --> Loader Class Initialized
INFO - 2020-01-27 07:21:45 --> Helper loaded: url_helper
INFO - 2020-01-27 07:21:45 --> Helper loaded: file_helper
INFO - 2020-01-27 07:21:45 --> Helper loaded: form_helper
INFO - 2020-01-27 07:21:45 --> Helper loaded: my_helper
INFO - 2020-01-27 07:21:45 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:21:45 --> Controller Class Initialized
INFO - 2020-01-27 07:21:45 --> Final output sent to browser
DEBUG - 2020-01-27 07:21:45 --> Total execution time: 0.5108
INFO - 2020-01-27 07:21:45 --> Config Class Initialized
INFO - 2020-01-27 07:21:45 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:21:45 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:21:45 --> Utf8 Class Initialized
INFO - 2020-01-27 07:21:45 --> URI Class Initialized
INFO - 2020-01-27 07:21:45 --> Router Class Initialized
INFO - 2020-01-27 07:21:45 --> Output Class Initialized
INFO - 2020-01-27 07:21:45 --> Security Class Initialized
DEBUG - 2020-01-27 07:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:21:45 --> Input Class Initialized
INFO - 2020-01-27 07:21:45 --> Language Class Initialized
INFO - 2020-01-27 07:21:45 --> Language Class Initialized
INFO - 2020-01-27 07:21:45 --> Config Class Initialized
INFO - 2020-01-27 07:21:45 --> Loader Class Initialized
INFO - 2020-01-27 07:21:45 --> Helper loaded: url_helper
INFO - 2020-01-27 07:21:45 --> Helper loaded: file_helper
INFO - 2020-01-27 07:21:45 --> Helper loaded: form_helper
INFO - 2020-01-27 07:21:45 --> Helper loaded: my_helper
INFO - 2020-01-27 07:21:45 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:21:45 --> Controller Class Initialized
INFO - 2020-01-27 07:21:47 --> Config Class Initialized
INFO - 2020-01-27 07:21:47 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:21:47 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:21:47 --> Utf8 Class Initialized
INFO - 2020-01-27 07:21:47 --> URI Class Initialized
INFO - 2020-01-27 07:21:47 --> Router Class Initialized
INFO - 2020-01-27 07:21:47 --> Output Class Initialized
INFO - 2020-01-27 07:21:47 --> Security Class Initialized
DEBUG - 2020-01-27 07:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:21:47 --> Input Class Initialized
INFO - 2020-01-27 07:21:47 --> Language Class Initialized
INFO - 2020-01-27 07:21:47 --> Language Class Initialized
INFO - 2020-01-27 07:21:47 --> Config Class Initialized
INFO - 2020-01-27 07:21:47 --> Loader Class Initialized
INFO - 2020-01-27 07:21:47 --> Helper loaded: url_helper
INFO - 2020-01-27 07:21:47 --> Helper loaded: file_helper
INFO - 2020-01-27 07:21:47 --> Helper loaded: form_helper
INFO - 2020-01-27 07:21:47 --> Helper loaded: my_helper
INFO - 2020-01-27 07:21:47 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:21:47 --> Controller Class Initialized
INFO - 2020-01-27 07:21:47 --> Final output sent to browser
DEBUG - 2020-01-27 07:21:47 --> Total execution time: 0.4861
INFO - 2020-01-27 07:21:47 --> Config Class Initialized
INFO - 2020-01-27 07:21:47 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:21:48 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:21:48 --> Utf8 Class Initialized
INFO - 2020-01-27 07:21:48 --> URI Class Initialized
INFO - 2020-01-27 07:21:48 --> Router Class Initialized
INFO - 2020-01-27 07:21:48 --> Output Class Initialized
INFO - 2020-01-27 07:21:48 --> Security Class Initialized
DEBUG - 2020-01-27 07:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:21:48 --> Input Class Initialized
INFO - 2020-01-27 07:21:48 --> Language Class Initialized
INFO - 2020-01-27 07:21:48 --> Language Class Initialized
INFO - 2020-01-27 07:21:48 --> Config Class Initialized
INFO - 2020-01-27 07:21:48 --> Loader Class Initialized
INFO - 2020-01-27 07:21:48 --> Helper loaded: url_helper
INFO - 2020-01-27 07:21:48 --> Helper loaded: file_helper
INFO - 2020-01-27 07:21:48 --> Helper loaded: form_helper
INFO - 2020-01-27 07:21:48 --> Helper loaded: my_helper
INFO - 2020-01-27 07:21:48 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:21:48 --> Controller Class Initialized
INFO - 2020-01-27 07:21:50 --> Config Class Initialized
INFO - 2020-01-27 07:21:50 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:21:50 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:21:50 --> Utf8 Class Initialized
INFO - 2020-01-27 07:21:50 --> URI Class Initialized
INFO - 2020-01-27 07:21:50 --> Router Class Initialized
INFO - 2020-01-27 07:21:50 --> Output Class Initialized
INFO - 2020-01-27 07:21:50 --> Security Class Initialized
DEBUG - 2020-01-27 07:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:21:50 --> Input Class Initialized
INFO - 2020-01-27 07:21:50 --> Language Class Initialized
INFO - 2020-01-27 07:21:50 --> Language Class Initialized
INFO - 2020-01-27 07:21:50 --> Config Class Initialized
INFO - 2020-01-27 07:21:50 --> Loader Class Initialized
INFO - 2020-01-27 07:21:50 --> Helper loaded: url_helper
INFO - 2020-01-27 07:21:50 --> Helper loaded: file_helper
INFO - 2020-01-27 07:21:50 --> Helper loaded: form_helper
INFO - 2020-01-27 07:21:50 --> Helper loaded: my_helper
INFO - 2020-01-27 07:21:50 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:21:50 --> Controller Class Initialized
INFO - 2020-01-27 07:21:50 --> Final output sent to browser
DEBUG - 2020-01-27 07:21:50 --> Total execution time: 0.4251
INFO - 2020-01-27 07:22:03 --> Config Class Initialized
INFO - 2020-01-27 07:22:03 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:22:03 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:22:03 --> Utf8 Class Initialized
INFO - 2020-01-27 07:22:03 --> URI Class Initialized
INFO - 2020-01-27 07:22:03 --> Router Class Initialized
INFO - 2020-01-27 07:22:03 --> Output Class Initialized
INFO - 2020-01-27 07:22:03 --> Security Class Initialized
DEBUG - 2020-01-27 07:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:22:03 --> Input Class Initialized
INFO - 2020-01-27 07:22:03 --> Language Class Initialized
INFO - 2020-01-27 07:22:03 --> Language Class Initialized
INFO - 2020-01-27 07:22:03 --> Config Class Initialized
INFO - 2020-01-27 07:22:03 --> Loader Class Initialized
INFO - 2020-01-27 07:22:03 --> Helper loaded: url_helper
INFO - 2020-01-27 07:22:03 --> Helper loaded: file_helper
INFO - 2020-01-27 07:22:03 --> Helper loaded: form_helper
INFO - 2020-01-27 07:22:03 --> Helper loaded: my_helper
INFO - 2020-01-27 07:22:03 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:22:03 --> Controller Class Initialized
INFO - 2020-01-27 07:22:03 --> Final output sent to browser
DEBUG - 2020-01-27 07:22:03 --> Total execution time: 0.3908
INFO - 2020-01-27 07:22:03 --> Config Class Initialized
INFO - 2020-01-27 07:22:03 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:22:03 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:22:03 --> Utf8 Class Initialized
INFO - 2020-01-27 07:22:04 --> URI Class Initialized
INFO - 2020-01-27 07:22:04 --> Router Class Initialized
INFO - 2020-01-27 07:22:04 --> Output Class Initialized
INFO - 2020-01-27 07:22:04 --> Security Class Initialized
DEBUG - 2020-01-27 07:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:22:04 --> Input Class Initialized
INFO - 2020-01-27 07:22:04 --> Language Class Initialized
INFO - 2020-01-27 07:22:04 --> Language Class Initialized
INFO - 2020-01-27 07:22:04 --> Config Class Initialized
INFO - 2020-01-27 07:22:04 --> Loader Class Initialized
INFO - 2020-01-27 07:22:04 --> Helper loaded: url_helper
INFO - 2020-01-27 07:22:04 --> Helper loaded: file_helper
INFO - 2020-01-27 07:22:04 --> Helper loaded: form_helper
INFO - 2020-01-27 07:22:04 --> Helper loaded: my_helper
INFO - 2020-01-27 07:22:04 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:22:04 --> Controller Class Initialized
INFO - 2020-01-27 07:22:10 --> Config Class Initialized
INFO - 2020-01-27 07:22:10 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:22:10 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:22:10 --> Utf8 Class Initialized
INFO - 2020-01-27 07:22:10 --> URI Class Initialized
INFO - 2020-01-27 07:22:10 --> Router Class Initialized
INFO - 2020-01-27 07:22:10 --> Output Class Initialized
INFO - 2020-01-27 07:22:10 --> Security Class Initialized
DEBUG - 2020-01-27 07:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:22:10 --> Input Class Initialized
INFO - 2020-01-27 07:22:10 --> Language Class Initialized
INFO - 2020-01-27 07:22:10 --> Language Class Initialized
INFO - 2020-01-27 07:22:10 --> Config Class Initialized
INFO - 2020-01-27 07:22:10 --> Loader Class Initialized
INFO - 2020-01-27 07:22:10 --> Helper loaded: url_helper
INFO - 2020-01-27 07:22:10 --> Helper loaded: file_helper
INFO - 2020-01-27 07:22:10 --> Helper loaded: form_helper
INFO - 2020-01-27 07:22:10 --> Helper loaded: my_helper
INFO - 2020-01-27 07:22:10 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:22:10 --> Controller Class Initialized
DEBUG - 2020-01-27 07:22:10 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-01-27 07:22:11 --> Final output sent to browser
DEBUG - 2020-01-27 07:22:11 --> Total execution time: 0.4793
INFO - 2020-01-27 07:22:26 --> Config Class Initialized
INFO - 2020-01-27 07:22:26 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:22:26 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:22:26 --> Utf8 Class Initialized
INFO - 2020-01-27 07:22:26 --> URI Class Initialized
INFO - 2020-01-27 07:22:26 --> Router Class Initialized
INFO - 2020-01-27 07:22:26 --> Output Class Initialized
INFO - 2020-01-27 07:22:26 --> Security Class Initialized
DEBUG - 2020-01-27 07:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:22:26 --> Input Class Initialized
INFO - 2020-01-27 07:22:26 --> Language Class Initialized
INFO - 2020-01-27 07:22:26 --> Language Class Initialized
INFO - 2020-01-27 07:22:26 --> Config Class Initialized
INFO - 2020-01-27 07:22:26 --> Loader Class Initialized
INFO - 2020-01-27 07:22:26 --> Helper loaded: url_helper
INFO - 2020-01-27 07:22:26 --> Helper loaded: file_helper
INFO - 2020-01-27 07:22:26 --> Helper loaded: form_helper
INFO - 2020-01-27 07:22:26 --> Helper loaded: my_helper
INFO - 2020-01-27 07:22:26 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:22:26 --> Controller Class Initialized
INFO - 2020-01-27 07:22:26 --> Final output sent to browser
DEBUG - 2020-01-27 07:22:26 --> Total execution time: 0.4462
INFO - 2020-01-27 07:22:26 --> Config Class Initialized
INFO - 2020-01-27 07:22:26 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:22:26 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:22:26 --> Utf8 Class Initialized
INFO - 2020-01-27 07:22:26 --> URI Class Initialized
INFO - 2020-01-27 07:22:26 --> Router Class Initialized
INFO - 2020-01-27 07:22:26 --> Output Class Initialized
INFO - 2020-01-27 07:22:26 --> Security Class Initialized
DEBUG - 2020-01-27 07:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:22:26 --> Input Class Initialized
INFO - 2020-01-27 07:22:26 --> Language Class Initialized
INFO - 2020-01-27 07:22:26 --> Language Class Initialized
INFO - 2020-01-27 07:22:26 --> Config Class Initialized
INFO - 2020-01-27 07:22:26 --> Loader Class Initialized
INFO - 2020-01-27 07:22:26 --> Helper loaded: url_helper
INFO - 2020-01-27 07:22:26 --> Helper loaded: file_helper
INFO - 2020-01-27 07:22:26 --> Helper loaded: form_helper
INFO - 2020-01-27 07:22:26 --> Helper loaded: my_helper
INFO - 2020-01-27 07:22:26 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:22:26 --> Controller Class Initialized
INFO - 2020-01-27 07:22:28 --> Config Class Initialized
INFO - 2020-01-27 07:22:28 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:22:28 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:22:28 --> Utf8 Class Initialized
INFO - 2020-01-27 07:22:28 --> URI Class Initialized
INFO - 2020-01-27 07:22:28 --> Router Class Initialized
INFO - 2020-01-27 07:22:28 --> Output Class Initialized
INFO - 2020-01-27 07:22:28 --> Security Class Initialized
DEBUG - 2020-01-27 07:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:22:28 --> Input Class Initialized
INFO - 2020-01-27 07:22:29 --> Language Class Initialized
INFO - 2020-01-27 07:22:29 --> Language Class Initialized
INFO - 2020-01-27 07:22:29 --> Config Class Initialized
INFO - 2020-01-27 07:22:29 --> Loader Class Initialized
INFO - 2020-01-27 07:22:29 --> Helper loaded: url_helper
INFO - 2020-01-27 07:22:29 --> Helper loaded: file_helper
INFO - 2020-01-27 07:22:29 --> Helper loaded: form_helper
INFO - 2020-01-27 07:22:29 --> Helper loaded: my_helper
INFO - 2020-01-27 07:22:29 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:22:29 --> Controller Class Initialized
DEBUG - 2020-01-27 07:22:29 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-01-27 07:22:29 --> Final output sent to browser
DEBUG - 2020-01-27 07:22:29 --> Total execution time: 0.4839
INFO - 2020-01-27 07:26:20 --> Config Class Initialized
INFO - 2020-01-27 07:26:20 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:26:20 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:26:20 --> Utf8 Class Initialized
INFO - 2020-01-27 07:26:20 --> URI Class Initialized
INFO - 2020-01-27 07:26:20 --> Router Class Initialized
INFO - 2020-01-27 07:26:20 --> Output Class Initialized
INFO - 2020-01-27 07:26:20 --> Security Class Initialized
DEBUG - 2020-01-27 07:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:26:20 --> Input Class Initialized
INFO - 2020-01-27 07:26:20 --> Language Class Initialized
INFO - 2020-01-27 07:26:20 --> Language Class Initialized
INFO - 2020-01-27 07:26:20 --> Config Class Initialized
INFO - 2020-01-27 07:26:20 --> Loader Class Initialized
INFO - 2020-01-27 07:26:20 --> Helper loaded: url_helper
INFO - 2020-01-27 07:26:20 --> Helper loaded: file_helper
INFO - 2020-01-27 07:26:20 --> Helper loaded: form_helper
INFO - 2020-01-27 07:26:20 --> Helper loaded: my_helper
INFO - 2020-01-27 07:26:20 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:26:20 --> Controller Class Initialized
INFO - 2020-01-27 07:26:22 --> Config Class Initialized
INFO - 2020-01-27 07:26:22 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:26:22 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:26:22 --> Utf8 Class Initialized
INFO - 2020-01-27 07:26:22 --> URI Class Initialized
INFO - 2020-01-27 07:26:23 --> Router Class Initialized
INFO - 2020-01-27 07:26:23 --> Output Class Initialized
INFO - 2020-01-27 07:26:23 --> Security Class Initialized
DEBUG - 2020-01-27 07:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:26:23 --> Input Class Initialized
INFO - 2020-01-27 07:26:23 --> Language Class Initialized
INFO - 2020-01-27 07:26:23 --> Language Class Initialized
INFO - 2020-01-27 07:26:23 --> Config Class Initialized
INFO - 2020-01-27 07:26:23 --> Loader Class Initialized
INFO - 2020-01-27 07:26:23 --> Helper loaded: url_helper
INFO - 2020-01-27 07:26:23 --> Helper loaded: file_helper
INFO - 2020-01-27 07:26:23 --> Helper loaded: form_helper
INFO - 2020-01-27 07:26:23 --> Helper loaded: my_helper
INFO - 2020-01-27 07:26:23 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:26:23 --> Controller Class Initialized
INFO - 2020-01-27 07:26:23 --> Final output sent to browser
DEBUG - 2020-01-27 07:26:23 --> Total execution time: 0.4384
INFO - 2020-01-27 07:26:28 --> Config Class Initialized
INFO - 2020-01-27 07:26:28 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:26:28 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:26:28 --> Utf8 Class Initialized
INFO - 2020-01-27 07:26:28 --> URI Class Initialized
INFO - 2020-01-27 07:26:28 --> Router Class Initialized
INFO - 2020-01-27 07:26:28 --> Output Class Initialized
INFO - 2020-01-27 07:26:28 --> Security Class Initialized
DEBUG - 2020-01-27 07:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:26:28 --> Input Class Initialized
INFO - 2020-01-27 07:26:28 --> Language Class Initialized
INFO - 2020-01-27 07:26:28 --> Language Class Initialized
INFO - 2020-01-27 07:26:28 --> Config Class Initialized
INFO - 2020-01-27 07:26:28 --> Loader Class Initialized
INFO - 2020-01-27 07:26:28 --> Helper loaded: url_helper
INFO - 2020-01-27 07:26:28 --> Helper loaded: file_helper
INFO - 2020-01-27 07:26:28 --> Helper loaded: form_helper
INFO - 2020-01-27 07:26:28 --> Helper loaded: my_helper
INFO - 2020-01-27 07:26:28 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:26:28 --> Controller Class Initialized
ERROR - 2020-01-27 07:26:28 --> Severity: Notice --> Undefined index: tambahan_sub E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\data_mapel\controllers\Data_mapel.php 83
INFO - 2020-01-27 07:26:28 --> Final output sent to browser
DEBUG - 2020-01-27 07:26:28 --> Total execution time: 0.4205
INFO - 2020-01-27 07:26:33 --> Config Class Initialized
INFO - 2020-01-27 07:26:33 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:26:33 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:26:33 --> Utf8 Class Initialized
INFO - 2020-01-27 07:26:33 --> URI Class Initialized
INFO - 2020-01-27 07:26:33 --> Router Class Initialized
INFO - 2020-01-27 07:26:33 --> Output Class Initialized
INFO - 2020-01-27 07:26:33 --> Security Class Initialized
DEBUG - 2020-01-27 07:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:26:33 --> Input Class Initialized
INFO - 2020-01-27 07:26:33 --> Language Class Initialized
INFO - 2020-01-27 07:26:33 --> Language Class Initialized
INFO - 2020-01-27 07:26:33 --> Config Class Initialized
INFO - 2020-01-27 07:26:33 --> Loader Class Initialized
INFO - 2020-01-27 07:26:33 --> Helper loaded: url_helper
INFO - 2020-01-27 07:26:33 --> Helper loaded: file_helper
INFO - 2020-01-27 07:26:33 --> Helper loaded: form_helper
INFO - 2020-01-27 07:26:33 --> Helper loaded: my_helper
INFO - 2020-01-27 07:26:33 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:26:33 --> Controller Class Initialized
ERROR - 2020-01-27 07:26:33 --> Severity: Notice --> Undefined index: tambahan_sub E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\data_mapel\controllers\Data_mapel.php 83
INFO - 2020-01-27 07:26:33 --> Final output sent to browser
DEBUG - 2020-01-27 07:26:33 --> Total execution time: 0.4047
INFO - 2020-01-27 07:26:43 --> Config Class Initialized
INFO - 2020-01-27 07:26:43 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:26:43 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:26:43 --> Utf8 Class Initialized
INFO - 2020-01-27 07:26:43 --> URI Class Initialized
INFO - 2020-01-27 07:26:43 --> Router Class Initialized
INFO - 2020-01-27 07:26:43 --> Output Class Initialized
INFO - 2020-01-27 07:26:43 --> Security Class Initialized
DEBUG - 2020-01-27 07:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:26:43 --> Input Class Initialized
INFO - 2020-01-27 07:26:43 --> Language Class Initialized
INFO - 2020-01-27 07:26:43 --> Language Class Initialized
INFO - 2020-01-27 07:26:43 --> Config Class Initialized
INFO - 2020-01-27 07:26:43 --> Loader Class Initialized
INFO - 2020-01-27 07:26:43 --> Helper loaded: url_helper
INFO - 2020-01-27 07:26:43 --> Helper loaded: file_helper
INFO - 2020-01-27 07:26:43 --> Helper loaded: form_helper
INFO - 2020-01-27 07:26:43 --> Helper loaded: my_helper
INFO - 2020-01-27 07:26:43 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:26:43 --> Controller Class Initialized
INFO - 2020-01-27 07:26:50 --> Config Class Initialized
INFO - 2020-01-27 07:26:50 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:26:50 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:26:50 --> Utf8 Class Initialized
INFO - 2020-01-27 07:26:50 --> URI Class Initialized
INFO - 2020-01-27 07:26:50 --> Router Class Initialized
INFO - 2020-01-27 07:26:50 --> Output Class Initialized
INFO - 2020-01-27 07:26:50 --> Security Class Initialized
DEBUG - 2020-01-27 07:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:26:50 --> Input Class Initialized
INFO - 2020-01-27 07:26:50 --> Language Class Initialized
INFO - 2020-01-27 07:26:50 --> Language Class Initialized
INFO - 2020-01-27 07:26:50 --> Config Class Initialized
INFO - 2020-01-27 07:26:50 --> Loader Class Initialized
INFO - 2020-01-27 07:26:50 --> Helper loaded: url_helper
INFO - 2020-01-27 07:26:50 --> Helper loaded: file_helper
INFO - 2020-01-27 07:26:50 --> Helper loaded: form_helper
INFO - 2020-01-27 07:26:50 --> Helper loaded: my_helper
INFO - 2020-01-27 07:26:50 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:26:50 --> Controller Class Initialized
INFO - 2020-01-27 07:39:07 --> Config Class Initialized
INFO - 2020-01-27 07:39:07 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:39:07 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:39:07 --> Utf8 Class Initialized
INFO - 2020-01-27 07:39:07 --> URI Class Initialized
INFO - 2020-01-27 07:39:07 --> Router Class Initialized
INFO - 2020-01-27 07:39:07 --> Output Class Initialized
INFO - 2020-01-27 07:39:07 --> Security Class Initialized
DEBUG - 2020-01-27 07:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:39:07 --> Input Class Initialized
INFO - 2020-01-27 07:39:07 --> Language Class Initialized
INFO - 2020-01-27 07:39:07 --> Language Class Initialized
INFO - 2020-01-27 07:39:07 --> Config Class Initialized
INFO - 2020-01-27 07:39:07 --> Loader Class Initialized
INFO - 2020-01-27 07:39:07 --> Helper loaded: url_helper
INFO - 2020-01-27 07:39:07 --> Helper loaded: file_helper
INFO - 2020-01-27 07:39:07 --> Helper loaded: form_helper
INFO - 2020-01-27 07:39:07 --> Helper loaded: my_helper
INFO - 2020-01-27 07:39:07 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:39:07 --> Controller Class Initialized
INFO - 2020-01-27 07:39:09 --> Config Class Initialized
INFO - 2020-01-27 07:39:09 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:39:09 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:39:09 --> Utf8 Class Initialized
INFO - 2020-01-27 07:39:09 --> URI Class Initialized
INFO - 2020-01-27 07:39:09 --> Router Class Initialized
INFO - 2020-01-27 07:39:09 --> Output Class Initialized
INFO - 2020-01-27 07:39:09 --> Security Class Initialized
DEBUG - 2020-01-27 07:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:39:09 --> Input Class Initialized
INFO - 2020-01-27 07:39:09 --> Language Class Initialized
INFO - 2020-01-27 07:39:09 --> Language Class Initialized
INFO - 2020-01-27 07:39:09 --> Config Class Initialized
INFO - 2020-01-27 07:39:09 --> Loader Class Initialized
INFO - 2020-01-27 07:39:09 --> Helper loaded: url_helper
INFO - 2020-01-27 07:39:09 --> Helper loaded: file_helper
INFO - 2020-01-27 07:39:09 --> Helper loaded: form_helper
INFO - 2020-01-27 07:39:09 --> Helper loaded: my_helper
INFO - 2020-01-27 07:39:09 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:39:09 --> Controller Class Initialized
INFO - 2020-01-27 07:39:11 --> Config Class Initialized
INFO - 2020-01-27 07:39:11 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:39:11 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:39:11 --> Utf8 Class Initialized
INFO - 2020-01-27 07:39:11 --> URI Class Initialized
INFO - 2020-01-27 07:39:11 --> Router Class Initialized
INFO - 2020-01-27 07:39:11 --> Output Class Initialized
INFO - 2020-01-27 07:39:11 --> Security Class Initialized
DEBUG - 2020-01-27 07:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:39:11 --> Input Class Initialized
INFO - 2020-01-27 07:39:11 --> Language Class Initialized
INFO - 2020-01-27 07:39:11 --> Language Class Initialized
INFO - 2020-01-27 07:39:11 --> Config Class Initialized
INFO - 2020-01-27 07:39:11 --> Loader Class Initialized
INFO - 2020-01-27 07:39:11 --> Helper loaded: url_helper
INFO - 2020-01-27 07:39:11 --> Helper loaded: file_helper
INFO - 2020-01-27 07:39:11 --> Helper loaded: form_helper
INFO - 2020-01-27 07:39:11 --> Helper loaded: my_helper
INFO - 2020-01-27 07:39:11 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:39:11 --> Controller Class Initialized
INFO - 2020-01-27 07:39:11 --> Final output sent to browser
DEBUG - 2020-01-27 07:39:11 --> Total execution time: 0.4264
INFO - 2020-01-27 07:39:16 --> Config Class Initialized
INFO - 2020-01-27 07:39:16 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:39:16 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:39:16 --> Utf8 Class Initialized
INFO - 2020-01-27 07:39:16 --> URI Class Initialized
INFO - 2020-01-27 07:39:16 --> Router Class Initialized
INFO - 2020-01-27 07:39:16 --> Output Class Initialized
INFO - 2020-01-27 07:39:16 --> Security Class Initialized
DEBUG - 2020-01-27 07:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:39:16 --> Input Class Initialized
INFO - 2020-01-27 07:39:16 --> Language Class Initialized
INFO - 2020-01-27 07:39:16 --> Language Class Initialized
INFO - 2020-01-27 07:39:16 --> Config Class Initialized
INFO - 2020-01-27 07:39:16 --> Loader Class Initialized
INFO - 2020-01-27 07:39:16 --> Helper loaded: url_helper
INFO - 2020-01-27 07:39:16 --> Helper loaded: file_helper
INFO - 2020-01-27 07:39:16 --> Helper loaded: form_helper
INFO - 2020-01-27 07:39:16 --> Helper loaded: my_helper
INFO - 2020-01-27 07:39:16 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:39:16 --> Controller Class Initialized
INFO - 2020-01-27 07:39:16 --> Final output sent to browser
DEBUG - 2020-01-27 07:39:16 --> Total execution time: 0.4023
INFO - 2020-01-27 07:39:16 --> Config Class Initialized
INFO - 2020-01-27 07:39:16 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:39:16 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:39:16 --> Utf8 Class Initialized
INFO - 2020-01-27 07:39:16 --> URI Class Initialized
INFO - 2020-01-27 07:39:16 --> Router Class Initialized
INFO - 2020-01-27 07:39:16 --> Output Class Initialized
INFO - 2020-01-27 07:39:16 --> Security Class Initialized
DEBUG - 2020-01-27 07:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:39:16 --> Input Class Initialized
INFO - 2020-01-27 07:39:16 --> Language Class Initialized
INFO - 2020-01-27 07:39:16 --> Language Class Initialized
INFO - 2020-01-27 07:39:16 --> Config Class Initialized
INFO - 2020-01-27 07:39:16 --> Loader Class Initialized
INFO - 2020-01-27 07:39:16 --> Helper loaded: url_helper
INFO - 2020-01-27 07:39:16 --> Helper loaded: file_helper
INFO - 2020-01-27 07:39:16 --> Helper loaded: form_helper
INFO - 2020-01-27 07:39:16 --> Helper loaded: my_helper
INFO - 2020-01-27 07:39:16 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:39:16 --> Controller Class Initialized
INFO - 2020-01-27 07:39:26 --> Config Class Initialized
INFO - 2020-01-27 07:39:26 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:39:26 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:39:26 --> Utf8 Class Initialized
INFO - 2020-01-27 07:39:26 --> URI Class Initialized
INFO - 2020-01-27 07:39:26 --> Router Class Initialized
INFO - 2020-01-27 07:39:26 --> Output Class Initialized
INFO - 2020-01-27 07:39:26 --> Security Class Initialized
DEBUG - 2020-01-27 07:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:39:26 --> Input Class Initialized
INFO - 2020-01-27 07:39:26 --> Language Class Initialized
INFO - 2020-01-27 07:39:26 --> Language Class Initialized
INFO - 2020-01-27 07:39:26 --> Config Class Initialized
INFO - 2020-01-27 07:39:26 --> Loader Class Initialized
INFO - 2020-01-27 07:39:26 --> Helper loaded: url_helper
INFO - 2020-01-27 07:39:26 --> Helper loaded: file_helper
INFO - 2020-01-27 07:39:26 --> Helper loaded: form_helper
INFO - 2020-01-27 07:39:26 --> Helper loaded: my_helper
INFO - 2020-01-27 07:39:26 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:39:26 --> Controller Class Initialized
INFO - 2020-01-27 07:39:26 --> Final output sent to browser
DEBUG - 2020-01-27 07:39:26 --> Total execution time: 0.4332
INFO - 2020-01-27 07:39:30 --> Config Class Initialized
INFO - 2020-01-27 07:39:30 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:39:30 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:39:30 --> Utf8 Class Initialized
INFO - 2020-01-27 07:39:30 --> URI Class Initialized
INFO - 2020-01-27 07:39:30 --> Router Class Initialized
INFO - 2020-01-27 07:39:30 --> Output Class Initialized
INFO - 2020-01-27 07:39:30 --> Security Class Initialized
DEBUG - 2020-01-27 07:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:39:30 --> Input Class Initialized
INFO - 2020-01-27 07:39:30 --> Language Class Initialized
INFO - 2020-01-27 07:39:30 --> Language Class Initialized
INFO - 2020-01-27 07:39:30 --> Config Class Initialized
INFO - 2020-01-27 07:39:30 --> Loader Class Initialized
INFO - 2020-01-27 07:39:30 --> Helper loaded: url_helper
INFO - 2020-01-27 07:39:30 --> Helper loaded: file_helper
INFO - 2020-01-27 07:39:30 --> Helper loaded: form_helper
INFO - 2020-01-27 07:39:30 --> Helper loaded: my_helper
INFO - 2020-01-27 07:39:30 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:39:30 --> Controller Class Initialized
INFO - 2020-01-27 07:39:30 --> Final output sent to browser
DEBUG - 2020-01-27 07:39:30 --> Total execution time: 0.4181
INFO - 2020-01-27 07:39:30 --> Config Class Initialized
INFO - 2020-01-27 07:39:30 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:39:30 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:39:30 --> Utf8 Class Initialized
INFO - 2020-01-27 07:39:30 --> URI Class Initialized
INFO - 2020-01-27 07:39:30 --> Router Class Initialized
INFO - 2020-01-27 07:39:30 --> Output Class Initialized
INFO - 2020-01-27 07:39:30 --> Security Class Initialized
DEBUG - 2020-01-27 07:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:39:30 --> Input Class Initialized
INFO - 2020-01-27 07:39:31 --> Language Class Initialized
INFO - 2020-01-27 07:39:31 --> Language Class Initialized
INFO - 2020-01-27 07:39:31 --> Config Class Initialized
INFO - 2020-01-27 07:39:31 --> Loader Class Initialized
INFO - 2020-01-27 07:39:31 --> Helper loaded: url_helper
INFO - 2020-01-27 07:39:31 --> Helper loaded: file_helper
INFO - 2020-01-27 07:39:31 --> Helper loaded: form_helper
INFO - 2020-01-27 07:39:31 --> Helper loaded: my_helper
INFO - 2020-01-27 07:39:31 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:39:31 --> Controller Class Initialized
INFO - 2020-01-27 07:39:36 --> Config Class Initialized
INFO - 2020-01-27 07:39:36 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:39:36 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:39:36 --> Utf8 Class Initialized
INFO - 2020-01-27 07:39:36 --> URI Class Initialized
INFO - 2020-01-27 07:39:36 --> Router Class Initialized
INFO - 2020-01-27 07:39:36 --> Output Class Initialized
INFO - 2020-01-27 07:39:36 --> Security Class Initialized
DEBUG - 2020-01-27 07:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:39:36 --> Input Class Initialized
INFO - 2020-01-27 07:39:36 --> Language Class Initialized
INFO - 2020-01-27 07:39:36 --> Language Class Initialized
INFO - 2020-01-27 07:39:36 --> Config Class Initialized
INFO - 2020-01-27 07:39:37 --> Loader Class Initialized
INFO - 2020-01-27 07:39:37 --> Helper loaded: url_helper
INFO - 2020-01-27 07:39:37 --> Helper loaded: file_helper
INFO - 2020-01-27 07:39:37 --> Helper loaded: form_helper
INFO - 2020-01-27 07:39:37 --> Helper loaded: my_helper
INFO - 2020-01-27 07:39:37 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:39:37 --> Controller Class Initialized
INFO - 2020-01-27 07:39:37 --> Final output sent to browser
DEBUG - 2020-01-27 07:39:37 --> Total execution time: 0.4752
INFO - 2020-01-27 07:39:40 --> Config Class Initialized
INFO - 2020-01-27 07:39:40 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:39:40 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:39:40 --> Utf8 Class Initialized
INFO - 2020-01-27 07:39:40 --> URI Class Initialized
INFO - 2020-01-27 07:39:40 --> Router Class Initialized
INFO - 2020-01-27 07:39:40 --> Output Class Initialized
INFO - 2020-01-27 07:39:40 --> Security Class Initialized
DEBUG - 2020-01-27 07:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:39:40 --> Input Class Initialized
INFO - 2020-01-27 07:39:40 --> Language Class Initialized
INFO - 2020-01-27 07:39:40 --> Language Class Initialized
INFO - 2020-01-27 07:39:40 --> Config Class Initialized
INFO - 2020-01-27 07:39:40 --> Loader Class Initialized
INFO - 2020-01-27 07:39:40 --> Helper loaded: url_helper
INFO - 2020-01-27 07:39:40 --> Helper loaded: file_helper
INFO - 2020-01-27 07:39:40 --> Helper loaded: form_helper
INFO - 2020-01-27 07:39:40 --> Helper loaded: my_helper
INFO - 2020-01-27 07:39:40 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:39:40 --> Controller Class Initialized
INFO - 2020-01-27 07:39:40 --> Final output sent to browser
DEBUG - 2020-01-27 07:39:40 --> Total execution time: 0.4156
INFO - 2020-01-27 07:39:40 --> Config Class Initialized
INFO - 2020-01-27 07:39:40 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:39:40 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:39:41 --> Utf8 Class Initialized
INFO - 2020-01-27 07:39:41 --> URI Class Initialized
INFO - 2020-01-27 07:39:41 --> Router Class Initialized
INFO - 2020-01-27 07:39:41 --> Output Class Initialized
INFO - 2020-01-27 07:39:41 --> Security Class Initialized
DEBUG - 2020-01-27 07:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:39:41 --> Input Class Initialized
INFO - 2020-01-27 07:39:41 --> Language Class Initialized
INFO - 2020-01-27 07:39:41 --> Language Class Initialized
INFO - 2020-01-27 07:39:41 --> Config Class Initialized
INFO - 2020-01-27 07:39:41 --> Loader Class Initialized
INFO - 2020-01-27 07:39:41 --> Helper loaded: url_helper
INFO - 2020-01-27 07:39:41 --> Helper loaded: file_helper
INFO - 2020-01-27 07:39:41 --> Helper loaded: form_helper
INFO - 2020-01-27 07:39:41 --> Helper loaded: my_helper
INFO - 2020-01-27 07:39:41 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:39:41 --> Controller Class Initialized
INFO - 2020-01-27 07:39:46 --> Config Class Initialized
INFO - 2020-01-27 07:39:46 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:39:46 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:39:46 --> Utf8 Class Initialized
INFO - 2020-01-27 07:39:46 --> URI Class Initialized
INFO - 2020-01-27 07:39:46 --> Router Class Initialized
INFO - 2020-01-27 07:39:46 --> Output Class Initialized
INFO - 2020-01-27 07:39:46 --> Security Class Initialized
DEBUG - 2020-01-27 07:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:39:46 --> Input Class Initialized
INFO - 2020-01-27 07:39:46 --> Language Class Initialized
INFO - 2020-01-27 07:39:46 --> Language Class Initialized
INFO - 2020-01-27 07:39:46 --> Config Class Initialized
INFO - 2020-01-27 07:39:46 --> Loader Class Initialized
INFO - 2020-01-27 07:39:46 --> Helper loaded: url_helper
INFO - 2020-01-27 07:39:46 --> Helper loaded: file_helper
INFO - 2020-01-27 07:39:46 --> Helper loaded: form_helper
INFO - 2020-01-27 07:39:46 --> Helper loaded: my_helper
INFO - 2020-01-27 07:39:46 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:39:46 --> Controller Class Initialized
INFO - 2020-01-27 07:39:46 --> Final output sent to browser
DEBUG - 2020-01-27 07:39:46 --> Total execution time: 0.4309
INFO - 2020-01-27 07:39:49 --> Config Class Initialized
INFO - 2020-01-27 07:39:49 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:39:49 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:39:49 --> Utf8 Class Initialized
INFO - 2020-01-27 07:39:49 --> URI Class Initialized
INFO - 2020-01-27 07:39:49 --> Router Class Initialized
INFO - 2020-01-27 07:39:49 --> Output Class Initialized
INFO - 2020-01-27 07:39:49 --> Security Class Initialized
DEBUG - 2020-01-27 07:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:39:49 --> Input Class Initialized
INFO - 2020-01-27 07:39:49 --> Language Class Initialized
INFO - 2020-01-27 07:39:49 --> Language Class Initialized
INFO - 2020-01-27 07:39:49 --> Config Class Initialized
INFO - 2020-01-27 07:39:49 --> Loader Class Initialized
INFO - 2020-01-27 07:39:49 --> Helper loaded: url_helper
INFO - 2020-01-27 07:39:50 --> Helper loaded: file_helper
INFO - 2020-01-27 07:39:50 --> Helper loaded: form_helper
INFO - 2020-01-27 07:39:50 --> Helper loaded: my_helper
INFO - 2020-01-27 07:39:50 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:39:50 --> Controller Class Initialized
INFO - 2020-01-27 07:39:50 --> Final output sent to browser
DEBUG - 2020-01-27 07:39:50 --> Total execution time: 0.4084
INFO - 2020-01-27 07:39:50 --> Config Class Initialized
INFO - 2020-01-27 07:39:50 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:39:50 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:39:50 --> Utf8 Class Initialized
INFO - 2020-01-27 07:39:50 --> URI Class Initialized
INFO - 2020-01-27 07:39:50 --> Router Class Initialized
INFO - 2020-01-27 07:39:50 --> Output Class Initialized
INFO - 2020-01-27 07:39:50 --> Security Class Initialized
DEBUG - 2020-01-27 07:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:39:50 --> Input Class Initialized
INFO - 2020-01-27 07:39:50 --> Language Class Initialized
INFO - 2020-01-27 07:39:50 --> Language Class Initialized
INFO - 2020-01-27 07:39:50 --> Config Class Initialized
INFO - 2020-01-27 07:39:50 --> Loader Class Initialized
INFO - 2020-01-27 07:39:50 --> Helper loaded: url_helper
INFO - 2020-01-27 07:39:50 --> Helper loaded: file_helper
INFO - 2020-01-27 07:39:50 --> Helper loaded: form_helper
INFO - 2020-01-27 07:39:50 --> Helper loaded: my_helper
INFO - 2020-01-27 07:39:50 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:39:50 --> Controller Class Initialized
INFO - 2020-01-27 07:39:56 --> Config Class Initialized
INFO - 2020-01-27 07:39:56 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:39:56 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:39:56 --> Utf8 Class Initialized
INFO - 2020-01-27 07:39:56 --> URI Class Initialized
INFO - 2020-01-27 07:39:56 --> Router Class Initialized
INFO - 2020-01-27 07:39:56 --> Output Class Initialized
INFO - 2020-01-27 07:39:56 --> Security Class Initialized
DEBUG - 2020-01-27 07:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:39:56 --> Input Class Initialized
INFO - 2020-01-27 07:39:56 --> Language Class Initialized
INFO - 2020-01-27 07:39:56 --> Language Class Initialized
INFO - 2020-01-27 07:39:56 --> Config Class Initialized
INFO - 2020-01-27 07:39:56 --> Loader Class Initialized
INFO - 2020-01-27 07:39:56 --> Helper loaded: url_helper
INFO - 2020-01-27 07:39:56 --> Helper loaded: file_helper
INFO - 2020-01-27 07:39:56 --> Helper loaded: form_helper
INFO - 2020-01-27 07:39:56 --> Helper loaded: my_helper
INFO - 2020-01-27 07:39:56 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:39:56 --> Controller Class Initialized
INFO - 2020-01-27 07:39:56 --> Final output sent to browser
DEBUG - 2020-01-27 07:39:56 --> Total execution time: 0.4517
INFO - 2020-01-27 07:39:59 --> Config Class Initialized
INFO - 2020-01-27 07:39:59 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:39:59 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:39:59 --> Utf8 Class Initialized
INFO - 2020-01-27 07:39:59 --> URI Class Initialized
INFO - 2020-01-27 07:39:59 --> Router Class Initialized
INFO - 2020-01-27 07:40:00 --> Output Class Initialized
INFO - 2020-01-27 07:40:00 --> Security Class Initialized
DEBUG - 2020-01-27 07:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:40:00 --> Input Class Initialized
INFO - 2020-01-27 07:40:00 --> Language Class Initialized
INFO - 2020-01-27 07:40:00 --> Language Class Initialized
INFO - 2020-01-27 07:40:00 --> Config Class Initialized
INFO - 2020-01-27 07:40:00 --> Loader Class Initialized
INFO - 2020-01-27 07:40:00 --> Helper loaded: url_helper
INFO - 2020-01-27 07:40:00 --> Helper loaded: file_helper
INFO - 2020-01-27 07:40:00 --> Helper loaded: form_helper
INFO - 2020-01-27 07:40:00 --> Helper loaded: my_helper
INFO - 2020-01-27 07:40:00 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:40:00 --> Controller Class Initialized
INFO - 2020-01-27 07:40:00 --> Final output sent to browser
DEBUG - 2020-01-27 07:40:00 --> Total execution time: 0.4192
INFO - 2020-01-27 07:40:00 --> Config Class Initialized
INFO - 2020-01-27 07:40:00 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:40:00 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:40:00 --> Utf8 Class Initialized
INFO - 2020-01-27 07:40:00 --> URI Class Initialized
INFO - 2020-01-27 07:40:00 --> Router Class Initialized
INFO - 2020-01-27 07:40:00 --> Output Class Initialized
INFO - 2020-01-27 07:40:00 --> Security Class Initialized
DEBUG - 2020-01-27 07:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:40:00 --> Input Class Initialized
INFO - 2020-01-27 07:40:00 --> Language Class Initialized
INFO - 2020-01-27 07:40:00 --> Language Class Initialized
INFO - 2020-01-27 07:40:00 --> Config Class Initialized
INFO - 2020-01-27 07:40:00 --> Loader Class Initialized
INFO - 2020-01-27 07:40:00 --> Helper loaded: url_helper
INFO - 2020-01-27 07:40:00 --> Helper loaded: file_helper
INFO - 2020-01-27 07:40:00 --> Helper loaded: form_helper
INFO - 2020-01-27 07:40:00 --> Helper loaded: my_helper
INFO - 2020-01-27 07:40:00 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:40:00 --> Controller Class Initialized
INFO - 2020-01-27 07:40:07 --> Config Class Initialized
INFO - 2020-01-27 07:40:07 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:40:07 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:40:07 --> Utf8 Class Initialized
INFO - 2020-01-27 07:40:07 --> URI Class Initialized
INFO - 2020-01-27 07:40:07 --> Router Class Initialized
INFO - 2020-01-27 07:40:07 --> Output Class Initialized
INFO - 2020-01-27 07:40:07 --> Security Class Initialized
DEBUG - 2020-01-27 07:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:40:07 --> Input Class Initialized
INFO - 2020-01-27 07:40:07 --> Language Class Initialized
INFO - 2020-01-27 07:40:07 --> Language Class Initialized
INFO - 2020-01-27 07:40:07 --> Config Class Initialized
INFO - 2020-01-27 07:40:07 --> Loader Class Initialized
INFO - 2020-01-27 07:40:07 --> Helper loaded: url_helper
INFO - 2020-01-27 07:40:07 --> Helper loaded: file_helper
INFO - 2020-01-27 07:40:07 --> Helper loaded: form_helper
INFO - 2020-01-27 07:40:07 --> Helper loaded: my_helper
INFO - 2020-01-27 07:40:07 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:40:07 --> Controller Class Initialized
INFO - 2020-01-27 07:40:07 --> Final output sent to browser
DEBUG - 2020-01-27 07:40:07 --> Total execution time: 0.4795
INFO - 2020-01-27 07:40:11 --> Config Class Initialized
INFO - 2020-01-27 07:40:11 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:40:11 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:40:11 --> Utf8 Class Initialized
INFO - 2020-01-27 07:40:11 --> URI Class Initialized
INFO - 2020-01-27 07:40:11 --> Router Class Initialized
INFO - 2020-01-27 07:40:11 --> Output Class Initialized
INFO - 2020-01-27 07:40:11 --> Security Class Initialized
DEBUG - 2020-01-27 07:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:40:11 --> Input Class Initialized
INFO - 2020-01-27 07:40:11 --> Language Class Initialized
INFO - 2020-01-27 07:40:11 --> Language Class Initialized
INFO - 2020-01-27 07:40:11 --> Config Class Initialized
INFO - 2020-01-27 07:40:11 --> Loader Class Initialized
INFO - 2020-01-27 07:40:11 --> Helper loaded: url_helper
INFO - 2020-01-27 07:40:11 --> Helper loaded: file_helper
INFO - 2020-01-27 07:40:11 --> Helper loaded: form_helper
INFO - 2020-01-27 07:40:11 --> Helper loaded: my_helper
INFO - 2020-01-27 07:40:11 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:40:11 --> Controller Class Initialized
INFO - 2020-01-27 07:40:11 --> Final output sent to browser
DEBUG - 2020-01-27 07:40:11 --> Total execution time: 0.4145
INFO - 2020-01-27 07:40:11 --> Config Class Initialized
INFO - 2020-01-27 07:40:11 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:40:11 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:40:11 --> Utf8 Class Initialized
INFO - 2020-01-27 07:40:11 --> URI Class Initialized
INFO - 2020-01-27 07:40:11 --> Router Class Initialized
INFO - 2020-01-27 07:40:11 --> Output Class Initialized
INFO - 2020-01-27 07:40:11 --> Security Class Initialized
DEBUG - 2020-01-27 07:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:40:11 --> Input Class Initialized
INFO - 2020-01-27 07:40:11 --> Language Class Initialized
INFO - 2020-01-27 07:40:11 --> Language Class Initialized
INFO - 2020-01-27 07:40:11 --> Config Class Initialized
INFO - 2020-01-27 07:40:11 --> Loader Class Initialized
INFO - 2020-01-27 07:40:11 --> Helper loaded: url_helper
INFO - 2020-01-27 07:40:11 --> Helper loaded: file_helper
INFO - 2020-01-27 07:40:11 --> Helper loaded: form_helper
INFO - 2020-01-27 07:40:11 --> Helper loaded: my_helper
INFO - 2020-01-27 07:40:11 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:40:12 --> Controller Class Initialized
INFO - 2020-01-27 07:40:25 --> Config Class Initialized
INFO - 2020-01-27 07:40:25 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:40:25 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:40:25 --> Utf8 Class Initialized
INFO - 2020-01-27 07:40:25 --> URI Class Initialized
INFO - 2020-01-27 07:40:25 --> Router Class Initialized
INFO - 2020-01-27 07:40:25 --> Output Class Initialized
INFO - 2020-01-27 07:40:25 --> Security Class Initialized
DEBUG - 2020-01-27 07:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:40:25 --> Input Class Initialized
INFO - 2020-01-27 07:40:25 --> Language Class Initialized
INFO - 2020-01-27 07:40:25 --> Language Class Initialized
INFO - 2020-01-27 07:40:25 --> Config Class Initialized
INFO - 2020-01-27 07:40:25 --> Loader Class Initialized
INFO - 2020-01-27 07:40:25 --> Helper loaded: url_helper
INFO - 2020-01-27 07:40:25 --> Helper loaded: file_helper
INFO - 2020-01-27 07:40:25 --> Helper loaded: form_helper
INFO - 2020-01-27 07:40:25 --> Helper loaded: my_helper
INFO - 2020-01-27 07:40:25 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:40:25 --> Controller Class Initialized
INFO - 2020-01-27 07:40:25 --> Final output sent to browser
DEBUG - 2020-01-27 07:40:25 --> Total execution time: 0.4482
INFO - 2020-01-27 07:40:28 --> Config Class Initialized
INFO - 2020-01-27 07:40:28 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:40:28 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:40:28 --> Utf8 Class Initialized
INFO - 2020-01-27 07:40:28 --> URI Class Initialized
INFO - 2020-01-27 07:40:28 --> Router Class Initialized
INFO - 2020-01-27 07:40:28 --> Output Class Initialized
INFO - 2020-01-27 07:40:28 --> Security Class Initialized
DEBUG - 2020-01-27 07:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:40:28 --> Input Class Initialized
INFO - 2020-01-27 07:40:28 --> Language Class Initialized
INFO - 2020-01-27 07:40:28 --> Language Class Initialized
INFO - 2020-01-27 07:40:28 --> Config Class Initialized
INFO - 2020-01-27 07:40:28 --> Loader Class Initialized
INFO - 2020-01-27 07:40:28 --> Helper loaded: url_helper
INFO - 2020-01-27 07:40:28 --> Helper loaded: file_helper
INFO - 2020-01-27 07:40:28 --> Helper loaded: form_helper
INFO - 2020-01-27 07:40:28 --> Helper loaded: my_helper
INFO - 2020-01-27 07:40:29 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:40:29 --> Controller Class Initialized
INFO - 2020-01-27 07:40:29 --> Final output sent to browser
DEBUG - 2020-01-27 07:40:29 --> Total execution time: 0.4078
INFO - 2020-01-27 07:40:29 --> Config Class Initialized
INFO - 2020-01-27 07:40:29 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:40:29 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:40:29 --> Utf8 Class Initialized
INFO - 2020-01-27 07:40:29 --> URI Class Initialized
INFO - 2020-01-27 07:40:29 --> Router Class Initialized
INFO - 2020-01-27 07:40:29 --> Output Class Initialized
INFO - 2020-01-27 07:40:29 --> Security Class Initialized
DEBUG - 2020-01-27 07:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:40:29 --> Input Class Initialized
INFO - 2020-01-27 07:40:29 --> Language Class Initialized
INFO - 2020-01-27 07:40:29 --> Language Class Initialized
INFO - 2020-01-27 07:40:29 --> Config Class Initialized
INFO - 2020-01-27 07:40:29 --> Loader Class Initialized
INFO - 2020-01-27 07:40:29 --> Helper loaded: url_helper
INFO - 2020-01-27 07:40:29 --> Helper loaded: file_helper
INFO - 2020-01-27 07:40:29 --> Helper loaded: form_helper
INFO - 2020-01-27 07:40:29 --> Helper loaded: my_helper
INFO - 2020-01-27 07:40:29 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:40:29 --> Controller Class Initialized
INFO - 2020-01-27 07:40:34 --> Config Class Initialized
INFO - 2020-01-27 07:40:34 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:40:34 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:40:34 --> Utf8 Class Initialized
INFO - 2020-01-27 07:40:34 --> URI Class Initialized
INFO - 2020-01-27 07:40:34 --> Router Class Initialized
INFO - 2020-01-27 07:40:34 --> Output Class Initialized
INFO - 2020-01-27 07:40:34 --> Security Class Initialized
DEBUG - 2020-01-27 07:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:40:34 --> Input Class Initialized
INFO - 2020-01-27 07:40:34 --> Language Class Initialized
INFO - 2020-01-27 07:40:34 --> Language Class Initialized
INFO - 2020-01-27 07:40:34 --> Config Class Initialized
INFO - 2020-01-27 07:40:34 --> Loader Class Initialized
INFO - 2020-01-27 07:40:34 --> Helper loaded: url_helper
INFO - 2020-01-27 07:40:34 --> Helper loaded: file_helper
INFO - 2020-01-27 07:40:34 --> Helper loaded: form_helper
INFO - 2020-01-27 07:40:34 --> Helper loaded: my_helper
INFO - 2020-01-27 07:40:34 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:40:34 --> Controller Class Initialized
INFO - 2020-01-27 07:40:34 --> Final output sent to browser
DEBUG - 2020-01-27 07:40:34 --> Total execution time: 0.4293
INFO - 2020-01-27 07:40:38 --> Config Class Initialized
INFO - 2020-01-27 07:40:38 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:40:38 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:40:38 --> Utf8 Class Initialized
INFO - 2020-01-27 07:40:38 --> URI Class Initialized
INFO - 2020-01-27 07:40:38 --> Router Class Initialized
INFO - 2020-01-27 07:40:38 --> Output Class Initialized
INFO - 2020-01-27 07:40:38 --> Security Class Initialized
DEBUG - 2020-01-27 07:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:40:38 --> Input Class Initialized
INFO - 2020-01-27 07:40:38 --> Language Class Initialized
INFO - 2020-01-27 07:40:38 --> Language Class Initialized
INFO - 2020-01-27 07:40:38 --> Config Class Initialized
INFO - 2020-01-27 07:40:38 --> Loader Class Initialized
INFO - 2020-01-27 07:40:38 --> Helper loaded: url_helper
INFO - 2020-01-27 07:40:38 --> Helper loaded: file_helper
INFO - 2020-01-27 07:40:38 --> Helper loaded: form_helper
INFO - 2020-01-27 07:40:38 --> Helper loaded: my_helper
INFO - 2020-01-27 07:40:38 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:40:38 --> Controller Class Initialized
INFO - 2020-01-27 07:40:38 --> Final output sent to browser
DEBUG - 2020-01-27 07:40:38 --> Total execution time: 0.4450
INFO - 2020-01-27 07:40:38 --> Config Class Initialized
INFO - 2020-01-27 07:40:39 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:40:39 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:40:39 --> Utf8 Class Initialized
INFO - 2020-01-27 07:40:39 --> URI Class Initialized
INFO - 2020-01-27 07:40:39 --> Router Class Initialized
INFO - 2020-01-27 07:40:39 --> Output Class Initialized
INFO - 2020-01-27 07:40:39 --> Security Class Initialized
DEBUG - 2020-01-27 07:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:40:39 --> Input Class Initialized
INFO - 2020-01-27 07:40:39 --> Language Class Initialized
INFO - 2020-01-27 07:40:39 --> Language Class Initialized
INFO - 2020-01-27 07:40:39 --> Config Class Initialized
INFO - 2020-01-27 07:40:39 --> Loader Class Initialized
INFO - 2020-01-27 07:40:39 --> Helper loaded: url_helper
INFO - 2020-01-27 07:40:39 --> Helper loaded: file_helper
INFO - 2020-01-27 07:40:39 --> Helper loaded: form_helper
INFO - 2020-01-27 07:40:39 --> Helper loaded: my_helper
INFO - 2020-01-27 07:40:39 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:40:39 --> Controller Class Initialized
INFO - 2020-01-27 07:40:50 --> Config Class Initialized
INFO - 2020-01-27 07:40:50 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:40:50 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:40:50 --> Utf8 Class Initialized
INFO - 2020-01-27 07:40:50 --> URI Class Initialized
INFO - 2020-01-27 07:40:50 --> Router Class Initialized
INFO - 2020-01-27 07:40:50 --> Output Class Initialized
INFO - 2020-01-27 07:40:50 --> Security Class Initialized
DEBUG - 2020-01-27 07:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:40:50 --> Input Class Initialized
INFO - 2020-01-27 07:40:50 --> Language Class Initialized
INFO - 2020-01-27 07:40:50 --> Language Class Initialized
INFO - 2020-01-27 07:40:50 --> Config Class Initialized
INFO - 2020-01-27 07:40:50 --> Loader Class Initialized
INFO - 2020-01-27 07:40:50 --> Helper loaded: url_helper
INFO - 2020-01-27 07:40:50 --> Helper loaded: file_helper
INFO - 2020-01-27 07:40:50 --> Helper loaded: form_helper
INFO - 2020-01-27 07:40:50 --> Helper loaded: my_helper
INFO - 2020-01-27 07:40:50 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:40:50 --> Controller Class Initialized
INFO - 2020-01-27 07:40:50 --> Final output sent to browser
DEBUG - 2020-01-27 07:40:50 --> Total execution time: 0.4345
INFO - 2020-01-27 07:40:53 --> Config Class Initialized
INFO - 2020-01-27 07:40:53 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:40:53 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:40:53 --> Utf8 Class Initialized
INFO - 2020-01-27 07:40:53 --> URI Class Initialized
INFO - 2020-01-27 07:40:53 --> Router Class Initialized
INFO - 2020-01-27 07:40:53 --> Output Class Initialized
INFO - 2020-01-27 07:40:53 --> Security Class Initialized
DEBUG - 2020-01-27 07:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:40:54 --> Input Class Initialized
INFO - 2020-01-27 07:40:54 --> Language Class Initialized
INFO - 2020-01-27 07:40:54 --> Language Class Initialized
INFO - 2020-01-27 07:40:54 --> Config Class Initialized
INFO - 2020-01-27 07:40:54 --> Loader Class Initialized
INFO - 2020-01-27 07:40:54 --> Helper loaded: url_helper
INFO - 2020-01-27 07:40:54 --> Helper loaded: file_helper
INFO - 2020-01-27 07:40:54 --> Helper loaded: form_helper
INFO - 2020-01-27 07:40:54 --> Helper loaded: my_helper
INFO - 2020-01-27 07:40:54 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:40:54 --> Controller Class Initialized
INFO - 2020-01-27 07:40:54 --> Final output sent to browser
DEBUG - 2020-01-27 07:40:54 --> Total execution time: 0.4369
INFO - 2020-01-27 07:40:54 --> Config Class Initialized
INFO - 2020-01-27 07:40:54 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:40:54 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:40:54 --> Utf8 Class Initialized
INFO - 2020-01-27 07:40:54 --> URI Class Initialized
INFO - 2020-01-27 07:40:54 --> Router Class Initialized
INFO - 2020-01-27 07:40:54 --> Output Class Initialized
INFO - 2020-01-27 07:40:54 --> Security Class Initialized
DEBUG - 2020-01-27 07:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:40:54 --> Input Class Initialized
INFO - 2020-01-27 07:40:54 --> Language Class Initialized
INFO - 2020-01-27 07:40:54 --> Language Class Initialized
INFO - 2020-01-27 07:40:54 --> Config Class Initialized
INFO - 2020-01-27 07:40:54 --> Loader Class Initialized
INFO - 2020-01-27 07:40:54 --> Helper loaded: url_helper
INFO - 2020-01-27 07:40:54 --> Helper loaded: file_helper
INFO - 2020-01-27 07:40:54 --> Helper loaded: form_helper
INFO - 2020-01-27 07:40:54 --> Helper loaded: my_helper
INFO - 2020-01-27 07:40:54 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:40:54 --> Controller Class Initialized
INFO - 2020-01-27 07:40:58 --> Config Class Initialized
INFO - 2020-01-27 07:40:58 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:40:58 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:40:58 --> Utf8 Class Initialized
INFO - 2020-01-27 07:40:58 --> URI Class Initialized
INFO - 2020-01-27 07:40:58 --> Router Class Initialized
INFO - 2020-01-27 07:40:58 --> Output Class Initialized
INFO - 2020-01-27 07:40:58 --> Security Class Initialized
DEBUG - 2020-01-27 07:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:40:58 --> Input Class Initialized
INFO - 2020-01-27 07:40:58 --> Language Class Initialized
INFO - 2020-01-27 07:40:58 --> Language Class Initialized
INFO - 2020-01-27 07:40:58 --> Config Class Initialized
INFO - 2020-01-27 07:40:58 --> Loader Class Initialized
INFO - 2020-01-27 07:40:58 --> Helper loaded: url_helper
INFO - 2020-01-27 07:40:58 --> Helper loaded: file_helper
INFO - 2020-01-27 07:40:58 --> Helper loaded: form_helper
INFO - 2020-01-27 07:40:58 --> Helper loaded: my_helper
INFO - 2020-01-27 07:40:58 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:40:58 --> Controller Class Initialized
INFO - 2020-01-27 07:40:58 --> Final output sent to browser
DEBUG - 2020-01-27 07:40:58 --> Total execution time: 0.4392
INFO - 2020-01-27 07:41:01 --> Config Class Initialized
INFO - 2020-01-27 07:41:01 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:41:01 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:41:01 --> Utf8 Class Initialized
INFO - 2020-01-27 07:41:01 --> URI Class Initialized
INFO - 2020-01-27 07:41:01 --> Router Class Initialized
INFO - 2020-01-27 07:41:01 --> Output Class Initialized
INFO - 2020-01-27 07:41:01 --> Security Class Initialized
DEBUG - 2020-01-27 07:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:41:01 --> Input Class Initialized
INFO - 2020-01-27 07:41:01 --> Language Class Initialized
INFO - 2020-01-27 07:41:01 --> Language Class Initialized
INFO - 2020-01-27 07:41:01 --> Config Class Initialized
INFO - 2020-01-27 07:41:01 --> Loader Class Initialized
INFO - 2020-01-27 07:41:01 --> Helper loaded: url_helper
INFO - 2020-01-27 07:41:02 --> Helper loaded: file_helper
INFO - 2020-01-27 07:41:02 --> Helper loaded: form_helper
INFO - 2020-01-27 07:41:02 --> Helper loaded: my_helper
INFO - 2020-01-27 07:41:02 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:41:02 --> Controller Class Initialized
INFO - 2020-01-27 07:41:02 --> Final output sent to browser
DEBUG - 2020-01-27 07:41:02 --> Total execution time: 0.4375
INFO - 2020-01-27 07:41:02 --> Config Class Initialized
INFO - 2020-01-27 07:41:02 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:41:02 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:41:02 --> Utf8 Class Initialized
INFO - 2020-01-27 07:41:02 --> URI Class Initialized
INFO - 2020-01-27 07:41:02 --> Router Class Initialized
INFO - 2020-01-27 07:41:02 --> Output Class Initialized
INFO - 2020-01-27 07:41:02 --> Security Class Initialized
DEBUG - 2020-01-27 07:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:41:02 --> Input Class Initialized
INFO - 2020-01-27 07:41:02 --> Language Class Initialized
INFO - 2020-01-27 07:41:02 --> Language Class Initialized
INFO - 2020-01-27 07:41:02 --> Config Class Initialized
INFO - 2020-01-27 07:41:02 --> Loader Class Initialized
INFO - 2020-01-27 07:41:02 --> Helper loaded: url_helper
INFO - 2020-01-27 07:41:02 --> Helper loaded: file_helper
INFO - 2020-01-27 07:41:02 --> Helper loaded: form_helper
INFO - 2020-01-27 07:41:02 --> Helper loaded: my_helper
INFO - 2020-01-27 07:41:02 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:41:02 --> Controller Class Initialized
INFO - 2020-01-27 07:41:19 --> Config Class Initialized
INFO - 2020-01-27 07:41:19 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:41:19 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:41:19 --> Utf8 Class Initialized
INFO - 2020-01-27 07:41:19 --> URI Class Initialized
INFO - 2020-01-27 07:41:19 --> Router Class Initialized
INFO - 2020-01-27 07:41:19 --> Output Class Initialized
INFO - 2020-01-27 07:41:19 --> Security Class Initialized
DEBUG - 2020-01-27 07:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:41:19 --> Input Class Initialized
INFO - 2020-01-27 07:41:20 --> Language Class Initialized
INFO - 2020-01-27 07:41:20 --> Language Class Initialized
INFO - 2020-01-27 07:41:20 --> Config Class Initialized
INFO - 2020-01-27 07:41:20 --> Loader Class Initialized
INFO - 2020-01-27 07:41:20 --> Helper loaded: url_helper
INFO - 2020-01-27 07:41:20 --> Helper loaded: file_helper
INFO - 2020-01-27 07:41:20 --> Helper loaded: form_helper
INFO - 2020-01-27 07:41:20 --> Helper loaded: my_helper
INFO - 2020-01-27 07:41:20 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:41:20 --> Controller Class Initialized
INFO - 2020-01-27 07:41:20 --> Final output sent to browser
DEBUG - 2020-01-27 07:41:20 --> Total execution time: 0.4382
INFO - 2020-01-27 07:41:22 --> Config Class Initialized
INFO - 2020-01-27 07:41:22 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:41:22 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:41:22 --> Utf8 Class Initialized
INFO - 2020-01-27 07:41:22 --> URI Class Initialized
INFO - 2020-01-27 07:41:22 --> Router Class Initialized
INFO - 2020-01-27 07:41:22 --> Output Class Initialized
INFO - 2020-01-27 07:41:22 --> Security Class Initialized
DEBUG - 2020-01-27 07:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:41:22 --> Input Class Initialized
INFO - 2020-01-27 07:41:22 --> Language Class Initialized
INFO - 2020-01-27 07:41:22 --> Language Class Initialized
INFO - 2020-01-27 07:41:22 --> Config Class Initialized
INFO - 2020-01-27 07:41:22 --> Loader Class Initialized
INFO - 2020-01-27 07:41:22 --> Helper loaded: url_helper
INFO - 2020-01-27 07:41:22 --> Helper loaded: file_helper
INFO - 2020-01-27 07:41:22 --> Helper loaded: form_helper
INFO - 2020-01-27 07:41:22 --> Helper loaded: my_helper
INFO - 2020-01-27 07:41:22 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:41:22 --> Controller Class Initialized
INFO - 2020-01-27 07:41:22 --> Helper loaded: cookie_helper
INFO - 2020-01-27 07:41:22 --> Config Class Initialized
INFO - 2020-01-27 07:41:22 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:41:22 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:41:22 --> Utf8 Class Initialized
INFO - 2020-01-27 07:41:22 --> URI Class Initialized
INFO - 2020-01-27 07:41:22 --> Router Class Initialized
INFO - 2020-01-27 07:41:22 --> Output Class Initialized
INFO - 2020-01-27 07:41:22 --> Security Class Initialized
DEBUG - 2020-01-27 07:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:41:22 --> Input Class Initialized
INFO - 2020-01-27 07:41:22 --> Language Class Initialized
INFO - 2020-01-27 07:41:22 --> Language Class Initialized
INFO - 2020-01-27 07:41:22 --> Config Class Initialized
INFO - 2020-01-27 07:41:22 --> Loader Class Initialized
INFO - 2020-01-27 07:41:22 --> Helper loaded: url_helper
INFO - 2020-01-27 07:41:22 --> Helper loaded: file_helper
INFO - 2020-01-27 07:41:23 --> Helper loaded: form_helper
INFO - 2020-01-27 07:41:23 --> Helper loaded: my_helper
INFO - 2020-01-27 07:41:23 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:41:23 --> Controller Class Initialized
INFO - 2020-01-27 07:41:23 --> Config Class Initialized
INFO - 2020-01-27 07:41:23 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:41:23 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:41:23 --> Utf8 Class Initialized
INFO - 2020-01-27 07:41:23 --> URI Class Initialized
INFO - 2020-01-27 07:41:23 --> Router Class Initialized
INFO - 2020-01-27 07:41:23 --> Output Class Initialized
INFO - 2020-01-27 07:41:23 --> Security Class Initialized
DEBUG - 2020-01-27 07:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:41:23 --> Input Class Initialized
INFO - 2020-01-27 07:41:23 --> Language Class Initialized
INFO - 2020-01-27 07:41:23 --> Language Class Initialized
INFO - 2020-01-27 07:41:23 --> Config Class Initialized
INFO - 2020-01-27 07:41:23 --> Loader Class Initialized
INFO - 2020-01-27 07:41:23 --> Helper loaded: url_helper
INFO - 2020-01-27 07:41:23 --> Helper loaded: file_helper
INFO - 2020-01-27 07:41:23 --> Helper loaded: form_helper
INFO - 2020-01-27 07:41:23 --> Helper loaded: my_helper
INFO - 2020-01-27 07:41:23 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:41:23 --> Controller Class Initialized
DEBUG - 2020-01-27 07:41:23 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-27 07:41:23 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 07:41:23 --> Final output sent to browser
DEBUG - 2020-01-27 07:41:23 --> Total execution time: 0.4619
INFO - 2020-01-27 07:41:29 --> Config Class Initialized
INFO - 2020-01-27 07:41:29 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:41:29 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:41:29 --> Utf8 Class Initialized
INFO - 2020-01-27 07:41:29 --> URI Class Initialized
INFO - 2020-01-27 07:41:29 --> Router Class Initialized
INFO - 2020-01-27 07:41:29 --> Output Class Initialized
INFO - 2020-01-27 07:41:29 --> Security Class Initialized
DEBUG - 2020-01-27 07:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:41:29 --> Input Class Initialized
INFO - 2020-01-27 07:41:29 --> Language Class Initialized
INFO - 2020-01-27 07:41:29 --> Language Class Initialized
INFO - 2020-01-27 07:41:29 --> Config Class Initialized
INFO - 2020-01-27 07:41:29 --> Loader Class Initialized
INFO - 2020-01-27 07:41:29 --> Helper loaded: url_helper
INFO - 2020-01-27 07:41:29 --> Helper loaded: file_helper
INFO - 2020-01-27 07:41:29 --> Helper loaded: form_helper
INFO - 2020-01-27 07:41:29 --> Helper loaded: my_helper
INFO - 2020-01-27 07:41:29 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:41:29 --> Controller Class Initialized
INFO - 2020-01-27 07:41:29 --> Helper loaded: cookie_helper
INFO - 2020-01-27 07:41:29 --> Final output sent to browser
DEBUG - 2020-01-27 07:41:29 --> Total execution time: 0.4846
INFO - 2020-01-27 07:41:31 --> Config Class Initialized
INFO - 2020-01-27 07:41:31 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:41:31 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:41:31 --> Utf8 Class Initialized
INFO - 2020-01-27 07:41:31 --> URI Class Initialized
INFO - 2020-01-27 07:41:31 --> Router Class Initialized
INFO - 2020-01-27 07:41:31 --> Output Class Initialized
INFO - 2020-01-27 07:41:31 --> Security Class Initialized
DEBUG - 2020-01-27 07:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:41:31 --> Input Class Initialized
INFO - 2020-01-27 07:41:31 --> Language Class Initialized
INFO - 2020-01-27 07:41:31 --> Language Class Initialized
INFO - 2020-01-27 07:41:31 --> Config Class Initialized
INFO - 2020-01-27 07:41:31 --> Loader Class Initialized
INFO - 2020-01-27 07:41:31 --> Helper loaded: url_helper
INFO - 2020-01-27 07:41:31 --> Helper loaded: file_helper
INFO - 2020-01-27 07:41:31 --> Helper loaded: form_helper
INFO - 2020-01-27 07:41:31 --> Helper loaded: my_helper
INFO - 2020-01-27 07:41:31 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:41:31 --> Controller Class Initialized
DEBUG - 2020-01-27 07:41:31 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-27 07:41:31 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 07:41:31 --> Final output sent to browser
DEBUG - 2020-01-27 07:41:31 --> Total execution time: 0.5587
INFO - 2020-01-27 07:44:21 --> Config Class Initialized
INFO - 2020-01-27 07:44:21 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:44:21 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:44:21 --> Utf8 Class Initialized
INFO - 2020-01-27 07:44:21 --> URI Class Initialized
INFO - 2020-01-27 07:44:21 --> Router Class Initialized
INFO - 2020-01-27 07:44:21 --> Output Class Initialized
INFO - 2020-01-27 07:44:21 --> Security Class Initialized
DEBUG - 2020-01-27 07:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:44:21 --> Input Class Initialized
INFO - 2020-01-27 07:44:21 --> Language Class Initialized
INFO - 2020-01-27 07:44:21 --> Language Class Initialized
INFO - 2020-01-27 07:44:21 --> Config Class Initialized
INFO - 2020-01-27 07:44:21 --> Loader Class Initialized
INFO - 2020-01-27 07:44:21 --> Helper loaded: url_helper
INFO - 2020-01-27 07:44:21 --> Helper loaded: file_helper
INFO - 2020-01-27 07:44:21 --> Helper loaded: form_helper
ERROR - 2020-01-27 07:44:21 --> Severity: error --> Exception: syntax error, unexpected '$rentang' (T_VARIABLE) E:\xampp\htdocs\_2020\nilaik13_ci\application\helpers\my_helper.php 24
INFO - 2020-01-27 07:44:38 --> Config Class Initialized
INFO - 2020-01-27 07:44:38 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:44:38 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:44:38 --> Utf8 Class Initialized
INFO - 2020-01-27 07:44:38 --> URI Class Initialized
INFO - 2020-01-27 07:44:38 --> Router Class Initialized
INFO - 2020-01-27 07:44:38 --> Output Class Initialized
INFO - 2020-01-27 07:44:38 --> Security Class Initialized
DEBUG - 2020-01-27 07:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:44:38 --> Input Class Initialized
INFO - 2020-01-27 07:44:38 --> Language Class Initialized
INFO - 2020-01-27 07:44:38 --> Language Class Initialized
INFO - 2020-01-27 07:44:38 --> Config Class Initialized
INFO - 2020-01-27 07:44:38 --> Loader Class Initialized
INFO - 2020-01-27 07:44:38 --> Helper loaded: url_helper
INFO - 2020-01-27 07:44:38 --> Helper loaded: file_helper
INFO - 2020-01-27 07:44:38 --> Helper loaded: form_helper
ERROR - 2020-01-27 07:44:38 --> Severity: error --> Exception: syntax error, unexpected '$rentang' (T_VARIABLE) E:\xampp\htdocs\_2020\nilaik13_ci\application\helpers\my_helper.php 55
INFO - 2020-01-27 07:44:46 --> Config Class Initialized
INFO - 2020-01-27 07:44:46 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:44:46 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:44:46 --> Utf8 Class Initialized
INFO - 2020-01-27 07:44:46 --> URI Class Initialized
INFO - 2020-01-27 07:44:46 --> Router Class Initialized
INFO - 2020-01-27 07:44:46 --> Output Class Initialized
INFO - 2020-01-27 07:44:46 --> Security Class Initialized
DEBUG - 2020-01-27 07:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:44:46 --> Input Class Initialized
INFO - 2020-01-27 07:44:46 --> Language Class Initialized
INFO - 2020-01-27 07:44:46 --> Language Class Initialized
INFO - 2020-01-27 07:44:46 --> Config Class Initialized
INFO - 2020-01-27 07:44:46 --> Loader Class Initialized
INFO - 2020-01-27 07:44:46 --> Helper loaded: url_helper
INFO - 2020-01-27 07:44:46 --> Helper loaded: file_helper
INFO - 2020-01-27 07:44:46 --> Helper loaded: form_helper
INFO - 2020-01-27 07:44:46 --> Helper loaded: my_helper
INFO - 2020-01-27 07:44:46 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:44:46 --> Controller Class Initialized
DEBUG - 2020-01-27 07:44:46 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-01-27 07:44:46 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 07:44:46 --> Final output sent to browser
DEBUG - 2020-01-27 07:44:46 --> Total execution time: 0.4986
INFO - 2020-01-27 07:44:50 --> Config Class Initialized
INFO - 2020-01-27 07:44:50 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:44:50 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:44:50 --> Utf8 Class Initialized
INFO - 2020-01-27 07:44:50 --> URI Class Initialized
INFO - 2020-01-27 07:44:50 --> Router Class Initialized
INFO - 2020-01-27 07:44:50 --> Output Class Initialized
INFO - 2020-01-27 07:44:50 --> Security Class Initialized
DEBUG - 2020-01-27 07:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:44:50 --> Input Class Initialized
INFO - 2020-01-27 07:44:50 --> Language Class Initialized
INFO - 2020-01-27 07:44:50 --> Language Class Initialized
INFO - 2020-01-27 07:44:50 --> Config Class Initialized
INFO - 2020-01-27 07:44:50 --> Loader Class Initialized
INFO - 2020-01-27 07:44:50 --> Helper loaded: url_helper
INFO - 2020-01-27 07:44:50 --> Helper loaded: file_helper
INFO - 2020-01-27 07:44:50 --> Helper loaded: form_helper
INFO - 2020-01-27 07:44:50 --> Helper loaded: my_helper
INFO - 2020-01-27 07:44:50 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:44:50 --> Controller Class Initialized
DEBUG - 2020-01-27 07:44:50 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-01-27 07:44:50 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 07:44:50 --> Final output sent to browser
DEBUG - 2020-01-27 07:44:50 --> Total execution time: 0.5038
INFO - 2020-01-27 07:44:52 --> Config Class Initialized
INFO - 2020-01-27 07:44:52 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:44:52 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:44:52 --> Utf8 Class Initialized
INFO - 2020-01-27 07:44:52 --> URI Class Initialized
INFO - 2020-01-27 07:44:52 --> Router Class Initialized
INFO - 2020-01-27 07:44:52 --> Output Class Initialized
INFO - 2020-01-27 07:44:52 --> Security Class Initialized
DEBUG - 2020-01-27 07:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:44:52 --> Input Class Initialized
INFO - 2020-01-27 07:44:52 --> Language Class Initialized
INFO - 2020-01-27 07:44:52 --> Language Class Initialized
INFO - 2020-01-27 07:44:52 --> Config Class Initialized
INFO - 2020-01-27 07:44:52 --> Loader Class Initialized
INFO - 2020-01-27 07:44:52 --> Helper loaded: url_helper
INFO - 2020-01-27 07:44:52 --> Helper loaded: file_helper
INFO - 2020-01-27 07:44:52 --> Helper loaded: form_helper
INFO - 2020-01-27 07:44:52 --> Helper loaded: my_helper
INFO - 2020-01-27 07:44:52 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:44:52 --> Controller Class Initialized
DEBUG - 2020-01-27 07:44:52 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-01-27 07:44:52 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 07:44:52 --> Final output sent to browser
DEBUG - 2020-01-27 07:44:52 --> Total execution time: 0.4798
INFO - 2020-01-27 07:44:52 --> Config Class Initialized
INFO - 2020-01-27 07:44:53 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:44:53 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:44:53 --> Utf8 Class Initialized
INFO - 2020-01-27 07:44:53 --> URI Class Initialized
INFO - 2020-01-27 07:44:53 --> Router Class Initialized
INFO - 2020-01-27 07:44:53 --> Output Class Initialized
INFO - 2020-01-27 07:44:53 --> Security Class Initialized
DEBUG - 2020-01-27 07:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:44:53 --> Input Class Initialized
INFO - 2020-01-27 07:44:53 --> Language Class Initialized
INFO - 2020-01-27 07:44:53 --> Language Class Initialized
INFO - 2020-01-27 07:44:53 --> Config Class Initialized
INFO - 2020-01-27 07:44:53 --> Loader Class Initialized
INFO - 2020-01-27 07:44:53 --> Helper loaded: url_helper
INFO - 2020-01-27 07:44:53 --> Helper loaded: file_helper
INFO - 2020-01-27 07:44:53 --> Helper loaded: form_helper
INFO - 2020-01-27 07:44:53 --> Helper loaded: my_helper
INFO - 2020-01-27 07:44:53 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:44:53 --> Controller Class Initialized
INFO - 2020-01-27 07:47:03 --> Config Class Initialized
INFO - 2020-01-27 07:47:03 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:47:04 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:47:04 --> Utf8 Class Initialized
INFO - 2020-01-27 07:47:04 --> URI Class Initialized
INFO - 2020-01-27 07:47:04 --> Router Class Initialized
INFO - 2020-01-27 07:47:04 --> Output Class Initialized
INFO - 2020-01-27 07:47:04 --> Security Class Initialized
DEBUG - 2020-01-27 07:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:47:04 --> Input Class Initialized
INFO - 2020-01-27 07:47:04 --> Language Class Initialized
INFO - 2020-01-27 07:47:04 --> Language Class Initialized
INFO - 2020-01-27 07:47:04 --> Config Class Initialized
INFO - 2020-01-27 07:47:04 --> Loader Class Initialized
INFO - 2020-01-27 07:47:04 --> Helper loaded: url_helper
INFO - 2020-01-27 07:47:04 --> Helper loaded: file_helper
INFO - 2020-01-27 07:47:04 --> Helper loaded: form_helper
INFO - 2020-01-27 07:47:04 --> Helper loaded: my_helper
INFO - 2020-01-27 07:47:04 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:47:04 --> Controller Class Initialized
DEBUG - 2020-01-27 07:47:04 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-01-27 07:47:04 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 07:47:04 --> Final output sent to browser
DEBUG - 2020-01-27 07:47:04 --> Total execution time: 0.5097
INFO - 2020-01-27 07:47:04 --> Config Class Initialized
INFO - 2020-01-27 07:47:04 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:47:04 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:47:04 --> Utf8 Class Initialized
INFO - 2020-01-27 07:47:04 --> URI Class Initialized
INFO - 2020-01-27 07:47:04 --> Router Class Initialized
INFO - 2020-01-27 07:47:04 --> Output Class Initialized
INFO - 2020-01-27 07:47:04 --> Security Class Initialized
DEBUG - 2020-01-27 07:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:47:04 --> Input Class Initialized
INFO - 2020-01-27 07:47:04 --> Language Class Initialized
INFO - 2020-01-27 07:47:04 --> Language Class Initialized
INFO - 2020-01-27 07:47:04 --> Config Class Initialized
INFO - 2020-01-27 07:47:04 --> Loader Class Initialized
INFO - 2020-01-27 07:47:04 --> Helper loaded: url_helper
INFO - 2020-01-27 07:47:04 --> Helper loaded: file_helper
INFO - 2020-01-27 07:47:05 --> Helper loaded: form_helper
INFO - 2020-01-27 07:47:05 --> Helper loaded: my_helper
INFO - 2020-01-27 07:47:05 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:47:05 --> Controller Class Initialized
INFO - 2020-01-27 07:47:06 --> Config Class Initialized
INFO - 2020-01-27 07:47:06 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:47:06 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:47:06 --> Utf8 Class Initialized
INFO - 2020-01-27 07:47:06 --> URI Class Initialized
INFO - 2020-01-27 07:47:06 --> Router Class Initialized
INFO - 2020-01-27 07:47:06 --> Output Class Initialized
INFO - 2020-01-27 07:47:07 --> Security Class Initialized
DEBUG - 2020-01-27 07:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:47:07 --> Input Class Initialized
INFO - 2020-01-27 07:47:07 --> Language Class Initialized
INFO - 2020-01-27 07:47:07 --> Language Class Initialized
INFO - 2020-01-27 07:47:07 --> Config Class Initialized
INFO - 2020-01-27 07:47:07 --> Loader Class Initialized
INFO - 2020-01-27 07:47:07 --> Helper loaded: url_helper
INFO - 2020-01-27 07:47:07 --> Helper loaded: file_helper
INFO - 2020-01-27 07:47:07 --> Helper loaded: form_helper
INFO - 2020-01-27 07:47:07 --> Helper loaded: my_helper
INFO - 2020-01-27 07:47:07 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:47:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:47:07 --> Controller Class Initialized
DEBUG - 2020-01-27 07:47:07 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-01-27 07:47:07 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 07:47:07 --> Final output sent to browser
DEBUG - 2020-01-27 07:47:07 --> Total execution time: 0.5423
INFO - 2020-01-27 07:47:07 --> Config Class Initialized
INFO - 2020-01-27 07:47:07 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:47:07 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:47:07 --> Utf8 Class Initialized
INFO - 2020-01-27 07:47:07 --> URI Class Initialized
INFO - 2020-01-27 07:47:07 --> Router Class Initialized
INFO - 2020-01-27 07:47:07 --> Output Class Initialized
INFO - 2020-01-27 07:47:07 --> Security Class Initialized
DEBUG - 2020-01-27 07:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:47:07 --> Input Class Initialized
INFO - 2020-01-27 07:47:07 --> Language Class Initialized
INFO - 2020-01-27 07:47:07 --> Language Class Initialized
INFO - 2020-01-27 07:47:07 --> Config Class Initialized
INFO - 2020-01-27 07:47:07 --> Loader Class Initialized
INFO - 2020-01-27 07:47:07 --> Helper loaded: url_helper
INFO - 2020-01-27 07:47:07 --> Helper loaded: file_helper
INFO - 2020-01-27 07:47:07 --> Helper loaded: form_helper
INFO - 2020-01-27 07:47:07 --> Helper loaded: my_helper
INFO - 2020-01-27 07:47:07 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:47:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:47:08 --> Controller Class Initialized
INFO - 2020-01-27 07:47:19 --> Config Class Initialized
INFO - 2020-01-27 07:47:19 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:47:19 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:47:19 --> Utf8 Class Initialized
INFO - 2020-01-27 07:47:19 --> URI Class Initialized
INFO - 2020-01-27 07:47:19 --> Router Class Initialized
INFO - 2020-01-27 07:47:19 --> Output Class Initialized
INFO - 2020-01-27 07:47:19 --> Security Class Initialized
DEBUG - 2020-01-27 07:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:47:19 --> Input Class Initialized
INFO - 2020-01-27 07:47:19 --> Language Class Initialized
INFO - 2020-01-27 07:47:20 --> Language Class Initialized
INFO - 2020-01-27 07:47:20 --> Config Class Initialized
INFO - 2020-01-27 07:47:20 --> Loader Class Initialized
INFO - 2020-01-27 07:47:20 --> Helper loaded: url_helper
INFO - 2020-01-27 07:47:20 --> Helper loaded: file_helper
INFO - 2020-01-27 07:47:20 --> Helper loaded: form_helper
INFO - 2020-01-27 07:47:20 --> Helper loaded: my_helper
INFO - 2020-01-27 07:47:20 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:47:20 --> Controller Class Initialized
DEBUG - 2020-01-27 07:47:20 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-01-27 07:47:20 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 07:47:20 --> Final output sent to browser
DEBUG - 2020-01-27 07:47:20 --> Total execution time: 0.4990
INFO - 2020-01-27 07:47:20 --> Config Class Initialized
INFO - 2020-01-27 07:47:20 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:47:20 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:47:20 --> Utf8 Class Initialized
INFO - 2020-01-27 07:47:20 --> URI Class Initialized
INFO - 2020-01-27 07:47:20 --> Router Class Initialized
INFO - 2020-01-27 07:47:20 --> Output Class Initialized
INFO - 2020-01-27 07:47:20 --> Security Class Initialized
DEBUG - 2020-01-27 07:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:47:20 --> Input Class Initialized
INFO - 2020-01-27 07:47:20 --> Language Class Initialized
INFO - 2020-01-27 07:47:20 --> Language Class Initialized
INFO - 2020-01-27 07:47:20 --> Config Class Initialized
INFO - 2020-01-27 07:47:20 --> Loader Class Initialized
INFO - 2020-01-27 07:47:20 --> Helper loaded: url_helper
INFO - 2020-01-27 07:47:20 --> Helper loaded: file_helper
INFO - 2020-01-27 07:47:20 --> Helper loaded: form_helper
INFO - 2020-01-27 07:47:20 --> Helper loaded: my_helper
INFO - 2020-01-27 07:47:20 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:47:20 --> Controller Class Initialized
INFO - 2020-01-27 07:47:32 --> Config Class Initialized
INFO - 2020-01-27 07:47:32 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:47:32 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:47:32 --> Utf8 Class Initialized
INFO - 2020-01-27 07:47:32 --> URI Class Initialized
INFO - 2020-01-27 07:47:32 --> Router Class Initialized
INFO - 2020-01-27 07:47:32 --> Output Class Initialized
INFO - 2020-01-27 07:47:32 --> Security Class Initialized
DEBUG - 2020-01-27 07:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:47:32 --> Input Class Initialized
INFO - 2020-01-27 07:47:32 --> Language Class Initialized
INFO - 2020-01-27 07:47:32 --> Language Class Initialized
INFO - 2020-01-27 07:47:33 --> Config Class Initialized
INFO - 2020-01-27 07:47:33 --> Loader Class Initialized
INFO - 2020-01-27 07:47:33 --> Helper loaded: url_helper
INFO - 2020-01-27 07:47:33 --> Helper loaded: file_helper
INFO - 2020-01-27 07:47:33 --> Helper loaded: form_helper
INFO - 2020-01-27 07:47:33 --> Helper loaded: my_helper
INFO - 2020-01-27 07:47:33 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:47:33 --> Controller Class Initialized
DEBUG - 2020-01-27 07:47:33 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-01-27 07:47:33 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 07:47:33 --> Final output sent to browser
DEBUG - 2020-01-27 07:47:33 --> Total execution time: 0.5712
INFO - 2020-01-27 07:47:34 --> Config Class Initialized
INFO - 2020-01-27 07:47:34 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:47:34 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:47:34 --> Utf8 Class Initialized
INFO - 2020-01-27 07:47:34 --> URI Class Initialized
INFO - 2020-01-27 07:47:34 --> Router Class Initialized
INFO - 2020-01-27 07:47:34 --> Output Class Initialized
INFO - 2020-01-27 07:47:34 --> Security Class Initialized
DEBUG - 2020-01-27 07:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:47:34 --> Input Class Initialized
INFO - 2020-01-27 07:47:34 --> Language Class Initialized
INFO - 2020-01-27 07:47:34 --> Language Class Initialized
INFO - 2020-01-27 07:47:34 --> Config Class Initialized
INFO - 2020-01-27 07:47:34 --> Loader Class Initialized
INFO - 2020-01-27 07:47:34 --> Helper loaded: url_helper
INFO - 2020-01-27 07:47:34 --> Helper loaded: file_helper
INFO - 2020-01-27 07:47:34 --> Helper loaded: form_helper
INFO - 2020-01-27 07:47:34 --> Helper loaded: my_helper
INFO - 2020-01-27 07:47:34 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:47:34 --> Controller Class Initialized
ERROR - 2020-01-27 07:47:34 --> Severity: Notice --> Undefined index: kkm E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\views\list.php 6
DEBUG - 2020-01-27 07:47:34 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-01-27 07:47:34 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 07:47:34 --> Final output sent to browser
DEBUG - 2020-01-27 07:47:34 --> Total execution time: 0.4979
INFO - 2020-01-27 07:48:00 --> Config Class Initialized
INFO - 2020-01-27 07:48:00 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:48:00 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:48:00 --> Utf8 Class Initialized
INFO - 2020-01-27 07:48:00 --> URI Class Initialized
INFO - 2020-01-27 07:48:00 --> Router Class Initialized
INFO - 2020-01-27 07:48:00 --> Output Class Initialized
INFO - 2020-01-27 07:48:00 --> Security Class Initialized
DEBUG - 2020-01-27 07:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:48:01 --> Input Class Initialized
INFO - 2020-01-27 07:48:01 --> Language Class Initialized
INFO - 2020-01-27 07:48:01 --> Language Class Initialized
INFO - 2020-01-27 07:48:01 --> Config Class Initialized
INFO - 2020-01-27 07:48:01 --> Loader Class Initialized
INFO - 2020-01-27 07:48:01 --> Helper loaded: url_helper
INFO - 2020-01-27 07:48:01 --> Helper loaded: file_helper
INFO - 2020-01-27 07:48:01 --> Helper loaded: form_helper
INFO - 2020-01-27 07:48:01 --> Helper loaded: my_helper
INFO - 2020-01-27 07:48:01 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:48:01 --> Controller Class Initialized
DEBUG - 2020-01-27 07:48:01 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-01-27 07:48:01 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 07:48:01 --> Final output sent to browser
DEBUG - 2020-01-27 07:48:01 --> Total execution time: 0.5517
INFO - 2020-01-27 07:48:40 --> Config Class Initialized
INFO - 2020-01-27 07:48:40 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:48:40 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:48:40 --> Utf8 Class Initialized
INFO - 2020-01-27 07:48:40 --> URI Class Initialized
INFO - 2020-01-27 07:48:40 --> Router Class Initialized
INFO - 2020-01-27 07:48:40 --> Output Class Initialized
INFO - 2020-01-27 07:48:40 --> Security Class Initialized
DEBUG - 2020-01-27 07:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:48:40 --> Input Class Initialized
INFO - 2020-01-27 07:48:40 --> Language Class Initialized
INFO - 2020-01-27 07:48:40 --> Language Class Initialized
INFO - 2020-01-27 07:48:40 --> Config Class Initialized
INFO - 2020-01-27 07:48:40 --> Loader Class Initialized
INFO - 2020-01-27 07:48:40 --> Helper loaded: url_helper
INFO - 2020-01-27 07:48:40 --> Helper loaded: file_helper
INFO - 2020-01-27 07:48:40 --> Helper loaded: form_helper
INFO - 2020-01-27 07:48:40 --> Helper loaded: my_helper
INFO - 2020-01-27 07:48:40 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:48:40 --> Controller Class Initialized
DEBUG - 2020-01-27 07:48:40 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-01-27 07:48:41 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 07:48:41 --> Final output sent to browser
DEBUG - 2020-01-27 07:48:41 --> Total execution time: 0.5128
INFO - 2020-01-27 07:50:39 --> Config Class Initialized
INFO - 2020-01-27 07:50:39 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:50:39 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:50:39 --> Utf8 Class Initialized
INFO - 2020-01-27 07:50:39 --> URI Class Initialized
INFO - 2020-01-27 07:50:39 --> Router Class Initialized
INFO - 2020-01-27 07:50:39 --> Output Class Initialized
INFO - 2020-01-27 07:50:39 --> Security Class Initialized
DEBUG - 2020-01-27 07:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:50:39 --> Input Class Initialized
INFO - 2020-01-27 07:50:39 --> Language Class Initialized
INFO - 2020-01-27 07:50:39 --> Language Class Initialized
INFO - 2020-01-27 07:50:39 --> Config Class Initialized
INFO - 2020-01-27 07:50:39 --> Loader Class Initialized
INFO - 2020-01-27 07:50:39 --> Helper loaded: url_helper
INFO - 2020-01-27 07:50:39 --> Helper loaded: file_helper
INFO - 2020-01-27 07:50:39 --> Helper loaded: form_helper
INFO - 2020-01-27 07:50:39 --> Helper loaded: my_helper
INFO - 2020-01-27 07:50:39 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:50:39 --> Controller Class Initialized
INFO - 2020-01-27 07:50:40 --> Final output sent to browser
DEBUG - 2020-01-27 07:50:40 --> Total execution time: 0.4124
INFO - 2020-01-27 07:50:59 --> Config Class Initialized
INFO - 2020-01-27 07:50:59 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:50:59 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:50:59 --> Utf8 Class Initialized
INFO - 2020-01-27 07:50:59 --> URI Class Initialized
INFO - 2020-01-27 07:50:59 --> Router Class Initialized
INFO - 2020-01-27 07:50:59 --> Output Class Initialized
INFO - 2020-01-27 07:50:59 --> Security Class Initialized
DEBUG - 2020-01-27 07:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:50:59 --> Input Class Initialized
INFO - 2020-01-27 07:50:59 --> Language Class Initialized
ERROR - 2020-01-27 07:50:59 --> 404 Page Not Found: /index
INFO - 2020-01-27 07:51:04 --> Config Class Initialized
INFO - 2020-01-27 07:51:04 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:51:04 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:51:04 --> Utf8 Class Initialized
INFO - 2020-01-27 07:51:04 --> URI Class Initialized
INFO - 2020-01-27 07:51:04 --> Router Class Initialized
INFO - 2020-01-27 07:51:04 --> Output Class Initialized
INFO - 2020-01-27 07:51:04 --> Security Class Initialized
DEBUG - 2020-01-27 07:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:51:04 --> Input Class Initialized
INFO - 2020-01-27 07:51:04 --> Language Class Initialized
INFO - 2020-01-27 07:51:04 --> Language Class Initialized
INFO - 2020-01-27 07:51:04 --> Config Class Initialized
INFO - 2020-01-27 07:51:04 --> Loader Class Initialized
INFO - 2020-01-27 07:51:04 --> Helper loaded: url_helper
INFO - 2020-01-27 07:51:04 --> Helper loaded: file_helper
INFO - 2020-01-27 07:51:04 --> Helper loaded: form_helper
INFO - 2020-01-27 07:51:04 --> Helper loaded: my_helper
INFO - 2020-01-27 07:51:04 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:51:04 --> Controller Class Initialized
INFO - 2020-01-27 07:51:04 --> Final output sent to browser
DEBUG - 2020-01-27 07:51:04 --> Total execution time: 0.4397
INFO - 2020-01-27 07:54:09 --> Config Class Initialized
INFO - 2020-01-27 07:54:09 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:54:09 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:54:09 --> Utf8 Class Initialized
INFO - 2020-01-27 07:54:09 --> URI Class Initialized
INFO - 2020-01-27 07:54:09 --> Router Class Initialized
INFO - 2020-01-27 07:54:09 --> Output Class Initialized
INFO - 2020-01-27 07:54:09 --> Security Class Initialized
DEBUG - 2020-01-27 07:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:54:09 --> Input Class Initialized
INFO - 2020-01-27 07:54:09 --> Language Class Initialized
INFO - 2020-01-27 07:54:09 --> Language Class Initialized
INFO - 2020-01-27 07:54:10 --> Config Class Initialized
INFO - 2020-01-27 07:54:10 --> Loader Class Initialized
INFO - 2020-01-27 07:54:10 --> Helper loaded: url_helper
INFO - 2020-01-27 07:54:10 --> Helper loaded: file_helper
INFO - 2020-01-27 07:54:10 --> Helper loaded: form_helper
INFO - 2020-01-27 07:54:10 --> Helper loaded: my_helper
INFO - 2020-01-27 07:54:10 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:54:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:54:10 --> Controller Class Initialized
DEBUG - 2020-01-27 07:54:10 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-01-27 07:54:10 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 07:54:10 --> Final output sent to browser
DEBUG - 2020-01-27 07:54:10 --> Total execution time: 0.5065
INFO - 2020-01-27 07:54:12 --> Config Class Initialized
INFO - 2020-01-27 07:54:12 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:54:12 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:54:12 --> Utf8 Class Initialized
INFO - 2020-01-27 07:54:12 --> URI Class Initialized
INFO - 2020-01-27 07:54:12 --> Router Class Initialized
INFO - 2020-01-27 07:54:12 --> Output Class Initialized
INFO - 2020-01-27 07:54:12 --> Security Class Initialized
DEBUG - 2020-01-27 07:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:54:12 --> Input Class Initialized
INFO - 2020-01-27 07:54:12 --> Language Class Initialized
INFO - 2020-01-27 07:54:12 --> Language Class Initialized
INFO - 2020-01-27 07:54:12 --> Config Class Initialized
INFO - 2020-01-27 07:54:12 --> Loader Class Initialized
INFO - 2020-01-27 07:54:12 --> Helper loaded: url_helper
INFO - 2020-01-27 07:54:12 --> Helper loaded: file_helper
INFO - 2020-01-27 07:54:12 --> Helper loaded: form_helper
INFO - 2020-01-27 07:54:12 --> Helper loaded: my_helper
INFO - 2020-01-27 07:54:12 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:54:12 --> Controller Class Initialized
INFO - 2020-01-27 07:54:12 --> Final output sent to browser
DEBUG - 2020-01-27 07:54:12 --> Total execution time: 0.4258
INFO - 2020-01-27 07:54:19 --> Config Class Initialized
INFO - 2020-01-27 07:54:19 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:54:19 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:54:19 --> Utf8 Class Initialized
INFO - 2020-01-27 07:54:19 --> URI Class Initialized
INFO - 2020-01-27 07:54:19 --> Router Class Initialized
INFO - 2020-01-27 07:54:19 --> Output Class Initialized
INFO - 2020-01-27 07:54:19 --> Security Class Initialized
DEBUG - 2020-01-27 07:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:54:19 --> Input Class Initialized
INFO - 2020-01-27 07:54:19 --> Language Class Initialized
INFO - 2020-01-27 07:54:19 --> Language Class Initialized
INFO - 2020-01-27 07:54:19 --> Config Class Initialized
INFO - 2020-01-27 07:54:19 --> Loader Class Initialized
INFO - 2020-01-27 07:54:19 --> Helper loaded: url_helper
INFO - 2020-01-27 07:54:19 --> Helper loaded: file_helper
INFO - 2020-01-27 07:54:19 --> Helper loaded: form_helper
INFO - 2020-01-27 07:54:19 --> Helper loaded: my_helper
INFO - 2020-01-27 07:54:19 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:54:20 --> Controller Class Initialized
INFO - 2020-01-27 07:54:20 --> Final output sent to browser
DEBUG - 2020-01-27 07:54:20 --> Total execution time: 0.4648
INFO - 2020-01-27 07:54:22 --> Config Class Initialized
INFO - 2020-01-27 07:54:22 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:54:22 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:54:22 --> Utf8 Class Initialized
INFO - 2020-01-27 07:54:22 --> URI Class Initialized
INFO - 2020-01-27 07:54:22 --> Router Class Initialized
INFO - 2020-01-27 07:54:22 --> Output Class Initialized
INFO - 2020-01-27 07:54:22 --> Security Class Initialized
DEBUG - 2020-01-27 07:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:54:22 --> Input Class Initialized
INFO - 2020-01-27 07:54:22 --> Language Class Initialized
INFO - 2020-01-27 07:54:22 --> Language Class Initialized
INFO - 2020-01-27 07:54:22 --> Config Class Initialized
INFO - 2020-01-27 07:54:22 --> Loader Class Initialized
INFO - 2020-01-27 07:54:22 --> Helper loaded: url_helper
INFO - 2020-01-27 07:54:22 --> Helper loaded: file_helper
INFO - 2020-01-27 07:54:22 --> Helper loaded: form_helper
INFO - 2020-01-27 07:54:22 --> Helper loaded: my_helper
INFO - 2020-01-27 07:54:22 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:54:23 --> Controller Class Initialized
ERROR - 2020-01-27 07:54:23 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:54:23 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:54:23 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:54:23 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:54:23 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:54:23 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:54:23 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:54:23 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:54:23 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:54:23 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:54:23 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:54:23 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:54:23 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:54:23 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:54:23 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:54:23 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:54:23 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:54:23 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:54:23 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:54:23 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
DEBUG - 2020-01-27 07:54:23 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 07:54:23 --> Final output sent to browser
DEBUG - 2020-01-27 07:54:23 --> Total execution time: 0.9452
INFO - 2020-01-27 07:58:29 --> Config Class Initialized
INFO - 2020-01-27 07:58:29 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:58:29 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:58:29 --> Utf8 Class Initialized
INFO - 2020-01-27 07:58:29 --> URI Class Initialized
INFO - 2020-01-27 07:58:29 --> Router Class Initialized
INFO - 2020-01-27 07:58:29 --> Output Class Initialized
INFO - 2020-01-27 07:58:29 --> Security Class Initialized
DEBUG - 2020-01-27 07:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:58:29 --> Input Class Initialized
INFO - 2020-01-27 07:58:29 --> Language Class Initialized
INFO - 2020-01-27 07:58:29 --> Language Class Initialized
INFO - 2020-01-27 07:58:29 --> Config Class Initialized
INFO - 2020-01-27 07:58:29 --> Loader Class Initialized
INFO - 2020-01-27 07:58:30 --> Helper loaded: url_helper
INFO - 2020-01-27 07:58:30 --> Helper loaded: file_helper
INFO - 2020-01-27 07:58:30 --> Helper loaded: form_helper
INFO - 2020-01-27 07:58:30 --> Helper loaded: my_helper
INFO - 2020-01-27 07:58:30 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:58:30 --> Controller Class Initialized
ERROR - 2020-01-27 07:58:30 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:58:30 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:58:30 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:58:30 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:58:30 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:58:30 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:58:30 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:58:30 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:58:30 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:58:30 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:58:30 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:58:30 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:58:30 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:58:30 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:58:30 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:58:30 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:58:30 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:58:30 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:58:30 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
ERROR - 2020-01-27 07:58:30 --> Severity: Warning --> A non-numeric value encountered E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 500
DEBUG - 2020-01-27 07:58:30 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 07:58:30 --> Final output sent to browser
DEBUG - 2020-01-27 07:58:30 --> Total execution time: 0.9476
INFO - 2020-01-27 07:59:55 --> Config Class Initialized
INFO - 2020-01-27 07:59:55 --> Hooks Class Initialized
DEBUG - 2020-01-27 07:59:55 --> UTF-8 Support Enabled
INFO - 2020-01-27 07:59:55 --> Utf8 Class Initialized
INFO - 2020-01-27 07:59:55 --> URI Class Initialized
INFO - 2020-01-27 07:59:55 --> Router Class Initialized
INFO - 2020-01-27 07:59:55 --> Output Class Initialized
INFO - 2020-01-27 07:59:55 --> Security Class Initialized
DEBUG - 2020-01-27 07:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 07:59:55 --> Input Class Initialized
INFO - 2020-01-27 07:59:55 --> Language Class Initialized
INFO - 2020-01-27 07:59:55 --> Language Class Initialized
INFO - 2020-01-27 07:59:55 --> Config Class Initialized
INFO - 2020-01-27 07:59:55 --> Loader Class Initialized
INFO - 2020-01-27 07:59:55 --> Helper loaded: url_helper
INFO - 2020-01-27 07:59:55 --> Helper loaded: file_helper
INFO - 2020-01-27 07:59:55 --> Helper loaded: form_helper
INFO - 2020-01-27 07:59:55 --> Helper loaded: my_helper
INFO - 2020-01-27 07:59:55 --> Database Driver Class Initialized
DEBUG - 2020-01-27 07:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 07:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 07:59:55 --> Controller Class Initialized
DEBUG - 2020-01-27 07:59:55 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 07:59:55 --> Final output sent to browser
DEBUG - 2020-01-27 07:59:55 --> Total execution time: 0.5189
INFO - 2020-01-27 08:02:36 --> Config Class Initialized
INFO - 2020-01-27 08:02:36 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:02:37 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:02:37 --> Utf8 Class Initialized
INFO - 2020-01-27 08:02:37 --> URI Class Initialized
INFO - 2020-01-27 08:02:37 --> Router Class Initialized
INFO - 2020-01-27 08:02:37 --> Output Class Initialized
INFO - 2020-01-27 08:02:37 --> Security Class Initialized
DEBUG - 2020-01-27 08:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:02:37 --> Input Class Initialized
INFO - 2020-01-27 08:02:37 --> Language Class Initialized
ERROR - 2020-01-27 08:02:37 --> Severity: error --> Exception: syntax error, unexpected '.' E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 514
INFO - 2020-01-27 08:03:34 --> Config Class Initialized
INFO - 2020-01-27 08:03:34 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:03:34 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:03:34 --> Utf8 Class Initialized
INFO - 2020-01-27 08:03:34 --> URI Class Initialized
INFO - 2020-01-27 08:03:34 --> Router Class Initialized
INFO - 2020-01-27 08:03:34 --> Output Class Initialized
INFO - 2020-01-27 08:03:34 --> Security Class Initialized
DEBUG - 2020-01-27 08:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:03:34 --> Input Class Initialized
INFO - 2020-01-27 08:03:34 --> Language Class Initialized
INFO - 2020-01-27 08:03:34 --> Language Class Initialized
INFO - 2020-01-27 08:03:34 --> Config Class Initialized
INFO - 2020-01-27 08:03:34 --> Loader Class Initialized
INFO - 2020-01-27 08:03:34 --> Helper loaded: url_helper
INFO - 2020-01-27 08:03:34 --> Helper loaded: file_helper
INFO - 2020-01-27 08:03:34 --> Helper loaded: form_helper
INFO - 2020-01-27 08:03:34 --> Helper loaded: my_helper
INFO - 2020-01-27 08:03:34 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:03:34 --> Controller Class Initialized
DEBUG - 2020-01-27 08:03:34 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:03:34 --> Final output sent to browser
DEBUG - 2020-01-27 08:03:34 --> Total execution time: 0.5591
INFO - 2020-01-27 08:04:27 --> Config Class Initialized
INFO - 2020-01-27 08:04:27 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:04:27 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:04:27 --> Utf8 Class Initialized
INFO - 2020-01-27 08:04:27 --> URI Class Initialized
INFO - 2020-01-27 08:04:27 --> Router Class Initialized
INFO - 2020-01-27 08:04:27 --> Output Class Initialized
INFO - 2020-01-27 08:04:27 --> Security Class Initialized
DEBUG - 2020-01-27 08:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:04:28 --> Input Class Initialized
INFO - 2020-01-27 08:04:28 --> Language Class Initialized
INFO - 2020-01-27 08:04:28 --> Language Class Initialized
INFO - 2020-01-27 08:04:28 --> Config Class Initialized
INFO - 2020-01-27 08:04:28 --> Loader Class Initialized
INFO - 2020-01-27 08:04:28 --> Helper loaded: url_helper
INFO - 2020-01-27 08:04:28 --> Helper loaded: file_helper
INFO - 2020-01-27 08:04:28 --> Helper loaded: form_helper
INFO - 2020-01-27 08:04:28 --> Helper loaded: my_helper
INFO - 2020-01-27 08:04:28 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:04:28 --> Controller Class Initialized
DEBUG - 2020-01-27 08:04:28 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:04:28 --> Final output sent to browser
DEBUG - 2020-01-27 08:04:28 --> Total execution time: 0.5192
INFO - 2020-01-27 08:04:40 --> Config Class Initialized
INFO - 2020-01-27 08:04:40 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:04:40 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:04:40 --> Utf8 Class Initialized
INFO - 2020-01-27 08:04:40 --> URI Class Initialized
INFO - 2020-01-27 08:04:40 --> Router Class Initialized
INFO - 2020-01-27 08:04:40 --> Output Class Initialized
INFO - 2020-01-27 08:04:40 --> Security Class Initialized
DEBUG - 2020-01-27 08:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:04:40 --> Input Class Initialized
INFO - 2020-01-27 08:04:40 --> Language Class Initialized
INFO - 2020-01-27 08:04:40 --> Language Class Initialized
INFO - 2020-01-27 08:04:40 --> Config Class Initialized
INFO - 2020-01-27 08:04:40 --> Loader Class Initialized
INFO - 2020-01-27 08:04:40 --> Helper loaded: url_helper
INFO - 2020-01-27 08:04:40 --> Helper loaded: file_helper
INFO - 2020-01-27 08:04:40 --> Helper loaded: form_helper
INFO - 2020-01-27 08:04:40 --> Helper loaded: my_helper
INFO - 2020-01-27 08:04:40 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:04:40 --> Controller Class Initialized
DEBUG - 2020-01-27 08:04:41 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:04:41 --> Final output sent to browser
DEBUG - 2020-01-27 08:04:41 --> Total execution time: 0.5170
INFO - 2020-01-27 08:04:48 --> Config Class Initialized
INFO - 2020-01-27 08:04:48 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:04:48 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:04:48 --> Utf8 Class Initialized
INFO - 2020-01-27 08:04:48 --> URI Class Initialized
INFO - 2020-01-27 08:04:48 --> Router Class Initialized
INFO - 2020-01-27 08:04:48 --> Output Class Initialized
INFO - 2020-01-27 08:04:48 --> Security Class Initialized
DEBUG - 2020-01-27 08:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:04:48 --> Input Class Initialized
INFO - 2020-01-27 08:04:49 --> Language Class Initialized
INFO - 2020-01-27 08:04:49 --> Language Class Initialized
INFO - 2020-01-27 08:04:49 --> Config Class Initialized
INFO - 2020-01-27 08:04:49 --> Loader Class Initialized
INFO - 2020-01-27 08:04:49 --> Helper loaded: url_helper
INFO - 2020-01-27 08:04:49 --> Helper loaded: file_helper
INFO - 2020-01-27 08:04:49 --> Helper loaded: form_helper
INFO - 2020-01-27 08:04:49 --> Helper loaded: my_helper
INFO - 2020-01-27 08:04:49 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:04:49 --> Controller Class Initialized
DEBUG - 2020-01-27 08:04:49 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:04:49 --> Final output sent to browser
DEBUG - 2020-01-27 08:04:49 --> Total execution time: 0.5178
INFO - 2020-01-27 08:06:32 --> Config Class Initialized
INFO - 2020-01-27 08:06:32 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:06:32 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:06:32 --> Utf8 Class Initialized
INFO - 2020-01-27 08:06:32 --> URI Class Initialized
INFO - 2020-01-27 08:06:32 --> Router Class Initialized
INFO - 2020-01-27 08:06:32 --> Output Class Initialized
INFO - 2020-01-27 08:06:32 --> Security Class Initialized
DEBUG - 2020-01-27 08:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:06:33 --> Input Class Initialized
INFO - 2020-01-27 08:06:33 --> Language Class Initialized
INFO - 2020-01-27 08:06:33 --> Language Class Initialized
INFO - 2020-01-27 08:06:33 --> Config Class Initialized
INFO - 2020-01-27 08:06:33 --> Loader Class Initialized
INFO - 2020-01-27 08:06:33 --> Helper loaded: url_helper
INFO - 2020-01-27 08:06:33 --> Helper loaded: file_helper
INFO - 2020-01-27 08:06:33 --> Helper loaded: form_helper
INFO - 2020-01-27 08:06:33 --> Helper loaded: my_helper
INFO - 2020-01-27 08:06:33 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:06:33 --> Controller Class Initialized
DEBUG - 2020-01-27 08:06:33 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:06:33 --> Final output sent to browser
DEBUG - 2020-01-27 08:06:33 --> Total execution time: 0.5361
INFO - 2020-01-27 08:07:50 --> Config Class Initialized
INFO - 2020-01-27 08:07:50 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:07:50 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:07:50 --> Utf8 Class Initialized
INFO - 2020-01-27 08:07:50 --> URI Class Initialized
INFO - 2020-01-27 08:07:50 --> Router Class Initialized
INFO - 2020-01-27 08:07:50 --> Output Class Initialized
INFO - 2020-01-27 08:07:50 --> Security Class Initialized
DEBUG - 2020-01-27 08:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:07:50 --> Input Class Initialized
INFO - 2020-01-27 08:07:50 --> Language Class Initialized
INFO - 2020-01-27 08:07:50 --> Language Class Initialized
INFO - 2020-01-27 08:07:50 --> Config Class Initialized
INFO - 2020-01-27 08:07:50 --> Loader Class Initialized
INFO - 2020-01-27 08:07:50 --> Helper loaded: url_helper
INFO - 2020-01-27 08:07:50 --> Helper loaded: file_helper
INFO - 2020-01-27 08:07:50 --> Helper loaded: form_helper
INFO - 2020-01-27 08:07:50 --> Helper loaded: my_helper
INFO - 2020-01-27 08:07:50 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:07:50 --> Controller Class Initialized
DEBUG - 2020-01-27 08:07:50 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:07:50 --> Final output sent to browser
DEBUG - 2020-01-27 08:07:50 --> Total execution time: 0.5030
INFO - 2020-01-27 08:10:10 --> Config Class Initialized
INFO - 2020-01-27 08:10:10 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:10:10 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:10:10 --> Utf8 Class Initialized
INFO - 2020-01-27 08:10:10 --> URI Class Initialized
INFO - 2020-01-27 08:10:10 --> Router Class Initialized
INFO - 2020-01-27 08:10:10 --> Output Class Initialized
INFO - 2020-01-27 08:10:10 --> Security Class Initialized
DEBUG - 2020-01-27 08:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:10:10 --> Input Class Initialized
INFO - 2020-01-27 08:10:10 --> Language Class Initialized
INFO - 2020-01-27 08:10:10 --> Language Class Initialized
INFO - 2020-01-27 08:10:10 --> Config Class Initialized
INFO - 2020-01-27 08:10:10 --> Loader Class Initialized
INFO - 2020-01-27 08:10:10 --> Helper loaded: url_helper
INFO - 2020-01-27 08:10:10 --> Helper loaded: file_helper
INFO - 2020-01-27 08:10:10 --> Helper loaded: form_helper
INFO - 2020-01-27 08:10:10 --> Helper loaded: my_helper
INFO - 2020-01-27 08:10:10 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:10:10 --> Controller Class Initialized
DEBUG - 2020-01-27 08:10:10 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:10:10 --> Final output sent to browser
DEBUG - 2020-01-27 08:10:10 --> Total execution time: 0.5176
INFO - 2020-01-27 08:10:51 --> Config Class Initialized
INFO - 2020-01-27 08:10:51 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:10:51 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:10:51 --> Utf8 Class Initialized
INFO - 2020-01-27 08:10:51 --> URI Class Initialized
INFO - 2020-01-27 08:10:51 --> Router Class Initialized
INFO - 2020-01-27 08:10:51 --> Output Class Initialized
INFO - 2020-01-27 08:10:51 --> Security Class Initialized
DEBUG - 2020-01-27 08:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:10:51 --> Input Class Initialized
INFO - 2020-01-27 08:10:51 --> Language Class Initialized
INFO - 2020-01-27 08:10:51 --> Language Class Initialized
INFO - 2020-01-27 08:10:51 --> Config Class Initialized
INFO - 2020-01-27 08:10:51 --> Loader Class Initialized
INFO - 2020-01-27 08:10:51 --> Helper loaded: url_helper
INFO - 2020-01-27 08:10:51 --> Helper loaded: file_helper
INFO - 2020-01-27 08:10:51 --> Helper loaded: form_helper
INFO - 2020-01-27 08:10:51 --> Helper loaded: my_helper
INFO - 2020-01-27 08:10:51 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:10:51 --> Controller Class Initialized
INFO - 2020-01-27 08:10:51 --> Final output sent to browser
DEBUG - 2020-01-27 08:10:51 --> Total execution time: 0.4450
INFO - 2020-01-27 08:10:57 --> Config Class Initialized
INFO - 2020-01-27 08:10:57 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:10:57 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:10:57 --> Utf8 Class Initialized
INFO - 2020-01-27 08:10:57 --> URI Class Initialized
INFO - 2020-01-27 08:10:57 --> Router Class Initialized
INFO - 2020-01-27 08:10:57 --> Output Class Initialized
INFO - 2020-01-27 08:10:57 --> Security Class Initialized
DEBUG - 2020-01-27 08:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:10:57 --> Input Class Initialized
INFO - 2020-01-27 08:10:57 --> Language Class Initialized
INFO - 2020-01-27 08:10:57 --> Language Class Initialized
INFO - 2020-01-27 08:10:58 --> Config Class Initialized
INFO - 2020-01-27 08:10:58 --> Loader Class Initialized
INFO - 2020-01-27 08:10:58 --> Helper loaded: url_helper
INFO - 2020-01-27 08:10:58 --> Helper loaded: file_helper
INFO - 2020-01-27 08:10:58 --> Helper loaded: form_helper
INFO - 2020-01-27 08:10:58 --> Helper loaded: my_helper
INFO - 2020-01-27 08:10:58 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:10:58 --> Controller Class Initialized
DEBUG - 2020-01-27 08:10:58 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:10:58 --> Final output sent to browser
DEBUG - 2020-01-27 08:10:58 --> Total execution time: 0.5395
INFO - 2020-01-27 08:11:39 --> Config Class Initialized
INFO - 2020-01-27 08:11:39 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:11:39 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:11:39 --> Utf8 Class Initialized
INFO - 2020-01-27 08:11:39 --> URI Class Initialized
INFO - 2020-01-27 08:11:39 --> Router Class Initialized
INFO - 2020-01-27 08:11:39 --> Output Class Initialized
INFO - 2020-01-27 08:11:39 --> Security Class Initialized
DEBUG - 2020-01-27 08:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:11:39 --> Input Class Initialized
INFO - 2020-01-27 08:11:39 --> Language Class Initialized
INFO - 2020-01-27 08:11:39 --> Language Class Initialized
INFO - 2020-01-27 08:11:39 --> Config Class Initialized
INFO - 2020-01-27 08:11:39 --> Loader Class Initialized
INFO - 2020-01-27 08:11:39 --> Helper loaded: url_helper
INFO - 2020-01-27 08:11:39 --> Helper loaded: file_helper
INFO - 2020-01-27 08:11:39 --> Helper loaded: form_helper
INFO - 2020-01-27 08:11:39 --> Helper loaded: my_helper
INFO - 2020-01-27 08:11:39 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:11:39 --> Controller Class Initialized
INFO - 2020-01-27 08:11:39 --> Final output sent to browser
DEBUG - 2020-01-27 08:11:39 --> Total execution time: 0.4765
INFO - 2020-01-27 08:11:43 --> Config Class Initialized
INFO - 2020-01-27 08:11:43 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:11:43 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:11:43 --> Utf8 Class Initialized
INFO - 2020-01-27 08:11:43 --> URI Class Initialized
INFO - 2020-01-27 08:11:43 --> Router Class Initialized
INFO - 2020-01-27 08:11:43 --> Output Class Initialized
INFO - 2020-01-27 08:11:43 --> Security Class Initialized
DEBUG - 2020-01-27 08:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:11:43 --> Input Class Initialized
INFO - 2020-01-27 08:11:43 --> Language Class Initialized
INFO - 2020-01-27 08:11:43 --> Language Class Initialized
INFO - 2020-01-27 08:11:43 --> Config Class Initialized
INFO - 2020-01-27 08:11:43 --> Loader Class Initialized
INFO - 2020-01-27 08:11:43 --> Helper loaded: url_helper
INFO - 2020-01-27 08:11:43 --> Helper loaded: file_helper
INFO - 2020-01-27 08:11:43 --> Helper loaded: form_helper
INFO - 2020-01-27 08:11:43 --> Helper loaded: my_helper
INFO - 2020-01-27 08:11:43 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:11:43 --> Controller Class Initialized
DEBUG - 2020-01-27 08:11:43 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:11:43 --> Final output sent to browser
DEBUG - 2020-01-27 08:11:43 --> Total execution time: 0.5064
INFO - 2020-01-27 08:16:50 --> Config Class Initialized
INFO - 2020-01-27 08:16:51 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:16:51 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:16:51 --> Utf8 Class Initialized
INFO - 2020-01-27 08:16:51 --> URI Class Initialized
INFO - 2020-01-27 08:16:51 --> Router Class Initialized
INFO - 2020-01-27 08:16:51 --> Output Class Initialized
INFO - 2020-01-27 08:16:51 --> Security Class Initialized
DEBUG - 2020-01-27 08:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:16:51 --> Input Class Initialized
INFO - 2020-01-27 08:16:51 --> Language Class Initialized
INFO - 2020-01-27 08:16:51 --> Language Class Initialized
INFO - 2020-01-27 08:16:51 --> Config Class Initialized
INFO - 2020-01-27 08:16:51 --> Loader Class Initialized
INFO - 2020-01-27 08:16:51 --> Helper loaded: url_helper
INFO - 2020-01-27 08:16:51 --> Helper loaded: file_helper
INFO - 2020-01-27 08:16:51 --> Helper loaded: form_helper
INFO - 2020-01-27 08:16:51 --> Helper loaded: my_helper
INFO - 2020-01-27 08:16:51 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:16:51 --> Controller Class Initialized
DEBUG - 2020-01-27 08:16:51 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:16:51 --> Final output sent to browser
DEBUG - 2020-01-27 08:16:51 --> Total execution time: 0.5007
INFO - 2020-01-27 08:16:59 --> Config Class Initialized
INFO - 2020-01-27 08:17:00 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:17:00 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:17:00 --> Utf8 Class Initialized
INFO - 2020-01-27 08:17:00 --> URI Class Initialized
INFO - 2020-01-27 08:17:00 --> Router Class Initialized
INFO - 2020-01-27 08:17:00 --> Output Class Initialized
INFO - 2020-01-27 08:17:00 --> Security Class Initialized
DEBUG - 2020-01-27 08:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:17:00 --> Input Class Initialized
INFO - 2020-01-27 08:17:00 --> Language Class Initialized
INFO - 2020-01-27 08:17:00 --> Language Class Initialized
INFO - 2020-01-27 08:17:00 --> Config Class Initialized
INFO - 2020-01-27 08:17:00 --> Loader Class Initialized
INFO - 2020-01-27 08:17:00 --> Helper loaded: url_helper
INFO - 2020-01-27 08:17:00 --> Helper loaded: file_helper
INFO - 2020-01-27 08:17:00 --> Helper loaded: form_helper
INFO - 2020-01-27 08:17:00 --> Helper loaded: my_helper
INFO - 2020-01-27 08:17:00 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:17:00 --> Controller Class Initialized
DEBUG - 2020-01-27 08:17:00 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:17:00 --> Final output sent to browser
DEBUG - 2020-01-27 08:17:00 --> Total execution time: 0.6229
INFO - 2020-01-27 08:17:20 --> Config Class Initialized
INFO - 2020-01-27 08:17:20 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:17:20 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:17:20 --> Utf8 Class Initialized
INFO - 2020-01-27 08:17:20 --> URI Class Initialized
INFO - 2020-01-27 08:17:20 --> Router Class Initialized
INFO - 2020-01-27 08:17:20 --> Output Class Initialized
INFO - 2020-01-27 08:17:20 --> Security Class Initialized
DEBUG - 2020-01-27 08:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:17:20 --> Input Class Initialized
INFO - 2020-01-27 08:17:20 --> Language Class Initialized
INFO - 2020-01-27 08:17:20 --> Language Class Initialized
INFO - 2020-01-27 08:17:20 --> Config Class Initialized
INFO - 2020-01-27 08:17:20 --> Loader Class Initialized
INFO - 2020-01-27 08:17:20 --> Helper loaded: url_helper
INFO - 2020-01-27 08:17:20 --> Helper loaded: file_helper
INFO - 2020-01-27 08:17:20 --> Helper loaded: form_helper
INFO - 2020-01-27 08:17:20 --> Helper loaded: my_helper
INFO - 2020-01-27 08:17:20 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:17:20 --> Controller Class Initialized
DEBUG - 2020-01-27 08:17:20 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:17:20 --> Final output sent to browser
DEBUG - 2020-01-27 08:17:20 --> Total execution time: 0.5095
INFO - 2020-01-27 08:17:27 --> Config Class Initialized
INFO - 2020-01-27 08:17:27 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:17:27 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:17:27 --> Utf8 Class Initialized
INFO - 2020-01-27 08:17:27 --> URI Class Initialized
INFO - 2020-01-27 08:17:27 --> Router Class Initialized
INFO - 2020-01-27 08:17:27 --> Output Class Initialized
INFO - 2020-01-27 08:17:27 --> Security Class Initialized
DEBUG - 2020-01-27 08:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:17:27 --> Input Class Initialized
INFO - 2020-01-27 08:17:27 --> Language Class Initialized
INFO - 2020-01-27 08:17:27 --> Language Class Initialized
INFO - 2020-01-27 08:17:27 --> Config Class Initialized
INFO - 2020-01-27 08:17:27 --> Loader Class Initialized
INFO - 2020-01-27 08:17:27 --> Helper loaded: url_helper
INFO - 2020-01-27 08:17:27 --> Helper loaded: file_helper
INFO - 2020-01-27 08:17:27 --> Helper loaded: form_helper
INFO - 2020-01-27 08:17:27 --> Helper loaded: my_helper
INFO - 2020-01-27 08:17:27 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:17:27 --> Controller Class Initialized
DEBUG - 2020-01-27 08:17:27 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:17:27 --> Final output sent to browser
DEBUG - 2020-01-27 08:17:27 --> Total execution time: 0.5041
INFO - 2020-01-27 08:18:36 --> Config Class Initialized
INFO - 2020-01-27 08:18:36 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:18:36 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:18:36 --> Utf8 Class Initialized
INFO - 2020-01-27 08:18:36 --> URI Class Initialized
INFO - 2020-01-27 08:18:36 --> Router Class Initialized
INFO - 2020-01-27 08:18:36 --> Output Class Initialized
INFO - 2020-01-27 08:18:36 --> Security Class Initialized
DEBUG - 2020-01-27 08:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:18:36 --> Input Class Initialized
INFO - 2020-01-27 08:18:36 --> Language Class Initialized
ERROR - 2020-01-27 08:18:36 --> Severity: error --> Exception: syntax error, unexpected '.' E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 514
INFO - 2020-01-27 08:18:54 --> Config Class Initialized
INFO - 2020-01-27 08:18:54 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:18:55 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:18:55 --> Utf8 Class Initialized
INFO - 2020-01-27 08:18:55 --> URI Class Initialized
INFO - 2020-01-27 08:18:55 --> Router Class Initialized
INFO - 2020-01-27 08:18:55 --> Output Class Initialized
INFO - 2020-01-27 08:18:55 --> Security Class Initialized
DEBUG - 2020-01-27 08:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:18:55 --> Input Class Initialized
INFO - 2020-01-27 08:18:55 --> Language Class Initialized
INFO - 2020-01-27 08:18:55 --> Language Class Initialized
INFO - 2020-01-27 08:18:55 --> Config Class Initialized
INFO - 2020-01-27 08:18:55 --> Loader Class Initialized
INFO - 2020-01-27 08:18:55 --> Helper loaded: url_helper
INFO - 2020-01-27 08:18:55 --> Helper loaded: file_helper
INFO - 2020-01-27 08:18:55 --> Helper loaded: form_helper
INFO - 2020-01-27 08:18:55 --> Helper loaded: my_helper
INFO - 2020-01-27 08:18:55 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:18:55 --> Controller Class Initialized
DEBUG - 2020-01-27 08:18:55 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:18:55 --> Final output sent to browser
DEBUG - 2020-01-27 08:18:55 --> Total execution time: 0.5392
INFO - 2020-01-27 08:20:15 --> Config Class Initialized
INFO - 2020-01-27 08:20:15 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:20:15 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:20:15 --> Utf8 Class Initialized
INFO - 2020-01-27 08:20:15 --> URI Class Initialized
INFO - 2020-01-27 08:20:15 --> Router Class Initialized
INFO - 2020-01-27 08:20:15 --> Output Class Initialized
INFO - 2020-01-27 08:20:15 --> Security Class Initialized
DEBUG - 2020-01-27 08:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:20:15 --> Input Class Initialized
INFO - 2020-01-27 08:20:15 --> Language Class Initialized
INFO - 2020-01-27 08:20:15 --> Language Class Initialized
INFO - 2020-01-27 08:20:15 --> Config Class Initialized
INFO - 2020-01-27 08:20:15 --> Loader Class Initialized
INFO - 2020-01-27 08:20:15 --> Helper loaded: url_helper
INFO - 2020-01-27 08:20:15 --> Helper loaded: file_helper
INFO - 2020-01-27 08:20:15 --> Helper loaded: form_helper
INFO - 2020-01-27 08:20:15 --> Helper loaded: my_helper
INFO - 2020-01-27 08:20:15 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:20:15 --> Controller Class Initialized
DEBUG - 2020-01-27 08:20:15 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:20:15 --> Final output sent to browser
DEBUG - 2020-01-27 08:20:15 --> Total execution time: 0.5103
INFO - 2020-01-27 08:22:04 --> Config Class Initialized
INFO - 2020-01-27 08:22:04 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:22:05 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:22:05 --> Utf8 Class Initialized
INFO - 2020-01-27 08:22:05 --> URI Class Initialized
INFO - 2020-01-27 08:22:05 --> Router Class Initialized
INFO - 2020-01-27 08:22:05 --> Output Class Initialized
INFO - 2020-01-27 08:22:05 --> Security Class Initialized
DEBUG - 2020-01-27 08:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:22:05 --> Input Class Initialized
INFO - 2020-01-27 08:22:05 --> Language Class Initialized
INFO - 2020-01-27 08:22:05 --> Language Class Initialized
INFO - 2020-01-27 08:22:05 --> Config Class Initialized
INFO - 2020-01-27 08:22:05 --> Loader Class Initialized
INFO - 2020-01-27 08:22:05 --> Helper loaded: url_helper
INFO - 2020-01-27 08:22:05 --> Helper loaded: file_helper
INFO - 2020-01-27 08:22:05 --> Helper loaded: form_helper
INFO - 2020-01-27 08:22:05 --> Helper loaded: my_helper
INFO - 2020-01-27 08:22:05 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:22:05 --> Controller Class Initialized
DEBUG - 2020-01-27 08:22:05 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:22:05 --> Final output sent to browser
DEBUG - 2020-01-27 08:22:05 --> Total execution time: 0.5266
INFO - 2020-01-27 08:22:21 --> Config Class Initialized
INFO - 2020-01-27 08:22:21 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:22:21 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:22:21 --> Utf8 Class Initialized
INFO - 2020-01-27 08:22:21 --> URI Class Initialized
INFO - 2020-01-27 08:22:21 --> Router Class Initialized
INFO - 2020-01-27 08:22:21 --> Output Class Initialized
INFO - 2020-01-27 08:22:21 --> Security Class Initialized
DEBUG - 2020-01-27 08:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:22:21 --> Input Class Initialized
INFO - 2020-01-27 08:22:21 --> Language Class Initialized
INFO - 2020-01-27 08:22:21 --> Language Class Initialized
INFO - 2020-01-27 08:22:22 --> Config Class Initialized
INFO - 2020-01-27 08:22:22 --> Loader Class Initialized
INFO - 2020-01-27 08:22:22 --> Helper loaded: url_helper
INFO - 2020-01-27 08:22:22 --> Helper loaded: file_helper
INFO - 2020-01-27 08:22:22 --> Helper loaded: form_helper
INFO - 2020-01-27 08:22:22 --> Helper loaded: my_helper
INFO - 2020-01-27 08:22:22 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:22:22 --> Controller Class Initialized
DEBUG - 2020-01-27 08:22:22 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:22:22 --> Final output sent to browser
DEBUG - 2020-01-27 08:22:22 --> Total execution time: 0.5127
INFO - 2020-01-27 08:24:55 --> Config Class Initialized
INFO - 2020-01-27 08:24:55 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:24:55 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:24:55 --> Utf8 Class Initialized
INFO - 2020-01-27 08:24:55 --> URI Class Initialized
INFO - 2020-01-27 08:24:55 --> Router Class Initialized
INFO - 2020-01-27 08:24:55 --> Output Class Initialized
INFO - 2020-01-27 08:24:55 --> Security Class Initialized
DEBUG - 2020-01-27 08:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:24:55 --> Input Class Initialized
INFO - 2020-01-27 08:24:55 --> Language Class Initialized
INFO - 2020-01-27 08:24:55 --> Language Class Initialized
INFO - 2020-01-27 08:24:55 --> Config Class Initialized
INFO - 2020-01-27 08:24:55 --> Loader Class Initialized
INFO - 2020-01-27 08:24:55 --> Helper loaded: url_helper
INFO - 2020-01-27 08:24:55 --> Helper loaded: file_helper
INFO - 2020-01-27 08:24:55 --> Helper loaded: form_helper
INFO - 2020-01-27 08:24:55 --> Helper loaded: my_helper
INFO - 2020-01-27 08:24:55 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:24:55 --> Controller Class Initialized
DEBUG - 2020-01-27 08:24:55 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:24:55 --> Final output sent to browser
DEBUG - 2020-01-27 08:24:55 --> Total execution time: 0.5128
INFO - 2020-01-27 08:29:33 --> Config Class Initialized
INFO - 2020-01-27 08:29:33 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:29:33 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:29:33 --> Utf8 Class Initialized
INFO - 2020-01-27 08:29:33 --> URI Class Initialized
INFO - 2020-01-27 08:29:33 --> Router Class Initialized
INFO - 2020-01-27 08:29:33 --> Output Class Initialized
INFO - 2020-01-27 08:29:33 --> Security Class Initialized
DEBUG - 2020-01-27 08:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:29:34 --> Input Class Initialized
INFO - 2020-01-27 08:29:34 --> Language Class Initialized
INFO - 2020-01-27 08:29:34 --> Language Class Initialized
INFO - 2020-01-27 08:29:34 --> Config Class Initialized
INFO - 2020-01-27 08:29:34 --> Loader Class Initialized
INFO - 2020-01-27 08:29:34 --> Helper loaded: url_helper
INFO - 2020-01-27 08:29:34 --> Helper loaded: file_helper
INFO - 2020-01-27 08:29:34 --> Helper loaded: form_helper
INFO - 2020-01-27 08:29:34 --> Helper loaded: my_helper
INFO - 2020-01-27 08:29:34 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:29:34 --> Controller Class Initialized
DEBUG - 2020-01-27 08:29:34 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:29:34 --> Final output sent to browser
DEBUG - 2020-01-27 08:29:34 --> Total execution time: 0.5245
INFO - 2020-01-27 08:32:10 --> Config Class Initialized
INFO - 2020-01-27 08:32:10 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:32:10 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:32:10 --> Utf8 Class Initialized
INFO - 2020-01-27 08:32:10 --> URI Class Initialized
INFO - 2020-01-27 08:32:10 --> Router Class Initialized
INFO - 2020-01-27 08:32:10 --> Output Class Initialized
INFO - 2020-01-27 08:32:10 --> Security Class Initialized
DEBUG - 2020-01-27 08:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:32:10 --> Input Class Initialized
INFO - 2020-01-27 08:32:10 --> Language Class Initialized
INFO - 2020-01-27 08:32:10 --> Language Class Initialized
INFO - 2020-01-27 08:32:10 --> Config Class Initialized
INFO - 2020-01-27 08:32:10 --> Loader Class Initialized
INFO - 2020-01-27 08:32:10 --> Helper loaded: url_helper
INFO - 2020-01-27 08:32:10 --> Helper loaded: file_helper
INFO - 2020-01-27 08:32:10 --> Helper loaded: form_helper
INFO - 2020-01-27 08:32:10 --> Helper loaded: my_helper
INFO - 2020-01-27 08:32:10 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:32:11 --> Controller Class Initialized
DEBUG - 2020-01-27 08:32:11 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:32:11 --> Final output sent to browser
DEBUG - 2020-01-27 08:32:11 --> Total execution time: 0.4832
INFO - 2020-01-27 08:35:22 --> Config Class Initialized
INFO - 2020-01-27 08:35:22 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:35:22 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:35:22 --> Utf8 Class Initialized
INFO - 2020-01-27 08:35:22 --> URI Class Initialized
INFO - 2020-01-27 08:35:22 --> Router Class Initialized
INFO - 2020-01-27 08:35:22 --> Output Class Initialized
INFO - 2020-01-27 08:35:22 --> Security Class Initialized
DEBUG - 2020-01-27 08:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:35:22 --> Input Class Initialized
INFO - 2020-01-27 08:35:22 --> Language Class Initialized
INFO - 2020-01-27 08:35:22 --> Language Class Initialized
INFO - 2020-01-27 08:35:22 --> Config Class Initialized
INFO - 2020-01-27 08:35:22 --> Loader Class Initialized
INFO - 2020-01-27 08:35:22 --> Helper loaded: url_helper
INFO - 2020-01-27 08:35:22 --> Helper loaded: file_helper
INFO - 2020-01-27 08:35:22 --> Helper loaded: form_helper
INFO - 2020-01-27 08:35:22 --> Helper loaded: my_helper
INFO - 2020-01-27 08:35:22 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:35:22 --> Controller Class Initialized
INFO - 2020-01-27 08:36:27 --> Config Class Initialized
INFO - 2020-01-27 08:36:27 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:36:27 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:36:27 --> Utf8 Class Initialized
INFO - 2020-01-27 08:36:27 --> URI Class Initialized
INFO - 2020-01-27 08:36:27 --> Router Class Initialized
INFO - 2020-01-27 08:36:27 --> Output Class Initialized
INFO - 2020-01-27 08:36:27 --> Security Class Initialized
DEBUG - 2020-01-27 08:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:36:27 --> Input Class Initialized
INFO - 2020-01-27 08:36:27 --> Language Class Initialized
INFO - 2020-01-27 08:36:28 --> Language Class Initialized
INFO - 2020-01-27 08:36:28 --> Config Class Initialized
INFO - 2020-01-27 08:36:28 --> Loader Class Initialized
INFO - 2020-01-27 08:36:28 --> Helper loaded: url_helper
INFO - 2020-01-27 08:36:28 --> Helper loaded: file_helper
INFO - 2020-01-27 08:36:28 --> Helper loaded: form_helper
INFO - 2020-01-27 08:36:28 --> Helper loaded: my_helper
INFO - 2020-01-27 08:36:28 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:36:28 --> Controller Class Initialized
DEBUG - 2020-01-27 08:36:28 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:36:28 --> Final output sent to browser
DEBUG - 2020-01-27 08:36:28 --> Total execution time: 0.5157
INFO - 2020-01-27 08:43:07 --> Config Class Initialized
INFO - 2020-01-27 08:43:07 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:43:07 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:43:07 --> Utf8 Class Initialized
INFO - 2020-01-27 08:43:07 --> URI Class Initialized
INFO - 2020-01-27 08:43:07 --> Router Class Initialized
INFO - 2020-01-27 08:43:07 --> Output Class Initialized
INFO - 2020-01-27 08:43:07 --> Security Class Initialized
DEBUG - 2020-01-27 08:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:43:07 --> Input Class Initialized
INFO - 2020-01-27 08:43:07 --> Language Class Initialized
INFO - 2020-01-27 08:43:07 --> Language Class Initialized
INFO - 2020-01-27 08:43:07 --> Config Class Initialized
INFO - 2020-01-27 08:43:07 --> Loader Class Initialized
INFO - 2020-01-27 08:43:07 --> Helper loaded: url_helper
INFO - 2020-01-27 08:43:07 --> Helper loaded: file_helper
INFO - 2020-01-27 08:43:07 --> Helper loaded: form_helper
INFO - 2020-01-27 08:43:07 --> Helper loaded: my_helper
INFO - 2020-01-27 08:43:07 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:43:07 --> Controller Class Initialized
DEBUG - 2020-01-27 08:43:07 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:43:07 --> Final output sent to browser
DEBUG - 2020-01-27 08:43:07 --> Total execution time: 0.5175
INFO - 2020-01-27 08:43:51 --> Config Class Initialized
INFO - 2020-01-27 08:43:51 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:43:51 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:43:51 --> Utf8 Class Initialized
INFO - 2020-01-27 08:43:51 --> URI Class Initialized
INFO - 2020-01-27 08:43:51 --> Router Class Initialized
INFO - 2020-01-27 08:43:51 --> Output Class Initialized
INFO - 2020-01-27 08:43:51 --> Security Class Initialized
DEBUG - 2020-01-27 08:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:43:51 --> Input Class Initialized
INFO - 2020-01-27 08:43:51 --> Language Class Initialized
INFO - 2020-01-27 08:43:51 --> Language Class Initialized
INFO - 2020-01-27 08:43:51 --> Config Class Initialized
INFO - 2020-01-27 08:43:51 --> Loader Class Initialized
INFO - 2020-01-27 08:43:52 --> Helper loaded: url_helper
INFO - 2020-01-27 08:43:52 --> Helper loaded: file_helper
INFO - 2020-01-27 08:43:52 --> Helper loaded: form_helper
INFO - 2020-01-27 08:43:52 --> Helper loaded: my_helper
INFO - 2020-01-27 08:43:52 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:43:52 --> Controller Class Initialized
INFO - 2020-01-27 08:43:52 --> Final output sent to browser
DEBUG - 2020-01-27 08:43:52 --> Total execution time: 0.4619
INFO - 2020-01-27 08:43:54 --> Config Class Initialized
INFO - 2020-01-27 08:43:54 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:43:54 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:43:54 --> Utf8 Class Initialized
INFO - 2020-01-27 08:43:55 --> URI Class Initialized
INFO - 2020-01-27 08:43:55 --> Router Class Initialized
INFO - 2020-01-27 08:43:55 --> Output Class Initialized
INFO - 2020-01-27 08:43:55 --> Security Class Initialized
DEBUG - 2020-01-27 08:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:43:55 --> Input Class Initialized
INFO - 2020-01-27 08:43:55 --> Language Class Initialized
INFO - 2020-01-27 08:43:55 --> Language Class Initialized
INFO - 2020-01-27 08:43:55 --> Config Class Initialized
INFO - 2020-01-27 08:43:55 --> Loader Class Initialized
INFO - 2020-01-27 08:43:55 --> Helper loaded: url_helper
INFO - 2020-01-27 08:43:55 --> Helper loaded: file_helper
INFO - 2020-01-27 08:43:55 --> Helper loaded: form_helper
INFO - 2020-01-27 08:43:55 --> Helper loaded: my_helper
INFO - 2020-01-27 08:43:55 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:43:55 --> Controller Class Initialized
DEBUG - 2020-01-27 08:43:55 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:43:55 --> Final output sent to browser
DEBUG - 2020-01-27 08:43:55 --> Total execution time: 0.5094
INFO - 2020-01-27 08:44:03 --> Config Class Initialized
INFO - 2020-01-27 08:44:03 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:44:03 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:44:03 --> Utf8 Class Initialized
INFO - 2020-01-27 08:44:03 --> URI Class Initialized
INFO - 2020-01-27 08:44:03 --> Router Class Initialized
INFO - 2020-01-27 08:44:03 --> Output Class Initialized
INFO - 2020-01-27 08:44:03 --> Security Class Initialized
DEBUG - 2020-01-27 08:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:44:03 --> Input Class Initialized
INFO - 2020-01-27 08:44:03 --> Language Class Initialized
INFO - 2020-01-27 08:44:03 --> Language Class Initialized
INFO - 2020-01-27 08:44:03 --> Config Class Initialized
INFO - 2020-01-27 08:44:03 --> Loader Class Initialized
INFO - 2020-01-27 08:44:03 --> Helper loaded: url_helper
INFO - 2020-01-27 08:44:03 --> Helper loaded: file_helper
INFO - 2020-01-27 08:44:03 --> Helper loaded: form_helper
INFO - 2020-01-27 08:44:03 --> Helper loaded: my_helper
INFO - 2020-01-27 08:44:03 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:44:04 --> Controller Class Initialized
INFO - 2020-01-27 08:44:04 --> Final output sent to browser
DEBUG - 2020-01-27 08:44:04 --> Total execution time: 0.5331
INFO - 2020-01-27 08:44:05 --> Config Class Initialized
INFO - 2020-01-27 08:44:05 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:44:05 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:44:06 --> Utf8 Class Initialized
INFO - 2020-01-27 08:44:06 --> URI Class Initialized
INFO - 2020-01-27 08:44:06 --> Router Class Initialized
INFO - 2020-01-27 08:44:06 --> Output Class Initialized
INFO - 2020-01-27 08:44:06 --> Security Class Initialized
DEBUG - 2020-01-27 08:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:44:06 --> Input Class Initialized
INFO - 2020-01-27 08:44:06 --> Language Class Initialized
INFO - 2020-01-27 08:44:06 --> Language Class Initialized
INFO - 2020-01-27 08:44:06 --> Config Class Initialized
INFO - 2020-01-27 08:44:06 --> Loader Class Initialized
INFO - 2020-01-27 08:44:06 --> Helper loaded: url_helper
INFO - 2020-01-27 08:44:06 --> Helper loaded: file_helper
INFO - 2020-01-27 08:44:06 --> Helper loaded: form_helper
INFO - 2020-01-27 08:44:06 --> Helper loaded: my_helper
INFO - 2020-01-27 08:44:06 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:44:06 --> Controller Class Initialized
DEBUG - 2020-01-27 08:44:06 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:44:06 --> Final output sent to browser
DEBUG - 2020-01-27 08:44:06 --> Total execution time: 0.5639
INFO - 2020-01-27 08:45:08 --> Config Class Initialized
INFO - 2020-01-27 08:45:08 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:45:08 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:45:08 --> Utf8 Class Initialized
INFO - 2020-01-27 08:45:08 --> URI Class Initialized
INFO - 2020-01-27 08:45:08 --> Router Class Initialized
INFO - 2020-01-27 08:45:08 --> Output Class Initialized
INFO - 2020-01-27 08:45:08 --> Security Class Initialized
DEBUG - 2020-01-27 08:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:45:08 --> Input Class Initialized
INFO - 2020-01-27 08:45:08 --> Language Class Initialized
INFO - 2020-01-27 08:45:08 --> Language Class Initialized
INFO - 2020-01-27 08:45:09 --> Config Class Initialized
INFO - 2020-01-27 08:45:09 --> Loader Class Initialized
INFO - 2020-01-27 08:45:09 --> Helper loaded: url_helper
INFO - 2020-01-27 08:45:09 --> Helper loaded: file_helper
INFO - 2020-01-27 08:45:09 --> Helper loaded: form_helper
INFO - 2020-01-27 08:45:09 --> Helper loaded: my_helper
INFO - 2020-01-27 08:45:09 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:45:09 --> Controller Class Initialized
DEBUG - 2020-01-27 08:45:09 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:45:09 --> Final output sent to browser
DEBUG - 2020-01-27 08:45:09 --> Total execution time: 0.5043
INFO - 2020-01-27 08:45:20 --> Config Class Initialized
INFO - 2020-01-27 08:45:20 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:45:20 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:45:20 --> Utf8 Class Initialized
INFO - 2020-01-27 08:45:20 --> URI Class Initialized
INFO - 2020-01-27 08:45:20 --> Router Class Initialized
INFO - 2020-01-27 08:45:20 --> Output Class Initialized
INFO - 2020-01-27 08:45:20 --> Security Class Initialized
DEBUG - 2020-01-27 08:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:45:20 --> Input Class Initialized
INFO - 2020-01-27 08:45:20 --> Language Class Initialized
INFO - 2020-01-27 08:45:20 --> Language Class Initialized
INFO - 2020-01-27 08:45:20 --> Config Class Initialized
INFO - 2020-01-27 08:45:20 --> Loader Class Initialized
INFO - 2020-01-27 08:45:20 --> Helper loaded: url_helper
INFO - 2020-01-27 08:45:20 --> Helper loaded: file_helper
INFO - 2020-01-27 08:45:20 --> Helper loaded: form_helper
INFO - 2020-01-27 08:45:20 --> Helper loaded: my_helper
INFO - 2020-01-27 08:45:20 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:45:20 --> Controller Class Initialized
ERROR - 2020-01-27 08:45:20 --> Severity: Notice --> Undefined offset: 1 E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 376
ERROR - 2020-01-27 08:45:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND a.tasm = '20182'' at line 8 - Invalid query: SELECT 
                                b.nama nmmapel, b.kkm, c.nama nmkelas, d.nama nmguru
                                FROM t_guru_mapel a
                                INNER JOIN m_mapel b ON a.id_mapel = b.id 
                                INNER JOIN m_kelas c ON a.id_kelas = c.id
                                INNER JOIN m_guru d ON a.id_guru = d.id 
                                WHERE b.id = 1 AND c.id =  
                                AND a.tasm = '20182'
INFO - 2020-01-27 08:45:20 --> Language file loaded: language/english/db_lang.php
INFO - 2020-01-27 08:45:23 --> Config Class Initialized
INFO - 2020-01-27 08:45:23 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:45:23 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:45:23 --> Utf8 Class Initialized
INFO - 2020-01-27 08:45:23 --> URI Class Initialized
INFO - 2020-01-27 08:45:23 --> Router Class Initialized
INFO - 2020-01-27 08:45:23 --> Output Class Initialized
INFO - 2020-01-27 08:45:23 --> Security Class Initialized
DEBUG - 2020-01-27 08:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:45:23 --> Input Class Initialized
INFO - 2020-01-27 08:45:23 --> Language Class Initialized
INFO - 2020-01-27 08:45:23 --> Language Class Initialized
INFO - 2020-01-27 08:45:23 --> Config Class Initialized
INFO - 2020-01-27 08:45:23 --> Loader Class Initialized
INFO - 2020-01-27 08:45:23 --> Helper loaded: url_helper
INFO - 2020-01-27 08:45:23 --> Helper loaded: file_helper
INFO - 2020-01-27 08:45:23 --> Helper loaded: form_helper
INFO - 2020-01-27 08:45:23 --> Helper loaded: my_helper
INFO - 2020-01-27 08:45:23 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:45:23 --> Controller Class Initialized
ERROR - 2020-01-27 08:45:23 --> Severity: error --> Exception: Too few arguments to function N_keterampilan::cetak(), 0 passed in E:\xampp\htdocs\_2020\nilaik13_ci\system\core\CodeIgniter.php on line 532 and at least 1 expected E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 362
INFO - 2020-01-27 08:45:24 --> Config Class Initialized
INFO - 2020-01-27 08:45:24 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:45:24 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:45:24 --> Utf8 Class Initialized
INFO - 2020-01-27 08:45:24 --> URI Class Initialized
INFO - 2020-01-27 08:45:24 --> Router Class Initialized
INFO - 2020-01-27 08:45:25 --> Output Class Initialized
INFO - 2020-01-27 08:45:25 --> Security Class Initialized
DEBUG - 2020-01-27 08:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:45:25 --> Input Class Initialized
INFO - 2020-01-27 08:45:25 --> Language Class Initialized
INFO - 2020-01-27 08:45:25 --> Language Class Initialized
INFO - 2020-01-27 08:45:25 --> Config Class Initialized
INFO - 2020-01-27 08:45:25 --> Loader Class Initialized
INFO - 2020-01-27 08:45:25 --> Helper loaded: url_helper
INFO - 2020-01-27 08:45:25 --> Helper loaded: file_helper
INFO - 2020-01-27 08:45:25 --> Helper loaded: form_helper
INFO - 2020-01-27 08:45:25 --> Helper loaded: my_helper
INFO - 2020-01-27 08:45:25 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:45:25 --> Controller Class Initialized
ERROR - 2020-01-27 08:45:25 --> Severity: Notice --> Undefined offset: 1 E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 376
INFO - 2020-01-27 08:45:25 --> Config Class Initialized
INFO - 2020-01-27 08:45:25 --> Hooks Class Initialized
ERROR - 2020-01-27 08:45:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND a.tasm = '20182'' at line 8 - Invalid query: SELECT 
                                b.nama nmmapel, b.kkm, c.nama nmkelas, d.nama nmguru
                                FROM t_guru_mapel a
                                INNER JOIN m_mapel b ON a.id_mapel = b.id 
                                INNER JOIN m_kelas c ON a.id_kelas = c.id
                                INNER JOIN m_guru d ON a.id_guru = d.id 
                                WHERE b.id = 1 AND c.id =  
                                AND a.tasm = '20182'
INFO - 2020-01-27 08:45:25 --> Language file loaded: language/english/db_lang.php
DEBUG - 2020-01-27 08:45:25 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:45:25 --> Utf8 Class Initialized
INFO - 2020-01-27 08:45:25 --> URI Class Initialized
INFO - 2020-01-27 08:45:25 --> Router Class Initialized
INFO - 2020-01-27 08:45:25 --> Output Class Initialized
INFO - 2020-01-27 08:45:25 --> Security Class Initialized
DEBUG - 2020-01-27 08:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:45:25 --> Input Class Initialized
INFO - 2020-01-27 08:45:25 --> Language Class Initialized
INFO - 2020-01-27 08:45:25 --> Language Class Initialized
INFO - 2020-01-27 08:45:25 --> Config Class Initialized
INFO - 2020-01-27 08:45:25 --> Loader Class Initialized
INFO - 2020-01-27 08:45:25 --> Helper loaded: url_helper
INFO - 2020-01-27 08:45:25 --> Helper loaded: file_helper
INFO - 2020-01-27 08:45:25 --> Helper loaded: form_helper
INFO - 2020-01-27 08:45:25 --> Helper loaded: my_helper
INFO - 2020-01-27 08:45:25 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:45:25 --> Controller Class Initialized
DEBUG - 2020-01-27 08:45:25 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:45:25 --> Final output sent to browser
DEBUG - 2020-01-27 08:45:25 --> Total execution time: 0.4979
INFO - 2020-01-27 08:45:31 --> Config Class Initialized
INFO - 2020-01-27 08:45:31 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:45:31 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:45:31 --> Utf8 Class Initialized
INFO - 2020-01-27 08:45:31 --> URI Class Initialized
INFO - 2020-01-27 08:45:31 --> Router Class Initialized
INFO - 2020-01-27 08:45:31 --> Output Class Initialized
INFO - 2020-01-27 08:45:31 --> Security Class Initialized
DEBUG - 2020-01-27 08:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:45:31 --> Input Class Initialized
INFO - 2020-01-27 08:45:31 --> Language Class Initialized
INFO - 2020-01-27 08:45:31 --> Language Class Initialized
INFO - 2020-01-27 08:45:31 --> Config Class Initialized
INFO - 2020-01-27 08:45:31 --> Loader Class Initialized
INFO - 2020-01-27 08:45:31 --> Helper loaded: url_helper
INFO - 2020-01-27 08:45:31 --> Helper loaded: file_helper
INFO - 2020-01-27 08:45:31 --> Helper loaded: form_helper
INFO - 2020-01-27 08:45:31 --> Helper loaded: my_helper
INFO - 2020-01-27 08:45:31 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:45:31 --> Controller Class Initialized
DEBUG - 2020-01-27 08:45:31 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:45:32 --> Final output sent to browser
DEBUG - 2020-01-27 08:45:32 --> Total execution time: 0.5466
INFO - 2020-01-27 08:46:30 --> Config Class Initialized
INFO - 2020-01-27 08:46:30 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:46:30 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:46:30 --> Utf8 Class Initialized
INFO - 2020-01-27 08:46:30 --> URI Class Initialized
INFO - 2020-01-27 08:46:30 --> Router Class Initialized
INFO - 2020-01-27 08:46:30 --> Output Class Initialized
INFO - 2020-01-27 08:46:30 --> Security Class Initialized
DEBUG - 2020-01-27 08:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:46:30 --> Input Class Initialized
INFO - 2020-01-27 08:46:30 --> Language Class Initialized
INFO - 2020-01-27 08:46:30 --> Language Class Initialized
INFO - 2020-01-27 08:46:30 --> Config Class Initialized
INFO - 2020-01-27 08:46:30 --> Loader Class Initialized
INFO - 2020-01-27 08:46:30 --> Helper loaded: url_helper
INFO - 2020-01-27 08:46:30 --> Helper loaded: file_helper
INFO - 2020-01-27 08:46:30 --> Helper loaded: form_helper
INFO - 2020-01-27 08:46:30 --> Helper loaded: my_helper
INFO - 2020-01-27 08:46:30 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:46:30 --> Controller Class Initialized
DEBUG - 2020-01-27 08:46:30 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:46:30 --> Final output sent to browser
DEBUG - 2020-01-27 08:46:30 --> Total execution time: 0.5212
INFO - 2020-01-27 08:47:52 --> Config Class Initialized
INFO - 2020-01-27 08:47:52 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:47:52 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:47:52 --> Utf8 Class Initialized
INFO - 2020-01-27 08:47:52 --> URI Class Initialized
INFO - 2020-01-27 08:47:52 --> Router Class Initialized
INFO - 2020-01-27 08:47:52 --> Output Class Initialized
INFO - 2020-01-27 08:47:52 --> Security Class Initialized
DEBUG - 2020-01-27 08:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:47:52 --> Input Class Initialized
INFO - 2020-01-27 08:47:53 --> Language Class Initialized
INFO - 2020-01-27 08:47:53 --> Language Class Initialized
INFO - 2020-01-27 08:47:53 --> Config Class Initialized
INFO - 2020-01-27 08:47:53 --> Loader Class Initialized
INFO - 2020-01-27 08:47:53 --> Helper loaded: url_helper
INFO - 2020-01-27 08:47:53 --> Helper loaded: file_helper
INFO - 2020-01-27 08:47:53 --> Helper loaded: form_helper
INFO - 2020-01-27 08:47:53 --> Helper loaded: my_helper
INFO - 2020-01-27 08:47:53 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:47:53 --> Controller Class Initialized
INFO - 2020-01-27 08:48:22 --> Config Class Initialized
INFO - 2020-01-27 08:48:22 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:48:22 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:48:22 --> Utf8 Class Initialized
INFO - 2020-01-27 08:48:22 --> URI Class Initialized
INFO - 2020-01-27 08:48:23 --> Router Class Initialized
INFO - 2020-01-27 08:48:23 --> Output Class Initialized
INFO - 2020-01-27 08:48:23 --> Security Class Initialized
DEBUG - 2020-01-27 08:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:48:23 --> Input Class Initialized
INFO - 2020-01-27 08:48:23 --> Language Class Initialized
INFO - 2020-01-27 08:48:23 --> Language Class Initialized
INFO - 2020-01-27 08:48:23 --> Config Class Initialized
INFO - 2020-01-27 08:48:23 --> Loader Class Initialized
INFO - 2020-01-27 08:48:23 --> Helper loaded: url_helper
INFO - 2020-01-27 08:48:23 --> Helper loaded: file_helper
INFO - 2020-01-27 08:48:23 --> Helper loaded: form_helper
INFO - 2020-01-27 08:48:23 --> Helper loaded: my_helper
INFO - 2020-01-27 08:48:23 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:48:23 --> Controller Class Initialized
INFO - 2020-01-27 08:49:26 --> Config Class Initialized
INFO - 2020-01-27 08:49:26 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:49:26 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:49:26 --> Utf8 Class Initialized
INFO - 2020-01-27 08:49:26 --> URI Class Initialized
INFO - 2020-01-27 08:49:26 --> Router Class Initialized
INFO - 2020-01-27 08:49:26 --> Output Class Initialized
INFO - 2020-01-27 08:49:26 --> Security Class Initialized
DEBUG - 2020-01-27 08:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:49:26 --> Input Class Initialized
INFO - 2020-01-27 08:49:26 --> Language Class Initialized
INFO - 2020-01-27 08:49:26 --> Language Class Initialized
INFO - 2020-01-27 08:49:26 --> Config Class Initialized
INFO - 2020-01-27 08:49:27 --> Loader Class Initialized
INFO - 2020-01-27 08:49:27 --> Helper loaded: url_helper
INFO - 2020-01-27 08:49:27 --> Helper loaded: file_helper
INFO - 2020-01-27 08:49:27 --> Helper loaded: form_helper
INFO - 2020-01-27 08:49:27 --> Helper loaded: my_helper
INFO - 2020-01-27 08:49:27 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:49:27 --> Controller Class Initialized
INFO - 2020-01-27 08:49:42 --> Config Class Initialized
INFO - 2020-01-27 08:49:42 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:49:43 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:49:43 --> Utf8 Class Initialized
INFO - 2020-01-27 08:49:43 --> URI Class Initialized
INFO - 2020-01-27 08:49:43 --> Router Class Initialized
INFO - 2020-01-27 08:49:43 --> Output Class Initialized
INFO - 2020-01-27 08:49:43 --> Security Class Initialized
DEBUG - 2020-01-27 08:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:49:43 --> Input Class Initialized
INFO - 2020-01-27 08:49:43 --> Language Class Initialized
INFO - 2020-01-27 08:49:43 --> Language Class Initialized
INFO - 2020-01-27 08:49:43 --> Config Class Initialized
INFO - 2020-01-27 08:49:43 --> Loader Class Initialized
INFO - 2020-01-27 08:49:43 --> Helper loaded: url_helper
INFO - 2020-01-27 08:49:43 --> Helper loaded: file_helper
INFO - 2020-01-27 08:49:43 --> Helper loaded: form_helper
INFO - 2020-01-27 08:49:43 --> Helper loaded: my_helper
INFO - 2020-01-27 08:49:43 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:49:43 --> Controller Class Initialized
INFO - 2020-01-27 08:49:43 --> Final output sent to browser
DEBUG - 2020-01-27 08:49:43 --> Total execution time: 0.4455
INFO - 2020-01-27 08:50:09 --> Config Class Initialized
INFO - 2020-01-27 08:50:09 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:50:09 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:50:09 --> Utf8 Class Initialized
INFO - 2020-01-27 08:50:09 --> URI Class Initialized
INFO - 2020-01-27 08:50:09 --> Router Class Initialized
INFO - 2020-01-27 08:50:09 --> Output Class Initialized
INFO - 2020-01-27 08:50:09 --> Security Class Initialized
DEBUG - 2020-01-27 08:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:50:09 --> Input Class Initialized
INFO - 2020-01-27 08:50:09 --> Language Class Initialized
INFO - 2020-01-27 08:50:09 --> Language Class Initialized
INFO - 2020-01-27 08:50:09 --> Config Class Initialized
INFO - 2020-01-27 08:50:10 --> Loader Class Initialized
INFO - 2020-01-27 08:50:10 --> Helper loaded: url_helper
INFO - 2020-01-27 08:50:10 --> Helper loaded: file_helper
INFO - 2020-01-27 08:50:10 --> Helper loaded: form_helper
INFO - 2020-01-27 08:50:10 --> Helper loaded: my_helper
INFO - 2020-01-27 08:50:10 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:50:10 --> Controller Class Initialized
DEBUG - 2020-01-27 08:50:10 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:50:10 --> Final output sent to browser
DEBUG - 2020-01-27 08:50:10 --> Total execution time: 0.5271
INFO - 2020-01-27 08:53:40 --> Config Class Initialized
INFO - 2020-01-27 08:53:40 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:53:40 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:53:40 --> Utf8 Class Initialized
INFO - 2020-01-27 08:53:40 --> URI Class Initialized
INFO - 2020-01-27 08:53:40 --> Router Class Initialized
INFO - 2020-01-27 08:53:40 --> Output Class Initialized
INFO - 2020-01-27 08:53:40 --> Security Class Initialized
DEBUG - 2020-01-27 08:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:53:40 --> Input Class Initialized
INFO - 2020-01-27 08:53:40 --> Language Class Initialized
INFO - 2020-01-27 08:53:40 --> Language Class Initialized
INFO - 2020-01-27 08:53:40 --> Config Class Initialized
INFO - 2020-01-27 08:53:40 --> Loader Class Initialized
INFO - 2020-01-27 08:53:40 --> Helper loaded: url_helper
INFO - 2020-01-27 08:53:40 --> Helper loaded: file_helper
INFO - 2020-01-27 08:53:40 --> Helper loaded: form_helper
INFO - 2020-01-27 08:53:40 --> Helper loaded: my_helper
INFO - 2020-01-27 08:53:40 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:53:41 --> Controller Class Initialized
DEBUG - 2020-01-27 08:53:41 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:53:41 --> Final output sent to browser
DEBUG - 2020-01-27 08:53:41 --> Total execution time: 0.5456
INFO - 2020-01-27 08:55:23 --> Config Class Initialized
INFO - 2020-01-27 08:55:23 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:55:23 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:55:23 --> Utf8 Class Initialized
INFO - 2020-01-27 08:55:23 --> URI Class Initialized
INFO - 2020-01-27 08:55:23 --> Router Class Initialized
INFO - 2020-01-27 08:55:23 --> Output Class Initialized
INFO - 2020-01-27 08:55:23 --> Security Class Initialized
DEBUG - 2020-01-27 08:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:55:23 --> Input Class Initialized
INFO - 2020-01-27 08:55:23 --> Language Class Initialized
INFO - 2020-01-27 08:55:23 --> Language Class Initialized
INFO - 2020-01-27 08:55:23 --> Config Class Initialized
INFO - 2020-01-27 08:55:24 --> Loader Class Initialized
INFO - 2020-01-27 08:55:24 --> Helper loaded: url_helper
INFO - 2020-01-27 08:55:24 --> Helper loaded: file_helper
INFO - 2020-01-27 08:55:24 --> Helper loaded: form_helper
INFO - 2020-01-27 08:55:24 --> Helper loaded: my_helper
INFO - 2020-01-27 08:55:24 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:55:24 --> Controller Class Initialized
DEBUG - 2020-01-27 08:55:24 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:55:24 --> Final output sent to browser
DEBUG - 2020-01-27 08:55:24 --> Total execution time: 0.5628
INFO - 2020-01-27 08:55:45 --> Config Class Initialized
INFO - 2020-01-27 08:55:45 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:55:45 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:55:45 --> Utf8 Class Initialized
INFO - 2020-01-27 08:55:45 --> URI Class Initialized
INFO - 2020-01-27 08:55:45 --> Router Class Initialized
INFO - 2020-01-27 08:55:45 --> Output Class Initialized
INFO - 2020-01-27 08:55:45 --> Security Class Initialized
DEBUG - 2020-01-27 08:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:55:45 --> Input Class Initialized
INFO - 2020-01-27 08:55:45 --> Language Class Initialized
INFO - 2020-01-27 08:55:45 --> Language Class Initialized
INFO - 2020-01-27 08:55:45 --> Config Class Initialized
INFO - 2020-01-27 08:55:45 --> Loader Class Initialized
INFO - 2020-01-27 08:55:46 --> Helper loaded: url_helper
INFO - 2020-01-27 08:55:46 --> Helper loaded: file_helper
INFO - 2020-01-27 08:55:46 --> Helper loaded: form_helper
INFO - 2020-01-27 08:55:46 --> Helper loaded: my_helper
INFO - 2020-01-27 08:55:46 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:55:46 --> Controller Class Initialized
DEBUG - 2020-01-27 08:55:46 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:55:46 --> Final output sent to browser
DEBUG - 2020-01-27 08:55:46 --> Total execution time: 0.5255
INFO - 2020-01-27 08:55:56 --> Config Class Initialized
INFO - 2020-01-27 08:55:56 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:55:56 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:55:56 --> Utf8 Class Initialized
INFO - 2020-01-27 08:55:56 --> URI Class Initialized
INFO - 2020-01-27 08:55:56 --> Router Class Initialized
INFO - 2020-01-27 08:55:56 --> Output Class Initialized
INFO - 2020-01-27 08:55:56 --> Security Class Initialized
DEBUG - 2020-01-27 08:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:55:56 --> Input Class Initialized
INFO - 2020-01-27 08:55:56 --> Language Class Initialized
INFO - 2020-01-27 08:55:56 --> Language Class Initialized
INFO - 2020-01-27 08:55:56 --> Config Class Initialized
INFO - 2020-01-27 08:55:56 --> Loader Class Initialized
INFO - 2020-01-27 08:55:56 --> Helper loaded: url_helper
INFO - 2020-01-27 08:55:56 --> Helper loaded: file_helper
INFO - 2020-01-27 08:55:56 --> Helper loaded: form_helper
INFO - 2020-01-27 08:55:56 --> Helper loaded: my_helper
INFO - 2020-01-27 08:55:56 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:55:57 --> Controller Class Initialized
INFO - 2020-01-27 08:55:57 --> Final output sent to browser
DEBUG - 2020-01-27 08:55:57 --> Total execution time: 0.4592
INFO - 2020-01-27 08:55:57 --> Config Class Initialized
INFO - 2020-01-27 08:55:57 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:55:57 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:55:57 --> Utf8 Class Initialized
INFO - 2020-01-27 08:55:57 --> URI Class Initialized
INFO - 2020-01-27 08:55:57 --> Router Class Initialized
INFO - 2020-01-27 08:55:57 --> Output Class Initialized
INFO - 2020-01-27 08:55:57 --> Security Class Initialized
DEBUG - 2020-01-27 08:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:55:57 --> Input Class Initialized
INFO - 2020-01-27 08:55:57 --> Language Class Initialized
INFO - 2020-01-27 08:55:57 --> Language Class Initialized
INFO - 2020-01-27 08:55:57 --> Config Class Initialized
INFO - 2020-01-27 08:55:57 --> Loader Class Initialized
INFO - 2020-01-27 08:55:58 --> Helper loaded: url_helper
INFO - 2020-01-27 08:55:58 --> Helper loaded: file_helper
INFO - 2020-01-27 08:55:58 --> Helper loaded: form_helper
INFO - 2020-01-27 08:55:58 --> Helper loaded: my_helper
INFO - 2020-01-27 08:55:58 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:55:58 --> Controller Class Initialized
INFO - 2020-01-27 08:55:58 --> Final output sent to browser
DEBUG - 2020-01-27 08:55:58 --> Total execution time: 0.4907
INFO - 2020-01-27 08:56:01 --> Config Class Initialized
INFO - 2020-01-27 08:56:01 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:56:01 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:56:01 --> Utf8 Class Initialized
INFO - 2020-01-27 08:56:01 --> URI Class Initialized
INFO - 2020-01-27 08:56:01 --> Router Class Initialized
INFO - 2020-01-27 08:56:01 --> Output Class Initialized
INFO - 2020-01-27 08:56:01 --> Security Class Initialized
DEBUG - 2020-01-27 08:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:56:01 --> Input Class Initialized
INFO - 2020-01-27 08:56:01 --> Language Class Initialized
INFO - 2020-01-27 08:56:01 --> Language Class Initialized
INFO - 2020-01-27 08:56:01 --> Config Class Initialized
INFO - 2020-01-27 08:56:02 --> Loader Class Initialized
INFO - 2020-01-27 08:56:02 --> Helper loaded: url_helper
INFO - 2020-01-27 08:56:02 --> Helper loaded: file_helper
INFO - 2020-01-27 08:56:02 --> Helper loaded: form_helper
INFO - 2020-01-27 08:56:02 --> Helper loaded: my_helper
INFO - 2020-01-27 08:56:02 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:56:02 --> Controller Class Initialized
INFO - 2020-01-27 08:56:02 --> Final output sent to browser
DEBUG - 2020-01-27 08:56:02 --> Total execution time: 0.4973
INFO - 2020-01-27 08:56:04 --> Config Class Initialized
INFO - 2020-01-27 08:56:04 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:56:04 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:56:04 --> Utf8 Class Initialized
INFO - 2020-01-27 08:56:04 --> URI Class Initialized
INFO - 2020-01-27 08:56:04 --> Router Class Initialized
INFO - 2020-01-27 08:56:04 --> Output Class Initialized
INFO - 2020-01-27 08:56:04 --> Security Class Initialized
DEBUG - 2020-01-27 08:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:56:04 --> Input Class Initialized
INFO - 2020-01-27 08:56:04 --> Language Class Initialized
INFO - 2020-01-27 08:56:04 --> Language Class Initialized
INFO - 2020-01-27 08:56:04 --> Config Class Initialized
INFO - 2020-01-27 08:56:04 --> Loader Class Initialized
INFO - 2020-01-27 08:56:04 --> Helper loaded: url_helper
INFO - 2020-01-27 08:56:04 --> Helper loaded: file_helper
INFO - 2020-01-27 08:56:04 --> Helper loaded: form_helper
INFO - 2020-01-27 08:56:04 --> Helper loaded: my_helper
INFO - 2020-01-27 08:56:04 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:56:04 --> Controller Class Initialized
DEBUG - 2020-01-27 08:56:04 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:56:04 --> Final output sent to browser
DEBUG - 2020-01-27 08:56:04 --> Total execution time: 0.5097
INFO - 2020-01-27 08:57:01 --> Config Class Initialized
INFO - 2020-01-27 08:57:01 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:57:01 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:57:01 --> Utf8 Class Initialized
INFO - 2020-01-27 08:57:01 --> URI Class Initialized
INFO - 2020-01-27 08:57:01 --> Router Class Initialized
INFO - 2020-01-27 08:57:01 --> Output Class Initialized
INFO - 2020-01-27 08:57:01 --> Security Class Initialized
DEBUG - 2020-01-27 08:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:57:01 --> Input Class Initialized
INFO - 2020-01-27 08:57:01 --> Language Class Initialized
INFO - 2020-01-27 08:57:01 --> Language Class Initialized
INFO - 2020-01-27 08:57:01 --> Config Class Initialized
INFO - 2020-01-27 08:57:01 --> Loader Class Initialized
INFO - 2020-01-27 08:57:01 --> Helper loaded: url_helper
INFO - 2020-01-27 08:57:01 --> Helper loaded: file_helper
INFO - 2020-01-27 08:57:01 --> Helper loaded: form_helper
INFO - 2020-01-27 08:57:01 --> Helper loaded: my_helper
INFO - 2020-01-27 08:57:01 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:57:01 --> Controller Class Initialized
INFO - 2020-01-27 08:57:32 --> Config Class Initialized
INFO - 2020-01-27 08:57:32 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:57:33 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:57:33 --> Utf8 Class Initialized
INFO - 2020-01-27 08:57:33 --> URI Class Initialized
INFO - 2020-01-27 08:57:33 --> Router Class Initialized
INFO - 2020-01-27 08:57:33 --> Output Class Initialized
INFO - 2020-01-27 08:57:33 --> Security Class Initialized
DEBUG - 2020-01-27 08:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:57:33 --> Input Class Initialized
INFO - 2020-01-27 08:57:33 --> Language Class Initialized
INFO - 2020-01-27 08:57:33 --> Language Class Initialized
INFO - 2020-01-27 08:57:33 --> Config Class Initialized
INFO - 2020-01-27 08:57:33 --> Loader Class Initialized
INFO - 2020-01-27 08:57:33 --> Helper loaded: url_helper
INFO - 2020-01-27 08:57:33 --> Helper loaded: file_helper
INFO - 2020-01-27 08:57:33 --> Helper loaded: form_helper
INFO - 2020-01-27 08:57:33 --> Helper loaded: my_helper
INFO - 2020-01-27 08:57:33 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:57:33 --> Controller Class Initialized
INFO - 2020-01-27 08:57:33 --> Final output sent to browser
DEBUG - 2020-01-27 08:57:33 --> Total execution time: 0.4794
INFO - 2020-01-27 08:57:34 --> Config Class Initialized
INFO - 2020-01-27 08:57:35 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:57:35 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:57:35 --> Utf8 Class Initialized
INFO - 2020-01-27 08:57:35 --> URI Class Initialized
INFO - 2020-01-27 08:57:35 --> Router Class Initialized
INFO - 2020-01-27 08:57:35 --> Output Class Initialized
INFO - 2020-01-27 08:57:35 --> Security Class Initialized
DEBUG - 2020-01-27 08:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:57:35 --> Input Class Initialized
INFO - 2020-01-27 08:57:35 --> Language Class Initialized
INFO - 2020-01-27 08:57:35 --> Language Class Initialized
INFO - 2020-01-27 08:57:35 --> Config Class Initialized
INFO - 2020-01-27 08:57:35 --> Loader Class Initialized
INFO - 2020-01-27 08:57:35 --> Helper loaded: url_helper
INFO - 2020-01-27 08:57:35 --> Helper loaded: file_helper
INFO - 2020-01-27 08:57:35 --> Helper loaded: form_helper
INFO - 2020-01-27 08:57:35 --> Helper loaded: my_helper
INFO - 2020-01-27 08:57:35 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:57:35 --> Controller Class Initialized
INFO - 2020-01-27 08:57:35 --> Final output sent to browser
DEBUG - 2020-01-27 08:57:35 --> Total execution time: 0.4881
INFO - 2020-01-27 08:57:39 --> Config Class Initialized
INFO - 2020-01-27 08:57:39 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:57:39 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:57:39 --> Utf8 Class Initialized
INFO - 2020-01-27 08:57:39 --> URI Class Initialized
INFO - 2020-01-27 08:57:39 --> Router Class Initialized
INFO - 2020-01-27 08:57:39 --> Output Class Initialized
INFO - 2020-01-27 08:57:39 --> Security Class Initialized
DEBUG - 2020-01-27 08:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:57:39 --> Input Class Initialized
INFO - 2020-01-27 08:57:39 --> Language Class Initialized
INFO - 2020-01-27 08:57:39 --> Language Class Initialized
INFO - 2020-01-27 08:57:39 --> Config Class Initialized
INFO - 2020-01-27 08:57:39 --> Loader Class Initialized
INFO - 2020-01-27 08:57:39 --> Helper loaded: url_helper
INFO - 2020-01-27 08:57:39 --> Helper loaded: file_helper
INFO - 2020-01-27 08:57:39 --> Helper loaded: form_helper
INFO - 2020-01-27 08:57:39 --> Helper loaded: my_helper
INFO - 2020-01-27 08:57:39 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:57:39 --> Controller Class Initialized
INFO - 2020-01-27 08:57:39 --> Final output sent to browser
DEBUG - 2020-01-27 08:57:39 --> Total execution time: 0.5449
INFO - 2020-01-27 08:57:41 --> Config Class Initialized
INFO - 2020-01-27 08:57:41 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:57:41 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:57:41 --> Utf8 Class Initialized
INFO - 2020-01-27 08:57:41 --> URI Class Initialized
INFO - 2020-01-27 08:57:41 --> Router Class Initialized
INFO - 2020-01-27 08:57:41 --> Output Class Initialized
INFO - 2020-01-27 08:57:41 --> Security Class Initialized
DEBUG - 2020-01-27 08:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:57:41 --> Input Class Initialized
INFO - 2020-01-27 08:57:41 --> Language Class Initialized
INFO - 2020-01-27 08:57:41 --> Language Class Initialized
INFO - 2020-01-27 08:57:41 --> Config Class Initialized
INFO - 2020-01-27 08:57:41 --> Loader Class Initialized
INFO - 2020-01-27 08:57:41 --> Helper loaded: url_helper
INFO - 2020-01-27 08:57:41 --> Helper loaded: file_helper
INFO - 2020-01-27 08:57:41 --> Helper loaded: form_helper
INFO - 2020-01-27 08:57:41 --> Helper loaded: my_helper
INFO - 2020-01-27 08:57:41 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:57:41 --> Controller Class Initialized
INFO - 2020-01-27 08:57:49 --> Config Class Initialized
INFO - 2020-01-27 08:57:49 --> Hooks Class Initialized
DEBUG - 2020-01-27 08:57:49 --> UTF-8 Support Enabled
INFO - 2020-01-27 08:57:49 --> Utf8 Class Initialized
INFO - 2020-01-27 08:57:49 --> URI Class Initialized
INFO - 2020-01-27 08:57:49 --> Router Class Initialized
INFO - 2020-01-27 08:57:49 --> Output Class Initialized
INFO - 2020-01-27 08:57:49 --> Security Class Initialized
DEBUG - 2020-01-27 08:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 08:57:49 --> Input Class Initialized
INFO - 2020-01-27 08:57:49 --> Language Class Initialized
INFO - 2020-01-27 08:57:49 --> Language Class Initialized
INFO - 2020-01-27 08:57:49 --> Config Class Initialized
INFO - 2020-01-27 08:57:49 --> Loader Class Initialized
INFO - 2020-01-27 08:57:49 --> Helper loaded: url_helper
INFO - 2020-01-27 08:57:49 --> Helper loaded: file_helper
INFO - 2020-01-27 08:57:49 --> Helper loaded: form_helper
INFO - 2020-01-27 08:57:49 --> Helper loaded: my_helper
INFO - 2020-01-27 08:57:49 --> Database Driver Class Initialized
DEBUG - 2020-01-27 08:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 08:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 08:57:49 --> Controller Class Initialized
DEBUG - 2020-01-27 08:57:49 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 08:57:49 --> Final output sent to browser
DEBUG - 2020-01-27 08:57:49 --> Total execution time: 0.5232
INFO - 2020-01-27 09:13:36 --> Config Class Initialized
INFO - 2020-01-27 09:13:36 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:13:36 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:13:36 --> Utf8 Class Initialized
INFO - 2020-01-27 09:13:36 --> URI Class Initialized
INFO - 2020-01-27 09:13:36 --> Router Class Initialized
INFO - 2020-01-27 09:13:36 --> Output Class Initialized
INFO - 2020-01-27 09:13:36 --> Security Class Initialized
DEBUG - 2020-01-27 09:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:13:36 --> Input Class Initialized
INFO - 2020-01-27 09:13:36 --> Language Class Initialized
INFO - 2020-01-27 09:13:36 --> Language Class Initialized
INFO - 2020-01-27 09:13:36 --> Config Class Initialized
INFO - 2020-01-27 09:13:36 --> Loader Class Initialized
INFO - 2020-01-27 09:13:36 --> Helper loaded: url_helper
INFO - 2020-01-27 09:13:36 --> Helper loaded: file_helper
INFO - 2020-01-27 09:13:36 --> Helper loaded: form_helper
INFO - 2020-01-27 09:13:36 --> Helper loaded: my_helper
INFO - 2020-01-27 09:13:36 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:13:36 --> Controller Class Initialized
DEBUG - 2020-01-27 09:13:36 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 09:13:36 --> Final output sent to browser
DEBUG - 2020-01-27 09:13:36 --> Total execution time: 0.5363
INFO - 2020-01-27 09:14:11 --> Config Class Initialized
INFO - 2020-01-27 09:14:11 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:14:11 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:14:11 --> Utf8 Class Initialized
INFO - 2020-01-27 09:14:11 --> URI Class Initialized
INFO - 2020-01-27 09:14:11 --> Router Class Initialized
INFO - 2020-01-27 09:14:11 --> Output Class Initialized
INFO - 2020-01-27 09:14:11 --> Security Class Initialized
DEBUG - 2020-01-27 09:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:14:11 --> Input Class Initialized
INFO - 2020-01-27 09:14:11 --> Language Class Initialized
INFO - 2020-01-27 09:14:11 --> Language Class Initialized
INFO - 2020-01-27 09:14:11 --> Config Class Initialized
INFO - 2020-01-27 09:14:11 --> Loader Class Initialized
INFO - 2020-01-27 09:14:11 --> Helper loaded: url_helper
INFO - 2020-01-27 09:14:11 --> Helper loaded: file_helper
INFO - 2020-01-27 09:14:11 --> Helper loaded: form_helper
INFO - 2020-01-27 09:14:11 --> Helper loaded: my_helper
INFO - 2020-01-27 09:14:11 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:14:11 --> Controller Class Initialized
DEBUG - 2020-01-27 09:14:11 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 09:14:11 --> Final output sent to browser
DEBUG - 2020-01-27 09:14:11 --> Total execution time: 0.5234
INFO - 2020-01-27 09:14:26 --> Config Class Initialized
INFO - 2020-01-27 09:14:26 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:14:26 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:14:26 --> Utf8 Class Initialized
INFO - 2020-01-27 09:14:26 --> URI Class Initialized
INFO - 2020-01-27 09:14:26 --> Router Class Initialized
INFO - 2020-01-27 09:14:26 --> Output Class Initialized
INFO - 2020-01-27 09:14:26 --> Security Class Initialized
DEBUG - 2020-01-27 09:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:14:26 --> Input Class Initialized
INFO - 2020-01-27 09:14:26 --> Language Class Initialized
INFO - 2020-01-27 09:14:26 --> Language Class Initialized
INFO - 2020-01-27 09:14:27 --> Config Class Initialized
INFO - 2020-01-27 09:14:27 --> Loader Class Initialized
INFO - 2020-01-27 09:14:27 --> Helper loaded: url_helper
INFO - 2020-01-27 09:14:27 --> Helper loaded: file_helper
INFO - 2020-01-27 09:14:27 --> Helper loaded: form_helper
INFO - 2020-01-27 09:14:27 --> Helper loaded: my_helper
INFO - 2020-01-27 09:14:27 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:14:27 --> Controller Class Initialized
INFO - 2020-01-27 09:14:27 --> Final output sent to browser
DEBUG - 2020-01-27 09:14:27 --> Total execution time: 0.4886
INFO - 2020-01-27 09:14:29 --> Config Class Initialized
INFO - 2020-01-27 09:14:29 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:14:29 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:14:29 --> Utf8 Class Initialized
INFO - 2020-01-27 09:14:29 --> URI Class Initialized
INFO - 2020-01-27 09:14:29 --> Router Class Initialized
INFO - 2020-01-27 09:14:29 --> Output Class Initialized
INFO - 2020-01-27 09:14:29 --> Security Class Initialized
DEBUG - 2020-01-27 09:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:14:29 --> Input Class Initialized
INFO - 2020-01-27 09:14:29 --> Language Class Initialized
INFO - 2020-01-27 09:14:29 --> Language Class Initialized
INFO - 2020-01-27 09:14:29 --> Config Class Initialized
INFO - 2020-01-27 09:14:29 --> Loader Class Initialized
INFO - 2020-01-27 09:14:29 --> Helper loaded: url_helper
INFO - 2020-01-27 09:14:29 --> Helper loaded: file_helper
INFO - 2020-01-27 09:14:29 --> Helper loaded: form_helper
INFO - 2020-01-27 09:14:29 --> Helper loaded: my_helper
INFO - 2020-01-27 09:14:29 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:14:29 --> Controller Class Initialized
INFO - 2020-01-27 09:14:29 --> Final output sent to browser
DEBUG - 2020-01-27 09:14:29 --> Total execution time: 0.4821
INFO - 2020-01-27 09:14:35 --> Config Class Initialized
INFO - 2020-01-27 09:14:35 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:14:35 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:14:35 --> Utf8 Class Initialized
INFO - 2020-01-27 09:14:35 --> URI Class Initialized
INFO - 2020-01-27 09:14:35 --> Router Class Initialized
INFO - 2020-01-27 09:14:35 --> Output Class Initialized
INFO - 2020-01-27 09:14:35 --> Security Class Initialized
DEBUG - 2020-01-27 09:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:14:35 --> Input Class Initialized
INFO - 2020-01-27 09:14:35 --> Language Class Initialized
INFO - 2020-01-27 09:14:35 --> Language Class Initialized
INFO - 2020-01-27 09:14:35 --> Config Class Initialized
INFO - 2020-01-27 09:14:35 --> Loader Class Initialized
INFO - 2020-01-27 09:14:35 --> Helper loaded: url_helper
INFO - 2020-01-27 09:14:35 --> Helper loaded: file_helper
INFO - 2020-01-27 09:14:35 --> Helper loaded: form_helper
INFO - 2020-01-27 09:14:35 --> Helper loaded: my_helper
INFO - 2020-01-27 09:14:35 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:14:35 --> Controller Class Initialized
INFO - 2020-01-27 09:14:35 --> Final output sent to browser
DEBUG - 2020-01-27 09:14:35 --> Total execution time: 0.4920
INFO - 2020-01-27 09:14:39 --> Config Class Initialized
INFO - 2020-01-27 09:14:39 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:14:39 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:14:39 --> Utf8 Class Initialized
INFO - 2020-01-27 09:14:39 --> URI Class Initialized
INFO - 2020-01-27 09:14:39 --> Router Class Initialized
INFO - 2020-01-27 09:14:39 --> Output Class Initialized
INFO - 2020-01-27 09:14:39 --> Security Class Initialized
DEBUG - 2020-01-27 09:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:14:39 --> Input Class Initialized
INFO - 2020-01-27 09:14:39 --> Language Class Initialized
INFO - 2020-01-27 09:14:39 --> Language Class Initialized
INFO - 2020-01-27 09:14:39 --> Config Class Initialized
INFO - 2020-01-27 09:14:39 --> Loader Class Initialized
INFO - 2020-01-27 09:14:40 --> Helper loaded: url_helper
INFO - 2020-01-27 09:14:40 --> Helper loaded: file_helper
INFO - 2020-01-27 09:14:40 --> Helper loaded: form_helper
INFO - 2020-01-27 09:14:40 --> Helper loaded: my_helper
INFO - 2020-01-27 09:14:40 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:14:40 --> Controller Class Initialized
DEBUG - 2020-01-27 09:14:40 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 09:14:40 --> Final output sent to browser
DEBUG - 2020-01-27 09:14:40 --> Total execution time: 0.5204
INFO - 2020-01-27 09:15:45 --> Config Class Initialized
INFO - 2020-01-27 09:15:45 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:15:45 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:15:45 --> Utf8 Class Initialized
INFO - 2020-01-27 09:15:45 --> URI Class Initialized
INFO - 2020-01-27 09:15:45 --> Router Class Initialized
INFO - 2020-01-27 09:15:45 --> Output Class Initialized
INFO - 2020-01-27 09:15:45 --> Security Class Initialized
DEBUG - 2020-01-27 09:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:15:45 --> Input Class Initialized
INFO - 2020-01-27 09:15:45 --> Language Class Initialized
INFO - 2020-01-27 09:15:45 --> Language Class Initialized
INFO - 2020-01-27 09:15:45 --> Config Class Initialized
INFO - 2020-01-27 09:15:45 --> Loader Class Initialized
INFO - 2020-01-27 09:15:45 --> Helper loaded: url_helper
INFO - 2020-01-27 09:15:45 --> Helper loaded: file_helper
INFO - 2020-01-27 09:15:45 --> Helper loaded: form_helper
INFO - 2020-01-27 09:15:45 --> Helper loaded: my_helper
INFO - 2020-01-27 09:15:45 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:15:45 --> Controller Class Initialized
INFO - 2020-01-27 09:16:25 --> Config Class Initialized
INFO - 2020-01-27 09:16:25 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:16:25 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:16:25 --> Utf8 Class Initialized
INFO - 2020-01-27 09:16:25 --> URI Class Initialized
INFO - 2020-01-27 09:16:25 --> Router Class Initialized
INFO - 2020-01-27 09:16:25 --> Output Class Initialized
INFO - 2020-01-27 09:16:25 --> Security Class Initialized
DEBUG - 2020-01-27 09:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:16:25 --> Input Class Initialized
INFO - 2020-01-27 09:16:25 --> Language Class Initialized
INFO - 2020-01-27 09:16:25 --> Language Class Initialized
INFO - 2020-01-27 09:16:25 --> Config Class Initialized
INFO - 2020-01-27 09:16:25 --> Loader Class Initialized
INFO - 2020-01-27 09:16:25 --> Helper loaded: url_helper
INFO - 2020-01-27 09:16:25 --> Helper loaded: file_helper
INFO - 2020-01-27 09:16:25 --> Helper loaded: form_helper
INFO - 2020-01-27 09:16:25 --> Helper loaded: my_helper
INFO - 2020-01-27 09:16:25 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:16:25 --> Controller Class Initialized
INFO - 2020-01-27 09:16:31 --> Config Class Initialized
INFO - 2020-01-27 09:16:31 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:16:31 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:16:31 --> Utf8 Class Initialized
INFO - 2020-01-27 09:16:31 --> URI Class Initialized
INFO - 2020-01-27 09:16:31 --> Router Class Initialized
INFO - 2020-01-27 09:16:31 --> Output Class Initialized
INFO - 2020-01-27 09:16:31 --> Security Class Initialized
DEBUG - 2020-01-27 09:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:16:31 --> Input Class Initialized
INFO - 2020-01-27 09:16:31 --> Language Class Initialized
INFO - 2020-01-27 09:16:31 --> Language Class Initialized
INFO - 2020-01-27 09:16:31 --> Config Class Initialized
INFO - 2020-01-27 09:16:31 --> Loader Class Initialized
INFO - 2020-01-27 09:16:31 --> Helper loaded: url_helper
INFO - 2020-01-27 09:16:31 --> Helper loaded: file_helper
INFO - 2020-01-27 09:16:31 --> Helper loaded: form_helper
INFO - 2020-01-27 09:16:31 --> Helper loaded: my_helper
INFO - 2020-01-27 09:16:31 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:16:31 --> Controller Class Initialized
DEBUG - 2020-01-27 09:16:31 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 09:16:31 --> Final output sent to browser
DEBUG - 2020-01-27 09:16:31 --> Total execution time: 0.5586
INFO - 2020-01-27 09:19:46 --> Config Class Initialized
INFO - 2020-01-27 09:19:46 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:19:46 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:19:46 --> Utf8 Class Initialized
INFO - 2020-01-27 09:19:46 --> URI Class Initialized
INFO - 2020-01-27 09:19:46 --> Router Class Initialized
INFO - 2020-01-27 09:19:46 --> Output Class Initialized
INFO - 2020-01-27 09:19:46 --> Security Class Initialized
DEBUG - 2020-01-27 09:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:19:46 --> Input Class Initialized
INFO - 2020-01-27 09:19:46 --> Language Class Initialized
INFO - 2020-01-27 09:19:46 --> Language Class Initialized
INFO - 2020-01-27 09:19:46 --> Config Class Initialized
INFO - 2020-01-27 09:19:46 --> Loader Class Initialized
INFO - 2020-01-27 09:19:46 --> Helper loaded: url_helper
INFO - 2020-01-27 09:19:46 --> Helper loaded: file_helper
INFO - 2020-01-27 09:19:46 --> Helper loaded: form_helper
INFO - 2020-01-27 09:19:46 --> Helper loaded: my_helper
INFO - 2020-01-27 09:19:46 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:19:46 --> Controller Class Initialized
DEBUG - 2020-01-27 09:19:46 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-01-27 09:19:46 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 09:19:46 --> Final output sent to browser
DEBUG - 2020-01-27 09:19:46 --> Total execution time: 0.5858
INFO - 2020-01-27 09:19:48 --> Config Class Initialized
INFO - 2020-01-27 09:19:49 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:19:49 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:19:49 --> Utf8 Class Initialized
INFO - 2020-01-27 09:19:49 --> URI Class Initialized
INFO - 2020-01-27 09:19:49 --> Router Class Initialized
INFO - 2020-01-27 09:19:49 --> Output Class Initialized
INFO - 2020-01-27 09:19:49 --> Security Class Initialized
DEBUG - 2020-01-27 09:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:19:49 --> Input Class Initialized
INFO - 2020-01-27 09:19:49 --> Language Class Initialized
INFO - 2020-01-27 09:19:49 --> Language Class Initialized
INFO - 2020-01-27 09:19:49 --> Config Class Initialized
INFO - 2020-01-27 09:19:49 --> Loader Class Initialized
INFO - 2020-01-27 09:19:49 --> Helper loaded: url_helper
INFO - 2020-01-27 09:19:49 --> Helper loaded: file_helper
INFO - 2020-01-27 09:19:49 --> Helper loaded: form_helper
INFO - 2020-01-27 09:19:49 --> Helper loaded: my_helper
INFO - 2020-01-27 09:19:49 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:19:49 --> Controller Class Initialized
DEBUG - 2020-01-27 09:19:49 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 09:19:49 --> Final output sent to browser
DEBUG - 2020-01-27 09:19:49 --> Total execution time: 0.5449
INFO - 2020-01-27 09:19:51 --> Config Class Initialized
INFO - 2020-01-27 09:19:51 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:19:51 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:19:51 --> Utf8 Class Initialized
INFO - 2020-01-27 09:19:51 --> URI Class Initialized
INFO - 2020-01-27 09:19:51 --> Router Class Initialized
INFO - 2020-01-27 09:19:51 --> Output Class Initialized
INFO - 2020-01-27 09:19:51 --> Security Class Initialized
DEBUG - 2020-01-27 09:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:19:51 --> Input Class Initialized
INFO - 2020-01-27 09:19:51 --> Language Class Initialized
INFO - 2020-01-27 09:19:52 --> Language Class Initialized
INFO - 2020-01-27 09:19:52 --> Config Class Initialized
INFO - 2020-01-27 09:19:52 --> Loader Class Initialized
INFO - 2020-01-27 09:19:52 --> Helper loaded: url_helper
INFO - 2020-01-27 09:19:52 --> Helper loaded: file_helper
INFO - 2020-01-27 09:19:52 --> Helper loaded: form_helper
INFO - 2020-01-27 09:19:52 --> Helper loaded: my_helper
INFO - 2020-01-27 09:19:52 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:19:52 --> Controller Class Initialized
DEBUG - 2020-01-27 09:19:52 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 09:19:52 --> Final output sent to browser
DEBUG - 2020-01-27 09:19:52 --> Total execution time: 0.5307
INFO - 2020-01-27 09:19:54 --> Config Class Initialized
INFO - 2020-01-27 09:19:54 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:19:54 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:19:54 --> Utf8 Class Initialized
INFO - 2020-01-27 09:19:54 --> URI Class Initialized
INFO - 2020-01-27 09:19:54 --> Router Class Initialized
INFO - 2020-01-27 09:19:54 --> Output Class Initialized
INFO - 2020-01-27 09:19:54 --> Security Class Initialized
DEBUG - 2020-01-27 09:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:19:54 --> Input Class Initialized
INFO - 2020-01-27 09:19:54 --> Language Class Initialized
INFO - 2020-01-27 09:19:54 --> Language Class Initialized
INFO - 2020-01-27 09:19:54 --> Config Class Initialized
INFO - 2020-01-27 09:19:54 --> Loader Class Initialized
INFO - 2020-01-27 09:19:54 --> Helper loaded: url_helper
INFO - 2020-01-27 09:19:54 --> Helper loaded: file_helper
INFO - 2020-01-27 09:19:54 --> Helper loaded: form_helper
INFO - 2020-01-27 09:19:54 --> Helper loaded: my_helper
INFO - 2020-01-27 09:19:54 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:19:54 --> Controller Class Initialized
DEBUG - 2020-01-27 09:19:54 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 09:19:54 --> Final output sent to browser
DEBUG - 2020-01-27 09:19:54 --> Total execution time: 0.5381
INFO - 2020-01-27 09:20:12 --> Config Class Initialized
INFO - 2020-01-27 09:20:12 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:20:12 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:20:12 --> Utf8 Class Initialized
INFO - 2020-01-27 09:20:12 --> URI Class Initialized
INFO - 2020-01-27 09:20:12 --> Router Class Initialized
INFO - 2020-01-27 09:20:12 --> Output Class Initialized
INFO - 2020-01-27 09:20:12 --> Security Class Initialized
DEBUG - 2020-01-27 09:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:20:12 --> Input Class Initialized
INFO - 2020-01-27 09:20:12 --> Language Class Initialized
INFO - 2020-01-27 09:20:12 --> Language Class Initialized
INFO - 2020-01-27 09:20:12 --> Config Class Initialized
INFO - 2020-01-27 09:20:12 --> Loader Class Initialized
INFO - 2020-01-27 09:20:12 --> Helper loaded: url_helper
INFO - 2020-01-27 09:20:12 --> Helper loaded: file_helper
INFO - 2020-01-27 09:20:12 --> Helper loaded: form_helper
INFO - 2020-01-27 09:20:12 --> Helper loaded: my_helper
INFO - 2020-01-27 09:20:12 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:20:12 --> Controller Class Initialized
DEBUG - 2020-01-27 09:20:12 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 09:20:12 --> Final output sent to browser
DEBUG - 2020-01-27 09:20:12 --> Total execution time: 0.5424
INFO - 2020-01-27 09:20:28 --> Config Class Initialized
INFO - 2020-01-27 09:20:28 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:20:28 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:20:28 --> Utf8 Class Initialized
INFO - 2020-01-27 09:20:28 --> URI Class Initialized
INFO - 2020-01-27 09:20:28 --> Router Class Initialized
INFO - 2020-01-27 09:20:28 --> Output Class Initialized
INFO - 2020-01-27 09:20:28 --> Security Class Initialized
DEBUG - 2020-01-27 09:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:20:28 --> Input Class Initialized
INFO - 2020-01-27 09:20:28 --> Language Class Initialized
INFO - 2020-01-27 09:20:28 --> Language Class Initialized
INFO - 2020-01-27 09:20:28 --> Config Class Initialized
INFO - 2020-01-27 09:20:28 --> Loader Class Initialized
INFO - 2020-01-27 09:20:28 --> Helper loaded: url_helper
INFO - 2020-01-27 09:20:28 --> Helper loaded: file_helper
INFO - 2020-01-27 09:20:28 --> Helper loaded: form_helper
INFO - 2020-01-27 09:20:28 --> Helper loaded: my_helper
INFO - 2020-01-27 09:20:28 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:20:29 --> Controller Class Initialized
ERROR - 2020-01-27 09:20:29 --> Query error: Unknown column 't_mapel_kd.id' in 'order clause' - Invalid query: SELECT a.* 
                                    FROM t_mapel_kd a
                                    LEFT JOIN m_kelas b ON a.tingkat = b.tingkat
                                    WHERE a.id_guru = '1'
                                    AND a.id_mapel = '1'
                                    AND b.id = 1 
                                    AND a.semester = '2'
                                    AND a.jenis = 'K' order by t_mapel_kd.id asc
INFO - 2020-01-27 09:20:29 --> Language file loaded: language/english/db_lang.php
INFO - 2020-01-27 09:20:56 --> Config Class Initialized
INFO - 2020-01-27 09:20:56 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:20:56 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:20:56 --> Utf8 Class Initialized
INFO - 2020-01-27 09:20:56 --> URI Class Initialized
INFO - 2020-01-27 09:20:56 --> Router Class Initialized
INFO - 2020-01-27 09:20:56 --> Output Class Initialized
INFO - 2020-01-27 09:20:56 --> Security Class Initialized
DEBUG - 2020-01-27 09:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:20:56 --> Input Class Initialized
INFO - 2020-01-27 09:20:56 --> Language Class Initialized
INFO - 2020-01-27 09:20:56 --> Language Class Initialized
INFO - 2020-01-27 09:20:56 --> Config Class Initialized
INFO - 2020-01-27 09:20:56 --> Loader Class Initialized
INFO - 2020-01-27 09:20:56 --> Helper loaded: url_helper
INFO - 2020-01-27 09:20:56 --> Helper loaded: file_helper
INFO - 2020-01-27 09:20:56 --> Helper loaded: form_helper
INFO - 2020-01-27 09:20:56 --> Helper loaded: my_helper
INFO - 2020-01-27 09:20:56 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:20:56 --> Controller Class Initialized
ERROR - 2020-01-27 09:20:56 --> Query error: Unknown column 't_mapel_kd.id' in 'order clause' - Invalid query: SELECT a.* 
                                    FROM t_mapel_kd a
                                    LEFT JOIN m_kelas b ON a.tingkat = b.tingkat
                                    WHERE a.id_guru = '1'
                                    AND a.id_mapel = '1'
                                    AND b.id = 1 
                                    AND a.semester = '2'
                                    AND a.jenis = 'K' order by t_mapel_kd.id asc
INFO - 2020-01-27 09:20:56 --> Language file loaded: language/english/db_lang.php
INFO - 2020-01-27 09:21:45 --> Config Class Initialized
INFO - 2020-01-27 09:21:45 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:21:45 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:21:45 --> Utf8 Class Initialized
INFO - 2020-01-27 09:21:45 --> URI Class Initialized
INFO - 2020-01-27 09:21:45 --> Router Class Initialized
INFO - 2020-01-27 09:21:45 --> Output Class Initialized
INFO - 2020-01-27 09:21:45 --> Security Class Initialized
DEBUG - 2020-01-27 09:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:21:45 --> Input Class Initialized
INFO - 2020-01-27 09:21:45 --> Language Class Initialized
INFO - 2020-01-27 09:21:45 --> Language Class Initialized
INFO - 2020-01-27 09:21:45 --> Config Class Initialized
INFO - 2020-01-27 09:21:45 --> Loader Class Initialized
INFO - 2020-01-27 09:21:45 --> Helper loaded: url_helper
INFO - 2020-01-27 09:21:45 --> Helper loaded: file_helper
INFO - 2020-01-27 09:21:45 --> Helper loaded: form_helper
INFO - 2020-01-27 09:21:45 --> Helper loaded: my_helper
INFO - 2020-01-27 09:21:45 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:21:45 --> Controller Class Initialized
DEBUG - 2020-01-27 09:21:45 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 09:21:45 --> Final output sent to browser
DEBUG - 2020-01-27 09:21:45 --> Total execution time: 0.5585
INFO - 2020-01-27 09:24:11 --> Config Class Initialized
INFO - 2020-01-27 09:24:11 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:24:11 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:24:11 --> Utf8 Class Initialized
INFO - 2020-01-27 09:24:11 --> URI Class Initialized
INFO - 2020-01-27 09:24:11 --> Router Class Initialized
INFO - 2020-01-27 09:24:11 --> Output Class Initialized
INFO - 2020-01-27 09:24:11 --> Security Class Initialized
DEBUG - 2020-01-27 09:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:24:11 --> Input Class Initialized
INFO - 2020-01-27 09:24:11 --> Language Class Initialized
INFO - 2020-01-27 09:24:11 --> Language Class Initialized
INFO - 2020-01-27 09:24:11 --> Config Class Initialized
INFO - 2020-01-27 09:24:11 --> Loader Class Initialized
INFO - 2020-01-27 09:24:11 --> Helper loaded: url_helper
INFO - 2020-01-27 09:24:11 --> Helper loaded: file_helper
INFO - 2020-01-27 09:24:11 --> Helper loaded: form_helper
INFO - 2020-01-27 09:24:11 --> Helper loaded: my_helper
INFO - 2020-01-27 09:24:11 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:24:11 --> Controller Class Initialized
DEBUG - 2020-01-27 09:24:11 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 09:24:11 --> Final output sent to browser
DEBUG - 2020-01-27 09:24:11 --> Total execution time: 0.5500
INFO - 2020-01-27 09:24:13 --> Config Class Initialized
INFO - 2020-01-27 09:24:13 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:24:13 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:24:13 --> Utf8 Class Initialized
INFO - 2020-01-27 09:24:13 --> URI Class Initialized
INFO - 2020-01-27 09:24:13 --> Router Class Initialized
INFO - 2020-01-27 09:24:13 --> Output Class Initialized
INFO - 2020-01-27 09:24:13 --> Security Class Initialized
DEBUG - 2020-01-27 09:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:24:13 --> Input Class Initialized
INFO - 2020-01-27 09:24:13 --> Language Class Initialized
INFO - 2020-01-27 09:24:13 --> Language Class Initialized
INFO - 2020-01-27 09:24:13 --> Config Class Initialized
INFO - 2020-01-27 09:24:13 --> Loader Class Initialized
INFO - 2020-01-27 09:24:13 --> Helper loaded: url_helper
INFO - 2020-01-27 09:24:13 --> Helper loaded: file_helper
INFO - 2020-01-27 09:24:13 --> Helper loaded: form_helper
INFO - 2020-01-27 09:24:13 --> Helper loaded: my_helper
INFO - 2020-01-27 09:24:13 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:24:14 --> Controller Class Initialized
DEBUG - 2020-01-27 09:24:14 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 09:24:14 --> Final output sent to browser
DEBUG - 2020-01-27 09:24:14 --> Total execution time: 0.5252
INFO - 2020-01-27 09:25:11 --> Config Class Initialized
INFO - 2020-01-27 09:25:11 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:25:11 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:25:11 --> Utf8 Class Initialized
INFO - 2020-01-27 09:25:11 --> URI Class Initialized
INFO - 2020-01-27 09:25:11 --> Router Class Initialized
INFO - 2020-01-27 09:25:11 --> Output Class Initialized
INFO - 2020-01-27 09:25:11 --> Security Class Initialized
DEBUG - 2020-01-27 09:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:25:11 --> Input Class Initialized
INFO - 2020-01-27 09:25:11 --> Language Class Initialized
INFO - 2020-01-27 09:25:11 --> Language Class Initialized
INFO - 2020-01-27 09:25:11 --> Config Class Initialized
INFO - 2020-01-27 09:25:11 --> Loader Class Initialized
INFO - 2020-01-27 09:25:11 --> Helper loaded: url_helper
INFO - 2020-01-27 09:25:11 --> Helper loaded: file_helper
INFO - 2020-01-27 09:25:11 --> Helper loaded: form_helper
INFO - 2020-01-27 09:25:11 --> Helper loaded: my_helper
INFO - 2020-01-27 09:25:11 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:25:11 --> Controller Class Initialized
DEBUG - 2020-01-27 09:25:11 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 09:25:11 --> Final output sent to browser
DEBUG - 2020-01-27 09:25:11 --> Total execution time: 0.5469
INFO - 2020-01-27 09:25:47 --> Config Class Initialized
INFO - 2020-01-27 09:25:47 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:25:47 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:25:47 --> Utf8 Class Initialized
INFO - 2020-01-27 09:25:47 --> URI Class Initialized
INFO - 2020-01-27 09:25:47 --> Router Class Initialized
INFO - 2020-01-27 09:25:48 --> Output Class Initialized
INFO - 2020-01-27 09:25:48 --> Security Class Initialized
DEBUG - 2020-01-27 09:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:25:48 --> Input Class Initialized
INFO - 2020-01-27 09:25:48 --> Language Class Initialized
INFO - 2020-01-27 09:25:48 --> Language Class Initialized
INFO - 2020-01-27 09:25:48 --> Config Class Initialized
INFO - 2020-01-27 09:25:48 --> Loader Class Initialized
INFO - 2020-01-27 09:25:48 --> Helper loaded: url_helper
INFO - 2020-01-27 09:25:48 --> Helper loaded: file_helper
INFO - 2020-01-27 09:25:48 --> Helper loaded: form_helper
INFO - 2020-01-27 09:25:48 --> Helper loaded: my_helper
INFO - 2020-01-27 09:25:48 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:25:48 --> Controller Class Initialized
DEBUG - 2020-01-27 09:25:48 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 09:25:48 --> Final output sent to browser
DEBUG - 2020-01-27 09:25:48 --> Total execution time: 0.5370
INFO - 2020-01-27 09:25:56 --> Config Class Initialized
INFO - 2020-01-27 09:25:56 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:25:56 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:25:56 --> Utf8 Class Initialized
INFO - 2020-01-27 09:25:56 --> URI Class Initialized
INFO - 2020-01-27 09:25:56 --> Router Class Initialized
INFO - 2020-01-27 09:25:56 --> Output Class Initialized
INFO - 2020-01-27 09:25:56 --> Security Class Initialized
DEBUG - 2020-01-27 09:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:25:57 --> Input Class Initialized
INFO - 2020-01-27 09:25:57 --> Language Class Initialized
INFO - 2020-01-27 09:25:57 --> Language Class Initialized
INFO - 2020-01-27 09:25:57 --> Config Class Initialized
INFO - 2020-01-27 09:25:57 --> Loader Class Initialized
INFO - 2020-01-27 09:25:57 --> Helper loaded: url_helper
INFO - 2020-01-27 09:25:57 --> Helper loaded: file_helper
INFO - 2020-01-27 09:25:57 --> Helper loaded: form_helper
INFO - 2020-01-27 09:25:57 --> Helper loaded: my_helper
INFO - 2020-01-27 09:25:57 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:25:57 --> Controller Class Initialized
INFO - 2020-01-27 09:25:57 --> Final output sent to browser
DEBUG - 2020-01-27 09:25:57 --> Total execution time: 0.4749
INFO - 2020-01-27 09:26:02 --> Config Class Initialized
INFO - 2020-01-27 09:26:02 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:26:02 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:26:02 --> Utf8 Class Initialized
INFO - 2020-01-27 09:26:02 --> URI Class Initialized
INFO - 2020-01-27 09:26:02 --> Router Class Initialized
INFO - 2020-01-27 09:26:02 --> Output Class Initialized
INFO - 2020-01-27 09:26:02 --> Security Class Initialized
DEBUG - 2020-01-27 09:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:26:03 --> Input Class Initialized
INFO - 2020-01-27 09:26:03 --> Language Class Initialized
INFO - 2020-01-27 09:26:03 --> Language Class Initialized
INFO - 2020-01-27 09:26:03 --> Config Class Initialized
INFO - 2020-01-27 09:26:03 --> Loader Class Initialized
INFO - 2020-01-27 09:26:03 --> Helper loaded: url_helper
INFO - 2020-01-27 09:26:03 --> Helper loaded: file_helper
INFO - 2020-01-27 09:26:03 --> Helper loaded: form_helper
INFO - 2020-01-27 09:26:03 --> Helper loaded: my_helper
INFO - 2020-01-27 09:26:03 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:26:03 --> Controller Class Initialized
INFO - 2020-01-27 09:26:03 --> Final output sent to browser
DEBUG - 2020-01-27 09:26:03 --> Total execution time: 0.5254
INFO - 2020-01-27 09:26:06 --> Config Class Initialized
INFO - 2020-01-27 09:26:06 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:26:07 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:26:07 --> Utf8 Class Initialized
INFO - 2020-01-27 09:26:07 --> URI Class Initialized
INFO - 2020-01-27 09:26:07 --> Router Class Initialized
INFO - 2020-01-27 09:26:07 --> Output Class Initialized
INFO - 2020-01-27 09:26:07 --> Security Class Initialized
DEBUG - 2020-01-27 09:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:26:07 --> Input Class Initialized
INFO - 2020-01-27 09:26:07 --> Language Class Initialized
INFO - 2020-01-27 09:26:07 --> Language Class Initialized
INFO - 2020-01-27 09:26:07 --> Config Class Initialized
INFO - 2020-01-27 09:26:07 --> Loader Class Initialized
INFO - 2020-01-27 09:26:07 --> Helper loaded: url_helper
INFO - 2020-01-27 09:26:07 --> Helper loaded: file_helper
INFO - 2020-01-27 09:26:07 --> Helper loaded: form_helper
INFO - 2020-01-27 09:26:07 --> Helper loaded: my_helper
INFO - 2020-01-27 09:26:07 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:26:07 --> Controller Class Initialized
DEBUG - 2020-01-27 09:26:07 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 09:26:07 --> Final output sent to browser
DEBUG - 2020-01-27 09:26:07 --> Total execution time: 0.6012
INFO - 2020-01-27 09:26:09 --> Config Class Initialized
INFO - 2020-01-27 09:26:09 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:26:09 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:26:09 --> Utf8 Class Initialized
INFO - 2020-01-27 09:26:09 --> URI Class Initialized
INFO - 2020-01-27 09:26:09 --> Router Class Initialized
INFO - 2020-01-27 09:26:09 --> Output Class Initialized
INFO - 2020-01-27 09:26:09 --> Security Class Initialized
DEBUG - 2020-01-27 09:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:26:09 --> Input Class Initialized
INFO - 2020-01-27 09:26:09 --> Language Class Initialized
INFO - 2020-01-27 09:26:09 --> Language Class Initialized
INFO - 2020-01-27 09:26:09 --> Config Class Initialized
INFO - 2020-01-27 09:26:09 --> Loader Class Initialized
INFO - 2020-01-27 09:26:09 --> Helper loaded: url_helper
INFO - 2020-01-27 09:26:09 --> Helper loaded: file_helper
INFO - 2020-01-27 09:26:09 --> Helper loaded: form_helper
INFO - 2020-01-27 09:26:09 --> Helper loaded: my_helper
INFO - 2020-01-27 09:26:09 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:26:09 --> Controller Class Initialized
DEBUG - 2020-01-27 09:26:09 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 09:26:09 --> Final output sent to browser
DEBUG - 2020-01-27 09:26:09 --> Total execution time: 0.5592
INFO - 2020-01-27 09:26:15 --> Config Class Initialized
INFO - 2020-01-27 09:26:15 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:26:15 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:26:15 --> Utf8 Class Initialized
INFO - 2020-01-27 09:26:15 --> URI Class Initialized
INFO - 2020-01-27 09:26:15 --> Router Class Initialized
INFO - 2020-01-27 09:26:15 --> Output Class Initialized
INFO - 2020-01-27 09:26:15 --> Security Class Initialized
DEBUG - 2020-01-27 09:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:26:15 --> Input Class Initialized
INFO - 2020-01-27 09:26:15 --> Language Class Initialized
INFO - 2020-01-27 09:26:15 --> Language Class Initialized
INFO - 2020-01-27 09:26:15 --> Config Class Initialized
INFO - 2020-01-27 09:26:15 --> Loader Class Initialized
INFO - 2020-01-27 09:26:15 --> Helper loaded: url_helper
INFO - 2020-01-27 09:26:15 --> Helper loaded: file_helper
INFO - 2020-01-27 09:26:15 --> Helper loaded: form_helper
INFO - 2020-01-27 09:26:15 --> Helper loaded: my_helper
INFO - 2020-01-27 09:26:15 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:26:15 --> Controller Class Initialized
INFO - 2020-01-27 09:26:15 --> Final output sent to browser
DEBUG - 2020-01-27 09:26:15 --> Total execution time: 0.4927
INFO - 2020-01-27 09:26:21 --> Config Class Initialized
INFO - 2020-01-27 09:26:21 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:26:21 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:26:21 --> Utf8 Class Initialized
INFO - 2020-01-27 09:26:21 --> URI Class Initialized
INFO - 2020-01-27 09:26:21 --> Router Class Initialized
INFO - 2020-01-27 09:26:21 --> Output Class Initialized
INFO - 2020-01-27 09:26:21 --> Security Class Initialized
DEBUG - 2020-01-27 09:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:26:21 --> Input Class Initialized
INFO - 2020-01-27 09:26:21 --> Language Class Initialized
INFO - 2020-01-27 09:26:21 --> Language Class Initialized
INFO - 2020-01-27 09:26:21 --> Config Class Initialized
INFO - 2020-01-27 09:26:21 --> Loader Class Initialized
INFO - 2020-01-27 09:26:21 --> Helper loaded: url_helper
INFO - 2020-01-27 09:26:21 --> Helper loaded: file_helper
INFO - 2020-01-27 09:26:21 --> Helper loaded: form_helper
INFO - 2020-01-27 09:26:21 --> Helper loaded: my_helper
INFO - 2020-01-27 09:26:21 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:26:21 --> Controller Class Initialized
INFO - 2020-01-27 09:26:21 --> Final output sent to browser
DEBUG - 2020-01-27 09:26:21 --> Total execution time: 0.5177
INFO - 2020-01-27 09:26:24 --> Config Class Initialized
INFO - 2020-01-27 09:26:24 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:26:24 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:26:24 --> Utf8 Class Initialized
INFO - 2020-01-27 09:26:24 --> URI Class Initialized
INFO - 2020-01-27 09:26:24 --> Router Class Initialized
INFO - 2020-01-27 09:26:24 --> Output Class Initialized
INFO - 2020-01-27 09:26:24 --> Security Class Initialized
DEBUG - 2020-01-27 09:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:26:24 --> Input Class Initialized
INFO - 2020-01-27 09:26:24 --> Language Class Initialized
INFO - 2020-01-27 09:26:24 --> Language Class Initialized
INFO - 2020-01-27 09:26:24 --> Config Class Initialized
INFO - 2020-01-27 09:26:24 --> Loader Class Initialized
INFO - 2020-01-27 09:26:24 --> Helper loaded: url_helper
INFO - 2020-01-27 09:26:24 --> Helper loaded: file_helper
INFO - 2020-01-27 09:26:24 --> Helper loaded: form_helper
INFO - 2020-01-27 09:26:24 --> Helper loaded: my_helper
INFO - 2020-01-27 09:26:24 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:26:24 --> Controller Class Initialized
DEBUG - 2020-01-27 09:26:24 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 09:26:24 --> Final output sent to browser
DEBUG - 2020-01-27 09:26:24 --> Total execution time: 0.6184
INFO - 2020-01-27 09:26:31 --> Config Class Initialized
INFO - 2020-01-27 09:26:31 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:26:31 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:26:32 --> Utf8 Class Initialized
INFO - 2020-01-27 09:26:32 --> URI Class Initialized
INFO - 2020-01-27 09:26:32 --> Router Class Initialized
INFO - 2020-01-27 09:26:32 --> Output Class Initialized
INFO - 2020-01-27 09:26:32 --> Security Class Initialized
DEBUG - 2020-01-27 09:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:26:32 --> Input Class Initialized
INFO - 2020-01-27 09:26:32 --> Language Class Initialized
INFO - 2020-01-27 09:26:32 --> Language Class Initialized
INFO - 2020-01-27 09:26:32 --> Config Class Initialized
INFO - 2020-01-27 09:26:32 --> Loader Class Initialized
INFO - 2020-01-27 09:26:32 --> Helper loaded: url_helper
INFO - 2020-01-27 09:26:32 --> Helper loaded: file_helper
INFO - 2020-01-27 09:26:32 --> Helper loaded: form_helper
INFO - 2020-01-27 09:26:32 --> Helper loaded: my_helper
INFO - 2020-01-27 09:26:32 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:26:32 --> Controller Class Initialized
DEBUG - 2020-01-27 09:26:32 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 09:26:32 --> Final output sent to browser
DEBUG - 2020-01-27 09:26:32 --> Total execution time: 0.5407
INFO - 2020-01-27 09:26:47 --> Config Class Initialized
INFO - 2020-01-27 09:26:47 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:26:47 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:26:47 --> Utf8 Class Initialized
INFO - 2020-01-27 09:26:47 --> URI Class Initialized
INFO - 2020-01-27 09:26:47 --> Router Class Initialized
INFO - 2020-01-27 09:26:47 --> Output Class Initialized
INFO - 2020-01-27 09:26:47 --> Security Class Initialized
DEBUG - 2020-01-27 09:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:26:47 --> Input Class Initialized
INFO - 2020-01-27 09:26:47 --> Language Class Initialized
INFO - 2020-01-27 09:26:47 --> Language Class Initialized
INFO - 2020-01-27 09:26:47 --> Config Class Initialized
INFO - 2020-01-27 09:26:47 --> Loader Class Initialized
INFO - 2020-01-27 09:26:47 --> Helper loaded: url_helper
INFO - 2020-01-27 09:26:47 --> Helper loaded: file_helper
INFO - 2020-01-27 09:26:47 --> Helper loaded: form_helper
INFO - 2020-01-27 09:26:47 --> Helper loaded: my_helper
INFO - 2020-01-27 09:26:47 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:26:47 --> Controller Class Initialized
INFO - 2020-01-27 09:26:47 --> Final output sent to browser
DEBUG - 2020-01-27 09:26:47 --> Total execution time: 0.4840
INFO - 2020-01-27 09:26:53 --> Config Class Initialized
INFO - 2020-01-27 09:26:53 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:26:53 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:26:53 --> Utf8 Class Initialized
INFO - 2020-01-27 09:26:53 --> URI Class Initialized
INFO - 2020-01-27 09:26:53 --> Router Class Initialized
INFO - 2020-01-27 09:26:53 --> Output Class Initialized
INFO - 2020-01-27 09:26:53 --> Security Class Initialized
DEBUG - 2020-01-27 09:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:26:53 --> Input Class Initialized
INFO - 2020-01-27 09:26:53 --> Language Class Initialized
INFO - 2020-01-27 09:26:53 --> Language Class Initialized
INFO - 2020-01-27 09:26:53 --> Config Class Initialized
INFO - 2020-01-27 09:26:53 --> Loader Class Initialized
INFO - 2020-01-27 09:26:53 --> Helper loaded: url_helper
INFO - 2020-01-27 09:26:53 --> Helper loaded: file_helper
INFO - 2020-01-27 09:26:53 --> Helper loaded: form_helper
INFO - 2020-01-27 09:26:53 --> Helper loaded: my_helper
INFO - 2020-01-27 09:26:53 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:26:54 --> Controller Class Initialized
INFO - 2020-01-27 09:26:54 --> Final output sent to browser
DEBUG - 2020-01-27 09:26:54 --> Total execution time: 0.4933
INFO - 2020-01-27 09:26:57 --> Config Class Initialized
INFO - 2020-01-27 09:26:57 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:26:57 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:26:57 --> Utf8 Class Initialized
INFO - 2020-01-27 09:26:57 --> URI Class Initialized
INFO - 2020-01-27 09:26:57 --> Router Class Initialized
INFO - 2020-01-27 09:26:57 --> Output Class Initialized
INFO - 2020-01-27 09:26:57 --> Security Class Initialized
DEBUG - 2020-01-27 09:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:26:57 --> Input Class Initialized
INFO - 2020-01-27 09:26:57 --> Language Class Initialized
INFO - 2020-01-27 09:26:57 --> Language Class Initialized
INFO - 2020-01-27 09:26:57 --> Config Class Initialized
INFO - 2020-01-27 09:26:57 --> Loader Class Initialized
INFO - 2020-01-27 09:26:57 --> Helper loaded: url_helper
INFO - 2020-01-27 09:26:57 --> Helper loaded: file_helper
INFO - 2020-01-27 09:26:57 --> Helper loaded: form_helper
INFO - 2020-01-27 09:26:58 --> Helper loaded: my_helper
INFO - 2020-01-27 09:26:58 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:26:58 --> Controller Class Initialized
DEBUG - 2020-01-27 09:26:58 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 09:26:58 --> Final output sent to browser
DEBUG - 2020-01-27 09:26:58 --> Total execution time: 0.5440
INFO - 2020-01-27 09:27:00 --> Config Class Initialized
INFO - 2020-01-27 09:27:00 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:27:00 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:27:00 --> Utf8 Class Initialized
INFO - 2020-01-27 09:27:00 --> URI Class Initialized
INFO - 2020-01-27 09:27:00 --> Router Class Initialized
INFO - 2020-01-27 09:27:01 --> Output Class Initialized
INFO - 2020-01-27 09:27:01 --> Security Class Initialized
DEBUG - 2020-01-27 09:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:27:01 --> Input Class Initialized
INFO - 2020-01-27 09:27:01 --> Language Class Initialized
INFO - 2020-01-27 09:27:01 --> Language Class Initialized
INFO - 2020-01-27 09:27:01 --> Config Class Initialized
INFO - 2020-01-27 09:27:01 --> Loader Class Initialized
INFO - 2020-01-27 09:27:01 --> Helper loaded: url_helper
INFO - 2020-01-27 09:27:01 --> Helper loaded: file_helper
INFO - 2020-01-27 09:27:01 --> Helper loaded: form_helper
INFO - 2020-01-27 09:27:01 --> Helper loaded: my_helper
INFO - 2020-01-27 09:27:01 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:27:01 --> Controller Class Initialized
INFO - 2020-01-27 09:27:01 --> Final output sent to browser
DEBUG - 2020-01-27 09:27:01 --> Total execution time: 0.5516
INFO - 2020-01-27 09:27:02 --> Config Class Initialized
INFO - 2020-01-27 09:27:02 --> Hooks Class Initialized
DEBUG - 2020-01-27 09:27:02 --> UTF-8 Support Enabled
INFO - 2020-01-27 09:27:02 --> Utf8 Class Initialized
INFO - 2020-01-27 09:27:02 --> URI Class Initialized
INFO - 2020-01-27 09:27:02 --> Router Class Initialized
INFO - 2020-01-27 09:27:02 --> Output Class Initialized
INFO - 2020-01-27 09:27:02 --> Security Class Initialized
DEBUG - 2020-01-27 09:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 09:27:02 --> Input Class Initialized
INFO - 2020-01-27 09:27:02 --> Language Class Initialized
INFO - 2020-01-27 09:27:02 --> Language Class Initialized
INFO - 2020-01-27 09:27:02 --> Config Class Initialized
INFO - 2020-01-27 09:27:02 --> Loader Class Initialized
INFO - 2020-01-27 09:27:02 --> Helper loaded: url_helper
INFO - 2020-01-27 09:27:02 --> Helper loaded: file_helper
INFO - 2020-01-27 09:27:02 --> Helper loaded: form_helper
INFO - 2020-01-27 09:27:02 --> Helper loaded: my_helper
INFO - 2020-01-27 09:27:02 --> Database Driver Class Initialized
DEBUG - 2020-01-27 09:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 09:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 09:27:03 --> Controller Class Initialized
INFO - 2020-01-27 09:27:03 --> Final output sent to browser
DEBUG - 2020-01-27 09:27:03 --> Total execution time: 0.4825
INFO - 2020-01-27 12:05:50 --> Config Class Initialized
INFO - 2020-01-27 12:05:50 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:05:50 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:05:50 --> Utf8 Class Initialized
INFO - 2020-01-27 12:05:50 --> URI Class Initialized
INFO - 2020-01-27 12:05:50 --> Router Class Initialized
INFO - 2020-01-27 12:05:50 --> Output Class Initialized
INFO - 2020-01-27 12:05:50 --> Security Class Initialized
DEBUG - 2020-01-27 12:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:05:50 --> Input Class Initialized
INFO - 2020-01-27 12:05:50 --> Language Class Initialized
INFO - 2020-01-27 12:05:50 --> Language Class Initialized
INFO - 2020-01-27 12:05:50 --> Config Class Initialized
INFO - 2020-01-27 12:05:50 --> Loader Class Initialized
INFO - 2020-01-27 12:05:50 --> Helper loaded: url_helper
INFO - 2020-01-27 12:05:50 --> Helper loaded: file_helper
INFO - 2020-01-27 12:05:50 --> Helper loaded: form_helper
INFO - 2020-01-27 12:05:50 --> Helper loaded: my_helper
INFO - 2020-01-27 12:05:50 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:05:50 --> Controller Class Initialized
INFO - 2020-01-27 12:05:50 --> Final output sent to browser
DEBUG - 2020-01-27 12:05:50 --> Total execution time: 0.5015
INFO - 2020-01-27 12:05:59 --> Config Class Initialized
INFO - 2020-01-27 12:05:59 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:05:59 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:05:59 --> Utf8 Class Initialized
INFO - 2020-01-27 12:05:59 --> URI Class Initialized
INFO - 2020-01-27 12:05:59 --> Router Class Initialized
INFO - 2020-01-27 12:05:59 --> Output Class Initialized
INFO - 2020-01-27 12:05:59 --> Security Class Initialized
DEBUG - 2020-01-27 12:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:05:59 --> Input Class Initialized
INFO - 2020-01-27 12:05:59 --> Language Class Initialized
INFO - 2020-01-27 12:05:59 --> Language Class Initialized
INFO - 2020-01-27 12:05:59 --> Config Class Initialized
INFO - 2020-01-27 12:05:59 --> Loader Class Initialized
INFO - 2020-01-27 12:06:00 --> Helper loaded: url_helper
INFO - 2020-01-27 12:06:00 --> Helper loaded: file_helper
INFO - 2020-01-27 12:06:00 --> Helper loaded: form_helper
INFO - 2020-01-27 12:06:00 --> Helper loaded: my_helper
INFO - 2020-01-27 12:06:00 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:06:00 --> Controller Class Initialized
INFO - 2020-01-27 12:06:00 --> Final output sent to browser
DEBUG - 2020-01-27 12:06:00 --> Total execution time: 0.5262
INFO - 2020-01-27 12:06:05 --> Config Class Initialized
INFO - 2020-01-27 12:06:05 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:06:05 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:06:05 --> Utf8 Class Initialized
INFO - 2020-01-27 12:06:05 --> URI Class Initialized
INFO - 2020-01-27 12:06:05 --> Router Class Initialized
INFO - 2020-01-27 12:06:05 --> Output Class Initialized
INFO - 2020-01-27 12:06:05 --> Security Class Initialized
DEBUG - 2020-01-27 12:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:06:05 --> Input Class Initialized
INFO - 2020-01-27 12:06:05 --> Language Class Initialized
INFO - 2020-01-27 12:06:05 --> Language Class Initialized
INFO - 2020-01-27 12:06:05 --> Config Class Initialized
INFO - 2020-01-27 12:06:05 --> Loader Class Initialized
INFO - 2020-01-27 12:06:05 --> Helper loaded: url_helper
INFO - 2020-01-27 12:06:05 --> Helper loaded: file_helper
INFO - 2020-01-27 12:06:05 --> Helper loaded: form_helper
INFO - 2020-01-27 12:06:05 --> Helper loaded: my_helper
INFO - 2020-01-27 12:06:05 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:06:05 --> Controller Class Initialized
INFO - 2020-01-27 12:06:05 --> Final output sent to browser
DEBUG - 2020-01-27 12:06:05 --> Total execution time: 0.4806
INFO - 2020-01-27 12:06:06 --> Config Class Initialized
INFO - 2020-01-27 12:06:06 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:06:07 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:06:07 --> Utf8 Class Initialized
INFO - 2020-01-27 12:06:07 --> URI Class Initialized
INFO - 2020-01-27 12:06:07 --> Router Class Initialized
INFO - 2020-01-27 12:06:07 --> Output Class Initialized
INFO - 2020-01-27 12:06:07 --> Security Class Initialized
DEBUG - 2020-01-27 12:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:06:07 --> Input Class Initialized
INFO - 2020-01-27 12:06:07 --> Language Class Initialized
INFO - 2020-01-27 12:06:07 --> Language Class Initialized
INFO - 2020-01-27 12:06:07 --> Config Class Initialized
INFO - 2020-01-27 12:06:07 --> Loader Class Initialized
INFO - 2020-01-27 12:06:07 --> Helper loaded: url_helper
INFO - 2020-01-27 12:06:07 --> Helper loaded: file_helper
INFO - 2020-01-27 12:06:07 --> Helper loaded: form_helper
INFO - 2020-01-27 12:06:07 --> Helper loaded: my_helper
INFO - 2020-01-27 12:06:07 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:06:07 --> Controller Class Initialized
INFO - 2020-01-27 12:06:07 --> Final output sent to browser
DEBUG - 2020-01-27 12:06:07 --> Total execution time: 0.5714
INFO - 2020-01-27 12:07:21 --> Config Class Initialized
INFO - 2020-01-27 12:07:21 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:07:21 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:07:21 --> Utf8 Class Initialized
INFO - 2020-01-27 12:07:21 --> URI Class Initialized
INFO - 2020-01-27 12:07:21 --> Router Class Initialized
INFO - 2020-01-27 12:07:21 --> Output Class Initialized
INFO - 2020-01-27 12:07:21 --> Security Class Initialized
DEBUG - 2020-01-27 12:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:07:22 --> Input Class Initialized
INFO - 2020-01-27 12:07:22 --> Language Class Initialized
INFO - 2020-01-27 12:07:22 --> Language Class Initialized
INFO - 2020-01-27 12:07:22 --> Config Class Initialized
INFO - 2020-01-27 12:07:22 --> Loader Class Initialized
INFO - 2020-01-27 12:07:22 --> Helper loaded: url_helper
INFO - 2020-01-27 12:07:22 --> Helper loaded: file_helper
INFO - 2020-01-27 12:07:22 --> Helper loaded: form_helper
INFO - 2020-01-27 12:07:22 --> Helper loaded: my_helper
INFO - 2020-01-27 12:07:22 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:07:22 --> Controller Class Initialized
DEBUG - 2020-01-27 12:07:22 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-01-27 12:07:22 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 12:07:22 --> Final output sent to browser
DEBUG - 2020-01-27 12:07:22 --> Total execution time: 0.6480
INFO - 2020-01-27 12:07:24 --> Config Class Initialized
INFO - 2020-01-27 12:07:24 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:07:24 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:07:24 --> Utf8 Class Initialized
INFO - 2020-01-27 12:07:24 --> URI Class Initialized
INFO - 2020-01-27 12:07:24 --> Router Class Initialized
INFO - 2020-01-27 12:07:24 --> Output Class Initialized
INFO - 2020-01-27 12:07:24 --> Security Class Initialized
DEBUG - 2020-01-27 12:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:07:24 --> Input Class Initialized
INFO - 2020-01-27 12:07:24 --> Language Class Initialized
INFO - 2020-01-27 12:07:24 --> Language Class Initialized
INFO - 2020-01-27 12:07:24 --> Config Class Initialized
INFO - 2020-01-27 12:07:24 --> Loader Class Initialized
INFO - 2020-01-27 12:07:24 --> Helper loaded: url_helper
INFO - 2020-01-27 12:07:24 --> Helper loaded: file_helper
INFO - 2020-01-27 12:07:24 --> Helper loaded: form_helper
INFO - 2020-01-27 12:07:24 --> Helper loaded: my_helper
INFO - 2020-01-27 12:07:24 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:07:24 --> Controller Class Initialized
INFO - 2020-01-27 12:07:24 --> Final output sent to browser
DEBUG - 2020-01-27 12:07:25 --> Total execution time: 0.5196
INFO - 2020-01-27 12:07:30 --> Config Class Initialized
INFO - 2020-01-27 12:07:30 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:07:30 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:07:30 --> Utf8 Class Initialized
INFO - 2020-01-27 12:07:31 --> URI Class Initialized
INFO - 2020-01-27 12:07:31 --> Router Class Initialized
INFO - 2020-01-27 12:07:31 --> Output Class Initialized
INFO - 2020-01-27 12:07:31 --> Security Class Initialized
DEBUG - 2020-01-27 12:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:07:31 --> Input Class Initialized
INFO - 2020-01-27 12:07:31 --> Language Class Initialized
INFO - 2020-01-27 12:07:31 --> Language Class Initialized
INFO - 2020-01-27 12:07:31 --> Config Class Initialized
INFO - 2020-01-27 12:07:31 --> Loader Class Initialized
INFO - 2020-01-27 12:07:31 --> Helper loaded: url_helper
INFO - 2020-01-27 12:07:31 --> Helper loaded: file_helper
INFO - 2020-01-27 12:07:31 --> Helper loaded: form_helper
INFO - 2020-01-27 12:07:31 --> Helper loaded: my_helper
INFO - 2020-01-27 12:07:31 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:07:31 --> Controller Class Initialized
INFO - 2020-01-27 12:07:37 --> Config Class Initialized
INFO - 2020-01-27 12:07:37 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:07:37 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:07:37 --> Utf8 Class Initialized
INFO - 2020-01-27 12:07:37 --> URI Class Initialized
INFO - 2020-01-27 12:07:37 --> Router Class Initialized
INFO - 2020-01-27 12:07:37 --> Output Class Initialized
INFO - 2020-01-27 12:07:37 --> Security Class Initialized
DEBUG - 2020-01-27 12:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:07:37 --> Input Class Initialized
INFO - 2020-01-27 12:07:37 --> Language Class Initialized
ERROR - 2020-01-27 12:07:37 --> 404 Page Not Found: /index
INFO - 2020-01-27 12:07:50 --> Config Class Initialized
INFO - 2020-01-27 12:07:50 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:07:50 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:07:50 --> Utf8 Class Initialized
INFO - 2020-01-27 12:07:50 --> URI Class Initialized
INFO - 2020-01-27 12:07:50 --> Router Class Initialized
INFO - 2020-01-27 12:07:50 --> Output Class Initialized
INFO - 2020-01-27 12:07:50 --> Security Class Initialized
DEBUG - 2020-01-27 12:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:07:50 --> Input Class Initialized
INFO - 2020-01-27 12:07:50 --> Language Class Initialized
INFO - 2020-01-27 12:07:50 --> Language Class Initialized
INFO - 2020-01-27 12:07:50 --> Config Class Initialized
INFO - 2020-01-27 12:07:50 --> Loader Class Initialized
INFO - 2020-01-27 12:07:50 --> Helper loaded: url_helper
INFO - 2020-01-27 12:07:50 --> Helper loaded: file_helper
INFO - 2020-01-27 12:07:50 --> Helper loaded: form_helper
INFO - 2020-01-27 12:07:50 --> Helper loaded: my_helper
INFO - 2020-01-27 12:07:50 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:07:51 --> Controller Class Initialized
INFO - 2020-01-27 12:08:07 --> Config Class Initialized
INFO - 2020-01-27 12:08:07 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:08:07 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:08:07 --> Utf8 Class Initialized
INFO - 2020-01-27 12:08:07 --> URI Class Initialized
INFO - 2020-01-27 12:08:07 --> Router Class Initialized
INFO - 2020-01-27 12:08:07 --> Output Class Initialized
INFO - 2020-01-27 12:08:07 --> Security Class Initialized
DEBUG - 2020-01-27 12:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:08:07 --> Input Class Initialized
INFO - 2020-01-27 12:08:07 --> Language Class Initialized
INFO - 2020-01-27 12:08:07 --> Language Class Initialized
INFO - 2020-01-27 12:08:07 --> Config Class Initialized
INFO - 2020-01-27 12:08:07 --> Loader Class Initialized
INFO - 2020-01-27 12:08:07 --> Helper loaded: url_helper
INFO - 2020-01-27 12:08:07 --> Helper loaded: file_helper
INFO - 2020-01-27 12:08:07 --> Helper loaded: form_helper
INFO - 2020-01-27 12:08:07 --> Helper loaded: my_helper
INFO - 2020-01-27 12:08:07 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:08:07 --> Controller Class Initialized
DEBUG - 2020-01-27 12:08:07 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-01-27 12:08:07 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 12:08:07 --> Final output sent to browser
DEBUG - 2020-01-27 12:08:08 --> Total execution time: 0.7252
INFO - 2020-01-27 12:08:08 --> Config Class Initialized
INFO - 2020-01-27 12:08:08 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:08:08 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:08:08 --> Utf8 Class Initialized
INFO - 2020-01-27 12:08:08 --> URI Class Initialized
INFO - 2020-01-27 12:08:08 --> Router Class Initialized
INFO - 2020-01-27 12:08:08 --> Output Class Initialized
INFO - 2020-01-27 12:08:08 --> Security Class Initialized
DEBUG - 2020-01-27 12:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:08:08 --> Input Class Initialized
INFO - 2020-01-27 12:08:08 --> Language Class Initialized
ERROR - 2020-01-27 12:08:08 --> 404 Page Not Found: /index
INFO - 2020-01-27 12:08:11 --> Config Class Initialized
INFO - 2020-01-27 12:08:11 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:08:11 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:08:11 --> Utf8 Class Initialized
INFO - 2020-01-27 12:08:11 --> URI Class Initialized
INFO - 2020-01-27 12:08:11 --> Router Class Initialized
INFO - 2020-01-27 12:08:11 --> Output Class Initialized
INFO - 2020-01-27 12:08:11 --> Security Class Initialized
DEBUG - 2020-01-27 12:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:08:11 --> Input Class Initialized
INFO - 2020-01-27 12:08:11 --> Language Class Initialized
INFO - 2020-01-27 12:08:11 --> Language Class Initialized
INFO - 2020-01-27 12:08:11 --> Config Class Initialized
INFO - 2020-01-27 12:08:11 --> Loader Class Initialized
INFO - 2020-01-27 12:08:11 --> Helper loaded: url_helper
INFO - 2020-01-27 12:08:11 --> Helper loaded: file_helper
INFO - 2020-01-27 12:08:11 --> Helper loaded: form_helper
INFO - 2020-01-27 12:08:11 --> Helper loaded: my_helper
INFO - 2020-01-27 12:08:11 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:08:11 --> Controller Class Initialized
INFO - 2020-01-27 12:08:11 --> Final output sent to browser
DEBUG - 2020-01-27 12:08:11 --> Total execution time: 0.5133
INFO - 2020-01-27 12:08:11 --> Config Class Initialized
INFO - 2020-01-27 12:08:11 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:08:11 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:08:11 --> Utf8 Class Initialized
INFO - 2020-01-27 12:08:11 --> URI Class Initialized
INFO - 2020-01-27 12:08:11 --> Router Class Initialized
INFO - 2020-01-27 12:08:11 --> Output Class Initialized
INFO - 2020-01-27 12:08:11 --> Security Class Initialized
DEBUG - 2020-01-27 12:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:08:11 --> Input Class Initialized
INFO - 2020-01-27 12:08:11 --> Language Class Initialized
INFO - 2020-01-27 12:08:11 --> Language Class Initialized
INFO - 2020-01-27 12:08:11 --> Config Class Initialized
INFO - 2020-01-27 12:08:11 --> Loader Class Initialized
INFO - 2020-01-27 12:08:11 --> Helper loaded: url_helper
INFO - 2020-01-27 12:08:11 --> Helper loaded: file_helper
INFO - 2020-01-27 12:08:12 --> Helper loaded: form_helper
INFO - 2020-01-27 12:08:12 --> Helper loaded: my_helper
INFO - 2020-01-27 12:08:12 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:08:12 --> Controller Class Initialized
INFO - 2020-01-27 12:08:12 --> Final output sent to browser
DEBUG - 2020-01-27 12:08:12 --> Total execution time: 0.5032
INFO - 2020-01-27 12:08:18 --> Config Class Initialized
INFO - 2020-01-27 12:08:18 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:08:18 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:08:18 --> Utf8 Class Initialized
INFO - 2020-01-27 12:08:19 --> URI Class Initialized
INFO - 2020-01-27 12:08:19 --> Router Class Initialized
INFO - 2020-01-27 12:08:19 --> Output Class Initialized
INFO - 2020-01-27 12:08:19 --> Security Class Initialized
DEBUG - 2020-01-27 12:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:08:19 --> Input Class Initialized
INFO - 2020-01-27 12:08:19 --> Language Class Initialized
INFO - 2020-01-27 12:08:19 --> Language Class Initialized
INFO - 2020-01-27 12:08:19 --> Config Class Initialized
INFO - 2020-01-27 12:08:19 --> Loader Class Initialized
INFO - 2020-01-27 12:08:19 --> Helper loaded: url_helper
INFO - 2020-01-27 12:08:19 --> Helper loaded: file_helper
INFO - 2020-01-27 12:08:19 --> Helper loaded: form_helper
INFO - 2020-01-27 12:08:19 --> Helper loaded: my_helper
INFO - 2020-01-27 12:08:19 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:08:19 --> Controller Class Initialized
INFO - 2020-01-27 12:08:19 --> Final output sent to browser
DEBUG - 2020-01-27 12:08:19 --> Total execution time: 0.5397
INFO - 2020-01-27 12:08:50 --> Config Class Initialized
INFO - 2020-01-27 12:08:50 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:08:50 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:08:50 --> Utf8 Class Initialized
INFO - 2020-01-27 12:08:50 --> URI Class Initialized
INFO - 2020-01-27 12:08:50 --> Router Class Initialized
INFO - 2020-01-27 12:08:50 --> Output Class Initialized
INFO - 2020-01-27 12:08:50 --> Security Class Initialized
DEBUG - 2020-01-27 12:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:08:50 --> Input Class Initialized
INFO - 2020-01-27 12:08:50 --> Language Class Initialized
INFO - 2020-01-27 12:08:50 --> Language Class Initialized
INFO - 2020-01-27 12:08:50 --> Config Class Initialized
INFO - 2020-01-27 12:08:50 --> Loader Class Initialized
INFO - 2020-01-27 12:08:50 --> Helper loaded: url_helper
INFO - 2020-01-27 12:08:50 --> Helper loaded: file_helper
INFO - 2020-01-27 12:08:50 --> Helper loaded: form_helper
INFO - 2020-01-27 12:08:50 --> Helper loaded: my_helper
INFO - 2020-01-27 12:08:50 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:08:50 --> Controller Class Initialized
DEBUG - 2020-01-27 12:08:50 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-01-27 12:08:51 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 12:08:51 --> Final output sent to browser
DEBUG - 2020-01-27 12:08:51 --> Total execution time: 0.6479
INFO - 2020-01-27 12:08:51 --> Config Class Initialized
INFO - 2020-01-27 12:08:51 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:08:51 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:08:51 --> Utf8 Class Initialized
INFO - 2020-01-27 12:08:51 --> URI Class Initialized
INFO - 2020-01-27 12:08:51 --> Router Class Initialized
INFO - 2020-01-27 12:08:51 --> Output Class Initialized
INFO - 2020-01-27 12:08:51 --> Security Class Initialized
DEBUG - 2020-01-27 12:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:08:51 --> Input Class Initialized
INFO - 2020-01-27 12:08:51 --> Language Class Initialized
ERROR - 2020-01-27 12:08:51 --> 404 Page Not Found: /index
INFO - 2020-01-27 12:08:53 --> Config Class Initialized
INFO - 2020-01-27 12:08:53 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:08:53 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:08:53 --> Utf8 Class Initialized
INFO - 2020-01-27 12:08:53 --> URI Class Initialized
INFO - 2020-01-27 12:08:53 --> Router Class Initialized
INFO - 2020-01-27 12:08:53 --> Output Class Initialized
INFO - 2020-01-27 12:08:53 --> Security Class Initialized
DEBUG - 2020-01-27 12:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:08:53 --> Input Class Initialized
INFO - 2020-01-27 12:08:53 --> Language Class Initialized
INFO - 2020-01-27 12:08:53 --> Language Class Initialized
INFO - 2020-01-27 12:08:53 --> Config Class Initialized
INFO - 2020-01-27 12:08:53 --> Loader Class Initialized
INFO - 2020-01-27 12:08:53 --> Helper loaded: url_helper
INFO - 2020-01-27 12:08:53 --> Helper loaded: file_helper
INFO - 2020-01-27 12:08:53 --> Helper loaded: form_helper
INFO - 2020-01-27 12:08:53 --> Helper loaded: my_helper
INFO - 2020-01-27 12:08:53 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:08:53 --> Controller Class Initialized
INFO - 2020-01-27 12:08:53 --> Final output sent to browser
DEBUG - 2020-01-27 12:08:53 --> Total execution time: 0.5080
INFO - 2020-01-27 12:09:02 --> Config Class Initialized
INFO - 2020-01-27 12:09:02 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:09:02 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:09:02 --> Utf8 Class Initialized
INFO - 2020-01-27 12:09:02 --> URI Class Initialized
INFO - 2020-01-27 12:09:02 --> Router Class Initialized
INFO - 2020-01-27 12:09:02 --> Output Class Initialized
INFO - 2020-01-27 12:09:02 --> Security Class Initialized
DEBUG - 2020-01-27 12:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:09:02 --> Input Class Initialized
INFO - 2020-01-27 12:09:02 --> Language Class Initialized
INFO - 2020-01-27 12:09:02 --> Language Class Initialized
INFO - 2020-01-27 12:09:02 --> Config Class Initialized
INFO - 2020-01-27 12:09:02 --> Loader Class Initialized
INFO - 2020-01-27 12:09:02 --> Helper loaded: url_helper
INFO - 2020-01-27 12:09:02 --> Helper loaded: file_helper
INFO - 2020-01-27 12:09:02 --> Helper loaded: form_helper
INFO - 2020-01-27 12:09:02 --> Helper loaded: my_helper
INFO - 2020-01-27 12:09:02 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:09:02 --> Controller Class Initialized
INFO - 2020-01-27 12:10:32 --> Config Class Initialized
INFO - 2020-01-27 12:10:32 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:10:32 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:10:32 --> Utf8 Class Initialized
INFO - 2020-01-27 12:10:32 --> URI Class Initialized
INFO - 2020-01-27 12:10:32 --> Router Class Initialized
INFO - 2020-01-27 12:10:32 --> Output Class Initialized
INFO - 2020-01-27 12:10:32 --> Security Class Initialized
DEBUG - 2020-01-27 12:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:10:32 --> Input Class Initialized
INFO - 2020-01-27 12:10:32 --> Language Class Initialized
INFO - 2020-01-27 12:10:32 --> Language Class Initialized
INFO - 2020-01-27 12:10:32 --> Config Class Initialized
INFO - 2020-01-27 12:10:32 --> Loader Class Initialized
INFO - 2020-01-27 12:10:32 --> Helper loaded: url_helper
INFO - 2020-01-27 12:10:32 --> Helper loaded: file_helper
INFO - 2020-01-27 12:10:32 --> Helper loaded: form_helper
INFO - 2020-01-27 12:10:32 --> Helper loaded: my_helper
INFO - 2020-01-27 12:10:32 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:10:32 --> Controller Class Initialized
DEBUG - 2020-01-27 12:10:33 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-01-27 12:10:33 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 12:10:33 --> Final output sent to browser
DEBUG - 2020-01-27 12:10:33 --> Total execution time: 0.6495
INFO - 2020-01-27 12:10:33 --> Config Class Initialized
INFO - 2020-01-27 12:10:33 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:10:33 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:10:33 --> Utf8 Class Initialized
INFO - 2020-01-27 12:10:33 --> URI Class Initialized
INFO - 2020-01-27 12:10:33 --> Router Class Initialized
INFO - 2020-01-27 12:10:33 --> Output Class Initialized
INFO - 2020-01-27 12:10:33 --> Security Class Initialized
DEBUG - 2020-01-27 12:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:10:33 --> Input Class Initialized
INFO - 2020-01-27 12:10:33 --> Language Class Initialized
ERROR - 2020-01-27 12:10:33 --> 404 Page Not Found: /index
INFO - 2020-01-27 12:10:36 --> Config Class Initialized
INFO - 2020-01-27 12:10:36 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:10:36 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:10:36 --> Utf8 Class Initialized
INFO - 2020-01-27 12:10:36 --> URI Class Initialized
INFO - 2020-01-27 12:10:36 --> Router Class Initialized
INFO - 2020-01-27 12:10:36 --> Output Class Initialized
INFO - 2020-01-27 12:10:36 --> Security Class Initialized
DEBUG - 2020-01-27 12:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:10:36 --> Input Class Initialized
INFO - 2020-01-27 12:10:36 --> Language Class Initialized
INFO - 2020-01-27 12:10:36 --> Language Class Initialized
INFO - 2020-01-27 12:10:36 --> Config Class Initialized
INFO - 2020-01-27 12:10:36 --> Loader Class Initialized
INFO - 2020-01-27 12:10:36 --> Helper loaded: url_helper
INFO - 2020-01-27 12:10:36 --> Helper loaded: file_helper
INFO - 2020-01-27 12:10:36 --> Helper loaded: form_helper
INFO - 2020-01-27 12:10:37 --> Helper loaded: my_helper
INFO - 2020-01-27 12:10:37 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:10:37 --> Controller Class Initialized
INFO - 2020-01-27 12:10:37 --> Final output sent to browser
DEBUG - 2020-01-27 12:10:37 --> Total execution time: 0.4966
INFO - 2020-01-27 12:10:44 --> Config Class Initialized
INFO - 2020-01-27 12:10:44 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:10:44 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:10:44 --> Utf8 Class Initialized
INFO - 2020-01-27 12:10:44 --> URI Class Initialized
INFO - 2020-01-27 12:10:44 --> Router Class Initialized
INFO - 2020-01-27 12:10:44 --> Output Class Initialized
INFO - 2020-01-27 12:10:44 --> Security Class Initialized
DEBUG - 2020-01-27 12:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:10:44 --> Input Class Initialized
INFO - 2020-01-27 12:10:44 --> Language Class Initialized
INFO - 2020-01-27 12:10:44 --> Language Class Initialized
INFO - 2020-01-27 12:10:44 --> Config Class Initialized
INFO - 2020-01-27 12:10:44 --> Loader Class Initialized
INFO - 2020-01-27 12:10:44 --> Helper loaded: url_helper
INFO - 2020-01-27 12:10:44 --> Helper loaded: file_helper
INFO - 2020-01-27 12:10:44 --> Helper loaded: form_helper
INFO - 2020-01-27 12:10:44 --> Helper loaded: my_helper
INFO - 2020-01-27 12:10:44 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:10:44 --> Controller Class Initialized
INFO - 2020-01-27 12:12:13 --> Config Class Initialized
INFO - 2020-01-27 12:12:13 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:12:13 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:12:13 --> Utf8 Class Initialized
INFO - 2020-01-27 12:12:13 --> URI Class Initialized
INFO - 2020-01-27 12:12:13 --> Router Class Initialized
INFO - 2020-01-27 12:12:13 --> Output Class Initialized
INFO - 2020-01-27 12:12:13 --> Security Class Initialized
DEBUG - 2020-01-27 12:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:12:13 --> Input Class Initialized
INFO - 2020-01-27 12:12:13 --> Language Class Initialized
INFO - 2020-01-27 12:12:13 --> Language Class Initialized
INFO - 2020-01-27 12:12:13 --> Config Class Initialized
INFO - 2020-01-27 12:12:13 --> Loader Class Initialized
INFO - 2020-01-27 12:12:14 --> Helper loaded: url_helper
INFO - 2020-01-27 12:12:14 --> Helper loaded: file_helper
INFO - 2020-01-27 12:12:14 --> Helper loaded: form_helper
INFO - 2020-01-27 12:12:14 --> Helper loaded: my_helper
INFO - 2020-01-27 12:12:14 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:12:14 --> Controller Class Initialized
DEBUG - 2020-01-27 12:12:14 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-01-27 12:12:14 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 12:12:14 --> Final output sent to browser
DEBUG - 2020-01-27 12:12:14 --> Total execution time: 0.6840
INFO - 2020-01-27 12:12:14 --> Config Class Initialized
INFO - 2020-01-27 12:12:14 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:12:14 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:12:14 --> Utf8 Class Initialized
INFO - 2020-01-27 12:12:14 --> URI Class Initialized
INFO - 2020-01-27 12:12:14 --> Router Class Initialized
INFO - 2020-01-27 12:12:14 --> Output Class Initialized
INFO - 2020-01-27 12:12:14 --> Security Class Initialized
DEBUG - 2020-01-27 12:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:12:14 --> Input Class Initialized
INFO - 2020-01-27 12:12:14 --> Language Class Initialized
ERROR - 2020-01-27 12:12:14 --> 404 Page Not Found: /index
INFO - 2020-01-27 12:12:16 --> Config Class Initialized
INFO - 2020-01-27 12:12:16 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:12:16 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:12:16 --> Utf8 Class Initialized
INFO - 2020-01-27 12:12:16 --> URI Class Initialized
INFO - 2020-01-27 12:12:16 --> Router Class Initialized
INFO - 2020-01-27 12:12:16 --> Output Class Initialized
INFO - 2020-01-27 12:12:16 --> Security Class Initialized
DEBUG - 2020-01-27 12:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:12:16 --> Input Class Initialized
INFO - 2020-01-27 12:12:16 --> Language Class Initialized
INFO - 2020-01-27 12:12:16 --> Language Class Initialized
INFO - 2020-01-27 12:12:16 --> Config Class Initialized
INFO - 2020-01-27 12:12:16 --> Loader Class Initialized
INFO - 2020-01-27 12:12:16 --> Helper loaded: url_helper
INFO - 2020-01-27 12:12:16 --> Helper loaded: file_helper
INFO - 2020-01-27 12:12:16 --> Helper loaded: form_helper
INFO - 2020-01-27 12:12:16 --> Helper loaded: my_helper
INFO - 2020-01-27 12:12:16 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:12:16 --> Controller Class Initialized
INFO - 2020-01-27 12:12:16 --> Final output sent to browser
DEBUG - 2020-01-27 12:12:16 --> Total execution time: 0.5031
INFO - 2020-01-27 12:12:29 --> Config Class Initialized
INFO - 2020-01-27 12:12:29 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:12:29 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:12:29 --> Utf8 Class Initialized
INFO - 2020-01-27 12:12:29 --> URI Class Initialized
INFO - 2020-01-27 12:12:29 --> Router Class Initialized
INFO - 2020-01-27 12:12:29 --> Output Class Initialized
INFO - 2020-01-27 12:12:29 --> Security Class Initialized
DEBUG - 2020-01-27 12:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:12:29 --> Input Class Initialized
INFO - 2020-01-27 12:12:29 --> Language Class Initialized
INFO - 2020-01-27 12:12:29 --> Language Class Initialized
INFO - 2020-01-27 12:12:29 --> Config Class Initialized
INFO - 2020-01-27 12:12:29 --> Loader Class Initialized
INFO - 2020-01-27 12:12:29 --> Helper loaded: url_helper
INFO - 2020-01-27 12:12:29 --> Helper loaded: file_helper
INFO - 2020-01-27 12:12:29 --> Helper loaded: form_helper
INFO - 2020-01-27 12:12:29 --> Helper loaded: my_helper
INFO - 2020-01-27 12:12:29 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:12:29 --> Controller Class Initialized
INFO - 2020-01-27 12:12:29 --> Final output sent to browser
DEBUG - 2020-01-27 12:12:29 --> Total execution time: 0.6514
INFO - 2020-01-27 12:13:15 --> Config Class Initialized
INFO - 2020-01-27 12:13:15 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:13:15 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:13:15 --> Utf8 Class Initialized
INFO - 2020-01-27 12:13:15 --> URI Class Initialized
INFO - 2020-01-27 12:13:15 --> Router Class Initialized
INFO - 2020-01-27 12:13:15 --> Output Class Initialized
INFO - 2020-01-27 12:13:15 --> Security Class Initialized
DEBUG - 2020-01-27 12:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:13:15 --> Input Class Initialized
INFO - 2020-01-27 12:13:15 --> Language Class Initialized
INFO - 2020-01-27 12:13:15 --> Language Class Initialized
INFO - 2020-01-27 12:13:15 --> Config Class Initialized
INFO - 2020-01-27 12:13:15 --> Loader Class Initialized
INFO - 2020-01-27 12:13:15 --> Helper loaded: url_helper
INFO - 2020-01-27 12:13:15 --> Helper loaded: file_helper
INFO - 2020-01-27 12:13:15 --> Helper loaded: form_helper
INFO - 2020-01-27 12:13:15 --> Helper loaded: my_helper
INFO - 2020-01-27 12:13:15 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:13:15 --> Controller Class Initialized
INFO - 2020-01-27 12:13:15 --> Final output sent to browser
DEBUG - 2020-01-27 12:13:15 --> Total execution time: 0.5074
INFO - 2020-01-27 12:13:19 --> Config Class Initialized
INFO - 2020-01-27 12:13:19 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:13:19 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:13:19 --> Utf8 Class Initialized
INFO - 2020-01-27 12:13:19 --> URI Class Initialized
INFO - 2020-01-27 12:13:19 --> Router Class Initialized
INFO - 2020-01-27 12:13:19 --> Output Class Initialized
INFO - 2020-01-27 12:13:19 --> Security Class Initialized
DEBUG - 2020-01-27 12:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:13:19 --> Input Class Initialized
INFO - 2020-01-27 12:13:19 --> Language Class Initialized
INFO - 2020-01-27 12:13:19 --> Language Class Initialized
INFO - 2020-01-27 12:13:19 --> Config Class Initialized
INFO - 2020-01-27 12:13:19 --> Loader Class Initialized
INFO - 2020-01-27 12:13:19 --> Helper loaded: url_helper
INFO - 2020-01-27 12:13:19 --> Helper loaded: file_helper
INFO - 2020-01-27 12:13:19 --> Helper loaded: form_helper
INFO - 2020-01-27 12:13:19 --> Helper loaded: my_helper
INFO - 2020-01-27 12:13:19 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:13:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:13:19 --> Controller Class Initialized
INFO - 2020-01-27 12:13:19 --> Final output sent to browser
DEBUG - 2020-01-27 12:13:19 --> Total execution time: 0.5223
INFO - 2020-01-27 12:13:22 --> Config Class Initialized
INFO - 2020-01-27 12:13:22 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:13:22 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:13:22 --> Utf8 Class Initialized
INFO - 2020-01-27 12:13:22 --> URI Class Initialized
INFO - 2020-01-27 12:13:22 --> Router Class Initialized
INFO - 2020-01-27 12:13:22 --> Output Class Initialized
INFO - 2020-01-27 12:13:22 --> Security Class Initialized
DEBUG - 2020-01-27 12:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:13:22 --> Input Class Initialized
INFO - 2020-01-27 12:13:22 --> Language Class Initialized
INFO - 2020-01-27 12:13:22 --> Language Class Initialized
INFO - 2020-01-27 12:13:22 --> Config Class Initialized
INFO - 2020-01-27 12:13:22 --> Loader Class Initialized
INFO - 2020-01-27 12:13:22 --> Helper loaded: url_helper
INFO - 2020-01-27 12:13:22 --> Helper loaded: file_helper
INFO - 2020-01-27 12:13:22 --> Helper loaded: form_helper
INFO - 2020-01-27 12:13:22 --> Helper loaded: my_helper
INFO - 2020-01-27 12:13:22 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:13:22 --> Controller Class Initialized
INFO - 2020-01-27 12:13:22 --> Final output sent to browser
DEBUG - 2020-01-27 12:13:22 --> Total execution time: 0.5086
INFO - 2020-01-27 12:13:28 --> Config Class Initialized
INFO - 2020-01-27 12:13:28 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:13:29 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:13:29 --> Utf8 Class Initialized
INFO - 2020-01-27 12:13:29 --> URI Class Initialized
INFO - 2020-01-27 12:13:29 --> Router Class Initialized
INFO - 2020-01-27 12:13:29 --> Output Class Initialized
INFO - 2020-01-27 12:13:29 --> Security Class Initialized
DEBUG - 2020-01-27 12:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:13:29 --> Input Class Initialized
INFO - 2020-01-27 12:13:29 --> Language Class Initialized
INFO - 2020-01-27 12:13:29 --> Language Class Initialized
INFO - 2020-01-27 12:13:29 --> Config Class Initialized
INFO - 2020-01-27 12:13:29 --> Loader Class Initialized
INFO - 2020-01-27 12:13:29 --> Helper loaded: url_helper
INFO - 2020-01-27 12:13:29 --> Helper loaded: file_helper
INFO - 2020-01-27 12:13:29 --> Helper loaded: form_helper
INFO - 2020-01-27 12:13:29 --> Helper loaded: my_helper
INFO - 2020-01-27 12:13:29 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:13:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:13:29 --> Controller Class Initialized
INFO - 2020-01-27 12:13:29 --> Final output sent to browser
DEBUG - 2020-01-27 12:13:29 --> Total execution time: 0.5367
INFO - 2020-01-27 12:13:34 --> Config Class Initialized
INFO - 2020-01-27 12:13:34 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:13:34 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:13:34 --> Utf8 Class Initialized
INFO - 2020-01-27 12:13:34 --> URI Class Initialized
INFO - 2020-01-27 12:13:34 --> Router Class Initialized
INFO - 2020-01-27 12:13:34 --> Output Class Initialized
INFO - 2020-01-27 12:13:34 --> Security Class Initialized
DEBUG - 2020-01-27 12:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:13:34 --> Input Class Initialized
INFO - 2020-01-27 12:13:34 --> Language Class Initialized
INFO - 2020-01-27 12:13:34 --> Language Class Initialized
INFO - 2020-01-27 12:13:34 --> Config Class Initialized
INFO - 2020-01-27 12:13:34 --> Loader Class Initialized
INFO - 2020-01-27 12:13:34 --> Helper loaded: url_helper
INFO - 2020-01-27 12:13:34 --> Helper loaded: file_helper
INFO - 2020-01-27 12:13:34 --> Helper loaded: form_helper
INFO - 2020-01-27 12:13:34 --> Helper loaded: my_helper
INFO - 2020-01-27 12:13:34 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:13:34 --> Controller Class Initialized
INFO - 2020-01-27 12:13:34 --> Final output sent to browser
DEBUG - 2020-01-27 12:13:34 --> Total execution time: 0.5234
INFO - 2020-01-27 12:14:41 --> Config Class Initialized
INFO - 2020-01-27 12:14:41 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:14:41 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:14:41 --> Utf8 Class Initialized
INFO - 2020-01-27 12:14:41 --> URI Class Initialized
INFO - 2020-01-27 12:14:41 --> Router Class Initialized
INFO - 2020-01-27 12:14:42 --> Output Class Initialized
INFO - 2020-01-27 12:14:42 --> Security Class Initialized
DEBUG - 2020-01-27 12:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:14:42 --> Input Class Initialized
INFO - 2020-01-27 12:14:42 --> Language Class Initialized
INFO - 2020-01-27 12:14:42 --> Language Class Initialized
INFO - 2020-01-27 12:14:42 --> Config Class Initialized
INFO - 2020-01-27 12:14:42 --> Loader Class Initialized
INFO - 2020-01-27 12:14:42 --> Helper loaded: url_helper
INFO - 2020-01-27 12:14:42 --> Helper loaded: file_helper
INFO - 2020-01-27 12:14:42 --> Helper loaded: form_helper
INFO - 2020-01-27 12:14:42 --> Helper loaded: my_helper
INFO - 2020-01-27 12:14:42 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:14:42 --> Controller Class Initialized
DEBUG - 2020-01-27 12:14:42 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-01-27 12:14:42 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 12:14:42 --> Final output sent to browser
DEBUG - 2020-01-27 12:14:42 --> Total execution time: 0.7142
INFO - 2020-01-27 12:14:43 --> Config Class Initialized
INFO - 2020-01-27 12:14:44 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:14:44 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:14:44 --> Utf8 Class Initialized
INFO - 2020-01-27 12:14:44 --> URI Class Initialized
INFO - 2020-01-27 12:14:44 --> Router Class Initialized
INFO - 2020-01-27 12:14:44 --> Output Class Initialized
INFO - 2020-01-27 12:14:44 --> Security Class Initialized
DEBUG - 2020-01-27 12:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:14:44 --> Input Class Initialized
INFO - 2020-01-27 12:14:44 --> Language Class Initialized
INFO - 2020-01-27 12:14:44 --> Language Class Initialized
INFO - 2020-01-27 12:14:44 --> Config Class Initialized
INFO - 2020-01-27 12:14:44 --> Loader Class Initialized
INFO - 2020-01-27 12:14:44 --> Helper loaded: url_helper
INFO - 2020-01-27 12:14:44 --> Helper loaded: file_helper
INFO - 2020-01-27 12:14:44 --> Helper loaded: form_helper
INFO - 2020-01-27 12:14:44 --> Helper loaded: my_helper
INFO - 2020-01-27 12:14:44 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:14:44 --> Controller Class Initialized
INFO - 2020-01-27 12:14:44 --> Final output sent to browser
DEBUG - 2020-01-27 12:14:44 --> Total execution time: 0.5148
INFO - 2020-01-27 12:14:51 --> Config Class Initialized
INFO - 2020-01-27 12:14:51 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:14:51 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:14:51 --> Utf8 Class Initialized
INFO - 2020-01-27 12:14:51 --> URI Class Initialized
INFO - 2020-01-27 12:14:51 --> Router Class Initialized
INFO - 2020-01-27 12:14:51 --> Output Class Initialized
INFO - 2020-01-27 12:14:51 --> Security Class Initialized
DEBUG - 2020-01-27 12:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:14:51 --> Input Class Initialized
INFO - 2020-01-27 12:14:51 --> Language Class Initialized
INFO - 2020-01-27 12:14:51 --> Language Class Initialized
INFO - 2020-01-27 12:14:51 --> Config Class Initialized
INFO - 2020-01-27 12:14:51 --> Loader Class Initialized
INFO - 2020-01-27 12:14:51 --> Helper loaded: url_helper
INFO - 2020-01-27 12:14:51 --> Helper loaded: file_helper
INFO - 2020-01-27 12:14:51 --> Helper loaded: form_helper
INFO - 2020-01-27 12:14:51 --> Helper loaded: my_helper
INFO - 2020-01-27 12:14:51 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:14:51 --> Controller Class Initialized
INFO - 2020-01-27 12:14:51 --> Final output sent to browser
DEBUG - 2020-01-27 12:14:51 --> Total execution time: 0.5782
INFO - 2020-01-27 12:14:54 --> Config Class Initialized
INFO - 2020-01-27 12:14:54 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:14:54 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:14:54 --> Utf8 Class Initialized
INFO - 2020-01-27 12:14:54 --> URI Class Initialized
INFO - 2020-01-27 12:14:54 --> Router Class Initialized
INFO - 2020-01-27 12:14:54 --> Output Class Initialized
INFO - 2020-01-27 12:14:54 --> Security Class Initialized
DEBUG - 2020-01-27 12:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:14:54 --> Input Class Initialized
INFO - 2020-01-27 12:14:54 --> Language Class Initialized
INFO - 2020-01-27 12:14:54 --> Language Class Initialized
INFO - 2020-01-27 12:14:54 --> Config Class Initialized
INFO - 2020-01-27 12:14:54 --> Loader Class Initialized
INFO - 2020-01-27 12:14:54 --> Helper loaded: url_helper
INFO - 2020-01-27 12:14:54 --> Helper loaded: file_helper
INFO - 2020-01-27 12:14:54 --> Helper loaded: form_helper
INFO - 2020-01-27 12:14:54 --> Helper loaded: my_helper
INFO - 2020-01-27 12:14:54 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:14:54 --> Controller Class Initialized
INFO - 2020-01-27 12:14:54 --> Final output sent to browser
DEBUG - 2020-01-27 12:14:54 --> Total execution time: 0.5281
INFO - 2020-01-27 12:15:05 --> Config Class Initialized
INFO - 2020-01-27 12:15:05 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:15:05 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:15:05 --> Utf8 Class Initialized
INFO - 2020-01-27 12:15:05 --> URI Class Initialized
INFO - 2020-01-27 12:15:05 --> Router Class Initialized
INFO - 2020-01-27 12:15:06 --> Output Class Initialized
INFO - 2020-01-27 12:15:06 --> Security Class Initialized
DEBUG - 2020-01-27 12:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:15:06 --> Input Class Initialized
INFO - 2020-01-27 12:15:06 --> Language Class Initialized
INFO - 2020-01-27 12:15:06 --> Language Class Initialized
INFO - 2020-01-27 12:15:06 --> Config Class Initialized
INFO - 2020-01-27 12:15:06 --> Loader Class Initialized
INFO - 2020-01-27 12:15:06 --> Helper loaded: url_helper
INFO - 2020-01-27 12:15:06 --> Helper loaded: file_helper
INFO - 2020-01-27 12:15:06 --> Helper loaded: form_helper
INFO - 2020-01-27 12:15:06 --> Helper loaded: my_helper
INFO - 2020-01-27 12:15:06 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:15:06 --> Controller Class Initialized
INFO - 2020-01-27 12:15:06 --> Final output sent to browser
DEBUG - 2020-01-27 12:15:06 --> Total execution time: 0.5062
INFO - 2020-01-27 12:15:08 --> Config Class Initialized
INFO - 2020-01-27 12:15:08 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:15:08 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:15:08 --> Utf8 Class Initialized
INFO - 2020-01-27 12:15:08 --> URI Class Initialized
INFO - 2020-01-27 12:15:08 --> Router Class Initialized
INFO - 2020-01-27 12:15:08 --> Output Class Initialized
INFO - 2020-01-27 12:15:09 --> Security Class Initialized
DEBUG - 2020-01-27 12:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:15:09 --> Input Class Initialized
INFO - 2020-01-27 12:15:09 --> Language Class Initialized
INFO - 2020-01-27 12:15:09 --> Language Class Initialized
INFO - 2020-01-27 12:15:09 --> Config Class Initialized
INFO - 2020-01-27 12:15:09 --> Loader Class Initialized
INFO - 2020-01-27 12:15:09 --> Helper loaded: url_helper
INFO - 2020-01-27 12:15:09 --> Helper loaded: file_helper
INFO - 2020-01-27 12:15:09 --> Helper loaded: form_helper
INFO - 2020-01-27 12:15:09 --> Helper loaded: my_helper
INFO - 2020-01-27 12:15:09 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:15:09 --> Controller Class Initialized
INFO - 2020-01-27 12:15:09 --> Final output sent to browser
DEBUG - 2020-01-27 12:15:09 --> Total execution time: 0.5095
INFO - 2020-01-27 12:15:21 --> Config Class Initialized
INFO - 2020-01-27 12:15:21 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:15:21 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:15:21 --> Utf8 Class Initialized
INFO - 2020-01-27 12:15:21 --> URI Class Initialized
INFO - 2020-01-27 12:15:21 --> Router Class Initialized
INFO - 2020-01-27 12:15:21 --> Output Class Initialized
INFO - 2020-01-27 12:15:21 --> Security Class Initialized
DEBUG - 2020-01-27 12:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:15:21 --> Input Class Initialized
INFO - 2020-01-27 12:15:21 --> Language Class Initialized
INFO - 2020-01-27 12:15:21 --> Language Class Initialized
INFO - 2020-01-27 12:15:21 --> Config Class Initialized
INFO - 2020-01-27 12:15:22 --> Loader Class Initialized
INFO - 2020-01-27 12:15:22 --> Helper loaded: url_helper
INFO - 2020-01-27 12:15:22 --> Helper loaded: file_helper
INFO - 2020-01-27 12:15:22 --> Helper loaded: form_helper
INFO - 2020-01-27 12:15:22 --> Helper loaded: my_helper
INFO - 2020-01-27 12:15:22 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:15:22 --> Controller Class Initialized
INFO - 2020-01-27 12:15:22 --> Final output sent to browser
DEBUG - 2020-01-27 12:15:22 --> Total execution time: 0.4971
INFO - 2020-01-27 12:15:26 --> Config Class Initialized
INFO - 2020-01-27 12:15:26 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:15:26 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:15:26 --> Utf8 Class Initialized
INFO - 2020-01-27 12:15:26 --> URI Class Initialized
INFO - 2020-01-27 12:15:26 --> Router Class Initialized
INFO - 2020-01-27 12:15:26 --> Output Class Initialized
INFO - 2020-01-27 12:15:26 --> Security Class Initialized
DEBUG - 2020-01-27 12:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:15:26 --> Input Class Initialized
INFO - 2020-01-27 12:15:26 --> Language Class Initialized
INFO - 2020-01-27 12:15:26 --> Language Class Initialized
INFO - 2020-01-27 12:15:26 --> Config Class Initialized
INFO - 2020-01-27 12:15:26 --> Loader Class Initialized
INFO - 2020-01-27 12:15:27 --> Helper loaded: url_helper
INFO - 2020-01-27 12:15:27 --> Helper loaded: file_helper
INFO - 2020-01-27 12:15:27 --> Helper loaded: form_helper
INFO - 2020-01-27 12:15:27 --> Helper loaded: my_helper
INFO - 2020-01-27 12:15:27 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:15:27 --> Controller Class Initialized
INFO - 2020-01-27 12:15:27 --> Final output sent to browser
DEBUG - 2020-01-27 12:15:27 --> Total execution time: 0.6060
INFO - 2020-01-27 12:15:29 --> Config Class Initialized
INFO - 2020-01-27 12:15:29 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:15:29 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:15:29 --> Utf8 Class Initialized
INFO - 2020-01-27 12:15:29 --> URI Class Initialized
INFO - 2020-01-27 12:15:29 --> Router Class Initialized
INFO - 2020-01-27 12:15:29 --> Output Class Initialized
INFO - 2020-01-27 12:15:29 --> Security Class Initialized
DEBUG - 2020-01-27 12:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:15:29 --> Input Class Initialized
INFO - 2020-01-27 12:15:29 --> Language Class Initialized
INFO - 2020-01-27 12:15:29 --> Language Class Initialized
INFO - 2020-01-27 12:15:29 --> Config Class Initialized
INFO - 2020-01-27 12:15:29 --> Loader Class Initialized
INFO - 2020-01-27 12:15:29 --> Helper loaded: url_helper
INFO - 2020-01-27 12:15:29 --> Helper loaded: file_helper
INFO - 2020-01-27 12:15:29 --> Helper loaded: form_helper
INFO - 2020-01-27 12:15:29 --> Helper loaded: my_helper
INFO - 2020-01-27 12:15:29 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:15:29 --> Controller Class Initialized
INFO - 2020-01-27 12:15:29 --> Final output sent to browser
DEBUG - 2020-01-27 12:15:29 --> Total execution time: 0.5095
INFO - 2020-01-27 12:15:31 --> Config Class Initialized
INFO - 2020-01-27 12:15:31 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:15:31 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:15:31 --> Utf8 Class Initialized
INFO - 2020-01-27 12:15:31 --> URI Class Initialized
INFO - 2020-01-27 12:15:31 --> Router Class Initialized
INFO - 2020-01-27 12:15:31 --> Output Class Initialized
INFO - 2020-01-27 12:15:31 --> Security Class Initialized
DEBUG - 2020-01-27 12:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:15:31 --> Input Class Initialized
INFO - 2020-01-27 12:15:31 --> Language Class Initialized
INFO - 2020-01-27 12:15:31 --> Language Class Initialized
INFO - 2020-01-27 12:15:31 --> Config Class Initialized
INFO - 2020-01-27 12:15:31 --> Loader Class Initialized
INFO - 2020-01-27 12:15:31 --> Helper loaded: url_helper
INFO - 2020-01-27 12:15:31 --> Helper loaded: file_helper
INFO - 2020-01-27 12:15:31 --> Helper loaded: form_helper
INFO - 2020-01-27 12:15:31 --> Helper loaded: my_helper
INFO - 2020-01-27 12:15:31 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:15:31 --> Controller Class Initialized
INFO - 2020-01-27 12:15:31 --> Final output sent to browser
DEBUG - 2020-01-27 12:15:31 --> Total execution time: 0.5056
INFO - 2020-01-27 12:15:39 --> Config Class Initialized
INFO - 2020-01-27 12:15:39 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:15:39 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:15:39 --> Utf8 Class Initialized
INFO - 2020-01-27 12:15:39 --> URI Class Initialized
INFO - 2020-01-27 12:15:39 --> Router Class Initialized
INFO - 2020-01-27 12:15:39 --> Output Class Initialized
INFO - 2020-01-27 12:15:39 --> Security Class Initialized
DEBUG - 2020-01-27 12:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:15:39 --> Input Class Initialized
INFO - 2020-01-27 12:15:39 --> Language Class Initialized
INFO - 2020-01-27 12:15:39 --> Language Class Initialized
INFO - 2020-01-27 12:15:40 --> Config Class Initialized
INFO - 2020-01-27 12:15:40 --> Loader Class Initialized
INFO - 2020-01-27 12:15:40 --> Helper loaded: url_helper
INFO - 2020-01-27 12:15:40 --> Helper loaded: file_helper
INFO - 2020-01-27 12:15:40 --> Helper loaded: form_helper
INFO - 2020-01-27 12:15:40 --> Helper loaded: my_helper
INFO - 2020-01-27 12:15:40 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:15:40 --> Controller Class Initialized
INFO - 2020-01-27 12:15:40 --> Final output sent to browser
DEBUG - 2020-01-27 12:15:40 --> Total execution time: 0.5310
INFO - 2020-01-27 12:15:42 --> Config Class Initialized
INFO - 2020-01-27 12:15:42 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:15:42 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:15:42 --> Utf8 Class Initialized
INFO - 2020-01-27 12:15:43 --> URI Class Initialized
INFO - 2020-01-27 12:15:43 --> Router Class Initialized
INFO - 2020-01-27 12:15:43 --> Output Class Initialized
INFO - 2020-01-27 12:15:43 --> Security Class Initialized
DEBUG - 2020-01-27 12:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:15:43 --> Input Class Initialized
INFO - 2020-01-27 12:15:43 --> Language Class Initialized
INFO - 2020-01-27 12:15:43 --> Language Class Initialized
INFO - 2020-01-27 12:15:43 --> Config Class Initialized
INFO - 2020-01-27 12:15:43 --> Loader Class Initialized
INFO - 2020-01-27 12:15:43 --> Helper loaded: url_helper
INFO - 2020-01-27 12:15:43 --> Helper loaded: file_helper
INFO - 2020-01-27 12:15:43 --> Helper loaded: form_helper
INFO - 2020-01-27 12:15:43 --> Helper loaded: my_helper
INFO - 2020-01-27 12:15:43 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:15:43 --> Controller Class Initialized
INFO - 2020-01-27 12:15:43 --> Final output sent to browser
DEBUG - 2020-01-27 12:15:43 --> Total execution time: 0.5323
INFO - 2020-01-27 12:15:44 --> Config Class Initialized
INFO - 2020-01-27 12:15:44 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:15:44 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:15:44 --> Utf8 Class Initialized
INFO - 2020-01-27 12:15:44 --> URI Class Initialized
INFO - 2020-01-27 12:15:44 --> Router Class Initialized
INFO - 2020-01-27 12:15:44 --> Output Class Initialized
INFO - 2020-01-27 12:15:44 --> Security Class Initialized
DEBUG - 2020-01-27 12:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:15:44 --> Input Class Initialized
INFO - 2020-01-27 12:15:44 --> Language Class Initialized
INFO - 2020-01-27 12:15:44 --> Language Class Initialized
INFO - 2020-01-27 12:15:44 --> Config Class Initialized
INFO - 2020-01-27 12:15:44 --> Loader Class Initialized
INFO - 2020-01-27 12:15:44 --> Helper loaded: url_helper
INFO - 2020-01-27 12:15:44 --> Helper loaded: file_helper
INFO - 2020-01-27 12:15:44 --> Helper loaded: form_helper
INFO - 2020-01-27 12:15:44 --> Helper loaded: my_helper
INFO - 2020-01-27 12:15:44 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:15:44 --> Controller Class Initialized
INFO - 2020-01-27 12:15:44 --> Final output sent to browser
DEBUG - 2020-01-27 12:15:44 --> Total execution time: 0.4950
INFO - 2020-01-27 12:15:54 --> Config Class Initialized
INFO - 2020-01-27 12:15:54 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:15:54 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:15:54 --> Utf8 Class Initialized
INFO - 2020-01-27 12:15:54 --> URI Class Initialized
INFO - 2020-01-27 12:15:54 --> Router Class Initialized
INFO - 2020-01-27 12:15:55 --> Output Class Initialized
INFO - 2020-01-27 12:15:55 --> Security Class Initialized
DEBUG - 2020-01-27 12:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:15:55 --> Input Class Initialized
INFO - 2020-01-27 12:15:55 --> Language Class Initialized
INFO - 2020-01-27 12:15:55 --> Language Class Initialized
INFO - 2020-01-27 12:15:55 --> Config Class Initialized
INFO - 2020-01-27 12:15:55 --> Loader Class Initialized
INFO - 2020-01-27 12:15:55 --> Helper loaded: url_helper
INFO - 2020-01-27 12:15:55 --> Helper loaded: file_helper
INFO - 2020-01-27 12:15:55 --> Helper loaded: form_helper
INFO - 2020-01-27 12:15:55 --> Helper loaded: my_helper
INFO - 2020-01-27 12:15:55 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:15:55 --> Controller Class Initialized
ERROR - 2020-01-27 12:15:55 --> Severity: Warning --> Division by zero E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 520
ERROR - 2020-01-27 12:15:55 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 521
ERROR - 2020-01-27 12:15:55 --> Severity: Warning --> Division by zero E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 520
ERROR - 2020-01-27 12:15:55 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 521
ERROR - 2020-01-27 12:15:55 --> Severity: Warning --> Division by zero E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 520
ERROR - 2020-01-27 12:15:55 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 521
ERROR - 2020-01-27 12:15:55 --> Severity: Warning --> Division by zero E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 520
ERROR - 2020-01-27 12:15:55 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 521
ERROR - 2020-01-27 12:15:55 --> Severity: Warning --> Division by zero E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 520
ERROR - 2020-01-27 12:15:55 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 521
ERROR - 2020-01-27 12:15:55 --> Severity: Warning --> Division by zero E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 520
ERROR - 2020-01-27 12:15:55 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 521
ERROR - 2020-01-27 12:15:55 --> Severity: Warning --> Division by zero E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 520
ERROR - 2020-01-27 12:15:55 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 521
ERROR - 2020-01-27 12:15:55 --> Severity: Warning --> Division by zero E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 520
ERROR - 2020-01-27 12:15:55 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 521
ERROR - 2020-01-27 12:15:55 --> Severity: Warning --> Division by zero E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 520
ERROR - 2020-01-27 12:15:56 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 521
ERROR - 2020-01-27 12:15:56 --> Severity: Warning --> Division by zero E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 520
ERROR - 2020-01-27 12:15:56 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 521
ERROR - 2020-01-27 12:15:56 --> Severity: Warning --> Division by zero E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 520
ERROR - 2020-01-27 12:15:56 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 521
DEBUG - 2020-01-27 12:15:56 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 12:15:56 --> Final output sent to browser
DEBUG - 2020-01-27 12:15:56 --> Total execution time: 1.3173
INFO - 2020-01-27 12:17:45 --> Config Class Initialized
INFO - 2020-01-27 12:17:45 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:17:45 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:17:45 --> Utf8 Class Initialized
INFO - 2020-01-27 12:17:45 --> URI Class Initialized
INFO - 2020-01-27 12:17:45 --> Router Class Initialized
INFO - 2020-01-27 12:17:45 --> Output Class Initialized
INFO - 2020-01-27 12:17:45 --> Security Class Initialized
DEBUG - 2020-01-27 12:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:17:45 --> Input Class Initialized
INFO - 2020-01-27 12:17:45 --> Language Class Initialized
INFO - 2020-01-27 12:17:45 --> Language Class Initialized
INFO - 2020-01-27 12:17:45 --> Config Class Initialized
INFO - 2020-01-27 12:17:45 --> Loader Class Initialized
INFO - 2020-01-27 12:17:45 --> Helper loaded: url_helper
INFO - 2020-01-27 12:17:45 --> Helper loaded: file_helper
INFO - 2020-01-27 12:17:45 --> Helper loaded: form_helper
INFO - 2020-01-27 12:17:45 --> Helper loaded: my_helper
INFO - 2020-01-27 12:17:45 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:17:46 --> Controller Class Initialized
ERROR - 2020-01-27 12:17:46 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 521
ERROR - 2020-01-27 12:17:46 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 521
ERROR - 2020-01-27 12:17:46 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 521
ERROR - 2020-01-27 12:17:46 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 521
ERROR - 2020-01-27 12:17:46 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 521
ERROR - 2020-01-27 12:17:46 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 521
ERROR - 2020-01-27 12:17:46 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 521
ERROR - 2020-01-27 12:17:46 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 521
ERROR - 2020-01-27 12:17:46 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 521
ERROR - 2020-01-27 12:17:46 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 521
ERROR - 2020-01-27 12:17:46 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 521
DEBUG - 2020-01-27 12:17:46 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 12:17:46 --> Final output sent to browser
DEBUG - 2020-01-27 12:17:46 --> Total execution time: 0.8425
INFO - 2020-01-27 12:18:08 --> Config Class Initialized
INFO - 2020-01-27 12:18:08 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:18:08 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:18:08 --> Utf8 Class Initialized
INFO - 2020-01-27 12:18:08 --> URI Class Initialized
INFO - 2020-01-27 12:18:08 --> Router Class Initialized
INFO - 2020-01-27 12:18:08 --> Output Class Initialized
INFO - 2020-01-27 12:18:08 --> Security Class Initialized
DEBUG - 2020-01-27 12:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:18:08 --> Input Class Initialized
INFO - 2020-01-27 12:18:08 --> Language Class Initialized
INFO - 2020-01-27 12:18:08 --> Language Class Initialized
INFO - 2020-01-27 12:18:08 --> Config Class Initialized
INFO - 2020-01-27 12:18:08 --> Loader Class Initialized
INFO - 2020-01-27 12:18:08 --> Helper loaded: url_helper
INFO - 2020-01-27 12:18:08 --> Helper loaded: file_helper
INFO - 2020-01-27 12:18:08 --> Helper loaded: form_helper
INFO - 2020-01-27 12:18:08 --> Helper loaded: my_helper
INFO - 2020-01-27 12:18:08 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:18:08 --> Controller Class Initialized
ERROR - 2020-01-27 12:18:08 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 521
ERROR - 2020-01-27 12:18:08 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 521
ERROR - 2020-01-27 12:18:08 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 521
ERROR - 2020-01-27 12:18:09 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 521
ERROR - 2020-01-27 12:18:09 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 521
ERROR - 2020-01-27 12:18:09 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 521
ERROR - 2020-01-27 12:18:09 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 521
ERROR - 2020-01-27 12:18:09 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 521
ERROR - 2020-01-27 12:18:09 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 521
ERROR - 2020-01-27 12:18:09 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 521
ERROR - 2020-01-27 12:18:09 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_keterampilan\controllers\N_keterampilan.php 521
DEBUG - 2020-01-27 12:18:09 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 12:18:09 --> Final output sent to browser
DEBUG - 2020-01-27 12:18:09 --> Total execution time: 0.9460
INFO - 2020-01-27 12:18:36 --> Config Class Initialized
INFO - 2020-01-27 12:18:36 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:18:36 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:18:36 --> Utf8 Class Initialized
INFO - 2020-01-27 12:18:36 --> URI Class Initialized
INFO - 2020-01-27 12:18:36 --> Router Class Initialized
INFO - 2020-01-27 12:18:36 --> Output Class Initialized
INFO - 2020-01-27 12:18:36 --> Security Class Initialized
DEBUG - 2020-01-27 12:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:18:36 --> Input Class Initialized
INFO - 2020-01-27 12:18:36 --> Language Class Initialized
INFO - 2020-01-27 12:18:36 --> Language Class Initialized
INFO - 2020-01-27 12:18:36 --> Config Class Initialized
INFO - 2020-01-27 12:18:36 --> Loader Class Initialized
INFO - 2020-01-27 12:18:36 --> Helper loaded: url_helper
INFO - 2020-01-27 12:18:36 --> Helper loaded: file_helper
INFO - 2020-01-27 12:18:36 --> Helper loaded: form_helper
INFO - 2020-01-27 12:18:36 --> Helper loaded: my_helper
INFO - 2020-01-27 12:18:36 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:18:37 --> Controller Class Initialized
INFO - 2020-01-27 12:18:37 --> Final output sent to browser
DEBUG - 2020-01-27 12:18:37 --> Total execution time: 0.5093
INFO - 2020-01-27 12:18:44 --> Config Class Initialized
INFO - 2020-01-27 12:18:44 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:18:44 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:18:44 --> Utf8 Class Initialized
INFO - 2020-01-27 12:18:44 --> URI Class Initialized
INFO - 2020-01-27 12:18:44 --> Router Class Initialized
INFO - 2020-01-27 12:18:44 --> Output Class Initialized
INFO - 2020-01-27 12:18:44 --> Security Class Initialized
DEBUG - 2020-01-27 12:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:18:44 --> Input Class Initialized
INFO - 2020-01-27 12:18:44 --> Language Class Initialized
INFO - 2020-01-27 12:18:44 --> Language Class Initialized
INFO - 2020-01-27 12:18:44 --> Config Class Initialized
INFO - 2020-01-27 12:18:44 --> Loader Class Initialized
INFO - 2020-01-27 12:18:44 --> Helper loaded: url_helper
INFO - 2020-01-27 12:18:44 --> Helper loaded: file_helper
INFO - 2020-01-27 12:18:44 --> Helper loaded: form_helper
INFO - 2020-01-27 12:18:44 --> Helper loaded: my_helper
INFO - 2020-01-27 12:18:44 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:18:44 --> Controller Class Initialized
DEBUG - 2020-01-27 12:18:44 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-27 12:18:44 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 12:18:44 --> Final output sent to browser
DEBUG - 2020-01-27 12:18:45 --> Total execution time: 0.5635
INFO - 2020-01-27 12:18:52 --> Config Class Initialized
INFO - 2020-01-27 12:18:52 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:18:52 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:18:53 --> Utf8 Class Initialized
INFO - 2020-01-27 12:18:53 --> URI Class Initialized
INFO - 2020-01-27 12:18:53 --> Router Class Initialized
INFO - 2020-01-27 12:18:53 --> Output Class Initialized
INFO - 2020-01-27 12:18:53 --> Security Class Initialized
DEBUG - 2020-01-27 12:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:18:53 --> Input Class Initialized
INFO - 2020-01-27 12:18:53 --> Language Class Initialized
INFO - 2020-01-27 12:18:53 --> Language Class Initialized
INFO - 2020-01-27 12:18:53 --> Config Class Initialized
INFO - 2020-01-27 12:18:53 --> Loader Class Initialized
INFO - 2020-01-27 12:18:53 --> Helper loaded: url_helper
INFO - 2020-01-27 12:18:53 --> Helper loaded: file_helper
INFO - 2020-01-27 12:18:53 --> Helper loaded: form_helper
INFO - 2020-01-27 12:18:53 --> Helper loaded: my_helper
INFO - 2020-01-27 12:18:53 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:18:53 --> Controller Class Initialized
INFO - 2020-01-27 12:18:53 --> Helper loaded: cookie_helper
INFO - 2020-01-27 12:18:53 --> Final output sent to browser
DEBUG - 2020-01-27 12:18:53 --> Total execution time: 0.5793
INFO - 2020-01-27 12:18:54 --> Config Class Initialized
INFO - 2020-01-27 12:18:54 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:18:54 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:18:54 --> Utf8 Class Initialized
INFO - 2020-01-27 12:18:54 --> URI Class Initialized
INFO - 2020-01-27 12:18:55 --> Router Class Initialized
INFO - 2020-01-27 12:18:55 --> Output Class Initialized
INFO - 2020-01-27 12:18:55 --> Security Class Initialized
DEBUG - 2020-01-27 12:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:18:55 --> Input Class Initialized
INFO - 2020-01-27 12:18:55 --> Language Class Initialized
INFO - 2020-01-27 12:18:55 --> Language Class Initialized
INFO - 2020-01-27 12:18:55 --> Config Class Initialized
INFO - 2020-01-27 12:18:55 --> Loader Class Initialized
INFO - 2020-01-27 12:18:55 --> Helper loaded: url_helper
INFO - 2020-01-27 12:18:55 --> Helper loaded: file_helper
INFO - 2020-01-27 12:18:55 --> Helper loaded: form_helper
INFO - 2020-01-27 12:18:55 --> Helper loaded: my_helper
INFO - 2020-01-27 12:18:55 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:18:55 --> Controller Class Initialized
DEBUG - 2020-01-27 12:18:55 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-27 12:18:55 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 12:18:55 --> Final output sent to browser
DEBUG - 2020-01-27 12:18:55 --> Total execution time: 0.6717
INFO - 2020-01-27 12:18:59 --> Config Class Initialized
INFO - 2020-01-27 12:18:59 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:18:59 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:18:59 --> Utf8 Class Initialized
INFO - 2020-01-27 12:18:59 --> URI Class Initialized
INFO - 2020-01-27 12:18:59 --> Router Class Initialized
INFO - 2020-01-27 12:18:59 --> Output Class Initialized
INFO - 2020-01-27 12:18:59 --> Security Class Initialized
DEBUG - 2020-01-27 12:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:18:59 --> Input Class Initialized
INFO - 2020-01-27 12:18:59 --> Language Class Initialized
INFO - 2020-01-27 12:18:59 --> Language Class Initialized
INFO - 2020-01-27 12:18:59 --> Config Class Initialized
INFO - 2020-01-27 12:18:59 --> Loader Class Initialized
INFO - 2020-01-27 12:18:59 --> Helper loaded: url_helper
INFO - 2020-01-27 12:18:59 --> Helper loaded: file_helper
INFO - 2020-01-27 12:18:59 --> Helper loaded: form_helper
INFO - 2020-01-27 12:18:59 --> Helper loaded: my_helper
INFO - 2020-01-27 12:18:59 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:18:59 --> Controller Class Initialized
INFO - 2020-01-27 12:18:59 --> Helper loaded: cookie_helper
INFO - 2020-01-27 12:18:59 --> Config Class Initialized
INFO - 2020-01-27 12:18:59 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:18:59 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:18:59 --> Utf8 Class Initialized
INFO - 2020-01-27 12:18:59 --> URI Class Initialized
INFO - 2020-01-27 12:18:59 --> Router Class Initialized
INFO - 2020-01-27 12:18:59 --> Output Class Initialized
INFO - 2020-01-27 12:18:59 --> Security Class Initialized
DEBUG - 2020-01-27 12:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:18:59 --> Input Class Initialized
INFO - 2020-01-27 12:18:59 --> Language Class Initialized
INFO - 2020-01-27 12:18:59 --> Language Class Initialized
INFO - 2020-01-27 12:18:59 --> Config Class Initialized
INFO - 2020-01-27 12:18:59 --> Loader Class Initialized
INFO - 2020-01-27 12:19:00 --> Helper loaded: url_helper
INFO - 2020-01-27 12:19:00 --> Helper loaded: file_helper
INFO - 2020-01-27 12:19:00 --> Helper loaded: form_helper
INFO - 2020-01-27 12:19:00 --> Helper loaded: my_helper
INFO - 2020-01-27 12:19:00 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:19:00 --> Controller Class Initialized
INFO - 2020-01-27 12:19:00 --> Config Class Initialized
INFO - 2020-01-27 12:19:00 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:19:00 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:19:00 --> Utf8 Class Initialized
INFO - 2020-01-27 12:19:00 --> URI Class Initialized
INFO - 2020-01-27 12:19:00 --> Router Class Initialized
INFO - 2020-01-27 12:19:00 --> Output Class Initialized
INFO - 2020-01-27 12:19:00 --> Security Class Initialized
DEBUG - 2020-01-27 12:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:19:00 --> Input Class Initialized
INFO - 2020-01-27 12:19:00 --> Language Class Initialized
INFO - 2020-01-27 12:19:00 --> Language Class Initialized
INFO - 2020-01-27 12:19:00 --> Config Class Initialized
INFO - 2020-01-27 12:19:00 --> Loader Class Initialized
INFO - 2020-01-27 12:19:00 --> Helper loaded: url_helper
INFO - 2020-01-27 12:19:00 --> Helper loaded: file_helper
INFO - 2020-01-27 12:19:00 --> Helper loaded: form_helper
INFO - 2020-01-27 12:19:00 --> Helper loaded: my_helper
INFO - 2020-01-27 12:19:00 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:19:00 --> Controller Class Initialized
DEBUG - 2020-01-27 12:19:00 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-27 12:19:00 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 12:19:00 --> Final output sent to browser
DEBUG - 2020-01-27 12:19:00 --> Total execution time: 0.6762
INFO - 2020-01-27 12:19:06 --> Config Class Initialized
INFO - 2020-01-27 12:19:06 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:19:06 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:19:06 --> Utf8 Class Initialized
INFO - 2020-01-27 12:19:06 --> URI Class Initialized
INFO - 2020-01-27 12:19:06 --> Router Class Initialized
INFO - 2020-01-27 12:19:06 --> Output Class Initialized
INFO - 2020-01-27 12:19:06 --> Security Class Initialized
DEBUG - 2020-01-27 12:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:19:06 --> Input Class Initialized
INFO - 2020-01-27 12:19:06 --> Language Class Initialized
INFO - 2020-01-27 12:19:06 --> Language Class Initialized
INFO - 2020-01-27 12:19:06 --> Config Class Initialized
INFO - 2020-01-27 12:19:06 --> Loader Class Initialized
INFO - 2020-01-27 12:19:06 --> Helper loaded: url_helper
INFO - 2020-01-27 12:19:06 --> Helper loaded: file_helper
INFO - 2020-01-27 12:19:06 --> Helper loaded: form_helper
INFO - 2020-01-27 12:19:06 --> Helper loaded: my_helper
INFO - 2020-01-27 12:19:06 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:19:06 --> Controller Class Initialized
INFO - 2020-01-27 12:19:06 --> Helper loaded: cookie_helper
INFO - 2020-01-27 12:19:06 --> Final output sent to browser
DEBUG - 2020-01-27 12:19:06 --> Total execution time: 0.6170
INFO - 2020-01-27 12:19:08 --> Config Class Initialized
INFO - 2020-01-27 12:19:08 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:19:08 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:19:08 --> Utf8 Class Initialized
INFO - 2020-01-27 12:19:08 --> URI Class Initialized
INFO - 2020-01-27 12:19:08 --> Router Class Initialized
INFO - 2020-01-27 12:19:08 --> Output Class Initialized
INFO - 2020-01-27 12:19:08 --> Security Class Initialized
DEBUG - 2020-01-27 12:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:19:08 --> Input Class Initialized
INFO - 2020-01-27 12:19:08 --> Language Class Initialized
INFO - 2020-01-27 12:19:08 --> Language Class Initialized
INFO - 2020-01-27 12:19:08 --> Config Class Initialized
INFO - 2020-01-27 12:19:08 --> Loader Class Initialized
INFO - 2020-01-27 12:19:08 --> Helper loaded: url_helper
INFO - 2020-01-27 12:19:08 --> Helper loaded: file_helper
INFO - 2020-01-27 12:19:08 --> Helper loaded: form_helper
INFO - 2020-01-27 12:19:09 --> Helper loaded: my_helper
INFO - 2020-01-27 12:19:09 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:19:09 --> Controller Class Initialized
DEBUG - 2020-01-27 12:19:09 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-27 12:19:09 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 12:19:09 --> Final output sent to browser
DEBUG - 2020-01-27 12:19:09 --> Total execution time: 0.7639
INFO - 2020-01-27 12:19:14 --> Config Class Initialized
INFO - 2020-01-27 12:19:14 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:19:14 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:19:14 --> Utf8 Class Initialized
INFO - 2020-01-27 12:19:14 --> URI Class Initialized
INFO - 2020-01-27 12:19:14 --> Router Class Initialized
INFO - 2020-01-27 12:19:14 --> Output Class Initialized
INFO - 2020-01-27 12:19:14 --> Security Class Initialized
DEBUG - 2020-01-27 12:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:19:14 --> Input Class Initialized
INFO - 2020-01-27 12:19:14 --> Language Class Initialized
INFO - 2020-01-27 12:19:14 --> Language Class Initialized
INFO - 2020-01-27 12:19:15 --> Config Class Initialized
INFO - 2020-01-27 12:19:15 --> Loader Class Initialized
INFO - 2020-01-27 12:19:15 --> Helper loaded: url_helper
INFO - 2020-01-27 12:19:15 --> Helper loaded: file_helper
INFO - 2020-01-27 12:19:15 --> Helper loaded: form_helper
INFO - 2020-01-27 12:19:15 --> Helper loaded: my_helper
INFO - 2020-01-27 12:19:15 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:19:15 --> Controller Class Initialized
DEBUG - 2020-01-27 12:19:15 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-01-27 12:19:15 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 12:19:15 --> Final output sent to browser
DEBUG - 2020-01-27 12:19:15 --> Total execution time: 0.6202
INFO - 2020-01-27 12:19:17 --> Config Class Initialized
INFO - 2020-01-27 12:19:17 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:19:17 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:19:17 --> Utf8 Class Initialized
INFO - 2020-01-27 12:19:17 --> URI Class Initialized
INFO - 2020-01-27 12:19:17 --> Router Class Initialized
INFO - 2020-01-27 12:19:17 --> Output Class Initialized
INFO - 2020-01-27 12:19:17 --> Security Class Initialized
DEBUG - 2020-01-27 12:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:19:17 --> Input Class Initialized
INFO - 2020-01-27 12:19:18 --> Language Class Initialized
INFO - 2020-01-27 12:19:18 --> Language Class Initialized
INFO - 2020-01-27 12:19:18 --> Config Class Initialized
INFO - 2020-01-27 12:19:18 --> Loader Class Initialized
INFO - 2020-01-27 12:19:18 --> Helper loaded: url_helper
INFO - 2020-01-27 12:19:18 --> Helper loaded: file_helper
INFO - 2020-01-27 12:19:18 --> Helper loaded: form_helper
INFO - 2020-01-27 12:19:18 --> Helper loaded: my_helper
INFO - 2020-01-27 12:19:18 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:19:18 --> Controller Class Initialized
DEBUG - 2020-01-27 12:19:18 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-01-27 12:19:18 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 12:19:18 --> Final output sent to browser
DEBUG - 2020-01-27 12:19:18 --> Total execution time: 0.5801
INFO - 2020-01-27 12:19:20 --> Config Class Initialized
INFO - 2020-01-27 12:19:20 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:19:20 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:19:20 --> Utf8 Class Initialized
INFO - 2020-01-27 12:19:20 --> URI Class Initialized
INFO - 2020-01-27 12:19:20 --> Router Class Initialized
INFO - 2020-01-27 12:19:20 --> Output Class Initialized
INFO - 2020-01-27 12:19:20 --> Security Class Initialized
DEBUG - 2020-01-27 12:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:19:20 --> Input Class Initialized
INFO - 2020-01-27 12:19:20 --> Language Class Initialized
INFO - 2020-01-27 12:19:20 --> Language Class Initialized
INFO - 2020-01-27 12:19:20 --> Config Class Initialized
INFO - 2020-01-27 12:19:20 --> Loader Class Initialized
INFO - 2020-01-27 12:19:20 --> Helper loaded: url_helper
INFO - 2020-01-27 12:19:20 --> Helper loaded: file_helper
INFO - 2020-01-27 12:19:20 --> Helper loaded: form_helper
INFO - 2020-01-27 12:19:20 --> Helper loaded: my_helper
INFO - 2020-01-27 12:19:20 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:19:20 --> Controller Class Initialized
INFO - 2020-01-27 12:19:20 --> Final output sent to browser
DEBUG - 2020-01-27 12:19:20 --> Total execution time: 0.5163
INFO - 2020-01-27 12:19:24 --> Config Class Initialized
INFO - 2020-01-27 12:19:24 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:19:24 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:19:24 --> Utf8 Class Initialized
INFO - 2020-01-27 12:19:24 --> URI Class Initialized
INFO - 2020-01-27 12:19:25 --> Router Class Initialized
INFO - 2020-01-27 12:19:25 --> Output Class Initialized
INFO - 2020-01-27 12:19:25 --> Security Class Initialized
DEBUG - 2020-01-27 12:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:19:25 --> Input Class Initialized
INFO - 2020-01-27 12:19:25 --> Language Class Initialized
INFO - 2020-01-27 12:19:25 --> Language Class Initialized
INFO - 2020-01-27 12:19:25 --> Config Class Initialized
INFO - 2020-01-27 12:19:25 --> Loader Class Initialized
INFO - 2020-01-27 12:19:25 --> Helper loaded: url_helper
INFO - 2020-01-27 12:19:25 --> Helper loaded: file_helper
INFO - 2020-01-27 12:19:25 --> Helper loaded: form_helper
INFO - 2020-01-27 12:19:25 --> Helper loaded: my_helper
INFO - 2020-01-27 12:19:25 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:19:25 --> Controller Class Initialized
INFO - 2020-01-27 12:19:25 --> Final output sent to browser
DEBUG - 2020-01-27 12:19:25 --> Total execution time: 0.4977
INFO - 2020-01-27 12:19:27 --> Config Class Initialized
INFO - 2020-01-27 12:19:28 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:19:28 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:19:28 --> Utf8 Class Initialized
INFO - 2020-01-27 12:19:28 --> URI Class Initialized
INFO - 2020-01-27 12:19:28 --> Router Class Initialized
INFO - 2020-01-27 12:19:28 --> Output Class Initialized
INFO - 2020-01-27 12:19:28 --> Security Class Initialized
DEBUG - 2020-01-27 12:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:19:28 --> Input Class Initialized
INFO - 2020-01-27 12:19:28 --> Language Class Initialized
INFO - 2020-01-27 12:19:28 --> Language Class Initialized
INFO - 2020-01-27 12:19:28 --> Config Class Initialized
INFO - 2020-01-27 12:19:28 --> Loader Class Initialized
INFO - 2020-01-27 12:19:28 --> Helper loaded: url_helper
INFO - 2020-01-27 12:19:28 --> Helper loaded: file_helper
INFO - 2020-01-27 12:19:28 --> Helper loaded: form_helper
INFO - 2020-01-27 12:19:28 --> Helper loaded: my_helper
INFO - 2020-01-27 12:19:28 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:19:28 --> Controller Class Initialized
INFO - 2020-01-27 12:19:28 --> Final output sent to browser
DEBUG - 2020-01-27 12:19:28 --> Total execution time: 0.5358
INFO - 2020-01-27 12:19:29 --> Config Class Initialized
INFO - 2020-01-27 12:19:29 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:19:29 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:19:29 --> Utf8 Class Initialized
INFO - 2020-01-27 12:19:29 --> URI Class Initialized
INFO - 2020-01-27 12:19:29 --> Router Class Initialized
INFO - 2020-01-27 12:19:29 --> Output Class Initialized
INFO - 2020-01-27 12:19:29 --> Security Class Initialized
DEBUG - 2020-01-27 12:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:19:29 --> Input Class Initialized
INFO - 2020-01-27 12:19:29 --> Language Class Initialized
INFO - 2020-01-27 12:19:29 --> Language Class Initialized
INFO - 2020-01-27 12:19:29 --> Config Class Initialized
INFO - 2020-01-27 12:19:29 --> Loader Class Initialized
INFO - 2020-01-27 12:19:29 --> Helper loaded: url_helper
INFO - 2020-01-27 12:19:29 --> Helper loaded: file_helper
INFO - 2020-01-27 12:19:29 --> Helper loaded: form_helper
INFO - 2020-01-27 12:19:29 --> Helper loaded: my_helper
INFO - 2020-01-27 12:19:29 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:19:29 --> Controller Class Initialized
DEBUG - 2020-01-27 12:19:29 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 12:19:29 --> Final output sent to browser
DEBUG - 2020-01-27 12:19:29 --> Total execution time: 0.6616
INFO - 2020-01-27 12:20:54 --> Config Class Initialized
INFO - 2020-01-27 12:20:54 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:20:54 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:20:54 --> Utf8 Class Initialized
INFO - 2020-01-27 12:20:54 --> URI Class Initialized
INFO - 2020-01-27 12:20:54 --> Router Class Initialized
INFO - 2020-01-27 12:20:54 --> Output Class Initialized
INFO - 2020-01-27 12:20:54 --> Security Class Initialized
DEBUG - 2020-01-27 12:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:20:54 --> Input Class Initialized
INFO - 2020-01-27 12:20:54 --> Language Class Initialized
INFO - 2020-01-27 12:20:54 --> Language Class Initialized
INFO - 2020-01-27 12:20:54 --> Config Class Initialized
INFO - 2020-01-27 12:20:54 --> Loader Class Initialized
INFO - 2020-01-27 12:20:54 --> Helper loaded: url_helper
INFO - 2020-01-27 12:20:54 --> Helper loaded: file_helper
INFO - 2020-01-27 12:20:54 --> Helper loaded: form_helper
INFO - 2020-01-27 12:20:54 --> Helper loaded: my_helper
INFO - 2020-01-27 12:20:54 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:20:54 --> Controller Class Initialized
INFO - 2020-01-27 12:20:54 --> Final output sent to browser
DEBUG - 2020-01-27 12:20:54 --> Total execution time: 0.5239
INFO - 2020-01-27 12:20:59 --> Config Class Initialized
INFO - 2020-01-27 12:20:59 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:20:59 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:20:59 --> Utf8 Class Initialized
INFO - 2020-01-27 12:20:59 --> URI Class Initialized
INFO - 2020-01-27 12:20:59 --> Router Class Initialized
INFO - 2020-01-27 12:20:59 --> Output Class Initialized
INFO - 2020-01-27 12:20:59 --> Security Class Initialized
DEBUG - 2020-01-27 12:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:20:59 --> Input Class Initialized
INFO - 2020-01-27 12:20:59 --> Language Class Initialized
INFO - 2020-01-27 12:20:59 --> Language Class Initialized
INFO - 2020-01-27 12:20:59 --> Config Class Initialized
INFO - 2020-01-27 12:20:59 --> Loader Class Initialized
INFO - 2020-01-27 12:20:59 --> Helper loaded: url_helper
INFO - 2020-01-27 12:20:59 --> Helper loaded: file_helper
INFO - 2020-01-27 12:20:59 --> Helper loaded: form_helper
INFO - 2020-01-27 12:20:59 --> Helper loaded: my_helper
INFO - 2020-01-27 12:20:59 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:20:59 --> Controller Class Initialized
INFO - 2020-01-27 12:20:59 --> Final output sent to browser
DEBUG - 2020-01-27 12:20:59 --> Total execution time: 0.5322
INFO - 2020-01-27 12:21:02 --> Config Class Initialized
INFO - 2020-01-27 12:21:02 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:21:02 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:21:02 --> Utf8 Class Initialized
INFO - 2020-01-27 12:21:02 --> URI Class Initialized
INFO - 2020-01-27 12:21:02 --> Router Class Initialized
INFO - 2020-01-27 12:21:02 --> Output Class Initialized
INFO - 2020-01-27 12:21:02 --> Security Class Initialized
DEBUG - 2020-01-27 12:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:21:02 --> Input Class Initialized
INFO - 2020-01-27 12:21:02 --> Language Class Initialized
INFO - 2020-01-27 12:21:02 --> Language Class Initialized
INFO - 2020-01-27 12:21:02 --> Config Class Initialized
INFO - 2020-01-27 12:21:02 --> Loader Class Initialized
INFO - 2020-01-27 12:21:02 --> Helper loaded: url_helper
INFO - 2020-01-27 12:21:02 --> Helper loaded: file_helper
INFO - 2020-01-27 12:21:02 --> Helper loaded: form_helper
INFO - 2020-01-27 12:21:02 --> Helper loaded: my_helper
INFO - 2020-01-27 12:21:02 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:21:02 --> Controller Class Initialized
DEBUG - 2020-01-27 12:21:02 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 12:21:02 --> Final output sent to browser
DEBUG - 2020-01-27 12:21:03 --> Total execution time: 0.6469
INFO - 2020-01-27 12:21:05 --> Config Class Initialized
INFO - 2020-01-27 12:21:05 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:21:05 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:21:05 --> Utf8 Class Initialized
INFO - 2020-01-27 12:21:05 --> URI Class Initialized
INFO - 2020-01-27 12:21:05 --> Router Class Initialized
INFO - 2020-01-27 12:21:05 --> Output Class Initialized
INFO - 2020-01-27 12:21:05 --> Security Class Initialized
DEBUG - 2020-01-27 12:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:21:05 --> Input Class Initialized
INFO - 2020-01-27 12:21:05 --> Language Class Initialized
INFO - 2020-01-27 12:21:05 --> Language Class Initialized
INFO - 2020-01-27 12:21:05 --> Config Class Initialized
INFO - 2020-01-27 12:21:05 --> Loader Class Initialized
INFO - 2020-01-27 12:21:05 --> Helper loaded: url_helper
INFO - 2020-01-27 12:21:05 --> Helper loaded: file_helper
INFO - 2020-01-27 12:21:05 --> Helper loaded: form_helper
INFO - 2020-01-27 12:21:05 --> Helper loaded: my_helper
INFO - 2020-01-27 12:21:05 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:21:05 --> Controller Class Initialized
DEBUG - 2020-01-27 12:21:05 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 12:21:05 --> Final output sent to browser
DEBUG - 2020-01-27 12:21:05 --> Total execution time: 0.5868
INFO - 2020-01-27 12:21:09 --> Config Class Initialized
INFO - 2020-01-27 12:21:10 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:21:10 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:21:10 --> Utf8 Class Initialized
INFO - 2020-01-27 12:21:10 --> URI Class Initialized
INFO - 2020-01-27 12:21:10 --> Router Class Initialized
INFO - 2020-01-27 12:21:10 --> Output Class Initialized
INFO - 2020-01-27 12:21:10 --> Security Class Initialized
DEBUG - 2020-01-27 12:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:21:10 --> Input Class Initialized
INFO - 2020-01-27 12:21:10 --> Language Class Initialized
INFO - 2020-01-27 12:21:10 --> Language Class Initialized
INFO - 2020-01-27 12:21:10 --> Config Class Initialized
INFO - 2020-01-27 12:21:10 --> Loader Class Initialized
INFO - 2020-01-27 12:21:10 --> Helper loaded: url_helper
INFO - 2020-01-27 12:21:10 --> Helper loaded: file_helper
INFO - 2020-01-27 12:21:10 --> Helper loaded: form_helper
INFO - 2020-01-27 12:21:10 --> Helper loaded: my_helper
INFO - 2020-01-27 12:21:10 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:21:10 --> Controller Class Initialized
INFO - 2020-01-27 12:21:10 --> Final output sent to browser
DEBUG - 2020-01-27 12:21:10 --> Total execution time: 0.5702
INFO - 2020-01-27 12:21:15 --> Config Class Initialized
INFO - 2020-01-27 12:21:15 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:21:15 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:21:15 --> Utf8 Class Initialized
INFO - 2020-01-27 12:21:15 --> URI Class Initialized
INFO - 2020-01-27 12:21:15 --> Router Class Initialized
INFO - 2020-01-27 12:21:15 --> Output Class Initialized
INFO - 2020-01-27 12:21:15 --> Security Class Initialized
DEBUG - 2020-01-27 12:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:21:15 --> Input Class Initialized
INFO - 2020-01-27 12:21:15 --> Language Class Initialized
INFO - 2020-01-27 12:21:15 --> Language Class Initialized
INFO - 2020-01-27 12:21:15 --> Config Class Initialized
INFO - 2020-01-27 12:21:15 --> Loader Class Initialized
INFO - 2020-01-27 12:21:15 --> Helper loaded: url_helper
INFO - 2020-01-27 12:21:15 --> Helper loaded: file_helper
INFO - 2020-01-27 12:21:15 --> Helper loaded: form_helper
INFO - 2020-01-27 12:21:15 --> Helper loaded: my_helper
INFO - 2020-01-27 12:21:15 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:21:15 --> Controller Class Initialized
INFO - 2020-01-27 12:21:15 --> Final output sent to browser
DEBUG - 2020-01-27 12:21:15 --> Total execution time: 0.5356
INFO - 2020-01-27 12:23:20 --> Config Class Initialized
INFO - 2020-01-27 12:23:20 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:23:20 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:23:20 --> Utf8 Class Initialized
INFO - 2020-01-27 12:23:20 --> URI Class Initialized
INFO - 2020-01-27 12:23:20 --> Router Class Initialized
INFO - 2020-01-27 12:23:20 --> Output Class Initialized
INFO - 2020-01-27 12:23:20 --> Security Class Initialized
DEBUG - 2020-01-27 12:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:23:20 --> Input Class Initialized
INFO - 2020-01-27 12:23:20 --> Language Class Initialized
INFO - 2020-01-27 12:23:20 --> Language Class Initialized
INFO - 2020-01-27 12:23:20 --> Config Class Initialized
INFO - 2020-01-27 12:23:21 --> Loader Class Initialized
INFO - 2020-01-27 12:23:21 --> Helper loaded: url_helper
INFO - 2020-01-27 12:23:21 --> Helper loaded: file_helper
INFO - 2020-01-27 12:23:21 --> Helper loaded: form_helper
INFO - 2020-01-27 12:23:21 --> Helper loaded: my_helper
INFO - 2020-01-27 12:23:21 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:23:21 --> Controller Class Initialized
DEBUG - 2020-01-27 12:23:21 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-01-27 12:23:21 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 12:23:21 --> Final output sent to browser
DEBUG - 2020-01-27 12:23:21 --> Total execution time: 0.6340
INFO - 2020-01-27 12:23:32 --> Config Class Initialized
INFO - 2020-01-27 12:23:32 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:23:32 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:23:32 --> Utf8 Class Initialized
INFO - 2020-01-27 12:23:32 --> URI Class Initialized
INFO - 2020-01-27 12:23:32 --> Router Class Initialized
INFO - 2020-01-27 12:23:32 --> Output Class Initialized
INFO - 2020-01-27 12:23:32 --> Security Class Initialized
DEBUG - 2020-01-27 12:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:23:32 --> Input Class Initialized
INFO - 2020-01-27 12:23:32 --> Language Class Initialized
INFO - 2020-01-27 12:23:32 --> Language Class Initialized
INFO - 2020-01-27 12:23:32 --> Config Class Initialized
INFO - 2020-01-27 12:23:32 --> Loader Class Initialized
INFO - 2020-01-27 12:23:32 --> Helper loaded: url_helper
INFO - 2020-01-27 12:23:32 --> Helper loaded: file_helper
INFO - 2020-01-27 12:23:32 --> Helper loaded: form_helper
INFO - 2020-01-27 12:23:32 --> Helper loaded: my_helper
INFO - 2020-01-27 12:23:32 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:23:32 --> Controller Class Initialized
INFO - 2020-01-27 12:23:32 --> Config Class Initialized
INFO - 2020-01-27 12:23:32 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:23:32 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:23:33 --> Utf8 Class Initialized
INFO - 2020-01-27 12:23:33 --> URI Class Initialized
INFO - 2020-01-27 12:23:33 --> Router Class Initialized
INFO - 2020-01-27 12:23:33 --> Output Class Initialized
INFO - 2020-01-27 12:23:33 --> Security Class Initialized
DEBUG - 2020-01-27 12:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:23:33 --> Input Class Initialized
INFO - 2020-01-27 12:23:33 --> Language Class Initialized
INFO - 2020-01-27 12:23:33 --> Language Class Initialized
INFO - 2020-01-27 12:23:33 --> Config Class Initialized
INFO - 2020-01-27 12:23:33 --> Loader Class Initialized
INFO - 2020-01-27 12:23:33 --> Helper loaded: url_helper
INFO - 2020-01-27 12:23:33 --> Helper loaded: file_helper
INFO - 2020-01-27 12:23:33 --> Helper loaded: form_helper
INFO - 2020-01-27 12:23:33 --> Helper loaded: my_helper
INFO - 2020-01-27 12:23:33 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:23:33 --> Controller Class Initialized
DEBUG - 2020-01-27 12:23:33 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-27 12:23:33 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 12:23:33 --> Final output sent to browser
DEBUG - 2020-01-27 12:23:33 --> Total execution time: 0.7231
INFO - 2020-01-27 12:23:39 --> Config Class Initialized
INFO - 2020-01-27 12:23:39 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:23:39 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:23:39 --> Utf8 Class Initialized
INFO - 2020-01-27 12:23:39 --> URI Class Initialized
INFO - 2020-01-27 12:23:39 --> Router Class Initialized
INFO - 2020-01-27 12:23:39 --> Output Class Initialized
INFO - 2020-01-27 12:23:39 --> Security Class Initialized
DEBUG - 2020-01-27 12:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:23:39 --> Input Class Initialized
INFO - 2020-01-27 12:23:39 --> Language Class Initialized
INFO - 2020-01-27 12:23:39 --> Language Class Initialized
INFO - 2020-01-27 12:23:39 --> Config Class Initialized
INFO - 2020-01-27 12:23:39 --> Loader Class Initialized
INFO - 2020-01-27 12:23:39 --> Helper loaded: url_helper
INFO - 2020-01-27 12:23:39 --> Helper loaded: file_helper
INFO - 2020-01-27 12:23:39 --> Helper loaded: form_helper
INFO - 2020-01-27 12:23:39 --> Helper loaded: my_helper
INFO - 2020-01-27 12:23:39 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:23:39 --> Controller Class Initialized
INFO - 2020-01-27 12:23:39 --> Helper loaded: cookie_helper
INFO - 2020-01-27 12:23:39 --> Final output sent to browser
DEBUG - 2020-01-27 12:23:39 --> Total execution time: 0.5853
INFO - 2020-01-27 12:23:41 --> Config Class Initialized
INFO - 2020-01-27 12:23:41 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:23:41 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:23:41 --> Utf8 Class Initialized
INFO - 2020-01-27 12:23:41 --> URI Class Initialized
INFO - 2020-01-27 12:23:41 --> Router Class Initialized
INFO - 2020-01-27 12:23:41 --> Output Class Initialized
INFO - 2020-01-27 12:23:41 --> Security Class Initialized
DEBUG - 2020-01-27 12:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:23:41 --> Input Class Initialized
INFO - 2020-01-27 12:23:41 --> Language Class Initialized
INFO - 2020-01-27 12:23:41 --> Language Class Initialized
INFO - 2020-01-27 12:23:41 --> Config Class Initialized
INFO - 2020-01-27 12:23:41 --> Loader Class Initialized
INFO - 2020-01-27 12:23:41 --> Helper loaded: url_helper
INFO - 2020-01-27 12:23:41 --> Helper loaded: file_helper
INFO - 2020-01-27 12:23:41 --> Helper loaded: form_helper
INFO - 2020-01-27 12:23:41 --> Helper loaded: my_helper
INFO - 2020-01-27 12:23:41 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:23:41 --> Controller Class Initialized
DEBUG - 2020-01-27 12:23:41 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-27 12:23:41 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 12:23:41 --> Final output sent to browser
DEBUG - 2020-01-27 12:23:41 --> Total execution time: 0.6795
INFO - 2020-01-27 12:23:46 --> Config Class Initialized
INFO - 2020-01-27 12:23:46 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:23:46 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:23:46 --> Utf8 Class Initialized
INFO - 2020-01-27 12:23:46 --> URI Class Initialized
INFO - 2020-01-27 12:23:46 --> Router Class Initialized
INFO - 2020-01-27 12:23:46 --> Output Class Initialized
INFO - 2020-01-27 12:23:46 --> Security Class Initialized
DEBUG - 2020-01-27 12:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:23:46 --> Input Class Initialized
INFO - 2020-01-27 12:23:46 --> Language Class Initialized
INFO - 2020-01-27 12:23:46 --> Language Class Initialized
INFO - 2020-01-27 12:23:46 --> Config Class Initialized
INFO - 2020-01-27 12:23:46 --> Loader Class Initialized
INFO - 2020-01-27 12:23:46 --> Helper loaded: url_helper
INFO - 2020-01-27 12:23:46 --> Helper loaded: file_helper
INFO - 2020-01-27 12:23:46 --> Helper loaded: form_helper
INFO - 2020-01-27 12:23:46 --> Helper loaded: my_helper
INFO - 2020-01-27 12:23:46 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:23:46 --> Controller Class Initialized
DEBUG - 2020-01-27 12:23:46 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_kelas/views/list.php
DEBUG - 2020-01-27 12:23:46 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 12:23:46 --> Final output sent to browser
DEBUG - 2020-01-27 12:23:46 --> Total execution time: 0.6105
INFO - 2020-01-27 12:23:46 --> Config Class Initialized
INFO - 2020-01-27 12:23:47 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:23:47 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:23:47 --> Utf8 Class Initialized
INFO - 2020-01-27 12:23:47 --> URI Class Initialized
INFO - 2020-01-27 12:23:47 --> Router Class Initialized
INFO - 2020-01-27 12:23:47 --> Output Class Initialized
INFO - 2020-01-27 12:23:47 --> Security Class Initialized
DEBUG - 2020-01-27 12:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:23:47 --> Input Class Initialized
INFO - 2020-01-27 12:23:47 --> Language Class Initialized
INFO - 2020-01-27 12:23:47 --> Language Class Initialized
INFO - 2020-01-27 12:23:47 --> Config Class Initialized
INFO - 2020-01-27 12:23:47 --> Loader Class Initialized
INFO - 2020-01-27 12:23:47 --> Helper loaded: url_helper
INFO - 2020-01-27 12:23:47 --> Helper loaded: file_helper
INFO - 2020-01-27 12:23:47 --> Helper loaded: form_helper
INFO - 2020-01-27 12:23:47 --> Helper loaded: my_helper
INFO - 2020-01-27 12:23:47 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:23:47 --> Controller Class Initialized
INFO - 2020-01-27 12:23:48 --> Config Class Initialized
INFO - 2020-01-27 12:23:48 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:23:48 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:23:48 --> Utf8 Class Initialized
INFO - 2020-01-27 12:23:48 --> URI Class Initialized
INFO - 2020-01-27 12:23:48 --> Router Class Initialized
INFO - 2020-01-27 12:23:48 --> Output Class Initialized
INFO - 2020-01-27 12:23:48 --> Security Class Initialized
DEBUG - 2020-01-27 12:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:23:48 --> Input Class Initialized
INFO - 2020-01-27 12:23:48 --> Language Class Initialized
INFO - 2020-01-27 12:23:48 --> Language Class Initialized
INFO - 2020-01-27 12:23:48 --> Config Class Initialized
INFO - 2020-01-27 12:23:48 --> Loader Class Initialized
INFO - 2020-01-27 12:23:48 --> Helper loaded: url_helper
INFO - 2020-01-27 12:23:48 --> Helper loaded: file_helper
INFO - 2020-01-27 12:23:48 --> Helper loaded: form_helper
INFO - 2020-01-27 12:23:48 --> Helper loaded: my_helper
INFO - 2020-01-27 12:23:48 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:23:48 --> Controller Class Initialized
DEBUG - 2020-01-27 12:23:48 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_siswa/views/list.php
DEBUG - 2020-01-27 12:23:48 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 12:23:48 --> Final output sent to browser
DEBUG - 2020-01-27 12:23:48 --> Total execution time: 0.5873
INFO - 2020-01-27 12:23:49 --> Config Class Initialized
INFO - 2020-01-27 12:23:49 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:23:49 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:23:49 --> Utf8 Class Initialized
INFO - 2020-01-27 12:23:49 --> URI Class Initialized
INFO - 2020-01-27 12:23:49 --> Router Class Initialized
INFO - 2020-01-27 12:23:49 --> Output Class Initialized
INFO - 2020-01-27 12:23:49 --> Security Class Initialized
DEBUG - 2020-01-27 12:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:23:49 --> Input Class Initialized
INFO - 2020-01-27 12:23:49 --> Language Class Initialized
INFO - 2020-01-27 12:23:49 --> Language Class Initialized
INFO - 2020-01-27 12:23:49 --> Config Class Initialized
INFO - 2020-01-27 12:23:49 --> Loader Class Initialized
INFO - 2020-01-27 12:23:49 --> Helper loaded: url_helper
INFO - 2020-01-27 12:23:49 --> Helper loaded: file_helper
INFO - 2020-01-27 12:23:49 --> Helper loaded: form_helper
INFO - 2020-01-27 12:23:49 --> Helper loaded: my_helper
INFO - 2020-01-27 12:23:49 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:23:49 --> Controller Class Initialized
INFO - 2020-01-27 12:23:52 --> Config Class Initialized
INFO - 2020-01-27 12:23:52 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:23:52 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:23:52 --> Utf8 Class Initialized
INFO - 2020-01-27 12:23:52 --> URI Class Initialized
INFO - 2020-01-27 12:23:52 --> Router Class Initialized
INFO - 2020-01-27 12:23:52 --> Output Class Initialized
INFO - 2020-01-27 12:23:52 --> Security Class Initialized
DEBUG - 2020-01-27 12:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:23:52 --> Input Class Initialized
INFO - 2020-01-27 12:23:52 --> Language Class Initialized
INFO - 2020-01-27 12:23:52 --> Language Class Initialized
INFO - 2020-01-27 12:23:52 --> Config Class Initialized
INFO - 2020-01-27 12:23:52 --> Loader Class Initialized
INFO - 2020-01-27 12:23:52 --> Helper loaded: url_helper
INFO - 2020-01-27 12:23:53 --> Helper loaded: file_helper
INFO - 2020-01-27 12:23:53 --> Helper loaded: form_helper
INFO - 2020-01-27 12:23:53 --> Helper loaded: my_helper
INFO - 2020-01-27 12:23:53 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:23:53 --> Controller Class Initialized
INFO - 2020-01-27 12:23:55 --> Config Class Initialized
INFO - 2020-01-27 12:23:55 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:23:55 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:23:55 --> Utf8 Class Initialized
INFO - 2020-01-27 12:23:55 --> URI Class Initialized
INFO - 2020-01-27 12:23:55 --> Router Class Initialized
INFO - 2020-01-27 12:23:55 --> Output Class Initialized
INFO - 2020-01-27 12:23:55 --> Security Class Initialized
DEBUG - 2020-01-27 12:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:23:55 --> Input Class Initialized
INFO - 2020-01-27 12:23:55 --> Language Class Initialized
INFO - 2020-01-27 12:23:55 --> Language Class Initialized
INFO - 2020-01-27 12:23:55 --> Config Class Initialized
INFO - 2020-01-27 12:23:55 --> Loader Class Initialized
INFO - 2020-01-27 12:23:55 --> Helper loaded: url_helper
INFO - 2020-01-27 12:23:55 --> Helper loaded: file_helper
INFO - 2020-01-27 12:23:56 --> Helper loaded: form_helper
INFO - 2020-01-27 12:23:56 --> Helper loaded: my_helper
INFO - 2020-01-27 12:23:56 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:23:56 --> Controller Class Initialized
INFO - 2020-01-27 12:23:58 --> Config Class Initialized
INFO - 2020-01-27 12:23:58 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:23:58 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:23:58 --> Utf8 Class Initialized
INFO - 2020-01-27 12:23:58 --> URI Class Initialized
INFO - 2020-01-27 12:23:58 --> Router Class Initialized
INFO - 2020-01-27 12:23:58 --> Output Class Initialized
INFO - 2020-01-27 12:23:58 --> Security Class Initialized
DEBUG - 2020-01-27 12:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:23:59 --> Input Class Initialized
INFO - 2020-01-27 12:23:59 --> Language Class Initialized
INFO - 2020-01-27 12:23:59 --> Language Class Initialized
INFO - 2020-01-27 12:23:59 --> Config Class Initialized
INFO - 2020-01-27 12:23:59 --> Loader Class Initialized
INFO - 2020-01-27 12:23:59 --> Helper loaded: url_helper
INFO - 2020-01-27 12:23:59 --> Helper loaded: file_helper
INFO - 2020-01-27 12:23:59 --> Helper loaded: form_helper
INFO - 2020-01-27 12:23:59 --> Helper loaded: my_helper
INFO - 2020-01-27 12:23:59 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:23:59 --> Controller Class Initialized
DEBUG - 2020-01-27 12:23:59 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/list.php
DEBUG - 2020-01-27 12:23:59 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 12:23:59 --> Final output sent to browser
DEBUG - 2020-01-27 12:23:59 --> Total execution time: 0.6324
INFO - 2020-01-27 12:24:20 --> Config Class Initialized
INFO - 2020-01-27 12:24:20 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:24:20 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:24:20 --> Utf8 Class Initialized
INFO - 2020-01-27 12:24:20 --> URI Class Initialized
INFO - 2020-01-27 12:24:20 --> Router Class Initialized
INFO - 2020-01-27 12:24:20 --> Output Class Initialized
INFO - 2020-01-27 12:24:20 --> Security Class Initialized
DEBUG - 2020-01-27 12:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:24:20 --> Input Class Initialized
INFO - 2020-01-27 12:24:20 --> Language Class Initialized
INFO - 2020-01-27 12:24:20 --> Language Class Initialized
INFO - 2020-01-27 12:24:20 --> Config Class Initialized
INFO - 2020-01-27 12:24:20 --> Loader Class Initialized
INFO - 2020-01-27 12:24:20 --> Helper loaded: url_helper
INFO - 2020-01-27 12:24:20 --> Helper loaded: file_helper
INFO - 2020-01-27 12:24:20 --> Helper loaded: form_helper
INFO - 2020-01-27 12:24:20 --> Helper loaded: my_helper
INFO - 2020-01-27 12:24:20 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:24:20 --> Controller Class Initialized
DEBUG - 2020-01-27 12:24:20 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-01-27 12:24:20 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 12:24:20 --> Final output sent to browser
DEBUG - 2020-01-27 12:24:21 --> Total execution time: 0.6282
INFO - 2020-01-27 12:24:21 --> Config Class Initialized
INFO - 2020-01-27 12:24:21 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:24:21 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:24:21 --> Utf8 Class Initialized
INFO - 2020-01-27 12:24:21 --> URI Class Initialized
INFO - 2020-01-27 12:24:21 --> Router Class Initialized
INFO - 2020-01-27 12:24:21 --> Output Class Initialized
INFO - 2020-01-27 12:24:21 --> Security Class Initialized
DEBUG - 2020-01-27 12:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:24:21 --> Input Class Initialized
INFO - 2020-01-27 12:24:21 --> Language Class Initialized
INFO - 2020-01-27 12:24:21 --> Language Class Initialized
INFO - 2020-01-27 12:24:21 --> Config Class Initialized
INFO - 2020-01-27 12:24:21 --> Loader Class Initialized
INFO - 2020-01-27 12:24:21 --> Helper loaded: url_helper
INFO - 2020-01-27 12:24:21 --> Helper loaded: file_helper
INFO - 2020-01-27 12:24:21 --> Helper loaded: form_helper
INFO - 2020-01-27 12:24:21 --> Helper loaded: my_helper
INFO - 2020-01-27 12:24:21 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:24:21 --> Controller Class Initialized
INFO - 2020-01-27 12:24:23 --> Config Class Initialized
INFO - 2020-01-27 12:24:23 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:24:23 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:24:23 --> Utf8 Class Initialized
INFO - 2020-01-27 12:24:23 --> URI Class Initialized
INFO - 2020-01-27 12:24:23 --> Router Class Initialized
INFO - 2020-01-27 12:24:23 --> Output Class Initialized
INFO - 2020-01-27 12:24:23 --> Security Class Initialized
DEBUG - 2020-01-27 12:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:24:23 --> Input Class Initialized
INFO - 2020-01-27 12:24:23 --> Language Class Initialized
INFO - 2020-01-27 12:24:23 --> Language Class Initialized
INFO - 2020-01-27 12:24:23 --> Config Class Initialized
INFO - 2020-01-27 12:24:23 --> Loader Class Initialized
INFO - 2020-01-27 12:24:23 --> Helper loaded: url_helper
INFO - 2020-01-27 12:24:23 --> Helper loaded: file_helper
INFO - 2020-01-27 12:24:23 --> Helper loaded: form_helper
INFO - 2020-01-27 12:24:23 --> Helper loaded: my_helper
INFO - 2020-01-27 12:24:23 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:24:23 --> Controller Class Initialized
INFO - 2020-01-27 12:24:23 --> Final output sent to browser
DEBUG - 2020-01-27 12:24:23 --> Total execution time: 0.5429
INFO - 2020-01-27 12:24:45 --> Config Class Initialized
INFO - 2020-01-27 12:24:45 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:24:45 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:24:45 --> Utf8 Class Initialized
INFO - 2020-01-27 12:24:45 --> URI Class Initialized
INFO - 2020-01-27 12:24:45 --> Router Class Initialized
INFO - 2020-01-27 12:24:46 --> Output Class Initialized
INFO - 2020-01-27 12:24:46 --> Security Class Initialized
DEBUG - 2020-01-27 12:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:24:46 --> Input Class Initialized
INFO - 2020-01-27 12:24:46 --> Language Class Initialized
INFO - 2020-01-27 12:24:46 --> Language Class Initialized
INFO - 2020-01-27 12:24:46 --> Config Class Initialized
INFO - 2020-01-27 12:24:46 --> Loader Class Initialized
INFO - 2020-01-27 12:24:46 --> Helper loaded: url_helper
INFO - 2020-01-27 12:24:46 --> Helper loaded: file_helper
INFO - 2020-01-27 12:24:46 --> Helper loaded: form_helper
INFO - 2020-01-27 12:24:46 --> Helper loaded: my_helper
INFO - 2020-01-27 12:24:46 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:24:46 --> Controller Class Initialized
DEBUG - 2020-01-27 12:24:46 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-01-27 12:24:46 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 12:24:46 --> Final output sent to browser
DEBUG - 2020-01-27 12:24:46 --> Total execution time: 0.6999
INFO - 2020-01-27 12:24:48 --> Config Class Initialized
INFO - 2020-01-27 12:24:48 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:24:48 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:24:48 --> Utf8 Class Initialized
INFO - 2020-01-27 12:24:48 --> URI Class Initialized
INFO - 2020-01-27 12:24:48 --> Router Class Initialized
INFO - 2020-01-27 12:24:48 --> Output Class Initialized
INFO - 2020-01-27 12:24:48 --> Security Class Initialized
DEBUG - 2020-01-27 12:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:24:48 --> Input Class Initialized
INFO - 2020-01-27 12:24:48 --> Language Class Initialized
INFO - 2020-01-27 12:24:48 --> Language Class Initialized
INFO - 2020-01-27 12:24:48 --> Config Class Initialized
INFO - 2020-01-27 12:24:48 --> Loader Class Initialized
INFO - 2020-01-27 12:24:48 --> Helper loaded: url_helper
INFO - 2020-01-27 12:24:48 --> Helper loaded: file_helper
INFO - 2020-01-27 12:24:48 --> Helper loaded: form_helper
INFO - 2020-01-27 12:24:48 --> Helper loaded: my_helper
INFO - 2020-01-27 12:24:48 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:24:48 --> Controller Class Initialized
DEBUG - 2020-01-27 12:24:48 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-01-27 12:24:48 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 12:24:48 --> Final output sent to browser
DEBUG - 2020-01-27 12:24:48 --> Total execution time: 0.6356
INFO - 2020-01-27 12:24:50 --> Config Class Initialized
INFO - 2020-01-27 12:24:50 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:24:50 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:24:50 --> Utf8 Class Initialized
INFO - 2020-01-27 12:24:50 --> URI Class Initialized
INFO - 2020-01-27 12:24:50 --> Router Class Initialized
INFO - 2020-01-27 12:24:50 --> Output Class Initialized
INFO - 2020-01-27 12:24:50 --> Security Class Initialized
DEBUG - 2020-01-27 12:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:24:50 --> Input Class Initialized
INFO - 2020-01-27 12:24:50 --> Language Class Initialized
INFO - 2020-01-27 12:24:50 --> Language Class Initialized
INFO - 2020-01-27 12:24:50 --> Config Class Initialized
INFO - 2020-01-27 12:24:50 --> Loader Class Initialized
INFO - 2020-01-27 12:24:50 --> Helper loaded: url_helper
INFO - 2020-01-27 12:24:50 --> Helper loaded: file_helper
INFO - 2020-01-27 12:24:50 --> Helper loaded: form_helper
INFO - 2020-01-27 12:24:50 --> Helper loaded: my_helper
INFO - 2020-01-27 12:24:50 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:24:50 --> Controller Class Initialized
INFO - 2020-01-27 12:24:50 --> Final output sent to browser
DEBUG - 2020-01-27 12:24:50 --> Total execution time: 0.5633
INFO - 2020-01-27 12:24:54 --> Config Class Initialized
INFO - 2020-01-27 12:24:55 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:24:55 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:24:55 --> Utf8 Class Initialized
INFO - 2020-01-27 12:24:55 --> URI Class Initialized
INFO - 2020-01-27 12:24:55 --> Router Class Initialized
INFO - 2020-01-27 12:24:55 --> Output Class Initialized
INFO - 2020-01-27 12:24:55 --> Security Class Initialized
DEBUG - 2020-01-27 12:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:24:55 --> Input Class Initialized
INFO - 2020-01-27 12:24:55 --> Language Class Initialized
INFO - 2020-01-27 12:24:55 --> Language Class Initialized
INFO - 2020-01-27 12:24:55 --> Config Class Initialized
INFO - 2020-01-27 12:24:55 --> Loader Class Initialized
INFO - 2020-01-27 12:24:55 --> Helper loaded: url_helper
INFO - 2020-01-27 12:24:55 --> Helper loaded: file_helper
INFO - 2020-01-27 12:24:55 --> Helper loaded: form_helper
INFO - 2020-01-27 12:24:55 --> Helper loaded: my_helper
INFO - 2020-01-27 12:24:55 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:24:55 --> Controller Class Initialized
INFO - 2020-01-27 12:24:55 --> Final output sent to browser
DEBUG - 2020-01-27 12:24:55 --> Total execution time: 0.6507
INFO - 2020-01-27 12:24:55 --> Config Class Initialized
INFO - 2020-01-27 12:24:55 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:24:55 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:24:55 --> Utf8 Class Initialized
INFO - 2020-01-27 12:24:55 --> URI Class Initialized
INFO - 2020-01-27 12:24:55 --> Router Class Initialized
INFO - 2020-01-27 12:24:55 --> Output Class Initialized
INFO - 2020-01-27 12:24:55 --> Security Class Initialized
DEBUG - 2020-01-27 12:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:24:55 --> Input Class Initialized
INFO - 2020-01-27 12:24:55 --> Language Class Initialized
INFO - 2020-01-27 12:24:56 --> Language Class Initialized
INFO - 2020-01-27 12:24:56 --> Config Class Initialized
INFO - 2020-01-27 12:24:56 --> Loader Class Initialized
INFO - 2020-01-27 12:24:56 --> Helper loaded: url_helper
INFO - 2020-01-27 12:24:56 --> Helper loaded: file_helper
INFO - 2020-01-27 12:24:56 --> Helper loaded: form_helper
INFO - 2020-01-27 12:24:56 --> Helper loaded: my_helper
INFO - 2020-01-27 12:24:56 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:24:56 --> Controller Class Initialized
DEBUG - 2020-01-27 12:24:56 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-01-27 12:24:56 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 12:24:56 --> Final output sent to browser
DEBUG - 2020-01-27 12:24:56 --> Total execution time: 0.6920
INFO - 2020-01-27 12:24:59 --> Config Class Initialized
INFO - 2020-01-27 12:24:59 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:24:59 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:24:59 --> Utf8 Class Initialized
INFO - 2020-01-27 12:24:59 --> URI Class Initialized
INFO - 2020-01-27 12:24:59 --> Router Class Initialized
INFO - 2020-01-27 12:24:59 --> Output Class Initialized
INFO - 2020-01-27 12:24:59 --> Security Class Initialized
DEBUG - 2020-01-27 12:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:24:59 --> Input Class Initialized
INFO - 2020-01-27 12:24:59 --> Language Class Initialized
INFO - 2020-01-27 12:24:59 --> Language Class Initialized
INFO - 2020-01-27 12:24:59 --> Config Class Initialized
INFO - 2020-01-27 12:24:59 --> Loader Class Initialized
INFO - 2020-01-27 12:24:59 --> Helper loaded: url_helper
INFO - 2020-01-27 12:24:59 --> Helper loaded: file_helper
INFO - 2020-01-27 12:24:59 --> Helper loaded: form_helper
INFO - 2020-01-27 12:24:59 --> Helper loaded: my_helper
INFO - 2020-01-27 12:24:59 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:24:59 --> Controller Class Initialized
INFO - 2020-01-27 12:24:59 --> Final output sent to browser
DEBUG - 2020-01-27 12:24:59 --> Total execution time: 0.6664
INFO - 2020-01-27 12:24:59 --> Config Class Initialized
INFO - 2020-01-27 12:24:59 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:24:59 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:24:59 --> Utf8 Class Initialized
INFO - 2020-01-27 12:24:59 --> URI Class Initialized
INFO - 2020-01-27 12:24:59 --> Router Class Initialized
INFO - 2020-01-27 12:24:59 --> Output Class Initialized
INFO - 2020-01-27 12:24:59 --> Security Class Initialized
DEBUG - 2020-01-27 12:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:25:00 --> Input Class Initialized
INFO - 2020-01-27 12:25:00 --> Language Class Initialized
INFO - 2020-01-27 12:25:00 --> Language Class Initialized
INFO - 2020-01-27 12:25:00 --> Config Class Initialized
INFO - 2020-01-27 12:25:00 --> Loader Class Initialized
INFO - 2020-01-27 12:25:00 --> Helper loaded: url_helper
INFO - 2020-01-27 12:25:00 --> Helper loaded: file_helper
INFO - 2020-01-27 12:25:00 --> Helper loaded: form_helper
INFO - 2020-01-27 12:25:00 --> Helper loaded: my_helper
INFO - 2020-01-27 12:25:00 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:25:00 --> Controller Class Initialized
DEBUG - 2020-01-27 12:25:00 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-01-27 12:25:00 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 12:25:00 --> Final output sent to browser
DEBUG - 2020-01-27 12:25:00 --> Total execution time: 0.9899
INFO - 2020-01-27 12:25:05 --> Config Class Initialized
INFO - 2020-01-27 12:25:05 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:25:05 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:25:05 --> Utf8 Class Initialized
INFO - 2020-01-27 12:25:05 --> URI Class Initialized
INFO - 2020-01-27 12:25:05 --> Router Class Initialized
INFO - 2020-01-27 12:25:05 --> Output Class Initialized
INFO - 2020-01-27 12:25:05 --> Security Class Initialized
DEBUG - 2020-01-27 12:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:25:05 --> Input Class Initialized
INFO - 2020-01-27 12:25:05 --> Language Class Initialized
INFO - 2020-01-27 12:25:05 --> Language Class Initialized
INFO - 2020-01-27 12:25:06 --> Config Class Initialized
INFO - 2020-01-27 12:25:06 --> Loader Class Initialized
INFO - 2020-01-27 12:25:06 --> Helper loaded: url_helper
INFO - 2020-01-27 12:25:06 --> Helper loaded: file_helper
INFO - 2020-01-27 12:25:06 --> Helper loaded: form_helper
INFO - 2020-01-27 12:25:06 --> Helper loaded: my_helper
INFO - 2020-01-27 12:25:06 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:25:06 --> Controller Class Initialized
INFO - 2020-01-27 12:25:06 --> Final output sent to browser
DEBUG - 2020-01-27 12:25:06 --> Total execution time: 0.5618
INFO - 2020-01-27 12:25:30 --> Config Class Initialized
INFO - 2020-01-27 12:25:30 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:25:30 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:25:30 --> Utf8 Class Initialized
INFO - 2020-01-27 12:25:30 --> URI Class Initialized
INFO - 2020-01-27 12:25:31 --> Router Class Initialized
INFO - 2020-01-27 12:25:31 --> Output Class Initialized
INFO - 2020-01-27 12:25:31 --> Security Class Initialized
DEBUG - 2020-01-27 12:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:25:31 --> Input Class Initialized
INFO - 2020-01-27 12:25:31 --> Language Class Initialized
INFO - 2020-01-27 12:25:31 --> Language Class Initialized
INFO - 2020-01-27 12:25:31 --> Config Class Initialized
INFO - 2020-01-27 12:25:31 --> Loader Class Initialized
INFO - 2020-01-27 12:25:31 --> Helper loaded: url_helper
INFO - 2020-01-27 12:25:31 --> Helper loaded: file_helper
INFO - 2020-01-27 12:25:31 --> Helper loaded: form_helper
INFO - 2020-01-27 12:25:31 --> Helper loaded: my_helper
INFO - 2020-01-27 12:25:31 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:25:31 --> Controller Class Initialized
INFO - 2020-01-27 12:25:31 --> Final output sent to browser
DEBUG - 2020-01-27 12:25:31 --> Total execution time: 0.6250
INFO - 2020-01-27 12:25:31 --> Config Class Initialized
INFO - 2020-01-27 12:25:31 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:25:31 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:25:31 --> Utf8 Class Initialized
INFO - 2020-01-27 12:25:31 --> URI Class Initialized
INFO - 2020-01-27 12:25:31 --> Router Class Initialized
INFO - 2020-01-27 12:25:31 --> Output Class Initialized
INFO - 2020-01-27 12:25:31 --> Security Class Initialized
DEBUG - 2020-01-27 12:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:25:31 --> Input Class Initialized
INFO - 2020-01-27 12:25:31 --> Language Class Initialized
INFO - 2020-01-27 12:25:31 --> Language Class Initialized
INFO - 2020-01-27 12:25:31 --> Config Class Initialized
INFO - 2020-01-27 12:25:31 --> Loader Class Initialized
INFO - 2020-01-27 12:25:31 --> Helper loaded: url_helper
INFO - 2020-01-27 12:25:31 --> Helper loaded: file_helper
INFO - 2020-01-27 12:25:32 --> Helper loaded: form_helper
INFO - 2020-01-27 12:25:32 --> Helper loaded: my_helper
INFO - 2020-01-27 12:25:32 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:25:32 --> Controller Class Initialized
DEBUG - 2020-01-27 12:25:32 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-01-27 12:25:32 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 12:25:32 --> Final output sent to browser
DEBUG - 2020-01-27 12:25:32 --> Total execution time: 0.6856
INFO - 2020-01-27 12:25:34 --> Config Class Initialized
INFO - 2020-01-27 12:25:34 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:25:34 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:25:34 --> Utf8 Class Initialized
INFO - 2020-01-27 12:25:34 --> URI Class Initialized
INFO - 2020-01-27 12:25:34 --> Router Class Initialized
INFO - 2020-01-27 12:25:34 --> Output Class Initialized
INFO - 2020-01-27 12:25:34 --> Security Class Initialized
DEBUG - 2020-01-27 12:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:25:34 --> Input Class Initialized
INFO - 2020-01-27 12:25:34 --> Language Class Initialized
INFO - 2020-01-27 12:25:34 --> Language Class Initialized
INFO - 2020-01-27 12:25:34 --> Config Class Initialized
INFO - 2020-01-27 12:25:34 --> Loader Class Initialized
INFO - 2020-01-27 12:25:34 --> Helper loaded: url_helper
INFO - 2020-01-27 12:25:34 --> Helper loaded: file_helper
INFO - 2020-01-27 12:25:34 --> Helper loaded: form_helper
INFO - 2020-01-27 12:25:34 --> Helper loaded: my_helper
INFO - 2020-01-27 12:25:34 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:25:34 --> Controller Class Initialized
INFO - 2020-01-27 12:25:34 --> Final output sent to browser
DEBUG - 2020-01-27 12:25:34 --> Total execution time: 0.5702
INFO - 2020-01-27 12:25:43 --> Config Class Initialized
INFO - 2020-01-27 12:25:43 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:25:43 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:25:43 --> Utf8 Class Initialized
INFO - 2020-01-27 12:25:43 --> URI Class Initialized
INFO - 2020-01-27 12:25:43 --> Router Class Initialized
INFO - 2020-01-27 12:25:43 --> Output Class Initialized
INFO - 2020-01-27 12:25:43 --> Security Class Initialized
DEBUG - 2020-01-27 12:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:25:43 --> Input Class Initialized
INFO - 2020-01-27 12:25:43 --> Language Class Initialized
INFO - 2020-01-27 12:25:44 --> Language Class Initialized
INFO - 2020-01-27 12:25:44 --> Config Class Initialized
INFO - 2020-01-27 12:25:44 --> Loader Class Initialized
INFO - 2020-01-27 12:25:44 --> Helper loaded: url_helper
INFO - 2020-01-27 12:25:44 --> Helper loaded: file_helper
INFO - 2020-01-27 12:25:44 --> Helper loaded: form_helper
INFO - 2020-01-27 12:25:44 --> Helper loaded: my_helper
INFO - 2020-01-27 12:25:44 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:25:44 --> Controller Class Initialized
INFO - 2020-01-27 12:25:44 --> Final output sent to browser
DEBUG - 2020-01-27 12:25:44 --> Total execution time: 0.5768
INFO - 2020-01-27 12:25:48 --> Config Class Initialized
INFO - 2020-01-27 12:25:48 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:25:48 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:25:48 --> Utf8 Class Initialized
INFO - 2020-01-27 12:25:48 --> URI Class Initialized
INFO - 2020-01-27 12:25:48 --> Router Class Initialized
INFO - 2020-01-27 12:25:48 --> Output Class Initialized
INFO - 2020-01-27 12:25:48 --> Security Class Initialized
DEBUG - 2020-01-27 12:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:25:48 --> Input Class Initialized
INFO - 2020-01-27 12:25:48 --> Language Class Initialized
INFO - 2020-01-27 12:25:48 --> Language Class Initialized
INFO - 2020-01-27 12:25:48 --> Config Class Initialized
INFO - 2020-01-27 12:25:48 --> Loader Class Initialized
INFO - 2020-01-27 12:25:48 --> Helper loaded: url_helper
INFO - 2020-01-27 12:25:48 --> Helper loaded: file_helper
INFO - 2020-01-27 12:25:48 --> Helper loaded: form_helper
INFO - 2020-01-27 12:25:48 --> Helper loaded: my_helper
INFO - 2020-01-27 12:25:48 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:25:48 --> Controller Class Initialized
INFO - 2020-01-27 12:25:48 --> Final output sent to browser
DEBUG - 2020-01-27 12:25:48 --> Total execution time: 0.5871
INFO - 2020-01-27 12:26:02 --> Config Class Initialized
INFO - 2020-01-27 12:26:02 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:26:02 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:26:02 --> Utf8 Class Initialized
INFO - 2020-01-27 12:26:02 --> URI Class Initialized
INFO - 2020-01-27 12:26:02 --> Router Class Initialized
INFO - 2020-01-27 12:26:02 --> Output Class Initialized
INFO - 2020-01-27 12:26:02 --> Security Class Initialized
DEBUG - 2020-01-27 12:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:26:02 --> Input Class Initialized
INFO - 2020-01-27 12:26:02 --> Language Class Initialized
INFO - 2020-01-27 12:26:03 --> Language Class Initialized
INFO - 2020-01-27 12:26:03 --> Config Class Initialized
INFO - 2020-01-27 12:26:03 --> Loader Class Initialized
INFO - 2020-01-27 12:26:03 --> Helper loaded: url_helper
INFO - 2020-01-27 12:26:03 --> Helper loaded: file_helper
INFO - 2020-01-27 12:26:03 --> Helper loaded: form_helper
INFO - 2020-01-27 12:26:03 --> Helper loaded: my_helper
INFO - 2020-01-27 12:26:03 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:26:03 --> Controller Class Initialized
INFO - 2020-01-27 12:26:03 --> Final output sent to browser
DEBUG - 2020-01-27 12:26:03 --> Total execution time: 0.5686
INFO - 2020-01-27 12:26:03 --> Config Class Initialized
INFO - 2020-01-27 12:26:03 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:26:03 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:26:03 --> Utf8 Class Initialized
INFO - 2020-01-27 12:26:03 --> URI Class Initialized
INFO - 2020-01-27 12:26:03 --> Router Class Initialized
INFO - 2020-01-27 12:26:03 --> Output Class Initialized
INFO - 2020-01-27 12:26:03 --> Security Class Initialized
DEBUG - 2020-01-27 12:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:26:03 --> Input Class Initialized
INFO - 2020-01-27 12:26:03 --> Language Class Initialized
INFO - 2020-01-27 12:26:03 --> Language Class Initialized
INFO - 2020-01-27 12:26:03 --> Config Class Initialized
INFO - 2020-01-27 12:26:03 --> Loader Class Initialized
INFO - 2020-01-27 12:26:03 --> Helper loaded: url_helper
INFO - 2020-01-27 12:26:03 --> Helper loaded: file_helper
INFO - 2020-01-27 12:26:03 --> Helper loaded: form_helper
INFO - 2020-01-27 12:26:03 --> Helper loaded: my_helper
INFO - 2020-01-27 12:26:03 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:26:04 --> Controller Class Initialized
DEBUG - 2020-01-27 12:26:04 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-01-27 12:26:04 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 12:26:04 --> Final output sent to browser
DEBUG - 2020-01-27 12:26:04 --> Total execution time: 0.7200
INFO - 2020-01-27 12:26:05 --> Config Class Initialized
INFO - 2020-01-27 12:26:05 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:26:05 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:26:05 --> Utf8 Class Initialized
INFO - 2020-01-27 12:26:05 --> URI Class Initialized
INFO - 2020-01-27 12:26:05 --> Router Class Initialized
INFO - 2020-01-27 12:26:05 --> Output Class Initialized
INFO - 2020-01-27 12:26:05 --> Security Class Initialized
DEBUG - 2020-01-27 12:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:26:05 --> Input Class Initialized
INFO - 2020-01-27 12:26:05 --> Language Class Initialized
INFO - 2020-01-27 12:26:05 --> Language Class Initialized
INFO - 2020-01-27 12:26:05 --> Config Class Initialized
INFO - 2020-01-27 12:26:05 --> Loader Class Initialized
INFO - 2020-01-27 12:26:05 --> Helper loaded: url_helper
INFO - 2020-01-27 12:26:05 --> Helper loaded: file_helper
INFO - 2020-01-27 12:26:06 --> Helper loaded: form_helper
INFO - 2020-01-27 12:26:06 --> Helper loaded: my_helper
INFO - 2020-01-27 12:26:06 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:26:06 --> Controller Class Initialized
INFO - 2020-01-27 12:26:06 --> Final output sent to browser
DEBUG - 2020-01-27 12:26:06 --> Total execution time: 0.5938
INFO - 2020-01-27 12:26:08 --> Config Class Initialized
INFO - 2020-01-27 12:26:08 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:26:08 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:26:08 --> Utf8 Class Initialized
INFO - 2020-01-27 12:26:08 --> URI Class Initialized
INFO - 2020-01-27 12:26:08 --> Router Class Initialized
INFO - 2020-01-27 12:26:08 --> Output Class Initialized
INFO - 2020-01-27 12:26:08 --> Security Class Initialized
DEBUG - 2020-01-27 12:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:26:08 --> Input Class Initialized
INFO - 2020-01-27 12:26:08 --> Language Class Initialized
INFO - 2020-01-27 12:26:08 --> Language Class Initialized
INFO - 2020-01-27 12:26:08 --> Config Class Initialized
INFO - 2020-01-27 12:26:08 --> Loader Class Initialized
INFO - 2020-01-27 12:26:08 --> Helper loaded: url_helper
INFO - 2020-01-27 12:26:08 --> Helper loaded: file_helper
INFO - 2020-01-27 12:26:08 --> Helper loaded: form_helper
INFO - 2020-01-27 12:26:08 --> Helper loaded: my_helper
INFO - 2020-01-27 12:26:08 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:26:08 --> Controller Class Initialized
INFO - 2020-01-27 12:26:08 --> Final output sent to browser
DEBUG - 2020-01-27 12:26:08 --> Total execution time: 0.6469
INFO - 2020-01-27 12:26:10 --> Config Class Initialized
INFO - 2020-01-27 12:26:10 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:26:10 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:26:10 --> Utf8 Class Initialized
INFO - 2020-01-27 12:26:10 --> URI Class Initialized
INFO - 2020-01-27 12:26:10 --> Router Class Initialized
INFO - 2020-01-27 12:26:10 --> Output Class Initialized
INFO - 2020-01-27 12:26:10 --> Security Class Initialized
DEBUG - 2020-01-27 12:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:26:10 --> Input Class Initialized
INFO - 2020-01-27 12:26:10 --> Language Class Initialized
INFO - 2020-01-27 12:26:10 --> Language Class Initialized
INFO - 2020-01-27 12:26:10 --> Config Class Initialized
INFO - 2020-01-27 12:26:10 --> Loader Class Initialized
INFO - 2020-01-27 12:26:10 --> Helper loaded: url_helper
INFO - 2020-01-27 12:26:10 --> Helper loaded: file_helper
INFO - 2020-01-27 12:26:10 --> Helper loaded: form_helper
INFO - 2020-01-27 12:26:10 --> Helper loaded: my_helper
INFO - 2020-01-27 12:26:10 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:26:10 --> Controller Class Initialized
INFO - 2020-01-27 12:26:10 --> Final output sent to browser
DEBUG - 2020-01-27 12:26:10 --> Total execution time: 0.5968
INFO - 2020-01-27 12:26:18 --> Config Class Initialized
INFO - 2020-01-27 12:26:18 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:26:18 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:26:18 --> Utf8 Class Initialized
INFO - 2020-01-27 12:26:18 --> URI Class Initialized
INFO - 2020-01-27 12:26:18 --> Router Class Initialized
INFO - 2020-01-27 12:26:18 --> Output Class Initialized
INFO - 2020-01-27 12:26:18 --> Security Class Initialized
DEBUG - 2020-01-27 12:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:26:18 --> Input Class Initialized
INFO - 2020-01-27 12:26:18 --> Language Class Initialized
INFO - 2020-01-27 12:26:18 --> Language Class Initialized
INFO - 2020-01-27 12:26:18 --> Config Class Initialized
INFO - 2020-01-27 12:26:18 --> Loader Class Initialized
INFO - 2020-01-27 12:26:18 --> Helper loaded: url_helper
INFO - 2020-01-27 12:26:18 --> Helper loaded: file_helper
INFO - 2020-01-27 12:26:18 --> Helper loaded: form_helper
INFO - 2020-01-27 12:26:18 --> Helper loaded: my_helper
INFO - 2020-01-27 12:26:18 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:26:18 --> Controller Class Initialized
INFO - 2020-01-27 12:26:18 --> Final output sent to browser
DEBUG - 2020-01-27 12:26:18 --> Total execution time: 0.5862
INFO - 2020-01-27 12:26:20 --> Config Class Initialized
INFO - 2020-01-27 12:26:20 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:26:20 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:26:20 --> Utf8 Class Initialized
INFO - 2020-01-27 12:26:20 --> URI Class Initialized
INFO - 2020-01-27 12:26:20 --> Router Class Initialized
INFO - 2020-01-27 12:26:20 --> Output Class Initialized
INFO - 2020-01-27 12:26:21 --> Security Class Initialized
DEBUG - 2020-01-27 12:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:26:21 --> Input Class Initialized
INFO - 2020-01-27 12:26:21 --> Language Class Initialized
INFO - 2020-01-27 12:26:21 --> Language Class Initialized
INFO - 2020-01-27 12:26:21 --> Config Class Initialized
INFO - 2020-01-27 12:26:21 --> Loader Class Initialized
INFO - 2020-01-27 12:26:21 --> Helper loaded: url_helper
INFO - 2020-01-27 12:26:21 --> Helper loaded: file_helper
INFO - 2020-01-27 12:26:21 --> Helper loaded: form_helper
INFO - 2020-01-27 12:26:21 --> Helper loaded: my_helper
INFO - 2020-01-27 12:26:21 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:26:21 --> Controller Class Initialized
INFO - 2020-01-27 12:26:21 --> Final output sent to browser
DEBUG - 2020-01-27 12:26:21 --> Total execution time: 0.5884
INFO - 2020-01-27 12:26:28 --> Config Class Initialized
INFO - 2020-01-27 12:26:28 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:26:28 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:26:28 --> Utf8 Class Initialized
INFO - 2020-01-27 12:26:28 --> URI Class Initialized
INFO - 2020-01-27 12:26:28 --> Router Class Initialized
INFO - 2020-01-27 12:26:28 --> Output Class Initialized
INFO - 2020-01-27 12:26:28 --> Security Class Initialized
DEBUG - 2020-01-27 12:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:26:28 --> Input Class Initialized
INFO - 2020-01-27 12:26:28 --> Language Class Initialized
INFO - 2020-01-27 12:26:28 --> Language Class Initialized
INFO - 2020-01-27 12:26:28 --> Config Class Initialized
INFO - 2020-01-27 12:26:28 --> Loader Class Initialized
INFO - 2020-01-27 12:26:28 --> Helper loaded: url_helper
INFO - 2020-01-27 12:26:28 --> Helper loaded: file_helper
INFO - 2020-01-27 12:26:28 --> Helper loaded: form_helper
INFO - 2020-01-27 12:26:28 --> Helper loaded: my_helper
INFO - 2020-01-27 12:26:28 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:26:28 --> Controller Class Initialized
INFO - 2020-01-27 12:26:28 --> Final output sent to browser
DEBUG - 2020-01-27 12:26:28 --> Total execution time: 0.5796
INFO - 2020-01-27 12:26:33 --> Config Class Initialized
INFO - 2020-01-27 12:26:33 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:26:33 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:26:33 --> Utf8 Class Initialized
INFO - 2020-01-27 12:26:34 --> URI Class Initialized
INFO - 2020-01-27 12:26:34 --> Router Class Initialized
INFO - 2020-01-27 12:26:34 --> Output Class Initialized
INFO - 2020-01-27 12:26:34 --> Security Class Initialized
DEBUG - 2020-01-27 12:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:26:34 --> Input Class Initialized
INFO - 2020-01-27 12:26:34 --> Language Class Initialized
INFO - 2020-01-27 12:26:34 --> Language Class Initialized
INFO - 2020-01-27 12:26:34 --> Config Class Initialized
INFO - 2020-01-27 12:26:34 --> Loader Class Initialized
INFO - 2020-01-27 12:26:34 --> Helper loaded: url_helper
INFO - 2020-01-27 12:26:34 --> Helper loaded: file_helper
INFO - 2020-01-27 12:26:34 --> Helper loaded: form_helper
INFO - 2020-01-27 12:26:34 --> Helper loaded: my_helper
INFO - 2020-01-27 12:26:34 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:26:34 --> Controller Class Initialized
INFO - 2020-01-27 12:26:34 --> Final output sent to browser
DEBUG - 2020-01-27 12:26:34 --> Total execution time: 0.5508
INFO - 2020-01-27 12:28:28 --> Config Class Initialized
INFO - 2020-01-27 12:28:28 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:28:28 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:28:28 --> Utf8 Class Initialized
INFO - 2020-01-27 12:28:28 --> URI Class Initialized
INFO - 2020-01-27 12:28:28 --> Router Class Initialized
INFO - 2020-01-27 12:28:29 --> Output Class Initialized
INFO - 2020-01-27 12:28:29 --> Security Class Initialized
DEBUG - 2020-01-27 12:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:28:29 --> Input Class Initialized
INFO - 2020-01-27 12:28:29 --> Language Class Initialized
INFO - 2020-01-27 12:28:29 --> Language Class Initialized
INFO - 2020-01-27 12:28:29 --> Config Class Initialized
INFO - 2020-01-27 12:28:29 --> Loader Class Initialized
INFO - 2020-01-27 12:28:29 --> Helper loaded: url_helper
INFO - 2020-01-27 12:28:29 --> Helper loaded: file_helper
INFO - 2020-01-27 12:28:29 --> Helper loaded: form_helper
INFO - 2020-01-27 12:28:29 --> Helper loaded: my_helper
INFO - 2020-01-27 12:28:29 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:28:29 --> Controller Class Initialized
DEBUG - 2020-01-27 12:28:29 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-27 12:28:29 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 12:28:29 --> Final output sent to browser
DEBUG - 2020-01-27 12:28:29 --> Total execution time: 0.6192
INFO - 2020-01-27 12:29:27 --> Config Class Initialized
INFO - 2020-01-27 12:29:27 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:29:27 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:29:27 --> Utf8 Class Initialized
INFO - 2020-01-27 12:29:27 --> URI Class Initialized
INFO - 2020-01-27 12:29:27 --> Router Class Initialized
INFO - 2020-01-27 12:29:27 --> Output Class Initialized
INFO - 2020-01-27 12:29:27 --> Security Class Initialized
DEBUG - 2020-01-27 12:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:29:27 --> Input Class Initialized
INFO - 2020-01-27 12:29:27 --> Language Class Initialized
ERROR - 2020-01-27 12:29:27 --> 404 Page Not Found: /index
INFO - 2020-01-27 12:29:30 --> Config Class Initialized
INFO - 2020-01-27 12:29:30 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:29:30 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:29:30 --> Utf8 Class Initialized
INFO - 2020-01-27 12:29:30 --> URI Class Initialized
INFO - 2020-01-27 12:29:30 --> Router Class Initialized
INFO - 2020-01-27 12:29:30 --> Output Class Initialized
INFO - 2020-01-27 12:29:30 --> Security Class Initialized
DEBUG - 2020-01-27 12:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:29:30 --> Input Class Initialized
INFO - 2020-01-27 12:29:30 --> Language Class Initialized
INFO - 2020-01-27 12:29:30 --> Language Class Initialized
INFO - 2020-01-27 12:29:30 --> Config Class Initialized
INFO - 2020-01-27 12:29:30 --> Loader Class Initialized
INFO - 2020-01-27 12:29:30 --> Helper loaded: url_helper
INFO - 2020-01-27 12:29:30 --> Helper loaded: file_helper
INFO - 2020-01-27 12:29:30 --> Helper loaded: form_helper
INFO - 2020-01-27 12:29:30 --> Helper loaded: my_helper
INFO - 2020-01-27 12:29:31 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:29:31 --> Controller Class Initialized
DEBUG - 2020-01-27 12:29:31 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-01-27 12:29:31 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 12:29:31 --> Final output sent to browser
DEBUG - 2020-01-27 12:29:31 --> Total execution time: 0.7317
INFO - 2020-01-27 12:29:31 --> Config Class Initialized
INFO - 2020-01-27 12:29:31 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:29:31 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:29:31 --> Utf8 Class Initialized
INFO - 2020-01-27 12:29:31 --> URI Class Initialized
INFO - 2020-01-27 12:29:31 --> Router Class Initialized
INFO - 2020-01-27 12:29:31 --> Output Class Initialized
INFO - 2020-01-27 12:29:31 --> Security Class Initialized
DEBUG - 2020-01-27 12:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:29:32 --> Input Class Initialized
INFO - 2020-01-27 12:29:32 --> Language Class Initialized
ERROR - 2020-01-27 12:29:32 --> 404 Page Not Found: /index
INFO - 2020-01-27 12:36:16 --> Config Class Initialized
INFO - 2020-01-27 12:36:16 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:36:16 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:36:16 --> Utf8 Class Initialized
INFO - 2020-01-27 12:36:17 --> URI Class Initialized
INFO - 2020-01-27 12:36:17 --> Router Class Initialized
INFO - 2020-01-27 12:36:17 --> Output Class Initialized
INFO - 2020-01-27 12:36:17 --> Security Class Initialized
DEBUG - 2020-01-27 12:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:36:17 --> Input Class Initialized
INFO - 2020-01-27 12:36:17 --> Language Class Initialized
INFO - 2020-01-27 12:36:17 --> Language Class Initialized
INFO - 2020-01-27 12:36:17 --> Config Class Initialized
INFO - 2020-01-27 12:36:17 --> Loader Class Initialized
INFO - 2020-01-27 12:36:17 --> Helper loaded: url_helper
INFO - 2020-01-27 12:36:17 --> Helper loaded: file_helper
INFO - 2020-01-27 12:36:17 --> Helper loaded: form_helper
INFO - 2020-01-27 12:36:17 --> Helper loaded: my_helper
INFO - 2020-01-27 12:36:17 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:36:17 --> Controller Class Initialized
DEBUG - 2020-01-27 12:36:17 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 12:36:17 --> Final output sent to browser
DEBUG - 2020-01-27 12:36:17 --> Total execution time: 0.6425
INFO - 2020-01-27 12:36:20 --> Config Class Initialized
INFO - 2020-01-27 12:36:20 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:36:21 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:36:21 --> Utf8 Class Initialized
INFO - 2020-01-27 12:36:21 --> URI Class Initialized
INFO - 2020-01-27 12:36:21 --> Router Class Initialized
INFO - 2020-01-27 12:36:21 --> Output Class Initialized
INFO - 2020-01-27 12:36:21 --> Security Class Initialized
DEBUG - 2020-01-27 12:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:36:21 --> Input Class Initialized
INFO - 2020-01-27 12:36:21 --> Language Class Initialized
INFO - 2020-01-27 12:36:21 --> Language Class Initialized
INFO - 2020-01-27 12:36:21 --> Config Class Initialized
INFO - 2020-01-27 12:36:21 --> Loader Class Initialized
INFO - 2020-01-27 12:36:21 --> Helper loaded: url_helper
INFO - 2020-01-27 12:36:21 --> Helper loaded: file_helper
INFO - 2020-01-27 12:36:21 --> Helper loaded: form_helper
INFO - 2020-01-27 12:36:21 --> Helper loaded: my_helper
INFO - 2020-01-27 12:36:21 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:36:21 --> Controller Class Initialized
DEBUG - 2020-01-27 12:36:21 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-01-27 12:36:21 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 12:36:21 --> Final output sent to browser
DEBUG - 2020-01-27 12:36:21 --> Total execution time: 0.7721
INFO - 2020-01-27 12:36:22 --> Config Class Initialized
INFO - 2020-01-27 12:36:22 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:36:22 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:36:22 --> Utf8 Class Initialized
INFO - 2020-01-27 12:36:22 --> URI Class Initialized
INFO - 2020-01-27 12:36:22 --> Router Class Initialized
INFO - 2020-01-27 12:36:22 --> Output Class Initialized
INFO - 2020-01-27 12:36:22 --> Security Class Initialized
DEBUG - 2020-01-27 12:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:36:22 --> Input Class Initialized
INFO - 2020-01-27 12:36:22 --> Language Class Initialized
INFO - 2020-01-27 12:36:22 --> Language Class Initialized
INFO - 2020-01-27 12:36:22 --> Config Class Initialized
INFO - 2020-01-27 12:36:22 --> Loader Class Initialized
INFO - 2020-01-27 12:36:22 --> Helper loaded: url_helper
INFO - 2020-01-27 12:36:22 --> Helper loaded: file_helper
INFO - 2020-01-27 12:36:22 --> Helper loaded: form_helper
INFO - 2020-01-27 12:36:22 --> Helper loaded: my_helper
INFO - 2020-01-27 12:36:22 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:36:23 --> Controller Class Initialized
INFO - 2020-01-27 12:36:23 --> Final output sent to browser
DEBUG - 2020-01-27 12:36:23 --> Total execution time: 0.5407
INFO - 2020-01-27 12:36:26 --> Config Class Initialized
INFO - 2020-01-27 12:36:26 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:36:26 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:36:26 --> Utf8 Class Initialized
INFO - 2020-01-27 12:36:26 --> URI Class Initialized
INFO - 2020-01-27 12:36:26 --> Router Class Initialized
INFO - 2020-01-27 12:36:26 --> Output Class Initialized
INFO - 2020-01-27 12:36:26 --> Security Class Initialized
DEBUG - 2020-01-27 12:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:36:26 --> Input Class Initialized
INFO - 2020-01-27 12:36:26 --> Language Class Initialized
INFO - 2020-01-27 12:36:26 --> Language Class Initialized
INFO - 2020-01-27 12:36:26 --> Config Class Initialized
INFO - 2020-01-27 12:36:26 --> Loader Class Initialized
INFO - 2020-01-27 12:36:26 --> Helper loaded: url_helper
INFO - 2020-01-27 12:36:26 --> Helper loaded: file_helper
INFO - 2020-01-27 12:36:26 --> Helper loaded: form_helper
INFO - 2020-01-27 12:36:26 --> Helper loaded: my_helper
INFO - 2020-01-27 12:36:26 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:36:26 --> Controller Class Initialized
INFO - 2020-01-27 12:36:26 --> Final output sent to browser
DEBUG - 2020-01-27 12:36:26 --> Total execution time: 0.5632
INFO - 2020-01-27 12:36:28 --> Config Class Initialized
INFO - 2020-01-27 12:36:28 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:36:28 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:36:28 --> Utf8 Class Initialized
INFO - 2020-01-27 12:36:28 --> URI Class Initialized
INFO - 2020-01-27 12:36:28 --> Router Class Initialized
INFO - 2020-01-27 12:36:28 --> Output Class Initialized
INFO - 2020-01-27 12:36:28 --> Security Class Initialized
DEBUG - 2020-01-27 12:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:36:28 --> Input Class Initialized
INFO - 2020-01-27 12:36:28 --> Language Class Initialized
INFO - 2020-01-27 12:36:28 --> Language Class Initialized
INFO - 2020-01-27 12:36:28 --> Config Class Initialized
INFO - 2020-01-27 12:36:28 --> Loader Class Initialized
INFO - 2020-01-27 12:36:28 --> Helper loaded: url_helper
INFO - 2020-01-27 12:36:28 --> Helper loaded: file_helper
INFO - 2020-01-27 12:36:28 --> Helper loaded: form_helper
INFO - 2020-01-27 12:36:28 --> Helper loaded: my_helper
INFO - 2020-01-27 12:36:28 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:36:28 --> Controller Class Initialized
INFO - 2020-01-27 12:36:28 --> Final output sent to browser
DEBUG - 2020-01-27 12:36:28 --> Total execution time: 0.5891
INFO - 2020-01-27 12:36:32 --> Config Class Initialized
INFO - 2020-01-27 12:36:32 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:36:32 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:36:32 --> Utf8 Class Initialized
INFO - 2020-01-27 12:36:32 --> URI Class Initialized
INFO - 2020-01-27 12:36:32 --> Router Class Initialized
INFO - 2020-01-27 12:36:32 --> Output Class Initialized
INFO - 2020-01-27 12:36:32 --> Security Class Initialized
DEBUG - 2020-01-27 12:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:36:32 --> Input Class Initialized
INFO - 2020-01-27 12:36:32 --> Language Class Initialized
INFO - 2020-01-27 12:36:32 --> Language Class Initialized
INFO - 2020-01-27 12:36:32 --> Config Class Initialized
INFO - 2020-01-27 12:36:32 --> Loader Class Initialized
INFO - 2020-01-27 12:36:32 --> Helper loaded: url_helper
INFO - 2020-01-27 12:36:32 --> Helper loaded: file_helper
INFO - 2020-01-27 12:36:32 --> Helper loaded: form_helper
INFO - 2020-01-27 12:36:32 --> Helper loaded: my_helper
INFO - 2020-01-27 12:36:32 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:36:32 --> Controller Class Initialized
INFO - 2020-01-27 12:36:32 --> Final output sent to browser
DEBUG - 2020-01-27 12:36:32 --> Total execution time: 0.5723
INFO - 2020-01-27 12:36:36 --> Config Class Initialized
INFO - 2020-01-27 12:36:36 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:36:36 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:36:36 --> Utf8 Class Initialized
INFO - 2020-01-27 12:36:36 --> URI Class Initialized
INFO - 2020-01-27 12:36:36 --> Router Class Initialized
INFO - 2020-01-27 12:36:36 --> Output Class Initialized
INFO - 2020-01-27 12:36:36 --> Security Class Initialized
DEBUG - 2020-01-27 12:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:36:36 --> Input Class Initialized
INFO - 2020-01-27 12:36:36 --> Language Class Initialized
INFO - 2020-01-27 12:36:36 --> Language Class Initialized
INFO - 2020-01-27 12:36:36 --> Config Class Initialized
INFO - 2020-01-27 12:36:36 --> Loader Class Initialized
INFO - 2020-01-27 12:36:36 --> Helper loaded: url_helper
INFO - 2020-01-27 12:36:36 --> Helper loaded: file_helper
INFO - 2020-01-27 12:36:36 --> Helper loaded: form_helper
INFO - 2020-01-27 12:36:36 --> Helper loaded: my_helper
INFO - 2020-01-27 12:36:36 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:36:36 --> Controller Class Initialized
INFO - 2020-01-27 12:36:36 --> Final output sent to browser
DEBUG - 2020-01-27 12:36:36 --> Total execution time: 0.6192
INFO - 2020-01-27 12:36:38 --> Config Class Initialized
INFO - 2020-01-27 12:36:38 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:36:38 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:36:38 --> Utf8 Class Initialized
INFO - 2020-01-27 12:36:38 --> URI Class Initialized
INFO - 2020-01-27 12:36:38 --> Router Class Initialized
INFO - 2020-01-27 12:36:38 --> Output Class Initialized
INFO - 2020-01-27 12:36:38 --> Security Class Initialized
DEBUG - 2020-01-27 12:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:36:38 --> Input Class Initialized
INFO - 2020-01-27 12:36:38 --> Language Class Initialized
INFO - 2020-01-27 12:36:38 --> Language Class Initialized
INFO - 2020-01-27 12:36:38 --> Config Class Initialized
INFO - 2020-01-27 12:36:39 --> Loader Class Initialized
INFO - 2020-01-27 12:36:39 --> Helper loaded: url_helper
INFO - 2020-01-27 12:36:39 --> Helper loaded: file_helper
INFO - 2020-01-27 12:36:39 --> Helper loaded: form_helper
INFO - 2020-01-27 12:36:39 --> Helper loaded: my_helper
INFO - 2020-01-27 12:36:39 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:36:39 --> Controller Class Initialized
INFO - 2020-01-27 12:36:39 --> Final output sent to browser
DEBUG - 2020-01-27 12:36:39 --> Total execution time: 0.5763
INFO - 2020-01-27 12:36:43 --> Config Class Initialized
INFO - 2020-01-27 12:36:43 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:36:43 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:36:43 --> Utf8 Class Initialized
INFO - 2020-01-27 12:36:43 --> URI Class Initialized
INFO - 2020-01-27 12:36:43 --> Router Class Initialized
INFO - 2020-01-27 12:36:43 --> Output Class Initialized
INFO - 2020-01-27 12:36:43 --> Security Class Initialized
DEBUG - 2020-01-27 12:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:36:43 --> Input Class Initialized
INFO - 2020-01-27 12:36:43 --> Language Class Initialized
INFO - 2020-01-27 12:36:44 --> Language Class Initialized
INFO - 2020-01-27 12:36:44 --> Config Class Initialized
INFO - 2020-01-27 12:36:44 --> Loader Class Initialized
INFO - 2020-01-27 12:36:44 --> Helper loaded: url_helper
INFO - 2020-01-27 12:36:44 --> Helper loaded: file_helper
INFO - 2020-01-27 12:36:44 --> Helper loaded: form_helper
INFO - 2020-01-27 12:36:44 --> Helper loaded: my_helper
INFO - 2020-01-27 12:36:44 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:36:44 --> Controller Class Initialized
INFO - 2020-01-27 12:36:44 --> Final output sent to browser
DEBUG - 2020-01-27 12:36:44 --> Total execution time: 0.5595
INFO - 2020-01-27 12:36:46 --> Config Class Initialized
INFO - 2020-01-27 12:36:46 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:36:46 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:36:46 --> Utf8 Class Initialized
INFO - 2020-01-27 12:36:46 --> URI Class Initialized
INFO - 2020-01-27 12:36:46 --> Router Class Initialized
INFO - 2020-01-27 12:36:46 --> Output Class Initialized
INFO - 2020-01-27 12:36:46 --> Security Class Initialized
DEBUG - 2020-01-27 12:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:36:46 --> Input Class Initialized
INFO - 2020-01-27 12:36:46 --> Language Class Initialized
INFO - 2020-01-27 12:36:46 --> Language Class Initialized
INFO - 2020-01-27 12:36:46 --> Config Class Initialized
INFO - 2020-01-27 12:36:46 --> Loader Class Initialized
INFO - 2020-01-27 12:36:46 --> Helper loaded: url_helper
INFO - 2020-01-27 12:36:46 --> Helper loaded: file_helper
INFO - 2020-01-27 12:36:46 --> Helper loaded: form_helper
INFO - 2020-01-27 12:36:46 --> Helper loaded: my_helper
INFO - 2020-01-27 12:36:46 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:36:46 --> Controller Class Initialized
INFO - 2020-01-27 12:36:46 --> Final output sent to browser
DEBUG - 2020-01-27 12:36:46 --> Total execution time: 0.5729
INFO - 2020-01-27 12:36:48 --> Config Class Initialized
INFO - 2020-01-27 12:36:48 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:36:48 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:36:48 --> Utf8 Class Initialized
INFO - 2020-01-27 12:36:48 --> URI Class Initialized
INFO - 2020-01-27 12:36:48 --> Router Class Initialized
INFO - 2020-01-27 12:36:48 --> Output Class Initialized
INFO - 2020-01-27 12:36:48 --> Security Class Initialized
DEBUG - 2020-01-27 12:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:36:48 --> Input Class Initialized
INFO - 2020-01-27 12:36:48 --> Language Class Initialized
INFO - 2020-01-27 12:36:48 --> Language Class Initialized
INFO - 2020-01-27 12:36:48 --> Config Class Initialized
INFO - 2020-01-27 12:36:48 --> Loader Class Initialized
INFO - 2020-01-27 12:36:48 --> Helper loaded: url_helper
INFO - 2020-01-27 12:36:48 --> Helper loaded: file_helper
INFO - 2020-01-27 12:36:48 --> Helper loaded: form_helper
INFO - 2020-01-27 12:36:48 --> Helper loaded: my_helper
INFO - 2020-01-27 12:36:48 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:36:48 --> Controller Class Initialized
INFO - 2020-01-27 12:36:48 --> Final output sent to browser
DEBUG - 2020-01-27 12:36:49 --> Total execution time: 0.5537
INFO - 2020-01-27 12:36:52 --> Config Class Initialized
INFO - 2020-01-27 12:36:52 --> Hooks Class Initialized
DEBUG - 2020-01-27 12:36:52 --> UTF-8 Support Enabled
INFO - 2020-01-27 12:36:52 --> Utf8 Class Initialized
INFO - 2020-01-27 12:36:52 --> URI Class Initialized
INFO - 2020-01-27 12:36:52 --> Router Class Initialized
INFO - 2020-01-27 12:36:52 --> Output Class Initialized
INFO - 2020-01-27 12:36:52 --> Security Class Initialized
DEBUG - 2020-01-27 12:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 12:36:52 --> Input Class Initialized
INFO - 2020-01-27 12:36:52 --> Language Class Initialized
INFO - 2020-01-27 12:36:52 --> Language Class Initialized
INFO - 2020-01-27 12:36:52 --> Config Class Initialized
INFO - 2020-01-27 12:36:52 --> Loader Class Initialized
INFO - 2020-01-27 12:36:53 --> Helper loaded: url_helper
INFO - 2020-01-27 12:36:53 --> Helper loaded: file_helper
INFO - 2020-01-27 12:36:53 --> Helper loaded: form_helper
INFO - 2020-01-27 12:36:53 --> Helper loaded: my_helper
INFO - 2020-01-27 12:36:53 --> Database Driver Class Initialized
DEBUG - 2020-01-27 12:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 12:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 12:36:53 --> Controller Class Initialized
DEBUG - 2020-01-27 12:36:53 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 12:36:53 --> Final output sent to browser
DEBUG - 2020-01-27 12:36:53 --> Total execution time: 0.6924
INFO - 2020-01-27 13:14:29 --> Config Class Initialized
INFO - 2020-01-27 13:14:29 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:14:29 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:14:29 --> Utf8 Class Initialized
INFO - 2020-01-27 13:14:29 --> URI Class Initialized
INFO - 2020-01-27 13:14:29 --> Router Class Initialized
INFO - 2020-01-27 13:14:29 --> Output Class Initialized
INFO - 2020-01-27 13:14:29 --> Security Class Initialized
DEBUG - 2020-01-27 13:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:14:29 --> Input Class Initialized
INFO - 2020-01-27 13:14:29 --> Language Class Initialized
INFO - 2020-01-27 13:14:29 --> Language Class Initialized
INFO - 2020-01-27 13:14:29 --> Config Class Initialized
INFO - 2020-01-27 13:14:29 --> Loader Class Initialized
INFO - 2020-01-27 13:14:29 --> Helper loaded: url_helper
INFO - 2020-01-27 13:14:29 --> Helper loaded: file_helper
INFO - 2020-01-27 13:14:29 --> Helper loaded: form_helper
INFO - 2020-01-27 13:14:29 --> Helper loaded: my_helper
INFO - 2020-01-27 13:14:29 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:14:29 --> Controller Class Initialized
DEBUG - 2020-01-27 13:14:29 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 13:14:30 --> Final output sent to browser
DEBUG - 2020-01-27 13:14:30 --> Total execution time: 0.6695
INFO - 2020-01-27 13:14:55 --> Config Class Initialized
INFO - 2020-01-27 13:14:55 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:14:55 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:14:55 --> Utf8 Class Initialized
INFO - 2020-01-27 13:14:55 --> URI Class Initialized
INFO - 2020-01-27 13:14:55 --> Router Class Initialized
INFO - 2020-01-27 13:14:55 --> Output Class Initialized
INFO - 2020-01-27 13:14:55 --> Security Class Initialized
DEBUG - 2020-01-27 13:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:14:55 --> Input Class Initialized
INFO - 2020-01-27 13:14:55 --> Language Class Initialized
INFO - 2020-01-27 13:14:55 --> Language Class Initialized
INFO - 2020-01-27 13:14:55 --> Config Class Initialized
INFO - 2020-01-27 13:14:55 --> Loader Class Initialized
INFO - 2020-01-27 13:14:55 --> Helper loaded: url_helper
INFO - 2020-01-27 13:14:55 --> Helper loaded: file_helper
INFO - 2020-01-27 13:14:55 --> Helper loaded: form_helper
INFO - 2020-01-27 13:14:55 --> Helper loaded: my_helper
INFO - 2020-01-27 13:14:55 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:14:55 --> Controller Class Initialized
INFO - 2020-01-27 13:14:55 --> Final output sent to browser
DEBUG - 2020-01-27 13:14:55 --> Total execution time: 0.6347
INFO - 2020-01-27 13:15:00 --> Config Class Initialized
INFO - 2020-01-27 13:15:00 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:15:00 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:15:00 --> Utf8 Class Initialized
INFO - 2020-01-27 13:15:00 --> URI Class Initialized
INFO - 2020-01-27 13:15:00 --> Router Class Initialized
INFO - 2020-01-27 13:15:00 --> Output Class Initialized
INFO - 2020-01-27 13:15:00 --> Security Class Initialized
DEBUG - 2020-01-27 13:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:15:00 --> Input Class Initialized
INFO - 2020-01-27 13:15:00 --> Language Class Initialized
INFO - 2020-01-27 13:15:00 --> Language Class Initialized
INFO - 2020-01-27 13:15:00 --> Config Class Initialized
INFO - 2020-01-27 13:15:00 --> Loader Class Initialized
INFO - 2020-01-27 13:15:00 --> Helper loaded: url_helper
INFO - 2020-01-27 13:15:00 --> Helper loaded: file_helper
INFO - 2020-01-27 13:15:00 --> Helper loaded: form_helper
INFO - 2020-01-27 13:15:00 --> Helper loaded: my_helper
INFO - 2020-01-27 13:15:00 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:15:00 --> Controller Class Initialized
INFO - 2020-01-27 13:15:00 --> Final output sent to browser
DEBUG - 2020-01-27 13:15:00 --> Total execution time: 0.5903
INFO - 2020-01-27 13:15:00 --> Config Class Initialized
INFO - 2020-01-27 13:15:00 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:15:00 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:15:00 --> Utf8 Class Initialized
INFO - 2020-01-27 13:15:00 --> URI Class Initialized
INFO - 2020-01-27 13:15:00 --> Router Class Initialized
INFO - 2020-01-27 13:15:01 --> Output Class Initialized
INFO - 2020-01-27 13:15:01 --> Security Class Initialized
DEBUG - 2020-01-27 13:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:15:01 --> Input Class Initialized
INFO - 2020-01-27 13:15:01 --> Language Class Initialized
INFO - 2020-01-27 13:15:01 --> Language Class Initialized
INFO - 2020-01-27 13:15:01 --> Config Class Initialized
INFO - 2020-01-27 13:15:01 --> Loader Class Initialized
INFO - 2020-01-27 13:15:01 --> Helper loaded: url_helper
INFO - 2020-01-27 13:15:01 --> Helper loaded: file_helper
INFO - 2020-01-27 13:15:01 --> Helper loaded: form_helper
INFO - 2020-01-27 13:15:01 --> Helper loaded: my_helper
INFO - 2020-01-27 13:15:01 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:15:01 --> Controller Class Initialized
DEBUG - 2020-01-27 13:15:01 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-01-27 13:15:01 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 13:15:01 --> Final output sent to browser
DEBUG - 2020-01-27 13:15:01 --> Total execution time: 0.7503
INFO - 2020-01-27 13:15:02 --> Config Class Initialized
INFO - 2020-01-27 13:15:02 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:15:02 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:15:02 --> Utf8 Class Initialized
INFO - 2020-01-27 13:15:02 --> URI Class Initialized
INFO - 2020-01-27 13:15:02 --> Router Class Initialized
INFO - 2020-01-27 13:15:02 --> Output Class Initialized
INFO - 2020-01-27 13:15:02 --> Security Class Initialized
DEBUG - 2020-01-27 13:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:15:02 --> Input Class Initialized
INFO - 2020-01-27 13:15:02 --> Language Class Initialized
INFO - 2020-01-27 13:15:02 --> Language Class Initialized
INFO - 2020-01-27 13:15:02 --> Config Class Initialized
INFO - 2020-01-27 13:15:02 --> Loader Class Initialized
INFO - 2020-01-27 13:15:02 --> Helper loaded: url_helper
INFO - 2020-01-27 13:15:02 --> Helper loaded: file_helper
INFO - 2020-01-27 13:15:02 --> Helper loaded: form_helper
INFO - 2020-01-27 13:15:02 --> Helper loaded: my_helper
INFO - 2020-01-27 13:15:02 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:15:02 --> Controller Class Initialized
INFO - 2020-01-27 13:15:02 --> Final output sent to browser
DEBUG - 2020-01-27 13:15:02 --> Total execution time: 0.5834
INFO - 2020-01-27 13:15:12 --> Config Class Initialized
INFO - 2020-01-27 13:15:12 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:15:12 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:15:12 --> Utf8 Class Initialized
INFO - 2020-01-27 13:15:12 --> URI Class Initialized
INFO - 2020-01-27 13:15:12 --> Router Class Initialized
INFO - 2020-01-27 13:15:12 --> Output Class Initialized
INFO - 2020-01-27 13:15:12 --> Security Class Initialized
DEBUG - 2020-01-27 13:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:15:13 --> Input Class Initialized
INFO - 2020-01-27 13:15:13 --> Language Class Initialized
INFO - 2020-01-27 13:15:13 --> Language Class Initialized
INFO - 2020-01-27 13:15:13 --> Config Class Initialized
INFO - 2020-01-27 13:15:13 --> Loader Class Initialized
INFO - 2020-01-27 13:15:13 --> Helper loaded: url_helper
INFO - 2020-01-27 13:15:13 --> Helper loaded: file_helper
INFO - 2020-01-27 13:15:13 --> Helper loaded: form_helper
INFO - 2020-01-27 13:15:13 --> Helper loaded: my_helper
INFO - 2020-01-27 13:15:13 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:15:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:15:13 --> Controller Class Initialized
DEBUG - 2020-01-27 13:15:13 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-27 13:15:13 --> Final output sent to browser
DEBUG - 2020-01-27 13:15:13 --> Total execution time: 0.6489
INFO - 2020-01-27 13:15:39 --> Config Class Initialized
INFO - 2020-01-27 13:15:39 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:15:39 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:15:39 --> Utf8 Class Initialized
INFO - 2020-01-27 13:15:39 --> URI Class Initialized
INFO - 2020-01-27 13:15:39 --> Router Class Initialized
INFO - 2020-01-27 13:15:39 --> Output Class Initialized
INFO - 2020-01-27 13:15:39 --> Security Class Initialized
DEBUG - 2020-01-27 13:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:15:39 --> Input Class Initialized
INFO - 2020-01-27 13:15:39 --> Language Class Initialized
INFO - 2020-01-27 13:15:39 --> Language Class Initialized
INFO - 2020-01-27 13:15:39 --> Config Class Initialized
INFO - 2020-01-27 13:15:39 --> Loader Class Initialized
INFO - 2020-01-27 13:15:39 --> Helper loaded: url_helper
INFO - 2020-01-27 13:15:39 --> Helper loaded: file_helper
INFO - 2020-01-27 13:15:39 --> Helper loaded: form_helper
INFO - 2020-01-27 13:15:39 --> Helper loaded: my_helper
INFO - 2020-01-27 13:15:39 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:15:40 --> Controller Class Initialized
INFO - 2020-01-27 13:15:40 --> Final output sent to browser
DEBUG - 2020-01-27 13:15:40 --> Total execution time: 0.5447
INFO - 2020-01-27 13:15:40 --> Config Class Initialized
INFO - 2020-01-27 13:15:40 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:15:41 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:15:41 --> Utf8 Class Initialized
INFO - 2020-01-27 13:15:41 --> URI Class Initialized
INFO - 2020-01-27 13:15:41 --> Router Class Initialized
INFO - 2020-01-27 13:15:41 --> Output Class Initialized
INFO - 2020-01-27 13:15:41 --> Security Class Initialized
DEBUG - 2020-01-27 13:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:15:41 --> Input Class Initialized
INFO - 2020-01-27 13:15:41 --> Language Class Initialized
INFO - 2020-01-27 13:15:41 --> Language Class Initialized
INFO - 2020-01-27 13:15:41 --> Config Class Initialized
INFO - 2020-01-27 13:15:41 --> Loader Class Initialized
INFO - 2020-01-27 13:15:41 --> Helper loaded: url_helper
INFO - 2020-01-27 13:15:41 --> Helper loaded: file_helper
INFO - 2020-01-27 13:15:41 --> Helper loaded: form_helper
INFO - 2020-01-27 13:15:41 --> Helper loaded: my_helper
INFO - 2020-01-27 13:15:41 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:15:41 --> Controller Class Initialized
INFO - 2020-01-27 13:15:41 --> Final output sent to browser
DEBUG - 2020-01-27 13:15:41 --> Total execution time: 0.5423
INFO - 2020-01-27 13:15:44 --> Config Class Initialized
INFO - 2020-01-27 13:15:44 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:15:44 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:15:44 --> Utf8 Class Initialized
INFO - 2020-01-27 13:15:44 --> URI Class Initialized
INFO - 2020-01-27 13:15:44 --> Router Class Initialized
INFO - 2020-01-27 13:15:44 --> Output Class Initialized
INFO - 2020-01-27 13:15:44 --> Security Class Initialized
DEBUG - 2020-01-27 13:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:15:44 --> Input Class Initialized
INFO - 2020-01-27 13:15:44 --> Language Class Initialized
INFO - 2020-01-27 13:15:44 --> Language Class Initialized
INFO - 2020-01-27 13:15:44 --> Config Class Initialized
INFO - 2020-01-27 13:15:44 --> Loader Class Initialized
INFO - 2020-01-27 13:15:44 --> Helper loaded: url_helper
INFO - 2020-01-27 13:15:44 --> Helper loaded: file_helper
INFO - 2020-01-27 13:15:44 --> Helper loaded: form_helper
INFO - 2020-01-27 13:15:44 --> Helper loaded: my_helper
INFO - 2020-01-27 13:15:44 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:15:44 --> Controller Class Initialized
INFO - 2020-01-27 13:15:44 --> Final output sent to browser
DEBUG - 2020-01-27 13:15:44 --> Total execution time: 0.5993
INFO - 2020-01-27 13:16:46 --> Config Class Initialized
INFO - 2020-01-27 13:16:46 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:16:46 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:16:46 --> Utf8 Class Initialized
INFO - 2020-01-27 13:16:46 --> URI Class Initialized
INFO - 2020-01-27 13:16:46 --> Router Class Initialized
INFO - 2020-01-27 13:16:46 --> Output Class Initialized
INFO - 2020-01-27 13:16:46 --> Security Class Initialized
DEBUG - 2020-01-27 13:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:16:46 --> Input Class Initialized
INFO - 2020-01-27 13:16:46 --> Language Class Initialized
INFO - 2020-01-27 13:16:46 --> Language Class Initialized
INFO - 2020-01-27 13:16:46 --> Config Class Initialized
INFO - 2020-01-27 13:16:46 --> Loader Class Initialized
INFO - 2020-01-27 13:16:47 --> Helper loaded: url_helper
INFO - 2020-01-27 13:16:47 --> Helper loaded: file_helper
INFO - 2020-01-27 13:16:47 --> Helper loaded: form_helper
INFO - 2020-01-27 13:16:47 --> Helper loaded: my_helper
INFO - 2020-01-27 13:16:47 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:16:47 --> Controller Class Initialized
DEBUG - 2020-01-27 13:16:47 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-01-27 13:16:47 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 13:16:47 --> Final output sent to browser
DEBUG - 2020-01-27 13:16:47 --> Total execution time: 0.6351
INFO - 2020-01-27 13:16:49 --> Config Class Initialized
INFO - 2020-01-27 13:16:49 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:16:49 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:16:49 --> Utf8 Class Initialized
INFO - 2020-01-27 13:16:49 --> URI Class Initialized
INFO - 2020-01-27 13:16:49 --> Router Class Initialized
INFO - 2020-01-27 13:16:49 --> Output Class Initialized
INFO - 2020-01-27 13:16:49 --> Security Class Initialized
DEBUG - 2020-01-27 13:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:16:49 --> Input Class Initialized
INFO - 2020-01-27 13:16:49 --> Language Class Initialized
INFO - 2020-01-27 13:16:49 --> Language Class Initialized
INFO - 2020-01-27 13:16:49 --> Config Class Initialized
INFO - 2020-01-27 13:16:49 --> Loader Class Initialized
INFO - 2020-01-27 13:16:49 --> Helper loaded: url_helper
INFO - 2020-01-27 13:16:49 --> Helper loaded: file_helper
INFO - 2020-01-27 13:16:49 --> Helper loaded: form_helper
INFO - 2020-01-27 13:16:49 --> Helper loaded: my_helper
INFO - 2020-01-27 13:16:49 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:16:49 --> Controller Class Initialized
DEBUG - 2020-01-27 13:16:49 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-01-27 13:16:49 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 13:16:49 --> Final output sent to browser
DEBUG - 2020-01-27 13:16:49 --> Total execution time: 0.6449
INFO - 2020-01-27 13:16:49 --> Config Class Initialized
INFO - 2020-01-27 13:16:49 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:16:49 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:16:49 --> Utf8 Class Initialized
INFO - 2020-01-27 13:16:49 --> URI Class Initialized
INFO - 2020-01-27 13:16:50 --> Router Class Initialized
INFO - 2020-01-27 13:16:50 --> Output Class Initialized
INFO - 2020-01-27 13:16:50 --> Security Class Initialized
DEBUG - 2020-01-27 13:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:16:50 --> Input Class Initialized
INFO - 2020-01-27 13:16:50 --> Language Class Initialized
INFO - 2020-01-27 13:16:50 --> Language Class Initialized
INFO - 2020-01-27 13:16:50 --> Config Class Initialized
INFO - 2020-01-27 13:16:50 --> Loader Class Initialized
INFO - 2020-01-27 13:16:50 --> Helper loaded: url_helper
INFO - 2020-01-27 13:16:50 --> Helper loaded: file_helper
INFO - 2020-01-27 13:16:50 --> Helper loaded: form_helper
INFO - 2020-01-27 13:16:50 --> Helper loaded: my_helper
INFO - 2020-01-27 13:16:50 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:16:50 --> Controller Class Initialized
INFO - 2020-01-27 13:16:52 --> Config Class Initialized
INFO - 2020-01-27 13:16:52 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:16:52 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:16:52 --> Utf8 Class Initialized
INFO - 2020-01-27 13:16:52 --> URI Class Initialized
INFO - 2020-01-27 13:16:52 --> Router Class Initialized
INFO - 2020-01-27 13:16:52 --> Output Class Initialized
INFO - 2020-01-27 13:16:52 --> Security Class Initialized
DEBUG - 2020-01-27 13:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:16:52 --> Input Class Initialized
INFO - 2020-01-27 13:16:52 --> Language Class Initialized
INFO - 2020-01-27 13:16:52 --> Language Class Initialized
INFO - 2020-01-27 13:16:52 --> Config Class Initialized
INFO - 2020-01-27 13:16:52 --> Loader Class Initialized
INFO - 2020-01-27 13:16:52 --> Helper loaded: url_helper
INFO - 2020-01-27 13:16:52 --> Helper loaded: file_helper
INFO - 2020-01-27 13:16:52 --> Helper loaded: form_helper
INFO - 2020-01-27 13:16:52 --> Helper loaded: my_helper
INFO - 2020-01-27 13:16:52 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:16:53 --> Controller Class Initialized
INFO - 2020-01-27 13:16:53 --> Final output sent to browser
DEBUG - 2020-01-27 13:16:53 --> Total execution time: 0.5498
INFO - 2020-01-27 13:16:56 --> Config Class Initialized
INFO - 2020-01-27 13:16:56 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:16:56 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:16:56 --> Utf8 Class Initialized
INFO - 2020-01-27 13:16:56 --> URI Class Initialized
INFO - 2020-01-27 13:16:56 --> Router Class Initialized
INFO - 2020-01-27 13:16:56 --> Output Class Initialized
INFO - 2020-01-27 13:16:56 --> Security Class Initialized
DEBUG - 2020-01-27 13:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:16:56 --> Input Class Initialized
INFO - 2020-01-27 13:16:56 --> Language Class Initialized
INFO - 2020-01-27 13:16:56 --> Language Class Initialized
INFO - 2020-01-27 13:16:56 --> Config Class Initialized
INFO - 2020-01-27 13:16:56 --> Loader Class Initialized
INFO - 2020-01-27 13:16:56 --> Helper loaded: url_helper
INFO - 2020-01-27 13:16:57 --> Helper loaded: file_helper
INFO - 2020-01-27 13:16:57 --> Helper loaded: form_helper
INFO - 2020-01-27 13:16:57 --> Helper loaded: my_helper
INFO - 2020-01-27 13:16:57 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:16:57 --> Controller Class Initialized
INFO - 2020-01-27 13:16:57 --> Final output sent to browser
DEBUG - 2020-01-27 13:16:57 --> Total execution time: 0.6131
INFO - 2020-01-27 13:17:32 --> Config Class Initialized
INFO - 2020-01-27 13:17:32 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:17:32 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:17:32 --> Utf8 Class Initialized
INFO - 2020-01-27 13:17:32 --> URI Class Initialized
INFO - 2020-01-27 13:17:32 --> Router Class Initialized
INFO - 2020-01-27 13:17:32 --> Output Class Initialized
INFO - 2020-01-27 13:17:32 --> Security Class Initialized
DEBUG - 2020-01-27 13:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:17:32 --> Input Class Initialized
INFO - 2020-01-27 13:17:32 --> Language Class Initialized
INFO - 2020-01-27 13:17:32 --> Language Class Initialized
INFO - 2020-01-27 13:17:33 --> Config Class Initialized
INFO - 2020-01-27 13:17:33 --> Loader Class Initialized
INFO - 2020-01-27 13:17:33 --> Helper loaded: url_helper
INFO - 2020-01-27 13:17:33 --> Helper loaded: file_helper
INFO - 2020-01-27 13:17:33 --> Helper loaded: form_helper
INFO - 2020-01-27 13:17:33 --> Helper loaded: my_helper
INFO - 2020-01-27 13:17:33 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:17:33 --> Controller Class Initialized
INFO - 2020-01-27 13:17:33 --> Final output sent to browser
DEBUG - 2020-01-27 13:17:33 --> Total execution time: 0.6175
INFO - 2020-01-27 13:17:33 --> Config Class Initialized
INFO - 2020-01-27 13:17:33 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:17:33 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:17:33 --> Utf8 Class Initialized
INFO - 2020-01-27 13:17:33 --> URI Class Initialized
INFO - 2020-01-27 13:17:33 --> Router Class Initialized
INFO - 2020-01-27 13:17:33 --> Output Class Initialized
INFO - 2020-01-27 13:17:33 --> Security Class Initialized
DEBUG - 2020-01-27 13:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:17:33 --> Input Class Initialized
INFO - 2020-01-27 13:17:33 --> Language Class Initialized
INFO - 2020-01-27 13:17:33 --> Language Class Initialized
INFO - 2020-01-27 13:17:33 --> Config Class Initialized
INFO - 2020-01-27 13:17:33 --> Loader Class Initialized
INFO - 2020-01-27 13:17:33 --> Helper loaded: url_helper
INFO - 2020-01-27 13:17:33 --> Helper loaded: file_helper
INFO - 2020-01-27 13:17:33 --> Helper loaded: form_helper
INFO - 2020-01-27 13:17:33 --> Helper loaded: my_helper
INFO - 2020-01-27 13:17:33 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:17:34 --> Controller Class Initialized
INFO - 2020-01-27 13:17:37 --> Config Class Initialized
INFO - 2020-01-27 13:17:37 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:17:37 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:17:37 --> Utf8 Class Initialized
INFO - 2020-01-27 13:17:37 --> URI Class Initialized
INFO - 2020-01-27 13:17:37 --> Router Class Initialized
INFO - 2020-01-27 13:17:37 --> Output Class Initialized
INFO - 2020-01-27 13:17:37 --> Security Class Initialized
DEBUG - 2020-01-27 13:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:17:37 --> Input Class Initialized
INFO - 2020-01-27 13:17:37 --> Language Class Initialized
INFO - 2020-01-27 13:17:37 --> Language Class Initialized
INFO - 2020-01-27 13:17:37 --> Config Class Initialized
INFO - 2020-01-27 13:17:37 --> Loader Class Initialized
INFO - 2020-01-27 13:17:37 --> Helper loaded: url_helper
INFO - 2020-01-27 13:17:37 --> Helper loaded: file_helper
INFO - 2020-01-27 13:17:37 --> Helper loaded: form_helper
INFO - 2020-01-27 13:17:37 --> Helper loaded: my_helper
INFO - 2020-01-27 13:17:37 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:17:37 --> Controller Class Initialized
INFO - 2020-01-27 13:17:37 --> Final output sent to browser
DEBUG - 2020-01-27 13:17:37 --> Total execution time: 0.6704
INFO - 2020-01-27 13:17:38 --> Config Class Initialized
INFO - 2020-01-27 13:17:38 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:17:38 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:17:38 --> Utf8 Class Initialized
INFO - 2020-01-27 13:17:38 --> URI Class Initialized
INFO - 2020-01-27 13:17:38 --> Router Class Initialized
INFO - 2020-01-27 13:17:38 --> Output Class Initialized
INFO - 2020-01-27 13:17:38 --> Security Class Initialized
DEBUG - 2020-01-27 13:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:17:38 --> Input Class Initialized
INFO - 2020-01-27 13:17:38 --> Language Class Initialized
INFO - 2020-01-27 13:17:38 --> Language Class Initialized
INFO - 2020-01-27 13:17:38 --> Config Class Initialized
INFO - 2020-01-27 13:17:38 --> Loader Class Initialized
INFO - 2020-01-27 13:17:38 --> Helper loaded: url_helper
INFO - 2020-01-27 13:17:38 --> Helper loaded: file_helper
INFO - 2020-01-27 13:17:38 --> Helper loaded: form_helper
INFO - 2020-01-27 13:17:38 --> Helper loaded: my_helper
INFO - 2020-01-27 13:17:38 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:17:38 --> Controller Class Initialized
INFO - 2020-01-27 13:17:38 --> Final output sent to browser
DEBUG - 2020-01-27 13:17:38 --> Total execution time: 0.5416
INFO - 2020-01-27 13:17:41 --> Config Class Initialized
INFO - 2020-01-27 13:17:41 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:17:41 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:17:41 --> Utf8 Class Initialized
INFO - 2020-01-27 13:17:41 --> URI Class Initialized
INFO - 2020-01-27 13:17:41 --> Router Class Initialized
INFO - 2020-01-27 13:17:41 --> Output Class Initialized
INFO - 2020-01-27 13:17:41 --> Security Class Initialized
DEBUG - 2020-01-27 13:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:17:41 --> Input Class Initialized
INFO - 2020-01-27 13:17:41 --> Language Class Initialized
INFO - 2020-01-27 13:17:41 --> Language Class Initialized
INFO - 2020-01-27 13:17:41 --> Config Class Initialized
INFO - 2020-01-27 13:17:41 --> Loader Class Initialized
INFO - 2020-01-27 13:17:41 --> Helper loaded: url_helper
INFO - 2020-01-27 13:17:41 --> Helper loaded: file_helper
INFO - 2020-01-27 13:17:41 --> Helper loaded: form_helper
INFO - 2020-01-27 13:17:41 --> Helper loaded: my_helper
INFO - 2020-01-27 13:17:41 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:17:41 --> Controller Class Initialized
DEBUG - 2020-01-27 13:17:41 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-01-27 13:17:41 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 13:17:41 --> Final output sent to browser
DEBUG - 2020-01-27 13:17:41 --> Total execution time: 0.6937
INFO - 2020-01-27 13:17:43 --> Config Class Initialized
INFO - 2020-01-27 13:17:43 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:17:43 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:17:43 --> Utf8 Class Initialized
INFO - 2020-01-27 13:17:43 --> URI Class Initialized
INFO - 2020-01-27 13:17:43 --> Router Class Initialized
INFO - 2020-01-27 13:17:43 --> Output Class Initialized
INFO - 2020-01-27 13:17:43 --> Security Class Initialized
DEBUG - 2020-01-27 13:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:17:43 --> Input Class Initialized
INFO - 2020-01-27 13:17:43 --> Language Class Initialized
INFO - 2020-01-27 13:17:43 --> Language Class Initialized
INFO - 2020-01-27 13:17:43 --> Config Class Initialized
INFO - 2020-01-27 13:17:43 --> Loader Class Initialized
INFO - 2020-01-27 13:17:43 --> Helper loaded: url_helper
INFO - 2020-01-27 13:17:43 --> Helper loaded: file_helper
INFO - 2020-01-27 13:17:43 --> Helper loaded: form_helper
INFO - 2020-01-27 13:17:43 --> Helper loaded: my_helper
INFO - 2020-01-27 13:17:43 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:17:43 --> Controller Class Initialized
DEBUG - 2020-01-27 13:17:43 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-01-27 13:17:43 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 13:17:43 --> Final output sent to browser
DEBUG - 2020-01-27 13:17:43 --> Total execution time: 0.6700
INFO - 2020-01-27 13:17:45 --> Config Class Initialized
INFO - 2020-01-27 13:17:45 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:17:45 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:17:45 --> Utf8 Class Initialized
INFO - 2020-01-27 13:17:45 --> URI Class Initialized
INFO - 2020-01-27 13:17:45 --> Router Class Initialized
INFO - 2020-01-27 13:17:45 --> Output Class Initialized
INFO - 2020-01-27 13:17:45 --> Security Class Initialized
DEBUG - 2020-01-27 13:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:17:45 --> Input Class Initialized
INFO - 2020-01-27 13:17:45 --> Language Class Initialized
INFO - 2020-01-27 13:17:45 --> Language Class Initialized
INFO - 2020-01-27 13:17:45 --> Config Class Initialized
INFO - 2020-01-27 13:17:45 --> Loader Class Initialized
INFO - 2020-01-27 13:17:45 --> Helper loaded: url_helper
INFO - 2020-01-27 13:17:45 --> Helper loaded: file_helper
INFO - 2020-01-27 13:17:45 --> Helper loaded: form_helper
INFO - 2020-01-27 13:17:45 --> Helper loaded: my_helper
INFO - 2020-01-27 13:17:45 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:17:46 --> Controller Class Initialized
DEBUG - 2020-01-27 13:17:46 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-01-27 13:17:46 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 13:17:46 --> Final output sent to browser
DEBUG - 2020-01-27 13:17:46 --> Total execution time: 0.6745
INFO - 2020-01-27 13:17:47 --> Config Class Initialized
INFO - 2020-01-27 13:17:47 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:17:47 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:17:47 --> Utf8 Class Initialized
INFO - 2020-01-27 13:17:47 --> URI Class Initialized
INFO - 2020-01-27 13:17:47 --> Router Class Initialized
INFO - 2020-01-27 13:17:47 --> Output Class Initialized
INFO - 2020-01-27 13:17:47 --> Security Class Initialized
DEBUG - 2020-01-27 13:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:17:47 --> Input Class Initialized
INFO - 2020-01-27 13:17:47 --> Language Class Initialized
INFO - 2020-01-27 13:17:47 --> Language Class Initialized
INFO - 2020-01-27 13:17:47 --> Config Class Initialized
INFO - 2020-01-27 13:17:47 --> Loader Class Initialized
INFO - 2020-01-27 13:17:47 --> Helper loaded: url_helper
INFO - 2020-01-27 13:17:47 --> Helper loaded: file_helper
INFO - 2020-01-27 13:17:48 --> Helper loaded: form_helper
INFO - 2020-01-27 13:17:48 --> Helper loaded: my_helper
INFO - 2020-01-27 13:17:48 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:17:48 --> Controller Class Initialized
DEBUG - 2020-01-27 13:17:48 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-01-27 13:17:48 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 13:17:48 --> Final output sent to browser
DEBUG - 2020-01-27 13:17:48 --> Total execution time: 0.6804
INFO - 2020-01-27 13:17:48 --> Config Class Initialized
INFO - 2020-01-27 13:17:48 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:17:48 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:17:48 --> Utf8 Class Initialized
INFO - 2020-01-27 13:17:48 --> URI Class Initialized
INFO - 2020-01-27 13:17:48 --> Router Class Initialized
INFO - 2020-01-27 13:17:48 --> Output Class Initialized
INFO - 2020-01-27 13:17:48 --> Security Class Initialized
DEBUG - 2020-01-27 13:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:17:48 --> Input Class Initialized
INFO - 2020-01-27 13:17:48 --> Language Class Initialized
INFO - 2020-01-27 13:17:48 --> Language Class Initialized
INFO - 2020-01-27 13:17:48 --> Config Class Initialized
INFO - 2020-01-27 13:17:48 --> Loader Class Initialized
INFO - 2020-01-27 13:17:48 --> Helper loaded: url_helper
INFO - 2020-01-27 13:17:48 --> Helper loaded: file_helper
INFO - 2020-01-27 13:17:48 --> Helper loaded: form_helper
INFO - 2020-01-27 13:17:48 --> Helper loaded: my_helper
INFO - 2020-01-27 13:17:48 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:17:49 --> Controller Class Initialized
INFO - 2020-01-27 13:17:50 --> Config Class Initialized
INFO - 2020-01-27 13:17:50 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:17:50 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:17:50 --> Utf8 Class Initialized
INFO - 2020-01-27 13:17:50 --> URI Class Initialized
INFO - 2020-01-27 13:17:50 --> Router Class Initialized
INFO - 2020-01-27 13:17:50 --> Output Class Initialized
INFO - 2020-01-27 13:17:50 --> Security Class Initialized
DEBUG - 2020-01-27 13:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:17:50 --> Input Class Initialized
INFO - 2020-01-27 13:17:50 --> Language Class Initialized
INFO - 2020-01-27 13:17:50 --> Language Class Initialized
INFO - 2020-01-27 13:17:50 --> Config Class Initialized
INFO - 2020-01-27 13:17:50 --> Loader Class Initialized
INFO - 2020-01-27 13:17:50 --> Helper loaded: url_helper
INFO - 2020-01-27 13:17:50 --> Helper loaded: file_helper
INFO - 2020-01-27 13:17:50 --> Helper loaded: form_helper
INFO - 2020-01-27 13:17:50 --> Helper loaded: my_helper
INFO - 2020-01-27 13:17:50 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:17:50 --> Controller Class Initialized
INFO - 2020-01-27 13:17:50 --> Final output sent to browser
DEBUG - 2020-01-27 13:17:50 --> Total execution time: 0.6574
INFO - 2020-01-27 13:17:56 --> Config Class Initialized
INFO - 2020-01-27 13:17:56 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:17:56 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:17:56 --> Utf8 Class Initialized
INFO - 2020-01-27 13:17:56 --> URI Class Initialized
INFO - 2020-01-27 13:17:56 --> Router Class Initialized
INFO - 2020-01-27 13:17:56 --> Output Class Initialized
INFO - 2020-01-27 13:17:56 --> Security Class Initialized
DEBUG - 2020-01-27 13:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:17:56 --> Input Class Initialized
INFO - 2020-01-27 13:17:56 --> Language Class Initialized
INFO - 2020-01-27 13:17:56 --> Language Class Initialized
INFO - 2020-01-27 13:17:56 --> Config Class Initialized
INFO - 2020-01-27 13:17:56 --> Loader Class Initialized
INFO - 2020-01-27 13:17:56 --> Helper loaded: url_helper
INFO - 2020-01-27 13:17:56 --> Helper loaded: file_helper
INFO - 2020-01-27 13:17:56 --> Helper loaded: form_helper
INFO - 2020-01-27 13:17:56 --> Helper loaded: my_helper
INFO - 2020-01-27 13:17:56 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:17:56 --> Controller Class Initialized
INFO - 2020-01-27 13:17:57 --> Final output sent to browser
DEBUG - 2020-01-27 13:17:57 --> Total execution time: 0.6890
INFO - 2020-01-27 13:18:02 --> Config Class Initialized
INFO - 2020-01-27 13:18:02 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:18:02 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:18:02 --> Utf8 Class Initialized
INFO - 2020-01-27 13:18:02 --> URI Class Initialized
INFO - 2020-01-27 13:18:02 --> Router Class Initialized
INFO - 2020-01-27 13:18:02 --> Output Class Initialized
INFO - 2020-01-27 13:18:02 --> Security Class Initialized
DEBUG - 2020-01-27 13:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:18:02 --> Input Class Initialized
INFO - 2020-01-27 13:18:02 --> Language Class Initialized
INFO - 2020-01-27 13:18:02 --> Language Class Initialized
INFO - 2020-01-27 13:18:02 --> Config Class Initialized
INFO - 2020-01-27 13:18:02 --> Loader Class Initialized
INFO - 2020-01-27 13:18:03 --> Helper loaded: url_helper
INFO - 2020-01-27 13:18:03 --> Helper loaded: file_helper
INFO - 2020-01-27 13:18:03 --> Helper loaded: form_helper
INFO - 2020-01-27 13:18:03 --> Helper loaded: my_helper
INFO - 2020-01-27 13:18:03 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:18:03 --> Controller Class Initialized
INFO - 2020-01-27 13:18:03 --> Final output sent to browser
DEBUG - 2020-01-27 13:18:03 --> Total execution time: 0.6353
INFO - 2020-01-27 13:18:04 --> Config Class Initialized
INFO - 2020-01-27 13:18:05 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:18:05 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:18:05 --> Utf8 Class Initialized
INFO - 2020-01-27 13:18:05 --> URI Class Initialized
INFO - 2020-01-27 13:18:05 --> Router Class Initialized
INFO - 2020-01-27 13:18:05 --> Output Class Initialized
INFO - 2020-01-27 13:18:05 --> Security Class Initialized
DEBUG - 2020-01-27 13:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:18:05 --> Input Class Initialized
INFO - 2020-01-27 13:18:05 --> Language Class Initialized
INFO - 2020-01-27 13:18:05 --> Language Class Initialized
INFO - 2020-01-27 13:18:05 --> Config Class Initialized
INFO - 2020-01-27 13:18:05 --> Loader Class Initialized
INFO - 2020-01-27 13:18:05 --> Helper loaded: url_helper
INFO - 2020-01-27 13:18:05 --> Helper loaded: file_helper
INFO - 2020-01-27 13:18:05 --> Helper loaded: form_helper
INFO - 2020-01-27 13:18:05 --> Helper loaded: my_helper
INFO - 2020-01-27 13:18:05 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:18:05 --> Controller Class Initialized
INFO - 2020-01-27 13:18:05 --> Final output sent to browser
DEBUG - 2020-01-27 13:18:05 --> Total execution time: 0.7133
INFO - 2020-01-27 13:18:07 --> Config Class Initialized
INFO - 2020-01-27 13:18:07 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:18:07 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:18:07 --> Utf8 Class Initialized
INFO - 2020-01-27 13:18:07 --> URI Class Initialized
INFO - 2020-01-27 13:18:07 --> Router Class Initialized
INFO - 2020-01-27 13:18:07 --> Output Class Initialized
INFO - 2020-01-27 13:18:07 --> Security Class Initialized
DEBUG - 2020-01-27 13:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:18:08 --> Input Class Initialized
INFO - 2020-01-27 13:18:08 --> Language Class Initialized
INFO - 2020-01-27 13:18:08 --> Language Class Initialized
INFO - 2020-01-27 13:18:08 --> Config Class Initialized
INFO - 2020-01-27 13:18:08 --> Loader Class Initialized
INFO - 2020-01-27 13:18:08 --> Helper loaded: url_helper
INFO - 2020-01-27 13:18:08 --> Helper loaded: file_helper
INFO - 2020-01-27 13:18:08 --> Helper loaded: form_helper
INFO - 2020-01-27 13:18:08 --> Helper loaded: my_helper
INFO - 2020-01-27 13:18:08 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:18:08 --> Controller Class Initialized
INFO - 2020-01-27 13:18:08 --> Final output sent to browser
DEBUG - 2020-01-27 13:18:08 --> Total execution time: 0.6473
INFO - 2020-01-27 13:18:13 --> Config Class Initialized
INFO - 2020-01-27 13:18:13 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:18:14 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:18:14 --> Utf8 Class Initialized
INFO - 2020-01-27 13:18:14 --> URI Class Initialized
INFO - 2020-01-27 13:18:14 --> Router Class Initialized
INFO - 2020-01-27 13:18:14 --> Output Class Initialized
INFO - 2020-01-27 13:18:14 --> Security Class Initialized
DEBUG - 2020-01-27 13:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:18:14 --> Input Class Initialized
INFO - 2020-01-27 13:18:14 --> Language Class Initialized
INFO - 2020-01-27 13:18:14 --> Language Class Initialized
INFO - 2020-01-27 13:18:14 --> Config Class Initialized
INFO - 2020-01-27 13:18:14 --> Loader Class Initialized
INFO - 2020-01-27 13:18:14 --> Helper loaded: url_helper
INFO - 2020-01-27 13:18:14 --> Helper loaded: file_helper
INFO - 2020-01-27 13:18:14 --> Helper loaded: form_helper
INFO - 2020-01-27 13:18:14 --> Helper loaded: my_helper
INFO - 2020-01-27 13:18:14 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:18:14 --> Controller Class Initialized
INFO - 2020-01-27 13:18:14 --> Final output sent to browser
DEBUG - 2020-01-27 13:18:14 --> Total execution time: 0.5835
INFO - 2020-01-27 13:18:15 --> Config Class Initialized
INFO - 2020-01-27 13:18:16 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:18:16 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:18:16 --> Utf8 Class Initialized
INFO - 2020-01-27 13:18:16 --> URI Class Initialized
INFO - 2020-01-27 13:18:16 --> Router Class Initialized
INFO - 2020-01-27 13:18:16 --> Output Class Initialized
INFO - 2020-01-27 13:18:16 --> Security Class Initialized
DEBUG - 2020-01-27 13:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:18:16 --> Input Class Initialized
INFO - 2020-01-27 13:18:16 --> Language Class Initialized
INFO - 2020-01-27 13:18:16 --> Language Class Initialized
INFO - 2020-01-27 13:18:16 --> Config Class Initialized
INFO - 2020-01-27 13:18:16 --> Loader Class Initialized
INFO - 2020-01-27 13:18:16 --> Helper loaded: url_helper
INFO - 2020-01-27 13:18:16 --> Helper loaded: file_helper
INFO - 2020-01-27 13:18:16 --> Helper loaded: form_helper
INFO - 2020-01-27 13:18:16 --> Helper loaded: my_helper
INFO - 2020-01-27 13:18:16 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:18:16 --> Controller Class Initialized
INFO - 2020-01-27 13:18:16 --> Final output sent to browser
DEBUG - 2020-01-27 13:18:16 --> Total execution time: 0.8430
INFO - 2020-01-27 13:18:19 --> Config Class Initialized
INFO - 2020-01-27 13:18:19 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:18:19 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:18:19 --> Utf8 Class Initialized
INFO - 2020-01-27 13:18:19 --> URI Class Initialized
INFO - 2020-01-27 13:18:19 --> Router Class Initialized
INFO - 2020-01-27 13:18:19 --> Output Class Initialized
INFO - 2020-01-27 13:18:19 --> Security Class Initialized
DEBUG - 2020-01-27 13:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:18:19 --> Input Class Initialized
INFO - 2020-01-27 13:18:19 --> Language Class Initialized
INFO - 2020-01-27 13:18:19 --> Language Class Initialized
INFO - 2020-01-27 13:18:19 --> Config Class Initialized
INFO - 2020-01-27 13:18:19 --> Loader Class Initialized
INFO - 2020-01-27 13:18:19 --> Helper loaded: url_helper
INFO - 2020-01-27 13:18:19 --> Helper loaded: file_helper
INFO - 2020-01-27 13:18:19 --> Helper loaded: form_helper
INFO - 2020-01-27 13:18:19 --> Helper loaded: my_helper
INFO - 2020-01-27 13:18:19 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:18:19 --> Controller Class Initialized
INFO - 2020-01-27 13:18:19 --> Final output sent to browser
DEBUG - 2020-01-27 13:18:19 --> Total execution time: 0.5666
INFO - 2020-01-27 13:18:23 --> Config Class Initialized
INFO - 2020-01-27 13:18:23 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:18:23 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:18:23 --> Utf8 Class Initialized
INFO - 2020-01-27 13:18:23 --> URI Class Initialized
INFO - 2020-01-27 13:18:23 --> Router Class Initialized
INFO - 2020-01-27 13:18:23 --> Output Class Initialized
INFO - 2020-01-27 13:18:23 --> Security Class Initialized
DEBUG - 2020-01-27 13:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:18:23 --> Input Class Initialized
INFO - 2020-01-27 13:18:23 --> Language Class Initialized
INFO - 2020-01-27 13:18:23 --> Language Class Initialized
INFO - 2020-01-27 13:18:23 --> Config Class Initialized
INFO - 2020-01-27 13:18:23 --> Loader Class Initialized
INFO - 2020-01-27 13:18:23 --> Helper loaded: url_helper
INFO - 2020-01-27 13:18:23 --> Helper loaded: file_helper
INFO - 2020-01-27 13:18:23 --> Helper loaded: form_helper
INFO - 2020-01-27 13:18:23 --> Helper loaded: my_helper
INFO - 2020-01-27 13:18:23 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:18:23 --> Controller Class Initialized
INFO - 2020-01-27 13:18:23 --> Final output sent to browser
DEBUG - 2020-01-27 13:18:23 --> Total execution time: 0.5602
INFO - 2020-01-27 13:18:32 --> Config Class Initialized
INFO - 2020-01-27 13:18:32 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:18:32 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:18:32 --> Utf8 Class Initialized
INFO - 2020-01-27 13:18:32 --> URI Class Initialized
INFO - 2020-01-27 13:18:32 --> Router Class Initialized
INFO - 2020-01-27 13:18:32 --> Output Class Initialized
INFO - 2020-01-27 13:18:33 --> Security Class Initialized
DEBUG - 2020-01-27 13:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:18:33 --> Input Class Initialized
INFO - 2020-01-27 13:18:33 --> Language Class Initialized
INFO - 2020-01-27 13:18:33 --> Language Class Initialized
INFO - 2020-01-27 13:18:33 --> Config Class Initialized
INFO - 2020-01-27 13:18:33 --> Loader Class Initialized
INFO - 2020-01-27 13:18:33 --> Helper loaded: url_helper
INFO - 2020-01-27 13:18:33 --> Helper loaded: file_helper
INFO - 2020-01-27 13:18:33 --> Helper loaded: form_helper
INFO - 2020-01-27 13:18:33 --> Helper loaded: my_helper
INFO - 2020-01-27 13:18:33 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:18:33 --> Controller Class Initialized
INFO - 2020-01-27 13:18:33 --> Final output sent to browser
DEBUG - 2020-01-27 13:18:33 --> Total execution time: 0.7310
INFO - 2020-01-27 13:18:35 --> Config Class Initialized
INFO - 2020-01-27 13:18:35 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:18:35 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:18:35 --> Utf8 Class Initialized
INFO - 2020-01-27 13:18:35 --> URI Class Initialized
INFO - 2020-01-27 13:18:35 --> Router Class Initialized
INFO - 2020-01-27 13:18:36 --> Output Class Initialized
INFO - 2020-01-27 13:18:36 --> Security Class Initialized
DEBUG - 2020-01-27 13:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:18:36 --> Input Class Initialized
INFO - 2020-01-27 13:18:36 --> Language Class Initialized
INFO - 2020-01-27 13:18:36 --> Language Class Initialized
INFO - 2020-01-27 13:18:36 --> Config Class Initialized
INFO - 2020-01-27 13:18:36 --> Loader Class Initialized
INFO - 2020-01-27 13:18:36 --> Helper loaded: url_helper
INFO - 2020-01-27 13:18:36 --> Helper loaded: file_helper
INFO - 2020-01-27 13:18:36 --> Helper loaded: form_helper
INFO - 2020-01-27 13:18:36 --> Helper loaded: my_helper
INFO - 2020-01-27 13:18:36 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:18:36 --> Controller Class Initialized
INFO - 2020-01-27 13:18:36 --> Final output sent to browser
DEBUG - 2020-01-27 13:18:36 --> Total execution time: 0.6367
INFO - 2020-01-27 13:18:38 --> Config Class Initialized
INFO - 2020-01-27 13:18:38 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:18:38 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:18:38 --> Utf8 Class Initialized
INFO - 2020-01-27 13:18:38 --> URI Class Initialized
INFO - 2020-01-27 13:18:38 --> Router Class Initialized
INFO - 2020-01-27 13:18:38 --> Output Class Initialized
INFO - 2020-01-27 13:18:38 --> Security Class Initialized
DEBUG - 2020-01-27 13:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:18:38 --> Input Class Initialized
INFO - 2020-01-27 13:18:38 --> Language Class Initialized
INFO - 2020-01-27 13:18:38 --> Language Class Initialized
INFO - 2020-01-27 13:18:38 --> Config Class Initialized
INFO - 2020-01-27 13:18:38 --> Loader Class Initialized
INFO - 2020-01-27 13:18:38 --> Helper loaded: url_helper
INFO - 2020-01-27 13:18:38 --> Helper loaded: file_helper
INFO - 2020-01-27 13:18:38 --> Helper loaded: form_helper
INFO - 2020-01-27 13:18:38 --> Helper loaded: my_helper
INFO - 2020-01-27 13:18:38 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:18:38 --> Controller Class Initialized
INFO - 2020-01-27 13:18:38 --> Final output sent to browser
DEBUG - 2020-01-27 13:18:38 --> Total execution time: 0.5915
INFO - 2020-01-27 13:18:40 --> Config Class Initialized
INFO - 2020-01-27 13:18:40 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:18:40 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:18:40 --> Utf8 Class Initialized
INFO - 2020-01-27 13:18:40 --> URI Class Initialized
INFO - 2020-01-27 13:18:40 --> Router Class Initialized
INFO - 2020-01-27 13:18:40 --> Output Class Initialized
INFO - 2020-01-27 13:18:40 --> Security Class Initialized
DEBUG - 2020-01-27 13:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:18:40 --> Input Class Initialized
INFO - 2020-01-27 13:18:40 --> Language Class Initialized
INFO - 2020-01-27 13:18:40 --> Language Class Initialized
INFO - 2020-01-27 13:18:40 --> Config Class Initialized
INFO - 2020-01-27 13:18:40 --> Loader Class Initialized
INFO - 2020-01-27 13:18:40 --> Helper loaded: url_helper
INFO - 2020-01-27 13:18:40 --> Helper loaded: file_helper
INFO - 2020-01-27 13:18:40 --> Helper loaded: form_helper
INFO - 2020-01-27 13:18:40 --> Helper loaded: my_helper
INFO - 2020-01-27 13:18:40 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:18:40 --> Controller Class Initialized
INFO - 2020-01-27 13:18:40 --> Final output sent to browser
DEBUG - 2020-01-27 13:18:40 --> Total execution time: 0.6469
INFO - 2020-01-27 13:18:45 --> Config Class Initialized
INFO - 2020-01-27 13:18:45 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:18:45 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:18:45 --> Utf8 Class Initialized
INFO - 2020-01-27 13:18:45 --> URI Class Initialized
INFO - 2020-01-27 13:18:45 --> Router Class Initialized
INFO - 2020-01-27 13:18:45 --> Output Class Initialized
INFO - 2020-01-27 13:18:45 --> Security Class Initialized
DEBUG - 2020-01-27 13:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:18:45 --> Input Class Initialized
INFO - 2020-01-27 13:18:45 --> Language Class Initialized
INFO - 2020-01-27 13:18:45 --> Language Class Initialized
INFO - 2020-01-27 13:18:45 --> Config Class Initialized
INFO - 2020-01-27 13:18:45 --> Loader Class Initialized
INFO - 2020-01-27 13:18:45 --> Helper loaded: url_helper
INFO - 2020-01-27 13:18:45 --> Helper loaded: file_helper
INFO - 2020-01-27 13:18:46 --> Helper loaded: form_helper
INFO - 2020-01-27 13:18:46 --> Helper loaded: my_helper
INFO - 2020-01-27 13:18:46 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:18:46 --> Controller Class Initialized
INFO - 2020-01-27 13:18:46 --> Final output sent to browser
DEBUG - 2020-01-27 13:18:46 --> Total execution time: 0.5918
INFO - 2020-01-27 13:18:47 --> Config Class Initialized
INFO - 2020-01-27 13:18:47 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:18:47 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:18:48 --> Utf8 Class Initialized
INFO - 2020-01-27 13:18:48 --> URI Class Initialized
INFO - 2020-01-27 13:18:48 --> Router Class Initialized
INFO - 2020-01-27 13:18:48 --> Output Class Initialized
INFO - 2020-01-27 13:18:48 --> Security Class Initialized
DEBUG - 2020-01-27 13:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:18:48 --> Input Class Initialized
INFO - 2020-01-27 13:18:48 --> Language Class Initialized
INFO - 2020-01-27 13:18:48 --> Language Class Initialized
INFO - 2020-01-27 13:18:48 --> Config Class Initialized
INFO - 2020-01-27 13:18:48 --> Loader Class Initialized
INFO - 2020-01-27 13:18:48 --> Helper loaded: url_helper
INFO - 2020-01-27 13:18:48 --> Helper loaded: file_helper
INFO - 2020-01-27 13:18:48 --> Helper loaded: form_helper
INFO - 2020-01-27 13:18:48 --> Helper loaded: my_helper
INFO - 2020-01-27 13:18:48 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:18:48 --> Controller Class Initialized
INFO - 2020-01-27 13:18:48 --> Final output sent to browser
DEBUG - 2020-01-27 13:18:48 --> Total execution time: 0.6188
INFO - 2020-01-27 13:18:50 --> Config Class Initialized
INFO - 2020-01-27 13:18:50 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:18:50 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:18:50 --> Utf8 Class Initialized
INFO - 2020-01-27 13:18:50 --> URI Class Initialized
INFO - 2020-01-27 13:18:50 --> Router Class Initialized
INFO - 2020-01-27 13:18:50 --> Output Class Initialized
INFO - 2020-01-27 13:18:50 --> Security Class Initialized
DEBUG - 2020-01-27 13:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:18:50 --> Input Class Initialized
INFO - 2020-01-27 13:18:50 --> Language Class Initialized
INFO - 2020-01-27 13:18:50 --> Language Class Initialized
INFO - 2020-01-27 13:18:50 --> Config Class Initialized
INFO - 2020-01-27 13:18:50 --> Loader Class Initialized
INFO - 2020-01-27 13:18:50 --> Helper loaded: url_helper
INFO - 2020-01-27 13:18:50 --> Helper loaded: file_helper
INFO - 2020-01-27 13:18:50 --> Helper loaded: form_helper
INFO - 2020-01-27 13:18:50 --> Helper loaded: my_helper
INFO - 2020-01-27 13:18:50 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:18:50 --> Controller Class Initialized
INFO - 2020-01-27 13:18:50 --> Final output sent to browser
DEBUG - 2020-01-27 13:18:50 --> Total execution time: 0.6082
INFO - 2020-01-27 13:18:52 --> Config Class Initialized
INFO - 2020-01-27 13:18:52 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:18:52 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:18:52 --> Utf8 Class Initialized
INFO - 2020-01-27 13:18:52 --> URI Class Initialized
INFO - 2020-01-27 13:18:52 --> Router Class Initialized
INFO - 2020-01-27 13:18:52 --> Output Class Initialized
INFO - 2020-01-27 13:18:52 --> Security Class Initialized
DEBUG - 2020-01-27 13:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:18:52 --> Input Class Initialized
INFO - 2020-01-27 13:18:52 --> Language Class Initialized
INFO - 2020-01-27 13:18:52 --> Language Class Initialized
INFO - 2020-01-27 13:18:52 --> Config Class Initialized
INFO - 2020-01-27 13:18:52 --> Loader Class Initialized
INFO - 2020-01-27 13:18:52 --> Helper loaded: url_helper
INFO - 2020-01-27 13:18:52 --> Helper loaded: file_helper
INFO - 2020-01-27 13:18:52 --> Helper loaded: form_helper
INFO - 2020-01-27 13:18:53 --> Helper loaded: my_helper
INFO - 2020-01-27 13:18:53 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:18:53 --> Controller Class Initialized
DEBUG - 2020-01-27 13:18:53 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-01-27 13:18:53 --> Final output sent to browser
DEBUG - 2020-01-27 13:18:53 --> Total execution time: 0.6903
INFO - 2020-01-27 13:27:18 --> Config Class Initialized
INFO - 2020-01-27 13:27:18 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:27:18 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:27:18 --> Utf8 Class Initialized
INFO - 2020-01-27 13:27:18 --> URI Class Initialized
INFO - 2020-01-27 13:27:18 --> Router Class Initialized
INFO - 2020-01-27 13:27:18 --> Output Class Initialized
INFO - 2020-01-27 13:27:18 --> Security Class Initialized
DEBUG - 2020-01-27 13:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:27:19 --> Input Class Initialized
INFO - 2020-01-27 13:27:19 --> Language Class Initialized
INFO - 2020-01-27 13:27:19 --> Language Class Initialized
INFO - 2020-01-27 13:27:19 --> Config Class Initialized
INFO - 2020-01-27 13:27:19 --> Loader Class Initialized
INFO - 2020-01-27 13:27:19 --> Helper loaded: url_helper
INFO - 2020-01-27 13:27:19 --> Helper loaded: file_helper
INFO - 2020-01-27 13:27:19 --> Helper loaded: form_helper
INFO - 2020-01-27 13:27:19 --> Helper loaded: my_helper
INFO - 2020-01-27 13:27:19 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:27:19 --> Controller Class Initialized
ERROR - 2020-01-27 13:27:19 --> Severity: Notice --> Undefined variable: html1 E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_pengetahuan\views\cetak.php 16
DEBUG - 2020-01-27 13:27:19 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-01-27 13:27:19 --> Final output sent to browser
DEBUG - 2020-01-27 13:27:19 --> Total execution time: 0.6901
INFO - 2020-01-27 13:29:21 --> Config Class Initialized
INFO - 2020-01-27 13:29:21 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:29:21 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:29:21 --> Utf8 Class Initialized
INFO - 2020-01-27 13:29:21 --> URI Class Initialized
INFO - 2020-01-27 13:29:21 --> Router Class Initialized
INFO - 2020-01-27 13:29:21 --> Output Class Initialized
INFO - 2020-01-27 13:29:21 --> Security Class Initialized
DEBUG - 2020-01-27 13:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:29:21 --> Input Class Initialized
INFO - 2020-01-27 13:29:21 --> Language Class Initialized
INFO - 2020-01-27 13:29:21 --> Language Class Initialized
INFO - 2020-01-27 13:29:21 --> Config Class Initialized
INFO - 2020-01-27 13:29:21 --> Loader Class Initialized
INFO - 2020-01-27 13:29:22 --> Helper loaded: url_helper
INFO - 2020-01-27 13:29:22 --> Helper loaded: file_helper
INFO - 2020-01-27 13:29:22 --> Helper loaded: form_helper
INFO - 2020-01-27 13:29:22 --> Helper loaded: my_helper
INFO - 2020-01-27 13:29:22 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:29:22 --> Controller Class Initialized
ERROR - 2020-01-27 13:29:22 --> Severity: Notice --> Undefined variable: detil_guru E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 234
ERROR - 2020-01-27 13:29:22 --> Severity: Notice --> Undefined variable: detil_guru E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 234
ERROR - 2020-01-27 13:29:22 --> Severity: Notice --> Undefined variable: detil_guru E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 234
DEBUG - 2020-01-27 13:29:22 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-01-27 13:29:22 --> Final output sent to browser
DEBUG - 2020-01-27 13:29:22 --> Total execution time: 0.7812
INFO - 2020-01-27 13:30:15 --> Config Class Initialized
INFO - 2020-01-27 13:30:15 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:30:15 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:30:15 --> Utf8 Class Initialized
INFO - 2020-01-27 13:30:15 --> URI Class Initialized
INFO - 2020-01-27 13:30:15 --> Router Class Initialized
INFO - 2020-01-27 13:30:15 --> Output Class Initialized
INFO - 2020-01-27 13:30:15 --> Security Class Initialized
DEBUG - 2020-01-27 13:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:30:15 --> Input Class Initialized
INFO - 2020-01-27 13:30:15 --> Language Class Initialized
INFO - 2020-01-27 13:30:16 --> Language Class Initialized
INFO - 2020-01-27 13:30:16 --> Config Class Initialized
INFO - 2020-01-27 13:30:16 --> Loader Class Initialized
INFO - 2020-01-27 13:30:16 --> Helper loaded: url_helper
INFO - 2020-01-27 13:30:16 --> Helper loaded: file_helper
INFO - 2020-01-27 13:30:16 --> Helper loaded: form_helper
INFO - 2020-01-27 13:30:16 --> Helper loaded: my_helper
INFO - 2020-01-27 13:30:16 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:30:16 --> Controller Class Initialized
ERROR - 2020-01-27 13:30:16 --> Severity: Notice --> Undefined offset: 1 E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 140
ERROR - 2020-01-27 13:30:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND a.tasm = '20182'' at line 8 - Invalid query: SELECT 
                                         b.nama nmmapel, c.nama nmkelas, d.nama nmguru
                                         FROM t_guru_mapel a
                                         INNER JOIN m_mapel b ON a.id_mapel = b.id 
                                         INNER JOIN m_kelas c ON a.id_kelas = c.id
                                         INNER JOIN m_guru d ON a.id_guru = d.id 
                                         WHERE b.id = 1 AND c.id =  
                                         AND a.tasm = '20182'
INFO - 2020-01-27 13:30:16 --> Language file loaded: language/english/db_lang.php
INFO - 2020-01-27 13:30:54 --> Config Class Initialized
INFO - 2020-01-27 13:30:54 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:30:54 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:30:54 --> Utf8 Class Initialized
INFO - 2020-01-27 13:30:54 --> URI Class Initialized
INFO - 2020-01-27 13:30:54 --> Router Class Initialized
INFO - 2020-01-27 13:30:54 --> Output Class Initialized
INFO - 2020-01-27 13:30:54 --> Security Class Initialized
DEBUG - 2020-01-27 13:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:30:54 --> Input Class Initialized
INFO - 2020-01-27 13:30:54 --> Language Class Initialized
INFO - 2020-01-27 13:30:54 --> Language Class Initialized
INFO - 2020-01-27 13:30:55 --> Config Class Initialized
INFO - 2020-01-27 13:30:55 --> Loader Class Initialized
INFO - 2020-01-27 13:30:55 --> Helper loaded: url_helper
INFO - 2020-01-27 13:30:55 --> Helper loaded: file_helper
INFO - 2020-01-27 13:30:55 --> Helper loaded: form_helper
INFO - 2020-01-27 13:30:55 --> Helper loaded: my_helper
INFO - 2020-01-27 13:30:55 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:30:55 --> Controller Class Initialized
DEBUG - 2020-01-27 13:30:55 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-01-27 13:30:55 --> Final output sent to browser
DEBUG - 2020-01-27 13:30:55 --> Total execution time: 0.6800
INFO - 2020-01-27 13:31:39 --> Config Class Initialized
INFO - 2020-01-27 13:31:39 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:31:39 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:31:39 --> Utf8 Class Initialized
INFO - 2020-01-27 13:31:40 --> URI Class Initialized
INFO - 2020-01-27 13:31:40 --> Router Class Initialized
INFO - 2020-01-27 13:31:40 --> Output Class Initialized
INFO - 2020-01-27 13:31:40 --> Security Class Initialized
DEBUG - 2020-01-27 13:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:31:40 --> Input Class Initialized
INFO - 2020-01-27 13:31:40 --> Language Class Initialized
ERROR - 2020-01-27 13:31:40 --> Severity: Compile Error --> Cannot redeclare N_pengetahuan::ambil_siswa() E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 704
INFO - 2020-01-27 13:32:18 --> Config Class Initialized
INFO - 2020-01-27 13:32:18 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:32:18 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:32:18 --> Utf8 Class Initialized
INFO - 2020-01-27 13:32:18 --> URI Class Initialized
INFO - 2020-01-27 13:32:18 --> Router Class Initialized
INFO - 2020-01-27 13:32:18 --> Output Class Initialized
INFO - 2020-01-27 13:32:18 --> Security Class Initialized
DEBUG - 2020-01-27 13:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:32:18 --> Input Class Initialized
INFO - 2020-01-27 13:32:18 --> Language Class Initialized
INFO - 2020-01-27 13:32:18 --> Language Class Initialized
INFO - 2020-01-27 13:32:18 --> Config Class Initialized
INFO - 2020-01-27 13:32:18 --> Loader Class Initialized
INFO - 2020-01-27 13:32:18 --> Helper loaded: url_helper
INFO - 2020-01-27 13:32:18 --> Helper loaded: file_helper
INFO - 2020-01-27 13:32:19 --> Helper loaded: form_helper
INFO - 2020-01-27 13:32:19 --> Helper loaded: my_helper
INFO - 2020-01-27 13:32:19 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:32:19 --> Controller Class Initialized
ERROR - 2020-01-27 13:32:19 --> Severity: Notice --> Undefined offset: 1 E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 39
ERROR - 2020-01-27 13:32:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND a.tasm = '20182'' at line 8 - Invalid query: SELECT 
                                b.nama nmmapel, b.kkm, c.nama nmkelas, d.nama nmguru
                                FROM t_guru_mapel a
                                INNER JOIN m_mapel b ON a.id_mapel = b.id 
                                INNER JOIN m_kelas c ON a.id_kelas = c.id
                                INNER JOIN m_guru d ON a.id_guru = d.id 
                                WHERE b.id = 1 AND c.id =  
                                AND a.tasm = '20182'
INFO - 2020-01-27 13:32:19 --> Language file loaded: language/english/db_lang.php
INFO - 2020-01-27 13:32:55 --> Config Class Initialized
INFO - 2020-01-27 13:32:55 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:32:55 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:32:55 --> Utf8 Class Initialized
INFO - 2020-01-27 13:32:55 --> URI Class Initialized
INFO - 2020-01-27 13:32:55 --> Router Class Initialized
INFO - 2020-01-27 13:32:55 --> Output Class Initialized
INFO - 2020-01-27 13:32:55 --> Security Class Initialized
DEBUG - 2020-01-27 13:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:32:55 --> Input Class Initialized
INFO - 2020-01-27 13:32:55 --> Language Class Initialized
INFO - 2020-01-27 13:32:55 --> Language Class Initialized
INFO - 2020-01-27 13:32:55 --> Config Class Initialized
INFO - 2020-01-27 13:32:55 --> Loader Class Initialized
INFO - 2020-01-27 13:32:55 --> Helper loaded: url_helper
INFO - 2020-01-27 13:32:55 --> Helper loaded: file_helper
INFO - 2020-01-27 13:32:55 --> Helper loaded: form_helper
INFO - 2020-01-27 13:32:55 --> Helper loaded: my_helper
INFO - 2020-01-27 13:32:55 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:32:55 --> Controller Class Initialized
ERROR - 2020-01-27 13:32:55 --> Severity: Notice --> Undefined offset: 1 E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 39
ERROR - 2020-01-27 13:32:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND a.tasm = '20182'' at line 8 - Invalid query: SELECT 
                                b.nama nmmapel, b.kkm, c.nama nmkelas, d.nama nmguru
                                FROM t_guru_mapel a
                                INNER JOIN m_mapel b ON a.id_mapel = b.id 
                                INNER JOIN m_kelas c ON a.id_kelas = c.id
                                INNER JOIN m_guru d ON a.id_guru = d.id 
                                WHERE b.id = 1 AND c.id =  
                                AND a.tasm = '20182'
INFO - 2020-01-27 13:32:56 --> Language file loaded: language/english/db_lang.php
INFO - 2020-01-27 13:34:27 --> Config Class Initialized
INFO - 2020-01-27 13:34:27 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:34:27 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:34:27 --> Utf8 Class Initialized
INFO - 2020-01-27 13:34:27 --> URI Class Initialized
INFO - 2020-01-27 13:34:27 --> Router Class Initialized
INFO - 2020-01-27 13:34:27 --> Output Class Initialized
INFO - 2020-01-27 13:34:27 --> Security Class Initialized
DEBUG - 2020-01-27 13:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:34:27 --> Input Class Initialized
INFO - 2020-01-27 13:34:27 --> Language Class Initialized
INFO - 2020-01-27 13:34:27 --> Language Class Initialized
INFO - 2020-01-27 13:34:27 --> Config Class Initialized
INFO - 2020-01-27 13:34:27 --> Loader Class Initialized
INFO - 2020-01-27 13:34:27 --> Helper loaded: url_helper
INFO - 2020-01-27 13:34:27 --> Helper loaded: file_helper
INFO - 2020-01-27 13:34:27 --> Helper loaded: form_helper
INFO - 2020-01-27 13:34:27 --> Helper loaded: my_helper
INFO - 2020-01-27 13:34:28 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:34:28 --> Controller Class Initialized
DEBUG - 2020-01-27 13:34:28 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-01-27 13:34:28 --> Final output sent to browser
DEBUG - 2020-01-27 13:34:28 --> Total execution time: 0.6731
INFO - 2020-01-27 13:35:18 --> Config Class Initialized
INFO - 2020-01-27 13:35:18 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:35:18 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:35:18 --> Utf8 Class Initialized
INFO - 2020-01-27 13:35:18 --> URI Class Initialized
INFO - 2020-01-27 13:35:18 --> Router Class Initialized
INFO - 2020-01-27 13:35:18 --> Output Class Initialized
INFO - 2020-01-27 13:35:18 --> Security Class Initialized
DEBUG - 2020-01-27 13:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:35:18 --> Input Class Initialized
INFO - 2020-01-27 13:35:18 --> Language Class Initialized
INFO - 2020-01-27 13:35:18 --> Language Class Initialized
INFO - 2020-01-27 13:35:18 --> Config Class Initialized
INFO - 2020-01-27 13:35:18 --> Loader Class Initialized
INFO - 2020-01-27 13:35:18 --> Helper loaded: url_helper
INFO - 2020-01-27 13:35:18 --> Helper loaded: file_helper
INFO - 2020-01-27 13:35:18 --> Helper loaded: form_helper
INFO - 2020-01-27 13:35:18 --> Helper loaded: my_helper
INFO - 2020-01-27 13:35:18 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:35:19 --> Controller Class Initialized
DEBUG - 2020-01-27 13:35:19 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-01-27 13:35:19 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-27 13:35:19 --> Final output sent to browser
DEBUG - 2020-01-27 13:35:19 --> Total execution time: 0.7632
INFO - 2020-01-27 13:35:19 --> Config Class Initialized
INFO - 2020-01-27 13:35:19 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:35:19 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:35:19 --> Utf8 Class Initialized
INFO - 2020-01-27 13:35:19 --> URI Class Initialized
INFO - 2020-01-27 13:35:19 --> Router Class Initialized
INFO - 2020-01-27 13:35:19 --> Output Class Initialized
INFO - 2020-01-27 13:35:19 --> Security Class Initialized
DEBUG - 2020-01-27 13:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:35:19 --> Input Class Initialized
INFO - 2020-01-27 13:35:19 --> Language Class Initialized
INFO - 2020-01-27 13:35:19 --> Language Class Initialized
INFO - 2020-01-27 13:35:19 --> Config Class Initialized
INFO - 2020-01-27 13:35:19 --> Loader Class Initialized
INFO - 2020-01-27 13:35:19 --> Helper loaded: url_helper
INFO - 2020-01-27 13:35:19 --> Helper loaded: file_helper
INFO - 2020-01-27 13:35:19 --> Helper loaded: form_helper
INFO - 2020-01-27 13:35:19 --> Helper loaded: my_helper
INFO - 2020-01-27 13:35:19 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:35:19 --> Controller Class Initialized
INFO - 2020-01-27 13:35:22 --> Config Class Initialized
INFO - 2020-01-27 13:35:22 --> Hooks Class Initialized
DEBUG - 2020-01-27 13:35:22 --> UTF-8 Support Enabled
INFO - 2020-01-27 13:35:22 --> Utf8 Class Initialized
INFO - 2020-01-27 13:35:22 --> URI Class Initialized
INFO - 2020-01-27 13:35:22 --> Router Class Initialized
INFO - 2020-01-27 13:35:22 --> Output Class Initialized
INFO - 2020-01-27 13:35:22 --> Security Class Initialized
DEBUG - 2020-01-27 13:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-27 13:35:22 --> Input Class Initialized
INFO - 2020-01-27 13:35:22 --> Language Class Initialized
INFO - 2020-01-27 13:35:22 --> Language Class Initialized
INFO - 2020-01-27 13:35:22 --> Config Class Initialized
INFO - 2020-01-27 13:35:22 --> Loader Class Initialized
INFO - 2020-01-27 13:35:22 --> Helper loaded: url_helper
INFO - 2020-01-27 13:35:22 --> Helper loaded: file_helper
INFO - 2020-01-27 13:35:22 --> Helper loaded: form_helper
INFO - 2020-01-27 13:35:22 --> Helper loaded: my_helper
INFO - 2020-01-27 13:35:22 --> Database Driver Class Initialized
DEBUG - 2020-01-27 13:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-27 13:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-27 13:35:22 --> Controller Class Initialized
ERROR - 2020-01-27 13:35:22 --> Severity: Notice --> Uninitialized string offset: 1 E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 50
ERROR - 2020-01-27 13:35:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND b.id_mapel = 1
                                AND a.tasm = '20182'
        ' at line 7 - Invalid query: SELECT 
                                d.nama nmsiswa, a.id_mapel_kd, a.id_siswa, a.nilai
                                FROM t_nilai_ket a
                                LEFT JOIN t_mapel_kd b ON a.id_mapel_kd = b.id
                                LEFT JOIN t_kelas_siswa c ON CONCAT(a.id_siswa,LEFT(a.tasm,4)) = CONCAT(c.id_siswa,c.ta)
                                LEFT JOIN m_siswa d ON c.id_siswa = d.id
                                WHERE c.id_kelas =  AND b.id_mapel = 1
                                AND a.tasm = '20182'
                                ORDER BY d.nama ASC
INFO - 2020-01-27 13:35:22 --> Language file loaded: language/english/db_lang.php
