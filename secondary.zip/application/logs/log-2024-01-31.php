<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-01-31 12:57:27 --> Config Class Initialized
INFO - 2024-01-31 12:57:27 --> Hooks Class Initialized
DEBUG - 2024-01-31 12:57:27 --> UTF-8 Support Enabled
INFO - 2024-01-31 12:57:27 --> Utf8 Class Initialized
INFO - 2024-01-31 12:57:27 --> URI Class Initialized
INFO - 2024-01-31 12:57:27 --> Router Class Initialized
INFO - 2024-01-31 12:57:27 --> Output Class Initialized
INFO - 2024-01-31 12:57:27 --> Security Class Initialized
DEBUG - 2024-01-31 12:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-31 12:57:27 --> Input Class Initialized
INFO - 2024-01-31 12:57:27 --> Language Class Initialized
INFO - 2024-01-31 12:57:27 --> Language Class Initialized
INFO - 2024-01-31 12:57:27 --> Config Class Initialized
INFO - 2024-01-31 12:57:27 --> Loader Class Initialized
INFO - 2024-01-31 12:57:27 --> Helper loaded: url_helper
INFO - 2024-01-31 12:57:27 --> Helper loaded: file_helper
INFO - 2024-01-31 12:57:27 --> Helper loaded: form_helper
INFO - 2024-01-31 12:57:27 --> Helper loaded: my_helper
INFO - 2024-01-31 12:57:27 --> Database Driver Class Initialized
INFO - 2024-01-31 12:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-31 12:57:28 --> Controller Class Initialized
DEBUG - 2024-01-31 12:57:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-01-31 12:57:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-31 12:57:28 --> Final output sent to browser
DEBUG - 2024-01-31 12:57:28 --> Total execution time: 0.5122
