<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-13 02:38:57 --> Config Class Initialized
INFO - 2024-10-13 02:38:57 --> Hooks Class Initialized
DEBUG - 2024-10-13 02:38:57 --> UTF-8 Support Enabled
INFO - 2024-10-13 02:38:57 --> Utf8 Class Initialized
INFO - 2024-10-13 02:38:57 --> URI Class Initialized
INFO - 2024-10-13 02:38:57 --> Router Class Initialized
INFO - 2024-10-13 02:38:57 --> Output Class Initialized
INFO - 2024-10-13 02:38:57 --> Security Class Initialized
DEBUG - 2024-10-13 02:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 02:38:57 --> Input Class Initialized
INFO - 2024-10-13 02:38:57 --> Language Class Initialized
INFO - 2024-10-13 02:38:57 --> Language Class Initialized
INFO - 2024-10-13 02:38:57 --> Config Class Initialized
INFO - 2024-10-13 02:38:57 --> Loader Class Initialized
INFO - 2024-10-13 02:38:57 --> Helper loaded: url_helper
INFO - 2024-10-13 02:38:57 --> Helper loaded: file_helper
INFO - 2024-10-13 02:38:57 --> Helper loaded: form_helper
INFO - 2024-10-13 02:38:57 --> Helper loaded: my_helper
INFO - 2024-10-13 02:38:57 --> Database Driver Class Initialized
INFO - 2024-10-13 02:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-13 02:38:57 --> Controller Class Initialized
INFO - 2024-10-13 02:38:57 --> Helper loaded: cookie_helper
INFO - 2024-10-13 02:38:57 --> Final output sent to browser
DEBUG - 2024-10-13 02:38:57 --> Total execution time: 0.1224
INFO - 2024-10-13 02:38:58 --> Config Class Initialized
INFO - 2024-10-13 02:38:58 --> Hooks Class Initialized
DEBUG - 2024-10-13 02:38:58 --> UTF-8 Support Enabled
INFO - 2024-10-13 02:38:58 --> Utf8 Class Initialized
INFO - 2024-10-13 02:38:58 --> URI Class Initialized
INFO - 2024-10-13 02:38:58 --> Router Class Initialized
INFO - 2024-10-13 02:38:58 --> Output Class Initialized
INFO - 2024-10-13 02:38:58 --> Security Class Initialized
DEBUG - 2024-10-13 02:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 02:38:58 --> Input Class Initialized
INFO - 2024-10-13 02:38:58 --> Language Class Initialized
INFO - 2024-10-13 02:38:58 --> Language Class Initialized
INFO - 2024-10-13 02:38:58 --> Config Class Initialized
INFO - 2024-10-13 02:38:58 --> Loader Class Initialized
INFO - 2024-10-13 02:38:58 --> Helper loaded: url_helper
INFO - 2024-10-13 02:38:58 --> Helper loaded: file_helper
INFO - 2024-10-13 02:38:58 --> Helper loaded: form_helper
INFO - 2024-10-13 02:38:58 --> Helper loaded: my_helper
INFO - 2024-10-13 02:38:58 --> Database Driver Class Initialized
INFO - 2024-10-13 02:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-13 02:38:58 --> Controller Class Initialized
INFO - 2024-10-13 02:38:58 --> Helper loaded: cookie_helper
INFO - 2024-10-13 02:38:58 --> Config Class Initialized
INFO - 2024-10-13 02:38:58 --> Hooks Class Initialized
DEBUG - 2024-10-13 02:38:58 --> UTF-8 Support Enabled
INFO - 2024-10-13 02:38:58 --> Utf8 Class Initialized
INFO - 2024-10-13 02:38:58 --> URI Class Initialized
INFO - 2024-10-13 02:38:58 --> Router Class Initialized
INFO - 2024-10-13 02:38:58 --> Output Class Initialized
INFO - 2024-10-13 02:38:58 --> Security Class Initialized
DEBUG - 2024-10-13 02:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 02:38:58 --> Input Class Initialized
INFO - 2024-10-13 02:38:58 --> Language Class Initialized
INFO - 2024-10-13 02:38:58 --> Language Class Initialized
INFO - 2024-10-13 02:38:58 --> Config Class Initialized
INFO - 2024-10-13 02:38:58 --> Loader Class Initialized
INFO - 2024-10-13 02:38:58 --> Helper loaded: url_helper
INFO - 2024-10-13 02:38:58 --> Helper loaded: file_helper
INFO - 2024-10-13 02:38:58 --> Helper loaded: form_helper
INFO - 2024-10-13 02:38:58 --> Helper loaded: my_helper
INFO - 2024-10-13 02:38:58 --> Database Driver Class Initialized
INFO - 2024-10-13 02:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-13 02:38:58 --> Controller Class Initialized
DEBUG - 2024-10-13 02:38:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-13 02:38:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-13 02:38:58 --> Final output sent to browser
DEBUG - 2024-10-13 02:38:58 --> Total execution time: 0.0892
INFO - 2024-10-13 02:39:02 --> Config Class Initialized
INFO - 2024-10-13 02:39:02 --> Hooks Class Initialized
DEBUG - 2024-10-13 02:39:02 --> UTF-8 Support Enabled
INFO - 2024-10-13 02:39:02 --> Utf8 Class Initialized
INFO - 2024-10-13 02:39:02 --> URI Class Initialized
INFO - 2024-10-13 02:39:02 --> Router Class Initialized
INFO - 2024-10-13 02:39:02 --> Output Class Initialized
INFO - 2024-10-13 02:39:02 --> Security Class Initialized
DEBUG - 2024-10-13 02:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 02:39:02 --> Input Class Initialized
INFO - 2024-10-13 02:39:02 --> Language Class Initialized
INFO - 2024-10-13 02:39:02 --> Language Class Initialized
INFO - 2024-10-13 02:39:02 --> Config Class Initialized
INFO - 2024-10-13 02:39:02 --> Loader Class Initialized
INFO - 2024-10-13 02:39:02 --> Helper loaded: url_helper
INFO - 2024-10-13 02:39:02 --> Helper loaded: file_helper
INFO - 2024-10-13 02:39:02 --> Helper loaded: form_helper
INFO - 2024-10-13 02:39:02 --> Helper loaded: my_helper
INFO - 2024-10-13 02:39:02 --> Database Driver Class Initialized
INFO - 2024-10-13 02:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-13 02:39:03 --> Controller Class Initialized
ERROR - 2024-10-13 02:39:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-13 02:39:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-13 02:39:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-13 02:39:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-13 02:39:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-13 02:39:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-13 02:39:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-13 02:39:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-13 02:39:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-13 02:39:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-13 02:39:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-13 02:39:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-13 02:39:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-13 02:39:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-13 02:39:07 --> Final output sent to browser
DEBUG - 2024-10-13 02:39:07 --> Total execution time: 5.1674
INFO - 2024-10-13 02:39:17 --> Config Class Initialized
INFO - 2024-10-13 02:39:17 --> Hooks Class Initialized
DEBUG - 2024-10-13 02:39:17 --> UTF-8 Support Enabled
INFO - 2024-10-13 02:39:17 --> Utf8 Class Initialized
INFO - 2024-10-13 02:39:17 --> URI Class Initialized
INFO - 2024-10-13 02:39:17 --> Router Class Initialized
INFO - 2024-10-13 02:39:17 --> Output Class Initialized
INFO - 2024-10-13 02:39:17 --> Security Class Initialized
DEBUG - 2024-10-13 02:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 02:39:17 --> Input Class Initialized
INFO - 2024-10-13 02:39:17 --> Language Class Initialized
INFO - 2024-10-13 02:39:17 --> Language Class Initialized
INFO - 2024-10-13 02:39:17 --> Config Class Initialized
INFO - 2024-10-13 02:39:17 --> Loader Class Initialized
INFO - 2024-10-13 02:39:17 --> Helper loaded: url_helper
INFO - 2024-10-13 02:39:17 --> Helper loaded: file_helper
INFO - 2024-10-13 02:39:17 --> Helper loaded: form_helper
INFO - 2024-10-13 02:39:17 --> Helper loaded: my_helper
INFO - 2024-10-13 02:39:17 --> Database Driver Class Initialized
INFO - 2024-10-13 02:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-13 02:39:17 --> Controller Class Initialized
ERROR - 2024-10-13 02:39:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-10-13 02:39:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-10-13 02:39:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-10-13 02:39:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-10-13 02:39:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-10-13 02:39:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-10-13 02:39:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-10-13 02:39:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-10-13 02:39:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-10-13 02:39:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-10-13 02:39:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-10-13 02:39:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-10-13 02:39:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-10-13 02:39:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-10-13 02:39:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-10-13 02:39:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-10-13 02:39:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-10-13 02:39:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-10-13 02:39:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-10-13 02:39:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-10-13 02:39:20 --> Final output sent to browser
DEBUG - 2024-10-13 02:39:20 --> Total execution time: 3.2848
INFO - 2024-10-13 02:39:24 --> Config Class Initialized
INFO - 2024-10-13 02:39:24 --> Hooks Class Initialized
DEBUG - 2024-10-13 02:39:24 --> UTF-8 Support Enabled
INFO - 2024-10-13 02:39:24 --> Utf8 Class Initialized
INFO - 2024-10-13 02:39:24 --> URI Class Initialized
INFO - 2024-10-13 02:39:24 --> Router Class Initialized
INFO - 2024-10-13 02:39:24 --> Output Class Initialized
INFO - 2024-10-13 02:39:24 --> Security Class Initialized
DEBUG - 2024-10-13 02:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 02:39:24 --> Input Class Initialized
INFO - 2024-10-13 02:39:24 --> Language Class Initialized
INFO - 2024-10-13 02:39:24 --> Language Class Initialized
INFO - 2024-10-13 02:39:24 --> Config Class Initialized
INFO - 2024-10-13 02:39:24 --> Loader Class Initialized
INFO - 2024-10-13 02:39:24 --> Helper loaded: url_helper
INFO - 2024-10-13 02:39:24 --> Helper loaded: file_helper
INFO - 2024-10-13 02:39:24 --> Helper loaded: form_helper
INFO - 2024-10-13 02:39:24 --> Helper loaded: my_helper
INFO - 2024-10-13 02:39:24 --> Database Driver Class Initialized
INFO - 2024-10-13 02:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-13 02:39:24 --> Controller Class Initialized
ERROR - 2024-10-13 02:39:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2591
ERROR - 2024-10-13 02:39:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3156
ERROR - 2024-10-13 02:39:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3194
ERROR - 2024-10-13 02:39:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3232
ERROR - 2024-10-13 02:39:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3271
ERROR - 2024-10-13 02:39:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3388
ERROR - 2024-10-13 02:39:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3507
ERROR - 2024-10-13 02:39:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3626
ERROR - 2024-10-13 02:39:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3745
ERROR - 2024-10-13 02:39:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-10-13 02:39:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-10-13 02:39:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 40
ERROR - 2024-10-13 02:39:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-10-13 02:39:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-10-13 02:39:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
ERROR - 2024-10-13 02:39:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
DEBUG - 2024-10-13 02:39:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-10-13 08:03:18 --> Config Class Initialized
INFO - 2024-10-13 08:03:18 --> Hooks Class Initialized
DEBUG - 2024-10-13 08:03:18 --> UTF-8 Support Enabled
INFO - 2024-10-13 08:03:18 --> Utf8 Class Initialized
INFO - 2024-10-13 08:03:18 --> URI Class Initialized
INFO - 2024-10-13 08:03:18 --> Router Class Initialized
INFO - 2024-10-13 08:03:18 --> Output Class Initialized
INFO - 2024-10-13 08:03:19 --> Security Class Initialized
DEBUG - 2024-10-13 08:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 08:03:19 --> Input Class Initialized
INFO - 2024-10-13 08:03:19 --> Language Class Initialized
INFO - 2024-10-13 08:03:19 --> Language Class Initialized
INFO - 2024-10-13 08:03:19 --> Config Class Initialized
INFO - 2024-10-13 08:03:19 --> Loader Class Initialized
INFO - 2024-10-13 08:03:19 --> Helper loaded: url_helper
INFO - 2024-10-13 08:03:19 --> Helper loaded: file_helper
INFO - 2024-10-13 08:03:19 --> Helper loaded: form_helper
INFO - 2024-10-13 08:03:19 --> Helper loaded: my_helper
INFO - 2024-10-13 08:03:19 --> Database Driver Class Initialized
INFO - 2024-10-13 08:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-13 08:03:19 --> Controller Class Initialized
INFO - 2024-10-13 08:03:19 --> Helper loaded: cookie_helper
INFO - 2024-10-13 08:03:19 --> Final output sent to browser
DEBUG - 2024-10-13 08:03:19 --> Total execution time: 0.0640
INFO - 2024-10-13 08:03:19 --> Config Class Initialized
INFO - 2024-10-13 08:03:19 --> Hooks Class Initialized
DEBUG - 2024-10-13 08:03:19 --> UTF-8 Support Enabled
INFO - 2024-10-13 08:03:19 --> Utf8 Class Initialized
INFO - 2024-10-13 08:03:19 --> URI Class Initialized
INFO - 2024-10-13 08:03:19 --> Router Class Initialized
INFO - 2024-10-13 08:03:19 --> Output Class Initialized
INFO - 2024-10-13 08:03:19 --> Security Class Initialized
DEBUG - 2024-10-13 08:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 08:03:19 --> Input Class Initialized
INFO - 2024-10-13 08:03:19 --> Language Class Initialized
INFO - 2024-10-13 08:03:19 --> Language Class Initialized
INFO - 2024-10-13 08:03:19 --> Config Class Initialized
INFO - 2024-10-13 08:03:19 --> Loader Class Initialized
INFO - 2024-10-13 08:03:19 --> Helper loaded: url_helper
INFO - 2024-10-13 08:03:19 --> Helper loaded: file_helper
INFO - 2024-10-13 08:03:19 --> Helper loaded: form_helper
INFO - 2024-10-13 08:03:19 --> Helper loaded: my_helper
INFO - 2024-10-13 08:03:19 --> Database Driver Class Initialized
INFO - 2024-10-13 08:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-13 08:03:19 --> Controller Class Initialized
INFO - 2024-10-13 08:03:20 --> Helper loaded: cookie_helper
INFO - 2024-10-13 08:03:20 --> Config Class Initialized
INFO - 2024-10-13 08:03:20 --> Hooks Class Initialized
DEBUG - 2024-10-13 08:03:20 --> UTF-8 Support Enabled
INFO - 2024-10-13 08:03:20 --> Utf8 Class Initialized
INFO - 2024-10-13 08:03:20 --> URI Class Initialized
INFO - 2024-10-13 08:03:20 --> Router Class Initialized
INFO - 2024-10-13 08:03:20 --> Output Class Initialized
INFO - 2024-10-13 08:03:20 --> Security Class Initialized
DEBUG - 2024-10-13 08:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 08:03:20 --> Input Class Initialized
INFO - 2024-10-13 08:03:20 --> Language Class Initialized
INFO - 2024-10-13 08:03:20 --> Language Class Initialized
INFO - 2024-10-13 08:03:20 --> Config Class Initialized
INFO - 2024-10-13 08:03:20 --> Loader Class Initialized
INFO - 2024-10-13 08:03:20 --> Helper loaded: url_helper
INFO - 2024-10-13 08:03:20 --> Helper loaded: file_helper
INFO - 2024-10-13 08:03:20 --> Helper loaded: form_helper
INFO - 2024-10-13 08:03:20 --> Helper loaded: my_helper
INFO - 2024-10-13 08:03:20 --> Database Driver Class Initialized
INFO - 2024-10-13 08:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-13 08:03:20 --> Controller Class Initialized
DEBUG - 2024-10-13 08:03:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-13 08:03:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-13 08:03:20 --> Final output sent to browser
DEBUG - 2024-10-13 08:03:20 --> Total execution time: 0.0399
INFO - 2024-10-13 08:03:46 --> Config Class Initialized
INFO - 2024-10-13 08:03:46 --> Hooks Class Initialized
DEBUG - 2024-10-13 08:03:46 --> UTF-8 Support Enabled
INFO - 2024-10-13 08:03:46 --> Utf8 Class Initialized
INFO - 2024-10-13 08:03:46 --> URI Class Initialized
INFO - 2024-10-13 08:03:46 --> Router Class Initialized
INFO - 2024-10-13 08:03:46 --> Output Class Initialized
INFO - 2024-10-13 08:03:46 --> Security Class Initialized
DEBUG - 2024-10-13 08:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 08:03:46 --> Input Class Initialized
INFO - 2024-10-13 08:03:46 --> Language Class Initialized
INFO - 2024-10-13 08:03:46 --> Language Class Initialized
INFO - 2024-10-13 08:03:46 --> Config Class Initialized
INFO - 2024-10-13 08:03:46 --> Loader Class Initialized
INFO - 2024-10-13 08:03:46 --> Helper loaded: url_helper
INFO - 2024-10-13 08:03:46 --> Helper loaded: file_helper
INFO - 2024-10-13 08:03:46 --> Helper loaded: form_helper
INFO - 2024-10-13 08:03:46 --> Helper loaded: my_helper
INFO - 2024-10-13 08:03:46 --> Database Driver Class Initialized
INFO - 2024-10-13 08:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-13 08:03:46 --> Controller Class Initialized
DEBUG - 2024-10-13 08:03:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-13 08:03:50 --> Final output sent to browser
DEBUG - 2024-10-13 08:03:50 --> Total execution time: 3.4102
INFO - 2024-10-13 13:48:56 --> Config Class Initialized
INFO - 2024-10-13 13:48:56 --> Hooks Class Initialized
DEBUG - 2024-10-13 13:48:56 --> UTF-8 Support Enabled
INFO - 2024-10-13 13:48:56 --> Utf8 Class Initialized
INFO - 2024-10-13 13:48:56 --> URI Class Initialized
INFO - 2024-10-13 13:48:56 --> Router Class Initialized
INFO - 2024-10-13 13:48:56 --> Output Class Initialized
INFO - 2024-10-13 13:48:56 --> Security Class Initialized
DEBUG - 2024-10-13 13:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 13:48:56 --> Input Class Initialized
INFO - 2024-10-13 13:48:56 --> Language Class Initialized
INFO - 2024-10-13 13:48:56 --> Language Class Initialized
INFO - 2024-10-13 13:48:56 --> Config Class Initialized
INFO - 2024-10-13 13:48:56 --> Loader Class Initialized
INFO - 2024-10-13 13:48:56 --> Helper loaded: url_helper
INFO - 2024-10-13 13:48:56 --> Helper loaded: file_helper
INFO - 2024-10-13 13:48:56 --> Helper loaded: form_helper
INFO - 2024-10-13 13:48:56 --> Helper loaded: my_helper
INFO - 2024-10-13 13:48:56 --> Database Driver Class Initialized
INFO - 2024-10-13 13:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-13 13:48:56 --> Controller Class Initialized
INFO - 2024-10-13 13:48:56 --> Helper loaded: cookie_helper
INFO - 2024-10-13 13:48:56 --> Final output sent to browser
DEBUG - 2024-10-13 13:48:56 --> Total execution time: 0.0650
INFO - 2024-10-13 13:48:57 --> Config Class Initialized
INFO - 2024-10-13 13:48:57 --> Hooks Class Initialized
DEBUG - 2024-10-13 13:48:57 --> UTF-8 Support Enabled
INFO - 2024-10-13 13:48:57 --> Utf8 Class Initialized
INFO - 2024-10-13 13:48:57 --> URI Class Initialized
INFO - 2024-10-13 13:48:57 --> Router Class Initialized
INFO - 2024-10-13 13:48:57 --> Output Class Initialized
INFO - 2024-10-13 13:48:57 --> Security Class Initialized
DEBUG - 2024-10-13 13:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 13:48:57 --> Input Class Initialized
INFO - 2024-10-13 13:48:57 --> Language Class Initialized
INFO - 2024-10-13 13:48:57 --> Language Class Initialized
INFO - 2024-10-13 13:48:57 --> Config Class Initialized
INFO - 2024-10-13 13:48:57 --> Loader Class Initialized
INFO - 2024-10-13 13:48:57 --> Helper loaded: url_helper
INFO - 2024-10-13 13:48:57 --> Helper loaded: file_helper
INFO - 2024-10-13 13:48:57 --> Helper loaded: form_helper
INFO - 2024-10-13 13:48:57 --> Helper loaded: my_helper
INFO - 2024-10-13 13:48:57 --> Database Driver Class Initialized
INFO - 2024-10-13 13:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-13 13:48:57 --> Controller Class Initialized
INFO - 2024-10-13 13:48:57 --> Helper loaded: cookie_helper
INFO - 2024-10-13 13:48:57 --> Config Class Initialized
INFO - 2024-10-13 13:48:57 --> Hooks Class Initialized
DEBUG - 2024-10-13 13:48:57 --> UTF-8 Support Enabled
INFO - 2024-10-13 13:48:57 --> Utf8 Class Initialized
INFO - 2024-10-13 13:48:57 --> URI Class Initialized
INFO - 2024-10-13 13:48:57 --> Router Class Initialized
INFO - 2024-10-13 13:48:57 --> Output Class Initialized
INFO - 2024-10-13 13:48:57 --> Security Class Initialized
DEBUG - 2024-10-13 13:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 13:48:57 --> Input Class Initialized
INFO - 2024-10-13 13:48:57 --> Language Class Initialized
INFO - 2024-10-13 13:48:57 --> Language Class Initialized
INFO - 2024-10-13 13:48:57 --> Config Class Initialized
INFO - 2024-10-13 13:48:57 --> Loader Class Initialized
INFO - 2024-10-13 13:48:57 --> Helper loaded: url_helper
INFO - 2024-10-13 13:48:57 --> Helper loaded: file_helper
INFO - 2024-10-13 13:48:57 --> Helper loaded: form_helper
INFO - 2024-10-13 13:48:57 --> Helper loaded: my_helper
INFO - 2024-10-13 13:48:57 --> Database Driver Class Initialized
INFO - 2024-10-13 13:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-13 13:48:57 --> Controller Class Initialized
DEBUG - 2024-10-13 13:48:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-13 13:48:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-13 13:48:57 --> Final output sent to browser
DEBUG - 2024-10-13 13:48:57 --> Total execution time: 0.0397
INFO - 2024-10-13 13:49:00 --> Config Class Initialized
INFO - 2024-10-13 13:49:00 --> Hooks Class Initialized
DEBUG - 2024-10-13 13:49:00 --> UTF-8 Support Enabled
INFO - 2024-10-13 13:49:00 --> Utf8 Class Initialized
INFO - 2024-10-13 13:49:00 --> URI Class Initialized
INFO - 2024-10-13 13:49:00 --> Router Class Initialized
INFO - 2024-10-13 13:49:00 --> Output Class Initialized
INFO - 2024-10-13 13:49:00 --> Security Class Initialized
DEBUG - 2024-10-13 13:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 13:49:00 --> Input Class Initialized
INFO - 2024-10-13 13:49:00 --> Language Class Initialized
INFO - 2024-10-13 13:49:00 --> Language Class Initialized
INFO - 2024-10-13 13:49:00 --> Config Class Initialized
INFO - 2024-10-13 13:49:00 --> Loader Class Initialized
INFO - 2024-10-13 13:49:00 --> Helper loaded: url_helper
INFO - 2024-10-13 13:49:00 --> Helper loaded: file_helper
INFO - 2024-10-13 13:49:00 --> Helper loaded: form_helper
INFO - 2024-10-13 13:49:00 --> Helper loaded: my_helper
INFO - 2024-10-13 13:49:00 --> Database Driver Class Initialized
INFO - 2024-10-13 13:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-13 13:49:00 --> Controller Class Initialized
ERROR - 2024-10-13 13:49:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-13 13:49:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-13 13:49:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-13 13:49:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-13 13:49:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-13 13:49:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-13 13:49:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-13 13:49:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-13 13:49:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-13 13:49:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-13 13:49:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-13 13:49:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-13 13:49:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-13 13:49:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-13 13:49:03 --> Final output sent to browser
DEBUG - 2024-10-13 13:49:03 --> Total execution time: 3.8382
INFO - 2024-10-13 23:23:28 --> Config Class Initialized
INFO - 2024-10-13 23:23:28 --> Hooks Class Initialized
DEBUG - 2024-10-13 23:23:28 --> UTF-8 Support Enabled
INFO - 2024-10-13 23:23:28 --> Utf8 Class Initialized
INFO - 2024-10-13 23:23:28 --> URI Class Initialized
INFO - 2024-10-13 23:23:28 --> Router Class Initialized
INFO - 2024-10-13 23:23:28 --> Output Class Initialized
INFO - 2024-10-13 23:23:28 --> Security Class Initialized
DEBUG - 2024-10-13 23:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 23:23:28 --> Input Class Initialized
INFO - 2024-10-13 23:23:28 --> Language Class Initialized
INFO - 2024-10-13 23:23:28 --> Language Class Initialized
INFO - 2024-10-13 23:23:28 --> Config Class Initialized
INFO - 2024-10-13 23:23:28 --> Loader Class Initialized
INFO - 2024-10-13 23:23:28 --> Helper loaded: url_helper
INFO - 2024-10-13 23:23:28 --> Helper loaded: file_helper
INFO - 2024-10-13 23:23:28 --> Helper loaded: form_helper
INFO - 2024-10-13 23:23:28 --> Helper loaded: my_helper
INFO - 2024-10-13 23:23:28 --> Database Driver Class Initialized
INFO - 2024-10-13 23:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-13 23:23:28 --> Controller Class Initialized
INFO - 2024-10-13 23:23:28 --> Helper loaded: cookie_helper
INFO - 2024-10-13 23:23:28 --> Final output sent to browser
DEBUG - 2024-10-13 23:23:28 --> Total execution time: 0.0729
INFO - 2024-10-13 23:23:28 --> Config Class Initialized
INFO - 2024-10-13 23:23:28 --> Hooks Class Initialized
DEBUG - 2024-10-13 23:23:28 --> UTF-8 Support Enabled
INFO - 2024-10-13 23:23:28 --> Utf8 Class Initialized
INFO - 2024-10-13 23:23:28 --> URI Class Initialized
INFO - 2024-10-13 23:23:28 --> Router Class Initialized
INFO - 2024-10-13 23:23:28 --> Output Class Initialized
INFO - 2024-10-13 23:23:28 --> Security Class Initialized
DEBUG - 2024-10-13 23:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 23:23:28 --> Input Class Initialized
INFO - 2024-10-13 23:23:28 --> Language Class Initialized
INFO - 2024-10-13 23:23:28 --> Language Class Initialized
INFO - 2024-10-13 23:23:28 --> Config Class Initialized
INFO - 2024-10-13 23:23:28 --> Loader Class Initialized
INFO - 2024-10-13 23:23:28 --> Helper loaded: url_helper
INFO - 2024-10-13 23:23:28 --> Helper loaded: file_helper
INFO - 2024-10-13 23:23:28 --> Helper loaded: form_helper
INFO - 2024-10-13 23:23:28 --> Helper loaded: my_helper
INFO - 2024-10-13 23:23:28 --> Database Driver Class Initialized
INFO - 2024-10-13 23:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-13 23:23:28 --> Controller Class Initialized
INFO - 2024-10-13 23:23:28 --> Helper loaded: cookie_helper
INFO - 2024-10-13 23:23:28 --> Config Class Initialized
INFO - 2024-10-13 23:23:28 --> Hooks Class Initialized
DEBUG - 2024-10-13 23:23:28 --> UTF-8 Support Enabled
INFO - 2024-10-13 23:23:28 --> Utf8 Class Initialized
INFO - 2024-10-13 23:23:28 --> URI Class Initialized
INFO - 2024-10-13 23:23:28 --> Router Class Initialized
INFO - 2024-10-13 23:23:28 --> Output Class Initialized
INFO - 2024-10-13 23:23:28 --> Security Class Initialized
DEBUG - 2024-10-13 23:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 23:23:28 --> Input Class Initialized
INFO - 2024-10-13 23:23:28 --> Language Class Initialized
INFO - 2024-10-13 23:23:28 --> Language Class Initialized
INFO - 2024-10-13 23:23:28 --> Config Class Initialized
INFO - 2024-10-13 23:23:28 --> Loader Class Initialized
INFO - 2024-10-13 23:23:28 --> Helper loaded: url_helper
INFO - 2024-10-13 23:23:28 --> Helper loaded: file_helper
INFO - 2024-10-13 23:23:28 --> Helper loaded: form_helper
INFO - 2024-10-13 23:23:28 --> Helper loaded: my_helper
INFO - 2024-10-13 23:23:28 --> Database Driver Class Initialized
INFO - 2024-10-13 23:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-13 23:23:28 --> Controller Class Initialized
DEBUG - 2024-10-13 23:23:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-13 23:23:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-13 23:23:28 --> Final output sent to browser
DEBUG - 2024-10-13 23:23:28 --> Total execution time: 0.0508
INFO - 2024-10-13 23:23:37 --> Config Class Initialized
INFO - 2024-10-13 23:23:37 --> Hooks Class Initialized
DEBUG - 2024-10-13 23:23:37 --> UTF-8 Support Enabled
INFO - 2024-10-13 23:23:37 --> Utf8 Class Initialized
INFO - 2024-10-13 23:23:37 --> URI Class Initialized
INFO - 2024-10-13 23:23:37 --> Router Class Initialized
INFO - 2024-10-13 23:23:37 --> Output Class Initialized
INFO - 2024-10-13 23:23:37 --> Security Class Initialized
DEBUG - 2024-10-13 23:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 23:23:37 --> Input Class Initialized
INFO - 2024-10-13 23:23:37 --> Language Class Initialized
INFO - 2024-10-13 23:23:37 --> Language Class Initialized
INFO - 2024-10-13 23:23:37 --> Config Class Initialized
INFO - 2024-10-13 23:23:37 --> Loader Class Initialized
INFO - 2024-10-13 23:23:37 --> Helper loaded: url_helper
INFO - 2024-10-13 23:23:37 --> Helper loaded: file_helper
INFO - 2024-10-13 23:23:37 --> Helper loaded: form_helper
INFO - 2024-10-13 23:23:37 --> Helper loaded: my_helper
INFO - 2024-10-13 23:23:37 --> Database Driver Class Initialized
INFO - 2024-10-13 23:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-13 23:23:37 --> Controller Class Initialized
DEBUG - 2024-10-13 23:23:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-13 23:23:40 --> Final output sent to browser
DEBUG - 2024-10-13 23:23:40 --> Total execution time: 3.0731
