<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-04 08:47:18 --> Config Class Initialized
INFO - 2024-11-04 08:47:18 --> Hooks Class Initialized
DEBUG - 2024-11-04 08:47:18 --> UTF-8 Support Enabled
INFO - 2024-11-04 08:47:18 --> Utf8 Class Initialized
INFO - 2024-11-04 08:47:18 --> URI Class Initialized
INFO - 2024-11-04 08:47:18 --> Router Class Initialized
INFO - 2024-11-04 08:47:18 --> Output Class Initialized
INFO - 2024-11-04 08:47:18 --> Security Class Initialized
DEBUG - 2024-11-04 08:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 08:47:18 --> Input Class Initialized
INFO - 2024-11-04 08:47:18 --> Language Class Initialized
INFO - 2024-11-04 08:47:18 --> Language Class Initialized
INFO - 2024-11-04 08:47:18 --> Config Class Initialized
INFO - 2024-11-04 08:47:18 --> Loader Class Initialized
INFO - 2024-11-04 08:47:18 --> Helper loaded: url_helper
INFO - 2024-11-04 08:47:18 --> Helper loaded: file_helper
INFO - 2024-11-04 08:47:18 --> Helper loaded: form_helper
INFO - 2024-11-04 08:47:18 --> Helper loaded: my_helper
INFO - 2024-11-04 08:47:18 --> Database Driver Class Initialized
INFO - 2024-11-04 08:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-04 08:47:18 --> Controller Class Initialized
INFO - 2024-11-04 08:47:18 --> Helper loaded: cookie_helper
INFO - 2024-11-04 08:47:18 --> Final output sent to browser
DEBUG - 2024-11-04 08:47:18 --> Total execution time: 0.0711
INFO - 2024-11-04 08:47:19 --> Config Class Initialized
INFO - 2024-11-04 08:47:19 --> Hooks Class Initialized
DEBUG - 2024-11-04 08:47:19 --> UTF-8 Support Enabled
INFO - 2024-11-04 08:47:19 --> Utf8 Class Initialized
INFO - 2024-11-04 08:47:19 --> URI Class Initialized
INFO - 2024-11-04 08:47:19 --> Router Class Initialized
INFO - 2024-11-04 08:47:19 --> Output Class Initialized
INFO - 2024-11-04 08:47:19 --> Security Class Initialized
DEBUG - 2024-11-04 08:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 08:47:19 --> Input Class Initialized
INFO - 2024-11-04 08:47:19 --> Language Class Initialized
INFO - 2024-11-04 08:47:19 --> Language Class Initialized
INFO - 2024-11-04 08:47:19 --> Config Class Initialized
INFO - 2024-11-04 08:47:19 --> Loader Class Initialized
INFO - 2024-11-04 08:47:19 --> Helper loaded: url_helper
INFO - 2024-11-04 08:47:19 --> Helper loaded: file_helper
INFO - 2024-11-04 08:47:19 --> Helper loaded: form_helper
INFO - 2024-11-04 08:47:19 --> Helper loaded: my_helper
INFO - 2024-11-04 08:47:19 --> Database Driver Class Initialized
INFO - 2024-11-04 08:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-04 08:47:19 --> Controller Class Initialized
INFO - 2024-11-04 08:47:19 --> Helper loaded: cookie_helper
INFO - 2024-11-04 08:47:19 --> Config Class Initialized
INFO - 2024-11-04 08:47:19 --> Hooks Class Initialized
DEBUG - 2024-11-04 08:47:19 --> UTF-8 Support Enabled
INFO - 2024-11-04 08:47:19 --> Utf8 Class Initialized
INFO - 2024-11-04 08:47:19 --> URI Class Initialized
INFO - 2024-11-04 08:47:19 --> Router Class Initialized
INFO - 2024-11-04 08:47:19 --> Output Class Initialized
INFO - 2024-11-04 08:47:19 --> Security Class Initialized
DEBUG - 2024-11-04 08:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 08:47:19 --> Input Class Initialized
INFO - 2024-11-04 08:47:19 --> Language Class Initialized
INFO - 2024-11-04 08:47:19 --> Language Class Initialized
INFO - 2024-11-04 08:47:19 --> Config Class Initialized
INFO - 2024-11-04 08:47:19 --> Loader Class Initialized
INFO - 2024-11-04 08:47:19 --> Helper loaded: url_helper
INFO - 2024-11-04 08:47:19 --> Helper loaded: file_helper
INFO - 2024-11-04 08:47:19 --> Helper loaded: form_helper
INFO - 2024-11-04 08:47:19 --> Helper loaded: my_helper
INFO - 2024-11-04 08:47:19 --> Database Driver Class Initialized
INFO - 2024-11-04 08:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-04 08:47:19 --> Controller Class Initialized
DEBUG - 2024-11-04 08:47:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-11-04 08:47:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-04 08:47:19 --> Final output sent to browser
DEBUG - 2024-11-04 08:47:19 --> Total execution time: 0.0377
INFO - 2024-11-04 08:47:23 --> Config Class Initialized
INFO - 2024-11-04 08:47:23 --> Hooks Class Initialized
DEBUG - 2024-11-04 08:47:23 --> UTF-8 Support Enabled
INFO - 2024-11-04 08:47:23 --> Utf8 Class Initialized
INFO - 2024-11-04 08:47:23 --> URI Class Initialized
INFO - 2024-11-04 08:47:23 --> Router Class Initialized
INFO - 2024-11-04 08:47:23 --> Output Class Initialized
INFO - 2024-11-04 08:47:23 --> Security Class Initialized
DEBUG - 2024-11-04 08:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 08:47:23 --> Input Class Initialized
INFO - 2024-11-04 08:47:23 --> Language Class Initialized
INFO - 2024-11-04 08:47:23 --> Language Class Initialized
INFO - 2024-11-04 08:47:23 --> Config Class Initialized
INFO - 2024-11-04 08:47:23 --> Loader Class Initialized
INFO - 2024-11-04 08:47:23 --> Helper loaded: url_helper
INFO - 2024-11-04 08:47:23 --> Helper loaded: file_helper
INFO - 2024-11-04 08:47:23 --> Helper loaded: form_helper
INFO - 2024-11-04 08:47:23 --> Helper loaded: my_helper
INFO - 2024-11-04 08:47:23 --> Database Driver Class Initialized
INFO - 2024-11-04 08:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-04 08:47:23 --> Controller Class Initialized
DEBUG - 2024-11-04 08:47:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-04 08:47:26 --> Final output sent to browser
DEBUG - 2024-11-04 08:47:26 --> Total execution time: 2.8147
INFO - 2024-11-04 11:37:39 --> Config Class Initialized
INFO - 2024-11-04 11:37:39 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:37:39 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:37:39 --> Utf8 Class Initialized
INFO - 2024-11-04 11:37:39 --> URI Class Initialized
INFO - 2024-11-04 11:37:39 --> Router Class Initialized
INFO - 2024-11-04 11:37:39 --> Output Class Initialized
INFO - 2024-11-04 11:37:39 --> Security Class Initialized
DEBUG - 2024-11-04 11:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:37:39 --> Input Class Initialized
INFO - 2024-11-04 11:37:39 --> Language Class Initialized
INFO - 2024-11-04 11:37:39 --> Language Class Initialized
INFO - 2024-11-04 11:37:39 --> Config Class Initialized
INFO - 2024-11-04 11:37:39 --> Loader Class Initialized
INFO - 2024-11-04 11:37:39 --> Helper loaded: url_helper
INFO - 2024-11-04 11:37:39 --> Helper loaded: file_helper
INFO - 2024-11-04 11:37:39 --> Helper loaded: form_helper
INFO - 2024-11-04 11:37:39 --> Helper loaded: my_helper
INFO - 2024-11-04 11:37:39 --> Database Driver Class Initialized
INFO - 2024-11-04 11:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-04 11:37:39 --> Controller Class Initialized
INFO - 2024-11-04 11:37:39 --> Helper loaded: cookie_helper
INFO - 2024-11-04 11:37:39 --> Final output sent to browser
DEBUG - 2024-11-04 11:37:39 --> Total execution time: 0.3912
INFO - 2024-11-04 11:37:40 --> Config Class Initialized
INFO - 2024-11-04 11:37:40 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:37:40 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:37:40 --> Utf8 Class Initialized
INFO - 2024-11-04 11:37:40 --> URI Class Initialized
INFO - 2024-11-04 11:37:40 --> Router Class Initialized
INFO - 2024-11-04 11:37:40 --> Output Class Initialized
INFO - 2024-11-04 11:37:40 --> Security Class Initialized
DEBUG - 2024-11-04 11:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:37:40 --> Input Class Initialized
INFO - 2024-11-04 11:37:40 --> Language Class Initialized
INFO - 2024-11-04 11:37:40 --> Language Class Initialized
INFO - 2024-11-04 11:37:40 --> Config Class Initialized
INFO - 2024-11-04 11:37:40 --> Loader Class Initialized
INFO - 2024-11-04 11:37:40 --> Helper loaded: url_helper
INFO - 2024-11-04 11:37:40 --> Helper loaded: file_helper
INFO - 2024-11-04 11:37:40 --> Helper loaded: form_helper
INFO - 2024-11-04 11:37:40 --> Helper loaded: my_helper
INFO - 2024-11-04 11:37:40 --> Database Driver Class Initialized
INFO - 2024-11-04 11:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-04 11:37:40 --> Controller Class Initialized
INFO - 2024-11-04 11:37:40 --> Helper loaded: cookie_helper
INFO - 2024-11-04 11:37:40 --> Config Class Initialized
INFO - 2024-11-04 11:37:40 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:37:40 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:37:40 --> Utf8 Class Initialized
INFO - 2024-11-04 11:37:40 --> URI Class Initialized
INFO - 2024-11-04 11:37:40 --> Router Class Initialized
INFO - 2024-11-04 11:37:40 --> Output Class Initialized
INFO - 2024-11-04 11:37:40 --> Security Class Initialized
DEBUG - 2024-11-04 11:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:37:40 --> Input Class Initialized
INFO - 2024-11-04 11:37:40 --> Language Class Initialized
INFO - 2024-11-04 11:37:40 --> Language Class Initialized
INFO - 2024-11-04 11:37:40 --> Config Class Initialized
INFO - 2024-11-04 11:37:40 --> Loader Class Initialized
INFO - 2024-11-04 11:37:40 --> Helper loaded: url_helper
INFO - 2024-11-04 11:37:40 --> Helper loaded: file_helper
INFO - 2024-11-04 11:37:40 --> Helper loaded: form_helper
INFO - 2024-11-04 11:37:40 --> Helper loaded: my_helper
INFO - 2024-11-04 11:37:40 --> Database Driver Class Initialized
INFO - 2024-11-04 11:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-04 11:37:40 --> Controller Class Initialized
DEBUG - 2024-11-04 11:37:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-11-04 11:37:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-04 11:37:40 --> Final output sent to browser
DEBUG - 2024-11-04 11:37:40 --> Total execution time: 0.0404
INFO - 2024-11-04 11:39:45 --> Config Class Initialized
INFO - 2024-11-04 11:39:45 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:39:45 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:39:45 --> Utf8 Class Initialized
INFO - 2024-11-04 11:39:45 --> URI Class Initialized
INFO - 2024-11-04 11:39:45 --> Router Class Initialized
INFO - 2024-11-04 11:39:45 --> Output Class Initialized
INFO - 2024-11-04 11:39:45 --> Security Class Initialized
DEBUG - 2024-11-04 11:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:39:45 --> Input Class Initialized
INFO - 2024-11-04 11:39:45 --> Language Class Initialized
INFO - 2024-11-04 11:39:45 --> Language Class Initialized
INFO - 2024-11-04 11:39:45 --> Config Class Initialized
INFO - 2024-11-04 11:39:45 --> Loader Class Initialized
INFO - 2024-11-04 11:39:45 --> Helper loaded: url_helper
INFO - 2024-11-04 11:39:45 --> Helper loaded: file_helper
INFO - 2024-11-04 11:39:45 --> Helper loaded: form_helper
INFO - 2024-11-04 11:39:45 --> Helper loaded: my_helper
INFO - 2024-11-04 11:39:45 --> Database Driver Class Initialized
INFO - 2024-11-04 11:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-04 11:39:45 --> Controller Class Initialized
INFO - 2024-11-04 11:39:45 --> Helper loaded: cookie_helper
INFO - 2024-11-04 11:39:45 --> Final output sent to browser
DEBUG - 2024-11-04 11:39:45 --> Total execution time: 0.0362
INFO - 2024-11-04 11:39:45 --> Config Class Initialized
INFO - 2024-11-04 11:39:45 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:39:45 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:39:45 --> Utf8 Class Initialized
INFO - 2024-11-04 11:39:45 --> URI Class Initialized
INFO - 2024-11-04 11:39:45 --> Router Class Initialized
INFO - 2024-11-04 11:39:45 --> Output Class Initialized
INFO - 2024-11-04 11:39:45 --> Security Class Initialized
DEBUG - 2024-11-04 11:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:39:45 --> Input Class Initialized
INFO - 2024-11-04 11:39:45 --> Language Class Initialized
INFO - 2024-11-04 11:39:45 --> Language Class Initialized
INFO - 2024-11-04 11:39:45 --> Config Class Initialized
INFO - 2024-11-04 11:39:45 --> Loader Class Initialized
INFO - 2024-11-04 11:39:45 --> Helper loaded: url_helper
INFO - 2024-11-04 11:39:45 --> Helper loaded: file_helper
INFO - 2024-11-04 11:39:45 --> Helper loaded: form_helper
INFO - 2024-11-04 11:39:45 --> Helper loaded: my_helper
INFO - 2024-11-04 11:39:45 --> Database Driver Class Initialized
INFO - 2024-11-04 11:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-04 11:39:45 --> Controller Class Initialized
INFO - 2024-11-04 11:39:45 --> Helper loaded: cookie_helper
INFO - 2024-11-04 11:39:45 --> Config Class Initialized
INFO - 2024-11-04 11:39:45 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:39:45 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:39:45 --> Utf8 Class Initialized
INFO - 2024-11-04 11:39:45 --> URI Class Initialized
INFO - 2024-11-04 11:39:45 --> Router Class Initialized
INFO - 2024-11-04 11:39:45 --> Output Class Initialized
INFO - 2024-11-04 11:39:45 --> Security Class Initialized
DEBUG - 2024-11-04 11:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:39:45 --> Input Class Initialized
INFO - 2024-11-04 11:39:45 --> Language Class Initialized
INFO - 2024-11-04 11:39:45 --> Language Class Initialized
INFO - 2024-11-04 11:39:45 --> Config Class Initialized
INFO - 2024-11-04 11:39:45 --> Loader Class Initialized
INFO - 2024-11-04 11:39:45 --> Helper loaded: url_helper
INFO - 2024-11-04 11:39:45 --> Helper loaded: file_helper
INFO - 2024-11-04 11:39:45 --> Helper loaded: form_helper
INFO - 2024-11-04 11:39:45 --> Helper loaded: my_helper
INFO - 2024-11-04 11:39:45 --> Database Driver Class Initialized
INFO - 2024-11-04 11:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-04 11:39:45 --> Controller Class Initialized
DEBUG - 2024-11-04 11:39:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-11-04 11:39:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-04 11:39:45 --> Final output sent to browser
DEBUG - 2024-11-04 11:39:45 --> Total execution time: 0.0288
INFO - 2024-11-04 11:39:50 --> Config Class Initialized
INFO - 2024-11-04 11:39:50 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:39:50 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:39:50 --> Utf8 Class Initialized
INFO - 2024-11-04 11:39:50 --> URI Class Initialized
INFO - 2024-11-04 11:39:50 --> Router Class Initialized
INFO - 2024-11-04 11:39:50 --> Output Class Initialized
INFO - 2024-11-04 11:39:51 --> Security Class Initialized
DEBUG - 2024-11-04 11:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:39:51 --> Input Class Initialized
INFO - 2024-11-04 11:39:51 --> Language Class Initialized
INFO - 2024-11-04 11:39:51 --> Language Class Initialized
INFO - 2024-11-04 11:39:51 --> Config Class Initialized
INFO - 2024-11-04 11:39:51 --> Loader Class Initialized
INFO - 2024-11-04 11:39:51 --> Helper loaded: url_helper
INFO - 2024-11-04 11:39:51 --> Helper loaded: file_helper
INFO - 2024-11-04 11:39:51 --> Helper loaded: form_helper
INFO - 2024-11-04 11:39:51 --> Helper loaded: my_helper
INFO - 2024-11-04 11:39:51 --> Database Driver Class Initialized
INFO - 2024-11-04 11:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-04 11:39:51 --> Controller Class Initialized
DEBUG - 2024-11-04 11:39:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-04 11:39:54 --> Final output sent to browser
DEBUG - 2024-11-04 11:39:54 --> Total execution time: 3.0985
INFO - 2024-11-04 11:44:01 --> Config Class Initialized
INFO - 2024-11-04 11:44:01 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:44:01 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:44:01 --> Utf8 Class Initialized
INFO - 2024-11-04 11:44:01 --> URI Class Initialized
INFO - 2024-11-04 11:44:01 --> Router Class Initialized
INFO - 2024-11-04 11:44:01 --> Output Class Initialized
INFO - 2024-11-04 11:44:01 --> Security Class Initialized
DEBUG - 2024-11-04 11:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:44:01 --> Input Class Initialized
INFO - 2024-11-04 11:44:01 --> Language Class Initialized
INFO - 2024-11-04 11:44:01 --> Language Class Initialized
INFO - 2024-11-04 11:44:01 --> Config Class Initialized
INFO - 2024-11-04 11:44:01 --> Loader Class Initialized
INFO - 2024-11-04 11:44:01 --> Helper loaded: url_helper
INFO - 2024-11-04 11:44:01 --> Helper loaded: file_helper
INFO - 2024-11-04 11:44:01 --> Helper loaded: form_helper
INFO - 2024-11-04 11:44:01 --> Helper loaded: my_helper
INFO - 2024-11-04 11:44:01 --> Database Driver Class Initialized
INFO - 2024-11-04 11:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-04 11:44:01 --> Controller Class Initialized
INFO - 2024-11-04 11:44:01 --> Helper loaded: cookie_helper
INFO - 2024-11-04 11:44:02 --> Final output sent to browser
DEBUG - 2024-11-04 11:44:02 --> Total execution time: 0.1700
INFO - 2024-11-04 11:44:02 --> Config Class Initialized
INFO - 2024-11-04 11:44:02 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:44:02 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:44:02 --> Utf8 Class Initialized
INFO - 2024-11-04 11:44:02 --> URI Class Initialized
INFO - 2024-11-04 11:44:02 --> Router Class Initialized
INFO - 2024-11-04 11:44:02 --> Output Class Initialized
INFO - 2024-11-04 11:44:02 --> Security Class Initialized
DEBUG - 2024-11-04 11:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:44:02 --> Input Class Initialized
INFO - 2024-11-04 11:44:02 --> Language Class Initialized
INFO - 2024-11-04 11:44:02 --> Language Class Initialized
INFO - 2024-11-04 11:44:02 --> Config Class Initialized
INFO - 2024-11-04 11:44:02 --> Loader Class Initialized
INFO - 2024-11-04 11:44:02 --> Helper loaded: url_helper
INFO - 2024-11-04 11:44:02 --> Helper loaded: file_helper
INFO - 2024-11-04 11:44:02 --> Helper loaded: form_helper
INFO - 2024-11-04 11:44:02 --> Helper loaded: my_helper
INFO - 2024-11-04 11:44:02 --> Database Driver Class Initialized
INFO - 2024-11-04 11:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-04 11:44:02 --> Controller Class Initialized
INFO - 2024-11-04 11:44:02 --> Helper loaded: cookie_helper
INFO - 2024-11-04 11:44:02 --> Config Class Initialized
INFO - 2024-11-04 11:44:02 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:44:02 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:44:02 --> Utf8 Class Initialized
INFO - 2024-11-04 11:44:02 --> URI Class Initialized
INFO - 2024-11-04 11:44:02 --> Router Class Initialized
INFO - 2024-11-04 11:44:02 --> Output Class Initialized
INFO - 2024-11-04 11:44:02 --> Security Class Initialized
DEBUG - 2024-11-04 11:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:44:02 --> Input Class Initialized
INFO - 2024-11-04 11:44:02 --> Language Class Initialized
INFO - 2024-11-04 11:44:02 --> Language Class Initialized
INFO - 2024-11-04 11:44:02 --> Config Class Initialized
INFO - 2024-11-04 11:44:02 --> Loader Class Initialized
INFO - 2024-11-04 11:44:02 --> Helper loaded: url_helper
INFO - 2024-11-04 11:44:02 --> Helper loaded: file_helper
INFO - 2024-11-04 11:44:02 --> Helper loaded: form_helper
INFO - 2024-11-04 11:44:02 --> Helper loaded: my_helper
INFO - 2024-11-04 11:44:02 --> Database Driver Class Initialized
INFO - 2024-11-04 11:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-04 11:44:02 --> Controller Class Initialized
DEBUG - 2024-11-04 11:44:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-11-04 11:44:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-04 11:44:02 --> Final output sent to browser
DEBUG - 2024-11-04 11:44:02 --> Total execution time: 0.0388
