<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-31 08:01:34 --> Config Class Initialized
INFO - 2024-07-31 08:01:34 --> Hooks Class Initialized
DEBUG - 2024-07-31 08:01:34 --> UTF-8 Support Enabled
INFO - 2024-07-31 08:01:34 --> Utf8 Class Initialized
INFO - 2024-07-31 08:01:34 --> URI Class Initialized
INFO - 2024-07-31 08:01:34 --> Router Class Initialized
INFO - 2024-07-31 08:01:34 --> Output Class Initialized
INFO - 2024-07-31 08:01:34 --> Security Class Initialized
DEBUG - 2024-07-31 08:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-31 08:01:34 --> Input Class Initialized
INFO - 2024-07-31 08:01:34 --> Language Class Initialized
INFO - 2024-07-31 08:01:34 --> Language Class Initialized
INFO - 2024-07-31 08:01:34 --> Config Class Initialized
INFO - 2024-07-31 08:01:34 --> Loader Class Initialized
INFO - 2024-07-31 08:01:34 --> Helper loaded: url_helper
INFO - 2024-07-31 08:01:34 --> Helper loaded: file_helper
INFO - 2024-07-31 08:01:34 --> Helper loaded: form_helper
INFO - 2024-07-31 08:01:34 --> Helper loaded: my_helper
INFO - 2024-07-31 08:01:34 --> Database Driver Class Initialized
INFO - 2024-07-31 08:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-31 08:01:34 --> Controller Class Initialized
DEBUG - 2024-07-31 08:01:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-07-31 08:01:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-31 08:01:34 --> Final output sent to browser
DEBUG - 2024-07-31 08:01:34 --> Total execution time: 0.0995
INFO - 2024-07-31 22:55:10 --> Config Class Initialized
INFO - 2024-07-31 22:55:10 --> Hooks Class Initialized
DEBUG - 2024-07-31 22:55:10 --> UTF-8 Support Enabled
INFO - 2024-07-31 22:55:10 --> Utf8 Class Initialized
INFO - 2024-07-31 22:55:10 --> URI Class Initialized
INFO - 2024-07-31 22:55:10 --> Router Class Initialized
INFO - 2024-07-31 22:55:10 --> Output Class Initialized
INFO - 2024-07-31 22:55:10 --> Security Class Initialized
DEBUG - 2024-07-31 22:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-31 22:55:10 --> Input Class Initialized
INFO - 2024-07-31 22:55:10 --> Language Class Initialized
INFO - 2024-07-31 22:55:10 --> Language Class Initialized
INFO - 2024-07-31 22:55:10 --> Config Class Initialized
INFO - 2024-07-31 22:55:10 --> Loader Class Initialized
INFO - 2024-07-31 22:55:10 --> Helper loaded: url_helper
INFO - 2024-07-31 22:55:10 --> Helper loaded: file_helper
INFO - 2024-07-31 22:55:10 --> Helper loaded: form_helper
INFO - 2024-07-31 22:55:10 --> Helper loaded: my_helper
INFO - 2024-07-31 22:55:10 --> Database Driver Class Initialized
INFO - 2024-07-31 22:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-31 22:55:10 --> Controller Class Initialized
INFO - 2024-07-31 22:55:10 --> Config Class Initialized
INFO - 2024-07-31 22:55:10 --> Hooks Class Initialized
DEBUG - 2024-07-31 22:55:10 --> UTF-8 Support Enabled
INFO - 2024-07-31 22:55:10 --> Utf8 Class Initialized
INFO - 2024-07-31 22:55:10 --> URI Class Initialized
INFO - 2024-07-31 22:55:10 --> Router Class Initialized
INFO - 2024-07-31 22:55:10 --> Output Class Initialized
INFO - 2024-07-31 22:55:10 --> Security Class Initialized
DEBUG - 2024-07-31 22:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-31 22:55:10 --> Input Class Initialized
INFO - 2024-07-31 22:55:10 --> Language Class Initialized
INFO - 2024-07-31 22:55:10 --> Language Class Initialized
INFO - 2024-07-31 22:55:10 --> Config Class Initialized
INFO - 2024-07-31 22:55:10 --> Loader Class Initialized
INFO - 2024-07-31 22:55:10 --> Helper loaded: url_helper
INFO - 2024-07-31 22:55:10 --> Helper loaded: file_helper
INFO - 2024-07-31 22:55:10 --> Helper loaded: form_helper
INFO - 2024-07-31 22:55:10 --> Helper loaded: my_helper
INFO - 2024-07-31 22:55:10 --> Database Driver Class Initialized
INFO - 2024-07-31 22:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-31 22:55:10 --> Controller Class Initialized
DEBUG - 2024-07-31 22:55:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-07-31 22:55:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-31 22:55:10 --> Final output sent to browser
DEBUG - 2024-07-31 22:55:10 --> Total execution time: 0.0296
INFO - 2024-07-31 23:20:59 --> Config Class Initialized
INFO - 2024-07-31 23:20:59 --> Hooks Class Initialized
DEBUG - 2024-07-31 23:20:59 --> UTF-8 Support Enabled
INFO - 2024-07-31 23:20:59 --> Utf8 Class Initialized
INFO - 2024-07-31 23:20:59 --> URI Class Initialized
INFO - 2024-07-31 23:20:59 --> Router Class Initialized
INFO - 2024-07-31 23:20:59 --> Output Class Initialized
INFO - 2024-07-31 23:20:59 --> Security Class Initialized
DEBUG - 2024-07-31 23:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-31 23:20:59 --> Input Class Initialized
INFO - 2024-07-31 23:20:59 --> Language Class Initialized
INFO - 2024-07-31 23:20:59 --> Language Class Initialized
INFO - 2024-07-31 23:20:59 --> Config Class Initialized
INFO - 2024-07-31 23:20:59 --> Loader Class Initialized
INFO - 2024-07-31 23:20:59 --> Helper loaded: url_helper
INFO - 2024-07-31 23:20:59 --> Helper loaded: file_helper
INFO - 2024-07-31 23:20:59 --> Helper loaded: form_helper
INFO - 2024-07-31 23:20:59 --> Helper loaded: my_helper
INFO - 2024-07-31 23:20:59 --> Database Driver Class Initialized
INFO - 2024-07-31 23:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-31 23:20:59 --> Controller Class Initialized
