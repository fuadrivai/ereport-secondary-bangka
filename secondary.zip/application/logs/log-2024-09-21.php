<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-21 12:48:24 --> Config Class Initialized
INFO - 2024-09-21 12:48:24 --> Hooks Class Initialized
DEBUG - 2024-09-21 12:48:24 --> UTF-8 Support Enabled
INFO - 2024-09-21 12:48:24 --> Utf8 Class Initialized
INFO - 2024-09-21 12:48:24 --> URI Class Initialized
INFO - 2024-09-21 12:48:24 --> Router Class Initialized
INFO - 2024-09-21 12:48:24 --> Output Class Initialized
INFO - 2024-09-21 12:48:24 --> Security Class Initialized
DEBUG - 2024-09-21 12:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 12:48:24 --> Input Class Initialized
INFO - 2024-09-21 12:48:24 --> Language Class Initialized
INFO - 2024-09-21 12:48:24 --> Language Class Initialized
INFO - 2024-09-21 12:48:24 --> Config Class Initialized
INFO - 2024-09-21 12:48:24 --> Loader Class Initialized
INFO - 2024-09-21 12:48:24 --> Helper loaded: url_helper
INFO - 2024-09-21 12:48:24 --> Helper loaded: file_helper
INFO - 2024-09-21 12:48:24 --> Helper loaded: form_helper
INFO - 2024-09-21 12:48:24 --> Helper loaded: my_helper
INFO - 2024-09-21 12:48:24 --> Database Driver Class Initialized
INFO - 2024-09-21 12:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 12:48:24 --> Controller Class Initialized
INFO - 2024-09-21 12:48:24 --> Helper loaded: cookie_helper
INFO - 2024-09-21 12:48:24 --> Final output sent to browser
DEBUG - 2024-09-21 12:48:24 --> Total execution time: 0.0746
INFO - 2024-09-21 12:48:25 --> Config Class Initialized
INFO - 2024-09-21 12:48:25 --> Hooks Class Initialized
DEBUG - 2024-09-21 12:48:25 --> UTF-8 Support Enabled
INFO - 2024-09-21 12:48:25 --> Utf8 Class Initialized
INFO - 2024-09-21 12:48:25 --> URI Class Initialized
INFO - 2024-09-21 12:48:25 --> Router Class Initialized
INFO - 2024-09-21 12:48:25 --> Output Class Initialized
INFO - 2024-09-21 12:48:25 --> Security Class Initialized
DEBUG - 2024-09-21 12:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 12:48:25 --> Input Class Initialized
INFO - 2024-09-21 12:48:25 --> Language Class Initialized
INFO - 2024-09-21 12:48:25 --> Language Class Initialized
INFO - 2024-09-21 12:48:25 --> Config Class Initialized
INFO - 2024-09-21 12:48:25 --> Loader Class Initialized
INFO - 2024-09-21 12:48:25 --> Helper loaded: url_helper
INFO - 2024-09-21 12:48:25 --> Helper loaded: file_helper
INFO - 2024-09-21 12:48:25 --> Helper loaded: form_helper
INFO - 2024-09-21 12:48:25 --> Helper loaded: my_helper
INFO - 2024-09-21 12:48:25 --> Database Driver Class Initialized
INFO - 2024-09-21 12:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 12:48:25 --> Controller Class Initialized
INFO - 2024-09-21 12:48:25 --> Helper loaded: cookie_helper
INFO - 2024-09-21 12:48:25 --> Config Class Initialized
INFO - 2024-09-21 12:48:25 --> Hooks Class Initialized
DEBUG - 2024-09-21 12:48:25 --> UTF-8 Support Enabled
INFO - 2024-09-21 12:48:25 --> Utf8 Class Initialized
INFO - 2024-09-21 12:48:25 --> URI Class Initialized
INFO - 2024-09-21 12:48:25 --> Router Class Initialized
INFO - 2024-09-21 12:48:25 --> Output Class Initialized
INFO - 2024-09-21 12:48:25 --> Security Class Initialized
DEBUG - 2024-09-21 12:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 12:48:25 --> Input Class Initialized
INFO - 2024-09-21 12:48:25 --> Language Class Initialized
INFO - 2024-09-21 12:48:25 --> Language Class Initialized
INFO - 2024-09-21 12:48:25 --> Config Class Initialized
INFO - 2024-09-21 12:48:25 --> Loader Class Initialized
INFO - 2024-09-21 12:48:25 --> Helper loaded: url_helper
INFO - 2024-09-21 12:48:25 --> Helper loaded: file_helper
INFO - 2024-09-21 12:48:25 --> Helper loaded: form_helper
INFO - 2024-09-21 12:48:25 --> Helper loaded: my_helper
INFO - 2024-09-21 12:48:25 --> Database Driver Class Initialized
INFO - 2024-09-21 12:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 12:48:25 --> Controller Class Initialized
DEBUG - 2024-09-21 12:48:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-21 12:48:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-21 12:48:25 --> Final output sent to browser
DEBUG - 2024-09-21 12:48:25 --> Total execution time: 0.0361
INFO - 2024-09-21 12:48:57 --> Config Class Initialized
INFO - 2024-09-21 12:48:57 --> Hooks Class Initialized
DEBUG - 2024-09-21 12:48:57 --> UTF-8 Support Enabled
INFO - 2024-09-21 12:48:57 --> Utf8 Class Initialized
INFO - 2024-09-21 12:48:57 --> URI Class Initialized
INFO - 2024-09-21 12:48:57 --> Router Class Initialized
INFO - 2024-09-21 12:48:57 --> Output Class Initialized
INFO - 2024-09-21 12:48:57 --> Security Class Initialized
DEBUG - 2024-09-21 12:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 12:48:57 --> Input Class Initialized
INFO - 2024-09-21 12:48:57 --> Language Class Initialized
INFO - 2024-09-21 12:48:57 --> Language Class Initialized
INFO - 2024-09-21 12:48:57 --> Config Class Initialized
INFO - 2024-09-21 12:48:57 --> Loader Class Initialized
INFO - 2024-09-21 12:48:57 --> Helper loaded: url_helper
INFO - 2024-09-21 12:48:57 --> Helper loaded: file_helper
INFO - 2024-09-21 12:48:57 --> Helper loaded: form_helper
INFO - 2024-09-21 12:48:57 --> Helper loaded: my_helper
INFO - 2024-09-21 12:48:57 --> Database Driver Class Initialized
INFO - 2024-09-21 12:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 12:48:57 --> Controller Class Initialized
INFO - 2024-09-21 12:48:57 --> Helper loaded: cookie_helper
INFO - 2024-09-21 12:48:57 --> Final output sent to browser
DEBUG - 2024-09-21 12:48:57 --> Total execution time: 0.0325
INFO - 2024-09-21 12:48:57 --> Config Class Initialized
INFO - 2024-09-21 12:48:57 --> Hooks Class Initialized
DEBUG - 2024-09-21 12:48:57 --> UTF-8 Support Enabled
INFO - 2024-09-21 12:48:57 --> Utf8 Class Initialized
INFO - 2024-09-21 12:48:57 --> URI Class Initialized
INFO - 2024-09-21 12:48:57 --> Router Class Initialized
INFO - 2024-09-21 12:48:57 --> Output Class Initialized
INFO - 2024-09-21 12:48:57 --> Security Class Initialized
DEBUG - 2024-09-21 12:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 12:48:57 --> Input Class Initialized
INFO - 2024-09-21 12:48:57 --> Language Class Initialized
INFO - 2024-09-21 12:48:57 --> Language Class Initialized
INFO - 2024-09-21 12:48:57 --> Config Class Initialized
INFO - 2024-09-21 12:48:57 --> Loader Class Initialized
INFO - 2024-09-21 12:48:57 --> Helper loaded: url_helper
INFO - 2024-09-21 12:48:57 --> Helper loaded: file_helper
INFO - 2024-09-21 12:48:57 --> Helper loaded: form_helper
INFO - 2024-09-21 12:48:57 --> Helper loaded: my_helper
INFO - 2024-09-21 12:48:57 --> Database Driver Class Initialized
INFO - 2024-09-21 12:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 12:48:57 --> Controller Class Initialized
INFO - 2024-09-21 12:48:57 --> Helper loaded: cookie_helper
INFO - 2024-09-21 12:48:57 --> Config Class Initialized
INFO - 2024-09-21 12:48:57 --> Hooks Class Initialized
DEBUG - 2024-09-21 12:48:57 --> UTF-8 Support Enabled
INFO - 2024-09-21 12:48:57 --> Utf8 Class Initialized
INFO - 2024-09-21 12:48:57 --> URI Class Initialized
INFO - 2024-09-21 12:48:57 --> Router Class Initialized
INFO - 2024-09-21 12:48:57 --> Output Class Initialized
INFO - 2024-09-21 12:48:57 --> Security Class Initialized
DEBUG - 2024-09-21 12:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 12:48:57 --> Input Class Initialized
INFO - 2024-09-21 12:48:57 --> Language Class Initialized
INFO - 2024-09-21 12:48:57 --> Language Class Initialized
INFO - 2024-09-21 12:48:57 --> Config Class Initialized
INFO - 2024-09-21 12:48:57 --> Loader Class Initialized
INFO - 2024-09-21 12:48:57 --> Helper loaded: url_helper
INFO - 2024-09-21 12:48:57 --> Helper loaded: file_helper
INFO - 2024-09-21 12:48:57 --> Helper loaded: form_helper
INFO - 2024-09-21 12:48:57 --> Helper loaded: my_helper
INFO - 2024-09-21 12:48:57 --> Database Driver Class Initialized
INFO - 2024-09-21 12:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 12:48:57 --> Controller Class Initialized
DEBUG - 2024-09-21 12:48:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-21 12:48:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-21 12:48:57 --> Final output sent to browser
DEBUG - 2024-09-21 12:48:57 --> Total execution time: 0.0271
INFO - 2024-09-21 13:49:30 --> Config Class Initialized
INFO - 2024-09-21 13:49:30 --> Hooks Class Initialized
DEBUG - 2024-09-21 13:49:30 --> UTF-8 Support Enabled
INFO - 2024-09-21 13:49:30 --> Utf8 Class Initialized
INFO - 2024-09-21 13:49:30 --> URI Class Initialized
INFO - 2024-09-21 13:49:30 --> Router Class Initialized
INFO - 2024-09-21 13:49:30 --> Output Class Initialized
INFO - 2024-09-21 13:49:30 --> Security Class Initialized
DEBUG - 2024-09-21 13:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 13:49:30 --> Input Class Initialized
INFO - 2024-09-21 13:49:30 --> Language Class Initialized
INFO - 2024-09-21 13:49:30 --> Language Class Initialized
INFO - 2024-09-21 13:49:30 --> Config Class Initialized
INFO - 2024-09-21 13:49:30 --> Loader Class Initialized
INFO - 2024-09-21 13:49:30 --> Helper loaded: url_helper
INFO - 2024-09-21 13:49:30 --> Helper loaded: file_helper
INFO - 2024-09-21 13:49:30 --> Helper loaded: form_helper
INFO - 2024-09-21 13:49:30 --> Helper loaded: my_helper
INFO - 2024-09-21 13:49:30 --> Database Driver Class Initialized
INFO - 2024-09-21 13:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 13:49:30 --> Controller Class Initialized
INFO - 2024-09-21 13:49:30 --> Helper loaded: cookie_helper
INFO - 2024-09-21 13:49:30 --> Final output sent to browser
DEBUG - 2024-09-21 13:49:30 --> Total execution time: 0.0498
INFO - 2024-09-21 13:49:30 --> Config Class Initialized
INFO - 2024-09-21 13:49:30 --> Hooks Class Initialized
DEBUG - 2024-09-21 13:49:30 --> UTF-8 Support Enabled
INFO - 2024-09-21 13:49:30 --> Utf8 Class Initialized
INFO - 2024-09-21 13:49:30 --> URI Class Initialized
INFO - 2024-09-21 13:49:30 --> Router Class Initialized
INFO - 2024-09-21 13:49:30 --> Output Class Initialized
INFO - 2024-09-21 13:49:30 --> Security Class Initialized
DEBUG - 2024-09-21 13:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 13:49:30 --> Input Class Initialized
INFO - 2024-09-21 13:49:30 --> Language Class Initialized
INFO - 2024-09-21 13:49:30 --> Language Class Initialized
INFO - 2024-09-21 13:49:30 --> Config Class Initialized
INFO - 2024-09-21 13:49:30 --> Loader Class Initialized
INFO - 2024-09-21 13:49:30 --> Helper loaded: url_helper
INFO - 2024-09-21 13:49:30 --> Helper loaded: file_helper
INFO - 2024-09-21 13:49:30 --> Helper loaded: form_helper
INFO - 2024-09-21 13:49:30 --> Helper loaded: my_helper
INFO - 2024-09-21 13:49:30 --> Database Driver Class Initialized
INFO - 2024-09-21 13:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 13:49:30 --> Controller Class Initialized
INFO - 2024-09-21 13:49:30 --> Helper loaded: cookie_helper
INFO - 2024-09-21 13:49:30 --> Config Class Initialized
INFO - 2024-09-21 13:49:30 --> Hooks Class Initialized
DEBUG - 2024-09-21 13:49:30 --> UTF-8 Support Enabled
INFO - 2024-09-21 13:49:30 --> Utf8 Class Initialized
INFO - 2024-09-21 13:49:30 --> URI Class Initialized
INFO - 2024-09-21 13:49:30 --> Router Class Initialized
INFO - 2024-09-21 13:49:30 --> Output Class Initialized
INFO - 2024-09-21 13:49:30 --> Security Class Initialized
DEBUG - 2024-09-21 13:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 13:49:30 --> Input Class Initialized
INFO - 2024-09-21 13:49:30 --> Language Class Initialized
INFO - 2024-09-21 13:49:30 --> Language Class Initialized
INFO - 2024-09-21 13:49:30 --> Config Class Initialized
INFO - 2024-09-21 13:49:30 --> Loader Class Initialized
INFO - 2024-09-21 13:49:30 --> Helper loaded: url_helper
INFO - 2024-09-21 13:49:30 --> Helper loaded: file_helper
INFO - 2024-09-21 13:49:30 --> Helper loaded: form_helper
INFO - 2024-09-21 13:49:30 --> Helper loaded: my_helper
INFO - 2024-09-21 13:49:30 --> Database Driver Class Initialized
INFO - 2024-09-21 13:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 13:49:30 --> Controller Class Initialized
DEBUG - 2024-09-21 13:49:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-21 13:49:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-21 13:49:30 --> Final output sent to browser
DEBUG - 2024-09-21 13:49:30 --> Total execution time: 0.0275
INFO - 2024-09-21 13:49:42 --> Config Class Initialized
INFO - 2024-09-21 13:49:42 --> Hooks Class Initialized
DEBUG - 2024-09-21 13:49:42 --> UTF-8 Support Enabled
INFO - 2024-09-21 13:49:42 --> Utf8 Class Initialized
INFO - 2024-09-21 13:49:42 --> URI Class Initialized
INFO - 2024-09-21 13:49:42 --> Router Class Initialized
INFO - 2024-09-21 13:49:42 --> Output Class Initialized
INFO - 2024-09-21 13:49:42 --> Security Class Initialized
DEBUG - 2024-09-21 13:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 13:49:42 --> Input Class Initialized
INFO - 2024-09-21 13:49:42 --> Language Class Initialized
INFO - 2024-09-21 13:49:42 --> Language Class Initialized
INFO - 2024-09-21 13:49:42 --> Config Class Initialized
INFO - 2024-09-21 13:49:42 --> Loader Class Initialized
INFO - 2024-09-21 13:49:42 --> Helper loaded: url_helper
INFO - 2024-09-21 13:49:42 --> Helper loaded: file_helper
INFO - 2024-09-21 13:49:42 --> Helper loaded: form_helper
INFO - 2024-09-21 13:49:42 --> Helper loaded: my_helper
INFO - 2024-09-21 13:49:42 --> Database Driver Class Initialized
INFO - 2024-09-21 13:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 13:49:42 --> Controller Class Initialized
ERROR - 2024-09-21 13:49:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-21 13:49:42 --> Severity: Notice --> Undefined variable: kkmx /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1493
ERROR - 2024-09-21 13:49:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-21 13:49:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-21 13:49:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-21 13:49:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-21 13:49:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-21 13:49:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-21 13:49:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-21 13:49:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-21 13:49:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-21 13:49:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-21 13:49:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-21 13:49:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-21 13:49:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-21 13:49:44 --> Final output sent to browser
DEBUG - 2024-09-21 13:49:44 --> Total execution time: 2.2139
INFO - 2024-09-21 13:49:51 --> Config Class Initialized
INFO - 2024-09-21 13:49:51 --> Hooks Class Initialized
DEBUG - 2024-09-21 13:49:51 --> UTF-8 Support Enabled
INFO - 2024-09-21 13:49:51 --> Utf8 Class Initialized
INFO - 2024-09-21 13:49:51 --> URI Class Initialized
INFO - 2024-09-21 13:49:51 --> Router Class Initialized
INFO - 2024-09-21 13:49:51 --> Output Class Initialized
INFO - 2024-09-21 13:49:51 --> Security Class Initialized
DEBUG - 2024-09-21 13:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 13:49:51 --> Input Class Initialized
INFO - 2024-09-21 13:49:51 --> Language Class Initialized
INFO - 2024-09-21 13:49:51 --> Language Class Initialized
INFO - 2024-09-21 13:49:51 --> Config Class Initialized
INFO - 2024-09-21 13:49:51 --> Loader Class Initialized
INFO - 2024-09-21 13:49:51 --> Helper loaded: url_helper
INFO - 2024-09-21 13:49:51 --> Helper loaded: file_helper
INFO - 2024-09-21 13:49:51 --> Helper loaded: form_helper
INFO - 2024-09-21 13:49:51 --> Helper loaded: my_helper
INFO - 2024-09-21 13:49:51 --> Database Driver Class Initialized
INFO - 2024-09-21 13:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 13:49:51 --> Controller Class Initialized
DEBUG - 2024-09-21 13:49:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-09-21 13:49:54 --> Final output sent to browser
DEBUG - 2024-09-21 13:49:54 --> Total execution time: 3.0971
INFO - 2024-09-21 14:02:59 --> Config Class Initialized
INFO - 2024-09-21 14:02:59 --> Hooks Class Initialized
DEBUG - 2024-09-21 14:02:59 --> UTF-8 Support Enabled
INFO - 2024-09-21 14:02:59 --> Utf8 Class Initialized
INFO - 2024-09-21 14:02:59 --> URI Class Initialized
INFO - 2024-09-21 14:02:59 --> Router Class Initialized
INFO - 2024-09-21 14:02:59 --> Output Class Initialized
INFO - 2024-09-21 14:02:59 --> Security Class Initialized
DEBUG - 2024-09-21 14:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 14:02:59 --> Input Class Initialized
INFO - 2024-09-21 14:02:59 --> Language Class Initialized
INFO - 2024-09-21 14:02:59 --> Language Class Initialized
INFO - 2024-09-21 14:02:59 --> Config Class Initialized
INFO - 2024-09-21 14:02:59 --> Loader Class Initialized
INFO - 2024-09-21 14:02:59 --> Helper loaded: url_helper
INFO - 2024-09-21 14:02:59 --> Helper loaded: file_helper
INFO - 2024-09-21 14:02:59 --> Helper loaded: form_helper
INFO - 2024-09-21 14:02:59 --> Helper loaded: my_helper
INFO - 2024-09-21 14:02:59 --> Database Driver Class Initialized
INFO - 2024-09-21 14:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 14:02:59 --> Controller Class Initialized
INFO - 2024-09-21 14:02:59 --> Helper loaded: cookie_helper
INFO - 2024-09-21 14:02:59 --> Final output sent to browser
DEBUG - 2024-09-21 14:02:59 --> Total execution time: 0.0350
INFO - 2024-09-21 14:02:59 --> Config Class Initialized
INFO - 2024-09-21 14:02:59 --> Hooks Class Initialized
DEBUG - 2024-09-21 14:02:59 --> UTF-8 Support Enabled
INFO - 2024-09-21 14:02:59 --> Utf8 Class Initialized
INFO - 2024-09-21 14:02:59 --> URI Class Initialized
INFO - 2024-09-21 14:02:59 --> Router Class Initialized
INFO - 2024-09-21 14:02:59 --> Output Class Initialized
INFO - 2024-09-21 14:02:59 --> Security Class Initialized
DEBUG - 2024-09-21 14:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 14:02:59 --> Input Class Initialized
INFO - 2024-09-21 14:02:59 --> Language Class Initialized
INFO - 2024-09-21 14:02:59 --> Language Class Initialized
INFO - 2024-09-21 14:02:59 --> Config Class Initialized
INFO - 2024-09-21 14:02:59 --> Loader Class Initialized
INFO - 2024-09-21 14:02:59 --> Helper loaded: url_helper
INFO - 2024-09-21 14:02:59 --> Helper loaded: file_helper
INFO - 2024-09-21 14:02:59 --> Helper loaded: form_helper
INFO - 2024-09-21 14:02:59 --> Helper loaded: my_helper
INFO - 2024-09-21 14:02:59 --> Database Driver Class Initialized
INFO - 2024-09-21 14:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 14:02:59 --> Controller Class Initialized
INFO - 2024-09-21 14:02:59 --> Helper loaded: cookie_helper
INFO - 2024-09-21 14:03:00 --> Config Class Initialized
INFO - 2024-09-21 14:03:00 --> Hooks Class Initialized
DEBUG - 2024-09-21 14:03:00 --> UTF-8 Support Enabled
INFO - 2024-09-21 14:03:00 --> Utf8 Class Initialized
INFO - 2024-09-21 14:03:00 --> URI Class Initialized
INFO - 2024-09-21 14:03:00 --> Router Class Initialized
INFO - 2024-09-21 14:03:00 --> Output Class Initialized
INFO - 2024-09-21 14:03:00 --> Security Class Initialized
DEBUG - 2024-09-21 14:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 14:03:00 --> Input Class Initialized
INFO - 2024-09-21 14:03:00 --> Language Class Initialized
INFO - 2024-09-21 14:03:00 --> Language Class Initialized
INFO - 2024-09-21 14:03:00 --> Config Class Initialized
INFO - 2024-09-21 14:03:00 --> Loader Class Initialized
INFO - 2024-09-21 14:03:00 --> Helper loaded: url_helper
INFO - 2024-09-21 14:03:00 --> Helper loaded: file_helper
INFO - 2024-09-21 14:03:00 --> Helper loaded: form_helper
INFO - 2024-09-21 14:03:00 --> Helper loaded: my_helper
INFO - 2024-09-21 14:03:00 --> Database Driver Class Initialized
INFO - 2024-09-21 14:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 14:03:00 --> Controller Class Initialized
DEBUG - 2024-09-21 14:03:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-21 14:03:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-21 14:03:00 --> Final output sent to browser
DEBUG - 2024-09-21 14:03:00 --> Total execution time: 0.0312
INFO - 2024-09-21 14:03:05 --> Config Class Initialized
INFO - 2024-09-21 14:03:05 --> Hooks Class Initialized
DEBUG - 2024-09-21 14:03:05 --> UTF-8 Support Enabled
INFO - 2024-09-21 14:03:05 --> Utf8 Class Initialized
INFO - 2024-09-21 14:03:05 --> URI Class Initialized
INFO - 2024-09-21 14:03:05 --> Router Class Initialized
INFO - 2024-09-21 14:03:05 --> Output Class Initialized
INFO - 2024-09-21 14:03:05 --> Security Class Initialized
DEBUG - 2024-09-21 14:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 14:03:05 --> Input Class Initialized
INFO - 2024-09-21 14:03:05 --> Language Class Initialized
INFO - 2024-09-21 14:03:05 --> Language Class Initialized
INFO - 2024-09-21 14:03:05 --> Config Class Initialized
INFO - 2024-09-21 14:03:05 --> Loader Class Initialized
INFO - 2024-09-21 14:03:05 --> Helper loaded: url_helper
INFO - 2024-09-21 14:03:05 --> Helper loaded: file_helper
INFO - 2024-09-21 14:03:05 --> Helper loaded: form_helper
INFO - 2024-09-21 14:03:05 --> Helper loaded: my_helper
INFO - 2024-09-21 14:03:05 --> Database Driver Class Initialized
INFO - 2024-09-21 14:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 14:03:05 --> Controller Class Initialized
ERROR - 2024-09-21 14:03:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-21 14:03:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-21 14:03:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-21 14:03:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-21 14:03:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-21 14:03:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-21 14:03:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-21 14:03:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-21 14:03:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-21 14:03:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-21 14:03:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-21 14:03:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-21 14:03:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-21 14:03:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-21 14:03:07 --> Final output sent to browser
DEBUG - 2024-09-21 14:03:07 --> Total execution time: 2.3081
INFO - 2024-09-21 14:03:08 --> Config Class Initialized
INFO - 2024-09-21 14:03:08 --> Hooks Class Initialized
DEBUG - 2024-09-21 14:03:08 --> UTF-8 Support Enabled
INFO - 2024-09-21 14:03:08 --> Utf8 Class Initialized
INFO - 2024-09-21 14:03:08 --> URI Class Initialized
INFO - 2024-09-21 14:03:08 --> Router Class Initialized
INFO - 2024-09-21 14:03:08 --> Output Class Initialized
INFO - 2024-09-21 14:03:08 --> Security Class Initialized
DEBUG - 2024-09-21 14:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 14:03:08 --> Input Class Initialized
INFO - 2024-09-21 14:03:08 --> Language Class Initialized
INFO - 2024-09-21 14:03:08 --> Language Class Initialized
INFO - 2024-09-21 14:03:08 --> Config Class Initialized
INFO - 2024-09-21 14:03:08 --> Loader Class Initialized
INFO - 2024-09-21 14:03:08 --> Helper loaded: url_helper
INFO - 2024-09-21 14:03:08 --> Helper loaded: file_helper
INFO - 2024-09-21 14:03:08 --> Helper loaded: form_helper
INFO - 2024-09-21 14:03:08 --> Helper loaded: my_helper
INFO - 2024-09-21 14:03:08 --> Database Driver Class Initialized
INFO - 2024-09-21 14:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 14:03:08 --> Controller Class Initialized
ERROR - 2024-09-21 14:03:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-21 14:03:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-21 14:03:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-21 14:03:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-21 14:03:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-21 14:03:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-21 14:03:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-21 14:03:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-21 14:03:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-21 14:03:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-21 14:03:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-21 14:03:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-21 14:03:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-21 14:03:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-21 14:03:09 --> Config Class Initialized
INFO - 2024-09-21 14:03:09 --> Hooks Class Initialized
DEBUG - 2024-09-21 14:03:09 --> UTF-8 Support Enabled
INFO - 2024-09-21 14:03:09 --> Utf8 Class Initialized
INFO - 2024-09-21 14:03:09 --> URI Class Initialized
INFO - 2024-09-21 14:03:09 --> Router Class Initialized
INFO - 2024-09-21 14:03:09 --> Output Class Initialized
INFO - 2024-09-21 14:03:09 --> Security Class Initialized
DEBUG - 2024-09-21 14:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 14:03:09 --> Input Class Initialized
INFO - 2024-09-21 14:03:09 --> Language Class Initialized
INFO - 2024-09-21 14:03:09 --> Language Class Initialized
INFO - 2024-09-21 14:03:09 --> Config Class Initialized
INFO - 2024-09-21 14:03:09 --> Loader Class Initialized
INFO - 2024-09-21 14:03:09 --> Helper loaded: url_helper
INFO - 2024-09-21 14:03:09 --> Helper loaded: file_helper
INFO - 2024-09-21 14:03:09 --> Helper loaded: form_helper
INFO - 2024-09-21 14:03:09 --> Helper loaded: my_helper
INFO - 2024-09-21 14:03:09 --> Database Driver Class Initialized
INFO - 2024-09-21 14:03:10 --> Final output sent to browser
DEBUG - 2024-09-21 14:03:10 --> Total execution time: 2.1723
INFO - 2024-09-21 14:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 14:03:10 --> Controller Class Initialized
DEBUG - 2024-09-21 14:03:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-09-21 14:03:13 --> Final output sent to browser
DEBUG - 2024-09-21 14:03:13 --> Total execution time: 3.5072
INFO - 2024-09-21 14:03:13 --> Config Class Initialized
INFO - 2024-09-21 14:03:13 --> Hooks Class Initialized
DEBUG - 2024-09-21 14:03:13 --> UTF-8 Support Enabled
INFO - 2024-09-21 14:03:13 --> Utf8 Class Initialized
INFO - 2024-09-21 14:03:13 --> URI Class Initialized
INFO - 2024-09-21 14:03:13 --> Router Class Initialized
INFO - 2024-09-21 14:03:13 --> Output Class Initialized
INFO - 2024-09-21 14:03:13 --> Security Class Initialized
DEBUG - 2024-09-21 14:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 14:03:13 --> Input Class Initialized
INFO - 2024-09-21 14:03:13 --> Language Class Initialized
INFO - 2024-09-21 14:03:13 --> Language Class Initialized
INFO - 2024-09-21 14:03:13 --> Config Class Initialized
INFO - 2024-09-21 14:03:13 --> Loader Class Initialized
INFO - 2024-09-21 14:03:13 --> Helper loaded: url_helper
INFO - 2024-09-21 14:03:13 --> Helper loaded: file_helper
INFO - 2024-09-21 14:03:13 --> Helper loaded: form_helper
INFO - 2024-09-21 14:03:13 --> Helper loaded: my_helper
INFO - 2024-09-21 14:03:13 --> Database Driver Class Initialized
INFO - 2024-09-21 14:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 14:03:13 --> Controller Class Initialized
DEBUG - 2024-09-21 14:03:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-09-21 14:03:16 --> Final output sent to browser
DEBUG - 2024-09-21 14:03:16 --> Total execution time: 2.9520
INFO - 2024-09-21 14:03:16 --> Config Class Initialized
INFO - 2024-09-21 14:03:16 --> Hooks Class Initialized
DEBUG - 2024-09-21 14:03:16 --> UTF-8 Support Enabled
INFO - 2024-09-21 14:03:16 --> Utf8 Class Initialized
INFO - 2024-09-21 14:03:16 --> URI Class Initialized
INFO - 2024-09-21 14:03:16 --> Router Class Initialized
INFO - 2024-09-21 14:03:16 --> Output Class Initialized
INFO - 2024-09-21 14:03:16 --> Security Class Initialized
DEBUG - 2024-09-21 14:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 14:03:16 --> Input Class Initialized
INFO - 2024-09-21 14:03:16 --> Language Class Initialized
INFO - 2024-09-21 14:03:16 --> Language Class Initialized
INFO - 2024-09-21 14:03:16 --> Config Class Initialized
INFO - 2024-09-21 14:03:16 --> Loader Class Initialized
INFO - 2024-09-21 14:03:16 --> Helper loaded: url_helper
INFO - 2024-09-21 14:03:16 --> Helper loaded: file_helper
INFO - 2024-09-21 14:03:16 --> Helper loaded: form_helper
INFO - 2024-09-21 14:03:16 --> Helper loaded: my_helper
INFO - 2024-09-21 14:03:16 --> Database Driver Class Initialized
INFO - 2024-09-21 14:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 14:03:16 --> Controller Class Initialized
ERROR - 2024-09-21 14:03:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1797
ERROR - 2024-09-21 14:03:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1804
ERROR - 2024-09-21 14:03:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-09-21 14:03:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-09-21 14:03:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-09-21 14:03:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 86
ERROR - 2024-09-21 14:03:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-09-21 14:03:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-09-21 14:03:16 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-09-21 14:03:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-09-21 14:03:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-09-21 14:03:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-09-21 14:03:17 --> Config Class Initialized
INFO - 2024-09-21 14:03:17 --> Hooks Class Initialized
DEBUG - 2024-09-21 14:03:17 --> UTF-8 Support Enabled
INFO - 2024-09-21 14:03:17 --> Utf8 Class Initialized
INFO - 2024-09-21 14:03:17 --> URI Class Initialized
INFO - 2024-09-21 14:03:17 --> Router Class Initialized
INFO - 2024-09-21 14:03:17 --> Output Class Initialized
INFO - 2024-09-21 14:03:17 --> Security Class Initialized
DEBUG - 2024-09-21 14:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 14:03:17 --> Input Class Initialized
INFO - 2024-09-21 14:03:17 --> Language Class Initialized
INFO - 2024-09-21 14:03:17 --> Language Class Initialized
INFO - 2024-09-21 14:03:17 --> Config Class Initialized
INFO - 2024-09-21 14:03:17 --> Loader Class Initialized
INFO - 2024-09-21 14:03:17 --> Helper loaded: url_helper
INFO - 2024-09-21 14:03:17 --> Helper loaded: file_helper
INFO - 2024-09-21 14:03:17 --> Helper loaded: form_helper
INFO - 2024-09-21 14:03:17 --> Helper loaded: my_helper
INFO - 2024-09-21 14:03:17 --> Database Driver Class Initialized
INFO - 2024-09-21 14:03:18 --> Config Class Initialized
INFO - 2024-09-21 14:03:18 --> Hooks Class Initialized
DEBUG - 2024-09-21 14:03:18 --> UTF-8 Support Enabled
INFO - 2024-09-21 14:03:18 --> Utf8 Class Initialized
INFO - 2024-09-21 14:03:18 --> URI Class Initialized
INFO - 2024-09-21 14:03:18 --> Router Class Initialized
INFO - 2024-09-21 14:03:18 --> Output Class Initialized
INFO - 2024-09-21 14:03:18 --> Security Class Initialized
DEBUG - 2024-09-21 14:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 14:03:18 --> Input Class Initialized
INFO - 2024-09-21 14:03:18 --> Language Class Initialized
INFO - 2024-09-21 14:03:18 --> Language Class Initialized
INFO - 2024-09-21 14:03:18 --> Config Class Initialized
INFO - 2024-09-21 14:03:18 --> Loader Class Initialized
INFO - 2024-09-21 14:03:18 --> Helper loaded: url_helper
INFO - 2024-09-21 14:03:18 --> Helper loaded: file_helper
INFO - 2024-09-21 14:03:18 --> Helper loaded: form_helper
INFO - 2024-09-21 14:03:18 --> Helper loaded: my_helper
INFO - 2024-09-21 14:03:18 --> Database Driver Class Initialized
ERROR - 2024-09-21 14:03:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
ERROR - 2024-09-21 14:03:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
INFO - 2024-09-21 14:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 14:03:19 --> Controller Class Initialized
ERROR - 2024-09-21 14:03:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2591
ERROR - 2024-09-21 14:03:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3156
ERROR - 2024-09-21 14:03:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3194
ERROR - 2024-09-21 14:03:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3232
ERROR - 2024-09-21 14:03:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3271
ERROR - 2024-09-21 14:03:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3388
ERROR - 2024-09-21 14:03:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3507
ERROR - 2024-09-21 14:03:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3626
ERROR - 2024-09-21 14:03:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3745
INFO - 2024-09-21 14:03:19 --> Config Class Initialized
INFO - 2024-09-21 14:03:19 --> Hooks Class Initialized
DEBUG - 2024-09-21 14:03:19 --> UTF-8 Support Enabled
INFO - 2024-09-21 14:03:19 --> Utf8 Class Initialized
INFO - 2024-09-21 14:03:19 --> URI Class Initialized
INFO - 2024-09-21 14:03:19 --> Router Class Initialized
INFO - 2024-09-21 14:03:19 --> Output Class Initialized
INFO - 2024-09-21 14:03:19 --> Security Class Initialized
DEBUG - 2024-09-21 14:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 14:03:19 --> Input Class Initialized
INFO - 2024-09-21 14:03:19 --> Language Class Initialized
ERROR - 2024-09-21 14:03:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-09-21 14:03:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-09-21 14:03:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 40
ERROR - 2024-09-21 14:03:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-09-21 14:03:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-09-21 14:03:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
ERROR - 2024-09-21 14:03:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
DEBUG - 2024-09-21 14:03:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-09-21 14:03:19 --> Language Class Initialized
INFO - 2024-09-21 14:03:19 --> Config Class Initialized
INFO - 2024-09-21 14:03:19 --> Loader Class Initialized
INFO - 2024-09-21 14:03:19 --> Helper loaded: url_helper
INFO - 2024-09-21 14:03:19 --> Helper loaded: file_helper
INFO - 2024-09-21 14:03:19 --> Helper loaded: form_helper
INFO - 2024-09-21 14:03:19 --> Helper loaded: my_helper
INFO - 2024-09-21 14:03:19 --> Database Driver Class Initialized
INFO - 2024-09-21 14:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 14:06:06 --> Controller Class Initialized
ERROR - 2024-09-21 14:06:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-09-21 14:06:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-21 14:06:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-21 14:06:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-09-21 14:06:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-21 14:06:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-21 14:06:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-09-21 14:06:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-09-21 14:06:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-21 14:06:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-21 14:06:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-09-21 14:06:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-21 14:06:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-21 14:06:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-09-21 14:06:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-21 14:06:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-21 14:06:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-09-21 14:06:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-09-21 14:06:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-09-21 14:06:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-09-21 14:06:08 --> Final output sent to browser
DEBUG - 2024-09-21 14:06:08 --> Total execution time: 170.0026
INFO - 2024-09-21 14:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 14:06:08 --> Controller Class Initialized
ERROR - 2024-09-21 14:06:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-21 14:06:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-21 14:06:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-21 14:06:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-21 14:06:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-21 14:06:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-21 14:06:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-21 14:06:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-21 14:06:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-21 14:06:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-21 14:06:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-21 14:06:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-21 14:06:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-21 14:06:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-21 14:06:10 --> Final output sent to browser
DEBUG - 2024-09-21 14:06:10 --> Total execution time: 171.5110
