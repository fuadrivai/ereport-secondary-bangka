<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-19 10:36:45 --> Config Class Initialized
INFO - 2024-07-19 10:36:45 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:36:45 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:36:45 --> Utf8 Class Initialized
INFO - 2024-07-19 10:36:45 --> URI Class Initialized
INFO - 2024-07-19 10:36:45 --> Router Class Initialized
INFO - 2024-07-19 10:36:45 --> Output Class Initialized
INFO - 2024-07-19 10:36:45 --> Security Class Initialized
DEBUG - 2024-07-19 10:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:36:45 --> Input Class Initialized
INFO - 2024-07-19 10:36:45 --> Language Class Initialized
INFO - 2024-07-19 10:36:45 --> Language Class Initialized
INFO - 2024-07-19 10:36:45 --> Config Class Initialized
INFO - 2024-07-19 10:36:45 --> Loader Class Initialized
INFO - 2024-07-19 10:36:45 --> Helper loaded: url_helper
INFO - 2024-07-19 10:36:45 --> Helper loaded: file_helper
INFO - 2024-07-19 10:36:45 --> Helper loaded: form_helper
INFO - 2024-07-19 10:36:45 --> Helper loaded: my_helper
INFO - 2024-07-19 10:36:45 --> Database Driver Class Initialized
INFO - 2024-07-19 10:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:36:45 --> Controller Class Initialized
DEBUG - 2024-07-19 10:36:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-07-19 10:36:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:36:45 --> Final output sent to browser
DEBUG - 2024-07-19 10:36:45 --> Total execution time: 0.0761
INFO - 2024-07-19 10:36:48 --> Config Class Initialized
INFO - 2024-07-19 10:36:48 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:36:48 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:36:48 --> Utf8 Class Initialized
INFO - 2024-07-19 10:36:48 --> URI Class Initialized
INFO - 2024-07-19 10:36:48 --> Router Class Initialized
INFO - 2024-07-19 10:36:48 --> Output Class Initialized
INFO - 2024-07-19 10:36:48 --> Security Class Initialized
DEBUG - 2024-07-19 10:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:36:48 --> Input Class Initialized
INFO - 2024-07-19 10:36:48 --> Language Class Initialized
INFO - 2024-07-19 10:36:48 --> Language Class Initialized
INFO - 2024-07-19 10:36:48 --> Config Class Initialized
INFO - 2024-07-19 10:36:48 --> Loader Class Initialized
INFO - 2024-07-19 10:36:48 --> Helper loaded: url_helper
INFO - 2024-07-19 10:36:48 --> Helper loaded: file_helper
INFO - 2024-07-19 10:36:48 --> Helper loaded: form_helper
INFO - 2024-07-19 10:36:48 --> Helper loaded: my_helper
INFO - 2024-07-19 10:36:48 --> Database Driver Class Initialized
INFO - 2024-07-19 10:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:36:48 --> Controller Class Initialized
INFO - 2024-07-19 10:36:48 --> Helper loaded: cookie_helper
INFO - 2024-07-19 10:36:48 --> Final output sent to browser
DEBUG - 2024-07-19 10:36:48 --> Total execution time: 0.0508
INFO - 2024-07-19 10:36:48 --> Config Class Initialized
INFO - 2024-07-19 10:36:48 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:36:48 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:36:48 --> Utf8 Class Initialized
INFO - 2024-07-19 10:36:48 --> URI Class Initialized
INFO - 2024-07-19 10:36:48 --> Router Class Initialized
INFO - 2024-07-19 10:36:48 --> Output Class Initialized
INFO - 2024-07-19 10:36:48 --> Security Class Initialized
DEBUG - 2024-07-19 10:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:36:48 --> Input Class Initialized
INFO - 2024-07-19 10:36:48 --> Language Class Initialized
INFO - 2024-07-19 10:36:48 --> Language Class Initialized
INFO - 2024-07-19 10:36:48 --> Config Class Initialized
INFO - 2024-07-19 10:36:48 --> Loader Class Initialized
INFO - 2024-07-19 10:36:48 --> Helper loaded: url_helper
INFO - 2024-07-19 10:36:48 --> Helper loaded: file_helper
INFO - 2024-07-19 10:36:48 --> Helper loaded: form_helper
INFO - 2024-07-19 10:36:48 --> Helper loaded: my_helper
INFO - 2024-07-19 10:36:48 --> Database Driver Class Initialized
INFO - 2024-07-19 10:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:36:48 --> Controller Class Initialized
DEBUG - 2024-07-19 10:36:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-07-19 10:36:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:36:48 --> Final output sent to browser
DEBUG - 2024-07-19 10:36:48 --> Total execution time: 0.0387
INFO - 2024-07-19 10:36:51 --> Config Class Initialized
INFO - 2024-07-19 10:36:51 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:36:51 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:36:51 --> Utf8 Class Initialized
INFO - 2024-07-19 10:36:51 --> URI Class Initialized
INFO - 2024-07-19 10:36:51 --> Router Class Initialized
INFO - 2024-07-19 10:36:51 --> Output Class Initialized
INFO - 2024-07-19 10:36:51 --> Security Class Initialized
DEBUG - 2024-07-19 10:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:36:51 --> Input Class Initialized
INFO - 2024-07-19 10:36:51 --> Language Class Initialized
INFO - 2024-07-19 10:36:51 --> Language Class Initialized
INFO - 2024-07-19 10:36:51 --> Config Class Initialized
INFO - 2024-07-19 10:36:51 --> Loader Class Initialized
INFO - 2024-07-19 10:36:51 --> Helper loaded: url_helper
INFO - 2024-07-19 10:36:51 --> Helper loaded: file_helper
INFO - 2024-07-19 10:36:51 --> Helper loaded: form_helper
INFO - 2024-07-19 10:36:51 --> Helper loaded: my_helper
INFO - 2024-07-19 10:36:51 --> Database Driver Class Initialized
INFO - 2024-07-19 10:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:36:51 --> Controller Class Initialized
DEBUG - 2024-07-19 10:36:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-19 10:36:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:36:51 --> Final output sent to browser
DEBUG - 2024-07-19 10:36:51 --> Total execution time: 0.0357
INFO - 2024-07-19 10:36:51 --> Config Class Initialized
INFO - 2024-07-19 10:36:51 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:36:51 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:36:51 --> Utf8 Class Initialized
INFO - 2024-07-19 10:36:51 --> URI Class Initialized
INFO - 2024-07-19 10:36:51 --> Router Class Initialized
INFO - 2024-07-19 10:36:51 --> Output Class Initialized
INFO - 2024-07-19 10:36:51 --> Security Class Initialized
DEBUG - 2024-07-19 10:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:36:51 --> Input Class Initialized
INFO - 2024-07-19 10:36:51 --> Language Class Initialized
ERROR - 2024-07-19 10:36:51 --> 404 Page Not Found: /index
INFO - 2024-07-19 10:36:51 --> Config Class Initialized
INFO - 2024-07-19 10:36:51 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:36:51 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:36:51 --> Utf8 Class Initialized
INFO - 2024-07-19 10:36:51 --> URI Class Initialized
INFO - 2024-07-19 10:36:51 --> Router Class Initialized
INFO - 2024-07-19 10:36:51 --> Output Class Initialized
INFO - 2024-07-19 10:36:51 --> Security Class Initialized
DEBUG - 2024-07-19 10:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:36:51 --> Input Class Initialized
INFO - 2024-07-19 10:36:51 --> Language Class Initialized
INFO - 2024-07-19 10:36:51 --> Language Class Initialized
INFO - 2024-07-19 10:36:51 --> Config Class Initialized
INFO - 2024-07-19 10:36:51 --> Loader Class Initialized
INFO - 2024-07-19 10:36:51 --> Helper loaded: url_helper
INFO - 2024-07-19 10:36:51 --> Helper loaded: file_helper
INFO - 2024-07-19 10:36:51 --> Helper loaded: form_helper
INFO - 2024-07-19 10:36:51 --> Helper loaded: my_helper
INFO - 2024-07-19 10:36:51 --> Database Driver Class Initialized
INFO - 2024-07-19 10:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:36:51 --> Controller Class Initialized
INFO - 2024-07-19 10:36:55 --> Config Class Initialized
INFO - 2024-07-19 10:36:55 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:36:55 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:36:55 --> Utf8 Class Initialized
INFO - 2024-07-19 10:36:55 --> URI Class Initialized
INFO - 2024-07-19 10:36:55 --> Router Class Initialized
INFO - 2024-07-19 10:36:55 --> Output Class Initialized
INFO - 2024-07-19 10:36:55 --> Security Class Initialized
DEBUG - 2024-07-19 10:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:36:55 --> Input Class Initialized
INFO - 2024-07-19 10:36:55 --> Language Class Initialized
INFO - 2024-07-19 10:36:55 --> Language Class Initialized
INFO - 2024-07-19 10:36:55 --> Config Class Initialized
INFO - 2024-07-19 10:36:55 --> Loader Class Initialized
INFO - 2024-07-19 10:36:55 --> Helper loaded: url_helper
INFO - 2024-07-19 10:36:55 --> Helper loaded: file_helper
INFO - 2024-07-19 10:36:55 --> Helper loaded: form_helper
INFO - 2024-07-19 10:36:55 --> Helper loaded: my_helper
INFO - 2024-07-19 10:36:55 --> Database Driver Class Initialized
INFO - 2024-07-19 10:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:36:55 --> Controller Class Initialized
DEBUG - 2024-07-19 10:36:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-19 10:36:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:36:55 --> Final output sent to browser
DEBUG - 2024-07-19 10:36:55 --> Total execution time: 0.0649
INFO - 2024-07-19 10:39:20 --> Config Class Initialized
INFO - 2024-07-19 10:39:20 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:39:20 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:39:20 --> Utf8 Class Initialized
INFO - 2024-07-19 10:39:20 --> URI Class Initialized
DEBUG - 2024-07-19 10:39:20 --> No URI present. Default controller set.
INFO - 2024-07-19 10:39:20 --> Router Class Initialized
INFO - 2024-07-19 10:39:20 --> Output Class Initialized
INFO - 2024-07-19 10:39:20 --> Security Class Initialized
DEBUG - 2024-07-19 10:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:39:20 --> Input Class Initialized
INFO - 2024-07-19 10:39:20 --> Language Class Initialized
INFO - 2024-07-19 10:39:20 --> Language Class Initialized
INFO - 2024-07-19 10:39:20 --> Config Class Initialized
INFO - 2024-07-19 10:39:20 --> Loader Class Initialized
INFO - 2024-07-19 10:39:20 --> Helper loaded: url_helper
INFO - 2024-07-19 10:39:20 --> Helper loaded: file_helper
INFO - 2024-07-19 10:39:20 --> Helper loaded: form_helper
INFO - 2024-07-19 10:39:20 --> Helper loaded: my_helper
INFO - 2024-07-19 10:39:20 --> Database Driver Class Initialized
INFO - 2024-07-19 10:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:39:20 --> Controller Class Initialized
INFO - 2024-07-19 10:39:21 --> Config Class Initialized
INFO - 2024-07-19 10:39:21 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:39:21 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:39:21 --> Utf8 Class Initialized
INFO - 2024-07-19 10:39:21 --> URI Class Initialized
INFO - 2024-07-19 10:39:21 --> Router Class Initialized
INFO - 2024-07-19 10:39:21 --> Output Class Initialized
INFO - 2024-07-19 10:39:21 --> Security Class Initialized
DEBUG - 2024-07-19 10:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:39:21 --> Input Class Initialized
INFO - 2024-07-19 10:39:21 --> Language Class Initialized
INFO - 2024-07-19 10:39:21 --> Language Class Initialized
INFO - 2024-07-19 10:39:21 --> Config Class Initialized
INFO - 2024-07-19 10:39:21 --> Loader Class Initialized
INFO - 2024-07-19 10:39:21 --> Helper loaded: url_helper
INFO - 2024-07-19 10:39:21 --> Helper loaded: file_helper
INFO - 2024-07-19 10:39:21 --> Helper loaded: form_helper
INFO - 2024-07-19 10:39:21 --> Helper loaded: my_helper
INFO - 2024-07-19 10:39:21 --> Database Driver Class Initialized
INFO - 2024-07-19 10:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:39:21 --> Controller Class Initialized
DEBUG - 2024-07-19 10:39:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-07-19 10:39:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:39:21 --> Final output sent to browser
DEBUG - 2024-07-19 10:39:21 --> Total execution time: 0.0312
INFO - 2024-07-19 10:39:27 --> Config Class Initialized
INFO - 2024-07-19 10:39:27 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:39:27 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:39:27 --> Utf8 Class Initialized
INFO - 2024-07-19 10:39:27 --> URI Class Initialized
INFO - 2024-07-19 10:39:27 --> Router Class Initialized
INFO - 2024-07-19 10:39:27 --> Output Class Initialized
INFO - 2024-07-19 10:39:27 --> Security Class Initialized
DEBUG - 2024-07-19 10:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:39:27 --> Input Class Initialized
INFO - 2024-07-19 10:39:27 --> Language Class Initialized
INFO - 2024-07-19 10:39:27 --> Language Class Initialized
INFO - 2024-07-19 10:39:27 --> Config Class Initialized
INFO - 2024-07-19 10:39:27 --> Loader Class Initialized
INFO - 2024-07-19 10:39:27 --> Helper loaded: url_helper
INFO - 2024-07-19 10:39:27 --> Helper loaded: file_helper
INFO - 2024-07-19 10:39:27 --> Helper loaded: form_helper
INFO - 2024-07-19 10:39:27 --> Helper loaded: my_helper
INFO - 2024-07-19 10:39:27 --> Database Driver Class Initialized
INFO - 2024-07-19 10:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:39:27 --> Controller Class Initialized
INFO - 2024-07-19 10:39:27 --> Helper loaded: cookie_helper
INFO - 2024-07-19 10:39:27 --> Final output sent to browser
DEBUG - 2024-07-19 10:39:27 --> Total execution time: 0.0340
INFO - 2024-07-19 10:39:27 --> Config Class Initialized
INFO - 2024-07-19 10:39:27 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:39:27 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:39:27 --> Utf8 Class Initialized
INFO - 2024-07-19 10:39:27 --> URI Class Initialized
INFO - 2024-07-19 10:39:27 --> Router Class Initialized
INFO - 2024-07-19 10:39:27 --> Output Class Initialized
INFO - 2024-07-19 10:39:27 --> Security Class Initialized
DEBUG - 2024-07-19 10:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:39:27 --> Input Class Initialized
INFO - 2024-07-19 10:39:27 --> Language Class Initialized
INFO - 2024-07-19 10:39:27 --> Language Class Initialized
INFO - 2024-07-19 10:39:27 --> Config Class Initialized
INFO - 2024-07-19 10:39:27 --> Loader Class Initialized
INFO - 2024-07-19 10:39:27 --> Helper loaded: url_helper
INFO - 2024-07-19 10:39:27 --> Helper loaded: file_helper
INFO - 2024-07-19 10:39:27 --> Helper loaded: form_helper
INFO - 2024-07-19 10:39:27 --> Helper loaded: my_helper
INFO - 2024-07-19 10:39:27 --> Database Driver Class Initialized
INFO - 2024-07-19 10:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:39:27 --> Controller Class Initialized
DEBUG - 2024-07-19 10:39:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-07-19 10:39:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:39:27 --> Final output sent to browser
DEBUG - 2024-07-19 10:39:27 --> Total execution time: 0.0351
INFO - 2024-07-19 10:39:34 --> Config Class Initialized
INFO - 2024-07-19 10:39:34 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:39:34 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:39:34 --> Utf8 Class Initialized
INFO - 2024-07-19 10:39:34 --> URI Class Initialized
INFO - 2024-07-19 10:39:34 --> Router Class Initialized
INFO - 2024-07-19 10:39:34 --> Output Class Initialized
INFO - 2024-07-19 10:39:34 --> Security Class Initialized
DEBUG - 2024-07-19 10:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:39:34 --> Input Class Initialized
INFO - 2024-07-19 10:39:34 --> Language Class Initialized
INFO - 2024-07-19 10:39:34 --> Language Class Initialized
INFO - 2024-07-19 10:39:34 --> Config Class Initialized
INFO - 2024-07-19 10:39:34 --> Loader Class Initialized
INFO - 2024-07-19 10:39:34 --> Helper loaded: url_helper
INFO - 2024-07-19 10:39:34 --> Helper loaded: file_helper
INFO - 2024-07-19 10:39:34 --> Helper loaded: form_helper
INFO - 2024-07-19 10:39:34 --> Helper loaded: my_helper
INFO - 2024-07-19 10:39:34 --> Database Driver Class Initialized
INFO - 2024-07-19 10:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:39:34 --> Controller Class Initialized
DEBUG - 2024-07-19 10:39:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_ekstra/views/list.php
DEBUG - 2024-07-19 10:39:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:39:34 --> Final output sent to browser
DEBUG - 2024-07-19 10:39:34 --> Total execution time: 0.0336
INFO - 2024-07-19 10:39:34 --> Config Class Initialized
INFO - 2024-07-19 10:39:34 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:39:34 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:39:34 --> Utf8 Class Initialized
INFO - 2024-07-19 10:39:34 --> URI Class Initialized
INFO - 2024-07-19 10:39:34 --> Router Class Initialized
INFO - 2024-07-19 10:39:34 --> Output Class Initialized
INFO - 2024-07-19 10:39:34 --> Security Class Initialized
DEBUG - 2024-07-19 10:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:39:34 --> Input Class Initialized
INFO - 2024-07-19 10:39:34 --> Language Class Initialized
ERROR - 2024-07-19 10:39:34 --> 404 Page Not Found: /index
INFO - 2024-07-19 10:39:34 --> Config Class Initialized
INFO - 2024-07-19 10:39:34 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:39:34 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:39:34 --> Utf8 Class Initialized
INFO - 2024-07-19 10:39:34 --> URI Class Initialized
INFO - 2024-07-19 10:39:34 --> Router Class Initialized
INFO - 2024-07-19 10:39:34 --> Output Class Initialized
INFO - 2024-07-19 10:39:34 --> Security Class Initialized
DEBUG - 2024-07-19 10:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:39:34 --> Input Class Initialized
INFO - 2024-07-19 10:39:34 --> Language Class Initialized
INFO - 2024-07-19 10:39:34 --> Language Class Initialized
INFO - 2024-07-19 10:39:34 --> Config Class Initialized
INFO - 2024-07-19 10:39:34 --> Loader Class Initialized
INFO - 2024-07-19 10:39:34 --> Helper loaded: url_helper
INFO - 2024-07-19 10:39:34 --> Helper loaded: file_helper
INFO - 2024-07-19 10:39:34 --> Helper loaded: form_helper
INFO - 2024-07-19 10:39:34 --> Helper loaded: my_helper
INFO - 2024-07-19 10:39:34 --> Database Driver Class Initialized
INFO - 2024-07-19 10:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:39:34 --> Controller Class Initialized
INFO - 2024-07-19 10:39:38 --> Config Class Initialized
INFO - 2024-07-19 10:39:38 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:39:38 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:39:38 --> Utf8 Class Initialized
INFO - 2024-07-19 10:39:38 --> URI Class Initialized
INFO - 2024-07-19 10:39:38 --> Router Class Initialized
INFO - 2024-07-19 10:39:38 --> Output Class Initialized
INFO - 2024-07-19 10:39:38 --> Security Class Initialized
DEBUG - 2024-07-19 10:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:39:38 --> Input Class Initialized
INFO - 2024-07-19 10:39:38 --> Language Class Initialized
INFO - 2024-07-19 10:39:38 --> Language Class Initialized
INFO - 2024-07-19 10:39:38 --> Config Class Initialized
INFO - 2024-07-19 10:39:38 --> Loader Class Initialized
INFO - 2024-07-19 10:39:38 --> Helper loaded: url_helper
INFO - 2024-07-19 10:39:38 --> Helper loaded: file_helper
INFO - 2024-07-19 10:39:38 --> Helper loaded: form_helper
INFO - 2024-07-19 10:39:38 --> Helper loaded: my_helper
INFO - 2024-07-19 10:39:38 --> Database Driver Class Initialized
INFO - 2024-07-19 10:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:39:38 --> Controller Class Initialized
DEBUG - 2024-07-19 10:39:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2024-07-19 10:39:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:39:38 --> Final output sent to browser
DEBUG - 2024-07-19 10:39:38 --> Total execution time: 0.0299
INFO - 2024-07-19 10:39:38 --> Config Class Initialized
INFO - 2024-07-19 10:39:38 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:39:38 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:39:38 --> Utf8 Class Initialized
INFO - 2024-07-19 10:39:38 --> URI Class Initialized
INFO - 2024-07-19 10:39:38 --> Router Class Initialized
INFO - 2024-07-19 10:39:38 --> Output Class Initialized
INFO - 2024-07-19 10:39:38 --> Security Class Initialized
DEBUG - 2024-07-19 10:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:39:38 --> Input Class Initialized
INFO - 2024-07-19 10:39:38 --> Language Class Initialized
ERROR - 2024-07-19 10:39:38 --> 404 Page Not Found: /index
INFO - 2024-07-19 10:39:39 --> Config Class Initialized
INFO - 2024-07-19 10:39:39 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:39:39 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:39:39 --> Utf8 Class Initialized
INFO - 2024-07-19 10:39:39 --> URI Class Initialized
INFO - 2024-07-19 10:39:39 --> Router Class Initialized
INFO - 2024-07-19 10:39:39 --> Output Class Initialized
INFO - 2024-07-19 10:39:39 --> Security Class Initialized
DEBUG - 2024-07-19 10:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:39:39 --> Input Class Initialized
INFO - 2024-07-19 10:39:39 --> Language Class Initialized
INFO - 2024-07-19 10:39:39 --> Language Class Initialized
INFO - 2024-07-19 10:39:39 --> Config Class Initialized
INFO - 2024-07-19 10:39:39 --> Loader Class Initialized
INFO - 2024-07-19 10:39:39 --> Helper loaded: url_helper
INFO - 2024-07-19 10:39:39 --> Helper loaded: file_helper
INFO - 2024-07-19 10:39:39 --> Helper loaded: form_helper
INFO - 2024-07-19 10:39:39 --> Helper loaded: my_helper
INFO - 2024-07-19 10:39:39 --> Database Driver Class Initialized
INFO - 2024-07-19 10:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:39:39 --> Controller Class Initialized
INFO - 2024-07-19 10:39:39 --> Config Class Initialized
INFO - 2024-07-19 10:39:39 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:39:39 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:39:39 --> Utf8 Class Initialized
INFO - 2024-07-19 10:39:39 --> URI Class Initialized
INFO - 2024-07-19 10:39:39 --> Router Class Initialized
INFO - 2024-07-19 10:39:39 --> Output Class Initialized
INFO - 2024-07-19 10:39:39 --> Security Class Initialized
DEBUG - 2024-07-19 10:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:39:39 --> Input Class Initialized
INFO - 2024-07-19 10:39:39 --> Language Class Initialized
INFO - 2024-07-19 10:39:39 --> Language Class Initialized
INFO - 2024-07-19 10:39:39 --> Config Class Initialized
INFO - 2024-07-19 10:39:39 --> Loader Class Initialized
INFO - 2024-07-19 10:39:39 --> Helper loaded: url_helper
INFO - 2024-07-19 10:39:39 --> Helper loaded: file_helper
INFO - 2024-07-19 10:39:39 --> Helper loaded: form_helper
INFO - 2024-07-19 10:39:39 --> Helper loaded: my_helper
INFO - 2024-07-19 10:39:39 --> Database Driver Class Initialized
INFO - 2024-07-19 10:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:39:39 --> Controller Class Initialized
DEBUG - 2024-07-19 10:39:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-19 10:39:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:39:39 --> Final output sent to browser
DEBUG - 2024-07-19 10:39:39 --> Total execution time: 0.0352
INFO - 2024-07-19 10:39:39 --> Config Class Initialized
INFO - 2024-07-19 10:39:39 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:39:39 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:39:39 --> Utf8 Class Initialized
INFO - 2024-07-19 10:39:39 --> URI Class Initialized
INFO - 2024-07-19 10:39:39 --> Router Class Initialized
INFO - 2024-07-19 10:39:39 --> Output Class Initialized
INFO - 2024-07-19 10:39:39 --> Security Class Initialized
DEBUG - 2024-07-19 10:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:39:39 --> Input Class Initialized
INFO - 2024-07-19 10:39:39 --> Language Class Initialized
ERROR - 2024-07-19 10:39:39 --> 404 Page Not Found: /index
INFO - 2024-07-19 10:39:40 --> Config Class Initialized
INFO - 2024-07-19 10:39:40 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:39:40 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:39:40 --> Utf8 Class Initialized
INFO - 2024-07-19 10:39:40 --> URI Class Initialized
INFO - 2024-07-19 10:39:40 --> Router Class Initialized
INFO - 2024-07-19 10:39:40 --> Output Class Initialized
INFO - 2024-07-19 10:39:40 --> Security Class Initialized
DEBUG - 2024-07-19 10:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:39:40 --> Input Class Initialized
INFO - 2024-07-19 10:39:40 --> Language Class Initialized
INFO - 2024-07-19 10:39:40 --> Language Class Initialized
INFO - 2024-07-19 10:39:40 --> Config Class Initialized
INFO - 2024-07-19 10:39:40 --> Loader Class Initialized
INFO - 2024-07-19 10:39:40 --> Helper loaded: url_helper
INFO - 2024-07-19 10:39:40 --> Helper loaded: file_helper
INFO - 2024-07-19 10:39:40 --> Helper loaded: form_helper
INFO - 2024-07-19 10:39:40 --> Helper loaded: my_helper
INFO - 2024-07-19 10:39:40 --> Database Driver Class Initialized
INFO - 2024-07-19 10:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:39:40 --> Controller Class Initialized
INFO - 2024-07-19 10:39:49 --> Config Class Initialized
INFO - 2024-07-19 10:39:49 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:39:49 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:39:49 --> Utf8 Class Initialized
INFO - 2024-07-19 10:39:49 --> URI Class Initialized
INFO - 2024-07-19 10:39:49 --> Router Class Initialized
INFO - 2024-07-19 10:39:49 --> Output Class Initialized
INFO - 2024-07-19 10:39:49 --> Security Class Initialized
DEBUG - 2024-07-19 10:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:39:49 --> Input Class Initialized
INFO - 2024-07-19 10:39:49 --> Language Class Initialized
INFO - 2024-07-19 10:39:49 --> Language Class Initialized
INFO - 2024-07-19 10:39:49 --> Config Class Initialized
INFO - 2024-07-19 10:39:49 --> Loader Class Initialized
INFO - 2024-07-19 10:39:49 --> Helper loaded: url_helper
INFO - 2024-07-19 10:39:49 --> Helper loaded: file_helper
INFO - 2024-07-19 10:39:49 --> Helper loaded: form_helper
INFO - 2024-07-19 10:39:49 --> Helper loaded: my_helper
INFO - 2024-07-19 10:39:49 --> Database Driver Class Initialized
INFO - 2024-07-19 10:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:39:49 --> Controller Class Initialized
DEBUG - 2024-07-19 10:39:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_walikelas/views/list.php
DEBUG - 2024-07-19 10:39:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:39:49 --> Final output sent to browser
DEBUG - 2024-07-19 10:39:49 --> Total execution time: 0.0699
INFO - 2024-07-19 10:39:49 --> Config Class Initialized
INFO - 2024-07-19 10:39:49 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:39:49 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:39:49 --> Utf8 Class Initialized
INFO - 2024-07-19 10:39:49 --> URI Class Initialized
INFO - 2024-07-19 10:39:49 --> Router Class Initialized
INFO - 2024-07-19 10:39:49 --> Output Class Initialized
INFO - 2024-07-19 10:39:49 --> Security Class Initialized
DEBUG - 2024-07-19 10:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:39:49 --> Input Class Initialized
INFO - 2024-07-19 10:39:49 --> Language Class Initialized
ERROR - 2024-07-19 10:39:49 --> 404 Page Not Found: /index
INFO - 2024-07-19 10:39:49 --> Config Class Initialized
INFO - 2024-07-19 10:39:49 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:39:49 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:39:49 --> Utf8 Class Initialized
INFO - 2024-07-19 10:39:49 --> URI Class Initialized
INFO - 2024-07-19 10:39:49 --> Router Class Initialized
INFO - 2024-07-19 10:39:49 --> Output Class Initialized
INFO - 2024-07-19 10:39:49 --> Security Class Initialized
DEBUG - 2024-07-19 10:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:39:49 --> Input Class Initialized
INFO - 2024-07-19 10:39:49 --> Language Class Initialized
INFO - 2024-07-19 10:39:49 --> Language Class Initialized
INFO - 2024-07-19 10:39:49 --> Config Class Initialized
INFO - 2024-07-19 10:39:49 --> Loader Class Initialized
INFO - 2024-07-19 10:39:49 --> Helper loaded: url_helper
INFO - 2024-07-19 10:39:49 --> Helper loaded: file_helper
INFO - 2024-07-19 10:39:49 --> Helper loaded: form_helper
INFO - 2024-07-19 10:39:49 --> Helper loaded: my_helper
INFO - 2024-07-19 10:39:49 --> Database Driver Class Initialized
INFO - 2024-07-19 10:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:39:49 --> Controller Class Initialized
INFO - 2024-07-19 10:39:51 --> Config Class Initialized
INFO - 2024-07-19 10:39:51 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:39:51 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:39:51 --> Utf8 Class Initialized
INFO - 2024-07-19 10:39:51 --> URI Class Initialized
INFO - 2024-07-19 10:39:51 --> Router Class Initialized
INFO - 2024-07-19 10:39:51 --> Output Class Initialized
INFO - 2024-07-19 10:39:51 --> Security Class Initialized
DEBUG - 2024-07-19 10:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:39:51 --> Input Class Initialized
INFO - 2024-07-19 10:39:51 --> Language Class Initialized
INFO - 2024-07-19 10:39:51 --> Language Class Initialized
INFO - 2024-07-19 10:39:51 --> Config Class Initialized
INFO - 2024-07-19 10:39:51 --> Loader Class Initialized
INFO - 2024-07-19 10:39:51 --> Helper loaded: url_helper
INFO - 2024-07-19 10:39:51 --> Helper loaded: file_helper
INFO - 2024-07-19 10:39:51 --> Helper loaded: form_helper
INFO - 2024-07-19 10:39:51 --> Helper loaded: my_helper
INFO - 2024-07-19 10:39:51 --> Database Driver Class Initialized
INFO - 2024-07-19 10:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:39:51 --> Controller Class Initialized
DEBUG - 2024-07-19 10:39:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/pengumuman/views/list.php
DEBUG - 2024-07-19 10:39:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:39:51 --> Final output sent to browser
DEBUG - 2024-07-19 10:39:51 --> Total execution time: 0.0355
INFO - 2024-07-19 10:39:51 --> Config Class Initialized
INFO - 2024-07-19 10:39:51 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:39:51 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:39:51 --> Utf8 Class Initialized
INFO - 2024-07-19 10:39:51 --> URI Class Initialized
INFO - 2024-07-19 10:39:51 --> Router Class Initialized
INFO - 2024-07-19 10:39:51 --> Output Class Initialized
INFO - 2024-07-19 10:39:51 --> Security Class Initialized
DEBUG - 2024-07-19 10:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:39:51 --> Input Class Initialized
INFO - 2024-07-19 10:39:51 --> Language Class Initialized
ERROR - 2024-07-19 10:39:51 --> 404 Page Not Found: /index
INFO - 2024-07-19 10:39:52 --> Config Class Initialized
INFO - 2024-07-19 10:39:52 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:39:52 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:39:52 --> Utf8 Class Initialized
INFO - 2024-07-19 10:39:52 --> URI Class Initialized
INFO - 2024-07-19 10:39:52 --> Router Class Initialized
INFO - 2024-07-19 10:39:52 --> Output Class Initialized
INFO - 2024-07-19 10:39:52 --> Security Class Initialized
DEBUG - 2024-07-19 10:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:39:52 --> Input Class Initialized
INFO - 2024-07-19 10:39:52 --> Language Class Initialized
INFO - 2024-07-19 10:39:52 --> Language Class Initialized
INFO - 2024-07-19 10:39:52 --> Config Class Initialized
INFO - 2024-07-19 10:39:52 --> Loader Class Initialized
INFO - 2024-07-19 10:39:52 --> Helper loaded: url_helper
INFO - 2024-07-19 10:39:52 --> Helper loaded: file_helper
INFO - 2024-07-19 10:39:52 --> Helper loaded: form_helper
INFO - 2024-07-19 10:39:52 --> Helper loaded: my_helper
INFO - 2024-07-19 10:39:52 --> Database Driver Class Initialized
INFO - 2024-07-19 10:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:39:52 --> Controller Class Initialized
INFO - 2024-07-19 10:39:54 --> Config Class Initialized
INFO - 2024-07-19 10:39:54 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:39:54 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:39:54 --> Utf8 Class Initialized
INFO - 2024-07-19 10:39:54 --> URI Class Initialized
INFO - 2024-07-19 10:39:54 --> Router Class Initialized
INFO - 2024-07-19 10:39:54 --> Output Class Initialized
INFO - 2024-07-19 10:39:54 --> Security Class Initialized
DEBUG - 2024-07-19 10:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:39:54 --> Input Class Initialized
INFO - 2024-07-19 10:39:54 --> Language Class Initialized
INFO - 2024-07-19 10:39:54 --> Language Class Initialized
INFO - 2024-07-19 10:39:54 --> Config Class Initialized
INFO - 2024-07-19 10:39:54 --> Loader Class Initialized
INFO - 2024-07-19 10:39:54 --> Helper loaded: url_helper
INFO - 2024-07-19 10:39:54 --> Helper loaded: file_helper
INFO - 2024-07-19 10:39:54 --> Helper loaded: form_helper
INFO - 2024-07-19 10:39:54 --> Helper loaded: my_helper
INFO - 2024-07-19 10:39:54 --> Database Driver Class Initialized
INFO - 2024-07-19 10:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:39:54 --> Controller Class Initialized
DEBUG - 2024-07-19 10:39:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-07-19 10:39:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:39:54 --> Final output sent to browser
DEBUG - 2024-07-19 10:39:54 --> Total execution time: 0.0339
INFO - 2024-07-19 10:39:54 --> Config Class Initialized
INFO - 2024-07-19 10:39:54 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:39:54 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:39:54 --> Utf8 Class Initialized
INFO - 2024-07-19 10:39:54 --> URI Class Initialized
INFO - 2024-07-19 10:39:54 --> Router Class Initialized
INFO - 2024-07-19 10:39:54 --> Output Class Initialized
INFO - 2024-07-19 10:39:54 --> Security Class Initialized
DEBUG - 2024-07-19 10:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:39:54 --> Input Class Initialized
INFO - 2024-07-19 10:39:54 --> Language Class Initialized
ERROR - 2024-07-19 10:39:54 --> 404 Page Not Found: /index
INFO - 2024-07-19 10:39:54 --> Config Class Initialized
INFO - 2024-07-19 10:39:54 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:39:54 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:39:54 --> Utf8 Class Initialized
INFO - 2024-07-19 10:39:54 --> URI Class Initialized
INFO - 2024-07-19 10:39:54 --> Router Class Initialized
INFO - 2024-07-19 10:39:54 --> Output Class Initialized
INFO - 2024-07-19 10:39:54 --> Security Class Initialized
DEBUG - 2024-07-19 10:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:39:54 --> Input Class Initialized
INFO - 2024-07-19 10:39:54 --> Language Class Initialized
INFO - 2024-07-19 10:39:54 --> Language Class Initialized
INFO - 2024-07-19 10:39:54 --> Config Class Initialized
INFO - 2024-07-19 10:39:54 --> Loader Class Initialized
INFO - 2024-07-19 10:39:54 --> Helper loaded: url_helper
INFO - 2024-07-19 10:39:54 --> Helper loaded: file_helper
INFO - 2024-07-19 10:39:54 --> Helper loaded: form_helper
INFO - 2024-07-19 10:39:54 --> Helper loaded: my_helper
INFO - 2024-07-19 10:39:54 --> Database Driver Class Initialized
INFO - 2024-07-19 10:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:39:54 --> Controller Class Initialized
INFO - 2024-07-19 10:39:56 --> Config Class Initialized
INFO - 2024-07-19 10:39:56 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:39:56 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:39:56 --> Utf8 Class Initialized
INFO - 2024-07-19 10:39:56 --> URI Class Initialized
INFO - 2024-07-19 10:39:56 --> Router Class Initialized
INFO - 2024-07-19 10:39:56 --> Output Class Initialized
INFO - 2024-07-19 10:39:56 --> Security Class Initialized
DEBUG - 2024-07-19 10:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:39:56 --> Input Class Initialized
INFO - 2024-07-19 10:39:56 --> Language Class Initialized
INFO - 2024-07-19 10:39:57 --> Language Class Initialized
INFO - 2024-07-19 10:39:57 --> Config Class Initialized
INFO - 2024-07-19 10:39:57 --> Loader Class Initialized
INFO - 2024-07-19 10:39:57 --> Helper loaded: url_helper
INFO - 2024-07-19 10:39:57 --> Helper loaded: file_helper
INFO - 2024-07-19 10:39:57 --> Helper loaded: form_helper
INFO - 2024-07-19 10:39:57 --> Helper loaded: my_helper
INFO - 2024-07-19 10:39:57 --> Database Driver Class Initialized
INFO - 2024-07-19 10:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:39:57 --> Controller Class Initialized
DEBUG - 2024-07-19 10:39:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-07-19 10:39:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:39:57 --> Final output sent to browser
DEBUG - 2024-07-19 10:39:57 --> Total execution time: 0.0721
INFO - 2024-07-19 10:39:57 --> Config Class Initialized
INFO - 2024-07-19 10:39:57 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:39:57 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:39:57 --> Utf8 Class Initialized
INFO - 2024-07-19 10:39:57 --> URI Class Initialized
INFO - 2024-07-19 10:39:57 --> Router Class Initialized
INFO - 2024-07-19 10:39:57 --> Output Class Initialized
INFO - 2024-07-19 10:39:57 --> Security Class Initialized
DEBUG - 2024-07-19 10:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:39:57 --> Input Class Initialized
INFO - 2024-07-19 10:39:57 --> Language Class Initialized
ERROR - 2024-07-19 10:39:57 --> 404 Page Not Found: /index
INFO - 2024-07-19 10:39:57 --> Config Class Initialized
INFO - 2024-07-19 10:39:57 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:39:57 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:39:57 --> Utf8 Class Initialized
INFO - 2024-07-19 10:39:57 --> URI Class Initialized
INFO - 2024-07-19 10:39:57 --> Router Class Initialized
INFO - 2024-07-19 10:39:57 --> Output Class Initialized
INFO - 2024-07-19 10:39:57 --> Security Class Initialized
DEBUG - 2024-07-19 10:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:39:57 --> Input Class Initialized
INFO - 2024-07-19 10:39:57 --> Language Class Initialized
INFO - 2024-07-19 10:39:57 --> Language Class Initialized
INFO - 2024-07-19 10:39:57 --> Config Class Initialized
INFO - 2024-07-19 10:39:57 --> Loader Class Initialized
INFO - 2024-07-19 10:39:57 --> Helper loaded: url_helper
INFO - 2024-07-19 10:39:57 --> Helper loaded: file_helper
INFO - 2024-07-19 10:39:57 --> Helper loaded: form_helper
INFO - 2024-07-19 10:39:57 --> Helper loaded: my_helper
INFO - 2024-07-19 10:39:57 --> Database Driver Class Initialized
INFO - 2024-07-19 10:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:39:57 --> Controller Class Initialized
INFO - 2024-07-19 10:39:58 --> Config Class Initialized
INFO - 2024-07-19 10:39:58 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:39:58 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:39:58 --> Utf8 Class Initialized
INFO - 2024-07-19 10:39:58 --> URI Class Initialized
INFO - 2024-07-19 10:39:58 --> Router Class Initialized
INFO - 2024-07-19 10:39:58 --> Output Class Initialized
INFO - 2024-07-19 10:39:58 --> Security Class Initialized
DEBUG - 2024-07-19 10:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:39:58 --> Input Class Initialized
INFO - 2024-07-19 10:39:58 --> Language Class Initialized
INFO - 2024-07-19 10:39:58 --> Language Class Initialized
INFO - 2024-07-19 10:39:58 --> Config Class Initialized
INFO - 2024-07-19 10:39:58 --> Loader Class Initialized
INFO - 2024-07-19 10:39:58 --> Helper loaded: url_helper
INFO - 2024-07-19 10:39:58 --> Helper loaded: file_helper
INFO - 2024-07-19 10:39:58 --> Helper loaded: form_helper
INFO - 2024-07-19 10:39:58 --> Helper loaded: my_helper
INFO - 2024-07-19 10:39:58 --> Database Driver Class Initialized
INFO - 2024-07-19 10:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:39:58 --> Controller Class Initialized
DEBUG - 2024-07-19 10:39:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-19 10:39:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:39:58 --> Final output sent to browser
DEBUG - 2024-07-19 10:39:58 --> Total execution time: 0.0440
INFO - 2024-07-19 10:39:58 --> Config Class Initialized
INFO - 2024-07-19 10:39:58 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:39:58 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:39:58 --> Utf8 Class Initialized
INFO - 2024-07-19 10:39:58 --> URI Class Initialized
INFO - 2024-07-19 10:39:58 --> Router Class Initialized
INFO - 2024-07-19 10:39:58 --> Output Class Initialized
INFO - 2024-07-19 10:39:58 --> Security Class Initialized
DEBUG - 2024-07-19 10:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:39:58 --> Input Class Initialized
INFO - 2024-07-19 10:39:58 --> Language Class Initialized
ERROR - 2024-07-19 10:39:58 --> 404 Page Not Found: /index
INFO - 2024-07-19 10:39:59 --> Config Class Initialized
INFO - 2024-07-19 10:39:59 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:39:59 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:39:59 --> Utf8 Class Initialized
INFO - 2024-07-19 10:39:59 --> URI Class Initialized
INFO - 2024-07-19 10:39:59 --> Router Class Initialized
INFO - 2024-07-19 10:39:59 --> Output Class Initialized
INFO - 2024-07-19 10:39:59 --> Security Class Initialized
DEBUG - 2024-07-19 10:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:39:59 --> Input Class Initialized
INFO - 2024-07-19 10:39:59 --> Language Class Initialized
INFO - 2024-07-19 10:39:59 --> Language Class Initialized
INFO - 2024-07-19 10:39:59 --> Config Class Initialized
INFO - 2024-07-19 10:39:59 --> Loader Class Initialized
INFO - 2024-07-19 10:39:59 --> Helper loaded: url_helper
INFO - 2024-07-19 10:39:59 --> Helper loaded: file_helper
INFO - 2024-07-19 10:39:59 --> Helper loaded: form_helper
INFO - 2024-07-19 10:39:59 --> Helper loaded: my_helper
INFO - 2024-07-19 10:39:59 --> Database Driver Class Initialized
INFO - 2024-07-19 10:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:39:59 --> Controller Class Initialized
INFO - 2024-07-19 10:40:00 --> Config Class Initialized
INFO - 2024-07-19 10:40:00 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:40:00 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:40:00 --> Utf8 Class Initialized
INFO - 2024-07-19 10:40:00 --> URI Class Initialized
INFO - 2024-07-19 10:40:00 --> Router Class Initialized
INFO - 2024-07-19 10:40:00 --> Output Class Initialized
INFO - 2024-07-19 10:40:00 --> Security Class Initialized
DEBUG - 2024-07-19 10:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:40:00 --> Input Class Initialized
INFO - 2024-07-19 10:40:00 --> Language Class Initialized
INFO - 2024-07-19 10:40:00 --> Language Class Initialized
INFO - 2024-07-19 10:40:00 --> Config Class Initialized
INFO - 2024-07-19 10:40:00 --> Loader Class Initialized
INFO - 2024-07-19 10:40:00 --> Helper loaded: url_helper
INFO - 2024-07-19 10:40:00 --> Helper loaded: file_helper
INFO - 2024-07-19 10:40:00 --> Helper loaded: form_helper
INFO - 2024-07-19 10:40:00 --> Helper loaded: my_helper
INFO - 2024-07-19 10:40:00 --> Database Driver Class Initialized
INFO - 2024-07-19 10:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:40:00 --> Controller Class Initialized
DEBUG - 2024-07-19 10:40:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2024-07-19 10:40:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:40:00 --> Final output sent to browser
DEBUG - 2024-07-19 10:40:00 --> Total execution time: 0.0266
INFO - 2024-07-19 10:40:00 --> Config Class Initialized
INFO - 2024-07-19 10:40:00 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:40:00 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:40:00 --> Utf8 Class Initialized
INFO - 2024-07-19 10:40:00 --> URI Class Initialized
INFO - 2024-07-19 10:40:00 --> Router Class Initialized
INFO - 2024-07-19 10:40:00 --> Output Class Initialized
INFO - 2024-07-19 10:40:00 --> Security Class Initialized
DEBUG - 2024-07-19 10:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:40:00 --> Input Class Initialized
INFO - 2024-07-19 10:40:00 --> Language Class Initialized
ERROR - 2024-07-19 10:40:00 --> 404 Page Not Found: /index
INFO - 2024-07-19 10:40:00 --> Config Class Initialized
INFO - 2024-07-19 10:40:00 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:40:00 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:40:00 --> Utf8 Class Initialized
INFO - 2024-07-19 10:40:00 --> URI Class Initialized
INFO - 2024-07-19 10:40:00 --> Router Class Initialized
INFO - 2024-07-19 10:40:00 --> Output Class Initialized
INFO - 2024-07-19 10:40:00 --> Security Class Initialized
DEBUG - 2024-07-19 10:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:40:00 --> Input Class Initialized
INFO - 2024-07-19 10:40:00 --> Language Class Initialized
INFO - 2024-07-19 10:40:00 --> Language Class Initialized
INFO - 2024-07-19 10:40:00 --> Config Class Initialized
INFO - 2024-07-19 10:40:00 --> Loader Class Initialized
INFO - 2024-07-19 10:40:00 --> Helper loaded: url_helper
INFO - 2024-07-19 10:40:00 --> Helper loaded: file_helper
INFO - 2024-07-19 10:40:00 --> Helper loaded: form_helper
INFO - 2024-07-19 10:40:00 --> Helper loaded: my_helper
INFO - 2024-07-19 10:40:00 --> Database Driver Class Initialized
INFO - 2024-07-19 10:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:40:00 --> Controller Class Initialized
INFO - 2024-07-19 10:40:05 --> Config Class Initialized
INFO - 2024-07-19 10:40:05 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:40:05 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:40:05 --> Utf8 Class Initialized
INFO - 2024-07-19 10:40:05 --> URI Class Initialized
INFO - 2024-07-19 10:40:05 --> Router Class Initialized
INFO - 2024-07-19 10:40:05 --> Output Class Initialized
INFO - 2024-07-19 10:40:05 --> Security Class Initialized
DEBUG - 2024-07-19 10:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:40:05 --> Input Class Initialized
INFO - 2024-07-19 10:40:05 --> Language Class Initialized
INFO - 2024-07-19 10:40:05 --> Language Class Initialized
INFO - 2024-07-19 10:40:05 --> Config Class Initialized
INFO - 2024-07-19 10:40:05 --> Loader Class Initialized
INFO - 2024-07-19 10:40:05 --> Helper loaded: url_helper
INFO - 2024-07-19 10:40:05 --> Helper loaded: file_helper
INFO - 2024-07-19 10:40:05 --> Helper loaded: form_helper
INFO - 2024-07-19 10:40:05 --> Helper loaded: my_helper
INFO - 2024-07-19 10:40:05 --> Database Driver Class Initialized
INFO - 2024-07-19 10:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:40:05 --> Controller Class Initialized
DEBUG - 2024-07-19 10:40:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2024-07-19 10:40:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:40:05 --> Final output sent to browser
DEBUG - 2024-07-19 10:40:05 --> Total execution time: 0.1041
INFO - 2024-07-19 10:40:05 --> Config Class Initialized
INFO - 2024-07-19 10:40:05 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:40:05 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:40:05 --> Utf8 Class Initialized
INFO - 2024-07-19 10:40:05 --> URI Class Initialized
INFO - 2024-07-19 10:40:06 --> Router Class Initialized
INFO - 2024-07-19 10:40:06 --> Output Class Initialized
INFO - 2024-07-19 10:40:06 --> Security Class Initialized
DEBUG - 2024-07-19 10:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:40:06 --> Input Class Initialized
INFO - 2024-07-19 10:40:06 --> Language Class Initialized
ERROR - 2024-07-19 10:40:06 --> 404 Page Not Found: /index
INFO - 2024-07-19 10:40:06 --> Config Class Initialized
INFO - 2024-07-19 10:40:06 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:40:06 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:40:06 --> Utf8 Class Initialized
INFO - 2024-07-19 10:40:06 --> URI Class Initialized
INFO - 2024-07-19 10:40:06 --> Router Class Initialized
INFO - 2024-07-19 10:40:06 --> Output Class Initialized
INFO - 2024-07-19 10:40:06 --> Security Class Initialized
DEBUG - 2024-07-19 10:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:40:06 --> Input Class Initialized
INFO - 2024-07-19 10:40:06 --> Language Class Initialized
INFO - 2024-07-19 10:40:06 --> Language Class Initialized
INFO - 2024-07-19 10:40:06 --> Config Class Initialized
INFO - 2024-07-19 10:40:06 --> Loader Class Initialized
INFO - 2024-07-19 10:40:06 --> Helper loaded: url_helper
INFO - 2024-07-19 10:40:06 --> Helper loaded: file_helper
INFO - 2024-07-19 10:40:06 --> Helper loaded: form_helper
INFO - 2024-07-19 10:40:06 --> Helper loaded: my_helper
INFO - 2024-07-19 10:40:06 --> Database Driver Class Initialized
INFO - 2024-07-19 10:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:40:06 --> Controller Class Initialized
INFO - 2024-07-19 10:40:07 --> Config Class Initialized
INFO - 2024-07-19 10:40:07 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:40:07 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:40:07 --> Utf8 Class Initialized
INFO - 2024-07-19 10:40:07 --> URI Class Initialized
INFO - 2024-07-19 10:40:07 --> Router Class Initialized
INFO - 2024-07-19 10:40:07 --> Output Class Initialized
INFO - 2024-07-19 10:40:07 --> Security Class Initialized
DEBUG - 2024-07-19 10:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:40:07 --> Input Class Initialized
INFO - 2024-07-19 10:40:07 --> Language Class Initialized
INFO - 2024-07-19 10:40:07 --> Language Class Initialized
INFO - 2024-07-19 10:40:07 --> Config Class Initialized
INFO - 2024-07-19 10:40:07 --> Loader Class Initialized
INFO - 2024-07-19 10:40:07 --> Helper loaded: url_helper
INFO - 2024-07-19 10:40:07 --> Helper loaded: file_helper
INFO - 2024-07-19 10:40:07 --> Helper loaded: form_helper
INFO - 2024-07-19 10:40:07 --> Helper loaded: my_helper
INFO - 2024-07-19 10:40:07 --> Database Driver Class Initialized
INFO - 2024-07-19 10:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:40:07 --> Controller Class Initialized
DEBUG - 2024-07-19 10:40:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_ekstra/views/list.php
DEBUG - 2024-07-19 10:40:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:40:07 --> Final output sent to browser
DEBUG - 2024-07-19 10:40:07 --> Total execution time: 0.0265
INFO - 2024-07-19 10:40:08 --> Config Class Initialized
INFO - 2024-07-19 10:40:08 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:40:08 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:40:08 --> Utf8 Class Initialized
INFO - 2024-07-19 10:40:08 --> URI Class Initialized
INFO - 2024-07-19 10:40:08 --> Router Class Initialized
INFO - 2024-07-19 10:40:08 --> Output Class Initialized
INFO - 2024-07-19 10:40:08 --> Security Class Initialized
DEBUG - 2024-07-19 10:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:40:08 --> Input Class Initialized
INFO - 2024-07-19 10:40:08 --> Language Class Initialized
ERROR - 2024-07-19 10:40:08 --> 404 Page Not Found: /index
INFO - 2024-07-19 10:40:08 --> Config Class Initialized
INFO - 2024-07-19 10:40:08 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:40:08 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:40:08 --> Utf8 Class Initialized
INFO - 2024-07-19 10:40:08 --> URI Class Initialized
INFO - 2024-07-19 10:40:08 --> Router Class Initialized
INFO - 2024-07-19 10:40:08 --> Output Class Initialized
INFO - 2024-07-19 10:40:08 --> Security Class Initialized
DEBUG - 2024-07-19 10:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:40:08 --> Input Class Initialized
INFO - 2024-07-19 10:40:08 --> Language Class Initialized
INFO - 2024-07-19 10:40:08 --> Language Class Initialized
INFO - 2024-07-19 10:40:08 --> Config Class Initialized
INFO - 2024-07-19 10:40:08 --> Loader Class Initialized
INFO - 2024-07-19 10:40:08 --> Helper loaded: url_helper
INFO - 2024-07-19 10:40:08 --> Helper loaded: file_helper
INFO - 2024-07-19 10:40:08 --> Helper loaded: form_helper
INFO - 2024-07-19 10:40:08 --> Helper loaded: my_helper
INFO - 2024-07-19 10:40:08 --> Database Driver Class Initialized
INFO - 2024-07-19 10:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:40:08 --> Controller Class Initialized
INFO - 2024-07-19 10:40:09 --> Config Class Initialized
INFO - 2024-07-19 10:40:09 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:40:09 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:40:09 --> Utf8 Class Initialized
INFO - 2024-07-19 10:40:09 --> URI Class Initialized
INFO - 2024-07-19 10:40:09 --> Router Class Initialized
INFO - 2024-07-19 10:40:09 --> Output Class Initialized
INFO - 2024-07-19 10:40:09 --> Security Class Initialized
DEBUG - 2024-07-19 10:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:40:09 --> Input Class Initialized
INFO - 2024-07-19 10:40:09 --> Language Class Initialized
INFO - 2024-07-19 10:40:09 --> Language Class Initialized
INFO - 2024-07-19 10:40:09 --> Config Class Initialized
INFO - 2024-07-19 10:40:09 --> Loader Class Initialized
INFO - 2024-07-19 10:40:09 --> Helper loaded: url_helper
INFO - 2024-07-19 10:40:09 --> Helper loaded: file_helper
INFO - 2024-07-19 10:40:09 --> Helper loaded: form_helper
INFO - 2024-07-19 10:40:09 --> Helper loaded: my_helper
INFO - 2024-07-19 10:40:09 --> Database Driver Class Initialized
INFO - 2024-07-19 10:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:40:09 --> Controller Class Initialized
DEBUG - 2024-07-19 10:40:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/backup_db/views/list.php
DEBUG - 2024-07-19 10:40:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:40:09 --> Final output sent to browser
DEBUG - 2024-07-19 10:40:09 --> Total execution time: 0.0628
INFO - 2024-07-19 10:40:09 --> Config Class Initialized
INFO - 2024-07-19 10:40:09 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:40:09 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:40:09 --> Utf8 Class Initialized
INFO - 2024-07-19 10:40:09 --> URI Class Initialized
INFO - 2024-07-19 10:40:09 --> Router Class Initialized
INFO - 2024-07-19 10:40:09 --> Output Class Initialized
INFO - 2024-07-19 10:40:09 --> Security Class Initialized
DEBUG - 2024-07-19 10:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:40:09 --> Input Class Initialized
INFO - 2024-07-19 10:40:09 --> Language Class Initialized
ERROR - 2024-07-19 10:40:09 --> 404 Page Not Found: /index
INFO - 2024-07-19 10:40:09 --> Config Class Initialized
INFO - 2024-07-19 10:40:09 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:40:09 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:40:09 --> Utf8 Class Initialized
INFO - 2024-07-19 10:40:09 --> URI Class Initialized
INFO - 2024-07-19 10:40:09 --> Router Class Initialized
INFO - 2024-07-19 10:40:09 --> Output Class Initialized
INFO - 2024-07-19 10:40:09 --> Security Class Initialized
DEBUG - 2024-07-19 10:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:40:09 --> Input Class Initialized
INFO - 2024-07-19 10:40:09 --> Language Class Initialized
INFO - 2024-07-19 10:40:09 --> Language Class Initialized
INFO - 2024-07-19 10:40:09 --> Config Class Initialized
INFO - 2024-07-19 10:40:09 --> Loader Class Initialized
INFO - 2024-07-19 10:40:09 --> Helper loaded: url_helper
INFO - 2024-07-19 10:40:09 --> Helper loaded: file_helper
INFO - 2024-07-19 10:40:09 --> Helper loaded: form_helper
INFO - 2024-07-19 10:40:09 --> Helper loaded: my_helper
INFO - 2024-07-19 10:40:09 --> Database Driver Class Initialized
INFO - 2024-07-19 10:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:40:09 --> Controller Class Initialized
INFO - 2024-07-19 10:40:20 --> Config Class Initialized
INFO - 2024-07-19 10:40:20 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:40:20 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:40:20 --> Utf8 Class Initialized
INFO - 2024-07-19 10:40:20 --> URI Class Initialized
INFO - 2024-07-19 10:40:20 --> Router Class Initialized
INFO - 2024-07-19 10:40:20 --> Output Class Initialized
INFO - 2024-07-19 10:40:20 --> Security Class Initialized
DEBUG - 2024-07-19 10:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:40:20 --> Input Class Initialized
INFO - 2024-07-19 10:40:20 --> Language Class Initialized
INFO - 2024-07-19 10:40:20 --> Language Class Initialized
INFO - 2024-07-19 10:40:20 --> Config Class Initialized
INFO - 2024-07-19 10:40:20 --> Loader Class Initialized
INFO - 2024-07-19 10:40:20 --> Helper loaded: url_helper
INFO - 2024-07-19 10:40:20 --> Helper loaded: file_helper
INFO - 2024-07-19 10:40:20 --> Helper loaded: form_helper
INFO - 2024-07-19 10:40:20 --> Helper loaded: my_helper
INFO - 2024-07-19 10:40:20 --> Database Driver Class Initialized
INFO - 2024-07-19 10:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:40:20 --> Controller Class Initialized
DEBUG - 2024-07-19 10:40:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-07-19 10:40:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:40:20 --> Final output sent to browser
DEBUG - 2024-07-19 10:40:20 --> Total execution time: 0.0337
INFO - 2024-07-19 10:40:20 --> Config Class Initialized
INFO - 2024-07-19 10:40:20 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:40:20 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:40:20 --> Utf8 Class Initialized
INFO - 2024-07-19 10:40:20 --> URI Class Initialized
INFO - 2024-07-19 10:40:20 --> Router Class Initialized
INFO - 2024-07-19 10:40:20 --> Output Class Initialized
INFO - 2024-07-19 10:40:20 --> Security Class Initialized
DEBUG - 2024-07-19 10:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:40:20 --> Input Class Initialized
INFO - 2024-07-19 10:40:20 --> Language Class Initialized
ERROR - 2024-07-19 10:40:20 --> 404 Page Not Found: /index
INFO - 2024-07-19 10:40:20 --> Config Class Initialized
INFO - 2024-07-19 10:40:20 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:40:20 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:40:20 --> Utf8 Class Initialized
INFO - 2024-07-19 10:40:20 --> URI Class Initialized
INFO - 2024-07-19 10:40:20 --> Router Class Initialized
INFO - 2024-07-19 10:40:20 --> Output Class Initialized
INFO - 2024-07-19 10:40:20 --> Security Class Initialized
DEBUG - 2024-07-19 10:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:40:20 --> Input Class Initialized
INFO - 2024-07-19 10:40:20 --> Language Class Initialized
INFO - 2024-07-19 10:40:20 --> Language Class Initialized
INFO - 2024-07-19 10:40:20 --> Config Class Initialized
INFO - 2024-07-19 10:40:20 --> Loader Class Initialized
INFO - 2024-07-19 10:40:20 --> Helper loaded: url_helper
INFO - 2024-07-19 10:40:20 --> Helper loaded: file_helper
INFO - 2024-07-19 10:40:20 --> Helper loaded: form_helper
INFO - 2024-07-19 10:40:20 --> Helper loaded: my_helper
INFO - 2024-07-19 10:40:20 --> Database Driver Class Initialized
INFO - 2024-07-19 10:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:40:20 --> Controller Class Initialized
INFO - 2024-07-19 10:40:25 --> Config Class Initialized
INFO - 2024-07-19 10:40:25 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:40:25 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:40:25 --> Utf8 Class Initialized
INFO - 2024-07-19 10:40:25 --> URI Class Initialized
INFO - 2024-07-19 10:40:25 --> Router Class Initialized
INFO - 2024-07-19 10:40:25 --> Output Class Initialized
INFO - 2024-07-19 10:40:25 --> Security Class Initialized
DEBUG - 2024-07-19 10:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:40:25 --> Input Class Initialized
INFO - 2024-07-19 10:40:25 --> Language Class Initialized
INFO - 2024-07-19 10:40:25 --> Language Class Initialized
INFO - 2024-07-19 10:40:25 --> Config Class Initialized
INFO - 2024-07-19 10:40:25 --> Loader Class Initialized
INFO - 2024-07-19 10:40:25 --> Helper loaded: url_helper
INFO - 2024-07-19 10:40:25 --> Helper loaded: file_helper
INFO - 2024-07-19 10:40:25 --> Helper loaded: form_helper
INFO - 2024-07-19 10:40:25 --> Helper loaded: my_helper
INFO - 2024-07-19 10:40:25 --> Database Driver Class Initialized
INFO - 2024-07-19 10:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:40:25 --> Controller Class Initialized
DEBUG - 2024-07-19 10:40:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/pengumuman/views/list.php
DEBUG - 2024-07-19 10:40:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:40:25 --> Final output sent to browser
DEBUG - 2024-07-19 10:40:25 --> Total execution time: 0.0498
INFO - 2024-07-19 10:40:25 --> Config Class Initialized
INFO - 2024-07-19 10:40:25 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:40:25 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:40:25 --> Utf8 Class Initialized
INFO - 2024-07-19 10:40:25 --> URI Class Initialized
INFO - 2024-07-19 10:40:25 --> Router Class Initialized
INFO - 2024-07-19 10:40:25 --> Output Class Initialized
INFO - 2024-07-19 10:40:25 --> Security Class Initialized
DEBUG - 2024-07-19 10:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:40:25 --> Input Class Initialized
INFO - 2024-07-19 10:40:25 --> Language Class Initialized
ERROR - 2024-07-19 10:40:25 --> 404 Page Not Found: /index
INFO - 2024-07-19 10:40:25 --> Config Class Initialized
INFO - 2024-07-19 10:40:25 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:40:25 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:40:25 --> Utf8 Class Initialized
INFO - 2024-07-19 10:40:25 --> URI Class Initialized
INFO - 2024-07-19 10:40:25 --> Router Class Initialized
INFO - 2024-07-19 10:40:25 --> Output Class Initialized
INFO - 2024-07-19 10:40:25 --> Security Class Initialized
DEBUG - 2024-07-19 10:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:40:25 --> Input Class Initialized
INFO - 2024-07-19 10:40:25 --> Language Class Initialized
INFO - 2024-07-19 10:40:25 --> Language Class Initialized
INFO - 2024-07-19 10:40:25 --> Config Class Initialized
INFO - 2024-07-19 10:40:25 --> Loader Class Initialized
INFO - 2024-07-19 10:40:25 --> Helper loaded: url_helper
INFO - 2024-07-19 10:40:25 --> Helper loaded: file_helper
INFO - 2024-07-19 10:40:25 --> Helper loaded: form_helper
INFO - 2024-07-19 10:40:25 --> Helper loaded: my_helper
INFO - 2024-07-19 10:40:25 --> Database Driver Class Initialized
INFO - 2024-07-19 10:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:40:25 --> Controller Class Initialized
INFO - 2024-07-19 10:40:27 --> Config Class Initialized
INFO - 2024-07-19 10:40:27 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:40:27 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:40:27 --> Utf8 Class Initialized
INFO - 2024-07-19 10:40:27 --> URI Class Initialized
DEBUG - 2024-07-19 10:40:27 --> No URI present. Default controller set.
INFO - 2024-07-19 10:40:27 --> Router Class Initialized
INFO - 2024-07-19 10:40:27 --> Output Class Initialized
INFO - 2024-07-19 10:40:27 --> Security Class Initialized
DEBUG - 2024-07-19 10:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:40:27 --> Input Class Initialized
INFO - 2024-07-19 10:40:27 --> Language Class Initialized
INFO - 2024-07-19 10:40:27 --> Language Class Initialized
INFO - 2024-07-19 10:40:27 --> Config Class Initialized
INFO - 2024-07-19 10:40:27 --> Loader Class Initialized
INFO - 2024-07-19 10:40:27 --> Helper loaded: url_helper
INFO - 2024-07-19 10:40:27 --> Helper loaded: file_helper
INFO - 2024-07-19 10:40:27 --> Helper loaded: form_helper
INFO - 2024-07-19 10:40:27 --> Helper loaded: my_helper
INFO - 2024-07-19 10:40:27 --> Database Driver Class Initialized
INFO - 2024-07-19 10:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:40:27 --> Controller Class Initialized
DEBUG - 2024-07-19 10:40:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-07-19 10:40:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:40:27 --> Final output sent to browser
DEBUG - 2024-07-19 10:40:27 --> Total execution time: 0.0345
INFO - 2024-07-19 10:43:16 --> Config Class Initialized
INFO - 2024-07-19 10:43:16 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:43:16 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:43:16 --> Utf8 Class Initialized
INFO - 2024-07-19 10:43:16 --> URI Class Initialized
INFO - 2024-07-19 10:43:16 --> Router Class Initialized
INFO - 2024-07-19 10:43:16 --> Output Class Initialized
INFO - 2024-07-19 10:43:16 --> Security Class Initialized
DEBUG - 2024-07-19 10:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:43:16 --> Input Class Initialized
INFO - 2024-07-19 10:43:16 --> Language Class Initialized
INFO - 2024-07-19 10:43:16 --> Language Class Initialized
INFO - 2024-07-19 10:43:16 --> Config Class Initialized
INFO - 2024-07-19 10:43:16 --> Loader Class Initialized
INFO - 2024-07-19 10:43:16 --> Helper loaded: url_helper
INFO - 2024-07-19 10:43:16 --> Helper loaded: file_helper
INFO - 2024-07-19 10:43:16 --> Helper loaded: form_helper
INFO - 2024-07-19 10:43:16 --> Helper loaded: my_helper
INFO - 2024-07-19 10:43:16 --> Database Driver Class Initialized
INFO - 2024-07-19 10:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:43:16 --> Controller Class Initialized
DEBUG - 2024-07-19 10:43:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_ekstra/views/list.php
DEBUG - 2024-07-19 10:43:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:43:16 --> Final output sent to browser
DEBUG - 2024-07-19 10:43:16 --> Total execution time: 0.0337
INFO - 2024-07-19 10:43:16 --> Config Class Initialized
INFO - 2024-07-19 10:43:16 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:43:16 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:43:16 --> Utf8 Class Initialized
INFO - 2024-07-19 10:43:16 --> URI Class Initialized
INFO - 2024-07-19 10:43:16 --> Router Class Initialized
INFO - 2024-07-19 10:43:16 --> Output Class Initialized
INFO - 2024-07-19 10:43:16 --> Security Class Initialized
DEBUG - 2024-07-19 10:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:43:16 --> Input Class Initialized
INFO - 2024-07-19 10:43:16 --> Language Class Initialized
ERROR - 2024-07-19 10:43:16 --> 404 Page Not Found: /index
INFO - 2024-07-19 10:43:16 --> Config Class Initialized
INFO - 2024-07-19 10:43:16 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:43:16 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:43:16 --> Utf8 Class Initialized
INFO - 2024-07-19 10:43:16 --> URI Class Initialized
INFO - 2024-07-19 10:43:16 --> Router Class Initialized
INFO - 2024-07-19 10:43:16 --> Output Class Initialized
INFO - 2024-07-19 10:43:16 --> Security Class Initialized
DEBUG - 2024-07-19 10:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:43:16 --> Input Class Initialized
INFO - 2024-07-19 10:43:16 --> Language Class Initialized
INFO - 2024-07-19 10:43:16 --> Language Class Initialized
INFO - 2024-07-19 10:43:16 --> Config Class Initialized
INFO - 2024-07-19 10:43:16 --> Loader Class Initialized
INFO - 2024-07-19 10:43:16 --> Helper loaded: url_helper
INFO - 2024-07-19 10:43:16 --> Helper loaded: file_helper
INFO - 2024-07-19 10:43:16 --> Helper loaded: form_helper
INFO - 2024-07-19 10:43:16 --> Helper loaded: my_helper
INFO - 2024-07-19 10:43:16 --> Database Driver Class Initialized
INFO - 2024-07-19 10:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:43:16 --> Controller Class Initialized
INFO - 2024-07-19 10:43:17 --> Config Class Initialized
INFO - 2024-07-19 10:43:17 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:43:17 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:43:17 --> Utf8 Class Initialized
INFO - 2024-07-19 10:43:17 --> URI Class Initialized
INFO - 2024-07-19 10:43:17 --> Router Class Initialized
INFO - 2024-07-19 10:43:17 --> Output Class Initialized
INFO - 2024-07-19 10:43:17 --> Security Class Initialized
DEBUG - 2024-07-19 10:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:43:17 --> Input Class Initialized
INFO - 2024-07-19 10:43:17 --> Language Class Initialized
INFO - 2024-07-19 10:43:17 --> Language Class Initialized
INFO - 2024-07-19 10:43:17 --> Config Class Initialized
INFO - 2024-07-19 10:43:17 --> Loader Class Initialized
INFO - 2024-07-19 10:43:17 --> Helper loaded: url_helper
INFO - 2024-07-19 10:43:17 --> Helper loaded: file_helper
INFO - 2024-07-19 10:43:17 --> Helper loaded: form_helper
INFO - 2024-07-19 10:43:17 --> Helper loaded: my_helper
INFO - 2024-07-19 10:43:17 --> Database Driver Class Initialized
INFO - 2024-07-19 10:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:43:17 --> Controller Class Initialized
DEBUG - 2024-07-19 10:43:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-07-19 10:43:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:43:17 --> Final output sent to browser
DEBUG - 2024-07-19 10:43:17 --> Total execution time: 0.0300
INFO - 2024-07-19 10:43:17 --> Config Class Initialized
INFO - 2024-07-19 10:43:17 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:43:17 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:43:17 --> Utf8 Class Initialized
INFO - 2024-07-19 10:43:17 --> URI Class Initialized
INFO - 2024-07-19 10:43:17 --> Router Class Initialized
INFO - 2024-07-19 10:43:17 --> Output Class Initialized
INFO - 2024-07-19 10:43:17 --> Security Class Initialized
DEBUG - 2024-07-19 10:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:43:17 --> Input Class Initialized
INFO - 2024-07-19 10:43:17 --> Language Class Initialized
ERROR - 2024-07-19 10:43:17 --> 404 Page Not Found: /index
INFO - 2024-07-19 10:43:17 --> Config Class Initialized
INFO - 2024-07-19 10:43:17 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:43:17 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:43:17 --> Utf8 Class Initialized
INFO - 2024-07-19 10:43:17 --> URI Class Initialized
INFO - 2024-07-19 10:43:17 --> Router Class Initialized
INFO - 2024-07-19 10:43:17 --> Output Class Initialized
INFO - 2024-07-19 10:43:17 --> Security Class Initialized
DEBUG - 2024-07-19 10:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:43:17 --> Input Class Initialized
INFO - 2024-07-19 10:43:17 --> Language Class Initialized
INFO - 2024-07-19 10:43:17 --> Language Class Initialized
INFO - 2024-07-19 10:43:17 --> Config Class Initialized
INFO - 2024-07-19 10:43:17 --> Loader Class Initialized
INFO - 2024-07-19 10:43:17 --> Helper loaded: url_helper
INFO - 2024-07-19 10:43:17 --> Helper loaded: file_helper
INFO - 2024-07-19 10:43:17 --> Helper loaded: form_helper
INFO - 2024-07-19 10:43:17 --> Helper loaded: my_helper
INFO - 2024-07-19 10:43:17 --> Database Driver Class Initialized
INFO - 2024-07-19 10:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:43:17 --> Controller Class Initialized
INFO - 2024-07-19 10:43:20 --> Config Class Initialized
INFO - 2024-07-19 10:43:20 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:43:20 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:43:20 --> Utf8 Class Initialized
INFO - 2024-07-19 10:43:20 --> URI Class Initialized
INFO - 2024-07-19 10:43:20 --> Router Class Initialized
INFO - 2024-07-19 10:43:20 --> Output Class Initialized
INFO - 2024-07-19 10:43:20 --> Security Class Initialized
DEBUG - 2024-07-19 10:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:43:20 --> Input Class Initialized
INFO - 2024-07-19 10:43:20 --> Language Class Initialized
INFO - 2024-07-19 10:43:20 --> Language Class Initialized
INFO - 2024-07-19 10:43:20 --> Config Class Initialized
INFO - 2024-07-19 10:43:20 --> Loader Class Initialized
INFO - 2024-07-19 10:43:20 --> Helper loaded: url_helper
INFO - 2024-07-19 10:43:20 --> Helper loaded: file_helper
INFO - 2024-07-19 10:43:20 --> Helper loaded: form_helper
INFO - 2024-07-19 10:43:20 --> Helper loaded: my_helper
INFO - 2024-07-19 10:43:20 --> Database Driver Class Initialized
INFO - 2024-07-19 10:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:43:20 --> Controller Class Initialized
DEBUG - 2024-07-19 10:43:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-19 10:43:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:43:20 --> Final output sent to browser
DEBUG - 2024-07-19 10:43:20 --> Total execution time: 0.0270
INFO - 2024-07-19 10:43:20 --> Config Class Initialized
INFO - 2024-07-19 10:43:20 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:43:20 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:43:20 --> Utf8 Class Initialized
INFO - 2024-07-19 10:43:20 --> URI Class Initialized
INFO - 2024-07-19 10:43:20 --> Router Class Initialized
INFO - 2024-07-19 10:43:20 --> Output Class Initialized
INFO - 2024-07-19 10:43:20 --> Security Class Initialized
DEBUG - 2024-07-19 10:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:43:20 --> Input Class Initialized
INFO - 2024-07-19 10:43:20 --> Language Class Initialized
ERROR - 2024-07-19 10:43:20 --> 404 Page Not Found: /index
INFO - 2024-07-19 10:43:20 --> Config Class Initialized
INFO - 2024-07-19 10:43:20 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:43:20 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:43:20 --> Utf8 Class Initialized
INFO - 2024-07-19 10:43:20 --> URI Class Initialized
INFO - 2024-07-19 10:43:20 --> Router Class Initialized
INFO - 2024-07-19 10:43:20 --> Output Class Initialized
INFO - 2024-07-19 10:43:20 --> Security Class Initialized
DEBUG - 2024-07-19 10:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:43:20 --> Input Class Initialized
INFO - 2024-07-19 10:43:20 --> Language Class Initialized
INFO - 2024-07-19 10:43:20 --> Language Class Initialized
INFO - 2024-07-19 10:43:20 --> Config Class Initialized
INFO - 2024-07-19 10:43:20 --> Loader Class Initialized
INFO - 2024-07-19 10:43:20 --> Helper loaded: url_helper
INFO - 2024-07-19 10:43:20 --> Helper loaded: file_helper
INFO - 2024-07-19 10:43:20 --> Helper loaded: form_helper
INFO - 2024-07-19 10:43:20 --> Helper loaded: my_helper
INFO - 2024-07-19 10:43:20 --> Database Driver Class Initialized
INFO - 2024-07-19 10:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:43:20 --> Controller Class Initialized
INFO - 2024-07-19 10:43:27 --> Config Class Initialized
INFO - 2024-07-19 10:43:27 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:43:27 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:43:27 --> Utf8 Class Initialized
INFO - 2024-07-19 10:43:27 --> URI Class Initialized
INFO - 2024-07-19 10:43:27 --> Router Class Initialized
INFO - 2024-07-19 10:43:27 --> Output Class Initialized
INFO - 2024-07-19 10:43:27 --> Security Class Initialized
DEBUG - 2024-07-19 10:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:43:27 --> Input Class Initialized
INFO - 2024-07-19 10:43:27 --> Language Class Initialized
INFO - 2024-07-19 10:43:27 --> Language Class Initialized
INFO - 2024-07-19 10:43:27 --> Config Class Initialized
INFO - 2024-07-19 10:43:27 --> Loader Class Initialized
INFO - 2024-07-19 10:43:27 --> Helper loaded: url_helper
INFO - 2024-07-19 10:43:27 --> Helper loaded: file_helper
INFO - 2024-07-19 10:43:27 --> Helper loaded: form_helper
INFO - 2024-07-19 10:43:27 --> Helper loaded: my_helper
INFO - 2024-07-19 10:43:27 --> Database Driver Class Initialized
INFO - 2024-07-19 10:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:43:27 --> Controller Class Initialized
INFO - 2024-07-19 10:43:27 --> Config Class Initialized
INFO - 2024-07-19 10:43:27 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:43:27 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:43:27 --> Utf8 Class Initialized
INFO - 2024-07-19 10:43:27 --> URI Class Initialized
INFO - 2024-07-19 10:43:27 --> Router Class Initialized
INFO - 2024-07-19 10:43:27 --> Output Class Initialized
INFO - 2024-07-19 10:43:27 --> Security Class Initialized
DEBUG - 2024-07-19 10:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:43:27 --> Input Class Initialized
INFO - 2024-07-19 10:43:27 --> Language Class Initialized
INFO - 2024-07-19 10:43:27 --> Language Class Initialized
INFO - 2024-07-19 10:43:27 --> Config Class Initialized
INFO - 2024-07-19 10:43:27 --> Loader Class Initialized
INFO - 2024-07-19 10:43:27 --> Helper loaded: url_helper
INFO - 2024-07-19 10:43:27 --> Helper loaded: file_helper
INFO - 2024-07-19 10:43:27 --> Helper loaded: form_helper
INFO - 2024-07-19 10:43:27 --> Helper loaded: my_helper
INFO - 2024-07-19 10:43:27 --> Database Driver Class Initialized
INFO - 2024-07-19 10:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:43:27 --> Controller Class Initialized
INFO - 2024-07-19 10:43:27 --> Config Class Initialized
INFO - 2024-07-19 10:43:27 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:43:27 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:43:27 --> Utf8 Class Initialized
INFO - 2024-07-19 10:43:27 --> URI Class Initialized
INFO - 2024-07-19 10:43:27 --> Router Class Initialized
INFO - 2024-07-19 10:43:27 --> Output Class Initialized
INFO - 2024-07-19 10:43:27 --> Security Class Initialized
DEBUG - 2024-07-19 10:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:43:27 --> Input Class Initialized
INFO - 2024-07-19 10:43:27 --> Language Class Initialized
INFO - 2024-07-19 10:43:27 --> Language Class Initialized
INFO - 2024-07-19 10:43:27 --> Config Class Initialized
INFO - 2024-07-19 10:43:27 --> Loader Class Initialized
INFO - 2024-07-19 10:43:27 --> Helper loaded: url_helper
INFO - 2024-07-19 10:43:27 --> Helper loaded: file_helper
INFO - 2024-07-19 10:43:27 --> Helper loaded: form_helper
INFO - 2024-07-19 10:43:27 --> Helper loaded: my_helper
INFO - 2024-07-19 10:43:27 --> Database Driver Class Initialized
INFO - 2024-07-19 10:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:43:27 --> Controller Class Initialized
INFO - 2024-07-19 10:43:28 --> Config Class Initialized
INFO - 2024-07-19 10:43:28 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:43:28 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:43:28 --> Utf8 Class Initialized
INFO - 2024-07-19 10:43:28 --> URI Class Initialized
INFO - 2024-07-19 10:43:28 --> Router Class Initialized
INFO - 2024-07-19 10:43:28 --> Output Class Initialized
INFO - 2024-07-19 10:43:28 --> Security Class Initialized
DEBUG - 2024-07-19 10:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:43:28 --> Input Class Initialized
INFO - 2024-07-19 10:43:28 --> Language Class Initialized
INFO - 2024-07-19 10:43:28 --> Language Class Initialized
INFO - 2024-07-19 10:43:28 --> Config Class Initialized
INFO - 2024-07-19 10:43:28 --> Loader Class Initialized
INFO - 2024-07-19 10:43:28 --> Helper loaded: url_helper
INFO - 2024-07-19 10:43:28 --> Helper loaded: file_helper
INFO - 2024-07-19 10:43:28 --> Helper loaded: form_helper
INFO - 2024-07-19 10:43:28 --> Helper loaded: my_helper
INFO - 2024-07-19 10:43:28 --> Database Driver Class Initialized
INFO - 2024-07-19 10:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:43:28 --> Controller Class Initialized
INFO - 2024-07-19 10:43:29 --> Config Class Initialized
INFO - 2024-07-19 10:43:29 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:43:29 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:43:29 --> Utf8 Class Initialized
INFO - 2024-07-19 10:43:29 --> URI Class Initialized
INFO - 2024-07-19 10:43:29 --> Router Class Initialized
INFO - 2024-07-19 10:43:29 --> Output Class Initialized
INFO - 2024-07-19 10:43:29 --> Security Class Initialized
DEBUG - 2024-07-19 10:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:43:29 --> Input Class Initialized
INFO - 2024-07-19 10:43:29 --> Language Class Initialized
INFO - 2024-07-19 10:43:29 --> Language Class Initialized
INFO - 2024-07-19 10:43:29 --> Config Class Initialized
INFO - 2024-07-19 10:43:29 --> Loader Class Initialized
INFO - 2024-07-19 10:43:29 --> Helper loaded: url_helper
INFO - 2024-07-19 10:43:29 --> Helper loaded: file_helper
INFO - 2024-07-19 10:43:29 --> Helper loaded: form_helper
INFO - 2024-07-19 10:43:29 --> Helper loaded: my_helper
INFO - 2024-07-19 10:43:29 --> Database Driver Class Initialized
INFO - 2024-07-19 10:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:43:29 --> Controller Class Initialized
INFO - 2024-07-19 10:43:40 --> Config Class Initialized
INFO - 2024-07-19 10:43:40 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:43:40 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:43:40 --> Utf8 Class Initialized
INFO - 2024-07-19 10:43:40 --> URI Class Initialized
INFO - 2024-07-19 10:43:40 --> Router Class Initialized
INFO - 2024-07-19 10:43:40 --> Output Class Initialized
INFO - 2024-07-19 10:43:40 --> Security Class Initialized
DEBUG - 2024-07-19 10:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:43:40 --> Input Class Initialized
INFO - 2024-07-19 10:43:40 --> Language Class Initialized
INFO - 2024-07-19 10:43:40 --> Language Class Initialized
INFO - 2024-07-19 10:43:40 --> Config Class Initialized
INFO - 2024-07-19 10:43:40 --> Loader Class Initialized
INFO - 2024-07-19 10:43:40 --> Helper loaded: url_helper
INFO - 2024-07-19 10:43:40 --> Helper loaded: file_helper
INFO - 2024-07-19 10:43:40 --> Helper loaded: form_helper
INFO - 2024-07-19 10:43:40 --> Helper loaded: my_helper
INFO - 2024-07-19 10:43:40 --> Database Driver Class Initialized
INFO - 2024-07-19 10:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:43:40 --> Controller Class Initialized
ERROR - 2024-07-19 10:43:40 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-07-19 10:43:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-07-19 10:43:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:43:40 --> Final output sent to browser
DEBUG - 2024-07-19 10:43:40 --> Total execution time: 0.0447
INFO - 2024-07-19 10:43:46 --> Config Class Initialized
INFO - 2024-07-19 10:43:46 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:43:46 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:43:46 --> Utf8 Class Initialized
INFO - 2024-07-19 10:43:46 --> URI Class Initialized
INFO - 2024-07-19 10:43:46 --> Router Class Initialized
INFO - 2024-07-19 10:43:46 --> Output Class Initialized
INFO - 2024-07-19 10:43:46 --> Security Class Initialized
DEBUG - 2024-07-19 10:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:43:46 --> Input Class Initialized
INFO - 2024-07-19 10:43:46 --> Language Class Initialized
INFO - 2024-07-19 10:43:46 --> Language Class Initialized
INFO - 2024-07-19 10:43:46 --> Config Class Initialized
INFO - 2024-07-19 10:43:46 --> Loader Class Initialized
INFO - 2024-07-19 10:43:46 --> Helper loaded: url_helper
INFO - 2024-07-19 10:43:46 --> Helper loaded: file_helper
INFO - 2024-07-19 10:43:46 --> Helper loaded: form_helper
INFO - 2024-07-19 10:43:46 --> Helper loaded: my_helper
INFO - 2024-07-19 10:43:46 --> Database Driver Class Initialized
INFO - 2024-07-19 10:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:43:46 --> Controller Class Initialized
DEBUG - 2024-07-19 10:43:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-19 10:43:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:43:46 --> Final output sent to browser
DEBUG - 2024-07-19 10:43:46 --> Total execution time: 0.0494
INFO - 2024-07-19 10:43:46 --> Config Class Initialized
INFO - 2024-07-19 10:43:46 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:43:46 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:43:46 --> Utf8 Class Initialized
INFO - 2024-07-19 10:43:46 --> URI Class Initialized
INFO - 2024-07-19 10:43:46 --> Router Class Initialized
INFO - 2024-07-19 10:43:46 --> Output Class Initialized
INFO - 2024-07-19 10:43:46 --> Security Class Initialized
DEBUG - 2024-07-19 10:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:43:46 --> Input Class Initialized
INFO - 2024-07-19 10:43:46 --> Language Class Initialized
ERROR - 2024-07-19 10:43:46 --> 404 Page Not Found: /index
INFO - 2024-07-19 10:43:46 --> Config Class Initialized
INFO - 2024-07-19 10:43:46 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:43:46 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:43:46 --> Utf8 Class Initialized
INFO - 2024-07-19 10:43:46 --> URI Class Initialized
INFO - 2024-07-19 10:43:46 --> Router Class Initialized
INFO - 2024-07-19 10:43:46 --> Output Class Initialized
INFO - 2024-07-19 10:43:46 --> Security Class Initialized
DEBUG - 2024-07-19 10:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:43:46 --> Input Class Initialized
INFO - 2024-07-19 10:43:46 --> Language Class Initialized
INFO - 2024-07-19 10:43:46 --> Language Class Initialized
INFO - 2024-07-19 10:43:46 --> Config Class Initialized
INFO - 2024-07-19 10:43:46 --> Loader Class Initialized
INFO - 2024-07-19 10:43:46 --> Helper loaded: url_helper
INFO - 2024-07-19 10:43:46 --> Helper loaded: file_helper
INFO - 2024-07-19 10:43:46 --> Helper loaded: form_helper
INFO - 2024-07-19 10:43:46 --> Helper loaded: my_helper
INFO - 2024-07-19 10:43:46 --> Database Driver Class Initialized
INFO - 2024-07-19 10:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:43:46 --> Controller Class Initialized
INFO - 2024-07-19 10:43:50 --> Config Class Initialized
INFO - 2024-07-19 10:43:50 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:43:50 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:43:50 --> Utf8 Class Initialized
INFO - 2024-07-19 10:43:50 --> URI Class Initialized
INFO - 2024-07-19 10:43:50 --> Router Class Initialized
INFO - 2024-07-19 10:43:50 --> Output Class Initialized
INFO - 2024-07-19 10:43:50 --> Security Class Initialized
DEBUG - 2024-07-19 10:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:43:50 --> Input Class Initialized
INFO - 2024-07-19 10:43:50 --> Language Class Initialized
INFO - 2024-07-19 10:43:50 --> Language Class Initialized
INFO - 2024-07-19 10:43:50 --> Config Class Initialized
INFO - 2024-07-19 10:43:50 --> Loader Class Initialized
INFO - 2024-07-19 10:43:50 --> Helper loaded: url_helper
INFO - 2024-07-19 10:43:50 --> Helper loaded: file_helper
INFO - 2024-07-19 10:43:50 --> Helper loaded: form_helper
INFO - 2024-07-19 10:43:50 --> Helper loaded: my_helper
INFO - 2024-07-19 10:43:50 --> Database Driver Class Initialized
INFO - 2024-07-19 10:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:43:51 --> Controller Class Initialized
INFO - 2024-07-19 10:43:51 --> Config Class Initialized
INFO - 2024-07-19 10:43:51 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:43:51 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:43:51 --> Utf8 Class Initialized
INFO - 2024-07-19 10:43:51 --> URI Class Initialized
INFO - 2024-07-19 10:43:51 --> Router Class Initialized
INFO - 2024-07-19 10:43:51 --> Output Class Initialized
INFO - 2024-07-19 10:43:51 --> Security Class Initialized
DEBUG - 2024-07-19 10:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:43:51 --> Input Class Initialized
INFO - 2024-07-19 10:43:51 --> Language Class Initialized
INFO - 2024-07-19 10:43:51 --> Language Class Initialized
INFO - 2024-07-19 10:43:51 --> Config Class Initialized
INFO - 2024-07-19 10:43:51 --> Loader Class Initialized
INFO - 2024-07-19 10:43:51 --> Helper loaded: url_helper
INFO - 2024-07-19 10:43:51 --> Helper loaded: file_helper
INFO - 2024-07-19 10:43:51 --> Helper loaded: form_helper
INFO - 2024-07-19 10:43:51 --> Helper loaded: my_helper
INFO - 2024-07-19 10:43:51 --> Database Driver Class Initialized
INFO - 2024-07-19 10:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:43:51 --> Controller Class Initialized
INFO - 2024-07-19 10:43:51 --> Config Class Initialized
INFO - 2024-07-19 10:43:51 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:43:51 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:43:51 --> Utf8 Class Initialized
INFO - 2024-07-19 10:43:51 --> URI Class Initialized
INFO - 2024-07-19 10:43:51 --> Router Class Initialized
INFO - 2024-07-19 10:43:51 --> Output Class Initialized
INFO - 2024-07-19 10:43:51 --> Security Class Initialized
DEBUG - 2024-07-19 10:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:43:51 --> Input Class Initialized
INFO - 2024-07-19 10:43:51 --> Language Class Initialized
INFO - 2024-07-19 10:43:51 --> Language Class Initialized
INFO - 2024-07-19 10:43:51 --> Config Class Initialized
INFO - 2024-07-19 10:43:51 --> Loader Class Initialized
INFO - 2024-07-19 10:43:51 --> Helper loaded: url_helper
INFO - 2024-07-19 10:43:51 --> Helper loaded: file_helper
INFO - 2024-07-19 10:43:51 --> Helper loaded: form_helper
INFO - 2024-07-19 10:43:51 --> Helper loaded: my_helper
INFO - 2024-07-19 10:43:51 --> Database Driver Class Initialized
INFO - 2024-07-19 10:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:43:51 --> Controller Class Initialized
INFO - 2024-07-19 10:43:52 --> Config Class Initialized
INFO - 2024-07-19 10:43:52 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:43:52 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:43:52 --> Utf8 Class Initialized
INFO - 2024-07-19 10:43:52 --> URI Class Initialized
INFO - 2024-07-19 10:43:52 --> Router Class Initialized
INFO - 2024-07-19 10:43:52 --> Output Class Initialized
INFO - 2024-07-19 10:43:52 --> Security Class Initialized
DEBUG - 2024-07-19 10:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:43:52 --> Input Class Initialized
INFO - 2024-07-19 10:43:52 --> Language Class Initialized
INFO - 2024-07-19 10:43:52 --> Language Class Initialized
INFO - 2024-07-19 10:43:52 --> Config Class Initialized
INFO - 2024-07-19 10:43:52 --> Loader Class Initialized
INFO - 2024-07-19 10:43:52 --> Helper loaded: url_helper
INFO - 2024-07-19 10:43:52 --> Helper loaded: file_helper
INFO - 2024-07-19 10:43:52 --> Helper loaded: form_helper
INFO - 2024-07-19 10:43:52 --> Helper loaded: my_helper
INFO - 2024-07-19 10:43:52 --> Database Driver Class Initialized
INFO - 2024-07-19 10:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:43:52 --> Controller Class Initialized
INFO - 2024-07-19 10:43:55 --> Config Class Initialized
INFO - 2024-07-19 10:43:55 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:43:55 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:43:55 --> Utf8 Class Initialized
INFO - 2024-07-19 10:43:55 --> URI Class Initialized
INFO - 2024-07-19 10:43:55 --> Router Class Initialized
INFO - 2024-07-19 10:43:55 --> Output Class Initialized
INFO - 2024-07-19 10:43:55 --> Security Class Initialized
DEBUG - 2024-07-19 10:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:43:55 --> Input Class Initialized
INFO - 2024-07-19 10:43:55 --> Language Class Initialized
INFO - 2024-07-19 10:43:55 --> Language Class Initialized
INFO - 2024-07-19 10:43:55 --> Config Class Initialized
INFO - 2024-07-19 10:43:55 --> Loader Class Initialized
INFO - 2024-07-19 10:43:55 --> Helper loaded: url_helper
INFO - 2024-07-19 10:43:55 --> Helper loaded: file_helper
INFO - 2024-07-19 10:43:55 --> Helper loaded: form_helper
INFO - 2024-07-19 10:43:55 --> Helper loaded: my_helper
INFO - 2024-07-19 10:43:55 --> Database Driver Class Initialized
INFO - 2024-07-19 10:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:43:55 --> Controller Class Initialized
INFO - 2024-07-19 10:43:55 --> Final output sent to browser
DEBUG - 2024-07-19 10:43:55 --> Total execution time: 0.0362
INFO - 2024-07-19 10:43:55 --> Config Class Initialized
INFO - 2024-07-19 10:43:55 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:43:55 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:43:55 --> Utf8 Class Initialized
INFO - 2024-07-19 10:43:55 --> URI Class Initialized
INFO - 2024-07-19 10:43:55 --> Router Class Initialized
INFO - 2024-07-19 10:43:55 --> Output Class Initialized
INFO - 2024-07-19 10:43:55 --> Security Class Initialized
DEBUG - 2024-07-19 10:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:43:55 --> Input Class Initialized
INFO - 2024-07-19 10:43:55 --> Language Class Initialized
ERROR - 2024-07-19 10:43:55 --> 404 Page Not Found: /index
INFO - 2024-07-19 10:43:55 --> Config Class Initialized
INFO - 2024-07-19 10:43:55 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:43:55 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:43:55 --> Utf8 Class Initialized
INFO - 2024-07-19 10:43:55 --> URI Class Initialized
INFO - 2024-07-19 10:43:55 --> Router Class Initialized
INFO - 2024-07-19 10:43:55 --> Output Class Initialized
INFO - 2024-07-19 10:43:55 --> Security Class Initialized
DEBUG - 2024-07-19 10:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:43:55 --> Input Class Initialized
INFO - 2024-07-19 10:43:55 --> Language Class Initialized
INFO - 2024-07-19 10:43:55 --> Language Class Initialized
INFO - 2024-07-19 10:43:55 --> Config Class Initialized
INFO - 2024-07-19 10:43:55 --> Loader Class Initialized
INFO - 2024-07-19 10:43:55 --> Helper loaded: url_helper
INFO - 2024-07-19 10:43:55 --> Helper loaded: file_helper
INFO - 2024-07-19 10:43:55 --> Helper loaded: form_helper
INFO - 2024-07-19 10:43:55 --> Helper loaded: my_helper
INFO - 2024-07-19 10:43:55 --> Database Driver Class Initialized
INFO - 2024-07-19 10:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:43:55 --> Controller Class Initialized
INFO - 2024-07-19 10:43:59 --> Config Class Initialized
INFO - 2024-07-19 10:43:59 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:43:59 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:43:59 --> Utf8 Class Initialized
INFO - 2024-07-19 10:43:59 --> URI Class Initialized
INFO - 2024-07-19 10:43:59 --> Router Class Initialized
INFO - 2024-07-19 10:43:59 --> Output Class Initialized
INFO - 2024-07-19 10:43:59 --> Security Class Initialized
DEBUG - 2024-07-19 10:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:43:59 --> Input Class Initialized
INFO - 2024-07-19 10:43:59 --> Language Class Initialized
INFO - 2024-07-19 10:43:59 --> Language Class Initialized
INFO - 2024-07-19 10:43:59 --> Config Class Initialized
INFO - 2024-07-19 10:43:59 --> Loader Class Initialized
INFO - 2024-07-19 10:43:59 --> Helper loaded: url_helper
INFO - 2024-07-19 10:43:59 --> Helper loaded: file_helper
INFO - 2024-07-19 10:43:59 --> Helper loaded: form_helper
INFO - 2024-07-19 10:43:59 --> Helper loaded: my_helper
INFO - 2024-07-19 10:43:59 --> Database Driver Class Initialized
INFO - 2024-07-19 10:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:43:59 --> Controller Class Initialized
INFO - 2024-07-19 10:43:59 --> Config Class Initialized
INFO - 2024-07-19 10:43:59 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:43:59 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:43:59 --> Utf8 Class Initialized
INFO - 2024-07-19 10:43:59 --> URI Class Initialized
INFO - 2024-07-19 10:43:59 --> Router Class Initialized
INFO - 2024-07-19 10:43:59 --> Output Class Initialized
INFO - 2024-07-19 10:43:59 --> Security Class Initialized
DEBUG - 2024-07-19 10:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:43:59 --> Input Class Initialized
INFO - 2024-07-19 10:43:59 --> Language Class Initialized
INFO - 2024-07-19 10:43:59 --> Language Class Initialized
INFO - 2024-07-19 10:43:59 --> Config Class Initialized
INFO - 2024-07-19 10:43:59 --> Loader Class Initialized
INFO - 2024-07-19 10:43:59 --> Helper loaded: url_helper
INFO - 2024-07-19 10:43:59 --> Helper loaded: file_helper
INFO - 2024-07-19 10:43:59 --> Helper loaded: form_helper
INFO - 2024-07-19 10:43:59 --> Helper loaded: my_helper
INFO - 2024-07-19 10:43:59 --> Database Driver Class Initialized
INFO - 2024-07-19 10:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:43:59 --> Controller Class Initialized
INFO - 2024-07-19 10:44:00 --> Config Class Initialized
INFO - 2024-07-19 10:44:00 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:44:00 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:44:00 --> Utf8 Class Initialized
INFO - 2024-07-19 10:44:00 --> URI Class Initialized
INFO - 2024-07-19 10:44:00 --> Router Class Initialized
INFO - 2024-07-19 10:44:00 --> Output Class Initialized
INFO - 2024-07-19 10:44:00 --> Security Class Initialized
DEBUG - 2024-07-19 10:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:44:00 --> Input Class Initialized
INFO - 2024-07-19 10:44:00 --> Language Class Initialized
INFO - 2024-07-19 10:44:00 --> Language Class Initialized
INFO - 2024-07-19 10:44:00 --> Config Class Initialized
INFO - 2024-07-19 10:44:00 --> Loader Class Initialized
INFO - 2024-07-19 10:44:00 --> Helper loaded: url_helper
INFO - 2024-07-19 10:44:00 --> Helper loaded: file_helper
INFO - 2024-07-19 10:44:00 --> Helper loaded: form_helper
INFO - 2024-07-19 10:44:00 --> Helper loaded: my_helper
INFO - 2024-07-19 10:44:00 --> Database Driver Class Initialized
INFO - 2024-07-19 10:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:44:00 --> Controller Class Initialized
INFO - 2024-07-19 10:44:00 --> Config Class Initialized
INFO - 2024-07-19 10:44:00 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:44:00 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:44:00 --> Utf8 Class Initialized
INFO - 2024-07-19 10:44:00 --> URI Class Initialized
INFO - 2024-07-19 10:44:00 --> Router Class Initialized
INFO - 2024-07-19 10:44:00 --> Output Class Initialized
INFO - 2024-07-19 10:44:00 --> Security Class Initialized
DEBUG - 2024-07-19 10:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:44:00 --> Input Class Initialized
INFO - 2024-07-19 10:44:00 --> Language Class Initialized
INFO - 2024-07-19 10:44:00 --> Language Class Initialized
INFO - 2024-07-19 10:44:00 --> Config Class Initialized
INFO - 2024-07-19 10:44:00 --> Loader Class Initialized
INFO - 2024-07-19 10:44:00 --> Helper loaded: url_helper
INFO - 2024-07-19 10:44:00 --> Helper loaded: file_helper
INFO - 2024-07-19 10:44:00 --> Helper loaded: form_helper
INFO - 2024-07-19 10:44:00 --> Helper loaded: my_helper
INFO - 2024-07-19 10:44:00 --> Database Driver Class Initialized
INFO - 2024-07-19 10:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:44:00 --> Controller Class Initialized
INFO - 2024-07-19 10:44:00 --> Config Class Initialized
INFO - 2024-07-19 10:44:00 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:44:00 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:44:00 --> Utf8 Class Initialized
INFO - 2024-07-19 10:44:00 --> URI Class Initialized
INFO - 2024-07-19 10:44:00 --> Router Class Initialized
INFO - 2024-07-19 10:44:00 --> Output Class Initialized
INFO - 2024-07-19 10:44:00 --> Security Class Initialized
DEBUG - 2024-07-19 10:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:44:00 --> Input Class Initialized
INFO - 2024-07-19 10:44:00 --> Language Class Initialized
INFO - 2024-07-19 10:44:00 --> Language Class Initialized
INFO - 2024-07-19 10:44:00 --> Config Class Initialized
INFO - 2024-07-19 10:44:00 --> Loader Class Initialized
INFO - 2024-07-19 10:44:00 --> Helper loaded: url_helper
INFO - 2024-07-19 10:44:00 --> Helper loaded: file_helper
INFO - 2024-07-19 10:44:00 --> Helper loaded: form_helper
INFO - 2024-07-19 10:44:00 --> Helper loaded: my_helper
INFO - 2024-07-19 10:44:00 --> Database Driver Class Initialized
INFO - 2024-07-19 10:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:44:00 --> Controller Class Initialized
INFO - 2024-07-19 10:44:01 --> Config Class Initialized
INFO - 2024-07-19 10:44:01 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:44:01 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:44:01 --> Utf8 Class Initialized
INFO - 2024-07-19 10:44:01 --> URI Class Initialized
INFO - 2024-07-19 10:44:01 --> Router Class Initialized
INFO - 2024-07-19 10:44:01 --> Output Class Initialized
INFO - 2024-07-19 10:44:01 --> Security Class Initialized
DEBUG - 2024-07-19 10:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:44:01 --> Input Class Initialized
INFO - 2024-07-19 10:44:01 --> Language Class Initialized
INFO - 2024-07-19 10:44:01 --> Language Class Initialized
INFO - 2024-07-19 10:44:01 --> Config Class Initialized
INFO - 2024-07-19 10:44:01 --> Loader Class Initialized
INFO - 2024-07-19 10:44:01 --> Helper loaded: url_helper
INFO - 2024-07-19 10:44:01 --> Helper loaded: file_helper
INFO - 2024-07-19 10:44:01 --> Helper loaded: form_helper
INFO - 2024-07-19 10:44:01 --> Helper loaded: my_helper
INFO - 2024-07-19 10:44:01 --> Database Driver Class Initialized
INFO - 2024-07-19 10:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:44:01 --> Controller Class Initialized
INFO - 2024-07-19 10:44:04 --> Config Class Initialized
INFO - 2024-07-19 10:44:04 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:44:04 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:44:04 --> Utf8 Class Initialized
INFO - 2024-07-19 10:44:04 --> URI Class Initialized
INFO - 2024-07-19 10:44:04 --> Router Class Initialized
INFO - 2024-07-19 10:44:04 --> Output Class Initialized
INFO - 2024-07-19 10:44:04 --> Security Class Initialized
DEBUG - 2024-07-19 10:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:44:04 --> Input Class Initialized
INFO - 2024-07-19 10:44:04 --> Language Class Initialized
INFO - 2024-07-19 10:44:04 --> Language Class Initialized
INFO - 2024-07-19 10:44:04 --> Config Class Initialized
INFO - 2024-07-19 10:44:04 --> Loader Class Initialized
INFO - 2024-07-19 10:44:04 --> Helper loaded: url_helper
INFO - 2024-07-19 10:44:04 --> Helper loaded: file_helper
INFO - 2024-07-19 10:44:04 --> Helper loaded: form_helper
INFO - 2024-07-19 10:44:04 --> Helper loaded: my_helper
INFO - 2024-07-19 10:44:04 --> Database Driver Class Initialized
INFO - 2024-07-19 10:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:44:04 --> Controller Class Initialized
INFO - 2024-07-19 10:44:04 --> Final output sent to browser
DEBUG - 2024-07-19 10:44:04 --> Total execution time: 0.0431
INFO - 2024-07-19 10:44:04 --> Config Class Initialized
INFO - 2024-07-19 10:44:04 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:44:04 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:44:04 --> Utf8 Class Initialized
INFO - 2024-07-19 10:44:04 --> URI Class Initialized
INFO - 2024-07-19 10:44:04 --> Router Class Initialized
INFO - 2024-07-19 10:44:04 --> Output Class Initialized
INFO - 2024-07-19 10:44:04 --> Security Class Initialized
DEBUG - 2024-07-19 10:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:44:04 --> Input Class Initialized
INFO - 2024-07-19 10:44:04 --> Language Class Initialized
ERROR - 2024-07-19 10:44:04 --> 404 Page Not Found: /index
INFO - 2024-07-19 10:44:04 --> Config Class Initialized
INFO - 2024-07-19 10:44:04 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:44:04 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:44:04 --> Utf8 Class Initialized
INFO - 2024-07-19 10:44:04 --> URI Class Initialized
INFO - 2024-07-19 10:44:04 --> Router Class Initialized
INFO - 2024-07-19 10:44:04 --> Output Class Initialized
INFO - 2024-07-19 10:44:04 --> Security Class Initialized
DEBUG - 2024-07-19 10:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:44:04 --> Input Class Initialized
INFO - 2024-07-19 10:44:04 --> Language Class Initialized
INFO - 2024-07-19 10:44:04 --> Language Class Initialized
INFO - 2024-07-19 10:44:04 --> Config Class Initialized
INFO - 2024-07-19 10:44:04 --> Loader Class Initialized
INFO - 2024-07-19 10:44:04 --> Helper loaded: url_helper
INFO - 2024-07-19 10:44:04 --> Helper loaded: file_helper
INFO - 2024-07-19 10:44:04 --> Helper loaded: form_helper
INFO - 2024-07-19 10:44:04 --> Helper loaded: my_helper
INFO - 2024-07-19 10:44:04 --> Database Driver Class Initialized
INFO - 2024-07-19 10:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:44:04 --> Controller Class Initialized
INFO - 2024-07-19 10:44:06 --> Config Class Initialized
INFO - 2024-07-19 10:44:06 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:44:06 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:44:06 --> Utf8 Class Initialized
INFO - 2024-07-19 10:44:06 --> URI Class Initialized
INFO - 2024-07-19 10:44:06 --> Router Class Initialized
INFO - 2024-07-19 10:44:06 --> Output Class Initialized
INFO - 2024-07-19 10:44:06 --> Security Class Initialized
DEBUG - 2024-07-19 10:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:44:06 --> Input Class Initialized
INFO - 2024-07-19 10:44:06 --> Language Class Initialized
INFO - 2024-07-19 10:44:06 --> Language Class Initialized
INFO - 2024-07-19 10:44:06 --> Config Class Initialized
INFO - 2024-07-19 10:44:06 --> Loader Class Initialized
INFO - 2024-07-19 10:44:06 --> Helper loaded: url_helper
INFO - 2024-07-19 10:44:06 --> Helper loaded: file_helper
INFO - 2024-07-19 10:44:06 --> Helper loaded: form_helper
INFO - 2024-07-19 10:44:06 --> Helper loaded: my_helper
INFO - 2024-07-19 10:44:06 --> Database Driver Class Initialized
INFO - 2024-07-19 10:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:44:06 --> Controller Class Initialized
INFO - 2024-07-19 10:44:07 --> Config Class Initialized
INFO - 2024-07-19 10:44:07 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:44:07 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:44:07 --> Utf8 Class Initialized
INFO - 2024-07-19 10:44:07 --> URI Class Initialized
INFO - 2024-07-19 10:44:07 --> Router Class Initialized
INFO - 2024-07-19 10:44:07 --> Output Class Initialized
INFO - 2024-07-19 10:44:07 --> Security Class Initialized
DEBUG - 2024-07-19 10:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:44:07 --> Input Class Initialized
INFO - 2024-07-19 10:44:07 --> Language Class Initialized
INFO - 2024-07-19 10:44:07 --> Language Class Initialized
INFO - 2024-07-19 10:44:07 --> Config Class Initialized
INFO - 2024-07-19 10:44:07 --> Loader Class Initialized
INFO - 2024-07-19 10:44:07 --> Helper loaded: url_helper
INFO - 2024-07-19 10:44:07 --> Helper loaded: file_helper
INFO - 2024-07-19 10:44:07 --> Helper loaded: form_helper
INFO - 2024-07-19 10:44:07 --> Helper loaded: my_helper
INFO - 2024-07-19 10:44:07 --> Database Driver Class Initialized
INFO - 2024-07-19 10:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:44:07 --> Controller Class Initialized
INFO - 2024-07-19 10:44:08 --> Config Class Initialized
INFO - 2024-07-19 10:44:08 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:44:08 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:44:08 --> Utf8 Class Initialized
INFO - 2024-07-19 10:44:08 --> URI Class Initialized
INFO - 2024-07-19 10:44:08 --> Router Class Initialized
INFO - 2024-07-19 10:44:08 --> Output Class Initialized
INFO - 2024-07-19 10:44:08 --> Security Class Initialized
DEBUG - 2024-07-19 10:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:44:08 --> Input Class Initialized
INFO - 2024-07-19 10:44:08 --> Language Class Initialized
INFO - 2024-07-19 10:44:08 --> Language Class Initialized
INFO - 2024-07-19 10:44:08 --> Config Class Initialized
INFO - 2024-07-19 10:44:08 --> Loader Class Initialized
INFO - 2024-07-19 10:44:08 --> Helper loaded: url_helper
INFO - 2024-07-19 10:44:08 --> Helper loaded: file_helper
INFO - 2024-07-19 10:44:08 --> Helper loaded: form_helper
INFO - 2024-07-19 10:44:08 --> Helper loaded: my_helper
INFO - 2024-07-19 10:44:08 --> Database Driver Class Initialized
INFO - 2024-07-19 10:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:44:08 --> Controller Class Initialized
INFO - 2024-07-19 10:44:10 --> Config Class Initialized
INFO - 2024-07-19 10:44:10 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:44:10 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:44:10 --> Utf8 Class Initialized
INFO - 2024-07-19 10:44:10 --> URI Class Initialized
INFO - 2024-07-19 10:44:10 --> Router Class Initialized
INFO - 2024-07-19 10:44:10 --> Output Class Initialized
INFO - 2024-07-19 10:44:10 --> Security Class Initialized
DEBUG - 2024-07-19 10:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:44:10 --> Input Class Initialized
INFO - 2024-07-19 10:44:10 --> Language Class Initialized
INFO - 2024-07-19 10:44:10 --> Language Class Initialized
INFO - 2024-07-19 10:44:10 --> Config Class Initialized
INFO - 2024-07-19 10:44:10 --> Loader Class Initialized
INFO - 2024-07-19 10:44:10 --> Helper loaded: url_helper
INFO - 2024-07-19 10:44:10 --> Helper loaded: file_helper
INFO - 2024-07-19 10:44:10 --> Helper loaded: form_helper
INFO - 2024-07-19 10:44:10 --> Helper loaded: my_helper
INFO - 2024-07-19 10:44:10 --> Database Driver Class Initialized
INFO - 2024-07-19 10:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:44:10 --> Controller Class Initialized
INFO - 2024-07-19 10:44:10 --> Final output sent to browser
DEBUG - 2024-07-19 10:44:10 --> Total execution time: 0.1259
INFO - 2024-07-19 10:44:10 --> Config Class Initialized
INFO - 2024-07-19 10:44:10 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:44:10 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:44:10 --> Utf8 Class Initialized
INFO - 2024-07-19 10:44:10 --> URI Class Initialized
INFO - 2024-07-19 10:44:10 --> Router Class Initialized
INFO - 2024-07-19 10:44:10 --> Output Class Initialized
INFO - 2024-07-19 10:44:10 --> Security Class Initialized
DEBUG - 2024-07-19 10:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:44:10 --> Input Class Initialized
INFO - 2024-07-19 10:44:10 --> Language Class Initialized
ERROR - 2024-07-19 10:44:10 --> 404 Page Not Found: /index
INFO - 2024-07-19 10:44:10 --> Config Class Initialized
INFO - 2024-07-19 10:44:10 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:44:10 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:44:10 --> Utf8 Class Initialized
INFO - 2024-07-19 10:44:10 --> URI Class Initialized
INFO - 2024-07-19 10:44:10 --> Router Class Initialized
INFO - 2024-07-19 10:44:10 --> Output Class Initialized
INFO - 2024-07-19 10:44:10 --> Security Class Initialized
DEBUG - 2024-07-19 10:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:44:10 --> Input Class Initialized
INFO - 2024-07-19 10:44:10 --> Language Class Initialized
INFO - 2024-07-19 10:44:10 --> Language Class Initialized
INFO - 2024-07-19 10:44:10 --> Config Class Initialized
INFO - 2024-07-19 10:44:10 --> Loader Class Initialized
INFO - 2024-07-19 10:44:10 --> Helper loaded: url_helper
INFO - 2024-07-19 10:44:10 --> Helper loaded: file_helper
INFO - 2024-07-19 10:44:10 --> Helper loaded: form_helper
INFO - 2024-07-19 10:44:10 --> Helper loaded: my_helper
INFO - 2024-07-19 10:44:10 --> Database Driver Class Initialized
INFO - 2024-07-19 10:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:44:10 --> Controller Class Initialized
INFO - 2024-07-19 10:45:47 --> Config Class Initialized
INFO - 2024-07-19 10:45:47 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:45:47 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:45:47 --> Utf8 Class Initialized
INFO - 2024-07-19 10:45:47 --> URI Class Initialized
INFO - 2024-07-19 10:45:47 --> Router Class Initialized
INFO - 2024-07-19 10:45:47 --> Output Class Initialized
INFO - 2024-07-19 10:45:47 --> Security Class Initialized
DEBUG - 2024-07-19 10:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:45:47 --> Input Class Initialized
INFO - 2024-07-19 10:45:47 --> Language Class Initialized
INFO - 2024-07-19 10:45:47 --> Language Class Initialized
INFO - 2024-07-19 10:45:47 --> Config Class Initialized
INFO - 2024-07-19 10:45:47 --> Loader Class Initialized
INFO - 2024-07-19 10:45:47 --> Helper loaded: url_helper
INFO - 2024-07-19 10:45:47 --> Helper loaded: file_helper
INFO - 2024-07-19 10:45:47 --> Helper loaded: form_helper
INFO - 2024-07-19 10:45:47 --> Helper loaded: my_helper
INFO - 2024-07-19 10:45:47 --> Database Driver Class Initialized
INFO - 2024-07-19 10:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:45:47 --> Controller Class Initialized
INFO - 2024-07-19 10:45:47 --> Config Class Initialized
INFO - 2024-07-19 10:45:47 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:45:47 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:45:47 --> Utf8 Class Initialized
INFO - 2024-07-19 10:45:47 --> URI Class Initialized
INFO - 2024-07-19 10:45:47 --> Router Class Initialized
INFO - 2024-07-19 10:45:47 --> Output Class Initialized
INFO - 2024-07-19 10:45:47 --> Security Class Initialized
DEBUG - 2024-07-19 10:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:45:47 --> Input Class Initialized
INFO - 2024-07-19 10:45:47 --> Language Class Initialized
INFO - 2024-07-19 10:45:47 --> Language Class Initialized
INFO - 2024-07-19 10:45:47 --> Config Class Initialized
INFO - 2024-07-19 10:45:47 --> Loader Class Initialized
INFO - 2024-07-19 10:45:47 --> Helper loaded: url_helper
INFO - 2024-07-19 10:45:47 --> Helper loaded: file_helper
INFO - 2024-07-19 10:45:47 --> Helper loaded: form_helper
INFO - 2024-07-19 10:45:47 --> Helper loaded: my_helper
INFO - 2024-07-19 10:45:47 --> Database Driver Class Initialized
INFO - 2024-07-19 10:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:45:47 --> Controller Class Initialized
INFO - 2024-07-19 10:45:48 --> Config Class Initialized
INFO - 2024-07-19 10:45:48 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:45:48 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:45:48 --> Utf8 Class Initialized
INFO - 2024-07-19 10:45:48 --> URI Class Initialized
INFO - 2024-07-19 10:45:48 --> Router Class Initialized
INFO - 2024-07-19 10:45:48 --> Output Class Initialized
INFO - 2024-07-19 10:45:48 --> Security Class Initialized
DEBUG - 2024-07-19 10:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:45:48 --> Input Class Initialized
INFO - 2024-07-19 10:45:48 --> Language Class Initialized
INFO - 2024-07-19 10:45:48 --> Language Class Initialized
INFO - 2024-07-19 10:45:48 --> Config Class Initialized
INFO - 2024-07-19 10:45:48 --> Loader Class Initialized
INFO - 2024-07-19 10:45:48 --> Helper loaded: url_helper
INFO - 2024-07-19 10:45:48 --> Helper loaded: file_helper
INFO - 2024-07-19 10:45:48 --> Helper loaded: form_helper
INFO - 2024-07-19 10:45:48 --> Helper loaded: my_helper
INFO - 2024-07-19 10:45:48 --> Database Driver Class Initialized
INFO - 2024-07-19 10:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:45:48 --> Controller Class Initialized
INFO - 2024-07-19 10:47:46 --> Config Class Initialized
INFO - 2024-07-19 10:47:46 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:47:46 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:47:46 --> Utf8 Class Initialized
INFO - 2024-07-19 10:47:46 --> URI Class Initialized
INFO - 2024-07-19 10:47:46 --> Router Class Initialized
INFO - 2024-07-19 10:47:46 --> Output Class Initialized
INFO - 2024-07-19 10:47:46 --> Security Class Initialized
DEBUG - 2024-07-19 10:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:47:46 --> Input Class Initialized
INFO - 2024-07-19 10:47:46 --> Language Class Initialized
INFO - 2024-07-19 10:47:46 --> Language Class Initialized
INFO - 2024-07-19 10:47:46 --> Config Class Initialized
INFO - 2024-07-19 10:47:46 --> Loader Class Initialized
INFO - 2024-07-19 10:47:46 --> Helper loaded: url_helper
INFO - 2024-07-19 10:47:46 --> Helper loaded: file_helper
INFO - 2024-07-19 10:47:46 --> Helper loaded: form_helper
INFO - 2024-07-19 10:47:46 --> Helper loaded: my_helper
INFO - 2024-07-19 10:47:46 --> Database Driver Class Initialized
INFO - 2024-07-19 10:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:47:46 --> Controller Class Initialized
DEBUG - 2024-07-19 10:47:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2024-07-19 10:47:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:47:46 --> Final output sent to browser
DEBUG - 2024-07-19 10:47:46 --> Total execution time: 0.0297
INFO - 2024-07-19 10:47:47 --> Config Class Initialized
INFO - 2024-07-19 10:47:47 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:47:47 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:47:47 --> Utf8 Class Initialized
INFO - 2024-07-19 10:47:47 --> URI Class Initialized
INFO - 2024-07-19 10:47:47 --> Router Class Initialized
INFO - 2024-07-19 10:47:47 --> Output Class Initialized
INFO - 2024-07-19 10:47:47 --> Security Class Initialized
DEBUG - 2024-07-19 10:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:47:47 --> Input Class Initialized
INFO - 2024-07-19 10:47:47 --> Language Class Initialized
ERROR - 2024-07-19 10:47:47 --> 404 Page Not Found: /index
INFO - 2024-07-19 10:47:47 --> Config Class Initialized
INFO - 2024-07-19 10:47:47 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:47:47 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:47:47 --> Utf8 Class Initialized
INFO - 2024-07-19 10:47:47 --> URI Class Initialized
INFO - 2024-07-19 10:47:47 --> Router Class Initialized
INFO - 2024-07-19 10:47:47 --> Output Class Initialized
INFO - 2024-07-19 10:47:47 --> Security Class Initialized
DEBUG - 2024-07-19 10:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:47:47 --> Input Class Initialized
INFO - 2024-07-19 10:47:47 --> Language Class Initialized
INFO - 2024-07-19 10:47:47 --> Language Class Initialized
INFO - 2024-07-19 10:47:47 --> Config Class Initialized
INFO - 2024-07-19 10:47:47 --> Loader Class Initialized
INFO - 2024-07-19 10:47:47 --> Helper loaded: url_helper
INFO - 2024-07-19 10:47:47 --> Helper loaded: file_helper
INFO - 2024-07-19 10:47:47 --> Helper loaded: form_helper
INFO - 2024-07-19 10:47:47 --> Helper loaded: my_helper
INFO - 2024-07-19 10:47:47 --> Database Driver Class Initialized
INFO - 2024-07-19 10:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:47:47 --> Controller Class Initialized
INFO - 2024-07-19 10:47:49 --> Config Class Initialized
INFO - 2024-07-19 10:47:49 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:47:49 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:47:49 --> Utf8 Class Initialized
INFO - 2024-07-19 10:47:49 --> URI Class Initialized
INFO - 2024-07-19 10:47:49 --> Router Class Initialized
INFO - 2024-07-19 10:47:49 --> Output Class Initialized
INFO - 2024-07-19 10:47:49 --> Security Class Initialized
DEBUG - 2024-07-19 10:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:47:49 --> Input Class Initialized
INFO - 2024-07-19 10:47:49 --> Language Class Initialized
INFO - 2024-07-19 10:47:49 --> Language Class Initialized
INFO - 2024-07-19 10:47:49 --> Config Class Initialized
INFO - 2024-07-19 10:47:49 --> Loader Class Initialized
INFO - 2024-07-19 10:47:49 --> Helper loaded: url_helper
INFO - 2024-07-19 10:47:49 --> Helper loaded: file_helper
INFO - 2024-07-19 10:47:49 --> Helper loaded: form_helper
INFO - 2024-07-19 10:47:49 --> Helper loaded: my_helper
INFO - 2024-07-19 10:47:49 --> Database Driver Class Initialized
INFO - 2024-07-19 10:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:47:49 --> Controller Class Initialized
DEBUG - 2024-07-19 10:47:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/backup_db/views/list.php
DEBUG - 2024-07-19 10:47:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:47:49 --> Final output sent to browser
DEBUG - 2024-07-19 10:47:49 --> Total execution time: 0.0769
INFO - 2024-07-19 10:47:49 --> Config Class Initialized
INFO - 2024-07-19 10:47:49 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:47:49 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:47:49 --> Utf8 Class Initialized
INFO - 2024-07-19 10:47:49 --> URI Class Initialized
INFO - 2024-07-19 10:47:49 --> Router Class Initialized
INFO - 2024-07-19 10:47:49 --> Output Class Initialized
INFO - 2024-07-19 10:47:49 --> Security Class Initialized
DEBUG - 2024-07-19 10:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:47:49 --> Input Class Initialized
INFO - 2024-07-19 10:47:49 --> Language Class Initialized
ERROR - 2024-07-19 10:47:49 --> 404 Page Not Found: /index
INFO - 2024-07-19 10:47:49 --> Config Class Initialized
INFO - 2024-07-19 10:47:49 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:47:49 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:47:49 --> Utf8 Class Initialized
INFO - 2024-07-19 10:47:49 --> URI Class Initialized
INFO - 2024-07-19 10:47:49 --> Router Class Initialized
INFO - 2024-07-19 10:47:49 --> Output Class Initialized
INFO - 2024-07-19 10:47:49 --> Security Class Initialized
DEBUG - 2024-07-19 10:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:47:49 --> Input Class Initialized
INFO - 2024-07-19 10:47:49 --> Language Class Initialized
INFO - 2024-07-19 10:47:49 --> Language Class Initialized
INFO - 2024-07-19 10:47:49 --> Config Class Initialized
INFO - 2024-07-19 10:47:49 --> Loader Class Initialized
INFO - 2024-07-19 10:47:49 --> Helper loaded: url_helper
INFO - 2024-07-19 10:47:49 --> Helper loaded: file_helper
INFO - 2024-07-19 10:47:49 --> Helper loaded: form_helper
INFO - 2024-07-19 10:47:49 --> Helper loaded: my_helper
INFO - 2024-07-19 10:47:49 --> Database Driver Class Initialized
INFO - 2024-07-19 10:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:47:49 --> Controller Class Initialized
INFO - 2024-07-19 10:47:51 --> Config Class Initialized
INFO - 2024-07-19 10:47:51 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:47:51 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:47:51 --> Utf8 Class Initialized
INFO - 2024-07-19 10:47:51 --> URI Class Initialized
INFO - 2024-07-19 10:47:51 --> Router Class Initialized
INFO - 2024-07-19 10:47:51 --> Output Class Initialized
INFO - 2024-07-19 10:47:51 --> Security Class Initialized
DEBUG - 2024-07-19 10:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:47:51 --> Input Class Initialized
INFO - 2024-07-19 10:47:51 --> Language Class Initialized
INFO - 2024-07-19 10:47:51 --> Language Class Initialized
INFO - 2024-07-19 10:47:51 --> Config Class Initialized
INFO - 2024-07-19 10:47:51 --> Loader Class Initialized
INFO - 2024-07-19 10:47:51 --> Helper loaded: url_helper
INFO - 2024-07-19 10:47:51 --> Helper loaded: file_helper
INFO - 2024-07-19 10:47:51 --> Helper loaded: form_helper
INFO - 2024-07-19 10:47:51 --> Helper loaded: my_helper
INFO - 2024-07-19 10:47:51 --> Database Driver Class Initialized
INFO - 2024-07-19 10:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:47:51 --> Controller Class Initialized
DEBUG - 2024-07-19 10:47:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_ekstra/views/list.php
DEBUG - 2024-07-19 10:47:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:47:51 --> Final output sent to browser
DEBUG - 2024-07-19 10:47:51 --> Total execution time: 0.0414
INFO - 2024-07-19 10:47:51 --> Config Class Initialized
INFO - 2024-07-19 10:47:51 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:47:51 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:47:51 --> Utf8 Class Initialized
INFO - 2024-07-19 10:47:51 --> URI Class Initialized
INFO - 2024-07-19 10:47:51 --> Router Class Initialized
INFO - 2024-07-19 10:47:51 --> Output Class Initialized
INFO - 2024-07-19 10:47:51 --> Security Class Initialized
DEBUG - 2024-07-19 10:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:47:51 --> Input Class Initialized
INFO - 2024-07-19 10:47:51 --> Language Class Initialized
ERROR - 2024-07-19 10:47:51 --> 404 Page Not Found: /index
INFO - 2024-07-19 10:47:51 --> Config Class Initialized
INFO - 2024-07-19 10:47:51 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:47:51 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:47:51 --> Utf8 Class Initialized
INFO - 2024-07-19 10:47:51 --> URI Class Initialized
INFO - 2024-07-19 10:47:51 --> Router Class Initialized
INFO - 2024-07-19 10:47:51 --> Output Class Initialized
INFO - 2024-07-19 10:47:51 --> Security Class Initialized
DEBUG - 2024-07-19 10:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:47:51 --> Input Class Initialized
INFO - 2024-07-19 10:47:51 --> Language Class Initialized
INFO - 2024-07-19 10:47:51 --> Language Class Initialized
INFO - 2024-07-19 10:47:51 --> Config Class Initialized
INFO - 2024-07-19 10:47:51 --> Loader Class Initialized
INFO - 2024-07-19 10:47:51 --> Helper loaded: url_helper
INFO - 2024-07-19 10:47:51 --> Helper loaded: file_helper
INFO - 2024-07-19 10:47:51 --> Helper loaded: form_helper
INFO - 2024-07-19 10:47:51 --> Helper loaded: my_helper
INFO - 2024-07-19 10:47:51 --> Database Driver Class Initialized
INFO - 2024-07-19 10:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:47:51 --> Controller Class Initialized
INFO - 2024-07-19 10:47:53 --> Config Class Initialized
INFO - 2024-07-19 10:47:53 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:47:53 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:47:53 --> Utf8 Class Initialized
INFO - 2024-07-19 10:47:53 --> URI Class Initialized
INFO - 2024-07-19 10:47:53 --> Router Class Initialized
INFO - 2024-07-19 10:47:53 --> Output Class Initialized
INFO - 2024-07-19 10:47:53 --> Security Class Initialized
DEBUG - 2024-07-19 10:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:47:53 --> Input Class Initialized
INFO - 2024-07-19 10:47:53 --> Language Class Initialized
INFO - 2024-07-19 10:47:53 --> Language Class Initialized
INFO - 2024-07-19 10:47:53 --> Config Class Initialized
INFO - 2024-07-19 10:47:53 --> Loader Class Initialized
INFO - 2024-07-19 10:47:53 --> Helper loaded: url_helper
INFO - 2024-07-19 10:47:53 --> Helper loaded: file_helper
INFO - 2024-07-19 10:47:53 --> Helper loaded: form_helper
INFO - 2024-07-19 10:47:53 --> Helper loaded: my_helper
INFO - 2024-07-19 10:47:53 --> Database Driver Class Initialized
INFO - 2024-07-19 10:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:47:53 --> Controller Class Initialized
DEBUG - 2024-07-19 10:47:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2024-07-19 10:47:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:47:53 --> Final output sent to browser
DEBUG - 2024-07-19 10:47:53 --> Total execution time: 0.0285
INFO - 2024-07-19 10:47:53 --> Config Class Initialized
INFO - 2024-07-19 10:47:53 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:47:53 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:47:53 --> Utf8 Class Initialized
INFO - 2024-07-19 10:47:53 --> URI Class Initialized
INFO - 2024-07-19 10:47:53 --> Router Class Initialized
INFO - 2024-07-19 10:47:53 --> Output Class Initialized
INFO - 2024-07-19 10:47:53 --> Security Class Initialized
DEBUG - 2024-07-19 10:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:47:53 --> Input Class Initialized
INFO - 2024-07-19 10:47:53 --> Language Class Initialized
ERROR - 2024-07-19 10:47:53 --> 404 Page Not Found: /index
INFO - 2024-07-19 10:47:53 --> Config Class Initialized
INFO - 2024-07-19 10:47:53 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:47:53 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:47:53 --> Utf8 Class Initialized
INFO - 2024-07-19 10:47:53 --> URI Class Initialized
INFO - 2024-07-19 10:47:53 --> Router Class Initialized
INFO - 2024-07-19 10:47:53 --> Output Class Initialized
INFO - 2024-07-19 10:47:53 --> Security Class Initialized
DEBUG - 2024-07-19 10:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:47:53 --> Input Class Initialized
INFO - 2024-07-19 10:47:53 --> Language Class Initialized
INFO - 2024-07-19 10:47:54 --> Language Class Initialized
INFO - 2024-07-19 10:47:54 --> Config Class Initialized
INFO - 2024-07-19 10:47:54 --> Loader Class Initialized
INFO - 2024-07-19 10:47:54 --> Helper loaded: url_helper
INFO - 2024-07-19 10:47:54 --> Helper loaded: file_helper
INFO - 2024-07-19 10:47:54 --> Helper loaded: form_helper
INFO - 2024-07-19 10:47:54 --> Helper loaded: my_helper
INFO - 2024-07-19 10:47:54 --> Database Driver Class Initialized
INFO - 2024-07-19 10:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:47:54 --> Controller Class Initialized
INFO - 2024-07-19 10:47:58 --> Config Class Initialized
INFO - 2024-07-19 10:47:58 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:47:58 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:47:58 --> Utf8 Class Initialized
INFO - 2024-07-19 10:47:58 --> URI Class Initialized
INFO - 2024-07-19 10:47:58 --> Router Class Initialized
INFO - 2024-07-19 10:47:58 --> Output Class Initialized
INFO - 2024-07-19 10:47:58 --> Security Class Initialized
DEBUG - 2024-07-19 10:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:47:58 --> Input Class Initialized
INFO - 2024-07-19 10:47:58 --> Language Class Initialized
INFO - 2024-07-19 10:47:58 --> Language Class Initialized
INFO - 2024-07-19 10:47:58 --> Config Class Initialized
INFO - 2024-07-19 10:47:58 --> Loader Class Initialized
INFO - 2024-07-19 10:47:58 --> Helper loaded: url_helper
INFO - 2024-07-19 10:47:58 --> Helper loaded: file_helper
INFO - 2024-07-19 10:47:58 --> Helper loaded: form_helper
INFO - 2024-07-19 10:47:58 --> Helper loaded: my_helper
INFO - 2024-07-19 10:47:58 --> Database Driver Class Initialized
INFO - 2024-07-19 10:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:47:58 --> Controller Class Initialized
DEBUG - 2024-07-19 10:47:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-07-19 10:47:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:47:58 --> Final output sent to browser
DEBUG - 2024-07-19 10:47:58 --> Total execution time: 0.0338
INFO - 2024-07-19 10:47:58 --> Config Class Initialized
INFO - 2024-07-19 10:47:58 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:47:58 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:47:58 --> Utf8 Class Initialized
INFO - 2024-07-19 10:47:58 --> URI Class Initialized
INFO - 2024-07-19 10:47:58 --> Router Class Initialized
INFO - 2024-07-19 10:47:58 --> Output Class Initialized
INFO - 2024-07-19 10:47:58 --> Security Class Initialized
DEBUG - 2024-07-19 10:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:47:58 --> Input Class Initialized
INFO - 2024-07-19 10:47:58 --> Language Class Initialized
ERROR - 2024-07-19 10:47:58 --> 404 Page Not Found: /index
INFO - 2024-07-19 10:47:58 --> Config Class Initialized
INFO - 2024-07-19 10:47:58 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:47:58 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:47:58 --> Utf8 Class Initialized
INFO - 2024-07-19 10:47:58 --> URI Class Initialized
INFO - 2024-07-19 10:47:58 --> Router Class Initialized
INFO - 2024-07-19 10:47:58 --> Output Class Initialized
INFO - 2024-07-19 10:47:58 --> Security Class Initialized
DEBUG - 2024-07-19 10:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:47:58 --> Input Class Initialized
INFO - 2024-07-19 10:47:58 --> Language Class Initialized
INFO - 2024-07-19 10:47:58 --> Language Class Initialized
INFO - 2024-07-19 10:47:58 --> Config Class Initialized
INFO - 2024-07-19 10:47:58 --> Loader Class Initialized
INFO - 2024-07-19 10:47:58 --> Helper loaded: url_helper
INFO - 2024-07-19 10:47:58 --> Helper loaded: file_helper
INFO - 2024-07-19 10:47:58 --> Helper loaded: form_helper
INFO - 2024-07-19 10:47:58 --> Helper loaded: my_helper
INFO - 2024-07-19 10:47:58 --> Database Driver Class Initialized
INFO - 2024-07-19 10:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:47:58 --> Controller Class Initialized
INFO - 2024-07-19 10:48:04 --> Config Class Initialized
INFO - 2024-07-19 10:48:04 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:48:04 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:48:04 --> Utf8 Class Initialized
INFO - 2024-07-19 10:48:04 --> URI Class Initialized
INFO - 2024-07-19 10:48:04 --> Router Class Initialized
INFO - 2024-07-19 10:48:04 --> Output Class Initialized
INFO - 2024-07-19 10:48:04 --> Security Class Initialized
DEBUG - 2024-07-19 10:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:48:04 --> Input Class Initialized
INFO - 2024-07-19 10:48:04 --> Language Class Initialized
INFO - 2024-07-19 10:48:04 --> Language Class Initialized
INFO - 2024-07-19 10:48:04 --> Config Class Initialized
INFO - 2024-07-19 10:48:04 --> Loader Class Initialized
INFO - 2024-07-19 10:48:04 --> Helper loaded: url_helper
INFO - 2024-07-19 10:48:04 --> Helper loaded: file_helper
INFO - 2024-07-19 10:48:04 --> Helper loaded: form_helper
INFO - 2024-07-19 10:48:04 --> Helper loaded: my_helper
INFO - 2024-07-19 10:48:04 --> Database Driver Class Initialized
INFO - 2024-07-19 10:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:48:04 --> Controller Class Initialized
DEBUG - 2024-07-19 10:48:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2024-07-19 10:48:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:48:04 --> Final output sent to browser
DEBUG - 2024-07-19 10:48:04 --> Total execution time: 0.0541
INFO - 2024-07-19 10:48:04 --> Config Class Initialized
INFO - 2024-07-19 10:48:04 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:48:04 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:48:04 --> Utf8 Class Initialized
INFO - 2024-07-19 10:48:04 --> URI Class Initialized
INFO - 2024-07-19 10:48:04 --> Router Class Initialized
INFO - 2024-07-19 10:48:04 --> Output Class Initialized
INFO - 2024-07-19 10:48:04 --> Security Class Initialized
DEBUG - 2024-07-19 10:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:48:04 --> Input Class Initialized
INFO - 2024-07-19 10:48:04 --> Language Class Initialized
ERROR - 2024-07-19 10:48:04 --> 404 Page Not Found: /index
INFO - 2024-07-19 10:48:04 --> Config Class Initialized
INFO - 2024-07-19 10:48:04 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:48:04 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:48:04 --> Utf8 Class Initialized
INFO - 2024-07-19 10:48:04 --> URI Class Initialized
INFO - 2024-07-19 10:48:04 --> Router Class Initialized
INFO - 2024-07-19 10:48:04 --> Output Class Initialized
INFO - 2024-07-19 10:48:04 --> Security Class Initialized
DEBUG - 2024-07-19 10:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:48:04 --> Input Class Initialized
INFO - 2024-07-19 10:48:04 --> Language Class Initialized
INFO - 2024-07-19 10:48:04 --> Language Class Initialized
INFO - 2024-07-19 10:48:04 --> Config Class Initialized
INFO - 2024-07-19 10:48:04 --> Loader Class Initialized
INFO - 2024-07-19 10:48:04 --> Helper loaded: url_helper
INFO - 2024-07-19 10:48:04 --> Helper loaded: file_helper
INFO - 2024-07-19 10:48:04 --> Helper loaded: form_helper
INFO - 2024-07-19 10:48:04 --> Helper loaded: my_helper
INFO - 2024-07-19 10:48:04 --> Database Driver Class Initialized
INFO - 2024-07-19 10:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:48:04 --> Controller Class Initialized
INFO - 2024-07-19 10:48:05 --> Config Class Initialized
INFO - 2024-07-19 10:48:05 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:48:05 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:48:05 --> Utf8 Class Initialized
INFO - 2024-07-19 10:48:05 --> URI Class Initialized
INFO - 2024-07-19 10:48:05 --> Router Class Initialized
INFO - 2024-07-19 10:48:05 --> Output Class Initialized
INFO - 2024-07-19 10:48:05 --> Security Class Initialized
DEBUG - 2024-07-19 10:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:48:05 --> Input Class Initialized
INFO - 2024-07-19 10:48:05 --> Language Class Initialized
INFO - 2024-07-19 10:48:05 --> Language Class Initialized
INFO - 2024-07-19 10:48:05 --> Config Class Initialized
INFO - 2024-07-19 10:48:05 --> Loader Class Initialized
INFO - 2024-07-19 10:48:05 --> Helper loaded: url_helper
INFO - 2024-07-19 10:48:05 --> Helper loaded: file_helper
INFO - 2024-07-19 10:48:05 --> Helper loaded: form_helper
INFO - 2024-07-19 10:48:05 --> Helper loaded: my_helper
INFO - 2024-07-19 10:48:05 --> Database Driver Class Initialized
INFO - 2024-07-19 10:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:48:05 --> Controller Class Initialized
DEBUG - 2024-07-19 10:48:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_ekstra/views/list.php
DEBUG - 2024-07-19 10:48:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:48:05 --> Final output sent to browser
DEBUG - 2024-07-19 10:48:05 --> Total execution time: 0.0505
INFO - 2024-07-19 10:48:05 --> Config Class Initialized
INFO - 2024-07-19 10:48:05 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:48:05 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:48:05 --> Utf8 Class Initialized
INFO - 2024-07-19 10:48:05 --> URI Class Initialized
INFO - 2024-07-19 10:48:05 --> Router Class Initialized
INFO - 2024-07-19 10:48:05 --> Output Class Initialized
INFO - 2024-07-19 10:48:05 --> Security Class Initialized
DEBUG - 2024-07-19 10:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:48:05 --> Input Class Initialized
INFO - 2024-07-19 10:48:05 --> Language Class Initialized
ERROR - 2024-07-19 10:48:05 --> 404 Page Not Found: /index
INFO - 2024-07-19 10:48:05 --> Config Class Initialized
INFO - 2024-07-19 10:48:05 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:48:05 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:48:05 --> Utf8 Class Initialized
INFO - 2024-07-19 10:48:05 --> URI Class Initialized
INFO - 2024-07-19 10:48:05 --> Router Class Initialized
INFO - 2024-07-19 10:48:05 --> Output Class Initialized
INFO - 2024-07-19 10:48:05 --> Security Class Initialized
DEBUG - 2024-07-19 10:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:48:05 --> Input Class Initialized
INFO - 2024-07-19 10:48:05 --> Language Class Initialized
INFO - 2024-07-19 10:48:05 --> Language Class Initialized
INFO - 2024-07-19 10:48:05 --> Config Class Initialized
INFO - 2024-07-19 10:48:05 --> Loader Class Initialized
INFO - 2024-07-19 10:48:05 --> Helper loaded: url_helper
INFO - 2024-07-19 10:48:05 --> Helper loaded: file_helper
INFO - 2024-07-19 10:48:05 --> Helper loaded: form_helper
INFO - 2024-07-19 10:48:05 --> Helper loaded: my_helper
INFO - 2024-07-19 10:48:05 --> Database Driver Class Initialized
INFO - 2024-07-19 10:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:48:05 --> Controller Class Initialized
INFO - 2024-07-19 10:48:09 --> Config Class Initialized
INFO - 2024-07-19 10:48:09 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:48:09 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:48:09 --> Utf8 Class Initialized
INFO - 2024-07-19 10:48:09 --> URI Class Initialized
INFO - 2024-07-19 10:48:09 --> Router Class Initialized
INFO - 2024-07-19 10:48:09 --> Output Class Initialized
INFO - 2024-07-19 10:48:09 --> Security Class Initialized
DEBUG - 2024-07-19 10:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:48:09 --> Input Class Initialized
INFO - 2024-07-19 10:48:09 --> Language Class Initialized
INFO - 2024-07-19 10:48:09 --> Language Class Initialized
INFO - 2024-07-19 10:48:09 --> Config Class Initialized
INFO - 2024-07-19 10:48:09 --> Loader Class Initialized
INFO - 2024-07-19 10:48:09 --> Helper loaded: url_helper
INFO - 2024-07-19 10:48:09 --> Helper loaded: file_helper
INFO - 2024-07-19 10:48:09 --> Helper loaded: form_helper
INFO - 2024-07-19 10:48:09 --> Helper loaded: my_helper
INFO - 2024-07-19 10:48:09 --> Database Driver Class Initialized
INFO - 2024-07-19 10:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:48:09 --> Controller Class Initialized
DEBUG - 2024-07-19 10:48:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_walikelas/views/list.php
DEBUG - 2024-07-19 10:48:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:48:09 --> Final output sent to browser
DEBUG - 2024-07-19 10:48:09 --> Total execution time: 0.0612
INFO - 2024-07-19 10:48:09 --> Config Class Initialized
INFO - 2024-07-19 10:48:09 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:48:09 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:48:09 --> Utf8 Class Initialized
INFO - 2024-07-19 10:48:09 --> URI Class Initialized
INFO - 2024-07-19 10:48:09 --> Router Class Initialized
INFO - 2024-07-19 10:48:09 --> Output Class Initialized
INFO - 2024-07-19 10:48:09 --> Security Class Initialized
DEBUG - 2024-07-19 10:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:48:09 --> Input Class Initialized
INFO - 2024-07-19 10:48:09 --> Language Class Initialized
ERROR - 2024-07-19 10:48:09 --> 404 Page Not Found: /index
INFO - 2024-07-19 10:48:09 --> Config Class Initialized
INFO - 2024-07-19 10:48:09 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:48:09 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:48:09 --> Utf8 Class Initialized
INFO - 2024-07-19 10:48:09 --> URI Class Initialized
INFO - 2024-07-19 10:48:09 --> Router Class Initialized
INFO - 2024-07-19 10:48:09 --> Output Class Initialized
INFO - 2024-07-19 10:48:09 --> Security Class Initialized
DEBUG - 2024-07-19 10:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:48:09 --> Input Class Initialized
INFO - 2024-07-19 10:48:09 --> Language Class Initialized
INFO - 2024-07-19 10:48:09 --> Language Class Initialized
INFO - 2024-07-19 10:48:09 --> Config Class Initialized
INFO - 2024-07-19 10:48:09 --> Loader Class Initialized
INFO - 2024-07-19 10:48:09 --> Helper loaded: url_helper
INFO - 2024-07-19 10:48:09 --> Helper loaded: file_helper
INFO - 2024-07-19 10:48:09 --> Helper loaded: form_helper
INFO - 2024-07-19 10:48:09 --> Helper loaded: my_helper
INFO - 2024-07-19 10:48:09 --> Database Driver Class Initialized
INFO - 2024-07-19 10:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:48:09 --> Controller Class Initialized
INFO - 2024-07-19 10:48:14 --> Config Class Initialized
INFO - 2024-07-19 10:48:14 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:48:14 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:48:14 --> Utf8 Class Initialized
INFO - 2024-07-19 10:48:14 --> URI Class Initialized
INFO - 2024-07-19 10:48:14 --> Router Class Initialized
INFO - 2024-07-19 10:48:14 --> Output Class Initialized
INFO - 2024-07-19 10:48:14 --> Security Class Initialized
DEBUG - 2024-07-19 10:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:48:14 --> Input Class Initialized
INFO - 2024-07-19 10:48:14 --> Language Class Initialized
INFO - 2024-07-19 10:48:14 --> Language Class Initialized
INFO - 2024-07-19 10:48:14 --> Config Class Initialized
INFO - 2024-07-19 10:48:14 --> Loader Class Initialized
INFO - 2024-07-19 10:48:14 --> Helper loaded: url_helper
INFO - 2024-07-19 10:48:14 --> Helper loaded: file_helper
INFO - 2024-07-19 10:48:14 --> Helper loaded: form_helper
INFO - 2024-07-19 10:48:14 --> Helper loaded: my_helper
INFO - 2024-07-19 10:48:14 --> Database Driver Class Initialized
INFO - 2024-07-19 10:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:48:14 --> Controller Class Initialized
DEBUG - 2024-07-19 10:48:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/pengumuman/views/list.php
DEBUG - 2024-07-19 10:48:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:48:14 --> Final output sent to browser
DEBUG - 2024-07-19 10:48:14 --> Total execution time: 0.0471
INFO - 2024-07-19 10:48:14 --> Config Class Initialized
INFO - 2024-07-19 10:48:14 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:48:14 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:48:14 --> Utf8 Class Initialized
INFO - 2024-07-19 10:48:14 --> URI Class Initialized
INFO - 2024-07-19 10:48:14 --> Router Class Initialized
INFO - 2024-07-19 10:48:14 --> Output Class Initialized
INFO - 2024-07-19 10:48:14 --> Security Class Initialized
DEBUG - 2024-07-19 10:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:48:14 --> Input Class Initialized
INFO - 2024-07-19 10:48:14 --> Language Class Initialized
ERROR - 2024-07-19 10:48:14 --> 404 Page Not Found: /index
INFO - 2024-07-19 10:48:14 --> Config Class Initialized
INFO - 2024-07-19 10:48:14 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:48:14 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:48:14 --> Utf8 Class Initialized
INFO - 2024-07-19 10:48:14 --> URI Class Initialized
INFO - 2024-07-19 10:48:14 --> Router Class Initialized
INFO - 2024-07-19 10:48:14 --> Output Class Initialized
INFO - 2024-07-19 10:48:14 --> Security Class Initialized
DEBUG - 2024-07-19 10:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:48:14 --> Input Class Initialized
INFO - 2024-07-19 10:48:14 --> Language Class Initialized
INFO - 2024-07-19 10:48:14 --> Language Class Initialized
INFO - 2024-07-19 10:48:14 --> Config Class Initialized
INFO - 2024-07-19 10:48:14 --> Loader Class Initialized
INFO - 2024-07-19 10:48:14 --> Helper loaded: url_helper
INFO - 2024-07-19 10:48:14 --> Helper loaded: file_helper
INFO - 2024-07-19 10:48:14 --> Helper loaded: form_helper
INFO - 2024-07-19 10:48:14 --> Helper loaded: my_helper
INFO - 2024-07-19 10:48:14 --> Database Driver Class Initialized
INFO - 2024-07-19 10:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:48:14 --> Controller Class Initialized
INFO - 2024-07-19 10:48:58 --> Config Class Initialized
INFO - 2024-07-19 10:48:58 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:48:58 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:48:58 --> Utf8 Class Initialized
INFO - 2024-07-19 10:48:58 --> URI Class Initialized
INFO - 2024-07-19 10:48:58 --> Router Class Initialized
INFO - 2024-07-19 10:48:58 --> Output Class Initialized
INFO - 2024-07-19 10:48:58 --> Security Class Initialized
DEBUG - 2024-07-19 10:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:48:58 --> Input Class Initialized
INFO - 2024-07-19 10:48:58 --> Language Class Initialized
INFO - 2024-07-19 10:48:58 --> Language Class Initialized
INFO - 2024-07-19 10:48:58 --> Config Class Initialized
INFO - 2024-07-19 10:48:58 --> Loader Class Initialized
INFO - 2024-07-19 10:48:58 --> Helper loaded: url_helper
INFO - 2024-07-19 10:48:58 --> Helper loaded: file_helper
INFO - 2024-07-19 10:48:58 --> Helper loaded: form_helper
INFO - 2024-07-19 10:48:58 --> Helper loaded: my_helper
INFO - 2024-07-19 10:48:58 --> Database Driver Class Initialized
INFO - 2024-07-19 10:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:48:58 --> Controller Class Initialized
DEBUG - 2024-07-19 10:48:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-19 10:48:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:48:58 --> Final output sent to browser
DEBUG - 2024-07-19 10:48:58 --> Total execution time: 0.0318
INFO - 2024-07-19 10:48:58 --> Config Class Initialized
INFO - 2024-07-19 10:48:58 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:48:58 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:48:58 --> Utf8 Class Initialized
INFO - 2024-07-19 10:48:58 --> URI Class Initialized
INFO - 2024-07-19 10:48:58 --> Router Class Initialized
INFO - 2024-07-19 10:48:58 --> Output Class Initialized
INFO - 2024-07-19 10:48:58 --> Security Class Initialized
DEBUG - 2024-07-19 10:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:48:58 --> Input Class Initialized
INFO - 2024-07-19 10:48:58 --> Language Class Initialized
ERROR - 2024-07-19 10:48:58 --> 404 Page Not Found: /index
INFO - 2024-07-19 10:48:59 --> Config Class Initialized
INFO - 2024-07-19 10:48:59 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:48:59 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:48:59 --> Utf8 Class Initialized
INFO - 2024-07-19 10:48:59 --> URI Class Initialized
INFO - 2024-07-19 10:48:59 --> Router Class Initialized
INFO - 2024-07-19 10:48:59 --> Output Class Initialized
INFO - 2024-07-19 10:48:59 --> Security Class Initialized
DEBUG - 2024-07-19 10:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:48:59 --> Input Class Initialized
INFO - 2024-07-19 10:48:59 --> Language Class Initialized
INFO - 2024-07-19 10:48:59 --> Language Class Initialized
INFO - 2024-07-19 10:48:59 --> Config Class Initialized
INFO - 2024-07-19 10:48:59 --> Loader Class Initialized
INFO - 2024-07-19 10:48:59 --> Helper loaded: url_helper
INFO - 2024-07-19 10:48:59 --> Helper loaded: file_helper
INFO - 2024-07-19 10:48:59 --> Helper loaded: form_helper
INFO - 2024-07-19 10:48:59 --> Helper loaded: my_helper
INFO - 2024-07-19 10:48:59 --> Database Driver Class Initialized
INFO - 2024-07-19 10:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:48:59 --> Controller Class Initialized
INFO - 2024-07-19 10:49:01 --> Config Class Initialized
INFO - 2024-07-19 10:49:01 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:49:01 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:49:01 --> Utf8 Class Initialized
INFO - 2024-07-19 10:49:01 --> URI Class Initialized
INFO - 2024-07-19 10:49:01 --> Router Class Initialized
INFO - 2024-07-19 10:49:01 --> Output Class Initialized
INFO - 2024-07-19 10:49:01 --> Security Class Initialized
DEBUG - 2024-07-19 10:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:49:01 --> Input Class Initialized
INFO - 2024-07-19 10:49:01 --> Language Class Initialized
INFO - 2024-07-19 10:49:01 --> Language Class Initialized
INFO - 2024-07-19 10:49:01 --> Config Class Initialized
INFO - 2024-07-19 10:49:01 --> Loader Class Initialized
INFO - 2024-07-19 10:49:01 --> Helper loaded: url_helper
INFO - 2024-07-19 10:49:01 --> Helper loaded: file_helper
INFO - 2024-07-19 10:49:01 --> Helper loaded: form_helper
INFO - 2024-07-19 10:49:01 --> Helper loaded: my_helper
INFO - 2024-07-19 10:49:01 --> Database Driver Class Initialized
INFO - 2024-07-19 10:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:49:01 --> Controller Class Initialized
INFO - 2024-07-19 10:49:09 --> Config Class Initialized
INFO - 2024-07-19 10:49:09 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:49:09 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:49:09 --> Utf8 Class Initialized
INFO - 2024-07-19 10:49:09 --> URI Class Initialized
INFO - 2024-07-19 10:49:09 --> Router Class Initialized
INFO - 2024-07-19 10:49:09 --> Output Class Initialized
INFO - 2024-07-19 10:49:09 --> Security Class Initialized
DEBUG - 2024-07-19 10:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:49:09 --> Input Class Initialized
INFO - 2024-07-19 10:49:09 --> Language Class Initialized
INFO - 2024-07-19 10:49:09 --> Language Class Initialized
INFO - 2024-07-19 10:49:09 --> Config Class Initialized
INFO - 2024-07-19 10:49:09 --> Loader Class Initialized
INFO - 2024-07-19 10:49:09 --> Helper loaded: url_helper
INFO - 2024-07-19 10:49:09 --> Helper loaded: file_helper
INFO - 2024-07-19 10:49:09 --> Helper loaded: form_helper
INFO - 2024-07-19 10:49:09 --> Helper loaded: my_helper
INFO - 2024-07-19 10:49:09 --> Database Driver Class Initialized
INFO - 2024-07-19 10:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:49:09 --> Controller Class Initialized
INFO - 2024-07-19 10:49:09 --> Final output sent to browser
DEBUG - 2024-07-19 10:49:09 --> Total execution time: 0.1520
INFO - 2024-07-19 10:49:09 --> Config Class Initialized
INFO - 2024-07-19 10:49:09 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:49:09 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:49:09 --> Utf8 Class Initialized
INFO - 2024-07-19 10:49:09 --> URI Class Initialized
INFO - 2024-07-19 10:49:09 --> Router Class Initialized
INFO - 2024-07-19 10:49:09 --> Output Class Initialized
INFO - 2024-07-19 10:49:09 --> Security Class Initialized
DEBUG - 2024-07-19 10:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:49:09 --> Input Class Initialized
INFO - 2024-07-19 10:49:09 --> Language Class Initialized
ERROR - 2024-07-19 10:49:09 --> 404 Page Not Found: /index
INFO - 2024-07-19 10:49:09 --> Config Class Initialized
INFO - 2024-07-19 10:49:09 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:49:09 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:49:09 --> Utf8 Class Initialized
INFO - 2024-07-19 10:49:09 --> URI Class Initialized
INFO - 2024-07-19 10:49:09 --> Router Class Initialized
INFO - 2024-07-19 10:49:09 --> Output Class Initialized
INFO - 2024-07-19 10:49:09 --> Security Class Initialized
DEBUG - 2024-07-19 10:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:49:09 --> Input Class Initialized
INFO - 2024-07-19 10:49:09 --> Language Class Initialized
INFO - 2024-07-19 10:49:09 --> Language Class Initialized
INFO - 2024-07-19 10:49:09 --> Config Class Initialized
INFO - 2024-07-19 10:49:09 --> Loader Class Initialized
INFO - 2024-07-19 10:49:09 --> Helper loaded: url_helper
INFO - 2024-07-19 10:49:09 --> Helper loaded: file_helper
INFO - 2024-07-19 10:49:09 --> Helper loaded: form_helper
INFO - 2024-07-19 10:49:09 --> Helper loaded: my_helper
INFO - 2024-07-19 10:49:09 --> Database Driver Class Initialized
INFO - 2024-07-19 10:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:49:09 --> Controller Class Initialized
INFO - 2024-07-19 10:49:11 --> Config Class Initialized
INFO - 2024-07-19 10:49:11 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:49:11 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:49:11 --> Utf8 Class Initialized
INFO - 2024-07-19 10:49:11 --> URI Class Initialized
INFO - 2024-07-19 10:49:11 --> Router Class Initialized
INFO - 2024-07-19 10:49:11 --> Output Class Initialized
INFO - 2024-07-19 10:49:11 --> Security Class Initialized
DEBUG - 2024-07-19 10:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:49:11 --> Input Class Initialized
INFO - 2024-07-19 10:49:11 --> Language Class Initialized
INFO - 2024-07-19 10:49:11 --> Language Class Initialized
INFO - 2024-07-19 10:49:11 --> Config Class Initialized
INFO - 2024-07-19 10:49:11 --> Loader Class Initialized
INFO - 2024-07-19 10:49:11 --> Helper loaded: url_helper
INFO - 2024-07-19 10:49:11 --> Helper loaded: file_helper
INFO - 2024-07-19 10:49:11 --> Helper loaded: form_helper
INFO - 2024-07-19 10:49:11 --> Helper loaded: my_helper
INFO - 2024-07-19 10:49:11 --> Database Driver Class Initialized
INFO - 2024-07-19 10:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:49:11 --> Controller Class Initialized
INFO - 2024-07-19 10:49:12 --> Config Class Initialized
INFO - 2024-07-19 10:49:12 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:49:12 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:49:12 --> Utf8 Class Initialized
INFO - 2024-07-19 10:49:12 --> URI Class Initialized
INFO - 2024-07-19 10:49:12 --> Router Class Initialized
INFO - 2024-07-19 10:49:12 --> Output Class Initialized
INFO - 2024-07-19 10:49:12 --> Security Class Initialized
DEBUG - 2024-07-19 10:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:49:12 --> Input Class Initialized
INFO - 2024-07-19 10:49:12 --> Language Class Initialized
INFO - 2024-07-19 10:49:12 --> Language Class Initialized
INFO - 2024-07-19 10:49:12 --> Config Class Initialized
INFO - 2024-07-19 10:49:12 --> Loader Class Initialized
INFO - 2024-07-19 10:49:12 --> Helper loaded: url_helper
INFO - 2024-07-19 10:49:12 --> Helper loaded: file_helper
INFO - 2024-07-19 10:49:12 --> Helper loaded: form_helper
INFO - 2024-07-19 10:49:12 --> Helper loaded: my_helper
INFO - 2024-07-19 10:49:12 --> Database Driver Class Initialized
INFO - 2024-07-19 10:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:49:12 --> Controller Class Initialized
INFO - 2024-07-19 10:49:15 --> Config Class Initialized
INFO - 2024-07-19 10:49:15 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:49:15 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:49:15 --> Utf8 Class Initialized
INFO - 2024-07-19 10:49:15 --> URI Class Initialized
INFO - 2024-07-19 10:49:15 --> Router Class Initialized
INFO - 2024-07-19 10:49:15 --> Output Class Initialized
INFO - 2024-07-19 10:49:15 --> Security Class Initialized
DEBUG - 2024-07-19 10:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:49:15 --> Input Class Initialized
INFO - 2024-07-19 10:49:15 --> Language Class Initialized
INFO - 2024-07-19 10:49:15 --> Language Class Initialized
INFO - 2024-07-19 10:49:15 --> Config Class Initialized
INFO - 2024-07-19 10:49:15 --> Loader Class Initialized
INFO - 2024-07-19 10:49:15 --> Helper loaded: url_helper
INFO - 2024-07-19 10:49:15 --> Helper loaded: file_helper
INFO - 2024-07-19 10:49:15 --> Helper loaded: form_helper
INFO - 2024-07-19 10:49:15 --> Helper loaded: my_helper
INFO - 2024-07-19 10:49:15 --> Database Driver Class Initialized
INFO - 2024-07-19 10:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:49:15 --> Controller Class Initialized
INFO - 2024-07-19 10:49:18 --> Config Class Initialized
INFO - 2024-07-19 10:49:18 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:49:18 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:49:18 --> Utf8 Class Initialized
INFO - 2024-07-19 10:49:18 --> URI Class Initialized
INFO - 2024-07-19 10:49:18 --> Router Class Initialized
INFO - 2024-07-19 10:49:18 --> Output Class Initialized
INFO - 2024-07-19 10:49:18 --> Security Class Initialized
DEBUG - 2024-07-19 10:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:49:18 --> Input Class Initialized
INFO - 2024-07-19 10:49:18 --> Language Class Initialized
INFO - 2024-07-19 10:49:18 --> Language Class Initialized
INFO - 2024-07-19 10:49:18 --> Config Class Initialized
INFO - 2024-07-19 10:49:18 --> Loader Class Initialized
INFO - 2024-07-19 10:49:18 --> Helper loaded: url_helper
INFO - 2024-07-19 10:49:18 --> Helper loaded: file_helper
INFO - 2024-07-19 10:49:18 --> Helper loaded: form_helper
INFO - 2024-07-19 10:49:18 --> Helper loaded: my_helper
INFO - 2024-07-19 10:49:18 --> Database Driver Class Initialized
INFO - 2024-07-19 10:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:49:18 --> Controller Class Initialized
INFO - 2024-07-19 10:49:32 --> Config Class Initialized
INFO - 2024-07-19 10:49:32 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:49:32 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:49:32 --> Utf8 Class Initialized
INFO - 2024-07-19 10:49:32 --> URI Class Initialized
DEBUG - 2024-07-19 10:49:32 --> No URI present. Default controller set.
INFO - 2024-07-19 10:49:32 --> Router Class Initialized
INFO - 2024-07-19 10:49:32 --> Output Class Initialized
INFO - 2024-07-19 10:49:32 --> Security Class Initialized
DEBUG - 2024-07-19 10:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:49:32 --> Input Class Initialized
INFO - 2024-07-19 10:49:32 --> Language Class Initialized
INFO - 2024-07-19 10:49:32 --> Language Class Initialized
INFO - 2024-07-19 10:49:32 --> Config Class Initialized
INFO - 2024-07-19 10:49:32 --> Loader Class Initialized
INFO - 2024-07-19 10:49:32 --> Helper loaded: url_helper
INFO - 2024-07-19 10:49:32 --> Helper loaded: file_helper
INFO - 2024-07-19 10:49:32 --> Helper loaded: form_helper
INFO - 2024-07-19 10:49:32 --> Helper loaded: my_helper
INFO - 2024-07-19 10:49:32 --> Database Driver Class Initialized
INFO - 2024-07-19 10:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:49:32 --> Controller Class Initialized
DEBUG - 2024-07-19 10:49:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-07-19 10:49:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:49:32 --> Final output sent to browser
DEBUG - 2024-07-19 10:49:32 --> Total execution time: 0.0403
INFO - 2024-07-19 10:58:20 --> Config Class Initialized
INFO - 2024-07-19 10:58:20 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:58:20 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:58:20 --> Utf8 Class Initialized
INFO - 2024-07-19 10:58:20 --> URI Class Initialized
DEBUG - 2024-07-19 10:58:20 --> No URI present. Default controller set.
INFO - 2024-07-19 10:58:20 --> Router Class Initialized
INFO - 2024-07-19 10:58:20 --> Output Class Initialized
INFO - 2024-07-19 10:58:20 --> Security Class Initialized
DEBUG - 2024-07-19 10:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:58:20 --> Input Class Initialized
INFO - 2024-07-19 10:58:20 --> Language Class Initialized
INFO - 2024-07-19 10:58:20 --> Language Class Initialized
INFO - 2024-07-19 10:58:20 --> Config Class Initialized
INFO - 2024-07-19 10:58:20 --> Loader Class Initialized
INFO - 2024-07-19 10:58:20 --> Helper loaded: url_helper
INFO - 2024-07-19 10:58:20 --> Helper loaded: file_helper
INFO - 2024-07-19 10:58:20 --> Helper loaded: form_helper
INFO - 2024-07-19 10:58:20 --> Helper loaded: my_helper
INFO - 2024-07-19 10:58:20 --> Database Driver Class Initialized
INFO - 2024-07-19 10:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:58:20 --> Controller Class Initialized
DEBUG - 2024-07-19 10:58:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-07-19 10:58:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:58:20 --> Final output sent to browser
DEBUG - 2024-07-19 10:58:20 --> Total execution time: 0.0673
INFO - 2024-07-19 10:58:26 --> Config Class Initialized
INFO - 2024-07-19 10:58:26 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:58:26 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:58:26 --> Utf8 Class Initialized
INFO - 2024-07-19 10:58:26 --> URI Class Initialized
INFO - 2024-07-19 10:58:26 --> Router Class Initialized
INFO - 2024-07-19 10:58:26 --> Output Class Initialized
INFO - 2024-07-19 10:58:26 --> Security Class Initialized
DEBUG - 2024-07-19 10:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:58:26 --> Input Class Initialized
INFO - 2024-07-19 10:58:26 --> Language Class Initialized
INFO - 2024-07-19 10:58:26 --> Language Class Initialized
INFO - 2024-07-19 10:58:26 --> Config Class Initialized
INFO - 2024-07-19 10:58:26 --> Loader Class Initialized
INFO - 2024-07-19 10:58:26 --> Helper loaded: url_helper
INFO - 2024-07-19 10:58:26 --> Helper loaded: file_helper
INFO - 2024-07-19 10:58:26 --> Helper loaded: form_helper
INFO - 2024-07-19 10:58:26 --> Helper loaded: my_helper
INFO - 2024-07-19 10:58:26 --> Database Driver Class Initialized
INFO - 2024-07-19 10:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:58:26 --> Controller Class Initialized
DEBUG - 2024-07-19 10:58:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-19 10:58:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:58:26 --> Final output sent to browser
DEBUG - 2024-07-19 10:58:26 --> Total execution time: 0.0295
INFO - 2024-07-19 10:58:28 --> Config Class Initialized
INFO - 2024-07-19 10:58:28 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:58:28 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:58:28 --> Utf8 Class Initialized
INFO - 2024-07-19 10:58:28 --> URI Class Initialized
INFO - 2024-07-19 10:58:28 --> Router Class Initialized
INFO - 2024-07-19 10:58:28 --> Output Class Initialized
INFO - 2024-07-19 10:58:28 --> Security Class Initialized
DEBUG - 2024-07-19 10:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:58:28 --> Input Class Initialized
INFO - 2024-07-19 10:58:28 --> Language Class Initialized
INFO - 2024-07-19 10:58:28 --> Language Class Initialized
INFO - 2024-07-19 10:58:28 --> Config Class Initialized
INFO - 2024-07-19 10:58:28 --> Loader Class Initialized
INFO - 2024-07-19 10:58:28 --> Helper loaded: url_helper
INFO - 2024-07-19 10:58:28 --> Helper loaded: file_helper
INFO - 2024-07-19 10:58:28 --> Helper loaded: form_helper
INFO - 2024-07-19 10:58:28 --> Helper loaded: my_helper
INFO - 2024-07-19 10:58:28 --> Database Driver Class Initialized
INFO - 2024-07-19 10:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:58:28 --> Controller Class Initialized
INFO - 2024-07-19 10:58:28 --> Database Driver Class Initialized
INFO - 2024-07-19 10:58:29 --> Config Class Initialized
INFO - 2024-07-19 10:58:29 --> Hooks Class Initialized
DEBUG - 2024-07-19 10:58:29 --> UTF-8 Support Enabled
INFO - 2024-07-19 10:58:29 --> Utf8 Class Initialized
INFO - 2024-07-19 10:58:29 --> URI Class Initialized
INFO - 2024-07-19 10:58:29 --> Router Class Initialized
INFO - 2024-07-19 10:58:29 --> Output Class Initialized
INFO - 2024-07-19 10:58:29 --> Security Class Initialized
DEBUG - 2024-07-19 10:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 10:58:29 --> Input Class Initialized
INFO - 2024-07-19 10:58:29 --> Language Class Initialized
INFO - 2024-07-19 10:58:29 --> Language Class Initialized
INFO - 2024-07-19 10:58:29 --> Config Class Initialized
INFO - 2024-07-19 10:58:29 --> Loader Class Initialized
INFO - 2024-07-19 10:58:29 --> Helper loaded: url_helper
INFO - 2024-07-19 10:58:29 --> Helper loaded: file_helper
INFO - 2024-07-19 10:58:29 --> Helper loaded: form_helper
INFO - 2024-07-19 10:58:29 --> Helper loaded: my_helper
INFO - 2024-07-19 10:58:29 --> Database Driver Class Initialized
INFO - 2024-07-19 10:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 10:58:29 --> Controller Class Initialized
DEBUG - 2024-07-19 10:58:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-19 10:58:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 10:58:29 --> Final output sent to browser
DEBUG - 2024-07-19 10:58:29 --> Total execution time: 0.0313
INFO - 2024-07-19 11:14:55 --> Config Class Initialized
INFO - 2024-07-19 11:14:55 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:14:55 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:14:55 --> Utf8 Class Initialized
INFO - 2024-07-19 11:14:55 --> URI Class Initialized
INFO - 2024-07-19 11:14:55 --> Router Class Initialized
INFO - 2024-07-19 11:14:55 --> Output Class Initialized
INFO - 2024-07-19 11:14:55 --> Security Class Initialized
DEBUG - 2024-07-19 11:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:14:55 --> Input Class Initialized
INFO - 2024-07-19 11:14:55 --> Language Class Initialized
INFO - 2024-07-19 11:14:55 --> Language Class Initialized
INFO - 2024-07-19 11:14:55 --> Config Class Initialized
INFO - 2024-07-19 11:14:55 --> Loader Class Initialized
INFO - 2024-07-19 11:14:55 --> Helper loaded: url_helper
INFO - 2024-07-19 11:14:55 --> Helper loaded: file_helper
INFO - 2024-07-19 11:14:55 --> Helper loaded: form_helper
INFO - 2024-07-19 11:14:55 --> Helper loaded: my_helper
INFO - 2024-07-19 11:14:55 --> Database Driver Class Initialized
INFO - 2024-07-19 11:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:14:55 --> Controller Class Initialized
DEBUG - 2024-07-19 11:14:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-19 11:14:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 11:14:55 --> Final output sent to browser
DEBUG - 2024-07-19 11:14:55 --> Total execution time: 0.0458
INFO - 2024-07-19 11:14:55 --> Config Class Initialized
INFO - 2024-07-19 11:14:55 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:14:55 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:14:55 --> Utf8 Class Initialized
INFO - 2024-07-19 11:14:55 --> URI Class Initialized
INFO - 2024-07-19 11:14:55 --> Router Class Initialized
INFO - 2024-07-19 11:14:55 --> Output Class Initialized
INFO - 2024-07-19 11:14:55 --> Security Class Initialized
DEBUG - 2024-07-19 11:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:14:55 --> Input Class Initialized
INFO - 2024-07-19 11:14:55 --> Language Class Initialized
ERROR - 2024-07-19 11:14:55 --> 404 Page Not Found: /index
INFO - 2024-07-19 11:14:56 --> Config Class Initialized
INFO - 2024-07-19 11:14:56 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:14:56 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:14:56 --> Utf8 Class Initialized
INFO - 2024-07-19 11:14:56 --> URI Class Initialized
INFO - 2024-07-19 11:14:56 --> Router Class Initialized
INFO - 2024-07-19 11:14:56 --> Output Class Initialized
INFO - 2024-07-19 11:14:56 --> Security Class Initialized
DEBUG - 2024-07-19 11:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:14:56 --> Input Class Initialized
INFO - 2024-07-19 11:14:56 --> Language Class Initialized
INFO - 2024-07-19 11:14:56 --> Language Class Initialized
INFO - 2024-07-19 11:14:56 --> Config Class Initialized
INFO - 2024-07-19 11:14:56 --> Loader Class Initialized
INFO - 2024-07-19 11:14:56 --> Helper loaded: url_helper
INFO - 2024-07-19 11:14:56 --> Helper loaded: file_helper
INFO - 2024-07-19 11:14:56 --> Helper loaded: form_helper
INFO - 2024-07-19 11:14:56 --> Helper loaded: my_helper
INFO - 2024-07-19 11:14:56 --> Database Driver Class Initialized
INFO - 2024-07-19 11:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:14:56 --> Controller Class Initialized
INFO - 2024-07-19 11:14:58 --> Config Class Initialized
INFO - 2024-07-19 11:14:58 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:14:58 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:14:58 --> Utf8 Class Initialized
INFO - 2024-07-19 11:14:58 --> URI Class Initialized
INFO - 2024-07-19 11:14:58 --> Router Class Initialized
INFO - 2024-07-19 11:14:58 --> Output Class Initialized
INFO - 2024-07-19 11:14:58 --> Security Class Initialized
DEBUG - 2024-07-19 11:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:14:58 --> Input Class Initialized
INFO - 2024-07-19 11:14:58 --> Language Class Initialized
INFO - 2024-07-19 11:14:58 --> Language Class Initialized
INFO - 2024-07-19 11:14:58 --> Config Class Initialized
INFO - 2024-07-19 11:14:58 --> Loader Class Initialized
INFO - 2024-07-19 11:14:58 --> Helper loaded: url_helper
INFO - 2024-07-19 11:14:58 --> Helper loaded: file_helper
INFO - 2024-07-19 11:14:58 --> Helper loaded: form_helper
INFO - 2024-07-19 11:14:58 --> Helper loaded: my_helper
INFO - 2024-07-19 11:14:58 --> Database Driver Class Initialized
INFO - 2024-07-19 11:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:14:58 --> Controller Class Initialized
INFO - 2024-07-19 11:14:58 --> Config Class Initialized
INFO - 2024-07-19 11:14:58 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:14:58 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:14:58 --> Utf8 Class Initialized
INFO - 2024-07-19 11:14:58 --> URI Class Initialized
INFO - 2024-07-19 11:14:58 --> Router Class Initialized
INFO - 2024-07-19 11:14:58 --> Output Class Initialized
INFO - 2024-07-19 11:14:58 --> Security Class Initialized
DEBUG - 2024-07-19 11:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:14:58 --> Input Class Initialized
INFO - 2024-07-19 11:14:58 --> Language Class Initialized
INFO - 2024-07-19 11:14:58 --> Language Class Initialized
INFO - 2024-07-19 11:14:58 --> Config Class Initialized
INFO - 2024-07-19 11:14:58 --> Loader Class Initialized
INFO - 2024-07-19 11:14:58 --> Helper loaded: url_helper
INFO - 2024-07-19 11:14:58 --> Helper loaded: file_helper
INFO - 2024-07-19 11:14:58 --> Helper loaded: form_helper
INFO - 2024-07-19 11:14:58 --> Helper loaded: my_helper
INFO - 2024-07-19 11:14:58 --> Database Driver Class Initialized
INFO - 2024-07-19 11:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:14:58 --> Controller Class Initialized
INFO - 2024-07-19 11:14:59 --> Config Class Initialized
INFO - 2024-07-19 11:14:59 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:14:59 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:14:59 --> Utf8 Class Initialized
INFO - 2024-07-19 11:14:59 --> URI Class Initialized
INFO - 2024-07-19 11:14:59 --> Router Class Initialized
INFO - 2024-07-19 11:14:59 --> Output Class Initialized
INFO - 2024-07-19 11:14:59 --> Security Class Initialized
DEBUG - 2024-07-19 11:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:14:59 --> Input Class Initialized
INFO - 2024-07-19 11:14:59 --> Language Class Initialized
INFO - 2024-07-19 11:14:59 --> Language Class Initialized
INFO - 2024-07-19 11:14:59 --> Config Class Initialized
INFO - 2024-07-19 11:14:59 --> Loader Class Initialized
INFO - 2024-07-19 11:14:59 --> Helper loaded: url_helper
INFO - 2024-07-19 11:14:59 --> Helper loaded: file_helper
INFO - 2024-07-19 11:14:59 --> Helper loaded: form_helper
INFO - 2024-07-19 11:14:59 --> Helper loaded: my_helper
INFO - 2024-07-19 11:14:59 --> Database Driver Class Initialized
INFO - 2024-07-19 11:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:14:59 --> Controller Class Initialized
INFO - 2024-07-19 11:14:59 --> Config Class Initialized
INFO - 2024-07-19 11:14:59 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:14:59 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:14:59 --> Utf8 Class Initialized
INFO - 2024-07-19 11:14:59 --> URI Class Initialized
INFO - 2024-07-19 11:14:59 --> Router Class Initialized
INFO - 2024-07-19 11:14:59 --> Output Class Initialized
INFO - 2024-07-19 11:14:59 --> Security Class Initialized
DEBUG - 2024-07-19 11:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:14:59 --> Input Class Initialized
INFO - 2024-07-19 11:14:59 --> Language Class Initialized
INFO - 2024-07-19 11:14:59 --> Language Class Initialized
INFO - 2024-07-19 11:14:59 --> Config Class Initialized
INFO - 2024-07-19 11:14:59 --> Loader Class Initialized
INFO - 2024-07-19 11:14:59 --> Helper loaded: url_helper
INFO - 2024-07-19 11:14:59 --> Helper loaded: file_helper
INFO - 2024-07-19 11:14:59 --> Helper loaded: form_helper
INFO - 2024-07-19 11:14:59 --> Helper loaded: my_helper
INFO - 2024-07-19 11:14:59 --> Database Driver Class Initialized
INFO - 2024-07-19 11:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:14:59 --> Controller Class Initialized
INFO - 2024-07-19 11:15:10 --> Config Class Initialized
INFO - 2024-07-19 11:15:10 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:15:10 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:15:10 --> Utf8 Class Initialized
INFO - 2024-07-19 11:15:10 --> URI Class Initialized
INFO - 2024-07-19 11:15:10 --> Router Class Initialized
INFO - 2024-07-19 11:15:10 --> Output Class Initialized
INFO - 2024-07-19 11:15:10 --> Security Class Initialized
DEBUG - 2024-07-19 11:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:15:10 --> Input Class Initialized
INFO - 2024-07-19 11:15:10 --> Language Class Initialized
INFO - 2024-07-19 11:15:10 --> Language Class Initialized
INFO - 2024-07-19 11:15:10 --> Config Class Initialized
INFO - 2024-07-19 11:15:10 --> Loader Class Initialized
INFO - 2024-07-19 11:15:10 --> Helper loaded: url_helper
INFO - 2024-07-19 11:15:10 --> Helper loaded: file_helper
INFO - 2024-07-19 11:15:10 --> Helper loaded: form_helper
INFO - 2024-07-19 11:15:10 --> Helper loaded: my_helper
INFO - 2024-07-19 11:15:10 --> Database Driver Class Initialized
INFO - 2024-07-19 11:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:15:10 --> Controller Class Initialized
DEBUG - 2024-07-19 11:15:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-07-19 11:15:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 11:15:10 --> Final output sent to browser
DEBUG - 2024-07-19 11:15:10 --> Total execution time: 0.0316
INFO - 2024-07-19 11:15:10 --> Config Class Initialized
INFO - 2024-07-19 11:15:10 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:15:10 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:15:10 --> Utf8 Class Initialized
INFO - 2024-07-19 11:15:10 --> URI Class Initialized
INFO - 2024-07-19 11:15:10 --> Router Class Initialized
INFO - 2024-07-19 11:15:10 --> Output Class Initialized
INFO - 2024-07-19 11:15:10 --> Security Class Initialized
DEBUG - 2024-07-19 11:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:15:10 --> Input Class Initialized
INFO - 2024-07-19 11:15:10 --> Language Class Initialized
ERROR - 2024-07-19 11:15:10 --> 404 Page Not Found: /index
INFO - 2024-07-19 11:15:10 --> Config Class Initialized
INFO - 2024-07-19 11:15:10 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:15:10 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:15:10 --> Utf8 Class Initialized
INFO - 2024-07-19 11:15:10 --> URI Class Initialized
INFO - 2024-07-19 11:15:10 --> Router Class Initialized
INFO - 2024-07-19 11:15:10 --> Output Class Initialized
INFO - 2024-07-19 11:15:10 --> Security Class Initialized
DEBUG - 2024-07-19 11:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:15:10 --> Input Class Initialized
INFO - 2024-07-19 11:15:10 --> Language Class Initialized
INFO - 2024-07-19 11:15:10 --> Language Class Initialized
INFO - 2024-07-19 11:15:10 --> Config Class Initialized
INFO - 2024-07-19 11:15:10 --> Loader Class Initialized
INFO - 2024-07-19 11:15:10 --> Helper loaded: url_helper
INFO - 2024-07-19 11:15:10 --> Helper loaded: file_helper
INFO - 2024-07-19 11:15:10 --> Helper loaded: form_helper
INFO - 2024-07-19 11:15:10 --> Helper loaded: my_helper
INFO - 2024-07-19 11:15:10 --> Database Driver Class Initialized
INFO - 2024-07-19 11:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:15:10 --> Controller Class Initialized
INFO - 2024-07-19 11:15:14 --> Config Class Initialized
INFO - 2024-07-19 11:15:14 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:15:14 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:15:14 --> Utf8 Class Initialized
INFO - 2024-07-19 11:15:14 --> URI Class Initialized
INFO - 2024-07-19 11:15:14 --> Router Class Initialized
INFO - 2024-07-19 11:15:14 --> Output Class Initialized
INFO - 2024-07-19 11:15:14 --> Security Class Initialized
DEBUG - 2024-07-19 11:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:15:14 --> Input Class Initialized
INFO - 2024-07-19 11:15:14 --> Language Class Initialized
INFO - 2024-07-19 11:15:14 --> Language Class Initialized
INFO - 2024-07-19 11:15:14 --> Config Class Initialized
INFO - 2024-07-19 11:15:14 --> Loader Class Initialized
INFO - 2024-07-19 11:15:14 --> Helper loaded: url_helper
INFO - 2024-07-19 11:15:14 --> Helper loaded: file_helper
INFO - 2024-07-19 11:15:14 --> Helper loaded: form_helper
INFO - 2024-07-19 11:15:14 --> Helper loaded: my_helper
INFO - 2024-07-19 11:15:14 --> Database Driver Class Initialized
INFO - 2024-07-19 11:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:15:14 --> Controller Class Initialized
DEBUG - 2024-07-19 11:15:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-07-19 11:15:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 11:15:14 --> Final output sent to browser
DEBUG - 2024-07-19 11:15:14 --> Total execution time: 0.0612
INFO - 2024-07-19 11:15:14 --> Config Class Initialized
INFO - 2024-07-19 11:15:14 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:15:14 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:15:14 --> Utf8 Class Initialized
INFO - 2024-07-19 11:15:14 --> URI Class Initialized
INFO - 2024-07-19 11:15:14 --> Router Class Initialized
INFO - 2024-07-19 11:15:14 --> Output Class Initialized
INFO - 2024-07-19 11:15:14 --> Security Class Initialized
DEBUG - 2024-07-19 11:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:15:14 --> Input Class Initialized
INFO - 2024-07-19 11:15:14 --> Language Class Initialized
ERROR - 2024-07-19 11:15:14 --> 404 Page Not Found: /index
INFO - 2024-07-19 11:15:15 --> Config Class Initialized
INFO - 2024-07-19 11:15:15 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:15:15 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:15:15 --> Utf8 Class Initialized
INFO - 2024-07-19 11:15:15 --> URI Class Initialized
INFO - 2024-07-19 11:15:15 --> Router Class Initialized
INFO - 2024-07-19 11:15:15 --> Output Class Initialized
INFO - 2024-07-19 11:15:15 --> Security Class Initialized
DEBUG - 2024-07-19 11:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:15:15 --> Input Class Initialized
INFO - 2024-07-19 11:15:15 --> Language Class Initialized
INFO - 2024-07-19 11:15:15 --> Language Class Initialized
INFO - 2024-07-19 11:15:15 --> Config Class Initialized
INFO - 2024-07-19 11:15:15 --> Loader Class Initialized
INFO - 2024-07-19 11:15:15 --> Helper loaded: url_helper
INFO - 2024-07-19 11:15:15 --> Helper loaded: file_helper
INFO - 2024-07-19 11:15:15 --> Helper loaded: form_helper
INFO - 2024-07-19 11:15:15 --> Helper loaded: my_helper
INFO - 2024-07-19 11:15:15 --> Database Driver Class Initialized
INFO - 2024-07-19 11:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:15:15 --> Controller Class Initialized
INFO - 2024-07-19 11:15:19 --> Config Class Initialized
INFO - 2024-07-19 11:15:19 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:15:19 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:15:19 --> Utf8 Class Initialized
INFO - 2024-07-19 11:15:19 --> URI Class Initialized
INFO - 2024-07-19 11:15:19 --> Router Class Initialized
INFO - 2024-07-19 11:15:19 --> Output Class Initialized
INFO - 2024-07-19 11:15:19 --> Security Class Initialized
DEBUG - 2024-07-19 11:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:15:19 --> Input Class Initialized
INFO - 2024-07-19 11:15:19 --> Language Class Initialized
INFO - 2024-07-19 11:15:19 --> Language Class Initialized
INFO - 2024-07-19 11:15:19 --> Config Class Initialized
INFO - 2024-07-19 11:15:19 --> Loader Class Initialized
INFO - 2024-07-19 11:15:19 --> Helper loaded: url_helper
INFO - 2024-07-19 11:15:19 --> Helper loaded: file_helper
INFO - 2024-07-19 11:15:19 --> Helper loaded: form_helper
INFO - 2024-07-19 11:15:19 --> Helper loaded: my_helper
INFO - 2024-07-19 11:15:19 --> Database Driver Class Initialized
INFO - 2024-07-19 11:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:15:19 --> Controller Class Initialized
DEBUG - 2024-07-19 11:15:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-19 11:15:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 11:15:19 --> Final output sent to browser
DEBUG - 2024-07-19 11:15:19 --> Total execution time: 0.0393
INFO - 2024-07-19 11:15:23 --> Config Class Initialized
INFO - 2024-07-19 11:15:23 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:15:23 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:15:23 --> Utf8 Class Initialized
INFO - 2024-07-19 11:15:23 --> URI Class Initialized
INFO - 2024-07-19 11:15:23 --> Router Class Initialized
INFO - 2024-07-19 11:15:23 --> Output Class Initialized
INFO - 2024-07-19 11:15:23 --> Security Class Initialized
DEBUG - 2024-07-19 11:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:15:23 --> Input Class Initialized
INFO - 2024-07-19 11:15:23 --> Language Class Initialized
INFO - 2024-07-19 11:15:23 --> Language Class Initialized
INFO - 2024-07-19 11:15:23 --> Config Class Initialized
INFO - 2024-07-19 11:15:23 --> Loader Class Initialized
INFO - 2024-07-19 11:15:23 --> Helper loaded: url_helper
INFO - 2024-07-19 11:15:23 --> Helper loaded: file_helper
INFO - 2024-07-19 11:15:23 --> Helper loaded: form_helper
INFO - 2024-07-19 11:15:23 --> Helper loaded: my_helper
INFO - 2024-07-19 11:15:23 --> Database Driver Class Initialized
INFO - 2024-07-19 11:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:15:23 --> Controller Class Initialized
INFO - 2024-07-19 11:15:23 --> Database Driver Class Initialized
INFO - 2024-07-19 11:15:23 --> Config Class Initialized
INFO - 2024-07-19 11:15:23 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:15:23 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:15:23 --> Utf8 Class Initialized
INFO - 2024-07-19 11:15:23 --> URI Class Initialized
INFO - 2024-07-19 11:15:23 --> Router Class Initialized
INFO - 2024-07-19 11:15:23 --> Output Class Initialized
INFO - 2024-07-19 11:15:23 --> Security Class Initialized
DEBUG - 2024-07-19 11:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:15:23 --> Input Class Initialized
INFO - 2024-07-19 11:15:23 --> Language Class Initialized
INFO - 2024-07-19 11:15:23 --> Language Class Initialized
INFO - 2024-07-19 11:15:23 --> Config Class Initialized
INFO - 2024-07-19 11:15:23 --> Loader Class Initialized
INFO - 2024-07-19 11:15:23 --> Helper loaded: url_helper
INFO - 2024-07-19 11:15:23 --> Helper loaded: file_helper
INFO - 2024-07-19 11:15:23 --> Helper loaded: form_helper
INFO - 2024-07-19 11:15:23 --> Helper loaded: my_helper
INFO - 2024-07-19 11:15:23 --> Database Driver Class Initialized
INFO - 2024-07-19 11:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:15:23 --> Controller Class Initialized
DEBUG - 2024-07-19 11:15:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-19 11:15:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 11:15:23 --> Final output sent to browser
DEBUG - 2024-07-19 11:15:23 --> Total execution time: 0.0344
INFO - 2024-07-19 11:16:17 --> Config Class Initialized
INFO - 2024-07-19 11:16:17 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:16:17 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:16:17 --> Utf8 Class Initialized
INFO - 2024-07-19 11:16:17 --> URI Class Initialized
INFO - 2024-07-19 11:16:17 --> Router Class Initialized
INFO - 2024-07-19 11:16:17 --> Output Class Initialized
INFO - 2024-07-19 11:16:17 --> Security Class Initialized
DEBUG - 2024-07-19 11:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:16:17 --> Input Class Initialized
INFO - 2024-07-19 11:16:17 --> Language Class Initialized
INFO - 2024-07-19 11:16:17 --> Language Class Initialized
INFO - 2024-07-19 11:16:17 --> Config Class Initialized
INFO - 2024-07-19 11:16:17 --> Loader Class Initialized
INFO - 2024-07-19 11:16:17 --> Helper loaded: url_helper
INFO - 2024-07-19 11:16:17 --> Helper loaded: file_helper
INFO - 2024-07-19 11:16:17 --> Helper loaded: form_helper
INFO - 2024-07-19 11:16:17 --> Helper loaded: my_helper
INFO - 2024-07-19 11:16:17 --> Database Driver Class Initialized
INFO - 2024-07-19 11:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:16:17 --> Controller Class Initialized
DEBUG - 2024-07-19 11:16:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-19 11:16:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 11:16:17 --> Final output sent to browser
DEBUG - 2024-07-19 11:16:17 --> Total execution time: 0.0305
INFO - 2024-07-19 11:16:17 --> Config Class Initialized
INFO - 2024-07-19 11:16:17 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:16:17 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:16:17 --> Utf8 Class Initialized
INFO - 2024-07-19 11:16:17 --> URI Class Initialized
INFO - 2024-07-19 11:16:17 --> Router Class Initialized
INFO - 2024-07-19 11:16:17 --> Output Class Initialized
INFO - 2024-07-19 11:16:17 --> Security Class Initialized
DEBUG - 2024-07-19 11:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:16:17 --> Input Class Initialized
INFO - 2024-07-19 11:16:17 --> Language Class Initialized
ERROR - 2024-07-19 11:16:17 --> 404 Page Not Found: /index
INFO - 2024-07-19 11:16:17 --> Config Class Initialized
INFO - 2024-07-19 11:16:17 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:16:17 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:16:17 --> Utf8 Class Initialized
INFO - 2024-07-19 11:16:17 --> URI Class Initialized
INFO - 2024-07-19 11:16:17 --> Router Class Initialized
INFO - 2024-07-19 11:16:17 --> Output Class Initialized
INFO - 2024-07-19 11:16:17 --> Security Class Initialized
DEBUG - 2024-07-19 11:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:16:17 --> Input Class Initialized
INFO - 2024-07-19 11:16:17 --> Language Class Initialized
INFO - 2024-07-19 11:16:17 --> Language Class Initialized
INFO - 2024-07-19 11:16:17 --> Config Class Initialized
INFO - 2024-07-19 11:16:17 --> Loader Class Initialized
INFO - 2024-07-19 11:16:17 --> Helper loaded: url_helper
INFO - 2024-07-19 11:16:17 --> Helper loaded: file_helper
INFO - 2024-07-19 11:16:17 --> Helper loaded: form_helper
INFO - 2024-07-19 11:16:17 --> Helper loaded: my_helper
INFO - 2024-07-19 11:16:17 --> Database Driver Class Initialized
INFO - 2024-07-19 11:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:16:17 --> Controller Class Initialized
INFO - 2024-07-19 11:16:19 --> Config Class Initialized
INFO - 2024-07-19 11:16:19 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:16:19 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:16:19 --> Utf8 Class Initialized
INFO - 2024-07-19 11:16:19 --> URI Class Initialized
INFO - 2024-07-19 11:16:19 --> Router Class Initialized
INFO - 2024-07-19 11:16:19 --> Output Class Initialized
INFO - 2024-07-19 11:16:19 --> Security Class Initialized
DEBUG - 2024-07-19 11:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:16:19 --> Input Class Initialized
INFO - 2024-07-19 11:16:19 --> Language Class Initialized
INFO - 2024-07-19 11:16:19 --> Language Class Initialized
INFO - 2024-07-19 11:16:19 --> Config Class Initialized
INFO - 2024-07-19 11:16:19 --> Loader Class Initialized
INFO - 2024-07-19 11:16:19 --> Helper loaded: url_helper
INFO - 2024-07-19 11:16:19 --> Helper loaded: file_helper
INFO - 2024-07-19 11:16:19 --> Helper loaded: form_helper
INFO - 2024-07-19 11:16:19 --> Helper loaded: my_helper
INFO - 2024-07-19 11:16:19 --> Database Driver Class Initialized
INFO - 2024-07-19 11:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:16:19 --> Controller Class Initialized
INFO - 2024-07-19 11:16:20 --> Config Class Initialized
INFO - 2024-07-19 11:16:20 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:16:20 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:16:20 --> Utf8 Class Initialized
INFO - 2024-07-19 11:16:20 --> URI Class Initialized
INFO - 2024-07-19 11:16:20 --> Router Class Initialized
INFO - 2024-07-19 11:16:20 --> Output Class Initialized
INFO - 2024-07-19 11:16:20 --> Security Class Initialized
DEBUG - 2024-07-19 11:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:16:20 --> Input Class Initialized
INFO - 2024-07-19 11:16:20 --> Language Class Initialized
INFO - 2024-07-19 11:16:20 --> Language Class Initialized
INFO - 2024-07-19 11:16:20 --> Config Class Initialized
INFO - 2024-07-19 11:16:20 --> Loader Class Initialized
INFO - 2024-07-19 11:16:20 --> Helper loaded: url_helper
INFO - 2024-07-19 11:16:20 --> Helper loaded: file_helper
INFO - 2024-07-19 11:16:20 --> Helper loaded: form_helper
INFO - 2024-07-19 11:16:20 --> Helper loaded: my_helper
INFO - 2024-07-19 11:16:20 --> Database Driver Class Initialized
INFO - 2024-07-19 11:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:16:20 --> Controller Class Initialized
INFO - 2024-07-19 11:16:20 --> Config Class Initialized
INFO - 2024-07-19 11:16:20 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:16:21 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:16:21 --> Utf8 Class Initialized
INFO - 2024-07-19 11:16:21 --> URI Class Initialized
INFO - 2024-07-19 11:16:21 --> Router Class Initialized
INFO - 2024-07-19 11:16:21 --> Output Class Initialized
INFO - 2024-07-19 11:16:21 --> Security Class Initialized
DEBUG - 2024-07-19 11:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:16:21 --> Input Class Initialized
INFO - 2024-07-19 11:16:21 --> Language Class Initialized
INFO - 2024-07-19 11:16:21 --> Language Class Initialized
INFO - 2024-07-19 11:16:21 --> Config Class Initialized
INFO - 2024-07-19 11:16:21 --> Loader Class Initialized
INFO - 2024-07-19 11:16:21 --> Helper loaded: url_helper
INFO - 2024-07-19 11:16:21 --> Helper loaded: file_helper
INFO - 2024-07-19 11:16:21 --> Helper loaded: form_helper
INFO - 2024-07-19 11:16:21 --> Helper loaded: my_helper
INFO - 2024-07-19 11:16:21 --> Database Driver Class Initialized
INFO - 2024-07-19 11:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:16:21 --> Controller Class Initialized
INFO - 2024-07-19 11:16:22 --> Config Class Initialized
INFO - 2024-07-19 11:16:22 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:16:22 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:16:22 --> Utf8 Class Initialized
INFO - 2024-07-19 11:16:22 --> URI Class Initialized
INFO - 2024-07-19 11:16:22 --> Router Class Initialized
INFO - 2024-07-19 11:16:22 --> Output Class Initialized
INFO - 2024-07-19 11:16:22 --> Security Class Initialized
DEBUG - 2024-07-19 11:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:16:22 --> Input Class Initialized
INFO - 2024-07-19 11:16:22 --> Language Class Initialized
INFO - 2024-07-19 11:16:22 --> Language Class Initialized
INFO - 2024-07-19 11:16:22 --> Config Class Initialized
INFO - 2024-07-19 11:16:22 --> Loader Class Initialized
INFO - 2024-07-19 11:16:22 --> Helper loaded: url_helper
INFO - 2024-07-19 11:16:22 --> Helper loaded: file_helper
INFO - 2024-07-19 11:16:22 --> Helper loaded: form_helper
INFO - 2024-07-19 11:16:22 --> Helper loaded: my_helper
INFO - 2024-07-19 11:16:22 --> Database Driver Class Initialized
INFO - 2024-07-19 11:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:16:22 --> Controller Class Initialized
ERROR - 2024-07-19 11:16:22 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-07-19 11:16:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-07-19 11:16:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 11:16:22 --> Final output sent to browser
DEBUG - 2024-07-19 11:16:22 --> Total execution time: 0.0366
INFO - 2024-07-19 11:18:59 --> Config Class Initialized
INFO - 2024-07-19 11:18:59 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:18:59 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:18:59 --> Utf8 Class Initialized
INFO - 2024-07-19 11:18:59 --> URI Class Initialized
INFO - 2024-07-19 11:18:59 --> Router Class Initialized
INFO - 2024-07-19 11:18:59 --> Output Class Initialized
INFO - 2024-07-19 11:18:59 --> Security Class Initialized
DEBUG - 2024-07-19 11:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:18:59 --> Input Class Initialized
INFO - 2024-07-19 11:18:59 --> Language Class Initialized
INFO - 2024-07-19 11:18:59 --> Language Class Initialized
INFO - 2024-07-19 11:18:59 --> Config Class Initialized
INFO - 2024-07-19 11:18:59 --> Loader Class Initialized
INFO - 2024-07-19 11:18:59 --> Helper loaded: url_helper
INFO - 2024-07-19 11:18:59 --> Helper loaded: file_helper
INFO - 2024-07-19 11:18:59 --> Helper loaded: form_helper
INFO - 2024-07-19 11:18:59 --> Helper loaded: my_helper
INFO - 2024-07-19 11:18:59 --> Database Driver Class Initialized
INFO - 2024-07-19 11:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:18:59 --> Controller Class Initialized
DEBUG - 2024-07-19 11:18:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-19 11:18:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 11:18:59 --> Final output sent to browser
DEBUG - 2024-07-19 11:18:59 --> Total execution time: 0.0354
INFO - 2024-07-19 11:18:59 --> Config Class Initialized
INFO - 2024-07-19 11:18:59 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:18:59 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:18:59 --> Utf8 Class Initialized
INFO - 2024-07-19 11:18:59 --> URI Class Initialized
INFO - 2024-07-19 11:18:59 --> Router Class Initialized
INFO - 2024-07-19 11:18:59 --> Output Class Initialized
INFO - 2024-07-19 11:18:59 --> Security Class Initialized
DEBUG - 2024-07-19 11:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:18:59 --> Input Class Initialized
INFO - 2024-07-19 11:18:59 --> Language Class Initialized
ERROR - 2024-07-19 11:18:59 --> 404 Page Not Found: /index
INFO - 2024-07-19 11:18:59 --> Config Class Initialized
INFO - 2024-07-19 11:18:59 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:18:59 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:18:59 --> Utf8 Class Initialized
INFO - 2024-07-19 11:18:59 --> URI Class Initialized
INFO - 2024-07-19 11:18:59 --> Router Class Initialized
INFO - 2024-07-19 11:18:59 --> Output Class Initialized
INFO - 2024-07-19 11:18:59 --> Security Class Initialized
DEBUG - 2024-07-19 11:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:18:59 --> Input Class Initialized
INFO - 2024-07-19 11:18:59 --> Language Class Initialized
INFO - 2024-07-19 11:18:59 --> Language Class Initialized
INFO - 2024-07-19 11:18:59 --> Config Class Initialized
INFO - 2024-07-19 11:18:59 --> Loader Class Initialized
INFO - 2024-07-19 11:18:59 --> Helper loaded: url_helper
INFO - 2024-07-19 11:18:59 --> Helper loaded: file_helper
INFO - 2024-07-19 11:18:59 --> Helper loaded: form_helper
INFO - 2024-07-19 11:18:59 --> Helper loaded: my_helper
INFO - 2024-07-19 11:18:59 --> Database Driver Class Initialized
INFO - 2024-07-19 11:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:18:59 --> Controller Class Initialized
INFO - 2024-07-19 11:19:01 --> Config Class Initialized
INFO - 2024-07-19 11:19:01 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:19:01 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:19:01 --> Utf8 Class Initialized
INFO - 2024-07-19 11:19:01 --> URI Class Initialized
INFO - 2024-07-19 11:19:01 --> Router Class Initialized
INFO - 2024-07-19 11:19:01 --> Output Class Initialized
INFO - 2024-07-19 11:19:01 --> Security Class Initialized
DEBUG - 2024-07-19 11:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:19:01 --> Input Class Initialized
INFO - 2024-07-19 11:19:01 --> Language Class Initialized
INFO - 2024-07-19 11:19:01 --> Language Class Initialized
INFO - 2024-07-19 11:19:01 --> Config Class Initialized
INFO - 2024-07-19 11:19:01 --> Loader Class Initialized
INFO - 2024-07-19 11:19:01 --> Helper loaded: url_helper
INFO - 2024-07-19 11:19:01 --> Helper loaded: file_helper
INFO - 2024-07-19 11:19:01 --> Helper loaded: form_helper
INFO - 2024-07-19 11:19:01 --> Helper loaded: my_helper
INFO - 2024-07-19 11:19:01 --> Database Driver Class Initialized
INFO - 2024-07-19 11:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:19:01 --> Controller Class Initialized
INFO - 2024-07-19 11:19:02 --> Config Class Initialized
INFO - 2024-07-19 11:19:02 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:19:02 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:19:02 --> Utf8 Class Initialized
INFO - 2024-07-19 11:19:02 --> URI Class Initialized
INFO - 2024-07-19 11:19:02 --> Router Class Initialized
INFO - 2024-07-19 11:19:02 --> Output Class Initialized
INFO - 2024-07-19 11:19:02 --> Security Class Initialized
DEBUG - 2024-07-19 11:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:19:02 --> Input Class Initialized
INFO - 2024-07-19 11:19:02 --> Language Class Initialized
INFO - 2024-07-19 11:19:02 --> Language Class Initialized
INFO - 2024-07-19 11:19:02 --> Config Class Initialized
INFO - 2024-07-19 11:19:02 --> Loader Class Initialized
INFO - 2024-07-19 11:19:02 --> Helper loaded: url_helper
INFO - 2024-07-19 11:19:02 --> Helper loaded: file_helper
INFO - 2024-07-19 11:19:02 --> Helper loaded: form_helper
INFO - 2024-07-19 11:19:02 --> Helper loaded: my_helper
INFO - 2024-07-19 11:19:02 --> Database Driver Class Initialized
INFO - 2024-07-19 11:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:19:02 --> Controller Class Initialized
INFO - 2024-07-19 11:19:02 --> Config Class Initialized
INFO - 2024-07-19 11:19:02 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:19:02 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:19:02 --> Utf8 Class Initialized
INFO - 2024-07-19 11:19:02 --> URI Class Initialized
INFO - 2024-07-19 11:19:02 --> Router Class Initialized
INFO - 2024-07-19 11:19:02 --> Output Class Initialized
INFO - 2024-07-19 11:19:02 --> Security Class Initialized
DEBUG - 2024-07-19 11:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:19:02 --> Input Class Initialized
INFO - 2024-07-19 11:19:02 --> Language Class Initialized
INFO - 2024-07-19 11:19:02 --> Language Class Initialized
INFO - 2024-07-19 11:19:02 --> Config Class Initialized
INFO - 2024-07-19 11:19:02 --> Loader Class Initialized
INFO - 2024-07-19 11:19:02 --> Helper loaded: url_helper
INFO - 2024-07-19 11:19:02 --> Helper loaded: file_helper
INFO - 2024-07-19 11:19:02 --> Helper loaded: form_helper
INFO - 2024-07-19 11:19:02 --> Helper loaded: my_helper
INFO - 2024-07-19 11:19:02 --> Database Driver Class Initialized
INFO - 2024-07-19 11:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:19:02 --> Controller Class Initialized
INFO - 2024-07-19 11:19:36 --> Config Class Initialized
INFO - 2024-07-19 11:19:36 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:19:36 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:19:36 --> Utf8 Class Initialized
INFO - 2024-07-19 11:19:36 --> URI Class Initialized
INFO - 2024-07-19 11:19:36 --> Router Class Initialized
INFO - 2024-07-19 11:19:36 --> Output Class Initialized
INFO - 2024-07-19 11:19:36 --> Security Class Initialized
DEBUG - 2024-07-19 11:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:19:36 --> Input Class Initialized
INFO - 2024-07-19 11:19:36 --> Language Class Initialized
INFO - 2024-07-19 11:19:36 --> Language Class Initialized
INFO - 2024-07-19 11:19:36 --> Config Class Initialized
INFO - 2024-07-19 11:19:36 --> Loader Class Initialized
INFO - 2024-07-19 11:19:36 --> Helper loaded: url_helper
INFO - 2024-07-19 11:19:36 --> Helper loaded: file_helper
INFO - 2024-07-19 11:19:36 --> Helper loaded: form_helper
INFO - 2024-07-19 11:19:36 --> Helper loaded: my_helper
INFO - 2024-07-19 11:19:36 --> Database Driver Class Initialized
INFO - 2024-07-19 11:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:19:36 --> Controller Class Initialized
ERROR - 2024-07-19 11:19:36 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-07-19 11:19:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-07-19 11:19:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 11:19:36 --> Final output sent to browser
DEBUG - 2024-07-19 11:19:36 --> Total execution time: 0.0305
INFO - 2024-07-19 11:19:43 --> Config Class Initialized
INFO - 2024-07-19 11:19:43 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:19:43 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:19:43 --> Utf8 Class Initialized
INFO - 2024-07-19 11:19:43 --> URI Class Initialized
INFO - 2024-07-19 11:19:43 --> Router Class Initialized
INFO - 2024-07-19 11:19:43 --> Output Class Initialized
INFO - 2024-07-19 11:19:43 --> Security Class Initialized
DEBUG - 2024-07-19 11:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:19:43 --> Input Class Initialized
INFO - 2024-07-19 11:19:43 --> Language Class Initialized
INFO - 2024-07-19 11:19:43 --> Language Class Initialized
INFO - 2024-07-19 11:19:43 --> Config Class Initialized
INFO - 2024-07-19 11:19:43 --> Loader Class Initialized
INFO - 2024-07-19 11:19:43 --> Helper loaded: url_helper
INFO - 2024-07-19 11:19:43 --> Helper loaded: file_helper
INFO - 2024-07-19 11:19:43 --> Helper loaded: form_helper
INFO - 2024-07-19 11:19:43 --> Helper loaded: my_helper
INFO - 2024-07-19 11:19:43 --> Database Driver Class Initialized
INFO - 2024-07-19 11:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:19:43 --> Controller Class Initialized
DEBUG - 2024-07-19 11:19:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-19 11:19:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 11:19:43 --> Final output sent to browser
DEBUG - 2024-07-19 11:19:43 --> Total execution time: 0.0602
INFO - 2024-07-19 11:19:43 --> Config Class Initialized
INFO - 2024-07-19 11:19:43 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:19:43 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:19:43 --> Utf8 Class Initialized
INFO - 2024-07-19 11:19:43 --> URI Class Initialized
INFO - 2024-07-19 11:19:43 --> Router Class Initialized
INFO - 2024-07-19 11:19:43 --> Output Class Initialized
INFO - 2024-07-19 11:19:43 --> Security Class Initialized
DEBUG - 2024-07-19 11:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:19:43 --> Input Class Initialized
INFO - 2024-07-19 11:19:43 --> Language Class Initialized
ERROR - 2024-07-19 11:19:43 --> 404 Page Not Found: /index
INFO - 2024-07-19 11:19:43 --> Config Class Initialized
INFO - 2024-07-19 11:19:43 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:19:43 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:19:43 --> Utf8 Class Initialized
INFO - 2024-07-19 11:19:43 --> URI Class Initialized
INFO - 2024-07-19 11:19:43 --> Router Class Initialized
INFO - 2024-07-19 11:19:43 --> Output Class Initialized
INFO - 2024-07-19 11:19:43 --> Security Class Initialized
DEBUG - 2024-07-19 11:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:19:43 --> Input Class Initialized
INFO - 2024-07-19 11:19:43 --> Language Class Initialized
INFO - 2024-07-19 11:19:43 --> Language Class Initialized
INFO - 2024-07-19 11:19:43 --> Config Class Initialized
INFO - 2024-07-19 11:19:43 --> Loader Class Initialized
INFO - 2024-07-19 11:19:43 --> Helper loaded: url_helper
INFO - 2024-07-19 11:19:43 --> Helper loaded: file_helper
INFO - 2024-07-19 11:19:43 --> Helper loaded: form_helper
INFO - 2024-07-19 11:19:43 --> Helper loaded: my_helper
INFO - 2024-07-19 11:19:43 --> Database Driver Class Initialized
INFO - 2024-07-19 11:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:19:43 --> Controller Class Initialized
INFO - 2024-07-19 11:19:45 --> Config Class Initialized
INFO - 2024-07-19 11:19:45 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:19:45 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:19:45 --> Utf8 Class Initialized
INFO - 2024-07-19 11:19:45 --> URI Class Initialized
INFO - 2024-07-19 11:19:45 --> Router Class Initialized
INFO - 2024-07-19 11:19:45 --> Output Class Initialized
INFO - 2024-07-19 11:19:45 --> Security Class Initialized
DEBUG - 2024-07-19 11:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:19:45 --> Input Class Initialized
INFO - 2024-07-19 11:19:45 --> Language Class Initialized
INFO - 2024-07-19 11:19:45 --> Language Class Initialized
INFO - 2024-07-19 11:19:45 --> Config Class Initialized
INFO - 2024-07-19 11:19:45 --> Loader Class Initialized
INFO - 2024-07-19 11:19:45 --> Helper loaded: url_helper
INFO - 2024-07-19 11:19:45 --> Helper loaded: file_helper
INFO - 2024-07-19 11:19:45 --> Helper loaded: form_helper
INFO - 2024-07-19 11:19:45 --> Helper loaded: my_helper
INFO - 2024-07-19 11:19:45 --> Database Driver Class Initialized
INFO - 2024-07-19 11:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:19:45 --> Controller Class Initialized
DEBUG - 2024-07-19 11:19:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-07-19 11:19:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 11:19:45 --> Final output sent to browser
DEBUG - 2024-07-19 11:19:45 --> Total execution time: 0.0289
INFO - 2024-07-19 11:19:45 --> Config Class Initialized
INFO - 2024-07-19 11:19:45 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:19:45 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:19:45 --> Utf8 Class Initialized
INFO - 2024-07-19 11:19:45 --> URI Class Initialized
INFO - 2024-07-19 11:19:45 --> Router Class Initialized
INFO - 2024-07-19 11:19:45 --> Output Class Initialized
INFO - 2024-07-19 11:19:45 --> Security Class Initialized
DEBUG - 2024-07-19 11:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:19:45 --> Input Class Initialized
INFO - 2024-07-19 11:19:45 --> Language Class Initialized
ERROR - 2024-07-19 11:19:45 --> 404 Page Not Found: /index
INFO - 2024-07-19 11:19:45 --> Config Class Initialized
INFO - 2024-07-19 11:19:45 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:19:45 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:19:45 --> Utf8 Class Initialized
INFO - 2024-07-19 11:19:45 --> URI Class Initialized
INFO - 2024-07-19 11:19:45 --> Router Class Initialized
INFO - 2024-07-19 11:19:45 --> Output Class Initialized
INFO - 2024-07-19 11:19:45 --> Security Class Initialized
DEBUG - 2024-07-19 11:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:19:45 --> Input Class Initialized
INFO - 2024-07-19 11:19:45 --> Language Class Initialized
INFO - 2024-07-19 11:19:45 --> Language Class Initialized
INFO - 2024-07-19 11:19:45 --> Config Class Initialized
INFO - 2024-07-19 11:19:45 --> Loader Class Initialized
INFO - 2024-07-19 11:19:45 --> Helper loaded: url_helper
INFO - 2024-07-19 11:19:45 --> Helper loaded: file_helper
INFO - 2024-07-19 11:19:45 --> Helper loaded: form_helper
INFO - 2024-07-19 11:19:45 --> Helper loaded: my_helper
INFO - 2024-07-19 11:19:45 --> Database Driver Class Initialized
INFO - 2024-07-19 11:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:19:45 --> Controller Class Initialized
INFO - 2024-07-19 11:19:51 --> Config Class Initialized
INFO - 2024-07-19 11:19:51 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:19:51 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:19:51 --> Utf8 Class Initialized
INFO - 2024-07-19 11:19:51 --> URI Class Initialized
INFO - 2024-07-19 11:19:51 --> Router Class Initialized
INFO - 2024-07-19 11:19:51 --> Output Class Initialized
INFO - 2024-07-19 11:19:51 --> Security Class Initialized
DEBUG - 2024-07-19 11:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:19:51 --> Input Class Initialized
INFO - 2024-07-19 11:19:51 --> Language Class Initialized
INFO - 2024-07-19 11:19:51 --> Language Class Initialized
INFO - 2024-07-19 11:19:51 --> Config Class Initialized
INFO - 2024-07-19 11:19:51 --> Loader Class Initialized
INFO - 2024-07-19 11:19:51 --> Helper loaded: url_helper
INFO - 2024-07-19 11:19:51 --> Helper loaded: file_helper
INFO - 2024-07-19 11:19:51 --> Helper loaded: form_helper
INFO - 2024-07-19 11:19:51 --> Helper loaded: my_helper
INFO - 2024-07-19 11:19:51 --> Database Driver Class Initialized
INFO - 2024-07-19 11:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:19:51 --> Controller Class Initialized
DEBUG - 2024-07-19 11:19:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-19 11:19:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 11:19:51 --> Final output sent to browser
DEBUG - 2024-07-19 11:19:51 --> Total execution time: 0.0296
INFO - 2024-07-19 11:19:58 --> Config Class Initialized
INFO - 2024-07-19 11:19:58 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:19:58 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:19:58 --> Utf8 Class Initialized
INFO - 2024-07-19 11:19:58 --> URI Class Initialized
INFO - 2024-07-19 11:19:58 --> Router Class Initialized
INFO - 2024-07-19 11:19:58 --> Output Class Initialized
INFO - 2024-07-19 11:19:58 --> Security Class Initialized
DEBUG - 2024-07-19 11:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:19:58 --> Input Class Initialized
INFO - 2024-07-19 11:19:58 --> Language Class Initialized
INFO - 2024-07-19 11:19:58 --> Language Class Initialized
INFO - 2024-07-19 11:19:58 --> Config Class Initialized
INFO - 2024-07-19 11:19:58 --> Loader Class Initialized
INFO - 2024-07-19 11:19:58 --> Helper loaded: url_helper
INFO - 2024-07-19 11:19:58 --> Helper loaded: file_helper
INFO - 2024-07-19 11:19:58 --> Helper loaded: form_helper
INFO - 2024-07-19 11:19:58 --> Helper loaded: my_helper
INFO - 2024-07-19 11:19:58 --> Database Driver Class Initialized
INFO - 2024-07-19 11:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:19:58 --> Controller Class Initialized
INFO - 2024-07-19 11:19:58 --> Database Driver Class Initialized
INFO - 2024-07-19 11:19:59 --> Config Class Initialized
INFO - 2024-07-19 11:19:59 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:19:59 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:19:59 --> Utf8 Class Initialized
INFO - 2024-07-19 11:19:59 --> URI Class Initialized
INFO - 2024-07-19 11:19:59 --> Router Class Initialized
INFO - 2024-07-19 11:19:59 --> Output Class Initialized
INFO - 2024-07-19 11:19:59 --> Security Class Initialized
DEBUG - 2024-07-19 11:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:19:59 --> Input Class Initialized
INFO - 2024-07-19 11:19:59 --> Language Class Initialized
INFO - 2024-07-19 11:19:59 --> Language Class Initialized
INFO - 2024-07-19 11:19:59 --> Config Class Initialized
INFO - 2024-07-19 11:19:59 --> Loader Class Initialized
INFO - 2024-07-19 11:19:59 --> Helper loaded: url_helper
INFO - 2024-07-19 11:19:59 --> Helper loaded: file_helper
INFO - 2024-07-19 11:19:59 --> Helper loaded: form_helper
INFO - 2024-07-19 11:19:59 --> Helper loaded: my_helper
INFO - 2024-07-19 11:19:59 --> Database Driver Class Initialized
INFO - 2024-07-19 11:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:19:59 --> Controller Class Initialized
DEBUG - 2024-07-19 11:19:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-19 11:19:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 11:19:59 --> Final output sent to browser
DEBUG - 2024-07-19 11:19:59 --> Total execution time: 0.0413
INFO - 2024-07-19 11:20:00 --> Config Class Initialized
INFO - 2024-07-19 11:20:00 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:20:00 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:20:00 --> Utf8 Class Initialized
INFO - 2024-07-19 11:20:00 --> URI Class Initialized
INFO - 2024-07-19 11:20:01 --> Router Class Initialized
INFO - 2024-07-19 11:20:01 --> Output Class Initialized
INFO - 2024-07-19 11:20:01 --> Security Class Initialized
DEBUG - 2024-07-19 11:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:20:01 --> Input Class Initialized
INFO - 2024-07-19 11:20:01 --> Language Class Initialized
INFO - 2024-07-19 11:20:01 --> Language Class Initialized
INFO - 2024-07-19 11:20:01 --> Config Class Initialized
INFO - 2024-07-19 11:20:01 --> Loader Class Initialized
INFO - 2024-07-19 11:20:01 --> Helper loaded: url_helper
INFO - 2024-07-19 11:20:01 --> Helper loaded: file_helper
INFO - 2024-07-19 11:20:01 --> Helper loaded: form_helper
INFO - 2024-07-19 11:20:01 --> Helper loaded: my_helper
INFO - 2024-07-19 11:20:01 --> Database Driver Class Initialized
INFO - 2024-07-19 11:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:20:01 --> Controller Class Initialized
INFO - 2024-07-19 11:20:01 --> Database Driver Class Initialized
INFO - 2024-07-19 11:20:01 --> Config Class Initialized
INFO - 2024-07-19 11:20:01 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:20:01 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:20:01 --> Utf8 Class Initialized
INFO - 2024-07-19 11:20:01 --> URI Class Initialized
INFO - 2024-07-19 11:20:01 --> Router Class Initialized
INFO - 2024-07-19 11:20:01 --> Output Class Initialized
INFO - 2024-07-19 11:20:01 --> Security Class Initialized
DEBUG - 2024-07-19 11:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:20:01 --> Input Class Initialized
INFO - 2024-07-19 11:20:01 --> Language Class Initialized
INFO - 2024-07-19 11:20:01 --> Language Class Initialized
INFO - 2024-07-19 11:20:01 --> Config Class Initialized
INFO - 2024-07-19 11:20:01 --> Loader Class Initialized
INFO - 2024-07-19 11:20:01 --> Helper loaded: url_helper
INFO - 2024-07-19 11:20:01 --> Helper loaded: file_helper
INFO - 2024-07-19 11:20:01 --> Helper loaded: form_helper
INFO - 2024-07-19 11:20:01 --> Helper loaded: my_helper
INFO - 2024-07-19 11:20:01 --> Database Driver Class Initialized
INFO - 2024-07-19 11:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:20:01 --> Controller Class Initialized
DEBUG - 2024-07-19 11:20:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-19 11:20:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 11:20:01 --> Final output sent to browser
DEBUG - 2024-07-19 11:20:01 --> Total execution time: 0.0342
INFO - 2024-07-19 11:20:02 --> Config Class Initialized
INFO - 2024-07-19 11:20:02 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:20:02 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:20:02 --> Utf8 Class Initialized
INFO - 2024-07-19 11:20:02 --> URI Class Initialized
INFO - 2024-07-19 11:20:02 --> Router Class Initialized
INFO - 2024-07-19 11:20:02 --> Output Class Initialized
INFO - 2024-07-19 11:20:02 --> Security Class Initialized
DEBUG - 2024-07-19 11:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:20:02 --> Input Class Initialized
INFO - 2024-07-19 11:20:02 --> Language Class Initialized
INFO - 2024-07-19 11:20:02 --> Language Class Initialized
INFO - 2024-07-19 11:20:02 --> Config Class Initialized
INFO - 2024-07-19 11:20:02 --> Loader Class Initialized
INFO - 2024-07-19 11:20:02 --> Helper loaded: url_helper
INFO - 2024-07-19 11:20:02 --> Helper loaded: file_helper
INFO - 2024-07-19 11:20:02 --> Helper loaded: form_helper
INFO - 2024-07-19 11:20:02 --> Helper loaded: my_helper
INFO - 2024-07-19 11:20:02 --> Database Driver Class Initialized
INFO - 2024-07-19 11:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:20:02 --> Controller Class Initialized
INFO - 2024-07-19 11:20:02 --> Database Driver Class Initialized
INFO - 2024-07-19 11:20:03 --> Config Class Initialized
INFO - 2024-07-19 11:20:03 --> Hooks Class Initialized
DEBUG - 2024-07-19 11:20:03 --> UTF-8 Support Enabled
INFO - 2024-07-19 11:20:03 --> Utf8 Class Initialized
INFO - 2024-07-19 11:20:03 --> URI Class Initialized
INFO - 2024-07-19 11:20:03 --> Router Class Initialized
INFO - 2024-07-19 11:20:03 --> Output Class Initialized
INFO - 2024-07-19 11:20:03 --> Security Class Initialized
DEBUG - 2024-07-19 11:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-19 11:20:03 --> Input Class Initialized
INFO - 2024-07-19 11:20:03 --> Language Class Initialized
INFO - 2024-07-19 11:20:03 --> Language Class Initialized
INFO - 2024-07-19 11:20:03 --> Config Class Initialized
INFO - 2024-07-19 11:20:03 --> Loader Class Initialized
INFO - 2024-07-19 11:20:03 --> Helper loaded: url_helper
INFO - 2024-07-19 11:20:03 --> Helper loaded: file_helper
INFO - 2024-07-19 11:20:03 --> Helper loaded: form_helper
INFO - 2024-07-19 11:20:03 --> Helper loaded: my_helper
INFO - 2024-07-19 11:20:03 --> Database Driver Class Initialized
INFO - 2024-07-19 11:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-19 11:20:03 --> Controller Class Initialized
DEBUG - 2024-07-19 11:20:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-19 11:20:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-19 11:20:03 --> Final output sent to browser
DEBUG - 2024-07-19 11:20:03 --> Total execution time: 0.0753
