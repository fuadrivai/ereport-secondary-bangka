<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-16 15:14:24 --> Config Class Initialized
INFO - 2024-09-16 15:14:24 --> Hooks Class Initialized
DEBUG - 2024-09-16 15:14:24 --> UTF-8 Support Enabled
INFO - 2024-09-16 15:14:24 --> Utf8 Class Initialized
INFO - 2024-09-16 15:14:24 --> URI Class Initialized
INFO - 2024-09-16 15:14:24 --> Router Class Initialized
INFO - 2024-09-16 15:14:24 --> Output Class Initialized
INFO - 2024-09-16 15:14:24 --> Security Class Initialized
DEBUG - 2024-09-16 15:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-16 15:14:24 --> Input Class Initialized
INFO - 2024-09-16 15:14:24 --> Language Class Initialized
INFO - 2024-09-16 15:14:24 --> Language Class Initialized
INFO - 2024-09-16 15:14:24 --> Config Class Initialized
INFO - 2024-09-16 15:14:24 --> Loader Class Initialized
INFO - 2024-09-16 15:14:24 --> Helper loaded: url_helper
INFO - 2024-09-16 15:14:24 --> Helper loaded: file_helper
INFO - 2024-09-16 15:14:24 --> Helper loaded: form_helper
INFO - 2024-09-16 15:14:24 --> Helper loaded: my_helper
INFO - 2024-09-16 15:14:24 --> Database Driver Class Initialized
INFO - 2024-09-16 15:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-16 15:14:24 --> Controller Class Initialized
INFO - 2024-09-16 15:14:24 --> Helper loaded: cookie_helper
INFO - 2024-09-16 15:14:24 --> Final output sent to browser
DEBUG - 2024-09-16 15:14:24 --> Total execution time: 0.0928
INFO - 2024-09-16 15:14:24 --> Config Class Initialized
INFO - 2024-09-16 15:14:24 --> Hooks Class Initialized
DEBUG - 2024-09-16 15:14:24 --> UTF-8 Support Enabled
INFO - 2024-09-16 15:14:24 --> Utf8 Class Initialized
INFO - 2024-09-16 15:14:24 --> URI Class Initialized
INFO - 2024-09-16 15:14:24 --> Router Class Initialized
INFO - 2024-09-16 15:14:24 --> Output Class Initialized
INFO - 2024-09-16 15:14:24 --> Security Class Initialized
DEBUG - 2024-09-16 15:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-16 15:14:24 --> Input Class Initialized
INFO - 2024-09-16 15:14:24 --> Language Class Initialized
INFO - 2024-09-16 15:14:24 --> Language Class Initialized
INFO - 2024-09-16 15:14:24 --> Config Class Initialized
INFO - 2024-09-16 15:14:24 --> Loader Class Initialized
INFO - 2024-09-16 15:14:24 --> Helper loaded: url_helper
INFO - 2024-09-16 15:14:24 --> Helper loaded: file_helper
INFO - 2024-09-16 15:14:24 --> Helper loaded: form_helper
INFO - 2024-09-16 15:14:24 --> Helper loaded: my_helper
INFO - 2024-09-16 15:14:24 --> Database Driver Class Initialized
INFO - 2024-09-16 15:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-16 15:14:24 --> Controller Class Initialized
INFO - 2024-09-16 15:14:24 --> Helper loaded: cookie_helper
INFO - 2024-09-16 15:14:24 --> Config Class Initialized
INFO - 2024-09-16 15:14:24 --> Hooks Class Initialized
DEBUG - 2024-09-16 15:14:24 --> UTF-8 Support Enabled
INFO - 2024-09-16 15:14:24 --> Utf8 Class Initialized
INFO - 2024-09-16 15:14:24 --> URI Class Initialized
INFO - 2024-09-16 15:14:24 --> Router Class Initialized
INFO - 2024-09-16 15:14:24 --> Output Class Initialized
INFO - 2024-09-16 15:14:24 --> Security Class Initialized
DEBUG - 2024-09-16 15:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-16 15:14:24 --> Input Class Initialized
INFO - 2024-09-16 15:14:24 --> Language Class Initialized
INFO - 2024-09-16 15:14:24 --> Language Class Initialized
INFO - 2024-09-16 15:14:24 --> Config Class Initialized
INFO - 2024-09-16 15:14:24 --> Loader Class Initialized
INFO - 2024-09-16 15:14:24 --> Helper loaded: url_helper
INFO - 2024-09-16 15:14:24 --> Helper loaded: file_helper
INFO - 2024-09-16 15:14:24 --> Helper loaded: form_helper
INFO - 2024-09-16 15:14:24 --> Helper loaded: my_helper
INFO - 2024-09-16 15:14:24 --> Database Driver Class Initialized
INFO - 2024-09-16 15:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-16 15:14:24 --> Controller Class Initialized
DEBUG - 2024-09-16 15:14:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-16 15:14:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-16 15:14:24 --> Final output sent to browser
DEBUG - 2024-09-16 15:14:24 --> Total execution time: 0.0407
INFO - 2024-09-16 15:14:29 --> Config Class Initialized
INFO - 2024-09-16 15:14:29 --> Hooks Class Initialized
DEBUG - 2024-09-16 15:14:29 --> UTF-8 Support Enabled
INFO - 2024-09-16 15:14:29 --> Utf8 Class Initialized
INFO - 2024-09-16 15:14:29 --> URI Class Initialized
INFO - 2024-09-16 15:14:29 --> Router Class Initialized
INFO - 2024-09-16 15:14:29 --> Output Class Initialized
INFO - 2024-09-16 15:14:29 --> Security Class Initialized
DEBUG - 2024-09-16 15:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-16 15:14:29 --> Input Class Initialized
INFO - 2024-09-16 15:14:29 --> Language Class Initialized
INFO - 2024-09-16 15:14:29 --> Language Class Initialized
INFO - 2024-09-16 15:14:29 --> Config Class Initialized
INFO - 2024-09-16 15:14:29 --> Loader Class Initialized
INFO - 2024-09-16 15:14:29 --> Helper loaded: url_helper
INFO - 2024-09-16 15:14:29 --> Helper loaded: file_helper
INFO - 2024-09-16 15:14:29 --> Helper loaded: form_helper
INFO - 2024-09-16 15:14:29 --> Helper loaded: my_helper
INFO - 2024-09-16 15:14:29 --> Database Driver Class Initialized
INFO - 2024-09-16 15:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-16 15:14:29 --> Controller Class Initialized
ERROR - 2024-09-16 15:14:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-16 15:14:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-16 15:14:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-16 15:14:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-16 15:14:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-16 15:14:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-16 15:14:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-16 15:14:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-16 15:14:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-16 15:14:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-16 15:14:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-16 15:14:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-16 15:14:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-16 15:14:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-16 15:14:31 --> Config Class Initialized
INFO - 2024-09-16 15:14:31 --> Hooks Class Initialized
DEBUG - 2024-09-16 15:14:31 --> UTF-8 Support Enabled
INFO - 2024-09-16 15:14:31 --> Utf8 Class Initialized
INFO - 2024-09-16 15:14:31 --> URI Class Initialized
INFO - 2024-09-16 15:14:31 --> Router Class Initialized
INFO - 2024-09-16 15:14:31 --> Output Class Initialized
INFO - 2024-09-16 15:14:31 --> Security Class Initialized
DEBUG - 2024-09-16 15:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-16 15:14:31 --> Input Class Initialized
INFO - 2024-09-16 15:14:31 --> Language Class Initialized
INFO - 2024-09-16 15:14:31 --> Language Class Initialized
INFO - 2024-09-16 15:14:31 --> Config Class Initialized
INFO - 2024-09-16 15:14:31 --> Loader Class Initialized
INFO - 2024-09-16 15:14:31 --> Helper loaded: url_helper
INFO - 2024-09-16 15:14:31 --> Helper loaded: file_helper
INFO - 2024-09-16 15:14:31 --> Helper loaded: form_helper
INFO - 2024-09-16 15:14:31 --> Helper loaded: my_helper
INFO - 2024-09-16 15:14:31 --> Database Driver Class Initialized
INFO - 2024-09-16 15:14:32 --> Final output sent to browser
DEBUG - 2024-09-16 15:14:32 --> Total execution time: 3.2824
INFO - 2024-09-16 15:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-16 15:14:32 --> Controller Class Initialized
ERROR - 2024-09-16 15:14:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-16 15:14:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-16 15:14:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-16 15:14:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-16 15:14:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-16 15:14:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-16 15:14:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-16 15:14:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-16 15:14:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-16 15:14:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-16 15:14:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-16 15:14:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-16 15:14:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-16 15:14:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-16 15:14:33 --> Config Class Initialized
INFO - 2024-09-16 15:14:33 --> Hooks Class Initialized
DEBUG - 2024-09-16 15:14:33 --> UTF-8 Support Enabled
INFO - 2024-09-16 15:14:33 --> Utf8 Class Initialized
INFO - 2024-09-16 15:14:33 --> URI Class Initialized
INFO - 2024-09-16 15:14:33 --> Router Class Initialized
INFO - 2024-09-16 15:14:33 --> Output Class Initialized
INFO - 2024-09-16 15:14:33 --> Security Class Initialized
DEBUG - 2024-09-16 15:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-16 15:14:33 --> Input Class Initialized
INFO - 2024-09-16 15:14:33 --> Language Class Initialized
INFO - 2024-09-16 15:14:33 --> Language Class Initialized
INFO - 2024-09-16 15:14:33 --> Config Class Initialized
INFO - 2024-09-16 15:14:33 --> Loader Class Initialized
INFO - 2024-09-16 15:14:33 --> Helper loaded: url_helper
INFO - 2024-09-16 15:14:33 --> Helper loaded: file_helper
INFO - 2024-09-16 15:14:33 --> Helper loaded: form_helper
INFO - 2024-09-16 15:14:33 --> Helper loaded: my_helper
INFO - 2024-09-16 15:14:33 --> Database Driver Class Initialized
INFO - 2024-09-16 15:14:34 --> Config Class Initialized
INFO - 2024-09-16 15:14:34 --> Hooks Class Initialized
DEBUG - 2024-09-16 15:14:34 --> UTF-8 Support Enabled
INFO - 2024-09-16 15:14:34 --> Utf8 Class Initialized
INFO - 2024-09-16 15:14:34 --> URI Class Initialized
INFO - 2024-09-16 15:14:34 --> Router Class Initialized
INFO - 2024-09-16 15:14:34 --> Output Class Initialized
INFO - 2024-09-16 15:14:34 --> Security Class Initialized
DEBUG - 2024-09-16 15:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-16 15:14:34 --> Input Class Initialized
INFO - 2024-09-16 15:14:34 --> Language Class Initialized
INFO - 2024-09-16 15:14:34 --> Language Class Initialized
INFO - 2024-09-16 15:14:34 --> Config Class Initialized
INFO - 2024-09-16 15:14:34 --> Loader Class Initialized
INFO - 2024-09-16 15:14:34 --> Helper loaded: url_helper
INFO - 2024-09-16 15:14:34 --> Helper loaded: file_helper
INFO - 2024-09-16 15:14:34 --> Helper loaded: form_helper
INFO - 2024-09-16 15:14:34 --> Helper loaded: my_helper
INFO - 2024-09-16 15:14:34 --> Database Driver Class Initialized
INFO - 2024-09-16 15:14:35 --> Final output sent to browser
DEBUG - 2024-09-16 15:14:35 --> Total execution time: 4.3996
INFO - 2024-09-16 15:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-16 15:14:35 --> Controller Class Initialized
ERROR - 2024-09-16 15:14:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-16 15:14:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-16 15:14:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-16 15:14:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-16 15:14:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-16 15:14:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-16 15:14:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-16 15:14:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-16 15:14:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-16 15:14:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-16 15:14:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-16 15:14:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-16 15:14:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-16 15:14:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-16 15:14:38 --> Final output sent to browser
DEBUG - 2024-09-16 15:14:38 --> Total execution time: 4.9955
INFO - 2024-09-16 15:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-16 15:14:38 --> Controller Class Initialized
INFO - 2024-09-16 15:14:38 --> Config Class Initialized
INFO - 2024-09-16 15:14:38 --> Hooks Class Initialized
DEBUG - 2024-09-16 15:14:38 --> UTF-8 Support Enabled
INFO - 2024-09-16 15:14:38 --> Utf8 Class Initialized
INFO - 2024-09-16 15:14:38 --> URI Class Initialized
INFO - 2024-09-16 15:14:38 --> Router Class Initialized
ERROR - 2024-09-16 15:14:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-16 15:14:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-16 15:14:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-16 15:14:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-16 15:14:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-16 15:14:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-16 15:14:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-16 15:14:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-16 15:14:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-16 15:14:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-16 15:14:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-16 15:14:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-16 15:14:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-16 15:14:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-16 15:14:38 --> Output Class Initialized
INFO - 2024-09-16 15:14:38 --> Security Class Initialized
DEBUG - 2024-09-16 15:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-16 15:14:38 --> Input Class Initialized
INFO - 2024-09-16 15:14:38 --> Language Class Initialized
INFO - 2024-09-16 15:14:38 --> Language Class Initialized
INFO - 2024-09-16 15:14:38 --> Config Class Initialized
INFO - 2024-09-16 15:14:38 --> Loader Class Initialized
INFO - 2024-09-16 15:14:38 --> Helper loaded: url_helper
INFO - 2024-09-16 15:14:38 --> Helper loaded: file_helper
INFO - 2024-09-16 15:14:38 --> Helper loaded: form_helper
INFO - 2024-09-16 15:14:38 --> Helper loaded: my_helper
INFO - 2024-09-16 15:14:38 --> Database Driver Class Initialized
INFO - 2024-09-16 15:14:41 --> Final output sent to browser
DEBUG - 2024-09-16 15:14:41 --> Total execution time: 6.7705
INFO - 2024-09-16 15:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-16 15:14:41 --> Controller Class Initialized
INFO - 2024-09-16 15:14:41 --> Config Class Initialized
INFO - 2024-09-16 15:14:41 --> Hooks Class Initialized
DEBUG - 2024-09-16 15:14:41 --> UTF-8 Support Enabled
INFO - 2024-09-16 15:14:41 --> Utf8 Class Initialized
INFO - 2024-09-16 15:14:41 --> URI Class Initialized
INFO - 2024-09-16 15:14:41 --> Router Class Initialized
INFO - 2024-09-16 15:14:41 --> Output Class Initialized
ERROR - 2024-09-16 15:14:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-16 15:14:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-16 15:14:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-16 15:14:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-16 15:14:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-16 15:14:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-16 15:14:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-16 15:14:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-16 15:14:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-16 15:14:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-16 15:14:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-16 15:14:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-16 15:14:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-16 15:14:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-16 15:14:41 --> Security Class Initialized
DEBUG - 2024-09-16 15:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-16 15:14:41 --> Input Class Initialized
INFO - 2024-09-16 15:14:41 --> Language Class Initialized
INFO - 2024-09-16 15:14:41 --> Language Class Initialized
INFO - 2024-09-16 15:14:41 --> Config Class Initialized
INFO - 2024-09-16 15:14:41 --> Loader Class Initialized
INFO - 2024-09-16 15:14:41 --> Helper loaded: url_helper
INFO - 2024-09-16 15:14:41 --> Helper loaded: file_helper
INFO - 2024-09-16 15:14:41 --> Helper loaded: form_helper
INFO - 2024-09-16 15:14:41 --> Helper loaded: my_helper
INFO - 2024-09-16 15:14:41 --> Database Driver Class Initialized
INFO - 2024-09-16 15:14:43 --> Final output sent to browser
DEBUG - 2024-09-16 15:14:43 --> Total execution time: 5.2257
INFO - 2024-09-16 15:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-16 15:14:43 --> Controller Class Initialized
INFO - 2024-09-16 15:14:43 --> Config Class Initialized
INFO - 2024-09-16 15:14:43 --> Hooks Class Initialized
DEBUG - 2024-09-16 15:14:43 --> UTF-8 Support Enabled
INFO - 2024-09-16 15:14:43 --> Utf8 Class Initialized
INFO - 2024-09-16 15:14:43 --> URI Class Initialized
INFO - 2024-09-16 15:14:43 --> Router Class Initialized
ERROR - 2024-09-16 15:14:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-16 15:14:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-16 15:14:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-16 15:14:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-16 15:14:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-16 15:14:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-16 15:14:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-16 15:14:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-16 15:14:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-16 15:14:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-16 15:14:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-16 15:14:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-16 15:14:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-16 15:14:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-16 15:14:43 --> Output Class Initialized
INFO - 2024-09-16 15:14:43 --> Security Class Initialized
DEBUG - 2024-09-16 15:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-16 15:14:43 --> Input Class Initialized
INFO - 2024-09-16 15:14:43 --> Language Class Initialized
INFO - 2024-09-16 15:14:43 --> Language Class Initialized
INFO - 2024-09-16 15:14:43 --> Config Class Initialized
INFO - 2024-09-16 15:14:43 --> Loader Class Initialized
INFO - 2024-09-16 15:14:43 --> Helper loaded: url_helper
INFO - 2024-09-16 15:14:43 --> Helper loaded: file_helper
INFO - 2024-09-16 15:14:43 --> Helper loaded: form_helper
INFO - 2024-09-16 15:14:43 --> Helper loaded: my_helper
INFO - 2024-09-16 15:14:43 --> Database Driver Class Initialized
INFO - 2024-09-16 15:14:46 --> Final output sent to browser
DEBUG - 2024-09-16 15:14:46 --> Total execution time: 5.2784
INFO - 2024-09-16 15:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-16 15:14:46 --> Controller Class Initialized
ERROR - 2024-09-16 15:14:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-16 15:14:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-16 15:14:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-16 15:14:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-16 15:14:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-16 15:14:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-16 15:14:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-16 15:14:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-16 15:14:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-16 15:14:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-16 15:14:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-16 15:14:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-16 15:14:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-16 15:14:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-16 15:14:48 --> Final output sent to browser
DEBUG - 2024-09-16 15:14:48 --> Total execution time: 5.3277
INFO - 2024-09-16 15:19:15 --> Config Class Initialized
INFO - 2024-09-16 15:19:15 --> Hooks Class Initialized
DEBUG - 2024-09-16 15:19:15 --> UTF-8 Support Enabled
INFO - 2024-09-16 15:19:15 --> Utf8 Class Initialized
INFO - 2024-09-16 15:19:15 --> URI Class Initialized
INFO - 2024-09-16 15:19:15 --> Router Class Initialized
INFO - 2024-09-16 15:19:15 --> Output Class Initialized
INFO - 2024-09-16 15:19:15 --> Security Class Initialized
DEBUG - 2024-09-16 15:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-16 15:19:15 --> Input Class Initialized
INFO - 2024-09-16 15:19:15 --> Language Class Initialized
INFO - 2024-09-16 15:19:15 --> Language Class Initialized
INFO - 2024-09-16 15:19:15 --> Config Class Initialized
INFO - 2024-09-16 15:19:15 --> Loader Class Initialized
INFO - 2024-09-16 15:19:15 --> Helper loaded: url_helper
INFO - 2024-09-16 15:19:15 --> Helper loaded: file_helper
INFO - 2024-09-16 15:19:15 --> Helper loaded: form_helper
INFO - 2024-09-16 15:19:15 --> Helper loaded: my_helper
INFO - 2024-09-16 15:19:16 --> Database Driver Class Initialized
INFO - 2024-09-16 15:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-16 15:19:16 --> Controller Class Initialized
INFO - 2024-09-16 15:19:16 --> Helper loaded: cookie_helper
INFO - 2024-09-16 15:19:16 --> Final output sent to browser
DEBUG - 2024-09-16 15:19:16 --> Total execution time: 0.0593
INFO - 2024-09-16 15:19:16 --> Config Class Initialized
INFO - 2024-09-16 15:19:16 --> Hooks Class Initialized
DEBUG - 2024-09-16 15:19:16 --> UTF-8 Support Enabled
INFO - 2024-09-16 15:19:16 --> Utf8 Class Initialized
INFO - 2024-09-16 15:19:16 --> URI Class Initialized
INFO - 2024-09-16 15:19:16 --> Router Class Initialized
INFO - 2024-09-16 15:19:16 --> Output Class Initialized
INFO - 2024-09-16 15:19:16 --> Security Class Initialized
DEBUG - 2024-09-16 15:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-16 15:19:16 --> Input Class Initialized
INFO - 2024-09-16 15:19:16 --> Language Class Initialized
INFO - 2024-09-16 15:19:16 --> Language Class Initialized
INFO - 2024-09-16 15:19:16 --> Config Class Initialized
INFO - 2024-09-16 15:19:16 --> Loader Class Initialized
INFO - 2024-09-16 15:19:16 --> Helper loaded: url_helper
INFO - 2024-09-16 15:19:16 --> Helper loaded: file_helper
INFO - 2024-09-16 15:19:16 --> Helper loaded: form_helper
INFO - 2024-09-16 15:19:16 --> Helper loaded: my_helper
INFO - 2024-09-16 15:19:16 --> Database Driver Class Initialized
INFO - 2024-09-16 15:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-16 15:19:16 --> Controller Class Initialized
INFO - 2024-09-16 15:19:16 --> Helper loaded: cookie_helper
INFO - 2024-09-16 15:19:16 --> Config Class Initialized
INFO - 2024-09-16 15:19:16 --> Hooks Class Initialized
DEBUG - 2024-09-16 15:19:16 --> UTF-8 Support Enabled
INFO - 2024-09-16 15:19:16 --> Utf8 Class Initialized
INFO - 2024-09-16 15:19:16 --> URI Class Initialized
INFO - 2024-09-16 15:19:16 --> Router Class Initialized
INFO - 2024-09-16 15:19:16 --> Output Class Initialized
INFO - 2024-09-16 15:19:16 --> Security Class Initialized
DEBUG - 2024-09-16 15:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-16 15:19:16 --> Input Class Initialized
INFO - 2024-09-16 15:19:16 --> Language Class Initialized
INFO - 2024-09-16 15:19:16 --> Language Class Initialized
INFO - 2024-09-16 15:19:16 --> Config Class Initialized
INFO - 2024-09-16 15:19:16 --> Loader Class Initialized
INFO - 2024-09-16 15:19:16 --> Helper loaded: url_helper
INFO - 2024-09-16 15:19:16 --> Helper loaded: file_helper
INFO - 2024-09-16 15:19:16 --> Helper loaded: form_helper
INFO - 2024-09-16 15:19:16 --> Helper loaded: my_helper
INFO - 2024-09-16 15:19:16 --> Database Driver Class Initialized
INFO - 2024-09-16 15:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-16 15:19:16 --> Controller Class Initialized
DEBUG - 2024-09-16 15:19:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-16 15:19:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-16 15:19:16 --> Final output sent to browser
DEBUG - 2024-09-16 15:19:16 --> Total execution time: 0.0339
INFO - 2024-09-16 18:19:45 --> Config Class Initialized
INFO - 2024-09-16 18:19:45 --> Hooks Class Initialized
DEBUG - 2024-09-16 18:19:45 --> UTF-8 Support Enabled
INFO - 2024-09-16 18:19:45 --> Utf8 Class Initialized
INFO - 2024-09-16 18:19:45 --> URI Class Initialized
INFO - 2024-09-16 18:19:45 --> Router Class Initialized
INFO - 2024-09-16 18:19:45 --> Output Class Initialized
INFO - 2024-09-16 18:19:45 --> Security Class Initialized
DEBUG - 2024-09-16 18:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-16 18:19:45 --> Input Class Initialized
INFO - 2024-09-16 18:19:45 --> Language Class Initialized
INFO - 2024-09-16 18:19:45 --> Language Class Initialized
INFO - 2024-09-16 18:19:45 --> Config Class Initialized
INFO - 2024-09-16 18:19:45 --> Loader Class Initialized
INFO - 2024-09-16 18:19:45 --> Helper loaded: url_helper
INFO - 2024-09-16 18:19:45 --> Helper loaded: file_helper
INFO - 2024-09-16 18:19:45 --> Helper loaded: form_helper
INFO - 2024-09-16 18:19:45 --> Helper loaded: my_helper
INFO - 2024-09-16 18:19:45 --> Database Driver Class Initialized
INFO - 2024-09-16 18:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-16 18:19:45 --> Controller Class Initialized
INFO - 2024-09-16 18:19:45 --> Helper loaded: cookie_helper
INFO - 2024-09-16 18:19:45 --> Final output sent to browser
DEBUG - 2024-09-16 18:19:45 --> Total execution time: 0.2624
INFO - 2024-09-16 18:19:46 --> Config Class Initialized
INFO - 2024-09-16 18:19:46 --> Hooks Class Initialized
DEBUG - 2024-09-16 18:19:46 --> UTF-8 Support Enabled
INFO - 2024-09-16 18:19:46 --> Utf8 Class Initialized
INFO - 2024-09-16 18:19:46 --> URI Class Initialized
INFO - 2024-09-16 18:19:46 --> Router Class Initialized
INFO - 2024-09-16 18:19:46 --> Output Class Initialized
INFO - 2024-09-16 18:19:46 --> Security Class Initialized
DEBUG - 2024-09-16 18:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-16 18:19:46 --> Input Class Initialized
INFO - 2024-09-16 18:19:46 --> Language Class Initialized
INFO - 2024-09-16 18:19:46 --> Language Class Initialized
INFO - 2024-09-16 18:19:46 --> Config Class Initialized
INFO - 2024-09-16 18:19:46 --> Loader Class Initialized
INFO - 2024-09-16 18:19:46 --> Helper loaded: url_helper
INFO - 2024-09-16 18:19:46 --> Helper loaded: file_helper
INFO - 2024-09-16 18:19:46 --> Helper loaded: form_helper
INFO - 2024-09-16 18:19:46 --> Helper loaded: my_helper
INFO - 2024-09-16 18:19:46 --> Database Driver Class Initialized
INFO - 2024-09-16 18:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-16 18:19:46 --> Controller Class Initialized
INFO - 2024-09-16 18:19:46 --> Helper loaded: cookie_helper
INFO - 2024-09-16 18:19:46 --> Config Class Initialized
INFO - 2024-09-16 18:19:46 --> Hooks Class Initialized
DEBUG - 2024-09-16 18:19:46 --> UTF-8 Support Enabled
INFO - 2024-09-16 18:19:46 --> Utf8 Class Initialized
INFO - 2024-09-16 18:19:46 --> URI Class Initialized
INFO - 2024-09-16 18:19:46 --> Router Class Initialized
INFO - 2024-09-16 18:19:46 --> Output Class Initialized
INFO - 2024-09-16 18:19:46 --> Security Class Initialized
DEBUG - 2024-09-16 18:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-16 18:19:46 --> Input Class Initialized
INFO - 2024-09-16 18:19:46 --> Language Class Initialized
INFO - 2024-09-16 18:19:46 --> Language Class Initialized
INFO - 2024-09-16 18:19:46 --> Config Class Initialized
INFO - 2024-09-16 18:19:46 --> Loader Class Initialized
INFO - 2024-09-16 18:19:46 --> Helper loaded: url_helper
INFO - 2024-09-16 18:19:46 --> Helper loaded: file_helper
INFO - 2024-09-16 18:19:46 --> Helper loaded: form_helper
INFO - 2024-09-16 18:19:46 --> Helper loaded: my_helper
INFO - 2024-09-16 18:19:46 --> Database Driver Class Initialized
INFO - 2024-09-16 18:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-16 18:19:46 --> Controller Class Initialized
DEBUG - 2024-09-16 18:19:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-16 18:19:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-16 18:19:46 --> Final output sent to browser
DEBUG - 2024-09-16 18:19:46 --> Total execution time: 0.2094
INFO - 2024-09-16 18:20:09 --> Config Class Initialized
INFO - 2024-09-16 18:20:09 --> Hooks Class Initialized
DEBUG - 2024-09-16 18:20:09 --> UTF-8 Support Enabled
INFO - 2024-09-16 18:20:09 --> Utf8 Class Initialized
INFO - 2024-09-16 18:20:09 --> URI Class Initialized
INFO - 2024-09-16 18:20:09 --> Router Class Initialized
INFO - 2024-09-16 18:20:09 --> Output Class Initialized
INFO - 2024-09-16 18:20:09 --> Security Class Initialized
DEBUG - 2024-09-16 18:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-16 18:20:09 --> Input Class Initialized
INFO - 2024-09-16 18:20:09 --> Language Class Initialized
INFO - 2024-09-16 18:20:09 --> Language Class Initialized
INFO - 2024-09-16 18:20:09 --> Config Class Initialized
INFO - 2024-09-16 18:20:09 --> Loader Class Initialized
INFO - 2024-09-16 18:20:09 --> Helper loaded: url_helper
INFO - 2024-09-16 18:20:09 --> Helper loaded: file_helper
INFO - 2024-09-16 18:20:09 --> Helper loaded: form_helper
INFO - 2024-09-16 18:20:09 --> Helper loaded: my_helper
INFO - 2024-09-16 18:20:09 --> Database Driver Class Initialized
INFO - 2024-09-16 18:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-16 18:20:09 --> Controller Class Initialized
ERROR - 2024-09-16 18:20:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-16 18:20:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-16 18:20:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-16 18:20:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-16 18:20:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-16 18:20:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-16 18:20:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-16 18:20:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-16 18:20:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-16 18:20:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-16 18:20:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-16 18:20:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-16 18:20:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-16 18:20:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-16 18:20:14 --> Final output sent to browser
DEBUG - 2024-09-16 18:20:14 --> Total execution time: 5.0045
INFO - 2024-09-16 18:20:14 --> Config Class Initialized
INFO - 2024-09-16 18:20:14 --> Hooks Class Initialized
DEBUG - 2024-09-16 18:20:14 --> UTF-8 Support Enabled
INFO - 2024-09-16 18:20:14 --> Utf8 Class Initialized
INFO - 2024-09-16 18:20:14 --> URI Class Initialized
INFO - 2024-09-16 18:20:14 --> Router Class Initialized
INFO - 2024-09-16 18:20:14 --> Output Class Initialized
INFO - 2024-09-16 18:20:14 --> Security Class Initialized
DEBUG - 2024-09-16 18:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-16 18:20:14 --> Input Class Initialized
INFO - 2024-09-16 18:20:14 --> Language Class Initialized
INFO - 2024-09-16 18:20:14 --> Language Class Initialized
INFO - 2024-09-16 18:20:14 --> Config Class Initialized
INFO - 2024-09-16 18:20:14 --> Loader Class Initialized
INFO - 2024-09-16 18:20:14 --> Helper loaded: url_helper
INFO - 2024-09-16 18:20:14 --> Helper loaded: file_helper
INFO - 2024-09-16 18:20:14 --> Helper loaded: form_helper
INFO - 2024-09-16 18:20:14 --> Helper loaded: my_helper
INFO - 2024-09-16 18:20:14 --> Database Driver Class Initialized
INFO - 2024-09-16 18:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-16 18:20:14 --> Controller Class Initialized
ERROR - 2024-09-16 18:20:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-16 18:20:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-16 18:20:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-16 18:20:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-16 18:20:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-16 18:20:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-16 18:20:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-16 18:20:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-16 18:20:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-16 18:20:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-16 18:20:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-16 18:20:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-16 18:20:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-16 18:20:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-16 18:20:19 --> Final output sent to browser
DEBUG - 2024-09-16 18:20:19 --> Total execution time: 4.3708
INFO - 2024-09-16 18:20:19 --> Config Class Initialized
INFO - 2024-09-16 18:20:19 --> Hooks Class Initialized
DEBUG - 2024-09-16 18:20:19 --> UTF-8 Support Enabled
INFO - 2024-09-16 18:20:19 --> Utf8 Class Initialized
INFO - 2024-09-16 18:20:19 --> URI Class Initialized
INFO - 2024-09-16 18:20:19 --> Router Class Initialized
INFO - 2024-09-16 18:20:19 --> Output Class Initialized
INFO - 2024-09-16 18:20:19 --> Security Class Initialized
DEBUG - 2024-09-16 18:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-16 18:20:19 --> Input Class Initialized
INFO - 2024-09-16 18:20:19 --> Language Class Initialized
INFO - 2024-09-16 18:20:19 --> Language Class Initialized
INFO - 2024-09-16 18:20:19 --> Config Class Initialized
INFO - 2024-09-16 18:20:19 --> Loader Class Initialized
INFO - 2024-09-16 18:20:19 --> Helper loaded: url_helper
INFO - 2024-09-16 18:20:19 --> Helper loaded: file_helper
INFO - 2024-09-16 18:20:19 --> Helper loaded: form_helper
INFO - 2024-09-16 18:20:19 --> Helper loaded: my_helper
INFO - 2024-09-16 18:20:19 --> Database Driver Class Initialized
INFO - 2024-09-16 18:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-16 18:20:19 --> Controller Class Initialized
ERROR - 2024-09-16 18:20:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-16 18:20:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-16 18:20:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-16 18:20:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-16 18:20:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-16 18:20:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-16 18:20:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-16 18:20:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-16 18:20:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-16 18:20:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-16 18:20:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-16 18:20:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-16 18:20:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-16 18:20:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-16 18:20:25 --> Final output sent to browser
DEBUG - 2024-09-16 18:20:25 --> Total execution time: 5.7586
INFO - 2024-09-16 18:20:26 --> Config Class Initialized
INFO - 2024-09-16 18:20:26 --> Hooks Class Initialized
DEBUG - 2024-09-16 18:20:26 --> UTF-8 Support Enabled
INFO - 2024-09-16 18:20:26 --> Utf8 Class Initialized
INFO - 2024-09-16 18:20:26 --> URI Class Initialized
INFO - 2024-09-16 18:20:26 --> Router Class Initialized
INFO - 2024-09-16 18:20:26 --> Output Class Initialized
INFO - 2024-09-16 18:20:26 --> Security Class Initialized
DEBUG - 2024-09-16 18:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-16 18:20:26 --> Input Class Initialized
INFO - 2024-09-16 18:20:26 --> Language Class Initialized
INFO - 2024-09-16 18:20:26 --> Language Class Initialized
INFO - 2024-09-16 18:20:26 --> Config Class Initialized
INFO - 2024-09-16 18:20:26 --> Loader Class Initialized
INFO - 2024-09-16 18:20:26 --> Helper loaded: url_helper
INFO - 2024-09-16 18:20:26 --> Helper loaded: file_helper
INFO - 2024-09-16 18:20:26 --> Helper loaded: form_helper
INFO - 2024-09-16 18:20:26 --> Helper loaded: my_helper
INFO - 2024-09-16 18:20:26 --> Database Driver Class Initialized
INFO - 2024-09-16 18:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-16 18:20:26 --> Controller Class Initialized
ERROR - 2024-09-16 18:20:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-16 18:20:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-16 18:20:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-16 18:20:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-16 18:20:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-16 18:20:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-16 18:20:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-16 18:20:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-16 18:20:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-16 18:20:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-16 18:20:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-16 18:20:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-16 18:20:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-16 18:20:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-16 18:20:31 --> Final output sent to browser
DEBUG - 2024-09-16 18:20:31 --> Total execution time: 4.9129
INFO - 2024-09-16 18:20:31 --> Config Class Initialized
INFO - 2024-09-16 18:20:31 --> Hooks Class Initialized
DEBUG - 2024-09-16 18:20:31 --> UTF-8 Support Enabled
INFO - 2024-09-16 18:20:31 --> Utf8 Class Initialized
INFO - 2024-09-16 18:20:31 --> URI Class Initialized
INFO - 2024-09-16 18:20:31 --> Router Class Initialized
INFO - 2024-09-16 18:20:31 --> Output Class Initialized
INFO - 2024-09-16 18:20:31 --> Security Class Initialized
DEBUG - 2024-09-16 18:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-16 18:20:31 --> Input Class Initialized
INFO - 2024-09-16 18:20:31 --> Language Class Initialized
INFO - 2024-09-16 18:20:31 --> Language Class Initialized
INFO - 2024-09-16 18:20:31 --> Config Class Initialized
INFO - 2024-09-16 18:20:31 --> Loader Class Initialized
INFO - 2024-09-16 18:20:31 --> Helper loaded: url_helper
INFO - 2024-09-16 18:20:31 --> Helper loaded: file_helper
INFO - 2024-09-16 18:20:31 --> Helper loaded: form_helper
INFO - 2024-09-16 18:20:31 --> Helper loaded: my_helper
INFO - 2024-09-16 18:20:31 --> Database Driver Class Initialized
INFO - 2024-09-16 18:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-16 18:20:32 --> Controller Class Initialized
ERROR - 2024-09-16 18:20:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-16 18:20:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-16 18:20:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-16 18:20:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-16 18:20:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-16 18:20:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-16 18:20:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-16 18:20:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-16 18:20:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-16 18:20:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-16 18:20:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-16 18:20:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-16 18:20:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-16 18:20:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-16 18:20:35 --> Final output sent to browser
DEBUG - 2024-09-16 18:20:35 --> Total execution time: 3.9893
