<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-07-05 03:53:04 --> Config Class Initialized
INFO - 2023-07-05 03:53:04 --> Hooks Class Initialized
DEBUG - 2023-07-05 03:53:04 --> UTF-8 Support Enabled
INFO - 2023-07-05 03:53:04 --> Utf8 Class Initialized
INFO - 2023-07-05 03:53:04 --> URI Class Initialized
DEBUG - 2023-07-05 03:53:05 --> No URI present. Default controller set.
INFO - 2023-07-05 03:53:05 --> Router Class Initialized
INFO - 2023-07-05 03:53:05 --> Output Class Initialized
INFO - 2023-07-05 03:53:05 --> Security Class Initialized
DEBUG - 2023-07-05 03:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-05 03:53:05 --> Input Class Initialized
INFO - 2023-07-05 03:53:05 --> Language Class Initialized
INFO - 2023-07-05 03:53:05 --> Language Class Initialized
INFO - 2023-07-05 03:53:05 --> Config Class Initialized
INFO - 2023-07-05 03:53:05 --> Loader Class Initialized
INFO - 2023-07-05 03:53:05 --> Helper loaded: url_helper
INFO - 2023-07-05 03:53:05 --> Helper loaded: file_helper
INFO - 2023-07-05 03:53:05 --> Helper loaded: form_helper
INFO - 2023-07-05 03:53:05 --> Helper loaded: my_helper
INFO - 2023-07-05 03:53:05 --> Database Driver Class Initialized
DEBUG - 2023-07-05 03:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-05 03:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-05 03:53:05 --> Controller Class Initialized
INFO - 2023-07-05 03:53:05 --> Config Class Initialized
INFO - 2023-07-05 03:53:05 --> Hooks Class Initialized
DEBUG - 2023-07-05 03:53:05 --> UTF-8 Support Enabled
INFO - 2023-07-05 03:53:05 --> Utf8 Class Initialized
INFO - 2023-07-05 03:53:05 --> URI Class Initialized
INFO - 2023-07-05 03:53:05 --> Router Class Initialized
INFO - 2023-07-05 03:53:05 --> Output Class Initialized
INFO - 2023-07-05 03:53:05 --> Security Class Initialized
DEBUG - 2023-07-05 03:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-05 03:53:05 --> Input Class Initialized
INFO - 2023-07-05 03:53:05 --> Language Class Initialized
INFO - 2023-07-05 03:53:05 --> Language Class Initialized
INFO - 2023-07-05 03:53:05 --> Config Class Initialized
INFO - 2023-07-05 03:53:05 --> Loader Class Initialized
INFO - 2023-07-05 03:53:05 --> Helper loaded: url_helper
INFO - 2023-07-05 03:53:05 --> Helper loaded: file_helper
INFO - 2023-07-05 03:53:05 --> Helper loaded: form_helper
INFO - 2023-07-05 03:53:05 --> Helper loaded: my_helper
INFO - 2023-07-05 03:53:05 --> Database Driver Class Initialized
DEBUG - 2023-07-05 03:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-05 03:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-05 03:53:05 --> Controller Class Initialized
DEBUG - 2023-07-05 03:53:05 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/login/views/login.php
DEBUG - 2023-07-05 03:53:05 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-05 03:53:05 --> Final output sent to browser
DEBUG - 2023-07-05 03:53:05 --> Total execution time: 0.0861
