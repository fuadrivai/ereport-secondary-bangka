<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-08-25 10:52:35 --> Config Class Initialized
INFO - 2023-08-25 10:52:35 --> Hooks Class Initialized
DEBUG - 2023-08-25 10:52:35 --> UTF-8 Support Enabled
INFO - 2023-08-25 10:52:35 --> Utf8 Class Initialized
INFO - 2023-08-25 10:52:35 --> URI Class Initialized
INFO - 2023-08-25 10:52:35 --> Router Class Initialized
INFO - 2023-08-25 10:52:35 --> Output Class Initialized
INFO - 2023-08-25 10:52:35 --> Security Class Initialized
DEBUG - 2023-08-25 10:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-25 10:52:35 --> Input Class Initialized
INFO - 2023-08-25 10:52:35 --> Language Class Initialized
INFO - 2023-08-25 10:52:35 --> Language Class Initialized
INFO - 2023-08-25 10:52:35 --> Config Class Initialized
INFO - 2023-08-25 10:52:35 --> Loader Class Initialized
INFO - 2023-08-25 10:52:35 --> Helper loaded: url_helper
INFO - 2023-08-25 10:52:35 --> Helper loaded: file_helper
INFO - 2023-08-25 10:52:35 --> Helper loaded: form_helper
INFO - 2023-08-25 10:52:35 --> Helper loaded: my_helper
INFO - 2023-08-25 10:52:35 --> Database Driver Class Initialized
INFO - 2023-08-25 10:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-25 10:52:35 --> Controller Class Initialized
DEBUG - 2023-08-25 10:52:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-08-25 10:52:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-25 10:52:35 --> Final output sent to browser
DEBUG - 2023-08-25 10:52:35 --> Total execution time: 0.0542
