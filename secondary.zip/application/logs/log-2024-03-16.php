<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-03-16 08:20:52 --> Config Class Initialized
INFO - 2024-03-16 08:20:52 --> Hooks Class Initialized
DEBUG - 2024-03-16 08:20:52 --> UTF-8 Support Enabled
INFO - 2024-03-16 08:20:52 --> Utf8 Class Initialized
INFO - 2024-03-16 08:20:52 --> URI Class Initialized
INFO - 2024-03-16 08:20:52 --> Router Class Initialized
INFO - 2024-03-16 08:20:52 --> Output Class Initialized
INFO - 2024-03-16 08:20:52 --> Security Class Initialized
DEBUG - 2024-03-16 08:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 08:20:52 --> Input Class Initialized
INFO - 2024-03-16 08:20:52 --> Language Class Initialized
INFO - 2024-03-16 08:20:52 --> Language Class Initialized
INFO - 2024-03-16 08:20:52 --> Config Class Initialized
INFO - 2024-03-16 08:20:52 --> Loader Class Initialized
INFO - 2024-03-16 08:20:52 --> Helper loaded: url_helper
INFO - 2024-03-16 08:20:52 --> Helper loaded: file_helper
INFO - 2024-03-16 08:20:52 --> Helper loaded: form_helper
INFO - 2024-03-16 08:20:52 --> Helper loaded: my_helper
INFO - 2024-03-16 08:20:52 --> Database Driver Class Initialized
INFO - 2024-03-16 08:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 08:20:52 --> Controller Class Initialized
DEBUG - 2024-03-16 08:20:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-16 08:20:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-16 08:20:52 --> Final output sent to browser
DEBUG - 2024-03-16 08:20:52 --> Total execution time: 0.2306
INFO - 2024-03-16 08:21:10 --> Config Class Initialized
INFO - 2024-03-16 08:21:10 --> Hooks Class Initialized
DEBUG - 2024-03-16 08:21:10 --> UTF-8 Support Enabled
INFO - 2024-03-16 08:21:10 --> Utf8 Class Initialized
INFO - 2024-03-16 08:21:10 --> URI Class Initialized
INFO - 2024-03-16 08:21:10 --> Router Class Initialized
INFO - 2024-03-16 08:21:10 --> Output Class Initialized
INFO - 2024-03-16 08:21:10 --> Security Class Initialized
DEBUG - 2024-03-16 08:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 08:21:10 --> Input Class Initialized
INFO - 2024-03-16 08:21:10 --> Language Class Initialized
INFO - 2024-03-16 08:21:10 --> Language Class Initialized
INFO - 2024-03-16 08:21:10 --> Config Class Initialized
INFO - 2024-03-16 08:21:10 --> Loader Class Initialized
INFO - 2024-03-16 08:21:10 --> Helper loaded: url_helper
INFO - 2024-03-16 08:21:10 --> Helper loaded: file_helper
INFO - 2024-03-16 08:21:10 --> Helper loaded: form_helper
INFO - 2024-03-16 08:21:10 --> Helper loaded: my_helper
INFO - 2024-03-16 08:21:10 --> Database Driver Class Initialized
INFO - 2024-03-16 08:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 08:21:10 --> Controller Class Initialized
INFO - 2024-03-16 08:21:11 --> Helper loaded: cookie_helper
INFO - 2024-03-16 08:21:11 --> Final output sent to browser
DEBUG - 2024-03-16 08:21:11 --> Total execution time: 0.3447
INFO - 2024-03-16 08:21:11 --> Config Class Initialized
INFO - 2024-03-16 08:21:11 --> Hooks Class Initialized
DEBUG - 2024-03-16 08:21:11 --> UTF-8 Support Enabled
INFO - 2024-03-16 08:21:11 --> Utf8 Class Initialized
INFO - 2024-03-16 08:21:11 --> URI Class Initialized
INFO - 2024-03-16 08:21:11 --> Router Class Initialized
INFO - 2024-03-16 08:21:11 --> Output Class Initialized
INFO - 2024-03-16 08:21:11 --> Security Class Initialized
DEBUG - 2024-03-16 08:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 08:21:11 --> Input Class Initialized
INFO - 2024-03-16 08:21:11 --> Language Class Initialized
INFO - 2024-03-16 08:21:11 --> Language Class Initialized
INFO - 2024-03-16 08:21:11 --> Config Class Initialized
INFO - 2024-03-16 08:21:11 --> Loader Class Initialized
INFO - 2024-03-16 08:21:11 --> Helper loaded: url_helper
INFO - 2024-03-16 08:21:11 --> Helper loaded: file_helper
INFO - 2024-03-16 08:21:11 --> Helper loaded: form_helper
INFO - 2024-03-16 08:21:11 --> Helper loaded: my_helper
INFO - 2024-03-16 08:21:11 --> Database Driver Class Initialized
INFO - 2024-03-16 08:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 08:21:11 --> Controller Class Initialized
DEBUG - 2024-03-16 08:21:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-16 08:21:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-16 08:21:11 --> Final output sent to browser
DEBUG - 2024-03-16 08:21:11 --> Total execution time: 0.0475
INFO - 2024-03-16 08:21:25 --> Config Class Initialized
INFO - 2024-03-16 08:21:25 --> Hooks Class Initialized
DEBUG - 2024-03-16 08:21:25 --> UTF-8 Support Enabled
INFO - 2024-03-16 08:21:25 --> Utf8 Class Initialized
INFO - 2024-03-16 08:21:25 --> URI Class Initialized
INFO - 2024-03-16 08:21:25 --> Router Class Initialized
INFO - 2024-03-16 08:21:25 --> Output Class Initialized
INFO - 2024-03-16 08:21:25 --> Security Class Initialized
DEBUG - 2024-03-16 08:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 08:21:25 --> Input Class Initialized
INFO - 2024-03-16 08:21:25 --> Language Class Initialized
INFO - 2024-03-16 08:21:25 --> Language Class Initialized
INFO - 2024-03-16 08:21:25 --> Config Class Initialized
INFO - 2024-03-16 08:21:25 --> Loader Class Initialized
INFO - 2024-03-16 08:21:25 --> Helper loaded: url_helper
INFO - 2024-03-16 08:21:25 --> Helper loaded: file_helper
INFO - 2024-03-16 08:21:25 --> Helper loaded: form_helper
INFO - 2024-03-16 08:21:25 --> Helper loaded: my_helper
INFO - 2024-03-16 08:21:25 --> Database Driver Class Initialized
INFO - 2024-03-16 08:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 08:21:25 --> Controller Class Initialized
DEBUG - 2024-03-16 08:21:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-16 08:21:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-16 08:21:25 --> Final output sent to browser
DEBUG - 2024-03-16 08:21:25 --> Total execution time: 0.0302
INFO - 2024-03-16 08:21:28 --> Config Class Initialized
INFO - 2024-03-16 08:21:28 --> Hooks Class Initialized
DEBUG - 2024-03-16 08:21:28 --> UTF-8 Support Enabled
INFO - 2024-03-16 08:21:28 --> Utf8 Class Initialized
INFO - 2024-03-16 08:21:28 --> URI Class Initialized
INFO - 2024-03-16 08:21:28 --> Router Class Initialized
INFO - 2024-03-16 08:21:28 --> Output Class Initialized
INFO - 2024-03-16 08:21:28 --> Security Class Initialized
DEBUG - 2024-03-16 08:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 08:21:28 --> Input Class Initialized
INFO - 2024-03-16 08:21:28 --> Language Class Initialized
INFO - 2024-03-16 08:21:28 --> Language Class Initialized
INFO - 2024-03-16 08:21:28 --> Config Class Initialized
INFO - 2024-03-16 08:21:28 --> Loader Class Initialized
INFO - 2024-03-16 08:21:28 --> Helper loaded: url_helper
INFO - 2024-03-16 08:21:28 --> Helper loaded: file_helper
INFO - 2024-03-16 08:21:28 --> Helper loaded: form_helper
INFO - 2024-03-16 08:21:28 --> Helper loaded: my_helper
INFO - 2024-03-16 08:21:28 --> Database Driver Class Initialized
INFO - 2024-03-16 08:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 08:21:28 --> Controller Class Initialized
DEBUG - 2024-03-16 08:21:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-16 08:21:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-16 08:21:28 --> Final output sent to browser
DEBUG - 2024-03-16 08:21:28 --> Total execution time: 0.0464
INFO - 2024-03-16 08:21:29 --> Config Class Initialized
INFO - 2024-03-16 08:21:29 --> Hooks Class Initialized
DEBUG - 2024-03-16 08:21:29 --> UTF-8 Support Enabled
INFO - 2024-03-16 08:21:29 --> Utf8 Class Initialized
INFO - 2024-03-16 08:21:29 --> URI Class Initialized
INFO - 2024-03-16 08:21:29 --> Router Class Initialized
INFO - 2024-03-16 08:21:29 --> Output Class Initialized
INFO - 2024-03-16 08:21:29 --> Security Class Initialized
DEBUG - 2024-03-16 08:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 08:21:29 --> Input Class Initialized
INFO - 2024-03-16 08:21:29 --> Language Class Initialized
INFO - 2024-03-16 08:21:29 --> Language Class Initialized
INFO - 2024-03-16 08:21:29 --> Config Class Initialized
INFO - 2024-03-16 08:21:29 --> Loader Class Initialized
INFO - 2024-03-16 08:21:29 --> Helper loaded: url_helper
INFO - 2024-03-16 08:21:29 --> Helper loaded: file_helper
INFO - 2024-03-16 08:21:29 --> Helper loaded: form_helper
INFO - 2024-03-16 08:21:29 --> Helper loaded: my_helper
INFO - 2024-03-16 08:21:29 --> Database Driver Class Initialized
INFO - 2024-03-16 08:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 08:21:29 --> Controller Class Initialized
INFO - 2024-03-16 08:21:35 --> Config Class Initialized
INFO - 2024-03-16 08:21:35 --> Hooks Class Initialized
DEBUG - 2024-03-16 08:21:35 --> UTF-8 Support Enabled
INFO - 2024-03-16 08:21:35 --> Utf8 Class Initialized
INFO - 2024-03-16 08:21:35 --> URI Class Initialized
INFO - 2024-03-16 08:21:35 --> Router Class Initialized
INFO - 2024-03-16 08:21:35 --> Output Class Initialized
INFO - 2024-03-16 08:21:35 --> Security Class Initialized
DEBUG - 2024-03-16 08:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 08:21:35 --> Input Class Initialized
INFO - 2024-03-16 08:21:35 --> Language Class Initialized
INFO - 2024-03-16 08:21:36 --> Language Class Initialized
INFO - 2024-03-16 08:21:36 --> Config Class Initialized
INFO - 2024-03-16 08:21:36 --> Loader Class Initialized
INFO - 2024-03-16 08:21:36 --> Helper loaded: url_helper
INFO - 2024-03-16 08:21:36 --> Helper loaded: file_helper
INFO - 2024-03-16 08:21:36 --> Helper loaded: form_helper
INFO - 2024-03-16 08:21:36 --> Helper loaded: my_helper
INFO - 2024-03-16 08:21:36 --> Database Driver Class Initialized
INFO - 2024-03-16 08:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 08:21:36 --> Controller Class Initialized
INFO - 2024-03-16 08:21:36 --> Final output sent to browser
DEBUG - 2024-03-16 08:21:36 --> Total execution time: 0.0570
INFO - 2024-03-16 08:21:42 --> Config Class Initialized
INFO - 2024-03-16 08:21:42 --> Hooks Class Initialized
DEBUG - 2024-03-16 08:21:42 --> UTF-8 Support Enabled
INFO - 2024-03-16 08:21:42 --> Utf8 Class Initialized
INFO - 2024-03-16 08:21:42 --> URI Class Initialized
INFO - 2024-03-16 08:21:42 --> Router Class Initialized
INFO - 2024-03-16 08:21:42 --> Output Class Initialized
INFO - 2024-03-16 08:21:42 --> Security Class Initialized
DEBUG - 2024-03-16 08:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 08:21:42 --> Input Class Initialized
INFO - 2024-03-16 08:21:42 --> Language Class Initialized
INFO - 2024-03-16 08:21:42 --> Language Class Initialized
INFO - 2024-03-16 08:21:42 --> Config Class Initialized
INFO - 2024-03-16 08:21:42 --> Loader Class Initialized
INFO - 2024-03-16 08:21:42 --> Helper loaded: url_helper
INFO - 2024-03-16 08:21:42 --> Helper loaded: file_helper
INFO - 2024-03-16 08:21:42 --> Helper loaded: form_helper
INFO - 2024-03-16 08:21:42 --> Helper loaded: my_helper
INFO - 2024-03-16 08:21:42 --> Database Driver Class Initialized
INFO - 2024-03-16 08:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 08:21:42 --> Controller Class Initialized
INFO - 2024-03-16 08:21:42 --> Final output sent to browser
DEBUG - 2024-03-16 08:21:42 --> Total execution time: 0.0403
INFO - 2024-03-16 08:22:06 --> Config Class Initialized
INFO - 2024-03-16 08:22:06 --> Hooks Class Initialized
DEBUG - 2024-03-16 08:22:06 --> UTF-8 Support Enabled
INFO - 2024-03-16 08:22:06 --> Utf8 Class Initialized
INFO - 2024-03-16 08:22:06 --> URI Class Initialized
INFO - 2024-03-16 08:22:06 --> Router Class Initialized
INFO - 2024-03-16 08:22:06 --> Output Class Initialized
INFO - 2024-03-16 08:22:06 --> Security Class Initialized
DEBUG - 2024-03-16 08:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 08:22:06 --> Input Class Initialized
INFO - 2024-03-16 08:22:06 --> Language Class Initialized
INFO - 2024-03-16 08:22:06 --> Language Class Initialized
INFO - 2024-03-16 08:22:06 --> Config Class Initialized
INFO - 2024-03-16 08:22:06 --> Loader Class Initialized
INFO - 2024-03-16 08:22:06 --> Helper loaded: url_helper
INFO - 2024-03-16 08:22:06 --> Helper loaded: file_helper
INFO - 2024-03-16 08:22:06 --> Helper loaded: form_helper
INFO - 2024-03-16 08:22:06 --> Helper loaded: my_helper
INFO - 2024-03-16 08:22:06 --> Database Driver Class Initialized
INFO - 2024-03-16 08:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 08:22:06 --> Controller Class Initialized
DEBUG - 2024-03-16 08:22:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-16 08:22:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-16 08:22:06 --> Final output sent to browser
DEBUG - 2024-03-16 08:22:06 --> Total execution time: 0.0258
INFO - 2024-03-16 08:22:09 --> Config Class Initialized
INFO - 2024-03-16 08:22:09 --> Hooks Class Initialized
DEBUG - 2024-03-16 08:22:09 --> UTF-8 Support Enabled
INFO - 2024-03-16 08:22:09 --> Utf8 Class Initialized
INFO - 2024-03-16 08:22:09 --> URI Class Initialized
INFO - 2024-03-16 08:22:09 --> Router Class Initialized
INFO - 2024-03-16 08:22:09 --> Output Class Initialized
INFO - 2024-03-16 08:22:09 --> Security Class Initialized
DEBUG - 2024-03-16 08:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 08:22:09 --> Input Class Initialized
INFO - 2024-03-16 08:22:09 --> Language Class Initialized
INFO - 2024-03-16 08:22:09 --> Language Class Initialized
INFO - 2024-03-16 08:22:09 --> Config Class Initialized
INFO - 2024-03-16 08:22:09 --> Loader Class Initialized
INFO - 2024-03-16 08:22:09 --> Helper loaded: url_helper
INFO - 2024-03-16 08:22:09 --> Helper loaded: file_helper
INFO - 2024-03-16 08:22:09 --> Helper loaded: form_helper
INFO - 2024-03-16 08:22:09 --> Helper loaded: my_helper
INFO - 2024-03-16 08:22:09 --> Database Driver Class Initialized
INFO - 2024-03-16 08:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 08:22:09 --> Controller Class Initialized
DEBUG - 2024-03-16 08:22:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-16 08:22:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-16 08:22:09 --> Final output sent to browser
DEBUG - 2024-03-16 08:22:09 --> Total execution time: 0.0311
INFO - 2024-03-16 08:22:09 --> Config Class Initialized
INFO - 2024-03-16 08:22:09 --> Hooks Class Initialized
DEBUG - 2024-03-16 08:22:09 --> UTF-8 Support Enabled
INFO - 2024-03-16 08:22:09 --> Utf8 Class Initialized
INFO - 2024-03-16 08:22:09 --> URI Class Initialized
INFO - 2024-03-16 08:22:09 --> Router Class Initialized
INFO - 2024-03-16 08:22:09 --> Output Class Initialized
INFO - 2024-03-16 08:22:09 --> Security Class Initialized
DEBUG - 2024-03-16 08:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 08:22:09 --> Input Class Initialized
INFO - 2024-03-16 08:22:09 --> Language Class Initialized
INFO - 2024-03-16 08:22:09 --> Language Class Initialized
INFO - 2024-03-16 08:22:09 --> Config Class Initialized
INFO - 2024-03-16 08:22:09 --> Loader Class Initialized
INFO - 2024-03-16 08:22:09 --> Helper loaded: url_helper
INFO - 2024-03-16 08:22:09 --> Helper loaded: file_helper
INFO - 2024-03-16 08:22:09 --> Helper loaded: form_helper
INFO - 2024-03-16 08:22:09 --> Helper loaded: my_helper
INFO - 2024-03-16 08:22:09 --> Database Driver Class Initialized
INFO - 2024-03-16 08:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 08:22:09 --> Controller Class Initialized
INFO - 2024-03-16 08:22:13 --> Config Class Initialized
INFO - 2024-03-16 08:22:13 --> Hooks Class Initialized
DEBUG - 2024-03-16 08:22:13 --> UTF-8 Support Enabled
INFO - 2024-03-16 08:22:13 --> Utf8 Class Initialized
INFO - 2024-03-16 08:22:13 --> URI Class Initialized
INFO - 2024-03-16 08:22:13 --> Router Class Initialized
INFO - 2024-03-16 08:22:13 --> Output Class Initialized
INFO - 2024-03-16 08:22:13 --> Security Class Initialized
DEBUG - 2024-03-16 08:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 08:22:13 --> Input Class Initialized
INFO - 2024-03-16 08:22:13 --> Language Class Initialized
INFO - 2024-03-16 08:22:13 --> Language Class Initialized
INFO - 2024-03-16 08:22:13 --> Config Class Initialized
INFO - 2024-03-16 08:22:13 --> Loader Class Initialized
INFO - 2024-03-16 08:22:13 --> Helper loaded: url_helper
INFO - 2024-03-16 08:22:13 --> Helper loaded: file_helper
INFO - 2024-03-16 08:22:13 --> Helper loaded: form_helper
INFO - 2024-03-16 08:22:13 --> Helper loaded: my_helper
INFO - 2024-03-16 08:22:13 --> Database Driver Class Initialized
INFO - 2024-03-16 08:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 08:22:13 --> Controller Class Initialized
INFO - 2024-03-16 08:22:13 --> Final output sent to browser
DEBUG - 2024-03-16 08:22:13 --> Total execution time: 0.0463
INFO - 2024-03-16 08:22:15 --> Config Class Initialized
INFO - 2024-03-16 08:22:15 --> Hooks Class Initialized
DEBUG - 2024-03-16 08:22:15 --> UTF-8 Support Enabled
INFO - 2024-03-16 08:22:15 --> Utf8 Class Initialized
INFO - 2024-03-16 08:22:15 --> URI Class Initialized
INFO - 2024-03-16 08:22:15 --> Router Class Initialized
INFO - 2024-03-16 08:22:15 --> Output Class Initialized
INFO - 2024-03-16 08:22:15 --> Security Class Initialized
DEBUG - 2024-03-16 08:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 08:22:15 --> Input Class Initialized
INFO - 2024-03-16 08:22:15 --> Language Class Initialized
INFO - 2024-03-16 08:22:15 --> Language Class Initialized
INFO - 2024-03-16 08:22:15 --> Config Class Initialized
INFO - 2024-03-16 08:22:15 --> Loader Class Initialized
INFO - 2024-03-16 08:22:15 --> Helper loaded: url_helper
INFO - 2024-03-16 08:22:15 --> Helper loaded: file_helper
INFO - 2024-03-16 08:22:15 --> Helper loaded: form_helper
INFO - 2024-03-16 08:22:15 --> Helper loaded: my_helper
INFO - 2024-03-16 08:22:15 --> Database Driver Class Initialized
INFO - 2024-03-16 08:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 08:22:15 --> Controller Class Initialized
INFO - 2024-03-16 08:22:15 --> Final output sent to browser
DEBUG - 2024-03-16 08:22:15 --> Total execution time: 0.0301
INFO - 2024-03-16 08:22:18 --> Config Class Initialized
INFO - 2024-03-16 08:22:18 --> Hooks Class Initialized
DEBUG - 2024-03-16 08:22:18 --> UTF-8 Support Enabled
INFO - 2024-03-16 08:22:18 --> Utf8 Class Initialized
INFO - 2024-03-16 08:22:18 --> URI Class Initialized
INFO - 2024-03-16 08:22:18 --> Router Class Initialized
INFO - 2024-03-16 08:22:18 --> Output Class Initialized
INFO - 2024-03-16 08:22:18 --> Security Class Initialized
DEBUG - 2024-03-16 08:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 08:22:18 --> Input Class Initialized
INFO - 2024-03-16 08:22:18 --> Language Class Initialized
INFO - 2024-03-16 08:22:18 --> Language Class Initialized
INFO - 2024-03-16 08:22:18 --> Config Class Initialized
INFO - 2024-03-16 08:22:18 --> Loader Class Initialized
INFO - 2024-03-16 08:22:18 --> Helper loaded: url_helper
INFO - 2024-03-16 08:22:18 --> Helper loaded: file_helper
INFO - 2024-03-16 08:22:18 --> Helper loaded: form_helper
INFO - 2024-03-16 08:22:18 --> Helper loaded: my_helper
INFO - 2024-03-16 08:22:18 --> Database Driver Class Initialized
INFO - 2024-03-16 08:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 08:22:18 --> Controller Class Initialized
INFO - 2024-03-16 08:22:18 --> Final output sent to browser
DEBUG - 2024-03-16 08:22:18 --> Total execution time: 0.1067
INFO - 2024-03-16 08:22:24 --> Config Class Initialized
INFO - 2024-03-16 08:22:24 --> Hooks Class Initialized
DEBUG - 2024-03-16 08:22:24 --> UTF-8 Support Enabled
INFO - 2024-03-16 08:22:24 --> Utf8 Class Initialized
INFO - 2024-03-16 08:22:24 --> URI Class Initialized
INFO - 2024-03-16 08:22:24 --> Router Class Initialized
INFO - 2024-03-16 08:22:24 --> Output Class Initialized
INFO - 2024-03-16 08:22:24 --> Security Class Initialized
DEBUG - 2024-03-16 08:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 08:22:24 --> Input Class Initialized
INFO - 2024-03-16 08:22:24 --> Language Class Initialized
INFO - 2024-03-16 08:22:24 --> Language Class Initialized
INFO - 2024-03-16 08:22:24 --> Config Class Initialized
INFO - 2024-03-16 08:22:24 --> Loader Class Initialized
INFO - 2024-03-16 08:22:24 --> Helper loaded: url_helper
INFO - 2024-03-16 08:22:24 --> Helper loaded: file_helper
INFO - 2024-03-16 08:22:24 --> Helper loaded: form_helper
INFO - 2024-03-16 08:22:24 --> Helper loaded: my_helper
INFO - 2024-03-16 08:22:24 --> Database Driver Class Initialized
INFO - 2024-03-16 08:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 08:22:24 --> Controller Class Initialized
DEBUG - 2024-03-16 08:22:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-16 08:22:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-16 08:22:24 --> Final output sent to browser
DEBUG - 2024-03-16 08:22:24 --> Total execution time: 0.0389
INFO - 2024-03-16 08:22:29 --> Config Class Initialized
INFO - 2024-03-16 08:22:29 --> Hooks Class Initialized
DEBUG - 2024-03-16 08:22:29 --> UTF-8 Support Enabled
INFO - 2024-03-16 08:22:29 --> Utf8 Class Initialized
INFO - 2024-03-16 08:22:29 --> URI Class Initialized
INFO - 2024-03-16 08:22:29 --> Router Class Initialized
INFO - 2024-03-16 08:22:29 --> Output Class Initialized
INFO - 2024-03-16 08:22:29 --> Security Class Initialized
DEBUG - 2024-03-16 08:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 08:22:29 --> Input Class Initialized
INFO - 2024-03-16 08:22:29 --> Language Class Initialized
INFO - 2024-03-16 08:22:29 --> Language Class Initialized
INFO - 2024-03-16 08:22:29 --> Config Class Initialized
INFO - 2024-03-16 08:22:29 --> Loader Class Initialized
INFO - 2024-03-16 08:22:29 --> Helper loaded: url_helper
INFO - 2024-03-16 08:22:29 --> Helper loaded: file_helper
INFO - 2024-03-16 08:22:29 --> Helper loaded: form_helper
INFO - 2024-03-16 08:22:29 --> Helper loaded: my_helper
INFO - 2024-03-16 08:22:29 --> Database Driver Class Initialized
INFO - 2024-03-16 08:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 08:22:29 --> Controller Class Initialized
DEBUG - 2024-03-16 08:22:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2024-03-16 08:22:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-16 08:22:29 --> Final output sent to browser
DEBUG - 2024-03-16 08:22:29 --> Total execution time: 0.0326
INFO - 2024-03-16 08:42:38 --> Config Class Initialized
INFO - 2024-03-16 08:42:38 --> Hooks Class Initialized
DEBUG - 2024-03-16 08:42:38 --> UTF-8 Support Enabled
INFO - 2024-03-16 08:42:38 --> Utf8 Class Initialized
INFO - 2024-03-16 08:42:38 --> URI Class Initialized
INFO - 2024-03-16 08:42:38 --> Router Class Initialized
INFO - 2024-03-16 08:42:38 --> Output Class Initialized
INFO - 2024-03-16 08:42:38 --> Security Class Initialized
DEBUG - 2024-03-16 08:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 08:42:38 --> Input Class Initialized
INFO - 2024-03-16 08:42:38 --> Language Class Initialized
INFO - 2024-03-16 08:42:38 --> Language Class Initialized
INFO - 2024-03-16 08:42:38 --> Config Class Initialized
INFO - 2024-03-16 08:42:38 --> Loader Class Initialized
INFO - 2024-03-16 08:42:38 --> Helper loaded: url_helper
INFO - 2024-03-16 08:42:38 --> Helper loaded: file_helper
INFO - 2024-03-16 08:42:38 --> Helper loaded: form_helper
INFO - 2024-03-16 08:42:38 --> Helper loaded: my_helper
INFO - 2024-03-16 08:42:38 --> Database Driver Class Initialized
INFO - 2024-03-16 08:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 08:42:38 --> Controller Class Initialized
DEBUG - 2024-03-16 08:42:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-16 08:42:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-16 08:42:38 --> Final output sent to browser
DEBUG - 2024-03-16 08:42:38 --> Total execution time: 0.1018
INFO - 2024-03-16 08:42:56 --> Config Class Initialized
INFO - 2024-03-16 08:42:56 --> Hooks Class Initialized
DEBUG - 2024-03-16 08:42:56 --> UTF-8 Support Enabled
INFO - 2024-03-16 08:42:56 --> Utf8 Class Initialized
INFO - 2024-03-16 08:42:56 --> URI Class Initialized
INFO - 2024-03-16 08:42:56 --> Router Class Initialized
INFO - 2024-03-16 08:42:56 --> Output Class Initialized
INFO - 2024-03-16 08:42:56 --> Security Class Initialized
DEBUG - 2024-03-16 08:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 08:42:56 --> Input Class Initialized
INFO - 2024-03-16 08:42:56 --> Language Class Initialized
INFO - 2024-03-16 08:42:56 --> Language Class Initialized
INFO - 2024-03-16 08:42:56 --> Config Class Initialized
INFO - 2024-03-16 08:42:56 --> Loader Class Initialized
INFO - 2024-03-16 08:42:56 --> Helper loaded: url_helper
INFO - 2024-03-16 08:42:56 --> Helper loaded: file_helper
INFO - 2024-03-16 08:42:56 --> Helper loaded: form_helper
INFO - 2024-03-16 08:42:56 --> Helper loaded: my_helper
INFO - 2024-03-16 08:42:56 --> Database Driver Class Initialized
INFO - 2024-03-16 08:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 08:42:56 --> Controller Class Initialized
INFO - 2024-03-16 08:42:56 --> Helper loaded: cookie_helper
INFO - 2024-03-16 08:42:56 --> Final output sent to browser
DEBUG - 2024-03-16 08:42:56 --> Total execution time: 0.0544
INFO - 2024-03-16 08:42:57 --> Config Class Initialized
INFO - 2024-03-16 08:42:57 --> Hooks Class Initialized
DEBUG - 2024-03-16 08:42:57 --> UTF-8 Support Enabled
INFO - 2024-03-16 08:42:57 --> Utf8 Class Initialized
INFO - 2024-03-16 08:42:57 --> URI Class Initialized
INFO - 2024-03-16 08:42:57 --> Router Class Initialized
INFO - 2024-03-16 08:42:57 --> Output Class Initialized
INFO - 2024-03-16 08:42:57 --> Security Class Initialized
DEBUG - 2024-03-16 08:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 08:42:57 --> Input Class Initialized
INFO - 2024-03-16 08:42:57 --> Language Class Initialized
INFO - 2024-03-16 08:42:57 --> Language Class Initialized
INFO - 2024-03-16 08:42:57 --> Config Class Initialized
INFO - 2024-03-16 08:42:57 --> Loader Class Initialized
INFO - 2024-03-16 08:42:57 --> Helper loaded: url_helper
INFO - 2024-03-16 08:42:57 --> Helper loaded: file_helper
INFO - 2024-03-16 08:42:57 --> Helper loaded: form_helper
INFO - 2024-03-16 08:42:57 --> Helper loaded: my_helper
INFO - 2024-03-16 08:42:57 --> Database Driver Class Initialized
INFO - 2024-03-16 08:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 08:42:57 --> Controller Class Initialized
DEBUG - 2024-03-16 08:42:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-16 08:42:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-16 08:42:57 --> Final output sent to browser
DEBUG - 2024-03-16 08:42:57 --> Total execution time: 0.0484
INFO - 2024-03-16 08:42:59 --> Config Class Initialized
INFO - 2024-03-16 08:42:59 --> Hooks Class Initialized
DEBUG - 2024-03-16 08:42:59 --> UTF-8 Support Enabled
INFO - 2024-03-16 08:42:59 --> Utf8 Class Initialized
INFO - 2024-03-16 08:42:59 --> URI Class Initialized
INFO - 2024-03-16 08:42:59 --> Router Class Initialized
INFO - 2024-03-16 08:42:59 --> Output Class Initialized
INFO - 2024-03-16 08:42:59 --> Security Class Initialized
DEBUG - 2024-03-16 08:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 08:42:59 --> Input Class Initialized
INFO - 2024-03-16 08:42:59 --> Language Class Initialized
INFO - 2024-03-16 08:42:59 --> Language Class Initialized
INFO - 2024-03-16 08:42:59 --> Config Class Initialized
INFO - 2024-03-16 08:42:59 --> Loader Class Initialized
INFO - 2024-03-16 08:42:59 --> Helper loaded: url_helper
INFO - 2024-03-16 08:42:59 --> Helper loaded: file_helper
INFO - 2024-03-16 08:42:59 --> Helper loaded: form_helper
INFO - 2024-03-16 08:42:59 --> Helper loaded: my_helper
INFO - 2024-03-16 08:42:59 --> Database Driver Class Initialized
INFO - 2024-03-16 08:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 08:42:59 --> Controller Class Initialized
DEBUG - 2024-03-16 08:42:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-16 08:42:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-16 08:42:59 --> Final output sent to browser
DEBUG - 2024-03-16 08:42:59 --> Total execution time: 0.0298
INFO - 2024-03-16 08:43:01 --> Config Class Initialized
INFO - 2024-03-16 08:43:01 --> Hooks Class Initialized
DEBUG - 2024-03-16 08:43:01 --> UTF-8 Support Enabled
INFO - 2024-03-16 08:43:01 --> Utf8 Class Initialized
INFO - 2024-03-16 08:43:01 --> URI Class Initialized
INFO - 2024-03-16 08:43:01 --> Router Class Initialized
INFO - 2024-03-16 08:43:01 --> Output Class Initialized
INFO - 2024-03-16 08:43:01 --> Security Class Initialized
DEBUG - 2024-03-16 08:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 08:43:01 --> Input Class Initialized
INFO - 2024-03-16 08:43:01 --> Language Class Initialized
INFO - 2024-03-16 08:43:01 --> Language Class Initialized
INFO - 2024-03-16 08:43:01 --> Config Class Initialized
INFO - 2024-03-16 08:43:01 --> Loader Class Initialized
INFO - 2024-03-16 08:43:01 --> Helper loaded: url_helper
INFO - 2024-03-16 08:43:01 --> Helper loaded: file_helper
INFO - 2024-03-16 08:43:01 --> Helper loaded: form_helper
INFO - 2024-03-16 08:43:01 --> Helper loaded: my_helper
INFO - 2024-03-16 08:43:01 --> Database Driver Class Initialized
INFO - 2024-03-16 08:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 08:43:01 --> Controller Class Initialized
DEBUG - 2024-03-16 08:43:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-16 08:43:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-16 08:43:01 --> Final output sent to browser
DEBUG - 2024-03-16 08:43:01 --> Total execution time: 0.0437
INFO - 2024-03-16 08:43:01 --> Config Class Initialized
INFO - 2024-03-16 08:43:01 --> Hooks Class Initialized
DEBUG - 2024-03-16 08:43:01 --> UTF-8 Support Enabled
INFO - 2024-03-16 08:43:01 --> Utf8 Class Initialized
INFO - 2024-03-16 08:43:01 --> URI Class Initialized
INFO - 2024-03-16 08:43:01 --> Router Class Initialized
INFO - 2024-03-16 08:43:01 --> Output Class Initialized
INFO - 2024-03-16 08:43:01 --> Security Class Initialized
DEBUG - 2024-03-16 08:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 08:43:01 --> Input Class Initialized
INFO - 2024-03-16 08:43:01 --> Language Class Initialized
INFO - 2024-03-16 08:43:01 --> Language Class Initialized
INFO - 2024-03-16 08:43:01 --> Config Class Initialized
INFO - 2024-03-16 08:43:01 --> Loader Class Initialized
INFO - 2024-03-16 08:43:01 --> Helper loaded: url_helper
INFO - 2024-03-16 08:43:01 --> Helper loaded: file_helper
INFO - 2024-03-16 08:43:01 --> Helper loaded: form_helper
INFO - 2024-03-16 08:43:01 --> Helper loaded: my_helper
INFO - 2024-03-16 08:43:01 --> Database Driver Class Initialized
INFO - 2024-03-16 08:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 08:43:01 --> Controller Class Initialized
INFO - 2024-03-16 08:43:29 --> Config Class Initialized
INFO - 2024-03-16 08:43:29 --> Hooks Class Initialized
DEBUG - 2024-03-16 08:43:29 --> UTF-8 Support Enabled
INFO - 2024-03-16 08:43:29 --> Utf8 Class Initialized
INFO - 2024-03-16 08:43:29 --> URI Class Initialized
INFO - 2024-03-16 08:43:29 --> Router Class Initialized
INFO - 2024-03-16 08:43:29 --> Output Class Initialized
INFO - 2024-03-16 08:43:29 --> Security Class Initialized
DEBUG - 2024-03-16 08:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 08:43:29 --> Input Class Initialized
INFO - 2024-03-16 08:43:29 --> Language Class Initialized
INFO - 2024-03-16 08:43:29 --> Language Class Initialized
INFO - 2024-03-16 08:43:29 --> Config Class Initialized
INFO - 2024-03-16 08:43:29 --> Loader Class Initialized
INFO - 2024-03-16 08:43:29 --> Helper loaded: url_helper
INFO - 2024-03-16 08:43:29 --> Helper loaded: file_helper
INFO - 2024-03-16 08:43:29 --> Helper loaded: form_helper
INFO - 2024-03-16 08:43:29 --> Helper loaded: my_helper
INFO - 2024-03-16 08:43:29 --> Database Driver Class Initialized
INFO - 2024-03-16 08:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 08:43:29 --> Controller Class Initialized
INFO - 2024-03-16 08:43:29 --> Final output sent to browser
DEBUG - 2024-03-16 08:43:29 --> Total execution time: 0.1271
INFO - 2024-03-16 08:43:50 --> Config Class Initialized
INFO - 2024-03-16 08:43:50 --> Hooks Class Initialized
DEBUG - 2024-03-16 08:43:50 --> UTF-8 Support Enabled
INFO - 2024-03-16 08:43:50 --> Utf8 Class Initialized
INFO - 2024-03-16 08:43:50 --> URI Class Initialized
INFO - 2024-03-16 08:43:50 --> Router Class Initialized
INFO - 2024-03-16 08:43:50 --> Output Class Initialized
INFO - 2024-03-16 08:43:50 --> Security Class Initialized
DEBUG - 2024-03-16 08:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 08:43:50 --> Input Class Initialized
INFO - 2024-03-16 08:43:50 --> Language Class Initialized
INFO - 2024-03-16 08:43:50 --> Language Class Initialized
INFO - 2024-03-16 08:43:50 --> Config Class Initialized
INFO - 2024-03-16 08:43:50 --> Loader Class Initialized
INFO - 2024-03-16 08:43:50 --> Helper loaded: url_helper
INFO - 2024-03-16 08:43:50 --> Helper loaded: file_helper
INFO - 2024-03-16 08:43:50 --> Helper loaded: form_helper
INFO - 2024-03-16 08:43:50 --> Helper loaded: my_helper
INFO - 2024-03-16 08:43:50 --> Database Driver Class Initialized
INFO - 2024-03-16 08:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 08:43:50 --> Controller Class Initialized
INFO - 2024-03-16 08:43:50 --> Final output sent to browser
DEBUG - 2024-03-16 08:43:50 --> Total execution time: 0.0390
INFO - 2024-03-16 08:43:50 --> Config Class Initialized
INFO - 2024-03-16 08:43:50 --> Hooks Class Initialized
DEBUG - 2024-03-16 08:43:50 --> UTF-8 Support Enabled
INFO - 2024-03-16 08:43:50 --> Utf8 Class Initialized
INFO - 2024-03-16 08:43:50 --> URI Class Initialized
INFO - 2024-03-16 08:43:50 --> Router Class Initialized
INFO - 2024-03-16 08:43:50 --> Output Class Initialized
INFO - 2024-03-16 08:43:50 --> Security Class Initialized
DEBUG - 2024-03-16 08:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 08:43:50 --> Input Class Initialized
INFO - 2024-03-16 08:43:50 --> Language Class Initialized
INFO - 2024-03-16 08:43:50 --> Language Class Initialized
INFO - 2024-03-16 08:43:50 --> Config Class Initialized
INFO - 2024-03-16 08:43:50 --> Loader Class Initialized
INFO - 2024-03-16 08:43:50 --> Helper loaded: url_helper
INFO - 2024-03-16 08:43:50 --> Helper loaded: file_helper
INFO - 2024-03-16 08:43:50 --> Helper loaded: form_helper
INFO - 2024-03-16 08:43:50 --> Helper loaded: my_helper
INFO - 2024-03-16 08:43:50 --> Database Driver Class Initialized
INFO - 2024-03-16 08:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 08:43:50 --> Controller Class Initialized
INFO - 2024-03-16 08:43:52 --> Config Class Initialized
INFO - 2024-03-16 08:43:52 --> Hooks Class Initialized
DEBUG - 2024-03-16 08:43:52 --> UTF-8 Support Enabled
INFO - 2024-03-16 08:43:52 --> Utf8 Class Initialized
INFO - 2024-03-16 08:43:52 --> URI Class Initialized
INFO - 2024-03-16 08:43:52 --> Router Class Initialized
INFO - 2024-03-16 08:43:52 --> Output Class Initialized
INFO - 2024-03-16 08:43:52 --> Security Class Initialized
DEBUG - 2024-03-16 08:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 08:43:52 --> Input Class Initialized
INFO - 2024-03-16 08:43:52 --> Language Class Initialized
INFO - 2024-03-16 08:43:52 --> Language Class Initialized
INFO - 2024-03-16 08:43:52 --> Config Class Initialized
INFO - 2024-03-16 08:43:52 --> Loader Class Initialized
INFO - 2024-03-16 08:43:52 --> Helper loaded: url_helper
INFO - 2024-03-16 08:43:52 --> Helper loaded: file_helper
INFO - 2024-03-16 08:43:52 --> Helper loaded: form_helper
INFO - 2024-03-16 08:43:52 --> Helper loaded: my_helper
INFO - 2024-03-16 08:43:52 --> Database Driver Class Initialized
INFO - 2024-03-16 08:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 08:43:52 --> Controller Class Initialized
INFO - 2024-03-16 08:43:52 --> Final output sent to browser
DEBUG - 2024-03-16 08:43:52 --> Total execution time: 0.0783
INFO - 2024-03-16 08:43:56 --> Config Class Initialized
INFO - 2024-03-16 08:43:56 --> Hooks Class Initialized
DEBUG - 2024-03-16 08:43:56 --> UTF-8 Support Enabled
INFO - 2024-03-16 08:43:56 --> Utf8 Class Initialized
INFO - 2024-03-16 08:43:56 --> URI Class Initialized
INFO - 2024-03-16 08:43:56 --> Router Class Initialized
INFO - 2024-03-16 08:43:56 --> Output Class Initialized
INFO - 2024-03-16 08:43:56 --> Security Class Initialized
DEBUG - 2024-03-16 08:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 08:43:56 --> Input Class Initialized
INFO - 2024-03-16 08:43:56 --> Language Class Initialized
INFO - 2024-03-16 08:43:56 --> Language Class Initialized
INFO - 2024-03-16 08:43:56 --> Config Class Initialized
INFO - 2024-03-16 08:43:56 --> Loader Class Initialized
INFO - 2024-03-16 08:43:56 --> Helper loaded: url_helper
INFO - 2024-03-16 08:43:56 --> Helper loaded: file_helper
INFO - 2024-03-16 08:43:56 --> Helper loaded: form_helper
INFO - 2024-03-16 08:43:56 --> Helper loaded: my_helper
INFO - 2024-03-16 08:43:56 --> Database Driver Class Initialized
INFO - 2024-03-16 08:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 08:43:56 --> Controller Class Initialized
INFO - 2024-03-16 08:43:56 --> Final output sent to browser
DEBUG - 2024-03-16 08:43:56 --> Total execution time: 0.0847
INFO - 2024-03-16 08:44:25 --> Config Class Initialized
INFO - 2024-03-16 08:44:25 --> Hooks Class Initialized
DEBUG - 2024-03-16 08:44:25 --> UTF-8 Support Enabled
INFO - 2024-03-16 08:44:25 --> Utf8 Class Initialized
INFO - 2024-03-16 08:44:25 --> URI Class Initialized
INFO - 2024-03-16 08:44:25 --> Router Class Initialized
INFO - 2024-03-16 08:44:25 --> Output Class Initialized
INFO - 2024-03-16 08:44:25 --> Security Class Initialized
DEBUG - 2024-03-16 08:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 08:44:25 --> Input Class Initialized
INFO - 2024-03-16 08:44:25 --> Language Class Initialized
INFO - 2024-03-16 08:44:25 --> Language Class Initialized
INFO - 2024-03-16 08:44:25 --> Config Class Initialized
INFO - 2024-03-16 08:44:25 --> Loader Class Initialized
INFO - 2024-03-16 08:44:25 --> Helper loaded: url_helper
INFO - 2024-03-16 08:44:25 --> Helper loaded: file_helper
INFO - 2024-03-16 08:44:25 --> Helper loaded: form_helper
INFO - 2024-03-16 08:44:25 --> Helper loaded: my_helper
INFO - 2024-03-16 08:44:25 --> Database Driver Class Initialized
INFO - 2024-03-16 08:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 08:44:25 --> Controller Class Initialized
INFO - 2024-03-16 08:44:26 --> Final output sent to browser
DEBUG - 2024-03-16 08:44:26 --> Total execution time: 0.4725
INFO - 2024-03-16 08:44:30 --> Config Class Initialized
INFO - 2024-03-16 08:44:30 --> Hooks Class Initialized
DEBUG - 2024-03-16 08:44:30 --> UTF-8 Support Enabled
INFO - 2024-03-16 08:44:30 --> Utf8 Class Initialized
INFO - 2024-03-16 08:44:30 --> URI Class Initialized
INFO - 2024-03-16 08:44:30 --> Router Class Initialized
INFO - 2024-03-16 08:44:30 --> Output Class Initialized
INFO - 2024-03-16 08:44:30 --> Security Class Initialized
DEBUG - 2024-03-16 08:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 08:44:30 --> Input Class Initialized
INFO - 2024-03-16 08:44:30 --> Language Class Initialized
INFO - 2024-03-16 08:44:30 --> Language Class Initialized
INFO - 2024-03-16 08:44:30 --> Config Class Initialized
INFO - 2024-03-16 08:44:30 --> Loader Class Initialized
INFO - 2024-03-16 08:44:30 --> Helper loaded: url_helper
INFO - 2024-03-16 08:44:30 --> Helper loaded: file_helper
INFO - 2024-03-16 08:44:30 --> Helper loaded: form_helper
INFO - 2024-03-16 08:44:30 --> Helper loaded: my_helper
INFO - 2024-03-16 08:44:30 --> Database Driver Class Initialized
INFO - 2024-03-16 08:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 08:44:30 --> Controller Class Initialized
INFO - 2024-03-16 08:44:30 --> Final output sent to browser
DEBUG - 2024-03-16 08:44:30 --> Total execution time: 0.0349
INFO - 2024-03-16 08:46:46 --> Config Class Initialized
INFO - 2024-03-16 08:46:46 --> Hooks Class Initialized
DEBUG - 2024-03-16 08:46:46 --> UTF-8 Support Enabled
INFO - 2024-03-16 08:46:46 --> Utf8 Class Initialized
INFO - 2024-03-16 08:46:46 --> URI Class Initialized
INFO - 2024-03-16 08:46:46 --> Router Class Initialized
INFO - 2024-03-16 08:46:46 --> Output Class Initialized
INFO - 2024-03-16 08:46:46 --> Security Class Initialized
DEBUG - 2024-03-16 08:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 08:46:46 --> Input Class Initialized
INFO - 2024-03-16 08:46:46 --> Language Class Initialized
INFO - 2024-03-16 08:46:46 --> Language Class Initialized
INFO - 2024-03-16 08:46:46 --> Config Class Initialized
INFO - 2024-03-16 08:46:46 --> Loader Class Initialized
INFO - 2024-03-16 08:46:46 --> Helper loaded: url_helper
INFO - 2024-03-16 08:46:46 --> Helper loaded: file_helper
INFO - 2024-03-16 08:46:46 --> Helper loaded: form_helper
INFO - 2024-03-16 08:46:46 --> Helper loaded: my_helper
INFO - 2024-03-16 08:46:46 --> Database Driver Class Initialized
INFO - 2024-03-16 08:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 08:46:46 --> Controller Class Initialized
INFO - 2024-03-16 08:46:47 --> Final output sent to browser
DEBUG - 2024-03-16 08:46:47 --> Total execution time: 0.4181
INFO - 2024-03-16 08:46:57 --> Config Class Initialized
INFO - 2024-03-16 08:46:57 --> Hooks Class Initialized
DEBUG - 2024-03-16 08:46:57 --> UTF-8 Support Enabled
INFO - 2024-03-16 08:46:57 --> Utf8 Class Initialized
INFO - 2024-03-16 08:46:57 --> URI Class Initialized
INFO - 2024-03-16 08:46:57 --> Router Class Initialized
INFO - 2024-03-16 08:46:57 --> Output Class Initialized
INFO - 2024-03-16 08:46:57 --> Security Class Initialized
DEBUG - 2024-03-16 08:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 08:46:57 --> Input Class Initialized
INFO - 2024-03-16 08:46:57 --> Language Class Initialized
INFO - 2024-03-16 08:46:57 --> Language Class Initialized
INFO - 2024-03-16 08:46:57 --> Config Class Initialized
INFO - 2024-03-16 08:46:57 --> Loader Class Initialized
INFO - 2024-03-16 08:46:57 --> Helper loaded: url_helper
INFO - 2024-03-16 08:46:57 --> Helper loaded: file_helper
INFO - 2024-03-16 08:46:57 --> Helper loaded: form_helper
INFO - 2024-03-16 08:46:57 --> Helper loaded: my_helper
INFO - 2024-03-16 08:46:57 --> Database Driver Class Initialized
INFO - 2024-03-16 08:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 08:46:57 --> Controller Class Initialized
INFO - 2024-03-16 08:46:58 --> Final output sent to browser
DEBUG - 2024-03-16 08:46:58 --> Total execution time: 0.5354
INFO - 2024-03-16 08:47:01 --> Config Class Initialized
INFO - 2024-03-16 08:47:01 --> Hooks Class Initialized
DEBUG - 2024-03-16 08:47:01 --> UTF-8 Support Enabled
INFO - 2024-03-16 08:47:01 --> Utf8 Class Initialized
INFO - 2024-03-16 08:47:01 --> URI Class Initialized
DEBUG - 2024-03-16 08:47:01 --> No URI present. Default controller set.
INFO - 2024-03-16 08:47:01 --> Router Class Initialized
INFO - 2024-03-16 08:47:01 --> Output Class Initialized
INFO - 2024-03-16 08:47:01 --> Security Class Initialized
DEBUG - 2024-03-16 08:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 08:47:01 --> Input Class Initialized
INFO - 2024-03-16 08:47:01 --> Language Class Initialized
INFO - 2024-03-16 08:47:01 --> Language Class Initialized
INFO - 2024-03-16 08:47:01 --> Config Class Initialized
INFO - 2024-03-16 08:47:01 --> Loader Class Initialized
INFO - 2024-03-16 08:47:01 --> Helper loaded: url_helper
INFO - 2024-03-16 08:47:01 --> Helper loaded: file_helper
INFO - 2024-03-16 08:47:01 --> Helper loaded: form_helper
INFO - 2024-03-16 08:47:01 --> Helper loaded: my_helper
INFO - 2024-03-16 08:47:01 --> Database Driver Class Initialized
INFO - 2024-03-16 08:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 08:47:01 --> Controller Class Initialized
DEBUG - 2024-03-16 08:47:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-16 08:47:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-16 08:47:01 --> Final output sent to browser
DEBUG - 2024-03-16 08:47:01 --> Total execution time: 0.0454
INFO - 2024-03-16 11:10:25 --> Config Class Initialized
INFO - 2024-03-16 11:10:25 --> Hooks Class Initialized
DEBUG - 2024-03-16 11:10:25 --> UTF-8 Support Enabled
INFO - 2024-03-16 11:10:25 --> Utf8 Class Initialized
INFO - 2024-03-16 11:10:25 --> URI Class Initialized
INFO - 2024-03-16 11:10:25 --> Router Class Initialized
INFO - 2024-03-16 11:10:25 --> Output Class Initialized
INFO - 2024-03-16 11:10:25 --> Security Class Initialized
DEBUG - 2024-03-16 11:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 11:10:25 --> Input Class Initialized
INFO - 2024-03-16 11:10:25 --> Language Class Initialized
INFO - 2024-03-16 11:10:25 --> Language Class Initialized
INFO - 2024-03-16 11:10:25 --> Config Class Initialized
INFO - 2024-03-16 11:10:25 --> Loader Class Initialized
INFO - 2024-03-16 11:10:25 --> Helper loaded: url_helper
INFO - 2024-03-16 11:10:25 --> Helper loaded: file_helper
INFO - 2024-03-16 11:10:25 --> Helper loaded: form_helper
INFO - 2024-03-16 11:10:25 --> Helper loaded: my_helper
INFO - 2024-03-16 11:10:25 --> Database Driver Class Initialized
INFO - 2024-03-16 11:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 11:10:25 --> Controller Class Initialized
ERROR - 2024-03-16 11:10:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2389
DEBUG - 2024-03-16 11:10:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-03-16 11:10:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-16 11:10:25 --> Final output sent to browser
DEBUG - 2024-03-16 11:10:25 --> Total execution time: 0.7213
INFO - 2024-03-16 11:10:30 --> Config Class Initialized
INFO - 2024-03-16 11:10:30 --> Hooks Class Initialized
DEBUG - 2024-03-16 11:10:30 --> UTF-8 Support Enabled
INFO - 2024-03-16 11:10:30 --> Utf8 Class Initialized
INFO - 2024-03-16 11:10:30 --> URI Class Initialized
INFO - 2024-03-16 11:10:30 --> Router Class Initialized
INFO - 2024-03-16 11:10:30 --> Output Class Initialized
INFO - 2024-03-16 11:10:30 --> Security Class Initialized
DEBUG - 2024-03-16 11:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 11:10:30 --> Input Class Initialized
INFO - 2024-03-16 11:10:30 --> Language Class Initialized
INFO - 2024-03-16 11:10:30 --> Language Class Initialized
INFO - 2024-03-16 11:10:30 --> Config Class Initialized
INFO - 2024-03-16 11:10:30 --> Loader Class Initialized
INFO - 2024-03-16 11:10:30 --> Helper loaded: url_helper
INFO - 2024-03-16 11:10:30 --> Helper loaded: file_helper
INFO - 2024-03-16 11:10:30 --> Helper loaded: form_helper
INFO - 2024-03-16 11:10:30 --> Helper loaded: my_helper
INFO - 2024-03-16 11:10:30 --> Database Driver Class Initialized
INFO - 2024-03-16 11:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 11:10:30 --> Controller Class Initialized
ERROR - 2024-03-16 11:10:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2389
DEBUG - 2024-03-16 11:10:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-03-16 11:10:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-16 11:10:30 --> Final output sent to browser
DEBUG - 2024-03-16 11:10:30 --> Total execution time: 0.1126
INFO - 2024-03-16 11:10:34 --> Config Class Initialized
INFO - 2024-03-16 11:10:34 --> Hooks Class Initialized
DEBUG - 2024-03-16 11:10:34 --> UTF-8 Support Enabled
INFO - 2024-03-16 11:10:34 --> Utf8 Class Initialized
INFO - 2024-03-16 11:10:34 --> URI Class Initialized
INFO - 2024-03-16 11:10:35 --> Router Class Initialized
INFO - 2024-03-16 11:10:35 --> Output Class Initialized
INFO - 2024-03-16 11:10:35 --> Security Class Initialized
DEBUG - 2024-03-16 11:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 11:10:35 --> Input Class Initialized
INFO - 2024-03-16 11:10:35 --> Language Class Initialized
INFO - 2024-03-16 11:10:35 --> Language Class Initialized
INFO - 2024-03-16 11:10:35 --> Config Class Initialized
INFO - 2024-03-16 11:10:35 --> Loader Class Initialized
INFO - 2024-03-16 11:10:35 --> Helper loaded: url_helper
INFO - 2024-03-16 11:10:35 --> Helper loaded: file_helper
INFO - 2024-03-16 11:10:35 --> Helper loaded: form_helper
INFO - 2024-03-16 11:10:35 --> Helper loaded: my_helper
INFO - 2024-03-16 11:10:35 --> Database Driver Class Initialized
INFO - 2024-03-16 11:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 11:10:35 --> Controller Class Initialized
ERROR - 2024-03-16 11:10:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2389
DEBUG - 2024-03-16 11:10:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-03-16 11:10:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-16 11:10:35 --> Final output sent to browser
DEBUG - 2024-03-16 11:10:35 --> Total execution time: 0.1178
INFO - 2024-03-16 11:10:41 --> Config Class Initialized
INFO - 2024-03-16 11:10:41 --> Hooks Class Initialized
DEBUG - 2024-03-16 11:10:41 --> UTF-8 Support Enabled
INFO - 2024-03-16 11:10:41 --> Utf8 Class Initialized
INFO - 2024-03-16 11:10:41 --> URI Class Initialized
INFO - 2024-03-16 11:10:41 --> Router Class Initialized
INFO - 2024-03-16 11:10:41 --> Output Class Initialized
INFO - 2024-03-16 11:10:41 --> Security Class Initialized
DEBUG - 2024-03-16 11:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 11:10:41 --> Input Class Initialized
INFO - 2024-03-16 11:10:41 --> Language Class Initialized
INFO - 2024-03-16 11:10:41 --> Language Class Initialized
INFO - 2024-03-16 11:10:41 --> Config Class Initialized
INFO - 2024-03-16 11:10:41 --> Loader Class Initialized
INFO - 2024-03-16 11:10:41 --> Helper loaded: url_helper
INFO - 2024-03-16 11:10:41 --> Helper loaded: file_helper
INFO - 2024-03-16 11:10:41 --> Helper loaded: form_helper
INFO - 2024-03-16 11:10:41 --> Helper loaded: my_helper
INFO - 2024-03-16 11:10:41 --> Database Driver Class Initialized
INFO - 2024-03-16 11:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 11:10:41 --> Controller Class Initialized
DEBUG - 2024-03-16 11:10:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-16 11:10:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-16 11:10:41 --> Final output sent to browser
DEBUG - 2024-03-16 11:10:41 --> Total execution time: 0.1028
INFO - 2024-03-16 11:10:47 --> Config Class Initialized
INFO - 2024-03-16 11:10:47 --> Hooks Class Initialized
DEBUG - 2024-03-16 11:10:47 --> UTF-8 Support Enabled
INFO - 2024-03-16 11:10:47 --> Utf8 Class Initialized
INFO - 2024-03-16 11:10:47 --> URI Class Initialized
INFO - 2024-03-16 11:10:47 --> Router Class Initialized
INFO - 2024-03-16 11:10:47 --> Output Class Initialized
INFO - 2024-03-16 11:10:47 --> Security Class Initialized
DEBUG - 2024-03-16 11:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 11:10:47 --> Input Class Initialized
INFO - 2024-03-16 11:10:47 --> Language Class Initialized
INFO - 2024-03-16 11:10:47 --> Language Class Initialized
INFO - 2024-03-16 11:10:47 --> Config Class Initialized
INFO - 2024-03-16 11:10:47 --> Loader Class Initialized
INFO - 2024-03-16 11:10:47 --> Helper loaded: url_helper
INFO - 2024-03-16 11:10:47 --> Helper loaded: file_helper
INFO - 2024-03-16 11:10:47 --> Helper loaded: form_helper
INFO - 2024-03-16 11:10:47 --> Helper loaded: my_helper
INFO - 2024-03-16 11:10:47 --> Database Driver Class Initialized
INFO - 2024-03-16 11:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 11:10:47 --> Controller Class Initialized
INFO - 2024-03-16 11:10:47 --> Helper loaded: cookie_helper
INFO - 2024-03-16 11:10:47 --> Final output sent to browser
DEBUG - 2024-03-16 11:10:47 --> Total execution time: 0.0325
INFO - 2024-03-16 11:10:47 --> Config Class Initialized
INFO - 2024-03-16 11:10:47 --> Hooks Class Initialized
DEBUG - 2024-03-16 11:10:47 --> UTF-8 Support Enabled
INFO - 2024-03-16 11:10:47 --> Utf8 Class Initialized
INFO - 2024-03-16 11:10:47 --> URI Class Initialized
INFO - 2024-03-16 11:10:47 --> Router Class Initialized
INFO - 2024-03-16 11:10:47 --> Output Class Initialized
INFO - 2024-03-16 11:10:47 --> Security Class Initialized
DEBUG - 2024-03-16 11:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 11:10:47 --> Input Class Initialized
INFO - 2024-03-16 11:10:47 --> Language Class Initialized
INFO - 2024-03-16 11:10:47 --> Language Class Initialized
INFO - 2024-03-16 11:10:47 --> Config Class Initialized
INFO - 2024-03-16 11:10:47 --> Loader Class Initialized
INFO - 2024-03-16 11:10:47 --> Helper loaded: url_helper
INFO - 2024-03-16 11:10:47 --> Helper loaded: file_helper
INFO - 2024-03-16 11:10:47 --> Helper loaded: form_helper
INFO - 2024-03-16 11:10:47 --> Helper loaded: my_helper
INFO - 2024-03-16 11:10:47 --> Database Driver Class Initialized
INFO - 2024-03-16 11:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 11:10:47 --> Controller Class Initialized
DEBUG - 2024-03-16 11:10:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-16 11:10:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-16 11:10:47 --> Final output sent to browser
DEBUG - 2024-03-16 11:10:47 --> Total execution time: 0.0416
INFO - 2024-03-16 11:10:52 --> Config Class Initialized
INFO - 2024-03-16 11:10:52 --> Hooks Class Initialized
DEBUG - 2024-03-16 11:10:52 --> UTF-8 Support Enabled
INFO - 2024-03-16 11:10:52 --> Utf8 Class Initialized
INFO - 2024-03-16 11:10:52 --> URI Class Initialized
INFO - 2024-03-16 11:10:52 --> Router Class Initialized
INFO - 2024-03-16 11:10:52 --> Output Class Initialized
INFO - 2024-03-16 11:10:52 --> Security Class Initialized
DEBUG - 2024-03-16 11:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 11:10:52 --> Input Class Initialized
INFO - 2024-03-16 11:10:52 --> Language Class Initialized
INFO - 2024-03-16 11:10:52 --> Language Class Initialized
INFO - 2024-03-16 11:10:52 --> Config Class Initialized
INFO - 2024-03-16 11:10:52 --> Loader Class Initialized
INFO - 2024-03-16 11:10:52 --> Helper loaded: url_helper
INFO - 2024-03-16 11:10:52 --> Helper loaded: file_helper
INFO - 2024-03-16 11:10:52 --> Helper loaded: form_helper
INFO - 2024-03-16 11:10:52 --> Helper loaded: my_helper
INFO - 2024-03-16 11:10:52 --> Database Driver Class Initialized
INFO - 2024-03-16 11:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 11:10:52 --> Controller Class Initialized
DEBUG - 2024-03-16 11:10:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-16 11:10:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-16 11:10:52 --> Final output sent to browser
DEBUG - 2024-03-16 11:10:52 --> Total execution time: 0.0846
INFO - 2024-03-16 11:36:35 --> Config Class Initialized
INFO - 2024-03-16 11:36:35 --> Hooks Class Initialized
DEBUG - 2024-03-16 11:36:35 --> UTF-8 Support Enabled
INFO - 2024-03-16 11:36:35 --> Utf8 Class Initialized
INFO - 2024-03-16 11:36:35 --> URI Class Initialized
INFO - 2024-03-16 11:36:35 --> Router Class Initialized
INFO - 2024-03-16 11:36:35 --> Output Class Initialized
INFO - 2024-03-16 11:36:35 --> Security Class Initialized
DEBUG - 2024-03-16 11:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 11:36:35 --> Input Class Initialized
INFO - 2024-03-16 11:36:35 --> Language Class Initialized
INFO - 2024-03-16 11:36:35 --> Language Class Initialized
INFO - 2024-03-16 11:36:35 --> Config Class Initialized
INFO - 2024-03-16 11:36:35 --> Loader Class Initialized
INFO - 2024-03-16 11:36:35 --> Helper loaded: url_helper
INFO - 2024-03-16 11:36:35 --> Helper loaded: file_helper
INFO - 2024-03-16 11:36:35 --> Helper loaded: form_helper
INFO - 2024-03-16 11:36:35 --> Helper loaded: my_helper
INFO - 2024-03-16 11:36:35 --> Database Driver Class Initialized
INFO - 2024-03-16 11:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 11:36:35 --> Controller Class Initialized
DEBUG - 2024-03-16 11:36:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-16 11:36:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-16 11:36:35 --> Final output sent to browser
DEBUG - 2024-03-16 11:36:35 --> Total execution time: 0.0414
INFO - 2024-03-16 12:11:53 --> Config Class Initialized
INFO - 2024-03-16 12:11:53 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:11:53 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:11:53 --> Utf8 Class Initialized
INFO - 2024-03-16 12:11:53 --> URI Class Initialized
INFO - 2024-03-16 12:11:53 --> Router Class Initialized
INFO - 2024-03-16 12:11:53 --> Output Class Initialized
INFO - 2024-03-16 12:11:53 --> Security Class Initialized
DEBUG - 2024-03-16 12:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:11:53 --> Input Class Initialized
INFO - 2024-03-16 12:11:53 --> Language Class Initialized
INFO - 2024-03-16 12:11:53 --> Language Class Initialized
INFO - 2024-03-16 12:11:53 --> Config Class Initialized
INFO - 2024-03-16 12:11:53 --> Loader Class Initialized
INFO - 2024-03-16 12:11:53 --> Helper loaded: url_helper
INFO - 2024-03-16 12:11:53 --> Helper loaded: file_helper
INFO - 2024-03-16 12:11:53 --> Helper loaded: form_helper
INFO - 2024-03-16 12:11:53 --> Helper loaded: my_helper
INFO - 2024-03-16 12:11:53 --> Database Driver Class Initialized
INFO - 2024-03-16 12:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:11:53 --> Controller Class Initialized
DEBUG - 2024-03-16 12:11:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-03-16 12:11:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-16 12:11:53 --> Final output sent to browser
DEBUG - 2024-03-16 12:11:53 --> Total execution time: 0.3930
INFO - 2024-03-16 12:11:53 --> Config Class Initialized
INFO - 2024-03-16 12:11:53 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:11:53 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:11:53 --> Utf8 Class Initialized
INFO - 2024-03-16 12:11:53 --> URI Class Initialized
INFO - 2024-03-16 12:11:53 --> Router Class Initialized
INFO - 2024-03-16 12:11:53 --> Output Class Initialized
INFO - 2024-03-16 12:11:53 --> Security Class Initialized
DEBUG - 2024-03-16 12:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:11:53 --> Input Class Initialized
INFO - 2024-03-16 12:11:53 --> Language Class Initialized
INFO - 2024-03-16 12:11:53 --> Language Class Initialized
INFO - 2024-03-16 12:11:53 --> Config Class Initialized
INFO - 2024-03-16 12:11:53 --> Loader Class Initialized
INFO - 2024-03-16 12:11:53 --> Helper loaded: url_helper
INFO - 2024-03-16 12:11:53 --> Helper loaded: file_helper
INFO - 2024-03-16 12:11:53 --> Helper loaded: form_helper
INFO - 2024-03-16 12:11:53 --> Helper loaded: my_helper
INFO - 2024-03-16 12:11:53 --> Database Driver Class Initialized
INFO - 2024-03-16 12:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:11:53 --> Controller Class Initialized
INFO - 2024-03-16 12:11:57 --> Config Class Initialized
INFO - 2024-03-16 12:11:57 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:11:57 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:11:57 --> Utf8 Class Initialized
INFO - 2024-03-16 12:11:57 --> URI Class Initialized
INFO - 2024-03-16 12:11:57 --> Router Class Initialized
INFO - 2024-03-16 12:11:57 --> Output Class Initialized
INFO - 2024-03-16 12:11:57 --> Security Class Initialized
DEBUG - 2024-03-16 12:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:11:57 --> Input Class Initialized
INFO - 2024-03-16 12:11:57 --> Language Class Initialized
INFO - 2024-03-16 12:11:57 --> Language Class Initialized
INFO - 2024-03-16 12:11:57 --> Config Class Initialized
INFO - 2024-03-16 12:11:57 --> Loader Class Initialized
INFO - 2024-03-16 12:11:57 --> Helper loaded: url_helper
INFO - 2024-03-16 12:11:57 --> Helper loaded: file_helper
INFO - 2024-03-16 12:11:57 --> Helper loaded: form_helper
INFO - 2024-03-16 12:11:57 --> Helper loaded: my_helper
INFO - 2024-03-16 12:11:57 --> Database Driver Class Initialized
INFO - 2024-03-16 12:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:11:57 --> Controller Class Initialized
INFO - 2024-03-16 12:11:57 --> Final output sent to browser
DEBUG - 2024-03-16 12:11:57 --> Total execution time: 0.1774
INFO - 2024-03-16 12:12:42 --> Config Class Initialized
INFO - 2024-03-16 12:12:42 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:12:42 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:12:42 --> Utf8 Class Initialized
INFO - 2024-03-16 12:12:42 --> URI Class Initialized
INFO - 2024-03-16 12:12:42 --> Router Class Initialized
INFO - 2024-03-16 12:12:42 --> Output Class Initialized
INFO - 2024-03-16 12:12:42 --> Security Class Initialized
DEBUG - 2024-03-16 12:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:12:42 --> Input Class Initialized
INFO - 2024-03-16 12:12:42 --> Language Class Initialized
INFO - 2024-03-16 12:12:42 --> Language Class Initialized
INFO - 2024-03-16 12:12:42 --> Config Class Initialized
INFO - 2024-03-16 12:12:42 --> Loader Class Initialized
INFO - 2024-03-16 12:12:42 --> Helper loaded: url_helper
INFO - 2024-03-16 12:12:42 --> Helper loaded: file_helper
INFO - 2024-03-16 12:12:42 --> Helper loaded: form_helper
INFO - 2024-03-16 12:12:42 --> Helper loaded: my_helper
INFO - 2024-03-16 12:12:42 --> Database Driver Class Initialized
INFO - 2024-03-16 12:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:12:42 --> Controller Class Initialized
INFO - 2024-03-16 12:12:42 --> Final output sent to browser
DEBUG - 2024-03-16 12:12:42 --> Total execution time: 0.0469
INFO - 2024-03-16 12:12:46 --> Config Class Initialized
INFO - 2024-03-16 12:12:46 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:12:46 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:12:46 --> Utf8 Class Initialized
INFO - 2024-03-16 12:12:46 --> URI Class Initialized
INFO - 2024-03-16 12:12:46 --> Router Class Initialized
INFO - 2024-03-16 12:12:46 --> Output Class Initialized
INFO - 2024-03-16 12:12:46 --> Security Class Initialized
DEBUG - 2024-03-16 12:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:12:46 --> Input Class Initialized
INFO - 2024-03-16 12:12:46 --> Language Class Initialized
INFO - 2024-03-16 12:12:46 --> Language Class Initialized
INFO - 2024-03-16 12:12:46 --> Config Class Initialized
INFO - 2024-03-16 12:12:46 --> Loader Class Initialized
INFO - 2024-03-16 12:12:46 --> Helper loaded: url_helper
INFO - 2024-03-16 12:12:46 --> Helper loaded: file_helper
INFO - 2024-03-16 12:12:46 --> Helper loaded: form_helper
INFO - 2024-03-16 12:12:46 --> Helper loaded: my_helper
INFO - 2024-03-16 12:12:46 --> Database Driver Class Initialized
INFO - 2024-03-16 12:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:12:46 --> Controller Class Initialized
INFO - 2024-03-16 12:12:46 --> Final output sent to browser
DEBUG - 2024-03-16 12:12:46 --> Total execution time: 0.0340
INFO - 2024-03-16 12:13:07 --> Config Class Initialized
INFO - 2024-03-16 12:13:07 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:13:07 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:13:07 --> Utf8 Class Initialized
INFO - 2024-03-16 12:13:07 --> URI Class Initialized
INFO - 2024-03-16 12:13:07 --> Router Class Initialized
INFO - 2024-03-16 12:13:07 --> Output Class Initialized
INFO - 2024-03-16 12:13:07 --> Security Class Initialized
DEBUG - 2024-03-16 12:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:13:07 --> Input Class Initialized
INFO - 2024-03-16 12:13:07 --> Language Class Initialized
INFO - 2024-03-16 12:13:07 --> Language Class Initialized
INFO - 2024-03-16 12:13:07 --> Config Class Initialized
INFO - 2024-03-16 12:13:07 --> Loader Class Initialized
INFO - 2024-03-16 12:13:07 --> Helper loaded: url_helper
INFO - 2024-03-16 12:13:07 --> Helper loaded: file_helper
INFO - 2024-03-16 12:13:07 --> Helper loaded: form_helper
INFO - 2024-03-16 12:13:07 --> Helper loaded: my_helper
INFO - 2024-03-16 12:13:07 --> Database Driver Class Initialized
INFO - 2024-03-16 12:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:13:07 --> Controller Class Initialized
INFO - 2024-03-16 12:13:07 --> Final output sent to browser
DEBUG - 2024-03-16 12:13:07 --> Total execution time: 0.0880
INFO - 2024-03-16 12:15:03 --> Config Class Initialized
INFO - 2024-03-16 12:15:03 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:15:03 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:15:03 --> Utf8 Class Initialized
INFO - 2024-03-16 12:15:03 --> URI Class Initialized
INFO - 2024-03-16 12:15:03 --> Router Class Initialized
INFO - 2024-03-16 12:15:03 --> Output Class Initialized
INFO - 2024-03-16 12:15:03 --> Security Class Initialized
DEBUG - 2024-03-16 12:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:15:03 --> Input Class Initialized
INFO - 2024-03-16 12:15:03 --> Language Class Initialized
INFO - 2024-03-16 12:15:03 --> Language Class Initialized
INFO - 2024-03-16 12:15:03 --> Config Class Initialized
INFO - 2024-03-16 12:15:03 --> Loader Class Initialized
INFO - 2024-03-16 12:15:03 --> Helper loaded: url_helper
INFO - 2024-03-16 12:15:03 --> Helper loaded: file_helper
INFO - 2024-03-16 12:15:03 --> Helper loaded: form_helper
INFO - 2024-03-16 12:15:03 --> Helper loaded: my_helper
INFO - 2024-03-16 12:15:03 --> Database Driver Class Initialized
INFO - 2024-03-16 12:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:15:03 --> Controller Class Initialized
DEBUG - 2024-03-16 12:15:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-16 12:15:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-16 12:15:03 --> Final output sent to browser
DEBUG - 2024-03-16 12:15:03 --> Total execution time: 0.0549
INFO - 2024-03-16 12:19:12 --> Config Class Initialized
INFO - 2024-03-16 12:19:12 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:19:12 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:19:12 --> Utf8 Class Initialized
INFO - 2024-03-16 12:19:12 --> URI Class Initialized
INFO - 2024-03-16 12:19:12 --> Router Class Initialized
INFO - 2024-03-16 12:19:12 --> Output Class Initialized
INFO - 2024-03-16 12:19:12 --> Security Class Initialized
DEBUG - 2024-03-16 12:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:19:12 --> Input Class Initialized
INFO - 2024-03-16 12:19:12 --> Language Class Initialized
INFO - 2024-03-16 12:19:12 --> Language Class Initialized
INFO - 2024-03-16 12:19:12 --> Config Class Initialized
INFO - 2024-03-16 12:19:12 --> Loader Class Initialized
INFO - 2024-03-16 12:19:12 --> Helper loaded: url_helper
INFO - 2024-03-16 12:19:12 --> Helper loaded: file_helper
INFO - 2024-03-16 12:19:12 --> Helper loaded: form_helper
INFO - 2024-03-16 12:19:12 --> Helper loaded: my_helper
INFO - 2024-03-16 12:19:12 --> Database Driver Class Initialized
INFO - 2024-03-16 12:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:19:12 --> Controller Class Initialized
INFO - 2024-03-16 12:19:12 --> Final output sent to browser
DEBUG - 2024-03-16 12:19:12 --> Total execution time: 0.3363
INFO - 2024-03-16 12:19:27 --> Config Class Initialized
INFO - 2024-03-16 12:19:27 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:19:27 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:19:27 --> Utf8 Class Initialized
INFO - 2024-03-16 12:19:27 --> URI Class Initialized
INFO - 2024-03-16 12:19:27 --> Router Class Initialized
INFO - 2024-03-16 12:19:27 --> Output Class Initialized
INFO - 2024-03-16 12:19:27 --> Security Class Initialized
DEBUG - 2024-03-16 12:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:19:27 --> Input Class Initialized
INFO - 2024-03-16 12:19:27 --> Language Class Initialized
INFO - 2024-03-16 12:19:27 --> Language Class Initialized
INFO - 2024-03-16 12:19:27 --> Config Class Initialized
INFO - 2024-03-16 12:19:27 --> Loader Class Initialized
INFO - 2024-03-16 12:19:27 --> Helper loaded: url_helper
INFO - 2024-03-16 12:19:27 --> Helper loaded: file_helper
INFO - 2024-03-16 12:19:27 --> Helper loaded: form_helper
INFO - 2024-03-16 12:19:27 --> Helper loaded: my_helper
INFO - 2024-03-16 12:19:27 --> Database Driver Class Initialized
INFO - 2024-03-16 12:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:19:27 --> Controller Class Initialized
INFO - 2024-03-16 12:19:27 --> Final output sent to browser
DEBUG - 2024-03-16 12:19:27 --> Total execution time: 0.0588
INFO - 2024-03-16 12:19:56 --> Config Class Initialized
INFO - 2024-03-16 12:19:56 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:19:56 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:19:56 --> Utf8 Class Initialized
INFO - 2024-03-16 12:19:56 --> URI Class Initialized
INFO - 2024-03-16 12:19:56 --> Router Class Initialized
INFO - 2024-03-16 12:19:56 --> Output Class Initialized
INFO - 2024-03-16 12:19:56 --> Security Class Initialized
DEBUG - 2024-03-16 12:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:19:56 --> Input Class Initialized
INFO - 2024-03-16 12:19:56 --> Language Class Initialized
INFO - 2024-03-16 12:19:56 --> Language Class Initialized
INFO - 2024-03-16 12:19:56 --> Config Class Initialized
INFO - 2024-03-16 12:19:56 --> Loader Class Initialized
INFO - 2024-03-16 12:19:56 --> Helper loaded: url_helper
INFO - 2024-03-16 12:19:56 --> Helper loaded: file_helper
INFO - 2024-03-16 12:19:56 --> Helper loaded: form_helper
INFO - 2024-03-16 12:19:56 --> Helper loaded: my_helper
INFO - 2024-03-16 12:19:56 --> Database Driver Class Initialized
INFO - 2024-03-16 12:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:19:56 --> Controller Class Initialized
INFO - 2024-03-16 12:19:56 --> Final output sent to browser
DEBUG - 2024-03-16 12:19:56 --> Total execution time: 0.0401
INFO - 2024-03-16 12:23:22 --> Config Class Initialized
INFO - 2024-03-16 12:23:22 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:23:22 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:23:22 --> Utf8 Class Initialized
INFO - 2024-03-16 12:23:22 --> URI Class Initialized
INFO - 2024-03-16 12:23:22 --> Router Class Initialized
INFO - 2024-03-16 12:23:22 --> Output Class Initialized
INFO - 2024-03-16 12:23:22 --> Security Class Initialized
DEBUG - 2024-03-16 12:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:23:22 --> Input Class Initialized
INFO - 2024-03-16 12:23:22 --> Language Class Initialized
INFO - 2024-03-16 12:23:22 --> Language Class Initialized
INFO - 2024-03-16 12:23:22 --> Config Class Initialized
INFO - 2024-03-16 12:23:22 --> Loader Class Initialized
INFO - 2024-03-16 12:23:22 --> Helper loaded: url_helper
INFO - 2024-03-16 12:23:22 --> Helper loaded: file_helper
INFO - 2024-03-16 12:23:22 --> Helper loaded: form_helper
INFO - 2024-03-16 12:23:22 --> Helper loaded: my_helper
INFO - 2024-03-16 12:23:22 --> Database Driver Class Initialized
INFO - 2024-03-16 12:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:23:22 --> Controller Class Initialized
INFO - 2024-03-16 12:23:22 --> Final output sent to browser
DEBUG - 2024-03-16 12:23:22 --> Total execution time: 0.0558
INFO - 2024-03-16 12:23:26 --> Config Class Initialized
INFO - 2024-03-16 12:23:26 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:23:26 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:23:26 --> Utf8 Class Initialized
INFO - 2024-03-16 12:23:26 --> URI Class Initialized
INFO - 2024-03-16 12:23:26 --> Router Class Initialized
INFO - 2024-03-16 12:23:26 --> Output Class Initialized
INFO - 2024-03-16 12:23:26 --> Security Class Initialized
DEBUG - 2024-03-16 12:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:23:26 --> Input Class Initialized
INFO - 2024-03-16 12:23:26 --> Language Class Initialized
INFO - 2024-03-16 12:23:26 --> Language Class Initialized
INFO - 2024-03-16 12:23:26 --> Config Class Initialized
INFO - 2024-03-16 12:23:26 --> Loader Class Initialized
INFO - 2024-03-16 12:23:26 --> Helper loaded: url_helper
INFO - 2024-03-16 12:23:26 --> Helper loaded: file_helper
INFO - 2024-03-16 12:23:26 --> Helper loaded: form_helper
INFO - 2024-03-16 12:23:26 --> Helper loaded: my_helper
INFO - 2024-03-16 12:23:26 --> Database Driver Class Initialized
INFO - 2024-03-16 12:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:23:26 --> Controller Class Initialized
INFO - 2024-03-16 12:23:26 --> Final output sent to browser
DEBUG - 2024-03-16 12:23:26 --> Total execution time: 0.0588
INFO - 2024-03-16 12:25:20 --> Config Class Initialized
INFO - 2024-03-16 12:25:20 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:25:20 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:25:20 --> Utf8 Class Initialized
INFO - 2024-03-16 12:25:20 --> URI Class Initialized
INFO - 2024-03-16 12:25:20 --> Router Class Initialized
INFO - 2024-03-16 12:25:20 --> Output Class Initialized
INFO - 2024-03-16 12:25:20 --> Security Class Initialized
DEBUG - 2024-03-16 12:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:25:20 --> Input Class Initialized
INFO - 2024-03-16 12:25:20 --> Language Class Initialized
INFO - 2024-03-16 12:25:20 --> Language Class Initialized
INFO - 2024-03-16 12:25:20 --> Config Class Initialized
INFO - 2024-03-16 12:25:20 --> Loader Class Initialized
INFO - 2024-03-16 12:25:20 --> Helper loaded: url_helper
INFO - 2024-03-16 12:25:20 --> Helper loaded: file_helper
INFO - 2024-03-16 12:25:20 --> Helper loaded: form_helper
INFO - 2024-03-16 12:25:20 --> Helper loaded: my_helper
INFO - 2024-03-16 12:25:20 --> Database Driver Class Initialized
INFO - 2024-03-16 12:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:25:20 --> Controller Class Initialized
INFO - 2024-03-16 12:25:20 --> Final output sent to browser
DEBUG - 2024-03-16 12:25:20 --> Total execution time: 0.0645
INFO - 2024-03-16 12:25:33 --> Config Class Initialized
INFO - 2024-03-16 12:25:33 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:25:33 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:25:33 --> Utf8 Class Initialized
INFO - 2024-03-16 12:25:33 --> URI Class Initialized
INFO - 2024-03-16 12:25:33 --> Router Class Initialized
INFO - 2024-03-16 12:25:33 --> Output Class Initialized
INFO - 2024-03-16 12:25:33 --> Security Class Initialized
DEBUG - 2024-03-16 12:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:25:33 --> Input Class Initialized
INFO - 2024-03-16 12:25:33 --> Language Class Initialized
INFO - 2024-03-16 12:25:33 --> Language Class Initialized
INFO - 2024-03-16 12:25:33 --> Config Class Initialized
INFO - 2024-03-16 12:25:33 --> Loader Class Initialized
INFO - 2024-03-16 12:25:33 --> Helper loaded: url_helper
INFO - 2024-03-16 12:25:33 --> Helper loaded: file_helper
INFO - 2024-03-16 12:25:33 --> Helper loaded: form_helper
INFO - 2024-03-16 12:25:33 --> Helper loaded: my_helper
INFO - 2024-03-16 12:25:33 --> Database Driver Class Initialized
INFO - 2024-03-16 12:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:25:33 --> Controller Class Initialized
INFO - 2024-03-16 12:25:33 --> Final output sent to browser
DEBUG - 2024-03-16 12:25:33 --> Total execution time: 0.0422
INFO - 2024-03-16 12:31:33 --> Config Class Initialized
INFO - 2024-03-16 12:31:33 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:31:33 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:31:33 --> Utf8 Class Initialized
INFO - 2024-03-16 12:31:33 --> URI Class Initialized
INFO - 2024-03-16 12:31:33 --> Router Class Initialized
INFO - 2024-03-16 12:31:33 --> Output Class Initialized
INFO - 2024-03-16 12:31:33 --> Security Class Initialized
DEBUG - 2024-03-16 12:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:31:33 --> Input Class Initialized
INFO - 2024-03-16 12:31:33 --> Language Class Initialized
INFO - 2024-03-16 12:31:33 --> Language Class Initialized
INFO - 2024-03-16 12:31:33 --> Config Class Initialized
INFO - 2024-03-16 12:31:33 --> Loader Class Initialized
INFO - 2024-03-16 12:31:33 --> Helper loaded: url_helper
INFO - 2024-03-16 12:31:33 --> Helper loaded: file_helper
INFO - 2024-03-16 12:31:33 --> Helper loaded: form_helper
INFO - 2024-03-16 12:31:33 --> Helper loaded: my_helper
INFO - 2024-03-16 12:31:33 --> Database Driver Class Initialized
INFO - 2024-03-16 12:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:31:33 --> Controller Class Initialized
INFO - 2024-03-16 12:31:33 --> Final output sent to browser
DEBUG - 2024-03-16 12:31:33 --> Total execution time: 0.4409
INFO - 2024-03-16 12:31:39 --> Config Class Initialized
INFO - 2024-03-16 12:31:39 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:31:39 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:31:39 --> Utf8 Class Initialized
INFO - 2024-03-16 12:31:39 --> URI Class Initialized
INFO - 2024-03-16 12:31:39 --> Router Class Initialized
INFO - 2024-03-16 12:31:39 --> Output Class Initialized
INFO - 2024-03-16 12:31:39 --> Security Class Initialized
DEBUG - 2024-03-16 12:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:31:39 --> Input Class Initialized
INFO - 2024-03-16 12:31:39 --> Language Class Initialized
INFO - 2024-03-16 12:31:39 --> Language Class Initialized
INFO - 2024-03-16 12:31:39 --> Config Class Initialized
INFO - 2024-03-16 12:31:39 --> Loader Class Initialized
INFO - 2024-03-16 12:31:39 --> Helper loaded: url_helper
INFO - 2024-03-16 12:31:39 --> Helper loaded: file_helper
INFO - 2024-03-16 12:31:39 --> Helper loaded: form_helper
INFO - 2024-03-16 12:31:39 --> Helper loaded: my_helper
INFO - 2024-03-16 12:31:39 --> Database Driver Class Initialized
INFO - 2024-03-16 12:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:31:39 --> Controller Class Initialized
INFO - 2024-03-16 12:31:39 --> Final output sent to browser
DEBUG - 2024-03-16 12:31:39 --> Total execution time: 0.0410
INFO - 2024-03-16 12:32:13 --> Config Class Initialized
INFO - 2024-03-16 12:32:13 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:32:13 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:32:13 --> Utf8 Class Initialized
INFO - 2024-03-16 12:32:13 --> URI Class Initialized
INFO - 2024-03-16 12:32:13 --> Router Class Initialized
INFO - 2024-03-16 12:32:13 --> Output Class Initialized
INFO - 2024-03-16 12:32:13 --> Security Class Initialized
DEBUG - 2024-03-16 12:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:32:13 --> Input Class Initialized
INFO - 2024-03-16 12:32:13 --> Language Class Initialized
INFO - 2024-03-16 12:32:13 --> Language Class Initialized
INFO - 2024-03-16 12:32:13 --> Config Class Initialized
INFO - 2024-03-16 12:32:13 --> Loader Class Initialized
INFO - 2024-03-16 12:32:13 --> Helper loaded: url_helper
INFO - 2024-03-16 12:32:13 --> Helper loaded: file_helper
INFO - 2024-03-16 12:32:13 --> Helper loaded: form_helper
INFO - 2024-03-16 12:32:13 --> Helper loaded: my_helper
INFO - 2024-03-16 12:32:13 --> Database Driver Class Initialized
INFO - 2024-03-16 12:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:32:13 --> Controller Class Initialized
INFO - 2024-03-16 12:32:14 --> Final output sent to browser
DEBUG - 2024-03-16 12:32:14 --> Total execution time: 0.5190
INFO - 2024-03-16 12:32:17 --> Config Class Initialized
INFO - 2024-03-16 12:32:17 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:32:17 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:32:17 --> Utf8 Class Initialized
INFO - 2024-03-16 12:32:17 --> URI Class Initialized
INFO - 2024-03-16 12:32:17 --> Router Class Initialized
INFO - 2024-03-16 12:32:17 --> Output Class Initialized
INFO - 2024-03-16 12:32:17 --> Security Class Initialized
DEBUG - 2024-03-16 12:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:32:17 --> Input Class Initialized
INFO - 2024-03-16 12:32:17 --> Language Class Initialized
INFO - 2024-03-16 12:32:17 --> Language Class Initialized
INFO - 2024-03-16 12:32:17 --> Config Class Initialized
INFO - 2024-03-16 12:32:17 --> Loader Class Initialized
INFO - 2024-03-16 12:32:17 --> Helper loaded: url_helper
INFO - 2024-03-16 12:32:17 --> Helper loaded: file_helper
INFO - 2024-03-16 12:32:17 --> Helper loaded: form_helper
INFO - 2024-03-16 12:32:17 --> Helper loaded: my_helper
INFO - 2024-03-16 12:32:17 --> Database Driver Class Initialized
INFO - 2024-03-16 12:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:32:17 --> Controller Class Initialized
INFO - 2024-03-16 12:32:17 --> Final output sent to browser
DEBUG - 2024-03-16 12:32:17 --> Total execution time: 0.0705
INFO - 2024-03-16 12:32:51 --> Config Class Initialized
INFO - 2024-03-16 12:32:51 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:32:51 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:32:51 --> Utf8 Class Initialized
INFO - 2024-03-16 12:32:51 --> URI Class Initialized
INFO - 2024-03-16 12:32:51 --> Router Class Initialized
INFO - 2024-03-16 12:32:51 --> Output Class Initialized
INFO - 2024-03-16 12:32:51 --> Security Class Initialized
DEBUG - 2024-03-16 12:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:32:51 --> Input Class Initialized
INFO - 2024-03-16 12:32:51 --> Language Class Initialized
INFO - 2024-03-16 12:32:51 --> Language Class Initialized
INFO - 2024-03-16 12:32:51 --> Config Class Initialized
INFO - 2024-03-16 12:32:51 --> Loader Class Initialized
INFO - 2024-03-16 12:32:51 --> Helper loaded: url_helper
INFO - 2024-03-16 12:32:51 --> Helper loaded: file_helper
INFO - 2024-03-16 12:32:51 --> Helper loaded: form_helper
INFO - 2024-03-16 12:32:51 --> Helper loaded: my_helper
INFO - 2024-03-16 12:32:51 --> Database Driver Class Initialized
INFO - 2024-03-16 12:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:32:51 --> Controller Class Initialized
INFO - 2024-03-16 12:32:51 --> Final output sent to browser
DEBUG - 2024-03-16 12:32:51 --> Total execution time: 0.3080
INFO - 2024-03-16 12:32:54 --> Config Class Initialized
INFO - 2024-03-16 12:32:54 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:32:54 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:32:54 --> Utf8 Class Initialized
INFO - 2024-03-16 12:32:54 --> URI Class Initialized
INFO - 2024-03-16 12:32:54 --> Router Class Initialized
INFO - 2024-03-16 12:32:54 --> Output Class Initialized
INFO - 2024-03-16 12:32:54 --> Security Class Initialized
DEBUG - 2024-03-16 12:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:32:54 --> Input Class Initialized
INFO - 2024-03-16 12:32:54 --> Language Class Initialized
INFO - 2024-03-16 12:32:54 --> Language Class Initialized
INFO - 2024-03-16 12:32:54 --> Config Class Initialized
INFO - 2024-03-16 12:32:54 --> Loader Class Initialized
INFO - 2024-03-16 12:32:54 --> Helper loaded: url_helper
INFO - 2024-03-16 12:32:54 --> Helper loaded: file_helper
INFO - 2024-03-16 12:32:54 --> Helper loaded: form_helper
INFO - 2024-03-16 12:32:54 --> Helper loaded: my_helper
INFO - 2024-03-16 12:32:54 --> Database Driver Class Initialized
INFO - 2024-03-16 12:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:32:54 --> Controller Class Initialized
INFO - 2024-03-16 12:32:54 --> Final output sent to browser
DEBUG - 2024-03-16 12:32:54 --> Total execution time: 0.1575
INFO - 2024-03-16 12:32:55 --> Config Class Initialized
INFO - 2024-03-16 12:32:55 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:32:55 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:32:55 --> Utf8 Class Initialized
INFO - 2024-03-16 12:32:55 --> URI Class Initialized
INFO - 2024-03-16 12:32:55 --> Router Class Initialized
INFO - 2024-03-16 12:32:55 --> Output Class Initialized
INFO - 2024-03-16 12:32:55 --> Security Class Initialized
DEBUG - 2024-03-16 12:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:32:55 --> Input Class Initialized
INFO - 2024-03-16 12:32:55 --> Language Class Initialized
INFO - 2024-03-16 12:32:55 --> Language Class Initialized
INFO - 2024-03-16 12:32:55 --> Config Class Initialized
INFO - 2024-03-16 12:32:55 --> Loader Class Initialized
INFO - 2024-03-16 12:32:55 --> Helper loaded: url_helper
INFO - 2024-03-16 12:32:55 --> Helper loaded: file_helper
INFO - 2024-03-16 12:32:55 --> Helper loaded: form_helper
INFO - 2024-03-16 12:32:55 --> Helper loaded: my_helper
INFO - 2024-03-16 12:32:55 --> Database Driver Class Initialized
INFO - 2024-03-16 12:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:32:55 --> Controller Class Initialized
INFO - 2024-03-16 12:32:55 --> Final output sent to browser
DEBUG - 2024-03-16 12:32:55 --> Total execution time: 0.1482
INFO - 2024-03-16 12:33:10 --> Config Class Initialized
INFO - 2024-03-16 12:33:10 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:33:10 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:33:10 --> Utf8 Class Initialized
INFO - 2024-03-16 12:33:10 --> URI Class Initialized
INFO - 2024-03-16 12:33:10 --> Router Class Initialized
INFO - 2024-03-16 12:33:10 --> Output Class Initialized
INFO - 2024-03-16 12:33:10 --> Security Class Initialized
DEBUG - 2024-03-16 12:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:33:10 --> Input Class Initialized
INFO - 2024-03-16 12:33:10 --> Language Class Initialized
INFO - 2024-03-16 12:33:10 --> Language Class Initialized
INFO - 2024-03-16 12:33:10 --> Config Class Initialized
INFO - 2024-03-16 12:33:10 --> Loader Class Initialized
INFO - 2024-03-16 12:33:10 --> Helper loaded: url_helper
INFO - 2024-03-16 12:33:10 --> Helper loaded: file_helper
INFO - 2024-03-16 12:33:10 --> Helper loaded: form_helper
INFO - 2024-03-16 12:33:10 --> Helper loaded: my_helper
INFO - 2024-03-16 12:33:10 --> Database Driver Class Initialized
INFO - 2024-03-16 12:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:33:10 --> Controller Class Initialized
INFO - 2024-03-16 12:33:10 --> Final output sent to browser
DEBUG - 2024-03-16 12:33:10 --> Total execution time: 0.4656
INFO - 2024-03-16 12:33:12 --> Config Class Initialized
INFO - 2024-03-16 12:33:12 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:33:12 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:33:12 --> Utf8 Class Initialized
INFO - 2024-03-16 12:33:12 --> URI Class Initialized
INFO - 2024-03-16 12:33:13 --> Router Class Initialized
INFO - 2024-03-16 12:33:13 --> Output Class Initialized
INFO - 2024-03-16 12:33:13 --> Security Class Initialized
DEBUG - 2024-03-16 12:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:33:13 --> Input Class Initialized
INFO - 2024-03-16 12:33:13 --> Language Class Initialized
INFO - 2024-03-16 12:33:13 --> Language Class Initialized
INFO - 2024-03-16 12:33:13 --> Config Class Initialized
INFO - 2024-03-16 12:33:13 --> Loader Class Initialized
INFO - 2024-03-16 12:33:13 --> Helper loaded: url_helper
INFO - 2024-03-16 12:33:13 --> Helper loaded: file_helper
INFO - 2024-03-16 12:33:13 --> Helper loaded: form_helper
INFO - 2024-03-16 12:33:13 --> Helper loaded: my_helper
INFO - 2024-03-16 12:33:13 --> Database Driver Class Initialized
INFO - 2024-03-16 12:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:33:13 --> Controller Class Initialized
DEBUG - 2024-03-16 12:33:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-16 12:33:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-16 12:33:13 --> Final output sent to browser
DEBUG - 2024-03-16 12:33:13 --> Total execution time: 0.1359
INFO - 2024-03-16 12:33:18 --> Config Class Initialized
INFO - 2024-03-16 12:33:18 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:33:18 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:33:18 --> Utf8 Class Initialized
INFO - 2024-03-16 12:33:18 --> URI Class Initialized
INFO - 2024-03-16 12:33:18 --> Router Class Initialized
INFO - 2024-03-16 12:33:18 --> Output Class Initialized
INFO - 2024-03-16 12:33:18 --> Security Class Initialized
DEBUG - 2024-03-16 12:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:33:18 --> Input Class Initialized
INFO - 2024-03-16 12:33:18 --> Language Class Initialized
INFO - 2024-03-16 12:33:18 --> Language Class Initialized
INFO - 2024-03-16 12:33:18 --> Config Class Initialized
INFO - 2024-03-16 12:33:18 --> Loader Class Initialized
INFO - 2024-03-16 12:33:18 --> Helper loaded: url_helper
INFO - 2024-03-16 12:33:18 --> Helper loaded: file_helper
INFO - 2024-03-16 12:33:18 --> Helper loaded: form_helper
INFO - 2024-03-16 12:33:18 --> Helper loaded: my_helper
INFO - 2024-03-16 12:33:18 --> Database Driver Class Initialized
INFO - 2024-03-16 12:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:33:18 --> Controller Class Initialized
DEBUG - 2024-03-16 12:33:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-03-16 12:33:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-16 12:33:18 --> Final output sent to browser
DEBUG - 2024-03-16 12:33:18 --> Total execution time: 0.1672
INFO - 2024-03-16 12:33:18 --> Config Class Initialized
INFO - 2024-03-16 12:33:18 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:33:18 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:33:18 --> Utf8 Class Initialized
INFO - 2024-03-16 12:33:18 --> URI Class Initialized
INFO - 2024-03-16 12:33:18 --> Router Class Initialized
INFO - 2024-03-16 12:33:18 --> Output Class Initialized
INFO - 2024-03-16 12:33:18 --> Security Class Initialized
DEBUG - 2024-03-16 12:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:33:18 --> Input Class Initialized
INFO - 2024-03-16 12:33:18 --> Language Class Initialized
INFO - 2024-03-16 12:33:18 --> Language Class Initialized
INFO - 2024-03-16 12:33:18 --> Config Class Initialized
INFO - 2024-03-16 12:33:18 --> Loader Class Initialized
INFO - 2024-03-16 12:33:18 --> Helper loaded: url_helper
INFO - 2024-03-16 12:33:18 --> Helper loaded: file_helper
INFO - 2024-03-16 12:33:18 --> Helper loaded: form_helper
INFO - 2024-03-16 12:33:18 --> Helper loaded: my_helper
INFO - 2024-03-16 12:33:18 --> Database Driver Class Initialized
INFO - 2024-03-16 12:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:33:18 --> Controller Class Initialized
INFO - 2024-03-16 12:33:20 --> Config Class Initialized
INFO - 2024-03-16 12:33:20 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:33:20 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:33:20 --> Utf8 Class Initialized
INFO - 2024-03-16 12:33:20 --> URI Class Initialized
INFO - 2024-03-16 12:33:20 --> Router Class Initialized
INFO - 2024-03-16 12:33:20 --> Output Class Initialized
INFO - 2024-03-16 12:33:20 --> Security Class Initialized
DEBUG - 2024-03-16 12:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:33:20 --> Input Class Initialized
INFO - 2024-03-16 12:33:20 --> Language Class Initialized
INFO - 2024-03-16 12:33:20 --> Language Class Initialized
INFO - 2024-03-16 12:33:20 --> Config Class Initialized
INFO - 2024-03-16 12:33:20 --> Loader Class Initialized
INFO - 2024-03-16 12:33:20 --> Helper loaded: url_helper
INFO - 2024-03-16 12:33:20 --> Helper loaded: file_helper
INFO - 2024-03-16 12:33:20 --> Helper loaded: form_helper
INFO - 2024-03-16 12:33:20 --> Helper loaded: my_helper
INFO - 2024-03-16 12:33:20 --> Database Driver Class Initialized
INFO - 2024-03-16 12:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:33:20 --> Controller Class Initialized
INFO - 2024-03-16 12:33:20 --> Final output sent to browser
DEBUG - 2024-03-16 12:33:20 --> Total execution time: 0.1411
INFO - 2024-03-16 12:33:43 --> Config Class Initialized
INFO - 2024-03-16 12:33:43 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:33:43 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:33:43 --> Utf8 Class Initialized
INFO - 2024-03-16 12:33:43 --> URI Class Initialized
INFO - 2024-03-16 12:33:43 --> Router Class Initialized
INFO - 2024-03-16 12:33:43 --> Output Class Initialized
INFO - 2024-03-16 12:33:43 --> Security Class Initialized
DEBUG - 2024-03-16 12:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:33:43 --> Input Class Initialized
INFO - 2024-03-16 12:33:43 --> Language Class Initialized
INFO - 2024-03-16 12:33:43 --> Language Class Initialized
INFO - 2024-03-16 12:33:43 --> Config Class Initialized
INFO - 2024-03-16 12:33:43 --> Loader Class Initialized
INFO - 2024-03-16 12:33:43 --> Helper loaded: url_helper
INFO - 2024-03-16 12:33:43 --> Helper loaded: file_helper
INFO - 2024-03-16 12:33:43 --> Helper loaded: form_helper
INFO - 2024-03-16 12:33:43 --> Helper loaded: my_helper
INFO - 2024-03-16 12:33:43 --> Database Driver Class Initialized
INFO - 2024-03-16 12:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:33:43 --> Controller Class Initialized
INFO - 2024-03-16 12:33:43 --> Final output sent to browser
DEBUG - 2024-03-16 12:33:43 --> Total execution time: 0.6422
INFO - 2024-03-16 12:33:46 --> Config Class Initialized
INFO - 2024-03-16 12:33:46 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:33:46 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:33:46 --> Utf8 Class Initialized
INFO - 2024-03-16 12:33:46 --> URI Class Initialized
INFO - 2024-03-16 12:33:46 --> Router Class Initialized
INFO - 2024-03-16 12:33:46 --> Output Class Initialized
INFO - 2024-03-16 12:33:46 --> Security Class Initialized
DEBUG - 2024-03-16 12:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:33:46 --> Input Class Initialized
INFO - 2024-03-16 12:33:46 --> Language Class Initialized
INFO - 2024-03-16 12:33:46 --> Language Class Initialized
INFO - 2024-03-16 12:33:46 --> Config Class Initialized
INFO - 2024-03-16 12:33:46 --> Loader Class Initialized
INFO - 2024-03-16 12:33:46 --> Helper loaded: url_helper
INFO - 2024-03-16 12:33:46 --> Helper loaded: file_helper
INFO - 2024-03-16 12:33:47 --> Helper loaded: form_helper
INFO - 2024-03-16 12:33:47 --> Helper loaded: my_helper
INFO - 2024-03-16 12:33:47 --> Database Driver Class Initialized
INFO - 2024-03-16 12:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:33:47 --> Controller Class Initialized
INFO - 2024-03-16 12:33:47 --> Final output sent to browser
DEBUG - 2024-03-16 12:33:47 --> Total execution time: 0.1915
INFO - 2024-03-16 12:34:17 --> Config Class Initialized
INFO - 2024-03-16 12:34:17 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:34:17 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:34:17 --> Utf8 Class Initialized
INFO - 2024-03-16 12:34:17 --> URI Class Initialized
INFO - 2024-03-16 12:34:17 --> Router Class Initialized
INFO - 2024-03-16 12:34:17 --> Output Class Initialized
INFO - 2024-03-16 12:34:17 --> Security Class Initialized
DEBUG - 2024-03-16 12:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:34:17 --> Input Class Initialized
INFO - 2024-03-16 12:34:17 --> Language Class Initialized
INFO - 2024-03-16 12:34:17 --> Language Class Initialized
INFO - 2024-03-16 12:34:17 --> Config Class Initialized
INFO - 2024-03-16 12:34:17 --> Loader Class Initialized
INFO - 2024-03-16 12:34:17 --> Helper loaded: url_helper
INFO - 2024-03-16 12:34:17 --> Helper loaded: file_helper
INFO - 2024-03-16 12:34:17 --> Helper loaded: form_helper
INFO - 2024-03-16 12:34:17 --> Helper loaded: my_helper
INFO - 2024-03-16 12:34:17 --> Database Driver Class Initialized
INFO - 2024-03-16 12:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:34:17 --> Controller Class Initialized
INFO - 2024-03-16 12:34:17 --> Final output sent to browser
DEBUG - 2024-03-16 12:34:17 --> Total execution time: 0.2499
INFO - 2024-03-16 12:34:21 --> Config Class Initialized
INFO - 2024-03-16 12:34:21 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:34:21 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:34:21 --> Utf8 Class Initialized
INFO - 2024-03-16 12:34:21 --> URI Class Initialized
INFO - 2024-03-16 12:34:21 --> Router Class Initialized
INFO - 2024-03-16 12:34:21 --> Output Class Initialized
INFO - 2024-03-16 12:34:21 --> Security Class Initialized
DEBUG - 2024-03-16 12:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:34:21 --> Input Class Initialized
INFO - 2024-03-16 12:34:21 --> Language Class Initialized
INFO - 2024-03-16 12:34:21 --> Language Class Initialized
INFO - 2024-03-16 12:34:21 --> Config Class Initialized
INFO - 2024-03-16 12:34:21 --> Loader Class Initialized
INFO - 2024-03-16 12:34:21 --> Helper loaded: url_helper
INFO - 2024-03-16 12:34:21 --> Helper loaded: file_helper
INFO - 2024-03-16 12:34:21 --> Helper loaded: form_helper
INFO - 2024-03-16 12:34:21 --> Helper loaded: my_helper
INFO - 2024-03-16 12:34:21 --> Database Driver Class Initialized
INFO - 2024-03-16 12:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:34:21 --> Controller Class Initialized
INFO - 2024-03-16 12:34:21 --> Final output sent to browser
DEBUG - 2024-03-16 12:34:21 --> Total execution time: 0.0411
INFO - 2024-03-16 12:34:36 --> Config Class Initialized
INFO - 2024-03-16 12:34:36 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:34:36 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:34:36 --> Utf8 Class Initialized
INFO - 2024-03-16 12:34:36 --> URI Class Initialized
INFO - 2024-03-16 12:34:36 --> Router Class Initialized
INFO - 2024-03-16 12:34:36 --> Output Class Initialized
INFO - 2024-03-16 12:34:36 --> Security Class Initialized
DEBUG - 2024-03-16 12:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:34:36 --> Input Class Initialized
INFO - 2024-03-16 12:34:36 --> Language Class Initialized
INFO - 2024-03-16 12:34:36 --> Language Class Initialized
INFO - 2024-03-16 12:34:36 --> Config Class Initialized
INFO - 2024-03-16 12:34:36 --> Loader Class Initialized
INFO - 2024-03-16 12:34:36 --> Helper loaded: url_helper
INFO - 2024-03-16 12:34:36 --> Helper loaded: file_helper
INFO - 2024-03-16 12:34:36 --> Helper loaded: form_helper
INFO - 2024-03-16 12:34:36 --> Helper loaded: my_helper
INFO - 2024-03-16 12:34:36 --> Database Driver Class Initialized
INFO - 2024-03-16 12:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:34:36 --> Controller Class Initialized
INFO - 2024-03-16 12:34:36 --> Final output sent to browser
DEBUG - 2024-03-16 12:34:36 --> Total execution time: 0.0496
INFO - 2024-03-16 12:34:40 --> Config Class Initialized
INFO - 2024-03-16 12:34:40 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:34:40 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:34:40 --> Utf8 Class Initialized
INFO - 2024-03-16 12:34:40 --> URI Class Initialized
INFO - 2024-03-16 12:34:40 --> Router Class Initialized
INFO - 2024-03-16 12:34:40 --> Output Class Initialized
INFO - 2024-03-16 12:34:40 --> Security Class Initialized
DEBUG - 2024-03-16 12:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:34:40 --> Input Class Initialized
INFO - 2024-03-16 12:34:40 --> Language Class Initialized
INFO - 2024-03-16 12:34:40 --> Language Class Initialized
INFO - 2024-03-16 12:34:40 --> Config Class Initialized
INFO - 2024-03-16 12:34:40 --> Loader Class Initialized
INFO - 2024-03-16 12:34:40 --> Helper loaded: url_helper
INFO - 2024-03-16 12:34:40 --> Helper loaded: file_helper
INFO - 2024-03-16 12:34:40 --> Helper loaded: form_helper
INFO - 2024-03-16 12:34:40 --> Helper loaded: my_helper
INFO - 2024-03-16 12:34:40 --> Database Driver Class Initialized
INFO - 2024-03-16 12:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:34:40 --> Controller Class Initialized
INFO - 2024-03-16 12:34:40 --> Final output sent to browser
DEBUG - 2024-03-16 12:34:40 --> Total execution time: 0.0432
INFO - 2024-03-16 12:34:57 --> Config Class Initialized
INFO - 2024-03-16 12:34:57 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:34:57 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:34:57 --> Utf8 Class Initialized
INFO - 2024-03-16 12:34:57 --> URI Class Initialized
INFO - 2024-03-16 12:34:57 --> Router Class Initialized
INFO - 2024-03-16 12:34:57 --> Output Class Initialized
INFO - 2024-03-16 12:34:57 --> Security Class Initialized
DEBUG - 2024-03-16 12:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:34:57 --> Input Class Initialized
INFO - 2024-03-16 12:34:57 --> Language Class Initialized
INFO - 2024-03-16 12:34:57 --> Language Class Initialized
INFO - 2024-03-16 12:34:57 --> Config Class Initialized
INFO - 2024-03-16 12:34:57 --> Loader Class Initialized
INFO - 2024-03-16 12:34:57 --> Helper loaded: url_helper
INFO - 2024-03-16 12:34:57 --> Helper loaded: file_helper
INFO - 2024-03-16 12:34:57 --> Helper loaded: form_helper
INFO - 2024-03-16 12:34:57 --> Helper loaded: my_helper
INFO - 2024-03-16 12:34:57 --> Database Driver Class Initialized
INFO - 2024-03-16 12:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:34:57 --> Controller Class Initialized
INFO - 2024-03-16 12:34:57 --> Final output sent to browser
DEBUG - 2024-03-16 12:34:57 --> Total execution time: 0.3383
INFO - 2024-03-16 12:35:01 --> Config Class Initialized
INFO - 2024-03-16 12:35:01 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:35:01 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:35:01 --> Utf8 Class Initialized
INFO - 2024-03-16 12:35:01 --> URI Class Initialized
INFO - 2024-03-16 12:35:01 --> Router Class Initialized
INFO - 2024-03-16 12:35:01 --> Output Class Initialized
INFO - 2024-03-16 12:35:01 --> Security Class Initialized
DEBUG - 2024-03-16 12:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:35:01 --> Input Class Initialized
INFO - 2024-03-16 12:35:01 --> Language Class Initialized
INFO - 2024-03-16 12:35:01 --> Language Class Initialized
INFO - 2024-03-16 12:35:01 --> Config Class Initialized
INFO - 2024-03-16 12:35:01 --> Loader Class Initialized
INFO - 2024-03-16 12:35:01 --> Helper loaded: url_helper
INFO - 2024-03-16 12:35:01 --> Helper loaded: file_helper
INFO - 2024-03-16 12:35:01 --> Helper loaded: form_helper
INFO - 2024-03-16 12:35:01 --> Helper loaded: my_helper
INFO - 2024-03-16 12:35:01 --> Database Driver Class Initialized
INFO - 2024-03-16 12:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:35:01 --> Controller Class Initialized
INFO - 2024-03-16 12:35:01 --> Final output sent to browser
DEBUG - 2024-03-16 12:35:01 --> Total execution time: 0.0431
INFO - 2024-03-16 12:35:32 --> Config Class Initialized
INFO - 2024-03-16 12:35:32 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:35:32 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:35:32 --> Utf8 Class Initialized
INFO - 2024-03-16 12:35:32 --> URI Class Initialized
INFO - 2024-03-16 12:35:32 --> Router Class Initialized
INFO - 2024-03-16 12:35:32 --> Output Class Initialized
INFO - 2024-03-16 12:35:32 --> Security Class Initialized
DEBUG - 2024-03-16 12:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:35:32 --> Input Class Initialized
INFO - 2024-03-16 12:35:32 --> Language Class Initialized
INFO - 2024-03-16 12:35:32 --> Language Class Initialized
INFO - 2024-03-16 12:35:32 --> Config Class Initialized
INFO - 2024-03-16 12:35:32 --> Loader Class Initialized
INFO - 2024-03-16 12:35:32 --> Helper loaded: url_helper
INFO - 2024-03-16 12:35:32 --> Helper loaded: file_helper
INFO - 2024-03-16 12:35:32 --> Helper loaded: form_helper
INFO - 2024-03-16 12:35:32 --> Helper loaded: my_helper
INFO - 2024-03-16 12:35:32 --> Database Driver Class Initialized
INFO - 2024-03-16 12:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:35:32 --> Controller Class Initialized
INFO - 2024-03-16 12:35:32 --> Final output sent to browser
DEBUG - 2024-03-16 12:35:32 --> Total execution time: 0.0441
INFO - 2024-03-16 12:35:58 --> Config Class Initialized
INFO - 2024-03-16 12:35:58 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:35:58 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:35:58 --> Utf8 Class Initialized
INFO - 2024-03-16 12:35:58 --> URI Class Initialized
INFO - 2024-03-16 12:35:58 --> Router Class Initialized
INFO - 2024-03-16 12:35:58 --> Output Class Initialized
INFO - 2024-03-16 12:35:58 --> Security Class Initialized
DEBUG - 2024-03-16 12:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:35:58 --> Input Class Initialized
INFO - 2024-03-16 12:35:58 --> Language Class Initialized
INFO - 2024-03-16 12:35:58 --> Language Class Initialized
INFO - 2024-03-16 12:35:58 --> Config Class Initialized
INFO - 2024-03-16 12:35:58 --> Loader Class Initialized
INFO - 2024-03-16 12:35:58 --> Helper loaded: url_helper
INFO - 2024-03-16 12:35:58 --> Helper loaded: file_helper
INFO - 2024-03-16 12:35:58 --> Helper loaded: form_helper
INFO - 2024-03-16 12:35:58 --> Helper loaded: my_helper
INFO - 2024-03-16 12:35:58 --> Database Driver Class Initialized
INFO - 2024-03-16 12:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:35:58 --> Controller Class Initialized
INFO - 2024-03-16 12:35:58 --> Final output sent to browser
DEBUG - 2024-03-16 12:35:58 --> Total execution time: 0.4577
INFO - 2024-03-16 12:36:11 --> Config Class Initialized
INFO - 2024-03-16 12:36:11 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:36:11 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:36:11 --> Utf8 Class Initialized
INFO - 2024-03-16 12:36:11 --> URI Class Initialized
INFO - 2024-03-16 12:36:11 --> Router Class Initialized
INFO - 2024-03-16 12:36:11 --> Output Class Initialized
INFO - 2024-03-16 12:36:11 --> Security Class Initialized
DEBUG - 2024-03-16 12:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:36:11 --> Input Class Initialized
INFO - 2024-03-16 12:36:11 --> Language Class Initialized
INFO - 2024-03-16 12:36:11 --> Language Class Initialized
INFO - 2024-03-16 12:36:11 --> Config Class Initialized
INFO - 2024-03-16 12:36:11 --> Loader Class Initialized
INFO - 2024-03-16 12:36:11 --> Helper loaded: url_helper
INFO - 2024-03-16 12:36:11 --> Helper loaded: file_helper
INFO - 2024-03-16 12:36:11 --> Helper loaded: form_helper
INFO - 2024-03-16 12:36:11 --> Helper loaded: my_helper
INFO - 2024-03-16 12:36:11 --> Database Driver Class Initialized
INFO - 2024-03-16 12:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:36:11 --> Controller Class Initialized
INFO - 2024-03-16 12:36:11 --> Final output sent to browser
DEBUG - 2024-03-16 12:36:11 --> Total execution time: 0.0341
INFO - 2024-03-16 12:36:37 --> Config Class Initialized
INFO - 2024-03-16 12:36:37 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:36:37 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:36:37 --> Utf8 Class Initialized
INFO - 2024-03-16 12:36:37 --> URI Class Initialized
INFO - 2024-03-16 12:36:37 --> Router Class Initialized
INFO - 2024-03-16 12:36:37 --> Output Class Initialized
INFO - 2024-03-16 12:36:37 --> Security Class Initialized
DEBUG - 2024-03-16 12:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:36:37 --> Input Class Initialized
INFO - 2024-03-16 12:36:37 --> Language Class Initialized
INFO - 2024-03-16 12:36:37 --> Language Class Initialized
INFO - 2024-03-16 12:36:37 --> Config Class Initialized
INFO - 2024-03-16 12:36:37 --> Loader Class Initialized
INFO - 2024-03-16 12:36:37 --> Helper loaded: url_helper
INFO - 2024-03-16 12:36:37 --> Helper loaded: file_helper
INFO - 2024-03-16 12:36:37 --> Helper loaded: form_helper
INFO - 2024-03-16 12:36:37 --> Helper loaded: my_helper
INFO - 2024-03-16 12:36:37 --> Database Driver Class Initialized
INFO - 2024-03-16 12:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:36:37 --> Controller Class Initialized
INFO - 2024-03-16 12:36:37 --> Final output sent to browser
DEBUG - 2024-03-16 12:36:37 --> Total execution time: 0.0495
INFO - 2024-03-16 12:36:46 --> Config Class Initialized
INFO - 2024-03-16 12:36:46 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:36:46 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:36:46 --> Utf8 Class Initialized
INFO - 2024-03-16 12:36:46 --> URI Class Initialized
INFO - 2024-03-16 12:36:46 --> Router Class Initialized
INFO - 2024-03-16 12:36:46 --> Output Class Initialized
INFO - 2024-03-16 12:36:46 --> Security Class Initialized
DEBUG - 2024-03-16 12:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:36:46 --> Input Class Initialized
INFO - 2024-03-16 12:36:46 --> Language Class Initialized
INFO - 2024-03-16 12:36:46 --> Language Class Initialized
INFO - 2024-03-16 12:36:46 --> Config Class Initialized
INFO - 2024-03-16 12:36:46 --> Loader Class Initialized
INFO - 2024-03-16 12:36:46 --> Helper loaded: url_helper
INFO - 2024-03-16 12:36:46 --> Helper loaded: file_helper
INFO - 2024-03-16 12:36:46 --> Helper loaded: form_helper
INFO - 2024-03-16 12:36:46 --> Helper loaded: my_helper
INFO - 2024-03-16 12:36:46 --> Database Driver Class Initialized
INFO - 2024-03-16 12:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:36:46 --> Controller Class Initialized
DEBUG - 2024-03-16 12:36:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-16 12:36:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-16 12:36:46 --> Final output sent to browser
DEBUG - 2024-03-16 12:36:46 --> Total execution time: 0.0361
INFO - 2024-03-16 12:36:53 --> Config Class Initialized
INFO - 2024-03-16 12:36:53 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:36:53 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:36:53 --> Utf8 Class Initialized
INFO - 2024-03-16 12:36:53 --> URI Class Initialized
INFO - 2024-03-16 12:36:53 --> Router Class Initialized
INFO - 2024-03-16 12:36:53 --> Output Class Initialized
INFO - 2024-03-16 12:36:53 --> Security Class Initialized
DEBUG - 2024-03-16 12:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:36:53 --> Input Class Initialized
INFO - 2024-03-16 12:36:53 --> Language Class Initialized
INFO - 2024-03-16 12:36:53 --> Language Class Initialized
INFO - 2024-03-16 12:36:53 --> Config Class Initialized
INFO - 2024-03-16 12:36:53 --> Loader Class Initialized
INFO - 2024-03-16 12:36:53 --> Helper loaded: url_helper
INFO - 2024-03-16 12:36:53 --> Helper loaded: file_helper
INFO - 2024-03-16 12:36:53 --> Helper loaded: form_helper
INFO - 2024-03-16 12:36:53 --> Helper loaded: my_helper
INFO - 2024-03-16 12:36:53 --> Database Driver Class Initialized
INFO - 2024-03-16 12:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:36:53 --> Controller Class Initialized
DEBUG - 2024-03-16 12:36:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-03-16 12:36:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-16 12:36:53 --> Final output sent to browser
DEBUG - 2024-03-16 12:36:53 --> Total execution time: 0.0411
INFO - 2024-03-16 12:36:53 --> Config Class Initialized
INFO - 2024-03-16 12:36:53 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:36:53 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:36:53 --> Utf8 Class Initialized
INFO - 2024-03-16 12:36:53 --> URI Class Initialized
INFO - 2024-03-16 12:36:53 --> Router Class Initialized
INFO - 2024-03-16 12:36:53 --> Output Class Initialized
INFO - 2024-03-16 12:36:53 --> Security Class Initialized
DEBUG - 2024-03-16 12:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:36:53 --> Input Class Initialized
INFO - 2024-03-16 12:36:53 --> Language Class Initialized
INFO - 2024-03-16 12:36:53 --> Language Class Initialized
INFO - 2024-03-16 12:36:53 --> Config Class Initialized
INFO - 2024-03-16 12:36:53 --> Loader Class Initialized
INFO - 2024-03-16 12:36:53 --> Helper loaded: url_helper
INFO - 2024-03-16 12:36:53 --> Helper loaded: file_helper
INFO - 2024-03-16 12:36:53 --> Helper loaded: form_helper
INFO - 2024-03-16 12:36:53 --> Helper loaded: my_helper
INFO - 2024-03-16 12:36:53 --> Database Driver Class Initialized
INFO - 2024-03-16 12:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:36:53 --> Controller Class Initialized
INFO - 2024-03-16 12:36:55 --> Config Class Initialized
INFO - 2024-03-16 12:36:55 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:36:55 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:36:55 --> Utf8 Class Initialized
INFO - 2024-03-16 12:36:55 --> URI Class Initialized
INFO - 2024-03-16 12:36:55 --> Router Class Initialized
INFO - 2024-03-16 12:36:55 --> Output Class Initialized
INFO - 2024-03-16 12:36:55 --> Security Class Initialized
DEBUG - 2024-03-16 12:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:36:55 --> Input Class Initialized
INFO - 2024-03-16 12:36:55 --> Language Class Initialized
INFO - 2024-03-16 12:36:55 --> Language Class Initialized
INFO - 2024-03-16 12:36:55 --> Config Class Initialized
INFO - 2024-03-16 12:36:55 --> Loader Class Initialized
INFO - 2024-03-16 12:36:55 --> Helper loaded: url_helper
INFO - 2024-03-16 12:36:55 --> Helper loaded: file_helper
INFO - 2024-03-16 12:36:55 --> Helper loaded: form_helper
INFO - 2024-03-16 12:36:55 --> Helper loaded: my_helper
INFO - 2024-03-16 12:36:55 --> Database Driver Class Initialized
INFO - 2024-03-16 12:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:36:55 --> Controller Class Initialized
INFO - 2024-03-16 12:36:55 --> Final output sent to browser
DEBUG - 2024-03-16 12:36:55 --> Total execution time: 0.0336
INFO - 2024-03-16 12:37:25 --> Config Class Initialized
INFO - 2024-03-16 12:37:25 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:37:25 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:37:25 --> Utf8 Class Initialized
INFO - 2024-03-16 12:37:25 --> URI Class Initialized
INFO - 2024-03-16 12:37:25 --> Router Class Initialized
INFO - 2024-03-16 12:37:25 --> Output Class Initialized
INFO - 2024-03-16 12:37:25 --> Security Class Initialized
DEBUG - 2024-03-16 12:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:37:25 --> Input Class Initialized
INFO - 2024-03-16 12:37:25 --> Language Class Initialized
INFO - 2024-03-16 12:37:25 --> Language Class Initialized
INFO - 2024-03-16 12:37:25 --> Config Class Initialized
INFO - 2024-03-16 12:37:25 --> Loader Class Initialized
INFO - 2024-03-16 12:37:25 --> Helper loaded: url_helper
INFO - 2024-03-16 12:37:25 --> Helper loaded: file_helper
INFO - 2024-03-16 12:37:25 --> Helper loaded: form_helper
INFO - 2024-03-16 12:37:25 --> Helper loaded: my_helper
INFO - 2024-03-16 12:37:25 --> Database Driver Class Initialized
INFO - 2024-03-16 12:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:37:25 --> Controller Class Initialized
INFO - 2024-03-16 12:37:25 --> Final output sent to browser
DEBUG - 2024-03-16 12:37:25 --> Total execution time: 0.0481
INFO - 2024-03-16 12:37:28 --> Config Class Initialized
INFO - 2024-03-16 12:37:28 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:37:28 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:37:28 --> Utf8 Class Initialized
INFO - 2024-03-16 12:37:28 --> URI Class Initialized
INFO - 2024-03-16 12:37:28 --> Router Class Initialized
INFO - 2024-03-16 12:37:28 --> Output Class Initialized
INFO - 2024-03-16 12:37:28 --> Security Class Initialized
DEBUG - 2024-03-16 12:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:37:28 --> Input Class Initialized
INFO - 2024-03-16 12:37:28 --> Language Class Initialized
INFO - 2024-03-16 12:37:28 --> Language Class Initialized
INFO - 2024-03-16 12:37:28 --> Config Class Initialized
INFO - 2024-03-16 12:37:28 --> Loader Class Initialized
INFO - 2024-03-16 12:37:28 --> Helper loaded: url_helper
INFO - 2024-03-16 12:37:28 --> Helper loaded: file_helper
INFO - 2024-03-16 12:37:28 --> Helper loaded: form_helper
INFO - 2024-03-16 12:37:28 --> Helper loaded: my_helper
INFO - 2024-03-16 12:37:28 --> Database Driver Class Initialized
INFO - 2024-03-16 12:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:37:28 --> Controller Class Initialized
INFO - 2024-03-16 12:37:28 --> Final output sent to browser
DEBUG - 2024-03-16 12:37:28 --> Total execution time: 0.0395
INFO - 2024-03-16 12:37:57 --> Config Class Initialized
INFO - 2024-03-16 12:37:57 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:37:57 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:37:57 --> Utf8 Class Initialized
INFO - 2024-03-16 12:37:57 --> URI Class Initialized
INFO - 2024-03-16 12:37:57 --> Router Class Initialized
INFO - 2024-03-16 12:37:57 --> Output Class Initialized
INFO - 2024-03-16 12:37:57 --> Security Class Initialized
DEBUG - 2024-03-16 12:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:37:57 --> Input Class Initialized
INFO - 2024-03-16 12:37:57 --> Language Class Initialized
INFO - 2024-03-16 12:37:57 --> Language Class Initialized
INFO - 2024-03-16 12:37:57 --> Config Class Initialized
INFO - 2024-03-16 12:37:57 --> Loader Class Initialized
INFO - 2024-03-16 12:37:57 --> Helper loaded: url_helper
INFO - 2024-03-16 12:37:57 --> Helper loaded: file_helper
INFO - 2024-03-16 12:37:57 --> Helper loaded: form_helper
INFO - 2024-03-16 12:37:57 --> Helper loaded: my_helper
INFO - 2024-03-16 12:37:57 --> Database Driver Class Initialized
INFO - 2024-03-16 12:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:37:57 --> Controller Class Initialized
INFO - 2024-03-16 12:37:57 --> Final output sent to browser
DEBUG - 2024-03-16 12:37:57 --> Total execution time: 0.0654
INFO - 2024-03-16 12:38:12 --> Config Class Initialized
INFO - 2024-03-16 12:38:12 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:38:12 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:38:12 --> Utf8 Class Initialized
INFO - 2024-03-16 12:38:12 --> URI Class Initialized
INFO - 2024-03-16 12:38:12 --> Router Class Initialized
INFO - 2024-03-16 12:38:12 --> Output Class Initialized
INFO - 2024-03-16 12:38:12 --> Security Class Initialized
DEBUG - 2024-03-16 12:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:38:12 --> Input Class Initialized
INFO - 2024-03-16 12:38:12 --> Language Class Initialized
INFO - 2024-03-16 12:38:12 --> Language Class Initialized
INFO - 2024-03-16 12:38:12 --> Config Class Initialized
INFO - 2024-03-16 12:38:12 --> Loader Class Initialized
INFO - 2024-03-16 12:38:12 --> Helper loaded: url_helper
INFO - 2024-03-16 12:38:12 --> Helper loaded: file_helper
INFO - 2024-03-16 12:38:12 --> Helper loaded: form_helper
INFO - 2024-03-16 12:38:12 --> Helper loaded: my_helper
INFO - 2024-03-16 12:38:12 --> Database Driver Class Initialized
INFO - 2024-03-16 12:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:38:12 --> Controller Class Initialized
INFO - 2024-03-16 12:38:12 --> Final output sent to browser
DEBUG - 2024-03-16 12:38:12 --> Total execution time: 0.0660
INFO - 2024-03-16 12:38:16 --> Config Class Initialized
INFO - 2024-03-16 12:38:16 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:38:16 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:38:16 --> Utf8 Class Initialized
INFO - 2024-03-16 12:38:16 --> URI Class Initialized
INFO - 2024-03-16 12:38:16 --> Router Class Initialized
INFO - 2024-03-16 12:38:16 --> Output Class Initialized
INFO - 2024-03-16 12:38:16 --> Security Class Initialized
DEBUG - 2024-03-16 12:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:38:16 --> Input Class Initialized
INFO - 2024-03-16 12:38:16 --> Language Class Initialized
INFO - 2024-03-16 12:38:16 --> Language Class Initialized
INFO - 2024-03-16 12:38:16 --> Config Class Initialized
INFO - 2024-03-16 12:38:16 --> Loader Class Initialized
INFO - 2024-03-16 12:38:16 --> Helper loaded: url_helper
INFO - 2024-03-16 12:38:16 --> Helper loaded: file_helper
INFO - 2024-03-16 12:38:16 --> Helper loaded: form_helper
INFO - 2024-03-16 12:38:16 --> Helper loaded: my_helper
INFO - 2024-03-16 12:38:16 --> Database Driver Class Initialized
INFO - 2024-03-16 12:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:38:16 --> Controller Class Initialized
INFO - 2024-03-16 12:38:16 --> Final output sent to browser
DEBUG - 2024-03-16 12:38:16 --> Total execution time: 0.0385
INFO - 2024-03-16 12:38:39 --> Config Class Initialized
INFO - 2024-03-16 12:38:39 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:38:39 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:38:39 --> Utf8 Class Initialized
INFO - 2024-03-16 12:38:39 --> URI Class Initialized
INFO - 2024-03-16 12:38:39 --> Router Class Initialized
INFO - 2024-03-16 12:38:39 --> Output Class Initialized
INFO - 2024-03-16 12:38:39 --> Security Class Initialized
DEBUG - 2024-03-16 12:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:38:39 --> Input Class Initialized
INFO - 2024-03-16 12:38:39 --> Language Class Initialized
INFO - 2024-03-16 12:38:39 --> Language Class Initialized
INFO - 2024-03-16 12:38:39 --> Config Class Initialized
INFO - 2024-03-16 12:38:39 --> Loader Class Initialized
INFO - 2024-03-16 12:38:39 --> Helper loaded: url_helper
INFO - 2024-03-16 12:38:39 --> Helper loaded: file_helper
INFO - 2024-03-16 12:38:39 --> Helper loaded: form_helper
INFO - 2024-03-16 12:38:39 --> Helper loaded: my_helper
INFO - 2024-03-16 12:38:39 --> Database Driver Class Initialized
INFO - 2024-03-16 12:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:38:39 --> Controller Class Initialized
INFO - 2024-03-16 12:38:39 --> Final output sent to browser
DEBUG - 2024-03-16 12:38:39 --> Total execution time: 0.0602
INFO - 2024-03-16 12:38:44 --> Config Class Initialized
INFO - 2024-03-16 12:38:44 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:38:44 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:38:44 --> Utf8 Class Initialized
INFO - 2024-03-16 12:38:44 --> URI Class Initialized
INFO - 2024-03-16 12:38:44 --> Router Class Initialized
INFO - 2024-03-16 12:38:44 --> Output Class Initialized
INFO - 2024-03-16 12:38:44 --> Security Class Initialized
DEBUG - 2024-03-16 12:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:38:44 --> Input Class Initialized
INFO - 2024-03-16 12:38:44 --> Language Class Initialized
INFO - 2024-03-16 12:38:44 --> Language Class Initialized
INFO - 2024-03-16 12:38:44 --> Config Class Initialized
INFO - 2024-03-16 12:38:44 --> Loader Class Initialized
INFO - 2024-03-16 12:38:44 --> Helper loaded: url_helper
INFO - 2024-03-16 12:38:44 --> Helper loaded: file_helper
INFO - 2024-03-16 12:38:44 --> Helper loaded: form_helper
INFO - 2024-03-16 12:38:44 --> Helper loaded: my_helper
INFO - 2024-03-16 12:38:44 --> Database Driver Class Initialized
INFO - 2024-03-16 12:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:38:44 --> Controller Class Initialized
INFO - 2024-03-16 12:38:44 --> Final output sent to browser
DEBUG - 2024-03-16 12:38:44 --> Total execution time: 0.0705
INFO - 2024-03-16 12:39:15 --> Config Class Initialized
INFO - 2024-03-16 12:39:15 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:39:15 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:39:15 --> Utf8 Class Initialized
INFO - 2024-03-16 12:39:15 --> URI Class Initialized
INFO - 2024-03-16 12:39:15 --> Router Class Initialized
INFO - 2024-03-16 12:39:15 --> Output Class Initialized
INFO - 2024-03-16 12:39:15 --> Security Class Initialized
DEBUG - 2024-03-16 12:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:39:15 --> Input Class Initialized
INFO - 2024-03-16 12:39:15 --> Language Class Initialized
INFO - 2024-03-16 12:39:15 --> Language Class Initialized
INFO - 2024-03-16 12:39:15 --> Config Class Initialized
INFO - 2024-03-16 12:39:15 --> Loader Class Initialized
INFO - 2024-03-16 12:39:15 --> Helper loaded: url_helper
INFO - 2024-03-16 12:39:15 --> Helper loaded: file_helper
INFO - 2024-03-16 12:39:15 --> Helper loaded: form_helper
INFO - 2024-03-16 12:39:15 --> Helper loaded: my_helper
INFO - 2024-03-16 12:39:15 --> Database Driver Class Initialized
INFO - 2024-03-16 12:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:39:15 --> Controller Class Initialized
INFO - 2024-03-16 12:39:16 --> Final output sent to browser
DEBUG - 2024-03-16 12:39:16 --> Total execution time: 0.3257
INFO - 2024-03-16 12:40:02 --> Config Class Initialized
INFO - 2024-03-16 12:40:02 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:40:02 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:40:02 --> Utf8 Class Initialized
INFO - 2024-03-16 12:40:02 --> URI Class Initialized
INFO - 2024-03-16 12:40:02 --> Router Class Initialized
INFO - 2024-03-16 12:40:03 --> Output Class Initialized
INFO - 2024-03-16 12:40:03 --> Security Class Initialized
DEBUG - 2024-03-16 12:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:40:03 --> Input Class Initialized
INFO - 2024-03-16 12:40:03 --> Language Class Initialized
INFO - 2024-03-16 12:40:03 --> Language Class Initialized
INFO - 2024-03-16 12:40:03 --> Config Class Initialized
INFO - 2024-03-16 12:40:03 --> Loader Class Initialized
INFO - 2024-03-16 12:40:03 --> Helper loaded: url_helper
INFO - 2024-03-16 12:40:03 --> Helper loaded: file_helper
INFO - 2024-03-16 12:40:03 --> Helper loaded: form_helper
INFO - 2024-03-16 12:40:03 --> Helper loaded: my_helper
INFO - 2024-03-16 12:40:03 --> Database Driver Class Initialized
INFO - 2024-03-16 12:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:40:03 --> Controller Class Initialized
INFO - 2024-03-16 12:40:03 --> Final output sent to browser
DEBUG - 2024-03-16 12:40:03 --> Total execution time: 0.3070
INFO - 2024-03-16 12:40:07 --> Config Class Initialized
INFO - 2024-03-16 12:40:07 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:40:07 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:40:07 --> Utf8 Class Initialized
INFO - 2024-03-16 12:40:07 --> URI Class Initialized
INFO - 2024-03-16 12:40:07 --> Router Class Initialized
INFO - 2024-03-16 12:40:07 --> Output Class Initialized
INFO - 2024-03-16 12:40:07 --> Security Class Initialized
DEBUG - 2024-03-16 12:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:40:07 --> Input Class Initialized
INFO - 2024-03-16 12:40:07 --> Language Class Initialized
INFO - 2024-03-16 12:40:07 --> Language Class Initialized
INFO - 2024-03-16 12:40:07 --> Config Class Initialized
INFO - 2024-03-16 12:40:07 --> Loader Class Initialized
INFO - 2024-03-16 12:40:07 --> Helper loaded: url_helper
INFO - 2024-03-16 12:40:07 --> Helper loaded: file_helper
INFO - 2024-03-16 12:40:07 --> Helper loaded: form_helper
INFO - 2024-03-16 12:40:07 --> Helper loaded: my_helper
INFO - 2024-03-16 12:40:07 --> Database Driver Class Initialized
INFO - 2024-03-16 12:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:40:07 --> Controller Class Initialized
INFO - 2024-03-16 12:40:07 --> Final output sent to browser
DEBUG - 2024-03-16 12:40:07 --> Total execution time: 0.0936
INFO - 2024-03-16 12:42:38 --> Config Class Initialized
INFO - 2024-03-16 12:42:38 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:42:38 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:42:38 --> Utf8 Class Initialized
INFO - 2024-03-16 12:42:38 --> URI Class Initialized
INFO - 2024-03-16 12:42:38 --> Router Class Initialized
INFO - 2024-03-16 12:42:38 --> Output Class Initialized
INFO - 2024-03-16 12:42:38 --> Security Class Initialized
DEBUG - 2024-03-16 12:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:42:38 --> Input Class Initialized
INFO - 2024-03-16 12:42:38 --> Language Class Initialized
INFO - 2024-03-16 12:42:38 --> Language Class Initialized
INFO - 2024-03-16 12:42:38 --> Config Class Initialized
INFO - 2024-03-16 12:42:38 --> Loader Class Initialized
INFO - 2024-03-16 12:42:38 --> Helper loaded: url_helper
INFO - 2024-03-16 12:42:38 --> Helper loaded: file_helper
INFO - 2024-03-16 12:42:38 --> Helper loaded: form_helper
INFO - 2024-03-16 12:42:38 --> Helper loaded: my_helper
INFO - 2024-03-16 12:42:38 --> Database Driver Class Initialized
INFO - 2024-03-16 12:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:42:38 --> Controller Class Initialized
INFO - 2024-03-16 12:42:38 --> Final output sent to browser
DEBUG - 2024-03-16 12:42:38 --> Total execution time: 0.2109
INFO - 2024-03-16 12:42:40 --> Config Class Initialized
INFO - 2024-03-16 12:42:40 --> Hooks Class Initialized
DEBUG - 2024-03-16 12:42:40 --> UTF-8 Support Enabled
INFO - 2024-03-16 12:42:40 --> Utf8 Class Initialized
INFO - 2024-03-16 12:42:40 --> URI Class Initialized
INFO - 2024-03-16 12:42:40 --> Router Class Initialized
INFO - 2024-03-16 12:42:40 --> Output Class Initialized
INFO - 2024-03-16 12:42:40 --> Security Class Initialized
DEBUG - 2024-03-16 12:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 12:42:40 --> Input Class Initialized
INFO - 2024-03-16 12:42:40 --> Language Class Initialized
INFO - 2024-03-16 12:42:40 --> Language Class Initialized
INFO - 2024-03-16 12:42:40 --> Config Class Initialized
INFO - 2024-03-16 12:42:40 --> Loader Class Initialized
INFO - 2024-03-16 12:42:40 --> Helper loaded: url_helper
INFO - 2024-03-16 12:42:40 --> Helper loaded: file_helper
INFO - 2024-03-16 12:42:40 --> Helper loaded: form_helper
INFO - 2024-03-16 12:42:40 --> Helper loaded: my_helper
INFO - 2024-03-16 12:42:40 --> Database Driver Class Initialized
INFO - 2024-03-16 12:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 12:42:40 --> Controller Class Initialized
DEBUG - 2024-03-16 12:42:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-16 12:42:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-16 12:42:40 --> Final output sent to browser
DEBUG - 2024-03-16 12:42:40 --> Total execution time: 0.0351
INFO - 2024-03-16 15:15:39 --> Config Class Initialized
INFO - 2024-03-16 15:15:39 --> Hooks Class Initialized
DEBUG - 2024-03-16 15:15:39 --> UTF-8 Support Enabled
INFO - 2024-03-16 15:15:39 --> Utf8 Class Initialized
INFO - 2024-03-16 15:15:39 --> URI Class Initialized
INFO - 2024-03-16 15:15:39 --> Router Class Initialized
INFO - 2024-03-16 15:15:39 --> Output Class Initialized
INFO - 2024-03-16 15:15:39 --> Security Class Initialized
DEBUG - 2024-03-16 15:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-16 15:15:39 --> Input Class Initialized
INFO - 2024-03-16 15:15:39 --> Language Class Initialized
INFO - 2024-03-16 15:15:39 --> Language Class Initialized
INFO - 2024-03-16 15:15:39 --> Config Class Initialized
INFO - 2024-03-16 15:15:39 --> Loader Class Initialized
INFO - 2024-03-16 15:15:39 --> Helper loaded: url_helper
INFO - 2024-03-16 15:15:39 --> Helper loaded: file_helper
INFO - 2024-03-16 15:15:39 --> Helper loaded: form_helper
INFO - 2024-03-16 15:15:39 --> Helper loaded: my_helper
INFO - 2024-03-16 15:15:39 --> Database Driver Class Initialized
INFO - 2024-03-16 15:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-16 15:15:39 --> Controller Class Initialized
DEBUG - 2024-03-16 15:15:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-16 15:15:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-16 15:15:39 --> Final output sent to browser
DEBUG - 2024-03-16 15:15:39 --> Total execution time: 0.0698
