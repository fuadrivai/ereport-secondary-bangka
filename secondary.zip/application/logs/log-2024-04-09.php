<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-04-09 15:33:57 --> Config Class Initialized
INFO - 2024-04-09 15:33:57 --> Hooks Class Initialized
DEBUG - 2024-04-09 15:33:57 --> UTF-8 Support Enabled
INFO - 2024-04-09 15:33:57 --> Utf8 Class Initialized
INFO - 2024-04-09 15:33:57 --> URI Class Initialized
INFO - 2024-04-09 15:33:57 --> Router Class Initialized
INFO - 2024-04-09 15:33:57 --> Output Class Initialized
INFO - 2024-04-09 15:33:57 --> Security Class Initialized
DEBUG - 2024-04-09 15:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-09 15:33:57 --> Input Class Initialized
INFO - 2024-04-09 15:33:57 --> Language Class Initialized
INFO - 2024-04-09 15:33:57 --> Language Class Initialized
INFO - 2024-04-09 15:33:57 --> Config Class Initialized
INFO - 2024-04-09 15:33:57 --> Loader Class Initialized
INFO - 2024-04-09 15:33:57 --> Helper loaded: url_helper
INFO - 2024-04-09 15:33:57 --> Helper loaded: file_helper
INFO - 2024-04-09 15:33:57 --> Helper loaded: form_helper
INFO - 2024-04-09 15:33:57 --> Helper loaded: my_helper
INFO - 2024-04-09 15:33:57 --> Database Driver Class Initialized
INFO - 2024-04-09 15:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-09 15:33:57 --> Controller Class Initialized
DEBUG - 2024-04-09 15:33:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-04-09 15:33:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-04-09 15:33:57 --> Final output sent to browser
DEBUG - 2024-04-09 15:33:57 --> Total execution time: 0.1084
INFO - 2024-04-09 15:33:57 --> Config Class Initialized
INFO - 2024-04-09 15:33:57 --> Hooks Class Initialized
DEBUG - 2024-04-09 15:33:57 --> UTF-8 Support Enabled
INFO - 2024-04-09 15:33:57 --> Utf8 Class Initialized
INFO - 2024-04-09 15:33:57 --> URI Class Initialized
INFO - 2024-04-09 15:33:57 --> Router Class Initialized
INFO - 2024-04-09 15:33:57 --> Output Class Initialized
INFO - 2024-04-09 15:33:57 --> Security Class Initialized
DEBUG - 2024-04-09 15:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-09 15:33:57 --> Input Class Initialized
INFO - 2024-04-09 15:33:57 --> Language Class Initialized
INFO - 2024-04-09 15:33:57 --> Language Class Initialized
INFO - 2024-04-09 15:33:57 --> Config Class Initialized
INFO - 2024-04-09 15:33:57 --> Loader Class Initialized
INFO - 2024-04-09 15:33:57 --> Helper loaded: url_helper
INFO - 2024-04-09 15:33:57 --> Helper loaded: file_helper
INFO - 2024-04-09 15:33:57 --> Helper loaded: form_helper
INFO - 2024-04-09 15:33:57 --> Helper loaded: my_helper
INFO - 2024-04-09 15:33:57 --> Database Driver Class Initialized
INFO - 2024-04-09 15:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-09 15:33:57 --> Controller Class Initialized
