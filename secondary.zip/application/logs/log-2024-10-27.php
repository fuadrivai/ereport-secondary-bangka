<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-27 17:00:45 --> Config Class Initialized
INFO - 2024-10-27 17:00:45 --> Hooks Class Initialized
DEBUG - 2024-10-27 17:00:45 --> UTF-8 Support Enabled
INFO - 2024-10-27 17:00:45 --> Utf8 Class Initialized
INFO - 2024-10-27 17:00:45 --> URI Class Initialized
INFO - 2024-10-27 17:00:45 --> Router Class Initialized
INFO - 2024-10-27 17:00:45 --> Output Class Initialized
INFO - 2024-10-27 17:00:45 --> Security Class Initialized
DEBUG - 2024-10-27 17:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 17:00:45 --> Input Class Initialized
INFO - 2024-10-27 17:00:45 --> Language Class Initialized
INFO - 2024-10-27 17:00:45 --> Language Class Initialized
INFO - 2024-10-27 17:00:45 --> Config Class Initialized
INFO - 2024-10-27 17:00:45 --> Loader Class Initialized
INFO - 2024-10-27 17:00:45 --> Helper loaded: url_helper
INFO - 2024-10-27 17:00:45 --> Helper loaded: file_helper
INFO - 2024-10-27 17:00:45 --> Helper loaded: form_helper
INFO - 2024-10-27 17:00:45 --> Helper loaded: my_helper
INFO - 2024-10-27 17:00:45 --> Database Driver Class Initialized
INFO - 2024-10-27 17:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 17:00:45 --> Controller Class Initialized
INFO - 2024-10-27 17:00:45 --> Helper loaded: cookie_helper
INFO - 2024-10-27 17:00:45 --> Final output sent to browser
DEBUG - 2024-10-27 17:00:45 --> Total execution time: 0.0702
INFO - 2024-10-27 17:00:46 --> Config Class Initialized
INFO - 2024-10-27 17:00:46 --> Hooks Class Initialized
DEBUG - 2024-10-27 17:00:46 --> UTF-8 Support Enabled
INFO - 2024-10-27 17:00:46 --> Utf8 Class Initialized
INFO - 2024-10-27 17:00:46 --> URI Class Initialized
INFO - 2024-10-27 17:00:46 --> Router Class Initialized
INFO - 2024-10-27 17:00:46 --> Output Class Initialized
INFO - 2024-10-27 17:00:46 --> Security Class Initialized
DEBUG - 2024-10-27 17:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 17:00:46 --> Input Class Initialized
INFO - 2024-10-27 17:00:46 --> Language Class Initialized
INFO - 2024-10-27 17:00:46 --> Language Class Initialized
INFO - 2024-10-27 17:00:46 --> Config Class Initialized
INFO - 2024-10-27 17:00:46 --> Loader Class Initialized
INFO - 2024-10-27 17:00:46 --> Helper loaded: url_helper
INFO - 2024-10-27 17:00:46 --> Helper loaded: file_helper
INFO - 2024-10-27 17:00:46 --> Helper loaded: form_helper
INFO - 2024-10-27 17:00:46 --> Helper loaded: my_helper
INFO - 2024-10-27 17:00:46 --> Database Driver Class Initialized
INFO - 2024-10-27 17:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 17:00:46 --> Controller Class Initialized
INFO - 2024-10-27 17:00:46 --> Helper loaded: cookie_helper
INFO - 2024-10-27 17:00:46 --> Config Class Initialized
INFO - 2024-10-27 17:00:46 --> Hooks Class Initialized
DEBUG - 2024-10-27 17:00:46 --> UTF-8 Support Enabled
INFO - 2024-10-27 17:00:46 --> Utf8 Class Initialized
INFO - 2024-10-27 17:00:46 --> URI Class Initialized
INFO - 2024-10-27 17:00:46 --> Router Class Initialized
INFO - 2024-10-27 17:00:46 --> Output Class Initialized
INFO - 2024-10-27 17:00:46 --> Security Class Initialized
DEBUG - 2024-10-27 17:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 17:00:46 --> Input Class Initialized
INFO - 2024-10-27 17:00:46 --> Language Class Initialized
INFO - 2024-10-27 17:00:46 --> Language Class Initialized
INFO - 2024-10-27 17:00:46 --> Config Class Initialized
INFO - 2024-10-27 17:00:46 --> Loader Class Initialized
INFO - 2024-10-27 17:00:46 --> Helper loaded: url_helper
INFO - 2024-10-27 17:00:46 --> Helper loaded: file_helper
INFO - 2024-10-27 17:00:46 --> Helper loaded: form_helper
INFO - 2024-10-27 17:00:46 --> Helper loaded: my_helper
INFO - 2024-10-27 17:00:46 --> Database Driver Class Initialized
INFO - 2024-10-27 17:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 17:00:46 --> Controller Class Initialized
DEBUG - 2024-10-27 17:00:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-27 17:00:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-27 17:00:46 --> Final output sent to browser
DEBUG - 2024-10-27 17:00:46 --> Total execution time: 0.0489
INFO - 2024-10-27 17:00:51 --> Config Class Initialized
INFO - 2024-10-27 17:00:51 --> Hooks Class Initialized
DEBUG - 2024-10-27 17:00:51 --> UTF-8 Support Enabled
INFO - 2024-10-27 17:00:51 --> Utf8 Class Initialized
INFO - 2024-10-27 17:00:51 --> URI Class Initialized
INFO - 2024-10-27 17:00:51 --> Router Class Initialized
INFO - 2024-10-27 17:00:51 --> Output Class Initialized
INFO - 2024-10-27 17:00:51 --> Security Class Initialized
DEBUG - 2024-10-27 17:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 17:00:51 --> Input Class Initialized
INFO - 2024-10-27 17:00:51 --> Language Class Initialized
INFO - 2024-10-27 17:00:51 --> Language Class Initialized
INFO - 2024-10-27 17:00:51 --> Config Class Initialized
INFO - 2024-10-27 17:00:51 --> Loader Class Initialized
INFO - 2024-10-27 17:00:51 --> Helper loaded: url_helper
INFO - 2024-10-27 17:00:51 --> Helper loaded: file_helper
INFO - 2024-10-27 17:00:51 --> Helper loaded: form_helper
INFO - 2024-10-27 17:00:51 --> Helper loaded: my_helper
INFO - 2024-10-27 17:00:51 --> Database Driver Class Initialized
INFO - 2024-10-27 17:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 17:00:51 --> Controller Class Initialized
DEBUG - 2024-10-27 17:00:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-27 17:00:54 --> Final output sent to browser
DEBUG - 2024-10-27 17:00:54 --> Total execution time: 3.6612
