<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-01-11 02:50:07 --> Config Class Initialized
INFO - 2023-01-11 02:50:07 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:50:07 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:50:07 --> Utf8 Class Initialized
INFO - 2023-01-11 02:50:07 --> URI Class Initialized
DEBUG - 2023-01-11 02:50:08 --> No URI present. Default controller set.
INFO - 2023-01-11 02:50:08 --> Router Class Initialized
INFO - 2023-01-11 02:50:08 --> Output Class Initialized
INFO - 2023-01-11 02:50:08 --> Security Class Initialized
DEBUG - 2023-01-11 02:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:50:08 --> Input Class Initialized
INFO - 2023-01-11 02:50:08 --> Language Class Initialized
INFO - 2023-01-11 02:50:08 --> Language Class Initialized
INFO - 2023-01-11 02:50:08 --> Config Class Initialized
INFO - 2023-01-11 02:50:08 --> Loader Class Initialized
INFO - 2023-01-11 02:50:08 --> Helper loaded: url_helper
INFO - 2023-01-11 02:50:08 --> Helper loaded: file_helper
INFO - 2023-01-11 02:50:08 --> Helper loaded: form_helper
INFO - 2023-01-11 02:50:08 --> Helper loaded: my_helper
INFO - 2023-01-11 02:50:08 --> Database Driver Class Initialized
DEBUG - 2023-01-11 02:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-11 02:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-11 02:50:08 --> Controller Class Initialized
INFO - 2023-01-11 02:50:08 --> Config Class Initialized
INFO - 2023-01-11 02:50:08 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:50:08 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:50:08 --> Utf8 Class Initialized
INFO - 2023-01-11 02:50:08 --> URI Class Initialized
INFO - 2023-01-11 02:50:08 --> Router Class Initialized
INFO - 2023-01-11 02:50:08 --> Output Class Initialized
INFO - 2023-01-11 02:50:08 --> Security Class Initialized
DEBUG - 2023-01-11 02:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:50:08 --> Input Class Initialized
INFO - 2023-01-11 02:50:08 --> Language Class Initialized
INFO - 2023-01-11 02:50:08 --> Language Class Initialized
INFO - 2023-01-11 02:50:08 --> Config Class Initialized
INFO - 2023-01-11 02:50:08 --> Loader Class Initialized
INFO - 2023-01-11 02:50:08 --> Helper loaded: url_helper
INFO - 2023-01-11 02:50:08 --> Helper loaded: file_helper
INFO - 2023-01-11 02:50:08 --> Helper loaded: form_helper
INFO - 2023-01-11 02:50:08 --> Helper loaded: my_helper
INFO - 2023-01-11 02:50:08 --> Database Driver Class Initialized
DEBUG - 2023-01-11 02:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-11 02:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-11 02:50:08 --> Controller Class Initialized
DEBUG - 2023-01-11 02:50:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-11 02:50:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-11 02:50:08 --> Final output sent to browser
DEBUG - 2023-01-11 02:50:08 --> Total execution time: 0.1048
INFO - 2023-01-11 02:50:32 --> Config Class Initialized
INFO - 2023-01-11 02:50:32 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:50:32 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:50:32 --> Utf8 Class Initialized
INFO - 2023-01-11 02:50:32 --> URI Class Initialized
INFO - 2023-01-11 02:50:32 --> Router Class Initialized
INFO - 2023-01-11 02:50:32 --> Output Class Initialized
INFO - 2023-01-11 02:50:32 --> Security Class Initialized
DEBUG - 2023-01-11 02:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:50:32 --> Input Class Initialized
INFO - 2023-01-11 02:50:32 --> Language Class Initialized
INFO - 2023-01-11 02:50:32 --> Language Class Initialized
INFO - 2023-01-11 02:50:32 --> Config Class Initialized
INFO - 2023-01-11 02:50:32 --> Loader Class Initialized
INFO - 2023-01-11 02:50:32 --> Helper loaded: url_helper
INFO - 2023-01-11 02:50:32 --> Helper loaded: file_helper
INFO - 2023-01-11 02:50:32 --> Helper loaded: form_helper
INFO - 2023-01-11 02:50:32 --> Helper loaded: my_helper
INFO - 2023-01-11 02:50:32 --> Database Driver Class Initialized
DEBUG - 2023-01-11 02:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-11 02:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-11 02:50:32 --> Controller Class Initialized
INFO - 2023-01-11 02:50:32 --> Helper loaded: cookie_helper
INFO - 2023-01-11 02:50:32 --> Final output sent to browser
DEBUG - 2023-01-11 02:50:32 --> Total execution time: 0.0930
INFO - 2023-01-11 02:50:32 --> Config Class Initialized
INFO - 2023-01-11 02:50:32 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:50:32 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:50:32 --> Utf8 Class Initialized
INFO - 2023-01-11 02:50:32 --> URI Class Initialized
INFO - 2023-01-11 02:50:32 --> Router Class Initialized
INFO - 2023-01-11 02:50:32 --> Output Class Initialized
INFO - 2023-01-11 02:50:32 --> Security Class Initialized
DEBUG - 2023-01-11 02:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:50:32 --> Input Class Initialized
INFO - 2023-01-11 02:50:32 --> Language Class Initialized
INFO - 2023-01-11 02:50:32 --> Language Class Initialized
INFO - 2023-01-11 02:50:32 --> Config Class Initialized
INFO - 2023-01-11 02:50:32 --> Loader Class Initialized
INFO - 2023-01-11 02:50:32 --> Helper loaded: url_helper
INFO - 2023-01-11 02:50:32 --> Helper loaded: file_helper
INFO - 2023-01-11 02:50:32 --> Helper loaded: form_helper
INFO - 2023-01-11 02:50:32 --> Helper loaded: my_helper
INFO - 2023-01-11 02:50:32 --> Database Driver Class Initialized
DEBUG - 2023-01-11 02:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-11 02:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-11 02:50:32 --> Controller Class Initialized
DEBUG - 2023-01-11 02:50:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-01-11 02:50:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-11 02:50:32 --> Final output sent to browser
DEBUG - 2023-01-11 02:50:32 --> Total execution time: 0.0806
INFO - 2023-01-11 02:51:25 --> Config Class Initialized
INFO - 2023-01-11 02:51:25 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:51:25 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:51:25 --> Utf8 Class Initialized
INFO - 2023-01-11 02:51:25 --> URI Class Initialized
INFO - 2023-01-11 02:51:25 --> Router Class Initialized
INFO - 2023-01-11 02:51:25 --> Output Class Initialized
INFO - 2023-01-11 02:51:25 --> Security Class Initialized
DEBUG - 2023-01-11 02:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:51:25 --> Input Class Initialized
INFO - 2023-01-11 02:51:25 --> Language Class Initialized
INFO - 2023-01-11 02:51:25 --> Language Class Initialized
INFO - 2023-01-11 02:51:25 --> Config Class Initialized
INFO - 2023-01-11 02:51:25 --> Loader Class Initialized
INFO - 2023-01-11 02:51:25 --> Helper loaded: url_helper
INFO - 2023-01-11 02:51:25 --> Helper loaded: file_helper
INFO - 2023-01-11 02:51:25 --> Helper loaded: form_helper
INFO - 2023-01-11 02:51:25 --> Helper loaded: my_helper
INFO - 2023-01-11 02:51:25 --> Database Driver Class Initialized
DEBUG - 2023-01-11 02:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-11 02:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-11 02:51:25 --> Controller Class Initialized
DEBUG - 2023-01-11 02:51:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-01-11 02:51:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-11 02:51:25 --> Final output sent to browser
DEBUG - 2023-01-11 02:51:25 --> Total execution time: 0.0612
INFO - 2023-01-11 02:51:30 --> Config Class Initialized
INFO - 2023-01-11 02:51:30 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:51:30 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:51:30 --> Utf8 Class Initialized
INFO - 2023-01-11 02:51:30 --> URI Class Initialized
INFO - 2023-01-11 02:51:30 --> Router Class Initialized
INFO - 2023-01-11 02:51:30 --> Output Class Initialized
INFO - 2023-01-11 02:51:30 --> Security Class Initialized
DEBUG - 2023-01-11 02:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:51:30 --> Input Class Initialized
INFO - 2023-01-11 02:51:30 --> Language Class Initialized
INFO - 2023-01-11 02:51:30 --> Language Class Initialized
INFO - 2023-01-11 02:51:30 --> Config Class Initialized
INFO - 2023-01-11 02:51:30 --> Loader Class Initialized
INFO - 2023-01-11 02:51:30 --> Helper loaded: url_helper
INFO - 2023-01-11 02:51:30 --> Helper loaded: file_helper
INFO - 2023-01-11 02:51:30 --> Helper loaded: form_helper
INFO - 2023-01-11 02:51:30 --> Helper loaded: my_helper
INFO - 2023-01-11 02:51:30 --> Database Driver Class Initialized
DEBUG - 2023-01-11 02:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-11 02:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-11 02:51:30 --> Controller Class Initialized
INFO - 2023-01-11 02:51:30 --> Helper loaded: cookie_helper
INFO - 2023-01-11 02:51:30 --> Config Class Initialized
INFO - 2023-01-11 02:51:30 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:51:30 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:51:30 --> Utf8 Class Initialized
INFO - 2023-01-11 02:51:30 --> URI Class Initialized
INFO - 2023-01-11 02:51:30 --> Router Class Initialized
INFO - 2023-01-11 02:51:30 --> Output Class Initialized
INFO - 2023-01-11 02:51:30 --> Security Class Initialized
DEBUG - 2023-01-11 02:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:51:30 --> Input Class Initialized
INFO - 2023-01-11 02:51:30 --> Language Class Initialized
INFO - 2023-01-11 02:51:30 --> Language Class Initialized
INFO - 2023-01-11 02:51:30 --> Config Class Initialized
INFO - 2023-01-11 02:51:30 --> Loader Class Initialized
INFO - 2023-01-11 02:51:30 --> Helper loaded: url_helper
INFO - 2023-01-11 02:51:30 --> Helper loaded: file_helper
INFO - 2023-01-11 02:51:30 --> Helper loaded: form_helper
INFO - 2023-01-11 02:51:30 --> Helper loaded: my_helper
INFO - 2023-01-11 02:51:30 --> Database Driver Class Initialized
DEBUG - 2023-01-11 02:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-11 02:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-11 02:51:30 --> Controller Class Initialized
INFO - 2023-01-11 02:51:30 --> Config Class Initialized
INFO - 2023-01-11 02:51:30 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:51:30 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:51:30 --> Utf8 Class Initialized
INFO - 2023-01-11 02:51:30 --> URI Class Initialized
INFO - 2023-01-11 02:51:30 --> Router Class Initialized
INFO - 2023-01-11 02:51:30 --> Output Class Initialized
INFO - 2023-01-11 02:51:30 --> Security Class Initialized
DEBUG - 2023-01-11 02:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:51:30 --> Input Class Initialized
INFO - 2023-01-11 02:51:30 --> Language Class Initialized
INFO - 2023-01-11 02:51:30 --> Language Class Initialized
INFO - 2023-01-11 02:51:30 --> Config Class Initialized
INFO - 2023-01-11 02:51:30 --> Loader Class Initialized
INFO - 2023-01-11 02:51:30 --> Helper loaded: url_helper
INFO - 2023-01-11 02:51:30 --> Helper loaded: file_helper
INFO - 2023-01-11 02:51:30 --> Helper loaded: form_helper
INFO - 2023-01-11 02:51:30 --> Helper loaded: my_helper
INFO - 2023-01-11 02:51:30 --> Database Driver Class Initialized
DEBUG - 2023-01-11 02:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-11 02:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-11 02:51:30 --> Controller Class Initialized
DEBUG - 2023-01-11 02:51:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-11 02:51:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-11 02:51:30 --> Final output sent to browser
DEBUG - 2023-01-11 02:51:30 --> Total execution time: 0.0380
INFO - 2023-01-11 02:52:25 --> Config Class Initialized
INFO - 2023-01-11 02:52:25 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:52:25 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:52:25 --> Utf8 Class Initialized
INFO - 2023-01-11 02:52:25 --> URI Class Initialized
INFO - 2023-01-11 02:52:25 --> Router Class Initialized
INFO - 2023-01-11 02:52:25 --> Output Class Initialized
INFO - 2023-01-11 02:52:25 --> Security Class Initialized
DEBUG - 2023-01-11 02:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:52:25 --> Input Class Initialized
INFO - 2023-01-11 02:52:25 --> Language Class Initialized
INFO - 2023-01-11 02:52:25 --> Language Class Initialized
INFO - 2023-01-11 02:52:25 --> Config Class Initialized
INFO - 2023-01-11 02:52:25 --> Loader Class Initialized
INFO - 2023-01-11 02:52:25 --> Helper loaded: url_helper
INFO - 2023-01-11 02:52:25 --> Helper loaded: file_helper
INFO - 2023-01-11 02:52:25 --> Helper loaded: form_helper
INFO - 2023-01-11 02:52:25 --> Helper loaded: my_helper
INFO - 2023-01-11 02:52:25 --> Database Driver Class Initialized
DEBUG - 2023-01-11 02:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-11 02:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-11 02:52:25 --> Controller Class Initialized
INFO - 2023-01-11 02:52:25 --> Helper loaded: cookie_helper
INFO - 2023-01-11 02:52:25 --> Final output sent to browser
DEBUG - 2023-01-11 02:52:25 --> Total execution time: 0.0689
INFO - 2023-01-11 02:52:25 --> Config Class Initialized
INFO - 2023-01-11 02:52:25 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:52:25 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:52:25 --> Utf8 Class Initialized
INFO - 2023-01-11 02:52:25 --> URI Class Initialized
INFO - 2023-01-11 02:52:25 --> Router Class Initialized
INFO - 2023-01-11 02:52:25 --> Output Class Initialized
INFO - 2023-01-11 02:52:25 --> Security Class Initialized
DEBUG - 2023-01-11 02:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:52:25 --> Input Class Initialized
INFO - 2023-01-11 02:52:25 --> Language Class Initialized
INFO - 2023-01-11 02:52:25 --> Language Class Initialized
INFO - 2023-01-11 02:52:25 --> Config Class Initialized
INFO - 2023-01-11 02:52:25 --> Loader Class Initialized
INFO - 2023-01-11 02:52:25 --> Helper loaded: url_helper
INFO - 2023-01-11 02:52:25 --> Helper loaded: file_helper
INFO - 2023-01-11 02:52:25 --> Helper loaded: form_helper
INFO - 2023-01-11 02:52:25 --> Helper loaded: my_helper
INFO - 2023-01-11 02:52:25 --> Database Driver Class Initialized
DEBUG - 2023-01-11 02:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-11 02:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-11 02:52:25 --> Controller Class Initialized
DEBUG - 2023-01-11 02:52:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-01-11 02:52:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-11 02:52:25 --> Final output sent to browser
DEBUG - 2023-01-11 02:52:25 --> Total execution time: 0.0550
INFO - 2023-01-11 02:52:58 --> Config Class Initialized
INFO - 2023-01-11 02:52:58 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:52:58 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:52:58 --> Utf8 Class Initialized
INFO - 2023-01-11 02:52:58 --> URI Class Initialized
INFO - 2023-01-11 02:52:58 --> Router Class Initialized
INFO - 2023-01-11 02:52:58 --> Output Class Initialized
INFO - 2023-01-11 02:52:58 --> Security Class Initialized
DEBUG - 2023-01-11 02:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:52:58 --> Input Class Initialized
INFO - 2023-01-11 02:52:58 --> Language Class Initialized
INFO - 2023-01-11 02:52:58 --> Language Class Initialized
INFO - 2023-01-11 02:52:58 --> Config Class Initialized
INFO - 2023-01-11 02:52:58 --> Loader Class Initialized
INFO - 2023-01-11 02:52:58 --> Helper loaded: url_helper
INFO - 2023-01-11 02:52:58 --> Helper loaded: file_helper
INFO - 2023-01-11 02:52:58 --> Helper loaded: form_helper
INFO - 2023-01-11 02:52:58 --> Helper loaded: my_helper
INFO - 2023-01-11 02:52:58 --> Database Driver Class Initialized
DEBUG - 2023-01-11 02:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-11 02:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-11 02:52:58 --> Controller Class Initialized
INFO - 2023-01-11 02:52:58 --> Helper loaded: cookie_helper
INFO - 2023-01-11 02:52:58 --> Config Class Initialized
INFO - 2023-01-11 02:52:58 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:52:58 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:52:58 --> Utf8 Class Initialized
INFO - 2023-01-11 02:52:58 --> URI Class Initialized
INFO - 2023-01-11 02:52:58 --> Router Class Initialized
INFO - 2023-01-11 02:52:58 --> Output Class Initialized
INFO - 2023-01-11 02:52:58 --> Security Class Initialized
DEBUG - 2023-01-11 02:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:52:58 --> Input Class Initialized
INFO - 2023-01-11 02:52:58 --> Language Class Initialized
INFO - 2023-01-11 02:52:58 --> Language Class Initialized
INFO - 2023-01-11 02:52:58 --> Config Class Initialized
INFO - 2023-01-11 02:52:58 --> Loader Class Initialized
INFO - 2023-01-11 02:52:58 --> Helper loaded: url_helper
INFO - 2023-01-11 02:52:58 --> Helper loaded: file_helper
INFO - 2023-01-11 02:52:58 --> Helper loaded: form_helper
INFO - 2023-01-11 02:52:58 --> Helper loaded: my_helper
INFO - 2023-01-11 02:52:58 --> Database Driver Class Initialized
DEBUG - 2023-01-11 02:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-11 02:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-11 02:52:58 --> Controller Class Initialized
INFO - 2023-01-11 02:52:58 --> Config Class Initialized
INFO - 2023-01-11 02:52:58 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:52:58 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:52:58 --> Utf8 Class Initialized
INFO - 2023-01-11 02:52:58 --> URI Class Initialized
INFO - 2023-01-11 02:52:58 --> Router Class Initialized
INFO - 2023-01-11 02:52:58 --> Output Class Initialized
INFO - 2023-01-11 02:52:58 --> Security Class Initialized
DEBUG - 2023-01-11 02:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:52:58 --> Input Class Initialized
INFO - 2023-01-11 02:52:58 --> Language Class Initialized
INFO - 2023-01-11 02:52:58 --> Language Class Initialized
INFO - 2023-01-11 02:52:58 --> Config Class Initialized
INFO - 2023-01-11 02:52:58 --> Loader Class Initialized
INFO - 2023-01-11 02:52:58 --> Helper loaded: url_helper
INFO - 2023-01-11 02:52:58 --> Helper loaded: file_helper
INFO - 2023-01-11 02:52:58 --> Helper loaded: form_helper
INFO - 2023-01-11 02:52:58 --> Helper loaded: my_helper
INFO - 2023-01-11 02:52:58 --> Database Driver Class Initialized
DEBUG - 2023-01-11 02:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-11 02:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-11 02:52:58 --> Controller Class Initialized
DEBUG - 2023-01-11 02:52:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-11 02:52:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-11 02:52:58 --> Final output sent to browser
DEBUG - 2023-01-11 02:52:58 --> Total execution time: 0.0358
INFO - 2023-01-11 02:53:02 --> Config Class Initialized
INFO - 2023-01-11 02:53:02 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:53:02 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:53:02 --> Utf8 Class Initialized
INFO - 2023-01-11 02:53:02 --> URI Class Initialized
INFO - 2023-01-11 02:53:02 --> Router Class Initialized
INFO - 2023-01-11 02:53:02 --> Output Class Initialized
INFO - 2023-01-11 02:53:02 --> Security Class Initialized
DEBUG - 2023-01-11 02:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:53:02 --> Input Class Initialized
INFO - 2023-01-11 02:53:02 --> Language Class Initialized
INFO - 2023-01-11 02:53:02 --> Language Class Initialized
INFO - 2023-01-11 02:53:02 --> Config Class Initialized
INFO - 2023-01-11 02:53:02 --> Loader Class Initialized
INFO - 2023-01-11 02:53:02 --> Helper loaded: url_helper
INFO - 2023-01-11 02:53:02 --> Helper loaded: file_helper
INFO - 2023-01-11 02:53:02 --> Helper loaded: form_helper
INFO - 2023-01-11 02:53:02 --> Helper loaded: my_helper
INFO - 2023-01-11 02:53:02 --> Database Driver Class Initialized
DEBUG - 2023-01-11 02:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-11 02:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-11 02:53:02 --> Controller Class Initialized
INFO - 2023-01-11 02:53:02 --> Helper loaded: cookie_helper
INFO - 2023-01-11 02:53:02 --> Final output sent to browser
DEBUG - 2023-01-11 02:53:02 --> Total execution time: 0.0589
INFO - 2023-01-11 02:53:02 --> Config Class Initialized
INFO - 2023-01-11 02:53:02 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:53:02 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:53:02 --> Utf8 Class Initialized
INFO - 2023-01-11 02:53:02 --> URI Class Initialized
INFO - 2023-01-11 02:53:02 --> Router Class Initialized
INFO - 2023-01-11 02:53:02 --> Output Class Initialized
INFO - 2023-01-11 02:53:02 --> Security Class Initialized
DEBUG - 2023-01-11 02:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:53:02 --> Input Class Initialized
INFO - 2023-01-11 02:53:02 --> Language Class Initialized
INFO - 2023-01-11 02:53:02 --> Language Class Initialized
INFO - 2023-01-11 02:53:02 --> Config Class Initialized
INFO - 2023-01-11 02:53:02 --> Loader Class Initialized
INFO - 2023-01-11 02:53:02 --> Helper loaded: url_helper
INFO - 2023-01-11 02:53:02 --> Helper loaded: file_helper
INFO - 2023-01-11 02:53:02 --> Helper loaded: form_helper
INFO - 2023-01-11 02:53:02 --> Helper loaded: my_helper
INFO - 2023-01-11 02:53:02 --> Database Driver Class Initialized
DEBUG - 2023-01-11 02:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-11 02:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-11 02:53:02 --> Controller Class Initialized
DEBUG - 2023-01-11 02:53:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-11 02:53:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-11 02:53:02 --> Final output sent to browser
DEBUG - 2023-01-11 02:53:02 --> Total execution time: 0.0484
INFO - 2023-01-11 02:53:06 --> Config Class Initialized
INFO - 2023-01-11 02:53:06 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:53:06 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:53:06 --> Utf8 Class Initialized
INFO - 2023-01-11 02:53:06 --> URI Class Initialized
INFO - 2023-01-11 02:53:06 --> Router Class Initialized
INFO - 2023-01-11 02:53:06 --> Output Class Initialized
INFO - 2023-01-11 02:53:06 --> Security Class Initialized
DEBUG - 2023-01-11 02:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:53:06 --> Input Class Initialized
INFO - 2023-01-11 02:53:06 --> Language Class Initialized
INFO - 2023-01-11 02:53:06 --> Language Class Initialized
INFO - 2023-01-11 02:53:06 --> Config Class Initialized
INFO - 2023-01-11 02:53:06 --> Loader Class Initialized
INFO - 2023-01-11 02:53:06 --> Helper loaded: url_helper
INFO - 2023-01-11 02:53:06 --> Helper loaded: file_helper
INFO - 2023-01-11 02:53:06 --> Helper loaded: form_helper
INFO - 2023-01-11 02:53:06 --> Helper loaded: my_helper
INFO - 2023-01-11 02:53:06 --> Database Driver Class Initialized
DEBUG - 2023-01-11 02:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-11 02:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-11 02:53:06 --> Controller Class Initialized
DEBUG - 2023-01-11 02:53:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-11 02:53:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-11 02:53:06 --> Final output sent to browser
DEBUG - 2023-01-11 02:53:06 --> Total execution time: 0.0519
INFO - 2023-01-11 02:53:06 --> Config Class Initialized
INFO - 2023-01-11 02:53:06 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:53:06 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:53:06 --> Utf8 Class Initialized
INFO - 2023-01-11 02:53:06 --> URI Class Initialized
INFO - 2023-01-11 02:53:06 --> Router Class Initialized
INFO - 2023-01-11 02:53:06 --> Output Class Initialized
INFO - 2023-01-11 02:53:06 --> Security Class Initialized
DEBUG - 2023-01-11 02:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:53:06 --> Input Class Initialized
INFO - 2023-01-11 02:53:06 --> Language Class Initialized
INFO - 2023-01-11 02:53:06 --> Language Class Initialized
INFO - 2023-01-11 02:53:06 --> Config Class Initialized
INFO - 2023-01-11 02:53:06 --> Loader Class Initialized
INFO - 2023-01-11 02:53:06 --> Helper loaded: url_helper
INFO - 2023-01-11 02:53:06 --> Helper loaded: file_helper
INFO - 2023-01-11 02:53:06 --> Helper loaded: form_helper
INFO - 2023-01-11 02:53:06 --> Helper loaded: my_helper
INFO - 2023-01-11 02:53:06 --> Database Driver Class Initialized
DEBUG - 2023-01-11 02:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-11 02:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-11 02:53:06 --> Controller Class Initialized
INFO - 2023-01-11 02:53:37 --> Config Class Initialized
INFO - 2023-01-11 02:53:37 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:53:37 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:53:37 --> Utf8 Class Initialized
INFO - 2023-01-11 02:53:37 --> URI Class Initialized
INFO - 2023-01-11 02:53:37 --> Router Class Initialized
INFO - 2023-01-11 02:53:37 --> Output Class Initialized
INFO - 2023-01-11 02:53:37 --> Security Class Initialized
DEBUG - 2023-01-11 02:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:53:37 --> Input Class Initialized
INFO - 2023-01-11 02:53:37 --> Language Class Initialized
INFO - 2023-01-11 02:53:37 --> Language Class Initialized
INFO - 2023-01-11 02:53:37 --> Config Class Initialized
INFO - 2023-01-11 02:53:37 --> Loader Class Initialized
INFO - 2023-01-11 02:53:37 --> Helper loaded: url_helper
INFO - 2023-01-11 02:53:37 --> Helper loaded: file_helper
INFO - 2023-01-11 02:53:37 --> Helper loaded: form_helper
INFO - 2023-01-11 02:53:37 --> Helper loaded: my_helper
INFO - 2023-01-11 02:53:37 --> Database Driver Class Initialized
DEBUG - 2023-01-11 02:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-11 02:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-11 02:53:37 --> Controller Class Initialized
DEBUG - 2023-01-11 02:53:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-11 02:53:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-11 02:53:37 --> Final output sent to browser
DEBUG - 2023-01-11 02:53:37 --> Total execution time: 0.0453
INFO - 2023-01-11 02:53:37 --> Config Class Initialized
INFO - 2023-01-11 02:53:37 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:53:37 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:53:37 --> Utf8 Class Initialized
INFO - 2023-01-11 02:53:37 --> URI Class Initialized
INFO - 2023-01-11 02:53:37 --> Router Class Initialized
INFO - 2023-01-11 02:53:37 --> Output Class Initialized
INFO - 2023-01-11 02:53:37 --> Security Class Initialized
DEBUG - 2023-01-11 02:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:53:37 --> Input Class Initialized
INFO - 2023-01-11 02:53:37 --> Language Class Initialized
INFO - 2023-01-11 02:53:37 --> Language Class Initialized
INFO - 2023-01-11 02:53:37 --> Config Class Initialized
INFO - 2023-01-11 02:53:37 --> Loader Class Initialized
INFO - 2023-01-11 02:53:37 --> Helper loaded: url_helper
INFO - 2023-01-11 02:53:37 --> Helper loaded: file_helper
INFO - 2023-01-11 02:53:37 --> Helper loaded: form_helper
INFO - 2023-01-11 02:53:37 --> Helper loaded: my_helper
INFO - 2023-01-11 02:53:37 --> Database Driver Class Initialized
DEBUG - 2023-01-11 02:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-11 02:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-11 02:53:37 --> Controller Class Initialized
INFO - 2023-01-11 02:54:22 --> Config Class Initialized
INFO - 2023-01-11 02:54:22 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:54:22 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:54:22 --> Utf8 Class Initialized
INFO - 2023-01-11 02:54:22 --> URI Class Initialized
INFO - 2023-01-11 02:54:22 --> Router Class Initialized
INFO - 2023-01-11 02:54:22 --> Output Class Initialized
INFO - 2023-01-11 02:54:22 --> Security Class Initialized
DEBUG - 2023-01-11 02:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:54:22 --> Input Class Initialized
INFO - 2023-01-11 02:54:22 --> Language Class Initialized
INFO - 2023-01-11 02:54:22 --> Language Class Initialized
INFO - 2023-01-11 02:54:22 --> Config Class Initialized
INFO - 2023-01-11 02:54:22 --> Loader Class Initialized
INFO - 2023-01-11 02:54:22 --> Helper loaded: url_helper
INFO - 2023-01-11 02:54:22 --> Helper loaded: file_helper
INFO - 2023-01-11 02:54:22 --> Helper loaded: form_helper
INFO - 2023-01-11 02:54:22 --> Helper loaded: my_helper
INFO - 2023-01-11 02:54:22 --> Database Driver Class Initialized
DEBUG - 2023-01-11 02:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-11 02:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-11 02:54:22 --> Controller Class Initialized
INFO - 2023-01-11 02:54:22 --> Helper loaded: cookie_helper
INFO - 2023-01-11 02:54:22 --> Config Class Initialized
INFO - 2023-01-11 02:54:22 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:54:22 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:54:22 --> Utf8 Class Initialized
INFO - 2023-01-11 02:54:22 --> URI Class Initialized
INFO - 2023-01-11 02:54:22 --> Router Class Initialized
INFO - 2023-01-11 02:54:22 --> Output Class Initialized
INFO - 2023-01-11 02:54:22 --> Security Class Initialized
DEBUG - 2023-01-11 02:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:54:22 --> Input Class Initialized
INFO - 2023-01-11 02:54:22 --> Language Class Initialized
INFO - 2023-01-11 02:54:22 --> Language Class Initialized
INFO - 2023-01-11 02:54:22 --> Config Class Initialized
INFO - 2023-01-11 02:54:22 --> Loader Class Initialized
INFO - 2023-01-11 02:54:22 --> Helper loaded: url_helper
INFO - 2023-01-11 02:54:22 --> Helper loaded: file_helper
INFO - 2023-01-11 02:54:22 --> Helper loaded: form_helper
INFO - 2023-01-11 02:54:22 --> Helper loaded: my_helper
INFO - 2023-01-11 02:54:22 --> Database Driver Class Initialized
DEBUG - 2023-01-11 02:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-11 02:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-11 02:54:22 --> Controller Class Initialized
INFO - 2023-01-11 02:54:22 --> Config Class Initialized
INFO - 2023-01-11 02:54:22 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:54:22 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:54:22 --> Utf8 Class Initialized
INFO - 2023-01-11 02:54:22 --> URI Class Initialized
INFO - 2023-01-11 02:54:22 --> Router Class Initialized
INFO - 2023-01-11 02:54:22 --> Output Class Initialized
INFO - 2023-01-11 02:54:22 --> Security Class Initialized
DEBUG - 2023-01-11 02:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:54:22 --> Input Class Initialized
INFO - 2023-01-11 02:54:22 --> Language Class Initialized
INFO - 2023-01-11 02:54:22 --> Language Class Initialized
INFO - 2023-01-11 02:54:22 --> Config Class Initialized
INFO - 2023-01-11 02:54:22 --> Loader Class Initialized
INFO - 2023-01-11 02:54:22 --> Helper loaded: url_helper
INFO - 2023-01-11 02:54:22 --> Helper loaded: file_helper
INFO - 2023-01-11 02:54:22 --> Helper loaded: form_helper
INFO - 2023-01-11 02:54:22 --> Helper loaded: my_helper
INFO - 2023-01-11 02:54:22 --> Database Driver Class Initialized
DEBUG - 2023-01-11 02:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-11 02:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-11 02:54:22 --> Controller Class Initialized
DEBUG - 2023-01-11 02:54:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-11 02:54:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-11 02:54:22 --> Final output sent to browser
DEBUG - 2023-01-11 02:54:22 --> Total execution time: 0.0409
INFO - 2023-01-11 02:54:26 --> Config Class Initialized
INFO - 2023-01-11 02:54:26 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:54:26 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:54:26 --> Utf8 Class Initialized
INFO - 2023-01-11 02:54:26 --> URI Class Initialized
INFO - 2023-01-11 02:54:26 --> Router Class Initialized
INFO - 2023-01-11 02:54:26 --> Output Class Initialized
INFO - 2023-01-11 02:54:26 --> Security Class Initialized
DEBUG - 2023-01-11 02:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:54:26 --> Input Class Initialized
INFO - 2023-01-11 02:54:26 --> Language Class Initialized
INFO - 2023-01-11 02:54:26 --> Language Class Initialized
INFO - 2023-01-11 02:54:26 --> Config Class Initialized
INFO - 2023-01-11 02:54:26 --> Loader Class Initialized
INFO - 2023-01-11 02:54:26 --> Helper loaded: url_helper
INFO - 2023-01-11 02:54:26 --> Helper loaded: file_helper
INFO - 2023-01-11 02:54:26 --> Helper loaded: form_helper
INFO - 2023-01-11 02:54:26 --> Helper loaded: my_helper
INFO - 2023-01-11 02:54:27 --> Database Driver Class Initialized
DEBUG - 2023-01-11 02:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-11 02:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-11 02:54:27 --> Controller Class Initialized
INFO - 2023-01-11 02:54:27 --> Helper loaded: cookie_helper
INFO - 2023-01-11 02:54:27 --> Final output sent to browser
DEBUG - 2023-01-11 02:54:27 --> Total execution time: 0.0334
INFO - 2023-01-11 02:54:27 --> Config Class Initialized
INFO - 2023-01-11 02:54:27 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:54:27 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:54:27 --> Utf8 Class Initialized
INFO - 2023-01-11 02:54:27 --> URI Class Initialized
INFO - 2023-01-11 02:54:27 --> Router Class Initialized
INFO - 2023-01-11 02:54:27 --> Output Class Initialized
INFO - 2023-01-11 02:54:27 --> Security Class Initialized
DEBUG - 2023-01-11 02:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:54:27 --> Input Class Initialized
INFO - 2023-01-11 02:54:27 --> Language Class Initialized
INFO - 2023-01-11 02:54:27 --> Language Class Initialized
INFO - 2023-01-11 02:54:27 --> Config Class Initialized
INFO - 2023-01-11 02:54:27 --> Loader Class Initialized
INFO - 2023-01-11 02:54:27 --> Helper loaded: url_helper
INFO - 2023-01-11 02:54:27 --> Helper loaded: file_helper
INFO - 2023-01-11 02:54:27 --> Helper loaded: form_helper
INFO - 2023-01-11 02:54:27 --> Helper loaded: my_helper
INFO - 2023-01-11 02:54:27 --> Database Driver Class Initialized
DEBUG - 2023-01-11 02:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-11 02:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-11 02:54:27 --> Controller Class Initialized
DEBUG - 2023-01-11 02:54:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-11 02:54:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-11 02:54:27 --> Final output sent to browser
DEBUG - 2023-01-11 02:54:27 --> Total execution time: 0.0387
INFO - 2023-01-11 02:54:29 --> Config Class Initialized
INFO - 2023-01-11 02:54:29 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:54:29 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:54:29 --> Utf8 Class Initialized
INFO - 2023-01-11 02:54:29 --> URI Class Initialized
INFO - 2023-01-11 02:54:29 --> Router Class Initialized
INFO - 2023-01-11 02:54:29 --> Output Class Initialized
INFO - 2023-01-11 02:54:29 --> Security Class Initialized
DEBUG - 2023-01-11 02:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:54:29 --> Input Class Initialized
INFO - 2023-01-11 02:54:29 --> Language Class Initialized
INFO - 2023-01-11 02:54:29 --> Language Class Initialized
INFO - 2023-01-11 02:54:29 --> Config Class Initialized
INFO - 2023-01-11 02:54:29 --> Loader Class Initialized
INFO - 2023-01-11 02:54:29 --> Helper loaded: url_helper
INFO - 2023-01-11 02:54:29 --> Helper loaded: file_helper
INFO - 2023-01-11 02:54:29 --> Helper loaded: form_helper
INFO - 2023-01-11 02:54:29 --> Helper loaded: my_helper
INFO - 2023-01-11 02:54:29 --> Database Driver Class Initialized
DEBUG - 2023-01-11 02:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-11 02:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-11 02:54:29 --> Controller Class Initialized
DEBUG - 2023-01-11 02:54:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-01-11 02:54:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-11 02:54:29 --> Final output sent to browser
DEBUG - 2023-01-11 02:54:29 --> Total execution time: 0.0612
INFO - 2023-01-11 02:54:30 --> Config Class Initialized
INFO - 2023-01-11 02:54:30 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:54:30 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:54:30 --> Utf8 Class Initialized
INFO - 2023-01-11 02:54:30 --> URI Class Initialized
INFO - 2023-01-11 02:54:30 --> Router Class Initialized
INFO - 2023-01-11 02:54:30 --> Output Class Initialized
INFO - 2023-01-11 02:54:30 --> Security Class Initialized
DEBUG - 2023-01-11 02:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:54:30 --> Input Class Initialized
INFO - 2023-01-11 02:54:30 --> Language Class Initialized
INFO - 2023-01-11 02:54:30 --> Language Class Initialized
INFO - 2023-01-11 02:54:30 --> Config Class Initialized
INFO - 2023-01-11 02:54:30 --> Loader Class Initialized
INFO - 2023-01-11 02:54:30 --> Helper loaded: url_helper
INFO - 2023-01-11 02:54:30 --> Helper loaded: file_helper
INFO - 2023-01-11 02:54:30 --> Helper loaded: form_helper
INFO - 2023-01-11 02:54:30 --> Helper loaded: my_helper
INFO - 2023-01-11 02:54:30 --> Database Driver Class Initialized
DEBUG - 2023-01-11 02:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-11 02:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-11 02:54:30 --> Controller Class Initialized
DEBUG - 2023-01-11 02:54:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-11 02:54:30 --> Final output sent to browser
DEBUG - 2023-01-11 02:54:30 --> Total execution time: 0.5046
INFO - 2023-01-11 03:28:39 --> Config Class Initialized
INFO - 2023-01-11 03:28:39 --> Hooks Class Initialized
DEBUG - 2023-01-11 03:28:39 --> UTF-8 Support Enabled
INFO - 2023-01-11 03:28:39 --> Utf8 Class Initialized
INFO - 2023-01-11 03:28:39 --> URI Class Initialized
INFO - 2023-01-11 03:28:39 --> Router Class Initialized
INFO - 2023-01-11 03:28:39 --> Output Class Initialized
INFO - 2023-01-11 03:28:39 --> Security Class Initialized
DEBUG - 2023-01-11 03:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 03:28:39 --> Input Class Initialized
INFO - 2023-01-11 03:28:39 --> Language Class Initialized
INFO - 2023-01-11 03:28:39 --> Language Class Initialized
INFO - 2023-01-11 03:28:39 --> Config Class Initialized
INFO - 2023-01-11 03:28:39 --> Loader Class Initialized
INFO - 2023-01-11 03:28:39 --> Helper loaded: url_helper
INFO - 2023-01-11 03:28:39 --> Helper loaded: file_helper
INFO - 2023-01-11 03:28:39 --> Helper loaded: form_helper
INFO - 2023-01-11 03:28:39 --> Helper loaded: my_helper
INFO - 2023-01-11 03:28:39 --> Database Driver Class Initialized
DEBUG - 2023-01-11 03:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-11 03:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-11 03:28:39 --> Controller Class Initialized
DEBUG - 2023-01-11 03:28:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-01-11 03:28:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-11 03:28:39 --> Final output sent to browser
DEBUG - 2023-01-11 03:28:39 --> Total execution time: 0.1213
INFO - 2023-01-11 04:49:16 --> Config Class Initialized
INFO - 2023-01-11 04:49:16 --> Hooks Class Initialized
DEBUG - 2023-01-11 04:49:16 --> UTF-8 Support Enabled
INFO - 2023-01-11 04:49:16 --> Utf8 Class Initialized
INFO - 2023-01-11 04:49:16 --> URI Class Initialized
INFO - 2023-01-11 04:49:16 --> Router Class Initialized
INFO - 2023-01-11 04:49:16 --> Output Class Initialized
INFO - 2023-01-11 04:49:16 --> Security Class Initialized
DEBUG - 2023-01-11 04:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 04:49:16 --> Input Class Initialized
INFO - 2023-01-11 04:49:16 --> Language Class Initialized
INFO - 2023-01-11 04:49:16 --> Language Class Initialized
INFO - 2023-01-11 04:49:16 --> Config Class Initialized
INFO - 2023-01-11 04:49:16 --> Loader Class Initialized
INFO - 2023-01-11 04:49:16 --> Helper loaded: url_helper
INFO - 2023-01-11 04:49:16 --> Helper loaded: file_helper
INFO - 2023-01-11 04:49:16 --> Helper loaded: form_helper
INFO - 2023-01-11 04:49:16 --> Helper loaded: my_helper
INFO - 2023-01-11 04:49:16 --> Database Driver Class Initialized
DEBUG - 2023-01-11 04:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-11 04:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-11 04:49:16 --> Controller Class Initialized
DEBUG - 2023-01-11 04:49:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-01-11 04:49:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-11 04:49:16 --> Final output sent to browser
DEBUG - 2023-01-11 04:49:16 --> Total execution time: 0.1083
