<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-09 14:49:48 --> Config Class Initialized
INFO - 2023-09-09 14:49:48 --> Hooks Class Initialized
DEBUG - 2023-09-09 14:49:48 --> UTF-8 Support Enabled
INFO - 2023-09-09 14:49:48 --> Utf8 Class Initialized
INFO - 2023-09-09 14:49:48 --> URI Class Initialized
DEBUG - 2023-09-09 14:49:48 --> No URI present. Default controller set.
INFO - 2023-09-09 14:49:48 --> Router Class Initialized
INFO - 2023-09-09 14:49:48 --> Output Class Initialized
INFO - 2023-09-09 14:49:48 --> Security Class Initialized
DEBUG - 2023-09-09 14:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-09 14:49:48 --> Input Class Initialized
INFO - 2023-09-09 14:49:48 --> Language Class Initialized
INFO - 2023-09-09 14:49:48 --> Language Class Initialized
INFO - 2023-09-09 14:49:48 --> Config Class Initialized
INFO - 2023-09-09 14:49:48 --> Loader Class Initialized
INFO - 2023-09-09 14:49:48 --> Helper loaded: url_helper
INFO - 2023-09-09 14:49:48 --> Helper loaded: file_helper
INFO - 2023-09-09 14:49:48 --> Helper loaded: form_helper
INFO - 2023-09-09 14:49:48 --> Helper loaded: my_helper
INFO - 2023-09-09 14:49:48 --> Database Driver Class Initialized
INFO - 2023-09-09 14:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-09 14:49:48 --> Controller Class Initialized
INFO - 2023-09-09 14:49:49 --> Config Class Initialized
INFO - 2023-09-09 14:49:49 --> Hooks Class Initialized
DEBUG - 2023-09-09 14:49:49 --> UTF-8 Support Enabled
INFO - 2023-09-09 14:49:49 --> Utf8 Class Initialized
INFO - 2023-09-09 14:49:49 --> URI Class Initialized
INFO - 2023-09-09 14:49:49 --> Router Class Initialized
INFO - 2023-09-09 14:49:49 --> Output Class Initialized
INFO - 2023-09-09 14:49:49 --> Security Class Initialized
DEBUG - 2023-09-09 14:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-09 14:49:49 --> Input Class Initialized
INFO - 2023-09-09 14:49:49 --> Language Class Initialized
INFO - 2023-09-09 14:49:49 --> Language Class Initialized
INFO - 2023-09-09 14:49:49 --> Config Class Initialized
INFO - 2023-09-09 14:49:49 --> Loader Class Initialized
INFO - 2023-09-09 14:49:49 --> Helper loaded: url_helper
INFO - 2023-09-09 14:49:49 --> Helper loaded: file_helper
INFO - 2023-09-09 14:49:49 --> Helper loaded: form_helper
INFO - 2023-09-09 14:49:49 --> Helper loaded: my_helper
INFO - 2023-09-09 14:49:49 --> Database Driver Class Initialized
INFO - 2023-09-09 14:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-09 14:49:49 --> Controller Class Initialized
DEBUG - 2023-09-09 14:49:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-09 14:49:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-09 14:49:49 --> Final output sent to browser
DEBUG - 2023-09-09 14:49:49 --> Total execution time: 0.3040
INFO - 2023-09-09 14:49:57 --> Config Class Initialized
INFO - 2023-09-09 14:49:57 --> Hooks Class Initialized
DEBUG - 2023-09-09 14:49:57 --> UTF-8 Support Enabled
INFO - 2023-09-09 14:49:57 --> Utf8 Class Initialized
INFO - 2023-09-09 14:49:57 --> URI Class Initialized
DEBUG - 2023-09-09 14:49:57 --> No URI present. Default controller set.
INFO - 2023-09-09 14:49:57 --> Router Class Initialized
INFO - 2023-09-09 14:49:57 --> Output Class Initialized
INFO - 2023-09-09 14:49:57 --> Security Class Initialized
DEBUG - 2023-09-09 14:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-09 14:49:57 --> Input Class Initialized
INFO - 2023-09-09 14:49:57 --> Language Class Initialized
INFO - 2023-09-09 14:49:57 --> Language Class Initialized
INFO - 2023-09-09 14:49:57 --> Config Class Initialized
INFO - 2023-09-09 14:49:57 --> Loader Class Initialized
INFO - 2023-09-09 14:49:57 --> Helper loaded: url_helper
INFO - 2023-09-09 14:49:57 --> Helper loaded: file_helper
INFO - 2023-09-09 14:49:57 --> Helper loaded: form_helper
INFO - 2023-09-09 14:49:57 --> Helper loaded: my_helper
INFO - 2023-09-09 14:49:57 --> Database Driver Class Initialized
INFO - 2023-09-09 14:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-09 14:49:57 --> Controller Class Initialized
INFO - 2023-09-09 14:49:58 --> Config Class Initialized
INFO - 2023-09-09 14:49:58 --> Hooks Class Initialized
DEBUG - 2023-09-09 14:49:58 --> UTF-8 Support Enabled
INFO - 2023-09-09 14:49:58 --> Utf8 Class Initialized
INFO - 2023-09-09 14:49:58 --> URI Class Initialized
INFO - 2023-09-09 14:49:58 --> Router Class Initialized
INFO - 2023-09-09 14:49:58 --> Output Class Initialized
INFO - 2023-09-09 14:49:58 --> Security Class Initialized
DEBUG - 2023-09-09 14:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-09 14:49:58 --> Input Class Initialized
INFO - 2023-09-09 14:49:58 --> Language Class Initialized
INFO - 2023-09-09 14:49:58 --> Language Class Initialized
INFO - 2023-09-09 14:49:58 --> Config Class Initialized
INFO - 2023-09-09 14:49:58 --> Loader Class Initialized
INFO - 2023-09-09 14:49:58 --> Helper loaded: url_helper
INFO - 2023-09-09 14:49:58 --> Helper loaded: file_helper
INFO - 2023-09-09 14:49:58 --> Helper loaded: form_helper
INFO - 2023-09-09 14:49:58 --> Helper loaded: my_helper
INFO - 2023-09-09 14:49:58 --> Database Driver Class Initialized
INFO - 2023-09-09 14:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-09 14:49:58 --> Controller Class Initialized
DEBUG - 2023-09-09 14:49:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-09 14:49:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-09 14:49:58 --> Final output sent to browser
DEBUG - 2023-09-09 14:49:58 --> Total execution time: 0.2474
