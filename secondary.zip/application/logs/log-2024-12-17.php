<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-17 07:48:21 --> Config Class Initialized
INFO - 2024-12-17 07:48:21 --> Hooks Class Initialized
DEBUG - 2024-12-17 07:48:21 --> UTF-8 Support Enabled
INFO - 2024-12-17 07:48:21 --> Utf8 Class Initialized
INFO - 2024-12-17 07:48:21 --> URI Class Initialized
INFO - 2024-12-17 07:48:21 --> Router Class Initialized
INFO - 2024-12-17 07:48:21 --> Output Class Initialized
INFO - 2024-12-17 07:48:21 --> Security Class Initialized
DEBUG - 2024-12-17 07:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 07:48:21 --> Input Class Initialized
INFO - 2024-12-17 07:48:21 --> Language Class Initialized
INFO - 2024-12-17 07:48:21 --> Language Class Initialized
INFO - 2024-12-17 07:48:21 --> Config Class Initialized
INFO - 2024-12-17 07:48:21 --> Loader Class Initialized
INFO - 2024-12-17 07:48:21 --> Helper loaded: url_helper
INFO - 2024-12-17 07:48:21 --> Helper loaded: file_helper
INFO - 2024-12-17 07:48:21 --> Helper loaded: form_helper
INFO - 2024-12-17 07:48:21 --> Helper loaded: my_helper
INFO - 2024-12-17 07:48:21 --> Database Driver Class Initialized
INFO - 2024-12-17 07:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 07:48:21 --> Controller Class Initialized
INFO - 2024-12-17 07:48:21 --> Helper loaded: cookie_helper
INFO - 2024-12-17 07:48:21 --> Final output sent to browser
DEBUG - 2024-12-17 07:48:21 --> Total execution time: 0.0759
INFO - 2024-12-17 07:48:21 --> Config Class Initialized
INFO - 2024-12-17 07:48:21 --> Hooks Class Initialized
DEBUG - 2024-12-17 07:48:21 --> UTF-8 Support Enabled
INFO - 2024-12-17 07:48:21 --> Utf8 Class Initialized
INFO - 2024-12-17 07:48:21 --> URI Class Initialized
INFO - 2024-12-17 07:48:21 --> Router Class Initialized
INFO - 2024-12-17 07:48:21 --> Output Class Initialized
INFO - 2024-12-17 07:48:21 --> Security Class Initialized
DEBUG - 2024-12-17 07:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 07:48:21 --> Input Class Initialized
INFO - 2024-12-17 07:48:21 --> Language Class Initialized
INFO - 2024-12-17 07:48:21 --> Language Class Initialized
INFO - 2024-12-17 07:48:21 --> Config Class Initialized
INFO - 2024-12-17 07:48:21 --> Loader Class Initialized
INFO - 2024-12-17 07:48:21 --> Helper loaded: url_helper
INFO - 2024-12-17 07:48:21 --> Helper loaded: file_helper
INFO - 2024-12-17 07:48:21 --> Helper loaded: form_helper
INFO - 2024-12-17 07:48:21 --> Helper loaded: my_helper
INFO - 2024-12-17 07:48:21 --> Database Driver Class Initialized
INFO - 2024-12-17 07:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 07:48:21 --> Controller Class Initialized
INFO - 2024-12-17 07:48:21 --> Helper loaded: cookie_helper
INFO - 2024-12-17 07:48:21 --> Config Class Initialized
INFO - 2024-12-17 07:48:21 --> Hooks Class Initialized
DEBUG - 2024-12-17 07:48:21 --> UTF-8 Support Enabled
INFO - 2024-12-17 07:48:21 --> Utf8 Class Initialized
INFO - 2024-12-17 07:48:21 --> URI Class Initialized
INFO - 2024-12-17 07:48:21 --> Router Class Initialized
INFO - 2024-12-17 07:48:21 --> Output Class Initialized
INFO - 2024-12-17 07:48:21 --> Security Class Initialized
DEBUG - 2024-12-17 07:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 07:48:21 --> Input Class Initialized
INFO - 2024-12-17 07:48:21 --> Language Class Initialized
INFO - 2024-12-17 07:48:21 --> Language Class Initialized
INFO - 2024-12-17 07:48:21 --> Config Class Initialized
INFO - 2024-12-17 07:48:21 --> Loader Class Initialized
INFO - 2024-12-17 07:48:21 --> Helper loaded: url_helper
INFO - 2024-12-17 07:48:21 --> Helper loaded: file_helper
INFO - 2024-12-17 07:48:21 --> Helper loaded: form_helper
INFO - 2024-12-17 07:48:21 --> Helper loaded: my_helper
INFO - 2024-12-17 07:48:21 --> Database Driver Class Initialized
INFO - 2024-12-17 07:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 07:48:21 --> Controller Class Initialized
DEBUG - 2024-12-17 07:48:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-17 07:48:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 07:48:21 --> Final output sent to browser
DEBUG - 2024-12-17 07:48:21 --> Total execution time: 0.0299
INFO - 2024-12-17 07:48:24 --> Config Class Initialized
INFO - 2024-12-17 07:48:24 --> Hooks Class Initialized
DEBUG - 2024-12-17 07:48:24 --> UTF-8 Support Enabled
INFO - 2024-12-17 07:48:24 --> Utf8 Class Initialized
INFO - 2024-12-17 07:48:24 --> URI Class Initialized
INFO - 2024-12-17 07:48:24 --> Router Class Initialized
INFO - 2024-12-17 07:48:24 --> Output Class Initialized
INFO - 2024-12-17 07:48:24 --> Security Class Initialized
DEBUG - 2024-12-17 07:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 07:48:24 --> Input Class Initialized
INFO - 2024-12-17 07:48:24 --> Language Class Initialized
INFO - 2024-12-17 07:48:24 --> Language Class Initialized
INFO - 2024-12-17 07:48:24 --> Config Class Initialized
INFO - 2024-12-17 07:48:24 --> Loader Class Initialized
INFO - 2024-12-17 07:48:24 --> Helper loaded: url_helper
INFO - 2024-12-17 07:48:24 --> Helper loaded: file_helper
INFO - 2024-12-17 07:48:24 --> Helper loaded: form_helper
INFO - 2024-12-17 07:48:24 --> Helper loaded: my_helper
INFO - 2024-12-17 07:48:24 --> Database Driver Class Initialized
INFO - 2024-12-17 07:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 07:48:24 --> Controller Class Initialized
DEBUG - 2024-12-17 07:48:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 07:48:29 --> Final output sent to browser
DEBUG - 2024-12-17 07:48:29 --> Total execution time: 4.4717
INFO - 2024-12-17 07:48:54 --> Config Class Initialized
INFO - 2024-12-17 07:48:54 --> Hooks Class Initialized
DEBUG - 2024-12-17 07:48:54 --> UTF-8 Support Enabled
INFO - 2024-12-17 07:48:54 --> Utf8 Class Initialized
INFO - 2024-12-17 07:48:54 --> URI Class Initialized
INFO - 2024-12-17 07:48:54 --> Router Class Initialized
INFO - 2024-12-17 07:48:54 --> Output Class Initialized
INFO - 2024-12-17 07:48:54 --> Security Class Initialized
DEBUG - 2024-12-17 07:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 07:48:54 --> Input Class Initialized
INFO - 2024-12-17 07:48:54 --> Language Class Initialized
INFO - 2024-12-17 07:48:54 --> Language Class Initialized
INFO - 2024-12-17 07:48:54 --> Config Class Initialized
INFO - 2024-12-17 07:48:54 --> Loader Class Initialized
INFO - 2024-12-17 07:48:54 --> Helper loaded: url_helper
INFO - 2024-12-17 07:48:54 --> Helper loaded: file_helper
INFO - 2024-12-17 07:48:54 --> Helper loaded: form_helper
INFO - 2024-12-17 07:48:54 --> Helper loaded: my_helper
INFO - 2024-12-17 07:48:54 --> Database Driver Class Initialized
INFO - 2024-12-17 07:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 07:48:54 --> Controller Class Initialized
DEBUG - 2024-12-17 07:48:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-17 07:48:57 --> Final output sent to browser
DEBUG - 2024-12-17 07:48:57 --> Total execution time: 3.3504
INFO - 2024-12-17 08:07:57 --> Config Class Initialized
INFO - 2024-12-17 08:07:57 --> Hooks Class Initialized
DEBUG - 2024-12-17 08:07:57 --> UTF-8 Support Enabled
INFO - 2024-12-17 08:07:57 --> Utf8 Class Initialized
INFO - 2024-12-17 08:07:57 --> URI Class Initialized
INFO - 2024-12-17 08:07:57 --> Router Class Initialized
INFO - 2024-12-17 08:07:57 --> Output Class Initialized
INFO - 2024-12-17 08:07:57 --> Security Class Initialized
DEBUG - 2024-12-17 08:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 08:07:57 --> Input Class Initialized
INFO - 2024-12-17 08:07:57 --> Language Class Initialized
INFO - 2024-12-17 08:07:57 --> Language Class Initialized
INFO - 2024-12-17 08:07:57 --> Config Class Initialized
INFO - 2024-12-17 08:07:57 --> Loader Class Initialized
INFO - 2024-12-17 08:07:57 --> Helper loaded: url_helper
INFO - 2024-12-17 08:07:57 --> Helper loaded: file_helper
INFO - 2024-12-17 08:07:57 --> Helper loaded: form_helper
INFO - 2024-12-17 08:07:57 --> Helper loaded: my_helper
INFO - 2024-12-17 08:07:57 --> Database Driver Class Initialized
INFO - 2024-12-17 08:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 08:07:57 --> Controller Class Initialized
INFO - 2024-12-17 08:07:57 --> Config Class Initialized
INFO - 2024-12-17 08:07:57 --> Hooks Class Initialized
DEBUG - 2024-12-17 08:07:57 --> UTF-8 Support Enabled
INFO - 2024-12-17 08:07:57 --> Utf8 Class Initialized
INFO - 2024-12-17 08:07:57 --> URI Class Initialized
INFO - 2024-12-17 08:07:57 --> Router Class Initialized
INFO - 2024-12-17 08:07:57 --> Output Class Initialized
INFO - 2024-12-17 08:07:57 --> Security Class Initialized
DEBUG - 2024-12-17 08:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 08:07:57 --> Input Class Initialized
INFO - 2024-12-17 08:07:57 --> Language Class Initialized
INFO - 2024-12-17 08:07:57 --> Language Class Initialized
INFO - 2024-12-17 08:07:57 --> Config Class Initialized
INFO - 2024-12-17 08:07:57 --> Loader Class Initialized
INFO - 2024-12-17 08:07:57 --> Helper loaded: url_helper
INFO - 2024-12-17 08:07:57 --> Helper loaded: file_helper
INFO - 2024-12-17 08:07:57 --> Helper loaded: form_helper
INFO - 2024-12-17 08:07:57 --> Helper loaded: my_helper
INFO - 2024-12-17 08:07:57 --> Database Driver Class Initialized
INFO - 2024-12-17 08:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 08:07:57 --> Controller Class Initialized
DEBUG - 2024-12-17 08:07:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-17 08:07:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 08:07:57 --> Final output sent to browser
DEBUG - 2024-12-17 08:07:57 --> Total execution time: 0.0814
INFO - 2024-12-17 08:07:59 --> Config Class Initialized
INFO - 2024-12-17 08:07:59 --> Hooks Class Initialized
DEBUG - 2024-12-17 08:07:59 --> UTF-8 Support Enabled
INFO - 2024-12-17 08:07:59 --> Utf8 Class Initialized
INFO - 2024-12-17 08:07:59 --> URI Class Initialized
INFO - 2024-12-17 08:07:59 --> Router Class Initialized
INFO - 2024-12-17 08:07:59 --> Output Class Initialized
INFO - 2024-12-17 08:07:59 --> Security Class Initialized
DEBUG - 2024-12-17 08:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 08:07:59 --> Input Class Initialized
INFO - 2024-12-17 08:07:59 --> Language Class Initialized
INFO - 2024-12-17 08:07:59 --> Language Class Initialized
INFO - 2024-12-17 08:07:59 --> Config Class Initialized
INFO - 2024-12-17 08:07:59 --> Loader Class Initialized
INFO - 2024-12-17 08:07:59 --> Helper loaded: url_helper
INFO - 2024-12-17 08:07:59 --> Helper loaded: file_helper
INFO - 2024-12-17 08:07:59 --> Helper loaded: form_helper
INFO - 2024-12-17 08:07:59 --> Helper loaded: my_helper
INFO - 2024-12-17 08:07:59 --> Database Driver Class Initialized
INFO - 2024-12-17 08:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 08:07:59 --> Controller Class Initialized
INFO - 2024-12-17 08:07:59 --> Helper loaded: cookie_helper
INFO - 2024-12-17 08:07:59 --> Final output sent to browser
DEBUG - 2024-12-17 08:07:59 --> Total execution time: 0.0941
INFO - 2024-12-17 08:07:59 --> Config Class Initialized
INFO - 2024-12-17 08:07:59 --> Hooks Class Initialized
DEBUG - 2024-12-17 08:07:59 --> UTF-8 Support Enabled
INFO - 2024-12-17 08:07:59 --> Utf8 Class Initialized
INFO - 2024-12-17 08:07:59 --> URI Class Initialized
INFO - 2024-12-17 08:07:59 --> Router Class Initialized
INFO - 2024-12-17 08:07:59 --> Output Class Initialized
INFO - 2024-12-17 08:07:59 --> Security Class Initialized
DEBUG - 2024-12-17 08:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 08:07:59 --> Input Class Initialized
INFO - 2024-12-17 08:07:59 --> Language Class Initialized
INFO - 2024-12-17 08:07:59 --> Language Class Initialized
INFO - 2024-12-17 08:07:59 --> Config Class Initialized
INFO - 2024-12-17 08:07:59 --> Loader Class Initialized
INFO - 2024-12-17 08:07:59 --> Helper loaded: url_helper
INFO - 2024-12-17 08:07:59 --> Helper loaded: file_helper
INFO - 2024-12-17 08:07:59 --> Helper loaded: form_helper
INFO - 2024-12-17 08:07:59 --> Helper loaded: my_helper
INFO - 2024-12-17 08:07:59 --> Database Driver Class Initialized
INFO - 2024-12-17 08:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 08:07:59 --> Controller Class Initialized
DEBUG - 2024-12-17 08:07:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-12-17 08:07:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 08:07:59 --> Final output sent to browser
DEBUG - 2024-12-17 08:07:59 --> Total execution time: 0.0863
INFO - 2024-12-17 08:09:24 --> Config Class Initialized
INFO - 2024-12-17 08:09:24 --> Hooks Class Initialized
DEBUG - 2024-12-17 08:09:24 --> UTF-8 Support Enabled
INFO - 2024-12-17 08:09:24 --> Utf8 Class Initialized
INFO - 2024-12-17 08:09:24 --> URI Class Initialized
INFO - 2024-12-17 08:09:24 --> Router Class Initialized
INFO - 2024-12-17 08:09:24 --> Output Class Initialized
INFO - 2024-12-17 08:09:24 --> Security Class Initialized
DEBUG - 2024-12-17 08:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 08:09:24 --> Input Class Initialized
INFO - 2024-12-17 08:09:24 --> Language Class Initialized
INFO - 2024-12-17 08:09:24 --> Language Class Initialized
INFO - 2024-12-17 08:09:24 --> Config Class Initialized
INFO - 2024-12-17 08:09:24 --> Loader Class Initialized
INFO - 2024-12-17 08:09:24 --> Helper loaded: url_helper
INFO - 2024-12-17 08:09:24 --> Helper loaded: file_helper
INFO - 2024-12-17 08:09:24 --> Helper loaded: form_helper
INFO - 2024-12-17 08:09:24 --> Helper loaded: my_helper
INFO - 2024-12-17 08:09:24 --> Database Driver Class Initialized
INFO - 2024-12-17 08:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 08:09:24 --> Controller Class Initialized
DEBUG - 2024-12-17 08:09:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-12-17 08:09:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 08:09:24 --> Final output sent to browser
DEBUG - 2024-12-17 08:09:24 --> Total execution time: 0.0577
INFO - 2024-12-17 08:09:28 --> Config Class Initialized
INFO - 2024-12-17 08:09:28 --> Hooks Class Initialized
DEBUG - 2024-12-17 08:09:28 --> UTF-8 Support Enabled
INFO - 2024-12-17 08:09:28 --> Utf8 Class Initialized
INFO - 2024-12-17 08:09:28 --> URI Class Initialized
INFO - 2024-12-17 08:09:28 --> Router Class Initialized
INFO - 2024-12-17 08:09:28 --> Output Class Initialized
INFO - 2024-12-17 08:09:28 --> Security Class Initialized
DEBUG - 2024-12-17 08:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 08:09:28 --> Input Class Initialized
INFO - 2024-12-17 08:09:28 --> Language Class Initialized
INFO - 2024-12-17 08:09:28 --> Language Class Initialized
INFO - 2024-12-17 08:09:28 --> Config Class Initialized
INFO - 2024-12-17 08:09:28 --> Loader Class Initialized
INFO - 2024-12-17 08:09:28 --> Helper loaded: url_helper
INFO - 2024-12-17 08:09:28 --> Helper loaded: file_helper
INFO - 2024-12-17 08:09:28 --> Helper loaded: form_helper
INFO - 2024-12-17 08:09:28 --> Helper loaded: my_helper
INFO - 2024-12-17 08:09:28 --> Database Driver Class Initialized
INFO - 2024-12-17 08:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 08:09:28 --> Controller Class Initialized
DEBUG - 2024-12-17 08:09:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2024-12-17 08:09:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 08:09:28 --> Final output sent to browser
DEBUG - 2024-12-17 08:09:28 --> Total execution time: 0.0329
INFO - 2024-12-17 08:09:30 --> Config Class Initialized
INFO - 2024-12-17 08:09:30 --> Hooks Class Initialized
DEBUG - 2024-12-17 08:09:30 --> UTF-8 Support Enabled
INFO - 2024-12-17 08:09:30 --> Utf8 Class Initialized
INFO - 2024-12-17 08:09:30 --> URI Class Initialized
INFO - 2024-12-17 08:09:30 --> Router Class Initialized
INFO - 2024-12-17 08:09:30 --> Output Class Initialized
INFO - 2024-12-17 08:09:30 --> Security Class Initialized
DEBUG - 2024-12-17 08:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 08:09:30 --> Input Class Initialized
INFO - 2024-12-17 08:09:30 --> Language Class Initialized
INFO - 2024-12-17 08:09:30 --> Language Class Initialized
INFO - 2024-12-17 08:09:30 --> Config Class Initialized
INFO - 2024-12-17 08:09:30 --> Loader Class Initialized
INFO - 2024-12-17 08:09:30 --> Helper loaded: url_helper
INFO - 2024-12-17 08:09:30 --> Helper loaded: file_helper
INFO - 2024-12-17 08:09:30 --> Helper loaded: form_helper
INFO - 2024-12-17 08:09:30 --> Helper loaded: my_helper
INFO - 2024-12-17 08:09:30 --> Database Driver Class Initialized
INFO - 2024-12-17 08:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 08:09:30 --> Controller Class Initialized
DEBUG - 2024-12-17 08:09:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-12-17 08:09:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 08:09:30 --> Final output sent to browser
DEBUG - 2024-12-17 08:09:30 --> Total execution time: 0.0424
INFO - 2024-12-17 08:09:32 --> Config Class Initialized
INFO - 2024-12-17 08:09:32 --> Hooks Class Initialized
DEBUG - 2024-12-17 08:09:32 --> UTF-8 Support Enabled
INFO - 2024-12-17 08:09:32 --> Utf8 Class Initialized
INFO - 2024-12-17 08:09:32 --> URI Class Initialized
INFO - 2024-12-17 08:09:32 --> Router Class Initialized
INFO - 2024-12-17 08:09:32 --> Output Class Initialized
INFO - 2024-12-17 08:09:32 --> Security Class Initialized
DEBUG - 2024-12-17 08:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 08:09:32 --> Input Class Initialized
INFO - 2024-12-17 08:09:32 --> Language Class Initialized
INFO - 2024-12-17 08:09:32 --> Language Class Initialized
INFO - 2024-12-17 08:09:32 --> Config Class Initialized
INFO - 2024-12-17 08:09:32 --> Loader Class Initialized
INFO - 2024-12-17 08:09:32 --> Helper loaded: url_helper
INFO - 2024-12-17 08:09:32 --> Helper loaded: file_helper
INFO - 2024-12-17 08:09:32 --> Helper loaded: form_helper
INFO - 2024-12-17 08:09:32 --> Helper loaded: my_helper
INFO - 2024-12-17 08:09:32 --> Database Driver Class Initialized
INFO - 2024-12-17 08:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 08:09:32 --> Controller Class Initialized
DEBUG - 2024-12-17 08:09:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_homeroom/views/list.php
DEBUG - 2024-12-17 08:09:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 08:09:32 --> Final output sent to browser
DEBUG - 2024-12-17 08:09:32 --> Total execution time: 0.0454
INFO - 2024-12-17 08:10:08 --> Config Class Initialized
INFO - 2024-12-17 08:10:08 --> Hooks Class Initialized
DEBUG - 2024-12-17 08:10:08 --> UTF-8 Support Enabled
INFO - 2024-12-17 08:10:08 --> Utf8 Class Initialized
INFO - 2024-12-17 08:10:08 --> URI Class Initialized
INFO - 2024-12-17 08:10:08 --> Router Class Initialized
INFO - 2024-12-17 08:10:08 --> Output Class Initialized
INFO - 2024-12-17 08:10:08 --> Security Class Initialized
DEBUG - 2024-12-17 08:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 08:10:08 --> Input Class Initialized
INFO - 2024-12-17 08:10:08 --> Language Class Initialized
INFO - 2024-12-17 08:10:08 --> Language Class Initialized
INFO - 2024-12-17 08:10:08 --> Config Class Initialized
INFO - 2024-12-17 08:10:08 --> Loader Class Initialized
INFO - 2024-12-17 08:10:08 --> Helper loaded: url_helper
INFO - 2024-12-17 08:10:08 --> Helper loaded: file_helper
INFO - 2024-12-17 08:10:08 --> Helper loaded: form_helper
INFO - 2024-12-17 08:10:08 --> Helper loaded: my_helper
INFO - 2024-12-17 08:10:08 --> Database Driver Class Initialized
INFO - 2024-12-17 08:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 08:10:08 --> Controller Class Initialized
INFO - 2024-12-17 08:10:09 --> Final output sent to browser
DEBUG - 2024-12-17 08:10:09 --> Total execution time: 1.4376
INFO - 2024-12-17 08:10:18 --> Config Class Initialized
INFO - 2024-12-17 08:10:18 --> Hooks Class Initialized
DEBUG - 2024-12-17 08:10:18 --> UTF-8 Support Enabled
INFO - 2024-12-17 08:10:18 --> Utf8 Class Initialized
INFO - 2024-12-17 08:10:18 --> URI Class Initialized
INFO - 2024-12-17 08:10:18 --> Router Class Initialized
INFO - 2024-12-17 08:10:18 --> Output Class Initialized
INFO - 2024-12-17 08:10:18 --> Security Class Initialized
DEBUG - 2024-12-17 08:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 08:10:18 --> Input Class Initialized
INFO - 2024-12-17 08:10:18 --> Language Class Initialized
INFO - 2024-12-17 08:10:18 --> Language Class Initialized
INFO - 2024-12-17 08:10:18 --> Config Class Initialized
INFO - 2024-12-17 08:10:18 --> Loader Class Initialized
INFO - 2024-12-17 08:10:18 --> Helper loaded: url_helper
INFO - 2024-12-17 08:10:18 --> Helper loaded: file_helper
INFO - 2024-12-17 08:10:18 --> Helper loaded: form_helper
INFO - 2024-12-17 08:10:18 --> Helper loaded: my_helper
INFO - 2024-12-17 08:10:18 --> Database Driver Class Initialized
INFO - 2024-12-17 08:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 08:10:18 --> Controller Class Initialized
DEBUG - 2024-12-17 08:10:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan/views/list.php
DEBUG - 2024-12-17 08:10:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 08:10:18 --> Final output sent to browser
DEBUG - 2024-12-17 08:10:18 --> Total execution time: 0.0479
INFO - 2024-12-17 08:31:22 --> Config Class Initialized
INFO - 2024-12-17 08:31:22 --> Hooks Class Initialized
DEBUG - 2024-12-17 08:31:22 --> UTF-8 Support Enabled
INFO - 2024-12-17 08:31:22 --> Utf8 Class Initialized
INFO - 2024-12-17 08:31:22 --> URI Class Initialized
INFO - 2024-12-17 08:31:22 --> Router Class Initialized
INFO - 2024-12-17 08:31:22 --> Output Class Initialized
INFO - 2024-12-17 08:31:22 --> Security Class Initialized
DEBUG - 2024-12-17 08:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 08:31:22 --> Input Class Initialized
INFO - 2024-12-17 08:31:22 --> Language Class Initialized
INFO - 2024-12-17 08:31:22 --> Language Class Initialized
INFO - 2024-12-17 08:31:22 --> Config Class Initialized
INFO - 2024-12-17 08:31:22 --> Loader Class Initialized
INFO - 2024-12-17 08:31:22 --> Helper loaded: url_helper
INFO - 2024-12-17 08:31:22 --> Helper loaded: file_helper
INFO - 2024-12-17 08:31:22 --> Helper loaded: form_helper
INFO - 2024-12-17 08:31:22 --> Helper loaded: my_helper
INFO - 2024-12-17 08:31:22 --> Database Driver Class Initialized
INFO - 2024-12-17 08:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 08:31:22 --> Controller Class Initialized
ERROR - 2024-12-17 08:31:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3898
DEBUG - 2024-12-17 08:31:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-12-17 08:31:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 08:31:22 --> Final output sent to browser
DEBUG - 2024-12-17 08:31:22 --> Total execution time: 0.0601
INFO - 2024-12-17 08:31:26 --> Config Class Initialized
INFO - 2024-12-17 08:31:26 --> Hooks Class Initialized
DEBUG - 2024-12-17 08:31:26 --> UTF-8 Support Enabled
INFO - 2024-12-17 08:31:26 --> Utf8 Class Initialized
INFO - 2024-12-17 08:31:26 --> URI Class Initialized
INFO - 2024-12-17 08:31:26 --> Router Class Initialized
INFO - 2024-12-17 08:31:26 --> Output Class Initialized
INFO - 2024-12-17 08:31:26 --> Security Class Initialized
DEBUG - 2024-12-17 08:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 08:31:26 --> Input Class Initialized
INFO - 2024-12-17 08:31:26 --> Language Class Initialized
INFO - 2024-12-17 08:31:26 --> Language Class Initialized
INFO - 2024-12-17 08:31:26 --> Config Class Initialized
INFO - 2024-12-17 08:31:26 --> Loader Class Initialized
INFO - 2024-12-17 08:31:26 --> Helper loaded: url_helper
INFO - 2024-12-17 08:31:26 --> Helper loaded: file_helper
INFO - 2024-12-17 08:31:26 --> Helper loaded: form_helper
INFO - 2024-12-17 08:31:26 --> Helper loaded: my_helper
INFO - 2024-12-17 08:31:26 --> Database Driver Class Initialized
INFO - 2024-12-17 08:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 08:31:26 --> Controller Class Initialized
ERROR - 2024-12-17 08:31:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3898
DEBUG - 2024-12-17 08:31:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-12-17 08:31:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 08:31:26 --> Final output sent to browser
DEBUG - 2024-12-17 08:31:26 --> Total execution time: 0.0481
INFO - 2024-12-17 08:31:33 --> Config Class Initialized
INFO - 2024-12-17 08:31:33 --> Hooks Class Initialized
DEBUG - 2024-12-17 08:31:33 --> UTF-8 Support Enabled
INFO - 2024-12-17 08:31:33 --> Utf8 Class Initialized
INFO - 2024-12-17 08:31:33 --> URI Class Initialized
DEBUG - 2024-12-17 08:31:33 --> No URI present. Default controller set.
INFO - 2024-12-17 08:31:33 --> Router Class Initialized
INFO - 2024-12-17 08:31:33 --> Output Class Initialized
INFO - 2024-12-17 08:31:33 --> Security Class Initialized
DEBUG - 2024-12-17 08:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 08:31:33 --> Input Class Initialized
INFO - 2024-12-17 08:31:33 --> Language Class Initialized
INFO - 2024-12-17 08:31:33 --> Language Class Initialized
INFO - 2024-12-17 08:31:33 --> Config Class Initialized
INFO - 2024-12-17 08:31:33 --> Loader Class Initialized
INFO - 2024-12-17 08:31:33 --> Helper loaded: url_helper
INFO - 2024-12-17 08:31:33 --> Helper loaded: file_helper
INFO - 2024-12-17 08:31:33 --> Helper loaded: form_helper
INFO - 2024-12-17 08:31:33 --> Helper loaded: my_helper
INFO - 2024-12-17 08:31:33 --> Database Driver Class Initialized
INFO - 2024-12-17 08:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 08:31:33 --> Controller Class Initialized
INFO - 2024-12-17 08:31:33 --> Config Class Initialized
INFO - 2024-12-17 08:31:33 --> Hooks Class Initialized
DEBUG - 2024-12-17 08:31:33 --> UTF-8 Support Enabled
INFO - 2024-12-17 08:31:33 --> Utf8 Class Initialized
INFO - 2024-12-17 08:31:33 --> URI Class Initialized
INFO - 2024-12-17 08:31:33 --> Router Class Initialized
INFO - 2024-12-17 08:31:33 --> Output Class Initialized
INFO - 2024-12-17 08:31:33 --> Security Class Initialized
DEBUG - 2024-12-17 08:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 08:31:33 --> Input Class Initialized
INFO - 2024-12-17 08:31:33 --> Language Class Initialized
INFO - 2024-12-17 08:31:33 --> Language Class Initialized
INFO - 2024-12-17 08:31:33 --> Config Class Initialized
INFO - 2024-12-17 08:31:33 --> Loader Class Initialized
INFO - 2024-12-17 08:31:33 --> Helper loaded: url_helper
INFO - 2024-12-17 08:31:33 --> Helper loaded: file_helper
INFO - 2024-12-17 08:31:33 --> Helper loaded: form_helper
INFO - 2024-12-17 08:31:33 --> Helper loaded: my_helper
INFO - 2024-12-17 08:31:33 --> Database Driver Class Initialized
INFO - 2024-12-17 08:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 08:31:33 --> Controller Class Initialized
DEBUG - 2024-12-17 08:31:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-17 08:31:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 08:31:33 --> Final output sent to browser
DEBUG - 2024-12-17 08:31:33 --> Total execution time: 0.0298
INFO - 2024-12-17 08:39:16 --> Config Class Initialized
INFO - 2024-12-17 08:39:16 --> Hooks Class Initialized
DEBUG - 2024-12-17 08:39:16 --> UTF-8 Support Enabled
INFO - 2024-12-17 08:39:16 --> Utf8 Class Initialized
INFO - 2024-12-17 08:39:16 --> URI Class Initialized
INFO - 2024-12-17 08:39:16 --> Router Class Initialized
INFO - 2024-12-17 08:39:16 --> Output Class Initialized
INFO - 2024-12-17 08:39:16 --> Security Class Initialized
DEBUG - 2024-12-17 08:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 08:39:16 --> Input Class Initialized
INFO - 2024-12-17 08:39:16 --> Language Class Initialized
INFO - 2024-12-17 08:39:16 --> Language Class Initialized
INFO - 2024-12-17 08:39:16 --> Config Class Initialized
INFO - 2024-12-17 08:39:16 --> Loader Class Initialized
INFO - 2024-12-17 08:39:16 --> Helper loaded: url_helper
INFO - 2024-12-17 08:39:16 --> Helper loaded: file_helper
INFO - 2024-12-17 08:39:16 --> Helper loaded: form_helper
INFO - 2024-12-17 08:39:16 --> Helper loaded: my_helper
INFO - 2024-12-17 08:39:16 --> Database Driver Class Initialized
INFO - 2024-12-17 08:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 08:39:16 --> Controller Class Initialized
INFO - 2024-12-17 08:39:16 --> Helper loaded: cookie_helper
INFO - 2024-12-17 08:39:16 --> Final output sent to browser
DEBUG - 2024-12-17 08:39:16 --> Total execution time: 0.0400
INFO - 2024-12-17 08:39:16 --> Config Class Initialized
INFO - 2024-12-17 08:39:16 --> Hooks Class Initialized
DEBUG - 2024-12-17 08:39:16 --> UTF-8 Support Enabled
INFO - 2024-12-17 08:39:16 --> Utf8 Class Initialized
INFO - 2024-12-17 08:39:16 --> URI Class Initialized
INFO - 2024-12-17 08:39:16 --> Router Class Initialized
INFO - 2024-12-17 08:39:16 --> Output Class Initialized
INFO - 2024-12-17 08:39:16 --> Security Class Initialized
DEBUG - 2024-12-17 08:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 08:39:16 --> Input Class Initialized
INFO - 2024-12-17 08:39:16 --> Language Class Initialized
INFO - 2024-12-17 08:39:16 --> Language Class Initialized
INFO - 2024-12-17 08:39:16 --> Config Class Initialized
INFO - 2024-12-17 08:39:16 --> Loader Class Initialized
INFO - 2024-12-17 08:39:16 --> Helper loaded: url_helper
INFO - 2024-12-17 08:39:16 --> Helper loaded: file_helper
INFO - 2024-12-17 08:39:16 --> Helper loaded: form_helper
INFO - 2024-12-17 08:39:16 --> Helper loaded: my_helper
INFO - 2024-12-17 08:39:16 --> Database Driver Class Initialized
INFO - 2024-12-17 08:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 08:39:16 --> Controller Class Initialized
DEBUG - 2024-12-17 08:39:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-12-17 08:39:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 08:39:16 --> Final output sent to browser
DEBUG - 2024-12-17 08:39:16 --> Total execution time: 0.0285
INFO - 2024-12-17 08:39:40 --> Config Class Initialized
INFO - 2024-12-17 08:39:40 --> Hooks Class Initialized
DEBUG - 2024-12-17 08:39:40 --> UTF-8 Support Enabled
INFO - 2024-12-17 08:39:40 --> Utf8 Class Initialized
INFO - 2024-12-17 08:39:40 --> URI Class Initialized
INFO - 2024-12-17 08:39:40 --> Router Class Initialized
INFO - 2024-12-17 08:39:40 --> Output Class Initialized
INFO - 2024-12-17 08:39:40 --> Security Class Initialized
DEBUG - 2024-12-17 08:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 08:39:40 --> Input Class Initialized
INFO - 2024-12-17 08:39:40 --> Language Class Initialized
INFO - 2024-12-17 08:39:40 --> Language Class Initialized
INFO - 2024-12-17 08:39:40 --> Config Class Initialized
INFO - 2024-12-17 08:39:40 --> Loader Class Initialized
INFO - 2024-12-17 08:39:40 --> Helper loaded: url_helper
INFO - 2024-12-17 08:39:40 --> Helper loaded: file_helper
INFO - 2024-12-17 08:39:40 --> Helper loaded: form_helper
INFO - 2024-12-17 08:39:40 --> Helper loaded: my_helper
INFO - 2024-12-17 08:39:40 --> Database Driver Class Initialized
INFO - 2024-12-17 08:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 08:39:40 --> Controller Class Initialized
DEBUG - 2024-12-17 08:39:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-12-17 08:39:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 08:39:40 --> Final output sent to browser
DEBUG - 2024-12-17 08:39:40 --> Total execution time: 0.0374
INFO - 2024-12-17 09:22:27 --> Config Class Initialized
INFO - 2024-12-17 09:22:27 --> Hooks Class Initialized
DEBUG - 2024-12-17 09:22:27 --> UTF-8 Support Enabled
INFO - 2024-12-17 09:22:27 --> Utf8 Class Initialized
INFO - 2024-12-17 09:22:27 --> URI Class Initialized
INFO - 2024-12-17 09:22:27 --> Router Class Initialized
INFO - 2024-12-17 09:22:27 --> Output Class Initialized
INFO - 2024-12-17 09:22:27 --> Security Class Initialized
DEBUG - 2024-12-17 09:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 09:22:27 --> Input Class Initialized
INFO - 2024-12-17 09:22:27 --> Language Class Initialized
INFO - 2024-12-17 09:22:27 --> Language Class Initialized
INFO - 2024-12-17 09:22:27 --> Config Class Initialized
INFO - 2024-12-17 09:22:27 --> Loader Class Initialized
INFO - 2024-12-17 09:22:27 --> Helper loaded: url_helper
INFO - 2024-12-17 09:22:27 --> Helper loaded: file_helper
INFO - 2024-12-17 09:22:27 --> Helper loaded: form_helper
INFO - 2024-12-17 09:22:27 --> Helper loaded: my_helper
INFO - 2024-12-17 09:22:27 --> Database Driver Class Initialized
INFO - 2024-12-17 09:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 09:22:27 --> Controller Class Initialized
DEBUG - 2024-12-17 09:22:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-17 09:22:29 --> Final output sent to browser
DEBUG - 2024-12-17 09:22:29 --> Total execution time: 2.1329
INFO - 2024-12-17 09:23:36 --> Config Class Initialized
INFO - 2024-12-17 09:23:36 --> Hooks Class Initialized
DEBUG - 2024-12-17 09:23:36 --> UTF-8 Support Enabled
INFO - 2024-12-17 09:23:36 --> Utf8 Class Initialized
INFO - 2024-12-17 09:23:36 --> URI Class Initialized
INFO - 2024-12-17 09:23:36 --> Router Class Initialized
INFO - 2024-12-17 09:23:36 --> Output Class Initialized
INFO - 2024-12-17 09:23:36 --> Security Class Initialized
DEBUG - 2024-12-17 09:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 09:23:36 --> Input Class Initialized
INFO - 2024-12-17 09:23:36 --> Language Class Initialized
INFO - 2024-12-17 09:23:36 --> Language Class Initialized
INFO - 2024-12-17 09:23:36 --> Config Class Initialized
INFO - 2024-12-17 09:23:36 --> Loader Class Initialized
INFO - 2024-12-17 09:23:36 --> Helper loaded: url_helper
INFO - 2024-12-17 09:23:36 --> Helper loaded: file_helper
INFO - 2024-12-17 09:23:36 --> Helper loaded: form_helper
INFO - 2024-12-17 09:23:36 --> Helper loaded: my_helper
INFO - 2024-12-17 09:23:36 --> Database Driver Class Initialized
INFO - 2024-12-17 09:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 09:23:36 --> Controller Class Initialized
DEBUG - 2024-12-17 09:23:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 09:23:41 --> Final output sent to browser
DEBUG - 2024-12-17 09:23:41 --> Total execution time: 5.6319
INFO - 2024-12-17 09:25:17 --> Config Class Initialized
INFO - 2024-12-17 09:25:17 --> Hooks Class Initialized
DEBUG - 2024-12-17 09:25:17 --> UTF-8 Support Enabled
INFO - 2024-12-17 09:25:17 --> Utf8 Class Initialized
INFO - 2024-12-17 09:25:17 --> URI Class Initialized
INFO - 2024-12-17 09:25:17 --> Router Class Initialized
INFO - 2024-12-17 09:25:17 --> Output Class Initialized
INFO - 2024-12-17 09:25:17 --> Security Class Initialized
DEBUG - 2024-12-17 09:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 09:25:17 --> Input Class Initialized
INFO - 2024-12-17 09:25:17 --> Language Class Initialized
INFO - 2024-12-17 09:25:17 --> Language Class Initialized
INFO - 2024-12-17 09:25:17 --> Config Class Initialized
INFO - 2024-12-17 09:25:17 --> Loader Class Initialized
INFO - 2024-12-17 09:25:17 --> Helper loaded: url_helper
INFO - 2024-12-17 09:25:17 --> Helper loaded: file_helper
INFO - 2024-12-17 09:25:17 --> Helper loaded: form_helper
INFO - 2024-12-17 09:25:17 --> Helper loaded: my_helper
INFO - 2024-12-17 09:25:17 --> Database Driver Class Initialized
INFO - 2024-12-17 09:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 09:25:17 --> Controller Class Initialized
DEBUG - 2024-12-17 09:25:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-17 09:25:21 --> Final output sent to browser
DEBUG - 2024-12-17 09:25:21 --> Total execution time: 4.1830
INFO - 2024-12-17 09:29:40 --> Config Class Initialized
INFO - 2024-12-17 09:29:40 --> Hooks Class Initialized
DEBUG - 2024-12-17 09:29:40 --> UTF-8 Support Enabled
INFO - 2024-12-17 09:29:40 --> Utf8 Class Initialized
INFO - 2024-12-17 09:29:40 --> URI Class Initialized
INFO - 2024-12-17 09:29:40 --> Router Class Initialized
INFO - 2024-12-17 09:29:40 --> Output Class Initialized
INFO - 2024-12-17 09:29:40 --> Security Class Initialized
DEBUG - 2024-12-17 09:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 09:29:40 --> Input Class Initialized
INFO - 2024-12-17 09:29:40 --> Language Class Initialized
INFO - 2024-12-17 09:29:40 --> Language Class Initialized
INFO - 2024-12-17 09:29:40 --> Config Class Initialized
INFO - 2024-12-17 09:29:40 --> Loader Class Initialized
INFO - 2024-12-17 09:29:40 --> Helper loaded: url_helper
INFO - 2024-12-17 09:29:40 --> Helper loaded: file_helper
INFO - 2024-12-17 09:29:40 --> Helper loaded: form_helper
INFO - 2024-12-17 09:29:40 --> Helper loaded: my_helper
INFO - 2024-12-17 09:29:40 --> Database Driver Class Initialized
INFO - 2024-12-17 09:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 09:29:40 --> Controller Class Initialized
DEBUG - 2024-12-17 09:29:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-17 09:29:42 --> Final output sent to browser
DEBUG - 2024-12-17 09:29:42 --> Total execution time: 2.0161
INFO - 2024-12-17 09:33:33 --> Config Class Initialized
INFO - 2024-12-17 09:33:33 --> Hooks Class Initialized
DEBUG - 2024-12-17 09:33:33 --> UTF-8 Support Enabled
INFO - 2024-12-17 09:33:33 --> Utf8 Class Initialized
INFO - 2024-12-17 09:33:33 --> URI Class Initialized
INFO - 2024-12-17 09:33:33 --> Router Class Initialized
INFO - 2024-12-17 09:33:33 --> Output Class Initialized
INFO - 2024-12-17 09:33:34 --> Security Class Initialized
DEBUG - 2024-12-17 09:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 09:33:34 --> Input Class Initialized
INFO - 2024-12-17 09:33:34 --> Language Class Initialized
INFO - 2024-12-17 09:33:34 --> Language Class Initialized
INFO - 2024-12-17 09:33:34 --> Config Class Initialized
INFO - 2024-12-17 09:33:34 --> Loader Class Initialized
INFO - 2024-12-17 09:33:34 --> Helper loaded: url_helper
INFO - 2024-12-17 09:33:34 --> Helper loaded: file_helper
INFO - 2024-12-17 09:33:34 --> Helper loaded: form_helper
INFO - 2024-12-17 09:33:34 --> Helper loaded: my_helper
INFO - 2024-12-17 09:33:34 --> Database Driver Class Initialized
INFO - 2024-12-17 09:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 09:33:34 --> Controller Class Initialized
DEBUG - 2024-12-17 09:33:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 09:33:38 --> Final output sent to browser
DEBUG - 2024-12-17 09:33:38 --> Total execution time: 4.8558
INFO - 2024-12-17 09:36:21 --> Config Class Initialized
INFO - 2024-12-17 09:36:21 --> Hooks Class Initialized
DEBUG - 2024-12-17 09:36:21 --> UTF-8 Support Enabled
INFO - 2024-12-17 09:36:21 --> Utf8 Class Initialized
INFO - 2024-12-17 09:36:21 --> URI Class Initialized
INFO - 2024-12-17 09:36:21 --> Router Class Initialized
INFO - 2024-12-17 09:36:21 --> Output Class Initialized
INFO - 2024-12-17 09:36:21 --> Security Class Initialized
DEBUG - 2024-12-17 09:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 09:36:21 --> Input Class Initialized
INFO - 2024-12-17 09:36:21 --> Language Class Initialized
INFO - 2024-12-17 09:36:21 --> Language Class Initialized
INFO - 2024-12-17 09:36:21 --> Config Class Initialized
INFO - 2024-12-17 09:36:21 --> Loader Class Initialized
INFO - 2024-12-17 09:36:21 --> Helper loaded: url_helper
INFO - 2024-12-17 09:36:21 --> Helper loaded: file_helper
INFO - 2024-12-17 09:36:21 --> Helper loaded: form_helper
INFO - 2024-12-17 09:36:21 --> Helper loaded: my_helper
INFO - 2024-12-17 09:36:21 --> Database Driver Class Initialized
INFO - 2024-12-17 09:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 09:36:21 --> Controller Class Initialized
DEBUG - 2024-12-17 09:36:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-17 09:36:27 --> Final output sent to browser
DEBUG - 2024-12-17 09:36:27 --> Total execution time: 5.8833
INFO - 2024-12-17 09:42:21 --> Config Class Initialized
INFO - 2024-12-17 09:42:21 --> Hooks Class Initialized
DEBUG - 2024-12-17 09:42:21 --> UTF-8 Support Enabled
INFO - 2024-12-17 09:42:21 --> Utf8 Class Initialized
INFO - 2024-12-17 09:42:21 --> URI Class Initialized
INFO - 2024-12-17 09:42:21 --> Router Class Initialized
INFO - 2024-12-17 09:42:21 --> Output Class Initialized
INFO - 2024-12-17 09:42:21 --> Security Class Initialized
DEBUG - 2024-12-17 09:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 09:42:21 --> Input Class Initialized
INFO - 2024-12-17 09:42:21 --> Language Class Initialized
INFO - 2024-12-17 09:42:21 --> Language Class Initialized
INFO - 2024-12-17 09:42:21 --> Config Class Initialized
INFO - 2024-12-17 09:42:21 --> Loader Class Initialized
INFO - 2024-12-17 09:42:21 --> Helper loaded: url_helper
INFO - 2024-12-17 09:42:21 --> Helper loaded: file_helper
INFO - 2024-12-17 09:42:21 --> Helper loaded: form_helper
INFO - 2024-12-17 09:42:21 --> Helper loaded: my_helper
INFO - 2024-12-17 09:42:21 --> Database Driver Class Initialized
INFO - 2024-12-17 09:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 09:42:21 --> Controller Class Initialized
DEBUG - 2024-12-17 09:42:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-17 09:42:23 --> Final output sent to browser
DEBUG - 2024-12-17 09:42:23 --> Total execution time: 2.2670
INFO - 2024-12-17 09:43:55 --> Config Class Initialized
INFO - 2024-12-17 09:43:55 --> Hooks Class Initialized
DEBUG - 2024-12-17 09:43:55 --> UTF-8 Support Enabled
INFO - 2024-12-17 09:43:55 --> Utf8 Class Initialized
INFO - 2024-12-17 09:43:55 --> URI Class Initialized
INFO - 2024-12-17 09:43:55 --> Router Class Initialized
INFO - 2024-12-17 09:43:55 --> Output Class Initialized
INFO - 2024-12-17 09:43:55 --> Security Class Initialized
DEBUG - 2024-12-17 09:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 09:43:55 --> Input Class Initialized
INFO - 2024-12-17 09:43:55 --> Language Class Initialized
INFO - 2024-12-17 09:43:55 --> Language Class Initialized
INFO - 2024-12-17 09:43:55 --> Config Class Initialized
INFO - 2024-12-17 09:43:55 --> Loader Class Initialized
INFO - 2024-12-17 09:43:55 --> Helper loaded: url_helper
INFO - 2024-12-17 09:43:55 --> Helper loaded: file_helper
INFO - 2024-12-17 09:43:55 --> Helper loaded: form_helper
INFO - 2024-12-17 09:43:55 --> Helper loaded: my_helper
INFO - 2024-12-17 09:43:55 --> Database Driver Class Initialized
INFO - 2024-12-17 09:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 09:43:55 --> Controller Class Initialized
DEBUG - 2024-12-17 09:43:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 09:43:59 --> Final output sent to browser
DEBUG - 2024-12-17 09:43:59 --> Total execution time: 4.6912
INFO - 2024-12-17 09:48:36 --> Config Class Initialized
INFO - 2024-12-17 09:48:36 --> Hooks Class Initialized
DEBUG - 2024-12-17 09:48:36 --> UTF-8 Support Enabled
INFO - 2024-12-17 09:48:36 --> Utf8 Class Initialized
INFO - 2024-12-17 09:48:36 --> URI Class Initialized
INFO - 2024-12-17 09:48:36 --> Router Class Initialized
INFO - 2024-12-17 09:48:36 --> Output Class Initialized
INFO - 2024-12-17 09:48:36 --> Security Class Initialized
DEBUG - 2024-12-17 09:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 09:48:36 --> Input Class Initialized
INFO - 2024-12-17 09:48:36 --> Language Class Initialized
INFO - 2024-12-17 09:48:36 --> Language Class Initialized
INFO - 2024-12-17 09:48:36 --> Config Class Initialized
INFO - 2024-12-17 09:48:36 --> Loader Class Initialized
INFO - 2024-12-17 09:48:36 --> Helper loaded: url_helper
INFO - 2024-12-17 09:48:36 --> Helper loaded: file_helper
INFO - 2024-12-17 09:48:36 --> Helper loaded: form_helper
INFO - 2024-12-17 09:48:36 --> Helper loaded: my_helper
INFO - 2024-12-17 09:48:36 --> Database Driver Class Initialized
INFO - 2024-12-17 09:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 09:48:36 --> Controller Class Initialized
DEBUG - 2024-12-17 09:48:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-17 09:48:40 --> Final output sent to browser
DEBUG - 2024-12-17 09:48:40 --> Total execution time: 3.9061
INFO - 2024-12-17 09:49:33 --> Config Class Initialized
INFO - 2024-12-17 09:49:33 --> Hooks Class Initialized
DEBUG - 2024-12-17 09:49:33 --> UTF-8 Support Enabled
INFO - 2024-12-17 09:49:33 --> Utf8 Class Initialized
INFO - 2024-12-17 09:49:33 --> URI Class Initialized
INFO - 2024-12-17 09:49:33 --> Router Class Initialized
INFO - 2024-12-17 09:49:33 --> Output Class Initialized
INFO - 2024-12-17 09:49:33 --> Security Class Initialized
DEBUG - 2024-12-17 09:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 09:49:33 --> Input Class Initialized
INFO - 2024-12-17 09:49:33 --> Language Class Initialized
INFO - 2024-12-17 09:49:33 --> Language Class Initialized
INFO - 2024-12-17 09:49:33 --> Config Class Initialized
INFO - 2024-12-17 09:49:33 --> Loader Class Initialized
INFO - 2024-12-17 09:49:33 --> Helper loaded: url_helper
INFO - 2024-12-17 09:49:33 --> Helper loaded: file_helper
INFO - 2024-12-17 09:49:33 --> Helper loaded: form_helper
INFO - 2024-12-17 09:49:33 --> Helper loaded: my_helper
INFO - 2024-12-17 09:49:33 --> Database Driver Class Initialized
INFO - 2024-12-17 09:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 09:49:33 --> Controller Class Initialized
DEBUG - 2024-12-17 09:49:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-17 09:49:35 --> Final output sent to browser
DEBUG - 2024-12-17 09:49:35 --> Total execution time: 1.9895
INFO - 2024-12-17 09:50:26 --> Config Class Initialized
INFO - 2024-12-17 09:50:26 --> Hooks Class Initialized
DEBUG - 2024-12-17 09:50:26 --> UTF-8 Support Enabled
INFO - 2024-12-17 09:50:26 --> Utf8 Class Initialized
INFO - 2024-12-17 09:50:26 --> URI Class Initialized
INFO - 2024-12-17 09:50:26 --> Router Class Initialized
INFO - 2024-12-17 09:50:26 --> Output Class Initialized
INFO - 2024-12-17 09:50:26 --> Security Class Initialized
DEBUG - 2024-12-17 09:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 09:50:26 --> Input Class Initialized
INFO - 2024-12-17 09:50:26 --> Language Class Initialized
INFO - 2024-12-17 09:50:26 --> Language Class Initialized
INFO - 2024-12-17 09:50:26 --> Config Class Initialized
INFO - 2024-12-17 09:50:26 --> Loader Class Initialized
INFO - 2024-12-17 09:50:26 --> Helper loaded: url_helper
INFO - 2024-12-17 09:50:26 --> Helper loaded: file_helper
INFO - 2024-12-17 09:50:26 --> Helper loaded: form_helper
INFO - 2024-12-17 09:50:26 --> Helper loaded: my_helper
INFO - 2024-12-17 09:50:26 --> Database Driver Class Initialized
INFO - 2024-12-17 09:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 09:50:26 --> Controller Class Initialized
DEBUG - 2024-12-17 09:50:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 09:50:32 --> Final output sent to browser
DEBUG - 2024-12-17 09:50:32 --> Total execution time: 5.9204
INFO - 2024-12-17 09:52:07 --> Config Class Initialized
INFO - 2024-12-17 09:52:07 --> Hooks Class Initialized
DEBUG - 2024-12-17 09:52:07 --> UTF-8 Support Enabled
INFO - 2024-12-17 09:52:07 --> Utf8 Class Initialized
INFO - 2024-12-17 09:52:07 --> URI Class Initialized
INFO - 2024-12-17 09:52:07 --> Router Class Initialized
INFO - 2024-12-17 09:52:07 --> Output Class Initialized
INFO - 2024-12-17 09:52:07 --> Security Class Initialized
DEBUG - 2024-12-17 09:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 09:52:07 --> Input Class Initialized
INFO - 2024-12-17 09:52:07 --> Language Class Initialized
INFO - 2024-12-17 09:52:07 --> Language Class Initialized
INFO - 2024-12-17 09:52:07 --> Config Class Initialized
INFO - 2024-12-17 09:52:07 --> Loader Class Initialized
INFO - 2024-12-17 09:52:07 --> Helper loaded: url_helper
INFO - 2024-12-17 09:52:07 --> Helper loaded: file_helper
INFO - 2024-12-17 09:52:07 --> Helper loaded: form_helper
INFO - 2024-12-17 09:52:07 --> Helper loaded: my_helper
INFO - 2024-12-17 09:52:07 --> Database Driver Class Initialized
INFO - 2024-12-17 09:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 09:52:07 --> Controller Class Initialized
DEBUG - 2024-12-17 09:52:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-17 09:52:11 --> Final output sent to browser
DEBUG - 2024-12-17 09:52:11 --> Total execution time: 4.2873
INFO - 2024-12-17 09:56:16 --> Config Class Initialized
INFO - 2024-12-17 09:56:16 --> Hooks Class Initialized
DEBUG - 2024-12-17 09:56:16 --> UTF-8 Support Enabled
INFO - 2024-12-17 09:56:16 --> Utf8 Class Initialized
INFO - 2024-12-17 09:56:16 --> URI Class Initialized
INFO - 2024-12-17 09:56:16 --> Router Class Initialized
INFO - 2024-12-17 09:56:16 --> Output Class Initialized
INFO - 2024-12-17 09:56:16 --> Security Class Initialized
DEBUG - 2024-12-17 09:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 09:56:16 --> Input Class Initialized
INFO - 2024-12-17 09:56:16 --> Language Class Initialized
INFO - 2024-12-17 09:56:16 --> Language Class Initialized
INFO - 2024-12-17 09:56:16 --> Config Class Initialized
INFO - 2024-12-17 09:56:16 --> Loader Class Initialized
INFO - 2024-12-17 09:56:16 --> Helper loaded: url_helper
INFO - 2024-12-17 09:56:16 --> Helper loaded: file_helper
INFO - 2024-12-17 09:56:16 --> Helper loaded: form_helper
INFO - 2024-12-17 09:56:16 --> Helper loaded: my_helper
INFO - 2024-12-17 09:56:16 --> Database Driver Class Initialized
INFO - 2024-12-17 09:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 09:56:16 --> Controller Class Initialized
DEBUG - 2024-12-17 09:56:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-17 09:56:18 --> Final output sent to browser
DEBUG - 2024-12-17 09:56:18 --> Total execution time: 2.1001
INFO - 2024-12-17 10:01:07 --> Config Class Initialized
INFO - 2024-12-17 10:01:07 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:01:07 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:01:07 --> Utf8 Class Initialized
INFO - 2024-12-17 10:01:07 --> URI Class Initialized
INFO - 2024-12-17 10:01:07 --> Router Class Initialized
INFO - 2024-12-17 10:01:07 --> Output Class Initialized
INFO - 2024-12-17 10:01:07 --> Security Class Initialized
DEBUG - 2024-12-17 10:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:01:07 --> Input Class Initialized
INFO - 2024-12-17 10:01:07 --> Language Class Initialized
INFO - 2024-12-17 10:01:07 --> Language Class Initialized
INFO - 2024-12-17 10:01:07 --> Config Class Initialized
INFO - 2024-12-17 10:01:07 --> Loader Class Initialized
INFO - 2024-12-17 10:01:07 --> Helper loaded: url_helper
INFO - 2024-12-17 10:01:07 --> Helper loaded: file_helper
INFO - 2024-12-17 10:01:07 --> Helper loaded: form_helper
INFO - 2024-12-17 10:01:07 --> Helper loaded: my_helper
INFO - 2024-12-17 10:01:07 --> Database Driver Class Initialized
INFO - 2024-12-17 10:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:01:07 --> Controller Class Initialized
DEBUG - 2024-12-17 10:01:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 10:01:12 --> Final output sent to browser
DEBUG - 2024-12-17 10:01:12 --> Total execution time: 5.6602
INFO - 2024-12-17 10:01:28 --> Config Class Initialized
INFO - 2024-12-17 10:01:28 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:01:28 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:01:28 --> Utf8 Class Initialized
INFO - 2024-12-17 10:01:28 --> URI Class Initialized
INFO - 2024-12-17 10:01:28 --> Router Class Initialized
INFO - 2024-12-17 10:01:28 --> Output Class Initialized
INFO - 2024-12-17 10:01:28 --> Security Class Initialized
DEBUG - 2024-12-17 10:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:01:28 --> Input Class Initialized
INFO - 2024-12-17 10:01:28 --> Language Class Initialized
INFO - 2024-12-17 10:01:28 --> Language Class Initialized
INFO - 2024-12-17 10:01:28 --> Config Class Initialized
INFO - 2024-12-17 10:01:28 --> Loader Class Initialized
INFO - 2024-12-17 10:01:28 --> Helper loaded: url_helper
INFO - 2024-12-17 10:01:28 --> Helper loaded: file_helper
INFO - 2024-12-17 10:01:28 --> Helper loaded: form_helper
INFO - 2024-12-17 10:01:28 --> Helper loaded: my_helper
INFO - 2024-12-17 10:01:28 --> Database Driver Class Initialized
INFO - 2024-12-17 10:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:01:28 --> Controller Class Initialized
DEBUG - 2024-12-17 10:01:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-17 10:01:33 --> Final output sent to browser
DEBUG - 2024-12-17 10:01:33 --> Total execution time: 4.6299
INFO - 2024-12-17 10:04:06 --> Config Class Initialized
INFO - 2024-12-17 10:04:06 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:04:06 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:04:06 --> Utf8 Class Initialized
INFO - 2024-12-17 10:04:06 --> URI Class Initialized
INFO - 2024-12-17 10:04:06 --> Router Class Initialized
INFO - 2024-12-17 10:04:06 --> Output Class Initialized
INFO - 2024-12-17 10:04:06 --> Security Class Initialized
DEBUG - 2024-12-17 10:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:04:06 --> Input Class Initialized
INFO - 2024-12-17 10:04:06 --> Language Class Initialized
INFO - 2024-12-17 10:04:06 --> Language Class Initialized
INFO - 2024-12-17 10:04:06 --> Config Class Initialized
INFO - 2024-12-17 10:04:06 --> Loader Class Initialized
INFO - 2024-12-17 10:04:06 --> Helper loaded: url_helper
INFO - 2024-12-17 10:04:06 --> Helper loaded: file_helper
INFO - 2024-12-17 10:04:06 --> Helper loaded: form_helper
INFO - 2024-12-17 10:04:06 --> Helper loaded: my_helper
INFO - 2024-12-17 10:04:06 --> Database Driver Class Initialized
INFO - 2024-12-17 10:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:04:06 --> Controller Class Initialized
DEBUG - 2024-12-17 10:04:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-17 10:04:09 --> Final output sent to browser
DEBUG - 2024-12-17 10:04:09 --> Total execution time: 2.7307
INFO - 2024-12-17 10:04:27 --> Config Class Initialized
INFO - 2024-12-17 10:04:27 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:04:27 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:04:27 --> Utf8 Class Initialized
INFO - 2024-12-17 10:04:27 --> URI Class Initialized
INFO - 2024-12-17 10:04:27 --> Router Class Initialized
INFO - 2024-12-17 10:04:27 --> Output Class Initialized
INFO - 2024-12-17 10:04:27 --> Security Class Initialized
DEBUG - 2024-12-17 10:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:04:27 --> Input Class Initialized
INFO - 2024-12-17 10:04:27 --> Language Class Initialized
INFO - 2024-12-17 10:04:27 --> Language Class Initialized
INFO - 2024-12-17 10:04:27 --> Config Class Initialized
INFO - 2024-12-17 10:04:27 --> Loader Class Initialized
INFO - 2024-12-17 10:04:27 --> Helper loaded: url_helper
INFO - 2024-12-17 10:04:27 --> Helper loaded: file_helper
INFO - 2024-12-17 10:04:27 --> Helper loaded: form_helper
INFO - 2024-12-17 10:04:27 --> Helper loaded: my_helper
INFO - 2024-12-17 10:04:27 --> Database Driver Class Initialized
INFO - 2024-12-17 10:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:04:27 --> Controller Class Initialized
DEBUG - 2024-12-17 10:04:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 10:04:37 --> Final output sent to browser
DEBUG - 2024-12-17 10:04:37 --> Total execution time: 9.8407
INFO - 2024-12-17 10:07:00 --> Config Class Initialized
INFO - 2024-12-17 10:07:00 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:07:00 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:07:00 --> Utf8 Class Initialized
INFO - 2024-12-17 10:07:00 --> URI Class Initialized
INFO - 2024-12-17 10:07:00 --> Router Class Initialized
INFO - 2024-12-17 10:07:00 --> Output Class Initialized
INFO - 2024-12-17 10:07:00 --> Security Class Initialized
DEBUG - 2024-12-17 10:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:07:00 --> Input Class Initialized
INFO - 2024-12-17 10:07:00 --> Language Class Initialized
INFO - 2024-12-17 10:07:00 --> Language Class Initialized
INFO - 2024-12-17 10:07:00 --> Config Class Initialized
INFO - 2024-12-17 10:07:00 --> Loader Class Initialized
INFO - 2024-12-17 10:07:00 --> Helper loaded: url_helper
INFO - 2024-12-17 10:07:00 --> Helper loaded: file_helper
INFO - 2024-12-17 10:07:00 --> Helper loaded: form_helper
INFO - 2024-12-17 10:07:00 --> Helper loaded: my_helper
INFO - 2024-12-17 10:07:00 --> Database Driver Class Initialized
INFO - 2024-12-17 10:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:07:00 --> Controller Class Initialized
DEBUG - 2024-12-17 10:07:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-17 10:07:05 --> Final output sent to browser
DEBUG - 2024-12-17 10:07:05 --> Total execution time: 4.7395
INFO - 2024-12-17 10:10:05 --> Config Class Initialized
INFO - 2024-12-17 10:10:05 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:10:05 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:10:05 --> Utf8 Class Initialized
INFO - 2024-12-17 10:10:05 --> URI Class Initialized
INFO - 2024-12-17 10:10:05 --> Router Class Initialized
INFO - 2024-12-17 10:10:05 --> Output Class Initialized
INFO - 2024-12-17 10:10:05 --> Security Class Initialized
DEBUG - 2024-12-17 10:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:10:05 --> Input Class Initialized
INFO - 2024-12-17 10:10:05 --> Language Class Initialized
INFO - 2024-12-17 10:10:05 --> Language Class Initialized
INFO - 2024-12-17 10:10:05 --> Config Class Initialized
INFO - 2024-12-17 10:10:05 --> Loader Class Initialized
INFO - 2024-12-17 10:10:05 --> Helper loaded: url_helper
INFO - 2024-12-17 10:10:05 --> Helper loaded: file_helper
INFO - 2024-12-17 10:10:05 --> Helper loaded: form_helper
INFO - 2024-12-17 10:10:05 --> Helper loaded: my_helper
INFO - 2024-12-17 10:10:05 --> Database Driver Class Initialized
INFO - 2024-12-17 10:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:10:05 --> Controller Class Initialized
DEBUG - 2024-12-17 10:10:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-17 10:10:11 --> Final output sent to browser
DEBUG - 2024-12-17 10:10:11 --> Total execution time: 5.9087
INFO - 2024-12-17 10:37:15 --> Config Class Initialized
INFO - 2024-12-17 10:37:15 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:37:15 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:37:15 --> Utf8 Class Initialized
INFO - 2024-12-17 10:37:15 --> URI Class Initialized
INFO - 2024-12-17 10:37:15 --> Router Class Initialized
INFO - 2024-12-17 10:37:15 --> Output Class Initialized
INFO - 2024-12-17 10:37:15 --> Security Class Initialized
DEBUG - 2024-12-17 10:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:37:15 --> Input Class Initialized
INFO - 2024-12-17 10:37:15 --> Language Class Initialized
INFO - 2024-12-17 10:37:15 --> Language Class Initialized
INFO - 2024-12-17 10:37:15 --> Config Class Initialized
INFO - 2024-12-17 10:37:15 --> Loader Class Initialized
INFO - 2024-12-17 10:37:15 --> Helper loaded: url_helper
INFO - 2024-12-17 10:37:15 --> Helper loaded: file_helper
INFO - 2024-12-17 10:37:15 --> Helper loaded: form_helper
INFO - 2024-12-17 10:37:15 --> Helper loaded: my_helper
INFO - 2024-12-17 10:37:15 --> Database Driver Class Initialized
INFO - 2024-12-17 10:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:37:15 --> Controller Class Initialized
INFO - 2024-12-17 10:37:15 --> Final output sent to browser
DEBUG - 2024-12-17 10:37:15 --> Total execution time: 0.0650
INFO - 2024-12-17 10:37:33 --> Config Class Initialized
INFO - 2024-12-17 10:37:33 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:37:33 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:37:33 --> Utf8 Class Initialized
INFO - 2024-12-17 10:37:33 --> URI Class Initialized
DEBUG - 2024-12-17 10:37:33 --> No URI present. Default controller set.
INFO - 2024-12-17 10:37:33 --> Router Class Initialized
INFO - 2024-12-17 10:37:33 --> Output Class Initialized
INFO - 2024-12-17 10:37:33 --> Security Class Initialized
DEBUG - 2024-12-17 10:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:37:33 --> Input Class Initialized
INFO - 2024-12-17 10:37:33 --> Language Class Initialized
INFO - 2024-12-17 10:37:33 --> Language Class Initialized
INFO - 2024-12-17 10:37:33 --> Config Class Initialized
INFO - 2024-12-17 10:37:33 --> Loader Class Initialized
INFO - 2024-12-17 10:37:33 --> Helper loaded: url_helper
INFO - 2024-12-17 10:37:33 --> Helper loaded: file_helper
INFO - 2024-12-17 10:37:33 --> Helper loaded: form_helper
INFO - 2024-12-17 10:37:33 --> Helper loaded: my_helper
INFO - 2024-12-17 10:37:33 --> Database Driver Class Initialized
INFO - 2024-12-17 10:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:37:33 --> Controller Class Initialized
DEBUG - 2024-12-17 10:37:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-12-17 10:37:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 10:37:33 --> Final output sent to browser
DEBUG - 2024-12-17 10:37:33 --> Total execution time: 0.0799
INFO - 2024-12-17 10:37:33 --> Config Class Initialized
INFO - 2024-12-17 10:37:33 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:37:33 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:37:33 --> Utf8 Class Initialized
INFO - 2024-12-17 10:37:33 --> URI Class Initialized
INFO - 2024-12-17 10:37:33 --> Router Class Initialized
INFO - 2024-12-17 10:37:33 --> Output Class Initialized
INFO - 2024-12-17 10:37:33 --> Security Class Initialized
DEBUG - 2024-12-17 10:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:37:33 --> Input Class Initialized
INFO - 2024-12-17 10:37:33 --> Language Class Initialized
INFO - 2024-12-17 10:37:33 --> Language Class Initialized
INFO - 2024-12-17 10:37:33 --> Config Class Initialized
INFO - 2024-12-17 10:37:33 --> Loader Class Initialized
INFO - 2024-12-17 10:37:33 --> Helper loaded: url_helper
INFO - 2024-12-17 10:37:33 --> Helper loaded: file_helper
INFO - 2024-12-17 10:37:33 --> Helper loaded: form_helper
INFO - 2024-12-17 10:37:33 --> Helper loaded: my_helper
INFO - 2024-12-17 10:37:33 --> Database Driver Class Initialized
INFO - 2024-12-17 10:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:37:33 --> Controller Class Initialized
DEBUG - 2024-12-17 10:37:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 10:37:35 --> Config Class Initialized
INFO - 2024-12-17 10:37:35 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:37:35 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:37:35 --> Utf8 Class Initialized
INFO - 2024-12-17 10:37:35 --> URI Class Initialized
INFO - 2024-12-17 10:37:35 --> Router Class Initialized
INFO - 2024-12-17 10:37:35 --> Output Class Initialized
INFO - 2024-12-17 10:37:35 --> Security Class Initialized
DEBUG - 2024-12-17 10:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:37:35 --> Input Class Initialized
INFO - 2024-12-17 10:37:35 --> Language Class Initialized
INFO - 2024-12-17 10:37:35 --> Language Class Initialized
INFO - 2024-12-17 10:37:35 --> Config Class Initialized
INFO - 2024-12-17 10:37:35 --> Loader Class Initialized
INFO - 2024-12-17 10:37:35 --> Helper loaded: url_helper
INFO - 2024-12-17 10:37:35 --> Helper loaded: file_helper
INFO - 2024-12-17 10:37:35 --> Helper loaded: form_helper
INFO - 2024-12-17 10:37:35 --> Helper loaded: my_helper
INFO - 2024-12-17 10:37:35 --> Database Driver Class Initialized
INFO - 2024-12-17 10:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:37:35 --> Controller Class Initialized
INFO - 2024-12-17 10:37:35 --> Helper loaded: cookie_helper
INFO - 2024-12-17 10:37:36 --> Config Class Initialized
INFO - 2024-12-17 10:37:36 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:37:36 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:37:36 --> Utf8 Class Initialized
INFO - 2024-12-17 10:37:36 --> URI Class Initialized
INFO - 2024-12-17 10:37:36 --> Router Class Initialized
INFO - 2024-12-17 10:37:36 --> Output Class Initialized
INFO - 2024-12-17 10:37:36 --> Security Class Initialized
DEBUG - 2024-12-17 10:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:37:36 --> Input Class Initialized
INFO - 2024-12-17 10:37:36 --> Language Class Initialized
INFO - 2024-12-17 10:37:36 --> Language Class Initialized
INFO - 2024-12-17 10:37:36 --> Config Class Initialized
INFO - 2024-12-17 10:37:36 --> Loader Class Initialized
INFO - 2024-12-17 10:37:36 --> Helper loaded: url_helper
INFO - 2024-12-17 10:37:36 --> Helper loaded: file_helper
INFO - 2024-12-17 10:37:36 --> Helper loaded: form_helper
INFO - 2024-12-17 10:37:36 --> Helper loaded: my_helper
INFO - 2024-12-17 10:37:36 --> Database Driver Class Initialized
INFO - 2024-12-17 10:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:37:36 --> Controller Class Initialized
INFO - 2024-12-17 10:37:36 --> Config Class Initialized
INFO - 2024-12-17 10:37:36 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:37:36 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:37:36 --> Utf8 Class Initialized
INFO - 2024-12-17 10:37:36 --> URI Class Initialized
INFO - 2024-12-17 10:37:36 --> Router Class Initialized
INFO - 2024-12-17 10:37:36 --> Output Class Initialized
INFO - 2024-12-17 10:37:36 --> Security Class Initialized
DEBUG - 2024-12-17 10:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:37:36 --> Input Class Initialized
INFO - 2024-12-17 10:37:36 --> Language Class Initialized
INFO - 2024-12-17 10:37:36 --> Language Class Initialized
INFO - 2024-12-17 10:37:36 --> Config Class Initialized
INFO - 2024-12-17 10:37:36 --> Loader Class Initialized
INFO - 2024-12-17 10:37:36 --> Helper loaded: url_helper
INFO - 2024-12-17 10:37:36 --> Helper loaded: file_helper
INFO - 2024-12-17 10:37:36 --> Helper loaded: form_helper
INFO - 2024-12-17 10:37:36 --> Helper loaded: my_helper
INFO - 2024-12-17 10:37:36 --> Database Driver Class Initialized
INFO - 2024-12-17 10:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:37:36 --> Controller Class Initialized
DEBUG - 2024-12-17 10:37:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-17 10:37:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 10:37:36 --> Final output sent to browser
DEBUG - 2024-12-17 10:37:36 --> Total execution time: 0.1053
INFO - 2024-12-17 10:37:41 --> Final output sent to browser
DEBUG - 2024-12-17 10:37:41 --> Total execution time: 7.7531
INFO - 2024-12-17 10:37:41 --> Config Class Initialized
INFO - 2024-12-17 10:37:41 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:37:41 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:37:41 --> Utf8 Class Initialized
INFO - 2024-12-17 10:37:41 --> URI Class Initialized
INFO - 2024-12-17 10:37:41 --> Router Class Initialized
INFO - 2024-12-17 10:37:41 --> Output Class Initialized
INFO - 2024-12-17 10:37:41 --> Security Class Initialized
DEBUG - 2024-12-17 10:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:37:41 --> Input Class Initialized
INFO - 2024-12-17 10:37:41 --> Language Class Initialized
INFO - 2024-12-17 10:37:41 --> Language Class Initialized
INFO - 2024-12-17 10:37:41 --> Config Class Initialized
INFO - 2024-12-17 10:37:41 --> Loader Class Initialized
INFO - 2024-12-17 10:37:41 --> Helper loaded: url_helper
INFO - 2024-12-17 10:37:41 --> Helper loaded: file_helper
INFO - 2024-12-17 10:37:41 --> Helper loaded: form_helper
INFO - 2024-12-17 10:37:41 --> Helper loaded: my_helper
INFO - 2024-12-17 10:37:41 --> Database Driver Class Initialized
INFO - 2024-12-17 10:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:37:41 --> Controller Class Initialized
INFO - 2024-12-17 10:37:41 --> Final output sent to browser
DEBUG - 2024-12-17 10:37:41 --> Total execution time: 0.1668
INFO - 2024-12-17 10:37:52 --> Config Class Initialized
INFO - 2024-12-17 10:37:52 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:37:52 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:37:52 --> Utf8 Class Initialized
INFO - 2024-12-17 10:37:52 --> URI Class Initialized
INFO - 2024-12-17 10:37:52 --> Router Class Initialized
INFO - 2024-12-17 10:37:52 --> Output Class Initialized
INFO - 2024-12-17 10:37:52 --> Security Class Initialized
DEBUG - 2024-12-17 10:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:37:52 --> Input Class Initialized
INFO - 2024-12-17 10:37:52 --> Language Class Initialized
INFO - 2024-12-17 10:37:52 --> Language Class Initialized
INFO - 2024-12-17 10:37:52 --> Config Class Initialized
INFO - 2024-12-17 10:37:52 --> Loader Class Initialized
INFO - 2024-12-17 10:37:52 --> Helper loaded: url_helper
INFO - 2024-12-17 10:37:52 --> Helper loaded: file_helper
INFO - 2024-12-17 10:37:52 --> Helper loaded: form_helper
INFO - 2024-12-17 10:37:52 --> Helper loaded: my_helper
INFO - 2024-12-17 10:37:52 --> Database Driver Class Initialized
INFO - 2024-12-17 10:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:37:52 --> Controller Class Initialized
INFO - 2024-12-17 10:37:52 --> Final output sent to browser
DEBUG - 2024-12-17 10:37:52 --> Total execution time: 0.0532
INFO - 2024-12-17 10:38:03 --> Config Class Initialized
INFO - 2024-12-17 10:38:03 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:38:03 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:38:03 --> Utf8 Class Initialized
INFO - 2024-12-17 10:38:03 --> URI Class Initialized
INFO - 2024-12-17 10:38:03 --> Router Class Initialized
INFO - 2024-12-17 10:38:03 --> Output Class Initialized
INFO - 2024-12-17 10:38:03 --> Security Class Initialized
DEBUG - 2024-12-17 10:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:38:03 --> Input Class Initialized
INFO - 2024-12-17 10:38:03 --> Language Class Initialized
INFO - 2024-12-17 10:38:03 --> Language Class Initialized
INFO - 2024-12-17 10:38:03 --> Config Class Initialized
INFO - 2024-12-17 10:38:03 --> Loader Class Initialized
INFO - 2024-12-17 10:38:04 --> Helper loaded: url_helper
INFO - 2024-12-17 10:38:04 --> Helper loaded: file_helper
INFO - 2024-12-17 10:38:04 --> Helper loaded: form_helper
INFO - 2024-12-17 10:38:04 --> Helper loaded: my_helper
INFO - 2024-12-17 10:38:04 --> Database Driver Class Initialized
INFO - 2024-12-17 10:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:38:04 --> Controller Class Initialized
INFO - 2024-12-17 10:38:04 --> Helper loaded: cookie_helper
INFO - 2024-12-17 10:38:04 --> Final output sent to browser
DEBUG - 2024-12-17 10:38:04 --> Total execution time: 0.2988
INFO - 2024-12-17 10:38:04 --> Config Class Initialized
INFO - 2024-12-17 10:38:04 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:38:04 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:38:04 --> Utf8 Class Initialized
INFO - 2024-12-17 10:38:04 --> URI Class Initialized
INFO - 2024-12-17 10:38:04 --> Router Class Initialized
INFO - 2024-12-17 10:38:04 --> Output Class Initialized
INFO - 2024-12-17 10:38:04 --> Security Class Initialized
DEBUG - 2024-12-17 10:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:38:04 --> Input Class Initialized
INFO - 2024-12-17 10:38:04 --> Language Class Initialized
INFO - 2024-12-17 10:38:04 --> Language Class Initialized
INFO - 2024-12-17 10:38:04 --> Config Class Initialized
INFO - 2024-12-17 10:38:04 --> Loader Class Initialized
INFO - 2024-12-17 10:38:04 --> Helper loaded: url_helper
INFO - 2024-12-17 10:38:04 --> Helper loaded: file_helper
INFO - 2024-12-17 10:38:04 --> Helper loaded: form_helper
INFO - 2024-12-17 10:38:04 --> Helper loaded: my_helper
INFO - 2024-12-17 10:38:04 --> Database Driver Class Initialized
INFO - 2024-12-17 10:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:38:04 --> Controller Class Initialized
DEBUG - 2024-12-17 10:38:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-12-17 10:38:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 10:38:04 --> Final output sent to browser
DEBUG - 2024-12-17 10:38:04 --> Total execution time: 0.1410
INFO - 2024-12-17 10:38:07 --> Config Class Initialized
INFO - 2024-12-17 10:38:07 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:38:07 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:38:07 --> Utf8 Class Initialized
INFO - 2024-12-17 10:38:07 --> URI Class Initialized
INFO - 2024-12-17 10:38:07 --> Router Class Initialized
INFO - 2024-12-17 10:38:07 --> Output Class Initialized
INFO - 2024-12-17 10:38:07 --> Security Class Initialized
DEBUG - 2024-12-17 10:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:38:07 --> Input Class Initialized
INFO - 2024-12-17 10:38:07 --> Language Class Initialized
INFO - 2024-12-17 10:38:07 --> Language Class Initialized
INFO - 2024-12-17 10:38:07 --> Config Class Initialized
INFO - 2024-12-17 10:38:07 --> Loader Class Initialized
INFO - 2024-12-17 10:38:07 --> Helper loaded: url_helper
INFO - 2024-12-17 10:38:07 --> Helper loaded: file_helper
INFO - 2024-12-17 10:38:07 --> Helper loaded: form_helper
INFO - 2024-12-17 10:38:07 --> Helper loaded: my_helper
INFO - 2024-12-17 10:38:07 --> Database Driver Class Initialized
INFO - 2024-12-17 10:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:38:07 --> Controller Class Initialized
DEBUG - 2024-12-17 10:38:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-12-17 10:38:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 10:38:07 --> Final output sent to browser
DEBUG - 2024-12-17 10:38:07 --> Total execution time: 0.0557
INFO - 2024-12-17 10:38:07 --> Config Class Initialized
INFO - 2024-12-17 10:38:07 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:38:07 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:38:07 --> Utf8 Class Initialized
INFO - 2024-12-17 10:38:07 --> URI Class Initialized
INFO - 2024-12-17 10:38:07 --> Router Class Initialized
INFO - 2024-12-17 10:38:07 --> Output Class Initialized
INFO - 2024-12-17 10:38:07 --> Security Class Initialized
DEBUG - 2024-12-17 10:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:38:07 --> Input Class Initialized
INFO - 2024-12-17 10:38:07 --> Language Class Initialized
ERROR - 2024-12-17 10:38:07 --> 404 Page Not Found: /index
INFO - 2024-12-17 10:38:07 --> Config Class Initialized
INFO - 2024-12-17 10:38:07 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:38:07 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:38:07 --> Utf8 Class Initialized
INFO - 2024-12-17 10:38:07 --> URI Class Initialized
INFO - 2024-12-17 10:38:07 --> Router Class Initialized
INFO - 2024-12-17 10:38:07 --> Output Class Initialized
INFO - 2024-12-17 10:38:07 --> Security Class Initialized
DEBUG - 2024-12-17 10:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:38:07 --> Input Class Initialized
INFO - 2024-12-17 10:38:07 --> Language Class Initialized
INFO - 2024-12-17 10:38:07 --> Language Class Initialized
INFO - 2024-12-17 10:38:07 --> Config Class Initialized
INFO - 2024-12-17 10:38:07 --> Loader Class Initialized
INFO - 2024-12-17 10:38:07 --> Helper loaded: url_helper
INFO - 2024-12-17 10:38:07 --> Helper loaded: file_helper
INFO - 2024-12-17 10:38:07 --> Helper loaded: form_helper
INFO - 2024-12-17 10:38:07 --> Helper loaded: my_helper
INFO - 2024-12-17 10:38:07 --> Database Driver Class Initialized
INFO - 2024-12-17 10:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:38:07 --> Controller Class Initialized
INFO - 2024-12-17 10:38:09 --> Config Class Initialized
INFO - 2024-12-17 10:38:09 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:38:09 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:38:09 --> Utf8 Class Initialized
INFO - 2024-12-17 10:38:09 --> URI Class Initialized
INFO - 2024-12-17 10:38:09 --> Router Class Initialized
INFO - 2024-12-17 10:38:09 --> Output Class Initialized
INFO - 2024-12-17 10:38:09 --> Security Class Initialized
DEBUG - 2024-12-17 10:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:38:09 --> Input Class Initialized
INFO - 2024-12-17 10:38:09 --> Language Class Initialized
INFO - 2024-12-17 10:38:09 --> Language Class Initialized
INFO - 2024-12-17 10:38:09 --> Config Class Initialized
INFO - 2024-12-17 10:38:09 --> Loader Class Initialized
INFO - 2024-12-17 10:38:09 --> Helper loaded: url_helper
INFO - 2024-12-17 10:38:09 --> Helper loaded: file_helper
INFO - 2024-12-17 10:38:09 --> Helper loaded: form_helper
INFO - 2024-12-17 10:38:09 --> Helper loaded: my_helper
INFO - 2024-12-17 10:38:09 --> Database Driver Class Initialized
INFO - 2024-12-17 10:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:38:09 --> Controller Class Initialized
INFO - 2024-12-17 10:38:10 --> Config Class Initialized
INFO - 2024-12-17 10:38:10 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:38:10 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:38:10 --> Utf8 Class Initialized
INFO - 2024-12-17 10:38:10 --> URI Class Initialized
INFO - 2024-12-17 10:38:10 --> Router Class Initialized
INFO - 2024-12-17 10:38:10 --> Output Class Initialized
INFO - 2024-12-17 10:38:10 --> Security Class Initialized
DEBUG - 2024-12-17 10:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:38:10 --> Input Class Initialized
INFO - 2024-12-17 10:38:10 --> Language Class Initialized
INFO - 2024-12-17 10:38:10 --> Language Class Initialized
INFO - 2024-12-17 10:38:10 --> Config Class Initialized
INFO - 2024-12-17 10:38:10 --> Loader Class Initialized
INFO - 2024-12-17 10:38:10 --> Helper loaded: url_helper
INFO - 2024-12-17 10:38:10 --> Helper loaded: file_helper
INFO - 2024-12-17 10:38:10 --> Helper loaded: form_helper
INFO - 2024-12-17 10:38:10 --> Helper loaded: my_helper
INFO - 2024-12-17 10:38:10 --> Database Driver Class Initialized
INFO - 2024-12-17 10:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:38:10 --> Controller Class Initialized
INFO - 2024-12-17 10:38:10 --> Config Class Initialized
INFO - 2024-12-17 10:38:10 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:38:10 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:38:10 --> Utf8 Class Initialized
INFO - 2024-12-17 10:38:10 --> URI Class Initialized
INFO - 2024-12-17 10:38:10 --> Router Class Initialized
INFO - 2024-12-17 10:38:10 --> Output Class Initialized
INFO - 2024-12-17 10:38:10 --> Security Class Initialized
DEBUG - 2024-12-17 10:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:38:10 --> Input Class Initialized
INFO - 2024-12-17 10:38:10 --> Language Class Initialized
INFO - 2024-12-17 10:38:10 --> Language Class Initialized
INFO - 2024-12-17 10:38:10 --> Config Class Initialized
INFO - 2024-12-17 10:38:10 --> Loader Class Initialized
INFO - 2024-12-17 10:38:10 --> Helper loaded: url_helper
INFO - 2024-12-17 10:38:10 --> Helper loaded: file_helper
INFO - 2024-12-17 10:38:10 --> Helper loaded: form_helper
INFO - 2024-12-17 10:38:10 --> Helper loaded: my_helper
INFO - 2024-12-17 10:38:10 --> Database Driver Class Initialized
INFO - 2024-12-17 10:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:38:10 --> Controller Class Initialized
INFO - 2024-12-17 10:41:25 --> Config Class Initialized
INFO - 2024-12-17 10:41:25 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:41:25 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:41:25 --> Utf8 Class Initialized
INFO - 2024-12-17 10:41:25 --> URI Class Initialized
INFO - 2024-12-17 10:41:25 --> Router Class Initialized
INFO - 2024-12-17 10:41:25 --> Output Class Initialized
INFO - 2024-12-17 10:41:25 --> Security Class Initialized
DEBUG - 2024-12-17 10:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:41:25 --> Input Class Initialized
INFO - 2024-12-17 10:41:25 --> Language Class Initialized
INFO - 2024-12-17 10:41:25 --> Language Class Initialized
INFO - 2024-12-17 10:41:25 --> Config Class Initialized
INFO - 2024-12-17 10:41:25 --> Loader Class Initialized
INFO - 2024-12-17 10:41:25 --> Helper loaded: url_helper
INFO - 2024-12-17 10:41:25 --> Helper loaded: file_helper
INFO - 2024-12-17 10:41:25 --> Helper loaded: form_helper
INFO - 2024-12-17 10:41:25 --> Helper loaded: my_helper
INFO - 2024-12-17 10:41:25 --> Database Driver Class Initialized
INFO - 2024-12-17 10:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:41:25 --> Controller Class Initialized
DEBUG - 2024-12-17 10:41:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-12-17 10:41:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 10:41:25 --> Final output sent to browser
DEBUG - 2024-12-17 10:41:25 --> Total execution time: 0.0708
INFO - 2024-12-17 10:41:25 --> Config Class Initialized
INFO - 2024-12-17 10:41:25 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:41:25 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:41:25 --> Utf8 Class Initialized
INFO - 2024-12-17 10:41:25 --> URI Class Initialized
INFO - 2024-12-17 10:41:25 --> Router Class Initialized
INFO - 2024-12-17 10:41:25 --> Output Class Initialized
INFO - 2024-12-17 10:41:25 --> Security Class Initialized
DEBUG - 2024-12-17 10:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:41:25 --> Input Class Initialized
INFO - 2024-12-17 10:41:25 --> Language Class Initialized
ERROR - 2024-12-17 10:41:25 --> 404 Page Not Found: /index
INFO - 2024-12-17 10:41:25 --> Config Class Initialized
INFO - 2024-12-17 10:41:25 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:41:25 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:41:25 --> Utf8 Class Initialized
INFO - 2024-12-17 10:41:25 --> URI Class Initialized
INFO - 2024-12-17 10:41:25 --> Router Class Initialized
INFO - 2024-12-17 10:41:25 --> Output Class Initialized
INFO - 2024-12-17 10:41:25 --> Security Class Initialized
DEBUG - 2024-12-17 10:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:41:25 --> Input Class Initialized
INFO - 2024-12-17 10:41:25 --> Language Class Initialized
INFO - 2024-12-17 10:41:25 --> Language Class Initialized
INFO - 2024-12-17 10:41:25 --> Config Class Initialized
INFO - 2024-12-17 10:41:25 --> Loader Class Initialized
INFO - 2024-12-17 10:41:25 --> Helper loaded: url_helper
INFO - 2024-12-17 10:41:25 --> Helper loaded: file_helper
INFO - 2024-12-17 10:41:25 --> Helper loaded: form_helper
INFO - 2024-12-17 10:41:25 --> Helper loaded: my_helper
INFO - 2024-12-17 10:41:25 --> Database Driver Class Initialized
INFO - 2024-12-17 10:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:41:25 --> Controller Class Initialized
INFO - 2024-12-17 10:41:27 --> Config Class Initialized
INFO - 2024-12-17 10:41:27 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:41:27 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:41:27 --> Utf8 Class Initialized
INFO - 2024-12-17 10:41:27 --> URI Class Initialized
INFO - 2024-12-17 10:41:27 --> Router Class Initialized
INFO - 2024-12-17 10:41:27 --> Output Class Initialized
INFO - 2024-12-17 10:41:27 --> Security Class Initialized
DEBUG - 2024-12-17 10:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:41:27 --> Input Class Initialized
INFO - 2024-12-17 10:41:27 --> Language Class Initialized
INFO - 2024-12-17 10:41:27 --> Language Class Initialized
INFO - 2024-12-17 10:41:27 --> Config Class Initialized
INFO - 2024-12-17 10:41:27 --> Loader Class Initialized
INFO - 2024-12-17 10:41:27 --> Helper loaded: url_helper
INFO - 2024-12-17 10:41:27 --> Helper loaded: file_helper
INFO - 2024-12-17 10:41:27 --> Helper loaded: form_helper
INFO - 2024-12-17 10:41:27 --> Helper loaded: my_helper
INFO - 2024-12-17 10:41:27 --> Database Driver Class Initialized
INFO - 2024-12-17 10:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:41:27 --> Controller Class Initialized
INFO - 2024-12-17 10:41:27 --> Config Class Initialized
INFO - 2024-12-17 10:41:27 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:41:27 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:41:27 --> Utf8 Class Initialized
INFO - 2024-12-17 10:41:27 --> URI Class Initialized
INFO - 2024-12-17 10:41:27 --> Router Class Initialized
INFO - 2024-12-17 10:41:27 --> Output Class Initialized
INFO - 2024-12-17 10:41:27 --> Security Class Initialized
DEBUG - 2024-12-17 10:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:41:27 --> Input Class Initialized
INFO - 2024-12-17 10:41:27 --> Language Class Initialized
INFO - 2024-12-17 10:41:27 --> Language Class Initialized
INFO - 2024-12-17 10:41:27 --> Config Class Initialized
INFO - 2024-12-17 10:41:27 --> Loader Class Initialized
INFO - 2024-12-17 10:41:27 --> Helper loaded: url_helper
INFO - 2024-12-17 10:41:27 --> Helper loaded: file_helper
INFO - 2024-12-17 10:41:27 --> Helper loaded: form_helper
INFO - 2024-12-17 10:41:27 --> Helper loaded: my_helper
INFO - 2024-12-17 10:41:27 --> Database Driver Class Initialized
INFO - 2024-12-17 10:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:41:27 --> Controller Class Initialized
INFO - 2024-12-17 10:41:32 --> Config Class Initialized
INFO - 2024-12-17 10:41:32 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:41:32 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:41:32 --> Utf8 Class Initialized
INFO - 2024-12-17 10:41:32 --> URI Class Initialized
INFO - 2024-12-17 10:41:32 --> Router Class Initialized
INFO - 2024-12-17 10:41:32 --> Output Class Initialized
INFO - 2024-12-17 10:41:32 --> Security Class Initialized
DEBUG - 2024-12-17 10:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:41:32 --> Input Class Initialized
INFO - 2024-12-17 10:41:32 --> Language Class Initialized
INFO - 2024-12-17 10:41:32 --> Language Class Initialized
INFO - 2024-12-17 10:41:32 --> Config Class Initialized
INFO - 2024-12-17 10:41:32 --> Loader Class Initialized
INFO - 2024-12-17 10:41:32 --> Helper loaded: url_helper
INFO - 2024-12-17 10:41:32 --> Helper loaded: file_helper
INFO - 2024-12-17 10:41:32 --> Helper loaded: form_helper
INFO - 2024-12-17 10:41:32 --> Helper loaded: my_helper
INFO - 2024-12-17 10:41:32 --> Database Driver Class Initialized
INFO - 2024-12-17 10:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:41:33 --> Controller Class Initialized
INFO - 2024-12-17 10:41:33 --> Final output sent to browser
DEBUG - 2024-12-17 10:41:33 --> Total execution time: 0.1141
INFO - 2024-12-17 10:41:33 --> Config Class Initialized
INFO - 2024-12-17 10:41:33 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:41:33 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:41:33 --> Utf8 Class Initialized
INFO - 2024-12-17 10:41:33 --> URI Class Initialized
INFO - 2024-12-17 10:41:33 --> Router Class Initialized
INFO - 2024-12-17 10:41:33 --> Output Class Initialized
INFO - 2024-12-17 10:41:33 --> Security Class Initialized
DEBUG - 2024-12-17 10:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:41:33 --> Input Class Initialized
INFO - 2024-12-17 10:41:33 --> Language Class Initialized
ERROR - 2024-12-17 10:41:33 --> 404 Page Not Found: /index
INFO - 2024-12-17 10:41:33 --> Config Class Initialized
INFO - 2024-12-17 10:41:33 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:41:33 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:41:33 --> Utf8 Class Initialized
INFO - 2024-12-17 10:41:33 --> URI Class Initialized
INFO - 2024-12-17 10:41:33 --> Router Class Initialized
INFO - 2024-12-17 10:41:33 --> Output Class Initialized
INFO - 2024-12-17 10:41:33 --> Security Class Initialized
DEBUG - 2024-12-17 10:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:41:33 --> Input Class Initialized
INFO - 2024-12-17 10:41:33 --> Language Class Initialized
INFO - 2024-12-17 10:41:33 --> Language Class Initialized
INFO - 2024-12-17 10:41:33 --> Config Class Initialized
INFO - 2024-12-17 10:41:33 --> Loader Class Initialized
INFO - 2024-12-17 10:41:33 --> Helper loaded: url_helper
INFO - 2024-12-17 10:41:33 --> Helper loaded: file_helper
INFO - 2024-12-17 10:41:33 --> Helper loaded: form_helper
INFO - 2024-12-17 10:41:33 --> Helper loaded: my_helper
INFO - 2024-12-17 10:41:33 --> Database Driver Class Initialized
INFO - 2024-12-17 10:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:41:33 --> Controller Class Initialized
INFO - 2024-12-17 10:42:00 --> Config Class Initialized
INFO - 2024-12-17 10:42:00 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:42:00 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:42:00 --> Utf8 Class Initialized
INFO - 2024-12-17 10:42:00 --> URI Class Initialized
INFO - 2024-12-17 10:42:00 --> Router Class Initialized
INFO - 2024-12-17 10:42:00 --> Output Class Initialized
INFO - 2024-12-17 10:42:00 --> Security Class Initialized
DEBUG - 2024-12-17 10:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:42:00 --> Input Class Initialized
INFO - 2024-12-17 10:42:00 --> Language Class Initialized
INFO - 2024-12-17 10:42:00 --> Language Class Initialized
INFO - 2024-12-17 10:42:00 --> Config Class Initialized
INFO - 2024-12-17 10:42:00 --> Loader Class Initialized
INFO - 2024-12-17 10:42:00 --> Helper loaded: url_helper
INFO - 2024-12-17 10:42:00 --> Helper loaded: file_helper
INFO - 2024-12-17 10:42:00 --> Helper loaded: form_helper
INFO - 2024-12-17 10:42:00 --> Helper loaded: my_helper
INFO - 2024-12-17 10:42:00 --> Database Driver Class Initialized
INFO - 2024-12-17 10:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:42:00 --> Controller Class Initialized
INFO - 2024-12-17 10:42:00 --> Helper loaded: cookie_helper
INFO - 2024-12-17 10:42:00 --> Config Class Initialized
INFO - 2024-12-17 10:42:00 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:42:00 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:42:00 --> Utf8 Class Initialized
INFO - 2024-12-17 10:42:00 --> URI Class Initialized
INFO - 2024-12-17 10:42:00 --> Router Class Initialized
INFO - 2024-12-17 10:42:00 --> Output Class Initialized
INFO - 2024-12-17 10:42:00 --> Security Class Initialized
DEBUG - 2024-12-17 10:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:42:00 --> Input Class Initialized
INFO - 2024-12-17 10:42:00 --> Language Class Initialized
INFO - 2024-12-17 10:42:00 --> Language Class Initialized
INFO - 2024-12-17 10:42:00 --> Config Class Initialized
INFO - 2024-12-17 10:42:00 --> Loader Class Initialized
INFO - 2024-12-17 10:42:00 --> Helper loaded: url_helper
INFO - 2024-12-17 10:42:00 --> Helper loaded: file_helper
INFO - 2024-12-17 10:42:00 --> Helper loaded: form_helper
INFO - 2024-12-17 10:42:00 --> Helper loaded: my_helper
INFO - 2024-12-17 10:42:00 --> Database Driver Class Initialized
INFO - 2024-12-17 10:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:42:00 --> Controller Class Initialized
INFO - 2024-12-17 10:42:00 --> Config Class Initialized
INFO - 2024-12-17 10:42:00 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:42:00 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:42:00 --> Utf8 Class Initialized
INFO - 2024-12-17 10:42:00 --> URI Class Initialized
INFO - 2024-12-17 10:42:00 --> Router Class Initialized
INFO - 2024-12-17 10:42:00 --> Output Class Initialized
INFO - 2024-12-17 10:42:00 --> Security Class Initialized
DEBUG - 2024-12-17 10:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:42:00 --> Input Class Initialized
INFO - 2024-12-17 10:42:00 --> Language Class Initialized
INFO - 2024-12-17 10:42:00 --> Language Class Initialized
INFO - 2024-12-17 10:42:00 --> Config Class Initialized
INFO - 2024-12-17 10:42:00 --> Loader Class Initialized
INFO - 2024-12-17 10:42:00 --> Helper loaded: url_helper
INFO - 2024-12-17 10:42:00 --> Helper loaded: file_helper
INFO - 2024-12-17 10:42:00 --> Helper loaded: form_helper
INFO - 2024-12-17 10:42:00 --> Helper loaded: my_helper
INFO - 2024-12-17 10:42:00 --> Database Driver Class Initialized
INFO - 2024-12-17 10:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:42:00 --> Controller Class Initialized
DEBUG - 2024-12-17 10:42:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-17 10:42:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 10:42:00 --> Final output sent to browser
DEBUG - 2024-12-17 10:42:00 --> Total execution time: 0.0624
INFO - 2024-12-17 10:42:06 --> Config Class Initialized
INFO - 2024-12-17 10:42:06 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:42:06 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:42:06 --> Utf8 Class Initialized
INFO - 2024-12-17 10:42:06 --> URI Class Initialized
INFO - 2024-12-17 10:42:06 --> Router Class Initialized
INFO - 2024-12-17 10:42:06 --> Output Class Initialized
INFO - 2024-12-17 10:42:06 --> Security Class Initialized
DEBUG - 2024-12-17 10:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:42:06 --> Input Class Initialized
INFO - 2024-12-17 10:42:06 --> Language Class Initialized
INFO - 2024-12-17 10:42:06 --> Language Class Initialized
INFO - 2024-12-17 10:42:06 --> Config Class Initialized
INFO - 2024-12-17 10:42:06 --> Loader Class Initialized
INFO - 2024-12-17 10:42:06 --> Helper loaded: url_helper
INFO - 2024-12-17 10:42:06 --> Helper loaded: file_helper
INFO - 2024-12-17 10:42:06 --> Helper loaded: form_helper
INFO - 2024-12-17 10:42:06 --> Helper loaded: my_helper
INFO - 2024-12-17 10:42:06 --> Database Driver Class Initialized
INFO - 2024-12-17 10:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:42:06 --> Controller Class Initialized
INFO - 2024-12-17 10:42:06 --> Helper loaded: cookie_helper
INFO - 2024-12-17 10:42:06 --> Final output sent to browser
DEBUG - 2024-12-17 10:42:06 --> Total execution time: 0.0560
INFO - 2024-12-17 10:42:06 --> Config Class Initialized
INFO - 2024-12-17 10:42:06 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:42:06 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:42:06 --> Utf8 Class Initialized
INFO - 2024-12-17 10:42:06 --> URI Class Initialized
INFO - 2024-12-17 10:42:06 --> Router Class Initialized
INFO - 2024-12-17 10:42:06 --> Output Class Initialized
INFO - 2024-12-17 10:42:06 --> Security Class Initialized
DEBUG - 2024-12-17 10:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:42:06 --> Input Class Initialized
INFO - 2024-12-17 10:42:06 --> Language Class Initialized
INFO - 2024-12-17 10:42:06 --> Language Class Initialized
INFO - 2024-12-17 10:42:06 --> Config Class Initialized
INFO - 2024-12-17 10:42:06 --> Loader Class Initialized
INFO - 2024-12-17 10:42:06 --> Helper loaded: url_helper
INFO - 2024-12-17 10:42:06 --> Helper loaded: file_helper
INFO - 2024-12-17 10:42:06 --> Helper loaded: form_helper
INFO - 2024-12-17 10:42:06 --> Helper loaded: my_helper
INFO - 2024-12-17 10:42:06 --> Database Driver Class Initialized
INFO - 2024-12-17 10:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:42:06 --> Controller Class Initialized
DEBUG - 2024-12-17 10:42:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-12-17 10:42:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 10:42:06 --> Final output sent to browser
DEBUG - 2024-12-17 10:42:06 --> Total execution time: 0.0339
INFO - 2024-12-17 10:42:08 --> Config Class Initialized
INFO - 2024-12-17 10:42:08 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:42:08 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:42:08 --> Utf8 Class Initialized
INFO - 2024-12-17 10:42:08 --> URI Class Initialized
INFO - 2024-12-17 10:42:08 --> Router Class Initialized
INFO - 2024-12-17 10:42:08 --> Output Class Initialized
INFO - 2024-12-17 10:42:08 --> Security Class Initialized
DEBUG - 2024-12-17 10:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:42:08 --> Input Class Initialized
INFO - 2024-12-17 10:42:08 --> Language Class Initialized
INFO - 2024-12-17 10:42:08 --> Language Class Initialized
INFO - 2024-12-17 10:42:08 --> Config Class Initialized
INFO - 2024-12-17 10:42:08 --> Loader Class Initialized
INFO - 2024-12-17 10:42:08 --> Helper loaded: url_helper
INFO - 2024-12-17 10:42:08 --> Helper loaded: file_helper
INFO - 2024-12-17 10:42:08 --> Helper loaded: form_helper
INFO - 2024-12-17 10:42:08 --> Helper loaded: my_helper
INFO - 2024-12-17 10:42:08 --> Database Driver Class Initialized
INFO - 2024-12-17 10:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:42:08 --> Controller Class Initialized
DEBUG - 2024-12-17 10:42:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-17 10:42:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 10:42:08 --> Final output sent to browser
DEBUG - 2024-12-17 10:42:08 --> Total execution time: 0.0465
INFO - 2024-12-17 10:42:12 --> Config Class Initialized
INFO - 2024-12-17 10:42:12 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:42:12 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:42:12 --> Utf8 Class Initialized
INFO - 2024-12-17 10:42:12 --> URI Class Initialized
INFO - 2024-12-17 10:42:12 --> Router Class Initialized
INFO - 2024-12-17 10:42:12 --> Output Class Initialized
INFO - 2024-12-17 10:42:12 --> Security Class Initialized
DEBUG - 2024-12-17 10:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:42:12 --> Input Class Initialized
INFO - 2024-12-17 10:42:12 --> Language Class Initialized
INFO - 2024-12-17 10:42:12 --> Language Class Initialized
INFO - 2024-12-17 10:42:12 --> Config Class Initialized
INFO - 2024-12-17 10:42:12 --> Loader Class Initialized
INFO - 2024-12-17 10:42:12 --> Helper loaded: url_helper
INFO - 2024-12-17 10:42:12 --> Helper loaded: file_helper
INFO - 2024-12-17 10:42:12 --> Helper loaded: form_helper
INFO - 2024-12-17 10:42:12 --> Helper loaded: my_helper
INFO - 2024-12-17 10:42:12 --> Database Driver Class Initialized
INFO - 2024-12-17 10:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:42:12 --> Controller Class Initialized
DEBUG - 2024-12-17 10:42:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-17 10:42:16 --> Final output sent to browser
DEBUG - 2024-12-17 10:42:16 --> Total execution time: 3.9996
INFO - 2024-12-17 10:42:22 --> Config Class Initialized
INFO - 2024-12-17 10:42:22 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:42:22 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:42:22 --> Utf8 Class Initialized
INFO - 2024-12-17 10:42:22 --> URI Class Initialized
INFO - 2024-12-17 10:42:22 --> Router Class Initialized
INFO - 2024-12-17 10:42:22 --> Output Class Initialized
INFO - 2024-12-17 10:42:22 --> Security Class Initialized
DEBUG - 2024-12-17 10:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:42:22 --> Input Class Initialized
INFO - 2024-12-17 10:42:22 --> Language Class Initialized
INFO - 2024-12-17 10:42:22 --> Language Class Initialized
INFO - 2024-12-17 10:42:22 --> Config Class Initialized
INFO - 2024-12-17 10:42:22 --> Loader Class Initialized
INFO - 2024-12-17 10:42:22 --> Helper loaded: url_helper
INFO - 2024-12-17 10:42:22 --> Helper loaded: file_helper
INFO - 2024-12-17 10:42:22 --> Helper loaded: form_helper
INFO - 2024-12-17 10:42:22 --> Helper loaded: my_helper
INFO - 2024-12-17 10:42:23 --> Database Driver Class Initialized
INFO - 2024-12-17 10:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:42:23 --> Controller Class Initialized
DEBUG - 2024-12-17 10:42:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-17 10:42:29 --> Final output sent to browser
DEBUG - 2024-12-17 10:42:29 --> Total execution time: 6.5727
INFO - 2024-12-17 10:42:53 --> Config Class Initialized
INFO - 2024-12-17 10:42:53 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:42:53 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:42:53 --> Utf8 Class Initialized
INFO - 2024-12-17 10:42:53 --> URI Class Initialized
INFO - 2024-12-17 10:42:53 --> Router Class Initialized
INFO - 2024-12-17 10:42:53 --> Output Class Initialized
INFO - 2024-12-17 10:42:53 --> Security Class Initialized
DEBUG - 2024-12-17 10:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:42:53 --> Input Class Initialized
INFO - 2024-12-17 10:42:53 --> Language Class Initialized
INFO - 2024-12-17 10:42:53 --> Language Class Initialized
INFO - 2024-12-17 10:42:53 --> Config Class Initialized
INFO - 2024-12-17 10:42:53 --> Loader Class Initialized
INFO - 2024-12-17 10:42:53 --> Helper loaded: url_helper
INFO - 2024-12-17 10:42:53 --> Helper loaded: file_helper
INFO - 2024-12-17 10:42:53 --> Helper loaded: form_helper
INFO - 2024-12-17 10:42:53 --> Helper loaded: my_helper
INFO - 2024-12-17 10:42:53 --> Database Driver Class Initialized
INFO - 2024-12-17 10:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:42:53 --> Controller Class Initialized
INFO - 2024-12-17 10:42:53 --> Helper loaded: cookie_helper
INFO - 2024-12-17 10:42:53 --> Final output sent to browser
DEBUG - 2024-12-17 10:42:53 --> Total execution time: 0.1045
INFO - 2024-12-17 10:42:54 --> Config Class Initialized
INFO - 2024-12-17 10:42:54 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:42:54 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:42:54 --> Utf8 Class Initialized
INFO - 2024-12-17 10:42:54 --> URI Class Initialized
INFO - 2024-12-17 10:42:54 --> Router Class Initialized
INFO - 2024-12-17 10:42:54 --> Output Class Initialized
INFO - 2024-12-17 10:42:54 --> Security Class Initialized
DEBUG - 2024-12-17 10:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:42:54 --> Input Class Initialized
INFO - 2024-12-17 10:42:55 --> Language Class Initialized
INFO - 2024-12-17 10:42:55 --> Language Class Initialized
INFO - 2024-12-17 10:42:55 --> Config Class Initialized
INFO - 2024-12-17 10:42:55 --> Loader Class Initialized
INFO - 2024-12-17 10:42:55 --> Helper loaded: url_helper
INFO - 2024-12-17 10:42:55 --> Helper loaded: file_helper
INFO - 2024-12-17 10:42:55 --> Helper loaded: form_helper
INFO - 2024-12-17 10:42:55 --> Helper loaded: my_helper
INFO - 2024-12-17 10:42:55 --> Database Driver Class Initialized
INFO - 2024-12-17 10:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:42:55 --> Controller Class Initialized
INFO - 2024-12-17 10:42:55 --> Helper loaded: cookie_helper
INFO - 2024-12-17 10:42:55 --> Config Class Initialized
INFO - 2024-12-17 10:42:55 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:42:55 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:42:55 --> Utf8 Class Initialized
INFO - 2024-12-17 10:42:55 --> URI Class Initialized
INFO - 2024-12-17 10:42:55 --> Router Class Initialized
INFO - 2024-12-17 10:42:55 --> Output Class Initialized
INFO - 2024-12-17 10:42:55 --> Security Class Initialized
DEBUG - 2024-12-17 10:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:42:55 --> Input Class Initialized
INFO - 2024-12-17 10:42:55 --> Language Class Initialized
INFO - 2024-12-17 10:42:55 --> Language Class Initialized
INFO - 2024-12-17 10:42:55 --> Config Class Initialized
INFO - 2024-12-17 10:42:55 --> Loader Class Initialized
INFO - 2024-12-17 10:42:55 --> Helper loaded: url_helper
INFO - 2024-12-17 10:42:55 --> Helper loaded: file_helper
INFO - 2024-12-17 10:42:55 --> Helper loaded: form_helper
INFO - 2024-12-17 10:42:55 --> Helper loaded: my_helper
INFO - 2024-12-17 10:42:55 --> Database Driver Class Initialized
INFO - 2024-12-17 10:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:42:55 --> Controller Class Initialized
DEBUG - 2024-12-17 10:42:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-17 10:42:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 10:42:55 --> Final output sent to browser
DEBUG - 2024-12-17 10:42:55 --> Total execution time: 0.0518
INFO - 2024-12-17 10:43:21 --> Config Class Initialized
INFO - 2024-12-17 10:43:21 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:43:21 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:43:21 --> Utf8 Class Initialized
INFO - 2024-12-17 10:43:21 --> URI Class Initialized
INFO - 2024-12-17 10:43:21 --> Router Class Initialized
INFO - 2024-12-17 10:43:21 --> Output Class Initialized
INFO - 2024-12-17 10:43:21 --> Security Class Initialized
DEBUG - 2024-12-17 10:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:43:21 --> Input Class Initialized
INFO - 2024-12-17 10:43:21 --> Language Class Initialized
INFO - 2024-12-17 10:43:21 --> Language Class Initialized
INFO - 2024-12-17 10:43:21 --> Config Class Initialized
INFO - 2024-12-17 10:43:21 --> Loader Class Initialized
INFO - 2024-12-17 10:43:21 --> Helper loaded: url_helper
INFO - 2024-12-17 10:43:21 --> Helper loaded: file_helper
INFO - 2024-12-17 10:43:21 --> Helper loaded: form_helper
INFO - 2024-12-17 10:43:21 --> Helper loaded: my_helper
INFO - 2024-12-17 10:43:21 --> Database Driver Class Initialized
INFO - 2024-12-17 10:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:43:21 --> Controller Class Initialized
INFO - 2024-12-17 10:43:21 --> Helper loaded: cookie_helper
INFO - 2024-12-17 10:43:21 --> Config Class Initialized
INFO - 2024-12-17 10:43:21 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:43:21 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:43:21 --> Utf8 Class Initialized
INFO - 2024-12-17 10:43:21 --> URI Class Initialized
INFO - 2024-12-17 10:43:21 --> Router Class Initialized
INFO - 2024-12-17 10:43:21 --> Output Class Initialized
INFO - 2024-12-17 10:43:21 --> Security Class Initialized
DEBUG - 2024-12-17 10:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:43:21 --> Input Class Initialized
INFO - 2024-12-17 10:43:21 --> Language Class Initialized
INFO - 2024-12-17 10:43:21 --> Language Class Initialized
INFO - 2024-12-17 10:43:21 --> Config Class Initialized
INFO - 2024-12-17 10:43:21 --> Loader Class Initialized
INFO - 2024-12-17 10:43:21 --> Helper loaded: url_helper
INFO - 2024-12-17 10:43:21 --> Helper loaded: file_helper
INFO - 2024-12-17 10:43:21 --> Helper loaded: form_helper
INFO - 2024-12-17 10:43:21 --> Helper loaded: my_helper
INFO - 2024-12-17 10:43:21 --> Database Driver Class Initialized
INFO - 2024-12-17 10:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:43:21 --> Controller Class Initialized
INFO - 2024-12-17 10:43:22 --> Config Class Initialized
INFO - 2024-12-17 10:43:22 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:43:22 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:43:22 --> Utf8 Class Initialized
INFO - 2024-12-17 10:43:22 --> URI Class Initialized
INFO - 2024-12-17 10:43:22 --> Router Class Initialized
INFO - 2024-12-17 10:43:22 --> Output Class Initialized
INFO - 2024-12-17 10:43:22 --> Security Class Initialized
DEBUG - 2024-12-17 10:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:43:22 --> Input Class Initialized
INFO - 2024-12-17 10:43:22 --> Language Class Initialized
INFO - 2024-12-17 10:43:22 --> Language Class Initialized
INFO - 2024-12-17 10:43:22 --> Config Class Initialized
INFO - 2024-12-17 10:43:22 --> Loader Class Initialized
INFO - 2024-12-17 10:43:22 --> Helper loaded: url_helper
INFO - 2024-12-17 10:43:22 --> Helper loaded: file_helper
INFO - 2024-12-17 10:43:22 --> Helper loaded: form_helper
INFO - 2024-12-17 10:43:22 --> Helper loaded: my_helper
INFO - 2024-12-17 10:43:22 --> Database Driver Class Initialized
INFO - 2024-12-17 10:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:43:22 --> Controller Class Initialized
DEBUG - 2024-12-17 10:43:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-17 10:43:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 10:43:22 --> Final output sent to browser
DEBUG - 2024-12-17 10:43:22 --> Total execution time: 0.0334
INFO - 2024-12-17 10:43:23 --> Config Class Initialized
INFO - 2024-12-17 10:43:23 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:43:23 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:43:23 --> Utf8 Class Initialized
INFO - 2024-12-17 10:43:23 --> URI Class Initialized
INFO - 2024-12-17 10:43:23 --> Router Class Initialized
INFO - 2024-12-17 10:43:23 --> Output Class Initialized
INFO - 2024-12-17 10:43:23 --> Security Class Initialized
DEBUG - 2024-12-17 10:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:43:23 --> Input Class Initialized
INFO - 2024-12-17 10:43:23 --> Language Class Initialized
INFO - 2024-12-17 10:43:23 --> Language Class Initialized
INFO - 2024-12-17 10:43:23 --> Config Class Initialized
INFO - 2024-12-17 10:43:23 --> Loader Class Initialized
INFO - 2024-12-17 10:43:23 --> Helper loaded: url_helper
INFO - 2024-12-17 10:43:23 --> Helper loaded: file_helper
INFO - 2024-12-17 10:43:23 --> Helper loaded: form_helper
INFO - 2024-12-17 10:43:23 --> Helper loaded: my_helper
INFO - 2024-12-17 10:43:23 --> Database Driver Class Initialized
INFO - 2024-12-17 10:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:43:23 --> Controller Class Initialized
DEBUG - 2024-12-17 10:43:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-17 10:43:27 --> Final output sent to browser
DEBUG - 2024-12-17 10:43:27 --> Total execution time: 4.3688
INFO - 2024-12-17 10:43:27 --> Config Class Initialized
INFO - 2024-12-17 10:43:27 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:43:27 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:43:27 --> Utf8 Class Initialized
INFO - 2024-12-17 10:43:27 --> URI Class Initialized
INFO - 2024-12-17 10:43:27 --> Router Class Initialized
INFO - 2024-12-17 10:43:27 --> Output Class Initialized
INFO - 2024-12-17 10:43:27 --> Security Class Initialized
DEBUG - 2024-12-17 10:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:43:27 --> Input Class Initialized
INFO - 2024-12-17 10:43:27 --> Language Class Initialized
INFO - 2024-12-17 10:43:27 --> Language Class Initialized
INFO - 2024-12-17 10:43:27 --> Config Class Initialized
INFO - 2024-12-17 10:43:27 --> Loader Class Initialized
INFO - 2024-12-17 10:43:27 --> Helper loaded: url_helper
INFO - 2024-12-17 10:43:27 --> Helper loaded: file_helper
INFO - 2024-12-17 10:43:27 --> Helper loaded: form_helper
INFO - 2024-12-17 10:43:27 --> Helper loaded: my_helper
INFO - 2024-12-17 10:43:27 --> Database Driver Class Initialized
INFO - 2024-12-17 10:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:43:27 --> Controller Class Initialized
INFO - 2024-12-17 10:43:27 --> Helper loaded: cookie_helper
INFO - 2024-12-17 10:43:27 --> Final output sent to browser
DEBUG - 2024-12-17 10:43:27 --> Total execution time: 0.0358
INFO - 2024-12-17 10:43:27 --> Config Class Initialized
INFO - 2024-12-17 10:43:27 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:43:27 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:43:27 --> Utf8 Class Initialized
INFO - 2024-12-17 10:43:27 --> URI Class Initialized
INFO - 2024-12-17 10:43:27 --> Router Class Initialized
INFO - 2024-12-17 10:43:27 --> Output Class Initialized
INFO - 2024-12-17 10:43:27 --> Security Class Initialized
DEBUG - 2024-12-17 10:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:43:27 --> Input Class Initialized
INFO - 2024-12-17 10:43:27 --> Language Class Initialized
INFO - 2024-12-17 10:43:27 --> Language Class Initialized
INFO - 2024-12-17 10:43:27 --> Config Class Initialized
INFO - 2024-12-17 10:43:27 --> Loader Class Initialized
INFO - 2024-12-17 10:43:27 --> Helper loaded: url_helper
INFO - 2024-12-17 10:43:27 --> Helper loaded: file_helper
INFO - 2024-12-17 10:43:27 --> Helper loaded: form_helper
INFO - 2024-12-17 10:43:27 --> Helper loaded: my_helper
INFO - 2024-12-17 10:43:27 --> Database Driver Class Initialized
INFO - 2024-12-17 10:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:43:27 --> Controller Class Initialized
DEBUG - 2024-12-17 10:43:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-12-17 10:43:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 10:43:27 --> Final output sent to browser
DEBUG - 2024-12-17 10:43:27 --> Total execution time: 0.0400
INFO - 2024-12-17 10:43:35 --> Config Class Initialized
INFO - 2024-12-17 10:43:35 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:43:35 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:43:35 --> Utf8 Class Initialized
INFO - 2024-12-17 10:43:35 --> URI Class Initialized
INFO - 2024-12-17 10:43:35 --> Router Class Initialized
INFO - 2024-12-17 10:43:35 --> Output Class Initialized
INFO - 2024-12-17 10:43:35 --> Security Class Initialized
DEBUG - 2024-12-17 10:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:43:35 --> Input Class Initialized
INFO - 2024-12-17 10:43:35 --> Language Class Initialized
INFO - 2024-12-17 10:43:35 --> Language Class Initialized
INFO - 2024-12-17 10:43:35 --> Config Class Initialized
INFO - 2024-12-17 10:43:35 --> Loader Class Initialized
INFO - 2024-12-17 10:43:35 --> Helper loaded: url_helper
INFO - 2024-12-17 10:43:35 --> Helper loaded: file_helper
INFO - 2024-12-17 10:43:35 --> Helper loaded: form_helper
INFO - 2024-12-17 10:43:35 --> Helper loaded: my_helper
INFO - 2024-12-17 10:43:35 --> Database Driver Class Initialized
INFO - 2024-12-17 10:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:43:35 --> Controller Class Initialized
DEBUG - 2024-12-17 10:43:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-12-17 10:43:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 10:43:35 --> Final output sent to browser
DEBUG - 2024-12-17 10:43:35 --> Total execution time: 0.1760
INFO - 2024-12-17 10:43:44 --> Config Class Initialized
INFO - 2024-12-17 10:43:44 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:43:44 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:43:44 --> Utf8 Class Initialized
INFO - 2024-12-17 10:43:44 --> URI Class Initialized
INFO - 2024-12-17 10:43:44 --> Router Class Initialized
INFO - 2024-12-17 10:43:44 --> Output Class Initialized
INFO - 2024-12-17 10:43:44 --> Security Class Initialized
DEBUG - 2024-12-17 10:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:43:44 --> Input Class Initialized
INFO - 2024-12-17 10:43:44 --> Language Class Initialized
INFO - 2024-12-17 10:43:44 --> Language Class Initialized
INFO - 2024-12-17 10:43:44 --> Config Class Initialized
INFO - 2024-12-17 10:43:44 --> Loader Class Initialized
INFO - 2024-12-17 10:43:44 --> Helper loaded: url_helper
INFO - 2024-12-17 10:43:44 --> Helper loaded: file_helper
INFO - 2024-12-17 10:43:44 --> Helper loaded: form_helper
INFO - 2024-12-17 10:43:44 --> Helper loaded: my_helper
INFO - 2024-12-17 10:43:44 --> Database Driver Class Initialized
INFO - 2024-12-17 10:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:43:44 --> Controller Class Initialized
DEBUG - 2024-12-17 10:43:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-12-17 10:43:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 10:43:44 --> Final output sent to browser
DEBUG - 2024-12-17 10:43:44 --> Total execution time: 0.0784
INFO - 2024-12-17 10:43:45 --> Config Class Initialized
INFO - 2024-12-17 10:43:45 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:43:45 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:43:45 --> Utf8 Class Initialized
INFO - 2024-12-17 10:43:45 --> URI Class Initialized
INFO - 2024-12-17 10:43:45 --> Router Class Initialized
INFO - 2024-12-17 10:43:45 --> Output Class Initialized
INFO - 2024-12-17 10:43:45 --> Security Class Initialized
DEBUG - 2024-12-17 10:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:43:45 --> Input Class Initialized
INFO - 2024-12-17 10:43:45 --> Language Class Initialized
ERROR - 2024-12-17 10:43:45 --> 404 Page Not Found: /index
INFO - 2024-12-17 10:43:45 --> Config Class Initialized
INFO - 2024-12-17 10:43:45 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:43:45 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:43:45 --> Utf8 Class Initialized
INFO - 2024-12-17 10:43:45 --> URI Class Initialized
INFO - 2024-12-17 10:43:45 --> Router Class Initialized
INFO - 2024-12-17 10:43:45 --> Output Class Initialized
INFO - 2024-12-17 10:43:45 --> Security Class Initialized
DEBUG - 2024-12-17 10:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:43:45 --> Input Class Initialized
INFO - 2024-12-17 10:43:45 --> Language Class Initialized
INFO - 2024-12-17 10:43:45 --> Language Class Initialized
INFO - 2024-12-17 10:43:45 --> Config Class Initialized
INFO - 2024-12-17 10:43:45 --> Loader Class Initialized
INFO - 2024-12-17 10:43:45 --> Helper loaded: url_helper
INFO - 2024-12-17 10:43:45 --> Helper loaded: file_helper
INFO - 2024-12-17 10:43:45 --> Helper loaded: form_helper
INFO - 2024-12-17 10:43:45 --> Helper loaded: my_helper
INFO - 2024-12-17 10:43:45 --> Database Driver Class Initialized
INFO - 2024-12-17 10:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:43:45 --> Controller Class Initialized
INFO - 2024-12-17 10:43:47 --> Config Class Initialized
INFO - 2024-12-17 10:43:47 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:43:47 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:43:47 --> Utf8 Class Initialized
INFO - 2024-12-17 10:43:47 --> URI Class Initialized
INFO - 2024-12-17 10:43:47 --> Router Class Initialized
INFO - 2024-12-17 10:43:47 --> Output Class Initialized
INFO - 2024-12-17 10:43:47 --> Security Class Initialized
DEBUG - 2024-12-17 10:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:43:47 --> Input Class Initialized
INFO - 2024-12-17 10:43:47 --> Language Class Initialized
INFO - 2024-12-17 10:43:47 --> Language Class Initialized
INFO - 2024-12-17 10:43:47 --> Config Class Initialized
INFO - 2024-12-17 10:43:47 --> Loader Class Initialized
INFO - 2024-12-17 10:43:47 --> Helper loaded: url_helper
INFO - 2024-12-17 10:43:47 --> Helper loaded: file_helper
INFO - 2024-12-17 10:43:47 --> Helper loaded: form_helper
INFO - 2024-12-17 10:43:48 --> Helper loaded: my_helper
INFO - 2024-12-17 10:43:48 --> Database Driver Class Initialized
INFO - 2024-12-17 10:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:43:48 --> Controller Class Initialized
INFO - 2024-12-17 10:43:53 --> Config Class Initialized
INFO - 2024-12-17 10:43:53 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:43:53 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:43:53 --> Utf8 Class Initialized
INFO - 2024-12-17 10:43:53 --> URI Class Initialized
INFO - 2024-12-17 10:43:53 --> Router Class Initialized
INFO - 2024-12-17 10:43:53 --> Output Class Initialized
INFO - 2024-12-17 10:43:53 --> Security Class Initialized
DEBUG - 2024-12-17 10:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:43:53 --> Input Class Initialized
INFO - 2024-12-17 10:43:53 --> Language Class Initialized
INFO - 2024-12-17 10:43:53 --> Language Class Initialized
INFO - 2024-12-17 10:43:53 --> Config Class Initialized
INFO - 2024-12-17 10:43:53 --> Loader Class Initialized
INFO - 2024-12-17 10:43:53 --> Helper loaded: url_helper
INFO - 2024-12-17 10:43:53 --> Helper loaded: file_helper
INFO - 2024-12-17 10:43:53 --> Helper loaded: form_helper
INFO - 2024-12-17 10:43:53 --> Helper loaded: my_helper
INFO - 2024-12-17 10:43:53 --> Database Driver Class Initialized
INFO - 2024-12-17 10:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:43:53 --> Controller Class Initialized
INFO - 2024-12-17 10:43:53 --> Helper loaded: cookie_helper
INFO - 2024-12-17 10:43:53 --> Config Class Initialized
INFO - 2024-12-17 10:43:53 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:43:53 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:43:53 --> Utf8 Class Initialized
INFO - 2024-12-17 10:43:53 --> URI Class Initialized
INFO - 2024-12-17 10:43:53 --> Router Class Initialized
INFO - 2024-12-17 10:43:53 --> Output Class Initialized
INFO - 2024-12-17 10:43:53 --> Security Class Initialized
DEBUG - 2024-12-17 10:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:43:53 --> Input Class Initialized
INFO - 2024-12-17 10:43:53 --> Language Class Initialized
INFO - 2024-12-17 10:43:53 --> Language Class Initialized
INFO - 2024-12-17 10:43:53 --> Config Class Initialized
INFO - 2024-12-17 10:43:53 --> Loader Class Initialized
INFO - 2024-12-17 10:43:53 --> Helper loaded: url_helper
INFO - 2024-12-17 10:43:53 --> Helper loaded: file_helper
INFO - 2024-12-17 10:43:53 --> Helper loaded: form_helper
INFO - 2024-12-17 10:43:53 --> Helper loaded: my_helper
INFO - 2024-12-17 10:43:53 --> Database Driver Class Initialized
INFO - 2024-12-17 10:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:43:53 --> Controller Class Initialized
INFO - 2024-12-17 10:43:53 --> Config Class Initialized
INFO - 2024-12-17 10:43:53 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:43:53 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:43:53 --> Utf8 Class Initialized
INFO - 2024-12-17 10:43:53 --> URI Class Initialized
INFO - 2024-12-17 10:43:53 --> Router Class Initialized
INFO - 2024-12-17 10:43:53 --> Output Class Initialized
INFO - 2024-12-17 10:43:53 --> Security Class Initialized
DEBUG - 2024-12-17 10:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:43:53 --> Input Class Initialized
INFO - 2024-12-17 10:43:53 --> Language Class Initialized
INFO - 2024-12-17 10:43:53 --> Language Class Initialized
INFO - 2024-12-17 10:43:53 --> Config Class Initialized
INFO - 2024-12-17 10:43:53 --> Loader Class Initialized
INFO - 2024-12-17 10:43:53 --> Helper loaded: url_helper
INFO - 2024-12-17 10:43:53 --> Helper loaded: file_helper
INFO - 2024-12-17 10:43:53 --> Helper loaded: form_helper
INFO - 2024-12-17 10:43:53 --> Helper loaded: my_helper
INFO - 2024-12-17 10:43:53 --> Database Driver Class Initialized
INFO - 2024-12-17 10:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:43:53 --> Controller Class Initialized
DEBUG - 2024-12-17 10:43:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-17 10:43:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 10:43:53 --> Final output sent to browser
DEBUG - 2024-12-17 10:43:53 --> Total execution time: 0.0638
INFO - 2024-12-17 10:44:02 --> Config Class Initialized
INFO - 2024-12-17 10:44:02 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:44:02 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:44:02 --> Utf8 Class Initialized
INFO - 2024-12-17 10:44:02 --> URI Class Initialized
INFO - 2024-12-17 10:44:02 --> Router Class Initialized
INFO - 2024-12-17 10:44:02 --> Output Class Initialized
INFO - 2024-12-17 10:44:02 --> Security Class Initialized
DEBUG - 2024-12-17 10:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:44:02 --> Input Class Initialized
INFO - 2024-12-17 10:44:02 --> Language Class Initialized
INFO - 2024-12-17 10:44:02 --> Language Class Initialized
INFO - 2024-12-17 10:44:02 --> Config Class Initialized
INFO - 2024-12-17 10:44:02 --> Loader Class Initialized
INFO - 2024-12-17 10:44:02 --> Helper loaded: url_helper
INFO - 2024-12-17 10:44:02 --> Helper loaded: file_helper
INFO - 2024-12-17 10:44:02 --> Helper loaded: form_helper
INFO - 2024-12-17 10:44:02 --> Helper loaded: my_helper
INFO - 2024-12-17 10:44:02 --> Database Driver Class Initialized
INFO - 2024-12-17 10:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:44:02 --> Controller Class Initialized
INFO - 2024-12-17 10:44:02 --> Helper loaded: cookie_helper
INFO - 2024-12-17 10:44:02 --> Final output sent to browser
DEBUG - 2024-12-17 10:44:02 --> Total execution time: 0.0460
INFO - 2024-12-17 10:44:02 --> Config Class Initialized
INFO - 2024-12-17 10:44:02 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:44:02 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:44:02 --> Utf8 Class Initialized
INFO - 2024-12-17 10:44:02 --> URI Class Initialized
INFO - 2024-12-17 10:44:02 --> Router Class Initialized
INFO - 2024-12-17 10:44:02 --> Output Class Initialized
INFO - 2024-12-17 10:44:02 --> Security Class Initialized
DEBUG - 2024-12-17 10:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:44:02 --> Input Class Initialized
INFO - 2024-12-17 10:44:02 --> Language Class Initialized
INFO - 2024-12-17 10:44:02 --> Language Class Initialized
INFO - 2024-12-17 10:44:02 --> Config Class Initialized
INFO - 2024-12-17 10:44:02 --> Loader Class Initialized
INFO - 2024-12-17 10:44:02 --> Helper loaded: url_helper
INFO - 2024-12-17 10:44:02 --> Helper loaded: file_helper
INFO - 2024-12-17 10:44:02 --> Helper loaded: form_helper
INFO - 2024-12-17 10:44:02 --> Helper loaded: my_helper
INFO - 2024-12-17 10:44:02 --> Database Driver Class Initialized
INFO - 2024-12-17 10:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:44:02 --> Controller Class Initialized
DEBUG - 2024-12-17 10:44:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-12-17 10:44:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 10:44:02 --> Final output sent to browser
DEBUG - 2024-12-17 10:44:02 --> Total execution time: 0.0967
INFO - 2024-12-17 10:44:04 --> Config Class Initialized
INFO - 2024-12-17 10:44:04 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:44:04 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:44:04 --> Utf8 Class Initialized
INFO - 2024-12-17 10:44:04 --> URI Class Initialized
INFO - 2024-12-17 10:44:04 --> Router Class Initialized
INFO - 2024-12-17 10:44:04 --> Output Class Initialized
INFO - 2024-12-17 10:44:04 --> Security Class Initialized
DEBUG - 2024-12-17 10:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:44:04 --> Input Class Initialized
INFO - 2024-12-17 10:44:04 --> Language Class Initialized
INFO - 2024-12-17 10:44:04 --> Language Class Initialized
INFO - 2024-12-17 10:44:04 --> Config Class Initialized
INFO - 2024-12-17 10:44:04 --> Loader Class Initialized
INFO - 2024-12-17 10:44:04 --> Helper loaded: url_helper
INFO - 2024-12-17 10:44:04 --> Helper loaded: file_helper
INFO - 2024-12-17 10:44:04 --> Helper loaded: form_helper
INFO - 2024-12-17 10:44:04 --> Helper loaded: my_helper
INFO - 2024-12-17 10:44:04 --> Database Driver Class Initialized
INFO - 2024-12-17 10:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:44:04 --> Controller Class Initialized
DEBUG - 2024-12-17 10:44:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-17 10:44:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 10:44:04 --> Final output sent to browser
DEBUG - 2024-12-17 10:44:04 --> Total execution time: 0.0446
INFO - 2024-12-17 10:44:18 --> Config Class Initialized
INFO - 2024-12-17 10:44:18 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:44:18 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:44:18 --> Utf8 Class Initialized
INFO - 2024-12-17 10:44:18 --> URI Class Initialized
INFO - 2024-12-17 10:44:19 --> Router Class Initialized
INFO - 2024-12-17 10:44:19 --> Output Class Initialized
INFO - 2024-12-17 10:44:19 --> Security Class Initialized
DEBUG - 2024-12-17 10:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:44:19 --> Input Class Initialized
INFO - 2024-12-17 10:44:19 --> Language Class Initialized
INFO - 2024-12-17 10:44:19 --> Language Class Initialized
INFO - 2024-12-17 10:44:19 --> Config Class Initialized
INFO - 2024-12-17 10:44:19 --> Loader Class Initialized
INFO - 2024-12-17 10:44:19 --> Helper loaded: url_helper
INFO - 2024-12-17 10:44:19 --> Helper loaded: file_helper
INFO - 2024-12-17 10:44:19 --> Helper loaded: form_helper
INFO - 2024-12-17 10:44:19 --> Helper loaded: my_helper
INFO - 2024-12-17 10:44:19 --> Database Driver Class Initialized
INFO - 2024-12-17 10:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:44:19 --> Controller Class Initialized
INFO - 2024-12-17 10:44:19 --> Helper loaded: cookie_helper
INFO - 2024-12-17 10:44:19 --> Config Class Initialized
INFO - 2024-12-17 10:44:19 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:44:19 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:44:19 --> Utf8 Class Initialized
INFO - 2024-12-17 10:44:19 --> URI Class Initialized
INFO - 2024-12-17 10:44:19 --> Router Class Initialized
INFO - 2024-12-17 10:44:19 --> Output Class Initialized
INFO - 2024-12-17 10:44:19 --> Security Class Initialized
DEBUG - 2024-12-17 10:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:44:19 --> Input Class Initialized
INFO - 2024-12-17 10:44:19 --> Language Class Initialized
INFO - 2024-12-17 10:44:19 --> Language Class Initialized
INFO - 2024-12-17 10:44:19 --> Config Class Initialized
INFO - 2024-12-17 10:44:19 --> Loader Class Initialized
INFO - 2024-12-17 10:44:19 --> Helper loaded: url_helper
INFO - 2024-12-17 10:44:19 --> Helper loaded: file_helper
INFO - 2024-12-17 10:44:19 --> Helper loaded: form_helper
INFO - 2024-12-17 10:44:19 --> Helper loaded: my_helper
INFO - 2024-12-17 10:44:19 --> Database Driver Class Initialized
INFO - 2024-12-17 10:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:44:19 --> Controller Class Initialized
INFO - 2024-12-17 10:44:19 --> Config Class Initialized
INFO - 2024-12-17 10:44:19 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:44:19 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:44:19 --> Utf8 Class Initialized
INFO - 2024-12-17 10:44:19 --> URI Class Initialized
INFO - 2024-12-17 10:44:19 --> Router Class Initialized
INFO - 2024-12-17 10:44:19 --> Output Class Initialized
INFO - 2024-12-17 10:44:19 --> Security Class Initialized
DEBUG - 2024-12-17 10:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:44:19 --> Input Class Initialized
INFO - 2024-12-17 10:44:19 --> Language Class Initialized
INFO - 2024-12-17 10:44:19 --> Language Class Initialized
INFO - 2024-12-17 10:44:19 --> Config Class Initialized
INFO - 2024-12-17 10:44:19 --> Loader Class Initialized
INFO - 2024-12-17 10:44:19 --> Helper loaded: url_helper
INFO - 2024-12-17 10:44:19 --> Helper loaded: file_helper
INFO - 2024-12-17 10:44:19 --> Helper loaded: form_helper
INFO - 2024-12-17 10:44:19 --> Helper loaded: my_helper
INFO - 2024-12-17 10:44:19 --> Database Driver Class Initialized
INFO - 2024-12-17 10:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:44:19 --> Controller Class Initialized
DEBUG - 2024-12-17 10:44:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-17 10:44:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 10:44:19 --> Final output sent to browser
DEBUG - 2024-12-17 10:44:19 --> Total execution time: 0.0781
INFO - 2024-12-17 10:44:23 --> Config Class Initialized
INFO - 2024-12-17 10:44:23 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:44:23 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:44:23 --> Utf8 Class Initialized
INFO - 2024-12-17 10:44:24 --> URI Class Initialized
INFO - 2024-12-17 10:44:24 --> Router Class Initialized
INFO - 2024-12-17 10:44:24 --> Output Class Initialized
INFO - 2024-12-17 10:44:24 --> Security Class Initialized
DEBUG - 2024-12-17 10:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:44:24 --> Input Class Initialized
INFO - 2024-12-17 10:44:24 --> Language Class Initialized
INFO - 2024-12-17 10:44:24 --> Language Class Initialized
INFO - 2024-12-17 10:44:24 --> Config Class Initialized
INFO - 2024-12-17 10:44:24 --> Loader Class Initialized
INFO - 2024-12-17 10:44:24 --> Helper loaded: url_helper
INFO - 2024-12-17 10:44:24 --> Helper loaded: file_helper
INFO - 2024-12-17 10:44:24 --> Helper loaded: form_helper
INFO - 2024-12-17 10:44:24 --> Helper loaded: my_helper
INFO - 2024-12-17 10:44:24 --> Database Driver Class Initialized
INFO - 2024-12-17 10:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:44:24 --> Controller Class Initialized
INFO - 2024-12-17 10:44:24 --> Helper loaded: cookie_helper
INFO - 2024-12-17 10:44:24 --> Final output sent to browser
DEBUG - 2024-12-17 10:44:24 --> Total execution time: 0.0476
INFO - 2024-12-17 10:44:24 --> Config Class Initialized
INFO - 2024-12-17 10:44:24 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:44:24 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:44:24 --> Utf8 Class Initialized
INFO - 2024-12-17 10:44:24 --> URI Class Initialized
INFO - 2024-12-17 10:44:24 --> Router Class Initialized
INFO - 2024-12-17 10:44:24 --> Output Class Initialized
INFO - 2024-12-17 10:44:24 --> Security Class Initialized
DEBUG - 2024-12-17 10:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:44:24 --> Input Class Initialized
INFO - 2024-12-17 10:44:24 --> Language Class Initialized
INFO - 2024-12-17 10:44:24 --> Language Class Initialized
INFO - 2024-12-17 10:44:24 --> Config Class Initialized
INFO - 2024-12-17 10:44:24 --> Loader Class Initialized
INFO - 2024-12-17 10:44:24 --> Helper loaded: url_helper
INFO - 2024-12-17 10:44:24 --> Helper loaded: file_helper
INFO - 2024-12-17 10:44:24 --> Helper loaded: form_helper
INFO - 2024-12-17 10:44:24 --> Helper loaded: my_helper
INFO - 2024-12-17 10:44:24 --> Database Driver Class Initialized
INFO - 2024-12-17 10:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:44:24 --> Controller Class Initialized
DEBUG - 2024-12-17 10:44:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-12-17 10:44:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 10:44:24 --> Final output sent to browser
DEBUG - 2024-12-17 10:44:24 --> Total execution time: 0.0447
INFO - 2024-12-17 10:44:33 --> Config Class Initialized
INFO - 2024-12-17 10:44:33 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:44:33 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:44:33 --> Utf8 Class Initialized
INFO - 2024-12-17 10:44:33 --> URI Class Initialized
INFO - 2024-12-17 10:44:33 --> Router Class Initialized
INFO - 2024-12-17 10:44:33 --> Output Class Initialized
INFO - 2024-12-17 10:44:33 --> Security Class Initialized
DEBUG - 2024-12-17 10:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:44:33 --> Input Class Initialized
INFO - 2024-12-17 10:44:33 --> Language Class Initialized
INFO - 2024-12-17 10:44:33 --> Language Class Initialized
INFO - 2024-12-17 10:44:33 --> Config Class Initialized
INFO - 2024-12-17 10:44:33 --> Loader Class Initialized
INFO - 2024-12-17 10:44:33 --> Helper loaded: url_helper
INFO - 2024-12-17 10:44:33 --> Helper loaded: file_helper
INFO - 2024-12-17 10:44:33 --> Helper loaded: form_helper
INFO - 2024-12-17 10:44:33 --> Helper loaded: my_helper
INFO - 2024-12-17 10:44:33 --> Database Driver Class Initialized
INFO - 2024-12-17 10:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:44:33 --> Controller Class Initialized
DEBUG - 2024-12-17 10:44:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-12-17 10:44:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 10:44:33 --> Final output sent to browser
DEBUG - 2024-12-17 10:44:33 --> Total execution time: 0.0311
INFO - 2024-12-17 10:44:33 --> Config Class Initialized
INFO - 2024-12-17 10:44:33 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:44:33 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:44:33 --> Utf8 Class Initialized
INFO - 2024-12-17 10:44:33 --> URI Class Initialized
INFO - 2024-12-17 10:44:33 --> Router Class Initialized
INFO - 2024-12-17 10:44:33 --> Output Class Initialized
INFO - 2024-12-17 10:44:33 --> Security Class Initialized
DEBUG - 2024-12-17 10:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:44:33 --> Input Class Initialized
INFO - 2024-12-17 10:44:33 --> Language Class Initialized
ERROR - 2024-12-17 10:44:33 --> 404 Page Not Found: /index
INFO - 2024-12-17 10:44:33 --> Config Class Initialized
INFO - 2024-12-17 10:44:33 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:44:33 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:44:33 --> Utf8 Class Initialized
INFO - 2024-12-17 10:44:33 --> URI Class Initialized
INFO - 2024-12-17 10:44:33 --> Router Class Initialized
INFO - 2024-12-17 10:44:33 --> Output Class Initialized
INFO - 2024-12-17 10:44:33 --> Security Class Initialized
DEBUG - 2024-12-17 10:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:44:33 --> Input Class Initialized
INFO - 2024-12-17 10:44:33 --> Language Class Initialized
INFO - 2024-12-17 10:44:33 --> Language Class Initialized
INFO - 2024-12-17 10:44:33 --> Config Class Initialized
INFO - 2024-12-17 10:44:33 --> Loader Class Initialized
INFO - 2024-12-17 10:44:33 --> Helper loaded: url_helper
INFO - 2024-12-17 10:44:33 --> Helper loaded: file_helper
INFO - 2024-12-17 10:44:33 --> Helper loaded: form_helper
INFO - 2024-12-17 10:44:33 --> Helper loaded: my_helper
INFO - 2024-12-17 10:44:33 --> Database Driver Class Initialized
INFO - 2024-12-17 10:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:44:33 --> Controller Class Initialized
INFO - 2024-12-17 10:45:49 --> Config Class Initialized
INFO - 2024-12-17 10:45:49 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:45:49 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:45:49 --> Utf8 Class Initialized
INFO - 2024-12-17 10:45:49 --> URI Class Initialized
INFO - 2024-12-17 10:45:49 --> Router Class Initialized
INFO - 2024-12-17 10:45:49 --> Output Class Initialized
INFO - 2024-12-17 10:45:49 --> Security Class Initialized
DEBUG - 2024-12-17 10:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:45:49 --> Input Class Initialized
INFO - 2024-12-17 10:45:49 --> Language Class Initialized
INFO - 2024-12-17 10:45:49 --> Language Class Initialized
INFO - 2024-12-17 10:45:49 --> Config Class Initialized
INFO - 2024-12-17 10:45:49 --> Loader Class Initialized
INFO - 2024-12-17 10:45:49 --> Helper loaded: url_helper
INFO - 2024-12-17 10:45:49 --> Helper loaded: file_helper
INFO - 2024-12-17 10:45:49 --> Helper loaded: form_helper
INFO - 2024-12-17 10:45:49 --> Helper loaded: my_helper
INFO - 2024-12-17 10:45:49 --> Database Driver Class Initialized
INFO - 2024-12-17 10:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:45:49 --> Controller Class Initialized
DEBUG - 2024-12-17 10:45:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-17 10:45:52 --> Final output sent to browser
DEBUG - 2024-12-17 10:45:52 --> Total execution time: 2.3290
INFO - 2024-12-17 10:46:14 --> Config Class Initialized
INFO - 2024-12-17 10:46:14 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:46:14 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:46:14 --> Utf8 Class Initialized
INFO - 2024-12-17 10:46:14 --> URI Class Initialized
INFO - 2024-12-17 10:46:14 --> Router Class Initialized
INFO - 2024-12-17 10:46:14 --> Output Class Initialized
INFO - 2024-12-17 10:46:14 --> Security Class Initialized
DEBUG - 2024-12-17 10:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:46:14 --> Input Class Initialized
INFO - 2024-12-17 10:46:14 --> Language Class Initialized
INFO - 2024-12-17 10:46:14 --> Language Class Initialized
INFO - 2024-12-17 10:46:14 --> Config Class Initialized
INFO - 2024-12-17 10:46:14 --> Loader Class Initialized
INFO - 2024-12-17 10:46:14 --> Helper loaded: url_helper
INFO - 2024-12-17 10:46:14 --> Helper loaded: file_helper
INFO - 2024-12-17 10:46:14 --> Helper loaded: form_helper
INFO - 2024-12-17 10:46:14 --> Helper loaded: my_helper
INFO - 2024-12-17 10:46:14 --> Database Driver Class Initialized
INFO - 2024-12-17 10:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:46:14 --> Controller Class Initialized
DEBUG - 2024-12-17 10:46:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 10:46:24 --> Final output sent to browser
DEBUG - 2024-12-17 10:46:24 --> Total execution time: 10.7809
INFO - 2024-12-17 10:46:39 --> Config Class Initialized
INFO - 2024-12-17 10:46:39 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:46:39 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:46:39 --> Utf8 Class Initialized
INFO - 2024-12-17 10:46:39 --> URI Class Initialized
INFO - 2024-12-17 10:46:39 --> Router Class Initialized
INFO - 2024-12-17 10:46:39 --> Output Class Initialized
INFO - 2024-12-17 10:46:39 --> Security Class Initialized
DEBUG - 2024-12-17 10:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:46:39 --> Input Class Initialized
INFO - 2024-12-17 10:46:39 --> Language Class Initialized
INFO - 2024-12-17 10:46:39 --> Language Class Initialized
INFO - 2024-12-17 10:46:39 --> Config Class Initialized
INFO - 2024-12-17 10:46:39 --> Loader Class Initialized
INFO - 2024-12-17 10:46:39 --> Helper loaded: url_helper
INFO - 2024-12-17 10:46:39 --> Helper loaded: file_helper
INFO - 2024-12-17 10:46:39 --> Helper loaded: form_helper
INFO - 2024-12-17 10:46:39 --> Helper loaded: my_helper
INFO - 2024-12-17 10:46:39 --> Database Driver Class Initialized
INFO - 2024-12-17 10:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:46:40 --> Controller Class Initialized
INFO - 2024-12-17 10:46:40 --> Helper loaded: cookie_helper
INFO - 2024-12-17 10:46:40 --> Final output sent to browser
DEBUG - 2024-12-17 10:46:40 --> Total execution time: 0.1469
INFO - 2024-12-17 10:46:40 --> Config Class Initialized
INFO - 2024-12-17 10:46:40 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:46:40 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:46:40 --> Utf8 Class Initialized
INFO - 2024-12-17 10:46:40 --> URI Class Initialized
INFO - 2024-12-17 10:46:40 --> Router Class Initialized
INFO - 2024-12-17 10:46:40 --> Output Class Initialized
INFO - 2024-12-17 10:46:40 --> Security Class Initialized
DEBUG - 2024-12-17 10:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:46:40 --> Input Class Initialized
INFO - 2024-12-17 10:46:40 --> Language Class Initialized
INFO - 2024-12-17 10:46:40 --> Language Class Initialized
INFO - 2024-12-17 10:46:40 --> Config Class Initialized
INFO - 2024-12-17 10:46:40 --> Loader Class Initialized
INFO - 2024-12-17 10:46:40 --> Helper loaded: url_helper
INFO - 2024-12-17 10:46:40 --> Helper loaded: file_helper
INFO - 2024-12-17 10:46:40 --> Helper loaded: form_helper
INFO - 2024-12-17 10:46:40 --> Helper loaded: my_helper
INFO - 2024-12-17 10:46:40 --> Database Driver Class Initialized
INFO - 2024-12-17 10:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:46:40 --> Controller Class Initialized
INFO - 2024-12-17 10:46:40 --> Helper loaded: cookie_helper
INFO - 2024-12-17 10:46:40 --> Config Class Initialized
INFO - 2024-12-17 10:46:40 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:46:40 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:46:40 --> Utf8 Class Initialized
INFO - 2024-12-17 10:46:40 --> URI Class Initialized
INFO - 2024-12-17 10:46:40 --> Router Class Initialized
INFO - 2024-12-17 10:46:40 --> Output Class Initialized
INFO - 2024-12-17 10:46:40 --> Security Class Initialized
DEBUG - 2024-12-17 10:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:46:40 --> Input Class Initialized
INFO - 2024-12-17 10:46:40 --> Language Class Initialized
INFO - 2024-12-17 10:46:40 --> Language Class Initialized
INFO - 2024-12-17 10:46:40 --> Config Class Initialized
INFO - 2024-12-17 10:46:40 --> Loader Class Initialized
INFO - 2024-12-17 10:46:40 --> Helper loaded: url_helper
INFO - 2024-12-17 10:46:40 --> Helper loaded: file_helper
INFO - 2024-12-17 10:46:40 --> Helper loaded: form_helper
INFO - 2024-12-17 10:46:40 --> Helper loaded: my_helper
INFO - 2024-12-17 10:46:40 --> Database Driver Class Initialized
INFO - 2024-12-17 10:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:46:40 --> Controller Class Initialized
DEBUG - 2024-12-17 10:46:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-17 10:46:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 10:46:40 --> Final output sent to browser
DEBUG - 2024-12-17 10:46:40 --> Total execution time: 0.0422
INFO - 2024-12-17 10:47:03 --> Config Class Initialized
INFO - 2024-12-17 10:47:03 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:47:03 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:47:03 --> Utf8 Class Initialized
INFO - 2024-12-17 10:47:03 --> URI Class Initialized
INFO - 2024-12-17 10:47:03 --> Router Class Initialized
INFO - 2024-12-17 10:47:03 --> Output Class Initialized
INFO - 2024-12-17 10:47:03 --> Security Class Initialized
DEBUG - 2024-12-17 10:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:47:03 --> Input Class Initialized
INFO - 2024-12-17 10:47:03 --> Language Class Initialized
INFO - 2024-12-17 10:47:03 --> Language Class Initialized
INFO - 2024-12-17 10:47:03 --> Config Class Initialized
INFO - 2024-12-17 10:47:03 --> Loader Class Initialized
INFO - 2024-12-17 10:47:03 --> Helper loaded: url_helper
INFO - 2024-12-17 10:47:03 --> Helper loaded: file_helper
INFO - 2024-12-17 10:47:04 --> Helper loaded: form_helper
INFO - 2024-12-17 10:47:04 --> Helper loaded: my_helper
INFO - 2024-12-17 10:47:04 --> Database Driver Class Initialized
INFO - 2024-12-17 10:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:47:04 --> Controller Class Initialized
DEBUG - 2024-12-17 10:47:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 10:47:09 --> Final output sent to browser
DEBUG - 2024-12-17 10:47:09 --> Total execution time: 5.5595
INFO - 2024-12-17 10:47:46 --> Config Class Initialized
INFO - 2024-12-17 10:47:46 --> Hooks Class Initialized
DEBUG - 2024-12-17 10:47:46 --> UTF-8 Support Enabled
INFO - 2024-12-17 10:47:46 --> Utf8 Class Initialized
INFO - 2024-12-17 10:47:46 --> URI Class Initialized
INFO - 2024-12-17 10:47:46 --> Router Class Initialized
INFO - 2024-12-17 10:47:46 --> Output Class Initialized
INFO - 2024-12-17 10:47:46 --> Security Class Initialized
DEBUG - 2024-12-17 10:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 10:47:46 --> Input Class Initialized
INFO - 2024-12-17 10:47:46 --> Language Class Initialized
INFO - 2024-12-17 10:47:46 --> Language Class Initialized
INFO - 2024-12-17 10:47:46 --> Config Class Initialized
INFO - 2024-12-17 10:47:46 --> Loader Class Initialized
INFO - 2024-12-17 10:47:46 --> Helper loaded: url_helper
INFO - 2024-12-17 10:47:46 --> Helper loaded: file_helper
INFO - 2024-12-17 10:47:46 --> Helper loaded: form_helper
INFO - 2024-12-17 10:47:46 --> Helper loaded: my_helper
INFO - 2024-12-17 10:47:46 --> Database Driver Class Initialized
INFO - 2024-12-17 10:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 10:47:46 --> Controller Class Initialized
DEBUG - 2024-12-17 10:47:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-17 10:47:51 --> Final output sent to browser
DEBUG - 2024-12-17 10:47:51 --> Total execution time: 5.2195
INFO - 2024-12-17 11:17:39 --> Config Class Initialized
INFO - 2024-12-17 11:17:39 --> Hooks Class Initialized
DEBUG - 2024-12-17 11:17:39 --> UTF-8 Support Enabled
INFO - 2024-12-17 11:17:39 --> Utf8 Class Initialized
INFO - 2024-12-17 11:17:39 --> URI Class Initialized
INFO - 2024-12-17 11:17:39 --> Router Class Initialized
INFO - 2024-12-17 11:17:39 --> Output Class Initialized
INFO - 2024-12-17 11:17:39 --> Security Class Initialized
DEBUG - 2024-12-17 11:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 11:17:39 --> Input Class Initialized
INFO - 2024-12-17 11:17:39 --> Language Class Initialized
INFO - 2024-12-17 11:17:39 --> Language Class Initialized
INFO - 2024-12-17 11:17:39 --> Config Class Initialized
INFO - 2024-12-17 11:17:39 --> Loader Class Initialized
INFO - 2024-12-17 11:17:39 --> Helper loaded: url_helper
INFO - 2024-12-17 11:17:39 --> Helper loaded: file_helper
INFO - 2024-12-17 11:17:39 --> Helper loaded: form_helper
INFO - 2024-12-17 11:17:39 --> Helper loaded: my_helper
INFO - 2024-12-17 11:17:39 --> Database Driver Class Initialized
INFO - 2024-12-17 11:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 11:17:39 --> Controller Class Initialized
INFO - 2024-12-17 11:17:39 --> Helper loaded: cookie_helper
INFO - 2024-12-17 11:17:39 --> Final output sent to browser
DEBUG - 2024-12-17 11:17:39 --> Total execution time: 0.0752
INFO - 2024-12-17 11:17:40 --> Config Class Initialized
INFO - 2024-12-17 11:17:40 --> Hooks Class Initialized
DEBUG - 2024-12-17 11:17:40 --> UTF-8 Support Enabled
INFO - 2024-12-17 11:17:40 --> Utf8 Class Initialized
INFO - 2024-12-17 11:17:40 --> URI Class Initialized
INFO - 2024-12-17 11:17:40 --> Router Class Initialized
INFO - 2024-12-17 11:17:40 --> Output Class Initialized
INFO - 2024-12-17 11:17:40 --> Security Class Initialized
DEBUG - 2024-12-17 11:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 11:17:40 --> Input Class Initialized
INFO - 2024-12-17 11:17:40 --> Language Class Initialized
INFO - 2024-12-17 11:17:40 --> Language Class Initialized
INFO - 2024-12-17 11:17:40 --> Config Class Initialized
INFO - 2024-12-17 11:17:40 --> Loader Class Initialized
INFO - 2024-12-17 11:17:40 --> Helper loaded: url_helper
INFO - 2024-12-17 11:17:40 --> Helper loaded: file_helper
INFO - 2024-12-17 11:17:40 --> Helper loaded: form_helper
INFO - 2024-12-17 11:17:40 --> Helper loaded: my_helper
INFO - 2024-12-17 11:17:40 --> Database Driver Class Initialized
INFO - 2024-12-17 11:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 11:17:40 --> Controller Class Initialized
INFO - 2024-12-17 11:17:40 --> Helper loaded: cookie_helper
INFO - 2024-12-17 11:17:40 --> Config Class Initialized
INFO - 2024-12-17 11:17:40 --> Hooks Class Initialized
DEBUG - 2024-12-17 11:17:40 --> UTF-8 Support Enabled
INFO - 2024-12-17 11:17:40 --> Utf8 Class Initialized
INFO - 2024-12-17 11:17:40 --> URI Class Initialized
INFO - 2024-12-17 11:17:40 --> Router Class Initialized
INFO - 2024-12-17 11:17:40 --> Output Class Initialized
INFO - 2024-12-17 11:17:40 --> Security Class Initialized
DEBUG - 2024-12-17 11:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 11:17:40 --> Input Class Initialized
INFO - 2024-12-17 11:17:40 --> Language Class Initialized
INFO - 2024-12-17 11:17:40 --> Language Class Initialized
INFO - 2024-12-17 11:17:40 --> Config Class Initialized
INFO - 2024-12-17 11:17:40 --> Loader Class Initialized
INFO - 2024-12-17 11:17:40 --> Helper loaded: url_helper
INFO - 2024-12-17 11:17:40 --> Helper loaded: file_helper
INFO - 2024-12-17 11:17:40 --> Helper loaded: form_helper
INFO - 2024-12-17 11:17:40 --> Helper loaded: my_helper
INFO - 2024-12-17 11:17:40 --> Database Driver Class Initialized
INFO - 2024-12-17 11:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 11:17:40 --> Controller Class Initialized
DEBUG - 2024-12-17 11:17:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-17 11:17:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 11:17:40 --> Final output sent to browser
DEBUG - 2024-12-17 11:17:40 --> Total execution time: 0.0333
INFO - 2024-12-17 11:17:52 --> Config Class Initialized
INFO - 2024-12-17 11:17:52 --> Hooks Class Initialized
DEBUG - 2024-12-17 11:17:52 --> UTF-8 Support Enabled
INFO - 2024-12-17 11:17:52 --> Utf8 Class Initialized
INFO - 2024-12-17 11:17:52 --> URI Class Initialized
INFO - 2024-12-17 11:17:52 --> Router Class Initialized
INFO - 2024-12-17 11:17:52 --> Output Class Initialized
INFO - 2024-12-17 11:17:52 --> Security Class Initialized
DEBUG - 2024-12-17 11:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 11:17:52 --> Input Class Initialized
INFO - 2024-12-17 11:17:52 --> Language Class Initialized
INFO - 2024-12-17 11:17:52 --> Language Class Initialized
INFO - 2024-12-17 11:17:52 --> Config Class Initialized
INFO - 2024-12-17 11:17:52 --> Loader Class Initialized
INFO - 2024-12-17 11:17:52 --> Helper loaded: url_helper
INFO - 2024-12-17 11:17:52 --> Helper loaded: file_helper
INFO - 2024-12-17 11:17:52 --> Helper loaded: form_helper
INFO - 2024-12-17 11:17:52 --> Helper loaded: my_helper
INFO - 2024-12-17 11:17:52 --> Database Driver Class Initialized
INFO - 2024-12-17 11:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 11:17:52 --> Controller Class Initialized
DEBUG - 2024-12-17 11:17:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-17 11:17:56 --> Final output sent to browser
DEBUG - 2024-12-17 11:17:56 --> Total execution time: 3.8722
INFO - 2024-12-17 11:18:17 --> Config Class Initialized
INFO - 2024-12-17 11:18:17 --> Hooks Class Initialized
DEBUG - 2024-12-17 11:18:17 --> UTF-8 Support Enabled
INFO - 2024-12-17 11:18:17 --> Utf8 Class Initialized
INFO - 2024-12-17 11:18:17 --> URI Class Initialized
INFO - 2024-12-17 11:18:17 --> Router Class Initialized
INFO - 2024-12-17 11:18:17 --> Output Class Initialized
INFO - 2024-12-17 11:18:17 --> Security Class Initialized
DEBUG - 2024-12-17 11:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 11:18:17 --> Input Class Initialized
INFO - 2024-12-17 11:18:17 --> Language Class Initialized
INFO - 2024-12-17 11:18:17 --> Language Class Initialized
INFO - 2024-12-17 11:18:17 --> Config Class Initialized
INFO - 2024-12-17 11:18:17 --> Loader Class Initialized
INFO - 2024-12-17 11:18:17 --> Helper loaded: url_helper
INFO - 2024-12-17 11:18:17 --> Helper loaded: file_helper
INFO - 2024-12-17 11:18:17 --> Helper loaded: form_helper
INFO - 2024-12-17 11:18:17 --> Helper loaded: my_helper
INFO - 2024-12-17 11:18:18 --> Database Driver Class Initialized
INFO - 2024-12-17 11:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 11:18:18 --> Controller Class Initialized
DEBUG - 2024-12-17 11:18:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 11:18:24 --> Final output sent to browser
DEBUG - 2024-12-17 11:18:24 --> Total execution time: 6.5209
INFO - 2024-12-17 11:23:47 --> Config Class Initialized
INFO - 2024-12-17 11:23:47 --> Hooks Class Initialized
DEBUG - 2024-12-17 11:23:47 --> UTF-8 Support Enabled
INFO - 2024-12-17 11:23:47 --> Utf8 Class Initialized
INFO - 2024-12-17 11:23:47 --> URI Class Initialized
INFO - 2024-12-17 11:23:47 --> Router Class Initialized
INFO - 2024-12-17 11:23:47 --> Output Class Initialized
INFO - 2024-12-17 11:23:47 --> Security Class Initialized
DEBUG - 2024-12-17 11:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 11:23:47 --> Input Class Initialized
INFO - 2024-12-17 11:23:47 --> Language Class Initialized
INFO - 2024-12-17 11:23:47 --> Language Class Initialized
INFO - 2024-12-17 11:23:47 --> Config Class Initialized
INFO - 2024-12-17 11:23:47 --> Loader Class Initialized
INFO - 2024-12-17 11:23:47 --> Helper loaded: url_helper
INFO - 2024-12-17 11:23:47 --> Helper loaded: file_helper
INFO - 2024-12-17 11:23:47 --> Helper loaded: form_helper
INFO - 2024-12-17 11:23:47 --> Helper loaded: my_helper
INFO - 2024-12-17 11:23:47 --> Database Driver Class Initialized
INFO - 2024-12-17 11:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 11:23:47 --> Controller Class Initialized
DEBUG - 2024-12-17 11:23:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-17 11:23:49 --> Final output sent to browser
DEBUG - 2024-12-17 11:23:49 --> Total execution time: 2.5641
INFO - 2024-12-17 11:24:29 --> Config Class Initialized
INFO - 2024-12-17 11:24:29 --> Hooks Class Initialized
DEBUG - 2024-12-17 11:24:29 --> UTF-8 Support Enabled
INFO - 2024-12-17 11:24:29 --> Utf8 Class Initialized
INFO - 2024-12-17 11:24:29 --> URI Class Initialized
INFO - 2024-12-17 11:24:29 --> Router Class Initialized
INFO - 2024-12-17 11:24:29 --> Output Class Initialized
INFO - 2024-12-17 11:24:29 --> Security Class Initialized
DEBUG - 2024-12-17 11:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 11:24:29 --> Input Class Initialized
INFO - 2024-12-17 11:24:29 --> Language Class Initialized
INFO - 2024-12-17 11:24:29 --> Language Class Initialized
INFO - 2024-12-17 11:24:29 --> Config Class Initialized
INFO - 2024-12-17 11:24:29 --> Loader Class Initialized
INFO - 2024-12-17 11:24:29 --> Helper loaded: url_helper
INFO - 2024-12-17 11:24:29 --> Helper loaded: file_helper
INFO - 2024-12-17 11:24:29 --> Helper loaded: form_helper
INFO - 2024-12-17 11:24:29 --> Helper loaded: my_helper
INFO - 2024-12-17 11:24:29 --> Database Driver Class Initialized
INFO - 2024-12-17 11:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 11:24:29 --> Controller Class Initialized
DEBUG - 2024-12-17 11:24:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 11:24:36 --> Final output sent to browser
DEBUG - 2024-12-17 11:24:36 --> Total execution time: 6.7019
INFO - 2024-12-17 11:25:20 --> Config Class Initialized
INFO - 2024-12-17 11:25:20 --> Hooks Class Initialized
DEBUG - 2024-12-17 11:25:20 --> UTF-8 Support Enabled
INFO - 2024-12-17 11:25:20 --> Utf8 Class Initialized
INFO - 2024-12-17 11:25:20 --> URI Class Initialized
INFO - 2024-12-17 11:25:20 --> Router Class Initialized
INFO - 2024-12-17 11:25:20 --> Output Class Initialized
INFO - 2024-12-17 11:25:20 --> Security Class Initialized
DEBUG - 2024-12-17 11:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 11:25:20 --> Input Class Initialized
INFO - 2024-12-17 11:25:20 --> Language Class Initialized
INFO - 2024-12-17 11:25:20 --> Language Class Initialized
INFO - 2024-12-17 11:25:20 --> Config Class Initialized
INFO - 2024-12-17 11:25:20 --> Loader Class Initialized
INFO - 2024-12-17 11:25:20 --> Helper loaded: url_helper
INFO - 2024-12-17 11:25:20 --> Helper loaded: file_helper
INFO - 2024-12-17 11:25:20 --> Helper loaded: form_helper
INFO - 2024-12-17 11:25:20 --> Helper loaded: my_helper
INFO - 2024-12-17 11:25:20 --> Database Driver Class Initialized
INFO - 2024-12-17 11:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 11:25:20 --> Controller Class Initialized
DEBUG - 2024-12-17 11:25:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-17 11:25:24 --> Final output sent to browser
DEBUG - 2024-12-17 11:25:24 --> Total execution time: 4.3057
INFO - 2024-12-17 11:25:25 --> Config Class Initialized
INFO - 2024-12-17 11:25:25 --> Hooks Class Initialized
DEBUG - 2024-12-17 11:25:25 --> UTF-8 Support Enabled
INFO - 2024-12-17 11:25:25 --> Utf8 Class Initialized
INFO - 2024-12-17 11:25:25 --> URI Class Initialized
INFO - 2024-12-17 11:25:25 --> Router Class Initialized
INFO - 2024-12-17 11:25:25 --> Output Class Initialized
INFO - 2024-12-17 11:25:25 --> Security Class Initialized
DEBUG - 2024-12-17 11:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 11:25:25 --> Input Class Initialized
INFO - 2024-12-17 11:25:25 --> Language Class Initialized
INFO - 2024-12-17 11:25:25 --> Language Class Initialized
INFO - 2024-12-17 11:25:25 --> Config Class Initialized
INFO - 2024-12-17 11:25:25 --> Loader Class Initialized
INFO - 2024-12-17 11:25:25 --> Helper loaded: url_helper
INFO - 2024-12-17 11:25:25 --> Helper loaded: file_helper
INFO - 2024-12-17 11:25:25 --> Helper loaded: form_helper
INFO - 2024-12-17 11:25:25 --> Helper loaded: my_helper
INFO - 2024-12-17 11:25:25 --> Database Driver Class Initialized
INFO - 2024-12-17 11:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 11:25:25 --> Controller Class Initialized
INFO - 2024-12-17 11:25:26 --> Helper loaded: cookie_helper
INFO - 2024-12-17 11:25:26 --> Final output sent to browser
DEBUG - 2024-12-17 11:25:26 --> Total execution time: 0.0960
INFO - 2024-12-17 11:25:26 --> Config Class Initialized
INFO - 2024-12-17 11:25:26 --> Hooks Class Initialized
DEBUG - 2024-12-17 11:25:26 --> UTF-8 Support Enabled
INFO - 2024-12-17 11:25:26 --> Utf8 Class Initialized
INFO - 2024-12-17 11:25:26 --> URI Class Initialized
INFO - 2024-12-17 11:25:26 --> Router Class Initialized
INFO - 2024-12-17 11:25:26 --> Output Class Initialized
INFO - 2024-12-17 11:25:26 --> Security Class Initialized
DEBUG - 2024-12-17 11:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 11:25:26 --> Input Class Initialized
INFO - 2024-12-17 11:25:26 --> Language Class Initialized
INFO - 2024-12-17 11:25:26 --> Language Class Initialized
INFO - 2024-12-17 11:25:26 --> Config Class Initialized
INFO - 2024-12-17 11:25:26 --> Loader Class Initialized
INFO - 2024-12-17 11:25:26 --> Helper loaded: url_helper
INFO - 2024-12-17 11:25:26 --> Helper loaded: file_helper
INFO - 2024-12-17 11:25:26 --> Helper loaded: form_helper
INFO - 2024-12-17 11:25:26 --> Helper loaded: my_helper
INFO - 2024-12-17 11:25:26 --> Database Driver Class Initialized
INFO - 2024-12-17 11:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 11:25:26 --> Controller Class Initialized
INFO - 2024-12-17 11:25:26 --> Helper loaded: cookie_helper
INFO - 2024-12-17 11:25:26 --> Config Class Initialized
INFO - 2024-12-17 11:25:26 --> Hooks Class Initialized
DEBUG - 2024-12-17 11:25:27 --> UTF-8 Support Enabled
INFO - 2024-12-17 11:25:27 --> Utf8 Class Initialized
INFO - 2024-12-17 11:25:27 --> URI Class Initialized
INFO - 2024-12-17 11:25:27 --> Router Class Initialized
INFO - 2024-12-17 11:25:27 --> Output Class Initialized
INFO - 2024-12-17 11:25:27 --> Security Class Initialized
DEBUG - 2024-12-17 11:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 11:25:27 --> Input Class Initialized
INFO - 2024-12-17 11:25:27 --> Language Class Initialized
INFO - 2024-12-17 11:25:27 --> Language Class Initialized
INFO - 2024-12-17 11:25:27 --> Config Class Initialized
INFO - 2024-12-17 11:25:27 --> Loader Class Initialized
INFO - 2024-12-17 11:25:27 --> Helper loaded: url_helper
INFO - 2024-12-17 11:25:27 --> Helper loaded: file_helper
INFO - 2024-12-17 11:25:27 --> Helper loaded: form_helper
INFO - 2024-12-17 11:25:27 --> Helper loaded: my_helper
INFO - 2024-12-17 11:25:27 --> Database Driver Class Initialized
INFO - 2024-12-17 11:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 11:25:27 --> Controller Class Initialized
DEBUG - 2024-12-17 11:25:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-17 11:25:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 11:25:27 --> Final output sent to browser
DEBUG - 2024-12-17 11:25:27 --> Total execution time: 0.0494
INFO - 2024-12-17 11:25:33 --> Config Class Initialized
INFO - 2024-12-17 11:25:33 --> Hooks Class Initialized
DEBUG - 2024-12-17 11:25:33 --> UTF-8 Support Enabled
INFO - 2024-12-17 11:25:33 --> Utf8 Class Initialized
INFO - 2024-12-17 11:25:33 --> URI Class Initialized
INFO - 2024-12-17 11:25:33 --> Router Class Initialized
INFO - 2024-12-17 11:25:33 --> Output Class Initialized
INFO - 2024-12-17 11:25:33 --> Security Class Initialized
DEBUG - 2024-12-17 11:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 11:25:33 --> Input Class Initialized
INFO - 2024-12-17 11:25:33 --> Language Class Initialized
INFO - 2024-12-17 11:25:33 --> Language Class Initialized
INFO - 2024-12-17 11:25:33 --> Config Class Initialized
INFO - 2024-12-17 11:25:33 --> Loader Class Initialized
INFO - 2024-12-17 11:25:33 --> Helper loaded: url_helper
INFO - 2024-12-17 11:25:33 --> Helper loaded: file_helper
INFO - 2024-12-17 11:25:33 --> Helper loaded: form_helper
INFO - 2024-12-17 11:25:33 --> Helper loaded: my_helper
INFO - 2024-12-17 11:25:33 --> Database Driver Class Initialized
INFO - 2024-12-17 11:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 11:25:33 --> Controller Class Initialized
DEBUG - 2024-12-17 11:25:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 11:25:39 --> Final output sent to browser
DEBUG - 2024-12-17 11:25:39 --> Total execution time: 5.9218
INFO - 2024-12-17 11:28:08 --> Config Class Initialized
INFO - 2024-12-17 11:28:08 --> Hooks Class Initialized
DEBUG - 2024-12-17 11:28:08 --> UTF-8 Support Enabled
INFO - 2024-12-17 11:28:08 --> Utf8 Class Initialized
INFO - 2024-12-17 11:28:08 --> URI Class Initialized
INFO - 2024-12-17 11:28:08 --> Router Class Initialized
INFO - 2024-12-17 11:28:08 --> Output Class Initialized
INFO - 2024-12-17 11:28:08 --> Security Class Initialized
DEBUG - 2024-12-17 11:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 11:28:08 --> Input Class Initialized
INFO - 2024-12-17 11:28:08 --> Language Class Initialized
INFO - 2024-12-17 11:28:08 --> Language Class Initialized
INFO - 2024-12-17 11:28:08 --> Config Class Initialized
INFO - 2024-12-17 11:28:08 --> Loader Class Initialized
INFO - 2024-12-17 11:28:08 --> Helper loaded: url_helper
INFO - 2024-12-17 11:28:08 --> Helper loaded: file_helper
INFO - 2024-12-17 11:28:08 --> Helper loaded: form_helper
INFO - 2024-12-17 11:28:08 --> Helper loaded: my_helper
INFO - 2024-12-17 11:28:08 --> Database Driver Class Initialized
INFO - 2024-12-17 11:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 11:28:08 --> Controller Class Initialized
ERROR - 2024-12-17 11:28:08 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-12-17 11:28:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-12-17 11:28:13 --> Final output sent to browser
DEBUG - 2024-12-17 11:28:13 --> Total execution time: 4.4878
INFO - 2024-12-17 11:30:05 --> Config Class Initialized
INFO - 2024-12-17 11:30:05 --> Hooks Class Initialized
DEBUG - 2024-12-17 11:30:05 --> UTF-8 Support Enabled
INFO - 2024-12-17 11:30:05 --> Utf8 Class Initialized
INFO - 2024-12-17 11:30:05 --> URI Class Initialized
INFO - 2024-12-17 11:30:05 --> Router Class Initialized
INFO - 2024-12-17 11:30:05 --> Output Class Initialized
INFO - 2024-12-17 11:30:05 --> Security Class Initialized
DEBUG - 2024-12-17 11:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 11:30:05 --> Input Class Initialized
INFO - 2024-12-17 11:30:05 --> Language Class Initialized
INFO - 2024-12-17 11:30:05 --> Language Class Initialized
INFO - 2024-12-17 11:30:05 --> Config Class Initialized
INFO - 2024-12-17 11:30:05 --> Loader Class Initialized
INFO - 2024-12-17 11:30:05 --> Helper loaded: url_helper
INFO - 2024-12-17 11:30:05 --> Helper loaded: file_helper
INFO - 2024-12-17 11:30:05 --> Helper loaded: form_helper
INFO - 2024-12-17 11:30:05 --> Helper loaded: my_helper
INFO - 2024-12-17 11:30:05 --> Database Driver Class Initialized
INFO - 2024-12-17 11:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 11:30:05 --> Controller Class Initialized
DEBUG - 2024-12-17 11:30:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-17 11:30:08 --> Final output sent to browser
DEBUG - 2024-12-17 11:30:08 --> Total execution time: 2.6010
INFO - 2024-12-17 20:09:40 --> Config Class Initialized
INFO - 2024-12-17 20:09:40 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:09:40 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:09:40 --> Utf8 Class Initialized
INFO - 2024-12-17 20:09:40 --> URI Class Initialized
INFO - 2024-12-17 20:09:40 --> Router Class Initialized
INFO - 2024-12-17 20:09:40 --> Output Class Initialized
INFO - 2024-12-17 20:09:40 --> Security Class Initialized
DEBUG - 2024-12-17 20:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:09:40 --> Input Class Initialized
INFO - 2024-12-17 20:09:40 --> Language Class Initialized
INFO - 2024-12-17 20:09:40 --> Language Class Initialized
INFO - 2024-12-17 20:09:40 --> Config Class Initialized
INFO - 2024-12-17 20:09:40 --> Loader Class Initialized
INFO - 2024-12-17 20:09:40 --> Helper loaded: url_helper
INFO - 2024-12-17 20:09:40 --> Helper loaded: file_helper
INFO - 2024-12-17 20:09:40 --> Helper loaded: form_helper
INFO - 2024-12-17 20:09:40 --> Helper loaded: my_helper
INFO - 2024-12-17 20:09:40 --> Database Driver Class Initialized
INFO - 2024-12-17 20:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:09:40 --> Controller Class Initialized
INFO - 2024-12-17 20:09:40 --> Helper loaded: cookie_helper
INFO - 2024-12-17 20:09:40 --> Final output sent to browser
DEBUG - 2024-12-17 20:09:40 --> Total execution time: 0.0825
INFO - 2024-12-17 20:09:42 --> Config Class Initialized
INFO - 2024-12-17 20:09:42 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:09:42 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:09:42 --> Utf8 Class Initialized
INFO - 2024-12-17 20:09:42 --> URI Class Initialized
INFO - 2024-12-17 20:09:42 --> Router Class Initialized
INFO - 2024-12-17 20:09:42 --> Output Class Initialized
INFO - 2024-12-17 20:09:42 --> Security Class Initialized
DEBUG - 2024-12-17 20:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:09:42 --> Input Class Initialized
INFO - 2024-12-17 20:09:42 --> Language Class Initialized
INFO - 2024-12-17 20:09:42 --> Language Class Initialized
INFO - 2024-12-17 20:09:42 --> Config Class Initialized
INFO - 2024-12-17 20:09:42 --> Loader Class Initialized
INFO - 2024-12-17 20:09:42 --> Helper loaded: url_helper
INFO - 2024-12-17 20:09:42 --> Helper loaded: file_helper
INFO - 2024-12-17 20:09:42 --> Helper loaded: form_helper
INFO - 2024-12-17 20:09:42 --> Helper loaded: my_helper
INFO - 2024-12-17 20:09:42 --> Database Driver Class Initialized
INFO - 2024-12-17 20:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:09:42 --> Controller Class Initialized
INFO - 2024-12-17 20:09:42 --> Helper loaded: cookie_helper
INFO - 2024-12-17 20:09:42 --> Config Class Initialized
INFO - 2024-12-17 20:09:42 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:09:42 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:09:42 --> Utf8 Class Initialized
INFO - 2024-12-17 20:09:42 --> URI Class Initialized
INFO - 2024-12-17 20:09:42 --> Router Class Initialized
INFO - 2024-12-17 20:09:42 --> Output Class Initialized
INFO - 2024-12-17 20:09:42 --> Security Class Initialized
DEBUG - 2024-12-17 20:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:09:42 --> Input Class Initialized
INFO - 2024-12-17 20:09:42 --> Language Class Initialized
INFO - 2024-12-17 20:09:42 --> Language Class Initialized
INFO - 2024-12-17 20:09:42 --> Config Class Initialized
INFO - 2024-12-17 20:09:42 --> Loader Class Initialized
INFO - 2024-12-17 20:09:42 --> Helper loaded: url_helper
INFO - 2024-12-17 20:09:42 --> Helper loaded: file_helper
INFO - 2024-12-17 20:09:42 --> Helper loaded: form_helper
INFO - 2024-12-17 20:09:42 --> Helper loaded: my_helper
INFO - 2024-12-17 20:09:42 --> Database Driver Class Initialized
INFO - 2024-12-17 20:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:09:42 --> Controller Class Initialized
DEBUG - 2024-12-17 20:09:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-17 20:09:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 20:09:42 --> Final output sent to browser
DEBUG - 2024-12-17 20:09:42 --> Total execution time: 0.0500
INFO - 2024-12-17 20:09:47 --> Config Class Initialized
INFO - 2024-12-17 20:09:47 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:09:47 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:09:47 --> Utf8 Class Initialized
INFO - 2024-12-17 20:09:47 --> URI Class Initialized
INFO - 2024-12-17 20:09:47 --> Router Class Initialized
INFO - 2024-12-17 20:09:47 --> Output Class Initialized
INFO - 2024-12-17 20:09:47 --> Security Class Initialized
DEBUG - 2024-12-17 20:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:09:47 --> Input Class Initialized
INFO - 2024-12-17 20:09:47 --> Language Class Initialized
INFO - 2024-12-17 20:09:47 --> Language Class Initialized
INFO - 2024-12-17 20:09:47 --> Config Class Initialized
INFO - 2024-12-17 20:09:47 --> Loader Class Initialized
INFO - 2024-12-17 20:09:47 --> Helper loaded: url_helper
INFO - 2024-12-17 20:09:47 --> Helper loaded: file_helper
INFO - 2024-12-17 20:09:47 --> Helper loaded: form_helper
INFO - 2024-12-17 20:09:47 --> Helper loaded: my_helper
INFO - 2024-12-17 20:09:47 --> Database Driver Class Initialized
INFO - 2024-12-17 20:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:09:47 --> Controller Class Initialized
DEBUG - 2024-12-17 20:09:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:09:52 --> Final output sent to browser
DEBUG - 2024-12-17 20:09:52 --> Total execution time: 4.5738
INFO - 2024-12-17 20:10:15 --> Config Class Initialized
INFO - 2024-12-17 20:10:15 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:10:15 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:10:15 --> Utf8 Class Initialized
INFO - 2024-12-17 20:10:15 --> URI Class Initialized
INFO - 2024-12-17 20:10:15 --> Router Class Initialized
INFO - 2024-12-17 20:10:15 --> Output Class Initialized
INFO - 2024-12-17 20:10:15 --> Security Class Initialized
DEBUG - 2024-12-17 20:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:10:15 --> Input Class Initialized
INFO - 2024-12-17 20:10:15 --> Language Class Initialized
INFO - 2024-12-17 20:10:15 --> Language Class Initialized
INFO - 2024-12-17 20:10:15 --> Config Class Initialized
INFO - 2024-12-17 20:10:15 --> Loader Class Initialized
INFO - 2024-12-17 20:10:15 --> Helper loaded: url_helper
INFO - 2024-12-17 20:10:15 --> Helper loaded: file_helper
INFO - 2024-12-17 20:10:15 --> Helper loaded: form_helper
INFO - 2024-12-17 20:10:15 --> Helper loaded: my_helper
INFO - 2024-12-17 20:10:15 --> Database Driver Class Initialized
INFO - 2024-12-17 20:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:10:15 --> Controller Class Initialized
DEBUG - 2024-12-17 20:10:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-17 20:10:18 --> Final output sent to browser
DEBUG - 2024-12-17 20:10:18 --> Total execution time: 3.0863
INFO - 2024-12-17 20:11:54 --> Config Class Initialized
INFO - 2024-12-17 20:11:54 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:11:54 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:11:54 --> Utf8 Class Initialized
INFO - 2024-12-17 20:11:54 --> URI Class Initialized
INFO - 2024-12-17 20:11:54 --> Router Class Initialized
INFO - 2024-12-17 20:11:54 --> Output Class Initialized
INFO - 2024-12-17 20:11:54 --> Security Class Initialized
DEBUG - 2024-12-17 20:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:11:54 --> Input Class Initialized
INFO - 2024-12-17 20:11:54 --> Language Class Initialized
INFO - 2024-12-17 20:11:54 --> Language Class Initialized
INFO - 2024-12-17 20:11:54 --> Config Class Initialized
INFO - 2024-12-17 20:11:54 --> Loader Class Initialized
INFO - 2024-12-17 20:11:54 --> Helper loaded: url_helper
INFO - 2024-12-17 20:11:54 --> Helper loaded: file_helper
INFO - 2024-12-17 20:11:54 --> Helper loaded: form_helper
INFO - 2024-12-17 20:11:54 --> Helper loaded: my_helper
INFO - 2024-12-17 20:11:54 --> Database Driver Class Initialized
INFO - 2024-12-17 20:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:11:54 --> Controller Class Initialized
DEBUG - 2024-12-17 20:11:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-17 20:11:58 --> Final output sent to browser
DEBUG - 2024-12-17 20:11:58 --> Total execution time: 3.8263
INFO - 2024-12-17 20:12:24 --> Config Class Initialized
INFO - 2024-12-17 20:12:24 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:12:24 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:12:24 --> Utf8 Class Initialized
INFO - 2024-12-17 20:12:24 --> URI Class Initialized
INFO - 2024-12-17 20:12:24 --> Router Class Initialized
INFO - 2024-12-17 20:12:24 --> Output Class Initialized
INFO - 2024-12-17 20:12:24 --> Security Class Initialized
DEBUG - 2024-12-17 20:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:12:24 --> Input Class Initialized
INFO - 2024-12-17 20:12:24 --> Language Class Initialized
INFO - 2024-12-17 20:12:24 --> Language Class Initialized
INFO - 2024-12-17 20:12:24 --> Config Class Initialized
INFO - 2024-12-17 20:12:24 --> Loader Class Initialized
INFO - 2024-12-17 20:12:24 --> Helper loaded: url_helper
INFO - 2024-12-17 20:12:24 --> Helper loaded: file_helper
INFO - 2024-12-17 20:12:24 --> Helper loaded: form_helper
INFO - 2024-12-17 20:12:24 --> Helper loaded: my_helper
INFO - 2024-12-17 20:12:24 --> Database Driver Class Initialized
INFO - 2024-12-17 20:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:12:24 --> Controller Class Initialized
ERROR - 2024-12-17 20:12:24 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-12-17 20:12:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-12-17 20:12:27 --> Final output sent to browser
DEBUG - 2024-12-17 20:12:27 --> Total execution time: 3.3262
INFO - 2024-12-17 20:12:53 --> Config Class Initialized
INFO - 2024-12-17 20:12:53 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:12:53 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:12:53 --> Utf8 Class Initialized
INFO - 2024-12-17 20:12:53 --> URI Class Initialized
INFO - 2024-12-17 20:12:53 --> Router Class Initialized
INFO - 2024-12-17 20:12:53 --> Output Class Initialized
INFO - 2024-12-17 20:12:53 --> Security Class Initialized
DEBUG - 2024-12-17 20:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:12:53 --> Input Class Initialized
INFO - 2024-12-17 20:12:53 --> Language Class Initialized
INFO - 2024-12-17 20:12:53 --> Language Class Initialized
INFO - 2024-12-17 20:12:53 --> Config Class Initialized
INFO - 2024-12-17 20:12:53 --> Loader Class Initialized
INFO - 2024-12-17 20:12:53 --> Helper loaded: url_helper
INFO - 2024-12-17 20:12:53 --> Helper loaded: file_helper
INFO - 2024-12-17 20:12:53 --> Helper loaded: form_helper
INFO - 2024-12-17 20:12:53 --> Helper loaded: my_helper
INFO - 2024-12-17 20:12:53 --> Database Driver Class Initialized
INFO - 2024-12-17 20:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:12:53 --> Controller Class Initialized
DEBUG - 2024-12-17 20:12:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:12:57 --> Final output sent to browser
DEBUG - 2024-12-17 20:12:57 --> Total execution time: 4.6805
INFO - 2024-12-17 20:21:57 --> Config Class Initialized
INFO - 2024-12-17 20:21:57 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:21:57 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:21:57 --> Utf8 Class Initialized
INFO - 2024-12-17 20:21:57 --> URI Class Initialized
INFO - 2024-12-17 20:21:57 --> Router Class Initialized
INFO - 2024-12-17 20:21:57 --> Output Class Initialized
INFO - 2024-12-17 20:21:57 --> Security Class Initialized
DEBUG - 2024-12-17 20:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:21:57 --> Input Class Initialized
INFO - 2024-12-17 20:21:57 --> Language Class Initialized
INFO - 2024-12-17 20:21:57 --> Language Class Initialized
INFO - 2024-12-17 20:21:57 --> Config Class Initialized
INFO - 2024-12-17 20:21:57 --> Loader Class Initialized
INFO - 2024-12-17 20:21:57 --> Helper loaded: url_helper
INFO - 2024-12-17 20:21:57 --> Helper loaded: file_helper
INFO - 2024-12-17 20:21:57 --> Helper loaded: form_helper
INFO - 2024-12-17 20:21:57 --> Helper loaded: my_helper
INFO - 2024-12-17 20:21:57 --> Database Driver Class Initialized
INFO - 2024-12-17 20:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:21:57 --> Controller Class Initialized
DEBUG - 2024-12-17 20:21:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-17 20:21:59 --> Final output sent to browser
DEBUG - 2024-12-17 20:21:59 --> Total execution time: 1.8767
INFO - 2024-12-17 20:22:19 --> Config Class Initialized
INFO - 2024-12-17 20:22:19 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:22:19 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:22:19 --> Utf8 Class Initialized
INFO - 2024-12-17 20:22:19 --> URI Class Initialized
INFO - 2024-12-17 20:22:19 --> Router Class Initialized
INFO - 2024-12-17 20:22:19 --> Output Class Initialized
INFO - 2024-12-17 20:22:19 --> Security Class Initialized
DEBUG - 2024-12-17 20:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:22:19 --> Input Class Initialized
INFO - 2024-12-17 20:22:19 --> Language Class Initialized
INFO - 2024-12-17 20:22:19 --> Language Class Initialized
INFO - 2024-12-17 20:22:19 --> Config Class Initialized
INFO - 2024-12-17 20:22:19 --> Loader Class Initialized
INFO - 2024-12-17 20:22:19 --> Helper loaded: url_helper
INFO - 2024-12-17 20:22:19 --> Helper loaded: file_helper
INFO - 2024-12-17 20:22:19 --> Helper loaded: form_helper
INFO - 2024-12-17 20:22:19 --> Helper loaded: my_helper
INFO - 2024-12-17 20:22:19 --> Database Driver Class Initialized
INFO - 2024-12-17 20:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:22:19 --> Controller Class Initialized
DEBUG - 2024-12-17 20:22:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-17 20:22:22 --> Final output sent to browser
DEBUG - 2024-12-17 20:22:22 --> Total execution time: 2.7571
INFO - 2024-12-17 20:52:41 --> Config Class Initialized
INFO - 2024-12-17 20:52:41 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:52:41 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:52:41 --> Utf8 Class Initialized
INFO - 2024-12-17 20:52:41 --> URI Class Initialized
INFO - 2024-12-17 20:52:41 --> Router Class Initialized
INFO - 2024-12-17 20:52:41 --> Output Class Initialized
INFO - 2024-12-17 20:52:41 --> Security Class Initialized
DEBUG - 2024-12-17 20:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:52:41 --> Input Class Initialized
INFO - 2024-12-17 20:52:41 --> Language Class Initialized
INFO - 2024-12-17 20:52:41 --> Language Class Initialized
INFO - 2024-12-17 20:52:41 --> Config Class Initialized
INFO - 2024-12-17 20:52:41 --> Loader Class Initialized
INFO - 2024-12-17 20:52:41 --> Helper loaded: url_helper
INFO - 2024-12-17 20:52:41 --> Helper loaded: file_helper
INFO - 2024-12-17 20:52:41 --> Helper loaded: form_helper
INFO - 2024-12-17 20:52:41 --> Helper loaded: my_helper
INFO - 2024-12-17 20:52:41 --> Database Driver Class Initialized
INFO - 2024-12-17 20:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:52:41 --> Controller Class Initialized
INFO - 2024-12-17 20:52:41 --> Helper loaded: cookie_helper
INFO - 2024-12-17 20:52:41 --> Final output sent to browser
DEBUG - 2024-12-17 20:52:41 --> Total execution time: 0.0375
INFO - 2024-12-17 20:52:42 --> Config Class Initialized
INFO - 2024-12-17 20:52:42 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:52:42 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:52:42 --> Utf8 Class Initialized
INFO - 2024-12-17 20:52:42 --> URI Class Initialized
INFO - 2024-12-17 20:52:42 --> Router Class Initialized
INFO - 2024-12-17 20:52:42 --> Output Class Initialized
INFO - 2024-12-17 20:52:42 --> Security Class Initialized
DEBUG - 2024-12-17 20:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:52:42 --> Input Class Initialized
INFO - 2024-12-17 20:52:42 --> Language Class Initialized
INFO - 2024-12-17 20:52:42 --> Language Class Initialized
INFO - 2024-12-17 20:52:42 --> Config Class Initialized
INFO - 2024-12-17 20:52:42 --> Loader Class Initialized
INFO - 2024-12-17 20:52:42 --> Helper loaded: url_helper
INFO - 2024-12-17 20:52:42 --> Helper loaded: file_helper
INFO - 2024-12-17 20:52:42 --> Helper loaded: form_helper
INFO - 2024-12-17 20:52:42 --> Helper loaded: my_helper
INFO - 2024-12-17 20:52:42 --> Database Driver Class Initialized
INFO - 2024-12-17 20:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:52:42 --> Controller Class Initialized
INFO - 2024-12-17 20:52:42 --> Helper loaded: cookie_helper
INFO - 2024-12-17 20:52:42 --> Config Class Initialized
INFO - 2024-12-17 20:52:42 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:52:42 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:52:42 --> Utf8 Class Initialized
INFO - 2024-12-17 20:52:42 --> URI Class Initialized
INFO - 2024-12-17 20:52:42 --> Router Class Initialized
INFO - 2024-12-17 20:52:42 --> Output Class Initialized
INFO - 2024-12-17 20:52:42 --> Security Class Initialized
DEBUG - 2024-12-17 20:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:52:42 --> Input Class Initialized
INFO - 2024-12-17 20:52:42 --> Language Class Initialized
INFO - 2024-12-17 20:52:42 --> Language Class Initialized
INFO - 2024-12-17 20:52:42 --> Config Class Initialized
INFO - 2024-12-17 20:52:42 --> Loader Class Initialized
INFO - 2024-12-17 20:52:42 --> Helper loaded: url_helper
INFO - 2024-12-17 20:52:42 --> Helper loaded: file_helper
INFO - 2024-12-17 20:52:42 --> Helper loaded: form_helper
INFO - 2024-12-17 20:52:42 --> Helper loaded: my_helper
INFO - 2024-12-17 20:52:42 --> Database Driver Class Initialized
INFO - 2024-12-17 20:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:52:42 --> Controller Class Initialized
DEBUG - 2024-12-17 20:52:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-17 20:52:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-17 20:52:42 --> Final output sent to browser
DEBUG - 2024-12-17 20:52:42 --> Total execution time: 0.0346
INFO - 2024-12-17 20:52:51 --> Config Class Initialized
INFO - 2024-12-17 20:52:51 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:52:51 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:52:51 --> Utf8 Class Initialized
INFO - 2024-12-17 20:52:51 --> URI Class Initialized
INFO - 2024-12-17 20:52:51 --> Router Class Initialized
INFO - 2024-12-17 20:52:51 --> Output Class Initialized
INFO - 2024-12-17 20:52:51 --> Security Class Initialized
DEBUG - 2024-12-17 20:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:52:51 --> Input Class Initialized
INFO - 2024-12-17 20:52:51 --> Language Class Initialized
INFO - 2024-12-17 20:52:51 --> Language Class Initialized
INFO - 2024-12-17 20:52:51 --> Config Class Initialized
INFO - 2024-12-17 20:52:51 --> Loader Class Initialized
INFO - 2024-12-17 20:52:51 --> Helper loaded: url_helper
INFO - 2024-12-17 20:52:51 --> Helper loaded: file_helper
INFO - 2024-12-17 20:52:51 --> Helper loaded: form_helper
INFO - 2024-12-17 20:52:51 --> Helper loaded: my_helper
INFO - 2024-12-17 20:52:51 --> Database Driver Class Initialized
INFO - 2024-12-17 20:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:52:51 --> Controller Class Initialized
DEBUG - 2024-12-17 20:52:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:52:56 --> Final output sent to browser
DEBUG - 2024-12-17 20:52:56 --> Total execution time: 4.3926
INFO - 2024-12-17 20:52:56 --> Config Class Initialized
INFO - 2024-12-17 20:52:56 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:52:56 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:52:56 --> Utf8 Class Initialized
INFO - 2024-12-17 20:52:56 --> URI Class Initialized
INFO - 2024-12-17 20:52:56 --> Router Class Initialized
INFO - 2024-12-17 20:52:56 --> Output Class Initialized
INFO - 2024-12-17 20:52:56 --> Security Class Initialized
DEBUG - 2024-12-17 20:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:52:56 --> Input Class Initialized
INFO - 2024-12-17 20:52:56 --> Language Class Initialized
INFO - 2024-12-17 20:52:56 --> Language Class Initialized
INFO - 2024-12-17 20:52:56 --> Config Class Initialized
INFO - 2024-12-17 20:52:56 --> Loader Class Initialized
INFO - 2024-12-17 20:52:56 --> Helper loaded: url_helper
INFO - 2024-12-17 20:52:56 --> Helper loaded: file_helper
INFO - 2024-12-17 20:52:56 --> Helper loaded: form_helper
INFO - 2024-12-17 20:52:56 --> Helper loaded: my_helper
INFO - 2024-12-17 20:52:56 --> Database Driver Class Initialized
INFO - 2024-12-17 20:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:52:56 --> Controller Class Initialized
DEBUG - 2024-12-17 20:52:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:52:57 --> Config Class Initialized
INFO - 2024-12-17 20:52:57 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:52:57 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:52:57 --> Utf8 Class Initialized
INFO - 2024-12-17 20:52:57 --> URI Class Initialized
INFO - 2024-12-17 20:52:57 --> Router Class Initialized
INFO - 2024-12-17 20:52:57 --> Output Class Initialized
INFO - 2024-12-17 20:52:57 --> Security Class Initialized
DEBUG - 2024-12-17 20:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:52:57 --> Input Class Initialized
INFO - 2024-12-17 20:52:57 --> Language Class Initialized
INFO - 2024-12-17 20:52:57 --> Language Class Initialized
INFO - 2024-12-17 20:52:57 --> Config Class Initialized
INFO - 2024-12-17 20:52:57 --> Loader Class Initialized
INFO - 2024-12-17 20:52:57 --> Helper loaded: url_helper
INFO - 2024-12-17 20:52:57 --> Helper loaded: file_helper
INFO - 2024-12-17 20:52:57 --> Helper loaded: form_helper
INFO - 2024-12-17 20:52:57 --> Helper loaded: my_helper
INFO - 2024-12-17 20:52:57 --> Database Driver Class Initialized
INFO - 2024-12-17 20:53:00 --> Final output sent to browser
DEBUG - 2024-12-17 20:53:00 --> Total execution time: 4.2065
INFO - 2024-12-17 20:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:53:00 --> Controller Class Initialized
DEBUG - 2024-12-17 20:53:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:53:00 --> Config Class Initialized
INFO - 2024-12-17 20:53:00 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:53:00 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:53:00 --> Utf8 Class Initialized
INFO - 2024-12-17 20:53:00 --> URI Class Initialized
INFO - 2024-12-17 20:53:00 --> Router Class Initialized
INFO - 2024-12-17 20:53:00 --> Output Class Initialized
INFO - 2024-12-17 20:53:00 --> Security Class Initialized
DEBUG - 2024-12-17 20:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:53:00 --> Input Class Initialized
INFO - 2024-12-17 20:53:00 --> Language Class Initialized
INFO - 2024-12-17 20:53:00 --> Language Class Initialized
INFO - 2024-12-17 20:53:00 --> Config Class Initialized
INFO - 2024-12-17 20:53:00 --> Loader Class Initialized
INFO - 2024-12-17 20:53:00 --> Helper loaded: url_helper
INFO - 2024-12-17 20:53:00 --> Helper loaded: file_helper
INFO - 2024-12-17 20:53:00 --> Helper loaded: form_helper
INFO - 2024-12-17 20:53:00 --> Helper loaded: my_helper
INFO - 2024-12-17 20:53:00 --> Database Driver Class Initialized
INFO - 2024-12-17 20:53:05 --> Final output sent to browser
DEBUG - 2024-12-17 20:53:05 --> Total execution time: 7.7795
INFO - 2024-12-17 20:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:53:05 --> Controller Class Initialized
DEBUG - 2024-12-17 20:53:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:53:10 --> Final output sent to browser
DEBUG - 2024-12-17 20:53:10 --> Total execution time: 9.8197
INFO - 2024-12-17 20:53:10 --> Config Class Initialized
INFO - 2024-12-17 20:53:10 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:53:10 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:53:10 --> Utf8 Class Initialized
INFO - 2024-12-17 20:53:10 --> URI Class Initialized
INFO - 2024-12-17 20:53:10 --> Router Class Initialized
INFO - 2024-12-17 20:53:10 --> Output Class Initialized
INFO - 2024-12-17 20:53:10 --> Security Class Initialized
DEBUG - 2024-12-17 20:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:53:10 --> Input Class Initialized
INFO - 2024-12-17 20:53:10 --> Language Class Initialized
INFO - 2024-12-17 20:53:10 --> Language Class Initialized
INFO - 2024-12-17 20:53:10 --> Config Class Initialized
INFO - 2024-12-17 20:53:10 --> Loader Class Initialized
INFO - 2024-12-17 20:53:10 --> Helper loaded: url_helper
INFO - 2024-12-17 20:53:10 --> Helper loaded: file_helper
INFO - 2024-12-17 20:53:10 --> Helper loaded: form_helper
INFO - 2024-12-17 20:53:10 --> Helper loaded: my_helper
INFO - 2024-12-17 20:53:10 --> Database Driver Class Initialized
INFO - 2024-12-17 20:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:53:10 --> Controller Class Initialized
DEBUG - 2024-12-17 20:53:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:53:15 --> Final output sent to browser
DEBUG - 2024-12-17 20:53:15 --> Total execution time: 4.6441
INFO - 2024-12-17 20:53:15 --> Config Class Initialized
INFO - 2024-12-17 20:53:15 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:53:15 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:53:15 --> Utf8 Class Initialized
INFO - 2024-12-17 20:53:15 --> URI Class Initialized
INFO - 2024-12-17 20:53:15 --> Router Class Initialized
INFO - 2024-12-17 20:53:15 --> Output Class Initialized
INFO - 2024-12-17 20:53:15 --> Security Class Initialized
DEBUG - 2024-12-17 20:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:53:15 --> Input Class Initialized
INFO - 2024-12-17 20:53:15 --> Language Class Initialized
INFO - 2024-12-17 20:53:15 --> Language Class Initialized
INFO - 2024-12-17 20:53:15 --> Config Class Initialized
INFO - 2024-12-17 20:53:15 --> Loader Class Initialized
INFO - 2024-12-17 20:53:15 --> Helper loaded: url_helper
INFO - 2024-12-17 20:53:15 --> Helper loaded: file_helper
INFO - 2024-12-17 20:53:15 --> Helper loaded: form_helper
INFO - 2024-12-17 20:53:15 --> Helper loaded: my_helper
INFO - 2024-12-17 20:53:15 --> Database Driver Class Initialized
INFO - 2024-12-17 20:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:53:15 --> Controller Class Initialized
DEBUG - 2024-12-17 20:53:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:53:20 --> Final output sent to browser
DEBUG - 2024-12-17 20:53:20 --> Total execution time: 4.7320
INFO - 2024-12-17 20:53:20 --> Config Class Initialized
INFO - 2024-12-17 20:53:20 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:53:20 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:53:20 --> Utf8 Class Initialized
INFO - 2024-12-17 20:53:20 --> URI Class Initialized
INFO - 2024-12-17 20:53:20 --> Router Class Initialized
INFO - 2024-12-17 20:53:20 --> Output Class Initialized
INFO - 2024-12-17 20:53:20 --> Security Class Initialized
DEBUG - 2024-12-17 20:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:53:20 --> Input Class Initialized
INFO - 2024-12-17 20:53:20 --> Language Class Initialized
INFO - 2024-12-17 20:53:20 --> Language Class Initialized
INFO - 2024-12-17 20:53:20 --> Config Class Initialized
INFO - 2024-12-17 20:53:20 --> Loader Class Initialized
INFO - 2024-12-17 20:53:20 --> Helper loaded: url_helper
INFO - 2024-12-17 20:53:20 --> Helper loaded: file_helper
INFO - 2024-12-17 20:53:20 --> Helper loaded: form_helper
INFO - 2024-12-17 20:53:20 --> Helper loaded: my_helper
INFO - 2024-12-17 20:53:20 --> Database Driver Class Initialized
INFO - 2024-12-17 20:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:53:20 --> Controller Class Initialized
DEBUG - 2024-12-17 20:53:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:53:25 --> Final output sent to browser
DEBUG - 2024-12-17 20:53:25 --> Total execution time: 4.9117
INFO - 2024-12-17 20:53:25 --> Config Class Initialized
INFO - 2024-12-17 20:53:25 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:53:25 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:53:25 --> Utf8 Class Initialized
INFO - 2024-12-17 20:53:25 --> URI Class Initialized
INFO - 2024-12-17 20:53:25 --> Router Class Initialized
INFO - 2024-12-17 20:53:25 --> Output Class Initialized
INFO - 2024-12-17 20:53:25 --> Security Class Initialized
DEBUG - 2024-12-17 20:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:53:25 --> Input Class Initialized
INFO - 2024-12-17 20:53:25 --> Language Class Initialized
INFO - 2024-12-17 20:53:25 --> Language Class Initialized
INFO - 2024-12-17 20:53:25 --> Config Class Initialized
INFO - 2024-12-17 20:53:25 --> Loader Class Initialized
INFO - 2024-12-17 20:53:25 --> Helper loaded: url_helper
INFO - 2024-12-17 20:53:25 --> Helper loaded: file_helper
INFO - 2024-12-17 20:53:25 --> Helper loaded: form_helper
INFO - 2024-12-17 20:53:25 --> Helper loaded: my_helper
INFO - 2024-12-17 20:53:25 --> Database Driver Class Initialized
INFO - 2024-12-17 20:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:53:25 --> Controller Class Initialized
DEBUG - 2024-12-17 20:53:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:53:29 --> Final output sent to browser
DEBUG - 2024-12-17 20:53:29 --> Total execution time: 4.5793
INFO - 2024-12-17 20:53:30 --> Config Class Initialized
INFO - 2024-12-17 20:53:30 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:53:30 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:53:30 --> Utf8 Class Initialized
INFO - 2024-12-17 20:53:30 --> URI Class Initialized
INFO - 2024-12-17 20:53:30 --> Router Class Initialized
INFO - 2024-12-17 20:53:30 --> Output Class Initialized
INFO - 2024-12-17 20:53:30 --> Security Class Initialized
DEBUG - 2024-12-17 20:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:53:30 --> Input Class Initialized
INFO - 2024-12-17 20:53:30 --> Language Class Initialized
INFO - 2024-12-17 20:53:30 --> Language Class Initialized
INFO - 2024-12-17 20:53:30 --> Config Class Initialized
INFO - 2024-12-17 20:53:30 --> Loader Class Initialized
INFO - 2024-12-17 20:53:30 --> Helper loaded: url_helper
INFO - 2024-12-17 20:53:30 --> Helper loaded: file_helper
INFO - 2024-12-17 20:53:30 --> Helper loaded: form_helper
INFO - 2024-12-17 20:53:30 --> Helper loaded: my_helper
INFO - 2024-12-17 20:53:30 --> Database Driver Class Initialized
INFO - 2024-12-17 20:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:53:30 --> Controller Class Initialized
DEBUG - 2024-12-17 20:53:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:53:34 --> Final output sent to browser
DEBUG - 2024-12-17 20:53:34 --> Total execution time: 4.3136
INFO - 2024-12-17 20:53:34 --> Config Class Initialized
INFO - 2024-12-17 20:53:34 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:53:34 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:53:34 --> Utf8 Class Initialized
INFO - 2024-12-17 20:53:34 --> URI Class Initialized
INFO - 2024-12-17 20:53:34 --> Router Class Initialized
INFO - 2024-12-17 20:53:34 --> Output Class Initialized
INFO - 2024-12-17 20:53:34 --> Security Class Initialized
DEBUG - 2024-12-17 20:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:53:34 --> Input Class Initialized
INFO - 2024-12-17 20:53:34 --> Language Class Initialized
INFO - 2024-12-17 20:53:34 --> Language Class Initialized
INFO - 2024-12-17 20:53:34 --> Config Class Initialized
INFO - 2024-12-17 20:53:34 --> Loader Class Initialized
INFO - 2024-12-17 20:53:34 --> Helper loaded: url_helper
INFO - 2024-12-17 20:53:34 --> Helper loaded: file_helper
INFO - 2024-12-17 20:53:34 --> Helper loaded: form_helper
INFO - 2024-12-17 20:53:34 --> Helper loaded: my_helper
INFO - 2024-12-17 20:53:34 --> Database Driver Class Initialized
INFO - 2024-12-17 20:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:53:34 --> Controller Class Initialized
DEBUG - 2024-12-17 20:53:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:53:39 --> Final output sent to browser
DEBUG - 2024-12-17 20:53:39 --> Total execution time: 4.4390
INFO - 2024-12-17 20:53:39 --> Config Class Initialized
INFO - 2024-12-17 20:53:39 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:53:39 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:53:39 --> Utf8 Class Initialized
INFO - 2024-12-17 20:53:39 --> URI Class Initialized
INFO - 2024-12-17 20:53:39 --> Router Class Initialized
INFO - 2024-12-17 20:53:39 --> Output Class Initialized
INFO - 2024-12-17 20:53:39 --> Security Class Initialized
DEBUG - 2024-12-17 20:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:53:39 --> Input Class Initialized
INFO - 2024-12-17 20:53:39 --> Language Class Initialized
INFO - 2024-12-17 20:53:39 --> Language Class Initialized
INFO - 2024-12-17 20:53:39 --> Config Class Initialized
INFO - 2024-12-17 20:53:39 --> Loader Class Initialized
INFO - 2024-12-17 20:53:39 --> Helper loaded: url_helper
INFO - 2024-12-17 20:53:39 --> Helper loaded: file_helper
INFO - 2024-12-17 20:53:39 --> Helper loaded: form_helper
INFO - 2024-12-17 20:53:39 --> Helper loaded: my_helper
INFO - 2024-12-17 20:53:39 --> Database Driver Class Initialized
INFO - 2024-12-17 20:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:53:39 --> Controller Class Initialized
DEBUG - 2024-12-17 20:53:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:53:44 --> Final output sent to browser
DEBUG - 2024-12-17 20:53:44 --> Total execution time: 4.7415
INFO - 2024-12-17 20:53:44 --> Config Class Initialized
INFO - 2024-12-17 20:53:44 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:53:44 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:53:44 --> Utf8 Class Initialized
INFO - 2024-12-17 20:53:44 --> URI Class Initialized
INFO - 2024-12-17 20:53:44 --> Router Class Initialized
INFO - 2024-12-17 20:53:44 --> Output Class Initialized
INFO - 2024-12-17 20:53:44 --> Security Class Initialized
DEBUG - 2024-12-17 20:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:53:44 --> Input Class Initialized
INFO - 2024-12-17 20:53:44 --> Language Class Initialized
INFO - 2024-12-17 20:53:44 --> Language Class Initialized
INFO - 2024-12-17 20:53:44 --> Config Class Initialized
INFO - 2024-12-17 20:53:44 --> Loader Class Initialized
INFO - 2024-12-17 20:53:44 --> Helper loaded: url_helper
INFO - 2024-12-17 20:53:44 --> Helper loaded: file_helper
INFO - 2024-12-17 20:53:44 --> Helper loaded: form_helper
INFO - 2024-12-17 20:53:44 --> Helper loaded: my_helper
INFO - 2024-12-17 20:53:44 --> Database Driver Class Initialized
INFO - 2024-12-17 20:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:53:44 --> Controller Class Initialized
DEBUG - 2024-12-17 20:53:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:53:48 --> Final output sent to browser
DEBUG - 2024-12-17 20:53:48 --> Total execution time: 4.5791
INFO - 2024-12-17 20:53:49 --> Config Class Initialized
INFO - 2024-12-17 20:53:49 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:53:49 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:53:49 --> Utf8 Class Initialized
INFO - 2024-12-17 20:53:49 --> URI Class Initialized
INFO - 2024-12-17 20:53:49 --> Router Class Initialized
INFO - 2024-12-17 20:53:49 --> Output Class Initialized
INFO - 2024-12-17 20:53:49 --> Security Class Initialized
DEBUG - 2024-12-17 20:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:53:49 --> Input Class Initialized
INFO - 2024-12-17 20:53:49 --> Language Class Initialized
INFO - 2024-12-17 20:53:49 --> Language Class Initialized
INFO - 2024-12-17 20:53:49 --> Config Class Initialized
INFO - 2024-12-17 20:53:49 --> Loader Class Initialized
INFO - 2024-12-17 20:53:49 --> Helper loaded: url_helper
INFO - 2024-12-17 20:53:49 --> Helper loaded: file_helper
INFO - 2024-12-17 20:53:49 --> Helper loaded: form_helper
INFO - 2024-12-17 20:53:49 --> Helper loaded: my_helper
INFO - 2024-12-17 20:53:49 --> Database Driver Class Initialized
INFO - 2024-12-17 20:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:53:49 --> Controller Class Initialized
DEBUG - 2024-12-17 20:53:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:53:53 --> Final output sent to browser
DEBUG - 2024-12-17 20:53:53 --> Total execution time: 4.7163
INFO - 2024-12-17 20:53:54 --> Config Class Initialized
INFO - 2024-12-17 20:53:54 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:53:54 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:53:54 --> Utf8 Class Initialized
INFO - 2024-12-17 20:53:54 --> URI Class Initialized
INFO - 2024-12-17 20:53:54 --> Router Class Initialized
INFO - 2024-12-17 20:53:54 --> Output Class Initialized
INFO - 2024-12-17 20:53:54 --> Security Class Initialized
DEBUG - 2024-12-17 20:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:53:54 --> Input Class Initialized
INFO - 2024-12-17 20:53:54 --> Language Class Initialized
INFO - 2024-12-17 20:53:54 --> Language Class Initialized
INFO - 2024-12-17 20:53:54 --> Config Class Initialized
INFO - 2024-12-17 20:53:54 --> Loader Class Initialized
INFO - 2024-12-17 20:53:54 --> Helper loaded: url_helper
INFO - 2024-12-17 20:53:54 --> Helper loaded: file_helper
INFO - 2024-12-17 20:53:54 --> Helper loaded: form_helper
INFO - 2024-12-17 20:53:54 --> Helper loaded: my_helper
INFO - 2024-12-17 20:53:54 --> Database Driver Class Initialized
INFO - 2024-12-17 20:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:53:54 --> Controller Class Initialized
DEBUG - 2024-12-17 20:53:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:53:59 --> Final output sent to browser
DEBUG - 2024-12-17 20:53:59 --> Total execution time: 5.0029
INFO - 2024-12-17 20:53:59 --> Config Class Initialized
INFO - 2024-12-17 20:53:59 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:53:59 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:53:59 --> Utf8 Class Initialized
INFO - 2024-12-17 20:53:59 --> URI Class Initialized
INFO - 2024-12-17 20:53:59 --> Router Class Initialized
INFO - 2024-12-17 20:53:59 --> Output Class Initialized
INFO - 2024-12-17 20:53:59 --> Security Class Initialized
DEBUG - 2024-12-17 20:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:53:59 --> Input Class Initialized
INFO - 2024-12-17 20:53:59 --> Language Class Initialized
INFO - 2024-12-17 20:53:59 --> Language Class Initialized
INFO - 2024-12-17 20:53:59 --> Config Class Initialized
INFO - 2024-12-17 20:53:59 --> Loader Class Initialized
INFO - 2024-12-17 20:53:59 --> Helper loaded: url_helper
INFO - 2024-12-17 20:53:59 --> Helper loaded: file_helper
INFO - 2024-12-17 20:53:59 --> Helper loaded: form_helper
INFO - 2024-12-17 20:53:59 --> Helper loaded: my_helper
INFO - 2024-12-17 20:53:59 --> Database Driver Class Initialized
INFO - 2024-12-17 20:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:53:59 --> Controller Class Initialized
DEBUG - 2024-12-17 20:53:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:54:04 --> Config Class Initialized
INFO - 2024-12-17 20:54:04 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:54:04 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:54:04 --> Utf8 Class Initialized
INFO - 2024-12-17 20:54:04 --> URI Class Initialized
INFO - 2024-12-17 20:54:04 --> Router Class Initialized
INFO - 2024-12-17 20:54:04 --> Output Class Initialized
INFO - 2024-12-17 20:54:04 --> Security Class Initialized
DEBUG - 2024-12-17 20:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:54:04 --> Input Class Initialized
INFO - 2024-12-17 20:54:04 --> Language Class Initialized
INFO - 2024-12-17 20:54:04 --> Language Class Initialized
INFO - 2024-12-17 20:54:04 --> Config Class Initialized
INFO - 2024-12-17 20:54:04 --> Loader Class Initialized
INFO - 2024-12-17 20:54:04 --> Helper loaded: url_helper
INFO - 2024-12-17 20:54:04 --> Helper loaded: file_helper
INFO - 2024-12-17 20:54:04 --> Helper loaded: form_helper
INFO - 2024-12-17 20:54:04 --> Helper loaded: my_helper
INFO - 2024-12-17 20:54:04 --> Database Driver Class Initialized
INFO - 2024-12-17 20:54:04 --> Final output sent to browser
DEBUG - 2024-12-17 20:54:04 --> Total execution time: 5.8270
INFO - 2024-12-17 20:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:54:04 --> Controller Class Initialized
DEBUG - 2024-12-17 20:54:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:54:08 --> Config Class Initialized
INFO - 2024-12-17 20:54:08 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:54:08 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:54:08 --> Utf8 Class Initialized
INFO - 2024-12-17 20:54:08 --> URI Class Initialized
INFO - 2024-12-17 20:54:08 --> Router Class Initialized
INFO - 2024-12-17 20:54:08 --> Output Class Initialized
INFO - 2024-12-17 20:54:08 --> Security Class Initialized
DEBUG - 2024-12-17 20:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:54:08 --> Input Class Initialized
INFO - 2024-12-17 20:54:08 --> Language Class Initialized
INFO - 2024-12-17 20:54:08 --> Language Class Initialized
INFO - 2024-12-17 20:54:08 --> Config Class Initialized
INFO - 2024-12-17 20:54:08 --> Loader Class Initialized
INFO - 2024-12-17 20:54:08 --> Helper loaded: url_helper
INFO - 2024-12-17 20:54:08 --> Helper loaded: file_helper
INFO - 2024-12-17 20:54:08 --> Helper loaded: form_helper
INFO - 2024-12-17 20:54:08 --> Helper loaded: my_helper
INFO - 2024-12-17 20:54:08 --> Database Driver Class Initialized
INFO - 2024-12-17 20:54:10 --> Final output sent to browser
DEBUG - 2024-12-17 20:54:10 --> Total execution time: 5.6584
INFO - 2024-12-17 20:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:54:10 --> Controller Class Initialized
DEBUG - 2024-12-17 20:54:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-17 20:54:10 --> Config Class Initialized
INFO - 2024-12-17 20:54:10 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:54:10 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:54:10 --> Utf8 Class Initialized
INFO - 2024-12-17 20:54:10 --> URI Class Initialized
INFO - 2024-12-17 20:54:10 --> Router Class Initialized
INFO - 2024-12-17 20:54:10 --> Output Class Initialized
INFO - 2024-12-17 20:54:10 --> Security Class Initialized
DEBUG - 2024-12-17 20:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:54:10 --> Input Class Initialized
INFO - 2024-12-17 20:54:10 --> Language Class Initialized
INFO - 2024-12-17 20:54:10 --> Language Class Initialized
INFO - 2024-12-17 20:54:10 --> Config Class Initialized
INFO - 2024-12-17 20:54:10 --> Loader Class Initialized
INFO - 2024-12-17 20:54:10 --> Helper loaded: url_helper
INFO - 2024-12-17 20:54:10 --> Helper loaded: file_helper
INFO - 2024-12-17 20:54:10 --> Helper loaded: form_helper
INFO - 2024-12-17 20:54:10 --> Helper loaded: my_helper
INFO - 2024-12-17 20:54:10 --> Database Driver Class Initialized
INFO - 2024-12-17 20:54:12 --> Config Class Initialized
INFO - 2024-12-17 20:54:12 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:54:12 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:54:12 --> Utf8 Class Initialized
INFO - 2024-12-17 20:54:12 --> URI Class Initialized
INFO - 2024-12-17 20:54:12 --> Router Class Initialized
INFO - 2024-12-17 20:54:12 --> Final output sent to browser
DEBUG - 2024-12-17 20:54:12 --> Total execution time: 4.6133
INFO - 2024-12-17 20:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:54:12 --> Controller Class Initialized
DEBUG - 2024-12-17 20:54:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-17 20:54:12 --> Output Class Initialized
INFO - 2024-12-17 20:54:12 --> Security Class Initialized
DEBUG - 2024-12-17 20:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:54:12 --> Input Class Initialized
INFO - 2024-12-17 20:54:12 --> Language Class Initialized
INFO - 2024-12-17 20:54:12 --> Language Class Initialized
INFO - 2024-12-17 20:54:12 --> Config Class Initialized
INFO - 2024-12-17 20:54:12 --> Loader Class Initialized
INFO - 2024-12-17 20:54:12 --> Helper loaded: url_helper
INFO - 2024-12-17 20:54:12 --> Helper loaded: file_helper
INFO - 2024-12-17 20:54:12 --> Helper loaded: form_helper
INFO - 2024-12-17 20:54:12 --> Helper loaded: my_helper
INFO - 2024-12-17 20:54:12 --> Database Driver Class Initialized
INFO - 2024-12-17 20:54:16 --> Final output sent to browser
DEBUG - 2024-12-17 20:54:16 --> Total execution time: 5.8736
INFO - 2024-12-17 20:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:54:16 --> Controller Class Initialized
INFO - 2024-12-17 20:54:16 --> Config Class Initialized
INFO - 2024-12-17 20:54:16 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:54:16 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:54:16 --> Utf8 Class Initialized
INFO - 2024-12-17 20:54:16 --> URI Class Initialized
INFO - 2024-12-17 20:54:16 --> Router Class Initialized
DEBUG - 2024-12-17 20:54:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-17 20:54:16 --> Output Class Initialized
INFO - 2024-12-17 20:54:16 --> Security Class Initialized
DEBUG - 2024-12-17 20:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:54:16 --> Input Class Initialized
INFO - 2024-12-17 20:54:16 --> Language Class Initialized
INFO - 2024-12-17 20:54:16 --> Language Class Initialized
INFO - 2024-12-17 20:54:16 --> Config Class Initialized
INFO - 2024-12-17 20:54:16 --> Loader Class Initialized
INFO - 2024-12-17 20:54:16 --> Helper loaded: url_helper
INFO - 2024-12-17 20:54:16 --> Helper loaded: file_helper
INFO - 2024-12-17 20:54:16 --> Helper loaded: form_helper
INFO - 2024-12-17 20:54:16 --> Helper loaded: my_helper
INFO - 2024-12-17 20:54:16 --> Database Driver Class Initialized
INFO - 2024-12-17 20:54:19 --> Final output sent to browser
DEBUG - 2024-12-17 20:54:19 --> Total execution time: 6.2659
INFO - 2024-12-17 20:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:54:19 --> Controller Class Initialized
DEBUG - 2024-12-17 20:54:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-17 20:54:20 --> Config Class Initialized
INFO - 2024-12-17 20:54:20 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:54:20 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:54:20 --> Utf8 Class Initialized
INFO - 2024-12-17 20:54:20 --> URI Class Initialized
INFO - 2024-12-17 20:54:20 --> Router Class Initialized
INFO - 2024-12-17 20:54:20 --> Output Class Initialized
INFO - 2024-12-17 20:54:20 --> Security Class Initialized
DEBUG - 2024-12-17 20:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:54:20 --> Input Class Initialized
INFO - 2024-12-17 20:54:20 --> Language Class Initialized
INFO - 2024-12-17 20:54:20 --> Language Class Initialized
INFO - 2024-12-17 20:54:20 --> Config Class Initialized
INFO - 2024-12-17 20:54:20 --> Loader Class Initialized
INFO - 2024-12-17 20:54:20 --> Helper loaded: url_helper
INFO - 2024-12-17 20:54:20 --> Helper loaded: file_helper
INFO - 2024-12-17 20:54:20 --> Helper loaded: form_helper
INFO - 2024-12-17 20:54:20 --> Helper loaded: my_helper
INFO - 2024-12-17 20:54:20 --> Database Driver Class Initialized
INFO - 2024-12-17 20:54:22 --> Final output sent to browser
DEBUG - 2024-12-17 20:54:22 --> Total execution time: 6.0498
INFO - 2024-12-17 20:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:54:22 --> Controller Class Initialized
INFO - 2024-12-17 20:54:22 --> Config Class Initialized
INFO - 2024-12-17 20:54:22 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:54:22 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:54:22 --> Utf8 Class Initialized
INFO - 2024-12-17 20:54:22 --> URI Class Initialized
DEBUG - 2024-12-17 20:54:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:54:22 --> Router Class Initialized
INFO - 2024-12-17 20:54:22 --> Output Class Initialized
INFO - 2024-12-17 20:54:22 --> Security Class Initialized
DEBUG - 2024-12-17 20:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:54:22 --> Input Class Initialized
INFO - 2024-12-17 20:54:22 --> Language Class Initialized
INFO - 2024-12-17 20:54:22 --> Language Class Initialized
INFO - 2024-12-17 20:54:22 --> Config Class Initialized
INFO - 2024-12-17 20:54:22 --> Loader Class Initialized
INFO - 2024-12-17 20:54:22 --> Helper loaded: url_helper
INFO - 2024-12-17 20:54:22 --> Helper loaded: file_helper
INFO - 2024-12-17 20:54:22 --> Helper loaded: form_helper
INFO - 2024-12-17 20:54:22 --> Helper loaded: my_helper
INFO - 2024-12-17 20:54:22 --> Database Driver Class Initialized
INFO - 2024-12-17 20:54:27 --> Final output sent to browser
DEBUG - 2024-12-17 20:54:27 --> Total execution time: 6.9744
INFO - 2024-12-17 20:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:54:27 --> Controller Class Initialized
INFO - 2024-12-17 20:54:27 --> Config Class Initialized
INFO - 2024-12-17 20:54:27 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:54:27 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:54:27 --> Utf8 Class Initialized
INFO - 2024-12-17 20:54:27 --> URI Class Initialized
INFO - 2024-12-17 20:54:27 --> Router Class Initialized
INFO - 2024-12-17 20:54:27 --> Output Class Initialized
DEBUG - 2024-12-17 20:54:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:54:27 --> Security Class Initialized
DEBUG - 2024-12-17 20:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:54:27 --> Input Class Initialized
INFO - 2024-12-17 20:54:27 --> Language Class Initialized
INFO - 2024-12-17 20:54:27 --> Language Class Initialized
INFO - 2024-12-17 20:54:27 --> Config Class Initialized
INFO - 2024-12-17 20:54:27 --> Loader Class Initialized
INFO - 2024-12-17 20:54:27 --> Helper loaded: url_helper
INFO - 2024-12-17 20:54:27 --> Helper loaded: file_helper
INFO - 2024-12-17 20:54:27 --> Helper loaded: form_helper
INFO - 2024-12-17 20:54:27 --> Helper loaded: my_helper
INFO - 2024-12-17 20:54:27 --> Database Driver Class Initialized
INFO - 2024-12-17 20:54:32 --> Final output sent to browser
DEBUG - 2024-12-17 20:54:32 --> Total execution time: 10.6191
INFO - 2024-12-17 20:54:32 --> Config Class Initialized
INFO - 2024-12-17 20:54:32 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:54:32 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:54:32 --> Utf8 Class Initialized
INFO - 2024-12-17 20:54:32 --> URI Class Initialized
INFO - 2024-12-17 20:54:32 --> Router Class Initialized
INFO - 2024-12-17 20:54:32 --> Output Class Initialized
INFO - 2024-12-17 20:54:32 --> Security Class Initialized
DEBUG - 2024-12-17 20:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:54:32 --> Input Class Initialized
INFO - 2024-12-17 20:54:32 --> Language Class Initialized
INFO - 2024-12-17 20:54:32 --> Language Class Initialized
INFO - 2024-12-17 20:54:32 --> Config Class Initialized
INFO - 2024-12-17 20:54:32 --> Loader Class Initialized
INFO - 2024-12-17 20:54:32 --> Helper loaded: url_helper
INFO - 2024-12-17 20:54:32 --> Helper loaded: file_helper
INFO - 2024-12-17 20:54:32 --> Helper loaded: form_helper
INFO - 2024-12-17 20:54:32 --> Helper loaded: my_helper
INFO - 2024-12-17 20:54:32 --> Database Driver Class Initialized
INFO - 2024-12-17 20:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:54:33 --> Controller Class Initialized
DEBUG - 2024-12-17 20:54:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-17 20:54:36 --> Final output sent to browser
DEBUG - 2024-12-17 20:54:36 --> Total execution time: 8.4840
INFO - 2024-12-17 20:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:54:36 --> Controller Class Initialized
INFO - 2024-12-17 20:54:36 --> Config Class Initialized
INFO - 2024-12-17 20:54:36 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:54:36 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:54:36 --> Utf8 Class Initialized
INFO - 2024-12-17 20:54:36 --> URI Class Initialized
INFO - 2024-12-17 20:54:36 --> Router Class Initialized
DEBUG - 2024-12-17 20:54:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-17 20:54:36 --> Output Class Initialized
INFO - 2024-12-17 20:54:36 --> Security Class Initialized
DEBUG - 2024-12-17 20:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:54:36 --> Input Class Initialized
INFO - 2024-12-17 20:54:36 --> Language Class Initialized
INFO - 2024-12-17 20:54:36 --> Language Class Initialized
INFO - 2024-12-17 20:54:36 --> Config Class Initialized
INFO - 2024-12-17 20:54:36 --> Loader Class Initialized
INFO - 2024-12-17 20:54:36 --> Helper loaded: url_helper
INFO - 2024-12-17 20:54:36 --> Helper loaded: file_helper
INFO - 2024-12-17 20:54:36 --> Helper loaded: form_helper
INFO - 2024-12-17 20:54:36 --> Helper loaded: my_helper
INFO - 2024-12-17 20:54:36 --> Database Driver Class Initialized
INFO - 2024-12-17 20:54:39 --> Final output sent to browser
DEBUG - 2024-12-17 20:54:39 --> Total execution time: 6.3119
INFO - 2024-12-17 20:54:39 --> Config Class Initialized
INFO - 2024-12-17 20:54:39 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:54:39 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:54:39 --> Utf8 Class Initialized
INFO - 2024-12-17 20:54:39 --> URI Class Initialized
INFO - 2024-12-17 20:54:39 --> Router Class Initialized
INFO - 2024-12-17 20:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:54:39 --> Controller Class Initialized
INFO - 2024-12-17 20:54:39 --> Output Class Initialized
INFO - 2024-12-17 20:54:39 --> Security Class Initialized
DEBUG - 2024-12-17 20:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:54:39 --> Input Class Initialized
INFO - 2024-12-17 20:54:39 --> Language Class Initialized
DEBUG - 2024-12-17 20:54:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-17 20:54:39 --> Language Class Initialized
INFO - 2024-12-17 20:54:39 --> Config Class Initialized
INFO - 2024-12-17 20:54:39 --> Loader Class Initialized
INFO - 2024-12-17 20:54:39 --> Helper loaded: url_helper
INFO - 2024-12-17 20:54:39 --> Helper loaded: file_helper
INFO - 2024-12-17 20:54:39 --> Helper loaded: form_helper
INFO - 2024-12-17 20:54:39 --> Helper loaded: my_helper
INFO - 2024-12-17 20:54:39 --> Database Driver Class Initialized
INFO - 2024-12-17 20:54:42 --> Final output sent to browser
DEBUG - 2024-12-17 20:54:42 --> Total execution time: 6.5365
INFO - 2024-12-17 20:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:54:42 --> Controller Class Initialized
INFO - 2024-12-17 20:54:42 --> Config Class Initialized
INFO - 2024-12-17 20:54:42 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:54:42 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:54:42 --> Utf8 Class Initialized
INFO - 2024-12-17 20:54:42 --> URI Class Initialized
INFO - 2024-12-17 20:54:42 --> Router Class Initialized
INFO - 2024-12-17 20:54:42 --> Output Class Initialized
INFO - 2024-12-17 20:54:42 --> Security Class Initialized
DEBUG - 2024-12-17 20:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:54:42 --> Input Class Initialized
INFO - 2024-12-17 20:54:42 --> Language Class Initialized
INFO - 2024-12-17 20:54:42 --> Language Class Initialized
INFO - 2024-12-17 20:54:42 --> Config Class Initialized
INFO - 2024-12-17 20:54:42 --> Loader Class Initialized
INFO - 2024-12-17 20:54:42 --> Helper loaded: url_helper
INFO - 2024-12-17 20:54:42 --> Helper loaded: file_helper
INFO - 2024-12-17 20:54:42 --> Helper loaded: form_helper
INFO - 2024-12-17 20:54:42 --> Helper loaded: my_helper
INFO - 2024-12-17 20:54:42 --> Database Driver Class Initialized
ERROR - 2024-12-17 20:54:42 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-12-17 20:54:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-12-17 20:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:54:45 --> Controller Class Initialized
ERROR - 2024-12-17 20:54:45 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-12-17 20:54:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-12-17 20:54:49 --> Final output sent to browser
DEBUG - 2024-12-17 20:54:49 --> Total execution time: 6.7688
INFO - 2024-12-17 20:54:49 --> Config Class Initialized
INFO - 2024-12-17 20:54:49 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:54:49 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:54:49 --> Utf8 Class Initialized
INFO - 2024-12-17 20:54:49 --> URI Class Initialized
INFO - 2024-12-17 20:54:49 --> Router Class Initialized
INFO - 2024-12-17 20:54:49 --> Output Class Initialized
INFO - 2024-12-17 20:54:49 --> Security Class Initialized
DEBUG - 2024-12-17 20:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:54:49 --> Input Class Initialized
INFO - 2024-12-17 20:54:49 --> Language Class Initialized
INFO - 2024-12-17 20:54:49 --> Language Class Initialized
INFO - 2024-12-17 20:54:49 --> Config Class Initialized
INFO - 2024-12-17 20:54:49 --> Loader Class Initialized
INFO - 2024-12-17 20:54:49 --> Helper loaded: url_helper
INFO - 2024-12-17 20:54:49 --> Helper loaded: file_helper
INFO - 2024-12-17 20:54:49 --> Helper loaded: form_helper
INFO - 2024-12-17 20:54:49 --> Helper loaded: my_helper
INFO - 2024-12-17 20:54:49 --> Database Driver Class Initialized
INFO - 2024-12-17 20:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:54:49 --> Controller Class Initialized
ERROR - 2024-12-17 20:54:49 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-12-17 20:54:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-12-17 20:54:53 --> Final output sent to browser
DEBUG - 2024-12-17 20:54:53 --> Total execution time: 3.8831
INFO - 2024-12-17 20:54:53 --> Config Class Initialized
INFO - 2024-12-17 20:54:53 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:54:53 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:54:53 --> Utf8 Class Initialized
INFO - 2024-12-17 20:54:53 --> URI Class Initialized
INFO - 2024-12-17 20:54:53 --> Router Class Initialized
INFO - 2024-12-17 20:54:53 --> Output Class Initialized
INFO - 2024-12-17 20:54:53 --> Security Class Initialized
DEBUG - 2024-12-17 20:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:54:53 --> Input Class Initialized
INFO - 2024-12-17 20:54:53 --> Language Class Initialized
INFO - 2024-12-17 20:54:53 --> Language Class Initialized
INFO - 2024-12-17 20:54:53 --> Config Class Initialized
INFO - 2024-12-17 20:54:53 --> Loader Class Initialized
INFO - 2024-12-17 20:54:53 --> Helper loaded: url_helper
INFO - 2024-12-17 20:54:53 --> Helper loaded: file_helper
INFO - 2024-12-17 20:54:53 --> Helper loaded: form_helper
INFO - 2024-12-17 20:54:53 --> Helper loaded: my_helper
INFO - 2024-12-17 20:54:53 --> Database Driver Class Initialized
INFO - 2024-12-17 20:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:54:53 --> Controller Class Initialized
ERROR - 2024-12-17 20:54:53 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-12-17 20:54:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-12-17 20:54:57 --> Final output sent to browser
DEBUG - 2024-12-17 20:54:57 --> Total execution time: 3.4702
INFO - 2024-12-17 20:54:57 --> Config Class Initialized
INFO - 2024-12-17 20:54:57 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:54:57 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:54:57 --> Utf8 Class Initialized
INFO - 2024-12-17 20:54:57 --> URI Class Initialized
INFO - 2024-12-17 20:54:57 --> Router Class Initialized
INFO - 2024-12-17 20:54:57 --> Output Class Initialized
INFO - 2024-12-17 20:54:57 --> Security Class Initialized
DEBUG - 2024-12-17 20:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:54:57 --> Input Class Initialized
INFO - 2024-12-17 20:54:57 --> Language Class Initialized
INFO - 2024-12-17 20:54:57 --> Language Class Initialized
INFO - 2024-12-17 20:54:57 --> Config Class Initialized
INFO - 2024-12-17 20:54:57 --> Loader Class Initialized
INFO - 2024-12-17 20:54:57 --> Helper loaded: url_helper
INFO - 2024-12-17 20:54:57 --> Helper loaded: file_helper
INFO - 2024-12-17 20:54:57 --> Helper loaded: form_helper
INFO - 2024-12-17 20:54:57 --> Helper loaded: my_helper
INFO - 2024-12-17 20:54:57 --> Database Driver Class Initialized
INFO - 2024-12-17 20:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:54:57 --> Controller Class Initialized
ERROR - 2024-12-17 20:54:57 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-12-17 20:54:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-12-17 20:55:00 --> Final output sent to browser
DEBUG - 2024-12-17 20:55:00 --> Total execution time: 3.6989
INFO - 2024-12-17 20:55:01 --> Config Class Initialized
INFO - 2024-12-17 20:55:01 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:55:01 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:55:01 --> Utf8 Class Initialized
INFO - 2024-12-17 20:55:01 --> URI Class Initialized
INFO - 2024-12-17 20:55:01 --> Router Class Initialized
INFO - 2024-12-17 20:55:01 --> Output Class Initialized
INFO - 2024-12-17 20:55:01 --> Security Class Initialized
DEBUG - 2024-12-17 20:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:55:01 --> Input Class Initialized
INFO - 2024-12-17 20:55:01 --> Language Class Initialized
INFO - 2024-12-17 20:55:01 --> Language Class Initialized
INFO - 2024-12-17 20:55:01 --> Config Class Initialized
INFO - 2024-12-17 20:55:01 --> Loader Class Initialized
INFO - 2024-12-17 20:55:01 --> Helper loaded: url_helper
INFO - 2024-12-17 20:55:01 --> Helper loaded: file_helper
INFO - 2024-12-17 20:55:01 --> Helper loaded: form_helper
INFO - 2024-12-17 20:55:01 --> Helper loaded: my_helper
INFO - 2024-12-17 20:55:01 --> Database Driver Class Initialized
INFO - 2024-12-17 20:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:55:01 --> Controller Class Initialized
ERROR - 2024-12-17 20:55:01 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-12-17 20:55:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-12-17 20:55:05 --> Final output sent to browser
DEBUG - 2024-12-17 20:55:05 --> Total execution time: 4.2069
INFO - 2024-12-17 20:55:05 --> Config Class Initialized
INFO - 2024-12-17 20:55:05 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:55:05 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:55:05 --> Utf8 Class Initialized
INFO - 2024-12-17 20:55:05 --> URI Class Initialized
INFO - 2024-12-17 20:55:05 --> Router Class Initialized
INFO - 2024-12-17 20:55:05 --> Output Class Initialized
INFO - 2024-12-17 20:55:05 --> Security Class Initialized
DEBUG - 2024-12-17 20:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:55:05 --> Input Class Initialized
INFO - 2024-12-17 20:55:05 --> Language Class Initialized
INFO - 2024-12-17 20:55:05 --> Language Class Initialized
INFO - 2024-12-17 20:55:05 --> Config Class Initialized
INFO - 2024-12-17 20:55:05 --> Loader Class Initialized
INFO - 2024-12-17 20:55:05 --> Helper loaded: url_helper
INFO - 2024-12-17 20:55:05 --> Helper loaded: file_helper
INFO - 2024-12-17 20:55:05 --> Helper loaded: form_helper
INFO - 2024-12-17 20:55:05 --> Helper loaded: my_helper
INFO - 2024-12-17 20:55:05 --> Database Driver Class Initialized
INFO - 2024-12-17 20:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:55:05 --> Controller Class Initialized
ERROR - 2024-12-17 20:55:05 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-12-17 20:55:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-12-17 20:55:09 --> Final output sent to browser
DEBUG - 2024-12-17 20:55:09 --> Total execution time: 3.7309
INFO - 2024-12-17 20:55:09 --> Config Class Initialized
INFO - 2024-12-17 20:55:09 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:55:09 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:55:09 --> Utf8 Class Initialized
INFO - 2024-12-17 20:55:09 --> URI Class Initialized
INFO - 2024-12-17 20:55:09 --> Router Class Initialized
INFO - 2024-12-17 20:55:09 --> Output Class Initialized
INFO - 2024-12-17 20:55:09 --> Security Class Initialized
DEBUG - 2024-12-17 20:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:55:09 --> Input Class Initialized
INFO - 2024-12-17 20:55:09 --> Language Class Initialized
INFO - 2024-12-17 20:55:09 --> Language Class Initialized
INFO - 2024-12-17 20:55:09 --> Config Class Initialized
INFO - 2024-12-17 20:55:09 --> Loader Class Initialized
INFO - 2024-12-17 20:55:09 --> Helper loaded: url_helper
INFO - 2024-12-17 20:55:09 --> Helper loaded: file_helper
INFO - 2024-12-17 20:55:09 --> Helper loaded: form_helper
INFO - 2024-12-17 20:55:09 --> Helper loaded: my_helper
INFO - 2024-12-17 20:55:09 --> Database Driver Class Initialized
INFO - 2024-12-17 20:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:55:09 --> Controller Class Initialized
ERROR - 2024-12-17 20:55:09 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-12-17 20:55:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-12-17 20:55:12 --> Final output sent to browser
DEBUG - 2024-12-17 20:55:12 --> Total execution time: 3.3331
INFO - 2024-12-17 20:55:12 --> Config Class Initialized
INFO - 2024-12-17 20:55:12 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:55:12 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:55:12 --> Utf8 Class Initialized
INFO - 2024-12-17 20:55:12 --> URI Class Initialized
INFO - 2024-12-17 20:55:12 --> Router Class Initialized
INFO - 2024-12-17 20:55:12 --> Output Class Initialized
INFO - 2024-12-17 20:55:12 --> Security Class Initialized
DEBUG - 2024-12-17 20:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:55:12 --> Input Class Initialized
INFO - 2024-12-17 20:55:12 --> Language Class Initialized
INFO - 2024-12-17 20:55:12 --> Language Class Initialized
INFO - 2024-12-17 20:55:12 --> Config Class Initialized
INFO - 2024-12-17 20:55:12 --> Loader Class Initialized
INFO - 2024-12-17 20:55:12 --> Helper loaded: url_helper
INFO - 2024-12-17 20:55:12 --> Helper loaded: file_helper
INFO - 2024-12-17 20:55:12 --> Helper loaded: form_helper
INFO - 2024-12-17 20:55:12 --> Helper loaded: my_helper
INFO - 2024-12-17 20:55:12 --> Database Driver Class Initialized
INFO - 2024-12-17 20:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:55:12 --> Controller Class Initialized
ERROR - 2024-12-17 20:55:12 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-12-17 20:55:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-12-17 20:55:16 --> Final output sent to browser
DEBUG - 2024-12-17 20:55:16 --> Total execution time: 3.7107
INFO - 2024-12-17 20:55:16 --> Config Class Initialized
INFO - 2024-12-17 20:55:16 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:55:16 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:55:16 --> Utf8 Class Initialized
INFO - 2024-12-17 20:55:16 --> URI Class Initialized
INFO - 2024-12-17 20:55:16 --> Router Class Initialized
INFO - 2024-12-17 20:55:16 --> Output Class Initialized
INFO - 2024-12-17 20:55:16 --> Security Class Initialized
DEBUG - 2024-12-17 20:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:55:16 --> Input Class Initialized
INFO - 2024-12-17 20:55:16 --> Language Class Initialized
INFO - 2024-12-17 20:55:16 --> Language Class Initialized
INFO - 2024-12-17 20:55:16 --> Config Class Initialized
INFO - 2024-12-17 20:55:16 --> Loader Class Initialized
INFO - 2024-12-17 20:55:16 --> Helper loaded: url_helper
INFO - 2024-12-17 20:55:16 --> Helper loaded: file_helper
INFO - 2024-12-17 20:55:16 --> Helper loaded: form_helper
INFO - 2024-12-17 20:55:16 --> Helper loaded: my_helper
INFO - 2024-12-17 20:55:16 --> Database Driver Class Initialized
INFO - 2024-12-17 20:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:55:16 --> Controller Class Initialized
ERROR - 2024-12-17 20:55:16 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-12-17 20:55:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-12-17 20:55:18 --> Config Class Initialized
INFO - 2024-12-17 20:55:18 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:55:18 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:55:18 --> Utf8 Class Initialized
INFO - 2024-12-17 20:55:18 --> URI Class Initialized
INFO - 2024-12-17 20:55:18 --> Router Class Initialized
INFO - 2024-12-17 20:55:18 --> Output Class Initialized
INFO - 2024-12-17 20:55:18 --> Security Class Initialized
DEBUG - 2024-12-17 20:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:55:18 --> Input Class Initialized
INFO - 2024-12-17 20:55:18 --> Language Class Initialized
INFO - 2024-12-17 20:55:18 --> Language Class Initialized
INFO - 2024-12-17 20:55:18 --> Config Class Initialized
INFO - 2024-12-17 20:55:18 --> Loader Class Initialized
INFO - 2024-12-17 20:55:18 --> Helper loaded: url_helper
INFO - 2024-12-17 20:55:18 --> Helper loaded: file_helper
INFO - 2024-12-17 20:55:18 --> Helper loaded: form_helper
INFO - 2024-12-17 20:55:18 --> Helper loaded: my_helper
INFO - 2024-12-17 20:55:18 --> Database Driver Class Initialized
INFO - 2024-12-17 20:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:55:20 --> Controller Class Initialized
DEBUG - 2024-12-17 20:55:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:55:20 --> Config Class Initialized
INFO - 2024-12-17 20:55:20 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:55:20 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:55:20 --> Utf8 Class Initialized
INFO - 2024-12-17 20:55:20 --> URI Class Initialized
INFO - 2024-12-17 20:55:20 --> Router Class Initialized
INFO - 2024-12-17 20:55:20 --> Output Class Initialized
INFO - 2024-12-17 20:55:20 --> Security Class Initialized
DEBUG - 2024-12-17 20:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:55:20 --> Input Class Initialized
INFO - 2024-12-17 20:55:20 --> Language Class Initialized
INFO - 2024-12-17 20:55:20 --> Language Class Initialized
INFO - 2024-12-17 20:55:20 --> Config Class Initialized
INFO - 2024-12-17 20:55:20 --> Loader Class Initialized
INFO - 2024-12-17 20:55:20 --> Helper loaded: url_helper
INFO - 2024-12-17 20:55:20 --> Helper loaded: file_helper
INFO - 2024-12-17 20:55:20 --> Helper loaded: form_helper
INFO - 2024-12-17 20:55:20 --> Helper loaded: my_helper
INFO - 2024-12-17 20:55:20 --> Database Driver Class Initialized
INFO - 2024-12-17 20:55:21 --> Config Class Initialized
INFO - 2024-12-17 20:55:21 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:55:21 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:55:21 --> Utf8 Class Initialized
INFO - 2024-12-17 20:55:21 --> URI Class Initialized
INFO - 2024-12-17 20:55:21 --> Router Class Initialized
INFO - 2024-12-17 20:55:21 --> Output Class Initialized
INFO - 2024-12-17 20:55:21 --> Security Class Initialized
DEBUG - 2024-12-17 20:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:55:21 --> Input Class Initialized
INFO - 2024-12-17 20:55:21 --> Language Class Initialized
INFO - 2024-12-17 20:55:21 --> Language Class Initialized
INFO - 2024-12-17 20:55:21 --> Config Class Initialized
INFO - 2024-12-17 20:55:21 --> Loader Class Initialized
INFO - 2024-12-17 20:55:21 --> Helper loaded: url_helper
INFO - 2024-12-17 20:55:21 --> Helper loaded: file_helper
INFO - 2024-12-17 20:55:21 --> Helper loaded: form_helper
INFO - 2024-12-17 20:55:21 --> Helper loaded: my_helper
INFO - 2024-12-17 20:55:21 --> Database Driver Class Initialized
INFO - 2024-12-17 20:55:25 --> Final output sent to browser
DEBUG - 2024-12-17 20:55:25 --> Total execution time: 7.1730
INFO - 2024-12-17 20:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:55:25 --> Controller Class Initialized
ERROR - 2024-12-17 20:55:25 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-12-17 20:55:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-12-17 20:55:28 --> Config Class Initialized
INFO - 2024-12-17 20:55:28 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:55:28 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:55:28 --> Utf8 Class Initialized
INFO - 2024-12-17 20:55:28 --> URI Class Initialized
INFO - 2024-12-17 20:55:28 --> Router Class Initialized
INFO - 2024-12-17 20:55:28 --> Output Class Initialized
INFO - 2024-12-17 20:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:55:28 --> Controller Class Initialized
DEBUG - 2024-12-17 20:55:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:55:28 --> Security Class Initialized
DEBUG - 2024-12-17 20:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:55:28 --> Input Class Initialized
INFO - 2024-12-17 20:55:28 --> Language Class Initialized
INFO - 2024-12-17 20:55:29 --> Language Class Initialized
INFO - 2024-12-17 20:55:29 --> Config Class Initialized
INFO - 2024-12-17 20:55:29 --> Loader Class Initialized
INFO - 2024-12-17 20:55:29 --> Helper loaded: url_helper
INFO - 2024-12-17 20:55:29 --> Helper loaded: file_helper
INFO - 2024-12-17 20:55:29 --> Helper loaded: form_helper
INFO - 2024-12-17 20:55:29 --> Helper loaded: my_helper
INFO - 2024-12-17 20:55:29 --> Database Driver Class Initialized
INFO - 2024-12-17 20:55:33 --> Final output sent to browser
DEBUG - 2024-12-17 20:55:33 --> Total execution time: 11.8231
INFO - 2024-12-17 20:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:55:33 --> Controller Class Initialized
DEBUG - 2024-12-17 20:55:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:55:37 --> Final output sent to browser
DEBUG - 2024-12-17 20:55:37 --> Total execution time: 8.9885
INFO - 2024-12-17 20:55:38 --> Config Class Initialized
INFO - 2024-12-17 20:55:38 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:55:38 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:55:38 --> Utf8 Class Initialized
INFO - 2024-12-17 20:55:38 --> URI Class Initialized
INFO - 2024-12-17 20:55:38 --> Router Class Initialized
INFO - 2024-12-17 20:55:38 --> Output Class Initialized
INFO - 2024-12-17 20:55:38 --> Security Class Initialized
DEBUG - 2024-12-17 20:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:55:38 --> Input Class Initialized
INFO - 2024-12-17 20:55:38 --> Language Class Initialized
INFO - 2024-12-17 20:55:38 --> Language Class Initialized
INFO - 2024-12-17 20:55:38 --> Config Class Initialized
INFO - 2024-12-17 20:55:38 --> Loader Class Initialized
INFO - 2024-12-17 20:55:38 --> Helper loaded: url_helper
INFO - 2024-12-17 20:55:38 --> Helper loaded: file_helper
INFO - 2024-12-17 20:55:38 --> Helper loaded: form_helper
INFO - 2024-12-17 20:55:38 --> Helper loaded: my_helper
INFO - 2024-12-17 20:55:38 --> Database Driver Class Initialized
INFO - 2024-12-17 20:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:55:38 --> Controller Class Initialized
DEBUG - 2024-12-17 20:55:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:55:42 --> Final output sent to browser
DEBUG - 2024-12-17 20:55:42 --> Total execution time: 4.6916
INFO - 2024-12-17 20:55:43 --> Config Class Initialized
INFO - 2024-12-17 20:55:43 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:55:43 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:55:43 --> Utf8 Class Initialized
INFO - 2024-12-17 20:55:43 --> URI Class Initialized
INFO - 2024-12-17 20:55:43 --> Router Class Initialized
INFO - 2024-12-17 20:55:43 --> Output Class Initialized
INFO - 2024-12-17 20:55:43 --> Security Class Initialized
DEBUG - 2024-12-17 20:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:55:43 --> Input Class Initialized
INFO - 2024-12-17 20:55:43 --> Language Class Initialized
INFO - 2024-12-17 20:55:43 --> Language Class Initialized
INFO - 2024-12-17 20:55:43 --> Config Class Initialized
INFO - 2024-12-17 20:55:43 --> Loader Class Initialized
INFO - 2024-12-17 20:55:43 --> Helper loaded: url_helper
INFO - 2024-12-17 20:55:43 --> Helper loaded: file_helper
INFO - 2024-12-17 20:55:43 --> Helper loaded: form_helper
INFO - 2024-12-17 20:55:43 --> Helper loaded: my_helper
INFO - 2024-12-17 20:55:43 --> Database Driver Class Initialized
INFO - 2024-12-17 20:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:55:43 --> Controller Class Initialized
DEBUG - 2024-12-17 20:55:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:55:47 --> Final output sent to browser
DEBUG - 2024-12-17 20:55:47 --> Total execution time: 4.4749
INFO - 2024-12-17 20:55:48 --> Config Class Initialized
INFO - 2024-12-17 20:55:48 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:55:48 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:55:48 --> Utf8 Class Initialized
INFO - 2024-12-17 20:55:48 --> URI Class Initialized
INFO - 2024-12-17 20:55:48 --> Router Class Initialized
INFO - 2024-12-17 20:55:48 --> Output Class Initialized
INFO - 2024-12-17 20:55:48 --> Security Class Initialized
DEBUG - 2024-12-17 20:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:55:48 --> Input Class Initialized
INFO - 2024-12-17 20:55:48 --> Language Class Initialized
INFO - 2024-12-17 20:55:48 --> Language Class Initialized
INFO - 2024-12-17 20:55:48 --> Config Class Initialized
INFO - 2024-12-17 20:55:48 --> Loader Class Initialized
INFO - 2024-12-17 20:55:48 --> Helper loaded: url_helper
INFO - 2024-12-17 20:55:48 --> Helper loaded: file_helper
INFO - 2024-12-17 20:55:48 --> Helper loaded: form_helper
INFO - 2024-12-17 20:55:48 --> Helper loaded: my_helper
INFO - 2024-12-17 20:55:48 --> Database Driver Class Initialized
INFO - 2024-12-17 20:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:55:48 --> Controller Class Initialized
DEBUG - 2024-12-17 20:55:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:55:52 --> Final output sent to browser
DEBUG - 2024-12-17 20:55:52 --> Total execution time: 4.7200
INFO - 2024-12-17 20:55:52 --> Config Class Initialized
INFO - 2024-12-17 20:55:52 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:55:52 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:55:52 --> Utf8 Class Initialized
INFO - 2024-12-17 20:55:52 --> URI Class Initialized
INFO - 2024-12-17 20:55:52 --> Router Class Initialized
INFO - 2024-12-17 20:55:52 --> Output Class Initialized
INFO - 2024-12-17 20:55:52 --> Security Class Initialized
DEBUG - 2024-12-17 20:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:55:52 --> Input Class Initialized
INFO - 2024-12-17 20:55:52 --> Language Class Initialized
INFO - 2024-12-17 20:55:52 --> Language Class Initialized
INFO - 2024-12-17 20:55:52 --> Config Class Initialized
INFO - 2024-12-17 20:55:52 --> Loader Class Initialized
INFO - 2024-12-17 20:55:52 --> Helper loaded: url_helper
INFO - 2024-12-17 20:55:52 --> Helper loaded: file_helper
INFO - 2024-12-17 20:55:52 --> Helper loaded: form_helper
INFO - 2024-12-17 20:55:52 --> Helper loaded: my_helper
INFO - 2024-12-17 20:55:52 --> Database Driver Class Initialized
INFO - 2024-12-17 20:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:55:52 --> Controller Class Initialized
DEBUG - 2024-12-17 20:55:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:55:57 --> Final output sent to browser
DEBUG - 2024-12-17 20:55:57 --> Total execution time: 4.9996
INFO - 2024-12-17 20:55:58 --> Config Class Initialized
INFO - 2024-12-17 20:55:58 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:55:58 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:55:58 --> Utf8 Class Initialized
INFO - 2024-12-17 20:55:58 --> URI Class Initialized
INFO - 2024-12-17 20:55:58 --> Router Class Initialized
INFO - 2024-12-17 20:55:58 --> Output Class Initialized
INFO - 2024-12-17 20:55:58 --> Security Class Initialized
DEBUG - 2024-12-17 20:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:55:58 --> Input Class Initialized
INFO - 2024-12-17 20:55:58 --> Language Class Initialized
INFO - 2024-12-17 20:55:58 --> Language Class Initialized
INFO - 2024-12-17 20:55:58 --> Config Class Initialized
INFO - 2024-12-17 20:55:58 --> Loader Class Initialized
INFO - 2024-12-17 20:55:58 --> Helper loaded: url_helper
INFO - 2024-12-17 20:55:58 --> Helper loaded: file_helper
INFO - 2024-12-17 20:55:58 --> Helper loaded: form_helper
INFO - 2024-12-17 20:55:58 --> Helper loaded: my_helper
INFO - 2024-12-17 20:55:58 --> Database Driver Class Initialized
INFO - 2024-12-17 20:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:55:58 --> Controller Class Initialized
DEBUG - 2024-12-17 20:55:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:56:04 --> Final output sent to browser
DEBUG - 2024-12-17 20:56:04 --> Total execution time: 5.8138
INFO - 2024-12-17 20:56:04 --> Config Class Initialized
INFO - 2024-12-17 20:56:04 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:56:04 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:56:04 --> Utf8 Class Initialized
INFO - 2024-12-17 20:56:04 --> URI Class Initialized
INFO - 2024-12-17 20:56:04 --> Router Class Initialized
INFO - 2024-12-17 20:56:04 --> Output Class Initialized
INFO - 2024-12-17 20:56:04 --> Security Class Initialized
DEBUG - 2024-12-17 20:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:56:04 --> Input Class Initialized
INFO - 2024-12-17 20:56:04 --> Language Class Initialized
INFO - 2024-12-17 20:56:04 --> Language Class Initialized
INFO - 2024-12-17 20:56:04 --> Config Class Initialized
INFO - 2024-12-17 20:56:04 --> Loader Class Initialized
INFO - 2024-12-17 20:56:04 --> Helper loaded: url_helper
INFO - 2024-12-17 20:56:04 --> Helper loaded: file_helper
INFO - 2024-12-17 20:56:04 --> Helper loaded: form_helper
INFO - 2024-12-17 20:56:04 --> Helper loaded: my_helper
INFO - 2024-12-17 20:56:04 --> Database Driver Class Initialized
INFO - 2024-12-17 20:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:56:04 --> Controller Class Initialized
DEBUG - 2024-12-17 20:56:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:56:09 --> Final output sent to browser
DEBUG - 2024-12-17 20:56:09 --> Total execution time: 5.2823
INFO - 2024-12-17 20:56:09 --> Config Class Initialized
INFO - 2024-12-17 20:56:09 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:56:09 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:56:09 --> Utf8 Class Initialized
INFO - 2024-12-17 20:56:09 --> URI Class Initialized
INFO - 2024-12-17 20:56:09 --> Router Class Initialized
INFO - 2024-12-17 20:56:09 --> Output Class Initialized
INFO - 2024-12-17 20:56:09 --> Security Class Initialized
DEBUG - 2024-12-17 20:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:56:09 --> Input Class Initialized
INFO - 2024-12-17 20:56:09 --> Language Class Initialized
INFO - 2024-12-17 20:56:09 --> Language Class Initialized
INFO - 2024-12-17 20:56:09 --> Config Class Initialized
INFO - 2024-12-17 20:56:09 --> Loader Class Initialized
INFO - 2024-12-17 20:56:09 --> Helper loaded: url_helper
INFO - 2024-12-17 20:56:09 --> Helper loaded: file_helper
INFO - 2024-12-17 20:56:09 --> Helper loaded: form_helper
INFO - 2024-12-17 20:56:09 --> Helper loaded: my_helper
INFO - 2024-12-17 20:56:09 --> Database Driver Class Initialized
INFO - 2024-12-17 20:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:56:09 --> Controller Class Initialized
DEBUG - 2024-12-17 20:56:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:56:14 --> Final output sent to browser
DEBUG - 2024-12-17 20:56:14 --> Total execution time: 4.8139
INFO - 2024-12-17 20:56:14 --> Config Class Initialized
INFO - 2024-12-17 20:56:14 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:56:14 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:56:14 --> Utf8 Class Initialized
INFO - 2024-12-17 20:56:14 --> URI Class Initialized
INFO - 2024-12-17 20:56:14 --> Router Class Initialized
INFO - 2024-12-17 20:56:14 --> Output Class Initialized
INFO - 2024-12-17 20:56:14 --> Security Class Initialized
DEBUG - 2024-12-17 20:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:56:14 --> Input Class Initialized
INFO - 2024-12-17 20:56:14 --> Language Class Initialized
INFO - 2024-12-17 20:56:15 --> Language Class Initialized
INFO - 2024-12-17 20:56:15 --> Config Class Initialized
INFO - 2024-12-17 20:56:15 --> Loader Class Initialized
INFO - 2024-12-17 20:56:15 --> Helper loaded: url_helper
INFO - 2024-12-17 20:56:15 --> Helper loaded: file_helper
INFO - 2024-12-17 20:56:15 --> Helper loaded: form_helper
INFO - 2024-12-17 20:56:15 --> Helper loaded: my_helper
INFO - 2024-12-17 20:56:15 --> Database Driver Class Initialized
INFO - 2024-12-17 20:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:56:15 --> Controller Class Initialized
DEBUG - 2024-12-17 20:56:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:56:19 --> Final output sent to browser
DEBUG - 2024-12-17 20:56:19 --> Total execution time: 4.9096
INFO - 2024-12-17 20:56:20 --> Config Class Initialized
INFO - 2024-12-17 20:56:20 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:56:20 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:56:20 --> Utf8 Class Initialized
INFO - 2024-12-17 20:56:20 --> URI Class Initialized
INFO - 2024-12-17 20:56:20 --> Router Class Initialized
INFO - 2024-12-17 20:56:20 --> Output Class Initialized
INFO - 2024-12-17 20:56:20 --> Security Class Initialized
DEBUG - 2024-12-17 20:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:56:20 --> Input Class Initialized
INFO - 2024-12-17 20:56:20 --> Language Class Initialized
INFO - 2024-12-17 20:56:20 --> Language Class Initialized
INFO - 2024-12-17 20:56:20 --> Config Class Initialized
INFO - 2024-12-17 20:56:20 --> Loader Class Initialized
INFO - 2024-12-17 20:56:20 --> Helper loaded: url_helper
INFO - 2024-12-17 20:56:20 --> Helper loaded: file_helper
INFO - 2024-12-17 20:56:20 --> Helper loaded: form_helper
INFO - 2024-12-17 20:56:20 --> Helper loaded: my_helper
INFO - 2024-12-17 20:56:20 --> Database Driver Class Initialized
INFO - 2024-12-17 20:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:56:20 --> Controller Class Initialized
DEBUG - 2024-12-17 20:56:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:56:25 --> Final output sent to browser
DEBUG - 2024-12-17 20:56:25 --> Total execution time: 4.9645
INFO - 2024-12-17 20:56:25 --> Config Class Initialized
INFO - 2024-12-17 20:56:25 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:56:25 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:56:25 --> Utf8 Class Initialized
INFO - 2024-12-17 20:56:25 --> URI Class Initialized
INFO - 2024-12-17 20:56:25 --> Router Class Initialized
INFO - 2024-12-17 20:56:25 --> Output Class Initialized
INFO - 2024-12-17 20:56:25 --> Security Class Initialized
DEBUG - 2024-12-17 20:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:56:25 --> Input Class Initialized
INFO - 2024-12-17 20:56:25 --> Language Class Initialized
INFO - 2024-12-17 20:56:25 --> Language Class Initialized
INFO - 2024-12-17 20:56:25 --> Config Class Initialized
INFO - 2024-12-17 20:56:25 --> Loader Class Initialized
INFO - 2024-12-17 20:56:25 --> Helper loaded: url_helper
INFO - 2024-12-17 20:56:25 --> Helper loaded: file_helper
INFO - 2024-12-17 20:56:25 --> Helper loaded: form_helper
INFO - 2024-12-17 20:56:25 --> Helper loaded: my_helper
INFO - 2024-12-17 20:56:25 --> Database Driver Class Initialized
INFO - 2024-12-17 20:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:56:25 --> Controller Class Initialized
DEBUG - 2024-12-17 20:56:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:56:30 --> Final output sent to browser
DEBUG - 2024-12-17 20:56:30 --> Total execution time: 4.7952
INFO - 2024-12-17 20:56:30 --> Config Class Initialized
INFO - 2024-12-17 20:56:30 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:56:30 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:56:30 --> Utf8 Class Initialized
INFO - 2024-12-17 20:56:30 --> URI Class Initialized
INFO - 2024-12-17 20:56:30 --> Router Class Initialized
INFO - 2024-12-17 20:56:30 --> Output Class Initialized
INFO - 2024-12-17 20:56:30 --> Security Class Initialized
DEBUG - 2024-12-17 20:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:56:30 --> Input Class Initialized
INFO - 2024-12-17 20:56:30 --> Language Class Initialized
INFO - 2024-12-17 20:56:30 --> Language Class Initialized
INFO - 2024-12-17 20:56:30 --> Config Class Initialized
INFO - 2024-12-17 20:56:30 --> Loader Class Initialized
INFO - 2024-12-17 20:56:30 --> Helper loaded: url_helper
INFO - 2024-12-17 20:56:30 --> Helper loaded: file_helper
INFO - 2024-12-17 20:56:30 --> Helper loaded: form_helper
INFO - 2024-12-17 20:56:30 --> Helper loaded: my_helper
INFO - 2024-12-17 20:56:30 --> Database Driver Class Initialized
INFO - 2024-12-17 20:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:56:30 --> Controller Class Initialized
DEBUG - 2024-12-17 20:56:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:56:35 --> Final output sent to browser
DEBUG - 2024-12-17 20:56:35 --> Total execution time: 5.1811
INFO - 2024-12-17 20:56:35 --> Config Class Initialized
INFO - 2024-12-17 20:56:35 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:56:35 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:56:35 --> Utf8 Class Initialized
INFO - 2024-12-17 20:56:35 --> URI Class Initialized
INFO - 2024-12-17 20:56:35 --> Router Class Initialized
INFO - 2024-12-17 20:56:35 --> Output Class Initialized
INFO - 2024-12-17 20:56:35 --> Security Class Initialized
DEBUG - 2024-12-17 20:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:56:35 --> Input Class Initialized
INFO - 2024-12-17 20:56:35 --> Language Class Initialized
INFO - 2024-12-17 20:56:36 --> Language Class Initialized
INFO - 2024-12-17 20:56:36 --> Config Class Initialized
INFO - 2024-12-17 20:56:36 --> Loader Class Initialized
INFO - 2024-12-17 20:56:36 --> Helper loaded: url_helper
INFO - 2024-12-17 20:56:36 --> Helper loaded: file_helper
INFO - 2024-12-17 20:56:36 --> Helper loaded: form_helper
INFO - 2024-12-17 20:56:36 --> Helper loaded: my_helper
INFO - 2024-12-17 20:56:36 --> Database Driver Class Initialized
INFO - 2024-12-17 20:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:56:36 --> Controller Class Initialized
DEBUG - 2024-12-17 20:56:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:56:40 --> Final output sent to browser
DEBUG - 2024-12-17 20:56:40 --> Total execution time: 4.7907
INFO - 2024-12-17 20:56:41 --> Config Class Initialized
INFO - 2024-12-17 20:56:41 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:56:41 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:56:41 --> Utf8 Class Initialized
INFO - 2024-12-17 20:56:41 --> URI Class Initialized
INFO - 2024-12-17 20:56:41 --> Router Class Initialized
INFO - 2024-12-17 20:56:41 --> Output Class Initialized
INFO - 2024-12-17 20:56:41 --> Security Class Initialized
DEBUG - 2024-12-17 20:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:56:41 --> Input Class Initialized
INFO - 2024-12-17 20:56:41 --> Language Class Initialized
INFO - 2024-12-17 20:56:41 --> Language Class Initialized
INFO - 2024-12-17 20:56:41 --> Config Class Initialized
INFO - 2024-12-17 20:56:41 --> Loader Class Initialized
INFO - 2024-12-17 20:56:41 --> Helper loaded: url_helper
INFO - 2024-12-17 20:56:41 --> Helper loaded: file_helper
INFO - 2024-12-17 20:56:41 --> Helper loaded: form_helper
INFO - 2024-12-17 20:56:41 --> Helper loaded: my_helper
INFO - 2024-12-17 20:56:41 --> Database Driver Class Initialized
INFO - 2024-12-17 20:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:56:41 --> Controller Class Initialized
DEBUG - 2024-12-17 20:56:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:56:45 --> Final output sent to browser
DEBUG - 2024-12-17 20:56:45 --> Total execution time: 4.6165
INFO - 2024-12-17 20:56:46 --> Config Class Initialized
INFO - 2024-12-17 20:56:46 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:56:46 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:56:46 --> Utf8 Class Initialized
INFO - 2024-12-17 20:56:46 --> URI Class Initialized
INFO - 2024-12-17 20:56:46 --> Router Class Initialized
INFO - 2024-12-17 20:56:46 --> Output Class Initialized
INFO - 2024-12-17 20:56:46 --> Security Class Initialized
DEBUG - 2024-12-17 20:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:56:46 --> Input Class Initialized
INFO - 2024-12-17 20:56:46 --> Language Class Initialized
INFO - 2024-12-17 20:56:46 --> Language Class Initialized
INFO - 2024-12-17 20:56:46 --> Config Class Initialized
INFO - 2024-12-17 20:56:46 --> Loader Class Initialized
INFO - 2024-12-17 20:56:46 --> Helper loaded: url_helper
INFO - 2024-12-17 20:56:46 --> Helper loaded: file_helper
INFO - 2024-12-17 20:56:46 --> Helper loaded: form_helper
INFO - 2024-12-17 20:56:46 --> Helper loaded: my_helper
INFO - 2024-12-17 20:56:46 --> Database Driver Class Initialized
INFO - 2024-12-17 20:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:56:46 --> Controller Class Initialized
DEBUG - 2024-12-17 20:56:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:56:50 --> Final output sent to browser
DEBUG - 2024-12-17 20:56:50 --> Total execution time: 4.3582
INFO - 2024-12-17 20:56:50 --> Config Class Initialized
INFO - 2024-12-17 20:56:50 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:56:50 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:56:50 --> Utf8 Class Initialized
INFO - 2024-12-17 20:56:50 --> URI Class Initialized
INFO - 2024-12-17 20:56:50 --> Router Class Initialized
INFO - 2024-12-17 20:56:50 --> Output Class Initialized
INFO - 2024-12-17 20:56:50 --> Security Class Initialized
DEBUG - 2024-12-17 20:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:56:50 --> Input Class Initialized
INFO - 2024-12-17 20:56:50 --> Language Class Initialized
INFO - 2024-12-17 20:56:50 --> Language Class Initialized
INFO - 2024-12-17 20:56:50 --> Config Class Initialized
INFO - 2024-12-17 20:56:50 --> Loader Class Initialized
INFO - 2024-12-17 20:56:50 --> Helper loaded: url_helper
INFO - 2024-12-17 20:56:50 --> Helper loaded: file_helper
INFO - 2024-12-17 20:56:50 --> Helper loaded: form_helper
INFO - 2024-12-17 20:56:50 --> Helper loaded: my_helper
INFO - 2024-12-17 20:56:50 --> Database Driver Class Initialized
INFO - 2024-12-17 20:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:56:50 --> Controller Class Initialized
DEBUG - 2024-12-17 20:56:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:56:55 --> Final output sent to browser
DEBUG - 2024-12-17 20:56:55 --> Total execution time: 4.8325
INFO - 2024-12-17 20:56:56 --> Config Class Initialized
INFO - 2024-12-17 20:56:56 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:56:56 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:56:56 --> Utf8 Class Initialized
INFO - 2024-12-17 20:56:56 --> URI Class Initialized
INFO - 2024-12-17 20:56:56 --> Router Class Initialized
INFO - 2024-12-17 20:56:56 --> Output Class Initialized
INFO - 2024-12-17 20:56:56 --> Security Class Initialized
DEBUG - 2024-12-17 20:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:56:56 --> Input Class Initialized
INFO - 2024-12-17 20:56:56 --> Language Class Initialized
INFO - 2024-12-17 20:56:56 --> Language Class Initialized
INFO - 2024-12-17 20:56:56 --> Config Class Initialized
INFO - 2024-12-17 20:56:56 --> Loader Class Initialized
INFO - 2024-12-17 20:56:56 --> Helper loaded: url_helper
INFO - 2024-12-17 20:56:56 --> Helper loaded: file_helper
INFO - 2024-12-17 20:56:56 --> Helper loaded: form_helper
INFO - 2024-12-17 20:56:56 --> Helper loaded: my_helper
INFO - 2024-12-17 20:56:56 --> Database Driver Class Initialized
INFO - 2024-12-17 20:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:56:56 --> Controller Class Initialized
DEBUG - 2024-12-17 20:56:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:57:00 --> Final output sent to browser
DEBUG - 2024-12-17 20:57:00 --> Total execution time: 4.6381
INFO - 2024-12-17 20:57:00 --> Config Class Initialized
INFO - 2024-12-17 20:57:00 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:57:00 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:57:00 --> Utf8 Class Initialized
INFO - 2024-12-17 20:57:00 --> URI Class Initialized
INFO - 2024-12-17 20:57:00 --> Router Class Initialized
INFO - 2024-12-17 20:57:00 --> Output Class Initialized
INFO - 2024-12-17 20:57:00 --> Security Class Initialized
DEBUG - 2024-12-17 20:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:57:00 --> Input Class Initialized
INFO - 2024-12-17 20:57:00 --> Language Class Initialized
INFO - 2024-12-17 20:57:00 --> Language Class Initialized
INFO - 2024-12-17 20:57:00 --> Config Class Initialized
INFO - 2024-12-17 20:57:00 --> Loader Class Initialized
INFO - 2024-12-17 20:57:00 --> Helper loaded: url_helper
INFO - 2024-12-17 20:57:00 --> Helper loaded: file_helper
INFO - 2024-12-17 20:57:00 --> Helper loaded: form_helper
INFO - 2024-12-17 20:57:00 --> Helper loaded: my_helper
INFO - 2024-12-17 20:57:01 --> Database Driver Class Initialized
INFO - 2024-12-17 20:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:57:01 --> Controller Class Initialized
DEBUG - 2024-12-17 20:57:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:57:06 --> Final output sent to browser
DEBUG - 2024-12-17 20:57:06 --> Total execution time: 5.7271
INFO - 2024-12-17 20:57:06 --> Config Class Initialized
INFO - 2024-12-17 20:57:06 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:57:06 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:57:06 --> Utf8 Class Initialized
INFO - 2024-12-17 20:57:06 --> URI Class Initialized
INFO - 2024-12-17 20:57:06 --> Router Class Initialized
INFO - 2024-12-17 20:57:06 --> Output Class Initialized
INFO - 2024-12-17 20:57:06 --> Security Class Initialized
DEBUG - 2024-12-17 20:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:57:06 --> Input Class Initialized
INFO - 2024-12-17 20:57:06 --> Language Class Initialized
INFO - 2024-12-17 20:57:06 --> Language Class Initialized
INFO - 2024-12-17 20:57:06 --> Config Class Initialized
INFO - 2024-12-17 20:57:06 --> Loader Class Initialized
INFO - 2024-12-17 20:57:06 --> Helper loaded: url_helper
INFO - 2024-12-17 20:57:06 --> Helper loaded: file_helper
INFO - 2024-12-17 20:57:06 --> Helper loaded: form_helper
INFO - 2024-12-17 20:57:06 --> Helper loaded: my_helper
INFO - 2024-12-17 20:57:06 --> Database Driver Class Initialized
INFO - 2024-12-17 20:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:57:06 --> Controller Class Initialized
DEBUG - 2024-12-17 20:57:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:57:13 --> Final output sent to browser
DEBUG - 2024-12-17 20:57:13 --> Total execution time: 6.4443
INFO - 2024-12-17 20:57:13 --> Config Class Initialized
INFO - 2024-12-17 20:57:13 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:57:13 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:57:13 --> Utf8 Class Initialized
INFO - 2024-12-17 20:57:13 --> URI Class Initialized
INFO - 2024-12-17 20:57:13 --> Router Class Initialized
INFO - 2024-12-17 20:57:13 --> Output Class Initialized
INFO - 2024-12-17 20:57:13 --> Security Class Initialized
DEBUG - 2024-12-17 20:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:57:13 --> Input Class Initialized
INFO - 2024-12-17 20:57:13 --> Language Class Initialized
INFO - 2024-12-17 20:57:13 --> Language Class Initialized
INFO - 2024-12-17 20:57:13 --> Config Class Initialized
INFO - 2024-12-17 20:57:13 --> Loader Class Initialized
INFO - 2024-12-17 20:57:13 --> Helper loaded: url_helper
INFO - 2024-12-17 20:57:13 --> Helper loaded: file_helper
INFO - 2024-12-17 20:57:13 --> Helper loaded: form_helper
INFO - 2024-12-17 20:57:13 --> Helper loaded: my_helper
INFO - 2024-12-17 20:57:13 --> Database Driver Class Initialized
INFO - 2024-12-17 20:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:57:13 --> Controller Class Initialized
DEBUG - 2024-12-17 20:57:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:57:22 --> Final output sent to browser
DEBUG - 2024-12-17 20:57:22 --> Total execution time: 9.0272
INFO - 2024-12-17 20:57:22 --> Config Class Initialized
INFO - 2024-12-17 20:57:22 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:57:22 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:57:22 --> Utf8 Class Initialized
INFO - 2024-12-17 20:57:22 --> URI Class Initialized
INFO - 2024-12-17 20:57:22 --> Router Class Initialized
INFO - 2024-12-17 20:57:22 --> Output Class Initialized
INFO - 2024-12-17 20:57:22 --> Security Class Initialized
DEBUG - 2024-12-17 20:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:57:22 --> Input Class Initialized
INFO - 2024-12-17 20:57:22 --> Language Class Initialized
INFO - 2024-12-17 20:57:22 --> Language Class Initialized
INFO - 2024-12-17 20:57:22 --> Config Class Initialized
INFO - 2024-12-17 20:57:22 --> Loader Class Initialized
INFO - 2024-12-17 20:57:22 --> Helper loaded: url_helper
INFO - 2024-12-17 20:57:22 --> Helper loaded: file_helper
INFO - 2024-12-17 20:57:22 --> Helper loaded: form_helper
INFO - 2024-12-17 20:57:22 --> Helper loaded: my_helper
INFO - 2024-12-17 20:57:22 --> Database Driver Class Initialized
INFO - 2024-12-17 20:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:57:22 --> Controller Class Initialized
DEBUG - 2024-12-17 20:57:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:57:32 --> Final output sent to browser
DEBUG - 2024-12-17 20:57:32 --> Total execution time: 10.2379
INFO - 2024-12-17 20:57:33 --> Config Class Initialized
INFO - 2024-12-17 20:57:33 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:57:33 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:57:33 --> Utf8 Class Initialized
INFO - 2024-12-17 20:57:33 --> URI Class Initialized
INFO - 2024-12-17 20:57:33 --> Router Class Initialized
INFO - 2024-12-17 20:57:33 --> Output Class Initialized
INFO - 2024-12-17 20:57:33 --> Security Class Initialized
DEBUG - 2024-12-17 20:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:57:33 --> Input Class Initialized
INFO - 2024-12-17 20:57:33 --> Language Class Initialized
INFO - 2024-12-17 20:57:33 --> Language Class Initialized
INFO - 2024-12-17 20:57:33 --> Config Class Initialized
INFO - 2024-12-17 20:57:33 --> Loader Class Initialized
INFO - 2024-12-17 20:57:33 --> Helper loaded: url_helper
INFO - 2024-12-17 20:57:33 --> Helper loaded: file_helper
INFO - 2024-12-17 20:57:33 --> Helper loaded: form_helper
INFO - 2024-12-17 20:57:33 --> Helper loaded: my_helper
INFO - 2024-12-17 20:57:33 --> Database Driver Class Initialized
INFO - 2024-12-17 20:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:57:33 --> Controller Class Initialized
DEBUG - 2024-12-17 20:57:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:57:42 --> Final output sent to browser
DEBUG - 2024-12-17 20:57:42 --> Total execution time: 9.3396
INFO - 2024-12-17 20:57:42 --> Config Class Initialized
INFO - 2024-12-17 20:57:42 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:57:42 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:57:42 --> Utf8 Class Initialized
INFO - 2024-12-17 20:57:42 --> URI Class Initialized
INFO - 2024-12-17 20:57:42 --> Router Class Initialized
INFO - 2024-12-17 20:57:42 --> Output Class Initialized
INFO - 2024-12-17 20:57:42 --> Security Class Initialized
DEBUG - 2024-12-17 20:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:57:42 --> Input Class Initialized
INFO - 2024-12-17 20:57:42 --> Language Class Initialized
INFO - 2024-12-17 20:57:42 --> Language Class Initialized
INFO - 2024-12-17 20:57:42 --> Config Class Initialized
INFO - 2024-12-17 20:57:42 --> Loader Class Initialized
INFO - 2024-12-17 20:57:42 --> Helper loaded: url_helper
INFO - 2024-12-17 20:57:42 --> Helper loaded: file_helper
INFO - 2024-12-17 20:57:42 --> Helper loaded: form_helper
INFO - 2024-12-17 20:57:42 --> Helper loaded: my_helper
INFO - 2024-12-17 20:57:42 --> Database Driver Class Initialized
INFO - 2024-12-17 20:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:57:42 --> Controller Class Initialized
DEBUG - 2024-12-17 20:57:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:57:52 --> Final output sent to browser
DEBUG - 2024-12-17 20:57:52 --> Total execution time: 9.3383
INFO - 2024-12-17 20:57:52 --> Config Class Initialized
INFO - 2024-12-17 20:57:52 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:57:52 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:57:52 --> Utf8 Class Initialized
INFO - 2024-12-17 20:57:52 --> URI Class Initialized
INFO - 2024-12-17 20:57:52 --> Router Class Initialized
INFO - 2024-12-17 20:57:52 --> Output Class Initialized
INFO - 2024-12-17 20:57:52 --> Security Class Initialized
DEBUG - 2024-12-17 20:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:57:52 --> Input Class Initialized
INFO - 2024-12-17 20:57:52 --> Language Class Initialized
INFO - 2024-12-17 20:57:52 --> Language Class Initialized
INFO - 2024-12-17 20:57:52 --> Config Class Initialized
INFO - 2024-12-17 20:57:52 --> Loader Class Initialized
INFO - 2024-12-17 20:57:52 --> Helper loaded: url_helper
INFO - 2024-12-17 20:57:52 --> Helper loaded: file_helper
INFO - 2024-12-17 20:57:52 --> Helper loaded: form_helper
INFO - 2024-12-17 20:57:52 --> Helper loaded: my_helper
INFO - 2024-12-17 20:57:52 --> Database Driver Class Initialized
INFO - 2024-12-17 20:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:57:52 --> Controller Class Initialized
DEBUG - 2024-12-17 20:57:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:57:58 --> Final output sent to browser
DEBUG - 2024-12-17 20:57:58 --> Total execution time: 6.1434
INFO - 2024-12-17 20:57:58 --> Config Class Initialized
INFO - 2024-12-17 20:57:58 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:57:58 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:57:58 --> Utf8 Class Initialized
INFO - 2024-12-17 20:57:58 --> URI Class Initialized
INFO - 2024-12-17 20:57:58 --> Router Class Initialized
INFO - 2024-12-17 20:57:58 --> Output Class Initialized
INFO - 2024-12-17 20:57:58 --> Security Class Initialized
DEBUG - 2024-12-17 20:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:57:58 --> Input Class Initialized
INFO - 2024-12-17 20:57:58 --> Language Class Initialized
INFO - 2024-12-17 20:57:58 --> Language Class Initialized
INFO - 2024-12-17 20:57:58 --> Config Class Initialized
INFO - 2024-12-17 20:57:58 --> Loader Class Initialized
INFO - 2024-12-17 20:57:58 --> Helper loaded: url_helper
INFO - 2024-12-17 20:57:58 --> Helper loaded: file_helper
INFO - 2024-12-17 20:57:58 --> Helper loaded: form_helper
INFO - 2024-12-17 20:57:58 --> Helper loaded: my_helper
INFO - 2024-12-17 20:57:58 --> Database Driver Class Initialized
INFO - 2024-12-17 20:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:57:58 --> Controller Class Initialized
DEBUG - 2024-12-17 20:57:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:58:03 --> Final output sent to browser
DEBUG - 2024-12-17 20:58:03 --> Total execution time: 5.5169
INFO - 2024-12-17 20:58:04 --> Config Class Initialized
INFO - 2024-12-17 20:58:04 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:58:04 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:58:04 --> Utf8 Class Initialized
INFO - 2024-12-17 20:58:04 --> URI Class Initialized
INFO - 2024-12-17 20:58:04 --> Router Class Initialized
INFO - 2024-12-17 20:58:04 --> Output Class Initialized
INFO - 2024-12-17 20:58:04 --> Security Class Initialized
DEBUG - 2024-12-17 20:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:58:04 --> Input Class Initialized
INFO - 2024-12-17 20:58:04 --> Language Class Initialized
INFO - 2024-12-17 20:58:04 --> Language Class Initialized
INFO - 2024-12-17 20:58:04 --> Config Class Initialized
INFO - 2024-12-17 20:58:04 --> Loader Class Initialized
INFO - 2024-12-17 20:58:04 --> Helper loaded: url_helper
INFO - 2024-12-17 20:58:04 --> Helper loaded: file_helper
INFO - 2024-12-17 20:58:04 --> Helper loaded: form_helper
INFO - 2024-12-17 20:58:04 --> Helper loaded: my_helper
INFO - 2024-12-17 20:58:04 --> Database Driver Class Initialized
INFO - 2024-12-17 20:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:58:04 --> Controller Class Initialized
DEBUG - 2024-12-17 20:58:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:58:09 --> Final output sent to browser
DEBUG - 2024-12-17 20:58:09 --> Total execution time: 5.0157
INFO - 2024-12-17 20:58:09 --> Config Class Initialized
INFO - 2024-12-17 20:58:09 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:58:09 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:58:09 --> Utf8 Class Initialized
INFO - 2024-12-17 20:58:09 --> URI Class Initialized
INFO - 2024-12-17 20:58:09 --> Router Class Initialized
INFO - 2024-12-17 20:58:09 --> Output Class Initialized
INFO - 2024-12-17 20:58:09 --> Security Class Initialized
DEBUG - 2024-12-17 20:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:58:09 --> Input Class Initialized
INFO - 2024-12-17 20:58:09 --> Language Class Initialized
INFO - 2024-12-17 20:58:09 --> Language Class Initialized
INFO - 2024-12-17 20:58:09 --> Config Class Initialized
INFO - 2024-12-17 20:58:09 --> Loader Class Initialized
INFO - 2024-12-17 20:58:09 --> Helper loaded: url_helper
INFO - 2024-12-17 20:58:09 --> Helper loaded: file_helper
INFO - 2024-12-17 20:58:09 --> Helper loaded: form_helper
INFO - 2024-12-17 20:58:09 --> Helper loaded: my_helper
INFO - 2024-12-17 20:58:09 --> Database Driver Class Initialized
INFO - 2024-12-17 20:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:58:09 --> Controller Class Initialized
DEBUG - 2024-12-17 20:58:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:58:13 --> Final output sent to browser
DEBUG - 2024-12-17 20:58:13 --> Total execution time: 4.7347
INFO - 2024-12-17 20:58:14 --> Config Class Initialized
INFO - 2024-12-17 20:58:14 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:58:14 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:58:14 --> Utf8 Class Initialized
INFO - 2024-12-17 20:58:14 --> URI Class Initialized
INFO - 2024-12-17 20:58:14 --> Router Class Initialized
INFO - 2024-12-17 20:58:14 --> Output Class Initialized
INFO - 2024-12-17 20:58:14 --> Security Class Initialized
DEBUG - 2024-12-17 20:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:58:14 --> Input Class Initialized
INFO - 2024-12-17 20:58:14 --> Language Class Initialized
INFO - 2024-12-17 20:58:14 --> Language Class Initialized
INFO - 2024-12-17 20:58:14 --> Config Class Initialized
INFO - 2024-12-17 20:58:14 --> Loader Class Initialized
INFO - 2024-12-17 20:58:14 --> Helper loaded: url_helper
INFO - 2024-12-17 20:58:14 --> Helper loaded: file_helper
INFO - 2024-12-17 20:58:14 --> Helper loaded: form_helper
INFO - 2024-12-17 20:58:14 --> Helper loaded: my_helper
INFO - 2024-12-17 20:58:14 --> Database Driver Class Initialized
INFO - 2024-12-17 20:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:58:14 --> Controller Class Initialized
DEBUG - 2024-12-17 20:58:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:58:18 --> Final output sent to browser
DEBUG - 2024-12-17 20:58:18 --> Total execution time: 4.4665
INFO - 2024-12-17 20:58:18 --> Config Class Initialized
INFO - 2024-12-17 20:58:18 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:58:18 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:58:18 --> Utf8 Class Initialized
INFO - 2024-12-17 20:58:18 --> URI Class Initialized
INFO - 2024-12-17 20:58:18 --> Router Class Initialized
INFO - 2024-12-17 20:58:18 --> Output Class Initialized
INFO - 2024-12-17 20:58:18 --> Security Class Initialized
DEBUG - 2024-12-17 20:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:58:18 --> Input Class Initialized
INFO - 2024-12-17 20:58:18 --> Language Class Initialized
INFO - 2024-12-17 20:58:18 --> Language Class Initialized
INFO - 2024-12-17 20:58:18 --> Config Class Initialized
INFO - 2024-12-17 20:58:18 --> Loader Class Initialized
INFO - 2024-12-17 20:58:18 --> Helper loaded: url_helper
INFO - 2024-12-17 20:58:18 --> Helper loaded: file_helper
INFO - 2024-12-17 20:58:18 --> Helper loaded: form_helper
INFO - 2024-12-17 20:58:18 --> Helper loaded: my_helper
INFO - 2024-12-17 20:58:18 --> Database Driver Class Initialized
INFO - 2024-12-17 20:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:58:18 --> Controller Class Initialized
DEBUG - 2024-12-17 20:58:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:58:23 --> Final output sent to browser
DEBUG - 2024-12-17 20:58:23 --> Total execution time: 4.9161
INFO - 2024-12-17 20:58:23 --> Config Class Initialized
INFO - 2024-12-17 20:58:23 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:58:23 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:58:23 --> Utf8 Class Initialized
INFO - 2024-12-17 20:58:23 --> URI Class Initialized
INFO - 2024-12-17 20:58:23 --> Router Class Initialized
INFO - 2024-12-17 20:58:23 --> Output Class Initialized
INFO - 2024-12-17 20:58:23 --> Security Class Initialized
DEBUG - 2024-12-17 20:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:58:23 --> Input Class Initialized
INFO - 2024-12-17 20:58:23 --> Language Class Initialized
INFO - 2024-12-17 20:58:23 --> Language Class Initialized
INFO - 2024-12-17 20:58:23 --> Config Class Initialized
INFO - 2024-12-17 20:58:23 --> Loader Class Initialized
INFO - 2024-12-17 20:58:23 --> Helper loaded: url_helper
INFO - 2024-12-17 20:58:23 --> Helper loaded: file_helper
INFO - 2024-12-17 20:58:23 --> Helper loaded: form_helper
INFO - 2024-12-17 20:58:23 --> Helper loaded: my_helper
INFO - 2024-12-17 20:58:23 --> Database Driver Class Initialized
INFO - 2024-12-17 20:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:58:23 --> Controller Class Initialized
DEBUG - 2024-12-17 20:58:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:58:33 --> Final output sent to browser
DEBUG - 2024-12-17 20:58:33 --> Total execution time: 10.1779
INFO - 2024-12-17 20:58:34 --> Config Class Initialized
INFO - 2024-12-17 20:58:34 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:58:34 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:58:34 --> Utf8 Class Initialized
INFO - 2024-12-17 20:58:34 --> URI Class Initialized
INFO - 2024-12-17 20:58:34 --> Router Class Initialized
INFO - 2024-12-17 20:58:34 --> Output Class Initialized
INFO - 2024-12-17 20:58:34 --> Security Class Initialized
DEBUG - 2024-12-17 20:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:58:34 --> Input Class Initialized
INFO - 2024-12-17 20:58:34 --> Language Class Initialized
INFO - 2024-12-17 20:58:34 --> Language Class Initialized
INFO - 2024-12-17 20:58:34 --> Config Class Initialized
INFO - 2024-12-17 20:58:34 --> Loader Class Initialized
INFO - 2024-12-17 20:58:34 --> Helper loaded: url_helper
INFO - 2024-12-17 20:58:34 --> Helper loaded: file_helper
INFO - 2024-12-17 20:58:34 --> Helper loaded: form_helper
INFO - 2024-12-17 20:58:34 --> Helper loaded: my_helper
INFO - 2024-12-17 20:58:34 --> Database Driver Class Initialized
INFO - 2024-12-17 20:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:58:34 --> Controller Class Initialized
DEBUG - 2024-12-17 20:58:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:58:41 --> Final output sent to browser
DEBUG - 2024-12-17 20:58:41 --> Total execution time: 7.8187
INFO - 2024-12-17 20:58:42 --> Config Class Initialized
INFO - 2024-12-17 20:58:42 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:58:42 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:58:42 --> Utf8 Class Initialized
INFO - 2024-12-17 20:58:42 --> URI Class Initialized
INFO - 2024-12-17 20:58:42 --> Router Class Initialized
INFO - 2024-12-17 20:58:42 --> Output Class Initialized
INFO - 2024-12-17 20:58:42 --> Security Class Initialized
DEBUG - 2024-12-17 20:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:58:42 --> Input Class Initialized
INFO - 2024-12-17 20:58:42 --> Language Class Initialized
INFO - 2024-12-17 20:58:42 --> Language Class Initialized
INFO - 2024-12-17 20:58:42 --> Config Class Initialized
INFO - 2024-12-17 20:58:42 --> Loader Class Initialized
INFO - 2024-12-17 20:58:42 --> Helper loaded: url_helper
INFO - 2024-12-17 20:58:42 --> Helper loaded: file_helper
INFO - 2024-12-17 20:58:42 --> Helper loaded: form_helper
INFO - 2024-12-17 20:58:42 --> Helper loaded: my_helper
INFO - 2024-12-17 20:58:42 --> Database Driver Class Initialized
INFO - 2024-12-17 20:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:58:42 --> Controller Class Initialized
DEBUG - 2024-12-17 20:58:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:58:47 --> Final output sent to browser
DEBUG - 2024-12-17 20:58:47 --> Total execution time: 4.9721
INFO - 2024-12-17 20:58:47 --> Config Class Initialized
INFO - 2024-12-17 20:58:47 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:58:47 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:58:47 --> Utf8 Class Initialized
INFO - 2024-12-17 20:58:47 --> URI Class Initialized
INFO - 2024-12-17 20:58:47 --> Router Class Initialized
INFO - 2024-12-17 20:58:47 --> Output Class Initialized
INFO - 2024-12-17 20:58:47 --> Security Class Initialized
DEBUG - 2024-12-17 20:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:58:47 --> Input Class Initialized
INFO - 2024-12-17 20:58:47 --> Language Class Initialized
INFO - 2024-12-17 20:58:47 --> Language Class Initialized
INFO - 2024-12-17 20:58:47 --> Config Class Initialized
INFO - 2024-12-17 20:58:47 --> Loader Class Initialized
INFO - 2024-12-17 20:58:47 --> Helper loaded: url_helper
INFO - 2024-12-17 20:58:47 --> Helper loaded: file_helper
INFO - 2024-12-17 20:58:47 --> Helper loaded: form_helper
INFO - 2024-12-17 20:58:47 --> Helper loaded: my_helper
INFO - 2024-12-17 20:58:47 --> Database Driver Class Initialized
INFO - 2024-12-17 20:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:58:47 --> Controller Class Initialized
DEBUG - 2024-12-17 20:58:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:58:52 --> Final output sent to browser
DEBUG - 2024-12-17 20:58:52 --> Total execution time: 4.9457
INFO - 2024-12-17 20:58:52 --> Config Class Initialized
INFO - 2024-12-17 20:58:52 --> Hooks Class Initialized
DEBUG - 2024-12-17 20:58:52 --> UTF-8 Support Enabled
INFO - 2024-12-17 20:58:52 --> Utf8 Class Initialized
INFO - 2024-12-17 20:58:52 --> URI Class Initialized
INFO - 2024-12-17 20:58:52 --> Router Class Initialized
INFO - 2024-12-17 20:58:52 --> Output Class Initialized
INFO - 2024-12-17 20:58:52 --> Security Class Initialized
DEBUG - 2024-12-17 20:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 20:58:52 --> Input Class Initialized
INFO - 2024-12-17 20:58:52 --> Language Class Initialized
INFO - 2024-12-17 20:58:52 --> Language Class Initialized
INFO - 2024-12-17 20:58:52 --> Config Class Initialized
INFO - 2024-12-17 20:58:52 --> Loader Class Initialized
INFO - 2024-12-17 20:58:52 --> Helper loaded: url_helper
INFO - 2024-12-17 20:58:52 --> Helper loaded: file_helper
INFO - 2024-12-17 20:58:52 --> Helper loaded: form_helper
INFO - 2024-12-17 20:58:52 --> Helper loaded: my_helper
INFO - 2024-12-17 20:58:52 --> Database Driver Class Initialized
INFO - 2024-12-17 20:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 20:58:52 --> Controller Class Initialized
DEBUG - 2024-12-17 20:58:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 20:58:57 --> Final output sent to browser
DEBUG - 2024-12-17 20:58:57 --> Total execution time: 4.6606
INFO - 2024-12-17 21:01:30 --> Config Class Initialized
INFO - 2024-12-17 21:01:30 --> Hooks Class Initialized
DEBUG - 2024-12-17 21:01:30 --> UTF-8 Support Enabled
INFO - 2024-12-17 21:01:30 --> Utf8 Class Initialized
INFO - 2024-12-17 21:01:30 --> URI Class Initialized
INFO - 2024-12-17 21:01:30 --> Router Class Initialized
INFO - 2024-12-17 21:01:30 --> Output Class Initialized
INFO - 2024-12-17 21:01:30 --> Security Class Initialized
DEBUG - 2024-12-17 21:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 21:01:30 --> Input Class Initialized
INFO - 2024-12-17 21:01:30 --> Language Class Initialized
INFO - 2024-12-17 21:01:30 --> Language Class Initialized
INFO - 2024-12-17 21:01:30 --> Config Class Initialized
INFO - 2024-12-17 21:01:30 --> Loader Class Initialized
INFO - 2024-12-17 21:01:30 --> Helper loaded: url_helper
INFO - 2024-12-17 21:01:30 --> Helper loaded: file_helper
INFO - 2024-12-17 21:01:30 --> Helper loaded: form_helper
INFO - 2024-12-17 21:01:30 --> Helper loaded: my_helper
INFO - 2024-12-17 21:01:30 --> Database Driver Class Initialized
INFO - 2024-12-17 21:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 21:01:30 --> Controller Class Initialized
DEBUG - 2024-12-17 21:01:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 21:01:35 --> Final output sent to browser
DEBUG - 2024-12-17 21:01:35 --> Total execution time: 5.5361
INFO - 2024-12-17 21:01:35 --> Config Class Initialized
INFO - 2024-12-17 21:01:35 --> Hooks Class Initialized
DEBUG - 2024-12-17 21:01:35 --> UTF-8 Support Enabled
INFO - 2024-12-17 21:01:35 --> Utf8 Class Initialized
INFO - 2024-12-17 21:01:35 --> URI Class Initialized
INFO - 2024-12-17 21:01:35 --> Router Class Initialized
INFO - 2024-12-17 21:01:35 --> Output Class Initialized
INFO - 2024-12-17 21:01:35 --> Security Class Initialized
DEBUG - 2024-12-17 21:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 21:01:35 --> Input Class Initialized
INFO - 2024-12-17 21:01:35 --> Language Class Initialized
INFO - 2024-12-17 21:01:35 --> Language Class Initialized
INFO - 2024-12-17 21:01:35 --> Config Class Initialized
INFO - 2024-12-17 21:01:35 --> Loader Class Initialized
INFO - 2024-12-17 21:01:35 --> Helper loaded: url_helper
INFO - 2024-12-17 21:01:35 --> Helper loaded: file_helper
INFO - 2024-12-17 21:01:35 --> Helper loaded: form_helper
INFO - 2024-12-17 21:01:35 --> Helper loaded: my_helper
INFO - 2024-12-17 21:01:35 --> Database Driver Class Initialized
INFO - 2024-12-17 21:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 21:01:35 --> Controller Class Initialized
DEBUG - 2024-12-17 21:01:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-17 21:01:40 --> Final output sent to browser
DEBUG - 2024-12-17 21:01:40 --> Total execution time: 4.9736
