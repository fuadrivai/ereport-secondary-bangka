<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-04-19 11:32:15 --> Config Class Initialized
INFO - 2023-04-19 11:32:15 --> Hooks Class Initialized
DEBUG - 2023-04-19 11:32:15 --> UTF-8 Support Enabled
INFO - 2023-04-19 11:32:15 --> Utf8 Class Initialized
INFO - 2023-04-19 11:32:15 --> URI Class Initialized
DEBUG - 2023-04-19 11:32:15 --> No URI present. Default controller set.
INFO - 2023-04-19 11:32:15 --> Router Class Initialized
INFO - 2023-04-19 11:32:15 --> Output Class Initialized
INFO - 2023-04-19 11:32:15 --> Security Class Initialized
DEBUG - 2023-04-19 11:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 11:32:15 --> Input Class Initialized
INFO - 2023-04-19 11:32:15 --> Language Class Initialized
INFO - 2023-04-19 11:32:16 --> Language Class Initialized
INFO - 2023-04-19 11:32:16 --> Config Class Initialized
INFO - 2023-04-19 11:32:16 --> Loader Class Initialized
INFO - 2023-04-19 11:32:16 --> Helper loaded: url_helper
INFO - 2023-04-19 11:32:16 --> Helper loaded: file_helper
INFO - 2023-04-19 11:32:16 --> Helper loaded: form_helper
INFO - 2023-04-19 11:32:16 --> Helper loaded: my_helper
INFO - 2023-04-19 11:32:16 --> Database Driver Class Initialized
ERROR - 2023-04-19 11:32:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\myraportk13\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2023-04-19 11:32:20 --> Unable to connect to the database
INFO - 2023-04-19 11:32:20 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-19 11:42:25 --> Config Class Initialized
INFO - 2023-04-19 11:42:25 --> Hooks Class Initialized
DEBUG - 2023-04-19 11:42:25 --> UTF-8 Support Enabled
INFO - 2023-04-19 11:42:25 --> Utf8 Class Initialized
INFO - 2023-04-19 11:42:25 --> URI Class Initialized
DEBUG - 2023-04-19 11:42:25 --> No URI present. Default controller set.
INFO - 2023-04-19 11:42:25 --> Router Class Initialized
INFO - 2023-04-19 11:42:25 --> Output Class Initialized
INFO - 2023-04-19 11:42:25 --> Security Class Initialized
DEBUG - 2023-04-19 11:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 11:42:25 --> Input Class Initialized
INFO - 2023-04-19 11:42:25 --> Language Class Initialized
INFO - 2023-04-19 11:42:25 --> Language Class Initialized
INFO - 2023-04-19 11:42:25 --> Config Class Initialized
INFO - 2023-04-19 11:42:25 --> Loader Class Initialized
INFO - 2023-04-19 11:42:25 --> Helper loaded: url_helper
INFO - 2023-04-19 11:42:25 --> Helper loaded: file_helper
INFO - 2023-04-19 11:42:25 --> Helper loaded: form_helper
INFO - 2023-04-19 11:42:25 --> Helper loaded: my_helper
INFO - 2023-04-19 11:42:25 --> Database Driver Class Initialized
DEBUG - 2023-04-19 11:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-19 11:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-19 11:42:26 --> Controller Class Initialized
INFO - 2023-04-19 11:42:26 --> Config Class Initialized
INFO - 2023-04-19 11:42:26 --> Hooks Class Initialized
DEBUG - 2023-04-19 11:42:26 --> UTF-8 Support Enabled
INFO - 2023-04-19 11:42:26 --> Utf8 Class Initialized
INFO - 2023-04-19 11:42:26 --> URI Class Initialized
INFO - 2023-04-19 11:42:26 --> Router Class Initialized
INFO - 2023-04-19 11:42:26 --> Output Class Initialized
INFO - 2023-04-19 11:42:26 --> Security Class Initialized
DEBUG - 2023-04-19 11:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 11:42:26 --> Input Class Initialized
INFO - 2023-04-19 11:42:26 --> Language Class Initialized
INFO - 2023-04-19 11:42:26 --> Language Class Initialized
INFO - 2023-04-19 11:42:26 --> Config Class Initialized
INFO - 2023-04-19 11:42:26 --> Loader Class Initialized
INFO - 2023-04-19 11:42:26 --> Helper loaded: url_helper
INFO - 2023-04-19 11:42:26 --> Helper loaded: file_helper
INFO - 2023-04-19 11:42:26 --> Helper loaded: form_helper
INFO - 2023-04-19 11:42:26 --> Helper loaded: my_helper
INFO - 2023-04-19 11:42:26 --> Database Driver Class Initialized
DEBUG - 2023-04-19 11:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-19 11:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-19 11:42:26 --> Controller Class Initialized
DEBUG - 2023-04-19 11:42:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-04-19 11:42:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-19 11:42:26 --> Final output sent to browser
DEBUG - 2023-04-19 11:42:26 --> Total execution time: 0.1040
INFO - 2023-04-19 11:42:34 --> Config Class Initialized
INFO - 2023-04-19 11:42:34 --> Hooks Class Initialized
DEBUG - 2023-04-19 11:42:34 --> UTF-8 Support Enabled
INFO - 2023-04-19 11:42:34 --> Utf8 Class Initialized
INFO - 2023-04-19 11:42:34 --> URI Class Initialized
INFO - 2023-04-19 11:42:34 --> Router Class Initialized
INFO - 2023-04-19 11:42:34 --> Output Class Initialized
INFO - 2023-04-19 11:42:34 --> Security Class Initialized
DEBUG - 2023-04-19 11:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 11:42:34 --> Input Class Initialized
INFO - 2023-04-19 11:42:34 --> Language Class Initialized
INFO - 2023-04-19 11:42:34 --> Language Class Initialized
INFO - 2023-04-19 11:42:34 --> Config Class Initialized
INFO - 2023-04-19 11:42:34 --> Loader Class Initialized
INFO - 2023-04-19 11:42:34 --> Helper loaded: url_helper
INFO - 2023-04-19 11:42:34 --> Helper loaded: file_helper
INFO - 2023-04-19 11:42:34 --> Helper loaded: form_helper
INFO - 2023-04-19 11:42:34 --> Helper loaded: my_helper
INFO - 2023-04-19 11:42:34 --> Database Driver Class Initialized
DEBUG - 2023-04-19 11:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-19 11:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-19 11:42:34 --> Controller Class Initialized
INFO - 2023-04-19 11:42:34 --> Helper loaded: cookie_helper
INFO - 2023-04-19 11:42:34 --> Final output sent to browser
DEBUG - 2023-04-19 11:42:34 --> Total execution time: 0.1376
INFO - 2023-04-19 11:42:34 --> Config Class Initialized
INFO - 2023-04-19 11:42:34 --> Hooks Class Initialized
DEBUG - 2023-04-19 11:42:34 --> UTF-8 Support Enabled
INFO - 2023-04-19 11:42:34 --> Utf8 Class Initialized
INFO - 2023-04-19 11:42:34 --> URI Class Initialized
INFO - 2023-04-19 11:42:34 --> Router Class Initialized
INFO - 2023-04-19 11:42:34 --> Output Class Initialized
INFO - 2023-04-19 11:42:34 --> Security Class Initialized
DEBUG - 2023-04-19 11:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 11:42:34 --> Input Class Initialized
INFO - 2023-04-19 11:42:34 --> Language Class Initialized
INFO - 2023-04-19 11:42:34 --> Language Class Initialized
INFO - 2023-04-19 11:42:34 --> Config Class Initialized
INFO - 2023-04-19 11:42:34 --> Loader Class Initialized
INFO - 2023-04-19 11:42:34 --> Helper loaded: url_helper
INFO - 2023-04-19 11:42:34 --> Helper loaded: file_helper
INFO - 2023-04-19 11:42:34 --> Helper loaded: form_helper
INFO - 2023-04-19 11:42:34 --> Helper loaded: my_helper
INFO - 2023-04-19 11:42:34 --> Database Driver Class Initialized
DEBUG - 2023-04-19 11:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-19 11:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-19 11:42:34 --> Controller Class Initialized
DEBUG - 2023-04-19 11:42:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-04-19 11:42:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-19 11:42:34 --> Final output sent to browser
DEBUG - 2023-04-19 11:42:34 --> Total execution time: 0.1348
INFO - 2023-04-19 11:42:53 --> Config Class Initialized
INFO - 2023-04-19 11:42:53 --> Hooks Class Initialized
DEBUG - 2023-04-19 11:42:53 --> UTF-8 Support Enabled
INFO - 2023-04-19 11:42:53 --> Utf8 Class Initialized
INFO - 2023-04-19 11:42:53 --> URI Class Initialized
INFO - 2023-04-19 11:42:53 --> Router Class Initialized
INFO - 2023-04-19 11:42:53 --> Output Class Initialized
INFO - 2023-04-19 11:42:53 --> Security Class Initialized
DEBUG - 2023-04-19 11:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 11:42:53 --> Input Class Initialized
INFO - 2023-04-19 11:42:53 --> Language Class Initialized
INFO - 2023-04-19 11:42:53 --> Language Class Initialized
INFO - 2023-04-19 11:42:53 --> Config Class Initialized
INFO - 2023-04-19 11:42:53 --> Loader Class Initialized
INFO - 2023-04-19 11:42:53 --> Helper loaded: url_helper
INFO - 2023-04-19 11:42:53 --> Helper loaded: file_helper
INFO - 2023-04-19 11:42:53 --> Helper loaded: form_helper
INFO - 2023-04-19 11:42:53 --> Helper loaded: my_helper
INFO - 2023-04-19 11:42:53 --> Database Driver Class Initialized
DEBUG - 2023-04-19 11:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-19 11:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-19 11:42:53 --> Controller Class Initialized
DEBUG - 2023-04-19 11:42:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_homeroom/views/list.php
DEBUG - 2023-04-19 11:42:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-19 11:42:53 --> Final output sent to browser
DEBUG - 2023-04-19 11:42:53 --> Total execution time: 0.1336
INFO - 2023-04-19 11:43:04 --> Config Class Initialized
INFO - 2023-04-19 11:43:04 --> Hooks Class Initialized
DEBUG - 2023-04-19 11:43:04 --> UTF-8 Support Enabled
INFO - 2023-04-19 11:43:04 --> Utf8 Class Initialized
INFO - 2023-04-19 11:43:04 --> URI Class Initialized
INFO - 2023-04-19 11:43:04 --> Router Class Initialized
INFO - 2023-04-19 11:43:04 --> Output Class Initialized
INFO - 2023-04-19 11:43:04 --> Security Class Initialized
DEBUG - 2023-04-19 11:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 11:43:04 --> Input Class Initialized
INFO - 2023-04-19 11:43:04 --> Language Class Initialized
INFO - 2023-04-19 11:43:04 --> Language Class Initialized
INFO - 2023-04-19 11:43:04 --> Config Class Initialized
INFO - 2023-04-19 11:43:04 --> Loader Class Initialized
INFO - 2023-04-19 11:43:04 --> Helper loaded: url_helper
INFO - 2023-04-19 11:43:04 --> Helper loaded: file_helper
INFO - 2023-04-19 11:43:04 --> Helper loaded: form_helper
INFO - 2023-04-19 11:43:04 --> Helper loaded: my_helper
INFO - 2023-04-19 11:43:04 --> Database Driver Class Initialized
DEBUG - 2023-04-19 11:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-19 11:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-19 11:43:04 --> Controller Class Initialized
DEBUG - 2023-04-19 11:43:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-04-19 11:43:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-19 11:43:04 --> Final output sent to browser
DEBUG - 2023-04-19 11:43:04 --> Total execution time: 0.1150
INFO - 2023-04-19 11:43:08 --> Config Class Initialized
INFO - 2023-04-19 11:43:08 --> Hooks Class Initialized
DEBUG - 2023-04-19 11:43:08 --> UTF-8 Support Enabled
INFO - 2023-04-19 11:43:08 --> Utf8 Class Initialized
INFO - 2023-04-19 11:43:08 --> URI Class Initialized
INFO - 2023-04-19 11:43:08 --> Router Class Initialized
INFO - 2023-04-19 11:43:08 --> Output Class Initialized
INFO - 2023-04-19 11:43:08 --> Security Class Initialized
DEBUG - 2023-04-19 11:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 11:43:08 --> Input Class Initialized
INFO - 2023-04-19 11:43:08 --> Language Class Initialized
INFO - 2023-04-19 11:43:08 --> Language Class Initialized
INFO - 2023-04-19 11:43:08 --> Config Class Initialized
INFO - 2023-04-19 11:43:08 --> Loader Class Initialized
INFO - 2023-04-19 11:43:08 --> Helper loaded: url_helper
INFO - 2023-04-19 11:43:08 --> Helper loaded: file_helper
INFO - 2023-04-19 11:43:08 --> Helper loaded: form_helper
INFO - 2023-04-19 11:43:08 --> Helper loaded: my_helper
INFO - 2023-04-19 11:43:08 --> Database Driver Class Initialized
DEBUG - 2023-04-19 11:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-19 11:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-19 11:43:08 --> Controller Class Initialized
DEBUG - 2023-04-19 11:43:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_homeroom/views/list.php
DEBUG - 2023-04-19 11:43:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-19 11:43:08 --> Final output sent to browser
DEBUG - 2023-04-19 11:43:08 --> Total execution time: 0.0441
INFO - 2023-04-19 11:45:50 --> Config Class Initialized
INFO - 2023-04-19 11:45:50 --> Hooks Class Initialized
DEBUG - 2023-04-19 11:45:50 --> UTF-8 Support Enabled
INFO - 2023-04-19 11:45:50 --> Utf8 Class Initialized
INFO - 2023-04-19 11:45:50 --> URI Class Initialized
INFO - 2023-04-19 11:45:50 --> Router Class Initialized
INFO - 2023-04-19 11:45:50 --> Output Class Initialized
INFO - 2023-04-19 11:45:50 --> Security Class Initialized
DEBUG - 2023-04-19 11:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 11:45:50 --> Input Class Initialized
INFO - 2023-04-19 11:45:50 --> Language Class Initialized
INFO - 2023-04-19 11:45:50 --> Language Class Initialized
INFO - 2023-04-19 11:45:50 --> Config Class Initialized
INFO - 2023-04-19 11:45:50 --> Loader Class Initialized
INFO - 2023-04-19 11:45:50 --> Helper loaded: url_helper
INFO - 2023-04-19 11:45:50 --> Helper loaded: file_helper
INFO - 2023-04-19 11:45:50 --> Helper loaded: form_helper
INFO - 2023-04-19 11:45:50 --> Helper loaded: my_helper
INFO - 2023-04-19 11:45:50 --> Database Driver Class Initialized
DEBUG - 2023-04-19 11:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-19 11:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-19 11:45:50 --> Controller Class Initialized
DEBUG - 2023-04-19 11:45:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_homeroom/views/list.php
DEBUG - 2023-04-19 11:45:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-19 11:45:50 --> Final output sent to browser
DEBUG - 2023-04-19 11:45:50 --> Total execution time: 0.0447
INFO - 2023-04-19 13:20:41 --> Config Class Initialized
INFO - 2023-04-19 13:20:41 --> Hooks Class Initialized
DEBUG - 2023-04-19 13:20:41 --> UTF-8 Support Enabled
INFO - 2023-04-19 13:20:41 --> Utf8 Class Initialized
INFO - 2023-04-19 13:20:41 --> URI Class Initialized
INFO - 2023-04-19 13:20:42 --> Router Class Initialized
INFO - 2023-04-19 13:20:42 --> Output Class Initialized
INFO - 2023-04-19 13:20:42 --> Security Class Initialized
DEBUG - 2023-04-19 13:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 13:20:42 --> Input Class Initialized
INFO - 2023-04-19 13:20:42 --> Language Class Initialized
INFO - 2023-04-19 13:20:42 --> Language Class Initialized
INFO - 2023-04-19 13:20:42 --> Config Class Initialized
INFO - 2023-04-19 13:20:42 --> Loader Class Initialized
INFO - 2023-04-19 13:20:42 --> Helper loaded: url_helper
INFO - 2023-04-19 13:20:42 --> Helper loaded: file_helper
INFO - 2023-04-19 13:20:42 --> Helper loaded: form_helper
INFO - 2023-04-19 13:20:42 --> Helper loaded: my_helper
INFO - 2023-04-19 13:20:42 --> Database Driver Class Initialized
DEBUG - 2023-04-19 13:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-19 13:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-19 13:20:42 --> Controller Class Initialized
DEBUG - 2023-04-19 13:20:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_homeroom/views/list.php
DEBUG - 2023-04-19 13:20:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-19 13:20:42 --> Final output sent to browser
DEBUG - 2023-04-19 13:20:42 --> Total execution time: 1.0296
INFO - 2023-04-19 13:20:46 --> Config Class Initialized
INFO - 2023-04-19 13:20:46 --> Hooks Class Initialized
DEBUG - 2023-04-19 13:20:46 --> UTF-8 Support Enabled
INFO - 2023-04-19 13:20:46 --> Utf8 Class Initialized
INFO - 2023-04-19 13:20:46 --> URI Class Initialized
INFO - 2023-04-19 13:20:46 --> Router Class Initialized
INFO - 2023-04-19 13:20:46 --> Output Class Initialized
INFO - 2023-04-19 13:20:46 --> Security Class Initialized
DEBUG - 2023-04-19 13:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 13:20:46 --> Input Class Initialized
INFO - 2023-04-19 13:20:46 --> Language Class Initialized
INFO - 2023-04-19 13:20:46 --> Language Class Initialized
INFO - 2023-04-19 13:20:46 --> Config Class Initialized
INFO - 2023-04-19 13:20:46 --> Loader Class Initialized
INFO - 2023-04-19 13:20:46 --> Helper loaded: url_helper
INFO - 2023-04-19 13:20:46 --> Helper loaded: file_helper
INFO - 2023-04-19 13:20:46 --> Helper loaded: form_helper
INFO - 2023-04-19 13:20:46 --> Helper loaded: my_helper
INFO - 2023-04-19 13:20:46 --> Database Driver Class Initialized
DEBUG - 2023-04-19 13:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-19 13:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-19 13:20:46 --> Controller Class Initialized
DEBUG - 2023-04-19 13:20:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-04-19 13:20:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-19 13:20:46 --> Final output sent to browser
DEBUG - 2023-04-19 13:20:46 --> Total execution time: 0.1125
INFO - 2023-04-19 13:21:05 --> Config Class Initialized
INFO - 2023-04-19 13:21:05 --> Hooks Class Initialized
DEBUG - 2023-04-19 13:21:05 --> UTF-8 Support Enabled
INFO - 2023-04-19 13:21:05 --> Utf8 Class Initialized
INFO - 2023-04-19 13:21:05 --> URI Class Initialized
INFO - 2023-04-19 13:21:05 --> Router Class Initialized
INFO - 2023-04-19 13:21:05 --> Output Class Initialized
INFO - 2023-04-19 13:21:05 --> Security Class Initialized
DEBUG - 2023-04-19 13:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 13:21:05 --> Input Class Initialized
INFO - 2023-04-19 13:21:05 --> Language Class Initialized
INFO - 2023-04-19 13:21:05 --> Language Class Initialized
INFO - 2023-04-19 13:21:05 --> Config Class Initialized
INFO - 2023-04-19 13:21:05 --> Loader Class Initialized
INFO - 2023-04-19 13:21:05 --> Helper loaded: url_helper
INFO - 2023-04-19 13:21:05 --> Helper loaded: file_helper
INFO - 2023-04-19 13:21:05 --> Helper loaded: form_helper
INFO - 2023-04-19 13:21:05 --> Helper loaded: my_helper
INFO - 2023-04-19 13:21:05 --> Database Driver Class Initialized
DEBUG - 2023-04-19 13:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-19 13:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-19 13:21:05 --> Controller Class Initialized
DEBUG - 2023-04-19 13:21:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-04-19 13:21:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-19 13:21:05 --> Final output sent to browser
DEBUG - 2023-04-19 13:21:05 --> Total execution time: 0.0454
INFO - 2023-04-19 13:21:07 --> Config Class Initialized
INFO - 2023-04-19 13:21:07 --> Hooks Class Initialized
DEBUG - 2023-04-19 13:21:07 --> UTF-8 Support Enabled
INFO - 2023-04-19 13:21:07 --> Utf8 Class Initialized
INFO - 2023-04-19 13:21:07 --> URI Class Initialized
INFO - 2023-04-19 13:21:07 --> Router Class Initialized
INFO - 2023-04-19 13:21:07 --> Output Class Initialized
INFO - 2023-04-19 13:21:07 --> Security Class Initialized
DEBUG - 2023-04-19 13:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 13:21:07 --> Input Class Initialized
INFO - 2023-04-19 13:21:07 --> Language Class Initialized
INFO - 2023-04-19 13:21:07 --> Language Class Initialized
INFO - 2023-04-19 13:21:07 --> Config Class Initialized
INFO - 2023-04-19 13:21:07 --> Loader Class Initialized
INFO - 2023-04-19 13:21:07 --> Helper loaded: url_helper
INFO - 2023-04-19 13:21:07 --> Helper loaded: file_helper
INFO - 2023-04-19 13:21:07 --> Helper loaded: form_helper
INFO - 2023-04-19 13:21:07 --> Helper loaded: my_helper
INFO - 2023-04-19 13:21:07 --> Database Driver Class Initialized
DEBUG - 2023-04-19 13:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-19 13:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-19 13:21:07 --> Controller Class Initialized
DEBUG - 2023-04-19 13:21:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl1/views/list.php
DEBUG - 2023-04-19 13:21:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-19 13:21:07 --> Final output sent to browser
DEBUG - 2023-04-19 13:21:07 --> Total execution time: 0.0534
