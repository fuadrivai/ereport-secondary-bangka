<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-04-07 13:31:21 --> Config Class Initialized
INFO - 2024-04-07 13:31:21 --> Hooks Class Initialized
DEBUG - 2024-04-07 13:31:21 --> UTF-8 Support Enabled
INFO - 2024-04-07 13:31:21 --> Utf8 Class Initialized
INFO - 2024-04-07 13:31:21 --> URI Class Initialized
INFO - 2024-04-07 13:31:21 --> Router Class Initialized
INFO - 2024-04-07 13:31:21 --> Output Class Initialized
INFO - 2024-04-07 13:31:21 --> Security Class Initialized
DEBUG - 2024-04-07 13:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-07 13:31:21 --> Input Class Initialized
INFO - 2024-04-07 13:31:21 --> Language Class Initialized
INFO - 2024-04-07 13:31:21 --> Config Class Initialized
INFO - 2024-04-07 13:31:21 --> Hooks Class Initialized
DEBUG - 2024-04-07 13:31:21 --> UTF-8 Support Enabled
INFO - 2024-04-07 13:31:21 --> Utf8 Class Initialized
INFO - 2024-04-07 13:31:21 --> URI Class Initialized
INFO - 2024-04-07 13:31:21 --> Router Class Initialized
INFO - 2024-04-07 13:31:21 --> Output Class Initialized
INFO - 2024-04-07 13:31:21 --> Security Class Initialized
DEBUG - 2024-04-07 13:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-07 13:31:21 --> Input Class Initialized
INFO - 2024-04-07 13:31:21 --> Language Class Initialized
INFO - 2024-04-07 13:31:21 --> Language Class Initialized
INFO - 2024-04-07 13:31:21 --> Config Class Initialized
INFO - 2024-04-07 13:31:21 --> Loader Class Initialized
INFO - 2024-04-07 13:31:21 --> Language Class Initialized
INFO - 2024-04-07 13:31:21 --> Config Class Initialized
INFO - 2024-04-07 13:31:21 --> Loader Class Initialized
INFO - 2024-04-07 13:31:21 --> Helper loaded: url_helper
INFO - 2024-04-07 13:31:21 --> Helper loaded: url_helper
INFO - 2024-04-07 13:31:22 --> Helper loaded: file_helper
INFO - 2024-04-07 13:31:22 --> Helper loaded: file_helper
INFO - 2024-04-07 13:31:22 --> Helper loaded: form_helper
INFO - 2024-04-07 13:31:22 --> Helper loaded: form_helper
INFO - 2024-04-07 13:31:22 --> Helper loaded: my_helper
INFO - 2024-04-07 13:31:22 --> Helper loaded: my_helper
INFO - 2024-04-07 13:31:22 --> Database Driver Class Initialized
INFO - 2024-04-07 13:31:22 --> Database Driver Class Initialized
INFO - 2024-04-07 13:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-07 13:31:22 --> Controller Class Initialized
INFO - 2024-04-07 13:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-07 13:31:22 --> Controller Class Initialized
INFO - 2024-04-07 13:31:22 --> Helper loaded: cookie_helper
INFO - 2024-04-07 13:31:22 --> Final output sent to browser
DEBUG - 2024-04-07 13:31:22 --> Total execution time: 0.2984
INFO - 2024-04-07 13:31:22 --> Helper loaded: cookie_helper
INFO - 2024-04-07 13:31:22 --> Final output sent to browser
DEBUG - 2024-04-07 13:31:22 --> Total execution time: 0.4029
INFO - 2024-04-07 13:31:22 --> Config Class Initialized
INFO - 2024-04-07 13:31:22 --> Hooks Class Initialized
DEBUG - 2024-04-07 13:31:22 --> UTF-8 Support Enabled
INFO - 2024-04-07 13:31:22 --> Utf8 Class Initialized
INFO - 2024-04-07 13:31:22 --> URI Class Initialized
INFO - 2024-04-07 13:31:22 --> Router Class Initialized
INFO - 2024-04-07 13:31:22 --> Output Class Initialized
INFO - 2024-04-07 13:31:22 --> Security Class Initialized
DEBUG - 2024-04-07 13:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-07 13:31:22 --> Input Class Initialized
INFO - 2024-04-07 13:31:22 --> Language Class Initialized
INFO - 2024-04-07 13:31:22 --> Language Class Initialized
INFO - 2024-04-07 13:31:22 --> Config Class Initialized
INFO - 2024-04-07 13:31:22 --> Loader Class Initialized
INFO - 2024-04-07 13:31:22 --> Helper loaded: url_helper
INFO - 2024-04-07 13:31:22 --> Helper loaded: file_helper
INFO - 2024-04-07 13:31:22 --> Helper loaded: form_helper
INFO - 2024-04-07 13:31:22 --> Helper loaded: my_helper
INFO - 2024-04-07 13:31:22 --> Config Class Initialized
INFO - 2024-04-07 13:31:22 --> Hooks Class Initialized
DEBUG - 2024-04-07 13:31:22 --> UTF-8 Support Enabled
INFO - 2024-04-07 13:31:22 --> Utf8 Class Initialized
INFO - 2024-04-07 13:31:22 --> URI Class Initialized
INFO - 2024-04-07 13:31:22 --> Router Class Initialized
INFO - 2024-04-07 13:31:22 --> Output Class Initialized
INFO - 2024-04-07 13:31:22 --> Security Class Initialized
DEBUG - 2024-04-07 13:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-07 13:31:22 --> Input Class Initialized
INFO - 2024-04-07 13:31:22 --> Language Class Initialized
INFO - 2024-04-07 13:31:22 --> Language Class Initialized
INFO - 2024-04-07 13:31:22 --> Config Class Initialized
INFO - 2024-04-07 13:31:22 --> Loader Class Initialized
INFO - 2024-04-07 13:31:22 --> Helper loaded: url_helper
INFO - 2024-04-07 13:31:22 --> Database Driver Class Initialized
INFO - 2024-04-07 13:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-07 13:31:22 --> Controller Class Initialized
INFO - 2024-04-07 13:31:22 --> Helper loaded: file_helper
INFO - 2024-04-07 13:31:22 --> Helper loaded: form_helper
INFO - 2024-04-07 13:31:22 --> Helper loaded: my_helper
INFO - 2024-04-07 13:31:22 --> Database Driver Class Initialized
INFO - 2024-04-07 13:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-07 13:31:22 --> Controller Class Initialized
INFO - 2024-04-07 13:31:22 --> Helper loaded: cookie_helper
INFO - 2024-04-07 13:31:22 --> Final output sent to browser
DEBUG - 2024-04-07 13:31:22 --> Total execution time: 0.0775
INFO - 2024-04-07 13:31:22 --> Config Class Initialized
INFO - 2024-04-07 13:31:22 --> Hooks Class Initialized
DEBUG - 2024-04-07 13:31:22 --> UTF-8 Support Enabled
INFO - 2024-04-07 13:31:22 --> Utf8 Class Initialized
INFO - 2024-04-07 13:31:22 --> URI Class Initialized
INFO - 2024-04-07 13:31:22 --> Helper loaded: cookie_helper
INFO - 2024-04-07 13:31:22 --> Final output sent to browser
DEBUG - 2024-04-07 13:31:22 --> Total execution time: 0.0619
INFO - 2024-04-07 13:31:22 --> Router Class Initialized
INFO - 2024-04-07 13:31:22 --> Output Class Initialized
INFO - 2024-04-07 13:31:22 --> Security Class Initialized
DEBUG - 2024-04-07 13:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-07 13:31:22 --> Input Class Initialized
INFO - 2024-04-07 13:31:22 --> Language Class Initialized
INFO - 2024-04-07 13:31:22 --> Language Class Initialized
INFO - 2024-04-07 13:31:22 --> Config Class Initialized
INFO - 2024-04-07 13:31:22 --> Loader Class Initialized
INFO - 2024-04-07 13:31:22 --> Helper loaded: url_helper
INFO - 2024-04-07 13:31:22 --> Helper loaded: file_helper
INFO - 2024-04-07 13:31:22 --> Helper loaded: form_helper
INFO - 2024-04-07 13:31:22 --> Helper loaded: my_helper
INFO - 2024-04-07 13:31:22 --> Database Driver Class Initialized
INFO - 2024-04-07 13:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-07 13:31:22 --> Controller Class Initialized
INFO - 2024-04-07 13:31:22 --> Helper loaded: cookie_helper
INFO - 2024-04-07 13:31:22 --> Final output sent to browser
DEBUG - 2024-04-07 13:31:22 --> Total execution time: 0.0490
INFO - 2024-04-07 13:31:22 --> Config Class Initialized
INFO - 2024-04-07 13:31:22 --> Hooks Class Initialized
DEBUG - 2024-04-07 13:31:22 --> UTF-8 Support Enabled
INFO - 2024-04-07 13:31:22 --> Utf8 Class Initialized
INFO - 2024-04-07 13:31:22 --> Config Class Initialized
INFO - 2024-04-07 13:31:22 --> Hooks Class Initialized
DEBUG - 2024-04-07 13:31:22 --> UTF-8 Support Enabled
INFO - 2024-04-07 13:31:22 --> Utf8 Class Initialized
INFO - 2024-04-07 13:31:22 --> URI Class Initialized
INFO - 2024-04-07 13:31:22 --> Router Class Initialized
INFO - 2024-04-07 13:31:22 --> Output Class Initialized
INFO - 2024-04-07 13:31:22 --> Security Class Initialized
DEBUG - 2024-04-07 13:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-07 13:31:22 --> Input Class Initialized
INFO - 2024-04-07 13:31:22 --> Language Class Initialized
INFO - 2024-04-07 13:31:22 --> Config Class Initialized
INFO - 2024-04-07 13:31:22 --> Hooks Class Initialized
DEBUG - 2024-04-07 13:31:22 --> UTF-8 Support Enabled
INFO - 2024-04-07 13:31:22 --> Utf8 Class Initialized
INFO - 2024-04-07 13:31:22 --> URI Class Initialized
INFO - 2024-04-07 13:31:22 --> Config Class Initialized
INFO - 2024-04-07 13:31:22 --> Hooks Class Initialized
DEBUG - 2024-04-07 13:31:22 --> UTF-8 Support Enabled
INFO - 2024-04-07 13:31:22 --> Utf8 Class Initialized
INFO - 2024-04-07 13:31:22 --> URI Class Initialized
INFO - 2024-04-07 13:31:22 --> Router Class Initialized
INFO - 2024-04-07 13:31:22 --> Output Class Initialized
INFO - 2024-04-07 13:31:22 --> Security Class Initialized
DEBUG - 2024-04-07 13:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-07 13:31:22 --> Input Class Initialized
INFO - 2024-04-07 13:31:22 --> Language Class Initialized
INFO - 2024-04-07 13:31:22 --> Config Class Initialized
INFO - 2024-04-07 13:31:22 --> Hooks Class Initialized
DEBUG - 2024-04-07 13:31:22 --> UTF-8 Support Enabled
INFO - 2024-04-07 13:31:22 --> Utf8 Class Initialized
INFO - 2024-04-07 13:31:22 --> URI Class Initialized
INFO - 2024-04-07 13:31:22 --> Language Class Initialized
INFO - 2024-04-07 13:31:22 --> Config Class Initialized
INFO - 2024-04-07 13:31:22 --> Loader Class Initialized
INFO - 2024-04-07 13:31:22 --> URI Class Initialized
INFO - 2024-04-07 13:31:22 --> Router Class Initialized
INFO - 2024-04-07 13:31:22 --> Output Class Initialized
INFO - 2024-04-07 13:31:22 --> Security Class Initialized
DEBUG - 2024-04-07 13:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-07 13:31:22 --> Input Class Initialized
INFO - 2024-04-07 13:31:22 --> Language Class Initialized
INFO - 2024-04-07 13:31:22 --> Router Class Initialized
INFO - 2024-04-07 13:31:22 --> Output Class Initialized
INFO - 2024-04-07 13:31:22 --> Security Class Initialized
DEBUG - 2024-04-07 13:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-07 13:31:22 --> Input Class Initialized
INFO - 2024-04-07 13:31:22 --> Language Class Initialized
INFO - 2024-04-07 13:31:22 --> Router Class Initialized
INFO - 2024-04-07 13:31:22 --> Output Class Initialized
INFO - 2024-04-07 13:31:22 --> Security Class Initialized
DEBUG - 2024-04-07 13:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-07 13:31:22 --> Input Class Initialized
INFO - 2024-04-07 13:31:22 --> Language Class Initialized
INFO - 2024-04-07 13:31:22 --> Language Class Initialized
INFO - 2024-04-07 13:31:22 --> Config Class Initialized
INFO - 2024-04-07 13:31:22 --> Language Class Initialized
INFO - 2024-04-07 13:31:22 --> Config Class Initialized
INFO - 2024-04-07 13:31:22 --> Loader Class Initialized
INFO - 2024-04-07 13:31:22 --> Helper loaded: url_helper
INFO - 2024-04-07 13:31:22 --> Helper loaded: file_helper
INFO - 2024-04-07 13:31:22 --> Helper loaded: form_helper
INFO - 2024-04-07 13:31:22 --> Helper loaded: my_helper
INFO - 2024-04-07 13:31:23 --> Helper loaded: url_helper
INFO - 2024-04-07 13:31:23 --> Helper loaded: file_helper
INFO - 2024-04-07 13:31:23 --> Helper loaded: form_helper
INFO - 2024-04-07 13:31:23 --> Helper loaded: my_helper
INFO - 2024-04-07 13:31:23 --> Language Class Initialized
INFO - 2024-04-07 13:31:23 --> Config Class Initialized
INFO - 2024-04-07 13:31:23 --> Loader Class Initialized
INFO - 2024-04-07 13:31:23 --> Language Class Initialized
INFO - 2024-04-07 13:31:23 --> Config Class Initialized
INFO - 2024-04-07 13:31:23 --> Loader Class Initialized
INFO - 2024-04-07 13:31:23 --> Loader Class Initialized
INFO - 2024-04-07 13:31:23 --> Helper loaded: url_helper
INFO - 2024-04-07 13:31:23 --> Helper loaded: file_helper
INFO - 2024-04-07 13:31:23 --> Helper loaded: form_helper
INFO - 2024-04-07 13:31:23 --> Helper loaded: my_helper
INFO - 2024-04-07 13:31:23 --> Database Driver Class Initialized
INFO - 2024-04-07 13:31:23 --> Helper loaded: url_helper
INFO - 2024-04-07 13:31:23 --> Helper loaded: file_helper
INFO - 2024-04-07 13:31:23 --> Helper loaded: form_helper
INFO - 2024-04-07 13:31:23 --> Helper loaded: my_helper
INFO - 2024-04-07 13:31:23 --> Helper loaded: url_helper
INFO - 2024-04-07 13:31:23 --> Helper loaded: file_helper
INFO - 2024-04-07 13:31:23 --> Helper loaded: form_helper
INFO - 2024-04-07 13:31:23 --> Helper loaded: my_helper
INFO - 2024-04-07 13:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-07 13:31:23 --> Controller Class Initialized
INFO - 2024-04-07 13:31:23 --> Database Driver Class Initialized
INFO - 2024-04-07 13:31:23 --> Database Driver Class Initialized
INFO - 2024-04-07 13:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-07 13:31:23 --> Controller Class Initialized
INFO - 2024-04-07 13:31:23 --> Database Driver Class Initialized
INFO - 2024-04-07 13:31:23 --> Helper loaded: cookie_helper
INFO - 2024-04-07 13:31:23 --> Database Driver Class Initialized
INFO - 2024-04-07 13:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-07 13:31:23 --> Controller Class Initialized
INFO - 2024-04-07 13:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-07 13:31:23 --> Controller Class Initialized
INFO - 2024-04-07 13:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-07 13:31:23 --> Controller Class Initialized
INFO - 2024-04-07 13:31:23 --> Helper loaded: cookie_helper
INFO - 2024-04-07 13:31:23 --> Helper loaded: cookie_helper
INFO - 2024-04-07 13:31:23 --> Helper loaded: cookie_helper
INFO - 2024-04-07 13:31:23 --> Helper loaded: cookie_helper
INFO - 2024-04-07 13:31:23 --> Config Class Initialized
INFO - 2024-04-07 13:31:23 --> Hooks Class Initialized
DEBUG - 2024-04-07 13:31:23 --> UTF-8 Support Enabled
INFO - 2024-04-07 13:31:23 --> Utf8 Class Initialized
INFO - 2024-04-07 13:31:23 --> URI Class Initialized
INFO - 2024-04-07 13:31:23 --> Router Class Initialized
INFO - 2024-04-07 13:31:23 --> Output Class Initialized
INFO - 2024-04-07 13:31:23 --> Security Class Initialized
DEBUG - 2024-04-07 13:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-07 13:31:23 --> Input Class Initialized
INFO - 2024-04-07 13:31:23 --> Language Class Initialized
INFO - 2024-04-07 13:31:23 --> Language Class Initialized
INFO - 2024-04-07 13:31:23 --> Config Class Initialized
INFO - 2024-04-07 13:31:23 --> Loader Class Initialized
INFO - 2024-04-07 13:31:23 --> Helper loaded: url_helper
INFO - 2024-04-07 13:31:23 --> Helper loaded: file_helper
INFO - 2024-04-07 13:31:23 --> Helper loaded: form_helper
INFO - 2024-04-07 13:31:23 --> Helper loaded: my_helper
INFO - 2024-04-07 13:31:23 --> Database Driver Class Initialized
INFO - 2024-04-07 13:31:23 --> Config Class Initialized
INFO - 2024-04-07 13:31:23 --> Hooks Class Initialized
DEBUG - 2024-04-07 13:31:23 --> UTF-8 Support Enabled
INFO - 2024-04-07 13:31:23 --> Utf8 Class Initialized
INFO - 2024-04-07 13:31:23 --> URI Class Initialized
INFO - 2024-04-07 13:31:23 --> Router Class Initialized
INFO - 2024-04-07 13:31:23 --> Output Class Initialized
INFO - 2024-04-07 13:31:23 --> Security Class Initialized
INFO - 2024-04-07 13:31:23 --> Config Class Initialized
INFO - 2024-04-07 13:31:23 --> Hooks Class Initialized
DEBUG - 2024-04-07 13:31:23 --> UTF-8 Support Enabled
INFO - 2024-04-07 13:31:23 --> Utf8 Class Initialized
INFO - 2024-04-07 13:31:23 --> URI Class Initialized
INFO - 2024-04-07 13:31:23 --> Config Class Initialized
INFO - 2024-04-07 13:31:23 --> Hooks Class Initialized
DEBUG - 2024-04-07 13:31:23 --> UTF-8 Support Enabled
INFO - 2024-04-07 13:31:23 --> Utf8 Class Initialized
INFO - 2024-04-07 13:31:23 --> URI Class Initialized
INFO - 2024-04-07 13:31:23 --> Config Class Initialized
INFO - 2024-04-07 13:31:23 --> Hooks Class Initialized
DEBUG - 2024-04-07 13:31:23 --> UTF-8 Support Enabled
INFO - 2024-04-07 13:31:23 --> Utf8 Class Initialized
INFO - 2024-04-07 13:31:23 --> URI Class Initialized
INFO - 2024-04-07 13:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-07 13:31:23 --> Controller Class Initialized
INFO - 2024-04-07 13:31:23 --> Router Class Initialized
INFO - 2024-04-07 13:31:23 --> Output Class Initialized
INFO - 2024-04-07 13:31:23 --> Security Class Initialized
DEBUG - 2024-04-07 13:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-07 13:31:23 --> Input Class Initialized
INFO - 2024-04-07 13:31:23 --> Language Class Initialized
INFO - 2024-04-07 13:31:23 --> Router Class Initialized
INFO - 2024-04-07 13:31:23 --> Output Class Initialized
INFO - 2024-04-07 13:31:23 --> Security Class Initialized
DEBUG - 2024-04-07 13:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-07 13:31:23 --> Input Class Initialized
INFO - 2024-04-07 13:31:23 --> Language Class Initialized
INFO - 2024-04-07 13:31:23 --> Router Class Initialized
INFO - 2024-04-07 13:31:23 --> Output Class Initialized
INFO - 2024-04-07 13:31:23 --> Security Class Initialized
DEBUG - 2024-04-07 13:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-07 13:31:23 --> Input Class Initialized
INFO - 2024-04-07 13:31:23 --> Language Class Initialized
DEBUG - 2024-04-07 13:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-07 13:31:23 --> Input Class Initialized
INFO - 2024-04-07 13:31:23 --> Language Class Initialized
INFO - 2024-04-07 13:31:23 --> Language Class Initialized
INFO - 2024-04-07 13:31:23 --> Config Class Initialized
INFO - 2024-04-07 13:31:23 --> Loader Class Initialized
INFO - 2024-04-07 13:31:23 --> Helper loaded: url_helper
INFO - 2024-04-07 13:31:23 --> Helper loaded: file_helper
INFO - 2024-04-07 13:31:23 --> Language Class Initialized
INFO - 2024-04-07 13:31:23 --> Config Class Initialized
INFO - 2024-04-07 13:31:23 --> Loader Class Initialized
INFO - 2024-04-07 13:31:23 --> Language Class Initialized
INFO - 2024-04-07 13:31:23 --> Config Class Initialized
INFO - 2024-04-07 13:31:23 --> Loader Class Initialized
INFO - 2024-04-07 13:31:23 --> Language Class Initialized
INFO - 2024-04-07 13:31:23 --> Config Class Initialized
INFO - 2024-04-07 13:31:23 --> Loader Class Initialized
INFO - 2024-04-07 13:31:23 --> Helper loaded: url_helper
INFO - 2024-04-07 13:31:23 --> Helper loaded: file_helper
INFO - 2024-04-07 13:31:23 --> Helper loaded: form_helper
INFO - 2024-04-07 13:31:23 --> Helper loaded: my_helper
INFO - 2024-04-07 13:31:23 --> Helper loaded: form_helper
INFO - 2024-04-07 13:31:23 --> Helper loaded: my_helper
INFO - 2024-04-07 13:31:23 --> Helper loaded: url_helper
INFO - 2024-04-07 13:31:23 --> Helper loaded: file_helper
INFO - 2024-04-07 13:31:23 --> Helper loaded: form_helper
INFO - 2024-04-07 13:31:23 --> Helper loaded: my_helper
DEBUG - 2024-04-07 13:31:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-04-07 13:31:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-04-07 13:31:23 --> Final output sent to browser
DEBUG - 2024-04-07 13:31:23 --> Total execution time: 0.1897
INFO - 2024-04-07 13:31:23 --> Helper loaded: url_helper
INFO - 2024-04-07 13:31:23 --> Helper loaded: file_helper
INFO - 2024-04-07 13:31:23 --> Helper loaded: form_helper
INFO - 2024-04-07 13:31:23 --> Helper loaded: my_helper
INFO - 2024-04-07 13:31:23 --> Database Driver Class Initialized
INFO - 2024-04-07 13:31:23 --> Database Driver Class Initialized
INFO - 2024-04-07 13:31:23 --> Database Driver Class Initialized
INFO - 2024-04-07 13:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-07 13:31:23 --> Controller Class Initialized
INFO - 2024-04-07 13:31:23 --> Database Driver Class Initialized
DEBUG - 2024-04-07 13:31:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-04-07 13:31:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-04-07 13:31:23 --> Final output sent to browser
DEBUG - 2024-04-07 13:31:23 --> Total execution time: 0.1889
INFO - 2024-04-07 13:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-07 13:31:23 --> Controller Class Initialized
DEBUG - 2024-04-07 13:31:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-04-07 13:31:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-04-07 13:31:23 --> Final output sent to browser
DEBUG - 2024-04-07 13:31:23 --> Total execution time: 0.1841
INFO - 2024-04-07 13:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-07 13:31:23 --> Controller Class Initialized
DEBUG - 2024-04-07 13:31:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-04-07 13:31:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-04-07 13:31:23 --> Final output sent to browser
DEBUG - 2024-04-07 13:31:23 --> Total execution time: 0.1670
INFO - 2024-04-07 13:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-07 13:31:23 --> Controller Class Initialized
DEBUG - 2024-04-07 13:31:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-04-07 13:31:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-04-07 13:31:23 --> Final output sent to browser
DEBUG - 2024-04-07 13:31:23 --> Total execution time: 0.1859
INFO - 2024-04-07 13:39:15 --> Config Class Initialized
INFO - 2024-04-07 13:39:15 --> Hooks Class Initialized
DEBUG - 2024-04-07 13:39:15 --> UTF-8 Support Enabled
INFO - 2024-04-07 13:39:15 --> Utf8 Class Initialized
INFO - 2024-04-07 13:39:15 --> URI Class Initialized
INFO - 2024-04-07 13:39:15 --> Router Class Initialized
INFO - 2024-04-07 13:39:15 --> Output Class Initialized
INFO - 2024-04-07 13:39:15 --> Security Class Initialized
DEBUG - 2024-04-07 13:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-07 13:39:15 --> Input Class Initialized
INFO - 2024-04-07 13:39:15 --> Language Class Initialized
INFO - 2024-04-07 13:39:15 --> Language Class Initialized
INFO - 2024-04-07 13:39:15 --> Config Class Initialized
INFO - 2024-04-07 13:39:15 --> Loader Class Initialized
INFO - 2024-04-07 13:39:15 --> Helper loaded: url_helper
INFO - 2024-04-07 13:39:15 --> Helper loaded: file_helper
INFO - 2024-04-07 13:39:15 --> Helper loaded: form_helper
INFO - 2024-04-07 13:39:15 --> Helper loaded: my_helper
INFO - 2024-04-07 13:39:15 --> Database Driver Class Initialized
INFO - 2024-04-07 13:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-07 13:39:15 --> Controller Class Initialized
INFO - 2024-04-07 13:39:15 --> Helper loaded: cookie_helper
INFO - 2024-04-07 13:39:15 --> Final output sent to browser
DEBUG - 2024-04-07 13:39:15 --> Total execution time: 0.0380
INFO - 2024-04-07 13:39:15 --> Config Class Initialized
INFO - 2024-04-07 13:39:15 --> Hooks Class Initialized
DEBUG - 2024-04-07 13:39:15 --> UTF-8 Support Enabled
INFO - 2024-04-07 13:39:15 --> Utf8 Class Initialized
INFO - 2024-04-07 13:39:15 --> URI Class Initialized
INFO - 2024-04-07 13:39:15 --> Router Class Initialized
INFO - 2024-04-07 13:39:15 --> Output Class Initialized
INFO - 2024-04-07 13:39:15 --> Security Class Initialized
DEBUG - 2024-04-07 13:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-07 13:39:15 --> Input Class Initialized
INFO - 2024-04-07 13:39:15 --> Language Class Initialized
INFO - 2024-04-07 13:39:15 --> Language Class Initialized
INFO - 2024-04-07 13:39:15 --> Config Class Initialized
INFO - 2024-04-07 13:39:15 --> Loader Class Initialized
INFO - 2024-04-07 13:39:15 --> Helper loaded: url_helper
INFO - 2024-04-07 13:39:15 --> Helper loaded: file_helper
INFO - 2024-04-07 13:39:15 --> Helper loaded: form_helper
INFO - 2024-04-07 13:39:15 --> Helper loaded: my_helper
INFO - 2024-04-07 13:39:15 --> Database Driver Class Initialized
INFO - 2024-04-07 13:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-07 13:39:15 --> Controller Class Initialized
INFO - 2024-04-07 13:39:15 --> Helper loaded: cookie_helper
INFO - 2024-04-07 13:39:15 --> Config Class Initialized
INFO - 2024-04-07 13:39:15 --> Hooks Class Initialized
DEBUG - 2024-04-07 13:39:15 --> UTF-8 Support Enabled
INFO - 2024-04-07 13:39:15 --> Utf8 Class Initialized
INFO - 2024-04-07 13:39:15 --> URI Class Initialized
INFO - 2024-04-07 13:39:15 --> Router Class Initialized
INFO - 2024-04-07 13:39:15 --> Output Class Initialized
INFO - 2024-04-07 13:39:15 --> Security Class Initialized
DEBUG - 2024-04-07 13:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-07 13:39:15 --> Input Class Initialized
INFO - 2024-04-07 13:39:15 --> Language Class Initialized
INFO - 2024-04-07 13:39:15 --> Language Class Initialized
INFO - 2024-04-07 13:39:15 --> Config Class Initialized
INFO - 2024-04-07 13:39:15 --> Loader Class Initialized
INFO - 2024-04-07 13:39:15 --> Helper loaded: url_helper
INFO - 2024-04-07 13:39:15 --> Helper loaded: file_helper
INFO - 2024-04-07 13:39:15 --> Helper loaded: form_helper
INFO - 2024-04-07 13:39:15 --> Helper loaded: my_helper
INFO - 2024-04-07 13:39:15 --> Database Driver Class Initialized
INFO - 2024-04-07 13:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-07 13:39:15 --> Controller Class Initialized
DEBUG - 2024-04-07 13:39:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-04-07 13:39:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-04-07 13:39:15 --> Final output sent to browser
DEBUG - 2024-04-07 13:39:15 --> Total execution time: 0.0324
