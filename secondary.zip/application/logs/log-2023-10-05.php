<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-10-05 07:43:46 --> Config Class Initialized
INFO - 2023-10-05 07:43:46 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:43:46 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:43:46 --> Utf8 Class Initialized
INFO - 2023-10-05 07:43:46 --> URI Class Initialized
INFO - 2023-10-05 07:43:46 --> Router Class Initialized
INFO - 2023-10-05 07:43:46 --> Output Class Initialized
INFO - 2023-10-05 07:43:46 --> Security Class Initialized
DEBUG - 2023-10-05 07:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:43:46 --> Input Class Initialized
INFO - 2023-10-05 07:43:46 --> Language Class Initialized
INFO - 2023-10-05 07:43:46 --> Language Class Initialized
INFO - 2023-10-05 07:43:46 --> Config Class Initialized
INFO - 2023-10-05 07:43:46 --> Loader Class Initialized
INFO - 2023-10-05 07:43:46 --> Helper loaded: url_helper
INFO - 2023-10-05 07:43:46 --> Helper loaded: file_helper
INFO - 2023-10-05 07:43:46 --> Helper loaded: form_helper
INFO - 2023-10-05 07:43:46 --> Helper loaded: my_helper
INFO - 2023-10-05 07:43:46 --> Database Driver Class Initialized
INFO - 2023-10-05 07:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:43:47 --> Controller Class Initialized
ERROR - 2023-10-05 07:43:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2389
DEBUG - 2023-10-05 07:43:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2023-10-05 07:43:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 07:43:47 --> Final output sent to browser
DEBUG - 2023-10-05 07:43:47 --> Total execution time: 0.0991
INFO - 2023-10-05 07:44:30 --> Config Class Initialized
INFO - 2023-10-05 07:44:30 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:44:30 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:44:30 --> Utf8 Class Initialized
INFO - 2023-10-05 07:44:30 --> URI Class Initialized
INFO - 2023-10-05 07:44:30 --> Router Class Initialized
INFO - 2023-10-05 07:44:30 --> Output Class Initialized
INFO - 2023-10-05 07:44:30 --> Security Class Initialized
DEBUG - 2023-10-05 07:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:44:30 --> Input Class Initialized
INFO - 2023-10-05 07:44:30 --> Language Class Initialized
INFO - 2023-10-05 07:44:30 --> Language Class Initialized
INFO - 2023-10-05 07:44:30 --> Config Class Initialized
INFO - 2023-10-05 07:44:30 --> Loader Class Initialized
INFO - 2023-10-05 07:44:30 --> Helper loaded: url_helper
INFO - 2023-10-05 07:44:30 --> Helper loaded: file_helper
INFO - 2023-10-05 07:44:30 --> Helper loaded: form_helper
INFO - 2023-10-05 07:44:30 --> Helper loaded: my_helper
INFO - 2023-10-05 07:44:30 --> Database Driver Class Initialized
INFO - 2023-10-05 07:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:44:30 --> Controller Class Initialized
DEBUG - 2023-10-05 07:44:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-05 07:44:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 07:44:30 --> Final output sent to browser
DEBUG - 2023-10-05 07:44:30 --> Total execution time: 0.0340
INFO - 2023-10-05 07:48:26 --> Config Class Initialized
INFO - 2023-10-05 07:48:26 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:48:26 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:48:26 --> Utf8 Class Initialized
INFO - 2023-10-05 07:48:26 --> URI Class Initialized
INFO - 2023-10-05 07:48:26 --> Router Class Initialized
INFO - 2023-10-05 07:48:26 --> Output Class Initialized
INFO - 2023-10-05 07:48:26 --> Security Class Initialized
DEBUG - 2023-10-05 07:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:48:26 --> Input Class Initialized
INFO - 2023-10-05 07:48:26 --> Language Class Initialized
INFO - 2023-10-05 07:48:26 --> Language Class Initialized
INFO - 2023-10-05 07:48:26 --> Config Class Initialized
INFO - 2023-10-05 07:48:26 --> Loader Class Initialized
INFO - 2023-10-05 07:48:26 --> Helper loaded: url_helper
INFO - 2023-10-05 07:48:26 --> Helper loaded: file_helper
INFO - 2023-10-05 07:48:26 --> Helper loaded: form_helper
INFO - 2023-10-05 07:48:26 --> Helper loaded: my_helper
INFO - 2023-10-05 07:48:26 --> Database Driver Class Initialized
INFO - 2023-10-05 07:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:48:26 --> Controller Class Initialized
INFO - 2023-10-05 07:48:26 --> Helper loaded: cookie_helper
INFO - 2023-10-05 07:48:26 --> Final output sent to browser
DEBUG - 2023-10-05 07:48:26 --> Total execution time: 0.1953
INFO - 2023-10-05 07:48:26 --> Config Class Initialized
INFO - 2023-10-05 07:48:26 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:48:26 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:48:26 --> Utf8 Class Initialized
INFO - 2023-10-05 07:48:26 --> URI Class Initialized
INFO - 2023-10-05 07:48:26 --> Router Class Initialized
INFO - 2023-10-05 07:48:26 --> Output Class Initialized
INFO - 2023-10-05 07:48:26 --> Security Class Initialized
DEBUG - 2023-10-05 07:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:48:26 --> Input Class Initialized
INFO - 2023-10-05 07:48:26 --> Language Class Initialized
INFO - 2023-10-05 07:48:26 --> Language Class Initialized
INFO - 2023-10-05 07:48:26 --> Config Class Initialized
INFO - 2023-10-05 07:48:26 --> Loader Class Initialized
INFO - 2023-10-05 07:48:26 --> Helper loaded: url_helper
INFO - 2023-10-05 07:48:26 --> Helper loaded: file_helper
INFO - 2023-10-05 07:48:26 --> Helper loaded: form_helper
INFO - 2023-10-05 07:48:26 --> Helper loaded: my_helper
INFO - 2023-10-05 07:48:26 --> Database Driver Class Initialized
INFO - 2023-10-05 07:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:48:26 --> Controller Class Initialized
DEBUG - 2023-10-05 07:48:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-10-05 07:48:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 07:48:26 --> Final output sent to browser
DEBUG - 2023-10-05 07:48:26 --> Total execution time: 0.0345
INFO - 2023-10-05 07:48:32 --> Config Class Initialized
INFO - 2023-10-05 07:48:32 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:48:32 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:48:32 --> Utf8 Class Initialized
INFO - 2023-10-05 07:48:32 --> URI Class Initialized
INFO - 2023-10-05 07:48:32 --> Router Class Initialized
INFO - 2023-10-05 07:48:32 --> Output Class Initialized
INFO - 2023-10-05 07:48:32 --> Security Class Initialized
DEBUG - 2023-10-05 07:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:48:32 --> Input Class Initialized
INFO - 2023-10-05 07:48:32 --> Language Class Initialized
INFO - 2023-10-05 07:48:32 --> Language Class Initialized
INFO - 2023-10-05 07:48:32 --> Config Class Initialized
INFO - 2023-10-05 07:48:32 --> Loader Class Initialized
INFO - 2023-10-05 07:48:32 --> Helper loaded: url_helper
INFO - 2023-10-05 07:48:32 --> Helper loaded: file_helper
INFO - 2023-10-05 07:48:32 --> Helper loaded: form_helper
INFO - 2023-10-05 07:48:32 --> Helper loaded: my_helper
INFO - 2023-10-05 07:48:32 --> Database Driver Class Initialized
INFO - 2023-10-05 07:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:48:32 --> Controller Class Initialized
DEBUG - 2023-10-05 07:48:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2023-10-05 07:48:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 07:48:32 --> Final output sent to browser
DEBUG - 2023-10-05 07:48:32 --> Total execution time: 0.0615
INFO - 2023-10-05 07:48:42 --> Config Class Initialized
INFO - 2023-10-05 07:48:42 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:48:42 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:48:42 --> Utf8 Class Initialized
INFO - 2023-10-05 07:48:42 --> URI Class Initialized
INFO - 2023-10-05 07:48:42 --> Router Class Initialized
INFO - 2023-10-05 07:48:42 --> Output Class Initialized
INFO - 2023-10-05 07:48:42 --> Security Class Initialized
DEBUG - 2023-10-05 07:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:48:42 --> Input Class Initialized
INFO - 2023-10-05 07:48:42 --> Language Class Initialized
INFO - 2023-10-05 07:48:42 --> Language Class Initialized
INFO - 2023-10-05 07:48:42 --> Config Class Initialized
INFO - 2023-10-05 07:48:42 --> Loader Class Initialized
INFO - 2023-10-05 07:48:42 --> Helper loaded: url_helper
INFO - 2023-10-05 07:48:42 --> Helper loaded: file_helper
INFO - 2023-10-05 07:48:42 --> Helper loaded: form_helper
INFO - 2023-10-05 07:48:42 --> Helper loaded: my_helper
INFO - 2023-10-05 07:48:42 --> Database Driver Class Initialized
INFO - 2023-10-05 07:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:48:42 --> Controller Class Initialized
DEBUG - 2023-10-05 07:48:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 07:48:47 --> Config Class Initialized
INFO - 2023-10-05 07:48:47 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:48:47 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:48:47 --> Utf8 Class Initialized
INFO - 2023-10-05 07:48:47 --> URI Class Initialized
INFO - 2023-10-05 07:48:47 --> Router Class Initialized
INFO - 2023-10-05 07:48:47 --> Output Class Initialized
INFO - 2023-10-05 07:48:47 --> Security Class Initialized
DEBUG - 2023-10-05 07:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:48:47 --> Input Class Initialized
INFO - 2023-10-05 07:48:47 --> Language Class Initialized
INFO - 2023-10-05 07:48:47 --> Language Class Initialized
INFO - 2023-10-05 07:48:47 --> Config Class Initialized
INFO - 2023-10-05 07:48:47 --> Loader Class Initialized
INFO - 2023-10-05 07:48:47 --> Helper loaded: url_helper
INFO - 2023-10-05 07:48:47 --> Helper loaded: file_helper
INFO - 2023-10-05 07:48:47 --> Helper loaded: form_helper
INFO - 2023-10-05 07:48:47 --> Helper loaded: my_helper
INFO - 2023-10-05 07:48:47 --> Database Driver Class Initialized
INFO - 2023-10-05 07:48:47 --> Final output sent to browser
DEBUG - 2023-10-05 07:48:47 --> Total execution time: 4.7565
INFO - 2023-10-05 07:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:48:47 --> Controller Class Initialized
DEBUG - 2023-10-05 07:48:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 07:48:51 --> Final output sent to browser
DEBUG - 2023-10-05 07:48:51 --> Total execution time: 4.1647
INFO - 2023-10-05 07:48:51 --> Config Class Initialized
INFO - 2023-10-05 07:48:51 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:48:51 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:48:51 --> Utf8 Class Initialized
INFO - 2023-10-05 07:48:51 --> URI Class Initialized
INFO - 2023-10-05 07:48:51 --> Router Class Initialized
INFO - 2023-10-05 07:48:51 --> Output Class Initialized
INFO - 2023-10-05 07:48:51 --> Security Class Initialized
DEBUG - 2023-10-05 07:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:48:51 --> Input Class Initialized
INFO - 2023-10-05 07:48:51 --> Language Class Initialized
INFO - 2023-10-05 07:48:51 --> Language Class Initialized
INFO - 2023-10-05 07:48:51 --> Config Class Initialized
INFO - 2023-10-05 07:48:51 --> Loader Class Initialized
INFO - 2023-10-05 07:48:51 --> Helper loaded: url_helper
INFO - 2023-10-05 07:48:51 --> Helper loaded: file_helper
INFO - 2023-10-05 07:48:51 --> Helper loaded: form_helper
INFO - 2023-10-05 07:48:51 --> Helper loaded: my_helper
INFO - 2023-10-05 07:48:51 --> Database Driver Class Initialized
INFO - 2023-10-05 07:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:48:51 --> Controller Class Initialized
DEBUG - 2023-10-05 07:48:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 07:48:54 --> Final output sent to browser
DEBUG - 2023-10-05 07:48:54 --> Total execution time: 3.2890
INFO - 2023-10-05 07:48:54 --> Config Class Initialized
INFO - 2023-10-05 07:48:54 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:48:54 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:48:54 --> Utf8 Class Initialized
INFO - 2023-10-05 07:48:54 --> URI Class Initialized
INFO - 2023-10-05 07:48:55 --> Router Class Initialized
INFO - 2023-10-05 07:48:55 --> Output Class Initialized
INFO - 2023-10-05 07:48:55 --> Security Class Initialized
DEBUG - 2023-10-05 07:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:48:55 --> Input Class Initialized
INFO - 2023-10-05 07:48:55 --> Language Class Initialized
INFO - 2023-10-05 07:48:55 --> Language Class Initialized
INFO - 2023-10-05 07:48:55 --> Config Class Initialized
INFO - 2023-10-05 07:48:55 --> Loader Class Initialized
INFO - 2023-10-05 07:48:55 --> Helper loaded: url_helper
INFO - 2023-10-05 07:48:55 --> Helper loaded: file_helper
INFO - 2023-10-05 07:48:55 --> Helper loaded: form_helper
INFO - 2023-10-05 07:48:55 --> Helper loaded: my_helper
INFO - 2023-10-05 07:48:55 --> Database Driver Class Initialized
INFO - 2023-10-05 07:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:48:55 --> Controller Class Initialized
DEBUG - 2023-10-05 07:48:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 07:48:59 --> Final output sent to browser
DEBUG - 2023-10-05 07:48:59 --> Total execution time: 4.7683
INFO - 2023-10-05 07:49:01 --> Config Class Initialized
INFO - 2023-10-05 07:49:01 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:49:01 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:49:01 --> Utf8 Class Initialized
INFO - 2023-10-05 07:49:01 --> URI Class Initialized
INFO - 2023-10-05 07:49:01 --> Router Class Initialized
INFO - 2023-10-05 07:49:01 --> Output Class Initialized
INFO - 2023-10-05 07:49:01 --> Security Class Initialized
DEBUG - 2023-10-05 07:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:49:01 --> Input Class Initialized
INFO - 2023-10-05 07:49:01 --> Language Class Initialized
INFO - 2023-10-05 07:49:01 --> Language Class Initialized
INFO - 2023-10-05 07:49:01 --> Config Class Initialized
INFO - 2023-10-05 07:49:01 --> Loader Class Initialized
INFO - 2023-10-05 07:49:01 --> Helper loaded: url_helper
INFO - 2023-10-05 07:49:01 --> Helper loaded: file_helper
INFO - 2023-10-05 07:49:01 --> Helper loaded: form_helper
INFO - 2023-10-05 07:49:01 --> Helper loaded: my_helper
INFO - 2023-10-05 07:49:01 --> Database Driver Class Initialized
INFO - 2023-10-05 07:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:49:01 --> Controller Class Initialized
DEBUG - 2023-10-05 07:49:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 07:49:05 --> Config Class Initialized
INFO - 2023-10-05 07:49:05 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:49:05 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:49:05 --> Utf8 Class Initialized
INFO - 2023-10-05 07:49:05 --> URI Class Initialized
INFO - 2023-10-05 07:49:05 --> Router Class Initialized
INFO - 2023-10-05 07:49:05 --> Output Class Initialized
INFO - 2023-10-05 07:49:05 --> Security Class Initialized
DEBUG - 2023-10-05 07:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:49:05 --> Input Class Initialized
INFO - 2023-10-05 07:49:05 --> Language Class Initialized
INFO - 2023-10-05 07:49:05 --> Language Class Initialized
INFO - 2023-10-05 07:49:05 --> Config Class Initialized
INFO - 2023-10-05 07:49:05 --> Loader Class Initialized
INFO - 2023-10-05 07:49:05 --> Helper loaded: url_helper
INFO - 2023-10-05 07:49:05 --> Helper loaded: file_helper
INFO - 2023-10-05 07:49:05 --> Helper loaded: form_helper
INFO - 2023-10-05 07:49:05 --> Helper loaded: my_helper
INFO - 2023-10-05 07:49:05 --> Database Driver Class Initialized
INFO - 2023-10-05 07:49:07 --> Final output sent to browser
DEBUG - 2023-10-05 07:49:07 --> Total execution time: 5.9030
INFO - 2023-10-05 07:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:49:07 --> Controller Class Initialized
DEBUG - 2023-10-05 07:49:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 07:49:10 --> Config Class Initialized
INFO - 2023-10-05 07:49:10 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:49:10 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:49:10 --> Utf8 Class Initialized
INFO - 2023-10-05 07:49:10 --> URI Class Initialized
INFO - 2023-10-05 07:49:10 --> Router Class Initialized
INFO - 2023-10-05 07:49:10 --> Output Class Initialized
INFO - 2023-10-05 07:49:10 --> Security Class Initialized
DEBUG - 2023-10-05 07:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:49:10 --> Input Class Initialized
INFO - 2023-10-05 07:49:10 --> Language Class Initialized
INFO - 2023-10-05 07:49:10 --> Language Class Initialized
INFO - 2023-10-05 07:49:10 --> Config Class Initialized
INFO - 2023-10-05 07:49:10 --> Loader Class Initialized
INFO - 2023-10-05 07:49:10 --> Helper loaded: url_helper
INFO - 2023-10-05 07:49:10 --> Helper loaded: file_helper
INFO - 2023-10-05 07:49:10 --> Helper loaded: form_helper
INFO - 2023-10-05 07:49:10 --> Helper loaded: my_helper
INFO - 2023-10-05 07:49:10 --> Database Driver Class Initialized
INFO - 2023-10-05 07:49:11 --> Final output sent to browser
DEBUG - 2023-10-05 07:49:11 --> Total execution time: 6.1243
INFO - 2023-10-05 07:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:49:11 --> Controller Class Initialized
DEBUG - 2023-10-05 07:49:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 07:49:15 --> Final output sent to browser
DEBUG - 2023-10-05 07:49:15 --> Total execution time: 5.6195
INFO - 2023-10-05 07:53:32 --> Config Class Initialized
INFO - 2023-10-05 07:53:32 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:53:32 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:53:32 --> Utf8 Class Initialized
INFO - 2023-10-05 07:53:32 --> URI Class Initialized
INFO - 2023-10-05 07:53:32 --> Router Class Initialized
INFO - 2023-10-05 07:53:32 --> Output Class Initialized
INFO - 2023-10-05 07:53:32 --> Security Class Initialized
DEBUG - 2023-10-05 07:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:53:32 --> Input Class Initialized
INFO - 2023-10-05 07:53:32 --> Language Class Initialized
INFO - 2023-10-05 07:53:32 --> Language Class Initialized
INFO - 2023-10-05 07:53:32 --> Config Class Initialized
INFO - 2023-10-05 07:53:32 --> Loader Class Initialized
INFO - 2023-10-05 07:53:32 --> Helper loaded: url_helper
INFO - 2023-10-05 07:53:32 --> Helper loaded: file_helper
INFO - 2023-10-05 07:53:32 --> Helper loaded: form_helper
INFO - 2023-10-05 07:53:32 --> Helper loaded: my_helper
INFO - 2023-10-05 07:53:32 --> Database Driver Class Initialized
INFO - 2023-10-05 07:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:53:32 --> Controller Class Initialized
DEBUG - 2023-10-05 07:53:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-05 07:53:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 07:53:32 --> Final output sent to browser
DEBUG - 2023-10-05 07:53:32 --> Total execution time: 0.0405
INFO - 2023-10-05 07:53:33 --> Config Class Initialized
INFO - 2023-10-05 07:53:33 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:53:33 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:53:33 --> Utf8 Class Initialized
INFO - 2023-10-05 07:53:33 --> URI Class Initialized
INFO - 2023-10-05 07:53:33 --> Router Class Initialized
INFO - 2023-10-05 07:53:33 --> Output Class Initialized
INFO - 2023-10-05 07:53:33 --> Security Class Initialized
DEBUG - 2023-10-05 07:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:53:33 --> Input Class Initialized
INFO - 2023-10-05 07:53:33 --> Language Class Initialized
INFO - 2023-10-05 07:53:33 --> Language Class Initialized
INFO - 2023-10-05 07:53:33 --> Config Class Initialized
INFO - 2023-10-05 07:53:33 --> Loader Class Initialized
INFO - 2023-10-05 07:53:33 --> Helper loaded: url_helper
INFO - 2023-10-05 07:53:33 --> Helper loaded: file_helper
INFO - 2023-10-05 07:53:33 --> Helper loaded: form_helper
INFO - 2023-10-05 07:53:33 --> Helper loaded: my_helper
INFO - 2023-10-05 07:53:33 --> Database Driver Class Initialized
INFO - 2023-10-05 07:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:53:33 --> Controller Class Initialized
INFO - 2023-10-05 07:54:29 --> Config Class Initialized
INFO - 2023-10-05 07:54:29 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:54:29 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:54:29 --> Utf8 Class Initialized
INFO - 2023-10-05 07:54:29 --> URI Class Initialized
INFO - 2023-10-05 07:54:29 --> Router Class Initialized
INFO - 2023-10-05 07:54:29 --> Output Class Initialized
INFO - 2023-10-05 07:54:29 --> Security Class Initialized
DEBUG - 2023-10-05 07:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:54:29 --> Input Class Initialized
INFO - 2023-10-05 07:54:29 --> Language Class Initialized
INFO - 2023-10-05 07:54:29 --> Language Class Initialized
INFO - 2023-10-05 07:54:29 --> Config Class Initialized
INFO - 2023-10-05 07:54:29 --> Loader Class Initialized
INFO - 2023-10-05 07:54:29 --> Helper loaded: url_helper
INFO - 2023-10-05 07:54:29 --> Helper loaded: file_helper
INFO - 2023-10-05 07:54:29 --> Helper loaded: form_helper
INFO - 2023-10-05 07:54:29 --> Helper loaded: my_helper
INFO - 2023-10-05 07:54:29 --> Database Driver Class Initialized
INFO - 2023-10-05 07:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:54:29 --> Controller Class Initialized
DEBUG - 2023-10-05 07:54:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-05 07:54:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 07:54:29 --> Final output sent to browser
DEBUG - 2023-10-05 07:54:29 --> Total execution time: 0.0523
INFO - 2023-10-05 07:54:29 --> Config Class Initialized
INFO - 2023-10-05 07:54:29 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:54:29 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:54:29 --> Utf8 Class Initialized
INFO - 2023-10-05 07:54:29 --> URI Class Initialized
INFO - 2023-10-05 07:54:29 --> Router Class Initialized
INFO - 2023-10-05 07:54:29 --> Output Class Initialized
INFO - 2023-10-05 07:54:29 --> Security Class Initialized
DEBUG - 2023-10-05 07:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:54:29 --> Input Class Initialized
INFO - 2023-10-05 07:54:29 --> Language Class Initialized
INFO - 2023-10-05 07:54:29 --> Language Class Initialized
INFO - 2023-10-05 07:54:29 --> Config Class Initialized
INFO - 2023-10-05 07:54:29 --> Loader Class Initialized
INFO - 2023-10-05 07:54:29 --> Helper loaded: url_helper
INFO - 2023-10-05 07:54:29 --> Helper loaded: file_helper
INFO - 2023-10-05 07:54:29 --> Helper loaded: form_helper
INFO - 2023-10-05 07:54:29 --> Helper loaded: my_helper
INFO - 2023-10-05 07:54:29 --> Database Driver Class Initialized
INFO - 2023-10-05 07:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:54:29 --> Controller Class Initialized
DEBUG - 2023-10-05 07:54:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-05 07:54:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 07:54:29 --> Final output sent to browser
DEBUG - 2023-10-05 07:54:29 --> Total execution time: 0.0665
INFO - 2023-10-05 07:54:30 --> Config Class Initialized
INFO - 2023-10-05 07:54:30 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:54:30 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:54:30 --> Utf8 Class Initialized
INFO - 2023-10-05 07:54:30 --> URI Class Initialized
INFO - 2023-10-05 07:54:30 --> Router Class Initialized
INFO - 2023-10-05 07:54:30 --> Output Class Initialized
INFO - 2023-10-05 07:54:30 --> Security Class Initialized
DEBUG - 2023-10-05 07:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:54:30 --> Input Class Initialized
INFO - 2023-10-05 07:54:30 --> Language Class Initialized
INFO - 2023-10-05 07:54:30 --> Language Class Initialized
INFO - 2023-10-05 07:54:30 --> Config Class Initialized
INFO - 2023-10-05 07:54:30 --> Loader Class Initialized
INFO - 2023-10-05 07:54:30 --> Helper loaded: url_helper
INFO - 2023-10-05 07:54:30 --> Helper loaded: file_helper
INFO - 2023-10-05 07:54:30 --> Helper loaded: form_helper
INFO - 2023-10-05 07:54:30 --> Helper loaded: my_helper
INFO - 2023-10-05 07:54:30 --> Database Driver Class Initialized
INFO - 2023-10-05 07:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:54:30 --> Controller Class Initialized
INFO - 2023-10-05 07:54:32 --> Config Class Initialized
INFO - 2023-10-05 07:54:32 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:54:32 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:54:32 --> Utf8 Class Initialized
INFO - 2023-10-05 07:54:32 --> URI Class Initialized
INFO - 2023-10-05 07:54:32 --> Router Class Initialized
INFO - 2023-10-05 07:54:32 --> Output Class Initialized
INFO - 2023-10-05 07:54:32 --> Security Class Initialized
DEBUG - 2023-10-05 07:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:54:32 --> Input Class Initialized
INFO - 2023-10-05 07:54:32 --> Language Class Initialized
INFO - 2023-10-05 07:54:32 --> Language Class Initialized
INFO - 2023-10-05 07:54:32 --> Config Class Initialized
INFO - 2023-10-05 07:54:32 --> Loader Class Initialized
INFO - 2023-10-05 07:54:32 --> Helper loaded: url_helper
INFO - 2023-10-05 07:54:32 --> Helper loaded: file_helper
INFO - 2023-10-05 07:54:32 --> Helper loaded: form_helper
INFO - 2023-10-05 07:54:32 --> Helper loaded: my_helper
INFO - 2023-10-05 07:54:32 --> Database Driver Class Initialized
INFO - 2023-10-05 07:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:54:32 --> Controller Class Initialized
DEBUG - 2023-10-05 07:54:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-05 07:54:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 07:54:32 --> Final output sent to browser
DEBUG - 2023-10-05 07:54:32 --> Total execution time: 0.0368
INFO - 2023-10-05 07:54:32 --> Config Class Initialized
INFO - 2023-10-05 07:54:32 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:54:32 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:54:32 --> Utf8 Class Initialized
INFO - 2023-10-05 07:54:32 --> URI Class Initialized
INFO - 2023-10-05 07:54:32 --> Router Class Initialized
INFO - 2023-10-05 07:54:32 --> Output Class Initialized
INFO - 2023-10-05 07:54:32 --> Security Class Initialized
DEBUG - 2023-10-05 07:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:54:32 --> Input Class Initialized
INFO - 2023-10-05 07:54:32 --> Language Class Initialized
INFO - 2023-10-05 07:54:32 --> Language Class Initialized
INFO - 2023-10-05 07:54:32 --> Config Class Initialized
INFO - 2023-10-05 07:54:32 --> Loader Class Initialized
INFO - 2023-10-05 07:54:32 --> Helper loaded: url_helper
INFO - 2023-10-05 07:54:32 --> Helper loaded: file_helper
INFO - 2023-10-05 07:54:32 --> Helper loaded: form_helper
INFO - 2023-10-05 07:54:32 --> Helper loaded: my_helper
INFO - 2023-10-05 07:54:32 --> Database Driver Class Initialized
INFO - 2023-10-05 07:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:54:32 --> Controller Class Initialized
INFO - 2023-10-05 07:55:15 --> Config Class Initialized
INFO - 2023-10-05 07:55:15 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:55:15 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:55:15 --> Utf8 Class Initialized
INFO - 2023-10-05 07:55:15 --> URI Class Initialized
INFO - 2023-10-05 07:55:15 --> Router Class Initialized
INFO - 2023-10-05 07:55:15 --> Output Class Initialized
INFO - 2023-10-05 07:55:15 --> Security Class Initialized
DEBUG - 2023-10-05 07:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:55:15 --> Input Class Initialized
INFO - 2023-10-05 07:55:15 --> Language Class Initialized
INFO - 2023-10-05 07:55:15 --> Language Class Initialized
INFO - 2023-10-05 07:55:15 --> Config Class Initialized
INFO - 2023-10-05 07:55:15 --> Loader Class Initialized
INFO - 2023-10-05 07:55:15 --> Helper loaded: url_helper
INFO - 2023-10-05 07:55:15 --> Helper loaded: file_helper
INFO - 2023-10-05 07:55:15 --> Helper loaded: form_helper
INFO - 2023-10-05 07:55:15 --> Helper loaded: my_helper
INFO - 2023-10-05 07:55:15 --> Database Driver Class Initialized
INFO - 2023-10-05 07:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:55:15 --> Controller Class Initialized
INFO - 2023-10-05 07:55:15 --> Helper loaded: cookie_helper
INFO - 2023-10-05 07:55:15 --> Final output sent to browser
DEBUG - 2023-10-05 07:55:15 --> Total execution time: 0.0654
INFO - 2023-10-05 07:55:15 --> Config Class Initialized
INFO - 2023-10-05 07:55:15 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:55:15 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:55:15 --> Utf8 Class Initialized
INFO - 2023-10-05 07:55:15 --> URI Class Initialized
INFO - 2023-10-05 07:55:15 --> Router Class Initialized
INFO - 2023-10-05 07:55:15 --> Output Class Initialized
INFO - 2023-10-05 07:55:15 --> Security Class Initialized
DEBUG - 2023-10-05 07:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:55:15 --> Input Class Initialized
INFO - 2023-10-05 07:55:15 --> Language Class Initialized
INFO - 2023-10-05 07:55:15 --> Language Class Initialized
INFO - 2023-10-05 07:55:15 --> Config Class Initialized
INFO - 2023-10-05 07:55:15 --> Loader Class Initialized
INFO - 2023-10-05 07:55:15 --> Helper loaded: url_helper
INFO - 2023-10-05 07:55:15 --> Helper loaded: file_helper
INFO - 2023-10-05 07:55:15 --> Helper loaded: form_helper
INFO - 2023-10-05 07:55:15 --> Helper loaded: my_helper
INFO - 2023-10-05 07:55:15 --> Database Driver Class Initialized
INFO - 2023-10-05 07:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:55:15 --> Controller Class Initialized
DEBUG - 2023-10-05 07:55:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-10-05 07:55:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 07:55:15 --> Final output sent to browser
DEBUG - 2023-10-05 07:55:15 --> Total execution time: 0.0445
INFO - 2023-10-05 07:55:49 --> Config Class Initialized
INFO - 2023-10-05 07:55:49 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:55:49 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:55:49 --> Utf8 Class Initialized
INFO - 2023-10-05 07:55:49 --> URI Class Initialized
INFO - 2023-10-05 07:55:49 --> Router Class Initialized
INFO - 2023-10-05 07:55:49 --> Output Class Initialized
INFO - 2023-10-05 07:55:49 --> Security Class Initialized
DEBUG - 2023-10-05 07:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:55:49 --> Input Class Initialized
INFO - 2023-10-05 07:55:49 --> Language Class Initialized
INFO - 2023-10-05 07:55:49 --> Language Class Initialized
INFO - 2023-10-05 07:55:49 --> Config Class Initialized
INFO - 2023-10-05 07:55:49 --> Loader Class Initialized
INFO - 2023-10-05 07:55:49 --> Helper loaded: url_helper
INFO - 2023-10-05 07:55:49 --> Helper loaded: file_helper
INFO - 2023-10-05 07:55:49 --> Helper loaded: form_helper
INFO - 2023-10-05 07:55:49 --> Helper loaded: my_helper
INFO - 2023-10-05 07:55:49 --> Database Driver Class Initialized
INFO - 2023-10-05 07:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:55:49 --> Controller Class Initialized
INFO - 2023-10-05 07:55:49 --> Helper loaded: cookie_helper
INFO - 2023-10-05 07:55:49 --> Config Class Initialized
INFO - 2023-10-05 07:55:49 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:55:49 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:55:49 --> Utf8 Class Initialized
INFO - 2023-10-05 07:55:49 --> URI Class Initialized
INFO - 2023-10-05 07:55:49 --> Router Class Initialized
INFO - 2023-10-05 07:55:49 --> Output Class Initialized
INFO - 2023-10-05 07:55:49 --> Security Class Initialized
DEBUG - 2023-10-05 07:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:55:49 --> Input Class Initialized
INFO - 2023-10-05 07:55:49 --> Language Class Initialized
INFO - 2023-10-05 07:55:49 --> Language Class Initialized
INFO - 2023-10-05 07:55:49 --> Config Class Initialized
INFO - 2023-10-05 07:55:49 --> Loader Class Initialized
INFO - 2023-10-05 07:55:49 --> Helper loaded: url_helper
INFO - 2023-10-05 07:55:49 --> Helper loaded: file_helper
INFO - 2023-10-05 07:55:49 --> Helper loaded: form_helper
INFO - 2023-10-05 07:55:49 --> Helper loaded: my_helper
INFO - 2023-10-05 07:55:49 --> Database Driver Class Initialized
INFO - 2023-10-05 07:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:55:49 --> Controller Class Initialized
INFO - 2023-10-05 07:55:49 --> Config Class Initialized
INFO - 2023-10-05 07:55:49 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:55:49 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:55:49 --> Utf8 Class Initialized
INFO - 2023-10-05 07:55:49 --> URI Class Initialized
INFO - 2023-10-05 07:55:49 --> Router Class Initialized
INFO - 2023-10-05 07:55:49 --> Output Class Initialized
INFO - 2023-10-05 07:55:49 --> Security Class Initialized
DEBUG - 2023-10-05 07:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:55:49 --> Input Class Initialized
INFO - 2023-10-05 07:55:49 --> Language Class Initialized
INFO - 2023-10-05 07:55:49 --> Language Class Initialized
INFO - 2023-10-05 07:55:49 --> Config Class Initialized
INFO - 2023-10-05 07:55:49 --> Loader Class Initialized
INFO - 2023-10-05 07:55:49 --> Helper loaded: url_helper
INFO - 2023-10-05 07:55:49 --> Helper loaded: file_helper
INFO - 2023-10-05 07:55:49 --> Helper loaded: form_helper
INFO - 2023-10-05 07:55:49 --> Helper loaded: my_helper
INFO - 2023-10-05 07:55:49 --> Database Driver Class Initialized
INFO - 2023-10-05 07:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:55:49 --> Controller Class Initialized
DEBUG - 2023-10-05 07:55:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-05 07:55:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 07:55:49 --> Final output sent to browser
DEBUG - 2023-10-05 07:55:49 --> Total execution time: 0.0345
INFO - 2023-10-05 07:56:52 --> Config Class Initialized
INFO - 2023-10-05 07:56:52 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:56:52 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:56:52 --> Utf8 Class Initialized
INFO - 2023-10-05 07:56:52 --> URI Class Initialized
INFO - 2023-10-05 07:56:52 --> Router Class Initialized
INFO - 2023-10-05 07:56:52 --> Output Class Initialized
INFO - 2023-10-05 07:56:52 --> Security Class Initialized
DEBUG - 2023-10-05 07:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:56:52 --> Input Class Initialized
INFO - 2023-10-05 07:56:52 --> Language Class Initialized
INFO - 2023-10-05 07:56:52 --> Language Class Initialized
INFO - 2023-10-05 07:56:52 --> Config Class Initialized
INFO - 2023-10-05 07:56:52 --> Loader Class Initialized
INFO - 2023-10-05 07:56:52 --> Helper loaded: url_helper
INFO - 2023-10-05 07:56:52 --> Helper loaded: file_helper
INFO - 2023-10-05 07:56:52 --> Helper loaded: form_helper
INFO - 2023-10-05 07:56:52 --> Helper loaded: my_helper
INFO - 2023-10-05 07:56:52 --> Database Driver Class Initialized
INFO - 2023-10-05 07:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:56:52 --> Controller Class Initialized
INFO - 2023-10-05 07:56:52 --> Config Class Initialized
INFO - 2023-10-05 07:56:52 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:56:52 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:56:52 --> Utf8 Class Initialized
INFO - 2023-10-05 07:56:52 --> URI Class Initialized
INFO - 2023-10-05 07:56:52 --> Router Class Initialized
INFO - 2023-10-05 07:56:52 --> Output Class Initialized
INFO - 2023-10-05 07:56:52 --> Security Class Initialized
DEBUG - 2023-10-05 07:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:56:52 --> Input Class Initialized
INFO - 2023-10-05 07:56:52 --> Language Class Initialized
INFO - 2023-10-05 07:56:52 --> Language Class Initialized
INFO - 2023-10-05 07:56:52 --> Config Class Initialized
INFO - 2023-10-05 07:56:52 --> Loader Class Initialized
INFO - 2023-10-05 07:56:52 --> Helper loaded: url_helper
INFO - 2023-10-05 07:56:52 --> Helper loaded: file_helper
INFO - 2023-10-05 07:56:52 --> Helper loaded: form_helper
INFO - 2023-10-05 07:56:52 --> Helper loaded: my_helper
INFO - 2023-10-05 07:56:52 --> Database Driver Class Initialized
INFO - 2023-10-05 07:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:56:52 --> Controller Class Initialized
DEBUG - 2023-10-05 07:56:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-05 07:56:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 07:56:52 --> Final output sent to browser
DEBUG - 2023-10-05 07:56:52 --> Total execution time: 0.0351
INFO - 2023-10-05 07:56:57 --> Config Class Initialized
INFO - 2023-10-05 07:56:57 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:56:57 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:56:57 --> Utf8 Class Initialized
INFO - 2023-10-05 07:56:57 --> URI Class Initialized
INFO - 2023-10-05 07:56:57 --> Router Class Initialized
INFO - 2023-10-05 07:56:57 --> Output Class Initialized
INFO - 2023-10-05 07:56:57 --> Security Class Initialized
DEBUG - 2023-10-05 07:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:56:57 --> Input Class Initialized
INFO - 2023-10-05 07:56:57 --> Language Class Initialized
INFO - 2023-10-05 07:56:57 --> Language Class Initialized
INFO - 2023-10-05 07:56:57 --> Config Class Initialized
INFO - 2023-10-05 07:56:57 --> Loader Class Initialized
INFO - 2023-10-05 07:56:57 --> Helper loaded: url_helper
INFO - 2023-10-05 07:56:57 --> Helper loaded: file_helper
INFO - 2023-10-05 07:56:57 --> Helper loaded: form_helper
INFO - 2023-10-05 07:56:57 --> Helper loaded: my_helper
INFO - 2023-10-05 07:56:57 --> Database Driver Class Initialized
INFO - 2023-10-05 07:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:56:57 --> Controller Class Initialized
INFO - 2023-10-05 07:56:57 --> Helper loaded: cookie_helper
INFO - 2023-10-05 07:56:57 --> Final output sent to browser
DEBUG - 2023-10-05 07:56:57 --> Total execution time: 0.0690
INFO - 2023-10-05 07:56:58 --> Config Class Initialized
INFO - 2023-10-05 07:56:58 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:56:58 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:56:58 --> Utf8 Class Initialized
INFO - 2023-10-05 07:56:58 --> URI Class Initialized
INFO - 2023-10-05 07:56:58 --> Router Class Initialized
INFO - 2023-10-05 07:56:58 --> Output Class Initialized
INFO - 2023-10-05 07:56:58 --> Security Class Initialized
DEBUG - 2023-10-05 07:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:56:58 --> Input Class Initialized
INFO - 2023-10-05 07:56:58 --> Language Class Initialized
INFO - 2023-10-05 07:56:58 --> Language Class Initialized
INFO - 2023-10-05 07:56:58 --> Config Class Initialized
INFO - 2023-10-05 07:56:58 --> Loader Class Initialized
INFO - 2023-10-05 07:56:58 --> Helper loaded: url_helper
INFO - 2023-10-05 07:56:58 --> Helper loaded: file_helper
INFO - 2023-10-05 07:56:58 --> Helper loaded: form_helper
INFO - 2023-10-05 07:56:58 --> Helper loaded: my_helper
INFO - 2023-10-05 07:56:58 --> Database Driver Class Initialized
INFO - 2023-10-05 07:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:56:58 --> Controller Class Initialized
DEBUG - 2023-10-05 07:56:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-10-05 07:56:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 07:56:58 --> Final output sent to browser
DEBUG - 2023-10-05 07:56:58 --> Total execution time: 0.1317
INFO - 2023-10-05 07:56:59 --> Config Class Initialized
INFO - 2023-10-05 07:56:59 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:56:59 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:56:59 --> Utf8 Class Initialized
INFO - 2023-10-05 07:56:59 --> URI Class Initialized
INFO - 2023-10-05 07:56:59 --> Router Class Initialized
INFO - 2023-10-05 07:56:59 --> Output Class Initialized
INFO - 2023-10-05 07:56:59 --> Security Class Initialized
DEBUG - 2023-10-05 07:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:56:59 --> Input Class Initialized
INFO - 2023-10-05 07:56:59 --> Language Class Initialized
INFO - 2023-10-05 07:56:59 --> Language Class Initialized
INFO - 2023-10-05 07:56:59 --> Config Class Initialized
INFO - 2023-10-05 07:56:59 --> Loader Class Initialized
INFO - 2023-10-05 07:56:59 --> Helper loaded: url_helper
INFO - 2023-10-05 07:56:59 --> Helper loaded: file_helper
INFO - 2023-10-05 07:56:59 --> Helper loaded: form_helper
INFO - 2023-10-05 07:56:59 --> Helper loaded: my_helper
INFO - 2023-10-05 07:56:59 --> Database Driver Class Initialized
INFO - 2023-10-05 07:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:56:59 --> Controller Class Initialized
DEBUG - 2023-10-05 07:56:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-10-05 07:56:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 07:56:59 --> Final output sent to browser
DEBUG - 2023-10-05 07:56:59 --> Total execution time: 0.0421
INFO - 2023-10-05 07:57:01 --> Config Class Initialized
INFO - 2023-10-05 07:57:01 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:57:01 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:57:01 --> Utf8 Class Initialized
INFO - 2023-10-05 07:57:01 --> URI Class Initialized
INFO - 2023-10-05 07:57:01 --> Router Class Initialized
INFO - 2023-10-05 07:57:01 --> Output Class Initialized
INFO - 2023-10-05 07:57:01 --> Security Class Initialized
DEBUG - 2023-10-05 07:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:57:01 --> Input Class Initialized
INFO - 2023-10-05 07:57:01 --> Language Class Initialized
INFO - 2023-10-05 07:57:01 --> Language Class Initialized
INFO - 2023-10-05 07:57:01 --> Config Class Initialized
INFO - 2023-10-05 07:57:01 --> Loader Class Initialized
INFO - 2023-10-05 07:57:01 --> Helper loaded: url_helper
INFO - 2023-10-05 07:57:01 --> Helper loaded: file_helper
INFO - 2023-10-05 07:57:01 --> Helper loaded: form_helper
INFO - 2023-10-05 07:57:01 --> Helper loaded: my_helper
INFO - 2023-10-05 07:57:01 --> Database Driver Class Initialized
INFO - 2023-10-05 07:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:57:01 --> Controller Class Initialized
INFO - 2023-10-05 07:57:01 --> Final output sent to browser
DEBUG - 2023-10-05 07:57:01 --> Total execution time: 0.0650
INFO - 2023-10-05 07:57:02 --> Config Class Initialized
INFO - 2023-10-05 07:57:02 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:57:02 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:57:02 --> Utf8 Class Initialized
INFO - 2023-10-05 07:57:02 --> URI Class Initialized
INFO - 2023-10-05 07:57:02 --> Router Class Initialized
INFO - 2023-10-05 07:57:02 --> Output Class Initialized
INFO - 2023-10-05 07:57:02 --> Security Class Initialized
DEBUG - 2023-10-05 07:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:57:02 --> Input Class Initialized
INFO - 2023-10-05 07:57:02 --> Language Class Initialized
INFO - 2023-10-05 07:57:02 --> Language Class Initialized
INFO - 2023-10-05 07:57:02 --> Config Class Initialized
INFO - 2023-10-05 07:57:02 --> Loader Class Initialized
INFO - 2023-10-05 07:57:02 --> Helper loaded: url_helper
INFO - 2023-10-05 07:57:02 --> Helper loaded: file_helper
INFO - 2023-10-05 07:57:02 --> Helper loaded: form_helper
INFO - 2023-10-05 07:57:02 --> Helper loaded: my_helper
INFO - 2023-10-05 07:57:02 --> Database Driver Class Initialized
INFO - 2023-10-05 07:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:57:02 --> Controller Class Initialized
DEBUG - 2023-10-05 07:57:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-10-05 07:57:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 07:57:02 --> Final output sent to browser
DEBUG - 2023-10-05 07:57:02 --> Total execution time: 0.2164
INFO - 2023-10-05 07:57:07 --> Config Class Initialized
INFO - 2023-10-05 07:57:07 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:57:07 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:57:07 --> Utf8 Class Initialized
INFO - 2023-10-05 07:57:07 --> URI Class Initialized
INFO - 2023-10-05 07:57:07 --> Router Class Initialized
INFO - 2023-10-05 07:57:07 --> Output Class Initialized
INFO - 2023-10-05 07:57:07 --> Security Class Initialized
DEBUG - 2023-10-05 07:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:57:07 --> Input Class Initialized
INFO - 2023-10-05 07:57:07 --> Language Class Initialized
INFO - 2023-10-05 07:57:07 --> Language Class Initialized
INFO - 2023-10-05 07:57:07 --> Config Class Initialized
INFO - 2023-10-05 07:57:07 --> Loader Class Initialized
INFO - 2023-10-05 07:57:07 --> Helper loaded: url_helper
INFO - 2023-10-05 07:57:07 --> Helper loaded: file_helper
INFO - 2023-10-05 07:57:07 --> Helper loaded: form_helper
INFO - 2023-10-05 07:57:07 --> Helper loaded: my_helper
INFO - 2023-10-05 07:57:07 --> Database Driver Class Initialized
INFO - 2023-10-05 07:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:57:07 --> Controller Class Initialized
INFO - 2023-10-05 07:57:07 --> Final output sent to browser
DEBUG - 2023-10-05 07:57:07 --> Total execution time: 0.0376
INFO - 2023-10-05 07:57:12 --> Config Class Initialized
INFO - 2023-10-05 07:57:12 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:57:12 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:57:12 --> Utf8 Class Initialized
INFO - 2023-10-05 07:57:12 --> URI Class Initialized
INFO - 2023-10-05 07:57:12 --> Router Class Initialized
INFO - 2023-10-05 07:57:12 --> Output Class Initialized
INFO - 2023-10-05 07:57:12 --> Security Class Initialized
DEBUG - 2023-10-05 07:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:57:12 --> Input Class Initialized
INFO - 2023-10-05 07:57:12 --> Language Class Initialized
INFO - 2023-10-05 07:57:12 --> Language Class Initialized
INFO - 2023-10-05 07:57:12 --> Config Class Initialized
INFO - 2023-10-05 07:57:12 --> Loader Class Initialized
INFO - 2023-10-05 07:57:12 --> Helper loaded: url_helper
INFO - 2023-10-05 07:57:12 --> Helper loaded: file_helper
INFO - 2023-10-05 07:57:12 --> Helper loaded: form_helper
INFO - 2023-10-05 07:57:12 --> Helper loaded: my_helper
INFO - 2023-10-05 07:57:12 --> Database Driver Class Initialized
INFO - 2023-10-05 07:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:57:12 --> Controller Class Initialized
INFO - 2023-10-05 07:57:12 --> Helper loaded: cookie_helper
INFO - 2023-10-05 07:57:12 --> Final output sent to browser
DEBUG - 2023-10-05 07:57:12 --> Total execution time: 0.1380
INFO - 2023-10-05 07:57:12 --> Config Class Initialized
INFO - 2023-10-05 07:57:12 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:57:12 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:57:12 --> Utf8 Class Initialized
INFO - 2023-10-05 07:57:12 --> URI Class Initialized
INFO - 2023-10-05 07:57:12 --> Router Class Initialized
INFO - 2023-10-05 07:57:12 --> Output Class Initialized
INFO - 2023-10-05 07:57:12 --> Security Class Initialized
DEBUG - 2023-10-05 07:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:57:12 --> Input Class Initialized
INFO - 2023-10-05 07:57:12 --> Language Class Initialized
INFO - 2023-10-05 07:57:12 --> Language Class Initialized
INFO - 2023-10-05 07:57:12 --> Config Class Initialized
INFO - 2023-10-05 07:57:12 --> Loader Class Initialized
INFO - 2023-10-05 07:57:12 --> Helper loaded: url_helper
INFO - 2023-10-05 07:57:12 --> Helper loaded: file_helper
INFO - 2023-10-05 07:57:12 --> Helper loaded: form_helper
INFO - 2023-10-05 07:57:12 --> Helper loaded: my_helper
INFO - 2023-10-05 07:57:12 --> Database Driver Class Initialized
INFO - 2023-10-05 07:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:57:12 --> Controller Class Initialized
DEBUG - 2023-10-05 07:57:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-10-05 07:57:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 07:57:12 --> Final output sent to browser
DEBUG - 2023-10-05 07:57:12 --> Total execution time: 0.0471
INFO - 2023-10-05 07:57:16 --> Config Class Initialized
INFO - 2023-10-05 07:57:16 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:57:16 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:57:16 --> Utf8 Class Initialized
INFO - 2023-10-05 07:57:16 --> URI Class Initialized
INFO - 2023-10-05 07:57:16 --> Router Class Initialized
INFO - 2023-10-05 07:57:16 --> Output Class Initialized
INFO - 2023-10-05 07:57:16 --> Security Class Initialized
DEBUG - 2023-10-05 07:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:57:16 --> Input Class Initialized
INFO - 2023-10-05 07:57:16 --> Language Class Initialized
INFO - 2023-10-05 07:57:16 --> Language Class Initialized
INFO - 2023-10-05 07:57:16 --> Config Class Initialized
INFO - 2023-10-05 07:57:16 --> Loader Class Initialized
INFO - 2023-10-05 07:57:16 --> Helper loaded: url_helper
INFO - 2023-10-05 07:57:16 --> Helper loaded: file_helper
INFO - 2023-10-05 07:57:16 --> Helper loaded: form_helper
INFO - 2023-10-05 07:57:16 --> Helper loaded: my_helper
INFO - 2023-10-05 07:57:16 --> Database Driver Class Initialized
INFO - 2023-10-05 07:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:57:16 --> Controller Class Initialized
DEBUG - 2023-10-05 07:57:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-10-05 07:57:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 07:57:16 --> Final output sent to browser
DEBUG - 2023-10-05 07:57:16 --> Total execution time: 0.0317
INFO - 2023-10-05 07:57:19 --> Config Class Initialized
INFO - 2023-10-05 07:57:19 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:57:19 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:57:19 --> Utf8 Class Initialized
INFO - 2023-10-05 07:57:19 --> URI Class Initialized
INFO - 2023-10-05 07:57:19 --> Router Class Initialized
INFO - 2023-10-05 07:57:19 --> Output Class Initialized
INFO - 2023-10-05 07:57:19 --> Security Class Initialized
DEBUG - 2023-10-05 07:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:57:19 --> Input Class Initialized
INFO - 2023-10-05 07:57:19 --> Language Class Initialized
INFO - 2023-10-05 07:57:19 --> Language Class Initialized
INFO - 2023-10-05 07:57:19 --> Config Class Initialized
INFO - 2023-10-05 07:57:19 --> Loader Class Initialized
INFO - 2023-10-05 07:57:19 --> Helper loaded: url_helper
INFO - 2023-10-05 07:57:19 --> Helper loaded: file_helper
INFO - 2023-10-05 07:57:19 --> Helper loaded: form_helper
INFO - 2023-10-05 07:57:19 --> Helper loaded: my_helper
INFO - 2023-10-05 07:57:19 --> Database Driver Class Initialized
INFO - 2023-10-05 07:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:57:19 --> Controller Class Initialized
DEBUG - 2023-10-05 07:57:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-05 07:57:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 07:57:19 --> Final output sent to browser
DEBUG - 2023-10-05 07:57:19 --> Total execution time: 0.0687
INFO - 2023-10-05 07:57:19 --> Config Class Initialized
INFO - 2023-10-05 07:57:19 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:57:19 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:57:19 --> Utf8 Class Initialized
INFO - 2023-10-05 07:57:19 --> URI Class Initialized
INFO - 2023-10-05 07:57:19 --> Router Class Initialized
INFO - 2023-10-05 07:57:19 --> Output Class Initialized
INFO - 2023-10-05 07:57:19 --> Security Class Initialized
DEBUG - 2023-10-05 07:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:57:19 --> Input Class Initialized
INFO - 2023-10-05 07:57:19 --> Language Class Initialized
INFO - 2023-10-05 07:57:19 --> Language Class Initialized
INFO - 2023-10-05 07:57:19 --> Config Class Initialized
INFO - 2023-10-05 07:57:19 --> Loader Class Initialized
INFO - 2023-10-05 07:57:19 --> Helper loaded: url_helper
INFO - 2023-10-05 07:57:19 --> Helper loaded: file_helper
INFO - 2023-10-05 07:57:19 --> Helper loaded: form_helper
INFO - 2023-10-05 07:57:19 --> Helper loaded: my_helper
INFO - 2023-10-05 07:57:19 --> Database Driver Class Initialized
INFO - 2023-10-05 07:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:57:19 --> Controller Class Initialized
INFO - 2023-10-05 07:57:21 --> Config Class Initialized
INFO - 2023-10-05 07:57:21 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:57:21 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:57:21 --> Utf8 Class Initialized
INFO - 2023-10-05 07:57:21 --> URI Class Initialized
INFO - 2023-10-05 07:57:21 --> Router Class Initialized
INFO - 2023-10-05 07:57:21 --> Output Class Initialized
INFO - 2023-10-05 07:57:21 --> Security Class Initialized
DEBUG - 2023-10-05 07:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:57:21 --> Input Class Initialized
INFO - 2023-10-05 07:57:21 --> Language Class Initialized
INFO - 2023-10-05 07:57:21 --> Language Class Initialized
INFO - 2023-10-05 07:57:21 --> Config Class Initialized
INFO - 2023-10-05 07:57:21 --> Loader Class Initialized
INFO - 2023-10-05 07:57:21 --> Helper loaded: url_helper
INFO - 2023-10-05 07:57:21 --> Helper loaded: file_helper
INFO - 2023-10-05 07:57:21 --> Helper loaded: form_helper
INFO - 2023-10-05 07:57:21 --> Helper loaded: my_helper
INFO - 2023-10-05 07:57:21 --> Database Driver Class Initialized
INFO - 2023-10-05 07:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:57:21 --> Controller Class Initialized
DEBUG - 2023-10-05 07:57:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-10-05 07:57:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 07:57:21 --> Final output sent to browser
DEBUG - 2023-10-05 07:57:21 --> Total execution time: 0.0344
INFO - 2023-10-05 07:57:22 --> Config Class Initialized
INFO - 2023-10-05 07:57:22 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:57:22 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:57:22 --> Utf8 Class Initialized
INFO - 2023-10-05 07:57:22 --> URI Class Initialized
INFO - 2023-10-05 07:57:22 --> Router Class Initialized
INFO - 2023-10-05 07:57:22 --> Output Class Initialized
INFO - 2023-10-05 07:57:22 --> Security Class Initialized
DEBUG - 2023-10-05 07:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:57:22 --> Input Class Initialized
INFO - 2023-10-05 07:57:22 --> Language Class Initialized
INFO - 2023-10-05 07:57:22 --> Language Class Initialized
INFO - 2023-10-05 07:57:22 --> Config Class Initialized
INFO - 2023-10-05 07:57:22 --> Loader Class Initialized
INFO - 2023-10-05 07:57:22 --> Helper loaded: url_helper
INFO - 2023-10-05 07:57:22 --> Helper loaded: file_helper
INFO - 2023-10-05 07:57:22 --> Helper loaded: form_helper
INFO - 2023-10-05 07:57:22 --> Helper loaded: my_helper
INFO - 2023-10-05 07:57:22 --> Database Driver Class Initialized
INFO - 2023-10-05 07:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:57:22 --> Controller Class Initialized
DEBUG - 2023-10-05 07:57:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-10-05 07:57:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 07:57:22 --> Final output sent to browser
DEBUG - 2023-10-05 07:57:22 --> Total execution time: 0.0340
INFO - 2023-10-05 07:57:32 --> Config Class Initialized
INFO - 2023-10-05 07:57:32 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:57:32 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:57:32 --> Utf8 Class Initialized
INFO - 2023-10-05 07:57:32 --> URI Class Initialized
INFO - 2023-10-05 07:57:32 --> Router Class Initialized
INFO - 2023-10-05 07:57:32 --> Output Class Initialized
INFO - 2023-10-05 07:57:32 --> Security Class Initialized
DEBUG - 2023-10-05 07:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:57:32 --> Input Class Initialized
INFO - 2023-10-05 07:57:32 --> Language Class Initialized
INFO - 2023-10-05 07:57:32 --> Language Class Initialized
INFO - 2023-10-05 07:57:32 --> Config Class Initialized
INFO - 2023-10-05 07:57:32 --> Loader Class Initialized
INFO - 2023-10-05 07:57:32 --> Helper loaded: url_helper
INFO - 2023-10-05 07:57:32 --> Helper loaded: file_helper
INFO - 2023-10-05 07:57:32 --> Helper loaded: form_helper
INFO - 2023-10-05 07:57:32 --> Helper loaded: my_helper
INFO - 2023-10-05 07:57:32 --> Database Driver Class Initialized
INFO - 2023-10-05 07:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:57:32 --> Controller Class Initialized
INFO - 2023-10-05 07:57:32 --> Final output sent to browser
DEBUG - 2023-10-05 07:57:32 --> Total execution time: 0.0762
INFO - 2023-10-05 07:57:56 --> Config Class Initialized
INFO - 2023-10-05 07:57:56 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:57:56 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:57:56 --> Utf8 Class Initialized
INFO - 2023-10-05 07:57:56 --> URI Class Initialized
INFO - 2023-10-05 07:57:56 --> Router Class Initialized
INFO - 2023-10-05 07:57:56 --> Output Class Initialized
INFO - 2023-10-05 07:57:56 --> Security Class Initialized
DEBUG - 2023-10-05 07:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:57:56 --> Input Class Initialized
INFO - 2023-10-05 07:57:56 --> Language Class Initialized
INFO - 2023-10-05 07:57:56 --> Language Class Initialized
INFO - 2023-10-05 07:57:56 --> Config Class Initialized
INFO - 2023-10-05 07:57:56 --> Loader Class Initialized
INFO - 2023-10-05 07:57:56 --> Helper loaded: url_helper
INFO - 2023-10-05 07:57:56 --> Helper loaded: file_helper
INFO - 2023-10-05 07:57:56 --> Helper loaded: form_helper
INFO - 2023-10-05 07:57:56 --> Helper loaded: my_helper
INFO - 2023-10-05 07:57:56 --> Database Driver Class Initialized
INFO - 2023-10-05 07:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:57:56 --> Controller Class Initialized
INFO - 2023-10-05 07:57:56 --> Helper loaded: cookie_helper
INFO - 2023-10-05 07:57:56 --> Config Class Initialized
INFO - 2023-10-05 07:57:56 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:57:56 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:57:56 --> Utf8 Class Initialized
INFO - 2023-10-05 07:57:56 --> URI Class Initialized
INFO - 2023-10-05 07:57:56 --> Router Class Initialized
INFO - 2023-10-05 07:57:56 --> Output Class Initialized
INFO - 2023-10-05 07:57:56 --> Security Class Initialized
DEBUG - 2023-10-05 07:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:57:56 --> Input Class Initialized
INFO - 2023-10-05 07:57:56 --> Language Class Initialized
INFO - 2023-10-05 07:57:56 --> Language Class Initialized
INFO - 2023-10-05 07:57:56 --> Config Class Initialized
INFO - 2023-10-05 07:57:56 --> Loader Class Initialized
INFO - 2023-10-05 07:57:56 --> Helper loaded: url_helper
INFO - 2023-10-05 07:57:56 --> Helper loaded: file_helper
INFO - 2023-10-05 07:57:56 --> Helper loaded: form_helper
INFO - 2023-10-05 07:57:56 --> Helper loaded: my_helper
INFO - 2023-10-05 07:57:56 --> Database Driver Class Initialized
INFO - 2023-10-05 07:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:57:56 --> Controller Class Initialized
INFO - 2023-10-05 07:57:57 --> Config Class Initialized
INFO - 2023-10-05 07:57:57 --> Hooks Class Initialized
DEBUG - 2023-10-05 07:57:57 --> UTF-8 Support Enabled
INFO - 2023-10-05 07:57:57 --> Utf8 Class Initialized
INFO - 2023-10-05 07:57:57 --> URI Class Initialized
INFO - 2023-10-05 07:57:57 --> Router Class Initialized
INFO - 2023-10-05 07:57:57 --> Output Class Initialized
INFO - 2023-10-05 07:57:57 --> Security Class Initialized
DEBUG - 2023-10-05 07:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 07:57:57 --> Input Class Initialized
INFO - 2023-10-05 07:57:57 --> Language Class Initialized
INFO - 2023-10-05 07:57:57 --> Language Class Initialized
INFO - 2023-10-05 07:57:57 --> Config Class Initialized
INFO - 2023-10-05 07:57:57 --> Loader Class Initialized
INFO - 2023-10-05 07:57:57 --> Helper loaded: url_helper
INFO - 2023-10-05 07:57:57 --> Helper loaded: file_helper
INFO - 2023-10-05 07:57:57 --> Helper loaded: form_helper
INFO - 2023-10-05 07:57:57 --> Helper loaded: my_helper
INFO - 2023-10-05 07:57:57 --> Database Driver Class Initialized
INFO - 2023-10-05 07:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 07:57:57 --> Controller Class Initialized
DEBUG - 2023-10-05 07:57:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-05 07:57:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 07:57:57 --> Final output sent to browser
DEBUG - 2023-10-05 07:57:57 --> Total execution time: 0.0298
INFO - 2023-10-05 08:00:38 --> Config Class Initialized
INFO - 2023-10-05 08:00:38 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:00:38 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:00:38 --> Utf8 Class Initialized
INFO - 2023-10-05 08:00:38 --> URI Class Initialized
INFO - 2023-10-05 08:00:38 --> Router Class Initialized
INFO - 2023-10-05 08:00:38 --> Output Class Initialized
INFO - 2023-10-05 08:00:38 --> Security Class Initialized
DEBUG - 2023-10-05 08:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:00:38 --> Input Class Initialized
INFO - 2023-10-05 08:00:38 --> Language Class Initialized
INFO - 2023-10-05 08:00:38 --> Language Class Initialized
INFO - 2023-10-05 08:00:38 --> Config Class Initialized
INFO - 2023-10-05 08:00:38 --> Loader Class Initialized
INFO - 2023-10-05 08:00:38 --> Helper loaded: url_helper
INFO - 2023-10-05 08:00:38 --> Helper loaded: file_helper
INFO - 2023-10-05 08:00:38 --> Helper loaded: form_helper
INFO - 2023-10-05 08:00:38 --> Helper loaded: my_helper
INFO - 2023-10-05 08:00:38 --> Database Driver Class Initialized
INFO - 2023-10-05 08:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:00:38 --> Controller Class Initialized
ERROR - 2023-10-05 08:00:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam s' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = '-', nilai_mid = 'Dalam memahami kandungan ayat tentang keutamaan menuntut ilmu dan Al-Qur'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam syamsiyah, alif lam qomariyah, nun sukun dan tasydid, kamu memiliki potensi untuk bisa memahami lebih detail. Namun, perlu lebih aktif lagi dalam mengikuti pelajaran. terutama jika ada materi yang belum bisa dipahami, kamu bisa langsung bertanya atau meminta penjelasan lebih rinci dan jelas. Aktif dan beranilah bertanya.' WHERE id_guru_mapel = '1' AND id_mapel_kd = '2' AND id_siswa = '1' AND jenis = 'c'
INFO - 2023-10-05 08:00:38 --> Language file loaded: language/english/db_lang.php
INFO - 2023-10-05 08:00:41 --> Config Class Initialized
INFO - 2023-10-05 08:00:41 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:00:41 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:00:41 --> Utf8 Class Initialized
INFO - 2023-10-05 08:00:41 --> URI Class Initialized
INFO - 2023-10-05 08:00:41 --> Router Class Initialized
INFO - 2023-10-05 08:00:41 --> Output Class Initialized
INFO - 2023-10-05 08:00:41 --> Security Class Initialized
DEBUG - 2023-10-05 08:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:00:41 --> Input Class Initialized
INFO - 2023-10-05 08:00:41 --> Language Class Initialized
INFO - 2023-10-05 08:00:41 --> Language Class Initialized
INFO - 2023-10-05 08:00:41 --> Config Class Initialized
INFO - 2023-10-05 08:00:41 --> Loader Class Initialized
INFO - 2023-10-05 08:00:41 --> Helper loaded: url_helper
INFO - 2023-10-05 08:00:41 --> Helper loaded: file_helper
INFO - 2023-10-05 08:00:41 --> Helper loaded: form_helper
INFO - 2023-10-05 08:00:41 --> Helper loaded: my_helper
INFO - 2023-10-05 08:00:41 --> Database Driver Class Initialized
INFO - 2023-10-05 08:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:00:41 --> Controller Class Initialized
ERROR - 2023-10-05 08:00:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam s' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = '-', nilai_mid = 'Dalam memahami kandungan ayat tentang keutamaan menuntut ilmu dan Al-Qur'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam syamsiyah, alif lam qomariyah, nun sukun dan tasydid, kamu memiliki potensi untuk bisa memahami lebih detail. Namun, perlu lebih aktif lagi dalam mengikuti pelajaran. terutama jika ada materi yang belum bisa dipahami, kamu bisa langsung bertanya atau meminta penjelasan lebih rinci dan jelas. Aktif dan beranilah bertanya.' WHERE id_guru_mapel = '1' AND id_mapel_kd = '2' AND id_siswa = '1' AND jenis = 'c'
INFO - 2023-10-05 08:00:41 --> Language file loaded: language/english/db_lang.php
INFO - 2023-10-05 08:00:41 --> Config Class Initialized
INFO - 2023-10-05 08:00:41 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:00:41 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:00:41 --> Utf8 Class Initialized
INFO - 2023-10-05 08:00:41 --> URI Class Initialized
INFO - 2023-10-05 08:00:41 --> Router Class Initialized
INFO - 2023-10-05 08:00:41 --> Output Class Initialized
INFO - 2023-10-05 08:00:41 --> Security Class Initialized
DEBUG - 2023-10-05 08:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:00:41 --> Input Class Initialized
INFO - 2023-10-05 08:00:41 --> Language Class Initialized
INFO - 2023-10-05 08:00:41 --> Language Class Initialized
INFO - 2023-10-05 08:00:41 --> Config Class Initialized
INFO - 2023-10-05 08:00:41 --> Loader Class Initialized
INFO - 2023-10-05 08:00:41 --> Helper loaded: url_helper
INFO - 2023-10-05 08:00:41 --> Helper loaded: file_helper
INFO - 2023-10-05 08:00:41 --> Helper loaded: form_helper
INFO - 2023-10-05 08:00:41 --> Helper loaded: my_helper
INFO - 2023-10-05 08:00:41 --> Database Driver Class Initialized
INFO - 2023-10-05 08:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:00:41 --> Controller Class Initialized
ERROR - 2023-10-05 08:00:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam s' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = '-', nilai_mid = 'Dalam memahami kandungan ayat tentang keutamaan menuntut ilmu dan Al-Qur'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam syamsiyah, alif lam qomariyah, nun sukun dan tasydid, kamu memiliki potensi untuk bisa memahami lebih detail. Namun, perlu lebih aktif lagi dalam mengikuti pelajaran. terutama jika ada materi yang belum bisa dipahami, kamu bisa langsung bertanya atau meminta penjelasan lebih rinci dan jelas. Aktif dan beranilah bertanya.' WHERE id_guru_mapel = '1' AND id_mapel_kd = '2' AND id_siswa = '1' AND jenis = 'c'
INFO - 2023-10-05 08:00:41 --> Language file loaded: language/english/db_lang.php
INFO - 2023-10-05 08:00:42 --> Config Class Initialized
INFO - 2023-10-05 08:00:42 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:00:42 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:00:42 --> Utf8 Class Initialized
INFO - 2023-10-05 08:00:42 --> URI Class Initialized
INFO - 2023-10-05 08:00:42 --> Router Class Initialized
INFO - 2023-10-05 08:00:42 --> Output Class Initialized
INFO - 2023-10-05 08:00:42 --> Security Class Initialized
DEBUG - 2023-10-05 08:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:00:42 --> Input Class Initialized
INFO - 2023-10-05 08:00:42 --> Language Class Initialized
INFO - 2023-10-05 08:00:42 --> Language Class Initialized
INFO - 2023-10-05 08:00:42 --> Config Class Initialized
INFO - 2023-10-05 08:00:42 --> Loader Class Initialized
INFO - 2023-10-05 08:00:42 --> Helper loaded: url_helper
INFO - 2023-10-05 08:00:42 --> Helper loaded: file_helper
INFO - 2023-10-05 08:00:42 --> Helper loaded: form_helper
INFO - 2023-10-05 08:00:42 --> Helper loaded: my_helper
INFO - 2023-10-05 08:00:42 --> Database Driver Class Initialized
INFO - 2023-10-05 08:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:00:42 --> Controller Class Initialized
ERROR - 2023-10-05 08:00:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam s' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = '-', nilai_mid = 'Dalam memahami kandungan ayat tentang keutamaan menuntut ilmu dan Al-Qur'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam syamsiyah, alif lam qomariyah, nun sukun dan tasydid, kamu memiliki potensi untuk bisa memahami lebih detail. Namun, perlu lebih aktif lagi dalam mengikuti pelajaran. terutama jika ada materi yang belum bisa dipahami, kamu bisa langsung bertanya atau meminta penjelasan lebih rinci dan jelas. Aktif dan beranilah bertanya.' WHERE id_guru_mapel = '1' AND id_mapel_kd = '2' AND id_siswa = '1' AND jenis = 'c'
INFO - 2023-10-05 08:00:42 --> Language file loaded: language/english/db_lang.php
INFO - 2023-10-05 08:00:42 --> Config Class Initialized
INFO - 2023-10-05 08:00:42 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:00:42 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:00:42 --> Utf8 Class Initialized
INFO - 2023-10-05 08:00:42 --> URI Class Initialized
INFO - 2023-10-05 08:00:42 --> Router Class Initialized
INFO - 2023-10-05 08:00:42 --> Output Class Initialized
INFO - 2023-10-05 08:00:42 --> Security Class Initialized
DEBUG - 2023-10-05 08:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:00:42 --> Input Class Initialized
INFO - 2023-10-05 08:00:42 --> Language Class Initialized
INFO - 2023-10-05 08:00:42 --> Language Class Initialized
INFO - 2023-10-05 08:00:42 --> Config Class Initialized
INFO - 2023-10-05 08:00:42 --> Loader Class Initialized
INFO - 2023-10-05 08:00:42 --> Helper loaded: url_helper
INFO - 2023-10-05 08:00:42 --> Helper loaded: file_helper
INFO - 2023-10-05 08:00:42 --> Helper loaded: form_helper
INFO - 2023-10-05 08:00:42 --> Helper loaded: my_helper
INFO - 2023-10-05 08:00:42 --> Database Driver Class Initialized
INFO - 2023-10-05 08:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:00:42 --> Controller Class Initialized
ERROR - 2023-10-05 08:00:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam s' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = '-', nilai_mid = 'Dalam memahami kandungan ayat tentang keutamaan menuntut ilmu dan Al-Qur'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam syamsiyah, alif lam qomariyah, nun sukun dan tasydid, kamu memiliki potensi untuk bisa memahami lebih detail. Namun, perlu lebih aktif lagi dalam mengikuti pelajaran. terutama jika ada materi yang belum bisa dipahami, kamu bisa langsung bertanya atau meminta penjelasan lebih rinci dan jelas. Aktif dan beranilah bertanya.' WHERE id_guru_mapel = '1' AND id_mapel_kd = '2' AND id_siswa = '1' AND jenis = 'c'
INFO - 2023-10-05 08:00:42 --> Language file loaded: language/english/db_lang.php
INFO - 2023-10-05 08:00:42 --> Config Class Initialized
INFO - 2023-10-05 08:00:42 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:00:42 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:00:42 --> Utf8 Class Initialized
INFO - 2023-10-05 08:00:42 --> URI Class Initialized
INFO - 2023-10-05 08:00:42 --> Router Class Initialized
INFO - 2023-10-05 08:00:42 --> Output Class Initialized
INFO - 2023-10-05 08:00:42 --> Security Class Initialized
DEBUG - 2023-10-05 08:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:00:42 --> Input Class Initialized
INFO - 2023-10-05 08:00:42 --> Language Class Initialized
INFO - 2023-10-05 08:00:42 --> Language Class Initialized
INFO - 2023-10-05 08:00:42 --> Config Class Initialized
INFO - 2023-10-05 08:00:42 --> Loader Class Initialized
INFO - 2023-10-05 08:00:42 --> Helper loaded: url_helper
INFO - 2023-10-05 08:00:42 --> Helper loaded: file_helper
INFO - 2023-10-05 08:00:42 --> Helper loaded: form_helper
INFO - 2023-10-05 08:00:42 --> Helper loaded: my_helper
INFO - 2023-10-05 08:00:42 --> Database Driver Class Initialized
INFO - 2023-10-05 08:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:00:42 --> Controller Class Initialized
ERROR - 2023-10-05 08:00:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam s' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = '-', nilai_mid = 'Dalam memahami kandungan ayat tentang keutamaan menuntut ilmu dan Al-Qur'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam syamsiyah, alif lam qomariyah, nun sukun dan tasydid, kamu memiliki potensi untuk bisa memahami lebih detail. Namun, perlu lebih aktif lagi dalam mengikuti pelajaran. terutama jika ada materi yang belum bisa dipahami, kamu bisa langsung bertanya atau meminta penjelasan lebih rinci dan jelas. Aktif dan beranilah bertanya.' WHERE id_guru_mapel = '1' AND id_mapel_kd = '2' AND id_siswa = '1' AND jenis = 'c'
INFO - 2023-10-05 08:00:42 --> Language file loaded: language/english/db_lang.php
INFO - 2023-10-05 08:00:46 --> Config Class Initialized
INFO - 2023-10-05 08:00:46 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:00:46 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:00:46 --> Utf8 Class Initialized
INFO - 2023-10-05 08:00:46 --> URI Class Initialized
INFO - 2023-10-05 08:00:46 --> Router Class Initialized
INFO - 2023-10-05 08:00:46 --> Output Class Initialized
INFO - 2023-10-05 08:00:46 --> Security Class Initialized
DEBUG - 2023-10-05 08:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:00:46 --> Input Class Initialized
INFO - 2023-10-05 08:00:46 --> Language Class Initialized
INFO - 2023-10-05 08:00:46 --> Language Class Initialized
INFO - 2023-10-05 08:00:46 --> Config Class Initialized
INFO - 2023-10-05 08:00:46 --> Loader Class Initialized
INFO - 2023-10-05 08:00:46 --> Helper loaded: url_helper
INFO - 2023-10-05 08:00:46 --> Helper loaded: file_helper
INFO - 2023-10-05 08:00:46 --> Helper loaded: form_helper
INFO - 2023-10-05 08:00:46 --> Helper loaded: my_helper
INFO - 2023-10-05 08:00:46 --> Database Driver Class Initialized
INFO - 2023-10-05 08:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:00:46 --> Controller Class Initialized
ERROR - 2023-10-05 08:00:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam s' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = '-', nilai_mid = 'Dalam memahami kandungan ayat tentang keutamaan menuntut ilmu dan Al-Qur'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam syamsiyah, alif lam qomariyah, nun sukun dan tasydid, kamu memiliki potensi untuk bisa memahami lebih detail. Namun, perlu lebih aktif lagi dalam mengikuti pelajaran. terutama jika ada materi yang belum bisa dipahami, kamu bisa langsung bertanya atau meminta penjelasan lebih rinci dan jelas. Aktif dan beranilah bertanya.' WHERE id_guru_mapel = '1' AND id_mapel_kd = '2' AND id_siswa = '1' AND jenis = 'c'
INFO - 2023-10-05 08:00:46 --> Language file loaded: language/english/db_lang.php
INFO - 2023-10-05 08:00:46 --> Config Class Initialized
INFO - 2023-10-05 08:00:46 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:00:46 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:00:46 --> Utf8 Class Initialized
INFO - 2023-10-05 08:00:46 --> URI Class Initialized
INFO - 2023-10-05 08:00:46 --> Router Class Initialized
INFO - 2023-10-05 08:00:46 --> Output Class Initialized
INFO - 2023-10-05 08:00:46 --> Security Class Initialized
DEBUG - 2023-10-05 08:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:00:46 --> Input Class Initialized
INFO - 2023-10-05 08:00:46 --> Language Class Initialized
INFO - 2023-10-05 08:00:46 --> Language Class Initialized
INFO - 2023-10-05 08:00:46 --> Config Class Initialized
INFO - 2023-10-05 08:00:46 --> Loader Class Initialized
INFO - 2023-10-05 08:00:46 --> Helper loaded: url_helper
INFO - 2023-10-05 08:00:46 --> Helper loaded: file_helper
INFO - 2023-10-05 08:00:46 --> Helper loaded: form_helper
INFO - 2023-10-05 08:00:46 --> Helper loaded: my_helper
INFO - 2023-10-05 08:00:46 --> Database Driver Class Initialized
INFO - 2023-10-05 08:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:00:46 --> Controller Class Initialized
ERROR - 2023-10-05 08:00:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam s' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = '-', nilai_mid = 'Dalam memahami kandungan ayat tentang keutamaan menuntut ilmu dan Al-Qur'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam syamsiyah, alif lam qomariyah, nun sukun dan tasydid, kamu memiliki potensi untuk bisa memahami lebih detail. Namun, perlu lebih aktif lagi dalam mengikuti pelajaran. terutama jika ada materi yang belum bisa dipahami, kamu bisa langsung bertanya atau meminta penjelasan lebih rinci dan jelas. Aktif dan beranilah bertanya.' WHERE id_guru_mapel = '1' AND id_mapel_kd = '2' AND id_siswa = '1' AND jenis = 'c'
INFO - 2023-10-05 08:00:46 --> Language file loaded: language/english/db_lang.php
INFO - 2023-10-05 08:00:46 --> Config Class Initialized
INFO - 2023-10-05 08:00:46 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:00:46 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:00:46 --> Utf8 Class Initialized
INFO - 2023-10-05 08:00:46 --> URI Class Initialized
INFO - 2023-10-05 08:00:46 --> Router Class Initialized
INFO - 2023-10-05 08:00:46 --> Output Class Initialized
INFO - 2023-10-05 08:00:46 --> Security Class Initialized
DEBUG - 2023-10-05 08:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:00:46 --> Input Class Initialized
INFO - 2023-10-05 08:00:46 --> Language Class Initialized
INFO - 2023-10-05 08:00:46 --> Language Class Initialized
INFO - 2023-10-05 08:00:46 --> Config Class Initialized
INFO - 2023-10-05 08:00:46 --> Loader Class Initialized
INFO - 2023-10-05 08:00:46 --> Helper loaded: url_helper
INFO - 2023-10-05 08:00:46 --> Helper loaded: file_helper
INFO - 2023-10-05 08:00:46 --> Helper loaded: form_helper
INFO - 2023-10-05 08:00:46 --> Helper loaded: my_helper
INFO - 2023-10-05 08:00:46 --> Database Driver Class Initialized
INFO - 2023-10-05 08:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:00:46 --> Controller Class Initialized
ERROR - 2023-10-05 08:00:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam s' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = '-', nilai_mid = 'Dalam memahami kandungan ayat tentang keutamaan menuntut ilmu dan Al-Qur'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam syamsiyah, alif lam qomariyah, nun sukun dan tasydid, kamu memiliki potensi untuk bisa memahami lebih detail. Namun, perlu lebih aktif lagi dalam mengikuti pelajaran. terutama jika ada materi yang belum bisa dipahami, kamu bisa langsung bertanya atau meminta penjelasan lebih rinci dan jelas. Aktif dan beranilah bertanya.' WHERE id_guru_mapel = '1' AND id_mapel_kd = '2' AND id_siswa = '1' AND jenis = 'c'
INFO - 2023-10-05 08:00:46 --> Language file loaded: language/english/db_lang.php
INFO - 2023-10-05 08:00:47 --> Config Class Initialized
INFO - 2023-10-05 08:00:47 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:00:47 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:00:47 --> Utf8 Class Initialized
INFO - 2023-10-05 08:00:47 --> URI Class Initialized
INFO - 2023-10-05 08:00:47 --> Router Class Initialized
INFO - 2023-10-05 08:00:47 --> Output Class Initialized
INFO - 2023-10-05 08:00:47 --> Security Class Initialized
DEBUG - 2023-10-05 08:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:00:47 --> Input Class Initialized
INFO - 2023-10-05 08:00:47 --> Language Class Initialized
INFO - 2023-10-05 08:00:47 --> Language Class Initialized
INFO - 2023-10-05 08:00:47 --> Config Class Initialized
INFO - 2023-10-05 08:00:47 --> Loader Class Initialized
INFO - 2023-10-05 08:00:47 --> Helper loaded: url_helper
INFO - 2023-10-05 08:00:47 --> Helper loaded: file_helper
INFO - 2023-10-05 08:00:47 --> Helper loaded: form_helper
INFO - 2023-10-05 08:00:47 --> Helper loaded: my_helper
INFO - 2023-10-05 08:00:47 --> Database Driver Class Initialized
INFO - 2023-10-05 08:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:00:47 --> Controller Class Initialized
ERROR - 2023-10-05 08:00:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam s' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = '-', nilai_mid = 'Dalam memahami kandungan ayat tentang keutamaan menuntut ilmu dan Al-Qur'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam syamsiyah, alif lam qomariyah, nun sukun dan tasydid, kamu memiliki potensi untuk bisa memahami lebih detail. Namun, perlu lebih aktif lagi dalam mengikuti pelajaran. terutama jika ada materi yang belum bisa dipahami, kamu bisa langsung bertanya atau meminta penjelasan lebih rinci dan jelas. Aktif dan beranilah bertanya.' WHERE id_guru_mapel = '1' AND id_mapel_kd = '2' AND id_siswa = '1' AND jenis = 'c'
INFO - 2023-10-05 08:00:47 --> Language file loaded: language/english/db_lang.php
INFO - 2023-10-05 08:00:47 --> Config Class Initialized
INFO - 2023-10-05 08:00:47 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:00:47 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:00:47 --> Utf8 Class Initialized
INFO - 2023-10-05 08:00:47 --> URI Class Initialized
INFO - 2023-10-05 08:00:47 --> Router Class Initialized
INFO - 2023-10-05 08:00:47 --> Output Class Initialized
INFO - 2023-10-05 08:00:47 --> Security Class Initialized
DEBUG - 2023-10-05 08:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:00:47 --> Input Class Initialized
INFO - 2023-10-05 08:00:47 --> Language Class Initialized
INFO - 2023-10-05 08:00:47 --> Language Class Initialized
INFO - 2023-10-05 08:00:47 --> Config Class Initialized
INFO - 2023-10-05 08:00:47 --> Loader Class Initialized
INFO - 2023-10-05 08:00:47 --> Helper loaded: url_helper
INFO - 2023-10-05 08:00:47 --> Helper loaded: file_helper
INFO - 2023-10-05 08:00:47 --> Helper loaded: form_helper
INFO - 2023-10-05 08:00:47 --> Helper loaded: my_helper
INFO - 2023-10-05 08:00:47 --> Database Driver Class Initialized
INFO - 2023-10-05 08:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:00:47 --> Controller Class Initialized
ERROR - 2023-10-05 08:00:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam s' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = '-', nilai_mid = 'Dalam memahami kandungan ayat tentang keutamaan menuntut ilmu dan Al-Qur'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam syamsiyah, alif lam qomariyah, nun sukun dan tasydid, kamu memiliki potensi untuk bisa memahami lebih detail. Namun, perlu lebih aktif lagi dalam mengikuti pelajaran. terutama jika ada materi yang belum bisa dipahami, kamu bisa langsung bertanya atau meminta penjelasan lebih rinci dan jelas. Aktif dan beranilah bertanya.' WHERE id_guru_mapel = '1' AND id_mapel_kd = '2' AND id_siswa = '1' AND jenis = 'c'
INFO - 2023-10-05 08:00:47 --> Language file loaded: language/english/db_lang.php
INFO - 2023-10-05 08:00:52 --> Config Class Initialized
INFO - 2023-10-05 08:00:52 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:00:52 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:00:52 --> Utf8 Class Initialized
INFO - 2023-10-05 08:00:52 --> URI Class Initialized
INFO - 2023-10-05 08:00:52 --> Router Class Initialized
INFO - 2023-10-05 08:00:52 --> Output Class Initialized
INFO - 2023-10-05 08:00:52 --> Security Class Initialized
DEBUG - 2023-10-05 08:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:00:52 --> Input Class Initialized
INFO - 2023-10-05 08:00:52 --> Language Class Initialized
INFO - 2023-10-05 08:00:52 --> Language Class Initialized
INFO - 2023-10-05 08:00:52 --> Config Class Initialized
INFO - 2023-10-05 08:00:52 --> Loader Class Initialized
INFO - 2023-10-05 08:00:52 --> Helper loaded: url_helper
INFO - 2023-10-05 08:00:52 --> Helper loaded: file_helper
INFO - 2023-10-05 08:00:52 --> Helper loaded: form_helper
INFO - 2023-10-05 08:00:52 --> Helper loaded: my_helper
INFO - 2023-10-05 08:00:52 --> Database Driver Class Initialized
INFO - 2023-10-05 08:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:00:52 --> Controller Class Initialized
INFO - 2023-10-05 08:00:52 --> Helper loaded: cookie_helper
INFO - 2023-10-05 08:00:52 --> Final output sent to browser
DEBUG - 2023-10-05 08:00:52 --> Total execution time: 0.1477
INFO - 2023-10-05 08:00:52 --> Config Class Initialized
INFO - 2023-10-05 08:00:52 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:00:52 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:00:52 --> Utf8 Class Initialized
INFO - 2023-10-05 08:00:52 --> URI Class Initialized
INFO - 2023-10-05 08:00:52 --> Router Class Initialized
INFO - 2023-10-05 08:00:52 --> Output Class Initialized
INFO - 2023-10-05 08:00:52 --> Security Class Initialized
DEBUG - 2023-10-05 08:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:00:52 --> Input Class Initialized
INFO - 2023-10-05 08:00:52 --> Language Class Initialized
INFO - 2023-10-05 08:00:52 --> Language Class Initialized
INFO - 2023-10-05 08:00:52 --> Config Class Initialized
INFO - 2023-10-05 08:00:52 --> Loader Class Initialized
INFO - 2023-10-05 08:00:52 --> Helper loaded: url_helper
INFO - 2023-10-05 08:00:52 --> Helper loaded: file_helper
INFO - 2023-10-05 08:00:52 --> Helper loaded: form_helper
INFO - 2023-10-05 08:00:52 --> Helper loaded: my_helper
INFO - 2023-10-05 08:00:52 --> Database Driver Class Initialized
INFO - 2023-10-05 08:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:00:52 --> Controller Class Initialized
DEBUG - 2023-10-05 08:00:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-10-05 08:00:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 08:00:52 --> Final output sent to browser
DEBUG - 2023-10-05 08:00:52 --> Total execution time: 0.0376
INFO - 2023-10-05 08:00:58 --> Config Class Initialized
INFO - 2023-10-05 08:00:58 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:00:58 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:00:58 --> Utf8 Class Initialized
INFO - 2023-10-05 08:00:58 --> URI Class Initialized
INFO - 2023-10-05 08:00:58 --> Router Class Initialized
INFO - 2023-10-05 08:00:58 --> Output Class Initialized
INFO - 2023-10-05 08:00:58 --> Security Class Initialized
DEBUG - 2023-10-05 08:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:00:58 --> Input Class Initialized
INFO - 2023-10-05 08:00:58 --> Language Class Initialized
INFO - 2023-10-05 08:00:58 --> Language Class Initialized
INFO - 2023-10-05 08:00:58 --> Config Class Initialized
INFO - 2023-10-05 08:00:58 --> Loader Class Initialized
INFO - 2023-10-05 08:00:58 --> Helper loaded: url_helper
INFO - 2023-10-05 08:00:58 --> Helper loaded: file_helper
INFO - 2023-10-05 08:00:58 --> Helper loaded: form_helper
INFO - 2023-10-05 08:00:58 --> Helper loaded: my_helper
INFO - 2023-10-05 08:00:58 --> Database Driver Class Initialized
INFO - 2023-10-05 08:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:00:58 --> Controller Class Initialized
DEBUG - 2023-10-05 08:00:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2023-10-05 08:00:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 08:00:58 --> Final output sent to browser
DEBUG - 2023-10-05 08:00:58 --> Total execution time: 0.0691
INFO - 2023-10-05 08:01:00 --> Config Class Initialized
INFO - 2023-10-05 08:01:00 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:01:00 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:01:00 --> Utf8 Class Initialized
INFO - 2023-10-05 08:01:00 --> URI Class Initialized
INFO - 2023-10-05 08:01:00 --> Router Class Initialized
INFO - 2023-10-05 08:01:00 --> Output Class Initialized
INFO - 2023-10-05 08:01:00 --> Security Class Initialized
DEBUG - 2023-10-05 08:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:01:00 --> Input Class Initialized
INFO - 2023-10-05 08:01:00 --> Language Class Initialized
INFO - 2023-10-05 08:01:00 --> Language Class Initialized
INFO - 2023-10-05 08:01:00 --> Config Class Initialized
INFO - 2023-10-05 08:01:00 --> Loader Class Initialized
INFO - 2023-10-05 08:01:00 --> Helper loaded: url_helper
INFO - 2023-10-05 08:01:00 --> Helper loaded: file_helper
INFO - 2023-10-05 08:01:00 --> Helper loaded: form_helper
INFO - 2023-10-05 08:01:00 --> Helper loaded: my_helper
INFO - 2023-10-05 08:01:00 --> Database Driver Class Initialized
INFO - 2023-10-05 08:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:01:00 --> Controller Class Initialized
DEBUG - 2023-10-05 08:01:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 08:01:07 --> Final output sent to browser
DEBUG - 2023-10-05 08:01:07 --> Total execution time: 6.9514
INFO - 2023-10-05 08:01:22 --> Config Class Initialized
INFO - 2023-10-05 08:01:22 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:01:22 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:01:22 --> Utf8 Class Initialized
INFO - 2023-10-05 08:01:22 --> URI Class Initialized
INFO - 2023-10-05 08:01:22 --> Router Class Initialized
INFO - 2023-10-05 08:01:22 --> Output Class Initialized
INFO - 2023-10-05 08:01:22 --> Security Class Initialized
DEBUG - 2023-10-05 08:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:01:22 --> Input Class Initialized
INFO - 2023-10-05 08:01:22 --> Language Class Initialized
INFO - 2023-10-05 08:01:22 --> Language Class Initialized
INFO - 2023-10-05 08:01:22 --> Config Class Initialized
INFO - 2023-10-05 08:01:22 --> Loader Class Initialized
INFO - 2023-10-05 08:01:22 --> Helper loaded: url_helper
INFO - 2023-10-05 08:01:22 --> Helper loaded: file_helper
INFO - 2023-10-05 08:01:22 --> Helper loaded: form_helper
INFO - 2023-10-05 08:01:22 --> Helper loaded: my_helper
INFO - 2023-10-05 08:01:22 --> Database Driver Class Initialized
INFO - 2023-10-05 08:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:01:22 --> Controller Class Initialized
INFO - 2023-10-05 08:01:22 --> Helper loaded: cookie_helper
INFO - 2023-10-05 08:01:22 --> Config Class Initialized
INFO - 2023-10-05 08:01:22 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:01:22 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:01:22 --> Utf8 Class Initialized
INFO - 2023-10-05 08:01:22 --> URI Class Initialized
INFO - 2023-10-05 08:01:22 --> Router Class Initialized
INFO - 2023-10-05 08:01:22 --> Output Class Initialized
INFO - 2023-10-05 08:01:22 --> Security Class Initialized
DEBUG - 2023-10-05 08:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:01:22 --> Input Class Initialized
INFO - 2023-10-05 08:01:22 --> Language Class Initialized
INFO - 2023-10-05 08:01:22 --> Language Class Initialized
INFO - 2023-10-05 08:01:22 --> Config Class Initialized
INFO - 2023-10-05 08:01:22 --> Loader Class Initialized
INFO - 2023-10-05 08:01:22 --> Helper loaded: url_helper
INFO - 2023-10-05 08:01:22 --> Helper loaded: file_helper
INFO - 2023-10-05 08:01:22 --> Helper loaded: form_helper
INFO - 2023-10-05 08:01:22 --> Helper loaded: my_helper
INFO - 2023-10-05 08:01:22 --> Database Driver Class Initialized
INFO - 2023-10-05 08:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:01:22 --> Controller Class Initialized
INFO - 2023-10-05 08:01:22 --> Config Class Initialized
INFO - 2023-10-05 08:01:22 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:01:22 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:01:22 --> Utf8 Class Initialized
INFO - 2023-10-05 08:01:22 --> URI Class Initialized
INFO - 2023-10-05 08:01:22 --> Router Class Initialized
INFO - 2023-10-05 08:01:22 --> Output Class Initialized
INFO - 2023-10-05 08:01:22 --> Security Class Initialized
DEBUG - 2023-10-05 08:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:01:22 --> Input Class Initialized
INFO - 2023-10-05 08:01:22 --> Language Class Initialized
INFO - 2023-10-05 08:01:22 --> Language Class Initialized
INFO - 2023-10-05 08:01:22 --> Config Class Initialized
INFO - 2023-10-05 08:01:22 --> Loader Class Initialized
INFO - 2023-10-05 08:01:22 --> Helper loaded: url_helper
INFO - 2023-10-05 08:01:22 --> Helper loaded: file_helper
INFO - 2023-10-05 08:01:22 --> Helper loaded: form_helper
INFO - 2023-10-05 08:01:22 --> Helper loaded: my_helper
INFO - 2023-10-05 08:01:22 --> Database Driver Class Initialized
INFO - 2023-10-05 08:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:01:22 --> Controller Class Initialized
DEBUG - 2023-10-05 08:01:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-05 08:01:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 08:01:22 --> Final output sent to browser
DEBUG - 2023-10-05 08:01:22 --> Total execution time: 0.0405
INFO - 2023-10-05 08:01:40 --> Config Class Initialized
INFO - 2023-10-05 08:01:40 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:01:40 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:01:40 --> Utf8 Class Initialized
INFO - 2023-10-05 08:01:40 --> URI Class Initialized
INFO - 2023-10-05 08:01:40 --> Router Class Initialized
INFO - 2023-10-05 08:01:40 --> Output Class Initialized
INFO - 2023-10-05 08:01:40 --> Security Class Initialized
DEBUG - 2023-10-05 08:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:01:40 --> Input Class Initialized
INFO - 2023-10-05 08:01:40 --> Language Class Initialized
INFO - 2023-10-05 08:01:40 --> Language Class Initialized
INFO - 2023-10-05 08:01:40 --> Config Class Initialized
INFO - 2023-10-05 08:01:40 --> Loader Class Initialized
INFO - 2023-10-05 08:01:40 --> Helper loaded: url_helper
INFO - 2023-10-05 08:01:40 --> Helper loaded: file_helper
INFO - 2023-10-05 08:01:40 --> Helper loaded: form_helper
INFO - 2023-10-05 08:01:40 --> Helper loaded: my_helper
INFO - 2023-10-05 08:01:40 --> Database Driver Class Initialized
INFO - 2023-10-05 08:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:01:40 --> Controller Class Initialized
INFO - 2023-10-05 08:01:40 --> Helper loaded: cookie_helper
INFO - 2023-10-05 08:01:40 --> Final output sent to browser
DEBUG - 2023-10-05 08:01:40 --> Total execution time: 0.0617
INFO - 2023-10-05 08:01:40 --> Config Class Initialized
INFO - 2023-10-05 08:01:40 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:01:40 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:01:40 --> Utf8 Class Initialized
INFO - 2023-10-05 08:01:40 --> URI Class Initialized
INFO - 2023-10-05 08:01:40 --> Router Class Initialized
INFO - 2023-10-05 08:01:40 --> Output Class Initialized
INFO - 2023-10-05 08:01:40 --> Security Class Initialized
DEBUG - 2023-10-05 08:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:01:40 --> Input Class Initialized
INFO - 2023-10-05 08:01:40 --> Language Class Initialized
INFO - 2023-10-05 08:01:40 --> Language Class Initialized
INFO - 2023-10-05 08:01:40 --> Config Class Initialized
INFO - 2023-10-05 08:01:40 --> Loader Class Initialized
INFO - 2023-10-05 08:01:40 --> Helper loaded: url_helper
INFO - 2023-10-05 08:01:40 --> Helper loaded: file_helper
INFO - 2023-10-05 08:01:40 --> Helper loaded: form_helper
INFO - 2023-10-05 08:01:40 --> Helper loaded: my_helper
INFO - 2023-10-05 08:01:40 --> Database Driver Class Initialized
INFO - 2023-10-05 08:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:01:40 --> Controller Class Initialized
DEBUG - 2023-10-05 08:01:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-10-05 08:01:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 08:01:40 --> Final output sent to browser
DEBUG - 2023-10-05 08:01:40 --> Total execution time: 0.0448
INFO - 2023-10-05 08:01:43 --> Config Class Initialized
INFO - 2023-10-05 08:01:43 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:01:43 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:01:43 --> Utf8 Class Initialized
INFO - 2023-10-05 08:01:43 --> URI Class Initialized
INFO - 2023-10-05 08:01:43 --> Router Class Initialized
INFO - 2023-10-05 08:01:43 --> Output Class Initialized
INFO - 2023-10-05 08:01:43 --> Security Class Initialized
DEBUG - 2023-10-05 08:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:01:43 --> Input Class Initialized
INFO - 2023-10-05 08:01:43 --> Language Class Initialized
INFO - 2023-10-05 08:01:43 --> Language Class Initialized
INFO - 2023-10-05 08:01:43 --> Config Class Initialized
INFO - 2023-10-05 08:01:43 --> Loader Class Initialized
INFO - 2023-10-05 08:01:43 --> Helper loaded: url_helper
INFO - 2023-10-05 08:01:43 --> Helper loaded: file_helper
INFO - 2023-10-05 08:01:43 --> Helper loaded: form_helper
INFO - 2023-10-05 08:01:43 --> Helper loaded: my_helper
INFO - 2023-10-05 08:01:43 --> Database Driver Class Initialized
INFO - 2023-10-05 08:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:01:43 --> Controller Class Initialized
ERROR - 2023-10-05 08:01:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam s' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = '-', nilai_mid = 'Dalam memahami kandungan ayat tentang keutamaan menuntut ilmu dan Al-Qur'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam syamsiyah, alif lam qomariyah, nun sukun dan tasydid, kamu memiliki potensi untuk bisa memahami lebih detail. Namun, perlu lebih aktif lagi dalam mengikuti pelajaran. terutama jika ada materi yang belum bisa dipahami, kamu bisa langsung bertanya atau meminta penjelasan lebih rinci dan jelas. Aktif dan beranilah bertanya.' WHERE id_guru_mapel = '1' AND id_mapel_kd = '2' AND id_siswa = '1' AND jenis = 'c'
INFO - 2023-10-05 08:01:43 --> Language file loaded: language/english/db_lang.php
INFO - 2023-10-05 08:01:46 --> Config Class Initialized
INFO - 2023-10-05 08:01:46 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:01:46 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:01:46 --> Utf8 Class Initialized
INFO - 2023-10-05 08:01:46 --> URI Class Initialized
INFO - 2023-10-05 08:01:46 --> Router Class Initialized
INFO - 2023-10-05 08:01:46 --> Output Class Initialized
INFO - 2023-10-05 08:01:46 --> Security Class Initialized
DEBUG - 2023-10-05 08:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:01:46 --> Input Class Initialized
INFO - 2023-10-05 08:01:46 --> Language Class Initialized
INFO - 2023-10-05 08:01:46 --> Language Class Initialized
INFO - 2023-10-05 08:01:46 --> Config Class Initialized
INFO - 2023-10-05 08:01:46 --> Loader Class Initialized
INFO - 2023-10-05 08:01:46 --> Helper loaded: url_helper
INFO - 2023-10-05 08:01:46 --> Helper loaded: file_helper
INFO - 2023-10-05 08:01:46 --> Helper loaded: form_helper
INFO - 2023-10-05 08:01:46 --> Helper loaded: my_helper
INFO - 2023-10-05 08:01:46 --> Database Driver Class Initialized
INFO - 2023-10-05 08:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:01:46 --> Controller Class Initialized
ERROR - 2023-10-05 08:01:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam s' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = '-', nilai_mid = 'Dalam memahami kandungan ayat tentang keutamaan menuntut ilmu dan Al-Qur'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam syamsiyah, alif lam qomariyah, nun sukun dan tasydid, kamu memiliki potensi untuk bisa memahami lebih detail. Namun, perlu lebih aktif lagi dalam mengikuti pelajaran. terutama jika ada materi yang belum bisa dipahami, kamu bisa langsung bertanya atau meminta penjelasan lebih rinci dan jelas. Aktif dan beranilah bertanya.' WHERE id_guru_mapel = '1' AND id_mapel_kd = '2' AND id_siswa = '1' AND jenis = 'c'
INFO - 2023-10-05 08:01:46 --> Language file loaded: language/english/db_lang.php
INFO - 2023-10-05 08:01:47 --> Config Class Initialized
INFO - 2023-10-05 08:01:47 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:01:47 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:01:47 --> Utf8 Class Initialized
INFO - 2023-10-05 08:01:47 --> URI Class Initialized
INFO - 2023-10-05 08:01:47 --> Router Class Initialized
INFO - 2023-10-05 08:01:47 --> Output Class Initialized
INFO - 2023-10-05 08:01:47 --> Security Class Initialized
DEBUG - 2023-10-05 08:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:01:47 --> Input Class Initialized
INFO - 2023-10-05 08:01:47 --> Language Class Initialized
INFO - 2023-10-05 08:01:47 --> Language Class Initialized
INFO - 2023-10-05 08:01:47 --> Config Class Initialized
INFO - 2023-10-05 08:01:47 --> Loader Class Initialized
INFO - 2023-10-05 08:01:47 --> Helper loaded: url_helper
INFO - 2023-10-05 08:01:47 --> Helper loaded: file_helper
INFO - 2023-10-05 08:01:47 --> Helper loaded: form_helper
INFO - 2023-10-05 08:01:47 --> Helper loaded: my_helper
INFO - 2023-10-05 08:01:47 --> Database Driver Class Initialized
INFO - 2023-10-05 08:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:01:47 --> Controller Class Initialized
ERROR - 2023-10-05 08:01:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam s' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = '-', nilai_mid = 'Dalam memahami kandungan ayat tentang keutamaan menuntut ilmu dan Al-Qur'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam syamsiyah, alif lam qomariyah, nun sukun dan tasydid, kamu memiliki potensi untuk bisa memahami lebih detail. Namun, perlu lebih aktif lagi dalam mengikuti pelajaran. terutama jika ada materi yang belum bisa dipahami, kamu bisa langsung bertanya atau meminta penjelasan lebih rinci dan jelas. Aktif dan beranilah bertanya.' WHERE id_guru_mapel = '1' AND id_mapel_kd = '2' AND id_siswa = '1' AND jenis = 'c'
INFO - 2023-10-05 08:01:47 --> Language file loaded: language/english/db_lang.php
INFO - 2023-10-05 08:01:50 --> Config Class Initialized
INFO - 2023-10-05 08:01:50 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:01:50 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:01:50 --> Utf8 Class Initialized
INFO - 2023-10-05 08:01:50 --> URI Class Initialized
INFO - 2023-10-05 08:01:50 --> Router Class Initialized
INFO - 2023-10-05 08:01:50 --> Output Class Initialized
INFO - 2023-10-05 08:01:50 --> Security Class Initialized
DEBUG - 2023-10-05 08:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:01:50 --> Input Class Initialized
INFO - 2023-10-05 08:01:50 --> Language Class Initialized
INFO - 2023-10-05 08:01:50 --> Language Class Initialized
INFO - 2023-10-05 08:01:50 --> Config Class Initialized
INFO - 2023-10-05 08:01:50 --> Loader Class Initialized
INFO - 2023-10-05 08:01:50 --> Helper loaded: url_helper
INFO - 2023-10-05 08:01:50 --> Helper loaded: file_helper
INFO - 2023-10-05 08:01:50 --> Helper loaded: form_helper
INFO - 2023-10-05 08:01:50 --> Helper loaded: my_helper
INFO - 2023-10-05 08:01:50 --> Database Driver Class Initialized
INFO - 2023-10-05 08:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:01:50 --> Controller Class Initialized
ERROR - 2023-10-05 08:01:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam s' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = '-', nilai_mid = 'Dalam memahami kandungan ayat tentang keutamaan menuntut ilmu dan Al-Qur'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam syamsiyah, alif lam qomariyah, nun sukun dan tasydid, kamu memiliki potensi untuk bisa memahami lebih detail. Namun, perlu lebih aktif lagi dalam mengikuti pelajaran. terutama jika ada materi yang belum bisa dipahami, kamu bisa langsung bertanya atau meminta penjelasan lebih rinci dan jelas. Aktif dan beranilah bertanya.' WHERE id_guru_mapel = '1' AND id_mapel_kd = '2' AND id_siswa = '1' AND jenis = 'c'
INFO - 2023-10-05 08:01:50 --> Language file loaded: language/english/db_lang.php
INFO - 2023-10-05 08:01:50 --> Config Class Initialized
INFO - 2023-10-05 08:01:50 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:01:50 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:01:50 --> Utf8 Class Initialized
INFO - 2023-10-05 08:01:50 --> URI Class Initialized
INFO - 2023-10-05 08:01:50 --> Router Class Initialized
INFO - 2023-10-05 08:01:50 --> Output Class Initialized
INFO - 2023-10-05 08:01:50 --> Security Class Initialized
DEBUG - 2023-10-05 08:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:01:50 --> Input Class Initialized
INFO - 2023-10-05 08:01:50 --> Language Class Initialized
INFO - 2023-10-05 08:01:50 --> Language Class Initialized
INFO - 2023-10-05 08:01:50 --> Config Class Initialized
INFO - 2023-10-05 08:01:50 --> Loader Class Initialized
INFO - 2023-10-05 08:01:50 --> Helper loaded: url_helper
INFO - 2023-10-05 08:01:50 --> Helper loaded: file_helper
INFO - 2023-10-05 08:01:50 --> Helper loaded: form_helper
INFO - 2023-10-05 08:01:50 --> Helper loaded: my_helper
INFO - 2023-10-05 08:01:50 --> Database Driver Class Initialized
INFO - 2023-10-05 08:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:01:50 --> Controller Class Initialized
ERROR - 2023-10-05 08:01:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam s' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = '-', nilai_mid = 'Dalam memahami kandungan ayat tentang keutamaan menuntut ilmu dan Al-Qur'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam syamsiyah, alif lam qomariyah, nun sukun dan tasydid, kamu memiliki potensi untuk bisa memahami lebih detail. Namun, perlu lebih aktif lagi dalam mengikuti pelajaran. terutama jika ada materi yang belum bisa dipahami, kamu bisa langsung bertanya atau meminta penjelasan lebih rinci dan jelas. Aktif dan beranilah bertanya.' WHERE id_guru_mapel = '1' AND id_mapel_kd = '2' AND id_siswa = '1' AND jenis = 'c'
INFO - 2023-10-05 08:01:50 --> Language file loaded: language/english/db_lang.php
INFO - 2023-10-05 08:02:00 --> Config Class Initialized
INFO - 2023-10-05 08:02:00 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:02:00 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:02:00 --> Utf8 Class Initialized
INFO - 2023-10-05 08:02:00 --> URI Class Initialized
INFO - 2023-10-05 08:02:00 --> Router Class Initialized
INFO - 2023-10-05 08:02:00 --> Output Class Initialized
INFO - 2023-10-05 08:02:00 --> Security Class Initialized
DEBUG - 2023-10-05 08:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:02:00 --> Input Class Initialized
INFO - 2023-10-05 08:02:00 --> Language Class Initialized
INFO - 2023-10-05 08:02:00 --> Language Class Initialized
INFO - 2023-10-05 08:02:00 --> Config Class Initialized
INFO - 2023-10-05 08:02:00 --> Loader Class Initialized
INFO - 2023-10-05 08:02:00 --> Helper loaded: url_helper
INFO - 2023-10-05 08:02:00 --> Helper loaded: file_helper
INFO - 2023-10-05 08:02:00 --> Helper loaded: form_helper
INFO - 2023-10-05 08:02:00 --> Helper loaded: my_helper
INFO - 2023-10-05 08:02:00 --> Database Driver Class Initialized
INFO - 2023-10-05 08:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:02:00 --> Controller Class Initialized
ERROR - 2023-10-05 08:02:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam s' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = '-', nilai_mid = 'Dalam memahami kandungan ayat tentang keutamaan menuntut ilmu dan Al-Qur'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam syamsiyah, alif lam qomariyah, nun sukun dan tasydid, kamu memiliki potensi untuk bisa memahami lebih detail. Namun, perlu lebih aktif lagi dalam mengikuti pelajaran. terutama jika ada materi yang belum bisa dipahami, kamu bisa langsung bertanya atau meminta penjelasan lebih rinci dan jelas. Aktif dan beranilah bertanya.' WHERE id_guru_mapel = '1' AND id_mapel_kd = '2' AND id_siswa = '1' AND jenis = 'c'
INFO - 2023-10-05 08:02:00 --> Language file loaded: language/english/db_lang.php
INFO - 2023-10-05 08:02:00 --> Config Class Initialized
INFO - 2023-10-05 08:02:00 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:02:00 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:02:00 --> Utf8 Class Initialized
INFO - 2023-10-05 08:02:00 --> URI Class Initialized
INFO - 2023-10-05 08:02:00 --> Router Class Initialized
INFO - 2023-10-05 08:02:00 --> Output Class Initialized
INFO - 2023-10-05 08:02:00 --> Security Class Initialized
DEBUG - 2023-10-05 08:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:02:00 --> Input Class Initialized
INFO - 2023-10-05 08:02:00 --> Language Class Initialized
INFO - 2023-10-05 08:02:00 --> Language Class Initialized
INFO - 2023-10-05 08:02:00 --> Config Class Initialized
INFO - 2023-10-05 08:02:00 --> Loader Class Initialized
INFO - 2023-10-05 08:02:00 --> Helper loaded: url_helper
INFO - 2023-10-05 08:02:00 --> Helper loaded: file_helper
INFO - 2023-10-05 08:02:00 --> Helper loaded: form_helper
INFO - 2023-10-05 08:02:00 --> Helper loaded: my_helper
INFO - 2023-10-05 08:02:00 --> Database Driver Class Initialized
INFO - 2023-10-05 08:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:02:00 --> Controller Class Initialized
ERROR - 2023-10-05 08:02:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam s' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = '-', nilai_mid = 'Dalam memahami kandungan ayat tentang keutamaan menuntut ilmu dan Al-Qur'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam syamsiyah, alif lam qomariyah, nun sukun dan tasydid, kamu memiliki potensi untuk bisa memahami lebih detail. Namun, perlu lebih aktif lagi dalam mengikuti pelajaran. terutama jika ada materi yang belum bisa dipahami, kamu bisa langsung bertanya atau meminta penjelasan lebih rinci dan jelas. Aktif dan beranilah bertanya.' WHERE id_guru_mapel = '1' AND id_mapel_kd = '2' AND id_siswa = '1' AND jenis = 'c'
INFO - 2023-10-05 08:02:00 --> Language file loaded: language/english/db_lang.php
INFO - 2023-10-05 08:02:01 --> Config Class Initialized
INFO - 2023-10-05 08:02:01 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:02:01 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:02:01 --> Utf8 Class Initialized
INFO - 2023-10-05 08:02:01 --> URI Class Initialized
INFO - 2023-10-05 08:02:01 --> Router Class Initialized
INFO - 2023-10-05 08:02:01 --> Output Class Initialized
INFO - 2023-10-05 08:02:01 --> Security Class Initialized
DEBUG - 2023-10-05 08:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:02:01 --> Input Class Initialized
INFO - 2023-10-05 08:02:01 --> Language Class Initialized
INFO - 2023-10-05 08:02:01 --> Language Class Initialized
INFO - 2023-10-05 08:02:01 --> Config Class Initialized
INFO - 2023-10-05 08:02:01 --> Loader Class Initialized
INFO - 2023-10-05 08:02:01 --> Helper loaded: url_helper
INFO - 2023-10-05 08:02:01 --> Helper loaded: file_helper
INFO - 2023-10-05 08:02:01 --> Helper loaded: form_helper
INFO - 2023-10-05 08:02:01 --> Helper loaded: my_helper
INFO - 2023-10-05 08:02:01 --> Database Driver Class Initialized
INFO - 2023-10-05 08:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:02:01 --> Controller Class Initialized
ERROR - 2023-10-05 08:02:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam s' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = '-', nilai_mid = 'Dalam memahami kandungan ayat tentang keutamaan menuntut ilmu dan Al-Qur'an sebagai sumber hukum, serta mengidentifikasi kaidah-kaidah tajwid; alif lam syamsiyah, alif lam qomariyah, nun sukun dan tasydid, kamu memiliki potensi untuk bisa memahami lebih detail. Namun, perlu lebih aktif lagi dalam mengikuti pelajaran. terutama jika ada materi yang belum bisa dipahami, kamu bisa langsung bertanya atau meminta penjelasan lebih rinci dan jelas. Aktif dan beranilah bertanya.' WHERE id_guru_mapel = '1' AND id_mapel_kd = '2' AND id_siswa = '1' AND jenis = 'c'
INFO - 2023-10-05 08:02:01 --> Language file loaded: language/english/db_lang.php
INFO - 2023-10-05 08:02:13 --> Config Class Initialized
INFO - 2023-10-05 08:02:13 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:02:13 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:02:13 --> Utf8 Class Initialized
INFO - 2023-10-05 08:02:13 --> URI Class Initialized
INFO - 2023-10-05 08:02:13 --> Router Class Initialized
INFO - 2023-10-05 08:02:13 --> Output Class Initialized
INFO - 2023-10-05 08:02:13 --> Security Class Initialized
DEBUG - 2023-10-05 08:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:02:13 --> Input Class Initialized
INFO - 2023-10-05 08:02:13 --> Language Class Initialized
INFO - 2023-10-05 08:02:13 --> Language Class Initialized
INFO - 2023-10-05 08:02:13 --> Config Class Initialized
INFO - 2023-10-05 08:02:13 --> Loader Class Initialized
INFO - 2023-10-05 08:02:13 --> Helper loaded: url_helper
INFO - 2023-10-05 08:02:13 --> Helper loaded: file_helper
INFO - 2023-10-05 08:02:13 --> Helper loaded: form_helper
INFO - 2023-10-05 08:02:13 --> Helper loaded: my_helper
INFO - 2023-10-05 08:02:13 --> Database Driver Class Initialized
INFO - 2023-10-05 08:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:02:13 --> Controller Class Initialized
DEBUG - 2023-10-05 08:02:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2023-10-05 08:02:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 08:02:13 --> Final output sent to browser
DEBUG - 2023-10-05 08:02:13 --> Total execution time: 0.0396
INFO - 2023-10-05 08:02:51 --> Config Class Initialized
INFO - 2023-10-05 08:02:51 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:02:51 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:02:51 --> Utf8 Class Initialized
INFO - 2023-10-05 08:02:51 --> URI Class Initialized
INFO - 2023-10-05 08:02:51 --> Router Class Initialized
INFO - 2023-10-05 08:02:51 --> Output Class Initialized
INFO - 2023-10-05 08:02:51 --> Security Class Initialized
DEBUG - 2023-10-05 08:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:02:51 --> Input Class Initialized
INFO - 2023-10-05 08:02:51 --> Language Class Initialized
INFO - 2023-10-05 08:02:51 --> Language Class Initialized
INFO - 2023-10-05 08:02:51 --> Config Class Initialized
INFO - 2023-10-05 08:02:51 --> Loader Class Initialized
INFO - 2023-10-05 08:02:51 --> Helper loaded: url_helper
INFO - 2023-10-05 08:02:51 --> Helper loaded: file_helper
INFO - 2023-10-05 08:02:51 --> Helper loaded: form_helper
INFO - 2023-10-05 08:02:51 --> Helper loaded: my_helper
INFO - 2023-10-05 08:02:51 --> Database Driver Class Initialized
INFO - 2023-10-05 08:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:02:51 --> Controller Class Initialized
DEBUG - 2023-10-05 08:02:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-10-05 08:02:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 08:02:51 --> Final output sent to browser
DEBUG - 2023-10-05 08:02:51 --> Total execution time: 0.1676
INFO - 2023-10-05 08:04:34 --> Config Class Initialized
INFO - 2023-10-05 08:04:34 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:04:34 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:04:34 --> Utf8 Class Initialized
INFO - 2023-10-05 08:04:34 --> URI Class Initialized
INFO - 2023-10-05 08:04:34 --> Router Class Initialized
INFO - 2023-10-05 08:04:34 --> Output Class Initialized
INFO - 2023-10-05 08:04:34 --> Security Class Initialized
DEBUG - 2023-10-05 08:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:04:34 --> Input Class Initialized
INFO - 2023-10-05 08:04:34 --> Language Class Initialized
INFO - 2023-10-05 08:04:34 --> Language Class Initialized
INFO - 2023-10-05 08:04:34 --> Config Class Initialized
INFO - 2023-10-05 08:04:34 --> Loader Class Initialized
INFO - 2023-10-05 08:04:34 --> Helper loaded: url_helper
INFO - 2023-10-05 08:04:34 --> Helper loaded: file_helper
INFO - 2023-10-05 08:04:34 --> Helper loaded: form_helper
INFO - 2023-10-05 08:04:34 --> Helper loaded: my_helper
INFO - 2023-10-05 08:04:34 --> Database Driver Class Initialized
INFO - 2023-10-05 08:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:04:34 --> Controller Class Initialized
DEBUG - 2023-10-05 08:04:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2023-10-05 08:04:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 08:04:34 --> Final output sent to browser
DEBUG - 2023-10-05 08:04:34 --> Total execution time: 0.3005
INFO - 2023-10-05 08:04:39 --> Config Class Initialized
INFO - 2023-10-05 08:04:39 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:04:39 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:04:39 --> Utf8 Class Initialized
INFO - 2023-10-05 08:04:39 --> URI Class Initialized
INFO - 2023-10-05 08:04:39 --> Router Class Initialized
INFO - 2023-10-05 08:04:39 --> Output Class Initialized
INFO - 2023-10-05 08:04:39 --> Security Class Initialized
DEBUG - 2023-10-05 08:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:04:39 --> Input Class Initialized
INFO - 2023-10-05 08:04:39 --> Language Class Initialized
INFO - 2023-10-05 08:04:39 --> Language Class Initialized
INFO - 2023-10-05 08:04:39 --> Config Class Initialized
INFO - 2023-10-05 08:04:39 --> Loader Class Initialized
INFO - 2023-10-05 08:04:39 --> Helper loaded: url_helper
INFO - 2023-10-05 08:04:39 --> Helper loaded: file_helper
INFO - 2023-10-05 08:04:39 --> Helper loaded: form_helper
INFO - 2023-10-05 08:04:39 --> Helper loaded: my_helper
INFO - 2023-10-05 08:04:39 --> Database Driver Class Initialized
INFO - 2023-10-05 08:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:04:39 --> Controller Class Initialized
DEBUG - 2023-10-05 08:04:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 08:04:45 --> Final output sent to browser
DEBUG - 2023-10-05 08:04:45 --> Total execution time: 5.7765
INFO - 2023-10-05 08:06:37 --> Config Class Initialized
INFO - 2023-10-05 08:06:37 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:06:37 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:06:37 --> Utf8 Class Initialized
INFO - 2023-10-05 08:06:37 --> URI Class Initialized
INFO - 2023-10-05 08:06:37 --> Router Class Initialized
INFO - 2023-10-05 08:06:37 --> Output Class Initialized
INFO - 2023-10-05 08:06:37 --> Security Class Initialized
DEBUG - 2023-10-05 08:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:06:37 --> Input Class Initialized
INFO - 2023-10-05 08:06:37 --> Language Class Initialized
INFO - 2023-10-05 08:06:37 --> Language Class Initialized
INFO - 2023-10-05 08:06:37 --> Config Class Initialized
INFO - 2023-10-05 08:06:37 --> Loader Class Initialized
INFO - 2023-10-05 08:06:37 --> Helper loaded: url_helper
INFO - 2023-10-05 08:06:37 --> Helper loaded: file_helper
INFO - 2023-10-05 08:06:37 --> Helper loaded: form_helper
INFO - 2023-10-05 08:06:37 --> Helper loaded: my_helper
INFO - 2023-10-05 08:06:37 --> Database Driver Class Initialized
INFO - 2023-10-05 08:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:06:37 --> Controller Class Initialized
DEBUG - 2023-10-05 08:06:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2023-10-05 08:06:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 08:06:37 --> Final output sent to browser
DEBUG - 2023-10-05 08:06:37 --> Total execution time: 0.1029
INFO - 2023-10-05 08:06:44 --> Config Class Initialized
INFO - 2023-10-05 08:06:44 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:06:44 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:06:44 --> Utf8 Class Initialized
INFO - 2023-10-05 08:06:44 --> URI Class Initialized
INFO - 2023-10-05 08:06:44 --> Router Class Initialized
INFO - 2023-10-05 08:06:44 --> Output Class Initialized
INFO - 2023-10-05 08:06:44 --> Security Class Initialized
DEBUG - 2023-10-05 08:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:06:44 --> Input Class Initialized
INFO - 2023-10-05 08:06:44 --> Language Class Initialized
INFO - 2023-10-05 08:06:44 --> Language Class Initialized
INFO - 2023-10-05 08:06:44 --> Config Class Initialized
INFO - 2023-10-05 08:06:44 --> Loader Class Initialized
INFO - 2023-10-05 08:06:44 --> Helper loaded: url_helper
INFO - 2023-10-05 08:06:44 --> Helper loaded: file_helper
INFO - 2023-10-05 08:06:44 --> Helper loaded: form_helper
INFO - 2023-10-05 08:06:44 --> Helper loaded: my_helper
INFO - 2023-10-05 08:06:44 --> Database Driver Class Initialized
INFO - 2023-10-05 08:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:06:44 --> Controller Class Initialized
INFO - 2023-10-05 08:06:44 --> Config Class Initialized
INFO - 2023-10-05 08:06:44 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:06:44 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:06:44 --> Utf8 Class Initialized
INFO - 2023-10-05 08:06:44 --> URI Class Initialized
INFO - 2023-10-05 08:06:44 --> Router Class Initialized
INFO - 2023-10-05 08:06:44 --> Output Class Initialized
INFO - 2023-10-05 08:06:44 --> Security Class Initialized
DEBUG - 2023-10-05 08:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:06:44 --> Input Class Initialized
INFO - 2023-10-05 08:06:44 --> Language Class Initialized
INFO - 2023-10-05 08:06:44 --> Language Class Initialized
INFO - 2023-10-05 08:06:44 --> Config Class Initialized
INFO - 2023-10-05 08:06:44 --> Loader Class Initialized
INFO - 2023-10-05 08:06:44 --> Helper loaded: url_helper
INFO - 2023-10-05 08:06:44 --> Helper loaded: file_helper
INFO - 2023-10-05 08:06:44 --> Helper loaded: form_helper
INFO - 2023-10-05 08:06:44 --> Helper loaded: my_helper
INFO - 2023-10-05 08:06:44 --> Database Driver Class Initialized
INFO - 2023-10-05 08:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:06:44 --> Controller Class Initialized
DEBUG - 2023-10-05 08:06:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-10-05 08:06:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 08:06:44 --> Final output sent to browser
DEBUG - 2023-10-05 08:06:44 --> Total execution time: 0.0343
INFO - 2023-10-05 08:06:49 --> Config Class Initialized
INFO - 2023-10-05 08:06:49 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:06:49 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:06:49 --> Utf8 Class Initialized
INFO - 2023-10-05 08:06:49 --> URI Class Initialized
INFO - 2023-10-05 08:06:49 --> Router Class Initialized
INFO - 2023-10-05 08:06:49 --> Output Class Initialized
INFO - 2023-10-05 08:06:49 --> Security Class Initialized
DEBUG - 2023-10-05 08:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:06:49 --> Input Class Initialized
INFO - 2023-10-05 08:06:49 --> Language Class Initialized
INFO - 2023-10-05 08:06:49 --> Language Class Initialized
INFO - 2023-10-05 08:06:49 --> Config Class Initialized
INFO - 2023-10-05 08:06:49 --> Loader Class Initialized
INFO - 2023-10-05 08:06:49 --> Helper loaded: url_helper
INFO - 2023-10-05 08:06:49 --> Helper loaded: file_helper
INFO - 2023-10-05 08:06:49 --> Helper loaded: form_helper
INFO - 2023-10-05 08:06:49 --> Helper loaded: my_helper
INFO - 2023-10-05 08:06:49 --> Database Driver Class Initialized
INFO - 2023-10-05 08:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:06:49 --> Controller Class Initialized
INFO - 2023-10-05 08:06:49 --> Final output sent to browser
DEBUG - 2023-10-05 08:06:49 --> Total execution time: 0.0760
INFO - 2023-10-05 08:06:55 --> Config Class Initialized
INFO - 2023-10-05 08:06:55 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:06:55 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:06:55 --> Utf8 Class Initialized
INFO - 2023-10-05 08:06:55 --> URI Class Initialized
INFO - 2023-10-05 08:06:55 --> Router Class Initialized
INFO - 2023-10-05 08:06:55 --> Output Class Initialized
INFO - 2023-10-05 08:06:55 --> Security Class Initialized
DEBUG - 2023-10-05 08:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:06:55 --> Input Class Initialized
INFO - 2023-10-05 08:06:55 --> Language Class Initialized
INFO - 2023-10-05 08:06:55 --> Language Class Initialized
INFO - 2023-10-05 08:06:55 --> Config Class Initialized
INFO - 2023-10-05 08:06:55 --> Loader Class Initialized
INFO - 2023-10-05 08:06:55 --> Helper loaded: url_helper
INFO - 2023-10-05 08:06:55 --> Helper loaded: file_helper
INFO - 2023-10-05 08:06:55 --> Helper loaded: form_helper
INFO - 2023-10-05 08:06:55 --> Helper loaded: my_helper
INFO - 2023-10-05 08:06:55 --> Database Driver Class Initialized
INFO - 2023-10-05 08:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:06:55 --> Controller Class Initialized
DEBUG - 2023-10-05 08:06:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-10-05 08:06:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 08:06:55 --> Final output sent to browser
DEBUG - 2023-10-05 08:06:55 --> Total execution time: 0.0324
INFO - 2023-10-05 08:06:58 --> Config Class Initialized
INFO - 2023-10-05 08:06:58 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:06:58 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:06:58 --> Utf8 Class Initialized
INFO - 2023-10-05 08:06:58 --> URI Class Initialized
INFO - 2023-10-05 08:06:58 --> Router Class Initialized
INFO - 2023-10-05 08:06:58 --> Output Class Initialized
INFO - 2023-10-05 08:06:58 --> Security Class Initialized
DEBUG - 2023-10-05 08:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:06:58 --> Input Class Initialized
INFO - 2023-10-05 08:06:58 --> Language Class Initialized
INFO - 2023-10-05 08:06:58 --> Language Class Initialized
INFO - 2023-10-05 08:06:58 --> Config Class Initialized
INFO - 2023-10-05 08:06:58 --> Loader Class Initialized
INFO - 2023-10-05 08:06:58 --> Helper loaded: url_helper
INFO - 2023-10-05 08:06:58 --> Helper loaded: file_helper
INFO - 2023-10-05 08:06:58 --> Helper loaded: form_helper
INFO - 2023-10-05 08:06:58 --> Helper loaded: my_helper
INFO - 2023-10-05 08:06:58 --> Database Driver Class Initialized
INFO - 2023-10-05 08:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:06:58 --> Controller Class Initialized
DEBUG - 2023-10-05 08:06:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-10-05 08:06:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 08:06:58 --> Final output sent to browser
DEBUG - 2023-10-05 08:06:58 --> Total execution time: 0.0791
INFO - 2023-10-05 08:07:01 --> Config Class Initialized
INFO - 2023-10-05 08:07:01 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:07:01 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:07:01 --> Utf8 Class Initialized
INFO - 2023-10-05 08:07:01 --> URI Class Initialized
INFO - 2023-10-05 08:07:01 --> Router Class Initialized
INFO - 2023-10-05 08:07:01 --> Output Class Initialized
INFO - 2023-10-05 08:07:01 --> Security Class Initialized
DEBUG - 2023-10-05 08:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:07:01 --> Input Class Initialized
INFO - 2023-10-05 08:07:01 --> Language Class Initialized
INFO - 2023-10-05 08:07:01 --> Language Class Initialized
INFO - 2023-10-05 08:07:01 --> Config Class Initialized
INFO - 2023-10-05 08:07:01 --> Loader Class Initialized
INFO - 2023-10-05 08:07:01 --> Helper loaded: url_helper
INFO - 2023-10-05 08:07:01 --> Helper loaded: file_helper
INFO - 2023-10-05 08:07:01 --> Helper loaded: form_helper
INFO - 2023-10-05 08:07:01 --> Helper loaded: my_helper
INFO - 2023-10-05 08:07:01 --> Database Driver Class Initialized
INFO - 2023-10-05 08:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:07:01 --> Controller Class Initialized
DEBUG - 2023-10-05 08:07:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-10-05 08:07:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 08:07:01 --> Final output sent to browser
DEBUG - 2023-10-05 08:07:01 --> Total execution time: 0.0430
INFO - 2023-10-05 08:07:01 --> Config Class Initialized
INFO - 2023-10-05 08:07:01 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:07:01 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:07:01 --> Utf8 Class Initialized
INFO - 2023-10-05 08:07:01 --> URI Class Initialized
INFO - 2023-10-05 08:07:01 --> Router Class Initialized
INFO - 2023-10-05 08:07:01 --> Output Class Initialized
INFO - 2023-10-05 08:07:01 --> Security Class Initialized
DEBUG - 2023-10-05 08:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:07:01 --> Input Class Initialized
INFO - 2023-10-05 08:07:01 --> Language Class Initialized
INFO - 2023-10-05 08:07:01 --> Language Class Initialized
INFO - 2023-10-05 08:07:01 --> Config Class Initialized
INFO - 2023-10-05 08:07:01 --> Loader Class Initialized
INFO - 2023-10-05 08:07:01 --> Helper loaded: url_helper
INFO - 2023-10-05 08:07:01 --> Helper loaded: file_helper
INFO - 2023-10-05 08:07:01 --> Helper loaded: form_helper
INFO - 2023-10-05 08:07:01 --> Helper loaded: my_helper
INFO - 2023-10-05 08:07:01 --> Database Driver Class Initialized
INFO - 2023-10-05 08:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:07:01 --> Controller Class Initialized
DEBUG - 2023-10-05 08:07:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2023-10-05 08:07:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 08:07:01 --> Final output sent to browser
DEBUG - 2023-10-05 08:07:01 --> Total execution time: 0.2106
INFO - 2023-10-05 08:07:02 --> Config Class Initialized
INFO - 2023-10-05 08:07:02 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:07:02 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:07:02 --> Utf8 Class Initialized
INFO - 2023-10-05 08:07:02 --> URI Class Initialized
INFO - 2023-10-05 08:07:02 --> Router Class Initialized
INFO - 2023-10-05 08:07:02 --> Output Class Initialized
INFO - 2023-10-05 08:07:02 --> Security Class Initialized
DEBUG - 2023-10-05 08:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:07:02 --> Input Class Initialized
INFO - 2023-10-05 08:07:02 --> Language Class Initialized
INFO - 2023-10-05 08:07:02 --> Language Class Initialized
INFO - 2023-10-05 08:07:02 --> Config Class Initialized
INFO - 2023-10-05 08:07:02 --> Loader Class Initialized
INFO - 2023-10-05 08:07:02 --> Helper loaded: url_helper
INFO - 2023-10-05 08:07:02 --> Helper loaded: file_helper
INFO - 2023-10-05 08:07:02 --> Helper loaded: form_helper
INFO - 2023-10-05 08:07:02 --> Helper loaded: my_helper
INFO - 2023-10-05 08:07:02 --> Database Driver Class Initialized
INFO - 2023-10-05 08:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:07:02 --> Controller Class Initialized
DEBUG - 2023-10-05 08:07:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-10-05 08:07:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 08:07:02 --> Final output sent to browser
DEBUG - 2023-10-05 08:07:02 --> Total execution time: 0.1052
INFO - 2023-10-05 08:07:04 --> Config Class Initialized
INFO - 2023-10-05 08:07:04 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:07:04 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:07:04 --> Utf8 Class Initialized
INFO - 2023-10-05 08:07:04 --> URI Class Initialized
INFO - 2023-10-05 08:07:04 --> Router Class Initialized
INFO - 2023-10-05 08:07:04 --> Output Class Initialized
INFO - 2023-10-05 08:07:04 --> Security Class Initialized
DEBUG - 2023-10-05 08:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:07:04 --> Input Class Initialized
INFO - 2023-10-05 08:07:04 --> Language Class Initialized
INFO - 2023-10-05 08:07:04 --> Language Class Initialized
INFO - 2023-10-05 08:07:04 --> Config Class Initialized
INFO - 2023-10-05 08:07:04 --> Loader Class Initialized
INFO - 2023-10-05 08:07:04 --> Helper loaded: url_helper
INFO - 2023-10-05 08:07:04 --> Helper loaded: file_helper
INFO - 2023-10-05 08:07:04 --> Helper loaded: form_helper
INFO - 2023-10-05 08:07:04 --> Helper loaded: my_helper
INFO - 2023-10-05 08:07:04 --> Database Driver Class Initialized
INFO - 2023-10-05 08:07:04 --> Config Class Initialized
INFO - 2023-10-05 08:07:04 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:07:04 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:07:04 --> Utf8 Class Initialized
INFO - 2023-10-05 08:07:04 --> URI Class Initialized
INFO - 2023-10-05 08:07:04 --> Router Class Initialized
INFO - 2023-10-05 08:07:04 --> Output Class Initialized
INFO - 2023-10-05 08:07:04 --> Security Class Initialized
DEBUG - 2023-10-05 08:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:07:04 --> Input Class Initialized
INFO - 2023-10-05 08:07:04 --> Language Class Initialized
INFO - 2023-10-05 08:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:07:04 --> Controller Class Initialized
INFO - 2023-10-05 08:07:04 --> Language Class Initialized
INFO - 2023-10-05 08:07:04 --> Config Class Initialized
INFO - 2023-10-05 08:07:04 --> Loader Class Initialized
INFO - 2023-10-05 08:07:04 --> Helper loaded: url_helper
INFO - 2023-10-05 08:07:04 --> Helper loaded: file_helper
INFO - 2023-10-05 08:07:04 --> Helper loaded: form_helper
INFO - 2023-10-05 08:07:04 --> Helper loaded: my_helper
DEBUG - 2023-10-05 08:07:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 08:07:04 --> Database Driver Class Initialized
INFO - 2023-10-05 08:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:07:04 --> Controller Class Initialized
INFO - 2023-10-05 08:07:04 --> Final output sent to browser
DEBUG - 2023-10-05 08:07:04 --> Total execution time: 0.1798
INFO - 2023-10-05 08:07:08 --> Final output sent to browser
DEBUG - 2023-10-05 08:07:08 --> Total execution time: 4.3987
INFO - 2023-10-05 08:08:05 --> Config Class Initialized
INFO - 2023-10-05 08:08:05 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:08:05 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:08:05 --> Utf8 Class Initialized
INFO - 2023-10-05 08:08:05 --> URI Class Initialized
INFO - 2023-10-05 08:08:05 --> Router Class Initialized
INFO - 2023-10-05 08:08:05 --> Output Class Initialized
INFO - 2023-10-05 08:08:05 --> Security Class Initialized
DEBUG - 2023-10-05 08:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:08:05 --> Input Class Initialized
INFO - 2023-10-05 08:08:05 --> Language Class Initialized
INFO - 2023-10-05 08:08:05 --> Language Class Initialized
INFO - 2023-10-05 08:08:05 --> Config Class Initialized
INFO - 2023-10-05 08:08:05 --> Loader Class Initialized
INFO - 2023-10-05 08:08:05 --> Helper loaded: url_helper
INFO - 2023-10-05 08:08:05 --> Helper loaded: file_helper
INFO - 2023-10-05 08:08:05 --> Helper loaded: form_helper
INFO - 2023-10-05 08:08:05 --> Helper loaded: my_helper
INFO - 2023-10-05 08:08:05 --> Database Driver Class Initialized
INFO - 2023-10-05 08:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:08:05 --> Controller Class Initialized
DEBUG - 2023-10-05 08:08:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 08:08:10 --> Final output sent to browser
DEBUG - 2023-10-05 08:08:10 --> Total execution time: 4.4127
INFO - 2023-10-05 08:09:52 --> Config Class Initialized
INFO - 2023-10-05 08:09:52 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:09:52 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:09:52 --> Utf8 Class Initialized
INFO - 2023-10-05 08:09:52 --> URI Class Initialized
INFO - 2023-10-05 08:09:52 --> Router Class Initialized
INFO - 2023-10-05 08:09:52 --> Output Class Initialized
INFO - 2023-10-05 08:09:52 --> Security Class Initialized
DEBUG - 2023-10-05 08:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:09:52 --> Input Class Initialized
INFO - 2023-10-05 08:09:52 --> Language Class Initialized
INFO - 2023-10-05 08:09:52 --> Language Class Initialized
INFO - 2023-10-05 08:09:52 --> Config Class Initialized
INFO - 2023-10-05 08:09:52 --> Loader Class Initialized
INFO - 2023-10-05 08:09:52 --> Helper loaded: url_helper
INFO - 2023-10-05 08:09:52 --> Helper loaded: file_helper
INFO - 2023-10-05 08:09:52 --> Helper loaded: form_helper
INFO - 2023-10-05 08:09:52 --> Helper loaded: my_helper
INFO - 2023-10-05 08:09:52 --> Database Driver Class Initialized
INFO - 2023-10-05 08:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:09:52 --> Controller Class Initialized
DEBUG - 2023-10-05 08:09:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 08:09:56 --> Final output sent to browser
DEBUG - 2023-10-05 08:09:56 --> Total execution time: 4.4951
INFO - 2023-10-05 08:10:27 --> Config Class Initialized
INFO - 2023-10-05 08:10:27 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:10:27 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:10:27 --> Utf8 Class Initialized
INFO - 2023-10-05 08:10:27 --> URI Class Initialized
INFO - 2023-10-05 08:10:27 --> Router Class Initialized
INFO - 2023-10-05 08:10:27 --> Output Class Initialized
INFO - 2023-10-05 08:10:27 --> Security Class Initialized
DEBUG - 2023-10-05 08:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:10:27 --> Input Class Initialized
INFO - 2023-10-05 08:10:27 --> Language Class Initialized
INFO - 2023-10-05 08:10:27 --> Language Class Initialized
INFO - 2023-10-05 08:10:27 --> Config Class Initialized
INFO - 2023-10-05 08:10:27 --> Loader Class Initialized
INFO - 2023-10-05 08:10:27 --> Helper loaded: url_helper
INFO - 2023-10-05 08:10:27 --> Helper loaded: file_helper
INFO - 2023-10-05 08:10:27 --> Helper loaded: form_helper
INFO - 2023-10-05 08:10:27 --> Helper loaded: my_helper
INFO - 2023-10-05 08:10:27 --> Database Driver Class Initialized
INFO - 2023-10-05 08:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:10:27 --> Controller Class Initialized
DEBUG - 2023-10-05 08:10:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 08:10:32 --> Final output sent to browser
DEBUG - 2023-10-05 08:10:32 --> Total execution time: 5.3005
INFO - 2023-10-05 08:10:53 --> Config Class Initialized
INFO - 2023-10-05 08:10:53 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:10:53 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:10:53 --> Utf8 Class Initialized
INFO - 2023-10-05 08:10:53 --> URI Class Initialized
INFO - 2023-10-05 08:10:53 --> Router Class Initialized
INFO - 2023-10-05 08:10:53 --> Output Class Initialized
INFO - 2023-10-05 08:10:53 --> Security Class Initialized
DEBUG - 2023-10-05 08:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:10:53 --> Input Class Initialized
INFO - 2023-10-05 08:10:53 --> Language Class Initialized
INFO - 2023-10-05 08:10:53 --> Language Class Initialized
INFO - 2023-10-05 08:10:53 --> Config Class Initialized
INFO - 2023-10-05 08:10:53 --> Loader Class Initialized
INFO - 2023-10-05 08:10:53 --> Helper loaded: url_helper
INFO - 2023-10-05 08:10:53 --> Helper loaded: file_helper
INFO - 2023-10-05 08:10:53 --> Helper loaded: form_helper
INFO - 2023-10-05 08:10:53 --> Helper loaded: my_helper
INFO - 2023-10-05 08:10:53 --> Database Driver Class Initialized
INFO - 2023-10-05 08:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:10:53 --> Controller Class Initialized
DEBUG - 2023-10-05 08:10:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 08:10:58 --> Final output sent to browser
DEBUG - 2023-10-05 08:10:58 --> Total execution time: 5.0069
INFO - 2023-10-05 08:11:47 --> Config Class Initialized
INFO - 2023-10-05 08:11:47 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:11:47 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:11:47 --> Utf8 Class Initialized
INFO - 2023-10-05 08:11:47 --> URI Class Initialized
INFO - 2023-10-05 08:11:47 --> Router Class Initialized
INFO - 2023-10-05 08:11:47 --> Output Class Initialized
INFO - 2023-10-05 08:11:47 --> Security Class Initialized
DEBUG - 2023-10-05 08:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:11:47 --> Input Class Initialized
INFO - 2023-10-05 08:11:47 --> Language Class Initialized
INFO - 2023-10-05 08:11:47 --> Language Class Initialized
INFO - 2023-10-05 08:11:47 --> Config Class Initialized
INFO - 2023-10-05 08:11:47 --> Loader Class Initialized
INFO - 2023-10-05 08:11:47 --> Helper loaded: url_helper
INFO - 2023-10-05 08:11:47 --> Helper loaded: file_helper
INFO - 2023-10-05 08:11:47 --> Helper loaded: form_helper
INFO - 2023-10-05 08:11:47 --> Helper loaded: my_helper
INFO - 2023-10-05 08:11:47 --> Database Driver Class Initialized
INFO - 2023-10-05 08:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:11:47 --> Controller Class Initialized
DEBUG - 2023-10-05 08:11:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 08:11:54 --> Final output sent to browser
DEBUG - 2023-10-05 08:11:54 --> Total execution time: 7.6104
INFO - 2023-10-05 08:13:25 --> Config Class Initialized
INFO - 2023-10-05 08:13:25 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:13:25 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:13:25 --> Utf8 Class Initialized
INFO - 2023-10-05 08:13:25 --> URI Class Initialized
INFO - 2023-10-05 08:13:25 --> Router Class Initialized
INFO - 2023-10-05 08:13:25 --> Output Class Initialized
INFO - 2023-10-05 08:13:25 --> Security Class Initialized
DEBUG - 2023-10-05 08:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:13:25 --> Input Class Initialized
INFO - 2023-10-05 08:13:25 --> Language Class Initialized
INFO - 2023-10-05 08:13:25 --> Language Class Initialized
INFO - 2023-10-05 08:13:25 --> Config Class Initialized
INFO - 2023-10-05 08:13:25 --> Loader Class Initialized
INFO - 2023-10-05 08:13:25 --> Helper loaded: url_helper
INFO - 2023-10-05 08:13:25 --> Helper loaded: file_helper
INFO - 2023-10-05 08:13:25 --> Helper loaded: form_helper
INFO - 2023-10-05 08:13:25 --> Helper loaded: my_helper
INFO - 2023-10-05 08:13:25 --> Database Driver Class Initialized
INFO - 2023-10-05 08:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:13:25 --> Controller Class Initialized
DEBUG - 2023-10-05 08:13:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 08:13:29 --> Final output sent to browser
DEBUG - 2023-10-05 08:13:29 --> Total execution time: 4.2171
INFO - 2023-10-05 08:13:55 --> Config Class Initialized
INFO - 2023-10-05 08:13:55 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:13:55 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:13:55 --> Utf8 Class Initialized
INFO - 2023-10-05 08:13:55 --> URI Class Initialized
INFO - 2023-10-05 08:13:55 --> Router Class Initialized
INFO - 2023-10-05 08:13:55 --> Output Class Initialized
INFO - 2023-10-05 08:13:55 --> Security Class Initialized
DEBUG - 2023-10-05 08:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:13:55 --> Input Class Initialized
INFO - 2023-10-05 08:13:55 --> Language Class Initialized
INFO - 2023-10-05 08:13:55 --> Language Class Initialized
INFO - 2023-10-05 08:13:55 --> Config Class Initialized
INFO - 2023-10-05 08:13:55 --> Loader Class Initialized
INFO - 2023-10-05 08:13:55 --> Helper loaded: url_helper
INFO - 2023-10-05 08:13:55 --> Helper loaded: file_helper
INFO - 2023-10-05 08:13:55 --> Helper loaded: form_helper
INFO - 2023-10-05 08:13:55 --> Helper loaded: my_helper
INFO - 2023-10-05 08:13:55 --> Database Driver Class Initialized
INFO - 2023-10-05 08:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:13:55 --> Controller Class Initialized
DEBUG - 2023-10-05 08:13:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 08:14:02 --> Final output sent to browser
DEBUG - 2023-10-05 08:14:02 --> Total execution time: 7.0329
INFO - 2023-10-05 08:14:21 --> Config Class Initialized
INFO - 2023-10-05 08:14:21 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:14:21 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:14:21 --> Utf8 Class Initialized
INFO - 2023-10-05 08:14:21 --> URI Class Initialized
INFO - 2023-10-05 08:14:21 --> Router Class Initialized
INFO - 2023-10-05 08:14:21 --> Output Class Initialized
INFO - 2023-10-05 08:14:21 --> Security Class Initialized
DEBUG - 2023-10-05 08:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:14:21 --> Input Class Initialized
INFO - 2023-10-05 08:14:21 --> Language Class Initialized
INFO - 2023-10-05 08:14:21 --> Language Class Initialized
INFO - 2023-10-05 08:14:21 --> Config Class Initialized
INFO - 2023-10-05 08:14:21 --> Loader Class Initialized
INFO - 2023-10-05 08:14:21 --> Helper loaded: url_helper
INFO - 2023-10-05 08:14:21 --> Helper loaded: file_helper
INFO - 2023-10-05 08:14:21 --> Helper loaded: form_helper
INFO - 2023-10-05 08:14:21 --> Helper loaded: my_helper
INFO - 2023-10-05 08:14:21 --> Database Driver Class Initialized
INFO - 2023-10-05 08:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:14:22 --> Controller Class Initialized
DEBUG - 2023-10-05 08:14:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 08:14:26 --> Final output sent to browser
DEBUG - 2023-10-05 08:14:26 --> Total execution time: 4.4714
INFO - 2023-10-05 08:14:50 --> Config Class Initialized
INFO - 2023-10-05 08:14:50 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:14:50 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:14:50 --> Utf8 Class Initialized
INFO - 2023-10-05 08:14:50 --> URI Class Initialized
INFO - 2023-10-05 08:14:50 --> Router Class Initialized
INFO - 2023-10-05 08:14:50 --> Output Class Initialized
INFO - 2023-10-05 08:14:50 --> Security Class Initialized
DEBUG - 2023-10-05 08:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:14:50 --> Input Class Initialized
INFO - 2023-10-05 08:14:50 --> Language Class Initialized
INFO - 2023-10-05 08:14:50 --> Language Class Initialized
INFO - 2023-10-05 08:14:50 --> Config Class Initialized
INFO - 2023-10-05 08:14:50 --> Loader Class Initialized
INFO - 2023-10-05 08:14:50 --> Helper loaded: url_helper
INFO - 2023-10-05 08:14:50 --> Helper loaded: file_helper
INFO - 2023-10-05 08:14:50 --> Helper loaded: form_helper
INFO - 2023-10-05 08:14:50 --> Helper loaded: my_helper
INFO - 2023-10-05 08:14:50 --> Database Driver Class Initialized
INFO - 2023-10-05 08:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:14:50 --> Controller Class Initialized
DEBUG - 2023-10-05 08:14:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 08:14:56 --> Final output sent to browser
DEBUG - 2023-10-05 08:14:56 --> Total execution time: 6.4444
INFO - 2023-10-05 08:15:10 --> Config Class Initialized
INFO - 2023-10-05 08:15:10 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:15:10 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:15:10 --> Utf8 Class Initialized
INFO - 2023-10-05 08:15:10 --> URI Class Initialized
INFO - 2023-10-05 08:15:10 --> Router Class Initialized
INFO - 2023-10-05 08:15:10 --> Output Class Initialized
INFO - 2023-10-05 08:15:10 --> Security Class Initialized
DEBUG - 2023-10-05 08:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:15:10 --> Input Class Initialized
INFO - 2023-10-05 08:15:10 --> Language Class Initialized
INFO - 2023-10-05 08:15:10 --> Language Class Initialized
INFO - 2023-10-05 08:15:10 --> Config Class Initialized
INFO - 2023-10-05 08:15:10 --> Loader Class Initialized
INFO - 2023-10-05 08:15:10 --> Helper loaded: url_helper
INFO - 2023-10-05 08:15:10 --> Helper loaded: file_helper
INFO - 2023-10-05 08:15:10 --> Helper loaded: form_helper
INFO - 2023-10-05 08:15:10 --> Helper loaded: my_helper
INFO - 2023-10-05 08:15:10 --> Database Driver Class Initialized
INFO - 2023-10-05 08:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:15:10 --> Controller Class Initialized
DEBUG - 2023-10-05 08:15:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 08:15:16 --> Final output sent to browser
DEBUG - 2023-10-05 08:15:16 --> Total execution time: 5.5864
INFO - 2023-10-05 08:15:30 --> Config Class Initialized
INFO - 2023-10-05 08:15:30 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:15:31 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:15:31 --> Utf8 Class Initialized
INFO - 2023-10-05 08:15:31 --> URI Class Initialized
INFO - 2023-10-05 08:15:31 --> Router Class Initialized
INFO - 2023-10-05 08:15:31 --> Output Class Initialized
INFO - 2023-10-05 08:15:31 --> Security Class Initialized
DEBUG - 2023-10-05 08:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:15:31 --> Input Class Initialized
INFO - 2023-10-05 08:15:31 --> Language Class Initialized
INFO - 2023-10-05 08:15:31 --> Language Class Initialized
INFO - 2023-10-05 08:15:31 --> Config Class Initialized
INFO - 2023-10-05 08:15:31 --> Loader Class Initialized
INFO - 2023-10-05 08:15:31 --> Helper loaded: url_helper
INFO - 2023-10-05 08:15:31 --> Helper loaded: file_helper
INFO - 2023-10-05 08:15:31 --> Helper loaded: form_helper
INFO - 2023-10-05 08:15:31 --> Helper loaded: my_helper
INFO - 2023-10-05 08:15:31 --> Database Driver Class Initialized
INFO - 2023-10-05 08:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:15:31 --> Controller Class Initialized
DEBUG - 2023-10-05 08:15:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 08:15:36 --> Final output sent to browser
DEBUG - 2023-10-05 08:15:36 --> Total execution time: 5.7951
INFO - 2023-10-05 08:16:03 --> Config Class Initialized
INFO - 2023-10-05 08:16:03 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:16:03 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:16:03 --> Utf8 Class Initialized
INFO - 2023-10-05 08:16:03 --> URI Class Initialized
INFO - 2023-10-05 08:16:03 --> Router Class Initialized
INFO - 2023-10-05 08:16:03 --> Output Class Initialized
INFO - 2023-10-05 08:16:03 --> Security Class Initialized
DEBUG - 2023-10-05 08:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:16:03 --> Input Class Initialized
INFO - 2023-10-05 08:16:03 --> Language Class Initialized
INFO - 2023-10-05 08:16:03 --> Language Class Initialized
INFO - 2023-10-05 08:16:03 --> Config Class Initialized
INFO - 2023-10-05 08:16:03 --> Loader Class Initialized
INFO - 2023-10-05 08:16:03 --> Helper loaded: url_helper
INFO - 2023-10-05 08:16:03 --> Helper loaded: file_helper
INFO - 2023-10-05 08:16:03 --> Helper loaded: form_helper
INFO - 2023-10-05 08:16:03 --> Helper loaded: my_helper
INFO - 2023-10-05 08:16:03 --> Database Driver Class Initialized
INFO - 2023-10-05 08:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:16:03 --> Controller Class Initialized
DEBUG - 2023-10-05 08:16:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 08:16:08 --> Final output sent to browser
DEBUG - 2023-10-05 08:16:08 --> Total execution time: 5.5714
INFO - 2023-10-05 08:16:22 --> Config Class Initialized
INFO - 2023-10-05 08:16:22 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:16:22 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:16:22 --> Utf8 Class Initialized
INFO - 2023-10-05 08:16:22 --> URI Class Initialized
INFO - 2023-10-05 08:16:22 --> Router Class Initialized
INFO - 2023-10-05 08:16:22 --> Output Class Initialized
INFO - 2023-10-05 08:16:22 --> Security Class Initialized
DEBUG - 2023-10-05 08:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:16:22 --> Input Class Initialized
INFO - 2023-10-05 08:16:22 --> Language Class Initialized
INFO - 2023-10-05 08:16:22 --> Language Class Initialized
INFO - 2023-10-05 08:16:22 --> Config Class Initialized
INFO - 2023-10-05 08:16:22 --> Loader Class Initialized
INFO - 2023-10-05 08:16:22 --> Helper loaded: url_helper
INFO - 2023-10-05 08:16:22 --> Helper loaded: file_helper
INFO - 2023-10-05 08:16:22 --> Helper loaded: form_helper
INFO - 2023-10-05 08:16:22 --> Helper loaded: my_helper
INFO - 2023-10-05 08:16:23 --> Database Driver Class Initialized
INFO - 2023-10-05 08:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:16:23 --> Controller Class Initialized
DEBUG - 2023-10-05 08:16:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 08:16:26 --> Final output sent to browser
DEBUG - 2023-10-05 08:16:26 --> Total execution time: 3.8759
INFO - 2023-10-05 08:16:40 --> Config Class Initialized
INFO - 2023-10-05 08:16:40 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:16:40 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:16:40 --> Utf8 Class Initialized
INFO - 2023-10-05 08:16:40 --> URI Class Initialized
INFO - 2023-10-05 08:16:40 --> Router Class Initialized
INFO - 2023-10-05 08:16:40 --> Output Class Initialized
INFO - 2023-10-05 08:16:40 --> Security Class Initialized
DEBUG - 2023-10-05 08:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:16:40 --> Input Class Initialized
INFO - 2023-10-05 08:16:40 --> Language Class Initialized
INFO - 2023-10-05 08:16:40 --> Language Class Initialized
INFO - 2023-10-05 08:16:40 --> Config Class Initialized
INFO - 2023-10-05 08:16:40 --> Loader Class Initialized
INFO - 2023-10-05 08:16:40 --> Helper loaded: url_helper
INFO - 2023-10-05 08:16:40 --> Helper loaded: file_helper
INFO - 2023-10-05 08:16:40 --> Helper loaded: form_helper
INFO - 2023-10-05 08:16:40 --> Helper loaded: my_helper
INFO - 2023-10-05 08:16:40 --> Database Driver Class Initialized
INFO - 2023-10-05 08:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:16:40 --> Controller Class Initialized
DEBUG - 2023-10-05 08:16:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 08:16:44 --> Final output sent to browser
DEBUG - 2023-10-05 08:16:44 --> Total execution time: 4.1298
INFO - 2023-10-05 08:17:03 --> Config Class Initialized
INFO - 2023-10-05 08:17:03 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:17:03 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:17:03 --> Utf8 Class Initialized
INFO - 2023-10-05 08:17:03 --> URI Class Initialized
INFO - 2023-10-05 08:17:03 --> Router Class Initialized
INFO - 2023-10-05 08:17:03 --> Output Class Initialized
INFO - 2023-10-05 08:17:03 --> Security Class Initialized
DEBUG - 2023-10-05 08:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:17:03 --> Input Class Initialized
INFO - 2023-10-05 08:17:03 --> Language Class Initialized
INFO - 2023-10-05 08:17:03 --> Language Class Initialized
INFO - 2023-10-05 08:17:03 --> Config Class Initialized
INFO - 2023-10-05 08:17:03 --> Loader Class Initialized
INFO - 2023-10-05 08:17:03 --> Helper loaded: url_helper
INFO - 2023-10-05 08:17:03 --> Helper loaded: file_helper
INFO - 2023-10-05 08:17:03 --> Helper loaded: form_helper
INFO - 2023-10-05 08:17:03 --> Helper loaded: my_helper
INFO - 2023-10-05 08:17:03 --> Database Driver Class Initialized
INFO - 2023-10-05 08:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:17:03 --> Controller Class Initialized
DEBUG - 2023-10-05 08:17:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 08:17:08 --> Final output sent to browser
DEBUG - 2023-10-05 08:17:08 --> Total execution time: 5.3384
INFO - 2023-10-05 08:17:28 --> Config Class Initialized
INFO - 2023-10-05 08:17:28 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:17:28 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:17:28 --> Utf8 Class Initialized
INFO - 2023-10-05 08:17:28 --> URI Class Initialized
INFO - 2023-10-05 08:17:28 --> Router Class Initialized
INFO - 2023-10-05 08:17:28 --> Output Class Initialized
INFO - 2023-10-05 08:17:28 --> Security Class Initialized
DEBUG - 2023-10-05 08:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:17:28 --> Input Class Initialized
INFO - 2023-10-05 08:17:28 --> Language Class Initialized
INFO - 2023-10-05 08:17:28 --> Language Class Initialized
INFO - 2023-10-05 08:17:28 --> Config Class Initialized
INFO - 2023-10-05 08:17:28 --> Loader Class Initialized
INFO - 2023-10-05 08:17:28 --> Helper loaded: url_helper
INFO - 2023-10-05 08:17:28 --> Helper loaded: file_helper
INFO - 2023-10-05 08:17:28 --> Helper loaded: form_helper
INFO - 2023-10-05 08:17:28 --> Helper loaded: my_helper
INFO - 2023-10-05 08:17:28 --> Database Driver Class Initialized
INFO - 2023-10-05 08:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:17:28 --> Controller Class Initialized
DEBUG - 2023-10-05 08:17:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 08:17:33 --> Final output sent to browser
DEBUG - 2023-10-05 08:17:33 --> Total execution time: 4.6283
INFO - 2023-10-05 08:33:29 --> Config Class Initialized
INFO - 2023-10-05 08:33:29 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:33:29 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:33:29 --> Utf8 Class Initialized
INFO - 2023-10-05 08:33:29 --> URI Class Initialized
INFO - 2023-10-05 08:33:29 --> Router Class Initialized
INFO - 2023-10-05 08:33:29 --> Output Class Initialized
INFO - 2023-10-05 08:33:29 --> Security Class Initialized
DEBUG - 2023-10-05 08:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:33:29 --> Input Class Initialized
INFO - 2023-10-05 08:33:29 --> Language Class Initialized
INFO - 2023-10-05 08:33:29 --> Language Class Initialized
INFO - 2023-10-05 08:33:29 --> Config Class Initialized
INFO - 2023-10-05 08:33:29 --> Loader Class Initialized
INFO - 2023-10-05 08:33:29 --> Helper loaded: url_helper
INFO - 2023-10-05 08:33:29 --> Helper loaded: file_helper
INFO - 2023-10-05 08:33:29 --> Helper loaded: form_helper
INFO - 2023-10-05 08:33:29 --> Helper loaded: my_helper
INFO - 2023-10-05 08:33:29 --> Database Driver Class Initialized
INFO - 2023-10-05 08:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:33:29 --> Controller Class Initialized
INFO - 2023-10-05 08:33:29 --> Helper loaded: cookie_helper
INFO - 2023-10-05 08:33:29 --> Config Class Initialized
INFO - 2023-10-05 08:33:29 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:33:29 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:33:29 --> Utf8 Class Initialized
INFO - 2023-10-05 08:33:29 --> URI Class Initialized
INFO - 2023-10-05 08:33:29 --> Router Class Initialized
INFO - 2023-10-05 08:33:29 --> Output Class Initialized
INFO - 2023-10-05 08:33:29 --> Security Class Initialized
DEBUG - 2023-10-05 08:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:33:29 --> Input Class Initialized
INFO - 2023-10-05 08:33:29 --> Language Class Initialized
INFO - 2023-10-05 08:33:29 --> Language Class Initialized
INFO - 2023-10-05 08:33:29 --> Config Class Initialized
INFO - 2023-10-05 08:33:29 --> Loader Class Initialized
INFO - 2023-10-05 08:33:29 --> Helper loaded: url_helper
INFO - 2023-10-05 08:33:29 --> Helper loaded: file_helper
INFO - 2023-10-05 08:33:29 --> Helper loaded: form_helper
INFO - 2023-10-05 08:33:29 --> Helper loaded: my_helper
INFO - 2023-10-05 08:33:29 --> Database Driver Class Initialized
INFO - 2023-10-05 08:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:33:29 --> Controller Class Initialized
INFO - 2023-10-05 08:33:29 --> Config Class Initialized
INFO - 2023-10-05 08:33:29 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:33:29 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:33:29 --> Utf8 Class Initialized
INFO - 2023-10-05 08:33:29 --> URI Class Initialized
INFO - 2023-10-05 08:33:29 --> Router Class Initialized
INFO - 2023-10-05 08:33:29 --> Output Class Initialized
INFO - 2023-10-05 08:33:29 --> Security Class Initialized
DEBUG - 2023-10-05 08:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:33:29 --> Input Class Initialized
INFO - 2023-10-05 08:33:29 --> Language Class Initialized
INFO - 2023-10-05 08:33:29 --> Language Class Initialized
INFO - 2023-10-05 08:33:29 --> Config Class Initialized
INFO - 2023-10-05 08:33:29 --> Loader Class Initialized
INFO - 2023-10-05 08:33:29 --> Helper loaded: url_helper
INFO - 2023-10-05 08:33:29 --> Helper loaded: file_helper
INFO - 2023-10-05 08:33:29 --> Helper loaded: form_helper
INFO - 2023-10-05 08:33:29 --> Helper loaded: my_helper
INFO - 2023-10-05 08:33:29 --> Database Driver Class Initialized
INFO - 2023-10-05 08:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:33:29 --> Controller Class Initialized
DEBUG - 2023-10-05 08:33:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-05 08:33:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 08:33:29 --> Final output sent to browser
DEBUG - 2023-10-05 08:33:29 --> Total execution time: 0.0322
INFO - 2023-10-05 08:50:46 --> Config Class Initialized
INFO - 2023-10-05 08:50:46 --> Hooks Class Initialized
DEBUG - 2023-10-05 08:50:46 --> UTF-8 Support Enabled
INFO - 2023-10-05 08:50:46 --> Utf8 Class Initialized
INFO - 2023-10-05 08:50:46 --> URI Class Initialized
INFO - 2023-10-05 08:50:46 --> Router Class Initialized
INFO - 2023-10-05 08:50:46 --> Output Class Initialized
INFO - 2023-10-05 08:50:46 --> Security Class Initialized
DEBUG - 2023-10-05 08:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 08:50:46 --> Input Class Initialized
INFO - 2023-10-05 08:50:46 --> Language Class Initialized
INFO - 2023-10-05 08:50:46 --> Language Class Initialized
INFO - 2023-10-05 08:50:46 --> Config Class Initialized
INFO - 2023-10-05 08:50:46 --> Loader Class Initialized
INFO - 2023-10-05 08:50:46 --> Helper loaded: url_helper
INFO - 2023-10-05 08:50:46 --> Helper loaded: file_helper
INFO - 2023-10-05 08:50:46 --> Helper loaded: form_helper
INFO - 2023-10-05 08:50:46 --> Helper loaded: my_helper
INFO - 2023-10-05 08:50:46 --> Database Driver Class Initialized
INFO - 2023-10-05 08:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 08:50:46 --> Controller Class Initialized
DEBUG - 2023-10-05 08:50:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-05 08:50:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-05 08:50:46 --> Final output sent to browser
DEBUG - 2023-10-05 08:50:46 --> Total execution time: 0.1875
INFO - 2023-10-05 09:17:47 --> Config Class Initialized
INFO - 2023-10-05 09:17:47 --> Hooks Class Initialized
DEBUG - 2023-10-05 09:17:47 --> UTF-8 Support Enabled
INFO - 2023-10-05 09:17:47 --> Utf8 Class Initialized
INFO - 2023-10-05 09:17:47 --> URI Class Initialized
INFO - 2023-10-05 09:17:47 --> Router Class Initialized
INFO - 2023-10-05 09:17:47 --> Output Class Initialized
INFO - 2023-10-05 09:17:47 --> Security Class Initialized
DEBUG - 2023-10-05 09:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 09:17:47 --> Input Class Initialized
INFO - 2023-10-05 09:17:47 --> Language Class Initialized
INFO - 2023-10-05 09:17:47 --> Language Class Initialized
INFO - 2023-10-05 09:17:47 --> Config Class Initialized
INFO - 2023-10-05 09:17:47 --> Loader Class Initialized
INFO - 2023-10-05 09:17:47 --> Helper loaded: url_helper
INFO - 2023-10-05 09:17:47 --> Helper loaded: file_helper
INFO - 2023-10-05 09:17:47 --> Helper loaded: form_helper
INFO - 2023-10-05 09:17:47 --> Helper loaded: my_helper
INFO - 2023-10-05 09:17:47 --> Database Driver Class Initialized
INFO - 2023-10-05 09:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 09:17:47 --> Controller Class Initialized
DEBUG - 2023-10-05 09:17:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 09:17:52 --> Final output sent to browser
DEBUG - 2023-10-05 09:17:52 --> Total execution time: 5.1202
INFO - 2023-10-05 09:18:17 --> Config Class Initialized
INFO - 2023-10-05 09:18:17 --> Hooks Class Initialized
DEBUG - 2023-10-05 09:18:17 --> UTF-8 Support Enabled
INFO - 2023-10-05 09:18:17 --> Utf8 Class Initialized
INFO - 2023-10-05 09:18:17 --> URI Class Initialized
INFO - 2023-10-05 09:18:17 --> Router Class Initialized
INFO - 2023-10-05 09:18:17 --> Output Class Initialized
INFO - 2023-10-05 09:18:17 --> Security Class Initialized
DEBUG - 2023-10-05 09:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 09:18:17 --> Input Class Initialized
INFO - 2023-10-05 09:18:17 --> Language Class Initialized
INFO - 2023-10-05 09:18:17 --> Language Class Initialized
INFO - 2023-10-05 09:18:17 --> Config Class Initialized
INFO - 2023-10-05 09:18:17 --> Loader Class Initialized
INFO - 2023-10-05 09:18:17 --> Helper loaded: url_helper
INFO - 2023-10-05 09:18:17 --> Helper loaded: file_helper
INFO - 2023-10-05 09:18:17 --> Helper loaded: form_helper
INFO - 2023-10-05 09:18:17 --> Helper loaded: my_helper
INFO - 2023-10-05 09:18:17 --> Database Driver Class Initialized
INFO - 2023-10-05 09:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 09:18:17 --> Controller Class Initialized
DEBUG - 2023-10-05 09:18:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 09:18:23 --> Final output sent to browser
DEBUG - 2023-10-05 09:18:23 --> Total execution time: 5.7438
INFO - 2023-10-05 09:18:24 --> Config Class Initialized
INFO - 2023-10-05 09:18:24 --> Hooks Class Initialized
DEBUG - 2023-10-05 09:18:24 --> UTF-8 Support Enabled
INFO - 2023-10-05 09:18:24 --> Utf8 Class Initialized
INFO - 2023-10-05 09:18:24 --> URI Class Initialized
INFO - 2023-10-05 09:18:24 --> Router Class Initialized
INFO - 2023-10-05 09:18:24 --> Output Class Initialized
INFO - 2023-10-05 09:18:24 --> Security Class Initialized
DEBUG - 2023-10-05 09:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 09:18:24 --> Input Class Initialized
INFO - 2023-10-05 09:18:24 --> Language Class Initialized
INFO - 2023-10-05 09:18:24 --> Language Class Initialized
INFO - 2023-10-05 09:18:24 --> Config Class Initialized
INFO - 2023-10-05 09:18:24 --> Loader Class Initialized
INFO - 2023-10-05 09:18:24 --> Helper loaded: url_helper
INFO - 2023-10-05 09:18:24 --> Helper loaded: file_helper
INFO - 2023-10-05 09:18:24 --> Helper loaded: form_helper
INFO - 2023-10-05 09:18:24 --> Helper loaded: my_helper
INFO - 2023-10-05 09:18:24 --> Database Driver Class Initialized
INFO - 2023-10-05 09:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 09:18:24 --> Controller Class Initialized
DEBUG - 2023-10-05 09:18:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 09:18:27 --> Config Class Initialized
INFO - 2023-10-05 09:18:27 --> Hooks Class Initialized
DEBUG - 2023-10-05 09:18:27 --> UTF-8 Support Enabled
INFO - 2023-10-05 09:18:27 --> Utf8 Class Initialized
INFO - 2023-10-05 09:18:27 --> URI Class Initialized
INFO - 2023-10-05 09:18:27 --> Router Class Initialized
INFO - 2023-10-05 09:18:27 --> Output Class Initialized
INFO - 2023-10-05 09:18:27 --> Security Class Initialized
DEBUG - 2023-10-05 09:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 09:18:27 --> Input Class Initialized
INFO - 2023-10-05 09:18:27 --> Language Class Initialized
INFO - 2023-10-05 09:18:27 --> Language Class Initialized
INFO - 2023-10-05 09:18:27 --> Config Class Initialized
INFO - 2023-10-05 09:18:27 --> Loader Class Initialized
INFO - 2023-10-05 09:18:27 --> Helper loaded: url_helper
INFO - 2023-10-05 09:18:27 --> Helper loaded: file_helper
INFO - 2023-10-05 09:18:27 --> Helper loaded: form_helper
INFO - 2023-10-05 09:18:27 --> Helper loaded: my_helper
INFO - 2023-10-05 09:18:27 --> Database Driver Class Initialized
INFO - 2023-10-05 09:18:29 --> Final output sent to browser
DEBUG - 2023-10-05 09:18:29 --> Total execution time: 4.7640
INFO - 2023-10-05 09:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 09:18:29 --> Controller Class Initialized
DEBUG - 2023-10-05 09:18:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 09:18:35 --> Final output sent to browser
DEBUG - 2023-10-05 09:18:35 --> Total execution time: 7.1927
INFO - 2023-10-05 10:23:45 --> Config Class Initialized
INFO - 2023-10-05 10:23:45 --> Hooks Class Initialized
DEBUG - 2023-10-05 10:23:45 --> UTF-8 Support Enabled
INFO - 2023-10-05 10:23:45 --> Utf8 Class Initialized
INFO - 2023-10-05 10:23:45 --> URI Class Initialized
INFO - 2023-10-05 10:23:45 --> Router Class Initialized
INFO - 2023-10-05 10:23:45 --> Output Class Initialized
INFO - 2023-10-05 10:23:45 --> Security Class Initialized
DEBUG - 2023-10-05 10:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 10:23:45 --> Input Class Initialized
INFO - 2023-10-05 10:23:45 --> Language Class Initialized
INFO - 2023-10-05 10:23:45 --> Language Class Initialized
INFO - 2023-10-05 10:23:45 --> Config Class Initialized
INFO - 2023-10-05 10:23:45 --> Loader Class Initialized
INFO - 2023-10-05 10:23:45 --> Helper loaded: url_helper
INFO - 2023-10-05 10:23:45 --> Helper loaded: file_helper
INFO - 2023-10-05 10:23:45 --> Helper loaded: form_helper
INFO - 2023-10-05 10:23:45 --> Helper loaded: my_helper
INFO - 2023-10-05 10:23:45 --> Database Driver Class Initialized
INFO - 2023-10-05 10:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 10:23:45 --> Controller Class Initialized
DEBUG - 2023-10-05 10:23:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 10:23:54 --> Final output sent to browser
DEBUG - 2023-10-05 10:23:54 --> Total execution time: 8.3950
INFO - 2023-10-05 10:25:07 --> Config Class Initialized
INFO - 2023-10-05 10:25:07 --> Hooks Class Initialized
DEBUG - 2023-10-05 10:25:07 --> UTF-8 Support Enabled
INFO - 2023-10-05 10:25:07 --> Utf8 Class Initialized
INFO - 2023-10-05 10:25:07 --> URI Class Initialized
INFO - 2023-10-05 10:25:07 --> Router Class Initialized
INFO - 2023-10-05 10:25:07 --> Output Class Initialized
INFO - 2023-10-05 10:25:07 --> Security Class Initialized
DEBUG - 2023-10-05 10:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 10:25:07 --> Input Class Initialized
INFO - 2023-10-05 10:25:07 --> Language Class Initialized
INFO - 2023-10-05 10:25:07 --> Language Class Initialized
INFO - 2023-10-05 10:25:07 --> Config Class Initialized
INFO - 2023-10-05 10:25:07 --> Loader Class Initialized
INFO - 2023-10-05 10:25:07 --> Helper loaded: url_helper
INFO - 2023-10-05 10:25:07 --> Helper loaded: file_helper
INFO - 2023-10-05 10:25:07 --> Helper loaded: form_helper
INFO - 2023-10-05 10:25:07 --> Helper loaded: my_helper
INFO - 2023-10-05 10:25:07 --> Database Driver Class Initialized
INFO - 2023-10-05 10:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 10:25:07 --> Controller Class Initialized
DEBUG - 2023-10-05 10:25:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 10:25:12 --> Final output sent to browser
DEBUG - 2023-10-05 10:25:12 --> Total execution time: 5.1149
INFO - 2023-10-05 10:37:58 --> Config Class Initialized
INFO - 2023-10-05 10:37:58 --> Hooks Class Initialized
DEBUG - 2023-10-05 10:37:58 --> UTF-8 Support Enabled
INFO - 2023-10-05 10:37:58 --> Utf8 Class Initialized
INFO - 2023-10-05 10:37:58 --> URI Class Initialized
INFO - 2023-10-05 10:37:58 --> Router Class Initialized
INFO - 2023-10-05 10:37:58 --> Output Class Initialized
INFO - 2023-10-05 10:37:58 --> Security Class Initialized
DEBUG - 2023-10-05 10:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 10:37:58 --> Input Class Initialized
INFO - 2023-10-05 10:37:58 --> Language Class Initialized
INFO - 2023-10-05 10:37:58 --> Language Class Initialized
INFO - 2023-10-05 10:37:58 --> Config Class Initialized
INFO - 2023-10-05 10:37:58 --> Loader Class Initialized
INFO - 2023-10-05 10:37:58 --> Helper loaded: url_helper
INFO - 2023-10-05 10:37:58 --> Helper loaded: file_helper
INFO - 2023-10-05 10:37:58 --> Helper loaded: form_helper
INFO - 2023-10-05 10:37:58 --> Helper loaded: my_helper
INFO - 2023-10-05 10:37:58 --> Database Driver Class Initialized
INFO - 2023-10-05 10:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 10:37:58 --> Controller Class Initialized
DEBUG - 2023-10-05 10:37:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 10:38:03 --> Final output sent to browser
DEBUG - 2023-10-05 10:38:03 --> Total execution time: 5.2348
INFO - 2023-10-05 11:14:27 --> Config Class Initialized
INFO - 2023-10-05 11:14:27 --> Hooks Class Initialized
DEBUG - 2023-10-05 11:14:27 --> UTF-8 Support Enabled
INFO - 2023-10-05 11:14:27 --> Utf8 Class Initialized
INFO - 2023-10-05 11:14:27 --> URI Class Initialized
INFO - 2023-10-05 11:14:27 --> Router Class Initialized
INFO - 2023-10-05 11:14:27 --> Output Class Initialized
INFO - 2023-10-05 11:14:27 --> Security Class Initialized
DEBUG - 2023-10-05 11:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 11:14:27 --> Input Class Initialized
INFO - 2023-10-05 11:14:27 --> Language Class Initialized
INFO - 2023-10-05 11:14:27 --> Language Class Initialized
INFO - 2023-10-05 11:14:27 --> Config Class Initialized
INFO - 2023-10-05 11:14:27 --> Loader Class Initialized
INFO - 2023-10-05 11:14:27 --> Helper loaded: url_helper
INFO - 2023-10-05 11:14:27 --> Helper loaded: file_helper
INFO - 2023-10-05 11:14:27 --> Helper loaded: form_helper
INFO - 2023-10-05 11:14:27 --> Helper loaded: my_helper
INFO - 2023-10-05 11:14:27 --> Database Driver Class Initialized
INFO - 2023-10-05 11:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 11:14:27 --> Controller Class Initialized
DEBUG - 2023-10-05 11:14:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 11:14:33 --> Final output sent to browser
DEBUG - 2023-10-05 11:14:33 --> Total execution time: 5.7427
INFO - 2023-10-05 11:14:38 --> Config Class Initialized
INFO - 2023-10-05 11:14:38 --> Hooks Class Initialized
DEBUG - 2023-10-05 11:14:38 --> UTF-8 Support Enabled
INFO - 2023-10-05 11:14:38 --> Utf8 Class Initialized
INFO - 2023-10-05 11:14:38 --> URI Class Initialized
INFO - 2023-10-05 11:14:38 --> Router Class Initialized
INFO - 2023-10-05 11:14:38 --> Output Class Initialized
INFO - 2023-10-05 11:14:38 --> Security Class Initialized
DEBUG - 2023-10-05 11:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 11:14:38 --> Input Class Initialized
INFO - 2023-10-05 11:14:38 --> Language Class Initialized
INFO - 2023-10-05 11:14:38 --> Language Class Initialized
INFO - 2023-10-05 11:14:38 --> Config Class Initialized
INFO - 2023-10-05 11:14:38 --> Loader Class Initialized
INFO - 2023-10-05 11:14:38 --> Helper loaded: url_helper
INFO - 2023-10-05 11:14:38 --> Helper loaded: file_helper
INFO - 2023-10-05 11:14:38 --> Helper loaded: form_helper
INFO - 2023-10-05 11:14:38 --> Helper loaded: my_helper
INFO - 2023-10-05 11:14:38 --> Database Driver Class Initialized
INFO - 2023-10-05 11:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 11:14:38 --> Controller Class Initialized
DEBUG - 2023-10-05 11:14:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 11:14:42 --> Final output sent to browser
DEBUG - 2023-10-05 11:14:42 --> Total execution time: 3.6053
INFO - 2023-10-05 11:14:43 --> Config Class Initialized
INFO - 2023-10-05 11:14:43 --> Hooks Class Initialized
DEBUG - 2023-10-05 11:14:43 --> UTF-8 Support Enabled
INFO - 2023-10-05 11:14:43 --> Utf8 Class Initialized
INFO - 2023-10-05 11:14:43 --> URI Class Initialized
INFO - 2023-10-05 11:14:43 --> Router Class Initialized
INFO - 2023-10-05 11:14:43 --> Output Class Initialized
INFO - 2023-10-05 11:14:43 --> Security Class Initialized
DEBUG - 2023-10-05 11:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-05 11:14:43 --> Input Class Initialized
INFO - 2023-10-05 11:14:43 --> Language Class Initialized
INFO - 2023-10-05 11:14:43 --> Language Class Initialized
INFO - 2023-10-05 11:14:43 --> Config Class Initialized
INFO - 2023-10-05 11:14:43 --> Loader Class Initialized
INFO - 2023-10-05 11:14:43 --> Helper loaded: url_helper
INFO - 2023-10-05 11:14:43 --> Helper loaded: file_helper
INFO - 2023-10-05 11:14:43 --> Helper loaded: form_helper
INFO - 2023-10-05 11:14:43 --> Helper loaded: my_helper
INFO - 2023-10-05 11:14:43 --> Database Driver Class Initialized
INFO - 2023-10-05 11:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-05 11:14:43 --> Controller Class Initialized
DEBUG - 2023-10-05 11:14:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-05 11:14:47 --> Final output sent to browser
DEBUG - 2023-10-05 11:14:47 --> Total execution time: 3.5805
