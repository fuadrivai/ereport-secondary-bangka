<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-09 01:19:32 --> Config Class Initialized
INFO - 2020-02-09 01:19:32 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:19:32 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:19:32 --> Utf8 Class Initialized
INFO - 2020-02-09 01:19:32 --> URI Class Initialized
DEBUG - 2020-02-09 01:19:32 --> No URI present. Default controller set.
INFO - 2020-02-09 01:19:32 --> Router Class Initialized
INFO - 2020-02-09 01:19:32 --> Output Class Initialized
INFO - 2020-02-09 01:19:32 --> Security Class Initialized
DEBUG - 2020-02-09 01:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:19:32 --> Input Class Initialized
INFO - 2020-02-09 01:19:32 --> Language Class Initialized
INFO - 2020-02-09 01:19:32 --> Language Class Initialized
INFO - 2020-02-09 01:19:32 --> Config Class Initialized
INFO - 2020-02-09 01:19:32 --> Loader Class Initialized
INFO - 2020-02-09 01:19:32 --> Helper loaded: url_helper
INFO - 2020-02-09 01:19:32 --> Helper loaded: file_helper
INFO - 2020-02-09 01:19:32 --> Helper loaded: form_helper
INFO - 2020-02-09 01:19:33 --> Helper loaded: my_helper
INFO - 2020-02-09 01:19:33 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:19:33 --> Controller Class Initialized
INFO - 2020-02-09 01:19:33 --> Config Class Initialized
INFO - 2020-02-09 01:19:33 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:19:33 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:19:33 --> Utf8 Class Initialized
INFO - 2020-02-09 01:19:33 --> URI Class Initialized
INFO - 2020-02-09 01:19:33 --> Router Class Initialized
INFO - 2020-02-09 01:19:33 --> Output Class Initialized
INFO - 2020-02-09 01:19:33 --> Security Class Initialized
DEBUG - 2020-02-09 01:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:19:33 --> Input Class Initialized
INFO - 2020-02-09 01:19:33 --> Language Class Initialized
INFO - 2020-02-09 01:19:33 --> Language Class Initialized
INFO - 2020-02-09 01:19:33 --> Config Class Initialized
INFO - 2020-02-09 01:19:33 --> Loader Class Initialized
INFO - 2020-02-09 01:19:33 --> Helper loaded: url_helper
INFO - 2020-02-09 01:19:33 --> Helper loaded: file_helper
INFO - 2020-02-09 01:19:33 --> Helper loaded: form_helper
INFO - 2020-02-09 01:19:33 --> Helper loaded: my_helper
INFO - 2020-02-09 01:19:33 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:19:33 --> Controller Class Initialized
DEBUG - 2020-02-09 01:19:33 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:19:33 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:19:33 --> Final output sent to browser
DEBUG - 2020-02-09 01:19:33 --> Total execution time: 0.2892
INFO - 2020-02-09 01:20:47 --> Config Class Initialized
INFO - 2020-02-09 01:20:47 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:20:47 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:20:47 --> Utf8 Class Initialized
INFO - 2020-02-09 01:20:47 --> URI Class Initialized
INFO - 2020-02-09 01:20:47 --> Router Class Initialized
INFO - 2020-02-09 01:20:47 --> Output Class Initialized
INFO - 2020-02-09 01:20:47 --> Security Class Initialized
DEBUG - 2020-02-09 01:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:20:47 --> Input Class Initialized
INFO - 2020-02-09 01:20:47 --> Language Class Initialized
INFO - 2020-02-09 01:20:47 --> Language Class Initialized
INFO - 2020-02-09 01:20:47 --> Config Class Initialized
INFO - 2020-02-09 01:20:47 --> Loader Class Initialized
INFO - 2020-02-09 01:20:47 --> Helper loaded: url_helper
INFO - 2020-02-09 01:20:47 --> Helper loaded: file_helper
INFO - 2020-02-09 01:20:47 --> Helper loaded: form_helper
INFO - 2020-02-09 01:20:47 --> Helper loaded: my_helper
INFO - 2020-02-09 01:20:47 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:20:47 --> Controller Class Initialized
DEBUG - 2020-02-09 01:20:47 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:20:47 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:20:47 --> Final output sent to browser
DEBUG - 2020-02-09 01:20:47 --> Total execution time: 0.2789
INFO - 2020-02-09 01:31:07 --> Config Class Initialized
INFO - 2020-02-09 01:31:07 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:31:08 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:31:08 --> Utf8 Class Initialized
INFO - 2020-02-09 01:31:08 --> URI Class Initialized
INFO - 2020-02-09 01:31:08 --> Router Class Initialized
INFO - 2020-02-09 01:31:08 --> Output Class Initialized
INFO - 2020-02-09 01:31:08 --> Security Class Initialized
DEBUG - 2020-02-09 01:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:31:08 --> Input Class Initialized
INFO - 2020-02-09 01:31:08 --> Language Class Initialized
INFO - 2020-02-09 01:31:08 --> Language Class Initialized
INFO - 2020-02-09 01:31:08 --> Config Class Initialized
INFO - 2020-02-09 01:31:08 --> Loader Class Initialized
INFO - 2020-02-09 01:31:08 --> Helper loaded: url_helper
INFO - 2020-02-09 01:31:08 --> Helper loaded: file_helper
INFO - 2020-02-09 01:31:08 --> Helper loaded: form_helper
INFO - 2020-02-09 01:31:08 --> Helper loaded: my_helper
INFO - 2020-02-09 01:31:08 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:31:08 --> Controller Class Initialized
DEBUG - 2020-02-09 01:31:08 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:31:08 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:31:08 --> Final output sent to browser
DEBUG - 2020-02-09 01:31:08 --> Total execution time: 0.3556
INFO - 2020-02-09 01:31:17 --> Config Class Initialized
INFO - 2020-02-09 01:31:17 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:31:17 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:31:17 --> Utf8 Class Initialized
INFO - 2020-02-09 01:31:17 --> URI Class Initialized
INFO - 2020-02-09 01:31:17 --> Router Class Initialized
INFO - 2020-02-09 01:31:17 --> Output Class Initialized
INFO - 2020-02-09 01:31:17 --> Security Class Initialized
DEBUG - 2020-02-09 01:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:31:17 --> Input Class Initialized
INFO - 2020-02-09 01:31:17 --> Language Class Initialized
INFO - 2020-02-09 01:31:17 --> Language Class Initialized
INFO - 2020-02-09 01:31:17 --> Config Class Initialized
INFO - 2020-02-09 01:31:17 --> Loader Class Initialized
INFO - 2020-02-09 01:31:17 --> Helper loaded: url_helper
INFO - 2020-02-09 01:31:17 --> Helper loaded: file_helper
INFO - 2020-02-09 01:31:17 --> Helper loaded: form_helper
INFO - 2020-02-09 01:31:17 --> Helper loaded: my_helper
INFO - 2020-02-09 01:31:17 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:31:17 --> Controller Class Initialized
DEBUG - 2020-02-09 01:31:17 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:31:17 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:31:17 --> Final output sent to browser
DEBUG - 2020-02-09 01:31:17 --> Total execution time: 0.3698
INFO - 2020-02-09 01:31:43 --> Config Class Initialized
INFO - 2020-02-09 01:31:43 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:31:43 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:31:43 --> Utf8 Class Initialized
INFO - 2020-02-09 01:31:43 --> URI Class Initialized
INFO - 2020-02-09 01:31:43 --> Router Class Initialized
INFO - 2020-02-09 01:31:43 --> Output Class Initialized
INFO - 2020-02-09 01:31:43 --> Security Class Initialized
DEBUG - 2020-02-09 01:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:31:43 --> Input Class Initialized
INFO - 2020-02-09 01:31:43 --> Language Class Initialized
INFO - 2020-02-09 01:31:43 --> Language Class Initialized
INFO - 2020-02-09 01:31:43 --> Config Class Initialized
INFO - 2020-02-09 01:31:43 --> Loader Class Initialized
INFO - 2020-02-09 01:31:43 --> Helper loaded: url_helper
INFO - 2020-02-09 01:31:43 --> Helper loaded: file_helper
INFO - 2020-02-09 01:31:43 --> Helper loaded: form_helper
INFO - 2020-02-09 01:31:43 --> Helper loaded: my_helper
INFO - 2020-02-09 01:31:43 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:31:43 --> Controller Class Initialized
DEBUG - 2020-02-09 01:31:43 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:31:43 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:31:43 --> Final output sent to browser
DEBUG - 2020-02-09 01:31:43 --> Total execution time: 0.3614
INFO - 2020-02-09 01:32:09 --> Config Class Initialized
INFO - 2020-02-09 01:32:09 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:32:09 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:32:09 --> Utf8 Class Initialized
INFO - 2020-02-09 01:32:09 --> URI Class Initialized
INFO - 2020-02-09 01:32:09 --> Router Class Initialized
INFO - 2020-02-09 01:32:09 --> Output Class Initialized
INFO - 2020-02-09 01:32:09 --> Security Class Initialized
DEBUG - 2020-02-09 01:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:32:09 --> Input Class Initialized
INFO - 2020-02-09 01:32:09 --> Language Class Initialized
INFO - 2020-02-09 01:32:09 --> Language Class Initialized
INFO - 2020-02-09 01:32:09 --> Config Class Initialized
INFO - 2020-02-09 01:32:09 --> Loader Class Initialized
INFO - 2020-02-09 01:32:09 --> Helper loaded: url_helper
INFO - 2020-02-09 01:32:09 --> Helper loaded: file_helper
INFO - 2020-02-09 01:32:09 --> Helper loaded: form_helper
INFO - 2020-02-09 01:32:09 --> Helper loaded: my_helper
INFO - 2020-02-09 01:32:09 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:32:09 --> Controller Class Initialized
DEBUG - 2020-02-09 01:32:09 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:32:09 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:32:09 --> Final output sent to browser
DEBUG - 2020-02-09 01:32:09 --> Total execution time: 0.3609
INFO - 2020-02-09 01:32:20 --> Config Class Initialized
INFO - 2020-02-09 01:32:20 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:32:20 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:32:20 --> Utf8 Class Initialized
INFO - 2020-02-09 01:32:20 --> URI Class Initialized
INFO - 2020-02-09 01:32:20 --> Router Class Initialized
INFO - 2020-02-09 01:32:20 --> Output Class Initialized
INFO - 2020-02-09 01:32:20 --> Security Class Initialized
DEBUG - 2020-02-09 01:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:32:20 --> Input Class Initialized
INFO - 2020-02-09 01:32:20 --> Language Class Initialized
INFO - 2020-02-09 01:32:20 --> Language Class Initialized
INFO - 2020-02-09 01:32:20 --> Config Class Initialized
INFO - 2020-02-09 01:32:20 --> Loader Class Initialized
INFO - 2020-02-09 01:32:20 --> Helper loaded: url_helper
INFO - 2020-02-09 01:32:20 --> Helper loaded: file_helper
INFO - 2020-02-09 01:32:20 --> Helper loaded: form_helper
INFO - 2020-02-09 01:32:20 --> Helper loaded: my_helper
INFO - 2020-02-09 01:32:20 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:32:20 --> Controller Class Initialized
DEBUG - 2020-02-09 01:32:20 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:32:20 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:32:20 --> Final output sent to browser
DEBUG - 2020-02-09 01:32:20 --> Total execution time: 0.3273
INFO - 2020-02-09 01:32:24 --> Config Class Initialized
INFO - 2020-02-09 01:32:24 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:32:24 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:32:24 --> Utf8 Class Initialized
INFO - 2020-02-09 01:32:24 --> URI Class Initialized
INFO - 2020-02-09 01:32:24 --> Router Class Initialized
INFO - 2020-02-09 01:32:24 --> Output Class Initialized
INFO - 2020-02-09 01:32:24 --> Security Class Initialized
DEBUG - 2020-02-09 01:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:32:24 --> Input Class Initialized
INFO - 2020-02-09 01:32:24 --> Language Class Initialized
INFO - 2020-02-09 01:32:24 --> Language Class Initialized
INFO - 2020-02-09 01:32:24 --> Config Class Initialized
INFO - 2020-02-09 01:32:24 --> Loader Class Initialized
INFO - 2020-02-09 01:32:24 --> Helper loaded: url_helper
INFO - 2020-02-09 01:32:24 --> Helper loaded: file_helper
INFO - 2020-02-09 01:32:24 --> Helper loaded: form_helper
INFO - 2020-02-09 01:32:24 --> Helper loaded: my_helper
INFO - 2020-02-09 01:32:24 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:32:24 --> Controller Class Initialized
DEBUG - 2020-02-09 01:32:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:32:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:32:24 --> Final output sent to browser
DEBUG - 2020-02-09 01:32:24 --> Total execution time: 0.3433
INFO - 2020-02-09 01:32:28 --> Config Class Initialized
INFO - 2020-02-09 01:32:28 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:32:28 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:32:28 --> Utf8 Class Initialized
INFO - 2020-02-09 01:32:28 --> URI Class Initialized
INFO - 2020-02-09 01:32:28 --> Router Class Initialized
INFO - 2020-02-09 01:32:28 --> Output Class Initialized
INFO - 2020-02-09 01:32:28 --> Security Class Initialized
DEBUG - 2020-02-09 01:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:32:28 --> Input Class Initialized
INFO - 2020-02-09 01:32:28 --> Language Class Initialized
INFO - 2020-02-09 01:32:28 --> Language Class Initialized
INFO - 2020-02-09 01:32:28 --> Config Class Initialized
INFO - 2020-02-09 01:32:28 --> Loader Class Initialized
INFO - 2020-02-09 01:32:28 --> Helper loaded: url_helper
INFO - 2020-02-09 01:32:28 --> Helper loaded: file_helper
INFO - 2020-02-09 01:32:28 --> Helper loaded: form_helper
INFO - 2020-02-09 01:32:28 --> Helper loaded: my_helper
INFO - 2020-02-09 01:32:28 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:32:28 --> Controller Class Initialized
DEBUG - 2020-02-09 01:32:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:32:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:32:28 --> Final output sent to browser
DEBUG - 2020-02-09 01:32:28 --> Total execution time: 0.3616
INFO - 2020-02-09 01:32:42 --> Config Class Initialized
INFO - 2020-02-09 01:32:42 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:32:42 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:32:42 --> Utf8 Class Initialized
INFO - 2020-02-09 01:32:42 --> URI Class Initialized
INFO - 2020-02-09 01:32:42 --> Router Class Initialized
INFO - 2020-02-09 01:32:42 --> Output Class Initialized
INFO - 2020-02-09 01:32:42 --> Security Class Initialized
DEBUG - 2020-02-09 01:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:32:42 --> Input Class Initialized
INFO - 2020-02-09 01:32:42 --> Language Class Initialized
INFO - 2020-02-09 01:32:42 --> Language Class Initialized
INFO - 2020-02-09 01:32:42 --> Config Class Initialized
INFO - 2020-02-09 01:32:42 --> Loader Class Initialized
INFO - 2020-02-09 01:32:42 --> Helper loaded: url_helper
INFO - 2020-02-09 01:32:42 --> Helper loaded: file_helper
INFO - 2020-02-09 01:32:42 --> Helper loaded: form_helper
INFO - 2020-02-09 01:32:42 --> Helper loaded: my_helper
INFO - 2020-02-09 01:32:42 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:32:42 --> Controller Class Initialized
DEBUG - 2020-02-09 01:32:42 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:32:42 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:32:42 --> Final output sent to browser
DEBUG - 2020-02-09 01:32:42 --> Total execution time: 0.3442
INFO - 2020-02-09 01:33:15 --> Config Class Initialized
INFO - 2020-02-09 01:33:15 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:33:16 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:33:16 --> Utf8 Class Initialized
INFO - 2020-02-09 01:33:16 --> URI Class Initialized
INFO - 2020-02-09 01:33:16 --> Router Class Initialized
INFO - 2020-02-09 01:33:16 --> Output Class Initialized
INFO - 2020-02-09 01:33:16 --> Security Class Initialized
DEBUG - 2020-02-09 01:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:33:16 --> Input Class Initialized
INFO - 2020-02-09 01:33:16 --> Language Class Initialized
INFO - 2020-02-09 01:33:16 --> Language Class Initialized
INFO - 2020-02-09 01:33:16 --> Config Class Initialized
INFO - 2020-02-09 01:33:16 --> Loader Class Initialized
INFO - 2020-02-09 01:33:16 --> Helper loaded: url_helper
INFO - 2020-02-09 01:33:16 --> Helper loaded: file_helper
INFO - 2020-02-09 01:33:16 --> Helper loaded: form_helper
INFO - 2020-02-09 01:33:16 --> Helper loaded: my_helper
INFO - 2020-02-09 01:33:16 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:33:16 --> Controller Class Initialized
DEBUG - 2020-02-09 01:33:16 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:33:16 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:33:16 --> Final output sent to browser
DEBUG - 2020-02-09 01:33:16 --> Total execution time: 0.3461
INFO - 2020-02-09 01:33:25 --> Config Class Initialized
INFO - 2020-02-09 01:33:25 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:33:25 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:33:25 --> Utf8 Class Initialized
INFO - 2020-02-09 01:33:25 --> URI Class Initialized
INFO - 2020-02-09 01:33:25 --> Router Class Initialized
INFO - 2020-02-09 01:33:25 --> Output Class Initialized
INFO - 2020-02-09 01:33:25 --> Security Class Initialized
DEBUG - 2020-02-09 01:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:33:25 --> Input Class Initialized
INFO - 2020-02-09 01:33:26 --> Language Class Initialized
INFO - 2020-02-09 01:33:26 --> Language Class Initialized
INFO - 2020-02-09 01:33:26 --> Config Class Initialized
INFO - 2020-02-09 01:33:26 --> Loader Class Initialized
INFO - 2020-02-09 01:33:26 --> Helper loaded: url_helper
INFO - 2020-02-09 01:33:26 --> Helper loaded: file_helper
INFO - 2020-02-09 01:33:26 --> Helper loaded: form_helper
INFO - 2020-02-09 01:33:26 --> Helper loaded: my_helper
INFO - 2020-02-09 01:33:26 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:33:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:33:26 --> Controller Class Initialized
DEBUG - 2020-02-09 01:33:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:33:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:33:26 --> Final output sent to browser
DEBUG - 2020-02-09 01:33:26 --> Total execution time: 0.3441
INFO - 2020-02-09 01:33:44 --> Config Class Initialized
INFO - 2020-02-09 01:33:44 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:33:44 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:33:44 --> Utf8 Class Initialized
INFO - 2020-02-09 01:33:44 --> URI Class Initialized
INFO - 2020-02-09 01:33:44 --> Router Class Initialized
INFO - 2020-02-09 01:33:44 --> Output Class Initialized
INFO - 2020-02-09 01:33:44 --> Security Class Initialized
DEBUG - 2020-02-09 01:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:33:44 --> Input Class Initialized
INFO - 2020-02-09 01:33:44 --> Language Class Initialized
INFO - 2020-02-09 01:33:44 --> Language Class Initialized
INFO - 2020-02-09 01:33:44 --> Config Class Initialized
INFO - 2020-02-09 01:33:44 --> Loader Class Initialized
INFO - 2020-02-09 01:33:44 --> Helper loaded: url_helper
INFO - 2020-02-09 01:33:44 --> Helper loaded: file_helper
INFO - 2020-02-09 01:33:44 --> Helper loaded: form_helper
INFO - 2020-02-09 01:33:44 --> Helper loaded: my_helper
INFO - 2020-02-09 01:33:44 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:33:44 --> Controller Class Initialized
DEBUG - 2020-02-09 01:33:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:33:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:33:44 --> Final output sent to browser
DEBUG - 2020-02-09 01:33:44 --> Total execution time: 0.3221
INFO - 2020-02-09 01:33:57 --> Config Class Initialized
INFO - 2020-02-09 01:33:57 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:33:57 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:33:57 --> Utf8 Class Initialized
INFO - 2020-02-09 01:33:57 --> URI Class Initialized
INFO - 2020-02-09 01:33:57 --> Router Class Initialized
INFO - 2020-02-09 01:33:57 --> Output Class Initialized
INFO - 2020-02-09 01:33:57 --> Security Class Initialized
DEBUG - 2020-02-09 01:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:33:57 --> Input Class Initialized
INFO - 2020-02-09 01:33:57 --> Language Class Initialized
INFO - 2020-02-09 01:33:57 --> Language Class Initialized
INFO - 2020-02-09 01:33:57 --> Config Class Initialized
INFO - 2020-02-09 01:33:57 --> Loader Class Initialized
INFO - 2020-02-09 01:33:57 --> Helper loaded: url_helper
INFO - 2020-02-09 01:33:57 --> Helper loaded: file_helper
INFO - 2020-02-09 01:33:57 --> Helper loaded: form_helper
INFO - 2020-02-09 01:33:57 --> Helper loaded: my_helper
INFO - 2020-02-09 01:33:57 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:33:57 --> Controller Class Initialized
DEBUG - 2020-02-09 01:33:57 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:33:57 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:33:57 --> Final output sent to browser
DEBUG - 2020-02-09 01:33:57 --> Total execution time: 0.3304
INFO - 2020-02-09 01:34:35 --> Config Class Initialized
INFO - 2020-02-09 01:34:35 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:34:35 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:34:35 --> Utf8 Class Initialized
INFO - 2020-02-09 01:34:35 --> URI Class Initialized
INFO - 2020-02-09 01:34:35 --> Router Class Initialized
INFO - 2020-02-09 01:34:35 --> Output Class Initialized
INFO - 2020-02-09 01:34:35 --> Security Class Initialized
DEBUG - 2020-02-09 01:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:34:35 --> Input Class Initialized
INFO - 2020-02-09 01:34:35 --> Language Class Initialized
ERROR - 2020-02-09 01:34:35 --> 404 Page Not Found: /index
INFO - 2020-02-09 01:34:41 --> Config Class Initialized
INFO - 2020-02-09 01:34:41 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:34:41 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:34:41 --> Utf8 Class Initialized
INFO - 2020-02-09 01:34:41 --> URI Class Initialized
DEBUG - 2020-02-09 01:34:41 --> No URI present. Default controller set.
INFO - 2020-02-09 01:34:41 --> Router Class Initialized
INFO - 2020-02-09 01:34:41 --> Output Class Initialized
INFO - 2020-02-09 01:34:41 --> Security Class Initialized
DEBUG - 2020-02-09 01:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:34:41 --> Input Class Initialized
INFO - 2020-02-09 01:34:41 --> Language Class Initialized
INFO - 2020-02-09 01:34:41 --> Language Class Initialized
INFO - 2020-02-09 01:34:41 --> Config Class Initialized
INFO - 2020-02-09 01:34:41 --> Loader Class Initialized
INFO - 2020-02-09 01:34:41 --> Helper loaded: url_helper
INFO - 2020-02-09 01:34:42 --> Helper loaded: file_helper
INFO - 2020-02-09 01:34:42 --> Helper loaded: form_helper
INFO - 2020-02-09 01:34:42 --> Helper loaded: my_helper
INFO - 2020-02-09 01:34:42 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:34:42 --> Controller Class Initialized
INFO - 2020-02-09 01:34:42 --> Config Class Initialized
INFO - 2020-02-09 01:34:42 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:34:42 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:34:42 --> Utf8 Class Initialized
INFO - 2020-02-09 01:34:42 --> URI Class Initialized
INFO - 2020-02-09 01:34:42 --> Router Class Initialized
INFO - 2020-02-09 01:34:42 --> Output Class Initialized
INFO - 2020-02-09 01:34:42 --> Security Class Initialized
DEBUG - 2020-02-09 01:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:34:42 --> Input Class Initialized
INFO - 2020-02-09 01:34:42 --> Language Class Initialized
INFO - 2020-02-09 01:34:42 --> Language Class Initialized
INFO - 2020-02-09 01:34:42 --> Config Class Initialized
INFO - 2020-02-09 01:34:42 --> Loader Class Initialized
INFO - 2020-02-09 01:34:42 --> Helper loaded: url_helper
INFO - 2020-02-09 01:34:42 --> Helper loaded: file_helper
INFO - 2020-02-09 01:34:42 --> Helper loaded: form_helper
INFO - 2020-02-09 01:34:42 --> Helper loaded: my_helper
INFO - 2020-02-09 01:34:42 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:34:42 --> Controller Class Initialized
DEBUG - 2020-02-09 01:34:42 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:34:42 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:34:42 --> Final output sent to browser
DEBUG - 2020-02-09 01:34:42 --> Total execution time: 0.4341
INFO - 2020-02-09 01:34:42 --> Config Class Initialized
INFO - 2020-02-09 01:34:42 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:34:42 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:34:42 --> Utf8 Class Initialized
INFO - 2020-02-09 01:34:43 --> URI Class Initialized
INFO - 2020-02-09 01:34:43 --> Router Class Initialized
INFO - 2020-02-09 01:34:43 --> Output Class Initialized
INFO - 2020-02-09 01:34:43 --> Security Class Initialized
DEBUG - 2020-02-09 01:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:34:43 --> Input Class Initialized
INFO - 2020-02-09 01:34:43 --> Language Class Initialized
ERROR - 2020-02-09 01:34:43 --> 404 Page Not Found: /index
INFO - 2020-02-09 01:37:48 --> Config Class Initialized
INFO - 2020-02-09 01:37:48 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:37:48 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:37:48 --> Utf8 Class Initialized
INFO - 2020-02-09 01:37:48 --> URI Class Initialized
INFO - 2020-02-09 01:37:48 --> Router Class Initialized
INFO - 2020-02-09 01:37:48 --> Output Class Initialized
INFO - 2020-02-09 01:37:48 --> Security Class Initialized
DEBUG - 2020-02-09 01:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:37:48 --> Input Class Initialized
INFO - 2020-02-09 01:37:48 --> Language Class Initialized
INFO - 2020-02-09 01:37:49 --> Language Class Initialized
INFO - 2020-02-09 01:37:49 --> Config Class Initialized
INFO - 2020-02-09 01:37:49 --> Loader Class Initialized
INFO - 2020-02-09 01:37:49 --> Helper loaded: url_helper
INFO - 2020-02-09 01:37:49 --> Helper loaded: file_helper
INFO - 2020-02-09 01:37:49 --> Helper loaded: form_helper
INFO - 2020-02-09 01:37:49 --> Helper loaded: my_helper
INFO - 2020-02-09 01:37:49 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:37:49 --> Controller Class Initialized
DEBUG - 2020-02-09 01:37:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:37:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:37:49 --> Final output sent to browser
DEBUG - 2020-02-09 01:37:49 --> Total execution time: 0.3643
INFO - 2020-02-09 01:37:49 --> Config Class Initialized
INFO - 2020-02-09 01:37:49 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:37:49 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:37:49 --> Utf8 Class Initialized
INFO - 2020-02-09 01:37:49 --> URI Class Initialized
INFO - 2020-02-09 01:37:49 --> Router Class Initialized
INFO - 2020-02-09 01:37:49 --> Output Class Initialized
INFO - 2020-02-09 01:37:49 --> Security Class Initialized
DEBUG - 2020-02-09 01:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:37:49 --> Input Class Initialized
INFO - 2020-02-09 01:37:49 --> Language Class Initialized
ERROR - 2020-02-09 01:37:49 --> 404 Page Not Found: /index
INFO - 2020-02-09 01:37:52 --> Config Class Initialized
INFO - 2020-02-09 01:37:52 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:37:52 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:37:52 --> Utf8 Class Initialized
INFO - 2020-02-09 01:37:52 --> URI Class Initialized
INFO - 2020-02-09 01:37:52 --> Router Class Initialized
INFO - 2020-02-09 01:37:52 --> Output Class Initialized
INFO - 2020-02-09 01:37:52 --> Security Class Initialized
DEBUG - 2020-02-09 01:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:37:52 --> Input Class Initialized
INFO - 2020-02-09 01:37:52 --> Language Class Initialized
INFO - 2020-02-09 01:37:52 --> Language Class Initialized
INFO - 2020-02-09 01:37:52 --> Config Class Initialized
INFO - 2020-02-09 01:37:52 --> Loader Class Initialized
INFO - 2020-02-09 01:37:52 --> Helper loaded: url_helper
INFO - 2020-02-09 01:37:52 --> Helper loaded: file_helper
INFO - 2020-02-09 01:37:52 --> Helper loaded: form_helper
INFO - 2020-02-09 01:37:52 --> Helper loaded: my_helper
INFO - 2020-02-09 01:37:52 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:37:52 --> Controller Class Initialized
DEBUG - 2020-02-09 01:37:52 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:37:52 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:37:52 --> Final output sent to browser
DEBUG - 2020-02-09 01:37:52 --> Total execution time: 0.3758
INFO - 2020-02-09 01:38:02 --> Config Class Initialized
INFO - 2020-02-09 01:38:02 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:38:02 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:38:02 --> Utf8 Class Initialized
INFO - 2020-02-09 01:38:02 --> URI Class Initialized
INFO - 2020-02-09 01:38:02 --> Router Class Initialized
INFO - 2020-02-09 01:38:03 --> Output Class Initialized
INFO - 2020-02-09 01:38:03 --> Security Class Initialized
DEBUG - 2020-02-09 01:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:38:03 --> Input Class Initialized
INFO - 2020-02-09 01:38:03 --> Language Class Initialized
INFO - 2020-02-09 01:38:03 --> Language Class Initialized
INFO - 2020-02-09 01:38:03 --> Config Class Initialized
INFO - 2020-02-09 01:38:03 --> Loader Class Initialized
INFO - 2020-02-09 01:38:03 --> Helper loaded: url_helper
INFO - 2020-02-09 01:38:03 --> Helper loaded: file_helper
INFO - 2020-02-09 01:38:03 --> Helper loaded: form_helper
INFO - 2020-02-09 01:38:03 --> Helper loaded: my_helper
INFO - 2020-02-09 01:38:03 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:38:03 --> Controller Class Initialized
DEBUG - 2020-02-09 01:38:03 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:38:03 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:38:03 --> Final output sent to browser
DEBUG - 2020-02-09 01:38:03 --> Total execution time: 0.3687
INFO - 2020-02-09 01:38:49 --> Config Class Initialized
INFO - 2020-02-09 01:38:49 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:38:49 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:38:49 --> Utf8 Class Initialized
INFO - 2020-02-09 01:38:49 --> URI Class Initialized
INFO - 2020-02-09 01:38:49 --> Router Class Initialized
INFO - 2020-02-09 01:38:49 --> Output Class Initialized
INFO - 2020-02-09 01:38:49 --> Security Class Initialized
DEBUG - 2020-02-09 01:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:38:49 --> Input Class Initialized
INFO - 2020-02-09 01:38:49 --> Language Class Initialized
INFO - 2020-02-09 01:38:49 --> Language Class Initialized
INFO - 2020-02-09 01:38:49 --> Config Class Initialized
INFO - 2020-02-09 01:38:49 --> Loader Class Initialized
INFO - 2020-02-09 01:38:49 --> Helper loaded: url_helper
INFO - 2020-02-09 01:38:49 --> Helper loaded: file_helper
INFO - 2020-02-09 01:38:49 --> Helper loaded: form_helper
INFO - 2020-02-09 01:38:49 --> Helper loaded: my_helper
INFO - 2020-02-09 01:38:49 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:38:49 --> Controller Class Initialized
DEBUG - 2020-02-09 01:38:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:38:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:38:49 --> Final output sent to browser
DEBUG - 2020-02-09 01:38:49 --> Total execution time: 0.3419
INFO - 2020-02-09 01:38:51 --> Config Class Initialized
INFO - 2020-02-09 01:38:51 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:38:51 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:38:51 --> Utf8 Class Initialized
INFO - 2020-02-09 01:38:51 --> URI Class Initialized
INFO - 2020-02-09 01:38:51 --> Router Class Initialized
INFO - 2020-02-09 01:38:51 --> Output Class Initialized
INFO - 2020-02-09 01:38:51 --> Security Class Initialized
DEBUG - 2020-02-09 01:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:38:51 --> Input Class Initialized
INFO - 2020-02-09 01:38:51 --> Language Class Initialized
INFO - 2020-02-09 01:38:51 --> Language Class Initialized
INFO - 2020-02-09 01:38:51 --> Config Class Initialized
INFO - 2020-02-09 01:38:51 --> Loader Class Initialized
INFO - 2020-02-09 01:38:51 --> Helper loaded: url_helper
INFO - 2020-02-09 01:38:51 --> Helper loaded: file_helper
INFO - 2020-02-09 01:38:51 --> Helper loaded: form_helper
INFO - 2020-02-09 01:38:51 --> Helper loaded: my_helper
INFO - 2020-02-09 01:38:51 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:38:51 --> Controller Class Initialized
DEBUG - 2020-02-09 01:38:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:38:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:38:51 --> Final output sent to browser
DEBUG - 2020-02-09 01:38:51 --> Total execution time: 0.3378
INFO - 2020-02-09 01:39:12 --> Config Class Initialized
INFO - 2020-02-09 01:39:12 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:39:12 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:39:12 --> Utf8 Class Initialized
INFO - 2020-02-09 01:39:12 --> URI Class Initialized
INFO - 2020-02-09 01:39:12 --> Router Class Initialized
INFO - 2020-02-09 01:39:12 --> Output Class Initialized
INFO - 2020-02-09 01:39:12 --> Security Class Initialized
DEBUG - 2020-02-09 01:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:39:12 --> Input Class Initialized
INFO - 2020-02-09 01:39:12 --> Language Class Initialized
INFO - 2020-02-09 01:39:12 --> Language Class Initialized
INFO - 2020-02-09 01:39:12 --> Config Class Initialized
INFO - 2020-02-09 01:39:12 --> Loader Class Initialized
INFO - 2020-02-09 01:39:12 --> Helper loaded: url_helper
INFO - 2020-02-09 01:39:12 --> Helper loaded: file_helper
INFO - 2020-02-09 01:39:12 --> Helper loaded: form_helper
INFO - 2020-02-09 01:39:12 --> Helper loaded: my_helper
INFO - 2020-02-09 01:39:12 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:39:12 --> Controller Class Initialized
DEBUG - 2020-02-09 01:39:12 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:39:12 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:39:12 --> Final output sent to browser
DEBUG - 2020-02-09 01:39:12 --> Total execution time: 0.3439
INFO - 2020-02-09 01:39:12 --> Config Class Initialized
INFO - 2020-02-09 01:39:12 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:39:12 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:39:12 --> Utf8 Class Initialized
INFO - 2020-02-09 01:39:12 --> URI Class Initialized
INFO - 2020-02-09 01:39:12 --> Router Class Initialized
INFO - 2020-02-09 01:39:12 --> Output Class Initialized
INFO - 2020-02-09 01:39:12 --> Security Class Initialized
DEBUG - 2020-02-09 01:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:39:13 --> Input Class Initialized
INFO - 2020-02-09 01:39:13 --> Language Class Initialized
INFO - 2020-02-09 01:39:13 --> Language Class Initialized
INFO - 2020-02-09 01:39:13 --> Config Class Initialized
INFO - 2020-02-09 01:39:13 --> Loader Class Initialized
INFO - 2020-02-09 01:39:13 --> Helper loaded: url_helper
INFO - 2020-02-09 01:39:13 --> Helper loaded: file_helper
INFO - 2020-02-09 01:39:13 --> Helper loaded: form_helper
INFO - 2020-02-09 01:39:13 --> Helper loaded: my_helper
INFO - 2020-02-09 01:39:13 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:39:13 --> Controller Class Initialized
DEBUG - 2020-02-09 01:39:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:39:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:39:13 --> Final output sent to browser
DEBUG - 2020-02-09 01:39:13 --> Total execution time: 0.3539
INFO - 2020-02-09 01:39:13 --> Config Class Initialized
INFO - 2020-02-09 01:39:13 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:39:13 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:39:13 --> Utf8 Class Initialized
INFO - 2020-02-09 01:39:13 --> URI Class Initialized
INFO - 2020-02-09 01:39:13 --> Router Class Initialized
INFO - 2020-02-09 01:39:13 --> Output Class Initialized
INFO - 2020-02-09 01:39:13 --> Security Class Initialized
DEBUG - 2020-02-09 01:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:39:13 --> Input Class Initialized
INFO - 2020-02-09 01:39:13 --> Language Class Initialized
INFO - 2020-02-09 01:39:13 --> Language Class Initialized
INFO - 2020-02-09 01:39:13 --> Config Class Initialized
INFO - 2020-02-09 01:39:13 --> Loader Class Initialized
INFO - 2020-02-09 01:39:13 --> Helper loaded: url_helper
INFO - 2020-02-09 01:39:13 --> Helper loaded: file_helper
INFO - 2020-02-09 01:39:13 --> Helper loaded: form_helper
INFO - 2020-02-09 01:39:13 --> Helper loaded: my_helper
INFO - 2020-02-09 01:39:13 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:39:13 --> Controller Class Initialized
DEBUG - 2020-02-09 01:39:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:39:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:39:13 --> Final output sent to browser
DEBUG - 2020-02-09 01:39:13 --> Total execution time: 0.3867
INFO - 2020-02-09 01:39:25 --> Config Class Initialized
INFO - 2020-02-09 01:39:25 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:39:25 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:39:25 --> Utf8 Class Initialized
INFO - 2020-02-09 01:39:25 --> URI Class Initialized
INFO - 2020-02-09 01:39:25 --> Router Class Initialized
INFO - 2020-02-09 01:39:25 --> Output Class Initialized
INFO - 2020-02-09 01:39:25 --> Security Class Initialized
DEBUG - 2020-02-09 01:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:39:25 --> Input Class Initialized
INFO - 2020-02-09 01:39:25 --> Language Class Initialized
INFO - 2020-02-09 01:39:25 --> Language Class Initialized
INFO - 2020-02-09 01:39:25 --> Config Class Initialized
INFO - 2020-02-09 01:39:25 --> Loader Class Initialized
INFO - 2020-02-09 01:39:25 --> Helper loaded: url_helper
INFO - 2020-02-09 01:39:25 --> Helper loaded: file_helper
INFO - 2020-02-09 01:39:25 --> Helper loaded: form_helper
INFO - 2020-02-09 01:39:25 --> Helper loaded: my_helper
INFO - 2020-02-09 01:39:25 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:39:25 --> Controller Class Initialized
DEBUG - 2020-02-09 01:39:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:39:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:39:25 --> Final output sent to browser
DEBUG - 2020-02-09 01:39:25 --> Total execution time: 0.3881
INFO - 2020-02-09 01:39:31 --> Config Class Initialized
INFO - 2020-02-09 01:39:31 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:39:31 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:39:31 --> Utf8 Class Initialized
INFO - 2020-02-09 01:39:31 --> URI Class Initialized
INFO - 2020-02-09 01:39:31 --> Router Class Initialized
INFO - 2020-02-09 01:39:31 --> Output Class Initialized
INFO - 2020-02-09 01:39:31 --> Security Class Initialized
DEBUG - 2020-02-09 01:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:39:31 --> Input Class Initialized
INFO - 2020-02-09 01:39:31 --> Language Class Initialized
INFO - 2020-02-09 01:39:31 --> Language Class Initialized
INFO - 2020-02-09 01:39:31 --> Config Class Initialized
INFO - 2020-02-09 01:39:31 --> Loader Class Initialized
INFO - 2020-02-09 01:39:31 --> Helper loaded: url_helper
INFO - 2020-02-09 01:39:31 --> Helper loaded: file_helper
INFO - 2020-02-09 01:39:31 --> Helper loaded: form_helper
INFO - 2020-02-09 01:39:31 --> Helper loaded: my_helper
INFO - 2020-02-09 01:39:31 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:39:31 --> Controller Class Initialized
DEBUG - 2020-02-09 01:39:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:39:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:39:31 --> Final output sent to browser
DEBUG - 2020-02-09 01:39:31 --> Total execution time: 0.3452
INFO - 2020-02-09 01:39:43 --> Config Class Initialized
INFO - 2020-02-09 01:39:43 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:39:43 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:39:43 --> Utf8 Class Initialized
INFO - 2020-02-09 01:39:43 --> URI Class Initialized
INFO - 2020-02-09 01:39:43 --> Router Class Initialized
INFO - 2020-02-09 01:39:43 --> Output Class Initialized
INFO - 2020-02-09 01:39:43 --> Security Class Initialized
DEBUG - 2020-02-09 01:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:39:43 --> Input Class Initialized
INFO - 2020-02-09 01:39:44 --> Language Class Initialized
INFO - 2020-02-09 01:39:44 --> Language Class Initialized
INFO - 2020-02-09 01:39:44 --> Config Class Initialized
INFO - 2020-02-09 01:39:44 --> Loader Class Initialized
INFO - 2020-02-09 01:39:44 --> Helper loaded: url_helper
INFO - 2020-02-09 01:39:44 --> Helper loaded: file_helper
INFO - 2020-02-09 01:39:44 --> Helper loaded: form_helper
INFO - 2020-02-09 01:39:44 --> Helper loaded: my_helper
INFO - 2020-02-09 01:39:44 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:39:44 --> Controller Class Initialized
DEBUG - 2020-02-09 01:39:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:39:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:39:44 --> Final output sent to browser
DEBUG - 2020-02-09 01:39:44 --> Total execution time: 0.3362
INFO - 2020-02-09 01:40:36 --> Config Class Initialized
INFO - 2020-02-09 01:40:36 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:40:36 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:40:36 --> Utf8 Class Initialized
INFO - 2020-02-09 01:40:36 --> URI Class Initialized
INFO - 2020-02-09 01:40:36 --> Router Class Initialized
INFO - 2020-02-09 01:40:36 --> Output Class Initialized
INFO - 2020-02-09 01:40:36 --> Security Class Initialized
DEBUG - 2020-02-09 01:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:40:36 --> Input Class Initialized
INFO - 2020-02-09 01:40:36 --> Language Class Initialized
INFO - 2020-02-09 01:40:36 --> Language Class Initialized
INFO - 2020-02-09 01:40:36 --> Config Class Initialized
INFO - 2020-02-09 01:40:36 --> Loader Class Initialized
INFO - 2020-02-09 01:40:36 --> Helper loaded: url_helper
INFO - 2020-02-09 01:40:36 --> Helper loaded: file_helper
INFO - 2020-02-09 01:40:36 --> Helper loaded: form_helper
INFO - 2020-02-09 01:40:36 --> Helper loaded: my_helper
INFO - 2020-02-09 01:40:36 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:40:37 --> Controller Class Initialized
DEBUG - 2020-02-09 01:40:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:40:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:40:37 --> Final output sent to browser
DEBUG - 2020-02-09 01:40:37 --> Total execution time: 0.3514
INFO - 2020-02-09 01:40:58 --> Config Class Initialized
INFO - 2020-02-09 01:40:58 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:40:58 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:40:58 --> Utf8 Class Initialized
INFO - 2020-02-09 01:40:58 --> URI Class Initialized
INFO - 2020-02-09 01:40:58 --> Router Class Initialized
INFO - 2020-02-09 01:40:58 --> Output Class Initialized
INFO - 2020-02-09 01:40:58 --> Security Class Initialized
DEBUG - 2020-02-09 01:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:40:58 --> Input Class Initialized
INFO - 2020-02-09 01:40:58 --> Language Class Initialized
INFO - 2020-02-09 01:40:58 --> Language Class Initialized
INFO - 2020-02-09 01:40:58 --> Config Class Initialized
INFO - 2020-02-09 01:40:58 --> Loader Class Initialized
INFO - 2020-02-09 01:40:58 --> Helper loaded: url_helper
INFO - 2020-02-09 01:40:58 --> Helper loaded: file_helper
INFO - 2020-02-09 01:40:59 --> Helper loaded: form_helper
INFO - 2020-02-09 01:40:59 --> Helper loaded: my_helper
INFO - 2020-02-09 01:40:59 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:40:59 --> Controller Class Initialized
DEBUG - 2020-02-09 01:40:59 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:40:59 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:40:59 --> Final output sent to browser
DEBUG - 2020-02-09 01:40:59 --> Total execution time: 0.3713
INFO - 2020-02-09 01:41:30 --> Config Class Initialized
INFO - 2020-02-09 01:41:30 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:41:30 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:41:30 --> Utf8 Class Initialized
INFO - 2020-02-09 01:41:30 --> URI Class Initialized
INFO - 2020-02-09 01:41:30 --> Router Class Initialized
INFO - 2020-02-09 01:41:30 --> Output Class Initialized
INFO - 2020-02-09 01:41:30 --> Security Class Initialized
DEBUG - 2020-02-09 01:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:41:30 --> Input Class Initialized
INFO - 2020-02-09 01:41:30 --> Language Class Initialized
INFO - 2020-02-09 01:41:30 --> Language Class Initialized
INFO - 2020-02-09 01:41:30 --> Config Class Initialized
INFO - 2020-02-09 01:41:30 --> Loader Class Initialized
INFO - 2020-02-09 01:41:30 --> Helper loaded: url_helper
INFO - 2020-02-09 01:41:30 --> Helper loaded: file_helper
INFO - 2020-02-09 01:41:30 --> Helper loaded: form_helper
INFO - 2020-02-09 01:41:30 --> Helper loaded: my_helper
INFO - 2020-02-09 01:41:30 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:41:30 --> Controller Class Initialized
DEBUG - 2020-02-09 01:41:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:41:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:41:30 --> Final output sent to browser
DEBUG - 2020-02-09 01:41:30 --> Total execution time: 0.3570
INFO - 2020-02-09 01:42:21 --> Config Class Initialized
INFO - 2020-02-09 01:42:22 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:42:22 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:42:22 --> Utf8 Class Initialized
INFO - 2020-02-09 01:42:22 --> URI Class Initialized
INFO - 2020-02-09 01:42:22 --> Router Class Initialized
INFO - 2020-02-09 01:42:22 --> Output Class Initialized
INFO - 2020-02-09 01:42:22 --> Security Class Initialized
DEBUG - 2020-02-09 01:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:42:22 --> Input Class Initialized
INFO - 2020-02-09 01:42:22 --> Language Class Initialized
INFO - 2020-02-09 01:42:22 --> Language Class Initialized
INFO - 2020-02-09 01:42:22 --> Config Class Initialized
INFO - 2020-02-09 01:42:22 --> Loader Class Initialized
INFO - 2020-02-09 01:42:22 --> Helper loaded: url_helper
INFO - 2020-02-09 01:42:22 --> Helper loaded: file_helper
INFO - 2020-02-09 01:42:22 --> Helper loaded: form_helper
INFO - 2020-02-09 01:42:22 --> Helper loaded: my_helper
INFO - 2020-02-09 01:42:22 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:42:22 --> Controller Class Initialized
DEBUG - 2020-02-09 01:42:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:42:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:42:22 --> Final output sent to browser
DEBUG - 2020-02-09 01:42:22 --> Total execution time: 0.3607
INFO - 2020-02-09 01:42:41 --> Config Class Initialized
INFO - 2020-02-09 01:42:41 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:42:41 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:42:41 --> Utf8 Class Initialized
INFO - 2020-02-09 01:42:41 --> URI Class Initialized
INFO - 2020-02-09 01:42:41 --> Router Class Initialized
INFO - 2020-02-09 01:42:41 --> Output Class Initialized
INFO - 2020-02-09 01:42:41 --> Security Class Initialized
DEBUG - 2020-02-09 01:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:42:42 --> Input Class Initialized
INFO - 2020-02-09 01:42:42 --> Language Class Initialized
INFO - 2020-02-09 01:42:42 --> Language Class Initialized
INFO - 2020-02-09 01:42:42 --> Config Class Initialized
INFO - 2020-02-09 01:42:42 --> Loader Class Initialized
INFO - 2020-02-09 01:42:42 --> Helper loaded: url_helper
INFO - 2020-02-09 01:42:42 --> Helper loaded: file_helper
INFO - 2020-02-09 01:42:42 --> Helper loaded: form_helper
INFO - 2020-02-09 01:42:42 --> Helper loaded: my_helper
INFO - 2020-02-09 01:42:42 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:42:42 --> Controller Class Initialized
DEBUG - 2020-02-09 01:42:42 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:42:42 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:42:42 --> Final output sent to browser
DEBUG - 2020-02-09 01:42:42 --> Total execution time: 0.3902
INFO - 2020-02-09 01:42:47 --> Config Class Initialized
INFO - 2020-02-09 01:42:47 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:42:47 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:42:47 --> Utf8 Class Initialized
INFO - 2020-02-09 01:42:47 --> URI Class Initialized
INFO - 2020-02-09 01:42:47 --> Router Class Initialized
INFO - 2020-02-09 01:42:47 --> Output Class Initialized
INFO - 2020-02-09 01:42:47 --> Security Class Initialized
DEBUG - 2020-02-09 01:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:42:47 --> Input Class Initialized
INFO - 2020-02-09 01:42:47 --> Language Class Initialized
INFO - 2020-02-09 01:42:47 --> Language Class Initialized
INFO - 2020-02-09 01:42:47 --> Config Class Initialized
INFO - 2020-02-09 01:42:47 --> Loader Class Initialized
INFO - 2020-02-09 01:42:47 --> Helper loaded: url_helper
INFO - 2020-02-09 01:42:48 --> Helper loaded: file_helper
INFO - 2020-02-09 01:42:48 --> Helper loaded: form_helper
INFO - 2020-02-09 01:42:48 --> Helper loaded: my_helper
INFO - 2020-02-09 01:42:48 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:42:48 --> Controller Class Initialized
DEBUG - 2020-02-09 01:42:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:42:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:42:48 --> Final output sent to browser
DEBUG - 2020-02-09 01:42:48 --> Total execution time: 0.3866
INFO - 2020-02-09 01:42:54 --> Config Class Initialized
INFO - 2020-02-09 01:42:54 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:42:54 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:42:54 --> Utf8 Class Initialized
INFO - 2020-02-09 01:42:54 --> URI Class Initialized
INFO - 2020-02-09 01:42:54 --> Router Class Initialized
INFO - 2020-02-09 01:42:54 --> Output Class Initialized
INFO - 2020-02-09 01:42:54 --> Security Class Initialized
DEBUG - 2020-02-09 01:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:42:54 --> Input Class Initialized
INFO - 2020-02-09 01:42:54 --> Language Class Initialized
INFO - 2020-02-09 01:42:54 --> Language Class Initialized
INFO - 2020-02-09 01:42:54 --> Config Class Initialized
INFO - 2020-02-09 01:42:54 --> Loader Class Initialized
INFO - 2020-02-09 01:42:54 --> Helper loaded: url_helper
INFO - 2020-02-09 01:42:54 --> Helper loaded: file_helper
INFO - 2020-02-09 01:42:54 --> Helper loaded: form_helper
INFO - 2020-02-09 01:42:54 --> Helper loaded: my_helper
INFO - 2020-02-09 01:42:54 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:42:55 --> Controller Class Initialized
DEBUG - 2020-02-09 01:42:55 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:42:55 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:42:55 --> Final output sent to browser
DEBUG - 2020-02-09 01:42:55 --> Total execution time: 0.4039
INFO - 2020-02-09 01:43:22 --> Config Class Initialized
INFO - 2020-02-09 01:43:22 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:43:22 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:43:22 --> Utf8 Class Initialized
INFO - 2020-02-09 01:43:22 --> URI Class Initialized
INFO - 2020-02-09 01:43:22 --> Router Class Initialized
INFO - 2020-02-09 01:43:22 --> Output Class Initialized
INFO - 2020-02-09 01:43:22 --> Security Class Initialized
DEBUG - 2020-02-09 01:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:43:22 --> Input Class Initialized
INFO - 2020-02-09 01:43:22 --> Language Class Initialized
INFO - 2020-02-09 01:43:22 --> Language Class Initialized
INFO - 2020-02-09 01:43:22 --> Config Class Initialized
INFO - 2020-02-09 01:43:22 --> Loader Class Initialized
INFO - 2020-02-09 01:43:22 --> Helper loaded: url_helper
INFO - 2020-02-09 01:43:22 --> Helper loaded: file_helper
INFO - 2020-02-09 01:43:22 --> Helper loaded: form_helper
INFO - 2020-02-09 01:43:22 --> Helper loaded: my_helper
INFO - 2020-02-09 01:43:22 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:43:22 --> Controller Class Initialized
DEBUG - 2020-02-09 01:43:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:43:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:43:22 --> Final output sent to browser
DEBUG - 2020-02-09 01:43:22 --> Total execution time: 0.6334
INFO - 2020-02-09 01:51:40 --> Config Class Initialized
INFO - 2020-02-09 01:51:40 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:51:40 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:51:40 --> Utf8 Class Initialized
INFO - 2020-02-09 01:51:40 --> URI Class Initialized
INFO - 2020-02-09 01:51:40 --> Router Class Initialized
INFO - 2020-02-09 01:51:40 --> Output Class Initialized
INFO - 2020-02-09 01:51:40 --> Security Class Initialized
DEBUG - 2020-02-09 01:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:51:41 --> Input Class Initialized
INFO - 2020-02-09 01:51:41 --> Language Class Initialized
INFO - 2020-02-09 01:51:41 --> Language Class Initialized
INFO - 2020-02-09 01:51:41 --> Config Class Initialized
INFO - 2020-02-09 01:51:41 --> Loader Class Initialized
INFO - 2020-02-09 01:51:41 --> Helper loaded: url_helper
INFO - 2020-02-09 01:51:41 --> Helper loaded: file_helper
INFO - 2020-02-09 01:51:41 --> Helper loaded: form_helper
INFO - 2020-02-09 01:51:41 --> Helper loaded: my_helper
INFO - 2020-02-09 01:51:41 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:51:41 --> Controller Class Initialized
DEBUG - 2020-02-09 01:51:41 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:51:41 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:51:41 --> Final output sent to browser
DEBUG - 2020-02-09 01:51:41 --> Total execution time: 0.3709
INFO - 2020-02-09 01:52:47 --> Config Class Initialized
INFO - 2020-02-09 01:52:47 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:52:47 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:52:47 --> Utf8 Class Initialized
INFO - 2020-02-09 01:52:47 --> URI Class Initialized
INFO - 2020-02-09 01:52:47 --> Router Class Initialized
INFO - 2020-02-09 01:52:47 --> Output Class Initialized
INFO - 2020-02-09 01:52:47 --> Security Class Initialized
DEBUG - 2020-02-09 01:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:52:47 --> Input Class Initialized
INFO - 2020-02-09 01:52:47 --> Language Class Initialized
INFO - 2020-02-09 01:52:47 --> Language Class Initialized
INFO - 2020-02-09 01:52:47 --> Config Class Initialized
INFO - 2020-02-09 01:52:47 --> Loader Class Initialized
INFO - 2020-02-09 01:52:47 --> Helper loaded: url_helper
INFO - 2020-02-09 01:52:47 --> Helper loaded: file_helper
INFO - 2020-02-09 01:52:47 --> Helper loaded: form_helper
INFO - 2020-02-09 01:52:47 --> Helper loaded: my_helper
INFO - 2020-02-09 01:52:47 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:52:47 --> Controller Class Initialized
DEBUG - 2020-02-09 01:52:47 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:52:47 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:52:47 --> Final output sent to browser
DEBUG - 2020-02-09 01:52:47 --> Total execution time: 0.4290
INFO - 2020-02-09 01:52:49 --> Config Class Initialized
INFO - 2020-02-09 01:52:49 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:52:49 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:52:49 --> Utf8 Class Initialized
INFO - 2020-02-09 01:52:49 --> URI Class Initialized
INFO - 2020-02-09 01:52:49 --> Router Class Initialized
INFO - 2020-02-09 01:52:49 --> Output Class Initialized
INFO - 2020-02-09 01:52:49 --> Security Class Initialized
DEBUG - 2020-02-09 01:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:52:49 --> Input Class Initialized
INFO - 2020-02-09 01:52:49 --> Language Class Initialized
INFO - 2020-02-09 01:52:49 --> Language Class Initialized
INFO - 2020-02-09 01:52:49 --> Config Class Initialized
INFO - 2020-02-09 01:52:49 --> Loader Class Initialized
INFO - 2020-02-09 01:52:49 --> Helper loaded: url_helper
INFO - 2020-02-09 01:52:49 --> Helper loaded: file_helper
INFO - 2020-02-09 01:52:49 --> Helper loaded: form_helper
INFO - 2020-02-09 01:52:49 --> Helper loaded: my_helper
INFO - 2020-02-09 01:52:49 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:52:49 --> Controller Class Initialized
DEBUG - 2020-02-09 01:52:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:52:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:52:49 --> Final output sent to browser
DEBUG - 2020-02-09 01:52:49 --> Total execution time: 0.3815
INFO - 2020-02-09 01:53:08 --> Config Class Initialized
INFO - 2020-02-09 01:53:08 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:53:08 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:53:08 --> Utf8 Class Initialized
INFO - 2020-02-09 01:53:08 --> URI Class Initialized
INFO - 2020-02-09 01:53:08 --> Router Class Initialized
INFO - 2020-02-09 01:53:08 --> Output Class Initialized
INFO - 2020-02-09 01:53:08 --> Security Class Initialized
DEBUG - 2020-02-09 01:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:53:08 --> Input Class Initialized
INFO - 2020-02-09 01:53:08 --> Language Class Initialized
INFO - 2020-02-09 01:53:08 --> Language Class Initialized
INFO - 2020-02-09 01:53:08 --> Config Class Initialized
INFO - 2020-02-09 01:53:08 --> Loader Class Initialized
INFO - 2020-02-09 01:53:08 --> Helper loaded: url_helper
INFO - 2020-02-09 01:53:08 --> Helper loaded: file_helper
INFO - 2020-02-09 01:53:08 --> Helper loaded: form_helper
INFO - 2020-02-09 01:53:08 --> Helper loaded: my_helper
INFO - 2020-02-09 01:53:08 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:53:08 --> Controller Class Initialized
DEBUG - 2020-02-09 01:53:09 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:53:09 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:53:09 --> Final output sent to browser
DEBUG - 2020-02-09 01:53:09 --> Total execution time: 0.4008
INFO - 2020-02-09 01:53:50 --> Config Class Initialized
INFO - 2020-02-09 01:53:51 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:53:51 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:53:51 --> Utf8 Class Initialized
INFO - 2020-02-09 01:53:51 --> URI Class Initialized
INFO - 2020-02-09 01:53:51 --> Router Class Initialized
INFO - 2020-02-09 01:53:51 --> Output Class Initialized
INFO - 2020-02-09 01:53:51 --> Security Class Initialized
DEBUG - 2020-02-09 01:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:53:51 --> Input Class Initialized
INFO - 2020-02-09 01:53:51 --> Language Class Initialized
INFO - 2020-02-09 01:53:51 --> Language Class Initialized
INFO - 2020-02-09 01:53:51 --> Config Class Initialized
INFO - 2020-02-09 01:53:51 --> Loader Class Initialized
INFO - 2020-02-09 01:53:51 --> Helper loaded: url_helper
INFO - 2020-02-09 01:53:51 --> Helper loaded: file_helper
INFO - 2020-02-09 01:53:51 --> Helper loaded: form_helper
INFO - 2020-02-09 01:53:51 --> Helper loaded: my_helper
INFO - 2020-02-09 01:53:51 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:53:51 --> Controller Class Initialized
DEBUG - 2020-02-09 01:53:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:53:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:53:51 --> Final output sent to browser
DEBUG - 2020-02-09 01:53:51 --> Total execution time: 0.3935
INFO - 2020-02-09 01:54:35 --> Config Class Initialized
INFO - 2020-02-09 01:54:35 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:54:35 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:54:35 --> Utf8 Class Initialized
INFO - 2020-02-09 01:54:35 --> URI Class Initialized
INFO - 2020-02-09 01:54:35 --> Router Class Initialized
INFO - 2020-02-09 01:54:35 --> Output Class Initialized
INFO - 2020-02-09 01:54:35 --> Security Class Initialized
DEBUG - 2020-02-09 01:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:54:35 --> Input Class Initialized
INFO - 2020-02-09 01:54:35 --> Language Class Initialized
INFO - 2020-02-09 01:54:35 --> Language Class Initialized
INFO - 2020-02-09 01:54:35 --> Config Class Initialized
INFO - 2020-02-09 01:54:35 --> Loader Class Initialized
INFO - 2020-02-09 01:54:35 --> Helper loaded: url_helper
INFO - 2020-02-09 01:54:35 --> Helper loaded: file_helper
INFO - 2020-02-09 01:54:35 --> Helper loaded: form_helper
INFO - 2020-02-09 01:54:35 --> Helper loaded: my_helper
INFO - 2020-02-09 01:54:35 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:54:35 --> Controller Class Initialized
DEBUG - 2020-02-09 01:54:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:54:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:54:35 --> Final output sent to browser
DEBUG - 2020-02-09 01:54:35 --> Total execution time: 0.4025
INFO - 2020-02-09 01:54:48 --> Config Class Initialized
INFO - 2020-02-09 01:54:48 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:54:48 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:54:48 --> Utf8 Class Initialized
INFO - 2020-02-09 01:54:48 --> URI Class Initialized
INFO - 2020-02-09 01:54:48 --> Router Class Initialized
INFO - 2020-02-09 01:54:48 --> Output Class Initialized
INFO - 2020-02-09 01:54:48 --> Security Class Initialized
DEBUG - 2020-02-09 01:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:54:48 --> Input Class Initialized
INFO - 2020-02-09 01:54:48 --> Language Class Initialized
INFO - 2020-02-09 01:54:48 --> Language Class Initialized
INFO - 2020-02-09 01:54:48 --> Config Class Initialized
INFO - 2020-02-09 01:54:48 --> Loader Class Initialized
INFO - 2020-02-09 01:54:49 --> Helper loaded: url_helper
INFO - 2020-02-09 01:54:49 --> Helper loaded: file_helper
INFO - 2020-02-09 01:54:49 --> Helper loaded: form_helper
INFO - 2020-02-09 01:54:49 --> Helper loaded: my_helper
INFO - 2020-02-09 01:54:49 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:54:49 --> Controller Class Initialized
DEBUG - 2020-02-09 01:54:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:54:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:54:49 --> Final output sent to browser
DEBUG - 2020-02-09 01:54:49 --> Total execution time: 0.3896
INFO - 2020-02-09 01:55:46 --> Config Class Initialized
INFO - 2020-02-09 01:55:46 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:55:46 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:55:46 --> Utf8 Class Initialized
INFO - 2020-02-09 01:55:46 --> URI Class Initialized
INFO - 2020-02-09 01:55:46 --> Router Class Initialized
INFO - 2020-02-09 01:55:46 --> Output Class Initialized
INFO - 2020-02-09 01:55:47 --> Security Class Initialized
DEBUG - 2020-02-09 01:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:55:47 --> Input Class Initialized
INFO - 2020-02-09 01:55:47 --> Language Class Initialized
INFO - 2020-02-09 01:55:47 --> Language Class Initialized
INFO - 2020-02-09 01:55:47 --> Config Class Initialized
INFO - 2020-02-09 01:55:47 --> Loader Class Initialized
INFO - 2020-02-09 01:55:47 --> Helper loaded: url_helper
INFO - 2020-02-09 01:55:47 --> Helper loaded: file_helper
INFO - 2020-02-09 01:55:47 --> Helper loaded: form_helper
INFO - 2020-02-09 01:55:47 --> Helper loaded: my_helper
INFO - 2020-02-09 01:55:47 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:55:47 --> Controller Class Initialized
DEBUG - 2020-02-09 01:55:47 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:55:47 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:55:47 --> Final output sent to browser
DEBUG - 2020-02-09 01:55:47 --> Total execution time: 0.4041
INFO - 2020-02-09 01:56:11 --> Config Class Initialized
INFO - 2020-02-09 01:56:11 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:56:11 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:56:11 --> Utf8 Class Initialized
INFO - 2020-02-09 01:56:11 --> URI Class Initialized
INFO - 2020-02-09 01:56:11 --> Router Class Initialized
INFO - 2020-02-09 01:56:12 --> Output Class Initialized
INFO - 2020-02-09 01:56:12 --> Security Class Initialized
DEBUG - 2020-02-09 01:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:56:12 --> Input Class Initialized
INFO - 2020-02-09 01:56:12 --> Language Class Initialized
INFO - 2020-02-09 01:56:12 --> Language Class Initialized
INFO - 2020-02-09 01:56:12 --> Config Class Initialized
INFO - 2020-02-09 01:56:12 --> Loader Class Initialized
INFO - 2020-02-09 01:56:12 --> Helper loaded: url_helper
INFO - 2020-02-09 01:56:12 --> Helper loaded: file_helper
INFO - 2020-02-09 01:56:12 --> Helper loaded: form_helper
INFO - 2020-02-09 01:56:12 --> Helper loaded: my_helper
INFO - 2020-02-09 01:56:12 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:56:12 --> Controller Class Initialized
DEBUG - 2020-02-09 01:56:12 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:56:12 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:56:12 --> Final output sent to browser
DEBUG - 2020-02-09 01:56:12 --> Total execution time: 0.3954
INFO - 2020-02-09 01:56:28 --> Config Class Initialized
INFO - 2020-02-09 01:56:28 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:56:28 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:56:28 --> Utf8 Class Initialized
INFO - 2020-02-09 01:56:28 --> URI Class Initialized
INFO - 2020-02-09 01:56:28 --> Router Class Initialized
INFO - 2020-02-09 01:56:28 --> Output Class Initialized
INFO - 2020-02-09 01:56:28 --> Security Class Initialized
DEBUG - 2020-02-09 01:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:56:28 --> Input Class Initialized
INFO - 2020-02-09 01:56:28 --> Language Class Initialized
INFO - 2020-02-09 01:56:28 --> Language Class Initialized
INFO - 2020-02-09 01:56:28 --> Config Class Initialized
INFO - 2020-02-09 01:56:28 --> Loader Class Initialized
INFO - 2020-02-09 01:56:28 --> Helper loaded: url_helper
INFO - 2020-02-09 01:56:28 --> Helper loaded: file_helper
INFO - 2020-02-09 01:56:28 --> Helper loaded: form_helper
INFO - 2020-02-09 01:56:28 --> Helper loaded: my_helper
INFO - 2020-02-09 01:56:29 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:56:29 --> Controller Class Initialized
DEBUG - 2020-02-09 01:56:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:56:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:56:29 --> Final output sent to browser
DEBUG - 2020-02-09 01:56:29 --> Total execution time: 0.3751
INFO - 2020-02-09 01:58:45 --> Config Class Initialized
INFO - 2020-02-09 01:58:45 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:58:45 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:58:45 --> Utf8 Class Initialized
INFO - 2020-02-09 01:58:45 --> URI Class Initialized
INFO - 2020-02-09 01:58:45 --> Router Class Initialized
INFO - 2020-02-09 01:58:45 --> Output Class Initialized
INFO - 2020-02-09 01:58:45 --> Security Class Initialized
DEBUG - 2020-02-09 01:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:58:45 --> Input Class Initialized
INFO - 2020-02-09 01:58:45 --> Language Class Initialized
INFO - 2020-02-09 01:58:45 --> Language Class Initialized
INFO - 2020-02-09 01:58:45 --> Config Class Initialized
INFO - 2020-02-09 01:58:45 --> Loader Class Initialized
INFO - 2020-02-09 01:58:45 --> Helper loaded: url_helper
INFO - 2020-02-09 01:58:45 --> Helper loaded: file_helper
INFO - 2020-02-09 01:58:45 --> Helper loaded: form_helper
INFO - 2020-02-09 01:58:45 --> Helper loaded: my_helper
INFO - 2020-02-09 01:58:45 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:58:45 --> Controller Class Initialized
DEBUG - 2020-02-09 01:58:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:58:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:58:46 --> Final output sent to browser
DEBUG - 2020-02-09 01:58:46 --> Total execution time: 0.3811
INFO - 2020-02-09 01:59:45 --> Config Class Initialized
INFO - 2020-02-09 01:59:45 --> Hooks Class Initialized
DEBUG - 2020-02-09 01:59:45 --> UTF-8 Support Enabled
INFO - 2020-02-09 01:59:45 --> Utf8 Class Initialized
INFO - 2020-02-09 01:59:45 --> URI Class Initialized
INFO - 2020-02-09 01:59:45 --> Router Class Initialized
INFO - 2020-02-09 01:59:45 --> Output Class Initialized
INFO - 2020-02-09 01:59:45 --> Security Class Initialized
DEBUG - 2020-02-09 01:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 01:59:45 --> Input Class Initialized
INFO - 2020-02-09 01:59:46 --> Language Class Initialized
INFO - 2020-02-09 01:59:46 --> Language Class Initialized
INFO - 2020-02-09 01:59:46 --> Config Class Initialized
INFO - 2020-02-09 01:59:46 --> Loader Class Initialized
INFO - 2020-02-09 01:59:46 --> Helper loaded: url_helper
INFO - 2020-02-09 01:59:46 --> Helper loaded: file_helper
INFO - 2020-02-09 01:59:46 --> Helper loaded: form_helper
INFO - 2020-02-09 01:59:46 --> Helper loaded: my_helper
INFO - 2020-02-09 01:59:46 --> Database Driver Class Initialized
DEBUG - 2020-02-09 01:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 01:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 01:59:46 --> Controller Class Initialized
DEBUG - 2020-02-09 01:59:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 01:59:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 01:59:46 --> Final output sent to browser
DEBUG - 2020-02-09 01:59:46 --> Total execution time: 0.3780
INFO - 2020-02-09 02:00:45 --> Config Class Initialized
INFO - 2020-02-09 02:00:45 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:00:45 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:00:45 --> Utf8 Class Initialized
INFO - 2020-02-09 02:00:45 --> URI Class Initialized
INFO - 2020-02-09 02:00:45 --> Router Class Initialized
INFO - 2020-02-09 02:00:45 --> Output Class Initialized
INFO - 2020-02-09 02:00:45 --> Security Class Initialized
DEBUG - 2020-02-09 02:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:00:45 --> Input Class Initialized
INFO - 2020-02-09 02:00:45 --> Language Class Initialized
INFO - 2020-02-09 02:00:45 --> Language Class Initialized
INFO - 2020-02-09 02:00:45 --> Config Class Initialized
INFO - 2020-02-09 02:00:45 --> Loader Class Initialized
INFO - 2020-02-09 02:00:45 --> Helper loaded: url_helper
INFO - 2020-02-09 02:00:45 --> Helper loaded: file_helper
INFO - 2020-02-09 02:00:45 --> Helper loaded: form_helper
INFO - 2020-02-09 02:00:45 --> Helper loaded: my_helper
INFO - 2020-02-09 02:00:45 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:00:45 --> Controller Class Initialized
DEBUG - 2020-02-09 02:00:45 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 02:00:45 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 02:00:45 --> Final output sent to browser
DEBUG - 2020-02-09 02:00:45 --> Total execution time: 0.4281
INFO - 2020-02-09 02:00:49 --> Config Class Initialized
INFO - 2020-02-09 02:00:50 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:00:50 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:00:50 --> Utf8 Class Initialized
INFO - 2020-02-09 02:00:50 --> URI Class Initialized
INFO - 2020-02-09 02:00:50 --> Router Class Initialized
INFO - 2020-02-09 02:00:50 --> Output Class Initialized
INFO - 2020-02-09 02:00:50 --> Security Class Initialized
DEBUG - 2020-02-09 02:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:00:50 --> Input Class Initialized
INFO - 2020-02-09 02:00:50 --> Language Class Initialized
INFO - 2020-02-09 02:00:50 --> Language Class Initialized
INFO - 2020-02-09 02:00:50 --> Config Class Initialized
INFO - 2020-02-09 02:00:50 --> Loader Class Initialized
INFO - 2020-02-09 02:00:50 --> Helper loaded: url_helper
INFO - 2020-02-09 02:00:50 --> Helper loaded: file_helper
INFO - 2020-02-09 02:00:50 --> Helper loaded: form_helper
INFO - 2020-02-09 02:00:50 --> Helper loaded: my_helper
INFO - 2020-02-09 02:00:50 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:00:50 --> Controller Class Initialized
DEBUG - 2020-02-09 02:00:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 02:00:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 02:00:50 --> Final output sent to browser
DEBUG - 2020-02-09 02:00:50 --> Total execution time: 0.3819
INFO - 2020-02-09 02:01:02 --> Config Class Initialized
INFO - 2020-02-09 02:01:02 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:01:02 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:01:02 --> Utf8 Class Initialized
INFO - 2020-02-09 02:01:02 --> URI Class Initialized
INFO - 2020-02-09 02:01:02 --> Router Class Initialized
INFO - 2020-02-09 02:01:02 --> Output Class Initialized
INFO - 2020-02-09 02:01:02 --> Security Class Initialized
DEBUG - 2020-02-09 02:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:01:02 --> Input Class Initialized
INFO - 2020-02-09 02:01:02 --> Language Class Initialized
INFO - 2020-02-09 02:01:02 --> Language Class Initialized
INFO - 2020-02-09 02:01:02 --> Config Class Initialized
INFO - 2020-02-09 02:01:02 --> Loader Class Initialized
INFO - 2020-02-09 02:01:02 --> Helper loaded: url_helper
INFO - 2020-02-09 02:01:02 --> Helper loaded: file_helper
INFO - 2020-02-09 02:01:02 --> Helper loaded: form_helper
INFO - 2020-02-09 02:01:02 --> Helper loaded: my_helper
INFO - 2020-02-09 02:01:02 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:01:02 --> Controller Class Initialized
DEBUG - 2020-02-09 02:01:02 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 02:01:02 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 02:01:02 --> Final output sent to browser
DEBUG - 2020-02-09 02:01:02 --> Total execution time: 0.3885
INFO - 2020-02-09 02:01:08 --> Config Class Initialized
INFO - 2020-02-09 02:01:08 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:01:08 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:01:08 --> Utf8 Class Initialized
INFO - 2020-02-09 02:01:08 --> URI Class Initialized
INFO - 2020-02-09 02:01:08 --> Router Class Initialized
INFO - 2020-02-09 02:01:08 --> Output Class Initialized
INFO - 2020-02-09 02:01:08 --> Security Class Initialized
DEBUG - 2020-02-09 02:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:01:08 --> Input Class Initialized
INFO - 2020-02-09 02:01:08 --> Language Class Initialized
INFO - 2020-02-09 02:01:08 --> Language Class Initialized
INFO - 2020-02-09 02:01:08 --> Config Class Initialized
INFO - 2020-02-09 02:01:08 --> Loader Class Initialized
INFO - 2020-02-09 02:01:08 --> Helper loaded: url_helper
INFO - 2020-02-09 02:01:08 --> Helper loaded: file_helper
INFO - 2020-02-09 02:01:09 --> Helper loaded: form_helper
INFO - 2020-02-09 02:01:09 --> Helper loaded: my_helper
INFO - 2020-02-09 02:01:09 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:01:09 --> Controller Class Initialized
DEBUG - 2020-02-09 02:01:09 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 02:01:09 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 02:01:09 --> Final output sent to browser
DEBUG - 2020-02-09 02:01:09 --> Total execution time: 0.3971
INFO - 2020-02-09 02:01:34 --> Config Class Initialized
INFO - 2020-02-09 02:01:34 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:01:34 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:01:34 --> Utf8 Class Initialized
INFO - 2020-02-09 02:01:34 --> URI Class Initialized
INFO - 2020-02-09 02:01:35 --> Router Class Initialized
INFO - 2020-02-09 02:01:35 --> Output Class Initialized
INFO - 2020-02-09 02:01:35 --> Security Class Initialized
DEBUG - 2020-02-09 02:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:01:35 --> Input Class Initialized
INFO - 2020-02-09 02:01:35 --> Language Class Initialized
INFO - 2020-02-09 02:01:35 --> Language Class Initialized
INFO - 2020-02-09 02:01:35 --> Config Class Initialized
INFO - 2020-02-09 02:01:35 --> Loader Class Initialized
INFO - 2020-02-09 02:01:35 --> Helper loaded: url_helper
INFO - 2020-02-09 02:01:35 --> Helper loaded: file_helper
INFO - 2020-02-09 02:01:35 --> Helper loaded: form_helper
INFO - 2020-02-09 02:01:35 --> Helper loaded: my_helper
INFO - 2020-02-09 02:01:35 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:01:35 --> Controller Class Initialized
DEBUG - 2020-02-09 02:01:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 02:01:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 02:01:35 --> Final output sent to browser
DEBUG - 2020-02-09 02:01:35 --> Total execution time: 0.3924
INFO - 2020-02-09 02:01:51 --> Config Class Initialized
INFO - 2020-02-09 02:01:51 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:01:51 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:01:51 --> Utf8 Class Initialized
INFO - 2020-02-09 02:01:51 --> URI Class Initialized
INFO - 2020-02-09 02:01:51 --> Router Class Initialized
INFO - 2020-02-09 02:01:51 --> Output Class Initialized
INFO - 2020-02-09 02:01:51 --> Security Class Initialized
DEBUG - 2020-02-09 02:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:01:51 --> Input Class Initialized
INFO - 2020-02-09 02:01:51 --> Language Class Initialized
INFO - 2020-02-09 02:01:52 --> Language Class Initialized
INFO - 2020-02-09 02:01:52 --> Config Class Initialized
INFO - 2020-02-09 02:01:52 --> Loader Class Initialized
INFO - 2020-02-09 02:01:52 --> Helper loaded: url_helper
INFO - 2020-02-09 02:01:52 --> Helper loaded: file_helper
INFO - 2020-02-09 02:01:52 --> Helper loaded: form_helper
INFO - 2020-02-09 02:01:52 --> Helper loaded: my_helper
INFO - 2020-02-09 02:01:52 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:01:52 --> Controller Class Initialized
DEBUG - 2020-02-09 02:01:52 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 02:01:52 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 02:01:52 --> Final output sent to browser
DEBUG - 2020-02-09 02:01:52 --> Total execution time: 0.3963
INFO - 2020-02-09 02:02:09 --> Config Class Initialized
INFO - 2020-02-09 02:02:09 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:02:09 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:02:09 --> Utf8 Class Initialized
INFO - 2020-02-09 02:02:09 --> URI Class Initialized
INFO - 2020-02-09 02:02:09 --> Router Class Initialized
INFO - 2020-02-09 02:02:09 --> Output Class Initialized
INFO - 2020-02-09 02:02:09 --> Security Class Initialized
DEBUG - 2020-02-09 02:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:02:09 --> Input Class Initialized
INFO - 2020-02-09 02:02:09 --> Language Class Initialized
INFO - 2020-02-09 02:02:09 --> Language Class Initialized
INFO - 2020-02-09 02:02:09 --> Config Class Initialized
INFO - 2020-02-09 02:02:09 --> Loader Class Initialized
INFO - 2020-02-09 02:02:09 --> Helper loaded: url_helper
INFO - 2020-02-09 02:02:09 --> Helper loaded: file_helper
INFO - 2020-02-09 02:02:09 --> Helper loaded: form_helper
INFO - 2020-02-09 02:02:09 --> Helper loaded: my_helper
INFO - 2020-02-09 02:02:09 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:02:10 --> Controller Class Initialized
DEBUG - 2020-02-09 02:02:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 02:02:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 02:02:10 --> Final output sent to browser
DEBUG - 2020-02-09 02:02:10 --> Total execution time: 0.4056
INFO - 2020-02-09 02:02:12 --> Config Class Initialized
INFO - 2020-02-09 02:02:12 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:02:12 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:02:12 --> Utf8 Class Initialized
INFO - 2020-02-09 02:02:12 --> URI Class Initialized
INFO - 2020-02-09 02:02:12 --> Router Class Initialized
INFO - 2020-02-09 02:02:12 --> Output Class Initialized
INFO - 2020-02-09 02:02:12 --> Security Class Initialized
DEBUG - 2020-02-09 02:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:02:12 --> Input Class Initialized
INFO - 2020-02-09 02:02:12 --> Language Class Initialized
INFO - 2020-02-09 02:02:12 --> Language Class Initialized
INFO - 2020-02-09 02:02:12 --> Config Class Initialized
INFO - 2020-02-09 02:02:12 --> Loader Class Initialized
INFO - 2020-02-09 02:02:12 --> Helper loaded: url_helper
INFO - 2020-02-09 02:02:12 --> Helper loaded: file_helper
INFO - 2020-02-09 02:02:12 --> Helper loaded: form_helper
INFO - 2020-02-09 02:02:12 --> Helper loaded: my_helper
INFO - 2020-02-09 02:02:12 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:02:12 --> Controller Class Initialized
DEBUG - 2020-02-09 02:02:12 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 02:02:12 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 02:02:12 --> Final output sent to browser
DEBUG - 2020-02-09 02:02:12 --> Total execution time: 0.3865
INFO - 2020-02-09 02:02:21 --> Config Class Initialized
INFO - 2020-02-09 02:02:21 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:02:21 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:02:21 --> Utf8 Class Initialized
INFO - 2020-02-09 02:02:21 --> URI Class Initialized
INFO - 2020-02-09 02:02:21 --> Router Class Initialized
INFO - 2020-02-09 02:02:21 --> Output Class Initialized
INFO - 2020-02-09 02:02:21 --> Security Class Initialized
DEBUG - 2020-02-09 02:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:02:21 --> Input Class Initialized
INFO - 2020-02-09 02:02:21 --> Language Class Initialized
INFO - 2020-02-09 02:02:21 --> Language Class Initialized
INFO - 2020-02-09 02:02:21 --> Config Class Initialized
INFO - 2020-02-09 02:02:21 --> Loader Class Initialized
INFO - 2020-02-09 02:02:21 --> Helper loaded: url_helper
INFO - 2020-02-09 02:02:21 --> Helper loaded: file_helper
INFO - 2020-02-09 02:02:21 --> Helper loaded: form_helper
INFO - 2020-02-09 02:02:21 --> Helper loaded: my_helper
INFO - 2020-02-09 02:02:21 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:02:21 --> Controller Class Initialized
DEBUG - 2020-02-09 02:02:21 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 02:02:21 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 02:02:21 --> Final output sent to browser
DEBUG - 2020-02-09 02:02:21 --> Total execution time: 0.4080
INFO - 2020-02-09 02:02:50 --> Config Class Initialized
INFO - 2020-02-09 02:02:50 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:02:50 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:02:50 --> Utf8 Class Initialized
INFO - 2020-02-09 02:02:50 --> URI Class Initialized
INFO - 2020-02-09 02:02:50 --> Router Class Initialized
INFO - 2020-02-09 02:02:50 --> Output Class Initialized
INFO - 2020-02-09 02:02:50 --> Security Class Initialized
DEBUG - 2020-02-09 02:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:02:50 --> Input Class Initialized
INFO - 2020-02-09 02:02:50 --> Language Class Initialized
INFO - 2020-02-09 02:02:50 --> Language Class Initialized
INFO - 2020-02-09 02:02:50 --> Config Class Initialized
INFO - 2020-02-09 02:02:50 --> Loader Class Initialized
INFO - 2020-02-09 02:02:50 --> Helper loaded: url_helper
INFO - 2020-02-09 02:02:50 --> Helper loaded: file_helper
INFO - 2020-02-09 02:02:50 --> Helper loaded: form_helper
INFO - 2020-02-09 02:02:50 --> Helper loaded: my_helper
INFO - 2020-02-09 02:02:50 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:02:50 --> Controller Class Initialized
DEBUG - 2020-02-09 02:02:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 02:02:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 02:02:50 --> Final output sent to browser
DEBUG - 2020-02-09 02:02:50 --> Total execution time: 0.3840
INFO - 2020-02-09 02:02:55 --> Config Class Initialized
INFO - 2020-02-09 02:02:55 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:02:55 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:02:55 --> Utf8 Class Initialized
INFO - 2020-02-09 02:02:55 --> URI Class Initialized
INFO - 2020-02-09 02:02:55 --> Router Class Initialized
INFO - 2020-02-09 02:02:55 --> Output Class Initialized
INFO - 2020-02-09 02:02:55 --> Security Class Initialized
DEBUG - 2020-02-09 02:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:02:55 --> Input Class Initialized
INFO - 2020-02-09 02:02:55 --> Language Class Initialized
INFO - 2020-02-09 02:02:55 --> Language Class Initialized
INFO - 2020-02-09 02:02:55 --> Config Class Initialized
INFO - 2020-02-09 02:02:55 --> Loader Class Initialized
INFO - 2020-02-09 02:02:55 --> Helper loaded: url_helper
INFO - 2020-02-09 02:02:55 --> Helper loaded: file_helper
INFO - 2020-02-09 02:02:55 --> Helper loaded: form_helper
INFO - 2020-02-09 02:02:55 --> Helper loaded: my_helper
INFO - 2020-02-09 02:02:55 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:02:55 --> Controller Class Initialized
DEBUG - 2020-02-09 02:02:55 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 02:02:55 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 02:02:55 --> Final output sent to browser
DEBUG - 2020-02-09 02:02:56 --> Total execution time: 0.3963
INFO - 2020-02-09 02:02:57 --> Config Class Initialized
INFO - 2020-02-09 02:02:57 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:02:57 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:02:57 --> Utf8 Class Initialized
INFO - 2020-02-09 02:02:57 --> URI Class Initialized
INFO - 2020-02-09 02:02:57 --> Router Class Initialized
INFO - 2020-02-09 02:02:57 --> Output Class Initialized
INFO - 2020-02-09 02:02:57 --> Security Class Initialized
DEBUG - 2020-02-09 02:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:02:57 --> Input Class Initialized
INFO - 2020-02-09 02:02:57 --> Language Class Initialized
INFO - 2020-02-09 02:02:57 --> Language Class Initialized
INFO - 2020-02-09 02:02:57 --> Config Class Initialized
INFO - 2020-02-09 02:02:57 --> Loader Class Initialized
INFO - 2020-02-09 02:02:57 --> Helper loaded: url_helper
INFO - 2020-02-09 02:02:57 --> Helper loaded: file_helper
INFO - 2020-02-09 02:02:57 --> Helper loaded: form_helper
INFO - 2020-02-09 02:02:57 --> Helper loaded: my_helper
INFO - 2020-02-09 02:02:57 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:02:57 --> Controller Class Initialized
DEBUG - 2020-02-09 02:02:57 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 02:02:57 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 02:02:58 --> Final output sent to browser
DEBUG - 2020-02-09 02:02:58 --> Total execution time: 0.4436
INFO - 2020-02-09 02:03:22 --> Config Class Initialized
INFO - 2020-02-09 02:03:22 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:03:22 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:03:22 --> Utf8 Class Initialized
INFO - 2020-02-09 02:03:22 --> URI Class Initialized
INFO - 2020-02-09 02:03:22 --> Router Class Initialized
INFO - 2020-02-09 02:03:22 --> Output Class Initialized
INFO - 2020-02-09 02:03:22 --> Security Class Initialized
DEBUG - 2020-02-09 02:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:03:22 --> Input Class Initialized
INFO - 2020-02-09 02:03:22 --> Language Class Initialized
INFO - 2020-02-09 02:03:22 --> Language Class Initialized
INFO - 2020-02-09 02:03:22 --> Config Class Initialized
INFO - 2020-02-09 02:03:22 --> Loader Class Initialized
INFO - 2020-02-09 02:03:22 --> Helper loaded: url_helper
INFO - 2020-02-09 02:03:22 --> Helper loaded: file_helper
INFO - 2020-02-09 02:03:22 --> Helper loaded: form_helper
INFO - 2020-02-09 02:03:22 --> Helper loaded: my_helper
INFO - 2020-02-09 02:03:22 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:03:22 --> Controller Class Initialized
DEBUG - 2020-02-09 02:03:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 02:03:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 02:03:22 --> Final output sent to browser
DEBUG - 2020-02-09 02:03:22 --> Total execution time: 0.3987
INFO - 2020-02-09 02:03:30 --> Config Class Initialized
INFO - 2020-02-09 02:03:30 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:03:30 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:03:30 --> Utf8 Class Initialized
INFO - 2020-02-09 02:03:30 --> URI Class Initialized
INFO - 2020-02-09 02:03:30 --> Router Class Initialized
INFO - 2020-02-09 02:03:31 --> Output Class Initialized
INFO - 2020-02-09 02:03:31 --> Security Class Initialized
DEBUG - 2020-02-09 02:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:03:31 --> Input Class Initialized
INFO - 2020-02-09 02:03:31 --> Language Class Initialized
INFO - 2020-02-09 02:03:31 --> Language Class Initialized
INFO - 2020-02-09 02:03:31 --> Config Class Initialized
INFO - 2020-02-09 02:03:31 --> Loader Class Initialized
INFO - 2020-02-09 02:03:31 --> Helper loaded: url_helper
INFO - 2020-02-09 02:03:31 --> Helper loaded: file_helper
INFO - 2020-02-09 02:03:31 --> Helper loaded: form_helper
INFO - 2020-02-09 02:03:31 --> Helper loaded: my_helper
INFO - 2020-02-09 02:03:31 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:03:31 --> Controller Class Initialized
DEBUG - 2020-02-09 02:03:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 02:03:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 02:03:31 --> Final output sent to browser
DEBUG - 2020-02-09 02:03:31 --> Total execution time: 0.3891
INFO - 2020-02-09 02:07:08 --> Config Class Initialized
INFO - 2020-02-09 02:07:08 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:07:08 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:07:08 --> Utf8 Class Initialized
INFO - 2020-02-09 02:07:08 --> URI Class Initialized
INFO - 2020-02-09 02:07:08 --> Router Class Initialized
INFO - 2020-02-09 02:07:08 --> Output Class Initialized
INFO - 2020-02-09 02:07:08 --> Security Class Initialized
DEBUG - 2020-02-09 02:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:07:08 --> Input Class Initialized
INFO - 2020-02-09 02:07:08 --> Language Class Initialized
INFO - 2020-02-09 02:07:08 --> Language Class Initialized
INFO - 2020-02-09 02:07:08 --> Config Class Initialized
INFO - 2020-02-09 02:07:08 --> Loader Class Initialized
INFO - 2020-02-09 02:07:08 --> Helper loaded: url_helper
INFO - 2020-02-09 02:07:08 --> Helper loaded: file_helper
INFO - 2020-02-09 02:07:08 --> Helper loaded: form_helper
INFO - 2020-02-09 02:07:08 --> Helper loaded: my_helper
INFO - 2020-02-09 02:07:08 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:07:08 --> Controller Class Initialized
DEBUG - 2020-02-09 02:07:08 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 02:07:08 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 02:07:08 --> Final output sent to browser
DEBUG - 2020-02-09 02:07:09 --> Total execution time: 0.4314
INFO - 2020-02-09 02:08:12 --> Config Class Initialized
INFO - 2020-02-09 02:08:12 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:08:12 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:08:12 --> Utf8 Class Initialized
INFO - 2020-02-09 02:08:12 --> URI Class Initialized
INFO - 2020-02-09 02:08:12 --> Router Class Initialized
INFO - 2020-02-09 02:08:12 --> Output Class Initialized
INFO - 2020-02-09 02:08:12 --> Security Class Initialized
DEBUG - 2020-02-09 02:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:08:12 --> Input Class Initialized
INFO - 2020-02-09 02:08:12 --> Language Class Initialized
INFO - 2020-02-09 02:08:12 --> Language Class Initialized
INFO - 2020-02-09 02:08:12 --> Config Class Initialized
INFO - 2020-02-09 02:08:12 --> Loader Class Initialized
INFO - 2020-02-09 02:08:12 --> Helper loaded: url_helper
INFO - 2020-02-09 02:08:12 --> Helper loaded: file_helper
INFO - 2020-02-09 02:08:12 --> Helper loaded: form_helper
INFO - 2020-02-09 02:08:12 --> Helper loaded: my_helper
INFO - 2020-02-09 02:08:12 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:08:12 --> Controller Class Initialized
DEBUG - 2020-02-09 02:08:12 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 02:08:12 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 02:08:12 --> Final output sent to browser
DEBUG - 2020-02-09 02:08:12 --> Total execution time: 0.3912
INFO - 2020-02-09 02:08:28 --> Config Class Initialized
INFO - 2020-02-09 02:08:28 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:08:28 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:08:28 --> Utf8 Class Initialized
INFO - 2020-02-09 02:08:28 --> URI Class Initialized
INFO - 2020-02-09 02:08:28 --> Router Class Initialized
INFO - 2020-02-09 02:08:28 --> Output Class Initialized
INFO - 2020-02-09 02:08:28 --> Security Class Initialized
DEBUG - 2020-02-09 02:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:08:28 --> Input Class Initialized
INFO - 2020-02-09 02:08:28 --> Language Class Initialized
INFO - 2020-02-09 02:08:28 --> Language Class Initialized
INFO - 2020-02-09 02:08:28 --> Config Class Initialized
INFO - 2020-02-09 02:08:28 --> Loader Class Initialized
INFO - 2020-02-09 02:08:28 --> Helper loaded: url_helper
INFO - 2020-02-09 02:08:28 --> Helper loaded: file_helper
INFO - 2020-02-09 02:08:28 --> Helper loaded: form_helper
INFO - 2020-02-09 02:08:28 --> Helper loaded: my_helper
INFO - 2020-02-09 02:08:28 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:08:28 --> Controller Class Initialized
DEBUG - 2020-02-09 02:08:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 02:08:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 02:08:28 --> Final output sent to browser
DEBUG - 2020-02-09 02:08:28 --> Total execution time: 0.3869
INFO - 2020-02-09 02:08:33 --> Config Class Initialized
INFO - 2020-02-09 02:08:33 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:08:33 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:08:33 --> Utf8 Class Initialized
INFO - 2020-02-09 02:08:33 --> URI Class Initialized
INFO - 2020-02-09 02:08:33 --> Router Class Initialized
INFO - 2020-02-09 02:08:33 --> Output Class Initialized
INFO - 2020-02-09 02:08:33 --> Security Class Initialized
DEBUG - 2020-02-09 02:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:08:33 --> Input Class Initialized
INFO - 2020-02-09 02:08:33 --> Language Class Initialized
INFO - 2020-02-09 02:08:33 --> Language Class Initialized
INFO - 2020-02-09 02:08:33 --> Config Class Initialized
INFO - 2020-02-09 02:08:33 --> Loader Class Initialized
INFO - 2020-02-09 02:08:33 --> Helper loaded: url_helper
INFO - 2020-02-09 02:08:33 --> Helper loaded: file_helper
INFO - 2020-02-09 02:08:33 --> Helper loaded: form_helper
INFO - 2020-02-09 02:08:33 --> Helper loaded: my_helper
INFO - 2020-02-09 02:08:33 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:08:33 --> Controller Class Initialized
DEBUG - 2020-02-09 02:08:33 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 02:08:33 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 02:08:33 --> Final output sent to browser
DEBUG - 2020-02-09 02:08:33 --> Total execution time: 0.4053
INFO - 2020-02-09 02:09:07 --> Config Class Initialized
INFO - 2020-02-09 02:09:07 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:09:07 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:09:07 --> Utf8 Class Initialized
INFO - 2020-02-09 02:09:07 --> URI Class Initialized
INFO - 2020-02-09 02:09:07 --> Router Class Initialized
INFO - 2020-02-09 02:09:07 --> Output Class Initialized
INFO - 2020-02-09 02:09:07 --> Security Class Initialized
DEBUG - 2020-02-09 02:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:09:07 --> Input Class Initialized
INFO - 2020-02-09 02:09:07 --> Language Class Initialized
INFO - 2020-02-09 02:09:07 --> Language Class Initialized
INFO - 2020-02-09 02:09:07 --> Config Class Initialized
INFO - 2020-02-09 02:09:07 --> Loader Class Initialized
INFO - 2020-02-09 02:09:07 --> Helper loaded: url_helper
INFO - 2020-02-09 02:09:07 --> Helper loaded: file_helper
INFO - 2020-02-09 02:09:07 --> Helper loaded: form_helper
INFO - 2020-02-09 02:09:08 --> Helper loaded: my_helper
INFO - 2020-02-09 02:09:08 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:09:08 --> Controller Class Initialized
DEBUG - 2020-02-09 02:09:08 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 02:09:08 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 02:09:08 --> Final output sent to browser
DEBUG - 2020-02-09 02:09:08 --> Total execution time: 0.5176
INFO - 2020-02-09 02:09:23 --> Config Class Initialized
INFO - 2020-02-09 02:09:23 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:09:23 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:09:23 --> Utf8 Class Initialized
INFO - 2020-02-09 02:09:23 --> URI Class Initialized
INFO - 2020-02-09 02:09:23 --> Router Class Initialized
INFO - 2020-02-09 02:09:23 --> Output Class Initialized
INFO - 2020-02-09 02:09:23 --> Security Class Initialized
DEBUG - 2020-02-09 02:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:09:23 --> Input Class Initialized
INFO - 2020-02-09 02:09:23 --> Language Class Initialized
INFO - 2020-02-09 02:09:23 --> Language Class Initialized
INFO - 2020-02-09 02:09:23 --> Config Class Initialized
INFO - 2020-02-09 02:09:23 --> Loader Class Initialized
INFO - 2020-02-09 02:09:23 --> Helper loaded: url_helper
INFO - 2020-02-09 02:09:23 --> Helper loaded: file_helper
INFO - 2020-02-09 02:09:23 --> Helper loaded: form_helper
INFO - 2020-02-09 02:09:23 --> Helper loaded: my_helper
INFO - 2020-02-09 02:09:23 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:09:23 --> Controller Class Initialized
INFO - 2020-02-09 02:09:23 --> Helper loaded: cookie_helper
INFO - 2020-02-09 02:09:23 --> Final output sent to browser
DEBUG - 2020-02-09 02:09:23 --> Total execution time: 0.4183
INFO - 2020-02-09 02:09:24 --> Config Class Initialized
INFO - 2020-02-09 02:09:24 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:09:24 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:09:24 --> Utf8 Class Initialized
INFO - 2020-02-09 02:09:24 --> URI Class Initialized
INFO - 2020-02-09 02:09:24 --> Router Class Initialized
INFO - 2020-02-09 02:09:24 --> Output Class Initialized
INFO - 2020-02-09 02:09:24 --> Security Class Initialized
DEBUG - 2020-02-09 02:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:09:24 --> Input Class Initialized
INFO - 2020-02-09 02:09:24 --> Language Class Initialized
INFO - 2020-02-09 02:09:24 --> Language Class Initialized
INFO - 2020-02-09 02:09:24 --> Config Class Initialized
INFO - 2020-02-09 02:09:24 --> Loader Class Initialized
INFO - 2020-02-09 02:09:24 --> Helper loaded: url_helper
INFO - 2020-02-09 02:09:24 --> Helper loaded: file_helper
INFO - 2020-02-09 02:09:24 --> Helper loaded: form_helper
INFO - 2020-02-09 02:09:24 --> Helper loaded: my_helper
INFO - 2020-02-09 02:09:24 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:09:24 --> Controller Class Initialized
DEBUG - 2020-02-09 02:09:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-09 02:09:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 02:09:24 --> Final output sent to browser
DEBUG - 2020-02-09 02:09:24 --> Total execution time: 0.5963
INFO - 2020-02-09 02:09:46 --> Config Class Initialized
INFO - 2020-02-09 02:09:46 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:09:46 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:09:46 --> Utf8 Class Initialized
INFO - 2020-02-09 02:09:46 --> URI Class Initialized
INFO - 2020-02-09 02:09:46 --> Router Class Initialized
INFO - 2020-02-09 02:09:46 --> Output Class Initialized
INFO - 2020-02-09 02:09:46 --> Security Class Initialized
DEBUG - 2020-02-09 02:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:09:46 --> Input Class Initialized
INFO - 2020-02-09 02:09:46 --> Language Class Initialized
INFO - 2020-02-09 02:09:46 --> Language Class Initialized
INFO - 2020-02-09 02:09:46 --> Config Class Initialized
INFO - 2020-02-09 02:09:46 --> Loader Class Initialized
INFO - 2020-02-09 02:09:46 --> Helper loaded: url_helper
INFO - 2020-02-09 02:09:46 --> Helper loaded: file_helper
INFO - 2020-02-09 02:09:46 --> Helper loaded: form_helper
INFO - 2020-02-09 02:09:46 --> Helper loaded: my_helper
INFO - 2020-02-09 02:09:46 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:09:46 --> Controller Class Initialized
DEBUG - 2020-02-09 02:09:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_guru/views/list.php
DEBUG - 2020-02-09 02:09:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 02:09:46 --> Final output sent to browser
DEBUG - 2020-02-09 02:09:46 --> Total execution time: 0.4304
INFO - 2020-02-09 02:09:47 --> Config Class Initialized
INFO - 2020-02-09 02:09:47 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:09:47 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:09:47 --> Utf8 Class Initialized
INFO - 2020-02-09 02:09:47 --> URI Class Initialized
INFO - 2020-02-09 02:09:47 --> Router Class Initialized
INFO - 2020-02-09 02:09:47 --> Output Class Initialized
INFO - 2020-02-09 02:09:47 --> Security Class Initialized
DEBUG - 2020-02-09 02:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:09:47 --> Input Class Initialized
INFO - 2020-02-09 02:09:47 --> Language Class Initialized
INFO - 2020-02-09 02:09:47 --> Language Class Initialized
INFO - 2020-02-09 02:09:47 --> Config Class Initialized
INFO - 2020-02-09 02:09:47 --> Loader Class Initialized
INFO - 2020-02-09 02:09:47 --> Helper loaded: url_helper
INFO - 2020-02-09 02:09:47 --> Helper loaded: file_helper
INFO - 2020-02-09 02:09:47 --> Helper loaded: form_helper
INFO - 2020-02-09 02:09:47 --> Helper loaded: my_helper
INFO - 2020-02-09 02:09:47 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:09:47 --> Controller Class Initialized
INFO - 2020-02-09 02:09:48 --> Config Class Initialized
INFO - 2020-02-09 02:09:48 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:09:48 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:09:48 --> Utf8 Class Initialized
INFO - 2020-02-09 02:09:48 --> URI Class Initialized
DEBUG - 2020-02-09 02:09:48 --> No URI present. Default controller set.
INFO - 2020-02-09 02:09:48 --> Router Class Initialized
INFO - 2020-02-09 02:09:48 --> Output Class Initialized
INFO - 2020-02-09 02:09:48 --> Security Class Initialized
DEBUG - 2020-02-09 02:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:09:48 --> Input Class Initialized
INFO - 2020-02-09 02:09:48 --> Language Class Initialized
INFO - 2020-02-09 02:09:48 --> Language Class Initialized
INFO - 2020-02-09 02:09:48 --> Config Class Initialized
INFO - 2020-02-09 02:09:48 --> Loader Class Initialized
INFO - 2020-02-09 02:09:48 --> Helper loaded: url_helper
INFO - 2020-02-09 02:09:48 --> Helper loaded: file_helper
INFO - 2020-02-09 02:09:48 --> Helper loaded: form_helper
INFO - 2020-02-09 02:09:48 --> Helper loaded: my_helper
INFO - 2020-02-09 02:09:48 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:09:48 --> Controller Class Initialized
DEBUG - 2020-02-09 02:09:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-09 02:09:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 02:09:49 --> Final output sent to browser
DEBUG - 2020-02-09 02:09:49 --> Total execution time: 0.6299
INFO - 2020-02-09 02:10:15 --> Config Class Initialized
INFO - 2020-02-09 02:10:15 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:10:15 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:10:15 --> Utf8 Class Initialized
INFO - 2020-02-09 02:10:15 --> URI Class Initialized
DEBUG - 2020-02-09 02:10:15 --> No URI present. Default controller set.
INFO - 2020-02-09 02:10:15 --> Router Class Initialized
INFO - 2020-02-09 02:10:15 --> Output Class Initialized
INFO - 2020-02-09 02:10:15 --> Security Class Initialized
DEBUG - 2020-02-09 02:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:10:15 --> Input Class Initialized
INFO - 2020-02-09 02:10:15 --> Language Class Initialized
INFO - 2020-02-09 02:10:15 --> Language Class Initialized
INFO - 2020-02-09 02:10:15 --> Config Class Initialized
INFO - 2020-02-09 02:10:15 --> Loader Class Initialized
INFO - 2020-02-09 02:10:15 --> Helper loaded: url_helper
INFO - 2020-02-09 02:10:15 --> Helper loaded: file_helper
INFO - 2020-02-09 02:10:15 --> Helper loaded: form_helper
INFO - 2020-02-09 02:10:15 --> Helper loaded: my_helper
INFO - 2020-02-09 02:10:15 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:10:15 --> Controller Class Initialized
DEBUG - 2020-02-09 02:10:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-09 02:10:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 02:10:15 --> Final output sent to browser
DEBUG - 2020-02-09 02:10:15 --> Total execution time: 0.4277
INFO - 2020-02-09 02:10:23 --> Config Class Initialized
INFO - 2020-02-09 02:10:23 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:10:24 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:10:24 --> Utf8 Class Initialized
INFO - 2020-02-09 02:10:24 --> URI Class Initialized
INFO - 2020-02-09 02:10:24 --> Router Class Initialized
INFO - 2020-02-09 02:10:24 --> Output Class Initialized
INFO - 2020-02-09 02:10:24 --> Security Class Initialized
DEBUG - 2020-02-09 02:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:10:24 --> Input Class Initialized
INFO - 2020-02-09 02:10:24 --> Language Class Initialized
INFO - 2020-02-09 02:10:24 --> Language Class Initialized
INFO - 2020-02-09 02:10:24 --> Config Class Initialized
INFO - 2020-02-09 02:10:24 --> Loader Class Initialized
INFO - 2020-02-09 02:10:24 --> Helper loaded: url_helper
INFO - 2020-02-09 02:10:24 --> Helper loaded: file_helper
INFO - 2020-02-09 02:10:24 --> Helper loaded: form_helper
INFO - 2020-02-09 02:10:24 --> Helper loaded: my_helper
INFO - 2020-02-09 02:10:24 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:10:24 --> Controller Class Initialized
DEBUG - 2020-02-09 02:10:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_guru/views/list.php
DEBUG - 2020-02-09 02:10:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 02:10:24 --> Final output sent to browser
DEBUG - 2020-02-09 02:10:24 --> Total execution time: 0.5226
INFO - 2020-02-09 02:10:24 --> Config Class Initialized
INFO - 2020-02-09 02:10:24 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:10:24 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:10:24 --> Utf8 Class Initialized
INFO - 2020-02-09 02:10:24 --> URI Class Initialized
INFO - 2020-02-09 02:10:24 --> Router Class Initialized
INFO - 2020-02-09 02:10:24 --> Output Class Initialized
INFO - 2020-02-09 02:10:24 --> Security Class Initialized
DEBUG - 2020-02-09 02:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:10:24 --> Input Class Initialized
INFO - 2020-02-09 02:10:25 --> Language Class Initialized
INFO - 2020-02-09 02:10:25 --> Language Class Initialized
INFO - 2020-02-09 02:10:25 --> Config Class Initialized
INFO - 2020-02-09 02:10:25 --> Loader Class Initialized
INFO - 2020-02-09 02:10:25 --> Helper loaded: url_helper
INFO - 2020-02-09 02:10:25 --> Helper loaded: file_helper
INFO - 2020-02-09 02:10:25 --> Helper loaded: form_helper
INFO - 2020-02-09 02:10:25 --> Helper loaded: my_helper
INFO - 2020-02-09 02:10:25 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:10:25 --> Controller Class Initialized
INFO - 2020-02-09 02:10:27 --> Config Class Initialized
INFO - 2020-02-09 02:10:27 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:10:27 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:10:27 --> Utf8 Class Initialized
INFO - 2020-02-09 02:10:27 --> URI Class Initialized
INFO - 2020-02-09 02:10:27 --> Router Class Initialized
INFO - 2020-02-09 02:10:27 --> Output Class Initialized
INFO - 2020-02-09 02:10:27 --> Security Class Initialized
DEBUG - 2020-02-09 02:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:10:27 --> Input Class Initialized
INFO - 2020-02-09 02:10:27 --> Language Class Initialized
INFO - 2020-02-09 02:10:27 --> Language Class Initialized
INFO - 2020-02-09 02:10:27 --> Config Class Initialized
INFO - 2020-02-09 02:10:27 --> Loader Class Initialized
INFO - 2020-02-09 02:10:27 --> Helper loaded: url_helper
INFO - 2020-02-09 02:10:28 --> Helper loaded: file_helper
INFO - 2020-02-09 02:10:28 --> Helper loaded: form_helper
INFO - 2020-02-09 02:10:28 --> Helper loaded: my_helper
INFO - 2020-02-09 02:10:28 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:10:28 --> Controller Class Initialized
DEBUG - 2020-02-09 02:10:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_ekstra/views/list.php
DEBUG - 2020-02-09 02:10:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 02:10:28 --> Final output sent to browser
DEBUG - 2020-02-09 02:10:28 --> Total execution time: 0.4939
INFO - 2020-02-09 02:10:28 --> Config Class Initialized
INFO - 2020-02-09 02:10:28 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:10:28 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:10:28 --> Utf8 Class Initialized
INFO - 2020-02-09 02:10:28 --> URI Class Initialized
INFO - 2020-02-09 02:10:28 --> Router Class Initialized
INFO - 2020-02-09 02:10:28 --> Output Class Initialized
INFO - 2020-02-09 02:10:28 --> Security Class Initialized
DEBUG - 2020-02-09 02:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:10:28 --> Input Class Initialized
INFO - 2020-02-09 02:10:28 --> Language Class Initialized
INFO - 2020-02-09 02:10:28 --> Language Class Initialized
INFO - 2020-02-09 02:10:28 --> Config Class Initialized
INFO - 2020-02-09 02:10:28 --> Loader Class Initialized
INFO - 2020-02-09 02:10:28 --> Helper loaded: url_helper
INFO - 2020-02-09 02:10:28 --> Helper loaded: file_helper
INFO - 2020-02-09 02:10:28 --> Helper loaded: form_helper
INFO - 2020-02-09 02:10:28 --> Helper loaded: my_helper
INFO - 2020-02-09 02:10:28 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:10:28 --> Controller Class Initialized
INFO - 2020-02-09 02:10:34 --> Config Class Initialized
INFO - 2020-02-09 02:10:34 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:10:34 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:10:34 --> Utf8 Class Initialized
INFO - 2020-02-09 02:10:34 --> URI Class Initialized
INFO - 2020-02-09 02:10:34 --> Router Class Initialized
INFO - 2020-02-09 02:10:34 --> Output Class Initialized
INFO - 2020-02-09 02:10:34 --> Security Class Initialized
DEBUG - 2020-02-09 02:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:10:34 --> Input Class Initialized
INFO - 2020-02-09 02:10:34 --> Language Class Initialized
INFO - 2020-02-09 02:10:34 --> Language Class Initialized
INFO - 2020-02-09 02:10:34 --> Config Class Initialized
INFO - 2020-02-09 02:10:34 --> Loader Class Initialized
INFO - 2020-02-09 02:10:34 --> Helper loaded: url_helper
INFO - 2020-02-09 02:10:34 --> Helper loaded: file_helper
INFO - 2020-02-09 02:10:34 --> Helper loaded: form_helper
INFO - 2020-02-09 02:10:34 --> Helper loaded: my_helper
INFO - 2020-02-09 02:10:34 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:10:34 --> Controller Class Initialized
DEBUG - 2020-02-09 02:10:34 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_ekstra/views/list.php
DEBUG - 2020-02-09 02:10:34 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 02:10:34 --> Final output sent to browser
DEBUG - 2020-02-09 02:10:34 --> Total execution time: 0.4237
INFO - 2020-02-09 02:10:34 --> Config Class Initialized
INFO - 2020-02-09 02:10:34 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:10:34 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:10:34 --> Utf8 Class Initialized
INFO - 2020-02-09 02:10:34 --> URI Class Initialized
INFO - 2020-02-09 02:10:34 --> Router Class Initialized
INFO - 2020-02-09 02:10:34 --> Output Class Initialized
INFO - 2020-02-09 02:10:34 --> Security Class Initialized
DEBUG - 2020-02-09 02:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:10:34 --> Input Class Initialized
INFO - 2020-02-09 02:10:34 --> Language Class Initialized
INFO - 2020-02-09 02:10:34 --> Language Class Initialized
INFO - 2020-02-09 02:10:34 --> Config Class Initialized
INFO - 2020-02-09 02:10:34 --> Loader Class Initialized
INFO - 2020-02-09 02:10:34 --> Helper loaded: url_helper
INFO - 2020-02-09 02:10:34 --> Helper loaded: file_helper
INFO - 2020-02-09 02:10:34 --> Helper loaded: form_helper
INFO - 2020-02-09 02:10:34 --> Helper loaded: my_helper
INFO - 2020-02-09 02:10:34 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:10:35 --> Controller Class Initialized
INFO - 2020-02-09 02:10:38 --> Config Class Initialized
INFO - 2020-02-09 02:10:38 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:10:38 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:10:38 --> Utf8 Class Initialized
INFO - 2020-02-09 02:10:38 --> URI Class Initialized
DEBUG - 2020-02-09 02:10:38 --> No URI present. Default controller set.
INFO - 2020-02-09 02:10:38 --> Router Class Initialized
INFO - 2020-02-09 02:10:38 --> Output Class Initialized
INFO - 2020-02-09 02:10:38 --> Security Class Initialized
DEBUG - 2020-02-09 02:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:10:38 --> Input Class Initialized
INFO - 2020-02-09 02:10:38 --> Language Class Initialized
INFO - 2020-02-09 02:10:38 --> Language Class Initialized
INFO - 2020-02-09 02:10:38 --> Config Class Initialized
INFO - 2020-02-09 02:10:38 --> Loader Class Initialized
INFO - 2020-02-09 02:10:38 --> Helper loaded: url_helper
INFO - 2020-02-09 02:10:38 --> Helper loaded: file_helper
INFO - 2020-02-09 02:10:38 --> Helper loaded: form_helper
INFO - 2020-02-09 02:10:38 --> Helper loaded: my_helper
INFO - 2020-02-09 02:10:38 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:10:38 --> Controller Class Initialized
DEBUG - 2020-02-09 02:10:38 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-09 02:10:38 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 02:10:38 --> Final output sent to browser
DEBUG - 2020-02-09 02:10:38 --> Total execution time: 0.5226
INFO - 2020-02-09 02:10:40 --> Config Class Initialized
INFO - 2020-02-09 02:10:40 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:10:40 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:10:40 --> Utf8 Class Initialized
INFO - 2020-02-09 02:10:40 --> URI Class Initialized
INFO - 2020-02-09 02:10:40 --> Router Class Initialized
INFO - 2020-02-09 02:10:40 --> Output Class Initialized
INFO - 2020-02-09 02:10:40 --> Security Class Initialized
DEBUG - 2020-02-09 02:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:10:40 --> Input Class Initialized
INFO - 2020-02-09 02:10:40 --> Language Class Initialized
INFO - 2020-02-09 02:10:40 --> Language Class Initialized
INFO - 2020-02-09 02:10:40 --> Config Class Initialized
INFO - 2020-02-09 02:10:40 --> Loader Class Initialized
INFO - 2020-02-09 02:10:40 --> Helper loaded: url_helper
INFO - 2020-02-09 02:10:40 --> Helper loaded: file_helper
INFO - 2020-02-09 02:10:40 --> Helper loaded: form_helper
INFO - 2020-02-09 02:10:40 --> Helper loaded: my_helper
INFO - 2020-02-09 02:10:40 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:10:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:10:41 --> Controller Class Initialized
INFO - 2020-02-09 02:10:41 --> Helper loaded: cookie_helper
INFO - 2020-02-09 02:10:41 --> Config Class Initialized
INFO - 2020-02-09 02:10:41 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:10:41 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:10:41 --> Utf8 Class Initialized
INFO - 2020-02-09 02:10:41 --> URI Class Initialized
INFO - 2020-02-09 02:10:41 --> Router Class Initialized
INFO - 2020-02-09 02:10:41 --> Output Class Initialized
INFO - 2020-02-09 02:10:41 --> Security Class Initialized
DEBUG - 2020-02-09 02:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:10:41 --> Input Class Initialized
INFO - 2020-02-09 02:10:41 --> Language Class Initialized
INFO - 2020-02-09 02:10:41 --> Language Class Initialized
INFO - 2020-02-09 02:10:41 --> Config Class Initialized
INFO - 2020-02-09 02:10:41 --> Loader Class Initialized
INFO - 2020-02-09 02:10:41 --> Helper loaded: url_helper
INFO - 2020-02-09 02:10:41 --> Helper loaded: file_helper
INFO - 2020-02-09 02:10:41 --> Helper loaded: form_helper
INFO - 2020-02-09 02:10:41 --> Helper loaded: my_helper
INFO - 2020-02-09 02:10:41 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:10:41 --> Controller Class Initialized
INFO - 2020-02-09 02:10:41 --> Config Class Initialized
INFO - 2020-02-09 02:10:41 --> Hooks Class Initialized
DEBUG - 2020-02-09 02:10:41 --> UTF-8 Support Enabled
INFO - 2020-02-09 02:10:41 --> Utf8 Class Initialized
INFO - 2020-02-09 02:10:41 --> URI Class Initialized
INFO - 2020-02-09 02:10:41 --> Router Class Initialized
INFO - 2020-02-09 02:10:41 --> Output Class Initialized
INFO - 2020-02-09 02:10:41 --> Security Class Initialized
DEBUG - 2020-02-09 02:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 02:10:41 --> Input Class Initialized
INFO - 2020-02-09 02:10:41 --> Language Class Initialized
INFO - 2020-02-09 02:10:41 --> Language Class Initialized
INFO - 2020-02-09 02:10:41 --> Config Class Initialized
INFO - 2020-02-09 02:10:41 --> Loader Class Initialized
INFO - 2020-02-09 02:10:41 --> Helper loaded: url_helper
INFO - 2020-02-09 02:10:41 --> Helper loaded: file_helper
INFO - 2020-02-09 02:10:41 --> Helper loaded: form_helper
INFO - 2020-02-09 02:10:41 --> Helper loaded: my_helper
INFO - 2020-02-09 02:10:41 --> Database Driver Class Initialized
DEBUG - 2020-02-09 02:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 02:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 02:10:41 --> Controller Class Initialized
DEBUG - 2020-02-09 02:10:41 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 02:10:41 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 02:10:41 --> Final output sent to browser
DEBUG - 2020-02-09 02:10:41 --> Total execution time: 0.4562
INFO - 2020-02-09 04:55:32 --> Config Class Initialized
INFO - 2020-02-09 04:55:32 --> Hooks Class Initialized
DEBUG - 2020-02-09 04:55:32 --> UTF-8 Support Enabled
INFO - 2020-02-09 04:55:32 --> Utf8 Class Initialized
INFO - 2020-02-09 04:55:32 --> URI Class Initialized
INFO - 2020-02-09 04:55:32 --> Router Class Initialized
INFO - 2020-02-09 04:55:32 --> Output Class Initialized
INFO - 2020-02-09 04:55:32 --> Security Class Initialized
DEBUG - 2020-02-09 04:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 04:55:32 --> Input Class Initialized
INFO - 2020-02-09 04:55:32 --> Language Class Initialized
INFO - 2020-02-09 04:55:32 --> Language Class Initialized
INFO - 2020-02-09 04:55:32 --> Config Class Initialized
INFO - 2020-02-09 04:55:32 --> Loader Class Initialized
INFO - 2020-02-09 04:55:32 --> Helper loaded: url_helper
INFO - 2020-02-09 04:55:32 --> Helper loaded: file_helper
INFO - 2020-02-09 04:55:32 --> Helper loaded: form_helper
INFO - 2020-02-09 04:55:32 --> Helper loaded: my_helper
INFO - 2020-02-09 04:55:32 --> Database Driver Class Initialized
DEBUG - 2020-02-09 04:55:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 04:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 04:55:33 --> Controller Class Initialized
INFO - 2020-02-09 04:55:33 --> Final output sent to browser
DEBUG - 2020-02-09 04:55:33 --> Total execution time: 0.3363
INFO - 2020-02-09 04:55:37 --> Config Class Initialized
INFO - 2020-02-09 04:55:37 --> Hooks Class Initialized
DEBUG - 2020-02-09 04:55:37 --> UTF-8 Support Enabled
INFO - 2020-02-09 04:55:37 --> Utf8 Class Initialized
INFO - 2020-02-09 04:55:37 --> URI Class Initialized
INFO - 2020-02-09 04:55:37 --> Router Class Initialized
INFO - 2020-02-09 04:55:37 --> Output Class Initialized
INFO - 2020-02-09 04:55:37 --> Security Class Initialized
DEBUG - 2020-02-09 04:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 04:55:37 --> Input Class Initialized
INFO - 2020-02-09 04:55:37 --> Language Class Initialized
INFO - 2020-02-09 04:55:38 --> Language Class Initialized
INFO - 2020-02-09 04:55:38 --> Config Class Initialized
INFO - 2020-02-09 04:55:38 --> Loader Class Initialized
INFO - 2020-02-09 04:55:38 --> Helper loaded: url_helper
INFO - 2020-02-09 04:55:38 --> Helper loaded: file_helper
INFO - 2020-02-09 04:55:38 --> Helper loaded: form_helper
INFO - 2020-02-09 04:55:38 --> Helper loaded: my_helper
INFO - 2020-02-09 04:55:38 --> Database Driver Class Initialized
DEBUG - 2020-02-09 04:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 04:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 04:55:38 --> Controller Class Initialized
INFO - 2020-02-09 04:55:38 --> Helper loaded: cookie_helper
INFO - 2020-02-09 04:55:38 --> Final output sent to browser
DEBUG - 2020-02-09 04:55:38 --> Total execution time: 0.3539
INFO - 2020-02-09 04:55:38 --> Config Class Initialized
INFO - 2020-02-09 04:55:38 --> Hooks Class Initialized
DEBUG - 2020-02-09 04:55:38 --> UTF-8 Support Enabled
INFO - 2020-02-09 04:55:38 --> Utf8 Class Initialized
INFO - 2020-02-09 04:55:38 --> URI Class Initialized
INFO - 2020-02-09 04:55:38 --> Router Class Initialized
INFO - 2020-02-09 04:55:38 --> Output Class Initialized
INFO - 2020-02-09 04:55:38 --> Security Class Initialized
DEBUG - 2020-02-09 04:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 04:55:38 --> Input Class Initialized
INFO - 2020-02-09 04:55:38 --> Language Class Initialized
INFO - 2020-02-09 04:55:38 --> Language Class Initialized
INFO - 2020-02-09 04:55:38 --> Config Class Initialized
INFO - 2020-02-09 04:55:38 --> Loader Class Initialized
INFO - 2020-02-09 04:55:38 --> Helper loaded: url_helper
INFO - 2020-02-09 04:55:38 --> Helper loaded: file_helper
INFO - 2020-02-09 04:55:38 --> Helper loaded: form_helper
INFO - 2020-02-09 04:55:38 --> Helper loaded: my_helper
INFO - 2020-02-09 04:55:38 --> Database Driver Class Initialized
DEBUG - 2020-02-09 04:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 04:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 04:55:38 --> Controller Class Initialized
DEBUG - 2020-02-09 04:55:38 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-09 04:55:38 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 04:55:38 --> Final output sent to browser
DEBUG - 2020-02-09 04:55:38 --> Total execution time: 0.4000
INFO - 2020-02-09 04:56:08 --> Config Class Initialized
INFO - 2020-02-09 04:56:08 --> Hooks Class Initialized
DEBUG - 2020-02-09 04:56:08 --> UTF-8 Support Enabled
INFO - 2020-02-09 04:56:08 --> Utf8 Class Initialized
INFO - 2020-02-09 04:56:08 --> URI Class Initialized
INFO - 2020-02-09 04:56:08 --> Router Class Initialized
INFO - 2020-02-09 04:56:08 --> Output Class Initialized
INFO - 2020-02-09 04:56:08 --> Security Class Initialized
DEBUG - 2020-02-09 04:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 04:56:08 --> Input Class Initialized
INFO - 2020-02-09 04:56:08 --> Language Class Initialized
INFO - 2020-02-09 04:56:08 --> Language Class Initialized
INFO - 2020-02-09 04:56:08 --> Config Class Initialized
INFO - 2020-02-09 04:56:08 --> Loader Class Initialized
INFO - 2020-02-09 04:56:08 --> Helper loaded: url_helper
INFO - 2020-02-09 04:56:08 --> Helper loaded: file_helper
INFO - 2020-02-09 04:56:08 --> Helper loaded: form_helper
INFO - 2020-02-09 04:56:08 --> Helper loaded: my_helper
INFO - 2020-02-09 04:56:08 --> Database Driver Class Initialized
DEBUG - 2020-02-09 04:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 04:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 04:56:08 --> Controller Class Initialized
DEBUG - 2020-02-09 04:56:08 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_guru/views/list.php
DEBUG - 2020-02-09 04:56:08 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 04:56:08 --> Final output sent to browser
DEBUG - 2020-02-09 04:56:08 --> Total execution time: 0.3610
INFO - 2020-02-09 04:56:08 --> Config Class Initialized
INFO - 2020-02-09 04:56:08 --> Hooks Class Initialized
DEBUG - 2020-02-09 04:56:08 --> UTF-8 Support Enabled
INFO - 2020-02-09 04:56:08 --> Utf8 Class Initialized
INFO - 2020-02-09 04:56:08 --> URI Class Initialized
INFO - 2020-02-09 04:56:08 --> Router Class Initialized
INFO - 2020-02-09 04:56:08 --> Output Class Initialized
INFO - 2020-02-09 04:56:08 --> Security Class Initialized
DEBUG - 2020-02-09 04:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 04:56:08 --> Input Class Initialized
INFO - 2020-02-09 04:56:09 --> Language Class Initialized
INFO - 2020-02-09 04:56:09 --> Language Class Initialized
INFO - 2020-02-09 04:56:09 --> Config Class Initialized
INFO - 2020-02-09 04:56:09 --> Loader Class Initialized
INFO - 2020-02-09 04:56:09 --> Helper loaded: url_helper
INFO - 2020-02-09 04:56:09 --> Helper loaded: file_helper
INFO - 2020-02-09 04:56:09 --> Helper loaded: form_helper
INFO - 2020-02-09 04:56:09 --> Helper loaded: my_helper
INFO - 2020-02-09 04:56:09 --> Database Driver Class Initialized
DEBUG - 2020-02-09 04:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 04:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 04:56:09 --> Controller Class Initialized
INFO - 2020-02-09 04:56:37 --> Config Class Initialized
INFO - 2020-02-09 04:56:37 --> Hooks Class Initialized
DEBUG - 2020-02-09 04:56:37 --> UTF-8 Support Enabled
INFO - 2020-02-09 04:56:37 --> Utf8 Class Initialized
INFO - 2020-02-09 04:56:37 --> URI Class Initialized
INFO - 2020-02-09 04:56:37 --> Router Class Initialized
INFO - 2020-02-09 04:56:37 --> Output Class Initialized
INFO - 2020-02-09 04:56:37 --> Security Class Initialized
DEBUG - 2020-02-09 04:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 04:56:37 --> Input Class Initialized
INFO - 2020-02-09 04:56:37 --> Language Class Initialized
INFO - 2020-02-09 04:56:37 --> Language Class Initialized
INFO - 2020-02-09 04:56:37 --> Config Class Initialized
INFO - 2020-02-09 04:56:37 --> Loader Class Initialized
INFO - 2020-02-09 04:56:37 --> Helper loaded: url_helper
INFO - 2020-02-09 04:56:37 --> Helper loaded: file_helper
INFO - 2020-02-09 04:56:37 --> Helper loaded: form_helper
INFO - 2020-02-09 04:56:38 --> Helper loaded: my_helper
INFO - 2020-02-09 04:56:38 --> Database Driver Class Initialized
DEBUG - 2020-02-09 04:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 04:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 04:56:38 --> Controller Class Initialized
DEBUG - 2020-02-09 04:56:38 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/list.php
DEBUG - 2020-02-09 04:56:38 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 04:56:38 --> Final output sent to browser
DEBUG - 2020-02-09 04:56:38 --> Total execution time: 0.3827
INFO - 2020-02-09 04:56:38 --> Config Class Initialized
INFO - 2020-02-09 04:56:38 --> Hooks Class Initialized
DEBUG - 2020-02-09 04:56:38 --> UTF-8 Support Enabled
INFO - 2020-02-09 04:56:38 --> Utf8 Class Initialized
INFO - 2020-02-09 04:56:38 --> URI Class Initialized
INFO - 2020-02-09 04:56:38 --> Router Class Initialized
INFO - 2020-02-09 04:56:38 --> Output Class Initialized
INFO - 2020-02-09 04:56:38 --> Security Class Initialized
DEBUG - 2020-02-09 04:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 04:56:38 --> Input Class Initialized
INFO - 2020-02-09 04:56:38 --> Language Class Initialized
INFO - 2020-02-09 04:56:38 --> Language Class Initialized
INFO - 2020-02-09 04:56:38 --> Config Class Initialized
INFO - 2020-02-09 04:56:38 --> Loader Class Initialized
INFO - 2020-02-09 04:56:38 --> Helper loaded: url_helper
INFO - 2020-02-09 04:56:38 --> Helper loaded: file_helper
INFO - 2020-02-09 04:56:38 --> Helper loaded: form_helper
INFO - 2020-02-09 04:56:38 --> Helper loaded: my_helper
INFO - 2020-02-09 04:56:38 --> Database Driver Class Initialized
DEBUG - 2020-02-09 04:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 04:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 04:56:38 --> Controller Class Initialized
INFO - 2020-02-09 04:56:42 --> Config Class Initialized
INFO - 2020-02-09 04:56:42 --> Hooks Class Initialized
DEBUG - 2020-02-09 04:56:42 --> UTF-8 Support Enabled
INFO - 2020-02-09 04:56:42 --> Utf8 Class Initialized
INFO - 2020-02-09 04:56:42 --> URI Class Initialized
INFO - 2020-02-09 04:56:42 --> Router Class Initialized
INFO - 2020-02-09 04:56:42 --> Output Class Initialized
INFO - 2020-02-09 04:56:42 --> Security Class Initialized
DEBUG - 2020-02-09 04:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 04:56:42 --> Input Class Initialized
INFO - 2020-02-09 04:56:42 --> Language Class Initialized
INFO - 2020-02-09 04:56:42 --> Language Class Initialized
INFO - 2020-02-09 04:56:42 --> Config Class Initialized
INFO - 2020-02-09 04:56:42 --> Loader Class Initialized
INFO - 2020-02-09 04:56:42 --> Helper loaded: url_helper
INFO - 2020-02-09 04:56:42 --> Helper loaded: file_helper
INFO - 2020-02-09 04:56:42 --> Helper loaded: form_helper
INFO - 2020-02-09 04:56:42 --> Helper loaded: my_helper
INFO - 2020-02-09 04:56:42 --> Database Driver Class Initialized
DEBUG - 2020-02-09 04:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 04:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 04:56:42 --> Controller Class Initialized
INFO - 2020-02-09 04:56:43 --> Config Class Initialized
INFO - 2020-02-09 04:56:43 --> Hooks Class Initialized
DEBUG - 2020-02-09 04:56:43 --> UTF-8 Support Enabled
INFO - 2020-02-09 04:56:43 --> Utf8 Class Initialized
INFO - 2020-02-09 04:56:43 --> URI Class Initialized
INFO - 2020-02-09 04:56:43 --> Router Class Initialized
INFO - 2020-02-09 04:56:43 --> Output Class Initialized
INFO - 2020-02-09 04:56:43 --> Security Class Initialized
DEBUG - 2020-02-09 04:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 04:56:43 --> Input Class Initialized
INFO - 2020-02-09 04:56:43 --> Language Class Initialized
INFO - 2020-02-09 04:56:43 --> Language Class Initialized
INFO - 2020-02-09 04:56:43 --> Config Class Initialized
INFO - 2020-02-09 04:56:43 --> Loader Class Initialized
INFO - 2020-02-09 04:56:43 --> Helper loaded: url_helper
INFO - 2020-02-09 04:56:43 --> Helper loaded: file_helper
INFO - 2020-02-09 04:56:43 --> Helper loaded: form_helper
INFO - 2020-02-09 04:56:43 --> Helper loaded: my_helper
INFO - 2020-02-09 04:56:43 --> Database Driver Class Initialized
DEBUG - 2020-02-09 04:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 04:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 04:56:43 --> Controller Class Initialized
INFO - 2020-02-09 04:56:44 --> Config Class Initialized
INFO - 2020-02-09 04:56:44 --> Hooks Class Initialized
DEBUG - 2020-02-09 04:56:44 --> UTF-8 Support Enabled
INFO - 2020-02-09 04:56:44 --> Utf8 Class Initialized
INFO - 2020-02-09 04:56:44 --> URI Class Initialized
INFO - 2020-02-09 04:56:44 --> Router Class Initialized
INFO - 2020-02-09 04:56:44 --> Output Class Initialized
INFO - 2020-02-09 04:56:44 --> Security Class Initialized
DEBUG - 2020-02-09 04:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 04:56:44 --> Input Class Initialized
INFO - 2020-02-09 04:56:44 --> Language Class Initialized
INFO - 2020-02-09 04:56:44 --> Language Class Initialized
INFO - 2020-02-09 04:56:44 --> Config Class Initialized
INFO - 2020-02-09 04:56:44 --> Loader Class Initialized
INFO - 2020-02-09 04:56:44 --> Helper loaded: url_helper
INFO - 2020-02-09 04:56:44 --> Helper loaded: file_helper
INFO - 2020-02-09 04:56:44 --> Helper loaded: form_helper
INFO - 2020-02-09 04:56:44 --> Helper loaded: my_helper
INFO - 2020-02-09 04:56:44 --> Database Driver Class Initialized
DEBUG - 2020-02-09 04:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 04:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 04:56:44 --> Controller Class Initialized
INFO - 2020-02-09 05:09:11 --> Config Class Initialized
INFO - 2020-02-09 05:09:11 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:09:11 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:09:11 --> Utf8 Class Initialized
INFO - 2020-02-09 05:09:11 --> URI Class Initialized
INFO - 2020-02-09 05:09:11 --> Router Class Initialized
INFO - 2020-02-09 05:09:11 --> Output Class Initialized
INFO - 2020-02-09 05:09:11 --> Security Class Initialized
DEBUG - 2020-02-09 05:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:09:11 --> Input Class Initialized
INFO - 2020-02-09 05:09:11 --> Language Class Initialized
INFO - 2020-02-09 05:09:11 --> Language Class Initialized
INFO - 2020-02-09 05:09:11 --> Config Class Initialized
INFO - 2020-02-09 05:09:11 --> Loader Class Initialized
INFO - 2020-02-09 05:09:11 --> Helper loaded: url_helper
INFO - 2020-02-09 05:09:11 --> Helper loaded: file_helper
INFO - 2020-02-09 05:09:11 --> Helper loaded: form_helper
INFO - 2020-02-09 05:09:11 --> Helper loaded: my_helper
INFO - 2020-02-09 05:09:11 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:09:11 --> Controller Class Initialized
DEBUG - 2020-02-09 05:09:12 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-02-09 05:09:12 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:09:12 --> Final output sent to browser
DEBUG - 2020-02-09 05:09:12 --> Total execution time: 0.4112
INFO - 2020-02-09 05:09:12 --> Config Class Initialized
INFO - 2020-02-09 05:09:12 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:09:12 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:09:12 --> Utf8 Class Initialized
INFO - 2020-02-09 05:09:12 --> URI Class Initialized
INFO - 2020-02-09 05:09:12 --> Router Class Initialized
INFO - 2020-02-09 05:09:12 --> Output Class Initialized
INFO - 2020-02-09 05:09:12 --> Security Class Initialized
DEBUG - 2020-02-09 05:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:09:12 --> Input Class Initialized
INFO - 2020-02-09 05:09:12 --> Language Class Initialized
INFO - 2020-02-09 05:09:12 --> Language Class Initialized
INFO - 2020-02-09 05:09:12 --> Config Class Initialized
INFO - 2020-02-09 05:09:12 --> Loader Class Initialized
INFO - 2020-02-09 05:09:12 --> Helper loaded: url_helper
INFO - 2020-02-09 05:09:12 --> Helper loaded: file_helper
INFO - 2020-02-09 05:09:12 --> Helper loaded: form_helper
INFO - 2020-02-09 05:09:12 --> Helper loaded: my_helper
INFO - 2020-02-09 05:09:12 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:09:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:09:12 --> Controller Class Initialized
INFO - 2020-02-09 05:09:50 --> Config Class Initialized
INFO - 2020-02-09 05:09:50 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:09:51 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:09:51 --> Utf8 Class Initialized
INFO - 2020-02-09 05:09:51 --> URI Class Initialized
INFO - 2020-02-09 05:09:51 --> Router Class Initialized
INFO - 2020-02-09 05:09:51 --> Output Class Initialized
INFO - 2020-02-09 05:09:51 --> Security Class Initialized
DEBUG - 2020-02-09 05:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:09:51 --> Input Class Initialized
INFO - 2020-02-09 05:09:51 --> Language Class Initialized
INFO - 2020-02-09 05:09:51 --> Language Class Initialized
INFO - 2020-02-09 05:09:51 --> Config Class Initialized
INFO - 2020-02-09 05:09:51 --> Loader Class Initialized
INFO - 2020-02-09 05:09:51 --> Helper loaded: url_helper
INFO - 2020-02-09 05:09:51 --> Helper loaded: file_helper
INFO - 2020-02-09 05:09:51 --> Helper loaded: form_helper
INFO - 2020-02-09 05:09:51 --> Helper loaded: my_helper
INFO - 2020-02-09 05:09:51 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:09:51 --> Controller Class Initialized
DEBUG - 2020-02-09 05:09:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_mapel/views/list.php
DEBUG - 2020-02-09 05:09:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:09:51 --> Final output sent to browser
DEBUG - 2020-02-09 05:09:51 --> Total execution time: 0.3967
INFO - 2020-02-09 05:09:51 --> Config Class Initialized
INFO - 2020-02-09 05:09:51 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:09:51 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:09:51 --> Utf8 Class Initialized
INFO - 2020-02-09 05:09:51 --> URI Class Initialized
INFO - 2020-02-09 05:09:51 --> Router Class Initialized
INFO - 2020-02-09 05:09:51 --> Output Class Initialized
INFO - 2020-02-09 05:09:51 --> Security Class Initialized
DEBUG - 2020-02-09 05:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:09:51 --> Input Class Initialized
INFO - 2020-02-09 05:09:51 --> Language Class Initialized
INFO - 2020-02-09 05:09:51 --> Language Class Initialized
INFO - 2020-02-09 05:09:51 --> Config Class Initialized
INFO - 2020-02-09 05:09:51 --> Loader Class Initialized
INFO - 2020-02-09 05:09:51 --> Helper loaded: url_helper
INFO - 2020-02-09 05:09:51 --> Helper loaded: file_helper
INFO - 2020-02-09 05:09:51 --> Helper loaded: form_helper
INFO - 2020-02-09 05:09:51 --> Helper loaded: my_helper
INFO - 2020-02-09 05:09:51 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:09:51 --> Controller Class Initialized
INFO - 2020-02-09 05:09:53 --> Config Class Initialized
INFO - 2020-02-09 05:09:54 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:09:54 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:09:54 --> Utf8 Class Initialized
INFO - 2020-02-09 05:09:54 --> URI Class Initialized
INFO - 2020-02-09 05:09:54 --> Router Class Initialized
INFO - 2020-02-09 05:09:54 --> Output Class Initialized
INFO - 2020-02-09 05:09:54 --> Security Class Initialized
DEBUG - 2020-02-09 05:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:09:54 --> Input Class Initialized
INFO - 2020-02-09 05:09:54 --> Language Class Initialized
INFO - 2020-02-09 05:09:54 --> Language Class Initialized
INFO - 2020-02-09 05:09:54 --> Config Class Initialized
INFO - 2020-02-09 05:09:54 --> Loader Class Initialized
INFO - 2020-02-09 05:09:54 --> Helper loaded: url_helper
INFO - 2020-02-09 05:09:54 --> Helper loaded: file_helper
INFO - 2020-02-09 05:09:54 --> Helper loaded: form_helper
INFO - 2020-02-09 05:09:54 --> Helper loaded: my_helper
INFO - 2020-02-09 05:09:54 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:09:54 --> Controller Class Initialized
INFO - 2020-02-09 05:09:54 --> Final output sent to browser
DEBUG - 2020-02-09 05:09:54 --> Total execution time: 0.3831
INFO - 2020-02-09 05:12:35 --> Config Class Initialized
INFO - 2020-02-09 05:12:35 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:12:35 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:12:35 --> Utf8 Class Initialized
INFO - 2020-02-09 05:12:35 --> URI Class Initialized
INFO - 2020-02-09 05:12:35 --> Router Class Initialized
INFO - 2020-02-09 05:12:35 --> Output Class Initialized
INFO - 2020-02-09 05:12:35 --> Security Class Initialized
DEBUG - 2020-02-09 05:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:12:35 --> Input Class Initialized
INFO - 2020-02-09 05:12:35 --> Language Class Initialized
INFO - 2020-02-09 05:12:35 --> Language Class Initialized
INFO - 2020-02-09 05:12:35 --> Config Class Initialized
INFO - 2020-02-09 05:12:35 --> Loader Class Initialized
INFO - 2020-02-09 05:12:35 --> Helper loaded: url_helper
INFO - 2020-02-09 05:12:35 --> Helper loaded: file_helper
INFO - 2020-02-09 05:12:35 --> Helper loaded: form_helper
INFO - 2020-02-09 05:12:35 --> Helper loaded: my_helper
INFO - 2020-02-09 05:12:35 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:12:35 --> Controller Class Initialized
INFO - 2020-02-09 05:12:35 --> Final output sent to browser
DEBUG - 2020-02-09 05:12:35 --> Total execution time: 0.3504
INFO - 2020-02-09 05:12:42 --> Config Class Initialized
INFO - 2020-02-09 05:12:42 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:12:42 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:12:42 --> Utf8 Class Initialized
INFO - 2020-02-09 05:12:42 --> URI Class Initialized
INFO - 2020-02-09 05:12:42 --> Router Class Initialized
INFO - 2020-02-09 05:12:42 --> Output Class Initialized
INFO - 2020-02-09 05:12:42 --> Security Class Initialized
DEBUG - 2020-02-09 05:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:12:42 --> Input Class Initialized
INFO - 2020-02-09 05:12:42 --> Language Class Initialized
INFO - 2020-02-09 05:12:42 --> Language Class Initialized
INFO - 2020-02-09 05:12:42 --> Config Class Initialized
INFO - 2020-02-09 05:12:42 --> Loader Class Initialized
INFO - 2020-02-09 05:12:42 --> Helper loaded: url_helper
INFO - 2020-02-09 05:12:42 --> Helper loaded: file_helper
INFO - 2020-02-09 05:12:42 --> Helper loaded: form_helper
INFO - 2020-02-09 05:12:42 --> Helper loaded: my_helper
INFO - 2020-02-09 05:12:42 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:12:42 --> Controller Class Initialized
DEBUG - 2020-02-09 05:12:42 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_mapel/views/list.php
DEBUG - 2020-02-09 05:12:42 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:12:42 --> Final output sent to browser
DEBUG - 2020-02-09 05:12:42 --> Total execution time: 0.3651
INFO - 2020-02-09 05:12:42 --> Config Class Initialized
INFO - 2020-02-09 05:12:43 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:12:43 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:12:43 --> Utf8 Class Initialized
INFO - 2020-02-09 05:12:43 --> URI Class Initialized
INFO - 2020-02-09 05:12:43 --> Router Class Initialized
INFO - 2020-02-09 05:12:43 --> Output Class Initialized
INFO - 2020-02-09 05:12:43 --> Security Class Initialized
DEBUG - 2020-02-09 05:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:12:43 --> Input Class Initialized
INFO - 2020-02-09 05:12:43 --> Language Class Initialized
INFO - 2020-02-09 05:12:43 --> Language Class Initialized
INFO - 2020-02-09 05:12:43 --> Config Class Initialized
INFO - 2020-02-09 05:12:43 --> Loader Class Initialized
INFO - 2020-02-09 05:12:43 --> Helper loaded: url_helper
INFO - 2020-02-09 05:12:43 --> Helper loaded: file_helper
INFO - 2020-02-09 05:12:43 --> Helper loaded: form_helper
INFO - 2020-02-09 05:12:43 --> Helper loaded: my_helper
INFO - 2020-02-09 05:12:43 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:12:43 --> Controller Class Initialized
INFO - 2020-02-09 05:12:45 --> Config Class Initialized
INFO - 2020-02-09 05:12:45 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:12:45 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:12:45 --> Utf8 Class Initialized
INFO - 2020-02-09 05:12:45 --> URI Class Initialized
INFO - 2020-02-09 05:12:45 --> Router Class Initialized
INFO - 2020-02-09 05:12:45 --> Output Class Initialized
INFO - 2020-02-09 05:12:45 --> Security Class Initialized
DEBUG - 2020-02-09 05:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:12:45 --> Input Class Initialized
INFO - 2020-02-09 05:12:45 --> Language Class Initialized
INFO - 2020-02-09 05:12:45 --> Language Class Initialized
INFO - 2020-02-09 05:12:45 --> Config Class Initialized
INFO - 2020-02-09 05:12:45 --> Loader Class Initialized
INFO - 2020-02-09 05:12:45 --> Helper loaded: url_helper
INFO - 2020-02-09 05:12:45 --> Helper loaded: file_helper
INFO - 2020-02-09 05:12:45 --> Helper loaded: form_helper
INFO - 2020-02-09 05:12:45 --> Helper loaded: my_helper
INFO - 2020-02-09 05:12:45 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:12:45 --> Controller Class Initialized
DEBUG - 2020-02-09 05:12:45 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_ekstra/views/list.php
DEBUG - 2020-02-09 05:12:45 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:12:45 --> Final output sent to browser
DEBUG - 2020-02-09 05:12:45 --> Total execution time: 0.3715
INFO - 2020-02-09 05:12:45 --> Config Class Initialized
INFO - 2020-02-09 05:12:45 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:12:45 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:12:45 --> Utf8 Class Initialized
INFO - 2020-02-09 05:12:45 --> URI Class Initialized
INFO - 2020-02-09 05:12:45 --> Router Class Initialized
INFO - 2020-02-09 05:12:45 --> Output Class Initialized
INFO - 2020-02-09 05:12:45 --> Security Class Initialized
DEBUG - 2020-02-09 05:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:12:45 --> Input Class Initialized
INFO - 2020-02-09 05:12:45 --> Language Class Initialized
INFO - 2020-02-09 05:12:45 --> Language Class Initialized
INFO - 2020-02-09 05:12:45 --> Config Class Initialized
INFO - 2020-02-09 05:12:45 --> Loader Class Initialized
INFO - 2020-02-09 05:12:45 --> Helper loaded: url_helper
INFO - 2020-02-09 05:12:45 --> Helper loaded: file_helper
INFO - 2020-02-09 05:12:45 --> Helper loaded: form_helper
INFO - 2020-02-09 05:12:45 --> Helper loaded: my_helper
INFO - 2020-02-09 05:12:45 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:12:45 --> Controller Class Initialized
INFO - 2020-02-09 05:12:49 --> Config Class Initialized
INFO - 2020-02-09 05:12:49 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:12:49 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:12:49 --> Utf8 Class Initialized
INFO - 2020-02-09 05:12:49 --> URI Class Initialized
INFO - 2020-02-09 05:12:49 --> Router Class Initialized
INFO - 2020-02-09 05:12:49 --> Output Class Initialized
INFO - 2020-02-09 05:12:49 --> Security Class Initialized
DEBUG - 2020-02-09 05:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:12:49 --> Input Class Initialized
INFO - 2020-02-09 05:12:49 --> Language Class Initialized
INFO - 2020-02-09 05:12:49 --> Language Class Initialized
INFO - 2020-02-09 05:12:49 --> Config Class Initialized
INFO - 2020-02-09 05:12:49 --> Loader Class Initialized
INFO - 2020-02-09 05:12:49 --> Helper loaded: url_helper
INFO - 2020-02-09 05:12:49 --> Helper loaded: file_helper
INFO - 2020-02-09 05:12:49 --> Helper loaded: form_helper
INFO - 2020-02-09 05:12:49 --> Helper loaded: my_helper
INFO - 2020-02-09 05:12:49 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:12:49 --> Controller Class Initialized
DEBUG - 2020-02-09 05:12:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-09 05:12:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:12:49 --> Final output sent to browser
DEBUG - 2020-02-09 05:12:49 --> Total execution time: 0.4139
INFO - 2020-02-09 05:12:49 --> Config Class Initialized
INFO - 2020-02-09 05:12:49 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:12:50 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:12:50 --> Utf8 Class Initialized
INFO - 2020-02-09 05:12:50 --> URI Class Initialized
INFO - 2020-02-09 05:12:50 --> Router Class Initialized
INFO - 2020-02-09 05:12:50 --> Output Class Initialized
INFO - 2020-02-09 05:12:50 --> Security Class Initialized
DEBUG - 2020-02-09 05:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:12:50 --> Input Class Initialized
INFO - 2020-02-09 05:12:50 --> Language Class Initialized
INFO - 2020-02-09 05:12:50 --> Language Class Initialized
INFO - 2020-02-09 05:12:50 --> Config Class Initialized
INFO - 2020-02-09 05:12:50 --> Loader Class Initialized
INFO - 2020-02-09 05:12:50 --> Helper loaded: url_helper
INFO - 2020-02-09 05:12:50 --> Helper loaded: file_helper
INFO - 2020-02-09 05:12:50 --> Helper loaded: form_helper
INFO - 2020-02-09 05:12:50 --> Helper loaded: my_helper
INFO - 2020-02-09 05:12:50 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:12:50 --> Controller Class Initialized
INFO - 2020-02-09 05:12:58 --> Config Class Initialized
INFO - 2020-02-09 05:12:58 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:12:58 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:12:58 --> Utf8 Class Initialized
INFO - 2020-02-09 05:12:58 --> URI Class Initialized
INFO - 2020-02-09 05:12:58 --> Router Class Initialized
INFO - 2020-02-09 05:12:58 --> Output Class Initialized
INFO - 2020-02-09 05:12:58 --> Security Class Initialized
DEBUG - 2020-02-09 05:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:12:58 --> Input Class Initialized
INFO - 2020-02-09 05:12:58 --> Language Class Initialized
INFO - 2020-02-09 05:12:58 --> Language Class Initialized
INFO - 2020-02-09 05:12:58 --> Config Class Initialized
INFO - 2020-02-09 05:12:58 --> Loader Class Initialized
INFO - 2020-02-09 05:12:58 --> Helper loaded: url_helper
INFO - 2020-02-09 05:12:58 --> Helper loaded: file_helper
INFO - 2020-02-09 05:12:58 --> Helper loaded: form_helper
INFO - 2020-02-09 05:12:58 --> Helper loaded: my_helper
INFO - 2020-02-09 05:12:58 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:12:58 --> Controller Class Initialized
DEBUG - 2020-02-09 05:12:58 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-09 05:12:59 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:12:59 --> Final output sent to browser
DEBUG - 2020-02-09 05:12:59 --> Total execution time: 0.4002
INFO - 2020-02-09 05:12:59 --> Config Class Initialized
INFO - 2020-02-09 05:12:59 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:12:59 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:12:59 --> Utf8 Class Initialized
INFO - 2020-02-09 05:12:59 --> URI Class Initialized
INFO - 2020-02-09 05:12:59 --> Router Class Initialized
INFO - 2020-02-09 05:12:59 --> Output Class Initialized
INFO - 2020-02-09 05:12:59 --> Security Class Initialized
DEBUG - 2020-02-09 05:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:12:59 --> Input Class Initialized
INFO - 2020-02-09 05:12:59 --> Language Class Initialized
INFO - 2020-02-09 05:12:59 --> Language Class Initialized
INFO - 2020-02-09 05:12:59 --> Config Class Initialized
INFO - 2020-02-09 05:12:59 --> Loader Class Initialized
INFO - 2020-02-09 05:12:59 --> Helper loaded: url_helper
INFO - 2020-02-09 05:12:59 --> Helper loaded: file_helper
INFO - 2020-02-09 05:12:59 --> Helper loaded: form_helper
INFO - 2020-02-09 05:12:59 --> Helper loaded: my_helper
INFO - 2020-02-09 05:12:59 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:12:59 --> Controller Class Initialized
INFO - 2020-02-09 05:13:09 --> Config Class Initialized
INFO - 2020-02-09 05:13:09 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:13:09 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:13:09 --> Utf8 Class Initialized
INFO - 2020-02-09 05:13:09 --> URI Class Initialized
INFO - 2020-02-09 05:13:09 --> Router Class Initialized
INFO - 2020-02-09 05:13:09 --> Output Class Initialized
INFO - 2020-02-09 05:13:09 --> Security Class Initialized
DEBUG - 2020-02-09 05:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:13:09 --> Input Class Initialized
INFO - 2020-02-09 05:13:09 --> Language Class Initialized
INFO - 2020-02-09 05:13:09 --> Language Class Initialized
INFO - 2020-02-09 05:13:09 --> Config Class Initialized
INFO - 2020-02-09 05:13:09 --> Loader Class Initialized
INFO - 2020-02-09 05:13:09 --> Helper loaded: url_helper
INFO - 2020-02-09 05:13:09 --> Helper loaded: file_helper
INFO - 2020-02-09 05:13:09 --> Helper loaded: form_helper
INFO - 2020-02-09 05:13:09 --> Helper loaded: my_helper
INFO - 2020-02-09 05:13:09 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:13:09 --> Controller Class Initialized
INFO - 2020-02-09 05:13:09 --> Final output sent to browser
DEBUG - 2020-02-09 05:13:09 --> Total execution time: 0.3762
INFO - 2020-02-09 05:13:09 --> Config Class Initialized
INFO - 2020-02-09 05:13:09 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:13:09 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:13:09 --> Utf8 Class Initialized
INFO - 2020-02-09 05:13:09 --> URI Class Initialized
INFO - 2020-02-09 05:13:09 --> Router Class Initialized
INFO - 2020-02-09 05:13:09 --> Output Class Initialized
INFO - 2020-02-09 05:13:09 --> Security Class Initialized
DEBUG - 2020-02-09 05:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:13:09 --> Input Class Initialized
INFO - 2020-02-09 05:13:09 --> Language Class Initialized
INFO - 2020-02-09 05:13:09 --> Language Class Initialized
INFO - 2020-02-09 05:13:09 --> Config Class Initialized
INFO - 2020-02-09 05:13:09 --> Loader Class Initialized
INFO - 2020-02-09 05:13:09 --> Helper loaded: url_helper
INFO - 2020-02-09 05:13:09 --> Helper loaded: file_helper
INFO - 2020-02-09 05:13:09 --> Helper loaded: form_helper
INFO - 2020-02-09 05:13:09 --> Helper loaded: my_helper
INFO - 2020-02-09 05:13:09 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:13:09 --> Controller Class Initialized
INFO - 2020-02-09 05:13:15 --> Config Class Initialized
INFO - 2020-02-09 05:13:15 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:13:15 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:13:15 --> Utf8 Class Initialized
INFO - 2020-02-09 05:13:15 --> URI Class Initialized
DEBUG - 2020-02-09 05:13:15 --> No URI present. Default controller set.
INFO - 2020-02-09 05:13:15 --> Router Class Initialized
INFO - 2020-02-09 05:13:16 --> Output Class Initialized
INFO - 2020-02-09 05:13:16 --> Security Class Initialized
DEBUG - 2020-02-09 05:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:13:16 --> Input Class Initialized
INFO - 2020-02-09 05:13:16 --> Language Class Initialized
INFO - 2020-02-09 05:13:16 --> Language Class Initialized
INFO - 2020-02-09 05:13:16 --> Config Class Initialized
INFO - 2020-02-09 05:13:16 --> Loader Class Initialized
INFO - 2020-02-09 05:13:16 --> Helper loaded: url_helper
INFO - 2020-02-09 05:13:16 --> Helper loaded: file_helper
INFO - 2020-02-09 05:13:16 --> Helper loaded: form_helper
INFO - 2020-02-09 05:13:16 --> Helper loaded: my_helper
INFO - 2020-02-09 05:13:16 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:13:16 --> Controller Class Initialized
DEBUG - 2020-02-09 05:13:16 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-09 05:13:16 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:13:16 --> Final output sent to browser
DEBUG - 2020-02-09 05:13:16 --> Total execution time: 0.6249
INFO - 2020-02-09 05:13:24 --> Config Class Initialized
INFO - 2020-02-09 05:13:24 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:13:24 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:13:24 --> Utf8 Class Initialized
INFO - 2020-02-09 05:13:24 --> URI Class Initialized
INFO - 2020-02-09 05:13:24 --> Router Class Initialized
INFO - 2020-02-09 05:13:24 --> Output Class Initialized
INFO - 2020-02-09 05:13:24 --> Security Class Initialized
DEBUG - 2020-02-09 05:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:13:24 --> Input Class Initialized
INFO - 2020-02-09 05:13:24 --> Language Class Initialized
INFO - 2020-02-09 05:13:24 --> Language Class Initialized
INFO - 2020-02-09 05:13:24 --> Config Class Initialized
INFO - 2020-02-09 05:13:24 --> Loader Class Initialized
INFO - 2020-02-09 05:13:24 --> Helper loaded: url_helper
INFO - 2020-02-09 05:13:24 --> Helper loaded: file_helper
INFO - 2020-02-09 05:13:24 --> Helper loaded: form_helper
INFO - 2020-02-09 05:13:24 --> Helper loaded: my_helper
INFO - 2020-02-09 05:13:24 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:13:24 --> Controller Class Initialized
DEBUG - 2020-02-09 05:13:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-09 05:13:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:13:24 --> Final output sent to browser
DEBUG - 2020-02-09 05:13:24 --> Total execution time: 0.3521
INFO - 2020-02-09 05:13:24 --> Config Class Initialized
INFO - 2020-02-09 05:13:24 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:13:25 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:13:25 --> Utf8 Class Initialized
INFO - 2020-02-09 05:13:25 --> URI Class Initialized
INFO - 2020-02-09 05:13:25 --> Router Class Initialized
INFO - 2020-02-09 05:13:25 --> Output Class Initialized
INFO - 2020-02-09 05:13:25 --> Security Class Initialized
DEBUG - 2020-02-09 05:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:13:25 --> Input Class Initialized
INFO - 2020-02-09 05:13:25 --> Language Class Initialized
INFO - 2020-02-09 05:13:25 --> Language Class Initialized
INFO - 2020-02-09 05:13:25 --> Config Class Initialized
INFO - 2020-02-09 05:13:25 --> Loader Class Initialized
INFO - 2020-02-09 05:13:25 --> Helper loaded: url_helper
INFO - 2020-02-09 05:13:25 --> Helper loaded: file_helper
INFO - 2020-02-09 05:13:25 --> Helper loaded: form_helper
INFO - 2020-02-09 05:13:25 --> Helper loaded: my_helper
INFO - 2020-02-09 05:13:25 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:13:25 --> Controller Class Initialized
INFO - 2020-02-09 05:13:26 --> Config Class Initialized
INFO - 2020-02-09 05:13:26 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:13:26 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:13:26 --> Utf8 Class Initialized
INFO - 2020-02-09 05:13:26 --> URI Class Initialized
INFO - 2020-02-09 05:13:26 --> Router Class Initialized
INFO - 2020-02-09 05:13:26 --> Output Class Initialized
INFO - 2020-02-09 05:13:26 --> Security Class Initialized
DEBUG - 2020-02-09 05:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:13:26 --> Input Class Initialized
INFO - 2020-02-09 05:13:26 --> Language Class Initialized
INFO - 2020-02-09 05:13:26 --> Language Class Initialized
INFO - 2020-02-09 05:13:26 --> Config Class Initialized
INFO - 2020-02-09 05:13:26 --> Loader Class Initialized
INFO - 2020-02-09 05:13:26 --> Helper loaded: url_helper
INFO - 2020-02-09 05:13:26 --> Helper loaded: file_helper
INFO - 2020-02-09 05:13:26 --> Helper loaded: form_helper
INFO - 2020-02-09 05:13:26 --> Helper loaded: my_helper
INFO - 2020-02-09 05:13:26 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:13:26 --> Controller Class Initialized
DEBUG - 2020-02-09 05:13:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-09 05:13:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:13:26 --> Final output sent to browser
DEBUG - 2020-02-09 05:13:26 --> Total execution time: 0.4036
INFO - 2020-02-09 05:13:33 --> Config Class Initialized
INFO - 2020-02-09 05:13:33 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:13:33 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:13:33 --> Utf8 Class Initialized
INFO - 2020-02-09 05:13:33 --> URI Class Initialized
INFO - 2020-02-09 05:13:33 --> Router Class Initialized
INFO - 2020-02-09 05:13:33 --> Output Class Initialized
INFO - 2020-02-09 05:13:33 --> Security Class Initialized
DEBUG - 2020-02-09 05:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:13:33 --> Input Class Initialized
INFO - 2020-02-09 05:13:33 --> Language Class Initialized
INFO - 2020-02-09 05:13:33 --> Language Class Initialized
INFO - 2020-02-09 05:13:33 --> Config Class Initialized
INFO - 2020-02-09 05:13:33 --> Loader Class Initialized
INFO - 2020-02-09 05:13:33 --> Helper loaded: url_helper
INFO - 2020-02-09 05:13:33 --> Helper loaded: file_helper
INFO - 2020-02-09 05:13:33 --> Helper loaded: form_helper
INFO - 2020-02-09 05:13:33 --> Helper loaded: my_helper
INFO - 2020-02-09 05:13:33 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:13:33 --> Controller Class Initialized
DEBUG - 2020-02-09 05:13:33 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-09 05:13:33 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:13:33 --> Final output sent to browser
DEBUG - 2020-02-09 05:13:33 --> Total execution time: 0.3577
INFO - 2020-02-09 05:13:33 --> Config Class Initialized
INFO - 2020-02-09 05:13:33 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:13:33 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:13:33 --> Utf8 Class Initialized
INFO - 2020-02-09 05:13:33 --> URI Class Initialized
INFO - 2020-02-09 05:13:33 --> Router Class Initialized
INFO - 2020-02-09 05:13:33 --> Output Class Initialized
INFO - 2020-02-09 05:13:33 --> Security Class Initialized
DEBUG - 2020-02-09 05:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:13:34 --> Input Class Initialized
INFO - 2020-02-09 05:13:34 --> Language Class Initialized
INFO - 2020-02-09 05:13:34 --> Language Class Initialized
INFO - 2020-02-09 05:13:34 --> Config Class Initialized
INFO - 2020-02-09 05:13:34 --> Loader Class Initialized
INFO - 2020-02-09 05:13:34 --> Helper loaded: url_helper
INFO - 2020-02-09 05:13:34 --> Helper loaded: file_helper
INFO - 2020-02-09 05:13:34 --> Helper loaded: form_helper
INFO - 2020-02-09 05:13:34 --> Helper loaded: my_helper
INFO - 2020-02-09 05:13:34 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:13:34 --> Controller Class Initialized
INFO - 2020-02-09 05:13:48 --> Config Class Initialized
INFO - 2020-02-09 05:13:48 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:13:48 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:13:48 --> Utf8 Class Initialized
INFO - 2020-02-09 05:13:48 --> URI Class Initialized
INFO - 2020-02-09 05:13:48 --> Router Class Initialized
INFO - 2020-02-09 05:13:48 --> Output Class Initialized
INFO - 2020-02-09 05:13:48 --> Security Class Initialized
DEBUG - 2020-02-09 05:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:13:48 --> Input Class Initialized
INFO - 2020-02-09 05:13:48 --> Language Class Initialized
INFO - 2020-02-09 05:13:48 --> Language Class Initialized
INFO - 2020-02-09 05:13:48 --> Config Class Initialized
INFO - 2020-02-09 05:13:48 --> Loader Class Initialized
INFO - 2020-02-09 05:13:48 --> Helper loaded: url_helper
INFO - 2020-02-09 05:13:48 --> Helper loaded: file_helper
INFO - 2020-02-09 05:13:48 --> Helper loaded: form_helper
INFO - 2020-02-09 05:13:48 --> Helper loaded: my_helper
INFO - 2020-02-09 05:13:48 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:13:48 --> Controller Class Initialized
DEBUG - 2020-02-09 05:13:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-09 05:13:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:13:48 --> Final output sent to browser
DEBUG - 2020-02-09 05:13:48 --> Total execution time: 0.3994
INFO - 2020-02-09 05:13:48 --> Config Class Initialized
INFO - 2020-02-09 05:13:48 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:13:48 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:13:48 --> Utf8 Class Initialized
INFO - 2020-02-09 05:13:49 --> URI Class Initialized
INFO - 2020-02-09 05:13:49 --> Router Class Initialized
INFO - 2020-02-09 05:13:49 --> Output Class Initialized
INFO - 2020-02-09 05:13:49 --> Security Class Initialized
DEBUG - 2020-02-09 05:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:13:49 --> Input Class Initialized
INFO - 2020-02-09 05:13:49 --> Language Class Initialized
INFO - 2020-02-09 05:13:49 --> Language Class Initialized
INFO - 2020-02-09 05:13:49 --> Config Class Initialized
INFO - 2020-02-09 05:13:49 --> Loader Class Initialized
INFO - 2020-02-09 05:13:49 --> Helper loaded: url_helper
INFO - 2020-02-09 05:13:49 --> Helper loaded: file_helper
INFO - 2020-02-09 05:13:49 --> Helper loaded: form_helper
INFO - 2020-02-09 05:13:49 --> Helper loaded: my_helper
INFO - 2020-02-09 05:13:49 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:13:49 --> Controller Class Initialized
INFO - 2020-02-09 05:13:50 --> Config Class Initialized
INFO - 2020-02-09 05:13:50 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:13:50 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:13:50 --> Utf8 Class Initialized
INFO - 2020-02-09 05:13:51 --> URI Class Initialized
INFO - 2020-02-09 05:13:51 --> Router Class Initialized
INFO - 2020-02-09 05:13:51 --> Output Class Initialized
INFO - 2020-02-09 05:13:51 --> Security Class Initialized
DEBUG - 2020-02-09 05:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:13:51 --> Input Class Initialized
INFO - 2020-02-09 05:13:51 --> Language Class Initialized
INFO - 2020-02-09 05:13:51 --> Language Class Initialized
INFO - 2020-02-09 05:13:51 --> Config Class Initialized
INFO - 2020-02-09 05:13:51 --> Loader Class Initialized
INFO - 2020-02-09 05:13:51 --> Helper loaded: url_helper
INFO - 2020-02-09 05:13:51 --> Helper loaded: file_helper
INFO - 2020-02-09 05:13:51 --> Helper loaded: form_helper
INFO - 2020-02-09 05:13:51 --> Helper loaded: my_helper
INFO - 2020-02-09 05:13:51 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:13:51 --> Controller Class Initialized
DEBUG - 2020-02-09 05:13:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-09 05:13:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:13:51 --> Final output sent to browser
DEBUG - 2020-02-09 05:13:51 --> Total execution time: 0.3883
INFO - 2020-02-09 05:14:07 --> Config Class Initialized
INFO - 2020-02-09 05:14:07 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:14:07 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:14:07 --> Utf8 Class Initialized
INFO - 2020-02-09 05:14:07 --> URI Class Initialized
INFO - 2020-02-09 05:14:07 --> Router Class Initialized
INFO - 2020-02-09 05:14:07 --> Output Class Initialized
INFO - 2020-02-09 05:14:07 --> Security Class Initialized
DEBUG - 2020-02-09 05:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:14:07 --> Input Class Initialized
INFO - 2020-02-09 05:14:07 --> Language Class Initialized
INFO - 2020-02-09 05:14:07 --> Language Class Initialized
INFO - 2020-02-09 05:14:07 --> Config Class Initialized
INFO - 2020-02-09 05:14:07 --> Loader Class Initialized
INFO - 2020-02-09 05:14:07 --> Helper loaded: url_helper
INFO - 2020-02-09 05:14:07 --> Helper loaded: file_helper
INFO - 2020-02-09 05:14:07 --> Helper loaded: form_helper
INFO - 2020-02-09 05:14:07 --> Helper loaded: my_helper
INFO - 2020-02-09 05:14:07 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:14:08 --> Controller Class Initialized
DEBUG - 2020-02-09 05:14:08 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-09 05:14:08 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:14:08 --> Final output sent to browser
DEBUG - 2020-02-09 05:14:08 --> Total execution time: 0.3979
INFO - 2020-02-09 05:14:10 --> Config Class Initialized
INFO - 2020-02-09 05:14:11 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:14:11 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:14:11 --> Utf8 Class Initialized
INFO - 2020-02-09 05:14:11 --> URI Class Initialized
INFO - 2020-02-09 05:14:11 --> Router Class Initialized
INFO - 2020-02-09 05:14:11 --> Output Class Initialized
INFO - 2020-02-09 05:14:11 --> Security Class Initialized
DEBUG - 2020-02-09 05:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:14:11 --> Input Class Initialized
INFO - 2020-02-09 05:14:11 --> Language Class Initialized
INFO - 2020-02-09 05:14:11 --> Language Class Initialized
INFO - 2020-02-09 05:14:11 --> Config Class Initialized
INFO - 2020-02-09 05:14:11 --> Loader Class Initialized
INFO - 2020-02-09 05:14:11 --> Helper loaded: url_helper
INFO - 2020-02-09 05:14:11 --> Helper loaded: file_helper
INFO - 2020-02-09 05:14:11 --> Helper loaded: form_helper
INFO - 2020-02-09 05:14:11 --> Helper loaded: my_helper
INFO - 2020-02-09 05:14:11 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:14:11 --> Controller Class Initialized
DEBUG - 2020-02-09 05:14:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-09 05:14:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:14:11 --> Final output sent to browser
DEBUG - 2020-02-09 05:14:11 --> Total execution time: 0.4410
INFO - 2020-02-09 05:14:11 --> Config Class Initialized
INFO - 2020-02-09 05:14:11 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:14:11 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:14:11 --> Utf8 Class Initialized
INFO - 2020-02-09 05:14:11 --> URI Class Initialized
INFO - 2020-02-09 05:14:11 --> Router Class Initialized
INFO - 2020-02-09 05:14:11 --> Output Class Initialized
INFO - 2020-02-09 05:14:11 --> Security Class Initialized
DEBUG - 2020-02-09 05:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:14:11 --> Input Class Initialized
INFO - 2020-02-09 05:14:11 --> Language Class Initialized
INFO - 2020-02-09 05:14:11 --> Language Class Initialized
INFO - 2020-02-09 05:14:11 --> Config Class Initialized
INFO - 2020-02-09 05:14:11 --> Loader Class Initialized
INFO - 2020-02-09 05:14:11 --> Helper loaded: url_helper
INFO - 2020-02-09 05:14:11 --> Helper loaded: file_helper
INFO - 2020-02-09 05:14:11 --> Helper loaded: form_helper
INFO - 2020-02-09 05:14:11 --> Helper loaded: my_helper
INFO - 2020-02-09 05:14:11 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:14:11 --> Controller Class Initialized
INFO - 2020-02-09 05:15:26 --> Config Class Initialized
INFO - 2020-02-09 05:15:26 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:15:26 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:15:26 --> Utf8 Class Initialized
INFO - 2020-02-09 05:15:26 --> URI Class Initialized
INFO - 2020-02-09 05:15:26 --> Router Class Initialized
INFO - 2020-02-09 05:15:26 --> Output Class Initialized
INFO - 2020-02-09 05:15:26 --> Security Class Initialized
DEBUG - 2020-02-09 05:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:15:26 --> Input Class Initialized
INFO - 2020-02-09 05:15:26 --> Language Class Initialized
INFO - 2020-02-09 05:15:26 --> Language Class Initialized
INFO - 2020-02-09 05:15:26 --> Config Class Initialized
INFO - 2020-02-09 05:15:26 --> Loader Class Initialized
INFO - 2020-02-09 05:15:26 --> Helper loaded: url_helper
INFO - 2020-02-09 05:15:26 --> Helper loaded: file_helper
INFO - 2020-02-09 05:15:26 --> Helper loaded: form_helper
INFO - 2020-02-09 05:15:26 --> Helper loaded: my_helper
INFO - 2020-02-09 05:15:26 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:15:26 --> Controller Class Initialized
DEBUG - 2020-02-09 05:15:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-09 05:15:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:15:26 --> Final output sent to browser
DEBUG - 2020-02-09 05:15:26 --> Total execution time: 0.3755
INFO - 2020-02-09 05:15:28 --> Config Class Initialized
INFO - 2020-02-09 05:15:28 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:15:28 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:15:28 --> Utf8 Class Initialized
INFO - 2020-02-09 05:15:28 --> URI Class Initialized
INFO - 2020-02-09 05:15:28 --> Router Class Initialized
INFO - 2020-02-09 05:15:28 --> Output Class Initialized
INFO - 2020-02-09 05:15:28 --> Security Class Initialized
DEBUG - 2020-02-09 05:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:15:28 --> Input Class Initialized
INFO - 2020-02-09 05:15:28 --> Language Class Initialized
INFO - 2020-02-09 05:15:28 --> Language Class Initialized
INFO - 2020-02-09 05:15:28 --> Config Class Initialized
INFO - 2020-02-09 05:15:28 --> Loader Class Initialized
INFO - 2020-02-09 05:15:28 --> Helper loaded: url_helper
INFO - 2020-02-09 05:15:28 --> Helper loaded: file_helper
INFO - 2020-02-09 05:15:28 --> Helper loaded: form_helper
INFO - 2020-02-09 05:15:28 --> Helper loaded: my_helper
INFO - 2020-02-09 05:15:28 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:15:28 --> Controller Class Initialized
DEBUG - 2020-02-09 05:15:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-09 05:15:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:15:28 --> Final output sent to browser
DEBUG - 2020-02-09 05:15:28 --> Total execution time: 0.3932
INFO - 2020-02-09 05:15:30 --> Config Class Initialized
INFO - 2020-02-09 05:15:30 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:15:30 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:15:30 --> Utf8 Class Initialized
INFO - 2020-02-09 05:15:30 --> URI Class Initialized
INFO - 2020-02-09 05:15:30 --> Router Class Initialized
INFO - 2020-02-09 05:15:30 --> Output Class Initialized
INFO - 2020-02-09 05:15:30 --> Security Class Initialized
DEBUG - 2020-02-09 05:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:15:30 --> Input Class Initialized
INFO - 2020-02-09 05:15:30 --> Language Class Initialized
INFO - 2020-02-09 05:15:30 --> Language Class Initialized
INFO - 2020-02-09 05:15:30 --> Config Class Initialized
INFO - 2020-02-09 05:15:30 --> Loader Class Initialized
INFO - 2020-02-09 05:15:30 --> Helper loaded: url_helper
INFO - 2020-02-09 05:15:30 --> Helper loaded: file_helper
INFO - 2020-02-09 05:15:30 --> Helper loaded: form_helper
INFO - 2020-02-09 05:15:30 --> Helper loaded: my_helper
INFO - 2020-02-09 05:15:30 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:15:30 --> Controller Class Initialized
DEBUG - 2020-02-09 05:15:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-09 05:15:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:15:30 --> Final output sent to browser
DEBUG - 2020-02-09 05:15:30 --> Total execution time: 0.3997
INFO - 2020-02-09 05:15:30 --> Config Class Initialized
INFO - 2020-02-09 05:15:30 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:15:30 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:15:30 --> Utf8 Class Initialized
INFO - 2020-02-09 05:15:30 --> URI Class Initialized
INFO - 2020-02-09 05:15:30 --> Router Class Initialized
INFO - 2020-02-09 05:15:30 --> Output Class Initialized
INFO - 2020-02-09 05:15:30 --> Security Class Initialized
DEBUG - 2020-02-09 05:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:15:30 --> Input Class Initialized
INFO - 2020-02-09 05:15:30 --> Language Class Initialized
INFO - 2020-02-09 05:15:30 --> Language Class Initialized
INFO - 2020-02-09 05:15:30 --> Config Class Initialized
INFO - 2020-02-09 05:15:30 --> Loader Class Initialized
INFO - 2020-02-09 05:15:30 --> Helper loaded: url_helper
INFO - 2020-02-09 05:15:30 --> Helper loaded: file_helper
INFO - 2020-02-09 05:15:30 --> Helper loaded: form_helper
INFO - 2020-02-09 05:15:30 --> Helper loaded: my_helper
INFO - 2020-02-09 05:15:30 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:15:30 --> Controller Class Initialized
INFO - 2020-02-09 05:15:33 --> Config Class Initialized
INFO - 2020-02-09 05:15:33 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:15:33 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:15:33 --> Utf8 Class Initialized
INFO - 2020-02-09 05:15:33 --> URI Class Initialized
INFO - 2020-02-09 05:15:33 --> Router Class Initialized
INFO - 2020-02-09 05:15:33 --> Output Class Initialized
INFO - 2020-02-09 05:15:33 --> Security Class Initialized
DEBUG - 2020-02-09 05:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:15:33 --> Input Class Initialized
INFO - 2020-02-09 05:15:33 --> Language Class Initialized
INFO - 2020-02-09 05:15:33 --> Language Class Initialized
INFO - 2020-02-09 05:15:33 --> Config Class Initialized
INFO - 2020-02-09 05:15:33 --> Loader Class Initialized
INFO - 2020-02-09 05:15:33 --> Helper loaded: url_helper
INFO - 2020-02-09 05:15:33 --> Helper loaded: file_helper
INFO - 2020-02-09 05:15:33 --> Helper loaded: form_helper
INFO - 2020-02-09 05:15:33 --> Helper loaded: my_helper
INFO - 2020-02-09 05:15:33 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:15:33 --> Controller Class Initialized
INFO - 2020-02-09 05:15:33 --> Final output sent to browser
DEBUG - 2020-02-09 05:15:33 --> Total execution time: 0.4252
INFO - 2020-02-09 05:15:33 --> Config Class Initialized
INFO - 2020-02-09 05:15:33 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:15:33 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:15:33 --> Utf8 Class Initialized
INFO - 2020-02-09 05:15:33 --> URI Class Initialized
INFO - 2020-02-09 05:15:33 --> Router Class Initialized
INFO - 2020-02-09 05:15:33 --> Output Class Initialized
INFO - 2020-02-09 05:15:33 --> Security Class Initialized
DEBUG - 2020-02-09 05:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:15:33 --> Input Class Initialized
INFO - 2020-02-09 05:15:33 --> Language Class Initialized
INFO - 2020-02-09 05:15:33 --> Language Class Initialized
INFO - 2020-02-09 05:15:33 --> Config Class Initialized
INFO - 2020-02-09 05:15:33 --> Loader Class Initialized
INFO - 2020-02-09 05:15:33 --> Helper loaded: url_helper
INFO - 2020-02-09 05:15:33 --> Helper loaded: file_helper
INFO - 2020-02-09 05:15:33 --> Helper loaded: form_helper
INFO - 2020-02-09 05:15:33 --> Helper loaded: my_helper
INFO - 2020-02-09 05:15:33 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:15:34 --> Controller Class Initialized
INFO - 2020-02-09 05:15:34 --> Config Class Initialized
INFO - 2020-02-09 05:15:34 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:15:34 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:15:34 --> Utf8 Class Initialized
INFO - 2020-02-09 05:15:34 --> URI Class Initialized
INFO - 2020-02-09 05:15:34 --> Router Class Initialized
INFO - 2020-02-09 05:15:34 --> Output Class Initialized
INFO - 2020-02-09 05:15:34 --> Security Class Initialized
DEBUG - 2020-02-09 05:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:15:34 --> Input Class Initialized
INFO - 2020-02-09 05:15:34 --> Language Class Initialized
INFO - 2020-02-09 05:15:34 --> Language Class Initialized
INFO - 2020-02-09 05:15:34 --> Config Class Initialized
INFO - 2020-02-09 05:15:34 --> Loader Class Initialized
INFO - 2020-02-09 05:15:34 --> Helper loaded: url_helper
INFO - 2020-02-09 05:15:34 --> Helper loaded: file_helper
INFO - 2020-02-09 05:15:34 --> Helper loaded: form_helper
INFO - 2020-02-09 05:15:34 --> Helper loaded: my_helper
INFO - 2020-02-09 05:15:34 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:15:34 --> Controller Class Initialized
DEBUG - 2020-02-09 05:15:34 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-09 05:15:34 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:15:34 --> Final output sent to browser
DEBUG - 2020-02-09 05:15:34 --> Total execution time: 0.3743
INFO - 2020-02-09 05:15:35 --> Config Class Initialized
INFO - 2020-02-09 05:15:35 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:15:35 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:15:35 --> Utf8 Class Initialized
INFO - 2020-02-09 05:15:35 --> URI Class Initialized
INFO - 2020-02-09 05:15:35 --> Router Class Initialized
INFO - 2020-02-09 05:15:35 --> Output Class Initialized
INFO - 2020-02-09 05:15:35 --> Security Class Initialized
DEBUG - 2020-02-09 05:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:15:35 --> Input Class Initialized
INFO - 2020-02-09 05:15:35 --> Language Class Initialized
INFO - 2020-02-09 05:15:35 --> Language Class Initialized
INFO - 2020-02-09 05:15:35 --> Config Class Initialized
INFO - 2020-02-09 05:15:35 --> Loader Class Initialized
INFO - 2020-02-09 05:15:35 --> Helper loaded: url_helper
INFO - 2020-02-09 05:15:35 --> Helper loaded: file_helper
INFO - 2020-02-09 05:15:35 --> Helper loaded: form_helper
INFO - 2020-02-09 05:15:35 --> Helper loaded: my_helper
INFO - 2020-02-09 05:15:35 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:15:35 --> Controller Class Initialized
INFO - 2020-02-09 05:15:37 --> Config Class Initialized
INFO - 2020-02-09 05:15:37 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:15:37 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:15:37 --> Utf8 Class Initialized
INFO - 2020-02-09 05:15:37 --> URI Class Initialized
INFO - 2020-02-09 05:15:37 --> Router Class Initialized
INFO - 2020-02-09 05:15:37 --> Output Class Initialized
INFO - 2020-02-09 05:15:37 --> Security Class Initialized
DEBUG - 2020-02-09 05:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:15:37 --> Input Class Initialized
INFO - 2020-02-09 05:15:37 --> Language Class Initialized
INFO - 2020-02-09 05:15:37 --> Language Class Initialized
INFO - 2020-02-09 05:15:37 --> Config Class Initialized
INFO - 2020-02-09 05:15:37 --> Loader Class Initialized
INFO - 2020-02-09 05:15:37 --> Helper loaded: url_helper
INFO - 2020-02-09 05:15:37 --> Helper loaded: file_helper
INFO - 2020-02-09 05:15:37 --> Helper loaded: form_helper
INFO - 2020-02-09 05:15:37 --> Helper loaded: my_helper
INFO - 2020-02-09 05:15:37 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:15:37 --> Controller Class Initialized
DEBUG - 2020-02-09 05:15:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-09 05:15:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:15:37 --> Final output sent to browser
DEBUG - 2020-02-09 05:15:37 --> Total execution time: 0.4646
INFO - 2020-02-09 05:15:38 --> Config Class Initialized
INFO - 2020-02-09 05:15:38 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:15:38 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:15:38 --> Utf8 Class Initialized
INFO - 2020-02-09 05:15:38 --> URI Class Initialized
INFO - 2020-02-09 05:15:38 --> Router Class Initialized
INFO - 2020-02-09 05:15:38 --> Output Class Initialized
INFO - 2020-02-09 05:15:38 --> Security Class Initialized
DEBUG - 2020-02-09 05:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:15:38 --> Input Class Initialized
INFO - 2020-02-09 05:15:38 --> Language Class Initialized
INFO - 2020-02-09 05:15:38 --> Language Class Initialized
INFO - 2020-02-09 05:15:38 --> Config Class Initialized
INFO - 2020-02-09 05:15:38 --> Loader Class Initialized
INFO - 2020-02-09 05:15:38 --> Helper loaded: url_helper
INFO - 2020-02-09 05:15:38 --> Helper loaded: file_helper
INFO - 2020-02-09 05:15:38 --> Helper loaded: form_helper
INFO - 2020-02-09 05:15:38 --> Helper loaded: my_helper
INFO - 2020-02-09 05:15:38 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:15:38 --> Controller Class Initialized
DEBUG - 2020-02-09 05:15:38 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-09 05:15:38 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:15:38 --> Final output sent to browser
DEBUG - 2020-02-09 05:15:38 --> Total execution time: 0.4702
INFO - 2020-02-09 05:16:09 --> Config Class Initialized
INFO - 2020-02-09 05:16:09 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:16:09 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:16:09 --> Utf8 Class Initialized
INFO - 2020-02-09 05:16:09 --> URI Class Initialized
INFO - 2020-02-09 05:16:09 --> Router Class Initialized
INFO - 2020-02-09 05:16:09 --> Output Class Initialized
INFO - 2020-02-09 05:16:09 --> Security Class Initialized
DEBUG - 2020-02-09 05:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:16:09 --> Input Class Initialized
INFO - 2020-02-09 05:16:09 --> Language Class Initialized
INFO - 2020-02-09 05:16:09 --> Language Class Initialized
INFO - 2020-02-09 05:16:09 --> Config Class Initialized
INFO - 2020-02-09 05:16:09 --> Loader Class Initialized
INFO - 2020-02-09 05:16:09 --> Helper loaded: url_helper
INFO - 2020-02-09 05:16:09 --> Helper loaded: file_helper
INFO - 2020-02-09 05:16:09 --> Helper loaded: form_helper
INFO - 2020-02-09 05:16:09 --> Helper loaded: my_helper
INFO - 2020-02-09 05:16:09 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:16:09 --> Controller Class Initialized
DEBUG - 2020-02-09 05:16:09 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-09 05:16:09 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:16:09 --> Final output sent to browser
DEBUG - 2020-02-09 05:16:09 --> Total execution time: 0.4845
INFO - 2020-02-09 05:16:09 --> Config Class Initialized
INFO - 2020-02-09 05:16:09 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:16:09 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:16:09 --> Utf8 Class Initialized
INFO - 2020-02-09 05:16:09 --> URI Class Initialized
INFO - 2020-02-09 05:16:09 --> Router Class Initialized
INFO - 2020-02-09 05:16:09 --> Output Class Initialized
INFO - 2020-02-09 05:16:09 --> Config Class Initialized
INFO - 2020-02-09 05:16:09 --> Hooks Class Initialized
INFO - 2020-02-09 05:16:09 --> Security Class Initialized
DEBUG - 2020-02-09 05:16:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 05:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:16:10 --> Utf8 Class Initialized
INFO - 2020-02-09 05:16:10 --> Input Class Initialized
INFO - 2020-02-09 05:16:10 --> Language Class Initialized
INFO - 2020-02-09 05:16:10 --> URI Class Initialized
INFO - 2020-02-09 05:16:10 --> Router Class Initialized
INFO - 2020-02-09 05:16:10 --> Language Class Initialized
INFO - 2020-02-09 05:16:10 --> Config Class Initialized
INFO - 2020-02-09 05:16:10 --> Output Class Initialized
INFO - 2020-02-09 05:16:10 --> Loader Class Initialized
INFO - 2020-02-09 05:16:10 --> Security Class Initialized
INFO - 2020-02-09 05:16:10 --> Helper loaded: url_helper
DEBUG - 2020-02-09 05:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:16:10 --> Input Class Initialized
INFO - 2020-02-09 05:16:10 --> Helper loaded: file_helper
INFO - 2020-02-09 05:16:10 --> Language Class Initialized
INFO - 2020-02-09 05:16:10 --> Helper loaded: form_helper
INFO - 2020-02-09 05:16:10 --> Helper loaded: my_helper
INFO - 2020-02-09 05:16:10 --> Language Class Initialized
INFO - 2020-02-09 05:16:10 --> Config Class Initialized
INFO - 2020-02-09 05:16:10 --> Database Driver Class Initialized
INFO - 2020-02-09 05:16:10 --> Loader Class Initialized
DEBUG - 2020-02-09 05:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:16:10 --> Helper loaded: url_helper
INFO - 2020-02-09 05:16:10 --> Controller Class Initialized
INFO - 2020-02-09 05:16:10 --> Helper loaded: file_helper
INFO - 2020-02-09 05:16:10 --> Helper loaded: form_helper
INFO - 2020-02-09 05:16:10 --> Helper loaded: my_helper
INFO - 2020-02-09 05:16:10 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:16:10 --> Controller Class Initialized
DEBUG - 2020-02-09 05:16:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-09 05:16:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:16:10 --> Final output sent to browser
DEBUG - 2020-02-09 05:16:10 --> Total execution time: 0.4363
INFO - 2020-02-09 05:16:18 --> Config Class Initialized
INFO - 2020-02-09 05:16:18 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:16:18 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:16:18 --> Utf8 Class Initialized
INFO - 2020-02-09 05:16:18 --> URI Class Initialized
INFO - 2020-02-09 05:16:18 --> Router Class Initialized
INFO - 2020-02-09 05:16:18 --> Output Class Initialized
INFO - 2020-02-09 05:16:18 --> Security Class Initialized
DEBUG - 2020-02-09 05:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:16:18 --> Input Class Initialized
INFO - 2020-02-09 05:16:18 --> Language Class Initialized
INFO - 2020-02-09 05:16:18 --> Language Class Initialized
INFO - 2020-02-09 05:16:18 --> Config Class Initialized
INFO - 2020-02-09 05:16:18 --> Loader Class Initialized
INFO - 2020-02-09 05:16:18 --> Helper loaded: url_helper
INFO - 2020-02-09 05:16:18 --> Helper loaded: file_helper
INFO - 2020-02-09 05:16:18 --> Helper loaded: form_helper
INFO - 2020-02-09 05:16:18 --> Helper loaded: my_helper
INFO - 2020-02-09 05:16:18 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:16:18 --> Controller Class Initialized
DEBUG - 2020-02-09 05:16:18 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-09 05:16:18 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:16:18 --> Final output sent to browser
DEBUG - 2020-02-09 05:16:18 --> Total execution time: 0.4142
INFO - 2020-02-09 05:16:18 --> Config Class Initialized
INFO - 2020-02-09 05:16:18 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:16:18 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:16:18 --> Utf8 Class Initialized
INFO - 2020-02-09 05:16:18 --> URI Class Initialized
INFO - 2020-02-09 05:16:18 --> Router Class Initialized
INFO - 2020-02-09 05:16:18 --> Output Class Initialized
INFO - 2020-02-09 05:16:18 --> Security Class Initialized
DEBUG - 2020-02-09 05:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:16:18 --> Input Class Initialized
INFO - 2020-02-09 05:16:18 --> Language Class Initialized
INFO - 2020-02-09 05:16:19 --> Language Class Initialized
INFO - 2020-02-09 05:16:19 --> Config Class Initialized
INFO - 2020-02-09 05:16:19 --> Loader Class Initialized
INFO - 2020-02-09 05:16:19 --> Helper loaded: url_helper
INFO - 2020-02-09 05:16:19 --> Helper loaded: file_helper
INFO - 2020-02-09 05:16:19 --> Helper loaded: form_helper
INFO - 2020-02-09 05:16:19 --> Helper loaded: my_helper
INFO - 2020-02-09 05:16:19 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:16:19 --> Controller Class Initialized
INFO - 2020-02-09 05:16:20 --> Config Class Initialized
INFO - 2020-02-09 05:16:20 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:16:20 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:16:20 --> Utf8 Class Initialized
INFO - 2020-02-09 05:16:20 --> URI Class Initialized
INFO - 2020-02-09 05:16:20 --> Router Class Initialized
INFO - 2020-02-09 05:16:20 --> Output Class Initialized
INFO - 2020-02-09 05:16:20 --> Security Class Initialized
DEBUG - 2020-02-09 05:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:16:20 --> Input Class Initialized
INFO - 2020-02-09 05:16:20 --> Language Class Initialized
INFO - 2020-02-09 05:16:20 --> Language Class Initialized
INFO - 2020-02-09 05:16:20 --> Config Class Initialized
INFO - 2020-02-09 05:16:20 --> Loader Class Initialized
INFO - 2020-02-09 05:16:21 --> Helper loaded: url_helper
INFO - 2020-02-09 05:16:21 --> Helper loaded: file_helper
INFO - 2020-02-09 05:16:21 --> Helper loaded: form_helper
INFO - 2020-02-09 05:16:21 --> Helper loaded: my_helper
INFO - 2020-02-09 05:16:21 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:16:21 --> Controller Class Initialized
INFO - 2020-02-09 05:16:21 --> Final output sent to browser
DEBUG - 2020-02-09 05:16:21 --> Total execution time: 0.3528
INFO - 2020-02-09 05:16:21 --> Config Class Initialized
INFO - 2020-02-09 05:16:21 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:16:21 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:16:21 --> Utf8 Class Initialized
INFO - 2020-02-09 05:16:21 --> URI Class Initialized
INFO - 2020-02-09 05:16:21 --> Router Class Initialized
INFO - 2020-02-09 05:16:21 --> Output Class Initialized
INFO - 2020-02-09 05:16:21 --> Security Class Initialized
DEBUG - 2020-02-09 05:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:16:21 --> Input Class Initialized
INFO - 2020-02-09 05:16:21 --> Language Class Initialized
INFO - 2020-02-09 05:16:21 --> Language Class Initialized
INFO - 2020-02-09 05:16:21 --> Config Class Initialized
INFO - 2020-02-09 05:16:21 --> Loader Class Initialized
INFO - 2020-02-09 05:16:21 --> Helper loaded: url_helper
INFO - 2020-02-09 05:16:21 --> Helper loaded: file_helper
INFO - 2020-02-09 05:16:21 --> Helper loaded: form_helper
INFO - 2020-02-09 05:16:21 --> Helper loaded: my_helper
INFO - 2020-02-09 05:16:21 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:16:21 --> Controller Class Initialized
INFO - 2020-02-09 05:16:24 --> Config Class Initialized
INFO - 2020-02-09 05:16:24 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:16:24 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:16:24 --> Utf8 Class Initialized
INFO - 2020-02-09 05:16:24 --> URI Class Initialized
INFO - 2020-02-09 05:16:24 --> Router Class Initialized
INFO - 2020-02-09 05:16:24 --> Output Class Initialized
INFO - 2020-02-09 05:16:24 --> Security Class Initialized
DEBUG - 2020-02-09 05:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:16:24 --> Input Class Initialized
INFO - 2020-02-09 05:16:24 --> Language Class Initialized
INFO - 2020-02-09 05:16:24 --> Language Class Initialized
INFO - 2020-02-09 05:16:24 --> Config Class Initialized
INFO - 2020-02-09 05:16:25 --> Loader Class Initialized
INFO - 2020-02-09 05:16:25 --> Helper loaded: url_helper
INFO - 2020-02-09 05:16:25 --> Helper loaded: file_helper
INFO - 2020-02-09 05:16:25 --> Helper loaded: form_helper
INFO - 2020-02-09 05:16:25 --> Helper loaded: my_helper
INFO - 2020-02-09 05:16:25 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:16:25 --> Controller Class Initialized
DEBUG - 2020-02-09 05:16:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-09 05:16:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:16:25 --> Final output sent to browser
DEBUG - 2020-02-09 05:16:25 --> Total execution time: 0.3866
INFO - 2020-02-09 05:16:45 --> Config Class Initialized
INFO - 2020-02-09 05:16:45 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:16:45 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:16:45 --> Utf8 Class Initialized
INFO - 2020-02-09 05:16:45 --> URI Class Initialized
INFO - 2020-02-09 05:16:45 --> Router Class Initialized
INFO - 2020-02-09 05:16:45 --> Output Class Initialized
INFO - 2020-02-09 05:16:45 --> Security Class Initialized
DEBUG - 2020-02-09 05:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:16:45 --> Input Class Initialized
INFO - 2020-02-09 05:16:45 --> Language Class Initialized
INFO - 2020-02-09 05:16:45 --> Language Class Initialized
INFO - 2020-02-09 05:16:45 --> Config Class Initialized
INFO - 2020-02-09 05:16:45 --> Loader Class Initialized
INFO - 2020-02-09 05:16:45 --> Helper loaded: url_helper
INFO - 2020-02-09 05:16:45 --> Helper loaded: file_helper
INFO - 2020-02-09 05:16:45 --> Helper loaded: form_helper
INFO - 2020-02-09 05:16:45 --> Helper loaded: my_helper
INFO - 2020-02-09 05:16:45 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:16:45 --> Controller Class Initialized
INFO - 2020-02-09 05:16:45 --> Final output sent to browser
DEBUG - 2020-02-09 05:16:45 --> Total execution time: 0.4059
INFO - 2020-02-09 05:16:49 --> Config Class Initialized
INFO - 2020-02-09 05:16:49 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:16:49 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:16:49 --> Utf8 Class Initialized
INFO - 2020-02-09 05:16:49 --> URI Class Initialized
INFO - 2020-02-09 05:16:49 --> Router Class Initialized
INFO - 2020-02-09 05:16:49 --> Output Class Initialized
INFO - 2020-02-09 05:16:49 --> Security Class Initialized
DEBUG - 2020-02-09 05:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:16:49 --> Input Class Initialized
INFO - 2020-02-09 05:16:49 --> Language Class Initialized
INFO - 2020-02-09 05:16:49 --> Language Class Initialized
INFO - 2020-02-09 05:16:49 --> Config Class Initialized
INFO - 2020-02-09 05:16:49 --> Loader Class Initialized
INFO - 2020-02-09 05:16:49 --> Helper loaded: url_helper
INFO - 2020-02-09 05:16:49 --> Helper loaded: file_helper
INFO - 2020-02-09 05:16:49 --> Helper loaded: form_helper
INFO - 2020-02-09 05:16:49 --> Helper loaded: my_helper
INFO - 2020-02-09 05:16:49 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:16:49 --> Controller Class Initialized
DEBUG - 2020-02-09 05:16:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-09 05:16:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:16:49 --> Final output sent to browser
DEBUG - 2020-02-09 05:16:49 --> Total execution time: 0.4559
INFO - 2020-02-09 05:16:51 --> Config Class Initialized
INFO - 2020-02-09 05:16:51 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:16:51 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:16:51 --> Utf8 Class Initialized
INFO - 2020-02-09 05:16:51 --> URI Class Initialized
INFO - 2020-02-09 05:16:51 --> Router Class Initialized
INFO - 2020-02-09 05:16:51 --> Output Class Initialized
INFO - 2020-02-09 05:16:51 --> Security Class Initialized
DEBUG - 2020-02-09 05:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:16:51 --> Input Class Initialized
INFO - 2020-02-09 05:16:51 --> Language Class Initialized
INFO - 2020-02-09 05:16:51 --> Language Class Initialized
INFO - 2020-02-09 05:16:51 --> Config Class Initialized
INFO - 2020-02-09 05:16:51 --> Loader Class Initialized
INFO - 2020-02-09 05:16:51 --> Helper loaded: url_helper
INFO - 2020-02-09 05:16:51 --> Helper loaded: file_helper
INFO - 2020-02-09 05:16:51 --> Helper loaded: form_helper
INFO - 2020-02-09 05:16:51 --> Helper loaded: my_helper
INFO - 2020-02-09 05:16:51 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:16:51 --> Controller Class Initialized
DEBUG - 2020-02-09 05:16:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-09 05:16:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:16:51 --> Final output sent to browser
DEBUG - 2020-02-09 05:16:51 --> Total execution time: 0.4318
INFO - 2020-02-09 05:17:05 --> Config Class Initialized
INFO - 2020-02-09 05:17:05 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:17:05 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:17:05 --> Utf8 Class Initialized
INFO - 2020-02-09 05:17:05 --> URI Class Initialized
INFO - 2020-02-09 05:17:05 --> Router Class Initialized
INFO - 2020-02-09 05:17:05 --> Output Class Initialized
INFO - 2020-02-09 05:17:05 --> Security Class Initialized
DEBUG - 2020-02-09 05:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:17:05 --> Input Class Initialized
INFO - 2020-02-09 05:17:05 --> Language Class Initialized
INFO - 2020-02-09 05:17:05 --> Language Class Initialized
INFO - 2020-02-09 05:17:05 --> Config Class Initialized
INFO - 2020-02-09 05:17:05 --> Loader Class Initialized
INFO - 2020-02-09 05:17:05 --> Helper loaded: url_helper
INFO - 2020-02-09 05:17:05 --> Helper loaded: file_helper
INFO - 2020-02-09 05:17:05 --> Helper loaded: form_helper
INFO - 2020-02-09 05:17:05 --> Helper loaded: my_helper
INFO - 2020-02-09 05:17:05 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:17:05 --> Controller Class Initialized
ERROR - 2020-02-09 05:17:05 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`db_nilaik13`.`t_kelas_siswa`, CONSTRAINT `t_kelas_siswa_ibfk_2` FOREIGN KEY (`id_siswa`) REFERENCES `m_siswa` (`id`)) - Invalid query: INSERT IGNORE INTO t_kelas_siswa (id_kelas, id_siswa, ta) VALUES ('1', '', '2018');
INFO - 2020-02-09 05:17:05 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-09 05:17:10 --> Config Class Initialized
INFO - 2020-02-09 05:17:10 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:17:10 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:17:10 --> Utf8 Class Initialized
INFO - 2020-02-09 05:17:10 --> URI Class Initialized
INFO - 2020-02-09 05:17:10 --> Router Class Initialized
INFO - 2020-02-09 05:17:10 --> Output Class Initialized
INFO - 2020-02-09 05:17:10 --> Security Class Initialized
DEBUG - 2020-02-09 05:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:17:10 --> Input Class Initialized
INFO - 2020-02-09 05:17:10 --> Language Class Initialized
INFO - 2020-02-09 05:17:10 --> Language Class Initialized
INFO - 2020-02-09 05:17:10 --> Config Class Initialized
INFO - 2020-02-09 05:17:10 --> Loader Class Initialized
INFO - 2020-02-09 05:17:10 --> Helper loaded: url_helper
INFO - 2020-02-09 05:17:10 --> Helper loaded: file_helper
INFO - 2020-02-09 05:17:10 --> Helper loaded: form_helper
INFO - 2020-02-09 05:17:10 --> Helper loaded: my_helper
INFO - 2020-02-09 05:17:10 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:17:11 --> Controller Class Initialized
DEBUG - 2020-02-09 05:17:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-09 05:17:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:17:11 --> Final output sent to browser
DEBUG - 2020-02-09 05:17:11 --> Total execution time: 0.4454
INFO - 2020-02-09 05:17:15 --> Config Class Initialized
INFO - 2020-02-09 05:17:15 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:17:15 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:17:15 --> Utf8 Class Initialized
INFO - 2020-02-09 05:17:15 --> URI Class Initialized
INFO - 2020-02-09 05:17:15 --> Router Class Initialized
INFO - 2020-02-09 05:17:15 --> Output Class Initialized
INFO - 2020-02-09 05:17:15 --> Security Class Initialized
DEBUG - 2020-02-09 05:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:17:15 --> Input Class Initialized
INFO - 2020-02-09 05:17:15 --> Language Class Initialized
INFO - 2020-02-09 05:17:16 --> Language Class Initialized
INFO - 2020-02-09 05:17:16 --> Config Class Initialized
INFO - 2020-02-09 05:17:16 --> Loader Class Initialized
INFO - 2020-02-09 05:17:16 --> Helper loaded: url_helper
INFO - 2020-02-09 05:17:16 --> Helper loaded: file_helper
INFO - 2020-02-09 05:17:16 --> Helper loaded: form_helper
INFO - 2020-02-09 05:17:16 --> Helper loaded: my_helper
INFO - 2020-02-09 05:17:16 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:17:16 --> Controller Class Initialized
DEBUG - 2020-02-09 05:17:16 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-09 05:17:16 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:17:16 --> Final output sent to browser
DEBUG - 2020-02-09 05:17:16 --> Total execution time: 0.4960
INFO - 2020-02-09 05:17:29 --> Config Class Initialized
INFO - 2020-02-09 05:17:29 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:17:29 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:17:29 --> Utf8 Class Initialized
INFO - 2020-02-09 05:17:29 --> URI Class Initialized
INFO - 2020-02-09 05:17:29 --> Router Class Initialized
INFO - 2020-02-09 05:17:29 --> Output Class Initialized
INFO - 2020-02-09 05:17:29 --> Security Class Initialized
DEBUG - 2020-02-09 05:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:17:29 --> Input Class Initialized
INFO - 2020-02-09 05:17:29 --> Language Class Initialized
INFO - 2020-02-09 05:17:29 --> Language Class Initialized
INFO - 2020-02-09 05:17:29 --> Config Class Initialized
INFO - 2020-02-09 05:17:29 --> Loader Class Initialized
INFO - 2020-02-09 05:17:29 --> Helper loaded: url_helper
INFO - 2020-02-09 05:17:29 --> Helper loaded: file_helper
INFO - 2020-02-09 05:17:29 --> Helper loaded: form_helper
INFO - 2020-02-09 05:17:29 --> Helper loaded: my_helper
INFO - 2020-02-09 05:17:29 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:17:29 --> Controller Class Initialized
DEBUG - 2020-02-09 05:17:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-09 05:17:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:17:29 --> Final output sent to browser
DEBUG - 2020-02-09 05:17:29 --> Total execution time: 0.3987
INFO - 2020-02-09 05:18:14 --> Config Class Initialized
INFO - 2020-02-09 05:18:14 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:18:14 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:18:14 --> Utf8 Class Initialized
INFO - 2020-02-09 05:18:14 --> URI Class Initialized
INFO - 2020-02-09 05:18:14 --> Router Class Initialized
INFO - 2020-02-09 05:18:14 --> Output Class Initialized
INFO - 2020-02-09 05:18:14 --> Security Class Initialized
DEBUG - 2020-02-09 05:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:18:14 --> Input Class Initialized
INFO - 2020-02-09 05:18:14 --> Language Class Initialized
INFO - 2020-02-09 05:18:14 --> Language Class Initialized
INFO - 2020-02-09 05:18:14 --> Config Class Initialized
INFO - 2020-02-09 05:18:14 --> Loader Class Initialized
INFO - 2020-02-09 05:18:14 --> Helper loaded: url_helper
INFO - 2020-02-09 05:18:14 --> Helper loaded: file_helper
INFO - 2020-02-09 05:18:14 --> Helper loaded: form_helper
INFO - 2020-02-09 05:18:14 --> Helper loaded: my_helper
INFO - 2020-02-09 05:18:14 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:18:14 --> Controller Class Initialized
DEBUG - 2020-02-09 05:18:14 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-09 05:18:14 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:18:14 --> Final output sent to browser
DEBUG - 2020-02-09 05:18:14 --> Total execution time: 0.4817
INFO - 2020-02-09 05:18:23 --> Config Class Initialized
INFO - 2020-02-09 05:18:23 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:18:23 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:18:23 --> Utf8 Class Initialized
INFO - 2020-02-09 05:18:23 --> URI Class Initialized
INFO - 2020-02-09 05:18:23 --> Router Class Initialized
INFO - 2020-02-09 05:18:23 --> Output Class Initialized
INFO - 2020-02-09 05:18:23 --> Security Class Initialized
DEBUG - 2020-02-09 05:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:18:23 --> Input Class Initialized
INFO - 2020-02-09 05:18:23 --> Language Class Initialized
INFO - 2020-02-09 05:18:23 --> Language Class Initialized
INFO - 2020-02-09 05:18:23 --> Config Class Initialized
INFO - 2020-02-09 05:18:23 --> Loader Class Initialized
INFO - 2020-02-09 05:18:23 --> Helper loaded: url_helper
INFO - 2020-02-09 05:18:23 --> Helper loaded: file_helper
INFO - 2020-02-09 05:18:23 --> Helper loaded: form_helper
INFO - 2020-02-09 05:18:23 --> Helper loaded: my_helper
INFO - 2020-02-09 05:18:23 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:18:23 --> Controller Class Initialized
DEBUG - 2020-02-09 05:18:23 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/list.php
DEBUG - 2020-02-09 05:18:23 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:18:23 --> Final output sent to browser
DEBUG - 2020-02-09 05:18:23 --> Total execution time: 0.4484
INFO - 2020-02-09 05:18:23 --> Config Class Initialized
INFO - 2020-02-09 05:18:23 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:18:23 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:18:23 --> Utf8 Class Initialized
INFO - 2020-02-09 05:18:23 --> URI Class Initialized
INFO - 2020-02-09 05:18:24 --> Router Class Initialized
INFO - 2020-02-09 05:18:24 --> Output Class Initialized
INFO - 2020-02-09 05:18:24 --> Security Class Initialized
DEBUG - 2020-02-09 05:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:18:24 --> Input Class Initialized
INFO - 2020-02-09 05:18:24 --> Language Class Initialized
INFO - 2020-02-09 05:18:24 --> Language Class Initialized
INFO - 2020-02-09 05:18:24 --> Config Class Initialized
INFO - 2020-02-09 05:18:24 --> Loader Class Initialized
INFO - 2020-02-09 05:18:24 --> Helper loaded: url_helper
INFO - 2020-02-09 05:18:24 --> Helper loaded: file_helper
INFO - 2020-02-09 05:18:24 --> Helper loaded: form_helper
INFO - 2020-02-09 05:18:24 --> Helper loaded: my_helper
INFO - 2020-02-09 05:18:24 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:18:24 --> Controller Class Initialized
INFO - 2020-02-09 05:18:25 --> Config Class Initialized
INFO - 2020-02-09 05:18:25 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:18:25 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:18:25 --> Utf8 Class Initialized
INFO - 2020-02-09 05:18:25 --> URI Class Initialized
INFO - 2020-02-09 05:18:25 --> Router Class Initialized
INFO - 2020-02-09 05:18:25 --> Output Class Initialized
INFO - 2020-02-09 05:18:25 --> Security Class Initialized
DEBUG - 2020-02-09 05:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:18:25 --> Input Class Initialized
INFO - 2020-02-09 05:18:25 --> Language Class Initialized
INFO - 2020-02-09 05:18:25 --> Language Class Initialized
INFO - 2020-02-09 05:18:25 --> Config Class Initialized
INFO - 2020-02-09 05:18:25 --> Loader Class Initialized
INFO - 2020-02-09 05:18:25 --> Helper loaded: url_helper
INFO - 2020-02-09 05:18:25 --> Helper loaded: file_helper
INFO - 2020-02-09 05:18:25 --> Helper loaded: form_helper
INFO - 2020-02-09 05:18:25 --> Helper loaded: my_helper
INFO - 2020-02-09 05:18:26 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:18:26 --> Controller Class Initialized
INFO - 2020-02-09 05:18:30 --> Config Class Initialized
INFO - 2020-02-09 05:18:31 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:18:31 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:18:31 --> Utf8 Class Initialized
INFO - 2020-02-09 05:18:31 --> URI Class Initialized
DEBUG - 2020-02-09 05:18:31 --> No URI present. Default controller set.
INFO - 2020-02-09 05:18:31 --> Router Class Initialized
INFO - 2020-02-09 05:18:31 --> Output Class Initialized
INFO - 2020-02-09 05:18:31 --> Security Class Initialized
DEBUG - 2020-02-09 05:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:18:31 --> Input Class Initialized
INFO - 2020-02-09 05:18:31 --> Language Class Initialized
INFO - 2020-02-09 05:18:31 --> Language Class Initialized
INFO - 2020-02-09 05:18:31 --> Config Class Initialized
INFO - 2020-02-09 05:18:31 --> Loader Class Initialized
INFO - 2020-02-09 05:18:31 --> Helper loaded: url_helper
INFO - 2020-02-09 05:18:31 --> Helper loaded: file_helper
INFO - 2020-02-09 05:18:31 --> Helper loaded: form_helper
INFO - 2020-02-09 05:18:31 --> Helper loaded: my_helper
INFO - 2020-02-09 05:18:31 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:18:31 --> Controller Class Initialized
DEBUG - 2020-02-09 05:18:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-09 05:18:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:18:31 --> Final output sent to browser
DEBUG - 2020-02-09 05:18:31 --> Total execution time: 0.4504
INFO - 2020-02-09 05:18:34 --> Config Class Initialized
INFO - 2020-02-09 05:18:34 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:18:34 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:18:34 --> Utf8 Class Initialized
INFO - 2020-02-09 05:18:34 --> URI Class Initialized
INFO - 2020-02-09 05:18:34 --> Router Class Initialized
INFO - 2020-02-09 05:18:34 --> Output Class Initialized
INFO - 2020-02-09 05:18:34 --> Security Class Initialized
DEBUG - 2020-02-09 05:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:18:34 --> Input Class Initialized
INFO - 2020-02-09 05:18:34 --> Language Class Initialized
INFO - 2020-02-09 05:18:34 --> Language Class Initialized
INFO - 2020-02-09 05:18:34 --> Config Class Initialized
INFO - 2020-02-09 05:18:34 --> Loader Class Initialized
INFO - 2020-02-09 05:18:34 --> Helper loaded: url_helper
INFO - 2020-02-09 05:18:34 --> Helper loaded: file_helper
INFO - 2020-02-09 05:18:34 --> Helper loaded: form_helper
INFO - 2020-02-09 05:18:34 --> Helper loaded: my_helper
INFO - 2020-02-09 05:18:34 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:18:34 --> Controller Class Initialized
DEBUG - 2020-02-09 05:18:34 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-09 05:18:34 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:18:34 --> Final output sent to browser
DEBUG - 2020-02-09 05:18:34 --> Total execution time: 0.4066
INFO - 2020-02-09 05:18:49 --> Config Class Initialized
INFO - 2020-02-09 05:18:49 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:18:49 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:18:49 --> Utf8 Class Initialized
INFO - 2020-02-09 05:18:49 --> URI Class Initialized
INFO - 2020-02-09 05:18:49 --> Router Class Initialized
INFO - 2020-02-09 05:18:49 --> Output Class Initialized
INFO - 2020-02-09 05:18:49 --> Security Class Initialized
DEBUG - 2020-02-09 05:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:18:49 --> Input Class Initialized
INFO - 2020-02-09 05:18:49 --> Language Class Initialized
INFO - 2020-02-09 05:18:49 --> Language Class Initialized
INFO - 2020-02-09 05:18:49 --> Config Class Initialized
INFO - 2020-02-09 05:18:49 --> Loader Class Initialized
INFO - 2020-02-09 05:18:49 --> Helper loaded: url_helper
INFO - 2020-02-09 05:18:49 --> Helper loaded: file_helper
INFO - 2020-02-09 05:18:49 --> Helper loaded: form_helper
INFO - 2020-02-09 05:18:49 --> Helper loaded: my_helper
INFO - 2020-02-09 05:18:49 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:18:49 --> Controller Class Initialized
DEBUG - 2020-02-09 05:18:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/list.php
DEBUG - 2020-02-09 05:18:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:18:49 --> Final output sent to browser
DEBUG - 2020-02-09 05:18:49 --> Total execution time: 0.4286
INFO - 2020-02-09 05:18:50 --> Config Class Initialized
INFO - 2020-02-09 05:18:50 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:18:50 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:18:50 --> Utf8 Class Initialized
INFO - 2020-02-09 05:18:50 --> URI Class Initialized
INFO - 2020-02-09 05:18:50 --> Router Class Initialized
INFO - 2020-02-09 05:18:50 --> Output Class Initialized
INFO - 2020-02-09 05:18:50 --> Security Class Initialized
DEBUG - 2020-02-09 05:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:18:50 --> Input Class Initialized
INFO - 2020-02-09 05:18:50 --> Language Class Initialized
INFO - 2020-02-09 05:18:50 --> Language Class Initialized
INFO - 2020-02-09 05:18:50 --> Config Class Initialized
INFO - 2020-02-09 05:18:50 --> Loader Class Initialized
INFO - 2020-02-09 05:18:50 --> Helper loaded: url_helper
INFO - 2020-02-09 05:18:50 --> Helper loaded: file_helper
INFO - 2020-02-09 05:18:50 --> Helper loaded: form_helper
INFO - 2020-02-09 05:18:50 --> Helper loaded: my_helper
INFO - 2020-02-09 05:18:50 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:18:50 --> Controller Class Initialized
INFO - 2020-02-09 05:45:55 --> Config Class Initialized
INFO - 2020-02-09 05:45:55 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:45:55 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:45:55 --> Utf8 Class Initialized
INFO - 2020-02-09 05:45:55 --> URI Class Initialized
DEBUG - 2020-02-09 05:45:56 --> No URI present. Default controller set.
INFO - 2020-02-09 05:45:56 --> Router Class Initialized
INFO - 2020-02-09 05:45:56 --> Output Class Initialized
INFO - 2020-02-09 05:45:56 --> Security Class Initialized
DEBUG - 2020-02-09 05:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:45:56 --> Input Class Initialized
INFO - 2020-02-09 05:45:56 --> Language Class Initialized
INFO - 2020-02-09 05:45:56 --> Language Class Initialized
INFO - 2020-02-09 05:45:56 --> Config Class Initialized
INFO - 2020-02-09 05:45:56 --> Loader Class Initialized
INFO - 2020-02-09 05:45:56 --> Helper loaded: url_helper
INFO - 2020-02-09 05:45:56 --> Helper loaded: file_helper
INFO - 2020-02-09 05:45:56 --> Helper loaded: form_helper
INFO - 2020-02-09 05:45:56 --> Helper loaded: my_helper
INFO - 2020-02-09 05:45:56 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:45:56 --> Controller Class Initialized
DEBUG - 2020-02-09 05:45:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-09 05:45:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:45:56 --> Final output sent to browser
DEBUG - 2020-02-09 05:45:57 --> Total execution time: 1.2478
INFO - 2020-02-09 05:46:47 --> Config Class Initialized
INFO - 2020-02-09 05:46:47 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:46:47 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:46:47 --> Utf8 Class Initialized
INFO - 2020-02-09 05:46:47 --> URI Class Initialized
INFO - 2020-02-09 05:46:47 --> Router Class Initialized
INFO - 2020-02-09 05:46:47 --> Output Class Initialized
INFO - 2020-02-09 05:46:47 --> Security Class Initialized
DEBUG - 2020-02-09 05:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:46:47 --> Input Class Initialized
INFO - 2020-02-09 05:46:48 --> Language Class Initialized
INFO - 2020-02-09 05:46:48 --> Language Class Initialized
INFO - 2020-02-09 05:46:48 --> Config Class Initialized
INFO - 2020-02-09 05:46:48 --> Loader Class Initialized
INFO - 2020-02-09 05:46:48 --> Helper loaded: url_helper
INFO - 2020-02-09 05:46:48 --> Helper loaded: file_helper
INFO - 2020-02-09 05:46:48 --> Helper loaded: form_helper
INFO - 2020-02-09 05:46:48 --> Helper loaded: my_helper
INFO - 2020-02-09 05:46:48 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:46:48 --> Controller Class Initialized
DEBUG - 2020-02-09 05:46:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-09 05:46:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:46:48 --> Final output sent to browser
DEBUG - 2020-02-09 05:46:48 --> Total execution time: 0.4098
INFO - 2020-02-09 05:46:48 --> Config Class Initialized
INFO - 2020-02-09 05:46:48 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:46:48 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:46:48 --> Utf8 Class Initialized
INFO - 2020-02-09 05:46:48 --> URI Class Initialized
INFO - 2020-02-09 05:46:48 --> Router Class Initialized
INFO - 2020-02-09 05:46:48 --> Output Class Initialized
INFO - 2020-02-09 05:46:48 --> Security Class Initialized
DEBUG - 2020-02-09 05:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:46:48 --> Input Class Initialized
INFO - 2020-02-09 05:46:48 --> Language Class Initialized
INFO - 2020-02-09 05:46:48 --> Language Class Initialized
INFO - 2020-02-09 05:46:48 --> Config Class Initialized
INFO - 2020-02-09 05:46:48 --> Loader Class Initialized
INFO - 2020-02-09 05:46:48 --> Helper loaded: url_helper
INFO - 2020-02-09 05:46:48 --> Helper loaded: file_helper
INFO - 2020-02-09 05:46:48 --> Helper loaded: form_helper
INFO - 2020-02-09 05:46:48 --> Helper loaded: my_helper
INFO - 2020-02-09 05:46:48 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:46:48 --> Controller Class Initialized
INFO - 2020-02-09 05:47:20 --> Config Class Initialized
INFO - 2020-02-09 05:47:20 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:47:20 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:47:20 --> Utf8 Class Initialized
INFO - 2020-02-09 05:47:20 --> URI Class Initialized
INFO - 2020-02-09 05:47:20 --> Router Class Initialized
INFO - 2020-02-09 05:47:20 --> Output Class Initialized
INFO - 2020-02-09 05:47:20 --> Security Class Initialized
DEBUG - 2020-02-09 05:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:47:20 --> Input Class Initialized
INFO - 2020-02-09 05:47:20 --> Language Class Initialized
INFO - 2020-02-09 05:47:20 --> Language Class Initialized
INFO - 2020-02-09 05:47:20 --> Config Class Initialized
INFO - 2020-02-09 05:47:20 --> Loader Class Initialized
INFO - 2020-02-09 05:47:20 --> Helper loaded: url_helper
INFO - 2020-02-09 05:47:20 --> Helper loaded: file_helper
INFO - 2020-02-09 05:47:20 --> Helper loaded: form_helper
INFO - 2020-02-09 05:47:20 --> Helper loaded: my_helper
INFO - 2020-02-09 05:47:20 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:47:20 --> Controller Class Initialized
DEBUG - 2020-02-09 05:47:20 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-09 05:47:20 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:47:20 --> Final output sent to browser
DEBUG - 2020-02-09 05:47:20 --> Total execution time: 0.4085
INFO - 2020-02-09 05:47:21 --> Config Class Initialized
INFO - 2020-02-09 05:47:21 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:47:21 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:47:21 --> Utf8 Class Initialized
INFO - 2020-02-09 05:47:21 --> URI Class Initialized
INFO - 2020-02-09 05:47:21 --> Router Class Initialized
INFO - 2020-02-09 05:47:21 --> Output Class Initialized
INFO - 2020-02-09 05:47:21 --> Security Class Initialized
DEBUG - 2020-02-09 05:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:47:21 --> Input Class Initialized
INFO - 2020-02-09 05:47:21 --> Language Class Initialized
INFO - 2020-02-09 05:47:21 --> Language Class Initialized
INFO - 2020-02-09 05:47:21 --> Config Class Initialized
INFO - 2020-02-09 05:47:21 --> Loader Class Initialized
INFO - 2020-02-09 05:47:21 --> Helper loaded: url_helper
INFO - 2020-02-09 05:47:21 --> Helper loaded: file_helper
INFO - 2020-02-09 05:47:21 --> Helper loaded: form_helper
INFO - 2020-02-09 05:47:21 --> Helper loaded: my_helper
INFO - 2020-02-09 05:47:21 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:47:21 --> Controller Class Initialized
INFO - 2020-02-09 05:47:23 --> Config Class Initialized
INFO - 2020-02-09 05:47:23 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:47:23 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:47:23 --> Utf8 Class Initialized
INFO - 2020-02-09 05:47:23 --> URI Class Initialized
INFO - 2020-02-09 05:47:23 --> Router Class Initialized
INFO - 2020-02-09 05:47:23 --> Output Class Initialized
INFO - 2020-02-09 05:47:23 --> Security Class Initialized
DEBUG - 2020-02-09 05:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:47:23 --> Input Class Initialized
INFO - 2020-02-09 05:47:23 --> Language Class Initialized
INFO - 2020-02-09 05:47:23 --> Language Class Initialized
INFO - 2020-02-09 05:47:23 --> Config Class Initialized
INFO - 2020-02-09 05:47:23 --> Loader Class Initialized
INFO - 2020-02-09 05:47:23 --> Helper loaded: url_helper
INFO - 2020-02-09 05:47:23 --> Helper loaded: file_helper
INFO - 2020-02-09 05:47:23 --> Helper loaded: form_helper
INFO - 2020-02-09 05:47:23 --> Helper loaded: my_helper
INFO - 2020-02-09 05:47:23 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:47:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:47:23 --> Controller Class Initialized
DEBUG - 2020-02-09 05:47:23 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_ekstra/views/list.php
DEBUG - 2020-02-09 05:47:23 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:47:23 --> Final output sent to browser
DEBUG - 2020-02-09 05:47:23 --> Total execution time: 0.4654
INFO - 2020-02-09 05:47:23 --> Config Class Initialized
INFO - 2020-02-09 05:47:23 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:47:23 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:47:23 --> Utf8 Class Initialized
INFO - 2020-02-09 05:47:23 --> URI Class Initialized
INFO - 2020-02-09 05:47:23 --> Router Class Initialized
INFO - 2020-02-09 05:47:23 --> Output Class Initialized
INFO - 2020-02-09 05:47:23 --> Security Class Initialized
DEBUG - 2020-02-09 05:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:47:23 --> Input Class Initialized
INFO - 2020-02-09 05:47:23 --> Language Class Initialized
INFO - 2020-02-09 05:47:23 --> Language Class Initialized
INFO - 2020-02-09 05:47:23 --> Config Class Initialized
INFO - 2020-02-09 05:47:23 --> Loader Class Initialized
INFO - 2020-02-09 05:47:23 --> Helper loaded: url_helper
INFO - 2020-02-09 05:47:24 --> Helper loaded: file_helper
INFO - 2020-02-09 05:47:24 --> Helper loaded: form_helper
INFO - 2020-02-09 05:47:24 --> Helper loaded: my_helper
INFO - 2020-02-09 05:47:24 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:47:24 --> Controller Class Initialized
INFO - 2020-02-09 05:47:24 --> Config Class Initialized
INFO - 2020-02-09 05:47:24 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:47:24 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:47:24 --> Utf8 Class Initialized
INFO - 2020-02-09 05:47:24 --> URI Class Initialized
INFO - 2020-02-09 05:47:24 --> Router Class Initialized
INFO - 2020-02-09 05:47:24 --> Output Class Initialized
INFO - 2020-02-09 05:47:24 --> Security Class Initialized
DEBUG - 2020-02-09 05:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:47:24 --> Input Class Initialized
INFO - 2020-02-09 05:47:24 --> Language Class Initialized
INFO - 2020-02-09 05:47:24 --> Language Class Initialized
INFO - 2020-02-09 05:47:24 --> Config Class Initialized
INFO - 2020-02-09 05:47:24 --> Loader Class Initialized
INFO - 2020-02-09 05:47:24 --> Helper loaded: url_helper
INFO - 2020-02-09 05:47:24 --> Helper loaded: file_helper
INFO - 2020-02-09 05:47:24 --> Helper loaded: form_helper
INFO - 2020-02-09 05:47:24 --> Helper loaded: my_helper
INFO - 2020-02-09 05:47:24 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:47:24 --> Controller Class Initialized
DEBUG - 2020-02-09 05:47:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-09 05:47:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:47:24 --> Final output sent to browser
DEBUG - 2020-02-09 05:47:24 --> Total execution time: 0.3822
INFO - 2020-02-09 05:47:25 --> Config Class Initialized
INFO - 2020-02-09 05:47:25 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:47:25 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:47:25 --> Utf8 Class Initialized
INFO - 2020-02-09 05:47:25 --> URI Class Initialized
INFO - 2020-02-09 05:47:25 --> Router Class Initialized
INFO - 2020-02-09 05:47:25 --> Output Class Initialized
INFO - 2020-02-09 05:47:25 --> Security Class Initialized
DEBUG - 2020-02-09 05:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:47:25 --> Input Class Initialized
INFO - 2020-02-09 05:47:25 --> Language Class Initialized
INFO - 2020-02-09 05:47:25 --> Language Class Initialized
INFO - 2020-02-09 05:47:25 --> Config Class Initialized
INFO - 2020-02-09 05:47:25 --> Loader Class Initialized
INFO - 2020-02-09 05:47:25 --> Helper loaded: url_helper
INFO - 2020-02-09 05:47:25 --> Helper loaded: file_helper
INFO - 2020-02-09 05:47:25 --> Helper loaded: form_helper
INFO - 2020-02-09 05:47:25 --> Helper loaded: my_helper
INFO - 2020-02-09 05:47:25 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:47:25 --> Controller Class Initialized
INFO - 2020-02-09 05:47:26 --> Config Class Initialized
INFO - 2020-02-09 05:47:26 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:47:26 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:47:26 --> Utf8 Class Initialized
INFO - 2020-02-09 05:47:26 --> URI Class Initialized
INFO - 2020-02-09 05:47:26 --> Router Class Initialized
INFO - 2020-02-09 05:47:26 --> Output Class Initialized
INFO - 2020-02-09 05:47:26 --> Security Class Initialized
DEBUG - 2020-02-09 05:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:47:26 --> Input Class Initialized
INFO - 2020-02-09 05:47:26 --> Language Class Initialized
INFO - 2020-02-09 05:47:26 --> Language Class Initialized
INFO - 2020-02-09 05:47:26 --> Config Class Initialized
INFO - 2020-02-09 05:47:26 --> Loader Class Initialized
INFO - 2020-02-09 05:47:26 --> Helper loaded: url_helper
INFO - 2020-02-09 05:47:26 --> Helper loaded: file_helper
INFO - 2020-02-09 05:47:26 --> Helper loaded: form_helper
INFO - 2020-02-09 05:47:26 --> Helper loaded: my_helper
INFO - 2020-02-09 05:47:26 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:47:26 --> Controller Class Initialized
DEBUG - 2020-02-09 05:47:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-09 05:47:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:47:26 --> Final output sent to browser
DEBUG - 2020-02-09 05:47:26 --> Total execution time: 0.4903
INFO - 2020-02-09 05:47:27 --> Config Class Initialized
INFO - 2020-02-09 05:47:27 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:47:27 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:47:27 --> Utf8 Class Initialized
INFO - 2020-02-09 05:47:27 --> URI Class Initialized
INFO - 2020-02-09 05:47:27 --> Router Class Initialized
INFO - 2020-02-09 05:47:27 --> Output Class Initialized
INFO - 2020-02-09 05:47:27 --> Security Class Initialized
DEBUG - 2020-02-09 05:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:47:27 --> Input Class Initialized
INFO - 2020-02-09 05:47:27 --> Language Class Initialized
INFO - 2020-02-09 05:47:27 --> Language Class Initialized
INFO - 2020-02-09 05:47:27 --> Config Class Initialized
INFO - 2020-02-09 05:47:27 --> Loader Class Initialized
INFO - 2020-02-09 05:47:27 --> Helper loaded: url_helper
INFO - 2020-02-09 05:47:27 --> Helper loaded: file_helper
INFO - 2020-02-09 05:47:27 --> Helper loaded: form_helper
INFO - 2020-02-09 05:47:27 --> Helper loaded: my_helper
INFO - 2020-02-09 05:47:27 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:47:27 --> Controller Class Initialized
DEBUG - 2020-02-09 05:47:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_ubah_password.php
DEBUG - 2020-02-09 05:47:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:47:27 --> Final output sent to browser
DEBUG - 2020-02-09 05:47:27 --> Total execution time: 0.4140
INFO - 2020-02-09 05:47:29 --> Config Class Initialized
INFO - 2020-02-09 05:47:29 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:47:29 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:47:29 --> Utf8 Class Initialized
INFO - 2020-02-09 05:47:29 --> URI Class Initialized
DEBUG - 2020-02-09 05:47:29 --> No URI present. Default controller set.
INFO - 2020-02-09 05:47:29 --> Router Class Initialized
INFO - 2020-02-09 05:47:29 --> Output Class Initialized
INFO - 2020-02-09 05:47:29 --> Security Class Initialized
DEBUG - 2020-02-09 05:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:47:29 --> Input Class Initialized
INFO - 2020-02-09 05:47:29 --> Language Class Initialized
INFO - 2020-02-09 05:47:29 --> Language Class Initialized
INFO - 2020-02-09 05:47:29 --> Config Class Initialized
INFO - 2020-02-09 05:47:29 --> Loader Class Initialized
INFO - 2020-02-09 05:47:29 --> Helper loaded: url_helper
INFO - 2020-02-09 05:47:29 --> Helper loaded: file_helper
INFO - 2020-02-09 05:47:29 --> Helper loaded: form_helper
INFO - 2020-02-09 05:47:29 --> Helper loaded: my_helper
INFO - 2020-02-09 05:47:29 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:47:29 --> Controller Class Initialized
DEBUG - 2020-02-09 05:47:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-09 05:47:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:47:29 --> Final output sent to browser
DEBUG - 2020-02-09 05:47:29 --> Total execution time: 0.3979
INFO - 2020-02-09 05:47:31 --> Config Class Initialized
INFO - 2020-02-09 05:47:31 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:47:31 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:47:31 --> Utf8 Class Initialized
INFO - 2020-02-09 05:47:31 --> URI Class Initialized
INFO - 2020-02-09 05:47:31 --> Router Class Initialized
INFO - 2020-02-09 05:47:31 --> Output Class Initialized
INFO - 2020-02-09 05:47:31 --> Security Class Initialized
DEBUG - 2020-02-09 05:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:47:31 --> Input Class Initialized
INFO - 2020-02-09 05:47:31 --> Language Class Initialized
INFO - 2020-02-09 05:47:31 --> Language Class Initialized
INFO - 2020-02-09 05:47:31 --> Config Class Initialized
INFO - 2020-02-09 05:47:31 --> Loader Class Initialized
INFO - 2020-02-09 05:47:31 --> Helper loaded: url_helper
INFO - 2020-02-09 05:47:31 --> Helper loaded: file_helper
INFO - 2020-02-09 05:47:31 --> Helper loaded: form_helper
INFO - 2020-02-09 05:47:31 --> Helper loaded: my_helper
INFO - 2020-02-09 05:47:31 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:47:31 --> Controller Class Initialized
INFO - 2020-02-09 05:47:31 --> Helper loaded: cookie_helper
INFO - 2020-02-09 05:47:31 --> Config Class Initialized
INFO - 2020-02-09 05:47:32 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:47:32 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:47:32 --> Utf8 Class Initialized
INFO - 2020-02-09 05:47:32 --> URI Class Initialized
INFO - 2020-02-09 05:47:32 --> Router Class Initialized
INFO - 2020-02-09 05:47:32 --> Output Class Initialized
INFO - 2020-02-09 05:47:32 --> Security Class Initialized
DEBUG - 2020-02-09 05:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:47:32 --> Input Class Initialized
INFO - 2020-02-09 05:47:32 --> Language Class Initialized
INFO - 2020-02-09 05:47:32 --> Language Class Initialized
INFO - 2020-02-09 05:47:32 --> Config Class Initialized
INFO - 2020-02-09 05:47:32 --> Loader Class Initialized
INFO - 2020-02-09 05:47:32 --> Helper loaded: url_helper
INFO - 2020-02-09 05:47:32 --> Helper loaded: file_helper
INFO - 2020-02-09 05:47:32 --> Helper loaded: form_helper
INFO - 2020-02-09 05:47:32 --> Helper loaded: my_helper
INFO - 2020-02-09 05:47:32 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:47:32 --> Controller Class Initialized
INFO - 2020-02-09 05:47:32 --> Config Class Initialized
INFO - 2020-02-09 05:47:32 --> Hooks Class Initialized
DEBUG - 2020-02-09 05:47:32 --> UTF-8 Support Enabled
INFO - 2020-02-09 05:47:32 --> Utf8 Class Initialized
INFO - 2020-02-09 05:47:32 --> URI Class Initialized
INFO - 2020-02-09 05:47:32 --> Router Class Initialized
INFO - 2020-02-09 05:47:32 --> Output Class Initialized
INFO - 2020-02-09 05:47:32 --> Security Class Initialized
DEBUG - 2020-02-09 05:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 05:47:32 --> Input Class Initialized
INFO - 2020-02-09 05:47:32 --> Language Class Initialized
INFO - 2020-02-09 05:47:32 --> Language Class Initialized
INFO - 2020-02-09 05:47:32 --> Config Class Initialized
INFO - 2020-02-09 05:47:32 --> Loader Class Initialized
INFO - 2020-02-09 05:47:32 --> Helper loaded: url_helper
INFO - 2020-02-09 05:47:32 --> Helper loaded: file_helper
INFO - 2020-02-09 05:47:32 --> Helper loaded: form_helper
INFO - 2020-02-09 05:47:32 --> Helper loaded: my_helper
INFO - 2020-02-09 05:47:32 --> Database Driver Class Initialized
DEBUG - 2020-02-09 05:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 05:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 05:47:32 --> Controller Class Initialized
DEBUG - 2020-02-09 05:47:32 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 05:47:32 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 05:47:32 --> Final output sent to browser
DEBUG - 2020-02-09 05:47:32 --> Total execution time: 0.4339
INFO - 2020-02-09 06:07:48 --> Config Class Initialized
INFO - 2020-02-09 06:07:48 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:07:48 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:07:48 --> Utf8 Class Initialized
INFO - 2020-02-09 06:07:48 --> URI Class Initialized
INFO - 2020-02-09 06:07:48 --> Router Class Initialized
INFO - 2020-02-09 06:07:48 --> Output Class Initialized
INFO - 2020-02-09 06:07:48 --> Security Class Initialized
DEBUG - 2020-02-09 06:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:07:48 --> Input Class Initialized
INFO - 2020-02-09 06:07:48 --> Language Class Initialized
INFO - 2020-02-09 06:07:49 --> Language Class Initialized
INFO - 2020-02-09 06:07:49 --> Config Class Initialized
INFO - 2020-02-09 06:07:49 --> Loader Class Initialized
INFO - 2020-02-09 06:07:49 --> Helper loaded: url_helper
INFO - 2020-02-09 06:07:49 --> Helper loaded: file_helper
INFO - 2020-02-09 06:07:49 --> Helper loaded: form_helper
INFO - 2020-02-09 06:07:49 --> Helper loaded: my_helper
INFO - 2020-02-09 06:07:49 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:07:49 --> Controller Class Initialized
INFO - 2020-02-09 06:07:49 --> Helper loaded: cookie_helper
INFO - 2020-02-09 06:07:49 --> Final output sent to browser
DEBUG - 2020-02-09 06:07:49 --> Total execution time: 1.1233
INFO - 2020-02-09 06:07:49 --> Config Class Initialized
INFO - 2020-02-09 06:07:49 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:07:49 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:07:49 --> Utf8 Class Initialized
INFO - 2020-02-09 06:07:49 --> URI Class Initialized
INFO - 2020-02-09 06:07:49 --> Router Class Initialized
INFO - 2020-02-09 06:07:50 --> Output Class Initialized
INFO - 2020-02-09 06:07:50 --> Security Class Initialized
DEBUG - 2020-02-09 06:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:07:50 --> Input Class Initialized
INFO - 2020-02-09 06:07:50 --> Language Class Initialized
INFO - 2020-02-09 06:07:50 --> Language Class Initialized
INFO - 2020-02-09 06:07:50 --> Config Class Initialized
INFO - 2020-02-09 06:07:50 --> Loader Class Initialized
INFO - 2020-02-09 06:07:50 --> Helper loaded: url_helper
INFO - 2020-02-09 06:07:50 --> Helper loaded: file_helper
INFO - 2020-02-09 06:07:50 --> Helper loaded: form_helper
INFO - 2020-02-09 06:07:50 --> Helper loaded: my_helper
INFO - 2020-02-09 06:07:50 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:07:50 --> Controller Class Initialized
DEBUG - 2020-02-09 06:07:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-09 06:07:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:07:50 --> Final output sent to browser
DEBUG - 2020-02-09 06:07:50 --> Total execution time: 0.9943
INFO - 2020-02-09 06:09:03 --> Config Class Initialized
INFO - 2020-02-09 06:09:03 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:09:03 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:09:03 --> Utf8 Class Initialized
INFO - 2020-02-09 06:09:03 --> URI Class Initialized
INFO - 2020-02-09 06:09:03 --> Router Class Initialized
INFO - 2020-02-09 06:09:04 --> Output Class Initialized
INFO - 2020-02-09 06:09:04 --> Security Class Initialized
DEBUG - 2020-02-09 06:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:09:04 --> Input Class Initialized
INFO - 2020-02-09 06:09:04 --> Language Class Initialized
INFO - 2020-02-09 06:09:04 --> Language Class Initialized
INFO - 2020-02-09 06:09:04 --> Config Class Initialized
INFO - 2020-02-09 06:09:04 --> Loader Class Initialized
INFO - 2020-02-09 06:09:04 --> Helper loaded: url_helper
INFO - 2020-02-09 06:09:04 --> Helper loaded: file_helper
INFO - 2020-02-09 06:09:04 --> Helper loaded: form_helper
INFO - 2020-02-09 06:09:04 --> Helper loaded: my_helper
INFO - 2020-02-09 06:09:04 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:09:04 --> Controller Class Initialized
DEBUG - 2020-02-09 06:09:04 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_guru/views/list.php
DEBUG - 2020-02-09 06:09:04 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:09:04 --> Final output sent to browser
DEBUG - 2020-02-09 06:09:04 --> Total execution time: 0.7298
INFO - 2020-02-09 06:09:05 --> Config Class Initialized
INFO - 2020-02-09 06:09:05 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:09:05 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:09:05 --> Utf8 Class Initialized
INFO - 2020-02-09 06:09:05 --> URI Class Initialized
INFO - 2020-02-09 06:09:05 --> Router Class Initialized
INFO - 2020-02-09 06:09:05 --> Output Class Initialized
INFO - 2020-02-09 06:09:05 --> Security Class Initialized
DEBUG - 2020-02-09 06:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:09:05 --> Input Class Initialized
INFO - 2020-02-09 06:09:05 --> Language Class Initialized
INFO - 2020-02-09 06:09:05 --> Language Class Initialized
INFO - 2020-02-09 06:09:05 --> Config Class Initialized
INFO - 2020-02-09 06:09:05 --> Loader Class Initialized
INFO - 2020-02-09 06:09:05 --> Helper loaded: url_helper
INFO - 2020-02-09 06:09:05 --> Helper loaded: file_helper
INFO - 2020-02-09 06:09:05 --> Helper loaded: form_helper
INFO - 2020-02-09 06:09:05 --> Helper loaded: my_helper
INFO - 2020-02-09 06:09:05 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:09:05 --> Controller Class Initialized
INFO - 2020-02-09 06:09:14 --> Config Class Initialized
INFO - 2020-02-09 06:09:14 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:09:14 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:09:14 --> Utf8 Class Initialized
INFO - 2020-02-09 06:09:14 --> URI Class Initialized
INFO - 2020-02-09 06:09:14 --> Router Class Initialized
INFO - 2020-02-09 06:09:15 --> Output Class Initialized
INFO - 2020-02-09 06:09:15 --> Security Class Initialized
DEBUG - 2020-02-09 06:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:09:15 --> Input Class Initialized
INFO - 2020-02-09 06:09:15 --> Language Class Initialized
INFO - 2020-02-09 06:09:15 --> Language Class Initialized
INFO - 2020-02-09 06:09:15 --> Config Class Initialized
INFO - 2020-02-09 06:09:15 --> Loader Class Initialized
INFO - 2020-02-09 06:09:15 --> Helper loaded: url_helper
INFO - 2020-02-09 06:09:15 --> Helper loaded: file_helper
INFO - 2020-02-09 06:09:15 --> Helper loaded: form_helper
INFO - 2020-02-09 06:09:15 --> Helper loaded: my_helper
INFO - 2020-02-09 06:09:15 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:09:15 --> Controller Class Initialized
INFO - 2020-02-09 06:09:15 --> Final output sent to browser
DEBUG - 2020-02-09 06:09:15 --> Total execution time: 0.6982
INFO - 2020-02-09 06:09:33 --> Config Class Initialized
INFO - 2020-02-09 06:09:33 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:09:34 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:09:34 --> Utf8 Class Initialized
INFO - 2020-02-09 06:09:34 --> URI Class Initialized
INFO - 2020-02-09 06:09:34 --> Router Class Initialized
INFO - 2020-02-09 06:09:34 --> Output Class Initialized
INFO - 2020-02-09 06:09:34 --> Security Class Initialized
DEBUG - 2020-02-09 06:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:09:34 --> Input Class Initialized
INFO - 2020-02-09 06:09:34 --> Language Class Initialized
INFO - 2020-02-09 06:09:34 --> Language Class Initialized
INFO - 2020-02-09 06:09:34 --> Config Class Initialized
INFO - 2020-02-09 06:09:34 --> Loader Class Initialized
INFO - 2020-02-09 06:09:34 --> Helper loaded: url_helper
INFO - 2020-02-09 06:09:34 --> Helper loaded: file_helper
INFO - 2020-02-09 06:09:34 --> Helper loaded: form_helper
INFO - 2020-02-09 06:09:34 --> Helper loaded: my_helper
INFO - 2020-02-09 06:09:34 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:09:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:09:34 --> Controller Class Initialized
INFO - 2020-02-09 06:09:34 --> Final output sent to browser
DEBUG - 2020-02-09 06:09:34 --> Total execution time: 0.4699
INFO - 2020-02-09 06:09:34 --> Config Class Initialized
INFO - 2020-02-09 06:09:34 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:09:34 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:09:34 --> Utf8 Class Initialized
INFO - 2020-02-09 06:09:34 --> URI Class Initialized
INFO - 2020-02-09 06:09:34 --> Router Class Initialized
INFO - 2020-02-09 06:09:34 --> Output Class Initialized
INFO - 2020-02-09 06:09:34 --> Security Class Initialized
DEBUG - 2020-02-09 06:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:09:34 --> Input Class Initialized
INFO - 2020-02-09 06:09:34 --> Language Class Initialized
INFO - 2020-02-09 06:09:34 --> Language Class Initialized
INFO - 2020-02-09 06:09:34 --> Config Class Initialized
INFO - 2020-02-09 06:09:34 --> Loader Class Initialized
INFO - 2020-02-09 06:09:34 --> Helper loaded: url_helper
INFO - 2020-02-09 06:09:35 --> Helper loaded: file_helper
INFO - 2020-02-09 06:09:35 --> Helper loaded: form_helper
INFO - 2020-02-09 06:09:35 --> Helper loaded: my_helper
INFO - 2020-02-09 06:09:35 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:09:35 --> Controller Class Initialized
INFO - 2020-02-09 06:10:02 --> Config Class Initialized
INFO - 2020-02-09 06:10:02 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:10:02 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:10:02 --> Utf8 Class Initialized
INFO - 2020-02-09 06:10:02 --> URI Class Initialized
INFO - 2020-02-09 06:10:02 --> Router Class Initialized
INFO - 2020-02-09 06:10:02 --> Output Class Initialized
INFO - 2020-02-09 06:10:02 --> Security Class Initialized
DEBUG - 2020-02-09 06:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:10:02 --> Input Class Initialized
INFO - 2020-02-09 06:10:02 --> Language Class Initialized
INFO - 2020-02-09 06:10:02 --> Language Class Initialized
INFO - 2020-02-09 06:10:02 --> Config Class Initialized
INFO - 2020-02-09 06:10:02 --> Loader Class Initialized
INFO - 2020-02-09 06:10:02 --> Helper loaded: url_helper
INFO - 2020-02-09 06:10:02 --> Helper loaded: file_helper
INFO - 2020-02-09 06:10:02 --> Helper loaded: form_helper
INFO - 2020-02-09 06:10:02 --> Helper loaded: my_helper
INFO - 2020-02-09 06:10:02 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:10:02 --> Controller Class Initialized
INFO - 2020-02-09 06:10:02 --> Final output sent to browser
DEBUG - 2020-02-09 06:10:02 --> Total execution time: 0.4579
INFO - 2020-02-09 06:10:03 --> Config Class Initialized
INFO - 2020-02-09 06:10:03 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:10:03 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:10:03 --> Utf8 Class Initialized
INFO - 2020-02-09 06:10:03 --> URI Class Initialized
INFO - 2020-02-09 06:10:03 --> Router Class Initialized
INFO - 2020-02-09 06:10:03 --> Output Class Initialized
INFO - 2020-02-09 06:10:03 --> Security Class Initialized
DEBUG - 2020-02-09 06:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:10:03 --> Input Class Initialized
INFO - 2020-02-09 06:10:03 --> Language Class Initialized
INFO - 2020-02-09 06:10:03 --> Language Class Initialized
INFO - 2020-02-09 06:10:03 --> Config Class Initialized
INFO - 2020-02-09 06:10:03 --> Loader Class Initialized
INFO - 2020-02-09 06:10:03 --> Helper loaded: url_helper
INFO - 2020-02-09 06:10:03 --> Helper loaded: file_helper
INFO - 2020-02-09 06:10:03 --> Helper loaded: form_helper
INFO - 2020-02-09 06:10:03 --> Helper loaded: my_helper
INFO - 2020-02-09 06:10:03 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:10:03 --> Controller Class Initialized
INFO - 2020-02-09 06:10:26 --> Config Class Initialized
INFO - 2020-02-09 06:10:26 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:10:26 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:10:26 --> Utf8 Class Initialized
INFO - 2020-02-09 06:10:26 --> URI Class Initialized
INFO - 2020-02-09 06:10:26 --> Router Class Initialized
INFO - 2020-02-09 06:10:26 --> Output Class Initialized
INFO - 2020-02-09 06:10:26 --> Security Class Initialized
DEBUG - 2020-02-09 06:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:10:26 --> Input Class Initialized
INFO - 2020-02-09 06:10:26 --> Language Class Initialized
INFO - 2020-02-09 06:10:26 --> Language Class Initialized
INFO - 2020-02-09 06:10:26 --> Config Class Initialized
INFO - 2020-02-09 06:10:26 --> Loader Class Initialized
INFO - 2020-02-09 06:10:26 --> Helper loaded: url_helper
INFO - 2020-02-09 06:10:27 --> Helper loaded: file_helper
INFO - 2020-02-09 06:10:27 --> Helper loaded: form_helper
INFO - 2020-02-09 06:10:27 --> Helper loaded: my_helper
INFO - 2020-02-09 06:10:27 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:10:27 --> Controller Class Initialized
INFO - 2020-02-09 06:10:27 --> Final output sent to browser
DEBUG - 2020-02-09 06:10:27 --> Total execution time: 0.5517
INFO - 2020-02-09 06:10:33 --> Config Class Initialized
INFO - 2020-02-09 06:10:34 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:10:34 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:10:34 --> Utf8 Class Initialized
INFO - 2020-02-09 06:10:34 --> URI Class Initialized
INFO - 2020-02-09 06:10:34 --> Router Class Initialized
INFO - 2020-02-09 06:10:34 --> Output Class Initialized
INFO - 2020-02-09 06:10:34 --> Security Class Initialized
DEBUG - 2020-02-09 06:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:10:34 --> Input Class Initialized
INFO - 2020-02-09 06:10:34 --> Language Class Initialized
INFO - 2020-02-09 06:10:34 --> Language Class Initialized
INFO - 2020-02-09 06:10:34 --> Config Class Initialized
INFO - 2020-02-09 06:10:34 --> Loader Class Initialized
INFO - 2020-02-09 06:10:34 --> Helper loaded: url_helper
INFO - 2020-02-09 06:10:34 --> Helper loaded: file_helper
INFO - 2020-02-09 06:10:34 --> Helper loaded: form_helper
INFO - 2020-02-09 06:10:34 --> Helper loaded: my_helper
INFO - 2020-02-09 06:10:34 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:10:34 --> Controller Class Initialized
DEBUG - 2020-02-09 06:10:34 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/list.php
DEBUG - 2020-02-09 06:10:34 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:10:34 --> Final output sent to browser
DEBUG - 2020-02-09 06:10:34 --> Total execution time: 0.7898
INFO - 2020-02-09 06:10:35 --> Config Class Initialized
INFO - 2020-02-09 06:10:35 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:10:35 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:10:35 --> Utf8 Class Initialized
INFO - 2020-02-09 06:10:35 --> URI Class Initialized
INFO - 2020-02-09 06:10:35 --> Router Class Initialized
INFO - 2020-02-09 06:10:35 --> Output Class Initialized
INFO - 2020-02-09 06:10:35 --> Security Class Initialized
DEBUG - 2020-02-09 06:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:10:35 --> Input Class Initialized
INFO - 2020-02-09 06:10:35 --> Language Class Initialized
INFO - 2020-02-09 06:10:36 --> Language Class Initialized
INFO - 2020-02-09 06:10:36 --> Config Class Initialized
INFO - 2020-02-09 06:10:36 --> Loader Class Initialized
INFO - 2020-02-09 06:10:36 --> Helper loaded: url_helper
INFO - 2020-02-09 06:10:36 --> Helper loaded: file_helper
INFO - 2020-02-09 06:10:36 --> Helper loaded: form_helper
INFO - 2020-02-09 06:10:36 --> Helper loaded: my_helper
INFO - 2020-02-09 06:10:36 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:10:36 --> Controller Class Initialized
INFO - 2020-02-09 06:11:00 --> Config Class Initialized
INFO - 2020-02-09 06:11:00 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:11:00 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:11:00 --> Utf8 Class Initialized
INFO - 2020-02-09 06:11:00 --> URI Class Initialized
INFO - 2020-02-09 06:11:00 --> Router Class Initialized
INFO - 2020-02-09 06:11:00 --> Output Class Initialized
INFO - 2020-02-09 06:11:00 --> Security Class Initialized
DEBUG - 2020-02-09 06:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:11:00 --> Input Class Initialized
INFO - 2020-02-09 06:11:00 --> Language Class Initialized
INFO - 2020-02-09 06:11:00 --> Language Class Initialized
INFO - 2020-02-09 06:11:00 --> Config Class Initialized
INFO - 2020-02-09 06:11:00 --> Loader Class Initialized
INFO - 2020-02-09 06:11:00 --> Helper loaded: url_helper
INFO - 2020-02-09 06:11:00 --> Helper loaded: file_helper
INFO - 2020-02-09 06:11:00 --> Helper loaded: form_helper
INFO - 2020-02-09 06:11:00 --> Helper loaded: my_helper
INFO - 2020-02-09 06:11:00 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:11:00 --> Controller Class Initialized
ERROR - 2020-02-09 06:11:01 --> Severity: Notice --> Undefined variable: status_form E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 223
DEBUG - 2020-02-09 06:11:01 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/form.php
DEBUG - 2020-02-09 06:11:01 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:11:01 --> Final output sent to browser
DEBUG - 2020-02-09 06:11:01 --> Total execution time: 0.8228
INFO - 2020-02-09 06:11:09 --> Config Class Initialized
INFO - 2020-02-09 06:11:10 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:11:10 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:11:10 --> Utf8 Class Initialized
INFO - 2020-02-09 06:11:10 --> URI Class Initialized
INFO - 2020-02-09 06:11:10 --> Router Class Initialized
INFO - 2020-02-09 06:11:10 --> Output Class Initialized
INFO - 2020-02-09 06:11:10 --> Security Class Initialized
DEBUG - 2020-02-09 06:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:11:10 --> Input Class Initialized
INFO - 2020-02-09 06:11:10 --> Language Class Initialized
INFO - 2020-02-09 06:11:10 --> Language Class Initialized
INFO - 2020-02-09 06:11:10 --> Config Class Initialized
INFO - 2020-02-09 06:11:10 --> Loader Class Initialized
INFO - 2020-02-09 06:11:10 --> Helper loaded: url_helper
INFO - 2020-02-09 06:11:10 --> Helper loaded: file_helper
INFO - 2020-02-09 06:11:10 --> Helper loaded: form_helper
INFO - 2020-02-09 06:11:10 --> Helper loaded: my_helper
INFO - 2020-02-09 06:11:10 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:11:10 --> Controller Class Initialized
DEBUG - 2020-02-09 06:11:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/list.php
DEBUG - 2020-02-09 06:11:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:11:10 --> Final output sent to browser
DEBUG - 2020-02-09 06:11:10 --> Total execution time: 0.8285
INFO - 2020-02-09 06:11:11 --> Config Class Initialized
INFO - 2020-02-09 06:11:11 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:11:11 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:11:11 --> Utf8 Class Initialized
INFO - 2020-02-09 06:11:11 --> URI Class Initialized
INFO - 2020-02-09 06:11:11 --> Router Class Initialized
INFO - 2020-02-09 06:11:11 --> Output Class Initialized
INFO - 2020-02-09 06:11:11 --> Security Class Initialized
DEBUG - 2020-02-09 06:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:11:11 --> Input Class Initialized
INFO - 2020-02-09 06:11:11 --> Language Class Initialized
INFO - 2020-02-09 06:11:12 --> Language Class Initialized
INFO - 2020-02-09 06:11:12 --> Config Class Initialized
INFO - 2020-02-09 06:11:12 --> Loader Class Initialized
INFO - 2020-02-09 06:11:12 --> Helper loaded: url_helper
INFO - 2020-02-09 06:11:12 --> Helper loaded: file_helper
INFO - 2020-02-09 06:11:12 --> Helper loaded: form_helper
INFO - 2020-02-09 06:11:12 --> Helper loaded: my_helper
INFO - 2020-02-09 06:11:12 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:11:12 --> Controller Class Initialized
INFO - 2020-02-09 06:11:59 --> Config Class Initialized
INFO - 2020-02-09 06:11:59 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:11:59 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:11:59 --> Utf8 Class Initialized
INFO - 2020-02-09 06:11:59 --> URI Class Initialized
INFO - 2020-02-09 06:11:59 --> Router Class Initialized
INFO - 2020-02-09 06:11:59 --> Output Class Initialized
INFO - 2020-02-09 06:11:59 --> Security Class Initialized
DEBUG - 2020-02-09 06:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:11:59 --> Input Class Initialized
INFO - 2020-02-09 06:11:59 --> Language Class Initialized
INFO - 2020-02-09 06:11:59 --> Language Class Initialized
INFO - 2020-02-09 06:11:59 --> Config Class Initialized
INFO - 2020-02-09 06:11:59 --> Loader Class Initialized
INFO - 2020-02-09 06:11:59 --> Helper loaded: url_helper
INFO - 2020-02-09 06:11:59 --> Helper loaded: file_helper
INFO - 2020-02-09 06:11:59 --> Helper loaded: form_helper
INFO - 2020-02-09 06:11:59 --> Helper loaded: my_helper
INFO - 2020-02-09 06:11:59 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:12:00 --> Controller Class Initialized
DEBUG - 2020-02-09 06:12:00 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/form_import.php
DEBUG - 2020-02-09 06:12:00 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:12:00 --> Final output sent to browser
DEBUG - 2020-02-09 06:12:00 --> Total execution time: 0.7668
INFO - 2020-02-09 06:12:10 --> Config Class Initialized
INFO - 2020-02-09 06:12:10 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:12:10 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:12:10 --> Utf8 Class Initialized
INFO - 2020-02-09 06:12:10 --> URI Class Initialized
INFO - 2020-02-09 06:12:10 --> Router Class Initialized
INFO - 2020-02-09 06:12:10 --> Output Class Initialized
INFO - 2020-02-09 06:12:10 --> Security Class Initialized
DEBUG - 2020-02-09 06:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:12:11 --> Input Class Initialized
INFO - 2020-02-09 06:12:11 --> Language Class Initialized
INFO - 2020-02-09 06:12:11 --> Language Class Initialized
INFO - 2020-02-09 06:12:11 --> Config Class Initialized
INFO - 2020-02-09 06:12:11 --> Loader Class Initialized
INFO - 2020-02-09 06:12:11 --> Helper loaded: url_helper
INFO - 2020-02-09 06:12:11 --> Helper loaded: file_helper
INFO - 2020-02-09 06:12:11 --> Helper loaded: form_helper
INFO - 2020-02-09 06:12:11 --> Helper loaded: my_helper
INFO - 2020-02-09 06:12:11 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:12:11 --> Controller Class Initialized
DEBUG - 2020-02-09 06:12:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/list.php
DEBUG - 2020-02-09 06:12:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:12:11 --> Final output sent to browser
DEBUG - 2020-02-09 06:12:11 --> Total execution time: 0.8541
INFO - 2020-02-09 06:12:11 --> Config Class Initialized
INFO - 2020-02-09 06:12:11 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:12:12 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:12:12 --> Utf8 Class Initialized
INFO - 2020-02-09 06:12:12 --> URI Class Initialized
INFO - 2020-02-09 06:12:12 --> Router Class Initialized
INFO - 2020-02-09 06:12:12 --> Output Class Initialized
INFO - 2020-02-09 06:12:12 --> Security Class Initialized
DEBUG - 2020-02-09 06:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:12:12 --> Input Class Initialized
INFO - 2020-02-09 06:12:12 --> Language Class Initialized
INFO - 2020-02-09 06:12:12 --> Language Class Initialized
INFO - 2020-02-09 06:12:12 --> Config Class Initialized
INFO - 2020-02-09 06:12:12 --> Loader Class Initialized
INFO - 2020-02-09 06:12:12 --> Helper loaded: url_helper
INFO - 2020-02-09 06:12:12 --> Helper loaded: file_helper
INFO - 2020-02-09 06:12:12 --> Helper loaded: form_helper
INFO - 2020-02-09 06:12:12 --> Helper loaded: my_helper
INFO - 2020-02-09 06:12:12 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:12:12 --> Controller Class Initialized
INFO - 2020-02-09 06:12:40 --> Config Class Initialized
INFO - 2020-02-09 06:12:40 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:12:40 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:12:40 --> Utf8 Class Initialized
INFO - 2020-02-09 06:12:40 --> URI Class Initialized
INFO - 2020-02-09 06:12:40 --> Router Class Initialized
INFO - 2020-02-09 06:12:40 --> Output Class Initialized
INFO - 2020-02-09 06:12:40 --> Security Class Initialized
DEBUG - 2020-02-09 06:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:12:40 --> Input Class Initialized
INFO - 2020-02-09 06:12:40 --> Language Class Initialized
INFO - 2020-02-09 06:12:40 --> Language Class Initialized
INFO - 2020-02-09 06:12:40 --> Config Class Initialized
INFO - 2020-02-09 06:12:40 --> Loader Class Initialized
INFO - 2020-02-09 06:12:40 --> Helper loaded: url_helper
INFO - 2020-02-09 06:12:40 --> Helper loaded: file_helper
INFO - 2020-02-09 06:12:40 --> Helper loaded: form_helper
INFO - 2020-02-09 06:12:40 --> Helper loaded: my_helper
INFO - 2020-02-09 06:12:40 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:12:40 --> Controller Class Initialized
INFO - 2020-02-09 06:12:40 --> Final output sent to browser
DEBUG - 2020-02-09 06:12:40 --> Total execution time: 0.7124
INFO - 2020-02-09 06:12:40 --> Config Class Initialized
INFO - 2020-02-09 06:12:40 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:12:40 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:12:41 --> Utf8 Class Initialized
INFO - 2020-02-09 06:12:41 --> URI Class Initialized
INFO - 2020-02-09 06:12:41 --> Router Class Initialized
INFO - 2020-02-09 06:12:41 --> Output Class Initialized
INFO - 2020-02-09 06:12:41 --> Security Class Initialized
DEBUG - 2020-02-09 06:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:12:41 --> Input Class Initialized
INFO - 2020-02-09 06:12:41 --> Language Class Initialized
INFO - 2020-02-09 06:12:41 --> Language Class Initialized
INFO - 2020-02-09 06:12:41 --> Config Class Initialized
INFO - 2020-02-09 06:12:41 --> Loader Class Initialized
INFO - 2020-02-09 06:12:41 --> Helper loaded: url_helper
INFO - 2020-02-09 06:12:41 --> Helper loaded: file_helper
INFO - 2020-02-09 06:12:41 --> Helper loaded: form_helper
INFO - 2020-02-09 06:12:41 --> Helper loaded: my_helper
INFO - 2020-02-09 06:12:41 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:12:41 --> Controller Class Initialized
INFO - 2020-02-09 06:13:04 --> Config Class Initialized
INFO - 2020-02-09 06:13:04 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:13:04 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:13:04 --> Utf8 Class Initialized
INFO - 2020-02-09 06:13:04 --> URI Class Initialized
INFO - 2020-02-09 06:13:04 --> Router Class Initialized
INFO - 2020-02-09 06:13:04 --> Output Class Initialized
INFO - 2020-02-09 06:13:04 --> Security Class Initialized
DEBUG - 2020-02-09 06:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:13:04 --> Input Class Initialized
INFO - 2020-02-09 06:13:04 --> Language Class Initialized
INFO - 2020-02-09 06:13:04 --> Language Class Initialized
INFO - 2020-02-09 06:13:04 --> Config Class Initialized
INFO - 2020-02-09 06:13:04 --> Loader Class Initialized
INFO - 2020-02-09 06:13:05 --> Helper loaded: url_helper
INFO - 2020-02-09 06:13:05 --> Helper loaded: file_helper
INFO - 2020-02-09 06:13:05 --> Helper loaded: form_helper
INFO - 2020-02-09 06:13:05 --> Helper loaded: my_helper
INFO - 2020-02-09 06:13:05 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:13:05 --> Controller Class Initialized
DEBUG - 2020-02-09 06:13:05 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-02-09 06:13:05 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:13:05 --> Final output sent to browser
DEBUG - 2020-02-09 06:13:05 --> Total execution time: 0.7109
INFO - 2020-02-09 06:13:05 --> Config Class Initialized
INFO - 2020-02-09 06:13:05 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:13:05 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:13:06 --> Utf8 Class Initialized
INFO - 2020-02-09 06:13:06 --> URI Class Initialized
INFO - 2020-02-09 06:13:06 --> Router Class Initialized
INFO - 2020-02-09 06:13:06 --> Output Class Initialized
INFO - 2020-02-09 06:13:06 --> Security Class Initialized
DEBUG - 2020-02-09 06:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:13:06 --> Input Class Initialized
INFO - 2020-02-09 06:13:06 --> Language Class Initialized
INFO - 2020-02-09 06:13:06 --> Language Class Initialized
INFO - 2020-02-09 06:13:06 --> Config Class Initialized
INFO - 2020-02-09 06:13:06 --> Loader Class Initialized
INFO - 2020-02-09 06:13:06 --> Helper loaded: url_helper
INFO - 2020-02-09 06:13:06 --> Helper loaded: file_helper
INFO - 2020-02-09 06:13:06 --> Helper loaded: form_helper
INFO - 2020-02-09 06:13:06 --> Helper loaded: my_helper
INFO - 2020-02-09 06:13:06 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:13:06 --> Controller Class Initialized
INFO - 2020-02-09 06:13:31 --> Config Class Initialized
INFO - 2020-02-09 06:13:31 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:13:31 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:13:31 --> Utf8 Class Initialized
INFO - 2020-02-09 06:13:31 --> URI Class Initialized
INFO - 2020-02-09 06:13:31 --> Router Class Initialized
INFO - 2020-02-09 06:13:31 --> Output Class Initialized
INFO - 2020-02-09 06:13:31 --> Security Class Initialized
DEBUG - 2020-02-09 06:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:13:31 --> Input Class Initialized
INFO - 2020-02-09 06:13:31 --> Language Class Initialized
INFO - 2020-02-09 06:13:31 --> Language Class Initialized
INFO - 2020-02-09 06:13:31 --> Config Class Initialized
INFO - 2020-02-09 06:13:32 --> Loader Class Initialized
INFO - 2020-02-09 06:13:32 --> Helper loaded: url_helper
INFO - 2020-02-09 06:13:32 --> Helper loaded: file_helper
INFO - 2020-02-09 06:13:32 --> Helper loaded: form_helper
INFO - 2020-02-09 06:13:32 --> Helper loaded: my_helper
INFO - 2020-02-09 06:13:32 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:13:32 --> Controller Class Initialized
INFO - 2020-02-09 06:13:32 --> Final output sent to browser
DEBUG - 2020-02-09 06:13:32 --> Total execution time: 0.5635
INFO - 2020-02-09 06:13:50 --> Config Class Initialized
INFO - 2020-02-09 06:13:50 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:13:50 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:13:50 --> Utf8 Class Initialized
INFO - 2020-02-09 06:13:50 --> URI Class Initialized
INFO - 2020-02-09 06:13:50 --> Router Class Initialized
INFO - 2020-02-09 06:13:50 --> Output Class Initialized
INFO - 2020-02-09 06:13:50 --> Security Class Initialized
DEBUG - 2020-02-09 06:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:13:50 --> Input Class Initialized
INFO - 2020-02-09 06:13:50 --> Language Class Initialized
INFO - 2020-02-09 06:13:50 --> Language Class Initialized
INFO - 2020-02-09 06:13:50 --> Config Class Initialized
INFO - 2020-02-09 06:13:50 --> Loader Class Initialized
INFO - 2020-02-09 06:13:50 --> Helper loaded: url_helper
INFO - 2020-02-09 06:13:50 --> Helper loaded: file_helper
INFO - 2020-02-09 06:13:50 --> Helper loaded: form_helper
INFO - 2020-02-09 06:13:50 --> Helper loaded: my_helper
INFO - 2020-02-09 06:13:50 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:13:51 --> Controller Class Initialized
DEBUG - 2020-02-09 06:13:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_mapel/views/list.php
DEBUG - 2020-02-09 06:13:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:13:51 --> Final output sent to browser
DEBUG - 2020-02-09 06:13:51 --> Total execution time: 0.7490
INFO - 2020-02-09 06:13:51 --> Config Class Initialized
INFO - 2020-02-09 06:13:51 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:13:51 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:13:51 --> Utf8 Class Initialized
INFO - 2020-02-09 06:13:51 --> URI Class Initialized
INFO - 2020-02-09 06:13:51 --> Router Class Initialized
INFO - 2020-02-09 06:13:51 --> Output Class Initialized
INFO - 2020-02-09 06:13:52 --> Security Class Initialized
DEBUG - 2020-02-09 06:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:13:52 --> Input Class Initialized
INFO - 2020-02-09 06:13:52 --> Language Class Initialized
INFO - 2020-02-09 06:13:52 --> Language Class Initialized
INFO - 2020-02-09 06:13:52 --> Config Class Initialized
INFO - 2020-02-09 06:13:52 --> Loader Class Initialized
INFO - 2020-02-09 06:13:52 --> Helper loaded: url_helper
INFO - 2020-02-09 06:13:52 --> Helper loaded: file_helper
INFO - 2020-02-09 06:13:52 --> Helper loaded: form_helper
INFO - 2020-02-09 06:13:52 --> Helper loaded: my_helper
INFO - 2020-02-09 06:13:52 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:13:52 --> Controller Class Initialized
INFO - 2020-02-09 06:14:01 --> Config Class Initialized
INFO - 2020-02-09 06:14:01 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:14:01 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:14:01 --> Utf8 Class Initialized
INFO - 2020-02-09 06:14:01 --> URI Class Initialized
INFO - 2020-02-09 06:14:01 --> Router Class Initialized
INFO - 2020-02-09 06:14:01 --> Output Class Initialized
INFO - 2020-02-09 06:14:01 --> Security Class Initialized
DEBUG - 2020-02-09 06:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:14:01 --> Input Class Initialized
INFO - 2020-02-09 06:14:01 --> Language Class Initialized
INFO - 2020-02-09 06:14:01 --> Language Class Initialized
INFO - 2020-02-09 06:14:01 --> Config Class Initialized
INFO - 2020-02-09 06:14:01 --> Loader Class Initialized
INFO - 2020-02-09 06:14:01 --> Helper loaded: url_helper
INFO - 2020-02-09 06:14:01 --> Helper loaded: file_helper
INFO - 2020-02-09 06:14:01 --> Helper loaded: form_helper
INFO - 2020-02-09 06:14:01 --> Helper loaded: my_helper
INFO - 2020-02-09 06:14:01 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:14:02 --> Controller Class Initialized
INFO - 2020-02-09 06:14:02 --> Final output sent to browser
DEBUG - 2020-02-09 06:14:02 --> Total execution time: 0.5811
INFO - 2020-02-09 06:14:30 --> Config Class Initialized
INFO - 2020-02-09 06:14:30 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:14:30 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:14:30 --> Utf8 Class Initialized
INFO - 2020-02-09 06:14:30 --> URI Class Initialized
INFO - 2020-02-09 06:14:30 --> Router Class Initialized
INFO - 2020-02-09 06:14:30 --> Output Class Initialized
INFO - 2020-02-09 06:14:30 --> Security Class Initialized
DEBUG - 2020-02-09 06:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:14:30 --> Input Class Initialized
INFO - 2020-02-09 06:14:30 --> Language Class Initialized
INFO - 2020-02-09 06:14:30 --> Language Class Initialized
INFO - 2020-02-09 06:14:30 --> Config Class Initialized
INFO - 2020-02-09 06:14:30 --> Loader Class Initialized
INFO - 2020-02-09 06:14:30 --> Helper loaded: url_helper
INFO - 2020-02-09 06:14:30 --> Helper loaded: file_helper
INFO - 2020-02-09 06:14:30 --> Helper loaded: form_helper
INFO - 2020-02-09 06:14:30 --> Helper loaded: my_helper
INFO - 2020-02-09 06:14:30 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:14:30 --> Controller Class Initialized
INFO - 2020-02-09 06:14:30 --> Final output sent to browser
DEBUG - 2020-02-09 06:14:30 --> Total execution time: 0.6616
INFO - 2020-02-09 06:15:08 --> Config Class Initialized
INFO - 2020-02-09 06:15:08 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:15:08 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:15:08 --> Utf8 Class Initialized
INFO - 2020-02-09 06:15:08 --> URI Class Initialized
INFO - 2020-02-09 06:15:09 --> Router Class Initialized
INFO - 2020-02-09 06:15:09 --> Output Class Initialized
INFO - 2020-02-09 06:15:09 --> Security Class Initialized
DEBUG - 2020-02-09 06:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:15:09 --> Input Class Initialized
INFO - 2020-02-09 06:15:09 --> Language Class Initialized
INFO - 2020-02-09 06:15:09 --> Language Class Initialized
INFO - 2020-02-09 06:15:09 --> Config Class Initialized
INFO - 2020-02-09 06:15:09 --> Loader Class Initialized
INFO - 2020-02-09 06:15:09 --> Helper loaded: url_helper
INFO - 2020-02-09 06:15:09 --> Helper loaded: file_helper
INFO - 2020-02-09 06:15:09 --> Helper loaded: form_helper
INFO - 2020-02-09 06:15:09 --> Helper loaded: my_helper
INFO - 2020-02-09 06:15:09 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:15:09 --> Controller Class Initialized
INFO - 2020-02-09 06:15:12 --> Config Class Initialized
INFO - 2020-02-09 06:15:12 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:15:12 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:15:12 --> Utf8 Class Initialized
INFO - 2020-02-09 06:15:12 --> URI Class Initialized
INFO - 2020-02-09 06:15:12 --> Router Class Initialized
INFO - 2020-02-09 06:15:12 --> Output Class Initialized
INFO - 2020-02-09 06:15:12 --> Security Class Initialized
DEBUG - 2020-02-09 06:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:15:12 --> Input Class Initialized
INFO - 2020-02-09 06:15:12 --> Language Class Initialized
INFO - 2020-02-09 06:15:12 --> Language Class Initialized
INFO - 2020-02-09 06:15:12 --> Config Class Initialized
INFO - 2020-02-09 06:15:12 --> Loader Class Initialized
INFO - 2020-02-09 06:15:12 --> Helper loaded: url_helper
INFO - 2020-02-09 06:15:12 --> Helper loaded: file_helper
INFO - 2020-02-09 06:15:12 --> Helper loaded: form_helper
INFO - 2020-02-09 06:15:12 --> Helper loaded: my_helper
INFO - 2020-02-09 06:15:12 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:15:13 --> Controller Class Initialized
INFO - 2020-02-09 06:15:23 --> Config Class Initialized
INFO - 2020-02-09 06:15:23 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:15:23 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:15:23 --> Utf8 Class Initialized
INFO - 2020-02-09 06:15:23 --> URI Class Initialized
INFO - 2020-02-09 06:15:23 --> Router Class Initialized
INFO - 2020-02-09 06:15:23 --> Output Class Initialized
INFO - 2020-02-09 06:15:23 --> Security Class Initialized
DEBUG - 2020-02-09 06:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:15:23 --> Input Class Initialized
INFO - 2020-02-09 06:15:23 --> Language Class Initialized
INFO - 2020-02-09 06:15:23 --> Language Class Initialized
INFO - 2020-02-09 06:15:23 --> Config Class Initialized
INFO - 2020-02-09 06:15:23 --> Loader Class Initialized
INFO - 2020-02-09 06:15:23 --> Helper loaded: url_helper
INFO - 2020-02-09 06:15:23 --> Helper loaded: file_helper
INFO - 2020-02-09 06:15:23 --> Helper loaded: form_helper
INFO - 2020-02-09 06:15:23 --> Helper loaded: my_helper
INFO - 2020-02-09 06:15:23 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:15:23 --> Controller Class Initialized
DEBUG - 2020-02-09 06:15:23 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_ekstra/views/list.php
DEBUG - 2020-02-09 06:15:23 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:15:23 --> Final output sent to browser
DEBUG - 2020-02-09 06:15:23 --> Total execution time: 0.6851
INFO - 2020-02-09 06:15:24 --> Config Class Initialized
INFO - 2020-02-09 06:15:24 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:15:24 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:15:24 --> Utf8 Class Initialized
INFO - 2020-02-09 06:15:24 --> URI Class Initialized
INFO - 2020-02-09 06:15:24 --> Router Class Initialized
INFO - 2020-02-09 06:15:24 --> Output Class Initialized
INFO - 2020-02-09 06:15:24 --> Security Class Initialized
DEBUG - 2020-02-09 06:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:15:24 --> Input Class Initialized
INFO - 2020-02-09 06:15:24 --> Language Class Initialized
INFO - 2020-02-09 06:15:24 --> Language Class Initialized
INFO - 2020-02-09 06:15:24 --> Config Class Initialized
INFO - 2020-02-09 06:15:24 --> Loader Class Initialized
INFO - 2020-02-09 06:15:24 --> Helper loaded: url_helper
INFO - 2020-02-09 06:15:24 --> Helper loaded: file_helper
INFO - 2020-02-09 06:15:24 --> Helper loaded: form_helper
INFO - 2020-02-09 06:15:24 --> Helper loaded: my_helper
INFO - 2020-02-09 06:15:24 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:15:24 --> Controller Class Initialized
INFO - 2020-02-09 06:16:02 --> Config Class Initialized
INFO - 2020-02-09 06:16:02 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:16:02 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:16:02 --> Utf8 Class Initialized
INFO - 2020-02-09 06:16:02 --> URI Class Initialized
INFO - 2020-02-09 06:16:02 --> Router Class Initialized
INFO - 2020-02-09 06:16:02 --> Output Class Initialized
INFO - 2020-02-09 06:16:02 --> Security Class Initialized
DEBUG - 2020-02-09 06:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:16:02 --> Input Class Initialized
INFO - 2020-02-09 06:16:02 --> Language Class Initialized
INFO - 2020-02-09 06:16:02 --> Language Class Initialized
INFO - 2020-02-09 06:16:02 --> Config Class Initialized
INFO - 2020-02-09 06:16:02 --> Loader Class Initialized
INFO - 2020-02-09 06:16:02 --> Helper loaded: url_helper
INFO - 2020-02-09 06:16:02 --> Helper loaded: file_helper
INFO - 2020-02-09 06:16:02 --> Helper loaded: form_helper
INFO - 2020-02-09 06:16:02 --> Helper loaded: my_helper
INFO - 2020-02-09 06:16:02 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:16:02 --> Controller Class Initialized
DEBUG - 2020-02-09 06:16:02 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-09 06:16:02 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:16:02 --> Final output sent to browser
DEBUG - 2020-02-09 06:16:02 --> Total execution time: 0.7403
INFO - 2020-02-09 06:16:03 --> Config Class Initialized
INFO - 2020-02-09 06:16:03 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:16:03 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:16:03 --> Utf8 Class Initialized
INFO - 2020-02-09 06:16:03 --> URI Class Initialized
INFO - 2020-02-09 06:16:03 --> Router Class Initialized
INFO - 2020-02-09 06:16:03 --> Output Class Initialized
INFO - 2020-02-09 06:16:03 --> Security Class Initialized
DEBUG - 2020-02-09 06:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:16:03 --> Input Class Initialized
INFO - 2020-02-09 06:16:03 --> Language Class Initialized
INFO - 2020-02-09 06:16:03 --> Language Class Initialized
INFO - 2020-02-09 06:16:03 --> Config Class Initialized
INFO - 2020-02-09 06:16:04 --> Loader Class Initialized
INFO - 2020-02-09 06:16:04 --> Helper loaded: url_helper
INFO - 2020-02-09 06:16:04 --> Helper loaded: file_helper
INFO - 2020-02-09 06:16:04 --> Helper loaded: form_helper
INFO - 2020-02-09 06:16:04 --> Helper loaded: my_helper
INFO - 2020-02-09 06:16:04 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:16:04 --> Controller Class Initialized
INFO - 2020-02-09 06:16:23 --> Config Class Initialized
INFO - 2020-02-09 06:16:23 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:16:23 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:16:23 --> Utf8 Class Initialized
INFO - 2020-02-09 06:16:23 --> URI Class Initialized
INFO - 2020-02-09 06:16:23 --> Router Class Initialized
INFO - 2020-02-09 06:16:23 --> Output Class Initialized
INFO - 2020-02-09 06:16:23 --> Security Class Initialized
DEBUG - 2020-02-09 06:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:16:23 --> Input Class Initialized
INFO - 2020-02-09 06:16:23 --> Language Class Initialized
INFO - 2020-02-09 06:16:23 --> Language Class Initialized
INFO - 2020-02-09 06:16:23 --> Config Class Initialized
INFO - 2020-02-09 06:16:23 --> Loader Class Initialized
INFO - 2020-02-09 06:16:23 --> Helper loaded: url_helper
INFO - 2020-02-09 06:16:23 --> Helper loaded: file_helper
INFO - 2020-02-09 06:16:23 --> Helper loaded: form_helper
INFO - 2020-02-09 06:16:23 --> Helper loaded: my_helper
INFO - 2020-02-09 06:16:23 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:16:24 --> Controller Class Initialized
INFO - 2020-02-09 06:16:24 --> Database Utility Class Initialized
INFO - 2020-02-09 06:16:24 --> Zip Compression Class Initialized
ERROR - 2020-02-09 06:16:24 --> Severity: Runtime Notice --> Only variables should be assigned by reference E:\xampp\htdocs\_2020\myraport\application\modules\backup_db\controllers\Backup_db.php 88
INFO - 2020-02-09 06:16:24 --> Config Class Initialized
INFO - 2020-02-09 06:16:24 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:16:24 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:16:24 --> Utf8 Class Initialized
INFO - 2020-02-09 06:16:24 --> URI Class Initialized
INFO - 2020-02-09 06:16:24 --> Router Class Initialized
INFO - 2020-02-09 06:16:24 --> Output Class Initialized
INFO - 2020-02-09 06:16:24 --> Security Class Initialized
DEBUG - 2020-02-09 06:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:16:24 --> Input Class Initialized
INFO - 2020-02-09 06:16:24 --> Language Class Initialized
INFO - 2020-02-09 06:16:24 --> Language Class Initialized
INFO - 2020-02-09 06:16:24 --> Config Class Initialized
INFO - 2020-02-09 06:16:24 --> Loader Class Initialized
INFO - 2020-02-09 06:16:24 --> Helper loaded: url_helper
INFO - 2020-02-09 06:16:24 --> Helper loaded: file_helper
INFO - 2020-02-09 06:16:24 --> Helper loaded: form_helper
INFO - 2020-02-09 06:16:24 --> Helper loaded: my_helper
INFO - 2020-02-09 06:16:24 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:16:25 --> Controller Class Initialized
DEBUG - 2020-02-09 06:16:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-09 06:16:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:16:25 --> Final output sent to browser
DEBUG - 2020-02-09 06:16:25 --> Total execution time: 0.6203
INFO - 2020-02-09 06:16:28 --> Config Class Initialized
INFO - 2020-02-09 06:16:28 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:16:28 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:16:28 --> Utf8 Class Initialized
INFO - 2020-02-09 06:16:28 --> URI Class Initialized
INFO - 2020-02-09 06:16:28 --> Router Class Initialized
INFO - 2020-02-09 06:16:28 --> Output Class Initialized
INFO - 2020-02-09 06:16:28 --> Security Class Initialized
DEBUG - 2020-02-09 06:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:16:28 --> Input Class Initialized
INFO - 2020-02-09 06:16:28 --> Language Class Initialized
INFO - 2020-02-09 06:16:28 --> Language Class Initialized
INFO - 2020-02-09 06:16:28 --> Config Class Initialized
INFO - 2020-02-09 06:16:28 --> Loader Class Initialized
INFO - 2020-02-09 06:16:28 --> Helper loaded: url_helper
INFO - 2020-02-09 06:16:28 --> Helper loaded: file_helper
INFO - 2020-02-09 06:16:28 --> Helper loaded: form_helper
INFO - 2020-02-09 06:16:28 --> Helper loaded: my_helper
INFO - 2020-02-09 06:16:28 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:16:28 --> Controller Class Initialized
INFO - 2020-02-09 06:16:57 --> Config Class Initialized
INFO - 2020-02-09 06:16:57 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:16:57 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:16:57 --> Utf8 Class Initialized
INFO - 2020-02-09 06:16:57 --> URI Class Initialized
INFO - 2020-02-09 06:16:57 --> Router Class Initialized
INFO - 2020-02-09 06:16:57 --> Output Class Initialized
INFO - 2020-02-09 06:16:57 --> Security Class Initialized
DEBUG - 2020-02-09 06:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:16:57 --> Input Class Initialized
INFO - 2020-02-09 06:16:57 --> Language Class Initialized
INFO - 2020-02-09 06:16:57 --> Language Class Initialized
INFO - 2020-02-09 06:16:57 --> Config Class Initialized
INFO - 2020-02-09 06:16:57 --> Loader Class Initialized
INFO - 2020-02-09 06:16:57 --> Helper loaded: url_helper
INFO - 2020-02-09 06:16:57 --> Helper loaded: file_helper
INFO - 2020-02-09 06:16:57 --> Helper loaded: form_helper
INFO - 2020-02-09 06:16:57 --> Helper loaded: my_helper
INFO - 2020-02-09 06:16:57 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:16:57 --> Controller Class Initialized
DEBUG - 2020-02-09 06:16:57 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-09 06:16:57 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:16:57 --> Final output sent to browser
DEBUG - 2020-02-09 06:16:57 --> Total execution time: 0.6976
INFO - 2020-02-09 06:16:58 --> Config Class Initialized
INFO - 2020-02-09 06:16:58 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:16:58 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:16:58 --> Utf8 Class Initialized
INFO - 2020-02-09 06:16:58 --> URI Class Initialized
INFO - 2020-02-09 06:16:58 --> Router Class Initialized
INFO - 2020-02-09 06:16:58 --> Output Class Initialized
INFO - 2020-02-09 06:16:58 --> Security Class Initialized
DEBUG - 2020-02-09 06:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:16:58 --> Input Class Initialized
INFO - 2020-02-09 06:16:58 --> Language Class Initialized
INFO - 2020-02-09 06:16:58 --> Language Class Initialized
INFO - 2020-02-09 06:16:58 --> Config Class Initialized
INFO - 2020-02-09 06:16:58 --> Loader Class Initialized
INFO - 2020-02-09 06:16:58 --> Helper loaded: url_helper
INFO - 2020-02-09 06:16:59 --> Helper loaded: file_helper
INFO - 2020-02-09 06:16:59 --> Helper loaded: form_helper
INFO - 2020-02-09 06:16:59 --> Helper loaded: my_helper
INFO - 2020-02-09 06:16:59 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:16:59 --> Controller Class Initialized
INFO - 2020-02-09 06:17:22 --> Config Class Initialized
INFO - 2020-02-09 06:17:22 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:17:22 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:17:22 --> Utf8 Class Initialized
INFO - 2020-02-09 06:17:22 --> URI Class Initialized
INFO - 2020-02-09 06:17:22 --> Router Class Initialized
INFO - 2020-02-09 06:17:22 --> Output Class Initialized
INFO - 2020-02-09 06:17:22 --> Security Class Initialized
DEBUG - 2020-02-09 06:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:17:22 --> Input Class Initialized
INFO - 2020-02-09 06:17:22 --> Language Class Initialized
INFO - 2020-02-09 06:17:22 --> Language Class Initialized
INFO - 2020-02-09 06:17:22 --> Config Class Initialized
INFO - 2020-02-09 06:17:22 --> Loader Class Initialized
INFO - 2020-02-09 06:17:22 --> Helper loaded: url_helper
INFO - 2020-02-09 06:17:22 --> Helper loaded: file_helper
INFO - 2020-02-09 06:17:22 --> Helper loaded: form_helper
INFO - 2020-02-09 06:17:22 --> Helper loaded: my_helper
INFO - 2020-02-09 06:17:22 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:17:22 --> Controller Class Initialized
INFO - 2020-02-09 06:17:22 --> Final output sent to browser
DEBUG - 2020-02-09 06:17:22 --> Total execution time: 0.7459
INFO - 2020-02-09 06:17:43 --> Config Class Initialized
INFO - 2020-02-09 06:17:43 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:17:43 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:17:43 --> Utf8 Class Initialized
INFO - 2020-02-09 06:17:43 --> URI Class Initialized
INFO - 2020-02-09 06:17:43 --> Router Class Initialized
INFO - 2020-02-09 06:17:43 --> Output Class Initialized
INFO - 2020-02-09 06:17:43 --> Security Class Initialized
DEBUG - 2020-02-09 06:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:17:43 --> Input Class Initialized
INFO - 2020-02-09 06:17:43 --> Language Class Initialized
INFO - 2020-02-09 06:17:43 --> Language Class Initialized
INFO - 2020-02-09 06:17:43 --> Config Class Initialized
INFO - 2020-02-09 06:17:43 --> Loader Class Initialized
INFO - 2020-02-09 06:17:43 --> Helper loaded: url_helper
INFO - 2020-02-09 06:17:43 --> Helper loaded: file_helper
INFO - 2020-02-09 06:17:43 --> Helper loaded: form_helper
INFO - 2020-02-09 06:17:43 --> Helper loaded: my_helper
INFO - 2020-02-09 06:17:43 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:17:44 --> Controller Class Initialized
INFO - 2020-02-09 06:17:44 --> Final output sent to browser
DEBUG - 2020-02-09 06:17:44 --> Total execution time: 0.7575
INFO - 2020-02-09 06:18:07 --> Config Class Initialized
INFO - 2020-02-09 06:18:07 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:18:07 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:18:07 --> Utf8 Class Initialized
INFO - 2020-02-09 06:18:07 --> URI Class Initialized
INFO - 2020-02-09 06:18:07 --> Router Class Initialized
INFO - 2020-02-09 06:18:07 --> Output Class Initialized
INFO - 2020-02-09 06:18:07 --> Security Class Initialized
DEBUG - 2020-02-09 06:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:18:07 --> Input Class Initialized
INFO - 2020-02-09 06:18:07 --> Language Class Initialized
INFO - 2020-02-09 06:18:07 --> Language Class Initialized
INFO - 2020-02-09 06:18:07 --> Config Class Initialized
INFO - 2020-02-09 06:18:07 --> Loader Class Initialized
INFO - 2020-02-09 06:18:07 --> Helper loaded: url_helper
INFO - 2020-02-09 06:18:07 --> Helper loaded: file_helper
INFO - 2020-02-09 06:18:07 --> Helper loaded: form_helper
INFO - 2020-02-09 06:18:07 --> Helper loaded: my_helper
INFO - 2020-02-09 06:18:07 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:18:07 --> Controller Class Initialized
INFO - 2020-02-09 06:18:08 --> Final output sent to browser
DEBUG - 2020-02-09 06:18:08 --> Total execution time: 0.5883
INFO - 2020-02-09 06:18:08 --> Config Class Initialized
INFO - 2020-02-09 06:18:08 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:18:08 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:18:08 --> Utf8 Class Initialized
INFO - 2020-02-09 06:18:08 --> URI Class Initialized
INFO - 2020-02-09 06:18:08 --> Router Class Initialized
INFO - 2020-02-09 06:18:08 --> Output Class Initialized
INFO - 2020-02-09 06:18:08 --> Security Class Initialized
DEBUG - 2020-02-09 06:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:18:08 --> Input Class Initialized
INFO - 2020-02-09 06:18:08 --> Language Class Initialized
INFO - 2020-02-09 06:18:08 --> Language Class Initialized
INFO - 2020-02-09 06:18:08 --> Config Class Initialized
INFO - 2020-02-09 06:18:08 --> Loader Class Initialized
INFO - 2020-02-09 06:18:08 --> Helper loaded: url_helper
INFO - 2020-02-09 06:18:08 --> Helper loaded: file_helper
INFO - 2020-02-09 06:18:08 --> Helper loaded: form_helper
INFO - 2020-02-09 06:18:08 --> Helper loaded: my_helper
INFO - 2020-02-09 06:18:08 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:18:08 --> Controller Class Initialized
INFO - 2020-02-09 06:18:22 --> Config Class Initialized
INFO - 2020-02-09 06:18:22 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:18:22 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:18:22 --> Utf8 Class Initialized
INFO - 2020-02-09 06:18:22 --> URI Class Initialized
INFO - 2020-02-09 06:18:22 --> Router Class Initialized
INFO - 2020-02-09 06:18:22 --> Output Class Initialized
INFO - 2020-02-09 06:18:23 --> Security Class Initialized
DEBUG - 2020-02-09 06:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:18:23 --> Input Class Initialized
INFO - 2020-02-09 06:18:23 --> Language Class Initialized
INFO - 2020-02-09 06:18:23 --> Language Class Initialized
INFO - 2020-02-09 06:18:23 --> Config Class Initialized
INFO - 2020-02-09 06:18:23 --> Loader Class Initialized
INFO - 2020-02-09 06:18:23 --> Helper loaded: url_helper
INFO - 2020-02-09 06:18:23 --> Helper loaded: file_helper
INFO - 2020-02-09 06:18:23 --> Helper loaded: form_helper
INFO - 2020-02-09 06:18:23 --> Helper loaded: my_helper
INFO - 2020-02-09 06:18:23 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:18:23 --> Controller Class Initialized
INFO - 2020-02-09 06:18:23 --> Final output sent to browser
DEBUG - 2020-02-09 06:18:23 --> Total execution time: 0.4912
INFO - 2020-02-09 06:18:23 --> Config Class Initialized
INFO - 2020-02-09 06:18:23 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:18:23 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:18:23 --> Utf8 Class Initialized
INFO - 2020-02-09 06:18:23 --> URI Class Initialized
INFO - 2020-02-09 06:18:23 --> Router Class Initialized
INFO - 2020-02-09 06:18:23 --> Output Class Initialized
INFO - 2020-02-09 06:18:23 --> Security Class Initialized
DEBUG - 2020-02-09 06:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:18:23 --> Input Class Initialized
INFO - 2020-02-09 06:18:23 --> Language Class Initialized
INFO - 2020-02-09 06:18:23 --> Language Class Initialized
INFO - 2020-02-09 06:18:23 --> Config Class Initialized
INFO - 2020-02-09 06:18:23 --> Loader Class Initialized
INFO - 2020-02-09 06:18:23 --> Helper loaded: url_helper
INFO - 2020-02-09 06:18:23 --> Helper loaded: file_helper
INFO - 2020-02-09 06:18:23 --> Helper loaded: form_helper
INFO - 2020-02-09 06:18:23 --> Helper loaded: my_helper
INFO - 2020-02-09 06:18:24 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:18:24 --> Controller Class Initialized
INFO - 2020-02-09 06:18:40 --> Config Class Initialized
INFO - 2020-02-09 06:18:40 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:18:40 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:18:40 --> Utf8 Class Initialized
INFO - 2020-02-09 06:18:40 --> URI Class Initialized
INFO - 2020-02-09 06:18:40 --> Router Class Initialized
INFO - 2020-02-09 06:18:40 --> Output Class Initialized
INFO - 2020-02-09 06:18:40 --> Security Class Initialized
DEBUG - 2020-02-09 06:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:18:40 --> Input Class Initialized
INFO - 2020-02-09 06:18:41 --> Language Class Initialized
INFO - 2020-02-09 06:18:41 --> Language Class Initialized
INFO - 2020-02-09 06:18:41 --> Config Class Initialized
INFO - 2020-02-09 06:18:41 --> Loader Class Initialized
INFO - 2020-02-09 06:18:41 --> Helper loaded: url_helper
INFO - 2020-02-09 06:18:41 --> Helper loaded: file_helper
INFO - 2020-02-09 06:18:41 --> Helper loaded: form_helper
INFO - 2020-02-09 06:18:41 --> Helper loaded: my_helper
INFO - 2020-02-09 06:18:41 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:18:41 --> Controller Class Initialized
INFO - 2020-02-09 06:18:41 --> Final output sent to browser
DEBUG - 2020-02-09 06:18:41 --> Total execution time: 0.4916
INFO - 2020-02-09 06:18:41 --> Config Class Initialized
INFO - 2020-02-09 06:18:41 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:18:41 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:18:41 --> Utf8 Class Initialized
INFO - 2020-02-09 06:18:41 --> URI Class Initialized
INFO - 2020-02-09 06:18:41 --> Router Class Initialized
INFO - 2020-02-09 06:18:41 --> Output Class Initialized
INFO - 2020-02-09 06:18:41 --> Security Class Initialized
DEBUG - 2020-02-09 06:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:18:41 --> Input Class Initialized
INFO - 2020-02-09 06:18:41 --> Language Class Initialized
INFO - 2020-02-09 06:18:41 --> Language Class Initialized
INFO - 2020-02-09 06:18:41 --> Config Class Initialized
INFO - 2020-02-09 06:18:41 --> Loader Class Initialized
INFO - 2020-02-09 06:18:41 --> Helper loaded: url_helper
INFO - 2020-02-09 06:18:41 --> Helper loaded: file_helper
INFO - 2020-02-09 06:18:41 --> Helper loaded: form_helper
INFO - 2020-02-09 06:18:41 --> Helper loaded: my_helper
INFO - 2020-02-09 06:18:41 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:18:42 --> Controller Class Initialized
INFO - 2020-02-09 06:18:47 --> Config Class Initialized
INFO - 2020-02-09 06:18:47 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:18:47 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:18:47 --> Utf8 Class Initialized
INFO - 2020-02-09 06:18:47 --> URI Class Initialized
INFO - 2020-02-09 06:18:47 --> Router Class Initialized
INFO - 2020-02-09 06:18:47 --> Output Class Initialized
INFO - 2020-02-09 06:18:48 --> Security Class Initialized
DEBUG - 2020-02-09 06:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:18:48 --> Input Class Initialized
INFO - 2020-02-09 06:18:48 --> Language Class Initialized
INFO - 2020-02-09 06:18:48 --> Language Class Initialized
INFO - 2020-02-09 06:18:48 --> Config Class Initialized
INFO - 2020-02-09 06:18:48 --> Loader Class Initialized
INFO - 2020-02-09 06:18:48 --> Helper loaded: url_helper
INFO - 2020-02-09 06:18:48 --> Helper loaded: file_helper
INFO - 2020-02-09 06:18:48 --> Helper loaded: form_helper
INFO - 2020-02-09 06:18:48 --> Helper loaded: my_helper
INFO - 2020-02-09 06:18:48 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:18:48 --> Controller Class Initialized
DEBUG - 2020-02-09 06:18:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-09 06:18:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:18:48 --> Final output sent to browser
DEBUG - 2020-02-09 06:18:48 --> Total execution time: 0.7747
INFO - 2020-02-09 06:19:14 --> Config Class Initialized
INFO - 2020-02-09 06:19:14 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:19:14 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:19:14 --> Utf8 Class Initialized
INFO - 2020-02-09 06:19:14 --> URI Class Initialized
INFO - 2020-02-09 06:19:15 --> Router Class Initialized
INFO - 2020-02-09 06:19:15 --> Output Class Initialized
INFO - 2020-02-09 06:19:15 --> Security Class Initialized
DEBUG - 2020-02-09 06:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:19:15 --> Input Class Initialized
INFO - 2020-02-09 06:19:15 --> Language Class Initialized
INFO - 2020-02-09 06:19:15 --> Language Class Initialized
INFO - 2020-02-09 06:19:15 --> Config Class Initialized
INFO - 2020-02-09 06:19:15 --> Loader Class Initialized
INFO - 2020-02-09 06:19:15 --> Helper loaded: url_helper
INFO - 2020-02-09 06:19:15 --> Helper loaded: file_helper
INFO - 2020-02-09 06:19:15 --> Helper loaded: form_helper
INFO - 2020-02-09 06:19:15 --> Helper loaded: my_helper
INFO - 2020-02-09 06:19:15 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:19:15 --> Controller Class Initialized
DEBUG - 2020-02-09 06:19:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-09 06:19:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:19:15 --> Final output sent to browser
DEBUG - 2020-02-09 06:19:15 --> Total execution time: 0.7389
INFO - 2020-02-09 06:19:24 --> Config Class Initialized
INFO - 2020-02-09 06:19:24 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:19:24 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:19:24 --> Utf8 Class Initialized
INFO - 2020-02-09 06:19:24 --> URI Class Initialized
INFO - 2020-02-09 06:19:24 --> Router Class Initialized
INFO - 2020-02-09 06:19:24 --> Output Class Initialized
INFO - 2020-02-09 06:19:24 --> Security Class Initialized
DEBUG - 2020-02-09 06:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:19:24 --> Input Class Initialized
INFO - 2020-02-09 06:19:24 --> Language Class Initialized
INFO - 2020-02-09 06:19:24 --> Language Class Initialized
INFO - 2020-02-09 06:19:24 --> Config Class Initialized
INFO - 2020-02-09 06:19:24 --> Loader Class Initialized
INFO - 2020-02-09 06:19:24 --> Helper loaded: url_helper
INFO - 2020-02-09 06:19:24 --> Helper loaded: file_helper
INFO - 2020-02-09 06:19:25 --> Helper loaded: form_helper
INFO - 2020-02-09 06:19:25 --> Helper loaded: my_helper
INFO - 2020-02-09 06:19:25 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:19:25 --> Controller Class Initialized
DEBUG - 2020-02-09 06:19:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-09 06:19:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:19:25 --> Final output sent to browser
DEBUG - 2020-02-09 06:19:25 --> Total execution time: 0.7506
INFO - 2020-02-09 06:19:35 --> Config Class Initialized
INFO - 2020-02-09 06:19:35 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:19:35 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:19:35 --> Utf8 Class Initialized
INFO - 2020-02-09 06:19:35 --> URI Class Initialized
INFO - 2020-02-09 06:19:35 --> Router Class Initialized
INFO - 2020-02-09 06:19:35 --> Output Class Initialized
INFO - 2020-02-09 06:19:35 --> Security Class Initialized
DEBUG - 2020-02-09 06:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:19:35 --> Input Class Initialized
INFO - 2020-02-09 06:19:35 --> Language Class Initialized
INFO - 2020-02-09 06:19:35 --> Language Class Initialized
INFO - 2020-02-09 06:19:35 --> Config Class Initialized
INFO - 2020-02-09 06:19:35 --> Loader Class Initialized
INFO - 2020-02-09 06:19:35 --> Helper loaded: url_helper
INFO - 2020-02-09 06:19:35 --> Helper loaded: file_helper
INFO - 2020-02-09 06:19:35 --> Helper loaded: form_helper
INFO - 2020-02-09 06:19:35 --> Helper loaded: my_helper
INFO - 2020-02-09 06:19:35 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:19:35 --> Controller Class Initialized
DEBUG - 2020-02-09 06:19:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/list.php
DEBUG - 2020-02-09 06:19:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:19:35 --> Final output sent to browser
DEBUG - 2020-02-09 06:19:35 --> Total execution time: 0.7749
INFO - 2020-02-09 06:19:36 --> Config Class Initialized
INFO - 2020-02-09 06:19:36 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:19:36 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:19:36 --> Utf8 Class Initialized
INFO - 2020-02-09 06:19:36 --> URI Class Initialized
INFO - 2020-02-09 06:19:36 --> Router Class Initialized
INFO - 2020-02-09 06:19:36 --> Output Class Initialized
INFO - 2020-02-09 06:19:36 --> Security Class Initialized
DEBUG - 2020-02-09 06:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:19:36 --> Input Class Initialized
INFO - 2020-02-09 06:19:36 --> Language Class Initialized
INFO - 2020-02-09 06:19:36 --> Language Class Initialized
INFO - 2020-02-09 06:19:36 --> Config Class Initialized
INFO - 2020-02-09 06:19:36 --> Loader Class Initialized
INFO - 2020-02-09 06:19:37 --> Helper loaded: url_helper
INFO - 2020-02-09 06:19:37 --> Helper loaded: file_helper
INFO - 2020-02-09 06:19:37 --> Helper loaded: form_helper
INFO - 2020-02-09 06:19:37 --> Helper loaded: my_helper
INFO - 2020-02-09 06:19:37 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:19:37 --> Controller Class Initialized
INFO - 2020-02-09 06:20:06 --> Config Class Initialized
INFO - 2020-02-09 06:20:06 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:20:06 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:20:06 --> Utf8 Class Initialized
INFO - 2020-02-09 06:20:07 --> URI Class Initialized
INFO - 2020-02-09 06:20:07 --> Router Class Initialized
INFO - 2020-02-09 06:20:07 --> Output Class Initialized
INFO - 2020-02-09 06:20:07 --> Security Class Initialized
DEBUG - 2020-02-09 06:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:20:07 --> Input Class Initialized
INFO - 2020-02-09 06:20:07 --> Language Class Initialized
INFO - 2020-02-09 06:20:07 --> Language Class Initialized
INFO - 2020-02-09 06:20:07 --> Config Class Initialized
INFO - 2020-02-09 06:20:07 --> Loader Class Initialized
INFO - 2020-02-09 06:20:07 --> Helper loaded: url_helper
INFO - 2020-02-09 06:20:07 --> Helper loaded: file_helper
INFO - 2020-02-09 06:20:07 --> Helper loaded: form_helper
INFO - 2020-02-09 06:20:07 --> Helper loaded: my_helper
INFO - 2020-02-09 06:20:07 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:20:07 --> Controller Class Initialized
DEBUG - 2020-02-09 06:20:07 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/form.php
DEBUG - 2020-02-09 06:20:07 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:20:07 --> Final output sent to browser
DEBUG - 2020-02-09 06:20:07 --> Total execution time: 0.7791
INFO - 2020-02-09 06:20:52 --> Config Class Initialized
INFO - 2020-02-09 06:20:52 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:20:52 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:20:52 --> Utf8 Class Initialized
INFO - 2020-02-09 06:20:52 --> URI Class Initialized
INFO - 2020-02-09 06:20:52 --> Router Class Initialized
INFO - 2020-02-09 06:20:52 --> Output Class Initialized
INFO - 2020-02-09 06:20:52 --> Security Class Initialized
DEBUG - 2020-02-09 06:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:20:52 --> Input Class Initialized
INFO - 2020-02-09 06:20:52 --> Language Class Initialized
INFO - 2020-02-09 06:20:52 --> Language Class Initialized
INFO - 2020-02-09 06:20:52 --> Config Class Initialized
INFO - 2020-02-09 06:20:52 --> Loader Class Initialized
INFO - 2020-02-09 06:20:52 --> Helper loaded: url_helper
INFO - 2020-02-09 06:20:52 --> Helper loaded: file_helper
INFO - 2020-02-09 06:20:52 --> Helper loaded: form_helper
INFO - 2020-02-09 06:20:52 --> Helper loaded: my_helper
INFO - 2020-02-09 06:20:52 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:20:53 --> Controller Class Initialized
DEBUG - 2020-02-09 06:20:53 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_walikelas/views/list.php
DEBUG - 2020-02-09 06:20:53 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:20:53 --> Final output sent to browser
DEBUG - 2020-02-09 06:20:53 --> Total execution time: 0.7854
INFO - 2020-02-09 06:20:53 --> Config Class Initialized
INFO - 2020-02-09 06:20:53 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:20:53 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:20:53 --> Utf8 Class Initialized
INFO - 2020-02-09 06:20:53 --> URI Class Initialized
INFO - 2020-02-09 06:20:53 --> Router Class Initialized
INFO - 2020-02-09 06:20:53 --> Output Class Initialized
INFO - 2020-02-09 06:20:53 --> Security Class Initialized
DEBUG - 2020-02-09 06:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:20:54 --> Input Class Initialized
INFO - 2020-02-09 06:20:54 --> Language Class Initialized
INFO - 2020-02-09 06:20:54 --> Language Class Initialized
INFO - 2020-02-09 06:20:54 --> Config Class Initialized
INFO - 2020-02-09 06:20:54 --> Loader Class Initialized
INFO - 2020-02-09 06:20:54 --> Helper loaded: url_helper
INFO - 2020-02-09 06:20:54 --> Helper loaded: file_helper
INFO - 2020-02-09 06:20:54 --> Helper loaded: form_helper
INFO - 2020-02-09 06:20:54 --> Helper loaded: my_helper
INFO - 2020-02-09 06:20:54 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:20:54 --> Controller Class Initialized
INFO - 2020-02-09 06:21:07 --> Config Class Initialized
INFO - 2020-02-09 06:21:07 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:21:07 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:21:08 --> Utf8 Class Initialized
INFO - 2020-02-09 06:21:08 --> URI Class Initialized
INFO - 2020-02-09 06:21:08 --> Router Class Initialized
INFO - 2020-02-09 06:21:08 --> Output Class Initialized
INFO - 2020-02-09 06:21:08 --> Security Class Initialized
DEBUG - 2020-02-09 06:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:21:08 --> Input Class Initialized
INFO - 2020-02-09 06:21:08 --> Language Class Initialized
INFO - 2020-02-09 06:21:08 --> Language Class Initialized
INFO - 2020-02-09 06:21:08 --> Config Class Initialized
INFO - 2020-02-09 06:21:08 --> Loader Class Initialized
INFO - 2020-02-09 06:21:08 --> Helper loaded: url_helper
INFO - 2020-02-09 06:21:08 --> Helper loaded: file_helper
INFO - 2020-02-09 06:21:08 --> Helper loaded: form_helper
INFO - 2020-02-09 06:21:08 --> Helper loaded: my_helper
INFO - 2020-02-09 06:21:08 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:21:08 --> Controller Class Initialized
INFO - 2020-02-09 06:21:08 --> Final output sent to browser
DEBUG - 2020-02-09 06:21:08 --> Total execution time: 0.5621
INFO - 2020-02-09 06:21:28 --> Config Class Initialized
INFO - 2020-02-09 06:21:29 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:21:29 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:21:29 --> Utf8 Class Initialized
INFO - 2020-02-09 06:21:29 --> URI Class Initialized
INFO - 2020-02-09 06:21:29 --> Router Class Initialized
INFO - 2020-02-09 06:21:29 --> Output Class Initialized
INFO - 2020-02-09 06:21:29 --> Security Class Initialized
DEBUG - 2020-02-09 06:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:21:29 --> Input Class Initialized
INFO - 2020-02-09 06:21:29 --> Language Class Initialized
INFO - 2020-02-09 06:21:29 --> Language Class Initialized
INFO - 2020-02-09 06:21:29 --> Config Class Initialized
INFO - 2020-02-09 06:21:29 --> Loader Class Initialized
INFO - 2020-02-09 06:21:29 --> Helper loaded: url_helper
INFO - 2020-02-09 06:21:29 --> Helper loaded: file_helper
INFO - 2020-02-09 06:21:29 --> Helper loaded: form_helper
INFO - 2020-02-09 06:21:29 --> Helper loaded: my_helper
INFO - 2020-02-09 06:21:29 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:21:29 --> Controller Class Initialized
DEBUG - 2020-02-09 06:21:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_ubah_password.php
DEBUG - 2020-02-09 06:21:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:21:29 --> Final output sent to browser
DEBUG - 2020-02-09 06:21:29 --> Total execution time: 0.7028
INFO - 2020-02-09 06:21:50 --> Config Class Initialized
INFO - 2020-02-09 06:21:50 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:21:50 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:21:50 --> Utf8 Class Initialized
INFO - 2020-02-09 06:21:50 --> URI Class Initialized
INFO - 2020-02-09 06:21:50 --> Router Class Initialized
INFO - 2020-02-09 06:21:50 --> Output Class Initialized
INFO - 2020-02-09 06:21:50 --> Security Class Initialized
DEBUG - 2020-02-09 06:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:21:50 --> Input Class Initialized
INFO - 2020-02-09 06:21:50 --> Language Class Initialized
INFO - 2020-02-09 06:21:50 --> Language Class Initialized
INFO - 2020-02-09 06:21:50 --> Config Class Initialized
INFO - 2020-02-09 06:21:50 --> Loader Class Initialized
INFO - 2020-02-09 06:21:50 --> Helper loaded: url_helper
INFO - 2020-02-09 06:21:50 --> Helper loaded: file_helper
INFO - 2020-02-09 06:21:51 --> Helper loaded: form_helper
INFO - 2020-02-09 06:21:51 --> Helper loaded: my_helper
INFO - 2020-02-09 06:21:51 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:21:51 --> Controller Class Initialized
DEBUG - 2020-02-09 06:21:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-09 06:21:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:21:51 --> Final output sent to browser
DEBUG - 2020-02-09 06:21:51 --> Total execution time: 0.6927
INFO - 2020-02-09 06:21:51 --> Config Class Initialized
INFO - 2020-02-09 06:21:51 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:21:52 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:21:52 --> Utf8 Class Initialized
INFO - 2020-02-09 06:21:52 --> URI Class Initialized
INFO - 2020-02-09 06:21:52 --> Router Class Initialized
INFO - 2020-02-09 06:21:52 --> Output Class Initialized
INFO - 2020-02-09 06:21:52 --> Security Class Initialized
DEBUG - 2020-02-09 06:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:21:52 --> Input Class Initialized
INFO - 2020-02-09 06:21:52 --> Language Class Initialized
INFO - 2020-02-09 06:21:52 --> Language Class Initialized
INFO - 2020-02-09 06:21:52 --> Config Class Initialized
INFO - 2020-02-09 06:21:52 --> Loader Class Initialized
INFO - 2020-02-09 06:21:52 --> Helper loaded: url_helper
INFO - 2020-02-09 06:21:52 --> Helper loaded: file_helper
INFO - 2020-02-09 06:21:52 --> Helper loaded: form_helper
INFO - 2020-02-09 06:21:52 --> Helper loaded: my_helper
INFO - 2020-02-09 06:21:52 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:21:52 --> Controller Class Initialized
INFO - 2020-02-09 06:22:02 --> Config Class Initialized
INFO - 2020-02-09 06:22:02 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:22:02 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:22:02 --> Utf8 Class Initialized
INFO - 2020-02-09 06:22:02 --> URI Class Initialized
INFO - 2020-02-09 06:22:02 --> Router Class Initialized
INFO - 2020-02-09 06:22:02 --> Output Class Initialized
INFO - 2020-02-09 06:22:02 --> Security Class Initialized
DEBUG - 2020-02-09 06:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:22:02 --> Input Class Initialized
INFO - 2020-02-09 06:22:02 --> Language Class Initialized
INFO - 2020-02-09 06:22:02 --> Language Class Initialized
INFO - 2020-02-09 06:22:02 --> Config Class Initialized
INFO - 2020-02-09 06:22:02 --> Loader Class Initialized
INFO - 2020-02-09 06:22:02 --> Helper loaded: url_helper
INFO - 2020-02-09 06:22:02 --> Helper loaded: file_helper
INFO - 2020-02-09 06:22:02 --> Helper loaded: form_helper
INFO - 2020-02-09 06:22:02 --> Helper loaded: my_helper
INFO - 2020-02-09 06:22:02 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:22:02 --> Controller Class Initialized
INFO - 2020-02-09 06:22:02 --> Final output sent to browser
DEBUG - 2020-02-09 06:22:02 --> Total execution time: 0.5489
INFO - 2020-02-09 06:22:02 --> Config Class Initialized
INFO - 2020-02-09 06:22:03 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:22:03 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:22:03 --> Utf8 Class Initialized
INFO - 2020-02-09 06:22:03 --> URI Class Initialized
INFO - 2020-02-09 06:22:03 --> Router Class Initialized
INFO - 2020-02-09 06:22:03 --> Output Class Initialized
INFO - 2020-02-09 06:22:03 --> Security Class Initialized
DEBUG - 2020-02-09 06:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:22:03 --> Input Class Initialized
INFO - 2020-02-09 06:22:03 --> Language Class Initialized
INFO - 2020-02-09 06:22:03 --> Language Class Initialized
INFO - 2020-02-09 06:22:03 --> Config Class Initialized
INFO - 2020-02-09 06:22:03 --> Loader Class Initialized
INFO - 2020-02-09 06:22:03 --> Helper loaded: url_helper
INFO - 2020-02-09 06:22:03 --> Helper loaded: file_helper
INFO - 2020-02-09 06:22:03 --> Helper loaded: form_helper
INFO - 2020-02-09 06:22:03 --> Helper loaded: my_helper
INFO - 2020-02-09 06:22:03 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:22:03 --> Controller Class Initialized
INFO - 2020-02-09 06:22:10 --> Config Class Initialized
INFO - 2020-02-09 06:22:10 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:22:10 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:22:10 --> Utf8 Class Initialized
INFO - 2020-02-09 06:22:10 --> URI Class Initialized
INFO - 2020-02-09 06:22:10 --> Router Class Initialized
INFO - 2020-02-09 06:22:10 --> Output Class Initialized
INFO - 2020-02-09 06:22:10 --> Security Class Initialized
DEBUG - 2020-02-09 06:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:22:10 --> Input Class Initialized
INFO - 2020-02-09 06:22:10 --> Language Class Initialized
INFO - 2020-02-09 06:22:10 --> Language Class Initialized
INFO - 2020-02-09 06:22:10 --> Config Class Initialized
INFO - 2020-02-09 06:22:10 --> Loader Class Initialized
INFO - 2020-02-09 06:22:10 --> Helper loaded: url_helper
INFO - 2020-02-09 06:22:10 --> Helper loaded: file_helper
INFO - 2020-02-09 06:22:10 --> Helper loaded: form_helper
INFO - 2020-02-09 06:22:10 --> Helper loaded: my_helper
INFO - 2020-02-09 06:22:10 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:22:10 --> Controller Class Initialized
DEBUG - 2020-02-09 06:22:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-09 06:22:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:22:11 --> Final output sent to browser
DEBUG - 2020-02-09 06:22:11 --> Total execution time: 0.6636
INFO - 2020-02-09 06:22:25 --> Config Class Initialized
INFO - 2020-02-09 06:22:25 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:22:25 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:22:25 --> Utf8 Class Initialized
INFO - 2020-02-09 06:22:25 --> URI Class Initialized
INFO - 2020-02-09 06:22:25 --> Router Class Initialized
INFO - 2020-02-09 06:22:25 --> Output Class Initialized
INFO - 2020-02-09 06:22:25 --> Security Class Initialized
DEBUG - 2020-02-09 06:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:22:25 --> Input Class Initialized
INFO - 2020-02-09 06:22:25 --> Language Class Initialized
INFO - 2020-02-09 06:22:25 --> Language Class Initialized
INFO - 2020-02-09 06:22:25 --> Config Class Initialized
INFO - 2020-02-09 06:22:25 --> Loader Class Initialized
INFO - 2020-02-09 06:22:25 --> Helper loaded: url_helper
INFO - 2020-02-09 06:22:25 --> Helper loaded: file_helper
INFO - 2020-02-09 06:22:25 --> Helper loaded: form_helper
INFO - 2020-02-09 06:22:25 --> Helper loaded: my_helper
INFO - 2020-02-09 06:22:25 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:22:25 --> Controller Class Initialized
DEBUG - 2020-02-09 06:22:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-09 06:22:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:22:25 --> Final output sent to browser
DEBUG - 2020-02-09 06:22:25 --> Total execution time: 0.7694
INFO - 2020-02-09 06:24:08 --> Config Class Initialized
INFO - 2020-02-09 06:24:08 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:24:09 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:24:09 --> Utf8 Class Initialized
INFO - 2020-02-09 06:24:09 --> URI Class Initialized
INFO - 2020-02-09 06:24:09 --> Router Class Initialized
INFO - 2020-02-09 06:24:09 --> Output Class Initialized
INFO - 2020-02-09 06:24:09 --> Security Class Initialized
DEBUG - 2020-02-09 06:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:24:09 --> Input Class Initialized
INFO - 2020-02-09 06:24:09 --> Language Class Initialized
INFO - 2020-02-09 06:24:09 --> Language Class Initialized
INFO - 2020-02-09 06:24:09 --> Config Class Initialized
INFO - 2020-02-09 06:24:09 --> Loader Class Initialized
INFO - 2020-02-09 06:24:09 --> Helper loaded: url_helper
INFO - 2020-02-09 06:24:09 --> Helper loaded: file_helper
INFO - 2020-02-09 06:24:09 --> Helper loaded: form_helper
INFO - 2020-02-09 06:24:09 --> Helper loaded: my_helper
INFO - 2020-02-09 06:24:09 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:24:09 --> Controller Class Initialized
INFO - 2020-02-09 06:24:09 --> Config Class Initialized
INFO - 2020-02-09 06:24:09 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:24:09 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:24:09 --> Utf8 Class Initialized
INFO - 2020-02-09 06:24:09 --> URI Class Initialized
INFO - 2020-02-09 06:24:09 --> Router Class Initialized
INFO - 2020-02-09 06:24:09 --> Output Class Initialized
INFO - 2020-02-09 06:24:09 --> Security Class Initialized
DEBUG - 2020-02-09 06:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:24:09 --> Input Class Initialized
INFO - 2020-02-09 06:24:09 --> Language Class Initialized
INFO - 2020-02-09 06:24:09 --> Language Class Initialized
INFO - 2020-02-09 06:24:09 --> Config Class Initialized
INFO - 2020-02-09 06:24:09 --> Loader Class Initialized
INFO - 2020-02-09 06:24:10 --> Helper loaded: url_helper
INFO - 2020-02-09 06:24:10 --> Helper loaded: file_helper
INFO - 2020-02-09 06:24:10 --> Helper loaded: form_helper
INFO - 2020-02-09 06:24:10 --> Helper loaded: my_helper
INFO - 2020-02-09 06:24:10 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:24:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:24:10 --> Controller Class Initialized
DEBUG - 2020-02-09 06:24:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-09 06:24:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:24:10 --> Final output sent to browser
DEBUG - 2020-02-09 06:24:10 --> Total execution time: 0.6347
INFO - 2020-02-09 06:24:34 --> Config Class Initialized
INFO - 2020-02-09 06:24:34 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:24:34 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:24:34 --> Utf8 Class Initialized
INFO - 2020-02-09 06:24:34 --> URI Class Initialized
INFO - 2020-02-09 06:24:34 --> Router Class Initialized
INFO - 2020-02-09 06:24:34 --> Output Class Initialized
INFO - 2020-02-09 06:24:34 --> Security Class Initialized
DEBUG - 2020-02-09 06:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:24:34 --> Input Class Initialized
INFO - 2020-02-09 06:24:34 --> Language Class Initialized
INFO - 2020-02-09 06:24:34 --> Language Class Initialized
INFO - 2020-02-09 06:24:34 --> Config Class Initialized
INFO - 2020-02-09 06:24:34 --> Loader Class Initialized
INFO - 2020-02-09 06:24:34 --> Helper loaded: url_helper
INFO - 2020-02-09 06:24:34 --> Helper loaded: file_helper
INFO - 2020-02-09 06:24:34 --> Helper loaded: form_helper
INFO - 2020-02-09 06:24:35 --> Helper loaded: my_helper
INFO - 2020-02-09 06:24:35 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:24:35 --> Controller Class Initialized
DEBUG - 2020-02-09 06:24:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/list.php
DEBUG - 2020-02-09 06:24:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:24:35 --> Final output sent to browser
DEBUG - 2020-02-09 06:24:35 --> Total execution time: 0.6801
INFO - 2020-02-09 06:24:35 --> Config Class Initialized
INFO - 2020-02-09 06:24:35 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:24:35 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:24:35 --> Utf8 Class Initialized
INFO - 2020-02-09 06:24:35 --> URI Class Initialized
INFO - 2020-02-09 06:24:36 --> Router Class Initialized
INFO - 2020-02-09 06:24:36 --> Output Class Initialized
INFO - 2020-02-09 06:24:36 --> Security Class Initialized
DEBUG - 2020-02-09 06:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:24:36 --> Input Class Initialized
INFO - 2020-02-09 06:24:36 --> Language Class Initialized
INFO - 2020-02-09 06:24:36 --> Language Class Initialized
INFO - 2020-02-09 06:24:36 --> Config Class Initialized
INFO - 2020-02-09 06:24:36 --> Loader Class Initialized
INFO - 2020-02-09 06:24:36 --> Helper loaded: url_helper
INFO - 2020-02-09 06:24:36 --> Helper loaded: file_helper
INFO - 2020-02-09 06:24:36 --> Helper loaded: form_helper
INFO - 2020-02-09 06:24:36 --> Helper loaded: my_helper
INFO - 2020-02-09 06:24:36 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:24:36 --> Controller Class Initialized
INFO - 2020-02-09 06:24:43 --> Config Class Initialized
INFO - 2020-02-09 06:24:43 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:24:43 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:24:43 --> Utf8 Class Initialized
INFO - 2020-02-09 06:24:43 --> URI Class Initialized
INFO - 2020-02-09 06:24:43 --> Router Class Initialized
INFO - 2020-02-09 06:24:43 --> Output Class Initialized
INFO - 2020-02-09 06:24:43 --> Security Class Initialized
DEBUG - 2020-02-09 06:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:24:43 --> Input Class Initialized
INFO - 2020-02-09 06:24:43 --> Language Class Initialized
INFO - 2020-02-09 06:24:43 --> Language Class Initialized
INFO - 2020-02-09 06:24:43 --> Config Class Initialized
INFO - 2020-02-09 06:24:43 --> Loader Class Initialized
INFO - 2020-02-09 06:24:43 --> Helper loaded: url_helper
INFO - 2020-02-09 06:24:43 --> Helper loaded: file_helper
INFO - 2020-02-09 06:24:43 --> Helper loaded: form_helper
INFO - 2020-02-09 06:24:43 --> Helper loaded: my_helper
INFO - 2020-02-09 06:24:43 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:24:43 --> Controller Class Initialized
DEBUG - 2020-02-09 06:24:43 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/form.php
DEBUG - 2020-02-09 06:24:43 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:24:43 --> Final output sent to browser
DEBUG - 2020-02-09 06:24:43 --> Total execution time: 0.7639
INFO - 2020-02-09 06:24:54 --> Config Class Initialized
INFO - 2020-02-09 06:24:54 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:24:54 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:24:55 --> Utf8 Class Initialized
INFO - 2020-02-09 06:24:55 --> URI Class Initialized
INFO - 2020-02-09 06:24:55 --> Router Class Initialized
INFO - 2020-02-09 06:24:55 --> Output Class Initialized
INFO - 2020-02-09 06:24:55 --> Security Class Initialized
DEBUG - 2020-02-09 06:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:24:55 --> Input Class Initialized
INFO - 2020-02-09 06:24:55 --> Language Class Initialized
INFO - 2020-02-09 06:24:55 --> Language Class Initialized
INFO - 2020-02-09 06:24:55 --> Config Class Initialized
INFO - 2020-02-09 06:24:55 --> Loader Class Initialized
INFO - 2020-02-09 06:24:55 --> Helper loaded: url_helper
INFO - 2020-02-09 06:24:55 --> Helper loaded: file_helper
INFO - 2020-02-09 06:24:55 --> Helper loaded: form_helper
INFO - 2020-02-09 06:24:55 --> Helper loaded: my_helper
INFO - 2020-02-09 06:24:55 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:24:55 --> Controller Class Initialized
INFO - 2020-02-09 06:24:55 --> Config Class Initialized
INFO - 2020-02-09 06:24:55 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:24:55 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:24:55 --> Utf8 Class Initialized
INFO - 2020-02-09 06:24:55 --> URI Class Initialized
INFO - 2020-02-09 06:24:55 --> Router Class Initialized
INFO - 2020-02-09 06:24:55 --> Output Class Initialized
INFO - 2020-02-09 06:24:55 --> Security Class Initialized
DEBUG - 2020-02-09 06:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:24:55 --> Input Class Initialized
INFO - 2020-02-09 06:24:55 --> Language Class Initialized
INFO - 2020-02-09 06:24:55 --> Language Class Initialized
INFO - 2020-02-09 06:24:55 --> Config Class Initialized
INFO - 2020-02-09 06:24:55 --> Loader Class Initialized
INFO - 2020-02-09 06:24:56 --> Helper loaded: url_helper
INFO - 2020-02-09 06:24:56 --> Helper loaded: file_helper
INFO - 2020-02-09 06:24:56 --> Helper loaded: form_helper
INFO - 2020-02-09 06:24:56 --> Helper loaded: my_helper
INFO - 2020-02-09 06:24:56 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:24:56 --> Controller Class Initialized
DEBUG - 2020-02-09 06:24:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/list.php
DEBUG - 2020-02-09 06:24:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:24:56 --> Final output sent to browser
DEBUG - 2020-02-09 06:24:56 --> Total execution time: 0.6570
INFO - 2020-02-09 06:24:56 --> Config Class Initialized
INFO - 2020-02-09 06:24:57 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:24:57 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:24:57 --> Utf8 Class Initialized
INFO - 2020-02-09 06:24:57 --> URI Class Initialized
INFO - 2020-02-09 06:24:57 --> Router Class Initialized
INFO - 2020-02-09 06:24:57 --> Output Class Initialized
INFO - 2020-02-09 06:24:57 --> Security Class Initialized
DEBUG - 2020-02-09 06:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:24:57 --> Input Class Initialized
INFO - 2020-02-09 06:24:57 --> Language Class Initialized
INFO - 2020-02-09 06:24:57 --> Language Class Initialized
INFO - 2020-02-09 06:24:57 --> Config Class Initialized
INFO - 2020-02-09 06:24:57 --> Loader Class Initialized
INFO - 2020-02-09 06:24:57 --> Helper loaded: url_helper
INFO - 2020-02-09 06:24:57 --> Helper loaded: file_helper
INFO - 2020-02-09 06:24:57 --> Helper loaded: form_helper
INFO - 2020-02-09 06:24:57 --> Helper loaded: my_helper
INFO - 2020-02-09 06:24:57 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:24:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:24:57 --> Controller Class Initialized
INFO - 2020-02-09 06:25:00 --> Config Class Initialized
INFO - 2020-02-09 06:25:00 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:25:00 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:25:00 --> Utf8 Class Initialized
INFO - 2020-02-09 06:25:00 --> URI Class Initialized
INFO - 2020-02-09 06:25:00 --> Router Class Initialized
INFO - 2020-02-09 06:25:00 --> Output Class Initialized
INFO - 2020-02-09 06:25:00 --> Security Class Initialized
DEBUG - 2020-02-09 06:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:25:00 --> Input Class Initialized
INFO - 2020-02-09 06:25:01 --> Language Class Initialized
INFO - 2020-02-09 06:25:01 --> Language Class Initialized
INFO - 2020-02-09 06:25:01 --> Config Class Initialized
INFO - 2020-02-09 06:25:01 --> Loader Class Initialized
INFO - 2020-02-09 06:25:01 --> Helper loaded: url_helper
INFO - 2020-02-09 06:25:01 --> Helper loaded: file_helper
INFO - 2020-02-09 06:25:01 --> Helper loaded: form_helper
INFO - 2020-02-09 06:25:01 --> Helper loaded: my_helper
INFO - 2020-02-09 06:25:01 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:25:01 --> Controller Class Initialized
DEBUG - 2020-02-09 06:25:01 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/form.php
DEBUG - 2020-02-09 06:25:01 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:25:01 --> Final output sent to browser
DEBUG - 2020-02-09 06:25:01 --> Total execution time: 0.8011
INFO - 2020-02-09 06:25:09 --> Config Class Initialized
INFO - 2020-02-09 06:25:09 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:25:09 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:25:09 --> Utf8 Class Initialized
INFO - 2020-02-09 06:25:09 --> URI Class Initialized
INFO - 2020-02-09 06:25:09 --> Router Class Initialized
INFO - 2020-02-09 06:25:09 --> Output Class Initialized
INFO - 2020-02-09 06:25:10 --> Security Class Initialized
DEBUG - 2020-02-09 06:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:25:10 --> Input Class Initialized
INFO - 2020-02-09 06:25:10 --> Language Class Initialized
INFO - 2020-02-09 06:25:10 --> Language Class Initialized
INFO - 2020-02-09 06:25:10 --> Config Class Initialized
INFO - 2020-02-09 06:25:10 --> Loader Class Initialized
INFO - 2020-02-09 06:25:10 --> Helper loaded: url_helper
INFO - 2020-02-09 06:25:10 --> Helper loaded: file_helper
INFO - 2020-02-09 06:25:10 --> Helper loaded: form_helper
INFO - 2020-02-09 06:25:10 --> Helper loaded: my_helper
INFO - 2020-02-09 06:25:10 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:25:10 --> Controller Class Initialized
INFO - 2020-02-09 06:25:10 --> Config Class Initialized
INFO - 2020-02-09 06:25:10 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:25:10 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:25:10 --> Utf8 Class Initialized
INFO - 2020-02-09 06:25:10 --> URI Class Initialized
INFO - 2020-02-09 06:25:10 --> Router Class Initialized
INFO - 2020-02-09 06:25:10 --> Output Class Initialized
INFO - 2020-02-09 06:25:10 --> Security Class Initialized
DEBUG - 2020-02-09 06:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:25:10 --> Input Class Initialized
INFO - 2020-02-09 06:25:10 --> Language Class Initialized
INFO - 2020-02-09 06:25:10 --> Language Class Initialized
INFO - 2020-02-09 06:25:10 --> Config Class Initialized
INFO - 2020-02-09 06:25:10 --> Loader Class Initialized
INFO - 2020-02-09 06:25:10 --> Helper loaded: url_helper
INFO - 2020-02-09 06:25:10 --> Helper loaded: file_helper
INFO - 2020-02-09 06:25:11 --> Helper loaded: form_helper
INFO - 2020-02-09 06:25:11 --> Helper loaded: my_helper
INFO - 2020-02-09 06:25:11 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:25:11 --> Controller Class Initialized
DEBUG - 2020-02-09 06:25:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/list.php
DEBUG - 2020-02-09 06:25:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:25:11 --> Final output sent to browser
DEBUG - 2020-02-09 06:25:11 --> Total execution time: 0.7612
INFO - 2020-02-09 06:25:11 --> Config Class Initialized
INFO - 2020-02-09 06:25:11 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:25:11 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:25:11 --> Utf8 Class Initialized
INFO - 2020-02-09 06:25:12 --> URI Class Initialized
INFO - 2020-02-09 06:25:12 --> Router Class Initialized
INFO - 2020-02-09 06:25:12 --> Output Class Initialized
INFO - 2020-02-09 06:25:12 --> Security Class Initialized
DEBUG - 2020-02-09 06:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:25:12 --> Input Class Initialized
INFO - 2020-02-09 06:25:12 --> Language Class Initialized
INFO - 2020-02-09 06:25:12 --> Language Class Initialized
INFO - 2020-02-09 06:25:12 --> Config Class Initialized
INFO - 2020-02-09 06:25:12 --> Loader Class Initialized
INFO - 2020-02-09 06:25:12 --> Helper loaded: url_helper
INFO - 2020-02-09 06:25:12 --> Helper loaded: file_helper
INFO - 2020-02-09 06:25:12 --> Helper loaded: form_helper
INFO - 2020-02-09 06:25:12 --> Helper loaded: my_helper
INFO - 2020-02-09 06:25:12 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:25:12 --> Controller Class Initialized
INFO - 2020-02-09 06:25:13 --> Config Class Initialized
INFO - 2020-02-09 06:25:13 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:25:13 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:25:13 --> Utf8 Class Initialized
INFO - 2020-02-09 06:25:13 --> URI Class Initialized
INFO - 2020-02-09 06:25:13 --> Router Class Initialized
INFO - 2020-02-09 06:25:13 --> Output Class Initialized
INFO - 2020-02-09 06:25:13 --> Security Class Initialized
DEBUG - 2020-02-09 06:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:25:13 --> Input Class Initialized
INFO - 2020-02-09 06:25:13 --> Language Class Initialized
INFO - 2020-02-09 06:25:13 --> Language Class Initialized
INFO - 2020-02-09 06:25:13 --> Config Class Initialized
INFO - 2020-02-09 06:25:14 --> Loader Class Initialized
INFO - 2020-02-09 06:25:14 --> Helper loaded: url_helper
INFO - 2020-02-09 06:25:14 --> Helper loaded: file_helper
INFO - 2020-02-09 06:25:14 --> Helper loaded: form_helper
INFO - 2020-02-09 06:25:14 --> Helper loaded: my_helper
INFO - 2020-02-09 06:25:14 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:25:14 --> Controller Class Initialized
DEBUG - 2020-02-09 06:25:14 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/form.php
DEBUG - 2020-02-09 06:25:14 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:25:14 --> Final output sent to browser
DEBUG - 2020-02-09 06:25:14 --> Total execution time: 0.7777
INFO - 2020-02-09 06:25:23 --> Config Class Initialized
INFO - 2020-02-09 06:25:23 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:25:23 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:25:23 --> Utf8 Class Initialized
INFO - 2020-02-09 06:25:23 --> URI Class Initialized
INFO - 2020-02-09 06:25:23 --> Router Class Initialized
INFO - 2020-02-09 06:25:23 --> Output Class Initialized
INFO - 2020-02-09 06:25:23 --> Security Class Initialized
DEBUG - 2020-02-09 06:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:25:23 --> Input Class Initialized
INFO - 2020-02-09 06:25:24 --> Language Class Initialized
INFO - 2020-02-09 06:25:24 --> Language Class Initialized
INFO - 2020-02-09 06:25:24 --> Config Class Initialized
INFO - 2020-02-09 06:25:24 --> Loader Class Initialized
INFO - 2020-02-09 06:25:24 --> Helper loaded: url_helper
INFO - 2020-02-09 06:25:24 --> Helper loaded: file_helper
INFO - 2020-02-09 06:25:24 --> Helper loaded: form_helper
INFO - 2020-02-09 06:25:24 --> Helper loaded: my_helper
INFO - 2020-02-09 06:25:24 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:25:24 --> Controller Class Initialized
INFO - 2020-02-09 06:25:24 --> Config Class Initialized
INFO - 2020-02-09 06:25:24 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:25:24 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:25:24 --> Utf8 Class Initialized
INFO - 2020-02-09 06:25:24 --> URI Class Initialized
INFO - 2020-02-09 06:25:24 --> Router Class Initialized
INFO - 2020-02-09 06:25:24 --> Output Class Initialized
INFO - 2020-02-09 06:25:24 --> Security Class Initialized
DEBUG - 2020-02-09 06:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:25:24 --> Input Class Initialized
INFO - 2020-02-09 06:25:24 --> Language Class Initialized
INFO - 2020-02-09 06:25:24 --> Language Class Initialized
INFO - 2020-02-09 06:25:24 --> Config Class Initialized
INFO - 2020-02-09 06:25:24 --> Loader Class Initialized
INFO - 2020-02-09 06:25:24 --> Helper loaded: url_helper
INFO - 2020-02-09 06:25:24 --> Helper loaded: file_helper
INFO - 2020-02-09 06:25:25 --> Helper loaded: form_helper
INFO - 2020-02-09 06:25:25 --> Helper loaded: my_helper
INFO - 2020-02-09 06:25:25 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:25:25 --> Controller Class Initialized
DEBUG - 2020-02-09 06:25:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/list.php
DEBUG - 2020-02-09 06:25:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:25:25 --> Final output sent to browser
DEBUG - 2020-02-09 06:25:25 --> Total execution time: 0.8120
INFO - 2020-02-09 06:25:25 --> Config Class Initialized
INFO - 2020-02-09 06:25:25 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:25:25 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:25:25 --> Utf8 Class Initialized
INFO - 2020-02-09 06:25:25 --> URI Class Initialized
INFO - 2020-02-09 06:25:26 --> Router Class Initialized
INFO - 2020-02-09 06:25:26 --> Output Class Initialized
INFO - 2020-02-09 06:25:26 --> Security Class Initialized
DEBUG - 2020-02-09 06:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:25:26 --> Input Class Initialized
INFO - 2020-02-09 06:25:26 --> Language Class Initialized
INFO - 2020-02-09 06:25:26 --> Language Class Initialized
INFO - 2020-02-09 06:25:26 --> Config Class Initialized
INFO - 2020-02-09 06:25:26 --> Loader Class Initialized
INFO - 2020-02-09 06:25:26 --> Helper loaded: url_helper
INFO - 2020-02-09 06:25:26 --> Helper loaded: file_helper
INFO - 2020-02-09 06:25:26 --> Helper loaded: form_helper
INFO - 2020-02-09 06:25:26 --> Helper loaded: my_helper
INFO - 2020-02-09 06:25:26 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:25:26 --> Controller Class Initialized
INFO - 2020-02-09 06:25:27 --> Config Class Initialized
INFO - 2020-02-09 06:25:27 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:25:27 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:25:27 --> Utf8 Class Initialized
INFO - 2020-02-09 06:25:27 --> URI Class Initialized
INFO - 2020-02-09 06:25:27 --> Router Class Initialized
INFO - 2020-02-09 06:25:27 --> Output Class Initialized
INFO - 2020-02-09 06:25:27 --> Security Class Initialized
DEBUG - 2020-02-09 06:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:25:27 --> Input Class Initialized
INFO - 2020-02-09 06:25:27 --> Language Class Initialized
INFO - 2020-02-09 06:25:27 --> Language Class Initialized
INFO - 2020-02-09 06:25:27 --> Config Class Initialized
INFO - 2020-02-09 06:25:27 --> Loader Class Initialized
INFO - 2020-02-09 06:25:27 --> Helper loaded: url_helper
INFO - 2020-02-09 06:25:27 --> Helper loaded: file_helper
INFO - 2020-02-09 06:25:27 --> Helper loaded: form_helper
INFO - 2020-02-09 06:25:27 --> Helper loaded: my_helper
INFO - 2020-02-09 06:25:27 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:25:27 --> Controller Class Initialized
DEBUG - 2020-02-09 06:25:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/form.php
DEBUG - 2020-02-09 06:25:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:25:28 --> Final output sent to browser
DEBUG - 2020-02-09 06:25:28 --> Total execution time: 0.8423
INFO - 2020-02-09 06:25:38 --> Config Class Initialized
INFO - 2020-02-09 06:25:39 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:25:39 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:25:39 --> Utf8 Class Initialized
INFO - 2020-02-09 06:25:39 --> URI Class Initialized
INFO - 2020-02-09 06:25:39 --> Router Class Initialized
INFO - 2020-02-09 06:25:39 --> Output Class Initialized
INFO - 2020-02-09 06:25:39 --> Security Class Initialized
DEBUG - 2020-02-09 06:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:25:39 --> Input Class Initialized
INFO - 2020-02-09 06:25:39 --> Language Class Initialized
INFO - 2020-02-09 06:25:39 --> Language Class Initialized
INFO - 2020-02-09 06:25:39 --> Config Class Initialized
INFO - 2020-02-09 06:25:39 --> Loader Class Initialized
INFO - 2020-02-09 06:25:39 --> Helper loaded: url_helper
INFO - 2020-02-09 06:25:39 --> Helper loaded: file_helper
INFO - 2020-02-09 06:25:39 --> Helper loaded: form_helper
INFO - 2020-02-09 06:25:39 --> Helper loaded: my_helper
INFO - 2020-02-09 06:25:39 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:25:39 --> Controller Class Initialized
INFO - 2020-02-09 06:25:39 --> Config Class Initialized
INFO - 2020-02-09 06:25:39 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:25:39 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:25:39 --> Utf8 Class Initialized
INFO - 2020-02-09 06:25:39 --> URI Class Initialized
INFO - 2020-02-09 06:25:40 --> Router Class Initialized
INFO - 2020-02-09 06:25:40 --> Output Class Initialized
INFO - 2020-02-09 06:25:40 --> Security Class Initialized
DEBUG - 2020-02-09 06:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:25:40 --> Input Class Initialized
INFO - 2020-02-09 06:25:40 --> Language Class Initialized
INFO - 2020-02-09 06:25:40 --> Language Class Initialized
INFO - 2020-02-09 06:25:40 --> Config Class Initialized
INFO - 2020-02-09 06:25:40 --> Loader Class Initialized
INFO - 2020-02-09 06:25:40 --> Helper loaded: url_helper
INFO - 2020-02-09 06:25:40 --> Helper loaded: file_helper
INFO - 2020-02-09 06:25:40 --> Helper loaded: form_helper
INFO - 2020-02-09 06:25:40 --> Helper loaded: my_helper
INFO - 2020-02-09 06:25:40 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:25:40 --> Controller Class Initialized
DEBUG - 2020-02-09 06:25:40 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/list.php
DEBUG - 2020-02-09 06:25:40 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:25:40 --> Final output sent to browser
DEBUG - 2020-02-09 06:25:40 --> Total execution time: 0.6613
INFO - 2020-02-09 06:25:41 --> Config Class Initialized
INFO - 2020-02-09 06:25:41 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:25:41 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:25:41 --> Utf8 Class Initialized
INFO - 2020-02-09 06:25:41 --> URI Class Initialized
INFO - 2020-02-09 06:25:41 --> Router Class Initialized
INFO - 2020-02-09 06:25:41 --> Output Class Initialized
INFO - 2020-02-09 06:25:41 --> Security Class Initialized
DEBUG - 2020-02-09 06:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:25:41 --> Input Class Initialized
INFO - 2020-02-09 06:25:41 --> Language Class Initialized
INFO - 2020-02-09 06:25:41 --> Language Class Initialized
INFO - 2020-02-09 06:25:41 --> Config Class Initialized
INFO - 2020-02-09 06:25:41 --> Loader Class Initialized
INFO - 2020-02-09 06:25:41 --> Helper loaded: url_helper
INFO - 2020-02-09 06:25:41 --> Helper loaded: file_helper
INFO - 2020-02-09 06:25:42 --> Helper loaded: form_helper
INFO - 2020-02-09 06:25:42 --> Helper loaded: my_helper
INFO - 2020-02-09 06:25:42 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:25:42 --> Controller Class Initialized
INFO - 2020-02-09 06:25:44 --> Config Class Initialized
INFO - 2020-02-09 06:25:44 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:25:44 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:25:44 --> Utf8 Class Initialized
INFO - 2020-02-09 06:25:44 --> URI Class Initialized
INFO - 2020-02-09 06:25:44 --> Router Class Initialized
INFO - 2020-02-09 06:25:44 --> Output Class Initialized
INFO - 2020-02-09 06:25:44 --> Security Class Initialized
DEBUG - 2020-02-09 06:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:25:44 --> Input Class Initialized
INFO - 2020-02-09 06:25:44 --> Language Class Initialized
INFO - 2020-02-09 06:25:44 --> Language Class Initialized
INFO - 2020-02-09 06:25:44 --> Config Class Initialized
INFO - 2020-02-09 06:25:44 --> Loader Class Initialized
INFO - 2020-02-09 06:25:44 --> Helper loaded: url_helper
INFO - 2020-02-09 06:25:44 --> Helper loaded: file_helper
INFO - 2020-02-09 06:25:44 --> Helper loaded: form_helper
INFO - 2020-02-09 06:25:44 --> Helper loaded: my_helper
INFO - 2020-02-09 06:25:44 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:25:44 --> Controller Class Initialized
DEBUG - 2020-02-09 06:25:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/form.php
DEBUG - 2020-02-09 06:25:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:25:44 --> Final output sent to browser
DEBUG - 2020-02-09 06:25:44 --> Total execution time: 0.7667
INFO - 2020-02-09 06:25:55 --> Config Class Initialized
INFO - 2020-02-09 06:25:55 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:25:55 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:25:55 --> Utf8 Class Initialized
INFO - 2020-02-09 06:25:56 --> URI Class Initialized
INFO - 2020-02-09 06:25:56 --> Router Class Initialized
INFO - 2020-02-09 06:25:56 --> Output Class Initialized
INFO - 2020-02-09 06:25:56 --> Security Class Initialized
DEBUG - 2020-02-09 06:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:25:56 --> Input Class Initialized
INFO - 2020-02-09 06:25:56 --> Language Class Initialized
INFO - 2020-02-09 06:25:56 --> Language Class Initialized
INFO - 2020-02-09 06:25:56 --> Config Class Initialized
INFO - 2020-02-09 06:25:56 --> Loader Class Initialized
INFO - 2020-02-09 06:25:56 --> Helper loaded: url_helper
INFO - 2020-02-09 06:25:56 --> Helper loaded: file_helper
INFO - 2020-02-09 06:25:56 --> Helper loaded: form_helper
INFO - 2020-02-09 06:25:56 --> Helper loaded: my_helper
INFO - 2020-02-09 06:25:56 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:25:56 --> Controller Class Initialized
INFO - 2020-02-09 06:25:56 --> Config Class Initialized
INFO - 2020-02-09 06:25:56 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:25:56 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:25:56 --> Utf8 Class Initialized
INFO - 2020-02-09 06:25:56 --> URI Class Initialized
INFO - 2020-02-09 06:25:56 --> Router Class Initialized
INFO - 2020-02-09 06:25:56 --> Output Class Initialized
INFO - 2020-02-09 06:25:56 --> Security Class Initialized
DEBUG - 2020-02-09 06:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:25:56 --> Input Class Initialized
INFO - 2020-02-09 06:25:56 --> Language Class Initialized
INFO - 2020-02-09 06:25:56 --> Language Class Initialized
INFO - 2020-02-09 06:25:56 --> Config Class Initialized
INFO - 2020-02-09 06:25:56 --> Loader Class Initialized
INFO - 2020-02-09 06:25:57 --> Helper loaded: url_helper
INFO - 2020-02-09 06:25:57 --> Helper loaded: file_helper
INFO - 2020-02-09 06:25:57 --> Helper loaded: form_helper
INFO - 2020-02-09 06:25:57 --> Helper loaded: my_helper
INFO - 2020-02-09 06:25:57 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:25:57 --> Controller Class Initialized
DEBUG - 2020-02-09 06:25:57 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/list.php
DEBUG - 2020-02-09 06:25:57 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:25:57 --> Final output sent to browser
DEBUG - 2020-02-09 06:25:57 --> Total execution time: 0.7289
INFO - 2020-02-09 06:25:57 --> Config Class Initialized
INFO - 2020-02-09 06:25:57 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:25:57 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:25:57 --> Utf8 Class Initialized
INFO - 2020-02-09 06:25:58 --> URI Class Initialized
INFO - 2020-02-09 06:25:58 --> Router Class Initialized
INFO - 2020-02-09 06:25:58 --> Output Class Initialized
INFO - 2020-02-09 06:25:58 --> Security Class Initialized
DEBUG - 2020-02-09 06:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:25:58 --> Input Class Initialized
INFO - 2020-02-09 06:25:58 --> Language Class Initialized
INFO - 2020-02-09 06:25:58 --> Language Class Initialized
INFO - 2020-02-09 06:25:58 --> Config Class Initialized
INFO - 2020-02-09 06:25:58 --> Loader Class Initialized
INFO - 2020-02-09 06:25:58 --> Helper loaded: url_helper
INFO - 2020-02-09 06:25:58 --> Helper loaded: file_helper
INFO - 2020-02-09 06:25:58 --> Helper loaded: form_helper
INFO - 2020-02-09 06:25:58 --> Helper loaded: my_helper
INFO - 2020-02-09 06:25:58 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:25:58 --> Controller Class Initialized
INFO - 2020-02-09 06:25:59 --> Config Class Initialized
INFO - 2020-02-09 06:25:59 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:25:59 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:25:59 --> Utf8 Class Initialized
INFO - 2020-02-09 06:25:59 --> URI Class Initialized
INFO - 2020-02-09 06:25:59 --> Router Class Initialized
INFO - 2020-02-09 06:25:59 --> Output Class Initialized
INFO - 2020-02-09 06:25:59 --> Security Class Initialized
DEBUG - 2020-02-09 06:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:25:59 --> Input Class Initialized
INFO - 2020-02-09 06:25:59 --> Language Class Initialized
INFO - 2020-02-09 06:25:59 --> Language Class Initialized
INFO - 2020-02-09 06:25:59 --> Config Class Initialized
INFO - 2020-02-09 06:25:59 --> Loader Class Initialized
INFO - 2020-02-09 06:25:59 --> Helper loaded: url_helper
INFO - 2020-02-09 06:25:59 --> Helper loaded: file_helper
INFO - 2020-02-09 06:25:59 --> Helper loaded: form_helper
INFO - 2020-02-09 06:25:59 --> Helper loaded: my_helper
INFO - 2020-02-09 06:25:59 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:25:59 --> Controller Class Initialized
DEBUG - 2020-02-09 06:25:59 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/form.php
DEBUG - 2020-02-09 06:25:59 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:25:59 --> Final output sent to browser
DEBUG - 2020-02-09 06:25:59 --> Total execution time: 0.8014
INFO - 2020-02-09 06:26:06 --> Config Class Initialized
INFO - 2020-02-09 06:26:07 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:26:07 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:26:07 --> Utf8 Class Initialized
INFO - 2020-02-09 06:26:07 --> URI Class Initialized
INFO - 2020-02-09 06:26:07 --> Router Class Initialized
INFO - 2020-02-09 06:26:07 --> Output Class Initialized
INFO - 2020-02-09 06:26:07 --> Security Class Initialized
DEBUG - 2020-02-09 06:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:26:07 --> Input Class Initialized
INFO - 2020-02-09 06:26:07 --> Language Class Initialized
INFO - 2020-02-09 06:26:07 --> Language Class Initialized
INFO - 2020-02-09 06:26:07 --> Config Class Initialized
INFO - 2020-02-09 06:26:07 --> Loader Class Initialized
INFO - 2020-02-09 06:26:07 --> Helper loaded: url_helper
INFO - 2020-02-09 06:26:07 --> Helper loaded: file_helper
INFO - 2020-02-09 06:26:07 --> Helper loaded: form_helper
INFO - 2020-02-09 06:26:07 --> Helper loaded: my_helper
INFO - 2020-02-09 06:26:07 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:26:07 --> Controller Class Initialized
INFO - 2020-02-09 06:26:07 --> Config Class Initialized
INFO - 2020-02-09 06:26:07 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:26:07 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:26:07 --> Utf8 Class Initialized
INFO - 2020-02-09 06:26:07 --> URI Class Initialized
INFO - 2020-02-09 06:26:07 --> Router Class Initialized
INFO - 2020-02-09 06:26:07 --> Output Class Initialized
INFO - 2020-02-09 06:26:07 --> Security Class Initialized
DEBUG - 2020-02-09 06:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:26:07 --> Input Class Initialized
INFO - 2020-02-09 06:26:07 --> Language Class Initialized
INFO - 2020-02-09 06:26:07 --> Language Class Initialized
INFO - 2020-02-09 06:26:07 --> Config Class Initialized
INFO - 2020-02-09 06:26:08 --> Loader Class Initialized
INFO - 2020-02-09 06:26:08 --> Helper loaded: url_helper
INFO - 2020-02-09 06:26:08 --> Helper loaded: file_helper
INFO - 2020-02-09 06:26:08 --> Helper loaded: form_helper
INFO - 2020-02-09 06:26:08 --> Helper loaded: my_helper
INFO - 2020-02-09 06:26:08 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:26:08 --> Controller Class Initialized
DEBUG - 2020-02-09 06:26:08 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/list.php
DEBUG - 2020-02-09 06:26:08 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:26:08 --> Final output sent to browser
DEBUG - 2020-02-09 06:26:08 --> Total execution time: 0.6830
INFO - 2020-02-09 06:26:08 --> Config Class Initialized
INFO - 2020-02-09 06:26:08 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:26:08 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:26:08 --> Utf8 Class Initialized
INFO - 2020-02-09 06:26:08 --> URI Class Initialized
INFO - 2020-02-09 06:26:09 --> Router Class Initialized
INFO - 2020-02-09 06:26:09 --> Output Class Initialized
INFO - 2020-02-09 06:26:09 --> Security Class Initialized
DEBUG - 2020-02-09 06:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:26:09 --> Input Class Initialized
INFO - 2020-02-09 06:26:09 --> Language Class Initialized
INFO - 2020-02-09 06:26:09 --> Language Class Initialized
INFO - 2020-02-09 06:26:09 --> Config Class Initialized
INFO - 2020-02-09 06:26:09 --> Loader Class Initialized
INFO - 2020-02-09 06:26:09 --> Helper loaded: url_helper
INFO - 2020-02-09 06:26:09 --> Helper loaded: file_helper
INFO - 2020-02-09 06:26:09 --> Helper loaded: form_helper
INFO - 2020-02-09 06:26:09 --> Helper loaded: my_helper
INFO - 2020-02-09 06:26:09 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:26:09 --> Controller Class Initialized
INFO - 2020-02-09 06:26:29 --> Config Class Initialized
INFO - 2020-02-09 06:26:29 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:26:29 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:26:29 --> Utf8 Class Initialized
INFO - 2020-02-09 06:26:29 --> URI Class Initialized
INFO - 2020-02-09 06:26:29 --> Router Class Initialized
INFO - 2020-02-09 06:26:29 --> Output Class Initialized
INFO - 2020-02-09 06:26:29 --> Security Class Initialized
DEBUG - 2020-02-09 06:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:26:29 --> Input Class Initialized
INFO - 2020-02-09 06:26:29 --> Language Class Initialized
INFO - 2020-02-09 06:26:29 --> Language Class Initialized
INFO - 2020-02-09 06:26:29 --> Config Class Initialized
INFO - 2020-02-09 06:26:29 --> Loader Class Initialized
INFO - 2020-02-09 06:26:29 --> Helper loaded: url_helper
INFO - 2020-02-09 06:26:29 --> Helper loaded: file_helper
INFO - 2020-02-09 06:26:29 --> Helper loaded: form_helper
INFO - 2020-02-09 06:26:29 --> Helper loaded: my_helper
INFO - 2020-02-09 06:26:29 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:26:29 --> Controller Class Initialized
DEBUG - 2020-02-09 06:26:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_walikelas/views/list.php
DEBUG - 2020-02-09 06:26:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:26:29 --> Final output sent to browser
DEBUG - 2020-02-09 06:26:29 --> Total execution time: 0.7115
INFO - 2020-02-09 06:26:30 --> Config Class Initialized
INFO - 2020-02-09 06:26:30 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:26:30 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:26:30 --> Utf8 Class Initialized
INFO - 2020-02-09 06:26:30 --> URI Class Initialized
INFO - 2020-02-09 06:26:30 --> Router Class Initialized
INFO - 2020-02-09 06:26:30 --> Output Class Initialized
INFO - 2020-02-09 06:26:30 --> Security Class Initialized
DEBUG - 2020-02-09 06:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:26:30 --> Input Class Initialized
INFO - 2020-02-09 06:26:30 --> Language Class Initialized
INFO - 2020-02-09 06:26:30 --> Language Class Initialized
INFO - 2020-02-09 06:26:30 --> Config Class Initialized
INFO - 2020-02-09 06:26:30 --> Loader Class Initialized
INFO - 2020-02-09 06:26:30 --> Helper loaded: url_helper
INFO - 2020-02-09 06:26:30 --> Helper loaded: file_helper
INFO - 2020-02-09 06:26:30 --> Helper loaded: form_helper
INFO - 2020-02-09 06:26:30 --> Helper loaded: my_helper
INFO - 2020-02-09 06:26:30 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:26:30 --> Controller Class Initialized
INFO - 2020-02-09 06:26:34 --> Config Class Initialized
INFO - 2020-02-09 06:26:35 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:26:35 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:26:35 --> Utf8 Class Initialized
INFO - 2020-02-09 06:26:35 --> URI Class Initialized
INFO - 2020-02-09 06:26:35 --> Router Class Initialized
INFO - 2020-02-09 06:26:35 --> Output Class Initialized
INFO - 2020-02-09 06:26:35 --> Security Class Initialized
DEBUG - 2020-02-09 06:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:26:35 --> Input Class Initialized
INFO - 2020-02-09 06:26:35 --> Language Class Initialized
INFO - 2020-02-09 06:26:35 --> Language Class Initialized
INFO - 2020-02-09 06:26:35 --> Config Class Initialized
INFO - 2020-02-09 06:26:35 --> Loader Class Initialized
INFO - 2020-02-09 06:26:35 --> Helper loaded: url_helper
INFO - 2020-02-09 06:26:35 --> Helper loaded: file_helper
INFO - 2020-02-09 06:26:35 --> Helper loaded: form_helper
INFO - 2020-02-09 06:26:35 --> Helper loaded: my_helper
INFO - 2020-02-09 06:26:35 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:26:35 --> Controller Class Initialized
INFO - 2020-02-09 06:26:35 --> Final output sent to browser
DEBUG - 2020-02-09 06:26:35 --> Total execution time: 0.6584
INFO - 2020-02-09 06:26:49 --> Config Class Initialized
INFO - 2020-02-09 06:26:49 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:26:49 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:26:49 --> Utf8 Class Initialized
INFO - 2020-02-09 06:26:49 --> URI Class Initialized
INFO - 2020-02-09 06:26:49 --> Router Class Initialized
INFO - 2020-02-09 06:26:49 --> Output Class Initialized
INFO - 2020-02-09 06:26:49 --> Security Class Initialized
DEBUG - 2020-02-09 06:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:26:49 --> Input Class Initialized
INFO - 2020-02-09 06:26:49 --> Language Class Initialized
INFO - 2020-02-09 06:26:49 --> Language Class Initialized
INFO - 2020-02-09 06:26:49 --> Config Class Initialized
INFO - 2020-02-09 06:26:49 --> Loader Class Initialized
INFO - 2020-02-09 06:26:49 --> Helper loaded: url_helper
INFO - 2020-02-09 06:26:49 --> Helper loaded: file_helper
INFO - 2020-02-09 06:26:49 --> Helper loaded: form_helper
INFO - 2020-02-09 06:26:49 --> Helper loaded: my_helper
INFO - 2020-02-09 06:26:49 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:26:49 --> Controller Class Initialized
INFO - 2020-02-09 06:26:49 --> Final output sent to browser
DEBUG - 2020-02-09 06:26:49 --> Total execution time: 0.5383
INFO - 2020-02-09 06:26:49 --> Config Class Initialized
INFO - 2020-02-09 06:26:49 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:26:49 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:26:50 --> Utf8 Class Initialized
INFO - 2020-02-09 06:26:50 --> URI Class Initialized
INFO - 2020-02-09 06:26:50 --> Router Class Initialized
INFO - 2020-02-09 06:26:50 --> Output Class Initialized
INFO - 2020-02-09 06:26:50 --> Security Class Initialized
DEBUG - 2020-02-09 06:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:26:50 --> Input Class Initialized
INFO - 2020-02-09 06:26:50 --> Language Class Initialized
INFO - 2020-02-09 06:26:50 --> Language Class Initialized
INFO - 2020-02-09 06:26:50 --> Config Class Initialized
INFO - 2020-02-09 06:26:50 --> Loader Class Initialized
INFO - 2020-02-09 06:26:50 --> Helper loaded: url_helper
INFO - 2020-02-09 06:26:50 --> Helper loaded: file_helper
INFO - 2020-02-09 06:26:50 --> Helper loaded: form_helper
INFO - 2020-02-09 06:26:50 --> Helper loaded: my_helper
INFO - 2020-02-09 06:26:50 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:26:50 --> Controller Class Initialized
INFO - 2020-02-09 06:27:29 --> Config Class Initialized
INFO - 2020-02-09 06:27:29 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:27:29 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:27:29 --> Utf8 Class Initialized
INFO - 2020-02-09 06:27:30 --> URI Class Initialized
INFO - 2020-02-09 06:27:30 --> Router Class Initialized
INFO - 2020-02-09 06:27:30 --> Output Class Initialized
INFO - 2020-02-09 06:27:30 --> Security Class Initialized
DEBUG - 2020-02-09 06:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:27:30 --> Input Class Initialized
INFO - 2020-02-09 06:27:30 --> Language Class Initialized
INFO - 2020-02-09 06:27:30 --> Language Class Initialized
INFO - 2020-02-09 06:27:30 --> Config Class Initialized
INFO - 2020-02-09 06:27:30 --> Loader Class Initialized
INFO - 2020-02-09 06:27:30 --> Helper loaded: url_helper
INFO - 2020-02-09 06:27:30 --> Helper loaded: file_helper
INFO - 2020-02-09 06:27:30 --> Helper loaded: form_helper
INFO - 2020-02-09 06:27:30 --> Helper loaded: my_helper
INFO - 2020-02-09 06:27:30 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:27:30 --> Controller Class Initialized
DEBUG - 2020-02-09 06:27:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_guru/views/list.php
DEBUG - 2020-02-09 06:27:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:27:30 --> Final output sent to browser
DEBUG - 2020-02-09 06:27:30 --> Total execution time: 0.9466
INFO - 2020-02-09 06:27:31 --> Config Class Initialized
INFO - 2020-02-09 06:27:31 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:27:31 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:27:31 --> Utf8 Class Initialized
INFO - 2020-02-09 06:27:31 --> URI Class Initialized
INFO - 2020-02-09 06:27:31 --> Router Class Initialized
INFO - 2020-02-09 06:27:31 --> Output Class Initialized
INFO - 2020-02-09 06:27:31 --> Security Class Initialized
DEBUG - 2020-02-09 06:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:27:31 --> Input Class Initialized
INFO - 2020-02-09 06:27:31 --> Language Class Initialized
INFO - 2020-02-09 06:27:31 --> Language Class Initialized
INFO - 2020-02-09 06:27:31 --> Config Class Initialized
INFO - 2020-02-09 06:27:31 --> Loader Class Initialized
INFO - 2020-02-09 06:27:31 --> Helper loaded: url_helper
INFO - 2020-02-09 06:27:31 --> Helper loaded: file_helper
INFO - 2020-02-09 06:27:31 --> Helper loaded: form_helper
INFO - 2020-02-09 06:27:31 --> Helper loaded: my_helper
INFO - 2020-02-09 06:27:32 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:27:32 --> Controller Class Initialized
INFO - 2020-02-09 06:27:39 --> Config Class Initialized
INFO - 2020-02-09 06:27:39 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:27:39 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:27:39 --> Utf8 Class Initialized
INFO - 2020-02-09 06:27:39 --> URI Class Initialized
INFO - 2020-02-09 06:27:39 --> Router Class Initialized
INFO - 2020-02-09 06:27:39 --> Output Class Initialized
INFO - 2020-02-09 06:27:39 --> Security Class Initialized
DEBUG - 2020-02-09 06:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:27:39 --> Input Class Initialized
INFO - 2020-02-09 06:27:39 --> Language Class Initialized
INFO - 2020-02-09 06:27:39 --> Language Class Initialized
INFO - 2020-02-09 06:27:39 --> Config Class Initialized
INFO - 2020-02-09 06:27:39 --> Loader Class Initialized
INFO - 2020-02-09 06:27:39 --> Helper loaded: url_helper
INFO - 2020-02-09 06:27:39 --> Helper loaded: file_helper
INFO - 2020-02-09 06:27:39 --> Helper loaded: form_helper
INFO - 2020-02-09 06:27:39 --> Helper loaded: my_helper
INFO - 2020-02-09 06:27:39 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:27:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:27:39 --> Controller Class Initialized
INFO - 2020-02-09 06:27:39 --> Helper loaded: cookie_helper
INFO - 2020-02-09 06:27:39 --> Config Class Initialized
INFO - 2020-02-09 06:27:39 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:27:39 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:27:39 --> Utf8 Class Initialized
INFO - 2020-02-09 06:27:40 --> URI Class Initialized
INFO - 2020-02-09 06:27:40 --> Router Class Initialized
INFO - 2020-02-09 06:27:40 --> Output Class Initialized
INFO - 2020-02-09 06:27:40 --> Security Class Initialized
DEBUG - 2020-02-09 06:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:27:40 --> Input Class Initialized
INFO - 2020-02-09 06:27:40 --> Language Class Initialized
INFO - 2020-02-09 06:27:40 --> Language Class Initialized
INFO - 2020-02-09 06:27:40 --> Config Class Initialized
INFO - 2020-02-09 06:27:40 --> Loader Class Initialized
INFO - 2020-02-09 06:27:40 --> Helper loaded: url_helper
INFO - 2020-02-09 06:27:40 --> Helper loaded: file_helper
INFO - 2020-02-09 06:27:40 --> Helper loaded: form_helper
INFO - 2020-02-09 06:27:40 --> Helper loaded: my_helper
INFO - 2020-02-09 06:27:40 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:27:40 --> Controller Class Initialized
INFO - 2020-02-09 06:27:40 --> Config Class Initialized
INFO - 2020-02-09 06:27:40 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:27:40 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:27:40 --> Utf8 Class Initialized
INFO - 2020-02-09 06:27:40 --> URI Class Initialized
INFO - 2020-02-09 06:27:40 --> Router Class Initialized
INFO - 2020-02-09 06:27:40 --> Output Class Initialized
INFO - 2020-02-09 06:27:40 --> Security Class Initialized
DEBUG - 2020-02-09 06:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:27:40 --> Input Class Initialized
INFO - 2020-02-09 06:27:40 --> Language Class Initialized
INFO - 2020-02-09 06:27:40 --> Language Class Initialized
INFO - 2020-02-09 06:27:40 --> Config Class Initialized
INFO - 2020-02-09 06:27:40 --> Loader Class Initialized
INFO - 2020-02-09 06:27:40 --> Helper loaded: url_helper
INFO - 2020-02-09 06:27:40 --> Helper loaded: file_helper
INFO - 2020-02-09 06:27:40 --> Helper loaded: form_helper
INFO - 2020-02-09 06:27:41 --> Helper loaded: my_helper
INFO - 2020-02-09 06:27:41 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:27:41 --> Controller Class Initialized
DEBUG - 2020-02-09 06:27:41 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 06:27:41 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:27:41 --> Final output sent to browser
DEBUG - 2020-02-09 06:27:41 --> Total execution time: 0.6895
INFO - 2020-02-09 06:28:11 --> Config Class Initialized
INFO - 2020-02-09 06:28:11 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:28:11 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:28:11 --> Utf8 Class Initialized
INFO - 2020-02-09 06:28:11 --> URI Class Initialized
INFO - 2020-02-09 06:28:11 --> Router Class Initialized
INFO - 2020-02-09 06:28:11 --> Output Class Initialized
INFO - 2020-02-09 06:28:11 --> Security Class Initialized
DEBUG - 2020-02-09 06:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:28:11 --> Input Class Initialized
INFO - 2020-02-09 06:28:11 --> Language Class Initialized
INFO - 2020-02-09 06:28:11 --> Language Class Initialized
INFO - 2020-02-09 06:28:11 --> Config Class Initialized
INFO - 2020-02-09 06:28:11 --> Loader Class Initialized
INFO - 2020-02-09 06:28:11 --> Helper loaded: url_helper
INFO - 2020-02-09 06:28:11 --> Helper loaded: file_helper
INFO - 2020-02-09 06:28:11 --> Helper loaded: form_helper
INFO - 2020-02-09 06:28:11 --> Helper loaded: my_helper
INFO - 2020-02-09 06:28:11 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:28:11 --> Controller Class Initialized
INFO - 2020-02-09 06:28:11 --> Helper loaded: cookie_helper
INFO - 2020-02-09 06:28:11 --> Final output sent to browser
DEBUG - 2020-02-09 06:28:12 --> Total execution time: 0.8294
INFO - 2020-02-09 06:28:12 --> Config Class Initialized
INFO - 2020-02-09 06:28:12 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:28:12 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:28:12 --> Utf8 Class Initialized
INFO - 2020-02-09 06:28:12 --> URI Class Initialized
INFO - 2020-02-09 06:28:12 --> Router Class Initialized
INFO - 2020-02-09 06:28:12 --> Output Class Initialized
INFO - 2020-02-09 06:28:12 --> Security Class Initialized
DEBUG - 2020-02-09 06:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:28:12 --> Input Class Initialized
INFO - 2020-02-09 06:28:12 --> Language Class Initialized
INFO - 2020-02-09 06:28:12 --> Language Class Initialized
INFO - 2020-02-09 06:28:12 --> Config Class Initialized
INFO - 2020-02-09 06:28:12 --> Loader Class Initialized
INFO - 2020-02-09 06:28:12 --> Helper loaded: url_helper
INFO - 2020-02-09 06:28:12 --> Helper loaded: file_helper
INFO - 2020-02-09 06:28:12 --> Helper loaded: form_helper
INFO - 2020-02-09 06:28:12 --> Helper loaded: my_helper
INFO - 2020-02-09 06:28:12 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:28:13 --> Controller Class Initialized
DEBUG - 2020-02-09 06:28:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-09 06:28:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:28:13 --> Final output sent to browser
DEBUG - 2020-02-09 06:28:13 --> Total execution time: 1.1331
INFO - 2020-02-09 06:29:14 --> Config Class Initialized
INFO - 2020-02-09 06:29:14 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:29:14 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:29:14 --> Utf8 Class Initialized
INFO - 2020-02-09 06:29:14 --> URI Class Initialized
INFO - 2020-02-09 06:29:14 --> Router Class Initialized
INFO - 2020-02-09 06:29:14 --> Output Class Initialized
INFO - 2020-02-09 06:29:14 --> Security Class Initialized
DEBUG - 2020-02-09 06:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:29:15 --> Input Class Initialized
INFO - 2020-02-09 06:29:15 --> Language Class Initialized
INFO - 2020-02-09 06:29:15 --> Language Class Initialized
INFO - 2020-02-09 06:29:15 --> Config Class Initialized
INFO - 2020-02-09 06:29:15 --> Loader Class Initialized
INFO - 2020-02-09 06:29:15 --> Helper loaded: url_helper
INFO - 2020-02-09 06:29:15 --> Helper loaded: file_helper
INFO - 2020-02-09 06:29:15 --> Helper loaded: form_helper
INFO - 2020-02-09 06:29:15 --> Helper loaded: my_helper
INFO - 2020-02-09 06:29:15 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:29:15 --> Controller Class Initialized
DEBUG - 2020-02-09 06:29:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-02-09 06:29:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:29:15 --> Final output sent to browser
DEBUG - 2020-02-09 06:29:15 --> Total execution time: 0.8507
INFO - 2020-02-09 06:29:33 --> Config Class Initialized
INFO - 2020-02-09 06:29:33 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:29:33 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:29:33 --> Utf8 Class Initialized
INFO - 2020-02-09 06:29:34 --> URI Class Initialized
INFO - 2020-02-09 06:29:34 --> Router Class Initialized
INFO - 2020-02-09 06:29:34 --> Output Class Initialized
INFO - 2020-02-09 06:29:34 --> Security Class Initialized
DEBUG - 2020-02-09 06:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:29:34 --> Input Class Initialized
INFO - 2020-02-09 06:29:34 --> Language Class Initialized
INFO - 2020-02-09 06:29:34 --> Language Class Initialized
INFO - 2020-02-09 06:29:34 --> Config Class Initialized
INFO - 2020-02-09 06:29:34 --> Loader Class Initialized
INFO - 2020-02-09 06:29:34 --> Helper loaded: url_helper
INFO - 2020-02-09 06:29:34 --> Helper loaded: file_helper
INFO - 2020-02-09 06:29:34 --> Helper loaded: form_helper
INFO - 2020-02-09 06:29:34 --> Helper loaded: my_helper
INFO - 2020-02-09 06:29:34 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:29:34 --> Controller Class Initialized
DEBUG - 2020-02-09 06:29:34 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-02-09 06:29:34 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:29:34 --> Final output sent to browser
DEBUG - 2020-02-09 06:29:34 --> Total execution time: 0.8748
INFO - 2020-02-09 06:29:35 --> Config Class Initialized
INFO - 2020-02-09 06:29:35 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:29:35 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:29:35 --> Utf8 Class Initialized
INFO - 2020-02-09 06:29:35 --> URI Class Initialized
INFO - 2020-02-09 06:29:35 --> Router Class Initialized
INFO - 2020-02-09 06:29:35 --> Output Class Initialized
INFO - 2020-02-09 06:29:35 --> Security Class Initialized
DEBUG - 2020-02-09 06:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:29:35 --> Input Class Initialized
INFO - 2020-02-09 06:29:35 --> Language Class Initialized
INFO - 2020-02-09 06:29:35 --> Language Class Initialized
INFO - 2020-02-09 06:29:35 --> Config Class Initialized
INFO - 2020-02-09 06:29:35 --> Loader Class Initialized
INFO - 2020-02-09 06:29:35 --> Helper loaded: url_helper
INFO - 2020-02-09 06:29:35 --> Helper loaded: file_helper
INFO - 2020-02-09 06:29:35 --> Helper loaded: form_helper
INFO - 2020-02-09 06:29:35 --> Helper loaded: my_helper
INFO - 2020-02-09 06:29:35 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:29:35 --> Controller Class Initialized
INFO - 2020-02-09 06:30:07 --> Config Class Initialized
INFO - 2020-02-09 06:30:07 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:30:07 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:30:07 --> Utf8 Class Initialized
INFO - 2020-02-09 06:30:07 --> URI Class Initialized
INFO - 2020-02-09 06:30:07 --> Router Class Initialized
INFO - 2020-02-09 06:30:07 --> Output Class Initialized
INFO - 2020-02-09 06:30:07 --> Security Class Initialized
DEBUG - 2020-02-09 06:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:30:07 --> Input Class Initialized
INFO - 2020-02-09 06:30:07 --> Language Class Initialized
INFO - 2020-02-09 06:30:07 --> Language Class Initialized
INFO - 2020-02-09 06:30:07 --> Config Class Initialized
INFO - 2020-02-09 06:30:07 --> Loader Class Initialized
INFO - 2020-02-09 06:30:07 --> Helper loaded: url_helper
INFO - 2020-02-09 06:30:07 --> Helper loaded: file_helper
INFO - 2020-02-09 06:30:07 --> Helper loaded: form_helper
INFO - 2020-02-09 06:30:07 --> Helper loaded: my_helper
INFO - 2020-02-09 06:30:07 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:30:07 --> Controller Class Initialized
INFO - 2020-02-09 06:30:07 --> Final output sent to browser
DEBUG - 2020-02-09 06:30:07 --> Total execution time: 0.5987
INFO - 2020-02-09 06:30:10 --> Config Class Initialized
INFO - 2020-02-09 06:30:10 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:30:10 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:30:10 --> Utf8 Class Initialized
INFO - 2020-02-09 06:30:10 --> URI Class Initialized
INFO - 2020-02-09 06:30:10 --> Router Class Initialized
INFO - 2020-02-09 06:30:10 --> Output Class Initialized
INFO - 2020-02-09 06:30:10 --> Security Class Initialized
DEBUG - 2020-02-09 06:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:30:10 --> Input Class Initialized
INFO - 2020-02-09 06:30:10 --> Language Class Initialized
INFO - 2020-02-09 06:30:10 --> Language Class Initialized
INFO - 2020-02-09 06:30:10 --> Config Class Initialized
INFO - 2020-02-09 06:30:11 --> Loader Class Initialized
INFO - 2020-02-09 06:30:11 --> Helper loaded: url_helper
INFO - 2020-02-09 06:30:11 --> Helper loaded: file_helper
INFO - 2020-02-09 06:30:11 --> Helper loaded: form_helper
INFO - 2020-02-09 06:30:11 --> Helper loaded: my_helper
INFO - 2020-02-09 06:30:11 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:30:11 --> Controller Class Initialized
INFO - 2020-02-09 06:30:11 --> Final output sent to browser
DEBUG - 2020-02-09 06:30:11 --> Total execution time: 0.6365
INFO - 2020-02-09 06:30:39 --> Config Class Initialized
INFO - 2020-02-09 06:30:39 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:30:39 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:30:39 --> Utf8 Class Initialized
INFO - 2020-02-09 06:30:39 --> URI Class Initialized
INFO - 2020-02-09 06:30:39 --> Router Class Initialized
INFO - 2020-02-09 06:30:39 --> Output Class Initialized
INFO - 2020-02-09 06:30:39 --> Security Class Initialized
DEBUG - 2020-02-09 06:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:30:39 --> Input Class Initialized
INFO - 2020-02-09 06:30:39 --> Language Class Initialized
INFO - 2020-02-09 06:30:39 --> Language Class Initialized
INFO - 2020-02-09 06:30:39 --> Config Class Initialized
INFO - 2020-02-09 06:30:39 --> Loader Class Initialized
INFO - 2020-02-09 06:30:39 --> Helper loaded: url_helper
INFO - 2020-02-09 06:30:39 --> Helper loaded: file_helper
INFO - 2020-02-09 06:30:39 --> Helper loaded: form_helper
INFO - 2020-02-09 06:30:39 --> Helper loaded: my_helper
INFO - 2020-02-09 06:30:39 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:30:39 --> Controller Class Initialized
INFO - 2020-02-09 06:30:39 --> Final output sent to browser
DEBUG - 2020-02-09 06:30:39 --> Total execution time: 0.5727
INFO - 2020-02-09 06:30:39 --> Config Class Initialized
INFO - 2020-02-09 06:30:39 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:30:39 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:30:39 --> Utf8 Class Initialized
INFO - 2020-02-09 06:30:40 --> URI Class Initialized
INFO - 2020-02-09 06:30:40 --> Router Class Initialized
INFO - 2020-02-09 06:30:40 --> Output Class Initialized
INFO - 2020-02-09 06:30:40 --> Security Class Initialized
DEBUG - 2020-02-09 06:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:30:40 --> Input Class Initialized
INFO - 2020-02-09 06:30:40 --> Language Class Initialized
INFO - 2020-02-09 06:30:40 --> Language Class Initialized
INFO - 2020-02-09 06:30:40 --> Config Class Initialized
INFO - 2020-02-09 06:30:40 --> Loader Class Initialized
INFO - 2020-02-09 06:30:40 --> Helper loaded: url_helper
INFO - 2020-02-09 06:30:40 --> Helper loaded: file_helper
INFO - 2020-02-09 06:30:40 --> Helper loaded: form_helper
INFO - 2020-02-09 06:30:40 --> Helper loaded: my_helper
INFO - 2020-02-09 06:30:40 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:30:41 --> Controller Class Initialized
INFO - 2020-02-09 06:30:48 --> Config Class Initialized
INFO - 2020-02-09 06:30:48 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:30:48 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:30:48 --> Utf8 Class Initialized
INFO - 2020-02-09 06:30:48 --> URI Class Initialized
INFO - 2020-02-09 06:30:48 --> Router Class Initialized
INFO - 2020-02-09 06:30:48 --> Output Class Initialized
INFO - 2020-02-09 06:30:48 --> Security Class Initialized
DEBUG - 2020-02-09 06:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:30:48 --> Input Class Initialized
INFO - 2020-02-09 06:30:48 --> Language Class Initialized
INFO - 2020-02-09 06:30:48 --> Language Class Initialized
INFO - 2020-02-09 06:30:48 --> Config Class Initialized
INFO - 2020-02-09 06:30:48 --> Loader Class Initialized
INFO - 2020-02-09 06:30:48 --> Helper loaded: url_helper
INFO - 2020-02-09 06:30:48 --> Helper loaded: file_helper
INFO - 2020-02-09 06:30:48 --> Helper loaded: form_helper
INFO - 2020-02-09 06:30:48 --> Helper loaded: my_helper
INFO - 2020-02-09 06:30:48 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:30:48 --> Controller Class Initialized
INFO - 2020-02-09 06:30:48 --> Final output sent to browser
DEBUG - 2020-02-09 06:30:48 --> Total execution time: 0.7287
INFO - 2020-02-09 06:30:54 --> Config Class Initialized
INFO - 2020-02-09 06:30:54 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:30:54 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:30:54 --> Utf8 Class Initialized
INFO - 2020-02-09 06:30:54 --> URI Class Initialized
INFO - 2020-02-09 06:30:54 --> Router Class Initialized
INFO - 2020-02-09 06:30:54 --> Output Class Initialized
INFO - 2020-02-09 06:30:54 --> Security Class Initialized
DEBUG - 2020-02-09 06:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:30:54 --> Input Class Initialized
INFO - 2020-02-09 06:30:54 --> Language Class Initialized
INFO - 2020-02-09 06:30:54 --> Language Class Initialized
INFO - 2020-02-09 06:30:54 --> Config Class Initialized
INFO - 2020-02-09 06:30:54 --> Loader Class Initialized
INFO - 2020-02-09 06:30:54 --> Helper loaded: url_helper
INFO - 2020-02-09 06:30:54 --> Helper loaded: file_helper
INFO - 2020-02-09 06:30:54 --> Helper loaded: form_helper
INFO - 2020-02-09 06:30:54 --> Helper loaded: my_helper
INFO - 2020-02-09 06:30:54 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:30:54 --> Controller Class Initialized
INFO - 2020-02-09 06:30:54 --> Final output sent to browser
DEBUG - 2020-02-09 06:30:54 --> Total execution time: 0.5469
INFO - 2020-02-09 06:30:54 --> Config Class Initialized
INFO - 2020-02-09 06:30:54 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:30:54 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:30:55 --> Utf8 Class Initialized
INFO - 2020-02-09 06:30:55 --> URI Class Initialized
INFO - 2020-02-09 06:30:55 --> Router Class Initialized
INFO - 2020-02-09 06:30:55 --> Output Class Initialized
INFO - 2020-02-09 06:30:55 --> Security Class Initialized
DEBUG - 2020-02-09 06:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:30:55 --> Input Class Initialized
INFO - 2020-02-09 06:30:55 --> Language Class Initialized
INFO - 2020-02-09 06:30:55 --> Language Class Initialized
INFO - 2020-02-09 06:30:55 --> Config Class Initialized
INFO - 2020-02-09 06:30:55 --> Loader Class Initialized
INFO - 2020-02-09 06:30:55 --> Helper loaded: url_helper
INFO - 2020-02-09 06:30:55 --> Helper loaded: file_helper
INFO - 2020-02-09 06:30:55 --> Helper loaded: form_helper
INFO - 2020-02-09 06:30:55 --> Helper loaded: my_helper
INFO - 2020-02-09 06:30:55 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:30:56 --> Controller Class Initialized
INFO - 2020-02-09 06:31:13 --> Config Class Initialized
INFO - 2020-02-09 06:31:13 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:31:13 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:31:13 --> Utf8 Class Initialized
INFO - 2020-02-09 06:31:13 --> URI Class Initialized
INFO - 2020-02-09 06:31:13 --> Router Class Initialized
INFO - 2020-02-09 06:31:13 --> Output Class Initialized
INFO - 2020-02-09 06:31:13 --> Security Class Initialized
DEBUG - 2020-02-09 06:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:31:13 --> Input Class Initialized
INFO - 2020-02-09 06:31:13 --> Language Class Initialized
INFO - 2020-02-09 06:31:13 --> Language Class Initialized
INFO - 2020-02-09 06:31:13 --> Config Class Initialized
INFO - 2020-02-09 06:31:13 --> Loader Class Initialized
INFO - 2020-02-09 06:31:13 --> Helper loaded: url_helper
INFO - 2020-02-09 06:31:13 --> Helper loaded: file_helper
INFO - 2020-02-09 06:31:13 --> Helper loaded: form_helper
INFO - 2020-02-09 06:31:13 --> Helper loaded: my_helper
INFO - 2020-02-09 06:31:13 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:31:14 --> Controller Class Initialized
INFO - 2020-02-09 06:31:14 --> Final output sent to browser
DEBUG - 2020-02-09 06:31:14 --> Total execution time: 0.5145
INFO - 2020-02-09 06:31:35 --> Config Class Initialized
INFO - 2020-02-09 06:31:35 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:31:35 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:31:35 --> Utf8 Class Initialized
INFO - 2020-02-09 06:31:35 --> URI Class Initialized
INFO - 2020-02-09 06:31:35 --> Router Class Initialized
INFO - 2020-02-09 06:31:35 --> Output Class Initialized
INFO - 2020-02-09 06:31:35 --> Security Class Initialized
DEBUG - 2020-02-09 06:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:31:35 --> Input Class Initialized
INFO - 2020-02-09 06:31:35 --> Language Class Initialized
INFO - 2020-02-09 06:31:35 --> Language Class Initialized
INFO - 2020-02-09 06:31:35 --> Config Class Initialized
INFO - 2020-02-09 06:31:35 --> Loader Class Initialized
INFO - 2020-02-09 06:31:35 --> Helper loaded: url_helper
INFO - 2020-02-09 06:31:35 --> Helper loaded: file_helper
INFO - 2020-02-09 06:31:35 --> Helper loaded: form_helper
INFO - 2020-02-09 06:31:35 --> Helper loaded: my_helper
INFO - 2020-02-09 06:31:35 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:31:35 --> Controller Class Initialized
INFO - 2020-02-09 06:32:36 --> Config Class Initialized
INFO - 2020-02-09 06:32:36 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:32:36 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:32:36 --> Utf8 Class Initialized
INFO - 2020-02-09 06:32:36 --> URI Class Initialized
INFO - 2020-02-09 06:32:36 --> Router Class Initialized
INFO - 2020-02-09 06:32:36 --> Output Class Initialized
INFO - 2020-02-09 06:32:36 --> Security Class Initialized
DEBUG - 2020-02-09 06:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:32:36 --> Input Class Initialized
INFO - 2020-02-09 06:32:36 --> Language Class Initialized
INFO - 2020-02-09 06:32:36 --> Language Class Initialized
INFO - 2020-02-09 06:32:36 --> Config Class Initialized
INFO - 2020-02-09 06:32:36 --> Loader Class Initialized
INFO - 2020-02-09 06:32:36 --> Helper loaded: url_helper
INFO - 2020-02-09 06:32:36 --> Helper loaded: file_helper
INFO - 2020-02-09 06:32:36 --> Helper loaded: form_helper
INFO - 2020-02-09 06:32:36 --> Helper loaded: my_helper
INFO - 2020-02-09 06:32:36 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:32:36 --> Controller Class Initialized
DEBUG - 2020-02-09 06:32:36 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_pengetahuan/views/form.php
DEBUG - 2020-02-09 06:32:36 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:32:36 --> Final output sent to browser
DEBUG - 2020-02-09 06:32:36 --> Total execution time: 0.8335
INFO - 2020-02-09 06:32:54 --> Config Class Initialized
INFO - 2020-02-09 06:32:54 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:32:54 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:32:54 --> Utf8 Class Initialized
INFO - 2020-02-09 06:32:54 --> URI Class Initialized
INFO - 2020-02-09 06:32:55 --> Router Class Initialized
INFO - 2020-02-09 06:32:55 --> Output Class Initialized
INFO - 2020-02-09 06:32:55 --> Security Class Initialized
DEBUG - 2020-02-09 06:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:32:55 --> Input Class Initialized
INFO - 2020-02-09 06:32:55 --> Language Class Initialized
INFO - 2020-02-09 06:32:55 --> Language Class Initialized
INFO - 2020-02-09 06:32:55 --> Config Class Initialized
INFO - 2020-02-09 06:32:55 --> Loader Class Initialized
INFO - 2020-02-09 06:32:55 --> Helper loaded: url_helper
INFO - 2020-02-09 06:32:55 --> Helper loaded: file_helper
INFO - 2020-02-09 06:32:55 --> Helper loaded: form_helper
INFO - 2020-02-09 06:32:55 --> Helper loaded: my_helper
INFO - 2020-02-09 06:32:55 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:32:55 --> Controller Class Initialized
INFO - 2020-02-09 06:32:55 --> Config Class Initialized
INFO - 2020-02-09 06:32:55 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:32:55 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:32:56 --> Utf8 Class Initialized
INFO - 2020-02-09 06:32:56 --> URI Class Initialized
INFO - 2020-02-09 06:32:56 --> Router Class Initialized
INFO - 2020-02-09 06:32:56 --> Output Class Initialized
INFO - 2020-02-09 06:32:56 --> Security Class Initialized
DEBUG - 2020-02-09 06:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:32:56 --> Input Class Initialized
INFO - 2020-02-09 06:32:56 --> Language Class Initialized
INFO - 2020-02-09 06:32:56 --> Language Class Initialized
INFO - 2020-02-09 06:32:56 --> Config Class Initialized
INFO - 2020-02-09 06:32:56 --> Loader Class Initialized
INFO - 2020-02-09 06:32:56 --> Helper loaded: url_helper
INFO - 2020-02-09 06:32:56 --> Helper loaded: file_helper
INFO - 2020-02-09 06:32:56 --> Helper loaded: form_helper
INFO - 2020-02-09 06:32:56 --> Helper loaded: my_helper
INFO - 2020-02-09 06:32:56 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:32:56 --> Controller Class Initialized
DEBUG - 2020-02-09 06:32:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-02-09 06:32:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:32:56 --> Final output sent to browser
DEBUG - 2020-02-09 06:32:56 --> Total execution time: 0.6627
INFO - 2020-02-09 06:32:56 --> Config Class Initialized
INFO - 2020-02-09 06:32:56 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:32:57 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:32:57 --> Utf8 Class Initialized
INFO - 2020-02-09 06:32:57 --> URI Class Initialized
INFO - 2020-02-09 06:32:57 --> Router Class Initialized
INFO - 2020-02-09 06:32:57 --> Output Class Initialized
INFO - 2020-02-09 06:32:57 --> Security Class Initialized
DEBUG - 2020-02-09 06:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:32:57 --> Input Class Initialized
INFO - 2020-02-09 06:32:57 --> Language Class Initialized
INFO - 2020-02-09 06:32:57 --> Language Class Initialized
INFO - 2020-02-09 06:32:57 --> Config Class Initialized
INFO - 2020-02-09 06:32:57 --> Loader Class Initialized
INFO - 2020-02-09 06:32:57 --> Helper loaded: url_helper
INFO - 2020-02-09 06:32:57 --> Helper loaded: file_helper
INFO - 2020-02-09 06:32:57 --> Helper loaded: form_helper
INFO - 2020-02-09 06:32:57 --> Helper loaded: my_helper
INFO - 2020-02-09 06:32:57 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:32:57 --> Controller Class Initialized
INFO - 2020-02-09 06:33:05 --> Config Class Initialized
INFO - 2020-02-09 06:33:05 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:33:05 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:33:05 --> Utf8 Class Initialized
INFO - 2020-02-09 06:33:05 --> URI Class Initialized
INFO - 2020-02-09 06:33:05 --> Router Class Initialized
INFO - 2020-02-09 06:33:05 --> Output Class Initialized
INFO - 2020-02-09 06:33:05 --> Security Class Initialized
DEBUG - 2020-02-09 06:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:33:05 --> Input Class Initialized
INFO - 2020-02-09 06:33:05 --> Language Class Initialized
INFO - 2020-02-09 06:33:05 --> Language Class Initialized
INFO - 2020-02-09 06:33:06 --> Config Class Initialized
INFO - 2020-02-09 06:33:06 --> Loader Class Initialized
INFO - 2020-02-09 06:33:06 --> Helper loaded: url_helper
INFO - 2020-02-09 06:33:06 --> Helper loaded: file_helper
INFO - 2020-02-09 06:33:06 --> Helper loaded: form_helper
INFO - 2020-02-09 06:33:06 --> Helper loaded: my_helper
INFO - 2020-02-09 06:33:06 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:33:06 --> Controller Class Initialized
INFO - 2020-02-09 06:33:06 --> Final output sent to browser
DEBUG - 2020-02-09 06:33:06 --> Total execution time: 0.5515
INFO - 2020-02-09 06:33:13 --> Config Class Initialized
INFO - 2020-02-09 06:33:13 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:33:13 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:33:13 --> Utf8 Class Initialized
INFO - 2020-02-09 06:33:13 --> URI Class Initialized
INFO - 2020-02-09 06:33:13 --> Router Class Initialized
INFO - 2020-02-09 06:33:13 --> Output Class Initialized
INFO - 2020-02-09 06:33:13 --> Security Class Initialized
DEBUG - 2020-02-09 06:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:33:13 --> Input Class Initialized
INFO - 2020-02-09 06:33:13 --> Language Class Initialized
INFO - 2020-02-09 06:33:13 --> Language Class Initialized
INFO - 2020-02-09 06:33:13 --> Config Class Initialized
INFO - 2020-02-09 06:33:13 --> Loader Class Initialized
INFO - 2020-02-09 06:33:13 --> Helper loaded: url_helper
INFO - 2020-02-09 06:33:13 --> Helper loaded: file_helper
INFO - 2020-02-09 06:33:13 --> Helper loaded: form_helper
INFO - 2020-02-09 06:33:13 --> Helper loaded: my_helper
INFO - 2020-02-09 06:33:13 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:33:13 --> Controller Class Initialized
INFO - 2020-02-09 06:33:13 --> Final output sent to browser
DEBUG - 2020-02-09 06:33:13 --> Total execution time: 0.5514
INFO - 2020-02-09 06:33:21 --> Config Class Initialized
INFO - 2020-02-09 06:33:21 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:33:21 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:33:21 --> Utf8 Class Initialized
INFO - 2020-02-09 06:33:22 --> URI Class Initialized
INFO - 2020-02-09 06:33:22 --> Router Class Initialized
INFO - 2020-02-09 06:33:22 --> Output Class Initialized
INFO - 2020-02-09 06:33:22 --> Security Class Initialized
DEBUG - 2020-02-09 06:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:33:22 --> Input Class Initialized
INFO - 2020-02-09 06:33:22 --> Language Class Initialized
INFO - 2020-02-09 06:33:22 --> Language Class Initialized
INFO - 2020-02-09 06:33:22 --> Config Class Initialized
INFO - 2020-02-09 06:33:22 --> Loader Class Initialized
INFO - 2020-02-09 06:33:22 --> Helper loaded: url_helper
INFO - 2020-02-09 06:33:22 --> Helper loaded: file_helper
INFO - 2020-02-09 06:33:22 --> Helper loaded: form_helper
INFO - 2020-02-09 06:33:22 --> Helper loaded: my_helper
INFO - 2020-02-09 06:33:22 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:33:22 --> Controller Class Initialized
INFO - 2020-02-09 06:33:22 --> Final output sent to browser
DEBUG - 2020-02-09 06:33:22 --> Total execution time: 0.5690
INFO - 2020-02-09 06:33:24 --> Config Class Initialized
INFO - 2020-02-09 06:33:25 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:33:25 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:33:25 --> Utf8 Class Initialized
INFO - 2020-02-09 06:33:25 --> URI Class Initialized
INFO - 2020-02-09 06:33:25 --> Router Class Initialized
INFO - 2020-02-09 06:33:25 --> Output Class Initialized
INFO - 2020-02-09 06:33:25 --> Security Class Initialized
DEBUG - 2020-02-09 06:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:33:25 --> Input Class Initialized
INFO - 2020-02-09 06:33:25 --> Language Class Initialized
INFO - 2020-02-09 06:33:25 --> Language Class Initialized
INFO - 2020-02-09 06:33:25 --> Config Class Initialized
INFO - 2020-02-09 06:33:25 --> Loader Class Initialized
INFO - 2020-02-09 06:33:25 --> Helper loaded: url_helper
INFO - 2020-02-09 06:33:25 --> Helper loaded: file_helper
INFO - 2020-02-09 06:33:25 --> Helper loaded: form_helper
INFO - 2020-02-09 06:33:25 --> Helper loaded: my_helper
INFO - 2020-02-09 06:33:25 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:33:25 --> Controller Class Initialized
INFO - 2020-02-09 06:33:25 --> Final output sent to browser
DEBUG - 2020-02-09 06:33:25 --> Total execution time: 0.7051
INFO - 2020-02-09 06:33:38 --> Config Class Initialized
INFO - 2020-02-09 06:33:38 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:33:38 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:33:38 --> Utf8 Class Initialized
INFO - 2020-02-09 06:33:38 --> URI Class Initialized
INFO - 2020-02-09 06:33:38 --> Router Class Initialized
INFO - 2020-02-09 06:33:38 --> Output Class Initialized
INFO - 2020-02-09 06:33:39 --> Security Class Initialized
DEBUG - 2020-02-09 06:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:33:39 --> Input Class Initialized
INFO - 2020-02-09 06:33:39 --> Language Class Initialized
INFO - 2020-02-09 06:33:39 --> Language Class Initialized
INFO - 2020-02-09 06:33:39 --> Config Class Initialized
INFO - 2020-02-09 06:33:39 --> Loader Class Initialized
INFO - 2020-02-09 06:33:39 --> Helper loaded: url_helper
INFO - 2020-02-09 06:33:39 --> Helper loaded: file_helper
INFO - 2020-02-09 06:33:39 --> Helper loaded: form_helper
INFO - 2020-02-09 06:33:39 --> Helper loaded: my_helper
INFO - 2020-02-09 06:33:39 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:33:39 --> Controller Class Initialized
DEBUG - 2020-02-09 06:33:39 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-02-09 06:33:39 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:33:39 --> Final output sent to browser
DEBUG - 2020-02-09 06:33:39 --> Total execution time: 0.8569
INFO - 2020-02-09 06:33:40 --> Config Class Initialized
INFO - 2020-02-09 06:33:40 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:33:40 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:33:40 --> Utf8 Class Initialized
INFO - 2020-02-09 06:33:40 --> URI Class Initialized
INFO - 2020-02-09 06:33:40 --> Router Class Initialized
INFO - 2020-02-09 06:33:40 --> Output Class Initialized
INFO - 2020-02-09 06:33:40 --> Security Class Initialized
DEBUG - 2020-02-09 06:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:33:41 --> Input Class Initialized
INFO - 2020-02-09 06:33:41 --> Language Class Initialized
INFO - 2020-02-09 06:33:41 --> Language Class Initialized
INFO - 2020-02-09 06:33:41 --> Config Class Initialized
INFO - 2020-02-09 06:33:41 --> Loader Class Initialized
INFO - 2020-02-09 06:33:41 --> Helper loaded: url_helper
INFO - 2020-02-09 06:33:41 --> Helper loaded: file_helper
INFO - 2020-02-09 06:33:41 --> Helper loaded: form_helper
INFO - 2020-02-09 06:33:41 --> Helper loaded: my_helper
INFO - 2020-02-09 06:33:41 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:33:41 --> Controller Class Initialized
DEBUG - 2020-02-09 06:33:41 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-02-09 06:33:41 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:33:41 --> Final output sent to browser
DEBUG - 2020-02-09 06:33:41 --> Total execution time: 0.8532
INFO - 2020-02-09 06:33:43 --> Config Class Initialized
INFO - 2020-02-09 06:33:43 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:33:44 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:33:44 --> Utf8 Class Initialized
INFO - 2020-02-09 06:33:44 --> URI Class Initialized
INFO - 2020-02-09 06:33:44 --> Router Class Initialized
INFO - 2020-02-09 06:33:44 --> Output Class Initialized
INFO - 2020-02-09 06:33:44 --> Security Class Initialized
DEBUG - 2020-02-09 06:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:33:44 --> Input Class Initialized
INFO - 2020-02-09 06:33:44 --> Language Class Initialized
INFO - 2020-02-09 06:33:44 --> Language Class Initialized
INFO - 2020-02-09 06:33:44 --> Config Class Initialized
INFO - 2020-02-09 06:33:44 --> Loader Class Initialized
INFO - 2020-02-09 06:33:44 --> Helper loaded: url_helper
INFO - 2020-02-09 06:33:44 --> Helper loaded: file_helper
INFO - 2020-02-09 06:33:44 --> Helper loaded: form_helper
INFO - 2020-02-09 06:33:44 --> Helper loaded: my_helper
INFO - 2020-02-09 06:33:44 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:33:44 --> Controller Class Initialized
INFO - 2020-02-09 06:33:44 --> Final output sent to browser
DEBUG - 2020-02-09 06:33:44 --> Total execution time: 0.6941
INFO - 2020-02-09 06:34:01 --> Config Class Initialized
INFO - 2020-02-09 06:34:01 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:34:01 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:34:01 --> Utf8 Class Initialized
INFO - 2020-02-09 06:34:01 --> URI Class Initialized
INFO - 2020-02-09 06:34:01 --> Router Class Initialized
INFO - 2020-02-09 06:34:01 --> Output Class Initialized
INFO - 2020-02-09 06:34:01 --> Security Class Initialized
DEBUG - 2020-02-09 06:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:34:01 --> Input Class Initialized
INFO - 2020-02-09 06:34:01 --> Language Class Initialized
INFO - 2020-02-09 06:34:01 --> Language Class Initialized
INFO - 2020-02-09 06:34:01 --> Config Class Initialized
INFO - 2020-02-09 06:34:01 --> Loader Class Initialized
INFO - 2020-02-09 06:34:01 --> Helper loaded: url_helper
INFO - 2020-02-09 06:34:01 --> Helper loaded: file_helper
INFO - 2020-02-09 06:34:01 --> Helper loaded: form_helper
INFO - 2020-02-09 06:34:01 --> Helper loaded: my_helper
INFO - 2020-02-09 06:34:01 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:34:01 --> Controller Class Initialized
INFO - 2020-02-09 06:34:01 --> Final output sent to browser
DEBUG - 2020-02-09 06:34:01 --> Total execution time: 0.6854
INFO - 2020-02-09 06:34:01 --> Config Class Initialized
INFO - 2020-02-09 06:34:02 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:34:02 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:34:02 --> Utf8 Class Initialized
INFO - 2020-02-09 06:34:02 --> URI Class Initialized
INFO - 2020-02-09 06:34:02 --> Router Class Initialized
INFO - 2020-02-09 06:34:02 --> Output Class Initialized
INFO - 2020-02-09 06:34:02 --> Security Class Initialized
DEBUG - 2020-02-09 06:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:34:02 --> Input Class Initialized
INFO - 2020-02-09 06:34:02 --> Language Class Initialized
INFO - 2020-02-09 06:34:02 --> Language Class Initialized
INFO - 2020-02-09 06:34:02 --> Config Class Initialized
INFO - 2020-02-09 06:34:02 --> Loader Class Initialized
INFO - 2020-02-09 06:34:02 --> Helper loaded: url_helper
INFO - 2020-02-09 06:34:02 --> Helper loaded: file_helper
INFO - 2020-02-09 06:34:02 --> Helper loaded: form_helper
INFO - 2020-02-09 06:34:02 --> Helper loaded: my_helper
INFO - 2020-02-09 06:34:02 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:34:02 --> Controller Class Initialized
DEBUG - 2020-02-09 06:34:02 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-02-09 06:34:03 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:34:03 --> Final output sent to browser
DEBUG - 2020-02-09 06:34:03 --> Total execution time: 1.0773
INFO - 2020-02-09 06:34:04 --> Config Class Initialized
INFO - 2020-02-09 06:34:04 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:34:04 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:34:04 --> Utf8 Class Initialized
INFO - 2020-02-09 06:34:04 --> URI Class Initialized
INFO - 2020-02-09 06:34:05 --> Router Class Initialized
INFO - 2020-02-09 06:34:05 --> Output Class Initialized
INFO - 2020-02-09 06:34:05 --> Security Class Initialized
DEBUG - 2020-02-09 06:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:34:05 --> Input Class Initialized
INFO - 2020-02-09 06:34:05 --> Language Class Initialized
INFO - 2020-02-09 06:34:05 --> Language Class Initialized
INFO - 2020-02-09 06:34:05 --> Config Class Initialized
INFO - 2020-02-09 06:34:05 --> Loader Class Initialized
INFO - 2020-02-09 06:34:05 --> Helper loaded: url_helper
INFO - 2020-02-09 06:34:05 --> Helper loaded: file_helper
INFO - 2020-02-09 06:34:05 --> Helper loaded: form_helper
INFO - 2020-02-09 06:34:05 --> Helper loaded: my_helper
INFO - 2020-02-09 06:34:05 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:34:05 --> Controller Class Initialized
INFO - 2020-02-09 06:34:05 --> Final output sent to browser
DEBUG - 2020-02-09 06:34:05 --> Total execution time: 1.1280
INFO - 2020-02-09 06:34:12 --> Config Class Initialized
INFO - 2020-02-09 06:34:12 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:34:12 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:34:12 --> Utf8 Class Initialized
INFO - 2020-02-09 06:34:12 --> URI Class Initialized
INFO - 2020-02-09 06:34:12 --> Router Class Initialized
INFO - 2020-02-09 06:34:12 --> Output Class Initialized
INFO - 2020-02-09 06:34:12 --> Security Class Initialized
DEBUG - 2020-02-09 06:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:34:12 --> Input Class Initialized
INFO - 2020-02-09 06:34:12 --> Language Class Initialized
INFO - 2020-02-09 06:34:12 --> Language Class Initialized
INFO - 2020-02-09 06:34:12 --> Config Class Initialized
INFO - 2020-02-09 06:34:12 --> Loader Class Initialized
INFO - 2020-02-09 06:34:12 --> Helper loaded: url_helper
INFO - 2020-02-09 06:34:12 --> Helper loaded: file_helper
INFO - 2020-02-09 06:34:12 --> Helper loaded: form_helper
INFO - 2020-02-09 06:34:12 --> Helper loaded: my_helper
INFO - 2020-02-09 06:34:12 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:34:13 --> Controller Class Initialized
INFO - 2020-02-09 06:34:13 --> Final output sent to browser
DEBUG - 2020-02-09 06:34:13 --> Total execution time: 0.6201
INFO - 2020-02-09 06:34:13 --> Config Class Initialized
INFO - 2020-02-09 06:34:13 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:34:13 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:34:13 --> Utf8 Class Initialized
INFO - 2020-02-09 06:34:13 --> URI Class Initialized
INFO - 2020-02-09 06:34:13 --> Router Class Initialized
INFO - 2020-02-09 06:34:13 --> Output Class Initialized
INFO - 2020-02-09 06:34:13 --> Security Class Initialized
DEBUG - 2020-02-09 06:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:34:13 --> Input Class Initialized
INFO - 2020-02-09 06:34:13 --> Language Class Initialized
INFO - 2020-02-09 06:34:13 --> Language Class Initialized
INFO - 2020-02-09 06:34:13 --> Config Class Initialized
INFO - 2020-02-09 06:34:13 --> Loader Class Initialized
INFO - 2020-02-09 06:34:13 --> Helper loaded: url_helper
INFO - 2020-02-09 06:34:13 --> Helper loaded: file_helper
INFO - 2020-02-09 06:34:14 --> Helper loaded: form_helper
INFO - 2020-02-09 06:34:14 --> Helper loaded: my_helper
INFO - 2020-02-09 06:34:14 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:34:14 --> Controller Class Initialized
DEBUG - 2020-02-09 06:34:14 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-02-09 06:34:14 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:34:14 --> Final output sent to browser
DEBUG - 2020-02-09 06:34:14 --> Total execution time: 1.0638
INFO - 2020-02-09 06:34:15 --> Config Class Initialized
INFO - 2020-02-09 06:34:15 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:34:15 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:34:15 --> Utf8 Class Initialized
INFO - 2020-02-09 06:34:15 --> URI Class Initialized
INFO - 2020-02-09 06:34:15 --> Router Class Initialized
INFO - 2020-02-09 06:34:15 --> Output Class Initialized
INFO - 2020-02-09 06:34:15 --> Security Class Initialized
DEBUG - 2020-02-09 06:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:34:15 --> Input Class Initialized
INFO - 2020-02-09 06:34:15 --> Language Class Initialized
INFO - 2020-02-09 06:34:15 --> Language Class Initialized
INFO - 2020-02-09 06:34:15 --> Config Class Initialized
INFO - 2020-02-09 06:34:15 --> Loader Class Initialized
INFO - 2020-02-09 06:34:15 --> Helper loaded: url_helper
INFO - 2020-02-09 06:34:15 --> Helper loaded: file_helper
INFO - 2020-02-09 06:34:15 --> Helper loaded: form_helper
INFO - 2020-02-09 06:34:15 --> Helper loaded: my_helper
INFO - 2020-02-09 06:34:15 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:34:15 --> Controller Class Initialized
INFO - 2020-02-09 06:34:15 --> Final output sent to browser
DEBUG - 2020-02-09 06:34:15 --> Total execution time: 0.6460
INFO - 2020-02-09 06:34:30 --> Config Class Initialized
INFO - 2020-02-09 06:34:30 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:34:30 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:34:30 --> Utf8 Class Initialized
INFO - 2020-02-09 06:34:30 --> URI Class Initialized
INFO - 2020-02-09 06:34:30 --> Router Class Initialized
INFO - 2020-02-09 06:34:30 --> Output Class Initialized
INFO - 2020-02-09 06:34:30 --> Security Class Initialized
DEBUG - 2020-02-09 06:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:34:30 --> Input Class Initialized
INFO - 2020-02-09 06:34:30 --> Language Class Initialized
INFO - 2020-02-09 06:34:30 --> Language Class Initialized
INFO - 2020-02-09 06:34:30 --> Config Class Initialized
INFO - 2020-02-09 06:34:30 --> Loader Class Initialized
INFO - 2020-02-09 06:34:30 --> Helper loaded: url_helper
INFO - 2020-02-09 06:34:30 --> Helper loaded: file_helper
INFO - 2020-02-09 06:34:30 --> Helper loaded: form_helper
INFO - 2020-02-09 06:34:30 --> Helper loaded: my_helper
INFO - 2020-02-09 06:34:30 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:34:31 --> Controller Class Initialized
INFO - 2020-02-09 06:34:31 --> Final output sent to browser
DEBUG - 2020-02-09 06:34:31 --> Total execution time: 0.7714
INFO - 2020-02-09 06:34:38 --> Config Class Initialized
INFO - 2020-02-09 06:34:38 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:34:38 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:34:38 --> Utf8 Class Initialized
INFO - 2020-02-09 06:34:38 --> URI Class Initialized
INFO - 2020-02-09 06:34:38 --> Router Class Initialized
INFO - 2020-02-09 06:34:38 --> Output Class Initialized
INFO - 2020-02-09 06:34:38 --> Security Class Initialized
DEBUG - 2020-02-09 06:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:34:38 --> Input Class Initialized
INFO - 2020-02-09 06:34:38 --> Language Class Initialized
INFO - 2020-02-09 06:34:38 --> Language Class Initialized
INFO - 2020-02-09 06:34:38 --> Config Class Initialized
INFO - 2020-02-09 06:34:38 --> Loader Class Initialized
INFO - 2020-02-09 06:34:38 --> Helper loaded: url_helper
INFO - 2020-02-09 06:34:38 --> Helper loaded: file_helper
INFO - 2020-02-09 06:34:38 --> Helper loaded: form_helper
INFO - 2020-02-09 06:34:38 --> Helper loaded: my_helper
INFO - 2020-02-09 06:34:38 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:34:39 --> Controller Class Initialized
INFO - 2020-02-09 06:34:39 --> Final output sent to browser
DEBUG - 2020-02-09 06:34:39 --> Total execution time: 0.7094
INFO - 2020-02-09 06:34:47 --> Config Class Initialized
INFO - 2020-02-09 06:34:47 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:34:47 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:34:47 --> Utf8 Class Initialized
INFO - 2020-02-09 06:34:47 --> URI Class Initialized
INFO - 2020-02-09 06:34:47 --> Router Class Initialized
INFO - 2020-02-09 06:34:47 --> Output Class Initialized
INFO - 2020-02-09 06:34:47 --> Security Class Initialized
DEBUG - 2020-02-09 06:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:34:47 --> Input Class Initialized
INFO - 2020-02-09 06:34:47 --> Language Class Initialized
INFO - 2020-02-09 06:34:47 --> Language Class Initialized
INFO - 2020-02-09 06:34:48 --> Config Class Initialized
INFO - 2020-02-09 06:34:48 --> Loader Class Initialized
INFO - 2020-02-09 06:34:48 --> Helper loaded: url_helper
INFO - 2020-02-09 06:34:48 --> Helper loaded: file_helper
INFO - 2020-02-09 06:34:48 --> Helper loaded: form_helper
INFO - 2020-02-09 06:34:48 --> Helper loaded: my_helper
INFO - 2020-02-09 06:34:48 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:34:48 --> Controller Class Initialized
INFO - 2020-02-09 06:34:48 --> Final output sent to browser
DEBUG - 2020-02-09 06:34:48 --> Total execution time: 0.8350
INFO - 2020-02-09 06:34:55 --> Config Class Initialized
INFO - 2020-02-09 06:34:55 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:34:55 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:34:55 --> Utf8 Class Initialized
INFO - 2020-02-09 06:34:55 --> URI Class Initialized
INFO - 2020-02-09 06:34:55 --> Router Class Initialized
INFO - 2020-02-09 06:34:55 --> Output Class Initialized
INFO - 2020-02-09 06:34:55 --> Security Class Initialized
DEBUG - 2020-02-09 06:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:34:55 --> Input Class Initialized
INFO - 2020-02-09 06:34:55 --> Language Class Initialized
INFO - 2020-02-09 06:34:55 --> Language Class Initialized
INFO - 2020-02-09 06:34:55 --> Config Class Initialized
INFO - 2020-02-09 06:34:55 --> Loader Class Initialized
INFO - 2020-02-09 06:34:55 --> Helper loaded: url_helper
INFO - 2020-02-09 06:34:55 --> Helper loaded: file_helper
INFO - 2020-02-09 06:34:56 --> Helper loaded: form_helper
INFO - 2020-02-09 06:34:56 --> Helper loaded: my_helper
INFO - 2020-02-09 06:34:56 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:34:56 --> Controller Class Initialized
DEBUG - 2020-02-09 06:34:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-02-09 06:34:56 --> Final output sent to browser
DEBUG - 2020-02-09 06:34:56 --> Total execution time: 1.4695
INFO - 2020-02-09 06:35:22 --> Config Class Initialized
INFO - 2020-02-09 06:35:22 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:35:22 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:35:22 --> Utf8 Class Initialized
INFO - 2020-02-09 06:35:22 --> URI Class Initialized
INFO - 2020-02-09 06:35:22 --> Router Class Initialized
INFO - 2020-02-09 06:35:22 --> Output Class Initialized
INFO - 2020-02-09 06:35:22 --> Security Class Initialized
DEBUG - 2020-02-09 06:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:35:22 --> Input Class Initialized
INFO - 2020-02-09 06:35:23 --> Language Class Initialized
INFO - 2020-02-09 06:35:23 --> Language Class Initialized
INFO - 2020-02-09 06:35:23 --> Config Class Initialized
INFO - 2020-02-09 06:35:23 --> Loader Class Initialized
INFO - 2020-02-09 06:35:23 --> Helper loaded: url_helper
INFO - 2020-02-09 06:35:23 --> Helper loaded: file_helper
INFO - 2020-02-09 06:35:23 --> Helper loaded: form_helper
INFO - 2020-02-09 06:35:23 --> Helper loaded: my_helper
INFO - 2020-02-09 06:35:23 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:35:23 --> Controller Class Initialized
DEBUG - 2020-02-09 06:35:23 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-02-09 06:35:23 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:35:23 --> Final output sent to browser
DEBUG - 2020-02-09 06:35:23 --> Total execution time: 0.8255
INFO - 2020-02-09 06:35:24 --> Config Class Initialized
INFO - 2020-02-09 06:35:24 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:35:24 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:35:24 --> Utf8 Class Initialized
INFO - 2020-02-09 06:35:24 --> URI Class Initialized
INFO - 2020-02-09 06:35:24 --> Router Class Initialized
INFO - 2020-02-09 06:35:24 --> Output Class Initialized
INFO - 2020-02-09 06:35:24 --> Security Class Initialized
DEBUG - 2020-02-09 06:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:35:24 --> Input Class Initialized
INFO - 2020-02-09 06:35:24 --> Language Class Initialized
INFO - 2020-02-09 06:35:24 --> Language Class Initialized
INFO - 2020-02-09 06:35:24 --> Config Class Initialized
INFO - 2020-02-09 06:35:24 --> Loader Class Initialized
INFO - 2020-02-09 06:35:24 --> Helper loaded: url_helper
INFO - 2020-02-09 06:35:24 --> Helper loaded: file_helper
INFO - 2020-02-09 06:35:25 --> Helper loaded: form_helper
INFO - 2020-02-09 06:35:25 --> Helper loaded: my_helper
INFO - 2020-02-09 06:35:25 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:35:25 --> Controller Class Initialized
DEBUG - 2020-02-09 06:35:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-02-09 06:35:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:35:25 --> Final output sent to browser
DEBUG - 2020-02-09 06:35:25 --> Total execution time: 0.7837
INFO - 2020-02-09 06:35:25 --> Config Class Initialized
INFO - 2020-02-09 06:35:25 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:35:25 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:35:25 --> Utf8 Class Initialized
INFO - 2020-02-09 06:35:25 --> URI Class Initialized
INFO - 2020-02-09 06:35:25 --> Router Class Initialized
INFO - 2020-02-09 06:35:26 --> Output Class Initialized
INFO - 2020-02-09 06:35:26 --> Security Class Initialized
DEBUG - 2020-02-09 06:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:35:26 --> Input Class Initialized
INFO - 2020-02-09 06:35:26 --> Language Class Initialized
INFO - 2020-02-09 06:35:26 --> Language Class Initialized
INFO - 2020-02-09 06:35:26 --> Config Class Initialized
INFO - 2020-02-09 06:35:26 --> Loader Class Initialized
INFO - 2020-02-09 06:35:26 --> Helper loaded: url_helper
INFO - 2020-02-09 06:35:26 --> Helper loaded: file_helper
INFO - 2020-02-09 06:35:26 --> Helper loaded: form_helper
INFO - 2020-02-09 06:35:26 --> Helper loaded: my_helper
INFO - 2020-02-09 06:35:26 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:35:26 --> Controller Class Initialized
INFO - 2020-02-09 06:35:28 --> Config Class Initialized
INFO - 2020-02-09 06:35:28 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:35:28 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:35:28 --> Utf8 Class Initialized
INFO - 2020-02-09 06:35:28 --> URI Class Initialized
INFO - 2020-02-09 06:35:28 --> Router Class Initialized
INFO - 2020-02-09 06:35:28 --> Output Class Initialized
INFO - 2020-02-09 06:35:29 --> Security Class Initialized
DEBUG - 2020-02-09 06:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:35:29 --> Input Class Initialized
INFO - 2020-02-09 06:35:29 --> Language Class Initialized
INFO - 2020-02-09 06:35:29 --> Language Class Initialized
INFO - 2020-02-09 06:35:29 --> Config Class Initialized
INFO - 2020-02-09 06:35:29 --> Loader Class Initialized
INFO - 2020-02-09 06:35:29 --> Helper loaded: url_helper
INFO - 2020-02-09 06:35:29 --> Helper loaded: file_helper
INFO - 2020-02-09 06:35:29 --> Helper loaded: form_helper
INFO - 2020-02-09 06:35:29 --> Helper loaded: my_helper
INFO - 2020-02-09 06:35:29 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:35:29 --> Controller Class Initialized
DEBUG - 2020-02-09 06:35:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-02-09 06:35:29 --> Final output sent to browser
DEBUG - 2020-02-09 06:35:30 --> Total execution time: 1.3747
INFO - 2020-02-09 06:35:58 --> Config Class Initialized
INFO - 2020-02-09 06:35:58 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:35:58 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:35:58 --> Utf8 Class Initialized
INFO - 2020-02-09 06:35:58 --> URI Class Initialized
INFO - 2020-02-09 06:35:58 --> Router Class Initialized
INFO - 2020-02-09 06:35:58 --> Output Class Initialized
INFO - 2020-02-09 06:35:58 --> Security Class Initialized
DEBUG - 2020-02-09 06:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:35:58 --> Input Class Initialized
INFO - 2020-02-09 06:35:58 --> Language Class Initialized
INFO - 2020-02-09 06:35:58 --> Language Class Initialized
INFO - 2020-02-09 06:35:58 --> Config Class Initialized
INFO - 2020-02-09 06:35:58 --> Loader Class Initialized
INFO - 2020-02-09 06:35:58 --> Helper loaded: url_helper
INFO - 2020-02-09 06:35:58 --> Helper loaded: file_helper
INFO - 2020-02-09 06:35:58 --> Helper loaded: form_helper
INFO - 2020-02-09 06:35:58 --> Helper loaded: my_helper
INFO - 2020-02-09 06:35:58 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:35:58 --> Controller Class Initialized
DEBUG - 2020-02-09 06:35:58 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-02-09 06:35:58 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:35:58 --> Final output sent to browser
DEBUG - 2020-02-09 06:35:58 --> Total execution time: 0.7895
INFO - 2020-02-09 06:36:04 --> Config Class Initialized
INFO - 2020-02-09 06:36:05 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:36:05 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:36:05 --> Utf8 Class Initialized
INFO - 2020-02-09 06:36:05 --> URI Class Initialized
INFO - 2020-02-09 06:36:05 --> Router Class Initialized
INFO - 2020-02-09 06:36:05 --> Output Class Initialized
INFO - 2020-02-09 06:36:05 --> Security Class Initialized
DEBUG - 2020-02-09 06:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:36:05 --> Input Class Initialized
INFO - 2020-02-09 06:36:05 --> Language Class Initialized
INFO - 2020-02-09 06:36:05 --> Language Class Initialized
INFO - 2020-02-09 06:36:05 --> Config Class Initialized
INFO - 2020-02-09 06:36:05 --> Loader Class Initialized
INFO - 2020-02-09 06:36:05 --> Helper loaded: url_helper
INFO - 2020-02-09 06:36:05 --> Helper loaded: file_helper
INFO - 2020-02-09 06:36:05 --> Helper loaded: form_helper
INFO - 2020-02-09 06:36:05 --> Helper loaded: my_helper
INFO - 2020-02-09 06:36:05 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:36:05 --> Controller Class Initialized
DEBUG - 2020-02-09 06:36:05 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-02-09 06:36:05 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:36:05 --> Final output sent to browser
DEBUG - 2020-02-09 06:36:05 --> Total execution time: 0.8465
INFO - 2020-02-09 06:36:17 --> Config Class Initialized
INFO - 2020-02-09 06:36:17 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:36:17 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:36:17 --> Utf8 Class Initialized
INFO - 2020-02-09 06:36:17 --> URI Class Initialized
INFO - 2020-02-09 06:36:17 --> Router Class Initialized
INFO - 2020-02-09 06:36:17 --> Output Class Initialized
INFO - 2020-02-09 06:36:17 --> Security Class Initialized
DEBUG - 2020-02-09 06:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:36:18 --> Input Class Initialized
INFO - 2020-02-09 06:36:18 --> Language Class Initialized
INFO - 2020-02-09 06:36:18 --> Language Class Initialized
INFO - 2020-02-09 06:36:18 --> Config Class Initialized
INFO - 2020-02-09 06:36:18 --> Loader Class Initialized
INFO - 2020-02-09 06:36:18 --> Helper loaded: url_helper
INFO - 2020-02-09 06:36:18 --> Helper loaded: file_helper
INFO - 2020-02-09 06:36:18 --> Helper loaded: form_helper
INFO - 2020-02-09 06:36:18 --> Helper loaded: my_helper
INFO - 2020-02-09 06:36:18 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:36:18 --> Controller Class Initialized
DEBUG - 2020-02-09 06:36:18 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-02-09 06:36:18 --> Final output sent to browser
DEBUG - 2020-02-09 06:36:18 --> Total execution time: 1.3585
INFO - 2020-02-09 06:36:24 --> Config Class Initialized
INFO - 2020-02-09 06:36:24 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:36:25 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:36:25 --> Utf8 Class Initialized
INFO - 2020-02-09 06:36:25 --> URI Class Initialized
INFO - 2020-02-09 06:36:25 --> Router Class Initialized
INFO - 2020-02-09 06:36:25 --> Output Class Initialized
INFO - 2020-02-09 06:36:25 --> Security Class Initialized
DEBUG - 2020-02-09 06:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:36:25 --> Input Class Initialized
INFO - 2020-02-09 06:36:25 --> Language Class Initialized
INFO - 2020-02-09 06:36:25 --> Language Class Initialized
INFO - 2020-02-09 06:36:25 --> Config Class Initialized
INFO - 2020-02-09 06:36:25 --> Loader Class Initialized
INFO - 2020-02-09 06:36:25 --> Helper loaded: url_helper
INFO - 2020-02-09 06:36:25 --> Helper loaded: file_helper
INFO - 2020-02-09 06:36:25 --> Helper loaded: form_helper
INFO - 2020-02-09 06:36:25 --> Helper loaded: my_helper
INFO - 2020-02-09 06:36:25 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:36:26 --> Controller Class Initialized
DEBUG - 2020-02-09 06:36:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-02-09 06:36:26 --> Final output sent to browser
DEBUG - 2020-02-09 06:36:26 --> Total execution time: 1.3247
INFO - 2020-02-09 06:36:34 --> Config Class Initialized
INFO - 2020-02-09 06:36:34 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:36:34 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:36:34 --> Utf8 Class Initialized
INFO - 2020-02-09 06:36:34 --> URI Class Initialized
INFO - 2020-02-09 06:36:34 --> Router Class Initialized
INFO - 2020-02-09 06:36:34 --> Output Class Initialized
INFO - 2020-02-09 06:36:34 --> Security Class Initialized
DEBUG - 2020-02-09 06:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:36:34 --> Input Class Initialized
INFO - 2020-02-09 06:36:34 --> Language Class Initialized
INFO - 2020-02-09 06:36:34 --> Language Class Initialized
INFO - 2020-02-09 06:36:34 --> Config Class Initialized
INFO - 2020-02-09 06:36:34 --> Loader Class Initialized
INFO - 2020-02-09 06:36:34 --> Helper loaded: url_helper
INFO - 2020-02-09 06:36:35 --> Helper loaded: file_helper
INFO - 2020-02-09 06:36:35 --> Helper loaded: form_helper
INFO - 2020-02-09 06:36:35 --> Helper loaded: my_helper
INFO - 2020-02-09 06:36:35 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:36:35 --> Controller Class Initialized
DEBUG - 2020-02-09 06:36:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-02-09 06:36:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:36:35 --> Final output sent to browser
DEBUG - 2020-02-09 06:36:35 --> Total execution time: 0.9127
INFO - 2020-02-09 06:37:03 --> Config Class Initialized
INFO - 2020-02-09 06:37:03 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:37:03 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:37:03 --> Utf8 Class Initialized
INFO - 2020-02-09 06:37:03 --> URI Class Initialized
INFO - 2020-02-09 06:37:03 --> Router Class Initialized
INFO - 2020-02-09 06:37:03 --> Output Class Initialized
INFO - 2020-02-09 06:37:03 --> Security Class Initialized
DEBUG - 2020-02-09 06:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:37:03 --> Input Class Initialized
INFO - 2020-02-09 06:37:03 --> Language Class Initialized
INFO - 2020-02-09 06:37:03 --> Language Class Initialized
INFO - 2020-02-09 06:37:03 --> Config Class Initialized
INFO - 2020-02-09 06:37:03 --> Loader Class Initialized
INFO - 2020-02-09 06:37:03 --> Helper loaded: url_helper
INFO - 2020-02-09 06:37:03 --> Helper loaded: file_helper
INFO - 2020-02-09 06:37:03 --> Helper loaded: form_helper
INFO - 2020-02-09 06:37:03 --> Helper loaded: my_helper
INFO - 2020-02-09 06:37:04 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:37:04 --> Controller Class Initialized
INFO - 2020-02-09 06:37:04 --> Final output sent to browser
DEBUG - 2020-02-09 06:37:04 --> Total execution time: 0.5248
INFO - 2020-02-09 06:37:09 --> Config Class Initialized
INFO - 2020-02-09 06:37:09 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:37:09 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:37:09 --> Utf8 Class Initialized
INFO - 2020-02-09 06:37:09 --> URI Class Initialized
INFO - 2020-02-09 06:37:09 --> Router Class Initialized
INFO - 2020-02-09 06:37:09 --> Output Class Initialized
INFO - 2020-02-09 06:37:09 --> Security Class Initialized
DEBUG - 2020-02-09 06:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:37:09 --> Input Class Initialized
INFO - 2020-02-09 06:37:09 --> Language Class Initialized
INFO - 2020-02-09 06:37:09 --> Language Class Initialized
INFO - 2020-02-09 06:37:09 --> Config Class Initialized
INFO - 2020-02-09 06:37:09 --> Loader Class Initialized
INFO - 2020-02-09 06:37:09 --> Helper loaded: url_helper
INFO - 2020-02-09 06:37:10 --> Helper loaded: file_helper
INFO - 2020-02-09 06:37:10 --> Helper loaded: form_helper
INFO - 2020-02-09 06:37:10 --> Helper loaded: my_helper
INFO - 2020-02-09 06:37:10 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:37:10 --> Controller Class Initialized
DEBUG - 2020-02-09 06:37:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_sikap_sp/views/cetak.php
INFO - 2020-02-09 06:37:10 --> Final output sent to browser
DEBUG - 2020-02-09 06:37:10 --> Total execution time: 1.2613
INFO - 2020-02-09 06:37:31 --> Config Class Initialized
INFO - 2020-02-09 06:37:31 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:37:31 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:37:31 --> Utf8 Class Initialized
INFO - 2020-02-09 06:37:31 --> URI Class Initialized
INFO - 2020-02-09 06:37:31 --> Router Class Initialized
INFO - 2020-02-09 06:37:31 --> Output Class Initialized
INFO - 2020-02-09 06:37:31 --> Security Class Initialized
DEBUG - 2020-02-09 06:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:37:31 --> Input Class Initialized
INFO - 2020-02-09 06:37:31 --> Language Class Initialized
INFO - 2020-02-09 06:37:31 --> Language Class Initialized
INFO - 2020-02-09 06:37:31 --> Config Class Initialized
INFO - 2020-02-09 06:37:31 --> Loader Class Initialized
INFO - 2020-02-09 06:37:31 --> Helper loaded: url_helper
INFO - 2020-02-09 06:37:32 --> Helper loaded: file_helper
INFO - 2020-02-09 06:37:32 --> Helper loaded: form_helper
INFO - 2020-02-09 06:37:32 --> Helper loaded: my_helper
INFO - 2020-02-09 06:37:32 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:37:32 --> Controller Class Initialized
DEBUG - 2020-02-09 06:37:32 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-02-09 06:37:32 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:37:32 --> Final output sent to browser
DEBUG - 2020-02-09 06:37:32 --> Total execution time: 0.9202
INFO - 2020-02-09 06:37:43 --> Config Class Initialized
INFO - 2020-02-09 06:37:43 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:37:43 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:37:43 --> Utf8 Class Initialized
INFO - 2020-02-09 06:37:43 --> URI Class Initialized
INFO - 2020-02-09 06:37:43 --> Router Class Initialized
INFO - 2020-02-09 06:37:43 --> Output Class Initialized
INFO - 2020-02-09 06:37:43 --> Security Class Initialized
DEBUG - 2020-02-09 06:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:37:43 --> Input Class Initialized
INFO - 2020-02-09 06:37:43 --> Language Class Initialized
INFO - 2020-02-09 06:37:43 --> Language Class Initialized
INFO - 2020-02-09 06:37:43 --> Config Class Initialized
INFO - 2020-02-09 06:37:43 --> Loader Class Initialized
INFO - 2020-02-09 06:37:43 --> Helper loaded: url_helper
INFO - 2020-02-09 06:37:43 --> Helper loaded: file_helper
INFO - 2020-02-09 06:37:43 --> Helper loaded: form_helper
INFO - 2020-02-09 06:37:43 --> Helper loaded: my_helper
INFO - 2020-02-09 06:37:43 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:37:43 --> Controller Class Initialized
INFO - 2020-02-09 06:37:44 --> Final output sent to browser
DEBUG - 2020-02-09 06:37:44 --> Total execution time: 0.6747
INFO - 2020-02-09 06:37:49 --> Config Class Initialized
INFO - 2020-02-09 06:37:49 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:37:49 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:37:49 --> Utf8 Class Initialized
INFO - 2020-02-09 06:37:49 --> URI Class Initialized
INFO - 2020-02-09 06:37:49 --> Router Class Initialized
INFO - 2020-02-09 06:37:49 --> Output Class Initialized
INFO - 2020-02-09 06:37:49 --> Security Class Initialized
DEBUG - 2020-02-09 06:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:37:49 --> Input Class Initialized
INFO - 2020-02-09 06:37:49 --> Language Class Initialized
INFO - 2020-02-09 06:37:49 --> Language Class Initialized
INFO - 2020-02-09 06:37:49 --> Config Class Initialized
INFO - 2020-02-09 06:37:50 --> Loader Class Initialized
INFO - 2020-02-09 06:37:50 --> Helper loaded: url_helper
INFO - 2020-02-09 06:37:50 --> Helper loaded: file_helper
INFO - 2020-02-09 06:37:50 --> Helper loaded: form_helper
INFO - 2020-02-09 06:37:50 --> Helper loaded: my_helper
INFO - 2020-02-09 06:37:50 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:37:50 --> Controller Class Initialized
DEBUG - 2020-02-09 06:37:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_sikap_so/views/cetak.php
INFO - 2020-02-09 06:37:50 --> Final output sent to browser
DEBUG - 2020-02-09 06:37:50 --> Total execution time: 1.3626
INFO - 2020-02-09 06:37:56 --> Config Class Initialized
INFO - 2020-02-09 06:37:56 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:37:56 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:37:56 --> Utf8 Class Initialized
INFO - 2020-02-09 06:37:56 --> URI Class Initialized
INFO - 2020-02-09 06:37:56 --> Router Class Initialized
INFO - 2020-02-09 06:37:56 --> Output Class Initialized
INFO - 2020-02-09 06:37:56 --> Security Class Initialized
DEBUG - 2020-02-09 06:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:37:56 --> Input Class Initialized
INFO - 2020-02-09 06:37:56 --> Language Class Initialized
INFO - 2020-02-09 06:37:56 --> Language Class Initialized
INFO - 2020-02-09 06:37:56 --> Config Class Initialized
INFO - 2020-02-09 06:37:56 --> Loader Class Initialized
INFO - 2020-02-09 06:37:56 --> Helper loaded: url_helper
INFO - 2020-02-09 06:37:56 --> Helper loaded: file_helper
INFO - 2020-02-09 06:37:56 --> Helper loaded: form_helper
INFO - 2020-02-09 06:37:56 --> Helper loaded: my_helper
INFO - 2020-02-09 06:37:56 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:37:57 --> Controller Class Initialized
DEBUG - 2020-02-09 06:37:57 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_absensi/views/list.php
DEBUG - 2020-02-09 06:37:57 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:37:57 --> Final output sent to browser
DEBUG - 2020-02-09 06:37:57 --> Total execution time: 0.8292
INFO - 2020-02-09 06:38:12 --> Config Class Initialized
INFO - 2020-02-09 06:38:12 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:38:12 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:38:12 --> Utf8 Class Initialized
INFO - 2020-02-09 06:38:12 --> URI Class Initialized
INFO - 2020-02-09 06:38:12 --> Router Class Initialized
INFO - 2020-02-09 06:38:12 --> Output Class Initialized
INFO - 2020-02-09 06:38:12 --> Security Class Initialized
DEBUG - 2020-02-09 06:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:38:12 --> Input Class Initialized
INFO - 2020-02-09 06:38:12 --> Language Class Initialized
INFO - 2020-02-09 06:38:12 --> Language Class Initialized
INFO - 2020-02-09 06:38:12 --> Config Class Initialized
INFO - 2020-02-09 06:38:12 --> Loader Class Initialized
INFO - 2020-02-09 06:38:12 --> Helper loaded: url_helper
INFO - 2020-02-09 06:38:12 --> Helper loaded: file_helper
INFO - 2020-02-09 06:38:12 --> Helper loaded: form_helper
INFO - 2020-02-09 06:38:12 --> Helper loaded: my_helper
INFO - 2020-02-09 06:38:12 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:38:12 --> Controller Class Initialized
INFO - 2020-02-09 06:38:12 --> Final output sent to browser
DEBUG - 2020-02-09 06:38:12 --> Total execution time: 0.7442
INFO - 2020-02-09 06:38:16 --> Config Class Initialized
INFO - 2020-02-09 06:38:16 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:38:16 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:38:16 --> Utf8 Class Initialized
INFO - 2020-02-09 06:38:16 --> URI Class Initialized
INFO - 2020-02-09 06:38:16 --> Router Class Initialized
INFO - 2020-02-09 06:38:16 --> Output Class Initialized
INFO - 2020-02-09 06:38:16 --> Security Class Initialized
DEBUG - 2020-02-09 06:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:38:16 --> Input Class Initialized
INFO - 2020-02-09 06:38:16 --> Language Class Initialized
INFO - 2020-02-09 06:38:16 --> Language Class Initialized
INFO - 2020-02-09 06:38:16 --> Config Class Initialized
INFO - 2020-02-09 06:38:16 --> Loader Class Initialized
INFO - 2020-02-09 06:38:16 --> Helper loaded: url_helper
INFO - 2020-02-09 06:38:16 --> Helper loaded: file_helper
INFO - 2020-02-09 06:38:17 --> Helper loaded: form_helper
INFO - 2020-02-09 06:38:17 --> Helper loaded: my_helper
INFO - 2020-02-09 06:38:17 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:38:17 --> Controller Class Initialized
DEBUG - 2020-02-09 06:38:17 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_absensi/views/cetak.php
INFO - 2020-02-09 06:38:17 --> Final output sent to browser
DEBUG - 2020-02-09 06:38:17 --> Total execution time: 1.2784
INFO - 2020-02-09 06:38:27 --> Config Class Initialized
INFO - 2020-02-09 06:38:27 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:38:27 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:38:27 --> Utf8 Class Initialized
INFO - 2020-02-09 06:38:27 --> URI Class Initialized
INFO - 2020-02-09 06:38:27 --> Router Class Initialized
INFO - 2020-02-09 06:38:27 --> Output Class Initialized
INFO - 2020-02-09 06:38:27 --> Security Class Initialized
DEBUG - 2020-02-09 06:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:38:28 --> Input Class Initialized
INFO - 2020-02-09 06:38:28 --> Language Class Initialized
INFO - 2020-02-09 06:38:28 --> Language Class Initialized
INFO - 2020-02-09 06:38:28 --> Config Class Initialized
INFO - 2020-02-09 06:38:28 --> Loader Class Initialized
INFO - 2020-02-09 06:38:28 --> Helper loaded: url_helper
INFO - 2020-02-09 06:38:28 --> Helper loaded: file_helper
INFO - 2020-02-09 06:38:28 --> Helper loaded: form_helper
INFO - 2020-02-09 06:38:28 --> Helper loaded: my_helper
INFO - 2020-02-09 06:38:28 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:38:28 --> Controller Class Initialized
DEBUG - 2020-02-09 06:38:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_ekstra/views/list.php
DEBUG - 2020-02-09 06:38:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:38:28 --> Final output sent to browser
DEBUG - 2020-02-09 06:38:28 --> Total execution time: 0.9582
INFO - 2020-02-09 06:38:37 --> Config Class Initialized
INFO - 2020-02-09 06:38:37 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:38:37 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:38:37 --> Utf8 Class Initialized
INFO - 2020-02-09 06:38:37 --> URI Class Initialized
INFO - 2020-02-09 06:38:37 --> Router Class Initialized
INFO - 2020-02-09 06:38:37 --> Output Class Initialized
INFO - 2020-02-09 06:38:37 --> Security Class Initialized
DEBUG - 2020-02-09 06:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:38:37 --> Input Class Initialized
INFO - 2020-02-09 06:38:37 --> Language Class Initialized
INFO - 2020-02-09 06:38:37 --> Language Class Initialized
INFO - 2020-02-09 06:38:37 --> Config Class Initialized
INFO - 2020-02-09 06:38:37 --> Loader Class Initialized
INFO - 2020-02-09 06:38:37 --> Helper loaded: url_helper
INFO - 2020-02-09 06:38:37 --> Helper loaded: file_helper
INFO - 2020-02-09 06:38:37 --> Helper loaded: form_helper
INFO - 2020-02-09 06:38:37 --> Helper loaded: my_helper
INFO - 2020-02-09 06:38:37 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:38:37 --> Controller Class Initialized
INFO - 2020-02-09 06:38:37 --> Final output sent to browser
DEBUG - 2020-02-09 06:38:37 --> Total execution time: 0.5520
INFO - 2020-02-09 06:38:54 --> Config Class Initialized
INFO - 2020-02-09 06:38:54 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:38:54 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:38:54 --> Utf8 Class Initialized
INFO - 2020-02-09 06:38:54 --> URI Class Initialized
INFO - 2020-02-09 06:38:54 --> Router Class Initialized
INFO - 2020-02-09 06:38:54 --> Output Class Initialized
INFO - 2020-02-09 06:38:54 --> Security Class Initialized
DEBUG - 2020-02-09 06:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:38:54 --> Input Class Initialized
INFO - 2020-02-09 06:38:54 --> Language Class Initialized
INFO - 2020-02-09 06:38:54 --> Language Class Initialized
INFO - 2020-02-09 06:38:54 --> Config Class Initialized
INFO - 2020-02-09 06:38:54 --> Loader Class Initialized
INFO - 2020-02-09 06:38:54 --> Helper loaded: url_helper
INFO - 2020-02-09 06:38:54 --> Helper loaded: file_helper
INFO - 2020-02-09 06:38:54 --> Helper loaded: form_helper
INFO - 2020-02-09 06:38:54 --> Helper loaded: my_helper
INFO - 2020-02-09 06:38:54 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:38:54 --> Controller Class Initialized
INFO - 2020-02-09 06:38:54 --> Final output sent to browser
DEBUG - 2020-02-09 06:38:54 --> Total execution time: 0.6836
INFO - 2020-02-09 06:38:57 --> Config Class Initialized
INFO - 2020-02-09 06:38:57 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:38:57 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:38:57 --> Utf8 Class Initialized
INFO - 2020-02-09 06:38:57 --> URI Class Initialized
INFO - 2020-02-09 06:38:57 --> Router Class Initialized
INFO - 2020-02-09 06:38:57 --> Output Class Initialized
INFO - 2020-02-09 06:38:57 --> Security Class Initialized
DEBUG - 2020-02-09 06:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:38:57 --> Input Class Initialized
INFO - 2020-02-09 06:38:57 --> Language Class Initialized
INFO - 2020-02-09 06:38:57 --> Language Class Initialized
INFO - 2020-02-09 06:38:57 --> Config Class Initialized
INFO - 2020-02-09 06:38:57 --> Loader Class Initialized
INFO - 2020-02-09 06:38:57 --> Helper loaded: url_helper
INFO - 2020-02-09 06:38:57 --> Helper loaded: file_helper
INFO - 2020-02-09 06:38:57 --> Helper loaded: form_helper
INFO - 2020-02-09 06:38:57 --> Helper loaded: my_helper
INFO - 2020-02-09 06:38:57 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:38:58 --> Controller Class Initialized
INFO - 2020-02-09 06:38:58 --> Final output sent to browser
DEBUG - 2020-02-09 06:38:58 --> Total execution time: 0.5771
INFO - 2020-02-09 06:39:10 --> Config Class Initialized
INFO - 2020-02-09 06:39:10 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:39:10 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:39:10 --> Utf8 Class Initialized
INFO - 2020-02-09 06:39:10 --> URI Class Initialized
INFO - 2020-02-09 06:39:10 --> Router Class Initialized
INFO - 2020-02-09 06:39:10 --> Output Class Initialized
INFO - 2020-02-09 06:39:10 --> Security Class Initialized
DEBUG - 2020-02-09 06:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:39:10 --> Input Class Initialized
INFO - 2020-02-09 06:39:10 --> Language Class Initialized
INFO - 2020-02-09 06:39:10 --> Language Class Initialized
INFO - 2020-02-09 06:39:10 --> Config Class Initialized
INFO - 2020-02-09 06:39:10 --> Loader Class Initialized
INFO - 2020-02-09 06:39:10 --> Helper loaded: url_helper
INFO - 2020-02-09 06:39:10 --> Helper loaded: file_helper
INFO - 2020-02-09 06:39:10 --> Helper loaded: form_helper
INFO - 2020-02-09 06:39:10 --> Helper loaded: my_helper
INFO - 2020-02-09 06:39:10 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:39:10 --> Controller Class Initialized
INFO - 2020-02-09 06:39:10 --> Final output sent to browser
DEBUG - 2020-02-09 06:39:10 --> Total execution time: 0.8277
INFO - 2020-02-09 06:39:13 --> Config Class Initialized
INFO - 2020-02-09 06:39:13 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:39:13 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:39:13 --> Utf8 Class Initialized
INFO - 2020-02-09 06:39:13 --> URI Class Initialized
INFO - 2020-02-09 06:39:13 --> Router Class Initialized
INFO - 2020-02-09 06:39:13 --> Output Class Initialized
INFO - 2020-02-09 06:39:13 --> Security Class Initialized
DEBUG - 2020-02-09 06:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:39:13 --> Input Class Initialized
INFO - 2020-02-09 06:39:13 --> Language Class Initialized
INFO - 2020-02-09 06:39:13 --> Language Class Initialized
INFO - 2020-02-09 06:39:13 --> Config Class Initialized
INFO - 2020-02-09 06:39:13 --> Loader Class Initialized
INFO - 2020-02-09 06:39:13 --> Helper loaded: url_helper
INFO - 2020-02-09 06:39:13 --> Helper loaded: file_helper
INFO - 2020-02-09 06:39:13 --> Helper loaded: form_helper
INFO - 2020-02-09 06:39:13 --> Helper loaded: my_helper
INFO - 2020-02-09 06:39:14 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:39:14 --> Controller Class Initialized
INFO - 2020-02-09 06:39:14 --> Final output sent to browser
DEBUG - 2020-02-09 06:39:14 --> Total execution time: 0.7159
INFO - 2020-02-09 06:39:23 --> Config Class Initialized
INFO - 2020-02-09 06:39:23 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:39:23 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:39:23 --> Utf8 Class Initialized
INFO - 2020-02-09 06:39:23 --> URI Class Initialized
INFO - 2020-02-09 06:39:23 --> Router Class Initialized
INFO - 2020-02-09 06:39:23 --> Output Class Initialized
INFO - 2020-02-09 06:39:23 --> Security Class Initialized
DEBUG - 2020-02-09 06:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:39:23 --> Input Class Initialized
INFO - 2020-02-09 06:39:23 --> Language Class Initialized
INFO - 2020-02-09 06:39:23 --> Language Class Initialized
INFO - 2020-02-09 06:39:23 --> Config Class Initialized
INFO - 2020-02-09 06:39:23 --> Loader Class Initialized
INFO - 2020-02-09 06:39:23 --> Helper loaded: url_helper
INFO - 2020-02-09 06:39:23 --> Helper loaded: file_helper
INFO - 2020-02-09 06:39:23 --> Helper loaded: form_helper
INFO - 2020-02-09 06:39:23 --> Helper loaded: my_helper
INFO - 2020-02-09 06:39:24 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:39:24 --> Controller Class Initialized
INFO - 2020-02-09 06:39:24 --> Final output sent to browser
DEBUG - 2020-02-09 06:39:24 --> Total execution time: 0.7931
INFO - 2020-02-09 06:39:29 --> Config Class Initialized
INFO - 2020-02-09 06:39:29 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:39:29 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:39:29 --> Utf8 Class Initialized
INFO - 2020-02-09 06:39:29 --> URI Class Initialized
INFO - 2020-02-09 06:39:29 --> Router Class Initialized
INFO - 2020-02-09 06:39:29 --> Output Class Initialized
INFO - 2020-02-09 06:39:29 --> Security Class Initialized
DEBUG - 2020-02-09 06:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:39:29 --> Input Class Initialized
INFO - 2020-02-09 06:39:29 --> Language Class Initialized
INFO - 2020-02-09 06:39:29 --> Language Class Initialized
INFO - 2020-02-09 06:39:30 --> Config Class Initialized
INFO - 2020-02-09 06:39:30 --> Loader Class Initialized
INFO - 2020-02-09 06:39:30 --> Helper loaded: url_helper
INFO - 2020-02-09 06:39:30 --> Helper loaded: file_helper
INFO - 2020-02-09 06:39:30 --> Helper loaded: form_helper
INFO - 2020-02-09 06:39:30 --> Helper loaded: my_helper
INFO - 2020-02-09 06:39:30 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:39:30 --> Controller Class Initialized
DEBUG - 2020-02-09 06:39:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_prestasi/views/list.php
DEBUG - 2020-02-09 06:39:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:39:30 --> Final output sent to browser
DEBUG - 2020-02-09 06:39:31 --> Total execution time: 1.6799
INFO - 2020-02-09 06:39:31 --> Config Class Initialized
INFO - 2020-02-09 06:39:31 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:39:31 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:39:31 --> Utf8 Class Initialized
INFO - 2020-02-09 06:39:31 --> URI Class Initialized
INFO - 2020-02-09 06:39:31 --> Router Class Initialized
INFO - 2020-02-09 06:39:31 --> Output Class Initialized
INFO - 2020-02-09 06:39:31 --> Security Class Initialized
DEBUG - 2020-02-09 06:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:39:32 --> Input Class Initialized
INFO - 2020-02-09 06:39:32 --> Language Class Initialized
INFO - 2020-02-09 06:39:32 --> Language Class Initialized
INFO - 2020-02-09 06:39:32 --> Config Class Initialized
INFO - 2020-02-09 06:39:32 --> Loader Class Initialized
INFO - 2020-02-09 06:39:32 --> Helper loaded: url_helper
INFO - 2020-02-09 06:39:32 --> Helper loaded: file_helper
INFO - 2020-02-09 06:39:32 --> Helper loaded: form_helper
INFO - 2020-02-09 06:39:32 --> Helper loaded: my_helper
INFO - 2020-02-09 06:39:32 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:39:32 --> Controller Class Initialized
INFO - 2020-02-09 06:40:02 --> Config Class Initialized
INFO - 2020-02-09 06:40:02 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:40:02 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:40:02 --> Utf8 Class Initialized
INFO - 2020-02-09 06:40:02 --> URI Class Initialized
INFO - 2020-02-09 06:40:02 --> Router Class Initialized
INFO - 2020-02-09 06:40:02 --> Output Class Initialized
INFO - 2020-02-09 06:40:02 --> Security Class Initialized
DEBUG - 2020-02-09 06:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:40:03 --> Input Class Initialized
INFO - 2020-02-09 06:40:03 --> Language Class Initialized
INFO - 2020-02-09 06:40:03 --> Language Class Initialized
INFO - 2020-02-09 06:40:03 --> Config Class Initialized
INFO - 2020-02-09 06:40:03 --> Loader Class Initialized
INFO - 2020-02-09 06:40:03 --> Helper loaded: url_helper
INFO - 2020-02-09 06:40:03 --> Helper loaded: file_helper
INFO - 2020-02-09 06:40:03 --> Helper loaded: form_helper
INFO - 2020-02-09 06:40:03 --> Helper loaded: my_helper
INFO - 2020-02-09 06:40:03 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:40:03 --> Controller Class Initialized
INFO - 2020-02-09 06:40:03 --> Final output sent to browser
DEBUG - 2020-02-09 06:40:03 --> Total execution time: 0.6787
INFO - 2020-02-09 06:40:03 --> Config Class Initialized
INFO - 2020-02-09 06:40:03 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:40:03 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:40:03 --> Utf8 Class Initialized
INFO - 2020-02-09 06:40:03 --> URI Class Initialized
INFO - 2020-02-09 06:40:03 --> Router Class Initialized
INFO - 2020-02-09 06:40:03 --> Output Class Initialized
INFO - 2020-02-09 06:40:03 --> Security Class Initialized
DEBUG - 2020-02-09 06:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:40:03 --> Input Class Initialized
INFO - 2020-02-09 06:40:03 --> Language Class Initialized
INFO - 2020-02-09 06:40:03 --> Language Class Initialized
INFO - 2020-02-09 06:40:03 --> Config Class Initialized
INFO - 2020-02-09 06:40:03 --> Loader Class Initialized
INFO - 2020-02-09 06:40:03 --> Helper loaded: url_helper
INFO - 2020-02-09 06:40:03 --> Helper loaded: file_helper
INFO - 2020-02-09 06:40:03 --> Helper loaded: form_helper
INFO - 2020-02-09 06:40:03 --> Helper loaded: my_helper
INFO - 2020-02-09 06:40:04 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:40:04 --> Controller Class Initialized
INFO - 2020-02-09 06:40:06 --> Config Class Initialized
INFO - 2020-02-09 06:40:06 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:40:06 --> UTF-8 Support Enabled
INFO - 2020-02-09 06:40:06 --> Utf8 Class Initialized
INFO - 2020-02-09 06:40:06 --> URI Class Initialized
INFO - 2020-02-09 06:40:06 --> Router Class Initialized
INFO - 2020-02-09 06:40:06 --> Output Class Initialized
INFO - 2020-02-09 06:40:06 --> Security Class Initialized
DEBUG - 2020-02-09 06:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 06:40:06 --> Input Class Initialized
INFO - 2020-02-09 06:40:06 --> Language Class Initialized
INFO - 2020-02-09 06:40:07 --> Language Class Initialized
INFO - 2020-02-09 06:40:07 --> Config Class Initialized
INFO - 2020-02-09 06:40:07 --> Loader Class Initialized
INFO - 2020-02-09 06:40:07 --> Helper loaded: url_helper
INFO - 2020-02-09 06:40:07 --> Helper loaded: file_helper
INFO - 2020-02-09 06:40:07 --> Helper loaded: form_helper
INFO - 2020-02-09 06:40:07 --> Helper loaded: my_helper
INFO - 2020-02-09 06:40:07 --> Database Driver Class Initialized
DEBUG - 2020-02-09 06:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 06:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 06:40:07 --> Controller Class Initialized
DEBUG - 2020-02-09 06:40:07 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_catatan/views/list.php
DEBUG - 2020-02-09 06:40:07 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 06:40:07 --> Final output sent to browser
DEBUG - 2020-02-09 06:40:07 --> Total execution time: 0.8727
INFO - 2020-02-09 07:03:28 --> Config Class Initialized
INFO - 2020-02-09 07:03:28 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:03:28 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:03:28 --> Utf8 Class Initialized
INFO - 2020-02-09 07:03:28 --> URI Class Initialized
INFO - 2020-02-09 07:03:28 --> Router Class Initialized
INFO - 2020-02-09 07:03:28 --> Output Class Initialized
INFO - 2020-02-09 07:03:28 --> Security Class Initialized
DEBUG - 2020-02-09 07:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:03:28 --> Input Class Initialized
INFO - 2020-02-09 07:03:28 --> Language Class Initialized
INFO - 2020-02-09 07:03:28 --> Language Class Initialized
INFO - 2020-02-09 07:03:28 --> Config Class Initialized
INFO - 2020-02-09 07:03:28 --> Loader Class Initialized
INFO - 2020-02-09 07:03:28 --> Helper loaded: url_helper
INFO - 2020-02-09 07:03:28 --> Helper loaded: file_helper
INFO - 2020-02-09 07:03:28 --> Helper loaded: form_helper
INFO - 2020-02-09 07:03:28 --> Helper loaded: my_helper
INFO - 2020-02-09 07:03:28 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:03:29 --> Controller Class Initialized
INFO - 2020-02-09 07:03:29 --> Helper loaded: cookie_helper
INFO - 2020-02-09 07:03:29 --> Config Class Initialized
INFO - 2020-02-09 07:03:29 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:03:29 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:03:29 --> Utf8 Class Initialized
INFO - 2020-02-09 07:03:29 --> URI Class Initialized
INFO - 2020-02-09 07:03:29 --> Router Class Initialized
INFO - 2020-02-09 07:03:29 --> Output Class Initialized
INFO - 2020-02-09 07:03:29 --> Security Class Initialized
DEBUG - 2020-02-09 07:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:03:29 --> Input Class Initialized
INFO - 2020-02-09 07:03:29 --> Language Class Initialized
INFO - 2020-02-09 07:03:29 --> Language Class Initialized
INFO - 2020-02-09 07:03:29 --> Config Class Initialized
INFO - 2020-02-09 07:03:29 --> Loader Class Initialized
INFO - 2020-02-09 07:03:29 --> Helper loaded: url_helper
INFO - 2020-02-09 07:03:29 --> Helper loaded: file_helper
INFO - 2020-02-09 07:03:29 --> Helper loaded: form_helper
INFO - 2020-02-09 07:03:29 --> Helper loaded: my_helper
INFO - 2020-02-09 07:03:29 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:03:29 --> Controller Class Initialized
INFO - 2020-02-09 07:03:29 --> Config Class Initialized
INFO - 2020-02-09 07:03:29 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:03:29 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:03:29 --> Utf8 Class Initialized
INFO - 2020-02-09 07:03:29 --> URI Class Initialized
INFO - 2020-02-09 07:03:29 --> Router Class Initialized
INFO - 2020-02-09 07:03:29 --> Output Class Initialized
INFO - 2020-02-09 07:03:29 --> Security Class Initialized
DEBUG - 2020-02-09 07:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:03:29 --> Input Class Initialized
INFO - 2020-02-09 07:03:29 --> Language Class Initialized
INFO - 2020-02-09 07:03:29 --> Language Class Initialized
INFO - 2020-02-09 07:03:29 --> Config Class Initialized
INFO - 2020-02-09 07:03:29 --> Loader Class Initialized
INFO - 2020-02-09 07:03:29 --> Helper loaded: url_helper
INFO - 2020-02-09 07:03:29 --> Helper loaded: file_helper
INFO - 2020-02-09 07:03:29 --> Helper loaded: form_helper
INFO - 2020-02-09 07:03:29 --> Helper loaded: my_helper
INFO - 2020-02-09 07:03:30 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:03:30 --> Controller Class Initialized
DEBUG - 2020-02-09 07:03:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 07:03:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:03:30 --> Final output sent to browser
DEBUG - 2020-02-09 07:03:30 --> Total execution time: 0.5231
INFO - 2020-02-09 07:03:36 --> Config Class Initialized
INFO - 2020-02-09 07:03:36 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:03:36 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:03:36 --> Utf8 Class Initialized
INFO - 2020-02-09 07:03:37 --> URI Class Initialized
INFO - 2020-02-09 07:03:37 --> Router Class Initialized
INFO - 2020-02-09 07:03:37 --> Output Class Initialized
INFO - 2020-02-09 07:03:37 --> Security Class Initialized
DEBUG - 2020-02-09 07:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:03:37 --> Input Class Initialized
INFO - 2020-02-09 07:03:37 --> Language Class Initialized
INFO - 2020-02-09 07:03:37 --> Language Class Initialized
INFO - 2020-02-09 07:03:37 --> Config Class Initialized
INFO - 2020-02-09 07:03:37 --> Loader Class Initialized
INFO - 2020-02-09 07:03:37 --> Helper loaded: url_helper
INFO - 2020-02-09 07:03:37 --> Helper loaded: file_helper
INFO - 2020-02-09 07:03:37 --> Helper loaded: form_helper
INFO - 2020-02-09 07:03:37 --> Helper loaded: my_helper
INFO - 2020-02-09 07:03:37 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:03:37 --> Controller Class Initialized
INFO - 2020-02-09 07:03:37 --> Helper loaded: cookie_helper
INFO - 2020-02-09 07:03:37 --> Final output sent to browser
DEBUG - 2020-02-09 07:03:37 --> Total execution time: 0.4963
INFO - 2020-02-09 07:03:37 --> Config Class Initialized
INFO - 2020-02-09 07:03:37 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:03:37 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:03:37 --> Utf8 Class Initialized
INFO - 2020-02-09 07:03:37 --> URI Class Initialized
INFO - 2020-02-09 07:03:37 --> Router Class Initialized
INFO - 2020-02-09 07:03:37 --> Output Class Initialized
INFO - 2020-02-09 07:03:37 --> Security Class Initialized
DEBUG - 2020-02-09 07:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:03:37 --> Input Class Initialized
INFO - 2020-02-09 07:03:37 --> Language Class Initialized
INFO - 2020-02-09 07:03:37 --> Language Class Initialized
INFO - 2020-02-09 07:03:37 --> Config Class Initialized
INFO - 2020-02-09 07:03:37 --> Loader Class Initialized
INFO - 2020-02-09 07:03:37 --> Helper loaded: url_helper
INFO - 2020-02-09 07:03:37 --> Helper loaded: file_helper
INFO - 2020-02-09 07:03:37 --> Helper loaded: form_helper
INFO - 2020-02-09 07:03:37 --> Helper loaded: my_helper
INFO - 2020-02-09 07:03:37 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:03:38 --> Controller Class Initialized
DEBUG - 2020-02-09 07:03:38 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-09 07:03:38 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:03:38 --> Final output sent to browser
DEBUG - 2020-02-09 07:03:38 --> Total execution time: 0.6263
INFO - 2020-02-09 07:03:41 --> Config Class Initialized
INFO - 2020-02-09 07:03:41 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:03:41 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:03:41 --> Utf8 Class Initialized
INFO - 2020-02-09 07:03:41 --> URI Class Initialized
INFO - 2020-02-09 07:03:41 --> Router Class Initialized
INFO - 2020-02-09 07:03:41 --> Output Class Initialized
INFO - 2020-02-09 07:03:41 --> Security Class Initialized
DEBUG - 2020-02-09 07:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:03:41 --> Input Class Initialized
INFO - 2020-02-09 07:03:41 --> Language Class Initialized
INFO - 2020-02-09 07:03:41 --> Language Class Initialized
INFO - 2020-02-09 07:03:41 --> Config Class Initialized
INFO - 2020-02-09 07:03:41 --> Loader Class Initialized
INFO - 2020-02-09 07:03:41 --> Helper loaded: url_helper
INFO - 2020-02-09 07:03:41 --> Helper loaded: file_helper
INFO - 2020-02-09 07:03:42 --> Helper loaded: form_helper
INFO - 2020-02-09 07:03:42 --> Helper loaded: my_helper
INFO - 2020-02-09 07:03:42 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:03:42 --> Controller Class Initialized
DEBUG - 2020-02-09 07:03:42 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-09 07:03:42 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:03:42 --> Final output sent to browser
DEBUG - 2020-02-09 07:03:42 --> Total execution time: 0.5889
INFO - 2020-02-09 07:03:42 --> Config Class Initialized
INFO - 2020-02-09 07:03:42 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:03:42 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:03:42 --> Utf8 Class Initialized
INFO - 2020-02-09 07:03:42 --> URI Class Initialized
INFO - 2020-02-09 07:03:42 --> Router Class Initialized
INFO - 2020-02-09 07:03:42 --> Output Class Initialized
INFO - 2020-02-09 07:03:42 --> Security Class Initialized
DEBUG - 2020-02-09 07:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:03:42 --> Input Class Initialized
INFO - 2020-02-09 07:03:42 --> Language Class Initialized
INFO - 2020-02-09 07:03:42 --> Language Class Initialized
INFO - 2020-02-09 07:03:42 --> Config Class Initialized
INFO - 2020-02-09 07:03:42 --> Loader Class Initialized
INFO - 2020-02-09 07:03:42 --> Helper loaded: url_helper
INFO - 2020-02-09 07:03:42 --> Helper loaded: file_helper
INFO - 2020-02-09 07:03:42 --> Helper loaded: form_helper
INFO - 2020-02-09 07:03:42 --> Helper loaded: my_helper
INFO - 2020-02-09 07:03:42 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:03:42 --> Controller Class Initialized
INFO - 2020-02-09 07:03:45 --> Config Class Initialized
INFO - 2020-02-09 07:03:45 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:03:46 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:03:46 --> Utf8 Class Initialized
INFO - 2020-02-09 07:03:46 --> URI Class Initialized
INFO - 2020-02-09 07:03:46 --> Router Class Initialized
INFO - 2020-02-09 07:03:46 --> Output Class Initialized
INFO - 2020-02-09 07:03:46 --> Security Class Initialized
DEBUG - 2020-02-09 07:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:03:46 --> Input Class Initialized
INFO - 2020-02-09 07:03:46 --> Language Class Initialized
INFO - 2020-02-09 07:03:46 --> Language Class Initialized
INFO - 2020-02-09 07:03:46 --> Config Class Initialized
INFO - 2020-02-09 07:03:46 --> Loader Class Initialized
INFO - 2020-02-09 07:03:46 --> Helper loaded: url_helper
INFO - 2020-02-09 07:03:46 --> Helper loaded: file_helper
INFO - 2020-02-09 07:03:46 --> Helper loaded: form_helper
INFO - 2020-02-09 07:03:46 --> Helper loaded: my_helper
INFO - 2020-02-09 07:03:46 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:03:46 --> Controller Class Initialized
DEBUG - 2020-02-09 07:03:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-09 07:03:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:03:46 --> Final output sent to browser
DEBUG - 2020-02-09 07:03:46 --> Total execution time: 0.5694
INFO - 2020-02-09 07:03:46 --> Config Class Initialized
INFO - 2020-02-09 07:03:46 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:03:46 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:03:46 --> Utf8 Class Initialized
INFO - 2020-02-09 07:03:46 --> URI Class Initialized
INFO - 2020-02-09 07:03:46 --> Router Class Initialized
INFO - 2020-02-09 07:03:46 --> Output Class Initialized
INFO - 2020-02-09 07:03:46 --> Security Class Initialized
DEBUG - 2020-02-09 07:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:03:46 --> Input Class Initialized
INFO - 2020-02-09 07:03:46 --> Language Class Initialized
INFO - 2020-02-09 07:03:46 --> Language Class Initialized
INFO - 2020-02-09 07:03:46 --> Config Class Initialized
INFO - 2020-02-09 07:03:47 --> Loader Class Initialized
INFO - 2020-02-09 07:03:47 --> Helper loaded: url_helper
INFO - 2020-02-09 07:03:47 --> Helper loaded: file_helper
INFO - 2020-02-09 07:03:47 --> Helper loaded: form_helper
INFO - 2020-02-09 07:03:47 --> Helper loaded: my_helper
INFO - 2020-02-09 07:03:47 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:03:47 --> Controller Class Initialized
INFO - 2020-02-09 07:05:32 --> Config Class Initialized
INFO - 2020-02-09 07:05:32 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:05:32 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:05:32 --> Utf8 Class Initialized
INFO - 2020-02-09 07:05:32 --> URI Class Initialized
DEBUG - 2020-02-09 07:05:32 --> No URI present. Default controller set.
INFO - 2020-02-09 07:05:32 --> Router Class Initialized
INFO - 2020-02-09 07:05:32 --> Output Class Initialized
INFO - 2020-02-09 07:05:32 --> Security Class Initialized
DEBUG - 2020-02-09 07:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:05:32 --> Input Class Initialized
INFO - 2020-02-09 07:05:32 --> Language Class Initialized
INFO - 2020-02-09 07:05:32 --> Language Class Initialized
INFO - 2020-02-09 07:05:32 --> Config Class Initialized
INFO - 2020-02-09 07:05:32 --> Loader Class Initialized
INFO - 2020-02-09 07:05:32 --> Helper loaded: url_helper
INFO - 2020-02-09 07:05:32 --> Helper loaded: file_helper
INFO - 2020-02-09 07:05:32 --> Helper loaded: form_helper
INFO - 2020-02-09 07:05:32 --> Helper loaded: my_helper
INFO - 2020-02-09 07:05:32 --> Database Driver Class Initialized
ERROR - 2020-02-09 07:05:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'db_nilaik13' E:\xampp\htdocs\_2020\myraport\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2020-02-09 07:05:32 --> Unable to connect to the database
INFO - 2020-02-09 07:05:32 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-09 07:05:54 --> Config Class Initialized
INFO - 2020-02-09 07:05:54 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:05:54 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:05:54 --> Utf8 Class Initialized
INFO - 2020-02-09 07:05:54 --> URI Class Initialized
DEBUG - 2020-02-09 07:05:54 --> No URI present. Default controller set.
INFO - 2020-02-09 07:05:54 --> Router Class Initialized
INFO - 2020-02-09 07:05:54 --> Output Class Initialized
INFO - 2020-02-09 07:05:54 --> Security Class Initialized
DEBUG - 2020-02-09 07:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:05:54 --> Input Class Initialized
INFO - 2020-02-09 07:05:54 --> Language Class Initialized
INFO - 2020-02-09 07:05:54 --> Language Class Initialized
INFO - 2020-02-09 07:05:54 --> Config Class Initialized
INFO - 2020-02-09 07:05:54 --> Loader Class Initialized
INFO - 2020-02-09 07:05:54 --> Helper loaded: url_helper
INFO - 2020-02-09 07:05:54 --> Helper loaded: file_helper
INFO - 2020-02-09 07:05:54 --> Helper loaded: form_helper
INFO - 2020-02-09 07:05:54 --> Helper loaded: my_helper
INFO - 2020-02-09 07:05:55 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:05:55 --> Controller Class Initialized
DEBUG - 2020-02-09 07:05:55 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-09 07:05:55 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:05:55 --> Final output sent to browser
DEBUG - 2020-02-09 07:05:55 --> Total execution time: 0.5976
INFO - 2020-02-09 07:06:02 --> Config Class Initialized
INFO - 2020-02-09 07:06:02 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:06:02 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:06:02 --> Utf8 Class Initialized
INFO - 2020-02-09 07:06:02 --> URI Class Initialized
INFO - 2020-02-09 07:06:02 --> Router Class Initialized
INFO - 2020-02-09 07:06:02 --> Output Class Initialized
INFO - 2020-02-09 07:06:02 --> Security Class Initialized
DEBUG - 2020-02-09 07:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:06:02 --> Input Class Initialized
INFO - 2020-02-09 07:06:02 --> Language Class Initialized
INFO - 2020-02-09 07:06:02 --> Language Class Initialized
INFO - 2020-02-09 07:06:02 --> Config Class Initialized
INFO - 2020-02-09 07:06:02 --> Loader Class Initialized
INFO - 2020-02-09 07:06:02 --> Helper loaded: url_helper
INFO - 2020-02-09 07:06:02 --> Helper loaded: file_helper
INFO - 2020-02-09 07:06:02 --> Helper loaded: form_helper
INFO - 2020-02-09 07:06:03 --> Helper loaded: my_helper
INFO - 2020-02-09 07:06:03 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:06:03 --> Controller Class Initialized
INFO - 2020-02-09 07:06:03 --> Helper loaded: cookie_helper
INFO - 2020-02-09 07:06:03 --> Config Class Initialized
INFO - 2020-02-09 07:06:03 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:06:03 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:06:03 --> Utf8 Class Initialized
INFO - 2020-02-09 07:06:03 --> URI Class Initialized
INFO - 2020-02-09 07:06:03 --> Router Class Initialized
INFO - 2020-02-09 07:06:03 --> Output Class Initialized
INFO - 2020-02-09 07:06:03 --> Security Class Initialized
DEBUG - 2020-02-09 07:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:06:03 --> Input Class Initialized
INFO - 2020-02-09 07:06:03 --> Language Class Initialized
INFO - 2020-02-09 07:06:03 --> Language Class Initialized
INFO - 2020-02-09 07:06:03 --> Config Class Initialized
INFO - 2020-02-09 07:06:03 --> Loader Class Initialized
INFO - 2020-02-09 07:06:03 --> Helper loaded: url_helper
INFO - 2020-02-09 07:06:03 --> Helper loaded: file_helper
INFO - 2020-02-09 07:06:03 --> Helper loaded: form_helper
INFO - 2020-02-09 07:06:03 --> Helper loaded: my_helper
INFO - 2020-02-09 07:06:03 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:06:03 --> Controller Class Initialized
INFO - 2020-02-09 07:06:03 --> Config Class Initialized
INFO - 2020-02-09 07:06:03 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:06:03 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:06:03 --> Utf8 Class Initialized
INFO - 2020-02-09 07:06:03 --> URI Class Initialized
INFO - 2020-02-09 07:06:03 --> Router Class Initialized
INFO - 2020-02-09 07:06:03 --> Output Class Initialized
INFO - 2020-02-09 07:06:03 --> Security Class Initialized
DEBUG - 2020-02-09 07:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:06:03 --> Input Class Initialized
INFO - 2020-02-09 07:06:03 --> Language Class Initialized
INFO - 2020-02-09 07:06:04 --> Language Class Initialized
INFO - 2020-02-09 07:06:04 --> Config Class Initialized
INFO - 2020-02-09 07:06:04 --> Loader Class Initialized
INFO - 2020-02-09 07:06:04 --> Helper loaded: url_helper
INFO - 2020-02-09 07:06:04 --> Helper loaded: file_helper
INFO - 2020-02-09 07:06:04 --> Helper loaded: form_helper
INFO - 2020-02-09 07:06:04 --> Helper loaded: my_helper
INFO - 2020-02-09 07:06:04 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:06:04 --> Controller Class Initialized
DEBUG - 2020-02-09 07:06:04 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 07:06:04 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:06:04 --> Final output sent to browser
DEBUG - 2020-02-09 07:06:04 --> Total execution time: 0.5676
INFO - 2020-02-09 07:12:51 --> Config Class Initialized
INFO - 2020-02-09 07:12:51 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:12:51 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:12:51 --> Utf8 Class Initialized
INFO - 2020-02-09 07:12:51 --> URI Class Initialized
INFO - 2020-02-09 07:12:51 --> Router Class Initialized
INFO - 2020-02-09 07:12:51 --> Output Class Initialized
INFO - 2020-02-09 07:12:51 --> Security Class Initialized
DEBUG - 2020-02-09 07:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:12:51 --> Input Class Initialized
INFO - 2020-02-09 07:12:51 --> Language Class Initialized
INFO - 2020-02-09 07:12:51 --> Language Class Initialized
INFO - 2020-02-09 07:12:51 --> Config Class Initialized
INFO - 2020-02-09 07:12:51 --> Loader Class Initialized
INFO - 2020-02-09 07:12:51 --> Helper loaded: url_helper
INFO - 2020-02-09 07:12:51 --> Helper loaded: file_helper
INFO - 2020-02-09 07:12:51 --> Helper loaded: form_helper
INFO - 2020-02-09 07:12:51 --> Helper loaded: my_helper
INFO - 2020-02-09 07:12:51 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:12:52 --> Controller Class Initialized
INFO - 2020-02-09 07:12:52 --> Helper loaded: cookie_helper
INFO - 2020-02-09 07:12:52 --> Final output sent to browser
DEBUG - 2020-02-09 07:12:52 --> Total execution time: 0.7771
INFO - 2020-02-09 07:12:52 --> Config Class Initialized
INFO - 2020-02-09 07:12:52 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:12:52 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:12:52 --> Utf8 Class Initialized
INFO - 2020-02-09 07:12:52 --> URI Class Initialized
INFO - 2020-02-09 07:12:52 --> Router Class Initialized
INFO - 2020-02-09 07:12:52 --> Output Class Initialized
INFO - 2020-02-09 07:12:52 --> Security Class Initialized
DEBUG - 2020-02-09 07:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:12:52 --> Input Class Initialized
INFO - 2020-02-09 07:12:52 --> Language Class Initialized
INFO - 2020-02-09 07:12:52 --> Language Class Initialized
INFO - 2020-02-09 07:12:52 --> Config Class Initialized
INFO - 2020-02-09 07:12:52 --> Loader Class Initialized
INFO - 2020-02-09 07:12:53 --> Helper loaded: url_helper
INFO - 2020-02-09 07:12:53 --> Helper loaded: file_helper
INFO - 2020-02-09 07:12:53 --> Helper loaded: form_helper
INFO - 2020-02-09 07:12:53 --> Helper loaded: my_helper
INFO - 2020-02-09 07:12:53 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:12:53 --> Controller Class Initialized
DEBUG - 2020-02-09 07:12:53 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-09 07:12:53 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:12:53 --> Final output sent to browser
DEBUG - 2020-02-09 07:12:53 --> Total execution time: 1.1379
INFO - 2020-02-09 07:14:03 --> Config Class Initialized
INFO - 2020-02-09 07:14:03 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:14:03 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:14:03 --> Utf8 Class Initialized
INFO - 2020-02-09 07:14:03 --> URI Class Initialized
INFO - 2020-02-09 07:14:03 --> Router Class Initialized
INFO - 2020-02-09 07:14:03 --> Output Class Initialized
INFO - 2020-02-09 07:14:03 --> Security Class Initialized
DEBUG - 2020-02-09 07:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:14:03 --> Input Class Initialized
INFO - 2020-02-09 07:14:03 --> Language Class Initialized
INFO - 2020-02-09 07:14:03 --> Language Class Initialized
INFO - 2020-02-09 07:14:03 --> Config Class Initialized
INFO - 2020-02-09 07:14:03 --> Loader Class Initialized
INFO - 2020-02-09 07:14:03 --> Helper loaded: url_helper
INFO - 2020-02-09 07:14:03 --> Helper loaded: file_helper
INFO - 2020-02-09 07:14:03 --> Helper loaded: form_helper
INFO - 2020-02-09 07:14:03 --> Helper loaded: my_helper
INFO - 2020-02-09 07:14:03 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:14:04 --> Controller Class Initialized
DEBUG - 2020-02-09 07:14:04 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_guru/views/list.php
DEBUG - 2020-02-09 07:14:04 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:14:04 --> Final output sent to browser
DEBUG - 2020-02-09 07:14:04 --> Total execution time: 0.9196
INFO - 2020-02-09 07:14:04 --> Config Class Initialized
INFO - 2020-02-09 07:14:04 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:14:04 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:14:05 --> Utf8 Class Initialized
INFO - 2020-02-09 07:14:05 --> URI Class Initialized
INFO - 2020-02-09 07:14:05 --> Router Class Initialized
INFO - 2020-02-09 07:14:05 --> Output Class Initialized
INFO - 2020-02-09 07:14:05 --> Security Class Initialized
DEBUG - 2020-02-09 07:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:14:05 --> Input Class Initialized
INFO - 2020-02-09 07:14:05 --> Language Class Initialized
INFO - 2020-02-09 07:14:05 --> Language Class Initialized
INFO - 2020-02-09 07:14:05 --> Config Class Initialized
INFO - 2020-02-09 07:14:05 --> Loader Class Initialized
INFO - 2020-02-09 07:14:05 --> Helper loaded: url_helper
INFO - 2020-02-09 07:14:05 --> Helper loaded: file_helper
INFO - 2020-02-09 07:14:05 --> Helper loaded: form_helper
INFO - 2020-02-09 07:14:05 --> Helper loaded: my_helper
INFO - 2020-02-09 07:14:05 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:14:05 --> Controller Class Initialized
INFO - 2020-02-09 07:14:13 --> Config Class Initialized
INFO - 2020-02-09 07:14:14 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:14:14 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:14:14 --> Utf8 Class Initialized
INFO - 2020-02-09 07:14:14 --> URI Class Initialized
INFO - 2020-02-09 07:14:14 --> Router Class Initialized
INFO - 2020-02-09 07:14:14 --> Output Class Initialized
INFO - 2020-02-09 07:14:14 --> Security Class Initialized
DEBUG - 2020-02-09 07:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:14:14 --> Input Class Initialized
INFO - 2020-02-09 07:14:14 --> Language Class Initialized
INFO - 2020-02-09 07:14:14 --> Language Class Initialized
INFO - 2020-02-09 07:14:14 --> Config Class Initialized
INFO - 2020-02-09 07:14:14 --> Loader Class Initialized
INFO - 2020-02-09 07:14:14 --> Helper loaded: url_helper
INFO - 2020-02-09 07:14:14 --> Helper loaded: file_helper
INFO - 2020-02-09 07:14:14 --> Helper loaded: form_helper
INFO - 2020-02-09 07:14:14 --> Helper loaded: my_helper
INFO - 2020-02-09 07:14:14 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:14:14 --> Controller Class Initialized
INFO - 2020-02-09 07:14:14 --> Final output sent to browser
DEBUG - 2020-02-09 07:14:14 --> Total execution time: 0.8126
INFO - 2020-02-09 07:14:31 --> Config Class Initialized
INFO - 2020-02-09 07:14:31 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:14:31 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:14:31 --> Utf8 Class Initialized
INFO - 2020-02-09 07:14:31 --> URI Class Initialized
INFO - 2020-02-09 07:14:31 --> Router Class Initialized
INFO - 2020-02-09 07:14:31 --> Output Class Initialized
INFO - 2020-02-09 07:14:31 --> Security Class Initialized
DEBUG - 2020-02-09 07:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:14:31 --> Input Class Initialized
INFO - 2020-02-09 07:14:31 --> Language Class Initialized
INFO - 2020-02-09 07:14:31 --> Language Class Initialized
INFO - 2020-02-09 07:14:31 --> Config Class Initialized
INFO - 2020-02-09 07:14:31 --> Loader Class Initialized
INFO - 2020-02-09 07:14:31 --> Helper loaded: url_helper
INFO - 2020-02-09 07:14:31 --> Helper loaded: file_helper
INFO - 2020-02-09 07:14:31 --> Helper loaded: form_helper
INFO - 2020-02-09 07:14:31 --> Helper loaded: my_helper
INFO - 2020-02-09 07:14:31 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:14:31 --> Controller Class Initialized
INFO - 2020-02-09 07:14:31 --> Final output sent to browser
DEBUG - 2020-02-09 07:14:31 --> Total execution time: 0.5365
INFO - 2020-02-09 07:14:31 --> Config Class Initialized
INFO - 2020-02-09 07:14:31 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:14:31 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:14:31 --> Utf8 Class Initialized
INFO - 2020-02-09 07:14:32 --> URI Class Initialized
INFO - 2020-02-09 07:14:32 --> Router Class Initialized
INFO - 2020-02-09 07:14:32 --> Output Class Initialized
INFO - 2020-02-09 07:14:32 --> Security Class Initialized
DEBUG - 2020-02-09 07:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:14:32 --> Input Class Initialized
INFO - 2020-02-09 07:14:32 --> Language Class Initialized
INFO - 2020-02-09 07:14:32 --> Language Class Initialized
INFO - 2020-02-09 07:14:32 --> Config Class Initialized
INFO - 2020-02-09 07:14:32 --> Loader Class Initialized
INFO - 2020-02-09 07:14:32 --> Helper loaded: url_helper
INFO - 2020-02-09 07:14:32 --> Helper loaded: file_helper
INFO - 2020-02-09 07:14:32 --> Helper loaded: form_helper
INFO - 2020-02-09 07:14:32 --> Helper loaded: my_helper
INFO - 2020-02-09 07:14:32 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:14:32 --> Controller Class Initialized
INFO - 2020-02-09 07:14:51 --> Config Class Initialized
INFO - 2020-02-09 07:14:51 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:14:51 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:14:51 --> Utf8 Class Initialized
INFO - 2020-02-09 07:14:51 --> URI Class Initialized
INFO - 2020-02-09 07:14:51 --> Router Class Initialized
INFO - 2020-02-09 07:14:51 --> Output Class Initialized
INFO - 2020-02-09 07:14:51 --> Security Class Initialized
DEBUG - 2020-02-09 07:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:14:51 --> Input Class Initialized
INFO - 2020-02-09 07:14:51 --> Language Class Initialized
INFO - 2020-02-09 07:14:51 --> Language Class Initialized
INFO - 2020-02-09 07:14:51 --> Config Class Initialized
INFO - 2020-02-09 07:14:51 --> Loader Class Initialized
INFO - 2020-02-09 07:14:51 --> Helper loaded: url_helper
INFO - 2020-02-09 07:14:51 --> Helper loaded: file_helper
INFO - 2020-02-09 07:14:51 --> Helper loaded: form_helper
INFO - 2020-02-09 07:14:51 --> Helper loaded: my_helper
INFO - 2020-02-09 07:14:51 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:14:51 --> Controller Class Initialized
INFO - 2020-02-09 07:14:51 --> Final output sent to browser
DEBUG - 2020-02-09 07:14:51 --> Total execution time: 0.5288
INFO - 2020-02-09 07:14:52 --> Config Class Initialized
INFO - 2020-02-09 07:14:52 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:14:52 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:14:52 --> Utf8 Class Initialized
INFO - 2020-02-09 07:14:52 --> URI Class Initialized
INFO - 2020-02-09 07:14:52 --> Router Class Initialized
INFO - 2020-02-09 07:14:52 --> Output Class Initialized
INFO - 2020-02-09 07:14:52 --> Security Class Initialized
DEBUG - 2020-02-09 07:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:14:52 --> Input Class Initialized
INFO - 2020-02-09 07:14:52 --> Language Class Initialized
INFO - 2020-02-09 07:14:52 --> Language Class Initialized
INFO - 2020-02-09 07:14:52 --> Config Class Initialized
INFO - 2020-02-09 07:14:52 --> Loader Class Initialized
INFO - 2020-02-09 07:14:52 --> Helper loaded: url_helper
INFO - 2020-02-09 07:14:52 --> Helper loaded: file_helper
INFO - 2020-02-09 07:14:52 --> Helper loaded: form_helper
INFO - 2020-02-09 07:14:52 --> Helper loaded: my_helper
INFO - 2020-02-09 07:14:52 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:14:52 --> Controller Class Initialized
INFO - 2020-02-09 07:15:25 --> Config Class Initialized
INFO - 2020-02-09 07:15:25 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:15:25 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:15:25 --> Utf8 Class Initialized
INFO - 2020-02-09 07:15:25 --> URI Class Initialized
INFO - 2020-02-09 07:15:25 --> Router Class Initialized
INFO - 2020-02-09 07:15:25 --> Output Class Initialized
INFO - 2020-02-09 07:15:26 --> Security Class Initialized
DEBUG - 2020-02-09 07:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:15:26 --> Input Class Initialized
INFO - 2020-02-09 07:15:26 --> Language Class Initialized
INFO - 2020-02-09 07:15:26 --> Language Class Initialized
INFO - 2020-02-09 07:15:26 --> Config Class Initialized
INFO - 2020-02-09 07:15:26 --> Loader Class Initialized
INFO - 2020-02-09 07:15:26 --> Helper loaded: url_helper
INFO - 2020-02-09 07:15:26 --> Helper loaded: file_helper
INFO - 2020-02-09 07:15:26 --> Helper loaded: form_helper
INFO - 2020-02-09 07:15:26 --> Helper loaded: my_helper
INFO - 2020-02-09 07:15:26 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:15:26 --> Controller Class Initialized
DEBUG - 2020-02-09 07:15:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/list.php
DEBUG - 2020-02-09 07:15:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:15:26 --> Final output sent to browser
DEBUG - 2020-02-09 07:15:26 --> Total execution time: 0.7697
INFO - 2020-02-09 07:15:27 --> Config Class Initialized
INFO - 2020-02-09 07:15:27 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:15:27 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:15:27 --> Utf8 Class Initialized
INFO - 2020-02-09 07:15:27 --> URI Class Initialized
INFO - 2020-02-09 07:15:27 --> Router Class Initialized
INFO - 2020-02-09 07:15:27 --> Output Class Initialized
INFO - 2020-02-09 07:15:27 --> Security Class Initialized
DEBUG - 2020-02-09 07:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:15:27 --> Input Class Initialized
INFO - 2020-02-09 07:15:27 --> Language Class Initialized
INFO - 2020-02-09 07:15:27 --> Language Class Initialized
INFO - 2020-02-09 07:15:27 --> Config Class Initialized
INFO - 2020-02-09 07:15:27 --> Loader Class Initialized
INFO - 2020-02-09 07:15:27 --> Helper loaded: url_helper
INFO - 2020-02-09 07:15:27 --> Helper loaded: file_helper
INFO - 2020-02-09 07:15:27 --> Helper loaded: form_helper
INFO - 2020-02-09 07:15:28 --> Helper loaded: my_helper
INFO - 2020-02-09 07:15:28 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:15:28 --> Controller Class Initialized
INFO - 2020-02-09 07:15:34 --> Config Class Initialized
INFO - 2020-02-09 07:15:34 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:15:34 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:15:34 --> Utf8 Class Initialized
INFO - 2020-02-09 07:15:34 --> URI Class Initialized
INFO - 2020-02-09 07:15:34 --> Router Class Initialized
INFO - 2020-02-09 07:15:34 --> Output Class Initialized
INFO - 2020-02-09 07:15:34 --> Security Class Initialized
DEBUG - 2020-02-09 07:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:15:34 --> Input Class Initialized
INFO - 2020-02-09 07:15:34 --> Language Class Initialized
INFO - 2020-02-09 07:15:34 --> Language Class Initialized
INFO - 2020-02-09 07:15:34 --> Config Class Initialized
INFO - 2020-02-09 07:15:34 --> Loader Class Initialized
INFO - 2020-02-09 07:15:34 --> Helper loaded: url_helper
INFO - 2020-02-09 07:15:34 --> Helper loaded: file_helper
INFO - 2020-02-09 07:15:34 --> Helper loaded: form_helper
INFO - 2020-02-09 07:15:34 --> Helper loaded: my_helper
INFO - 2020-02-09 07:15:34 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:15:35 --> Controller Class Initialized
ERROR - 2020-02-09 07:15:35 --> Severity: Notice --> Undefined variable: status_form E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 223
DEBUG - 2020-02-09 07:15:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/form.php
DEBUG - 2020-02-09 07:15:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:15:35 --> Final output sent to browser
DEBUG - 2020-02-09 07:15:35 --> Total execution time: 0.8537
INFO - 2020-02-09 07:15:44 --> Config Class Initialized
INFO - 2020-02-09 07:15:45 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:15:45 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:15:45 --> Utf8 Class Initialized
INFO - 2020-02-09 07:15:45 --> URI Class Initialized
INFO - 2020-02-09 07:15:45 --> Router Class Initialized
INFO - 2020-02-09 07:15:45 --> Output Class Initialized
INFO - 2020-02-09 07:15:45 --> Security Class Initialized
DEBUG - 2020-02-09 07:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:15:45 --> Input Class Initialized
INFO - 2020-02-09 07:15:45 --> Language Class Initialized
INFO - 2020-02-09 07:15:45 --> Language Class Initialized
INFO - 2020-02-09 07:15:45 --> Config Class Initialized
INFO - 2020-02-09 07:15:45 --> Loader Class Initialized
INFO - 2020-02-09 07:15:45 --> Helper loaded: url_helper
INFO - 2020-02-09 07:15:45 --> Helper loaded: file_helper
INFO - 2020-02-09 07:15:45 --> Helper loaded: form_helper
INFO - 2020-02-09 07:15:45 --> Helper loaded: my_helper
INFO - 2020-02-09 07:15:45 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:15:45 --> Controller Class Initialized
DEBUG - 2020-02-09 07:15:45 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/list.php
DEBUG - 2020-02-09 07:15:45 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:15:45 --> Final output sent to browser
DEBUG - 2020-02-09 07:15:45 --> Total execution time: 0.8732
INFO - 2020-02-09 07:15:46 --> Config Class Initialized
INFO - 2020-02-09 07:15:46 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:15:46 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:15:46 --> Utf8 Class Initialized
INFO - 2020-02-09 07:15:46 --> URI Class Initialized
INFO - 2020-02-09 07:15:46 --> Router Class Initialized
INFO - 2020-02-09 07:15:46 --> Output Class Initialized
INFO - 2020-02-09 07:15:46 --> Security Class Initialized
DEBUG - 2020-02-09 07:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:15:46 --> Input Class Initialized
INFO - 2020-02-09 07:15:46 --> Language Class Initialized
INFO - 2020-02-09 07:15:46 --> Language Class Initialized
INFO - 2020-02-09 07:15:47 --> Config Class Initialized
INFO - 2020-02-09 07:15:47 --> Loader Class Initialized
INFO - 2020-02-09 07:15:47 --> Helper loaded: url_helper
INFO - 2020-02-09 07:15:47 --> Helper loaded: file_helper
INFO - 2020-02-09 07:15:47 --> Helper loaded: form_helper
INFO - 2020-02-09 07:15:47 --> Helper loaded: my_helper
INFO - 2020-02-09 07:15:47 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:15:47 --> Controller Class Initialized
INFO - 2020-02-09 07:16:36 --> Config Class Initialized
INFO - 2020-02-09 07:16:36 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:16:36 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:16:36 --> Utf8 Class Initialized
INFO - 2020-02-09 07:16:36 --> URI Class Initialized
INFO - 2020-02-09 07:16:36 --> Router Class Initialized
INFO - 2020-02-09 07:16:36 --> Output Class Initialized
INFO - 2020-02-09 07:16:36 --> Security Class Initialized
DEBUG - 2020-02-09 07:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:16:36 --> Input Class Initialized
INFO - 2020-02-09 07:16:36 --> Language Class Initialized
INFO - 2020-02-09 07:16:37 --> Language Class Initialized
INFO - 2020-02-09 07:16:37 --> Config Class Initialized
INFO - 2020-02-09 07:16:37 --> Loader Class Initialized
INFO - 2020-02-09 07:16:37 --> Helper loaded: url_helper
INFO - 2020-02-09 07:16:37 --> Helper loaded: file_helper
INFO - 2020-02-09 07:16:37 --> Helper loaded: form_helper
INFO - 2020-02-09 07:16:37 --> Helper loaded: my_helper
INFO - 2020-02-09 07:16:37 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:16:37 --> Controller Class Initialized
DEBUG - 2020-02-09 07:16:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/form_import.php
DEBUG - 2020-02-09 07:16:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:16:37 --> Final output sent to browser
DEBUG - 2020-02-09 07:16:37 --> Total execution time: 0.8293
INFO - 2020-02-09 07:16:47 --> Config Class Initialized
INFO - 2020-02-09 07:16:47 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:16:47 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:16:47 --> Utf8 Class Initialized
INFO - 2020-02-09 07:16:47 --> URI Class Initialized
INFO - 2020-02-09 07:16:47 --> Router Class Initialized
INFO - 2020-02-09 07:16:47 --> Output Class Initialized
INFO - 2020-02-09 07:16:47 --> Security Class Initialized
DEBUG - 2020-02-09 07:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:16:47 --> Input Class Initialized
INFO - 2020-02-09 07:16:47 --> Language Class Initialized
INFO - 2020-02-09 07:16:47 --> Language Class Initialized
INFO - 2020-02-09 07:16:47 --> Config Class Initialized
INFO - 2020-02-09 07:16:47 --> Loader Class Initialized
INFO - 2020-02-09 07:16:47 --> Helper loaded: url_helper
INFO - 2020-02-09 07:16:47 --> Helper loaded: file_helper
INFO - 2020-02-09 07:16:47 --> Helper loaded: form_helper
INFO - 2020-02-09 07:16:47 --> Helper loaded: my_helper
INFO - 2020-02-09 07:16:47 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:16:47 --> Controller Class Initialized
DEBUG - 2020-02-09 07:16:47 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/list.php
DEBUG - 2020-02-09 07:16:47 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:16:47 --> Final output sent to browser
DEBUG - 2020-02-09 07:16:48 --> Total execution time: 0.8343
INFO - 2020-02-09 07:16:48 --> Config Class Initialized
INFO - 2020-02-09 07:16:48 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:16:48 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:16:48 --> Utf8 Class Initialized
INFO - 2020-02-09 07:16:48 --> URI Class Initialized
INFO - 2020-02-09 07:16:48 --> Router Class Initialized
INFO - 2020-02-09 07:16:49 --> Output Class Initialized
INFO - 2020-02-09 07:16:49 --> Security Class Initialized
DEBUG - 2020-02-09 07:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:16:49 --> Input Class Initialized
INFO - 2020-02-09 07:16:49 --> Language Class Initialized
INFO - 2020-02-09 07:16:49 --> Language Class Initialized
INFO - 2020-02-09 07:16:49 --> Config Class Initialized
INFO - 2020-02-09 07:16:49 --> Loader Class Initialized
INFO - 2020-02-09 07:16:49 --> Helper loaded: url_helper
INFO - 2020-02-09 07:16:49 --> Helper loaded: file_helper
INFO - 2020-02-09 07:16:49 --> Helper loaded: form_helper
INFO - 2020-02-09 07:16:49 --> Helper loaded: my_helper
INFO - 2020-02-09 07:16:49 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:16:49 --> Controller Class Initialized
INFO - 2020-02-09 07:17:10 --> Config Class Initialized
INFO - 2020-02-09 07:17:10 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:17:10 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:17:10 --> Utf8 Class Initialized
INFO - 2020-02-09 07:17:10 --> URI Class Initialized
INFO - 2020-02-09 07:17:10 --> Router Class Initialized
INFO - 2020-02-09 07:17:11 --> Output Class Initialized
INFO - 2020-02-09 07:17:11 --> Security Class Initialized
DEBUG - 2020-02-09 07:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:17:11 --> Input Class Initialized
INFO - 2020-02-09 07:17:11 --> Language Class Initialized
INFO - 2020-02-09 07:17:11 --> Language Class Initialized
INFO - 2020-02-09 07:17:11 --> Config Class Initialized
INFO - 2020-02-09 07:17:11 --> Loader Class Initialized
INFO - 2020-02-09 07:17:11 --> Helper loaded: url_helper
INFO - 2020-02-09 07:17:11 --> Helper loaded: file_helper
INFO - 2020-02-09 07:17:11 --> Helper loaded: form_helper
INFO - 2020-02-09 07:17:11 --> Helper loaded: my_helper
INFO - 2020-02-09 07:17:11 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:17:11 --> Controller Class Initialized
INFO - 2020-02-09 07:17:11 --> Final output sent to browser
DEBUG - 2020-02-09 07:17:11 --> Total execution time: 0.9246
INFO - 2020-02-09 07:17:11 --> Config Class Initialized
INFO - 2020-02-09 07:17:11 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:17:11 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:17:11 --> Utf8 Class Initialized
INFO - 2020-02-09 07:17:12 --> URI Class Initialized
INFO - 2020-02-09 07:17:12 --> Router Class Initialized
INFO - 2020-02-09 07:17:12 --> Output Class Initialized
INFO - 2020-02-09 07:17:12 --> Security Class Initialized
DEBUG - 2020-02-09 07:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:17:12 --> Input Class Initialized
INFO - 2020-02-09 07:17:12 --> Language Class Initialized
INFO - 2020-02-09 07:17:12 --> Language Class Initialized
INFO - 2020-02-09 07:17:12 --> Config Class Initialized
INFO - 2020-02-09 07:17:12 --> Loader Class Initialized
INFO - 2020-02-09 07:17:12 --> Helper loaded: url_helper
INFO - 2020-02-09 07:17:12 --> Helper loaded: file_helper
INFO - 2020-02-09 07:17:12 --> Helper loaded: form_helper
INFO - 2020-02-09 07:17:12 --> Helper loaded: my_helper
INFO - 2020-02-09 07:17:12 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:17:12 --> Controller Class Initialized
INFO - 2020-02-09 07:17:37 --> Config Class Initialized
INFO - 2020-02-09 07:17:37 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:17:37 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:17:37 --> Utf8 Class Initialized
INFO - 2020-02-09 07:17:37 --> URI Class Initialized
INFO - 2020-02-09 07:17:37 --> Router Class Initialized
INFO - 2020-02-09 07:17:37 --> Output Class Initialized
INFO - 2020-02-09 07:17:37 --> Security Class Initialized
DEBUG - 2020-02-09 07:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:17:37 --> Input Class Initialized
INFO - 2020-02-09 07:17:37 --> Language Class Initialized
INFO - 2020-02-09 07:17:37 --> Language Class Initialized
INFO - 2020-02-09 07:17:37 --> Config Class Initialized
INFO - 2020-02-09 07:17:37 --> Loader Class Initialized
INFO - 2020-02-09 07:17:37 --> Helper loaded: url_helper
INFO - 2020-02-09 07:17:37 --> Helper loaded: file_helper
INFO - 2020-02-09 07:17:37 --> Helper loaded: form_helper
INFO - 2020-02-09 07:17:37 --> Helper loaded: my_helper
INFO - 2020-02-09 07:17:37 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:17:37 --> Controller Class Initialized
DEBUG - 2020-02-09 07:17:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-02-09 07:17:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:17:37 --> Final output sent to browser
DEBUG - 2020-02-09 07:17:37 --> Total execution time: 0.7791
INFO - 2020-02-09 07:17:38 --> Config Class Initialized
INFO - 2020-02-09 07:17:38 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:17:38 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:17:38 --> Utf8 Class Initialized
INFO - 2020-02-09 07:17:38 --> URI Class Initialized
INFO - 2020-02-09 07:17:38 --> Router Class Initialized
INFO - 2020-02-09 07:17:38 --> Output Class Initialized
INFO - 2020-02-09 07:17:38 --> Security Class Initialized
DEBUG - 2020-02-09 07:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:17:38 --> Input Class Initialized
INFO - 2020-02-09 07:17:38 --> Language Class Initialized
INFO - 2020-02-09 07:17:38 --> Language Class Initialized
INFO - 2020-02-09 07:17:38 --> Config Class Initialized
INFO - 2020-02-09 07:17:38 --> Loader Class Initialized
INFO - 2020-02-09 07:17:38 --> Helper loaded: url_helper
INFO - 2020-02-09 07:17:38 --> Helper loaded: file_helper
INFO - 2020-02-09 07:17:38 --> Helper loaded: form_helper
INFO - 2020-02-09 07:17:38 --> Helper loaded: my_helper
INFO - 2020-02-09 07:17:38 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:17:39 --> Controller Class Initialized
INFO - 2020-02-09 07:17:55 --> Config Class Initialized
INFO - 2020-02-09 07:17:55 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:17:55 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:17:55 --> Utf8 Class Initialized
INFO - 2020-02-09 07:17:55 --> URI Class Initialized
INFO - 2020-02-09 07:17:55 --> Router Class Initialized
INFO - 2020-02-09 07:17:55 --> Output Class Initialized
INFO - 2020-02-09 07:17:55 --> Security Class Initialized
DEBUG - 2020-02-09 07:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:17:56 --> Input Class Initialized
INFO - 2020-02-09 07:17:56 --> Language Class Initialized
INFO - 2020-02-09 07:17:56 --> Language Class Initialized
INFO - 2020-02-09 07:17:56 --> Config Class Initialized
INFO - 2020-02-09 07:17:56 --> Loader Class Initialized
INFO - 2020-02-09 07:17:56 --> Helper loaded: url_helper
INFO - 2020-02-09 07:17:56 --> Helper loaded: file_helper
INFO - 2020-02-09 07:17:56 --> Helper loaded: form_helper
INFO - 2020-02-09 07:17:56 --> Helper loaded: my_helper
INFO - 2020-02-09 07:17:56 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:17:56 --> Controller Class Initialized
INFO - 2020-02-09 07:17:56 --> Final output sent to browser
DEBUG - 2020-02-09 07:17:56 --> Total execution time: 0.7003
INFO - 2020-02-09 07:18:17 --> Config Class Initialized
INFO - 2020-02-09 07:18:17 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:18:17 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:18:17 --> Utf8 Class Initialized
INFO - 2020-02-09 07:18:17 --> URI Class Initialized
INFO - 2020-02-09 07:18:17 --> Router Class Initialized
INFO - 2020-02-09 07:18:17 --> Output Class Initialized
INFO - 2020-02-09 07:18:17 --> Security Class Initialized
DEBUG - 2020-02-09 07:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:18:17 --> Input Class Initialized
INFO - 2020-02-09 07:18:17 --> Language Class Initialized
INFO - 2020-02-09 07:18:17 --> Language Class Initialized
INFO - 2020-02-09 07:18:17 --> Config Class Initialized
INFO - 2020-02-09 07:18:17 --> Loader Class Initialized
INFO - 2020-02-09 07:18:17 --> Helper loaded: url_helper
INFO - 2020-02-09 07:18:17 --> Helper loaded: file_helper
INFO - 2020-02-09 07:18:17 --> Helper loaded: form_helper
INFO - 2020-02-09 07:18:18 --> Helper loaded: my_helper
INFO - 2020-02-09 07:18:18 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:18:18 --> Controller Class Initialized
DEBUG - 2020-02-09 07:18:18 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_mapel/views/list.php
DEBUG - 2020-02-09 07:18:18 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:18:18 --> Final output sent to browser
DEBUG - 2020-02-09 07:18:18 --> Total execution time: 1.0022
INFO - 2020-02-09 07:18:18 --> Config Class Initialized
INFO - 2020-02-09 07:18:19 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:18:19 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:18:19 --> Utf8 Class Initialized
INFO - 2020-02-09 07:18:19 --> URI Class Initialized
INFO - 2020-02-09 07:18:19 --> Router Class Initialized
INFO - 2020-02-09 07:18:19 --> Output Class Initialized
INFO - 2020-02-09 07:18:19 --> Security Class Initialized
DEBUG - 2020-02-09 07:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:18:19 --> Input Class Initialized
INFO - 2020-02-09 07:18:19 --> Language Class Initialized
INFO - 2020-02-09 07:18:19 --> Language Class Initialized
INFO - 2020-02-09 07:18:19 --> Config Class Initialized
INFO - 2020-02-09 07:18:19 --> Loader Class Initialized
INFO - 2020-02-09 07:18:19 --> Helper loaded: url_helper
INFO - 2020-02-09 07:18:19 --> Helper loaded: file_helper
INFO - 2020-02-09 07:18:19 --> Helper loaded: form_helper
INFO - 2020-02-09 07:18:20 --> Helper loaded: my_helper
INFO - 2020-02-09 07:18:20 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:18:20 --> Controller Class Initialized
INFO - 2020-02-09 07:18:30 --> Config Class Initialized
INFO - 2020-02-09 07:18:30 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:18:30 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:18:30 --> Utf8 Class Initialized
INFO - 2020-02-09 07:18:30 --> URI Class Initialized
INFO - 2020-02-09 07:18:30 --> Router Class Initialized
INFO - 2020-02-09 07:18:30 --> Output Class Initialized
INFO - 2020-02-09 07:18:30 --> Security Class Initialized
DEBUG - 2020-02-09 07:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:18:30 --> Input Class Initialized
INFO - 2020-02-09 07:18:30 --> Language Class Initialized
INFO - 2020-02-09 07:18:30 --> Language Class Initialized
INFO - 2020-02-09 07:18:30 --> Config Class Initialized
INFO - 2020-02-09 07:18:30 --> Loader Class Initialized
INFO - 2020-02-09 07:18:30 --> Helper loaded: url_helper
INFO - 2020-02-09 07:18:30 --> Helper loaded: file_helper
INFO - 2020-02-09 07:18:30 --> Helper loaded: form_helper
INFO - 2020-02-09 07:18:30 --> Helper loaded: my_helper
INFO - 2020-02-09 07:18:30 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:18:31 --> Controller Class Initialized
INFO - 2020-02-09 07:18:31 --> Final output sent to browser
DEBUG - 2020-02-09 07:18:31 --> Total execution time: 0.6762
INFO - 2020-02-09 07:18:55 --> Config Class Initialized
INFO - 2020-02-09 07:18:55 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:18:55 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:18:55 --> Utf8 Class Initialized
INFO - 2020-02-09 07:18:55 --> URI Class Initialized
INFO - 2020-02-09 07:18:55 --> Router Class Initialized
INFO - 2020-02-09 07:18:55 --> Output Class Initialized
INFO - 2020-02-09 07:18:55 --> Security Class Initialized
DEBUG - 2020-02-09 07:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:18:56 --> Input Class Initialized
INFO - 2020-02-09 07:18:56 --> Language Class Initialized
INFO - 2020-02-09 07:18:56 --> Language Class Initialized
INFO - 2020-02-09 07:18:56 --> Config Class Initialized
INFO - 2020-02-09 07:18:56 --> Loader Class Initialized
INFO - 2020-02-09 07:18:56 --> Helper loaded: url_helper
INFO - 2020-02-09 07:18:56 --> Helper loaded: file_helper
INFO - 2020-02-09 07:18:56 --> Helper loaded: form_helper
INFO - 2020-02-09 07:18:56 --> Helper loaded: my_helper
INFO - 2020-02-09 07:18:56 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:18:56 --> Controller Class Initialized
INFO - 2020-02-09 07:18:56 --> Final output sent to browser
DEBUG - 2020-02-09 07:18:56 --> Total execution time: 0.7139
INFO - 2020-02-09 07:19:34 --> Config Class Initialized
INFO - 2020-02-09 07:19:35 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:19:35 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:19:35 --> Utf8 Class Initialized
INFO - 2020-02-09 07:19:35 --> URI Class Initialized
INFO - 2020-02-09 07:19:35 --> Router Class Initialized
INFO - 2020-02-09 07:19:35 --> Output Class Initialized
INFO - 2020-02-09 07:19:35 --> Security Class Initialized
DEBUG - 2020-02-09 07:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:19:35 --> Input Class Initialized
INFO - 2020-02-09 07:19:35 --> Language Class Initialized
INFO - 2020-02-09 07:19:35 --> Language Class Initialized
INFO - 2020-02-09 07:19:35 --> Config Class Initialized
INFO - 2020-02-09 07:19:35 --> Loader Class Initialized
INFO - 2020-02-09 07:19:35 --> Helper loaded: url_helper
INFO - 2020-02-09 07:19:35 --> Helper loaded: file_helper
INFO - 2020-02-09 07:19:35 --> Helper loaded: form_helper
INFO - 2020-02-09 07:19:35 --> Helper loaded: my_helper
INFO - 2020-02-09 07:19:35 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:19:35 --> Controller Class Initialized
DEBUG - 2020-02-09 07:19:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_ekstra/views/list.php
DEBUG - 2020-02-09 07:19:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:19:35 --> Final output sent to browser
DEBUG - 2020-02-09 07:19:35 --> Total execution time: 0.7773
INFO - 2020-02-09 07:19:36 --> Config Class Initialized
INFO - 2020-02-09 07:19:36 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:19:36 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:19:36 --> Utf8 Class Initialized
INFO - 2020-02-09 07:19:36 --> URI Class Initialized
INFO - 2020-02-09 07:19:36 --> Router Class Initialized
INFO - 2020-02-09 07:19:36 --> Output Class Initialized
INFO - 2020-02-09 07:19:36 --> Security Class Initialized
DEBUG - 2020-02-09 07:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:19:36 --> Input Class Initialized
INFO - 2020-02-09 07:19:36 --> Language Class Initialized
INFO - 2020-02-09 07:19:36 --> Language Class Initialized
INFO - 2020-02-09 07:19:36 --> Config Class Initialized
INFO - 2020-02-09 07:19:36 --> Loader Class Initialized
INFO - 2020-02-09 07:19:36 --> Helper loaded: url_helper
INFO - 2020-02-09 07:19:36 --> Helper loaded: file_helper
INFO - 2020-02-09 07:19:37 --> Helper loaded: form_helper
INFO - 2020-02-09 07:19:37 --> Helper loaded: my_helper
INFO - 2020-02-09 07:19:37 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:19:37 --> Controller Class Initialized
INFO - 2020-02-09 07:19:46 --> Config Class Initialized
INFO - 2020-02-09 07:19:46 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:19:46 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:19:46 --> Utf8 Class Initialized
INFO - 2020-02-09 07:19:46 --> URI Class Initialized
INFO - 2020-02-09 07:19:46 --> Router Class Initialized
INFO - 2020-02-09 07:19:46 --> Output Class Initialized
INFO - 2020-02-09 07:19:46 --> Security Class Initialized
DEBUG - 2020-02-09 07:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:19:46 --> Input Class Initialized
INFO - 2020-02-09 07:19:47 --> Language Class Initialized
INFO - 2020-02-09 07:19:47 --> Language Class Initialized
INFO - 2020-02-09 07:19:47 --> Config Class Initialized
INFO - 2020-02-09 07:19:47 --> Loader Class Initialized
INFO - 2020-02-09 07:19:47 --> Helper loaded: url_helper
INFO - 2020-02-09 07:19:47 --> Helper loaded: file_helper
INFO - 2020-02-09 07:19:47 --> Helper loaded: form_helper
INFO - 2020-02-09 07:19:47 --> Helper loaded: my_helper
INFO - 2020-02-09 07:19:47 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:19:47 --> Controller Class Initialized
INFO - 2020-02-09 07:19:47 --> Final output sent to browser
DEBUG - 2020-02-09 07:19:47 --> Total execution time: 0.6753
INFO - 2020-02-09 07:20:05 --> Config Class Initialized
INFO - 2020-02-09 07:20:05 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:20:05 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:20:05 --> Utf8 Class Initialized
INFO - 2020-02-09 07:20:05 --> URI Class Initialized
INFO - 2020-02-09 07:20:05 --> Router Class Initialized
INFO - 2020-02-09 07:20:05 --> Output Class Initialized
INFO - 2020-02-09 07:20:05 --> Security Class Initialized
DEBUG - 2020-02-09 07:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:20:05 --> Input Class Initialized
INFO - 2020-02-09 07:20:05 --> Language Class Initialized
INFO - 2020-02-09 07:20:05 --> Language Class Initialized
INFO - 2020-02-09 07:20:05 --> Config Class Initialized
INFO - 2020-02-09 07:20:05 --> Loader Class Initialized
INFO - 2020-02-09 07:20:05 --> Helper loaded: url_helper
INFO - 2020-02-09 07:20:05 --> Helper loaded: file_helper
INFO - 2020-02-09 07:20:05 --> Helper loaded: form_helper
INFO - 2020-02-09 07:20:06 --> Helper loaded: my_helper
INFO - 2020-02-09 07:20:06 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:20:06 --> Controller Class Initialized
DEBUG - 2020-02-09 07:20:06 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-09 07:20:06 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:20:06 --> Final output sent to browser
DEBUG - 2020-02-09 07:20:06 --> Total execution time: 0.8827
INFO - 2020-02-09 07:20:06 --> Config Class Initialized
INFO - 2020-02-09 07:20:06 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:20:07 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:20:07 --> Utf8 Class Initialized
INFO - 2020-02-09 07:20:07 --> URI Class Initialized
INFO - 2020-02-09 07:20:07 --> Router Class Initialized
INFO - 2020-02-09 07:20:07 --> Output Class Initialized
INFO - 2020-02-09 07:20:07 --> Security Class Initialized
DEBUG - 2020-02-09 07:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:20:07 --> Input Class Initialized
INFO - 2020-02-09 07:20:07 --> Language Class Initialized
INFO - 2020-02-09 07:20:07 --> Language Class Initialized
INFO - 2020-02-09 07:20:07 --> Config Class Initialized
INFO - 2020-02-09 07:20:07 --> Loader Class Initialized
INFO - 2020-02-09 07:20:07 --> Helper loaded: url_helper
INFO - 2020-02-09 07:20:07 --> Helper loaded: file_helper
INFO - 2020-02-09 07:20:07 --> Helper loaded: form_helper
INFO - 2020-02-09 07:20:07 --> Helper loaded: my_helper
INFO - 2020-02-09 07:20:07 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:20:07 --> Controller Class Initialized
INFO - 2020-02-09 07:20:30 --> Config Class Initialized
INFO - 2020-02-09 07:20:30 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:20:30 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:20:30 --> Utf8 Class Initialized
INFO - 2020-02-09 07:20:30 --> URI Class Initialized
INFO - 2020-02-09 07:20:31 --> Router Class Initialized
INFO - 2020-02-09 07:20:31 --> Output Class Initialized
INFO - 2020-02-09 07:20:31 --> Security Class Initialized
DEBUG - 2020-02-09 07:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:20:31 --> Input Class Initialized
INFO - 2020-02-09 07:20:31 --> Language Class Initialized
INFO - 2020-02-09 07:20:31 --> Language Class Initialized
INFO - 2020-02-09 07:20:31 --> Config Class Initialized
INFO - 2020-02-09 07:20:31 --> Loader Class Initialized
INFO - 2020-02-09 07:20:31 --> Helper loaded: url_helper
INFO - 2020-02-09 07:20:31 --> Helper loaded: file_helper
INFO - 2020-02-09 07:20:31 --> Helper loaded: form_helper
INFO - 2020-02-09 07:20:31 --> Helper loaded: my_helper
INFO - 2020-02-09 07:20:31 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:20:31 --> Controller Class Initialized
INFO - 2020-02-09 07:20:31 --> Database Utility Class Initialized
INFO - 2020-02-09 07:20:31 --> Zip Compression Class Initialized
ERROR - 2020-02-09 07:20:31 --> Severity: Runtime Notice --> Only variables should be assigned by reference E:\xampp\htdocs\_2020\myraport\application\modules\backup_db\controllers\Backup_db.php 88
INFO - 2020-02-09 07:20:31 --> Config Class Initialized
INFO - 2020-02-09 07:20:32 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:20:32 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:20:32 --> Utf8 Class Initialized
INFO - 2020-02-09 07:20:32 --> URI Class Initialized
INFO - 2020-02-09 07:20:32 --> Router Class Initialized
INFO - 2020-02-09 07:20:32 --> Output Class Initialized
INFO - 2020-02-09 07:20:32 --> Security Class Initialized
DEBUG - 2020-02-09 07:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:20:32 --> Input Class Initialized
INFO - 2020-02-09 07:20:32 --> Language Class Initialized
INFO - 2020-02-09 07:20:32 --> Language Class Initialized
INFO - 2020-02-09 07:20:32 --> Config Class Initialized
INFO - 2020-02-09 07:20:32 --> Loader Class Initialized
INFO - 2020-02-09 07:20:32 --> Helper loaded: url_helper
INFO - 2020-02-09 07:20:32 --> Helper loaded: file_helper
INFO - 2020-02-09 07:20:32 --> Helper loaded: form_helper
INFO - 2020-02-09 07:20:32 --> Helper loaded: my_helper
INFO - 2020-02-09 07:20:32 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:20:32 --> Controller Class Initialized
DEBUG - 2020-02-09 07:20:32 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-09 07:20:32 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:20:32 --> Final output sent to browser
DEBUG - 2020-02-09 07:20:32 --> Total execution time: 0.6913
INFO - 2020-02-09 07:20:36 --> Config Class Initialized
INFO - 2020-02-09 07:20:36 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:20:36 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:20:36 --> Utf8 Class Initialized
INFO - 2020-02-09 07:20:36 --> URI Class Initialized
INFO - 2020-02-09 07:20:36 --> Router Class Initialized
INFO - 2020-02-09 07:20:36 --> Output Class Initialized
INFO - 2020-02-09 07:20:37 --> Security Class Initialized
DEBUG - 2020-02-09 07:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:20:37 --> Input Class Initialized
INFO - 2020-02-09 07:20:37 --> Language Class Initialized
INFO - 2020-02-09 07:20:37 --> Language Class Initialized
INFO - 2020-02-09 07:20:37 --> Config Class Initialized
INFO - 2020-02-09 07:20:37 --> Loader Class Initialized
INFO - 2020-02-09 07:20:37 --> Helper loaded: url_helper
INFO - 2020-02-09 07:20:37 --> Helper loaded: file_helper
INFO - 2020-02-09 07:20:37 --> Helper loaded: form_helper
INFO - 2020-02-09 07:20:37 --> Helper loaded: my_helper
INFO - 2020-02-09 07:20:37 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:20:37 --> Controller Class Initialized
INFO - 2020-02-09 07:20:53 --> Config Class Initialized
INFO - 2020-02-09 07:20:54 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:20:54 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:20:54 --> Utf8 Class Initialized
INFO - 2020-02-09 07:20:54 --> URI Class Initialized
INFO - 2020-02-09 07:20:54 --> Router Class Initialized
INFO - 2020-02-09 07:20:54 --> Output Class Initialized
INFO - 2020-02-09 07:20:54 --> Security Class Initialized
DEBUG - 2020-02-09 07:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:20:54 --> Input Class Initialized
INFO - 2020-02-09 07:20:54 --> Language Class Initialized
INFO - 2020-02-09 07:20:54 --> Language Class Initialized
INFO - 2020-02-09 07:20:54 --> Config Class Initialized
INFO - 2020-02-09 07:20:54 --> Loader Class Initialized
INFO - 2020-02-09 07:20:54 --> Helper loaded: url_helper
INFO - 2020-02-09 07:20:54 --> Helper loaded: file_helper
INFO - 2020-02-09 07:20:54 --> Helper loaded: form_helper
INFO - 2020-02-09 07:20:54 --> Helper loaded: my_helper
INFO - 2020-02-09 07:20:54 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:20:54 --> Controller Class Initialized
DEBUG - 2020-02-09 07:20:54 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-09 07:20:55 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:20:55 --> Final output sent to browser
DEBUG - 2020-02-09 07:20:55 --> Total execution time: 1.0426
INFO - 2020-02-09 07:20:55 --> Config Class Initialized
INFO - 2020-02-09 07:20:55 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:20:55 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:20:56 --> Utf8 Class Initialized
INFO - 2020-02-09 07:20:56 --> URI Class Initialized
INFO - 2020-02-09 07:20:56 --> Router Class Initialized
INFO - 2020-02-09 07:20:56 --> Output Class Initialized
INFO - 2020-02-09 07:20:56 --> Security Class Initialized
DEBUG - 2020-02-09 07:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:20:56 --> Input Class Initialized
INFO - 2020-02-09 07:20:56 --> Language Class Initialized
INFO - 2020-02-09 07:20:56 --> Language Class Initialized
INFO - 2020-02-09 07:20:56 --> Config Class Initialized
INFO - 2020-02-09 07:20:56 --> Loader Class Initialized
INFO - 2020-02-09 07:20:56 --> Helper loaded: url_helper
INFO - 2020-02-09 07:20:56 --> Helper loaded: file_helper
INFO - 2020-02-09 07:20:56 --> Helper loaded: form_helper
INFO - 2020-02-09 07:20:56 --> Helper loaded: my_helper
INFO - 2020-02-09 07:20:56 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:20:56 --> Controller Class Initialized
INFO - 2020-02-09 07:21:04 --> Config Class Initialized
INFO - 2020-02-09 07:21:04 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:21:04 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:21:04 --> Utf8 Class Initialized
INFO - 2020-02-09 07:21:04 --> URI Class Initialized
INFO - 2020-02-09 07:21:04 --> Router Class Initialized
INFO - 2020-02-09 07:21:04 --> Output Class Initialized
INFO - 2020-02-09 07:21:04 --> Security Class Initialized
DEBUG - 2020-02-09 07:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:21:05 --> Input Class Initialized
INFO - 2020-02-09 07:21:05 --> Language Class Initialized
INFO - 2020-02-09 07:21:05 --> Language Class Initialized
INFO - 2020-02-09 07:21:05 --> Config Class Initialized
INFO - 2020-02-09 07:21:05 --> Loader Class Initialized
INFO - 2020-02-09 07:21:05 --> Helper loaded: url_helper
INFO - 2020-02-09 07:21:05 --> Helper loaded: file_helper
INFO - 2020-02-09 07:21:05 --> Helper loaded: form_helper
INFO - 2020-02-09 07:21:05 --> Helper loaded: my_helper
INFO - 2020-02-09 07:21:05 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:21:05 --> Controller Class Initialized
DEBUG - 2020-02-09 07:21:05 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-09 07:21:05 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:21:05 --> Final output sent to browser
DEBUG - 2020-02-09 07:21:05 --> Total execution time: 1.0223
INFO - 2020-02-09 07:21:06 --> Config Class Initialized
INFO - 2020-02-09 07:21:06 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:21:06 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:21:06 --> Utf8 Class Initialized
INFO - 2020-02-09 07:21:06 --> URI Class Initialized
INFO - 2020-02-09 07:21:06 --> Router Class Initialized
INFO - 2020-02-09 07:21:06 --> Output Class Initialized
INFO - 2020-02-09 07:21:06 --> Security Class Initialized
DEBUG - 2020-02-09 07:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:21:06 --> Input Class Initialized
INFO - 2020-02-09 07:21:06 --> Language Class Initialized
INFO - 2020-02-09 07:21:06 --> Language Class Initialized
INFO - 2020-02-09 07:21:06 --> Config Class Initialized
INFO - 2020-02-09 07:21:06 --> Loader Class Initialized
INFO - 2020-02-09 07:21:06 --> Helper loaded: url_helper
INFO - 2020-02-09 07:21:07 --> Helper loaded: file_helper
INFO - 2020-02-09 07:21:07 --> Helper loaded: form_helper
INFO - 2020-02-09 07:21:07 --> Helper loaded: my_helper
INFO - 2020-02-09 07:21:07 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:21:07 --> Controller Class Initialized
INFO - 2020-02-09 07:21:21 --> Config Class Initialized
INFO - 2020-02-09 07:21:21 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:21:21 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:21:21 --> Utf8 Class Initialized
INFO - 2020-02-09 07:21:21 --> URI Class Initialized
INFO - 2020-02-09 07:21:21 --> Router Class Initialized
INFO - 2020-02-09 07:21:22 --> Output Class Initialized
INFO - 2020-02-09 07:21:22 --> Security Class Initialized
DEBUG - 2020-02-09 07:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:21:22 --> Input Class Initialized
INFO - 2020-02-09 07:21:22 --> Language Class Initialized
INFO - 2020-02-09 07:21:22 --> Language Class Initialized
INFO - 2020-02-09 07:21:22 --> Config Class Initialized
INFO - 2020-02-09 07:21:22 --> Loader Class Initialized
INFO - 2020-02-09 07:21:22 --> Helper loaded: url_helper
INFO - 2020-02-09 07:21:22 --> Helper loaded: file_helper
INFO - 2020-02-09 07:21:22 --> Helper loaded: form_helper
INFO - 2020-02-09 07:21:22 --> Helper loaded: my_helper
INFO - 2020-02-09 07:21:22 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:21:22 --> Controller Class Initialized
INFO - 2020-02-09 07:21:22 --> Final output sent to browser
DEBUG - 2020-02-09 07:21:22 --> Total execution time: 0.9063
INFO - 2020-02-09 07:21:34 --> Config Class Initialized
INFO - 2020-02-09 07:21:34 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:21:34 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:21:34 --> Utf8 Class Initialized
INFO - 2020-02-09 07:21:34 --> URI Class Initialized
INFO - 2020-02-09 07:21:34 --> Router Class Initialized
INFO - 2020-02-09 07:21:34 --> Output Class Initialized
INFO - 2020-02-09 07:21:34 --> Security Class Initialized
DEBUG - 2020-02-09 07:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:21:34 --> Input Class Initialized
INFO - 2020-02-09 07:21:34 --> Language Class Initialized
INFO - 2020-02-09 07:21:34 --> Language Class Initialized
INFO - 2020-02-09 07:21:34 --> Config Class Initialized
INFO - 2020-02-09 07:21:34 --> Loader Class Initialized
INFO - 2020-02-09 07:21:34 --> Helper loaded: url_helper
INFO - 2020-02-09 07:21:35 --> Helper loaded: file_helper
INFO - 2020-02-09 07:21:35 --> Helper loaded: form_helper
INFO - 2020-02-09 07:21:35 --> Helper loaded: my_helper
INFO - 2020-02-09 07:21:35 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:21:35 --> Controller Class Initialized
INFO - 2020-02-09 07:21:35 --> Final output sent to browser
DEBUG - 2020-02-09 07:21:35 --> Total execution time: 0.8124
INFO - 2020-02-09 07:21:56 --> Config Class Initialized
INFO - 2020-02-09 07:21:56 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:21:56 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:21:56 --> Utf8 Class Initialized
INFO - 2020-02-09 07:21:56 --> URI Class Initialized
INFO - 2020-02-09 07:21:56 --> Router Class Initialized
INFO - 2020-02-09 07:21:56 --> Output Class Initialized
INFO - 2020-02-09 07:21:56 --> Security Class Initialized
DEBUG - 2020-02-09 07:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:21:56 --> Input Class Initialized
INFO - 2020-02-09 07:21:56 --> Language Class Initialized
INFO - 2020-02-09 07:21:56 --> Language Class Initialized
INFO - 2020-02-09 07:21:56 --> Config Class Initialized
INFO - 2020-02-09 07:21:56 --> Loader Class Initialized
INFO - 2020-02-09 07:21:56 --> Helper loaded: url_helper
INFO - 2020-02-09 07:21:56 --> Helper loaded: file_helper
INFO - 2020-02-09 07:21:56 --> Helper loaded: form_helper
INFO - 2020-02-09 07:21:56 --> Helper loaded: my_helper
INFO - 2020-02-09 07:21:56 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:21:56 --> Controller Class Initialized
INFO - 2020-02-09 07:21:56 --> Final output sent to browser
DEBUG - 2020-02-09 07:21:56 --> Total execution time: 0.6490
INFO - 2020-02-09 07:21:56 --> Config Class Initialized
INFO - 2020-02-09 07:21:57 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:21:57 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:21:57 --> Utf8 Class Initialized
INFO - 2020-02-09 07:21:57 --> URI Class Initialized
INFO - 2020-02-09 07:21:57 --> Router Class Initialized
INFO - 2020-02-09 07:21:57 --> Output Class Initialized
INFO - 2020-02-09 07:21:57 --> Security Class Initialized
DEBUG - 2020-02-09 07:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:21:57 --> Input Class Initialized
INFO - 2020-02-09 07:21:57 --> Language Class Initialized
INFO - 2020-02-09 07:21:57 --> Language Class Initialized
INFO - 2020-02-09 07:21:57 --> Config Class Initialized
INFO - 2020-02-09 07:21:57 --> Loader Class Initialized
INFO - 2020-02-09 07:21:57 --> Helper loaded: url_helper
INFO - 2020-02-09 07:21:57 --> Helper loaded: file_helper
INFO - 2020-02-09 07:21:57 --> Helper loaded: form_helper
INFO - 2020-02-09 07:21:57 --> Helper loaded: my_helper
INFO - 2020-02-09 07:21:57 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:21:57 --> Controller Class Initialized
INFO - 2020-02-09 07:22:25 --> Config Class Initialized
INFO - 2020-02-09 07:22:25 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:22:25 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:22:25 --> Utf8 Class Initialized
INFO - 2020-02-09 07:22:25 --> URI Class Initialized
INFO - 2020-02-09 07:22:25 --> Router Class Initialized
INFO - 2020-02-09 07:22:25 --> Output Class Initialized
INFO - 2020-02-09 07:22:25 --> Security Class Initialized
DEBUG - 2020-02-09 07:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:22:25 --> Input Class Initialized
INFO - 2020-02-09 07:22:25 --> Language Class Initialized
INFO - 2020-02-09 07:22:25 --> Language Class Initialized
INFO - 2020-02-09 07:22:25 --> Config Class Initialized
INFO - 2020-02-09 07:22:25 --> Loader Class Initialized
INFO - 2020-02-09 07:22:25 --> Helper loaded: url_helper
INFO - 2020-02-09 07:22:25 --> Helper loaded: file_helper
INFO - 2020-02-09 07:22:25 --> Helper loaded: form_helper
INFO - 2020-02-09 07:22:25 --> Helper loaded: my_helper
INFO - 2020-02-09 07:22:25 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:22:25 --> Controller Class Initialized
INFO - 2020-02-09 07:22:25 --> Final output sent to browser
DEBUG - 2020-02-09 07:22:25 --> Total execution time: 0.5298
INFO - 2020-02-09 07:22:25 --> Config Class Initialized
INFO - 2020-02-09 07:22:25 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:22:25 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:22:25 --> Utf8 Class Initialized
INFO - 2020-02-09 07:22:25 --> URI Class Initialized
INFO - 2020-02-09 07:22:25 --> Router Class Initialized
INFO - 2020-02-09 07:22:25 --> Output Class Initialized
INFO - 2020-02-09 07:22:26 --> Security Class Initialized
DEBUG - 2020-02-09 07:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:22:26 --> Input Class Initialized
INFO - 2020-02-09 07:22:26 --> Language Class Initialized
INFO - 2020-02-09 07:22:26 --> Language Class Initialized
INFO - 2020-02-09 07:22:26 --> Config Class Initialized
INFO - 2020-02-09 07:22:26 --> Loader Class Initialized
INFO - 2020-02-09 07:22:26 --> Helper loaded: url_helper
INFO - 2020-02-09 07:22:26 --> Helper loaded: file_helper
INFO - 2020-02-09 07:22:26 --> Helper loaded: form_helper
INFO - 2020-02-09 07:22:26 --> Helper loaded: my_helper
INFO - 2020-02-09 07:22:26 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:22:26 --> Controller Class Initialized
INFO - 2020-02-09 07:22:44 --> Config Class Initialized
INFO - 2020-02-09 07:22:44 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:22:44 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:22:44 --> Utf8 Class Initialized
INFO - 2020-02-09 07:22:44 --> URI Class Initialized
INFO - 2020-02-09 07:22:44 --> Router Class Initialized
INFO - 2020-02-09 07:22:44 --> Output Class Initialized
INFO - 2020-02-09 07:22:44 --> Security Class Initialized
DEBUG - 2020-02-09 07:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:22:44 --> Input Class Initialized
INFO - 2020-02-09 07:22:44 --> Language Class Initialized
INFO - 2020-02-09 07:22:44 --> Language Class Initialized
INFO - 2020-02-09 07:22:44 --> Config Class Initialized
INFO - 2020-02-09 07:22:44 --> Loader Class Initialized
INFO - 2020-02-09 07:22:44 --> Helper loaded: url_helper
INFO - 2020-02-09 07:22:44 --> Helper loaded: file_helper
INFO - 2020-02-09 07:22:44 --> Helper loaded: form_helper
INFO - 2020-02-09 07:22:44 --> Helper loaded: my_helper
INFO - 2020-02-09 07:22:44 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:22:45 --> Controller Class Initialized
INFO - 2020-02-09 07:22:45 --> Final output sent to browser
DEBUG - 2020-02-09 07:22:45 --> Total execution time: 0.5263
INFO - 2020-02-09 07:22:45 --> Config Class Initialized
INFO - 2020-02-09 07:22:45 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:22:45 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:22:45 --> Utf8 Class Initialized
INFO - 2020-02-09 07:22:45 --> URI Class Initialized
INFO - 2020-02-09 07:22:45 --> Router Class Initialized
INFO - 2020-02-09 07:22:45 --> Output Class Initialized
INFO - 2020-02-09 07:22:45 --> Security Class Initialized
DEBUG - 2020-02-09 07:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:22:45 --> Input Class Initialized
INFO - 2020-02-09 07:22:45 --> Language Class Initialized
INFO - 2020-02-09 07:22:45 --> Language Class Initialized
INFO - 2020-02-09 07:22:45 --> Config Class Initialized
INFO - 2020-02-09 07:22:45 --> Loader Class Initialized
INFO - 2020-02-09 07:22:45 --> Helper loaded: url_helper
INFO - 2020-02-09 07:22:45 --> Helper loaded: file_helper
INFO - 2020-02-09 07:22:45 --> Helper loaded: form_helper
INFO - 2020-02-09 07:22:45 --> Helper loaded: my_helper
INFO - 2020-02-09 07:22:45 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:22:45 --> Controller Class Initialized
INFO - 2020-02-09 07:22:56 --> Config Class Initialized
INFO - 2020-02-09 07:22:56 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:22:56 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:22:56 --> Utf8 Class Initialized
INFO - 2020-02-09 07:22:56 --> URI Class Initialized
INFO - 2020-02-09 07:22:56 --> Router Class Initialized
INFO - 2020-02-09 07:22:56 --> Output Class Initialized
INFO - 2020-02-09 07:22:56 --> Security Class Initialized
DEBUG - 2020-02-09 07:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:22:56 --> Input Class Initialized
INFO - 2020-02-09 07:22:56 --> Language Class Initialized
INFO - 2020-02-09 07:22:56 --> Language Class Initialized
INFO - 2020-02-09 07:22:56 --> Config Class Initialized
INFO - 2020-02-09 07:22:56 --> Loader Class Initialized
INFO - 2020-02-09 07:22:56 --> Helper loaded: url_helper
INFO - 2020-02-09 07:22:56 --> Helper loaded: file_helper
INFO - 2020-02-09 07:22:56 --> Helper loaded: form_helper
INFO - 2020-02-09 07:22:56 --> Helper loaded: my_helper
INFO - 2020-02-09 07:22:56 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:22:56 --> Controller Class Initialized
DEBUG - 2020-02-09 07:22:57 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-09 07:22:57 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:22:57 --> Final output sent to browser
DEBUG - 2020-02-09 07:22:57 --> Total execution time: 0.8038
INFO - 2020-02-09 07:23:24 --> Config Class Initialized
INFO - 2020-02-09 07:23:24 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:23:24 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:23:24 --> Utf8 Class Initialized
INFO - 2020-02-09 07:23:24 --> URI Class Initialized
INFO - 2020-02-09 07:23:24 --> Router Class Initialized
INFO - 2020-02-09 07:23:24 --> Output Class Initialized
INFO - 2020-02-09 07:23:24 --> Security Class Initialized
DEBUG - 2020-02-09 07:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:23:24 --> Input Class Initialized
INFO - 2020-02-09 07:23:24 --> Language Class Initialized
INFO - 2020-02-09 07:23:24 --> Language Class Initialized
INFO - 2020-02-09 07:23:24 --> Config Class Initialized
INFO - 2020-02-09 07:23:24 --> Loader Class Initialized
INFO - 2020-02-09 07:23:24 --> Helper loaded: url_helper
INFO - 2020-02-09 07:23:24 --> Helper loaded: file_helper
INFO - 2020-02-09 07:23:24 --> Helper loaded: form_helper
INFO - 2020-02-09 07:23:24 --> Helper loaded: my_helper
INFO - 2020-02-09 07:23:24 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:23:24 --> Controller Class Initialized
DEBUG - 2020-02-09 07:23:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/list.php
DEBUG - 2020-02-09 07:23:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:23:25 --> Final output sent to browser
DEBUG - 2020-02-09 07:23:25 --> Total execution time: 0.8532
INFO - 2020-02-09 07:23:25 --> Config Class Initialized
INFO - 2020-02-09 07:23:25 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:23:26 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:23:26 --> Utf8 Class Initialized
INFO - 2020-02-09 07:23:26 --> URI Class Initialized
INFO - 2020-02-09 07:23:26 --> Router Class Initialized
INFO - 2020-02-09 07:23:26 --> Output Class Initialized
INFO - 2020-02-09 07:23:26 --> Security Class Initialized
DEBUG - 2020-02-09 07:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:23:26 --> Input Class Initialized
INFO - 2020-02-09 07:23:26 --> Language Class Initialized
INFO - 2020-02-09 07:23:26 --> Language Class Initialized
INFO - 2020-02-09 07:23:26 --> Config Class Initialized
INFO - 2020-02-09 07:23:26 --> Loader Class Initialized
INFO - 2020-02-09 07:23:26 --> Helper loaded: url_helper
INFO - 2020-02-09 07:23:26 --> Helper loaded: file_helper
INFO - 2020-02-09 07:23:27 --> Helper loaded: form_helper
INFO - 2020-02-09 07:23:27 --> Helper loaded: my_helper
INFO - 2020-02-09 07:23:27 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:23:27 --> Controller Class Initialized
INFO - 2020-02-09 07:23:53 --> Config Class Initialized
INFO - 2020-02-09 07:23:53 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:23:53 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:23:53 --> Utf8 Class Initialized
INFO - 2020-02-09 07:23:53 --> URI Class Initialized
INFO - 2020-02-09 07:23:53 --> Router Class Initialized
INFO - 2020-02-09 07:23:53 --> Output Class Initialized
INFO - 2020-02-09 07:23:53 --> Security Class Initialized
DEBUG - 2020-02-09 07:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:23:54 --> Input Class Initialized
INFO - 2020-02-09 07:23:54 --> Language Class Initialized
INFO - 2020-02-09 07:23:54 --> Language Class Initialized
INFO - 2020-02-09 07:23:54 --> Config Class Initialized
INFO - 2020-02-09 07:23:54 --> Loader Class Initialized
INFO - 2020-02-09 07:23:54 --> Helper loaded: url_helper
INFO - 2020-02-09 07:23:54 --> Helper loaded: file_helper
INFO - 2020-02-09 07:23:54 --> Helper loaded: form_helper
INFO - 2020-02-09 07:23:54 --> Helper loaded: my_helper
INFO - 2020-02-09 07:23:54 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:23:54 --> Controller Class Initialized
DEBUG - 2020-02-09 07:23:54 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/form.php
DEBUG - 2020-02-09 07:23:54 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:23:54 --> Final output sent to browser
DEBUG - 2020-02-09 07:23:54 --> Total execution time: 0.8312
INFO - 2020-02-09 07:24:21 --> Config Class Initialized
INFO - 2020-02-09 07:24:21 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:24:21 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:24:21 --> Utf8 Class Initialized
INFO - 2020-02-09 07:24:21 --> URI Class Initialized
INFO - 2020-02-09 07:24:21 --> Router Class Initialized
INFO - 2020-02-09 07:24:21 --> Output Class Initialized
INFO - 2020-02-09 07:24:21 --> Security Class Initialized
DEBUG - 2020-02-09 07:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:24:21 --> Input Class Initialized
INFO - 2020-02-09 07:24:21 --> Language Class Initialized
INFO - 2020-02-09 07:24:21 --> Language Class Initialized
INFO - 2020-02-09 07:24:21 --> Config Class Initialized
INFO - 2020-02-09 07:24:21 --> Loader Class Initialized
INFO - 2020-02-09 07:24:22 --> Helper loaded: url_helper
INFO - 2020-02-09 07:24:22 --> Helper loaded: file_helper
INFO - 2020-02-09 07:24:22 --> Helper loaded: form_helper
INFO - 2020-02-09 07:24:22 --> Helper loaded: my_helper
INFO - 2020-02-09 07:24:22 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:24:22 --> Controller Class Initialized
DEBUG - 2020-02-09 07:24:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/list.php
DEBUG - 2020-02-09 07:24:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:24:22 --> Final output sent to browser
DEBUG - 2020-02-09 07:24:22 --> Total execution time: 1.4663
INFO - 2020-02-09 07:24:23 --> Config Class Initialized
INFO - 2020-02-09 07:24:23 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:24:23 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:24:23 --> Utf8 Class Initialized
INFO - 2020-02-09 07:24:23 --> URI Class Initialized
INFO - 2020-02-09 07:24:23 --> Router Class Initialized
INFO - 2020-02-09 07:24:23 --> Output Class Initialized
INFO - 2020-02-09 07:24:23 --> Security Class Initialized
DEBUG - 2020-02-09 07:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:24:23 --> Input Class Initialized
INFO - 2020-02-09 07:24:23 --> Language Class Initialized
INFO - 2020-02-09 07:24:23 --> Config Class Initialized
INFO - 2020-02-09 07:24:23 --> Hooks Class Initialized
INFO - 2020-02-09 07:24:23 --> Language Class Initialized
INFO - 2020-02-09 07:24:23 --> Config Class Initialized
DEBUG - 2020-02-09 07:24:23 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:24:23 --> Loader Class Initialized
INFO - 2020-02-09 07:24:23 --> Utf8 Class Initialized
INFO - 2020-02-09 07:24:23 --> URI Class Initialized
INFO - 2020-02-09 07:24:23 --> Helper loaded: url_helper
INFO - 2020-02-09 07:24:23 --> Helper loaded: file_helper
INFO - 2020-02-09 07:24:23 --> Router Class Initialized
INFO - 2020-02-09 07:24:23 --> Helper loaded: form_helper
INFO - 2020-02-09 07:24:23 --> Output Class Initialized
INFO - 2020-02-09 07:24:23 --> Helper loaded: my_helper
INFO - 2020-02-09 07:24:23 --> Security Class Initialized
DEBUG - 2020-02-09 07:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:24:24 --> Database Driver Class Initialized
INFO - 2020-02-09 07:24:24 --> Input Class Initialized
DEBUG - 2020-02-09 07:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:24:24 --> Language Class Initialized
INFO - 2020-02-09 07:24:24 --> Controller Class Initialized
INFO - 2020-02-09 07:24:24 --> Language Class Initialized
INFO - 2020-02-09 07:24:24 --> Config Class Initialized
INFO - 2020-02-09 07:24:24 --> Loader Class Initialized
INFO - 2020-02-09 07:24:24 --> Helper loaded: url_helper
INFO - 2020-02-09 07:24:24 --> Helper loaded: file_helper
INFO - 2020-02-09 07:24:24 --> Helper loaded: form_helper
INFO - 2020-02-09 07:24:24 --> Helper loaded: my_helper
INFO - 2020-02-09 07:24:24 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:24:24 --> Controller Class Initialized
DEBUG - 2020-02-09 07:24:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_walikelas/views/list.php
DEBUG - 2020-02-09 07:24:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:24:24 --> Final output sent to browser
DEBUG - 2020-02-09 07:24:24 --> Total execution time: 0.9024
INFO - 2020-02-09 07:24:25 --> Config Class Initialized
INFO - 2020-02-09 07:24:25 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:24:25 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:24:25 --> Utf8 Class Initialized
INFO - 2020-02-09 07:24:25 --> URI Class Initialized
INFO - 2020-02-09 07:24:25 --> Router Class Initialized
INFO - 2020-02-09 07:24:25 --> Output Class Initialized
INFO - 2020-02-09 07:24:25 --> Security Class Initialized
DEBUG - 2020-02-09 07:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:24:25 --> Input Class Initialized
INFO - 2020-02-09 07:24:25 --> Language Class Initialized
INFO - 2020-02-09 07:24:25 --> Language Class Initialized
INFO - 2020-02-09 07:24:25 --> Config Class Initialized
INFO - 2020-02-09 07:24:25 --> Loader Class Initialized
INFO - 2020-02-09 07:24:25 --> Helper loaded: url_helper
INFO - 2020-02-09 07:24:25 --> Helper loaded: file_helper
INFO - 2020-02-09 07:24:25 --> Helper loaded: form_helper
INFO - 2020-02-09 07:24:25 --> Helper loaded: my_helper
INFO - 2020-02-09 07:24:25 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:24:25 --> Controller Class Initialized
INFO - 2020-02-09 07:24:40 --> Config Class Initialized
INFO - 2020-02-09 07:24:40 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:24:40 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:24:40 --> Utf8 Class Initialized
INFO - 2020-02-09 07:24:40 --> URI Class Initialized
INFO - 2020-02-09 07:24:41 --> Router Class Initialized
INFO - 2020-02-09 07:24:41 --> Output Class Initialized
INFO - 2020-02-09 07:24:41 --> Security Class Initialized
DEBUG - 2020-02-09 07:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:24:41 --> Input Class Initialized
INFO - 2020-02-09 07:24:41 --> Language Class Initialized
INFO - 2020-02-09 07:24:41 --> Language Class Initialized
INFO - 2020-02-09 07:24:41 --> Config Class Initialized
INFO - 2020-02-09 07:24:41 --> Loader Class Initialized
INFO - 2020-02-09 07:24:41 --> Helper loaded: url_helper
INFO - 2020-02-09 07:24:41 --> Helper loaded: file_helper
INFO - 2020-02-09 07:24:41 --> Helper loaded: form_helper
INFO - 2020-02-09 07:24:41 --> Helper loaded: my_helper
INFO - 2020-02-09 07:24:41 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:24:41 --> Controller Class Initialized
INFO - 2020-02-09 07:24:41 --> Final output sent to browser
DEBUG - 2020-02-09 07:24:41 --> Total execution time: 0.6664
INFO - 2020-02-09 07:24:53 --> Config Class Initialized
INFO - 2020-02-09 07:24:53 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:24:53 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:24:53 --> Utf8 Class Initialized
INFO - 2020-02-09 07:24:53 --> URI Class Initialized
INFO - 2020-02-09 07:24:53 --> Router Class Initialized
INFO - 2020-02-09 07:24:53 --> Output Class Initialized
INFO - 2020-02-09 07:24:53 --> Security Class Initialized
DEBUG - 2020-02-09 07:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:24:53 --> Input Class Initialized
INFO - 2020-02-09 07:24:53 --> Language Class Initialized
INFO - 2020-02-09 07:24:53 --> Language Class Initialized
INFO - 2020-02-09 07:24:53 --> Config Class Initialized
INFO - 2020-02-09 07:24:53 --> Loader Class Initialized
INFO - 2020-02-09 07:24:54 --> Helper loaded: url_helper
INFO - 2020-02-09 07:24:54 --> Helper loaded: file_helper
INFO - 2020-02-09 07:24:54 --> Helper loaded: form_helper
INFO - 2020-02-09 07:24:54 --> Helper loaded: my_helper
INFO - 2020-02-09 07:24:54 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:24:54 --> Controller Class Initialized
DEBUG - 2020-02-09 07:24:54 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_ubah_password.php
DEBUG - 2020-02-09 07:24:54 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:24:54 --> Final output sent to browser
DEBUG - 2020-02-09 07:24:54 --> Total execution time: 0.8424
INFO - 2020-02-09 07:25:32 --> Config Class Initialized
INFO - 2020-02-09 07:25:32 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:25:32 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:25:32 --> Utf8 Class Initialized
INFO - 2020-02-09 07:25:32 --> URI Class Initialized
INFO - 2020-02-09 07:25:32 --> Router Class Initialized
INFO - 2020-02-09 07:25:32 --> Output Class Initialized
INFO - 2020-02-09 07:25:32 --> Security Class Initialized
DEBUG - 2020-02-09 07:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:25:32 --> Input Class Initialized
INFO - 2020-02-09 07:25:33 --> Language Class Initialized
INFO - 2020-02-09 07:25:33 --> Language Class Initialized
INFO - 2020-02-09 07:25:33 --> Config Class Initialized
INFO - 2020-02-09 07:25:33 --> Loader Class Initialized
INFO - 2020-02-09 07:25:33 --> Helper loaded: url_helper
INFO - 2020-02-09 07:25:33 --> Helper loaded: file_helper
INFO - 2020-02-09 07:25:33 --> Helper loaded: form_helper
INFO - 2020-02-09 07:25:33 --> Helper loaded: my_helper
INFO - 2020-02-09 07:25:33 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:25:33 --> Controller Class Initialized
DEBUG - 2020-02-09 07:25:33 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-09 07:25:33 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:25:33 --> Final output sent to browser
DEBUG - 2020-02-09 07:25:33 --> Total execution time: 0.7920
INFO - 2020-02-09 07:25:33 --> Config Class Initialized
INFO - 2020-02-09 07:25:34 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:25:34 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:25:34 --> Utf8 Class Initialized
INFO - 2020-02-09 07:25:34 --> URI Class Initialized
INFO - 2020-02-09 07:25:34 --> Router Class Initialized
INFO - 2020-02-09 07:25:34 --> Output Class Initialized
INFO - 2020-02-09 07:25:34 --> Security Class Initialized
DEBUG - 2020-02-09 07:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:25:34 --> Input Class Initialized
INFO - 2020-02-09 07:25:34 --> Language Class Initialized
INFO - 2020-02-09 07:25:34 --> Language Class Initialized
INFO - 2020-02-09 07:25:34 --> Config Class Initialized
INFO - 2020-02-09 07:25:34 --> Loader Class Initialized
INFO - 2020-02-09 07:25:34 --> Helper loaded: url_helper
INFO - 2020-02-09 07:25:34 --> Helper loaded: file_helper
INFO - 2020-02-09 07:25:34 --> Helper loaded: form_helper
INFO - 2020-02-09 07:25:34 --> Helper loaded: my_helper
INFO - 2020-02-09 07:25:34 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:25:34 --> Controller Class Initialized
INFO - 2020-02-09 07:25:41 --> Config Class Initialized
INFO - 2020-02-09 07:25:41 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:25:41 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:25:41 --> Utf8 Class Initialized
INFO - 2020-02-09 07:25:41 --> URI Class Initialized
INFO - 2020-02-09 07:25:41 --> Router Class Initialized
INFO - 2020-02-09 07:25:42 --> Output Class Initialized
INFO - 2020-02-09 07:25:42 --> Security Class Initialized
DEBUG - 2020-02-09 07:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:25:42 --> Input Class Initialized
INFO - 2020-02-09 07:25:42 --> Language Class Initialized
INFO - 2020-02-09 07:25:42 --> Language Class Initialized
INFO - 2020-02-09 07:25:42 --> Config Class Initialized
INFO - 2020-02-09 07:25:42 --> Loader Class Initialized
INFO - 2020-02-09 07:25:42 --> Helper loaded: url_helper
INFO - 2020-02-09 07:25:42 --> Helper loaded: file_helper
INFO - 2020-02-09 07:25:42 --> Helper loaded: form_helper
INFO - 2020-02-09 07:25:42 --> Helper loaded: my_helper
INFO - 2020-02-09 07:25:42 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:25:42 --> Controller Class Initialized
INFO - 2020-02-09 07:25:42 --> Final output sent to browser
DEBUG - 2020-02-09 07:25:42 --> Total execution time: 0.5424
INFO - 2020-02-09 07:25:42 --> Config Class Initialized
INFO - 2020-02-09 07:25:42 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:25:42 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:25:42 --> Utf8 Class Initialized
INFO - 2020-02-09 07:25:42 --> URI Class Initialized
INFO - 2020-02-09 07:25:42 --> Router Class Initialized
INFO - 2020-02-09 07:25:42 --> Output Class Initialized
INFO - 2020-02-09 07:25:42 --> Security Class Initialized
DEBUG - 2020-02-09 07:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:25:42 --> Input Class Initialized
INFO - 2020-02-09 07:25:42 --> Language Class Initialized
INFO - 2020-02-09 07:25:42 --> Language Class Initialized
INFO - 2020-02-09 07:25:42 --> Config Class Initialized
INFO - 2020-02-09 07:25:42 --> Loader Class Initialized
INFO - 2020-02-09 07:25:43 --> Helper loaded: url_helper
INFO - 2020-02-09 07:25:43 --> Helper loaded: file_helper
INFO - 2020-02-09 07:25:43 --> Helper loaded: form_helper
INFO - 2020-02-09 07:25:43 --> Helper loaded: my_helper
INFO - 2020-02-09 07:25:43 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:25:43 --> Controller Class Initialized
INFO - 2020-02-09 07:25:50 --> Config Class Initialized
INFO - 2020-02-09 07:25:50 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:25:50 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:25:50 --> Utf8 Class Initialized
INFO - 2020-02-09 07:25:50 --> URI Class Initialized
INFO - 2020-02-09 07:25:50 --> Router Class Initialized
INFO - 2020-02-09 07:25:50 --> Output Class Initialized
INFO - 2020-02-09 07:25:50 --> Security Class Initialized
DEBUG - 2020-02-09 07:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:25:50 --> Input Class Initialized
INFO - 2020-02-09 07:25:50 --> Language Class Initialized
INFO - 2020-02-09 07:25:50 --> Language Class Initialized
INFO - 2020-02-09 07:25:50 --> Config Class Initialized
INFO - 2020-02-09 07:25:50 --> Loader Class Initialized
INFO - 2020-02-09 07:25:50 --> Helper loaded: url_helper
INFO - 2020-02-09 07:25:50 --> Helper loaded: file_helper
INFO - 2020-02-09 07:25:50 --> Helper loaded: form_helper
INFO - 2020-02-09 07:25:50 --> Helper loaded: my_helper
INFO - 2020-02-09 07:25:50 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:25:51 --> Controller Class Initialized
DEBUG - 2020-02-09 07:25:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-09 07:25:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:25:51 --> Final output sent to browser
DEBUG - 2020-02-09 07:25:51 --> Total execution time: 0.7464
INFO - 2020-02-09 07:26:12 --> Config Class Initialized
INFO - 2020-02-09 07:26:12 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:26:12 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:26:12 --> Utf8 Class Initialized
INFO - 2020-02-09 07:26:12 --> URI Class Initialized
INFO - 2020-02-09 07:26:12 --> Router Class Initialized
INFO - 2020-02-09 07:26:12 --> Output Class Initialized
INFO - 2020-02-09 07:26:12 --> Security Class Initialized
DEBUG - 2020-02-09 07:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:26:12 --> Input Class Initialized
INFO - 2020-02-09 07:26:12 --> Language Class Initialized
INFO - 2020-02-09 07:26:12 --> Language Class Initialized
INFO - 2020-02-09 07:26:13 --> Config Class Initialized
INFO - 2020-02-09 07:26:13 --> Loader Class Initialized
INFO - 2020-02-09 07:26:13 --> Helper loaded: url_helper
INFO - 2020-02-09 07:26:13 --> Helper loaded: file_helper
INFO - 2020-02-09 07:26:13 --> Helper loaded: form_helper
INFO - 2020-02-09 07:26:13 --> Helper loaded: my_helper
INFO - 2020-02-09 07:26:13 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:26:13 --> Controller Class Initialized
DEBUG - 2020-02-09 07:26:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-09 07:26:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:26:13 --> Final output sent to browser
DEBUG - 2020-02-09 07:26:13 --> Total execution time: 1.0845
INFO - 2020-02-09 07:28:13 --> Config Class Initialized
INFO - 2020-02-09 07:28:13 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:28:13 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:28:13 --> Utf8 Class Initialized
INFO - 2020-02-09 07:28:13 --> URI Class Initialized
INFO - 2020-02-09 07:28:13 --> Router Class Initialized
INFO - 2020-02-09 07:28:13 --> Output Class Initialized
INFO - 2020-02-09 07:28:13 --> Security Class Initialized
DEBUG - 2020-02-09 07:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:28:13 --> Input Class Initialized
INFO - 2020-02-09 07:28:13 --> Language Class Initialized
INFO - 2020-02-09 07:28:13 --> Language Class Initialized
INFO - 2020-02-09 07:28:13 --> Config Class Initialized
INFO - 2020-02-09 07:28:13 --> Loader Class Initialized
INFO - 2020-02-09 07:28:13 --> Helper loaded: url_helper
INFO - 2020-02-09 07:28:13 --> Helper loaded: file_helper
INFO - 2020-02-09 07:28:14 --> Helper loaded: form_helper
INFO - 2020-02-09 07:28:14 --> Helper loaded: my_helper
INFO - 2020-02-09 07:28:14 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:28:14 --> Controller Class Initialized
INFO - 2020-02-09 07:28:14 --> Config Class Initialized
INFO - 2020-02-09 07:28:14 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:28:14 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:28:14 --> Utf8 Class Initialized
INFO - 2020-02-09 07:28:14 --> URI Class Initialized
INFO - 2020-02-09 07:28:14 --> Router Class Initialized
INFO - 2020-02-09 07:28:14 --> Output Class Initialized
INFO - 2020-02-09 07:28:14 --> Security Class Initialized
DEBUG - 2020-02-09 07:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:28:14 --> Input Class Initialized
INFO - 2020-02-09 07:28:14 --> Language Class Initialized
INFO - 2020-02-09 07:28:14 --> Language Class Initialized
INFO - 2020-02-09 07:28:14 --> Config Class Initialized
INFO - 2020-02-09 07:28:14 --> Loader Class Initialized
INFO - 2020-02-09 07:28:14 --> Helper loaded: url_helper
INFO - 2020-02-09 07:28:14 --> Helper loaded: file_helper
INFO - 2020-02-09 07:28:14 --> Helper loaded: form_helper
INFO - 2020-02-09 07:28:14 --> Helper loaded: my_helper
INFO - 2020-02-09 07:28:14 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:28:15 --> Controller Class Initialized
DEBUG - 2020-02-09 07:28:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-09 07:28:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:28:15 --> Final output sent to browser
DEBUG - 2020-02-09 07:28:15 --> Total execution time: 0.8766
INFO - 2020-02-09 07:28:50 --> Config Class Initialized
INFO - 2020-02-09 07:28:50 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:28:50 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:28:50 --> Utf8 Class Initialized
INFO - 2020-02-09 07:28:50 --> URI Class Initialized
INFO - 2020-02-09 07:28:50 --> Router Class Initialized
INFO - 2020-02-09 07:28:50 --> Output Class Initialized
INFO - 2020-02-09 07:28:51 --> Security Class Initialized
DEBUG - 2020-02-09 07:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:28:51 --> Input Class Initialized
INFO - 2020-02-09 07:28:51 --> Language Class Initialized
INFO - 2020-02-09 07:28:51 --> Language Class Initialized
INFO - 2020-02-09 07:28:51 --> Config Class Initialized
INFO - 2020-02-09 07:28:51 --> Loader Class Initialized
INFO - 2020-02-09 07:28:51 --> Helper loaded: url_helper
INFO - 2020-02-09 07:28:51 --> Helper loaded: file_helper
INFO - 2020-02-09 07:28:51 --> Helper loaded: form_helper
INFO - 2020-02-09 07:28:51 --> Helper loaded: my_helper
INFO - 2020-02-09 07:28:51 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:28:51 --> Controller Class Initialized
DEBUG - 2020-02-09 07:28:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/list.php
DEBUG - 2020-02-09 07:28:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:28:51 --> Final output sent to browser
DEBUG - 2020-02-09 07:28:51 --> Total execution time: 0.8526
INFO - 2020-02-09 07:28:52 --> Config Class Initialized
INFO - 2020-02-09 07:28:52 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:28:52 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:28:52 --> Utf8 Class Initialized
INFO - 2020-02-09 07:28:52 --> URI Class Initialized
INFO - 2020-02-09 07:28:52 --> Router Class Initialized
INFO - 2020-02-09 07:28:52 --> Output Class Initialized
INFO - 2020-02-09 07:28:52 --> Security Class Initialized
DEBUG - 2020-02-09 07:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:28:52 --> Input Class Initialized
INFO - 2020-02-09 07:28:52 --> Language Class Initialized
INFO - 2020-02-09 07:28:52 --> Language Class Initialized
INFO - 2020-02-09 07:28:52 --> Config Class Initialized
INFO - 2020-02-09 07:28:52 --> Loader Class Initialized
INFO - 2020-02-09 07:28:52 --> Helper loaded: url_helper
INFO - 2020-02-09 07:28:52 --> Helper loaded: file_helper
INFO - 2020-02-09 07:28:52 --> Helper loaded: form_helper
INFO - 2020-02-09 07:28:52 --> Helper loaded: my_helper
INFO - 2020-02-09 07:28:52 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:28:53 --> Controller Class Initialized
INFO - 2020-02-09 07:29:02 --> Config Class Initialized
INFO - 2020-02-09 07:29:02 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:29:02 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:29:02 --> Utf8 Class Initialized
INFO - 2020-02-09 07:29:02 --> URI Class Initialized
INFO - 2020-02-09 07:29:02 --> Router Class Initialized
INFO - 2020-02-09 07:29:02 --> Output Class Initialized
INFO - 2020-02-09 07:29:02 --> Security Class Initialized
DEBUG - 2020-02-09 07:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:29:02 --> Input Class Initialized
INFO - 2020-02-09 07:29:02 --> Language Class Initialized
INFO - 2020-02-09 07:29:02 --> Language Class Initialized
INFO - 2020-02-09 07:29:02 --> Config Class Initialized
INFO - 2020-02-09 07:29:02 --> Loader Class Initialized
INFO - 2020-02-09 07:29:02 --> Helper loaded: url_helper
INFO - 2020-02-09 07:29:02 --> Helper loaded: file_helper
INFO - 2020-02-09 07:29:02 --> Helper loaded: form_helper
INFO - 2020-02-09 07:29:02 --> Helper loaded: my_helper
INFO - 2020-02-09 07:29:02 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:29:03 --> Controller Class Initialized
DEBUG - 2020-02-09 07:29:03 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/form.php
DEBUG - 2020-02-09 07:29:03 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:29:03 --> Final output sent to browser
DEBUG - 2020-02-09 07:29:03 --> Total execution time: 0.9422
INFO - 2020-02-09 07:29:15 --> Config Class Initialized
INFO - 2020-02-09 07:29:15 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:29:15 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:29:15 --> Utf8 Class Initialized
INFO - 2020-02-09 07:29:16 --> URI Class Initialized
INFO - 2020-02-09 07:29:16 --> Router Class Initialized
INFO - 2020-02-09 07:29:16 --> Output Class Initialized
INFO - 2020-02-09 07:29:16 --> Security Class Initialized
DEBUG - 2020-02-09 07:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:29:16 --> Input Class Initialized
INFO - 2020-02-09 07:29:16 --> Language Class Initialized
INFO - 2020-02-09 07:29:16 --> Language Class Initialized
INFO - 2020-02-09 07:29:16 --> Config Class Initialized
INFO - 2020-02-09 07:29:16 --> Loader Class Initialized
INFO - 2020-02-09 07:29:16 --> Helper loaded: url_helper
INFO - 2020-02-09 07:29:16 --> Helper loaded: file_helper
INFO - 2020-02-09 07:29:16 --> Helper loaded: form_helper
INFO - 2020-02-09 07:29:16 --> Helper loaded: my_helper
INFO - 2020-02-09 07:29:16 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:29:16 --> Controller Class Initialized
INFO - 2020-02-09 07:29:16 --> Config Class Initialized
INFO - 2020-02-09 07:29:16 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:29:16 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:29:16 --> Utf8 Class Initialized
INFO - 2020-02-09 07:29:16 --> URI Class Initialized
INFO - 2020-02-09 07:29:16 --> Router Class Initialized
INFO - 2020-02-09 07:29:16 --> Output Class Initialized
INFO - 2020-02-09 07:29:17 --> Security Class Initialized
DEBUG - 2020-02-09 07:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:29:17 --> Input Class Initialized
INFO - 2020-02-09 07:29:17 --> Language Class Initialized
INFO - 2020-02-09 07:29:17 --> Language Class Initialized
INFO - 2020-02-09 07:29:17 --> Config Class Initialized
INFO - 2020-02-09 07:29:17 --> Loader Class Initialized
INFO - 2020-02-09 07:29:17 --> Helper loaded: url_helper
INFO - 2020-02-09 07:29:17 --> Helper loaded: file_helper
INFO - 2020-02-09 07:29:17 --> Helper loaded: form_helper
INFO - 2020-02-09 07:29:17 --> Helper loaded: my_helper
INFO - 2020-02-09 07:29:17 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:29:17 --> Controller Class Initialized
DEBUG - 2020-02-09 07:29:17 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/list.php
DEBUG - 2020-02-09 07:29:17 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:29:17 --> Final output sent to browser
DEBUG - 2020-02-09 07:29:17 --> Total execution time: 0.8984
INFO - 2020-02-09 07:29:18 --> Config Class Initialized
INFO - 2020-02-09 07:29:18 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:29:18 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:29:18 --> Utf8 Class Initialized
INFO - 2020-02-09 07:29:18 --> URI Class Initialized
INFO - 2020-02-09 07:29:18 --> Router Class Initialized
INFO - 2020-02-09 07:29:18 --> Output Class Initialized
INFO - 2020-02-09 07:29:18 --> Security Class Initialized
DEBUG - 2020-02-09 07:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:29:18 --> Input Class Initialized
INFO - 2020-02-09 07:29:18 --> Language Class Initialized
INFO - 2020-02-09 07:29:18 --> Language Class Initialized
INFO - 2020-02-09 07:29:18 --> Config Class Initialized
INFO - 2020-02-09 07:29:18 --> Loader Class Initialized
INFO - 2020-02-09 07:29:18 --> Helper loaded: url_helper
INFO - 2020-02-09 07:29:18 --> Helper loaded: file_helper
INFO - 2020-02-09 07:29:18 --> Helper loaded: form_helper
INFO - 2020-02-09 07:29:18 --> Helper loaded: my_helper
INFO - 2020-02-09 07:29:18 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:29:18 --> Controller Class Initialized
INFO - 2020-02-09 07:29:25 --> Config Class Initialized
INFO - 2020-02-09 07:29:25 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:29:25 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:29:25 --> Utf8 Class Initialized
INFO - 2020-02-09 07:29:25 --> URI Class Initialized
INFO - 2020-02-09 07:29:25 --> Router Class Initialized
INFO - 2020-02-09 07:29:25 --> Output Class Initialized
INFO - 2020-02-09 07:29:25 --> Security Class Initialized
DEBUG - 2020-02-09 07:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:29:25 --> Input Class Initialized
INFO - 2020-02-09 07:29:25 --> Language Class Initialized
INFO - 2020-02-09 07:29:25 --> Language Class Initialized
INFO - 2020-02-09 07:29:25 --> Config Class Initialized
INFO - 2020-02-09 07:29:25 --> Loader Class Initialized
INFO - 2020-02-09 07:29:25 --> Helper loaded: url_helper
INFO - 2020-02-09 07:29:25 --> Helper loaded: file_helper
INFO - 2020-02-09 07:29:25 --> Helper loaded: form_helper
INFO - 2020-02-09 07:29:25 --> Helper loaded: my_helper
INFO - 2020-02-09 07:29:26 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:29:26 --> Controller Class Initialized
DEBUG - 2020-02-09 07:29:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/form.php
DEBUG - 2020-02-09 07:29:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:29:26 --> Final output sent to browser
DEBUG - 2020-02-09 07:29:26 --> Total execution time: 0.8645
INFO - 2020-02-09 07:29:35 --> Config Class Initialized
INFO - 2020-02-09 07:29:35 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:29:35 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:29:35 --> Utf8 Class Initialized
INFO - 2020-02-09 07:29:35 --> URI Class Initialized
INFO - 2020-02-09 07:29:35 --> Router Class Initialized
INFO - 2020-02-09 07:29:35 --> Output Class Initialized
INFO - 2020-02-09 07:29:35 --> Security Class Initialized
DEBUG - 2020-02-09 07:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:29:35 --> Input Class Initialized
INFO - 2020-02-09 07:29:35 --> Language Class Initialized
INFO - 2020-02-09 07:29:35 --> Language Class Initialized
INFO - 2020-02-09 07:29:35 --> Config Class Initialized
INFO - 2020-02-09 07:29:35 --> Loader Class Initialized
INFO - 2020-02-09 07:29:35 --> Helper loaded: url_helper
INFO - 2020-02-09 07:29:35 --> Helper loaded: file_helper
INFO - 2020-02-09 07:29:35 --> Helper loaded: form_helper
INFO - 2020-02-09 07:29:35 --> Helper loaded: my_helper
INFO - 2020-02-09 07:29:35 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:29:35 --> Controller Class Initialized
INFO - 2020-02-09 07:29:35 --> Config Class Initialized
INFO - 2020-02-09 07:29:35 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:29:35 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:29:35 --> Utf8 Class Initialized
INFO - 2020-02-09 07:29:36 --> URI Class Initialized
INFO - 2020-02-09 07:29:36 --> Router Class Initialized
INFO - 2020-02-09 07:29:36 --> Output Class Initialized
INFO - 2020-02-09 07:29:36 --> Security Class Initialized
DEBUG - 2020-02-09 07:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:29:36 --> Input Class Initialized
INFO - 2020-02-09 07:29:36 --> Language Class Initialized
INFO - 2020-02-09 07:29:36 --> Language Class Initialized
INFO - 2020-02-09 07:29:36 --> Config Class Initialized
INFO - 2020-02-09 07:29:36 --> Loader Class Initialized
INFO - 2020-02-09 07:29:36 --> Helper loaded: url_helper
INFO - 2020-02-09 07:29:36 --> Helper loaded: file_helper
INFO - 2020-02-09 07:29:36 --> Helper loaded: form_helper
INFO - 2020-02-09 07:29:36 --> Helper loaded: my_helper
INFO - 2020-02-09 07:29:36 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:29:36 --> Controller Class Initialized
DEBUG - 2020-02-09 07:29:36 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/list.php
DEBUG - 2020-02-09 07:29:36 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:29:36 --> Final output sent to browser
DEBUG - 2020-02-09 07:29:36 --> Total execution time: 0.7819
INFO - 2020-02-09 07:29:37 --> Config Class Initialized
INFO - 2020-02-09 07:29:37 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:29:37 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:29:37 --> Utf8 Class Initialized
INFO - 2020-02-09 07:29:37 --> URI Class Initialized
INFO - 2020-02-09 07:29:37 --> Router Class Initialized
INFO - 2020-02-09 07:29:37 --> Output Class Initialized
INFO - 2020-02-09 07:29:37 --> Security Class Initialized
DEBUG - 2020-02-09 07:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:29:37 --> Input Class Initialized
INFO - 2020-02-09 07:29:37 --> Language Class Initialized
INFO - 2020-02-09 07:29:37 --> Language Class Initialized
INFO - 2020-02-09 07:29:37 --> Config Class Initialized
INFO - 2020-02-09 07:29:37 --> Loader Class Initialized
INFO - 2020-02-09 07:29:37 --> Helper loaded: url_helper
INFO - 2020-02-09 07:29:37 --> Helper loaded: file_helper
INFO - 2020-02-09 07:29:37 --> Helper loaded: form_helper
INFO - 2020-02-09 07:29:37 --> Helper loaded: my_helper
INFO - 2020-02-09 07:29:37 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:29:37 --> Controller Class Initialized
INFO - 2020-02-09 07:29:38 --> Config Class Initialized
INFO - 2020-02-09 07:29:38 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:29:38 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:29:38 --> Utf8 Class Initialized
INFO - 2020-02-09 07:29:38 --> URI Class Initialized
INFO - 2020-02-09 07:29:38 --> Router Class Initialized
INFO - 2020-02-09 07:29:38 --> Output Class Initialized
INFO - 2020-02-09 07:29:38 --> Security Class Initialized
DEBUG - 2020-02-09 07:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:29:38 --> Input Class Initialized
INFO - 2020-02-09 07:29:38 --> Language Class Initialized
INFO - 2020-02-09 07:29:38 --> Language Class Initialized
INFO - 2020-02-09 07:29:38 --> Config Class Initialized
INFO - 2020-02-09 07:29:39 --> Loader Class Initialized
INFO - 2020-02-09 07:29:39 --> Helper loaded: url_helper
INFO - 2020-02-09 07:29:39 --> Helper loaded: file_helper
INFO - 2020-02-09 07:29:39 --> Helper loaded: form_helper
INFO - 2020-02-09 07:29:39 --> Helper loaded: my_helper
INFO - 2020-02-09 07:29:39 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:29:39 --> Controller Class Initialized
DEBUG - 2020-02-09 07:29:39 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/form.php
DEBUG - 2020-02-09 07:29:39 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:29:39 --> Final output sent to browser
DEBUG - 2020-02-09 07:29:39 --> Total execution time: 0.8612
INFO - 2020-02-09 07:29:47 --> Config Class Initialized
INFO - 2020-02-09 07:29:47 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:29:47 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:29:47 --> Utf8 Class Initialized
INFO - 2020-02-09 07:29:47 --> URI Class Initialized
INFO - 2020-02-09 07:29:47 --> Router Class Initialized
INFO - 2020-02-09 07:29:47 --> Output Class Initialized
INFO - 2020-02-09 07:29:47 --> Security Class Initialized
DEBUG - 2020-02-09 07:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:29:47 --> Input Class Initialized
INFO - 2020-02-09 07:29:47 --> Language Class Initialized
INFO - 2020-02-09 07:29:47 --> Language Class Initialized
INFO - 2020-02-09 07:29:47 --> Config Class Initialized
INFO - 2020-02-09 07:29:47 --> Loader Class Initialized
INFO - 2020-02-09 07:29:47 --> Helper loaded: url_helper
INFO - 2020-02-09 07:29:47 --> Helper loaded: file_helper
INFO - 2020-02-09 07:29:47 --> Helper loaded: form_helper
INFO - 2020-02-09 07:29:47 --> Helper loaded: my_helper
INFO - 2020-02-09 07:29:47 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:29:47 --> Controller Class Initialized
INFO - 2020-02-09 07:29:48 --> Config Class Initialized
INFO - 2020-02-09 07:29:48 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:29:48 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:29:48 --> Utf8 Class Initialized
INFO - 2020-02-09 07:29:48 --> URI Class Initialized
INFO - 2020-02-09 07:29:48 --> Router Class Initialized
INFO - 2020-02-09 07:29:48 --> Output Class Initialized
INFO - 2020-02-09 07:29:48 --> Security Class Initialized
DEBUG - 2020-02-09 07:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:29:48 --> Input Class Initialized
INFO - 2020-02-09 07:29:48 --> Language Class Initialized
INFO - 2020-02-09 07:29:48 --> Language Class Initialized
INFO - 2020-02-09 07:29:48 --> Config Class Initialized
INFO - 2020-02-09 07:29:48 --> Loader Class Initialized
INFO - 2020-02-09 07:29:48 --> Helper loaded: url_helper
INFO - 2020-02-09 07:29:48 --> Helper loaded: file_helper
INFO - 2020-02-09 07:29:48 --> Helper loaded: form_helper
INFO - 2020-02-09 07:29:48 --> Helper loaded: my_helper
INFO - 2020-02-09 07:29:48 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:29:48 --> Controller Class Initialized
DEBUG - 2020-02-09 07:29:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/list.php
DEBUG - 2020-02-09 07:29:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:29:48 --> Final output sent to browser
DEBUG - 2020-02-09 07:29:48 --> Total execution time: 0.8545
INFO - 2020-02-09 07:29:49 --> Config Class Initialized
INFO - 2020-02-09 07:29:49 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:29:49 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:29:49 --> Utf8 Class Initialized
INFO - 2020-02-09 07:29:49 --> URI Class Initialized
INFO - 2020-02-09 07:29:49 --> Router Class Initialized
INFO - 2020-02-09 07:29:49 --> Output Class Initialized
INFO - 2020-02-09 07:29:49 --> Security Class Initialized
DEBUG - 2020-02-09 07:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:29:49 --> Input Class Initialized
INFO - 2020-02-09 07:29:49 --> Language Class Initialized
INFO - 2020-02-09 07:29:49 --> Language Class Initialized
INFO - 2020-02-09 07:29:49 --> Config Class Initialized
INFO - 2020-02-09 07:29:49 --> Loader Class Initialized
INFO - 2020-02-09 07:29:50 --> Helper loaded: url_helper
INFO - 2020-02-09 07:29:50 --> Helper loaded: file_helper
INFO - 2020-02-09 07:29:50 --> Helper loaded: form_helper
INFO - 2020-02-09 07:29:50 --> Helper loaded: my_helper
INFO - 2020-02-09 07:29:50 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:29:50 --> Controller Class Initialized
INFO - 2020-02-09 07:29:50 --> Config Class Initialized
INFO - 2020-02-09 07:29:50 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:29:50 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:29:50 --> Utf8 Class Initialized
INFO - 2020-02-09 07:29:50 --> URI Class Initialized
INFO - 2020-02-09 07:29:51 --> Router Class Initialized
INFO - 2020-02-09 07:29:51 --> Output Class Initialized
INFO - 2020-02-09 07:29:51 --> Security Class Initialized
DEBUG - 2020-02-09 07:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:29:51 --> Input Class Initialized
INFO - 2020-02-09 07:29:51 --> Language Class Initialized
INFO - 2020-02-09 07:29:51 --> Language Class Initialized
INFO - 2020-02-09 07:29:51 --> Config Class Initialized
INFO - 2020-02-09 07:29:51 --> Loader Class Initialized
INFO - 2020-02-09 07:29:51 --> Helper loaded: url_helper
INFO - 2020-02-09 07:29:51 --> Helper loaded: file_helper
INFO - 2020-02-09 07:29:51 --> Helper loaded: form_helper
INFO - 2020-02-09 07:29:51 --> Helper loaded: my_helper
INFO - 2020-02-09 07:29:51 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:29:51 --> Controller Class Initialized
DEBUG - 2020-02-09 07:29:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/form.php
DEBUG - 2020-02-09 07:29:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:29:51 --> Final output sent to browser
DEBUG - 2020-02-09 07:29:51 --> Total execution time: 0.9167
INFO - 2020-02-09 07:30:01 --> Config Class Initialized
INFO - 2020-02-09 07:30:01 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:30:01 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:30:01 --> Utf8 Class Initialized
INFO - 2020-02-09 07:30:01 --> URI Class Initialized
INFO - 2020-02-09 07:30:01 --> Router Class Initialized
INFO - 2020-02-09 07:30:01 --> Output Class Initialized
INFO - 2020-02-09 07:30:01 --> Security Class Initialized
DEBUG - 2020-02-09 07:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:30:01 --> Input Class Initialized
INFO - 2020-02-09 07:30:01 --> Language Class Initialized
INFO - 2020-02-09 07:30:01 --> Language Class Initialized
INFO - 2020-02-09 07:30:02 --> Config Class Initialized
INFO - 2020-02-09 07:30:02 --> Loader Class Initialized
INFO - 2020-02-09 07:30:02 --> Helper loaded: url_helper
INFO - 2020-02-09 07:30:02 --> Helper loaded: file_helper
INFO - 2020-02-09 07:30:02 --> Helper loaded: form_helper
INFO - 2020-02-09 07:30:02 --> Helper loaded: my_helper
INFO - 2020-02-09 07:30:02 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:30:02 --> Controller Class Initialized
INFO - 2020-02-09 07:30:02 --> Config Class Initialized
INFO - 2020-02-09 07:30:02 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:30:02 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:30:02 --> Utf8 Class Initialized
INFO - 2020-02-09 07:30:02 --> URI Class Initialized
INFO - 2020-02-09 07:30:02 --> Router Class Initialized
INFO - 2020-02-09 07:30:02 --> Output Class Initialized
INFO - 2020-02-09 07:30:02 --> Security Class Initialized
DEBUG - 2020-02-09 07:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:30:02 --> Input Class Initialized
INFO - 2020-02-09 07:30:02 --> Language Class Initialized
INFO - 2020-02-09 07:30:02 --> Language Class Initialized
INFO - 2020-02-09 07:30:02 --> Config Class Initialized
INFO - 2020-02-09 07:30:03 --> Loader Class Initialized
INFO - 2020-02-09 07:30:03 --> Helper loaded: url_helper
INFO - 2020-02-09 07:30:03 --> Helper loaded: file_helper
INFO - 2020-02-09 07:30:03 --> Helper loaded: form_helper
INFO - 2020-02-09 07:30:03 --> Helper loaded: my_helper
INFO - 2020-02-09 07:30:03 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:30:03 --> Controller Class Initialized
DEBUG - 2020-02-09 07:30:03 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/list.php
DEBUG - 2020-02-09 07:30:03 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:30:03 --> Final output sent to browser
DEBUG - 2020-02-09 07:30:03 --> Total execution time: 0.9369
INFO - 2020-02-09 07:30:03 --> Config Class Initialized
INFO - 2020-02-09 07:30:04 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:30:04 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:30:04 --> Utf8 Class Initialized
INFO - 2020-02-09 07:30:04 --> URI Class Initialized
INFO - 2020-02-09 07:30:04 --> Router Class Initialized
INFO - 2020-02-09 07:30:04 --> Output Class Initialized
INFO - 2020-02-09 07:30:04 --> Security Class Initialized
DEBUG - 2020-02-09 07:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:30:04 --> Input Class Initialized
INFO - 2020-02-09 07:30:04 --> Language Class Initialized
INFO - 2020-02-09 07:30:04 --> Language Class Initialized
INFO - 2020-02-09 07:30:04 --> Config Class Initialized
INFO - 2020-02-09 07:30:04 --> Loader Class Initialized
INFO - 2020-02-09 07:30:04 --> Helper loaded: url_helper
INFO - 2020-02-09 07:30:04 --> Helper loaded: file_helper
INFO - 2020-02-09 07:30:04 --> Helper loaded: form_helper
INFO - 2020-02-09 07:30:04 --> Helper loaded: my_helper
INFO - 2020-02-09 07:30:04 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:30:04 --> Controller Class Initialized
INFO - 2020-02-09 07:30:05 --> Config Class Initialized
INFO - 2020-02-09 07:30:05 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:30:05 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:30:05 --> Utf8 Class Initialized
INFO - 2020-02-09 07:30:05 --> URI Class Initialized
INFO - 2020-02-09 07:30:05 --> Router Class Initialized
INFO - 2020-02-09 07:30:05 --> Output Class Initialized
INFO - 2020-02-09 07:30:05 --> Security Class Initialized
DEBUG - 2020-02-09 07:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:30:05 --> Input Class Initialized
INFO - 2020-02-09 07:30:05 --> Language Class Initialized
INFO - 2020-02-09 07:30:05 --> Language Class Initialized
INFO - 2020-02-09 07:30:05 --> Config Class Initialized
INFO - 2020-02-09 07:30:05 --> Loader Class Initialized
INFO - 2020-02-09 07:30:05 --> Helper loaded: url_helper
INFO - 2020-02-09 07:30:06 --> Helper loaded: file_helper
INFO - 2020-02-09 07:30:06 --> Helper loaded: form_helper
INFO - 2020-02-09 07:30:06 --> Helper loaded: my_helper
INFO - 2020-02-09 07:30:06 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:30:06 --> Controller Class Initialized
DEBUG - 2020-02-09 07:30:06 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/form.php
DEBUG - 2020-02-09 07:30:06 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:30:06 --> Final output sent to browser
DEBUG - 2020-02-09 07:30:06 --> Total execution time: 1.0081
INFO - 2020-02-09 07:30:12 --> Config Class Initialized
INFO - 2020-02-09 07:30:12 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:30:12 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:30:12 --> Utf8 Class Initialized
INFO - 2020-02-09 07:30:12 --> URI Class Initialized
INFO - 2020-02-09 07:30:12 --> Router Class Initialized
INFO - 2020-02-09 07:30:12 --> Output Class Initialized
INFO - 2020-02-09 07:30:12 --> Security Class Initialized
DEBUG - 2020-02-09 07:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:30:12 --> Input Class Initialized
INFO - 2020-02-09 07:30:13 --> Language Class Initialized
INFO - 2020-02-09 07:30:13 --> Language Class Initialized
INFO - 2020-02-09 07:30:13 --> Config Class Initialized
INFO - 2020-02-09 07:30:13 --> Loader Class Initialized
INFO - 2020-02-09 07:30:13 --> Helper loaded: url_helper
INFO - 2020-02-09 07:30:13 --> Helper loaded: file_helper
INFO - 2020-02-09 07:30:13 --> Helper loaded: form_helper
INFO - 2020-02-09 07:30:13 --> Helper loaded: my_helper
INFO - 2020-02-09 07:30:13 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:30:13 --> Controller Class Initialized
INFO - 2020-02-09 07:30:13 --> Config Class Initialized
INFO - 2020-02-09 07:30:13 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:30:13 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:30:13 --> Utf8 Class Initialized
INFO - 2020-02-09 07:30:13 --> URI Class Initialized
INFO - 2020-02-09 07:30:13 --> Router Class Initialized
INFO - 2020-02-09 07:30:13 --> Output Class Initialized
INFO - 2020-02-09 07:30:13 --> Security Class Initialized
DEBUG - 2020-02-09 07:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:30:13 --> Input Class Initialized
INFO - 2020-02-09 07:30:13 --> Language Class Initialized
INFO - 2020-02-09 07:30:13 --> Language Class Initialized
INFO - 2020-02-09 07:30:13 --> Config Class Initialized
INFO - 2020-02-09 07:30:13 --> Loader Class Initialized
INFO - 2020-02-09 07:30:14 --> Helper loaded: url_helper
INFO - 2020-02-09 07:30:14 --> Helper loaded: file_helper
INFO - 2020-02-09 07:30:14 --> Helper loaded: form_helper
INFO - 2020-02-09 07:30:14 --> Helper loaded: my_helper
INFO - 2020-02-09 07:30:14 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:30:14 --> Controller Class Initialized
DEBUG - 2020-02-09 07:30:14 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/list.php
DEBUG - 2020-02-09 07:30:14 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:30:14 --> Final output sent to browser
DEBUG - 2020-02-09 07:30:14 --> Total execution time: 0.8854
INFO - 2020-02-09 07:30:14 --> Config Class Initialized
INFO - 2020-02-09 07:30:14 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:30:14 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:30:14 --> Utf8 Class Initialized
INFO - 2020-02-09 07:30:14 --> URI Class Initialized
INFO - 2020-02-09 07:30:15 --> Router Class Initialized
INFO - 2020-02-09 07:30:15 --> Output Class Initialized
INFO - 2020-02-09 07:30:15 --> Security Class Initialized
DEBUG - 2020-02-09 07:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:30:15 --> Input Class Initialized
INFO - 2020-02-09 07:30:15 --> Language Class Initialized
INFO - 2020-02-09 07:30:15 --> Language Class Initialized
INFO - 2020-02-09 07:30:15 --> Config Class Initialized
INFO - 2020-02-09 07:30:15 --> Loader Class Initialized
INFO - 2020-02-09 07:30:15 --> Helper loaded: url_helper
INFO - 2020-02-09 07:30:15 --> Helper loaded: file_helper
INFO - 2020-02-09 07:30:15 --> Helper loaded: form_helper
INFO - 2020-02-09 07:30:15 --> Helper loaded: my_helper
INFO - 2020-02-09 07:30:15 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:30:15 --> Controller Class Initialized
INFO - 2020-02-09 07:30:32 --> Config Class Initialized
INFO - 2020-02-09 07:30:32 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:30:32 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:30:32 --> Utf8 Class Initialized
INFO - 2020-02-09 07:30:32 --> URI Class Initialized
INFO - 2020-02-09 07:30:32 --> Router Class Initialized
INFO - 2020-02-09 07:30:32 --> Output Class Initialized
INFO - 2020-02-09 07:30:32 --> Security Class Initialized
DEBUG - 2020-02-09 07:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:30:32 --> Input Class Initialized
INFO - 2020-02-09 07:30:32 --> Language Class Initialized
INFO - 2020-02-09 07:30:32 --> Language Class Initialized
INFO - 2020-02-09 07:30:32 --> Config Class Initialized
INFO - 2020-02-09 07:30:32 --> Loader Class Initialized
INFO - 2020-02-09 07:30:32 --> Helper loaded: url_helper
INFO - 2020-02-09 07:30:32 --> Helper loaded: file_helper
INFO - 2020-02-09 07:30:32 --> Helper loaded: form_helper
INFO - 2020-02-09 07:30:33 --> Helper loaded: my_helper
INFO - 2020-02-09 07:30:33 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:30:33 --> Controller Class Initialized
DEBUG - 2020-02-09 07:30:33 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_walikelas/views/list.php
DEBUG - 2020-02-09 07:30:33 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:30:33 --> Final output sent to browser
DEBUG - 2020-02-09 07:30:33 --> Total execution time: 0.8002
INFO - 2020-02-09 07:30:33 --> Config Class Initialized
INFO - 2020-02-09 07:30:33 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:30:33 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:30:33 --> Utf8 Class Initialized
INFO - 2020-02-09 07:30:33 --> URI Class Initialized
INFO - 2020-02-09 07:30:33 --> Router Class Initialized
INFO - 2020-02-09 07:30:34 --> Output Class Initialized
INFO - 2020-02-09 07:30:34 --> Security Class Initialized
DEBUG - 2020-02-09 07:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:30:34 --> Input Class Initialized
INFO - 2020-02-09 07:30:34 --> Language Class Initialized
INFO - 2020-02-09 07:30:34 --> Language Class Initialized
INFO - 2020-02-09 07:30:34 --> Config Class Initialized
INFO - 2020-02-09 07:30:34 --> Loader Class Initialized
INFO - 2020-02-09 07:30:34 --> Helper loaded: url_helper
INFO - 2020-02-09 07:30:34 --> Helper loaded: file_helper
INFO - 2020-02-09 07:30:34 --> Helper loaded: form_helper
INFO - 2020-02-09 07:30:34 --> Helper loaded: my_helper
INFO - 2020-02-09 07:30:34 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:30:34 --> Controller Class Initialized
INFO - 2020-02-09 07:30:42 --> Config Class Initialized
INFO - 2020-02-09 07:30:42 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:30:42 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:30:42 --> Utf8 Class Initialized
INFO - 2020-02-09 07:30:42 --> URI Class Initialized
INFO - 2020-02-09 07:30:42 --> Router Class Initialized
INFO - 2020-02-09 07:30:42 --> Output Class Initialized
INFO - 2020-02-09 07:30:42 --> Security Class Initialized
DEBUG - 2020-02-09 07:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:30:42 --> Input Class Initialized
INFO - 2020-02-09 07:30:42 --> Language Class Initialized
INFO - 2020-02-09 07:30:42 --> Language Class Initialized
INFO - 2020-02-09 07:30:42 --> Config Class Initialized
INFO - 2020-02-09 07:30:43 --> Loader Class Initialized
INFO - 2020-02-09 07:30:43 --> Helper loaded: url_helper
INFO - 2020-02-09 07:30:43 --> Helper loaded: file_helper
INFO - 2020-02-09 07:30:43 --> Helper loaded: form_helper
INFO - 2020-02-09 07:30:43 --> Helper loaded: my_helper
INFO - 2020-02-09 07:30:43 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:30:43 --> Controller Class Initialized
INFO - 2020-02-09 07:30:43 --> Final output sent to browser
DEBUG - 2020-02-09 07:30:43 --> Total execution time: 0.7435
INFO - 2020-02-09 07:30:52 --> Config Class Initialized
INFO - 2020-02-09 07:30:52 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:30:52 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:30:52 --> Utf8 Class Initialized
INFO - 2020-02-09 07:30:52 --> URI Class Initialized
INFO - 2020-02-09 07:30:52 --> Router Class Initialized
INFO - 2020-02-09 07:30:52 --> Output Class Initialized
INFO - 2020-02-09 07:30:52 --> Security Class Initialized
DEBUG - 2020-02-09 07:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:30:52 --> Input Class Initialized
INFO - 2020-02-09 07:30:52 --> Language Class Initialized
INFO - 2020-02-09 07:30:52 --> Language Class Initialized
INFO - 2020-02-09 07:30:52 --> Config Class Initialized
INFO - 2020-02-09 07:30:52 --> Loader Class Initialized
INFO - 2020-02-09 07:30:52 --> Helper loaded: url_helper
INFO - 2020-02-09 07:30:52 --> Helper loaded: file_helper
INFO - 2020-02-09 07:30:52 --> Helper loaded: form_helper
INFO - 2020-02-09 07:30:52 --> Helper loaded: my_helper
INFO - 2020-02-09 07:30:52 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:30:52 --> Controller Class Initialized
INFO - 2020-02-09 07:30:52 --> Final output sent to browser
DEBUG - 2020-02-09 07:30:52 --> Total execution time: 0.5991
INFO - 2020-02-09 07:30:53 --> Config Class Initialized
INFO - 2020-02-09 07:30:53 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:30:53 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:30:53 --> Utf8 Class Initialized
INFO - 2020-02-09 07:30:53 --> URI Class Initialized
INFO - 2020-02-09 07:30:53 --> Router Class Initialized
INFO - 2020-02-09 07:30:53 --> Output Class Initialized
INFO - 2020-02-09 07:30:53 --> Security Class Initialized
DEBUG - 2020-02-09 07:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:30:53 --> Input Class Initialized
INFO - 2020-02-09 07:30:53 --> Language Class Initialized
INFO - 2020-02-09 07:30:53 --> Language Class Initialized
INFO - 2020-02-09 07:30:53 --> Config Class Initialized
INFO - 2020-02-09 07:30:53 --> Loader Class Initialized
INFO - 2020-02-09 07:30:53 --> Helper loaded: url_helper
INFO - 2020-02-09 07:30:53 --> Helper loaded: file_helper
INFO - 2020-02-09 07:30:53 --> Helper loaded: form_helper
INFO - 2020-02-09 07:30:53 --> Helper loaded: my_helper
INFO - 2020-02-09 07:30:53 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:30:53 --> Controller Class Initialized
INFO - 2020-02-09 07:31:32 --> Config Class Initialized
INFO - 2020-02-09 07:31:32 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:31:32 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:31:32 --> Utf8 Class Initialized
INFO - 2020-02-09 07:31:32 --> URI Class Initialized
INFO - 2020-02-09 07:31:32 --> Router Class Initialized
INFO - 2020-02-09 07:31:32 --> Output Class Initialized
INFO - 2020-02-09 07:31:32 --> Security Class Initialized
DEBUG - 2020-02-09 07:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:31:32 --> Input Class Initialized
INFO - 2020-02-09 07:31:32 --> Language Class Initialized
INFO - 2020-02-09 07:31:32 --> Language Class Initialized
INFO - 2020-02-09 07:31:32 --> Config Class Initialized
INFO - 2020-02-09 07:31:32 --> Loader Class Initialized
INFO - 2020-02-09 07:31:32 --> Helper loaded: url_helper
INFO - 2020-02-09 07:31:32 --> Helper loaded: file_helper
INFO - 2020-02-09 07:31:32 --> Helper loaded: form_helper
INFO - 2020-02-09 07:31:33 --> Helper loaded: my_helper
INFO - 2020-02-09 07:31:33 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:31:33 --> Controller Class Initialized
DEBUG - 2020-02-09 07:31:33 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-09 07:31:33 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:31:33 --> Final output sent to browser
DEBUG - 2020-02-09 07:31:33 --> Total execution time: 0.8828
INFO - 2020-02-09 07:31:33 --> Config Class Initialized
INFO - 2020-02-09 07:31:33 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:31:33 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:31:34 --> Utf8 Class Initialized
INFO - 2020-02-09 07:31:34 --> URI Class Initialized
INFO - 2020-02-09 07:31:34 --> Router Class Initialized
INFO - 2020-02-09 07:31:34 --> Output Class Initialized
INFO - 2020-02-09 07:31:34 --> Security Class Initialized
DEBUG - 2020-02-09 07:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:31:34 --> Input Class Initialized
INFO - 2020-02-09 07:31:34 --> Language Class Initialized
INFO - 2020-02-09 07:31:34 --> Language Class Initialized
INFO - 2020-02-09 07:31:34 --> Config Class Initialized
INFO - 2020-02-09 07:31:34 --> Loader Class Initialized
INFO - 2020-02-09 07:31:34 --> Helper loaded: url_helper
INFO - 2020-02-09 07:31:34 --> Helper loaded: file_helper
INFO - 2020-02-09 07:31:34 --> Helper loaded: form_helper
INFO - 2020-02-09 07:31:34 --> Helper loaded: my_helper
INFO - 2020-02-09 07:31:34 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:31:34 --> Controller Class Initialized
INFO - 2020-02-09 07:31:38 --> Config Class Initialized
INFO - 2020-02-09 07:31:38 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:31:39 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:31:39 --> Utf8 Class Initialized
INFO - 2020-02-09 07:31:39 --> URI Class Initialized
INFO - 2020-02-09 07:31:39 --> Router Class Initialized
INFO - 2020-02-09 07:31:39 --> Output Class Initialized
INFO - 2020-02-09 07:31:39 --> Security Class Initialized
DEBUG - 2020-02-09 07:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:31:39 --> Input Class Initialized
INFO - 2020-02-09 07:31:39 --> Language Class Initialized
INFO - 2020-02-09 07:31:39 --> Language Class Initialized
INFO - 2020-02-09 07:31:39 --> Config Class Initialized
INFO - 2020-02-09 07:31:39 --> Loader Class Initialized
INFO - 2020-02-09 07:31:39 --> Helper loaded: url_helper
INFO - 2020-02-09 07:31:39 --> Helper loaded: file_helper
INFO - 2020-02-09 07:31:39 --> Helper loaded: form_helper
INFO - 2020-02-09 07:31:39 --> Helper loaded: my_helper
INFO - 2020-02-09 07:31:39 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:31:39 --> Controller Class Initialized
INFO - 2020-02-09 07:31:39 --> Final output sent to browser
DEBUG - 2020-02-09 07:31:39 --> Total execution time: 0.5832
INFO - 2020-02-09 07:31:39 --> Config Class Initialized
INFO - 2020-02-09 07:31:39 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:31:39 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:31:39 --> Utf8 Class Initialized
INFO - 2020-02-09 07:31:39 --> URI Class Initialized
INFO - 2020-02-09 07:31:39 --> Router Class Initialized
INFO - 2020-02-09 07:31:39 --> Output Class Initialized
INFO - 2020-02-09 07:31:39 --> Security Class Initialized
DEBUG - 2020-02-09 07:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:31:39 --> Input Class Initialized
INFO - 2020-02-09 07:31:39 --> Language Class Initialized
INFO - 2020-02-09 07:31:40 --> Language Class Initialized
INFO - 2020-02-09 07:31:40 --> Config Class Initialized
INFO - 2020-02-09 07:31:40 --> Loader Class Initialized
INFO - 2020-02-09 07:31:40 --> Helper loaded: url_helper
INFO - 2020-02-09 07:31:40 --> Helper loaded: file_helper
INFO - 2020-02-09 07:31:40 --> Helper loaded: form_helper
INFO - 2020-02-09 07:31:40 --> Helper loaded: my_helper
INFO - 2020-02-09 07:31:40 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:31:40 --> Controller Class Initialized
INFO - 2020-02-09 07:31:43 --> Config Class Initialized
INFO - 2020-02-09 07:31:43 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:31:43 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:31:43 --> Utf8 Class Initialized
INFO - 2020-02-09 07:31:43 --> URI Class Initialized
INFO - 2020-02-09 07:31:43 --> Router Class Initialized
INFO - 2020-02-09 07:31:43 --> Output Class Initialized
INFO - 2020-02-09 07:31:43 --> Security Class Initialized
DEBUG - 2020-02-09 07:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:31:43 --> Input Class Initialized
INFO - 2020-02-09 07:31:43 --> Language Class Initialized
INFO - 2020-02-09 07:31:43 --> Language Class Initialized
INFO - 2020-02-09 07:31:44 --> Config Class Initialized
INFO - 2020-02-09 07:31:44 --> Loader Class Initialized
INFO - 2020-02-09 07:31:44 --> Helper loaded: url_helper
INFO - 2020-02-09 07:31:44 --> Helper loaded: file_helper
INFO - 2020-02-09 07:31:44 --> Helper loaded: form_helper
INFO - 2020-02-09 07:31:44 --> Helper loaded: my_helper
INFO - 2020-02-09 07:31:44 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:31:44 --> Controller Class Initialized
DEBUG - 2020-02-09 07:31:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-09 07:31:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:31:44 --> Final output sent to browser
DEBUG - 2020-02-09 07:31:44 --> Total execution time: 0.8405
INFO - 2020-02-09 07:32:02 --> Config Class Initialized
INFO - 2020-02-09 07:32:02 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:32:02 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:32:02 --> Utf8 Class Initialized
INFO - 2020-02-09 07:32:02 --> URI Class Initialized
INFO - 2020-02-09 07:32:02 --> Router Class Initialized
INFO - 2020-02-09 07:32:02 --> Output Class Initialized
INFO - 2020-02-09 07:32:02 --> Security Class Initialized
DEBUG - 2020-02-09 07:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:32:02 --> Input Class Initialized
INFO - 2020-02-09 07:32:02 --> Language Class Initialized
INFO - 2020-02-09 07:32:03 --> Language Class Initialized
INFO - 2020-02-09 07:32:03 --> Config Class Initialized
INFO - 2020-02-09 07:32:03 --> Loader Class Initialized
INFO - 2020-02-09 07:32:03 --> Helper loaded: url_helper
INFO - 2020-02-09 07:32:03 --> Helper loaded: file_helper
INFO - 2020-02-09 07:32:03 --> Helper loaded: form_helper
INFO - 2020-02-09 07:32:03 --> Helper loaded: my_helper
INFO - 2020-02-09 07:32:03 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:32:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:32:03 --> Controller Class Initialized
DEBUG - 2020-02-09 07:32:03 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-09 07:32:03 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:32:03 --> Final output sent to browser
DEBUG - 2020-02-09 07:32:03 --> Total execution time: 1.1312
INFO - 2020-02-09 07:32:04 --> Config Class Initialized
INFO - 2020-02-09 07:32:04 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:32:04 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:32:04 --> Utf8 Class Initialized
INFO - 2020-02-09 07:32:04 --> URI Class Initialized
INFO - 2020-02-09 07:32:04 --> Router Class Initialized
INFO - 2020-02-09 07:32:04 --> Output Class Initialized
INFO - 2020-02-09 07:32:04 --> Security Class Initialized
DEBUG - 2020-02-09 07:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:32:04 --> Input Class Initialized
INFO - 2020-02-09 07:32:04 --> Language Class Initialized
INFO - 2020-02-09 07:32:04 --> Language Class Initialized
INFO - 2020-02-09 07:32:05 --> Config Class Initialized
INFO - 2020-02-09 07:32:05 --> Loader Class Initialized
INFO - 2020-02-09 07:32:05 --> Helper loaded: url_helper
INFO - 2020-02-09 07:32:05 --> Helper loaded: file_helper
INFO - 2020-02-09 07:32:05 --> Helper loaded: form_helper
INFO - 2020-02-09 07:32:05 --> Helper loaded: my_helper
INFO - 2020-02-09 07:32:05 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:32:05 --> Controller Class Initialized
INFO - 2020-02-09 07:32:12 --> Config Class Initialized
INFO - 2020-02-09 07:32:12 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:32:12 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:32:12 --> Utf8 Class Initialized
INFO - 2020-02-09 07:32:12 --> URI Class Initialized
INFO - 2020-02-09 07:32:12 --> Router Class Initialized
INFO - 2020-02-09 07:32:12 --> Output Class Initialized
INFO - 2020-02-09 07:32:12 --> Security Class Initialized
DEBUG - 2020-02-09 07:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:32:12 --> Input Class Initialized
INFO - 2020-02-09 07:32:12 --> Language Class Initialized
INFO - 2020-02-09 07:32:12 --> Language Class Initialized
INFO - 2020-02-09 07:32:12 --> Config Class Initialized
INFO - 2020-02-09 07:32:12 --> Loader Class Initialized
INFO - 2020-02-09 07:32:12 --> Helper loaded: url_helper
INFO - 2020-02-09 07:32:12 --> Helper loaded: file_helper
INFO - 2020-02-09 07:32:12 --> Helper loaded: form_helper
INFO - 2020-02-09 07:32:12 --> Helper loaded: my_helper
INFO - 2020-02-09 07:32:12 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:32:12 --> Controller Class Initialized
INFO - 2020-02-09 07:32:12 --> Final output sent to browser
DEBUG - 2020-02-09 07:32:12 --> Total execution time: 0.6256
INFO - 2020-02-09 07:32:12 --> Config Class Initialized
INFO - 2020-02-09 07:32:12 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:32:13 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:32:13 --> Utf8 Class Initialized
INFO - 2020-02-09 07:32:13 --> URI Class Initialized
INFO - 2020-02-09 07:32:13 --> Router Class Initialized
INFO - 2020-02-09 07:32:13 --> Output Class Initialized
INFO - 2020-02-09 07:32:13 --> Security Class Initialized
DEBUG - 2020-02-09 07:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:32:13 --> Input Class Initialized
INFO - 2020-02-09 07:32:13 --> Language Class Initialized
INFO - 2020-02-09 07:32:13 --> Language Class Initialized
INFO - 2020-02-09 07:32:13 --> Config Class Initialized
INFO - 2020-02-09 07:32:13 --> Loader Class Initialized
INFO - 2020-02-09 07:32:13 --> Helper loaded: url_helper
INFO - 2020-02-09 07:32:13 --> Helper loaded: file_helper
INFO - 2020-02-09 07:32:14 --> Helper loaded: form_helper
INFO - 2020-02-09 07:32:14 --> Helper loaded: my_helper
INFO - 2020-02-09 07:32:14 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:32:14 --> Controller Class Initialized
INFO - 2020-02-09 07:32:15 --> Config Class Initialized
INFO - 2020-02-09 07:32:15 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:32:15 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:32:15 --> Utf8 Class Initialized
INFO - 2020-02-09 07:32:15 --> URI Class Initialized
INFO - 2020-02-09 07:32:15 --> Router Class Initialized
INFO - 2020-02-09 07:32:15 --> Output Class Initialized
INFO - 2020-02-09 07:32:15 --> Security Class Initialized
DEBUG - 2020-02-09 07:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:32:15 --> Input Class Initialized
INFO - 2020-02-09 07:32:15 --> Language Class Initialized
INFO - 2020-02-09 07:32:15 --> Language Class Initialized
INFO - 2020-02-09 07:32:15 --> Config Class Initialized
INFO - 2020-02-09 07:32:16 --> Loader Class Initialized
INFO - 2020-02-09 07:32:16 --> Helper loaded: url_helper
INFO - 2020-02-09 07:32:16 --> Helper loaded: file_helper
INFO - 2020-02-09 07:32:16 --> Helper loaded: form_helper
INFO - 2020-02-09 07:32:16 --> Helper loaded: my_helper
INFO - 2020-02-09 07:32:16 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:32:16 --> Controller Class Initialized
DEBUG - 2020-02-09 07:32:16 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-09 07:32:16 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:32:16 --> Final output sent to browser
DEBUG - 2020-02-09 07:32:16 --> Total execution time: 1.0038
INFO - 2020-02-09 07:32:53 --> Config Class Initialized
INFO - 2020-02-09 07:32:53 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:32:53 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:32:53 --> Utf8 Class Initialized
INFO - 2020-02-09 07:32:53 --> URI Class Initialized
DEBUG - 2020-02-09 07:32:53 --> No URI present. Default controller set.
INFO - 2020-02-09 07:32:53 --> Router Class Initialized
INFO - 2020-02-09 07:32:54 --> Output Class Initialized
INFO - 2020-02-09 07:32:54 --> Security Class Initialized
DEBUG - 2020-02-09 07:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:32:54 --> Input Class Initialized
INFO - 2020-02-09 07:32:54 --> Language Class Initialized
INFO - 2020-02-09 07:32:54 --> Language Class Initialized
INFO - 2020-02-09 07:32:54 --> Config Class Initialized
INFO - 2020-02-09 07:32:54 --> Loader Class Initialized
INFO - 2020-02-09 07:32:54 --> Helper loaded: url_helper
INFO - 2020-02-09 07:32:54 --> Helper loaded: file_helper
INFO - 2020-02-09 07:32:54 --> Helper loaded: form_helper
INFO - 2020-02-09 07:32:54 --> Helper loaded: my_helper
INFO - 2020-02-09 07:32:54 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:32:54 --> Controller Class Initialized
DEBUG - 2020-02-09 07:32:54 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-09 07:32:54 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:32:54 --> Final output sent to browser
DEBUG - 2020-02-09 07:32:54 --> Total execution time: 1.0279
INFO - 2020-02-09 07:35:47 --> Config Class Initialized
INFO - 2020-02-09 07:35:47 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:35:47 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:35:47 --> Utf8 Class Initialized
INFO - 2020-02-09 07:35:47 --> URI Class Initialized
INFO - 2020-02-09 07:35:47 --> Router Class Initialized
INFO - 2020-02-09 07:35:47 --> Output Class Initialized
INFO - 2020-02-09 07:35:47 --> Security Class Initialized
DEBUG - 2020-02-09 07:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:35:47 --> Input Class Initialized
INFO - 2020-02-09 07:35:47 --> Language Class Initialized
INFO - 2020-02-09 07:35:47 --> Language Class Initialized
INFO - 2020-02-09 07:35:47 --> Config Class Initialized
INFO - 2020-02-09 07:35:47 --> Loader Class Initialized
INFO - 2020-02-09 07:35:47 --> Helper loaded: url_helper
INFO - 2020-02-09 07:35:48 --> Helper loaded: file_helper
INFO - 2020-02-09 07:35:48 --> Helper loaded: form_helper
INFO - 2020-02-09 07:35:48 --> Helper loaded: my_helper
INFO - 2020-02-09 07:35:48 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:35:48 --> Controller Class Initialized
INFO - 2020-02-09 07:35:48 --> Helper loaded: cookie_helper
INFO - 2020-02-09 07:35:48 --> Config Class Initialized
INFO - 2020-02-09 07:35:48 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:35:48 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:35:48 --> Utf8 Class Initialized
INFO - 2020-02-09 07:35:48 --> URI Class Initialized
INFO - 2020-02-09 07:35:48 --> Router Class Initialized
INFO - 2020-02-09 07:35:48 --> Output Class Initialized
INFO - 2020-02-09 07:35:48 --> Security Class Initialized
DEBUG - 2020-02-09 07:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:35:48 --> Input Class Initialized
INFO - 2020-02-09 07:35:48 --> Language Class Initialized
INFO - 2020-02-09 07:35:48 --> Language Class Initialized
INFO - 2020-02-09 07:35:48 --> Config Class Initialized
INFO - 2020-02-09 07:35:48 --> Loader Class Initialized
INFO - 2020-02-09 07:35:48 --> Helper loaded: url_helper
INFO - 2020-02-09 07:35:48 --> Helper loaded: file_helper
INFO - 2020-02-09 07:35:48 --> Helper loaded: form_helper
INFO - 2020-02-09 07:35:48 --> Helper loaded: my_helper
INFO - 2020-02-09 07:35:48 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:35:48 --> Controller Class Initialized
INFO - 2020-02-09 07:35:48 --> Config Class Initialized
INFO - 2020-02-09 07:35:48 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:35:48 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:35:48 --> Utf8 Class Initialized
INFO - 2020-02-09 07:35:48 --> URI Class Initialized
INFO - 2020-02-09 07:35:48 --> Router Class Initialized
INFO - 2020-02-09 07:35:48 --> Output Class Initialized
INFO - 2020-02-09 07:35:48 --> Security Class Initialized
DEBUG - 2020-02-09 07:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:35:48 --> Input Class Initialized
INFO - 2020-02-09 07:35:48 --> Language Class Initialized
INFO - 2020-02-09 07:35:49 --> Language Class Initialized
INFO - 2020-02-09 07:35:49 --> Config Class Initialized
INFO - 2020-02-09 07:35:49 --> Loader Class Initialized
INFO - 2020-02-09 07:35:49 --> Helper loaded: url_helper
INFO - 2020-02-09 07:35:49 --> Helper loaded: file_helper
INFO - 2020-02-09 07:35:49 --> Helper loaded: form_helper
INFO - 2020-02-09 07:35:49 --> Helper loaded: my_helper
INFO - 2020-02-09 07:35:49 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:35:49 --> Controller Class Initialized
DEBUG - 2020-02-09 07:35:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 07:35:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:35:49 --> Final output sent to browser
DEBUG - 2020-02-09 07:35:49 --> Total execution time: 0.5585
INFO - 2020-02-09 07:37:04 --> Config Class Initialized
INFO - 2020-02-09 07:37:04 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:37:04 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:37:04 --> Utf8 Class Initialized
INFO - 2020-02-09 07:37:04 --> URI Class Initialized
INFO - 2020-02-09 07:37:04 --> Router Class Initialized
INFO - 2020-02-09 07:37:04 --> Output Class Initialized
INFO - 2020-02-09 07:37:04 --> Security Class Initialized
DEBUG - 2020-02-09 07:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:37:04 --> Input Class Initialized
INFO - 2020-02-09 07:37:04 --> Language Class Initialized
INFO - 2020-02-09 07:37:04 --> Language Class Initialized
INFO - 2020-02-09 07:37:04 --> Config Class Initialized
INFO - 2020-02-09 07:37:04 --> Loader Class Initialized
INFO - 2020-02-09 07:37:04 --> Helper loaded: url_helper
INFO - 2020-02-09 07:37:04 --> Helper loaded: file_helper
INFO - 2020-02-09 07:37:04 --> Helper loaded: form_helper
INFO - 2020-02-09 07:37:04 --> Helper loaded: my_helper
INFO - 2020-02-09 07:37:04 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:37:05 --> Controller Class Initialized
INFO - 2020-02-09 07:37:05 --> Helper loaded: cookie_helper
INFO - 2020-02-09 07:37:05 --> Final output sent to browser
DEBUG - 2020-02-09 07:37:05 --> Total execution time: 1.0072
INFO - 2020-02-09 07:37:05 --> Config Class Initialized
INFO - 2020-02-09 07:37:05 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:37:05 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:37:05 --> Utf8 Class Initialized
INFO - 2020-02-09 07:37:05 --> URI Class Initialized
INFO - 2020-02-09 07:37:05 --> Router Class Initialized
INFO - 2020-02-09 07:37:05 --> Output Class Initialized
INFO - 2020-02-09 07:37:05 --> Security Class Initialized
DEBUG - 2020-02-09 07:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:37:05 --> Input Class Initialized
INFO - 2020-02-09 07:37:06 --> Language Class Initialized
INFO - 2020-02-09 07:37:06 --> Language Class Initialized
INFO - 2020-02-09 07:37:06 --> Config Class Initialized
INFO - 2020-02-09 07:37:06 --> Loader Class Initialized
INFO - 2020-02-09 07:37:06 --> Helper loaded: url_helper
INFO - 2020-02-09 07:37:06 --> Helper loaded: file_helper
INFO - 2020-02-09 07:37:06 --> Helper loaded: form_helper
INFO - 2020-02-09 07:37:06 --> Helper loaded: my_helper
INFO - 2020-02-09 07:37:06 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:37:06 --> Controller Class Initialized
DEBUG - 2020-02-09 07:37:07 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-09 07:37:07 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:37:07 --> Final output sent to browser
DEBUG - 2020-02-09 07:37:07 --> Total execution time: 1.7923
INFO - 2020-02-09 07:38:40 --> Config Class Initialized
INFO - 2020-02-09 07:38:40 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:38:40 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:38:40 --> Utf8 Class Initialized
INFO - 2020-02-09 07:38:40 --> URI Class Initialized
INFO - 2020-02-09 07:38:41 --> Router Class Initialized
INFO - 2020-02-09 07:38:41 --> Output Class Initialized
INFO - 2020-02-09 07:38:41 --> Security Class Initialized
DEBUG - 2020-02-09 07:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:38:41 --> Input Class Initialized
INFO - 2020-02-09 07:38:41 --> Language Class Initialized
INFO - 2020-02-09 07:38:41 --> Language Class Initialized
INFO - 2020-02-09 07:38:41 --> Config Class Initialized
INFO - 2020-02-09 07:38:41 --> Loader Class Initialized
INFO - 2020-02-09 07:38:41 --> Helper loaded: url_helper
INFO - 2020-02-09 07:38:41 --> Helper loaded: file_helper
INFO - 2020-02-09 07:38:41 --> Helper loaded: form_helper
INFO - 2020-02-09 07:38:41 --> Helper loaded: my_helper
INFO - 2020-02-09 07:38:41 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:38:41 --> Controller Class Initialized
DEBUG - 2020-02-09 07:38:41 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-02-09 07:38:41 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:38:41 --> Final output sent to browser
DEBUG - 2020-02-09 07:38:41 --> Total execution time: 0.8860
INFO - 2020-02-09 07:39:14 --> Config Class Initialized
INFO - 2020-02-09 07:39:14 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:39:14 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:39:14 --> Utf8 Class Initialized
INFO - 2020-02-09 07:39:14 --> URI Class Initialized
INFO - 2020-02-09 07:39:14 --> Router Class Initialized
INFO - 2020-02-09 07:39:14 --> Output Class Initialized
INFO - 2020-02-09 07:39:14 --> Security Class Initialized
DEBUG - 2020-02-09 07:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:39:14 --> Input Class Initialized
INFO - 2020-02-09 07:39:14 --> Language Class Initialized
INFO - 2020-02-09 07:39:15 --> Language Class Initialized
INFO - 2020-02-09 07:39:15 --> Config Class Initialized
INFO - 2020-02-09 07:39:15 --> Loader Class Initialized
INFO - 2020-02-09 07:39:15 --> Helper loaded: url_helper
INFO - 2020-02-09 07:39:15 --> Helper loaded: file_helper
INFO - 2020-02-09 07:39:15 --> Helper loaded: form_helper
INFO - 2020-02-09 07:39:15 --> Helper loaded: my_helper
INFO - 2020-02-09 07:39:15 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:39:15 --> Controller Class Initialized
DEBUG - 2020-02-09 07:39:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-02-09 07:39:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:39:15 --> Final output sent to browser
DEBUG - 2020-02-09 07:39:15 --> Total execution time: 1.1050
INFO - 2020-02-09 07:39:16 --> Config Class Initialized
INFO - 2020-02-09 07:39:16 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:39:16 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:39:16 --> Utf8 Class Initialized
INFO - 2020-02-09 07:39:16 --> URI Class Initialized
INFO - 2020-02-09 07:39:16 --> Router Class Initialized
INFO - 2020-02-09 07:39:16 --> Output Class Initialized
INFO - 2020-02-09 07:39:16 --> Security Class Initialized
DEBUG - 2020-02-09 07:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:39:16 --> Input Class Initialized
INFO - 2020-02-09 07:39:16 --> Language Class Initialized
INFO - 2020-02-09 07:39:16 --> Language Class Initialized
INFO - 2020-02-09 07:39:16 --> Config Class Initialized
INFO - 2020-02-09 07:39:16 --> Loader Class Initialized
INFO - 2020-02-09 07:39:16 --> Helper loaded: url_helper
INFO - 2020-02-09 07:39:16 --> Helper loaded: file_helper
INFO - 2020-02-09 07:39:17 --> Helper loaded: form_helper
INFO - 2020-02-09 07:39:17 --> Helper loaded: my_helper
INFO - 2020-02-09 07:39:17 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:39:17 --> Controller Class Initialized
INFO - 2020-02-09 07:39:48 --> Config Class Initialized
INFO - 2020-02-09 07:39:48 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:39:48 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:39:48 --> Utf8 Class Initialized
INFO - 2020-02-09 07:39:48 --> URI Class Initialized
INFO - 2020-02-09 07:39:48 --> Router Class Initialized
INFO - 2020-02-09 07:39:48 --> Output Class Initialized
INFO - 2020-02-09 07:39:48 --> Security Class Initialized
DEBUG - 2020-02-09 07:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:39:48 --> Input Class Initialized
INFO - 2020-02-09 07:39:48 --> Language Class Initialized
INFO - 2020-02-09 07:39:48 --> Language Class Initialized
INFO - 2020-02-09 07:39:48 --> Config Class Initialized
INFO - 2020-02-09 07:39:48 --> Loader Class Initialized
INFO - 2020-02-09 07:39:48 --> Helper loaded: url_helper
INFO - 2020-02-09 07:39:48 --> Helper loaded: file_helper
INFO - 2020-02-09 07:39:48 --> Helper loaded: form_helper
INFO - 2020-02-09 07:39:48 --> Helper loaded: my_helper
INFO - 2020-02-09 07:39:48 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:39:48 --> Controller Class Initialized
INFO - 2020-02-09 07:39:48 --> Final output sent to browser
DEBUG - 2020-02-09 07:39:48 --> Total execution time: 0.6735
INFO - 2020-02-09 07:40:01 --> Config Class Initialized
INFO - 2020-02-09 07:40:01 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:40:01 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:40:01 --> Utf8 Class Initialized
INFO - 2020-02-09 07:40:01 --> URI Class Initialized
INFO - 2020-02-09 07:40:01 --> Router Class Initialized
INFO - 2020-02-09 07:40:01 --> Output Class Initialized
INFO - 2020-02-09 07:40:02 --> Security Class Initialized
DEBUG - 2020-02-09 07:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:40:02 --> Input Class Initialized
INFO - 2020-02-09 07:40:02 --> Language Class Initialized
INFO - 2020-02-09 07:40:02 --> Language Class Initialized
INFO - 2020-02-09 07:40:02 --> Config Class Initialized
INFO - 2020-02-09 07:40:02 --> Loader Class Initialized
INFO - 2020-02-09 07:40:02 --> Helper loaded: url_helper
INFO - 2020-02-09 07:40:02 --> Helper loaded: file_helper
INFO - 2020-02-09 07:40:02 --> Helper loaded: form_helper
INFO - 2020-02-09 07:40:02 --> Helper loaded: my_helper
INFO - 2020-02-09 07:40:02 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:40:02 --> Controller Class Initialized
INFO - 2020-02-09 07:40:02 --> Final output sent to browser
DEBUG - 2020-02-09 07:40:02 --> Total execution time: 0.8610
INFO - 2020-02-09 07:40:02 --> Config Class Initialized
INFO - 2020-02-09 07:40:02 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:40:02 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:40:02 --> Utf8 Class Initialized
INFO - 2020-02-09 07:40:03 --> URI Class Initialized
INFO - 2020-02-09 07:40:03 --> Router Class Initialized
INFO - 2020-02-09 07:40:03 --> Output Class Initialized
INFO - 2020-02-09 07:40:03 --> Security Class Initialized
DEBUG - 2020-02-09 07:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:40:03 --> Input Class Initialized
INFO - 2020-02-09 07:40:03 --> Language Class Initialized
INFO - 2020-02-09 07:40:03 --> Language Class Initialized
INFO - 2020-02-09 07:40:03 --> Config Class Initialized
INFO - 2020-02-09 07:40:03 --> Loader Class Initialized
INFO - 2020-02-09 07:40:03 --> Helper loaded: url_helper
INFO - 2020-02-09 07:40:03 --> Helper loaded: file_helper
INFO - 2020-02-09 07:40:03 --> Helper loaded: form_helper
INFO - 2020-02-09 07:40:03 --> Helper loaded: my_helper
INFO - 2020-02-09 07:40:04 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:40:04 --> Controller Class Initialized
INFO - 2020-02-09 07:40:06 --> Config Class Initialized
INFO - 2020-02-09 07:40:06 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:40:06 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:40:06 --> Utf8 Class Initialized
INFO - 2020-02-09 07:40:06 --> URI Class Initialized
INFO - 2020-02-09 07:40:06 --> Router Class Initialized
INFO - 2020-02-09 07:40:06 --> Output Class Initialized
INFO - 2020-02-09 07:40:06 --> Security Class Initialized
DEBUG - 2020-02-09 07:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:40:07 --> Input Class Initialized
INFO - 2020-02-09 07:40:07 --> Language Class Initialized
INFO - 2020-02-09 07:40:07 --> Language Class Initialized
INFO - 2020-02-09 07:40:07 --> Config Class Initialized
INFO - 2020-02-09 07:40:07 --> Loader Class Initialized
INFO - 2020-02-09 07:40:07 --> Helper loaded: url_helper
INFO - 2020-02-09 07:40:07 --> Helper loaded: file_helper
INFO - 2020-02-09 07:40:07 --> Helper loaded: form_helper
INFO - 2020-02-09 07:40:07 --> Helper loaded: my_helper
INFO - 2020-02-09 07:40:07 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:40:07 --> Controller Class Initialized
INFO - 2020-02-09 07:40:07 --> Final output sent to browser
DEBUG - 2020-02-09 07:40:07 --> Total execution time: 0.6666
INFO - 2020-02-09 07:40:12 --> Config Class Initialized
INFO - 2020-02-09 07:40:12 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:40:12 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:40:12 --> Utf8 Class Initialized
INFO - 2020-02-09 07:40:12 --> URI Class Initialized
INFO - 2020-02-09 07:40:12 --> Router Class Initialized
INFO - 2020-02-09 07:40:12 --> Output Class Initialized
INFO - 2020-02-09 07:40:12 --> Security Class Initialized
DEBUG - 2020-02-09 07:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:40:12 --> Input Class Initialized
INFO - 2020-02-09 07:40:12 --> Language Class Initialized
INFO - 2020-02-09 07:40:12 --> Language Class Initialized
INFO - 2020-02-09 07:40:12 --> Config Class Initialized
INFO - 2020-02-09 07:40:12 --> Loader Class Initialized
INFO - 2020-02-09 07:40:12 --> Helper loaded: url_helper
INFO - 2020-02-09 07:40:13 --> Helper loaded: file_helper
INFO - 2020-02-09 07:40:13 --> Helper loaded: form_helper
INFO - 2020-02-09 07:40:13 --> Helper loaded: my_helper
INFO - 2020-02-09 07:40:13 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:40:13 --> Controller Class Initialized
INFO - 2020-02-09 07:40:13 --> Final output sent to browser
DEBUG - 2020-02-09 07:40:13 --> Total execution time: 1.1460
INFO - 2020-02-09 07:40:21 --> Config Class Initialized
INFO - 2020-02-09 07:40:21 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:40:21 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:40:21 --> Utf8 Class Initialized
INFO - 2020-02-09 07:40:21 --> URI Class Initialized
INFO - 2020-02-09 07:40:21 --> Router Class Initialized
INFO - 2020-02-09 07:40:21 --> Output Class Initialized
INFO - 2020-02-09 07:40:21 --> Security Class Initialized
DEBUG - 2020-02-09 07:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:40:21 --> Input Class Initialized
INFO - 2020-02-09 07:40:21 --> Language Class Initialized
INFO - 2020-02-09 07:40:21 --> Language Class Initialized
INFO - 2020-02-09 07:40:21 --> Config Class Initialized
INFO - 2020-02-09 07:40:22 --> Loader Class Initialized
INFO - 2020-02-09 07:40:22 --> Helper loaded: url_helper
INFO - 2020-02-09 07:40:22 --> Helper loaded: file_helper
INFO - 2020-02-09 07:40:22 --> Helper loaded: form_helper
INFO - 2020-02-09 07:40:22 --> Helper loaded: my_helper
INFO - 2020-02-09 07:40:22 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:40:22 --> Controller Class Initialized
INFO - 2020-02-09 07:40:22 --> Final output sent to browser
DEBUG - 2020-02-09 07:40:22 --> Total execution time: 0.7039
INFO - 2020-02-09 07:40:22 --> Config Class Initialized
INFO - 2020-02-09 07:40:22 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:40:22 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:40:22 --> Utf8 Class Initialized
INFO - 2020-02-09 07:40:22 --> URI Class Initialized
INFO - 2020-02-09 07:40:22 --> Router Class Initialized
INFO - 2020-02-09 07:40:22 --> Output Class Initialized
INFO - 2020-02-09 07:40:22 --> Security Class Initialized
DEBUG - 2020-02-09 07:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:40:22 --> Input Class Initialized
INFO - 2020-02-09 07:40:22 --> Language Class Initialized
INFO - 2020-02-09 07:40:23 --> Language Class Initialized
INFO - 2020-02-09 07:40:23 --> Config Class Initialized
INFO - 2020-02-09 07:40:23 --> Loader Class Initialized
INFO - 2020-02-09 07:40:23 --> Helper loaded: url_helper
INFO - 2020-02-09 07:40:23 --> Helper loaded: file_helper
INFO - 2020-02-09 07:40:23 --> Helper loaded: form_helper
INFO - 2020-02-09 07:40:23 --> Helper loaded: my_helper
INFO - 2020-02-09 07:40:23 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:40:23 --> Controller Class Initialized
INFO - 2020-02-09 07:40:32 --> Config Class Initialized
INFO - 2020-02-09 07:40:32 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:40:32 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:40:32 --> Utf8 Class Initialized
INFO - 2020-02-09 07:40:32 --> URI Class Initialized
INFO - 2020-02-09 07:40:32 --> Router Class Initialized
INFO - 2020-02-09 07:40:32 --> Output Class Initialized
INFO - 2020-02-09 07:40:32 --> Security Class Initialized
DEBUG - 2020-02-09 07:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:40:32 --> Input Class Initialized
INFO - 2020-02-09 07:40:32 --> Language Class Initialized
INFO - 2020-02-09 07:40:32 --> Language Class Initialized
INFO - 2020-02-09 07:40:32 --> Config Class Initialized
INFO - 2020-02-09 07:40:32 --> Loader Class Initialized
INFO - 2020-02-09 07:40:32 --> Helper loaded: url_helper
INFO - 2020-02-09 07:40:32 --> Helper loaded: file_helper
INFO - 2020-02-09 07:40:32 --> Helper loaded: form_helper
INFO - 2020-02-09 07:40:32 --> Helper loaded: my_helper
INFO - 2020-02-09 07:40:32 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:40:32 --> Controller Class Initialized
INFO - 2020-02-09 07:40:32 --> Final output sent to browser
DEBUG - 2020-02-09 07:40:33 --> Total execution time: 0.6338
INFO - 2020-02-09 07:40:42 --> Config Class Initialized
INFO - 2020-02-09 07:40:42 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:40:42 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:40:42 --> Utf8 Class Initialized
INFO - 2020-02-09 07:40:42 --> URI Class Initialized
INFO - 2020-02-09 07:40:42 --> Router Class Initialized
INFO - 2020-02-09 07:40:42 --> Output Class Initialized
INFO - 2020-02-09 07:40:42 --> Security Class Initialized
DEBUG - 2020-02-09 07:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:40:42 --> Input Class Initialized
INFO - 2020-02-09 07:40:42 --> Language Class Initialized
INFO - 2020-02-09 07:40:42 --> Language Class Initialized
INFO - 2020-02-09 07:40:42 --> Config Class Initialized
INFO - 2020-02-09 07:40:42 --> Loader Class Initialized
INFO - 2020-02-09 07:40:42 --> Helper loaded: url_helper
INFO - 2020-02-09 07:40:42 --> Helper loaded: file_helper
INFO - 2020-02-09 07:40:42 --> Helper loaded: form_helper
INFO - 2020-02-09 07:40:43 --> Helper loaded: my_helper
INFO - 2020-02-09 07:40:43 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:40:43 --> Controller Class Initialized
INFO - 2020-02-09 07:40:43 --> Final output sent to browser
DEBUG - 2020-02-09 07:40:43 --> Total execution time: 0.7324
INFO - 2020-02-09 07:41:08 --> Config Class Initialized
INFO - 2020-02-09 07:41:09 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:41:09 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:41:09 --> Utf8 Class Initialized
INFO - 2020-02-09 07:41:09 --> URI Class Initialized
INFO - 2020-02-09 07:41:09 --> Router Class Initialized
INFO - 2020-02-09 07:41:09 --> Output Class Initialized
INFO - 2020-02-09 07:41:09 --> Security Class Initialized
DEBUG - 2020-02-09 07:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:41:09 --> Input Class Initialized
INFO - 2020-02-09 07:41:09 --> Language Class Initialized
INFO - 2020-02-09 07:41:09 --> Language Class Initialized
INFO - 2020-02-09 07:41:09 --> Config Class Initialized
INFO - 2020-02-09 07:41:09 --> Loader Class Initialized
INFO - 2020-02-09 07:41:09 --> Helper loaded: url_helper
INFO - 2020-02-09 07:41:09 --> Helper loaded: file_helper
INFO - 2020-02-09 07:41:09 --> Helper loaded: form_helper
INFO - 2020-02-09 07:41:09 --> Helper loaded: my_helper
INFO - 2020-02-09 07:41:09 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:41:09 --> Controller Class Initialized
INFO - 2020-02-09 07:43:02 --> Config Class Initialized
INFO - 2020-02-09 07:43:02 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:43:02 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:43:02 --> Utf8 Class Initialized
INFO - 2020-02-09 07:43:02 --> URI Class Initialized
INFO - 2020-02-09 07:43:02 --> Router Class Initialized
INFO - 2020-02-09 07:43:02 --> Output Class Initialized
INFO - 2020-02-09 07:43:02 --> Security Class Initialized
DEBUG - 2020-02-09 07:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:43:02 --> Input Class Initialized
INFO - 2020-02-09 07:43:02 --> Language Class Initialized
INFO - 2020-02-09 07:43:03 --> Language Class Initialized
INFO - 2020-02-09 07:43:03 --> Config Class Initialized
INFO - 2020-02-09 07:43:03 --> Loader Class Initialized
INFO - 2020-02-09 07:43:03 --> Helper loaded: url_helper
INFO - 2020-02-09 07:43:03 --> Helper loaded: file_helper
INFO - 2020-02-09 07:43:03 --> Helper loaded: form_helper
INFO - 2020-02-09 07:43:03 --> Helper loaded: my_helper
INFO - 2020-02-09 07:43:03 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:43:03 --> Controller Class Initialized
DEBUG - 2020-02-09 07:43:03 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_pengetahuan/views/form.php
DEBUG - 2020-02-09 07:43:03 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:43:03 --> Final output sent to browser
DEBUG - 2020-02-09 07:43:03 --> Total execution time: 1.1480
INFO - 2020-02-09 07:43:23 --> Config Class Initialized
INFO - 2020-02-09 07:43:23 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:43:23 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:43:23 --> Utf8 Class Initialized
INFO - 2020-02-09 07:43:23 --> URI Class Initialized
INFO - 2020-02-09 07:43:23 --> Router Class Initialized
INFO - 2020-02-09 07:43:23 --> Output Class Initialized
INFO - 2020-02-09 07:43:23 --> Security Class Initialized
DEBUG - 2020-02-09 07:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:43:23 --> Input Class Initialized
INFO - 2020-02-09 07:43:24 --> Language Class Initialized
INFO - 2020-02-09 07:43:24 --> Language Class Initialized
INFO - 2020-02-09 07:43:24 --> Config Class Initialized
INFO - 2020-02-09 07:43:24 --> Loader Class Initialized
INFO - 2020-02-09 07:43:24 --> Helper loaded: url_helper
INFO - 2020-02-09 07:43:24 --> Helper loaded: file_helper
INFO - 2020-02-09 07:43:24 --> Helper loaded: form_helper
INFO - 2020-02-09 07:43:24 --> Helper loaded: my_helper
INFO - 2020-02-09 07:43:24 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:43:24 --> Controller Class Initialized
INFO - 2020-02-09 07:43:24 --> Config Class Initialized
INFO - 2020-02-09 07:43:24 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:43:24 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:43:24 --> Utf8 Class Initialized
INFO - 2020-02-09 07:43:25 --> URI Class Initialized
INFO - 2020-02-09 07:43:25 --> Router Class Initialized
INFO - 2020-02-09 07:43:25 --> Output Class Initialized
INFO - 2020-02-09 07:43:25 --> Security Class Initialized
DEBUG - 2020-02-09 07:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:43:25 --> Input Class Initialized
INFO - 2020-02-09 07:43:25 --> Language Class Initialized
INFO - 2020-02-09 07:43:25 --> Language Class Initialized
INFO - 2020-02-09 07:43:25 --> Config Class Initialized
INFO - 2020-02-09 07:43:25 --> Loader Class Initialized
INFO - 2020-02-09 07:43:25 --> Helper loaded: url_helper
INFO - 2020-02-09 07:43:25 --> Helper loaded: file_helper
INFO - 2020-02-09 07:43:25 --> Helper loaded: form_helper
INFO - 2020-02-09 07:43:25 --> Helper loaded: my_helper
INFO - 2020-02-09 07:43:25 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:43:25 --> Controller Class Initialized
DEBUG - 2020-02-09 07:43:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-02-09 07:43:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:43:25 --> Final output sent to browser
DEBUG - 2020-02-09 07:43:25 --> Total execution time: 0.7810
INFO - 2020-02-09 07:43:25 --> Config Class Initialized
INFO - 2020-02-09 07:43:26 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:43:26 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:43:26 --> Utf8 Class Initialized
INFO - 2020-02-09 07:43:26 --> URI Class Initialized
INFO - 2020-02-09 07:43:26 --> Router Class Initialized
INFO - 2020-02-09 07:43:26 --> Output Class Initialized
INFO - 2020-02-09 07:43:26 --> Security Class Initialized
DEBUG - 2020-02-09 07:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:43:26 --> Input Class Initialized
INFO - 2020-02-09 07:43:26 --> Language Class Initialized
INFO - 2020-02-09 07:43:26 --> Language Class Initialized
INFO - 2020-02-09 07:43:26 --> Config Class Initialized
INFO - 2020-02-09 07:43:26 --> Loader Class Initialized
INFO - 2020-02-09 07:43:26 --> Helper loaded: url_helper
INFO - 2020-02-09 07:43:26 --> Helper loaded: file_helper
INFO - 2020-02-09 07:43:26 --> Helper loaded: form_helper
INFO - 2020-02-09 07:43:26 --> Helper loaded: my_helper
INFO - 2020-02-09 07:43:26 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:43:26 --> Controller Class Initialized
INFO - 2020-02-09 07:43:32 --> Config Class Initialized
INFO - 2020-02-09 07:43:32 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:43:32 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:43:32 --> Utf8 Class Initialized
INFO - 2020-02-09 07:43:32 --> URI Class Initialized
INFO - 2020-02-09 07:43:32 --> Router Class Initialized
INFO - 2020-02-09 07:43:32 --> Output Class Initialized
INFO - 2020-02-09 07:43:32 --> Security Class Initialized
DEBUG - 2020-02-09 07:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:43:33 --> Input Class Initialized
INFO - 2020-02-09 07:43:33 --> Language Class Initialized
INFO - 2020-02-09 07:43:33 --> Language Class Initialized
INFO - 2020-02-09 07:43:33 --> Config Class Initialized
INFO - 2020-02-09 07:43:33 --> Loader Class Initialized
INFO - 2020-02-09 07:43:33 --> Helper loaded: url_helper
INFO - 2020-02-09 07:43:33 --> Helper loaded: file_helper
INFO - 2020-02-09 07:43:33 --> Helper loaded: form_helper
INFO - 2020-02-09 07:43:33 --> Helper loaded: my_helper
INFO - 2020-02-09 07:43:33 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:43:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:43:33 --> Controller Class Initialized
INFO - 2020-02-09 07:43:33 --> Final output sent to browser
DEBUG - 2020-02-09 07:43:33 --> Total execution time: 0.5465
INFO - 2020-02-09 07:43:38 --> Config Class Initialized
INFO - 2020-02-09 07:43:38 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:43:38 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:43:38 --> Utf8 Class Initialized
INFO - 2020-02-09 07:43:38 --> URI Class Initialized
INFO - 2020-02-09 07:43:38 --> Router Class Initialized
INFO - 2020-02-09 07:43:38 --> Output Class Initialized
INFO - 2020-02-09 07:43:38 --> Security Class Initialized
DEBUG - 2020-02-09 07:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:43:38 --> Input Class Initialized
INFO - 2020-02-09 07:43:39 --> Language Class Initialized
INFO - 2020-02-09 07:43:39 --> Language Class Initialized
INFO - 2020-02-09 07:43:39 --> Config Class Initialized
INFO - 2020-02-09 07:43:39 --> Loader Class Initialized
INFO - 2020-02-09 07:43:39 --> Helper loaded: url_helper
INFO - 2020-02-09 07:43:39 --> Helper loaded: file_helper
INFO - 2020-02-09 07:43:39 --> Helper loaded: form_helper
INFO - 2020-02-09 07:43:39 --> Helper loaded: my_helper
INFO - 2020-02-09 07:43:39 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:43:39 --> Controller Class Initialized
INFO - 2020-02-09 07:43:39 --> Final output sent to browser
DEBUG - 2020-02-09 07:43:39 --> Total execution time: 0.6466
INFO - 2020-02-09 07:43:42 --> Config Class Initialized
INFO - 2020-02-09 07:43:42 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:43:42 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:43:42 --> Utf8 Class Initialized
INFO - 2020-02-09 07:43:42 --> URI Class Initialized
INFO - 2020-02-09 07:43:42 --> Router Class Initialized
INFO - 2020-02-09 07:43:42 --> Output Class Initialized
INFO - 2020-02-09 07:43:42 --> Security Class Initialized
DEBUG - 2020-02-09 07:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:43:42 --> Input Class Initialized
INFO - 2020-02-09 07:43:42 --> Language Class Initialized
INFO - 2020-02-09 07:43:42 --> Language Class Initialized
INFO - 2020-02-09 07:43:42 --> Config Class Initialized
INFO - 2020-02-09 07:43:42 --> Loader Class Initialized
INFO - 2020-02-09 07:43:43 --> Helper loaded: url_helper
INFO - 2020-02-09 07:43:43 --> Helper loaded: file_helper
INFO - 2020-02-09 07:43:43 --> Helper loaded: form_helper
INFO - 2020-02-09 07:43:43 --> Helper loaded: my_helper
INFO - 2020-02-09 07:43:43 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:43:43 --> Controller Class Initialized
INFO - 2020-02-09 07:43:43 --> Final output sent to browser
DEBUG - 2020-02-09 07:43:43 --> Total execution time: 0.5713
INFO - 2020-02-09 07:43:46 --> Config Class Initialized
INFO - 2020-02-09 07:43:46 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:43:46 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:43:46 --> Utf8 Class Initialized
INFO - 2020-02-09 07:43:46 --> URI Class Initialized
INFO - 2020-02-09 07:43:46 --> Router Class Initialized
INFO - 2020-02-09 07:43:46 --> Output Class Initialized
INFO - 2020-02-09 07:43:46 --> Security Class Initialized
DEBUG - 2020-02-09 07:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:43:46 --> Input Class Initialized
INFO - 2020-02-09 07:43:46 --> Language Class Initialized
INFO - 2020-02-09 07:43:46 --> Language Class Initialized
INFO - 2020-02-09 07:43:46 --> Config Class Initialized
INFO - 2020-02-09 07:43:46 --> Loader Class Initialized
INFO - 2020-02-09 07:43:46 --> Helper loaded: url_helper
INFO - 2020-02-09 07:43:46 --> Helper loaded: file_helper
INFO - 2020-02-09 07:43:46 --> Helper loaded: form_helper
INFO - 2020-02-09 07:43:46 --> Helper loaded: my_helper
INFO - 2020-02-09 07:43:47 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:43:47 --> Controller Class Initialized
INFO - 2020-02-09 07:43:47 --> Final output sent to browser
DEBUG - 2020-02-09 07:43:47 --> Total execution time: 0.6779
INFO - 2020-02-09 07:43:47 --> Config Class Initialized
INFO - 2020-02-09 07:43:47 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:43:47 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:43:47 --> Utf8 Class Initialized
INFO - 2020-02-09 07:43:47 --> URI Class Initialized
INFO - 2020-02-09 07:43:47 --> Router Class Initialized
INFO - 2020-02-09 07:43:47 --> Output Class Initialized
INFO - 2020-02-09 07:43:47 --> Security Class Initialized
DEBUG - 2020-02-09 07:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:43:47 --> Input Class Initialized
INFO - 2020-02-09 07:43:47 --> Language Class Initialized
INFO - 2020-02-09 07:43:47 --> Language Class Initialized
INFO - 2020-02-09 07:43:47 --> Config Class Initialized
INFO - 2020-02-09 07:43:47 --> Loader Class Initialized
INFO - 2020-02-09 07:43:47 --> Helper loaded: url_helper
INFO - 2020-02-09 07:43:47 --> Helper loaded: file_helper
INFO - 2020-02-09 07:43:47 --> Helper loaded: form_helper
INFO - 2020-02-09 07:43:47 --> Helper loaded: my_helper
INFO - 2020-02-09 07:43:47 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:43:48 --> Controller Class Initialized
INFO - 2020-02-09 07:43:48 --> Final output sent to browser
DEBUG - 2020-02-09 07:43:48 --> Total execution time: 0.9542
INFO - 2020-02-09 07:43:54 --> Config Class Initialized
INFO - 2020-02-09 07:43:55 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:43:55 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:43:55 --> Utf8 Class Initialized
INFO - 2020-02-09 07:43:55 --> URI Class Initialized
INFO - 2020-02-09 07:43:55 --> Router Class Initialized
INFO - 2020-02-09 07:43:55 --> Output Class Initialized
INFO - 2020-02-09 07:43:55 --> Security Class Initialized
DEBUG - 2020-02-09 07:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:43:55 --> Input Class Initialized
INFO - 2020-02-09 07:43:55 --> Language Class Initialized
INFO - 2020-02-09 07:43:55 --> Language Class Initialized
INFO - 2020-02-09 07:43:55 --> Config Class Initialized
INFO - 2020-02-09 07:43:55 --> Loader Class Initialized
INFO - 2020-02-09 07:43:55 --> Helper loaded: url_helper
INFO - 2020-02-09 07:43:55 --> Helper loaded: file_helper
INFO - 2020-02-09 07:43:55 --> Helper loaded: form_helper
INFO - 2020-02-09 07:43:55 --> Helper loaded: my_helper
INFO - 2020-02-09 07:43:55 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:43:55 --> Controller Class Initialized
DEBUG - 2020-02-09 07:43:55 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-02-09 07:43:55 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:43:55 --> Final output sent to browser
DEBUG - 2020-02-09 07:43:55 --> Total execution time: 0.8817
INFO - 2020-02-09 07:43:57 --> Config Class Initialized
INFO - 2020-02-09 07:43:57 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:43:57 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:43:57 --> Utf8 Class Initialized
INFO - 2020-02-09 07:43:57 --> URI Class Initialized
INFO - 2020-02-09 07:43:57 --> Router Class Initialized
INFO - 2020-02-09 07:43:57 --> Output Class Initialized
INFO - 2020-02-09 07:43:57 --> Security Class Initialized
DEBUG - 2020-02-09 07:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:43:57 --> Input Class Initialized
INFO - 2020-02-09 07:43:57 --> Language Class Initialized
INFO - 2020-02-09 07:43:57 --> Language Class Initialized
INFO - 2020-02-09 07:43:57 --> Config Class Initialized
INFO - 2020-02-09 07:43:57 --> Loader Class Initialized
INFO - 2020-02-09 07:43:57 --> Helper loaded: url_helper
INFO - 2020-02-09 07:43:57 --> Helper loaded: file_helper
INFO - 2020-02-09 07:43:57 --> Helper loaded: form_helper
INFO - 2020-02-09 07:43:57 --> Helper loaded: my_helper
INFO - 2020-02-09 07:43:57 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:43:57 --> Controller Class Initialized
DEBUG - 2020-02-09 07:43:57 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-02-09 07:43:57 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:43:57 --> Final output sent to browser
DEBUG - 2020-02-09 07:43:57 --> Total execution time: 0.7999
INFO - 2020-02-09 07:43:58 --> Config Class Initialized
INFO - 2020-02-09 07:43:58 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:43:58 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:43:58 --> Utf8 Class Initialized
INFO - 2020-02-09 07:43:58 --> URI Class Initialized
INFO - 2020-02-09 07:43:58 --> Router Class Initialized
INFO - 2020-02-09 07:43:58 --> Output Class Initialized
INFO - 2020-02-09 07:43:58 --> Security Class Initialized
DEBUG - 2020-02-09 07:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:43:58 --> Input Class Initialized
INFO - 2020-02-09 07:43:58 --> Language Class Initialized
INFO - 2020-02-09 07:43:58 --> Language Class Initialized
INFO - 2020-02-09 07:43:58 --> Config Class Initialized
INFO - 2020-02-09 07:43:58 --> Loader Class Initialized
INFO - 2020-02-09 07:43:58 --> Helper loaded: url_helper
INFO - 2020-02-09 07:43:58 --> Helper loaded: file_helper
INFO - 2020-02-09 07:43:58 --> Helper loaded: form_helper
INFO - 2020-02-09 07:43:58 --> Helper loaded: my_helper
INFO - 2020-02-09 07:43:59 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:43:59 --> Controller Class Initialized
INFO - 2020-02-09 07:44:04 --> Config Class Initialized
INFO - 2020-02-09 07:44:04 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:44:04 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:44:05 --> Utf8 Class Initialized
INFO - 2020-02-09 07:44:05 --> URI Class Initialized
INFO - 2020-02-09 07:44:05 --> Router Class Initialized
INFO - 2020-02-09 07:44:05 --> Output Class Initialized
INFO - 2020-02-09 07:44:05 --> Security Class Initialized
DEBUG - 2020-02-09 07:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:44:05 --> Input Class Initialized
INFO - 2020-02-09 07:44:05 --> Language Class Initialized
INFO - 2020-02-09 07:44:05 --> Language Class Initialized
INFO - 2020-02-09 07:44:05 --> Config Class Initialized
INFO - 2020-02-09 07:44:05 --> Loader Class Initialized
INFO - 2020-02-09 07:44:05 --> Helper loaded: url_helper
INFO - 2020-02-09 07:44:05 --> Helper loaded: file_helper
INFO - 2020-02-09 07:44:05 --> Helper loaded: form_helper
INFO - 2020-02-09 07:44:05 --> Helper loaded: my_helper
INFO - 2020-02-09 07:44:05 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:44:05 --> Controller Class Initialized
DEBUG - 2020-02-09 07:44:05 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-02-09 07:44:06 --> Final output sent to browser
DEBUG - 2020-02-09 07:44:06 --> Total execution time: 1.2013
INFO - 2020-02-09 07:44:57 --> Config Class Initialized
INFO - 2020-02-09 07:44:57 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:44:57 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:44:57 --> Utf8 Class Initialized
INFO - 2020-02-09 07:44:58 --> URI Class Initialized
INFO - 2020-02-09 07:44:58 --> Router Class Initialized
INFO - 2020-02-09 07:44:58 --> Output Class Initialized
INFO - 2020-02-09 07:44:58 --> Security Class Initialized
DEBUG - 2020-02-09 07:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:44:58 --> Input Class Initialized
INFO - 2020-02-09 07:44:58 --> Language Class Initialized
INFO - 2020-02-09 07:44:58 --> Language Class Initialized
INFO - 2020-02-09 07:44:58 --> Config Class Initialized
INFO - 2020-02-09 07:44:58 --> Loader Class Initialized
INFO - 2020-02-09 07:44:58 --> Helper loaded: url_helper
INFO - 2020-02-09 07:44:58 --> Helper loaded: file_helper
INFO - 2020-02-09 07:44:58 --> Helper loaded: form_helper
INFO - 2020-02-09 07:44:58 --> Helper loaded: my_helper
INFO - 2020-02-09 07:44:58 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:44:58 --> Controller Class Initialized
DEBUG - 2020-02-09 07:44:58 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-02-09 07:44:58 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:44:58 --> Final output sent to browser
DEBUG - 2020-02-09 07:44:58 --> Total execution time: 0.9337
INFO - 2020-02-09 07:45:00 --> Config Class Initialized
INFO - 2020-02-09 07:45:00 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:45:00 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:45:01 --> Utf8 Class Initialized
INFO - 2020-02-09 07:45:01 --> URI Class Initialized
INFO - 2020-02-09 07:45:01 --> Router Class Initialized
INFO - 2020-02-09 07:45:01 --> Output Class Initialized
INFO - 2020-02-09 07:45:01 --> Security Class Initialized
DEBUG - 2020-02-09 07:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:45:01 --> Input Class Initialized
INFO - 2020-02-09 07:45:01 --> Language Class Initialized
INFO - 2020-02-09 07:45:01 --> Language Class Initialized
INFO - 2020-02-09 07:45:01 --> Config Class Initialized
INFO - 2020-02-09 07:45:01 --> Loader Class Initialized
INFO - 2020-02-09 07:45:01 --> Helper loaded: url_helper
INFO - 2020-02-09 07:45:01 --> Helper loaded: file_helper
INFO - 2020-02-09 07:45:01 --> Helper loaded: form_helper
INFO - 2020-02-09 07:45:01 --> Helper loaded: my_helper
INFO - 2020-02-09 07:45:01 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:45:01 --> Controller Class Initialized
DEBUG - 2020-02-09 07:45:02 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-02-09 07:45:02 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:45:02 --> Final output sent to browser
DEBUG - 2020-02-09 07:45:02 --> Total execution time: 1.2229
INFO - 2020-02-09 07:45:07 --> Config Class Initialized
INFO - 2020-02-09 07:45:07 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:45:07 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:45:07 --> Utf8 Class Initialized
INFO - 2020-02-09 07:45:07 --> URI Class Initialized
INFO - 2020-02-09 07:45:07 --> Router Class Initialized
INFO - 2020-02-09 07:45:07 --> Output Class Initialized
INFO - 2020-02-09 07:45:07 --> Security Class Initialized
DEBUG - 2020-02-09 07:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:45:07 --> Input Class Initialized
INFO - 2020-02-09 07:45:07 --> Language Class Initialized
INFO - 2020-02-09 07:45:07 --> Language Class Initialized
INFO - 2020-02-09 07:45:07 --> Config Class Initialized
INFO - 2020-02-09 07:45:07 --> Loader Class Initialized
INFO - 2020-02-09 07:45:07 --> Helper loaded: url_helper
INFO - 2020-02-09 07:45:07 --> Helper loaded: file_helper
INFO - 2020-02-09 07:45:07 --> Helper loaded: form_helper
INFO - 2020-02-09 07:45:07 --> Helper loaded: my_helper
INFO - 2020-02-09 07:45:08 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:45:08 --> Controller Class Initialized
INFO - 2020-02-09 07:45:08 --> Final output sent to browser
DEBUG - 2020-02-09 07:45:08 --> Total execution time: 0.9550
INFO - 2020-02-09 07:45:19 --> Config Class Initialized
INFO - 2020-02-09 07:45:19 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:45:19 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:45:19 --> Utf8 Class Initialized
INFO - 2020-02-09 07:45:19 --> URI Class Initialized
INFO - 2020-02-09 07:45:19 --> Router Class Initialized
INFO - 2020-02-09 07:45:19 --> Output Class Initialized
INFO - 2020-02-09 07:45:19 --> Security Class Initialized
DEBUG - 2020-02-09 07:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:45:19 --> Input Class Initialized
INFO - 2020-02-09 07:45:19 --> Language Class Initialized
INFO - 2020-02-09 07:45:19 --> Language Class Initialized
INFO - 2020-02-09 07:45:19 --> Config Class Initialized
INFO - 2020-02-09 07:45:19 --> Loader Class Initialized
INFO - 2020-02-09 07:45:19 --> Helper loaded: url_helper
INFO - 2020-02-09 07:45:19 --> Helper loaded: file_helper
INFO - 2020-02-09 07:45:19 --> Helper loaded: form_helper
INFO - 2020-02-09 07:45:19 --> Helper loaded: my_helper
INFO - 2020-02-09 07:45:20 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:45:20 --> Controller Class Initialized
INFO - 2020-02-09 07:45:20 --> Final output sent to browser
DEBUG - 2020-02-09 07:45:20 --> Total execution time: 0.9725
INFO - 2020-02-09 07:45:20 --> Config Class Initialized
INFO - 2020-02-09 07:45:20 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:45:20 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:45:20 --> Utf8 Class Initialized
INFO - 2020-02-09 07:45:20 --> URI Class Initialized
INFO - 2020-02-09 07:45:20 --> Router Class Initialized
INFO - 2020-02-09 07:45:20 --> Output Class Initialized
INFO - 2020-02-09 07:45:20 --> Security Class Initialized
DEBUG - 2020-02-09 07:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:45:21 --> Input Class Initialized
INFO - 2020-02-09 07:45:21 --> Language Class Initialized
INFO - 2020-02-09 07:45:21 --> Language Class Initialized
INFO - 2020-02-09 07:45:21 --> Config Class Initialized
INFO - 2020-02-09 07:45:21 --> Loader Class Initialized
INFO - 2020-02-09 07:45:21 --> Helper loaded: url_helper
INFO - 2020-02-09 07:45:21 --> Helper loaded: file_helper
INFO - 2020-02-09 07:45:21 --> Helper loaded: form_helper
INFO - 2020-02-09 07:45:21 --> Helper loaded: my_helper
INFO - 2020-02-09 07:45:21 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:45:21 --> Controller Class Initialized
DEBUG - 2020-02-09 07:45:21 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-02-09 07:45:21 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:45:21 --> Final output sent to browser
DEBUG - 2020-02-09 07:45:21 --> Total execution time: 1.3782
INFO - 2020-02-09 07:45:22 --> Config Class Initialized
INFO - 2020-02-09 07:45:22 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:45:22 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:45:22 --> Utf8 Class Initialized
INFO - 2020-02-09 07:45:23 --> URI Class Initialized
INFO - 2020-02-09 07:45:23 --> Router Class Initialized
INFO - 2020-02-09 07:45:23 --> Output Class Initialized
INFO - 2020-02-09 07:45:23 --> Security Class Initialized
DEBUG - 2020-02-09 07:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:45:23 --> Input Class Initialized
INFO - 2020-02-09 07:45:23 --> Language Class Initialized
INFO - 2020-02-09 07:45:23 --> Language Class Initialized
INFO - 2020-02-09 07:45:23 --> Config Class Initialized
INFO - 2020-02-09 07:45:23 --> Loader Class Initialized
INFO - 2020-02-09 07:45:23 --> Helper loaded: url_helper
INFO - 2020-02-09 07:45:23 --> Helper loaded: file_helper
INFO - 2020-02-09 07:45:23 --> Helper loaded: form_helper
INFO - 2020-02-09 07:45:23 --> Helper loaded: my_helper
INFO - 2020-02-09 07:45:23 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:45:23 --> Controller Class Initialized
INFO - 2020-02-09 07:45:24 --> Final output sent to browser
DEBUG - 2020-02-09 07:45:24 --> Total execution time: 1.2423
INFO - 2020-02-09 07:45:32 --> Config Class Initialized
INFO - 2020-02-09 07:45:32 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:45:32 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:45:32 --> Utf8 Class Initialized
INFO - 2020-02-09 07:45:32 --> URI Class Initialized
INFO - 2020-02-09 07:45:32 --> Router Class Initialized
INFO - 2020-02-09 07:45:32 --> Output Class Initialized
INFO - 2020-02-09 07:45:32 --> Security Class Initialized
DEBUG - 2020-02-09 07:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:45:32 --> Input Class Initialized
INFO - 2020-02-09 07:45:32 --> Language Class Initialized
INFO - 2020-02-09 07:45:32 --> Language Class Initialized
INFO - 2020-02-09 07:45:32 --> Config Class Initialized
INFO - 2020-02-09 07:45:32 --> Loader Class Initialized
INFO - 2020-02-09 07:45:32 --> Helper loaded: url_helper
INFO - 2020-02-09 07:45:32 --> Helper loaded: file_helper
INFO - 2020-02-09 07:45:32 --> Helper loaded: form_helper
INFO - 2020-02-09 07:45:32 --> Helper loaded: my_helper
INFO - 2020-02-09 07:45:32 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:45:33 --> Controller Class Initialized
INFO - 2020-02-09 07:45:33 --> Final output sent to browser
DEBUG - 2020-02-09 07:45:33 --> Total execution time: 0.8432
INFO - 2020-02-09 07:45:33 --> Config Class Initialized
INFO - 2020-02-09 07:45:33 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:45:33 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:45:33 --> Utf8 Class Initialized
INFO - 2020-02-09 07:45:33 --> URI Class Initialized
INFO - 2020-02-09 07:45:33 --> Router Class Initialized
INFO - 2020-02-09 07:45:33 --> Output Class Initialized
INFO - 2020-02-09 07:45:33 --> Security Class Initialized
DEBUG - 2020-02-09 07:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:45:33 --> Input Class Initialized
INFO - 2020-02-09 07:45:34 --> Language Class Initialized
INFO - 2020-02-09 07:45:34 --> Language Class Initialized
INFO - 2020-02-09 07:45:34 --> Config Class Initialized
INFO - 2020-02-09 07:45:34 --> Loader Class Initialized
INFO - 2020-02-09 07:45:34 --> Helper loaded: url_helper
INFO - 2020-02-09 07:45:34 --> Helper loaded: file_helper
INFO - 2020-02-09 07:45:34 --> Helper loaded: form_helper
INFO - 2020-02-09 07:45:34 --> Helper loaded: my_helper
INFO - 2020-02-09 07:45:34 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:45:34 --> Controller Class Initialized
DEBUG - 2020-02-09 07:45:34 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-02-09 07:45:34 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:45:34 --> Final output sent to browser
DEBUG - 2020-02-09 07:45:34 --> Total execution time: 1.5939
INFO - 2020-02-09 07:45:37 --> Config Class Initialized
INFO - 2020-02-09 07:45:37 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:45:37 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:45:37 --> Utf8 Class Initialized
INFO - 2020-02-09 07:45:37 --> URI Class Initialized
INFO - 2020-02-09 07:45:38 --> Router Class Initialized
INFO - 2020-02-09 07:45:38 --> Output Class Initialized
INFO - 2020-02-09 07:45:38 --> Security Class Initialized
DEBUG - 2020-02-09 07:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:45:38 --> Input Class Initialized
INFO - 2020-02-09 07:45:38 --> Language Class Initialized
INFO - 2020-02-09 07:45:38 --> Language Class Initialized
INFO - 2020-02-09 07:45:38 --> Config Class Initialized
INFO - 2020-02-09 07:45:38 --> Loader Class Initialized
INFO - 2020-02-09 07:45:38 --> Helper loaded: url_helper
INFO - 2020-02-09 07:45:38 --> Helper loaded: file_helper
INFO - 2020-02-09 07:45:38 --> Helper loaded: form_helper
INFO - 2020-02-09 07:45:38 --> Helper loaded: my_helper
INFO - 2020-02-09 07:45:38 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:45:38 --> Controller Class Initialized
INFO - 2020-02-09 07:45:38 --> Final output sent to browser
DEBUG - 2020-02-09 07:45:38 --> Total execution time: 0.5929
INFO - 2020-02-09 07:45:45 --> Config Class Initialized
INFO - 2020-02-09 07:45:45 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:45:45 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:45:45 --> Utf8 Class Initialized
INFO - 2020-02-09 07:45:45 --> URI Class Initialized
INFO - 2020-02-09 07:45:45 --> Router Class Initialized
INFO - 2020-02-09 07:45:46 --> Output Class Initialized
INFO - 2020-02-09 07:45:46 --> Security Class Initialized
DEBUG - 2020-02-09 07:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:45:46 --> Input Class Initialized
INFO - 2020-02-09 07:45:46 --> Language Class Initialized
INFO - 2020-02-09 07:45:46 --> Language Class Initialized
INFO - 2020-02-09 07:45:46 --> Config Class Initialized
INFO - 2020-02-09 07:45:46 --> Loader Class Initialized
INFO - 2020-02-09 07:45:46 --> Helper loaded: url_helper
INFO - 2020-02-09 07:45:46 --> Helper loaded: file_helper
INFO - 2020-02-09 07:45:46 --> Helper loaded: form_helper
INFO - 2020-02-09 07:45:46 --> Helper loaded: my_helper
INFO - 2020-02-09 07:45:46 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:45:46 --> Controller Class Initialized
INFO - 2020-02-09 07:46:09 --> Config Class Initialized
INFO - 2020-02-09 07:46:09 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:46:09 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:46:09 --> Utf8 Class Initialized
INFO - 2020-02-09 07:46:09 --> URI Class Initialized
INFO - 2020-02-09 07:46:09 --> Router Class Initialized
INFO - 2020-02-09 07:46:09 --> Output Class Initialized
INFO - 2020-02-09 07:46:09 --> Security Class Initialized
DEBUG - 2020-02-09 07:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:46:09 --> Input Class Initialized
INFO - 2020-02-09 07:46:09 --> Language Class Initialized
INFO - 2020-02-09 07:46:09 --> Language Class Initialized
INFO - 2020-02-09 07:46:10 --> Config Class Initialized
INFO - 2020-02-09 07:46:10 --> Loader Class Initialized
INFO - 2020-02-09 07:46:10 --> Helper loaded: url_helper
INFO - 2020-02-09 07:46:10 --> Helper loaded: file_helper
INFO - 2020-02-09 07:46:10 --> Helper loaded: form_helper
INFO - 2020-02-09 07:46:10 --> Helper loaded: my_helper
INFO - 2020-02-09 07:46:10 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:46:10 --> Controller Class Initialized
DEBUG - 2020-02-09 07:46:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_keterampilan/views/form.php
DEBUG - 2020-02-09 07:46:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:46:10 --> Final output sent to browser
DEBUG - 2020-02-09 07:46:10 --> Total execution time: 0.9271
INFO - 2020-02-09 07:46:26 --> Config Class Initialized
INFO - 2020-02-09 07:46:26 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:46:26 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:46:26 --> Utf8 Class Initialized
INFO - 2020-02-09 07:46:26 --> URI Class Initialized
INFO - 2020-02-09 07:46:26 --> Router Class Initialized
INFO - 2020-02-09 07:46:26 --> Output Class Initialized
INFO - 2020-02-09 07:46:26 --> Security Class Initialized
DEBUG - 2020-02-09 07:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:46:26 --> Input Class Initialized
INFO - 2020-02-09 07:46:26 --> Language Class Initialized
INFO - 2020-02-09 07:46:26 --> Language Class Initialized
INFO - 2020-02-09 07:46:26 --> Config Class Initialized
INFO - 2020-02-09 07:46:26 --> Loader Class Initialized
INFO - 2020-02-09 07:46:26 --> Helper loaded: url_helper
INFO - 2020-02-09 07:46:26 --> Helper loaded: file_helper
INFO - 2020-02-09 07:46:27 --> Helper loaded: form_helper
INFO - 2020-02-09 07:46:27 --> Helper loaded: my_helper
INFO - 2020-02-09 07:46:27 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:46:27 --> Controller Class Initialized
INFO - 2020-02-09 07:46:27 --> Config Class Initialized
INFO - 2020-02-09 07:46:27 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:46:27 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:46:27 --> Utf8 Class Initialized
INFO - 2020-02-09 07:46:27 --> URI Class Initialized
INFO - 2020-02-09 07:46:27 --> Router Class Initialized
INFO - 2020-02-09 07:46:27 --> Output Class Initialized
INFO - 2020-02-09 07:46:27 --> Security Class Initialized
DEBUG - 2020-02-09 07:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:46:27 --> Input Class Initialized
INFO - 2020-02-09 07:46:27 --> Language Class Initialized
INFO - 2020-02-09 07:46:27 --> Language Class Initialized
INFO - 2020-02-09 07:46:27 --> Config Class Initialized
INFO - 2020-02-09 07:46:27 --> Loader Class Initialized
INFO - 2020-02-09 07:46:27 --> Helper loaded: url_helper
INFO - 2020-02-09 07:46:27 --> Helper loaded: file_helper
INFO - 2020-02-09 07:46:27 --> Helper loaded: form_helper
INFO - 2020-02-09 07:46:27 --> Helper loaded: my_helper
INFO - 2020-02-09 07:46:27 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:46:28 --> Controller Class Initialized
DEBUG - 2020-02-09 07:46:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-02-09 07:46:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:46:28 --> Final output sent to browser
DEBUG - 2020-02-09 07:46:28 --> Total execution time: 0.7942
INFO - 2020-02-09 07:46:32 --> Config Class Initialized
INFO - 2020-02-09 07:46:32 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:46:32 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:46:32 --> Utf8 Class Initialized
INFO - 2020-02-09 07:46:32 --> URI Class Initialized
INFO - 2020-02-09 07:46:32 --> Router Class Initialized
INFO - 2020-02-09 07:46:32 --> Output Class Initialized
INFO - 2020-02-09 07:46:32 --> Security Class Initialized
DEBUG - 2020-02-09 07:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:46:33 --> Input Class Initialized
INFO - 2020-02-09 07:46:33 --> Language Class Initialized
INFO - 2020-02-09 07:46:33 --> Language Class Initialized
INFO - 2020-02-09 07:46:33 --> Config Class Initialized
INFO - 2020-02-09 07:46:33 --> Loader Class Initialized
INFO - 2020-02-09 07:46:33 --> Helper loaded: url_helper
INFO - 2020-02-09 07:46:33 --> Helper loaded: file_helper
INFO - 2020-02-09 07:46:33 --> Helper loaded: form_helper
INFO - 2020-02-09 07:46:33 --> Helper loaded: my_helper
INFO - 2020-02-09 07:46:33 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:46:33 --> Controller Class Initialized
INFO - 2020-02-09 07:46:33 --> Final output sent to browser
DEBUG - 2020-02-09 07:46:33 --> Total execution time: 0.5739
INFO - 2020-02-09 07:46:38 --> Config Class Initialized
INFO - 2020-02-09 07:46:38 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:46:38 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:46:38 --> Utf8 Class Initialized
INFO - 2020-02-09 07:46:38 --> URI Class Initialized
INFO - 2020-02-09 07:46:38 --> Router Class Initialized
INFO - 2020-02-09 07:46:38 --> Output Class Initialized
INFO - 2020-02-09 07:46:38 --> Security Class Initialized
DEBUG - 2020-02-09 07:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:46:38 --> Input Class Initialized
INFO - 2020-02-09 07:46:38 --> Language Class Initialized
INFO - 2020-02-09 07:46:38 --> Language Class Initialized
INFO - 2020-02-09 07:46:38 --> Config Class Initialized
INFO - 2020-02-09 07:46:38 --> Loader Class Initialized
INFO - 2020-02-09 07:46:38 --> Helper loaded: url_helper
INFO - 2020-02-09 07:46:38 --> Helper loaded: file_helper
INFO - 2020-02-09 07:46:38 --> Helper loaded: form_helper
INFO - 2020-02-09 07:46:38 --> Helper loaded: my_helper
INFO - 2020-02-09 07:46:38 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:46:39 --> Controller Class Initialized
INFO - 2020-02-09 07:46:39 --> Final output sent to browser
DEBUG - 2020-02-09 07:46:39 --> Total execution time: 0.7940
INFO - 2020-02-09 07:46:43 --> Config Class Initialized
INFO - 2020-02-09 07:46:43 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:46:43 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:46:43 --> Utf8 Class Initialized
INFO - 2020-02-09 07:46:43 --> URI Class Initialized
INFO - 2020-02-09 07:46:43 --> Router Class Initialized
INFO - 2020-02-09 07:46:43 --> Output Class Initialized
INFO - 2020-02-09 07:46:43 --> Security Class Initialized
DEBUG - 2020-02-09 07:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:46:44 --> Input Class Initialized
INFO - 2020-02-09 07:46:44 --> Language Class Initialized
INFO - 2020-02-09 07:46:44 --> Language Class Initialized
INFO - 2020-02-09 07:46:44 --> Config Class Initialized
INFO - 2020-02-09 07:46:44 --> Loader Class Initialized
INFO - 2020-02-09 07:46:44 --> Helper loaded: url_helper
INFO - 2020-02-09 07:46:44 --> Helper loaded: file_helper
INFO - 2020-02-09 07:46:44 --> Helper loaded: form_helper
INFO - 2020-02-09 07:46:44 --> Helper loaded: my_helper
INFO - 2020-02-09 07:46:44 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:46:44 --> Controller Class Initialized
DEBUG - 2020-02-09 07:46:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-02-09 07:46:44 --> Final output sent to browser
DEBUG - 2020-02-09 07:46:44 --> Total execution time: 1.2678
INFO - 2020-02-09 07:47:13 --> Config Class Initialized
INFO - 2020-02-09 07:47:13 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:47:13 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:47:13 --> Utf8 Class Initialized
INFO - 2020-02-09 07:47:13 --> URI Class Initialized
INFO - 2020-02-09 07:47:13 --> Router Class Initialized
INFO - 2020-02-09 07:47:13 --> Output Class Initialized
INFO - 2020-02-09 07:47:13 --> Security Class Initialized
DEBUG - 2020-02-09 07:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:47:13 --> Input Class Initialized
INFO - 2020-02-09 07:47:13 --> Language Class Initialized
INFO - 2020-02-09 07:47:13 --> Language Class Initialized
INFO - 2020-02-09 07:47:13 --> Config Class Initialized
INFO - 2020-02-09 07:47:13 --> Loader Class Initialized
INFO - 2020-02-09 07:47:13 --> Helper loaded: url_helper
INFO - 2020-02-09 07:47:13 --> Helper loaded: file_helper
INFO - 2020-02-09 07:47:13 --> Helper loaded: form_helper
INFO - 2020-02-09 07:47:13 --> Helper loaded: my_helper
INFO - 2020-02-09 07:47:13 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:47:13 --> Controller Class Initialized
DEBUG - 2020-02-09 07:47:14 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-02-09 07:47:14 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:47:14 --> Final output sent to browser
DEBUG - 2020-02-09 07:47:14 --> Total execution time: 1.1617
INFO - 2020-02-09 07:47:42 --> Config Class Initialized
INFO - 2020-02-09 07:47:42 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:47:42 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:47:42 --> Utf8 Class Initialized
INFO - 2020-02-09 07:47:42 --> URI Class Initialized
INFO - 2020-02-09 07:47:42 --> Router Class Initialized
INFO - 2020-02-09 07:47:42 --> Output Class Initialized
INFO - 2020-02-09 07:47:42 --> Security Class Initialized
DEBUG - 2020-02-09 07:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:47:43 --> Input Class Initialized
INFO - 2020-02-09 07:47:43 --> Language Class Initialized
INFO - 2020-02-09 07:47:43 --> Language Class Initialized
INFO - 2020-02-09 07:47:43 --> Config Class Initialized
INFO - 2020-02-09 07:47:43 --> Loader Class Initialized
INFO - 2020-02-09 07:47:43 --> Helper loaded: url_helper
INFO - 2020-02-09 07:47:43 --> Helper loaded: file_helper
INFO - 2020-02-09 07:47:43 --> Helper loaded: form_helper
INFO - 2020-02-09 07:47:43 --> Helper loaded: my_helper
INFO - 2020-02-09 07:47:43 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:47:43 --> Controller Class Initialized
INFO - 2020-02-09 07:47:43 --> Final output sent to browser
DEBUG - 2020-02-09 07:47:43 --> Total execution time: 1.0572
INFO - 2020-02-09 07:47:48 --> Config Class Initialized
INFO - 2020-02-09 07:47:48 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:47:48 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:47:48 --> Utf8 Class Initialized
INFO - 2020-02-09 07:47:48 --> URI Class Initialized
INFO - 2020-02-09 07:47:49 --> Router Class Initialized
INFO - 2020-02-09 07:47:49 --> Output Class Initialized
INFO - 2020-02-09 07:47:49 --> Security Class Initialized
DEBUG - 2020-02-09 07:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:47:49 --> Input Class Initialized
INFO - 2020-02-09 07:47:49 --> Language Class Initialized
INFO - 2020-02-09 07:47:49 --> Language Class Initialized
INFO - 2020-02-09 07:47:49 --> Config Class Initialized
INFO - 2020-02-09 07:47:49 --> Loader Class Initialized
INFO - 2020-02-09 07:47:49 --> Helper loaded: url_helper
INFO - 2020-02-09 07:47:49 --> Helper loaded: file_helper
INFO - 2020-02-09 07:47:49 --> Helper loaded: form_helper
INFO - 2020-02-09 07:47:49 --> Helper loaded: my_helper
INFO - 2020-02-09 07:47:49 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:47:49 --> Controller Class Initialized
DEBUG - 2020-02-09 07:47:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_sikap_sp/views/cetak.php
INFO - 2020-02-09 07:47:50 --> Final output sent to browser
DEBUG - 2020-02-09 07:47:50 --> Total execution time: 1.3810
INFO - 2020-02-09 07:48:23 --> Config Class Initialized
INFO - 2020-02-09 07:48:23 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:48:23 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:48:23 --> Utf8 Class Initialized
INFO - 2020-02-09 07:48:23 --> URI Class Initialized
INFO - 2020-02-09 07:48:23 --> Router Class Initialized
INFO - 2020-02-09 07:48:23 --> Output Class Initialized
INFO - 2020-02-09 07:48:23 --> Security Class Initialized
DEBUG - 2020-02-09 07:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:48:23 --> Input Class Initialized
INFO - 2020-02-09 07:48:23 --> Language Class Initialized
INFO - 2020-02-09 07:48:23 --> Language Class Initialized
INFO - 2020-02-09 07:48:23 --> Config Class Initialized
INFO - 2020-02-09 07:48:23 --> Loader Class Initialized
INFO - 2020-02-09 07:48:23 --> Helper loaded: url_helper
INFO - 2020-02-09 07:48:23 --> Helper loaded: file_helper
INFO - 2020-02-09 07:48:23 --> Helper loaded: form_helper
INFO - 2020-02-09 07:48:23 --> Helper loaded: my_helper
INFO - 2020-02-09 07:48:23 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:48:24 --> Controller Class Initialized
DEBUG - 2020-02-09 07:48:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-02-09 07:48:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:48:24 --> Final output sent to browser
DEBUG - 2020-02-09 07:48:24 --> Total execution time: 0.9244
INFO - 2020-02-09 07:48:42 --> Config Class Initialized
INFO - 2020-02-09 07:48:42 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:48:42 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:48:42 --> Utf8 Class Initialized
INFO - 2020-02-09 07:48:42 --> URI Class Initialized
INFO - 2020-02-09 07:48:42 --> Router Class Initialized
INFO - 2020-02-09 07:48:42 --> Output Class Initialized
INFO - 2020-02-09 07:48:42 --> Security Class Initialized
DEBUG - 2020-02-09 07:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:48:42 --> Input Class Initialized
INFO - 2020-02-09 07:48:42 --> Language Class Initialized
INFO - 2020-02-09 07:48:42 --> Language Class Initialized
INFO - 2020-02-09 07:48:42 --> Config Class Initialized
INFO - 2020-02-09 07:48:43 --> Loader Class Initialized
INFO - 2020-02-09 07:48:43 --> Helper loaded: url_helper
INFO - 2020-02-09 07:48:43 --> Helper loaded: file_helper
INFO - 2020-02-09 07:48:43 --> Helper loaded: form_helper
INFO - 2020-02-09 07:48:43 --> Helper loaded: my_helper
INFO - 2020-02-09 07:48:43 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:48:43 --> Controller Class Initialized
INFO - 2020-02-09 07:48:43 --> Final output sent to browser
DEBUG - 2020-02-09 07:48:43 --> Total execution time: 0.8027
INFO - 2020-02-09 07:48:46 --> Config Class Initialized
INFO - 2020-02-09 07:48:46 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:48:46 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:48:46 --> Utf8 Class Initialized
INFO - 2020-02-09 07:48:46 --> URI Class Initialized
INFO - 2020-02-09 07:48:46 --> Router Class Initialized
INFO - 2020-02-09 07:48:46 --> Output Class Initialized
INFO - 2020-02-09 07:48:47 --> Security Class Initialized
DEBUG - 2020-02-09 07:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:48:47 --> Input Class Initialized
INFO - 2020-02-09 07:48:47 --> Language Class Initialized
INFO - 2020-02-09 07:48:47 --> Language Class Initialized
INFO - 2020-02-09 07:48:47 --> Config Class Initialized
INFO - 2020-02-09 07:48:47 --> Loader Class Initialized
INFO - 2020-02-09 07:48:47 --> Helper loaded: url_helper
INFO - 2020-02-09 07:48:47 --> Helper loaded: file_helper
INFO - 2020-02-09 07:48:47 --> Helper loaded: form_helper
INFO - 2020-02-09 07:48:47 --> Helper loaded: my_helper
INFO - 2020-02-09 07:48:47 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:48:47 --> Controller Class Initialized
DEBUG - 2020-02-09 07:48:47 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_sikap_so/views/cetak.php
INFO - 2020-02-09 07:48:47 --> Final output sent to browser
DEBUG - 2020-02-09 07:48:47 --> Total execution time: 1.1488
INFO - 2020-02-09 07:49:04 --> Config Class Initialized
INFO - 2020-02-09 07:49:04 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:49:04 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:49:04 --> Utf8 Class Initialized
INFO - 2020-02-09 07:49:04 --> URI Class Initialized
INFO - 2020-02-09 07:49:04 --> Router Class Initialized
INFO - 2020-02-09 07:49:04 --> Output Class Initialized
INFO - 2020-02-09 07:49:04 --> Security Class Initialized
DEBUG - 2020-02-09 07:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:49:04 --> Input Class Initialized
INFO - 2020-02-09 07:49:04 --> Language Class Initialized
INFO - 2020-02-09 07:49:05 --> Language Class Initialized
INFO - 2020-02-09 07:49:05 --> Config Class Initialized
INFO - 2020-02-09 07:49:05 --> Loader Class Initialized
INFO - 2020-02-09 07:49:05 --> Helper loaded: url_helper
INFO - 2020-02-09 07:49:05 --> Helper loaded: file_helper
INFO - 2020-02-09 07:49:05 --> Helper loaded: form_helper
INFO - 2020-02-09 07:49:05 --> Helper loaded: my_helper
INFO - 2020-02-09 07:49:05 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:49:05 --> Controller Class Initialized
DEBUG - 2020-02-09 07:49:05 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_absensi/views/list.php
DEBUG - 2020-02-09 07:49:05 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:49:05 --> Final output sent to browser
DEBUG - 2020-02-09 07:49:05 --> Total execution time: 1.1734
INFO - 2020-02-09 07:49:23 --> Config Class Initialized
INFO - 2020-02-09 07:49:23 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:49:23 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:49:23 --> Utf8 Class Initialized
INFO - 2020-02-09 07:49:23 --> URI Class Initialized
INFO - 2020-02-09 07:49:23 --> Router Class Initialized
INFO - 2020-02-09 07:49:23 --> Output Class Initialized
INFO - 2020-02-09 07:49:23 --> Security Class Initialized
DEBUG - 2020-02-09 07:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:49:23 --> Input Class Initialized
INFO - 2020-02-09 07:49:23 --> Language Class Initialized
INFO - 2020-02-09 07:49:23 --> Language Class Initialized
INFO - 2020-02-09 07:49:23 --> Config Class Initialized
INFO - 2020-02-09 07:49:23 --> Loader Class Initialized
INFO - 2020-02-09 07:49:23 --> Helper loaded: url_helper
INFO - 2020-02-09 07:49:23 --> Helper loaded: file_helper
INFO - 2020-02-09 07:49:23 --> Helper loaded: form_helper
INFO - 2020-02-09 07:49:23 --> Helper loaded: my_helper
INFO - 2020-02-09 07:49:23 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:49:23 --> Controller Class Initialized
INFO - 2020-02-09 07:49:23 --> Final output sent to browser
DEBUG - 2020-02-09 07:49:23 --> Total execution time: 0.7769
INFO - 2020-02-09 07:49:26 --> Config Class Initialized
INFO - 2020-02-09 07:49:26 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:49:26 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:49:27 --> Utf8 Class Initialized
INFO - 2020-02-09 07:49:27 --> URI Class Initialized
INFO - 2020-02-09 07:49:27 --> Router Class Initialized
INFO - 2020-02-09 07:49:27 --> Output Class Initialized
INFO - 2020-02-09 07:49:27 --> Security Class Initialized
DEBUG - 2020-02-09 07:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:49:27 --> Input Class Initialized
INFO - 2020-02-09 07:49:27 --> Language Class Initialized
INFO - 2020-02-09 07:49:27 --> Language Class Initialized
INFO - 2020-02-09 07:49:27 --> Config Class Initialized
INFO - 2020-02-09 07:49:27 --> Loader Class Initialized
INFO - 2020-02-09 07:49:27 --> Helper loaded: url_helper
INFO - 2020-02-09 07:49:27 --> Helper loaded: file_helper
INFO - 2020-02-09 07:49:27 --> Helper loaded: form_helper
INFO - 2020-02-09 07:49:27 --> Helper loaded: my_helper
INFO - 2020-02-09 07:49:27 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:49:27 --> Controller Class Initialized
DEBUG - 2020-02-09 07:49:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_absensi/views/cetak.php
INFO - 2020-02-09 07:49:28 --> Final output sent to browser
DEBUG - 2020-02-09 07:49:28 --> Total execution time: 1.2503
INFO - 2020-02-09 07:49:48 --> Config Class Initialized
INFO - 2020-02-09 07:49:48 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:49:48 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:49:48 --> Utf8 Class Initialized
INFO - 2020-02-09 07:49:48 --> URI Class Initialized
INFO - 2020-02-09 07:49:48 --> Router Class Initialized
INFO - 2020-02-09 07:49:48 --> Output Class Initialized
INFO - 2020-02-09 07:49:48 --> Security Class Initialized
DEBUG - 2020-02-09 07:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:49:48 --> Input Class Initialized
INFO - 2020-02-09 07:49:48 --> Language Class Initialized
INFO - 2020-02-09 07:49:48 --> Language Class Initialized
INFO - 2020-02-09 07:49:48 --> Config Class Initialized
INFO - 2020-02-09 07:49:48 --> Loader Class Initialized
INFO - 2020-02-09 07:49:48 --> Helper loaded: url_helper
INFO - 2020-02-09 07:49:48 --> Helper loaded: file_helper
INFO - 2020-02-09 07:49:49 --> Helper loaded: form_helper
INFO - 2020-02-09 07:49:49 --> Helper loaded: my_helper
INFO - 2020-02-09 07:49:49 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:49:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:49:49 --> Controller Class Initialized
DEBUG - 2020-02-09 07:49:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_ekstra/views/list.php
DEBUG - 2020-02-09 07:49:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:49:49 --> Final output sent to browser
DEBUG - 2020-02-09 07:49:49 --> Total execution time: 0.9308
INFO - 2020-02-09 07:49:52 --> Config Class Initialized
INFO - 2020-02-09 07:49:53 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:49:53 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:49:53 --> Utf8 Class Initialized
INFO - 2020-02-09 07:49:53 --> URI Class Initialized
INFO - 2020-02-09 07:49:53 --> Router Class Initialized
INFO - 2020-02-09 07:49:53 --> Output Class Initialized
INFO - 2020-02-09 07:49:53 --> Security Class Initialized
DEBUG - 2020-02-09 07:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:49:53 --> Input Class Initialized
INFO - 2020-02-09 07:49:53 --> Language Class Initialized
INFO - 2020-02-09 07:49:53 --> Language Class Initialized
INFO - 2020-02-09 07:49:53 --> Config Class Initialized
INFO - 2020-02-09 07:49:53 --> Loader Class Initialized
INFO - 2020-02-09 07:49:53 --> Helper loaded: url_helper
INFO - 2020-02-09 07:49:53 --> Helper loaded: file_helper
INFO - 2020-02-09 07:49:53 --> Helper loaded: form_helper
INFO - 2020-02-09 07:49:53 --> Helper loaded: my_helper
INFO - 2020-02-09 07:49:53 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:49:53 --> Controller Class Initialized
INFO - 2020-02-09 07:49:53 --> Final output sent to browser
DEBUG - 2020-02-09 07:49:53 --> Total execution time: 0.7128
INFO - 2020-02-09 07:50:02 --> Config Class Initialized
INFO - 2020-02-09 07:50:02 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:50:02 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:50:02 --> Utf8 Class Initialized
INFO - 2020-02-09 07:50:02 --> URI Class Initialized
INFO - 2020-02-09 07:50:03 --> Router Class Initialized
INFO - 2020-02-09 07:50:03 --> Output Class Initialized
INFO - 2020-02-09 07:50:03 --> Security Class Initialized
DEBUG - 2020-02-09 07:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:50:03 --> Input Class Initialized
INFO - 2020-02-09 07:50:03 --> Language Class Initialized
INFO - 2020-02-09 07:50:03 --> Language Class Initialized
INFO - 2020-02-09 07:50:03 --> Config Class Initialized
INFO - 2020-02-09 07:50:03 --> Loader Class Initialized
INFO - 2020-02-09 07:50:03 --> Helper loaded: url_helper
INFO - 2020-02-09 07:50:03 --> Helper loaded: file_helper
INFO - 2020-02-09 07:50:03 --> Helper loaded: form_helper
INFO - 2020-02-09 07:50:03 --> Helper loaded: my_helper
INFO - 2020-02-09 07:50:03 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:50:03 --> Controller Class Initialized
INFO - 2020-02-09 07:50:03 --> Final output sent to browser
DEBUG - 2020-02-09 07:50:03 --> Total execution time: 0.9776
INFO - 2020-02-09 07:50:06 --> Config Class Initialized
INFO - 2020-02-09 07:50:06 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:50:06 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:50:06 --> Utf8 Class Initialized
INFO - 2020-02-09 07:50:06 --> URI Class Initialized
INFO - 2020-02-09 07:50:06 --> Router Class Initialized
INFO - 2020-02-09 07:50:06 --> Output Class Initialized
INFO - 2020-02-09 07:50:06 --> Security Class Initialized
DEBUG - 2020-02-09 07:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:50:06 --> Input Class Initialized
INFO - 2020-02-09 07:50:06 --> Language Class Initialized
INFO - 2020-02-09 07:50:06 --> Language Class Initialized
INFO - 2020-02-09 07:50:06 --> Config Class Initialized
INFO - 2020-02-09 07:50:06 --> Loader Class Initialized
INFO - 2020-02-09 07:50:06 --> Helper loaded: url_helper
INFO - 2020-02-09 07:50:06 --> Helper loaded: file_helper
INFO - 2020-02-09 07:50:06 --> Helper loaded: form_helper
INFO - 2020-02-09 07:50:06 --> Helper loaded: my_helper
INFO - 2020-02-09 07:50:06 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:50:06 --> Controller Class Initialized
INFO - 2020-02-09 07:50:06 --> Final output sent to browser
DEBUG - 2020-02-09 07:50:06 --> Total execution time: 0.8232
INFO - 2020-02-09 07:50:07 --> Config Class Initialized
INFO - 2020-02-09 07:50:07 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:50:07 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:50:07 --> Utf8 Class Initialized
INFO - 2020-02-09 07:50:07 --> URI Class Initialized
INFO - 2020-02-09 07:50:07 --> Router Class Initialized
INFO - 2020-02-09 07:50:07 --> Output Class Initialized
INFO - 2020-02-09 07:50:07 --> Security Class Initialized
DEBUG - 2020-02-09 07:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:50:07 --> Input Class Initialized
INFO - 2020-02-09 07:50:07 --> Language Class Initialized
INFO - 2020-02-09 07:50:07 --> Language Class Initialized
INFO - 2020-02-09 07:50:07 --> Config Class Initialized
INFO - 2020-02-09 07:50:07 --> Loader Class Initialized
INFO - 2020-02-09 07:50:07 --> Helper loaded: url_helper
INFO - 2020-02-09 07:50:07 --> Helper loaded: file_helper
INFO - 2020-02-09 07:50:07 --> Helper loaded: form_helper
INFO - 2020-02-09 07:50:07 --> Helper loaded: my_helper
INFO - 2020-02-09 07:50:07 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:50:07 --> Controller Class Initialized
INFO - 2020-02-09 07:50:07 --> Final output sent to browser
DEBUG - 2020-02-09 07:50:07 --> Total execution time: 0.8759
INFO - 2020-02-09 07:50:18 --> Config Class Initialized
INFO - 2020-02-09 07:50:18 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:50:18 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:50:18 --> Utf8 Class Initialized
INFO - 2020-02-09 07:50:19 --> URI Class Initialized
INFO - 2020-02-09 07:50:19 --> Router Class Initialized
INFO - 2020-02-09 07:50:19 --> Output Class Initialized
INFO - 2020-02-09 07:50:19 --> Security Class Initialized
DEBUG - 2020-02-09 07:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:50:19 --> Input Class Initialized
INFO - 2020-02-09 07:50:19 --> Language Class Initialized
INFO - 2020-02-09 07:50:19 --> Language Class Initialized
INFO - 2020-02-09 07:50:19 --> Config Class Initialized
INFO - 2020-02-09 07:50:19 --> Loader Class Initialized
INFO - 2020-02-09 07:50:19 --> Helper loaded: url_helper
INFO - 2020-02-09 07:50:19 --> Helper loaded: file_helper
INFO - 2020-02-09 07:50:19 --> Helper loaded: form_helper
INFO - 2020-02-09 07:50:19 --> Helper loaded: my_helper
INFO - 2020-02-09 07:50:19 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:50:19 --> Controller Class Initialized
INFO - 2020-02-09 07:50:19 --> Final output sent to browser
DEBUG - 2020-02-09 07:50:20 --> Total execution time: 1.0179
INFO - 2020-02-09 07:50:21 --> Config Class Initialized
INFO - 2020-02-09 07:50:21 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:50:21 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:50:21 --> Utf8 Class Initialized
INFO - 2020-02-09 07:50:21 --> URI Class Initialized
INFO - 2020-02-09 07:50:22 --> Router Class Initialized
INFO - 2020-02-09 07:50:22 --> Output Class Initialized
INFO - 2020-02-09 07:50:22 --> Security Class Initialized
DEBUG - 2020-02-09 07:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:50:22 --> Input Class Initialized
INFO - 2020-02-09 07:50:22 --> Language Class Initialized
INFO - 2020-02-09 07:50:22 --> Language Class Initialized
INFO - 2020-02-09 07:50:22 --> Config Class Initialized
INFO - 2020-02-09 07:50:22 --> Loader Class Initialized
INFO - 2020-02-09 07:50:22 --> Helper loaded: url_helper
INFO - 2020-02-09 07:50:22 --> Helper loaded: file_helper
INFO - 2020-02-09 07:50:22 --> Helper loaded: form_helper
INFO - 2020-02-09 07:50:22 --> Helper loaded: my_helper
INFO - 2020-02-09 07:50:22 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:50:23 --> Controller Class Initialized
INFO - 2020-02-09 07:50:23 --> Final output sent to browser
DEBUG - 2020-02-09 07:50:23 --> Total execution time: 1.6262
INFO - 2020-02-09 07:50:32 --> Config Class Initialized
INFO - 2020-02-09 07:50:32 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:50:32 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:50:32 --> Utf8 Class Initialized
INFO - 2020-02-09 07:50:32 --> URI Class Initialized
INFO - 2020-02-09 07:50:32 --> Router Class Initialized
INFO - 2020-02-09 07:50:32 --> Output Class Initialized
INFO - 2020-02-09 07:50:32 --> Security Class Initialized
DEBUG - 2020-02-09 07:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:50:32 --> Input Class Initialized
INFO - 2020-02-09 07:50:32 --> Language Class Initialized
INFO - 2020-02-09 07:50:32 --> Language Class Initialized
INFO - 2020-02-09 07:50:32 --> Config Class Initialized
INFO - 2020-02-09 07:50:32 --> Loader Class Initialized
INFO - 2020-02-09 07:50:32 --> Helper loaded: url_helper
INFO - 2020-02-09 07:50:32 --> Helper loaded: file_helper
INFO - 2020-02-09 07:50:32 --> Helper loaded: form_helper
INFO - 2020-02-09 07:50:32 --> Helper loaded: my_helper
INFO - 2020-02-09 07:50:32 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:50:32 --> Controller Class Initialized
INFO - 2020-02-09 07:50:33 --> Final output sent to browser
DEBUG - 2020-02-09 07:50:33 --> Total execution time: 0.8335
INFO - 2020-02-09 07:50:49 --> Config Class Initialized
INFO - 2020-02-09 07:50:49 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:50:49 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:50:49 --> Utf8 Class Initialized
INFO - 2020-02-09 07:50:49 --> URI Class Initialized
INFO - 2020-02-09 07:50:49 --> Router Class Initialized
INFO - 2020-02-09 07:50:49 --> Output Class Initialized
INFO - 2020-02-09 07:50:49 --> Security Class Initialized
DEBUG - 2020-02-09 07:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:50:50 --> Input Class Initialized
INFO - 2020-02-09 07:50:50 --> Language Class Initialized
INFO - 2020-02-09 07:50:50 --> Language Class Initialized
INFO - 2020-02-09 07:50:50 --> Config Class Initialized
INFO - 2020-02-09 07:50:50 --> Loader Class Initialized
INFO - 2020-02-09 07:50:50 --> Helper loaded: url_helper
INFO - 2020-02-09 07:50:50 --> Helper loaded: file_helper
INFO - 2020-02-09 07:50:50 --> Helper loaded: form_helper
INFO - 2020-02-09 07:50:50 --> Helper loaded: my_helper
INFO - 2020-02-09 07:50:50 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:50:50 --> Controller Class Initialized
DEBUG - 2020-02-09 07:50:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_prestasi/views/list.php
DEBUG - 2020-02-09 07:50:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:50:50 --> Final output sent to browser
DEBUG - 2020-02-09 07:50:50 --> Total execution time: 0.9000
INFO - 2020-02-09 07:50:51 --> Config Class Initialized
INFO - 2020-02-09 07:50:51 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:50:51 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:50:51 --> Utf8 Class Initialized
INFO - 2020-02-09 07:50:51 --> URI Class Initialized
INFO - 2020-02-09 07:50:51 --> Router Class Initialized
INFO - 2020-02-09 07:50:51 --> Output Class Initialized
INFO - 2020-02-09 07:50:51 --> Security Class Initialized
DEBUG - 2020-02-09 07:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:50:51 --> Input Class Initialized
INFO - 2020-02-09 07:50:51 --> Language Class Initialized
INFO - 2020-02-09 07:50:51 --> Language Class Initialized
INFO - 2020-02-09 07:50:51 --> Config Class Initialized
INFO - 2020-02-09 07:50:51 --> Loader Class Initialized
INFO - 2020-02-09 07:50:51 --> Helper loaded: url_helper
INFO - 2020-02-09 07:50:51 --> Helper loaded: file_helper
INFO - 2020-02-09 07:50:51 --> Helper loaded: form_helper
INFO - 2020-02-09 07:50:51 --> Helper loaded: my_helper
INFO - 2020-02-09 07:50:52 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:50:52 --> Controller Class Initialized
INFO - 2020-02-09 07:51:24 --> Config Class Initialized
INFO - 2020-02-09 07:51:24 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:51:25 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:51:25 --> Utf8 Class Initialized
INFO - 2020-02-09 07:51:25 --> URI Class Initialized
INFO - 2020-02-09 07:51:25 --> Router Class Initialized
INFO - 2020-02-09 07:51:25 --> Output Class Initialized
INFO - 2020-02-09 07:51:25 --> Security Class Initialized
DEBUG - 2020-02-09 07:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:51:25 --> Input Class Initialized
INFO - 2020-02-09 07:51:25 --> Language Class Initialized
INFO - 2020-02-09 07:51:25 --> Language Class Initialized
INFO - 2020-02-09 07:51:25 --> Config Class Initialized
INFO - 2020-02-09 07:51:25 --> Loader Class Initialized
INFO - 2020-02-09 07:51:25 --> Helper loaded: url_helper
INFO - 2020-02-09 07:51:25 --> Helper loaded: file_helper
INFO - 2020-02-09 07:51:25 --> Helper loaded: form_helper
INFO - 2020-02-09 07:51:25 --> Helper loaded: my_helper
INFO - 2020-02-09 07:51:25 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:51:25 --> Controller Class Initialized
INFO - 2020-02-09 07:51:25 --> Final output sent to browser
DEBUG - 2020-02-09 07:51:25 --> Total execution time: 0.6692
INFO - 2020-02-09 07:51:25 --> Config Class Initialized
INFO - 2020-02-09 07:51:25 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:51:25 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:51:25 --> Utf8 Class Initialized
INFO - 2020-02-09 07:51:25 --> URI Class Initialized
INFO - 2020-02-09 07:51:25 --> Router Class Initialized
INFO - 2020-02-09 07:51:25 --> Output Class Initialized
INFO - 2020-02-09 07:51:25 --> Security Class Initialized
DEBUG - 2020-02-09 07:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:51:25 --> Input Class Initialized
INFO - 2020-02-09 07:51:26 --> Language Class Initialized
INFO - 2020-02-09 07:51:26 --> Language Class Initialized
INFO - 2020-02-09 07:51:26 --> Config Class Initialized
INFO - 2020-02-09 07:51:26 --> Loader Class Initialized
INFO - 2020-02-09 07:51:26 --> Helper loaded: url_helper
INFO - 2020-02-09 07:51:26 --> Helper loaded: file_helper
INFO - 2020-02-09 07:51:26 --> Helper loaded: form_helper
INFO - 2020-02-09 07:51:26 --> Helper loaded: my_helper
INFO - 2020-02-09 07:51:26 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:51:26 --> Controller Class Initialized
INFO - 2020-02-09 07:51:30 --> Config Class Initialized
INFO - 2020-02-09 07:51:30 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:51:30 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:51:30 --> Utf8 Class Initialized
INFO - 2020-02-09 07:51:30 --> URI Class Initialized
INFO - 2020-02-09 07:51:30 --> Router Class Initialized
INFO - 2020-02-09 07:51:30 --> Output Class Initialized
INFO - 2020-02-09 07:51:30 --> Security Class Initialized
DEBUG - 2020-02-09 07:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:51:30 --> Input Class Initialized
INFO - 2020-02-09 07:51:30 --> Language Class Initialized
INFO - 2020-02-09 07:51:30 --> Language Class Initialized
INFO - 2020-02-09 07:51:30 --> Config Class Initialized
INFO - 2020-02-09 07:51:30 --> Loader Class Initialized
INFO - 2020-02-09 07:51:30 --> Helper loaded: url_helper
INFO - 2020-02-09 07:51:30 --> Helper loaded: file_helper
INFO - 2020-02-09 07:51:30 --> Helper loaded: form_helper
INFO - 2020-02-09 07:51:30 --> Helper loaded: my_helper
INFO - 2020-02-09 07:51:30 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:51:31 --> Controller Class Initialized
DEBUG - 2020-02-09 07:51:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_catatan/views/list.php
DEBUG - 2020-02-09 07:51:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:51:31 --> Final output sent to browser
DEBUG - 2020-02-09 07:51:31 --> Total execution time: 0.9738
INFO - 2020-02-09 07:52:19 --> Config Class Initialized
INFO - 2020-02-09 07:52:19 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:52:19 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:52:19 --> Utf8 Class Initialized
INFO - 2020-02-09 07:52:19 --> URI Class Initialized
INFO - 2020-02-09 07:52:19 --> Router Class Initialized
INFO - 2020-02-09 07:52:19 --> Output Class Initialized
INFO - 2020-02-09 07:52:19 --> Security Class Initialized
DEBUG - 2020-02-09 07:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:52:19 --> Input Class Initialized
INFO - 2020-02-09 07:52:19 --> Language Class Initialized
INFO - 2020-02-09 07:52:19 --> Language Class Initialized
INFO - 2020-02-09 07:52:19 --> Config Class Initialized
INFO - 2020-02-09 07:52:19 --> Loader Class Initialized
INFO - 2020-02-09 07:52:19 --> Helper loaded: url_helper
INFO - 2020-02-09 07:52:19 --> Helper loaded: file_helper
INFO - 2020-02-09 07:52:19 --> Helper loaded: form_helper
INFO - 2020-02-09 07:52:19 --> Helper loaded: my_helper
INFO - 2020-02-09 07:52:19 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:52:19 --> Controller Class Initialized
INFO - 2020-02-09 07:52:20 --> Final output sent to browser
DEBUG - 2020-02-09 07:52:20 --> Total execution time: 0.7158
INFO - 2020-02-09 07:52:41 --> Config Class Initialized
INFO - 2020-02-09 07:52:41 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:52:42 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:52:42 --> Utf8 Class Initialized
INFO - 2020-02-09 07:52:42 --> URI Class Initialized
INFO - 2020-02-09 07:52:42 --> Router Class Initialized
INFO - 2020-02-09 07:52:42 --> Output Class Initialized
INFO - 2020-02-09 07:52:42 --> Security Class Initialized
DEBUG - 2020-02-09 07:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:52:42 --> Input Class Initialized
INFO - 2020-02-09 07:52:42 --> Language Class Initialized
INFO - 2020-02-09 07:52:42 --> Language Class Initialized
INFO - 2020-02-09 07:52:42 --> Config Class Initialized
INFO - 2020-02-09 07:52:42 --> Loader Class Initialized
INFO - 2020-02-09 07:52:42 --> Helper loaded: url_helper
INFO - 2020-02-09 07:52:42 --> Helper loaded: file_helper
INFO - 2020-02-09 07:52:42 --> Helper loaded: form_helper
INFO - 2020-02-09 07:52:42 --> Helper loaded: my_helper
INFO - 2020-02-09 07:52:42 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:52:42 --> Controller Class Initialized
DEBUG - 2020-02-09 07:52:42 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2020-02-09 07:52:42 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:52:42 --> Final output sent to browser
DEBUG - 2020-02-09 07:52:42 --> Total execution time: 0.9667
INFO - 2020-02-09 07:52:47 --> Config Class Initialized
INFO - 2020-02-09 07:52:47 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:52:47 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:52:47 --> Utf8 Class Initialized
INFO - 2020-02-09 07:52:47 --> URI Class Initialized
INFO - 2020-02-09 07:52:48 --> Router Class Initialized
INFO - 2020-02-09 07:52:48 --> Output Class Initialized
INFO - 2020-02-09 07:52:48 --> Security Class Initialized
DEBUG - 2020-02-09 07:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:52:48 --> Input Class Initialized
INFO - 2020-02-09 07:52:48 --> Language Class Initialized
INFO - 2020-02-09 07:52:48 --> Language Class Initialized
INFO - 2020-02-09 07:52:48 --> Config Class Initialized
INFO - 2020-02-09 07:52:48 --> Loader Class Initialized
INFO - 2020-02-09 07:52:48 --> Helper loaded: url_helper
INFO - 2020-02-09 07:52:48 --> Helper loaded: file_helper
INFO - 2020-02-09 07:52:48 --> Helper loaded: form_helper
INFO - 2020-02-09 07:52:48 --> Helper loaded: my_helper
INFO - 2020-02-09 07:52:48 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:52:49 --> Controller Class Initialized
DEBUG - 2020-02-09 07:52:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-02-09 07:52:49 --> Final output sent to browser
DEBUG - 2020-02-09 07:52:49 --> Total execution time: 1.6408
INFO - 2020-02-09 07:53:56 --> Config Class Initialized
INFO - 2020-02-09 07:53:56 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:53:56 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:53:56 --> Utf8 Class Initialized
INFO - 2020-02-09 07:53:56 --> URI Class Initialized
INFO - 2020-02-09 07:53:56 --> Router Class Initialized
INFO - 2020-02-09 07:53:56 --> Output Class Initialized
INFO - 2020-02-09 07:53:56 --> Security Class Initialized
DEBUG - 2020-02-09 07:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:53:56 --> Input Class Initialized
INFO - 2020-02-09 07:53:56 --> Language Class Initialized
INFO - 2020-02-09 07:53:56 --> Language Class Initialized
INFO - 2020-02-09 07:53:56 --> Config Class Initialized
INFO - 2020-02-09 07:53:56 --> Loader Class Initialized
INFO - 2020-02-09 07:53:56 --> Helper loaded: url_helper
INFO - 2020-02-09 07:53:56 --> Helper loaded: file_helper
INFO - 2020-02-09 07:53:56 --> Helper loaded: form_helper
INFO - 2020-02-09 07:53:56 --> Helper loaded: my_helper
INFO - 2020-02-09 07:53:56 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:53:56 --> Controller Class Initialized
DEBUG - 2020-02-09 07:53:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/list.php
DEBUG - 2020-02-09 07:53:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:53:57 --> Final output sent to browser
DEBUG - 2020-02-09 07:53:57 --> Total execution time: 0.9389
INFO - 2020-02-09 07:54:03 --> Config Class Initialized
INFO - 2020-02-09 07:54:03 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:54:03 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:54:03 --> Utf8 Class Initialized
INFO - 2020-02-09 07:54:03 --> URI Class Initialized
INFO - 2020-02-09 07:54:03 --> Router Class Initialized
INFO - 2020-02-09 07:54:03 --> Output Class Initialized
INFO - 2020-02-09 07:54:03 --> Security Class Initialized
DEBUG - 2020-02-09 07:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:54:03 --> Input Class Initialized
INFO - 2020-02-09 07:54:03 --> Language Class Initialized
INFO - 2020-02-09 07:54:03 --> Language Class Initialized
INFO - 2020-02-09 07:54:04 --> Config Class Initialized
INFO - 2020-02-09 07:54:04 --> Loader Class Initialized
INFO - 2020-02-09 07:54:04 --> Helper loaded: url_helper
INFO - 2020-02-09 07:54:04 --> Helper loaded: file_helper
INFO - 2020-02-09 07:54:04 --> Helper loaded: form_helper
INFO - 2020-02-09 07:54:04 --> Helper loaded: my_helper
INFO - 2020-02-09 07:54:04 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:54:04 --> Controller Class Initialized
DEBUG - 2020-02-09 07:54:04 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2020-02-09 07:54:05 --> Final output sent to browser
DEBUG - 2020-02-09 07:54:05 --> Total execution time: 1.8817
INFO - 2020-02-09 07:54:23 --> Config Class Initialized
INFO - 2020-02-09 07:54:23 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:54:23 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:54:24 --> Utf8 Class Initialized
INFO - 2020-02-09 07:54:24 --> URI Class Initialized
INFO - 2020-02-09 07:54:24 --> Router Class Initialized
INFO - 2020-02-09 07:54:24 --> Output Class Initialized
INFO - 2020-02-09 07:54:24 --> Security Class Initialized
DEBUG - 2020-02-09 07:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:54:24 --> Input Class Initialized
INFO - 2020-02-09 07:54:24 --> Language Class Initialized
INFO - 2020-02-09 07:54:24 --> Language Class Initialized
INFO - 2020-02-09 07:54:24 --> Config Class Initialized
INFO - 2020-02-09 07:54:25 --> Loader Class Initialized
INFO - 2020-02-09 07:54:25 --> Helper loaded: url_helper
INFO - 2020-02-09 07:54:25 --> Helper loaded: file_helper
INFO - 2020-02-09 07:54:25 --> Helper loaded: form_helper
INFO - 2020-02-09 07:54:25 --> Helper loaded: my_helper
INFO - 2020-02-09 07:54:25 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:54:25 --> Controller Class Initialized
DEBUG - 2020-02-09 07:54:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2020-02-09 07:54:25 --> Final output sent to browser
DEBUG - 2020-02-09 07:54:26 --> Total execution time: 2.1305
INFO - 2020-02-09 07:54:35 --> Config Class Initialized
INFO - 2020-02-09 07:54:35 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:54:35 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:54:35 --> Utf8 Class Initialized
INFO - 2020-02-09 07:54:35 --> URI Class Initialized
INFO - 2020-02-09 07:54:35 --> Router Class Initialized
INFO - 2020-02-09 07:54:35 --> Output Class Initialized
INFO - 2020-02-09 07:54:36 --> Security Class Initialized
DEBUG - 2020-02-09 07:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:54:36 --> Input Class Initialized
INFO - 2020-02-09 07:54:36 --> Language Class Initialized
INFO - 2020-02-09 07:54:36 --> Language Class Initialized
INFO - 2020-02-09 07:54:36 --> Config Class Initialized
INFO - 2020-02-09 07:54:36 --> Loader Class Initialized
INFO - 2020-02-09 07:54:36 --> Helper loaded: url_helper
INFO - 2020-02-09 07:54:36 --> Helper loaded: file_helper
INFO - 2020-02-09 07:54:36 --> Helper loaded: form_helper
INFO - 2020-02-09 07:54:36 --> Helper loaded: my_helper
INFO - 2020-02-09 07:54:36 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:54:36 --> Controller Class Initialized
DEBUG - 2020-02-09 07:54:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2020-02-09 07:54:37 --> Final output sent to browser
DEBUG - 2020-02-09 07:54:37 --> Total execution time: 1.5912
INFO - 2020-02-09 07:54:48 --> Config Class Initialized
INFO - 2020-02-09 07:54:48 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:54:48 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:54:48 --> Utf8 Class Initialized
INFO - 2020-02-09 07:54:48 --> URI Class Initialized
INFO - 2020-02-09 07:54:48 --> Router Class Initialized
INFO - 2020-02-09 07:54:48 --> Output Class Initialized
INFO - 2020-02-09 07:54:48 --> Security Class Initialized
DEBUG - 2020-02-09 07:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:54:48 --> Input Class Initialized
INFO - 2020-02-09 07:54:49 --> Language Class Initialized
INFO - 2020-02-09 07:54:49 --> Language Class Initialized
INFO - 2020-02-09 07:54:49 --> Config Class Initialized
INFO - 2020-02-09 07:54:49 --> Loader Class Initialized
INFO - 2020-02-09 07:54:49 --> Helper loaded: url_helper
INFO - 2020-02-09 07:54:49 --> Helper loaded: file_helper
INFO - 2020-02-09 07:54:49 --> Helper loaded: form_helper
INFO - 2020-02-09 07:54:49 --> Helper loaded: my_helper
INFO - 2020-02-09 07:54:49 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:54:49 --> Controller Class Initialized
DEBUG - 2020-02-09 07:54:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-02-09 07:54:49 --> Final output sent to browser
DEBUG - 2020-02-09 07:54:49 --> Total execution time: 1.5079
INFO - 2020-02-09 07:56:45 --> Config Class Initialized
INFO - 2020-02-09 07:56:45 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:56:45 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:56:45 --> Utf8 Class Initialized
INFO - 2020-02-09 07:56:45 --> URI Class Initialized
INFO - 2020-02-09 07:56:45 --> Router Class Initialized
INFO - 2020-02-09 07:56:45 --> Output Class Initialized
INFO - 2020-02-09 07:56:46 --> Security Class Initialized
DEBUG - 2020-02-09 07:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:56:46 --> Input Class Initialized
INFO - 2020-02-09 07:56:46 --> Language Class Initialized
INFO - 2020-02-09 07:56:46 --> Language Class Initialized
INFO - 2020-02-09 07:56:46 --> Config Class Initialized
INFO - 2020-02-09 07:56:46 --> Loader Class Initialized
INFO - 2020-02-09 07:56:46 --> Helper loaded: url_helper
INFO - 2020-02-09 07:56:46 --> Helper loaded: file_helper
INFO - 2020-02-09 07:56:46 --> Helper loaded: form_helper
INFO - 2020-02-09 07:56:46 --> Helper loaded: my_helper
INFO - 2020-02-09 07:56:46 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:56:46 --> Controller Class Initialized
DEBUG - 2020-02-09 07:56:47 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/cetak_prestasi.php
INFO - 2020-02-09 07:56:47 --> Final output sent to browser
DEBUG - 2020-02-09 07:56:47 --> Total execution time: 1.5224
INFO - 2020-02-09 07:57:13 --> Config Class Initialized
INFO - 2020-02-09 07:57:13 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:57:13 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:57:13 --> Utf8 Class Initialized
INFO - 2020-02-09 07:57:13 --> URI Class Initialized
INFO - 2020-02-09 07:57:13 --> Router Class Initialized
INFO - 2020-02-09 07:57:13 --> Output Class Initialized
INFO - 2020-02-09 07:57:13 --> Security Class Initialized
DEBUG - 2020-02-09 07:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:57:14 --> Input Class Initialized
INFO - 2020-02-09 07:57:14 --> Language Class Initialized
INFO - 2020-02-09 07:57:14 --> Language Class Initialized
INFO - 2020-02-09 07:57:14 --> Config Class Initialized
INFO - 2020-02-09 07:57:14 --> Loader Class Initialized
INFO - 2020-02-09 07:57:14 --> Helper loaded: url_helper
INFO - 2020-02-09 07:57:14 --> Helper loaded: file_helper
INFO - 2020-02-09 07:57:14 --> Helper loaded: form_helper
INFO - 2020-02-09 07:57:14 --> Helper loaded: my_helper
INFO - 2020-02-09 07:57:14 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:57:14 --> Controller Class Initialized
DEBUG - 2020-02-09 07:57:14 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-02-09 07:57:14 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:57:14 --> Final output sent to browser
DEBUG - 2020-02-09 07:57:15 --> Total execution time: 1.4655
INFO - 2020-02-09 07:57:25 --> Config Class Initialized
INFO - 2020-02-09 07:57:25 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:57:25 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:57:25 --> Utf8 Class Initialized
INFO - 2020-02-09 07:57:25 --> URI Class Initialized
INFO - 2020-02-09 07:57:25 --> Router Class Initialized
INFO - 2020-02-09 07:57:25 --> Output Class Initialized
INFO - 2020-02-09 07:57:25 --> Security Class Initialized
DEBUG - 2020-02-09 07:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:57:25 --> Input Class Initialized
INFO - 2020-02-09 07:57:25 --> Language Class Initialized
INFO - 2020-02-09 07:57:26 --> Language Class Initialized
INFO - 2020-02-09 07:57:26 --> Config Class Initialized
INFO - 2020-02-09 07:57:26 --> Loader Class Initialized
INFO - 2020-02-09 07:57:26 --> Helper loaded: url_helper
INFO - 2020-02-09 07:57:26 --> Helper loaded: file_helper
INFO - 2020-02-09 07:57:26 --> Helper loaded: form_helper
INFO - 2020-02-09 07:57:26 --> Helper loaded: my_helper
INFO - 2020-02-09 07:57:26 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:57:26 --> Controller Class Initialized
DEBUG - 2020-02-09 07:57:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_leger/views/cetak.php
INFO - 2020-02-09 07:57:27 --> Final output sent to browser
DEBUG - 2020-02-09 07:57:27 --> Total execution time: 2.2651
INFO - 2020-02-09 07:58:08 --> Config Class Initialized
INFO - 2020-02-09 07:58:09 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:58:09 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:58:09 --> Utf8 Class Initialized
INFO - 2020-02-09 07:58:09 --> URI Class Initialized
INFO - 2020-02-09 07:58:09 --> Router Class Initialized
INFO - 2020-02-09 07:58:09 --> Output Class Initialized
INFO - 2020-02-09 07:58:09 --> Security Class Initialized
DEBUG - 2020-02-09 07:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:58:09 --> Input Class Initialized
INFO - 2020-02-09 07:58:09 --> Language Class Initialized
INFO - 2020-02-09 07:58:09 --> Language Class Initialized
INFO - 2020-02-09 07:58:09 --> Config Class Initialized
INFO - 2020-02-09 07:58:10 --> Loader Class Initialized
INFO - 2020-02-09 07:58:10 --> Helper loaded: url_helper
INFO - 2020-02-09 07:58:10 --> Helper loaded: file_helper
INFO - 2020-02-09 07:58:10 --> Helper loaded: form_helper
INFO - 2020-02-09 07:58:10 --> Helper loaded: my_helper
INFO - 2020-02-09 07:58:10 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:58:10 --> Controller Class Initialized
DEBUG - 2020-02-09 07:58:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_leger/views/cetak_ekstra.php
INFO - 2020-02-09 07:58:10 --> Final output sent to browser
DEBUG - 2020-02-09 07:58:11 --> Total execution time: 1.8802
INFO - 2020-02-09 07:58:27 --> Config Class Initialized
INFO - 2020-02-09 07:58:27 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:58:27 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:58:27 --> Utf8 Class Initialized
INFO - 2020-02-09 07:58:27 --> URI Class Initialized
INFO - 2020-02-09 07:58:27 --> Router Class Initialized
INFO - 2020-02-09 07:58:27 --> Output Class Initialized
INFO - 2020-02-09 07:58:27 --> Security Class Initialized
DEBUG - 2020-02-09 07:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:58:27 --> Input Class Initialized
INFO - 2020-02-09 07:58:27 --> Language Class Initialized
INFO - 2020-02-09 07:58:27 --> Language Class Initialized
INFO - 2020-02-09 07:58:27 --> Config Class Initialized
INFO - 2020-02-09 07:58:27 --> Loader Class Initialized
INFO - 2020-02-09 07:58:27 --> Helper loaded: url_helper
INFO - 2020-02-09 07:58:27 --> Helper loaded: file_helper
INFO - 2020-02-09 07:58:28 --> Helper loaded: form_helper
INFO - 2020-02-09 07:58:28 --> Helper loaded: my_helper
INFO - 2020-02-09 07:58:28 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:58:28 --> Controller Class Initialized
DEBUG - 2020-02-09 07:58:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_ubah_password.php
DEBUG - 2020-02-09 07:58:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:58:28 --> Final output sent to browser
DEBUG - 2020-02-09 07:58:28 --> Total execution time: 1.0873
INFO - 2020-02-09 07:58:46 --> Config Class Initialized
INFO - 2020-02-09 07:58:46 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:58:46 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:58:46 --> Utf8 Class Initialized
INFO - 2020-02-09 07:58:46 --> URI Class Initialized
DEBUG - 2020-02-09 07:58:46 --> No URI present. Default controller set.
INFO - 2020-02-09 07:58:46 --> Router Class Initialized
INFO - 2020-02-09 07:58:46 --> Output Class Initialized
INFO - 2020-02-09 07:58:46 --> Security Class Initialized
DEBUG - 2020-02-09 07:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:58:46 --> Input Class Initialized
INFO - 2020-02-09 07:58:46 --> Language Class Initialized
INFO - 2020-02-09 07:58:46 --> Language Class Initialized
INFO - 2020-02-09 07:58:46 --> Config Class Initialized
INFO - 2020-02-09 07:58:46 --> Loader Class Initialized
INFO - 2020-02-09 07:58:46 --> Helper loaded: url_helper
INFO - 2020-02-09 07:58:46 --> Helper loaded: file_helper
INFO - 2020-02-09 07:58:46 --> Helper loaded: form_helper
INFO - 2020-02-09 07:58:46 --> Helper loaded: my_helper
INFO - 2020-02-09 07:58:46 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:58:46 --> Controller Class Initialized
DEBUG - 2020-02-09 07:58:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-09 07:58:47 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:58:47 --> Final output sent to browser
DEBUG - 2020-02-09 07:58:47 --> Total execution time: 0.9901
INFO - 2020-02-09 07:59:57 --> Config Class Initialized
INFO - 2020-02-09 07:59:57 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:59:57 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:59:57 --> Utf8 Class Initialized
INFO - 2020-02-09 07:59:57 --> URI Class Initialized
INFO - 2020-02-09 07:59:57 --> Router Class Initialized
INFO - 2020-02-09 07:59:57 --> Output Class Initialized
INFO - 2020-02-09 07:59:57 --> Security Class Initialized
DEBUG - 2020-02-09 07:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:59:57 --> Input Class Initialized
INFO - 2020-02-09 07:59:57 --> Language Class Initialized
INFO - 2020-02-09 07:59:57 --> Language Class Initialized
INFO - 2020-02-09 07:59:57 --> Config Class Initialized
INFO - 2020-02-09 07:59:57 --> Loader Class Initialized
INFO - 2020-02-09 07:59:57 --> Helper loaded: url_helper
INFO - 2020-02-09 07:59:57 --> Helper loaded: file_helper
INFO - 2020-02-09 07:59:57 --> Helper loaded: form_helper
INFO - 2020-02-09 07:59:57 --> Helper loaded: my_helper
INFO - 2020-02-09 07:59:57 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:59:57 --> Controller Class Initialized
INFO - 2020-02-09 07:59:57 --> Helper loaded: cookie_helper
INFO - 2020-02-09 07:59:58 --> Config Class Initialized
INFO - 2020-02-09 07:59:58 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:59:58 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:59:58 --> Utf8 Class Initialized
INFO - 2020-02-09 07:59:58 --> URI Class Initialized
INFO - 2020-02-09 07:59:58 --> Router Class Initialized
INFO - 2020-02-09 07:59:58 --> Output Class Initialized
INFO - 2020-02-09 07:59:58 --> Security Class Initialized
DEBUG - 2020-02-09 07:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:59:58 --> Input Class Initialized
INFO - 2020-02-09 07:59:58 --> Language Class Initialized
INFO - 2020-02-09 07:59:58 --> Language Class Initialized
INFO - 2020-02-09 07:59:58 --> Config Class Initialized
INFO - 2020-02-09 07:59:58 --> Loader Class Initialized
INFO - 2020-02-09 07:59:58 --> Helper loaded: url_helper
INFO - 2020-02-09 07:59:58 --> Helper loaded: file_helper
INFO - 2020-02-09 07:59:58 --> Helper loaded: form_helper
INFO - 2020-02-09 07:59:58 --> Helper loaded: my_helper
INFO - 2020-02-09 07:59:58 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:59:58 --> Controller Class Initialized
INFO - 2020-02-09 07:59:58 --> Config Class Initialized
INFO - 2020-02-09 07:59:58 --> Hooks Class Initialized
DEBUG - 2020-02-09 07:59:58 --> UTF-8 Support Enabled
INFO - 2020-02-09 07:59:58 --> Utf8 Class Initialized
INFO - 2020-02-09 07:59:59 --> URI Class Initialized
INFO - 2020-02-09 07:59:59 --> Router Class Initialized
INFO - 2020-02-09 07:59:59 --> Output Class Initialized
INFO - 2020-02-09 07:59:59 --> Security Class Initialized
DEBUG - 2020-02-09 07:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 07:59:59 --> Input Class Initialized
INFO - 2020-02-09 07:59:59 --> Language Class Initialized
INFO - 2020-02-09 07:59:59 --> Language Class Initialized
INFO - 2020-02-09 07:59:59 --> Config Class Initialized
INFO - 2020-02-09 07:59:59 --> Loader Class Initialized
INFO - 2020-02-09 07:59:59 --> Helper loaded: url_helper
INFO - 2020-02-09 07:59:59 --> Helper loaded: file_helper
INFO - 2020-02-09 07:59:59 --> Helper loaded: form_helper
INFO - 2020-02-09 07:59:59 --> Helper loaded: my_helper
INFO - 2020-02-09 07:59:59 --> Database Driver Class Initialized
DEBUG - 2020-02-09 07:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 07:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 07:59:59 --> Controller Class Initialized
DEBUG - 2020-02-09 07:59:59 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 07:59:59 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 07:59:59 --> Final output sent to browser
DEBUG - 2020-02-09 07:59:59 --> Total execution time: 0.8528
INFO - 2020-02-09 14:30:45 --> Config Class Initialized
INFO - 2020-02-09 14:30:45 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:30:45 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:30:45 --> Utf8 Class Initialized
INFO - 2020-02-09 14:30:45 --> URI Class Initialized
DEBUG - 2020-02-09 14:30:45 --> No URI present. Default controller set.
INFO - 2020-02-09 14:30:45 --> Router Class Initialized
INFO - 2020-02-09 14:30:45 --> Output Class Initialized
INFO - 2020-02-09 14:30:45 --> Security Class Initialized
DEBUG - 2020-02-09 14:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:30:45 --> Input Class Initialized
INFO - 2020-02-09 14:30:45 --> Language Class Initialized
INFO - 2020-02-09 14:30:45 --> Language Class Initialized
INFO - 2020-02-09 14:30:45 --> Config Class Initialized
INFO - 2020-02-09 14:30:45 --> Loader Class Initialized
INFO - 2020-02-09 14:30:45 --> Helper loaded: url_helper
INFO - 2020-02-09 14:30:45 --> Helper loaded: file_helper
INFO - 2020-02-09 14:30:45 --> Helper loaded: form_helper
INFO - 2020-02-09 14:30:46 --> Helper loaded: my_helper
INFO - 2020-02-09 14:30:46 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:30:46 --> Controller Class Initialized
INFO - 2020-02-09 14:30:46 --> Config Class Initialized
INFO - 2020-02-09 14:30:46 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:30:46 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:30:46 --> Utf8 Class Initialized
INFO - 2020-02-09 14:30:46 --> URI Class Initialized
INFO - 2020-02-09 14:30:46 --> Router Class Initialized
INFO - 2020-02-09 14:30:46 --> Output Class Initialized
INFO - 2020-02-09 14:30:46 --> Security Class Initialized
DEBUG - 2020-02-09 14:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:30:46 --> Input Class Initialized
INFO - 2020-02-09 14:30:46 --> Language Class Initialized
INFO - 2020-02-09 14:30:46 --> Language Class Initialized
INFO - 2020-02-09 14:30:46 --> Config Class Initialized
INFO - 2020-02-09 14:30:46 --> Loader Class Initialized
INFO - 2020-02-09 14:30:46 --> Helper loaded: url_helper
INFO - 2020-02-09 14:30:46 --> Helper loaded: file_helper
INFO - 2020-02-09 14:30:46 --> Helper loaded: form_helper
INFO - 2020-02-09 14:30:46 --> Helper loaded: my_helper
INFO - 2020-02-09 14:30:46 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:30:46 --> Controller Class Initialized
DEBUG - 2020-02-09 14:30:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 14:30:47 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 14:30:47 --> Final output sent to browser
DEBUG - 2020-02-09 14:30:47 --> Total execution time: 0.6654
INFO - 2020-02-09 14:31:08 --> Config Class Initialized
INFO - 2020-02-09 14:31:08 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:31:08 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:31:08 --> Utf8 Class Initialized
INFO - 2020-02-09 14:31:08 --> URI Class Initialized
INFO - 2020-02-09 14:31:08 --> Router Class Initialized
INFO - 2020-02-09 14:31:08 --> Output Class Initialized
INFO - 2020-02-09 14:31:08 --> Security Class Initialized
DEBUG - 2020-02-09 14:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:31:08 --> Input Class Initialized
INFO - 2020-02-09 14:31:08 --> Language Class Initialized
INFO - 2020-02-09 14:31:08 --> Language Class Initialized
INFO - 2020-02-09 14:31:08 --> Config Class Initialized
INFO - 2020-02-09 14:31:08 --> Loader Class Initialized
INFO - 2020-02-09 14:31:08 --> Helper loaded: url_helper
INFO - 2020-02-09 14:31:08 --> Helper loaded: file_helper
INFO - 2020-02-09 14:31:08 --> Helper loaded: form_helper
INFO - 2020-02-09 14:31:08 --> Helper loaded: my_helper
INFO - 2020-02-09 14:31:08 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:31:08 --> Controller Class Initialized
INFO - 2020-02-09 14:31:09 --> Helper loaded: cookie_helper
INFO - 2020-02-09 14:31:09 --> Final output sent to browser
DEBUG - 2020-02-09 14:31:09 --> Total execution time: 0.7613
INFO - 2020-02-09 14:31:09 --> Config Class Initialized
INFO - 2020-02-09 14:31:09 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:31:09 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:31:09 --> Utf8 Class Initialized
INFO - 2020-02-09 14:31:09 --> URI Class Initialized
INFO - 2020-02-09 14:31:09 --> Router Class Initialized
INFO - 2020-02-09 14:31:09 --> Output Class Initialized
INFO - 2020-02-09 14:31:09 --> Security Class Initialized
DEBUG - 2020-02-09 14:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:31:09 --> Input Class Initialized
INFO - 2020-02-09 14:31:09 --> Language Class Initialized
INFO - 2020-02-09 14:31:09 --> Language Class Initialized
INFO - 2020-02-09 14:31:09 --> Config Class Initialized
INFO - 2020-02-09 14:31:09 --> Loader Class Initialized
INFO - 2020-02-09 14:31:09 --> Helper loaded: url_helper
INFO - 2020-02-09 14:31:09 --> Helper loaded: file_helper
INFO - 2020-02-09 14:31:09 --> Helper loaded: form_helper
INFO - 2020-02-09 14:31:09 --> Helper loaded: my_helper
INFO - 2020-02-09 14:31:09 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:31:09 --> Controller Class Initialized
DEBUG - 2020-02-09 14:31:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-09 14:31:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 14:31:10 --> Final output sent to browser
DEBUG - 2020-02-09 14:31:10 --> Total execution time: 0.8817
INFO - 2020-02-09 14:31:18 --> Config Class Initialized
INFO - 2020-02-09 14:31:18 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:31:18 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:31:18 --> Utf8 Class Initialized
INFO - 2020-02-09 14:31:18 --> URI Class Initialized
INFO - 2020-02-09 14:31:18 --> Router Class Initialized
INFO - 2020-02-09 14:31:18 --> Output Class Initialized
INFO - 2020-02-09 14:31:18 --> Security Class Initialized
DEBUG - 2020-02-09 14:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:31:18 --> Input Class Initialized
INFO - 2020-02-09 14:31:18 --> Language Class Initialized
INFO - 2020-02-09 14:31:18 --> Language Class Initialized
INFO - 2020-02-09 14:31:18 --> Config Class Initialized
INFO - 2020-02-09 14:31:18 --> Loader Class Initialized
INFO - 2020-02-09 14:31:18 --> Helper loaded: url_helper
INFO - 2020-02-09 14:31:18 --> Helper loaded: file_helper
INFO - 2020-02-09 14:31:18 --> Helper loaded: form_helper
INFO - 2020-02-09 14:31:18 --> Helper loaded: my_helper
INFO - 2020-02-09 14:31:18 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:31:18 --> Controller Class Initialized
INFO - 2020-02-09 14:31:18 --> Helper loaded: cookie_helper
INFO - 2020-02-09 14:31:18 --> Config Class Initialized
INFO - 2020-02-09 14:31:18 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:31:19 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:31:19 --> Utf8 Class Initialized
INFO - 2020-02-09 14:31:19 --> URI Class Initialized
INFO - 2020-02-09 14:31:19 --> Router Class Initialized
INFO - 2020-02-09 14:31:19 --> Output Class Initialized
INFO - 2020-02-09 14:31:19 --> Security Class Initialized
DEBUG - 2020-02-09 14:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:31:19 --> Input Class Initialized
INFO - 2020-02-09 14:31:19 --> Language Class Initialized
INFO - 2020-02-09 14:31:19 --> Language Class Initialized
INFO - 2020-02-09 14:31:19 --> Config Class Initialized
INFO - 2020-02-09 14:31:19 --> Loader Class Initialized
INFO - 2020-02-09 14:31:19 --> Helper loaded: url_helper
INFO - 2020-02-09 14:31:19 --> Helper loaded: file_helper
INFO - 2020-02-09 14:31:19 --> Helper loaded: form_helper
INFO - 2020-02-09 14:31:19 --> Helper loaded: my_helper
INFO - 2020-02-09 14:31:19 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:31:19 --> Controller Class Initialized
INFO - 2020-02-09 14:31:19 --> Config Class Initialized
INFO - 2020-02-09 14:31:19 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:31:19 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:31:19 --> Utf8 Class Initialized
INFO - 2020-02-09 14:31:19 --> URI Class Initialized
INFO - 2020-02-09 14:31:19 --> Router Class Initialized
INFO - 2020-02-09 14:31:19 --> Output Class Initialized
INFO - 2020-02-09 14:31:19 --> Security Class Initialized
DEBUG - 2020-02-09 14:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:31:19 --> Input Class Initialized
INFO - 2020-02-09 14:31:19 --> Language Class Initialized
INFO - 2020-02-09 14:31:19 --> Language Class Initialized
INFO - 2020-02-09 14:31:19 --> Config Class Initialized
INFO - 2020-02-09 14:31:19 --> Loader Class Initialized
INFO - 2020-02-09 14:31:19 --> Helper loaded: url_helper
INFO - 2020-02-09 14:31:19 --> Helper loaded: file_helper
INFO - 2020-02-09 14:31:19 --> Helper loaded: form_helper
INFO - 2020-02-09 14:31:19 --> Helper loaded: my_helper
INFO - 2020-02-09 14:31:20 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:31:20 --> Controller Class Initialized
DEBUG - 2020-02-09 14:31:20 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 14:31:20 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 14:31:20 --> Final output sent to browser
DEBUG - 2020-02-09 14:31:20 --> Total execution time: 0.6284
INFO - 2020-02-09 14:31:27 --> Config Class Initialized
INFO - 2020-02-09 14:31:27 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:31:27 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:31:27 --> Utf8 Class Initialized
INFO - 2020-02-09 14:31:27 --> URI Class Initialized
INFO - 2020-02-09 14:31:27 --> Router Class Initialized
INFO - 2020-02-09 14:31:27 --> Output Class Initialized
INFO - 2020-02-09 14:31:27 --> Security Class Initialized
DEBUG - 2020-02-09 14:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:31:27 --> Input Class Initialized
INFO - 2020-02-09 14:31:27 --> Language Class Initialized
INFO - 2020-02-09 14:31:27 --> Language Class Initialized
INFO - 2020-02-09 14:31:27 --> Config Class Initialized
INFO - 2020-02-09 14:31:27 --> Loader Class Initialized
INFO - 2020-02-09 14:31:27 --> Helper loaded: url_helper
INFO - 2020-02-09 14:31:27 --> Helper loaded: file_helper
INFO - 2020-02-09 14:31:27 --> Helper loaded: form_helper
INFO - 2020-02-09 14:31:27 --> Helper loaded: my_helper
INFO - 2020-02-09 14:31:27 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:31:27 --> Controller Class Initialized
INFO - 2020-02-09 14:31:27 --> Helper loaded: cookie_helper
INFO - 2020-02-09 14:31:27 --> Final output sent to browser
DEBUG - 2020-02-09 14:31:27 --> Total execution time: 0.6231
INFO - 2020-02-09 14:31:27 --> Config Class Initialized
INFO - 2020-02-09 14:31:27 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:31:27 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:31:27 --> Utf8 Class Initialized
INFO - 2020-02-09 14:31:27 --> URI Class Initialized
INFO - 2020-02-09 14:31:27 --> Router Class Initialized
INFO - 2020-02-09 14:31:27 --> Output Class Initialized
INFO - 2020-02-09 14:31:27 --> Security Class Initialized
DEBUG - 2020-02-09 14:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:31:28 --> Input Class Initialized
INFO - 2020-02-09 14:31:28 --> Language Class Initialized
INFO - 2020-02-09 14:31:28 --> Language Class Initialized
INFO - 2020-02-09 14:31:28 --> Config Class Initialized
INFO - 2020-02-09 14:31:28 --> Loader Class Initialized
INFO - 2020-02-09 14:31:28 --> Helper loaded: url_helper
INFO - 2020-02-09 14:31:28 --> Helper loaded: file_helper
INFO - 2020-02-09 14:31:28 --> Helper loaded: form_helper
INFO - 2020-02-09 14:31:28 --> Helper loaded: my_helper
INFO - 2020-02-09 14:31:28 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:31:28 --> Controller Class Initialized
DEBUG - 2020-02-09 14:31:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-09 14:31:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 14:31:28 --> Final output sent to browser
DEBUG - 2020-02-09 14:31:28 --> Total execution time: 0.7960
INFO - 2020-02-09 14:31:30 --> Config Class Initialized
INFO - 2020-02-09 14:31:30 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:31:31 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:31:31 --> Utf8 Class Initialized
INFO - 2020-02-09 14:31:31 --> URI Class Initialized
INFO - 2020-02-09 14:31:31 --> Router Class Initialized
INFO - 2020-02-09 14:31:31 --> Output Class Initialized
INFO - 2020-02-09 14:31:31 --> Security Class Initialized
DEBUG - 2020-02-09 14:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:31:31 --> Input Class Initialized
INFO - 2020-02-09 14:31:31 --> Language Class Initialized
INFO - 2020-02-09 14:31:31 --> Language Class Initialized
INFO - 2020-02-09 14:31:31 --> Config Class Initialized
INFO - 2020-02-09 14:31:31 --> Loader Class Initialized
INFO - 2020-02-09 14:31:31 --> Helper loaded: url_helper
INFO - 2020-02-09 14:31:31 --> Helper loaded: file_helper
INFO - 2020-02-09 14:31:31 --> Helper loaded: form_helper
INFO - 2020-02-09 14:31:31 --> Helper loaded: my_helper
INFO - 2020-02-09 14:31:31 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:31:31 --> Controller Class Initialized
DEBUG - 2020-02-09 14:31:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-09 14:31:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 14:31:31 --> Final output sent to browser
DEBUG - 2020-02-09 14:31:31 --> Total execution time: 0.7289
INFO - 2020-02-09 14:31:31 --> Config Class Initialized
INFO - 2020-02-09 14:31:31 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:31:31 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:31:32 --> Utf8 Class Initialized
INFO - 2020-02-09 14:31:32 --> URI Class Initialized
INFO - 2020-02-09 14:31:32 --> Router Class Initialized
INFO - 2020-02-09 14:31:32 --> Output Class Initialized
INFO - 2020-02-09 14:31:32 --> Security Class Initialized
DEBUG - 2020-02-09 14:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:31:32 --> Input Class Initialized
INFO - 2020-02-09 14:31:32 --> Language Class Initialized
INFO - 2020-02-09 14:31:32 --> Language Class Initialized
INFO - 2020-02-09 14:31:32 --> Config Class Initialized
INFO - 2020-02-09 14:31:32 --> Loader Class Initialized
INFO - 2020-02-09 14:31:32 --> Helper loaded: url_helper
INFO - 2020-02-09 14:31:32 --> Helper loaded: file_helper
INFO - 2020-02-09 14:31:32 --> Helper loaded: form_helper
INFO - 2020-02-09 14:31:32 --> Helper loaded: my_helper
INFO - 2020-02-09 14:31:32 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:31:32 --> Controller Class Initialized
INFO - 2020-02-09 14:31:34 --> Config Class Initialized
INFO - 2020-02-09 14:31:34 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:31:34 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:31:34 --> Utf8 Class Initialized
INFO - 2020-02-09 14:31:34 --> URI Class Initialized
INFO - 2020-02-09 14:31:34 --> Router Class Initialized
INFO - 2020-02-09 14:31:34 --> Output Class Initialized
INFO - 2020-02-09 14:31:34 --> Security Class Initialized
DEBUG - 2020-02-09 14:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:31:34 --> Input Class Initialized
INFO - 2020-02-09 14:31:34 --> Language Class Initialized
INFO - 2020-02-09 14:31:34 --> Language Class Initialized
INFO - 2020-02-09 14:31:34 --> Config Class Initialized
INFO - 2020-02-09 14:31:34 --> Loader Class Initialized
INFO - 2020-02-09 14:31:34 --> Helper loaded: url_helper
INFO - 2020-02-09 14:31:34 --> Helper loaded: file_helper
INFO - 2020-02-09 14:31:34 --> Helper loaded: form_helper
INFO - 2020-02-09 14:31:34 --> Helper loaded: my_helper
INFO - 2020-02-09 14:31:34 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:31:34 --> Controller Class Initialized
INFO - 2020-02-09 14:31:34 --> Final output sent to browser
DEBUG - 2020-02-09 14:31:34 --> Total execution time: 0.5771
INFO - 2020-02-09 14:31:35 --> Config Class Initialized
INFO - 2020-02-09 14:31:35 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:31:35 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:31:35 --> Utf8 Class Initialized
INFO - 2020-02-09 14:31:35 --> URI Class Initialized
INFO - 2020-02-09 14:31:35 --> Router Class Initialized
INFO - 2020-02-09 14:31:35 --> Output Class Initialized
INFO - 2020-02-09 14:31:35 --> Security Class Initialized
DEBUG - 2020-02-09 14:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:31:35 --> Input Class Initialized
INFO - 2020-02-09 14:31:35 --> Language Class Initialized
INFO - 2020-02-09 14:31:35 --> Language Class Initialized
INFO - 2020-02-09 14:31:35 --> Config Class Initialized
INFO - 2020-02-09 14:31:35 --> Loader Class Initialized
INFO - 2020-02-09 14:31:35 --> Helper loaded: url_helper
INFO - 2020-02-09 14:31:35 --> Helper loaded: file_helper
INFO - 2020-02-09 14:31:35 --> Helper loaded: form_helper
INFO - 2020-02-09 14:31:35 --> Helper loaded: my_helper
INFO - 2020-02-09 14:31:35 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:31:35 --> Controller Class Initialized
INFO - 2020-02-09 14:31:37 --> Config Class Initialized
INFO - 2020-02-09 14:31:37 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:31:37 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:31:37 --> Utf8 Class Initialized
INFO - 2020-02-09 14:31:37 --> URI Class Initialized
DEBUG - 2020-02-09 14:31:37 --> No URI present. Default controller set.
INFO - 2020-02-09 14:31:37 --> Router Class Initialized
INFO - 2020-02-09 14:31:37 --> Output Class Initialized
INFO - 2020-02-09 14:31:37 --> Security Class Initialized
DEBUG - 2020-02-09 14:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:31:37 --> Input Class Initialized
INFO - 2020-02-09 14:31:37 --> Language Class Initialized
INFO - 2020-02-09 14:31:37 --> Language Class Initialized
INFO - 2020-02-09 14:31:37 --> Config Class Initialized
INFO - 2020-02-09 14:31:37 --> Loader Class Initialized
INFO - 2020-02-09 14:31:37 --> Helper loaded: url_helper
INFO - 2020-02-09 14:31:37 --> Helper loaded: file_helper
INFO - 2020-02-09 14:31:37 --> Helper loaded: form_helper
INFO - 2020-02-09 14:31:37 --> Helper loaded: my_helper
INFO - 2020-02-09 14:31:37 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:31:37 --> Controller Class Initialized
DEBUG - 2020-02-09 14:31:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-09 14:31:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 14:31:37 --> Final output sent to browser
DEBUG - 2020-02-09 14:31:37 --> Total execution time: 0.6794
INFO - 2020-02-09 14:31:47 --> Config Class Initialized
INFO - 2020-02-09 14:31:47 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:31:47 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:31:47 --> Utf8 Class Initialized
INFO - 2020-02-09 14:31:47 --> URI Class Initialized
INFO - 2020-02-09 14:31:47 --> Router Class Initialized
INFO - 2020-02-09 14:31:47 --> Output Class Initialized
INFO - 2020-02-09 14:31:47 --> Security Class Initialized
DEBUG - 2020-02-09 14:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:31:47 --> Input Class Initialized
INFO - 2020-02-09 14:31:47 --> Language Class Initialized
INFO - 2020-02-09 14:31:47 --> Language Class Initialized
INFO - 2020-02-09 14:31:47 --> Config Class Initialized
INFO - 2020-02-09 14:31:48 --> Loader Class Initialized
INFO - 2020-02-09 14:31:48 --> Helper loaded: url_helper
INFO - 2020-02-09 14:31:48 --> Helper loaded: file_helper
INFO - 2020-02-09 14:31:48 --> Helper loaded: form_helper
INFO - 2020-02-09 14:31:48 --> Helper loaded: my_helper
INFO - 2020-02-09 14:31:48 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:31:48 --> Controller Class Initialized
INFO - 2020-02-09 14:31:48 --> Helper loaded: cookie_helper
INFO - 2020-02-09 14:31:48 --> Config Class Initialized
INFO - 2020-02-09 14:31:48 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:31:48 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:31:48 --> Utf8 Class Initialized
INFO - 2020-02-09 14:31:48 --> URI Class Initialized
INFO - 2020-02-09 14:31:48 --> Router Class Initialized
INFO - 2020-02-09 14:31:48 --> Output Class Initialized
INFO - 2020-02-09 14:31:48 --> Security Class Initialized
DEBUG - 2020-02-09 14:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:31:48 --> Input Class Initialized
INFO - 2020-02-09 14:31:48 --> Language Class Initialized
INFO - 2020-02-09 14:31:48 --> Language Class Initialized
INFO - 2020-02-09 14:31:48 --> Config Class Initialized
INFO - 2020-02-09 14:31:48 --> Loader Class Initialized
INFO - 2020-02-09 14:31:48 --> Helper loaded: url_helper
INFO - 2020-02-09 14:31:48 --> Helper loaded: file_helper
INFO - 2020-02-09 14:31:48 --> Helper loaded: form_helper
INFO - 2020-02-09 14:31:48 --> Helper loaded: my_helper
INFO - 2020-02-09 14:31:48 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:31:48 --> Controller Class Initialized
INFO - 2020-02-09 14:31:48 --> Config Class Initialized
INFO - 2020-02-09 14:31:48 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:31:48 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:31:48 --> Utf8 Class Initialized
INFO - 2020-02-09 14:31:49 --> URI Class Initialized
INFO - 2020-02-09 14:31:49 --> Router Class Initialized
INFO - 2020-02-09 14:31:49 --> Output Class Initialized
INFO - 2020-02-09 14:31:49 --> Security Class Initialized
DEBUG - 2020-02-09 14:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:31:49 --> Input Class Initialized
INFO - 2020-02-09 14:31:49 --> Language Class Initialized
INFO - 2020-02-09 14:31:49 --> Language Class Initialized
INFO - 2020-02-09 14:31:49 --> Config Class Initialized
INFO - 2020-02-09 14:31:49 --> Loader Class Initialized
INFO - 2020-02-09 14:31:49 --> Helper loaded: url_helper
INFO - 2020-02-09 14:31:49 --> Helper loaded: file_helper
INFO - 2020-02-09 14:31:49 --> Helper loaded: form_helper
INFO - 2020-02-09 14:31:49 --> Helper loaded: my_helper
INFO - 2020-02-09 14:31:49 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:31:49 --> Controller Class Initialized
DEBUG - 2020-02-09 14:31:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 14:31:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 14:31:49 --> Final output sent to browser
DEBUG - 2020-02-09 14:31:49 --> Total execution time: 0.6649
INFO - 2020-02-09 14:32:00 --> Config Class Initialized
INFO - 2020-02-09 14:32:00 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:32:00 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:32:01 --> Utf8 Class Initialized
INFO - 2020-02-09 14:32:01 --> URI Class Initialized
INFO - 2020-02-09 14:32:01 --> Router Class Initialized
INFO - 2020-02-09 14:32:01 --> Output Class Initialized
INFO - 2020-02-09 14:32:01 --> Security Class Initialized
DEBUG - 2020-02-09 14:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:32:01 --> Input Class Initialized
INFO - 2020-02-09 14:32:01 --> Language Class Initialized
INFO - 2020-02-09 14:32:01 --> Language Class Initialized
INFO - 2020-02-09 14:32:01 --> Config Class Initialized
INFO - 2020-02-09 14:32:01 --> Loader Class Initialized
INFO - 2020-02-09 14:32:01 --> Helper loaded: url_helper
INFO - 2020-02-09 14:32:01 --> Helper loaded: file_helper
INFO - 2020-02-09 14:32:01 --> Helper loaded: form_helper
INFO - 2020-02-09 14:32:01 --> Helper loaded: my_helper
INFO - 2020-02-09 14:32:01 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:32:01 --> Controller Class Initialized
INFO - 2020-02-09 14:32:01 --> Helper loaded: cookie_helper
INFO - 2020-02-09 14:32:01 --> Final output sent to browser
DEBUG - 2020-02-09 14:32:01 --> Total execution time: 0.6973
INFO - 2020-02-09 14:32:01 --> Config Class Initialized
INFO - 2020-02-09 14:32:01 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:32:01 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:32:01 --> Utf8 Class Initialized
INFO - 2020-02-09 14:32:01 --> URI Class Initialized
INFO - 2020-02-09 14:32:01 --> Router Class Initialized
INFO - 2020-02-09 14:32:01 --> Output Class Initialized
INFO - 2020-02-09 14:32:01 --> Security Class Initialized
DEBUG - 2020-02-09 14:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:32:02 --> Input Class Initialized
INFO - 2020-02-09 14:32:02 --> Language Class Initialized
INFO - 2020-02-09 14:32:02 --> Language Class Initialized
INFO - 2020-02-09 14:32:02 --> Config Class Initialized
INFO - 2020-02-09 14:32:02 --> Loader Class Initialized
INFO - 2020-02-09 14:32:02 --> Helper loaded: url_helper
INFO - 2020-02-09 14:32:02 --> Helper loaded: file_helper
INFO - 2020-02-09 14:32:02 --> Helper loaded: form_helper
INFO - 2020-02-09 14:32:02 --> Helper loaded: my_helper
INFO - 2020-02-09 14:32:02 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:32:02 --> Controller Class Initialized
DEBUG - 2020-02-09 14:32:02 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-09 14:32:02 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 14:32:02 --> Final output sent to browser
DEBUG - 2020-02-09 14:32:02 --> Total execution time: 0.7996
INFO - 2020-02-09 14:32:19 --> Config Class Initialized
INFO - 2020-02-09 14:32:19 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:32:19 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:32:19 --> Utf8 Class Initialized
INFO - 2020-02-09 14:32:19 --> URI Class Initialized
INFO - 2020-02-09 14:32:19 --> Router Class Initialized
INFO - 2020-02-09 14:32:19 --> Output Class Initialized
INFO - 2020-02-09 14:32:19 --> Security Class Initialized
DEBUG - 2020-02-09 14:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:32:19 --> Input Class Initialized
INFO - 2020-02-09 14:32:19 --> Language Class Initialized
INFO - 2020-02-09 14:32:19 --> Language Class Initialized
INFO - 2020-02-09 14:32:19 --> Config Class Initialized
INFO - 2020-02-09 14:32:19 --> Loader Class Initialized
INFO - 2020-02-09 14:32:19 --> Helper loaded: url_helper
INFO - 2020-02-09 14:32:19 --> Helper loaded: file_helper
INFO - 2020-02-09 14:32:19 --> Helper loaded: form_helper
INFO - 2020-02-09 14:32:19 --> Helper loaded: my_helper
INFO - 2020-02-09 14:32:19 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:32:19 --> Controller Class Initialized
DEBUG - 2020-02-09 14:32:19 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-02-09 14:32:19 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 14:32:19 --> Final output sent to browser
DEBUG - 2020-02-09 14:32:19 --> Total execution time: 0.7227
INFO - 2020-02-09 14:32:20 --> Config Class Initialized
INFO - 2020-02-09 14:32:20 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:32:20 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:32:20 --> Utf8 Class Initialized
INFO - 2020-02-09 14:32:20 --> URI Class Initialized
INFO - 2020-02-09 14:32:20 --> Router Class Initialized
INFO - 2020-02-09 14:32:20 --> Output Class Initialized
INFO - 2020-02-09 14:32:20 --> Security Class Initialized
DEBUG - 2020-02-09 14:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:32:20 --> Input Class Initialized
INFO - 2020-02-09 14:32:20 --> Language Class Initialized
INFO - 2020-02-09 14:32:20 --> Language Class Initialized
INFO - 2020-02-09 14:32:20 --> Config Class Initialized
INFO - 2020-02-09 14:32:20 --> Loader Class Initialized
INFO - 2020-02-09 14:32:20 --> Helper loaded: url_helper
INFO - 2020-02-09 14:32:21 --> Helper loaded: file_helper
INFO - 2020-02-09 14:32:21 --> Helper loaded: form_helper
INFO - 2020-02-09 14:32:21 --> Helper loaded: my_helper
INFO - 2020-02-09 14:32:21 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:32:21 --> Controller Class Initialized
DEBUG - 2020-02-09 14:32:21 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-02-09 14:32:21 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 14:32:21 --> Final output sent to browser
DEBUG - 2020-02-09 14:32:21 --> Total execution time: 0.6874
INFO - 2020-02-09 14:32:22 --> Config Class Initialized
INFO - 2020-02-09 14:32:22 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:32:22 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:32:22 --> Utf8 Class Initialized
INFO - 2020-02-09 14:32:22 --> URI Class Initialized
INFO - 2020-02-09 14:32:22 --> Router Class Initialized
INFO - 2020-02-09 14:32:22 --> Output Class Initialized
INFO - 2020-02-09 14:32:22 --> Security Class Initialized
DEBUG - 2020-02-09 14:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:32:22 --> Input Class Initialized
INFO - 2020-02-09 14:32:22 --> Language Class Initialized
INFO - 2020-02-09 14:32:22 --> Language Class Initialized
INFO - 2020-02-09 14:32:22 --> Config Class Initialized
INFO - 2020-02-09 14:32:22 --> Loader Class Initialized
INFO - 2020-02-09 14:32:22 --> Helper loaded: url_helper
INFO - 2020-02-09 14:32:23 --> Helper loaded: file_helper
INFO - 2020-02-09 14:32:23 --> Helper loaded: form_helper
INFO - 2020-02-09 14:32:23 --> Helper loaded: my_helper
INFO - 2020-02-09 14:32:23 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:32:23 --> Controller Class Initialized
DEBUG - 2020-02-09 14:32:23 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-02-09 14:32:23 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 14:32:23 --> Final output sent to browser
DEBUG - 2020-02-09 14:32:23 --> Total execution time: 0.8143
INFO - 2020-02-09 14:32:28 --> Config Class Initialized
INFO - 2020-02-09 14:32:28 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:32:28 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:32:28 --> Utf8 Class Initialized
INFO - 2020-02-09 14:32:29 --> URI Class Initialized
INFO - 2020-02-09 14:32:29 --> Router Class Initialized
INFO - 2020-02-09 14:32:29 --> Output Class Initialized
INFO - 2020-02-09 14:32:29 --> Security Class Initialized
DEBUG - 2020-02-09 14:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:32:29 --> Input Class Initialized
INFO - 2020-02-09 14:32:29 --> Language Class Initialized
INFO - 2020-02-09 14:32:29 --> Language Class Initialized
INFO - 2020-02-09 14:32:29 --> Config Class Initialized
INFO - 2020-02-09 14:32:29 --> Loader Class Initialized
INFO - 2020-02-09 14:32:29 --> Helper loaded: url_helper
INFO - 2020-02-09 14:32:29 --> Helper loaded: file_helper
INFO - 2020-02-09 14:32:29 --> Helper loaded: form_helper
INFO - 2020-02-09 14:32:29 --> Helper loaded: my_helper
INFO - 2020-02-09 14:32:29 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:32:29 --> Controller Class Initialized
DEBUG - 2020-02-09 14:32:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/list.php
DEBUG - 2020-02-09 14:32:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 14:32:29 --> Final output sent to browser
DEBUG - 2020-02-09 14:32:29 --> Total execution time: 0.7186
INFO - 2020-02-09 14:32:31 --> Config Class Initialized
INFO - 2020-02-09 14:32:31 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:32:31 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:32:31 --> Utf8 Class Initialized
INFO - 2020-02-09 14:32:31 --> URI Class Initialized
INFO - 2020-02-09 14:32:31 --> Router Class Initialized
INFO - 2020-02-09 14:32:31 --> Output Class Initialized
INFO - 2020-02-09 14:32:31 --> Security Class Initialized
DEBUG - 2020-02-09 14:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:32:31 --> Input Class Initialized
INFO - 2020-02-09 14:32:31 --> Language Class Initialized
INFO - 2020-02-09 14:32:31 --> Language Class Initialized
INFO - 2020-02-09 14:32:31 --> Config Class Initialized
INFO - 2020-02-09 14:32:32 --> Loader Class Initialized
INFO - 2020-02-09 14:32:32 --> Helper loaded: url_helper
INFO - 2020-02-09 14:32:32 --> Helper loaded: file_helper
INFO - 2020-02-09 14:32:32 --> Helper loaded: form_helper
INFO - 2020-02-09 14:32:32 --> Helper loaded: my_helper
INFO - 2020-02-09 14:32:32 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:32:32 --> Controller Class Initialized
DEBUG - 2020-02-09 14:32:32 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-02-09 14:32:32 --> Final output sent to browser
DEBUG - 2020-02-09 14:32:32 --> Total execution time: 0.8567
INFO - 2020-02-09 14:32:46 --> Config Class Initialized
INFO - 2020-02-09 14:32:46 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:32:46 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:32:46 --> Utf8 Class Initialized
INFO - 2020-02-09 14:32:46 --> URI Class Initialized
DEBUG - 2020-02-09 14:32:46 --> No URI present. Default controller set.
INFO - 2020-02-09 14:32:46 --> Router Class Initialized
INFO - 2020-02-09 14:32:46 --> Output Class Initialized
INFO - 2020-02-09 14:32:46 --> Security Class Initialized
DEBUG - 2020-02-09 14:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:32:46 --> Input Class Initialized
INFO - 2020-02-09 14:32:46 --> Language Class Initialized
INFO - 2020-02-09 14:32:46 --> Language Class Initialized
INFO - 2020-02-09 14:32:46 --> Config Class Initialized
INFO - 2020-02-09 14:32:46 --> Loader Class Initialized
INFO - 2020-02-09 14:32:46 --> Helper loaded: url_helper
INFO - 2020-02-09 14:32:46 --> Helper loaded: file_helper
INFO - 2020-02-09 14:32:46 --> Helper loaded: form_helper
INFO - 2020-02-09 14:32:46 --> Helper loaded: my_helper
INFO - 2020-02-09 14:32:46 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:32:47 --> Controller Class Initialized
DEBUG - 2020-02-09 14:32:47 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-09 14:32:47 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 14:32:47 --> Final output sent to browser
DEBUG - 2020-02-09 14:32:47 --> Total execution time: 0.6858
INFO - 2020-02-09 14:34:23 --> Config Class Initialized
INFO - 2020-02-09 14:34:23 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:34:23 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:34:23 --> Utf8 Class Initialized
INFO - 2020-02-09 14:34:23 --> URI Class Initialized
INFO - 2020-02-09 14:34:24 --> Router Class Initialized
INFO - 2020-02-09 14:34:24 --> Output Class Initialized
INFO - 2020-02-09 14:34:24 --> Security Class Initialized
DEBUG - 2020-02-09 14:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:34:24 --> Input Class Initialized
INFO - 2020-02-09 14:34:24 --> Language Class Initialized
INFO - 2020-02-09 14:34:24 --> Language Class Initialized
INFO - 2020-02-09 14:34:24 --> Config Class Initialized
INFO - 2020-02-09 14:34:24 --> Loader Class Initialized
INFO - 2020-02-09 14:34:24 --> Helper loaded: url_helper
INFO - 2020-02-09 14:34:24 --> Helper loaded: file_helper
INFO - 2020-02-09 14:34:24 --> Helper loaded: form_helper
INFO - 2020-02-09 14:34:24 --> Helper loaded: my_helper
INFO - 2020-02-09 14:34:24 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:34:24 --> Controller Class Initialized
INFO - 2020-02-09 14:34:24 --> Helper loaded: cookie_helper
INFO - 2020-02-09 14:34:24 --> Config Class Initialized
INFO - 2020-02-09 14:34:24 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:34:24 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:34:24 --> Utf8 Class Initialized
INFO - 2020-02-09 14:34:24 --> URI Class Initialized
INFO - 2020-02-09 14:34:24 --> Router Class Initialized
INFO - 2020-02-09 14:34:24 --> Output Class Initialized
INFO - 2020-02-09 14:34:24 --> Security Class Initialized
DEBUG - 2020-02-09 14:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:34:24 --> Input Class Initialized
INFO - 2020-02-09 14:34:24 --> Language Class Initialized
INFO - 2020-02-09 14:34:24 --> Language Class Initialized
INFO - 2020-02-09 14:34:24 --> Config Class Initialized
INFO - 2020-02-09 14:34:24 --> Loader Class Initialized
INFO - 2020-02-09 14:34:24 --> Helper loaded: url_helper
INFO - 2020-02-09 14:34:24 --> Helper loaded: file_helper
INFO - 2020-02-09 14:34:25 --> Helper loaded: form_helper
INFO - 2020-02-09 14:34:25 --> Helper loaded: my_helper
INFO - 2020-02-09 14:34:25 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:34:25 --> Controller Class Initialized
INFO - 2020-02-09 14:34:25 --> Config Class Initialized
INFO - 2020-02-09 14:34:25 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:34:25 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:34:25 --> Utf8 Class Initialized
INFO - 2020-02-09 14:34:25 --> URI Class Initialized
INFO - 2020-02-09 14:34:25 --> Router Class Initialized
INFO - 2020-02-09 14:34:25 --> Output Class Initialized
INFO - 2020-02-09 14:34:25 --> Security Class Initialized
DEBUG - 2020-02-09 14:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:34:25 --> Input Class Initialized
INFO - 2020-02-09 14:34:25 --> Language Class Initialized
INFO - 2020-02-09 14:34:25 --> Language Class Initialized
INFO - 2020-02-09 14:34:25 --> Config Class Initialized
INFO - 2020-02-09 14:34:25 --> Loader Class Initialized
INFO - 2020-02-09 14:34:25 --> Helper loaded: url_helper
INFO - 2020-02-09 14:34:25 --> Helper loaded: file_helper
INFO - 2020-02-09 14:34:25 --> Helper loaded: form_helper
INFO - 2020-02-09 14:34:25 --> Helper loaded: my_helper
INFO - 2020-02-09 14:34:25 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:34:26 --> Controller Class Initialized
DEBUG - 2020-02-09 14:34:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 14:34:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 14:34:26 --> Final output sent to browser
DEBUG - 2020-02-09 14:34:26 --> Total execution time: 0.9446
INFO - 2020-02-09 14:34:36 --> Config Class Initialized
INFO - 2020-02-09 14:34:36 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:34:36 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:34:36 --> Utf8 Class Initialized
INFO - 2020-02-09 14:34:36 --> URI Class Initialized
INFO - 2020-02-09 14:34:36 --> Router Class Initialized
INFO - 2020-02-09 14:34:36 --> Output Class Initialized
INFO - 2020-02-09 14:34:36 --> Security Class Initialized
DEBUG - 2020-02-09 14:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:34:36 --> Input Class Initialized
INFO - 2020-02-09 14:34:36 --> Language Class Initialized
INFO - 2020-02-09 14:34:36 --> Language Class Initialized
INFO - 2020-02-09 14:34:36 --> Config Class Initialized
INFO - 2020-02-09 14:34:36 --> Loader Class Initialized
INFO - 2020-02-09 14:34:36 --> Helper loaded: url_helper
INFO - 2020-02-09 14:34:36 --> Helper loaded: file_helper
INFO - 2020-02-09 14:34:36 --> Helper loaded: form_helper
INFO - 2020-02-09 14:34:36 --> Helper loaded: my_helper
INFO - 2020-02-09 14:34:37 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:34:37 --> Controller Class Initialized
INFO - 2020-02-09 14:34:37 --> Helper loaded: cookie_helper
INFO - 2020-02-09 14:34:37 --> Final output sent to browser
DEBUG - 2020-02-09 14:34:37 --> Total execution time: 0.6421
INFO - 2020-02-09 14:34:37 --> Config Class Initialized
INFO - 2020-02-09 14:34:37 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:34:37 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:34:37 --> Utf8 Class Initialized
INFO - 2020-02-09 14:34:37 --> URI Class Initialized
INFO - 2020-02-09 14:34:37 --> Router Class Initialized
INFO - 2020-02-09 14:34:37 --> Output Class Initialized
INFO - 2020-02-09 14:34:37 --> Security Class Initialized
DEBUG - 2020-02-09 14:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:34:37 --> Input Class Initialized
INFO - 2020-02-09 14:34:37 --> Language Class Initialized
INFO - 2020-02-09 14:34:37 --> Language Class Initialized
INFO - 2020-02-09 14:34:37 --> Config Class Initialized
INFO - 2020-02-09 14:34:37 --> Loader Class Initialized
INFO - 2020-02-09 14:34:37 --> Helper loaded: url_helper
INFO - 2020-02-09 14:34:37 --> Helper loaded: file_helper
INFO - 2020-02-09 14:34:37 --> Helper loaded: form_helper
INFO - 2020-02-09 14:34:37 --> Helper loaded: my_helper
INFO - 2020-02-09 14:34:37 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:34:37 --> Controller Class Initialized
DEBUG - 2020-02-09 14:34:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-09 14:34:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 14:34:37 --> Final output sent to browser
DEBUG - 2020-02-09 14:34:38 --> Total execution time: 0.7343
INFO - 2020-02-09 14:37:52 --> Config Class Initialized
INFO - 2020-02-09 14:37:52 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:37:52 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:37:52 --> Utf8 Class Initialized
INFO - 2020-02-09 14:37:52 --> URI Class Initialized
INFO - 2020-02-09 14:37:53 --> Router Class Initialized
INFO - 2020-02-09 14:37:53 --> Output Class Initialized
INFO - 2020-02-09 14:37:53 --> Security Class Initialized
DEBUG - 2020-02-09 14:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:37:53 --> Input Class Initialized
INFO - 2020-02-09 14:37:53 --> Language Class Initialized
INFO - 2020-02-09 14:37:53 --> Language Class Initialized
INFO - 2020-02-09 14:37:53 --> Config Class Initialized
INFO - 2020-02-09 14:37:53 --> Loader Class Initialized
INFO - 2020-02-09 14:37:53 --> Helper loaded: url_helper
INFO - 2020-02-09 14:37:53 --> Helper loaded: file_helper
INFO - 2020-02-09 14:37:53 --> Helper loaded: form_helper
INFO - 2020-02-09 14:37:53 --> Helper loaded: my_helper
INFO - 2020-02-09 14:37:53 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:37:53 --> Controller Class Initialized
INFO - 2020-02-09 14:37:53 --> Helper loaded: cookie_helper
INFO - 2020-02-09 14:37:53 --> Config Class Initialized
INFO - 2020-02-09 14:37:53 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:37:53 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:37:53 --> Utf8 Class Initialized
INFO - 2020-02-09 14:37:53 --> URI Class Initialized
INFO - 2020-02-09 14:37:53 --> Router Class Initialized
INFO - 2020-02-09 14:37:53 --> Output Class Initialized
INFO - 2020-02-09 14:37:53 --> Security Class Initialized
DEBUG - 2020-02-09 14:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:37:53 --> Input Class Initialized
INFO - 2020-02-09 14:37:53 --> Language Class Initialized
INFO - 2020-02-09 14:37:53 --> Language Class Initialized
INFO - 2020-02-09 14:37:53 --> Config Class Initialized
INFO - 2020-02-09 14:37:53 --> Loader Class Initialized
INFO - 2020-02-09 14:37:53 --> Helper loaded: url_helper
INFO - 2020-02-09 14:37:53 --> Helper loaded: file_helper
INFO - 2020-02-09 14:37:53 --> Helper loaded: form_helper
INFO - 2020-02-09 14:37:53 --> Helper loaded: my_helper
INFO - 2020-02-09 14:37:54 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:37:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:37:54 --> Controller Class Initialized
INFO - 2020-02-09 14:37:54 --> Config Class Initialized
INFO - 2020-02-09 14:37:54 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:37:54 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:37:54 --> Utf8 Class Initialized
INFO - 2020-02-09 14:37:54 --> URI Class Initialized
INFO - 2020-02-09 14:37:54 --> Router Class Initialized
INFO - 2020-02-09 14:37:54 --> Output Class Initialized
INFO - 2020-02-09 14:37:54 --> Security Class Initialized
DEBUG - 2020-02-09 14:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:37:54 --> Input Class Initialized
INFO - 2020-02-09 14:37:54 --> Language Class Initialized
INFO - 2020-02-09 14:37:54 --> Language Class Initialized
INFO - 2020-02-09 14:37:54 --> Config Class Initialized
INFO - 2020-02-09 14:37:54 --> Loader Class Initialized
INFO - 2020-02-09 14:37:54 --> Helper loaded: url_helper
INFO - 2020-02-09 14:37:54 --> Helper loaded: file_helper
INFO - 2020-02-09 14:37:54 --> Helper loaded: form_helper
INFO - 2020-02-09 14:37:54 --> Helper loaded: my_helper
INFO - 2020-02-09 14:37:54 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:37:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:37:54 --> Controller Class Initialized
DEBUG - 2020-02-09 14:37:54 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 14:37:54 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 14:37:54 --> Final output sent to browser
DEBUG - 2020-02-09 14:37:54 --> Total execution time: 0.6370
INFO - 2020-02-09 14:38:03 --> Config Class Initialized
INFO - 2020-02-09 14:38:03 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:38:03 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:38:03 --> Utf8 Class Initialized
INFO - 2020-02-09 14:38:03 --> URI Class Initialized
INFO - 2020-02-09 14:38:03 --> Router Class Initialized
INFO - 2020-02-09 14:38:03 --> Output Class Initialized
INFO - 2020-02-09 14:38:03 --> Security Class Initialized
DEBUG - 2020-02-09 14:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:38:03 --> Input Class Initialized
INFO - 2020-02-09 14:38:03 --> Language Class Initialized
INFO - 2020-02-09 14:38:03 --> Language Class Initialized
INFO - 2020-02-09 14:38:03 --> Config Class Initialized
INFO - 2020-02-09 14:38:03 --> Loader Class Initialized
INFO - 2020-02-09 14:38:03 --> Helper loaded: url_helper
INFO - 2020-02-09 14:38:03 --> Helper loaded: file_helper
INFO - 2020-02-09 14:38:03 --> Helper loaded: form_helper
INFO - 2020-02-09 14:38:03 --> Helper loaded: my_helper
INFO - 2020-02-09 14:38:03 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:38:03 --> Controller Class Initialized
INFO - 2020-02-09 14:38:03 --> Helper loaded: cookie_helper
INFO - 2020-02-09 14:38:03 --> Final output sent to browser
DEBUG - 2020-02-09 14:38:03 --> Total execution time: 0.7357
INFO - 2020-02-09 14:38:03 --> Config Class Initialized
INFO - 2020-02-09 14:38:03 --> Hooks Class Initialized
DEBUG - 2020-02-09 14:38:03 --> UTF-8 Support Enabled
INFO - 2020-02-09 14:38:04 --> Utf8 Class Initialized
INFO - 2020-02-09 14:38:04 --> URI Class Initialized
INFO - 2020-02-09 14:38:04 --> Router Class Initialized
INFO - 2020-02-09 14:38:04 --> Output Class Initialized
INFO - 2020-02-09 14:38:04 --> Security Class Initialized
DEBUG - 2020-02-09 14:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 14:38:04 --> Input Class Initialized
INFO - 2020-02-09 14:38:04 --> Language Class Initialized
INFO - 2020-02-09 14:38:04 --> Language Class Initialized
INFO - 2020-02-09 14:38:04 --> Config Class Initialized
INFO - 2020-02-09 14:38:04 --> Loader Class Initialized
INFO - 2020-02-09 14:38:04 --> Helper loaded: url_helper
INFO - 2020-02-09 14:38:04 --> Helper loaded: file_helper
INFO - 2020-02-09 14:38:04 --> Helper loaded: form_helper
INFO - 2020-02-09 14:38:04 --> Helper loaded: my_helper
INFO - 2020-02-09 14:38:04 --> Database Driver Class Initialized
DEBUG - 2020-02-09 14:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 14:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 14:38:04 --> Controller Class Initialized
DEBUG - 2020-02-09 14:38:04 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-09 14:38:04 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 14:38:04 --> Final output sent to browser
DEBUG - 2020-02-09 14:38:04 --> Total execution time: 0.8531
INFO - 2020-02-09 15:01:48 --> Config Class Initialized
INFO - 2020-02-09 15:01:48 --> Hooks Class Initialized
DEBUG - 2020-02-09 15:01:48 --> UTF-8 Support Enabled
INFO - 2020-02-09 15:01:48 --> Utf8 Class Initialized
INFO - 2020-02-09 15:01:48 --> URI Class Initialized
INFO - 2020-02-09 15:01:48 --> Router Class Initialized
INFO - 2020-02-09 15:01:48 --> Output Class Initialized
INFO - 2020-02-09 15:01:48 --> Security Class Initialized
DEBUG - 2020-02-09 15:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 15:01:49 --> Input Class Initialized
INFO - 2020-02-09 15:01:49 --> Language Class Initialized
INFO - 2020-02-09 15:01:49 --> Language Class Initialized
INFO - 2020-02-09 15:01:49 --> Config Class Initialized
INFO - 2020-02-09 15:01:49 --> Loader Class Initialized
INFO - 2020-02-09 15:01:49 --> Helper loaded: url_helper
INFO - 2020-02-09 15:01:49 --> Helper loaded: file_helper
INFO - 2020-02-09 15:01:49 --> Helper loaded: form_helper
INFO - 2020-02-09 15:01:49 --> Helper loaded: my_helper
INFO - 2020-02-09 15:01:49 --> Database Driver Class Initialized
DEBUG - 2020-02-09 15:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 15:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 15:01:49 --> Controller Class Initialized
INFO - 2020-02-09 15:01:49 --> Helper loaded: cookie_helper
INFO - 2020-02-09 15:01:49 --> Config Class Initialized
INFO - 2020-02-09 15:01:49 --> Hooks Class Initialized
DEBUG - 2020-02-09 15:01:49 --> UTF-8 Support Enabled
INFO - 2020-02-09 15:01:49 --> Utf8 Class Initialized
INFO - 2020-02-09 15:01:49 --> URI Class Initialized
INFO - 2020-02-09 15:01:49 --> Router Class Initialized
INFO - 2020-02-09 15:01:49 --> Output Class Initialized
INFO - 2020-02-09 15:01:49 --> Security Class Initialized
DEBUG - 2020-02-09 15:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 15:01:49 --> Input Class Initialized
INFO - 2020-02-09 15:01:49 --> Language Class Initialized
INFO - 2020-02-09 15:01:49 --> Language Class Initialized
INFO - 2020-02-09 15:01:50 --> Config Class Initialized
INFO - 2020-02-09 15:01:50 --> Loader Class Initialized
INFO - 2020-02-09 15:01:50 --> Helper loaded: url_helper
INFO - 2020-02-09 15:01:50 --> Helper loaded: file_helper
INFO - 2020-02-09 15:01:50 --> Helper loaded: form_helper
INFO - 2020-02-09 15:01:50 --> Helper loaded: my_helper
INFO - 2020-02-09 15:01:50 --> Database Driver Class Initialized
DEBUG - 2020-02-09 15:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 15:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 15:01:50 --> Controller Class Initialized
INFO - 2020-02-09 15:01:50 --> Config Class Initialized
INFO - 2020-02-09 15:01:50 --> Hooks Class Initialized
DEBUG - 2020-02-09 15:01:50 --> UTF-8 Support Enabled
INFO - 2020-02-09 15:01:50 --> Utf8 Class Initialized
INFO - 2020-02-09 15:01:50 --> URI Class Initialized
INFO - 2020-02-09 15:01:50 --> Router Class Initialized
INFO - 2020-02-09 15:01:50 --> Output Class Initialized
INFO - 2020-02-09 15:01:50 --> Security Class Initialized
DEBUG - 2020-02-09 15:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 15:01:50 --> Input Class Initialized
INFO - 2020-02-09 15:01:50 --> Language Class Initialized
INFO - 2020-02-09 15:01:50 --> Language Class Initialized
INFO - 2020-02-09 15:01:50 --> Config Class Initialized
INFO - 2020-02-09 15:01:51 --> Loader Class Initialized
INFO - 2020-02-09 15:01:51 --> Helper loaded: url_helper
INFO - 2020-02-09 15:01:51 --> Helper loaded: file_helper
INFO - 2020-02-09 15:01:51 --> Helper loaded: form_helper
INFO - 2020-02-09 15:01:51 --> Helper loaded: my_helper
INFO - 2020-02-09 15:01:51 --> Database Driver Class Initialized
DEBUG - 2020-02-09 15:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 15:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 15:01:51 --> Controller Class Initialized
DEBUG - 2020-02-09 15:01:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-09 15:01:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-09 15:01:51 --> Final output sent to browser
DEBUG - 2020-02-09 15:01:51 --> Total execution time: 1.0071
