<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-24 07:32:20 --> Config Class Initialized
INFO - 2024-08-24 07:32:20 --> Hooks Class Initialized
DEBUG - 2024-08-24 07:32:20 --> UTF-8 Support Enabled
INFO - 2024-08-24 07:32:20 --> Utf8 Class Initialized
INFO - 2024-08-24 07:32:20 --> URI Class Initialized
INFO - 2024-08-24 07:32:20 --> Router Class Initialized
INFO - 2024-08-24 07:32:20 --> Output Class Initialized
INFO - 2024-08-24 07:32:20 --> Security Class Initialized
DEBUG - 2024-08-24 07:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-24 07:32:20 --> Input Class Initialized
INFO - 2024-08-24 07:32:20 --> Language Class Initialized
INFO - 2024-08-24 07:32:20 --> Language Class Initialized
INFO - 2024-08-24 07:32:20 --> Config Class Initialized
INFO - 2024-08-24 07:32:20 --> Loader Class Initialized
INFO - 2024-08-24 07:32:20 --> Helper loaded: url_helper
INFO - 2024-08-24 07:32:20 --> Helper loaded: file_helper
INFO - 2024-08-24 07:32:20 --> Helper loaded: form_helper
INFO - 2024-08-24 07:32:20 --> Helper loaded: my_helper
INFO - 2024-08-24 07:32:20 --> Database Driver Class Initialized
INFO - 2024-08-24 07:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-24 07:32:20 --> Controller Class Initialized
INFO - 2024-08-24 07:32:20 --> Helper loaded: cookie_helper
INFO - 2024-08-24 07:32:20 --> Final output sent to browser
DEBUG - 2024-08-24 07:32:20 --> Total execution time: 0.0609
INFO - 2024-08-24 07:32:20 --> Config Class Initialized
INFO - 2024-08-24 07:32:20 --> Hooks Class Initialized
DEBUG - 2024-08-24 07:32:20 --> UTF-8 Support Enabled
INFO - 2024-08-24 07:32:20 --> Utf8 Class Initialized
INFO - 2024-08-24 07:32:20 --> URI Class Initialized
INFO - 2024-08-24 07:32:20 --> Router Class Initialized
INFO - 2024-08-24 07:32:20 --> Output Class Initialized
INFO - 2024-08-24 07:32:20 --> Security Class Initialized
DEBUG - 2024-08-24 07:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-24 07:32:20 --> Input Class Initialized
INFO - 2024-08-24 07:32:20 --> Language Class Initialized
INFO - 2024-08-24 07:32:20 --> Language Class Initialized
INFO - 2024-08-24 07:32:20 --> Config Class Initialized
INFO - 2024-08-24 07:32:20 --> Loader Class Initialized
INFO - 2024-08-24 07:32:20 --> Helper loaded: url_helper
INFO - 2024-08-24 07:32:20 --> Helper loaded: file_helper
INFO - 2024-08-24 07:32:20 --> Helper loaded: form_helper
INFO - 2024-08-24 07:32:20 --> Helper loaded: my_helper
INFO - 2024-08-24 07:32:20 --> Database Driver Class Initialized
INFO - 2024-08-24 07:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-24 07:32:20 --> Controller Class Initialized
INFO - 2024-08-24 07:32:20 --> Helper loaded: cookie_helper
INFO - 2024-08-24 07:32:20 --> Config Class Initialized
INFO - 2024-08-24 07:32:20 --> Hooks Class Initialized
DEBUG - 2024-08-24 07:32:20 --> UTF-8 Support Enabled
INFO - 2024-08-24 07:32:20 --> Utf8 Class Initialized
INFO - 2024-08-24 07:32:20 --> URI Class Initialized
INFO - 2024-08-24 07:32:20 --> Router Class Initialized
INFO - 2024-08-24 07:32:20 --> Output Class Initialized
INFO - 2024-08-24 07:32:20 --> Security Class Initialized
DEBUG - 2024-08-24 07:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-24 07:32:20 --> Input Class Initialized
INFO - 2024-08-24 07:32:20 --> Language Class Initialized
INFO - 2024-08-24 07:32:20 --> Language Class Initialized
INFO - 2024-08-24 07:32:20 --> Config Class Initialized
INFO - 2024-08-24 07:32:20 --> Loader Class Initialized
INFO - 2024-08-24 07:32:20 --> Helper loaded: url_helper
INFO - 2024-08-24 07:32:20 --> Helper loaded: file_helper
INFO - 2024-08-24 07:32:20 --> Helper loaded: form_helper
INFO - 2024-08-24 07:32:20 --> Helper loaded: my_helper
INFO - 2024-08-24 07:32:20 --> Database Driver Class Initialized
INFO - 2024-08-24 07:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-24 07:32:20 --> Controller Class Initialized
DEBUG - 2024-08-24 07:32:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-24 07:32:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-24 07:32:20 --> Final output sent to browser
DEBUG - 2024-08-24 07:32:20 --> Total execution time: 0.0709
INFO - 2024-08-24 07:32:32 --> Config Class Initialized
INFO - 2024-08-24 07:32:32 --> Hooks Class Initialized
DEBUG - 2024-08-24 07:32:32 --> UTF-8 Support Enabled
INFO - 2024-08-24 07:32:32 --> Utf8 Class Initialized
INFO - 2024-08-24 07:32:32 --> URI Class Initialized
INFO - 2024-08-24 07:32:32 --> Router Class Initialized
INFO - 2024-08-24 07:32:32 --> Output Class Initialized
INFO - 2024-08-24 07:32:32 --> Security Class Initialized
DEBUG - 2024-08-24 07:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-24 07:32:32 --> Input Class Initialized
INFO - 2024-08-24 07:32:32 --> Language Class Initialized
INFO - 2024-08-24 07:32:32 --> Language Class Initialized
INFO - 2024-08-24 07:32:32 --> Config Class Initialized
INFO - 2024-08-24 07:32:32 --> Loader Class Initialized
INFO - 2024-08-24 07:32:32 --> Helper loaded: url_helper
INFO - 2024-08-24 07:32:32 --> Helper loaded: file_helper
INFO - 2024-08-24 07:32:32 --> Helper loaded: form_helper
INFO - 2024-08-24 07:32:32 --> Helper loaded: my_helper
INFO - 2024-08-24 07:32:32 --> Database Driver Class Initialized
INFO - 2024-08-24 07:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-24 07:32:32 --> Controller Class Initialized
DEBUG - 2024-08-24 07:32:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-24 07:32:34 --> Config Class Initialized
INFO - 2024-08-24 07:32:34 --> Hooks Class Initialized
DEBUG - 2024-08-24 07:32:34 --> UTF-8 Support Enabled
INFO - 2024-08-24 07:32:34 --> Utf8 Class Initialized
INFO - 2024-08-24 07:32:34 --> URI Class Initialized
INFO - 2024-08-24 07:32:34 --> Router Class Initialized
INFO - 2024-08-24 07:32:34 --> Output Class Initialized
INFO - 2024-08-24 07:32:34 --> Security Class Initialized
DEBUG - 2024-08-24 07:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-24 07:32:34 --> Input Class Initialized
INFO - 2024-08-24 07:32:34 --> Language Class Initialized
INFO - 2024-08-24 07:32:34 --> Language Class Initialized
INFO - 2024-08-24 07:32:34 --> Config Class Initialized
INFO - 2024-08-24 07:32:34 --> Loader Class Initialized
INFO - 2024-08-24 07:32:34 --> Helper loaded: url_helper
INFO - 2024-08-24 07:32:34 --> Helper loaded: file_helper
INFO - 2024-08-24 07:32:34 --> Helper loaded: form_helper
INFO - 2024-08-24 07:32:34 --> Helper loaded: my_helper
INFO - 2024-08-24 07:32:34 --> Database Driver Class Initialized
INFO - 2024-08-24 07:32:35 --> Config Class Initialized
INFO - 2024-08-24 07:32:35 --> Hooks Class Initialized
DEBUG - 2024-08-24 07:32:35 --> UTF-8 Support Enabled
INFO - 2024-08-24 07:32:35 --> Utf8 Class Initialized
INFO - 2024-08-24 07:32:35 --> URI Class Initialized
INFO - 2024-08-24 07:32:35 --> Router Class Initialized
INFO - 2024-08-24 07:32:35 --> Output Class Initialized
INFO - 2024-08-24 07:32:35 --> Security Class Initialized
DEBUG - 2024-08-24 07:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-24 07:32:35 --> Input Class Initialized
INFO - 2024-08-24 07:32:35 --> Language Class Initialized
INFO - 2024-08-24 07:32:35 --> Language Class Initialized
INFO - 2024-08-24 07:32:35 --> Config Class Initialized
INFO - 2024-08-24 07:32:35 --> Loader Class Initialized
INFO - 2024-08-24 07:32:35 --> Helper loaded: url_helper
INFO - 2024-08-24 07:32:35 --> Helper loaded: file_helper
INFO - 2024-08-24 07:32:35 --> Helper loaded: form_helper
INFO - 2024-08-24 07:32:35 --> Helper loaded: my_helper
INFO - 2024-08-24 07:32:35 --> Database Driver Class Initialized
INFO - 2024-08-24 07:32:36 --> Config Class Initialized
INFO - 2024-08-24 07:32:36 --> Hooks Class Initialized
DEBUG - 2024-08-24 07:32:36 --> UTF-8 Support Enabled
INFO - 2024-08-24 07:32:36 --> Utf8 Class Initialized
INFO - 2024-08-24 07:32:36 --> URI Class Initialized
INFO - 2024-08-24 07:32:36 --> Router Class Initialized
INFO - 2024-08-24 07:32:36 --> Output Class Initialized
INFO - 2024-08-24 07:32:36 --> Security Class Initialized
DEBUG - 2024-08-24 07:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-24 07:32:36 --> Input Class Initialized
INFO - 2024-08-24 07:32:36 --> Language Class Initialized
INFO - 2024-08-24 07:32:36 --> Language Class Initialized
INFO - 2024-08-24 07:32:36 --> Config Class Initialized
INFO - 2024-08-24 07:32:36 --> Loader Class Initialized
INFO - 2024-08-24 07:32:36 --> Helper loaded: url_helper
INFO - 2024-08-24 07:32:36 --> Helper loaded: file_helper
INFO - 2024-08-24 07:32:36 --> Helper loaded: form_helper
INFO - 2024-08-24 07:32:36 --> Helper loaded: my_helper
INFO - 2024-08-24 07:32:36 --> Database Driver Class Initialized
INFO - 2024-08-24 07:32:40 --> Final output sent to browser
DEBUG - 2024-08-24 07:32:40 --> Total execution time: 8.1312
INFO - 2024-08-24 07:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-24 07:32:40 --> Controller Class Initialized
DEBUG - 2024-08-24 07:32:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-24 07:32:45 --> Final output sent to browser
DEBUG - 2024-08-24 07:32:45 --> Total execution time: 10.8819
INFO - 2024-08-24 07:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-24 07:32:45 --> Controller Class Initialized
DEBUG - 2024-08-24 07:32:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-24 07:32:51 --> Final output sent to browser
DEBUG - 2024-08-24 07:32:51 --> Total execution time: 15.9624
INFO - 2024-08-24 07:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-24 07:32:51 --> Controller Class Initialized
DEBUG - 2024-08-24 07:32:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-24 07:32:51 --> Config Class Initialized
INFO - 2024-08-24 07:32:51 --> Hooks Class Initialized
DEBUG - 2024-08-24 07:32:51 --> UTF-8 Support Enabled
INFO - 2024-08-24 07:32:51 --> Utf8 Class Initialized
INFO - 2024-08-24 07:32:51 --> URI Class Initialized
INFO - 2024-08-24 07:32:51 --> Router Class Initialized
INFO - 2024-08-24 07:32:51 --> Output Class Initialized
INFO - 2024-08-24 07:32:51 --> Security Class Initialized
DEBUG - 2024-08-24 07:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-24 07:32:51 --> Input Class Initialized
INFO - 2024-08-24 07:32:51 --> Language Class Initialized
INFO - 2024-08-24 07:32:51 --> Language Class Initialized
INFO - 2024-08-24 07:32:51 --> Config Class Initialized
INFO - 2024-08-24 07:32:51 --> Loader Class Initialized
INFO - 2024-08-24 07:32:51 --> Helper loaded: url_helper
INFO - 2024-08-24 07:32:51 --> Helper loaded: file_helper
INFO - 2024-08-24 07:32:51 --> Helper loaded: form_helper
INFO - 2024-08-24 07:32:51 --> Helper loaded: my_helper
INFO - 2024-08-24 07:32:51 --> Database Driver Class Initialized
INFO - 2024-08-24 07:32:56 --> Final output sent to browser
DEBUG - 2024-08-24 07:32:56 --> Total execution time: 20.1320
INFO - 2024-08-24 07:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-24 07:32:56 --> Controller Class Initialized
INFO - 2024-08-24 07:32:56 --> Config Class Initialized
INFO - 2024-08-24 07:32:56 --> Hooks Class Initialized
DEBUG - 2024-08-24 07:32:56 --> UTF-8 Support Enabled
INFO - 2024-08-24 07:32:56 --> Utf8 Class Initialized
INFO - 2024-08-24 07:32:56 --> URI Class Initialized
INFO - 2024-08-24 07:32:56 --> Router Class Initialized
INFO - 2024-08-24 07:32:56 --> Output Class Initialized
INFO - 2024-08-24 07:32:56 --> Security Class Initialized
DEBUG - 2024-08-24 07:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-24 07:32:56 --> Input Class Initialized
INFO - 2024-08-24 07:32:56 --> Language Class Initialized
INFO - 2024-08-24 07:32:56 --> Language Class Initialized
INFO - 2024-08-24 07:32:56 --> Config Class Initialized
INFO - 2024-08-24 07:32:56 --> Loader Class Initialized
INFO - 2024-08-24 07:32:56 --> Helper loaded: url_helper
INFO - 2024-08-24 07:32:56 --> Helper loaded: file_helper
INFO - 2024-08-24 07:32:56 --> Helper loaded: form_helper
INFO - 2024-08-24 07:32:56 --> Helper loaded: my_helper
INFO - 2024-08-24 07:32:56 --> Database Driver Class Initialized
DEBUG - 2024-08-24 07:32:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-08-24 07:32:58 --> Final output sent to browser
DEBUG - 2024-08-24 07:32:58 --> Total execution time: 6.9438
INFO - 2024-08-24 07:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-24 07:32:58 --> Controller Class Initialized
DEBUG - 2024-08-24 07:32:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-24 07:32:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-24 07:32:58 --> Final output sent to browser
DEBUG - 2024-08-24 07:32:58 --> Total execution time: 2.1348
INFO - 2024-08-24 07:32:59 --> Config Class Initialized
INFO - 2024-08-24 07:32:59 --> Hooks Class Initialized
DEBUG - 2024-08-24 07:32:59 --> UTF-8 Support Enabled
INFO - 2024-08-24 07:32:59 --> Utf8 Class Initialized
INFO - 2024-08-24 07:32:59 --> URI Class Initialized
INFO - 2024-08-24 07:32:59 --> Router Class Initialized
INFO - 2024-08-24 07:32:59 --> Output Class Initialized
INFO - 2024-08-24 07:32:59 --> Security Class Initialized
DEBUG - 2024-08-24 07:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-24 07:32:59 --> Input Class Initialized
INFO - 2024-08-24 07:32:59 --> Language Class Initialized
INFO - 2024-08-24 07:32:59 --> Language Class Initialized
INFO - 2024-08-24 07:32:59 --> Config Class Initialized
INFO - 2024-08-24 07:32:59 --> Loader Class Initialized
INFO - 2024-08-24 07:32:59 --> Helper loaded: url_helper
INFO - 2024-08-24 07:32:59 --> Helper loaded: file_helper
INFO - 2024-08-24 07:32:59 --> Helper loaded: form_helper
INFO - 2024-08-24 07:32:59 --> Helper loaded: my_helper
INFO - 2024-08-24 07:32:59 --> Database Driver Class Initialized
INFO - 2024-08-24 07:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-24 07:32:59 --> Controller Class Initialized
INFO - 2024-08-24 07:33:00 --> Helper loaded: cookie_helper
INFO - 2024-08-24 07:33:00 --> Final output sent to browser
DEBUG - 2024-08-24 07:33:00 --> Total execution time: 0.2366
INFO - 2024-08-24 07:33:00 --> Config Class Initialized
INFO - 2024-08-24 07:33:00 --> Hooks Class Initialized
DEBUG - 2024-08-24 07:33:00 --> UTF-8 Support Enabled
INFO - 2024-08-24 07:33:00 --> Utf8 Class Initialized
INFO - 2024-08-24 07:33:00 --> URI Class Initialized
INFO - 2024-08-24 07:33:00 --> Router Class Initialized
INFO - 2024-08-24 07:33:00 --> Output Class Initialized
INFO - 2024-08-24 07:33:00 --> Security Class Initialized
DEBUG - 2024-08-24 07:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-24 07:33:00 --> Input Class Initialized
INFO - 2024-08-24 07:33:00 --> Language Class Initialized
INFO - 2024-08-24 07:33:00 --> Language Class Initialized
INFO - 2024-08-24 07:33:00 --> Config Class Initialized
INFO - 2024-08-24 07:33:00 --> Loader Class Initialized
INFO - 2024-08-24 07:33:00 --> Helper loaded: url_helper
INFO - 2024-08-24 07:33:00 --> Helper loaded: file_helper
INFO - 2024-08-24 07:33:00 --> Helper loaded: form_helper
INFO - 2024-08-24 07:33:00 --> Helper loaded: my_helper
INFO - 2024-08-24 07:33:00 --> Database Driver Class Initialized
INFO - 2024-08-24 07:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-24 07:33:00 --> Controller Class Initialized
INFO - 2024-08-24 07:33:00 --> Helper loaded: cookie_helper
INFO - 2024-08-24 07:33:00 --> Config Class Initialized
INFO - 2024-08-24 07:33:00 --> Hooks Class Initialized
DEBUG - 2024-08-24 07:33:00 --> UTF-8 Support Enabled
INFO - 2024-08-24 07:33:00 --> Utf8 Class Initialized
INFO - 2024-08-24 07:33:00 --> URI Class Initialized
INFO - 2024-08-24 07:33:00 --> Router Class Initialized
INFO - 2024-08-24 07:33:00 --> Output Class Initialized
INFO - 2024-08-24 07:33:00 --> Security Class Initialized
DEBUG - 2024-08-24 07:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-24 07:33:00 --> Input Class Initialized
INFO - 2024-08-24 07:33:00 --> Language Class Initialized
INFO - 2024-08-24 07:33:00 --> Language Class Initialized
INFO - 2024-08-24 07:33:00 --> Config Class Initialized
INFO - 2024-08-24 07:33:00 --> Loader Class Initialized
INFO - 2024-08-24 07:33:00 --> Helper loaded: url_helper
INFO - 2024-08-24 07:33:00 --> Helper loaded: file_helper
INFO - 2024-08-24 07:33:00 --> Helper loaded: form_helper
INFO - 2024-08-24 07:33:00 --> Helper loaded: my_helper
INFO - 2024-08-24 07:33:00 --> Database Driver Class Initialized
INFO - 2024-08-24 07:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-24 07:33:00 --> Controller Class Initialized
DEBUG - 2024-08-24 07:33:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-24 07:33:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-24 07:33:00 --> Final output sent to browser
DEBUG - 2024-08-24 07:33:00 --> Total execution time: 0.0361
INFO - 2024-08-24 07:33:03 --> Config Class Initialized
INFO - 2024-08-24 07:33:03 --> Hooks Class Initialized
DEBUG - 2024-08-24 07:33:03 --> UTF-8 Support Enabled
INFO - 2024-08-24 07:33:03 --> Utf8 Class Initialized
INFO - 2024-08-24 07:33:03 --> URI Class Initialized
INFO - 2024-08-24 07:33:03 --> Router Class Initialized
INFO - 2024-08-24 07:33:03 --> Output Class Initialized
INFO - 2024-08-24 07:33:03 --> Security Class Initialized
DEBUG - 2024-08-24 07:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-24 07:33:03 --> Input Class Initialized
INFO - 2024-08-24 07:33:03 --> Language Class Initialized
INFO - 2024-08-24 07:33:03 --> Language Class Initialized
INFO - 2024-08-24 07:33:03 --> Config Class Initialized
INFO - 2024-08-24 07:33:03 --> Loader Class Initialized
INFO - 2024-08-24 07:33:03 --> Helper loaded: url_helper
INFO - 2024-08-24 07:33:03 --> Helper loaded: file_helper
INFO - 2024-08-24 07:33:03 --> Helper loaded: form_helper
INFO - 2024-08-24 07:33:03 --> Helper loaded: my_helper
INFO - 2024-08-24 07:33:03 --> Database Driver Class Initialized
INFO - 2024-08-24 07:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-24 07:33:03 --> Controller Class Initialized
DEBUG - 2024-08-24 07:33:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-24 07:33:04 --> Config Class Initialized
INFO - 2024-08-24 07:33:04 --> Hooks Class Initialized
DEBUG - 2024-08-24 07:33:04 --> UTF-8 Support Enabled
INFO - 2024-08-24 07:33:04 --> Utf8 Class Initialized
INFO - 2024-08-24 07:33:04 --> URI Class Initialized
INFO - 2024-08-24 07:33:04 --> Router Class Initialized
INFO - 2024-08-24 07:33:04 --> Output Class Initialized
INFO - 2024-08-24 07:33:04 --> Security Class Initialized
DEBUG - 2024-08-24 07:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-24 07:33:04 --> Input Class Initialized
INFO - 2024-08-24 07:33:04 --> Language Class Initialized
INFO - 2024-08-24 07:33:04 --> Language Class Initialized
INFO - 2024-08-24 07:33:04 --> Config Class Initialized
INFO - 2024-08-24 07:33:04 --> Loader Class Initialized
INFO - 2024-08-24 07:33:04 --> Helper loaded: url_helper
INFO - 2024-08-24 07:33:04 --> Helper loaded: file_helper
INFO - 2024-08-24 07:33:04 --> Helper loaded: form_helper
INFO - 2024-08-24 07:33:04 --> Helper loaded: my_helper
INFO - 2024-08-24 07:33:04 --> Database Driver Class Initialized
INFO - 2024-08-24 07:33:07 --> Config Class Initialized
INFO - 2024-08-24 07:33:07 --> Hooks Class Initialized
DEBUG - 2024-08-24 07:33:07 --> UTF-8 Support Enabled
INFO - 2024-08-24 07:33:07 --> Utf8 Class Initialized
INFO - 2024-08-24 07:33:07 --> URI Class Initialized
INFO - 2024-08-24 07:33:07 --> Router Class Initialized
INFO - 2024-08-24 07:33:07 --> Output Class Initialized
INFO - 2024-08-24 07:33:07 --> Security Class Initialized
DEBUG - 2024-08-24 07:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-24 07:33:07 --> Input Class Initialized
INFO - 2024-08-24 07:33:07 --> Language Class Initialized
INFO - 2024-08-24 07:33:07 --> Language Class Initialized
INFO - 2024-08-24 07:33:07 --> Config Class Initialized
INFO - 2024-08-24 07:33:07 --> Loader Class Initialized
INFO - 2024-08-24 07:33:07 --> Helper loaded: url_helper
INFO - 2024-08-24 07:33:07 --> Helper loaded: file_helper
INFO - 2024-08-24 07:33:07 --> Helper loaded: form_helper
INFO - 2024-08-24 07:33:07 --> Helper loaded: my_helper
INFO - 2024-08-24 07:33:07 --> Database Driver Class Initialized
INFO - 2024-08-24 07:33:08 --> Final output sent to browser
DEBUG - 2024-08-24 07:33:08 --> Total execution time: 5.0220
INFO - 2024-08-24 07:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-24 07:33:08 --> Controller Class Initialized
DEBUG - 2024-08-24 07:33:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-24 07:33:14 --> Final output sent to browser
DEBUG - 2024-08-24 07:33:14 --> Total execution time: 9.3274
INFO - 2024-08-24 07:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-24 07:33:14 --> Controller Class Initialized
DEBUG - 2024-08-24 07:33:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-24 07:33:19 --> Final output sent to browser
DEBUG - 2024-08-24 07:33:19 --> Total execution time: 12.1792
INFO - 2024-08-24 09:06:28 --> Config Class Initialized
INFO - 2024-08-24 09:06:28 --> Hooks Class Initialized
DEBUG - 2024-08-24 09:06:28 --> UTF-8 Support Enabled
INFO - 2024-08-24 09:06:28 --> Utf8 Class Initialized
INFO - 2024-08-24 09:06:28 --> URI Class Initialized
INFO - 2024-08-24 09:06:28 --> Router Class Initialized
INFO - 2024-08-24 09:06:28 --> Output Class Initialized
INFO - 2024-08-24 09:06:28 --> Security Class Initialized
DEBUG - 2024-08-24 09:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-24 09:06:28 --> Input Class Initialized
INFO - 2024-08-24 09:06:28 --> Language Class Initialized
INFO - 2024-08-24 09:06:28 --> Language Class Initialized
INFO - 2024-08-24 09:06:28 --> Config Class Initialized
INFO - 2024-08-24 09:06:28 --> Loader Class Initialized
INFO - 2024-08-24 09:06:28 --> Helper loaded: url_helper
INFO - 2024-08-24 09:06:28 --> Helper loaded: file_helper
INFO - 2024-08-24 09:06:28 --> Helper loaded: form_helper
INFO - 2024-08-24 09:06:28 --> Helper loaded: my_helper
INFO - 2024-08-24 09:06:28 --> Database Driver Class Initialized
INFO - 2024-08-24 09:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-24 09:06:28 --> Controller Class Initialized
INFO - 2024-08-24 09:06:29 --> Helper loaded: cookie_helper
INFO - 2024-08-24 09:06:29 --> Final output sent to browser
DEBUG - 2024-08-24 09:06:29 --> Total execution time: 0.0589
INFO - 2024-08-24 09:06:29 --> Config Class Initialized
INFO - 2024-08-24 09:06:29 --> Hooks Class Initialized
DEBUG - 2024-08-24 09:06:29 --> UTF-8 Support Enabled
INFO - 2024-08-24 09:06:29 --> Utf8 Class Initialized
INFO - 2024-08-24 09:06:29 --> URI Class Initialized
INFO - 2024-08-24 09:06:29 --> Router Class Initialized
INFO - 2024-08-24 09:06:29 --> Output Class Initialized
INFO - 2024-08-24 09:06:29 --> Security Class Initialized
DEBUG - 2024-08-24 09:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-24 09:06:29 --> Input Class Initialized
INFO - 2024-08-24 09:06:29 --> Language Class Initialized
INFO - 2024-08-24 09:06:29 --> Language Class Initialized
INFO - 2024-08-24 09:06:29 --> Config Class Initialized
INFO - 2024-08-24 09:06:29 --> Loader Class Initialized
INFO - 2024-08-24 09:06:29 --> Helper loaded: url_helper
INFO - 2024-08-24 09:06:29 --> Helper loaded: file_helper
INFO - 2024-08-24 09:06:29 --> Helper loaded: form_helper
INFO - 2024-08-24 09:06:29 --> Helper loaded: my_helper
INFO - 2024-08-24 09:06:29 --> Database Driver Class Initialized
INFO - 2024-08-24 09:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-24 09:06:29 --> Controller Class Initialized
INFO - 2024-08-24 09:06:29 --> Helper loaded: cookie_helper
INFO - 2024-08-24 09:06:29 --> Config Class Initialized
INFO - 2024-08-24 09:06:29 --> Hooks Class Initialized
DEBUG - 2024-08-24 09:06:29 --> UTF-8 Support Enabled
INFO - 2024-08-24 09:06:29 --> Utf8 Class Initialized
INFO - 2024-08-24 09:06:29 --> URI Class Initialized
INFO - 2024-08-24 09:06:29 --> Router Class Initialized
INFO - 2024-08-24 09:06:29 --> Output Class Initialized
INFO - 2024-08-24 09:06:29 --> Security Class Initialized
DEBUG - 2024-08-24 09:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-24 09:06:29 --> Input Class Initialized
INFO - 2024-08-24 09:06:29 --> Language Class Initialized
INFO - 2024-08-24 09:06:29 --> Language Class Initialized
INFO - 2024-08-24 09:06:29 --> Config Class Initialized
INFO - 2024-08-24 09:06:29 --> Loader Class Initialized
INFO - 2024-08-24 09:06:29 --> Helper loaded: url_helper
INFO - 2024-08-24 09:06:29 --> Helper loaded: file_helper
INFO - 2024-08-24 09:06:29 --> Helper loaded: form_helper
INFO - 2024-08-24 09:06:29 --> Helper loaded: my_helper
INFO - 2024-08-24 09:06:29 --> Database Driver Class Initialized
INFO - 2024-08-24 09:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-24 09:06:29 --> Controller Class Initialized
DEBUG - 2024-08-24 09:06:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-24 09:06:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-24 09:06:29 --> Final output sent to browser
DEBUG - 2024-08-24 09:06:29 --> Total execution time: 0.0654
INFO - 2024-08-24 09:06:34 --> Config Class Initialized
INFO - 2024-08-24 09:06:34 --> Hooks Class Initialized
DEBUG - 2024-08-24 09:06:34 --> UTF-8 Support Enabled
INFO - 2024-08-24 09:06:34 --> Utf8 Class Initialized
INFO - 2024-08-24 09:06:34 --> URI Class Initialized
INFO - 2024-08-24 09:06:34 --> Router Class Initialized
INFO - 2024-08-24 09:06:34 --> Output Class Initialized
INFO - 2024-08-24 09:06:34 --> Security Class Initialized
DEBUG - 2024-08-24 09:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-24 09:06:34 --> Input Class Initialized
INFO - 2024-08-24 09:06:34 --> Language Class Initialized
INFO - 2024-08-24 09:06:34 --> Language Class Initialized
INFO - 2024-08-24 09:06:34 --> Config Class Initialized
INFO - 2024-08-24 09:06:34 --> Loader Class Initialized
INFO - 2024-08-24 09:06:34 --> Helper loaded: url_helper
INFO - 2024-08-24 09:06:34 --> Helper loaded: file_helper
INFO - 2024-08-24 09:06:34 --> Helper loaded: form_helper
INFO - 2024-08-24 09:06:34 --> Helper loaded: my_helper
INFO - 2024-08-24 09:06:34 --> Database Driver Class Initialized
INFO - 2024-08-24 09:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-24 09:06:34 --> Controller Class Initialized
ERROR - 2024-08-24 09:06:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-24 09:06:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-24 09:06:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-24 09:06:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-24 09:06:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-24 09:06:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-24 09:06:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-24 09:06:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-24 09:06:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-24 09:06:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-24 09:06:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-24 09:06:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-24 09:06:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-24 09:06:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-24 09:06:35 --> Config Class Initialized
INFO - 2024-08-24 09:06:35 --> Hooks Class Initialized
DEBUG - 2024-08-24 09:06:35 --> UTF-8 Support Enabled
INFO - 2024-08-24 09:06:35 --> Utf8 Class Initialized
INFO - 2024-08-24 09:06:35 --> URI Class Initialized
INFO - 2024-08-24 09:06:35 --> Router Class Initialized
INFO - 2024-08-24 09:06:35 --> Output Class Initialized
INFO - 2024-08-24 09:06:35 --> Security Class Initialized
DEBUG - 2024-08-24 09:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-24 09:06:35 --> Input Class Initialized
INFO - 2024-08-24 09:06:35 --> Language Class Initialized
INFO - 2024-08-24 09:06:35 --> Language Class Initialized
INFO - 2024-08-24 09:06:35 --> Config Class Initialized
INFO - 2024-08-24 09:06:35 --> Loader Class Initialized
INFO - 2024-08-24 09:06:35 --> Helper loaded: url_helper
INFO - 2024-08-24 09:06:35 --> Helper loaded: file_helper
INFO - 2024-08-24 09:06:35 --> Helper loaded: form_helper
INFO - 2024-08-24 09:06:35 --> Helper loaded: my_helper
INFO - 2024-08-24 09:06:35 --> Database Driver Class Initialized
INFO - 2024-08-24 09:06:36 --> Config Class Initialized
INFO - 2024-08-24 09:06:36 --> Hooks Class Initialized
DEBUG - 2024-08-24 09:06:36 --> UTF-8 Support Enabled
INFO - 2024-08-24 09:06:36 --> Utf8 Class Initialized
INFO - 2024-08-24 09:06:36 --> URI Class Initialized
INFO - 2024-08-24 09:06:36 --> Router Class Initialized
INFO - 2024-08-24 09:06:36 --> Output Class Initialized
INFO - 2024-08-24 09:06:36 --> Security Class Initialized
DEBUG - 2024-08-24 09:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-24 09:06:36 --> Input Class Initialized
INFO - 2024-08-24 09:06:36 --> Language Class Initialized
INFO - 2024-08-24 09:06:36 --> Language Class Initialized
INFO - 2024-08-24 09:06:36 --> Config Class Initialized
INFO - 2024-08-24 09:06:36 --> Loader Class Initialized
INFO - 2024-08-24 09:06:36 --> Helper loaded: url_helper
INFO - 2024-08-24 09:06:36 --> Helper loaded: file_helper
INFO - 2024-08-24 09:06:36 --> Helper loaded: form_helper
INFO - 2024-08-24 09:06:36 --> Helper loaded: my_helper
INFO - 2024-08-24 09:06:36 --> Database Driver Class Initialized
INFO - 2024-08-24 09:06:37 --> Final output sent to browser
DEBUG - 2024-08-24 09:06:37 --> Total execution time: 2.9129
INFO - 2024-08-24 09:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-24 09:06:37 --> Controller Class Initialized
ERROR - 2024-08-24 09:06:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-24 09:06:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-24 09:06:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-24 09:06:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-24 09:06:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-24 09:06:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-24 09:06:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-24 09:06:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-24 09:06:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-24 09:06:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-24 09:06:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-24 09:06:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-24 09:06:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-24 09:06:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-24 09:06:40 --> Final output sent to browser
DEBUG - 2024-08-24 09:06:40 --> Total execution time: 4.6529
INFO - 2024-08-24 09:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-24 09:06:40 --> Controller Class Initialized
ERROR - 2024-08-24 09:06:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-08-24 09:06:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-24 09:06:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-24 09:06:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-08-24 09:06:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-24 09:06:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-24 09:06:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-08-24 09:06:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-08-24 09:06:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-24 09:06:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-24 09:06:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-08-24 09:06:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-24 09:06:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-24 09:06:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-08-24 09:06:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-24 09:06:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-24 09:06:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-08-24 09:06:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-08-24 09:06:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-08-24 09:06:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-08-24 09:06:43 --> Final output sent to browser
DEBUG - 2024-08-24 09:06:43 --> Total execution time: 6.9833
INFO - 2024-08-24 20:36:57 --> Config Class Initialized
INFO - 2024-08-24 20:36:57 --> Hooks Class Initialized
DEBUG - 2024-08-24 20:36:57 --> UTF-8 Support Enabled
INFO - 2024-08-24 20:36:57 --> Utf8 Class Initialized
INFO - 2024-08-24 20:36:57 --> URI Class Initialized
INFO - 2024-08-24 20:36:57 --> Router Class Initialized
INFO - 2024-08-24 20:36:57 --> Output Class Initialized
INFO - 2024-08-24 20:36:57 --> Security Class Initialized
DEBUG - 2024-08-24 20:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-24 20:36:57 --> Input Class Initialized
INFO - 2024-08-24 20:36:57 --> Language Class Initialized
INFO - 2024-08-24 20:36:57 --> Language Class Initialized
INFO - 2024-08-24 20:36:57 --> Config Class Initialized
INFO - 2024-08-24 20:36:57 --> Loader Class Initialized
INFO - 2024-08-24 20:36:57 --> Helper loaded: url_helper
INFO - 2024-08-24 20:36:57 --> Helper loaded: file_helper
INFO - 2024-08-24 20:36:57 --> Helper loaded: form_helper
INFO - 2024-08-24 20:36:57 --> Helper loaded: my_helper
INFO - 2024-08-24 20:36:57 --> Database Driver Class Initialized
INFO - 2024-08-24 20:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-24 20:36:57 --> Controller Class Initialized
INFO - 2024-08-24 20:36:57 --> Helper loaded: cookie_helper
INFO - 2024-08-24 20:36:57 --> Final output sent to browser
DEBUG - 2024-08-24 20:36:57 --> Total execution time: 0.0664
INFO - 2024-08-24 20:36:57 --> Config Class Initialized
INFO - 2024-08-24 20:36:57 --> Hooks Class Initialized
DEBUG - 2024-08-24 20:36:57 --> UTF-8 Support Enabled
INFO - 2024-08-24 20:36:57 --> Utf8 Class Initialized
INFO - 2024-08-24 20:36:57 --> URI Class Initialized
INFO - 2024-08-24 20:36:57 --> Router Class Initialized
INFO - 2024-08-24 20:36:57 --> Output Class Initialized
INFO - 2024-08-24 20:36:57 --> Security Class Initialized
DEBUG - 2024-08-24 20:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-24 20:36:57 --> Input Class Initialized
INFO - 2024-08-24 20:36:57 --> Language Class Initialized
INFO - 2024-08-24 20:36:57 --> Language Class Initialized
INFO - 2024-08-24 20:36:57 --> Config Class Initialized
INFO - 2024-08-24 20:36:57 --> Loader Class Initialized
INFO - 2024-08-24 20:36:57 --> Helper loaded: url_helper
INFO - 2024-08-24 20:36:57 --> Helper loaded: file_helper
INFO - 2024-08-24 20:36:57 --> Helper loaded: form_helper
INFO - 2024-08-24 20:36:57 --> Helper loaded: my_helper
INFO - 2024-08-24 20:36:57 --> Database Driver Class Initialized
INFO - 2024-08-24 20:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-24 20:36:57 --> Controller Class Initialized
INFO - 2024-08-24 20:36:57 --> Helper loaded: cookie_helper
INFO - 2024-08-24 20:36:57 --> Config Class Initialized
INFO - 2024-08-24 20:36:57 --> Hooks Class Initialized
DEBUG - 2024-08-24 20:36:57 --> UTF-8 Support Enabled
INFO - 2024-08-24 20:36:57 --> Utf8 Class Initialized
INFO - 2024-08-24 20:36:57 --> URI Class Initialized
INFO - 2024-08-24 20:36:57 --> Router Class Initialized
INFO - 2024-08-24 20:36:57 --> Output Class Initialized
INFO - 2024-08-24 20:36:57 --> Security Class Initialized
DEBUG - 2024-08-24 20:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-24 20:36:57 --> Input Class Initialized
INFO - 2024-08-24 20:36:57 --> Language Class Initialized
INFO - 2024-08-24 20:36:57 --> Language Class Initialized
INFO - 2024-08-24 20:36:57 --> Config Class Initialized
INFO - 2024-08-24 20:36:57 --> Loader Class Initialized
INFO - 2024-08-24 20:36:57 --> Helper loaded: url_helper
INFO - 2024-08-24 20:36:57 --> Helper loaded: file_helper
INFO - 2024-08-24 20:36:57 --> Helper loaded: form_helper
INFO - 2024-08-24 20:36:57 --> Helper loaded: my_helper
INFO - 2024-08-24 20:36:57 --> Database Driver Class Initialized
INFO - 2024-08-24 20:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-24 20:36:57 --> Controller Class Initialized
DEBUG - 2024-08-24 20:36:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-24 20:36:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-24 20:36:57 --> Final output sent to browser
DEBUG - 2024-08-24 20:36:57 --> Total execution time: 0.0345
