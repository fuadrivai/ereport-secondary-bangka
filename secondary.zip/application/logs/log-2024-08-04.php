<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-04 00:27:36 --> Config Class Initialized
INFO - 2024-08-04 00:27:36 --> Hooks Class Initialized
DEBUG - 2024-08-04 00:27:36 --> UTF-8 Support Enabled
INFO - 2024-08-04 00:27:36 --> Utf8 Class Initialized
INFO - 2024-08-04 00:27:36 --> URI Class Initialized
INFO - 2024-08-04 00:27:36 --> Router Class Initialized
INFO - 2024-08-04 00:27:36 --> Output Class Initialized
INFO - 2024-08-04 00:27:36 --> Security Class Initialized
DEBUG - 2024-08-04 00:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-04 00:27:36 --> Input Class Initialized
INFO - 2024-08-04 00:27:36 --> Language Class Initialized
INFO - 2024-08-04 00:27:36 --> Language Class Initialized
INFO - 2024-08-04 00:27:36 --> Config Class Initialized
INFO - 2024-08-04 00:27:36 --> Loader Class Initialized
INFO - 2024-08-04 00:27:36 --> Helper loaded: url_helper
INFO - 2024-08-04 00:27:36 --> Helper loaded: file_helper
INFO - 2024-08-04 00:27:36 --> Helper loaded: form_helper
INFO - 2024-08-04 00:27:36 --> Helper loaded: my_helper
INFO - 2024-08-04 00:27:36 --> Database Driver Class Initialized
INFO - 2024-08-04 00:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-04 00:27:36 --> Controller Class Initialized
INFO - 2024-08-04 00:27:36 --> Helper loaded: cookie_helper
INFO - 2024-08-04 00:27:36 --> Final output sent to browser
DEBUG - 2024-08-04 00:27:36 --> Total execution time: 0.0841
INFO - 2024-08-04 00:27:36 --> Config Class Initialized
INFO - 2024-08-04 00:27:36 --> Hooks Class Initialized
DEBUG - 2024-08-04 00:27:36 --> UTF-8 Support Enabled
INFO - 2024-08-04 00:27:36 --> Utf8 Class Initialized
INFO - 2024-08-04 00:27:36 --> URI Class Initialized
INFO - 2024-08-04 00:27:36 --> Router Class Initialized
INFO - 2024-08-04 00:27:36 --> Output Class Initialized
INFO - 2024-08-04 00:27:36 --> Security Class Initialized
DEBUG - 2024-08-04 00:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-04 00:27:36 --> Input Class Initialized
INFO - 2024-08-04 00:27:36 --> Language Class Initialized
INFO - 2024-08-04 00:27:36 --> Language Class Initialized
INFO - 2024-08-04 00:27:36 --> Config Class Initialized
INFO - 2024-08-04 00:27:36 --> Loader Class Initialized
INFO - 2024-08-04 00:27:36 --> Helper loaded: url_helper
INFO - 2024-08-04 00:27:36 --> Helper loaded: file_helper
INFO - 2024-08-04 00:27:36 --> Helper loaded: form_helper
INFO - 2024-08-04 00:27:36 --> Helper loaded: my_helper
INFO - 2024-08-04 00:27:36 --> Database Driver Class Initialized
INFO - 2024-08-04 00:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-04 00:27:36 --> Controller Class Initialized
INFO - 2024-08-04 00:27:36 --> Helper loaded: cookie_helper
INFO - 2024-08-04 00:27:36 --> Config Class Initialized
INFO - 2024-08-04 00:27:36 --> Hooks Class Initialized
DEBUG - 2024-08-04 00:27:36 --> UTF-8 Support Enabled
INFO - 2024-08-04 00:27:36 --> Utf8 Class Initialized
INFO - 2024-08-04 00:27:36 --> URI Class Initialized
INFO - 2024-08-04 00:27:36 --> Router Class Initialized
INFO - 2024-08-04 00:27:36 --> Output Class Initialized
INFO - 2024-08-04 00:27:36 --> Security Class Initialized
DEBUG - 2024-08-04 00:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-04 00:27:36 --> Input Class Initialized
INFO - 2024-08-04 00:27:36 --> Language Class Initialized
INFO - 2024-08-04 00:27:36 --> Language Class Initialized
INFO - 2024-08-04 00:27:36 --> Config Class Initialized
INFO - 2024-08-04 00:27:36 --> Loader Class Initialized
INFO - 2024-08-04 00:27:36 --> Helper loaded: url_helper
INFO - 2024-08-04 00:27:36 --> Helper loaded: file_helper
INFO - 2024-08-04 00:27:36 --> Helper loaded: form_helper
INFO - 2024-08-04 00:27:36 --> Helper loaded: my_helper
INFO - 2024-08-04 00:27:36 --> Database Driver Class Initialized
INFO - 2024-08-04 00:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-04 00:27:36 --> Controller Class Initialized
DEBUG - 2024-08-04 00:27:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-04 00:27:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-04 00:27:36 --> Final output sent to browser
DEBUG - 2024-08-04 00:27:36 --> Total execution time: 0.0421
INFO - 2024-08-04 21:38:47 --> Config Class Initialized
INFO - 2024-08-04 21:38:47 --> Hooks Class Initialized
DEBUG - 2024-08-04 21:38:47 --> UTF-8 Support Enabled
INFO - 2024-08-04 21:38:47 --> Utf8 Class Initialized
INFO - 2024-08-04 21:38:47 --> URI Class Initialized
INFO - 2024-08-04 21:38:47 --> Router Class Initialized
INFO - 2024-08-04 21:38:47 --> Output Class Initialized
INFO - 2024-08-04 21:38:47 --> Security Class Initialized
DEBUG - 2024-08-04 21:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-04 21:38:47 --> Input Class Initialized
INFO - 2024-08-04 21:38:47 --> Language Class Initialized
INFO - 2024-08-04 21:38:47 --> Language Class Initialized
INFO - 2024-08-04 21:38:47 --> Config Class Initialized
INFO - 2024-08-04 21:38:47 --> Loader Class Initialized
INFO - 2024-08-04 21:38:47 --> Helper loaded: url_helper
INFO - 2024-08-04 21:38:47 --> Helper loaded: file_helper
INFO - 2024-08-04 21:38:47 --> Helper loaded: form_helper
INFO - 2024-08-04 21:38:47 --> Helper loaded: my_helper
INFO - 2024-08-04 21:38:47 --> Database Driver Class Initialized
INFO - 2024-08-04 21:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-04 21:38:47 --> Controller Class Initialized
INFO - 2024-08-04 21:38:47 --> Helper loaded: cookie_helper
INFO - 2024-08-04 21:38:47 --> Final output sent to browser
DEBUG - 2024-08-04 21:38:47 --> Total execution time: 0.0733
INFO - 2024-08-04 21:56:36 --> Config Class Initialized
INFO - 2024-08-04 21:56:36 --> Hooks Class Initialized
DEBUG - 2024-08-04 21:56:36 --> UTF-8 Support Enabled
INFO - 2024-08-04 21:56:36 --> Utf8 Class Initialized
INFO - 2024-08-04 21:56:36 --> URI Class Initialized
INFO - 2024-08-04 21:56:36 --> Router Class Initialized
INFO - 2024-08-04 21:56:36 --> Output Class Initialized
INFO - 2024-08-04 21:56:36 --> Security Class Initialized
DEBUG - 2024-08-04 21:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-04 21:56:36 --> Input Class Initialized
INFO - 2024-08-04 21:56:36 --> Language Class Initialized
INFO - 2024-08-04 21:56:36 --> Language Class Initialized
INFO - 2024-08-04 21:56:36 --> Config Class Initialized
INFO - 2024-08-04 21:56:36 --> Loader Class Initialized
INFO - 2024-08-04 21:56:36 --> Helper loaded: url_helper
INFO - 2024-08-04 21:56:36 --> Helper loaded: file_helper
INFO - 2024-08-04 21:56:36 --> Helper loaded: form_helper
INFO - 2024-08-04 21:56:36 --> Helper loaded: my_helper
INFO - 2024-08-04 21:56:36 --> Database Driver Class Initialized
INFO - 2024-08-04 21:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-04 21:56:36 --> Controller Class Initialized
INFO - 2024-08-04 21:56:36 --> Helper loaded: cookie_helper
INFO - 2024-08-04 21:56:36 --> Final output sent to browser
DEBUG - 2024-08-04 21:56:36 --> Total execution time: 0.0646
INFO - 2024-08-04 21:56:37 --> Config Class Initialized
INFO - 2024-08-04 21:56:37 --> Hooks Class Initialized
DEBUG - 2024-08-04 21:56:37 --> UTF-8 Support Enabled
INFO - 2024-08-04 21:56:37 --> Utf8 Class Initialized
INFO - 2024-08-04 21:56:37 --> URI Class Initialized
INFO - 2024-08-04 21:56:37 --> Router Class Initialized
INFO - 2024-08-04 21:56:37 --> Output Class Initialized
INFO - 2024-08-04 21:56:37 --> Security Class Initialized
DEBUG - 2024-08-04 21:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-04 21:56:37 --> Input Class Initialized
INFO - 2024-08-04 21:56:37 --> Language Class Initialized
INFO - 2024-08-04 21:56:37 --> Language Class Initialized
INFO - 2024-08-04 21:56:37 --> Config Class Initialized
INFO - 2024-08-04 21:56:37 --> Loader Class Initialized
INFO - 2024-08-04 21:56:37 --> Helper loaded: url_helper
INFO - 2024-08-04 21:56:37 --> Helper loaded: file_helper
INFO - 2024-08-04 21:56:37 --> Helper loaded: form_helper
INFO - 2024-08-04 21:56:37 --> Helper loaded: my_helper
INFO - 2024-08-04 21:56:37 --> Database Driver Class Initialized
INFO - 2024-08-04 21:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-04 21:56:37 --> Controller Class Initialized
INFO - 2024-08-04 21:56:37 --> Helper loaded: cookie_helper
INFO - 2024-08-04 21:56:37 --> Config Class Initialized
INFO - 2024-08-04 21:56:37 --> Hooks Class Initialized
DEBUG - 2024-08-04 21:56:37 --> UTF-8 Support Enabled
INFO - 2024-08-04 21:56:37 --> Utf8 Class Initialized
INFO - 2024-08-04 21:56:37 --> URI Class Initialized
INFO - 2024-08-04 21:56:37 --> Router Class Initialized
INFO - 2024-08-04 21:56:37 --> Output Class Initialized
INFO - 2024-08-04 21:56:37 --> Security Class Initialized
DEBUG - 2024-08-04 21:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-04 21:56:37 --> Input Class Initialized
INFO - 2024-08-04 21:56:37 --> Language Class Initialized
INFO - 2024-08-04 21:56:37 --> Language Class Initialized
INFO - 2024-08-04 21:56:37 --> Config Class Initialized
INFO - 2024-08-04 21:56:37 --> Loader Class Initialized
INFO - 2024-08-04 21:56:37 --> Helper loaded: url_helper
INFO - 2024-08-04 21:56:37 --> Helper loaded: file_helper
INFO - 2024-08-04 21:56:37 --> Helper loaded: form_helper
INFO - 2024-08-04 21:56:37 --> Helper loaded: my_helper
INFO - 2024-08-04 21:56:37 --> Database Driver Class Initialized
INFO - 2024-08-04 21:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-04 21:56:37 --> Controller Class Initialized
DEBUG - 2024-08-04 21:56:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-04 21:56:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-04 21:56:37 --> Final output sent to browser
DEBUG - 2024-08-04 21:56:37 --> Total execution time: 0.0367
INFO - 2024-08-04 21:57:41 --> Config Class Initialized
INFO - 2024-08-04 21:57:41 --> Hooks Class Initialized
DEBUG - 2024-08-04 21:57:41 --> UTF-8 Support Enabled
INFO - 2024-08-04 21:57:41 --> Utf8 Class Initialized
INFO - 2024-08-04 21:57:41 --> URI Class Initialized
INFO - 2024-08-04 21:57:41 --> Router Class Initialized
INFO - 2024-08-04 21:57:41 --> Output Class Initialized
INFO - 2024-08-04 21:57:41 --> Security Class Initialized
DEBUG - 2024-08-04 21:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-04 21:57:41 --> Input Class Initialized
INFO - 2024-08-04 21:57:41 --> Language Class Initialized
INFO - 2024-08-04 21:57:41 --> Language Class Initialized
INFO - 2024-08-04 21:57:41 --> Config Class Initialized
INFO - 2024-08-04 21:57:41 --> Loader Class Initialized
INFO - 2024-08-04 21:57:41 --> Helper loaded: url_helper
INFO - 2024-08-04 21:57:41 --> Helper loaded: file_helper
INFO - 2024-08-04 21:57:41 --> Helper loaded: form_helper
INFO - 2024-08-04 21:57:41 --> Helper loaded: my_helper
INFO - 2024-08-04 21:57:41 --> Database Driver Class Initialized
INFO - 2024-08-04 21:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-04 21:57:41 --> Controller Class Initialized
ERROR - 2024-08-04 21:57:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-04 21:57:42 --> Severity: Notice --> Undefined variable: kkmx /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1493
ERROR - 2024-08-04 21:57:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-04 21:57:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-04 21:57:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-04 21:57:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-04 21:57:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-04 21:57:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-04 21:57:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-04 21:57:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-04 21:57:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-04 21:57:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-04 21:57:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-04 21:57:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-04 21:57:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-04 21:57:44 --> Final output sent to browser
DEBUG - 2024-08-04 21:57:44 --> Total execution time: 3.1078
INFO - 2024-08-04 21:57:46 --> Config Class Initialized
INFO - 2024-08-04 21:57:46 --> Hooks Class Initialized
DEBUG - 2024-08-04 21:57:46 --> UTF-8 Support Enabled
INFO - 2024-08-04 21:57:46 --> Utf8 Class Initialized
INFO - 2024-08-04 21:57:46 --> URI Class Initialized
INFO - 2024-08-04 21:57:46 --> Router Class Initialized
INFO - 2024-08-04 21:57:46 --> Output Class Initialized
INFO - 2024-08-04 21:57:46 --> Security Class Initialized
DEBUG - 2024-08-04 21:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-04 21:57:46 --> Input Class Initialized
INFO - 2024-08-04 21:57:46 --> Language Class Initialized
INFO - 2024-08-04 21:57:46 --> Language Class Initialized
INFO - 2024-08-04 21:57:46 --> Config Class Initialized
INFO - 2024-08-04 21:57:46 --> Loader Class Initialized
INFO - 2024-08-04 21:57:46 --> Helper loaded: url_helper
INFO - 2024-08-04 21:57:46 --> Helper loaded: file_helper
INFO - 2024-08-04 21:57:46 --> Helper loaded: form_helper
INFO - 2024-08-04 21:57:46 --> Helper loaded: my_helper
INFO - 2024-08-04 21:57:46 --> Database Driver Class Initialized
INFO - 2024-08-04 21:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-04 21:57:46 --> Controller Class Initialized
ERROR - 2024-08-04 21:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-04 21:57:46 --> Severity: Notice --> Undefined variable: kkmx /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1493
ERROR - 2024-08-04 21:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-04 21:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-04 21:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-04 21:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-04 21:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-04 21:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-04 21:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-04 21:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-04 21:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-04 21:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-04 21:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-04 21:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-04 21:57:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-04 21:57:49 --> Final output sent to browser
DEBUG - 2024-08-04 21:57:49 --> Total execution time: 2.7106
INFO - 2024-08-04 21:57:52 --> Config Class Initialized
INFO - 2024-08-04 21:57:52 --> Hooks Class Initialized
DEBUG - 2024-08-04 21:57:52 --> UTF-8 Support Enabled
INFO - 2024-08-04 21:57:52 --> Utf8 Class Initialized
INFO - 2024-08-04 21:57:52 --> URI Class Initialized
INFO - 2024-08-04 21:57:52 --> Router Class Initialized
INFO - 2024-08-04 21:57:52 --> Output Class Initialized
INFO - 2024-08-04 21:57:52 --> Security Class Initialized
DEBUG - 2024-08-04 21:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-04 21:57:52 --> Input Class Initialized
INFO - 2024-08-04 21:57:52 --> Language Class Initialized
INFO - 2024-08-04 21:57:52 --> Language Class Initialized
INFO - 2024-08-04 21:57:52 --> Config Class Initialized
INFO - 2024-08-04 21:57:52 --> Loader Class Initialized
INFO - 2024-08-04 21:57:52 --> Helper loaded: url_helper
INFO - 2024-08-04 21:57:52 --> Helper loaded: file_helper
INFO - 2024-08-04 21:57:52 --> Helper loaded: form_helper
INFO - 2024-08-04 21:57:52 --> Helper loaded: my_helper
INFO - 2024-08-04 21:57:52 --> Database Driver Class Initialized
INFO - 2024-08-04 21:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-04 21:57:52 --> Controller Class Initialized
ERROR - 2024-08-04 21:57:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-04 21:57:52 --> Severity: Notice --> Undefined variable: kkmx /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1493
ERROR - 2024-08-04 21:57:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-04 21:57:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-04 21:57:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-04 21:57:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-04 21:57:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-04 21:57:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-04 21:57:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-04 21:57:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-04 21:57:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-04 21:57:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-04 21:57:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-04 21:57:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-04 21:57:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-04 21:57:54 --> Final output sent to browser
DEBUG - 2024-08-04 21:57:54 --> Total execution time: 2.4657
