<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-07-29 05:35:47 --> Config Class Initialized
INFO - 2023-07-29 05:35:47 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:35:47 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:35:47 --> Utf8 Class Initialized
INFO - 2023-07-29 05:35:47 --> URI Class Initialized
DEBUG - 2023-07-29 05:35:47 --> No URI present. Default controller set.
INFO - 2023-07-29 05:35:47 --> Router Class Initialized
INFO - 2023-07-29 05:35:47 --> Output Class Initialized
INFO - 2023-07-29 05:35:47 --> Security Class Initialized
DEBUG - 2023-07-29 05:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:35:47 --> Input Class Initialized
INFO - 2023-07-29 05:35:47 --> Language Class Initialized
INFO - 2023-07-29 05:35:47 --> Language Class Initialized
INFO - 2023-07-29 05:35:47 --> Config Class Initialized
INFO - 2023-07-29 05:35:47 --> Loader Class Initialized
INFO - 2023-07-29 05:35:47 --> Helper loaded: url_helper
INFO - 2023-07-29 05:35:47 --> Helper loaded: file_helper
INFO - 2023-07-29 05:35:47 --> Helper loaded: form_helper
INFO - 2023-07-29 05:35:47 --> Helper loaded: my_helper
INFO - 2023-07-29 05:35:47 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:35:47 --> Controller Class Initialized
INFO - 2023-07-29 05:35:48 --> Config Class Initialized
INFO - 2023-07-29 05:35:48 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:35:48 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:35:48 --> Utf8 Class Initialized
INFO - 2023-07-29 05:35:48 --> URI Class Initialized
INFO - 2023-07-29 05:35:48 --> Router Class Initialized
INFO - 2023-07-29 05:35:48 --> Output Class Initialized
INFO - 2023-07-29 05:35:48 --> Security Class Initialized
DEBUG - 2023-07-29 05:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:35:48 --> Input Class Initialized
INFO - 2023-07-29 05:35:48 --> Language Class Initialized
INFO - 2023-07-29 05:35:48 --> Language Class Initialized
INFO - 2023-07-29 05:35:48 --> Config Class Initialized
INFO - 2023-07-29 05:35:48 --> Loader Class Initialized
INFO - 2023-07-29 05:35:48 --> Helper loaded: url_helper
INFO - 2023-07-29 05:35:48 --> Helper loaded: file_helper
INFO - 2023-07-29 05:35:48 --> Helper loaded: form_helper
INFO - 2023-07-29 05:35:48 --> Helper loaded: my_helper
INFO - 2023-07-29 05:35:48 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:35:48 --> Controller Class Initialized
DEBUG - 2023-07-29 05:35:48 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/login/views/login.php
DEBUG - 2023-07-29 05:35:48 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 05:35:48 --> Final output sent to browser
DEBUG - 2023-07-29 05:35:48 --> Total execution time: 0.0865
INFO - 2023-07-29 05:35:52 --> Config Class Initialized
INFO - 2023-07-29 05:35:52 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:35:52 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:35:52 --> Utf8 Class Initialized
INFO - 2023-07-29 05:35:52 --> URI Class Initialized
INFO - 2023-07-29 05:35:52 --> Router Class Initialized
INFO - 2023-07-29 05:35:52 --> Output Class Initialized
INFO - 2023-07-29 05:35:52 --> Security Class Initialized
DEBUG - 2023-07-29 05:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:35:52 --> Input Class Initialized
INFO - 2023-07-29 05:35:52 --> Language Class Initialized
INFO - 2023-07-29 05:35:52 --> Language Class Initialized
INFO - 2023-07-29 05:35:52 --> Config Class Initialized
INFO - 2023-07-29 05:35:52 --> Loader Class Initialized
INFO - 2023-07-29 05:35:52 --> Helper loaded: url_helper
INFO - 2023-07-29 05:35:52 --> Helper loaded: file_helper
INFO - 2023-07-29 05:35:52 --> Helper loaded: form_helper
INFO - 2023-07-29 05:35:52 --> Helper loaded: my_helper
INFO - 2023-07-29 05:35:52 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:35:52 --> Controller Class Initialized
INFO - 2023-07-29 05:35:52 --> Final output sent to browser
DEBUG - 2023-07-29 05:35:52 --> Total execution time: 0.0360
INFO - 2023-07-29 05:35:57 --> Config Class Initialized
INFO - 2023-07-29 05:35:57 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:35:57 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:35:57 --> Utf8 Class Initialized
INFO - 2023-07-29 05:35:57 --> URI Class Initialized
INFO - 2023-07-29 05:35:57 --> Router Class Initialized
INFO - 2023-07-29 05:35:57 --> Output Class Initialized
INFO - 2023-07-29 05:35:57 --> Security Class Initialized
DEBUG - 2023-07-29 05:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:35:57 --> Input Class Initialized
INFO - 2023-07-29 05:35:57 --> Language Class Initialized
INFO - 2023-07-29 05:35:57 --> Language Class Initialized
INFO - 2023-07-29 05:35:57 --> Config Class Initialized
INFO - 2023-07-29 05:35:57 --> Loader Class Initialized
INFO - 2023-07-29 05:35:57 --> Helper loaded: url_helper
INFO - 2023-07-29 05:35:57 --> Helper loaded: file_helper
INFO - 2023-07-29 05:35:57 --> Helper loaded: form_helper
INFO - 2023-07-29 05:35:57 --> Helper loaded: my_helper
INFO - 2023-07-29 05:35:57 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:35:57 --> Controller Class Initialized
INFO - 2023-07-29 05:35:57 --> Helper loaded: cookie_helper
INFO - 2023-07-29 05:35:57 --> Final output sent to browser
DEBUG - 2023-07-29 05:35:57 --> Total execution time: 0.0436
INFO - 2023-07-29 05:35:57 --> Config Class Initialized
INFO - 2023-07-29 05:35:57 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:35:57 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:35:57 --> Utf8 Class Initialized
INFO - 2023-07-29 05:35:57 --> URI Class Initialized
INFO - 2023-07-29 05:35:57 --> Router Class Initialized
INFO - 2023-07-29 05:35:57 --> Output Class Initialized
INFO - 2023-07-29 05:35:57 --> Security Class Initialized
DEBUG - 2023-07-29 05:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:35:57 --> Input Class Initialized
INFO - 2023-07-29 05:35:57 --> Language Class Initialized
INFO - 2023-07-29 05:35:57 --> Language Class Initialized
INFO - 2023-07-29 05:35:57 --> Config Class Initialized
INFO - 2023-07-29 05:35:57 --> Loader Class Initialized
INFO - 2023-07-29 05:35:57 --> Helper loaded: url_helper
INFO - 2023-07-29 05:35:57 --> Helper loaded: file_helper
INFO - 2023-07-29 05:35:57 --> Helper loaded: form_helper
INFO - 2023-07-29 05:35:57 --> Helper loaded: my_helper
INFO - 2023-07-29 05:35:57 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:35:57 --> Controller Class Initialized
DEBUG - 2023-07-29 05:35:57 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 05:35:57 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 05:35:57 --> Final output sent to browser
DEBUG - 2023-07-29 05:35:57 --> Total execution time: 0.0991
INFO - 2023-07-29 05:35:59 --> Config Class Initialized
INFO - 2023-07-29 05:35:59 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:35:59 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:35:59 --> Utf8 Class Initialized
INFO - 2023-07-29 05:35:59 --> URI Class Initialized
INFO - 2023-07-29 05:35:59 --> Router Class Initialized
INFO - 2023-07-29 05:35:59 --> Output Class Initialized
INFO - 2023-07-29 05:35:59 --> Security Class Initialized
DEBUG - 2023-07-29 05:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:35:59 --> Input Class Initialized
INFO - 2023-07-29 05:35:59 --> Language Class Initialized
INFO - 2023-07-29 05:35:59 --> Language Class Initialized
INFO - 2023-07-29 05:35:59 --> Config Class Initialized
INFO - 2023-07-29 05:35:59 --> Loader Class Initialized
INFO - 2023-07-29 05:35:59 --> Helper loaded: url_helper
INFO - 2023-07-29 05:35:59 --> Helper loaded: file_helper
INFO - 2023-07-29 05:35:59 --> Helper loaded: form_helper
INFO - 2023-07-29 05:35:59 --> Helper loaded: my_helper
INFO - 2023-07-29 05:35:59 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:35:59 --> Controller Class Initialized
DEBUG - 2023-07-29 05:35:59 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-29 05:35:59 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 05:35:59 --> Final output sent to browser
DEBUG - 2023-07-29 05:35:59 --> Total execution time: 0.0561
INFO - 2023-07-29 05:35:59 --> Config Class Initialized
INFO - 2023-07-29 05:35:59 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:35:59 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:35:59 --> Utf8 Class Initialized
INFO - 2023-07-29 05:35:59 --> URI Class Initialized
INFO - 2023-07-29 05:35:59 --> Router Class Initialized
INFO - 2023-07-29 05:35:59 --> Output Class Initialized
INFO - 2023-07-29 05:35:59 --> Security Class Initialized
DEBUG - 2023-07-29 05:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:35:59 --> Input Class Initialized
INFO - 2023-07-29 05:35:59 --> Language Class Initialized
INFO - 2023-07-29 05:35:59 --> Language Class Initialized
INFO - 2023-07-29 05:35:59 --> Config Class Initialized
INFO - 2023-07-29 05:35:59 --> Loader Class Initialized
INFO - 2023-07-29 05:35:59 --> Helper loaded: url_helper
INFO - 2023-07-29 05:35:59 --> Helper loaded: file_helper
INFO - 2023-07-29 05:35:59 --> Helper loaded: form_helper
INFO - 2023-07-29 05:35:59 --> Helper loaded: my_helper
INFO - 2023-07-29 05:35:59 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:35:59 --> Controller Class Initialized
INFO - 2023-07-29 05:36:06 --> Config Class Initialized
INFO - 2023-07-29 05:36:06 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:36:06 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:36:06 --> Utf8 Class Initialized
INFO - 2023-07-29 05:36:06 --> URI Class Initialized
INFO - 2023-07-29 05:36:06 --> Router Class Initialized
INFO - 2023-07-29 05:36:06 --> Output Class Initialized
INFO - 2023-07-29 05:36:06 --> Security Class Initialized
DEBUG - 2023-07-29 05:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:36:06 --> Input Class Initialized
INFO - 2023-07-29 05:36:06 --> Language Class Initialized
INFO - 2023-07-29 05:36:06 --> Language Class Initialized
INFO - 2023-07-29 05:36:06 --> Config Class Initialized
INFO - 2023-07-29 05:36:06 --> Loader Class Initialized
INFO - 2023-07-29 05:36:06 --> Helper loaded: url_helper
INFO - 2023-07-29 05:36:06 --> Helper loaded: file_helper
INFO - 2023-07-29 05:36:06 --> Helper loaded: form_helper
INFO - 2023-07-29 05:36:06 --> Helper loaded: my_helper
INFO - 2023-07-29 05:36:06 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:36:06 --> Controller Class Initialized
INFO - 2023-07-29 05:36:06 --> Helper loaded: cookie_helper
INFO - 2023-07-29 05:36:06 --> Config Class Initialized
INFO - 2023-07-29 05:36:06 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:36:06 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:36:06 --> Utf8 Class Initialized
INFO - 2023-07-29 05:36:06 --> URI Class Initialized
INFO - 2023-07-29 05:36:06 --> Router Class Initialized
INFO - 2023-07-29 05:36:06 --> Output Class Initialized
INFO - 2023-07-29 05:36:06 --> Security Class Initialized
DEBUG - 2023-07-29 05:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:36:06 --> Input Class Initialized
INFO - 2023-07-29 05:36:06 --> Language Class Initialized
INFO - 2023-07-29 05:36:06 --> Language Class Initialized
INFO - 2023-07-29 05:36:06 --> Config Class Initialized
INFO - 2023-07-29 05:36:06 --> Loader Class Initialized
INFO - 2023-07-29 05:36:06 --> Helper loaded: url_helper
INFO - 2023-07-29 05:36:06 --> Helper loaded: file_helper
INFO - 2023-07-29 05:36:06 --> Helper loaded: form_helper
INFO - 2023-07-29 05:36:06 --> Helper loaded: my_helper
INFO - 2023-07-29 05:36:06 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:36:06 --> Controller Class Initialized
INFO - 2023-07-29 05:36:06 --> Config Class Initialized
INFO - 2023-07-29 05:36:06 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:36:06 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:36:06 --> Utf8 Class Initialized
INFO - 2023-07-29 05:36:06 --> URI Class Initialized
INFO - 2023-07-29 05:36:06 --> Router Class Initialized
INFO - 2023-07-29 05:36:06 --> Output Class Initialized
INFO - 2023-07-29 05:36:06 --> Security Class Initialized
DEBUG - 2023-07-29 05:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:36:06 --> Input Class Initialized
INFO - 2023-07-29 05:36:06 --> Language Class Initialized
INFO - 2023-07-29 05:36:06 --> Language Class Initialized
INFO - 2023-07-29 05:36:06 --> Config Class Initialized
INFO - 2023-07-29 05:36:06 --> Loader Class Initialized
INFO - 2023-07-29 05:36:06 --> Helper loaded: url_helper
INFO - 2023-07-29 05:36:06 --> Helper loaded: file_helper
INFO - 2023-07-29 05:36:06 --> Helper loaded: form_helper
INFO - 2023-07-29 05:36:06 --> Helper loaded: my_helper
INFO - 2023-07-29 05:36:06 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:36:06 --> Controller Class Initialized
DEBUG - 2023-07-29 05:36:06 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/login/views/login.php
DEBUG - 2023-07-29 05:36:06 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 05:36:06 --> Final output sent to browser
DEBUG - 2023-07-29 05:36:06 --> Total execution time: 0.0472
INFO - 2023-07-29 05:36:13 --> Config Class Initialized
INFO - 2023-07-29 05:36:13 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:36:13 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:36:13 --> Utf8 Class Initialized
INFO - 2023-07-29 05:36:13 --> URI Class Initialized
INFO - 2023-07-29 05:36:13 --> Router Class Initialized
INFO - 2023-07-29 05:36:13 --> Output Class Initialized
INFO - 2023-07-29 05:36:13 --> Security Class Initialized
DEBUG - 2023-07-29 05:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:36:13 --> Input Class Initialized
INFO - 2023-07-29 05:36:13 --> Language Class Initialized
INFO - 2023-07-29 05:36:13 --> Language Class Initialized
INFO - 2023-07-29 05:36:13 --> Config Class Initialized
INFO - 2023-07-29 05:36:13 --> Loader Class Initialized
INFO - 2023-07-29 05:36:13 --> Helper loaded: url_helper
INFO - 2023-07-29 05:36:13 --> Helper loaded: file_helper
INFO - 2023-07-29 05:36:13 --> Helper loaded: form_helper
INFO - 2023-07-29 05:36:13 --> Helper loaded: my_helper
INFO - 2023-07-29 05:36:13 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:36:13 --> Controller Class Initialized
INFO - 2023-07-29 05:36:13 --> Helper loaded: cookie_helper
INFO - 2023-07-29 05:36:13 --> Final output sent to browser
DEBUG - 2023-07-29 05:36:13 --> Total execution time: 0.0510
INFO - 2023-07-29 05:36:13 --> Config Class Initialized
INFO - 2023-07-29 05:36:13 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:36:13 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:36:13 --> Utf8 Class Initialized
INFO - 2023-07-29 05:36:13 --> URI Class Initialized
INFO - 2023-07-29 05:36:13 --> Router Class Initialized
INFO - 2023-07-29 05:36:13 --> Output Class Initialized
INFO - 2023-07-29 05:36:13 --> Security Class Initialized
DEBUG - 2023-07-29 05:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:36:13 --> Input Class Initialized
INFO - 2023-07-29 05:36:13 --> Language Class Initialized
INFO - 2023-07-29 05:36:13 --> Language Class Initialized
INFO - 2023-07-29 05:36:13 --> Config Class Initialized
INFO - 2023-07-29 05:36:13 --> Loader Class Initialized
INFO - 2023-07-29 05:36:13 --> Helper loaded: url_helper
INFO - 2023-07-29 05:36:13 --> Helper loaded: file_helper
INFO - 2023-07-29 05:36:13 --> Helper loaded: form_helper
INFO - 2023-07-29 05:36:13 --> Helper loaded: my_helper
INFO - 2023-07-29 05:36:13 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:36:13 --> Controller Class Initialized
DEBUG - 2023-07-29 05:36:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-07-29 05:36:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 05:36:13 --> Final output sent to browser
DEBUG - 2023-07-29 05:36:13 --> Total execution time: 0.0582
INFO - 2023-07-29 05:36:21 --> Config Class Initialized
INFO - 2023-07-29 05:36:21 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:36:21 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:36:21 --> Utf8 Class Initialized
INFO - 2023-07-29 05:36:21 --> URI Class Initialized
INFO - 2023-07-29 05:36:21 --> Router Class Initialized
INFO - 2023-07-29 05:36:21 --> Output Class Initialized
INFO - 2023-07-29 05:36:21 --> Security Class Initialized
DEBUG - 2023-07-29 05:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:36:21 --> Input Class Initialized
INFO - 2023-07-29 05:36:21 --> Language Class Initialized
INFO - 2023-07-29 05:36:21 --> Language Class Initialized
INFO - 2023-07-29 05:36:21 --> Config Class Initialized
INFO - 2023-07-29 05:36:21 --> Loader Class Initialized
INFO - 2023-07-29 05:36:21 --> Helper loaded: url_helper
INFO - 2023-07-29 05:36:21 --> Helper loaded: file_helper
INFO - 2023-07-29 05:36:21 --> Helper loaded: form_helper
INFO - 2023-07-29 05:36:21 --> Helper loaded: my_helper
INFO - 2023-07-29 05:36:21 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:36:21 --> Controller Class Initialized
DEBUG - 2023-07-29 05:36:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/list.php
DEBUG - 2023-07-29 05:36:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 05:36:21 --> Final output sent to browser
DEBUG - 2023-07-29 05:36:21 --> Total execution time: 0.0715
INFO - 2023-07-29 05:36:24 --> Config Class Initialized
INFO - 2023-07-29 05:36:24 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:36:24 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:36:24 --> Utf8 Class Initialized
INFO - 2023-07-29 05:36:24 --> URI Class Initialized
INFO - 2023-07-29 05:36:24 --> Router Class Initialized
INFO - 2023-07-29 05:36:24 --> Output Class Initialized
INFO - 2023-07-29 05:36:24 --> Security Class Initialized
DEBUG - 2023-07-29 05:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:36:24 --> Input Class Initialized
INFO - 2023-07-29 05:36:24 --> Language Class Initialized
INFO - 2023-07-29 05:36:24 --> Language Class Initialized
INFO - 2023-07-29 05:36:24 --> Config Class Initialized
INFO - 2023-07-29 05:36:24 --> Loader Class Initialized
INFO - 2023-07-29 05:36:24 --> Helper loaded: url_helper
INFO - 2023-07-29 05:36:24 --> Helper loaded: file_helper
INFO - 2023-07-29 05:36:24 --> Helper loaded: form_helper
INFO - 2023-07-29 05:36:24 --> Helper loaded: my_helper
INFO - 2023-07-29 05:36:24 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:36:24 --> Controller Class Initialized
DEBUG - 2023-07-29 05:36:25 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-29 05:36:27 --> Final output sent to browser
DEBUG - 2023-07-29 05:36:27 --> Total execution time: 2.1189
INFO - 2023-07-29 05:36:47 --> Config Class Initialized
INFO - 2023-07-29 05:36:47 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:36:47 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:36:47 --> Utf8 Class Initialized
INFO - 2023-07-29 05:36:47 --> URI Class Initialized
INFO - 2023-07-29 05:36:47 --> Router Class Initialized
INFO - 2023-07-29 05:36:47 --> Output Class Initialized
INFO - 2023-07-29 05:36:47 --> Security Class Initialized
DEBUG - 2023-07-29 05:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:36:47 --> Input Class Initialized
INFO - 2023-07-29 05:36:47 --> Language Class Initialized
INFO - 2023-07-29 05:36:47 --> Language Class Initialized
INFO - 2023-07-29 05:36:47 --> Config Class Initialized
INFO - 2023-07-29 05:36:47 --> Loader Class Initialized
INFO - 2023-07-29 05:36:47 --> Helper loaded: url_helper
INFO - 2023-07-29 05:36:47 --> Helper loaded: file_helper
INFO - 2023-07-29 05:36:47 --> Helper loaded: form_helper
INFO - 2023-07-29 05:36:47 --> Helper loaded: my_helper
INFO - 2023-07-29 05:36:47 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:36:47 --> Controller Class Initialized
INFO - 2023-07-29 05:36:47 --> Helper loaded: cookie_helper
INFO - 2023-07-29 05:36:47 --> Config Class Initialized
INFO - 2023-07-29 05:36:47 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:36:47 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:36:47 --> Utf8 Class Initialized
INFO - 2023-07-29 05:36:47 --> URI Class Initialized
INFO - 2023-07-29 05:36:47 --> Router Class Initialized
INFO - 2023-07-29 05:36:47 --> Output Class Initialized
INFO - 2023-07-29 05:36:47 --> Security Class Initialized
DEBUG - 2023-07-29 05:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:36:47 --> Input Class Initialized
INFO - 2023-07-29 05:36:47 --> Language Class Initialized
INFO - 2023-07-29 05:36:47 --> Language Class Initialized
INFO - 2023-07-29 05:36:47 --> Config Class Initialized
INFO - 2023-07-29 05:36:47 --> Loader Class Initialized
INFO - 2023-07-29 05:36:47 --> Helper loaded: url_helper
INFO - 2023-07-29 05:36:47 --> Helper loaded: file_helper
INFO - 2023-07-29 05:36:47 --> Helper loaded: form_helper
INFO - 2023-07-29 05:36:47 --> Helper loaded: my_helper
INFO - 2023-07-29 05:36:47 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:36:47 --> Controller Class Initialized
INFO - 2023-07-29 05:36:47 --> Config Class Initialized
INFO - 2023-07-29 05:36:47 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:36:47 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:36:47 --> Utf8 Class Initialized
INFO - 2023-07-29 05:36:47 --> URI Class Initialized
INFO - 2023-07-29 05:36:47 --> Router Class Initialized
INFO - 2023-07-29 05:36:47 --> Output Class Initialized
INFO - 2023-07-29 05:36:47 --> Security Class Initialized
DEBUG - 2023-07-29 05:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:36:47 --> Input Class Initialized
INFO - 2023-07-29 05:36:47 --> Language Class Initialized
INFO - 2023-07-29 05:36:47 --> Language Class Initialized
INFO - 2023-07-29 05:36:47 --> Config Class Initialized
INFO - 2023-07-29 05:36:47 --> Loader Class Initialized
INFO - 2023-07-29 05:36:47 --> Helper loaded: url_helper
INFO - 2023-07-29 05:36:47 --> Helper loaded: file_helper
INFO - 2023-07-29 05:36:47 --> Helper loaded: form_helper
INFO - 2023-07-29 05:36:47 --> Helper loaded: my_helper
INFO - 2023-07-29 05:36:47 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:36:47 --> Controller Class Initialized
DEBUG - 2023-07-29 05:36:47 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/login/views/login.php
DEBUG - 2023-07-29 05:36:47 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 05:36:47 --> Final output sent to browser
DEBUG - 2023-07-29 05:36:47 --> Total execution time: 0.0379
INFO - 2023-07-29 05:36:52 --> Config Class Initialized
INFO - 2023-07-29 05:36:52 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:36:52 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:36:52 --> Utf8 Class Initialized
INFO - 2023-07-29 05:36:52 --> URI Class Initialized
INFO - 2023-07-29 05:36:52 --> Router Class Initialized
INFO - 2023-07-29 05:36:52 --> Output Class Initialized
INFO - 2023-07-29 05:36:52 --> Security Class Initialized
DEBUG - 2023-07-29 05:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:36:52 --> Input Class Initialized
INFO - 2023-07-29 05:36:52 --> Language Class Initialized
INFO - 2023-07-29 05:36:52 --> Language Class Initialized
INFO - 2023-07-29 05:36:52 --> Config Class Initialized
INFO - 2023-07-29 05:36:52 --> Loader Class Initialized
INFO - 2023-07-29 05:36:52 --> Helper loaded: url_helper
INFO - 2023-07-29 05:36:52 --> Helper loaded: file_helper
INFO - 2023-07-29 05:36:52 --> Helper loaded: form_helper
INFO - 2023-07-29 05:36:52 --> Helper loaded: my_helper
INFO - 2023-07-29 05:36:52 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:36:52 --> Controller Class Initialized
INFO - 2023-07-29 05:36:52 --> Helper loaded: cookie_helper
INFO - 2023-07-29 05:36:52 --> Final output sent to browser
DEBUG - 2023-07-29 05:36:52 --> Total execution time: 0.0254
INFO - 2023-07-29 05:36:52 --> Config Class Initialized
INFO - 2023-07-29 05:36:52 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:36:52 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:36:52 --> Utf8 Class Initialized
INFO - 2023-07-29 05:36:52 --> URI Class Initialized
INFO - 2023-07-29 05:36:52 --> Router Class Initialized
INFO - 2023-07-29 05:36:52 --> Output Class Initialized
INFO - 2023-07-29 05:36:52 --> Security Class Initialized
DEBUG - 2023-07-29 05:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:36:52 --> Input Class Initialized
INFO - 2023-07-29 05:36:52 --> Language Class Initialized
INFO - 2023-07-29 05:36:52 --> Language Class Initialized
INFO - 2023-07-29 05:36:52 --> Config Class Initialized
INFO - 2023-07-29 05:36:52 --> Loader Class Initialized
INFO - 2023-07-29 05:36:52 --> Helper loaded: url_helper
INFO - 2023-07-29 05:36:52 --> Helper loaded: file_helper
INFO - 2023-07-29 05:36:52 --> Helper loaded: form_helper
INFO - 2023-07-29 05:36:52 --> Helper loaded: my_helper
INFO - 2023-07-29 05:36:52 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:36:52 --> Controller Class Initialized
DEBUG - 2023-07-29 05:36:52 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-07-29 05:36:52 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 05:36:52 --> Final output sent to browser
DEBUG - 2023-07-29 05:36:52 --> Total execution time: 0.0510
INFO - 2023-07-29 05:36:54 --> Config Class Initialized
INFO - 2023-07-29 05:36:54 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:36:54 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:36:54 --> Utf8 Class Initialized
INFO - 2023-07-29 05:36:54 --> URI Class Initialized
DEBUG - 2023-07-29 05:36:54 --> No URI present. Default controller set.
INFO - 2023-07-29 05:36:54 --> Router Class Initialized
INFO - 2023-07-29 05:36:54 --> Output Class Initialized
INFO - 2023-07-29 05:36:54 --> Security Class Initialized
DEBUG - 2023-07-29 05:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:36:54 --> Input Class Initialized
INFO - 2023-07-29 05:36:54 --> Language Class Initialized
INFO - 2023-07-29 05:36:54 --> Language Class Initialized
INFO - 2023-07-29 05:36:54 --> Config Class Initialized
INFO - 2023-07-29 05:36:54 --> Loader Class Initialized
INFO - 2023-07-29 05:36:54 --> Helper loaded: url_helper
INFO - 2023-07-29 05:36:54 --> Helper loaded: file_helper
INFO - 2023-07-29 05:36:54 --> Helper loaded: form_helper
INFO - 2023-07-29 05:36:54 --> Helper loaded: my_helper
INFO - 2023-07-29 05:36:54 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:36:54 --> Controller Class Initialized
DEBUG - 2023-07-29 05:36:54 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-07-29 05:36:54 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 05:36:54 --> Final output sent to browser
DEBUG - 2023-07-29 05:36:54 --> Total execution time: 0.0439
INFO - 2023-07-29 05:36:56 --> Config Class Initialized
INFO - 2023-07-29 05:36:56 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:36:56 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:36:56 --> Utf8 Class Initialized
INFO - 2023-07-29 05:36:56 --> URI Class Initialized
INFO - 2023-07-29 05:36:56 --> Router Class Initialized
INFO - 2023-07-29 05:36:56 --> Output Class Initialized
INFO - 2023-07-29 05:36:56 --> Security Class Initialized
DEBUG - 2023-07-29 05:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:36:56 --> Input Class Initialized
INFO - 2023-07-29 05:36:56 --> Language Class Initialized
INFO - 2023-07-29 05:36:56 --> Language Class Initialized
INFO - 2023-07-29 05:36:56 --> Config Class Initialized
INFO - 2023-07-29 05:36:56 --> Loader Class Initialized
INFO - 2023-07-29 05:36:56 --> Helper loaded: url_helper
INFO - 2023-07-29 05:36:56 --> Helper loaded: file_helper
INFO - 2023-07-29 05:36:56 --> Helper loaded: form_helper
INFO - 2023-07-29 05:36:56 --> Helper loaded: my_helper
INFO - 2023-07-29 05:36:56 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:36:56 --> Controller Class Initialized
DEBUG - 2023-07-29 05:36:56 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-07-29 05:36:56 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 05:36:56 --> Final output sent to browser
DEBUG - 2023-07-29 05:36:56 --> Total execution time: 0.0785
INFO - 2023-07-29 05:37:05 --> Config Class Initialized
INFO - 2023-07-29 05:37:05 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:37:05 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:37:05 --> Utf8 Class Initialized
INFO - 2023-07-29 05:37:05 --> URI Class Initialized
INFO - 2023-07-29 05:37:05 --> Router Class Initialized
INFO - 2023-07-29 05:37:05 --> Output Class Initialized
INFO - 2023-07-29 05:37:05 --> Security Class Initialized
DEBUG - 2023-07-29 05:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:37:05 --> Input Class Initialized
INFO - 2023-07-29 05:37:05 --> Language Class Initialized
INFO - 2023-07-29 05:37:05 --> Language Class Initialized
INFO - 2023-07-29 05:37:05 --> Config Class Initialized
INFO - 2023-07-29 05:37:05 --> Loader Class Initialized
INFO - 2023-07-29 05:37:05 --> Helper loaded: url_helper
INFO - 2023-07-29 05:37:05 --> Helper loaded: file_helper
INFO - 2023-07-29 05:37:05 --> Helper loaded: form_helper
INFO - 2023-07-29 05:37:05 --> Helper loaded: my_helper
INFO - 2023-07-29 05:37:05 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:37:05 --> Controller Class Initialized
DEBUG - 2023-07-29 05:37:06 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_keterampilan/views/list.php
DEBUG - 2023-07-29 05:37:06 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 05:37:06 --> Final output sent to browser
DEBUG - 2023-07-29 05:37:06 --> Total execution time: 0.0924
INFO - 2023-07-29 05:37:09 --> Config Class Initialized
INFO - 2023-07-29 05:37:09 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:37:09 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:37:09 --> Utf8 Class Initialized
INFO - 2023-07-29 05:37:09 --> URI Class Initialized
INFO - 2023-07-29 05:37:09 --> Router Class Initialized
INFO - 2023-07-29 05:37:09 --> Output Class Initialized
INFO - 2023-07-29 05:37:09 --> Security Class Initialized
DEBUG - 2023-07-29 05:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:37:09 --> Input Class Initialized
INFO - 2023-07-29 05:37:09 --> Language Class Initialized
INFO - 2023-07-29 05:37:09 --> Language Class Initialized
INFO - 2023-07-29 05:37:09 --> Config Class Initialized
INFO - 2023-07-29 05:37:09 --> Loader Class Initialized
INFO - 2023-07-29 05:37:09 --> Helper loaded: url_helper
INFO - 2023-07-29 05:37:09 --> Helper loaded: file_helper
INFO - 2023-07-29 05:37:09 --> Helper loaded: form_helper
INFO - 2023-07-29 05:37:09 --> Helper loaded: my_helper
INFO - 2023-07-29 05:37:09 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:37:09 --> Controller Class Initialized
INFO - 2023-07-29 05:37:09 --> Final output sent to browser
DEBUG - 2023-07-29 05:37:09 --> Total execution time: 0.0456
INFO - 2023-07-29 05:37:17 --> Config Class Initialized
INFO - 2023-07-29 05:37:17 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:37:17 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:37:17 --> Utf8 Class Initialized
INFO - 2023-07-29 05:37:17 --> URI Class Initialized
INFO - 2023-07-29 05:37:17 --> Router Class Initialized
INFO - 2023-07-29 05:37:17 --> Output Class Initialized
INFO - 2023-07-29 05:37:17 --> Security Class Initialized
DEBUG - 2023-07-29 05:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:37:17 --> Input Class Initialized
INFO - 2023-07-29 05:37:17 --> Language Class Initialized
INFO - 2023-07-29 05:37:17 --> Language Class Initialized
INFO - 2023-07-29 05:37:17 --> Config Class Initialized
INFO - 2023-07-29 05:37:17 --> Loader Class Initialized
INFO - 2023-07-29 05:37:17 --> Helper loaded: url_helper
INFO - 2023-07-29 05:37:17 --> Helper loaded: file_helper
INFO - 2023-07-29 05:37:17 --> Helper loaded: form_helper
INFO - 2023-07-29 05:37:17 --> Helper loaded: my_helper
INFO - 2023-07-29 05:37:17 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:37:17 --> Controller Class Initialized
INFO - 2023-07-29 05:37:17 --> Final output sent to browser
DEBUG - 2023-07-29 05:37:17 --> Total execution time: 0.0422
INFO - 2023-07-29 05:37:25 --> Config Class Initialized
INFO - 2023-07-29 05:37:25 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:37:25 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:37:25 --> Utf8 Class Initialized
INFO - 2023-07-29 05:37:25 --> URI Class Initialized
INFO - 2023-07-29 05:37:25 --> Router Class Initialized
INFO - 2023-07-29 05:37:25 --> Output Class Initialized
INFO - 2023-07-29 05:37:25 --> Security Class Initialized
DEBUG - 2023-07-29 05:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:37:25 --> Input Class Initialized
INFO - 2023-07-29 05:37:25 --> Language Class Initialized
INFO - 2023-07-29 05:37:25 --> Language Class Initialized
INFO - 2023-07-29 05:37:25 --> Config Class Initialized
INFO - 2023-07-29 05:37:25 --> Loader Class Initialized
INFO - 2023-07-29 05:37:25 --> Helper loaded: url_helper
INFO - 2023-07-29 05:37:25 --> Helper loaded: file_helper
INFO - 2023-07-29 05:37:25 --> Helper loaded: form_helper
INFO - 2023-07-29 05:37:25 --> Helper loaded: my_helper
INFO - 2023-07-29 05:37:25 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:37:25 --> Controller Class Initialized
INFO - 2023-07-29 05:37:51 --> Config Class Initialized
INFO - 2023-07-29 05:37:51 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:37:51 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:37:51 --> Utf8 Class Initialized
INFO - 2023-07-29 05:37:51 --> URI Class Initialized
INFO - 2023-07-29 05:37:51 --> Router Class Initialized
INFO - 2023-07-29 05:37:51 --> Output Class Initialized
INFO - 2023-07-29 05:37:51 --> Security Class Initialized
DEBUG - 2023-07-29 05:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:37:51 --> Input Class Initialized
INFO - 2023-07-29 05:37:51 --> Language Class Initialized
INFO - 2023-07-29 05:37:51 --> Language Class Initialized
INFO - 2023-07-29 05:37:51 --> Config Class Initialized
INFO - 2023-07-29 05:37:51 --> Loader Class Initialized
INFO - 2023-07-29 05:37:51 --> Helper loaded: url_helper
INFO - 2023-07-29 05:37:51 --> Helper loaded: file_helper
INFO - 2023-07-29 05:37:51 --> Helper loaded: form_helper
INFO - 2023-07-29 05:37:51 --> Helper loaded: my_helper
INFO - 2023-07-29 05:37:51 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:37:51 --> Controller Class Initialized
INFO - 2023-07-29 05:37:51 --> Final output sent to browser
DEBUG - 2023-07-29 05:37:51 --> Total execution time: 0.0403
INFO - 2023-07-29 05:38:22 --> Config Class Initialized
INFO - 2023-07-29 05:38:22 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:38:22 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:38:22 --> Utf8 Class Initialized
INFO - 2023-07-29 05:38:22 --> URI Class Initialized
INFO - 2023-07-29 05:38:22 --> Router Class Initialized
INFO - 2023-07-29 05:38:22 --> Output Class Initialized
INFO - 2023-07-29 05:38:22 --> Security Class Initialized
DEBUG - 2023-07-29 05:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:38:22 --> Input Class Initialized
INFO - 2023-07-29 05:38:22 --> Language Class Initialized
INFO - 2023-07-29 05:38:22 --> Language Class Initialized
INFO - 2023-07-29 05:38:22 --> Config Class Initialized
INFO - 2023-07-29 05:38:22 --> Loader Class Initialized
INFO - 2023-07-29 05:38:22 --> Helper loaded: url_helper
INFO - 2023-07-29 05:38:22 --> Helper loaded: file_helper
INFO - 2023-07-29 05:38:22 --> Helper loaded: form_helper
INFO - 2023-07-29 05:38:22 --> Helper loaded: my_helper
INFO - 2023-07-29 05:38:22 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:38:22 --> Controller Class Initialized
INFO - 2023-07-29 05:38:22 --> Final output sent to browser
DEBUG - 2023-07-29 05:38:22 --> Total execution time: 0.0255
INFO - 2023-07-29 05:38:40 --> Config Class Initialized
INFO - 2023-07-29 05:38:40 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:38:40 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:38:40 --> Utf8 Class Initialized
INFO - 2023-07-29 05:38:40 --> URI Class Initialized
INFO - 2023-07-29 05:38:40 --> Router Class Initialized
INFO - 2023-07-29 05:38:40 --> Output Class Initialized
INFO - 2023-07-29 05:38:40 --> Security Class Initialized
DEBUG - 2023-07-29 05:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:38:40 --> Input Class Initialized
INFO - 2023-07-29 05:38:40 --> Language Class Initialized
INFO - 2023-07-29 05:38:40 --> Language Class Initialized
INFO - 2023-07-29 05:38:40 --> Config Class Initialized
INFO - 2023-07-29 05:38:40 --> Loader Class Initialized
INFO - 2023-07-29 05:38:40 --> Helper loaded: url_helper
INFO - 2023-07-29 05:38:40 --> Helper loaded: file_helper
INFO - 2023-07-29 05:38:40 --> Helper loaded: form_helper
INFO - 2023-07-29 05:38:40 --> Helper loaded: my_helper
INFO - 2023-07-29 05:38:40 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:38:40 --> Controller Class Initialized
INFO - 2023-07-29 05:38:40 --> Final output sent to browser
DEBUG - 2023-07-29 05:38:40 --> Total execution time: 0.0273
INFO - 2023-07-29 05:38:42 --> Config Class Initialized
INFO - 2023-07-29 05:38:42 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:38:42 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:38:42 --> Utf8 Class Initialized
INFO - 2023-07-29 05:38:42 --> URI Class Initialized
INFO - 2023-07-29 05:38:42 --> Router Class Initialized
INFO - 2023-07-29 05:38:42 --> Output Class Initialized
INFO - 2023-07-29 05:38:42 --> Security Class Initialized
DEBUG - 2023-07-29 05:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:38:42 --> Input Class Initialized
INFO - 2023-07-29 05:38:42 --> Language Class Initialized
INFO - 2023-07-29 05:38:42 --> Language Class Initialized
INFO - 2023-07-29 05:38:42 --> Config Class Initialized
INFO - 2023-07-29 05:38:42 --> Loader Class Initialized
INFO - 2023-07-29 05:38:42 --> Helper loaded: url_helper
INFO - 2023-07-29 05:38:42 --> Helper loaded: file_helper
INFO - 2023-07-29 05:38:42 --> Helper loaded: form_helper
INFO - 2023-07-29 05:38:42 --> Helper loaded: my_helper
INFO - 2023-07-29 05:38:42 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:38:42 --> Controller Class Initialized
DEBUG - 2023-07-29 05:38:42 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-29 05:38:43 --> Final output sent to browser
DEBUG - 2023-07-29 05:38:43 --> Total execution time: 1.0737
INFO - 2023-07-29 05:38:57 --> Config Class Initialized
INFO - 2023-07-29 05:38:57 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:38:57 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:38:57 --> Utf8 Class Initialized
INFO - 2023-07-29 05:38:57 --> URI Class Initialized
INFO - 2023-07-29 05:38:57 --> Router Class Initialized
INFO - 2023-07-29 05:38:57 --> Output Class Initialized
INFO - 2023-07-29 05:38:57 --> Security Class Initialized
DEBUG - 2023-07-29 05:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:38:57 --> Input Class Initialized
INFO - 2023-07-29 05:38:57 --> Language Class Initialized
INFO - 2023-07-29 05:38:57 --> Language Class Initialized
INFO - 2023-07-29 05:38:57 --> Config Class Initialized
INFO - 2023-07-29 05:38:57 --> Loader Class Initialized
INFO - 2023-07-29 05:38:57 --> Helper loaded: url_helper
INFO - 2023-07-29 05:38:57 --> Helper loaded: file_helper
INFO - 2023-07-29 05:38:57 --> Helper loaded: form_helper
INFO - 2023-07-29 05:38:57 --> Helper loaded: my_helper
INFO - 2023-07-29 05:38:57 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:38:57 --> Controller Class Initialized
DEBUG - 2023-07-29 05:38:57 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-07-29 05:38:57 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 05:38:57 --> Final output sent to browser
DEBUG - 2023-07-29 05:38:57 --> Total execution time: 0.0270
INFO - 2023-07-29 05:38:58 --> Config Class Initialized
INFO - 2023-07-29 05:38:58 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:38:58 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:38:58 --> Utf8 Class Initialized
INFO - 2023-07-29 05:38:58 --> URI Class Initialized
INFO - 2023-07-29 05:38:58 --> Router Class Initialized
INFO - 2023-07-29 05:38:58 --> Output Class Initialized
INFO - 2023-07-29 05:38:58 --> Security Class Initialized
DEBUG - 2023-07-29 05:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:38:58 --> Input Class Initialized
INFO - 2023-07-29 05:38:58 --> Language Class Initialized
INFO - 2023-07-29 05:38:58 --> Language Class Initialized
INFO - 2023-07-29 05:38:58 --> Config Class Initialized
INFO - 2023-07-29 05:38:58 --> Loader Class Initialized
INFO - 2023-07-29 05:38:58 --> Helper loaded: url_helper
INFO - 2023-07-29 05:38:58 --> Helper loaded: file_helper
INFO - 2023-07-29 05:38:58 --> Helper loaded: form_helper
INFO - 2023-07-29 05:38:58 --> Helper loaded: my_helper
INFO - 2023-07-29 05:38:58 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:38:58 --> Controller Class Initialized
DEBUG - 2023-07-29 05:38:58 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-07-29 05:38:58 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 05:38:58 --> Final output sent to browser
DEBUG - 2023-07-29 05:38:58 --> Total execution time: 0.0945
INFO - 2023-07-29 05:38:58 --> Config Class Initialized
INFO - 2023-07-29 05:38:58 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:38:58 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:38:58 --> Utf8 Class Initialized
INFO - 2023-07-29 05:38:58 --> URI Class Initialized
INFO - 2023-07-29 05:38:58 --> Router Class Initialized
INFO - 2023-07-29 05:38:58 --> Output Class Initialized
INFO - 2023-07-29 05:38:58 --> Security Class Initialized
DEBUG - 2023-07-29 05:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:38:58 --> Input Class Initialized
INFO - 2023-07-29 05:38:58 --> Language Class Initialized
INFO - 2023-07-29 05:38:58 --> Language Class Initialized
INFO - 2023-07-29 05:38:58 --> Config Class Initialized
INFO - 2023-07-29 05:38:58 --> Loader Class Initialized
INFO - 2023-07-29 05:38:58 --> Helper loaded: url_helper
INFO - 2023-07-29 05:38:58 --> Helper loaded: file_helper
INFO - 2023-07-29 05:38:58 --> Helper loaded: form_helper
INFO - 2023-07-29 05:38:58 --> Helper loaded: my_helper
INFO - 2023-07-29 05:38:58 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:38:58 --> Controller Class Initialized
INFO - 2023-07-29 05:39:00 --> Config Class Initialized
INFO - 2023-07-29 05:39:00 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:39:00 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:39:00 --> Utf8 Class Initialized
INFO - 2023-07-29 05:39:00 --> URI Class Initialized
INFO - 2023-07-29 05:39:00 --> Router Class Initialized
INFO - 2023-07-29 05:39:00 --> Output Class Initialized
INFO - 2023-07-29 05:39:00 --> Security Class Initialized
DEBUG - 2023-07-29 05:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:39:00 --> Input Class Initialized
INFO - 2023-07-29 05:39:00 --> Language Class Initialized
INFO - 2023-07-29 05:39:00 --> Language Class Initialized
INFO - 2023-07-29 05:39:00 --> Config Class Initialized
INFO - 2023-07-29 05:39:00 --> Loader Class Initialized
INFO - 2023-07-29 05:39:00 --> Helper loaded: url_helper
INFO - 2023-07-29 05:39:00 --> Helper loaded: file_helper
INFO - 2023-07-29 05:39:00 --> Helper loaded: form_helper
INFO - 2023-07-29 05:39:00 --> Helper loaded: my_helper
INFO - 2023-07-29 05:39:00 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:39:00 --> Controller Class Initialized
INFO - 2023-07-29 05:39:00 --> Final output sent to browser
DEBUG - 2023-07-29 05:39:00 --> Total execution time: 0.0362
INFO - 2023-07-29 05:39:16 --> Config Class Initialized
INFO - 2023-07-29 05:39:16 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:39:16 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:39:16 --> Utf8 Class Initialized
INFO - 2023-07-29 05:39:16 --> URI Class Initialized
INFO - 2023-07-29 05:39:16 --> Router Class Initialized
INFO - 2023-07-29 05:39:16 --> Output Class Initialized
INFO - 2023-07-29 05:39:16 --> Security Class Initialized
DEBUG - 2023-07-29 05:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:39:16 --> Input Class Initialized
INFO - 2023-07-29 05:39:16 --> Language Class Initialized
INFO - 2023-07-29 05:39:16 --> Language Class Initialized
INFO - 2023-07-29 05:39:16 --> Config Class Initialized
INFO - 2023-07-29 05:39:16 --> Loader Class Initialized
INFO - 2023-07-29 05:39:16 --> Helper loaded: url_helper
INFO - 2023-07-29 05:39:16 --> Helper loaded: file_helper
INFO - 2023-07-29 05:39:16 --> Helper loaded: form_helper
INFO - 2023-07-29 05:39:16 --> Helper loaded: my_helper
INFO - 2023-07-29 05:39:16 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:39:16 --> Controller Class Initialized
INFO - 2023-07-29 05:39:16 --> Final output sent to browser
DEBUG - 2023-07-29 05:39:16 --> Total execution time: 0.0383
INFO - 2023-07-29 05:39:18 --> Config Class Initialized
INFO - 2023-07-29 05:39:18 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:39:18 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:39:18 --> Utf8 Class Initialized
INFO - 2023-07-29 05:39:18 --> URI Class Initialized
INFO - 2023-07-29 05:39:18 --> Router Class Initialized
INFO - 2023-07-29 05:39:18 --> Output Class Initialized
INFO - 2023-07-29 05:39:18 --> Security Class Initialized
DEBUG - 2023-07-29 05:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:39:18 --> Input Class Initialized
INFO - 2023-07-29 05:39:18 --> Language Class Initialized
INFO - 2023-07-29 05:39:18 --> Language Class Initialized
INFO - 2023-07-29 05:39:18 --> Config Class Initialized
INFO - 2023-07-29 05:39:18 --> Loader Class Initialized
INFO - 2023-07-29 05:39:18 --> Helper loaded: url_helper
INFO - 2023-07-29 05:39:18 --> Helper loaded: file_helper
INFO - 2023-07-29 05:39:18 --> Helper loaded: form_helper
INFO - 2023-07-29 05:39:18 --> Helper loaded: my_helper
INFO - 2023-07-29 05:39:18 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:39:18 --> Controller Class Initialized
DEBUG - 2023-07-29 05:39:18 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-29 05:39:19 --> Final output sent to browser
DEBUG - 2023-07-29 05:39:19 --> Total execution time: 1.0919
INFO - 2023-07-29 05:43:31 --> Config Class Initialized
INFO - 2023-07-29 05:43:31 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:43:31 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:43:31 --> Utf8 Class Initialized
INFO - 2023-07-29 05:43:31 --> URI Class Initialized
INFO - 2023-07-29 05:43:31 --> Router Class Initialized
INFO - 2023-07-29 05:43:31 --> Output Class Initialized
INFO - 2023-07-29 05:43:31 --> Security Class Initialized
DEBUG - 2023-07-29 05:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:43:31 --> Input Class Initialized
INFO - 2023-07-29 05:43:31 --> Language Class Initialized
INFO - 2023-07-29 05:43:31 --> Language Class Initialized
INFO - 2023-07-29 05:43:31 --> Config Class Initialized
INFO - 2023-07-29 05:43:31 --> Loader Class Initialized
INFO - 2023-07-29 05:43:31 --> Helper loaded: url_helper
INFO - 2023-07-29 05:43:31 --> Helper loaded: file_helper
INFO - 2023-07-29 05:43:31 --> Helper loaded: form_helper
INFO - 2023-07-29 05:43:31 --> Helper loaded: my_helper
INFO - 2023-07-29 05:43:31 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:43:31 --> Controller Class Initialized
DEBUG - 2023-07-29 05:43:31 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-29 05:43:32 --> Final output sent to browser
DEBUG - 2023-07-29 05:43:32 --> Total execution time: 1.1727
INFO - 2023-07-29 05:45:33 --> Config Class Initialized
INFO - 2023-07-29 05:45:33 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:45:33 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:45:33 --> Utf8 Class Initialized
INFO - 2023-07-29 05:45:33 --> URI Class Initialized
INFO - 2023-07-29 05:45:33 --> Router Class Initialized
INFO - 2023-07-29 05:45:33 --> Output Class Initialized
INFO - 2023-07-29 05:45:33 --> Security Class Initialized
DEBUG - 2023-07-29 05:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:45:33 --> Input Class Initialized
INFO - 2023-07-29 05:45:33 --> Language Class Initialized
INFO - 2023-07-29 05:45:33 --> Language Class Initialized
INFO - 2023-07-29 05:45:33 --> Config Class Initialized
INFO - 2023-07-29 05:45:33 --> Loader Class Initialized
INFO - 2023-07-29 05:45:33 --> Helper loaded: url_helper
INFO - 2023-07-29 05:45:33 --> Helper loaded: file_helper
INFO - 2023-07-29 05:45:33 --> Helper loaded: form_helper
INFO - 2023-07-29 05:45:33 --> Helper loaded: my_helper
INFO - 2023-07-29 05:45:33 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:45:33 --> Controller Class Initialized
DEBUG - 2023-07-29 05:45:33 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-29 05:45:35 --> Final output sent to browser
DEBUG - 2023-07-29 05:45:35 --> Total execution time: 1.1443
INFO - 2023-07-29 05:45:56 --> Config Class Initialized
INFO - 2023-07-29 05:45:56 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:45:56 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:45:56 --> Utf8 Class Initialized
INFO - 2023-07-29 05:45:56 --> URI Class Initialized
INFO - 2023-07-29 05:45:56 --> Router Class Initialized
INFO - 2023-07-29 05:45:56 --> Output Class Initialized
INFO - 2023-07-29 05:45:56 --> Security Class Initialized
DEBUG - 2023-07-29 05:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:45:56 --> Input Class Initialized
INFO - 2023-07-29 05:45:56 --> Language Class Initialized
INFO - 2023-07-29 05:45:56 --> Language Class Initialized
INFO - 2023-07-29 05:45:56 --> Config Class Initialized
INFO - 2023-07-29 05:45:56 --> Loader Class Initialized
INFO - 2023-07-29 05:45:56 --> Helper loaded: url_helper
INFO - 2023-07-29 05:45:56 --> Helper loaded: file_helper
INFO - 2023-07-29 05:45:56 --> Helper loaded: form_helper
INFO - 2023-07-29 05:45:56 --> Helper loaded: my_helper
INFO - 2023-07-29 05:45:56 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:45:56 --> Controller Class Initialized
DEBUG - 2023-07-29 05:45:56 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-29 05:45:57 --> Final output sent to browser
DEBUG - 2023-07-29 05:45:57 --> Total execution time: 1.1045
INFO - 2023-07-29 05:49:45 --> Config Class Initialized
INFO - 2023-07-29 05:49:45 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:49:45 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:49:45 --> Utf8 Class Initialized
INFO - 2023-07-29 05:49:45 --> URI Class Initialized
INFO - 2023-07-29 05:49:45 --> Router Class Initialized
INFO - 2023-07-29 05:49:45 --> Output Class Initialized
INFO - 2023-07-29 05:49:45 --> Security Class Initialized
DEBUG - 2023-07-29 05:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:49:45 --> Input Class Initialized
INFO - 2023-07-29 05:49:45 --> Language Class Initialized
INFO - 2023-07-29 05:49:45 --> Language Class Initialized
INFO - 2023-07-29 05:49:45 --> Config Class Initialized
INFO - 2023-07-29 05:49:45 --> Loader Class Initialized
INFO - 2023-07-29 05:49:45 --> Helper loaded: url_helper
INFO - 2023-07-29 05:49:45 --> Helper loaded: file_helper
INFO - 2023-07-29 05:49:45 --> Helper loaded: form_helper
INFO - 2023-07-29 05:49:45 --> Helper loaded: my_helper
INFO - 2023-07-29 05:49:45 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:49:45 --> Controller Class Initialized
DEBUG - 2023-07-29 05:49:45 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-29 05:49:46 --> Final output sent to browser
DEBUG - 2023-07-29 05:49:46 --> Total execution time: 1.0877
INFO - 2023-07-29 05:49:58 --> Config Class Initialized
INFO - 2023-07-29 05:49:58 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:49:58 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:49:58 --> Utf8 Class Initialized
INFO - 2023-07-29 05:49:58 --> URI Class Initialized
INFO - 2023-07-29 05:49:58 --> Router Class Initialized
INFO - 2023-07-29 05:49:58 --> Output Class Initialized
INFO - 2023-07-29 05:49:58 --> Security Class Initialized
DEBUG - 2023-07-29 05:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:49:58 --> Input Class Initialized
INFO - 2023-07-29 05:49:58 --> Language Class Initialized
INFO - 2023-07-29 05:49:58 --> Language Class Initialized
INFO - 2023-07-29 05:49:58 --> Config Class Initialized
INFO - 2023-07-29 05:49:58 --> Loader Class Initialized
INFO - 2023-07-29 05:49:58 --> Helper loaded: url_helper
INFO - 2023-07-29 05:49:58 --> Helper loaded: file_helper
INFO - 2023-07-29 05:49:58 --> Helper loaded: form_helper
INFO - 2023-07-29 05:49:58 --> Helper loaded: my_helper
INFO - 2023-07-29 05:49:58 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:49:58 --> Controller Class Initialized
DEBUG - 2023-07-29 05:49:58 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-29 05:49:59 --> Final output sent to browser
DEBUG - 2023-07-29 05:49:59 --> Total execution time: 1.0611
INFO - 2023-07-29 05:50:25 --> Config Class Initialized
INFO - 2023-07-29 05:50:25 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:50:25 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:50:25 --> Utf8 Class Initialized
INFO - 2023-07-29 05:50:25 --> URI Class Initialized
INFO - 2023-07-29 05:50:25 --> Router Class Initialized
INFO - 2023-07-29 05:50:25 --> Output Class Initialized
INFO - 2023-07-29 05:50:25 --> Security Class Initialized
DEBUG - 2023-07-29 05:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:50:25 --> Input Class Initialized
INFO - 2023-07-29 05:50:25 --> Language Class Initialized
INFO - 2023-07-29 05:50:25 --> Language Class Initialized
INFO - 2023-07-29 05:50:25 --> Config Class Initialized
INFO - 2023-07-29 05:50:25 --> Loader Class Initialized
INFO - 2023-07-29 05:50:25 --> Helper loaded: url_helper
INFO - 2023-07-29 05:50:25 --> Helper loaded: file_helper
INFO - 2023-07-29 05:50:25 --> Helper loaded: form_helper
INFO - 2023-07-29 05:50:25 --> Helper loaded: my_helper
INFO - 2023-07-29 05:50:25 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:50:25 --> Controller Class Initialized
DEBUG - 2023-07-29 05:50:26 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-29 05:50:27 --> Final output sent to browser
DEBUG - 2023-07-29 05:50:27 --> Total execution time: 2.3884
INFO - 2023-07-29 05:50:42 --> Config Class Initialized
INFO - 2023-07-29 05:50:42 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:50:42 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:50:42 --> Utf8 Class Initialized
INFO - 2023-07-29 05:50:42 --> URI Class Initialized
INFO - 2023-07-29 05:50:42 --> Router Class Initialized
INFO - 2023-07-29 05:50:42 --> Output Class Initialized
INFO - 2023-07-29 05:50:42 --> Security Class Initialized
DEBUG - 2023-07-29 05:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:50:42 --> Input Class Initialized
INFO - 2023-07-29 05:50:42 --> Language Class Initialized
INFO - 2023-07-29 05:50:42 --> Language Class Initialized
INFO - 2023-07-29 05:50:42 --> Config Class Initialized
INFO - 2023-07-29 05:50:42 --> Loader Class Initialized
INFO - 2023-07-29 05:50:42 --> Helper loaded: url_helper
INFO - 2023-07-29 05:50:42 --> Helper loaded: file_helper
INFO - 2023-07-29 05:50:42 --> Helper loaded: form_helper
INFO - 2023-07-29 05:50:42 --> Helper loaded: my_helper
INFO - 2023-07-29 05:50:42 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:50:42 --> Controller Class Initialized
DEBUG - 2023-07-29 05:50:42 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-29 05:50:43 --> Final output sent to browser
DEBUG - 2023-07-29 05:50:43 --> Total execution time: 1.2215
INFO - 2023-07-29 05:51:26 --> Config Class Initialized
INFO - 2023-07-29 05:51:26 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:51:26 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:51:26 --> Utf8 Class Initialized
INFO - 2023-07-29 05:51:26 --> URI Class Initialized
INFO - 2023-07-29 05:51:26 --> Router Class Initialized
INFO - 2023-07-29 05:51:26 --> Output Class Initialized
INFO - 2023-07-29 05:51:26 --> Security Class Initialized
DEBUG - 2023-07-29 05:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:51:26 --> Input Class Initialized
INFO - 2023-07-29 05:51:26 --> Language Class Initialized
INFO - 2023-07-29 05:51:26 --> Language Class Initialized
INFO - 2023-07-29 05:51:26 --> Config Class Initialized
INFO - 2023-07-29 05:51:26 --> Loader Class Initialized
INFO - 2023-07-29 05:51:26 --> Helper loaded: url_helper
INFO - 2023-07-29 05:51:26 --> Helper loaded: file_helper
INFO - 2023-07-29 05:51:26 --> Helper loaded: form_helper
INFO - 2023-07-29 05:51:26 --> Helper loaded: my_helper
INFO - 2023-07-29 05:51:26 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:51:26 --> Controller Class Initialized
DEBUG - 2023-07-29 05:51:26 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-29 05:51:27 --> Final output sent to browser
DEBUG - 2023-07-29 05:51:27 --> Total execution time: 1.1625
INFO - 2023-07-29 05:51:47 --> Config Class Initialized
INFO - 2023-07-29 05:51:47 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:51:47 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:51:47 --> Utf8 Class Initialized
INFO - 2023-07-29 05:51:47 --> URI Class Initialized
INFO - 2023-07-29 05:51:47 --> Router Class Initialized
INFO - 2023-07-29 05:51:47 --> Output Class Initialized
INFO - 2023-07-29 05:51:47 --> Security Class Initialized
DEBUG - 2023-07-29 05:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:51:47 --> Input Class Initialized
INFO - 2023-07-29 05:51:47 --> Language Class Initialized
INFO - 2023-07-29 05:51:47 --> Language Class Initialized
INFO - 2023-07-29 05:51:47 --> Config Class Initialized
INFO - 2023-07-29 05:51:47 --> Loader Class Initialized
INFO - 2023-07-29 05:51:47 --> Helper loaded: url_helper
INFO - 2023-07-29 05:51:47 --> Helper loaded: file_helper
INFO - 2023-07-29 05:51:47 --> Helper loaded: form_helper
INFO - 2023-07-29 05:51:47 --> Helper loaded: my_helper
INFO - 2023-07-29 05:51:47 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:51:47 --> Controller Class Initialized
DEBUG - 2023-07-29 05:51:47 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-29 05:51:48 --> Final output sent to browser
DEBUG - 2023-07-29 05:51:48 --> Total execution time: 1.1073
INFO - 2023-07-29 05:51:53 --> Config Class Initialized
INFO - 2023-07-29 05:51:53 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:51:53 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:51:53 --> Utf8 Class Initialized
INFO - 2023-07-29 05:51:53 --> URI Class Initialized
INFO - 2023-07-29 05:51:53 --> Router Class Initialized
INFO - 2023-07-29 05:51:53 --> Output Class Initialized
INFO - 2023-07-29 05:51:53 --> Security Class Initialized
DEBUG - 2023-07-29 05:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:51:53 --> Input Class Initialized
INFO - 2023-07-29 05:51:53 --> Language Class Initialized
ERROR - 2023-07-29 05:51:53 --> 404 Page Not Found: /index
INFO - 2023-07-29 05:53:04 --> Config Class Initialized
INFO - 2023-07-29 05:53:04 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:53:04 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:53:04 --> Utf8 Class Initialized
INFO - 2023-07-29 05:53:04 --> URI Class Initialized
INFO - 2023-07-29 05:53:04 --> Router Class Initialized
INFO - 2023-07-29 05:53:04 --> Output Class Initialized
INFO - 2023-07-29 05:53:04 --> Security Class Initialized
DEBUG - 2023-07-29 05:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:53:04 --> Input Class Initialized
INFO - 2023-07-29 05:53:04 --> Language Class Initialized
INFO - 2023-07-29 05:53:04 --> Language Class Initialized
INFO - 2023-07-29 05:53:04 --> Config Class Initialized
INFO - 2023-07-29 05:53:04 --> Loader Class Initialized
INFO - 2023-07-29 05:53:04 --> Helper loaded: url_helper
INFO - 2023-07-29 05:53:04 --> Helper loaded: file_helper
INFO - 2023-07-29 05:53:04 --> Helper loaded: form_helper
INFO - 2023-07-29 05:53:04 --> Helper loaded: my_helper
INFO - 2023-07-29 05:53:04 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:53:04 --> Controller Class Initialized
DEBUG - 2023-07-29 05:53:04 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
ERROR - 2023-07-29 05:53:05 --> Severity: Warning --> unlink(C:\xampp\tmp/__tcpdf_1bcf05103320ad6b5260ae654afb5f95_imgmask_alpha_bbf70f351151ae27d2f6bb0d9478645a): No such file or directory C:\xampp\htdocs\myraportk13\bintaro\primary\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7801
ERROR - 2023-07-29 05:53:05 --> Severity: Warning --> unlink(C:\xampp\tmp/__tcpdf_1bcf05103320ad6b5260ae654afb5f95_imgmask_plain_bbf70f351151ae27d2f6bb0d9478645a): No such file or directory C:\xampp\htdocs\myraportk13\bintaro\primary\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7801
ERROR - 2023-07-29 05:53:05 --> Severity: Warning --> unlink(C:\xampp\tmp/__tcpdf_1bcf05103320ad6b5260ae654afb5f95_imgmask_alpha_7de96fd9f6bd1ee181eca7a687e2e5f9): No such file or directory C:\xampp\htdocs\myraportk13\bintaro\primary\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7801
ERROR - 2023-07-29 05:53:05 --> Severity: Warning --> unlink(C:\xampp\tmp/__tcpdf_1bcf05103320ad6b5260ae654afb5f95_imgmask_plain_7de96fd9f6bd1ee181eca7a687e2e5f9): No such file or directory C:\xampp\htdocs\myraportk13\bintaro\primary\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7801
ERROR - 2023-07-29 05:53:05 --> Severity: error --> Exception: TCPDF ERROR: Could not include font definition file: roboto C:\xampp\htdocs\myraportk13\bintaro\primary\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 2950
ERROR - 2023-07-29 05:53:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\bintaro\primary\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\bintaro\primary\system\core\Common.php 570
INFO - 2023-07-29 05:53:23 --> Config Class Initialized
INFO - 2023-07-29 05:53:23 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:53:23 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:53:23 --> Utf8 Class Initialized
INFO - 2023-07-29 05:53:23 --> URI Class Initialized
INFO - 2023-07-29 05:53:23 --> Router Class Initialized
INFO - 2023-07-29 05:53:23 --> Output Class Initialized
INFO - 2023-07-29 05:53:23 --> Security Class Initialized
DEBUG - 2023-07-29 05:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:53:23 --> Input Class Initialized
INFO - 2023-07-29 05:53:23 --> Language Class Initialized
INFO - 2023-07-29 05:53:23 --> Language Class Initialized
INFO - 2023-07-29 05:53:23 --> Config Class Initialized
INFO - 2023-07-29 05:53:23 --> Loader Class Initialized
INFO - 2023-07-29 05:53:23 --> Helper loaded: url_helper
INFO - 2023-07-29 05:53:23 --> Helper loaded: file_helper
INFO - 2023-07-29 05:53:23 --> Helper loaded: form_helper
INFO - 2023-07-29 05:53:23 --> Helper loaded: my_helper
INFO - 2023-07-29 05:53:23 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:53:23 --> Controller Class Initialized
DEBUG - 2023-07-29 05:53:23 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-29 05:53:24 --> Final output sent to browser
DEBUG - 2023-07-29 05:53:24 --> Total execution time: 1.0784
INFO - 2023-07-29 05:53:50 --> Config Class Initialized
INFO - 2023-07-29 05:53:50 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:53:50 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:53:50 --> Utf8 Class Initialized
INFO - 2023-07-29 05:53:50 --> URI Class Initialized
INFO - 2023-07-29 05:53:50 --> Router Class Initialized
INFO - 2023-07-29 05:53:50 --> Output Class Initialized
INFO - 2023-07-29 05:53:50 --> Security Class Initialized
DEBUG - 2023-07-29 05:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:53:50 --> Input Class Initialized
INFO - 2023-07-29 05:53:50 --> Language Class Initialized
INFO - 2023-07-29 05:53:50 --> Language Class Initialized
INFO - 2023-07-29 05:53:50 --> Config Class Initialized
INFO - 2023-07-29 05:53:50 --> Loader Class Initialized
INFO - 2023-07-29 05:53:50 --> Helper loaded: url_helper
INFO - 2023-07-29 05:53:50 --> Helper loaded: file_helper
INFO - 2023-07-29 05:53:50 --> Helper loaded: form_helper
INFO - 2023-07-29 05:53:50 --> Helper loaded: my_helper
INFO - 2023-07-29 05:53:50 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:53:50 --> Controller Class Initialized
DEBUG - 2023-07-29 05:53:50 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
ERROR - 2023-07-29 05:53:51 --> Severity: Warning --> unlink(C:\xampp\tmp/__tcpdf_8cda5cf7fb2efe919d84cf8df1bc1e30_imgmask_alpha_bbf70f351151ae27d2f6bb0d9478645a): No such file or directory C:\xampp\htdocs\myraportk13\bintaro\primary\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7801
ERROR - 2023-07-29 05:53:51 --> Severity: Warning --> unlink(C:\xampp\tmp/__tcpdf_8cda5cf7fb2efe919d84cf8df1bc1e30_imgmask_plain_bbf70f351151ae27d2f6bb0d9478645a): No such file or directory C:\xampp\htdocs\myraportk13\bintaro\primary\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7801
ERROR - 2023-07-29 05:53:51 --> Severity: Warning --> unlink(C:\xampp\tmp/__tcpdf_8cda5cf7fb2efe919d84cf8df1bc1e30_imgmask_alpha_7de96fd9f6bd1ee181eca7a687e2e5f9): No such file or directory C:\xampp\htdocs\myraportk13\bintaro\primary\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7801
ERROR - 2023-07-29 05:53:51 --> Severity: Warning --> unlink(C:\xampp\tmp/__tcpdf_8cda5cf7fb2efe919d84cf8df1bc1e30_imgmask_plain_7de96fd9f6bd1ee181eca7a687e2e5f9): No such file or directory C:\xampp\htdocs\myraportk13\bintaro\primary\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7801
ERROR - 2023-07-29 05:53:51 --> Severity: error --> Exception: TCPDF ERROR: Could not include font definition file: roboto C:\xampp\htdocs\myraportk13\bintaro\primary\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 2950
ERROR - 2023-07-29 05:53:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\bintaro\primary\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\bintaro\primary\system\core\Common.php 570
INFO - 2023-07-29 05:55:00 --> Config Class Initialized
INFO - 2023-07-29 05:55:00 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:55:00 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:55:00 --> Utf8 Class Initialized
INFO - 2023-07-29 05:55:00 --> URI Class Initialized
INFO - 2023-07-29 05:55:00 --> Router Class Initialized
INFO - 2023-07-29 05:55:00 --> Output Class Initialized
INFO - 2023-07-29 05:55:00 --> Security Class Initialized
DEBUG - 2023-07-29 05:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:55:00 --> Input Class Initialized
INFO - 2023-07-29 05:55:00 --> Language Class Initialized
INFO - 2023-07-29 05:55:00 --> Language Class Initialized
INFO - 2023-07-29 05:55:00 --> Config Class Initialized
INFO - 2023-07-29 05:55:00 --> Loader Class Initialized
INFO - 2023-07-29 05:55:00 --> Helper loaded: url_helper
INFO - 2023-07-29 05:55:00 --> Helper loaded: file_helper
INFO - 2023-07-29 05:55:00 --> Helper loaded: form_helper
INFO - 2023-07-29 05:55:00 --> Helper loaded: my_helper
INFO - 2023-07-29 05:55:00 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:55:00 --> Controller Class Initialized
DEBUG - 2023-07-29 05:55:00 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
ERROR - 2023-07-29 05:55:01 --> Severity: Warning --> unlink(C:\xampp\tmp/__tcpdf_4443b257f71e38a5bf063c27e8f098e1_imgmask_alpha_bbf70f351151ae27d2f6bb0d9478645a): No such file or directory C:\xampp\htdocs\myraportk13\bintaro\primary\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7801
ERROR - 2023-07-29 05:55:01 --> Severity: Warning --> unlink(C:\xampp\tmp/__tcpdf_4443b257f71e38a5bf063c27e8f098e1_imgmask_plain_bbf70f351151ae27d2f6bb0d9478645a): No such file or directory C:\xampp\htdocs\myraportk13\bintaro\primary\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7801
ERROR - 2023-07-29 05:55:01 --> Severity: Warning --> unlink(C:\xampp\tmp/__tcpdf_4443b257f71e38a5bf063c27e8f098e1_imgmask_alpha_7de96fd9f6bd1ee181eca7a687e2e5f9): No such file or directory C:\xampp\htdocs\myraportk13\bintaro\primary\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7801
ERROR - 2023-07-29 05:55:01 --> Severity: Warning --> unlink(C:\xampp\tmp/__tcpdf_4443b257f71e38a5bf063c27e8f098e1_imgmask_plain_7de96fd9f6bd1ee181eca7a687e2e5f9): No such file or directory C:\xampp\htdocs\myraportk13\bintaro\primary\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7801
ERROR - 2023-07-29 05:55:01 --> Severity: error --> Exception: TCPDF ERROR: Could not include font definition file: helvetica neue C:\xampp\htdocs\myraportk13\bintaro\primary\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 2950
ERROR - 2023-07-29 05:55:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\bintaro\primary\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\bintaro\primary\system\core\Common.php 570
INFO - 2023-07-29 05:55:18 --> Config Class Initialized
INFO - 2023-07-29 05:55:18 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:55:18 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:55:18 --> Utf8 Class Initialized
INFO - 2023-07-29 05:55:18 --> URI Class Initialized
INFO - 2023-07-29 05:55:18 --> Router Class Initialized
INFO - 2023-07-29 05:55:18 --> Output Class Initialized
INFO - 2023-07-29 05:55:18 --> Security Class Initialized
DEBUG - 2023-07-29 05:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:55:18 --> Input Class Initialized
INFO - 2023-07-29 05:55:18 --> Language Class Initialized
INFO - 2023-07-29 05:55:18 --> Language Class Initialized
INFO - 2023-07-29 05:55:18 --> Config Class Initialized
INFO - 2023-07-29 05:55:18 --> Loader Class Initialized
INFO - 2023-07-29 05:55:18 --> Helper loaded: url_helper
INFO - 2023-07-29 05:55:18 --> Helper loaded: file_helper
INFO - 2023-07-29 05:55:18 --> Helper loaded: form_helper
INFO - 2023-07-29 05:55:18 --> Helper loaded: my_helper
INFO - 2023-07-29 05:55:18 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:55:18 --> Controller Class Initialized
DEBUG - 2023-07-29 05:55:18 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-29 05:55:19 --> Final output sent to browser
DEBUG - 2023-07-29 05:55:19 --> Total execution time: 1.0956
INFO - 2023-07-29 05:55:36 --> Config Class Initialized
INFO - 2023-07-29 05:55:36 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:55:36 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:55:36 --> Utf8 Class Initialized
INFO - 2023-07-29 05:55:36 --> URI Class Initialized
INFO - 2023-07-29 05:55:36 --> Router Class Initialized
INFO - 2023-07-29 05:55:36 --> Output Class Initialized
INFO - 2023-07-29 05:55:36 --> Security Class Initialized
DEBUG - 2023-07-29 05:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:55:36 --> Input Class Initialized
INFO - 2023-07-29 05:55:36 --> Language Class Initialized
INFO - 2023-07-29 05:55:36 --> Language Class Initialized
INFO - 2023-07-29 05:55:36 --> Config Class Initialized
INFO - 2023-07-29 05:55:36 --> Loader Class Initialized
INFO - 2023-07-29 05:55:36 --> Helper loaded: url_helper
INFO - 2023-07-29 05:55:36 --> Helper loaded: file_helper
INFO - 2023-07-29 05:55:36 --> Helper loaded: form_helper
INFO - 2023-07-29 05:55:36 --> Helper loaded: my_helper
INFO - 2023-07-29 05:55:36 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:55:36 --> Controller Class Initialized
DEBUG - 2023-07-29 05:55:36 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
ERROR - 2023-07-29 05:55:37 --> Severity: Warning --> unlink(C:\xampp\tmp/__tcpdf_7f7f2a67eb9321ed7de6df4f32710e8c_imgmask_alpha_bbf70f351151ae27d2f6bb0d9478645a): No such file or directory C:\xampp\htdocs\myraportk13\bintaro\primary\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7801
ERROR - 2023-07-29 05:55:37 --> Severity: Warning --> unlink(C:\xampp\tmp/__tcpdf_7f7f2a67eb9321ed7de6df4f32710e8c_imgmask_plain_bbf70f351151ae27d2f6bb0d9478645a): No such file or directory C:\xampp\htdocs\myraportk13\bintaro\primary\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7801
ERROR - 2023-07-29 05:55:37 --> Severity: Warning --> unlink(C:\xampp\tmp/__tcpdf_7f7f2a67eb9321ed7de6df4f32710e8c_imgmask_alpha_7de96fd9f6bd1ee181eca7a687e2e5f9): No such file or directory C:\xampp\htdocs\myraportk13\bintaro\primary\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7801
ERROR - 2023-07-29 05:55:37 --> Severity: Warning --> unlink(C:\xampp\tmp/__tcpdf_7f7f2a67eb9321ed7de6df4f32710e8c_imgmask_plain_7de96fd9f6bd1ee181eca7a687e2e5f9): No such file or directory C:\xampp\htdocs\myraportk13\bintaro\primary\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7801
ERROR - 2023-07-29 05:55:37 --> Severity: error --> Exception: TCPDF ERROR: Could not include font definition file: sans-serif C:\xampp\htdocs\myraportk13\bintaro\primary\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 2950
ERROR - 2023-07-29 05:55:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\bintaro\primary\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\bintaro\primary\system\core\Common.php 570
INFO - 2023-07-29 05:56:32 --> Config Class Initialized
INFO - 2023-07-29 05:56:32 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:56:32 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:56:32 --> Utf8 Class Initialized
INFO - 2023-07-29 05:56:32 --> URI Class Initialized
INFO - 2023-07-29 05:56:32 --> Router Class Initialized
INFO - 2023-07-29 05:56:32 --> Output Class Initialized
INFO - 2023-07-29 05:56:32 --> Security Class Initialized
DEBUG - 2023-07-29 05:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:56:32 --> Input Class Initialized
INFO - 2023-07-29 05:56:32 --> Language Class Initialized
INFO - 2023-07-29 05:56:32 --> Language Class Initialized
INFO - 2023-07-29 05:56:32 --> Config Class Initialized
INFO - 2023-07-29 05:56:32 --> Loader Class Initialized
INFO - 2023-07-29 05:56:32 --> Helper loaded: url_helper
INFO - 2023-07-29 05:56:32 --> Helper loaded: file_helper
INFO - 2023-07-29 05:56:32 --> Helper loaded: form_helper
INFO - 2023-07-29 05:56:32 --> Helper loaded: my_helper
INFO - 2023-07-29 05:56:32 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:56:32 --> Controller Class Initialized
DEBUG - 2023-07-29 05:56:32 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
ERROR - 2023-07-29 05:56:33 --> Severity: Warning --> unlink(C:\xampp\tmp/__tcpdf_b91411a63c9a60311876decb5beda07b_imgmask_alpha_bbf70f351151ae27d2f6bb0d9478645a): No such file or directory C:\xampp\htdocs\myraportk13\bintaro\primary\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7801
ERROR - 2023-07-29 05:56:33 --> Severity: Warning --> unlink(C:\xampp\tmp/__tcpdf_b91411a63c9a60311876decb5beda07b_imgmask_plain_bbf70f351151ae27d2f6bb0d9478645a): No such file or directory C:\xampp\htdocs\myraportk13\bintaro\primary\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7801
ERROR - 2023-07-29 05:56:33 --> Severity: Warning --> unlink(C:\xampp\tmp/__tcpdf_b91411a63c9a60311876decb5beda07b_imgmask_alpha_7de96fd9f6bd1ee181eca7a687e2e5f9): No such file or directory C:\xampp\htdocs\myraportk13\bintaro\primary\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7801
ERROR - 2023-07-29 05:56:33 --> Severity: Warning --> unlink(C:\xampp\tmp/__tcpdf_b91411a63c9a60311876decb5beda07b_imgmask_plain_7de96fd9f6bd1ee181eca7a687e2e5f9): No such file or directory C:\xampp\htdocs\myraportk13\bintaro\primary\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7801
ERROR - 2023-07-29 05:56:33 --> Severity: error --> Exception: TCPDF ERROR: Could not include font definition file: sans-serif C:\xampp\htdocs\myraportk13\bintaro\primary\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 2950
ERROR - 2023-07-29 05:56:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\bintaro\primary\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\bintaro\primary\system\core\Common.php 570
INFO - 2023-07-29 05:56:39 --> Config Class Initialized
INFO - 2023-07-29 05:56:39 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:56:39 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:56:39 --> Utf8 Class Initialized
INFO - 2023-07-29 05:56:39 --> URI Class Initialized
INFO - 2023-07-29 05:56:39 --> Router Class Initialized
INFO - 2023-07-29 05:56:39 --> Output Class Initialized
INFO - 2023-07-29 05:56:39 --> Security Class Initialized
DEBUG - 2023-07-29 05:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:56:39 --> Input Class Initialized
INFO - 2023-07-29 05:56:39 --> Language Class Initialized
INFO - 2023-07-29 05:56:39 --> Language Class Initialized
INFO - 2023-07-29 05:56:39 --> Config Class Initialized
INFO - 2023-07-29 05:56:39 --> Loader Class Initialized
INFO - 2023-07-29 05:56:39 --> Helper loaded: url_helper
INFO - 2023-07-29 05:56:39 --> Helper loaded: file_helper
INFO - 2023-07-29 05:56:39 --> Helper loaded: form_helper
INFO - 2023-07-29 05:56:39 --> Helper loaded: my_helper
INFO - 2023-07-29 05:56:39 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:56:39 --> Controller Class Initialized
DEBUG - 2023-07-29 05:56:39 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
ERROR - 2023-07-29 05:56:40 --> Severity: Warning --> unlink(C:\xampp\tmp/__tcpdf_f23cba76c82df638df5fed83a278006b_imgmask_alpha_bbf70f351151ae27d2f6bb0d9478645a): No such file or directory C:\xampp\htdocs\myraportk13\bintaro\primary\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7801
ERROR - 2023-07-29 05:56:40 --> Severity: Warning --> unlink(C:\xampp\tmp/__tcpdf_f23cba76c82df638df5fed83a278006b_imgmask_plain_bbf70f351151ae27d2f6bb0d9478645a): No such file or directory C:\xampp\htdocs\myraportk13\bintaro\primary\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7801
ERROR - 2023-07-29 05:56:40 --> Severity: Warning --> unlink(C:\xampp\tmp/__tcpdf_f23cba76c82df638df5fed83a278006b_imgmask_alpha_7de96fd9f6bd1ee181eca7a687e2e5f9): No such file or directory C:\xampp\htdocs\myraportk13\bintaro\primary\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7801
ERROR - 2023-07-29 05:56:40 --> Severity: Warning --> unlink(C:\xampp\tmp/__tcpdf_f23cba76c82df638df5fed83a278006b_imgmask_plain_7de96fd9f6bd1ee181eca7a687e2e5f9): No such file or directory C:\xampp\htdocs\myraportk13\bintaro\primary\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7801
ERROR - 2023-07-29 05:56:40 --> Severity: error --> Exception: TCPDF ERROR: Could not include font definition file: sans-serif C:\xampp\htdocs\myraportk13\bintaro\primary\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 2950
ERROR - 2023-07-29 05:56:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\bintaro\primary\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\bintaro\primary\system\core\Common.php 570
INFO - 2023-07-29 05:56:56 --> Config Class Initialized
INFO - 2023-07-29 05:56:56 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:56:56 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:56:56 --> Utf8 Class Initialized
INFO - 2023-07-29 05:56:56 --> URI Class Initialized
INFO - 2023-07-29 05:56:56 --> Router Class Initialized
INFO - 2023-07-29 05:56:56 --> Output Class Initialized
INFO - 2023-07-29 05:56:56 --> Security Class Initialized
DEBUG - 2023-07-29 05:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:56:56 --> Input Class Initialized
INFO - 2023-07-29 05:56:56 --> Language Class Initialized
INFO - 2023-07-29 05:56:56 --> Language Class Initialized
INFO - 2023-07-29 05:56:56 --> Config Class Initialized
INFO - 2023-07-29 05:56:56 --> Loader Class Initialized
INFO - 2023-07-29 05:56:56 --> Helper loaded: url_helper
INFO - 2023-07-29 05:56:56 --> Helper loaded: file_helper
INFO - 2023-07-29 05:56:56 --> Helper loaded: form_helper
INFO - 2023-07-29 05:56:56 --> Helper loaded: my_helper
INFO - 2023-07-29 05:56:56 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:56:56 --> Controller Class Initialized
DEBUG - 2023-07-29 05:56:56 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-29 05:56:57 --> Final output sent to browser
DEBUG - 2023-07-29 05:56:57 --> Total execution time: 1.1013
INFO - 2023-07-29 05:57:33 --> Config Class Initialized
INFO - 2023-07-29 05:57:33 --> Hooks Class Initialized
DEBUG - 2023-07-29 05:57:33 --> UTF-8 Support Enabled
INFO - 2023-07-29 05:57:33 --> Utf8 Class Initialized
INFO - 2023-07-29 05:57:33 --> URI Class Initialized
INFO - 2023-07-29 05:57:33 --> Router Class Initialized
INFO - 2023-07-29 05:57:33 --> Output Class Initialized
INFO - 2023-07-29 05:57:33 --> Security Class Initialized
DEBUG - 2023-07-29 05:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 05:57:33 --> Input Class Initialized
INFO - 2023-07-29 05:57:33 --> Language Class Initialized
INFO - 2023-07-29 05:57:33 --> Language Class Initialized
INFO - 2023-07-29 05:57:33 --> Config Class Initialized
INFO - 2023-07-29 05:57:33 --> Loader Class Initialized
INFO - 2023-07-29 05:57:33 --> Helper loaded: url_helper
INFO - 2023-07-29 05:57:33 --> Helper loaded: file_helper
INFO - 2023-07-29 05:57:33 --> Helper loaded: form_helper
INFO - 2023-07-29 05:57:33 --> Helper loaded: my_helper
INFO - 2023-07-29 05:57:33 --> Database Driver Class Initialized
DEBUG - 2023-07-29 05:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 05:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 05:57:33 --> Controller Class Initialized
DEBUG - 2023-07-29 05:57:33 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-29 05:57:34 --> Final output sent to browser
DEBUG - 2023-07-29 05:57:34 --> Total execution time: 1.2923
INFO - 2023-07-29 06:00:31 --> Config Class Initialized
INFO - 2023-07-29 06:00:31 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:00:31 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:00:31 --> Utf8 Class Initialized
INFO - 2023-07-29 06:00:31 --> URI Class Initialized
INFO - 2023-07-29 06:00:31 --> Router Class Initialized
INFO - 2023-07-29 06:00:31 --> Output Class Initialized
INFO - 2023-07-29 06:00:31 --> Security Class Initialized
DEBUG - 2023-07-29 06:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:00:31 --> Input Class Initialized
INFO - 2023-07-29 06:00:31 --> Language Class Initialized
INFO - 2023-07-29 06:00:31 --> Language Class Initialized
INFO - 2023-07-29 06:00:31 --> Config Class Initialized
INFO - 2023-07-29 06:00:31 --> Loader Class Initialized
INFO - 2023-07-29 06:00:31 --> Helper loaded: url_helper
INFO - 2023-07-29 06:00:31 --> Helper loaded: file_helper
INFO - 2023-07-29 06:00:31 --> Helper loaded: form_helper
INFO - 2023-07-29 06:00:31 --> Helper loaded: my_helper
INFO - 2023-07-29 06:00:31 --> Database Driver Class Initialized
DEBUG - 2023-07-29 06:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 06:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 06:00:31 --> Controller Class Initialized
DEBUG - 2023-07-29 06:00:31 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-29 06:00:32 --> Final output sent to browser
DEBUG - 2023-07-29 06:00:32 --> Total execution time: 1.1989
INFO - 2023-07-29 06:00:54 --> Config Class Initialized
INFO - 2023-07-29 06:00:54 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:00:54 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:00:54 --> Utf8 Class Initialized
INFO - 2023-07-29 06:00:54 --> URI Class Initialized
INFO - 2023-07-29 06:00:54 --> Router Class Initialized
INFO - 2023-07-29 06:00:54 --> Output Class Initialized
INFO - 2023-07-29 06:00:54 --> Security Class Initialized
DEBUG - 2023-07-29 06:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:00:54 --> Input Class Initialized
INFO - 2023-07-29 06:00:54 --> Language Class Initialized
INFO - 2023-07-29 06:00:54 --> Language Class Initialized
INFO - 2023-07-29 06:00:54 --> Config Class Initialized
INFO - 2023-07-29 06:00:54 --> Loader Class Initialized
INFO - 2023-07-29 06:00:54 --> Helper loaded: url_helper
INFO - 2023-07-29 06:00:54 --> Helper loaded: file_helper
INFO - 2023-07-29 06:00:54 --> Helper loaded: form_helper
INFO - 2023-07-29 06:00:54 --> Helper loaded: my_helper
INFO - 2023-07-29 06:00:54 --> Database Driver Class Initialized
DEBUG - 2023-07-29 06:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 06:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 06:00:54 --> Controller Class Initialized
DEBUG - 2023-07-29 06:00:54 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-29 06:00:55 --> Final output sent to browser
DEBUG - 2023-07-29 06:00:55 --> Total execution time: 1.1889
INFO - 2023-07-29 06:01:09 --> Config Class Initialized
INFO - 2023-07-29 06:01:09 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:01:09 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:01:09 --> Utf8 Class Initialized
INFO - 2023-07-29 06:01:09 --> URI Class Initialized
INFO - 2023-07-29 06:01:09 --> Router Class Initialized
INFO - 2023-07-29 06:01:09 --> Output Class Initialized
INFO - 2023-07-29 06:01:09 --> Security Class Initialized
DEBUG - 2023-07-29 06:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:01:09 --> Input Class Initialized
INFO - 2023-07-29 06:01:09 --> Language Class Initialized
INFO - 2023-07-29 06:01:09 --> Language Class Initialized
INFO - 2023-07-29 06:01:09 --> Config Class Initialized
INFO - 2023-07-29 06:01:09 --> Loader Class Initialized
INFO - 2023-07-29 06:01:09 --> Helper loaded: url_helper
INFO - 2023-07-29 06:01:09 --> Helper loaded: file_helper
INFO - 2023-07-29 06:01:09 --> Helper loaded: form_helper
INFO - 2023-07-29 06:01:09 --> Helper loaded: my_helper
INFO - 2023-07-29 06:01:09 --> Database Driver Class Initialized
DEBUG - 2023-07-29 06:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 06:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 06:01:09 --> Controller Class Initialized
INFO - 2023-07-29 06:02:11 --> Config Class Initialized
INFO - 2023-07-29 06:02:11 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:02:11 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:02:11 --> Utf8 Class Initialized
INFO - 2023-07-29 06:02:11 --> URI Class Initialized
INFO - 2023-07-29 06:02:11 --> Router Class Initialized
INFO - 2023-07-29 06:02:11 --> Output Class Initialized
INFO - 2023-07-29 06:02:11 --> Security Class Initialized
DEBUG - 2023-07-29 06:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:02:11 --> Input Class Initialized
INFO - 2023-07-29 06:02:11 --> Language Class Initialized
INFO - 2023-07-29 06:02:11 --> Language Class Initialized
INFO - 2023-07-29 06:02:11 --> Config Class Initialized
INFO - 2023-07-29 06:02:11 --> Loader Class Initialized
INFO - 2023-07-29 06:02:11 --> Helper loaded: url_helper
INFO - 2023-07-29 06:02:11 --> Helper loaded: file_helper
INFO - 2023-07-29 06:02:11 --> Helper loaded: form_helper
INFO - 2023-07-29 06:02:11 --> Helper loaded: my_helper
INFO - 2023-07-29 06:02:11 --> Database Driver Class Initialized
DEBUG - 2023-07-29 06:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 06:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 06:02:11 --> Controller Class Initialized
DEBUG - 2023-07-29 06:02:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-07-29 06:02:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 06:02:11 --> Final output sent to browser
DEBUG - 2023-07-29 06:02:11 --> Total execution time: 0.0340
INFO - 2023-07-29 06:02:11 --> Config Class Initialized
INFO - 2023-07-29 06:02:11 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:02:11 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:02:11 --> Utf8 Class Initialized
INFO - 2023-07-29 06:02:11 --> URI Class Initialized
INFO - 2023-07-29 06:02:11 --> Router Class Initialized
INFO - 2023-07-29 06:02:11 --> Output Class Initialized
INFO - 2023-07-29 06:02:11 --> Security Class Initialized
DEBUG - 2023-07-29 06:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:02:11 --> Input Class Initialized
INFO - 2023-07-29 06:02:11 --> Language Class Initialized
INFO - 2023-07-29 06:02:11 --> Language Class Initialized
INFO - 2023-07-29 06:02:11 --> Config Class Initialized
INFO - 2023-07-29 06:02:11 --> Loader Class Initialized
INFO - 2023-07-29 06:02:11 --> Helper loaded: url_helper
INFO - 2023-07-29 06:02:11 --> Helper loaded: file_helper
INFO - 2023-07-29 06:02:11 --> Helper loaded: form_helper
INFO - 2023-07-29 06:02:11 --> Helper loaded: my_helper
INFO - 2023-07-29 06:02:11 --> Database Driver Class Initialized
DEBUG - 2023-07-29 06:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 06:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 06:02:11 --> Controller Class Initialized
INFO - 2023-07-29 06:02:13 --> Config Class Initialized
INFO - 2023-07-29 06:02:13 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:02:13 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:02:13 --> Utf8 Class Initialized
INFO - 2023-07-29 06:02:13 --> URI Class Initialized
INFO - 2023-07-29 06:02:13 --> Router Class Initialized
INFO - 2023-07-29 06:02:13 --> Output Class Initialized
INFO - 2023-07-29 06:02:13 --> Security Class Initialized
DEBUG - 2023-07-29 06:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:02:13 --> Input Class Initialized
INFO - 2023-07-29 06:02:13 --> Language Class Initialized
INFO - 2023-07-29 06:02:13 --> Language Class Initialized
INFO - 2023-07-29 06:02:13 --> Config Class Initialized
INFO - 2023-07-29 06:02:13 --> Loader Class Initialized
INFO - 2023-07-29 06:02:13 --> Helper loaded: url_helper
INFO - 2023-07-29 06:02:13 --> Helper loaded: file_helper
INFO - 2023-07-29 06:02:13 --> Helper loaded: form_helper
INFO - 2023-07-29 06:02:13 --> Helper loaded: my_helper
INFO - 2023-07-29 06:02:13 --> Database Driver Class Initialized
DEBUG - 2023-07-29 06:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 06:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 06:02:13 --> Controller Class Initialized
INFO - 2023-07-29 06:02:13 --> Final output sent to browser
DEBUG - 2023-07-29 06:02:13 --> Total execution time: 0.0360
INFO - 2023-07-29 06:05:38 --> Config Class Initialized
INFO - 2023-07-29 06:05:38 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:05:38 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:05:38 --> Utf8 Class Initialized
INFO - 2023-07-29 06:05:38 --> URI Class Initialized
INFO - 2023-07-29 06:05:38 --> Router Class Initialized
INFO - 2023-07-29 06:05:38 --> Output Class Initialized
INFO - 2023-07-29 06:05:38 --> Security Class Initialized
DEBUG - 2023-07-29 06:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:05:38 --> Input Class Initialized
INFO - 2023-07-29 06:05:38 --> Language Class Initialized
INFO - 2023-07-29 06:05:38 --> Language Class Initialized
INFO - 2023-07-29 06:05:38 --> Config Class Initialized
INFO - 2023-07-29 06:05:38 --> Loader Class Initialized
INFO - 2023-07-29 06:05:38 --> Helper loaded: url_helper
INFO - 2023-07-29 06:05:38 --> Helper loaded: file_helper
INFO - 2023-07-29 06:05:38 --> Helper loaded: form_helper
INFO - 2023-07-29 06:05:38 --> Helper loaded: my_helper
INFO - 2023-07-29 06:05:38 --> Database Driver Class Initialized
DEBUG - 2023-07-29 06:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 06:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 06:05:38 --> Controller Class Initialized
DEBUG - 2023-07-29 06:05:38 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-07-29 06:05:38 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 06:05:38 --> Final output sent to browser
DEBUG - 2023-07-29 06:05:38 --> Total execution time: 0.0614
INFO - 2023-07-29 06:05:38 --> Config Class Initialized
INFO - 2023-07-29 06:05:38 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:05:38 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:05:38 --> Utf8 Class Initialized
INFO - 2023-07-29 06:05:38 --> URI Class Initialized
INFO - 2023-07-29 06:05:38 --> Router Class Initialized
INFO - 2023-07-29 06:05:38 --> Output Class Initialized
INFO - 2023-07-29 06:05:38 --> Security Class Initialized
DEBUG - 2023-07-29 06:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:05:38 --> Input Class Initialized
INFO - 2023-07-29 06:05:38 --> Language Class Initialized
INFO - 2023-07-29 06:05:38 --> Language Class Initialized
INFO - 2023-07-29 06:05:38 --> Config Class Initialized
INFO - 2023-07-29 06:05:38 --> Loader Class Initialized
INFO - 2023-07-29 06:05:38 --> Helper loaded: url_helper
INFO - 2023-07-29 06:05:38 --> Helper loaded: file_helper
INFO - 2023-07-29 06:05:38 --> Helper loaded: form_helper
INFO - 2023-07-29 06:05:38 --> Helper loaded: my_helper
INFO - 2023-07-29 06:05:38 --> Database Driver Class Initialized
DEBUG - 2023-07-29 06:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 06:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 06:05:38 --> Controller Class Initialized
INFO - 2023-07-29 06:05:40 --> Config Class Initialized
INFO - 2023-07-29 06:05:40 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:05:40 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:05:40 --> Utf8 Class Initialized
INFO - 2023-07-29 06:05:40 --> URI Class Initialized
INFO - 2023-07-29 06:05:40 --> Router Class Initialized
INFO - 2023-07-29 06:05:40 --> Output Class Initialized
INFO - 2023-07-29 06:05:40 --> Security Class Initialized
DEBUG - 2023-07-29 06:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:05:40 --> Input Class Initialized
INFO - 2023-07-29 06:05:40 --> Language Class Initialized
INFO - 2023-07-29 06:05:40 --> Language Class Initialized
INFO - 2023-07-29 06:05:40 --> Config Class Initialized
INFO - 2023-07-29 06:05:40 --> Loader Class Initialized
INFO - 2023-07-29 06:05:40 --> Helper loaded: url_helper
INFO - 2023-07-29 06:05:40 --> Helper loaded: file_helper
INFO - 2023-07-29 06:05:40 --> Helper loaded: form_helper
INFO - 2023-07-29 06:05:40 --> Helper loaded: my_helper
INFO - 2023-07-29 06:05:40 --> Database Driver Class Initialized
DEBUG - 2023-07-29 06:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 06:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 06:05:40 --> Controller Class Initialized
INFO - 2023-07-29 06:05:40 --> Final output sent to browser
DEBUG - 2023-07-29 06:05:40 --> Total execution time: 0.0448
INFO - 2023-07-29 06:05:54 --> Config Class Initialized
INFO - 2023-07-29 06:05:54 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:05:54 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:05:54 --> Utf8 Class Initialized
INFO - 2023-07-29 06:05:54 --> URI Class Initialized
INFO - 2023-07-29 06:05:54 --> Router Class Initialized
INFO - 2023-07-29 06:05:54 --> Output Class Initialized
INFO - 2023-07-29 06:05:54 --> Security Class Initialized
DEBUG - 2023-07-29 06:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:05:54 --> Input Class Initialized
INFO - 2023-07-29 06:05:54 --> Language Class Initialized
ERROR - 2023-07-29 06:05:54 --> 404 Page Not Found: /index
INFO - 2023-07-29 06:06:31 --> Config Class Initialized
INFO - 2023-07-29 06:06:31 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:06:31 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:06:31 --> Utf8 Class Initialized
INFO - 2023-07-29 06:06:31 --> URI Class Initialized
INFO - 2023-07-29 06:06:31 --> Router Class Initialized
INFO - 2023-07-29 06:06:31 --> Output Class Initialized
INFO - 2023-07-29 06:06:31 --> Security Class Initialized
DEBUG - 2023-07-29 06:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:06:31 --> Input Class Initialized
INFO - 2023-07-29 06:06:31 --> Language Class Initialized
INFO - 2023-07-29 06:06:31 --> Language Class Initialized
INFO - 2023-07-29 06:06:31 --> Config Class Initialized
INFO - 2023-07-29 06:06:31 --> Loader Class Initialized
INFO - 2023-07-29 06:06:31 --> Helper loaded: url_helper
INFO - 2023-07-29 06:06:31 --> Helper loaded: file_helper
INFO - 2023-07-29 06:06:31 --> Helper loaded: form_helper
INFO - 2023-07-29 06:06:31 --> Helper loaded: my_helper
INFO - 2023-07-29 06:06:31 --> Database Driver Class Initialized
DEBUG - 2023-07-29 06:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 06:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 06:06:31 --> Controller Class Initialized
DEBUG - 2023-07-29 06:06:31 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-07-29 06:06:31 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 06:06:31 --> Final output sent to browser
DEBUG - 2023-07-29 06:06:31 --> Total execution time: 0.0693
INFO - 2023-07-29 06:06:31 --> Config Class Initialized
INFO - 2023-07-29 06:06:31 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:06:31 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:06:31 --> Utf8 Class Initialized
INFO - 2023-07-29 06:06:31 --> URI Class Initialized
INFO - 2023-07-29 06:06:31 --> Router Class Initialized
INFO - 2023-07-29 06:06:31 --> Output Class Initialized
INFO - 2023-07-29 06:06:31 --> Security Class Initialized
DEBUG - 2023-07-29 06:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:06:31 --> Input Class Initialized
INFO - 2023-07-29 06:06:31 --> Language Class Initialized
INFO - 2023-07-29 06:06:31 --> Language Class Initialized
INFO - 2023-07-29 06:06:31 --> Config Class Initialized
INFO - 2023-07-29 06:06:31 --> Loader Class Initialized
INFO - 2023-07-29 06:06:31 --> Helper loaded: url_helper
INFO - 2023-07-29 06:06:31 --> Helper loaded: file_helper
INFO - 2023-07-29 06:06:31 --> Helper loaded: form_helper
INFO - 2023-07-29 06:06:31 --> Helper loaded: my_helper
INFO - 2023-07-29 06:06:31 --> Database Driver Class Initialized
DEBUG - 2023-07-29 06:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 06:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 06:06:31 --> Controller Class Initialized
INFO - 2023-07-29 06:06:34 --> Config Class Initialized
INFO - 2023-07-29 06:06:34 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:06:34 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:06:34 --> Utf8 Class Initialized
INFO - 2023-07-29 06:06:34 --> URI Class Initialized
INFO - 2023-07-29 06:06:34 --> Router Class Initialized
INFO - 2023-07-29 06:06:34 --> Output Class Initialized
INFO - 2023-07-29 06:06:34 --> Security Class Initialized
DEBUG - 2023-07-29 06:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:06:34 --> Input Class Initialized
INFO - 2023-07-29 06:06:34 --> Language Class Initialized
INFO - 2023-07-29 06:06:34 --> Language Class Initialized
INFO - 2023-07-29 06:06:34 --> Config Class Initialized
INFO - 2023-07-29 06:06:34 --> Loader Class Initialized
INFO - 2023-07-29 06:06:34 --> Helper loaded: url_helper
INFO - 2023-07-29 06:06:34 --> Helper loaded: file_helper
INFO - 2023-07-29 06:06:34 --> Helper loaded: form_helper
INFO - 2023-07-29 06:06:34 --> Helper loaded: my_helper
INFO - 2023-07-29 06:06:34 --> Database Driver Class Initialized
DEBUG - 2023-07-29 06:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 06:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 06:06:34 --> Controller Class Initialized
INFO - 2023-07-29 06:06:34 --> Final output sent to browser
DEBUG - 2023-07-29 06:06:34 --> Total execution time: 0.0311
INFO - 2023-07-29 06:06:52 --> Config Class Initialized
INFO - 2023-07-29 06:06:52 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:06:52 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:06:52 --> Utf8 Class Initialized
INFO - 2023-07-29 06:06:52 --> URI Class Initialized
INFO - 2023-07-29 06:06:52 --> Router Class Initialized
INFO - 2023-07-29 06:06:52 --> Output Class Initialized
INFO - 2023-07-29 06:06:52 --> Security Class Initialized
DEBUG - 2023-07-29 06:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:06:52 --> Input Class Initialized
INFO - 2023-07-29 06:06:52 --> Language Class Initialized
ERROR - 2023-07-29 06:06:52 --> 404 Page Not Found: /index
INFO - 2023-07-29 06:07:13 --> Config Class Initialized
INFO - 2023-07-29 06:07:13 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:07:13 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:07:13 --> Utf8 Class Initialized
INFO - 2023-07-29 06:07:13 --> URI Class Initialized
INFO - 2023-07-29 06:07:13 --> Router Class Initialized
INFO - 2023-07-29 06:07:13 --> Output Class Initialized
INFO - 2023-07-29 06:07:13 --> Security Class Initialized
DEBUG - 2023-07-29 06:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:07:13 --> Input Class Initialized
INFO - 2023-07-29 06:07:13 --> Language Class Initialized
INFO - 2023-07-29 06:07:13 --> Language Class Initialized
INFO - 2023-07-29 06:07:13 --> Config Class Initialized
INFO - 2023-07-29 06:07:13 --> Loader Class Initialized
INFO - 2023-07-29 06:07:13 --> Helper loaded: url_helper
INFO - 2023-07-29 06:07:13 --> Helper loaded: file_helper
INFO - 2023-07-29 06:07:13 --> Helper loaded: form_helper
INFO - 2023-07-29 06:07:13 --> Helper loaded: my_helper
INFO - 2023-07-29 06:07:13 --> Database Driver Class Initialized
DEBUG - 2023-07-29 06:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 06:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 06:07:13 --> Controller Class Initialized
DEBUG - 2023-07-29 06:07:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-07-29 06:07:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 06:07:13 --> Final output sent to browser
DEBUG - 2023-07-29 06:07:13 --> Total execution time: 0.0766
INFO - 2023-07-29 06:07:13 --> Config Class Initialized
INFO - 2023-07-29 06:07:13 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:07:13 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:07:13 --> Utf8 Class Initialized
INFO - 2023-07-29 06:07:13 --> URI Class Initialized
INFO - 2023-07-29 06:07:13 --> Router Class Initialized
INFO - 2023-07-29 06:07:13 --> Output Class Initialized
INFO - 2023-07-29 06:07:13 --> Security Class Initialized
DEBUG - 2023-07-29 06:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:07:13 --> Input Class Initialized
INFO - 2023-07-29 06:07:13 --> Language Class Initialized
ERROR - 2023-07-29 06:07:13 --> 404 Page Not Found: /index
INFO - 2023-07-29 06:07:13 --> Config Class Initialized
INFO - 2023-07-29 06:07:13 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:07:13 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:07:13 --> Utf8 Class Initialized
INFO - 2023-07-29 06:07:13 --> URI Class Initialized
INFO - 2023-07-29 06:07:13 --> Router Class Initialized
INFO - 2023-07-29 06:07:13 --> Output Class Initialized
INFO - 2023-07-29 06:07:13 --> Security Class Initialized
DEBUG - 2023-07-29 06:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:07:13 --> Input Class Initialized
INFO - 2023-07-29 06:07:13 --> Language Class Initialized
INFO - 2023-07-29 06:07:13 --> Language Class Initialized
INFO - 2023-07-29 06:07:13 --> Config Class Initialized
INFO - 2023-07-29 06:07:13 --> Loader Class Initialized
INFO - 2023-07-29 06:07:13 --> Helper loaded: url_helper
INFO - 2023-07-29 06:07:13 --> Helper loaded: file_helper
INFO - 2023-07-29 06:07:13 --> Helper loaded: form_helper
INFO - 2023-07-29 06:07:13 --> Helper loaded: my_helper
INFO - 2023-07-29 06:07:13 --> Database Driver Class Initialized
DEBUG - 2023-07-29 06:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 06:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 06:07:13 --> Controller Class Initialized
INFO - 2023-07-29 06:07:15 --> Config Class Initialized
INFO - 2023-07-29 06:07:15 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:07:15 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:07:15 --> Utf8 Class Initialized
INFO - 2023-07-29 06:07:15 --> URI Class Initialized
INFO - 2023-07-29 06:07:15 --> Router Class Initialized
INFO - 2023-07-29 06:07:15 --> Output Class Initialized
INFO - 2023-07-29 06:07:15 --> Security Class Initialized
DEBUG - 2023-07-29 06:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:07:15 --> Input Class Initialized
INFO - 2023-07-29 06:07:15 --> Language Class Initialized
INFO - 2023-07-29 06:07:15 --> Language Class Initialized
INFO - 2023-07-29 06:07:15 --> Config Class Initialized
INFO - 2023-07-29 06:07:15 --> Loader Class Initialized
INFO - 2023-07-29 06:07:15 --> Helper loaded: url_helper
INFO - 2023-07-29 06:07:15 --> Helper loaded: file_helper
INFO - 2023-07-29 06:07:15 --> Helper loaded: form_helper
INFO - 2023-07-29 06:07:15 --> Helper loaded: my_helper
INFO - 2023-07-29 06:07:15 --> Database Driver Class Initialized
DEBUG - 2023-07-29 06:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 06:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 06:07:15 --> Controller Class Initialized
INFO - 2023-07-29 06:07:15 --> Final output sent to browser
DEBUG - 2023-07-29 06:07:15 --> Total execution time: 0.0374
INFO - 2023-07-29 06:07:17 --> Config Class Initialized
INFO - 2023-07-29 06:07:17 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:07:17 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:07:17 --> Utf8 Class Initialized
INFO - 2023-07-29 06:07:17 --> URI Class Initialized
INFO - 2023-07-29 06:07:17 --> Router Class Initialized
INFO - 2023-07-29 06:07:17 --> Output Class Initialized
INFO - 2023-07-29 06:07:17 --> Security Class Initialized
DEBUG - 2023-07-29 06:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:07:17 --> Input Class Initialized
INFO - 2023-07-29 06:07:17 --> Language Class Initialized
INFO - 2023-07-29 06:07:17 --> Language Class Initialized
INFO - 2023-07-29 06:07:17 --> Config Class Initialized
INFO - 2023-07-29 06:07:17 --> Loader Class Initialized
INFO - 2023-07-29 06:07:17 --> Helper loaded: url_helper
INFO - 2023-07-29 06:07:17 --> Helper loaded: file_helper
INFO - 2023-07-29 06:07:17 --> Helper loaded: form_helper
INFO - 2023-07-29 06:07:17 --> Helper loaded: my_helper
INFO - 2023-07-29 06:07:17 --> Database Driver Class Initialized
DEBUG - 2023-07-29 06:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 06:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 06:07:17 --> Controller Class Initialized
INFO - 2023-07-29 06:07:17 --> Final output sent to browser
DEBUG - 2023-07-29 06:07:17 --> Total execution time: 0.0278
INFO - 2023-07-29 06:07:20 --> Config Class Initialized
INFO - 2023-07-29 06:07:20 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:07:20 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:07:20 --> Utf8 Class Initialized
INFO - 2023-07-29 06:07:20 --> URI Class Initialized
INFO - 2023-07-29 06:07:20 --> Router Class Initialized
INFO - 2023-07-29 06:07:20 --> Output Class Initialized
INFO - 2023-07-29 06:07:20 --> Security Class Initialized
DEBUG - 2023-07-29 06:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:07:20 --> Input Class Initialized
INFO - 2023-07-29 06:07:20 --> Language Class Initialized
INFO - 2023-07-29 06:07:20 --> Language Class Initialized
INFO - 2023-07-29 06:07:20 --> Config Class Initialized
INFO - 2023-07-29 06:07:20 --> Loader Class Initialized
INFO - 2023-07-29 06:07:20 --> Helper loaded: url_helper
INFO - 2023-07-29 06:07:20 --> Helper loaded: file_helper
INFO - 2023-07-29 06:07:20 --> Helper loaded: form_helper
INFO - 2023-07-29 06:07:20 --> Helper loaded: my_helper
INFO - 2023-07-29 06:07:20 --> Database Driver Class Initialized
DEBUG - 2023-07-29 06:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 06:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 06:07:20 --> Controller Class Initialized
DEBUG - 2023-07-29 06:07:20 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-29 06:07:21 --> Final output sent to browser
DEBUG - 2023-07-29 06:07:21 --> Total execution time: 1.2185
INFO - 2023-07-29 06:07:32 --> Config Class Initialized
INFO - 2023-07-29 06:07:32 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:07:32 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:07:32 --> Utf8 Class Initialized
INFO - 2023-07-29 06:07:32 --> URI Class Initialized
INFO - 2023-07-29 06:07:32 --> Router Class Initialized
INFO - 2023-07-29 06:07:32 --> Output Class Initialized
INFO - 2023-07-29 06:07:32 --> Security Class Initialized
DEBUG - 2023-07-29 06:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:07:32 --> Input Class Initialized
INFO - 2023-07-29 06:07:32 --> Language Class Initialized
INFO - 2023-07-29 06:07:32 --> Language Class Initialized
INFO - 2023-07-29 06:07:32 --> Config Class Initialized
INFO - 2023-07-29 06:07:32 --> Loader Class Initialized
INFO - 2023-07-29 06:07:32 --> Helper loaded: url_helper
INFO - 2023-07-29 06:07:32 --> Helper loaded: file_helper
INFO - 2023-07-29 06:07:32 --> Helper loaded: form_helper
INFO - 2023-07-29 06:07:32 --> Helper loaded: my_helper
INFO - 2023-07-29 06:07:32 --> Database Driver Class Initialized
DEBUG - 2023-07-29 06:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 06:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 06:07:32 --> Controller Class Initialized
INFO - 2023-07-29 06:07:32 --> Final output sent to browser
DEBUG - 2023-07-29 06:07:32 --> Total execution time: 0.0296
INFO - 2023-07-29 06:07:34 --> Config Class Initialized
INFO - 2023-07-29 06:07:34 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:07:34 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:07:34 --> Utf8 Class Initialized
INFO - 2023-07-29 06:07:34 --> URI Class Initialized
INFO - 2023-07-29 06:07:34 --> Router Class Initialized
INFO - 2023-07-29 06:07:34 --> Output Class Initialized
INFO - 2023-07-29 06:07:34 --> Security Class Initialized
DEBUG - 2023-07-29 06:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:07:34 --> Input Class Initialized
INFO - 2023-07-29 06:07:34 --> Language Class Initialized
INFO - 2023-07-29 06:07:34 --> Language Class Initialized
INFO - 2023-07-29 06:07:34 --> Config Class Initialized
INFO - 2023-07-29 06:07:34 --> Loader Class Initialized
INFO - 2023-07-29 06:07:34 --> Helper loaded: url_helper
INFO - 2023-07-29 06:07:34 --> Helper loaded: file_helper
INFO - 2023-07-29 06:07:34 --> Helper loaded: form_helper
INFO - 2023-07-29 06:07:34 --> Helper loaded: my_helper
INFO - 2023-07-29 06:07:34 --> Database Driver Class Initialized
DEBUG - 2023-07-29 06:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 06:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 06:07:34 --> Controller Class Initialized
DEBUG - 2023-07-29 06:07:34 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-29 06:07:35 --> Final output sent to browser
DEBUG - 2023-07-29 06:07:35 --> Total execution time: 1.1639
INFO - 2023-07-29 06:07:41 --> Config Class Initialized
INFO - 2023-07-29 06:07:41 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:07:41 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:07:41 --> Utf8 Class Initialized
INFO - 2023-07-29 06:07:41 --> URI Class Initialized
INFO - 2023-07-29 06:07:41 --> Router Class Initialized
INFO - 2023-07-29 06:07:41 --> Output Class Initialized
INFO - 2023-07-29 06:07:41 --> Security Class Initialized
DEBUG - 2023-07-29 06:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:07:41 --> Input Class Initialized
INFO - 2023-07-29 06:07:41 --> Language Class Initialized
INFO - 2023-07-29 06:07:41 --> Language Class Initialized
INFO - 2023-07-29 06:07:41 --> Config Class Initialized
INFO - 2023-07-29 06:07:41 --> Loader Class Initialized
INFO - 2023-07-29 06:07:41 --> Helper loaded: url_helper
INFO - 2023-07-29 06:07:41 --> Helper loaded: file_helper
INFO - 2023-07-29 06:07:41 --> Helper loaded: form_helper
INFO - 2023-07-29 06:07:41 --> Helper loaded: my_helper
INFO - 2023-07-29 06:07:41 --> Database Driver Class Initialized
DEBUG - 2023-07-29 06:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 06:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 06:07:41 --> Controller Class Initialized
INFO - 2023-07-29 06:07:41 --> Final output sent to browser
DEBUG - 2023-07-29 06:07:41 --> Total execution time: 0.0343
INFO - 2023-07-29 06:07:43 --> Config Class Initialized
INFO - 2023-07-29 06:07:43 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:07:43 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:07:43 --> Utf8 Class Initialized
INFO - 2023-07-29 06:07:43 --> URI Class Initialized
INFO - 2023-07-29 06:07:43 --> Router Class Initialized
INFO - 2023-07-29 06:07:43 --> Output Class Initialized
INFO - 2023-07-29 06:07:43 --> Security Class Initialized
DEBUG - 2023-07-29 06:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:07:43 --> Input Class Initialized
INFO - 2023-07-29 06:07:43 --> Language Class Initialized
INFO - 2023-07-29 06:07:43 --> Language Class Initialized
INFO - 2023-07-29 06:07:43 --> Config Class Initialized
INFO - 2023-07-29 06:07:43 --> Loader Class Initialized
INFO - 2023-07-29 06:07:43 --> Helper loaded: url_helper
INFO - 2023-07-29 06:07:43 --> Helper loaded: file_helper
INFO - 2023-07-29 06:07:43 --> Helper loaded: form_helper
INFO - 2023-07-29 06:07:43 --> Helper loaded: my_helper
INFO - 2023-07-29 06:07:43 --> Database Driver Class Initialized
DEBUG - 2023-07-29 06:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 06:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 06:07:43 --> Controller Class Initialized
DEBUG - 2023-07-29 06:07:43 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-29 06:07:44 --> Final output sent to browser
DEBUG - 2023-07-29 06:07:44 --> Total execution time: 1.1852
INFO - 2023-07-29 06:08:12 --> Config Class Initialized
INFO - 2023-07-29 06:08:12 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:08:12 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:08:12 --> Utf8 Class Initialized
INFO - 2023-07-29 06:08:12 --> URI Class Initialized
INFO - 2023-07-29 06:08:12 --> Router Class Initialized
INFO - 2023-07-29 06:08:12 --> Output Class Initialized
INFO - 2023-07-29 06:08:12 --> Security Class Initialized
DEBUG - 2023-07-29 06:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:08:12 --> Input Class Initialized
INFO - 2023-07-29 06:08:12 --> Language Class Initialized
INFO - 2023-07-29 06:08:12 --> Language Class Initialized
INFO - 2023-07-29 06:08:12 --> Config Class Initialized
INFO - 2023-07-29 06:08:12 --> Loader Class Initialized
INFO - 2023-07-29 06:08:12 --> Helper loaded: url_helper
INFO - 2023-07-29 06:08:12 --> Helper loaded: file_helper
INFO - 2023-07-29 06:08:12 --> Helper loaded: form_helper
INFO - 2023-07-29 06:08:12 --> Helper loaded: my_helper
INFO - 2023-07-29 06:08:12 --> Database Driver Class Initialized
DEBUG - 2023-07-29 06:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 06:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 06:08:12 --> Controller Class Initialized
INFO - 2023-07-29 06:08:12 --> Final output sent to browser
DEBUG - 2023-07-29 06:08:12 --> Total execution time: 0.0273
INFO - 2023-07-29 18:23:39 --> Config Class Initialized
INFO - 2023-07-29 18:23:39 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:23:39 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:23:39 --> Utf8 Class Initialized
INFO - 2023-07-29 18:23:39 --> URI Class Initialized
DEBUG - 2023-07-29 18:23:39 --> No URI present. Default controller set.
INFO - 2023-07-29 18:23:39 --> Router Class Initialized
INFO - 2023-07-29 18:23:39 --> Output Class Initialized
INFO - 2023-07-29 18:23:40 --> Security Class Initialized
DEBUG - 2023-07-29 18:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:23:40 --> Input Class Initialized
INFO - 2023-07-29 18:23:40 --> Language Class Initialized
INFO - 2023-07-29 18:23:40 --> Language Class Initialized
INFO - 2023-07-29 18:23:40 --> Config Class Initialized
INFO - 2023-07-29 18:23:40 --> Loader Class Initialized
INFO - 2023-07-29 18:23:40 --> Helper loaded: url_helper
INFO - 2023-07-29 18:23:40 --> Helper loaded: file_helper
INFO - 2023-07-29 18:23:40 --> Helper loaded: form_helper
INFO - 2023-07-29 18:23:40 --> Helper loaded: my_helper
INFO - 2023-07-29 18:23:40 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:23:40 --> Controller Class Initialized
INFO - 2023-07-29 18:23:40 --> Config Class Initialized
INFO - 2023-07-29 18:23:40 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:23:40 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:23:40 --> Utf8 Class Initialized
INFO - 2023-07-29 18:23:40 --> URI Class Initialized
INFO - 2023-07-29 18:23:40 --> Router Class Initialized
INFO - 2023-07-29 18:23:40 --> Output Class Initialized
INFO - 2023-07-29 18:23:40 --> Security Class Initialized
DEBUG - 2023-07-29 18:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:23:40 --> Input Class Initialized
INFO - 2023-07-29 18:23:40 --> Language Class Initialized
INFO - 2023-07-29 18:23:40 --> Language Class Initialized
INFO - 2023-07-29 18:23:40 --> Config Class Initialized
INFO - 2023-07-29 18:23:40 --> Loader Class Initialized
INFO - 2023-07-29 18:23:40 --> Helper loaded: url_helper
INFO - 2023-07-29 18:23:40 --> Helper loaded: file_helper
INFO - 2023-07-29 18:23:40 --> Helper loaded: form_helper
INFO - 2023-07-29 18:23:40 --> Helper loaded: my_helper
INFO - 2023-07-29 18:23:40 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:23:40 --> Controller Class Initialized
DEBUG - 2023-07-29 18:23:40 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/login/views/login.php
DEBUG - 2023-07-29 18:23:40 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:23:40 --> Final output sent to browser
DEBUG - 2023-07-29 18:23:40 --> Total execution time: 0.1280
INFO - 2023-07-29 18:25:37 --> Config Class Initialized
INFO - 2023-07-29 18:25:37 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:25:37 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:25:37 --> Utf8 Class Initialized
INFO - 2023-07-29 18:25:37 --> URI Class Initialized
INFO - 2023-07-29 18:25:37 --> Router Class Initialized
INFO - 2023-07-29 18:25:37 --> Output Class Initialized
INFO - 2023-07-29 18:25:37 --> Security Class Initialized
DEBUG - 2023-07-29 18:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:25:37 --> Input Class Initialized
INFO - 2023-07-29 18:25:37 --> Language Class Initialized
INFO - 2023-07-29 18:25:37 --> Language Class Initialized
INFO - 2023-07-29 18:25:37 --> Config Class Initialized
INFO - 2023-07-29 18:25:37 --> Loader Class Initialized
INFO - 2023-07-29 18:25:37 --> Helper loaded: url_helper
INFO - 2023-07-29 18:25:37 --> Helper loaded: file_helper
INFO - 2023-07-29 18:25:37 --> Helper loaded: form_helper
INFO - 2023-07-29 18:25:37 --> Helper loaded: my_helper
INFO - 2023-07-29 18:25:37 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:25:37 --> Controller Class Initialized
INFO - 2023-07-29 18:25:37 --> Helper loaded: cookie_helper
INFO - 2023-07-29 18:25:37 --> Final output sent to browser
DEBUG - 2023-07-29 18:25:37 --> Total execution time: 0.0989
INFO - 2023-07-29 18:25:37 --> Config Class Initialized
INFO - 2023-07-29 18:25:37 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:25:37 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:25:37 --> Utf8 Class Initialized
INFO - 2023-07-29 18:25:37 --> URI Class Initialized
INFO - 2023-07-29 18:25:37 --> Router Class Initialized
INFO - 2023-07-29 18:25:37 --> Output Class Initialized
INFO - 2023-07-29 18:25:37 --> Security Class Initialized
DEBUG - 2023-07-29 18:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:25:37 --> Input Class Initialized
INFO - 2023-07-29 18:25:37 --> Language Class Initialized
INFO - 2023-07-29 18:25:37 --> Language Class Initialized
INFO - 2023-07-29 18:25:37 --> Config Class Initialized
INFO - 2023-07-29 18:25:37 --> Loader Class Initialized
INFO - 2023-07-29 18:25:37 --> Helper loaded: url_helper
INFO - 2023-07-29 18:25:37 --> Helper loaded: file_helper
INFO - 2023-07-29 18:25:37 --> Helper loaded: form_helper
INFO - 2023-07-29 18:25:37 --> Helper loaded: my_helper
INFO - 2023-07-29 18:25:37 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:25:37 --> Controller Class Initialized
DEBUG - 2023-07-29 18:25:37 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:25:37 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:25:37 --> Final output sent to browser
DEBUG - 2023-07-29 18:25:37 --> Total execution time: 0.1494
INFO - 2023-07-29 18:26:40 --> Config Class Initialized
INFO - 2023-07-29 18:26:40 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:26:40 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:26:40 --> Utf8 Class Initialized
INFO - 2023-07-29 18:26:40 --> URI Class Initialized
INFO - 2023-07-29 18:26:40 --> Router Class Initialized
INFO - 2023-07-29 18:26:40 --> Output Class Initialized
INFO - 2023-07-29 18:26:40 --> Security Class Initialized
DEBUG - 2023-07-29 18:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:26:40 --> Input Class Initialized
INFO - 2023-07-29 18:26:40 --> Language Class Initialized
INFO - 2023-07-29 18:26:40 --> Language Class Initialized
INFO - 2023-07-29 18:26:40 --> Config Class Initialized
INFO - 2023-07-29 18:26:40 --> Loader Class Initialized
INFO - 2023-07-29 18:26:40 --> Helper loaded: url_helper
INFO - 2023-07-29 18:26:40 --> Helper loaded: file_helper
INFO - 2023-07-29 18:26:40 --> Helper loaded: form_helper
INFO - 2023-07-29 18:26:40 --> Helper loaded: my_helper
INFO - 2023-07-29 18:26:40 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:26:40 --> Controller Class Initialized
DEBUG - 2023-07-29 18:26:40 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/backup_db/views/list.php
DEBUG - 2023-07-29 18:26:40 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:26:40 --> Final output sent to browser
DEBUG - 2023-07-29 18:26:40 --> Total execution time: 0.0931
INFO - 2023-07-29 18:26:40 --> Config Class Initialized
INFO - 2023-07-29 18:26:40 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:26:40 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:26:40 --> Utf8 Class Initialized
INFO - 2023-07-29 18:26:40 --> URI Class Initialized
INFO - 2023-07-29 18:26:40 --> Router Class Initialized
INFO - 2023-07-29 18:26:40 --> Output Class Initialized
INFO - 2023-07-29 18:26:40 --> Security Class Initialized
DEBUG - 2023-07-29 18:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:26:40 --> Input Class Initialized
INFO - 2023-07-29 18:26:40 --> Language Class Initialized
INFO - 2023-07-29 18:26:40 --> Language Class Initialized
INFO - 2023-07-29 18:26:40 --> Config Class Initialized
INFO - 2023-07-29 18:26:40 --> Loader Class Initialized
INFO - 2023-07-29 18:26:40 --> Helper loaded: url_helper
INFO - 2023-07-29 18:26:40 --> Helper loaded: file_helper
INFO - 2023-07-29 18:26:40 --> Helper loaded: form_helper
INFO - 2023-07-29 18:26:40 --> Helper loaded: my_helper
INFO - 2023-07-29 18:26:40 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:26:40 --> Controller Class Initialized
INFO - 2023-07-29 18:26:41 --> Config Class Initialized
INFO - 2023-07-29 18:26:41 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:26:41 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:26:41 --> Utf8 Class Initialized
INFO - 2023-07-29 18:26:41 --> URI Class Initialized
INFO - 2023-07-29 18:26:41 --> Router Class Initialized
INFO - 2023-07-29 18:26:41 --> Output Class Initialized
INFO - 2023-07-29 18:26:41 --> Security Class Initialized
DEBUG - 2023-07-29 18:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:26:41 --> Input Class Initialized
INFO - 2023-07-29 18:26:41 --> Language Class Initialized
INFO - 2023-07-29 18:26:41 --> Language Class Initialized
INFO - 2023-07-29 18:26:41 --> Config Class Initialized
INFO - 2023-07-29 18:26:41 --> Loader Class Initialized
INFO - 2023-07-29 18:26:41 --> Helper loaded: url_helper
INFO - 2023-07-29 18:26:41 --> Helper loaded: file_helper
INFO - 2023-07-29 18:26:41 --> Helper loaded: form_helper
INFO - 2023-07-29 18:26:41 --> Helper loaded: my_helper
INFO - 2023-07-29 18:26:41 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:26:41 --> Controller Class Initialized
INFO - 2023-07-29 18:26:42 --> Database Utility Class Initialized
INFO - 2023-07-29 18:26:42 --> Zip Compression Class Initialized
ERROR - 2023-07-29 18:26:42 --> Severity: Notice --> Only variables should be assigned by reference C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\backup_db\controllers\Backup_db.php 96
INFO - 2023-07-29 18:26:42 --> Config Class Initialized
INFO - 2023-07-29 18:26:42 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:26:42 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:26:42 --> Utf8 Class Initialized
INFO - 2023-07-29 18:26:42 --> URI Class Initialized
INFO - 2023-07-29 18:26:42 --> Router Class Initialized
INFO - 2023-07-29 18:26:42 --> Output Class Initialized
INFO - 2023-07-29 18:26:42 --> Security Class Initialized
DEBUG - 2023-07-29 18:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:26:42 --> Input Class Initialized
INFO - 2023-07-29 18:26:42 --> Language Class Initialized
INFO - 2023-07-29 18:26:42 --> Language Class Initialized
INFO - 2023-07-29 18:26:42 --> Config Class Initialized
INFO - 2023-07-29 18:26:42 --> Loader Class Initialized
INFO - 2023-07-29 18:26:42 --> Helper loaded: url_helper
INFO - 2023-07-29 18:26:42 --> Helper loaded: file_helper
INFO - 2023-07-29 18:26:42 --> Helper loaded: form_helper
INFO - 2023-07-29 18:26:42 --> Helper loaded: my_helper
INFO - 2023-07-29 18:26:42 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:26:42 --> Controller Class Initialized
DEBUG - 2023-07-29 18:26:42 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/backup_db/views/list.php
DEBUG - 2023-07-29 18:26:42 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:26:42 --> Final output sent to browser
DEBUG - 2023-07-29 18:26:42 --> Total execution time: 0.0333
INFO - 2023-07-29 18:26:43 --> Config Class Initialized
INFO - 2023-07-29 18:26:43 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:26:43 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:26:43 --> Utf8 Class Initialized
INFO - 2023-07-29 18:26:43 --> URI Class Initialized
INFO - 2023-07-29 18:26:43 --> Router Class Initialized
INFO - 2023-07-29 18:26:43 --> Output Class Initialized
INFO - 2023-07-29 18:26:43 --> Security Class Initialized
DEBUG - 2023-07-29 18:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:26:43 --> Input Class Initialized
INFO - 2023-07-29 18:26:43 --> Language Class Initialized
INFO - 2023-07-29 18:26:43 --> Language Class Initialized
INFO - 2023-07-29 18:26:43 --> Config Class Initialized
INFO - 2023-07-29 18:26:43 --> Loader Class Initialized
INFO - 2023-07-29 18:26:43 --> Helper loaded: url_helper
INFO - 2023-07-29 18:26:43 --> Helper loaded: file_helper
INFO - 2023-07-29 18:26:43 --> Helper loaded: form_helper
INFO - 2023-07-29 18:26:43 --> Helper loaded: my_helper
INFO - 2023-07-29 18:26:43 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:26:43 --> Controller Class Initialized
INFO - 2023-07-29 18:27:31 --> Config Class Initialized
INFO - 2023-07-29 18:27:31 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:27:31 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:27:31 --> Utf8 Class Initialized
INFO - 2023-07-29 18:27:31 --> URI Class Initialized
DEBUG - 2023-07-29 18:27:31 --> No URI present. Default controller set.
INFO - 2023-07-29 18:27:31 --> Router Class Initialized
INFO - 2023-07-29 18:27:31 --> Output Class Initialized
INFO - 2023-07-29 18:27:31 --> Security Class Initialized
DEBUG - 2023-07-29 18:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:27:31 --> Input Class Initialized
INFO - 2023-07-29 18:27:31 --> Language Class Initialized
INFO - 2023-07-29 18:27:31 --> Language Class Initialized
INFO - 2023-07-29 18:27:31 --> Config Class Initialized
INFO - 2023-07-29 18:27:31 --> Loader Class Initialized
INFO - 2023-07-29 18:27:31 --> Helper loaded: url_helper
INFO - 2023-07-29 18:27:31 --> Helper loaded: file_helper
INFO - 2023-07-29 18:27:31 --> Helper loaded: form_helper
INFO - 2023-07-29 18:27:31 --> Helper loaded: my_helper
INFO - 2023-07-29 18:27:31 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:27:31 --> Controller Class Initialized
DEBUG - 2023-07-29 18:27:31 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:27:31 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:27:31 --> Final output sent to browser
DEBUG - 2023-07-29 18:27:31 --> Total execution time: 0.0635
INFO - 2023-07-29 18:36:02 --> Config Class Initialized
INFO - 2023-07-29 18:36:02 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:36:02 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:36:02 --> Utf8 Class Initialized
INFO - 2023-07-29 18:36:02 --> URI Class Initialized
DEBUG - 2023-07-29 18:36:02 --> No URI present. Default controller set.
INFO - 2023-07-29 18:36:02 --> Router Class Initialized
INFO - 2023-07-29 18:36:02 --> Output Class Initialized
INFO - 2023-07-29 18:36:02 --> Security Class Initialized
DEBUG - 2023-07-29 18:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:36:02 --> Input Class Initialized
INFO - 2023-07-29 18:36:02 --> Language Class Initialized
INFO - 2023-07-29 18:36:02 --> Language Class Initialized
INFO - 2023-07-29 18:36:02 --> Config Class Initialized
INFO - 2023-07-29 18:36:02 --> Loader Class Initialized
INFO - 2023-07-29 18:36:02 --> Helper loaded: url_helper
INFO - 2023-07-29 18:36:02 --> Helper loaded: file_helper
INFO - 2023-07-29 18:36:02 --> Helper loaded: form_helper
INFO - 2023-07-29 18:36:02 --> Helper loaded: my_helper
INFO - 2023-07-29 18:36:02 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:36:02 --> Controller Class Initialized
DEBUG - 2023-07-29 18:36:02 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:36:02 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:36:02 --> Final output sent to browser
DEBUG - 2023-07-29 18:36:02 --> Total execution time: 0.0790
INFO - 2023-07-29 18:36:05 --> Config Class Initialized
INFO - 2023-07-29 18:36:05 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:36:05 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:36:05 --> Utf8 Class Initialized
INFO - 2023-07-29 18:36:05 --> URI Class Initialized
INFO - 2023-07-29 18:36:05 --> Router Class Initialized
INFO - 2023-07-29 18:36:05 --> Output Class Initialized
INFO - 2023-07-29 18:36:05 --> Security Class Initialized
DEBUG - 2023-07-29 18:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:36:05 --> Input Class Initialized
INFO - 2023-07-29 18:36:05 --> Language Class Initialized
INFO - 2023-07-29 18:36:05 --> Language Class Initialized
INFO - 2023-07-29 18:36:05 --> Config Class Initialized
INFO - 2023-07-29 18:36:05 --> Loader Class Initialized
INFO - 2023-07-29 18:36:05 --> Helper loaded: url_helper
INFO - 2023-07-29 18:36:05 --> Helper loaded: file_helper
INFO - 2023-07-29 18:36:05 --> Helper loaded: form_helper
INFO - 2023-07-29 18:36:05 --> Helper loaded: my_helper
INFO - 2023-07-29 18:36:05 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:36:05 --> Controller Class Initialized
DEBUG - 2023-07-29 18:36:05 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_guru/views/list.php
DEBUG - 2023-07-29 18:36:05 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:36:05 --> Final output sent to browser
DEBUG - 2023-07-29 18:36:05 --> Total execution time: 0.1056
INFO - 2023-07-29 18:36:05 --> Config Class Initialized
INFO - 2023-07-29 18:36:05 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:36:05 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:36:05 --> Utf8 Class Initialized
INFO - 2023-07-29 18:36:05 --> URI Class Initialized
INFO - 2023-07-29 18:36:05 --> Router Class Initialized
INFO - 2023-07-29 18:36:05 --> Output Class Initialized
INFO - 2023-07-29 18:36:05 --> Security Class Initialized
DEBUG - 2023-07-29 18:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:36:05 --> Input Class Initialized
INFO - 2023-07-29 18:36:05 --> Language Class Initialized
INFO - 2023-07-29 18:36:05 --> Language Class Initialized
INFO - 2023-07-29 18:36:05 --> Config Class Initialized
INFO - 2023-07-29 18:36:05 --> Loader Class Initialized
INFO - 2023-07-29 18:36:05 --> Helper loaded: url_helper
INFO - 2023-07-29 18:36:05 --> Helper loaded: file_helper
INFO - 2023-07-29 18:36:05 --> Helper loaded: form_helper
INFO - 2023-07-29 18:36:05 --> Helper loaded: my_helper
INFO - 2023-07-29 18:36:05 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:36:05 --> Controller Class Initialized
INFO - 2023-07-29 18:36:10 --> Config Class Initialized
INFO - 2023-07-29 18:36:10 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:36:10 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:36:10 --> Utf8 Class Initialized
INFO - 2023-07-29 18:36:10 --> URI Class Initialized
INFO - 2023-07-29 18:36:10 --> Router Class Initialized
INFO - 2023-07-29 18:36:10 --> Output Class Initialized
INFO - 2023-07-29 18:36:10 --> Security Class Initialized
DEBUG - 2023-07-29 18:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:36:10 --> Input Class Initialized
INFO - 2023-07-29 18:36:10 --> Language Class Initialized
INFO - 2023-07-29 18:36:10 --> Language Class Initialized
INFO - 2023-07-29 18:36:10 --> Config Class Initialized
INFO - 2023-07-29 18:36:10 --> Loader Class Initialized
INFO - 2023-07-29 18:36:10 --> Helper loaded: url_helper
INFO - 2023-07-29 18:36:10 --> Helper loaded: file_helper
INFO - 2023-07-29 18:36:10 --> Helper loaded: form_helper
INFO - 2023-07-29 18:36:10 --> Helper loaded: my_helper
INFO - 2023-07-29 18:36:10 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:36:10 --> Controller Class Initialized
DEBUG - 2023-07-29 18:36:10 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_mapel/views/list.php
DEBUG - 2023-07-29 18:36:10 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:36:10 --> Final output sent to browser
DEBUG - 2023-07-29 18:36:10 --> Total execution time: 0.0839
INFO - 2023-07-29 18:36:10 --> Config Class Initialized
INFO - 2023-07-29 18:36:10 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:36:10 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:36:10 --> Utf8 Class Initialized
INFO - 2023-07-29 18:36:10 --> URI Class Initialized
INFO - 2023-07-29 18:36:10 --> Router Class Initialized
INFO - 2023-07-29 18:36:10 --> Output Class Initialized
INFO - 2023-07-29 18:36:10 --> Security Class Initialized
DEBUG - 2023-07-29 18:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:36:10 --> Input Class Initialized
INFO - 2023-07-29 18:36:10 --> Language Class Initialized
INFO - 2023-07-29 18:36:10 --> Language Class Initialized
INFO - 2023-07-29 18:36:10 --> Config Class Initialized
INFO - 2023-07-29 18:36:10 --> Loader Class Initialized
INFO - 2023-07-29 18:36:10 --> Helper loaded: url_helper
INFO - 2023-07-29 18:36:10 --> Helper loaded: file_helper
INFO - 2023-07-29 18:36:10 --> Helper loaded: form_helper
INFO - 2023-07-29 18:36:10 --> Helper loaded: my_helper
INFO - 2023-07-29 18:36:10 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:36:10 --> Controller Class Initialized
INFO - 2023-07-29 18:42:59 --> Config Class Initialized
INFO - 2023-07-29 18:42:59 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:42:59 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:42:59 --> Utf8 Class Initialized
INFO - 2023-07-29 18:42:59 --> URI Class Initialized
DEBUG - 2023-07-29 18:42:59 --> No URI present. Default controller set.
INFO - 2023-07-29 18:42:59 --> Router Class Initialized
INFO - 2023-07-29 18:42:59 --> Output Class Initialized
INFO - 2023-07-29 18:42:59 --> Security Class Initialized
DEBUG - 2023-07-29 18:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:42:59 --> Input Class Initialized
INFO - 2023-07-29 18:42:59 --> Language Class Initialized
INFO - 2023-07-29 18:42:59 --> Language Class Initialized
INFO - 2023-07-29 18:42:59 --> Config Class Initialized
INFO - 2023-07-29 18:42:59 --> Loader Class Initialized
INFO - 2023-07-29 18:42:59 --> Helper loaded: url_helper
INFO - 2023-07-29 18:42:59 --> Helper loaded: file_helper
INFO - 2023-07-29 18:42:59 --> Helper loaded: form_helper
INFO - 2023-07-29 18:42:59 --> Helper loaded: my_helper
INFO - 2023-07-29 18:42:59 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:42:59 --> Controller Class Initialized
DEBUG - 2023-07-29 18:42:59 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:42:59 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:42:59 --> Final output sent to browser
DEBUG - 2023-07-29 18:42:59 --> Total execution time: 0.0447
INFO - 2023-07-29 18:43:50 --> Config Class Initialized
INFO - 2023-07-29 18:43:50 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:43:50 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:43:50 --> Utf8 Class Initialized
INFO - 2023-07-29 18:43:50 --> URI Class Initialized
DEBUG - 2023-07-29 18:43:50 --> No URI present. Default controller set.
INFO - 2023-07-29 18:43:50 --> Router Class Initialized
INFO - 2023-07-29 18:43:50 --> Output Class Initialized
INFO - 2023-07-29 18:43:50 --> Security Class Initialized
DEBUG - 2023-07-29 18:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:43:50 --> Input Class Initialized
INFO - 2023-07-29 18:43:50 --> Language Class Initialized
INFO - 2023-07-29 18:43:50 --> Language Class Initialized
INFO - 2023-07-29 18:43:50 --> Config Class Initialized
INFO - 2023-07-29 18:43:50 --> Loader Class Initialized
INFO - 2023-07-29 18:43:50 --> Helper loaded: url_helper
INFO - 2023-07-29 18:43:50 --> Helper loaded: file_helper
INFO - 2023-07-29 18:43:50 --> Helper loaded: form_helper
INFO - 2023-07-29 18:43:50 --> Helper loaded: my_helper
INFO - 2023-07-29 18:43:50 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:43:50 --> Controller Class Initialized
DEBUG - 2023-07-29 18:43:50 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:43:50 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:43:50 --> Final output sent to browser
DEBUG - 2023-07-29 18:43:50 --> Total execution time: 0.0647
INFO - 2023-07-29 18:44:12 --> Config Class Initialized
INFO - 2023-07-29 18:44:12 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:44:12 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:44:12 --> Utf8 Class Initialized
INFO - 2023-07-29 18:44:12 --> URI Class Initialized
DEBUG - 2023-07-29 18:44:12 --> No URI present. Default controller set.
INFO - 2023-07-29 18:44:12 --> Router Class Initialized
INFO - 2023-07-29 18:44:12 --> Output Class Initialized
INFO - 2023-07-29 18:44:12 --> Security Class Initialized
DEBUG - 2023-07-29 18:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:44:12 --> Input Class Initialized
INFO - 2023-07-29 18:44:12 --> Language Class Initialized
INFO - 2023-07-29 18:44:12 --> Language Class Initialized
INFO - 2023-07-29 18:44:12 --> Config Class Initialized
INFO - 2023-07-29 18:44:12 --> Loader Class Initialized
INFO - 2023-07-29 18:44:12 --> Helper loaded: url_helper
INFO - 2023-07-29 18:44:12 --> Helper loaded: file_helper
INFO - 2023-07-29 18:44:12 --> Helper loaded: form_helper
INFO - 2023-07-29 18:44:12 --> Helper loaded: my_helper
INFO - 2023-07-29 18:44:12 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:44:12 --> Controller Class Initialized
DEBUG - 2023-07-29 18:44:12 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:44:12 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:44:12 --> Final output sent to browser
DEBUG - 2023-07-29 18:44:12 --> Total execution time: 0.0433
INFO - 2023-07-29 18:46:11 --> Config Class Initialized
INFO - 2023-07-29 18:46:11 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:46:11 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:46:11 --> Utf8 Class Initialized
INFO - 2023-07-29 18:46:11 --> URI Class Initialized
DEBUG - 2023-07-29 18:46:11 --> No URI present. Default controller set.
INFO - 2023-07-29 18:46:11 --> Router Class Initialized
INFO - 2023-07-29 18:46:11 --> Output Class Initialized
INFO - 2023-07-29 18:46:11 --> Security Class Initialized
DEBUG - 2023-07-29 18:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:46:11 --> Input Class Initialized
INFO - 2023-07-29 18:46:11 --> Language Class Initialized
INFO - 2023-07-29 18:46:11 --> Language Class Initialized
INFO - 2023-07-29 18:46:11 --> Config Class Initialized
INFO - 2023-07-29 18:46:11 --> Loader Class Initialized
INFO - 2023-07-29 18:46:11 --> Helper loaded: url_helper
INFO - 2023-07-29 18:46:11 --> Helper loaded: file_helper
INFO - 2023-07-29 18:46:11 --> Helper loaded: form_helper
INFO - 2023-07-29 18:46:11 --> Helper loaded: my_helper
INFO - 2023-07-29 18:46:11 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:46:11 --> Controller Class Initialized
DEBUG - 2023-07-29 18:46:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:46:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:46:11 --> Final output sent to browser
DEBUG - 2023-07-29 18:46:11 --> Total execution time: 0.0416
INFO - 2023-07-29 18:47:14 --> Config Class Initialized
INFO - 2023-07-29 18:47:14 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:47:14 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:47:14 --> Utf8 Class Initialized
INFO - 2023-07-29 18:47:14 --> URI Class Initialized
DEBUG - 2023-07-29 18:47:14 --> No URI present. Default controller set.
INFO - 2023-07-29 18:47:14 --> Router Class Initialized
INFO - 2023-07-29 18:47:14 --> Output Class Initialized
INFO - 2023-07-29 18:47:14 --> Security Class Initialized
DEBUG - 2023-07-29 18:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:47:14 --> Input Class Initialized
INFO - 2023-07-29 18:47:14 --> Language Class Initialized
INFO - 2023-07-29 18:47:14 --> Language Class Initialized
INFO - 2023-07-29 18:47:14 --> Config Class Initialized
INFO - 2023-07-29 18:47:14 --> Loader Class Initialized
INFO - 2023-07-29 18:47:14 --> Helper loaded: url_helper
INFO - 2023-07-29 18:47:14 --> Helper loaded: file_helper
INFO - 2023-07-29 18:47:14 --> Helper loaded: form_helper
INFO - 2023-07-29 18:47:14 --> Helper loaded: my_helper
INFO - 2023-07-29 18:47:14 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:47:14 --> Controller Class Initialized
DEBUG - 2023-07-29 18:47:14 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:47:14 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:47:14 --> Final output sent to browser
DEBUG - 2023-07-29 18:47:14 --> Total execution time: 0.0618
INFO - 2023-07-29 18:47:16 --> Config Class Initialized
INFO - 2023-07-29 18:47:16 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:47:16 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:47:16 --> Utf8 Class Initialized
INFO - 2023-07-29 18:47:16 --> URI Class Initialized
DEBUG - 2023-07-29 18:47:16 --> No URI present. Default controller set.
INFO - 2023-07-29 18:47:16 --> Router Class Initialized
INFO - 2023-07-29 18:47:16 --> Output Class Initialized
INFO - 2023-07-29 18:47:16 --> Security Class Initialized
DEBUG - 2023-07-29 18:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:47:16 --> Input Class Initialized
INFO - 2023-07-29 18:47:16 --> Language Class Initialized
INFO - 2023-07-29 18:47:16 --> Language Class Initialized
INFO - 2023-07-29 18:47:16 --> Config Class Initialized
INFO - 2023-07-29 18:47:16 --> Loader Class Initialized
INFO - 2023-07-29 18:47:16 --> Helper loaded: url_helper
INFO - 2023-07-29 18:47:16 --> Helper loaded: file_helper
INFO - 2023-07-29 18:47:16 --> Helper loaded: form_helper
INFO - 2023-07-29 18:47:16 --> Helper loaded: my_helper
INFO - 2023-07-29 18:47:16 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:47:16 --> Controller Class Initialized
DEBUG - 2023-07-29 18:47:16 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:47:16 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:47:16 --> Final output sent to browser
DEBUG - 2023-07-29 18:47:16 --> Total execution time: 0.0615
INFO - 2023-07-29 18:47:16 --> Config Class Initialized
INFO - 2023-07-29 18:47:16 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:47:16 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:47:16 --> Utf8 Class Initialized
INFO - 2023-07-29 18:47:16 --> URI Class Initialized
DEBUG - 2023-07-29 18:47:16 --> No URI present. Default controller set.
INFO - 2023-07-29 18:47:16 --> Router Class Initialized
INFO - 2023-07-29 18:47:16 --> Output Class Initialized
INFO - 2023-07-29 18:47:16 --> Security Class Initialized
DEBUG - 2023-07-29 18:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:47:16 --> Input Class Initialized
INFO - 2023-07-29 18:47:16 --> Language Class Initialized
INFO - 2023-07-29 18:47:16 --> Language Class Initialized
INFO - 2023-07-29 18:47:16 --> Config Class Initialized
INFO - 2023-07-29 18:47:16 --> Loader Class Initialized
INFO - 2023-07-29 18:47:16 --> Helper loaded: url_helper
INFO - 2023-07-29 18:47:16 --> Helper loaded: file_helper
INFO - 2023-07-29 18:47:16 --> Helper loaded: form_helper
INFO - 2023-07-29 18:47:16 --> Helper loaded: my_helper
INFO - 2023-07-29 18:47:16 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:47:17 --> Controller Class Initialized
DEBUG - 2023-07-29 18:47:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:47:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:47:17 --> Final output sent to browser
DEBUG - 2023-07-29 18:47:17 --> Total execution time: 0.0458
INFO - 2023-07-29 18:47:17 --> Config Class Initialized
INFO - 2023-07-29 18:47:17 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:47:17 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:47:17 --> Utf8 Class Initialized
INFO - 2023-07-29 18:47:17 --> URI Class Initialized
DEBUG - 2023-07-29 18:47:17 --> No URI present. Default controller set.
INFO - 2023-07-29 18:47:17 --> Router Class Initialized
INFO - 2023-07-29 18:47:17 --> Output Class Initialized
INFO - 2023-07-29 18:47:17 --> Security Class Initialized
DEBUG - 2023-07-29 18:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:47:17 --> Input Class Initialized
INFO - 2023-07-29 18:47:17 --> Language Class Initialized
INFO - 2023-07-29 18:47:17 --> Language Class Initialized
INFO - 2023-07-29 18:47:17 --> Config Class Initialized
INFO - 2023-07-29 18:47:17 --> Loader Class Initialized
INFO - 2023-07-29 18:47:17 --> Helper loaded: url_helper
INFO - 2023-07-29 18:47:17 --> Helper loaded: file_helper
INFO - 2023-07-29 18:47:17 --> Helper loaded: form_helper
INFO - 2023-07-29 18:47:17 --> Helper loaded: my_helper
INFO - 2023-07-29 18:47:17 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:47:17 --> Controller Class Initialized
DEBUG - 2023-07-29 18:47:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:47:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:47:17 --> Final output sent to browser
DEBUG - 2023-07-29 18:47:17 --> Total execution time: 0.0350
INFO - 2023-07-29 18:47:17 --> Config Class Initialized
INFO - 2023-07-29 18:47:17 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:47:17 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:47:17 --> Utf8 Class Initialized
INFO - 2023-07-29 18:47:17 --> URI Class Initialized
DEBUG - 2023-07-29 18:47:17 --> No URI present. Default controller set.
INFO - 2023-07-29 18:47:17 --> Router Class Initialized
INFO - 2023-07-29 18:47:17 --> Output Class Initialized
INFO - 2023-07-29 18:47:17 --> Security Class Initialized
DEBUG - 2023-07-29 18:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:47:17 --> Input Class Initialized
INFO - 2023-07-29 18:47:17 --> Language Class Initialized
INFO - 2023-07-29 18:47:17 --> Language Class Initialized
INFO - 2023-07-29 18:47:17 --> Config Class Initialized
INFO - 2023-07-29 18:47:17 --> Loader Class Initialized
INFO - 2023-07-29 18:47:17 --> Helper loaded: url_helper
INFO - 2023-07-29 18:47:17 --> Helper loaded: file_helper
INFO - 2023-07-29 18:47:17 --> Helper loaded: form_helper
INFO - 2023-07-29 18:47:17 --> Helper loaded: my_helper
INFO - 2023-07-29 18:47:17 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:47:17 --> Controller Class Initialized
DEBUG - 2023-07-29 18:47:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:47:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:47:17 --> Final output sent to browser
DEBUG - 2023-07-29 18:47:17 --> Total execution time: 0.0615
INFO - 2023-07-29 18:47:18 --> Config Class Initialized
INFO - 2023-07-29 18:47:18 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:47:18 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:47:18 --> Utf8 Class Initialized
INFO - 2023-07-29 18:47:18 --> URI Class Initialized
DEBUG - 2023-07-29 18:47:18 --> No URI present. Default controller set.
INFO - 2023-07-29 18:47:18 --> Router Class Initialized
INFO - 2023-07-29 18:47:18 --> Output Class Initialized
INFO - 2023-07-29 18:47:18 --> Security Class Initialized
DEBUG - 2023-07-29 18:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:47:18 --> Input Class Initialized
INFO - 2023-07-29 18:47:18 --> Language Class Initialized
INFO - 2023-07-29 18:47:18 --> Language Class Initialized
INFO - 2023-07-29 18:47:18 --> Config Class Initialized
INFO - 2023-07-29 18:47:18 --> Loader Class Initialized
INFO - 2023-07-29 18:47:18 --> Helper loaded: url_helper
INFO - 2023-07-29 18:47:18 --> Helper loaded: file_helper
INFO - 2023-07-29 18:47:18 --> Helper loaded: form_helper
INFO - 2023-07-29 18:47:18 --> Helper loaded: my_helper
INFO - 2023-07-29 18:47:18 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:47:18 --> Controller Class Initialized
DEBUG - 2023-07-29 18:47:18 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:47:18 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:47:18 --> Final output sent to browser
DEBUG - 2023-07-29 18:47:18 --> Total execution time: 0.0617
INFO - 2023-07-29 18:47:19 --> Config Class Initialized
INFO - 2023-07-29 18:47:19 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:47:19 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:47:19 --> Utf8 Class Initialized
INFO - 2023-07-29 18:47:19 --> URI Class Initialized
DEBUG - 2023-07-29 18:47:19 --> No URI present. Default controller set.
INFO - 2023-07-29 18:47:19 --> Router Class Initialized
INFO - 2023-07-29 18:47:19 --> Output Class Initialized
INFO - 2023-07-29 18:47:19 --> Security Class Initialized
DEBUG - 2023-07-29 18:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:47:19 --> Input Class Initialized
INFO - 2023-07-29 18:47:19 --> Language Class Initialized
INFO - 2023-07-29 18:47:19 --> Language Class Initialized
INFO - 2023-07-29 18:47:19 --> Config Class Initialized
INFO - 2023-07-29 18:47:19 --> Loader Class Initialized
INFO - 2023-07-29 18:47:19 --> Helper loaded: url_helper
INFO - 2023-07-29 18:47:19 --> Helper loaded: file_helper
INFO - 2023-07-29 18:47:19 --> Helper loaded: form_helper
INFO - 2023-07-29 18:47:19 --> Helper loaded: my_helper
INFO - 2023-07-29 18:47:19 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:47:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:47:19 --> Controller Class Initialized
DEBUG - 2023-07-29 18:47:19 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:47:19 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:47:19 --> Final output sent to browser
DEBUG - 2023-07-29 18:47:19 --> Total execution time: 0.0597
INFO - 2023-07-29 18:47:20 --> Config Class Initialized
INFO - 2023-07-29 18:47:20 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:47:20 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:47:20 --> Utf8 Class Initialized
INFO - 2023-07-29 18:47:20 --> URI Class Initialized
DEBUG - 2023-07-29 18:47:20 --> No URI present. Default controller set.
INFO - 2023-07-29 18:47:20 --> Router Class Initialized
INFO - 2023-07-29 18:47:20 --> Output Class Initialized
INFO - 2023-07-29 18:47:20 --> Security Class Initialized
DEBUG - 2023-07-29 18:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:47:20 --> Input Class Initialized
INFO - 2023-07-29 18:47:20 --> Language Class Initialized
INFO - 2023-07-29 18:47:20 --> Language Class Initialized
INFO - 2023-07-29 18:47:20 --> Config Class Initialized
INFO - 2023-07-29 18:47:20 --> Loader Class Initialized
INFO - 2023-07-29 18:47:20 --> Helper loaded: url_helper
INFO - 2023-07-29 18:47:20 --> Helper loaded: file_helper
INFO - 2023-07-29 18:47:20 --> Helper loaded: form_helper
INFO - 2023-07-29 18:47:20 --> Helper loaded: my_helper
INFO - 2023-07-29 18:47:20 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:47:20 --> Controller Class Initialized
DEBUG - 2023-07-29 18:47:20 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:47:20 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:47:20 --> Final output sent to browser
DEBUG - 2023-07-29 18:47:20 --> Total execution time: 0.0341
INFO - 2023-07-29 18:47:20 --> Config Class Initialized
INFO - 2023-07-29 18:47:20 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:47:20 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:47:20 --> Utf8 Class Initialized
INFO - 2023-07-29 18:47:20 --> URI Class Initialized
DEBUG - 2023-07-29 18:47:20 --> No URI present. Default controller set.
INFO - 2023-07-29 18:47:20 --> Router Class Initialized
INFO - 2023-07-29 18:47:20 --> Output Class Initialized
INFO - 2023-07-29 18:47:20 --> Security Class Initialized
DEBUG - 2023-07-29 18:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:47:20 --> Input Class Initialized
INFO - 2023-07-29 18:47:20 --> Language Class Initialized
INFO - 2023-07-29 18:47:20 --> Language Class Initialized
INFO - 2023-07-29 18:47:20 --> Config Class Initialized
INFO - 2023-07-29 18:47:20 --> Loader Class Initialized
INFO - 2023-07-29 18:47:20 --> Helper loaded: url_helper
INFO - 2023-07-29 18:47:20 --> Helper loaded: file_helper
INFO - 2023-07-29 18:47:20 --> Helper loaded: form_helper
INFO - 2023-07-29 18:47:20 --> Helper loaded: my_helper
INFO - 2023-07-29 18:47:20 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:47:20 --> Controller Class Initialized
DEBUG - 2023-07-29 18:47:20 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:47:20 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:47:20 --> Final output sent to browser
DEBUG - 2023-07-29 18:47:20 --> Total execution time: 0.0607
INFO - 2023-07-29 18:47:20 --> Config Class Initialized
INFO - 2023-07-29 18:47:20 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:47:20 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:47:20 --> Utf8 Class Initialized
INFO - 2023-07-29 18:47:20 --> URI Class Initialized
DEBUG - 2023-07-29 18:47:20 --> No URI present. Default controller set.
INFO - 2023-07-29 18:47:20 --> Router Class Initialized
INFO - 2023-07-29 18:47:20 --> Output Class Initialized
INFO - 2023-07-29 18:47:20 --> Security Class Initialized
DEBUG - 2023-07-29 18:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:47:20 --> Input Class Initialized
INFO - 2023-07-29 18:47:20 --> Language Class Initialized
INFO - 2023-07-29 18:47:20 --> Language Class Initialized
INFO - 2023-07-29 18:47:20 --> Config Class Initialized
INFO - 2023-07-29 18:47:20 --> Loader Class Initialized
INFO - 2023-07-29 18:47:20 --> Helper loaded: url_helper
INFO - 2023-07-29 18:47:20 --> Helper loaded: file_helper
INFO - 2023-07-29 18:47:20 --> Helper loaded: form_helper
INFO - 2023-07-29 18:47:20 --> Helper loaded: my_helper
INFO - 2023-07-29 18:47:20 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:47:20 --> Controller Class Initialized
DEBUG - 2023-07-29 18:47:20 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:47:20 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:47:20 --> Final output sent to browser
DEBUG - 2023-07-29 18:47:20 --> Total execution time: 0.0537
INFO - 2023-07-29 18:48:05 --> Config Class Initialized
INFO - 2023-07-29 18:48:05 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:48:05 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:48:05 --> Utf8 Class Initialized
INFO - 2023-07-29 18:48:05 --> URI Class Initialized
DEBUG - 2023-07-29 18:48:05 --> No URI present. Default controller set.
INFO - 2023-07-29 18:48:05 --> Router Class Initialized
INFO - 2023-07-29 18:48:05 --> Output Class Initialized
INFO - 2023-07-29 18:48:05 --> Security Class Initialized
DEBUG - 2023-07-29 18:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:48:05 --> Input Class Initialized
INFO - 2023-07-29 18:48:05 --> Language Class Initialized
INFO - 2023-07-29 18:48:05 --> Language Class Initialized
INFO - 2023-07-29 18:48:05 --> Config Class Initialized
INFO - 2023-07-29 18:48:05 --> Loader Class Initialized
INFO - 2023-07-29 18:48:05 --> Helper loaded: url_helper
INFO - 2023-07-29 18:48:05 --> Helper loaded: file_helper
INFO - 2023-07-29 18:48:05 --> Helper loaded: form_helper
INFO - 2023-07-29 18:48:05 --> Helper loaded: my_helper
INFO - 2023-07-29 18:48:05 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:48:05 --> Controller Class Initialized
DEBUG - 2023-07-29 18:48:05 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:48:05 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:48:05 --> Final output sent to browser
DEBUG - 2023-07-29 18:48:05 --> Total execution time: 0.0467
INFO - 2023-07-29 18:48:11 --> Config Class Initialized
INFO - 2023-07-29 18:48:11 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:48:11 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:48:11 --> Utf8 Class Initialized
INFO - 2023-07-29 18:48:11 --> URI Class Initialized
DEBUG - 2023-07-29 18:48:11 --> No URI present. Default controller set.
INFO - 2023-07-29 18:48:11 --> Router Class Initialized
INFO - 2023-07-29 18:48:11 --> Output Class Initialized
INFO - 2023-07-29 18:48:11 --> Security Class Initialized
DEBUG - 2023-07-29 18:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:48:11 --> Input Class Initialized
INFO - 2023-07-29 18:48:11 --> Language Class Initialized
INFO - 2023-07-29 18:48:11 --> Language Class Initialized
INFO - 2023-07-29 18:48:11 --> Config Class Initialized
INFO - 2023-07-29 18:48:11 --> Loader Class Initialized
INFO - 2023-07-29 18:48:11 --> Helper loaded: url_helper
INFO - 2023-07-29 18:48:11 --> Helper loaded: file_helper
INFO - 2023-07-29 18:48:11 --> Helper loaded: form_helper
INFO - 2023-07-29 18:48:11 --> Helper loaded: my_helper
INFO - 2023-07-29 18:48:11 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:48:11 --> Controller Class Initialized
DEBUG - 2023-07-29 18:48:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:48:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:48:11 --> Final output sent to browser
DEBUG - 2023-07-29 18:48:11 --> Total execution time: 0.0443
INFO - 2023-07-29 18:48:21 --> Config Class Initialized
INFO - 2023-07-29 18:48:21 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:48:21 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:48:21 --> Utf8 Class Initialized
INFO - 2023-07-29 18:48:21 --> URI Class Initialized
INFO - 2023-07-29 18:48:21 --> Router Class Initialized
INFO - 2023-07-29 18:48:21 --> Output Class Initialized
INFO - 2023-07-29 18:48:21 --> Security Class Initialized
DEBUG - 2023-07-29 18:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:48:21 --> Input Class Initialized
INFO - 2023-07-29 18:48:21 --> Language Class Initialized
INFO - 2023-07-29 18:48:21 --> Language Class Initialized
INFO - 2023-07-29 18:48:21 --> Config Class Initialized
INFO - 2023-07-29 18:48:21 --> Loader Class Initialized
INFO - 2023-07-29 18:48:21 --> Helper loaded: url_helper
INFO - 2023-07-29 18:48:21 --> Helper loaded: file_helper
INFO - 2023-07-29 18:48:21 --> Helper loaded: form_helper
INFO - 2023-07-29 18:48:21 --> Helper loaded: my_helper
INFO - 2023-07-29 18:48:21 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:48:21 --> Controller Class Initialized
DEBUG - 2023-07-29 18:48:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/tahun/views/list.php
DEBUG - 2023-07-29 18:48:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:48:21 --> Final output sent to browser
DEBUG - 2023-07-29 18:48:21 --> Total execution time: 0.0824
INFO - 2023-07-29 18:48:21 --> Config Class Initialized
INFO - 2023-07-29 18:48:21 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:48:21 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:48:21 --> Utf8 Class Initialized
INFO - 2023-07-29 18:48:21 --> URI Class Initialized
INFO - 2023-07-29 18:48:21 --> Router Class Initialized
INFO - 2023-07-29 18:48:21 --> Output Class Initialized
INFO - 2023-07-29 18:48:21 --> Security Class Initialized
DEBUG - 2023-07-29 18:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:48:21 --> Input Class Initialized
INFO - 2023-07-29 18:48:21 --> Language Class Initialized
INFO - 2023-07-29 18:48:21 --> Language Class Initialized
INFO - 2023-07-29 18:48:21 --> Config Class Initialized
INFO - 2023-07-29 18:48:21 --> Loader Class Initialized
INFO - 2023-07-29 18:48:21 --> Helper loaded: url_helper
INFO - 2023-07-29 18:48:21 --> Helper loaded: file_helper
INFO - 2023-07-29 18:48:21 --> Helper loaded: form_helper
INFO - 2023-07-29 18:48:21 --> Helper loaded: my_helper
INFO - 2023-07-29 18:48:21 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:48:21 --> Controller Class Initialized
INFO - 2023-07-29 18:48:25 --> Config Class Initialized
INFO - 2023-07-29 18:48:25 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:48:25 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:48:25 --> Utf8 Class Initialized
INFO - 2023-07-29 18:48:25 --> URI Class Initialized
INFO - 2023-07-29 18:48:25 --> Router Class Initialized
INFO - 2023-07-29 18:48:25 --> Output Class Initialized
INFO - 2023-07-29 18:48:25 --> Security Class Initialized
DEBUG - 2023-07-29 18:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:48:25 --> Input Class Initialized
INFO - 2023-07-29 18:48:25 --> Language Class Initialized
INFO - 2023-07-29 18:48:25 --> Language Class Initialized
INFO - 2023-07-29 18:48:25 --> Config Class Initialized
INFO - 2023-07-29 18:48:25 --> Loader Class Initialized
INFO - 2023-07-29 18:48:25 --> Helper loaded: url_helper
INFO - 2023-07-29 18:48:25 --> Helper loaded: file_helper
INFO - 2023-07-29 18:48:25 --> Helper loaded: form_helper
INFO - 2023-07-29 18:48:25 --> Helper loaded: my_helper
INFO - 2023-07-29 18:48:25 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:48:25 --> Controller Class Initialized
DEBUG - 2023-07-29 18:48:25 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/set_kelas/views/list.php
DEBUG - 2023-07-29 18:48:25 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:48:25 --> Final output sent to browser
DEBUG - 2023-07-29 18:48:25 --> Total execution time: 0.0982
INFO - 2023-07-29 18:48:30 --> Config Class Initialized
INFO - 2023-07-29 18:48:30 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:48:30 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:48:30 --> Utf8 Class Initialized
INFO - 2023-07-29 18:48:30 --> URI Class Initialized
DEBUG - 2023-07-29 18:48:30 --> No URI present. Default controller set.
INFO - 2023-07-29 18:48:30 --> Router Class Initialized
INFO - 2023-07-29 18:48:30 --> Output Class Initialized
INFO - 2023-07-29 18:48:30 --> Security Class Initialized
DEBUG - 2023-07-29 18:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:48:30 --> Input Class Initialized
INFO - 2023-07-29 18:48:30 --> Language Class Initialized
INFO - 2023-07-29 18:48:30 --> Language Class Initialized
INFO - 2023-07-29 18:48:30 --> Config Class Initialized
INFO - 2023-07-29 18:48:30 --> Loader Class Initialized
INFO - 2023-07-29 18:48:30 --> Helper loaded: url_helper
INFO - 2023-07-29 18:48:30 --> Helper loaded: file_helper
INFO - 2023-07-29 18:48:30 --> Helper loaded: form_helper
INFO - 2023-07-29 18:48:30 --> Helper loaded: my_helper
INFO - 2023-07-29 18:48:30 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:48:30 --> Controller Class Initialized
DEBUG - 2023-07-29 18:48:30 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:48:30 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:48:30 --> Final output sent to browser
DEBUG - 2023-07-29 18:48:30 --> Total execution time: 0.0430
INFO - 2023-07-29 18:49:15 --> Config Class Initialized
INFO - 2023-07-29 18:49:15 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:49:15 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:49:15 --> Utf8 Class Initialized
INFO - 2023-07-29 18:49:15 --> URI Class Initialized
INFO - 2023-07-29 18:49:15 --> Router Class Initialized
INFO - 2023-07-29 18:49:15 --> Output Class Initialized
INFO - 2023-07-29 18:49:15 --> Security Class Initialized
DEBUG - 2023-07-29 18:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:49:15 --> Input Class Initialized
INFO - 2023-07-29 18:49:15 --> Language Class Initialized
INFO - 2023-07-29 18:49:15 --> Language Class Initialized
INFO - 2023-07-29 18:49:15 --> Config Class Initialized
INFO - 2023-07-29 18:49:15 --> Loader Class Initialized
INFO - 2023-07-29 18:49:15 --> Helper loaded: url_helper
INFO - 2023-07-29 18:49:15 --> Helper loaded: file_helper
INFO - 2023-07-29 18:49:15 --> Helper loaded: form_helper
INFO - 2023-07-29 18:49:15 --> Helper loaded: my_helper
INFO - 2023-07-29 18:49:15 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:49:15 --> Controller Class Initialized
DEBUG - 2023-07-29 18:49:15 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_guru/views/list.php
DEBUG - 2023-07-29 18:49:15 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:49:15 --> Final output sent to browser
DEBUG - 2023-07-29 18:49:15 --> Total execution time: 0.0388
INFO - 2023-07-29 18:49:15 --> Config Class Initialized
INFO - 2023-07-29 18:49:15 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:49:15 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:49:15 --> Utf8 Class Initialized
INFO - 2023-07-29 18:49:15 --> URI Class Initialized
INFO - 2023-07-29 18:49:15 --> Router Class Initialized
INFO - 2023-07-29 18:49:15 --> Output Class Initialized
INFO - 2023-07-29 18:49:15 --> Security Class Initialized
DEBUG - 2023-07-29 18:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:49:15 --> Input Class Initialized
INFO - 2023-07-29 18:49:15 --> Language Class Initialized
INFO - 2023-07-29 18:49:15 --> Language Class Initialized
INFO - 2023-07-29 18:49:15 --> Config Class Initialized
INFO - 2023-07-29 18:49:15 --> Loader Class Initialized
INFO - 2023-07-29 18:49:15 --> Helper loaded: url_helper
INFO - 2023-07-29 18:49:15 --> Helper loaded: file_helper
INFO - 2023-07-29 18:49:15 --> Helper loaded: form_helper
INFO - 2023-07-29 18:49:15 --> Helper loaded: my_helper
INFO - 2023-07-29 18:49:15 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:49:15 --> Controller Class Initialized
INFO - 2023-07-29 18:49:17 --> Config Class Initialized
INFO - 2023-07-29 18:49:17 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:49:17 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:49:17 --> Utf8 Class Initialized
INFO - 2023-07-29 18:49:17 --> URI Class Initialized
INFO - 2023-07-29 18:49:17 --> Router Class Initialized
INFO - 2023-07-29 18:49:17 --> Output Class Initialized
INFO - 2023-07-29 18:49:17 --> Security Class Initialized
DEBUG - 2023-07-29 18:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:49:17 --> Input Class Initialized
INFO - 2023-07-29 18:49:17 --> Language Class Initialized
INFO - 2023-07-29 18:49:17 --> Language Class Initialized
INFO - 2023-07-29 18:49:17 --> Config Class Initialized
INFO - 2023-07-29 18:49:17 --> Loader Class Initialized
INFO - 2023-07-29 18:49:17 --> Helper loaded: url_helper
INFO - 2023-07-29 18:49:17 --> Helper loaded: file_helper
INFO - 2023-07-29 18:49:17 --> Helper loaded: form_helper
INFO - 2023-07-29 18:49:17 --> Helper loaded: my_helper
INFO - 2023-07-29 18:49:17 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:49:17 --> Controller Class Initialized
DEBUG - 2023-07-29 18:49:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-29 18:49:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:49:17 --> Final output sent to browser
DEBUG - 2023-07-29 18:49:17 --> Total execution time: 0.0749
INFO - 2023-07-29 18:49:17 --> Config Class Initialized
INFO - 2023-07-29 18:49:17 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:49:17 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:49:17 --> Utf8 Class Initialized
INFO - 2023-07-29 18:49:17 --> URI Class Initialized
INFO - 2023-07-29 18:49:17 --> Router Class Initialized
INFO - 2023-07-29 18:49:17 --> Output Class Initialized
INFO - 2023-07-29 18:49:17 --> Security Class Initialized
DEBUG - 2023-07-29 18:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:49:17 --> Input Class Initialized
INFO - 2023-07-29 18:49:17 --> Language Class Initialized
INFO - 2023-07-29 18:49:17 --> Language Class Initialized
INFO - 2023-07-29 18:49:17 --> Config Class Initialized
INFO - 2023-07-29 18:49:17 --> Loader Class Initialized
INFO - 2023-07-29 18:49:17 --> Helper loaded: url_helper
INFO - 2023-07-29 18:49:17 --> Helper loaded: file_helper
INFO - 2023-07-29 18:49:17 --> Helper loaded: form_helper
INFO - 2023-07-29 18:49:17 --> Helper loaded: my_helper
INFO - 2023-07-29 18:49:17 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:49:17 --> Controller Class Initialized
INFO - 2023-07-29 18:49:18 --> Config Class Initialized
INFO - 2023-07-29 18:49:18 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:49:18 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:49:18 --> Utf8 Class Initialized
INFO - 2023-07-29 18:49:18 --> URI Class Initialized
INFO - 2023-07-29 18:49:18 --> Router Class Initialized
INFO - 2023-07-29 18:49:18 --> Output Class Initialized
INFO - 2023-07-29 18:49:18 --> Security Class Initialized
DEBUG - 2023-07-29 18:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:49:18 --> Input Class Initialized
INFO - 2023-07-29 18:49:18 --> Language Class Initialized
INFO - 2023-07-29 18:49:18 --> Language Class Initialized
INFO - 2023-07-29 18:49:18 --> Config Class Initialized
INFO - 2023-07-29 18:49:18 --> Loader Class Initialized
INFO - 2023-07-29 18:49:18 --> Helper loaded: url_helper
INFO - 2023-07-29 18:49:18 --> Helper loaded: file_helper
INFO - 2023-07-29 18:49:18 --> Helper loaded: form_helper
INFO - 2023-07-29 18:49:18 --> Helper loaded: my_helper
INFO - 2023-07-29 18:49:18 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:49:19 --> Controller Class Initialized
DEBUG - 2023-07-29 18:49:19 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_kelas/views/list.php
DEBUG - 2023-07-29 18:49:19 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:49:19 --> Final output sent to browser
DEBUG - 2023-07-29 18:49:19 --> Total execution time: 0.1019
INFO - 2023-07-29 18:49:19 --> Config Class Initialized
INFO - 2023-07-29 18:49:19 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:49:19 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:49:19 --> Utf8 Class Initialized
INFO - 2023-07-29 18:49:19 --> URI Class Initialized
INFO - 2023-07-29 18:49:19 --> Router Class Initialized
INFO - 2023-07-29 18:49:19 --> Output Class Initialized
INFO - 2023-07-29 18:49:19 --> Security Class Initialized
DEBUG - 2023-07-29 18:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:49:19 --> Input Class Initialized
INFO - 2023-07-29 18:49:19 --> Language Class Initialized
INFO - 2023-07-29 18:49:19 --> Language Class Initialized
INFO - 2023-07-29 18:49:19 --> Config Class Initialized
INFO - 2023-07-29 18:49:19 --> Loader Class Initialized
INFO - 2023-07-29 18:49:19 --> Helper loaded: url_helper
INFO - 2023-07-29 18:49:19 --> Helper loaded: file_helper
INFO - 2023-07-29 18:49:19 --> Helper loaded: form_helper
INFO - 2023-07-29 18:49:19 --> Helper loaded: my_helper
INFO - 2023-07-29 18:49:19 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:49:19 --> Controller Class Initialized
INFO - 2023-07-29 18:49:21 --> Config Class Initialized
INFO - 2023-07-29 18:49:21 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:49:21 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:49:21 --> Utf8 Class Initialized
INFO - 2023-07-29 18:49:21 --> URI Class Initialized
INFO - 2023-07-29 18:49:21 --> Router Class Initialized
INFO - 2023-07-29 18:49:21 --> Output Class Initialized
INFO - 2023-07-29 18:49:21 --> Security Class Initialized
DEBUG - 2023-07-29 18:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:49:21 --> Input Class Initialized
INFO - 2023-07-29 18:49:21 --> Language Class Initialized
INFO - 2023-07-29 18:49:21 --> Language Class Initialized
INFO - 2023-07-29 18:49:21 --> Config Class Initialized
INFO - 2023-07-29 18:49:21 --> Loader Class Initialized
INFO - 2023-07-29 18:49:21 --> Helper loaded: url_helper
INFO - 2023-07-29 18:49:21 --> Helper loaded: file_helper
INFO - 2023-07-29 18:49:21 --> Helper loaded: form_helper
INFO - 2023-07-29 18:49:21 --> Helper loaded: my_helper
INFO - 2023-07-29 18:49:21 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:49:21 --> Controller Class Initialized
DEBUG - 2023-07-29 18:49:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_mapel/views/list.php
DEBUG - 2023-07-29 18:49:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:49:21 --> Final output sent to browser
DEBUG - 2023-07-29 18:49:21 --> Total execution time: 0.0383
INFO - 2023-07-29 18:49:22 --> Config Class Initialized
INFO - 2023-07-29 18:49:22 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:49:22 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:49:22 --> Utf8 Class Initialized
INFO - 2023-07-29 18:49:22 --> URI Class Initialized
INFO - 2023-07-29 18:49:22 --> Router Class Initialized
INFO - 2023-07-29 18:49:22 --> Output Class Initialized
INFO - 2023-07-29 18:49:22 --> Security Class Initialized
DEBUG - 2023-07-29 18:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:49:22 --> Input Class Initialized
INFO - 2023-07-29 18:49:22 --> Language Class Initialized
INFO - 2023-07-29 18:49:22 --> Language Class Initialized
INFO - 2023-07-29 18:49:22 --> Config Class Initialized
INFO - 2023-07-29 18:49:22 --> Loader Class Initialized
INFO - 2023-07-29 18:49:22 --> Helper loaded: url_helper
INFO - 2023-07-29 18:49:22 --> Helper loaded: file_helper
INFO - 2023-07-29 18:49:22 --> Helper loaded: form_helper
INFO - 2023-07-29 18:49:22 --> Helper loaded: my_helper
INFO - 2023-07-29 18:49:22 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:49:22 --> Controller Class Initialized
INFO - 2023-07-29 18:49:27 --> Config Class Initialized
INFO - 2023-07-29 18:49:27 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:49:27 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:49:27 --> Utf8 Class Initialized
INFO - 2023-07-29 18:49:27 --> URI Class Initialized
INFO - 2023-07-29 18:49:27 --> Router Class Initialized
INFO - 2023-07-29 18:49:27 --> Output Class Initialized
INFO - 2023-07-29 18:49:27 --> Security Class Initialized
DEBUG - 2023-07-29 18:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:49:27 --> Input Class Initialized
INFO - 2023-07-29 18:49:27 --> Language Class Initialized
INFO - 2023-07-29 18:49:27 --> Language Class Initialized
INFO - 2023-07-29 18:49:27 --> Config Class Initialized
INFO - 2023-07-29 18:49:27 --> Loader Class Initialized
INFO - 2023-07-29 18:49:27 --> Helper loaded: url_helper
INFO - 2023-07-29 18:49:27 --> Helper loaded: file_helper
INFO - 2023-07-29 18:49:27 --> Helper loaded: form_helper
INFO - 2023-07-29 18:49:27 --> Helper loaded: my_helper
INFO - 2023-07-29 18:49:27 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:49:27 --> Controller Class Initialized
INFO - 2023-07-29 18:49:31 --> Config Class Initialized
INFO - 2023-07-29 18:49:31 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:49:31 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:49:31 --> Utf8 Class Initialized
INFO - 2023-07-29 18:49:31 --> URI Class Initialized
INFO - 2023-07-29 18:49:31 --> Router Class Initialized
INFO - 2023-07-29 18:49:31 --> Output Class Initialized
INFO - 2023-07-29 18:49:31 --> Security Class Initialized
DEBUG - 2023-07-29 18:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:49:31 --> Input Class Initialized
INFO - 2023-07-29 18:49:31 --> Language Class Initialized
INFO - 2023-07-29 18:49:31 --> Language Class Initialized
INFO - 2023-07-29 18:49:31 --> Config Class Initialized
INFO - 2023-07-29 18:49:31 --> Loader Class Initialized
INFO - 2023-07-29 18:49:31 --> Helper loaded: url_helper
INFO - 2023-07-29 18:49:31 --> Helper loaded: file_helper
INFO - 2023-07-29 18:49:31 --> Helper loaded: form_helper
INFO - 2023-07-29 18:49:31 --> Helper loaded: my_helper
INFO - 2023-07-29 18:49:31 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:49:31 --> Controller Class Initialized
INFO - 2023-07-29 18:49:54 --> Config Class Initialized
INFO - 2023-07-29 18:49:54 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:49:54 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:49:54 --> Utf8 Class Initialized
INFO - 2023-07-29 18:49:54 --> URI Class Initialized
DEBUG - 2023-07-29 18:49:54 --> No URI present. Default controller set.
INFO - 2023-07-29 18:49:54 --> Router Class Initialized
INFO - 2023-07-29 18:49:54 --> Output Class Initialized
INFO - 2023-07-29 18:49:54 --> Security Class Initialized
DEBUG - 2023-07-29 18:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:49:54 --> Input Class Initialized
INFO - 2023-07-29 18:49:54 --> Language Class Initialized
INFO - 2023-07-29 18:49:54 --> Language Class Initialized
INFO - 2023-07-29 18:49:54 --> Config Class Initialized
INFO - 2023-07-29 18:49:54 --> Loader Class Initialized
INFO - 2023-07-29 18:49:54 --> Helper loaded: url_helper
INFO - 2023-07-29 18:49:54 --> Helper loaded: file_helper
INFO - 2023-07-29 18:49:54 --> Helper loaded: form_helper
INFO - 2023-07-29 18:49:54 --> Helper loaded: my_helper
INFO - 2023-07-29 18:49:54 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:49:54 --> Controller Class Initialized
DEBUG - 2023-07-29 18:49:54 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:49:54 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:49:54 --> Final output sent to browser
DEBUG - 2023-07-29 18:49:54 --> Total execution time: 0.0636
INFO - 2023-07-29 18:50:08 --> Config Class Initialized
INFO - 2023-07-29 18:50:08 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:50:08 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:50:08 --> Utf8 Class Initialized
INFO - 2023-07-29 18:50:08 --> URI Class Initialized
DEBUG - 2023-07-29 18:50:08 --> No URI present. Default controller set.
INFO - 2023-07-29 18:50:08 --> Router Class Initialized
INFO - 2023-07-29 18:50:08 --> Output Class Initialized
INFO - 2023-07-29 18:50:08 --> Security Class Initialized
DEBUG - 2023-07-29 18:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:50:08 --> Input Class Initialized
INFO - 2023-07-29 18:50:08 --> Language Class Initialized
INFO - 2023-07-29 18:50:08 --> Language Class Initialized
INFO - 2023-07-29 18:50:08 --> Config Class Initialized
INFO - 2023-07-29 18:50:08 --> Loader Class Initialized
INFO - 2023-07-29 18:50:08 --> Helper loaded: url_helper
INFO - 2023-07-29 18:50:08 --> Helper loaded: file_helper
INFO - 2023-07-29 18:50:08 --> Helper loaded: form_helper
INFO - 2023-07-29 18:50:08 --> Helper loaded: my_helper
INFO - 2023-07-29 18:50:08 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:50:08 --> Controller Class Initialized
DEBUG - 2023-07-29 18:50:08 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:50:08 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:50:08 --> Final output sent to browser
DEBUG - 2023-07-29 18:50:08 --> Total execution time: 0.0614
INFO - 2023-07-29 18:50:11 --> Config Class Initialized
INFO - 2023-07-29 18:50:11 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:50:11 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:50:11 --> Utf8 Class Initialized
INFO - 2023-07-29 18:50:11 --> URI Class Initialized
INFO - 2023-07-29 18:50:11 --> Router Class Initialized
INFO - 2023-07-29 18:50:11 --> Output Class Initialized
INFO - 2023-07-29 18:50:11 --> Security Class Initialized
DEBUG - 2023-07-29 18:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:50:11 --> Input Class Initialized
INFO - 2023-07-29 18:50:11 --> Language Class Initialized
INFO - 2023-07-29 18:50:11 --> Language Class Initialized
INFO - 2023-07-29 18:50:11 --> Config Class Initialized
INFO - 2023-07-29 18:50:11 --> Loader Class Initialized
INFO - 2023-07-29 18:50:11 --> Helper loaded: url_helper
INFO - 2023-07-29 18:50:11 --> Helper loaded: file_helper
INFO - 2023-07-29 18:50:11 --> Helper loaded: form_helper
INFO - 2023-07-29 18:50:11 --> Helper loaded: my_helper
INFO - 2023-07-29 18:50:11 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:50:11 --> Controller Class Initialized
DEBUG - 2023-07-29 18:50:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_guru/views/list.php
DEBUG - 2023-07-29 18:50:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:50:11 --> Final output sent to browser
DEBUG - 2023-07-29 18:50:11 --> Total execution time: 0.0495
INFO - 2023-07-29 18:50:11 --> Config Class Initialized
INFO - 2023-07-29 18:50:11 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:50:11 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:50:11 --> Utf8 Class Initialized
INFO - 2023-07-29 18:50:11 --> URI Class Initialized
INFO - 2023-07-29 18:50:11 --> Router Class Initialized
INFO - 2023-07-29 18:50:11 --> Output Class Initialized
INFO - 2023-07-29 18:50:11 --> Security Class Initialized
DEBUG - 2023-07-29 18:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:50:11 --> Input Class Initialized
INFO - 2023-07-29 18:50:11 --> Language Class Initialized
INFO - 2023-07-29 18:50:11 --> Language Class Initialized
INFO - 2023-07-29 18:50:11 --> Config Class Initialized
INFO - 2023-07-29 18:50:11 --> Loader Class Initialized
INFO - 2023-07-29 18:50:11 --> Helper loaded: url_helper
INFO - 2023-07-29 18:50:11 --> Helper loaded: file_helper
INFO - 2023-07-29 18:50:11 --> Helper loaded: form_helper
INFO - 2023-07-29 18:50:11 --> Helper loaded: my_helper
INFO - 2023-07-29 18:50:11 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:50:11 --> Controller Class Initialized
INFO - 2023-07-29 18:50:13 --> Config Class Initialized
INFO - 2023-07-29 18:50:13 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:50:13 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:50:13 --> Utf8 Class Initialized
INFO - 2023-07-29 18:50:13 --> URI Class Initialized
INFO - 2023-07-29 18:50:13 --> Router Class Initialized
INFO - 2023-07-29 18:50:13 --> Output Class Initialized
INFO - 2023-07-29 18:50:13 --> Security Class Initialized
DEBUG - 2023-07-29 18:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:50:13 --> Input Class Initialized
INFO - 2023-07-29 18:50:13 --> Language Class Initialized
INFO - 2023-07-29 18:50:13 --> Language Class Initialized
INFO - 2023-07-29 18:50:13 --> Config Class Initialized
INFO - 2023-07-29 18:50:13 --> Loader Class Initialized
INFO - 2023-07-29 18:50:13 --> Helper loaded: url_helper
INFO - 2023-07-29 18:50:13 --> Helper loaded: file_helper
INFO - 2023-07-29 18:50:13 --> Helper loaded: form_helper
INFO - 2023-07-29 18:50:13 --> Helper loaded: my_helper
INFO - 2023-07-29 18:50:13 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:50:13 --> Controller Class Initialized
DEBUG - 2023-07-29 18:50:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-29 18:50:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:50:13 --> Final output sent to browser
DEBUG - 2023-07-29 18:50:13 --> Total execution time: 0.0412
INFO - 2023-07-29 18:50:13 --> Config Class Initialized
INFO - 2023-07-29 18:50:13 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:50:13 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:50:13 --> Utf8 Class Initialized
INFO - 2023-07-29 18:50:13 --> URI Class Initialized
INFO - 2023-07-29 18:50:13 --> Router Class Initialized
INFO - 2023-07-29 18:50:13 --> Output Class Initialized
INFO - 2023-07-29 18:50:13 --> Security Class Initialized
DEBUG - 2023-07-29 18:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:50:13 --> Input Class Initialized
INFO - 2023-07-29 18:50:13 --> Language Class Initialized
INFO - 2023-07-29 18:50:13 --> Language Class Initialized
INFO - 2023-07-29 18:50:13 --> Config Class Initialized
INFO - 2023-07-29 18:50:13 --> Loader Class Initialized
INFO - 2023-07-29 18:50:13 --> Helper loaded: url_helper
INFO - 2023-07-29 18:50:13 --> Helper loaded: file_helper
INFO - 2023-07-29 18:50:13 --> Helper loaded: form_helper
INFO - 2023-07-29 18:50:13 --> Helper loaded: my_helper
INFO - 2023-07-29 18:50:13 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:50:13 --> Controller Class Initialized
INFO - 2023-07-29 18:50:26 --> Config Class Initialized
INFO - 2023-07-29 18:50:26 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:50:26 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:50:26 --> Utf8 Class Initialized
INFO - 2023-07-29 18:50:26 --> URI Class Initialized
INFO - 2023-07-29 18:50:26 --> Router Class Initialized
INFO - 2023-07-29 18:50:26 --> Output Class Initialized
INFO - 2023-07-29 18:50:26 --> Security Class Initialized
DEBUG - 2023-07-29 18:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:50:26 --> Input Class Initialized
INFO - 2023-07-29 18:50:26 --> Language Class Initialized
INFO - 2023-07-29 18:50:26 --> Language Class Initialized
INFO - 2023-07-29 18:50:26 --> Config Class Initialized
INFO - 2023-07-29 18:50:26 --> Loader Class Initialized
INFO - 2023-07-29 18:50:26 --> Helper loaded: url_helper
INFO - 2023-07-29 18:50:26 --> Helper loaded: file_helper
INFO - 2023-07-29 18:50:26 --> Helper loaded: form_helper
INFO - 2023-07-29 18:50:26 --> Helper loaded: my_helper
INFO - 2023-07-29 18:50:26 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:50:26 --> Controller Class Initialized
INFO - 2023-07-29 18:50:26 --> Config Class Initialized
INFO - 2023-07-29 18:50:26 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:50:26 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:50:26 --> Utf8 Class Initialized
INFO - 2023-07-29 18:50:26 --> URI Class Initialized
INFO - 2023-07-29 18:50:26 --> Router Class Initialized
INFO - 2023-07-29 18:50:26 --> Output Class Initialized
INFO - 2023-07-29 18:50:26 --> Security Class Initialized
DEBUG - 2023-07-29 18:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:50:26 --> Input Class Initialized
INFO - 2023-07-29 18:50:26 --> Language Class Initialized
INFO - 2023-07-29 18:50:26 --> Language Class Initialized
INFO - 2023-07-29 18:50:26 --> Config Class Initialized
INFO - 2023-07-29 18:50:26 --> Loader Class Initialized
INFO - 2023-07-29 18:50:26 --> Helper loaded: url_helper
INFO - 2023-07-29 18:50:26 --> Helper loaded: file_helper
INFO - 2023-07-29 18:50:26 --> Helper loaded: form_helper
INFO - 2023-07-29 18:50:26 --> Helper loaded: my_helper
INFO - 2023-07-29 18:50:26 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:50:26 --> Controller Class Initialized
DEBUG - 2023-07-29 18:50:26 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-29 18:50:26 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:50:26 --> Final output sent to browser
DEBUG - 2023-07-29 18:50:26 --> Total execution time: 0.0618
INFO - 2023-07-29 18:50:26 --> Config Class Initialized
INFO - 2023-07-29 18:50:26 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:50:26 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:50:26 --> Utf8 Class Initialized
INFO - 2023-07-29 18:50:26 --> URI Class Initialized
INFO - 2023-07-29 18:50:26 --> Router Class Initialized
INFO - 2023-07-29 18:50:26 --> Output Class Initialized
INFO - 2023-07-29 18:50:26 --> Security Class Initialized
DEBUG - 2023-07-29 18:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:50:26 --> Input Class Initialized
INFO - 2023-07-29 18:50:26 --> Language Class Initialized
INFO - 2023-07-29 18:50:26 --> Language Class Initialized
INFO - 2023-07-29 18:50:26 --> Config Class Initialized
INFO - 2023-07-29 18:50:26 --> Loader Class Initialized
INFO - 2023-07-29 18:50:26 --> Helper loaded: url_helper
INFO - 2023-07-29 18:50:26 --> Helper loaded: file_helper
INFO - 2023-07-29 18:50:26 --> Helper loaded: form_helper
INFO - 2023-07-29 18:50:26 --> Helper loaded: my_helper
INFO - 2023-07-29 18:50:26 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:50:26 --> Controller Class Initialized
INFO - 2023-07-29 18:50:35 --> Config Class Initialized
INFO - 2023-07-29 18:50:35 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:50:35 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:50:35 --> Utf8 Class Initialized
INFO - 2023-07-29 18:50:35 --> URI Class Initialized
INFO - 2023-07-29 18:50:35 --> Router Class Initialized
INFO - 2023-07-29 18:50:35 --> Output Class Initialized
INFO - 2023-07-29 18:50:35 --> Security Class Initialized
DEBUG - 2023-07-29 18:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:50:35 --> Input Class Initialized
INFO - 2023-07-29 18:50:35 --> Language Class Initialized
INFO - 2023-07-29 18:50:35 --> Language Class Initialized
INFO - 2023-07-29 18:50:35 --> Config Class Initialized
INFO - 2023-07-29 18:50:35 --> Loader Class Initialized
INFO - 2023-07-29 18:50:35 --> Helper loaded: url_helper
INFO - 2023-07-29 18:50:35 --> Helper loaded: file_helper
INFO - 2023-07-29 18:50:35 --> Helper loaded: form_helper
INFO - 2023-07-29 18:50:35 --> Helper loaded: my_helper
INFO - 2023-07-29 18:50:35 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:50:35 --> Controller Class Initialized
DEBUG - 2023-07-29 18:50:35 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_kelas/views/list.php
DEBUG - 2023-07-29 18:50:35 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:50:35 --> Final output sent to browser
DEBUG - 2023-07-29 18:50:35 --> Total execution time: 0.0586
INFO - 2023-07-29 18:50:35 --> Config Class Initialized
INFO - 2023-07-29 18:50:35 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:50:35 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:50:35 --> Utf8 Class Initialized
INFO - 2023-07-29 18:50:35 --> URI Class Initialized
INFO - 2023-07-29 18:50:35 --> Router Class Initialized
INFO - 2023-07-29 18:50:35 --> Output Class Initialized
INFO - 2023-07-29 18:50:35 --> Security Class Initialized
DEBUG - 2023-07-29 18:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:50:35 --> Input Class Initialized
INFO - 2023-07-29 18:50:35 --> Language Class Initialized
INFO - 2023-07-29 18:50:35 --> Language Class Initialized
INFO - 2023-07-29 18:50:35 --> Config Class Initialized
INFO - 2023-07-29 18:50:35 --> Loader Class Initialized
INFO - 2023-07-29 18:50:35 --> Helper loaded: url_helper
INFO - 2023-07-29 18:50:35 --> Helper loaded: file_helper
INFO - 2023-07-29 18:50:35 --> Helper loaded: form_helper
INFO - 2023-07-29 18:50:35 --> Helper loaded: my_helper
INFO - 2023-07-29 18:50:35 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:50:35 --> Controller Class Initialized
INFO - 2023-07-29 18:50:40 --> Config Class Initialized
INFO - 2023-07-29 18:50:40 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:50:40 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:50:40 --> Utf8 Class Initialized
INFO - 2023-07-29 18:50:40 --> URI Class Initialized
INFO - 2023-07-29 18:50:40 --> Router Class Initialized
INFO - 2023-07-29 18:50:40 --> Output Class Initialized
INFO - 2023-07-29 18:50:40 --> Security Class Initialized
DEBUG - 2023-07-29 18:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:50:40 --> Input Class Initialized
INFO - 2023-07-29 18:50:40 --> Language Class Initialized
INFO - 2023-07-29 18:50:40 --> Language Class Initialized
INFO - 2023-07-29 18:50:40 --> Config Class Initialized
INFO - 2023-07-29 18:50:40 --> Loader Class Initialized
INFO - 2023-07-29 18:50:40 --> Helper loaded: url_helper
INFO - 2023-07-29 18:50:40 --> Helper loaded: file_helper
INFO - 2023-07-29 18:50:40 --> Helper loaded: form_helper
INFO - 2023-07-29 18:50:40 --> Helper loaded: my_helper
INFO - 2023-07-29 18:50:40 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:50:40 --> Controller Class Initialized
INFO - 2023-07-29 18:50:46 --> Config Class Initialized
INFO - 2023-07-29 18:50:46 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:50:46 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:50:46 --> Utf8 Class Initialized
INFO - 2023-07-29 18:50:46 --> URI Class Initialized
INFO - 2023-07-29 18:50:46 --> Router Class Initialized
INFO - 2023-07-29 18:50:46 --> Output Class Initialized
INFO - 2023-07-29 18:50:46 --> Security Class Initialized
DEBUG - 2023-07-29 18:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:50:46 --> Input Class Initialized
INFO - 2023-07-29 18:50:46 --> Language Class Initialized
INFO - 2023-07-29 18:50:46 --> Language Class Initialized
INFO - 2023-07-29 18:50:46 --> Config Class Initialized
INFO - 2023-07-29 18:50:46 --> Loader Class Initialized
INFO - 2023-07-29 18:50:46 --> Helper loaded: url_helper
INFO - 2023-07-29 18:50:46 --> Helper loaded: file_helper
INFO - 2023-07-29 18:50:46 --> Helper loaded: form_helper
INFO - 2023-07-29 18:50:46 --> Helper loaded: my_helper
INFO - 2023-07-29 18:50:46 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:50:46 --> Controller Class Initialized
DEBUG - 2023-07-29 18:50:46 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_mapel/views/list.php
DEBUG - 2023-07-29 18:50:46 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:50:46 --> Final output sent to browser
DEBUG - 2023-07-29 18:50:46 --> Total execution time: 0.0476
INFO - 2023-07-29 18:50:46 --> Config Class Initialized
INFO - 2023-07-29 18:50:46 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:50:46 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:50:46 --> Utf8 Class Initialized
INFO - 2023-07-29 18:50:46 --> URI Class Initialized
INFO - 2023-07-29 18:50:46 --> Router Class Initialized
INFO - 2023-07-29 18:50:46 --> Output Class Initialized
INFO - 2023-07-29 18:50:46 --> Security Class Initialized
DEBUG - 2023-07-29 18:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:50:46 --> Input Class Initialized
INFO - 2023-07-29 18:50:46 --> Language Class Initialized
INFO - 2023-07-29 18:50:46 --> Language Class Initialized
INFO - 2023-07-29 18:50:46 --> Config Class Initialized
INFO - 2023-07-29 18:50:46 --> Loader Class Initialized
INFO - 2023-07-29 18:50:46 --> Helper loaded: url_helper
INFO - 2023-07-29 18:50:46 --> Helper loaded: file_helper
INFO - 2023-07-29 18:50:46 --> Helper loaded: form_helper
INFO - 2023-07-29 18:50:46 --> Helper loaded: my_helper
INFO - 2023-07-29 18:50:46 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:50:46 --> Controller Class Initialized
INFO - 2023-07-29 18:50:50 --> Config Class Initialized
INFO - 2023-07-29 18:50:50 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:50:50 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:50:50 --> Utf8 Class Initialized
INFO - 2023-07-29 18:50:50 --> URI Class Initialized
INFO - 2023-07-29 18:50:50 --> Router Class Initialized
INFO - 2023-07-29 18:50:50 --> Output Class Initialized
INFO - 2023-07-29 18:50:50 --> Security Class Initialized
DEBUG - 2023-07-29 18:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:50:50 --> Input Class Initialized
INFO - 2023-07-29 18:50:50 --> Language Class Initialized
INFO - 2023-07-29 18:50:50 --> Language Class Initialized
INFO - 2023-07-29 18:50:50 --> Config Class Initialized
INFO - 2023-07-29 18:50:50 --> Loader Class Initialized
INFO - 2023-07-29 18:50:50 --> Helper loaded: url_helper
INFO - 2023-07-29 18:50:50 --> Helper loaded: file_helper
INFO - 2023-07-29 18:50:50 --> Helper loaded: form_helper
INFO - 2023-07-29 18:50:50 --> Helper loaded: my_helper
INFO - 2023-07-29 18:50:50 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:50:50 --> Controller Class Initialized
INFO - 2023-07-29 18:50:53 --> Config Class Initialized
INFO - 2023-07-29 18:50:53 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:50:53 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:50:53 --> Utf8 Class Initialized
INFO - 2023-07-29 18:50:53 --> URI Class Initialized
INFO - 2023-07-29 18:50:53 --> Router Class Initialized
INFO - 2023-07-29 18:50:53 --> Output Class Initialized
INFO - 2023-07-29 18:50:53 --> Security Class Initialized
DEBUG - 2023-07-29 18:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:50:53 --> Input Class Initialized
INFO - 2023-07-29 18:50:53 --> Language Class Initialized
INFO - 2023-07-29 18:50:53 --> Language Class Initialized
INFO - 2023-07-29 18:50:53 --> Config Class Initialized
INFO - 2023-07-29 18:50:53 --> Loader Class Initialized
INFO - 2023-07-29 18:50:53 --> Helper loaded: url_helper
INFO - 2023-07-29 18:50:53 --> Helper loaded: file_helper
INFO - 2023-07-29 18:50:53 --> Helper loaded: form_helper
INFO - 2023-07-29 18:50:53 --> Helper loaded: my_helper
INFO - 2023-07-29 18:50:53 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:50:53 --> Controller Class Initialized
DEBUG - 2023-07-29 18:50:53 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_mapel/views/list.php
DEBUG - 2023-07-29 18:50:53 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:50:53 --> Final output sent to browser
DEBUG - 2023-07-29 18:50:53 --> Total execution time: 0.0568
INFO - 2023-07-29 18:50:53 --> Config Class Initialized
INFO - 2023-07-29 18:50:53 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:50:53 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:50:53 --> Utf8 Class Initialized
INFO - 2023-07-29 18:50:53 --> URI Class Initialized
INFO - 2023-07-29 18:50:53 --> Router Class Initialized
INFO - 2023-07-29 18:50:53 --> Output Class Initialized
INFO - 2023-07-29 18:50:53 --> Security Class Initialized
DEBUG - 2023-07-29 18:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:50:53 --> Input Class Initialized
INFO - 2023-07-29 18:50:53 --> Language Class Initialized
INFO - 2023-07-29 18:50:53 --> Language Class Initialized
INFO - 2023-07-29 18:50:53 --> Config Class Initialized
INFO - 2023-07-29 18:50:53 --> Loader Class Initialized
INFO - 2023-07-29 18:50:53 --> Helper loaded: url_helper
INFO - 2023-07-29 18:50:53 --> Helper loaded: file_helper
INFO - 2023-07-29 18:50:53 --> Helper loaded: form_helper
INFO - 2023-07-29 18:50:53 --> Helper loaded: my_helper
INFO - 2023-07-29 18:50:53 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:50:53 --> Controller Class Initialized
INFO - 2023-07-29 18:50:55 --> Config Class Initialized
INFO - 2023-07-29 18:50:55 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:50:55 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:50:55 --> Utf8 Class Initialized
INFO - 2023-07-29 18:50:55 --> URI Class Initialized
INFO - 2023-07-29 18:50:55 --> Router Class Initialized
INFO - 2023-07-29 18:50:55 --> Output Class Initialized
INFO - 2023-07-29 18:50:55 --> Security Class Initialized
DEBUG - 2023-07-29 18:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:50:55 --> Input Class Initialized
INFO - 2023-07-29 18:50:55 --> Language Class Initialized
INFO - 2023-07-29 18:50:55 --> Language Class Initialized
INFO - 2023-07-29 18:50:55 --> Config Class Initialized
INFO - 2023-07-29 18:50:55 --> Loader Class Initialized
INFO - 2023-07-29 18:50:55 --> Helper loaded: url_helper
INFO - 2023-07-29 18:50:55 --> Helper loaded: file_helper
INFO - 2023-07-29 18:50:55 --> Helper loaded: form_helper
INFO - 2023-07-29 18:50:55 --> Helper loaded: my_helper
INFO - 2023-07-29 18:50:55 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:50:55 --> Controller Class Initialized
INFO - 2023-07-29 18:50:58 --> Config Class Initialized
INFO - 2023-07-29 18:50:58 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:50:58 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:50:58 --> Utf8 Class Initialized
INFO - 2023-07-29 18:50:58 --> URI Class Initialized
INFO - 2023-07-29 18:50:58 --> Router Class Initialized
INFO - 2023-07-29 18:50:58 --> Output Class Initialized
INFO - 2023-07-29 18:50:58 --> Security Class Initialized
DEBUG - 2023-07-29 18:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:50:58 --> Input Class Initialized
INFO - 2023-07-29 18:50:58 --> Language Class Initialized
INFO - 2023-07-29 18:50:58 --> Language Class Initialized
INFO - 2023-07-29 18:50:58 --> Config Class Initialized
INFO - 2023-07-29 18:50:58 --> Loader Class Initialized
INFO - 2023-07-29 18:50:58 --> Helper loaded: url_helper
INFO - 2023-07-29 18:50:58 --> Helper loaded: file_helper
INFO - 2023-07-29 18:50:58 --> Helper loaded: form_helper
INFO - 2023-07-29 18:50:58 --> Helper loaded: my_helper
INFO - 2023-07-29 18:50:58 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:50:58 --> Controller Class Initialized
DEBUG - 2023-07-29 18:50:58 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_mapel/views/list.php
DEBUG - 2023-07-29 18:50:58 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:50:58 --> Final output sent to browser
DEBUG - 2023-07-29 18:50:58 --> Total execution time: 0.0382
INFO - 2023-07-29 18:50:58 --> Config Class Initialized
INFO - 2023-07-29 18:50:58 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:50:58 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:50:58 --> Utf8 Class Initialized
INFO - 2023-07-29 18:50:58 --> URI Class Initialized
INFO - 2023-07-29 18:50:58 --> Router Class Initialized
INFO - 2023-07-29 18:50:58 --> Output Class Initialized
INFO - 2023-07-29 18:50:58 --> Security Class Initialized
DEBUG - 2023-07-29 18:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:50:58 --> Input Class Initialized
INFO - 2023-07-29 18:50:58 --> Language Class Initialized
INFO - 2023-07-29 18:50:58 --> Language Class Initialized
INFO - 2023-07-29 18:50:58 --> Config Class Initialized
INFO - 2023-07-29 18:50:58 --> Loader Class Initialized
INFO - 2023-07-29 18:50:58 --> Helper loaded: url_helper
INFO - 2023-07-29 18:50:58 --> Helper loaded: file_helper
INFO - 2023-07-29 18:50:58 --> Helper loaded: form_helper
INFO - 2023-07-29 18:50:58 --> Helper loaded: my_helper
INFO - 2023-07-29 18:50:58 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:50:58 --> Controller Class Initialized
INFO - 2023-07-29 18:50:58 --> Config Class Initialized
INFO - 2023-07-29 18:50:58 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:50:58 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:50:58 --> Utf8 Class Initialized
INFO - 2023-07-29 18:50:58 --> URI Class Initialized
INFO - 2023-07-29 18:50:58 --> Router Class Initialized
INFO - 2023-07-29 18:50:58 --> Output Class Initialized
INFO - 2023-07-29 18:50:58 --> Security Class Initialized
DEBUG - 2023-07-29 18:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:50:58 --> Input Class Initialized
INFO - 2023-07-29 18:50:58 --> Language Class Initialized
INFO - 2023-07-29 18:50:58 --> Language Class Initialized
INFO - 2023-07-29 18:50:58 --> Config Class Initialized
INFO - 2023-07-29 18:50:58 --> Loader Class Initialized
INFO - 2023-07-29 18:50:58 --> Helper loaded: url_helper
INFO - 2023-07-29 18:50:58 --> Helper loaded: file_helper
INFO - 2023-07-29 18:50:58 --> Helper loaded: form_helper
INFO - 2023-07-29 18:50:58 --> Helper loaded: my_helper
INFO - 2023-07-29 18:50:58 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:50:58 --> Controller Class Initialized
DEBUG - 2023-07-29 18:50:58 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_ekstra/views/list.php
DEBUG - 2023-07-29 18:50:58 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:50:58 --> Final output sent to browser
DEBUG - 2023-07-29 18:50:58 --> Total execution time: 0.0852
INFO - 2023-07-29 18:50:58 --> Config Class Initialized
INFO - 2023-07-29 18:50:58 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:50:58 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:50:58 --> Utf8 Class Initialized
INFO - 2023-07-29 18:50:58 --> URI Class Initialized
INFO - 2023-07-29 18:50:58 --> Router Class Initialized
INFO - 2023-07-29 18:50:58 --> Output Class Initialized
INFO - 2023-07-29 18:50:58 --> Security Class Initialized
DEBUG - 2023-07-29 18:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:50:58 --> Input Class Initialized
INFO - 2023-07-29 18:50:58 --> Language Class Initialized
INFO - 2023-07-29 18:50:58 --> Language Class Initialized
INFO - 2023-07-29 18:50:58 --> Config Class Initialized
INFO - 2023-07-29 18:50:58 --> Loader Class Initialized
INFO - 2023-07-29 18:50:58 --> Helper loaded: url_helper
INFO - 2023-07-29 18:50:58 --> Helper loaded: file_helper
INFO - 2023-07-29 18:50:58 --> Helper loaded: form_helper
INFO - 2023-07-29 18:50:58 --> Helper loaded: my_helper
INFO - 2023-07-29 18:50:58 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:50:58 --> Controller Class Initialized
INFO - 2023-07-29 18:51:00 --> Config Class Initialized
INFO - 2023-07-29 18:51:00 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:51:00 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:51:00 --> Utf8 Class Initialized
INFO - 2023-07-29 18:51:00 --> URI Class Initialized
INFO - 2023-07-29 18:51:00 --> Router Class Initialized
INFO - 2023-07-29 18:51:00 --> Output Class Initialized
INFO - 2023-07-29 18:51:00 --> Security Class Initialized
DEBUG - 2023-07-29 18:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:51:00 --> Input Class Initialized
INFO - 2023-07-29 18:51:00 --> Language Class Initialized
INFO - 2023-07-29 18:51:00 --> Language Class Initialized
INFO - 2023-07-29 18:51:00 --> Config Class Initialized
INFO - 2023-07-29 18:51:00 --> Loader Class Initialized
INFO - 2023-07-29 18:51:00 --> Helper loaded: url_helper
INFO - 2023-07-29 18:51:00 --> Helper loaded: file_helper
INFO - 2023-07-29 18:51:00 --> Helper loaded: form_helper
INFO - 2023-07-29 18:51:00 --> Helper loaded: my_helper
INFO - 2023-07-29 18:51:00 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:51:00 --> Controller Class Initialized
DEBUG - 2023-07-29 18:51:00 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/backup_db/views/list.php
DEBUG - 2023-07-29 18:51:00 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:51:00 --> Final output sent to browser
DEBUG - 2023-07-29 18:51:00 --> Total execution time: 0.0401
INFO - 2023-07-29 18:51:00 --> Config Class Initialized
INFO - 2023-07-29 18:51:00 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:51:00 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:51:00 --> Utf8 Class Initialized
INFO - 2023-07-29 18:51:00 --> URI Class Initialized
INFO - 2023-07-29 18:51:00 --> Router Class Initialized
INFO - 2023-07-29 18:51:00 --> Output Class Initialized
INFO - 2023-07-29 18:51:00 --> Security Class Initialized
DEBUG - 2023-07-29 18:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:51:00 --> Input Class Initialized
INFO - 2023-07-29 18:51:00 --> Language Class Initialized
INFO - 2023-07-29 18:51:00 --> Language Class Initialized
INFO - 2023-07-29 18:51:00 --> Config Class Initialized
INFO - 2023-07-29 18:51:00 --> Loader Class Initialized
INFO - 2023-07-29 18:51:00 --> Helper loaded: url_helper
INFO - 2023-07-29 18:51:00 --> Helper loaded: file_helper
INFO - 2023-07-29 18:51:00 --> Helper loaded: form_helper
INFO - 2023-07-29 18:51:00 --> Helper loaded: my_helper
INFO - 2023-07-29 18:51:00 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:51:00 --> Controller Class Initialized
INFO - 2023-07-29 18:51:11 --> Config Class Initialized
INFO - 2023-07-29 18:51:11 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:51:11 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:51:11 --> Utf8 Class Initialized
INFO - 2023-07-29 18:51:11 --> URI Class Initialized
INFO - 2023-07-29 18:51:11 --> Router Class Initialized
INFO - 2023-07-29 18:51:11 --> Output Class Initialized
INFO - 2023-07-29 18:51:11 --> Security Class Initialized
DEBUG - 2023-07-29 18:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:51:11 --> Input Class Initialized
INFO - 2023-07-29 18:51:11 --> Language Class Initialized
INFO - 2023-07-29 18:51:11 --> Language Class Initialized
INFO - 2023-07-29 18:51:11 --> Config Class Initialized
INFO - 2023-07-29 18:51:11 --> Loader Class Initialized
INFO - 2023-07-29 18:51:11 --> Helper loaded: url_helper
INFO - 2023-07-29 18:51:11 --> Helper loaded: file_helper
INFO - 2023-07-29 18:51:11 --> Helper loaded: form_helper
INFO - 2023-07-29 18:51:11 --> Helper loaded: my_helper
INFO - 2023-07-29 18:51:11 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:51:11 --> Controller Class Initialized
DEBUG - 2023-07-29 18:51:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/tahun/views/list.php
DEBUG - 2023-07-29 18:51:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:51:11 --> Final output sent to browser
DEBUG - 2023-07-29 18:51:11 --> Total execution time: 0.0566
INFO - 2023-07-29 18:51:11 --> Config Class Initialized
INFO - 2023-07-29 18:51:11 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:51:11 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:51:11 --> Utf8 Class Initialized
INFO - 2023-07-29 18:51:11 --> URI Class Initialized
INFO - 2023-07-29 18:51:11 --> Router Class Initialized
INFO - 2023-07-29 18:51:11 --> Output Class Initialized
INFO - 2023-07-29 18:51:11 --> Security Class Initialized
DEBUG - 2023-07-29 18:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:51:11 --> Input Class Initialized
INFO - 2023-07-29 18:51:11 --> Language Class Initialized
INFO - 2023-07-29 18:51:11 --> Language Class Initialized
INFO - 2023-07-29 18:51:11 --> Config Class Initialized
INFO - 2023-07-29 18:51:11 --> Loader Class Initialized
INFO - 2023-07-29 18:51:11 --> Helper loaded: url_helper
INFO - 2023-07-29 18:51:11 --> Helper loaded: file_helper
INFO - 2023-07-29 18:51:11 --> Helper loaded: form_helper
INFO - 2023-07-29 18:51:11 --> Helper loaded: my_helper
INFO - 2023-07-29 18:51:11 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:51:11 --> Controller Class Initialized
INFO - 2023-07-29 18:51:11 --> Config Class Initialized
INFO - 2023-07-29 18:51:11 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:51:11 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:51:11 --> Utf8 Class Initialized
INFO - 2023-07-29 18:51:11 --> URI Class Initialized
INFO - 2023-07-29 18:51:11 --> Router Class Initialized
INFO - 2023-07-29 18:51:11 --> Output Class Initialized
INFO - 2023-07-29 18:51:11 --> Security Class Initialized
DEBUG - 2023-07-29 18:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:51:11 --> Input Class Initialized
INFO - 2023-07-29 18:51:11 --> Language Class Initialized
INFO - 2023-07-29 18:51:11 --> Language Class Initialized
INFO - 2023-07-29 18:51:11 --> Config Class Initialized
INFO - 2023-07-29 18:51:11 --> Loader Class Initialized
INFO - 2023-07-29 18:51:11 --> Helper loaded: url_helper
INFO - 2023-07-29 18:51:11 --> Helper loaded: file_helper
INFO - 2023-07-29 18:51:11 --> Helper loaded: form_helper
INFO - 2023-07-29 18:51:11 --> Helper loaded: my_helper
INFO - 2023-07-29 18:51:11 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:51:11 --> Controller Class Initialized
DEBUG - 2023-07-29 18:51:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/backup_db/views/list.php
DEBUG - 2023-07-29 18:51:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:51:11 --> Final output sent to browser
DEBUG - 2023-07-29 18:51:11 --> Total execution time: 0.0367
INFO - 2023-07-29 18:51:12 --> Config Class Initialized
INFO - 2023-07-29 18:51:12 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:51:12 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:51:12 --> Utf8 Class Initialized
INFO - 2023-07-29 18:51:12 --> URI Class Initialized
INFO - 2023-07-29 18:51:12 --> Router Class Initialized
INFO - 2023-07-29 18:51:12 --> Output Class Initialized
INFO - 2023-07-29 18:51:12 --> Security Class Initialized
DEBUG - 2023-07-29 18:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:51:12 --> Input Class Initialized
INFO - 2023-07-29 18:51:12 --> Language Class Initialized
INFO - 2023-07-29 18:51:12 --> Language Class Initialized
INFO - 2023-07-29 18:51:12 --> Config Class Initialized
INFO - 2023-07-29 18:51:12 --> Loader Class Initialized
INFO - 2023-07-29 18:51:12 --> Helper loaded: url_helper
INFO - 2023-07-29 18:51:12 --> Helper loaded: file_helper
INFO - 2023-07-29 18:51:12 --> Helper loaded: form_helper
INFO - 2023-07-29 18:51:12 --> Helper loaded: my_helper
INFO - 2023-07-29 18:51:12 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:51:12 --> Controller Class Initialized
INFO - 2023-07-29 18:51:12 --> Config Class Initialized
INFO - 2023-07-29 18:51:12 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:51:12 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:51:12 --> Utf8 Class Initialized
INFO - 2023-07-29 18:51:12 --> URI Class Initialized
INFO - 2023-07-29 18:51:12 --> Router Class Initialized
INFO - 2023-07-29 18:51:12 --> Output Class Initialized
INFO - 2023-07-29 18:51:12 --> Security Class Initialized
DEBUG - 2023-07-29 18:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:51:12 --> Input Class Initialized
INFO - 2023-07-29 18:51:12 --> Language Class Initialized
INFO - 2023-07-29 18:51:12 --> Language Class Initialized
INFO - 2023-07-29 18:51:12 --> Config Class Initialized
INFO - 2023-07-29 18:51:12 --> Loader Class Initialized
INFO - 2023-07-29 18:51:12 --> Helper loaded: url_helper
INFO - 2023-07-29 18:51:12 --> Helper loaded: file_helper
INFO - 2023-07-29 18:51:12 --> Helper loaded: form_helper
INFO - 2023-07-29 18:51:12 --> Helper loaded: my_helper
INFO - 2023-07-29 18:51:12 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:51:12 --> Controller Class Initialized
DEBUG - 2023-07-29 18:51:12 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_ekstra/views/list.php
DEBUG - 2023-07-29 18:51:12 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:51:12 --> Final output sent to browser
DEBUG - 2023-07-29 18:51:12 --> Total execution time: 0.0372
INFO - 2023-07-29 18:51:12 --> Config Class Initialized
INFO - 2023-07-29 18:51:12 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:51:12 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:51:12 --> Utf8 Class Initialized
INFO - 2023-07-29 18:51:12 --> URI Class Initialized
INFO - 2023-07-29 18:51:12 --> Router Class Initialized
INFO - 2023-07-29 18:51:12 --> Output Class Initialized
INFO - 2023-07-29 18:51:12 --> Security Class Initialized
DEBUG - 2023-07-29 18:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:51:12 --> Input Class Initialized
INFO - 2023-07-29 18:51:12 --> Language Class Initialized
INFO - 2023-07-29 18:51:12 --> Language Class Initialized
INFO - 2023-07-29 18:51:12 --> Config Class Initialized
INFO - 2023-07-29 18:51:12 --> Loader Class Initialized
INFO - 2023-07-29 18:51:12 --> Helper loaded: url_helper
INFO - 2023-07-29 18:51:12 --> Helper loaded: file_helper
INFO - 2023-07-29 18:51:12 --> Helper loaded: form_helper
INFO - 2023-07-29 18:51:12 --> Helper loaded: my_helper
INFO - 2023-07-29 18:51:12 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:51:12 --> Controller Class Initialized
INFO - 2023-07-29 18:51:17 --> Config Class Initialized
INFO - 2023-07-29 18:51:17 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:51:17 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:51:17 --> Utf8 Class Initialized
INFO - 2023-07-29 18:51:17 --> URI Class Initialized
DEBUG - 2023-07-29 18:51:17 --> No URI present. Default controller set.
INFO - 2023-07-29 18:51:17 --> Router Class Initialized
INFO - 2023-07-29 18:51:17 --> Output Class Initialized
INFO - 2023-07-29 18:51:17 --> Security Class Initialized
DEBUG - 2023-07-29 18:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:51:17 --> Input Class Initialized
INFO - 2023-07-29 18:51:17 --> Language Class Initialized
INFO - 2023-07-29 18:51:17 --> Language Class Initialized
INFO - 2023-07-29 18:51:17 --> Config Class Initialized
INFO - 2023-07-29 18:51:17 --> Loader Class Initialized
INFO - 2023-07-29 18:51:17 --> Helper loaded: url_helper
INFO - 2023-07-29 18:51:17 --> Helper loaded: file_helper
INFO - 2023-07-29 18:51:17 --> Helper loaded: form_helper
INFO - 2023-07-29 18:51:17 --> Helper loaded: my_helper
INFO - 2023-07-29 18:51:17 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:51:17 --> Controller Class Initialized
DEBUG - 2023-07-29 18:51:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:51:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:51:17 --> Final output sent to browser
DEBUG - 2023-07-29 18:51:17 --> Total execution time: 0.0533
INFO - 2023-07-29 18:53:00 --> Config Class Initialized
INFO - 2023-07-29 18:53:00 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:53:00 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:53:00 --> Utf8 Class Initialized
INFO - 2023-07-29 18:53:00 --> URI Class Initialized
INFO - 2023-07-29 18:53:00 --> Router Class Initialized
INFO - 2023-07-29 18:53:00 --> Output Class Initialized
INFO - 2023-07-29 18:53:00 --> Security Class Initialized
DEBUG - 2023-07-29 18:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:53:00 --> Input Class Initialized
INFO - 2023-07-29 18:53:00 --> Language Class Initialized
INFO - 2023-07-29 18:53:00 --> Language Class Initialized
INFO - 2023-07-29 18:53:00 --> Config Class Initialized
INFO - 2023-07-29 18:53:00 --> Loader Class Initialized
INFO - 2023-07-29 18:53:00 --> Helper loaded: url_helper
INFO - 2023-07-29 18:53:00 --> Helper loaded: file_helper
INFO - 2023-07-29 18:53:00 --> Helper loaded: form_helper
INFO - 2023-07-29 18:53:00 --> Helper loaded: my_helper
INFO - 2023-07-29 18:53:00 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:53:00 --> Controller Class Initialized
DEBUG - 2023-07-29 18:53:00 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_guru/views/list.php
DEBUG - 2023-07-29 18:53:00 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:53:00 --> Final output sent to browser
DEBUG - 2023-07-29 18:53:00 --> Total execution time: 0.0415
INFO - 2023-07-29 18:53:00 --> Config Class Initialized
INFO - 2023-07-29 18:53:00 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:53:00 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:53:00 --> Utf8 Class Initialized
INFO - 2023-07-29 18:53:00 --> URI Class Initialized
INFO - 2023-07-29 18:53:00 --> Router Class Initialized
INFO - 2023-07-29 18:53:00 --> Output Class Initialized
INFO - 2023-07-29 18:53:00 --> Security Class Initialized
DEBUG - 2023-07-29 18:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:53:00 --> Input Class Initialized
INFO - 2023-07-29 18:53:00 --> Language Class Initialized
INFO - 2023-07-29 18:53:00 --> Language Class Initialized
INFO - 2023-07-29 18:53:00 --> Config Class Initialized
INFO - 2023-07-29 18:53:00 --> Loader Class Initialized
INFO - 2023-07-29 18:53:00 --> Helper loaded: url_helper
INFO - 2023-07-29 18:53:00 --> Helper loaded: file_helper
INFO - 2023-07-29 18:53:00 --> Helper loaded: form_helper
INFO - 2023-07-29 18:53:00 --> Helper loaded: my_helper
INFO - 2023-07-29 18:53:00 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:53:00 --> Controller Class Initialized
INFO - 2023-07-29 18:53:00 --> Config Class Initialized
INFO - 2023-07-29 18:53:00 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:53:00 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:53:00 --> Utf8 Class Initialized
INFO - 2023-07-29 18:53:00 --> URI Class Initialized
DEBUG - 2023-07-29 18:53:00 --> No URI present. Default controller set.
INFO - 2023-07-29 18:53:00 --> Router Class Initialized
INFO - 2023-07-29 18:53:00 --> Output Class Initialized
INFO - 2023-07-29 18:53:00 --> Security Class Initialized
DEBUG - 2023-07-29 18:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:53:00 --> Input Class Initialized
INFO - 2023-07-29 18:53:00 --> Language Class Initialized
INFO - 2023-07-29 18:53:00 --> Language Class Initialized
INFO - 2023-07-29 18:53:00 --> Config Class Initialized
INFO - 2023-07-29 18:53:00 --> Loader Class Initialized
INFO - 2023-07-29 18:53:00 --> Helper loaded: url_helper
INFO - 2023-07-29 18:53:00 --> Helper loaded: file_helper
INFO - 2023-07-29 18:53:00 --> Helper loaded: form_helper
INFO - 2023-07-29 18:53:00 --> Helper loaded: my_helper
INFO - 2023-07-29 18:53:00 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:53:00 --> Controller Class Initialized
DEBUG - 2023-07-29 18:53:00 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:53:00 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:53:00 --> Final output sent to browser
DEBUG - 2023-07-29 18:53:00 --> Total execution time: 0.0627
INFO - 2023-07-29 18:53:03 --> Config Class Initialized
INFO - 2023-07-29 18:53:03 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:53:03 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:53:03 --> Utf8 Class Initialized
INFO - 2023-07-29 18:53:03 --> URI Class Initialized
INFO - 2023-07-29 18:53:03 --> Router Class Initialized
INFO - 2023-07-29 18:53:03 --> Output Class Initialized
INFO - 2023-07-29 18:53:03 --> Security Class Initialized
DEBUG - 2023-07-29 18:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:53:03 --> Input Class Initialized
INFO - 2023-07-29 18:53:03 --> Language Class Initialized
INFO - 2023-07-29 18:53:03 --> Language Class Initialized
INFO - 2023-07-29 18:53:03 --> Config Class Initialized
INFO - 2023-07-29 18:53:03 --> Loader Class Initialized
INFO - 2023-07-29 18:53:03 --> Helper loaded: url_helper
INFO - 2023-07-29 18:53:03 --> Helper loaded: file_helper
INFO - 2023-07-29 18:53:03 --> Helper loaded: form_helper
INFO - 2023-07-29 18:53:03 --> Helper loaded: my_helper
INFO - 2023-07-29 18:53:03 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:53:03 --> Controller Class Initialized
DEBUG - 2023-07-29 18:53:03 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_guru/views/list.php
DEBUG - 2023-07-29 18:53:03 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:53:03 --> Final output sent to browser
DEBUG - 2023-07-29 18:53:03 --> Total execution time: 0.0607
INFO - 2023-07-29 18:53:03 --> Config Class Initialized
INFO - 2023-07-29 18:53:03 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:53:03 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:53:03 --> Utf8 Class Initialized
INFO - 2023-07-29 18:53:03 --> URI Class Initialized
INFO - 2023-07-29 18:53:03 --> Router Class Initialized
INFO - 2023-07-29 18:53:03 --> Output Class Initialized
INFO - 2023-07-29 18:53:03 --> Security Class Initialized
DEBUG - 2023-07-29 18:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:53:03 --> Input Class Initialized
INFO - 2023-07-29 18:53:03 --> Language Class Initialized
INFO - 2023-07-29 18:53:03 --> Language Class Initialized
INFO - 2023-07-29 18:53:03 --> Config Class Initialized
INFO - 2023-07-29 18:53:03 --> Loader Class Initialized
INFO - 2023-07-29 18:53:03 --> Helper loaded: url_helper
INFO - 2023-07-29 18:53:03 --> Helper loaded: file_helper
INFO - 2023-07-29 18:53:03 --> Helper loaded: form_helper
INFO - 2023-07-29 18:53:03 --> Helper loaded: my_helper
INFO - 2023-07-29 18:53:03 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:53:03 --> Controller Class Initialized
INFO - 2023-07-29 18:53:04 --> Config Class Initialized
INFO - 2023-07-29 18:53:04 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:53:04 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:53:04 --> Utf8 Class Initialized
INFO - 2023-07-29 18:53:04 --> URI Class Initialized
INFO - 2023-07-29 18:53:04 --> Router Class Initialized
INFO - 2023-07-29 18:53:04 --> Output Class Initialized
INFO - 2023-07-29 18:53:04 --> Security Class Initialized
DEBUG - 2023-07-29 18:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:53:04 --> Input Class Initialized
INFO - 2023-07-29 18:53:04 --> Language Class Initialized
INFO - 2023-07-29 18:53:04 --> Language Class Initialized
INFO - 2023-07-29 18:53:04 --> Config Class Initialized
INFO - 2023-07-29 18:53:04 --> Loader Class Initialized
INFO - 2023-07-29 18:53:04 --> Helper loaded: url_helper
INFO - 2023-07-29 18:53:04 --> Helper loaded: file_helper
INFO - 2023-07-29 18:53:04 --> Helper loaded: form_helper
INFO - 2023-07-29 18:53:04 --> Helper loaded: my_helper
INFO - 2023-07-29 18:53:04 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:53:04 --> Controller Class Initialized
DEBUG - 2023-07-29 18:53:04 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-29 18:53:04 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:53:04 --> Final output sent to browser
DEBUG - 2023-07-29 18:53:04 --> Total execution time: 0.0544
INFO - 2023-07-29 18:53:04 --> Config Class Initialized
INFO - 2023-07-29 18:53:04 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:53:04 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:53:04 --> Utf8 Class Initialized
INFO - 2023-07-29 18:53:04 --> URI Class Initialized
INFO - 2023-07-29 18:53:04 --> Router Class Initialized
INFO - 2023-07-29 18:53:04 --> Output Class Initialized
INFO - 2023-07-29 18:53:04 --> Security Class Initialized
DEBUG - 2023-07-29 18:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:53:04 --> Input Class Initialized
INFO - 2023-07-29 18:53:04 --> Language Class Initialized
INFO - 2023-07-29 18:53:04 --> Language Class Initialized
INFO - 2023-07-29 18:53:04 --> Config Class Initialized
INFO - 2023-07-29 18:53:04 --> Loader Class Initialized
INFO - 2023-07-29 18:53:04 --> Helper loaded: url_helper
INFO - 2023-07-29 18:53:04 --> Helper loaded: file_helper
INFO - 2023-07-29 18:53:04 --> Helper loaded: form_helper
INFO - 2023-07-29 18:53:04 --> Helper loaded: my_helper
INFO - 2023-07-29 18:53:04 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:53:04 --> Controller Class Initialized
INFO - 2023-07-29 18:53:04 --> Config Class Initialized
INFO - 2023-07-29 18:53:04 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:53:04 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:53:04 --> Utf8 Class Initialized
INFO - 2023-07-29 18:53:04 --> URI Class Initialized
INFO - 2023-07-29 18:53:04 --> Router Class Initialized
INFO - 2023-07-29 18:53:04 --> Output Class Initialized
INFO - 2023-07-29 18:53:04 --> Security Class Initialized
DEBUG - 2023-07-29 18:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:53:04 --> Input Class Initialized
INFO - 2023-07-29 18:53:04 --> Language Class Initialized
INFO - 2023-07-29 18:53:04 --> Language Class Initialized
INFO - 2023-07-29 18:53:04 --> Config Class Initialized
INFO - 2023-07-29 18:53:04 --> Loader Class Initialized
INFO - 2023-07-29 18:53:04 --> Helper loaded: url_helper
INFO - 2023-07-29 18:53:04 --> Helper loaded: file_helper
INFO - 2023-07-29 18:53:04 --> Helper loaded: form_helper
INFO - 2023-07-29 18:53:04 --> Helper loaded: my_helper
INFO - 2023-07-29 18:53:04 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:53:04 --> Controller Class Initialized
DEBUG - 2023-07-29 18:53:04 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_kelas/views/list.php
DEBUG - 2023-07-29 18:53:04 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:53:04 --> Final output sent to browser
DEBUG - 2023-07-29 18:53:04 --> Total execution time: 0.0465
INFO - 2023-07-29 18:53:05 --> Config Class Initialized
INFO - 2023-07-29 18:53:05 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:53:05 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:53:05 --> Utf8 Class Initialized
INFO - 2023-07-29 18:53:05 --> URI Class Initialized
INFO - 2023-07-29 18:53:05 --> Router Class Initialized
INFO - 2023-07-29 18:53:05 --> Output Class Initialized
INFO - 2023-07-29 18:53:05 --> Security Class Initialized
DEBUG - 2023-07-29 18:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:53:05 --> Input Class Initialized
INFO - 2023-07-29 18:53:05 --> Language Class Initialized
INFO - 2023-07-29 18:53:05 --> Language Class Initialized
INFO - 2023-07-29 18:53:05 --> Config Class Initialized
INFO - 2023-07-29 18:53:05 --> Loader Class Initialized
INFO - 2023-07-29 18:53:05 --> Helper loaded: url_helper
INFO - 2023-07-29 18:53:05 --> Helper loaded: file_helper
INFO - 2023-07-29 18:53:05 --> Helper loaded: form_helper
INFO - 2023-07-29 18:53:05 --> Helper loaded: my_helper
INFO - 2023-07-29 18:53:05 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:53:05 --> Controller Class Initialized
INFO - 2023-07-29 18:53:05 --> Config Class Initialized
INFO - 2023-07-29 18:53:05 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:53:05 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:53:05 --> Utf8 Class Initialized
INFO - 2023-07-29 18:53:05 --> URI Class Initialized
INFO - 2023-07-29 18:53:05 --> Router Class Initialized
INFO - 2023-07-29 18:53:05 --> Output Class Initialized
INFO - 2023-07-29 18:53:05 --> Security Class Initialized
DEBUG - 2023-07-29 18:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:53:05 --> Input Class Initialized
INFO - 2023-07-29 18:53:05 --> Language Class Initialized
INFO - 2023-07-29 18:53:05 --> Language Class Initialized
INFO - 2023-07-29 18:53:05 --> Config Class Initialized
INFO - 2023-07-29 18:53:05 --> Loader Class Initialized
INFO - 2023-07-29 18:53:05 --> Helper loaded: url_helper
INFO - 2023-07-29 18:53:05 --> Helper loaded: file_helper
INFO - 2023-07-29 18:53:05 --> Helper loaded: form_helper
INFO - 2023-07-29 18:53:05 --> Helper loaded: my_helper
INFO - 2023-07-29 18:53:05 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:53:05 --> Controller Class Initialized
DEBUG - 2023-07-29 18:53:05 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_mapel/views/list.php
DEBUG - 2023-07-29 18:53:05 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:53:05 --> Final output sent to browser
DEBUG - 2023-07-29 18:53:05 --> Total execution time: 0.0473
INFO - 2023-07-29 18:53:05 --> Config Class Initialized
INFO - 2023-07-29 18:53:05 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:53:05 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:53:05 --> Utf8 Class Initialized
INFO - 2023-07-29 18:53:05 --> URI Class Initialized
INFO - 2023-07-29 18:53:05 --> Router Class Initialized
INFO - 2023-07-29 18:53:05 --> Output Class Initialized
INFO - 2023-07-29 18:53:05 --> Security Class Initialized
DEBUG - 2023-07-29 18:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:53:05 --> Input Class Initialized
INFO - 2023-07-29 18:53:05 --> Language Class Initialized
INFO - 2023-07-29 18:53:05 --> Language Class Initialized
INFO - 2023-07-29 18:53:05 --> Config Class Initialized
INFO - 2023-07-29 18:53:05 --> Loader Class Initialized
INFO - 2023-07-29 18:53:05 --> Helper loaded: url_helper
INFO - 2023-07-29 18:53:05 --> Helper loaded: file_helper
INFO - 2023-07-29 18:53:05 --> Helper loaded: form_helper
INFO - 2023-07-29 18:53:05 --> Helper loaded: my_helper
INFO - 2023-07-29 18:53:05 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:53:05 --> Controller Class Initialized
INFO - 2023-07-29 18:53:06 --> Config Class Initialized
INFO - 2023-07-29 18:53:06 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:53:06 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:53:06 --> Utf8 Class Initialized
INFO - 2023-07-29 18:53:06 --> URI Class Initialized
INFO - 2023-07-29 18:53:06 --> Router Class Initialized
INFO - 2023-07-29 18:53:06 --> Output Class Initialized
INFO - 2023-07-29 18:53:06 --> Security Class Initialized
DEBUG - 2023-07-29 18:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:53:06 --> Input Class Initialized
INFO - 2023-07-29 18:53:06 --> Language Class Initialized
INFO - 2023-07-29 18:53:06 --> Language Class Initialized
INFO - 2023-07-29 18:53:06 --> Config Class Initialized
INFO - 2023-07-29 18:53:06 --> Loader Class Initialized
INFO - 2023-07-29 18:53:06 --> Helper loaded: url_helper
INFO - 2023-07-29 18:53:06 --> Helper loaded: file_helper
INFO - 2023-07-29 18:53:06 --> Helper loaded: form_helper
INFO - 2023-07-29 18:53:06 --> Helper loaded: my_helper
INFO - 2023-07-29 18:53:06 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:53:06 --> Controller Class Initialized
DEBUG - 2023-07-29 18:53:06 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_ekstra/views/list.php
DEBUG - 2023-07-29 18:53:06 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:53:06 --> Final output sent to browser
DEBUG - 2023-07-29 18:53:06 --> Total execution time: 0.0405
INFO - 2023-07-29 18:53:06 --> Config Class Initialized
INFO - 2023-07-29 18:53:06 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:53:06 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:53:06 --> Utf8 Class Initialized
INFO - 2023-07-29 18:53:06 --> URI Class Initialized
INFO - 2023-07-29 18:53:06 --> Router Class Initialized
INFO - 2023-07-29 18:53:06 --> Output Class Initialized
INFO - 2023-07-29 18:53:06 --> Security Class Initialized
DEBUG - 2023-07-29 18:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:53:06 --> Input Class Initialized
INFO - 2023-07-29 18:53:06 --> Language Class Initialized
INFO - 2023-07-29 18:53:06 --> Language Class Initialized
INFO - 2023-07-29 18:53:06 --> Config Class Initialized
INFO - 2023-07-29 18:53:06 --> Loader Class Initialized
INFO - 2023-07-29 18:53:06 --> Helper loaded: url_helper
INFO - 2023-07-29 18:53:06 --> Helper loaded: file_helper
INFO - 2023-07-29 18:53:06 --> Helper loaded: form_helper
INFO - 2023-07-29 18:53:06 --> Helper loaded: my_helper
INFO - 2023-07-29 18:53:06 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:53:06 --> Controller Class Initialized
INFO - 2023-07-29 18:53:07 --> Config Class Initialized
INFO - 2023-07-29 18:53:07 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:53:07 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:53:07 --> Utf8 Class Initialized
INFO - 2023-07-29 18:53:07 --> URI Class Initialized
INFO - 2023-07-29 18:53:07 --> Router Class Initialized
INFO - 2023-07-29 18:53:07 --> Output Class Initialized
INFO - 2023-07-29 18:53:07 --> Security Class Initialized
DEBUG - 2023-07-29 18:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:53:07 --> Input Class Initialized
INFO - 2023-07-29 18:53:07 --> Language Class Initialized
INFO - 2023-07-29 18:53:07 --> Language Class Initialized
INFO - 2023-07-29 18:53:07 --> Config Class Initialized
INFO - 2023-07-29 18:53:07 --> Loader Class Initialized
INFO - 2023-07-29 18:53:07 --> Helper loaded: url_helper
INFO - 2023-07-29 18:53:07 --> Helper loaded: file_helper
INFO - 2023-07-29 18:53:07 --> Helper loaded: form_helper
INFO - 2023-07-29 18:53:07 --> Helper loaded: my_helper
INFO - 2023-07-29 18:53:07 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:53:07 --> Controller Class Initialized
DEBUG - 2023-07-29 18:53:07 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_mapel/views/list.php
DEBUG - 2023-07-29 18:53:07 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:53:07 --> Final output sent to browser
DEBUG - 2023-07-29 18:53:07 --> Total execution time: 0.0591
INFO - 2023-07-29 18:53:07 --> Config Class Initialized
INFO - 2023-07-29 18:53:07 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:53:07 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:53:07 --> Utf8 Class Initialized
INFO - 2023-07-29 18:53:07 --> URI Class Initialized
INFO - 2023-07-29 18:53:07 --> Router Class Initialized
INFO - 2023-07-29 18:53:07 --> Output Class Initialized
INFO - 2023-07-29 18:53:07 --> Security Class Initialized
DEBUG - 2023-07-29 18:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:53:07 --> Input Class Initialized
INFO - 2023-07-29 18:53:07 --> Language Class Initialized
INFO - 2023-07-29 18:53:07 --> Language Class Initialized
INFO - 2023-07-29 18:53:07 --> Config Class Initialized
INFO - 2023-07-29 18:53:07 --> Loader Class Initialized
INFO - 2023-07-29 18:53:07 --> Helper loaded: url_helper
INFO - 2023-07-29 18:53:07 --> Helper loaded: file_helper
INFO - 2023-07-29 18:53:07 --> Helper loaded: form_helper
INFO - 2023-07-29 18:53:07 --> Helper loaded: my_helper
INFO - 2023-07-29 18:53:07 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:53:07 --> Controller Class Initialized
INFO - 2023-07-29 18:53:07 --> Config Class Initialized
INFO - 2023-07-29 18:53:07 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:53:07 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:53:07 --> Utf8 Class Initialized
INFO - 2023-07-29 18:53:07 --> URI Class Initialized
INFO - 2023-07-29 18:53:07 --> Router Class Initialized
INFO - 2023-07-29 18:53:07 --> Output Class Initialized
INFO - 2023-07-29 18:53:07 --> Security Class Initialized
DEBUG - 2023-07-29 18:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:53:07 --> Input Class Initialized
INFO - 2023-07-29 18:53:07 --> Language Class Initialized
INFO - 2023-07-29 18:53:07 --> Language Class Initialized
INFO - 2023-07-29 18:53:07 --> Config Class Initialized
INFO - 2023-07-29 18:53:07 --> Loader Class Initialized
INFO - 2023-07-29 18:53:07 --> Helper loaded: url_helper
INFO - 2023-07-29 18:53:07 --> Helper loaded: file_helper
INFO - 2023-07-29 18:53:07 --> Helper loaded: form_helper
INFO - 2023-07-29 18:53:07 --> Helper loaded: my_helper
INFO - 2023-07-29 18:53:07 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:53:07 --> Controller Class Initialized
DEBUG - 2023-07-29 18:53:07 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_kelas/views/list.php
DEBUG - 2023-07-29 18:53:07 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:53:07 --> Final output sent to browser
DEBUG - 2023-07-29 18:53:07 --> Total execution time: 0.0367
INFO - 2023-07-29 18:53:07 --> Config Class Initialized
INFO - 2023-07-29 18:53:07 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:53:07 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:53:07 --> Utf8 Class Initialized
INFO - 2023-07-29 18:53:07 --> URI Class Initialized
INFO - 2023-07-29 18:53:07 --> Router Class Initialized
INFO - 2023-07-29 18:53:07 --> Output Class Initialized
INFO - 2023-07-29 18:53:07 --> Security Class Initialized
DEBUG - 2023-07-29 18:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:53:07 --> Input Class Initialized
INFO - 2023-07-29 18:53:07 --> Language Class Initialized
INFO - 2023-07-29 18:53:07 --> Language Class Initialized
INFO - 2023-07-29 18:53:07 --> Config Class Initialized
INFO - 2023-07-29 18:53:07 --> Loader Class Initialized
INFO - 2023-07-29 18:53:07 --> Helper loaded: url_helper
INFO - 2023-07-29 18:53:07 --> Helper loaded: file_helper
INFO - 2023-07-29 18:53:07 --> Helper loaded: form_helper
INFO - 2023-07-29 18:53:07 --> Helper loaded: my_helper
INFO - 2023-07-29 18:53:07 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:53:07 --> Controller Class Initialized
INFO - 2023-07-29 18:53:08 --> Config Class Initialized
INFO - 2023-07-29 18:53:08 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:53:08 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:53:08 --> Utf8 Class Initialized
INFO - 2023-07-29 18:53:08 --> URI Class Initialized
INFO - 2023-07-29 18:53:08 --> Router Class Initialized
INFO - 2023-07-29 18:53:08 --> Output Class Initialized
INFO - 2023-07-29 18:53:08 --> Security Class Initialized
DEBUG - 2023-07-29 18:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:53:08 --> Input Class Initialized
INFO - 2023-07-29 18:53:08 --> Language Class Initialized
INFO - 2023-07-29 18:53:08 --> Language Class Initialized
INFO - 2023-07-29 18:53:08 --> Config Class Initialized
INFO - 2023-07-29 18:53:08 --> Loader Class Initialized
INFO - 2023-07-29 18:53:08 --> Helper loaded: url_helper
INFO - 2023-07-29 18:53:08 --> Helper loaded: file_helper
INFO - 2023-07-29 18:53:08 --> Helper loaded: form_helper
INFO - 2023-07-29 18:53:08 --> Helper loaded: my_helper
INFO - 2023-07-29 18:53:08 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:53:08 --> Controller Class Initialized
DEBUG - 2023-07-29 18:53:08 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-29 18:53:08 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:53:08 --> Final output sent to browser
DEBUG - 2023-07-29 18:53:08 --> Total execution time: 0.0398
INFO - 2023-07-29 18:53:08 --> Config Class Initialized
INFO - 2023-07-29 18:53:08 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:53:08 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:53:08 --> Utf8 Class Initialized
INFO - 2023-07-29 18:53:08 --> URI Class Initialized
INFO - 2023-07-29 18:53:08 --> Router Class Initialized
INFO - 2023-07-29 18:53:08 --> Output Class Initialized
INFO - 2023-07-29 18:53:08 --> Security Class Initialized
DEBUG - 2023-07-29 18:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:53:08 --> Input Class Initialized
INFO - 2023-07-29 18:53:08 --> Language Class Initialized
INFO - 2023-07-29 18:53:08 --> Language Class Initialized
INFO - 2023-07-29 18:53:08 --> Config Class Initialized
INFO - 2023-07-29 18:53:08 --> Loader Class Initialized
INFO - 2023-07-29 18:53:08 --> Helper loaded: url_helper
INFO - 2023-07-29 18:53:08 --> Helper loaded: file_helper
INFO - 2023-07-29 18:53:08 --> Helper loaded: form_helper
INFO - 2023-07-29 18:53:08 --> Helper loaded: my_helper
INFO - 2023-07-29 18:53:08 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:53:08 --> Controller Class Initialized
INFO - 2023-07-29 18:53:08 --> Config Class Initialized
INFO - 2023-07-29 18:53:08 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:53:08 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:53:08 --> Utf8 Class Initialized
INFO - 2023-07-29 18:53:08 --> URI Class Initialized
INFO - 2023-07-29 18:53:08 --> Router Class Initialized
INFO - 2023-07-29 18:53:08 --> Output Class Initialized
INFO - 2023-07-29 18:53:08 --> Security Class Initialized
DEBUG - 2023-07-29 18:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:53:08 --> Input Class Initialized
INFO - 2023-07-29 18:53:08 --> Language Class Initialized
INFO - 2023-07-29 18:53:08 --> Language Class Initialized
INFO - 2023-07-29 18:53:08 --> Config Class Initialized
INFO - 2023-07-29 18:53:08 --> Loader Class Initialized
INFO - 2023-07-29 18:53:08 --> Helper loaded: url_helper
INFO - 2023-07-29 18:53:08 --> Helper loaded: file_helper
INFO - 2023-07-29 18:53:08 --> Helper loaded: form_helper
INFO - 2023-07-29 18:53:08 --> Helper loaded: my_helper
INFO - 2023-07-29 18:53:08 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:53:08 --> Controller Class Initialized
DEBUG - 2023-07-29 18:53:08 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_guru/views/list.php
DEBUG - 2023-07-29 18:53:08 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:53:08 --> Final output sent to browser
DEBUG - 2023-07-29 18:53:08 --> Total execution time: 0.0596
INFO - 2023-07-29 18:53:08 --> Config Class Initialized
INFO - 2023-07-29 18:53:08 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:53:08 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:53:08 --> Utf8 Class Initialized
INFO - 2023-07-29 18:53:08 --> URI Class Initialized
INFO - 2023-07-29 18:53:08 --> Router Class Initialized
INFO - 2023-07-29 18:53:08 --> Output Class Initialized
INFO - 2023-07-29 18:53:08 --> Security Class Initialized
DEBUG - 2023-07-29 18:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:53:08 --> Input Class Initialized
INFO - 2023-07-29 18:53:08 --> Language Class Initialized
INFO - 2023-07-29 18:53:08 --> Language Class Initialized
INFO - 2023-07-29 18:53:08 --> Config Class Initialized
INFO - 2023-07-29 18:53:08 --> Loader Class Initialized
INFO - 2023-07-29 18:53:08 --> Helper loaded: url_helper
INFO - 2023-07-29 18:53:08 --> Helper loaded: file_helper
INFO - 2023-07-29 18:53:08 --> Helper loaded: form_helper
INFO - 2023-07-29 18:53:08 --> Helper loaded: my_helper
INFO - 2023-07-29 18:53:08 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:53:08 --> Controller Class Initialized
INFO - 2023-07-29 18:53:08 --> Config Class Initialized
INFO - 2023-07-29 18:53:08 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:53:08 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:53:08 --> Utf8 Class Initialized
INFO - 2023-07-29 18:53:08 --> URI Class Initialized
DEBUG - 2023-07-29 18:53:08 --> No URI present. Default controller set.
INFO - 2023-07-29 18:53:08 --> Router Class Initialized
INFO - 2023-07-29 18:53:08 --> Output Class Initialized
INFO - 2023-07-29 18:53:08 --> Security Class Initialized
DEBUG - 2023-07-29 18:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:53:08 --> Input Class Initialized
INFO - 2023-07-29 18:53:08 --> Language Class Initialized
INFO - 2023-07-29 18:53:08 --> Language Class Initialized
INFO - 2023-07-29 18:53:08 --> Config Class Initialized
INFO - 2023-07-29 18:53:08 --> Loader Class Initialized
INFO - 2023-07-29 18:53:08 --> Helper loaded: url_helper
INFO - 2023-07-29 18:53:08 --> Helper loaded: file_helper
INFO - 2023-07-29 18:53:08 --> Helper loaded: form_helper
INFO - 2023-07-29 18:53:08 --> Helper loaded: my_helper
INFO - 2023-07-29 18:53:08 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:53:08 --> Controller Class Initialized
DEBUG - 2023-07-29 18:53:08 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:53:08 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:53:08 --> Final output sent to browser
DEBUG - 2023-07-29 18:53:08 --> Total execution time: 0.0522
INFO - 2023-07-29 18:56:58 --> Config Class Initialized
INFO - 2023-07-29 18:56:58 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:56:58 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:56:58 --> Utf8 Class Initialized
INFO - 2023-07-29 18:56:58 --> URI Class Initialized
DEBUG - 2023-07-29 18:56:58 --> No URI present. Default controller set.
INFO - 2023-07-29 18:56:58 --> Router Class Initialized
INFO - 2023-07-29 18:56:58 --> Output Class Initialized
INFO - 2023-07-29 18:56:58 --> Security Class Initialized
DEBUG - 2023-07-29 18:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:56:58 --> Input Class Initialized
INFO - 2023-07-29 18:56:58 --> Language Class Initialized
INFO - 2023-07-29 18:56:58 --> Language Class Initialized
INFO - 2023-07-29 18:56:58 --> Config Class Initialized
INFO - 2023-07-29 18:56:58 --> Loader Class Initialized
INFO - 2023-07-29 18:56:58 --> Helper loaded: url_helper
INFO - 2023-07-29 18:56:58 --> Helper loaded: file_helper
INFO - 2023-07-29 18:56:58 --> Helper loaded: form_helper
INFO - 2023-07-29 18:56:58 --> Helper loaded: my_helper
INFO - 2023-07-29 18:56:58 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:56:58 --> Controller Class Initialized
DEBUG - 2023-07-29 18:56:58 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:56:58 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:56:58 --> Final output sent to browser
DEBUG - 2023-07-29 18:56:58 --> Total execution time: 0.0562
INFO - 2023-07-29 18:56:59 --> Config Class Initialized
INFO - 2023-07-29 18:56:59 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:56:59 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:56:59 --> Utf8 Class Initialized
INFO - 2023-07-29 18:56:59 --> URI Class Initialized
DEBUG - 2023-07-29 18:56:59 --> No URI present. Default controller set.
INFO - 2023-07-29 18:56:59 --> Router Class Initialized
INFO - 2023-07-29 18:56:59 --> Output Class Initialized
INFO - 2023-07-29 18:56:59 --> Security Class Initialized
DEBUG - 2023-07-29 18:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:56:59 --> Input Class Initialized
INFO - 2023-07-29 18:56:59 --> Language Class Initialized
INFO - 2023-07-29 18:56:59 --> Language Class Initialized
INFO - 2023-07-29 18:56:59 --> Config Class Initialized
INFO - 2023-07-29 18:56:59 --> Loader Class Initialized
INFO - 2023-07-29 18:56:59 --> Helper loaded: url_helper
INFO - 2023-07-29 18:56:59 --> Helper loaded: file_helper
INFO - 2023-07-29 18:56:59 --> Helper loaded: form_helper
INFO - 2023-07-29 18:56:59 --> Helper loaded: my_helper
INFO - 2023-07-29 18:56:59 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:56:59 --> Controller Class Initialized
DEBUG - 2023-07-29 18:56:59 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:56:59 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:56:59 --> Final output sent to browser
DEBUG - 2023-07-29 18:56:59 --> Total execution time: 0.0595
INFO - 2023-07-29 18:57:25 --> Config Class Initialized
INFO - 2023-07-29 18:57:25 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:57:25 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:57:25 --> Utf8 Class Initialized
INFO - 2023-07-29 18:57:25 --> URI Class Initialized
INFO - 2023-07-29 18:57:25 --> Router Class Initialized
INFO - 2023-07-29 18:57:25 --> Output Class Initialized
INFO - 2023-07-29 18:57:25 --> Security Class Initialized
DEBUG - 2023-07-29 18:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:57:25 --> Input Class Initialized
INFO - 2023-07-29 18:57:25 --> Language Class Initialized
INFO - 2023-07-29 18:57:25 --> Language Class Initialized
INFO - 2023-07-29 18:57:25 --> Config Class Initialized
INFO - 2023-07-29 18:57:25 --> Loader Class Initialized
INFO - 2023-07-29 18:57:25 --> Helper loaded: url_helper
INFO - 2023-07-29 18:57:25 --> Helper loaded: file_helper
INFO - 2023-07-29 18:57:25 --> Helper loaded: form_helper
INFO - 2023-07-29 18:57:25 --> Helper loaded: my_helper
INFO - 2023-07-29 18:57:25 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:57:25 --> Controller Class Initialized
DEBUG - 2023-07-29 18:57:25 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_guru/views/list.php
DEBUG - 2023-07-29 18:57:25 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:57:25 --> Final output sent to browser
DEBUG - 2023-07-29 18:57:25 --> Total execution time: 0.0494
INFO - 2023-07-29 18:57:25 --> Config Class Initialized
INFO - 2023-07-29 18:57:25 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:57:25 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:57:25 --> Utf8 Class Initialized
INFO - 2023-07-29 18:57:25 --> URI Class Initialized
INFO - 2023-07-29 18:57:25 --> Router Class Initialized
INFO - 2023-07-29 18:57:25 --> Output Class Initialized
INFO - 2023-07-29 18:57:25 --> Security Class Initialized
DEBUG - 2023-07-29 18:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:57:25 --> Input Class Initialized
INFO - 2023-07-29 18:57:25 --> Language Class Initialized
INFO - 2023-07-29 18:57:25 --> Language Class Initialized
INFO - 2023-07-29 18:57:25 --> Config Class Initialized
INFO - 2023-07-29 18:57:25 --> Loader Class Initialized
INFO - 2023-07-29 18:57:25 --> Helper loaded: url_helper
INFO - 2023-07-29 18:57:25 --> Helper loaded: file_helper
INFO - 2023-07-29 18:57:25 --> Helper loaded: form_helper
INFO - 2023-07-29 18:57:25 --> Helper loaded: my_helper
INFO - 2023-07-29 18:57:25 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:57:25 --> Controller Class Initialized
INFO - 2023-07-29 18:57:26 --> Config Class Initialized
INFO - 2023-07-29 18:57:26 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:57:26 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:57:26 --> Utf8 Class Initialized
INFO - 2023-07-29 18:57:26 --> URI Class Initialized
INFO - 2023-07-29 18:57:26 --> Router Class Initialized
INFO - 2023-07-29 18:57:26 --> Output Class Initialized
INFO - 2023-07-29 18:57:26 --> Security Class Initialized
DEBUG - 2023-07-29 18:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:57:26 --> Input Class Initialized
INFO - 2023-07-29 18:57:26 --> Language Class Initialized
INFO - 2023-07-29 18:57:26 --> Language Class Initialized
INFO - 2023-07-29 18:57:26 --> Config Class Initialized
INFO - 2023-07-29 18:57:26 --> Loader Class Initialized
INFO - 2023-07-29 18:57:26 --> Helper loaded: url_helper
INFO - 2023-07-29 18:57:26 --> Helper loaded: file_helper
INFO - 2023-07-29 18:57:26 --> Helper loaded: form_helper
INFO - 2023-07-29 18:57:26 --> Helper loaded: my_helper
INFO - 2023-07-29 18:57:26 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:57:26 --> Controller Class Initialized
DEBUG - 2023-07-29 18:57:26 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-29 18:57:26 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:57:26 --> Final output sent to browser
DEBUG - 2023-07-29 18:57:26 --> Total execution time: 0.0480
INFO - 2023-07-29 18:57:26 --> Config Class Initialized
INFO - 2023-07-29 18:57:26 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:57:26 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:57:26 --> Utf8 Class Initialized
INFO - 2023-07-29 18:57:26 --> URI Class Initialized
INFO - 2023-07-29 18:57:26 --> Router Class Initialized
INFO - 2023-07-29 18:57:26 --> Output Class Initialized
INFO - 2023-07-29 18:57:26 --> Security Class Initialized
DEBUG - 2023-07-29 18:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:57:26 --> Input Class Initialized
INFO - 2023-07-29 18:57:26 --> Language Class Initialized
INFO - 2023-07-29 18:57:26 --> Language Class Initialized
INFO - 2023-07-29 18:57:26 --> Config Class Initialized
INFO - 2023-07-29 18:57:26 --> Loader Class Initialized
INFO - 2023-07-29 18:57:26 --> Helper loaded: url_helper
INFO - 2023-07-29 18:57:26 --> Helper loaded: file_helper
INFO - 2023-07-29 18:57:26 --> Helper loaded: form_helper
INFO - 2023-07-29 18:57:26 --> Helper loaded: my_helper
INFO - 2023-07-29 18:57:26 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:57:26 --> Controller Class Initialized
INFO - 2023-07-29 18:57:26 --> Config Class Initialized
INFO - 2023-07-29 18:57:26 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:57:26 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:57:26 --> Utf8 Class Initialized
INFO - 2023-07-29 18:57:26 --> URI Class Initialized
INFO - 2023-07-29 18:57:26 --> Router Class Initialized
INFO - 2023-07-29 18:57:26 --> Output Class Initialized
INFO - 2023-07-29 18:57:26 --> Security Class Initialized
DEBUG - 2023-07-29 18:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:57:26 --> Input Class Initialized
INFO - 2023-07-29 18:57:26 --> Language Class Initialized
INFO - 2023-07-29 18:57:26 --> Language Class Initialized
INFO - 2023-07-29 18:57:26 --> Config Class Initialized
INFO - 2023-07-29 18:57:26 --> Loader Class Initialized
INFO - 2023-07-29 18:57:26 --> Helper loaded: url_helper
INFO - 2023-07-29 18:57:26 --> Helper loaded: file_helper
INFO - 2023-07-29 18:57:26 --> Helper loaded: form_helper
INFO - 2023-07-29 18:57:26 --> Helper loaded: my_helper
INFO - 2023-07-29 18:57:26 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:57:26 --> Controller Class Initialized
DEBUG - 2023-07-29 18:57:26 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_kelas/views/list.php
DEBUG - 2023-07-29 18:57:26 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:57:26 --> Final output sent to browser
DEBUG - 2023-07-29 18:57:26 --> Total execution time: 0.0368
INFO - 2023-07-29 18:57:26 --> Config Class Initialized
INFO - 2023-07-29 18:57:26 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:57:26 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:57:26 --> Utf8 Class Initialized
INFO - 2023-07-29 18:57:26 --> URI Class Initialized
INFO - 2023-07-29 18:57:26 --> Router Class Initialized
INFO - 2023-07-29 18:57:26 --> Output Class Initialized
INFO - 2023-07-29 18:57:26 --> Security Class Initialized
DEBUG - 2023-07-29 18:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:57:26 --> Input Class Initialized
INFO - 2023-07-29 18:57:26 --> Language Class Initialized
INFO - 2023-07-29 18:57:26 --> Language Class Initialized
INFO - 2023-07-29 18:57:26 --> Config Class Initialized
INFO - 2023-07-29 18:57:26 --> Loader Class Initialized
INFO - 2023-07-29 18:57:26 --> Helper loaded: url_helper
INFO - 2023-07-29 18:57:26 --> Helper loaded: file_helper
INFO - 2023-07-29 18:57:26 --> Helper loaded: form_helper
INFO - 2023-07-29 18:57:26 --> Helper loaded: my_helper
INFO - 2023-07-29 18:57:26 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:57:26 --> Controller Class Initialized
INFO - 2023-07-29 18:57:27 --> Config Class Initialized
INFO - 2023-07-29 18:57:27 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:57:27 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:57:27 --> Utf8 Class Initialized
INFO - 2023-07-29 18:57:27 --> URI Class Initialized
INFO - 2023-07-29 18:57:27 --> Router Class Initialized
INFO - 2023-07-29 18:57:27 --> Output Class Initialized
INFO - 2023-07-29 18:57:27 --> Security Class Initialized
DEBUG - 2023-07-29 18:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:57:27 --> Input Class Initialized
INFO - 2023-07-29 18:57:27 --> Language Class Initialized
INFO - 2023-07-29 18:57:27 --> Language Class Initialized
INFO - 2023-07-29 18:57:27 --> Config Class Initialized
INFO - 2023-07-29 18:57:27 --> Loader Class Initialized
INFO - 2023-07-29 18:57:27 --> Helper loaded: url_helper
INFO - 2023-07-29 18:57:27 --> Helper loaded: file_helper
INFO - 2023-07-29 18:57:27 --> Helper loaded: form_helper
INFO - 2023-07-29 18:57:27 --> Helper loaded: my_helper
INFO - 2023-07-29 18:57:27 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:57:27 --> Controller Class Initialized
DEBUG - 2023-07-29 18:57:27 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_mapel/views/list.php
DEBUG - 2023-07-29 18:57:27 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:57:27 --> Final output sent to browser
DEBUG - 2023-07-29 18:57:27 --> Total execution time: 0.0361
INFO - 2023-07-29 18:57:27 --> Config Class Initialized
INFO - 2023-07-29 18:57:27 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:57:27 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:57:27 --> Utf8 Class Initialized
INFO - 2023-07-29 18:57:27 --> URI Class Initialized
INFO - 2023-07-29 18:57:27 --> Router Class Initialized
INFO - 2023-07-29 18:57:27 --> Output Class Initialized
INFO - 2023-07-29 18:57:27 --> Security Class Initialized
DEBUG - 2023-07-29 18:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:57:27 --> Input Class Initialized
INFO - 2023-07-29 18:57:27 --> Language Class Initialized
INFO - 2023-07-29 18:57:27 --> Language Class Initialized
INFO - 2023-07-29 18:57:27 --> Config Class Initialized
INFO - 2023-07-29 18:57:27 --> Loader Class Initialized
INFO - 2023-07-29 18:57:27 --> Helper loaded: url_helper
INFO - 2023-07-29 18:57:27 --> Helper loaded: file_helper
INFO - 2023-07-29 18:57:27 --> Helper loaded: form_helper
INFO - 2023-07-29 18:57:27 --> Helper loaded: my_helper
INFO - 2023-07-29 18:57:27 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:57:27 --> Controller Class Initialized
INFO - 2023-07-29 18:57:28 --> Config Class Initialized
INFO - 2023-07-29 18:57:28 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:57:28 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:57:28 --> Utf8 Class Initialized
INFO - 2023-07-29 18:57:28 --> URI Class Initialized
INFO - 2023-07-29 18:57:28 --> Router Class Initialized
INFO - 2023-07-29 18:57:28 --> Output Class Initialized
INFO - 2023-07-29 18:57:28 --> Security Class Initialized
DEBUG - 2023-07-29 18:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:57:28 --> Input Class Initialized
INFO - 2023-07-29 18:57:28 --> Language Class Initialized
INFO - 2023-07-29 18:57:28 --> Language Class Initialized
INFO - 2023-07-29 18:57:28 --> Config Class Initialized
INFO - 2023-07-29 18:57:28 --> Loader Class Initialized
INFO - 2023-07-29 18:57:28 --> Helper loaded: url_helper
INFO - 2023-07-29 18:57:28 --> Helper loaded: file_helper
INFO - 2023-07-29 18:57:28 --> Helper loaded: form_helper
INFO - 2023-07-29 18:57:28 --> Helper loaded: my_helper
INFO - 2023-07-29 18:57:28 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:57:28 --> Controller Class Initialized
DEBUG - 2023-07-29 18:57:28 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_ekstra/views/list.php
DEBUG - 2023-07-29 18:57:28 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:57:28 --> Final output sent to browser
DEBUG - 2023-07-29 18:57:28 --> Total execution time: 0.0499
INFO - 2023-07-29 18:57:28 --> Config Class Initialized
INFO - 2023-07-29 18:57:28 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:57:28 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:57:28 --> Utf8 Class Initialized
INFO - 2023-07-29 18:57:28 --> URI Class Initialized
INFO - 2023-07-29 18:57:28 --> Router Class Initialized
INFO - 2023-07-29 18:57:28 --> Output Class Initialized
INFO - 2023-07-29 18:57:28 --> Security Class Initialized
DEBUG - 2023-07-29 18:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:57:28 --> Input Class Initialized
INFO - 2023-07-29 18:57:28 --> Language Class Initialized
INFO - 2023-07-29 18:57:28 --> Language Class Initialized
INFO - 2023-07-29 18:57:28 --> Config Class Initialized
INFO - 2023-07-29 18:57:28 --> Loader Class Initialized
INFO - 2023-07-29 18:57:28 --> Helper loaded: url_helper
INFO - 2023-07-29 18:57:28 --> Helper loaded: file_helper
INFO - 2023-07-29 18:57:28 --> Helper loaded: form_helper
INFO - 2023-07-29 18:57:28 --> Helper loaded: my_helper
INFO - 2023-07-29 18:57:28 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:57:28 --> Controller Class Initialized
INFO - 2023-07-29 18:57:28 --> Config Class Initialized
INFO - 2023-07-29 18:57:28 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:57:28 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:57:28 --> Utf8 Class Initialized
INFO - 2023-07-29 18:57:28 --> URI Class Initialized
INFO - 2023-07-29 18:57:28 --> Router Class Initialized
INFO - 2023-07-29 18:57:28 --> Output Class Initialized
INFO - 2023-07-29 18:57:28 --> Security Class Initialized
DEBUG - 2023-07-29 18:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:57:28 --> Input Class Initialized
INFO - 2023-07-29 18:57:28 --> Language Class Initialized
INFO - 2023-07-29 18:57:28 --> Language Class Initialized
INFO - 2023-07-29 18:57:28 --> Config Class Initialized
INFO - 2023-07-29 18:57:28 --> Loader Class Initialized
INFO - 2023-07-29 18:57:28 --> Helper loaded: url_helper
INFO - 2023-07-29 18:57:28 --> Helper loaded: file_helper
INFO - 2023-07-29 18:57:28 --> Helper loaded: form_helper
INFO - 2023-07-29 18:57:28 --> Helper loaded: my_helper
INFO - 2023-07-29 18:57:28 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:57:28 --> Controller Class Initialized
DEBUG - 2023-07-29 18:57:28 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_mapel/views/list.php
DEBUG - 2023-07-29 18:57:28 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:57:28 --> Final output sent to browser
DEBUG - 2023-07-29 18:57:28 --> Total execution time: 0.0493
INFO - 2023-07-29 18:57:28 --> Config Class Initialized
INFO - 2023-07-29 18:57:28 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:57:28 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:57:28 --> Utf8 Class Initialized
INFO - 2023-07-29 18:57:28 --> URI Class Initialized
INFO - 2023-07-29 18:57:28 --> Router Class Initialized
INFO - 2023-07-29 18:57:28 --> Output Class Initialized
INFO - 2023-07-29 18:57:28 --> Security Class Initialized
DEBUG - 2023-07-29 18:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:57:28 --> Input Class Initialized
INFO - 2023-07-29 18:57:28 --> Language Class Initialized
INFO - 2023-07-29 18:57:28 --> Language Class Initialized
INFO - 2023-07-29 18:57:28 --> Config Class Initialized
INFO - 2023-07-29 18:57:28 --> Loader Class Initialized
INFO - 2023-07-29 18:57:28 --> Helper loaded: url_helper
INFO - 2023-07-29 18:57:28 --> Helper loaded: file_helper
INFO - 2023-07-29 18:57:28 --> Helper loaded: form_helper
INFO - 2023-07-29 18:57:28 --> Helper loaded: my_helper
INFO - 2023-07-29 18:57:28 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:57:28 --> Controller Class Initialized
INFO - 2023-07-29 18:57:29 --> Config Class Initialized
INFO - 2023-07-29 18:57:29 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:57:29 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:57:29 --> Utf8 Class Initialized
INFO - 2023-07-29 18:57:29 --> URI Class Initialized
INFO - 2023-07-29 18:57:29 --> Router Class Initialized
INFO - 2023-07-29 18:57:29 --> Output Class Initialized
INFO - 2023-07-29 18:57:29 --> Security Class Initialized
DEBUG - 2023-07-29 18:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:57:29 --> Input Class Initialized
INFO - 2023-07-29 18:57:29 --> Language Class Initialized
INFO - 2023-07-29 18:57:29 --> Language Class Initialized
INFO - 2023-07-29 18:57:29 --> Config Class Initialized
INFO - 2023-07-29 18:57:29 --> Loader Class Initialized
INFO - 2023-07-29 18:57:29 --> Helper loaded: url_helper
INFO - 2023-07-29 18:57:29 --> Helper loaded: file_helper
INFO - 2023-07-29 18:57:29 --> Helper loaded: form_helper
INFO - 2023-07-29 18:57:29 --> Helper loaded: my_helper
INFO - 2023-07-29 18:57:29 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:57:29 --> Controller Class Initialized
DEBUG - 2023-07-29 18:57:29 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_kelas/views/list.php
DEBUG - 2023-07-29 18:57:29 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:57:29 --> Final output sent to browser
DEBUG - 2023-07-29 18:57:29 --> Total execution time: 0.0370
INFO - 2023-07-29 18:57:29 --> Config Class Initialized
INFO - 2023-07-29 18:57:29 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:57:29 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:57:29 --> Utf8 Class Initialized
INFO - 2023-07-29 18:57:29 --> URI Class Initialized
INFO - 2023-07-29 18:57:29 --> Router Class Initialized
INFO - 2023-07-29 18:57:29 --> Output Class Initialized
INFO - 2023-07-29 18:57:29 --> Security Class Initialized
DEBUG - 2023-07-29 18:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:57:29 --> Input Class Initialized
INFO - 2023-07-29 18:57:29 --> Language Class Initialized
INFO - 2023-07-29 18:57:29 --> Language Class Initialized
INFO - 2023-07-29 18:57:29 --> Config Class Initialized
INFO - 2023-07-29 18:57:29 --> Loader Class Initialized
INFO - 2023-07-29 18:57:29 --> Helper loaded: url_helper
INFO - 2023-07-29 18:57:29 --> Helper loaded: file_helper
INFO - 2023-07-29 18:57:29 --> Helper loaded: form_helper
INFO - 2023-07-29 18:57:29 --> Helper loaded: my_helper
INFO - 2023-07-29 18:57:29 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:57:29 --> Controller Class Initialized
INFO - 2023-07-29 18:57:29 --> Config Class Initialized
INFO - 2023-07-29 18:57:29 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:57:29 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:57:29 --> Utf8 Class Initialized
INFO - 2023-07-29 18:57:29 --> URI Class Initialized
INFO - 2023-07-29 18:57:29 --> Router Class Initialized
INFO - 2023-07-29 18:57:29 --> Output Class Initialized
INFO - 2023-07-29 18:57:29 --> Security Class Initialized
DEBUG - 2023-07-29 18:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:57:29 --> Input Class Initialized
INFO - 2023-07-29 18:57:29 --> Language Class Initialized
INFO - 2023-07-29 18:57:29 --> Language Class Initialized
INFO - 2023-07-29 18:57:29 --> Config Class Initialized
INFO - 2023-07-29 18:57:29 --> Loader Class Initialized
INFO - 2023-07-29 18:57:29 --> Helper loaded: url_helper
INFO - 2023-07-29 18:57:29 --> Helper loaded: file_helper
INFO - 2023-07-29 18:57:29 --> Helper loaded: form_helper
INFO - 2023-07-29 18:57:29 --> Helper loaded: my_helper
INFO - 2023-07-29 18:57:29 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:57:29 --> Controller Class Initialized
DEBUG - 2023-07-29 18:57:29 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-29 18:57:29 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:57:29 --> Final output sent to browser
DEBUG - 2023-07-29 18:57:29 --> Total execution time: 0.0559
INFO - 2023-07-29 18:57:29 --> Config Class Initialized
INFO - 2023-07-29 18:57:29 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:57:29 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:57:29 --> Utf8 Class Initialized
INFO - 2023-07-29 18:57:29 --> URI Class Initialized
INFO - 2023-07-29 18:57:29 --> Router Class Initialized
INFO - 2023-07-29 18:57:29 --> Output Class Initialized
INFO - 2023-07-29 18:57:29 --> Security Class Initialized
DEBUG - 2023-07-29 18:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:57:29 --> Input Class Initialized
INFO - 2023-07-29 18:57:29 --> Language Class Initialized
INFO - 2023-07-29 18:57:29 --> Language Class Initialized
INFO - 2023-07-29 18:57:29 --> Config Class Initialized
INFO - 2023-07-29 18:57:29 --> Loader Class Initialized
INFO - 2023-07-29 18:57:29 --> Helper loaded: url_helper
INFO - 2023-07-29 18:57:29 --> Helper loaded: file_helper
INFO - 2023-07-29 18:57:29 --> Helper loaded: form_helper
INFO - 2023-07-29 18:57:29 --> Helper loaded: my_helper
INFO - 2023-07-29 18:57:29 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:57:29 --> Controller Class Initialized
INFO - 2023-07-29 18:57:29 --> Config Class Initialized
INFO - 2023-07-29 18:57:29 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:57:29 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:57:29 --> Utf8 Class Initialized
INFO - 2023-07-29 18:57:29 --> URI Class Initialized
INFO - 2023-07-29 18:57:29 --> Router Class Initialized
INFO - 2023-07-29 18:57:29 --> Output Class Initialized
INFO - 2023-07-29 18:57:29 --> Security Class Initialized
DEBUG - 2023-07-29 18:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:57:29 --> Input Class Initialized
INFO - 2023-07-29 18:57:29 --> Language Class Initialized
INFO - 2023-07-29 18:57:29 --> Language Class Initialized
INFO - 2023-07-29 18:57:29 --> Config Class Initialized
INFO - 2023-07-29 18:57:29 --> Loader Class Initialized
INFO - 2023-07-29 18:57:29 --> Helper loaded: url_helper
INFO - 2023-07-29 18:57:29 --> Helper loaded: file_helper
INFO - 2023-07-29 18:57:29 --> Helper loaded: form_helper
INFO - 2023-07-29 18:57:29 --> Helper loaded: my_helper
INFO - 2023-07-29 18:57:29 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:57:29 --> Controller Class Initialized
DEBUG - 2023-07-29 18:57:29 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_guru/views/list.php
DEBUG - 2023-07-29 18:57:29 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:57:29 --> Final output sent to browser
DEBUG - 2023-07-29 18:57:29 --> Total execution time: 0.0369
INFO - 2023-07-29 18:57:30 --> Config Class Initialized
INFO - 2023-07-29 18:57:30 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:57:30 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:57:30 --> Utf8 Class Initialized
INFO - 2023-07-29 18:57:30 --> URI Class Initialized
INFO - 2023-07-29 18:57:30 --> Router Class Initialized
INFO - 2023-07-29 18:57:30 --> Output Class Initialized
INFO - 2023-07-29 18:57:30 --> Security Class Initialized
DEBUG - 2023-07-29 18:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:57:30 --> Input Class Initialized
INFO - 2023-07-29 18:57:30 --> Language Class Initialized
INFO - 2023-07-29 18:57:30 --> Language Class Initialized
INFO - 2023-07-29 18:57:30 --> Config Class Initialized
INFO - 2023-07-29 18:57:30 --> Loader Class Initialized
INFO - 2023-07-29 18:57:30 --> Helper loaded: url_helper
INFO - 2023-07-29 18:57:30 --> Helper loaded: file_helper
INFO - 2023-07-29 18:57:30 --> Helper loaded: form_helper
INFO - 2023-07-29 18:57:30 --> Helper loaded: my_helper
INFO - 2023-07-29 18:57:30 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:57:30 --> Controller Class Initialized
INFO - 2023-07-29 18:57:30 --> Config Class Initialized
INFO - 2023-07-29 18:57:30 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:57:30 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:57:30 --> Utf8 Class Initialized
INFO - 2023-07-29 18:57:30 --> URI Class Initialized
DEBUG - 2023-07-29 18:57:30 --> No URI present. Default controller set.
INFO - 2023-07-29 18:57:30 --> Router Class Initialized
INFO - 2023-07-29 18:57:30 --> Output Class Initialized
INFO - 2023-07-29 18:57:30 --> Security Class Initialized
DEBUG - 2023-07-29 18:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:57:30 --> Input Class Initialized
INFO - 2023-07-29 18:57:30 --> Language Class Initialized
INFO - 2023-07-29 18:57:30 --> Language Class Initialized
INFO - 2023-07-29 18:57:30 --> Config Class Initialized
INFO - 2023-07-29 18:57:30 --> Loader Class Initialized
INFO - 2023-07-29 18:57:30 --> Helper loaded: url_helper
INFO - 2023-07-29 18:57:30 --> Helper loaded: file_helper
INFO - 2023-07-29 18:57:30 --> Helper loaded: form_helper
INFO - 2023-07-29 18:57:30 --> Helper loaded: my_helper
INFO - 2023-07-29 18:57:30 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:57:30 --> Controller Class Initialized
DEBUG - 2023-07-29 18:57:30 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:57:30 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:57:30 --> Final output sent to browser
DEBUG - 2023-07-29 18:57:30 --> Total execution time: 0.0535
INFO - 2023-07-29 18:58:03 --> Config Class Initialized
INFO - 2023-07-29 18:58:03 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:03 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:03 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:03 --> URI Class Initialized
DEBUG - 2023-07-29 18:58:03 --> No URI present. Default controller set.
INFO - 2023-07-29 18:58:03 --> Router Class Initialized
INFO - 2023-07-29 18:58:03 --> Output Class Initialized
INFO - 2023-07-29 18:58:03 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:03 --> Input Class Initialized
INFO - 2023-07-29 18:58:03 --> Language Class Initialized
INFO - 2023-07-29 18:58:03 --> Language Class Initialized
INFO - 2023-07-29 18:58:03 --> Config Class Initialized
INFO - 2023-07-29 18:58:03 --> Loader Class Initialized
INFO - 2023-07-29 18:58:03 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:03 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:03 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:03 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:03 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:03 --> Controller Class Initialized
DEBUG - 2023-07-29 18:58:03 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:58:03 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:58:03 --> Final output sent to browser
DEBUG - 2023-07-29 18:58:03 --> Total execution time: 0.0596
INFO - 2023-07-29 18:58:08 --> Config Class Initialized
INFO - 2023-07-29 18:58:08 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:08 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:08 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:08 --> URI Class Initialized
INFO - 2023-07-29 18:58:08 --> Router Class Initialized
INFO - 2023-07-29 18:58:08 --> Output Class Initialized
INFO - 2023-07-29 18:58:08 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:08 --> Input Class Initialized
INFO - 2023-07-29 18:58:08 --> Language Class Initialized
INFO - 2023-07-29 18:58:08 --> Language Class Initialized
INFO - 2023-07-29 18:58:08 --> Config Class Initialized
INFO - 2023-07-29 18:58:08 --> Loader Class Initialized
INFO - 2023-07-29 18:58:08 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:08 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:08 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:08 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:08 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:08 --> Controller Class Initialized
DEBUG - 2023-07-29 18:58:08 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_guru/views/list.php
DEBUG - 2023-07-29 18:58:08 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:58:08 --> Final output sent to browser
DEBUG - 2023-07-29 18:58:08 --> Total execution time: 0.0379
INFO - 2023-07-29 18:58:08 --> Config Class Initialized
INFO - 2023-07-29 18:58:08 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:08 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:08 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:08 --> URI Class Initialized
INFO - 2023-07-29 18:58:08 --> Router Class Initialized
INFO - 2023-07-29 18:58:08 --> Output Class Initialized
INFO - 2023-07-29 18:58:08 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:08 --> Input Class Initialized
INFO - 2023-07-29 18:58:08 --> Language Class Initialized
INFO - 2023-07-29 18:58:08 --> Language Class Initialized
INFO - 2023-07-29 18:58:08 --> Config Class Initialized
INFO - 2023-07-29 18:58:08 --> Loader Class Initialized
INFO - 2023-07-29 18:58:08 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:08 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:08 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:08 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:08 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:08 --> Controller Class Initialized
INFO - 2023-07-29 18:58:09 --> Config Class Initialized
INFO - 2023-07-29 18:58:09 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:09 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:09 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:09 --> URI Class Initialized
INFO - 2023-07-29 18:58:09 --> Router Class Initialized
INFO - 2023-07-29 18:58:09 --> Output Class Initialized
INFO - 2023-07-29 18:58:09 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:09 --> Input Class Initialized
INFO - 2023-07-29 18:58:09 --> Language Class Initialized
INFO - 2023-07-29 18:58:09 --> Language Class Initialized
INFO - 2023-07-29 18:58:09 --> Config Class Initialized
INFO - 2023-07-29 18:58:09 --> Loader Class Initialized
INFO - 2023-07-29 18:58:09 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:09 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:09 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:09 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:09 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:09 --> Controller Class Initialized
DEBUG - 2023-07-29 18:58:09 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-29 18:58:09 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:58:09 --> Final output sent to browser
DEBUG - 2023-07-29 18:58:09 --> Total execution time: 0.0373
INFO - 2023-07-29 18:58:09 --> Config Class Initialized
INFO - 2023-07-29 18:58:09 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:09 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:09 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:09 --> URI Class Initialized
INFO - 2023-07-29 18:58:09 --> Router Class Initialized
INFO - 2023-07-29 18:58:09 --> Output Class Initialized
INFO - 2023-07-29 18:58:09 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:09 --> Input Class Initialized
INFO - 2023-07-29 18:58:09 --> Language Class Initialized
INFO - 2023-07-29 18:58:09 --> Language Class Initialized
INFO - 2023-07-29 18:58:09 --> Config Class Initialized
INFO - 2023-07-29 18:58:09 --> Loader Class Initialized
INFO - 2023-07-29 18:58:09 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:09 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:09 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:09 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:09 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:09 --> Controller Class Initialized
INFO - 2023-07-29 18:58:09 --> Config Class Initialized
INFO - 2023-07-29 18:58:09 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:09 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:09 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:09 --> URI Class Initialized
INFO - 2023-07-29 18:58:09 --> Router Class Initialized
INFO - 2023-07-29 18:58:09 --> Output Class Initialized
INFO - 2023-07-29 18:58:09 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:09 --> Input Class Initialized
INFO - 2023-07-29 18:58:09 --> Language Class Initialized
INFO - 2023-07-29 18:58:09 --> Language Class Initialized
INFO - 2023-07-29 18:58:09 --> Config Class Initialized
INFO - 2023-07-29 18:58:09 --> Loader Class Initialized
INFO - 2023-07-29 18:58:09 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:09 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:09 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:09 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:09 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:09 --> Controller Class Initialized
DEBUG - 2023-07-29 18:58:09 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_guru/views/list.php
DEBUG - 2023-07-29 18:58:09 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:58:09 --> Final output sent to browser
DEBUG - 2023-07-29 18:58:09 --> Total execution time: 0.0512
INFO - 2023-07-29 18:58:09 --> Config Class Initialized
INFO - 2023-07-29 18:58:09 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:09 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:09 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:09 --> URI Class Initialized
INFO - 2023-07-29 18:58:09 --> Router Class Initialized
INFO - 2023-07-29 18:58:09 --> Output Class Initialized
INFO - 2023-07-29 18:58:09 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:09 --> Input Class Initialized
INFO - 2023-07-29 18:58:09 --> Language Class Initialized
INFO - 2023-07-29 18:58:09 --> Language Class Initialized
INFO - 2023-07-29 18:58:09 --> Config Class Initialized
INFO - 2023-07-29 18:58:09 --> Loader Class Initialized
INFO - 2023-07-29 18:58:09 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:09 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:09 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:09 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:09 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:09 --> Controller Class Initialized
INFO - 2023-07-29 18:58:10 --> Config Class Initialized
INFO - 2023-07-29 18:58:10 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:10 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:10 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:10 --> URI Class Initialized
INFO - 2023-07-29 18:58:10 --> Router Class Initialized
INFO - 2023-07-29 18:58:10 --> Output Class Initialized
INFO - 2023-07-29 18:58:10 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:10 --> Input Class Initialized
INFO - 2023-07-29 18:58:10 --> Language Class Initialized
INFO - 2023-07-29 18:58:10 --> Language Class Initialized
INFO - 2023-07-29 18:58:10 --> Config Class Initialized
INFO - 2023-07-29 18:58:10 --> Loader Class Initialized
INFO - 2023-07-29 18:58:10 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:10 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:10 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:10 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:10 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:10 --> Controller Class Initialized
DEBUG - 2023-07-29 18:58:10 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-29 18:58:10 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:58:10 --> Final output sent to browser
DEBUG - 2023-07-29 18:58:10 --> Total execution time: 0.0362
INFO - 2023-07-29 18:58:10 --> Config Class Initialized
INFO - 2023-07-29 18:58:10 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:10 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:10 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:10 --> URI Class Initialized
INFO - 2023-07-29 18:58:10 --> Router Class Initialized
INFO - 2023-07-29 18:58:10 --> Output Class Initialized
INFO - 2023-07-29 18:58:10 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:10 --> Input Class Initialized
INFO - 2023-07-29 18:58:10 --> Language Class Initialized
INFO - 2023-07-29 18:58:10 --> Language Class Initialized
INFO - 2023-07-29 18:58:10 --> Config Class Initialized
INFO - 2023-07-29 18:58:10 --> Loader Class Initialized
INFO - 2023-07-29 18:58:10 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:10 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:10 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:10 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:10 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:10 --> Controller Class Initialized
INFO - 2023-07-29 18:58:10 --> Config Class Initialized
INFO - 2023-07-29 18:58:10 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:10 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:10 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:10 --> URI Class Initialized
INFO - 2023-07-29 18:58:10 --> Router Class Initialized
INFO - 2023-07-29 18:58:10 --> Output Class Initialized
INFO - 2023-07-29 18:58:10 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:10 --> Input Class Initialized
INFO - 2023-07-29 18:58:10 --> Language Class Initialized
INFO - 2023-07-29 18:58:10 --> Language Class Initialized
INFO - 2023-07-29 18:58:10 --> Config Class Initialized
INFO - 2023-07-29 18:58:10 --> Loader Class Initialized
INFO - 2023-07-29 18:58:10 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:10 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:10 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:10 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:10 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:10 --> Controller Class Initialized
DEBUG - 2023-07-29 18:58:10 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_kelas/views/list.php
DEBUG - 2023-07-29 18:58:10 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:58:10 --> Final output sent to browser
DEBUG - 2023-07-29 18:58:10 --> Total execution time: 0.0593
INFO - 2023-07-29 18:58:10 --> Config Class Initialized
INFO - 2023-07-29 18:58:10 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:10 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:10 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:10 --> URI Class Initialized
INFO - 2023-07-29 18:58:10 --> Router Class Initialized
INFO - 2023-07-29 18:58:10 --> Output Class Initialized
INFO - 2023-07-29 18:58:10 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:10 --> Input Class Initialized
INFO - 2023-07-29 18:58:10 --> Language Class Initialized
INFO - 2023-07-29 18:58:10 --> Language Class Initialized
INFO - 2023-07-29 18:58:10 --> Config Class Initialized
INFO - 2023-07-29 18:58:10 --> Loader Class Initialized
INFO - 2023-07-29 18:58:10 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:10 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:10 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:10 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:10 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:10 --> Controller Class Initialized
INFO - 2023-07-29 18:58:11 --> Config Class Initialized
INFO - 2023-07-29 18:58:11 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:11 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:11 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:11 --> URI Class Initialized
INFO - 2023-07-29 18:58:11 --> Router Class Initialized
INFO - 2023-07-29 18:58:11 --> Output Class Initialized
INFO - 2023-07-29 18:58:11 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:11 --> Input Class Initialized
INFO - 2023-07-29 18:58:11 --> Language Class Initialized
INFO - 2023-07-29 18:58:11 --> Language Class Initialized
INFO - 2023-07-29 18:58:11 --> Config Class Initialized
INFO - 2023-07-29 18:58:11 --> Loader Class Initialized
INFO - 2023-07-29 18:58:11 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:11 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:11 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:11 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:11 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:11 --> Controller Class Initialized
DEBUG - 2023-07-29 18:58:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-29 18:58:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:58:11 --> Final output sent to browser
DEBUG - 2023-07-29 18:58:11 --> Total execution time: 0.0540
INFO - 2023-07-29 18:58:11 --> Config Class Initialized
INFO - 2023-07-29 18:58:11 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:11 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:11 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:11 --> URI Class Initialized
INFO - 2023-07-29 18:58:11 --> Router Class Initialized
INFO - 2023-07-29 18:58:11 --> Output Class Initialized
INFO - 2023-07-29 18:58:11 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:11 --> Input Class Initialized
INFO - 2023-07-29 18:58:11 --> Language Class Initialized
INFO - 2023-07-29 18:58:11 --> Language Class Initialized
INFO - 2023-07-29 18:58:11 --> Config Class Initialized
INFO - 2023-07-29 18:58:11 --> Loader Class Initialized
INFO - 2023-07-29 18:58:11 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:11 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:11 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:11 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:11 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:11 --> Controller Class Initialized
INFO - 2023-07-29 18:58:11 --> Config Class Initialized
INFO - 2023-07-29 18:58:11 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:11 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:11 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:11 --> URI Class Initialized
INFO - 2023-07-29 18:58:11 --> Router Class Initialized
INFO - 2023-07-29 18:58:11 --> Output Class Initialized
INFO - 2023-07-29 18:58:11 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:11 --> Input Class Initialized
INFO - 2023-07-29 18:58:11 --> Language Class Initialized
INFO - 2023-07-29 18:58:11 --> Language Class Initialized
INFO - 2023-07-29 18:58:11 --> Config Class Initialized
INFO - 2023-07-29 18:58:11 --> Loader Class Initialized
INFO - 2023-07-29 18:58:11 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:11 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:11 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:11 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:11 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:11 --> Controller Class Initialized
DEBUG - 2023-07-29 18:58:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_guru/views/list.php
DEBUG - 2023-07-29 18:58:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:58:11 --> Final output sent to browser
DEBUG - 2023-07-29 18:58:11 --> Total execution time: 0.0569
INFO - 2023-07-29 18:58:11 --> Config Class Initialized
INFO - 2023-07-29 18:58:11 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:11 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:11 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:11 --> URI Class Initialized
INFO - 2023-07-29 18:58:11 --> Router Class Initialized
INFO - 2023-07-29 18:58:11 --> Output Class Initialized
INFO - 2023-07-29 18:58:11 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:11 --> Input Class Initialized
INFO - 2023-07-29 18:58:11 --> Language Class Initialized
INFO - 2023-07-29 18:58:11 --> Language Class Initialized
INFO - 2023-07-29 18:58:11 --> Config Class Initialized
INFO - 2023-07-29 18:58:11 --> Loader Class Initialized
INFO - 2023-07-29 18:58:11 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:11 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:11 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:11 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:11 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:11 --> Controller Class Initialized
INFO - 2023-07-29 18:58:12 --> Config Class Initialized
INFO - 2023-07-29 18:58:12 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:12 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:12 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:12 --> URI Class Initialized
DEBUG - 2023-07-29 18:58:12 --> No URI present. Default controller set.
INFO - 2023-07-29 18:58:12 --> Router Class Initialized
INFO - 2023-07-29 18:58:12 --> Output Class Initialized
INFO - 2023-07-29 18:58:12 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:12 --> Input Class Initialized
INFO - 2023-07-29 18:58:12 --> Language Class Initialized
INFO - 2023-07-29 18:58:12 --> Language Class Initialized
INFO - 2023-07-29 18:58:12 --> Config Class Initialized
INFO - 2023-07-29 18:58:12 --> Loader Class Initialized
INFO - 2023-07-29 18:58:12 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:12 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:12 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:12 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:12 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:12 --> Controller Class Initialized
DEBUG - 2023-07-29 18:58:12 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:58:12 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:58:12 --> Final output sent to browser
DEBUG - 2023-07-29 18:58:12 --> Total execution time: 0.0615
INFO - 2023-07-29 18:58:13 --> Config Class Initialized
INFO - 2023-07-29 18:58:13 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:13 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:13 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:13 --> URI Class Initialized
INFO - 2023-07-29 18:58:13 --> Router Class Initialized
INFO - 2023-07-29 18:58:13 --> Output Class Initialized
INFO - 2023-07-29 18:58:13 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:13 --> Input Class Initialized
INFO - 2023-07-29 18:58:13 --> Language Class Initialized
INFO - 2023-07-29 18:58:13 --> Language Class Initialized
INFO - 2023-07-29 18:58:13 --> Config Class Initialized
INFO - 2023-07-29 18:58:13 --> Loader Class Initialized
INFO - 2023-07-29 18:58:13 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:13 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:13 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:13 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:13 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:13 --> Controller Class Initialized
DEBUG - 2023-07-29 18:58:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_guru/views/list.php
DEBUG - 2023-07-29 18:58:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:58:13 --> Final output sent to browser
DEBUG - 2023-07-29 18:58:13 --> Total execution time: 0.0515
INFO - 2023-07-29 18:58:13 --> Config Class Initialized
INFO - 2023-07-29 18:58:13 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:13 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:13 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:13 --> URI Class Initialized
INFO - 2023-07-29 18:58:13 --> Router Class Initialized
INFO - 2023-07-29 18:58:13 --> Output Class Initialized
INFO - 2023-07-29 18:58:13 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:13 --> Input Class Initialized
INFO - 2023-07-29 18:58:13 --> Language Class Initialized
INFO - 2023-07-29 18:58:13 --> Language Class Initialized
INFO - 2023-07-29 18:58:13 --> Config Class Initialized
INFO - 2023-07-29 18:58:13 --> Loader Class Initialized
INFO - 2023-07-29 18:58:13 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:13 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:13 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:13 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:13 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:13 --> Controller Class Initialized
INFO - 2023-07-29 18:58:13 --> Config Class Initialized
INFO - 2023-07-29 18:58:13 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:13 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:13 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:13 --> URI Class Initialized
INFO - 2023-07-29 18:58:13 --> Router Class Initialized
INFO - 2023-07-29 18:58:13 --> Output Class Initialized
INFO - 2023-07-29 18:58:13 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:13 --> Input Class Initialized
INFO - 2023-07-29 18:58:13 --> Language Class Initialized
INFO - 2023-07-29 18:58:13 --> Language Class Initialized
INFO - 2023-07-29 18:58:13 --> Config Class Initialized
INFO - 2023-07-29 18:58:13 --> Loader Class Initialized
INFO - 2023-07-29 18:58:13 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:13 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:13 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:13 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:13 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:13 --> Controller Class Initialized
DEBUG - 2023-07-29 18:58:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-29 18:58:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:58:13 --> Final output sent to browser
DEBUG - 2023-07-29 18:58:13 --> Total execution time: 0.0597
INFO - 2023-07-29 18:58:14 --> Config Class Initialized
INFO - 2023-07-29 18:58:14 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:14 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:14 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:14 --> URI Class Initialized
INFO - 2023-07-29 18:58:14 --> Router Class Initialized
INFO - 2023-07-29 18:58:14 --> Output Class Initialized
INFO - 2023-07-29 18:58:14 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:14 --> Input Class Initialized
INFO - 2023-07-29 18:58:14 --> Language Class Initialized
INFO - 2023-07-29 18:58:14 --> Language Class Initialized
INFO - 2023-07-29 18:58:14 --> Config Class Initialized
INFO - 2023-07-29 18:58:14 --> Loader Class Initialized
INFO - 2023-07-29 18:58:14 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:14 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:14 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:14 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:14 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:14 --> Controller Class Initialized
INFO - 2023-07-29 18:58:14 --> Config Class Initialized
INFO - 2023-07-29 18:58:14 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:14 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:14 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:14 --> URI Class Initialized
INFO - 2023-07-29 18:58:14 --> Router Class Initialized
INFO - 2023-07-29 18:58:14 --> Output Class Initialized
INFO - 2023-07-29 18:58:14 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:14 --> Input Class Initialized
INFO - 2023-07-29 18:58:14 --> Language Class Initialized
INFO - 2023-07-29 18:58:14 --> Language Class Initialized
INFO - 2023-07-29 18:58:14 --> Config Class Initialized
INFO - 2023-07-29 18:58:14 --> Loader Class Initialized
INFO - 2023-07-29 18:58:14 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:14 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:14 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:14 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:14 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:14 --> Controller Class Initialized
DEBUG - 2023-07-29 18:58:14 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_kelas/views/list.php
DEBUG - 2023-07-29 18:58:14 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:58:14 --> Final output sent to browser
DEBUG - 2023-07-29 18:58:14 --> Total execution time: 0.0531
INFO - 2023-07-29 18:58:14 --> Config Class Initialized
INFO - 2023-07-29 18:58:14 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:14 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:14 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:14 --> URI Class Initialized
INFO - 2023-07-29 18:58:14 --> Router Class Initialized
INFO - 2023-07-29 18:58:14 --> Output Class Initialized
INFO - 2023-07-29 18:58:14 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:14 --> Input Class Initialized
INFO - 2023-07-29 18:58:14 --> Language Class Initialized
INFO - 2023-07-29 18:58:14 --> Language Class Initialized
INFO - 2023-07-29 18:58:14 --> Config Class Initialized
INFO - 2023-07-29 18:58:14 --> Loader Class Initialized
INFO - 2023-07-29 18:58:14 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:14 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:14 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:14 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:15 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:15 --> Controller Class Initialized
INFO - 2023-07-29 18:58:15 --> Config Class Initialized
INFO - 2023-07-29 18:58:15 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:15 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:15 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:15 --> URI Class Initialized
INFO - 2023-07-29 18:58:15 --> Router Class Initialized
INFO - 2023-07-29 18:58:15 --> Output Class Initialized
INFO - 2023-07-29 18:58:15 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:15 --> Input Class Initialized
INFO - 2023-07-29 18:58:15 --> Language Class Initialized
INFO - 2023-07-29 18:58:15 --> Language Class Initialized
INFO - 2023-07-29 18:58:15 --> Config Class Initialized
INFO - 2023-07-29 18:58:15 --> Loader Class Initialized
INFO - 2023-07-29 18:58:15 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:15 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:15 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:15 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:15 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:15 --> Controller Class Initialized
DEBUG - 2023-07-29 18:58:15 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_mapel/views/list.php
DEBUG - 2023-07-29 18:58:15 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:58:15 --> Final output sent to browser
DEBUG - 2023-07-29 18:58:15 --> Total execution time: 0.0369
INFO - 2023-07-29 18:58:15 --> Config Class Initialized
INFO - 2023-07-29 18:58:15 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:15 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:15 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:15 --> URI Class Initialized
INFO - 2023-07-29 18:58:15 --> Router Class Initialized
INFO - 2023-07-29 18:58:15 --> Output Class Initialized
INFO - 2023-07-29 18:58:15 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:15 --> Input Class Initialized
INFO - 2023-07-29 18:58:15 --> Language Class Initialized
INFO - 2023-07-29 18:58:15 --> Language Class Initialized
INFO - 2023-07-29 18:58:15 --> Config Class Initialized
INFO - 2023-07-29 18:58:15 --> Loader Class Initialized
INFO - 2023-07-29 18:58:15 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:15 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:15 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:15 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:15 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:15 --> Controller Class Initialized
INFO - 2023-07-29 18:58:16 --> Config Class Initialized
INFO - 2023-07-29 18:58:16 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:16 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:16 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:16 --> URI Class Initialized
INFO - 2023-07-29 18:58:16 --> Router Class Initialized
INFO - 2023-07-29 18:58:16 --> Output Class Initialized
INFO - 2023-07-29 18:58:16 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:16 --> Input Class Initialized
INFO - 2023-07-29 18:58:16 --> Language Class Initialized
INFO - 2023-07-29 18:58:16 --> Language Class Initialized
INFO - 2023-07-29 18:58:16 --> Config Class Initialized
INFO - 2023-07-29 18:58:16 --> Loader Class Initialized
INFO - 2023-07-29 18:58:16 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:16 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:16 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:16 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:16 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:16 --> Controller Class Initialized
DEBUG - 2023-07-29 18:58:16 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_kelas/views/list.php
DEBUG - 2023-07-29 18:58:16 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:58:16 --> Final output sent to browser
DEBUG - 2023-07-29 18:58:16 --> Total execution time: 0.0597
INFO - 2023-07-29 18:58:16 --> Config Class Initialized
INFO - 2023-07-29 18:58:16 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:16 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:16 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:16 --> URI Class Initialized
INFO - 2023-07-29 18:58:16 --> Router Class Initialized
INFO - 2023-07-29 18:58:16 --> Output Class Initialized
INFO - 2023-07-29 18:58:16 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:16 --> Input Class Initialized
INFO - 2023-07-29 18:58:16 --> Language Class Initialized
INFO - 2023-07-29 18:58:16 --> Language Class Initialized
INFO - 2023-07-29 18:58:16 --> Config Class Initialized
INFO - 2023-07-29 18:58:16 --> Loader Class Initialized
INFO - 2023-07-29 18:58:16 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:16 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:16 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:16 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:16 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:16 --> Controller Class Initialized
INFO - 2023-07-29 18:58:16 --> Config Class Initialized
INFO - 2023-07-29 18:58:16 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:16 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:16 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:16 --> URI Class Initialized
INFO - 2023-07-29 18:58:16 --> Router Class Initialized
INFO - 2023-07-29 18:58:16 --> Output Class Initialized
INFO - 2023-07-29 18:58:16 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:16 --> Input Class Initialized
INFO - 2023-07-29 18:58:16 --> Language Class Initialized
INFO - 2023-07-29 18:58:16 --> Language Class Initialized
INFO - 2023-07-29 18:58:16 --> Config Class Initialized
INFO - 2023-07-29 18:58:16 --> Loader Class Initialized
INFO - 2023-07-29 18:58:16 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:16 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:16 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:16 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:16 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:16 --> Controller Class Initialized
DEBUG - 2023-07-29 18:58:16 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-29 18:58:16 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:58:16 --> Final output sent to browser
DEBUG - 2023-07-29 18:58:16 --> Total execution time: 0.0561
INFO - 2023-07-29 18:58:16 --> Config Class Initialized
INFO - 2023-07-29 18:58:16 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:16 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:16 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:16 --> URI Class Initialized
INFO - 2023-07-29 18:58:16 --> Router Class Initialized
INFO - 2023-07-29 18:58:16 --> Output Class Initialized
INFO - 2023-07-29 18:58:16 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:16 --> Input Class Initialized
INFO - 2023-07-29 18:58:16 --> Language Class Initialized
INFO - 2023-07-29 18:58:16 --> Language Class Initialized
INFO - 2023-07-29 18:58:16 --> Config Class Initialized
INFO - 2023-07-29 18:58:16 --> Loader Class Initialized
INFO - 2023-07-29 18:58:16 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:16 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:16 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:16 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:16 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:16 --> Controller Class Initialized
INFO - 2023-07-29 18:58:17 --> Config Class Initialized
INFO - 2023-07-29 18:58:17 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:17 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:17 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:17 --> URI Class Initialized
INFO - 2023-07-29 18:58:17 --> Router Class Initialized
INFO - 2023-07-29 18:58:17 --> Output Class Initialized
INFO - 2023-07-29 18:58:17 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:17 --> Input Class Initialized
INFO - 2023-07-29 18:58:17 --> Language Class Initialized
INFO - 2023-07-29 18:58:17 --> Language Class Initialized
INFO - 2023-07-29 18:58:17 --> Config Class Initialized
INFO - 2023-07-29 18:58:17 --> Loader Class Initialized
INFO - 2023-07-29 18:58:17 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:17 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:17 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:17 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:17 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:17 --> Controller Class Initialized
DEBUG - 2023-07-29 18:58:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_guru/views/list.php
DEBUG - 2023-07-29 18:58:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:58:17 --> Final output sent to browser
DEBUG - 2023-07-29 18:58:17 --> Total execution time: 0.0600
INFO - 2023-07-29 18:58:17 --> Config Class Initialized
INFO - 2023-07-29 18:58:17 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:17 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:17 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:17 --> URI Class Initialized
INFO - 2023-07-29 18:58:17 --> Router Class Initialized
INFO - 2023-07-29 18:58:17 --> Output Class Initialized
INFO - 2023-07-29 18:58:17 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:17 --> Input Class Initialized
INFO - 2023-07-29 18:58:17 --> Language Class Initialized
INFO - 2023-07-29 18:58:17 --> Language Class Initialized
INFO - 2023-07-29 18:58:17 --> Config Class Initialized
INFO - 2023-07-29 18:58:17 --> Loader Class Initialized
INFO - 2023-07-29 18:58:17 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:17 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:17 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:17 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:17 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:17 --> Controller Class Initialized
INFO - 2023-07-29 18:58:17 --> Config Class Initialized
INFO - 2023-07-29 18:58:17 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:17 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:17 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:17 --> URI Class Initialized
DEBUG - 2023-07-29 18:58:17 --> No URI present. Default controller set.
INFO - 2023-07-29 18:58:17 --> Router Class Initialized
INFO - 2023-07-29 18:58:17 --> Output Class Initialized
INFO - 2023-07-29 18:58:17 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:17 --> Input Class Initialized
INFO - 2023-07-29 18:58:17 --> Language Class Initialized
INFO - 2023-07-29 18:58:17 --> Language Class Initialized
INFO - 2023-07-29 18:58:17 --> Config Class Initialized
INFO - 2023-07-29 18:58:17 --> Loader Class Initialized
INFO - 2023-07-29 18:58:17 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:17 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:17 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:17 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:17 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:17 --> Controller Class Initialized
DEBUG - 2023-07-29 18:58:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:58:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:58:17 --> Final output sent to browser
DEBUG - 2023-07-29 18:58:17 --> Total execution time: 0.0598
INFO - 2023-07-29 18:58:19 --> Config Class Initialized
INFO - 2023-07-29 18:58:19 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:19 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:19 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:19 --> URI Class Initialized
INFO - 2023-07-29 18:58:20 --> Router Class Initialized
INFO - 2023-07-29 18:58:20 --> Output Class Initialized
INFO - 2023-07-29 18:58:20 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:20 --> Input Class Initialized
INFO - 2023-07-29 18:58:20 --> Language Class Initialized
INFO - 2023-07-29 18:58:20 --> Language Class Initialized
INFO - 2023-07-29 18:58:20 --> Config Class Initialized
INFO - 2023-07-29 18:58:20 --> Loader Class Initialized
INFO - 2023-07-29 18:58:20 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:20 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:20 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:20 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:20 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:20 --> Controller Class Initialized
DEBUG - 2023-07-29 18:58:20 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_guru/views/list.php
DEBUG - 2023-07-29 18:58:20 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:58:20 --> Final output sent to browser
DEBUG - 2023-07-29 18:58:20 --> Total execution time: 0.0578
INFO - 2023-07-29 18:58:20 --> Config Class Initialized
INFO - 2023-07-29 18:58:20 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:20 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:20 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:20 --> URI Class Initialized
INFO - 2023-07-29 18:58:20 --> Router Class Initialized
INFO - 2023-07-29 18:58:20 --> Output Class Initialized
INFO - 2023-07-29 18:58:20 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:20 --> Input Class Initialized
INFO - 2023-07-29 18:58:20 --> Language Class Initialized
INFO - 2023-07-29 18:58:20 --> Language Class Initialized
INFO - 2023-07-29 18:58:20 --> Config Class Initialized
INFO - 2023-07-29 18:58:20 --> Loader Class Initialized
INFO - 2023-07-29 18:58:20 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:20 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:20 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:20 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:20 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:20 --> Controller Class Initialized
INFO - 2023-07-29 18:58:20 --> Config Class Initialized
INFO - 2023-07-29 18:58:20 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:20 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:20 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:20 --> URI Class Initialized
INFO - 2023-07-29 18:58:20 --> Router Class Initialized
INFO - 2023-07-29 18:58:20 --> Output Class Initialized
INFO - 2023-07-29 18:58:20 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:20 --> Input Class Initialized
INFO - 2023-07-29 18:58:20 --> Language Class Initialized
INFO - 2023-07-29 18:58:20 --> Language Class Initialized
INFO - 2023-07-29 18:58:20 --> Config Class Initialized
INFO - 2023-07-29 18:58:20 --> Loader Class Initialized
INFO - 2023-07-29 18:58:20 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:20 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:20 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:20 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:20 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:20 --> Controller Class Initialized
DEBUG - 2023-07-29 18:58:20 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-29 18:58:20 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:58:20 --> Final output sent to browser
DEBUG - 2023-07-29 18:58:20 --> Total execution time: 0.0498
INFO - 2023-07-29 18:58:20 --> Config Class Initialized
INFO - 2023-07-29 18:58:20 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:20 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:20 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:20 --> URI Class Initialized
INFO - 2023-07-29 18:58:20 --> Router Class Initialized
INFO - 2023-07-29 18:58:20 --> Output Class Initialized
INFO - 2023-07-29 18:58:20 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:20 --> Input Class Initialized
INFO - 2023-07-29 18:58:20 --> Language Class Initialized
INFO - 2023-07-29 18:58:20 --> Language Class Initialized
INFO - 2023-07-29 18:58:20 --> Config Class Initialized
INFO - 2023-07-29 18:58:20 --> Loader Class Initialized
INFO - 2023-07-29 18:58:20 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:20 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:20 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:20 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:20 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:20 --> Controller Class Initialized
INFO - 2023-07-29 18:58:21 --> Config Class Initialized
INFO - 2023-07-29 18:58:21 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:21 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:21 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:21 --> URI Class Initialized
INFO - 2023-07-29 18:58:21 --> Router Class Initialized
INFO - 2023-07-29 18:58:21 --> Output Class Initialized
INFO - 2023-07-29 18:58:21 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:21 --> Input Class Initialized
INFO - 2023-07-29 18:58:21 --> Language Class Initialized
INFO - 2023-07-29 18:58:21 --> Language Class Initialized
INFO - 2023-07-29 18:58:21 --> Config Class Initialized
INFO - 2023-07-29 18:58:21 --> Loader Class Initialized
INFO - 2023-07-29 18:58:21 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:21 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:21 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:21 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:21 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:21 --> Controller Class Initialized
DEBUG - 2023-07-29 18:58:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_kelas/views/list.php
DEBUG - 2023-07-29 18:58:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:58:21 --> Final output sent to browser
DEBUG - 2023-07-29 18:58:21 --> Total execution time: 0.0355
INFO - 2023-07-29 18:58:21 --> Config Class Initialized
INFO - 2023-07-29 18:58:21 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:21 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:21 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:21 --> URI Class Initialized
INFO - 2023-07-29 18:58:21 --> Router Class Initialized
INFO - 2023-07-29 18:58:21 --> Output Class Initialized
INFO - 2023-07-29 18:58:21 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:21 --> Input Class Initialized
INFO - 2023-07-29 18:58:21 --> Language Class Initialized
INFO - 2023-07-29 18:58:21 --> Language Class Initialized
INFO - 2023-07-29 18:58:21 --> Config Class Initialized
INFO - 2023-07-29 18:58:21 --> Loader Class Initialized
INFO - 2023-07-29 18:58:21 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:21 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:21 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:21 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:21 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:21 --> Controller Class Initialized
INFO - 2023-07-29 18:58:45 --> Config Class Initialized
INFO - 2023-07-29 18:58:45 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:45 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:45 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:45 --> URI Class Initialized
DEBUG - 2023-07-29 18:58:45 --> No URI present. Default controller set.
INFO - 2023-07-29 18:58:45 --> Router Class Initialized
INFO - 2023-07-29 18:58:45 --> Output Class Initialized
INFO - 2023-07-29 18:58:45 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:45 --> Input Class Initialized
INFO - 2023-07-29 18:58:45 --> Language Class Initialized
INFO - 2023-07-29 18:58:45 --> Language Class Initialized
INFO - 2023-07-29 18:58:45 --> Config Class Initialized
INFO - 2023-07-29 18:58:45 --> Loader Class Initialized
INFO - 2023-07-29 18:58:45 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:45 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:45 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:45 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:45 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:45 --> Controller Class Initialized
DEBUG - 2023-07-29 18:58:45 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:58:45 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:58:45 --> Final output sent to browser
DEBUG - 2023-07-29 18:58:45 --> Total execution time: 0.0537
INFO - 2023-07-29 18:58:47 --> Config Class Initialized
INFO - 2023-07-29 18:58:47 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:47 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:47 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:47 --> URI Class Initialized
INFO - 2023-07-29 18:58:47 --> Router Class Initialized
INFO - 2023-07-29 18:58:47 --> Output Class Initialized
INFO - 2023-07-29 18:58:47 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:47 --> Input Class Initialized
INFO - 2023-07-29 18:58:47 --> Language Class Initialized
INFO - 2023-07-29 18:58:47 --> Language Class Initialized
INFO - 2023-07-29 18:58:47 --> Config Class Initialized
INFO - 2023-07-29 18:58:47 --> Loader Class Initialized
INFO - 2023-07-29 18:58:47 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:47 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:47 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:47 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:47 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:47 --> Controller Class Initialized
DEBUG - 2023-07-29 18:58:47 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_guru/views/list.php
DEBUG - 2023-07-29 18:58:47 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:58:47 --> Final output sent to browser
DEBUG - 2023-07-29 18:58:47 --> Total execution time: 0.0497
INFO - 2023-07-29 18:58:47 --> Config Class Initialized
INFO - 2023-07-29 18:58:47 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:47 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:47 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:47 --> URI Class Initialized
INFO - 2023-07-29 18:58:47 --> Router Class Initialized
INFO - 2023-07-29 18:58:47 --> Output Class Initialized
INFO - 2023-07-29 18:58:47 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:47 --> Input Class Initialized
INFO - 2023-07-29 18:58:47 --> Language Class Initialized
INFO - 2023-07-29 18:58:47 --> Language Class Initialized
INFO - 2023-07-29 18:58:47 --> Config Class Initialized
INFO - 2023-07-29 18:58:47 --> Loader Class Initialized
INFO - 2023-07-29 18:58:47 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:47 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:47 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:47 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:47 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:47 --> Controller Class Initialized
INFO - 2023-07-29 18:58:48 --> Config Class Initialized
INFO - 2023-07-29 18:58:48 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:48 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:48 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:48 --> URI Class Initialized
DEBUG - 2023-07-29 18:58:48 --> No URI present. Default controller set.
INFO - 2023-07-29 18:58:48 --> Router Class Initialized
INFO - 2023-07-29 18:58:48 --> Output Class Initialized
INFO - 2023-07-29 18:58:48 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:48 --> Input Class Initialized
INFO - 2023-07-29 18:58:48 --> Language Class Initialized
INFO - 2023-07-29 18:58:48 --> Language Class Initialized
INFO - 2023-07-29 18:58:48 --> Config Class Initialized
INFO - 2023-07-29 18:58:48 --> Loader Class Initialized
INFO - 2023-07-29 18:58:48 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:48 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:48 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:48 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:48 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:48 --> Controller Class Initialized
DEBUG - 2023-07-29 18:58:48 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:58:48 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:58:48 --> Final output sent to browser
DEBUG - 2023-07-29 18:58:48 --> Total execution time: 0.0633
INFO - 2023-07-29 18:58:48 --> Config Class Initialized
INFO - 2023-07-29 18:58:48 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:48 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:48 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:48 --> URI Class Initialized
INFO - 2023-07-29 18:58:48 --> Router Class Initialized
INFO - 2023-07-29 18:58:48 --> Output Class Initialized
INFO - 2023-07-29 18:58:48 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:48 --> Input Class Initialized
INFO - 2023-07-29 18:58:48 --> Language Class Initialized
INFO - 2023-07-29 18:58:48 --> Language Class Initialized
INFO - 2023-07-29 18:58:48 --> Config Class Initialized
INFO - 2023-07-29 18:58:48 --> Loader Class Initialized
INFO - 2023-07-29 18:58:48 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:48 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:48 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:48 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:48 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:48 --> Controller Class Initialized
DEBUG - 2023-07-29 18:58:48 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_guru/views/list.php
DEBUG - 2023-07-29 18:58:48 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:58:48 --> Final output sent to browser
DEBUG - 2023-07-29 18:58:48 --> Total execution time: 0.0350
INFO - 2023-07-29 18:58:49 --> Config Class Initialized
INFO - 2023-07-29 18:58:49 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:49 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:49 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:49 --> URI Class Initialized
INFO - 2023-07-29 18:58:49 --> Router Class Initialized
INFO - 2023-07-29 18:58:49 --> Output Class Initialized
INFO - 2023-07-29 18:58:49 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:49 --> Input Class Initialized
INFO - 2023-07-29 18:58:49 --> Language Class Initialized
INFO - 2023-07-29 18:58:49 --> Language Class Initialized
INFO - 2023-07-29 18:58:49 --> Config Class Initialized
INFO - 2023-07-29 18:58:49 --> Loader Class Initialized
INFO - 2023-07-29 18:58:49 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:49 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:49 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:49 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:49 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:49 --> Controller Class Initialized
INFO - 2023-07-29 18:58:49 --> Config Class Initialized
INFO - 2023-07-29 18:58:49 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:49 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:49 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:49 --> URI Class Initialized
INFO - 2023-07-29 18:58:49 --> Router Class Initialized
INFO - 2023-07-29 18:58:49 --> Output Class Initialized
INFO - 2023-07-29 18:58:49 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:49 --> Input Class Initialized
INFO - 2023-07-29 18:58:49 --> Language Class Initialized
INFO - 2023-07-29 18:58:49 --> Language Class Initialized
INFO - 2023-07-29 18:58:49 --> Config Class Initialized
INFO - 2023-07-29 18:58:49 --> Loader Class Initialized
INFO - 2023-07-29 18:58:49 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:49 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:49 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:49 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:49 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:49 --> Controller Class Initialized
DEBUG - 2023-07-29 18:58:49 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-29 18:58:49 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:58:49 --> Final output sent to browser
DEBUG - 2023-07-29 18:58:49 --> Total execution time: 0.0506
INFO - 2023-07-29 18:58:49 --> Config Class Initialized
INFO - 2023-07-29 18:58:49 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:49 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:49 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:49 --> URI Class Initialized
INFO - 2023-07-29 18:58:49 --> Router Class Initialized
INFO - 2023-07-29 18:58:49 --> Output Class Initialized
INFO - 2023-07-29 18:58:49 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:49 --> Input Class Initialized
INFO - 2023-07-29 18:58:49 --> Language Class Initialized
INFO - 2023-07-29 18:58:49 --> Language Class Initialized
INFO - 2023-07-29 18:58:49 --> Config Class Initialized
INFO - 2023-07-29 18:58:49 --> Loader Class Initialized
INFO - 2023-07-29 18:58:49 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:49 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:49 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:49 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:49 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:49 --> Controller Class Initialized
INFO - 2023-07-29 18:58:50 --> Config Class Initialized
INFO - 2023-07-29 18:58:50 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:50 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:50 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:50 --> URI Class Initialized
INFO - 2023-07-29 18:58:50 --> Router Class Initialized
INFO - 2023-07-29 18:58:50 --> Output Class Initialized
INFO - 2023-07-29 18:58:50 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:50 --> Input Class Initialized
INFO - 2023-07-29 18:58:50 --> Language Class Initialized
INFO - 2023-07-29 18:58:50 --> Language Class Initialized
INFO - 2023-07-29 18:58:50 --> Config Class Initialized
INFO - 2023-07-29 18:58:50 --> Loader Class Initialized
INFO - 2023-07-29 18:58:50 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:50 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:50 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:50 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:50 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:50 --> Controller Class Initialized
DEBUG - 2023-07-29 18:58:50 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_kelas/views/list.php
DEBUG - 2023-07-29 18:58:50 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:58:50 --> Final output sent to browser
DEBUG - 2023-07-29 18:58:50 --> Total execution time: 0.0462
INFO - 2023-07-29 18:58:50 --> Config Class Initialized
INFO - 2023-07-29 18:58:50 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:50 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:50 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:50 --> URI Class Initialized
INFO - 2023-07-29 18:58:50 --> Router Class Initialized
INFO - 2023-07-29 18:58:50 --> Output Class Initialized
INFO - 2023-07-29 18:58:50 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:50 --> Input Class Initialized
INFO - 2023-07-29 18:58:50 --> Language Class Initialized
INFO - 2023-07-29 18:58:50 --> Language Class Initialized
INFO - 2023-07-29 18:58:50 --> Config Class Initialized
INFO - 2023-07-29 18:58:50 --> Loader Class Initialized
INFO - 2023-07-29 18:58:50 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:50 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:50 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:50 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:50 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:50 --> Controller Class Initialized
INFO - 2023-07-29 18:58:51 --> Config Class Initialized
INFO - 2023-07-29 18:58:51 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:51 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:51 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:51 --> URI Class Initialized
DEBUG - 2023-07-29 18:58:51 --> No URI present. Default controller set.
INFO - 2023-07-29 18:58:51 --> Router Class Initialized
INFO - 2023-07-29 18:58:51 --> Output Class Initialized
INFO - 2023-07-29 18:58:51 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:51 --> Input Class Initialized
INFO - 2023-07-29 18:58:51 --> Language Class Initialized
INFO - 2023-07-29 18:58:51 --> Language Class Initialized
INFO - 2023-07-29 18:58:51 --> Config Class Initialized
INFO - 2023-07-29 18:58:51 --> Loader Class Initialized
INFO - 2023-07-29 18:58:51 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:51 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:51 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:51 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:51 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:51 --> Controller Class Initialized
DEBUG - 2023-07-29 18:58:51 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 18:58:51 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:58:51 --> Final output sent to browser
DEBUG - 2023-07-29 18:58:51 --> Total execution time: 0.0348
INFO - 2023-07-29 18:58:54 --> Config Class Initialized
INFO - 2023-07-29 18:58:54 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:54 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:54 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:54 --> URI Class Initialized
INFO - 2023-07-29 18:58:54 --> Router Class Initialized
INFO - 2023-07-29 18:58:54 --> Output Class Initialized
INFO - 2023-07-29 18:58:54 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:54 --> Input Class Initialized
INFO - 2023-07-29 18:58:54 --> Language Class Initialized
INFO - 2023-07-29 18:58:54 --> Language Class Initialized
INFO - 2023-07-29 18:58:54 --> Config Class Initialized
INFO - 2023-07-29 18:58:54 --> Loader Class Initialized
INFO - 2023-07-29 18:58:54 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:54 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:54 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:54 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:54 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:54 --> Controller Class Initialized
DEBUG - 2023-07-29 18:58:54 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_guru/views/list.php
DEBUG - 2023-07-29 18:58:54 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 18:58:54 --> Final output sent to browser
DEBUG - 2023-07-29 18:58:54 --> Total execution time: 0.0531
INFO - 2023-07-29 18:58:54 --> Config Class Initialized
INFO - 2023-07-29 18:58:54 --> Hooks Class Initialized
DEBUG - 2023-07-29 18:58:54 --> UTF-8 Support Enabled
INFO - 2023-07-29 18:58:54 --> Utf8 Class Initialized
INFO - 2023-07-29 18:58:54 --> URI Class Initialized
INFO - 2023-07-29 18:58:54 --> Router Class Initialized
INFO - 2023-07-29 18:58:54 --> Output Class Initialized
INFO - 2023-07-29 18:58:54 --> Security Class Initialized
DEBUG - 2023-07-29 18:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 18:58:54 --> Input Class Initialized
INFO - 2023-07-29 18:58:54 --> Language Class Initialized
INFO - 2023-07-29 18:58:54 --> Language Class Initialized
INFO - 2023-07-29 18:58:54 --> Config Class Initialized
INFO - 2023-07-29 18:58:54 --> Loader Class Initialized
INFO - 2023-07-29 18:58:54 --> Helper loaded: url_helper
INFO - 2023-07-29 18:58:54 --> Helper loaded: file_helper
INFO - 2023-07-29 18:58:54 --> Helper loaded: form_helper
INFO - 2023-07-29 18:58:54 --> Helper loaded: my_helper
INFO - 2023-07-29 18:58:54 --> Database Driver Class Initialized
DEBUG - 2023-07-29 18:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 18:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 18:58:54 --> Controller Class Initialized
INFO - 2023-07-29 19:01:08 --> Config Class Initialized
INFO - 2023-07-29 19:01:08 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:01:08 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:01:08 --> Utf8 Class Initialized
INFO - 2023-07-29 19:01:08 --> URI Class Initialized
DEBUG - 2023-07-29 19:01:08 --> No URI present. Default controller set.
INFO - 2023-07-29 19:01:08 --> Router Class Initialized
INFO - 2023-07-29 19:01:08 --> Output Class Initialized
INFO - 2023-07-29 19:01:08 --> Security Class Initialized
DEBUG - 2023-07-29 19:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:01:08 --> Input Class Initialized
INFO - 2023-07-29 19:01:08 --> Language Class Initialized
INFO - 2023-07-29 19:01:08 --> Language Class Initialized
INFO - 2023-07-29 19:01:08 --> Config Class Initialized
INFO - 2023-07-29 19:01:08 --> Loader Class Initialized
INFO - 2023-07-29 19:01:08 --> Helper loaded: url_helper
INFO - 2023-07-29 19:01:08 --> Helper loaded: file_helper
INFO - 2023-07-29 19:01:08 --> Helper loaded: form_helper
INFO - 2023-07-29 19:01:08 --> Helper loaded: my_helper
INFO - 2023-07-29 19:01:08 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:01:08 --> Controller Class Initialized
DEBUG - 2023-07-29 19:01:08 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 19:01:08 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 19:01:08 --> Final output sent to browser
DEBUG - 2023-07-29 19:01:08 --> Total execution time: 0.0490
INFO - 2023-07-29 19:01:11 --> Config Class Initialized
INFO - 2023-07-29 19:01:11 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:01:11 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:01:11 --> Utf8 Class Initialized
INFO - 2023-07-29 19:01:11 --> URI Class Initialized
INFO - 2023-07-29 19:01:11 --> Router Class Initialized
INFO - 2023-07-29 19:01:11 --> Output Class Initialized
INFO - 2023-07-29 19:01:11 --> Security Class Initialized
DEBUG - 2023-07-29 19:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:01:11 --> Input Class Initialized
INFO - 2023-07-29 19:01:11 --> Language Class Initialized
INFO - 2023-07-29 19:01:11 --> Language Class Initialized
INFO - 2023-07-29 19:01:11 --> Config Class Initialized
INFO - 2023-07-29 19:01:11 --> Loader Class Initialized
INFO - 2023-07-29 19:01:11 --> Helper loaded: url_helper
INFO - 2023-07-29 19:01:11 --> Helper loaded: file_helper
INFO - 2023-07-29 19:01:11 --> Helper loaded: form_helper
INFO - 2023-07-29 19:01:11 --> Helper loaded: my_helper
INFO - 2023-07-29 19:01:11 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:01:11 --> Controller Class Initialized
DEBUG - 2023-07-29 19:01:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_guru/views/list.php
DEBUG - 2023-07-29 19:01:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 19:01:11 --> Final output sent to browser
DEBUG - 2023-07-29 19:01:11 --> Total execution time: 0.0447
INFO - 2023-07-29 19:01:11 --> Config Class Initialized
INFO - 2023-07-29 19:01:11 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:01:11 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:01:11 --> Utf8 Class Initialized
INFO - 2023-07-29 19:01:11 --> URI Class Initialized
INFO - 2023-07-29 19:01:11 --> Router Class Initialized
INFO - 2023-07-29 19:01:11 --> Output Class Initialized
INFO - 2023-07-29 19:01:11 --> Security Class Initialized
DEBUG - 2023-07-29 19:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:01:11 --> Input Class Initialized
INFO - 2023-07-29 19:01:11 --> Language Class Initialized
INFO - 2023-07-29 19:01:11 --> Language Class Initialized
INFO - 2023-07-29 19:01:11 --> Config Class Initialized
INFO - 2023-07-29 19:01:11 --> Loader Class Initialized
INFO - 2023-07-29 19:01:11 --> Helper loaded: url_helper
INFO - 2023-07-29 19:01:11 --> Helper loaded: file_helper
INFO - 2023-07-29 19:01:11 --> Helper loaded: form_helper
INFO - 2023-07-29 19:01:11 --> Helper loaded: my_helper
INFO - 2023-07-29 19:01:11 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:01:12 --> Controller Class Initialized
INFO - 2023-07-29 19:01:13 --> Config Class Initialized
INFO - 2023-07-29 19:01:13 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:01:13 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:01:13 --> Utf8 Class Initialized
INFO - 2023-07-29 19:01:13 --> URI Class Initialized
INFO - 2023-07-29 19:01:13 --> Router Class Initialized
INFO - 2023-07-29 19:01:13 --> Output Class Initialized
INFO - 2023-07-29 19:01:13 --> Security Class Initialized
DEBUG - 2023-07-29 19:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:01:13 --> Input Class Initialized
INFO - 2023-07-29 19:01:13 --> Language Class Initialized
INFO - 2023-07-29 19:01:13 --> Language Class Initialized
INFO - 2023-07-29 19:01:13 --> Config Class Initialized
INFO - 2023-07-29 19:01:13 --> Loader Class Initialized
INFO - 2023-07-29 19:01:13 --> Helper loaded: url_helper
INFO - 2023-07-29 19:01:13 --> Helper loaded: file_helper
INFO - 2023-07-29 19:01:13 --> Helper loaded: form_helper
INFO - 2023-07-29 19:01:13 --> Helper loaded: my_helper
INFO - 2023-07-29 19:01:13 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:01:13 --> Controller Class Initialized
DEBUG - 2023-07-29 19:01:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-29 19:01:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 19:01:13 --> Final output sent to browser
DEBUG - 2023-07-29 19:01:13 --> Total execution time: 0.0378
INFO - 2023-07-29 19:01:13 --> Config Class Initialized
INFO - 2023-07-29 19:01:13 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:01:13 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:01:13 --> Utf8 Class Initialized
INFO - 2023-07-29 19:01:13 --> URI Class Initialized
INFO - 2023-07-29 19:01:13 --> Router Class Initialized
INFO - 2023-07-29 19:01:13 --> Output Class Initialized
INFO - 2023-07-29 19:01:13 --> Security Class Initialized
DEBUG - 2023-07-29 19:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:01:13 --> Input Class Initialized
INFO - 2023-07-29 19:01:13 --> Language Class Initialized
INFO - 2023-07-29 19:01:13 --> Language Class Initialized
INFO - 2023-07-29 19:01:13 --> Config Class Initialized
INFO - 2023-07-29 19:01:13 --> Loader Class Initialized
INFO - 2023-07-29 19:01:13 --> Helper loaded: url_helper
INFO - 2023-07-29 19:01:13 --> Helper loaded: file_helper
INFO - 2023-07-29 19:01:13 --> Helper loaded: form_helper
INFO - 2023-07-29 19:01:13 --> Helper loaded: my_helper
INFO - 2023-07-29 19:01:13 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:01:13 --> Controller Class Initialized
INFO - 2023-07-29 19:01:13 --> Config Class Initialized
INFO - 2023-07-29 19:01:13 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:01:13 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:01:13 --> Utf8 Class Initialized
INFO - 2023-07-29 19:01:13 --> URI Class Initialized
INFO - 2023-07-29 19:01:13 --> Router Class Initialized
INFO - 2023-07-29 19:01:13 --> Output Class Initialized
INFO - 2023-07-29 19:01:13 --> Security Class Initialized
DEBUG - 2023-07-29 19:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:01:13 --> Input Class Initialized
INFO - 2023-07-29 19:01:13 --> Language Class Initialized
INFO - 2023-07-29 19:01:13 --> Language Class Initialized
INFO - 2023-07-29 19:01:13 --> Config Class Initialized
INFO - 2023-07-29 19:01:13 --> Loader Class Initialized
INFO - 2023-07-29 19:01:13 --> Helper loaded: url_helper
INFO - 2023-07-29 19:01:13 --> Helper loaded: file_helper
INFO - 2023-07-29 19:01:13 --> Helper loaded: form_helper
INFO - 2023-07-29 19:01:13 --> Helper loaded: my_helper
INFO - 2023-07-29 19:01:14 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:01:14 --> Controller Class Initialized
DEBUG - 2023-07-29 19:01:14 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_kelas/views/list.php
DEBUG - 2023-07-29 19:01:14 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 19:01:14 --> Final output sent to browser
DEBUG - 2023-07-29 19:01:14 --> Total execution time: 0.0364
INFO - 2023-07-29 19:01:14 --> Config Class Initialized
INFO - 2023-07-29 19:01:14 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:01:14 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:01:14 --> Utf8 Class Initialized
INFO - 2023-07-29 19:01:14 --> URI Class Initialized
INFO - 2023-07-29 19:01:14 --> Router Class Initialized
INFO - 2023-07-29 19:01:14 --> Output Class Initialized
INFO - 2023-07-29 19:01:14 --> Security Class Initialized
DEBUG - 2023-07-29 19:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:01:14 --> Input Class Initialized
INFO - 2023-07-29 19:01:14 --> Language Class Initialized
INFO - 2023-07-29 19:01:14 --> Language Class Initialized
INFO - 2023-07-29 19:01:14 --> Config Class Initialized
INFO - 2023-07-29 19:01:14 --> Loader Class Initialized
INFO - 2023-07-29 19:01:14 --> Helper loaded: url_helper
INFO - 2023-07-29 19:01:14 --> Helper loaded: file_helper
INFO - 2023-07-29 19:01:14 --> Helper loaded: form_helper
INFO - 2023-07-29 19:01:14 --> Helper loaded: my_helper
INFO - 2023-07-29 19:01:14 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:01:14 --> Controller Class Initialized
INFO - 2023-07-29 19:01:15 --> Config Class Initialized
INFO - 2023-07-29 19:01:15 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:01:15 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:01:15 --> Utf8 Class Initialized
INFO - 2023-07-29 19:01:15 --> URI Class Initialized
INFO - 2023-07-29 19:01:15 --> Router Class Initialized
INFO - 2023-07-29 19:01:15 --> Output Class Initialized
INFO - 2023-07-29 19:01:15 --> Security Class Initialized
DEBUG - 2023-07-29 19:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:01:15 --> Input Class Initialized
INFO - 2023-07-29 19:01:15 --> Language Class Initialized
INFO - 2023-07-29 19:01:15 --> Language Class Initialized
INFO - 2023-07-29 19:01:15 --> Config Class Initialized
INFO - 2023-07-29 19:01:15 --> Loader Class Initialized
INFO - 2023-07-29 19:01:15 --> Helper loaded: url_helper
INFO - 2023-07-29 19:01:15 --> Helper loaded: file_helper
INFO - 2023-07-29 19:01:15 --> Helper loaded: form_helper
INFO - 2023-07-29 19:01:15 --> Helper loaded: my_helper
INFO - 2023-07-29 19:01:15 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:01:15 --> Controller Class Initialized
DEBUG - 2023-07-29 19:01:15 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_mapel/views/list.php
DEBUG - 2023-07-29 19:01:15 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 19:01:15 --> Final output sent to browser
DEBUG - 2023-07-29 19:01:15 --> Total execution time: 0.0467
INFO - 2023-07-29 19:01:15 --> Config Class Initialized
INFO - 2023-07-29 19:01:15 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:01:15 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:01:15 --> Utf8 Class Initialized
INFO - 2023-07-29 19:01:15 --> URI Class Initialized
INFO - 2023-07-29 19:01:15 --> Router Class Initialized
INFO - 2023-07-29 19:01:15 --> Output Class Initialized
INFO - 2023-07-29 19:01:15 --> Security Class Initialized
DEBUG - 2023-07-29 19:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:01:15 --> Input Class Initialized
INFO - 2023-07-29 19:01:15 --> Language Class Initialized
INFO - 2023-07-29 19:01:15 --> Language Class Initialized
INFO - 2023-07-29 19:01:15 --> Config Class Initialized
INFO - 2023-07-29 19:01:15 --> Loader Class Initialized
INFO - 2023-07-29 19:01:15 --> Helper loaded: url_helper
INFO - 2023-07-29 19:01:15 --> Helper loaded: file_helper
INFO - 2023-07-29 19:01:15 --> Helper loaded: form_helper
INFO - 2023-07-29 19:01:15 --> Helper loaded: my_helper
INFO - 2023-07-29 19:01:15 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:01:15 --> Controller Class Initialized
INFO - 2023-07-29 19:01:19 --> Config Class Initialized
INFO - 2023-07-29 19:01:19 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:01:19 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:01:19 --> Utf8 Class Initialized
INFO - 2023-07-29 19:01:19 --> URI Class Initialized
INFO - 2023-07-29 19:01:19 --> Router Class Initialized
INFO - 2023-07-29 19:01:19 --> Output Class Initialized
INFO - 2023-07-29 19:01:19 --> Security Class Initialized
DEBUG - 2023-07-29 19:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:01:19 --> Input Class Initialized
INFO - 2023-07-29 19:01:19 --> Language Class Initialized
INFO - 2023-07-29 19:01:19 --> Language Class Initialized
INFO - 2023-07-29 19:01:19 --> Config Class Initialized
INFO - 2023-07-29 19:01:19 --> Loader Class Initialized
INFO - 2023-07-29 19:01:19 --> Helper loaded: url_helper
INFO - 2023-07-29 19:01:19 --> Helper loaded: file_helper
INFO - 2023-07-29 19:01:19 --> Helper loaded: form_helper
INFO - 2023-07-29 19:01:19 --> Helper loaded: my_helper
INFO - 2023-07-29 19:01:19 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:01:19 --> Controller Class Initialized
DEBUG - 2023-07-29 19:01:19 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_ekstra/views/list.php
DEBUG - 2023-07-29 19:01:19 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 19:01:19 --> Final output sent to browser
DEBUG - 2023-07-29 19:01:19 --> Total execution time: 0.0377
INFO - 2023-07-29 19:01:19 --> Config Class Initialized
INFO - 2023-07-29 19:01:19 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:01:19 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:01:19 --> Utf8 Class Initialized
INFO - 2023-07-29 19:01:19 --> URI Class Initialized
INFO - 2023-07-29 19:01:19 --> Router Class Initialized
INFO - 2023-07-29 19:01:19 --> Output Class Initialized
INFO - 2023-07-29 19:01:19 --> Security Class Initialized
DEBUG - 2023-07-29 19:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:01:19 --> Input Class Initialized
INFO - 2023-07-29 19:01:19 --> Language Class Initialized
INFO - 2023-07-29 19:01:19 --> Language Class Initialized
INFO - 2023-07-29 19:01:19 --> Config Class Initialized
INFO - 2023-07-29 19:01:19 --> Loader Class Initialized
INFO - 2023-07-29 19:01:19 --> Helper loaded: url_helper
INFO - 2023-07-29 19:01:19 --> Helper loaded: file_helper
INFO - 2023-07-29 19:01:19 --> Helper loaded: form_helper
INFO - 2023-07-29 19:01:19 --> Helper loaded: my_helper
INFO - 2023-07-29 19:01:19 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:01:19 --> Controller Class Initialized
INFO - 2023-07-29 19:01:20 --> Config Class Initialized
INFO - 2023-07-29 19:01:20 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:01:20 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:01:20 --> Utf8 Class Initialized
INFO - 2023-07-29 19:01:20 --> URI Class Initialized
DEBUG - 2023-07-29 19:01:20 --> No URI present. Default controller set.
INFO - 2023-07-29 19:01:20 --> Router Class Initialized
INFO - 2023-07-29 19:01:20 --> Output Class Initialized
INFO - 2023-07-29 19:01:20 --> Security Class Initialized
DEBUG - 2023-07-29 19:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:01:20 --> Input Class Initialized
INFO - 2023-07-29 19:01:20 --> Language Class Initialized
INFO - 2023-07-29 19:01:20 --> Language Class Initialized
INFO - 2023-07-29 19:01:20 --> Config Class Initialized
INFO - 2023-07-29 19:01:20 --> Loader Class Initialized
INFO - 2023-07-29 19:01:20 --> Helper loaded: url_helper
INFO - 2023-07-29 19:01:20 --> Helper loaded: file_helper
INFO - 2023-07-29 19:01:20 --> Helper loaded: form_helper
INFO - 2023-07-29 19:01:20 --> Helper loaded: my_helper
INFO - 2023-07-29 19:01:20 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:01:20 --> Controller Class Initialized
DEBUG - 2023-07-29 19:01:20 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 19:01:20 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 19:01:20 --> Final output sent to browser
DEBUG - 2023-07-29 19:01:20 --> Total execution time: 0.0395
INFO - 2023-07-29 19:03:57 --> Config Class Initialized
INFO - 2023-07-29 19:03:57 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:03:57 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:03:57 --> Utf8 Class Initialized
INFO - 2023-07-29 19:03:57 --> URI Class Initialized
DEBUG - 2023-07-29 19:03:57 --> No URI present. Default controller set.
INFO - 2023-07-29 19:03:57 --> Router Class Initialized
INFO - 2023-07-29 19:03:57 --> Output Class Initialized
INFO - 2023-07-29 19:03:57 --> Security Class Initialized
DEBUG - 2023-07-29 19:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:03:57 --> Input Class Initialized
INFO - 2023-07-29 19:03:57 --> Language Class Initialized
INFO - 2023-07-29 19:03:57 --> Language Class Initialized
INFO - 2023-07-29 19:03:57 --> Config Class Initialized
INFO - 2023-07-29 19:03:57 --> Loader Class Initialized
INFO - 2023-07-29 19:03:57 --> Helper loaded: url_helper
INFO - 2023-07-29 19:03:57 --> Helper loaded: file_helper
INFO - 2023-07-29 19:03:57 --> Helper loaded: form_helper
INFO - 2023-07-29 19:03:57 --> Helper loaded: my_helper
INFO - 2023-07-29 19:03:57 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:03:57 --> Controller Class Initialized
DEBUG - 2023-07-29 19:03:57 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 19:03:57 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 19:03:57 --> Final output sent to browser
DEBUG - 2023-07-29 19:03:57 --> Total execution time: 0.0428
INFO - 2023-07-29 19:06:00 --> Config Class Initialized
INFO - 2023-07-29 19:06:00 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:06:00 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:06:00 --> Utf8 Class Initialized
INFO - 2023-07-29 19:06:00 --> URI Class Initialized
DEBUG - 2023-07-29 19:06:00 --> No URI present. Default controller set.
INFO - 2023-07-29 19:06:00 --> Router Class Initialized
INFO - 2023-07-29 19:06:00 --> Output Class Initialized
INFO - 2023-07-29 19:06:00 --> Security Class Initialized
DEBUG - 2023-07-29 19:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:06:00 --> Input Class Initialized
INFO - 2023-07-29 19:06:00 --> Language Class Initialized
INFO - 2023-07-29 19:06:00 --> Language Class Initialized
INFO - 2023-07-29 19:06:00 --> Config Class Initialized
INFO - 2023-07-29 19:06:00 --> Loader Class Initialized
INFO - 2023-07-29 19:06:00 --> Helper loaded: url_helper
INFO - 2023-07-29 19:06:00 --> Helper loaded: file_helper
INFO - 2023-07-29 19:06:00 --> Helper loaded: form_helper
INFO - 2023-07-29 19:06:00 --> Helper loaded: my_helper
INFO - 2023-07-29 19:06:00 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:06:00 --> Controller Class Initialized
DEBUG - 2023-07-29 19:06:00 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 19:06:00 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 19:06:00 --> Final output sent to browser
DEBUG - 2023-07-29 19:06:00 --> Total execution time: 0.0429
INFO - 2023-07-29 19:06:01 --> Config Class Initialized
INFO - 2023-07-29 19:06:01 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:06:01 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:06:01 --> Utf8 Class Initialized
INFO - 2023-07-29 19:06:01 --> URI Class Initialized
INFO - 2023-07-29 19:06:01 --> Router Class Initialized
INFO - 2023-07-29 19:06:01 --> Output Class Initialized
INFO - 2023-07-29 19:06:01 --> Security Class Initialized
DEBUG - 2023-07-29 19:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:06:01 --> Input Class Initialized
INFO - 2023-07-29 19:06:01 --> Language Class Initialized
INFO - 2023-07-29 19:06:01 --> Language Class Initialized
INFO - 2023-07-29 19:06:01 --> Config Class Initialized
INFO - 2023-07-29 19:06:01 --> Loader Class Initialized
INFO - 2023-07-29 19:06:01 --> Helper loaded: url_helper
INFO - 2023-07-29 19:06:01 --> Helper loaded: file_helper
INFO - 2023-07-29 19:06:01 --> Helper loaded: form_helper
INFO - 2023-07-29 19:06:01 --> Helper loaded: my_helper
INFO - 2023-07-29 19:06:01 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:06:01 --> Controller Class Initialized
DEBUG - 2023-07-29 19:06:01 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_guru/views/list.php
DEBUG - 2023-07-29 19:06:01 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 19:06:01 --> Final output sent to browser
DEBUG - 2023-07-29 19:06:01 --> Total execution time: 0.0552
INFO - 2023-07-29 19:06:01 --> Config Class Initialized
INFO - 2023-07-29 19:06:01 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:06:01 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:06:01 --> Utf8 Class Initialized
INFO - 2023-07-29 19:06:01 --> URI Class Initialized
INFO - 2023-07-29 19:06:01 --> Router Class Initialized
INFO - 2023-07-29 19:06:01 --> Output Class Initialized
INFO - 2023-07-29 19:06:01 --> Security Class Initialized
DEBUG - 2023-07-29 19:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:06:01 --> Input Class Initialized
INFO - 2023-07-29 19:06:01 --> Language Class Initialized
INFO - 2023-07-29 19:06:01 --> Language Class Initialized
INFO - 2023-07-29 19:06:01 --> Config Class Initialized
INFO - 2023-07-29 19:06:01 --> Loader Class Initialized
INFO - 2023-07-29 19:06:01 --> Helper loaded: url_helper
INFO - 2023-07-29 19:06:01 --> Helper loaded: file_helper
INFO - 2023-07-29 19:06:01 --> Helper loaded: form_helper
INFO - 2023-07-29 19:06:01 --> Helper loaded: my_helper
INFO - 2023-07-29 19:06:01 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:06:01 --> Controller Class Initialized
INFO - 2023-07-29 19:06:02 --> Config Class Initialized
INFO - 2023-07-29 19:06:02 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:06:02 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:06:02 --> Utf8 Class Initialized
INFO - 2023-07-29 19:06:02 --> URI Class Initialized
INFO - 2023-07-29 19:06:02 --> Router Class Initialized
INFO - 2023-07-29 19:06:02 --> Output Class Initialized
INFO - 2023-07-29 19:06:02 --> Security Class Initialized
DEBUG - 2023-07-29 19:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:06:02 --> Input Class Initialized
INFO - 2023-07-29 19:06:02 --> Language Class Initialized
INFO - 2023-07-29 19:06:02 --> Language Class Initialized
INFO - 2023-07-29 19:06:02 --> Config Class Initialized
INFO - 2023-07-29 19:06:02 --> Loader Class Initialized
INFO - 2023-07-29 19:06:02 --> Helper loaded: url_helper
INFO - 2023-07-29 19:06:02 --> Helper loaded: file_helper
INFO - 2023-07-29 19:06:02 --> Helper loaded: form_helper
INFO - 2023-07-29 19:06:02 --> Helper loaded: my_helper
INFO - 2023-07-29 19:06:02 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:06:02 --> Controller Class Initialized
DEBUG - 2023-07-29 19:06:02 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-29 19:06:02 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 19:06:02 --> Final output sent to browser
DEBUG - 2023-07-29 19:06:02 --> Total execution time: 0.0541
INFO - 2023-07-29 19:06:02 --> Config Class Initialized
INFO - 2023-07-29 19:06:02 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:06:02 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:06:02 --> Utf8 Class Initialized
INFO - 2023-07-29 19:06:02 --> URI Class Initialized
INFO - 2023-07-29 19:06:02 --> Router Class Initialized
INFO - 2023-07-29 19:06:02 --> Output Class Initialized
INFO - 2023-07-29 19:06:02 --> Security Class Initialized
DEBUG - 2023-07-29 19:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:06:02 --> Input Class Initialized
INFO - 2023-07-29 19:06:02 --> Language Class Initialized
INFO - 2023-07-29 19:06:02 --> Language Class Initialized
INFO - 2023-07-29 19:06:02 --> Config Class Initialized
INFO - 2023-07-29 19:06:02 --> Loader Class Initialized
INFO - 2023-07-29 19:06:02 --> Helper loaded: url_helper
INFO - 2023-07-29 19:06:02 --> Helper loaded: file_helper
INFO - 2023-07-29 19:06:02 --> Helper loaded: form_helper
INFO - 2023-07-29 19:06:02 --> Helper loaded: my_helper
INFO - 2023-07-29 19:06:02 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:06:02 --> Controller Class Initialized
INFO - 2023-07-29 19:06:03 --> Config Class Initialized
INFO - 2023-07-29 19:06:03 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:06:03 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:06:03 --> Utf8 Class Initialized
INFO - 2023-07-29 19:06:03 --> URI Class Initialized
INFO - 2023-07-29 19:06:03 --> Router Class Initialized
INFO - 2023-07-29 19:06:03 --> Output Class Initialized
INFO - 2023-07-29 19:06:03 --> Security Class Initialized
DEBUG - 2023-07-29 19:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:06:03 --> Input Class Initialized
INFO - 2023-07-29 19:06:03 --> Language Class Initialized
INFO - 2023-07-29 19:06:03 --> Language Class Initialized
INFO - 2023-07-29 19:06:03 --> Config Class Initialized
INFO - 2023-07-29 19:06:03 --> Loader Class Initialized
INFO - 2023-07-29 19:06:03 --> Helper loaded: url_helper
INFO - 2023-07-29 19:06:03 --> Helper loaded: file_helper
INFO - 2023-07-29 19:06:03 --> Helper loaded: form_helper
INFO - 2023-07-29 19:06:03 --> Helper loaded: my_helper
INFO - 2023-07-29 19:06:03 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:06:03 --> Controller Class Initialized
DEBUG - 2023-07-29 19:06:03 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_kelas/views/list.php
DEBUG - 2023-07-29 19:06:03 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 19:06:03 --> Final output sent to browser
DEBUG - 2023-07-29 19:06:03 --> Total execution time: 0.0367
INFO - 2023-07-29 19:06:04 --> Config Class Initialized
INFO - 2023-07-29 19:06:04 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:06:04 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:06:04 --> Utf8 Class Initialized
INFO - 2023-07-29 19:06:04 --> URI Class Initialized
INFO - 2023-07-29 19:06:04 --> Router Class Initialized
INFO - 2023-07-29 19:06:04 --> Output Class Initialized
INFO - 2023-07-29 19:06:04 --> Security Class Initialized
DEBUG - 2023-07-29 19:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:06:04 --> Input Class Initialized
INFO - 2023-07-29 19:06:04 --> Language Class Initialized
INFO - 2023-07-29 19:06:04 --> Language Class Initialized
INFO - 2023-07-29 19:06:04 --> Config Class Initialized
INFO - 2023-07-29 19:06:04 --> Loader Class Initialized
INFO - 2023-07-29 19:06:04 --> Helper loaded: url_helper
INFO - 2023-07-29 19:06:04 --> Helper loaded: file_helper
INFO - 2023-07-29 19:06:04 --> Helper loaded: form_helper
INFO - 2023-07-29 19:06:04 --> Helper loaded: my_helper
INFO - 2023-07-29 19:06:04 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:06:04 --> Controller Class Initialized
INFO - 2023-07-29 19:06:04 --> Config Class Initialized
INFO - 2023-07-29 19:06:04 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:06:04 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:06:04 --> Utf8 Class Initialized
INFO - 2023-07-29 19:06:04 --> URI Class Initialized
INFO - 2023-07-29 19:06:04 --> Router Class Initialized
INFO - 2023-07-29 19:06:04 --> Output Class Initialized
INFO - 2023-07-29 19:06:04 --> Security Class Initialized
DEBUG - 2023-07-29 19:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:06:04 --> Input Class Initialized
INFO - 2023-07-29 19:06:04 --> Language Class Initialized
INFO - 2023-07-29 19:06:04 --> Language Class Initialized
INFO - 2023-07-29 19:06:04 --> Config Class Initialized
INFO - 2023-07-29 19:06:04 --> Loader Class Initialized
INFO - 2023-07-29 19:06:04 --> Helper loaded: url_helper
INFO - 2023-07-29 19:06:04 --> Helper loaded: file_helper
INFO - 2023-07-29 19:06:04 --> Helper loaded: form_helper
INFO - 2023-07-29 19:06:04 --> Helper loaded: my_helper
INFO - 2023-07-29 19:06:04 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:06:04 --> Controller Class Initialized
DEBUG - 2023-07-29 19:06:04 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_mapel/views/list.php
DEBUG - 2023-07-29 19:06:04 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 19:06:04 --> Final output sent to browser
DEBUG - 2023-07-29 19:06:04 --> Total execution time: 0.0454
INFO - 2023-07-29 19:06:05 --> Config Class Initialized
INFO - 2023-07-29 19:06:05 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:06:05 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:06:05 --> Utf8 Class Initialized
INFO - 2023-07-29 19:06:05 --> URI Class Initialized
INFO - 2023-07-29 19:06:05 --> Router Class Initialized
INFO - 2023-07-29 19:06:05 --> Output Class Initialized
INFO - 2023-07-29 19:06:05 --> Security Class Initialized
DEBUG - 2023-07-29 19:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:06:05 --> Input Class Initialized
INFO - 2023-07-29 19:06:05 --> Language Class Initialized
INFO - 2023-07-29 19:06:05 --> Language Class Initialized
INFO - 2023-07-29 19:06:05 --> Config Class Initialized
INFO - 2023-07-29 19:06:05 --> Loader Class Initialized
INFO - 2023-07-29 19:06:05 --> Helper loaded: url_helper
INFO - 2023-07-29 19:06:05 --> Helper loaded: file_helper
INFO - 2023-07-29 19:06:05 --> Helper loaded: form_helper
INFO - 2023-07-29 19:06:05 --> Helper loaded: my_helper
INFO - 2023-07-29 19:06:05 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:06:05 --> Controller Class Initialized
INFO - 2023-07-29 19:06:06 --> Config Class Initialized
INFO - 2023-07-29 19:06:06 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:06:06 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:06:06 --> Utf8 Class Initialized
INFO - 2023-07-29 19:06:06 --> URI Class Initialized
INFO - 2023-07-29 19:06:06 --> Router Class Initialized
INFO - 2023-07-29 19:06:06 --> Output Class Initialized
INFO - 2023-07-29 19:06:06 --> Security Class Initialized
DEBUG - 2023-07-29 19:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:06:06 --> Input Class Initialized
INFO - 2023-07-29 19:06:06 --> Language Class Initialized
INFO - 2023-07-29 19:06:06 --> Language Class Initialized
INFO - 2023-07-29 19:06:06 --> Config Class Initialized
INFO - 2023-07-29 19:06:06 --> Loader Class Initialized
INFO - 2023-07-29 19:06:06 --> Helper loaded: url_helper
INFO - 2023-07-29 19:06:06 --> Helper loaded: file_helper
INFO - 2023-07-29 19:06:06 --> Helper loaded: form_helper
INFO - 2023-07-29 19:06:06 --> Helper loaded: my_helper
INFO - 2023-07-29 19:06:06 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:06:06 --> Controller Class Initialized
DEBUG - 2023-07-29 19:06:06 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_kelas/views/list.php
DEBUG - 2023-07-29 19:06:06 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 19:06:06 --> Final output sent to browser
DEBUG - 2023-07-29 19:06:06 --> Total execution time: 0.0590
INFO - 2023-07-29 19:06:06 --> Config Class Initialized
INFO - 2023-07-29 19:06:06 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:06:06 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:06:06 --> Utf8 Class Initialized
INFO - 2023-07-29 19:06:06 --> URI Class Initialized
INFO - 2023-07-29 19:06:06 --> Router Class Initialized
INFO - 2023-07-29 19:06:06 --> Output Class Initialized
INFO - 2023-07-29 19:06:06 --> Security Class Initialized
DEBUG - 2023-07-29 19:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:06:06 --> Input Class Initialized
INFO - 2023-07-29 19:06:06 --> Language Class Initialized
INFO - 2023-07-29 19:06:06 --> Language Class Initialized
INFO - 2023-07-29 19:06:06 --> Config Class Initialized
INFO - 2023-07-29 19:06:06 --> Loader Class Initialized
INFO - 2023-07-29 19:06:06 --> Helper loaded: url_helper
INFO - 2023-07-29 19:06:06 --> Helper loaded: file_helper
INFO - 2023-07-29 19:06:06 --> Helper loaded: form_helper
INFO - 2023-07-29 19:06:06 --> Helper loaded: my_helper
INFO - 2023-07-29 19:06:06 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:06:06 --> Controller Class Initialized
INFO - 2023-07-29 19:06:08 --> Config Class Initialized
INFO - 2023-07-29 19:06:08 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:06:08 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:06:08 --> Utf8 Class Initialized
INFO - 2023-07-29 19:06:08 --> URI Class Initialized
INFO - 2023-07-29 19:06:08 --> Router Class Initialized
INFO - 2023-07-29 19:06:08 --> Output Class Initialized
INFO - 2023-07-29 19:06:08 --> Security Class Initialized
DEBUG - 2023-07-29 19:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:06:08 --> Input Class Initialized
INFO - 2023-07-29 19:06:08 --> Language Class Initialized
INFO - 2023-07-29 19:06:08 --> Language Class Initialized
INFO - 2023-07-29 19:06:08 --> Config Class Initialized
INFO - 2023-07-29 19:06:08 --> Loader Class Initialized
INFO - 2023-07-29 19:06:08 --> Helper loaded: url_helper
INFO - 2023-07-29 19:06:08 --> Helper loaded: file_helper
INFO - 2023-07-29 19:06:08 --> Helper loaded: form_helper
INFO - 2023-07-29 19:06:08 --> Helper loaded: my_helper
INFO - 2023-07-29 19:06:08 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:06:08 --> Controller Class Initialized
INFO - 2023-07-29 19:06:12 --> Config Class Initialized
INFO - 2023-07-29 19:06:12 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:06:12 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:06:12 --> Utf8 Class Initialized
INFO - 2023-07-29 19:06:12 --> URI Class Initialized
INFO - 2023-07-29 19:06:12 --> Router Class Initialized
INFO - 2023-07-29 19:06:12 --> Output Class Initialized
INFO - 2023-07-29 19:06:12 --> Security Class Initialized
DEBUG - 2023-07-29 19:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:06:12 --> Input Class Initialized
INFO - 2023-07-29 19:06:12 --> Language Class Initialized
INFO - 2023-07-29 19:06:12 --> Language Class Initialized
INFO - 2023-07-29 19:06:12 --> Config Class Initialized
INFO - 2023-07-29 19:06:12 --> Loader Class Initialized
INFO - 2023-07-29 19:06:12 --> Helper loaded: url_helper
INFO - 2023-07-29 19:06:12 --> Helper loaded: file_helper
INFO - 2023-07-29 19:06:12 --> Helper loaded: form_helper
INFO - 2023-07-29 19:06:12 --> Helper loaded: my_helper
INFO - 2023-07-29 19:06:12 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:06:12 --> Controller Class Initialized
DEBUG - 2023-07-29 19:06:12 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_mapel/views/list.php
DEBUG - 2023-07-29 19:06:12 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 19:06:12 --> Final output sent to browser
DEBUG - 2023-07-29 19:06:12 --> Total execution time: 0.0361
INFO - 2023-07-29 19:06:12 --> Config Class Initialized
INFO - 2023-07-29 19:06:12 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:06:12 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:06:12 --> Utf8 Class Initialized
INFO - 2023-07-29 19:06:12 --> URI Class Initialized
INFO - 2023-07-29 19:06:12 --> Router Class Initialized
INFO - 2023-07-29 19:06:12 --> Output Class Initialized
INFO - 2023-07-29 19:06:12 --> Security Class Initialized
DEBUG - 2023-07-29 19:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:06:12 --> Input Class Initialized
INFO - 2023-07-29 19:06:12 --> Language Class Initialized
INFO - 2023-07-29 19:06:12 --> Language Class Initialized
INFO - 2023-07-29 19:06:12 --> Config Class Initialized
INFO - 2023-07-29 19:06:12 --> Loader Class Initialized
INFO - 2023-07-29 19:06:12 --> Helper loaded: url_helper
INFO - 2023-07-29 19:06:12 --> Helper loaded: file_helper
INFO - 2023-07-29 19:06:12 --> Helper loaded: form_helper
INFO - 2023-07-29 19:06:12 --> Helper loaded: my_helper
INFO - 2023-07-29 19:06:12 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:06:12 --> Controller Class Initialized
INFO - 2023-07-29 19:06:15 --> Config Class Initialized
INFO - 2023-07-29 19:06:15 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:06:15 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:06:15 --> Utf8 Class Initialized
INFO - 2023-07-29 19:06:15 --> URI Class Initialized
INFO - 2023-07-29 19:06:15 --> Router Class Initialized
INFO - 2023-07-29 19:06:15 --> Output Class Initialized
INFO - 2023-07-29 19:06:15 --> Security Class Initialized
DEBUG - 2023-07-29 19:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:06:15 --> Input Class Initialized
INFO - 2023-07-29 19:06:15 --> Language Class Initialized
INFO - 2023-07-29 19:06:15 --> Language Class Initialized
INFO - 2023-07-29 19:06:15 --> Config Class Initialized
INFO - 2023-07-29 19:06:15 --> Loader Class Initialized
INFO - 2023-07-29 19:06:15 --> Helper loaded: url_helper
INFO - 2023-07-29 19:06:15 --> Helper loaded: file_helper
INFO - 2023-07-29 19:06:15 --> Helper loaded: form_helper
INFO - 2023-07-29 19:06:15 --> Helper loaded: my_helper
INFO - 2023-07-29 19:06:15 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:06:15 --> Controller Class Initialized
INFO - 2023-07-29 19:06:18 --> Config Class Initialized
INFO - 2023-07-29 19:06:18 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:06:18 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:06:18 --> Utf8 Class Initialized
INFO - 2023-07-29 19:06:18 --> URI Class Initialized
INFO - 2023-07-29 19:06:18 --> Router Class Initialized
INFO - 2023-07-29 19:06:18 --> Output Class Initialized
INFO - 2023-07-29 19:06:18 --> Security Class Initialized
DEBUG - 2023-07-29 19:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:06:18 --> Input Class Initialized
INFO - 2023-07-29 19:06:18 --> Language Class Initialized
INFO - 2023-07-29 19:06:18 --> Language Class Initialized
INFO - 2023-07-29 19:06:18 --> Config Class Initialized
INFO - 2023-07-29 19:06:18 --> Loader Class Initialized
INFO - 2023-07-29 19:06:18 --> Helper loaded: url_helper
INFO - 2023-07-29 19:06:18 --> Helper loaded: file_helper
INFO - 2023-07-29 19:06:18 --> Helper loaded: form_helper
INFO - 2023-07-29 19:06:18 --> Helper loaded: my_helper
INFO - 2023-07-29 19:06:18 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:06:18 --> Controller Class Initialized
DEBUG - 2023-07-29 19:06:18 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_ekstra/views/list.php
DEBUG - 2023-07-29 19:06:18 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 19:06:18 --> Final output sent to browser
DEBUG - 2023-07-29 19:06:18 --> Total execution time: 0.0461
INFO - 2023-07-29 19:06:18 --> Config Class Initialized
INFO - 2023-07-29 19:06:18 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:06:18 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:06:18 --> Utf8 Class Initialized
INFO - 2023-07-29 19:06:18 --> URI Class Initialized
INFO - 2023-07-29 19:06:18 --> Router Class Initialized
INFO - 2023-07-29 19:06:18 --> Output Class Initialized
INFO - 2023-07-29 19:06:18 --> Security Class Initialized
DEBUG - 2023-07-29 19:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:06:18 --> Input Class Initialized
INFO - 2023-07-29 19:06:18 --> Language Class Initialized
INFO - 2023-07-29 19:06:18 --> Language Class Initialized
INFO - 2023-07-29 19:06:18 --> Config Class Initialized
INFO - 2023-07-29 19:06:18 --> Loader Class Initialized
INFO - 2023-07-29 19:06:18 --> Helper loaded: url_helper
INFO - 2023-07-29 19:06:18 --> Helper loaded: file_helper
INFO - 2023-07-29 19:06:18 --> Helper loaded: form_helper
INFO - 2023-07-29 19:06:18 --> Helper loaded: my_helper
INFO - 2023-07-29 19:06:18 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:06:18 --> Controller Class Initialized
INFO - 2023-07-29 19:06:20 --> Config Class Initialized
INFO - 2023-07-29 19:06:20 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:06:20 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:06:20 --> Utf8 Class Initialized
INFO - 2023-07-29 19:06:20 --> URI Class Initialized
INFO - 2023-07-29 19:06:20 --> Router Class Initialized
INFO - 2023-07-29 19:06:20 --> Output Class Initialized
INFO - 2023-07-29 19:06:20 --> Security Class Initialized
DEBUG - 2023-07-29 19:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:06:20 --> Input Class Initialized
INFO - 2023-07-29 19:06:20 --> Language Class Initialized
INFO - 2023-07-29 19:06:20 --> Language Class Initialized
INFO - 2023-07-29 19:06:20 --> Config Class Initialized
INFO - 2023-07-29 19:06:20 --> Loader Class Initialized
INFO - 2023-07-29 19:06:20 --> Helper loaded: url_helper
INFO - 2023-07-29 19:06:20 --> Helper loaded: file_helper
INFO - 2023-07-29 19:06:20 --> Helper loaded: form_helper
INFO - 2023-07-29 19:06:20 --> Helper loaded: my_helper
INFO - 2023-07-29 19:06:20 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:06:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:06:20 --> Controller Class Initialized
INFO - 2023-07-29 19:06:44 --> Config Class Initialized
INFO - 2023-07-29 19:06:44 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:06:44 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:06:44 --> Utf8 Class Initialized
INFO - 2023-07-29 19:06:44 --> URI Class Initialized
DEBUG - 2023-07-29 19:06:44 --> No URI present. Default controller set.
INFO - 2023-07-29 19:06:44 --> Router Class Initialized
INFO - 2023-07-29 19:06:44 --> Output Class Initialized
INFO - 2023-07-29 19:06:44 --> Security Class Initialized
DEBUG - 2023-07-29 19:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:06:44 --> Input Class Initialized
INFO - 2023-07-29 19:06:44 --> Language Class Initialized
INFO - 2023-07-29 19:06:44 --> Language Class Initialized
INFO - 2023-07-29 19:06:44 --> Config Class Initialized
INFO - 2023-07-29 19:06:44 --> Loader Class Initialized
INFO - 2023-07-29 19:06:44 --> Helper loaded: url_helper
INFO - 2023-07-29 19:06:44 --> Helper loaded: file_helper
INFO - 2023-07-29 19:06:44 --> Helper loaded: form_helper
INFO - 2023-07-29 19:06:44 --> Helper loaded: my_helper
INFO - 2023-07-29 19:06:44 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:06:44 --> Controller Class Initialized
DEBUG - 2023-07-29 19:06:44 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 19:06:44 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 19:06:44 --> Final output sent to browser
DEBUG - 2023-07-29 19:06:44 --> Total execution time: 0.0591
INFO - 2023-07-29 19:06:52 --> Config Class Initialized
INFO - 2023-07-29 19:06:52 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:06:52 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:06:52 --> Utf8 Class Initialized
INFO - 2023-07-29 19:06:52 --> URI Class Initialized
INFO - 2023-07-29 19:06:52 --> Router Class Initialized
INFO - 2023-07-29 19:06:52 --> Output Class Initialized
INFO - 2023-07-29 19:06:52 --> Security Class Initialized
DEBUG - 2023-07-29 19:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:06:52 --> Input Class Initialized
INFO - 2023-07-29 19:06:52 --> Language Class Initialized
INFO - 2023-07-29 19:06:52 --> Language Class Initialized
INFO - 2023-07-29 19:06:52 --> Config Class Initialized
INFO - 2023-07-29 19:06:52 --> Loader Class Initialized
INFO - 2023-07-29 19:06:52 --> Helper loaded: url_helper
INFO - 2023-07-29 19:06:52 --> Helper loaded: file_helper
INFO - 2023-07-29 19:06:52 --> Helper loaded: form_helper
INFO - 2023-07-29 19:06:52 --> Helper loaded: my_helper
INFO - 2023-07-29 19:06:52 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:06:52 --> Controller Class Initialized
DEBUG - 2023-07-29 19:06:52 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_guru/views/list.php
DEBUG - 2023-07-29 19:06:52 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 19:06:52 --> Final output sent to browser
DEBUG - 2023-07-29 19:06:52 --> Total execution time: 0.0385
INFO - 2023-07-29 19:06:52 --> Config Class Initialized
INFO - 2023-07-29 19:06:52 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:06:52 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:06:52 --> Utf8 Class Initialized
INFO - 2023-07-29 19:06:52 --> URI Class Initialized
INFO - 2023-07-29 19:06:52 --> Router Class Initialized
INFO - 2023-07-29 19:06:52 --> Output Class Initialized
INFO - 2023-07-29 19:06:52 --> Security Class Initialized
DEBUG - 2023-07-29 19:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:06:52 --> Input Class Initialized
INFO - 2023-07-29 19:06:52 --> Language Class Initialized
INFO - 2023-07-29 19:06:52 --> Language Class Initialized
INFO - 2023-07-29 19:06:52 --> Config Class Initialized
INFO - 2023-07-29 19:06:52 --> Loader Class Initialized
INFO - 2023-07-29 19:06:52 --> Helper loaded: url_helper
INFO - 2023-07-29 19:06:52 --> Helper loaded: file_helper
INFO - 2023-07-29 19:06:52 --> Helper loaded: form_helper
INFO - 2023-07-29 19:06:52 --> Helper loaded: my_helper
INFO - 2023-07-29 19:06:52 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:06:52 --> Controller Class Initialized
INFO - 2023-07-29 19:06:53 --> Config Class Initialized
INFO - 2023-07-29 19:06:53 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:06:53 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:06:53 --> Utf8 Class Initialized
INFO - 2023-07-29 19:06:53 --> URI Class Initialized
INFO - 2023-07-29 19:06:53 --> Router Class Initialized
INFO - 2023-07-29 19:06:53 --> Output Class Initialized
INFO - 2023-07-29 19:06:53 --> Security Class Initialized
DEBUG - 2023-07-29 19:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:06:53 --> Input Class Initialized
INFO - 2023-07-29 19:06:53 --> Language Class Initialized
INFO - 2023-07-29 19:06:53 --> Language Class Initialized
INFO - 2023-07-29 19:06:53 --> Config Class Initialized
INFO - 2023-07-29 19:06:53 --> Loader Class Initialized
INFO - 2023-07-29 19:06:53 --> Helper loaded: url_helper
INFO - 2023-07-29 19:06:53 --> Helper loaded: file_helper
INFO - 2023-07-29 19:06:53 --> Helper loaded: form_helper
INFO - 2023-07-29 19:06:53 --> Helper loaded: my_helper
INFO - 2023-07-29 19:06:53 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:06:53 --> Controller Class Initialized
DEBUG - 2023-07-29 19:06:53 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-29 19:06:53 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 19:06:53 --> Final output sent to browser
DEBUG - 2023-07-29 19:06:53 --> Total execution time: 0.0504
INFO - 2023-07-29 19:06:54 --> Config Class Initialized
INFO - 2023-07-29 19:06:54 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:06:54 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:06:54 --> Utf8 Class Initialized
INFO - 2023-07-29 19:06:54 --> URI Class Initialized
INFO - 2023-07-29 19:06:54 --> Router Class Initialized
INFO - 2023-07-29 19:06:54 --> Output Class Initialized
INFO - 2023-07-29 19:06:54 --> Security Class Initialized
DEBUG - 2023-07-29 19:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:06:54 --> Input Class Initialized
INFO - 2023-07-29 19:06:54 --> Language Class Initialized
INFO - 2023-07-29 19:06:54 --> Language Class Initialized
INFO - 2023-07-29 19:06:54 --> Config Class Initialized
INFO - 2023-07-29 19:06:54 --> Loader Class Initialized
INFO - 2023-07-29 19:06:54 --> Helper loaded: url_helper
INFO - 2023-07-29 19:06:54 --> Helper loaded: file_helper
INFO - 2023-07-29 19:06:54 --> Helper loaded: form_helper
INFO - 2023-07-29 19:06:54 --> Helper loaded: my_helper
INFO - 2023-07-29 19:06:54 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:06:54 --> Controller Class Initialized
INFO - 2023-07-29 19:06:54 --> Config Class Initialized
INFO - 2023-07-29 19:06:54 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:06:54 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:06:54 --> Utf8 Class Initialized
INFO - 2023-07-29 19:06:54 --> URI Class Initialized
INFO - 2023-07-29 19:06:54 --> Router Class Initialized
INFO - 2023-07-29 19:06:54 --> Output Class Initialized
INFO - 2023-07-29 19:06:54 --> Security Class Initialized
DEBUG - 2023-07-29 19:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:06:54 --> Input Class Initialized
INFO - 2023-07-29 19:06:54 --> Language Class Initialized
INFO - 2023-07-29 19:06:54 --> Language Class Initialized
INFO - 2023-07-29 19:06:54 --> Config Class Initialized
INFO - 2023-07-29 19:06:54 --> Loader Class Initialized
INFO - 2023-07-29 19:06:54 --> Helper loaded: url_helper
INFO - 2023-07-29 19:06:54 --> Helper loaded: file_helper
INFO - 2023-07-29 19:06:54 --> Helper loaded: form_helper
INFO - 2023-07-29 19:06:54 --> Helper loaded: my_helper
INFO - 2023-07-29 19:06:54 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:06:54 --> Controller Class Initialized
DEBUG - 2023-07-29 19:06:54 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_kelas/views/list.php
DEBUG - 2023-07-29 19:06:54 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 19:06:54 --> Final output sent to browser
DEBUG - 2023-07-29 19:06:54 --> Total execution time: 0.0362
INFO - 2023-07-29 19:06:54 --> Config Class Initialized
INFO - 2023-07-29 19:06:54 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:06:54 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:06:54 --> Utf8 Class Initialized
INFO - 2023-07-29 19:06:54 --> URI Class Initialized
INFO - 2023-07-29 19:06:54 --> Router Class Initialized
INFO - 2023-07-29 19:06:54 --> Output Class Initialized
INFO - 2023-07-29 19:06:54 --> Security Class Initialized
DEBUG - 2023-07-29 19:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:06:54 --> Input Class Initialized
INFO - 2023-07-29 19:06:54 --> Language Class Initialized
INFO - 2023-07-29 19:06:54 --> Language Class Initialized
INFO - 2023-07-29 19:06:54 --> Config Class Initialized
INFO - 2023-07-29 19:06:54 --> Loader Class Initialized
INFO - 2023-07-29 19:06:54 --> Helper loaded: url_helper
INFO - 2023-07-29 19:06:54 --> Helper loaded: file_helper
INFO - 2023-07-29 19:06:54 --> Helper loaded: form_helper
INFO - 2023-07-29 19:06:54 --> Helper loaded: my_helper
INFO - 2023-07-29 19:06:54 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:06:54 --> Controller Class Initialized
INFO - 2023-07-29 19:06:55 --> Config Class Initialized
INFO - 2023-07-29 19:06:55 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:06:55 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:06:55 --> Utf8 Class Initialized
INFO - 2023-07-29 19:06:55 --> URI Class Initialized
INFO - 2023-07-29 19:06:55 --> Router Class Initialized
INFO - 2023-07-29 19:06:55 --> Output Class Initialized
INFO - 2023-07-29 19:06:55 --> Security Class Initialized
DEBUG - 2023-07-29 19:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:06:55 --> Input Class Initialized
INFO - 2023-07-29 19:06:55 --> Language Class Initialized
INFO - 2023-07-29 19:06:55 --> Language Class Initialized
INFO - 2023-07-29 19:06:55 --> Config Class Initialized
INFO - 2023-07-29 19:06:55 --> Loader Class Initialized
INFO - 2023-07-29 19:06:55 --> Helper loaded: url_helper
INFO - 2023-07-29 19:06:55 --> Helper loaded: file_helper
INFO - 2023-07-29 19:06:55 --> Helper loaded: form_helper
INFO - 2023-07-29 19:06:55 --> Helper loaded: my_helper
INFO - 2023-07-29 19:06:55 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:06:55 --> Controller Class Initialized
DEBUG - 2023-07-29 19:06:55 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_mapel/views/list.php
DEBUG - 2023-07-29 19:06:55 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 19:06:55 --> Final output sent to browser
DEBUG - 2023-07-29 19:06:55 --> Total execution time: 0.0487
INFO - 2023-07-29 19:06:55 --> Config Class Initialized
INFO - 2023-07-29 19:06:55 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:06:55 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:06:55 --> Utf8 Class Initialized
INFO - 2023-07-29 19:06:55 --> URI Class Initialized
INFO - 2023-07-29 19:06:55 --> Router Class Initialized
INFO - 2023-07-29 19:06:55 --> Output Class Initialized
INFO - 2023-07-29 19:06:55 --> Security Class Initialized
DEBUG - 2023-07-29 19:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:06:55 --> Input Class Initialized
INFO - 2023-07-29 19:06:55 --> Language Class Initialized
INFO - 2023-07-29 19:06:55 --> Language Class Initialized
INFO - 2023-07-29 19:06:55 --> Config Class Initialized
INFO - 2023-07-29 19:06:55 --> Loader Class Initialized
INFO - 2023-07-29 19:06:55 --> Helper loaded: url_helper
INFO - 2023-07-29 19:06:55 --> Helper loaded: file_helper
INFO - 2023-07-29 19:06:55 --> Helper loaded: form_helper
INFO - 2023-07-29 19:06:55 --> Helper loaded: my_helper
INFO - 2023-07-29 19:06:55 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:06:55 --> Controller Class Initialized
INFO - 2023-07-29 19:06:58 --> Config Class Initialized
INFO - 2023-07-29 19:06:58 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:06:58 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:06:58 --> Utf8 Class Initialized
INFO - 2023-07-29 19:06:58 --> URI Class Initialized
INFO - 2023-07-29 19:06:58 --> Router Class Initialized
INFO - 2023-07-29 19:06:58 --> Output Class Initialized
INFO - 2023-07-29 19:06:58 --> Security Class Initialized
DEBUG - 2023-07-29 19:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:06:58 --> Input Class Initialized
INFO - 2023-07-29 19:06:58 --> Language Class Initialized
INFO - 2023-07-29 19:06:58 --> Language Class Initialized
INFO - 2023-07-29 19:06:58 --> Config Class Initialized
INFO - 2023-07-29 19:06:58 --> Loader Class Initialized
INFO - 2023-07-29 19:06:58 --> Helper loaded: url_helper
INFO - 2023-07-29 19:06:58 --> Helper loaded: file_helper
INFO - 2023-07-29 19:06:58 --> Helper loaded: form_helper
INFO - 2023-07-29 19:06:58 --> Helper loaded: my_helper
INFO - 2023-07-29 19:06:58 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:06:58 --> Controller Class Initialized
DEBUG - 2023-07-29 19:06:58 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_ekstra/views/list.php
DEBUG - 2023-07-29 19:06:58 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 19:06:58 --> Final output sent to browser
DEBUG - 2023-07-29 19:06:58 --> Total execution time: 0.0488
INFO - 2023-07-29 19:06:58 --> Config Class Initialized
INFO - 2023-07-29 19:06:58 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:06:58 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:06:58 --> Utf8 Class Initialized
INFO - 2023-07-29 19:06:58 --> URI Class Initialized
INFO - 2023-07-29 19:06:58 --> Router Class Initialized
INFO - 2023-07-29 19:06:58 --> Output Class Initialized
INFO - 2023-07-29 19:06:58 --> Security Class Initialized
DEBUG - 2023-07-29 19:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:06:58 --> Input Class Initialized
INFO - 2023-07-29 19:06:58 --> Language Class Initialized
INFO - 2023-07-29 19:06:58 --> Language Class Initialized
INFO - 2023-07-29 19:06:58 --> Config Class Initialized
INFO - 2023-07-29 19:06:58 --> Loader Class Initialized
INFO - 2023-07-29 19:06:58 --> Helper loaded: url_helper
INFO - 2023-07-29 19:06:58 --> Helper loaded: file_helper
INFO - 2023-07-29 19:06:58 --> Helper loaded: form_helper
INFO - 2023-07-29 19:06:58 --> Helper loaded: my_helper
INFO - 2023-07-29 19:06:58 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:06:58 --> Controller Class Initialized
INFO - 2023-07-29 19:07:00 --> Config Class Initialized
INFO - 2023-07-29 19:07:00 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:07:00 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:07:00 --> Utf8 Class Initialized
INFO - 2023-07-29 19:07:00 --> URI Class Initialized
INFO - 2023-07-29 19:07:00 --> Router Class Initialized
INFO - 2023-07-29 19:07:00 --> Output Class Initialized
INFO - 2023-07-29 19:07:00 --> Security Class Initialized
DEBUG - 2023-07-29 19:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:07:00 --> Input Class Initialized
INFO - 2023-07-29 19:07:00 --> Language Class Initialized
INFO - 2023-07-29 19:07:00 --> Language Class Initialized
INFO - 2023-07-29 19:07:00 --> Config Class Initialized
INFO - 2023-07-29 19:07:00 --> Loader Class Initialized
INFO - 2023-07-29 19:07:00 --> Helper loaded: url_helper
INFO - 2023-07-29 19:07:00 --> Helper loaded: file_helper
INFO - 2023-07-29 19:07:00 --> Helper loaded: form_helper
INFO - 2023-07-29 19:07:00 --> Helper loaded: my_helper
INFO - 2023-07-29 19:07:00 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:07:00 --> Controller Class Initialized
DEBUG - 2023-07-29 19:07:00 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/backup_db/views/list.php
DEBUG - 2023-07-29 19:07:00 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 19:07:00 --> Final output sent to browser
DEBUG - 2023-07-29 19:07:00 --> Total execution time: 0.0486
INFO - 2023-07-29 19:07:00 --> Config Class Initialized
INFO - 2023-07-29 19:07:00 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:07:00 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:07:00 --> Utf8 Class Initialized
INFO - 2023-07-29 19:07:00 --> URI Class Initialized
INFO - 2023-07-29 19:07:00 --> Router Class Initialized
INFO - 2023-07-29 19:07:00 --> Output Class Initialized
INFO - 2023-07-29 19:07:00 --> Security Class Initialized
DEBUG - 2023-07-29 19:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:07:00 --> Input Class Initialized
INFO - 2023-07-29 19:07:00 --> Language Class Initialized
INFO - 2023-07-29 19:07:00 --> Language Class Initialized
INFO - 2023-07-29 19:07:00 --> Config Class Initialized
INFO - 2023-07-29 19:07:00 --> Loader Class Initialized
INFO - 2023-07-29 19:07:00 --> Helper loaded: url_helper
INFO - 2023-07-29 19:07:00 --> Helper loaded: file_helper
INFO - 2023-07-29 19:07:00 --> Helper loaded: form_helper
INFO - 2023-07-29 19:07:00 --> Helper loaded: my_helper
INFO - 2023-07-29 19:07:00 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:07:00 --> Controller Class Initialized
INFO - 2023-07-29 19:07:01 --> Config Class Initialized
INFO - 2023-07-29 19:07:01 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:07:01 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:07:01 --> Utf8 Class Initialized
INFO - 2023-07-29 19:07:01 --> URI Class Initialized
INFO - 2023-07-29 19:07:01 --> Router Class Initialized
INFO - 2023-07-29 19:07:01 --> Output Class Initialized
INFO - 2023-07-29 19:07:01 --> Security Class Initialized
DEBUG - 2023-07-29 19:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:07:01 --> Input Class Initialized
INFO - 2023-07-29 19:07:01 --> Language Class Initialized
INFO - 2023-07-29 19:07:01 --> Language Class Initialized
INFO - 2023-07-29 19:07:01 --> Config Class Initialized
INFO - 2023-07-29 19:07:01 --> Loader Class Initialized
INFO - 2023-07-29 19:07:01 --> Helper loaded: url_helper
INFO - 2023-07-29 19:07:01 --> Helper loaded: file_helper
INFO - 2023-07-29 19:07:01 --> Helper loaded: form_helper
INFO - 2023-07-29 19:07:01 --> Helper loaded: my_helper
INFO - 2023-07-29 19:07:01 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:07:01 --> Controller Class Initialized
DEBUG - 2023-07-29 19:07:01 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/tahun/views/list.php
DEBUG - 2023-07-29 19:07:01 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 19:07:01 --> Final output sent to browser
DEBUG - 2023-07-29 19:07:01 --> Total execution time: 0.0571
INFO - 2023-07-29 19:07:02 --> Config Class Initialized
INFO - 2023-07-29 19:07:02 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:07:02 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:07:02 --> Utf8 Class Initialized
INFO - 2023-07-29 19:07:02 --> URI Class Initialized
INFO - 2023-07-29 19:07:02 --> Router Class Initialized
INFO - 2023-07-29 19:07:02 --> Output Class Initialized
INFO - 2023-07-29 19:07:02 --> Security Class Initialized
DEBUG - 2023-07-29 19:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:07:02 --> Input Class Initialized
INFO - 2023-07-29 19:07:02 --> Language Class Initialized
INFO - 2023-07-29 19:07:02 --> Language Class Initialized
INFO - 2023-07-29 19:07:02 --> Config Class Initialized
INFO - 2023-07-29 19:07:02 --> Loader Class Initialized
INFO - 2023-07-29 19:07:02 --> Helper loaded: url_helper
INFO - 2023-07-29 19:07:02 --> Helper loaded: file_helper
INFO - 2023-07-29 19:07:02 --> Helper loaded: form_helper
INFO - 2023-07-29 19:07:02 --> Helper loaded: my_helper
INFO - 2023-07-29 19:07:02 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:07:02 --> Controller Class Initialized
INFO - 2023-07-29 19:07:12 --> Config Class Initialized
INFO - 2023-07-29 19:07:12 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:07:12 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:07:12 --> Utf8 Class Initialized
INFO - 2023-07-29 19:07:12 --> URI Class Initialized
INFO - 2023-07-29 19:07:12 --> Router Class Initialized
INFO - 2023-07-29 19:07:12 --> Output Class Initialized
INFO - 2023-07-29 19:07:12 --> Security Class Initialized
DEBUG - 2023-07-29 19:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:07:12 --> Input Class Initialized
INFO - 2023-07-29 19:07:12 --> Language Class Initialized
INFO - 2023-07-29 19:07:12 --> Language Class Initialized
INFO - 2023-07-29 19:07:12 --> Config Class Initialized
INFO - 2023-07-29 19:07:12 --> Loader Class Initialized
INFO - 2023-07-29 19:07:12 --> Helper loaded: url_helper
INFO - 2023-07-29 19:07:12 --> Helper loaded: file_helper
INFO - 2023-07-29 19:07:12 --> Helper loaded: form_helper
INFO - 2023-07-29 19:07:12 --> Helper loaded: my_helper
INFO - 2023-07-29 19:07:12 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:07:12 --> Controller Class Initialized
DEBUG - 2023-07-29 19:07:12 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_kelas/views/list.php
DEBUG - 2023-07-29 19:07:12 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 19:07:12 --> Final output sent to browser
DEBUG - 2023-07-29 19:07:12 --> Total execution time: 0.0474
INFO - 2023-07-29 19:07:12 --> Config Class Initialized
INFO - 2023-07-29 19:07:12 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:07:12 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:07:12 --> Utf8 Class Initialized
INFO - 2023-07-29 19:07:12 --> URI Class Initialized
INFO - 2023-07-29 19:07:12 --> Router Class Initialized
INFO - 2023-07-29 19:07:12 --> Output Class Initialized
INFO - 2023-07-29 19:07:12 --> Security Class Initialized
DEBUG - 2023-07-29 19:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:07:12 --> Input Class Initialized
INFO - 2023-07-29 19:07:12 --> Language Class Initialized
INFO - 2023-07-29 19:07:12 --> Language Class Initialized
INFO - 2023-07-29 19:07:12 --> Config Class Initialized
INFO - 2023-07-29 19:07:12 --> Loader Class Initialized
INFO - 2023-07-29 19:07:12 --> Helper loaded: url_helper
INFO - 2023-07-29 19:07:12 --> Helper loaded: file_helper
INFO - 2023-07-29 19:07:12 --> Helper loaded: form_helper
INFO - 2023-07-29 19:07:12 --> Helper loaded: my_helper
INFO - 2023-07-29 19:07:12 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:07:12 --> Controller Class Initialized
INFO - 2023-07-29 19:07:12 --> Config Class Initialized
INFO - 2023-07-29 19:07:12 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:07:12 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:07:12 --> Utf8 Class Initialized
INFO - 2023-07-29 19:07:12 --> URI Class Initialized
INFO - 2023-07-29 19:07:12 --> Router Class Initialized
INFO - 2023-07-29 19:07:12 --> Output Class Initialized
INFO - 2023-07-29 19:07:12 --> Security Class Initialized
DEBUG - 2023-07-29 19:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:07:12 --> Input Class Initialized
INFO - 2023-07-29 19:07:12 --> Language Class Initialized
INFO - 2023-07-29 19:07:12 --> Language Class Initialized
INFO - 2023-07-29 19:07:12 --> Config Class Initialized
INFO - 2023-07-29 19:07:12 --> Loader Class Initialized
INFO - 2023-07-29 19:07:12 --> Helper loaded: url_helper
INFO - 2023-07-29 19:07:12 --> Helper loaded: file_helper
INFO - 2023-07-29 19:07:12 --> Helper loaded: form_helper
INFO - 2023-07-29 19:07:12 --> Helper loaded: my_helper
INFO - 2023-07-29 19:07:12 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:07:12 --> Controller Class Initialized
DEBUG - 2023-07-29 19:07:12 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-29 19:07:12 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 19:07:12 --> Final output sent to browser
DEBUG - 2023-07-29 19:07:12 --> Total execution time: 0.0560
INFO - 2023-07-29 19:07:12 --> Config Class Initialized
INFO - 2023-07-29 19:07:12 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:07:12 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:07:12 --> Utf8 Class Initialized
INFO - 2023-07-29 19:07:12 --> URI Class Initialized
INFO - 2023-07-29 19:07:12 --> Router Class Initialized
INFO - 2023-07-29 19:07:12 --> Output Class Initialized
INFO - 2023-07-29 19:07:12 --> Security Class Initialized
DEBUG - 2023-07-29 19:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:07:12 --> Input Class Initialized
INFO - 2023-07-29 19:07:12 --> Language Class Initialized
INFO - 2023-07-29 19:07:12 --> Language Class Initialized
INFO - 2023-07-29 19:07:12 --> Config Class Initialized
INFO - 2023-07-29 19:07:12 --> Loader Class Initialized
INFO - 2023-07-29 19:07:12 --> Helper loaded: url_helper
INFO - 2023-07-29 19:07:12 --> Helper loaded: file_helper
INFO - 2023-07-29 19:07:12 --> Helper loaded: form_helper
INFO - 2023-07-29 19:07:12 --> Helper loaded: my_helper
INFO - 2023-07-29 19:07:12 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:07:12 --> Controller Class Initialized
INFO - 2023-07-29 19:07:13 --> Config Class Initialized
INFO - 2023-07-29 19:07:13 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:07:13 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:07:13 --> Utf8 Class Initialized
INFO - 2023-07-29 19:07:13 --> URI Class Initialized
INFO - 2023-07-29 19:07:13 --> Router Class Initialized
INFO - 2023-07-29 19:07:13 --> Output Class Initialized
INFO - 2023-07-29 19:07:13 --> Security Class Initialized
DEBUG - 2023-07-29 19:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:07:13 --> Input Class Initialized
INFO - 2023-07-29 19:07:13 --> Language Class Initialized
INFO - 2023-07-29 19:07:13 --> Language Class Initialized
INFO - 2023-07-29 19:07:13 --> Config Class Initialized
INFO - 2023-07-29 19:07:13 --> Loader Class Initialized
INFO - 2023-07-29 19:07:13 --> Helper loaded: url_helper
INFO - 2023-07-29 19:07:13 --> Helper loaded: file_helper
INFO - 2023-07-29 19:07:13 --> Helper loaded: form_helper
INFO - 2023-07-29 19:07:13 --> Helper loaded: my_helper
INFO - 2023-07-29 19:07:13 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:07:13 --> Controller Class Initialized
DEBUG - 2023-07-29 19:07:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_guru/views/list.php
DEBUG - 2023-07-29 19:07:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 19:07:13 --> Final output sent to browser
DEBUG - 2023-07-29 19:07:13 --> Total execution time: 0.0374
INFO - 2023-07-29 19:07:13 --> Config Class Initialized
INFO - 2023-07-29 19:07:13 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:07:13 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:07:13 --> Utf8 Class Initialized
INFO - 2023-07-29 19:07:13 --> URI Class Initialized
INFO - 2023-07-29 19:07:13 --> Router Class Initialized
INFO - 2023-07-29 19:07:13 --> Output Class Initialized
INFO - 2023-07-29 19:07:13 --> Security Class Initialized
DEBUG - 2023-07-29 19:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:07:13 --> Input Class Initialized
INFO - 2023-07-29 19:07:13 --> Language Class Initialized
INFO - 2023-07-29 19:07:13 --> Language Class Initialized
INFO - 2023-07-29 19:07:13 --> Config Class Initialized
INFO - 2023-07-29 19:07:13 --> Loader Class Initialized
INFO - 2023-07-29 19:07:13 --> Helper loaded: url_helper
INFO - 2023-07-29 19:07:13 --> Helper loaded: file_helper
INFO - 2023-07-29 19:07:13 --> Helper loaded: form_helper
INFO - 2023-07-29 19:07:13 --> Helper loaded: my_helper
INFO - 2023-07-29 19:07:13 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:07:13 --> Controller Class Initialized
INFO - 2023-07-29 19:07:13 --> Config Class Initialized
INFO - 2023-07-29 19:07:13 --> Hooks Class Initialized
DEBUG - 2023-07-29 19:07:13 --> UTF-8 Support Enabled
INFO - 2023-07-29 19:07:13 --> Utf8 Class Initialized
INFO - 2023-07-29 19:07:13 --> URI Class Initialized
DEBUG - 2023-07-29 19:07:13 --> No URI present. Default controller set.
INFO - 2023-07-29 19:07:13 --> Router Class Initialized
INFO - 2023-07-29 19:07:13 --> Output Class Initialized
INFO - 2023-07-29 19:07:13 --> Security Class Initialized
DEBUG - 2023-07-29 19:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 19:07:13 --> Input Class Initialized
INFO - 2023-07-29 19:07:13 --> Language Class Initialized
INFO - 2023-07-29 19:07:13 --> Language Class Initialized
INFO - 2023-07-29 19:07:13 --> Config Class Initialized
INFO - 2023-07-29 19:07:13 --> Loader Class Initialized
INFO - 2023-07-29 19:07:13 --> Helper loaded: url_helper
INFO - 2023-07-29 19:07:13 --> Helper loaded: file_helper
INFO - 2023-07-29 19:07:13 --> Helper loaded: form_helper
INFO - 2023-07-29 19:07:13 --> Helper loaded: my_helper
INFO - 2023-07-29 19:07:13 --> Database Driver Class Initialized
DEBUG - 2023-07-29 19:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-29 19:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 19:07:13 --> Controller Class Initialized
DEBUG - 2023-07-29 19:07:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-29 19:07:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-29 19:07:13 --> Final output sent to browser
DEBUG - 2023-07-29 19:07:13 --> Total execution time: 0.0538
