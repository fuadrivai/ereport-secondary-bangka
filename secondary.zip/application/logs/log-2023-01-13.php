<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-01-13 02:00:03 --> Config Class Initialized
INFO - 2023-01-13 02:00:03 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:00:03 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:00:03 --> Utf8 Class Initialized
INFO - 2023-01-13 02:00:03 --> URI Class Initialized
DEBUG - 2023-01-13 02:00:03 --> No URI present. Default controller set.
INFO - 2023-01-13 02:00:03 --> Router Class Initialized
INFO - 2023-01-13 02:00:03 --> Output Class Initialized
INFO - 2023-01-13 02:00:03 --> Security Class Initialized
DEBUG - 2023-01-13 02:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:00:03 --> Input Class Initialized
INFO - 2023-01-13 02:00:03 --> Language Class Initialized
INFO - 2023-01-13 02:00:04 --> Language Class Initialized
INFO - 2023-01-13 02:00:04 --> Config Class Initialized
INFO - 2023-01-13 02:00:04 --> Loader Class Initialized
INFO - 2023-01-13 02:00:04 --> Helper loaded: url_helper
INFO - 2023-01-13 02:00:04 --> Helper loaded: file_helper
INFO - 2023-01-13 02:00:04 --> Helper loaded: form_helper
INFO - 2023-01-13 02:00:04 --> Helper loaded: my_helper
INFO - 2023-01-13 02:00:04 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:00:04 --> Controller Class Initialized
INFO - 2023-01-13 02:00:04 --> Config Class Initialized
INFO - 2023-01-13 02:00:04 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:00:04 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:00:04 --> Utf8 Class Initialized
INFO - 2023-01-13 02:00:04 --> URI Class Initialized
INFO - 2023-01-13 02:00:04 --> Router Class Initialized
INFO - 2023-01-13 02:00:04 --> Output Class Initialized
INFO - 2023-01-13 02:00:04 --> Security Class Initialized
DEBUG - 2023-01-13 02:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:00:04 --> Input Class Initialized
INFO - 2023-01-13 02:00:04 --> Language Class Initialized
INFO - 2023-01-13 02:00:04 --> Language Class Initialized
INFO - 2023-01-13 02:00:04 --> Config Class Initialized
INFO - 2023-01-13 02:00:04 --> Loader Class Initialized
INFO - 2023-01-13 02:00:04 --> Helper loaded: url_helper
INFO - 2023-01-13 02:00:04 --> Helper loaded: file_helper
INFO - 2023-01-13 02:00:04 --> Helper loaded: form_helper
INFO - 2023-01-13 02:00:04 --> Helper loaded: my_helper
INFO - 2023-01-13 02:00:04 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:00:04 --> Controller Class Initialized
DEBUG - 2023-01-13 02:00:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-13 02:00:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 02:00:04 --> Final output sent to browser
DEBUG - 2023-01-13 02:00:04 --> Total execution time: 0.0896
INFO - 2023-01-13 02:00:12 --> Config Class Initialized
INFO - 2023-01-13 02:00:12 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:00:12 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:00:12 --> Utf8 Class Initialized
INFO - 2023-01-13 02:00:12 --> URI Class Initialized
INFO - 2023-01-13 02:00:12 --> Router Class Initialized
INFO - 2023-01-13 02:00:12 --> Output Class Initialized
INFO - 2023-01-13 02:00:12 --> Security Class Initialized
DEBUG - 2023-01-13 02:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:00:12 --> Input Class Initialized
INFO - 2023-01-13 02:00:12 --> Language Class Initialized
INFO - 2023-01-13 02:00:12 --> Language Class Initialized
INFO - 2023-01-13 02:00:12 --> Config Class Initialized
INFO - 2023-01-13 02:00:12 --> Loader Class Initialized
INFO - 2023-01-13 02:00:12 --> Helper loaded: url_helper
INFO - 2023-01-13 02:00:12 --> Helper loaded: file_helper
INFO - 2023-01-13 02:00:12 --> Helper loaded: form_helper
INFO - 2023-01-13 02:00:12 --> Helper loaded: my_helper
INFO - 2023-01-13 02:00:12 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:00:12 --> Controller Class Initialized
INFO - 2023-01-13 02:00:12 --> Helper loaded: cookie_helper
INFO - 2023-01-13 02:00:12 --> Final output sent to browser
DEBUG - 2023-01-13 02:00:12 --> Total execution time: 0.1180
INFO - 2023-01-13 02:00:13 --> Config Class Initialized
INFO - 2023-01-13 02:00:13 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:00:13 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:00:13 --> Utf8 Class Initialized
INFO - 2023-01-13 02:00:13 --> URI Class Initialized
INFO - 2023-01-13 02:00:13 --> Router Class Initialized
INFO - 2023-01-13 02:00:13 --> Output Class Initialized
INFO - 2023-01-13 02:00:13 --> Security Class Initialized
DEBUG - 2023-01-13 02:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:00:13 --> Input Class Initialized
INFO - 2023-01-13 02:00:13 --> Language Class Initialized
INFO - 2023-01-13 02:00:13 --> Language Class Initialized
INFO - 2023-01-13 02:00:13 --> Config Class Initialized
INFO - 2023-01-13 02:00:13 --> Loader Class Initialized
INFO - 2023-01-13 02:00:13 --> Helper loaded: url_helper
INFO - 2023-01-13 02:00:13 --> Helper loaded: file_helper
INFO - 2023-01-13 02:00:13 --> Helper loaded: form_helper
INFO - 2023-01-13 02:00:13 --> Helper loaded: my_helper
INFO - 2023-01-13 02:00:13 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:00:13 --> Controller Class Initialized
DEBUG - 2023-01-13 02:00:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-13 02:00:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 02:00:13 --> Final output sent to browser
DEBUG - 2023-01-13 02:00:13 --> Total execution time: 0.1219
INFO - 2023-01-13 02:00:15 --> Config Class Initialized
INFO - 2023-01-13 02:00:15 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:00:15 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:00:15 --> Utf8 Class Initialized
INFO - 2023-01-13 02:00:15 --> URI Class Initialized
INFO - 2023-01-13 02:00:15 --> Router Class Initialized
INFO - 2023-01-13 02:00:15 --> Output Class Initialized
INFO - 2023-01-13 02:00:15 --> Security Class Initialized
DEBUG - 2023-01-13 02:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:00:15 --> Input Class Initialized
INFO - 2023-01-13 02:00:15 --> Language Class Initialized
INFO - 2023-01-13 02:00:15 --> Language Class Initialized
INFO - 2023-01-13 02:00:15 --> Config Class Initialized
INFO - 2023-01-13 02:00:15 --> Loader Class Initialized
INFO - 2023-01-13 02:00:15 --> Helper loaded: url_helper
INFO - 2023-01-13 02:00:15 --> Helper loaded: file_helper
INFO - 2023-01-13 02:00:15 --> Helper loaded: form_helper
INFO - 2023-01-13 02:00:15 --> Helper loaded: my_helper
INFO - 2023-01-13 02:00:15 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:00:15 --> Controller Class Initialized
DEBUG - 2023-01-13 02:00:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-01-13 02:00:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 02:00:15 --> Final output sent to browser
DEBUG - 2023-01-13 02:00:15 --> Total execution time: 0.0663
INFO - 2023-01-13 02:00:17 --> Config Class Initialized
INFO - 2023-01-13 02:00:17 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:00:17 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:00:17 --> Utf8 Class Initialized
INFO - 2023-01-13 02:00:17 --> URI Class Initialized
INFO - 2023-01-13 02:00:17 --> Router Class Initialized
INFO - 2023-01-13 02:00:17 --> Output Class Initialized
INFO - 2023-01-13 02:00:17 --> Security Class Initialized
DEBUG - 2023-01-13 02:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:00:17 --> Input Class Initialized
INFO - 2023-01-13 02:00:17 --> Language Class Initialized
INFO - 2023-01-13 02:00:17 --> Language Class Initialized
INFO - 2023-01-13 02:00:17 --> Config Class Initialized
INFO - 2023-01-13 02:00:17 --> Loader Class Initialized
INFO - 2023-01-13 02:00:17 --> Helper loaded: url_helper
INFO - 2023-01-13 02:00:17 --> Helper loaded: file_helper
INFO - 2023-01-13 02:00:17 --> Helper loaded: form_helper
INFO - 2023-01-13 02:00:17 --> Helper loaded: my_helper
INFO - 2023-01-13 02:00:17 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:00:17 --> Controller Class Initialized
DEBUG - 2023-01-13 02:00:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-13 02:00:19 --> Final output sent to browser
DEBUG - 2023-01-13 02:00:19 --> Total execution time: 2.2635
INFO - 2023-01-13 02:05:27 --> Config Class Initialized
INFO - 2023-01-13 02:05:27 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:05:27 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:05:27 --> Utf8 Class Initialized
INFO - 2023-01-13 02:05:27 --> URI Class Initialized
INFO - 2023-01-13 02:05:27 --> Router Class Initialized
INFO - 2023-01-13 02:05:27 --> Output Class Initialized
INFO - 2023-01-13 02:05:27 --> Security Class Initialized
DEBUG - 2023-01-13 02:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:05:27 --> Input Class Initialized
INFO - 2023-01-13 02:05:27 --> Language Class Initialized
INFO - 2023-01-13 02:05:27 --> Language Class Initialized
INFO - 2023-01-13 02:05:27 --> Config Class Initialized
INFO - 2023-01-13 02:05:27 --> Loader Class Initialized
INFO - 2023-01-13 02:05:27 --> Helper loaded: url_helper
INFO - 2023-01-13 02:05:27 --> Helper loaded: file_helper
INFO - 2023-01-13 02:05:27 --> Helper loaded: form_helper
INFO - 2023-01-13 02:05:27 --> Helper loaded: my_helper
INFO - 2023-01-13 02:05:27 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:05:27 --> Controller Class Initialized
DEBUG - 2023-01-13 02:05:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-13 02:05:29 --> Final output sent to browser
DEBUG - 2023-01-13 02:05:29 --> Total execution time: 1.4204
INFO - 2023-01-13 02:07:25 --> Config Class Initialized
INFO - 2023-01-13 02:07:25 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:07:25 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:07:25 --> Utf8 Class Initialized
INFO - 2023-01-13 02:07:25 --> URI Class Initialized
INFO - 2023-01-13 02:07:25 --> Router Class Initialized
INFO - 2023-01-13 02:07:25 --> Output Class Initialized
INFO - 2023-01-13 02:07:25 --> Security Class Initialized
DEBUG - 2023-01-13 02:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:07:25 --> Input Class Initialized
INFO - 2023-01-13 02:07:25 --> Language Class Initialized
INFO - 2023-01-13 02:07:25 --> Language Class Initialized
INFO - 2023-01-13 02:07:25 --> Config Class Initialized
INFO - 2023-01-13 02:07:25 --> Loader Class Initialized
INFO - 2023-01-13 02:07:25 --> Helper loaded: url_helper
INFO - 2023-01-13 02:07:25 --> Helper loaded: file_helper
INFO - 2023-01-13 02:07:25 --> Helper loaded: form_helper
INFO - 2023-01-13 02:07:25 --> Helper loaded: my_helper
INFO - 2023-01-13 02:07:25 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:07:25 --> Controller Class Initialized
DEBUG - 2023-01-13 02:07:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-13 02:07:27 --> Final output sent to browser
DEBUG - 2023-01-13 02:07:27 --> Total execution time: 1.6246
INFO - 2023-01-13 02:09:00 --> Config Class Initialized
INFO - 2023-01-13 02:09:00 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:09:00 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:09:00 --> Utf8 Class Initialized
INFO - 2023-01-13 02:09:00 --> URI Class Initialized
INFO - 2023-01-13 02:09:00 --> Router Class Initialized
INFO - 2023-01-13 02:09:00 --> Output Class Initialized
INFO - 2023-01-13 02:09:00 --> Security Class Initialized
DEBUG - 2023-01-13 02:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:09:00 --> Input Class Initialized
INFO - 2023-01-13 02:09:00 --> Language Class Initialized
INFO - 2023-01-13 02:09:00 --> Language Class Initialized
INFO - 2023-01-13 02:09:00 --> Config Class Initialized
INFO - 2023-01-13 02:09:00 --> Loader Class Initialized
INFO - 2023-01-13 02:09:00 --> Helper loaded: url_helper
INFO - 2023-01-13 02:09:00 --> Helper loaded: file_helper
INFO - 2023-01-13 02:09:00 --> Helper loaded: form_helper
INFO - 2023-01-13 02:09:00 --> Helper loaded: my_helper
INFO - 2023-01-13 02:09:00 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:09:00 --> Controller Class Initialized
DEBUG - 2023-01-13 02:09:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-13 02:09:02 --> Final output sent to browser
DEBUG - 2023-01-13 02:09:02 --> Total execution time: 1.5371
INFO - 2023-01-13 02:10:56 --> Config Class Initialized
INFO - 2023-01-13 02:10:56 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:10:56 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:10:56 --> Utf8 Class Initialized
INFO - 2023-01-13 02:10:56 --> URI Class Initialized
INFO - 2023-01-13 02:10:56 --> Router Class Initialized
INFO - 2023-01-13 02:10:56 --> Output Class Initialized
INFO - 2023-01-13 02:10:56 --> Security Class Initialized
DEBUG - 2023-01-13 02:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:10:56 --> Input Class Initialized
INFO - 2023-01-13 02:10:56 --> Language Class Initialized
INFO - 2023-01-13 02:10:56 --> Language Class Initialized
INFO - 2023-01-13 02:10:56 --> Config Class Initialized
INFO - 2023-01-13 02:10:56 --> Loader Class Initialized
INFO - 2023-01-13 02:10:56 --> Helper loaded: url_helper
INFO - 2023-01-13 02:10:56 --> Helper loaded: file_helper
INFO - 2023-01-13 02:10:56 --> Helper loaded: form_helper
INFO - 2023-01-13 02:10:57 --> Helper loaded: my_helper
INFO - 2023-01-13 02:10:57 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:10:57 --> Controller Class Initialized
DEBUG - 2023-01-13 02:10:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-13 02:10:58 --> Final output sent to browser
DEBUG - 2023-01-13 02:10:58 --> Total execution time: 1.6082
INFO - 2023-01-13 02:25:54 --> Config Class Initialized
INFO - 2023-01-13 02:25:54 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:25:54 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:25:54 --> Utf8 Class Initialized
INFO - 2023-01-13 02:25:54 --> URI Class Initialized
INFO - 2023-01-13 02:25:54 --> Router Class Initialized
INFO - 2023-01-13 02:25:54 --> Output Class Initialized
INFO - 2023-01-13 02:25:54 --> Security Class Initialized
DEBUG - 2023-01-13 02:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:25:54 --> Input Class Initialized
INFO - 2023-01-13 02:25:54 --> Language Class Initialized
INFO - 2023-01-13 02:25:54 --> Language Class Initialized
INFO - 2023-01-13 02:25:54 --> Config Class Initialized
INFO - 2023-01-13 02:25:54 --> Loader Class Initialized
INFO - 2023-01-13 02:25:54 --> Helper loaded: url_helper
INFO - 2023-01-13 02:25:54 --> Helper loaded: file_helper
INFO - 2023-01-13 02:25:54 --> Helper loaded: form_helper
INFO - 2023-01-13 02:25:54 --> Helper loaded: my_helper
INFO - 2023-01-13 02:25:54 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:25:54 --> Controller Class Initialized
DEBUG - 2023-01-13 02:25:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-13 02:25:55 --> Final output sent to browser
DEBUG - 2023-01-13 02:25:55 --> Total execution time: 1.6594
INFO - 2023-01-13 02:28:51 --> Config Class Initialized
INFO - 2023-01-13 02:28:51 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:28:51 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:28:51 --> Utf8 Class Initialized
INFO - 2023-01-13 02:28:51 --> URI Class Initialized
INFO - 2023-01-13 02:28:51 --> Router Class Initialized
INFO - 2023-01-13 02:28:51 --> Output Class Initialized
INFO - 2023-01-13 02:28:51 --> Security Class Initialized
DEBUG - 2023-01-13 02:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:28:51 --> Input Class Initialized
INFO - 2023-01-13 02:28:51 --> Language Class Initialized
INFO - 2023-01-13 02:28:51 --> Language Class Initialized
INFO - 2023-01-13 02:28:51 --> Config Class Initialized
INFO - 2023-01-13 02:28:51 --> Loader Class Initialized
INFO - 2023-01-13 02:28:51 --> Helper loaded: url_helper
INFO - 2023-01-13 02:28:51 --> Helper loaded: file_helper
INFO - 2023-01-13 02:28:51 --> Helper loaded: form_helper
INFO - 2023-01-13 02:28:51 --> Helper loaded: my_helper
INFO - 2023-01-13 02:28:51 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:28:51 --> Controller Class Initialized
DEBUG - 2023-01-13 02:28:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-13 02:28:53 --> Final output sent to browser
DEBUG - 2023-01-13 02:28:53 --> Total execution time: 1.5621
INFO - 2023-01-13 02:34:53 --> Config Class Initialized
INFO - 2023-01-13 02:34:53 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:34:53 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:34:53 --> Utf8 Class Initialized
INFO - 2023-01-13 02:34:53 --> URI Class Initialized
INFO - 2023-01-13 02:34:53 --> Router Class Initialized
INFO - 2023-01-13 02:34:53 --> Output Class Initialized
INFO - 2023-01-13 02:34:53 --> Security Class Initialized
DEBUG - 2023-01-13 02:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:34:53 --> Input Class Initialized
INFO - 2023-01-13 02:34:53 --> Language Class Initialized
INFO - 2023-01-13 02:34:53 --> Language Class Initialized
INFO - 2023-01-13 02:34:53 --> Config Class Initialized
INFO - 2023-01-13 02:34:53 --> Loader Class Initialized
INFO - 2023-01-13 02:34:53 --> Helper loaded: url_helper
INFO - 2023-01-13 02:34:53 --> Helper loaded: file_helper
INFO - 2023-01-13 02:34:53 --> Helper loaded: form_helper
INFO - 2023-01-13 02:34:53 --> Helper loaded: my_helper
INFO - 2023-01-13 02:34:53 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:34:53 --> Controller Class Initialized
DEBUG - 2023-01-13 02:34:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-13 02:34:54 --> Final output sent to browser
DEBUG - 2023-01-13 02:34:54 --> Total execution time: 1.5684
INFO - 2023-01-13 02:35:33 --> Config Class Initialized
INFO - 2023-01-13 02:35:33 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:35:33 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:35:33 --> Utf8 Class Initialized
INFO - 2023-01-13 02:35:33 --> URI Class Initialized
INFO - 2023-01-13 02:35:33 --> Router Class Initialized
INFO - 2023-01-13 02:35:33 --> Output Class Initialized
INFO - 2023-01-13 02:35:33 --> Security Class Initialized
DEBUG - 2023-01-13 02:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:35:33 --> Input Class Initialized
INFO - 2023-01-13 02:35:33 --> Language Class Initialized
INFO - 2023-01-13 02:35:33 --> Language Class Initialized
INFO - 2023-01-13 02:35:33 --> Config Class Initialized
INFO - 2023-01-13 02:35:33 --> Loader Class Initialized
INFO - 2023-01-13 02:35:33 --> Helper loaded: url_helper
INFO - 2023-01-13 02:35:33 --> Helper loaded: file_helper
INFO - 2023-01-13 02:35:33 --> Helper loaded: form_helper
INFO - 2023-01-13 02:35:33 --> Helper loaded: my_helper
INFO - 2023-01-13 02:35:33 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:35:33 --> Controller Class Initialized
ERROR - 2023-01-13 02:35:33 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1313
DEBUG - 2023-01-13 02:35:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-13 02:35:35 --> Final output sent to browser
DEBUG - 2023-01-13 02:35:35 --> Total execution time: 1.4891
INFO - 2023-01-13 02:38:56 --> Config Class Initialized
INFO - 2023-01-13 02:38:56 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:38:56 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:38:56 --> Utf8 Class Initialized
INFO - 2023-01-13 02:38:56 --> URI Class Initialized
INFO - 2023-01-13 02:38:56 --> Router Class Initialized
INFO - 2023-01-13 02:38:56 --> Output Class Initialized
INFO - 2023-01-13 02:38:56 --> Security Class Initialized
DEBUG - 2023-01-13 02:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:38:56 --> Input Class Initialized
INFO - 2023-01-13 02:38:56 --> Language Class Initialized
INFO - 2023-01-13 02:38:56 --> Language Class Initialized
INFO - 2023-01-13 02:38:56 --> Config Class Initialized
INFO - 2023-01-13 02:38:56 --> Loader Class Initialized
INFO - 2023-01-13 02:38:56 --> Helper loaded: url_helper
INFO - 2023-01-13 02:38:56 --> Helper loaded: file_helper
INFO - 2023-01-13 02:38:56 --> Helper loaded: form_helper
INFO - 2023-01-13 02:38:56 --> Helper loaded: my_helper
INFO - 2023-01-13 02:38:56 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:38:56 --> Controller Class Initialized
DEBUG - 2023-01-13 02:38:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-13 02:38:58 --> Final output sent to browser
DEBUG - 2023-01-13 02:38:58 --> Total execution time: 2.0003
INFO - 2023-01-13 02:41:31 --> Config Class Initialized
INFO - 2023-01-13 02:41:31 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:41:31 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:41:31 --> Utf8 Class Initialized
INFO - 2023-01-13 02:41:31 --> URI Class Initialized
INFO - 2023-01-13 02:41:31 --> Router Class Initialized
INFO - 2023-01-13 02:41:31 --> Output Class Initialized
INFO - 2023-01-13 02:41:31 --> Security Class Initialized
DEBUG - 2023-01-13 02:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:41:31 --> Input Class Initialized
INFO - 2023-01-13 02:41:31 --> Language Class Initialized
INFO - 2023-01-13 02:41:31 --> Language Class Initialized
INFO - 2023-01-13 02:41:31 --> Config Class Initialized
INFO - 2023-01-13 02:41:31 --> Loader Class Initialized
INFO - 2023-01-13 02:41:31 --> Helper loaded: url_helper
INFO - 2023-01-13 02:41:31 --> Helper loaded: file_helper
INFO - 2023-01-13 02:41:31 --> Helper loaded: form_helper
INFO - 2023-01-13 02:41:31 --> Helper loaded: my_helper
INFO - 2023-01-13 02:41:31 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:41:31 --> Controller Class Initialized
ERROR - 2023-01-13 02:41:31 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1310
ERROR - 2023-01-13 02:41:31 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1310
ERROR - 2023-01-13 02:41:31 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1310
ERROR - 2023-01-13 02:41:31 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1310
ERROR - 2023-01-13 02:41:31 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1310
ERROR - 2023-01-13 02:41:31 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1539
DEBUG - 2023-01-13 02:41:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-13 02:41:32 --> Final output sent to browser
DEBUG - 2023-01-13 02:41:32 --> Total execution time: 1.2819
INFO - 2023-01-13 02:42:11 --> Config Class Initialized
INFO - 2023-01-13 02:42:11 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:42:11 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:42:11 --> Utf8 Class Initialized
INFO - 2023-01-13 02:42:11 --> URI Class Initialized
INFO - 2023-01-13 02:42:11 --> Router Class Initialized
INFO - 2023-01-13 02:42:11 --> Output Class Initialized
INFO - 2023-01-13 02:42:11 --> Security Class Initialized
DEBUG - 2023-01-13 02:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:42:11 --> Input Class Initialized
INFO - 2023-01-13 02:42:11 --> Language Class Initialized
INFO - 2023-01-13 02:42:11 --> Language Class Initialized
INFO - 2023-01-13 02:42:11 --> Config Class Initialized
INFO - 2023-01-13 02:42:11 --> Loader Class Initialized
INFO - 2023-01-13 02:42:11 --> Helper loaded: url_helper
INFO - 2023-01-13 02:42:11 --> Helper loaded: file_helper
INFO - 2023-01-13 02:42:11 --> Helper loaded: form_helper
INFO - 2023-01-13 02:42:11 --> Helper loaded: my_helper
INFO - 2023-01-13 02:42:11 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:42:11 --> Controller Class Initialized
DEBUG - 2023-01-13 02:42:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-13 02:42:13 --> Final output sent to browser
DEBUG - 2023-01-13 02:42:13 --> Total execution time: 1.2128
INFO - 2023-01-13 02:47:07 --> Config Class Initialized
INFO - 2023-01-13 02:47:07 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:47:07 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:47:07 --> Utf8 Class Initialized
INFO - 2023-01-13 02:47:07 --> URI Class Initialized
INFO - 2023-01-13 02:47:07 --> Router Class Initialized
INFO - 2023-01-13 02:47:07 --> Output Class Initialized
INFO - 2023-01-13 02:47:07 --> Security Class Initialized
DEBUG - 2023-01-13 02:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:47:07 --> Input Class Initialized
INFO - 2023-01-13 02:47:07 --> Language Class Initialized
INFO - 2023-01-13 02:47:07 --> Language Class Initialized
INFO - 2023-01-13 02:47:07 --> Config Class Initialized
INFO - 2023-01-13 02:47:07 --> Loader Class Initialized
INFO - 2023-01-13 02:47:07 --> Helper loaded: url_helper
INFO - 2023-01-13 02:47:07 --> Helper loaded: file_helper
INFO - 2023-01-13 02:47:07 --> Helper loaded: form_helper
INFO - 2023-01-13 02:47:07 --> Helper loaded: my_helper
INFO - 2023-01-13 02:47:07 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:47:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:47:07 --> Controller Class Initialized
ERROR - 2023-01-13 02:47:07 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 555
ERROR - 2023-01-13 02:47:07 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 565
ERROR - 2023-01-13 02:47:07 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 555
ERROR - 2023-01-13 02:47:07 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 565
ERROR - 2023-01-13 02:47:07 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 555
ERROR - 2023-01-13 02:47:07 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 565
ERROR - 2023-01-13 02:47:07 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 555
ERROR - 2023-01-13 02:47:07 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 565
ERROR - 2023-01-13 02:47:07 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 555
ERROR - 2023-01-13 02:47:07 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 565
DEBUG - 2023-01-13 02:47:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-13 02:47:08 --> Final output sent to browser
DEBUG - 2023-01-13 02:47:08 --> Total execution time: 1.3509
INFO - 2023-01-13 02:47:09 --> Config Class Initialized
INFO - 2023-01-13 02:47:09 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:47:09 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:47:09 --> Utf8 Class Initialized
INFO - 2023-01-13 02:47:09 --> URI Class Initialized
INFO - 2023-01-13 02:47:09 --> Router Class Initialized
INFO - 2023-01-13 02:47:09 --> Output Class Initialized
INFO - 2023-01-13 02:47:09 --> Security Class Initialized
DEBUG - 2023-01-13 02:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:47:09 --> Input Class Initialized
INFO - 2023-01-13 02:47:09 --> Language Class Initialized
INFO - 2023-01-13 02:47:09 --> Language Class Initialized
INFO - 2023-01-13 02:47:09 --> Config Class Initialized
INFO - 2023-01-13 02:47:09 --> Loader Class Initialized
INFO - 2023-01-13 02:47:09 --> Helper loaded: url_helper
INFO - 2023-01-13 02:47:09 --> Helper loaded: file_helper
INFO - 2023-01-13 02:47:09 --> Helper loaded: form_helper
INFO - 2023-01-13 02:47:09 --> Helper loaded: my_helper
INFO - 2023-01-13 02:47:09 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:47:09 --> Controller Class Initialized
DEBUG - 2023-01-13 02:47:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-13 02:47:10 --> Final output sent to browser
DEBUG - 2023-01-13 02:47:10 --> Total execution time: 1.2566
INFO - 2023-01-13 02:48:01 --> Config Class Initialized
INFO - 2023-01-13 02:48:01 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:48:01 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:48:01 --> Utf8 Class Initialized
INFO - 2023-01-13 02:48:01 --> URI Class Initialized
INFO - 2023-01-13 02:48:01 --> Router Class Initialized
INFO - 2023-01-13 02:48:01 --> Output Class Initialized
INFO - 2023-01-13 02:48:01 --> Security Class Initialized
DEBUG - 2023-01-13 02:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:48:01 --> Input Class Initialized
INFO - 2023-01-13 02:48:01 --> Language Class Initialized
INFO - 2023-01-13 02:48:01 --> Language Class Initialized
INFO - 2023-01-13 02:48:01 --> Config Class Initialized
INFO - 2023-01-13 02:48:01 --> Loader Class Initialized
INFO - 2023-01-13 02:48:01 --> Helper loaded: url_helper
INFO - 2023-01-13 02:48:01 --> Helper loaded: file_helper
INFO - 2023-01-13 02:48:01 --> Helper loaded: form_helper
INFO - 2023-01-13 02:48:01 --> Helper loaded: my_helper
INFO - 2023-01-13 02:48:01 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:48:01 --> Controller Class Initialized
DEBUG - 2023-01-13 02:48:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-13 02:48:02 --> Final output sent to browser
DEBUG - 2023-01-13 02:48:02 --> Total execution time: 1.1768
INFO - 2023-01-13 02:49:13 --> Config Class Initialized
INFO - 2023-01-13 02:49:13 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:49:13 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:49:13 --> Utf8 Class Initialized
INFO - 2023-01-13 02:49:13 --> URI Class Initialized
INFO - 2023-01-13 02:49:13 --> Router Class Initialized
INFO - 2023-01-13 02:49:13 --> Output Class Initialized
INFO - 2023-01-13 02:49:13 --> Security Class Initialized
DEBUG - 2023-01-13 02:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:49:13 --> Input Class Initialized
INFO - 2023-01-13 02:49:13 --> Language Class Initialized
INFO - 2023-01-13 02:49:13 --> Language Class Initialized
INFO - 2023-01-13 02:49:13 --> Config Class Initialized
INFO - 2023-01-13 02:49:13 --> Loader Class Initialized
INFO - 2023-01-13 02:49:13 --> Helper loaded: url_helper
INFO - 2023-01-13 02:49:13 --> Helper loaded: file_helper
INFO - 2023-01-13 02:49:13 --> Helper loaded: form_helper
INFO - 2023-01-13 02:49:13 --> Helper loaded: my_helper
INFO - 2023-01-13 02:49:13 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:49:13 --> Controller Class Initialized
DEBUG - 2023-01-13 02:49:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-13 02:49:14 --> Final output sent to browser
DEBUG - 2023-01-13 02:49:14 --> Total execution time: 1.2046
INFO - 2023-01-13 02:50:06 --> Config Class Initialized
INFO - 2023-01-13 02:50:06 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:50:06 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:50:06 --> Utf8 Class Initialized
INFO - 2023-01-13 02:50:06 --> URI Class Initialized
INFO - 2023-01-13 02:50:06 --> Router Class Initialized
INFO - 2023-01-13 02:50:06 --> Output Class Initialized
INFO - 2023-01-13 02:50:06 --> Security Class Initialized
DEBUG - 2023-01-13 02:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:50:06 --> Input Class Initialized
INFO - 2023-01-13 02:50:06 --> Language Class Initialized
INFO - 2023-01-13 02:50:06 --> Language Class Initialized
INFO - 2023-01-13 02:50:06 --> Config Class Initialized
INFO - 2023-01-13 02:50:06 --> Loader Class Initialized
INFO - 2023-01-13 02:50:06 --> Helper loaded: url_helper
INFO - 2023-01-13 02:50:06 --> Helper loaded: file_helper
INFO - 2023-01-13 02:50:06 --> Helper loaded: form_helper
INFO - 2023-01-13 02:50:06 --> Helper loaded: my_helper
INFO - 2023-01-13 02:50:06 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:50:06 --> Controller Class Initialized
DEBUG - 2023-01-13 02:50:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-13 02:50:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 02:50:06 --> Final output sent to browser
DEBUG - 2023-01-13 02:50:06 --> Total execution time: 0.1111
INFO - 2023-01-13 02:50:08 --> Config Class Initialized
INFO - 2023-01-13 02:50:08 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:50:08 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:50:08 --> Utf8 Class Initialized
INFO - 2023-01-13 02:50:08 --> URI Class Initialized
INFO - 2023-01-13 02:50:08 --> Router Class Initialized
INFO - 2023-01-13 02:50:08 --> Output Class Initialized
INFO - 2023-01-13 02:50:08 --> Security Class Initialized
DEBUG - 2023-01-13 02:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:50:08 --> Input Class Initialized
INFO - 2023-01-13 02:50:08 --> Language Class Initialized
INFO - 2023-01-13 02:50:08 --> Language Class Initialized
INFO - 2023-01-13 02:50:08 --> Config Class Initialized
INFO - 2023-01-13 02:50:08 --> Loader Class Initialized
INFO - 2023-01-13 02:50:08 --> Helper loaded: url_helper
INFO - 2023-01-13 02:50:08 --> Helper loaded: file_helper
INFO - 2023-01-13 02:50:08 --> Helper loaded: form_helper
INFO - 2023-01-13 02:50:08 --> Helper loaded: my_helper
INFO - 2023-01-13 02:50:08 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:50:08 --> Controller Class Initialized
DEBUG - 2023-01-13 02:50:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_absensi/views/list.php
DEBUG - 2023-01-13 02:50:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 02:50:08 --> Final output sent to browser
DEBUG - 2023-01-13 02:50:08 --> Total execution time: 0.0815
INFO - 2023-01-13 02:50:13 --> Config Class Initialized
INFO - 2023-01-13 02:50:13 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:50:13 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:50:13 --> Utf8 Class Initialized
INFO - 2023-01-13 02:50:13 --> URI Class Initialized
INFO - 2023-01-13 02:50:13 --> Router Class Initialized
INFO - 2023-01-13 02:50:13 --> Output Class Initialized
INFO - 2023-01-13 02:50:13 --> Security Class Initialized
DEBUG - 2023-01-13 02:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:50:13 --> Input Class Initialized
INFO - 2023-01-13 02:50:13 --> Language Class Initialized
INFO - 2023-01-13 02:50:13 --> Language Class Initialized
INFO - 2023-01-13 02:50:13 --> Config Class Initialized
INFO - 2023-01-13 02:50:13 --> Loader Class Initialized
INFO - 2023-01-13 02:50:13 --> Helper loaded: url_helper
INFO - 2023-01-13 02:50:13 --> Helper loaded: file_helper
INFO - 2023-01-13 02:50:13 --> Helper loaded: form_helper
INFO - 2023-01-13 02:50:13 --> Helper loaded: my_helper
INFO - 2023-01-13 02:50:13 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:50:13 --> Controller Class Initialized
INFO - 2023-01-13 02:50:13 --> Helper loaded: cookie_helper
INFO - 2023-01-13 02:50:13 --> Config Class Initialized
INFO - 2023-01-13 02:50:13 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:50:13 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:50:13 --> Utf8 Class Initialized
INFO - 2023-01-13 02:50:13 --> URI Class Initialized
INFO - 2023-01-13 02:50:13 --> Router Class Initialized
INFO - 2023-01-13 02:50:13 --> Output Class Initialized
INFO - 2023-01-13 02:50:13 --> Security Class Initialized
DEBUG - 2023-01-13 02:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:50:13 --> Input Class Initialized
INFO - 2023-01-13 02:50:13 --> Language Class Initialized
INFO - 2023-01-13 02:50:13 --> Language Class Initialized
INFO - 2023-01-13 02:50:13 --> Config Class Initialized
INFO - 2023-01-13 02:50:13 --> Loader Class Initialized
INFO - 2023-01-13 02:50:13 --> Helper loaded: url_helper
INFO - 2023-01-13 02:50:13 --> Helper loaded: file_helper
INFO - 2023-01-13 02:50:13 --> Helper loaded: form_helper
INFO - 2023-01-13 02:50:13 --> Helper loaded: my_helper
INFO - 2023-01-13 02:50:13 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:50:13 --> Controller Class Initialized
INFO - 2023-01-13 02:50:13 --> Config Class Initialized
INFO - 2023-01-13 02:50:13 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:50:13 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:50:13 --> Utf8 Class Initialized
INFO - 2023-01-13 02:50:13 --> URI Class Initialized
INFO - 2023-01-13 02:50:13 --> Router Class Initialized
INFO - 2023-01-13 02:50:13 --> Output Class Initialized
INFO - 2023-01-13 02:50:13 --> Security Class Initialized
DEBUG - 2023-01-13 02:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:50:13 --> Input Class Initialized
INFO - 2023-01-13 02:50:13 --> Language Class Initialized
INFO - 2023-01-13 02:50:13 --> Language Class Initialized
INFO - 2023-01-13 02:50:13 --> Config Class Initialized
INFO - 2023-01-13 02:50:13 --> Loader Class Initialized
INFO - 2023-01-13 02:50:13 --> Helper loaded: url_helper
INFO - 2023-01-13 02:50:13 --> Helper loaded: file_helper
INFO - 2023-01-13 02:50:13 --> Helper loaded: form_helper
INFO - 2023-01-13 02:50:13 --> Helper loaded: my_helper
INFO - 2023-01-13 02:50:13 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:50:13 --> Controller Class Initialized
DEBUG - 2023-01-13 02:50:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-13 02:50:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 02:50:13 --> Final output sent to browser
DEBUG - 2023-01-13 02:50:13 --> Total execution time: 0.0404
INFO - 2023-01-13 02:50:16 --> Config Class Initialized
INFO - 2023-01-13 02:50:16 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:50:16 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:50:16 --> Utf8 Class Initialized
INFO - 2023-01-13 02:50:16 --> URI Class Initialized
INFO - 2023-01-13 02:50:16 --> Router Class Initialized
INFO - 2023-01-13 02:50:16 --> Output Class Initialized
INFO - 2023-01-13 02:50:16 --> Security Class Initialized
DEBUG - 2023-01-13 02:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:50:16 --> Input Class Initialized
INFO - 2023-01-13 02:50:16 --> Language Class Initialized
INFO - 2023-01-13 02:50:16 --> Language Class Initialized
INFO - 2023-01-13 02:50:16 --> Config Class Initialized
INFO - 2023-01-13 02:50:16 --> Loader Class Initialized
INFO - 2023-01-13 02:50:16 --> Helper loaded: url_helper
INFO - 2023-01-13 02:50:16 --> Helper loaded: file_helper
INFO - 2023-01-13 02:50:16 --> Helper loaded: form_helper
INFO - 2023-01-13 02:50:16 --> Helper loaded: my_helper
INFO - 2023-01-13 02:50:16 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:50:16 --> Controller Class Initialized
INFO - 2023-01-13 02:50:16 --> Helper loaded: cookie_helper
INFO - 2023-01-13 02:50:16 --> Final output sent to browser
DEBUG - 2023-01-13 02:50:16 --> Total execution time: 0.0477
INFO - 2023-01-13 02:50:16 --> Config Class Initialized
INFO - 2023-01-13 02:50:16 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:50:16 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:50:16 --> Utf8 Class Initialized
INFO - 2023-01-13 02:50:16 --> URI Class Initialized
INFO - 2023-01-13 02:50:16 --> Router Class Initialized
INFO - 2023-01-13 02:50:16 --> Output Class Initialized
INFO - 2023-01-13 02:50:16 --> Security Class Initialized
DEBUG - 2023-01-13 02:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:50:16 --> Input Class Initialized
INFO - 2023-01-13 02:50:16 --> Language Class Initialized
INFO - 2023-01-13 02:50:16 --> Language Class Initialized
INFO - 2023-01-13 02:50:16 --> Config Class Initialized
INFO - 2023-01-13 02:50:16 --> Loader Class Initialized
INFO - 2023-01-13 02:50:16 --> Helper loaded: url_helper
INFO - 2023-01-13 02:50:17 --> Helper loaded: file_helper
INFO - 2023-01-13 02:50:17 --> Helper loaded: form_helper
INFO - 2023-01-13 02:50:17 --> Helper loaded: my_helper
INFO - 2023-01-13 02:50:17 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:50:17 --> Controller Class Initialized
DEBUG - 2023-01-13 02:50:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-01-13 02:50:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 02:50:17 --> Final output sent to browser
DEBUG - 2023-01-13 02:50:17 --> Total execution time: 0.0666
INFO - 2023-01-13 02:50:18 --> Config Class Initialized
INFO - 2023-01-13 02:50:18 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:50:18 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:50:18 --> Utf8 Class Initialized
INFO - 2023-01-13 02:50:18 --> URI Class Initialized
INFO - 2023-01-13 02:50:18 --> Router Class Initialized
INFO - 2023-01-13 02:50:18 --> Output Class Initialized
INFO - 2023-01-13 02:50:18 --> Security Class Initialized
DEBUG - 2023-01-13 02:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:50:18 --> Input Class Initialized
INFO - 2023-01-13 02:50:18 --> Language Class Initialized
INFO - 2023-01-13 02:50:18 --> Language Class Initialized
INFO - 2023-01-13 02:50:18 --> Config Class Initialized
INFO - 2023-01-13 02:50:18 --> Loader Class Initialized
INFO - 2023-01-13 02:50:18 --> Helper loaded: url_helper
INFO - 2023-01-13 02:50:18 --> Helper loaded: file_helper
INFO - 2023-01-13 02:50:18 --> Helper loaded: form_helper
INFO - 2023-01-13 02:50:18 --> Helper loaded: my_helper
INFO - 2023-01-13 02:50:18 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:50:18 --> Controller Class Initialized
DEBUG - 2023-01-13 02:50:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/list.php
DEBUG - 2023-01-13 02:50:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 02:50:18 --> Final output sent to browser
DEBUG - 2023-01-13 02:50:18 --> Total execution time: 0.0543
INFO - 2023-01-13 02:50:19 --> Config Class Initialized
INFO - 2023-01-13 02:50:19 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:50:19 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:50:19 --> Utf8 Class Initialized
INFO - 2023-01-13 02:50:19 --> URI Class Initialized
INFO - 2023-01-13 02:50:19 --> Router Class Initialized
INFO - 2023-01-13 02:50:19 --> Output Class Initialized
INFO - 2023-01-13 02:50:19 --> Security Class Initialized
DEBUG - 2023-01-13 02:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:50:19 --> Input Class Initialized
INFO - 2023-01-13 02:50:19 --> Language Class Initialized
INFO - 2023-01-13 02:50:19 --> Language Class Initialized
INFO - 2023-01-13 02:50:19 --> Config Class Initialized
INFO - 2023-01-13 02:50:19 --> Loader Class Initialized
INFO - 2023-01-13 02:50:19 --> Helper loaded: url_helper
INFO - 2023-01-13 02:50:19 --> Helper loaded: file_helper
INFO - 2023-01-13 02:50:19 --> Helper loaded: form_helper
INFO - 2023-01-13 02:50:19 --> Helper loaded: my_helper
INFO - 2023-01-13 02:50:19 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:50:19 --> Controller Class Initialized
INFO - 2023-01-13 02:50:22 --> Config Class Initialized
INFO - 2023-01-13 02:50:22 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:50:22 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:50:22 --> Utf8 Class Initialized
INFO - 2023-01-13 02:50:22 --> URI Class Initialized
INFO - 2023-01-13 02:50:22 --> Router Class Initialized
INFO - 2023-01-13 02:50:22 --> Output Class Initialized
INFO - 2023-01-13 02:50:22 --> Security Class Initialized
DEBUG - 2023-01-13 02:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:50:22 --> Input Class Initialized
INFO - 2023-01-13 02:50:22 --> Language Class Initialized
INFO - 2023-01-13 02:50:22 --> Language Class Initialized
INFO - 2023-01-13 02:50:22 --> Config Class Initialized
INFO - 2023-01-13 02:50:22 --> Loader Class Initialized
INFO - 2023-01-13 02:50:22 --> Helper loaded: url_helper
INFO - 2023-01-13 02:50:22 --> Helper loaded: file_helper
INFO - 2023-01-13 02:50:22 --> Helper loaded: form_helper
INFO - 2023-01-13 02:50:22 --> Helper loaded: my_helper
INFO - 2023-01-13 02:50:22 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:50:22 --> Controller Class Initialized
DEBUG - 2023-01-13 02:50:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_kelas/views/list.php
DEBUG - 2023-01-13 02:50:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 02:50:22 --> Final output sent to browser
DEBUG - 2023-01-13 02:50:22 --> Total execution time: 0.0502
INFO - 2023-01-13 02:50:22 --> Config Class Initialized
INFO - 2023-01-13 02:50:22 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:50:22 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:50:22 --> Utf8 Class Initialized
INFO - 2023-01-13 02:50:22 --> URI Class Initialized
INFO - 2023-01-13 02:50:22 --> Router Class Initialized
INFO - 2023-01-13 02:50:22 --> Output Class Initialized
INFO - 2023-01-13 02:50:22 --> Security Class Initialized
DEBUG - 2023-01-13 02:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:50:22 --> Input Class Initialized
INFO - 2023-01-13 02:50:22 --> Language Class Initialized
INFO - 2023-01-13 02:50:22 --> Language Class Initialized
INFO - 2023-01-13 02:50:22 --> Config Class Initialized
INFO - 2023-01-13 02:50:22 --> Loader Class Initialized
INFO - 2023-01-13 02:50:22 --> Helper loaded: url_helper
INFO - 2023-01-13 02:50:22 --> Helper loaded: file_helper
INFO - 2023-01-13 02:50:22 --> Helper loaded: form_helper
INFO - 2023-01-13 02:50:22 --> Helper loaded: my_helper
INFO - 2023-01-13 02:50:22 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:50:22 --> Controller Class Initialized
INFO - 2023-01-13 02:50:24 --> Config Class Initialized
INFO - 2023-01-13 02:50:24 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:50:24 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:50:24 --> Utf8 Class Initialized
INFO - 2023-01-13 02:50:24 --> URI Class Initialized
INFO - 2023-01-13 02:50:24 --> Router Class Initialized
INFO - 2023-01-13 02:50:24 --> Output Class Initialized
INFO - 2023-01-13 02:50:24 --> Security Class Initialized
DEBUG - 2023-01-13 02:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:50:24 --> Input Class Initialized
INFO - 2023-01-13 02:50:24 --> Language Class Initialized
INFO - 2023-01-13 02:50:24 --> Language Class Initialized
INFO - 2023-01-13 02:50:24 --> Config Class Initialized
INFO - 2023-01-13 02:50:24 --> Loader Class Initialized
INFO - 2023-01-13 02:50:24 --> Helper loaded: url_helper
INFO - 2023-01-13 02:50:24 --> Helper loaded: file_helper
INFO - 2023-01-13 02:50:24 --> Helper loaded: form_helper
INFO - 2023-01-13 02:50:24 --> Helper loaded: my_helper
INFO - 2023-01-13 02:50:24 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:50:24 --> Controller Class Initialized
DEBUG - 2023-01-13 02:50:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_mapel/views/list.php
DEBUG - 2023-01-13 02:50:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 02:50:24 --> Final output sent to browser
DEBUG - 2023-01-13 02:50:24 --> Total execution time: 0.0732
INFO - 2023-01-13 02:50:24 --> Config Class Initialized
INFO - 2023-01-13 02:50:24 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:50:24 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:50:24 --> Utf8 Class Initialized
INFO - 2023-01-13 02:50:24 --> URI Class Initialized
INFO - 2023-01-13 02:50:24 --> Router Class Initialized
INFO - 2023-01-13 02:50:24 --> Output Class Initialized
INFO - 2023-01-13 02:50:24 --> Security Class Initialized
DEBUG - 2023-01-13 02:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:50:24 --> Input Class Initialized
INFO - 2023-01-13 02:50:24 --> Language Class Initialized
INFO - 2023-01-13 02:50:24 --> Language Class Initialized
INFO - 2023-01-13 02:50:24 --> Config Class Initialized
INFO - 2023-01-13 02:50:24 --> Loader Class Initialized
INFO - 2023-01-13 02:50:24 --> Helper loaded: url_helper
INFO - 2023-01-13 02:50:24 --> Helper loaded: file_helper
INFO - 2023-01-13 02:50:24 --> Helper loaded: form_helper
INFO - 2023-01-13 02:50:24 --> Helper loaded: my_helper
INFO - 2023-01-13 02:50:24 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:50:24 --> Controller Class Initialized
INFO - 2023-01-13 02:50:27 --> Config Class Initialized
INFO - 2023-01-13 02:50:27 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:50:27 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:50:27 --> Utf8 Class Initialized
INFO - 2023-01-13 02:50:27 --> URI Class Initialized
INFO - 2023-01-13 02:50:27 --> Router Class Initialized
INFO - 2023-01-13 02:50:27 --> Output Class Initialized
INFO - 2023-01-13 02:50:27 --> Security Class Initialized
DEBUG - 2023-01-13 02:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:50:27 --> Input Class Initialized
INFO - 2023-01-13 02:50:27 --> Language Class Initialized
INFO - 2023-01-13 02:50:27 --> Language Class Initialized
INFO - 2023-01-13 02:50:27 --> Config Class Initialized
INFO - 2023-01-13 02:50:27 --> Loader Class Initialized
INFO - 2023-01-13 02:50:27 --> Helper loaded: url_helper
INFO - 2023-01-13 02:50:27 --> Helper loaded: file_helper
INFO - 2023-01-13 02:50:27 --> Helper loaded: form_helper
INFO - 2023-01-13 02:50:27 --> Helper loaded: my_helper
INFO - 2023-01-13 02:50:27 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 02:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 02:50:27 --> Controller Class Initialized
INFO - 2023-01-13 02:50:27 --> Final output sent to browser
DEBUG - 2023-01-13 02:50:27 --> Total execution time: 0.0294
INFO - 2023-01-13 03:01:11 --> Config Class Initialized
INFO - 2023-01-13 03:01:11 --> Hooks Class Initialized
DEBUG - 2023-01-13 03:01:11 --> UTF-8 Support Enabled
INFO - 2023-01-13 03:01:11 --> Utf8 Class Initialized
INFO - 2023-01-13 03:01:11 --> URI Class Initialized
INFO - 2023-01-13 03:01:11 --> Router Class Initialized
INFO - 2023-01-13 03:01:11 --> Output Class Initialized
INFO - 2023-01-13 03:01:11 --> Security Class Initialized
DEBUG - 2023-01-13 03:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 03:01:11 --> Input Class Initialized
INFO - 2023-01-13 03:01:11 --> Language Class Initialized
INFO - 2023-01-13 03:01:11 --> Language Class Initialized
INFO - 2023-01-13 03:01:11 --> Config Class Initialized
INFO - 2023-01-13 03:01:11 --> Loader Class Initialized
INFO - 2023-01-13 03:01:11 --> Helper loaded: url_helper
INFO - 2023-01-13 03:01:11 --> Helper loaded: file_helper
INFO - 2023-01-13 03:01:11 --> Helper loaded: form_helper
INFO - 2023-01-13 03:01:11 --> Helper loaded: my_helper
INFO - 2023-01-13 03:01:11 --> Database Driver Class Initialized
DEBUG - 2023-01-13 03:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 03:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 03:01:11 --> Controller Class Initialized
INFO - 2023-01-13 03:01:11 --> Helper loaded: cookie_helper
INFO - 2023-01-13 03:01:11 --> Config Class Initialized
INFO - 2023-01-13 03:01:11 --> Hooks Class Initialized
DEBUG - 2023-01-13 03:01:11 --> UTF-8 Support Enabled
INFO - 2023-01-13 03:01:11 --> Utf8 Class Initialized
INFO - 2023-01-13 03:01:11 --> URI Class Initialized
INFO - 2023-01-13 03:01:11 --> Router Class Initialized
INFO - 2023-01-13 03:01:11 --> Output Class Initialized
INFO - 2023-01-13 03:01:11 --> Security Class Initialized
DEBUG - 2023-01-13 03:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 03:01:11 --> Input Class Initialized
INFO - 2023-01-13 03:01:11 --> Language Class Initialized
INFO - 2023-01-13 03:01:11 --> Language Class Initialized
INFO - 2023-01-13 03:01:11 --> Config Class Initialized
INFO - 2023-01-13 03:01:11 --> Loader Class Initialized
INFO - 2023-01-13 03:01:11 --> Helper loaded: url_helper
INFO - 2023-01-13 03:01:11 --> Helper loaded: file_helper
INFO - 2023-01-13 03:01:11 --> Helper loaded: form_helper
INFO - 2023-01-13 03:01:11 --> Helper loaded: my_helper
INFO - 2023-01-13 03:01:11 --> Database Driver Class Initialized
DEBUG - 2023-01-13 03:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 03:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 03:01:11 --> Controller Class Initialized
INFO - 2023-01-13 03:01:11 --> Config Class Initialized
INFO - 2023-01-13 03:01:11 --> Hooks Class Initialized
DEBUG - 2023-01-13 03:01:11 --> UTF-8 Support Enabled
INFO - 2023-01-13 03:01:11 --> Utf8 Class Initialized
INFO - 2023-01-13 03:01:11 --> URI Class Initialized
INFO - 2023-01-13 03:01:11 --> Router Class Initialized
INFO - 2023-01-13 03:01:11 --> Output Class Initialized
INFO - 2023-01-13 03:01:11 --> Security Class Initialized
DEBUG - 2023-01-13 03:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 03:01:11 --> Input Class Initialized
INFO - 2023-01-13 03:01:11 --> Language Class Initialized
INFO - 2023-01-13 03:01:11 --> Language Class Initialized
INFO - 2023-01-13 03:01:11 --> Config Class Initialized
INFO - 2023-01-13 03:01:11 --> Loader Class Initialized
INFO - 2023-01-13 03:01:11 --> Helper loaded: url_helper
INFO - 2023-01-13 03:01:11 --> Helper loaded: file_helper
INFO - 2023-01-13 03:01:11 --> Helper loaded: form_helper
INFO - 2023-01-13 03:01:11 --> Helper loaded: my_helper
INFO - 2023-01-13 03:01:11 --> Database Driver Class Initialized
DEBUG - 2023-01-13 03:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 03:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 03:01:11 --> Controller Class Initialized
DEBUG - 2023-01-13 03:01:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-13 03:01:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 03:01:11 --> Final output sent to browser
DEBUG - 2023-01-13 03:01:11 --> Total execution time: 0.0226
INFO - 2023-01-13 03:01:16 --> Config Class Initialized
INFO - 2023-01-13 03:01:16 --> Hooks Class Initialized
DEBUG - 2023-01-13 03:01:16 --> UTF-8 Support Enabled
INFO - 2023-01-13 03:01:16 --> Utf8 Class Initialized
INFO - 2023-01-13 03:01:16 --> URI Class Initialized
INFO - 2023-01-13 03:01:16 --> Router Class Initialized
INFO - 2023-01-13 03:01:16 --> Output Class Initialized
INFO - 2023-01-13 03:01:16 --> Security Class Initialized
DEBUG - 2023-01-13 03:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 03:01:16 --> Input Class Initialized
INFO - 2023-01-13 03:01:16 --> Language Class Initialized
INFO - 2023-01-13 03:01:16 --> Language Class Initialized
INFO - 2023-01-13 03:01:16 --> Config Class Initialized
INFO - 2023-01-13 03:01:16 --> Loader Class Initialized
INFO - 2023-01-13 03:01:16 --> Helper loaded: url_helper
INFO - 2023-01-13 03:01:16 --> Helper loaded: file_helper
INFO - 2023-01-13 03:01:16 --> Helper loaded: form_helper
INFO - 2023-01-13 03:01:16 --> Helper loaded: my_helper
INFO - 2023-01-13 03:01:16 --> Database Driver Class Initialized
DEBUG - 2023-01-13 03:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 03:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 03:01:16 --> Controller Class Initialized
INFO - 2023-01-13 03:01:16 --> Helper loaded: cookie_helper
INFO - 2023-01-13 03:01:16 --> Final output sent to browser
DEBUG - 2023-01-13 03:01:16 --> Total execution time: 0.0243
INFO - 2023-01-13 03:01:16 --> Config Class Initialized
INFO - 2023-01-13 03:01:16 --> Hooks Class Initialized
DEBUG - 2023-01-13 03:01:16 --> UTF-8 Support Enabled
INFO - 2023-01-13 03:01:16 --> Utf8 Class Initialized
INFO - 2023-01-13 03:01:16 --> URI Class Initialized
INFO - 2023-01-13 03:01:16 --> Router Class Initialized
INFO - 2023-01-13 03:01:16 --> Output Class Initialized
INFO - 2023-01-13 03:01:16 --> Security Class Initialized
DEBUG - 2023-01-13 03:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 03:01:16 --> Input Class Initialized
INFO - 2023-01-13 03:01:16 --> Language Class Initialized
INFO - 2023-01-13 03:01:16 --> Language Class Initialized
INFO - 2023-01-13 03:01:16 --> Config Class Initialized
INFO - 2023-01-13 03:01:16 --> Loader Class Initialized
INFO - 2023-01-13 03:01:16 --> Helper loaded: url_helper
INFO - 2023-01-13 03:01:16 --> Helper loaded: file_helper
INFO - 2023-01-13 03:01:16 --> Helper loaded: form_helper
INFO - 2023-01-13 03:01:16 --> Helper loaded: my_helper
INFO - 2023-01-13 03:01:16 --> Database Driver Class Initialized
DEBUG - 2023-01-13 03:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 03:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 03:01:16 --> Controller Class Initialized
DEBUG - 2023-01-13 03:01:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-13 03:01:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 03:01:16 --> Final output sent to browser
DEBUG - 2023-01-13 03:01:16 --> Total execution time: 0.0281
INFO - 2023-01-13 03:01:19 --> Config Class Initialized
INFO - 2023-01-13 03:01:19 --> Hooks Class Initialized
DEBUG - 2023-01-13 03:01:19 --> UTF-8 Support Enabled
INFO - 2023-01-13 03:01:19 --> Utf8 Class Initialized
INFO - 2023-01-13 03:01:19 --> URI Class Initialized
INFO - 2023-01-13 03:01:19 --> Router Class Initialized
INFO - 2023-01-13 03:01:19 --> Output Class Initialized
INFO - 2023-01-13 03:01:19 --> Security Class Initialized
DEBUG - 2023-01-13 03:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 03:01:19 --> Input Class Initialized
INFO - 2023-01-13 03:01:19 --> Language Class Initialized
INFO - 2023-01-13 03:01:19 --> Language Class Initialized
INFO - 2023-01-13 03:01:19 --> Config Class Initialized
INFO - 2023-01-13 03:01:19 --> Loader Class Initialized
INFO - 2023-01-13 03:01:19 --> Helper loaded: url_helper
INFO - 2023-01-13 03:01:19 --> Helper loaded: file_helper
INFO - 2023-01-13 03:01:19 --> Helper loaded: form_helper
INFO - 2023-01-13 03:01:19 --> Helper loaded: my_helper
INFO - 2023-01-13 03:01:19 --> Database Driver Class Initialized
DEBUG - 2023-01-13 03:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 03:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 03:01:19 --> Controller Class Initialized
DEBUG - 2023-01-13 03:01:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-13 03:01:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 03:01:19 --> Final output sent to browser
DEBUG - 2023-01-13 03:01:19 --> Total execution time: 0.0273
INFO - 2023-01-13 03:01:20 --> Config Class Initialized
INFO - 2023-01-13 03:01:20 --> Hooks Class Initialized
DEBUG - 2023-01-13 03:01:20 --> UTF-8 Support Enabled
INFO - 2023-01-13 03:01:20 --> Utf8 Class Initialized
INFO - 2023-01-13 03:01:20 --> URI Class Initialized
INFO - 2023-01-13 03:01:20 --> Router Class Initialized
INFO - 2023-01-13 03:01:20 --> Output Class Initialized
INFO - 2023-01-13 03:01:20 --> Security Class Initialized
DEBUG - 2023-01-13 03:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 03:01:20 --> Input Class Initialized
INFO - 2023-01-13 03:01:20 --> Language Class Initialized
INFO - 2023-01-13 03:01:20 --> Language Class Initialized
INFO - 2023-01-13 03:01:20 --> Config Class Initialized
INFO - 2023-01-13 03:01:20 --> Loader Class Initialized
INFO - 2023-01-13 03:01:20 --> Helper loaded: url_helper
INFO - 2023-01-13 03:01:20 --> Helper loaded: file_helper
INFO - 2023-01-13 03:01:20 --> Helper loaded: form_helper
INFO - 2023-01-13 03:01:20 --> Helper loaded: my_helper
INFO - 2023-01-13 03:01:20 --> Database Driver Class Initialized
DEBUG - 2023-01-13 03:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 03:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 03:01:20 --> Controller Class Initialized
DEBUG - 2023-01-13 03:01:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-01-13 03:01:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 03:01:20 --> Final output sent to browser
DEBUG - 2023-01-13 03:01:20 --> Total execution time: 0.0916
INFO - 2023-01-13 03:01:20 --> Config Class Initialized
INFO - 2023-01-13 03:01:20 --> Hooks Class Initialized
DEBUG - 2023-01-13 03:01:20 --> UTF-8 Support Enabled
INFO - 2023-01-13 03:01:20 --> Utf8 Class Initialized
INFO - 2023-01-13 03:01:20 --> URI Class Initialized
INFO - 2023-01-13 03:01:20 --> Router Class Initialized
INFO - 2023-01-13 03:01:20 --> Output Class Initialized
INFO - 2023-01-13 03:01:20 --> Security Class Initialized
DEBUG - 2023-01-13 03:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 03:01:20 --> Input Class Initialized
INFO - 2023-01-13 03:01:20 --> Language Class Initialized
INFO - 2023-01-13 03:01:20 --> Language Class Initialized
INFO - 2023-01-13 03:01:20 --> Config Class Initialized
INFO - 2023-01-13 03:01:20 --> Loader Class Initialized
INFO - 2023-01-13 03:01:20 --> Helper loaded: url_helper
INFO - 2023-01-13 03:01:20 --> Helper loaded: file_helper
INFO - 2023-01-13 03:01:20 --> Helper loaded: form_helper
INFO - 2023-01-13 03:01:20 --> Helper loaded: my_helper
INFO - 2023-01-13 03:01:20 --> Database Driver Class Initialized
DEBUG - 2023-01-13 03:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 03:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 03:01:20 --> Controller Class Initialized
INFO - 2023-01-13 03:01:20 --> Final output sent to browser
DEBUG - 2023-01-13 03:01:20 --> Total execution time: 0.0557
INFO - 2023-01-13 03:01:30 --> Config Class Initialized
INFO - 2023-01-13 03:01:30 --> Hooks Class Initialized
DEBUG - 2023-01-13 03:01:30 --> UTF-8 Support Enabled
INFO - 2023-01-13 03:01:30 --> Utf8 Class Initialized
INFO - 2023-01-13 03:01:30 --> URI Class Initialized
INFO - 2023-01-13 03:01:30 --> Router Class Initialized
INFO - 2023-01-13 03:01:30 --> Output Class Initialized
INFO - 2023-01-13 03:01:30 --> Security Class Initialized
DEBUG - 2023-01-13 03:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 03:01:30 --> Input Class Initialized
INFO - 2023-01-13 03:01:30 --> Language Class Initialized
INFO - 2023-01-13 03:01:30 --> Language Class Initialized
INFO - 2023-01-13 03:01:30 --> Config Class Initialized
INFO - 2023-01-13 03:01:30 --> Loader Class Initialized
INFO - 2023-01-13 03:01:30 --> Helper loaded: url_helper
INFO - 2023-01-13 03:01:30 --> Helper loaded: file_helper
INFO - 2023-01-13 03:01:30 --> Helper loaded: form_helper
INFO - 2023-01-13 03:01:30 --> Helper loaded: my_helper
INFO - 2023-01-13 03:01:30 --> Database Driver Class Initialized
DEBUG - 2023-01-13 03:01:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 03:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 03:01:30 --> Controller Class Initialized
INFO - 2023-01-13 03:28:43 --> Config Class Initialized
INFO - 2023-01-13 03:28:43 --> Hooks Class Initialized
DEBUG - 2023-01-13 03:28:43 --> UTF-8 Support Enabled
INFO - 2023-01-13 03:28:43 --> Utf8 Class Initialized
INFO - 2023-01-13 03:28:43 --> URI Class Initialized
INFO - 2023-01-13 03:28:43 --> Router Class Initialized
INFO - 2023-01-13 03:28:43 --> Output Class Initialized
INFO - 2023-01-13 03:28:43 --> Security Class Initialized
DEBUG - 2023-01-13 03:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 03:28:43 --> Input Class Initialized
INFO - 2023-01-13 03:28:43 --> Language Class Initialized
INFO - 2023-01-13 03:28:43 --> Language Class Initialized
INFO - 2023-01-13 03:28:43 --> Config Class Initialized
INFO - 2023-01-13 03:28:43 --> Loader Class Initialized
INFO - 2023-01-13 03:28:43 --> Helper loaded: url_helper
INFO - 2023-01-13 03:28:43 --> Helper loaded: file_helper
INFO - 2023-01-13 03:28:43 --> Helper loaded: form_helper
INFO - 2023-01-13 03:28:43 --> Helper loaded: my_helper
INFO - 2023-01-13 03:28:43 --> Database Driver Class Initialized
DEBUG - 2023-01-13 03:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 03:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 03:28:44 --> Controller Class Initialized
DEBUG - 2023-01-13 03:28:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-13 03:28:45 --> Final output sent to browser
DEBUG - 2023-01-13 03:28:45 --> Total execution time: 1.1677
INFO - 2023-01-13 03:29:06 --> Config Class Initialized
INFO - 2023-01-13 03:29:06 --> Hooks Class Initialized
DEBUG - 2023-01-13 03:29:06 --> UTF-8 Support Enabled
INFO - 2023-01-13 03:29:06 --> Utf8 Class Initialized
INFO - 2023-01-13 03:29:06 --> URI Class Initialized
INFO - 2023-01-13 03:29:06 --> Router Class Initialized
INFO - 2023-01-13 03:29:06 --> Output Class Initialized
INFO - 2023-01-13 03:29:06 --> Security Class Initialized
DEBUG - 2023-01-13 03:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 03:29:06 --> Input Class Initialized
INFO - 2023-01-13 03:29:06 --> Language Class Initialized
INFO - 2023-01-13 03:29:06 --> Language Class Initialized
INFO - 2023-01-13 03:29:06 --> Config Class Initialized
INFO - 2023-01-13 03:29:06 --> Loader Class Initialized
INFO - 2023-01-13 03:29:06 --> Helper loaded: url_helper
INFO - 2023-01-13 03:29:06 --> Helper loaded: file_helper
INFO - 2023-01-13 03:29:06 --> Helper loaded: form_helper
INFO - 2023-01-13 03:29:06 --> Helper loaded: my_helper
INFO - 2023-01-13 03:29:06 --> Database Driver Class Initialized
DEBUG - 2023-01-13 03:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 03:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 03:29:06 --> Controller Class Initialized
INFO - 2023-01-13 03:29:06 --> Final output sent to browser
DEBUG - 2023-01-13 03:29:06 --> Total execution time: 0.0274
INFO - 2023-01-13 03:29:09 --> Config Class Initialized
INFO - 2023-01-13 03:29:09 --> Hooks Class Initialized
DEBUG - 2023-01-13 03:29:09 --> UTF-8 Support Enabled
INFO - 2023-01-13 03:29:09 --> Utf8 Class Initialized
INFO - 2023-01-13 03:29:09 --> URI Class Initialized
INFO - 2023-01-13 03:29:09 --> Router Class Initialized
INFO - 2023-01-13 03:29:09 --> Output Class Initialized
INFO - 2023-01-13 03:29:09 --> Security Class Initialized
DEBUG - 2023-01-13 03:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 03:29:09 --> Input Class Initialized
INFO - 2023-01-13 03:29:09 --> Language Class Initialized
INFO - 2023-01-13 03:29:09 --> Language Class Initialized
INFO - 2023-01-13 03:29:09 --> Config Class Initialized
INFO - 2023-01-13 03:29:09 --> Loader Class Initialized
INFO - 2023-01-13 03:29:09 --> Helper loaded: url_helper
INFO - 2023-01-13 03:29:09 --> Helper loaded: file_helper
INFO - 2023-01-13 03:29:09 --> Helper loaded: form_helper
INFO - 2023-01-13 03:29:09 --> Helper loaded: my_helper
INFO - 2023-01-13 03:29:09 --> Database Driver Class Initialized
DEBUG - 2023-01-13 03:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 03:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 03:29:09 --> Controller Class Initialized
DEBUG - 2023-01-13 03:29:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-13 03:29:11 --> Final output sent to browser
DEBUG - 2023-01-13 03:29:11 --> Total execution time: 1.1506
INFO - 2023-01-13 03:29:22 --> Config Class Initialized
INFO - 2023-01-13 03:29:22 --> Hooks Class Initialized
DEBUG - 2023-01-13 03:29:22 --> UTF-8 Support Enabled
INFO - 2023-01-13 03:29:22 --> Utf8 Class Initialized
INFO - 2023-01-13 03:29:22 --> URI Class Initialized
INFO - 2023-01-13 03:29:22 --> Router Class Initialized
INFO - 2023-01-13 03:29:22 --> Output Class Initialized
INFO - 2023-01-13 03:29:22 --> Security Class Initialized
DEBUG - 2023-01-13 03:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 03:29:22 --> Input Class Initialized
INFO - 2023-01-13 03:29:22 --> Language Class Initialized
INFO - 2023-01-13 03:29:22 --> Language Class Initialized
INFO - 2023-01-13 03:29:22 --> Config Class Initialized
INFO - 2023-01-13 03:29:22 --> Loader Class Initialized
INFO - 2023-01-13 03:29:22 --> Helper loaded: url_helper
INFO - 2023-01-13 03:29:22 --> Helper loaded: file_helper
INFO - 2023-01-13 03:29:22 --> Helper loaded: form_helper
INFO - 2023-01-13 03:29:22 --> Helper loaded: my_helper
INFO - 2023-01-13 03:29:22 --> Database Driver Class Initialized
DEBUG - 2023-01-13 03:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 03:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 03:29:22 --> Controller Class Initialized
DEBUG - 2023-01-13 03:29:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-01-13 03:29:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 03:29:22 --> Final output sent to browser
DEBUG - 2023-01-13 03:29:22 --> Total execution time: 0.0451
INFO - 2023-01-13 03:29:23 --> Config Class Initialized
INFO - 2023-01-13 03:29:23 --> Hooks Class Initialized
DEBUG - 2023-01-13 03:29:23 --> UTF-8 Support Enabled
INFO - 2023-01-13 03:29:23 --> Utf8 Class Initialized
INFO - 2023-01-13 03:29:23 --> URI Class Initialized
INFO - 2023-01-13 03:29:23 --> Router Class Initialized
INFO - 2023-01-13 03:29:23 --> Output Class Initialized
INFO - 2023-01-13 03:29:23 --> Security Class Initialized
DEBUG - 2023-01-13 03:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 03:29:23 --> Input Class Initialized
INFO - 2023-01-13 03:29:23 --> Language Class Initialized
INFO - 2023-01-13 03:29:23 --> Language Class Initialized
INFO - 2023-01-13 03:29:23 --> Config Class Initialized
INFO - 2023-01-13 03:29:23 --> Loader Class Initialized
INFO - 2023-01-13 03:29:23 --> Helper loaded: url_helper
INFO - 2023-01-13 03:29:23 --> Helper loaded: file_helper
INFO - 2023-01-13 03:29:23 --> Helper loaded: form_helper
INFO - 2023-01-13 03:29:23 --> Helper loaded: my_helper
INFO - 2023-01-13 03:29:23 --> Database Driver Class Initialized
DEBUG - 2023-01-13 03:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 03:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 03:29:23 --> Controller Class Initialized
INFO - 2023-01-13 03:29:23 --> Final output sent to browser
DEBUG - 2023-01-13 03:29:23 --> Total execution time: 0.0470
INFO - 2023-01-13 03:29:24 --> Config Class Initialized
INFO - 2023-01-13 03:29:24 --> Hooks Class Initialized
DEBUG - 2023-01-13 03:29:24 --> UTF-8 Support Enabled
INFO - 2023-01-13 03:29:24 --> Utf8 Class Initialized
INFO - 2023-01-13 03:29:24 --> URI Class Initialized
INFO - 2023-01-13 03:29:24 --> Router Class Initialized
INFO - 2023-01-13 03:29:24 --> Output Class Initialized
INFO - 2023-01-13 03:29:24 --> Security Class Initialized
DEBUG - 2023-01-13 03:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 03:29:24 --> Input Class Initialized
INFO - 2023-01-13 03:29:24 --> Language Class Initialized
INFO - 2023-01-13 03:29:24 --> Language Class Initialized
INFO - 2023-01-13 03:29:24 --> Config Class Initialized
INFO - 2023-01-13 03:29:24 --> Loader Class Initialized
INFO - 2023-01-13 03:29:24 --> Helper loaded: url_helper
INFO - 2023-01-13 03:29:24 --> Helper loaded: file_helper
INFO - 2023-01-13 03:29:24 --> Helper loaded: form_helper
INFO - 2023-01-13 03:29:24 --> Helper loaded: my_helper
INFO - 2023-01-13 03:29:24 --> Database Driver Class Initialized
DEBUG - 2023-01-13 03:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 03:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 03:29:24 --> Controller Class Initialized
INFO - 2023-01-13 03:29:30 --> Config Class Initialized
INFO - 2023-01-13 03:29:30 --> Hooks Class Initialized
DEBUG - 2023-01-13 03:29:30 --> UTF-8 Support Enabled
INFO - 2023-01-13 03:29:30 --> Utf8 Class Initialized
INFO - 2023-01-13 03:29:30 --> URI Class Initialized
INFO - 2023-01-13 03:29:30 --> Router Class Initialized
INFO - 2023-01-13 03:29:30 --> Output Class Initialized
INFO - 2023-01-13 03:29:30 --> Security Class Initialized
DEBUG - 2023-01-13 03:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 03:29:30 --> Input Class Initialized
INFO - 2023-01-13 03:29:30 --> Language Class Initialized
INFO - 2023-01-13 03:29:30 --> Language Class Initialized
INFO - 2023-01-13 03:29:30 --> Config Class Initialized
INFO - 2023-01-13 03:29:30 --> Loader Class Initialized
INFO - 2023-01-13 03:29:30 --> Helper loaded: url_helper
INFO - 2023-01-13 03:29:30 --> Helper loaded: file_helper
INFO - 2023-01-13 03:29:30 --> Helper loaded: form_helper
INFO - 2023-01-13 03:29:30 --> Helper loaded: my_helper
INFO - 2023-01-13 03:29:30 --> Database Driver Class Initialized
DEBUG - 2023-01-13 03:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 03:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 03:29:30 --> Controller Class Initialized
INFO - 2023-01-13 03:29:30 --> Helper loaded: cookie_helper
INFO - 2023-01-13 03:29:30 --> Config Class Initialized
INFO - 2023-01-13 03:29:30 --> Hooks Class Initialized
DEBUG - 2023-01-13 03:29:30 --> UTF-8 Support Enabled
INFO - 2023-01-13 03:29:30 --> Utf8 Class Initialized
INFO - 2023-01-13 03:29:30 --> URI Class Initialized
INFO - 2023-01-13 03:29:30 --> Router Class Initialized
INFO - 2023-01-13 03:29:30 --> Output Class Initialized
INFO - 2023-01-13 03:29:30 --> Security Class Initialized
DEBUG - 2023-01-13 03:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 03:29:30 --> Input Class Initialized
INFO - 2023-01-13 03:29:30 --> Language Class Initialized
INFO - 2023-01-13 03:29:30 --> Language Class Initialized
INFO - 2023-01-13 03:29:30 --> Config Class Initialized
INFO - 2023-01-13 03:29:30 --> Loader Class Initialized
INFO - 2023-01-13 03:29:30 --> Helper loaded: url_helper
INFO - 2023-01-13 03:29:30 --> Helper loaded: file_helper
INFO - 2023-01-13 03:29:30 --> Helper loaded: form_helper
INFO - 2023-01-13 03:29:30 --> Helper loaded: my_helper
INFO - 2023-01-13 03:29:30 --> Database Driver Class Initialized
DEBUG - 2023-01-13 03:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 03:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 03:29:30 --> Controller Class Initialized
INFO - 2023-01-13 03:29:30 --> Config Class Initialized
INFO - 2023-01-13 03:29:30 --> Hooks Class Initialized
DEBUG - 2023-01-13 03:29:30 --> UTF-8 Support Enabled
INFO - 2023-01-13 03:29:30 --> Utf8 Class Initialized
INFO - 2023-01-13 03:29:30 --> URI Class Initialized
INFO - 2023-01-13 03:29:30 --> Router Class Initialized
INFO - 2023-01-13 03:29:30 --> Output Class Initialized
INFO - 2023-01-13 03:29:30 --> Security Class Initialized
DEBUG - 2023-01-13 03:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 03:29:30 --> Input Class Initialized
INFO - 2023-01-13 03:29:30 --> Language Class Initialized
INFO - 2023-01-13 03:29:30 --> Language Class Initialized
INFO - 2023-01-13 03:29:30 --> Config Class Initialized
INFO - 2023-01-13 03:29:30 --> Loader Class Initialized
INFO - 2023-01-13 03:29:30 --> Helper loaded: url_helper
INFO - 2023-01-13 03:29:30 --> Helper loaded: file_helper
INFO - 2023-01-13 03:29:30 --> Helper loaded: form_helper
INFO - 2023-01-13 03:29:30 --> Helper loaded: my_helper
INFO - 2023-01-13 03:29:30 --> Database Driver Class Initialized
DEBUG - 2023-01-13 03:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 03:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 03:29:30 --> Controller Class Initialized
DEBUG - 2023-01-13 03:29:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-13 03:29:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 03:29:30 --> Final output sent to browser
DEBUG - 2023-01-13 03:29:30 --> Total execution time: 0.0436
INFO - 2023-01-13 03:29:39 --> Config Class Initialized
INFO - 2023-01-13 03:29:39 --> Hooks Class Initialized
DEBUG - 2023-01-13 03:29:39 --> UTF-8 Support Enabled
INFO - 2023-01-13 03:29:39 --> Utf8 Class Initialized
INFO - 2023-01-13 03:29:39 --> URI Class Initialized
INFO - 2023-01-13 03:29:39 --> Router Class Initialized
INFO - 2023-01-13 03:29:39 --> Output Class Initialized
INFO - 2023-01-13 03:29:39 --> Security Class Initialized
DEBUG - 2023-01-13 03:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 03:29:39 --> Input Class Initialized
INFO - 2023-01-13 03:29:39 --> Language Class Initialized
INFO - 2023-01-13 03:29:39 --> Language Class Initialized
INFO - 2023-01-13 03:29:39 --> Config Class Initialized
INFO - 2023-01-13 03:29:39 --> Loader Class Initialized
INFO - 2023-01-13 03:29:39 --> Helper loaded: url_helper
INFO - 2023-01-13 03:29:39 --> Helper loaded: file_helper
INFO - 2023-01-13 03:29:39 --> Helper loaded: form_helper
INFO - 2023-01-13 03:29:39 --> Helper loaded: my_helper
INFO - 2023-01-13 03:29:39 --> Database Driver Class Initialized
DEBUG - 2023-01-13 03:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 03:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 03:29:39 --> Controller Class Initialized
INFO - 2023-01-13 03:29:39 --> Helper loaded: cookie_helper
INFO - 2023-01-13 03:29:39 --> Final output sent to browser
DEBUG - 2023-01-13 03:29:39 --> Total execution time: 0.0492
INFO - 2023-01-13 03:29:39 --> Config Class Initialized
INFO - 2023-01-13 03:29:39 --> Hooks Class Initialized
DEBUG - 2023-01-13 03:29:39 --> UTF-8 Support Enabled
INFO - 2023-01-13 03:29:39 --> Utf8 Class Initialized
INFO - 2023-01-13 03:29:39 --> URI Class Initialized
INFO - 2023-01-13 03:29:39 --> Router Class Initialized
INFO - 2023-01-13 03:29:39 --> Output Class Initialized
INFO - 2023-01-13 03:29:39 --> Security Class Initialized
DEBUG - 2023-01-13 03:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 03:29:39 --> Input Class Initialized
INFO - 2023-01-13 03:29:39 --> Language Class Initialized
INFO - 2023-01-13 03:29:39 --> Language Class Initialized
INFO - 2023-01-13 03:29:39 --> Config Class Initialized
INFO - 2023-01-13 03:29:39 --> Loader Class Initialized
INFO - 2023-01-13 03:29:39 --> Helper loaded: url_helper
INFO - 2023-01-13 03:29:39 --> Helper loaded: file_helper
INFO - 2023-01-13 03:29:39 --> Helper loaded: form_helper
INFO - 2023-01-13 03:29:39 --> Helper loaded: my_helper
INFO - 2023-01-13 03:29:39 --> Database Driver Class Initialized
DEBUG - 2023-01-13 03:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 03:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 03:29:39 --> Controller Class Initialized
DEBUG - 2023-01-13 03:29:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-13 03:29:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 03:29:39 --> Final output sent to browser
DEBUG - 2023-01-13 03:29:39 --> Total execution time: 0.0524
INFO - 2023-01-13 03:29:41 --> Config Class Initialized
INFO - 2023-01-13 03:29:41 --> Hooks Class Initialized
DEBUG - 2023-01-13 03:29:41 --> UTF-8 Support Enabled
INFO - 2023-01-13 03:29:41 --> Utf8 Class Initialized
INFO - 2023-01-13 03:29:41 --> URI Class Initialized
INFO - 2023-01-13 03:29:41 --> Router Class Initialized
INFO - 2023-01-13 03:29:41 --> Output Class Initialized
INFO - 2023-01-13 03:29:41 --> Security Class Initialized
DEBUG - 2023-01-13 03:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 03:29:41 --> Input Class Initialized
INFO - 2023-01-13 03:29:41 --> Language Class Initialized
INFO - 2023-01-13 03:29:41 --> Language Class Initialized
INFO - 2023-01-13 03:29:41 --> Config Class Initialized
INFO - 2023-01-13 03:29:41 --> Loader Class Initialized
INFO - 2023-01-13 03:29:41 --> Helper loaded: url_helper
INFO - 2023-01-13 03:29:41 --> Helper loaded: file_helper
INFO - 2023-01-13 03:29:41 --> Helper loaded: form_helper
INFO - 2023-01-13 03:29:41 --> Helper loaded: my_helper
INFO - 2023-01-13 03:29:41 --> Database Driver Class Initialized
DEBUG - 2023-01-13 03:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 03:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 03:29:41 --> Controller Class Initialized
DEBUG - 2023-01-13 03:29:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-01-13 03:29:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 03:29:41 --> Final output sent to browser
DEBUG - 2023-01-13 03:29:41 --> Total execution time: 0.0658
INFO - 2023-01-13 03:29:43 --> Config Class Initialized
INFO - 2023-01-13 03:29:43 --> Hooks Class Initialized
DEBUG - 2023-01-13 03:29:43 --> UTF-8 Support Enabled
INFO - 2023-01-13 03:29:43 --> Utf8 Class Initialized
INFO - 2023-01-13 03:29:43 --> URI Class Initialized
INFO - 2023-01-13 03:29:43 --> Router Class Initialized
INFO - 2023-01-13 03:29:43 --> Output Class Initialized
INFO - 2023-01-13 03:29:43 --> Security Class Initialized
DEBUG - 2023-01-13 03:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 03:29:43 --> Input Class Initialized
INFO - 2023-01-13 03:29:43 --> Language Class Initialized
INFO - 2023-01-13 03:29:43 --> Language Class Initialized
INFO - 2023-01-13 03:29:43 --> Config Class Initialized
INFO - 2023-01-13 03:29:43 --> Loader Class Initialized
INFO - 2023-01-13 03:29:43 --> Helper loaded: url_helper
INFO - 2023-01-13 03:29:43 --> Helper loaded: file_helper
INFO - 2023-01-13 03:29:43 --> Helper loaded: form_helper
INFO - 2023-01-13 03:29:43 --> Helper loaded: my_helper
INFO - 2023-01-13 03:29:43 --> Database Driver Class Initialized
DEBUG - 2023-01-13 03:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 03:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 03:29:43 --> Controller Class Initialized
DEBUG - 2023-01-13 03:29:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-13 03:29:44 --> Final output sent to browser
DEBUG - 2023-01-13 03:29:44 --> Total execution time: 1.1173
INFO - 2023-01-13 04:59:30 --> Config Class Initialized
INFO - 2023-01-13 04:59:30 --> Hooks Class Initialized
DEBUG - 2023-01-13 04:59:30 --> UTF-8 Support Enabled
INFO - 2023-01-13 04:59:30 --> Utf8 Class Initialized
INFO - 2023-01-13 04:59:30 --> URI Class Initialized
DEBUG - 2023-01-13 04:59:30 --> No URI present. Default controller set.
INFO - 2023-01-13 04:59:30 --> Router Class Initialized
INFO - 2023-01-13 04:59:30 --> Output Class Initialized
INFO - 2023-01-13 04:59:30 --> Security Class Initialized
DEBUG - 2023-01-13 04:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 04:59:30 --> Input Class Initialized
INFO - 2023-01-13 04:59:30 --> Language Class Initialized
INFO - 2023-01-13 04:59:30 --> Language Class Initialized
INFO - 2023-01-13 04:59:30 --> Config Class Initialized
INFO - 2023-01-13 04:59:30 --> Loader Class Initialized
INFO - 2023-01-13 04:59:30 --> Helper loaded: url_helper
INFO - 2023-01-13 04:59:30 --> Helper loaded: file_helper
INFO - 2023-01-13 04:59:30 --> Helper loaded: form_helper
INFO - 2023-01-13 04:59:30 --> Helper loaded: my_helper
INFO - 2023-01-13 04:59:30 --> Database Driver Class Initialized
DEBUG - 2023-01-13 04:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 04:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 04:59:30 --> Controller Class Initialized
DEBUG - 2023-01-13 04:59:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-13 04:59:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 04:59:30 --> Final output sent to browser
DEBUG - 2023-01-13 04:59:30 --> Total execution time: 0.0563
INFO - 2023-01-13 04:59:34 --> Config Class Initialized
INFO - 2023-01-13 04:59:34 --> Hooks Class Initialized
DEBUG - 2023-01-13 04:59:34 --> UTF-8 Support Enabled
INFO - 2023-01-13 04:59:34 --> Utf8 Class Initialized
INFO - 2023-01-13 04:59:34 --> URI Class Initialized
INFO - 2023-01-13 04:59:34 --> Router Class Initialized
INFO - 2023-01-13 04:59:34 --> Output Class Initialized
INFO - 2023-01-13 04:59:34 --> Security Class Initialized
DEBUG - 2023-01-13 04:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 04:59:34 --> Input Class Initialized
INFO - 2023-01-13 04:59:34 --> Language Class Initialized
INFO - 2023-01-13 04:59:34 --> Language Class Initialized
INFO - 2023-01-13 04:59:34 --> Config Class Initialized
INFO - 2023-01-13 04:59:34 --> Loader Class Initialized
INFO - 2023-01-13 04:59:34 --> Helper loaded: url_helper
INFO - 2023-01-13 04:59:34 --> Helper loaded: file_helper
INFO - 2023-01-13 04:59:34 --> Helper loaded: form_helper
INFO - 2023-01-13 04:59:34 --> Helper loaded: my_helper
INFO - 2023-01-13 04:59:34 --> Database Driver Class Initialized
DEBUG - 2023-01-13 04:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 04:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 04:59:34 --> Controller Class Initialized
DEBUG - 2023-01-13 04:59:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2023-01-13 04:59:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 04:59:34 --> Final output sent to browser
DEBUG - 2023-01-13 04:59:34 --> Total execution time: 0.0931
INFO - 2023-01-13 04:59:38 --> Config Class Initialized
INFO - 2023-01-13 04:59:38 --> Hooks Class Initialized
DEBUG - 2023-01-13 04:59:38 --> UTF-8 Support Enabled
INFO - 2023-01-13 04:59:38 --> Utf8 Class Initialized
INFO - 2023-01-13 04:59:38 --> URI Class Initialized
INFO - 2023-01-13 04:59:38 --> Router Class Initialized
INFO - 2023-01-13 04:59:38 --> Output Class Initialized
INFO - 2023-01-13 04:59:38 --> Security Class Initialized
DEBUG - 2023-01-13 04:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 04:59:38 --> Input Class Initialized
INFO - 2023-01-13 04:59:38 --> Language Class Initialized
INFO - 2023-01-13 04:59:38 --> Language Class Initialized
INFO - 2023-01-13 04:59:38 --> Config Class Initialized
INFO - 2023-01-13 04:59:38 --> Loader Class Initialized
INFO - 2023-01-13 04:59:38 --> Helper loaded: url_helper
INFO - 2023-01-13 04:59:38 --> Helper loaded: file_helper
INFO - 2023-01-13 04:59:38 --> Helper loaded: form_helper
INFO - 2023-01-13 04:59:38 --> Helper loaded: my_helper
INFO - 2023-01-13 04:59:38 --> Database Driver Class Initialized
DEBUG - 2023-01-13 04:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 04:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 04:59:38 --> Controller Class Initialized
DEBUG - 2023-01-13 04:59:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-13 04:59:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 04:59:38 --> Final output sent to browser
DEBUG - 2023-01-13 04:59:38 --> Total execution time: 0.0278
INFO - 2023-01-13 04:59:40 --> Config Class Initialized
INFO - 2023-01-13 04:59:40 --> Hooks Class Initialized
DEBUG - 2023-01-13 04:59:40 --> UTF-8 Support Enabled
INFO - 2023-01-13 04:59:40 --> Utf8 Class Initialized
INFO - 2023-01-13 04:59:40 --> URI Class Initialized
INFO - 2023-01-13 04:59:40 --> Router Class Initialized
INFO - 2023-01-13 04:59:40 --> Output Class Initialized
INFO - 2023-01-13 04:59:40 --> Security Class Initialized
DEBUG - 2023-01-13 04:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 04:59:40 --> Input Class Initialized
INFO - 2023-01-13 04:59:40 --> Language Class Initialized
INFO - 2023-01-13 04:59:40 --> Language Class Initialized
INFO - 2023-01-13 04:59:40 --> Config Class Initialized
INFO - 2023-01-13 04:59:40 --> Loader Class Initialized
INFO - 2023-01-13 04:59:40 --> Helper loaded: url_helper
INFO - 2023-01-13 04:59:40 --> Helper loaded: file_helper
INFO - 2023-01-13 04:59:40 --> Helper loaded: form_helper
INFO - 2023-01-13 04:59:40 --> Helper loaded: my_helper
INFO - 2023-01-13 04:59:40 --> Database Driver Class Initialized
DEBUG - 2023-01-13 04:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 04:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 04:59:40 --> Controller Class Initialized
INFO - 2023-01-13 04:59:40 --> Helper loaded: cookie_helper
INFO - 2023-01-13 04:59:40 --> Config Class Initialized
INFO - 2023-01-13 04:59:40 --> Hooks Class Initialized
DEBUG - 2023-01-13 04:59:40 --> UTF-8 Support Enabled
INFO - 2023-01-13 04:59:40 --> Utf8 Class Initialized
INFO - 2023-01-13 04:59:40 --> URI Class Initialized
INFO - 2023-01-13 04:59:40 --> Router Class Initialized
INFO - 2023-01-13 04:59:40 --> Output Class Initialized
INFO - 2023-01-13 04:59:40 --> Security Class Initialized
DEBUG - 2023-01-13 04:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 04:59:40 --> Input Class Initialized
INFO - 2023-01-13 04:59:40 --> Language Class Initialized
INFO - 2023-01-13 04:59:40 --> Language Class Initialized
INFO - 2023-01-13 04:59:40 --> Config Class Initialized
INFO - 2023-01-13 04:59:40 --> Loader Class Initialized
INFO - 2023-01-13 04:59:40 --> Helper loaded: url_helper
INFO - 2023-01-13 04:59:40 --> Helper loaded: file_helper
INFO - 2023-01-13 04:59:40 --> Helper loaded: form_helper
INFO - 2023-01-13 04:59:40 --> Helper loaded: my_helper
INFO - 2023-01-13 04:59:40 --> Database Driver Class Initialized
DEBUG - 2023-01-13 04:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 04:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 04:59:40 --> Controller Class Initialized
INFO - 2023-01-13 04:59:40 --> Config Class Initialized
INFO - 2023-01-13 04:59:40 --> Hooks Class Initialized
DEBUG - 2023-01-13 04:59:40 --> UTF-8 Support Enabled
INFO - 2023-01-13 04:59:40 --> Utf8 Class Initialized
INFO - 2023-01-13 04:59:40 --> URI Class Initialized
INFO - 2023-01-13 04:59:40 --> Router Class Initialized
INFO - 2023-01-13 04:59:40 --> Output Class Initialized
INFO - 2023-01-13 04:59:40 --> Security Class Initialized
DEBUG - 2023-01-13 04:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 04:59:40 --> Input Class Initialized
INFO - 2023-01-13 04:59:40 --> Language Class Initialized
INFO - 2023-01-13 04:59:40 --> Language Class Initialized
INFO - 2023-01-13 04:59:40 --> Config Class Initialized
INFO - 2023-01-13 04:59:40 --> Loader Class Initialized
INFO - 2023-01-13 04:59:40 --> Helper loaded: url_helper
INFO - 2023-01-13 04:59:40 --> Helper loaded: file_helper
INFO - 2023-01-13 04:59:40 --> Helper loaded: form_helper
INFO - 2023-01-13 04:59:40 --> Helper loaded: my_helper
INFO - 2023-01-13 04:59:40 --> Database Driver Class Initialized
DEBUG - 2023-01-13 04:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 04:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 04:59:40 --> Controller Class Initialized
DEBUG - 2023-01-13 04:59:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-13 04:59:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 04:59:40 --> Final output sent to browser
DEBUG - 2023-01-13 04:59:40 --> Total execution time: 0.0236
INFO - 2023-01-13 04:59:43 --> Config Class Initialized
INFO - 2023-01-13 04:59:43 --> Hooks Class Initialized
DEBUG - 2023-01-13 04:59:43 --> UTF-8 Support Enabled
INFO - 2023-01-13 04:59:43 --> Utf8 Class Initialized
INFO - 2023-01-13 04:59:43 --> URI Class Initialized
INFO - 2023-01-13 04:59:43 --> Router Class Initialized
INFO - 2023-01-13 04:59:44 --> Output Class Initialized
INFO - 2023-01-13 04:59:44 --> Security Class Initialized
DEBUG - 2023-01-13 04:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 04:59:44 --> Input Class Initialized
INFO - 2023-01-13 04:59:44 --> Language Class Initialized
INFO - 2023-01-13 04:59:44 --> Language Class Initialized
INFO - 2023-01-13 04:59:44 --> Config Class Initialized
INFO - 2023-01-13 04:59:44 --> Loader Class Initialized
INFO - 2023-01-13 04:59:44 --> Helper loaded: url_helper
INFO - 2023-01-13 04:59:44 --> Helper loaded: file_helper
INFO - 2023-01-13 04:59:44 --> Helper loaded: form_helper
INFO - 2023-01-13 04:59:44 --> Helper loaded: my_helper
INFO - 2023-01-13 04:59:44 --> Database Driver Class Initialized
DEBUG - 2023-01-13 04:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 04:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 04:59:44 --> Controller Class Initialized
INFO - 2023-01-13 04:59:44 --> Helper loaded: cookie_helper
INFO - 2023-01-13 04:59:44 --> Final output sent to browser
DEBUG - 2023-01-13 04:59:44 --> Total execution time: 0.0457
INFO - 2023-01-13 04:59:44 --> Config Class Initialized
INFO - 2023-01-13 04:59:44 --> Hooks Class Initialized
DEBUG - 2023-01-13 04:59:44 --> UTF-8 Support Enabled
INFO - 2023-01-13 04:59:44 --> Utf8 Class Initialized
INFO - 2023-01-13 04:59:44 --> URI Class Initialized
INFO - 2023-01-13 04:59:44 --> Router Class Initialized
INFO - 2023-01-13 04:59:44 --> Output Class Initialized
INFO - 2023-01-13 04:59:44 --> Security Class Initialized
DEBUG - 2023-01-13 04:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 04:59:44 --> Input Class Initialized
INFO - 2023-01-13 04:59:44 --> Language Class Initialized
INFO - 2023-01-13 04:59:44 --> Language Class Initialized
INFO - 2023-01-13 04:59:44 --> Config Class Initialized
INFO - 2023-01-13 04:59:44 --> Loader Class Initialized
INFO - 2023-01-13 04:59:44 --> Helper loaded: url_helper
INFO - 2023-01-13 04:59:44 --> Helper loaded: file_helper
INFO - 2023-01-13 04:59:44 --> Helper loaded: form_helper
INFO - 2023-01-13 04:59:44 --> Helper loaded: my_helper
INFO - 2023-01-13 04:59:44 --> Database Driver Class Initialized
DEBUG - 2023-01-13 04:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 04:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 04:59:44 --> Controller Class Initialized
DEBUG - 2023-01-13 04:59:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-01-13 04:59:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 04:59:44 --> Final output sent to browser
DEBUG - 2023-01-13 04:59:44 --> Total execution time: 0.0279
INFO - 2023-01-13 10:51:09 --> Config Class Initialized
INFO - 2023-01-13 10:51:09 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:51:09 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:51:09 --> Utf8 Class Initialized
INFO - 2023-01-13 10:51:09 --> URI Class Initialized
DEBUG - 2023-01-13 10:51:09 --> No URI present. Default controller set.
INFO - 2023-01-13 10:51:09 --> Router Class Initialized
INFO - 2023-01-13 10:51:09 --> Output Class Initialized
INFO - 2023-01-13 10:51:09 --> Security Class Initialized
DEBUG - 2023-01-13 10:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:51:09 --> Input Class Initialized
INFO - 2023-01-13 10:51:09 --> Language Class Initialized
INFO - 2023-01-13 10:51:09 --> Language Class Initialized
INFO - 2023-01-13 10:51:09 --> Config Class Initialized
INFO - 2023-01-13 10:51:09 --> Loader Class Initialized
INFO - 2023-01-13 10:51:09 --> Helper loaded: url_helper
INFO - 2023-01-13 10:51:09 --> Helper loaded: file_helper
INFO - 2023-01-13 10:51:09 --> Helper loaded: form_helper
INFO - 2023-01-13 10:51:09 --> Helper loaded: my_helper
INFO - 2023-01-13 10:51:09 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:51:09 --> Controller Class Initialized
INFO - 2023-01-13 10:51:09 --> Config Class Initialized
INFO - 2023-01-13 10:51:09 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:51:09 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:51:09 --> Utf8 Class Initialized
INFO - 2023-01-13 10:51:09 --> URI Class Initialized
INFO - 2023-01-13 10:51:09 --> Router Class Initialized
INFO - 2023-01-13 10:51:09 --> Output Class Initialized
INFO - 2023-01-13 10:51:09 --> Security Class Initialized
DEBUG - 2023-01-13 10:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:51:09 --> Input Class Initialized
INFO - 2023-01-13 10:51:09 --> Language Class Initialized
INFO - 2023-01-13 10:51:09 --> Language Class Initialized
INFO - 2023-01-13 10:51:09 --> Config Class Initialized
INFO - 2023-01-13 10:51:09 --> Loader Class Initialized
INFO - 2023-01-13 10:51:09 --> Helper loaded: url_helper
INFO - 2023-01-13 10:51:09 --> Helper loaded: file_helper
INFO - 2023-01-13 10:51:09 --> Helper loaded: form_helper
INFO - 2023-01-13 10:51:09 --> Helper loaded: my_helper
INFO - 2023-01-13 10:51:09 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:51:09 --> Controller Class Initialized
DEBUG - 2023-01-13 10:51:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-13 10:51:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 10:51:09 --> Final output sent to browser
DEBUG - 2023-01-13 10:51:09 --> Total execution time: 0.0233
INFO - 2023-01-13 10:51:21 --> Config Class Initialized
INFO - 2023-01-13 10:51:21 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:51:21 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:51:21 --> Utf8 Class Initialized
INFO - 2023-01-13 10:51:21 --> URI Class Initialized
INFO - 2023-01-13 10:51:21 --> Router Class Initialized
INFO - 2023-01-13 10:51:21 --> Output Class Initialized
INFO - 2023-01-13 10:51:21 --> Security Class Initialized
DEBUG - 2023-01-13 10:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:51:21 --> Input Class Initialized
INFO - 2023-01-13 10:51:21 --> Language Class Initialized
INFO - 2023-01-13 10:51:21 --> Language Class Initialized
INFO - 2023-01-13 10:51:21 --> Config Class Initialized
INFO - 2023-01-13 10:51:21 --> Loader Class Initialized
INFO - 2023-01-13 10:51:21 --> Helper loaded: url_helper
INFO - 2023-01-13 10:51:21 --> Helper loaded: file_helper
INFO - 2023-01-13 10:51:21 --> Helper loaded: form_helper
INFO - 2023-01-13 10:51:21 --> Helper loaded: my_helper
INFO - 2023-01-13 10:51:21 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:51:21 --> Controller Class Initialized
INFO - 2023-01-13 10:51:21 --> Helper loaded: cookie_helper
INFO - 2023-01-13 10:51:21 --> Final output sent to browser
DEBUG - 2023-01-13 10:51:21 --> Total execution time: 0.0272
INFO - 2023-01-13 10:51:21 --> Config Class Initialized
INFO - 2023-01-13 10:51:21 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:51:21 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:51:21 --> Utf8 Class Initialized
INFO - 2023-01-13 10:51:21 --> URI Class Initialized
INFO - 2023-01-13 10:51:21 --> Router Class Initialized
INFO - 2023-01-13 10:51:21 --> Output Class Initialized
INFO - 2023-01-13 10:51:21 --> Security Class Initialized
DEBUG - 2023-01-13 10:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:51:21 --> Input Class Initialized
INFO - 2023-01-13 10:51:21 --> Language Class Initialized
INFO - 2023-01-13 10:51:21 --> Language Class Initialized
INFO - 2023-01-13 10:51:21 --> Config Class Initialized
INFO - 2023-01-13 10:51:21 --> Loader Class Initialized
INFO - 2023-01-13 10:51:21 --> Helper loaded: url_helper
INFO - 2023-01-13 10:51:21 --> Helper loaded: file_helper
INFO - 2023-01-13 10:51:21 --> Helper loaded: form_helper
INFO - 2023-01-13 10:51:21 --> Helper loaded: my_helper
INFO - 2023-01-13 10:51:21 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:51:21 --> Controller Class Initialized
DEBUG - 2023-01-13 10:51:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-01-13 10:51:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 10:51:21 --> Final output sent to browser
DEBUG - 2023-01-13 10:51:21 --> Total execution time: 0.0443
INFO - 2023-01-13 10:51:24 --> Config Class Initialized
INFO - 2023-01-13 10:51:24 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:51:24 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:51:24 --> Utf8 Class Initialized
INFO - 2023-01-13 10:51:24 --> URI Class Initialized
INFO - 2023-01-13 10:51:24 --> Router Class Initialized
INFO - 2023-01-13 10:51:24 --> Output Class Initialized
INFO - 2023-01-13 10:51:24 --> Security Class Initialized
DEBUG - 2023-01-13 10:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:51:24 --> Input Class Initialized
INFO - 2023-01-13 10:51:24 --> Language Class Initialized
INFO - 2023-01-13 10:51:24 --> Language Class Initialized
INFO - 2023-01-13 10:51:24 --> Config Class Initialized
INFO - 2023-01-13 10:51:24 --> Loader Class Initialized
INFO - 2023-01-13 10:51:24 --> Helper loaded: url_helper
INFO - 2023-01-13 10:51:24 --> Helper loaded: file_helper
INFO - 2023-01-13 10:51:24 --> Helper loaded: form_helper
INFO - 2023-01-13 10:51:24 --> Helper loaded: my_helper
INFO - 2023-01-13 10:51:24 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:51:24 --> Controller Class Initialized
DEBUG - 2023-01-13 10:51:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_guru/views/list.php
DEBUG - 2023-01-13 10:51:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 10:51:24 --> Final output sent to browser
DEBUG - 2023-01-13 10:51:24 --> Total execution time: 0.0661
INFO - 2023-01-13 10:51:24 --> Config Class Initialized
INFO - 2023-01-13 10:51:24 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:51:24 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:51:24 --> Utf8 Class Initialized
INFO - 2023-01-13 10:51:24 --> URI Class Initialized
INFO - 2023-01-13 10:51:24 --> Router Class Initialized
INFO - 2023-01-13 10:51:24 --> Output Class Initialized
INFO - 2023-01-13 10:51:24 --> Security Class Initialized
DEBUG - 2023-01-13 10:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:51:24 --> Input Class Initialized
INFO - 2023-01-13 10:51:24 --> Language Class Initialized
INFO - 2023-01-13 10:51:24 --> Language Class Initialized
INFO - 2023-01-13 10:51:24 --> Config Class Initialized
INFO - 2023-01-13 10:51:24 --> Loader Class Initialized
INFO - 2023-01-13 10:51:24 --> Helper loaded: url_helper
INFO - 2023-01-13 10:51:24 --> Helper loaded: file_helper
INFO - 2023-01-13 10:51:24 --> Helper loaded: form_helper
INFO - 2023-01-13 10:51:24 --> Helper loaded: my_helper
INFO - 2023-01-13 10:51:24 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:51:24 --> Controller Class Initialized
INFO - 2023-01-13 10:51:26 --> Config Class Initialized
INFO - 2023-01-13 10:51:26 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:51:26 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:51:26 --> Utf8 Class Initialized
INFO - 2023-01-13 10:51:26 --> URI Class Initialized
INFO - 2023-01-13 10:51:26 --> Router Class Initialized
INFO - 2023-01-13 10:51:26 --> Output Class Initialized
INFO - 2023-01-13 10:51:26 --> Security Class Initialized
DEBUG - 2023-01-13 10:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:51:26 --> Input Class Initialized
INFO - 2023-01-13 10:51:26 --> Language Class Initialized
INFO - 2023-01-13 10:51:26 --> Language Class Initialized
INFO - 2023-01-13 10:51:26 --> Config Class Initialized
INFO - 2023-01-13 10:51:26 --> Loader Class Initialized
INFO - 2023-01-13 10:51:26 --> Helper loaded: url_helper
INFO - 2023-01-13 10:51:26 --> Helper loaded: file_helper
INFO - 2023-01-13 10:51:26 --> Helper loaded: form_helper
INFO - 2023-01-13 10:51:26 --> Helper loaded: my_helper
INFO - 2023-01-13 10:51:26 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:51:26 --> Controller Class Initialized
DEBUG - 2023-01-13 10:51:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/list.php
DEBUG - 2023-01-13 10:51:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 10:51:26 --> Final output sent to browser
DEBUG - 2023-01-13 10:51:26 --> Total execution time: 0.0657
INFO - 2023-01-13 10:51:26 --> Config Class Initialized
INFO - 2023-01-13 10:51:26 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:51:26 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:51:26 --> Utf8 Class Initialized
INFO - 2023-01-13 10:51:26 --> URI Class Initialized
INFO - 2023-01-13 10:51:26 --> Router Class Initialized
INFO - 2023-01-13 10:51:26 --> Output Class Initialized
INFO - 2023-01-13 10:51:26 --> Security Class Initialized
DEBUG - 2023-01-13 10:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:51:26 --> Input Class Initialized
INFO - 2023-01-13 10:51:26 --> Language Class Initialized
INFO - 2023-01-13 10:51:26 --> Language Class Initialized
INFO - 2023-01-13 10:51:26 --> Config Class Initialized
INFO - 2023-01-13 10:51:26 --> Loader Class Initialized
INFO - 2023-01-13 10:51:26 --> Helper loaded: url_helper
INFO - 2023-01-13 10:51:26 --> Helper loaded: file_helper
INFO - 2023-01-13 10:51:26 --> Helper loaded: form_helper
INFO - 2023-01-13 10:51:26 --> Helper loaded: my_helper
INFO - 2023-01-13 10:51:26 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:51:26 --> Controller Class Initialized
INFO - 2023-01-13 10:51:27 --> Config Class Initialized
INFO - 2023-01-13 10:51:27 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:51:27 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:51:27 --> Utf8 Class Initialized
INFO - 2023-01-13 10:51:27 --> URI Class Initialized
INFO - 2023-01-13 10:51:27 --> Router Class Initialized
INFO - 2023-01-13 10:51:27 --> Output Class Initialized
INFO - 2023-01-13 10:51:27 --> Security Class Initialized
DEBUG - 2023-01-13 10:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:51:27 --> Input Class Initialized
INFO - 2023-01-13 10:51:27 --> Language Class Initialized
INFO - 2023-01-13 10:51:28 --> Language Class Initialized
INFO - 2023-01-13 10:51:28 --> Config Class Initialized
INFO - 2023-01-13 10:51:28 --> Loader Class Initialized
INFO - 2023-01-13 10:51:28 --> Helper loaded: url_helper
INFO - 2023-01-13 10:51:28 --> Helper loaded: file_helper
INFO - 2023-01-13 10:51:28 --> Helper loaded: form_helper
INFO - 2023-01-13 10:51:28 --> Helper loaded: my_helper
INFO - 2023-01-13 10:51:28 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:51:28 --> Controller Class Initialized
DEBUG - 2023-01-13 10:51:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_kelas/views/list.php
DEBUG - 2023-01-13 10:51:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 10:51:28 --> Final output sent to browser
DEBUG - 2023-01-13 10:51:28 --> Total execution time: 0.0652
INFO - 2023-01-13 10:51:28 --> Config Class Initialized
INFO - 2023-01-13 10:51:28 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:51:28 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:51:28 --> Utf8 Class Initialized
INFO - 2023-01-13 10:51:28 --> URI Class Initialized
INFO - 2023-01-13 10:51:28 --> Router Class Initialized
INFO - 2023-01-13 10:51:28 --> Output Class Initialized
INFO - 2023-01-13 10:51:28 --> Security Class Initialized
DEBUG - 2023-01-13 10:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:51:28 --> Input Class Initialized
INFO - 2023-01-13 10:51:28 --> Language Class Initialized
INFO - 2023-01-13 10:51:28 --> Language Class Initialized
INFO - 2023-01-13 10:51:28 --> Config Class Initialized
INFO - 2023-01-13 10:51:28 --> Loader Class Initialized
INFO - 2023-01-13 10:51:28 --> Helper loaded: url_helper
INFO - 2023-01-13 10:51:28 --> Helper loaded: file_helper
INFO - 2023-01-13 10:51:28 --> Helper loaded: form_helper
INFO - 2023-01-13 10:51:28 --> Helper loaded: my_helper
INFO - 2023-01-13 10:51:28 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:51:28 --> Controller Class Initialized
INFO - 2023-01-13 10:51:30 --> Config Class Initialized
INFO - 2023-01-13 10:51:30 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:51:30 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:51:30 --> Utf8 Class Initialized
INFO - 2023-01-13 10:51:30 --> URI Class Initialized
INFO - 2023-01-13 10:51:30 --> Router Class Initialized
INFO - 2023-01-13 10:51:30 --> Output Class Initialized
INFO - 2023-01-13 10:51:30 --> Security Class Initialized
DEBUG - 2023-01-13 10:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:51:30 --> Input Class Initialized
INFO - 2023-01-13 10:51:30 --> Language Class Initialized
INFO - 2023-01-13 10:51:30 --> Language Class Initialized
INFO - 2023-01-13 10:51:30 --> Config Class Initialized
INFO - 2023-01-13 10:51:30 --> Loader Class Initialized
INFO - 2023-01-13 10:51:30 --> Helper loaded: url_helper
INFO - 2023-01-13 10:51:30 --> Helper loaded: file_helper
INFO - 2023-01-13 10:51:30 --> Helper loaded: form_helper
INFO - 2023-01-13 10:51:30 --> Helper loaded: my_helper
INFO - 2023-01-13 10:51:30 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:51:30 --> Controller Class Initialized
DEBUG - 2023-01-13 10:51:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_mapel/views/list.php
DEBUG - 2023-01-13 10:51:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 10:51:30 --> Final output sent to browser
DEBUG - 2023-01-13 10:51:30 --> Total execution time: 0.0657
INFO - 2023-01-13 10:51:30 --> Config Class Initialized
INFO - 2023-01-13 10:51:30 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:51:30 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:51:30 --> Utf8 Class Initialized
INFO - 2023-01-13 10:51:30 --> URI Class Initialized
INFO - 2023-01-13 10:51:30 --> Router Class Initialized
INFO - 2023-01-13 10:51:30 --> Output Class Initialized
INFO - 2023-01-13 10:51:30 --> Security Class Initialized
DEBUG - 2023-01-13 10:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:51:30 --> Input Class Initialized
INFO - 2023-01-13 10:51:30 --> Language Class Initialized
INFO - 2023-01-13 10:51:30 --> Language Class Initialized
INFO - 2023-01-13 10:51:30 --> Config Class Initialized
INFO - 2023-01-13 10:51:30 --> Loader Class Initialized
INFO - 2023-01-13 10:51:30 --> Helper loaded: url_helper
INFO - 2023-01-13 10:51:30 --> Helper loaded: file_helper
INFO - 2023-01-13 10:51:30 --> Helper loaded: form_helper
INFO - 2023-01-13 10:51:30 --> Helper loaded: my_helper
INFO - 2023-01-13 10:51:30 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:51:30 --> Controller Class Initialized
INFO - 2023-01-13 10:56:16 --> Config Class Initialized
INFO - 2023-01-13 10:56:16 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:56:16 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:56:16 --> Utf8 Class Initialized
INFO - 2023-01-13 10:56:16 --> URI Class Initialized
INFO - 2023-01-13 10:56:16 --> Router Class Initialized
INFO - 2023-01-13 10:56:16 --> Output Class Initialized
INFO - 2023-01-13 10:56:16 --> Security Class Initialized
DEBUG - 2023-01-13 10:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:56:16 --> Input Class Initialized
INFO - 2023-01-13 10:56:16 --> Language Class Initialized
INFO - 2023-01-13 10:56:16 --> Language Class Initialized
INFO - 2023-01-13 10:56:16 --> Config Class Initialized
INFO - 2023-01-13 10:56:16 --> Loader Class Initialized
INFO - 2023-01-13 10:56:16 --> Helper loaded: url_helper
INFO - 2023-01-13 10:56:16 --> Helper loaded: file_helper
INFO - 2023-01-13 10:56:16 --> Helper loaded: form_helper
INFO - 2023-01-13 10:56:16 --> Helper loaded: my_helper
INFO - 2023-01-13 10:56:16 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:56:16 --> Controller Class Initialized
DEBUG - 2023-01-13 10:56:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_mapel/views/list.php
DEBUG - 2023-01-13 10:56:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 10:56:16 --> Final output sent to browser
DEBUG - 2023-01-13 10:56:16 --> Total execution time: 0.0248
INFO - 2023-01-13 10:56:16 --> Config Class Initialized
INFO - 2023-01-13 10:56:16 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:56:16 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:56:16 --> Utf8 Class Initialized
INFO - 2023-01-13 10:56:16 --> URI Class Initialized
INFO - 2023-01-13 10:56:16 --> Router Class Initialized
INFO - 2023-01-13 10:56:16 --> Output Class Initialized
INFO - 2023-01-13 10:56:16 --> Security Class Initialized
DEBUG - 2023-01-13 10:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:56:16 --> Input Class Initialized
INFO - 2023-01-13 10:56:16 --> Language Class Initialized
INFO - 2023-01-13 10:56:16 --> Language Class Initialized
INFO - 2023-01-13 10:56:16 --> Config Class Initialized
INFO - 2023-01-13 10:56:16 --> Loader Class Initialized
INFO - 2023-01-13 10:56:16 --> Helper loaded: url_helper
INFO - 2023-01-13 10:56:16 --> Helper loaded: file_helper
INFO - 2023-01-13 10:56:16 --> Helper loaded: form_helper
INFO - 2023-01-13 10:56:16 --> Helper loaded: my_helper
INFO - 2023-01-13 10:56:16 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:56:16 --> Controller Class Initialized
INFO - 2023-01-13 10:56:17 --> Config Class Initialized
INFO - 2023-01-13 10:56:17 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:56:17 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:56:17 --> Utf8 Class Initialized
INFO - 2023-01-13 10:56:17 --> URI Class Initialized
INFO - 2023-01-13 10:56:17 --> Router Class Initialized
INFO - 2023-01-13 10:56:17 --> Output Class Initialized
INFO - 2023-01-13 10:56:17 --> Security Class Initialized
DEBUG - 2023-01-13 10:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:56:17 --> Input Class Initialized
INFO - 2023-01-13 10:56:17 --> Language Class Initialized
INFO - 2023-01-13 10:56:17 --> Language Class Initialized
INFO - 2023-01-13 10:56:17 --> Config Class Initialized
INFO - 2023-01-13 10:56:17 --> Loader Class Initialized
INFO - 2023-01-13 10:56:17 --> Helper loaded: url_helper
INFO - 2023-01-13 10:56:17 --> Helper loaded: file_helper
INFO - 2023-01-13 10:56:17 --> Helper loaded: form_helper
INFO - 2023-01-13 10:56:17 --> Helper loaded: my_helper
INFO - 2023-01-13 10:56:17 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:56:17 --> Controller Class Initialized
INFO - 2023-01-13 10:56:17 --> Final output sent to browser
DEBUG - 2023-01-13 10:56:17 --> Total execution time: 0.0371
INFO - 2023-01-13 10:57:07 --> Config Class Initialized
INFO - 2023-01-13 10:57:07 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:57:07 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:57:07 --> Utf8 Class Initialized
INFO - 2023-01-13 10:57:07 --> URI Class Initialized
INFO - 2023-01-13 10:57:07 --> Router Class Initialized
INFO - 2023-01-13 10:57:07 --> Output Class Initialized
INFO - 2023-01-13 10:57:07 --> Security Class Initialized
DEBUG - 2023-01-13 10:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:57:07 --> Input Class Initialized
INFO - 2023-01-13 10:57:07 --> Language Class Initialized
INFO - 2023-01-13 10:57:07 --> Language Class Initialized
INFO - 2023-01-13 10:57:07 --> Config Class Initialized
INFO - 2023-01-13 10:57:07 --> Loader Class Initialized
INFO - 2023-01-13 10:57:07 --> Helper loaded: url_helper
INFO - 2023-01-13 10:57:07 --> Helper loaded: file_helper
INFO - 2023-01-13 10:57:07 --> Helper loaded: form_helper
INFO - 2023-01-13 10:57:07 --> Helper loaded: my_helper
INFO - 2023-01-13 10:57:07 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:57:07 --> Controller Class Initialized
INFO - 2023-01-13 10:57:07 --> Final output sent to browser
DEBUG - 2023-01-13 10:57:07 --> Total execution time: 0.0366
INFO - 2023-01-13 10:57:07 --> Config Class Initialized
INFO - 2023-01-13 10:57:07 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:57:07 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:57:07 --> Utf8 Class Initialized
INFO - 2023-01-13 10:57:07 --> URI Class Initialized
INFO - 2023-01-13 10:57:07 --> Router Class Initialized
INFO - 2023-01-13 10:57:07 --> Output Class Initialized
INFO - 2023-01-13 10:57:07 --> Security Class Initialized
DEBUG - 2023-01-13 10:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:57:07 --> Input Class Initialized
INFO - 2023-01-13 10:57:07 --> Language Class Initialized
INFO - 2023-01-13 10:57:07 --> Language Class Initialized
INFO - 2023-01-13 10:57:07 --> Config Class Initialized
INFO - 2023-01-13 10:57:07 --> Loader Class Initialized
INFO - 2023-01-13 10:57:07 --> Helper loaded: url_helper
INFO - 2023-01-13 10:57:07 --> Helper loaded: file_helper
INFO - 2023-01-13 10:57:07 --> Helper loaded: form_helper
INFO - 2023-01-13 10:57:07 --> Helper loaded: my_helper
INFO - 2023-01-13 10:57:07 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:57:07 --> Controller Class Initialized
INFO - 2023-01-13 10:57:19 --> Config Class Initialized
INFO - 2023-01-13 10:57:19 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:57:19 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:57:19 --> Utf8 Class Initialized
INFO - 2023-01-13 10:57:19 --> URI Class Initialized
INFO - 2023-01-13 10:57:19 --> Router Class Initialized
INFO - 2023-01-13 10:57:19 --> Output Class Initialized
INFO - 2023-01-13 10:57:19 --> Security Class Initialized
DEBUG - 2023-01-13 10:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:57:19 --> Input Class Initialized
INFO - 2023-01-13 10:57:19 --> Language Class Initialized
INFO - 2023-01-13 10:57:19 --> Language Class Initialized
INFO - 2023-01-13 10:57:19 --> Config Class Initialized
INFO - 2023-01-13 10:57:19 --> Loader Class Initialized
INFO - 2023-01-13 10:57:19 --> Helper loaded: url_helper
INFO - 2023-01-13 10:57:19 --> Helper loaded: file_helper
INFO - 2023-01-13 10:57:19 --> Helper loaded: form_helper
INFO - 2023-01-13 10:57:19 --> Helper loaded: my_helper
INFO - 2023-01-13 10:57:19 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:57:19 --> Controller Class Initialized
INFO - 2023-01-13 10:57:19 --> Helper loaded: cookie_helper
INFO - 2023-01-13 10:57:19 --> Config Class Initialized
INFO - 2023-01-13 10:57:19 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:57:19 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:57:19 --> Utf8 Class Initialized
INFO - 2023-01-13 10:57:19 --> URI Class Initialized
INFO - 2023-01-13 10:57:19 --> Router Class Initialized
INFO - 2023-01-13 10:57:19 --> Output Class Initialized
INFO - 2023-01-13 10:57:19 --> Security Class Initialized
DEBUG - 2023-01-13 10:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:57:19 --> Input Class Initialized
INFO - 2023-01-13 10:57:19 --> Language Class Initialized
INFO - 2023-01-13 10:57:19 --> Language Class Initialized
INFO - 2023-01-13 10:57:19 --> Config Class Initialized
INFO - 2023-01-13 10:57:19 --> Loader Class Initialized
INFO - 2023-01-13 10:57:19 --> Helper loaded: url_helper
INFO - 2023-01-13 10:57:19 --> Helper loaded: file_helper
INFO - 2023-01-13 10:57:19 --> Helper loaded: form_helper
INFO - 2023-01-13 10:57:19 --> Helper loaded: my_helper
INFO - 2023-01-13 10:57:19 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:57:19 --> Controller Class Initialized
INFO - 2023-01-13 10:57:19 --> Config Class Initialized
INFO - 2023-01-13 10:57:19 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:57:19 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:57:19 --> Utf8 Class Initialized
INFO - 2023-01-13 10:57:19 --> URI Class Initialized
INFO - 2023-01-13 10:57:19 --> Router Class Initialized
INFO - 2023-01-13 10:57:19 --> Output Class Initialized
INFO - 2023-01-13 10:57:19 --> Security Class Initialized
DEBUG - 2023-01-13 10:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:57:19 --> Input Class Initialized
INFO - 2023-01-13 10:57:19 --> Language Class Initialized
INFO - 2023-01-13 10:57:19 --> Language Class Initialized
INFO - 2023-01-13 10:57:19 --> Config Class Initialized
INFO - 2023-01-13 10:57:19 --> Loader Class Initialized
INFO - 2023-01-13 10:57:19 --> Helper loaded: url_helper
INFO - 2023-01-13 10:57:19 --> Helper loaded: file_helper
INFO - 2023-01-13 10:57:19 --> Helper loaded: form_helper
INFO - 2023-01-13 10:57:19 --> Helper loaded: my_helper
INFO - 2023-01-13 10:57:19 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:57:19 --> Controller Class Initialized
DEBUG - 2023-01-13 10:57:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-13 10:57:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 10:57:19 --> Final output sent to browser
DEBUG - 2023-01-13 10:57:19 --> Total execution time: 0.0231
INFO - 2023-01-13 10:57:24 --> Config Class Initialized
INFO - 2023-01-13 10:57:24 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:57:24 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:57:24 --> Utf8 Class Initialized
INFO - 2023-01-13 10:57:24 --> URI Class Initialized
INFO - 2023-01-13 10:57:24 --> Router Class Initialized
INFO - 2023-01-13 10:57:24 --> Output Class Initialized
INFO - 2023-01-13 10:57:24 --> Security Class Initialized
DEBUG - 2023-01-13 10:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:57:24 --> Input Class Initialized
INFO - 2023-01-13 10:57:24 --> Language Class Initialized
INFO - 2023-01-13 10:57:24 --> Language Class Initialized
INFO - 2023-01-13 10:57:24 --> Config Class Initialized
INFO - 2023-01-13 10:57:24 --> Loader Class Initialized
INFO - 2023-01-13 10:57:24 --> Helper loaded: url_helper
INFO - 2023-01-13 10:57:24 --> Helper loaded: file_helper
INFO - 2023-01-13 10:57:24 --> Helper loaded: form_helper
INFO - 2023-01-13 10:57:24 --> Helper loaded: my_helper
INFO - 2023-01-13 10:57:24 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:57:24 --> Controller Class Initialized
INFO - 2023-01-13 10:57:24 --> Helper loaded: cookie_helper
INFO - 2023-01-13 10:57:24 --> Final output sent to browser
DEBUG - 2023-01-13 10:57:24 --> Total execution time: 0.0252
INFO - 2023-01-13 10:57:24 --> Config Class Initialized
INFO - 2023-01-13 10:57:24 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:57:24 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:57:24 --> Utf8 Class Initialized
INFO - 2023-01-13 10:57:24 --> URI Class Initialized
INFO - 2023-01-13 10:57:24 --> Router Class Initialized
INFO - 2023-01-13 10:57:24 --> Output Class Initialized
INFO - 2023-01-13 10:57:24 --> Security Class Initialized
DEBUG - 2023-01-13 10:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:57:24 --> Input Class Initialized
INFO - 2023-01-13 10:57:24 --> Language Class Initialized
INFO - 2023-01-13 10:57:24 --> Language Class Initialized
INFO - 2023-01-13 10:57:24 --> Config Class Initialized
INFO - 2023-01-13 10:57:24 --> Loader Class Initialized
INFO - 2023-01-13 10:57:24 --> Helper loaded: url_helper
INFO - 2023-01-13 10:57:24 --> Helper loaded: file_helper
INFO - 2023-01-13 10:57:24 --> Helper loaded: form_helper
INFO - 2023-01-13 10:57:24 --> Helper loaded: my_helper
INFO - 2023-01-13 10:57:24 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:57:24 --> Controller Class Initialized
DEBUG - 2023-01-13 10:57:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-13 10:57:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 10:57:24 --> Final output sent to browser
DEBUG - 2023-01-13 10:57:24 --> Total execution time: 0.0452
INFO - 2023-01-13 10:57:25 --> Config Class Initialized
INFO - 2023-01-13 10:57:25 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:57:25 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:57:25 --> Utf8 Class Initialized
INFO - 2023-01-13 10:57:25 --> URI Class Initialized
INFO - 2023-01-13 10:57:25 --> Router Class Initialized
INFO - 2023-01-13 10:57:25 --> Output Class Initialized
INFO - 2023-01-13 10:57:25 --> Security Class Initialized
DEBUG - 2023-01-13 10:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:57:25 --> Input Class Initialized
INFO - 2023-01-13 10:57:25 --> Language Class Initialized
INFO - 2023-01-13 10:57:25 --> Language Class Initialized
INFO - 2023-01-13 10:57:25 --> Config Class Initialized
INFO - 2023-01-13 10:57:25 --> Loader Class Initialized
INFO - 2023-01-13 10:57:25 --> Helper loaded: url_helper
INFO - 2023-01-13 10:57:25 --> Helper loaded: file_helper
INFO - 2023-01-13 10:57:25 --> Helper loaded: form_helper
INFO - 2023-01-13 10:57:25 --> Helper loaded: my_helper
INFO - 2023-01-13 10:57:25 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:57:25 --> Controller Class Initialized
DEBUG - 2023-01-13 10:57:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-01-13 10:57:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 10:57:25 --> Final output sent to browser
DEBUG - 2023-01-13 10:57:25 --> Total execution time: 0.0478
INFO - 2023-01-13 10:57:27 --> Config Class Initialized
INFO - 2023-01-13 10:57:27 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:57:27 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:57:27 --> Utf8 Class Initialized
INFO - 2023-01-13 10:57:27 --> URI Class Initialized
INFO - 2023-01-13 10:57:27 --> Router Class Initialized
INFO - 2023-01-13 10:57:27 --> Output Class Initialized
INFO - 2023-01-13 10:57:27 --> Security Class Initialized
DEBUG - 2023-01-13 10:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:57:27 --> Input Class Initialized
INFO - 2023-01-13 10:57:27 --> Language Class Initialized
INFO - 2023-01-13 10:57:27 --> Language Class Initialized
INFO - 2023-01-13 10:57:27 --> Config Class Initialized
INFO - 2023-01-13 10:57:27 --> Loader Class Initialized
INFO - 2023-01-13 10:57:27 --> Helper loaded: url_helper
INFO - 2023-01-13 10:57:27 --> Helper loaded: file_helper
INFO - 2023-01-13 10:57:27 --> Helper loaded: form_helper
INFO - 2023-01-13 10:57:27 --> Helper loaded: my_helper
INFO - 2023-01-13 10:57:27 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:57:27 --> Controller Class Initialized
DEBUG - 2023-01-13 10:57:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-13 10:57:28 --> Final output sent to browser
DEBUG - 2023-01-13 10:57:28 --> Total execution time: 1.0919
INFO - 2023-01-13 10:57:47 --> Config Class Initialized
INFO - 2023-01-13 10:57:47 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:57:47 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:57:47 --> Utf8 Class Initialized
INFO - 2023-01-13 10:57:47 --> URI Class Initialized
INFO - 2023-01-13 10:57:47 --> Router Class Initialized
INFO - 2023-01-13 10:57:47 --> Output Class Initialized
INFO - 2023-01-13 10:57:47 --> Security Class Initialized
DEBUG - 2023-01-13 10:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:57:47 --> Input Class Initialized
INFO - 2023-01-13 10:57:47 --> Language Class Initialized
INFO - 2023-01-13 10:57:47 --> Language Class Initialized
INFO - 2023-01-13 10:57:47 --> Config Class Initialized
INFO - 2023-01-13 10:57:47 --> Loader Class Initialized
INFO - 2023-01-13 10:57:47 --> Helper loaded: url_helper
INFO - 2023-01-13 10:57:47 --> Helper loaded: file_helper
INFO - 2023-01-13 10:57:47 --> Helper loaded: form_helper
INFO - 2023-01-13 10:57:47 --> Helper loaded: my_helper
INFO - 2023-01-13 10:57:47 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:57:47 --> Controller Class Initialized
INFO - 2023-01-13 10:57:47 --> Helper loaded: cookie_helper
INFO - 2023-01-13 10:57:47 --> Config Class Initialized
INFO - 2023-01-13 10:57:47 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:57:47 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:57:47 --> Utf8 Class Initialized
INFO - 2023-01-13 10:57:47 --> URI Class Initialized
INFO - 2023-01-13 10:57:47 --> Router Class Initialized
INFO - 2023-01-13 10:57:47 --> Output Class Initialized
INFO - 2023-01-13 10:57:47 --> Security Class Initialized
DEBUG - 2023-01-13 10:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:57:47 --> Input Class Initialized
INFO - 2023-01-13 10:57:47 --> Language Class Initialized
INFO - 2023-01-13 10:57:47 --> Language Class Initialized
INFO - 2023-01-13 10:57:47 --> Config Class Initialized
INFO - 2023-01-13 10:57:47 --> Loader Class Initialized
INFO - 2023-01-13 10:57:47 --> Helper loaded: url_helper
INFO - 2023-01-13 10:57:47 --> Helper loaded: file_helper
INFO - 2023-01-13 10:57:47 --> Helper loaded: form_helper
INFO - 2023-01-13 10:57:47 --> Helper loaded: my_helper
INFO - 2023-01-13 10:57:47 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:57:47 --> Controller Class Initialized
INFO - 2023-01-13 10:57:47 --> Config Class Initialized
INFO - 2023-01-13 10:57:47 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:57:47 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:57:47 --> Utf8 Class Initialized
INFO - 2023-01-13 10:57:47 --> URI Class Initialized
INFO - 2023-01-13 10:57:47 --> Router Class Initialized
INFO - 2023-01-13 10:57:47 --> Output Class Initialized
INFO - 2023-01-13 10:57:47 --> Security Class Initialized
DEBUG - 2023-01-13 10:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:57:47 --> Input Class Initialized
INFO - 2023-01-13 10:57:47 --> Language Class Initialized
INFO - 2023-01-13 10:57:47 --> Language Class Initialized
INFO - 2023-01-13 10:57:47 --> Config Class Initialized
INFO - 2023-01-13 10:57:47 --> Loader Class Initialized
INFO - 2023-01-13 10:57:47 --> Helper loaded: url_helper
INFO - 2023-01-13 10:57:47 --> Helper loaded: file_helper
INFO - 2023-01-13 10:57:47 --> Helper loaded: form_helper
INFO - 2023-01-13 10:57:47 --> Helper loaded: my_helper
INFO - 2023-01-13 10:57:47 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:57:47 --> Controller Class Initialized
DEBUG - 2023-01-13 10:57:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-13 10:57:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 10:57:48 --> Final output sent to browser
DEBUG - 2023-01-13 10:57:48 --> Total execution time: 0.0226
INFO - 2023-01-13 10:57:53 --> Config Class Initialized
INFO - 2023-01-13 10:57:53 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:57:53 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:57:53 --> Utf8 Class Initialized
INFO - 2023-01-13 10:57:53 --> URI Class Initialized
INFO - 2023-01-13 10:57:53 --> Router Class Initialized
INFO - 2023-01-13 10:57:53 --> Output Class Initialized
INFO - 2023-01-13 10:57:53 --> Security Class Initialized
DEBUG - 2023-01-13 10:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:57:53 --> Input Class Initialized
INFO - 2023-01-13 10:57:53 --> Language Class Initialized
INFO - 2023-01-13 10:57:53 --> Language Class Initialized
INFO - 2023-01-13 10:57:53 --> Config Class Initialized
INFO - 2023-01-13 10:57:53 --> Loader Class Initialized
INFO - 2023-01-13 10:57:53 --> Helper loaded: url_helper
INFO - 2023-01-13 10:57:53 --> Helper loaded: file_helper
INFO - 2023-01-13 10:57:53 --> Helper loaded: form_helper
INFO - 2023-01-13 10:57:53 --> Helper loaded: my_helper
INFO - 2023-01-13 10:57:53 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:57:53 --> Controller Class Initialized
INFO - 2023-01-13 10:57:53 --> Helper loaded: cookie_helper
INFO - 2023-01-13 10:57:53 --> Final output sent to browser
DEBUG - 2023-01-13 10:57:53 --> Total execution time: 0.0352
INFO - 2023-01-13 10:57:53 --> Config Class Initialized
INFO - 2023-01-13 10:57:53 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:57:53 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:57:53 --> Utf8 Class Initialized
INFO - 2023-01-13 10:57:53 --> URI Class Initialized
INFO - 2023-01-13 10:57:53 --> Router Class Initialized
INFO - 2023-01-13 10:57:53 --> Output Class Initialized
INFO - 2023-01-13 10:57:53 --> Security Class Initialized
DEBUG - 2023-01-13 10:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:57:53 --> Input Class Initialized
INFO - 2023-01-13 10:57:53 --> Language Class Initialized
INFO - 2023-01-13 10:57:53 --> Language Class Initialized
INFO - 2023-01-13 10:57:53 --> Config Class Initialized
INFO - 2023-01-13 10:57:53 --> Loader Class Initialized
INFO - 2023-01-13 10:57:53 --> Helper loaded: url_helper
INFO - 2023-01-13 10:57:53 --> Helper loaded: file_helper
INFO - 2023-01-13 10:57:53 --> Helper loaded: form_helper
INFO - 2023-01-13 10:57:53 --> Helper loaded: my_helper
INFO - 2023-01-13 10:57:53 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:57:53 --> Controller Class Initialized
DEBUG - 2023-01-13 10:57:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-01-13 10:57:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 10:57:53 --> Final output sent to browser
DEBUG - 2023-01-13 10:57:53 --> Total execution time: 0.0460
INFO - 2023-01-13 10:57:57 --> Config Class Initialized
INFO - 2023-01-13 10:57:57 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:57:57 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:57:57 --> Utf8 Class Initialized
INFO - 2023-01-13 10:57:57 --> URI Class Initialized
INFO - 2023-01-13 10:57:57 --> Router Class Initialized
INFO - 2023-01-13 10:57:57 --> Output Class Initialized
INFO - 2023-01-13 10:57:57 --> Security Class Initialized
DEBUG - 2023-01-13 10:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:57:57 --> Input Class Initialized
INFO - 2023-01-13 10:57:57 --> Language Class Initialized
INFO - 2023-01-13 10:57:57 --> Language Class Initialized
INFO - 2023-01-13 10:57:57 --> Config Class Initialized
INFO - 2023-01-13 10:57:57 --> Loader Class Initialized
INFO - 2023-01-13 10:57:57 --> Helper loaded: url_helper
INFO - 2023-01-13 10:57:57 --> Helper loaded: file_helper
INFO - 2023-01-13 10:57:57 --> Helper loaded: form_helper
INFO - 2023-01-13 10:57:57 --> Helper loaded: my_helper
INFO - 2023-01-13 10:57:57 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:57:57 --> Controller Class Initialized
DEBUG - 2023-01-13 10:57:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/list.php
DEBUG - 2023-01-13 10:57:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 10:57:57 --> Final output sent to browser
DEBUG - 2023-01-13 10:57:57 --> Total execution time: 0.0253
INFO - 2023-01-13 10:57:57 --> Config Class Initialized
INFO - 2023-01-13 10:57:57 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:57:57 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:57:57 --> Utf8 Class Initialized
INFO - 2023-01-13 10:57:57 --> URI Class Initialized
INFO - 2023-01-13 10:57:57 --> Router Class Initialized
INFO - 2023-01-13 10:57:57 --> Output Class Initialized
INFO - 2023-01-13 10:57:57 --> Security Class Initialized
DEBUG - 2023-01-13 10:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:57:57 --> Input Class Initialized
INFO - 2023-01-13 10:57:57 --> Language Class Initialized
INFO - 2023-01-13 10:57:57 --> Language Class Initialized
INFO - 2023-01-13 10:57:57 --> Config Class Initialized
INFO - 2023-01-13 10:57:57 --> Loader Class Initialized
INFO - 2023-01-13 10:57:57 --> Helper loaded: url_helper
INFO - 2023-01-13 10:57:57 --> Helper loaded: file_helper
INFO - 2023-01-13 10:57:57 --> Helper loaded: form_helper
INFO - 2023-01-13 10:57:57 --> Helper loaded: my_helper
INFO - 2023-01-13 10:57:57 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:57:57 --> Controller Class Initialized
INFO - 2023-01-13 10:58:00 --> Config Class Initialized
INFO - 2023-01-13 10:58:00 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:58:00 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:58:00 --> Utf8 Class Initialized
INFO - 2023-01-13 10:58:00 --> URI Class Initialized
INFO - 2023-01-13 10:58:00 --> Router Class Initialized
INFO - 2023-01-13 10:58:00 --> Output Class Initialized
INFO - 2023-01-13 10:58:00 --> Security Class Initialized
DEBUG - 2023-01-13 10:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:58:00 --> Input Class Initialized
INFO - 2023-01-13 10:58:00 --> Language Class Initialized
INFO - 2023-01-13 10:58:00 --> Language Class Initialized
INFO - 2023-01-13 10:58:00 --> Config Class Initialized
INFO - 2023-01-13 10:58:00 --> Loader Class Initialized
INFO - 2023-01-13 10:58:00 --> Helper loaded: url_helper
INFO - 2023-01-13 10:58:00 --> Helper loaded: file_helper
INFO - 2023-01-13 10:58:00 --> Helper loaded: form_helper
INFO - 2023-01-13 10:58:00 --> Helper loaded: my_helper
INFO - 2023-01-13 10:58:00 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:58:00 --> Controller Class Initialized
DEBUG - 2023-01-13 10:58:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/form.php
DEBUG - 2023-01-13 10:58:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 10:58:00 --> Final output sent to browser
DEBUG - 2023-01-13 10:58:00 --> Total execution time: 0.0254
INFO - 2023-01-13 10:58:12 --> Config Class Initialized
INFO - 2023-01-13 10:58:12 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:58:12 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:58:12 --> Utf8 Class Initialized
INFO - 2023-01-13 10:58:12 --> URI Class Initialized
INFO - 2023-01-13 10:58:12 --> Router Class Initialized
INFO - 2023-01-13 10:58:12 --> Output Class Initialized
INFO - 2023-01-13 10:58:13 --> Security Class Initialized
DEBUG - 2023-01-13 10:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:58:13 --> Input Class Initialized
INFO - 2023-01-13 10:58:13 --> Language Class Initialized
INFO - 2023-01-13 10:58:13 --> Language Class Initialized
INFO - 2023-01-13 10:58:13 --> Config Class Initialized
INFO - 2023-01-13 10:58:13 --> Loader Class Initialized
INFO - 2023-01-13 10:58:13 --> Helper loaded: url_helper
INFO - 2023-01-13 10:58:13 --> Helper loaded: file_helper
INFO - 2023-01-13 10:58:13 --> Helper loaded: form_helper
INFO - 2023-01-13 10:58:13 --> Helper loaded: my_helper
INFO - 2023-01-13 10:58:13 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:58:13 --> Controller Class Initialized
INFO - 2023-01-13 10:58:13 --> Config Class Initialized
INFO - 2023-01-13 10:58:13 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:58:13 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:58:13 --> Utf8 Class Initialized
INFO - 2023-01-13 10:58:13 --> URI Class Initialized
INFO - 2023-01-13 10:58:13 --> Router Class Initialized
INFO - 2023-01-13 10:58:13 --> Output Class Initialized
INFO - 2023-01-13 10:58:13 --> Security Class Initialized
DEBUG - 2023-01-13 10:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:58:13 --> Input Class Initialized
INFO - 2023-01-13 10:58:13 --> Language Class Initialized
INFO - 2023-01-13 10:58:13 --> Language Class Initialized
INFO - 2023-01-13 10:58:13 --> Config Class Initialized
INFO - 2023-01-13 10:58:13 --> Loader Class Initialized
INFO - 2023-01-13 10:58:13 --> Helper loaded: url_helper
INFO - 2023-01-13 10:58:13 --> Helper loaded: file_helper
INFO - 2023-01-13 10:58:13 --> Helper loaded: form_helper
INFO - 2023-01-13 10:58:13 --> Helper loaded: my_helper
INFO - 2023-01-13 10:58:13 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:58:13 --> Controller Class Initialized
DEBUG - 2023-01-13 10:58:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/list.php
DEBUG - 2023-01-13 10:58:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 10:58:13 --> Final output sent to browser
DEBUG - 2023-01-13 10:58:13 --> Total execution time: 0.0242
INFO - 2023-01-13 10:58:13 --> Config Class Initialized
INFO - 2023-01-13 10:58:13 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:58:13 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:58:13 --> Utf8 Class Initialized
INFO - 2023-01-13 10:58:13 --> URI Class Initialized
INFO - 2023-01-13 10:58:13 --> Router Class Initialized
INFO - 2023-01-13 10:58:13 --> Output Class Initialized
INFO - 2023-01-13 10:58:13 --> Security Class Initialized
DEBUG - 2023-01-13 10:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:58:13 --> Input Class Initialized
INFO - 2023-01-13 10:58:13 --> Language Class Initialized
INFO - 2023-01-13 10:58:13 --> Language Class Initialized
INFO - 2023-01-13 10:58:13 --> Config Class Initialized
INFO - 2023-01-13 10:58:13 --> Loader Class Initialized
INFO - 2023-01-13 10:58:13 --> Helper loaded: url_helper
INFO - 2023-01-13 10:58:13 --> Helper loaded: file_helper
INFO - 2023-01-13 10:58:13 --> Helper loaded: form_helper
INFO - 2023-01-13 10:58:13 --> Helper loaded: my_helper
INFO - 2023-01-13 10:58:13 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:58:13 --> Controller Class Initialized
INFO - 2023-01-13 10:58:15 --> Config Class Initialized
INFO - 2023-01-13 10:58:15 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:58:15 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:58:15 --> Utf8 Class Initialized
INFO - 2023-01-13 10:58:15 --> URI Class Initialized
INFO - 2023-01-13 10:58:15 --> Router Class Initialized
INFO - 2023-01-13 10:58:15 --> Output Class Initialized
INFO - 2023-01-13 10:58:15 --> Security Class Initialized
DEBUG - 2023-01-13 10:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:58:15 --> Input Class Initialized
INFO - 2023-01-13 10:58:15 --> Language Class Initialized
INFO - 2023-01-13 10:58:15 --> Language Class Initialized
INFO - 2023-01-13 10:58:15 --> Config Class Initialized
INFO - 2023-01-13 10:58:15 --> Loader Class Initialized
INFO - 2023-01-13 10:58:15 --> Helper loaded: url_helper
INFO - 2023-01-13 10:58:15 --> Helper loaded: file_helper
INFO - 2023-01-13 10:58:15 --> Helper loaded: form_helper
INFO - 2023-01-13 10:58:15 --> Helper loaded: my_helper
INFO - 2023-01-13 10:58:15 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:58:15 --> Controller Class Initialized
INFO - 2023-01-13 10:58:15 --> Helper loaded: cookie_helper
INFO - 2023-01-13 10:58:15 --> Config Class Initialized
INFO - 2023-01-13 10:58:15 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:58:15 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:58:15 --> Utf8 Class Initialized
INFO - 2023-01-13 10:58:15 --> URI Class Initialized
INFO - 2023-01-13 10:58:15 --> Router Class Initialized
INFO - 2023-01-13 10:58:15 --> Output Class Initialized
INFO - 2023-01-13 10:58:15 --> Security Class Initialized
DEBUG - 2023-01-13 10:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:58:15 --> Input Class Initialized
INFO - 2023-01-13 10:58:15 --> Language Class Initialized
INFO - 2023-01-13 10:58:15 --> Language Class Initialized
INFO - 2023-01-13 10:58:15 --> Config Class Initialized
INFO - 2023-01-13 10:58:15 --> Loader Class Initialized
INFO - 2023-01-13 10:58:15 --> Helper loaded: url_helper
INFO - 2023-01-13 10:58:15 --> Helper loaded: file_helper
INFO - 2023-01-13 10:58:15 --> Helper loaded: form_helper
INFO - 2023-01-13 10:58:15 --> Helper loaded: my_helper
INFO - 2023-01-13 10:58:15 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:58:15 --> Controller Class Initialized
INFO - 2023-01-13 10:58:15 --> Config Class Initialized
INFO - 2023-01-13 10:58:15 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:58:15 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:58:15 --> Utf8 Class Initialized
INFO - 2023-01-13 10:58:15 --> URI Class Initialized
INFO - 2023-01-13 10:58:15 --> Router Class Initialized
INFO - 2023-01-13 10:58:15 --> Output Class Initialized
INFO - 2023-01-13 10:58:15 --> Security Class Initialized
DEBUG - 2023-01-13 10:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:58:15 --> Input Class Initialized
INFO - 2023-01-13 10:58:15 --> Language Class Initialized
INFO - 2023-01-13 10:58:15 --> Language Class Initialized
INFO - 2023-01-13 10:58:15 --> Config Class Initialized
INFO - 2023-01-13 10:58:15 --> Loader Class Initialized
INFO - 2023-01-13 10:58:15 --> Helper loaded: url_helper
INFO - 2023-01-13 10:58:15 --> Helper loaded: file_helper
INFO - 2023-01-13 10:58:15 --> Helper loaded: form_helper
INFO - 2023-01-13 10:58:15 --> Helper loaded: my_helper
INFO - 2023-01-13 10:58:15 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:58:15 --> Controller Class Initialized
DEBUG - 2023-01-13 10:58:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-13 10:58:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 10:58:15 --> Final output sent to browser
DEBUG - 2023-01-13 10:58:15 --> Total execution time: 0.0229
INFO - 2023-01-13 10:58:21 --> Config Class Initialized
INFO - 2023-01-13 10:58:21 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:58:21 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:58:21 --> Utf8 Class Initialized
INFO - 2023-01-13 10:58:21 --> URI Class Initialized
INFO - 2023-01-13 10:58:21 --> Router Class Initialized
INFO - 2023-01-13 10:58:21 --> Output Class Initialized
INFO - 2023-01-13 10:58:21 --> Security Class Initialized
DEBUG - 2023-01-13 10:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:58:21 --> Input Class Initialized
INFO - 2023-01-13 10:58:21 --> Language Class Initialized
INFO - 2023-01-13 10:58:21 --> Language Class Initialized
INFO - 2023-01-13 10:58:21 --> Config Class Initialized
INFO - 2023-01-13 10:58:21 --> Loader Class Initialized
INFO - 2023-01-13 10:58:21 --> Helper loaded: url_helper
INFO - 2023-01-13 10:58:21 --> Helper loaded: file_helper
INFO - 2023-01-13 10:58:21 --> Helper loaded: form_helper
INFO - 2023-01-13 10:58:21 --> Helper loaded: my_helper
INFO - 2023-01-13 10:58:21 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:58:21 --> Controller Class Initialized
INFO - 2023-01-13 10:58:21 --> Helper loaded: cookie_helper
INFO - 2023-01-13 10:58:21 --> Final output sent to browser
DEBUG - 2023-01-13 10:58:21 --> Total execution time: 0.0365
INFO - 2023-01-13 10:58:21 --> Config Class Initialized
INFO - 2023-01-13 10:58:21 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:58:21 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:58:21 --> Utf8 Class Initialized
INFO - 2023-01-13 10:58:21 --> URI Class Initialized
INFO - 2023-01-13 10:58:21 --> Router Class Initialized
INFO - 2023-01-13 10:58:21 --> Output Class Initialized
INFO - 2023-01-13 10:58:21 --> Security Class Initialized
DEBUG - 2023-01-13 10:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:58:21 --> Input Class Initialized
INFO - 2023-01-13 10:58:21 --> Language Class Initialized
INFO - 2023-01-13 10:58:21 --> Language Class Initialized
INFO - 2023-01-13 10:58:21 --> Config Class Initialized
INFO - 2023-01-13 10:58:21 --> Loader Class Initialized
INFO - 2023-01-13 10:58:21 --> Helper loaded: url_helper
INFO - 2023-01-13 10:58:21 --> Helper loaded: file_helper
INFO - 2023-01-13 10:58:21 --> Helper loaded: form_helper
INFO - 2023-01-13 10:58:21 --> Helper loaded: my_helper
INFO - 2023-01-13 10:58:21 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:58:21 --> Controller Class Initialized
DEBUG - 2023-01-13 10:58:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-13 10:58:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 10:58:21 --> Final output sent to browser
DEBUG - 2023-01-13 10:58:21 --> Total execution time: 0.0271
INFO - 2023-01-13 10:58:28 --> Config Class Initialized
INFO - 2023-01-13 10:58:28 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:58:28 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:58:28 --> Utf8 Class Initialized
INFO - 2023-01-13 10:58:28 --> URI Class Initialized
INFO - 2023-01-13 10:58:28 --> Router Class Initialized
INFO - 2023-01-13 10:58:28 --> Output Class Initialized
INFO - 2023-01-13 10:58:28 --> Security Class Initialized
DEBUG - 2023-01-13 10:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:58:28 --> Input Class Initialized
INFO - 2023-01-13 10:58:28 --> Language Class Initialized
INFO - 2023-01-13 10:58:28 --> Language Class Initialized
INFO - 2023-01-13 10:58:28 --> Config Class Initialized
INFO - 2023-01-13 10:58:28 --> Loader Class Initialized
INFO - 2023-01-13 10:58:28 --> Helper loaded: url_helper
INFO - 2023-01-13 10:58:28 --> Helper loaded: file_helper
INFO - 2023-01-13 10:58:28 --> Helper loaded: form_helper
INFO - 2023-01-13 10:58:28 --> Helper loaded: my_helper
INFO - 2023-01-13 10:58:28 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:58:28 --> Controller Class Initialized
DEBUG - 2023-01-13 10:58:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-13 10:58:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 10:58:28 --> Final output sent to browser
DEBUG - 2023-01-13 10:58:28 --> Total execution time: 0.0300
INFO - 2023-01-13 10:58:48 --> Config Class Initialized
INFO - 2023-01-13 10:58:48 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:58:48 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:58:48 --> Utf8 Class Initialized
INFO - 2023-01-13 10:58:48 --> URI Class Initialized
INFO - 2023-01-13 10:58:48 --> Router Class Initialized
INFO - 2023-01-13 10:58:48 --> Output Class Initialized
INFO - 2023-01-13 10:58:48 --> Security Class Initialized
DEBUG - 2023-01-13 10:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:58:48 --> Input Class Initialized
INFO - 2023-01-13 10:58:48 --> Language Class Initialized
INFO - 2023-01-13 10:58:48 --> Language Class Initialized
INFO - 2023-01-13 10:58:48 --> Config Class Initialized
INFO - 2023-01-13 10:58:48 --> Loader Class Initialized
INFO - 2023-01-13 10:58:48 --> Helper loaded: url_helper
INFO - 2023-01-13 10:58:48 --> Helper loaded: file_helper
INFO - 2023-01-13 10:58:48 --> Helper loaded: form_helper
INFO - 2023-01-13 10:58:48 --> Helper loaded: my_helper
INFO - 2023-01-13 10:58:48 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:58:48 --> Controller Class Initialized
DEBUG - 2023-01-13 10:58:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-13 10:58:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 10:58:48 --> Final output sent to browser
DEBUG - 2023-01-13 10:58:48 --> Total execution time: 0.0274
INFO - 2023-01-13 10:58:48 --> Config Class Initialized
INFO - 2023-01-13 10:58:48 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:58:48 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:58:48 --> Utf8 Class Initialized
INFO - 2023-01-13 10:58:48 --> URI Class Initialized
INFO - 2023-01-13 10:58:48 --> Router Class Initialized
INFO - 2023-01-13 10:58:48 --> Output Class Initialized
INFO - 2023-01-13 10:58:48 --> Security Class Initialized
DEBUG - 2023-01-13 10:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:58:48 --> Input Class Initialized
INFO - 2023-01-13 10:58:48 --> Language Class Initialized
INFO - 2023-01-13 10:58:48 --> Language Class Initialized
INFO - 2023-01-13 10:58:48 --> Config Class Initialized
INFO - 2023-01-13 10:58:48 --> Loader Class Initialized
INFO - 2023-01-13 10:58:48 --> Helper loaded: url_helper
INFO - 2023-01-13 10:58:48 --> Helper loaded: file_helper
INFO - 2023-01-13 10:58:48 --> Helper loaded: form_helper
INFO - 2023-01-13 10:58:48 --> Helper loaded: my_helper
INFO - 2023-01-13 10:58:48 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:58:48 --> Controller Class Initialized
INFO - 2023-01-13 10:59:09 --> Config Class Initialized
INFO - 2023-01-13 10:59:09 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:59:09 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:59:09 --> Utf8 Class Initialized
INFO - 2023-01-13 10:59:09 --> URI Class Initialized
INFO - 2023-01-13 10:59:09 --> Router Class Initialized
INFO - 2023-01-13 10:59:09 --> Output Class Initialized
INFO - 2023-01-13 10:59:09 --> Security Class Initialized
DEBUG - 2023-01-13 10:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:59:09 --> Input Class Initialized
INFO - 2023-01-13 10:59:09 --> Language Class Initialized
INFO - 2023-01-13 10:59:09 --> Language Class Initialized
INFO - 2023-01-13 10:59:09 --> Config Class Initialized
INFO - 2023-01-13 10:59:09 --> Loader Class Initialized
INFO - 2023-01-13 10:59:09 --> Helper loaded: url_helper
INFO - 2023-01-13 10:59:09 --> Helper loaded: file_helper
INFO - 2023-01-13 10:59:09 --> Helper loaded: form_helper
INFO - 2023-01-13 10:59:09 --> Helper loaded: my_helper
INFO - 2023-01-13 10:59:09 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:59:09 --> Controller Class Initialized
INFO - 2023-01-13 10:59:09 --> Final output sent to browser
DEBUG - 2023-01-13 10:59:09 --> Total execution time: 0.0306
INFO - 2023-01-13 10:59:22 --> Config Class Initialized
INFO - 2023-01-13 10:59:22 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:59:22 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:59:22 --> Utf8 Class Initialized
INFO - 2023-01-13 10:59:22 --> URI Class Initialized
INFO - 2023-01-13 10:59:22 --> Router Class Initialized
INFO - 2023-01-13 10:59:22 --> Output Class Initialized
INFO - 2023-01-13 10:59:22 --> Security Class Initialized
DEBUG - 2023-01-13 10:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:59:22 --> Input Class Initialized
INFO - 2023-01-13 10:59:22 --> Language Class Initialized
INFO - 2023-01-13 10:59:22 --> Language Class Initialized
INFO - 2023-01-13 10:59:22 --> Config Class Initialized
INFO - 2023-01-13 10:59:22 --> Loader Class Initialized
INFO - 2023-01-13 10:59:22 --> Helper loaded: url_helper
INFO - 2023-01-13 10:59:22 --> Helper loaded: file_helper
INFO - 2023-01-13 10:59:22 --> Helper loaded: form_helper
INFO - 2023-01-13 10:59:22 --> Helper loaded: my_helper
INFO - 2023-01-13 10:59:22 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:59:22 --> Controller Class Initialized
INFO - 2023-01-13 10:59:22 --> Final output sent to browser
DEBUG - 2023-01-13 10:59:22 --> Total execution time: 0.0379
INFO - 2023-01-13 10:59:22 --> Config Class Initialized
INFO - 2023-01-13 10:59:22 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:59:22 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:59:22 --> Utf8 Class Initialized
INFO - 2023-01-13 10:59:22 --> URI Class Initialized
INFO - 2023-01-13 10:59:22 --> Router Class Initialized
INFO - 2023-01-13 10:59:22 --> Output Class Initialized
INFO - 2023-01-13 10:59:22 --> Security Class Initialized
DEBUG - 2023-01-13 10:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:59:22 --> Input Class Initialized
INFO - 2023-01-13 10:59:22 --> Language Class Initialized
INFO - 2023-01-13 10:59:22 --> Language Class Initialized
INFO - 2023-01-13 10:59:22 --> Config Class Initialized
INFO - 2023-01-13 10:59:22 --> Loader Class Initialized
INFO - 2023-01-13 10:59:22 --> Helper loaded: url_helper
INFO - 2023-01-13 10:59:22 --> Helper loaded: file_helper
INFO - 2023-01-13 10:59:22 --> Helper loaded: form_helper
INFO - 2023-01-13 10:59:22 --> Helper loaded: my_helper
INFO - 2023-01-13 10:59:22 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:59:22 --> Controller Class Initialized
INFO - 2023-01-13 10:59:24 --> Config Class Initialized
INFO - 2023-01-13 10:59:24 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:59:24 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:59:24 --> Utf8 Class Initialized
INFO - 2023-01-13 10:59:24 --> URI Class Initialized
INFO - 2023-01-13 10:59:24 --> Router Class Initialized
INFO - 2023-01-13 10:59:24 --> Output Class Initialized
INFO - 2023-01-13 10:59:24 --> Security Class Initialized
DEBUG - 2023-01-13 10:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:59:24 --> Input Class Initialized
INFO - 2023-01-13 10:59:24 --> Language Class Initialized
INFO - 2023-01-13 10:59:24 --> Language Class Initialized
INFO - 2023-01-13 10:59:24 --> Config Class Initialized
INFO - 2023-01-13 10:59:24 --> Loader Class Initialized
INFO - 2023-01-13 10:59:24 --> Helper loaded: url_helper
INFO - 2023-01-13 10:59:24 --> Helper loaded: file_helper
INFO - 2023-01-13 10:59:24 --> Helper loaded: form_helper
INFO - 2023-01-13 10:59:24 --> Helper loaded: my_helper
INFO - 2023-01-13 10:59:24 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:59:24 --> Controller Class Initialized
INFO - 2023-01-13 10:59:24 --> Final output sent to browser
DEBUG - 2023-01-13 10:59:24 --> Total execution time: 0.0261
INFO - 2023-01-13 10:59:38 --> Config Class Initialized
INFO - 2023-01-13 10:59:38 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:59:38 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:59:38 --> Utf8 Class Initialized
INFO - 2023-01-13 10:59:38 --> URI Class Initialized
INFO - 2023-01-13 10:59:38 --> Router Class Initialized
INFO - 2023-01-13 10:59:38 --> Output Class Initialized
INFO - 2023-01-13 10:59:38 --> Security Class Initialized
DEBUG - 2023-01-13 10:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:59:38 --> Input Class Initialized
INFO - 2023-01-13 10:59:38 --> Language Class Initialized
INFO - 2023-01-13 10:59:38 --> Language Class Initialized
INFO - 2023-01-13 10:59:38 --> Config Class Initialized
INFO - 2023-01-13 10:59:38 --> Loader Class Initialized
INFO - 2023-01-13 10:59:38 --> Helper loaded: url_helper
INFO - 2023-01-13 10:59:38 --> Helper loaded: file_helper
INFO - 2023-01-13 10:59:38 --> Helper loaded: form_helper
INFO - 2023-01-13 10:59:38 --> Helper loaded: my_helper
INFO - 2023-01-13 10:59:38 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:59:38 --> Controller Class Initialized
INFO - 2023-01-13 10:59:38 --> Final output sent to browser
DEBUG - 2023-01-13 10:59:38 --> Total execution time: 0.0265
INFO - 2023-01-13 10:59:38 --> Config Class Initialized
INFO - 2023-01-13 10:59:38 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:59:38 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:59:38 --> Utf8 Class Initialized
INFO - 2023-01-13 10:59:38 --> URI Class Initialized
INFO - 2023-01-13 10:59:38 --> Router Class Initialized
INFO - 2023-01-13 10:59:38 --> Output Class Initialized
INFO - 2023-01-13 10:59:38 --> Security Class Initialized
DEBUG - 2023-01-13 10:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:59:38 --> Input Class Initialized
INFO - 2023-01-13 10:59:38 --> Language Class Initialized
INFO - 2023-01-13 10:59:38 --> Language Class Initialized
INFO - 2023-01-13 10:59:38 --> Config Class Initialized
INFO - 2023-01-13 10:59:38 --> Loader Class Initialized
INFO - 2023-01-13 10:59:38 --> Helper loaded: url_helper
INFO - 2023-01-13 10:59:38 --> Helper loaded: file_helper
INFO - 2023-01-13 10:59:38 --> Helper loaded: form_helper
INFO - 2023-01-13 10:59:38 --> Helper loaded: my_helper
INFO - 2023-01-13 10:59:38 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:59:38 --> Controller Class Initialized
INFO - 2023-01-13 10:59:47 --> Config Class Initialized
INFO - 2023-01-13 10:59:47 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:59:47 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:59:47 --> Utf8 Class Initialized
INFO - 2023-01-13 10:59:47 --> URI Class Initialized
INFO - 2023-01-13 10:59:47 --> Router Class Initialized
INFO - 2023-01-13 10:59:47 --> Output Class Initialized
INFO - 2023-01-13 10:59:47 --> Security Class Initialized
DEBUG - 2023-01-13 10:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:59:47 --> Input Class Initialized
INFO - 2023-01-13 10:59:47 --> Language Class Initialized
INFO - 2023-01-13 10:59:47 --> Language Class Initialized
INFO - 2023-01-13 10:59:47 --> Config Class Initialized
INFO - 2023-01-13 10:59:47 --> Loader Class Initialized
INFO - 2023-01-13 10:59:47 --> Helper loaded: url_helper
INFO - 2023-01-13 10:59:47 --> Helper loaded: file_helper
INFO - 2023-01-13 10:59:47 --> Helper loaded: form_helper
INFO - 2023-01-13 10:59:47 --> Helper loaded: my_helper
INFO - 2023-01-13 10:59:47 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:59:47 --> Controller Class Initialized
INFO - 2023-01-13 10:59:47 --> Final output sent to browser
DEBUG - 2023-01-13 10:59:47 --> Total execution time: 0.0301
INFO - 2023-01-13 10:59:51 --> Config Class Initialized
INFO - 2023-01-13 10:59:51 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:59:51 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:59:51 --> Utf8 Class Initialized
INFO - 2023-01-13 10:59:51 --> URI Class Initialized
INFO - 2023-01-13 10:59:51 --> Router Class Initialized
INFO - 2023-01-13 10:59:51 --> Output Class Initialized
INFO - 2023-01-13 10:59:51 --> Security Class Initialized
DEBUG - 2023-01-13 10:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:59:51 --> Input Class Initialized
INFO - 2023-01-13 10:59:51 --> Language Class Initialized
INFO - 2023-01-13 10:59:51 --> Language Class Initialized
INFO - 2023-01-13 10:59:51 --> Config Class Initialized
INFO - 2023-01-13 10:59:51 --> Loader Class Initialized
INFO - 2023-01-13 10:59:51 --> Helper loaded: url_helper
INFO - 2023-01-13 10:59:51 --> Helper loaded: file_helper
INFO - 2023-01-13 10:59:51 --> Helper loaded: form_helper
INFO - 2023-01-13 10:59:51 --> Helper loaded: my_helper
INFO - 2023-01-13 10:59:51 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:59:51 --> Controller Class Initialized
INFO - 2023-01-13 10:59:51 --> Final output sent to browser
DEBUG - 2023-01-13 10:59:51 --> Total execution time: 0.0258
INFO - 2023-01-13 10:59:51 --> Config Class Initialized
INFO - 2023-01-13 10:59:51 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:59:51 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:59:51 --> Utf8 Class Initialized
INFO - 2023-01-13 10:59:51 --> URI Class Initialized
INFO - 2023-01-13 10:59:51 --> Router Class Initialized
INFO - 2023-01-13 10:59:51 --> Output Class Initialized
INFO - 2023-01-13 10:59:51 --> Security Class Initialized
DEBUG - 2023-01-13 10:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:59:51 --> Input Class Initialized
INFO - 2023-01-13 10:59:51 --> Language Class Initialized
INFO - 2023-01-13 10:59:51 --> Language Class Initialized
INFO - 2023-01-13 10:59:51 --> Config Class Initialized
INFO - 2023-01-13 10:59:51 --> Loader Class Initialized
INFO - 2023-01-13 10:59:51 --> Helper loaded: url_helper
INFO - 2023-01-13 10:59:51 --> Helper loaded: file_helper
INFO - 2023-01-13 10:59:51 --> Helper loaded: form_helper
INFO - 2023-01-13 10:59:51 --> Helper loaded: my_helper
INFO - 2023-01-13 10:59:51 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:59:51 --> Controller Class Initialized
INFO - 2023-01-13 10:59:59 --> Config Class Initialized
INFO - 2023-01-13 10:59:59 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:59:59 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:59:59 --> Utf8 Class Initialized
INFO - 2023-01-13 10:59:59 --> URI Class Initialized
INFO - 2023-01-13 10:59:59 --> Router Class Initialized
INFO - 2023-01-13 10:59:59 --> Output Class Initialized
INFO - 2023-01-13 10:59:59 --> Security Class Initialized
DEBUG - 2023-01-13 10:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:59:59 --> Input Class Initialized
INFO - 2023-01-13 10:59:59 --> Language Class Initialized
INFO - 2023-01-13 10:59:59 --> Language Class Initialized
INFO - 2023-01-13 10:59:59 --> Config Class Initialized
INFO - 2023-01-13 10:59:59 --> Loader Class Initialized
INFO - 2023-01-13 10:59:59 --> Helper loaded: url_helper
INFO - 2023-01-13 10:59:59 --> Helper loaded: file_helper
INFO - 2023-01-13 10:59:59 --> Helper loaded: form_helper
INFO - 2023-01-13 10:59:59 --> Helper loaded: my_helper
INFO - 2023-01-13 10:59:59 --> Database Driver Class Initialized
DEBUG - 2023-01-13 10:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 10:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 10:59:59 --> Controller Class Initialized
INFO - 2023-01-13 10:59:59 --> Final output sent to browser
DEBUG - 2023-01-13 10:59:59 --> Total execution time: 0.0359
INFO - 2023-01-13 11:00:02 --> Config Class Initialized
INFO - 2023-01-13 11:00:02 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:00:02 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:00:02 --> Utf8 Class Initialized
INFO - 2023-01-13 11:00:02 --> URI Class Initialized
INFO - 2023-01-13 11:00:02 --> Router Class Initialized
INFO - 2023-01-13 11:00:02 --> Output Class Initialized
INFO - 2023-01-13 11:00:02 --> Security Class Initialized
DEBUG - 2023-01-13 11:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:00:02 --> Input Class Initialized
INFO - 2023-01-13 11:00:02 --> Language Class Initialized
INFO - 2023-01-13 11:00:02 --> Language Class Initialized
INFO - 2023-01-13 11:00:02 --> Config Class Initialized
INFO - 2023-01-13 11:00:02 --> Loader Class Initialized
INFO - 2023-01-13 11:00:02 --> Helper loaded: url_helper
INFO - 2023-01-13 11:00:02 --> Helper loaded: file_helper
INFO - 2023-01-13 11:00:02 --> Helper loaded: form_helper
INFO - 2023-01-13 11:00:02 --> Helper loaded: my_helper
INFO - 2023-01-13 11:00:02 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:00:02 --> Controller Class Initialized
INFO - 2023-01-13 11:00:02 --> Final output sent to browser
DEBUG - 2023-01-13 11:00:02 --> Total execution time: 0.0271
INFO - 2023-01-13 11:00:02 --> Config Class Initialized
INFO - 2023-01-13 11:00:02 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:00:02 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:00:02 --> Utf8 Class Initialized
INFO - 2023-01-13 11:00:02 --> URI Class Initialized
INFO - 2023-01-13 11:00:02 --> Router Class Initialized
INFO - 2023-01-13 11:00:02 --> Output Class Initialized
INFO - 2023-01-13 11:00:02 --> Security Class Initialized
DEBUG - 2023-01-13 11:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:00:02 --> Input Class Initialized
INFO - 2023-01-13 11:00:02 --> Language Class Initialized
INFO - 2023-01-13 11:00:02 --> Language Class Initialized
INFO - 2023-01-13 11:00:02 --> Config Class Initialized
INFO - 2023-01-13 11:00:02 --> Loader Class Initialized
INFO - 2023-01-13 11:00:02 --> Helper loaded: url_helper
INFO - 2023-01-13 11:00:02 --> Helper loaded: file_helper
INFO - 2023-01-13 11:00:02 --> Helper loaded: form_helper
INFO - 2023-01-13 11:00:02 --> Helper loaded: my_helper
INFO - 2023-01-13 11:00:02 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:00:02 --> Controller Class Initialized
INFO - 2023-01-13 11:00:11 --> Config Class Initialized
INFO - 2023-01-13 11:00:11 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:00:11 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:00:11 --> Utf8 Class Initialized
INFO - 2023-01-13 11:00:11 --> URI Class Initialized
INFO - 2023-01-13 11:00:11 --> Router Class Initialized
INFO - 2023-01-13 11:00:11 --> Output Class Initialized
INFO - 2023-01-13 11:00:11 --> Security Class Initialized
DEBUG - 2023-01-13 11:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:00:11 --> Input Class Initialized
INFO - 2023-01-13 11:00:11 --> Language Class Initialized
INFO - 2023-01-13 11:00:11 --> Language Class Initialized
INFO - 2023-01-13 11:00:11 --> Config Class Initialized
INFO - 2023-01-13 11:00:11 --> Loader Class Initialized
INFO - 2023-01-13 11:00:11 --> Helper loaded: url_helper
INFO - 2023-01-13 11:00:11 --> Helper loaded: file_helper
INFO - 2023-01-13 11:00:11 --> Helper loaded: form_helper
INFO - 2023-01-13 11:00:11 --> Helper loaded: my_helper
INFO - 2023-01-13 11:00:11 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:00:11 --> Controller Class Initialized
INFO - 2023-01-13 11:00:11 --> Final output sent to browser
DEBUG - 2023-01-13 11:00:11 --> Total execution time: 0.0285
INFO - 2023-01-13 11:00:14 --> Config Class Initialized
INFO - 2023-01-13 11:00:14 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:00:14 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:00:14 --> Utf8 Class Initialized
INFO - 2023-01-13 11:00:14 --> URI Class Initialized
INFO - 2023-01-13 11:00:14 --> Router Class Initialized
INFO - 2023-01-13 11:00:14 --> Output Class Initialized
INFO - 2023-01-13 11:00:14 --> Security Class Initialized
DEBUG - 2023-01-13 11:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:00:14 --> Input Class Initialized
INFO - 2023-01-13 11:00:14 --> Language Class Initialized
INFO - 2023-01-13 11:00:14 --> Language Class Initialized
INFO - 2023-01-13 11:00:14 --> Config Class Initialized
INFO - 2023-01-13 11:00:14 --> Loader Class Initialized
INFO - 2023-01-13 11:00:14 --> Helper loaded: url_helper
INFO - 2023-01-13 11:00:14 --> Helper loaded: file_helper
INFO - 2023-01-13 11:00:14 --> Helper loaded: form_helper
INFO - 2023-01-13 11:00:14 --> Helper loaded: my_helper
INFO - 2023-01-13 11:00:14 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:00:14 --> Controller Class Initialized
INFO - 2023-01-13 11:00:14 --> Final output sent to browser
DEBUG - 2023-01-13 11:00:14 --> Total execution time: 0.0359
INFO - 2023-01-13 11:00:14 --> Config Class Initialized
INFO - 2023-01-13 11:00:14 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:00:14 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:00:14 --> Utf8 Class Initialized
INFO - 2023-01-13 11:00:14 --> URI Class Initialized
INFO - 2023-01-13 11:00:14 --> Router Class Initialized
INFO - 2023-01-13 11:00:14 --> Output Class Initialized
INFO - 2023-01-13 11:00:14 --> Security Class Initialized
DEBUG - 2023-01-13 11:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:00:14 --> Input Class Initialized
INFO - 2023-01-13 11:00:14 --> Language Class Initialized
INFO - 2023-01-13 11:00:14 --> Language Class Initialized
INFO - 2023-01-13 11:00:14 --> Config Class Initialized
INFO - 2023-01-13 11:00:14 --> Loader Class Initialized
INFO - 2023-01-13 11:00:14 --> Helper loaded: url_helper
INFO - 2023-01-13 11:00:14 --> Helper loaded: file_helper
INFO - 2023-01-13 11:00:14 --> Helper loaded: form_helper
INFO - 2023-01-13 11:00:14 --> Helper loaded: my_helper
INFO - 2023-01-13 11:00:14 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:00:14 --> Controller Class Initialized
INFO - 2023-01-13 11:00:15 --> Config Class Initialized
INFO - 2023-01-13 11:00:15 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:00:15 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:00:15 --> Utf8 Class Initialized
INFO - 2023-01-13 11:00:15 --> URI Class Initialized
INFO - 2023-01-13 11:00:15 --> Router Class Initialized
INFO - 2023-01-13 11:00:15 --> Output Class Initialized
INFO - 2023-01-13 11:00:15 --> Security Class Initialized
DEBUG - 2023-01-13 11:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:00:15 --> Input Class Initialized
INFO - 2023-01-13 11:00:15 --> Language Class Initialized
INFO - 2023-01-13 11:00:15 --> Language Class Initialized
INFO - 2023-01-13 11:00:15 --> Config Class Initialized
INFO - 2023-01-13 11:00:15 --> Loader Class Initialized
INFO - 2023-01-13 11:00:15 --> Helper loaded: url_helper
INFO - 2023-01-13 11:00:15 --> Helper loaded: file_helper
INFO - 2023-01-13 11:00:15 --> Helper loaded: form_helper
INFO - 2023-01-13 11:00:15 --> Helper loaded: my_helper
INFO - 2023-01-13 11:00:15 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:00:15 --> Controller Class Initialized
INFO - 2023-01-13 11:00:15 --> Final output sent to browser
DEBUG - 2023-01-13 11:00:15 --> Total execution time: 0.0392
INFO - 2023-01-13 11:00:19 --> Config Class Initialized
INFO - 2023-01-13 11:00:19 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:00:19 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:00:19 --> Utf8 Class Initialized
INFO - 2023-01-13 11:00:19 --> URI Class Initialized
INFO - 2023-01-13 11:00:19 --> Router Class Initialized
INFO - 2023-01-13 11:00:19 --> Output Class Initialized
INFO - 2023-01-13 11:00:19 --> Security Class Initialized
DEBUG - 2023-01-13 11:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:00:19 --> Input Class Initialized
INFO - 2023-01-13 11:00:19 --> Language Class Initialized
INFO - 2023-01-13 11:00:19 --> Language Class Initialized
INFO - 2023-01-13 11:00:19 --> Config Class Initialized
INFO - 2023-01-13 11:00:19 --> Loader Class Initialized
INFO - 2023-01-13 11:00:19 --> Helper loaded: url_helper
INFO - 2023-01-13 11:00:19 --> Helper loaded: file_helper
INFO - 2023-01-13 11:00:19 --> Helper loaded: form_helper
INFO - 2023-01-13 11:00:19 --> Helper loaded: my_helper
INFO - 2023-01-13 11:00:19 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:00:19 --> Controller Class Initialized
INFO - 2023-01-13 11:00:19 --> Final output sent to browser
DEBUG - 2023-01-13 11:00:19 --> Total execution time: 0.0315
INFO - 2023-01-13 11:00:28 --> Config Class Initialized
INFO - 2023-01-13 11:00:28 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:00:28 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:00:28 --> Utf8 Class Initialized
INFO - 2023-01-13 11:00:28 --> URI Class Initialized
INFO - 2023-01-13 11:00:28 --> Router Class Initialized
INFO - 2023-01-13 11:00:28 --> Output Class Initialized
INFO - 2023-01-13 11:00:28 --> Security Class Initialized
DEBUG - 2023-01-13 11:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:00:28 --> Input Class Initialized
INFO - 2023-01-13 11:00:28 --> Language Class Initialized
INFO - 2023-01-13 11:00:28 --> Language Class Initialized
INFO - 2023-01-13 11:00:28 --> Config Class Initialized
INFO - 2023-01-13 11:00:28 --> Loader Class Initialized
INFO - 2023-01-13 11:00:28 --> Helper loaded: url_helper
INFO - 2023-01-13 11:00:28 --> Helper loaded: file_helper
INFO - 2023-01-13 11:00:28 --> Helper loaded: form_helper
INFO - 2023-01-13 11:00:28 --> Helper loaded: my_helper
INFO - 2023-01-13 11:00:28 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:00:28 --> Controller Class Initialized
INFO - 2023-01-13 11:00:28 --> Final output sent to browser
DEBUG - 2023-01-13 11:00:28 --> Total execution time: 0.0271
INFO - 2023-01-13 11:00:28 --> Config Class Initialized
INFO - 2023-01-13 11:00:28 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:00:28 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:00:28 --> Utf8 Class Initialized
INFO - 2023-01-13 11:00:28 --> URI Class Initialized
INFO - 2023-01-13 11:00:28 --> Router Class Initialized
INFO - 2023-01-13 11:00:28 --> Output Class Initialized
INFO - 2023-01-13 11:00:28 --> Security Class Initialized
DEBUG - 2023-01-13 11:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:00:28 --> Input Class Initialized
INFO - 2023-01-13 11:00:28 --> Language Class Initialized
INFO - 2023-01-13 11:00:28 --> Language Class Initialized
INFO - 2023-01-13 11:00:28 --> Config Class Initialized
INFO - 2023-01-13 11:00:28 --> Loader Class Initialized
INFO - 2023-01-13 11:00:28 --> Helper loaded: url_helper
INFO - 2023-01-13 11:00:28 --> Helper loaded: file_helper
INFO - 2023-01-13 11:00:28 --> Helper loaded: form_helper
INFO - 2023-01-13 11:00:28 --> Helper loaded: my_helper
INFO - 2023-01-13 11:00:28 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:00:28 --> Controller Class Initialized
INFO - 2023-01-13 11:00:37 --> Config Class Initialized
INFO - 2023-01-13 11:00:37 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:00:37 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:00:37 --> Utf8 Class Initialized
INFO - 2023-01-13 11:00:37 --> URI Class Initialized
INFO - 2023-01-13 11:00:37 --> Router Class Initialized
INFO - 2023-01-13 11:00:37 --> Output Class Initialized
INFO - 2023-01-13 11:00:37 --> Security Class Initialized
DEBUG - 2023-01-13 11:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:00:37 --> Input Class Initialized
INFO - 2023-01-13 11:00:37 --> Language Class Initialized
INFO - 2023-01-13 11:00:37 --> Language Class Initialized
INFO - 2023-01-13 11:00:37 --> Config Class Initialized
INFO - 2023-01-13 11:00:37 --> Loader Class Initialized
INFO - 2023-01-13 11:00:37 --> Helper loaded: url_helper
INFO - 2023-01-13 11:00:37 --> Helper loaded: file_helper
INFO - 2023-01-13 11:00:37 --> Helper loaded: form_helper
INFO - 2023-01-13 11:00:37 --> Helper loaded: my_helper
INFO - 2023-01-13 11:00:37 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:00:37 --> Controller Class Initialized
INFO - 2023-01-13 11:00:37 --> Final output sent to browser
DEBUG - 2023-01-13 11:00:37 --> Total execution time: 0.0292
INFO - 2023-01-13 11:00:40 --> Config Class Initialized
INFO - 2023-01-13 11:00:40 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:00:40 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:00:40 --> Utf8 Class Initialized
INFO - 2023-01-13 11:00:40 --> URI Class Initialized
INFO - 2023-01-13 11:00:40 --> Router Class Initialized
INFO - 2023-01-13 11:00:40 --> Output Class Initialized
INFO - 2023-01-13 11:00:40 --> Security Class Initialized
DEBUG - 2023-01-13 11:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:00:40 --> Input Class Initialized
INFO - 2023-01-13 11:00:40 --> Language Class Initialized
INFO - 2023-01-13 11:00:40 --> Language Class Initialized
INFO - 2023-01-13 11:00:40 --> Config Class Initialized
INFO - 2023-01-13 11:00:40 --> Loader Class Initialized
INFO - 2023-01-13 11:00:40 --> Helper loaded: url_helper
INFO - 2023-01-13 11:00:40 --> Helper loaded: file_helper
INFO - 2023-01-13 11:00:40 --> Helper loaded: form_helper
INFO - 2023-01-13 11:00:40 --> Helper loaded: my_helper
INFO - 2023-01-13 11:00:40 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:00:40 --> Controller Class Initialized
INFO - 2023-01-13 11:00:40 --> Final output sent to browser
DEBUG - 2023-01-13 11:00:40 --> Total execution time: 0.0395
INFO - 2023-01-13 11:00:40 --> Config Class Initialized
INFO - 2023-01-13 11:00:40 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:00:40 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:00:40 --> Utf8 Class Initialized
INFO - 2023-01-13 11:00:40 --> URI Class Initialized
INFO - 2023-01-13 11:00:40 --> Router Class Initialized
INFO - 2023-01-13 11:00:40 --> Output Class Initialized
INFO - 2023-01-13 11:00:40 --> Security Class Initialized
DEBUG - 2023-01-13 11:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:00:40 --> Input Class Initialized
INFO - 2023-01-13 11:00:40 --> Language Class Initialized
INFO - 2023-01-13 11:00:40 --> Language Class Initialized
INFO - 2023-01-13 11:00:40 --> Config Class Initialized
INFO - 2023-01-13 11:00:40 --> Loader Class Initialized
INFO - 2023-01-13 11:00:40 --> Helper loaded: url_helper
INFO - 2023-01-13 11:00:40 --> Helper loaded: file_helper
INFO - 2023-01-13 11:00:40 --> Helper loaded: form_helper
INFO - 2023-01-13 11:00:40 --> Helper loaded: my_helper
INFO - 2023-01-13 11:00:40 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:00:40 --> Controller Class Initialized
INFO - 2023-01-13 11:00:46 --> Config Class Initialized
INFO - 2023-01-13 11:00:46 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:00:46 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:00:46 --> Utf8 Class Initialized
INFO - 2023-01-13 11:00:46 --> URI Class Initialized
INFO - 2023-01-13 11:00:46 --> Router Class Initialized
INFO - 2023-01-13 11:00:46 --> Output Class Initialized
INFO - 2023-01-13 11:00:46 --> Security Class Initialized
DEBUG - 2023-01-13 11:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:00:46 --> Input Class Initialized
INFO - 2023-01-13 11:00:46 --> Language Class Initialized
INFO - 2023-01-13 11:00:46 --> Language Class Initialized
INFO - 2023-01-13 11:00:46 --> Config Class Initialized
INFO - 2023-01-13 11:00:46 --> Loader Class Initialized
INFO - 2023-01-13 11:00:46 --> Helper loaded: url_helper
INFO - 2023-01-13 11:00:46 --> Helper loaded: file_helper
INFO - 2023-01-13 11:00:46 --> Helper loaded: form_helper
INFO - 2023-01-13 11:00:46 --> Helper loaded: my_helper
INFO - 2023-01-13 11:00:46 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:00:46 --> Controller Class Initialized
INFO - 2023-01-13 11:00:46 --> Final output sent to browser
DEBUG - 2023-01-13 11:00:46 --> Total execution time: 0.0290
INFO - 2023-01-13 11:00:52 --> Config Class Initialized
INFO - 2023-01-13 11:00:52 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:00:52 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:00:52 --> Utf8 Class Initialized
INFO - 2023-01-13 11:00:52 --> URI Class Initialized
INFO - 2023-01-13 11:00:52 --> Router Class Initialized
INFO - 2023-01-13 11:00:52 --> Output Class Initialized
INFO - 2023-01-13 11:00:52 --> Security Class Initialized
DEBUG - 2023-01-13 11:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:00:52 --> Input Class Initialized
INFO - 2023-01-13 11:00:52 --> Language Class Initialized
INFO - 2023-01-13 11:00:52 --> Language Class Initialized
INFO - 2023-01-13 11:00:52 --> Config Class Initialized
INFO - 2023-01-13 11:00:52 --> Loader Class Initialized
INFO - 2023-01-13 11:00:52 --> Helper loaded: url_helper
INFO - 2023-01-13 11:00:52 --> Helper loaded: file_helper
INFO - 2023-01-13 11:00:52 --> Helper loaded: form_helper
INFO - 2023-01-13 11:00:52 --> Helper loaded: my_helper
INFO - 2023-01-13 11:00:52 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:00:52 --> Controller Class Initialized
INFO - 2023-01-13 11:00:52 --> Final output sent to browser
DEBUG - 2023-01-13 11:00:52 --> Total execution time: 0.0352
INFO - 2023-01-13 11:00:52 --> Config Class Initialized
INFO - 2023-01-13 11:00:52 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:00:52 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:00:52 --> Utf8 Class Initialized
INFO - 2023-01-13 11:00:52 --> URI Class Initialized
INFO - 2023-01-13 11:00:52 --> Router Class Initialized
INFO - 2023-01-13 11:00:52 --> Output Class Initialized
INFO - 2023-01-13 11:00:52 --> Security Class Initialized
DEBUG - 2023-01-13 11:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:00:52 --> Input Class Initialized
INFO - 2023-01-13 11:00:52 --> Language Class Initialized
INFO - 2023-01-13 11:00:52 --> Language Class Initialized
INFO - 2023-01-13 11:00:52 --> Config Class Initialized
INFO - 2023-01-13 11:00:52 --> Loader Class Initialized
INFO - 2023-01-13 11:00:52 --> Helper loaded: url_helper
INFO - 2023-01-13 11:00:52 --> Helper loaded: file_helper
INFO - 2023-01-13 11:00:52 --> Helper loaded: form_helper
INFO - 2023-01-13 11:00:52 --> Helper loaded: my_helper
INFO - 2023-01-13 11:00:52 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:00:52 --> Controller Class Initialized
INFO - 2023-01-13 11:01:01 --> Config Class Initialized
INFO - 2023-01-13 11:01:01 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:01:01 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:01:01 --> Utf8 Class Initialized
INFO - 2023-01-13 11:01:01 --> URI Class Initialized
INFO - 2023-01-13 11:01:01 --> Router Class Initialized
INFO - 2023-01-13 11:01:01 --> Output Class Initialized
INFO - 2023-01-13 11:01:01 --> Security Class Initialized
DEBUG - 2023-01-13 11:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:01:01 --> Input Class Initialized
INFO - 2023-01-13 11:01:01 --> Language Class Initialized
INFO - 2023-01-13 11:01:01 --> Language Class Initialized
INFO - 2023-01-13 11:01:01 --> Config Class Initialized
INFO - 2023-01-13 11:01:01 --> Loader Class Initialized
INFO - 2023-01-13 11:01:01 --> Helper loaded: url_helper
INFO - 2023-01-13 11:01:01 --> Helper loaded: file_helper
INFO - 2023-01-13 11:01:01 --> Helper loaded: form_helper
INFO - 2023-01-13 11:01:01 --> Helper loaded: my_helper
INFO - 2023-01-13 11:01:01 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:01:01 --> Controller Class Initialized
INFO - 2023-01-13 11:01:48 --> Config Class Initialized
INFO - 2023-01-13 11:01:48 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:01:48 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:01:48 --> Utf8 Class Initialized
INFO - 2023-01-13 11:01:48 --> URI Class Initialized
INFO - 2023-01-13 11:01:48 --> Router Class Initialized
INFO - 2023-01-13 11:01:48 --> Output Class Initialized
INFO - 2023-01-13 11:01:48 --> Security Class Initialized
DEBUG - 2023-01-13 11:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:01:48 --> Input Class Initialized
INFO - 2023-01-13 11:01:48 --> Language Class Initialized
INFO - 2023-01-13 11:01:48 --> Language Class Initialized
INFO - 2023-01-13 11:01:48 --> Config Class Initialized
INFO - 2023-01-13 11:01:48 --> Loader Class Initialized
INFO - 2023-01-13 11:01:48 --> Helper loaded: url_helper
INFO - 2023-01-13 11:01:48 --> Helper loaded: file_helper
INFO - 2023-01-13 11:01:48 --> Helper loaded: form_helper
INFO - 2023-01-13 11:01:48 --> Helper loaded: my_helper
INFO - 2023-01-13 11:01:48 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:01:48 --> Controller Class Initialized
DEBUG - 2023-01-13 11:01:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-13 11:01:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:01:48 --> Final output sent to browser
DEBUG - 2023-01-13 11:01:48 --> Total execution time: 0.0301
INFO - 2023-01-13 11:10:42 --> Config Class Initialized
INFO - 2023-01-13 11:10:42 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:10:42 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:10:42 --> Utf8 Class Initialized
INFO - 2023-01-13 11:10:42 --> URI Class Initialized
INFO - 2023-01-13 11:10:42 --> Router Class Initialized
INFO - 2023-01-13 11:10:42 --> Output Class Initialized
INFO - 2023-01-13 11:10:42 --> Security Class Initialized
DEBUG - 2023-01-13 11:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:10:42 --> Input Class Initialized
INFO - 2023-01-13 11:10:42 --> Language Class Initialized
INFO - 2023-01-13 11:10:42 --> Language Class Initialized
INFO - 2023-01-13 11:10:42 --> Config Class Initialized
INFO - 2023-01-13 11:10:42 --> Loader Class Initialized
INFO - 2023-01-13 11:10:42 --> Helper loaded: url_helper
INFO - 2023-01-13 11:10:42 --> Helper loaded: file_helper
INFO - 2023-01-13 11:10:42 --> Helper loaded: form_helper
INFO - 2023-01-13 11:10:42 --> Helper loaded: my_helper
INFO - 2023-01-13 11:10:42 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:10:42 --> Controller Class Initialized
DEBUG - 2023-01-13 11:10:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-13 11:10:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:10:42 --> Final output sent to browser
DEBUG - 2023-01-13 11:10:42 --> Total execution time: 0.0445
INFO - 2023-01-13 11:10:44 --> Config Class Initialized
INFO - 2023-01-13 11:10:44 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:10:44 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:10:44 --> Utf8 Class Initialized
INFO - 2023-01-13 11:10:44 --> URI Class Initialized
INFO - 2023-01-13 11:10:44 --> Router Class Initialized
INFO - 2023-01-13 11:10:44 --> Output Class Initialized
INFO - 2023-01-13 11:10:44 --> Security Class Initialized
DEBUG - 2023-01-13 11:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:10:44 --> Input Class Initialized
INFO - 2023-01-13 11:10:44 --> Language Class Initialized
INFO - 2023-01-13 11:10:44 --> Language Class Initialized
INFO - 2023-01-13 11:10:44 --> Config Class Initialized
INFO - 2023-01-13 11:10:44 --> Loader Class Initialized
INFO - 2023-01-13 11:10:44 --> Helper loaded: url_helper
INFO - 2023-01-13 11:10:44 --> Helper loaded: file_helper
INFO - 2023-01-13 11:10:44 --> Helper loaded: form_helper
INFO - 2023-01-13 11:10:44 --> Helper loaded: my_helper
INFO - 2023-01-13 11:10:44 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:10:44 --> Controller Class Initialized
DEBUG - 2023-01-13 11:10:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-13 11:10:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:10:44 --> Final output sent to browser
DEBUG - 2023-01-13 11:10:44 --> Total execution time: 0.0260
INFO - 2023-01-13 11:10:45 --> Config Class Initialized
INFO - 2023-01-13 11:10:45 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:10:45 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:10:45 --> Utf8 Class Initialized
INFO - 2023-01-13 11:10:45 --> URI Class Initialized
INFO - 2023-01-13 11:10:45 --> Router Class Initialized
INFO - 2023-01-13 11:10:45 --> Output Class Initialized
INFO - 2023-01-13 11:10:45 --> Security Class Initialized
DEBUG - 2023-01-13 11:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:10:45 --> Input Class Initialized
INFO - 2023-01-13 11:10:45 --> Language Class Initialized
INFO - 2023-01-13 11:10:45 --> Language Class Initialized
INFO - 2023-01-13 11:10:45 --> Config Class Initialized
INFO - 2023-01-13 11:10:45 --> Loader Class Initialized
INFO - 2023-01-13 11:10:45 --> Helper loaded: url_helper
INFO - 2023-01-13 11:10:45 --> Helper loaded: file_helper
INFO - 2023-01-13 11:10:45 --> Helper loaded: form_helper
INFO - 2023-01-13 11:10:45 --> Helper loaded: my_helper
INFO - 2023-01-13 11:10:45 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:10:45 --> Controller Class Initialized
DEBUG - 2023-01-13 11:10:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-13 11:10:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:10:45 --> Final output sent to browser
DEBUG - 2023-01-13 11:10:45 --> Total execution time: 0.0265
INFO - 2023-01-13 11:10:46 --> Config Class Initialized
INFO - 2023-01-13 11:10:46 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:10:46 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:10:46 --> Utf8 Class Initialized
INFO - 2023-01-13 11:10:46 --> URI Class Initialized
INFO - 2023-01-13 11:10:46 --> Router Class Initialized
INFO - 2023-01-13 11:10:46 --> Output Class Initialized
INFO - 2023-01-13 11:10:46 --> Security Class Initialized
DEBUG - 2023-01-13 11:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:10:46 --> Input Class Initialized
INFO - 2023-01-13 11:10:46 --> Language Class Initialized
INFO - 2023-01-13 11:10:46 --> Language Class Initialized
INFO - 2023-01-13 11:10:46 --> Config Class Initialized
INFO - 2023-01-13 11:10:46 --> Loader Class Initialized
INFO - 2023-01-13 11:10:46 --> Helper loaded: url_helper
INFO - 2023-01-13 11:10:46 --> Helper loaded: file_helper
INFO - 2023-01-13 11:10:46 --> Helper loaded: form_helper
INFO - 2023-01-13 11:10:46 --> Helper loaded: my_helper
INFO - 2023-01-13 11:10:46 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:10:46 --> Controller Class Initialized
DEBUG - 2023-01-13 11:10:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-13 11:10:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:10:46 --> Final output sent to browser
DEBUG - 2023-01-13 11:10:46 --> Total execution time: 0.0250
INFO - 2023-01-13 11:10:46 --> Config Class Initialized
INFO - 2023-01-13 11:10:46 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:10:46 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:10:46 --> Utf8 Class Initialized
INFO - 2023-01-13 11:10:46 --> URI Class Initialized
INFO - 2023-01-13 11:10:46 --> Router Class Initialized
INFO - 2023-01-13 11:10:46 --> Output Class Initialized
INFO - 2023-01-13 11:10:46 --> Security Class Initialized
DEBUG - 2023-01-13 11:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:10:46 --> Input Class Initialized
INFO - 2023-01-13 11:10:46 --> Language Class Initialized
INFO - 2023-01-13 11:10:46 --> Language Class Initialized
INFO - 2023-01-13 11:10:46 --> Config Class Initialized
INFO - 2023-01-13 11:10:46 --> Loader Class Initialized
INFO - 2023-01-13 11:10:46 --> Helper loaded: url_helper
INFO - 2023-01-13 11:10:46 --> Helper loaded: file_helper
INFO - 2023-01-13 11:10:46 --> Helper loaded: form_helper
INFO - 2023-01-13 11:10:46 --> Helper loaded: my_helper
INFO - 2023-01-13 11:10:46 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:10:46 --> Controller Class Initialized
DEBUG - 2023-01-13 11:10:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-13 11:10:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:10:46 --> Final output sent to browser
DEBUG - 2023-01-13 11:10:46 --> Total execution time: 0.0452
INFO - 2023-01-13 11:10:46 --> Config Class Initialized
INFO - 2023-01-13 11:10:46 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:10:46 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:10:46 --> Utf8 Class Initialized
INFO - 2023-01-13 11:10:46 --> URI Class Initialized
INFO - 2023-01-13 11:10:46 --> Router Class Initialized
INFO - 2023-01-13 11:10:46 --> Output Class Initialized
INFO - 2023-01-13 11:10:46 --> Security Class Initialized
DEBUG - 2023-01-13 11:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:10:46 --> Input Class Initialized
INFO - 2023-01-13 11:10:46 --> Language Class Initialized
INFO - 2023-01-13 11:10:46 --> Language Class Initialized
INFO - 2023-01-13 11:10:46 --> Config Class Initialized
INFO - 2023-01-13 11:10:46 --> Loader Class Initialized
INFO - 2023-01-13 11:10:46 --> Helper loaded: url_helper
INFO - 2023-01-13 11:10:46 --> Helper loaded: file_helper
INFO - 2023-01-13 11:10:46 --> Helper loaded: form_helper
INFO - 2023-01-13 11:10:46 --> Helper loaded: my_helper
INFO - 2023-01-13 11:10:46 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:10:46 --> Controller Class Initialized
DEBUG - 2023-01-13 11:10:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-13 11:10:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:10:46 --> Final output sent to browser
DEBUG - 2023-01-13 11:10:46 --> Total execution time: 0.0402
INFO - 2023-01-13 11:10:46 --> Config Class Initialized
INFO - 2023-01-13 11:10:46 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:10:46 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:10:46 --> Utf8 Class Initialized
INFO - 2023-01-13 11:10:46 --> URI Class Initialized
INFO - 2023-01-13 11:10:46 --> Router Class Initialized
INFO - 2023-01-13 11:10:46 --> Output Class Initialized
INFO - 2023-01-13 11:10:46 --> Security Class Initialized
DEBUG - 2023-01-13 11:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:10:46 --> Input Class Initialized
INFO - 2023-01-13 11:10:46 --> Language Class Initialized
INFO - 2023-01-13 11:10:46 --> Language Class Initialized
INFO - 2023-01-13 11:10:46 --> Config Class Initialized
INFO - 2023-01-13 11:10:46 --> Loader Class Initialized
INFO - 2023-01-13 11:10:46 --> Helper loaded: url_helper
INFO - 2023-01-13 11:10:46 --> Helper loaded: file_helper
INFO - 2023-01-13 11:10:46 --> Helper loaded: form_helper
INFO - 2023-01-13 11:10:46 --> Helper loaded: my_helper
INFO - 2023-01-13 11:10:46 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:10:46 --> Controller Class Initialized
DEBUG - 2023-01-13 11:10:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-13 11:10:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:10:46 --> Final output sent to browser
DEBUG - 2023-01-13 11:10:46 --> Total execution time: 0.0230
INFO - 2023-01-13 11:10:46 --> Config Class Initialized
INFO - 2023-01-13 11:10:46 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:10:46 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:10:46 --> Utf8 Class Initialized
INFO - 2023-01-13 11:10:46 --> URI Class Initialized
INFO - 2023-01-13 11:10:46 --> Router Class Initialized
INFO - 2023-01-13 11:10:46 --> Output Class Initialized
INFO - 2023-01-13 11:10:46 --> Security Class Initialized
DEBUG - 2023-01-13 11:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:10:46 --> Input Class Initialized
INFO - 2023-01-13 11:10:46 --> Language Class Initialized
INFO - 2023-01-13 11:10:46 --> Language Class Initialized
INFO - 2023-01-13 11:10:46 --> Config Class Initialized
INFO - 2023-01-13 11:10:46 --> Loader Class Initialized
INFO - 2023-01-13 11:10:46 --> Helper loaded: url_helper
INFO - 2023-01-13 11:10:47 --> Helper loaded: file_helper
INFO - 2023-01-13 11:10:47 --> Helper loaded: form_helper
INFO - 2023-01-13 11:10:47 --> Helper loaded: my_helper
INFO - 2023-01-13 11:10:47 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:10:47 --> Controller Class Initialized
DEBUG - 2023-01-13 11:10:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-13 11:10:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:10:47 --> Final output sent to browser
DEBUG - 2023-01-13 11:10:47 --> Total execution time: 0.0230
INFO - 2023-01-13 11:11:10 --> Config Class Initialized
INFO - 2023-01-13 11:11:10 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:11:10 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:11:10 --> Utf8 Class Initialized
INFO - 2023-01-13 11:11:10 --> URI Class Initialized
INFO - 2023-01-13 11:11:10 --> Router Class Initialized
INFO - 2023-01-13 11:11:10 --> Output Class Initialized
INFO - 2023-01-13 11:11:10 --> Security Class Initialized
DEBUG - 2023-01-13 11:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:11:10 --> Input Class Initialized
INFO - 2023-01-13 11:11:10 --> Language Class Initialized
INFO - 2023-01-13 11:11:10 --> Language Class Initialized
INFO - 2023-01-13 11:11:10 --> Config Class Initialized
INFO - 2023-01-13 11:11:10 --> Loader Class Initialized
INFO - 2023-01-13 11:11:10 --> Helper loaded: url_helper
INFO - 2023-01-13 11:11:10 --> Helper loaded: file_helper
INFO - 2023-01-13 11:11:10 --> Helper loaded: form_helper
INFO - 2023-01-13 11:11:10 --> Helper loaded: my_helper
INFO - 2023-01-13 11:11:10 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:11:10 --> Controller Class Initialized
DEBUG - 2023-01-13 11:11:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-13 11:11:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:11:10 --> Final output sent to browser
DEBUG - 2023-01-13 11:11:10 --> Total execution time: 0.0244
INFO - 2023-01-13 11:11:14 --> Config Class Initialized
INFO - 2023-01-13 11:11:14 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:11:14 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:11:14 --> Utf8 Class Initialized
INFO - 2023-01-13 11:11:14 --> URI Class Initialized
INFO - 2023-01-13 11:11:14 --> Router Class Initialized
INFO - 2023-01-13 11:11:14 --> Output Class Initialized
INFO - 2023-01-13 11:11:14 --> Security Class Initialized
DEBUG - 2023-01-13 11:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:11:14 --> Input Class Initialized
INFO - 2023-01-13 11:11:14 --> Language Class Initialized
INFO - 2023-01-13 11:11:14 --> Language Class Initialized
INFO - 2023-01-13 11:11:14 --> Config Class Initialized
INFO - 2023-01-13 11:11:14 --> Loader Class Initialized
INFO - 2023-01-13 11:11:14 --> Helper loaded: url_helper
INFO - 2023-01-13 11:11:14 --> Helper loaded: file_helper
INFO - 2023-01-13 11:11:14 --> Helper loaded: form_helper
INFO - 2023-01-13 11:11:14 --> Helper loaded: my_helper
INFO - 2023-01-13 11:11:14 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:11:14 --> Controller Class Initialized
DEBUG - 2023-01-13 11:11:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/cetak_absensi.php
INFO - 2023-01-13 11:11:14 --> Final output sent to browser
DEBUG - 2023-01-13 11:11:14 --> Total execution time: 0.0274
INFO - 2023-01-13 11:11:20 --> Config Class Initialized
INFO - 2023-01-13 11:11:20 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:11:20 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:11:20 --> Utf8 Class Initialized
INFO - 2023-01-13 11:11:20 --> URI Class Initialized
INFO - 2023-01-13 11:11:20 --> Router Class Initialized
INFO - 2023-01-13 11:11:20 --> Output Class Initialized
INFO - 2023-01-13 11:11:20 --> Security Class Initialized
DEBUG - 2023-01-13 11:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:11:20 --> Input Class Initialized
INFO - 2023-01-13 11:11:20 --> Language Class Initialized
INFO - 2023-01-13 11:11:20 --> Language Class Initialized
INFO - 2023-01-13 11:11:20 --> Config Class Initialized
INFO - 2023-01-13 11:11:20 --> Loader Class Initialized
INFO - 2023-01-13 11:11:20 --> Helper loaded: url_helper
INFO - 2023-01-13 11:11:20 --> Helper loaded: file_helper
INFO - 2023-01-13 11:11:20 --> Helper loaded: form_helper
INFO - 2023-01-13 11:11:20 --> Helper loaded: my_helper
INFO - 2023-01-13 11:11:20 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:11:20 --> Controller Class Initialized
DEBUG - 2023-01-13 11:11:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/cetak_absensi.php
INFO - 2023-01-13 11:11:20 --> Final output sent to browser
DEBUG - 2023-01-13 11:11:20 --> Total execution time: 0.0401
INFO - 2023-01-13 11:13:04 --> Config Class Initialized
INFO - 2023-01-13 11:13:04 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:13:04 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:13:04 --> Utf8 Class Initialized
INFO - 2023-01-13 11:13:04 --> URI Class Initialized
INFO - 2023-01-13 11:13:04 --> Router Class Initialized
INFO - 2023-01-13 11:13:04 --> Output Class Initialized
INFO - 2023-01-13 11:13:04 --> Security Class Initialized
DEBUG - 2023-01-13 11:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:13:04 --> Input Class Initialized
INFO - 2023-01-13 11:13:04 --> Language Class Initialized
INFO - 2023-01-13 11:13:04 --> Language Class Initialized
INFO - 2023-01-13 11:13:04 --> Config Class Initialized
INFO - 2023-01-13 11:13:04 --> Loader Class Initialized
INFO - 2023-01-13 11:13:04 --> Helper loaded: url_helper
INFO - 2023-01-13 11:13:04 --> Helper loaded: file_helper
INFO - 2023-01-13 11:13:04 --> Helper loaded: form_helper
INFO - 2023-01-13 11:13:04 --> Helper loaded: my_helper
INFO - 2023-01-13 11:13:04 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:13:04 --> Controller Class Initialized
DEBUG - 2023-01-13 11:13:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/cetak_absensi.php
INFO - 2023-01-13 11:13:04 --> Final output sent to browser
DEBUG - 2023-01-13 11:13:04 --> Total execution time: 0.0313
INFO - 2023-01-13 11:13:24 --> Config Class Initialized
INFO - 2023-01-13 11:13:24 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:13:24 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:13:24 --> Utf8 Class Initialized
INFO - 2023-01-13 11:13:24 --> URI Class Initialized
INFO - 2023-01-13 11:13:24 --> Router Class Initialized
INFO - 2023-01-13 11:13:24 --> Output Class Initialized
INFO - 2023-01-13 11:13:24 --> Security Class Initialized
DEBUG - 2023-01-13 11:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:13:24 --> Input Class Initialized
INFO - 2023-01-13 11:13:24 --> Language Class Initialized
INFO - 2023-01-13 11:13:24 --> Language Class Initialized
INFO - 2023-01-13 11:13:24 --> Config Class Initialized
INFO - 2023-01-13 11:13:24 --> Loader Class Initialized
INFO - 2023-01-13 11:13:24 --> Helper loaded: url_helper
INFO - 2023-01-13 11:13:24 --> Helper loaded: file_helper
INFO - 2023-01-13 11:13:24 --> Helper loaded: form_helper
INFO - 2023-01-13 11:13:24 --> Helper loaded: my_helper
INFO - 2023-01-13 11:13:24 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:13:24 --> Controller Class Initialized
DEBUG - 2023-01-13 11:13:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_absensi/views/list.php
DEBUG - 2023-01-13 11:13:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:13:24 --> Final output sent to browser
DEBUG - 2023-01-13 11:13:24 --> Total execution time: 0.0273
INFO - 2023-01-13 11:13:26 --> Config Class Initialized
INFO - 2023-01-13 11:13:26 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:13:26 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:13:26 --> Utf8 Class Initialized
INFO - 2023-01-13 11:13:26 --> URI Class Initialized
INFO - 2023-01-13 11:13:26 --> Router Class Initialized
INFO - 2023-01-13 11:13:26 --> Output Class Initialized
INFO - 2023-01-13 11:13:26 --> Security Class Initialized
DEBUG - 2023-01-13 11:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:13:26 --> Input Class Initialized
INFO - 2023-01-13 11:13:26 --> Language Class Initialized
INFO - 2023-01-13 11:13:26 --> Language Class Initialized
INFO - 2023-01-13 11:13:26 --> Config Class Initialized
INFO - 2023-01-13 11:13:26 --> Loader Class Initialized
INFO - 2023-01-13 11:13:26 --> Helper loaded: url_helper
INFO - 2023-01-13 11:13:26 --> Helper loaded: file_helper
INFO - 2023-01-13 11:13:26 --> Helper loaded: form_helper
INFO - 2023-01-13 11:13:26 --> Helper loaded: my_helper
INFO - 2023-01-13 11:13:26 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:13:26 --> Controller Class Initialized
DEBUG - 2023-01-13 11:13:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_absensi/views/cetak.php
INFO - 2023-01-13 11:13:26 --> Final output sent to browser
DEBUG - 2023-01-13 11:13:26 --> Total execution time: 0.0269
INFO - 2023-01-13 11:13:32 --> Config Class Initialized
INFO - 2023-01-13 11:13:32 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:13:32 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:13:32 --> Utf8 Class Initialized
INFO - 2023-01-13 11:13:32 --> URI Class Initialized
INFO - 2023-01-13 11:13:32 --> Router Class Initialized
INFO - 2023-01-13 11:13:32 --> Output Class Initialized
INFO - 2023-01-13 11:13:32 --> Security Class Initialized
DEBUG - 2023-01-13 11:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:13:32 --> Input Class Initialized
INFO - 2023-01-13 11:13:32 --> Language Class Initialized
INFO - 2023-01-13 11:13:32 --> Language Class Initialized
INFO - 2023-01-13 11:13:32 --> Config Class Initialized
INFO - 2023-01-13 11:13:32 --> Loader Class Initialized
INFO - 2023-01-13 11:13:32 --> Helper loaded: url_helper
INFO - 2023-01-13 11:13:32 --> Helper loaded: file_helper
INFO - 2023-01-13 11:13:32 --> Helper loaded: form_helper
INFO - 2023-01-13 11:13:32 --> Helper loaded: my_helper
INFO - 2023-01-13 11:13:32 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:13:32 --> Controller Class Initialized
DEBUG - 2023-01-13 11:13:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2023-01-13 11:13:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:13:32 --> Final output sent to browser
DEBUG - 2023-01-13 11:13:32 --> Total execution time: 0.0388
INFO - 2023-01-13 11:13:33 --> Config Class Initialized
INFO - 2023-01-13 11:13:33 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:13:33 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:13:33 --> Utf8 Class Initialized
INFO - 2023-01-13 11:13:33 --> URI Class Initialized
INFO - 2023-01-13 11:13:33 --> Router Class Initialized
INFO - 2023-01-13 11:13:33 --> Output Class Initialized
INFO - 2023-01-13 11:13:33 --> Security Class Initialized
DEBUG - 2023-01-13 11:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:13:33 --> Input Class Initialized
INFO - 2023-01-13 11:13:33 --> Language Class Initialized
INFO - 2023-01-13 11:13:33 --> Language Class Initialized
INFO - 2023-01-13 11:13:33 --> Config Class Initialized
INFO - 2023-01-13 11:13:33 --> Loader Class Initialized
INFO - 2023-01-13 11:13:33 --> Helper loaded: url_helper
INFO - 2023-01-13 11:13:33 --> Helper loaded: file_helper
INFO - 2023-01-13 11:13:33 --> Helper loaded: form_helper
INFO - 2023-01-13 11:13:33 --> Helper loaded: my_helper
INFO - 2023-01-13 11:13:33 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:13:33 --> Controller Class Initialized
DEBUG - 2023-01-13 11:13:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_sp/views/list.php
DEBUG - 2023-01-13 11:13:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:13:33 --> Final output sent to browser
DEBUG - 2023-01-13 11:13:33 --> Total execution time: 0.0427
INFO - 2023-01-13 11:13:34 --> Config Class Initialized
INFO - 2023-01-13 11:13:34 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:13:34 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:13:34 --> Utf8 Class Initialized
INFO - 2023-01-13 11:13:34 --> URI Class Initialized
INFO - 2023-01-13 11:13:34 --> Router Class Initialized
INFO - 2023-01-13 11:13:34 --> Output Class Initialized
INFO - 2023-01-13 11:13:34 --> Security Class Initialized
DEBUG - 2023-01-13 11:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:13:34 --> Input Class Initialized
INFO - 2023-01-13 11:13:34 --> Language Class Initialized
INFO - 2023-01-13 11:13:34 --> Language Class Initialized
INFO - 2023-01-13 11:13:34 --> Config Class Initialized
INFO - 2023-01-13 11:13:34 --> Loader Class Initialized
INFO - 2023-01-13 11:13:34 --> Helper loaded: url_helper
INFO - 2023-01-13 11:13:34 --> Helper loaded: file_helper
INFO - 2023-01-13 11:13:34 --> Helper loaded: form_helper
INFO - 2023-01-13 11:13:34 --> Helper loaded: my_helper
INFO - 2023-01-13 11:13:34 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:13:34 --> Controller Class Initialized
DEBUG - 2023-01-13 11:13:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_so/views/list.php
DEBUG - 2023-01-13 11:13:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:13:34 --> Final output sent to browser
DEBUG - 2023-01-13 11:13:34 --> Total execution time: 0.0441
INFO - 2023-01-13 11:13:36 --> Config Class Initialized
INFO - 2023-01-13 11:13:36 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:13:36 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:13:36 --> Utf8 Class Initialized
INFO - 2023-01-13 11:13:36 --> URI Class Initialized
INFO - 2023-01-13 11:13:36 --> Router Class Initialized
INFO - 2023-01-13 11:13:36 --> Output Class Initialized
INFO - 2023-01-13 11:13:36 --> Security Class Initialized
DEBUG - 2023-01-13 11:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:13:36 --> Input Class Initialized
INFO - 2023-01-13 11:13:36 --> Language Class Initialized
INFO - 2023-01-13 11:13:36 --> Language Class Initialized
INFO - 2023-01-13 11:13:36 --> Config Class Initialized
INFO - 2023-01-13 11:13:36 --> Loader Class Initialized
INFO - 2023-01-13 11:13:36 --> Helper loaded: url_helper
INFO - 2023-01-13 11:13:36 --> Helper loaded: file_helper
INFO - 2023-01-13 11:13:36 --> Helper loaded: form_helper
INFO - 2023-01-13 11:13:36 --> Helper loaded: my_helper
INFO - 2023-01-13 11:13:36 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:13:36 --> Controller Class Initialized
DEBUG - 2023-01-13 11:13:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_sp/views/list.php
DEBUG - 2023-01-13 11:13:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:13:36 --> Final output sent to browser
DEBUG - 2023-01-13 11:13:36 --> Total execution time: 0.0441
INFO - 2023-01-13 11:13:37 --> Config Class Initialized
INFO - 2023-01-13 11:13:37 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:13:37 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:13:37 --> Utf8 Class Initialized
INFO - 2023-01-13 11:13:37 --> URI Class Initialized
INFO - 2023-01-13 11:13:37 --> Router Class Initialized
INFO - 2023-01-13 11:13:37 --> Output Class Initialized
INFO - 2023-01-13 11:13:37 --> Security Class Initialized
DEBUG - 2023-01-13 11:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:13:37 --> Input Class Initialized
INFO - 2023-01-13 11:13:37 --> Language Class Initialized
INFO - 2023-01-13 11:13:37 --> Language Class Initialized
INFO - 2023-01-13 11:13:37 --> Config Class Initialized
INFO - 2023-01-13 11:13:37 --> Loader Class Initialized
INFO - 2023-01-13 11:13:37 --> Helper loaded: url_helper
INFO - 2023-01-13 11:13:37 --> Helper loaded: file_helper
INFO - 2023-01-13 11:13:37 --> Helper loaded: form_helper
INFO - 2023-01-13 11:13:37 --> Helper loaded: my_helper
INFO - 2023-01-13 11:13:37 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:13:37 --> Controller Class Initialized
DEBUG - 2023-01-13 11:13:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2023-01-13 11:13:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:13:37 --> Final output sent to browser
DEBUG - 2023-01-13 11:13:37 --> Total execution time: 0.0401
INFO - 2023-01-13 11:13:39 --> Config Class Initialized
INFO - 2023-01-13 11:13:39 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:13:39 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:13:39 --> Utf8 Class Initialized
INFO - 2023-01-13 11:13:39 --> URI Class Initialized
INFO - 2023-01-13 11:13:39 --> Router Class Initialized
INFO - 2023-01-13 11:13:39 --> Output Class Initialized
INFO - 2023-01-13 11:13:39 --> Security Class Initialized
DEBUG - 2023-01-13 11:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:13:39 --> Input Class Initialized
INFO - 2023-01-13 11:13:39 --> Language Class Initialized
INFO - 2023-01-13 11:13:39 --> Language Class Initialized
INFO - 2023-01-13 11:13:39 --> Config Class Initialized
INFO - 2023-01-13 11:13:39 --> Loader Class Initialized
INFO - 2023-01-13 11:13:39 --> Helper loaded: url_helper
INFO - 2023-01-13 11:13:39 --> Helper loaded: file_helper
INFO - 2023-01-13 11:13:39 --> Helper loaded: form_helper
INFO - 2023-01-13 11:13:39 --> Helper loaded: my_helper
INFO - 2023-01-13 11:13:39 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:13:39 --> Controller Class Initialized
ERROR - 2023-01-13 11:13:39 --> Severity: Notice --> Undefined variable: q_siswa_kelas C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 115
ERROR - 2023-01-13 11:13:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 115
DEBUG - 2023-01-13 11:13:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-13 11:13:39 --> Final output sent to browser
DEBUG - 2023-01-13 11:13:39 --> Total execution time: 0.0422
INFO - 2023-01-13 11:13:43 --> Config Class Initialized
INFO - 2023-01-13 11:13:43 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:13:43 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:13:43 --> Utf8 Class Initialized
INFO - 2023-01-13 11:13:43 --> URI Class Initialized
INFO - 2023-01-13 11:13:43 --> Router Class Initialized
INFO - 2023-01-13 11:13:43 --> Output Class Initialized
INFO - 2023-01-13 11:13:43 --> Security Class Initialized
DEBUG - 2023-01-13 11:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:13:43 --> Input Class Initialized
INFO - 2023-01-13 11:13:43 --> Language Class Initialized
INFO - 2023-01-13 11:13:43 --> Language Class Initialized
INFO - 2023-01-13 11:13:43 --> Config Class Initialized
INFO - 2023-01-13 11:13:43 --> Loader Class Initialized
INFO - 2023-01-13 11:13:43 --> Helper loaded: url_helper
INFO - 2023-01-13 11:13:43 --> Helper loaded: file_helper
INFO - 2023-01-13 11:13:43 --> Helper loaded: form_helper
INFO - 2023-01-13 11:13:43 --> Helper loaded: my_helper
INFO - 2023-01-13 11:13:43 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:13:43 --> Controller Class Initialized
DEBUG - 2023-01-13 11:13:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_keterampilan/views/cetak.php
INFO - 2023-01-13 11:13:43 --> Final output sent to browser
DEBUG - 2023-01-13 11:13:43 --> Total execution time: 0.0326
INFO - 2023-01-13 11:13:46 --> Config Class Initialized
INFO - 2023-01-13 11:13:46 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:13:46 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:13:46 --> Utf8 Class Initialized
INFO - 2023-01-13 11:13:46 --> URI Class Initialized
INFO - 2023-01-13 11:13:46 --> Router Class Initialized
INFO - 2023-01-13 11:13:46 --> Output Class Initialized
INFO - 2023-01-13 11:13:46 --> Security Class Initialized
DEBUG - 2023-01-13 11:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:13:46 --> Input Class Initialized
INFO - 2023-01-13 11:13:46 --> Language Class Initialized
INFO - 2023-01-13 11:13:46 --> Language Class Initialized
INFO - 2023-01-13 11:13:46 --> Config Class Initialized
INFO - 2023-01-13 11:13:46 --> Loader Class Initialized
INFO - 2023-01-13 11:13:46 --> Helper loaded: url_helper
INFO - 2023-01-13 11:13:46 --> Helper loaded: file_helper
INFO - 2023-01-13 11:13:46 --> Helper loaded: form_helper
INFO - 2023-01-13 11:13:46 --> Helper loaded: my_helper
INFO - 2023-01-13 11:13:46 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:13:46 --> Controller Class Initialized
DEBUG - 2023-01-13 11:13:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-13 11:13:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:13:46 --> Final output sent to browser
DEBUG - 2023-01-13 11:13:46 --> Total execution time: 0.0255
INFO - 2023-01-13 11:14:09 --> Config Class Initialized
INFO - 2023-01-13 11:14:09 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:14:09 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:14:09 --> Utf8 Class Initialized
INFO - 2023-01-13 11:14:09 --> URI Class Initialized
INFO - 2023-01-13 11:14:09 --> Router Class Initialized
INFO - 2023-01-13 11:14:09 --> Output Class Initialized
INFO - 2023-01-13 11:14:09 --> Security Class Initialized
DEBUG - 2023-01-13 11:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:14:09 --> Input Class Initialized
INFO - 2023-01-13 11:14:09 --> Language Class Initialized
INFO - 2023-01-13 11:14:09 --> Language Class Initialized
INFO - 2023-01-13 11:14:09 --> Config Class Initialized
INFO - 2023-01-13 11:14:09 --> Loader Class Initialized
INFO - 2023-01-13 11:14:09 --> Helper loaded: url_helper
INFO - 2023-01-13 11:14:09 --> Helper loaded: file_helper
INFO - 2023-01-13 11:14:09 --> Helper loaded: form_helper
INFO - 2023-01-13 11:14:09 --> Helper loaded: my_helper
INFO - 2023-01-13 11:14:09 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:14:09 --> Controller Class Initialized
DEBUG - 2023-01-13 11:14:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-13 11:14:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:14:09 --> Final output sent to browser
DEBUG - 2023-01-13 11:14:09 --> Total execution time: 0.0306
INFO - 2023-01-13 11:15:25 --> Config Class Initialized
INFO - 2023-01-13 11:15:25 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:15:25 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:15:25 --> Utf8 Class Initialized
INFO - 2023-01-13 11:15:25 --> URI Class Initialized
INFO - 2023-01-13 11:15:25 --> Router Class Initialized
INFO - 2023-01-13 11:15:25 --> Output Class Initialized
INFO - 2023-01-13 11:15:25 --> Security Class Initialized
DEBUG - 2023-01-13 11:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:15:25 --> Input Class Initialized
INFO - 2023-01-13 11:15:25 --> Language Class Initialized
INFO - 2023-01-13 11:15:25 --> Language Class Initialized
INFO - 2023-01-13 11:15:25 --> Config Class Initialized
INFO - 2023-01-13 11:15:25 --> Loader Class Initialized
INFO - 2023-01-13 11:15:25 --> Helper loaded: url_helper
INFO - 2023-01-13 11:15:25 --> Helper loaded: file_helper
INFO - 2023-01-13 11:15:25 --> Helper loaded: form_helper
INFO - 2023-01-13 11:15:25 --> Helper loaded: my_helper
INFO - 2023-01-13 11:15:25 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:15:25 --> Controller Class Initialized
DEBUG - 2023-01-13 11:15:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-13 11:15:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:15:26 --> Final output sent to browser
DEBUG - 2023-01-13 11:15:26 --> Total execution time: 0.0249
INFO - 2023-01-13 11:15:32 --> Config Class Initialized
INFO - 2023-01-13 11:15:32 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:15:32 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:15:32 --> Utf8 Class Initialized
INFO - 2023-01-13 11:15:32 --> URI Class Initialized
INFO - 2023-01-13 11:15:32 --> Router Class Initialized
INFO - 2023-01-13 11:15:32 --> Output Class Initialized
INFO - 2023-01-13 11:15:32 --> Security Class Initialized
DEBUG - 2023-01-13 11:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:15:32 --> Input Class Initialized
INFO - 2023-01-13 11:15:32 --> Language Class Initialized
INFO - 2023-01-13 11:15:32 --> Language Class Initialized
INFO - 2023-01-13 11:15:32 --> Config Class Initialized
INFO - 2023-01-13 11:15:32 --> Loader Class Initialized
INFO - 2023-01-13 11:15:32 --> Helper loaded: url_helper
INFO - 2023-01-13 11:15:32 --> Helper loaded: file_helper
INFO - 2023-01-13 11:15:32 --> Helper loaded: form_helper
INFO - 2023-01-13 11:15:32 --> Helper loaded: my_helper
INFO - 2023-01-13 11:15:32 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:15:32 --> Controller Class Initialized
DEBUG - 2023-01-13 11:15:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-13 11:15:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:15:32 --> Final output sent to browser
DEBUG - 2023-01-13 11:15:32 --> Total execution time: 0.0357
INFO - 2023-01-13 11:15:35 --> Config Class Initialized
INFO - 2023-01-13 11:15:35 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:15:35 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:15:35 --> Utf8 Class Initialized
INFO - 2023-01-13 11:15:35 --> URI Class Initialized
INFO - 2023-01-13 11:15:35 --> Router Class Initialized
INFO - 2023-01-13 11:15:35 --> Output Class Initialized
INFO - 2023-01-13 11:15:35 --> Security Class Initialized
DEBUG - 2023-01-13 11:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:15:35 --> Input Class Initialized
INFO - 2023-01-13 11:15:35 --> Language Class Initialized
INFO - 2023-01-13 11:15:35 --> Language Class Initialized
INFO - 2023-01-13 11:15:35 --> Config Class Initialized
INFO - 2023-01-13 11:15:35 --> Loader Class Initialized
INFO - 2023-01-13 11:15:35 --> Helper loaded: url_helper
INFO - 2023-01-13 11:15:35 --> Helper loaded: file_helper
INFO - 2023-01-13 11:15:35 --> Helper loaded: form_helper
INFO - 2023-01-13 11:15:35 --> Helper loaded: my_helper
INFO - 2023-01-13 11:15:35 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:15:35 --> Controller Class Initialized
DEBUG - 2023-01-13 11:15:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_keterampilan/views/list.php
DEBUG - 2023-01-13 11:15:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:15:35 --> Final output sent to browser
DEBUG - 2023-01-13 11:15:35 --> Total execution time: 0.0383
INFO - 2023-01-13 11:15:59 --> Config Class Initialized
INFO - 2023-01-13 11:15:59 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:15:59 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:15:59 --> Utf8 Class Initialized
INFO - 2023-01-13 11:15:59 --> URI Class Initialized
INFO - 2023-01-13 11:15:59 --> Router Class Initialized
INFO - 2023-01-13 11:15:59 --> Output Class Initialized
INFO - 2023-01-13 11:15:59 --> Security Class Initialized
DEBUG - 2023-01-13 11:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:15:59 --> Input Class Initialized
INFO - 2023-01-13 11:15:59 --> Language Class Initialized
INFO - 2023-01-13 11:15:59 --> Language Class Initialized
INFO - 2023-01-13 11:15:59 --> Config Class Initialized
INFO - 2023-01-13 11:15:59 --> Loader Class Initialized
INFO - 2023-01-13 11:15:59 --> Helper loaded: url_helper
INFO - 2023-01-13 11:15:59 --> Helper loaded: file_helper
INFO - 2023-01-13 11:15:59 --> Helper loaded: form_helper
INFO - 2023-01-13 11:15:59 --> Helper loaded: my_helper
INFO - 2023-01-13 11:15:59 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:15:59 --> Controller Class Initialized
DEBUG - 2023-01-13 11:15:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-13 11:15:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:15:59 --> Final output sent to browser
DEBUG - 2023-01-13 11:15:59 --> Total execution time: 0.0346
INFO - 2023-01-13 11:16:01 --> Config Class Initialized
INFO - 2023-01-13 11:16:01 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:16:01 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:16:01 --> Utf8 Class Initialized
INFO - 2023-01-13 11:16:01 --> URI Class Initialized
INFO - 2023-01-13 11:16:01 --> Router Class Initialized
INFO - 2023-01-13 11:16:01 --> Output Class Initialized
INFO - 2023-01-13 11:16:01 --> Security Class Initialized
DEBUG - 2023-01-13 11:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:16:01 --> Input Class Initialized
INFO - 2023-01-13 11:16:01 --> Language Class Initialized
INFO - 2023-01-13 11:16:01 --> Language Class Initialized
INFO - 2023-01-13 11:16:01 --> Config Class Initialized
INFO - 2023-01-13 11:16:01 --> Loader Class Initialized
INFO - 2023-01-13 11:16:01 --> Helper loaded: url_helper
INFO - 2023-01-13 11:16:01 --> Helper loaded: file_helper
INFO - 2023-01-13 11:16:01 --> Helper loaded: form_helper
INFO - 2023-01-13 11:16:01 --> Helper loaded: my_helper
INFO - 2023-01-13 11:16:01 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:16:01 --> Controller Class Initialized
DEBUG - 2023-01-13 11:16:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-13 11:16:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:16:01 --> Final output sent to browser
DEBUG - 2023-01-13 11:16:01 --> Total execution time: 0.0417
INFO - 2023-01-13 11:16:03 --> Config Class Initialized
INFO - 2023-01-13 11:16:03 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:16:03 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:16:03 --> Utf8 Class Initialized
INFO - 2023-01-13 11:16:03 --> URI Class Initialized
INFO - 2023-01-13 11:16:03 --> Router Class Initialized
INFO - 2023-01-13 11:16:03 --> Output Class Initialized
INFO - 2023-01-13 11:16:03 --> Security Class Initialized
DEBUG - 2023-01-13 11:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:16:03 --> Input Class Initialized
INFO - 2023-01-13 11:16:03 --> Language Class Initialized
INFO - 2023-01-13 11:16:03 --> Language Class Initialized
INFO - 2023-01-13 11:16:03 --> Config Class Initialized
INFO - 2023-01-13 11:16:03 --> Loader Class Initialized
INFO - 2023-01-13 11:16:03 --> Helper loaded: url_helper
INFO - 2023-01-13 11:16:03 --> Helper loaded: file_helper
INFO - 2023-01-13 11:16:03 --> Helper loaded: form_helper
INFO - 2023-01-13 11:16:03 --> Helper loaded: my_helper
INFO - 2023-01-13 11:16:03 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:16:03 --> Controller Class Initialized
DEBUG - 2023-01-13 11:16:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-13 11:16:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:16:03 --> Final output sent to browser
DEBUG - 2023-01-13 11:16:03 --> Total execution time: 0.0288
INFO - 2023-01-13 11:16:03 --> Config Class Initialized
INFO - 2023-01-13 11:16:03 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:16:03 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:16:03 --> Utf8 Class Initialized
INFO - 2023-01-13 11:16:03 --> URI Class Initialized
INFO - 2023-01-13 11:16:03 --> Router Class Initialized
INFO - 2023-01-13 11:16:03 --> Output Class Initialized
INFO - 2023-01-13 11:16:03 --> Security Class Initialized
DEBUG - 2023-01-13 11:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:16:03 --> Input Class Initialized
INFO - 2023-01-13 11:16:03 --> Language Class Initialized
INFO - 2023-01-13 11:16:03 --> Language Class Initialized
INFO - 2023-01-13 11:16:03 --> Config Class Initialized
INFO - 2023-01-13 11:16:03 --> Loader Class Initialized
INFO - 2023-01-13 11:16:03 --> Helper loaded: url_helper
INFO - 2023-01-13 11:16:03 --> Helper loaded: file_helper
INFO - 2023-01-13 11:16:03 --> Helper loaded: form_helper
INFO - 2023-01-13 11:16:03 --> Helper loaded: my_helper
INFO - 2023-01-13 11:16:03 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:16:03 --> Controller Class Initialized
INFO - 2023-01-13 11:16:06 --> Config Class Initialized
INFO - 2023-01-13 11:16:06 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:16:06 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:16:06 --> Utf8 Class Initialized
INFO - 2023-01-13 11:16:06 --> URI Class Initialized
INFO - 2023-01-13 11:16:06 --> Router Class Initialized
INFO - 2023-01-13 11:16:06 --> Output Class Initialized
INFO - 2023-01-13 11:16:06 --> Security Class Initialized
DEBUG - 2023-01-13 11:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:16:06 --> Input Class Initialized
INFO - 2023-01-13 11:16:06 --> Language Class Initialized
INFO - 2023-01-13 11:16:06 --> Language Class Initialized
INFO - 2023-01-13 11:16:06 --> Config Class Initialized
INFO - 2023-01-13 11:16:06 --> Loader Class Initialized
INFO - 2023-01-13 11:16:06 --> Helper loaded: url_helper
INFO - 2023-01-13 11:16:06 --> Helper loaded: file_helper
INFO - 2023-01-13 11:16:06 --> Helper loaded: form_helper
INFO - 2023-01-13 11:16:06 --> Helper loaded: my_helper
INFO - 2023-01-13 11:16:06 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:16:06 --> Controller Class Initialized
INFO - 2023-01-13 11:16:06 --> Final output sent to browser
DEBUG - 2023-01-13 11:16:06 --> Total execution time: 0.0343
INFO - 2023-01-13 11:16:07 --> Config Class Initialized
INFO - 2023-01-13 11:16:07 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:16:07 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:16:07 --> Utf8 Class Initialized
INFO - 2023-01-13 11:16:07 --> URI Class Initialized
INFO - 2023-01-13 11:16:07 --> Router Class Initialized
INFO - 2023-01-13 11:16:07 --> Output Class Initialized
INFO - 2023-01-13 11:16:07 --> Security Class Initialized
DEBUG - 2023-01-13 11:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:16:07 --> Input Class Initialized
INFO - 2023-01-13 11:16:07 --> Language Class Initialized
INFO - 2023-01-13 11:16:07 --> Language Class Initialized
INFO - 2023-01-13 11:16:07 --> Config Class Initialized
INFO - 2023-01-13 11:16:07 --> Loader Class Initialized
INFO - 2023-01-13 11:16:07 --> Helper loaded: url_helper
INFO - 2023-01-13 11:16:07 --> Helper loaded: file_helper
INFO - 2023-01-13 11:16:07 --> Helper loaded: form_helper
INFO - 2023-01-13 11:16:07 --> Helper loaded: my_helper
INFO - 2023-01-13 11:16:07 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:16:07 --> Controller Class Initialized
INFO - 2023-01-13 11:16:07 --> Final output sent to browser
DEBUG - 2023-01-13 11:16:07 --> Total execution time: 0.0347
INFO - 2023-01-13 11:16:08 --> Config Class Initialized
INFO - 2023-01-13 11:16:08 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:16:08 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:16:08 --> Utf8 Class Initialized
INFO - 2023-01-13 11:16:08 --> URI Class Initialized
INFO - 2023-01-13 11:16:08 --> Router Class Initialized
INFO - 2023-01-13 11:16:08 --> Output Class Initialized
INFO - 2023-01-13 11:16:08 --> Security Class Initialized
DEBUG - 2023-01-13 11:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:16:08 --> Input Class Initialized
INFO - 2023-01-13 11:16:08 --> Language Class Initialized
INFO - 2023-01-13 11:16:08 --> Language Class Initialized
INFO - 2023-01-13 11:16:08 --> Config Class Initialized
INFO - 2023-01-13 11:16:08 --> Loader Class Initialized
INFO - 2023-01-13 11:16:08 --> Helper loaded: url_helper
INFO - 2023-01-13 11:16:08 --> Helper loaded: file_helper
INFO - 2023-01-13 11:16:08 --> Helper loaded: form_helper
INFO - 2023-01-13 11:16:08 --> Helper loaded: my_helper
INFO - 2023-01-13 11:16:08 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:16:08 --> Controller Class Initialized
INFO - 2023-01-13 11:16:08 --> Final output sent to browser
DEBUG - 2023-01-13 11:16:08 --> Total execution time: 0.0230
INFO - 2023-01-13 11:20:56 --> Config Class Initialized
INFO - 2023-01-13 11:20:56 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:20:56 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:20:56 --> Utf8 Class Initialized
INFO - 2023-01-13 11:20:56 --> URI Class Initialized
INFO - 2023-01-13 11:20:56 --> Router Class Initialized
INFO - 2023-01-13 11:20:56 --> Output Class Initialized
INFO - 2023-01-13 11:20:56 --> Security Class Initialized
DEBUG - 2023-01-13 11:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:20:56 --> Input Class Initialized
INFO - 2023-01-13 11:20:56 --> Language Class Initialized
INFO - 2023-01-13 11:20:56 --> Language Class Initialized
INFO - 2023-01-13 11:20:56 --> Config Class Initialized
INFO - 2023-01-13 11:20:56 --> Loader Class Initialized
INFO - 2023-01-13 11:20:56 --> Helper loaded: url_helper
INFO - 2023-01-13 11:20:56 --> Helper loaded: file_helper
INFO - 2023-01-13 11:20:56 --> Helper loaded: form_helper
INFO - 2023-01-13 11:20:56 --> Helper loaded: my_helper
INFO - 2023-01-13 11:20:56 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:20:56 --> Controller Class Initialized
DEBUG - 2023-01-13 11:20:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-13 11:20:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:20:56 --> Final output sent to browser
DEBUG - 2023-01-13 11:20:56 --> Total execution time: 0.0368
INFO - 2023-01-13 11:20:58 --> Config Class Initialized
INFO - 2023-01-13 11:20:58 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:20:58 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:20:58 --> Utf8 Class Initialized
INFO - 2023-01-13 11:20:58 --> URI Class Initialized
INFO - 2023-01-13 11:20:58 --> Router Class Initialized
INFO - 2023-01-13 11:20:58 --> Output Class Initialized
INFO - 2023-01-13 11:20:58 --> Security Class Initialized
DEBUG - 2023-01-13 11:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:20:58 --> Input Class Initialized
INFO - 2023-01-13 11:20:58 --> Language Class Initialized
INFO - 2023-01-13 11:20:58 --> Language Class Initialized
INFO - 2023-01-13 11:20:58 --> Config Class Initialized
INFO - 2023-01-13 11:20:58 --> Loader Class Initialized
INFO - 2023-01-13 11:20:58 --> Helper loaded: url_helper
INFO - 2023-01-13 11:20:58 --> Helper loaded: file_helper
INFO - 2023-01-13 11:20:58 --> Helper loaded: form_helper
INFO - 2023-01-13 11:20:58 --> Helper loaded: my_helper
INFO - 2023-01-13 11:20:58 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:20:58 --> Controller Class Initialized
DEBUG - 2023-01-13 11:20:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-13 11:20:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:20:58 --> Final output sent to browser
DEBUG - 2023-01-13 11:20:58 --> Total execution time: 0.0252
INFO - 2023-01-13 11:20:59 --> Config Class Initialized
INFO - 2023-01-13 11:20:59 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:20:59 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:20:59 --> Utf8 Class Initialized
INFO - 2023-01-13 11:20:59 --> URI Class Initialized
INFO - 2023-01-13 11:20:59 --> Router Class Initialized
INFO - 2023-01-13 11:20:59 --> Output Class Initialized
INFO - 2023-01-13 11:20:59 --> Security Class Initialized
DEBUG - 2023-01-13 11:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:20:59 --> Input Class Initialized
INFO - 2023-01-13 11:20:59 --> Language Class Initialized
INFO - 2023-01-13 11:20:59 --> Language Class Initialized
INFO - 2023-01-13 11:20:59 --> Config Class Initialized
INFO - 2023-01-13 11:20:59 --> Loader Class Initialized
INFO - 2023-01-13 11:20:59 --> Helper loaded: url_helper
INFO - 2023-01-13 11:20:59 --> Helper loaded: file_helper
INFO - 2023-01-13 11:20:59 --> Helper loaded: form_helper
INFO - 2023-01-13 11:20:59 --> Helper loaded: my_helper
INFO - 2023-01-13 11:20:59 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:20:59 --> Controller Class Initialized
DEBUG - 2023-01-13 11:20:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-13 11:20:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:20:59 --> Final output sent to browser
DEBUG - 2023-01-13 11:20:59 --> Total execution time: 0.0653
INFO - 2023-01-13 11:23:10 --> Config Class Initialized
INFO - 2023-01-13 11:23:10 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:23:10 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:23:10 --> Utf8 Class Initialized
INFO - 2023-01-13 11:23:10 --> URI Class Initialized
INFO - 2023-01-13 11:23:10 --> Router Class Initialized
INFO - 2023-01-13 11:23:10 --> Output Class Initialized
INFO - 2023-01-13 11:23:10 --> Security Class Initialized
DEBUG - 2023-01-13 11:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:23:10 --> Input Class Initialized
INFO - 2023-01-13 11:23:10 --> Language Class Initialized
INFO - 2023-01-13 11:23:10 --> Language Class Initialized
INFO - 2023-01-13 11:23:10 --> Config Class Initialized
INFO - 2023-01-13 11:23:10 --> Loader Class Initialized
INFO - 2023-01-13 11:23:10 --> Helper loaded: url_helper
INFO - 2023-01-13 11:23:10 --> Helper loaded: file_helper
INFO - 2023-01-13 11:23:10 --> Helper loaded: form_helper
INFO - 2023-01-13 11:23:10 --> Helper loaded: my_helper
INFO - 2023-01-13 11:23:10 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:23:10 --> Controller Class Initialized
DEBUG - 2023-01-13 11:23:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-13 11:23:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:23:10 --> Final output sent to browser
DEBUG - 2023-01-13 11:23:10 --> Total execution time: 0.0291
INFO - 2023-01-13 11:23:11 --> Config Class Initialized
INFO - 2023-01-13 11:23:11 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:23:11 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:23:11 --> Utf8 Class Initialized
INFO - 2023-01-13 11:23:11 --> URI Class Initialized
INFO - 2023-01-13 11:23:11 --> Router Class Initialized
INFO - 2023-01-13 11:23:11 --> Output Class Initialized
INFO - 2023-01-13 11:23:11 --> Security Class Initialized
DEBUG - 2023-01-13 11:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:23:11 --> Input Class Initialized
INFO - 2023-01-13 11:23:11 --> Language Class Initialized
INFO - 2023-01-13 11:23:11 --> Language Class Initialized
INFO - 2023-01-13 11:23:11 --> Config Class Initialized
INFO - 2023-01-13 11:23:11 --> Loader Class Initialized
INFO - 2023-01-13 11:23:11 --> Helper loaded: url_helper
INFO - 2023-01-13 11:23:11 --> Helper loaded: file_helper
INFO - 2023-01-13 11:23:11 --> Helper loaded: form_helper
INFO - 2023-01-13 11:23:11 --> Helper loaded: my_helper
INFO - 2023-01-13 11:23:11 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:23:11 --> Controller Class Initialized
DEBUG - 2023-01-13 11:23:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-13 11:23:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:23:11 --> Final output sent to browser
DEBUG - 2023-01-13 11:23:11 --> Total execution time: 0.0268
INFO - 2023-01-13 11:23:11 --> Config Class Initialized
INFO - 2023-01-13 11:23:11 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:23:11 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:23:11 --> Utf8 Class Initialized
INFO - 2023-01-13 11:23:11 --> URI Class Initialized
INFO - 2023-01-13 11:23:11 --> Router Class Initialized
INFO - 2023-01-13 11:23:11 --> Output Class Initialized
INFO - 2023-01-13 11:23:11 --> Security Class Initialized
DEBUG - 2023-01-13 11:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:23:11 --> Input Class Initialized
INFO - 2023-01-13 11:23:11 --> Language Class Initialized
INFO - 2023-01-13 11:23:11 --> Language Class Initialized
INFO - 2023-01-13 11:23:11 --> Config Class Initialized
INFO - 2023-01-13 11:23:11 --> Loader Class Initialized
INFO - 2023-01-13 11:23:11 --> Helper loaded: url_helper
INFO - 2023-01-13 11:23:11 --> Helper loaded: file_helper
INFO - 2023-01-13 11:23:11 --> Helper loaded: form_helper
INFO - 2023-01-13 11:23:11 --> Helper loaded: my_helper
INFO - 2023-01-13 11:23:11 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:23:11 --> Controller Class Initialized
DEBUG - 2023-01-13 11:23:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-13 11:23:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:23:11 --> Final output sent to browser
DEBUG - 2023-01-13 11:23:11 --> Total execution time: 0.0388
INFO - 2023-01-13 11:23:11 --> Config Class Initialized
INFO - 2023-01-13 11:23:11 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:23:11 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:23:11 --> Utf8 Class Initialized
INFO - 2023-01-13 11:23:11 --> URI Class Initialized
INFO - 2023-01-13 11:23:11 --> Router Class Initialized
INFO - 2023-01-13 11:23:11 --> Output Class Initialized
INFO - 2023-01-13 11:23:11 --> Security Class Initialized
DEBUG - 2023-01-13 11:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:23:11 --> Input Class Initialized
INFO - 2023-01-13 11:23:11 --> Language Class Initialized
INFO - 2023-01-13 11:23:11 --> Language Class Initialized
INFO - 2023-01-13 11:23:11 --> Config Class Initialized
INFO - 2023-01-13 11:23:11 --> Loader Class Initialized
INFO - 2023-01-13 11:23:11 --> Helper loaded: url_helper
INFO - 2023-01-13 11:23:11 --> Helper loaded: file_helper
INFO - 2023-01-13 11:23:11 --> Helper loaded: form_helper
INFO - 2023-01-13 11:23:11 --> Helper loaded: my_helper
INFO - 2023-01-13 11:23:11 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:23:11 --> Controller Class Initialized
INFO - 2023-01-13 11:24:44 --> Config Class Initialized
INFO - 2023-01-13 11:24:44 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:24:44 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:24:44 --> Utf8 Class Initialized
INFO - 2023-01-13 11:24:44 --> URI Class Initialized
INFO - 2023-01-13 11:24:44 --> Router Class Initialized
INFO - 2023-01-13 11:24:44 --> Output Class Initialized
INFO - 2023-01-13 11:24:44 --> Security Class Initialized
DEBUG - 2023-01-13 11:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:24:44 --> Input Class Initialized
INFO - 2023-01-13 11:24:44 --> Language Class Initialized
INFO - 2023-01-13 11:24:44 --> Language Class Initialized
INFO - 2023-01-13 11:24:44 --> Config Class Initialized
INFO - 2023-01-13 11:24:44 --> Loader Class Initialized
INFO - 2023-01-13 11:24:44 --> Helper loaded: url_helper
INFO - 2023-01-13 11:24:44 --> Helper loaded: file_helper
INFO - 2023-01-13 11:24:44 --> Helper loaded: form_helper
INFO - 2023-01-13 11:24:44 --> Helper loaded: my_helper
INFO - 2023-01-13 11:24:44 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:24:44 --> Controller Class Initialized
DEBUG - 2023-01-13 11:24:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-13 11:24:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:24:44 --> Final output sent to browser
DEBUG - 2023-01-13 11:24:44 --> Total execution time: 0.0271
INFO - 2023-01-13 11:24:44 --> Config Class Initialized
INFO - 2023-01-13 11:24:44 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:24:44 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:24:44 --> Utf8 Class Initialized
INFO - 2023-01-13 11:24:44 --> URI Class Initialized
INFO - 2023-01-13 11:24:44 --> Router Class Initialized
INFO - 2023-01-13 11:24:44 --> Output Class Initialized
INFO - 2023-01-13 11:24:44 --> Security Class Initialized
DEBUG - 2023-01-13 11:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:24:44 --> Input Class Initialized
INFO - 2023-01-13 11:24:44 --> Language Class Initialized
INFO - 2023-01-13 11:24:44 --> Language Class Initialized
INFO - 2023-01-13 11:24:44 --> Config Class Initialized
INFO - 2023-01-13 11:24:44 --> Loader Class Initialized
INFO - 2023-01-13 11:24:44 --> Helper loaded: url_helper
INFO - 2023-01-13 11:24:44 --> Helper loaded: file_helper
INFO - 2023-01-13 11:24:44 --> Helper loaded: form_helper
INFO - 2023-01-13 11:24:44 --> Helper loaded: my_helper
INFO - 2023-01-13 11:24:44 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:24:44 --> Controller Class Initialized
INFO - 2023-01-13 11:24:55 --> Config Class Initialized
INFO - 2023-01-13 11:24:55 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:24:55 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:24:55 --> Utf8 Class Initialized
INFO - 2023-01-13 11:24:55 --> URI Class Initialized
INFO - 2023-01-13 11:24:55 --> Router Class Initialized
INFO - 2023-01-13 11:24:55 --> Output Class Initialized
INFO - 2023-01-13 11:24:55 --> Security Class Initialized
DEBUG - 2023-01-13 11:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:24:55 --> Input Class Initialized
INFO - 2023-01-13 11:24:55 --> Language Class Initialized
INFO - 2023-01-13 11:24:55 --> Language Class Initialized
INFO - 2023-01-13 11:24:55 --> Config Class Initialized
INFO - 2023-01-13 11:24:55 --> Loader Class Initialized
INFO - 2023-01-13 11:24:55 --> Helper loaded: url_helper
INFO - 2023-01-13 11:24:55 --> Helper loaded: file_helper
INFO - 2023-01-13 11:24:55 --> Helper loaded: form_helper
INFO - 2023-01-13 11:24:55 --> Helper loaded: my_helper
INFO - 2023-01-13 11:24:55 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:24:55 --> Controller Class Initialized
ERROR - 2023-01-13 11:24:55 --> Severity: Notice --> Undefined variable: q_siswa_kelas C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 115
ERROR - 2023-01-13 11:24:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 115
DEBUG - 2023-01-13 11:24:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-13 11:24:55 --> Final output sent to browser
DEBUG - 2023-01-13 11:24:55 --> Total execution time: 0.0428
INFO - 2023-01-13 11:25:15 --> Config Class Initialized
INFO - 2023-01-13 11:25:15 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:25:15 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:25:15 --> Utf8 Class Initialized
INFO - 2023-01-13 11:25:15 --> URI Class Initialized
INFO - 2023-01-13 11:25:15 --> Router Class Initialized
INFO - 2023-01-13 11:25:15 --> Output Class Initialized
INFO - 2023-01-13 11:25:15 --> Security Class Initialized
DEBUG - 2023-01-13 11:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:25:15 --> Input Class Initialized
INFO - 2023-01-13 11:25:15 --> Language Class Initialized
INFO - 2023-01-13 11:25:15 --> Language Class Initialized
INFO - 2023-01-13 11:25:15 --> Config Class Initialized
INFO - 2023-01-13 11:25:15 --> Loader Class Initialized
INFO - 2023-01-13 11:25:15 --> Helper loaded: url_helper
INFO - 2023-01-13 11:25:15 --> Helper loaded: file_helper
INFO - 2023-01-13 11:25:15 --> Helper loaded: form_helper
INFO - 2023-01-13 11:25:15 --> Helper loaded: my_helper
INFO - 2023-01-13 11:25:15 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:25:15 --> Controller Class Initialized
INFO - 2023-01-13 11:25:15 --> Final output sent to browser
DEBUG - 2023-01-13 11:25:15 --> Total execution time: 0.0397
INFO - 2023-01-13 11:25:15 --> Config Class Initialized
INFO - 2023-01-13 11:25:15 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:25:15 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:25:15 --> Utf8 Class Initialized
INFO - 2023-01-13 11:25:15 --> URI Class Initialized
INFO - 2023-01-13 11:25:15 --> Router Class Initialized
INFO - 2023-01-13 11:25:15 --> Output Class Initialized
INFO - 2023-01-13 11:25:15 --> Security Class Initialized
DEBUG - 2023-01-13 11:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:25:15 --> Input Class Initialized
INFO - 2023-01-13 11:25:15 --> Language Class Initialized
INFO - 2023-01-13 11:25:15 --> Language Class Initialized
INFO - 2023-01-13 11:25:15 --> Config Class Initialized
INFO - 2023-01-13 11:25:15 --> Loader Class Initialized
INFO - 2023-01-13 11:25:15 --> Helper loaded: url_helper
INFO - 2023-01-13 11:25:15 --> Helper loaded: file_helper
INFO - 2023-01-13 11:25:15 --> Helper loaded: form_helper
INFO - 2023-01-13 11:25:15 --> Helper loaded: my_helper
INFO - 2023-01-13 11:25:15 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:25:15 --> Controller Class Initialized
INFO - 2023-01-13 11:25:18 --> Config Class Initialized
INFO - 2023-01-13 11:25:18 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:25:18 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:25:18 --> Utf8 Class Initialized
INFO - 2023-01-13 11:25:18 --> URI Class Initialized
INFO - 2023-01-13 11:25:18 --> Router Class Initialized
INFO - 2023-01-13 11:25:18 --> Output Class Initialized
INFO - 2023-01-13 11:25:18 --> Security Class Initialized
DEBUG - 2023-01-13 11:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:25:18 --> Input Class Initialized
INFO - 2023-01-13 11:25:18 --> Language Class Initialized
INFO - 2023-01-13 11:25:18 --> Language Class Initialized
INFO - 2023-01-13 11:25:18 --> Config Class Initialized
INFO - 2023-01-13 11:25:18 --> Loader Class Initialized
INFO - 2023-01-13 11:25:18 --> Helper loaded: url_helper
INFO - 2023-01-13 11:25:18 --> Helper loaded: file_helper
INFO - 2023-01-13 11:25:18 --> Helper loaded: form_helper
INFO - 2023-01-13 11:25:18 --> Helper loaded: my_helper
INFO - 2023-01-13 11:25:18 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:25:18 --> Controller Class Initialized
INFO - 2023-01-13 11:25:18 --> Final output sent to browser
DEBUG - 2023-01-13 11:25:18 --> Total execution time: 0.0327
INFO - 2023-01-13 11:25:18 --> Config Class Initialized
INFO - 2023-01-13 11:25:18 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:25:18 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:25:18 --> Utf8 Class Initialized
INFO - 2023-01-13 11:25:18 --> URI Class Initialized
INFO - 2023-01-13 11:25:18 --> Router Class Initialized
INFO - 2023-01-13 11:25:18 --> Output Class Initialized
INFO - 2023-01-13 11:25:18 --> Security Class Initialized
DEBUG - 2023-01-13 11:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:25:18 --> Input Class Initialized
INFO - 2023-01-13 11:25:18 --> Language Class Initialized
INFO - 2023-01-13 11:25:18 --> Language Class Initialized
INFO - 2023-01-13 11:25:18 --> Config Class Initialized
INFO - 2023-01-13 11:25:18 --> Loader Class Initialized
INFO - 2023-01-13 11:25:18 --> Helper loaded: url_helper
INFO - 2023-01-13 11:25:18 --> Helper loaded: file_helper
INFO - 2023-01-13 11:25:18 --> Helper loaded: form_helper
INFO - 2023-01-13 11:25:18 --> Helper loaded: my_helper
INFO - 2023-01-13 11:25:18 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:25:18 --> Controller Class Initialized
INFO - 2023-01-13 11:25:19 --> Config Class Initialized
INFO - 2023-01-13 11:25:19 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:25:19 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:25:19 --> Utf8 Class Initialized
INFO - 2023-01-13 11:25:19 --> URI Class Initialized
INFO - 2023-01-13 11:25:19 --> Router Class Initialized
INFO - 2023-01-13 11:25:19 --> Output Class Initialized
INFO - 2023-01-13 11:25:19 --> Security Class Initialized
DEBUG - 2023-01-13 11:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:25:19 --> Input Class Initialized
INFO - 2023-01-13 11:25:19 --> Language Class Initialized
INFO - 2023-01-13 11:25:19 --> Language Class Initialized
INFO - 2023-01-13 11:25:19 --> Config Class Initialized
INFO - 2023-01-13 11:25:19 --> Loader Class Initialized
INFO - 2023-01-13 11:25:19 --> Helper loaded: url_helper
INFO - 2023-01-13 11:25:19 --> Helper loaded: file_helper
INFO - 2023-01-13 11:25:19 --> Helper loaded: form_helper
INFO - 2023-01-13 11:25:19 --> Helper loaded: my_helper
INFO - 2023-01-13 11:25:19 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:25:19 --> Controller Class Initialized
INFO - 2023-01-13 11:25:19 --> Final output sent to browser
DEBUG - 2023-01-13 11:25:19 --> Total execution time: 0.0549
INFO - 2023-01-13 11:25:19 --> Config Class Initialized
INFO - 2023-01-13 11:25:19 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:25:19 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:25:19 --> Utf8 Class Initialized
INFO - 2023-01-13 11:25:19 --> URI Class Initialized
INFO - 2023-01-13 11:25:19 --> Router Class Initialized
INFO - 2023-01-13 11:25:19 --> Output Class Initialized
INFO - 2023-01-13 11:25:19 --> Security Class Initialized
DEBUG - 2023-01-13 11:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:25:19 --> Input Class Initialized
INFO - 2023-01-13 11:25:19 --> Language Class Initialized
INFO - 2023-01-13 11:25:19 --> Language Class Initialized
INFO - 2023-01-13 11:25:19 --> Config Class Initialized
INFO - 2023-01-13 11:25:19 --> Loader Class Initialized
INFO - 2023-01-13 11:25:19 --> Helper loaded: url_helper
INFO - 2023-01-13 11:25:19 --> Helper loaded: file_helper
INFO - 2023-01-13 11:25:19 --> Helper loaded: form_helper
INFO - 2023-01-13 11:25:19 --> Helper loaded: my_helper
INFO - 2023-01-13 11:25:19 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:25:19 --> Controller Class Initialized
INFO - 2023-01-13 11:25:21 --> Config Class Initialized
INFO - 2023-01-13 11:25:21 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:25:21 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:25:21 --> Utf8 Class Initialized
INFO - 2023-01-13 11:25:21 --> URI Class Initialized
INFO - 2023-01-13 11:25:21 --> Router Class Initialized
INFO - 2023-01-13 11:25:21 --> Output Class Initialized
INFO - 2023-01-13 11:25:21 --> Security Class Initialized
DEBUG - 2023-01-13 11:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:25:21 --> Input Class Initialized
INFO - 2023-01-13 11:25:21 --> Language Class Initialized
INFO - 2023-01-13 11:25:21 --> Language Class Initialized
INFO - 2023-01-13 11:25:21 --> Config Class Initialized
INFO - 2023-01-13 11:25:21 --> Loader Class Initialized
INFO - 2023-01-13 11:25:21 --> Helper loaded: url_helper
INFO - 2023-01-13 11:25:21 --> Helper loaded: file_helper
INFO - 2023-01-13 11:25:21 --> Helper loaded: form_helper
INFO - 2023-01-13 11:25:21 --> Helper loaded: my_helper
INFO - 2023-01-13 11:25:21 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:25:21 --> Controller Class Initialized
INFO - 2023-01-13 11:25:21 --> Final output sent to browser
DEBUG - 2023-01-13 11:25:21 --> Total execution time: 0.0311
INFO - 2023-01-13 11:25:21 --> Config Class Initialized
INFO - 2023-01-13 11:25:21 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:25:21 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:25:21 --> Utf8 Class Initialized
INFO - 2023-01-13 11:25:21 --> URI Class Initialized
INFO - 2023-01-13 11:25:21 --> Router Class Initialized
INFO - 2023-01-13 11:25:21 --> Output Class Initialized
INFO - 2023-01-13 11:25:21 --> Security Class Initialized
DEBUG - 2023-01-13 11:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:25:21 --> Input Class Initialized
INFO - 2023-01-13 11:25:21 --> Language Class Initialized
INFO - 2023-01-13 11:25:21 --> Language Class Initialized
INFO - 2023-01-13 11:25:21 --> Config Class Initialized
INFO - 2023-01-13 11:25:21 --> Loader Class Initialized
INFO - 2023-01-13 11:25:21 --> Helper loaded: url_helper
INFO - 2023-01-13 11:25:21 --> Helper loaded: file_helper
INFO - 2023-01-13 11:25:21 --> Helper loaded: form_helper
INFO - 2023-01-13 11:25:21 --> Helper loaded: my_helper
INFO - 2023-01-13 11:25:21 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:25:21 --> Controller Class Initialized
INFO - 2023-01-13 11:25:23 --> Config Class Initialized
INFO - 2023-01-13 11:25:23 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:25:23 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:25:23 --> Utf8 Class Initialized
INFO - 2023-01-13 11:25:23 --> URI Class Initialized
INFO - 2023-01-13 11:25:23 --> Router Class Initialized
INFO - 2023-01-13 11:25:23 --> Output Class Initialized
INFO - 2023-01-13 11:25:23 --> Security Class Initialized
DEBUG - 2023-01-13 11:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:25:23 --> Input Class Initialized
INFO - 2023-01-13 11:25:23 --> Language Class Initialized
INFO - 2023-01-13 11:25:23 --> Language Class Initialized
INFO - 2023-01-13 11:25:23 --> Config Class Initialized
INFO - 2023-01-13 11:25:23 --> Loader Class Initialized
INFO - 2023-01-13 11:25:23 --> Helper loaded: url_helper
INFO - 2023-01-13 11:25:23 --> Helper loaded: file_helper
INFO - 2023-01-13 11:25:23 --> Helper loaded: form_helper
INFO - 2023-01-13 11:25:23 --> Helper loaded: my_helper
INFO - 2023-01-13 11:25:23 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:25:23 --> Controller Class Initialized
INFO - 2023-01-13 11:25:23 --> Final output sent to browser
DEBUG - 2023-01-13 11:25:23 --> Total execution time: 0.0462
INFO - 2023-01-13 11:25:23 --> Config Class Initialized
INFO - 2023-01-13 11:25:23 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:25:23 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:25:23 --> Utf8 Class Initialized
INFO - 2023-01-13 11:25:23 --> URI Class Initialized
INFO - 2023-01-13 11:25:23 --> Router Class Initialized
INFO - 2023-01-13 11:25:23 --> Output Class Initialized
INFO - 2023-01-13 11:25:23 --> Security Class Initialized
DEBUG - 2023-01-13 11:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:25:23 --> Input Class Initialized
INFO - 2023-01-13 11:25:23 --> Language Class Initialized
INFO - 2023-01-13 11:25:23 --> Language Class Initialized
INFO - 2023-01-13 11:25:23 --> Config Class Initialized
INFO - 2023-01-13 11:25:23 --> Loader Class Initialized
INFO - 2023-01-13 11:25:23 --> Helper loaded: url_helper
INFO - 2023-01-13 11:25:23 --> Helper loaded: file_helper
INFO - 2023-01-13 11:25:23 --> Helper loaded: form_helper
INFO - 2023-01-13 11:25:23 --> Helper loaded: my_helper
INFO - 2023-01-13 11:25:23 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:25:23 --> Controller Class Initialized
INFO - 2023-01-13 11:25:24 --> Config Class Initialized
INFO - 2023-01-13 11:25:24 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:25:24 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:25:24 --> Utf8 Class Initialized
INFO - 2023-01-13 11:25:24 --> URI Class Initialized
INFO - 2023-01-13 11:25:24 --> Router Class Initialized
INFO - 2023-01-13 11:25:24 --> Output Class Initialized
INFO - 2023-01-13 11:25:24 --> Security Class Initialized
DEBUG - 2023-01-13 11:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:25:24 --> Input Class Initialized
INFO - 2023-01-13 11:25:24 --> Language Class Initialized
INFO - 2023-01-13 11:25:24 --> Language Class Initialized
INFO - 2023-01-13 11:25:24 --> Config Class Initialized
INFO - 2023-01-13 11:25:24 --> Loader Class Initialized
INFO - 2023-01-13 11:25:24 --> Helper loaded: url_helper
INFO - 2023-01-13 11:25:24 --> Helper loaded: file_helper
INFO - 2023-01-13 11:25:24 --> Helper loaded: form_helper
INFO - 2023-01-13 11:25:24 --> Helper loaded: my_helper
INFO - 2023-01-13 11:25:24 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:25:25 --> Controller Class Initialized
INFO - 2023-01-13 11:25:25 --> Final output sent to browser
DEBUG - 2023-01-13 11:25:25 --> Total execution time: 0.0318
INFO - 2023-01-13 11:25:25 --> Config Class Initialized
INFO - 2023-01-13 11:25:25 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:25:25 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:25:25 --> Utf8 Class Initialized
INFO - 2023-01-13 11:25:25 --> URI Class Initialized
INFO - 2023-01-13 11:25:25 --> Router Class Initialized
INFO - 2023-01-13 11:25:25 --> Output Class Initialized
INFO - 2023-01-13 11:25:25 --> Security Class Initialized
DEBUG - 2023-01-13 11:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:25:25 --> Input Class Initialized
INFO - 2023-01-13 11:25:25 --> Language Class Initialized
INFO - 2023-01-13 11:25:25 --> Language Class Initialized
INFO - 2023-01-13 11:25:25 --> Config Class Initialized
INFO - 2023-01-13 11:25:25 --> Loader Class Initialized
INFO - 2023-01-13 11:25:25 --> Helper loaded: url_helper
INFO - 2023-01-13 11:25:25 --> Helper loaded: file_helper
INFO - 2023-01-13 11:25:25 --> Helper loaded: form_helper
INFO - 2023-01-13 11:25:25 --> Helper loaded: my_helper
INFO - 2023-01-13 11:25:25 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:25:25 --> Controller Class Initialized
INFO - 2023-01-13 11:25:49 --> Config Class Initialized
INFO - 2023-01-13 11:25:49 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:25:49 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:25:49 --> Utf8 Class Initialized
INFO - 2023-01-13 11:25:49 --> URI Class Initialized
INFO - 2023-01-13 11:25:49 --> Router Class Initialized
INFO - 2023-01-13 11:25:49 --> Output Class Initialized
INFO - 2023-01-13 11:25:49 --> Security Class Initialized
DEBUG - 2023-01-13 11:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:25:49 --> Input Class Initialized
INFO - 2023-01-13 11:25:49 --> Language Class Initialized
INFO - 2023-01-13 11:25:49 --> Language Class Initialized
INFO - 2023-01-13 11:25:49 --> Config Class Initialized
INFO - 2023-01-13 11:25:49 --> Loader Class Initialized
INFO - 2023-01-13 11:25:49 --> Helper loaded: url_helper
INFO - 2023-01-13 11:25:49 --> Helper loaded: file_helper
INFO - 2023-01-13 11:25:49 --> Helper loaded: form_helper
INFO - 2023-01-13 11:25:49 --> Helper loaded: my_helper
INFO - 2023-01-13 11:25:49 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:25:49 --> Controller Class Initialized
INFO - 2023-01-13 11:25:49 --> Final output sent to browser
DEBUG - 2023-01-13 11:25:49 --> Total execution time: 0.0420
INFO - 2023-01-13 11:25:49 --> Config Class Initialized
INFO - 2023-01-13 11:25:49 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:25:49 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:25:49 --> Utf8 Class Initialized
INFO - 2023-01-13 11:25:49 --> URI Class Initialized
INFO - 2023-01-13 11:25:49 --> Router Class Initialized
INFO - 2023-01-13 11:25:49 --> Output Class Initialized
INFO - 2023-01-13 11:25:49 --> Security Class Initialized
DEBUG - 2023-01-13 11:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:25:49 --> Input Class Initialized
INFO - 2023-01-13 11:25:49 --> Language Class Initialized
INFO - 2023-01-13 11:25:49 --> Language Class Initialized
INFO - 2023-01-13 11:25:49 --> Config Class Initialized
INFO - 2023-01-13 11:25:49 --> Loader Class Initialized
INFO - 2023-01-13 11:25:49 --> Helper loaded: url_helper
INFO - 2023-01-13 11:25:49 --> Helper loaded: file_helper
INFO - 2023-01-13 11:25:49 --> Helper loaded: form_helper
INFO - 2023-01-13 11:25:49 --> Helper loaded: my_helper
INFO - 2023-01-13 11:25:49 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:25:49 --> Controller Class Initialized
INFO - 2023-01-13 11:25:51 --> Config Class Initialized
INFO - 2023-01-13 11:25:51 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:25:51 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:25:51 --> Utf8 Class Initialized
INFO - 2023-01-13 11:25:51 --> URI Class Initialized
INFO - 2023-01-13 11:25:51 --> Router Class Initialized
INFO - 2023-01-13 11:25:51 --> Output Class Initialized
INFO - 2023-01-13 11:25:51 --> Security Class Initialized
DEBUG - 2023-01-13 11:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:25:51 --> Input Class Initialized
INFO - 2023-01-13 11:25:51 --> Language Class Initialized
INFO - 2023-01-13 11:25:51 --> Language Class Initialized
INFO - 2023-01-13 11:25:51 --> Config Class Initialized
INFO - 2023-01-13 11:25:51 --> Loader Class Initialized
INFO - 2023-01-13 11:25:51 --> Helper loaded: url_helper
INFO - 2023-01-13 11:25:51 --> Helper loaded: file_helper
INFO - 2023-01-13 11:25:51 --> Helper loaded: form_helper
INFO - 2023-01-13 11:25:51 --> Helper loaded: my_helper
INFO - 2023-01-13 11:25:51 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:25:51 --> Controller Class Initialized
INFO - 2023-01-13 11:25:51 --> Final output sent to browser
DEBUG - 2023-01-13 11:25:51 --> Total execution time: 0.0286
INFO - 2023-01-13 11:25:51 --> Config Class Initialized
INFO - 2023-01-13 11:25:51 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:25:51 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:25:51 --> Utf8 Class Initialized
INFO - 2023-01-13 11:25:51 --> URI Class Initialized
INFO - 2023-01-13 11:25:51 --> Router Class Initialized
INFO - 2023-01-13 11:25:51 --> Output Class Initialized
INFO - 2023-01-13 11:25:51 --> Security Class Initialized
DEBUG - 2023-01-13 11:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:25:51 --> Input Class Initialized
INFO - 2023-01-13 11:25:51 --> Language Class Initialized
INFO - 2023-01-13 11:25:51 --> Language Class Initialized
INFO - 2023-01-13 11:25:51 --> Config Class Initialized
INFO - 2023-01-13 11:25:51 --> Loader Class Initialized
INFO - 2023-01-13 11:25:51 --> Helper loaded: url_helper
INFO - 2023-01-13 11:25:51 --> Helper loaded: file_helper
INFO - 2023-01-13 11:25:51 --> Helper loaded: form_helper
INFO - 2023-01-13 11:25:51 --> Helper loaded: my_helper
INFO - 2023-01-13 11:25:51 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:25:51 --> Controller Class Initialized
INFO - 2023-01-13 11:26:08 --> Config Class Initialized
INFO - 2023-01-13 11:26:08 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:26:08 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:26:08 --> Utf8 Class Initialized
INFO - 2023-01-13 11:26:08 --> URI Class Initialized
INFO - 2023-01-13 11:26:08 --> Router Class Initialized
INFO - 2023-01-13 11:26:08 --> Output Class Initialized
INFO - 2023-01-13 11:26:08 --> Security Class Initialized
DEBUG - 2023-01-13 11:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:26:08 --> Input Class Initialized
INFO - 2023-01-13 11:26:08 --> Language Class Initialized
INFO - 2023-01-13 11:26:08 --> Language Class Initialized
INFO - 2023-01-13 11:26:08 --> Config Class Initialized
INFO - 2023-01-13 11:26:08 --> Loader Class Initialized
INFO - 2023-01-13 11:26:08 --> Helper loaded: url_helper
INFO - 2023-01-13 11:26:08 --> Helper loaded: file_helper
INFO - 2023-01-13 11:26:08 --> Helper loaded: form_helper
INFO - 2023-01-13 11:26:08 --> Helper loaded: my_helper
INFO - 2023-01-13 11:26:08 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:26:08 --> Controller Class Initialized
INFO - 2023-01-13 11:26:08 --> Final output sent to browser
DEBUG - 2023-01-13 11:26:08 --> Total execution time: 0.0281
INFO - 2023-01-13 11:26:43 --> Config Class Initialized
INFO - 2023-01-13 11:26:43 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:26:43 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:26:43 --> Utf8 Class Initialized
INFO - 2023-01-13 11:26:43 --> URI Class Initialized
INFO - 2023-01-13 11:26:43 --> Router Class Initialized
INFO - 2023-01-13 11:26:43 --> Output Class Initialized
INFO - 2023-01-13 11:26:43 --> Security Class Initialized
DEBUG - 2023-01-13 11:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:26:43 --> Input Class Initialized
INFO - 2023-01-13 11:26:43 --> Language Class Initialized
INFO - 2023-01-13 11:26:43 --> Language Class Initialized
INFO - 2023-01-13 11:26:43 --> Config Class Initialized
INFO - 2023-01-13 11:26:43 --> Loader Class Initialized
INFO - 2023-01-13 11:26:43 --> Helper loaded: url_helper
INFO - 2023-01-13 11:26:43 --> Helper loaded: file_helper
INFO - 2023-01-13 11:26:43 --> Helper loaded: form_helper
INFO - 2023-01-13 11:26:43 --> Helper loaded: my_helper
INFO - 2023-01-13 11:26:43 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:26:43 --> Controller Class Initialized
INFO - 2023-01-13 11:26:43 --> Final output sent to browser
DEBUG - 2023-01-13 11:26:43 --> Total execution time: 0.0503
INFO - 2023-01-13 11:26:46 --> Config Class Initialized
INFO - 2023-01-13 11:26:46 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:26:46 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:26:46 --> Utf8 Class Initialized
INFO - 2023-01-13 11:26:46 --> URI Class Initialized
INFO - 2023-01-13 11:26:46 --> Router Class Initialized
INFO - 2023-01-13 11:26:46 --> Output Class Initialized
INFO - 2023-01-13 11:26:46 --> Security Class Initialized
DEBUG - 2023-01-13 11:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:26:46 --> Input Class Initialized
INFO - 2023-01-13 11:26:46 --> Language Class Initialized
INFO - 2023-01-13 11:26:46 --> Language Class Initialized
INFO - 2023-01-13 11:26:46 --> Config Class Initialized
INFO - 2023-01-13 11:26:46 --> Loader Class Initialized
INFO - 2023-01-13 11:26:46 --> Helper loaded: url_helper
INFO - 2023-01-13 11:26:46 --> Helper loaded: file_helper
INFO - 2023-01-13 11:26:46 --> Helper loaded: form_helper
INFO - 2023-01-13 11:26:46 --> Helper loaded: my_helper
INFO - 2023-01-13 11:26:46 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:26:46 --> Controller Class Initialized
INFO - 2023-01-13 11:26:46 --> Final output sent to browser
DEBUG - 2023-01-13 11:26:46 --> Total execution time: 0.0264
INFO - 2023-01-13 11:26:46 --> Config Class Initialized
INFO - 2023-01-13 11:26:46 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:26:46 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:26:46 --> Utf8 Class Initialized
INFO - 2023-01-13 11:26:46 --> URI Class Initialized
INFO - 2023-01-13 11:26:46 --> Router Class Initialized
INFO - 2023-01-13 11:26:46 --> Output Class Initialized
INFO - 2023-01-13 11:26:46 --> Security Class Initialized
DEBUG - 2023-01-13 11:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:26:46 --> Input Class Initialized
INFO - 2023-01-13 11:26:46 --> Language Class Initialized
INFO - 2023-01-13 11:26:46 --> Language Class Initialized
INFO - 2023-01-13 11:26:46 --> Config Class Initialized
INFO - 2023-01-13 11:26:46 --> Loader Class Initialized
INFO - 2023-01-13 11:26:46 --> Helper loaded: url_helper
INFO - 2023-01-13 11:26:46 --> Helper loaded: file_helper
INFO - 2023-01-13 11:26:46 --> Helper loaded: form_helper
INFO - 2023-01-13 11:26:46 --> Helper loaded: my_helper
INFO - 2023-01-13 11:26:46 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:26:46 --> Controller Class Initialized
INFO - 2023-01-13 11:26:47 --> Config Class Initialized
INFO - 2023-01-13 11:26:47 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:26:47 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:26:47 --> Utf8 Class Initialized
INFO - 2023-01-13 11:26:47 --> URI Class Initialized
INFO - 2023-01-13 11:26:47 --> Router Class Initialized
INFO - 2023-01-13 11:26:47 --> Output Class Initialized
INFO - 2023-01-13 11:26:47 --> Security Class Initialized
DEBUG - 2023-01-13 11:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:26:47 --> Input Class Initialized
INFO - 2023-01-13 11:26:47 --> Language Class Initialized
INFO - 2023-01-13 11:26:47 --> Language Class Initialized
INFO - 2023-01-13 11:26:47 --> Config Class Initialized
INFO - 2023-01-13 11:26:47 --> Loader Class Initialized
INFO - 2023-01-13 11:26:47 --> Helper loaded: url_helper
INFO - 2023-01-13 11:26:47 --> Helper loaded: file_helper
INFO - 2023-01-13 11:26:47 --> Helper loaded: form_helper
INFO - 2023-01-13 11:26:47 --> Helper loaded: my_helper
INFO - 2023-01-13 11:26:47 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:26:47 --> Controller Class Initialized
INFO - 2023-01-13 11:26:47 --> Final output sent to browser
DEBUG - 2023-01-13 11:26:47 --> Total execution time: 0.0485
INFO - 2023-01-13 11:31:30 --> Config Class Initialized
INFO - 2023-01-13 11:31:30 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:31:30 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:31:30 --> Utf8 Class Initialized
INFO - 2023-01-13 11:31:30 --> URI Class Initialized
INFO - 2023-01-13 11:31:30 --> Router Class Initialized
INFO - 2023-01-13 11:31:30 --> Output Class Initialized
INFO - 2023-01-13 11:31:30 --> Security Class Initialized
DEBUG - 2023-01-13 11:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:31:30 --> Input Class Initialized
INFO - 2023-01-13 11:31:30 --> Language Class Initialized
INFO - 2023-01-13 11:31:30 --> Language Class Initialized
INFO - 2023-01-13 11:31:30 --> Config Class Initialized
INFO - 2023-01-13 11:31:30 --> Loader Class Initialized
INFO - 2023-01-13 11:31:30 --> Helper loaded: url_helper
INFO - 2023-01-13 11:31:30 --> Helper loaded: file_helper
INFO - 2023-01-13 11:31:30 --> Helper loaded: form_helper
INFO - 2023-01-13 11:31:30 --> Helper loaded: my_helper
INFO - 2023-01-13 11:31:30 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:31:31 --> Controller Class Initialized
DEBUG - 2023-01-13 11:31:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-13 11:31:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:31:31 --> Final output sent to browser
DEBUG - 2023-01-13 11:31:31 --> Total execution time: 0.0425
INFO - 2023-01-13 11:31:31 --> Config Class Initialized
INFO - 2023-01-13 11:31:31 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:31:31 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:31:31 --> Utf8 Class Initialized
INFO - 2023-01-13 11:31:31 --> URI Class Initialized
INFO - 2023-01-13 11:31:31 --> Router Class Initialized
INFO - 2023-01-13 11:31:31 --> Output Class Initialized
INFO - 2023-01-13 11:31:31 --> Security Class Initialized
DEBUG - 2023-01-13 11:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:31:31 --> Input Class Initialized
INFO - 2023-01-13 11:31:31 --> Language Class Initialized
INFO - 2023-01-13 11:31:31 --> Language Class Initialized
INFO - 2023-01-13 11:31:31 --> Config Class Initialized
INFO - 2023-01-13 11:31:31 --> Loader Class Initialized
INFO - 2023-01-13 11:31:31 --> Helper loaded: url_helper
INFO - 2023-01-13 11:31:31 --> Helper loaded: file_helper
INFO - 2023-01-13 11:31:31 --> Helper loaded: form_helper
INFO - 2023-01-13 11:31:31 --> Helper loaded: my_helper
INFO - 2023-01-13 11:31:31 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:31:31 --> Controller Class Initialized
INFO - 2023-01-13 11:31:32 --> Config Class Initialized
INFO - 2023-01-13 11:31:32 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:31:32 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:31:32 --> Utf8 Class Initialized
INFO - 2023-01-13 11:31:32 --> URI Class Initialized
INFO - 2023-01-13 11:31:32 --> Router Class Initialized
INFO - 2023-01-13 11:31:32 --> Output Class Initialized
INFO - 2023-01-13 11:31:32 --> Security Class Initialized
DEBUG - 2023-01-13 11:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:31:32 --> Input Class Initialized
INFO - 2023-01-13 11:31:32 --> Language Class Initialized
INFO - 2023-01-13 11:31:32 --> Language Class Initialized
INFO - 2023-01-13 11:31:32 --> Config Class Initialized
INFO - 2023-01-13 11:31:32 --> Loader Class Initialized
INFO - 2023-01-13 11:31:32 --> Helper loaded: url_helper
INFO - 2023-01-13 11:31:32 --> Helper loaded: file_helper
INFO - 2023-01-13 11:31:32 --> Helper loaded: form_helper
INFO - 2023-01-13 11:31:32 --> Helper loaded: my_helper
INFO - 2023-01-13 11:31:32 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:31:32 --> Controller Class Initialized
ERROR - 2023-01-13 11:31:32 --> Severity: Notice --> Undefined variable: arrayhmin C:\xampp\htdocs\myraportk13\application\modules\n_icb\controllers\N_icb.php 412
ERROR - 2023-01-13 11:31:32 --> Severity: Notice --> Undefined variable: arrayh C:\xampp\htdocs\myraportk13\application\modules\n_icb\controllers\N_icb.php 413
ERROR - 2023-01-13 11:31:32 --> Severity: Notice --> Undefined variable: arrayhmin C:\xampp\htdocs\myraportk13\application\modules\n_icb\controllers\N_icb.php 412
ERROR - 2023-01-13 11:31:32 --> Severity: Notice --> Undefined variable: arrayh C:\xampp\htdocs\myraportk13\application\modules\n_icb\controllers\N_icb.php 413
INFO - 2023-01-13 11:33:11 --> Config Class Initialized
INFO - 2023-01-13 11:33:11 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:33:11 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:33:11 --> Utf8 Class Initialized
INFO - 2023-01-13 11:33:11 --> URI Class Initialized
INFO - 2023-01-13 11:33:11 --> Router Class Initialized
INFO - 2023-01-13 11:33:11 --> Output Class Initialized
INFO - 2023-01-13 11:33:11 --> Security Class Initialized
DEBUG - 2023-01-13 11:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:33:11 --> Input Class Initialized
INFO - 2023-01-13 11:33:11 --> Language Class Initialized
INFO - 2023-01-13 11:33:11 --> Language Class Initialized
INFO - 2023-01-13 11:33:11 --> Config Class Initialized
INFO - 2023-01-13 11:33:11 --> Loader Class Initialized
INFO - 2023-01-13 11:33:11 --> Helper loaded: url_helper
INFO - 2023-01-13 11:33:11 --> Helper loaded: file_helper
INFO - 2023-01-13 11:33:11 --> Helper loaded: form_helper
INFO - 2023-01-13 11:33:11 --> Helper loaded: my_helper
INFO - 2023-01-13 11:33:11 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:33:11 --> Controller Class Initialized
ERROR - 2023-01-13 11:33:11 --> Severity: Warning --> explode() expects parameter 2 to be string, array given C:\xampp\htdocs\myraportk13\application\modules\n_icb\controllers\N_icb.php 412
ERROR - 2023-01-13 11:33:11 --> Severity: Warning --> explode() expects parameter 2 to be string, array given C:\xampp\htdocs\myraportk13\application\modules\n_icb\controllers\N_icb.php 412
INFO - 2023-01-13 11:34:12 --> Config Class Initialized
INFO - 2023-01-13 11:34:12 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:34:12 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:34:12 --> Utf8 Class Initialized
INFO - 2023-01-13 11:34:12 --> URI Class Initialized
INFO - 2023-01-13 11:34:12 --> Router Class Initialized
INFO - 2023-01-13 11:34:12 --> Output Class Initialized
INFO - 2023-01-13 11:34:12 --> Security Class Initialized
DEBUG - 2023-01-13 11:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:34:12 --> Input Class Initialized
INFO - 2023-01-13 11:34:12 --> Language Class Initialized
INFO - 2023-01-13 11:34:12 --> Language Class Initialized
INFO - 2023-01-13 11:34:12 --> Config Class Initialized
INFO - 2023-01-13 11:34:12 --> Loader Class Initialized
INFO - 2023-01-13 11:34:12 --> Helper loaded: url_helper
INFO - 2023-01-13 11:34:12 --> Helper loaded: file_helper
INFO - 2023-01-13 11:34:12 --> Helper loaded: form_helper
INFO - 2023-01-13 11:34:12 --> Helper loaded: my_helper
INFO - 2023-01-13 11:34:12 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:34:12 --> Controller Class Initialized
INFO - 2023-01-13 11:34:47 --> Config Class Initialized
INFO - 2023-01-13 11:34:47 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:34:47 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:34:47 --> Utf8 Class Initialized
INFO - 2023-01-13 11:34:47 --> URI Class Initialized
INFO - 2023-01-13 11:34:47 --> Router Class Initialized
INFO - 2023-01-13 11:34:47 --> Output Class Initialized
INFO - 2023-01-13 11:34:47 --> Security Class Initialized
DEBUG - 2023-01-13 11:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:34:47 --> Input Class Initialized
INFO - 2023-01-13 11:34:47 --> Language Class Initialized
INFO - 2023-01-13 11:34:47 --> Language Class Initialized
INFO - 2023-01-13 11:34:47 --> Config Class Initialized
INFO - 2023-01-13 11:34:47 --> Loader Class Initialized
INFO - 2023-01-13 11:34:47 --> Helper loaded: url_helper
INFO - 2023-01-13 11:34:47 --> Helper loaded: file_helper
INFO - 2023-01-13 11:34:47 --> Helper loaded: form_helper
INFO - 2023-01-13 11:34:47 --> Helper loaded: my_helper
INFO - 2023-01-13 11:34:47 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:34:47 --> Controller Class Initialized
ERROR - 2023-01-13 11:34:48 --> Severity: Notice --> Undefined variable: q_siswa_kelas C:\xampp\htdocs\myraportk13\application\modules\n_icb\controllers\N_icb.php 115
ERROR - 2023-01-13 11:34:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\myraportk13\application\modules\n_icb\controllers\N_icb.php 115
DEBUG - 2023-01-13 11:34:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/cetak.php
INFO - 2023-01-13 11:34:48 --> Final output sent to browser
DEBUG - 2023-01-13 11:34:48 --> Total execution time: 0.1040
INFO - 2023-01-13 11:34:52 --> Config Class Initialized
INFO - 2023-01-13 11:34:52 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:34:52 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:34:52 --> Utf8 Class Initialized
INFO - 2023-01-13 11:34:52 --> URI Class Initialized
INFO - 2023-01-13 11:34:52 --> Router Class Initialized
INFO - 2023-01-13 11:34:52 --> Output Class Initialized
INFO - 2023-01-13 11:34:52 --> Security Class Initialized
DEBUG - 2023-01-13 11:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:34:52 --> Input Class Initialized
INFO - 2023-01-13 11:34:52 --> Language Class Initialized
INFO - 2023-01-13 11:34:52 --> Language Class Initialized
INFO - 2023-01-13 11:34:52 --> Config Class Initialized
INFO - 2023-01-13 11:34:52 --> Loader Class Initialized
INFO - 2023-01-13 11:34:52 --> Helper loaded: url_helper
INFO - 2023-01-13 11:34:52 --> Helper loaded: file_helper
INFO - 2023-01-13 11:34:52 --> Helper loaded: form_helper
INFO - 2023-01-13 11:34:52 --> Helper loaded: my_helper
INFO - 2023-01-13 11:34:52 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:34:52 --> Controller Class Initialized
INFO - 2023-01-13 11:34:52 --> Final output sent to browser
DEBUG - 2023-01-13 11:34:52 --> Total execution time: 0.0405
INFO - 2023-01-13 11:34:54 --> Config Class Initialized
INFO - 2023-01-13 11:34:54 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:34:54 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:34:54 --> Utf8 Class Initialized
INFO - 2023-01-13 11:34:54 --> URI Class Initialized
INFO - 2023-01-13 11:34:54 --> Router Class Initialized
INFO - 2023-01-13 11:34:54 --> Output Class Initialized
INFO - 2023-01-13 11:34:54 --> Security Class Initialized
DEBUG - 2023-01-13 11:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:34:54 --> Input Class Initialized
INFO - 2023-01-13 11:34:54 --> Language Class Initialized
INFO - 2023-01-13 11:34:54 --> Language Class Initialized
INFO - 2023-01-13 11:34:54 --> Config Class Initialized
INFO - 2023-01-13 11:34:54 --> Loader Class Initialized
INFO - 2023-01-13 11:34:54 --> Helper loaded: url_helper
INFO - 2023-01-13 11:34:54 --> Helper loaded: file_helper
INFO - 2023-01-13 11:34:54 --> Helper loaded: form_helper
INFO - 2023-01-13 11:34:54 --> Helper loaded: my_helper
INFO - 2023-01-13 11:34:54 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:34:54 --> Controller Class Initialized
INFO - 2023-01-13 11:34:54 --> Final output sent to browser
DEBUG - 2023-01-13 11:34:54 --> Total execution time: 0.0248
INFO - 2023-01-13 11:34:55 --> Config Class Initialized
INFO - 2023-01-13 11:34:55 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:34:55 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:34:55 --> Utf8 Class Initialized
INFO - 2023-01-13 11:34:55 --> URI Class Initialized
INFO - 2023-01-13 11:34:55 --> Router Class Initialized
INFO - 2023-01-13 11:34:55 --> Output Class Initialized
INFO - 2023-01-13 11:34:55 --> Security Class Initialized
DEBUG - 2023-01-13 11:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:34:55 --> Input Class Initialized
INFO - 2023-01-13 11:34:55 --> Language Class Initialized
INFO - 2023-01-13 11:34:55 --> Language Class Initialized
INFO - 2023-01-13 11:34:55 --> Config Class Initialized
INFO - 2023-01-13 11:34:55 --> Loader Class Initialized
INFO - 2023-01-13 11:34:55 --> Helper loaded: url_helper
INFO - 2023-01-13 11:34:55 --> Helper loaded: file_helper
INFO - 2023-01-13 11:34:55 --> Helper loaded: form_helper
INFO - 2023-01-13 11:34:55 --> Helper loaded: my_helper
INFO - 2023-01-13 11:34:55 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:34:55 --> Controller Class Initialized
ERROR - 2023-01-13 11:34:55 --> Severity: Notice --> Undefined variable: q_siswa_kelas C:\xampp\htdocs\myraportk13\application\modules\n_icb\controllers\N_icb.php 115
ERROR - 2023-01-13 11:34:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\myraportk13\application\modules\n_icb\controllers\N_icb.php 115
DEBUG - 2023-01-13 11:34:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/cetak.php
INFO - 2023-01-13 11:34:55 --> Final output sent to browser
DEBUG - 2023-01-13 11:34:55 --> Total execution time: 0.0426
INFO - 2023-01-13 11:36:34 --> Config Class Initialized
INFO - 2023-01-13 11:36:34 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:36:34 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:36:34 --> Utf8 Class Initialized
INFO - 2023-01-13 11:36:34 --> URI Class Initialized
INFO - 2023-01-13 11:36:34 --> Router Class Initialized
INFO - 2023-01-13 11:36:34 --> Output Class Initialized
INFO - 2023-01-13 11:36:34 --> Security Class Initialized
DEBUG - 2023-01-13 11:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:36:34 --> Input Class Initialized
INFO - 2023-01-13 11:36:34 --> Language Class Initialized
INFO - 2023-01-13 11:36:34 --> Language Class Initialized
INFO - 2023-01-13 11:36:34 --> Config Class Initialized
INFO - 2023-01-13 11:36:34 --> Loader Class Initialized
INFO - 2023-01-13 11:36:34 --> Helper loaded: url_helper
INFO - 2023-01-13 11:36:34 --> Helper loaded: file_helper
INFO - 2023-01-13 11:36:34 --> Helper loaded: form_helper
INFO - 2023-01-13 11:36:34 --> Helper loaded: my_helper
INFO - 2023-01-13 11:36:34 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:36:34 --> Controller Class Initialized
DEBUG - 2023-01-13 11:36:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-13 11:36:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:36:34 --> Final output sent to browser
DEBUG - 2023-01-13 11:36:34 --> Total execution time: 0.0282
INFO - 2023-01-13 11:36:34 --> Config Class Initialized
INFO - 2023-01-13 11:36:34 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:36:34 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:36:34 --> Utf8 Class Initialized
INFO - 2023-01-13 11:36:34 --> URI Class Initialized
INFO - 2023-01-13 11:36:34 --> Router Class Initialized
INFO - 2023-01-13 11:36:34 --> Output Class Initialized
INFO - 2023-01-13 11:36:34 --> Security Class Initialized
DEBUG - 2023-01-13 11:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:36:34 --> Input Class Initialized
INFO - 2023-01-13 11:36:34 --> Language Class Initialized
INFO - 2023-01-13 11:36:34 --> Language Class Initialized
INFO - 2023-01-13 11:36:34 --> Config Class Initialized
INFO - 2023-01-13 11:36:34 --> Loader Class Initialized
INFO - 2023-01-13 11:36:34 --> Helper loaded: url_helper
INFO - 2023-01-13 11:36:34 --> Helper loaded: file_helper
INFO - 2023-01-13 11:36:34 --> Helper loaded: form_helper
INFO - 2023-01-13 11:36:34 --> Helper loaded: my_helper
INFO - 2023-01-13 11:36:34 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:36:34 --> Controller Class Initialized
INFO - 2023-01-13 11:36:37 --> Config Class Initialized
INFO - 2023-01-13 11:36:37 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:36:37 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:36:37 --> Utf8 Class Initialized
INFO - 2023-01-13 11:36:37 --> URI Class Initialized
INFO - 2023-01-13 11:36:37 --> Router Class Initialized
INFO - 2023-01-13 11:36:37 --> Output Class Initialized
INFO - 2023-01-13 11:36:37 --> Security Class Initialized
DEBUG - 2023-01-13 11:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:36:37 --> Input Class Initialized
INFO - 2023-01-13 11:36:37 --> Language Class Initialized
ERROR - 2023-01-13 11:36:37 --> 404 Page Not Found: /index
INFO - 2023-01-13 11:36:43 --> Config Class Initialized
INFO - 2023-01-13 11:36:43 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:36:43 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:36:43 --> Utf8 Class Initialized
INFO - 2023-01-13 11:36:43 --> URI Class Initialized
INFO - 2023-01-13 11:36:43 --> Router Class Initialized
INFO - 2023-01-13 11:36:43 --> Output Class Initialized
INFO - 2023-01-13 11:36:43 --> Security Class Initialized
DEBUG - 2023-01-13 11:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:36:43 --> Input Class Initialized
INFO - 2023-01-13 11:36:43 --> Language Class Initialized
INFO - 2023-01-13 11:36:43 --> Language Class Initialized
INFO - 2023-01-13 11:36:43 --> Config Class Initialized
INFO - 2023-01-13 11:36:43 --> Loader Class Initialized
INFO - 2023-01-13 11:36:43 --> Helper loaded: url_helper
INFO - 2023-01-13 11:36:43 --> Helper loaded: file_helper
INFO - 2023-01-13 11:36:43 --> Helper loaded: form_helper
INFO - 2023-01-13 11:36:43 --> Helper loaded: my_helper
INFO - 2023-01-13 11:36:43 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:36:43 --> Controller Class Initialized
INFO - 2023-01-13 11:36:43 --> Final output sent to browser
DEBUG - 2023-01-13 11:36:43 --> Total execution time: 0.0409
INFO - 2023-01-13 11:36:51 --> Config Class Initialized
INFO - 2023-01-13 11:36:51 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:36:51 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:36:51 --> Utf8 Class Initialized
INFO - 2023-01-13 11:36:51 --> URI Class Initialized
INFO - 2023-01-13 11:36:51 --> Router Class Initialized
INFO - 2023-01-13 11:36:51 --> Output Class Initialized
INFO - 2023-01-13 11:36:51 --> Security Class Initialized
DEBUG - 2023-01-13 11:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:36:51 --> Input Class Initialized
INFO - 2023-01-13 11:36:51 --> Language Class Initialized
INFO - 2023-01-13 11:36:51 --> Language Class Initialized
INFO - 2023-01-13 11:36:51 --> Config Class Initialized
INFO - 2023-01-13 11:36:51 --> Loader Class Initialized
INFO - 2023-01-13 11:36:51 --> Helper loaded: url_helper
INFO - 2023-01-13 11:36:51 --> Helper loaded: file_helper
INFO - 2023-01-13 11:36:51 --> Helper loaded: form_helper
INFO - 2023-01-13 11:36:51 --> Helper loaded: my_helper
INFO - 2023-01-13 11:36:51 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:36:51 --> Controller Class Initialized
INFO - 2023-01-13 11:36:51 --> Final output sent to browser
DEBUG - 2023-01-13 11:36:51 --> Total execution time: 0.0312
INFO - 2023-01-13 11:37:47 --> Config Class Initialized
INFO - 2023-01-13 11:37:47 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:37:47 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:37:47 --> Utf8 Class Initialized
INFO - 2023-01-13 11:37:47 --> URI Class Initialized
INFO - 2023-01-13 11:37:47 --> Router Class Initialized
INFO - 2023-01-13 11:37:47 --> Output Class Initialized
INFO - 2023-01-13 11:37:47 --> Security Class Initialized
DEBUG - 2023-01-13 11:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:37:47 --> Input Class Initialized
INFO - 2023-01-13 11:37:47 --> Language Class Initialized
INFO - 2023-01-13 11:37:47 --> Language Class Initialized
INFO - 2023-01-13 11:37:47 --> Config Class Initialized
INFO - 2023-01-13 11:37:47 --> Loader Class Initialized
INFO - 2023-01-13 11:37:47 --> Helper loaded: url_helper
INFO - 2023-01-13 11:37:47 --> Helper loaded: file_helper
INFO - 2023-01-13 11:37:47 --> Helper loaded: form_helper
INFO - 2023-01-13 11:37:47 --> Helper loaded: my_helper
INFO - 2023-01-13 11:37:47 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:37:47 --> Controller Class Initialized
DEBUG - 2023-01-13 11:37:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-13 11:37:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:37:47 --> Final output sent to browser
DEBUG - 2023-01-13 11:37:47 --> Total execution time: 0.0301
INFO - 2023-01-13 11:37:47 --> Config Class Initialized
INFO - 2023-01-13 11:37:47 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:37:47 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:37:47 --> Utf8 Class Initialized
INFO - 2023-01-13 11:37:47 --> URI Class Initialized
INFO - 2023-01-13 11:37:47 --> Router Class Initialized
INFO - 2023-01-13 11:37:47 --> Output Class Initialized
INFO - 2023-01-13 11:37:47 --> Security Class Initialized
DEBUG - 2023-01-13 11:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:37:47 --> Input Class Initialized
INFO - 2023-01-13 11:37:47 --> Language Class Initialized
ERROR - 2023-01-13 11:37:47 --> 404 Page Not Found: /index
INFO - 2023-01-13 11:37:47 --> Config Class Initialized
INFO - 2023-01-13 11:37:47 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:37:47 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:37:47 --> Utf8 Class Initialized
INFO - 2023-01-13 11:37:47 --> URI Class Initialized
INFO - 2023-01-13 11:37:47 --> Router Class Initialized
INFO - 2023-01-13 11:37:47 --> Output Class Initialized
INFO - 2023-01-13 11:37:47 --> Security Class Initialized
DEBUG - 2023-01-13 11:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:37:47 --> Input Class Initialized
INFO - 2023-01-13 11:37:47 --> Language Class Initialized
INFO - 2023-01-13 11:37:47 --> Language Class Initialized
INFO - 2023-01-13 11:37:47 --> Config Class Initialized
INFO - 2023-01-13 11:37:47 --> Loader Class Initialized
INFO - 2023-01-13 11:37:47 --> Helper loaded: url_helper
INFO - 2023-01-13 11:37:47 --> Helper loaded: file_helper
INFO - 2023-01-13 11:37:47 --> Helper loaded: form_helper
INFO - 2023-01-13 11:37:47 --> Helper loaded: my_helper
INFO - 2023-01-13 11:37:47 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:37:47 --> Controller Class Initialized
INFO - 2023-01-13 11:37:49 --> Config Class Initialized
INFO - 2023-01-13 11:37:49 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:37:49 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:37:49 --> Utf8 Class Initialized
INFO - 2023-01-13 11:37:49 --> URI Class Initialized
INFO - 2023-01-13 11:37:49 --> Router Class Initialized
INFO - 2023-01-13 11:37:49 --> Output Class Initialized
INFO - 2023-01-13 11:37:49 --> Security Class Initialized
DEBUG - 2023-01-13 11:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:37:49 --> Input Class Initialized
INFO - 2023-01-13 11:37:49 --> Language Class Initialized
INFO - 2023-01-13 11:37:49 --> Language Class Initialized
INFO - 2023-01-13 11:37:49 --> Config Class Initialized
INFO - 2023-01-13 11:37:49 --> Loader Class Initialized
INFO - 2023-01-13 11:37:49 --> Helper loaded: url_helper
INFO - 2023-01-13 11:37:49 --> Helper loaded: file_helper
INFO - 2023-01-13 11:37:49 --> Helper loaded: form_helper
INFO - 2023-01-13 11:37:49 --> Helper loaded: my_helper
INFO - 2023-01-13 11:37:49 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:37:49 --> Controller Class Initialized
INFO - 2023-01-13 11:37:49 --> Final output sent to browser
DEBUG - 2023-01-13 11:37:49 --> Total execution time: 0.0301
INFO - 2023-01-13 11:37:52 --> Config Class Initialized
INFO - 2023-01-13 11:37:52 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:37:52 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:37:52 --> Utf8 Class Initialized
INFO - 2023-01-13 11:37:52 --> URI Class Initialized
INFO - 2023-01-13 11:37:52 --> Router Class Initialized
INFO - 2023-01-13 11:37:52 --> Output Class Initialized
INFO - 2023-01-13 11:37:52 --> Security Class Initialized
DEBUG - 2023-01-13 11:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:37:52 --> Input Class Initialized
INFO - 2023-01-13 11:37:52 --> Language Class Initialized
INFO - 2023-01-13 11:37:52 --> Language Class Initialized
INFO - 2023-01-13 11:37:52 --> Config Class Initialized
INFO - 2023-01-13 11:37:52 --> Loader Class Initialized
INFO - 2023-01-13 11:37:52 --> Helper loaded: url_helper
INFO - 2023-01-13 11:37:52 --> Helper loaded: file_helper
INFO - 2023-01-13 11:37:52 --> Helper loaded: form_helper
INFO - 2023-01-13 11:37:52 --> Helper loaded: my_helper
INFO - 2023-01-13 11:37:52 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:37:52 --> Controller Class Initialized
INFO - 2023-01-13 11:37:52 --> Final output sent to browser
DEBUG - 2023-01-13 11:37:52 --> Total execution time: 0.0481
INFO - 2023-01-13 11:37:53 --> Config Class Initialized
INFO - 2023-01-13 11:37:53 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:37:53 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:37:53 --> Utf8 Class Initialized
INFO - 2023-01-13 11:37:53 --> URI Class Initialized
INFO - 2023-01-13 11:37:53 --> Router Class Initialized
INFO - 2023-01-13 11:37:53 --> Output Class Initialized
INFO - 2023-01-13 11:37:53 --> Security Class Initialized
DEBUG - 2023-01-13 11:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:37:53 --> Input Class Initialized
INFO - 2023-01-13 11:37:53 --> Language Class Initialized
INFO - 2023-01-13 11:37:53 --> Language Class Initialized
INFO - 2023-01-13 11:37:53 --> Config Class Initialized
INFO - 2023-01-13 11:37:53 --> Loader Class Initialized
INFO - 2023-01-13 11:37:53 --> Helper loaded: url_helper
INFO - 2023-01-13 11:37:53 --> Helper loaded: file_helper
INFO - 2023-01-13 11:37:53 --> Helper loaded: form_helper
INFO - 2023-01-13 11:37:53 --> Helper loaded: my_helper
INFO - 2023-01-13 11:37:53 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:37:53 --> Controller Class Initialized
DEBUG - 2023-01-13 11:37:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-13 11:37:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:37:53 --> Final output sent to browser
DEBUG - 2023-01-13 11:37:53 --> Total execution time: 0.0292
INFO - 2023-01-13 11:37:53 --> Config Class Initialized
INFO - 2023-01-13 11:37:53 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:37:53 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:37:53 --> Utf8 Class Initialized
INFO - 2023-01-13 11:37:53 --> URI Class Initialized
INFO - 2023-01-13 11:37:53 --> Router Class Initialized
INFO - 2023-01-13 11:37:53 --> Output Class Initialized
INFO - 2023-01-13 11:37:53 --> Security Class Initialized
DEBUG - 2023-01-13 11:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:37:53 --> Input Class Initialized
INFO - 2023-01-13 11:37:53 --> Language Class Initialized
ERROR - 2023-01-13 11:37:53 --> 404 Page Not Found: /index
INFO - 2023-01-13 11:37:53 --> Config Class Initialized
INFO - 2023-01-13 11:37:53 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:37:53 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:37:53 --> Utf8 Class Initialized
INFO - 2023-01-13 11:37:53 --> URI Class Initialized
INFO - 2023-01-13 11:37:53 --> Router Class Initialized
INFO - 2023-01-13 11:37:53 --> Output Class Initialized
INFO - 2023-01-13 11:37:53 --> Security Class Initialized
DEBUG - 2023-01-13 11:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:37:53 --> Input Class Initialized
INFO - 2023-01-13 11:37:53 --> Language Class Initialized
INFO - 2023-01-13 11:37:53 --> Language Class Initialized
INFO - 2023-01-13 11:37:53 --> Config Class Initialized
INFO - 2023-01-13 11:37:53 --> Loader Class Initialized
INFO - 2023-01-13 11:37:53 --> Helper loaded: url_helper
INFO - 2023-01-13 11:37:53 --> Helper loaded: file_helper
INFO - 2023-01-13 11:37:53 --> Helper loaded: form_helper
INFO - 2023-01-13 11:37:53 --> Helper loaded: my_helper
INFO - 2023-01-13 11:37:53 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:37:53 --> Controller Class Initialized
INFO - 2023-01-13 11:37:55 --> Config Class Initialized
INFO - 2023-01-13 11:37:55 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:37:55 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:37:55 --> Utf8 Class Initialized
INFO - 2023-01-13 11:37:55 --> URI Class Initialized
INFO - 2023-01-13 11:37:55 --> Router Class Initialized
INFO - 2023-01-13 11:37:55 --> Output Class Initialized
INFO - 2023-01-13 11:37:55 --> Security Class Initialized
DEBUG - 2023-01-13 11:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:37:55 --> Input Class Initialized
INFO - 2023-01-13 11:37:55 --> Language Class Initialized
INFO - 2023-01-13 11:37:55 --> Language Class Initialized
INFO - 2023-01-13 11:37:55 --> Config Class Initialized
INFO - 2023-01-13 11:37:55 --> Loader Class Initialized
INFO - 2023-01-13 11:37:55 --> Helper loaded: url_helper
INFO - 2023-01-13 11:37:55 --> Helper loaded: file_helper
INFO - 2023-01-13 11:37:55 --> Helper loaded: form_helper
INFO - 2023-01-13 11:37:55 --> Helper loaded: my_helper
INFO - 2023-01-13 11:37:55 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:37:55 --> Controller Class Initialized
INFO - 2023-01-13 11:37:55 --> Final output sent to browser
DEBUG - 2023-01-13 11:37:55 --> Total execution time: 0.0554
INFO - 2023-01-13 11:38:47 --> Config Class Initialized
INFO - 2023-01-13 11:38:47 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:38:47 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:38:47 --> Utf8 Class Initialized
INFO - 2023-01-13 11:38:47 --> URI Class Initialized
INFO - 2023-01-13 11:38:47 --> Router Class Initialized
INFO - 2023-01-13 11:38:47 --> Output Class Initialized
INFO - 2023-01-13 11:38:47 --> Security Class Initialized
DEBUG - 2023-01-13 11:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:38:47 --> Input Class Initialized
INFO - 2023-01-13 11:38:47 --> Language Class Initialized
INFO - 2023-01-13 11:38:47 --> Language Class Initialized
INFO - 2023-01-13 11:38:47 --> Config Class Initialized
INFO - 2023-01-13 11:38:47 --> Loader Class Initialized
INFO - 2023-01-13 11:38:47 --> Helper loaded: url_helper
INFO - 2023-01-13 11:38:47 --> Helper loaded: file_helper
INFO - 2023-01-13 11:38:47 --> Helper loaded: form_helper
INFO - 2023-01-13 11:38:47 --> Helper loaded: my_helper
INFO - 2023-01-13 11:38:47 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:38:47 --> Controller Class Initialized
INFO - 2023-01-13 11:38:47 --> Final output sent to browser
DEBUG - 2023-01-13 11:38:47 --> Total execution time: 0.0272
INFO - 2023-01-13 11:40:01 --> Config Class Initialized
INFO - 2023-01-13 11:40:01 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:40:01 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:40:01 --> Utf8 Class Initialized
INFO - 2023-01-13 11:40:01 --> URI Class Initialized
INFO - 2023-01-13 11:40:01 --> Router Class Initialized
INFO - 2023-01-13 11:40:01 --> Output Class Initialized
INFO - 2023-01-13 11:40:01 --> Security Class Initialized
DEBUG - 2023-01-13 11:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:40:01 --> Input Class Initialized
INFO - 2023-01-13 11:40:01 --> Language Class Initialized
INFO - 2023-01-13 11:40:01 --> Language Class Initialized
INFO - 2023-01-13 11:40:01 --> Config Class Initialized
INFO - 2023-01-13 11:40:01 --> Loader Class Initialized
INFO - 2023-01-13 11:40:01 --> Helper loaded: url_helper
INFO - 2023-01-13 11:40:01 --> Helper loaded: file_helper
INFO - 2023-01-13 11:40:01 --> Helper loaded: form_helper
INFO - 2023-01-13 11:40:01 --> Helper loaded: my_helper
INFO - 2023-01-13 11:40:01 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:40:01 --> Controller Class Initialized
DEBUG - 2023-01-13 11:40:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-13 11:40:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:40:01 --> Final output sent to browser
DEBUG - 2023-01-13 11:40:01 --> Total execution time: 0.0576
INFO - 2023-01-13 11:40:01 --> Config Class Initialized
INFO - 2023-01-13 11:40:01 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:40:01 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:40:01 --> Utf8 Class Initialized
INFO - 2023-01-13 11:40:01 --> URI Class Initialized
INFO - 2023-01-13 11:40:01 --> Router Class Initialized
INFO - 2023-01-13 11:40:01 --> Output Class Initialized
INFO - 2023-01-13 11:40:01 --> Security Class Initialized
DEBUG - 2023-01-13 11:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:40:01 --> Input Class Initialized
INFO - 2023-01-13 11:40:01 --> Language Class Initialized
ERROR - 2023-01-13 11:40:01 --> 404 Page Not Found: /index
INFO - 2023-01-13 11:40:01 --> Config Class Initialized
INFO - 2023-01-13 11:40:01 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:40:01 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:40:01 --> Utf8 Class Initialized
INFO - 2023-01-13 11:40:01 --> URI Class Initialized
INFO - 2023-01-13 11:40:01 --> Router Class Initialized
INFO - 2023-01-13 11:40:01 --> Output Class Initialized
INFO - 2023-01-13 11:40:01 --> Security Class Initialized
DEBUG - 2023-01-13 11:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:40:01 --> Input Class Initialized
INFO - 2023-01-13 11:40:01 --> Language Class Initialized
INFO - 2023-01-13 11:40:01 --> Language Class Initialized
INFO - 2023-01-13 11:40:01 --> Config Class Initialized
INFO - 2023-01-13 11:40:01 --> Loader Class Initialized
INFO - 2023-01-13 11:40:01 --> Helper loaded: url_helper
INFO - 2023-01-13 11:40:01 --> Helper loaded: file_helper
INFO - 2023-01-13 11:40:01 --> Helper loaded: form_helper
INFO - 2023-01-13 11:40:01 --> Helper loaded: my_helper
INFO - 2023-01-13 11:40:01 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:40:01 --> Controller Class Initialized
INFO - 2023-01-13 11:40:03 --> Config Class Initialized
INFO - 2023-01-13 11:40:03 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:40:03 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:40:03 --> Utf8 Class Initialized
INFO - 2023-01-13 11:40:03 --> URI Class Initialized
INFO - 2023-01-13 11:40:03 --> Router Class Initialized
INFO - 2023-01-13 11:40:03 --> Output Class Initialized
INFO - 2023-01-13 11:40:03 --> Security Class Initialized
DEBUG - 2023-01-13 11:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:40:03 --> Input Class Initialized
INFO - 2023-01-13 11:40:03 --> Language Class Initialized
INFO - 2023-01-13 11:40:03 --> Language Class Initialized
INFO - 2023-01-13 11:40:03 --> Config Class Initialized
INFO - 2023-01-13 11:40:03 --> Loader Class Initialized
INFO - 2023-01-13 11:40:03 --> Helper loaded: url_helper
INFO - 2023-01-13 11:40:03 --> Helper loaded: file_helper
INFO - 2023-01-13 11:40:03 --> Helper loaded: form_helper
INFO - 2023-01-13 11:40:03 --> Helper loaded: my_helper
INFO - 2023-01-13 11:40:03 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:40:03 --> Controller Class Initialized
INFO - 2023-01-13 11:40:03 --> Final output sent to browser
DEBUG - 2023-01-13 11:40:03 --> Total execution time: 0.0342
INFO - 2023-01-13 11:40:05 --> Config Class Initialized
INFO - 2023-01-13 11:40:05 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:40:05 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:40:05 --> Utf8 Class Initialized
INFO - 2023-01-13 11:40:05 --> URI Class Initialized
INFO - 2023-01-13 11:40:05 --> Router Class Initialized
INFO - 2023-01-13 11:40:05 --> Output Class Initialized
INFO - 2023-01-13 11:40:05 --> Security Class Initialized
DEBUG - 2023-01-13 11:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:40:05 --> Input Class Initialized
INFO - 2023-01-13 11:40:05 --> Language Class Initialized
INFO - 2023-01-13 11:40:05 --> Language Class Initialized
INFO - 2023-01-13 11:40:05 --> Config Class Initialized
INFO - 2023-01-13 11:40:05 --> Loader Class Initialized
INFO - 2023-01-13 11:40:05 --> Helper loaded: url_helper
INFO - 2023-01-13 11:40:05 --> Helper loaded: file_helper
INFO - 2023-01-13 11:40:05 --> Helper loaded: form_helper
INFO - 2023-01-13 11:40:05 --> Helper loaded: my_helper
INFO - 2023-01-13 11:40:05 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:40:05 --> Controller Class Initialized
INFO - 2023-01-13 11:40:05 --> Final output sent to browser
DEBUG - 2023-01-13 11:40:05 --> Total execution time: 0.0518
INFO - 2023-01-13 11:40:10 --> Config Class Initialized
INFO - 2023-01-13 11:40:10 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:40:10 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:40:10 --> Utf8 Class Initialized
INFO - 2023-01-13 11:40:10 --> URI Class Initialized
INFO - 2023-01-13 11:40:10 --> Router Class Initialized
INFO - 2023-01-13 11:40:10 --> Output Class Initialized
INFO - 2023-01-13 11:40:10 --> Security Class Initialized
DEBUG - 2023-01-13 11:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:40:10 --> Input Class Initialized
INFO - 2023-01-13 11:40:10 --> Language Class Initialized
INFO - 2023-01-13 11:40:10 --> Language Class Initialized
INFO - 2023-01-13 11:40:10 --> Config Class Initialized
INFO - 2023-01-13 11:40:10 --> Loader Class Initialized
INFO - 2023-01-13 11:40:10 --> Helper loaded: url_helper
INFO - 2023-01-13 11:40:10 --> Helper loaded: file_helper
INFO - 2023-01-13 11:40:10 --> Helper loaded: form_helper
INFO - 2023-01-13 11:40:10 --> Helper loaded: my_helper
INFO - 2023-01-13 11:40:10 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:40:10 --> Controller Class Initialized
ERROR - 2023-01-13 11:40:10 --> Query error: Unknown column 'a.catatan' in 'field list' - Invalid query: SELECT 
                                d.nama nmsiswa, a.jenis, a.id_siswa, a.nilai, a.catatan
                                FROM t_nilai_icb a
                                LEFT JOIN t_guru_mapel b ON a.id_guru_mapel = b.id 
                                LEFT JOIN t_kelas_siswa c ON CONCAT(a.id_siswa,LEFT(a.tasm,4)) = CONCAT(c.id_siswa,c.ta)
                                LEFT JOIN m_siswa d ON c.id_siswa = d.id
                                WHERE c.id_kelas = 8 AND b.id_mapel = 30 AND a.jenis != 'h'
                                AND a.tasm = '20232'
                                ORDER BY d.id
INFO - 2023-01-13 11:40:10 --> Language file loaded: language/english/db_lang.php
INFO - 2023-01-13 11:40:24 --> Config Class Initialized
INFO - 2023-01-13 11:40:24 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:40:24 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:40:24 --> Utf8 Class Initialized
INFO - 2023-01-13 11:40:24 --> URI Class Initialized
INFO - 2023-01-13 11:40:24 --> Router Class Initialized
INFO - 2023-01-13 11:40:24 --> Output Class Initialized
INFO - 2023-01-13 11:40:24 --> Security Class Initialized
DEBUG - 2023-01-13 11:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:40:24 --> Input Class Initialized
INFO - 2023-01-13 11:40:24 --> Language Class Initialized
INFO - 2023-01-13 11:40:24 --> Language Class Initialized
INFO - 2023-01-13 11:40:24 --> Config Class Initialized
INFO - 2023-01-13 11:40:24 --> Loader Class Initialized
INFO - 2023-01-13 11:40:24 --> Helper loaded: url_helper
INFO - 2023-01-13 11:40:24 --> Helper loaded: file_helper
INFO - 2023-01-13 11:40:24 --> Helper loaded: form_helper
INFO - 2023-01-13 11:40:24 --> Helper loaded: my_helper
INFO - 2023-01-13 11:40:24 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:40:24 --> Controller Class Initialized
DEBUG - 2023-01-13 11:40:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-13 11:40:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:40:24 --> Final output sent to browser
DEBUG - 2023-01-13 11:40:24 --> Total execution time: 0.0501
INFO - 2023-01-13 11:40:24 --> Config Class Initialized
INFO - 2023-01-13 11:40:24 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:40:24 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:40:24 --> Utf8 Class Initialized
INFO - 2023-01-13 11:40:24 --> URI Class Initialized
INFO - 2023-01-13 11:40:24 --> Router Class Initialized
INFO - 2023-01-13 11:40:24 --> Output Class Initialized
INFO - 2023-01-13 11:40:24 --> Security Class Initialized
DEBUG - 2023-01-13 11:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:40:24 --> Input Class Initialized
INFO - 2023-01-13 11:40:24 --> Language Class Initialized
INFO - 2023-01-13 11:40:24 --> Language Class Initialized
INFO - 2023-01-13 11:40:24 --> Config Class Initialized
INFO - 2023-01-13 11:40:24 --> Loader Class Initialized
INFO - 2023-01-13 11:40:24 --> Helper loaded: url_helper
INFO - 2023-01-13 11:40:24 --> Helper loaded: file_helper
INFO - 2023-01-13 11:40:24 --> Helper loaded: form_helper
INFO - 2023-01-13 11:40:24 --> Helper loaded: my_helper
INFO - 2023-01-13 11:40:24 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:40:24 --> Controller Class Initialized
INFO - 2023-01-13 11:40:26 --> Config Class Initialized
INFO - 2023-01-13 11:40:26 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:40:26 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:40:26 --> Utf8 Class Initialized
INFO - 2023-01-13 11:40:26 --> URI Class Initialized
INFO - 2023-01-13 11:40:26 --> Router Class Initialized
INFO - 2023-01-13 11:40:26 --> Output Class Initialized
INFO - 2023-01-13 11:40:26 --> Security Class Initialized
DEBUG - 2023-01-13 11:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:40:26 --> Input Class Initialized
INFO - 2023-01-13 11:40:26 --> Language Class Initialized
INFO - 2023-01-13 11:40:26 --> Language Class Initialized
INFO - 2023-01-13 11:40:26 --> Config Class Initialized
INFO - 2023-01-13 11:40:26 --> Loader Class Initialized
INFO - 2023-01-13 11:40:26 --> Helper loaded: url_helper
INFO - 2023-01-13 11:40:26 --> Helper loaded: file_helper
INFO - 2023-01-13 11:40:26 --> Helper loaded: form_helper
INFO - 2023-01-13 11:40:26 --> Helper loaded: my_helper
INFO - 2023-01-13 11:40:26 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:40:26 --> Controller Class Initialized
ERROR - 2023-01-13 11:40:26 --> Query error: Unknown column 'a.catatan' in 'field list' - Invalid query: SELECT 
                                d.nama nmsiswa, a.jenis, a.id_siswa, a.nilai, a.catatan
                                FROM t_nilai_icb a
                                LEFT JOIN t_guru_mapel b ON a.id_guru_mapel = b.id 
                                LEFT JOIN t_kelas_siswa c ON CONCAT(a.id_siswa,LEFT(a.tasm,4)) = CONCAT(c.id_siswa,c.ta)
                                LEFT JOIN m_siswa d ON c.id_siswa = d.id
                                WHERE c.id_kelas = 8 AND b.id_mapel = 30 AND a.jenis != 'h'
                                AND a.tasm = '20232'
                                ORDER BY d.id
INFO - 2023-01-13 11:40:26 --> Language file loaded: language/english/db_lang.php
INFO - 2023-01-13 11:41:11 --> Config Class Initialized
INFO - 2023-01-13 11:41:11 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:41:11 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:41:11 --> Utf8 Class Initialized
INFO - 2023-01-13 11:41:11 --> URI Class Initialized
INFO - 2023-01-13 11:41:11 --> Router Class Initialized
INFO - 2023-01-13 11:41:11 --> Output Class Initialized
INFO - 2023-01-13 11:41:11 --> Security Class Initialized
DEBUG - 2023-01-13 11:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:41:11 --> Input Class Initialized
INFO - 2023-01-13 11:41:11 --> Language Class Initialized
INFO - 2023-01-13 11:41:11 --> Language Class Initialized
INFO - 2023-01-13 11:41:11 --> Config Class Initialized
INFO - 2023-01-13 11:41:11 --> Loader Class Initialized
INFO - 2023-01-13 11:41:11 --> Helper loaded: url_helper
INFO - 2023-01-13 11:41:11 --> Helper loaded: file_helper
INFO - 2023-01-13 11:41:11 --> Helper loaded: form_helper
INFO - 2023-01-13 11:41:11 --> Helper loaded: my_helper
INFO - 2023-01-13 11:41:11 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:41:11 --> Controller Class Initialized
DEBUG - 2023-01-13 11:41:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-13 11:41:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:41:11 --> Final output sent to browser
DEBUG - 2023-01-13 11:41:11 --> Total execution time: 0.0327
INFO - 2023-01-13 11:41:11 --> Config Class Initialized
INFO - 2023-01-13 11:41:11 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:41:11 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:41:11 --> Utf8 Class Initialized
INFO - 2023-01-13 11:41:11 --> URI Class Initialized
INFO - 2023-01-13 11:41:11 --> Router Class Initialized
INFO - 2023-01-13 11:41:11 --> Output Class Initialized
INFO - 2023-01-13 11:41:11 --> Security Class Initialized
DEBUG - 2023-01-13 11:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:41:11 --> Input Class Initialized
INFO - 2023-01-13 11:41:11 --> Language Class Initialized
INFO - 2023-01-13 11:41:11 --> Language Class Initialized
INFO - 2023-01-13 11:41:11 --> Config Class Initialized
INFO - 2023-01-13 11:41:11 --> Loader Class Initialized
INFO - 2023-01-13 11:41:11 --> Helper loaded: url_helper
INFO - 2023-01-13 11:41:11 --> Helper loaded: file_helper
INFO - 2023-01-13 11:41:11 --> Helper loaded: form_helper
INFO - 2023-01-13 11:41:11 --> Helper loaded: my_helper
INFO - 2023-01-13 11:41:11 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:41:11 --> Controller Class Initialized
INFO - 2023-01-13 11:41:12 --> Config Class Initialized
INFO - 2023-01-13 11:41:12 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:41:12 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:41:12 --> Utf8 Class Initialized
INFO - 2023-01-13 11:41:12 --> URI Class Initialized
INFO - 2023-01-13 11:41:12 --> Router Class Initialized
INFO - 2023-01-13 11:41:12 --> Output Class Initialized
INFO - 2023-01-13 11:41:12 --> Security Class Initialized
DEBUG - 2023-01-13 11:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:41:12 --> Input Class Initialized
INFO - 2023-01-13 11:41:12 --> Language Class Initialized
INFO - 2023-01-13 11:41:12 --> Language Class Initialized
INFO - 2023-01-13 11:41:12 --> Config Class Initialized
INFO - 2023-01-13 11:41:12 --> Loader Class Initialized
INFO - 2023-01-13 11:41:12 --> Helper loaded: url_helper
INFO - 2023-01-13 11:41:12 --> Helper loaded: file_helper
INFO - 2023-01-13 11:41:12 --> Helper loaded: form_helper
INFO - 2023-01-13 11:41:12 --> Helper loaded: my_helper
INFO - 2023-01-13 11:41:12 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:41:12 --> Controller Class Initialized
DEBUG - 2023-01-13 11:41:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-13 11:41:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:41:12 --> Final output sent to browser
DEBUG - 2023-01-13 11:41:12 --> Total execution time: 0.0412
INFO - 2023-01-13 11:41:12 --> Config Class Initialized
INFO - 2023-01-13 11:41:12 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:41:12 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:41:12 --> Utf8 Class Initialized
INFO - 2023-01-13 11:41:12 --> URI Class Initialized
INFO - 2023-01-13 11:41:12 --> Router Class Initialized
INFO - 2023-01-13 11:41:12 --> Output Class Initialized
INFO - 2023-01-13 11:41:12 --> Security Class Initialized
DEBUG - 2023-01-13 11:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:41:12 --> Input Class Initialized
INFO - 2023-01-13 11:41:12 --> Language Class Initialized
INFO - 2023-01-13 11:41:12 --> Language Class Initialized
INFO - 2023-01-13 11:41:12 --> Config Class Initialized
INFO - 2023-01-13 11:41:12 --> Loader Class Initialized
INFO - 2023-01-13 11:41:12 --> Helper loaded: url_helper
INFO - 2023-01-13 11:41:12 --> Helper loaded: file_helper
INFO - 2023-01-13 11:41:12 --> Helper loaded: form_helper
INFO - 2023-01-13 11:41:12 --> Helper loaded: my_helper
INFO - 2023-01-13 11:41:12 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:41:12 --> Controller Class Initialized
INFO - 2023-01-13 11:41:13 --> Config Class Initialized
INFO - 2023-01-13 11:41:13 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:41:13 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:41:13 --> Utf8 Class Initialized
INFO - 2023-01-13 11:41:13 --> URI Class Initialized
INFO - 2023-01-13 11:41:13 --> Router Class Initialized
INFO - 2023-01-13 11:41:13 --> Output Class Initialized
INFO - 2023-01-13 11:41:13 --> Security Class Initialized
DEBUG - 2023-01-13 11:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:41:13 --> Input Class Initialized
INFO - 2023-01-13 11:41:13 --> Language Class Initialized
INFO - 2023-01-13 11:41:13 --> Language Class Initialized
INFO - 2023-01-13 11:41:13 --> Config Class Initialized
INFO - 2023-01-13 11:41:13 --> Loader Class Initialized
INFO - 2023-01-13 11:41:13 --> Helper loaded: url_helper
INFO - 2023-01-13 11:41:13 --> Helper loaded: file_helper
INFO - 2023-01-13 11:41:13 --> Helper loaded: form_helper
INFO - 2023-01-13 11:41:13 --> Helper loaded: my_helper
INFO - 2023-01-13 11:41:13 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:41:13 --> Controller Class Initialized
INFO - 2023-01-13 11:41:13 --> Final output sent to browser
DEBUG - 2023-01-13 11:41:13 --> Total execution time: 0.0248
INFO - 2023-01-13 11:41:14 --> Config Class Initialized
INFO - 2023-01-13 11:41:14 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:41:14 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:41:14 --> Utf8 Class Initialized
INFO - 2023-01-13 11:41:14 --> URI Class Initialized
INFO - 2023-01-13 11:41:14 --> Router Class Initialized
INFO - 2023-01-13 11:41:14 --> Output Class Initialized
INFO - 2023-01-13 11:41:14 --> Security Class Initialized
DEBUG - 2023-01-13 11:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:41:14 --> Input Class Initialized
INFO - 2023-01-13 11:41:14 --> Language Class Initialized
INFO - 2023-01-13 11:41:14 --> Language Class Initialized
INFO - 2023-01-13 11:41:14 --> Config Class Initialized
INFO - 2023-01-13 11:41:14 --> Loader Class Initialized
INFO - 2023-01-13 11:41:14 --> Helper loaded: url_helper
INFO - 2023-01-13 11:41:14 --> Helper loaded: file_helper
INFO - 2023-01-13 11:41:14 --> Helper loaded: form_helper
INFO - 2023-01-13 11:41:14 --> Helper loaded: my_helper
INFO - 2023-01-13 11:41:14 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:41:14 --> Controller Class Initialized
INFO - 2023-01-13 11:41:23 --> Config Class Initialized
INFO - 2023-01-13 11:41:23 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:41:23 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:41:23 --> Utf8 Class Initialized
INFO - 2023-01-13 11:41:23 --> URI Class Initialized
INFO - 2023-01-13 11:41:23 --> Router Class Initialized
INFO - 2023-01-13 11:41:23 --> Output Class Initialized
INFO - 2023-01-13 11:41:23 --> Security Class Initialized
DEBUG - 2023-01-13 11:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:41:23 --> Input Class Initialized
INFO - 2023-01-13 11:41:23 --> Language Class Initialized
INFO - 2023-01-13 11:41:23 --> Language Class Initialized
INFO - 2023-01-13 11:41:23 --> Config Class Initialized
INFO - 2023-01-13 11:41:23 --> Loader Class Initialized
INFO - 2023-01-13 11:41:23 --> Helper loaded: url_helper
INFO - 2023-01-13 11:41:23 --> Helper loaded: file_helper
INFO - 2023-01-13 11:41:23 --> Helper loaded: form_helper
INFO - 2023-01-13 11:41:23 --> Helper loaded: my_helper
INFO - 2023-01-13 11:41:23 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:41:23 --> Controller Class Initialized
INFO - 2023-01-13 11:41:23 --> Final output sent to browser
DEBUG - 2023-01-13 11:41:23 --> Total execution time: 0.0245
INFO - 2023-01-13 11:41:23 --> Config Class Initialized
INFO - 2023-01-13 11:41:23 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:41:23 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:41:23 --> Utf8 Class Initialized
INFO - 2023-01-13 11:41:23 --> URI Class Initialized
INFO - 2023-01-13 11:41:23 --> Router Class Initialized
INFO - 2023-01-13 11:41:23 --> Output Class Initialized
INFO - 2023-01-13 11:41:23 --> Security Class Initialized
DEBUG - 2023-01-13 11:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:41:23 --> Input Class Initialized
INFO - 2023-01-13 11:41:23 --> Language Class Initialized
INFO - 2023-01-13 11:41:23 --> Language Class Initialized
INFO - 2023-01-13 11:41:23 --> Config Class Initialized
INFO - 2023-01-13 11:41:23 --> Loader Class Initialized
INFO - 2023-01-13 11:41:23 --> Helper loaded: url_helper
INFO - 2023-01-13 11:41:23 --> Helper loaded: file_helper
INFO - 2023-01-13 11:41:23 --> Helper loaded: form_helper
INFO - 2023-01-13 11:41:23 --> Helper loaded: my_helper
INFO - 2023-01-13 11:41:23 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:41:23 --> Controller Class Initialized
INFO - 2023-01-13 11:41:23 --> Final output sent to browser
DEBUG - 2023-01-13 11:41:23 --> Total execution time: 0.0390
INFO - 2023-01-13 11:41:24 --> Config Class Initialized
INFO - 2023-01-13 11:41:24 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:41:24 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:41:24 --> Utf8 Class Initialized
INFO - 2023-01-13 11:41:24 --> URI Class Initialized
INFO - 2023-01-13 11:41:24 --> Router Class Initialized
INFO - 2023-01-13 11:41:24 --> Output Class Initialized
INFO - 2023-01-13 11:41:24 --> Security Class Initialized
DEBUG - 2023-01-13 11:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:41:24 --> Input Class Initialized
INFO - 2023-01-13 11:41:24 --> Language Class Initialized
INFO - 2023-01-13 11:41:24 --> Language Class Initialized
INFO - 2023-01-13 11:41:24 --> Config Class Initialized
INFO - 2023-01-13 11:41:24 --> Loader Class Initialized
INFO - 2023-01-13 11:41:24 --> Helper loaded: url_helper
INFO - 2023-01-13 11:41:24 --> Helper loaded: file_helper
INFO - 2023-01-13 11:41:24 --> Helper loaded: form_helper
INFO - 2023-01-13 11:41:24 --> Helper loaded: my_helper
INFO - 2023-01-13 11:41:24 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:41:24 --> Controller Class Initialized
INFO - 2023-01-13 11:41:24 --> Final output sent to browser
DEBUG - 2023-01-13 11:41:24 --> Total execution time: 0.0360
INFO - 2023-01-13 11:41:24 --> Config Class Initialized
INFO - 2023-01-13 11:41:24 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:41:24 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:41:24 --> Utf8 Class Initialized
INFO - 2023-01-13 11:41:24 --> URI Class Initialized
INFO - 2023-01-13 11:41:24 --> Router Class Initialized
INFO - 2023-01-13 11:41:24 --> Output Class Initialized
INFO - 2023-01-13 11:41:24 --> Security Class Initialized
DEBUG - 2023-01-13 11:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:41:24 --> Input Class Initialized
INFO - 2023-01-13 11:41:24 --> Language Class Initialized
INFO - 2023-01-13 11:41:24 --> Language Class Initialized
INFO - 2023-01-13 11:41:24 --> Config Class Initialized
INFO - 2023-01-13 11:41:24 --> Loader Class Initialized
INFO - 2023-01-13 11:41:24 --> Helper loaded: url_helper
INFO - 2023-01-13 11:41:24 --> Helper loaded: file_helper
INFO - 2023-01-13 11:41:24 --> Helper loaded: form_helper
INFO - 2023-01-13 11:41:24 --> Helper loaded: my_helper
INFO - 2023-01-13 11:41:24 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:41:24 --> Controller Class Initialized
DEBUG - 2023-01-13 11:41:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-13 11:41:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:41:24 --> Final output sent to browser
DEBUG - 2023-01-13 11:41:24 --> Total execution time: 0.0491
INFO - 2023-01-13 11:41:24 --> Config Class Initialized
INFO - 2023-01-13 11:41:24 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:41:24 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:41:24 --> Utf8 Class Initialized
INFO - 2023-01-13 11:41:24 --> URI Class Initialized
INFO - 2023-01-13 11:41:24 --> Router Class Initialized
INFO - 2023-01-13 11:41:24 --> Output Class Initialized
INFO - 2023-01-13 11:41:24 --> Security Class Initialized
DEBUG - 2023-01-13 11:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:41:24 --> Input Class Initialized
INFO - 2023-01-13 11:41:24 --> Language Class Initialized
INFO - 2023-01-13 11:41:24 --> Language Class Initialized
INFO - 2023-01-13 11:41:24 --> Config Class Initialized
INFO - 2023-01-13 11:41:24 --> Loader Class Initialized
INFO - 2023-01-13 11:41:24 --> Helper loaded: url_helper
INFO - 2023-01-13 11:41:24 --> Helper loaded: file_helper
INFO - 2023-01-13 11:41:24 --> Helper loaded: form_helper
INFO - 2023-01-13 11:41:24 --> Helper loaded: my_helper
INFO - 2023-01-13 11:41:24 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:41:24 --> Controller Class Initialized
INFO - 2023-01-13 11:41:25 --> Config Class Initialized
INFO - 2023-01-13 11:41:25 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:41:25 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:41:25 --> Utf8 Class Initialized
INFO - 2023-01-13 11:41:25 --> URI Class Initialized
INFO - 2023-01-13 11:41:25 --> Router Class Initialized
INFO - 2023-01-13 11:41:25 --> Output Class Initialized
INFO - 2023-01-13 11:41:25 --> Security Class Initialized
DEBUG - 2023-01-13 11:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:41:25 --> Input Class Initialized
INFO - 2023-01-13 11:41:25 --> Language Class Initialized
INFO - 2023-01-13 11:41:25 --> Language Class Initialized
INFO - 2023-01-13 11:41:25 --> Config Class Initialized
INFO - 2023-01-13 11:41:25 --> Loader Class Initialized
INFO - 2023-01-13 11:41:25 --> Helper loaded: url_helper
INFO - 2023-01-13 11:41:25 --> Helper loaded: file_helper
INFO - 2023-01-13 11:41:25 --> Helper loaded: form_helper
INFO - 2023-01-13 11:41:25 --> Helper loaded: my_helper
INFO - 2023-01-13 11:41:25 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:41:25 --> Controller Class Initialized
INFO - 2023-01-13 11:41:25 --> Final output sent to browser
DEBUG - 2023-01-13 11:41:25 --> Total execution time: 0.0231
INFO - 2023-01-13 11:41:36 --> Config Class Initialized
INFO - 2023-01-13 11:41:36 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:41:36 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:41:36 --> Utf8 Class Initialized
INFO - 2023-01-13 11:41:36 --> URI Class Initialized
INFO - 2023-01-13 11:41:36 --> Router Class Initialized
INFO - 2023-01-13 11:41:36 --> Output Class Initialized
INFO - 2023-01-13 11:41:36 --> Security Class Initialized
DEBUG - 2023-01-13 11:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:41:36 --> Input Class Initialized
INFO - 2023-01-13 11:41:36 --> Language Class Initialized
INFO - 2023-01-13 11:41:36 --> Language Class Initialized
INFO - 2023-01-13 11:41:36 --> Config Class Initialized
INFO - 2023-01-13 11:41:36 --> Loader Class Initialized
INFO - 2023-01-13 11:41:36 --> Helper loaded: url_helper
INFO - 2023-01-13 11:41:36 --> Helper loaded: file_helper
INFO - 2023-01-13 11:41:36 --> Helper loaded: form_helper
INFO - 2023-01-13 11:41:36 --> Helper loaded: my_helper
INFO - 2023-01-13 11:41:36 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:41:36 --> Controller Class Initialized
INFO - 2023-01-13 11:41:36 --> Final output sent to browser
DEBUG - 2023-01-13 11:41:36 --> Total execution time: 0.0389
INFO - 2023-01-13 11:41:36 --> Config Class Initialized
INFO - 2023-01-13 11:41:36 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:41:36 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:41:36 --> Utf8 Class Initialized
INFO - 2023-01-13 11:41:36 --> URI Class Initialized
INFO - 2023-01-13 11:41:36 --> Router Class Initialized
INFO - 2023-01-13 11:41:36 --> Output Class Initialized
INFO - 2023-01-13 11:41:36 --> Security Class Initialized
DEBUG - 2023-01-13 11:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:41:36 --> Input Class Initialized
INFO - 2023-01-13 11:41:36 --> Language Class Initialized
INFO - 2023-01-13 11:41:36 --> Language Class Initialized
INFO - 2023-01-13 11:41:36 --> Config Class Initialized
INFO - 2023-01-13 11:41:36 --> Loader Class Initialized
INFO - 2023-01-13 11:41:36 --> Helper loaded: url_helper
INFO - 2023-01-13 11:41:36 --> Helper loaded: file_helper
INFO - 2023-01-13 11:41:36 --> Helper loaded: form_helper
INFO - 2023-01-13 11:41:36 --> Helper loaded: my_helper
INFO - 2023-01-13 11:41:36 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:41:36 --> Controller Class Initialized
INFO - 2023-01-13 11:41:36 --> Final output sent to browser
DEBUG - 2023-01-13 11:41:36 --> Total execution time: 0.0223
INFO - 2023-01-13 11:41:36 --> Config Class Initialized
INFO - 2023-01-13 11:41:36 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:41:36 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:41:36 --> Utf8 Class Initialized
INFO - 2023-01-13 11:41:36 --> URI Class Initialized
INFO - 2023-01-13 11:41:36 --> Router Class Initialized
INFO - 2023-01-13 11:41:36 --> Output Class Initialized
INFO - 2023-01-13 11:41:36 --> Security Class Initialized
DEBUG - 2023-01-13 11:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:41:36 --> Input Class Initialized
INFO - 2023-01-13 11:41:36 --> Language Class Initialized
INFO - 2023-01-13 11:41:36 --> Language Class Initialized
INFO - 2023-01-13 11:41:36 --> Config Class Initialized
INFO - 2023-01-13 11:41:36 --> Loader Class Initialized
INFO - 2023-01-13 11:41:36 --> Helper loaded: url_helper
INFO - 2023-01-13 11:41:36 --> Helper loaded: file_helper
INFO - 2023-01-13 11:41:36 --> Helper loaded: form_helper
INFO - 2023-01-13 11:41:36 --> Helper loaded: my_helper
INFO - 2023-01-13 11:41:36 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:41:36 --> Controller Class Initialized
INFO - 2023-01-13 11:41:36 --> Final output sent to browser
DEBUG - 2023-01-13 11:41:36 --> Total execution time: 0.0399
INFO - 2023-01-13 11:41:39 --> Config Class Initialized
INFO - 2023-01-13 11:41:39 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:41:39 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:41:39 --> Utf8 Class Initialized
INFO - 2023-01-13 11:41:39 --> URI Class Initialized
INFO - 2023-01-13 11:41:39 --> Router Class Initialized
INFO - 2023-01-13 11:41:39 --> Output Class Initialized
INFO - 2023-01-13 11:41:39 --> Security Class Initialized
DEBUG - 2023-01-13 11:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:41:39 --> Input Class Initialized
INFO - 2023-01-13 11:41:39 --> Language Class Initialized
ERROR - 2023-01-13 11:41:39 --> 404 Page Not Found: /index
INFO - 2023-01-13 11:41:42 --> Config Class Initialized
INFO - 2023-01-13 11:41:42 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:41:42 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:41:42 --> Utf8 Class Initialized
INFO - 2023-01-13 11:41:42 --> URI Class Initialized
INFO - 2023-01-13 11:41:42 --> Router Class Initialized
INFO - 2023-01-13 11:41:42 --> Output Class Initialized
INFO - 2023-01-13 11:41:42 --> Security Class Initialized
DEBUG - 2023-01-13 11:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:41:42 --> Input Class Initialized
INFO - 2023-01-13 11:41:42 --> Language Class Initialized
INFO - 2023-01-13 11:41:42 --> Language Class Initialized
INFO - 2023-01-13 11:41:42 --> Config Class Initialized
INFO - 2023-01-13 11:41:42 --> Loader Class Initialized
INFO - 2023-01-13 11:41:42 --> Helper loaded: url_helper
INFO - 2023-01-13 11:41:42 --> Helper loaded: file_helper
INFO - 2023-01-13 11:41:42 --> Helper loaded: form_helper
INFO - 2023-01-13 11:41:42 --> Helper loaded: my_helper
INFO - 2023-01-13 11:41:42 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:41:42 --> Controller Class Initialized
INFO - 2023-01-13 11:41:42 --> Final output sent to browser
DEBUG - 2023-01-13 11:41:42 --> Total execution time: 0.0506
INFO - 2023-01-13 11:42:00 --> Config Class Initialized
INFO - 2023-01-13 11:42:00 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:42:00 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:42:00 --> Utf8 Class Initialized
INFO - 2023-01-13 11:42:00 --> URI Class Initialized
INFO - 2023-01-13 11:42:00 --> Router Class Initialized
INFO - 2023-01-13 11:42:00 --> Output Class Initialized
INFO - 2023-01-13 11:42:00 --> Security Class Initialized
DEBUG - 2023-01-13 11:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:42:00 --> Input Class Initialized
INFO - 2023-01-13 11:42:00 --> Language Class Initialized
INFO - 2023-01-13 11:42:00 --> Language Class Initialized
INFO - 2023-01-13 11:42:00 --> Config Class Initialized
INFO - 2023-01-13 11:42:00 --> Loader Class Initialized
INFO - 2023-01-13 11:42:00 --> Helper loaded: url_helper
INFO - 2023-01-13 11:42:00 --> Helper loaded: file_helper
INFO - 2023-01-13 11:42:00 --> Helper loaded: form_helper
INFO - 2023-01-13 11:42:00 --> Helper loaded: my_helper
INFO - 2023-01-13 11:42:00 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:42:00 --> Controller Class Initialized
INFO - 2023-01-13 11:42:00 --> Final output sent to browser
DEBUG - 2023-01-13 11:42:00 --> Total execution time: 0.0388
INFO - 2023-01-13 11:45:32 --> Config Class Initialized
INFO - 2023-01-13 11:45:32 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:45:32 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:45:32 --> Utf8 Class Initialized
INFO - 2023-01-13 11:45:32 --> URI Class Initialized
INFO - 2023-01-13 11:45:32 --> Router Class Initialized
INFO - 2023-01-13 11:45:32 --> Output Class Initialized
INFO - 2023-01-13 11:45:32 --> Security Class Initialized
DEBUG - 2023-01-13 11:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:45:32 --> Input Class Initialized
INFO - 2023-01-13 11:45:32 --> Language Class Initialized
INFO - 2023-01-13 11:45:32 --> Language Class Initialized
INFO - 2023-01-13 11:45:32 --> Config Class Initialized
INFO - 2023-01-13 11:45:32 --> Loader Class Initialized
INFO - 2023-01-13 11:45:32 --> Helper loaded: url_helper
INFO - 2023-01-13 11:45:32 --> Helper loaded: file_helper
INFO - 2023-01-13 11:45:32 --> Helper loaded: form_helper
INFO - 2023-01-13 11:45:32 --> Helper loaded: my_helper
INFO - 2023-01-13 11:45:32 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:45:32 --> Controller Class Initialized
DEBUG - 2023-01-13 11:45:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-13 11:45:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:45:32 --> Final output sent to browser
DEBUG - 2023-01-13 11:45:32 --> Total execution time: 0.0562
INFO - 2023-01-13 11:45:32 --> Config Class Initialized
INFO - 2023-01-13 11:45:32 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:45:32 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:45:32 --> Utf8 Class Initialized
INFO - 2023-01-13 11:45:32 --> URI Class Initialized
INFO - 2023-01-13 11:45:32 --> Router Class Initialized
INFO - 2023-01-13 11:45:32 --> Output Class Initialized
INFO - 2023-01-13 11:45:32 --> Config Class Initialized
INFO - 2023-01-13 11:45:32 --> Hooks Class Initialized
INFO - 2023-01-13 11:45:32 --> Security Class Initialized
DEBUG - 2023-01-13 11:45:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 11:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:45:32 --> Utf8 Class Initialized
INFO - 2023-01-13 11:45:32 --> Input Class Initialized
INFO - 2023-01-13 11:45:32 --> Language Class Initialized
INFO - 2023-01-13 11:45:32 --> URI Class Initialized
ERROR - 2023-01-13 11:45:32 --> 404 Page Not Found: /index
INFO - 2023-01-13 11:45:32 --> Router Class Initialized
INFO - 2023-01-13 11:45:32 --> Output Class Initialized
INFO - 2023-01-13 11:45:32 --> Security Class Initialized
DEBUG - 2023-01-13 11:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:45:32 --> Input Class Initialized
INFO - 2023-01-13 11:45:32 --> Language Class Initialized
INFO - 2023-01-13 11:45:32 --> Language Class Initialized
INFO - 2023-01-13 11:45:32 --> Config Class Initialized
INFO - 2023-01-13 11:45:32 --> Loader Class Initialized
INFO - 2023-01-13 11:45:32 --> Helper loaded: url_helper
INFO - 2023-01-13 11:45:32 --> Helper loaded: file_helper
INFO - 2023-01-13 11:45:32 --> Helper loaded: form_helper
INFO - 2023-01-13 11:45:32 --> Helper loaded: my_helper
INFO - 2023-01-13 11:45:32 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:45:32 --> Controller Class Initialized
INFO - 2023-01-13 11:45:33 --> Config Class Initialized
INFO - 2023-01-13 11:45:33 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:45:33 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:45:33 --> Utf8 Class Initialized
INFO - 2023-01-13 11:45:33 --> URI Class Initialized
INFO - 2023-01-13 11:45:33 --> Router Class Initialized
INFO - 2023-01-13 11:45:33 --> Output Class Initialized
INFO - 2023-01-13 11:45:33 --> Security Class Initialized
DEBUG - 2023-01-13 11:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:45:33 --> Input Class Initialized
INFO - 2023-01-13 11:45:33 --> Language Class Initialized
INFO - 2023-01-13 11:45:33 --> Language Class Initialized
INFO - 2023-01-13 11:45:33 --> Config Class Initialized
INFO - 2023-01-13 11:45:33 --> Loader Class Initialized
INFO - 2023-01-13 11:45:33 --> Helper loaded: url_helper
INFO - 2023-01-13 11:45:33 --> Helper loaded: file_helper
INFO - 2023-01-13 11:45:33 --> Helper loaded: form_helper
INFO - 2023-01-13 11:45:33 --> Helper loaded: my_helper
INFO - 2023-01-13 11:45:33 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:45:33 --> Controller Class Initialized
INFO - 2023-01-13 11:45:33 --> Final output sent to browser
DEBUG - 2023-01-13 11:45:33 --> Total execution time: 0.0431
INFO - 2023-01-13 11:45:36 --> Config Class Initialized
INFO - 2023-01-13 11:45:36 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:45:36 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:45:36 --> Utf8 Class Initialized
INFO - 2023-01-13 11:45:36 --> URI Class Initialized
INFO - 2023-01-13 11:45:36 --> Router Class Initialized
INFO - 2023-01-13 11:45:36 --> Output Class Initialized
INFO - 2023-01-13 11:45:36 --> Security Class Initialized
DEBUG - 2023-01-13 11:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:45:36 --> Input Class Initialized
INFO - 2023-01-13 11:45:36 --> Language Class Initialized
INFO - 2023-01-13 11:45:36 --> Language Class Initialized
INFO - 2023-01-13 11:45:36 --> Config Class Initialized
INFO - 2023-01-13 11:45:36 --> Loader Class Initialized
INFO - 2023-01-13 11:45:36 --> Helper loaded: url_helper
INFO - 2023-01-13 11:45:36 --> Helper loaded: file_helper
INFO - 2023-01-13 11:45:36 --> Helper loaded: form_helper
INFO - 2023-01-13 11:45:36 --> Helper loaded: my_helper
INFO - 2023-01-13 11:45:36 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:45:36 --> Controller Class Initialized
INFO - 2023-01-13 11:45:36 --> Final output sent to browser
DEBUG - 2023-01-13 11:45:36 --> Total execution time: 0.0282
INFO - 2023-01-13 11:45:37 --> Config Class Initialized
INFO - 2023-01-13 11:45:37 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:45:37 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:45:37 --> Utf8 Class Initialized
INFO - 2023-01-13 11:45:37 --> URI Class Initialized
INFO - 2023-01-13 11:45:37 --> Router Class Initialized
INFO - 2023-01-13 11:45:37 --> Output Class Initialized
INFO - 2023-01-13 11:45:37 --> Security Class Initialized
DEBUG - 2023-01-13 11:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:45:37 --> Input Class Initialized
INFO - 2023-01-13 11:45:37 --> Language Class Initialized
INFO - 2023-01-13 11:45:37 --> Language Class Initialized
INFO - 2023-01-13 11:45:37 --> Config Class Initialized
INFO - 2023-01-13 11:45:37 --> Loader Class Initialized
INFO - 2023-01-13 11:45:37 --> Helper loaded: url_helper
INFO - 2023-01-13 11:45:37 --> Helper loaded: file_helper
INFO - 2023-01-13 11:45:37 --> Helper loaded: form_helper
INFO - 2023-01-13 11:45:37 --> Helper loaded: my_helper
INFO - 2023-01-13 11:45:37 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:45:37 --> Controller Class Initialized
DEBUG - 2023-01-13 11:45:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-13 11:45:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:45:37 --> Final output sent to browser
DEBUG - 2023-01-13 11:45:37 --> Total execution time: 0.0313
INFO - 2023-01-13 11:45:38 --> Config Class Initialized
INFO - 2023-01-13 11:45:38 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:45:38 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:45:38 --> Utf8 Class Initialized
INFO - 2023-01-13 11:45:38 --> URI Class Initialized
INFO - 2023-01-13 11:45:38 --> Router Class Initialized
INFO - 2023-01-13 11:45:38 --> Output Class Initialized
INFO - 2023-01-13 11:45:38 --> Security Class Initialized
DEBUG - 2023-01-13 11:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:45:38 --> Input Class Initialized
INFO - 2023-01-13 11:45:38 --> Language Class Initialized
ERROR - 2023-01-13 11:45:38 --> 404 Page Not Found: /index
INFO - 2023-01-13 11:45:38 --> Config Class Initialized
INFO - 2023-01-13 11:45:38 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:45:38 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:45:38 --> Utf8 Class Initialized
INFO - 2023-01-13 11:45:38 --> URI Class Initialized
INFO - 2023-01-13 11:45:38 --> Router Class Initialized
INFO - 2023-01-13 11:45:38 --> Output Class Initialized
INFO - 2023-01-13 11:45:38 --> Security Class Initialized
DEBUG - 2023-01-13 11:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:45:38 --> Input Class Initialized
INFO - 2023-01-13 11:45:38 --> Language Class Initialized
INFO - 2023-01-13 11:45:38 --> Language Class Initialized
INFO - 2023-01-13 11:45:38 --> Config Class Initialized
INFO - 2023-01-13 11:45:38 --> Loader Class Initialized
INFO - 2023-01-13 11:45:38 --> Helper loaded: url_helper
INFO - 2023-01-13 11:45:38 --> Helper loaded: file_helper
INFO - 2023-01-13 11:45:38 --> Helper loaded: form_helper
INFO - 2023-01-13 11:45:38 --> Helper loaded: my_helper
INFO - 2023-01-13 11:45:38 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:45:38 --> Controller Class Initialized
INFO - 2023-01-13 11:45:39 --> Config Class Initialized
INFO - 2023-01-13 11:45:39 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:45:39 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:45:39 --> Utf8 Class Initialized
INFO - 2023-01-13 11:45:39 --> URI Class Initialized
INFO - 2023-01-13 11:45:39 --> Router Class Initialized
INFO - 2023-01-13 11:45:39 --> Output Class Initialized
INFO - 2023-01-13 11:45:39 --> Security Class Initialized
DEBUG - 2023-01-13 11:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:45:39 --> Input Class Initialized
INFO - 2023-01-13 11:45:39 --> Language Class Initialized
INFO - 2023-01-13 11:45:39 --> Language Class Initialized
INFO - 2023-01-13 11:45:39 --> Config Class Initialized
INFO - 2023-01-13 11:45:39 --> Loader Class Initialized
INFO - 2023-01-13 11:45:39 --> Helper loaded: url_helper
INFO - 2023-01-13 11:45:39 --> Helper loaded: file_helper
INFO - 2023-01-13 11:45:39 --> Helper loaded: form_helper
INFO - 2023-01-13 11:45:39 --> Helper loaded: my_helper
INFO - 2023-01-13 11:45:39 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:45:39 --> Controller Class Initialized
INFO - 2023-01-13 11:45:39 --> Final output sent to browser
DEBUG - 2023-01-13 11:45:39 --> Total execution time: 0.0568
INFO - 2023-01-13 11:45:40 --> Config Class Initialized
INFO - 2023-01-13 11:45:40 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:45:40 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:45:40 --> Utf8 Class Initialized
INFO - 2023-01-13 11:45:40 --> URI Class Initialized
INFO - 2023-01-13 11:45:40 --> Router Class Initialized
INFO - 2023-01-13 11:45:40 --> Output Class Initialized
INFO - 2023-01-13 11:45:40 --> Security Class Initialized
DEBUG - 2023-01-13 11:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:45:40 --> Input Class Initialized
INFO - 2023-01-13 11:45:40 --> Language Class Initialized
INFO - 2023-01-13 11:45:40 --> Language Class Initialized
INFO - 2023-01-13 11:45:40 --> Config Class Initialized
INFO - 2023-01-13 11:45:40 --> Loader Class Initialized
INFO - 2023-01-13 11:45:40 --> Helper loaded: url_helper
INFO - 2023-01-13 11:45:40 --> Helper loaded: file_helper
INFO - 2023-01-13 11:45:40 --> Helper loaded: form_helper
INFO - 2023-01-13 11:45:40 --> Helper loaded: my_helper
INFO - 2023-01-13 11:45:40 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:45:40 --> Controller Class Initialized
INFO - 2023-01-13 11:46:05 --> Config Class Initialized
INFO - 2023-01-13 11:46:05 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:46:05 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:46:05 --> Utf8 Class Initialized
INFO - 2023-01-13 11:46:05 --> URI Class Initialized
INFO - 2023-01-13 11:46:05 --> Router Class Initialized
INFO - 2023-01-13 11:46:05 --> Output Class Initialized
INFO - 2023-01-13 11:46:05 --> Security Class Initialized
DEBUG - 2023-01-13 11:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:46:05 --> Input Class Initialized
INFO - 2023-01-13 11:46:05 --> Language Class Initialized
INFO - 2023-01-13 11:46:05 --> Language Class Initialized
INFO - 2023-01-13 11:46:05 --> Config Class Initialized
INFO - 2023-01-13 11:46:05 --> Loader Class Initialized
INFO - 2023-01-13 11:46:05 --> Helper loaded: url_helper
INFO - 2023-01-13 11:46:05 --> Helper loaded: file_helper
INFO - 2023-01-13 11:46:05 --> Helper loaded: form_helper
INFO - 2023-01-13 11:46:05 --> Helper loaded: my_helper
INFO - 2023-01-13 11:46:05 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:46:05 --> Controller Class Initialized
DEBUG - 2023-01-13 11:46:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-13 11:46:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:46:05 --> Final output sent to browser
DEBUG - 2023-01-13 11:46:05 --> Total execution time: 0.0520
INFO - 2023-01-13 11:46:38 --> Config Class Initialized
INFO - 2023-01-13 11:46:38 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:46:39 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:46:39 --> Utf8 Class Initialized
INFO - 2023-01-13 11:46:39 --> URI Class Initialized
INFO - 2023-01-13 11:46:39 --> Router Class Initialized
INFO - 2023-01-13 11:46:39 --> Output Class Initialized
INFO - 2023-01-13 11:46:39 --> Security Class Initialized
DEBUG - 2023-01-13 11:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:46:39 --> Input Class Initialized
INFO - 2023-01-13 11:46:39 --> Language Class Initialized
INFO - 2023-01-13 11:46:39 --> Language Class Initialized
INFO - 2023-01-13 11:46:39 --> Config Class Initialized
INFO - 2023-01-13 11:46:39 --> Loader Class Initialized
INFO - 2023-01-13 11:46:39 --> Helper loaded: url_helper
INFO - 2023-01-13 11:46:39 --> Helper loaded: file_helper
INFO - 2023-01-13 11:46:39 --> Helper loaded: form_helper
INFO - 2023-01-13 11:46:39 --> Helper loaded: my_helper
INFO - 2023-01-13 11:46:39 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:46:39 --> Controller Class Initialized
DEBUG - 2023-01-13 11:46:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-13 11:46:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:46:39 --> Final output sent to browser
DEBUG - 2023-01-13 11:46:39 --> Total execution time: 0.0358
INFO - 2023-01-13 11:46:39 --> Config Class Initialized
INFO - 2023-01-13 11:46:39 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:46:39 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:46:39 --> Utf8 Class Initialized
INFO - 2023-01-13 11:46:39 --> URI Class Initialized
INFO - 2023-01-13 11:46:39 --> Router Class Initialized
INFO - 2023-01-13 11:46:39 --> Output Class Initialized
INFO - 2023-01-13 11:46:39 --> Security Class Initialized
DEBUG - 2023-01-13 11:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:46:39 --> Input Class Initialized
INFO - 2023-01-13 11:46:39 --> Language Class Initialized
INFO - 2023-01-13 11:46:39 --> Language Class Initialized
INFO - 2023-01-13 11:46:39 --> Config Class Initialized
INFO - 2023-01-13 11:46:39 --> Loader Class Initialized
INFO - 2023-01-13 11:46:39 --> Helper loaded: url_helper
INFO - 2023-01-13 11:46:39 --> Helper loaded: file_helper
INFO - 2023-01-13 11:46:39 --> Helper loaded: form_helper
INFO - 2023-01-13 11:46:39 --> Helper loaded: my_helper
INFO - 2023-01-13 11:46:39 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:46:39 --> Controller Class Initialized
INFO - 2023-01-13 11:46:40 --> Config Class Initialized
INFO - 2023-01-13 11:46:40 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:46:40 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:46:40 --> Utf8 Class Initialized
INFO - 2023-01-13 11:46:40 --> URI Class Initialized
INFO - 2023-01-13 11:46:40 --> Router Class Initialized
INFO - 2023-01-13 11:46:40 --> Output Class Initialized
INFO - 2023-01-13 11:46:40 --> Security Class Initialized
DEBUG - 2023-01-13 11:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:46:40 --> Input Class Initialized
INFO - 2023-01-13 11:46:40 --> Language Class Initialized
INFO - 2023-01-13 11:46:40 --> Language Class Initialized
INFO - 2023-01-13 11:46:40 --> Config Class Initialized
INFO - 2023-01-13 11:46:40 --> Loader Class Initialized
INFO - 2023-01-13 11:46:40 --> Helper loaded: url_helper
INFO - 2023-01-13 11:46:40 --> Helper loaded: file_helper
INFO - 2023-01-13 11:46:40 --> Helper loaded: form_helper
INFO - 2023-01-13 11:46:40 --> Helper loaded: my_helper
INFO - 2023-01-13 11:46:40 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:46:40 --> Controller Class Initialized
ERROR - 2023-01-13 11:46:40 --> Severity: Notice --> Undefined index: catatan C:\xampp\htdocs\myraportk13\application\modules\n_icb\controllers\N_icb.php 94
ERROR - 2023-01-13 11:46:40 --> Severity: Notice --> Undefined index: catatan C:\xampp\htdocs\myraportk13\application\modules\n_icb\controllers\N_icb.php 94
ERROR - 2023-01-13 11:46:40 --> Severity: Notice --> Undefined variable: q_siswa_kelas C:\xampp\htdocs\myraportk13\application\modules\n_icb\controllers\N_icb.php 115
ERROR - 2023-01-13 11:46:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\myraportk13\application\modules\n_icb\controllers\N_icb.php 115
DEBUG - 2023-01-13 11:46:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/cetak.php
INFO - 2023-01-13 11:46:40 --> Final output sent to browser
DEBUG - 2023-01-13 11:46:40 --> Total execution time: 0.0419
INFO - 2023-01-13 11:47:19 --> Config Class Initialized
INFO - 2023-01-13 11:47:19 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:47:19 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:47:19 --> Utf8 Class Initialized
INFO - 2023-01-13 11:47:19 --> URI Class Initialized
INFO - 2023-01-13 11:47:19 --> Router Class Initialized
INFO - 2023-01-13 11:47:19 --> Output Class Initialized
INFO - 2023-01-13 11:47:19 --> Security Class Initialized
DEBUG - 2023-01-13 11:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:47:19 --> Input Class Initialized
INFO - 2023-01-13 11:47:19 --> Language Class Initialized
INFO - 2023-01-13 11:47:19 --> Language Class Initialized
INFO - 2023-01-13 11:47:19 --> Config Class Initialized
INFO - 2023-01-13 11:47:19 --> Loader Class Initialized
INFO - 2023-01-13 11:47:19 --> Helper loaded: url_helper
INFO - 2023-01-13 11:47:19 --> Helper loaded: file_helper
INFO - 2023-01-13 11:47:19 --> Helper loaded: form_helper
INFO - 2023-01-13 11:47:19 --> Helper loaded: my_helper
INFO - 2023-01-13 11:47:19 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:47:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:47:19 --> Controller Class Initialized
ERROR - 2023-01-13 11:47:19 --> Severity: Notice --> Undefined variable: q_siswa_kelas C:\xampp\htdocs\myraportk13\application\modules\n_icb\controllers\N_icb.php 115
ERROR - 2023-01-13 11:47:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\myraportk13\application\modules\n_icb\controllers\N_icb.php 115
DEBUG - 2023-01-13 11:47:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/cetak.php
INFO - 2023-01-13 11:47:19 --> Final output sent to browser
DEBUG - 2023-01-13 11:47:19 --> Total execution time: 0.0484
INFO - 2023-01-13 11:47:25 --> Config Class Initialized
INFO - 2023-01-13 11:47:25 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:47:25 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:47:25 --> Utf8 Class Initialized
INFO - 2023-01-13 11:47:25 --> URI Class Initialized
INFO - 2023-01-13 11:47:25 --> Router Class Initialized
INFO - 2023-01-13 11:47:25 --> Output Class Initialized
INFO - 2023-01-13 11:47:25 --> Security Class Initialized
DEBUG - 2023-01-13 11:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:47:25 --> Input Class Initialized
INFO - 2023-01-13 11:47:25 --> Language Class Initialized
INFO - 2023-01-13 11:47:25 --> Language Class Initialized
INFO - 2023-01-13 11:47:25 --> Config Class Initialized
INFO - 2023-01-13 11:47:25 --> Loader Class Initialized
INFO - 2023-01-13 11:47:25 --> Helper loaded: url_helper
INFO - 2023-01-13 11:47:25 --> Helper loaded: file_helper
INFO - 2023-01-13 11:47:25 --> Helper loaded: form_helper
INFO - 2023-01-13 11:47:25 --> Helper loaded: my_helper
INFO - 2023-01-13 11:47:25 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:47:25 --> Controller Class Initialized
INFO - 2023-01-13 11:47:25 --> Final output sent to browser
DEBUG - 2023-01-13 11:47:25 --> Total execution time: 0.0291
INFO - 2023-01-13 11:47:26 --> Config Class Initialized
INFO - 2023-01-13 11:47:26 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:47:26 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:47:26 --> Utf8 Class Initialized
INFO - 2023-01-13 11:47:26 --> URI Class Initialized
INFO - 2023-01-13 11:47:26 --> Router Class Initialized
INFO - 2023-01-13 11:47:26 --> Output Class Initialized
INFO - 2023-01-13 11:47:26 --> Security Class Initialized
DEBUG - 2023-01-13 11:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:47:26 --> Input Class Initialized
INFO - 2023-01-13 11:47:26 --> Language Class Initialized
INFO - 2023-01-13 11:47:26 --> Language Class Initialized
INFO - 2023-01-13 11:47:26 --> Config Class Initialized
INFO - 2023-01-13 11:47:26 --> Loader Class Initialized
INFO - 2023-01-13 11:47:26 --> Helper loaded: url_helper
INFO - 2023-01-13 11:47:26 --> Helper loaded: file_helper
INFO - 2023-01-13 11:47:26 --> Helper loaded: form_helper
INFO - 2023-01-13 11:47:26 --> Helper loaded: my_helper
INFO - 2023-01-13 11:47:26 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:47:26 --> Controller Class Initialized
DEBUG - 2023-01-13 11:47:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-13 11:47:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:47:26 --> Final output sent to browser
DEBUG - 2023-01-13 11:47:26 --> Total execution time: 0.0503
INFO - 2023-01-13 11:47:26 --> Config Class Initialized
INFO - 2023-01-13 11:47:26 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:47:26 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:47:26 --> Utf8 Class Initialized
INFO - 2023-01-13 11:47:26 --> URI Class Initialized
INFO - 2023-01-13 11:47:26 --> Router Class Initialized
INFO - 2023-01-13 11:47:26 --> Output Class Initialized
INFO - 2023-01-13 11:47:26 --> Security Class Initialized
DEBUG - 2023-01-13 11:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:47:26 --> Input Class Initialized
INFO - 2023-01-13 11:47:26 --> Language Class Initialized
INFO - 2023-01-13 11:47:26 --> Language Class Initialized
INFO - 2023-01-13 11:47:26 --> Config Class Initialized
INFO - 2023-01-13 11:47:26 --> Loader Class Initialized
INFO - 2023-01-13 11:47:26 --> Helper loaded: url_helper
INFO - 2023-01-13 11:47:26 --> Helper loaded: file_helper
INFO - 2023-01-13 11:47:26 --> Helper loaded: form_helper
INFO - 2023-01-13 11:47:26 --> Helper loaded: my_helper
INFO - 2023-01-13 11:47:26 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:47:26 --> Controller Class Initialized
INFO - 2023-01-13 11:48:05 --> Config Class Initialized
INFO - 2023-01-13 11:48:05 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:48:05 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:48:05 --> Utf8 Class Initialized
INFO - 2023-01-13 11:48:05 --> URI Class Initialized
INFO - 2023-01-13 11:48:05 --> Router Class Initialized
INFO - 2023-01-13 11:48:05 --> Output Class Initialized
INFO - 2023-01-13 11:48:05 --> Security Class Initialized
DEBUG - 2023-01-13 11:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:48:05 --> Input Class Initialized
INFO - 2023-01-13 11:48:05 --> Language Class Initialized
INFO - 2023-01-13 11:48:05 --> Language Class Initialized
INFO - 2023-01-13 11:48:05 --> Config Class Initialized
INFO - 2023-01-13 11:48:05 --> Loader Class Initialized
INFO - 2023-01-13 11:48:05 --> Helper loaded: url_helper
INFO - 2023-01-13 11:48:05 --> Helper loaded: file_helper
INFO - 2023-01-13 11:48:05 --> Helper loaded: form_helper
INFO - 2023-01-13 11:48:05 --> Helper loaded: my_helper
INFO - 2023-01-13 11:48:05 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:48:05 --> Controller Class Initialized
DEBUG - 2023-01-13 11:48:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-13 11:48:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:48:05 --> Final output sent to browser
DEBUG - 2023-01-13 11:48:05 --> Total execution time: 0.0499
INFO - 2023-01-13 11:48:07 --> Config Class Initialized
INFO - 2023-01-13 11:48:07 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:48:07 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:48:07 --> Utf8 Class Initialized
INFO - 2023-01-13 11:48:07 --> URI Class Initialized
INFO - 2023-01-13 11:48:07 --> Router Class Initialized
INFO - 2023-01-13 11:48:07 --> Output Class Initialized
INFO - 2023-01-13 11:48:07 --> Security Class Initialized
DEBUG - 2023-01-13 11:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:48:07 --> Input Class Initialized
INFO - 2023-01-13 11:48:07 --> Language Class Initialized
INFO - 2023-01-13 11:48:07 --> Language Class Initialized
INFO - 2023-01-13 11:48:07 --> Config Class Initialized
INFO - 2023-01-13 11:48:07 --> Loader Class Initialized
INFO - 2023-01-13 11:48:07 --> Helper loaded: url_helper
INFO - 2023-01-13 11:48:07 --> Helper loaded: file_helper
INFO - 2023-01-13 11:48:07 --> Helper loaded: form_helper
INFO - 2023-01-13 11:48:07 --> Helper loaded: my_helper
INFO - 2023-01-13 11:48:07 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:48:07 --> Controller Class Initialized
INFO - 2023-01-13 11:48:07 --> Helper loaded: cookie_helper
INFO - 2023-01-13 11:48:07 --> Config Class Initialized
INFO - 2023-01-13 11:48:07 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:48:07 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:48:07 --> Utf8 Class Initialized
INFO - 2023-01-13 11:48:07 --> URI Class Initialized
INFO - 2023-01-13 11:48:07 --> Router Class Initialized
INFO - 2023-01-13 11:48:07 --> Output Class Initialized
INFO - 2023-01-13 11:48:07 --> Security Class Initialized
DEBUG - 2023-01-13 11:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:48:07 --> Input Class Initialized
INFO - 2023-01-13 11:48:07 --> Language Class Initialized
INFO - 2023-01-13 11:48:07 --> Language Class Initialized
INFO - 2023-01-13 11:48:07 --> Config Class Initialized
INFO - 2023-01-13 11:48:07 --> Loader Class Initialized
INFO - 2023-01-13 11:48:07 --> Helper loaded: url_helper
INFO - 2023-01-13 11:48:07 --> Helper loaded: file_helper
INFO - 2023-01-13 11:48:07 --> Helper loaded: form_helper
INFO - 2023-01-13 11:48:07 --> Helper loaded: my_helper
INFO - 2023-01-13 11:48:07 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:48:07 --> Controller Class Initialized
INFO - 2023-01-13 11:48:07 --> Config Class Initialized
INFO - 2023-01-13 11:48:07 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:48:07 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:48:07 --> Utf8 Class Initialized
INFO - 2023-01-13 11:48:07 --> URI Class Initialized
INFO - 2023-01-13 11:48:07 --> Router Class Initialized
INFO - 2023-01-13 11:48:07 --> Output Class Initialized
INFO - 2023-01-13 11:48:07 --> Security Class Initialized
DEBUG - 2023-01-13 11:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:48:07 --> Input Class Initialized
INFO - 2023-01-13 11:48:07 --> Language Class Initialized
INFO - 2023-01-13 11:48:07 --> Language Class Initialized
INFO - 2023-01-13 11:48:07 --> Config Class Initialized
INFO - 2023-01-13 11:48:07 --> Loader Class Initialized
INFO - 2023-01-13 11:48:07 --> Helper loaded: url_helper
INFO - 2023-01-13 11:48:07 --> Helper loaded: file_helper
INFO - 2023-01-13 11:48:07 --> Helper loaded: form_helper
INFO - 2023-01-13 11:48:07 --> Helper loaded: my_helper
INFO - 2023-01-13 11:48:07 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:48:07 --> Controller Class Initialized
DEBUG - 2023-01-13 11:48:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-13 11:48:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:48:07 --> Final output sent to browser
DEBUG - 2023-01-13 11:48:07 --> Total execution time: 0.0231
INFO - 2023-01-13 11:48:14 --> Config Class Initialized
INFO - 2023-01-13 11:48:14 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:48:14 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:48:14 --> Utf8 Class Initialized
INFO - 2023-01-13 11:48:14 --> URI Class Initialized
INFO - 2023-01-13 11:48:14 --> Router Class Initialized
INFO - 2023-01-13 11:48:14 --> Output Class Initialized
INFO - 2023-01-13 11:48:14 --> Security Class Initialized
DEBUG - 2023-01-13 11:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:48:14 --> Input Class Initialized
INFO - 2023-01-13 11:48:14 --> Language Class Initialized
INFO - 2023-01-13 11:48:14 --> Language Class Initialized
INFO - 2023-01-13 11:48:14 --> Config Class Initialized
INFO - 2023-01-13 11:48:14 --> Loader Class Initialized
INFO - 2023-01-13 11:48:14 --> Helper loaded: url_helper
INFO - 2023-01-13 11:48:14 --> Helper loaded: file_helper
INFO - 2023-01-13 11:48:14 --> Helper loaded: form_helper
INFO - 2023-01-13 11:48:14 --> Helper loaded: my_helper
INFO - 2023-01-13 11:48:14 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:48:14 --> Controller Class Initialized
INFO - 2023-01-13 11:48:14 --> Helper loaded: cookie_helper
INFO - 2023-01-13 11:48:14 --> Final output sent to browser
DEBUG - 2023-01-13 11:48:14 --> Total execution time: 0.0272
INFO - 2023-01-13 11:48:14 --> Config Class Initialized
INFO - 2023-01-13 11:48:14 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:48:14 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:48:14 --> Utf8 Class Initialized
INFO - 2023-01-13 11:48:14 --> URI Class Initialized
INFO - 2023-01-13 11:48:14 --> Router Class Initialized
INFO - 2023-01-13 11:48:14 --> Output Class Initialized
INFO - 2023-01-13 11:48:14 --> Security Class Initialized
DEBUG - 2023-01-13 11:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:48:14 --> Input Class Initialized
INFO - 2023-01-13 11:48:14 --> Language Class Initialized
INFO - 2023-01-13 11:48:14 --> Language Class Initialized
INFO - 2023-01-13 11:48:14 --> Config Class Initialized
INFO - 2023-01-13 11:48:14 --> Loader Class Initialized
INFO - 2023-01-13 11:48:14 --> Helper loaded: url_helper
INFO - 2023-01-13 11:48:14 --> Helper loaded: file_helper
INFO - 2023-01-13 11:48:14 --> Helper loaded: form_helper
INFO - 2023-01-13 11:48:14 --> Helper loaded: my_helper
INFO - 2023-01-13 11:48:14 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:48:14 --> Controller Class Initialized
DEBUG - 2023-01-13 11:48:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-13 11:48:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:48:14 --> Final output sent to browser
DEBUG - 2023-01-13 11:48:14 --> Total execution time: 0.0508
INFO - 2023-01-13 11:48:16 --> Config Class Initialized
INFO - 2023-01-13 11:48:16 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:48:16 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:48:16 --> Utf8 Class Initialized
INFO - 2023-01-13 11:48:16 --> URI Class Initialized
INFO - 2023-01-13 11:48:16 --> Router Class Initialized
INFO - 2023-01-13 11:48:16 --> Output Class Initialized
INFO - 2023-01-13 11:48:16 --> Security Class Initialized
DEBUG - 2023-01-13 11:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:48:16 --> Input Class Initialized
INFO - 2023-01-13 11:48:16 --> Language Class Initialized
INFO - 2023-01-13 11:48:16 --> Language Class Initialized
INFO - 2023-01-13 11:48:16 --> Config Class Initialized
INFO - 2023-01-13 11:48:16 --> Loader Class Initialized
INFO - 2023-01-13 11:48:16 --> Helper loaded: url_helper
INFO - 2023-01-13 11:48:16 --> Helper loaded: file_helper
INFO - 2023-01-13 11:48:16 --> Helper loaded: form_helper
INFO - 2023-01-13 11:48:16 --> Helper loaded: my_helper
INFO - 2023-01-13 11:48:16 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:48:16 --> Controller Class Initialized
DEBUG - 2023-01-13 11:48:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-13 11:48:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:48:16 --> Final output sent to browser
DEBUG - 2023-01-13 11:48:16 --> Total execution time: 0.0252
INFO - 2023-01-13 11:48:17 --> Config Class Initialized
INFO - 2023-01-13 11:48:17 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:48:17 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:48:17 --> Utf8 Class Initialized
INFO - 2023-01-13 11:48:17 --> URI Class Initialized
INFO - 2023-01-13 11:48:17 --> Router Class Initialized
INFO - 2023-01-13 11:48:17 --> Output Class Initialized
INFO - 2023-01-13 11:48:17 --> Security Class Initialized
DEBUG - 2023-01-13 11:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:48:17 --> Input Class Initialized
INFO - 2023-01-13 11:48:17 --> Language Class Initialized
INFO - 2023-01-13 11:48:17 --> Language Class Initialized
INFO - 2023-01-13 11:48:17 --> Config Class Initialized
INFO - 2023-01-13 11:48:17 --> Loader Class Initialized
INFO - 2023-01-13 11:48:17 --> Helper loaded: url_helper
INFO - 2023-01-13 11:48:17 --> Helper loaded: file_helper
INFO - 2023-01-13 11:48:17 --> Helper loaded: form_helper
INFO - 2023-01-13 11:48:17 --> Helper loaded: my_helper
INFO - 2023-01-13 11:48:17 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:48:17 --> Controller Class Initialized
DEBUG - 2023-01-13 11:48:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-01-13 11:48:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:48:17 --> Final output sent to browser
DEBUG - 2023-01-13 11:48:17 --> Total execution time: 0.0253
INFO - 2023-01-13 11:48:18 --> Config Class Initialized
INFO - 2023-01-13 11:48:18 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:48:18 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:48:18 --> Utf8 Class Initialized
INFO - 2023-01-13 11:48:18 --> URI Class Initialized
INFO - 2023-01-13 11:48:18 --> Router Class Initialized
INFO - 2023-01-13 11:48:18 --> Output Class Initialized
INFO - 2023-01-13 11:48:18 --> Security Class Initialized
DEBUG - 2023-01-13 11:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:48:18 --> Input Class Initialized
INFO - 2023-01-13 11:48:18 --> Language Class Initialized
INFO - 2023-01-13 11:48:18 --> Language Class Initialized
INFO - 2023-01-13 11:48:18 --> Config Class Initialized
INFO - 2023-01-13 11:48:18 --> Loader Class Initialized
INFO - 2023-01-13 11:48:18 --> Helper loaded: url_helper
INFO - 2023-01-13 11:48:18 --> Helper loaded: file_helper
INFO - 2023-01-13 11:48:18 --> Helper loaded: form_helper
INFO - 2023-01-13 11:48:18 --> Helper loaded: my_helper
INFO - 2023-01-13 11:48:18 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:48:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:48:18 --> Controller Class Initialized
DEBUG - 2023-01-13 11:48:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/cetak.php
INFO - 2023-01-13 11:48:18 --> Final output sent to browser
DEBUG - 2023-01-13 11:48:18 --> Total execution time: 0.0431
INFO - 2023-01-13 11:48:24 --> Config Class Initialized
INFO - 2023-01-13 11:48:24 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:48:24 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:48:24 --> Utf8 Class Initialized
INFO - 2023-01-13 11:48:24 --> URI Class Initialized
INFO - 2023-01-13 11:48:24 --> Router Class Initialized
INFO - 2023-01-13 11:48:24 --> Output Class Initialized
INFO - 2023-01-13 11:48:24 --> Security Class Initialized
DEBUG - 2023-01-13 11:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:48:24 --> Input Class Initialized
INFO - 2023-01-13 11:48:24 --> Language Class Initialized
INFO - 2023-01-13 11:48:24 --> Language Class Initialized
INFO - 2023-01-13 11:48:24 --> Config Class Initialized
INFO - 2023-01-13 11:48:24 --> Loader Class Initialized
INFO - 2023-01-13 11:48:24 --> Helper loaded: url_helper
INFO - 2023-01-13 11:48:24 --> Helper loaded: file_helper
INFO - 2023-01-13 11:48:24 --> Helper loaded: form_helper
INFO - 2023-01-13 11:48:24 --> Helper loaded: my_helper
INFO - 2023-01-13 11:48:24 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:48:24 --> Controller Class Initialized
INFO - 2023-01-13 11:48:24 --> Final output sent to browser
DEBUG - 2023-01-13 11:48:24 --> Total execution time: 0.0394
INFO - 2023-01-13 11:48:29 --> Config Class Initialized
INFO - 2023-01-13 11:48:29 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:48:29 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:48:29 --> Utf8 Class Initialized
INFO - 2023-01-13 11:48:29 --> URI Class Initialized
INFO - 2023-01-13 11:48:29 --> Router Class Initialized
INFO - 2023-01-13 11:48:29 --> Output Class Initialized
INFO - 2023-01-13 11:48:29 --> Security Class Initialized
DEBUG - 2023-01-13 11:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:48:29 --> Input Class Initialized
INFO - 2023-01-13 11:48:29 --> Language Class Initialized
INFO - 2023-01-13 11:48:29 --> Language Class Initialized
INFO - 2023-01-13 11:48:29 --> Config Class Initialized
INFO - 2023-01-13 11:48:29 --> Loader Class Initialized
INFO - 2023-01-13 11:48:29 --> Helper loaded: url_helper
INFO - 2023-01-13 11:48:29 --> Helper loaded: file_helper
INFO - 2023-01-13 11:48:29 --> Helper loaded: form_helper
INFO - 2023-01-13 11:48:29 --> Helper loaded: my_helper
INFO - 2023-01-13 11:48:29 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:48:29 --> Controller Class Initialized
DEBUG - 2023-01-13 11:48:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/cetak.php
INFO - 2023-01-13 11:48:29 --> Final output sent to browser
DEBUG - 2023-01-13 11:48:29 --> Total execution time: 0.0445
INFO - 2023-01-13 11:48:32 --> Config Class Initialized
INFO - 2023-01-13 11:48:32 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:48:32 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:48:32 --> Utf8 Class Initialized
INFO - 2023-01-13 11:48:32 --> URI Class Initialized
INFO - 2023-01-13 11:48:32 --> Router Class Initialized
INFO - 2023-01-13 11:48:32 --> Output Class Initialized
INFO - 2023-01-13 11:48:32 --> Security Class Initialized
DEBUG - 2023-01-13 11:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:48:32 --> Input Class Initialized
INFO - 2023-01-13 11:48:32 --> Language Class Initialized
INFO - 2023-01-13 11:48:32 --> Language Class Initialized
INFO - 2023-01-13 11:48:32 --> Config Class Initialized
INFO - 2023-01-13 11:48:32 --> Loader Class Initialized
INFO - 2023-01-13 11:48:32 --> Helper loaded: url_helper
INFO - 2023-01-13 11:48:32 --> Helper loaded: file_helper
INFO - 2023-01-13 11:48:32 --> Helper loaded: form_helper
INFO - 2023-01-13 11:48:32 --> Helper loaded: my_helper
INFO - 2023-01-13 11:48:32 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:48:32 --> Controller Class Initialized
INFO - 2023-01-13 11:48:32 --> Helper loaded: cookie_helper
INFO - 2023-01-13 11:48:32 --> Config Class Initialized
INFO - 2023-01-13 11:48:32 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:48:32 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:48:32 --> Utf8 Class Initialized
INFO - 2023-01-13 11:48:32 --> URI Class Initialized
INFO - 2023-01-13 11:48:32 --> Router Class Initialized
INFO - 2023-01-13 11:48:32 --> Output Class Initialized
INFO - 2023-01-13 11:48:32 --> Security Class Initialized
DEBUG - 2023-01-13 11:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:48:32 --> Input Class Initialized
INFO - 2023-01-13 11:48:32 --> Language Class Initialized
INFO - 2023-01-13 11:48:32 --> Language Class Initialized
INFO - 2023-01-13 11:48:32 --> Config Class Initialized
INFO - 2023-01-13 11:48:32 --> Loader Class Initialized
INFO - 2023-01-13 11:48:32 --> Helper loaded: url_helper
INFO - 2023-01-13 11:48:32 --> Helper loaded: file_helper
INFO - 2023-01-13 11:48:32 --> Helper loaded: form_helper
INFO - 2023-01-13 11:48:32 --> Helper loaded: my_helper
INFO - 2023-01-13 11:48:32 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:48:32 --> Controller Class Initialized
INFO - 2023-01-13 11:48:32 --> Config Class Initialized
INFO - 2023-01-13 11:48:32 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:48:32 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:48:32 --> Utf8 Class Initialized
INFO - 2023-01-13 11:48:32 --> URI Class Initialized
INFO - 2023-01-13 11:48:32 --> Router Class Initialized
INFO - 2023-01-13 11:48:32 --> Output Class Initialized
INFO - 2023-01-13 11:48:32 --> Security Class Initialized
DEBUG - 2023-01-13 11:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:48:32 --> Input Class Initialized
INFO - 2023-01-13 11:48:32 --> Language Class Initialized
INFO - 2023-01-13 11:48:32 --> Language Class Initialized
INFO - 2023-01-13 11:48:32 --> Config Class Initialized
INFO - 2023-01-13 11:48:32 --> Loader Class Initialized
INFO - 2023-01-13 11:48:32 --> Helper loaded: url_helper
INFO - 2023-01-13 11:48:32 --> Helper loaded: file_helper
INFO - 2023-01-13 11:48:32 --> Helper loaded: form_helper
INFO - 2023-01-13 11:48:32 --> Helper loaded: my_helper
INFO - 2023-01-13 11:48:32 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:48:32 --> Controller Class Initialized
DEBUG - 2023-01-13 11:48:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-13 11:48:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:48:32 --> Final output sent to browser
DEBUG - 2023-01-13 11:48:32 --> Total execution time: 0.0424
INFO - 2023-01-13 11:48:36 --> Config Class Initialized
INFO - 2023-01-13 11:48:36 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:48:36 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:48:36 --> Utf8 Class Initialized
INFO - 2023-01-13 11:48:36 --> URI Class Initialized
INFO - 2023-01-13 11:48:36 --> Router Class Initialized
INFO - 2023-01-13 11:48:36 --> Output Class Initialized
INFO - 2023-01-13 11:48:36 --> Security Class Initialized
DEBUG - 2023-01-13 11:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:48:36 --> Input Class Initialized
INFO - 2023-01-13 11:48:36 --> Language Class Initialized
INFO - 2023-01-13 11:48:36 --> Language Class Initialized
INFO - 2023-01-13 11:48:36 --> Config Class Initialized
INFO - 2023-01-13 11:48:36 --> Loader Class Initialized
INFO - 2023-01-13 11:48:36 --> Helper loaded: url_helper
INFO - 2023-01-13 11:48:36 --> Helper loaded: file_helper
INFO - 2023-01-13 11:48:36 --> Helper loaded: form_helper
INFO - 2023-01-13 11:48:36 --> Helper loaded: my_helper
INFO - 2023-01-13 11:48:36 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:48:36 --> Controller Class Initialized
INFO - 2023-01-13 11:48:36 --> Helper loaded: cookie_helper
INFO - 2023-01-13 11:48:36 --> Final output sent to browser
DEBUG - 2023-01-13 11:48:36 --> Total execution time: 0.0242
INFO - 2023-01-13 11:48:36 --> Config Class Initialized
INFO - 2023-01-13 11:48:36 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:48:36 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:48:36 --> Utf8 Class Initialized
INFO - 2023-01-13 11:48:36 --> URI Class Initialized
INFO - 2023-01-13 11:48:36 --> Router Class Initialized
INFO - 2023-01-13 11:48:36 --> Output Class Initialized
INFO - 2023-01-13 11:48:36 --> Security Class Initialized
DEBUG - 2023-01-13 11:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:48:36 --> Input Class Initialized
INFO - 2023-01-13 11:48:36 --> Language Class Initialized
INFO - 2023-01-13 11:48:36 --> Language Class Initialized
INFO - 2023-01-13 11:48:36 --> Config Class Initialized
INFO - 2023-01-13 11:48:36 --> Loader Class Initialized
INFO - 2023-01-13 11:48:36 --> Helper loaded: url_helper
INFO - 2023-01-13 11:48:36 --> Helper loaded: file_helper
INFO - 2023-01-13 11:48:36 --> Helper loaded: form_helper
INFO - 2023-01-13 11:48:36 --> Helper loaded: my_helper
INFO - 2023-01-13 11:48:36 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:48:36 --> Controller Class Initialized
DEBUG - 2023-01-13 11:48:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-13 11:48:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:48:36 --> Final output sent to browser
DEBUG - 2023-01-13 11:48:36 --> Total execution time: 0.0260
INFO - 2023-01-13 11:48:38 --> Config Class Initialized
INFO - 2023-01-13 11:48:38 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:48:38 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:48:38 --> Utf8 Class Initialized
INFO - 2023-01-13 11:48:38 --> URI Class Initialized
INFO - 2023-01-13 11:48:38 --> Router Class Initialized
INFO - 2023-01-13 11:48:38 --> Output Class Initialized
INFO - 2023-01-13 11:48:38 --> Security Class Initialized
DEBUG - 2023-01-13 11:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:48:38 --> Input Class Initialized
INFO - 2023-01-13 11:48:38 --> Language Class Initialized
INFO - 2023-01-13 11:48:38 --> Language Class Initialized
INFO - 2023-01-13 11:48:38 --> Config Class Initialized
INFO - 2023-01-13 11:48:38 --> Loader Class Initialized
INFO - 2023-01-13 11:48:38 --> Helper loaded: url_helper
INFO - 2023-01-13 11:48:38 --> Helper loaded: file_helper
INFO - 2023-01-13 11:48:38 --> Helper loaded: form_helper
INFO - 2023-01-13 11:48:38 --> Helper loaded: my_helper
INFO - 2023-01-13 11:48:38 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:48:38 --> Controller Class Initialized
DEBUG - 2023-01-13 11:48:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-13 11:48:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:48:38 --> Final output sent to browser
DEBUG - 2023-01-13 11:48:38 --> Total execution time: 0.0250
INFO - 2023-01-13 11:48:40 --> Config Class Initialized
INFO - 2023-01-13 11:48:40 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:48:40 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:48:40 --> Utf8 Class Initialized
INFO - 2023-01-13 11:48:40 --> URI Class Initialized
INFO - 2023-01-13 11:48:40 --> Router Class Initialized
INFO - 2023-01-13 11:48:40 --> Output Class Initialized
INFO - 2023-01-13 11:48:40 --> Security Class Initialized
DEBUG - 2023-01-13 11:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:48:40 --> Input Class Initialized
INFO - 2023-01-13 11:48:40 --> Language Class Initialized
INFO - 2023-01-13 11:48:40 --> Language Class Initialized
INFO - 2023-01-13 11:48:40 --> Config Class Initialized
INFO - 2023-01-13 11:48:40 --> Loader Class Initialized
INFO - 2023-01-13 11:48:40 --> Helper loaded: url_helper
INFO - 2023-01-13 11:48:40 --> Helper loaded: file_helper
INFO - 2023-01-13 11:48:40 --> Helper loaded: form_helper
INFO - 2023-01-13 11:48:40 --> Helper loaded: my_helper
INFO - 2023-01-13 11:48:40 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:48:40 --> Controller Class Initialized
DEBUG - 2023-01-13 11:48:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-13 11:48:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:48:40 --> Final output sent to browser
DEBUG - 2023-01-13 11:48:40 --> Total execution time: 0.0408
INFO - 2023-01-13 11:48:40 --> Config Class Initialized
INFO - 2023-01-13 11:48:40 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:48:40 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:48:40 --> Utf8 Class Initialized
INFO - 2023-01-13 11:48:40 --> URI Class Initialized
INFO - 2023-01-13 11:48:40 --> Router Class Initialized
INFO - 2023-01-13 11:48:40 --> Output Class Initialized
INFO - 2023-01-13 11:48:40 --> Security Class Initialized
DEBUG - 2023-01-13 11:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:48:40 --> Input Class Initialized
INFO - 2023-01-13 11:48:40 --> Language Class Initialized
INFO - 2023-01-13 11:48:40 --> Language Class Initialized
INFO - 2023-01-13 11:48:40 --> Config Class Initialized
INFO - 2023-01-13 11:48:40 --> Loader Class Initialized
INFO - 2023-01-13 11:48:40 --> Helper loaded: url_helper
INFO - 2023-01-13 11:48:40 --> Helper loaded: file_helper
INFO - 2023-01-13 11:48:40 --> Helper loaded: form_helper
INFO - 2023-01-13 11:48:40 --> Helper loaded: my_helper
INFO - 2023-01-13 11:48:40 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:48:40 --> Controller Class Initialized
INFO - 2023-01-13 11:48:42 --> Config Class Initialized
INFO - 2023-01-13 11:48:42 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:48:42 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:48:42 --> Utf8 Class Initialized
INFO - 2023-01-13 11:48:42 --> URI Class Initialized
INFO - 2023-01-13 11:48:42 --> Router Class Initialized
INFO - 2023-01-13 11:48:42 --> Output Class Initialized
INFO - 2023-01-13 11:48:42 --> Security Class Initialized
DEBUG - 2023-01-13 11:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:48:42 --> Input Class Initialized
INFO - 2023-01-13 11:48:42 --> Language Class Initialized
INFO - 2023-01-13 11:48:42 --> Language Class Initialized
INFO - 2023-01-13 11:48:42 --> Config Class Initialized
INFO - 2023-01-13 11:48:42 --> Loader Class Initialized
INFO - 2023-01-13 11:48:42 --> Helper loaded: url_helper
INFO - 2023-01-13 11:48:42 --> Helper loaded: file_helper
INFO - 2023-01-13 11:48:42 --> Helper loaded: form_helper
INFO - 2023-01-13 11:48:42 --> Helper loaded: my_helper
INFO - 2023-01-13 11:48:42 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:48:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:48:42 --> Controller Class Initialized
ERROR - 2023-01-13 11:48:42 --> Severity: Notice --> Undefined variable: q_siswa_kelas C:\xampp\htdocs\myraportk13\application\modules\n_icb\controllers\N_icb.php 115
ERROR - 2023-01-13 11:48:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\myraportk13\application\modules\n_icb\controllers\N_icb.php 115
DEBUG - 2023-01-13 11:48:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/cetak.php
INFO - 2023-01-13 11:48:42 --> Final output sent to browser
DEBUG - 2023-01-13 11:48:42 --> Total execution time: 0.0432
INFO - 2023-01-13 11:49:32 --> Config Class Initialized
INFO - 2023-01-13 11:49:32 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:49:32 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:49:32 --> Utf8 Class Initialized
INFO - 2023-01-13 11:49:32 --> URI Class Initialized
INFO - 2023-01-13 11:49:32 --> Router Class Initialized
INFO - 2023-01-13 11:49:32 --> Output Class Initialized
INFO - 2023-01-13 11:49:32 --> Security Class Initialized
DEBUG - 2023-01-13 11:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:49:32 --> Input Class Initialized
INFO - 2023-01-13 11:49:32 --> Language Class Initialized
INFO - 2023-01-13 11:49:32 --> Language Class Initialized
INFO - 2023-01-13 11:49:32 --> Config Class Initialized
INFO - 2023-01-13 11:49:32 --> Loader Class Initialized
INFO - 2023-01-13 11:49:32 --> Helper loaded: url_helper
INFO - 2023-01-13 11:49:32 --> Helper loaded: file_helper
INFO - 2023-01-13 11:49:32 --> Helper loaded: form_helper
INFO - 2023-01-13 11:49:32 --> Helper loaded: my_helper
INFO - 2023-01-13 11:49:32 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:49:32 --> Controller Class Initialized
DEBUG - 2023-01-13 11:49:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/cetak.php
INFO - 2023-01-13 11:49:32 --> Final output sent to browser
DEBUG - 2023-01-13 11:49:32 --> Total execution time: 0.0368
INFO - 2023-01-13 11:49:40 --> Config Class Initialized
INFO - 2023-01-13 11:49:40 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:49:40 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:49:40 --> Utf8 Class Initialized
INFO - 2023-01-13 11:49:40 --> URI Class Initialized
INFO - 2023-01-13 11:49:40 --> Router Class Initialized
INFO - 2023-01-13 11:49:40 --> Output Class Initialized
INFO - 2023-01-13 11:49:40 --> Security Class Initialized
DEBUG - 2023-01-13 11:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:49:40 --> Input Class Initialized
INFO - 2023-01-13 11:49:40 --> Language Class Initialized
INFO - 2023-01-13 11:49:40 --> Language Class Initialized
INFO - 2023-01-13 11:49:40 --> Config Class Initialized
INFO - 2023-01-13 11:49:40 --> Loader Class Initialized
INFO - 2023-01-13 11:49:40 --> Helper loaded: url_helper
INFO - 2023-01-13 11:49:40 --> Helper loaded: file_helper
INFO - 2023-01-13 11:49:40 --> Helper loaded: form_helper
INFO - 2023-01-13 11:49:40 --> Helper loaded: my_helper
INFO - 2023-01-13 11:49:40 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:49:40 --> Controller Class Initialized
INFO - 2023-01-13 11:49:40 --> Final output sent to browser
DEBUG - 2023-01-13 11:49:40 --> Total execution time: 0.0440
INFO - 2023-01-13 11:49:43 --> Config Class Initialized
INFO - 2023-01-13 11:49:43 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:49:43 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:49:43 --> Utf8 Class Initialized
INFO - 2023-01-13 11:49:43 --> URI Class Initialized
INFO - 2023-01-13 11:49:43 --> Router Class Initialized
INFO - 2023-01-13 11:49:43 --> Output Class Initialized
INFO - 2023-01-13 11:49:43 --> Security Class Initialized
DEBUG - 2023-01-13 11:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:49:43 --> Input Class Initialized
INFO - 2023-01-13 11:49:43 --> Language Class Initialized
INFO - 2023-01-13 11:49:43 --> Language Class Initialized
INFO - 2023-01-13 11:49:43 --> Config Class Initialized
INFO - 2023-01-13 11:49:43 --> Loader Class Initialized
INFO - 2023-01-13 11:49:43 --> Helper loaded: url_helper
INFO - 2023-01-13 11:49:43 --> Helper loaded: file_helper
INFO - 2023-01-13 11:49:43 --> Helper loaded: form_helper
INFO - 2023-01-13 11:49:43 --> Helper loaded: my_helper
INFO - 2023-01-13 11:49:43 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:49:43 --> Controller Class Initialized
INFO - 2023-01-13 11:49:43 --> Final output sent to browser
DEBUG - 2023-01-13 11:49:43 --> Total execution time: 0.0328
INFO - 2023-01-13 11:49:46 --> Config Class Initialized
INFO - 2023-01-13 11:49:46 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:49:46 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:49:46 --> Utf8 Class Initialized
INFO - 2023-01-13 11:49:46 --> URI Class Initialized
INFO - 2023-01-13 11:49:46 --> Router Class Initialized
INFO - 2023-01-13 11:49:46 --> Output Class Initialized
INFO - 2023-01-13 11:49:46 --> Security Class Initialized
DEBUG - 2023-01-13 11:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:49:46 --> Input Class Initialized
INFO - 2023-01-13 11:49:46 --> Language Class Initialized
INFO - 2023-01-13 11:49:46 --> Language Class Initialized
INFO - 2023-01-13 11:49:46 --> Config Class Initialized
INFO - 2023-01-13 11:49:46 --> Loader Class Initialized
INFO - 2023-01-13 11:49:46 --> Helper loaded: url_helper
INFO - 2023-01-13 11:49:46 --> Helper loaded: file_helper
INFO - 2023-01-13 11:49:46 --> Helper loaded: form_helper
INFO - 2023-01-13 11:49:46 --> Helper loaded: my_helper
INFO - 2023-01-13 11:49:46 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:49:46 --> Controller Class Initialized
DEBUG - 2023-01-13 11:49:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/cetak.php
INFO - 2023-01-13 11:49:46 --> Final output sent to browser
DEBUG - 2023-01-13 11:49:46 --> Total execution time: 0.0539
INFO - 2023-01-13 11:50:27 --> Config Class Initialized
INFO - 2023-01-13 11:50:27 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:50:27 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:50:27 --> Utf8 Class Initialized
INFO - 2023-01-13 11:50:27 --> URI Class Initialized
INFO - 2023-01-13 11:50:27 --> Router Class Initialized
INFO - 2023-01-13 11:50:27 --> Output Class Initialized
INFO - 2023-01-13 11:50:27 --> Security Class Initialized
DEBUG - 2023-01-13 11:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:50:27 --> Input Class Initialized
INFO - 2023-01-13 11:50:27 --> Language Class Initialized
INFO - 2023-01-13 11:50:27 --> Language Class Initialized
INFO - 2023-01-13 11:50:27 --> Config Class Initialized
INFO - 2023-01-13 11:50:27 --> Loader Class Initialized
INFO - 2023-01-13 11:50:27 --> Helper loaded: url_helper
INFO - 2023-01-13 11:50:27 --> Helper loaded: file_helper
INFO - 2023-01-13 11:50:27 --> Helper loaded: form_helper
INFO - 2023-01-13 11:50:27 --> Helper loaded: my_helper
INFO - 2023-01-13 11:50:27 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:50:27 --> Controller Class Initialized
DEBUG - 2023-01-13 11:50:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-13 11:50:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-13 11:50:27 --> Final output sent to browser
DEBUG - 2023-01-13 11:50:27 --> Total execution time: 0.0260
INFO - 2023-01-13 11:50:27 --> Config Class Initialized
INFO - 2023-01-13 11:50:27 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:50:27 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:50:27 --> Utf8 Class Initialized
INFO - 2023-01-13 11:50:27 --> URI Class Initialized
INFO - 2023-01-13 11:50:27 --> Router Class Initialized
INFO - 2023-01-13 11:50:27 --> Output Class Initialized
INFO - 2023-01-13 11:50:27 --> Security Class Initialized
DEBUG - 2023-01-13 11:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:50:27 --> Input Class Initialized
INFO - 2023-01-13 11:50:27 --> Language Class Initialized
INFO - 2023-01-13 11:50:27 --> Language Class Initialized
INFO - 2023-01-13 11:50:27 --> Config Class Initialized
INFO - 2023-01-13 11:50:27 --> Loader Class Initialized
INFO - 2023-01-13 11:50:27 --> Helper loaded: url_helper
INFO - 2023-01-13 11:50:27 --> Helper loaded: file_helper
INFO - 2023-01-13 11:50:27 --> Helper loaded: form_helper
INFO - 2023-01-13 11:50:27 --> Helper loaded: my_helper
INFO - 2023-01-13 11:50:27 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:50:27 --> Controller Class Initialized
INFO - 2023-01-13 11:50:28 --> Config Class Initialized
INFO - 2023-01-13 11:50:28 --> Hooks Class Initialized
DEBUG - 2023-01-13 11:50:28 --> UTF-8 Support Enabled
INFO - 2023-01-13 11:50:28 --> Utf8 Class Initialized
INFO - 2023-01-13 11:50:28 --> URI Class Initialized
INFO - 2023-01-13 11:50:28 --> Router Class Initialized
INFO - 2023-01-13 11:50:28 --> Output Class Initialized
INFO - 2023-01-13 11:50:28 --> Security Class Initialized
DEBUG - 2023-01-13 11:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 11:50:28 --> Input Class Initialized
INFO - 2023-01-13 11:50:28 --> Language Class Initialized
INFO - 2023-01-13 11:50:28 --> Language Class Initialized
INFO - 2023-01-13 11:50:28 --> Config Class Initialized
INFO - 2023-01-13 11:50:28 --> Loader Class Initialized
INFO - 2023-01-13 11:50:28 --> Helper loaded: url_helper
INFO - 2023-01-13 11:50:28 --> Helper loaded: file_helper
INFO - 2023-01-13 11:50:28 --> Helper loaded: form_helper
INFO - 2023-01-13 11:50:28 --> Helper loaded: my_helper
INFO - 2023-01-13 11:50:28 --> Database Driver Class Initialized
DEBUG - 2023-01-13 11:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-13 11:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-13 11:50:28 --> Controller Class Initialized
INFO - 2023-01-13 11:50:29 --> Final output sent to browser
DEBUG - 2023-01-13 11:50:29 --> Total execution time: 0.0482
