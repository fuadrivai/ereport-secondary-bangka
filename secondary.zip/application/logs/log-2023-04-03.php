<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-04-03 08:54:15 --> Config Class Initialized
INFO - 2023-04-03 08:54:15 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:54:15 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:54:15 --> Utf8 Class Initialized
INFO - 2023-04-03 08:54:15 --> URI Class Initialized
INFO - 2023-04-03 08:54:15 --> Router Class Initialized
INFO - 2023-04-03 08:54:15 --> Output Class Initialized
INFO - 2023-04-03 08:54:15 --> Security Class Initialized
DEBUG - 2023-04-03 08:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:54:15 --> Input Class Initialized
INFO - 2023-04-03 08:54:15 --> Language Class Initialized
INFO - 2023-04-03 08:54:15 --> Language Class Initialized
INFO - 2023-04-03 08:54:15 --> Config Class Initialized
INFO - 2023-04-03 08:54:15 --> Loader Class Initialized
INFO - 2023-04-03 08:54:15 --> Helper loaded: url_helper
INFO - 2023-04-03 08:54:15 --> Helper loaded: file_helper
INFO - 2023-04-03 08:54:15 --> Helper loaded: form_helper
INFO - 2023-04-03 08:54:15 --> Helper loaded: my_helper
INFO - 2023-04-03 08:54:16 --> Database Driver Class Initialized
ERROR - 2023-04-03 08:54:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\myraportk13\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2023-04-03 08:54:20 --> Unable to connect to the database
INFO - 2023-04-03 08:54:20 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 08:54:30 --> Config Class Initialized
INFO - 2023-04-03 08:54:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:54:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:54:30 --> Utf8 Class Initialized
INFO - 2023-04-03 08:54:30 --> URI Class Initialized
INFO - 2023-04-03 08:54:30 --> Router Class Initialized
INFO - 2023-04-03 08:54:30 --> Output Class Initialized
INFO - 2023-04-03 08:54:30 --> Security Class Initialized
DEBUG - 2023-04-03 08:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:54:30 --> Input Class Initialized
INFO - 2023-04-03 08:54:30 --> Language Class Initialized
INFO - 2023-04-03 08:54:30 --> Language Class Initialized
INFO - 2023-04-03 08:54:30 --> Config Class Initialized
INFO - 2023-04-03 08:54:30 --> Loader Class Initialized
INFO - 2023-04-03 08:54:30 --> Helper loaded: url_helper
INFO - 2023-04-03 08:54:30 --> Helper loaded: file_helper
INFO - 2023-04-03 08:54:30 --> Helper loaded: form_helper
INFO - 2023-04-03 08:54:30 --> Helper loaded: my_helper
INFO - 2023-04-03 08:54:30 --> Database Driver Class Initialized
DEBUG - 2023-04-03 08:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-03 08:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-03 08:54:30 --> Controller Class Initialized
DEBUG - 2023-04-03 08:54:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-04-03 08:54:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-03 08:54:30 --> Final output sent to browser
DEBUG - 2023-04-03 08:54:30 --> Total execution time: 0.3470
INFO - 2023-04-03 08:56:25 --> Config Class Initialized
INFO - 2023-04-03 08:56:25 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:56:25 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:56:25 --> Utf8 Class Initialized
INFO - 2023-04-03 08:56:25 --> URI Class Initialized
INFO - 2023-04-03 08:56:25 --> Router Class Initialized
INFO - 2023-04-03 08:56:25 --> Output Class Initialized
INFO - 2023-04-03 08:56:25 --> Security Class Initialized
DEBUG - 2023-04-03 08:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:56:25 --> Input Class Initialized
INFO - 2023-04-03 08:56:25 --> Language Class Initialized
INFO - 2023-04-03 08:56:25 --> Language Class Initialized
INFO - 2023-04-03 08:56:25 --> Config Class Initialized
INFO - 2023-04-03 08:56:25 --> Loader Class Initialized
INFO - 2023-04-03 08:56:25 --> Helper loaded: url_helper
INFO - 2023-04-03 08:56:25 --> Helper loaded: file_helper
INFO - 2023-04-03 08:56:25 --> Helper loaded: form_helper
INFO - 2023-04-03 08:56:25 --> Helper loaded: my_helper
INFO - 2023-04-03 08:56:25 --> Database Driver Class Initialized
DEBUG - 2023-04-03 08:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-03 08:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-03 08:56:25 --> Controller Class Initialized
INFO - 2023-04-03 08:56:25 --> Helper loaded: cookie_helper
INFO - 2023-04-03 08:56:25 --> Final output sent to browser
DEBUG - 2023-04-03 08:56:25 --> Total execution time: 0.1911
INFO - 2023-04-03 08:56:25 --> Config Class Initialized
INFO - 2023-04-03 08:56:25 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:56:25 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:56:25 --> Utf8 Class Initialized
INFO - 2023-04-03 08:56:25 --> URI Class Initialized
INFO - 2023-04-03 08:56:25 --> Router Class Initialized
INFO - 2023-04-03 08:56:25 --> Output Class Initialized
INFO - 2023-04-03 08:56:25 --> Security Class Initialized
DEBUG - 2023-04-03 08:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:56:25 --> Input Class Initialized
INFO - 2023-04-03 08:56:25 --> Language Class Initialized
INFO - 2023-04-03 08:56:25 --> Language Class Initialized
INFO - 2023-04-03 08:56:25 --> Config Class Initialized
INFO - 2023-04-03 08:56:25 --> Loader Class Initialized
INFO - 2023-04-03 08:56:25 --> Helper loaded: url_helper
INFO - 2023-04-03 08:56:25 --> Helper loaded: file_helper
INFO - 2023-04-03 08:56:25 --> Helper loaded: form_helper
INFO - 2023-04-03 08:56:25 --> Helper loaded: my_helper
INFO - 2023-04-03 08:56:25 --> Database Driver Class Initialized
DEBUG - 2023-04-03 08:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-03 08:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-03 08:56:25 --> Controller Class Initialized
DEBUG - 2023-04-03 08:56:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-04-03 08:56:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-03 08:56:25 --> Final output sent to browser
DEBUG - 2023-04-03 08:56:25 --> Total execution time: 0.2125
INFO - 2023-04-03 08:56:35 --> Config Class Initialized
INFO - 2023-04-03 08:56:35 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:56:35 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:56:35 --> Utf8 Class Initialized
INFO - 2023-04-03 08:56:35 --> URI Class Initialized
INFO - 2023-04-03 08:56:35 --> Router Class Initialized
INFO - 2023-04-03 08:56:35 --> Output Class Initialized
INFO - 2023-04-03 08:56:35 --> Security Class Initialized
DEBUG - 2023-04-03 08:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:56:35 --> Input Class Initialized
INFO - 2023-04-03 08:56:35 --> Language Class Initialized
INFO - 2023-04-03 08:56:35 --> Language Class Initialized
INFO - 2023-04-03 08:56:35 --> Config Class Initialized
INFO - 2023-04-03 08:56:35 --> Loader Class Initialized
INFO - 2023-04-03 08:56:35 --> Helper loaded: url_helper
INFO - 2023-04-03 08:56:35 --> Helper loaded: file_helper
INFO - 2023-04-03 08:56:35 --> Helper loaded: form_helper
INFO - 2023-04-03 08:56:35 --> Helper loaded: my_helper
INFO - 2023-04-03 08:56:35 --> Database Driver Class Initialized
DEBUG - 2023-04-03 08:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-03 08:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-03 08:56:35 --> Controller Class Initialized
DEBUG - 2023-04-03 08:56:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-04-03 08:56:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-03 08:56:35 --> Final output sent to browser
DEBUG - 2023-04-03 08:56:35 --> Total execution time: 0.1952
INFO - 2023-04-03 08:57:17 --> Config Class Initialized
INFO - 2023-04-03 08:57:17 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:57:17 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:57:17 --> Utf8 Class Initialized
INFO - 2023-04-03 08:57:17 --> URI Class Initialized
INFO - 2023-04-03 08:57:17 --> Router Class Initialized
INFO - 2023-04-03 08:57:17 --> Output Class Initialized
INFO - 2023-04-03 08:57:17 --> Security Class Initialized
DEBUG - 2023-04-03 08:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:57:17 --> Input Class Initialized
INFO - 2023-04-03 08:57:17 --> Language Class Initialized
INFO - 2023-04-03 08:57:17 --> Language Class Initialized
INFO - 2023-04-03 08:57:17 --> Config Class Initialized
INFO - 2023-04-03 08:57:17 --> Loader Class Initialized
INFO - 2023-04-03 08:57:17 --> Helper loaded: url_helper
INFO - 2023-04-03 08:57:17 --> Helper loaded: file_helper
INFO - 2023-04-03 08:57:17 --> Helper loaded: form_helper
INFO - 2023-04-03 08:57:17 --> Helper loaded: my_helper
INFO - 2023-04-03 08:57:17 --> Database Driver Class Initialized
DEBUG - 2023-04-03 08:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-03 08:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-03 08:57:17 --> Controller Class Initialized
DEBUG - 2023-04-03 08:57:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-04-03 08:57:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-03 08:57:17 --> Final output sent to browser
DEBUG - 2023-04-03 08:57:17 --> Total execution time: 0.1505
INFO - 2023-04-03 08:57:17 --> Config Class Initialized
INFO - 2023-04-03 08:57:17 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:57:17 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:57:17 --> Utf8 Class Initialized
INFO - 2023-04-03 08:57:17 --> URI Class Initialized
INFO - 2023-04-03 08:57:17 --> Router Class Initialized
INFO - 2023-04-03 08:57:17 --> Output Class Initialized
INFO - 2023-04-03 08:57:17 --> Security Class Initialized
DEBUG - 2023-04-03 08:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:57:17 --> Input Class Initialized
INFO - 2023-04-03 08:57:17 --> Language Class Initialized
INFO - 2023-04-03 08:57:17 --> Language Class Initialized
INFO - 2023-04-03 08:57:17 --> Config Class Initialized
INFO - 2023-04-03 08:57:17 --> Loader Class Initialized
INFO - 2023-04-03 08:57:17 --> Helper loaded: url_helper
INFO - 2023-04-03 08:57:17 --> Helper loaded: file_helper
INFO - 2023-04-03 08:57:17 --> Helper loaded: form_helper
INFO - 2023-04-03 08:57:17 --> Helper loaded: my_helper
INFO - 2023-04-03 08:57:17 --> Database Driver Class Initialized
DEBUG - 2023-04-03 08:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-03 08:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-03 08:57:17 --> Controller Class Initialized
INFO - 2023-04-03 08:57:29 --> Config Class Initialized
INFO - 2023-04-03 08:57:29 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:57:29 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:57:29 --> Utf8 Class Initialized
INFO - 2023-04-03 08:57:29 --> URI Class Initialized
INFO - 2023-04-03 08:57:29 --> Router Class Initialized
INFO - 2023-04-03 08:57:29 --> Output Class Initialized
INFO - 2023-04-03 08:57:29 --> Security Class Initialized
DEBUG - 2023-04-03 08:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:57:29 --> Input Class Initialized
INFO - 2023-04-03 08:57:29 --> Language Class Initialized
INFO - 2023-04-03 08:57:29 --> Language Class Initialized
INFO - 2023-04-03 08:57:29 --> Config Class Initialized
INFO - 2023-04-03 08:57:29 --> Loader Class Initialized
INFO - 2023-04-03 08:57:29 --> Helper loaded: url_helper
INFO - 2023-04-03 08:57:29 --> Helper loaded: file_helper
INFO - 2023-04-03 08:57:29 --> Helper loaded: form_helper
INFO - 2023-04-03 08:57:29 --> Helper loaded: my_helper
INFO - 2023-04-03 08:57:29 --> Database Driver Class Initialized
DEBUG - 2023-04-03 08:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-03 08:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-03 08:57:29 --> Controller Class Initialized
INFO - 2023-04-03 08:57:29 --> Final output sent to browser
DEBUG - 2023-04-03 08:57:29 --> Total execution time: 0.1196
INFO - 2023-04-03 08:57:39 --> Config Class Initialized
INFO - 2023-04-03 08:57:39 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:57:39 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:57:39 --> Utf8 Class Initialized
INFO - 2023-04-03 08:57:39 --> URI Class Initialized
INFO - 2023-04-03 08:57:39 --> Router Class Initialized
INFO - 2023-04-03 08:57:39 --> Output Class Initialized
INFO - 2023-04-03 08:57:39 --> Security Class Initialized
DEBUG - 2023-04-03 08:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:57:39 --> Input Class Initialized
INFO - 2023-04-03 08:57:39 --> Language Class Initialized
INFO - 2023-04-03 08:57:39 --> Language Class Initialized
INFO - 2023-04-03 08:57:39 --> Config Class Initialized
INFO - 2023-04-03 08:57:39 --> Loader Class Initialized
INFO - 2023-04-03 08:57:39 --> Helper loaded: url_helper
INFO - 2023-04-03 08:57:39 --> Helper loaded: file_helper
INFO - 2023-04-03 08:57:39 --> Helper loaded: form_helper
INFO - 2023-04-03 08:57:39 --> Helper loaded: my_helper
INFO - 2023-04-03 08:57:39 --> Database Driver Class Initialized
DEBUG - 2023-04-03 08:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-03 08:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-03 08:57:39 --> Controller Class Initialized
INFO - 2023-04-03 08:57:39 --> Final output sent to browser
DEBUG - 2023-04-03 08:57:39 --> Total execution time: 0.0629
INFO - 2023-04-03 08:57:41 --> Config Class Initialized
INFO - 2023-04-03 08:57:41 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:57:41 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:57:41 --> Utf8 Class Initialized
INFO - 2023-04-03 08:57:41 --> URI Class Initialized
INFO - 2023-04-03 08:57:41 --> Router Class Initialized
INFO - 2023-04-03 08:57:41 --> Output Class Initialized
INFO - 2023-04-03 08:57:41 --> Security Class Initialized
DEBUG - 2023-04-03 08:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:57:41 --> Input Class Initialized
INFO - 2023-04-03 08:57:41 --> Language Class Initialized
INFO - 2023-04-03 08:57:41 --> Language Class Initialized
INFO - 2023-04-03 08:57:41 --> Config Class Initialized
INFO - 2023-04-03 08:57:41 --> Loader Class Initialized
INFO - 2023-04-03 08:57:41 --> Helper loaded: url_helper
INFO - 2023-04-03 08:57:41 --> Helper loaded: file_helper
INFO - 2023-04-03 08:57:41 --> Helper loaded: form_helper
INFO - 2023-04-03 08:57:41 --> Helper loaded: my_helper
INFO - 2023-04-03 08:57:41 --> Database Driver Class Initialized
DEBUG - 2023-04-03 08:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-03 08:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-03 08:57:41 --> Controller Class Initialized
INFO - 2023-04-03 08:57:41 --> Final output sent to browser
DEBUG - 2023-04-03 08:57:41 --> Total execution time: 0.0383
INFO - 2023-04-03 08:57:51 --> Config Class Initialized
INFO - 2023-04-03 08:57:51 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:57:51 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:57:51 --> Utf8 Class Initialized
INFO - 2023-04-03 08:57:51 --> URI Class Initialized
INFO - 2023-04-03 08:57:51 --> Router Class Initialized
INFO - 2023-04-03 08:57:51 --> Output Class Initialized
INFO - 2023-04-03 08:57:51 --> Security Class Initialized
DEBUG - 2023-04-03 08:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:57:51 --> Input Class Initialized
INFO - 2023-04-03 08:57:51 --> Language Class Initialized
INFO - 2023-04-03 08:57:51 --> Language Class Initialized
INFO - 2023-04-03 08:57:51 --> Config Class Initialized
INFO - 2023-04-03 08:57:51 --> Loader Class Initialized
INFO - 2023-04-03 08:57:51 --> Helper loaded: url_helper
INFO - 2023-04-03 08:57:51 --> Helper loaded: file_helper
INFO - 2023-04-03 08:57:51 --> Helper loaded: form_helper
INFO - 2023-04-03 08:57:51 --> Helper loaded: my_helper
INFO - 2023-04-03 08:57:51 --> Database Driver Class Initialized
DEBUG - 2023-04-03 08:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-03 08:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-03 08:57:51 --> Controller Class Initialized
INFO - 2023-04-03 08:57:51 --> Final output sent to browser
DEBUG - 2023-04-03 08:57:51 --> Total execution time: 0.0521
INFO - 2023-04-03 08:57:51 --> Config Class Initialized
INFO - 2023-04-03 08:57:51 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:57:51 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:57:51 --> Utf8 Class Initialized
INFO - 2023-04-03 08:57:51 --> URI Class Initialized
INFO - 2023-04-03 08:57:51 --> Router Class Initialized
INFO - 2023-04-03 08:57:51 --> Output Class Initialized
INFO - 2023-04-03 08:57:51 --> Security Class Initialized
DEBUG - 2023-04-03 08:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:57:51 --> Input Class Initialized
INFO - 2023-04-03 08:57:51 --> Language Class Initialized
INFO - 2023-04-03 08:57:51 --> Language Class Initialized
INFO - 2023-04-03 08:57:51 --> Config Class Initialized
INFO - 2023-04-03 08:57:51 --> Loader Class Initialized
INFO - 2023-04-03 08:57:51 --> Helper loaded: url_helper
INFO - 2023-04-03 08:57:51 --> Helper loaded: file_helper
INFO - 2023-04-03 08:57:51 --> Helper loaded: form_helper
INFO - 2023-04-03 08:57:51 --> Helper loaded: my_helper
INFO - 2023-04-03 08:57:51 --> Database Driver Class Initialized
DEBUG - 2023-04-03 08:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-03 08:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-03 08:57:51 --> Controller Class Initialized
INFO - 2023-04-03 08:57:51 --> Final output sent to browser
DEBUG - 2023-04-03 08:57:51 --> Total execution time: 0.0428
INFO - 2023-04-03 08:57:52 --> Config Class Initialized
INFO - 2023-04-03 08:57:52 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:57:52 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:57:52 --> Utf8 Class Initialized
INFO - 2023-04-03 08:57:52 --> URI Class Initialized
INFO - 2023-04-03 08:57:52 --> Router Class Initialized
INFO - 2023-04-03 08:57:52 --> Output Class Initialized
INFO - 2023-04-03 08:57:52 --> Security Class Initialized
DEBUG - 2023-04-03 08:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:57:52 --> Input Class Initialized
INFO - 2023-04-03 08:57:52 --> Language Class Initialized
INFO - 2023-04-03 08:57:52 --> Language Class Initialized
INFO - 2023-04-03 08:57:52 --> Config Class Initialized
INFO - 2023-04-03 08:57:52 --> Loader Class Initialized
INFO - 2023-04-03 08:57:52 --> Helper loaded: url_helper
INFO - 2023-04-03 08:57:52 --> Helper loaded: file_helper
INFO - 2023-04-03 08:57:52 --> Helper loaded: form_helper
INFO - 2023-04-03 08:57:52 --> Helper loaded: my_helper
INFO - 2023-04-03 08:57:52 --> Database Driver Class Initialized
DEBUG - 2023-04-03 08:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-03 08:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-03 08:57:52 --> Controller Class Initialized
INFO - 2023-04-03 08:57:52 --> Final output sent to browser
DEBUG - 2023-04-03 08:57:52 --> Total execution time: 0.0509
INFO - 2023-04-03 08:58:02 --> Config Class Initialized
INFO - 2023-04-03 08:58:02 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:58:02 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:58:02 --> Utf8 Class Initialized
INFO - 2023-04-03 08:58:02 --> URI Class Initialized
INFO - 2023-04-03 08:58:02 --> Router Class Initialized
INFO - 2023-04-03 08:58:02 --> Output Class Initialized
INFO - 2023-04-03 08:58:02 --> Security Class Initialized
DEBUG - 2023-04-03 08:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:58:02 --> Input Class Initialized
INFO - 2023-04-03 08:58:02 --> Language Class Initialized
INFO - 2023-04-03 08:58:02 --> Language Class Initialized
INFO - 2023-04-03 08:58:02 --> Config Class Initialized
INFO - 2023-04-03 08:58:02 --> Loader Class Initialized
INFO - 2023-04-03 08:58:02 --> Helper loaded: url_helper
INFO - 2023-04-03 08:58:02 --> Helper loaded: file_helper
INFO - 2023-04-03 08:58:02 --> Helper loaded: form_helper
INFO - 2023-04-03 08:58:02 --> Helper loaded: my_helper
INFO - 2023-04-03 08:58:02 --> Database Driver Class Initialized
DEBUG - 2023-04-03 08:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-03 08:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-03 08:58:02 --> Controller Class Initialized
INFO - 2023-04-03 08:58:02 --> Final output sent to browser
DEBUG - 2023-04-03 08:58:02 --> Total execution time: 0.0428
INFO - 2023-04-03 08:58:08 --> Config Class Initialized
INFO - 2023-04-03 08:58:08 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:58:08 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:58:08 --> Utf8 Class Initialized
INFO - 2023-04-03 08:58:08 --> URI Class Initialized
INFO - 2023-04-03 08:58:08 --> Router Class Initialized
INFO - 2023-04-03 08:58:08 --> Output Class Initialized
INFO - 2023-04-03 08:58:08 --> Security Class Initialized
DEBUG - 2023-04-03 08:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:58:08 --> Input Class Initialized
INFO - 2023-04-03 08:58:08 --> Language Class Initialized
INFO - 2023-04-03 08:58:08 --> Language Class Initialized
INFO - 2023-04-03 08:58:08 --> Config Class Initialized
INFO - 2023-04-03 08:58:08 --> Loader Class Initialized
INFO - 2023-04-03 08:58:08 --> Helper loaded: url_helper
INFO - 2023-04-03 08:58:08 --> Helper loaded: file_helper
INFO - 2023-04-03 08:58:08 --> Helper loaded: form_helper
INFO - 2023-04-03 08:58:08 --> Helper loaded: my_helper
INFO - 2023-04-03 08:58:08 --> Database Driver Class Initialized
DEBUG - 2023-04-03 08:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-03 08:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-03 08:58:08 --> Controller Class Initialized
INFO - 2023-04-03 08:58:08 --> Final output sent to browser
DEBUG - 2023-04-03 08:58:08 --> Total execution time: 0.0430
INFO - 2023-04-03 08:58:21 --> Config Class Initialized
INFO - 2023-04-03 08:58:21 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:58:21 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:58:21 --> Utf8 Class Initialized
INFO - 2023-04-03 08:58:21 --> URI Class Initialized
INFO - 2023-04-03 08:58:21 --> Router Class Initialized
INFO - 2023-04-03 08:58:21 --> Output Class Initialized
INFO - 2023-04-03 08:58:21 --> Security Class Initialized
DEBUG - 2023-04-03 08:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:58:21 --> Input Class Initialized
INFO - 2023-04-03 08:58:21 --> Language Class Initialized
INFO - 2023-04-03 08:58:21 --> Language Class Initialized
INFO - 2023-04-03 08:58:21 --> Config Class Initialized
INFO - 2023-04-03 08:58:21 --> Loader Class Initialized
INFO - 2023-04-03 08:58:21 --> Helper loaded: url_helper
INFO - 2023-04-03 08:58:21 --> Helper loaded: file_helper
INFO - 2023-04-03 08:58:21 --> Helper loaded: form_helper
INFO - 2023-04-03 08:58:21 --> Helper loaded: my_helper
INFO - 2023-04-03 08:58:21 --> Database Driver Class Initialized
DEBUG - 2023-04-03 08:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-03 08:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-03 08:58:21 --> Controller Class Initialized
INFO - 2023-04-03 08:58:21 --> Final output sent to browser
DEBUG - 2023-04-03 08:58:21 --> Total execution time: 0.0608
INFO - 2023-04-03 08:58:46 --> Config Class Initialized
INFO - 2023-04-03 08:58:46 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:58:46 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:58:46 --> Utf8 Class Initialized
INFO - 2023-04-03 08:58:46 --> URI Class Initialized
INFO - 2023-04-03 08:58:46 --> Router Class Initialized
INFO - 2023-04-03 08:58:46 --> Output Class Initialized
INFO - 2023-04-03 08:58:46 --> Security Class Initialized
DEBUG - 2023-04-03 08:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:58:46 --> Input Class Initialized
INFO - 2023-04-03 08:58:46 --> Language Class Initialized
INFO - 2023-04-03 08:58:46 --> Language Class Initialized
INFO - 2023-04-03 08:58:46 --> Config Class Initialized
INFO - 2023-04-03 08:58:46 --> Loader Class Initialized
INFO - 2023-04-03 08:58:46 --> Helper loaded: url_helper
INFO - 2023-04-03 08:58:46 --> Helper loaded: file_helper
INFO - 2023-04-03 08:58:46 --> Helper loaded: form_helper
INFO - 2023-04-03 08:58:46 --> Helper loaded: my_helper
INFO - 2023-04-03 08:58:47 --> Database Driver Class Initialized
DEBUG - 2023-04-03 08:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-03 08:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-03 08:58:47 --> Controller Class Initialized
INFO - 2023-04-03 09:02:37 --> Config Class Initialized
INFO - 2023-04-03 09:02:37 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:02:37 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:02:37 --> Utf8 Class Initialized
INFO - 2023-04-03 09:02:37 --> URI Class Initialized
INFO - 2023-04-03 09:02:37 --> Router Class Initialized
INFO - 2023-04-03 09:02:37 --> Output Class Initialized
INFO - 2023-04-03 09:02:37 --> Security Class Initialized
DEBUG - 2023-04-03 09:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:02:37 --> Input Class Initialized
INFO - 2023-04-03 09:02:37 --> Language Class Initialized
INFO - 2023-04-03 09:02:37 --> Language Class Initialized
INFO - 2023-04-03 09:02:37 --> Config Class Initialized
INFO - 2023-04-03 09:02:37 --> Loader Class Initialized
INFO - 2023-04-03 09:02:37 --> Helper loaded: url_helper
INFO - 2023-04-03 09:02:37 --> Helper loaded: file_helper
INFO - 2023-04-03 09:02:37 --> Helper loaded: form_helper
INFO - 2023-04-03 09:02:37 --> Helper loaded: my_helper
INFO - 2023-04-03 09:02:37 --> Database Driver Class Initialized
DEBUG - 2023-04-03 09:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-03 09:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-03 09:02:37 --> Controller Class Initialized
INFO - 2023-04-03 09:02:37 --> Helper loaded: cookie_helper
INFO - 2023-04-03 09:02:37 --> Config Class Initialized
INFO - 2023-04-03 09:02:37 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:02:37 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:02:37 --> Utf8 Class Initialized
INFO - 2023-04-03 09:02:37 --> URI Class Initialized
INFO - 2023-04-03 09:02:37 --> Router Class Initialized
INFO - 2023-04-03 09:02:37 --> Output Class Initialized
INFO - 2023-04-03 09:02:37 --> Security Class Initialized
DEBUG - 2023-04-03 09:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:02:37 --> Input Class Initialized
INFO - 2023-04-03 09:02:37 --> Language Class Initialized
INFO - 2023-04-03 09:02:37 --> Language Class Initialized
INFO - 2023-04-03 09:02:37 --> Config Class Initialized
INFO - 2023-04-03 09:02:37 --> Loader Class Initialized
INFO - 2023-04-03 09:02:37 --> Helper loaded: url_helper
INFO - 2023-04-03 09:02:37 --> Helper loaded: file_helper
INFO - 2023-04-03 09:02:37 --> Helper loaded: form_helper
INFO - 2023-04-03 09:02:37 --> Helper loaded: my_helper
INFO - 2023-04-03 09:02:37 --> Database Driver Class Initialized
DEBUG - 2023-04-03 09:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-03 09:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-03 09:02:37 --> Controller Class Initialized
INFO - 2023-04-03 09:02:37 --> Config Class Initialized
INFO - 2023-04-03 09:02:37 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:02:37 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:02:37 --> Utf8 Class Initialized
INFO - 2023-04-03 09:02:37 --> URI Class Initialized
INFO - 2023-04-03 09:02:37 --> Router Class Initialized
INFO - 2023-04-03 09:02:37 --> Output Class Initialized
INFO - 2023-04-03 09:02:37 --> Security Class Initialized
DEBUG - 2023-04-03 09:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:02:37 --> Input Class Initialized
INFO - 2023-04-03 09:02:37 --> Language Class Initialized
INFO - 2023-04-03 09:02:37 --> Language Class Initialized
INFO - 2023-04-03 09:02:37 --> Config Class Initialized
INFO - 2023-04-03 09:02:37 --> Loader Class Initialized
INFO - 2023-04-03 09:02:37 --> Helper loaded: url_helper
INFO - 2023-04-03 09:02:37 --> Helper loaded: file_helper
INFO - 2023-04-03 09:02:37 --> Helper loaded: form_helper
INFO - 2023-04-03 09:02:37 --> Helper loaded: my_helper
INFO - 2023-04-03 09:02:37 --> Database Driver Class Initialized
DEBUG - 2023-04-03 09:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-03 09:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-03 09:02:37 --> Controller Class Initialized
DEBUG - 2023-04-03 09:02:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-04-03 09:02:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-03 09:02:37 --> Final output sent to browser
DEBUG - 2023-04-03 09:02:37 --> Total execution time: 0.0495
INFO - 2023-04-03 09:03:21 --> Config Class Initialized
INFO - 2023-04-03 09:03:21 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:03:21 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:03:21 --> Utf8 Class Initialized
INFO - 2023-04-03 09:03:21 --> URI Class Initialized
INFO - 2023-04-03 09:03:21 --> Router Class Initialized
INFO - 2023-04-03 09:03:21 --> Output Class Initialized
INFO - 2023-04-03 09:03:21 --> Security Class Initialized
DEBUG - 2023-04-03 09:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:03:21 --> Input Class Initialized
INFO - 2023-04-03 09:03:21 --> Language Class Initialized
INFO - 2023-04-03 09:03:21 --> Language Class Initialized
INFO - 2023-04-03 09:03:21 --> Config Class Initialized
INFO - 2023-04-03 09:03:21 --> Loader Class Initialized
INFO - 2023-04-03 09:03:21 --> Helper loaded: url_helper
INFO - 2023-04-03 09:03:21 --> Helper loaded: file_helper
INFO - 2023-04-03 09:03:21 --> Helper loaded: form_helper
INFO - 2023-04-03 09:03:21 --> Helper loaded: my_helper
INFO - 2023-04-03 09:03:21 --> Database Driver Class Initialized
DEBUG - 2023-04-03 09:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-03 09:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-03 09:03:21 --> Controller Class Initialized
INFO - 2023-04-03 09:03:21 --> Helper loaded: cookie_helper
INFO - 2023-04-03 09:03:21 --> Final output sent to browser
DEBUG - 2023-04-03 09:03:21 --> Total execution time: 0.0652
INFO - 2023-04-03 09:03:21 --> Config Class Initialized
INFO - 2023-04-03 09:03:21 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:03:21 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:03:21 --> Utf8 Class Initialized
INFO - 2023-04-03 09:03:21 --> URI Class Initialized
INFO - 2023-04-03 09:03:21 --> Router Class Initialized
INFO - 2023-04-03 09:03:21 --> Output Class Initialized
INFO - 2023-04-03 09:03:21 --> Security Class Initialized
DEBUG - 2023-04-03 09:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:03:21 --> Input Class Initialized
INFO - 2023-04-03 09:03:21 --> Language Class Initialized
INFO - 2023-04-03 09:03:21 --> Language Class Initialized
INFO - 2023-04-03 09:03:21 --> Config Class Initialized
INFO - 2023-04-03 09:03:21 --> Loader Class Initialized
INFO - 2023-04-03 09:03:21 --> Helper loaded: url_helper
INFO - 2023-04-03 09:03:21 --> Helper loaded: file_helper
INFO - 2023-04-03 09:03:21 --> Helper loaded: form_helper
INFO - 2023-04-03 09:03:21 --> Helper loaded: my_helper
INFO - 2023-04-03 09:03:21 --> Database Driver Class Initialized
DEBUG - 2023-04-03 09:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-03 09:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-03 09:03:21 --> Controller Class Initialized
DEBUG - 2023-04-03 09:03:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-04-03 09:03:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-03 09:03:21 --> Final output sent to browser
DEBUG - 2023-04-03 09:03:21 --> Total execution time: 0.0720
INFO - 2023-04-03 09:03:27 --> Config Class Initialized
INFO - 2023-04-03 09:03:27 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:03:27 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:03:27 --> Utf8 Class Initialized
INFO - 2023-04-03 09:03:27 --> URI Class Initialized
INFO - 2023-04-03 09:03:27 --> Router Class Initialized
INFO - 2023-04-03 09:03:27 --> Output Class Initialized
INFO - 2023-04-03 09:03:27 --> Security Class Initialized
DEBUG - 2023-04-03 09:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:03:27 --> Input Class Initialized
INFO - 2023-04-03 09:03:27 --> Language Class Initialized
INFO - 2023-04-03 09:03:27 --> Language Class Initialized
INFO - 2023-04-03 09:03:27 --> Config Class Initialized
INFO - 2023-04-03 09:03:27 --> Loader Class Initialized
INFO - 2023-04-03 09:03:27 --> Helper loaded: url_helper
INFO - 2023-04-03 09:03:27 --> Helper loaded: file_helper
INFO - 2023-04-03 09:03:27 --> Helper loaded: form_helper
INFO - 2023-04-03 09:03:27 --> Helper loaded: my_helper
INFO - 2023-04-03 09:03:27 --> Database Driver Class Initialized
DEBUG - 2023-04-03 09:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-03 09:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-03 09:03:27 --> Controller Class Initialized
DEBUG - 2023-04-03 09:03:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-04-03 09:03:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-03 09:03:27 --> Final output sent to browser
DEBUG - 2023-04-03 09:03:27 --> Total execution time: 0.1735
INFO - 2023-04-03 09:03:29 --> Config Class Initialized
INFO - 2023-04-03 09:03:29 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:03:29 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:03:29 --> Utf8 Class Initialized
INFO - 2023-04-03 09:03:29 --> URI Class Initialized
INFO - 2023-04-03 09:03:29 --> Router Class Initialized
INFO - 2023-04-03 09:03:29 --> Output Class Initialized
INFO - 2023-04-03 09:03:29 --> Security Class Initialized
DEBUG - 2023-04-03 09:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:03:29 --> Input Class Initialized
INFO - 2023-04-03 09:03:29 --> Language Class Initialized
INFO - 2023-04-03 09:03:29 --> Language Class Initialized
INFO - 2023-04-03 09:03:29 --> Config Class Initialized
INFO - 2023-04-03 09:03:29 --> Loader Class Initialized
INFO - 2023-04-03 09:03:29 --> Helper loaded: url_helper
INFO - 2023-04-03 09:03:29 --> Helper loaded: file_helper
INFO - 2023-04-03 09:03:29 --> Helper loaded: form_helper
INFO - 2023-04-03 09:03:29 --> Helper loaded: my_helper
INFO - 2023-04-03 09:03:29 --> Database Driver Class Initialized
DEBUG - 2023-04-03 09:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-03 09:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-03 09:03:29 --> Controller Class Initialized
DEBUG - 2023-04-03 09:03:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-04-03 09:03:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-03 09:03:29 --> Final output sent to browser
DEBUG - 2023-04-03 09:03:29 --> Total execution time: 0.1135
INFO - 2023-04-03 09:03:34 --> Config Class Initialized
INFO - 2023-04-03 09:03:34 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:03:34 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:03:34 --> Utf8 Class Initialized
INFO - 2023-04-03 09:03:34 --> URI Class Initialized
INFO - 2023-04-03 09:03:34 --> Router Class Initialized
INFO - 2023-04-03 09:03:34 --> Output Class Initialized
INFO - 2023-04-03 09:03:34 --> Security Class Initialized
DEBUG - 2023-04-03 09:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:03:34 --> Input Class Initialized
INFO - 2023-04-03 09:03:34 --> Language Class Initialized
INFO - 2023-04-03 09:03:34 --> Language Class Initialized
INFO - 2023-04-03 09:03:34 --> Config Class Initialized
INFO - 2023-04-03 09:03:34 --> Loader Class Initialized
INFO - 2023-04-03 09:03:34 --> Helper loaded: url_helper
INFO - 2023-04-03 09:03:34 --> Helper loaded: file_helper
INFO - 2023-04-03 09:03:34 --> Helper loaded: form_helper
INFO - 2023-04-03 09:03:34 --> Helper loaded: my_helper
INFO - 2023-04-03 09:03:34 --> Database Driver Class Initialized
DEBUG - 2023-04-03 09:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-03 09:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-03 09:03:34 --> Controller Class Initialized
DEBUG - 2023-04-03 09:03:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-04-03 09:03:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-03 09:03:34 --> Final output sent to browser
DEBUG - 2023-04-03 09:03:34 --> Total execution time: 0.0636
INFO - 2023-04-03 09:03:38 --> Config Class Initialized
INFO - 2023-04-03 09:03:38 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:03:38 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:03:38 --> Utf8 Class Initialized
INFO - 2023-04-03 09:03:38 --> URI Class Initialized
INFO - 2023-04-03 09:03:38 --> Router Class Initialized
INFO - 2023-04-03 09:03:38 --> Output Class Initialized
INFO - 2023-04-03 09:03:38 --> Security Class Initialized
DEBUG - 2023-04-03 09:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:03:38 --> Input Class Initialized
INFO - 2023-04-03 09:03:38 --> Language Class Initialized
INFO - 2023-04-03 09:03:38 --> Language Class Initialized
INFO - 2023-04-03 09:03:38 --> Config Class Initialized
INFO - 2023-04-03 09:03:38 --> Loader Class Initialized
INFO - 2023-04-03 09:03:38 --> Helper loaded: url_helper
INFO - 2023-04-03 09:03:38 --> Helper loaded: file_helper
INFO - 2023-04-03 09:03:38 --> Helper loaded: form_helper
INFO - 2023-04-03 09:03:38 --> Helper loaded: my_helper
INFO - 2023-04-03 09:03:38 --> Database Driver Class Initialized
DEBUG - 2023-04-03 09:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-03 09:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-03 09:03:38 --> Controller Class Initialized
DEBUG - 2023-04-03 09:03:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-04-03 09:03:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-03 09:03:38 --> Final output sent to browser
DEBUG - 2023-04-03 09:03:38 --> Total execution time: 0.0638
INFO - 2023-04-03 09:03:43 --> Config Class Initialized
INFO - 2023-04-03 09:03:43 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:03:43 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:03:43 --> Utf8 Class Initialized
INFO - 2023-04-03 09:03:43 --> URI Class Initialized
INFO - 2023-04-03 09:03:43 --> Router Class Initialized
INFO - 2023-04-03 09:03:43 --> Output Class Initialized
INFO - 2023-04-03 09:03:43 --> Security Class Initialized
DEBUG - 2023-04-03 09:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:03:43 --> Input Class Initialized
INFO - 2023-04-03 09:03:43 --> Language Class Initialized
INFO - 2023-04-03 09:03:43 --> Language Class Initialized
INFO - 2023-04-03 09:03:43 --> Config Class Initialized
INFO - 2023-04-03 09:03:43 --> Loader Class Initialized
INFO - 2023-04-03 09:03:43 --> Helper loaded: url_helper
INFO - 2023-04-03 09:03:43 --> Helper loaded: file_helper
INFO - 2023-04-03 09:03:43 --> Helper loaded: form_helper
INFO - 2023-04-03 09:03:43 --> Helper loaded: my_helper
INFO - 2023-04-03 09:03:43 --> Database Driver Class Initialized
DEBUG - 2023-04-03 09:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-03 09:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-03 09:03:43 --> Controller Class Initialized
DEBUG - 2023-04-03 09:03:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-04-03 09:03:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-03 09:03:43 --> Final output sent to browser
DEBUG - 2023-04-03 09:03:43 --> Total execution time: 0.0631
INFO - 2023-04-03 09:03:46 --> Config Class Initialized
INFO - 2023-04-03 09:03:46 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:03:46 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:03:46 --> Utf8 Class Initialized
INFO - 2023-04-03 09:03:46 --> URI Class Initialized
INFO - 2023-04-03 09:03:46 --> Router Class Initialized
INFO - 2023-04-03 09:03:46 --> Output Class Initialized
INFO - 2023-04-03 09:03:46 --> Security Class Initialized
DEBUG - 2023-04-03 09:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:03:46 --> Input Class Initialized
INFO - 2023-04-03 09:03:46 --> Language Class Initialized
INFO - 2023-04-03 09:03:46 --> Language Class Initialized
INFO - 2023-04-03 09:03:46 --> Config Class Initialized
INFO - 2023-04-03 09:03:46 --> Loader Class Initialized
INFO - 2023-04-03 09:03:46 --> Helper loaded: url_helper
INFO - 2023-04-03 09:03:46 --> Helper loaded: file_helper
INFO - 2023-04-03 09:03:46 --> Helper loaded: form_helper
INFO - 2023-04-03 09:03:46 --> Helper loaded: my_helper
INFO - 2023-04-03 09:03:46 --> Database Driver Class Initialized
DEBUG - 2023-04-03 09:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-03 09:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-03 09:03:46 --> Controller Class Initialized
DEBUG - 2023-04-03 09:03:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-04-03 09:03:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-03 09:03:46 --> Final output sent to browser
DEBUG - 2023-04-03 09:03:46 --> Total execution time: 0.0683
INFO - 2023-04-03 09:04:06 --> Config Class Initialized
INFO - 2023-04-03 09:04:06 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:04:06 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:04:06 --> Utf8 Class Initialized
INFO - 2023-04-03 09:04:06 --> URI Class Initialized
INFO - 2023-04-03 09:04:06 --> Router Class Initialized
INFO - 2023-04-03 09:04:06 --> Output Class Initialized
INFO - 2023-04-03 09:04:06 --> Security Class Initialized
DEBUG - 2023-04-03 09:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:04:06 --> Input Class Initialized
INFO - 2023-04-03 09:04:06 --> Language Class Initialized
INFO - 2023-04-03 09:04:06 --> Language Class Initialized
INFO - 2023-04-03 09:04:06 --> Config Class Initialized
INFO - 2023-04-03 09:04:06 --> Loader Class Initialized
INFO - 2023-04-03 09:04:06 --> Helper loaded: url_helper
INFO - 2023-04-03 09:04:06 --> Helper loaded: file_helper
INFO - 2023-04-03 09:04:06 --> Helper loaded: form_helper
INFO - 2023-04-03 09:04:06 --> Helper loaded: my_helper
INFO - 2023-04-03 09:04:06 --> Database Driver Class Initialized
DEBUG - 2023-04-03 09:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-03 09:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-03 09:04:06 --> Controller Class Initialized
DEBUG - 2023-04-03 09:04:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-04-03 09:04:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-03 09:04:06 --> Final output sent to browser
DEBUG - 2023-04-03 09:04:06 --> Total execution time: 0.1418
INFO - 2023-04-03 09:04:13 --> Config Class Initialized
INFO - 2023-04-03 09:04:13 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:04:13 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:04:13 --> Utf8 Class Initialized
INFO - 2023-04-03 09:04:13 --> URI Class Initialized
INFO - 2023-04-03 09:04:13 --> Router Class Initialized
INFO - 2023-04-03 09:04:13 --> Output Class Initialized
INFO - 2023-04-03 09:04:13 --> Security Class Initialized
DEBUG - 2023-04-03 09:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:04:13 --> Input Class Initialized
INFO - 2023-04-03 09:04:13 --> Language Class Initialized
INFO - 2023-04-03 09:04:13 --> Language Class Initialized
INFO - 2023-04-03 09:04:13 --> Config Class Initialized
INFO - 2023-04-03 09:04:13 --> Loader Class Initialized
INFO - 2023-04-03 09:04:13 --> Helper loaded: url_helper
INFO - 2023-04-03 09:04:13 --> Helper loaded: file_helper
INFO - 2023-04-03 09:04:13 --> Helper loaded: form_helper
INFO - 2023-04-03 09:04:13 --> Helper loaded: my_helper
INFO - 2023-04-03 09:04:13 --> Database Driver Class Initialized
DEBUG - 2023-04-03 09:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-03 09:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-03 09:04:13 --> Controller Class Initialized
DEBUG - 2023-04-03 09:04:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-03 09:04:16 --> Final output sent to browser
DEBUG - 2023-04-03 09:04:16 --> Total execution time: 2.9653
INFO - 2023-04-03 09:05:01 --> Config Class Initialized
INFO - 2023-04-03 09:05:01 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:05:01 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:05:01 --> Utf8 Class Initialized
INFO - 2023-04-03 09:05:01 --> URI Class Initialized
INFO - 2023-04-03 09:05:01 --> Router Class Initialized
INFO - 2023-04-03 09:05:01 --> Output Class Initialized
INFO - 2023-04-03 09:05:01 --> Security Class Initialized
DEBUG - 2023-04-03 09:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:05:01 --> Input Class Initialized
INFO - 2023-04-03 09:05:01 --> Language Class Initialized
INFO - 2023-04-03 09:05:01 --> Language Class Initialized
INFO - 2023-04-03 09:05:01 --> Config Class Initialized
INFO - 2023-04-03 09:05:01 --> Loader Class Initialized
INFO - 2023-04-03 09:05:01 --> Helper loaded: url_helper
INFO - 2023-04-03 09:05:01 --> Helper loaded: file_helper
INFO - 2023-04-03 09:05:01 --> Helper loaded: form_helper
INFO - 2023-04-03 09:05:01 --> Helper loaded: my_helper
INFO - 2023-04-03 09:05:01 --> Database Driver Class Initialized
DEBUG - 2023-04-03 09:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-03 09:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-03 09:05:01 --> Controller Class Initialized
DEBUG - 2023-04-03 09:05:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-04-03 09:05:03 --> Final output sent to browser
DEBUG - 2023-04-03 09:05:03 --> Total execution time: 1.7034
INFO - 2023-04-03 09:05:26 --> Config Class Initialized
INFO - 2023-04-03 09:05:26 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:05:26 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:05:26 --> Utf8 Class Initialized
INFO - 2023-04-03 09:05:26 --> URI Class Initialized
INFO - 2023-04-03 09:05:26 --> Router Class Initialized
INFO - 2023-04-03 09:05:26 --> Output Class Initialized
INFO - 2023-04-03 09:05:26 --> Security Class Initialized
DEBUG - 2023-04-03 09:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:05:26 --> Input Class Initialized
INFO - 2023-04-03 09:05:26 --> Language Class Initialized
INFO - 2023-04-03 09:05:26 --> Language Class Initialized
INFO - 2023-04-03 09:05:26 --> Config Class Initialized
INFO - 2023-04-03 09:05:26 --> Loader Class Initialized
INFO - 2023-04-03 09:05:26 --> Helper loaded: url_helper
INFO - 2023-04-03 09:05:26 --> Helper loaded: file_helper
INFO - 2023-04-03 09:05:26 --> Helper loaded: form_helper
INFO - 2023-04-03 09:05:26 --> Helper loaded: my_helper
INFO - 2023-04-03 09:05:26 --> Database Driver Class Initialized
DEBUG - 2023-04-03 09:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-03 09:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-03 09:05:26 --> Controller Class Initialized
DEBUG - 2023-04-03 09:05:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-04-03 09:05:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-03 09:05:26 --> Final output sent to browser
DEBUG - 2023-04-03 09:05:26 --> Total execution time: 0.0808
