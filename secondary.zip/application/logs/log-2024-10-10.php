<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-10 06:26:57 --> Config Class Initialized
INFO - 2024-10-10 06:26:57 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:26:57 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:26:57 --> Utf8 Class Initialized
INFO - 2024-10-10 06:26:57 --> URI Class Initialized
INFO - 2024-10-10 06:26:57 --> Router Class Initialized
INFO - 2024-10-10 06:26:57 --> Output Class Initialized
INFO - 2024-10-10 06:26:57 --> Security Class Initialized
DEBUG - 2024-10-10 06:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:26:57 --> Input Class Initialized
INFO - 2024-10-10 06:26:57 --> Language Class Initialized
INFO - 2024-10-10 06:26:57 --> Language Class Initialized
INFO - 2024-10-10 06:26:57 --> Config Class Initialized
INFO - 2024-10-10 06:26:57 --> Loader Class Initialized
INFO - 2024-10-10 06:26:57 --> Helper loaded: url_helper
INFO - 2024-10-10 06:26:57 --> Helper loaded: file_helper
INFO - 2024-10-10 06:26:57 --> Helper loaded: form_helper
INFO - 2024-10-10 06:26:57 --> Helper loaded: my_helper
INFO - 2024-10-10 06:26:57 --> Database Driver Class Initialized
INFO - 2024-10-10 06:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:26:57 --> Controller Class Initialized
ERROR - 2024-10-10 06:26:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2393
DEBUG - 2024-10-10 06:26:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-10 06:26:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 06:26:57 --> Final output sent to browser
DEBUG - 2024-10-10 06:26:57 --> Total execution time: 0.0917
INFO - 2024-10-10 06:27:12 --> Config Class Initialized
INFO - 2024-10-10 06:27:12 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:27:12 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:27:12 --> Utf8 Class Initialized
INFO - 2024-10-10 06:27:12 --> URI Class Initialized
DEBUG - 2024-10-10 06:27:12 --> No URI present. Default controller set.
INFO - 2024-10-10 06:27:12 --> Router Class Initialized
INFO - 2024-10-10 06:27:12 --> Output Class Initialized
INFO - 2024-10-10 06:27:12 --> Security Class Initialized
DEBUG - 2024-10-10 06:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:27:12 --> Input Class Initialized
INFO - 2024-10-10 06:27:12 --> Language Class Initialized
INFO - 2024-10-10 06:27:12 --> Language Class Initialized
INFO - 2024-10-10 06:27:12 --> Config Class Initialized
INFO - 2024-10-10 06:27:12 --> Loader Class Initialized
INFO - 2024-10-10 06:27:12 --> Helper loaded: url_helper
INFO - 2024-10-10 06:27:12 --> Helper loaded: file_helper
INFO - 2024-10-10 06:27:12 --> Helper loaded: form_helper
INFO - 2024-10-10 06:27:12 --> Helper loaded: my_helper
INFO - 2024-10-10 06:27:12 --> Database Driver Class Initialized
INFO - 2024-10-10 06:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:27:12 --> Controller Class Initialized
INFO - 2024-10-10 06:27:12 --> Config Class Initialized
INFO - 2024-10-10 06:27:12 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:27:12 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:27:12 --> Utf8 Class Initialized
INFO - 2024-10-10 06:27:12 --> URI Class Initialized
INFO - 2024-10-10 06:27:12 --> Router Class Initialized
INFO - 2024-10-10 06:27:12 --> Output Class Initialized
INFO - 2024-10-10 06:27:12 --> Security Class Initialized
DEBUG - 2024-10-10 06:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:27:12 --> Input Class Initialized
INFO - 2024-10-10 06:27:12 --> Language Class Initialized
INFO - 2024-10-10 06:27:12 --> Language Class Initialized
INFO - 2024-10-10 06:27:12 --> Config Class Initialized
INFO - 2024-10-10 06:27:12 --> Loader Class Initialized
INFO - 2024-10-10 06:27:12 --> Helper loaded: url_helper
INFO - 2024-10-10 06:27:12 --> Helper loaded: file_helper
INFO - 2024-10-10 06:27:12 --> Helper loaded: form_helper
INFO - 2024-10-10 06:27:12 --> Helper loaded: my_helper
INFO - 2024-10-10 06:27:12 --> Database Driver Class Initialized
INFO - 2024-10-10 06:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:27:12 --> Controller Class Initialized
DEBUG - 2024-10-10 06:27:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-10 06:27:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 06:27:12 --> Final output sent to browser
DEBUG - 2024-10-10 06:27:12 --> Total execution time: 0.0605
INFO - 2024-10-10 06:27:22 --> Config Class Initialized
INFO - 2024-10-10 06:27:22 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:27:22 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:27:22 --> Utf8 Class Initialized
INFO - 2024-10-10 06:27:22 --> URI Class Initialized
INFO - 2024-10-10 06:27:22 --> Router Class Initialized
INFO - 2024-10-10 06:27:22 --> Output Class Initialized
INFO - 2024-10-10 06:27:22 --> Security Class Initialized
DEBUG - 2024-10-10 06:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:27:22 --> Input Class Initialized
INFO - 2024-10-10 06:27:22 --> Language Class Initialized
INFO - 2024-10-10 06:27:22 --> Language Class Initialized
INFO - 2024-10-10 06:27:22 --> Config Class Initialized
INFO - 2024-10-10 06:27:22 --> Loader Class Initialized
INFO - 2024-10-10 06:27:22 --> Helper loaded: url_helper
INFO - 2024-10-10 06:27:22 --> Helper loaded: file_helper
INFO - 2024-10-10 06:27:22 --> Helper loaded: form_helper
INFO - 2024-10-10 06:27:22 --> Helper loaded: my_helper
INFO - 2024-10-10 06:27:22 --> Database Driver Class Initialized
INFO - 2024-10-10 06:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:27:22 --> Controller Class Initialized
INFO - 2024-10-10 06:27:22 --> Helper loaded: cookie_helper
INFO - 2024-10-10 06:27:22 --> Final output sent to browser
DEBUG - 2024-10-10 06:27:22 --> Total execution time: 0.0329
INFO - 2024-10-10 06:27:22 --> Config Class Initialized
INFO - 2024-10-10 06:27:22 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:27:22 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:27:22 --> Utf8 Class Initialized
INFO - 2024-10-10 06:27:22 --> URI Class Initialized
INFO - 2024-10-10 06:27:22 --> Router Class Initialized
INFO - 2024-10-10 06:27:22 --> Output Class Initialized
INFO - 2024-10-10 06:27:22 --> Security Class Initialized
DEBUG - 2024-10-10 06:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:27:22 --> Input Class Initialized
INFO - 2024-10-10 06:27:22 --> Language Class Initialized
INFO - 2024-10-10 06:27:22 --> Language Class Initialized
INFO - 2024-10-10 06:27:22 --> Config Class Initialized
INFO - 2024-10-10 06:27:22 --> Loader Class Initialized
INFO - 2024-10-10 06:27:22 --> Helper loaded: url_helper
INFO - 2024-10-10 06:27:22 --> Helper loaded: file_helper
INFO - 2024-10-10 06:27:22 --> Helper loaded: form_helper
INFO - 2024-10-10 06:27:22 --> Helper loaded: my_helper
INFO - 2024-10-10 06:27:22 --> Database Driver Class Initialized
INFO - 2024-10-10 06:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:27:22 --> Controller Class Initialized
DEBUG - 2024-10-10 06:27:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-10 06:27:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 06:27:22 --> Final output sent to browser
DEBUG - 2024-10-10 06:27:22 --> Total execution time: 0.0419
INFO - 2024-10-10 06:27:25 --> Config Class Initialized
INFO - 2024-10-10 06:27:25 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:27:25 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:27:25 --> Utf8 Class Initialized
INFO - 2024-10-10 06:27:25 --> URI Class Initialized
INFO - 2024-10-10 06:27:25 --> Router Class Initialized
INFO - 2024-10-10 06:27:25 --> Output Class Initialized
INFO - 2024-10-10 06:27:25 --> Security Class Initialized
DEBUG - 2024-10-10 06:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:27:25 --> Input Class Initialized
INFO - 2024-10-10 06:27:25 --> Language Class Initialized
INFO - 2024-10-10 06:27:25 --> Language Class Initialized
INFO - 2024-10-10 06:27:25 --> Config Class Initialized
INFO - 2024-10-10 06:27:25 --> Loader Class Initialized
INFO - 2024-10-10 06:27:25 --> Helper loaded: url_helper
INFO - 2024-10-10 06:27:25 --> Helper loaded: file_helper
INFO - 2024-10-10 06:27:25 --> Helper loaded: form_helper
INFO - 2024-10-10 06:27:25 --> Helper loaded: my_helper
INFO - 2024-10-10 06:27:25 --> Database Driver Class Initialized
INFO - 2024-10-10 06:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:27:25 --> Controller Class Initialized
DEBUG - 2024-10-10 06:27:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-10 06:27:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 06:27:25 --> Final output sent to browser
DEBUG - 2024-10-10 06:27:25 --> Total execution time: 0.0742
INFO - 2024-10-10 06:27:28 --> Config Class Initialized
INFO - 2024-10-10 06:27:28 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:27:28 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:27:28 --> Utf8 Class Initialized
INFO - 2024-10-10 06:27:28 --> URI Class Initialized
INFO - 2024-10-10 06:27:28 --> Router Class Initialized
INFO - 2024-10-10 06:27:28 --> Output Class Initialized
INFO - 2024-10-10 06:27:28 --> Security Class Initialized
DEBUG - 2024-10-10 06:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:27:28 --> Input Class Initialized
INFO - 2024-10-10 06:27:28 --> Language Class Initialized
INFO - 2024-10-10 06:27:28 --> Language Class Initialized
INFO - 2024-10-10 06:27:28 --> Config Class Initialized
INFO - 2024-10-10 06:27:28 --> Loader Class Initialized
INFO - 2024-10-10 06:27:28 --> Helper loaded: url_helper
INFO - 2024-10-10 06:27:28 --> Helper loaded: file_helper
INFO - 2024-10-10 06:27:28 --> Helper loaded: form_helper
INFO - 2024-10-10 06:27:28 --> Helper loaded: my_helper
INFO - 2024-10-10 06:27:28 --> Database Driver Class Initialized
INFO - 2024-10-10 06:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:27:28 --> Controller Class Initialized
DEBUG - 2024-10-10 06:27:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-10 06:27:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 06:27:28 --> Final output sent to browser
DEBUG - 2024-10-10 06:27:28 --> Total execution time: 0.0326
INFO - 2024-10-10 06:27:28 --> Config Class Initialized
INFO - 2024-10-10 06:27:28 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:27:28 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:27:28 --> Utf8 Class Initialized
INFO - 2024-10-10 06:27:28 --> URI Class Initialized
INFO - 2024-10-10 06:27:28 --> Router Class Initialized
INFO - 2024-10-10 06:27:28 --> Output Class Initialized
INFO - 2024-10-10 06:27:28 --> Security Class Initialized
DEBUG - 2024-10-10 06:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:27:28 --> Input Class Initialized
INFO - 2024-10-10 06:27:28 --> Language Class Initialized
INFO - 2024-10-10 06:27:28 --> Language Class Initialized
INFO - 2024-10-10 06:27:28 --> Config Class Initialized
INFO - 2024-10-10 06:27:28 --> Loader Class Initialized
INFO - 2024-10-10 06:27:28 --> Helper loaded: url_helper
INFO - 2024-10-10 06:27:28 --> Helper loaded: file_helper
INFO - 2024-10-10 06:27:28 --> Helper loaded: form_helper
INFO - 2024-10-10 06:27:28 --> Helper loaded: my_helper
INFO - 2024-10-10 06:27:28 --> Database Driver Class Initialized
INFO - 2024-10-10 06:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:27:28 --> Controller Class Initialized
INFO - 2024-10-10 06:27:44 --> Config Class Initialized
INFO - 2024-10-10 06:27:44 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:27:44 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:27:44 --> Utf8 Class Initialized
INFO - 2024-10-10 06:27:44 --> URI Class Initialized
INFO - 2024-10-10 06:27:44 --> Router Class Initialized
INFO - 2024-10-10 06:27:44 --> Output Class Initialized
INFO - 2024-10-10 06:27:44 --> Security Class Initialized
DEBUG - 2024-10-10 06:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:27:44 --> Input Class Initialized
INFO - 2024-10-10 06:27:44 --> Language Class Initialized
INFO - 2024-10-10 06:27:44 --> Language Class Initialized
INFO - 2024-10-10 06:27:44 --> Config Class Initialized
INFO - 2024-10-10 06:27:44 --> Loader Class Initialized
INFO - 2024-10-10 06:27:44 --> Helper loaded: url_helper
INFO - 2024-10-10 06:27:44 --> Helper loaded: file_helper
INFO - 2024-10-10 06:27:44 --> Helper loaded: form_helper
INFO - 2024-10-10 06:27:44 --> Helper loaded: my_helper
INFO - 2024-10-10 06:27:44 --> Database Driver Class Initialized
INFO - 2024-10-10 06:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:27:44 --> Controller Class Initialized
INFO - 2024-10-10 06:27:44 --> Final output sent to browser
DEBUG - 2024-10-10 06:27:44 --> Total execution time: 0.0338
INFO - 2024-10-10 06:27:47 --> Config Class Initialized
INFO - 2024-10-10 06:27:47 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:27:47 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:27:47 --> Utf8 Class Initialized
INFO - 2024-10-10 06:27:47 --> URI Class Initialized
INFO - 2024-10-10 06:27:47 --> Router Class Initialized
INFO - 2024-10-10 06:27:47 --> Output Class Initialized
INFO - 2024-10-10 06:27:47 --> Security Class Initialized
DEBUG - 2024-10-10 06:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:27:47 --> Input Class Initialized
INFO - 2024-10-10 06:27:47 --> Language Class Initialized
INFO - 2024-10-10 06:27:47 --> Language Class Initialized
INFO - 2024-10-10 06:27:47 --> Config Class Initialized
INFO - 2024-10-10 06:27:47 --> Loader Class Initialized
INFO - 2024-10-10 06:27:47 --> Helper loaded: url_helper
INFO - 2024-10-10 06:27:47 --> Helper loaded: file_helper
INFO - 2024-10-10 06:27:47 --> Helper loaded: form_helper
INFO - 2024-10-10 06:27:47 --> Helper loaded: my_helper
INFO - 2024-10-10 06:27:47 --> Database Driver Class Initialized
INFO - 2024-10-10 06:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:27:47 --> Controller Class Initialized
INFO - 2024-10-10 06:27:47 --> Final output sent to browser
DEBUG - 2024-10-10 06:27:47 --> Total execution time: 0.0275
INFO - 2024-10-10 06:27:47 --> Config Class Initialized
INFO - 2024-10-10 06:27:47 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:27:47 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:27:47 --> Utf8 Class Initialized
INFO - 2024-10-10 06:27:47 --> URI Class Initialized
INFO - 2024-10-10 06:27:47 --> Router Class Initialized
INFO - 2024-10-10 06:27:47 --> Output Class Initialized
INFO - 2024-10-10 06:27:47 --> Security Class Initialized
DEBUG - 2024-10-10 06:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:27:47 --> Input Class Initialized
INFO - 2024-10-10 06:27:47 --> Language Class Initialized
INFO - 2024-10-10 06:27:47 --> Language Class Initialized
INFO - 2024-10-10 06:27:47 --> Config Class Initialized
INFO - 2024-10-10 06:27:47 --> Loader Class Initialized
INFO - 2024-10-10 06:27:47 --> Helper loaded: url_helper
INFO - 2024-10-10 06:27:47 --> Helper loaded: file_helper
INFO - 2024-10-10 06:27:47 --> Helper loaded: form_helper
INFO - 2024-10-10 06:27:47 --> Helper loaded: my_helper
INFO - 2024-10-10 06:27:47 --> Database Driver Class Initialized
INFO - 2024-10-10 06:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:27:47 --> Controller Class Initialized
INFO - 2024-10-10 06:28:03 --> Config Class Initialized
INFO - 2024-10-10 06:28:03 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:28:03 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:28:03 --> Utf8 Class Initialized
INFO - 2024-10-10 06:28:03 --> URI Class Initialized
INFO - 2024-10-10 06:28:03 --> Router Class Initialized
INFO - 2024-10-10 06:28:03 --> Output Class Initialized
INFO - 2024-10-10 06:28:03 --> Security Class Initialized
DEBUG - 2024-10-10 06:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:28:03 --> Input Class Initialized
INFO - 2024-10-10 06:28:03 --> Language Class Initialized
INFO - 2024-10-10 06:28:03 --> Language Class Initialized
INFO - 2024-10-10 06:28:03 --> Config Class Initialized
INFO - 2024-10-10 06:28:03 --> Loader Class Initialized
INFO - 2024-10-10 06:28:03 --> Helper loaded: url_helper
INFO - 2024-10-10 06:28:03 --> Helper loaded: file_helper
INFO - 2024-10-10 06:28:03 --> Helper loaded: form_helper
INFO - 2024-10-10 06:28:03 --> Helper loaded: my_helper
INFO - 2024-10-10 06:28:03 --> Database Driver Class Initialized
INFO - 2024-10-10 06:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:28:03 --> Controller Class Initialized
INFO - 2024-10-10 06:28:03 --> Final output sent to browser
DEBUG - 2024-10-10 06:28:03 --> Total execution time: 0.0473
INFO - 2024-10-10 06:28:03 --> Config Class Initialized
INFO - 2024-10-10 06:28:03 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:28:03 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:28:03 --> Utf8 Class Initialized
INFO - 2024-10-10 06:28:03 --> URI Class Initialized
INFO - 2024-10-10 06:28:03 --> Router Class Initialized
INFO - 2024-10-10 06:28:03 --> Output Class Initialized
INFO - 2024-10-10 06:28:03 --> Security Class Initialized
DEBUG - 2024-10-10 06:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:28:03 --> Input Class Initialized
INFO - 2024-10-10 06:28:03 --> Language Class Initialized
INFO - 2024-10-10 06:28:03 --> Language Class Initialized
INFO - 2024-10-10 06:28:03 --> Config Class Initialized
INFO - 2024-10-10 06:28:03 --> Loader Class Initialized
INFO - 2024-10-10 06:28:03 --> Helper loaded: url_helper
INFO - 2024-10-10 06:28:03 --> Helper loaded: file_helper
INFO - 2024-10-10 06:28:03 --> Helper loaded: form_helper
INFO - 2024-10-10 06:28:03 --> Helper loaded: my_helper
INFO - 2024-10-10 06:28:03 --> Database Driver Class Initialized
INFO - 2024-10-10 06:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:28:03 --> Controller Class Initialized
INFO - 2024-10-10 06:28:08 --> Config Class Initialized
INFO - 2024-10-10 06:28:08 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:28:08 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:28:08 --> Utf8 Class Initialized
INFO - 2024-10-10 06:28:08 --> URI Class Initialized
INFO - 2024-10-10 06:28:08 --> Router Class Initialized
INFO - 2024-10-10 06:28:08 --> Output Class Initialized
INFO - 2024-10-10 06:28:08 --> Security Class Initialized
DEBUG - 2024-10-10 06:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:28:08 --> Input Class Initialized
INFO - 2024-10-10 06:28:08 --> Language Class Initialized
INFO - 2024-10-10 06:28:08 --> Language Class Initialized
INFO - 2024-10-10 06:28:08 --> Config Class Initialized
INFO - 2024-10-10 06:28:08 --> Loader Class Initialized
INFO - 2024-10-10 06:28:08 --> Helper loaded: url_helper
INFO - 2024-10-10 06:28:08 --> Helper loaded: file_helper
INFO - 2024-10-10 06:28:08 --> Helper loaded: form_helper
INFO - 2024-10-10 06:28:08 --> Helper loaded: my_helper
INFO - 2024-10-10 06:28:08 --> Database Driver Class Initialized
INFO - 2024-10-10 06:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:28:08 --> Controller Class Initialized
INFO - 2024-10-10 06:28:08 --> Final output sent to browser
DEBUG - 2024-10-10 06:28:08 --> Total execution time: 0.0476
INFO - 2024-10-10 06:28:09 --> Config Class Initialized
INFO - 2024-10-10 06:28:09 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:28:09 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:28:09 --> Utf8 Class Initialized
INFO - 2024-10-10 06:28:09 --> URI Class Initialized
INFO - 2024-10-10 06:28:09 --> Router Class Initialized
INFO - 2024-10-10 06:28:09 --> Output Class Initialized
INFO - 2024-10-10 06:28:09 --> Security Class Initialized
DEBUG - 2024-10-10 06:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:28:09 --> Input Class Initialized
INFO - 2024-10-10 06:28:09 --> Language Class Initialized
INFO - 2024-10-10 06:28:09 --> Language Class Initialized
INFO - 2024-10-10 06:28:09 --> Config Class Initialized
INFO - 2024-10-10 06:28:09 --> Loader Class Initialized
INFO - 2024-10-10 06:28:09 --> Helper loaded: url_helper
INFO - 2024-10-10 06:28:09 --> Helper loaded: file_helper
INFO - 2024-10-10 06:28:09 --> Helper loaded: form_helper
INFO - 2024-10-10 06:28:09 --> Helper loaded: my_helper
INFO - 2024-10-10 06:28:09 --> Database Driver Class Initialized
INFO - 2024-10-10 06:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:28:09 --> Controller Class Initialized
INFO - 2024-10-10 06:28:12 --> Config Class Initialized
INFO - 2024-10-10 06:28:12 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:28:12 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:28:12 --> Utf8 Class Initialized
INFO - 2024-10-10 06:28:12 --> URI Class Initialized
INFO - 2024-10-10 06:28:12 --> Router Class Initialized
INFO - 2024-10-10 06:28:12 --> Output Class Initialized
INFO - 2024-10-10 06:28:12 --> Security Class Initialized
DEBUG - 2024-10-10 06:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:28:12 --> Input Class Initialized
INFO - 2024-10-10 06:28:12 --> Language Class Initialized
INFO - 2024-10-10 06:28:12 --> Language Class Initialized
INFO - 2024-10-10 06:28:12 --> Config Class Initialized
INFO - 2024-10-10 06:28:12 --> Loader Class Initialized
INFO - 2024-10-10 06:28:12 --> Helper loaded: url_helper
INFO - 2024-10-10 06:28:12 --> Helper loaded: file_helper
INFO - 2024-10-10 06:28:12 --> Helper loaded: form_helper
INFO - 2024-10-10 06:28:12 --> Helper loaded: my_helper
INFO - 2024-10-10 06:28:12 --> Database Driver Class Initialized
INFO - 2024-10-10 06:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:28:12 --> Controller Class Initialized
INFO - 2024-10-10 06:28:12 --> Final output sent to browser
DEBUG - 2024-10-10 06:28:12 --> Total execution time: 0.0342
INFO - 2024-10-10 06:28:12 --> Config Class Initialized
INFO - 2024-10-10 06:28:12 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:28:12 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:28:12 --> Utf8 Class Initialized
INFO - 2024-10-10 06:28:12 --> URI Class Initialized
INFO - 2024-10-10 06:28:12 --> Router Class Initialized
INFO - 2024-10-10 06:28:12 --> Output Class Initialized
INFO - 2024-10-10 06:28:12 --> Security Class Initialized
DEBUG - 2024-10-10 06:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:28:12 --> Input Class Initialized
INFO - 2024-10-10 06:28:12 --> Language Class Initialized
INFO - 2024-10-10 06:28:12 --> Language Class Initialized
INFO - 2024-10-10 06:28:12 --> Config Class Initialized
INFO - 2024-10-10 06:28:12 --> Loader Class Initialized
INFO - 2024-10-10 06:28:12 --> Helper loaded: url_helper
INFO - 2024-10-10 06:28:12 --> Helper loaded: file_helper
INFO - 2024-10-10 06:28:12 --> Helper loaded: form_helper
INFO - 2024-10-10 06:28:12 --> Helper loaded: my_helper
INFO - 2024-10-10 06:28:12 --> Database Driver Class Initialized
INFO - 2024-10-10 06:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:28:12 --> Controller Class Initialized
INFO - 2024-10-10 06:28:14 --> Config Class Initialized
INFO - 2024-10-10 06:28:14 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:28:14 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:28:14 --> Utf8 Class Initialized
INFO - 2024-10-10 06:28:14 --> URI Class Initialized
INFO - 2024-10-10 06:28:14 --> Router Class Initialized
INFO - 2024-10-10 06:28:14 --> Output Class Initialized
INFO - 2024-10-10 06:28:14 --> Security Class Initialized
DEBUG - 2024-10-10 06:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:28:14 --> Input Class Initialized
INFO - 2024-10-10 06:28:14 --> Language Class Initialized
INFO - 2024-10-10 06:28:14 --> Language Class Initialized
INFO - 2024-10-10 06:28:14 --> Config Class Initialized
INFO - 2024-10-10 06:28:14 --> Loader Class Initialized
INFO - 2024-10-10 06:28:14 --> Helper loaded: url_helper
INFO - 2024-10-10 06:28:14 --> Helper loaded: file_helper
INFO - 2024-10-10 06:28:14 --> Helper loaded: form_helper
INFO - 2024-10-10 06:28:14 --> Helper loaded: my_helper
INFO - 2024-10-10 06:28:14 --> Database Driver Class Initialized
INFO - 2024-10-10 06:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:28:14 --> Controller Class Initialized
INFO - 2024-10-10 06:28:14 --> Final output sent to browser
DEBUG - 2024-10-10 06:28:14 --> Total execution time: 0.0313
INFO - 2024-10-10 06:28:21 --> Config Class Initialized
INFO - 2024-10-10 06:28:21 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:28:21 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:28:21 --> Utf8 Class Initialized
INFO - 2024-10-10 06:28:21 --> URI Class Initialized
INFO - 2024-10-10 06:28:21 --> Router Class Initialized
INFO - 2024-10-10 06:28:21 --> Output Class Initialized
INFO - 2024-10-10 06:28:21 --> Security Class Initialized
DEBUG - 2024-10-10 06:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:28:21 --> Input Class Initialized
INFO - 2024-10-10 06:28:21 --> Language Class Initialized
INFO - 2024-10-10 06:28:21 --> Language Class Initialized
INFO - 2024-10-10 06:28:21 --> Config Class Initialized
INFO - 2024-10-10 06:28:21 --> Loader Class Initialized
INFO - 2024-10-10 06:28:21 --> Helper loaded: url_helper
INFO - 2024-10-10 06:28:21 --> Helper loaded: file_helper
INFO - 2024-10-10 06:28:21 --> Helper loaded: form_helper
INFO - 2024-10-10 06:28:21 --> Helper loaded: my_helper
INFO - 2024-10-10 06:28:21 --> Database Driver Class Initialized
INFO - 2024-10-10 06:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:28:21 --> Controller Class Initialized
INFO - 2024-10-10 06:28:21 --> Final output sent to browser
DEBUG - 2024-10-10 06:28:21 --> Total execution time: 0.0300
INFO - 2024-10-10 06:28:21 --> Config Class Initialized
INFO - 2024-10-10 06:28:21 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:28:21 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:28:21 --> Utf8 Class Initialized
INFO - 2024-10-10 06:28:21 --> URI Class Initialized
INFO - 2024-10-10 06:28:21 --> Router Class Initialized
INFO - 2024-10-10 06:28:21 --> Output Class Initialized
INFO - 2024-10-10 06:28:21 --> Security Class Initialized
DEBUG - 2024-10-10 06:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:28:21 --> Input Class Initialized
INFO - 2024-10-10 06:28:21 --> Language Class Initialized
INFO - 2024-10-10 06:28:21 --> Language Class Initialized
INFO - 2024-10-10 06:28:21 --> Config Class Initialized
INFO - 2024-10-10 06:28:21 --> Loader Class Initialized
INFO - 2024-10-10 06:28:21 --> Helper loaded: url_helper
INFO - 2024-10-10 06:28:21 --> Helper loaded: file_helper
INFO - 2024-10-10 06:28:21 --> Helper loaded: form_helper
INFO - 2024-10-10 06:28:21 --> Helper loaded: my_helper
INFO - 2024-10-10 06:28:21 --> Database Driver Class Initialized
INFO - 2024-10-10 06:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:28:21 --> Controller Class Initialized
INFO - 2024-10-10 06:28:23 --> Config Class Initialized
INFO - 2024-10-10 06:28:23 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:28:23 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:28:23 --> Utf8 Class Initialized
INFO - 2024-10-10 06:28:23 --> URI Class Initialized
INFO - 2024-10-10 06:28:23 --> Router Class Initialized
INFO - 2024-10-10 06:28:23 --> Output Class Initialized
INFO - 2024-10-10 06:28:23 --> Security Class Initialized
DEBUG - 2024-10-10 06:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:28:23 --> Input Class Initialized
INFO - 2024-10-10 06:28:23 --> Language Class Initialized
INFO - 2024-10-10 06:28:23 --> Language Class Initialized
INFO - 2024-10-10 06:28:23 --> Config Class Initialized
INFO - 2024-10-10 06:28:23 --> Loader Class Initialized
INFO - 2024-10-10 06:28:23 --> Helper loaded: url_helper
INFO - 2024-10-10 06:28:23 --> Helper loaded: file_helper
INFO - 2024-10-10 06:28:23 --> Helper loaded: form_helper
INFO - 2024-10-10 06:28:23 --> Helper loaded: my_helper
INFO - 2024-10-10 06:28:23 --> Database Driver Class Initialized
INFO - 2024-10-10 06:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:28:23 --> Controller Class Initialized
INFO - 2024-10-10 06:28:26 --> Config Class Initialized
INFO - 2024-10-10 06:28:26 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:28:26 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:28:26 --> Utf8 Class Initialized
INFO - 2024-10-10 06:28:26 --> URI Class Initialized
INFO - 2024-10-10 06:28:26 --> Router Class Initialized
INFO - 2024-10-10 06:28:26 --> Output Class Initialized
INFO - 2024-10-10 06:28:26 --> Security Class Initialized
DEBUG - 2024-10-10 06:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:28:26 --> Input Class Initialized
INFO - 2024-10-10 06:28:26 --> Language Class Initialized
INFO - 2024-10-10 06:28:26 --> Language Class Initialized
INFO - 2024-10-10 06:28:26 --> Config Class Initialized
INFO - 2024-10-10 06:28:26 --> Loader Class Initialized
INFO - 2024-10-10 06:28:26 --> Helper loaded: url_helper
INFO - 2024-10-10 06:28:26 --> Helper loaded: file_helper
INFO - 2024-10-10 06:28:26 --> Helper loaded: form_helper
INFO - 2024-10-10 06:28:26 --> Helper loaded: my_helper
INFO - 2024-10-10 06:28:26 --> Database Driver Class Initialized
INFO - 2024-10-10 06:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:28:26 --> Controller Class Initialized
DEBUG - 2024-10-10 06:28:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-10 06:28:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 06:28:26 --> Final output sent to browser
DEBUG - 2024-10-10 06:28:26 --> Total execution time: 0.0259
INFO - 2024-10-10 06:28:28 --> Config Class Initialized
INFO - 2024-10-10 06:28:28 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:28:28 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:28:28 --> Utf8 Class Initialized
INFO - 2024-10-10 06:28:28 --> URI Class Initialized
INFO - 2024-10-10 06:28:28 --> Router Class Initialized
INFO - 2024-10-10 06:28:28 --> Output Class Initialized
INFO - 2024-10-10 06:28:28 --> Security Class Initialized
DEBUG - 2024-10-10 06:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:28:28 --> Input Class Initialized
INFO - 2024-10-10 06:28:28 --> Language Class Initialized
INFO - 2024-10-10 06:28:28 --> Language Class Initialized
INFO - 2024-10-10 06:28:28 --> Config Class Initialized
INFO - 2024-10-10 06:28:28 --> Loader Class Initialized
INFO - 2024-10-10 06:28:28 --> Helper loaded: url_helper
INFO - 2024-10-10 06:28:28 --> Helper loaded: file_helper
INFO - 2024-10-10 06:28:28 --> Helper loaded: form_helper
INFO - 2024-10-10 06:28:28 --> Helper loaded: my_helper
INFO - 2024-10-10 06:28:28 --> Database Driver Class Initialized
INFO - 2024-10-10 06:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:28:28 --> Controller Class Initialized
DEBUG - 2024-10-10 06:28:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-10 06:28:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 06:28:28 --> Final output sent to browser
DEBUG - 2024-10-10 06:28:28 --> Total execution time: 0.0311
INFO - 2024-10-10 06:28:28 --> Config Class Initialized
INFO - 2024-10-10 06:28:28 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:28:28 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:28:28 --> Utf8 Class Initialized
INFO - 2024-10-10 06:28:28 --> URI Class Initialized
INFO - 2024-10-10 06:28:28 --> Router Class Initialized
INFO - 2024-10-10 06:28:28 --> Output Class Initialized
INFO - 2024-10-10 06:28:28 --> Security Class Initialized
DEBUG - 2024-10-10 06:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:28:28 --> Input Class Initialized
INFO - 2024-10-10 06:28:28 --> Language Class Initialized
INFO - 2024-10-10 06:28:28 --> Language Class Initialized
INFO - 2024-10-10 06:28:28 --> Config Class Initialized
INFO - 2024-10-10 06:28:28 --> Loader Class Initialized
INFO - 2024-10-10 06:28:28 --> Helper loaded: url_helper
INFO - 2024-10-10 06:28:28 --> Helper loaded: file_helper
INFO - 2024-10-10 06:28:28 --> Helper loaded: form_helper
INFO - 2024-10-10 06:28:28 --> Helper loaded: my_helper
INFO - 2024-10-10 06:28:28 --> Database Driver Class Initialized
INFO - 2024-10-10 06:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:28:28 --> Controller Class Initialized
INFO - 2024-10-10 06:28:35 --> Config Class Initialized
INFO - 2024-10-10 06:28:35 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:28:35 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:28:35 --> Utf8 Class Initialized
INFO - 2024-10-10 06:28:35 --> URI Class Initialized
INFO - 2024-10-10 06:28:35 --> Router Class Initialized
INFO - 2024-10-10 06:28:35 --> Output Class Initialized
INFO - 2024-10-10 06:28:35 --> Security Class Initialized
DEBUG - 2024-10-10 06:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:28:35 --> Input Class Initialized
INFO - 2024-10-10 06:28:35 --> Language Class Initialized
INFO - 2024-10-10 06:28:35 --> Language Class Initialized
INFO - 2024-10-10 06:28:35 --> Config Class Initialized
INFO - 2024-10-10 06:28:35 --> Loader Class Initialized
INFO - 2024-10-10 06:28:35 --> Helper loaded: url_helper
INFO - 2024-10-10 06:28:35 --> Helper loaded: file_helper
INFO - 2024-10-10 06:28:35 --> Helper loaded: form_helper
INFO - 2024-10-10 06:28:35 --> Helper loaded: my_helper
INFO - 2024-10-10 06:28:35 --> Database Driver Class Initialized
INFO - 2024-10-10 06:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:28:35 --> Controller Class Initialized
INFO - 2024-10-10 06:28:36 --> Config Class Initialized
INFO - 2024-10-10 06:28:36 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:28:36 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:28:36 --> Utf8 Class Initialized
INFO - 2024-10-10 06:28:36 --> URI Class Initialized
INFO - 2024-10-10 06:28:36 --> Router Class Initialized
INFO - 2024-10-10 06:28:36 --> Output Class Initialized
INFO - 2024-10-10 06:28:36 --> Security Class Initialized
DEBUG - 2024-10-10 06:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:28:36 --> Input Class Initialized
INFO - 2024-10-10 06:28:36 --> Language Class Initialized
INFO - 2024-10-10 06:28:36 --> Language Class Initialized
INFO - 2024-10-10 06:28:36 --> Config Class Initialized
INFO - 2024-10-10 06:28:36 --> Loader Class Initialized
INFO - 2024-10-10 06:28:36 --> Helper loaded: url_helper
INFO - 2024-10-10 06:28:36 --> Helper loaded: file_helper
INFO - 2024-10-10 06:28:36 --> Helper loaded: form_helper
INFO - 2024-10-10 06:28:36 --> Helper loaded: my_helper
INFO - 2024-10-10 06:28:36 --> Database Driver Class Initialized
INFO - 2024-10-10 06:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:28:36 --> Controller Class Initialized
DEBUG - 2024-10-10 06:28:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-10 06:28:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 06:28:36 --> Final output sent to browser
DEBUG - 2024-10-10 06:28:36 --> Total execution time: 0.0267
INFO - 2024-10-10 06:28:38 --> Config Class Initialized
INFO - 2024-10-10 06:28:38 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:28:38 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:28:38 --> Utf8 Class Initialized
INFO - 2024-10-10 06:28:38 --> URI Class Initialized
INFO - 2024-10-10 06:28:38 --> Router Class Initialized
INFO - 2024-10-10 06:28:38 --> Output Class Initialized
INFO - 2024-10-10 06:28:38 --> Security Class Initialized
DEBUG - 2024-10-10 06:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:28:38 --> Input Class Initialized
INFO - 2024-10-10 06:28:38 --> Language Class Initialized
INFO - 2024-10-10 06:28:38 --> Language Class Initialized
INFO - 2024-10-10 06:28:38 --> Config Class Initialized
INFO - 2024-10-10 06:28:38 --> Loader Class Initialized
INFO - 2024-10-10 06:28:38 --> Helper loaded: url_helper
INFO - 2024-10-10 06:28:38 --> Helper loaded: file_helper
INFO - 2024-10-10 06:28:38 --> Helper loaded: form_helper
INFO - 2024-10-10 06:28:38 --> Helper loaded: my_helper
INFO - 2024-10-10 06:28:38 --> Database Driver Class Initialized
INFO - 2024-10-10 06:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:28:38 --> Controller Class Initialized
DEBUG - 2024-10-10 06:28:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-10 06:28:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 06:28:38 --> Final output sent to browser
DEBUG - 2024-10-10 06:28:38 --> Total execution time: 0.0328
INFO - 2024-10-10 06:28:38 --> Config Class Initialized
INFO - 2024-10-10 06:28:38 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:28:38 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:28:38 --> Utf8 Class Initialized
INFO - 2024-10-10 06:28:38 --> URI Class Initialized
INFO - 2024-10-10 06:28:38 --> Router Class Initialized
INFO - 2024-10-10 06:28:38 --> Output Class Initialized
INFO - 2024-10-10 06:28:38 --> Security Class Initialized
DEBUG - 2024-10-10 06:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:28:38 --> Input Class Initialized
INFO - 2024-10-10 06:28:38 --> Language Class Initialized
INFO - 2024-10-10 06:28:38 --> Language Class Initialized
INFO - 2024-10-10 06:28:38 --> Config Class Initialized
INFO - 2024-10-10 06:28:38 --> Loader Class Initialized
INFO - 2024-10-10 06:28:38 --> Helper loaded: url_helper
INFO - 2024-10-10 06:28:38 --> Helper loaded: file_helper
INFO - 2024-10-10 06:28:38 --> Helper loaded: form_helper
INFO - 2024-10-10 06:28:38 --> Helper loaded: my_helper
INFO - 2024-10-10 06:28:38 --> Database Driver Class Initialized
INFO - 2024-10-10 06:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:28:38 --> Controller Class Initialized
INFO - 2024-10-10 06:28:40 --> Config Class Initialized
INFO - 2024-10-10 06:28:40 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:28:40 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:28:40 --> Utf8 Class Initialized
INFO - 2024-10-10 06:28:40 --> URI Class Initialized
INFO - 2024-10-10 06:28:40 --> Router Class Initialized
INFO - 2024-10-10 06:28:40 --> Output Class Initialized
INFO - 2024-10-10 06:28:40 --> Security Class Initialized
DEBUG - 2024-10-10 06:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:28:40 --> Input Class Initialized
INFO - 2024-10-10 06:28:40 --> Language Class Initialized
INFO - 2024-10-10 06:28:40 --> Language Class Initialized
INFO - 2024-10-10 06:28:40 --> Config Class Initialized
INFO - 2024-10-10 06:28:40 --> Loader Class Initialized
INFO - 2024-10-10 06:28:40 --> Helper loaded: url_helper
INFO - 2024-10-10 06:28:40 --> Helper loaded: file_helper
INFO - 2024-10-10 06:28:40 --> Helper loaded: form_helper
INFO - 2024-10-10 06:28:40 --> Helper loaded: my_helper
INFO - 2024-10-10 06:28:40 --> Database Driver Class Initialized
INFO - 2024-10-10 06:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:28:40 --> Controller Class Initialized
INFO - 2024-10-10 06:28:40 --> Final output sent to browser
DEBUG - 2024-10-10 06:28:40 --> Total execution time: 0.0420
INFO - 2024-10-10 06:28:49 --> Config Class Initialized
INFO - 2024-10-10 06:28:49 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:28:49 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:28:49 --> Utf8 Class Initialized
INFO - 2024-10-10 06:28:49 --> URI Class Initialized
INFO - 2024-10-10 06:28:49 --> Router Class Initialized
INFO - 2024-10-10 06:28:49 --> Output Class Initialized
INFO - 2024-10-10 06:28:49 --> Security Class Initialized
DEBUG - 2024-10-10 06:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:28:49 --> Input Class Initialized
INFO - 2024-10-10 06:28:49 --> Language Class Initialized
INFO - 2024-10-10 06:28:49 --> Language Class Initialized
INFO - 2024-10-10 06:28:49 --> Config Class Initialized
INFO - 2024-10-10 06:28:49 --> Loader Class Initialized
INFO - 2024-10-10 06:28:49 --> Helper loaded: url_helper
INFO - 2024-10-10 06:28:49 --> Helper loaded: file_helper
INFO - 2024-10-10 06:28:49 --> Helper loaded: form_helper
INFO - 2024-10-10 06:28:49 --> Helper loaded: my_helper
INFO - 2024-10-10 06:28:49 --> Database Driver Class Initialized
INFO - 2024-10-10 06:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:28:49 --> Controller Class Initialized
INFO - 2024-10-10 06:28:49 --> Final output sent to browser
DEBUG - 2024-10-10 06:28:49 --> Total execution time: 0.0293
INFO - 2024-10-10 06:28:49 --> Config Class Initialized
INFO - 2024-10-10 06:28:49 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:28:49 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:28:49 --> Utf8 Class Initialized
INFO - 2024-10-10 06:28:49 --> URI Class Initialized
INFO - 2024-10-10 06:28:49 --> Router Class Initialized
INFO - 2024-10-10 06:28:49 --> Output Class Initialized
INFO - 2024-10-10 06:28:49 --> Security Class Initialized
DEBUG - 2024-10-10 06:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:28:49 --> Input Class Initialized
INFO - 2024-10-10 06:28:49 --> Language Class Initialized
INFO - 2024-10-10 06:28:49 --> Language Class Initialized
INFO - 2024-10-10 06:28:49 --> Config Class Initialized
INFO - 2024-10-10 06:28:49 --> Loader Class Initialized
INFO - 2024-10-10 06:28:49 --> Helper loaded: url_helper
INFO - 2024-10-10 06:28:49 --> Helper loaded: file_helper
INFO - 2024-10-10 06:28:49 --> Helper loaded: form_helper
INFO - 2024-10-10 06:28:49 --> Helper loaded: my_helper
INFO - 2024-10-10 06:28:49 --> Database Driver Class Initialized
INFO - 2024-10-10 06:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:28:49 --> Controller Class Initialized
INFO - 2024-10-10 06:28:51 --> Config Class Initialized
INFO - 2024-10-10 06:28:51 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:28:51 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:28:51 --> Utf8 Class Initialized
INFO - 2024-10-10 06:28:51 --> URI Class Initialized
INFO - 2024-10-10 06:28:51 --> Router Class Initialized
INFO - 2024-10-10 06:28:51 --> Output Class Initialized
INFO - 2024-10-10 06:28:51 --> Security Class Initialized
DEBUG - 2024-10-10 06:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:28:51 --> Input Class Initialized
INFO - 2024-10-10 06:28:51 --> Language Class Initialized
INFO - 2024-10-10 06:28:51 --> Language Class Initialized
INFO - 2024-10-10 06:28:51 --> Config Class Initialized
INFO - 2024-10-10 06:28:51 --> Loader Class Initialized
INFO - 2024-10-10 06:28:51 --> Helper loaded: url_helper
INFO - 2024-10-10 06:28:51 --> Helper loaded: file_helper
INFO - 2024-10-10 06:28:51 --> Helper loaded: form_helper
INFO - 2024-10-10 06:28:51 --> Helper loaded: my_helper
INFO - 2024-10-10 06:28:51 --> Database Driver Class Initialized
INFO - 2024-10-10 06:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:28:51 --> Controller Class Initialized
INFO - 2024-10-10 06:39:34 --> Config Class Initialized
INFO - 2024-10-10 06:39:34 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:39:34 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:39:34 --> Utf8 Class Initialized
INFO - 2024-10-10 06:39:34 --> URI Class Initialized
INFO - 2024-10-10 06:39:34 --> Router Class Initialized
INFO - 2024-10-10 06:39:34 --> Output Class Initialized
INFO - 2024-10-10 06:39:34 --> Security Class Initialized
DEBUG - 2024-10-10 06:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:39:34 --> Input Class Initialized
INFO - 2024-10-10 06:39:34 --> Language Class Initialized
INFO - 2024-10-10 06:39:34 --> Language Class Initialized
INFO - 2024-10-10 06:39:34 --> Config Class Initialized
INFO - 2024-10-10 06:39:34 --> Loader Class Initialized
INFO - 2024-10-10 06:39:34 --> Helper loaded: url_helper
INFO - 2024-10-10 06:39:34 --> Helper loaded: file_helper
INFO - 2024-10-10 06:39:34 --> Helper loaded: form_helper
INFO - 2024-10-10 06:39:34 --> Helper loaded: my_helper
INFO - 2024-10-10 06:39:34 --> Database Driver Class Initialized
INFO - 2024-10-10 06:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:39:34 --> Controller Class Initialized
DEBUG - 2024-10-10 06:39:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-10 06:39:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 06:39:34 --> Final output sent to browser
DEBUG - 2024-10-10 06:39:34 --> Total execution time: 0.0639
INFO - 2024-10-10 06:39:42 --> Config Class Initialized
INFO - 2024-10-10 06:39:42 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:39:42 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:39:42 --> Utf8 Class Initialized
INFO - 2024-10-10 06:39:42 --> URI Class Initialized
INFO - 2024-10-10 06:39:42 --> Router Class Initialized
INFO - 2024-10-10 06:39:42 --> Output Class Initialized
INFO - 2024-10-10 06:39:42 --> Security Class Initialized
DEBUG - 2024-10-10 06:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:39:42 --> Input Class Initialized
INFO - 2024-10-10 06:39:42 --> Language Class Initialized
INFO - 2024-10-10 06:39:42 --> Language Class Initialized
INFO - 2024-10-10 06:39:42 --> Config Class Initialized
INFO - 2024-10-10 06:39:42 --> Loader Class Initialized
INFO - 2024-10-10 06:39:42 --> Helper loaded: url_helper
INFO - 2024-10-10 06:39:42 --> Helper loaded: file_helper
INFO - 2024-10-10 06:39:42 --> Helper loaded: form_helper
INFO - 2024-10-10 06:39:42 --> Helper loaded: my_helper
INFO - 2024-10-10 06:39:42 --> Database Driver Class Initialized
INFO - 2024-10-10 06:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:39:42 --> Controller Class Initialized
INFO - 2024-10-10 06:39:42 --> Config Class Initialized
INFO - 2024-10-10 06:39:42 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:39:42 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:39:42 --> Utf8 Class Initialized
INFO - 2024-10-10 06:39:42 --> URI Class Initialized
INFO - 2024-10-10 06:39:42 --> Router Class Initialized
INFO - 2024-10-10 06:39:42 --> Output Class Initialized
INFO - 2024-10-10 06:39:42 --> Security Class Initialized
DEBUG - 2024-10-10 06:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:39:42 --> Input Class Initialized
INFO - 2024-10-10 06:39:42 --> Language Class Initialized
INFO - 2024-10-10 06:39:42 --> Language Class Initialized
INFO - 2024-10-10 06:39:42 --> Config Class Initialized
INFO - 2024-10-10 06:39:42 --> Loader Class Initialized
INFO - 2024-10-10 06:39:42 --> Helper loaded: url_helper
INFO - 2024-10-10 06:39:42 --> Helper loaded: file_helper
INFO - 2024-10-10 06:39:42 --> Helper loaded: form_helper
INFO - 2024-10-10 06:39:42 --> Helper loaded: my_helper
INFO - 2024-10-10 06:39:42 --> Database Driver Class Initialized
INFO - 2024-10-10 06:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:39:42 --> Controller Class Initialized
DEBUG - 2024-10-10 06:39:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-10 06:39:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 06:39:42 --> Final output sent to browser
DEBUG - 2024-10-10 06:39:42 --> Total execution time: 0.0384
INFO - 2024-10-10 06:39:42 --> Config Class Initialized
INFO - 2024-10-10 06:39:42 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:39:42 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:39:42 --> Utf8 Class Initialized
INFO - 2024-10-10 06:39:42 --> URI Class Initialized
INFO - 2024-10-10 06:39:42 --> Router Class Initialized
INFO - 2024-10-10 06:39:42 --> Output Class Initialized
INFO - 2024-10-10 06:39:42 --> Security Class Initialized
DEBUG - 2024-10-10 06:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:39:42 --> Input Class Initialized
INFO - 2024-10-10 06:39:42 --> Language Class Initialized
INFO - 2024-10-10 06:39:42 --> Language Class Initialized
INFO - 2024-10-10 06:39:42 --> Config Class Initialized
INFO - 2024-10-10 06:39:42 --> Loader Class Initialized
INFO - 2024-10-10 06:39:42 --> Helper loaded: url_helper
INFO - 2024-10-10 06:39:42 --> Helper loaded: file_helper
INFO - 2024-10-10 06:39:42 --> Helper loaded: form_helper
INFO - 2024-10-10 06:39:42 --> Helper loaded: my_helper
INFO - 2024-10-10 06:39:42 --> Database Driver Class Initialized
INFO - 2024-10-10 06:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:39:42 --> Controller Class Initialized
INFO - 2024-10-10 06:39:44 --> Config Class Initialized
INFO - 2024-10-10 06:39:44 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:39:44 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:39:44 --> Utf8 Class Initialized
INFO - 2024-10-10 06:39:44 --> URI Class Initialized
INFO - 2024-10-10 06:39:44 --> Router Class Initialized
INFO - 2024-10-10 06:39:44 --> Output Class Initialized
INFO - 2024-10-10 06:39:44 --> Security Class Initialized
DEBUG - 2024-10-10 06:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:39:44 --> Input Class Initialized
INFO - 2024-10-10 06:39:44 --> Language Class Initialized
INFO - 2024-10-10 06:39:44 --> Language Class Initialized
INFO - 2024-10-10 06:39:44 --> Config Class Initialized
INFO - 2024-10-10 06:39:44 --> Loader Class Initialized
INFO - 2024-10-10 06:39:44 --> Helper loaded: url_helper
INFO - 2024-10-10 06:39:44 --> Helper loaded: file_helper
INFO - 2024-10-10 06:39:44 --> Helper loaded: form_helper
INFO - 2024-10-10 06:39:44 --> Helper loaded: my_helper
INFO - 2024-10-10 06:39:44 --> Database Driver Class Initialized
INFO - 2024-10-10 06:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:39:44 --> Controller Class Initialized
INFO - 2024-10-10 06:39:44 --> Final output sent to browser
DEBUG - 2024-10-10 06:39:44 --> Total execution time: 0.0311
INFO - 2024-10-10 06:39:49 --> Config Class Initialized
INFO - 2024-10-10 06:39:49 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:39:49 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:39:49 --> Utf8 Class Initialized
INFO - 2024-10-10 06:39:49 --> URI Class Initialized
INFO - 2024-10-10 06:39:49 --> Router Class Initialized
INFO - 2024-10-10 06:39:49 --> Output Class Initialized
INFO - 2024-10-10 06:39:49 --> Security Class Initialized
DEBUG - 2024-10-10 06:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:39:49 --> Input Class Initialized
INFO - 2024-10-10 06:39:49 --> Language Class Initialized
INFO - 2024-10-10 06:39:49 --> Language Class Initialized
INFO - 2024-10-10 06:39:49 --> Config Class Initialized
INFO - 2024-10-10 06:39:49 --> Loader Class Initialized
INFO - 2024-10-10 06:39:49 --> Helper loaded: url_helper
INFO - 2024-10-10 06:39:49 --> Helper loaded: file_helper
INFO - 2024-10-10 06:39:49 --> Helper loaded: form_helper
INFO - 2024-10-10 06:39:49 --> Helper loaded: my_helper
INFO - 2024-10-10 06:39:49 --> Database Driver Class Initialized
INFO - 2024-10-10 06:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:39:49 --> Controller Class Initialized
DEBUG - 2024-10-10 06:39:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-10 06:39:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 06:39:49 --> Final output sent to browser
DEBUG - 2024-10-10 06:39:49 --> Total execution time: 0.0264
INFO - 2024-10-10 06:39:51 --> Config Class Initialized
INFO - 2024-10-10 06:39:51 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:39:51 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:39:51 --> Utf8 Class Initialized
INFO - 2024-10-10 06:39:51 --> URI Class Initialized
INFO - 2024-10-10 06:39:51 --> Router Class Initialized
INFO - 2024-10-10 06:39:51 --> Output Class Initialized
INFO - 2024-10-10 06:39:51 --> Security Class Initialized
DEBUG - 2024-10-10 06:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:39:51 --> Input Class Initialized
INFO - 2024-10-10 06:39:51 --> Language Class Initialized
INFO - 2024-10-10 06:39:51 --> Language Class Initialized
INFO - 2024-10-10 06:39:51 --> Config Class Initialized
INFO - 2024-10-10 06:39:51 --> Loader Class Initialized
INFO - 2024-10-10 06:39:51 --> Helper loaded: url_helper
INFO - 2024-10-10 06:39:51 --> Helper loaded: file_helper
INFO - 2024-10-10 06:39:51 --> Helper loaded: form_helper
INFO - 2024-10-10 06:39:51 --> Helper loaded: my_helper
INFO - 2024-10-10 06:39:51 --> Database Driver Class Initialized
INFO - 2024-10-10 06:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:39:51 --> Controller Class Initialized
DEBUG - 2024-10-10 06:39:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-10 06:39:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 06:39:51 --> Final output sent to browser
DEBUG - 2024-10-10 06:39:51 --> Total execution time: 0.0424
INFO - 2024-10-10 06:39:51 --> Config Class Initialized
INFO - 2024-10-10 06:39:51 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:39:51 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:39:51 --> Utf8 Class Initialized
INFO - 2024-10-10 06:39:51 --> URI Class Initialized
INFO - 2024-10-10 06:39:51 --> Router Class Initialized
INFO - 2024-10-10 06:39:51 --> Output Class Initialized
INFO - 2024-10-10 06:39:51 --> Security Class Initialized
DEBUG - 2024-10-10 06:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:39:51 --> Input Class Initialized
INFO - 2024-10-10 06:39:51 --> Language Class Initialized
INFO - 2024-10-10 06:39:51 --> Language Class Initialized
INFO - 2024-10-10 06:39:51 --> Config Class Initialized
INFO - 2024-10-10 06:39:51 --> Loader Class Initialized
INFO - 2024-10-10 06:39:51 --> Helper loaded: url_helper
INFO - 2024-10-10 06:39:51 --> Helper loaded: file_helper
INFO - 2024-10-10 06:39:51 --> Helper loaded: form_helper
INFO - 2024-10-10 06:39:51 --> Helper loaded: my_helper
INFO - 2024-10-10 06:39:51 --> Database Driver Class Initialized
INFO - 2024-10-10 06:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:39:51 --> Controller Class Initialized
INFO - 2024-10-10 06:39:53 --> Config Class Initialized
INFO - 2024-10-10 06:39:53 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:39:53 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:39:53 --> Utf8 Class Initialized
INFO - 2024-10-10 06:39:53 --> URI Class Initialized
INFO - 2024-10-10 06:39:53 --> Router Class Initialized
INFO - 2024-10-10 06:39:53 --> Output Class Initialized
INFO - 2024-10-10 06:39:53 --> Security Class Initialized
DEBUG - 2024-10-10 06:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:39:53 --> Input Class Initialized
INFO - 2024-10-10 06:39:53 --> Language Class Initialized
INFO - 2024-10-10 06:39:53 --> Language Class Initialized
INFO - 2024-10-10 06:39:53 --> Config Class Initialized
INFO - 2024-10-10 06:39:53 --> Loader Class Initialized
INFO - 2024-10-10 06:39:53 --> Helper loaded: url_helper
INFO - 2024-10-10 06:39:53 --> Helper loaded: file_helper
INFO - 2024-10-10 06:39:53 --> Helper loaded: form_helper
INFO - 2024-10-10 06:39:53 --> Helper loaded: my_helper
INFO - 2024-10-10 06:39:53 --> Database Driver Class Initialized
INFO - 2024-10-10 06:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:39:53 --> Controller Class Initialized
DEBUG - 2024-10-10 06:39:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-10 06:39:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 06:39:53 --> Final output sent to browser
DEBUG - 2024-10-10 06:39:53 --> Total execution time: 0.0298
INFO - 2024-10-10 06:39:59 --> Config Class Initialized
INFO - 2024-10-10 06:39:59 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:39:59 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:39:59 --> Utf8 Class Initialized
INFO - 2024-10-10 06:39:59 --> URI Class Initialized
INFO - 2024-10-10 06:39:59 --> Router Class Initialized
INFO - 2024-10-10 06:39:59 --> Output Class Initialized
INFO - 2024-10-10 06:39:59 --> Security Class Initialized
DEBUG - 2024-10-10 06:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:39:59 --> Input Class Initialized
INFO - 2024-10-10 06:39:59 --> Language Class Initialized
INFO - 2024-10-10 06:39:59 --> Language Class Initialized
INFO - 2024-10-10 06:39:59 --> Config Class Initialized
INFO - 2024-10-10 06:39:59 --> Loader Class Initialized
INFO - 2024-10-10 06:39:59 --> Helper loaded: url_helper
INFO - 2024-10-10 06:39:59 --> Helper loaded: file_helper
INFO - 2024-10-10 06:39:59 --> Helper loaded: form_helper
INFO - 2024-10-10 06:39:59 --> Helper loaded: my_helper
INFO - 2024-10-10 06:39:59 --> Database Driver Class Initialized
INFO - 2024-10-10 06:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:39:59 --> Controller Class Initialized
INFO - 2024-10-10 06:39:59 --> Config Class Initialized
INFO - 2024-10-10 06:39:59 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:39:59 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:39:59 --> Utf8 Class Initialized
INFO - 2024-10-10 06:39:59 --> URI Class Initialized
INFO - 2024-10-10 06:39:59 --> Router Class Initialized
INFO - 2024-10-10 06:39:59 --> Output Class Initialized
INFO - 2024-10-10 06:39:59 --> Security Class Initialized
DEBUG - 2024-10-10 06:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:39:59 --> Input Class Initialized
INFO - 2024-10-10 06:39:59 --> Language Class Initialized
INFO - 2024-10-10 06:39:59 --> Language Class Initialized
INFO - 2024-10-10 06:39:59 --> Config Class Initialized
INFO - 2024-10-10 06:39:59 --> Loader Class Initialized
INFO - 2024-10-10 06:39:59 --> Helper loaded: url_helper
INFO - 2024-10-10 06:39:59 --> Helper loaded: file_helper
INFO - 2024-10-10 06:39:59 --> Helper loaded: form_helper
INFO - 2024-10-10 06:39:59 --> Helper loaded: my_helper
INFO - 2024-10-10 06:39:59 --> Database Driver Class Initialized
INFO - 2024-10-10 06:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:39:59 --> Controller Class Initialized
DEBUG - 2024-10-10 06:39:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-10 06:39:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 06:39:59 --> Final output sent to browser
DEBUG - 2024-10-10 06:39:59 --> Total execution time: 0.0326
INFO - 2024-10-10 06:39:59 --> Config Class Initialized
INFO - 2024-10-10 06:39:59 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:39:59 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:39:59 --> Utf8 Class Initialized
INFO - 2024-10-10 06:39:59 --> URI Class Initialized
INFO - 2024-10-10 06:39:59 --> Router Class Initialized
INFO - 2024-10-10 06:39:59 --> Output Class Initialized
INFO - 2024-10-10 06:39:59 --> Security Class Initialized
DEBUG - 2024-10-10 06:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:39:59 --> Input Class Initialized
INFO - 2024-10-10 06:39:59 --> Language Class Initialized
INFO - 2024-10-10 06:39:59 --> Language Class Initialized
INFO - 2024-10-10 06:39:59 --> Config Class Initialized
INFO - 2024-10-10 06:39:59 --> Loader Class Initialized
INFO - 2024-10-10 06:39:59 --> Helper loaded: url_helper
INFO - 2024-10-10 06:39:59 --> Helper loaded: file_helper
INFO - 2024-10-10 06:39:59 --> Helper loaded: form_helper
INFO - 2024-10-10 06:39:59 --> Helper loaded: my_helper
INFO - 2024-10-10 06:39:59 --> Database Driver Class Initialized
INFO - 2024-10-10 06:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:39:59 --> Controller Class Initialized
INFO - 2024-10-10 06:40:01 --> Config Class Initialized
INFO - 2024-10-10 06:40:01 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:40:01 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:40:01 --> Utf8 Class Initialized
INFO - 2024-10-10 06:40:01 --> URI Class Initialized
INFO - 2024-10-10 06:40:01 --> Router Class Initialized
INFO - 2024-10-10 06:40:01 --> Output Class Initialized
INFO - 2024-10-10 06:40:01 --> Security Class Initialized
DEBUG - 2024-10-10 06:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:40:01 --> Input Class Initialized
INFO - 2024-10-10 06:40:01 --> Language Class Initialized
INFO - 2024-10-10 06:40:01 --> Language Class Initialized
INFO - 2024-10-10 06:40:01 --> Config Class Initialized
INFO - 2024-10-10 06:40:01 --> Loader Class Initialized
INFO - 2024-10-10 06:40:01 --> Helper loaded: url_helper
INFO - 2024-10-10 06:40:01 --> Helper loaded: file_helper
INFO - 2024-10-10 06:40:01 --> Helper loaded: form_helper
INFO - 2024-10-10 06:40:01 --> Helper loaded: my_helper
INFO - 2024-10-10 06:40:01 --> Database Driver Class Initialized
INFO - 2024-10-10 06:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:40:01 --> Controller Class Initialized
DEBUG - 2024-10-10 06:40:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-10 06:40:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 06:40:01 --> Final output sent to browser
DEBUG - 2024-10-10 06:40:01 --> Total execution time: 0.0389
INFO - 2024-10-10 06:40:03 --> Config Class Initialized
INFO - 2024-10-10 06:40:03 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:40:03 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:40:03 --> Utf8 Class Initialized
INFO - 2024-10-10 06:40:03 --> URI Class Initialized
INFO - 2024-10-10 06:40:03 --> Router Class Initialized
INFO - 2024-10-10 06:40:03 --> Output Class Initialized
INFO - 2024-10-10 06:40:03 --> Security Class Initialized
DEBUG - 2024-10-10 06:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:40:03 --> Input Class Initialized
INFO - 2024-10-10 06:40:03 --> Language Class Initialized
INFO - 2024-10-10 06:40:03 --> Language Class Initialized
INFO - 2024-10-10 06:40:03 --> Config Class Initialized
INFO - 2024-10-10 06:40:03 --> Loader Class Initialized
INFO - 2024-10-10 06:40:03 --> Helper loaded: url_helper
INFO - 2024-10-10 06:40:03 --> Helper loaded: file_helper
INFO - 2024-10-10 06:40:03 --> Helper loaded: form_helper
INFO - 2024-10-10 06:40:03 --> Helper loaded: my_helper
INFO - 2024-10-10 06:40:03 --> Database Driver Class Initialized
INFO - 2024-10-10 06:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:40:03 --> Controller Class Initialized
DEBUG - 2024-10-10 06:40:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-10 06:40:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 06:40:03 --> Final output sent to browser
DEBUG - 2024-10-10 06:40:03 --> Total execution time: 0.0403
INFO - 2024-10-10 06:40:03 --> Config Class Initialized
INFO - 2024-10-10 06:40:03 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:40:03 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:40:03 --> Utf8 Class Initialized
INFO - 2024-10-10 06:40:03 --> URI Class Initialized
INFO - 2024-10-10 06:40:03 --> Router Class Initialized
INFO - 2024-10-10 06:40:03 --> Output Class Initialized
INFO - 2024-10-10 06:40:03 --> Security Class Initialized
DEBUG - 2024-10-10 06:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:40:03 --> Input Class Initialized
INFO - 2024-10-10 06:40:03 --> Language Class Initialized
INFO - 2024-10-10 06:40:03 --> Language Class Initialized
INFO - 2024-10-10 06:40:03 --> Config Class Initialized
INFO - 2024-10-10 06:40:03 --> Loader Class Initialized
INFO - 2024-10-10 06:40:03 --> Helper loaded: url_helper
INFO - 2024-10-10 06:40:03 --> Helper loaded: file_helper
INFO - 2024-10-10 06:40:03 --> Helper loaded: form_helper
INFO - 2024-10-10 06:40:03 --> Helper loaded: my_helper
INFO - 2024-10-10 06:40:03 --> Database Driver Class Initialized
INFO - 2024-10-10 06:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:40:03 --> Controller Class Initialized
INFO - 2024-10-10 06:40:04 --> Config Class Initialized
INFO - 2024-10-10 06:40:04 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:40:04 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:40:04 --> Utf8 Class Initialized
INFO - 2024-10-10 06:40:04 --> URI Class Initialized
INFO - 2024-10-10 06:40:04 --> Router Class Initialized
INFO - 2024-10-10 06:40:04 --> Output Class Initialized
INFO - 2024-10-10 06:40:04 --> Security Class Initialized
DEBUG - 2024-10-10 06:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:40:04 --> Input Class Initialized
INFO - 2024-10-10 06:40:04 --> Language Class Initialized
INFO - 2024-10-10 06:40:04 --> Language Class Initialized
INFO - 2024-10-10 06:40:04 --> Config Class Initialized
INFO - 2024-10-10 06:40:04 --> Loader Class Initialized
INFO - 2024-10-10 06:40:04 --> Helper loaded: url_helper
INFO - 2024-10-10 06:40:04 --> Helper loaded: file_helper
INFO - 2024-10-10 06:40:04 --> Helper loaded: form_helper
INFO - 2024-10-10 06:40:04 --> Helper loaded: my_helper
INFO - 2024-10-10 06:40:04 --> Database Driver Class Initialized
INFO - 2024-10-10 06:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:40:04 --> Controller Class Initialized
DEBUG - 2024-10-10 06:40:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-10 06:40:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 06:40:04 --> Final output sent to browser
DEBUG - 2024-10-10 06:40:04 --> Total execution time: 0.0787
INFO - 2024-10-10 06:40:10 --> Config Class Initialized
INFO - 2024-10-10 06:40:10 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:40:10 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:40:10 --> Utf8 Class Initialized
INFO - 2024-10-10 06:40:10 --> URI Class Initialized
INFO - 2024-10-10 06:40:10 --> Router Class Initialized
INFO - 2024-10-10 06:40:10 --> Output Class Initialized
INFO - 2024-10-10 06:40:10 --> Security Class Initialized
DEBUG - 2024-10-10 06:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:40:10 --> Input Class Initialized
INFO - 2024-10-10 06:40:10 --> Language Class Initialized
INFO - 2024-10-10 06:40:10 --> Language Class Initialized
INFO - 2024-10-10 06:40:10 --> Config Class Initialized
INFO - 2024-10-10 06:40:10 --> Loader Class Initialized
INFO - 2024-10-10 06:40:10 --> Helper loaded: url_helper
INFO - 2024-10-10 06:40:10 --> Helper loaded: file_helper
INFO - 2024-10-10 06:40:10 --> Helper loaded: form_helper
INFO - 2024-10-10 06:40:10 --> Helper loaded: my_helper
INFO - 2024-10-10 06:40:10 --> Database Driver Class Initialized
INFO - 2024-10-10 06:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:40:10 --> Controller Class Initialized
INFO - 2024-10-10 06:40:11 --> Config Class Initialized
INFO - 2024-10-10 06:40:11 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:40:11 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:40:11 --> Utf8 Class Initialized
INFO - 2024-10-10 06:40:11 --> URI Class Initialized
INFO - 2024-10-10 06:40:11 --> Router Class Initialized
INFO - 2024-10-10 06:40:11 --> Output Class Initialized
INFO - 2024-10-10 06:40:11 --> Security Class Initialized
DEBUG - 2024-10-10 06:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:40:11 --> Input Class Initialized
INFO - 2024-10-10 06:40:11 --> Language Class Initialized
INFO - 2024-10-10 06:40:11 --> Language Class Initialized
INFO - 2024-10-10 06:40:11 --> Config Class Initialized
INFO - 2024-10-10 06:40:11 --> Loader Class Initialized
INFO - 2024-10-10 06:40:11 --> Helper loaded: url_helper
INFO - 2024-10-10 06:40:11 --> Helper loaded: file_helper
INFO - 2024-10-10 06:40:11 --> Helper loaded: form_helper
INFO - 2024-10-10 06:40:11 --> Helper loaded: my_helper
INFO - 2024-10-10 06:40:11 --> Database Driver Class Initialized
INFO - 2024-10-10 06:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:40:11 --> Controller Class Initialized
DEBUG - 2024-10-10 06:40:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-10 06:40:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 06:40:11 --> Final output sent to browser
DEBUG - 2024-10-10 06:40:11 --> Total execution time: 0.0292
INFO - 2024-10-10 06:40:11 --> Config Class Initialized
INFO - 2024-10-10 06:40:11 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:40:11 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:40:11 --> Utf8 Class Initialized
INFO - 2024-10-10 06:40:11 --> URI Class Initialized
INFO - 2024-10-10 06:40:11 --> Router Class Initialized
INFO - 2024-10-10 06:40:11 --> Output Class Initialized
INFO - 2024-10-10 06:40:11 --> Security Class Initialized
DEBUG - 2024-10-10 06:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:40:11 --> Input Class Initialized
INFO - 2024-10-10 06:40:11 --> Language Class Initialized
INFO - 2024-10-10 06:40:11 --> Language Class Initialized
INFO - 2024-10-10 06:40:11 --> Config Class Initialized
INFO - 2024-10-10 06:40:11 --> Loader Class Initialized
INFO - 2024-10-10 06:40:11 --> Helper loaded: url_helper
INFO - 2024-10-10 06:40:11 --> Helper loaded: file_helper
INFO - 2024-10-10 06:40:11 --> Helper loaded: form_helper
INFO - 2024-10-10 06:40:11 --> Helper loaded: my_helper
INFO - 2024-10-10 06:40:11 --> Database Driver Class Initialized
INFO - 2024-10-10 06:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:40:11 --> Controller Class Initialized
INFO - 2024-10-10 06:40:16 --> Config Class Initialized
INFO - 2024-10-10 06:40:16 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:40:16 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:40:16 --> Utf8 Class Initialized
INFO - 2024-10-10 06:40:16 --> URI Class Initialized
INFO - 2024-10-10 06:40:16 --> Router Class Initialized
INFO - 2024-10-10 06:40:16 --> Output Class Initialized
INFO - 2024-10-10 06:40:16 --> Security Class Initialized
DEBUG - 2024-10-10 06:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:40:16 --> Input Class Initialized
INFO - 2024-10-10 06:40:16 --> Language Class Initialized
INFO - 2024-10-10 06:40:16 --> Language Class Initialized
INFO - 2024-10-10 06:40:16 --> Config Class Initialized
INFO - 2024-10-10 06:40:16 --> Loader Class Initialized
INFO - 2024-10-10 06:40:16 --> Helper loaded: url_helper
INFO - 2024-10-10 06:40:16 --> Helper loaded: file_helper
INFO - 2024-10-10 06:40:16 --> Helper loaded: form_helper
INFO - 2024-10-10 06:40:16 --> Helper loaded: my_helper
INFO - 2024-10-10 06:40:16 --> Database Driver Class Initialized
INFO - 2024-10-10 06:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:40:16 --> Controller Class Initialized
INFO - 2024-10-10 06:40:16 --> Helper loaded: cookie_helper
INFO - 2024-10-10 06:40:17 --> Config Class Initialized
INFO - 2024-10-10 06:40:17 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:40:17 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:40:17 --> Utf8 Class Initialized
INFO - 2024-10-10 06:40:17 --> URI Class Initialized
INFO - 2024-10-10 06:40:17 --> Router Class Initialized
INFO - 2024-10-10 06:40:17 --> Output Class Initialized
INFO - 2024-10-10 06:40:17 --> Security Class Initialized
DEBUG - 2024-10-10 06:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:40:17 --> Input Class Initialized
INFO - 2024-10-10 06:40:17 --> Language Class Initialized
INFO - 2024-10-10 06:40:17 --> Language Class Initialized
INFO - 2024-10-10 06:40:17 --> Config Class Initialized
INFO - 2024-10-10 06:40:17 --> Loader Class Initialized
INFO - 2024-10-10 06:40:17 --> Helper loaded: url_helper
INFO - 2024-10-10 06:40:17 --> Helper loaded: file_helper
INFO - 2024-10-10 06:40:17 --> Helper loaded: form_helper
INFO - 2024-10-10 06:40:17 --> Helper loaded: my_helper
INFO - 2024-10-10 06:40:17 --> Database Driver Class Initialized
INFO - 2024-10-10 06:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:40:17 --> Controller Class Initialized
INFO - 2024-10-10 06:40:17 --> Config Class Initialized
INFO - 2024-10-10 06:40:17 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:40:17 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:40:17 --> Utf8 Class Initialized
INFO - 2024-10-10 06:40:17 --> URI Class Initialized
INFO - 2024-10-10 06:40:17 --> Router Class Initialized
INFO - 2024-10-10 06:40:17 --> Output Class Initialized
INFO - 2024-10-10 06:40:17 --> Security Class Initialized
DEBUG - 2024-10-10 06:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:40:17 --> Input Class Initialized
INFO - 2024-10-10 06:40:17 --> Language Class Initialized
INFO - 2024-10-10 06:40:17 --> Language Class Initialized
INFO - 2024-10-10 06:40:17 --> Config Class Initialized
INFO - 2024-10-10 06:40:17 --> Loader Class Initialized
INFO - 2024-10-10 06:40:17 --> Helper loaded: url_helper
INFO - 2024-10-10 06:40:17 --> Helper loaded: file_helper
INFO - 2024-10-10 06:40:17 --> Helper loaded: form_helper
INFO - 2024-10-10 06:40:17 --> Helper loaded: my_helper
INFO - 2024-10-10 06:40:17 --> Database Driver Class Initialized
INFO - 2024-10-10 06:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:40:17 --> Controller Class Initialized
DEBUG - 2024-10-10 06:40:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-10 06:40:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 06:40:17 --> Final output sent to browser
DEBUG - 2024-10-10 06:40:17 --> Total execution time: 0.0278
INFO - 2024-10-10 06:40:28 --> Config Class Initialized
INFO - 2024-10-10 06:40:28 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:40:28 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:40:28 --> Utf8 Class Initialized
INFO - 2024-10-10 06:40:28 --> URI Class Initialized
INFO - 2024-10-10 06:40:28 --> Router Class Initialized
INFO - 2024-10-10 06:40:28 --> Output Class Initialized
INFO - 2024-10-10 06:40:28 --> Security Class Initialized
DEBUG - 2024-10-10 06:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:40:28 --> Input Class Initialized
INFO - 2024-10-10 06:40:28 --> Language Class Initialized
INFO - 2024-10-10 06:40:28 --> Language Class Initialized
INFO - 2024-10-10 06:40:28 --> Config Class Initialized
INFO - 2024-10-10 06:40:28 --> Loader Class Initialized
INFO - 2024-10-10 06:40:28 --> Helper loaded: url_helper
INFO - 2024-10-10 06:40:28 --> Helper loaded: file_helper
INFO - 2024-10-10 06:40:28 --> Helper loaded: form_helper
INFO - 2024-10-10 06:40:28 --> Helper loaded: my_helper
INFO - 2024-10-10 06:40:28 --> Database Driver Class Initialized
INFO - 2024-10-10 06:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:40:29 --> Controller Class Initialized
INFO - 2024-10-10 06:40:29 --> Helper loaded: cookie_helper
INFO - 2024-10-10 06:40:29 --> Final output sent to browser
DEBUG - 2024-10-10 06:40:29 --> Total execution time: 0.3469
INFO - 2024-10-10 06:40:29 --> Config Class Initialized
INFO - 2024-10-10 06:40:29 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:40:29 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:40:29 --> Utf8 Class Initialized
INFO - 2024-10-10 06:40:29 --> URI Class Initialized
INFO - 2024-10-10 06:40:29 --> Router Class Initialized
INFO - 2024-10-10 06:40:29 --> Output Class Initialized
INFO - 2024-10-10 06:40:29 --> Security Class Initialized
DEBUG - 2024-10-10 06:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:40:29 --> Input Class Initialized
INFO - 2024-10-10 06:40:29 --> Language Class Initialized
INFO - 2024-10-10 06:40:29 --> Language Class Initialized
INFO - 2024-10-10 06:40:29 --> Config Class Initialized
INFO - 2024-10-10 06:40:29 --> Loader Class Initialized
INFO - 2024-10-10 06:40:29 --> Helper loaded: url_helper
INFO - 2024-10-10 06:40:29 --> Helper loaded: file_helper
INFO - 2024-10-10 06:40:29 --> Helper loaded: form_helper
INFO - 2024-10-10 06:40:29 --> Helper loaded: my_helper
INFO - 2024-10-10 06:40:29 --> Database Driver Class Initialized
INFO - 2024-10-10 06:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:40:29 --> Controller Class Initialized
DEBUG - 2024-10-10 06:40:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-10 06:40:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 06:40:29 --> Final output sent to browser
DEBUG - 2024-10-10 06:40:29 --> Total execution time: 0.0749
INFO - 2024-10-10 06:40:35 --> Config Class Initialized
INFO - 2024-10-10 06:40:35 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:40:35 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:40:35 --> Utf8 Class Initialized
INFO - 2024-10-10 06:40:35 --> URI Class Initialized
INFO - 2024-10-10 06:40:35 --> Router Class Initialized
INFO - 2024-10-10 06:40:35 --> Output Class Initialized
INFO - 2024-10-10 06:40:35 --> Security Class Initialized
DEBUG - 2024-10-10 06:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:40:35 --> Input Class Initialized
INFO - 2024-10-10 06:40:35 --> Language Class Initialized
INFO - 2024-10-10 06:40:35 --> Language Class Initialized
INFO - 2024-10-10 06:40:35 --> Config Class Initialized
INFO - 2024-10-10 06:40:35 --> Loader Class Initialized
INFO - 2024-10-10 06:40:35 --> Helper loaded: url_helper
INFO - 2024-10-10 06:40:35 --> Helper loaded: file_helper
INFO - 2024-10-10 06:40:35 --> Helper loaded: form_helper
INFO - 2024-10-10 06:40:35 --> Helper loaded: my_helper
INFO - 2024-10-10 06:40:35 --> Database Driver Class Initialized
INFO - 2024-10-10 06:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:40:35 --> Controller Class Initialized
DEBUG - 2024-10-10 06:40:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-10 06:40:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 06:40:35 --> Final output sent to browser
DEBUG - 2024-10-10 06:40:35 --> Total execution time: 0.0322
INFO - 2024-10-10 06:40:37 --> Config Class Initialized
INFO - 2024-10-10 06:40:37 --> Hooks Class Initialized
DEBUG - 2024-10-10 06:40:37 --> UTF-8 Support Enabled
INFO - 2024-10-10 06:40:37 --> Utf8 Class Initialized
INFO - 2024-10-10 06:40:37 --> URI Class Initialized
INFO - 2024-10-10 06:40:37 --> Router Class Initialized
INFO - 2024-10-10 06:40:37 --> Output Class Initialized
INFO - 2024-10-10 06:40:37 --> Security Class Initialized
DEBUG - 2024-10-10 06:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 06:40:37 --> Input Class Initialized
INFO - 2024-10-10 06:40:37 --> Language Class Initialized
INFO - 2024-10-10 06:40:37 --> Language Class Initialized
INFO - 2024-10-10 06:40:37 --> Config Class Initialized
INFO - 2024-10-10 06:40:37 --> Loader Class Initialized
INFO - 2024-10-10 06:40:37 --> Helper loaded: url_helper
INFO - 2024-10-10 06:40:37 --> Helper loaded: file_helper
INFO - 2024-10-10 06:40:37 --> Helper loaded: form_helper
INFO - 2024-10-10 06:40:37 --> Helper loaded: my_helper
INFO - 2024-10-10 06:40:37 --> Database Driver Class Initialized
INFO - 2024-10-10 06:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 06:40:37 --> Controller Class Initialized
DEBUG - 2024-10-10 06:40:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 06:40:40 --> Final output sent to browser
DEBUG - 2024-10-10 06:40:40 --> Total execution time: 2.6615
INFO - 2024-10-10 09:09:55 --> Config Class Initialized
INFO - 2024-10-10 09:09:55 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:09:55 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:09:55 --> Utf8 Class Initialized
INFO - 2024-10-10 09:09:55 --> URI Class Initialized
INFO - 2024-10-10 09:09:55 --> Router Class Initialized
INFO - 2024-10-10 09:09:56 --> Output Class Initialized
INFO - 2024-10-10 09:09:56 --> Security Class Initialized
DEBUG - 2024-10-10 09:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:09:56 --> Input Class Initialized
INFO - 2024-10-10 09:09:56 --> Language Class Initialized
INFO - 2024-10-10 09:09:56 --> Language Class Initialized
INFO - 2024-10-10 09:09:56 --> Config Class Initialized
INFO - 2024-10-10 09:09:56 --> Loader Class Initialized
INFO - 2024-10-10 09:09:56 --> Helper loaded: url_helper
INFO - 2024-10-10 09:09:56 --> Helper loaded: file_helper
INFO - 2024-10-10 09:09:56 --> Helper loaded: form_helper
INFO - 2024-10-10 09:09:56 --> Helper loaded: my_helper
INFO - 2024-10-10 09:09:56 --> Database Driver Class Initialized
INFO - 2024-10-10 09:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:09:56 --> Controller Class Initialized
DEBUG - 2024-10-10 09:09:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-10 09:09:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 09:09:56 --> Final output sent to browser
DEBUG - 2024-10-10 09:09:56 --> Total execution time: 0.6338
INFO - 2024-10-10 09:09:56 --> Config Class Initialized
INFO - 2024-10-10 09:09:56 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:09:56 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:09:56 --> Utf8 Class Initialized
INFO - 2024-10-10 09:09:56 --> URI Class Initialized
INFO - 2024-10-10 09:09:56 --> Router Class Initialized
INFO - 2024-10-10 09:09:56 --> Output Class Initialized
INFO - 2024-10-10 09:09:56 --> Security Class Initialized
DEBUG - 2024-10-10 09:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:09:56 --> Input Class Initialized
INFO - 2024-10-10 09:09:56 --> Language Class Initialized
INFO - 2024-10-10 09:09:56 --> Language Class Initialized
INFO - 2024-10-10 09:09:56 --> Config Class Initialized
INFO - 2024-10-10 09:09:56 --> Loader Class Initialized
INFO - 2024-10-10 09:09:56 --> Helper loaded: url_helper
INFO - 2024-10-10 09:09:56 --> Helper loaded: file_helper
INFO - 2024-10-10 09:09:56 --> Helper loaded: form_helper
INFO - 2024-10-10 09:09:56 --> Helper loaded: my_helper
INFO - 2024-10-10 09:09:56 --> Database Driver Class Initialized
INFO - 2024-10-10 09:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:09:56 --> Controller Class Initialized
DEBUG - 2024-10-10 09:09:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-10 09:09:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 09:09:56 --> Final output sent to browser
DEBUG - 2024-10-10 09:09:56 --> Total execution time: 0.1150
INFO - 2024-10-10 09:10:15 --> Config Class Initialized
INFO - 2024-10-10 09:10:15 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:10:15 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:10:15 --> Utf8 Class Initialized
INFO - 2024-10-10 09:10:15 --> URI Class Initialized
INFO - 2024-10-10 09:10:15 --> Router Class Initialized
INFO - 2024-10-10 09:10:15 --> Output Class Initialized
INFO - 2024-10-10 09:10:15 --> Security Class Initialized
DEBUG - 2024-10-10 09:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:10:15 --> Input Class Initialized
INFO - 2024-10-10 09:10:15 --> Language Class Initialized
INFO - 2024-10-10 09:10:15 --> Language Class Initialized
INFO - 2024-10-10 09:10:15 --> Config Class Initialized
INFO - 2024-10-10 09:10:15 --> Loader Class Initialized
INFO - 2024-10-10 09:10:15 --> Helper loaded: url_helper
INFO - 2024-10-10 09:10:15 --> Helper loaded: file_helper
INFO - 2024-10-10 09:10:15 --> Helper loaded: form_helper
INFO - 2024-10-10 09:10:15 --> Helper loaded: my_helper
INFO - 2024-10-10 09:10:15 --> Database Driver Class Initialized
INFO - 2024-10-10 09:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:10:15 --> Controller Class Initialized
INFO - 2024-10-10 09:10:15 --> Helper loaded: cookie_helper
INFO - 2024-10-10 09:10:15 --> Final output sent to browser
DEBUG - 2024-10-10 09:10:15 --> Total execution time: 0.1503
INFO - 2024-10-10 09:10:15 --> Config Class Initialized
INFO - 2024-10-10 09:10:15 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:10:15 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:10:15 --> Utf8 Class Initialized
INFO - 2024-10-10 09:10:15 --> URI Class Initialized
INFO - 2024-10-10 09:10:15 --> Router Class Initialized
INFO - 2024-10-10 09:10:15 --> Output Class Initialized
INFO - 2024-10-10 09:10:15 --> Security Class Initialized
DEBUG - 2024-10-10 09:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:10:15 --> Input Class Initialized
INFO - 2024-10-10 09:10:15 --> Language Class Initialized
INFO - 2024-10-10 09:10:15 --> Language Class Initialized
INFO - 2024-10-10 09:10:15 --> Config Class Initialized
INFO - 2024-10-10 09:10:15 --> Loader Class Initialized
INFO - 2024-10-10 09:10:15 --> Helper loaded: url_helper
INFO - 2024-10-10 09:10:15 --> Helper loaded: file_helper
INFO - 2024-10-10 09:10:15 --> Helper loaded: form_helper
INFO - 2024-10-10 09:10:16 --> Helper loaded: my_helper
INFO - 2024-10-10 09:10:16 --> Database Driver Class Initialized
INFO - 2024-10-10 09:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:10:16 --> Controller Class Initialized
DEBUG - 2024-10-10 09:10:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-10 09:10:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 09:10:16 --> Final output sent to browser
DEBUG - 2024-10-10 09:10:16 --> Total execution time: 0.1428
INFO - 2024-10-10 09:10:19 --> Config Class Initialized
INFO - 2024-10-10 09:10:19 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:10:19 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:10:19 --> Utf8 Class Initialized
INFO - 2024-10-10 09:10:19 --> URI Class Initialized
INFO - 2024-10-10 09:10:19 --> Router Class Initialized
INFO - 2024-10-10 09:10:19 --> Output Class Initialized
INFO - 2024-10-10 09:10:19 --> Security Class Initialized
DEBUG - 2024-10-10 09:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:10:19 --> Input Class Initialized
INFO - 2024-10-10 09:10:19 --> Language Class Initialized
INFO - 2024-10-10 09:10:19 --> Language Class Initialized
INFO - 2024-10-10 09:10:19 --> Config Class Initialized
INFO - 2024-10-10 09:10:19 --> Loader Class Initialized
INFO - 2024-10-10 09:10:19 --> Helper loaded: url_helper
INFO - 2024-10-10 09:10:19 --> Helper loaded: file_helper
INFO - 2024-10-10 09:10:19 --> Helper loaded: form_helper
INFO - 2024-10-10 09:10:19 --> Helper loaded: my_helper
INFO - 2024-10-10 09:10:19 --> Database Driver Class Initialized
INFO - 2024-10-10 09:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:10:19 --> Controller Class Initialized
DEBUG - 2024-10-10 09:10:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-10 09:10:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 09:10:20 --> Final output sent to browser
DEBUG - 2024-10-10 09:10:20 --> Total execution time: 0.4420
INFO - 2024-10-10 09:10:35 --> Config Class Initialized
INFO - 2024-10-10 09:10:35 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:10:35 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:10:35 --> Utf8 Class Initialized
INFO - 2024-10-10 09:10:35 --> URI Class Initialized
INFO - 2024-10-10 09:10:35 --> Router Class Initialized
INFO - 2024-10-10 09:10:35 --> Output Class Initialized
INFO - 2024-10-10 09:10:35 --> Security Class Initialized
DEBUG - 2024-10-10 09:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:10:35 --> Input Class Initialized
INFO - 2024-10-10 09:10:35 --> Language Class Initialized
INFO - 2024-10-10 09:10:35 --> Language Class Initialized
INFO - 2024-10-10 09:10:35 --> Config Class Initialized
INFO - 2024-10-10 09:10:35 --> Loader Class Initialized
INFO - 2024-10-10 09:10:35 --> Helper loaded: url_helper
INFO - 2024-10-10 09:10:35 --> Helper loaded: file_helper
INFO - 2024-10-10 09:10:35 --> Helper loaded: form_helper
INFO - 2024-10-10 09:10:35 --> Helper loaded: my_helper
INFO - 2024-10-10 09:10:35 --> Database Driver Class Initialized
INFO - 2024-10-10 09:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:10:35 --> Controller Class Initialized
DEBUG - 2024-10-10 09:10:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-10 09:10:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 09:10:35 --> Final output sent to browser
DEBUG - 2024-10-10 09:10:35 --> Total execution time: 0.3003
INFO - 2024-10-10 09:10:35 --> Config Class Initialized
INFO - 2024-10-10 09:10:35 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:10:35 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:10:35 --> Utf8 Class Initialized
INFO - 2024-10-10 09:10:35 --> URI Class Initialized
INFO - 2024-10-10 09:10:35 --> Router Class Initialized
INFO - 2024-10-10 09:10:35 --> Output Class Initialized
INFO - 2024-10-10 09:10:35 --> Security Class Initialized
DEBUG - 2024-10-10 09:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:10:35 --> Input Class Initialized
INFO - 2024-10-10 09:10:35 --> Language Class Initialized
INFO - 2024-10-10 09:10:35 --> Language Class Initialized
INFO - 2024-10-10 09:10:35 --> Config Class Initialized
INFO - 2024-10-10 09:10:35 --> Loader Class Initialized
INFO - 2024-10-10 09:10:35 --> Helper loaded: url_helper
INFO - 2024-10-10 09:10:35 --> Helper loaded: file_helper
INFO - 2024-10-10 09:10:35 --> Helper loaded: form_helper
INFO - 2024-10-10 09:10:35 --> Helper loaded: my_helper
INFO - 2024-10-10 09:10:35 --> Database Driver Class Initialized
INFO - 2024-10-10 09:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:10:35 --> Controller Class Initialized
INFO - 2024-10-10 09:10:43 --> Config Class Initialized
INFO - 2024-10-10 09:10:43 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:10:43 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:10:43 --> Utf8 Class Initialized
INFO - 2024-10-10 09:10:43 --> URI Class Initialized
INFO - 2024-10-10 09:10:43 --> Router Class Initialized
INFO - 2024-10-10 09:10:43 --> Output Class Initialized
INFO - 2024-10-10 09:10:43 --> Security Class Initialized
DEBUG - 2024-10-10 09:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:10:43 --> Input Class Initialized
INFO - 2024-10-10 09:10:43 --> Language Class Initialized
INFO - 2024-10-10 09:10:43 --> Language Class Initialized
INFO - 2024-10-10 09:10:43 --> Config Class Initialized
INFO - 2024-10-10 09:10:43 --> Loader Class Initialized
INFO - 2024-10-10 09:10:43 --> Helper loaded: url_helper
INFO - 2024-10-10 09:10:43 --> Helper loaded: file_helper
INFO - 2024-10-10 09:10:43 --> Helper loaded: form_helper
INFO - 2024-10-10 09:10:43 --> Helper loaded: my_helper
INFO - 2024-10-10 09:10:43 --> Database Driver Class Initialized
INFO - 2024-10-10 09:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:10:43 --> Controller Class Initialized
INFO - 2024-10-10 09:10:43 --> Final output sent to browser
DEBUG - 2024-10-10 09:10:43 --> Total execution time: 0.0742
INFO - 2024-10-10 09:11:05 --> Config Class Initialized
INFO - 2024-10-10 09:11:05 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:11:05 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:11:05 --> Utf8 Class Initialized
INFO - 2024-10-10 09:11:05 --> URI Class Initialized
INFO - 2024-10-10 09:11:05 --> Router Class Initialized
INFO - 2024-10-10 09:11:05 --> Output Class Initialized
INFO - 2024-10-10 09:11:05 --> Security Class Initialized
DEBUG - 2024-10-10 09:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:11:05 --> Input Class Initialized
INFO - 2024-10-10 09:11:05 --> Language Class Initialized
INFO - 2024-10-10 09:11:05 --> Language Class Initialized
INFO - 2024-10-10 09:11:05 --> Config Class Initialized
INFO - 2024-10-10 09:11:05 --> Loader Class Initialized
INFO - 2024-10-10 09:11:05 --> Helper loaded: url_helper
INFO - 2024-10-10 09:11:05 --> Helper loaded: file_helper
INFO - 2024-10-10 09:11:05 --> Helper loaded: form_helper
INFO - 2024-10-10 09:11:05 --> Helper loaded: my_helper
INFO - 2024-10-10 09:11:05 --> Database Driver Class Initialized
INFO - 2024-10-10 09:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:11:05 --> Controller Class Initialized
INFO - 2024-10-10 09:11:06 --> Final output sent to browser
DEBUG - 2024-10-10 09:11:06 --> Total execution time: 0.1341
INFO - 2024-10-10 09:11:06 --> Config Class Initialized
INFO - 2024-10-10 09:11:06 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:11:06 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:11:06 --> Utf8 Class Initialized
INFO - 2024-10-10 09:11:06 --> URI Class Initialized
INFO - 2024-10-10 09:11:06 --> Router Class Initialized
INFO - 2024-10-10 09:11:06 --> Output Class Initialized
INFO - 2024-10-10 09:11:06 --> Security Class Initialized
DEBUG - 2024-10-10 09:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:11:06 --> Input Class Initialized
INFO - 2024-10-10 09:11:06 --> Language Class Initialized
INFO - 2024-10-10 09:11:06 --> Language Class Initialized
INFO - 2024-10-10 09:11:06 --> Config Class Initialized
INFO - 2024-10-10 09:11:06 --> Loader Class Initialized
INFO - 2024-10-10 09:11:06 --> Helper loaded: url_helper
INFO - 2024-10-10 09:11:06 --> Helper loaded: file_helper
INFO - 2024-10-10 09:11:06 --> Helper loaded: form_helper
INFO - 2024-10-10 09:11:06 --> Helper loaded: my_helper
INFO - 2024-10-10 09:11:06 --> Database Driver Class Initialized
INFO - 2024-10-10 09:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:11:06 --> Controller Class Initialized
INFO - 2024-10-10 09:11:11 --> Config Class Initialized
INFO - 2024-10-10 09:11:11 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:11:11 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:11:11 --> Utf8 Class Initialized
INFO - 2024-10-10 09:11:11 --> URI Class Initialized
INFO - 2024-10-10 09:11:11 --> Router Class Initialized
INFO - 2024-10-10 09:11:11 --> Output Class Initialized
INFO - 2024-10-10 09:11:11 --> Security Class Initialized
DEBUG - 2024-10-10 09:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:11:11 --> Input Class Initialized
INFO - 2024-10-10 09:11:11 --> Language Class Initialized
INFO - 2024-10-10 09:11:11 --> Language Class Initialized
INFO - 2024-10-10 09:11:11 --> Config Class Initialized
INFO - 2024-10-10 09:11:11 --> Loader Class Initialized
INFO - 2024-10-10 09:11:11 --> Helper loaded: url_helper
INFO - 2024-10-10 09:11:11 --> Helper loaded: file_helper
INFO - 2024-10-10 09:11:11 --> Helper loaded: form_helper
INFO - 2024-10-10 09:11:11 --> Helper loaded: my_helper
INFO - 2024-10-10 09:11:11 --> Database Driver Class Initialized
INFO - 2024-10-10 09:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:11:11 --> Controller Class Initialized
INFO - 2024-10-10 09:11:11 --> Final output sent to browser
DEBUG - 2024-10-10 09:11:11 --> Total execution time: 0.3180
INFO - 2024-10-10 09:12:08 --> Config Class Initialized
INFO - 2024-10-10 09:12:08 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:12:08 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:12:08 --> Utf8 Class Initialized
INFO - 2024-10-10 09:12:08 --> URI Class Initialized
INFO - 2024-10-10 09:12:08 --> Router Class Initialized
INFO - 2024-10-10 09:12:08 --> Output Class Initialized
INFO - 2024-10-10 09:12:08 --> Security Class Initialized
DEBUG - 2024-10-10 09:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:12:08 --> Input Class Initialized
INFO - 2024-10-10 09:12:08 --> Language Class Initialized
INFO - 2024-10-10 09:12:08 --> Language Class Initialized
INFO - 2024-10-10 09:12:08 --> Config Class Initialized
INFO - 2024-10-10 09:12:08 --> Loader Class Initialized
INFO - 2024-10-10 09:12:08 --> Helper loaded: url_helper
INFO - 2024-10-10 09:12:08 --> Helper loaded: file_helper
INFO - 2024-10-10 09:12:08 --> Helper loaded: form_helper
INFO - 2024-10-10 09:12:08 --> Helper loaded: my_helper
INFO - 2024-10-10 09:12:08 --> Database Driver Class Initialized
INFO - 2024-10-10 09:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:12:08 --> Controller Class Initialized
INFO - 2024-10-10 09:12:08 --> Final output sent to browser
DEBUG - 2024-10-10 09:12:08 --> Total execution time: 0.5420
INFO - 2024-10-10 09:12:45 --> Config Class Initialized
INFO - 2024-10-10 09:12:45 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:12:45 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:12:45 --> Utf8 Class Initialized
INFO - 2024-10-10 09:12:45 --> URI Class Initialized
INFO - 2024-10-10 09:12:45 --> Router Class Initialized
INFO - 2024-10-10 09:12:45 --> Output Class Initialized
INFO - 2024-10-10 09:12:45 --> Security Class Initialized
DEBUG - 2024-10-10 09:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:12:45 --> Input Class Initialized
INFO - 2024-10-10 09:12:45 --> Language Class Initialized
INFO - 2024-10-10 09:12:45 --> Language Class Initialized
INFO - 2024-10-10 09:12:45 --> Config Class Initialized
INFO - 2024-10-10 09:12:45 --> Loader Class Initialized
INFO - 2024-10-10 09:12:45 --> Helper loaded: url_helper
INFO - 2024-10-10 09:12:45 --> Helper loaded: file_helper
INFO - 2024-10-10 09:12:45 --> Helper loaded: form_helper
INFO - 2024-10-10 09:12:45 --> Helper loaded: my_helper
INFO - 2024-10-10 09:12:45 --> Database Driver Class Initialized
INFO - 2024-10-10 09:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:12:45 --> Controller Class Initialized
DEBUG - 2024-10-10 09:12:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-10 09:12:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 09:12:46 --> Final output sent to browser
DEBUG - 2024-10-10 09:12:46 --> Total execution time: 0.1516
INFO - 2024-10-10 09:12:49 --> Config Class Initialized
INFO - 2024-10-10 09:12:49 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:12:49 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:12:49 --> Utf8 Class Initialized
INFO - 2024-10-10 09:12:49 --> URI Class Initialized
INFO - 2024-10-10 09:12:49 --> Router Class Initialized
INFO - 2024-10-10 09:12:49 --> Output Class Initialized
INFO - 2024-10-10 09:12:49 --> Security Class Initialized
DEBUG - 2024-10-10 09:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:12:49 --> Input Class Initialized
INFO - 2024-10-10 09:12:50 --> Language Class Initialized
INFO - 2024-10-10 09:12:50 --> Language Class Initialized
INFO - 2024-10-10 09:12:50 --> Config Class Initialized
INFO - 2024-10-10 09:12:50 --> Loader Class Initialized
INFO - 2024-10-10 09:12:50 --> Helper loaded: url_helper
INFO - 2024-10-10 09:12:50 --> Helper loaded: file_helper
INFO - 2024-10-10 09:12:50 --> Helper loaded: form_helper
INFO - 2024-10-10 09:12:50 --> Helper loaded: my_helper
INFO - 2024-10-10 09:12:50 --> Database Driver Class Initialized
INFO - 2024-10-10 09:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:12:50 --> Controller Class Initialized
DEBUG - 2024-10-10 09:12:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-10 09:12:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 09:12:50 --> Final output sent to browser
DEBUG - 2024-10-10 09:12:50 --> Total execution time: 0.1779
INFO - 2024-10-10 09:12:53 --> Config Class Initialized
INFO - 2024-10-10 09:12:53 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:12:53 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:12:53 --> Utf8 Class Initialized
INFO - 2024-10-10 09:12:53 --> URI Class Initialized
INFO - 2024-10-10 09:12:53 --> Router Class Initialized
INFO - 2024-10-10 09:12:53 --> Output Class Initialized
INFO - 2024-10-10 09:12:53 --> Security Class Initialized
DEBUG - 2024-10-10 09:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:12:53 --> Input Class Initialized
INFO - 2024-10-10 09:12:53 --> Language Class Initialized
INFO - 2024-10-10 09:12:53 --> Language Class Initialized
INFO - 2024-10-10 09:12:53 --> Config Class Initialized
INFO - 2024-10-10 09:12:53 --> Loader Class Initialized
INFO - 2024-10-10 09:12:53 --> Helper loaded: url_helper
INFO - 2024-10-10 09:12:53 --> Helper loaded: file_helper
INFO - 2024-10-10 09:12:53 --> Helper loaded: form_helper
INFO - 2024-10-10 09:12:53 --> Helper loaded: my_helper
INFO - 2024-10-10 09:12:53 --> Database Driver Class Initialized
INFO - 2024-10-10 09:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:12:53 --> Controller Class Initialized
DEBUG - 2024-10-10 09:12:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 09:13:01 --> Final output sent to browser
DEBUG - 2024-10-10 09:13:01 --> Total execution time: 8.1671
INFO - 2024-10-10 09:14:04 --> Config Class Initialized
INFO - 2024-10-10 09:14:04 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:14:04 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:14:04 --> Utf8 Class Initialized
INFO - 2024-10-10 09:14:04 --> URI Class Initialized
INFO - 2024-10-10 09:14:04 --> Router Class Initialized
INFO - 2024-10-10 09:14:04 --> Output Class Initialized
INFO - 2024-10-10 09:14:04 --> Security Class Initialized
DEBUG - 2024-10-10 09:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:14:04 --> Input Class Initialized
INFO - 2024-10-10 09:14:04 --> Language Class Initialized
INFO - 2024-10-10 09:14:04 --> Language Class Initialized
INFO - 2024-10-10 09:14:04 --> Config Class Initialized
INFO - 2024-10-10 09:14:04 --> Loader Class Initialized
INFO - 2024-10-10 09:14:04 --> Helper loaded: url_helper
INFO - 2024-10-10 09:14:04 --> Helper loaded: file_helper
INFO - 2024-10-10 09:14:04 --> Helper loaded: form_helper
INFO - 2024-10-10 09:14:04 --> Helper loaded: my_helper
INFO - 2024-10-10 09:14:04 --> Database Driver Class Initialized
INFO - 2024-10-10 09:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:14:04 --> Controller Class Initialized
DEBUG - 2024-10-10 09:14:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 09:14:13 --> Final output sent to browser
DEBUG - 2024-10-10 09:14:13 --> Total execution time: 8.7192
INFO - 2024-10-10 09:14:33 --> Config Class Initialized
INFO - 2024-10-10 09:14:33 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:14:33 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:14:33 --> Utf8 Class Initialized
INFO - 2024-10-10 09:14:33 --> URI Class Initialized
INFO - 2024-10-10 09:14:34 --> Router Class Initialized
INFO - 2024-10-10 09:14:34 --> Output Class Initialized
INFO - 2024-10-10 09:14:34 --> Security Class Initialized
DEBUG - 2024-10-10 09:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:14:34 --> Input Class Initialized
INFO - 2024-10-10 09:14:34 --> Language Class Initialized
INFO - 2024-10-10 09:14:34 --> Language Class Initialized
INFO - 2024-10-10 09:14:34 --> Config Class Initialized
INFO - 2024-10-10 09:14:34 --> Loader Class Initialized
INFO - 2024-10-10 09:14:34 --> Helper loaded: url_helper
INFO - 2024-10-10 09:14:34 --> Helper loaded: file_helper
INFO - 2024-10-10 09:14:34 --> Helper loaded: form_helper
INFO - 2024-10-10 09:14:34 --> Helper loaded: my_helper
INFO - 2024-10-10 09:14:34 --> Database Driver Class Initialized
INFO - 2024-10-10 09:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:14:34 --> Controller Class Initialized
DEBUG - 2024-10-10 09:14:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 09:14:36 --> Config Class Initialized
INFO - 2024-10-10 09:14:36 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:14:36 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:14:36 --> Utf8 Class Initialized
INFO - 2024-10-10 09:14:36 --> URI Class Initialized
INFO - 2024-10-10 09:14:36 --> Router Class Initialized
INFO - 2024-10-10 09:14:36 --> Output Class Initialized
INFO - 2024-10-10 09:14:36 --> Security Class Initialized
DEBUG - 2024-10-10 09:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:14:36 --> Input Class Initialized
INFO - 2024-10-10 09:14:36 --> Language Class Initialized
INFO - 2024-10-10 09:14:36 --> Language Class Initialized
INFO - 2024-10-10 09:14:36 --> Config Class Initialized
INFO - 2024-10-10 09:14:36 --> Loader Class Initialized
INFO - 2024-10-10 09:14:36 --> Helper loaded: url_helper
INFO - 2024-10-10 09:14:36 --> Helper loaded: file_helper
INFO - 2024-10-10 09:14:36 --> Helper loaded: form_helper
INFO - 2024-10-10 09:14:36 --> Helper loaded: my_helper
INFO - 2024-10-10 09:14:36 --> Database Driver Class Initialized
INFO - 2024-10-10 09:14:38 --> Config Class Initialized
INFO - 2024-10-10 09:14:38 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:14:38 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:14:38 --> Utf8 Class Initialized
INFO - 2024-10-10 09:14:38 --> URI Class Initialized
INFO - 2024-10-10 09:14:38 --> Router Class Initialized
INFO - 2024-10-10 09:14:38 --> Output Class Initialized
INFO - 2024-10-10 09:14:38 --> Security Class Initialized
DEBUG - 2024-10-10 09:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:14:38 --> Input Class Initialized
INFO - 2024-10-10 09:14:38 --> Language Class Initialized
INFO - 2024-10-10 09:14:38 --> Language Class Initialized
INFO - 2024-10-10 09:14:38 --> Config Class Initialized
INFO - 2024-10-10 09:14:38 --> Loader Class Initialized
INFO - 2024-10-10 09:14:38 --> Helper loaded: url_helper
INFO - 2024-10-10 09:14:38 --> Helper loaded: file_helper
INFO - 2024-10-10 09:14:38 --> Helper loaded: form_helper
INFO - 2024-10-10 09:14:38 --> Helper loaded: my_helper
INFO - 2024-10-10 09:14:38 --> Database Driver Class Initialized
INFO - 2024-10-10 09:14:40 --> Final output sent to browser
DEBUG - 2024-10-10 09:14:40 --> Total execution time: 6.7783
INFO - 2024-10-10 09:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:14:40 --> Controller Class Initialized
DEBUG - 2024-10-10 09:14:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 09:14:46 --> Final output sent to browser
DEBUG - 2024-10-10 09:14:46 --> Total execution time: 10.4683
INFO - 2024-10-10 09:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:14:46 --> Controller Class Initialized
DEBUG - 2024-10-10 09:14:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 09:14:48 --> Config Class Initialized
INFO - 2024-10-10 09:14:48 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:14:48 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:14:48 --> Utf8 Class Initialized
INFO - 2024-10-10 09:14:48 --> URI Class Initialized
INFO - 2024-10-10 09:14:48 --> Router Class Initialized
INFO - 2024-10-10 09:14:48 --> Output Class Initialized
INFO - 2024-10-10 09:14:48 --> Security Class Initialized
DEBUG - 2024-10-10 09:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:14:48 --> Input Class Initialized
INFO - 2024-10-10 09:14:48 --> Language Class Initialized
INFO - 2024-10-10 09:14:48 --> Language Class Initialized
INFO - 2024-10-10 09:14:48 --> Config Class Initialized
INFO - 2024-10-10 09:14:48 --> Loader Class Initialized
INFO - 2024-10-10 09:14:48 --> Helper loaded: url_helper
INFO - 2024-10-10 09:14:48 --> Helper loaded: file_helper
INFO - 2024-10-10 09:14:48 --> Helper loaded: form_helper
INFO - 2024-10-10 09:14:48 --> Helper loaded: my_helper
INFO - 2024-10-10 09:14:48 --> Database Driver Class Initialized
INFO - 2024-10-10 09:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:14:48 --> Controller Class Initialized
DEBUG - 2024-10-10 09:14:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-10 09:14:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 09:14:48 --> Final output sent to browser
DEBUG - 2024-10-10 09:14:48 --> Total execution time: 0.1078
INFO - 2024-10-10 09:14:52 --> Final output sent to browser
DEBUG - 2024-10-10 09:14:52 --> Total execution time: 14.6198
INFO - 2024-10-10 09:14:56 --> Config Class Initialized
INFO - 2024-10-10 09:14:56 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:14:56 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:14:56 --> Utf8 Class Initialized
INFO - 2024-10-10 09:14:56 --> URI Class Initialized
INFO - 2024-10-10 09:14:56 --> Router Class Initialized
INFO - 2024-10-10 09:14:56 --> Output Class Initialized
INFO - 2024-10-10 09:14:56 --> Security Class Initialized
DEBUG - 2024-10-10 09:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:14:56 --> Input Class Initialized
INFO - 2024-10-10 09:14:56 --> Language Class Initialized
INFO - 2024-10-10 09:14:56 --> Language Class Initialized
INFO - 2024-10-10 09:14:56 --> Config Class Initialized
INFO - 2024-10-10 09:14:56 --> Loader Class Initialized
INFO - 2024-10-10 09:14:56 --> Helper loaded: url_helper
INFO - 2024-10-10 09:14:56 --> Helper loaded: file_helper
INFO - 2024-10-10 09:14:56 --> Helper loaded: form_helper
INFO - 2024-10-10 09:14:56 --> Helper loaded: my_helper
INFO - 2024-10-10 09:14:56 --> Database Driver Class Initialized
INFO - 2024-10-10 09:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:14:56 --> Controller Class Initialized
INFO - 2024-10-10 09:14:57 --> Helper loaded: cookie_helper
INFO - 2024-10-10 09:14:57 --> Final output sent to browser
DEBUG - 2024-10-10 09:14:57 --> Total execution time: 0.0786
INFO - 2024-10-10 09:14:57 --> Config Class Initialized
INFO - 2024-10-10 09:14:57 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:14:57 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:14:57 --> Utf8 Class Initialized
INFO - 2024-10-10 09:14:57 --> URI Class Initialized
INFO - 2024-10-10 09:14:57 --> Router Class Initialized
INFO - 2024-10-10 09:14:57 --> Output Class Initialized
INFO - 2024-10-10 09:14:57 --> Security Class Initialized
DEBUG - 2024-10-10 09:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:14:57 --> Input Class Initialized
INFO - 2024-10-10 09:14:57 --> Language Class Initialized
INFO - 2024-10-10 09:14:57 --> Language Class Initialized
INFO - 2024-10-10 09:14:57 --> Config Class Initialized
INFO - 2024-10-10 09:14:57 --> Loader Class Initialized
INFO - 2024-10-10 09:14:57 --> Helper loaded: url_helper
INFO - 2024-10-10 09:14:57 --> Helper loaded: file_helper
INFO - 2024-10-10 09:14:57 --> Helper loaded: form_helper
INFO - 2024-10-10 09:14:57 --> Helper loaded: my_helper
INFO - 2024-10-10 09:14:57 --> Database Driver Class Initialized
INFO - 2024-10-10 09:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:14:57 --> Controller Class Initialized
DEBUG - 2024-10-10 09:14:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-10 09:14:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 09:14:57 --> Final output sent to browser
DEBUG - 2024-10-10 09:14:57 --> Total execution time: 0.0734
INFO - 2024-10-10 09:14:59 --> Config Class Initialized
INFO - 2024-10-10 09:14:59 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:14:59 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:14:59 --> Utf8 Class Initialized
INFO - 2024-10-10 09:14:59 --> URI Class Initialized
INFO - 2024-10-10 09:14:59 --> Router Class Initialized
INFO - 2024-10-10 09:14:59 --> Output Class Initialized
INFO - 2024-10-10 09:14:59 --> Security Class Initialized
DEBUG - 2024-10-10 09:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:14:59 --> Input Class Initialized
INFO - 2024-10-10 09:14:59 --> Language Class Initialized
INFO - 2024-10-10 09:14:59 --> Language Class Initialized
INFO - 2024-10-10 09:14:59 --> Config Class Initialized
INFO - 2024-10-10 09:14:59 --> Loader Class Initialized
INFO - 2024-10-10 09:14:59 --> Helper loaded: url_helper
INFO - 2024-10-10 09:14:59 --> Helper loaded: file_helper
INFO - 2024-10-10 09:14:59 --> Helper loaded: form_helper
INFO - 2024-10-10 09:14:59 --> Helper loaded: my_helper
INFO - 2024-10-10 09:14:59 --> Database Driver Class Initialized
INFO - 2024-10-10 09:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:14:59 --> Controller Class Initialized
DEBUG - 2024-10-10 09:14:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-10 09:14:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 09:14:59 --> Final output sent to browser
DEBUG - 2024-10-10 09:14:59 --> Total execution time: 0.0627
INFO - 2024-10-10 09:15:03 --> Config Class Initialized
INFO - 2024-10-10 09:15:03 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:15:03 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:15:03 --> Utf8 Class Initialized
INFO - 2024-10-10 09:15:03 --> URI Class Initialized
INFO - 2024-10-10 09:15:03 --> Router Class Initialized
INFO - 2024-10-10 09:15:03 --> Output Class Initialized
INFO - 2024-10-10 09:15:03 --> Security Class Initialized
DEBUG - 2024-10-10 09:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:15:03 --> Input Class Initialized
INFO - 2024-10-10 09:15:03 --> Language Class Initialized
INFO - 2024-10-10 09:15:03 --> Language Class Initialized
INFO - 2024-10-10 09:15:03 --> Config Class Initialized
INFO - 2024-10-10 09:15:03 --> Loader Class Initialized
INFO - 2024-10-10 09:15:03 --> Helper loaded: url_helper
INFO - 2024-10-10 09:15:03 --> Helper loaded: file_helper
INFO - 2024-10-10 09:15:03 --> Helper loaded: form_helper
INFO - 2024-10-10 09:15:03 --> Helper loaded: my_helper
INFO - 2024-10-10 09:15:03 --> Database Driver Class Initialized
INFO - 2024-10-10 09:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:15:03 --> Controller Class Initialized
DEBUG - 2024-10-10 09:15:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-10 09:15:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 09:15:03 --> Final output sent to browser
DEBUG - 2024-10-10 09:15:03 --> Total execution time: 0.1036
INFO - 2024-10-10 09:15:03 --> Config Class Initialized
INFO - 2024-10-10 09:15:03 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:15:03 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:15:03 --> Utf8 Class Initialized
INFO - 2024-10-10 09:15:03 --> URI Class Initialized
INFO - 2024-10-10 09:15:03 --> Router Class Initialized
INFO - 2024-10-10 09:15:03 --> Output Class Initialized
INFO - 2024-10-10 09:15:03 --> Security Class Initialized
DEBUG - 2024-10-10 09:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:15:03 --> Input Class Initialized
INFO - 2024-10-10 09:15:03 --> Language Class Initialized
INFO - 2024-10-10 09:15:03 --> Language Class Initialized
INFO - 2024-10-10 09:15:03 --> Config Class Initialized
INFO - 2024-10-10 09:15:03 --> Loader Class Initialized
INFO - 2024-10-10 09:15:03 --> Helper loaded: url_helper
INFO - 2024-10-10 09:15:03 --> Helper loaded: file_helper
INFO - 2024-10-10 09:15:03 --> Helper loaded: form_helper
INFO - 2024-10-10 09:15:03 --> Helper loaded: my_helper
INFO - 2024-10-10 09:15:03 --> Database Driver Class Initialized
INFO - 2024-10-10 09:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:15:03 --> Controller Class Initialized
INFO - 2024-10-10 09:15:06 --> Config Class Initialized
INFO - 2024-10-10 09:15:06 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:15:06 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:15:06 --> Utf8 Class Initialized
INFO - 2024-10-10 09:15:06 --> URI Class Initialized
INFO - 2024-10-10 09:15:06 --> Router Class Initialized
INFO - 2024-10-10 09:15:06 --> Output Class Initialized
INFO - 2024-10-10 09:15:06 --> Security Class Initialized
DEBUG - 2024-10-10 09:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:15:06 --> Input Class Initialized
INFO - 2024-10-10 09:15:06 --> Language Class Initialized
INFO - 2024-10-10 09:15:06 --> Language Class Initialized
INFO - 2024-10-10 09:15:06 --> Config Class Initialized
INFO - 2024-10-10 09:15:06 --> Loader Class Initialized
INFO - 2024-10-10 09:15:06 --> Helper loaded: url_helper
INFO - 2024-10-10 09:15:06 --> Helper loaded: file_helper
INFO - 2024-10-10 09:15:06 --> Helper loaded: form_helper
INFO - 2024-10-10 09:15:06 --> Helper loaded: my_helper
INFO - 2024-10-10 09:15:06 --> Database Driver Class Initialized
INFO - 2024-10-10 09:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:15:06 --> Controller Class Initialized
INFO - 2024-10-10 09:15:06 --> Final output sent to browser
DEBUG - 2024-10-10 09:15:06 --> Total execution time: 0.1146
INFO - 2024-10-10 09:15:58 --> Config Class Initialized
INFO - 2024-10-10 09:15:58 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:15:58 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:15:58 --> Utf8 Class Initialized
INFO - 2024-10-10 09:15:58 --> URI Class Initialized
INFO - 2024-10-10 09:15:58 --> Router Class Initialized
INFO - 2024-10-10 09:15:58 --> Output Class Initialized
INFO - 2024-10-10 09:15:58 --> Security Class Initialized
DEBUG - 2024-10-10 09:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:15:58 --> Input Class Initialized
INFO - 2024-10-10 09:15:58 --> Language Class Initialized
INFO - 2024-10-10 09:15:58 --> Language Class Initialized
INFO - 2024-10-10 09:15:58 --> Config Class Initialized
INFO - 2024-10-10 09:15:58 --> Loader Class Initialized
INFO - 2024-10-10 09:15:58 --> Helper loaded: url_helper
INFO - 2024-10-10 09:15:58 --> Helper loaded: file_helper
INFO - 2024-10-10 09:15:58 --> Helper loaded: form_helper
INFO - 2024-10-10 09:15:58 --> Helper loaded: my_helper
INFO - 2024-10-10 09:15:58 --> Database Driver Class Initialized
INFO - 2024-10-10 09:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:15:58 --> Controller Class Initialized
INFO - 2024-10-10 09:15:58 --> Final output sent to browser
DEBUG - 2024-10-10 09:15:58 --> Total execution time: 0.4173
INFO - 2024-10-10 09:16:17 --> Config Class Initialized
INFO - 2024-10-10 09:16:17 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:16:17 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:16:17 --> Utf8 Class Initialized
INFO - 2024-10-10 09:16:17 --> URI Class Initialized
INFO - 2024-10-10 09:16:17 --> Router Class Initialized
INFO - 2024-10-10 09:16:17 --> Output Class Initialized
INFO - 2024-10-10 09:16:17 --> Security Class Initialized
DEBUG - 2024-10-10 09:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:16:17 --> Input Class Initialized
INFO - 2024-10-10 09:16:17 --> Language Class Initialized
INFO - 2024-10-10 09:16:17 --> Language Class Initialized
INFO - 2024-10-10 09:16:17 --> Config Class Initialized
INFO - 2024-10-10 09:16:17 --> Loader Class Initialized
INFO - 2024-10-10 09:16:17 --> Helper loaded: url_helper
INFO - 2024-10-10 09:16:17 --> Helper loaded: file_helper
INFO - 2024-10-10 09:16:17 --> Helper loaded: form_helper
INFO - 2024-10-10 09:16:17 --> Helper loaded: my_helper
INFO - 2024-10-10 09:16:17 --> Database Driver Class Initialized
INFO - 2024-10-10 09:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:16:17 --> Controller Class Initialized
INFO - 2024-10-10 09:16:19 --> Final output sent to browser
DEBUG - 2024-10-10 09:16:19 --> Total execution time: 1.2268
INFO - 2024-10-10 09:16:44 --> Config Class Initialized
INFO - 2024-10-10 09:16:44 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:16:44 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:16:44 --> Utf8 Class Initialized
INFO - 2024-10-10 09:16:44 --> URI Class Initialized
INFO - 2024-10-10 09:16:44 --> Router Class Initialized
INFO - 2024-10-10 09:16:44 --> Output Class Initialized
INFO - 2024-10-10 09:16:44 --> Security Class Initialized
DEBUG - 2024-10-10 09:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:16:44 --> Input Class Initialized
INFO - 2024-10-10 09:16:44 --> Language Class Initialized
INFO - 2024-10-10 09:16:44 --> Language Class Initialized
INFO - 2024-10-10 09:16:44 --> Config Class Initialized
INFO - 2024-10-10 09:16:44 --> Loader Class Initialized
INFO - 2024-10-10 09:16:44 --> Helper loaded: url_helper
INFO - 2024-10-10 09:16:44 --> Helper loaded: file_helper
INFO - 2024-10-10 09:16:44 --> Helper loaded: form_helper
INFO - 2024-10-10 09:16:44 --> Helper loaded: my_helper
INFO - 2024-10-10 09:16:44 --> Database Driver Class Initialized
INFO - 2024-10-10 09:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:16:44 --> Controller Class Initialized
INFO - 2024-10-10 09:16:44 --> Final output sent to browser
DEBUG - 2024-10-10 09:16:44 --> Total execution time: 0.1271
INFO - 2024-10-10 09:16:54 --> Config Class Initialized
INFO - 2024-10-10 09:16:54 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:16:54 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:16:54 --> Utf8 Class Initialized
INFO - 2024-10-10 09:16:54 --> URI Class Initialized
INFO - 2024-10-10 09:16:54 --> Router Class Initialized
INFO - 2024-10-10 09:16:54 --> Output Class Initialized
INFO - 2024-10-10 09:16:54 --> Security Class Initialized
DEBUG - 2024-10-10 09:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:16:54 --> Input Class Initialized
INFO - 2024-10-10 09:16:54 --> Language Class Initialized
INFO - 2024-10-10 09:16:54 --> Language Class Initialized
INFO - 2024-10-10 09:16:54 --> Config Class Initialized
INFO - 2024-10-10 09:16:54 --> Loader Class Initialized
INFO - 2024-10-10 09:16:54 --> Helper loaded: url_helper
INFO - 2024-10-10 09:16:54 --> Helper loaded: file_helper
INFO - 2024-10-10 09:16:54 --> Helper loaded: form_helper
INFO - 2024-10-10 09:16:54 --> Helper loaded: my_helper
INFO - 2024-10-10 09:16:54 --> Database Driver Class Initialized
INFO - 2024-10-10 09:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:16:54 --> Controller Class Initialized
INFO - 2024-10-10 09:16:55 --> Final output sent to browser
DEBUG - 2024-10-10 09:16:55 --> Total execution time: 0.4713
INFO - 2024-10-10 09:16:59 --> Config Class Initialized
INFO - 2024-10-10 09:16:59 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:16:59 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:16:59 --> Utf8 Class Initialized
INFO - 2024-10-10 09:16:59 --> URI Class Initialized
INFO - 2024-10-10 09:16:59 --> Router Class Initialized
INFO - 2024-10-10 09:16:59 --> Output Class Initialized
INFO - 2024-10-10 09:16:59 --> Security Class Initialized
DEBUG - 2024-10-10 09:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:16:59 --> Input Class Initialized
INFO - 2024-10-10 09:16:59 --> Language Class Initialized
INFO - 2024-10-10 09:16:59 --> Language Class Initialized
INFO - 2024-10-10 09:16:59 --> Config Class Initialized
INFO - 2024-10-10 09:16:59 --> Loader Class Initialized
INFO - 2024-10-10 09:16:59 --> Helper loaded: url_helper
INFO - 2024-10-10 09:16:59 --> Helper loaded: file_helper
INFO - 2024-10-10 09:16:59 --> Helper loaded: form_helper
INFO - 2024-10-10 09:16:59 --> Helper loaded: my_helper
INFO - 2024-10-10 09:16:59 --> Database Driver Class Initialized
INFO - 2024-10-10 09:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:16:59 --> Controller Class Initialized
DEBUG - 2024-10-10 09:16:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-10 09:16:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 09:16:59 --> Final output sent to browser
DEBUG - 2024-10-10 09:16:59 --> Total execution time: 0.1169
INFO - 2024-10-10 09:17:03 --> Config Class Initialized
INFO - 2024-10-10 09:17:03 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:17:03 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:17:03 --> Utf8 Class Initialized
INFO - 2024-10-10 09:17:03 --> URI Class Initialized
INFO - 2024-10-10 09:17:03 --> Router Class Initialized
INFO - 2024-10-10 09:17:03 --> Output Class Initialized
INFO - 2024-10-10 09:17:03 --> Security Class Initialized
DEBUG - 2024-10-10 09:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:17:03 --> Input Class Initialized
INFO - 2024-10-10 09:17:03 --> Language Class Initialized
INFO - 2024-10-10 09:17:03 --> Language Class Initialized
INFO - 2024-10-10 09:17:03 --> Config Class Initialized
INFO - 2024-10-10 09:17:03 --> Loader Class Initialized
INFO - 2024-10-10 09:17:03 --> Helper loaded: url_helper
INFO - 2024-10-10 09:17:03 --> Helper loaded: file_helper
INFO - 2024-10-10 09:17:03 --> Helper loaded: form_helper
INFO - 2024-10-10 09:17:03 --> Helper loaded: my_helper
INFO - 2024-10-10 09:17:03 --> Database Driver Class Initialized
INFO - 2024-10-10 09:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:17:03 --> Controller Class Initialized
DEBUG - 2024-10-10 09:17:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-10 09:17:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 09:17:03 --> Final output sent to browser
DEBUG - 2024-10-10 09:17:03 --> Total execution time: 0.1690
INFO - 2024-10-10 09:17:05 --> Config Class Initialized
INFO - 2024-10-10 09:17:05 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:17:05 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:17:05 --> Utf8 Class Initialized
INFO - 2024-10-10 09:17:05 --> URI Class Initialized
INFO - 2024-10-10 09:17:05 --> Router Class Initialized
INFO - 2024-10-10 09:17:05 --> Output Class Initialized
INFO - 2024-10-10 09:17:05 --> Security Class Initialized
DEBUG - 2024-10-10 09:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:17:05 --> Input Class Initialized
INFO - 2024-10-10 09:17:05 --> Language Class Initialized
INFO - 2024-10-10 09:17:05 --> Language Class Initialized
INFO - 2024-10-10 09:17:05 --> Config Class Initialized
INFO - 2024-10-10 09:17:05 --> Loader Class Initialized
INFO - 2024-10-10 09:17:05 --> Helper loaded: url_helper
INFO - 2024-10-10 09:17:05 --> Helper loaded: file_helper
INFO - 2024-10-10 09:17:05 --> Helper loaded: form_helper
INFO - 2024-10-10 09:17:05 --> Helper loaded: my_helper
INFO - 2024-10-10 09:17:05 --> Database Driver Class Initialized
INFO - 2024-10-10 09:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:17:05 --> Controller Class Initialized
INFO - 2024-10-10 09:17:05 --> Final output sent to browser
DEBUG - 2024-10-10 09:17:05 --> Total execution time: 0.2233
INFO - 2024-10-10 09:18:04 --> Config Class Initialized
INFO - 2024-10-10 09:18:04 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:18:04 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:18:04 --> Utf8 Class Initialized
INFO - 2024-10-10 09:18:04 --> URI Class Initialized
INFO - 2024-10-10 09:18:04 --> Router Class Initialized
INFO - 2024-10-10 09:18:04 --> Output Class Initialized
INFO - 2024-10-10 09:18:04 --> Security Class Initialized
DEBUG - 2024-10-10 09:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:18:04 --> Input Class Initialized
INFO - 2024-10-10 09:18:04 --> Language Class Initialized
INFO - 2024-10-10 09:18:04 --> Language Class Initialized
INFO - 2024-10-10 09:18:04 --> Config Class Initialized
INFO - 2024-10-10 09:18:04 --> Loader Class Initialized
INFO - 2024-10-10 09:18:04 --> Helper loaded: url_helper
INFO - 2024-10-10 09:18:04 --> Helper loaded: file_helper
INFO - 2024-10-10 09:18:04 --> Helper loaded: form_helper
INFO - 2024-10-10 09:18:04 --> Helper loaded: my_helper
INFO - 2024-10-10 09:18:04 --> Database Driver Class Initialized
INFO - 2024-10-10 09:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:18:04 --> Controller Class Initialized
INFO - 2024-10-10 09:18:05 --> Final output sent to browser
DEBUG - 2024-10-10 09:18:05 --> Total execution time: 0.7509
INFO - 2024-10-10 09:18:12 --> Config Class Initialized
INFO - 2024-10-10 09:18:12 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:18:12 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:18:12 --> Utf8 Class Initialized
INFO - 2024-10-10 09:18:12 --> URI Class Initialized
INFO - 2024-10-10 09:18:12 --> Router Class Initialized
INFO - 2024-10-10 09:18:12 --> Output Class Initialized
INFO - 2024-10-10 09:18:12 --> Security Class Initialized
DEBUG - 2024-10-10 09:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:18:12 --> Input Class Initialized
INFO - 2024-10-10 09:18:12 --> Language Class Initialized
INFO - 2024-10-10 09:18:12 --> Language Class Initialized
INFO - 2024-10-10 09:18:12 --> Config Class Initialized
INFO - 2024-10-10 09:18:12 --> Loader Class Initialized
INFO - 2024-10-10 09:18:12 --> Helper loaded: url_helper
INFO - 2024-10-10 09:18:12 --> Helper loaded: file_helper
INFO - 2024-10-10 09:18:12 --> Helper loaded: form_helper
INFO - 2024-10-10 09:18:12 --> Helper loaded: my_helper
INFO - 2024-10-10 09:18:12 --> Database Driver Class Initialized
INFO - 2024-10-10 09:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:18:12 --> Controller Class Initialized
INFO - 2024-10-10 09:18:12 --> Helper loaded: cookie_helper
INFO - 2024-10-10 09:18:13 --> Config Class Initialized
INFO - 2024-10-10 09:18:13 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:18:13 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:18:13 --> Utf8 Class Initialized
INFO - 2024-10-10 09:18:13 --> URI Class Initialized
INFO - 2024-10-10 09:18:13 --> Router Class Initialized
INFO - 2024-10-10 09:18:13 --> Output Class Initialized
INFO - 2024-10-10 09:18:13 --> Security Class Initialized
DEBUG - 2024-10-10 09:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:18:13 --> Input Class Initialized
INFO - 2024-10-10 09:18:13 --> Language Class Initialized
INFO - 2024-10-10 09:18:13 --> Language Class Initialized
INFO - 2024-10-10 09:18:13 --> Config Class Initialized
INFO - 2024-10-10 09:18:13 --> Loader Class Initialized
INFO - 2024-10-10 09:18:13 --> Helper loaded: url_helper
INFO - 2024-10-10 09:18:13 --> Helper loaded: file_helper
INFO - 2024-10-10 09:18:13 --> Helper loaded: form_helper
INFO - 2024-10-10 09:18:13 --> Helper loaded: my_helper
INFO - 2024-10-10 09:18:13 --> Database Driver Class Initialized
INFO - 2024-10-10 09:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:18:13 --> Controller Class Initialized
INFO - 2024-10-10 09:18:13 --> Config Class Initialized
INFO - 2024-10-10 09:18:13 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:18:13 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:18:13 --> Utf8 Class Initialized
INFO - 2024-10-10 09:18:13 --> URI Class Initialized
INFO - 2024-10-10 09:18:13 --> Router Class Initialized
INFO - 2024-10-10 09:18:13 --> Output Class Initialized
INFO - 2024-10-10 09:18:13 --> Security Class Initialized
DEBUG - 2024-10-10 09:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:18:13 --> Input Class Initialized
INFO - 2024-10-10 09:18:13 --> Language Class Initialized
INFO - 2024-10-10 09:18:13 --> Language Class Initialized
INFO - 2024-10-10 09:18:13 --> Config Class Initialized
INFO - 2024-10-10 09:18:13 --> Loader Class Initialized
INFO - 2024-10-10 09:18:13 --> Helper loaded: url_helper
INFO - 2024-10-10 09:18:13 --> Helper loaded: file_helper
INFO - 2024-10-10 09:18:13 --> Helper loaded: form_helper
INFO - 2024-10-10 09:18:13 --> Helper loaded: my_helper
INFO - 2024-10-10 09:18:13 --> Database Driver Class Initialized
INFO - 2024-10-10 09:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:18:13 --> Controller Class Initialized
DEBUG - 2024-10-10 09:18:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-10 09:18:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 09:18:13 --> Final output sent to browser
DEBUG - 2024-10-10 09:18:13 --> Total execution time: 0.0643
INFO - 2024-10-10 09:18:18 --> Config Class Initialized
INFO - 2024-10-10 09:18:18 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:18:18 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:18:18 --> Utf8 Class Initialized
INFO - 2024-10-10 09:18:18 --> URI Class Initialized
INFO - 2024-10-10 09:18:18 --> Router Class Initialized
INFO - 2024-10-10 09:18:18 --> Output Class Initialized
INFO - 2024-10-10 09:18:18 --> Security Class Initialized
DEBUG - 2024-10-10 09:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:18:18 --> Input Class Initialized
INFO - 2024-10-10 09:18:18 --> Language Class Initialized
INFO - 2024-10-10 09:18:18 --> Language Class Initialized
INFO - 2024-10-10 09:18:18 --> Config Class Initialized
INFO - 2024-10-10 09:18:18 --> Loader Class Initialized
INFO - 2024-10-10 09:18:18 --> Helper loaded: url_helper
INFO - 2024-10-10 09:18:18 --> Helper loaded: file_helper
INFO - 2024-10-10 09:18:18 --> Helper loaded: form_helper
INFO - 2024-10-10 09:18:18 --> Helper loaded: my_helper
INFO - 2024-10-10 09:18:19 --> Database Driver Class Initialized
INFO - 2024-10-10 09:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:18:19 --> Controller Class Initialized
INFO - 2024-10-10 09:18:19 --> Helper loaded: cookie_helper
INFO - 2024-10-10 09:18:19 --> Final output sent to browser
DEBUG - 2024-10-10 09:18:19 --> Total execution time: 0.1736
INFO - 2024-10-10 09:18:19 --> Config Class Initialized
INFO - 2024-10-10 09:18:19 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:18:19 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:18:19 --> Utf8 Class Initialized
INFO - 2024-10-10 09:18:19 --> URI Class Initialized
INFO - 2024-10-10 09:18:19 --> Router Class Initialized
INFO - 2024-10-10 09:18:19 --> Output Class Initialized
INFO - 2024-10-10 09:18:19 --> Security Class Initialized
DEBUG - 2024-10-10 09:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:18:19 --> Input Class Initialized
INFO - 2024-10-10 09:18:19 --> Language Class Initialized
INFO - 2024-10-10 09:18:19 --> Language Class Initialized
INFO - 2024-10-10 09:18:19 --> Config Class Initialized
INFO - 2024-10-10 09:18:19 --> Loader Class Initialized
INFO - 2024-10-10 09:18:19 --> Helper loaded: url_helper
INFO - 2024-10-10 09:18:19 --> Helper loaded: file_helper
INFO - 2024-10-10 09:18:19 --> Helper loaded: form_helper
INFO - 2024-10-10 09:18:19 --> Helper loaded: my_helper
INFO - 2024-10-10 09:18:19 --> Database Driver Class Initialized
INFO - 2024-10-10 09:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:18:19 --> Controller Class Initialized
DEBUG - 2024-10-10 09:18:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-10 09:18:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 09:18:19 --> Final output sent to browser
DEBUG - 2024-10-10 09:18:19 --> Total execution time: 0.1304
INFO - 2024-10-10 09:18:25 --> Config Class Initialized
INFO - 2024-10-10 09:18:25 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:18:25 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:18:25 --> Utf8 Class Initialized
INFO - 2024-10-10 09:18:25 --> URI Class Initialized
INFO - 2024-10-10 09:18:25 --> Router Class Initialized
INFO - 2024-10-10 09:18:25 --> Output Class Initialized
INFO - 2024-10-10 09:18:25 --> Security Class Initialized
DEBUG - 2024-10-10 09:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:18:25 --> Input Class Initialized
INFO - 2024-10-10 09:18:25 --> Language Class Initialized
INFO - 2024-10-10 09:18:25 --> Language Class Initialized
INFO - 2024-10-10 09:18:25 --> Config Class Initialized
INFO - 2024-10-10 09:18:25 --> Loader Class Initialized
INFO - 2024-10-10 09:18:25 --> Helper loaded: url_helper
INFO - 2024-10-10 09:18:25 --> Helper loaded: file_helper
INFO - 2024-10-10 09:18:25 --> Helper loaded: form_helper
INFO - 2024-10-10 09:18:25 --> Helper loaded: my_helper
INFO - 2024-10-10 09:18:25 --> Database Driver Class Initialized
INFO - 2024-10-10 09:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:18:25 --> Controller Class Initialized
DEBUG - 2024-10-10 09:18:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-10 09:18:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 09:18:25 --> Final output sent to browser
DEBUG - 2024-10-10 09:18:25 --> Total execution time: 0.1242
INFO - 2024-10-10 09:18:28 --> Config Class Initialized
INFO - 2024-10-10 09:18:28 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:18:28 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:18:28 --> Utf8 Class Initialized
INFO - 2024-10-10 09:18:28 --> URI Class Initialized
INFO - 2024-10-10 09:18:28 --> Router Class Initialized
INFO - 2024-10-10 09:18:28 --> Output Class Initialized
INFO - 2024-10-10 09:18:28 --> Security Class Initialized
DEBUG - 2024-10-10 09:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:18:28 --> Input Class Initialized
INFO - 2024-10-10 09:18:28 --> Language Class Initialized
INFO - 2024-10-10 09:18:28 --> Language Class Initialized
INFO - 2024-10-10 09:18:28 --> Config Class Initialized
INFO - 2024-10-10 09:18:28 --> Loader Class Initialized
INFO - 2024-10-10 09:18:28 --> Helper loaded: url_helper
INFO - 2024-10-10 09:18:28 --> Helper loaded: file_helper
INFO - 2024-10-10 09:18:28 --> Helper loaded: form_helper
INFO - 2024-10-10 09:18:28 --> Helper loaded: my_helper
INFO - 2024-10-10 09:18:28 --> Database Driver Class Initialized
INFO - 2024-10-10 09:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:18:28 --> Controller Class Initialized
DEBUG - 2024-10-10 09:18:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 09:18:35 --> Final output sent to browser
DEBUG - 2024-10-10 09:18:35 --> Total execution time: 6.8234
INFO - 2024-10-10 09:18:58 --> Config Class Initialized
INFO - 2024-10-10 09:18:58 --> Hooks Class Initialized
DEBUG - 2024-10-10 09:18:58 --> UTF-8 Support Enabled
INFO - 2024-10-10 09:18:58 --> Utf8 Class Initialized
INFO - 2024-10-10 09:18:58 --> URI Class Initialized
INFO - 2024-10-10 09:18:58 --> Router Class Initialized
INFO - 2024-10-10 09:18:58 --> Output Class Initialized
INFO - 2024-10-10 09:18:58 --> Security Class Initialized
DEBUG - 2024-10-10 09:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 09:18:58 --> Input Class Initialized
INFO - 2024-10-10 09:18:58 --> Language Class Initialized
INFO - 2024-10-10 09:18:58 --> Language Class Initialized
INFO - 2024-10-10 09:18:58 --> Config Class Initialized
INFO - 2024-10-10 09:18:58 --> Loader Class Initialized
INFO - 2024-10-10 09:18:58 --> Helper loaded: url_helper
INFO - 2024-10-10 09:18:58 --> Helper loaded: file_helper
INFO - 2024-10-10 09:18:58 --> Helper loaded: form_helper
INFO - 2024-10-10 09:18:58 --> Helper loaded: my_helper
INFO - 2024-10-10 09:18:58 --> Database Driver Class Initialized
INFO - 2024-10-10 09:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 09:18:58 --> Controller Class Initialized
DEBUG - 2024-10-10 09:18:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 09:19:10 --> Final output sent to browser
DEBUG - 2024-10-10 09:19:10 --> Total execution time: 11.9122
INFO - 2024-10-10 11:25:06 --> Config Class Initialized
INFO - 2024-10-10 11:25:06 --> Hooks Class Initialized
DEBUG - 2024-10-10 11:25:06 --> UTF-8 Support Enabled
INFO - 2024-10-10 11:25:06 --> Utf8 Class Initialized
INFO - 2024-10-10 11:25:06 --> URI Class Initialized
INFO - 2024-10-10 11:25:06 --> Router Class Initialized
INFO - 2024-10-10 11:25:06 --> Output Class Initialized
INFO - 2024-10-10 11:25:06 --> Security Class Initialized
DEBUG - 2024-10-10 11:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 11:25:06 --> Input Class Initialized
INFO - 2024-10-10 11:25:06 --> Language Class Initialized
INFO - 2024-10-10 11:25:06 --> Language Class Initialized
INFO - 2024-10-10 11:25:06 --> Config Class Initialized
INFO - 2024-10-10 11:25:06 --> Loader Class Initialized
INFO - 2024-10-10 11:25:06 --> Helper loaded: url_helper
INFO - 2024-10-10 11:25:06 --> Helper loaded: file_helper
INFO - 2024-10-10 11:25:06 --> Helper loaded: form_helper
INFO - 2024-10-10 11:25:06 --> Helper loaded: my_helper
INFO - 2024-10-10 11:25:06 --> Database Driver Class Initialized
INFO - 2024-10-10 11:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 11:25:06 --> Controller Class Initialized
DEBUG - 2024-10-10 11:25:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-10 11:25:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 11:25:06 --> Final output sent to browser
DEBUG - 2024-10-10 11:25:06 --> Total execution time: 0.0522
INFO - 2024-10-10 11:25:21 --> Config Class Initialized
INFO - 2024-10-10 11:25:21 --> Hooks Class Initialized
DEBUG - 2024-10-10 11:25:21 --> UTF-8 Support Enabled
INFO - 2024-10-10 11:25:21 --> Utf8 Class Initialized
INFO - 2024-10-10 11:25:21 --> URI Class Initialized
INFO - 2024-10-10 11:25:21 --> Router Class Initialized
INFO - 2024-10-10 11:25:21 --> Output Class Initialized
INFO - 2024-10-10 11:25:21 --> Security Class Initialized
DEBUG - 2024-10-10 11:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 11:25:21 --> Input Class Initialized
INFO - 2024-10-10 11:25:21 --> Language Class Initialized
INFO - 2024-10-10 11:25:21 --> Language Class Initialized
INFO - 2024-10-10 11:25:21 --> Config Class Initialized
INFO - 2024-10-10 11:25:21 --> Loader Class Initialized
INFO - 2024-10-10 11:25:21 --> Helper loaded: url_helper
INFO - 2024-10-10 11:25:21 --> Helper loaded: file_helper
INFO - 2024-10-10 11:25:21 --> Helper loaded: form_helper
INFO - 2024-10-10 11:25:21 --> Helper loaded: my_helper
INFO - 2024-10-10 11:25:21 --> Database Driver Class Initialized
INFO - 2024-10-10 11:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 11:25:21 --> Controller Class Initialized
INFO - 2024-10-10 11:25:21 --> Helper loaded: cookie_helper
INFO - 2024-10-10 11:25:21 --> Final output sent to browser
DEBUG - 2024-10-10 11:25:21 --> Total execution time: 0.0328
INFO - 2024-10-10 11:25:21 --> Config Class Initialized
INFO - 2024-10-10 11:25:21 --> Hooks Class Initialized
DEBUG - 2024-10-10 11:25:21 --> UTF-8 Support Enabled
INFO - 2024-10-10 11:25:21 --> Utf8 Class Initialized
INFO - 2024-10-10 11:25:21 --> URI Class Initialized
INFO - 2024-10-10 11:25:21 --> Router Class Initialized
INFO - 2024-10-10 11:25:21 --> Output Class Initialized
INFO - 2024-10-10 11:25:21 --> Security Class Initialized
DEBUG - 2024-10-10 11:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 11:25:21 --> Input Class Initialized
INFO - 2024-10-10 11:25:21 --> Language Class Initialized
INFO - 2024-10-10 11:25:21 --> Language Class Initialized
INFO - 2024-10-10 11:25:21 --> Config Class Initialized
INFO - 2024-10-10 11:25:21 --> Loader Class Initialized
INFO - 2024-10-10 11:25:21 --> Helper loaded: url_helper
INFO - 2024-10-10 11:25:21 --> Helper loaded: file_helper
INFO - 2024-10-10 11:25:21 --> Helper loaded: form_helper
INFO - 2024-10-10 11:25:21 --> Helper loaded: my_helper
INFO - 2024-10-10 11:25:21 --> Database Driver Class Initialized
INFO - 2024-10-10 11:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 11:25:21 --> Controller Class Initialized
DEBUG - 2024-10-10 11:25:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-10 11:25:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 11:25:21 --> Final output sent to browser
DEBUG - 2024-10-10 11:25:21 --> Total execution time: 0.0371
INFO - 2024-10-10 11:25:32 --> Config Class Initialized
INFO - 2024-10-10 11:25:32 --> Hooks Class Initialized
DEBUG - 2024-10-10 11:25:32 --> UTF-8 Support Enabled
INFO - 2024-10-10 11:25:32 --> Utf8 Class Initialized
INFO - 2024-10-10 11:25:32 --> URI Class Initialized
INFO - 2024-10-10 11:25:32 --> Router Class Initialized
INFO - 2024-10-10 11:25:32 --> Output Class Initialized
INFO - 2024-10-10 11:25:32 --> Security Class Initialized
DEBUG - 2024-10-10 11:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 11:25:32 --> Input Class Initialized
INFO - 2024-10-10 11:25:32 --> Language Class Initialized
INFO - 2024-10-10 11:25:33 --> Language Class Initialized
INFO - 2024-10-10 11:25:33 --> Config Class Initialized
INFO - 2024-10-10 11:25:33 --> Loader Class Initialized
INFO - 2024-10-10 11:25:33 --> Helper loaded: url_helper
INFO - 2024-10-10 11:25:33 --> Helper loaded: file_helper
INFO - 2024-10-10 11:25:33 --> Helper loaded: form_helper
INFO - 2024-10-10 11:25:33 --> Helper loaded: my_helper
INFO - 2024-10-10 11:25:33 --> Database Driver Class Initialized
INFO - 2024-10-10 11:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 11:25:33 --> Controller Class Initialized
DEBUG - 2024-10-10 11:25:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-10 11:25:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 11:25:33 --> Final output sent to browser
DEBUG - 2024-10-10 11:25:33 --> Total execution time: 0.0365
INFO - 2024-10-10 11:25:35 --> Config Class Initialized
INFO - 2024-10-10 11:25:35 --> Hooks Class Initialized
DEBUG - 2024-10-10 11:25:35 --> UTF-8 Support Enabled
INFO - 2024-10-10 11:25:35 --> Utf8 Class Initialized
INFO - 2024-10-10 11:25:35 --> URI Class Initialized
INFO - 2024-10-10 11:25:35 --> Router Class Initialized
INFO - 2024-10-10 11:25:35 --> Output Class Initialized
INFO - 2024-10-10 11:25:35 --> Security Class Initialized
DEBUG - 2024-10-10 11:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 11:25:35 --> Input Class Initialized
INFO - 2024-10-10 11:25:35 --> Language Class Initialized
INFO - 2024-10-10 11:25:35 --> Language Class Initialized
INFO - 2024-10-10 11:25:35 --> Config Class Initialized
INFO - 2024-10-10 11:25:35 --> Loader Class Initialized
INFO - 2024-10-10 11:25:35 --> Helper loaded: url_helper
INFO - 2024-10-10 11:25:35 --> Helper loaded: file_helper
INFO - 2024-10-10 11:25:35 --> Helper loaded: form_helper
INFO - 2024-10-10 11:25:35 --> Helper loaded: my_helper
INFO - 2024-10-10 11:25:35 --> Database Driver Class Initialized
INFO - 2024-10-10 11:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 11:25:35 --> Controller Class Initialized
DEBUG - 2024-10-10 11:25:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 11:25:38 --> Final output sent to browser
DEBUG - 2024-10-10 11:25:38 --> Total execution time: 2.9821
INFO - 2024-10-10 11:26:58 --> Config Class Initialized
INFO - 2024-10-10 11:26:58 --> Hooks Class Initialized
DEBUG - 2024-10-10 11:26:58 --> UTF-8 Support Enabled
INFO - 2024-10-10 11:26:58 --> Utf8 Class Initialized
INFO - 2024-10-10 11:26:58 --> URI Class Initialized
INFO - 2024-10-10 11:26:58 --> Router Class Initialized
INFO - 2024-10-10 11:26:58 --> Output Class Initialized
INFO - 2024-10-10 11:26:58 --> Security Class Initialized
DEBUG - 2024-10-10 11:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 11:26:58 --> Input Class Initialized
INFO - 2024-10-10 11:26:58 --> Language Class Initialized
INFO - 2024-10-10 11:26:58 --> Language Class Initialized
INFO - 2024-10-10 11:26:58 --> Config Class Initialized
INFO - 2024-10-10 11:26:58 --> Loader Class Initialized
INFO - 2024-10-10 11:26:58 --> Helper loaded: url_helper
INFO - 2024-10-10 11:26:58 --> Helper loaded: file_helper
INFO - 2024-10-10 11:26:58 --> Helper loaded: form_helper
INFO - 2024-10-10 11:26:58 --> Helper loaded: my_helper
INFO - 2024-10-10 11:26:58 --> Database Driver Class Initialized
INFO - 2024-10-10 11:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 11:26:58 --> Controller Class Initialized
DEBUG - 2024-10-10 11:26:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 11:27:01 --> Final output sent to browser
DEBUG - 2024-10-10 11:27:01 --> Total execution time: 2.9974
INFO - 2024-10-10 11:27:53 --> Config Class Initialized
INFO - 2024-10-10 11:27:53 --> Hooks Class Initialized
DEBUG - 2024-10-10 11:27:53 --> UTF-8 Support Enabled
INFO - 2024-10-10 11:27:53 --> Utf8 Class Initialized
INFO - 2024-10-10 11:27:53 --> URI Class Initialized
INFO - 2024-10-10 11:27:53 --> Router Class Initialized
INFO - 2024-10-10 11:27:53 --> Output Class Initialized
INFO - 2024-10-10 11:27:53 --> Security Class Initialized
DEBUG - 2024-10-10 11:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 11:27:53 --> Input Class Initialized
INFO - 2024-10-10 11:27:53 --> Language Class Initialized
INFO - 2024-10-10 11:27:53 --> Language Class Initialized
INFO - 2024-10-10 11:27:53 --> Config Class Initialized
INFO - 2024-10-10 11:27:53 --> Loader Class Initialized
INFO - 2024-10-10 11:27:53 --> Helper loaded: url_helper
INFO - 2024-10-10 11:27:53 --> Helper loaded: file_helper
INFO - 2024-10-10 11:27:53 --> Helper loaded: form_helper
INFO - 2024-10-10 11:27:53 --> Helper loaded: my_helper
INFO - 2024-10-10 11:27:53 --> Database Driver Class Initialized
INFO - 2024-10-10 11:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 11:27:53 --> Controller Class Initialized
DEBUG - 2024-10-10 11:27:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 11:27:56 --> Final output sent to browser
DEBUG - 2024-10-10 11:27:56 --> Total execution time: 3.0243
INFO - 2024-10-10 11:32:30 --> Config Class Initialized
INFO - 2024-10-10 11:32:30 --> Hooks Class Initialized
DEBUG - 2024-10-10 11:32:30 --> UTF-8 Support Enabled
INFO - 2024-10-10 11:32:30 --> Utf8 Class Initialized
INFO - 2024-10-10 11:32:30 --> URI Class Initialized
INFO - 2024-10-10 11:32:30 --> Router Class Initialized
INFO - 2024-10-10 11:32:30 --> Output Class Initialized
INFO - 2024-10-10 11:32:30 --> Security Class Initialized
DEBUG - 2024-10-10 11:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 11:32:30 --> Input Class Initialized
INFO - 2024-10-10 11:32:30 --> Language Class Initialized
INFO - 2024-10-10 11:32:30 --> Language Class Initialized
INFO - 2024-10-10 11:32:30 --> Config Class Initialized
INFO - 2024-10-10 11:32:30 --> Loader Class Initialized
INFO - 2024-10-10 11:32:30 --> Helper loaded: url_helper
INFO - 2024-10-10 11:32:30 --> Helper loaded: file_helper
INFO - 2024-10-10 11:32:30 --> Helper loaded: form_helper
INFO - 2024-10-10 11:32:30 --> Helper loaded: my_helper
INFO - 2024-10-10 11:32:30 --> Database Driver Class Initialized
INFO - 2024-10-10 11:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 11:32:30 --> Controller Class Initialized
DEBUG - 2024-10-10 11:32:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 11:32:33 --> Final output sent to browser
DEBUG - 2024-10-10 11:32:33 --> Total execution time: 3.4506
INFO - 2024-10-10 11:34:05 --> Config Class Initialized
INFO - 2024-10-10 11:34:05 --> Hooks Class Initialized
DEBUG - 2024-10-10 11:34:05 --> UTF-8 Support Enabled
INFO - 2024-10-10 11:34:05 --> Utf8 Class Initialized
INFO - 2024-10-10 11:34:05 --> URI Class Initialized
INFO - 2024-10-10 11:34:05 --> Router Class Initialized
INFO - 2024-10-10 11:34:05 --> Output Class Initialized
INFO - 2024-10-10 11:34:05 --> Security Class Initialized
DEBUG - 2024-10-10 11:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 11:34:05 --> Input Class Initialized
INFO - 2024-10-10 11:34:05 --> Language Class Initialized
INFO - 2024-10-10 11:34:05 --> Language Class Initialized
INFO - 2024-10-10 11:34:05 --> Config Class Initialized
INFO - 2024-10-10 11:34:05 --> Loader Class Initialized
INFO - 2024-10-10 11:34:05 --> Helper loaded: url_helper
INFO - 2024-10-10 11:34:05 --> Helper loaded: file_helper
INFO - 2024-10-10 11:34:05 --> Helper loaded: form_helper
INFO - 2024-10-10 11:34:05 --> Helper loaded: my_helper
INFO - 2024-10-10 11:34:05 --> Database Driver Class Initialized
INFO - 2024-10-10 11:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 11:34:05 --> Controller Class Initialized
DEBUG - 2024-10-10 11:34:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 11:34:08 --> Final output sent to browser
DEBUG - 2024-10-10 11:34:08 --> Total execution time: 3.1012
INFO - 2024-10-10 12:12:13 --> Config Class Initialized
INFO - 2024-10-10 12:12:13 --> Hooks Class Initialized
DEBUG - 2024-10-10 12:12:13 --> UTF-8 Support Enabled
INFO - 2024-10-10 12:12:13 --> Utf8 Class Initialized
INFO - 2024-10-10 12:12:13 --> URI Class Initialized
INFO - 2024-10-10 12:12:13 --> Router Class Initialized
INFO - 2024-10-10 12:12:13 --> Output Class Initialized
INFO - 2024-10-10 12:12:13 --> Security Class Initialized
DEBUG - 2024-10-10 12:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 12:12:13 --> Input Class Initialized
INFO - 2024-10-10 12:12:13 --> Language Class Initialized
INFO - 2024-10-10 12:12:13 --> Language Class Initialized
INFO - 2024-10-10 12:12:13 --> Config Class Initialized
INFO - 2024-10-10 12:12:13 --> Loader Class Initialized
INFO - 2024-10-10 12:12:13 --> Helper loaded: url_helper
INFO - 2024-10-10 12:12:13 --> Helper loaded: file_helper
INFO - 2024-10-10 12:12:13 --> Helper loaded: form_helper
INFO - 2024-10-10 12:12:13 --> Helper loaded: my_helper
INFO - 2024-10-10 12:12:13 --> Database Driver Class Initialized
INFO - 2024-10-10 12:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 12:12:13 --> Controller Class Initialized
DEBUG - 2024-10-10 12:12:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-10 12:12:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 12:12:13 --> Final output sent to browser
DEBUG - 2024-10-10 12:12:13 --> Total execution time: 0.0545
INFO - 2024-10-10 12:12:22 --> Config Class Initialized
INFO - 2024-10-10 12:12:22 --> Hooks Class Initialized
DEBUG - 2024-10-10 12:12:22 --> UTF-8 Support Enabled
INFO - 2024-10-10 12:12:22 --> Utf8 Class Initialized
INFO - 2024-10-10 12:12:22 --> URI Class Initialized
INFO - 2024-10-10 12:12:22 --> Router Class Initialized
INFO - 2024-10-10 12:12:22 --> Output Class Initialized
INFO - 2024-10-10 12:12:22 --> Security Class Initialized
DEBUG - 2024-10-10 12:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 12:12:22 --> Input Class Initialized
INFO - 2024-10-10 12:12:22 --> Language Class Initialized
INFO - 2024-10-10 12:12:22 --> Language Class Initialized
INFO - 2024-10-10 12:12:22 --> Config Class Initialized
INFO - 2024-10-10 12:12:22 --> Loader Class Initialized
INFO - 2024-10-10 12:12:22 --> Helper loaded: url_helper
INFO - 2024-10-10 12:12:22 --> Helper loaded: file_helper
INFO - 2024-10-10 12:12:22 --> Helper loaded: form_helper
INFO - 2024-10-10 12:12:22 --> Helper loaded: my_helper
INFO - 2024-10-10 12:12:22 --> Database Driver Class Initialized
INFO - 2024-10-10 12:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 12:12:22 --> Controller Class Initialized
DEBUG - 2024-10-10 12:12:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 12:12:29 --> Final output sent to browser
DEBUG - 2024-10-10 12:12:29 --> Total execution time: 7.0307
INFO - 2024-10-10 16:58:50 --> Config Class Initialized
INFO - 2024-10-10 16:58:50 --> Hooks Class Initialized
DEBUG - 2024-10-10 16:58:50 --> UTF-8 Support Enabled
INFO - 2024-10-10 16:58:50 --> Utf8 Class Initialized
INFO - 2024-10-10 16:58:50 --> URI Class Initialized
INFO - 2024-10-10 16:58:50 --> Router Class Initialized
INFO - 2024-10-10 16:58:50 --> Output Class Initialized
INFO - 2024-10-10 16:58:50 --> Security Class Initialized
DEBUG - 2024-10-10 16:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 16:58:50 --> Input Class Initialized
INFO - 2024-10-10 16:58:50 --> Language Class Initialized
INFO - 2024-10-10 16:58:50 --> Language Class Initialized
INFO - 2024-10-10 16:58:50 --> Config Class Initialized
INFO - 2024-10-10 16:58:50 --> Loader Class Initialized
INFO - 2024-10-10 16:58:50 --> Helper loaded: url_helper
INFO - 2024-10-10 16:58:50 --> Helper loaded: file_helper
INFO - 2024-10-10 16:58:50 --> Helper loaded: form_helper
INFO - 2024-10-10 16:58:50 --> Helper loaded: my_helper
INFO - 2024-10-10 16:58:50 --> Database Driver Class Initialized
INFO - 2024-10-10 16:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 16:58:50 --> Controller Class Initialized
INFO - 2024-10-10 16:58:50 --> Config Class Initialized
INFO - 2024-10-10 16:58:50 --> Hooks Class Initialized
DEBUG - 2024-10-10 16:58:50 --> UTF-8 Support Enabled
INFO - 2024-10-10 16:58:50 --> Utf8 Class Initialized
INFO - 2024-10-10 16:58:50 --> URI Class Initialized
INFO - 2024-10-10 16:58:50 --> Router Class Initialized
INFO - 2024-10-10 16:58:50 --> Output Class Initialized
INFO - 2024-10-10 16:58:50 --> Security Class Initialized
DEBUG - 2024-10-10 16:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 16:58:50 --> Input Class Initialized
INFO - 2024-10-10 16:58:50 --> Language Class Initialized
INFO - 2024-10-10 16:58:50 --> Language Class Initialized
INFO - 2024-10-10 16:58:50 --> Config Class Initialized
INFO - 2024-10-10 16:58:50 --> Loader Class Initialized
INFO - 2024-10-10 16:58:50 --> Helper loaded: url_helper
INFO - 2024-10-10 16:58:50 --> Helper loaded: file_helper
INFO - 2024-10-10 16:58:50 --> Helper loaded: form_helper
INFO - 2024-10-10 16:58:50 --> Helper loaded: my_helper
INFO - 2024-10-10 16:58:50 --> Database Driver Class Initialized
INFO - 2024-10-10 16:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 16:58:50 --> Controller Class Initialized
DEBUG - 2024-10-10 16:58:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-10 16:58:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 16:58:51 --> Final output sent to browser
DEBUG - 2024-10-10 16:58:51 --> Total execution time: 0.1273
INFO - 2024-10-10 16:58:55 --> Config Class Initialized
INFO - 2024-10-10 16:58:55 --> Hooks Class Initialized
DEBUG - 2024-10-10 16:58:55 --> UTF-8 Support Enabled
INFO - 2024-10-10 16:58:55 --> Utf8 Class Initialized
INFO - 2024-10-10 16:58:55 --> URI Class Initialized
INFO - 2024-10-10 16:58:55 --> Router Class Initialized
INFO - 2024-10-10 16:58:55 --> Output Class Initialized
INFO - 2024-10-10 16:58:55 --> Security Class Initialized
DEBUG - 2024-10-10 16:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 16:58:55 --> Input Class Initialized
INFO - 2024-10-10 16:58:55 --> Language Class Initialized
INFO - 2024-10-10 16:58:55 --> Language Class Initialized
INFO - 2024-10-10 16:58:55 --> Config Class Initialized
INFO - 2024-10-10 16:58:55 --> Loader Class Initialized
INFO - 2024-10-10 16:58:55 --> Helper loaded: url_helper
INFO - 2024-10-10 16:58:55 --> Helper loaded: file_helper
INFO - 2024-10-10 16:58:55 --> Helper loaded: form_helper
INFO - 2024-10-10 16:58:55 --> Helper loaded: my_helper
INFO - 2024-10-10 16:58:55 --> Database Driver Class Initialized
INFO - 2024-10-10 16:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 16:58:55 --> Controller Class Initialized
INFO - 2024-10-10 16:58:56 --> Helper loaded: cookie_helper
INFO - 2024-10-10 16:58:56 --> Final output sent to browser
DEBUG - 2024-10-10 16:58:56 --> Total execution time: 0.3070
INFO - 2024-10-10 16:58:56 --> Config Class Initialized
INFO - 2024-10-10 16:58:56 --> Hooks Class Initialized
DEBUG - 2024-10-10 16:58:56 --> UTF-8 Support Enabled
INFO - 2024-10-10 16:58:56 --> Utf8 Class Initialized
INFO - 2024-10-10 16:58:56 --> URI Class Initialized
INFO - 2024-10-10 16:58:56 --> Router Class Initialized
INFO - 2024-10-10 16:58:56 --> Output Class Initialized
INFO - 2024-10-10 16:58:56 --> Security Class Initialized
DEBUG - 2024-10-10 16:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 16:58:56 --> Input Class Initialized
INFO - 2024-10-10 16:58:56 --> Language Class Initialized
INFO - 2024-10-10 16:58:56 --> Language Class Initialized
INFO - 2024-10-10 16:58:56 --> Config Class Initialized
INFO - 2024-10-10 16:58:56 --> Loader Class Initialized
INFO - 2024-10-10 16:58:56 --> Helper loaded: url_helper
INFO - 2024-10-10 16:58:56 --> Helper loaded: file_helper
INFO - 2024-10-10 16:58:56 --> Helper loaded: form_helper
INFO - 2024-10-10 16:58:56 --> Helper loaded: my_helper
INFO - 2024-10-10 16:58:56 --> Database Driver Class Initialized
INFO - 2024-10-10 16:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 16:58:56 --> Controller Class Initialized
DEBUG - 2024-10-10 16:58:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-10 16:58:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 16:58:56 --> Final output sent to browser
DEBUG - 2024-10-10 16:58:56 --> Total execution time: 0.0453
INFO - 2024-10-10 16:59:11 --> Config Class Initialized
INFO - 2024-10-10 16:59:11 --> Hooks Class Initialized
DEBUG - 2024-10-10 16:59:11 --> UTF-8 Support Enabled
INFO - 2024-10-10 16:59:11 --> Utf8 Class Initialized
INFO - 2024-10-10 16:59:11 --> URI Class Initialized
INFO - 2024-10-10 16:59:11 --> Router Class Initialized
INFO - 2024-10-10 16:59:11 --> Output Class Initialized
INFO - 2024-10-10 16:59:11 --> Security Class Initialized
DEBUG - 2024-10-10 16:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 16:59:11 --> Input Class Initialized
INFO - 2024-10-10 16:59:11 --> Language Class Initialized
INFO - 2024-10-10 16:59:11 --> Language Class Initialized
INFO - 2024-10-10 16:59:11 --> Config Class Initialized
INFO - 2024-10-10 16:59:11 --> Loader Class Initialized
INFO - 2024-10-10 16:59:11 --> Helper loaded: url_helper
INFO - 2024-10-10 16:59:11 --> Helper loaded: file_helper
INFO - 2024-10-10 16:59:11 --> Helper loaded: form_helper
INFO - 2024-10-10 16:59:11 --> Helper loaded: my_helper
INFO - 2024-10-10 16:59:11 --> Database Driver Class Initialized
INFO - 2024-10-10 16:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 16:59:11 --> Controller Class Initialized
DEBUG - 2024-10-10 16:59:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-10 16:59:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 16:59:11 --> Final output sent to browser
DEBUG - 2024-10-10 16:59:11 --> Total execution time: 0.0496
INFO - 2024-10-10 16:59:12 --> Config Class Initialized
INFO - 2024-10-10 16:59:12 --> Hooks Class Initialized
DEBUG - 2024-10-10 16:59:12 --> UTF-8 Support Enabled
INFO - 2024-10-10 16:59:12 --> Utf8 Class Initialized
INFO - 2024-10-10 16:59:12 --> URI Class Initialized
INFO - 2024-10-10 16:59:12 --> Router Class Initialized
INFO - 2024-10-10 16:59:12 --> Output Class Initialized
INFO - 2024-10-10 16:59:12 --> Security Class Initialized
DEBUG - 2024-10-10 16:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 16:59:12 --> Input Class Initialized
INFO - 2024-10-10 16:59:12 --> Language Class Initialized
INFO - 2024-10-10 16:59:12 --> Language Class Initialized
INFO - 2024-10-10 16:59:12 --> Config Class Initialized
INFO - 2024-10-10 16:59:12 --> Loader Class Initialized
INFO - 2024-10-10 16:59:12 --> Helper loaded: url_helper
INFO - 2024-10-10 16:59:12 --> Helper loaded: file_helper
INFO - 2024-10-10 16:59:12 --> Helper loaded: form_helper
INFO - 2024-10-10 16:59:12 --> Helper loaded: my_helper
INFO - 2024-10-10 16:59:12 --> Database Driver Class Initialized
INFO - 2024-10-10 16:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 16:59:12 --> Controller Class Initialized
DEBUG - 2024-10-10 16:59:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 16:59:15 --> Final output sent to browser
DEBUG - 2024-10-10 16:59:15 --> Total execution time: 3.3104
INFO - 2024-10-10 17:05:13 --> Config Class Initialized
INFO - 2024-10-10 17:05:13 --> Hooks Class Initialized
DEBUG - 2024-10-10 17:05:13 --> UTF-8 Support Enabled
INFO - 2024-10-10 17:05:13 --> Utf8 Class Initialized
INFO - 2024-10-10 17:05:13 --> URI Class Initialized
INFO - 2024-10-10 17:05:13 --> Router Class Initialized
INFO - 2024-10-10 17:05:13 --> Output Class Initialized
INFO - 2024-10-10 17:05:13 --> Security Class Initialized
DEBUG - 2024-10-10 17:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 17:05:13 --> Input Class Initialized
INFO - 2024-10-10 17:05:13 --> Language Class Initialized
INFO - 2024-10-10 17:05:13 --> Language Class Initialized
INFO - 2024-10-10 17:05:13 --> Config Class Initialized
INFO - 2024-10-10 17:05:13 --> Loader Class Initialized
INFO - 2024-10-10 17:05:13 --> Helper loaded: url_helper
INFO - 2024-10-10 17:05:13 --> Helper loaded: file_helper
INFO - 2024-10-10 17:05:13 --> Helper loaded: form_helper
INFO - 2024-10-10 17:05:13 --> Helper loaded: my_helper
INFO - 2024-10-10 17:05:13 --> Database Driver Class Initialized
INFO - 2024-10-10 17:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 17:05:13 --> Controller Class Initialized
DEBUG - 2024-10-10 17:05:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 17:05:29 --> Config Class Initialized
INFO - 2024-10-10 17:05:29 --> Hooks Class Initialized
DEBUG - 2024-10-10 17:05:29 --> UTF-8 Support Enabled
INFO - 2024-10-10 17:05:29 --> Utf8 Class Initialized
INFO - 2024-10-10 17:05:29 --> URI Class Initialized
INFO - 2024-10-10 17:05:29 --> Router Class Initialized
INFO - 2024-10-10 17:05:29 --> Output Class Initialized
INFO - 2024-10-10 17:05:29 --> Security Class Initialized
DEBUG - 2024-10-10 17:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 17:05:29 --> Input Class Initialized
INFO - 2024-10-10 17:05:29 --> Language Class Initialized
INFO - 2024-10-10 17:05:29 --> Language Class Initialized
INFO - 2024-10-10 17:05:29 --> Config Class Initialized
INFO - 2024-10-10 17:05:29 --> Loader Class Initialized
INFO - 2024-10-10 17:05:29 --> Helper loaded: url_helper
INFO - 2024-10-10 17:05:29 --> Helper loaded: file_helper
INFO - 2024-10-10 17:05:29 --> Helper loaded: form_helper
INFO - 2024-10-10 17:05:29 --> Helper loaded: my_helper
INFO - 2024-10-10 17:05:29 --> Database Driver Class Initialized
ERROR - 2024-10-10 17:05:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /www/wwwroot/report.mhis.link/bangka/secondary/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2024-10-10 17:05:29 --> Unable to connect to the database
INFO - 2024-10-10 17:05:29 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-10 17:05:36 --> Final output sent to browser
DEBUG - 2024-10-10 17:05:36 --> Total execution time: 23.4438
INFO - 2024-10-10 17:05:40 --> Config Class Initialized
INFO - 2024-10-10 17:05:40 --> Hooks Class Initialized
DEBUG - 2024-10-10 17:05:40 --> UTF-8 Support Enabled
INFO - 2024-10-10 17:05:40 --> Utf8 Class Initialized
INFO - 2024-10-10 17:05:41 --> URI Class Initialized
INFO - 2024-10-10 17:05:41 --> Router Class Initialized
INFO - 2024-10-10 17:05:41 --> Output Class Initialized
INFO - 2024-10-10 17:05:41 --> Security Class Initialized
DEBUG - 2024-10-10 17:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 17:05:41 --> Input Class Initialized
INFO - 2024-10-10 17:05:41 --> Language Class Initialized
INFO - 2024-10-10 17:05:41 --> Language Class Initialized
INFO - 2024-10-10 17:05:41 --> Config Class Initialized
INFO - 2024-10-10 17:05:41 --> Loader Class Initialized
INFO - 2024-10-10 17:05:41 --> Helper loaded: url_helper
INFO - 2024-10-10 17:05:41 --> Helper loaded: file_helper
INFO - 2024-10-10 17:05:41 --> Helper loaded: form_helper
INFO - 2024-10-10 17:05:41 --> Helper loaded: my_helper
INFO - 2024-10-10 17:05:41 --> Database Driver Class Initialized
INFO - 2024-10-10 17:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 17:05:41 --> Controller Class Initialized
DEBUG - 2024-10-10 17:05:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 17:05:49 --> Final output sent to browser
DEBUG - 2024-10-10 17:05:49 --> Total execution time: 8.2844
INFO - 2024-10-10 17:06:02 --> Config Class Initialized
INFO - 2024-10-10 17:06:02 --> Hooks Class Initialized
DEBUG - 2024-10-10 17:06:02 --> UTF-8 Support Enabled
INFO - 2024-10-10 17:06:02 --> Utf8 Class Initialized
INFO - 2024-10-10 17:06:02 --> URI Class Initialized
INFO - 2024-10-10 17:06:02 --> Router Class Initialized
INFO - 2024-10-10 17:06:02 --> Output Class Initialized
INFO - 2024-10-10 17:06:02 --> Security Class Initialized
DEBUG - 2024-10-10 17:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 17:06:02 --> Input Class Initialized
INFO - 2024-10-10 17:06:02 --> Language Class Initialized
INFO - 2024-10-10 17:06:02 --> Language Class Initialized
INFO - 2024-10-10 17:06:02 --> Config Class Initialized
INFO - 2024-10-10 17:06:02 --> Loader Class Initialized
INFO - 2024-10-10 17:06:02 --> Helper loaded: url_helper
INFO - 2024-10-10 17:06:02 --> Helper loaded: file_helper
INFO - 2024-10-10 17:06:02 --> Helper loaded: form_helper
INFO - 2024-10-10 17:06:02 --> Helper loaded: my_helper
INFO - 2024-10-10 17:06:02 --> Database Driver Class Initialized
INFO - 2024-10-10 17:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 17:06:02 --> Controller Class Initialized
ERROR - 2024-10-10 17:06:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2393
DEBUG - 2024-10-10 17:06:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-10 17:06:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 17:06:02 --> Final output sent to browser
DEBUG - 2024-10-10 17:06:02 --> Total execution time: 0.1121
INFO - 2024-10-10 17:06:03 --> Config Class Initialized
INFO - 2024-10-10 17:06:03 --> Hooks Class Initialized
DEBUG - 2024-10-10 17:06:03 --> UTF-8 Support Enabled
INFO - 2024-10-10 17:06:03 --> Utf8 Class Initialized
INFO - 2024-10-10 17:06:03 --> URI Class Initialized
INFO - 2024-10-10 17:06:03 --> Router Class Initialized
INFO - 2024-10-10 17:06:03 --> Output Class Initialized
INFO - 2024-10-10 17:06:03 --> Security Class Initialized
DEBUG - 2024-10-10 17:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 17:06:03 --> Input Class Initialized
INFO - 2024-10-10 17:06:03 --> Language Class Initialized
INFO - 2024-10-10 17:06:03 --> Language Class Initialized
INFO - 2024-10-10 17:06:03 --> Config Class Initialized
INFO - 2024-10-10 17:06:03 --> Loader Class Initialized
INFO - 2024-10-10 17:06:03 --> Helper loaded: url_helper
INFO - 2024-10-10 17:06:03 --> Helper loaded: file_helper
INFO - 2024-10-10 17:06:03 --> Helper loaded: form_helper
INFO - 2024-10-10 17:06:03 --> Helper loaded: my_helper
INFO - 2024-10-10 17:06:04 --> Database Driver Class Initialized
INFO - 2024-10-10 17:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 17:06:04 --> Controller Class Initialized
DEBUG - 2024-10-10 17:06:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 17:06:04 --> Config Class Initialized
INFO - 2024-10-10 17:06:04 --> Hooks Class Initialized
DEBUG - 2024-10-10 17:06:04 --> UTF-8 Support Enabled
INFO - 2024-10-10 17:06:04 --> Utf8 Class Initialized
INFO - 2024-10-10 17:06:04 --> URI Class Initialized
INFO - 2024-10-10 17:06:04 --> Router Class Initialized
INFO - 2024-10-10 17:06:04 --> Output Class Initialized
INFO - 2024-10-10 17:06:04 --> Security Class Initialized
DEBUG - 2024-10-10 17:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 17:06:04 --> Input Class Initialized
INFO - 2024-10-10 17:06:04 --> Language Class Initialized
INFO - 2024-10-10 17:06:04 --> Language Class Initialized
INFO - 2024-10-10 17:06:04 --> Config Class Initialized
INFO - 2024-10-10 17:06:04 --> Loader Class Initialized
INFO - 2024-10-10 17:06:04 --> Helper loaded: url_helper
INFO - 2024-10-10 17:06:04 --> Helper loaded: file_helper
INFO - 2024-10-10 17:06:04 --> Helper loaded: form_helper
INFO - 2024-10-10 17:06:04 --> Helper loaded: my_helper
INFO - 2024-10-10 17:06:04 --> Database Driver Class Initialized
INFO - 2024-10-10 17:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 17:06:04 --> Controller Class Initialized
ERROR - 2024-10-10 17:06:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2393
DEBUG - 2024-10-10 17:06:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-10 17:06:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 17:06:04 --> Final output sent to browser
DEBUG - 2024-10-10 17:06:04 --> Total execution time: 0.0925
INFO - 2024-10-10 17:06:08 --> Config Class Initialized
INFO - 2024-10-10 17:06:08 --> Hooks Class Initialized
DEBUG - 2024-10-10 17:06:08 --> UTF-8 Support Enabled
INFO - 2024-10-10 17:06:08 --> Utf8 Class Initialized
INFO - 2024-10-10 17:06:08 --> URI Class Initialized
INFO - 2024-10-10 17:06:08 --> Router Class Initialized
INFO - 2024-10-10 17:06:08 --> Output Class Initialized
INFO - 2024-10-10 17:06:08 --> Security Class Initialized
DEBUG - 2024-10-10 17:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 17:06:08 --> Input Class Initialized
INFO - 2024-10-10 17:06:08 --> Language Class Initialized
INFO - 2024-10-10 17:06:08 --> Language Class Initialized
INFO - 2024-10-10 17:06:08 --> Config Class Initialized
INFO - 2024-10-10 17:06:08 --> Loader Class Initialized
INFO - 2024-10-10 17:06:08 --> Helper loaded: url_helper
INFO - 2024-10-10 17:06:08 --> Helper loaded: file_helper
INFO - 2024-10-10 17:06:08 --> Helper loaded: form_helper
INFO - 2024-10-10 17:06:08 --> Helper loaded: my_helper
INFO - 2024-10-10 17:06:08 --> Database Driver Class Initialized
INFO - 2024-10-10 17:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 17:06:08 --> Controller Class Initialized
DEBUG - 2024-10-10 17:06:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-10 17:06:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 17:06:08 --> Final output sent to browser
DEBUG - 2024-10-10 17:06:08 --> Total execution time: 0.2946
INFO - 2024-10-10 17:06:11 --> Final output sent to browser
DEBUG - 2024-10-10 17:06:11 --> Total execution time: 7.4548
INFO - 2024-10-10 17:06:15 --> Config Class Initialized
INFO - 2024-10-10 17:06:15 --> Hooks Class Initialized
DEBUG - 2024-10-10 17:06:15 --> UTF-8 Support Enabled
INFO - 2024-10-10 17:06:15 --> Utf8 Class Initialized
INFO - 2024-10-10 17:06:15 --> URI Class Initialized
INFO - 2024-10-10 17:06:15 --> Router Class Initialized
INFO - 2024-10-10 17:06:15 --> Output Class Initialized
INFO - 2024-10-10 17:06:15 --> Security Class Initialized
DEBUG - 2024-10-10 17:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 17:06:15 --> Input Class Initialized
INFO - 2024-10-10 17:06:15 --> Language Class Initialized
INFO - 2024-10-10 17:06:15 --> Language Class Initialized
INFO - 2024-10-10 17:06:15 --> Config Class Initialized
INFO - 2024-10-10 17:06:15 --> Loader Class Initialized
INFO - 2024-10-10 17:06:15 --> Helper loaded: url_helper
INFO - 2024-10-10 17:06:15 --> Helper loaded: file_helper
INFO - 2024-10-10 17:06:15 --> Helper loaded: form_helper
INFO - 2024-10-10 17:06:15 --> Helper loaded: my_helper
INFO - 2024-10-10 17:06:15 --> Database Driver Class Initialized
INFO - 2024-10-10 17:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 17:06:16 --> Controller Class Initialized
INFO - 2024-10-10 17:06:16 --> Helper loaded: cookie_helper
INFO - 2024-10-10 17:06:16 --> Final output sent to browser
DEBUG - 2024-10-10 17:06:16 --> Total execution time: 0.2249
INFO - 2024-10-10 17:06:16 --> Config Class Initialized
INFO - 2024-10-10 17:06:16 --> Hooks Class Initialized
DEBUG - 2024-10-10 17:06:16 --> UTF-8 Support Enabled
INFO - 2024-10-10 17:06:16 --> Utf8 Class Initialized
INFO - 2024-10-10 17:06:16 --> URI Class Initialized
INFO - 2024-10-10 17:06:16 --> Router Class Initialized
INFO - 2024-10-10 17:06:16 --> Output Class Initialized
INFO - 2024-10-10 17:06:16 --> Security Class Initialized
DEBUG - 2024-10-10 17:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 17:06:16 --> Input Class Initialized
INFO - 2024-10-10 17:06:16 --> Language Class Initialized
INFO - 2024-10-10 17:06:16 --> Language Class Initialized
INFO - 2024-10-10 17:06:16 --> Config Class Initialized
INFO - 2024-10-10 17:06:16 --> Loader Class Initialized
INFO - 2024-10-10 17:06:16 --> Helper loaded: url_helper
INFO - 2024-10-10 17:06:16 --> Helper loaded: file_helper
INFO - 2024-10-10 17:06:16 --> Helper loaded: form_helper
INFO - 2024-10-10 17:06:16 --> Helper loaded: my_helper
INFO - 2024-10-10 17:06:16 --> Database Driver Class Initialized
INFO - 2024-10-10 17:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 17:06:16 --> Controller Class Initialized
DEBUG - 2024-10-10 17:06:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-10 17:06:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 17:06:16 --> Final output sent to browser
DEBUG - 2024-10-10 17:06:16 --> Total execution time: 0.1099
INFO - 2024-10-10 17:06:20 --> Config Class Initialized
INFO - 2024-10-10 17:06:20 --> Hooks Class Initialized
DEBUG - 2024-10-10 17:06:20 --> UTF-8 Support Enabled
INFO - 2024-10-10 17:06:20 --> Utf8 Class Initialized
INFO - 2024-10-10 17:06:20 --> URI Class Initialized
INFO - 2024-10-10 17:06:20 --> Router Class Initialized
INFO - 2024-10-10 17:06:20 --> Output Class Initialized
INFO - 2024-10-10 17:06:20 --> Security Class Initialized
DEBUG - 2024-10-10 17:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 17:06:20 --> Input Class Initialized
INFO - 2024-10-10 17:06:20 --> Language Class Initialized
INFO - 2024-10-10 17:06:20 --> Language Class Initialized
INFO - 2024-10-10 17:06:20 --> Config Class Initialized
INFO - 2024-10-10 17:06:20 --> Loader Class Initialized
INFO - 2024-10-10 17:06:20 --> Helper loaded: url_helper
INFO - 2024-10-10 17:06:20 --> Helper loaded: file_helper
INFO - 2024-10-10 17:06:20 --> Helper loaded: form_helper
INFO - 2024-10-10 17:06:20 --> Helper loaded: my_helper
INFO - 2024-10-10 17:06:20 --> Database Driver Class Initialized
INFO - 2024-10-10 17:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 17:06:20 --> Controller Class Initialized
DEBUG - 2024-10-10 17:06:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-10 17:06:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 17:06:20 --> Final output sent to browser
DEBUG - 2024-10-10 17:06:20 --> Total execution time: 0.1028
INFO - 2024-10-10 17:06:34 --> Config Class Initialized
INFO - 2024-10-10 17:06:34 --> Hooks Class Initialized
DEBUG - 2024-10-10 17:06:34 --> UTF-8 Support Enabled
INFO - 2024-10-10 17:06:34 --> Utf8 Class Initialized
INFO - 2024-10-10 17:06:34 --> URI Class Initialized
INFO - 2024-10-10 17:06:34 --> Router Class Initialized
INFO - 2024-10-10 17:06:34 --> Output Class Initialized
INFO - 2024-10-10 17:06:34 --> Security Class Initialized
DEBUG - 2024-10-10 17:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 17:06:34 --> Input Class Initialized
INFO - 2024-10-10 17:06:34 --> Language Class Initialized
INFO - 2024-10-10 17:06:34 --> Language Class Initialized
INFO - 2024-10-10 17:06:34 --> Config Class Initialized
INFO - 2024-10-10 17:06:34 --> Loader Class Initialized
INFO - 2024-10-10 17:06:34 --> Helper loaded: url_helper
INFO - 2024-10-10 17:06:34 --> Helper loaded: file_helper
INFO - 2024-10-10 17:06:34 --> Helper loaded: form_helper
INFO - 2024-10-10 17:06:34 --> Helper loaded: my_helper
INFO - 2024-10-10 17:06:34 --> Database Driver Class Initialized
INFO - 2024-10-10 17:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 17:06:34 --> Controller Class Initialized
DEBUG - 2024-10-10 17:06:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 17:06:37 --> Final output sent to browser
DEBUG - 2024-10-10 17:06:37 --> Total execution time: 3.5909
INFO - 2024-10-10 17:06:49 --> Config Class Initialized
INFO - 2024-10-10 17:06:49 --> Hooks Class Initialized
DEBUG - 2024-10-10 17:06:49 --> UTF-8 Support Enabled
INFO - 2024-10-10 17:06:49 --> Utf8 Class Initialized
INFO - 2024-10-10 17:06:49 --> URI Class Initialized
INFO - 2024-10-10 17:06:49 --> Router Class Initialized
INFO - 2024-10-10 17:06:49 --> Output Class Initialized
INFO - 2024-10-10 17:06:49 --> Security Class Initialized
DEBUG - 2024-10-10 17:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 17:06:49 --> Input Class Initialized
INFO - 2024-10-10 17:06:49 --> Language Class Initialized
INFO - 2024-10-10 17:06:49 --> Language Class Initialized
INFO - 2024-10-10 17:06:49 --> Config Class Initialized
INFO - 2024-10-10 17:06:49 --> Loader Class Initialized
INFO - 2024-10-10 17:06:49 --> Helper loaded: url_helper
INFO - 2024-10-10 17:06:49 --> Helper loaded: file_helper
INFO - 2024-10-10 17:06:49 --> Helper loaded: form_helper
INFO - 2024-10-10 17:06:49 --> Helper loaded: my_helper
INFO - 2024-10-10 17:06:49 --> Database Driver Class Initialized
INFO - 2024-10-10 17:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 17:06:49 --> Controller Class Initialized
DEBUG - 2024-10-10 17:06:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 17:06:53 --> Final output sent to browser
DEBUG - 2024-10-10 17:06:53 --> Total execution time: 3.8671
INFO - 2024-10-10 17:07:25 --> Config Class Initialized
INFO - 2024-10-10 17:07:25 --> Hooks Class Initialized
DEBUG - 2024-10-10 17:07:25 --> UTF-8 Support Enabled
INFO - 2024-10-10 17:07:25 --> Utf8 Class Initialized
INFO - 2024-10-10 17:07:25 --> URI Class Initialized
INFO - 2024-10-10 17:07:25 --> Router Class Initialized
INFO - 2024-10-10 17:07:25 --> Output Class Initialized
INFO - 2024-10-10 17:07:25 --> Security Class Initialized
DEBUG - 2024-10-10 17:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 17:07:25 --> Input Class Initialized
INFO - 2024-10-10 17:07:25 --> Language Class Initialized
INFO - 2024-10-10 17:07:25 --> Language Class Initialized
INFO - 2024-10-10 17:07:25 --> Config Class Initialized
INFO - 2024-10-10 17:07:25 --> Loader Class Initialized
INFO - 2024-10-10 17:07:25 --> Helper loaded: url_helper
INFO - 2024-10-10 17:07:25 --> Helper loaded: file_helper
INFO - 2024-10-10 17:07:25 --> Helper loaded: form_helper
INFO - 2024-10-10 17:07:25 --> Helper loaded: my_helper
INFO - 2024-10-10 17:07:25 --> Database Driver Class Initialized
INFO - 2024-10-10 17:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 17:07:25 --> Controller Class Initialized
DEBUG - 2024-10-10 17:07:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 17:07:28 --> Final output sent to browser
DEBUG - 2024-10-10 17:07:28 --> Total execution time: 3.3184
INFO - 2024-10-10 17:07:52 --> Config Class Initialized
INFO - 2024-10-10 17:07:52 --> Hooks Class Initialized
DEBUG - 2024-10-10 17:07:52 --> UTF-8 Support Enabled
INFO - 2024-10-10 17:07:52 --> Utf8 Class Initialized
INFO - 2024-10-10 17:07:52 --> URI Class Initialized
INFO - 2024-10-10 17:07:52 --> Router Class Initialized
INFO - 2024-10-10 17:07:52 --> Output Class Initialized
INFO - 2024-10-10 17:07:52 --> Security Class Initialized
DEBUG - 2024-10-10 17:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 17:07:52 --> Input Class Initialized
INFO - 2024-10-10 17:07:52 --> Language Class Initialized
INFO - 2024-10-10 17:07:52 --> Language Class Initialized
INFO - 2024-10-10 17:07:52 --> Config Class Initialized
INFO - 2024-10-10 17:07:52 --> Loader Class Initialized
INFO - 2024-10-10 17:07:52 --> Helper loaded: url_helper
INFO - 2024-10-10 17:07:52 --> Helper loaded: file_helper
INFO - 2024-10-10 17:07:52 --> Helper loaded: form_helper
INFO - 2024-10-10 17:07:52 --> Helper loaded: my_helper
INFO - 2024-10-10 17:07:52 --> Database Driver Class Initialized
INFO - 2024-10-10 17:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 17:07:52 --> Controller Class Initialized
DEBUG - 2024-10-10 17:07:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-10 17:07:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 17:07:52 --> Final output sent to browser
DEBUG - 2024-10-10 17:07:52 --> Total execution time: 0.0761
INFO - 2024-10-10 17:07:57 --> Config Class Initialized
INFO - 2024-10-10 17:07:57 --> Hooks Class Initialized
DEBUG - 2024-10-10 17:07:57 --> UTF-8 Support Enabled
INFO - 2024-10-10 17:07:57 --> Utf8 Class Initialized
INFO - 2024-10-10 17:07:57 --> URI Class Initialized
INFO - 2024-10-10 17:07:57 --> Router Class Initialized
INFO - 2024-10-10 17:07:57 --> Output Class Initialized
INFO - 2024-10-10 17:07:57 --> Security Class Initialized
DEBUG - 2024-10-10 17:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 17:07:57 --> Input Class Initialized
INFO - 2024-10-10 17:07:57 --> Language Class Initialized
INFO - 2024-10-10 17:07:57 --> Language Class Initialized
INFO - 2024-10-10 17:07:57 --> Config Class Initialized
INFO - 2024-10-10 17:07:57 --> Loader Class Initialized
INFO - 2024-10-10 17:07:57 --> Helper loaded: url_helper
INFO - 2024-10-10 17:07:57 --> Helper loaded: file_helper
INFO - 2024-10-10 17:07:57 --> Helper loaded: form_helper
INFO - 2024-10-10 17:07:57 --> Helper loaded: my_helper
INFO - 2024-10-10 17:07:57 --> Database Driver Class Initialized
INFO - 2024-10-10 17:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 17:07:57 --> Controller Class Initialized
DEBUG - 2024-10-10 17:07:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 17:07:58 --> Config Class Initialized
INFO - 2024-10-10 17:07:58 --> Hooks Class Initialized
DEBUG - 2024-10-10 17:07:58 --> UTF-8 Support Enabled
INFO - 2024-10-10 17:07:58 --> Utf8 Class Initialized
INFO - 2024-10-10 17:07:58 --> URI Class Initialized
INFO - 2024-10-10 17:07:58 --> Router Class Initialized
INFO - 2024-10-10 17:07:58 --> Output Class Initialized
INFO - 2024-10-10 17:07:58 --> Security Class Initialized
DEBUG - 2024-10-10 17:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 17:07:58 --> Input Class Initialized
INFO - 2024-10-10 17:07:58 --> Language Class Initialized
INFO - 2024-10-10 17:07:58 --> Language Class Initialized
INFO - 2024-10-10 17:07:58 --> Config Class Initialized
INFO - 2024-10-10 17:07:58 --> Loader Class Initialized
INFO - 2024-10-10 17:07:58 --> Helper loaded: url_helper
INFO - 2024-10-10 17:07:58 --> Helper loaded: file_helper
INFO - 2024-10-10 17:07:58 --> Helper loaded: form_helper
INFO - 2024-10-10 17:07:58 --> Helper loaded: my_helper
INFO - 2024-10-10 17:07:58 --> Database Driver Class Initialized
INFO - 2024-10-10 17:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 17:07:58 --> Controller Class Initialized
DEBUG - 2024-10-10 17:07:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 17:08:08 --> Final output sent to browser
DEBUG - 2024-10-10 17:08:08 --> Total execution time: 11.7869
INFO - 2024-10-10 17:08:10 --> Final output sent to browser
DEBUG - 2024-10-10 17:08:10 --> Total execution time: 12.1432
INFO - 2024-10-10 17:08:36 --> Config Class Initialized
INFO - 2024-10-10 17:08:36 --> Hooks Class Initialized
DEBUG - 2024-10-10 17:08:36 --> UTF-8 Support Enabled
INFO - 2024-10-10 17:08:36 --> Utf8 Class Initialized
INFO - 2024-10-10 17:08:36 --> URI Class Initialized
INFO - 2024-10-10 17:08:36 --> Router Class Initialized
INFO - 2024-10-10 17:08:36 --> Output Class Initialized
INFO - 2024-10-10 17:08:36 --> Security Class Initialized
DEBUG - 2024-10-10 17:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 17:08:36 --> Input Class Initialized
INFO - 2024-10-10 17:08:36 --> Language Class Initialized
INFO - 2024-10-10 17:08:37 --> Language Class Initialized
INFO - 2024-10-10 17:08:37 --> Config Class Initialized
INFO - 2024-10-10 17:08:37 --> Loader Class Initialized
INFO - 2024-10-10 17:08:37 --> Helper loaded: url_helper
INFO - 2024-10-10 17:08:37 --> Helper loaded: file_helper
INFO - 2024-10-10 17:08:37 --> Helper loaded: form_helper
INFO - 2024-10-10 17:08:37 --> Helper loaded: my_helper
INFO - 2024-10-10 17:08:37 --> Database Driver Class Initialized
INFO - 2024-10-10 17:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 17:08:37 --> Controller Class Initialized
DEBUG - 2024-10-10 17:08:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 17:08:40 --> Final output sent to browser
DEBUG - 2024-10-10 17:08:40 --> Total execution time: 3.0449
INFO - 2024-10-10 17:09:15 --> Config Class Initialized
INFO - 2024-10-10 17:09:15 --> Hooks Class Initialized
DEBUG - 2024-10-10 17:09:15 --> UTF-8 Support Enabled
INFO - 2024-10-10 17:09:15 --> Utf8 Class Initialized
INFO - 2024-10-10 17:09:15 --> URI Class Initialized
INFO - 2024-10-10 17:09:15 --> Router Class Initialized
INFO - 2024-10-10 17:09:15 --> Output Class Initialized
INFO - 2024-10-10 17:09:15 --> Security Class Initialized
DEBUG - 2024-10-10 17:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 17:09:15 --> Input Class Initialized
INFO - 2024-10-10 17:09:15 --> Language Class Initialized
INFO - 2024-10-10 17:09:15 --> Language Class Initialized
INFO - 2024-10-10 17:09:15 --> Config Class Initialized
INFO - 2024-10-10 17:09:15 --> Loader Class Initialized
INFO - 2024-10-10 17:09:15 --> Helper loaded: url_helper
INFO - 2024-10-10 17:09:15 --> Helper loaded: file_helper
INFO - 2024-10-10 17:09:15 --> Helper loaded: form_helper
INFO - 2024-10-10 17:09:15 --> Helper loaded: my_helper
INFO - 2024-10-10 17:09:15 --> Database Driver Class Initialized
INFO - 2024-10-10 17:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 17:09:15 --> Controller Class Initialized
DEBUG - 2024-10-10 17:09:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 17:09:19 --> Final output sent to browser
DEBUG - 2024-10-10 17:09:19 --> Total execution time: 4.1744
INFO - 2024-10-10 17:09:36 --> Config Class Initialized
INFO - 2024-10-10 17:09:36 --> Hooks Class Initialized
DEBUG - 2024-10-10 17:09:36 --> UTF-8 Support Enabled
INFO - 2024-10-10 17:09:36 --> Utf8 Class Initialized
INFO - 2024-10-10 17:09:36 --> URI Class Initialized
INFO - 2024-10-10 17:09:36 --> Router Class Initialized
INFO - 2024-10-10 17:09:36 --> Output Class Initialized
INFO - 2024-10-10 17:09:36 --> Security Class Initialized
DEBUG - 2024-10-10 17:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 17:09:36 --> Input Class Initialized
INFO - 2024-10-10 17:09:36 --> Language Class Initialized
INFO - 2024-10-10 17:09:36 --> Language Class Initialized
INFO - 2024-10-10 17:09:36 --> Config Class Initialized
INFO - 2024-10-10 17:09:36 --> Loader Class Initialized
INFO - 2024-10-10 17:09:36 --> Helper loaded: url_helper
INFO - 2024-10-10 17:09:36 --> Helper loaded: file_helper
INFO - 2024-10-10 17:09:36 --> Helper loaded: form_helper
INFO - 2024-10-10 17:09:36 --> Helper loaded: my_helper
INFO - 2024-10-10 17:09:36 --> Database Driver Class Initialized
INFO - 2024-10-10 17:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 17:09:36 --> Controller Class Initialized
DEBUG - 2024-10-10 17:09:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 17:09:39 --> Final output sent to browser
DEBUG - 2024-10-10 17:09:39 --> Total execution time: 2.9285
INFO - 2024-10-10 17:09:56 --> Config Class Initialized
INFO - 2024-10-10 17:09:56 --> Hooks Class Initialized
DEBUG - 2024-10-10 17:09:56 --> UTF-8 Support Enabled
INFO - 2024-10-10 17:09:56 --> Utf8 Class Initialized
INFO - 2024-10-10 17:09:56 --> URI Class Initialized
INFO - 2024-10-10 17:09:56 --> Router Class Initialized
INFO - 2024-10-10 17:09:56 --> Output Class Initialized
INFO - 2024-10-10 17:09:56 --> Security Class Initialized
DEBUG - 2024-10-10 17:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 17:09:56 --> Input Class Initialized
INFO - 2024-10-10 17:09:56 --> Language Class Initialized
INFO - 2024-10-10 17:09:56 --> Language Class Initialized
INFO - 2024-10-10 17:09:56 --> Config Class Initialized
INFO - 2024-10-10 17:09:56 --> Loader Class Initialized
INFO - 2024-10-10 17:09:56 --> Helper loaded: url_helper
INFO - 2024-10-10 17:09:56 --> Helper loaded: file_helper
INFO - 2024-10-10 17:09:56 --> Helper loaded: form_helper
INFO - 2024-10-10 17:09:56 --> Helper loaded: my_helper
INFO - 2024-10-10 17:09:56 --> Database Driver Class Initialized
INFO - 2024-10-10 17:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 17:09:56 --> Controller Class Initialized
DEBUG - 2024-10-10 17:09:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 17:10:03 --> Final output sent to browser
DEBUG - 2024-10-10 17:10:03 --> Total execution time: 7.3186
INFO - 2024-10-10 17:10:14 --> Config Class Initialized
INFO - 2024-10-10 17:10:14 --> Hooks Class Initialized
DEBUG - 2024-10-10 17:10:14 --> UTF-8 Support Enabled
INFO - 2024-10-10 17:10:14 --> Utf8 Class Initialized
INFO - 2024-10-10 17:10:14 --> URI Class Initialized
INFO - 2024-10-10 17:10:14 --> Router Class Initialized
INFO - 2024-10-10 17:10:14 --> Output Class Initialized
INFO - 2024-10-10 17:10:14 --> Security Class Initialized
DEBUG - 2024-10-10 17:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 17:10:14 --> Input Class Initialized
INFO - 2024-10-10 17:10:14 --> Language Class Initialized
INFO - 2024-10-10 17:10:14 --> Language Class Initialized
INFO - 2024-10-10 17:10:14 --> Config Class Initialized
INFO - 2024-10-10 17:10:14 --> Loader Class Initialized
INFO - 2024-10-10 17:10:14 --> Helper loaded: url_helper
INFO - 2024-10-10 17:10:14 --> Helper loaded: file_helper
INFO - 2024-10-10 17:10:14 --> Helper loaded: form_helper
INFO - 2024-10-10 17:10:14 --> Helper loaded: my_helper
INFO - 2024-10-10 17:10:14 --> Database Driver Class Initialized
INFO - 2024-10-10 17:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 17:10:14 --> Controller Class Initialized
DEBUG - 2024-10-10 17:10:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 17:10:18 --> Final output sent to browser
DEBUG - 2024-10-10 17:10:18 --> Total execution time: 3.6920
INFO - 2024-10-10 17:10:28 --> Config Class Initialized
INFO - 2024-10-10 17:10:28 --> Hooks Class Initialized
DEBUG - 2024-10-10 17:10:28 --> UTF-8 Support Enabled
INFO - 2024-10-10 17:10:28 --> Utf8 Class Initialized
INFO - 2024-10-10 17:10:28 --> URI Class Initialized
INFO - 2024-10-10 17:10:28 --> Router Class Initialized
INFO - 2024-10-10 17:10:28 --> Output Class Initialized
INFO - 2024-10-10 17:10:28 --> Security Class Initialized
DEBUG - 2024-10-10 17:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 17:10:28 --> Input Class Initialized
INFO - 2024-10-10 17:10:28 --> Language Class Initialized
INFO - 2024-10-10 17:10:28 --> Language Class Initialized
INFO - 2024-10-10 17:10:28 --> Config Class Initialized
INFO - 2024-10-10 17:10:28 --> Loader Class Initialized
INFO - 2024-10-10 17:10:28 --> Helper loaded: url_helper
INFO - 2024-10-10 17:10:28 --> Helper loaded: file_helper
INFO - 2024-10-10 17:10:28 --> Helper loaded: form_helper
INFO - 2024-10-10 17:10:28 --> Helper loaded: my_helper
INFO - 2024-10-10 17:10:28 --> Database Driver Class Initialized
INFO - 2024-10-10 17:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 17:10:28 --> Controller Class Initialized
DEBUG - 2024-10-10 17:10:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 17:10:31 --> Final output sent to browser
DEBUG - 2024-10-10 17:10:31 --> Total execution time: 3.2120
INFO - 2024-10-10 17:11:16 --> Config Class Initialized
INFO - 2024-10-10 17:11:16 --> Hooks Class Initialized
DEBUG - 2024-10-10 17:11:16 --> UTF-8 Support Enabled
INFO - 2024-10-10 17:11:16 --> Utf8 Class Initialized
INFO - 2024-10-10 17:11:16 --> URI Class Initialized
INFO - 2024-10-10 17:11:16 --> Router Class Initialized
INFO - 2024-10-10 17:11:16 --> Output Class Initialized
INFO - 2024-10-10 17:11:16 --> Security Class Initialized
DEBUG - 2024-10-10 17:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 17:11:16 --> Input Class Initialized
INFO - 2024-10-10 17:11:16 --> Language Class Initialized
INFO - 2024-10-10 17:11:16 --> Language Class Initialized
INFO - 2024-10-10 17:11:16 --> Config Class Initialized
INFO - 2024-10-10 17:11:16 --> Loader Class Initialized
INFO - 2024-10-10 17:11:16 --> Helper loaded: url_helper
INFO - 2024-10-10 17:11:16 --> Helper loaded: file_helper
INFO - 2024-10-10 17:11:16 --> Helper loaded: form_helper
INFO - 2024-10-10 17:11:16 --> Helper loaded: my_helper
INFO - 2024-10-10 17:11:16 --> Database Driver Class Initialized
INFO - 2024-10-10 17:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 17:11:16 --> Controller Class Initialized
DEBUG - 2024-10-10 17:11:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 17:11:19 --> Final output sent to browser
DEBUG - 2024-10-10 17:11:19 --> Total execution time: 3.1385
INFO - 2024-10-10 17:11:35 --> Config Class Initialized
INFO - 2024-10-10 17:11:35 --> Hooks Class Initialized
DEBUG - 2024-10-10 17:11:35 --> UTF-8 Support Enabled
INFO - 2024-10-10 17:11:35 --> Utf8 Class Initialized
INFO - 2024-10-10 17:11:35 --> URI Class Initialized
INFO - 2024-10-10 17:11:35 --> Router Class Initialized
INFO - 2024-10-10 17:11:35 --> Output Class Initialized
INFO - 2024-10-10 17:11:35 --> Security Class Initialized
DEBUG - 2024-10-10 17:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 17:11:35 --> Input Class Initialized
INFO - 2024-10-10 17:11:35 --> Language Class Initialized
INFO - 2024-10-10 17:11:35 --> Language Class Initialized
INFO - 2024-10-10 17:11:35 --> Config Class Initialized
INFO - 2024-10-10 17:11:35 --> Loader Class Initialized
INFO - 2024-10-10 17:11:35 --> Helper loaded: url_helper
INFO - 2024-10-10 17:11:35 --> Helper loaded: file_helper
INFO - 2024-10-10 17:11:35 --> Helper loaded: form_helper
INFO - 2024-10-10 17:11:35 --> Helper loaded: my_helper
INFO - 2024-10-10 17:11:35 --> Database Driver Class Initialized
INFO - 2024-10-10 17:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 17:11:35 --> Controller Class Initialized
DEBUG - 2024-10-10 17:11:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 17:11:38 --> Final output sent to browser
DEBUG - 2024-10-10 17:11:38 --> Total execution time: 3.3057
INFO - 2024-10-10 17:11:58 --> Config Class Initialized
INFO - 2024-10-10 17:11:58 --> Hooks Class Initialized
DEBUG - 2024-10-10 17:11:58 --> UTF-8 Support Enabled
INFO - 2024-10-10 17:11:58 --> Utf8 Class Initialized
INFO - 2024-10-10 17:11:58 --> URI Class Initialized
INFO - 2024-10-10 17:11:58 --> Router Class Initialized
INFO - 2024-10-10 17:11:58 --> Output Class Initialized
INFO - 2024-10-10 17:11:58 --> Security Class Initialized
DEBUG - 2024-10-10 17:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 17:11:58 --> Input Class Initialized
INFO - 2024-10-10 17:11:58 --> Language Class Initialized
INFO - 2024-10-10 17:11:58 --> Language Class Initialized
INFO - 2024-10-10 17:11:58 --> Config Class Initialized
INFO - 2024-10-10 17:11:58 --> Loader Class Initialized
INFO - 2024-10-10 17:11:58 --> Helper loaded: url_helper
INFO - 2024-10-10 17:11:58 --> Helper loaded: file_helper
INFO - 2024-10-10 17:11:58 --> Helper loaded: form_helper
INFO - 2024-10-10 17:11:58 --> Helper loaded: my_helper
INFO - 2024-10-10 17:11:58 --> Database Driver Class Initialized
INFO - 2024-10-10 17:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 17:11:58 --> Controller Class Initialized
DEBUG - 2024-10-10 17:11:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 17:12:04 --> Final output sent to browser
DEBUG - 2024-10-10 17:12:04 --> Total execution time: 6.0552
INFO - 2024-10-10 17:12:34 --> Config Class Initialized
INFO - 2024-10-10 17:12:34 --> Hooks Class Initialized
DEBUG - 2024-10-10 17:12:34 --> UTF-8 Support Enabled
INFO - 2024-10-10 17:12:34 --> Utf8 Class Initialized
INFO - 2024-10-10 17:12:34 --> URI Class Initialized
INFO - 2024-10-10 17:12:34 --> Router Class Initialized
INFO - 2024-10-10 17:12:34 --> Output Class Initialized
INFO - 2024-10-10 17:12:34 --> Security Class Initialized
DEBUG - 2024-10-10 17:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 17:12:34 --> Input Class Initialized
INFO - 2024-10-10 17:12:34 --> Language Class Initialized
INFO - 2024-10-10 17:12:34 --> Language Class Initialized
INFO - 2024-10-10 17:12:34 --> Config Class Initialized
INFO - 2024-10-10 17:12:34 --> Loader Class Initialized
INFO - 2024-10-10 17:12:34 --> Helper loaded: url_helper
INFO - 2024-10-10 17:12:34 --> Helper loaded: file_helper
INFO - 2024-10-10 17:12:34 --> Helper loaded: form_helper
INFO - 2024-10-10 17:12:34 --> Helper loaded: my_helper
INFO - 2024-10-10 17:12:34 --> Database Driver Class Initialized
INFO - 2024-10-10 17:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 17:12:34 --> Controller Class Initialized
DEBUG - 2024-10-10 17:12:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 17:12:37 --> Final output sent to browser
DEBUG - 2024-10-10 17:12:37 --> Total execution time: 3.3062
INFO - 2024-10-10 17:13:02 --> Config Class Initialized
INFO - 2024-10-10 17:13:02 --> Hooks Class Initialized
DEBUG - 2024-10-10 17:13:02 --> UTF-8 Support Enabled
INFO - 2024-10-10 17:13:02 --> Utf8 Class Initialized
INFO - 2024-10-10 17:13:02 --> URI Class Initialized
INFO - 2024-10-10 17:13:02 --> Router Class Initialized
INFO - 2024-10-10 17:13:02 --> Output Class Initialized
INFO - 2024-10-10 17:13:02 --> Security Class Initialized
DEBUG - 2024-10-10 17:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 17:13:02 --> Input Class Initialized
INFO - 2024-10-10 17:13:02 --> Language Class Initialized
INFO - 2024-10-10 17:13:02 --> Language Class Initialized
INFO - 2024-10-10 17:13:02 --> Config Class Initialized
INFO - 2024-10-10 17:13:02 --> Loader Class Initialized
INFO - 2024-10-10 17:13:02 --> Helper loaded: url_helper
INFO - 2024-10-10 17:13:02 --> Helper loaded: file_helper
INFO - 2024-10-10 17:13:02 --> Helper loaded: form_helper
INFO - 2024-10-10 17:13:02 --> Helper loaded: my_helper
INFO - 2024-10-10 17:13:02 --> Database Driver Class Initialized
INFO - 2024-10-10 17:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 17:13:02 --> Controller Class Initialized
DEBUG - 2024-10-10 17:13:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 17:13:05 --> Final output sent to browser
DEBUG - 2024-10-10 17:13:05 --> Total execution time: 3.2643
INFO - 2024-10-10 17:13:13 --> Config Class Initialized
INFO - 2024-10-10 17:13:13 --> Hooks Class Initialized
DEBUG - 2024-10-10 17:13:13 --> UTF-8 Support Enabled
INFO - 2024-10-10 17:13:13 --> Utf8 Class Initialized
INFO - 2024-10-10 17:13:13 --> URI Class Initialized
INFO - 2024-10-10 17:13:13 --> Router Class Initialized
INFO - 2024-10-10 17:13:13 --> Output Class Initialized
INFO - 2024-10-10 17:13:13 --> Security Class Initialized
DEBUG - 2024-10-10 17:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 17:13:13 --> Input Class Initialized
INFO - 2024-10-10 17:13:13 --> Language Class Initialized
INFO - 2024-10-10 17:13:13 --> Language Class Initialized
INFO - 2024-10-10 17:13:13 --> Config Class Initialized
INFO - 2024-10-10 17:13:13 --> Loader Class Initialized
INFO - 2024-10-10 17:13:13 --> Helper loaded: url_helper
INFO - 2024-10-10 17:13:13 --> Helper loaded: file_helper
INFO - 2024-10-10 17:13:13 --> Helper loaded: form_helper
INFO - 2024-10-10 17:13:13 --> Helper loaded: my_helper
INFO - 2024-10-10 17:13:13 --> Database Driver Class Initialized
INFO - 2024-10-10 17:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 17:13:13 --> Controller Class Initialized
DEBUG - 2024-10-10 17:13:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 17:13:16 --> Final output sent to browser
DEBUG - 2024-10-10 17:13:16 --> Total execution time: 3.1425
INFO - 2024-10-10 20:07:47 --> Config Class Initialized
INFO - 2024-10-10 20:07:47 --> Hooks Class Initialized
DEBUG - 2024-10-10 20:07:47 --> UTF-8 Support Enabled
INFO - 2024-10-10 20:07:47 --> Utf8 Class Initialized
INFO - 2024-10-10 20:07:47 --> URI Class Initialized
INFO - 2024-10-10 20:07:47 --> Router Class Initialized
INFO - 2024-10-10 20:07:47 --> Output Class Initialized
INFO - 2024-10-10 20:07:47 --> Security Class Initialized
DEBUG - 2024-10-10 20:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 20:07:47 --> Input Class Initialized
INFO - 2024-10-10 20:07:47 --> Language Class Initialized
INFO - 2024-10-10 20:07:47 --> Language Class Initialized
INFO - 2024-10-10 20:07:47 --> Config Class Initialized
INFO - 2024-10-10 20:07:47 --> Loader Class Initialized
INFO - 2024-10-10 20:07:47 --> Helper loaded: url_helper
INFO - 2024-10-10 20:07:47 --> Helper loaded: file_helper
INFO - 2024-10-10 20:07:47 --> Helper loaded: form_helper
INFO - 2024-10-10 20:07:47 --> Helper loaded: my_helper
INFO - 2024-10-10 20:07:47 --> Database Driver Class Initialized
INFO - 2024-10-10 20:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 20:07:47 --> Controller Class Initialized
ERROR - 2024-10-10 20:07:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2393
DEBUG - 2024-10-10 20:07:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-10 20:07:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 20:07:47 --> Final output sent to browser
DEBUG - 2024-10-10 20:07:47 --> Total execution time: 0.0680
INFO - 2024-10-10 20:16:09 --> Config Class Initialized
INFO - 2024-10-10 20:16:09 --> Hooks Class Initialized
DEBUG - 2024-10-10 20:16:09 --> UTF-8 Support Enabled
INFO - 2024-10-10 20:16:09 --> Utf8 Class Initialized
INFO - 2024-10-10 20:16:09 --> URI Class Initialized
INFO - 2024-10-10 20:16:09 --> Router Class Initialized
INFO - 2024-10-10 20:16:09 --> Output Class Initialized
INFO - 2024-10-10 20:16:09 --> Security Class Initialized
DEBUG - 2024-10-10 20:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 20:16:09 --> Input Class Initialized
INFO - 2024-10-10 20:16:09 --> Language Class Initialized
INFO - 2024-10-10 20:16:09 --> Language Class Initialized
INFO - 2024-10-10 20:16:09 --> Config Class Initialized
INFO - 2024-10-10 20:16:09 --> Loader Class Initialized
INFO - 2024-10-10 20:16:09 --> Helper loaded: url_helper
INFO - 2024-10-10 20:16:09 --> Helper loaded: file_helper
INFO - 2024-10-10 20:16:09 --> Helper loaded: form_helper
INFO - 2024-10-10 20:16:09 --> Helper loaded: my_helper
INFO - 2024-10-10 20:16:09 --> Database Driver Class Initialized
INFO - 2024-10-10 20:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 20:16:09 --> Controller Class Initialized
DEBUG - 2024-10-10 20:16:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-10 20:16:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 20:16:09 --> Final output sent to browser
DEBUG - 2024-10-10 20:16:09 --> Total execution time: 0.0410
INFO - 2024-10-10 20:16:22 --> Config Class Initialized
INFO - 2024-10-10 20:16:22 --> Hooks Class Initialized
DEBUG - 2024-10-10 20:16:22 --> UTF-8 Support Enabled
INFO - 2024-10-10 20:16:22 --> Utf8 Class Initialized
INFO - 2024-10-10 20:16:22 --> URI Class Initialized
INFO - 2024-10-10 20:16:22 --> Router Class Initialized
INFO - 2024-10-10 20:16:22 --> Output Class Initialized
INFO - 2024-10-10 20:16:22 --> Security Class Initialized
DEBUG - 2024-10-10 20:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 20:16:22 --> Input Class Initialized
INFO - 2024-10-10 20:16:22 --> Language Class Initialized
INFO - 2024-10-10 20:16:22 --> Language Class Initialized
INFO - 2024-10-10 20:16:22 --> Config Class Initialized
INFO - 2024-10-10 20:16:22 --> Loader Class Initialized
INFO - 2024-10-10 20:16:22 --> Helper loaded: url_helper
INFO - 2024-10-10 20:16:22 --> Helper loaded: file_helper
INFO - 2024-10-10 20:16:22 --> Helper loaded: form_helper
INFO - 2024-10-10 20:16:22 --> Helper loaded: my_helper
INFO - 2024-10-10 20:16:22 --> Database Driver Class Initialized
INFO - 2024-10-10 20:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 20:16:22 --> Controller Class Initialized
INFO - 2024-10-10 20:16:22 --> Helper loaded: cookie_helper
INFO - 2024-10-10 20:16:22 --> Final output sent to browser
DEBUG - 2024-10-10 20:16:22 --> Total execution time: 0.0603
INFO - 2024-10-10 20:16:22 --> Config Class Initialized
INFO - 2024-10-10 20:16:22 --> Hooks Class Initialized
DEBUG - 2024-10-10 20:16:22 --> UTF-8 Support Enabled
INFO - 2024-10-10 20:16:22 --> Utf8 Class Initialized
INFO - 2024-10-10 20:16:22 --> URI Class Initialized
INFO - 2024-10-10 20:16:22 --> Router Class Initialized
INFO - 2024-10-10 20:16:22 --> Output Class Initialized
INFO - 2024-10-10 20:16:22 --> Security Class Initialized
DEBUG - 2024-10-10 20:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 20:16:22 --> Input Class Initialized
INFO - 2024-10-10 20:16:22 --> Language Class Initialized
INFO - 2024-10-10 20:16:22 --> Language Class Initialized
INFO - 2024-10-10 20:16:22 --> Config Class Initialized
INFO - 2024-10-10 20:16:22 --> Loader Class Initialized
INFO - 2024-10-10 20:16:22 --> Helper loaded: url_helper
INFO - 2024-10-10 20:16:22 --> Helper loaded: file_helper
INFO - 2024-10-10 20:16:22 --> Helper loaded: form_helper
INFO - 2024-10-10 20:16:22 --> Helper loaded: my_helper
INFO - 2024-10-10 20:16:22 --> Database Driver Class Initialized
INFO - 2024-10-10 20:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 20:16:22 --> Controller Class Initialized
DEBUG - 2024-10-10 20:16:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-10 20:16:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 20:16:22 --> Final output sent to browser
DEBUG - 2024-10-10 20:16:22 --> Total execution time: 0.0896
INFO - 2024-10-10 20:16:34 --> Config Class Initialized
INFO - 2024-10-10 20:16:34 --> Hooks Class Initialized
DEBUG - 2024-10-10 20:16:34 --> UTF-8 Support Enabled
INFO - 2024-10-10 20:16:34 --> Utf8 Class Initialized
INFO - 2024-10-10 20:16:34 --> URI Class Initialized
INFO - 2024-10-10 20:16:34 --> Router Class Initialized
INFO - 2024-10-10 20:16:34 --> Output Class Initialized
INFO - 2024-10-10 20:16:34 --> Security Class Initialized
DEBUG - 2024-10-10 20:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 20:16:34 --> Input Class Initialized
INFO - 2024-10-10 20:16:34 --> Language Class Initialized
INFO - 2024-10-10 20:16:34 --> Language Class Initialized
INFO - 2024-10-10 20:16:34 --> Config Class Initialized
INFO - 2024-10-10 20:16:34 --> Loader Class Initialized
INFO - 2024-10-10 20:16:34 --> Helper loaded: url_helper
INFO - 2024-10-10 20:16:34 --> Helper loaded: file_helper
INFO - 2024-10-10 20:16:34 --> Helper loaded: form_helper
INFO - 2024-10-10 20:16:34 --> Helper loaded: my_helper
INFO - 2024-10-10 20:16:34 --> Database Driver Class Initialized
INFO - 2024-10-10 20:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 20:16:34 --> Controller Class Initialized
DEBUG - 2024-10-10 20:16:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-10 20:16:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 20:16:34 --> Final output sent to browser
DEBUG - 2024-10-10 20:16:34 --> Total execution time: 0.0385
INFO - 2024-10-10 20:16:46 --> Config Class Initialized
INFO - 2024-10-10 20:16:46 --> Hooks Class Initialized
DEBUG - 2024-10-10 20:16:46 --> UTF-8 Support Enabled
INFO - 2024-10-10 20:16:46 --> Utf8 Class Initialized
INFO - 2024-10-10 20:16:46 --> URI Class Initialized
INFO - 2024-10-10 20:16:46 --> Router Class Initialized
INFO - 2024-10-10 20:16:46 --> Output Class Initialized
INFO - 2024-10-10 20:16:46 --> Security Class Initialized
DEBUG - 2024-10-10 20:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 20:16:46 --> Input Class Initialized
INFO - 2024-10-10 20:16:46 --> Language Class Initialized
INFO - 2024-10-10 20:16:46 --> Language Class Initialized
INFO - 2024-10-10 20:16:46 --> Config Class Initialized
INFO - 2024-10-10 20:16:46 --> Loader Class Initialized
INFO - 2024-10-10 20:16:46 --> Helper loaded: url_helper
INFO - 2024-10-10 20:16:46 --> Helper loaded: file_helper
INFO - 2024-10-10 20:16:46 --> Helper loaded: form_helper
INFO - 2024-10-10 20:16:46 --> Helper loaded: my_helper
INFO - 2024-10-10 20:16:46 --> Database Driver Class Initialized
INFO - 2024-10-10 20:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 20:16:46 --> Controller Class Initialized
DEBUG - 2024-10-10 20:16:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-10 20:16:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 20:16:46 --> Final output sent to browser
DEBUG - 2024-10-10 20:16:46 --> Total execution time: 0.0421
INFO - 2024-10-10 20:16:51 --> Config Class Initialized
INFO - 2024-10-10 20:16:51 --> Hooks Class Initialized
DEBUG - 2024-10-10 20:16:51 --> UTF-8 Support Enabled
INFO - 2024-10-10 20:16:51 --> Utf8 Class Initialized
INFO - 2024-10-10 20:16:51 --> URI Class Initialized
INFO - 2024-10-10 20:16:51 --> Router Class Initialized
INFO - 2024-10-10 20:16:51 --> Output Class Initialized
INFO - 2024-10-10 20:16:51 --> Security Class Initialized
DEBUG - 2024-10-10 20:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 20:16:51 --> Input Class Initialized
INFO - 2024-10-10 20:16:51 --> Language Class Initialized
INFO - 2024-10-10 20:16:51 --> Language Class Initialized
INFO - 2024-10-10 20:16:51 --> Config Class Initialized
INFO - 2024-10-10 20:16:51 --> Loader Class Initialized
INFO - 2024-10-10 20:16:51 --> Helper loaded: url_helper
INFO - 2024-10-10 20:16:51 --> Helper loaded: file_helper
INFO - 2024-10-10 20:16:51 --> Helper loaded: form_helper
INFO - 2024-10-10 20:16:51 --> Helper loaded: my_helper
INFO - 2024-10-10 20:16:51 --> Database Driver Class Initialized
INFO - 2024-10-10 20:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 20:16:51 --> Controller Class Initialized
DEBUG - 2024-10-10 20:16:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 20:16:55 --> Final output sent to browser
DEBUG - 2024-10-10 20:16:55 --> Total execution time: 3.7936
INFO - 2024-10-10 20:17:41 --> Config Class Initialized
INFO - 2024-10-10 20:17:41 --> Hooks Class Initialized
DEBUG - 2024-10-10 20:17:41 --> UTF-8 Support Enabled
INFO - 2024-10-10 20:17:41 --> Utf8 Class Initialized
INFO - 2024-10-10 20:17:41 --> URI Class Initialized
INFO - 2024-10-10 20:17:41 --> Router Class Initialized
INFO - 2024-10-10 20:17:41 --> Output Class Initialized
INFO - 2024-10-10 20:17:41 --> Security Class Initialized
DEBUG - 2024-10-10 20:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 20:17:41 --> Input Class Initialized
INFO - 2024-10-10 20:17:41 --> Language Class Initialized
INFO - 2024-10-10 20:17:41 --> Language Class Initialized
INFO - 2024-10-10 20:17:41 --> Config Class Initialized
INFO - 2024-10-10 20:17:41 --> Loader Class Initialized
INFO - 2024-10-10 20:17:41 --> Helper loaded: url_helper
INFO - 2024-10-10 20:17:41 --> Helper loaded: file_helper
INFO - 2024-10-10 20:17:41 --> Helper loaded: form_helper
INFO - 2024-10-10 20:17:41 --> Helper loaded: my_helper
INFO - 2024-10-10 20:17:41 --> Database Driver Class Initialized
INFO - 2024-10-10 20:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 20:17:41 --> Controller Class Initialized
DEBUG - 2024-10-10 20:17:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 20:17:44 --> Final output sent to browser
DEBUG - 2024-10-10 20:17:44 --> Total execution time: 2.9539
INFO - 2024-10-10 20:21:10 --> Config Class Initialized
INFO - 2024-10-10 20:21:10 --> Hooks Class Initialized
DEBUG - 2024-10-10 20:21:10 --> UTF-8 Support Enabled
INFO - 2024-10-10 20:21:10 --> Utf8 Class Initialized
INFO - 2024-10-10 20:21:10 --> URI Class Initialized
INFO - 2024-10-10 20:21:10 --> Router Class Initialized
INFO - 2024-10-10 20:21:10 --> Output Class Initialized
INFO - 2024-10-10 20:21:10 --> Security Class Initialized
DEBUG - 2024-10-10 20:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 20:21:10 --> Input Class Initialized
INFO - 2024-10-10 20:21:10 --> Language Class Initialized
INFO - 2024-10-10 20:21:10 --> Language Class Initialized
INFO - 2024-10-10 20:21:10 --> Config Class Initialized
INFO - 2024-10-10 20:21:10 --> Loader Class Initialized
INFO - 2024-10-10 20:21:10 --> Helper loaded: url_helper
INFO - 2024-10-10 20:21:10 --> Helper loaded: file_helper
INFO - 2024-10-10 20:21:10 --> Helper loaded: form_helper
INFO - 2024-10-10 20:21:10 --> Helper loaded: my_helper
INFO - 2024-10-10 20:21:10 --> Database Driver Class Initialized
INFO - 2024-10-10 20:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 20:21:10 --> Controller Class Initialized
DEBUG - 2024-10-10 20:21:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 20:21:13 --> Final output sent to browser
DEBUG - 2024-10-10 20:21:13 --> Total execution time: 3.1515
INFO - 2024-10-10 20:22:46 --> Config Class Initialized
INFO - 2024-10-10 20:22:46 --> Hooks Class Initialized
DEBUG - 2024-10-10 20:22:46 --> UTF-8 Support Enabled
INFO - 2024-10-10 20:22:46 --> Utf8 Class Initialized
INFO - 2024-10-10 20:22:46 --> URI Class Initialized
INFO - 2024-10-10 20:22:46 --> Router Class Initialized
INFO - 2024-10-10 20:22:46 --> Output Class Initialized
INFO - 2024-10-10 20:22:46 --> Security Class Initialized
DEBUG - 2024-10-10 20:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 20:22:46 --> Input Class Initialized
INFO - 2024-10-10 20:22:46 --> Language Class Initialized
INFO - 2024-10-10 20:22:46 --> Language Class Initialized
INFO - 2024-10-10 20:22:46 --> Config Class Initialized
INFO - 2024-10-10 20:22:46 --> Loader Class Initialized
INFO - 2024-10-10 20:22:46 --> Helper loaded: url_helper
INFO - 2024-10-10 20:22:46 --> Helper loaded: file_helper
INFO - 2024-10-10 20:22:46 --> Helper loaded: form_helper
INFO - 2024-10-10 20:22:46 --> Helper loaded: my_helper
INFO - 2024-10-10 20:22:46 --> Database Driver Class Initialized
INFO - 2024-10-10 20:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 20:22:46 --> Controller Class Initialized
DEBUG - 2024-10-10 20:22:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 20:22:49 --> Final output sent to browser
DEBUG - 2024-10-10 20:22:49 --> Total execution time: 3.3131
INFO - 2024-10-10 20:23:52 --> Config Class Initialized
INFO - 2024-10-10 20:23:52 --> Hooks Class Initialized
DEBUG - 2024-10-10 20:23:52 --> UTF-8 Support Enabled
INFO - 2024-10-10 20:23:52 --> Utf8 Class Initialized
INFO - 2024-10-10 20:23:52 --> URI Class Initialized
INFO - 2024-10-10 20:23:52 --> Router Class Initialized
INFO - 2024-10-10 20:23:52 --> Output Class Initialized
INFO - 2024-10-10 20:23:52 --> Security Class Initialized
DEBUG - 2024-10-10 20:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 20:23:52 --> Input Class Initialized
INFO - 2024-10-10 20:23:52 --> Language Class Initialized
INFO - 2024-10-10 20:23:52 --> Language Class Initialized
INFO - 2024-10-10 20:23:52 --> Config Class Initialized
INFO - 2024-10-10 20:23:52 --> Loader Class Initialized
INFO - 2024-10-10 20:23:52 --> Helper loaded: url_helper
INFO - 2024-10-10 20:23:52 --> Helper loaded: file_helper
INFO - 2024-10-10 20:23:52 --> Helper loaded: form_helper
INFO - 2024-10-10 20:23:52 --> Helper loaded: my_helper
INFO - 2024-10-10 20:23:52 --> Database Driver Class Initialized
INFO - 2024-10-10 20:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 20:23:52 --> Controller Class Initialized
DEBUG - 2024-10-10 20:23:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 20:23:55 --> Final output sent to browser
DEBUG - 2024-10-10 20:23:55 --> Total execution time: 3.1601
INFO - 2024-10-10 20:25:04 --> Config Class Initialized
INFO - 2024-10-10 20:25:04 --> Hooks Class Initialized
DEBUG - 2024-10-10 20:25:04 --> UTF-8 Support Enabled
INFO - 2024-10-10 20:25:04 --> Utf8 Class Initialized
INFO - 2024-10-10 20:25:04 --> URI Class Initialized
INFO - 2024-10-10 20:25:04 --> Router Class Initialized
INFO - 2024-10-10 20:25:04 --> Output Class Initialized
INFO - 2024-10-10 20:25:04 --> Security Class Initialized
DEBUG - 2024-10-10 20:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 20:25:04 --> Input Class Initialized
INFO - 2024-10-10 20:25:04 --> Language Class Initialized
INFO - 2024-10-10 20:25:04 --> Language Class Initialized
INFO - 2024-10-10 20:25:04 --> Config Class Initialized
INFO - 2024-10-10 20:25:04 --> Loader Class Initialized
INFO - 2024-10-10 20:25:04 --> Helper loaded: url_helper
INFO - 2024-10-10 20:25:04 --> Helper loaded: file_helper
INFO - 2024-10-10 20:25:04 --> Helper loaded: form_helper
INFO - 2024-10-10 20:25:04 --> Helper loaded: my_helper
INFO - 2024-10-10 20:25:04 --> Database Driver Class Initialized
INFO - 2024-10-10 20:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 20:25:04 --> Controller Class Initialized
DEBUG - 2024-10-10 20:25:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 20:25:08 --> Final output sent to browser
DEBUG - 2024-10-10 20:25:08 --> Total execution time: 3.7449
INFO - 2024-10-10 20:26:23 --> Config Class Initialized
INFO - 2024-10-10 20:26:23 --> Hooks Class Initialized
DEBUG - 2024-10-10 20:26:23 --> UTF-8 Support Enabled
INFO - 2024-10-10 20:26:23 --> Utf8 Class Initialized
INFO - 2024-10-10 20:26:23 --> URI Class Initialized
INFO - 2024-10-10 20:26:23 --> Router Class Initialized
INFO - 2024-10-10 20:26:23 --> Output Class Initialized
INFO - 2024-10-10 20:26:23 --> Security Class Initialized
DEBUG - 2024-10-10 20:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 20:26:23 --> Input Class Initialized
INFO - 2024-10-10 20:26:23 --> Language Class Initialized
INFO - 2024-10-10 20:26:23 --> Language Class Initialized
INFO - 2024-10-10 20:26:23 --> Config Class Initialized
INFO - 2024-10-10 20:26:23 --> Loader Class Initialized
INFO - 2024-10-10 20:26:23 --> Helper loaded: url_helper
INFO - 2024-10-10 20:26:23 --> Helper loaded: file_helper
INFO - 2024-10-10 20:26:23 --> Helper loaded: form_helper
INFO - 2024-10-10 20:26:23 --> Helper loaded: my_helper
INFO - 2024-10-10 20:26:23 --> Database Driver Class Initialized
INFO - 2024-10-10 20:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 20:26:23 --> Controller Class Initialized
DEBUG - 2024-10-10 20:26:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 20:26:26 --> Final output sent to browser
DEBUG - 2024-10-10 20:26:26 --> Total execution time: 3.2615
INFO - 2024-10-10 22:11:28 --> Config Class Initialized
INFO - 2024-10-10 22:11:28 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:11:28 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:11:28 --> Utf8 Class Initialized
INFO - 2024-10-10 22:11:28 --> URI Class Initialized
INFO - 2024-10-10 22:11:28 --> Router Class Initialized
INFO - 2024-10-10 22:11:28 --> Output Class Initialized
INFO - 2024-10-10 22:11:28 --> Security Class Initialized
DEBUG - 2024-10-10 22:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:11:28 --> Input Class Initialized
INFO - 2024-10-10 22:11:28 --> Language Class Initialized
INFO - 2024-10-10 22:11:28 --> Language Class Initialized
INFO - 2024-10-10 22:11:28 --> Config Class Initialized
INFO - 2024-10-10 22:11:28 --> Loader Class Initialized
INFO - 2024-10-10 22:11:28 --> Helper loaded: url_helper
INFO - 2024-10-10 22:11:28 --> Helper loaded: file_helper
INFO - 2024-10-10 22:11:28 --> Helper loaded: form_helper
INFO - 2024-10-10 22:11:28 --> Helper loaded: my_helper
INFO - 2024-10-10 22:11:28 --> Database Driver Class Initialized
INFO - 2024-10-10 22:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:11:28 --> Controller Class Initialized
INFO - 2024-10-10 22:11:28 --> Config Class Initialized
INFO - 2024-10-10 22:11:28 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:11:28 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:11:28 --> Utf8 Class Initialized
INFO - 2024-10-10 22:11:28 --> URI Class Initialized
INFO - 2024-10-10 22:11:28 --> Router Class Initialized
INFO - 2024-10-10 22:11:28 --> Output Class Initialized
INFO - 2024-10-10 22:11:28 --> Security Class Initialized
DEBUG - 2024-10-10 22:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:11:28 --> Input Class Initialized
INFO - 2024-10-10 22:11:28 --> Language Class Initialized
INFO - 2024-10-10 22:11:28 --> Language Class Initialized
INFO - 2024-10-10 22:11:28 --> Config Class Initialized
INFO - 2024-10-10 22:11:28 --> Loader Class Initialized
INFO - 2024-10-10 22:11:28 --> Helper loaded: url_helper
INFO - 2024-10-10 22:11:28 --> Helper loaded: file_helper
INFO - 2024-10-10 22:11:28 --> Helper loaded: form_helper
INFO - 2024-10-10 22:11:28 --> Helper loaded: my_helper
INFO - 2024-10-10 22:11:28 --> Database Driver Class Initialized
INFO - 2024-10-10 22:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:11:29 --> Controller Class Initialized
DEBUG - 2024-10-10 22:11:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-10 22:11:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:11:29 --> Final output sent to browser
DEBUG - 2024-10-10 22:11:29 --> Total execution time: 0.0372
INFO - 2024-10-10 22:11:37 --> Config Class Initialized
INFO - 2024-10-10 22:11:37 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:11:37 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:11:37 --> Utf8 Class Initialized
INFO - 2024-10-10 22:11:37 --> URI Class Initialized
INFO - 2024-10-10 22:11:37 --> Router Class Initialized
INFO - 2024-10-10 22:11:37 --> Output Class Initialized
INFO - 2024-10-10 22:11:37 --> Security Class Initialized
DEBUG - 2024-10-10 22:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:11:38 --> Input Class Initialized
INFO - 2024-10-10 22:11:38 --> Language Class Initialized
INFO - 2024-10-10 22:11:38 --> Language Class Initialized
INFO - 2024-10-10 22:11:38 --> Config Class Initialized
INFO - 2024-10-10 22:11:38 --> Loader Class Initialized
INFO - 2024-10-10 22:11:38 --> Helper loaded: url_helper
INFO - 2024-10-10 22:11:38 --> Helper loaded: file_helper
INFO - 2024-10-10 22:11:38 --> Helper loaded: form_helper
INFO - 2024-10-10 22:11:38 --> Helper loaded: my_helper
INFO - 2024-10-10 22:11:38 --> Database Driver Class Initialized
INFO - 2024-10-10 22:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:11:38 --> Controller Class Initialized
INFO - 2024-10-10 22:11:38 --> Helper loaded: cookie_helper
INFO - 2024-10-10 22:11:38 --> Final output sent to browser
DEBUG - 2024-10-10 22:11:38 --> Total execution time: 0.0356
INFO - 2024-10-10 22:11:38 --> Config Class Initialized
INFO - 2024-10-10 22:11:38 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:11:38 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:11:38 --> Utf8 Class Initialized
INFO - 2024-10-10 22:11:38 --> URI Class Initialized
INFO - 2024-10-10 22:11:38 --> Router Class Initialized
INFO - 2024-10-10 22:11:38 --> Output Class Initialized
INFO - 2024-10-10 22:11:38 --> Security Class Initialized
DEBUG - 2024-10-10 22:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:11:38 --> Input Class Initialized
INFO - 2024-10-10 22:11:38 --> Language Class Initialized
INFO - 2024-10-10 22:11:38 --> Language Class Initialized
INFO - 2024-10-10 22:11:38 --> Config Class Initialized
INFO - 2024-10-10 22:11:38 --> Loader Class Initialized
INFO - 2024-10-10 22:11:38 --> Helper loaded: url_helper
INFO - 2024-10-10 22:11:38 --> Helper loaded: file_helper
INFO - 2024-10-10 22:11:38 --> Helper loaded: form_helper
INFO - 2024-10-10 22:11:38 --> Helper loaded: my_helper
INFO - 2024-10-10 22:11:38 --> Database Driver Class Initialized
INFO - 2024-10-10 22:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:11:38 --> Controller Class Initialized
DEBUG - 2024-10-10 22:11:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-10 22:11:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:11:38 --> Final output sent to browser
DEBUG - 2024-10-10 22:11:38 --> Total execution time: 0.0324
INFO - 2024-10-10 22:11:45 --> Config Class Initialized
INFO - 2024-10-10 22:11:45 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:11:45 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:11:45 --> Utf8 Class Initialized
INFO - 2024-10-10 22:11:45 --> URI Class Initialized
INFO - 2024-10-10 22:11:45 --> Router Class Initialized
INFO - 2024-10-10 22:11:45 --> Output Class Initialized
INFO - 2024-10-10 22:11:45 --> Security Class Initialized
DEBUG - 2024-10-10 22:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:11:45 --> Input Class Initialized
INFO - 2024-10-10 22:11:45 --> Language Class Initialized
INFO - 2024-10-10 22:11:45 --> Language Class Initialized
INFO - 2024-10-10 22:11:45 --> Config Class Initialized
INFO - 2024-10-10 22:11:45 --> Loader Class Initialized
INFO - 2024-10-10 22:11:45 --> Helper loaded: url_helper
INFO - 2024-10-10 22:11:45 --> Helper loaded: file_helper
INFO - 2024-10-10 22:11:45 --> Helper loaded: form_helper
INFO - 2024-10-10 22:11:45 --> Helper loaded: my_helper
INFO - 2024-10-10 22:11:45 --> Database Driver Class Initialized
INFO - 2024-10-10 22:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:11:45 --> Controller Class Initialized
DEBUG - 2024-10-10 22:11:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-10 22:11:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:11:45 --> Final output sent to browser
DEBUG - 2024-10-10 22:11:45 --> Total execution time: 0.0327
INFO - 2024-10-10 22:11:49 --> Config Class Initialized
INFO - 2024-10-10 22:11:49 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:11:49 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:11:49 --> Utf8 Class Initialized
INFO - 2024-10-10 22:11:49 --> URI Class Initialized
INFO - 2024-10-10 22:11:49 --> Router Class Initialized
INFO - 2024-10-10 22:11:49 --> Output Class Initialized
INFO - 2024-10-10 22:11:49 --> Security Class Initialized
DEBUG - 2024-10-10 22:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:11:49 --> Input Class Initialized
INFO - 2024-10-10 22:11:49 --> Language Class Initialized
INFO - 2024-10-10 22:11:49 --> Language Class Initialized
INFO - 2024-10-10 22:11:49 --> Config Class Initialized
INFO - 2024-10-10 22:11:49 --> Loader Class Initialized
INFO - 2024-10-10 22:11:49 --> Helper loaded: url_helper
INFO - 2024-10-10 22:11:49 --> Helper loaded: file_helper
INFO - 2024-10-10 22:11:49 --> Helper loaded: form_helper
INFO - 2024-10-10 22:11:49 --> Helper loaded: my_helper
INFO - 2024-10-10 22:11:49 --> Database Driver Class Initialized
INFO - 2024-10-10 22:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:11:49 --> Controller Class Initialized
DEBUG - 2024-10-10 22:11:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-10 22:11:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:11:49 --> Final output sent to browser
DEBUG - 2024-10-10 22:11:49 --> Total execution time: 0.0364
INFO - 2024-10-10 22:11:52 --> Config Class Initialized
INFO - 2024-10-10 22:11:52 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:11:52 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:11:52 --> Utf8 Class Initialized
INFO - 2024-10-10 22:11:52 --> URI Class Initialized
INFO - 2024-10-10 22:11:52 --> Router Class Initialized
INFO - 2024-10-10 22:11:52 --> Output Class Initialized
INFO - 2024-10-10 22:11:52 --> Security Class Initialized
DEBUG - 2024-10-10 22:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:11:52 --> Input Class Initialized
INFO - 2024-10-10 22:11:52 --> Language Class Initialized
INFO - 2024-10-10 22:11:52 --> Language Class Initialized
INFO - 2024-10-10 22:11:52 --> Config Class Initialized
INFO - 2024-10-10 22:11:52 --> Loader Class Initialized
INFO - 2024-10-10 22:11:52 --> Helper loaded: url_helper
INFO - 2024-10-10 22:11:52 --> Helper loaded: file_helper
INFO - 2024-10-10 22:11:52 --> Helper loaded: form_helper
INFO - 2024-10-10 22:11:52 --> Helper loaded: my_helper
INFO - 2024-10-10 22:11:52 --> Database Driver Class Initialized
INFO - 2024-10-10 22:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:11:52 --> Controller Class Initialized
INFO - 2024-10-10 22:11:52 --> Final output sent to browser
DEBUG - 2024-10-10 22:11:52 --> Total execution time: 0.0402
INFO - 2024-10-10 22:11:56 --> Config Class Initialized
INFO - 2024-10-10 22:11:56 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:11:56 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:11:56 --> Utf8 Class Initialized
INFO - 2024-10-10 22:11:56 --> URI Class Initialized
INFO - 2024-10-10 22:11:56 --> Router Class Initialized
INFO - 2024-10-10 22:11:56 --> Output Class Initialized
INFO - 2024-10-10 22:11:56 --> Security Class Initialized
DEBUG - 2024-10-10 22:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:11:56 --> Input Class Initialized
INFO - 2024-10-10 22:11:56 --> Language Class Initialized
INFO - 2024-10-10 22:11:56 --> Language Class Initialized
INFO - 2024-10-10 22:11:56 --> Config Class Initialized
INFO - 2024-10-10 22:11:56 --> Loader Class Initialized
INFO - 2024-10-10 22:11:56 --> Helper loaded: url_helper
INFO - 2024-10-10 22:11:56 --> Helper loaded: file_helper
INFO - 2024-10-10 22:11:56 --> Helper loaded: form_helper
INFO - 2024-10-10 22:11:56 --> Helper loaded: my_helper
INFO - 2024-10-10 22:11:56 --> Database Driver Class Initialized
INFO - 2024-10-10 22:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:11:57 --> Controller Class Initialized
INFO - 2024-10-10 22:13:32 --> Config Class Initialized
INFO - 2024-10-10 22:13:32 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:13:32 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:13:32 --> Utf8 Class Initialized
INFO - 2024-10-10 22:13:32 --> URI Class Initialized
INFO - 2024-10-10 22:13:32 --> Router Class Initialized
INFO - 2024-10-10 22:13:32 --> Output Class Initialized
INFO - 2024-10-10 22:13:32 --> Security Class Initialized
DEBUG - 2024-10-10 22:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:13:32 --> Input Class Initialized
INFO - 2024-10-10 22:13:32 --> Language Class Initialized
INFO - 2024-10-10 22:13:33 --> Language Class Initialized
INFO - 2024-10-10 22:13:33 --> Config Class Initialized
INFO - 2024-10-10 22:13:33 --> Loader Class Initialized
INFO - 2024-10-10 22:13:33 --> Helper loaded: url_helper
INFO - 2024-10-10 22:13:33 --> Helper loaded: file_helper
INFO - 2024-10-10 22:13:33 --> Helper loaded: form_helper
INFO - 2024-10-10 22:13:33 --> Helper loaded: my_helper
INFO - 2024-10-10 22:13:33 --> Database Driver Class Initialized
INFO - 2024-10-10 22:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:13:33 --> Controller Class Initialized
DEBUG - 2024-10-10 22:13:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-10-10 22:13:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:13:33 --> Final output sent to browser
DEBUG - 2024-10-10 22:13:33 --> Total execution time: 0.0372
INFO - 2024-10-10 22:13:43 --> Config Class Initialized
INFO - 2024-10-10 22:13:43 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:13:43 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:13:43 --> Utf8 Class Initialized
INFO - 2024-10-10 22:13:43 --> URI Class Initialized
INFO - 2024-10-10 22:13:43 --> Router Class Initialized
INFO - 2024-10-10 22:13:43 --> Output Class Initialized
INFO - 2024-10-10 22:13:43 --> Security Class Initialized
DEBUG - 2024-10-10 22:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:13:43 --> Input Class Initialized
INFO - 2024-10-10 22:13:43 --> Language Class Initialized
INFO - 2024-10-10 22:13:43 --> Language Class Initialized
INFO - 2024-10-10 22:13:43 --> Config Class Initialized
INFO - 2024-10-10 22:13:43 --> Loader Class Initialized
INFO - 2024-10-10 22:13:43 --> Helper loaded: url_helper
INFO - 2024-10-10 22:13:43 --> Helper loaded: file_helper
INFO - 2024-10-10 22:13:43 --> Helper loaded: form_helper
INFO - 2024-10-10 22:13:43 --> Helper loaded: my_helper
INFO - 2024-10-10 22:13:43 --> Database Driver Class Initialized
INFO - 2024-10-10 22:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:13:43 --> Controller Class Initialized
INFO - 2024-10-10 22:13:43 --> Config Class Initialized
INFO - 2024-10-10 22:13:43 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:13:43 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:13:43 --> Utf8 Class Initialized
INFO - 2024-10-10 22:13:43 --> URI Class Initialized
INFO - 2024-10-10 22:13:43 --> Router Class Initialized
INFO - 2024-10-10 22:13:43 --> Output Class Initialized
INFO - 2024-10-10 22:13:43 --> Security Class Initialized
DEBUG - 2024-10-10 22:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:13:43 --> Input Class Initialized
INFO - 2024-10-10 22:13:43 --> Language Class Initialized
INFO - 2024-10-10 22:13:43 --> Language Class Initialized
INFO - 2024-10-10 22:13:43 --> Config Class Initialized
INFO - 2024-10-10 22:13:43 --> Loader Class Initialized
INFO - 2024-10-10 22:13:43 --> Helper loaded: url_helper
INFO - 2024-10-10 22:13:43 --> Helper loaded: file_helper
INFO - 2024-10-10 22:13:43 --> Helper loaded: form_helper
INFO - 2024-10-10 22:13:43 --> Helper loaded: my_helper
INFO - 2024-10-10 22:13:43 --> Database Driver Class Initialized
INFO - 2024-10-10 22:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:13:43 --> Controller Class Initialized
DEBUG - 2024-10-10 22:13:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-10 22:13:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:13:43 --> Final output sent to browser
DEBUG - 2024-10-10 22:13:43 --> Total execution time: 0.0397
INFO - 2024-10-10 22:13:46 --> Config Class Initialized
INFO - 2024-10-10 22:13:46 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:13:46 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:13:46 --> Utf8 Class Initialized
INFO - 2024-10-10 22:13:46 --> URI Class Initialized
INFO - 2024-10-10 22:13:46 --> Router Class Initialized
INFO - 2024-10-10 22:13:46 --> Output Class Initialized
INFO - 2024-10-10 22:13:46 --> Security Class Initialized
DEBUG - 2024-10-10 22:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:13:46 --> Input Class Initialized
INFO - 2024-10-10 22:13:46 --> Language Class Initialized
INFO - 2024-10-10 22:13:46 --> Language Class Initialized
INFO - 2024-10-10 22:13:46 --> Config Class Initialized
INFO - 2024-10-10 22:13:46 --> Loader Class Initialized
INFO - 2024-10-10 22:13:46 --> Helper loaded: url_helper
INFO - 2024-10-10 22:13:46 --> Helper loaded: file_helper
INFO - 2024-10-10 22:13:46 --> Helper loaded: form_helper
INFO - 2024-10-10 22:13:46 --> Helper loaded: my_helper
INFO - 2024-10-10 22:13:46 --> Database Driver Class Initialized
INFO - 2024-10-10 22:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:13:46 --> Controller Class Initialized
INFO - 2024-10-10 22:13:46 --> Final output sent to browser
DEBUG - 2024-10-10 22:13:46 --> Total execution time: 0.0329
INFO - 2024-10-10 22:14:00 --> Config Class Initialized
INFO - 2024-10-10 22:14:00 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:14:00 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:14:00 --> Utf8 Class Initialized
INFO - 2024-10-10 22:14:00 --> URI Class Initialized
INFO - 2024-10-10 22:14:00 --> Router Class Initialized
INFO - 2024-10-10 22:14:00 --> Output Class Initialized
INFO - 2024-10-10 22:14:00 --> Security Class Initialized
DEBUG - 2024-10-10 22:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:14:00 --> Input Class Initialized
INFO - 2024-10-10 22:14:00 --> Language Class Initialized
INFO - 2024-10-10 22:14:00 --> Language Class Initialized
INFO - 2024-10-10 22:14:00 --> Config Class Initialized
INFO - 2024-10-10 22:14:00 --> Loader Class Initialized
INFO - 2024-10-10 22:14:00 --> Helper loaded: url_helper
INFO - 2024-10-10 22:14:00 --> Helper loaded: file_helper
INFO - 2024-10-10 22:14:00 --> Helper loaded: form_helper
INFO - 2024-10-10 22:14:00 --> Helper loaded: my_helper
INFO - 2024-10-10 22:14:00 --> Database Driver Class Initialized
INFO - 2024-10-10 22:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:14:00 --> Controller Class Initialized
INFO - 2024-10-10 22:14:00 --> Final output sent to browser
DEBUG - 2024-10-10 22:14:00 --> Total execution time: 0.1191
INFO - 2024-10-10 22:14:04 --> Config Class Initialized
INFO - 2024-10-10 22:14:04 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:14:04 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:14:04 --> Utf8 Class Initialized
INFO - 2024-10-10 22:14:04 --> URI Class Initialized
INFO - 2024-10-10 22:14:04 --> Router Class Initialized
INFO - 2024-10-10 22:14:04 --> Output Class Initialized
INFO - 2024-10-10 22:14:04 --> Security Class Initialized
DEBUG - 2024-10-10 22:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:14:04 --> Input Class Initialized
INFO - 2024-10-10 22:14:04 --> Language Class Initialized
INFO - 2024-10-10 22:14:04 --> Language Class Initialized
INFO - 2024-10-10 22:14:04 --> Config Class Initialized
INFO - 2024-10-10 22:14:04 --> Loader Class Initialized
INFO - 2024-10-10 22:14:04 --> Helper loaded: url_helper
INFO - 2024-10-10 22:14:04 --> Helper loaded: file_helper
INFO - 2024-10-10 22:14:04 --> Helper loaded: form_helper
INFO - 2024-10-10 22:14:04 --> Helper loaded: my_helper
INFO - 2024-10-10 22:14:04 --> Database Driver Class Initialized
INFO - 2024-10-10 22:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:14:04 --> Controller Class Initialized
INFO - 2024-10-10 22:15:03 --> Config Class Initialized
INFO - 2024-10-10 22:15:03 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:15:03 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:15:03 --> Utf8 Class Initialized
INFO - 2024-10-10 22:15:03 --> URI Class Initialized
INFO - 2024-10-10 22:15:03 --> Router Class Initialized
INFO - 2024-10-10 22:15:03 --> Output Class Initialized
INFO - 2024-10-10 22:15:03 --> Security Class Initialized
DEBUG - 2024-10-10 22:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:15:03 --> Input Class Initialized
INFO - 2024-10-10 22:15:03 --> Language Class Initialized
INFO - 2024-10-10 22:15:03 --> Language Class Initialized
INFO - 2024-10-10 22:15:03 --> Config Class Initialized
INFO - 2024-10-10 22:15:03 --> Loader Class Initialized
INFO - 2024-10-10 22:15:03 --> Helper loaded: url_helper
INFO - 2024-10-10 22:15:03 --> Helper loaded: file_helper
INFO - 2024-10-10 22:15:03 --> Helper loaded: form_helper
INFO - 2024-10-10 22:15:03 --> Helper loaded: my_helper
INFO - 2024-10-10 22:15:03 --> Database Driver Class Initialized
INFO - 2024-10-10 22:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:15:03 --> Controller Class Initialized
DEBUG - 2024-10-10 22:15:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-10 22:15:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:15:03 --> Final output sent to browser
DEBUG - 2024-10-10 22:15:03 --> Total execution time: 0.0897
INFO - 2024-10-10 22:15:07 --> Config Class Initialized
INFO - 2024-10-10 22:15:07 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:15:07 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:15:07 --> Utf8 Class Initialized
INFO - 2024-10-10 22:15:07 --> URI Class Initialized
INFO - 2024-10-10 22:15:07 --> Router Class Initialized
INFO - 2024-10-10 22:15:07 --> Output Class Initialized
INFO - 2024-10-10 22:15:07 --> Security Class Initialized
DEBUG - 2024-10-10 22:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:15:07 --> Input Class Initialized
INFO - 2024-10-10 22:15:07 --> Language Class Initialized
INFO - 2024-10-10 22:15:07 --> Language Class Initialized
INFO - 2024-10-10 22:15:07 --> Config Class Initialized
INFO - 2024-10-10 22:15:07 --> Loader Class Initialized
INFO - 2024-10-10 22:15:07 --> Helper loaded: url_helper
INFO - 2024-10-10 22:15:07 --> Helper loaded: file_helper
INFO - 2024-10-10 22:15:07 --> Helper loaded: form_helper
INFO - 2024-10-10 22:15:07 --> Helper loaded: my_helper
INFO - 2024-10-10 22:15:07 --> Database Driver Class Initialized
INFO - 2024-10-10 22:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:15:07 --> Controller Class Initialized
DEBUG - 2024-10-10 22:15:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-10 22:15:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:15:07 --> Final output sent to browser
DEBUG - 2024-10-10 22:15:07 --> Total execution time: 0.0350
INFO - 2024-10-10 22:15:09 --> Config Class Initialized
INFO - 2024-10-10 22:15:09 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:15:09 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:15:09 --> Utf8 Class Initialized
INFO - 2024-10-10 22:15:09 --> URI Class Initialized
INFO - 2024-10-10 22:15:09 --> Router Class Initialized
INFO - 2024-10-10 22:15:09 --> Output Class Initialized
INFO - 2024-10-10 22:15:09 --> Security Class Initialized
DEBUG - 2024-10-10 22:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:15:09 --> Input Class Initialized
INFO - 2024-10-10 22:15:09 --> Language Class Initialized
INFO - 2024-10-10 22:15:09 --> Language Class Initialized
INFO - 2024-10-10 22:15:09 --> Config Class Initialized
INFO - 2024-10-10 22:15:09 --> Loader Class Initialized
INFO - 2024-10-10 22:15:09 --> Helper loaded: url_helper
INFO - 2024-10-10 22:15:09 --> Helper loaded: file_helper
INFO - 2024-10-10 22:15:09 --> Helper loaded: form_helper
INFO - 2024-10-10 22:15:09 --> Helper loaded: my_helper
INFO - 2024-10-10 22:15:09 --> Database Driver Class Initialized
INFO - 2024-10-10 22:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:15:09 --> Controller Class Initialized
INFO - 2024-10-10 22:15:09 --> Final output sent to browser
DEBUG - 2024-10-10 22:15:09 --> Total execution time: 0.0357
INFO - 2024-10-10 22:15:10 --> Config Class Initialized
INFO - 2024-10-10 22:15:10 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:15:10 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:15:10 --> Utf8 Class Initialized
INFO - 2024-10-10 22:15:10 --> URI Class Initialized
INFO - 2024-10-10 22:15:10 --> Router Class Initialized
INFO - 2024-10-10 22:15:10 --> Output Class Initialized
INFO - 2024-10-10 22:15:10 --> Security Class Initialized
DEBUG - 2024-10-10 22:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:15:10 --> Input Class Initialized
INFO - 2024-10-10 22:15:10 --> Language Class Initialized
INFO - 2024-10-10 22:15:10 --> Language Class Initialized
INFO - 2024-10-10 22:15:10 --> Config Class Initialized
INFO - 2024-10-10 22:15:10 --> Loader Class Initialized
INFO - 2024-10-10 22:15:10 --> Helper loaded: url_helper
INFO - 2024-10-10 22:15:10 --> Helper loaded: file_helper
INFO - 2024-10-10 22:15:10 --> Helper loaded: form_helper
INFO - 2024-10-10 22:15:10 --> Helper loaded: my_helper
INFO - 2024-10-10 22:15:10 --> Database Driver Class Initialized
INFO - 2024-10-10 22:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:15:10 --> Controller Class Initialized
INFO - 2024-10-10 22:15:23 --> Config Class Initialized
INFO - 2024-10-10 22:15:23 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:15:23 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:15:23 --> Utf8 Class Initialized
INFO - 2024-10-10 22:15:23 --> URI Class Initialized
INFO - 2024-10-10 22:15:23 --> Router Class Initialized
INFO - 2024-10-10 22:15:23 --> Output Class Initialized
INFO - 2024-10-10 22:15:23 --> Security Class Initialized
DEBUG - 2024-10-10 22:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:15:23 --> Input Class Initialized
INFO - 2024-10-10 22:15:23 --> Language Class Initialized
INFO - 2024-10-10 22:15:23 --> Language Class Initialized
INFO - 2024-10-10 22:15:23 --> Config Class Initialized
INFO - 2024-10-10 22:15:23 --> Loader Class Initialized
INFO - 2024-10-10 22:15:23 --> Helper loaded: url_helper
INFO - 2024-10-10 22:15:23 --> Helper loaded: file_helper
INFO - 2024-10-10 22:15:23 --> Helper loaded: form_helper
INFO - 2024-10-10 22:15:23 --> Helper loaded: my_helper
INFO - 2024-10-10 22:15:23 --> Database Driver Class Initialized
INFO - 2024-10-10 22:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:15:23 --> Controller Class Initialized
DEBUG - 2024-10-10 22:15:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-10 22:15:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:15:23 --> Final output sent to browser
DEBUG - 2024-10-10 22:15:23 --> Total execution time: 0.0413
INFO - 2024-10-10 22:15:26 --> Config Class Initialized
INFO - 2024-10-10 22:15:26 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:15:26 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:15:26 --> Utf8 Class Initialized
INFO - 2024-10-10 22:15:26 --> URI Class Initialized
INFO - 2024-10-10 22:15:26 --> Router Class Initialized
INFO - 2024-10-10 22:15:26 --> Output Class Initialized
INFO - 2024-10-10 22:15:26 --> Security Class Initialized
DEBUG - 2024-10-10 22:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:15:26 --> Input Class Initialized
INFO - 2024-10-10 22:15:26 --> Language Class Initialized
INFO - 2024-10-10 22:15:26 --> Language Class Initialized
INFO - 2024-10-10 22:15:26 --> Config Class Initialized
INFO - 2024-10-10 22:15:26 --> Loader Class Initialized
INFO - 2024-10-10 22:15:26 --> Helper loaded: url_helper
INFO - 2024-10-10 22:15:26 --> Helper loaded: file_helper
INFO - 2024-10-10 22:15:26 --> Helper loaded: form_helper
INFO - 2024-10-10 22:15:26 --> Helper loaded: my_helper
INFO - 2024-10-10 22:15:26 --> Database Driver Class Initialized
INFO - 2024-10-10 22:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:15:26 --> Controller Class Initialized
DEBUG - 2024-10-10 22:15:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 22:15:29 --> Final output sent to browser
DEBUG - 2024-10-10 22:15:29 --> Total execution time: 3.1437
INFO - 2024-10-10 22:17:32 --> Config Class Initialized
INFO - 2024-10-10 22:17:32 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:17:32 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:17:32 --> Utf8 Class Initialized
INFO - 2024-10-10 22:17:32 --> URI Class Initialized
INFO - 2024-10-10 22:17:32 --> Router Class Initialized
INFO - 2024-10-10 22:17:32 --> Output Class Initialized
INFO - 2024-10-10 22:17:32 --> Security Class Initialized
DEBUG - 2024-10-10 22:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:17:32 --> Input Class Initialized
INFO - 2024-10-10 22:17:32 --> Language Class Initialized
INFO - 2024-10-10 22:17:32 --> Language Class Initialized
INFO - 2024-10-10 22:17:32 --> Config Class Initialized
INFO - 2024-10-10 22:17:32 --> Loader Class Initialized
INFO - 2024-10-10 22:17:32 --> Helper loaded: url_helper
INFO - 2024-10-10 22:17:32 --> Helper loaded: file_helper
INFO - 2024-10-10 22:17:32 --> Helper loaded: form_helper
INFO - 2024-10-10 22:17:32 --> Helper loaded: my_helper
INFO - 2024-10-10 22:17:32 --> Database Driver Class Initialized
INFO - 2024-10-10 22:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:17:32 --> Controller Class Initialized
DEBUG - 2024-10-10 22:17:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 22:17:35 --> Final output sent to browser
DEBUG - 2024-10-10 22:17:35 --> Total execution time: 2.9408
INFO - 2024-10-10 22:18:08 --> Config Class Initialized
INFO - 2024-10-10 22:18:08 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:18:08 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:18:08 --> Utf8 Class Initialized
INFO - 2024-10-10 22:18:08 --> URI Class Initialized
INFO - 2024-10-10 22:18:08 --> Router Class Initialized
INFO - 2024-10-10 22:18:08 --> Output Class Initialized
INFO - 2024-10-10 22:18:08 --> Security Class Initialized
DEBUG - 2024-10-10 22:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:18:08 --> Input Class Initialized
INFO - 2024-10-10 22:18:08 --> Language Class Initialized
INFO - 2024-10-10 22:18:08 --> Language Class Initialized
INFO - 2024-10-10 22:18:08 --> Config Class Initialized
INFO - 2024-10-10 22:18:08 --> Loader Class Initialized
INFO - 2024-10-10 22:18:08 --> Helper loaded: url_helper
INFO - 2024-10-10 22:18:08 --> Helper loaded: file_helper
INFO - 2024-10-10 22:18:08 --> Helper loaded: form_helper
INFO - 2024-10-10 22:18:08 --> Helper loaded: my_helper
INFO - 2024-10-10 22:18:08 --> Database Driver Class Initialized
INFO - 2024-10-10 22:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:18:08 --> Controller Class Initialized
DEBUG - 2024-10-10 22:18:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 22:18:11 --> Final output sent to browser
DEBUG - 2024-10-10 22:18:11 --> Total execution time: 2.9416
INFO - 2024-10-10 22:18:45 --> Config Class Initialized
INFO - 2024-10-10 22:18:45 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:18:45 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:18:45 --> Utf8 Class Initialized
INFO - 2024-10-10 22:18:45 --> URI Class Initialized
INFO - 2024-10-10 22:18:45 --> Router Class Initialized
INFO - 2024-10-10 22:18:45 --> Output Class Initialized
INFO - 2024-10-10 22:18:45 --> Security Class Initialized
DEBUG - 2024-10-10 22:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:18:45 --> Input Class Initialized
INFO - 2024-10-10 22:18:45 --> Language Class Initialized
INFO - 2024-10-10 22:18:45 --> Language Class Initialized
INFO - 2024-10-10 22:18:45 --> Config Class Initialized
INFO - 2024-10-10 22:18:45 --> Loader Class Initialized
INFO - 2024-10-10 22:18:45 --> Helper loaded: url_helper
INFO - 2024-10-10 22:18:45 --> Helper loaded: file_helper
INFO - 2024-10-10 22:18:45 --> Helper loaded: form_helper
INFO - 2024-10-10 22:18:45 --> Helper loaded: my_helper
INFO - 2024-10-10 22:18:45 --> Database Driver Class Initialized
INFO - 2024-10-10 22:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:18:45 --> Controller Class Initialized
DEBUG - 2024-10-10 22:18:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 22:18:48 --> Final output sent to browser
DEBUG - 2024-10-10 22:18:48 --> Total execution time: 3.3551
INFO - 2024-10-10 22:19:45 --> Config Class Initialized
INFO - 2024-10-10 22:19:45 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:19:45 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:19:45 --> Utf8 Class Initialized
INFO - 2024-10-10 22:19:45 --> URI Class Initialized
INFO - 2024-10-10 22:19:45 --> Router Class Initialized
INFO - 2024-10-10 22:19:45 --> Output Class Initialized
INFO - 2024-10-10 22:19:45 --> Security Class Initialized
DEBUG - 2024-10-10 22:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:19:45 --> Input Class Initialized
INFO - 2024-10-10 22:19:45 --> Language Class Initialized
INFO - 2024-10-10 22:19:45 --> Language Class Initialized
INFO - 2024-10-10 22:19:45 --> Config Class Initialized
INFO - 2024-10-10 22:19:45 --> Loader Class Initialized
INFO - 2024-10-10 22:19:46 --> Helper loaded: url_helper
INFO - 2024-10-10 22:19:46 --> Helper loaded: file_helper
INFO - 2024-10-10 22:19:46 --> Helper loaded: form_helper
INFO - 2024-10-10 22:19:46 --> Helper loaded: my_helper
INFO - 2024-10-10 22:19:46 --> Database Driver Class Initialized
INFO - 2024-10-10 22:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:19:46 --> Controller Class Initialized
DEBUG - 2024-10-10 22:19:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 22:19:48 --> Final output sent to browser
DEBUG - 2024-10-10 22:19:48 --> Total execution time: 3.0041
INFO - 2024-10-10 22:23:59 --> Config Class Initialized
INFO - 2024-10-10 22:23:59 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:23:59 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:23:59 --> Utf8 Class Initialized
INFO - 2024-10-10 22:23:59 --> URI Class Initialized
INFO - 2024-10-10 22:23:59 --> Router Class Initialized
INFO - 2024-10-10 22:23:59 --> Output Class Initialized
INFO - 2024-10-10 22:23:59 --> Security Class Initialized
DEBUG - 2024-10-10 22:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:23:59 --> Input Class Initialized
INFO - 2024-10-10 22:23:59 --> Language Class Initialized
INFO - 2024-10-10 22:23:59 --> Language Class Initialized
INFO - 2024-10-10 22:23:59 --> Config Class Initialized
INFO - 2024-10-10 22:23:59 --> Loader Class Initialized
INFO - 2024-10-10 22:23:59 --> Helper loaded: url_helper
INFO - 2024-10-10 22:23:59 --> Helper loaded: file_helper
INFO - 2024-10-10 22:23:59 --> Helper loaded: form_helper
INFO - 2024-10-10 22:23:59 --> Helper loaded: my_helper
INFO - 2024-10-10 22:23:59 --> Database Driver Class Initialized
INFO - 2024-10-10 22:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:23:59 --> Controller Class Initialized
DEBUG - 2024-10-10 22:23:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-10 22:23:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:23:59 --> Final output sent to browser
DEBUG - 2024-10-10 22:23:59 --> Total execution time: 0.0402
INFO - 2024-10-10 22:24:08 --> Config Class Initialized
INFO - 2024-10-10 22:24:08 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:24:08 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:24:08 --> Utf8 Class Initialized
INFO - 2024-10-10 22:24:08 --> URI Class Initialized
INFO - 2024-10-10 22:24:08 --> Router Class Initialized
INFO - 2024-10-10 22:24:08 --> Output Class Initialized
INFO - 2024-10-10 22:24:08 --> Security Class Initialized
DEBUG - 2024-10-10 22:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:24:08 --> Input Class Initialized
INFO - 2024-10-10 22:24:08 --> Language Class Initialized
INFO - 2024-10-10 22:24:08 --> Language Class Initialized
INFO - 2024-10-10 22:24:08 --> Config Class Initialized
INFO - 2024-10-10 22:24:08 --> Loader Class Initialized
INFO - 2024-10-10 22:24:08 --> Helper loaded: url_helper
INFO - 2024-10-10 22:24:08 --> Helper loaded: file_helper
INFO - 2024-10-10 22:24:08 --> Helper loaded: form_helper
INFO - 2024-10-10 22:24:08 --> Helper loaded: my_helper
INFO - 2024-10-10 22:24:08 --> Database Driver Class Initialized
INFO - 2024-10-10 22:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:24:08 --> Controller Class Initialized
INFO - 2024-10-10 22:24:08 --> Helper loaded: cookie_helper
INFO - 2024-10-10 22:24:08 --> Final output sent to browser
DEBUG - 2024-10-10 22:24:08 --> Total execution time: 0.0561
INFO - 2024-10-10 22:24:08 --> Config Class Initialized
INFO - 2024-10-10 22:24:08 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:24:08 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:24:08 --> Utf8 Class Initialized
INFO - 2024-10-10 22:24:08 --> URI Class Initialized
INFO - 2024-10-10 22:24:08 --> Router Class Initialized
INFO - 2024-10-10 22:24:08 --> Output Class Initialized
INFO - 2024-10-10 22:24:08 --> Security Class Initialized
DEBUG - 2024-10-10 22:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:24:08 --> Input Class Initialized
INFO - 2024-10-10 22:24:08 --> Language Class Initialized
INFO - 2024-10-10 22:24:08 --> Language Class Initialized
INFO - 2024-10-10 22:24:08 --> Config Class Initialized
INFO - 2024-10-10 22:24:08 --> Loader Class Initialized
INFO - 2024-10-10 22:24:08 --> Helper loaded: url_helper
INFO - 2024-10-10 22:24:08 --> Helper loaded: file_helper
INFO - 2024-10-10 22:24:08 --> Helper loaded: form_helper
INFO - 2024-10-10 22:24:08 --> Helper loaded: my_helper
INFO - 2024-10-10 22:24:08 --> Database Driver Class Initialized
INFO - 2024-10-10 22:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:24:08 --> Controller Class Initialized
DEBUG - 2024-10-10 22:24:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-10 22:24:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:24:08 --> Final output sent to browser
DEBUG - 2024-10-10 22:24:08 --> Total execution time: 0.0355
INFO - 2024-10-10 22:24:15 --> Config Class Initialized
INFO - 2024-10-10 22:24:15 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:24:15 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:24:15 --> Utf8 Class Initialized
INFO - 2024-10-10 22:24:15 --> URI Class Initialized
INFO - 2024-10-10 22:24:15 --> Router Class Initialized
INFO - 2024-10-10 22:24:15 --> Output Class Initialized
INFO - 2024-10-10 22:24:15 --> Security Class Initialized
DEBUG - 2024-10-10 22:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:24:15 --> Input Class Initialized
INFO - 2024-10-10 22:24:15 --> Language Class Initialized
INFO - 2024-10-10 22:24:15 --> Language Class Initialized
INFO - 2024-10-10 22:24:15 --> Config Class Initialized
INFO - 2024-10-10 22:24:15 --> Loader Class Initialized
INFO - 2024-10-10 22:24:15 --> Helper loaded: url_helper
INFO - 2024-10-10 22:24:15 --> Helper loaded: file_helper
INFO - 2024-10-10 22:24:15 --> Helper loaded: form_helper
INFO - 2024-10-10 22:24:15 --> Helper loaded: my_helper
INFO - 2024-10-10 22:24:15 --> Database Driver Class Initialized
INFO - 2024-10-10 22:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:24:15 --> Controller Class Initialized
DEBUG - 2024-10-10 22:24:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-10 22:24:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:24:15 --> Final output sent to browser
DEBUG - 2024-10-10 22:24:15 --> Total execution time: 0.0351
INFO - 2024-10-10 22:24:18 --> Config Class Initialized
INFO - 2024-10-10 22:24:18 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:24:18 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:24:18 --> Utf8 Class Initialized
INFO - 2024-10-10 22:24:18 --> URI Class Initialized
INFO - 2024-10-10 22:24:18 --> Router Class Initialized
INFO - 2024-10-10 22:24:18 --> Output Class Initialized
INFO - 2024-10-10 22:24:18 --> Security Class Initialized
DEBUG - 2024-10-10 22:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:24:18 --> Input Class Initialized
INFO - 2024-10-10 22:24:18 --> Language Class Initialized
INFO - 2024-10-10 22:24:18 --> Language Class Initialized
INFO - 2024-10-10 22:24:18 --> Config Class Initialized
INFO - 2024-10-10 22:24:18 --> Loader Class Initialized
INFO - 2024-10-10 22:24:18 --> Helper loaded: url_helper
INFO - 2024-10-10 22:24:18 --> Helper loaded: file_helper
INFO - 2024-10-10 22:24:18 --> Helper loaded: form_helper
INFO - 2024-10-10 22:24:18 --> Helper loaded: my_helper
INFO - 2024-10-10 22:24:18 --> Database Driver Class Initialized
INFO - 2024-10-10 22:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:24:18 --> Controller Class Initialized
DEBUG - 2024-10-10 22:24:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 22:24:21 --> Final output sent to browser
DEBUG - 2024-10-10 22:24:21 --> Total execution time: 2.8460
INFO - 2024-10-10 22:24:27 --> Config Class Initialized
INFO - 2024-10-10 22:24:27 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:24:27 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:24:27 --> Utf8 Class Initialized
INFO - 2024-10-10 22:24:27 --> URI Class Initialized
INFO - 2024-10-10 22:24:27 --> Router Class Initialized
INFO - 2024-10-10 22:24:27 --> Output Class Initialized
INFO - 2024-10-10 22:24:27 --> Security Class Initialized
DEBUG - 2024-10-10 22:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:24:27 --> Input Class Initialized
INFO - 2024-10-10 22:24:27 --> Language Class Initialized
INFO - 2024-10-10 22:24:27 --> Language Class Initialized
INFO - 2024-10-10 22:24:27 --> Config Class Initialized
INFO - 2024-10-10 22:24:27 --> Loader Class Initialized
INFO - 2024-10-10 22:24:27 --> Helper loaded: url_helper
INFO - 2024-10-10 22:24:27 --> Helper loaded: file_helper
INFO - 2024-10-10 22:24:27 --> Helper loaded: form_helper
INFO - 2024-10-10 22:24:27 --> Helper loaded: my_helper
INFO - 2024-10-10 22:24:27 --> Database Driver Class Initialized
INFO - 2024-10-10 22:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:24:27 --> Controller Class Initialized
INFO - 2024-10-10 22:24:27 --> Helper loaded: cookie_helper
INFO - 2024-10-10 22:24:27 --> Config Class Initialized
INFO - 2024-10-10 22:24:27 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:24:27 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:24:27 --> Utf8 Class Initialized
INFO - 2024-10-10 22:24:27 --> URI Class Initialized
INFO - 2024-10-10 22:24:27 --> Router Class Initialized
INFO - 2024-10-10 22:24:27 --> Output Class Initialized
INFO - 2024-10-10 22:24:27 --> Security Class Initialized
DEBUG - 2024-10-10 22:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:24:27 --> Input Class Initialized
INFO - 2024-10-10 22:24:27 --> Language Class Initialized
INFO - 2024-10-10 22:24:27 --> Language Class Initialized
INFO - 2024-10-10 22:24:27 --> Config Class Initialized
INFO - 2024-10-10 22:24:27 --> Loader Class Initialized
INFO - 2024-10-10 22:24:27 --> Helper loaded: url_helper
INFO - 2024-10-10 22:24:27 --> Helper loaded: file_helper
INFO - 2024-10-10 22:24:27 --> Helper loaded: form_helper
INFO - 2024-10-10 22:24:27 --> Helper loaded: my_helper
INFO - 2024-10-10 22:24:27 --> Database Driver Class Initialized
INFO - 2024-10-10 22:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:24:27 --> Controller Class Initialized
INFO - 2024-10-10 22:24:27 --> Config Class Initialized
INFO - 2024-10-10 22:24:27 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:24:27 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:24:27 --> Utf8 Class Initialized
INFO - 2024-10-10 22:24:27 --> URI Class Initialized
INFO - 2024-10-10 22:24:27 --> Router Class Initialized
INFO - 2024-10-10 22:24:27 --> Output Class Initialized
INFO - 2024-10-10 22:24:27 --> Security Class Initialized
DEBUG - 2024-10-10 22:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:24:27 --> Input Class Initialized
INFO - 2024-10-10 22:24:27 --> Language Class Initialized
INFO - 2024-10-10 22:24:27 --> Language Class Initialized
INFO - 2024-10-10 22:24:27 --> Config Class Initialized
INFO - 2024-10-10 22:24:27 --> Loader Class Initialized
INFO - 2024-10-10 22:24:27 --> Helper loaded: url_helper
INFO - 2024-10-10 22:24:27 --> Helper loaded: file_helper
INFO - 2024-10-10 22:24:27 --> Helper loaded: form_helper
INFO - 2024-10-10 22:24:27 --> Helper loaded: my_helper
INFO - 2024-10-10 22:24:27 --> Database Driver Class Initialized
INFO - 2024-10-10 22:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:24:27 --> Controller Class Initialized
DEBUG - 2024-10-10 22:24:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-10 22:24:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:24:27 --> Final output sent to browser
DEBUG - 2024-10-10 22:24:27 --> Total execution time: 0.0303
INFO - 2024-10-10 22:24:39 --> Config Class Initialized
INFO - 2024-10-10 22:24:39 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:24:39 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:24:39 --> Utf8 Class Initialized
INFO - 2024-10-10 22:24:39 --> URI Class Initialized
INFO - 2024-10-10 22:24:39 --> Router Class Initialized
INFO - 2024-10-10 22:24:39 --> Output Class Initialized
INFO - 2024-10-10 22:24:39 --> Security Class Initialized
DEBUG - 2024-10-10 22:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:24:39 --> Input Class Initialized
INFO - 2024-10-10 22:24:39 --> Language Class Initialized
INFO - 2024-10-10 22:24:39 --> Language Class Initialized
INFO - 2024-10-10 22:24:39 --> Config Class Initialized
INFO - 2024-10-10 22:24:39 --> Loader Class Initialized
INFO - 2024-10-10 22:24:39 --> Helper loaded: url_helper
INFO - 2024-10-10 22:24:39 --> Helper loaded: file_helper
INFO - 2024-10-10 22:24:39 --> Helper loaded: form_helper
INFO - 2024-10-10 22:24:39 --> Helper loaded: my_helper
INFO - 2024-10-10 22:24:39 --> Database Driver Class Initialized
INFO - 2024-10-10 22:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:24:39 --> Controller Class Initialized
INFO - 2024-10-10 22:24:39 --> Helper loaded: cookie_helper
INFO - 2024-10-10 22:24:39 --> Final output sent to browser
DEBUG - 2024-10-10 22:24:39 --> Total execution time: 0.0318
INFO - 2024-10-10 22:24:39 --> Config Class Initialized
INFO - 2024-10-10 22:24:39 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:24:39 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:24:39 --> Utf8 Class Initialized
INFO - 2024-10-10 22:24:39 --> URI Class Initialized
INFO - 2024-10-10 22:24:39 --> Router Class Initialized
INFO - 2024-10-10 22:24:39 --> Output Class Initialized
INFO - 2024-10-10 22:24:39 --> Security Class Initialized
DEBUG - 2024-10-10 22:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:24:39 --> Input Class Initialized
INFO - 2024-10-10 22:24:39 --> Language Class Initialized
INFO - 2024-10-10 22:24:39 --> Language Class Initialized
INFO - 2024-10-10 22:24:39 --> Config Class Initialized
INFO - 2024-10-10 22:24:39 --> Loader Class Initialized
INFO - 2024-10-10 22:24:39 --> Helper loaded: url_helper
INFO - 2024-10-10 22:24:39 --> Helper loaded: file_helper
INFO - 2024-10-10 22:24:39 --> Helper loaded: form_helper
INFO - 2024-10-10 22:24:39 --> Helper loaded: my_helper
INFO - 2024-10-10 22:24:39 --> Database Driver Class Initialized
INFO - 2024-10-10 22:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:24:39 --> Controller Class Initialized
DEBUG - 2024-10-10 22:24:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-10 22:24:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:24:39 --> Final output sent to browser
DEBUG - 2024-10-10 22:24:39 --> Total execution time: 0.0316
INFO - 2024-10-10 22:24:44 --> Config Class Initialized
INFO - 2024-10-10 22:24:44 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:24:44 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:24:44 --> Utf8 Class Initialized
INFO - 2024-10-10 22:24:44 --> URI Class Initialized
INFO - 2024-10-10 22:24:44 --> Router Class Initialized
INFO - 2024-10-10 22:24:44 --> Output Class Initialized
INFO - 2024-10-10 22:24:44 --> Security Class Initialized
DEBUG - 2024-10-10 22:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:24:44 --> Input Class Initialized
INFO - 2024-10-10 22:24:44 --> Language Class Initialized
INFO - 2024-10-10 22:24:44 --> Language Class Initialized
INFO - 2024-10-10 22:24:44 --> Config Class Initialized
INFO - 2024-10-10 22:24:44 --> Loader Class Initialized
INFO - 2024-10-10 22:24:44 --> Helper loaded: url_helper
INFO - 2024-10-10 22:24:44 --> Helper loaded: file_helper
INFO - 2024-10-10 22:24:44 --> Helper loaded: form_helper
INFO - 2024-10-10 22:24:44 --> Helper loaded: my_helper
INFO - 2024-10-10 22:24:44 --> Database Driver Class Initialized
INFO - 2024-10-10 22:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:24:44 --> Controller Class Initialized
DEBUG - 2024-10-10 22:24:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-10 22:24:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:24:44 --> Final output sent to browser
DEBUG - 2024-10-10 22:24:44 --> Total execution time: 0.0298
INFO - 2024-10-10 22:24:48 --> Config Class Initialized
INFO - 2024-10-10 22:24:48 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:24:48 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:24:48 --> Utf8 Class Initialized
INFO - 2024-10-10 22:24:48 --> URI Class Initialized
INFO - 2024-10-10 22:24:48 --> Router Class Initialized
INFO - 2024-10-10 22:24:48 --> Output Class Initialized
INFO - 2024-10-10 22:24:48 --> Security Class Initialized
DEBUG - 2024-10-10 22:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:24:48 --> Input Class Initialized
INFO - 2024-10-10 22:24:48 --> Language Class Initialized
INFO - 2024-10-10 22:24:48 --> Language Class Initialized
INFO - 2024-10-10 22:24:48 --> Config Class Initialized
INFO - 2024-10-10 22:24:48 --> Loader Class Initialized
INFO - 2024-10-10 22:24:48 --> Helper loaded: url_helper
INFO - 2024-10-10 22:24:48 --> Helper loaded: file_helper
INFO - 2024-10-10 22:24:48 --> Helper loaded: form_helper
INFO - 2024-10-10 22:24:48 --> Helper loaded: my_helper
INFO - 2024-10-10 22:24:48 --> Database Driver Class Initialized
INFO - 2024-10-10 22:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:24:48 --> Controller Class Initialized
DEBUG - 2024-10-10 22:24:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-10 22:24:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:24:48 --> Final output sent to browser
DEBUG - 2024-10-10 22:24:48 --> Total execution time: 0.0339
INFO - 2024-10-10 22:24:49 --> Config Class Initialized
INFO - 2024-10-10 22:24:49 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:24:49 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:24:49 --> Utf8 Class Initialized
INFO - 2024-10-10 22:24:49 --> URI Class Initialized
INFO - 2024-10-10 22:24:49 --> Router Class Initialized
INFO - 2024-10-10 22:24:49 --> Output Class Initialized
INFO - 2024-10-10 22:24:49 --> Security Class Initialized
DEBUG - 2024-10-10 22:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:24:49 --> Input Class Initialized
INFO - 2024-10-10 22:24:49 --> Language Class Initialized
INFO - 2024-10-10 22:24:49 --> Language Class Initialized
INFO - 2024-10-10 22:24:49 --> Config Class Initialized
INFO - 2024-10-10 22:24:49 --> Loader Class Initialized
INFO - 2024-10-10 22:24:49 --> Helper loaded: url_helper
INFO - 2024-10-10 22:24:49 --> Helper loaded: file_helper
INFO - 2024-10-10 22:24:49 --> Helper loaded: form_helper
INFO - 2024-10-10 22:24:49 --> Helper loaded: my_helper
INFO - 2024-10-10 22:24:49 --> Database Driver Class Initialized
INFO - 2024-10-10 22:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:24:49 --> Controller Class Initialized
INFO - 2024-10-10 22:24:49 --> Final output sent to browser
DEBUG - 2024-10-10 22:24:49 --> Total execution time: 0.0339
INFO - 2024-10-10 22:25:01 --> Config Class Initialized
INFO - 2024-10-10 22:25:01 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:25:01 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:25:01 --> Utf8 Class Initialized
INFO - 2024-10-10 22:25:01 --> URI Class Initialized
INFO - 2024-10-10 22:25:01 --> Router Class Initialized
INFO - 2024-10-10 22:25:01 --> Output Class Initialized
INFO - 2024-10-10 22:25:01 --> Security Class Initialized
DEBUG - 2024-10-10 22:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:25:01 --> Input Class Initialized
INFO - 2024-10-10 22:25:01 --> Language Class Initialized
INFO - 2024-10-10 22:25:01 --> Language Class Initialized
INFO - 2024-10-10 22:25:01 --> Config Class Initialized
INFO - 2024-10-10 22:25:01 --> Loader Class Initialized
INFO - 2024-10-10 22:25:01 --> Helper loaded: url_helper
INFO - 2024-10-10 22:25:01 --> Helper loaded: file_helper
INFO - 2024-10-10 22:25:01 --> Helper loaded: form_helper
INFO - 2024-10-10 22:25:01 --> Helper loaded: my_helper
INFO - 2024-10-10 22:25:01 --> Database Driver Class Initialized
INFO - 2024-10-10 22:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:25:01 --> Controller Class Initialized
INFO - 2024-10-10 22:25:01 --> Final output sent to browser
DEBUG - 2024-10-10 22:25:01 --> Total execution time: 0.1342
INFO - 2024-10-10 22:25:11 --> Config Class Initialized
INFO - 2024-10-10 22:25:11 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:25:11 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:25:11 --> Utf8 Class Initialized
INFO - 2024-10-10 22:25:11 --> URI Class Initialized
INFO - 2024-10-10 22:25:11 --> Router Class Initialized
INFO - 2024-10-10 22:25:11 --> Output Class Initialized
INFO - 2024-10-10 22:25:11 --> Security Class Initialized
DEBUG - 2024-10-10 22:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:25:11 --> Input Class Initialized
INFO - 2024-10-10 22:25:11 --> Language Class Initialized
INFO - 2024-10-10 22:25:11 --> Language Class Initialized
INFO - 2024-10-10 22:25:11 --> Config Class Initialized
INFO - 2024-10-10 22:25:11 --> Loader Class Initialized
INFO - 2024-10-10 22:25:11 --> Helper loaded: url_helper
INFO - 2024-10-10 22:25:11 --> Helper loaded: file_helper
INFO - 2024-10-10 22:25:11 --> Helper loaded: form_helper
INFO - 2024-10-10 22:25:11 --> Helper loaded: my_helper
INFO - 2024-10-10 22:25:11 --> Database Driver Class Initialized
INFO - 2024-10-10 22:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:25:11 --> Controller Class Initialized
INFO - 2024-10-10 22:25:12 --> Final output sent to browser
DEBUG - 2024-10-10 22:25:12 --> Total execution time: 0.0984
INFO - 2024-10-10 22:25:20 --> Config Class Initialized
INFO - 2024-10-10 22:25:20 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:25:20 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:25:20 --> Utf8 Class Initialized
INFO - 2024-10-10 22:25:20 --> URI Class Initialized
INFO - 2024-10-10 22:25:20 --> Router Class Initialized
INFO - 2024-10-10 22:25:20 --> Output Class Initialized
INFO - 2024-10-10 22:25:20 --> Security Class Initialized
DEBUG - 2024-10-10 22:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:25:20 --> Input Class Initialized
INFO - 2024-10-10 22:25:20 --> Language Class Initialized
INFO - 2024-10-10 22:25:20 --> Language Class Initialized
INFO - 2024-10-10 22:25:20 --> Config Class Initialized
INFO - 2024-10-10 22:25:20 --> Loader Class Initialized
INFO - 2024-10-10 22:25:20 --> Helper loaded: url_helper
INFO - 2024-10-10 22:25:20 --> Helper loaded: file_helper
INFO - 2024-10-10 22:25:20 --> Helper loaded: form_helper
INFO - 2024-10-10 22:25:20 --> Helper loaded: my_helper
INFO - 2024-10-10 22:25:20 --> Database Driver Class Initialized
INFO - 2024-10-10 22:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:25:20 --> Controller Class Initialized
INFO - 2024-10-10 22:25:20 --> Final output sent to browser
DEBUG - 2024-10-10 22:25:20 --> Total execution time: 0.0893
INFO - 2024-10-10 22:25:23 --> Config Class Initialized
INFO - 2024-10-10 22:25:23 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:25:23 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:25:23 --> Utf8 Class Initialized
INFO - 2024-10-10 22:25:23 --> URI Class Initialized
INFO - 2024-10-10 22:25:23 --> Router Class Initialized
INFO - 2024-10-10 22:25:23 --> Output Class Initialized
INFO - 2024-10-10 22:25:23 --> Security Class Initialized
DEBUG - 2024-10-10 22:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:25:23 --> Input Class Initialized
INFO - 2024-10-10 22:25:23 --> Language Class Initialized
INFO - 2024-10-10 22:25:23 --> Language Class Initialized
INFO - 2024-10-10 22:25:23 --> Config Class Initialized
INFO - 2024-10-10 22:25:23 --> Loader Class Initialized
INFO - 2024-10-10 22:25:23 --> Helper loaded: url_helper
INFO - 2024-10-10 22:25:23 --> Helper loaded: file_helper
INFO - 2024-10-10 22:25:23 --> Helper loaded: form_helper
INFO - 2024-10-10 22:25:23 --> Helper loaded: my_helper
INFO - 2024-10-10 22:25:23 --> Database Driver Class Initialized
INFO - 2024-10-10 22:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:25:23 --> Controller Class Initialized
DEBUG - 2024-10-10 22:25:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-10 22:25:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:25:23 --> Final output sent to browser
DEBUG - 2024-10-10 22:25:23 --> Total execution time: 0.0514
INFO - 2024-10-10 22:25:25 --> Config Class Initialized
INFO - 2024-10-10 22:25:25 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:25:25 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:25:25 --> Utf8 Class Initialized
INFO - 2024-10-10 22:25:25 --> URI Class Initialized
INFO - 2024-10-10 22:25:25 --> Router Class Initialized
INFO - 2024-10-10 22:25:25 --> Output Class Initialized
INFO - 2024-10-10 22:25:25 --> Security Class Initialized
DEBUG - 2024-10-10 22:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:25:25 --> Input Class Initialized
INFO - 2024-10-10 22:25:25 --> Language Class Initialized
INFO - 2024-10-10 22:25:25 --> Language Class Initialized
INFO - 2024-10-10 22:25:25 --> Config Class Initialized
INFO - 2024-10-10 22:25:25 --> Loader Class Initialized
INFO - 2024-10-10 22:25:25 --> Helper loaded: url_helper
INFO - 2024-10-10 22:25:25 --> Helper loaded: file_helper
INFO - 2024-10-10 22:25:25 --> Helper loaded: form_helper
INFO - 2024-10-10 22:25:25 --> Helper loaded: my_helper
INFO - 2024-10-10 22:25:25 --> Database Driver Class Initialized
INFO - 2024-10-10 22:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:25:25 --> Controller Class Initialized
INFO - 2024-10-10 22:25:25 --> Helper loaded: cookie_helper
INFO - 2024-10-10 22:25:25 --> Config Class Initialized
INFO - 2024-10-10 22:25:25 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:25:25 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:25:25 --> Utf8 Class Initialized
INFO - 2024-10-10 22:25:25 --> URI Class Initialized
INFO - 2024-10-10 22:25:25 --> Router Class Initialized
INFO - 2024-10-10 22:25:25 --> Output Class Initialized
INFO - 2024-10-10 22:25:25 --> Security Class Initialized
DEBUG - 2024-10-10 22:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:25:25 --> Input Class Initialized
INFO - 2024-10-10 22:25:25 --> Language Class Initialized
INFO - 2024-10-10 22:25:25 --> Language Class Initialized
INFO - 2024-10-10 22:25:25 --> Config Class Initialized
INFO - 2024-10-10 22:25:25 --> Loader Class Initialized
INFO - 2024-10-10 22:25:25 --> Helper loaded: url_helper
INFO - 2024-10-10 22:25:25 --> Helper loaded: file_helper
INFO - 2024-10-10 22:25:25 --> Helper loaded: form_helper
INFO - 2024-10-10 22:25:25 --> Helper loaded: my_helper
INFO - 2024-10-10 22:25:25 --> Database Driver Class Initialized
INFO - 2024-10-10 22:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:25:25 --> Controller Class Initialized
INFO - 2024-10-10 22:25:25 --> Config Class Initialized
INFO - 2024-10-10 22:25:25 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:25:25 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:25:25 --> Utf8 Class Initialized
INFO - 2024-10-10 22:25:25 --> URI Class Initialized
INFO - 2024-10-10 22:25:25 --> Router Class Initialized
INFO - 2024-10-10 22:25:25 --> Output Class Initialized
INFO - 2024-10-10 22:25:25 --> Security Class Initialized
DEBUG - 2024-10-10 22:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:25:25 --> Input Class Initialized
INFO - 2024-10-10 22:25:25 --> Language Class Initialized
INFO - 2024-10-10 22:25:25 --> Language Class Initialized
INFO - 2024-10-10 22:25:25 --> Config Class Initialized
INFO - 2024-10-10 22:25:25 --> Loader Class Initialized
INFO - 2024-10-10 22:25:25 --> Helper loaded: url_helper
INFO - 2024-10-10 22:25:25 --> Helper loaded: file_helper
INFO - 2024-10-10 22:25:25 --> Helper loaded: form_helper
INFO - 2024-10-10 22:25:25 --> Helper loaded: my_helper
INFO - 2024-10-10 22:25:25 --> Database Driver Class Initialized
INFO - 2024-10-10 22:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:25:25 --> Controller Class Initialized
DEBUG - 2024-10-10 22:25:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-10 22:25:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:25:25 --> Final output sent to browser
DEBUG - 2024-10-10 22:25:25 --> Total execution time: 0.0336
INFO - 2024-10-10 22:25:33 --> Config Class Initialized
INFO - 2024-10-10 22:25:33 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:25:33 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:25:33 --> Utf8 Class Initialized
INFO - 2024-10-10 22:25:33 --> URI Class Initialized
INFO - 2024-10-10 22:25:33 --> Router Class Initialized
INFO - 2024-10-10 22:25:33 --> Output Class Initialized
INFO - 2024-10-10 22:25:33 --> Security Class Initialized
DEBUG - 2024-10-10 22:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:25:33 --> Input Class Initialized
INFO - 2024-10-10 22:25:33 --> Language Class Initialized
INFO - 2024-10-10 22:25:33 --> Language Class Initialized
INFO - 2024-10-10 22:25:33 --> Config Class Initialized
INFO - 2024-10-10 22:25:33 --> Loader Class Initialized
INFO - 2024-10-10 22:25:33 --> Helper loaded: url_helper
INFO - 2024-10-10 22:25:33 --> Helper loaded: file_helper
INFO - 2024-10-10 22:25:33 --> Helper loaded: form_helper
INFO - 2024-10-10 22:25:33 --> Helper loaded: my_helper
INFO - 2024-10-10 22:25:33 --> Database Driver Class Initialized
INFO - 2024-10-10 22:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:25:33 --> Controller Class Initialized
INFO - 2024-10-10 22:25:33 --> Helper loaded: cookie_helper
INFO - 2024-10-10 22:25:33 --> Final output sent to browser
DEBUG - 2024-10-10 22:25:33 --> Total execution time: 0.0345
INFO - 2024-10-10 22:25:34 --> Config Class Initialized
INFO - 2024-10-10 22:25:34 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:25:34 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:25:34 --> Utf8 Class Initialized
INFO - 2024-10-10 22:25:34 --> URI Class Initialized
INFO - 2024-10-10 22:25:34 --> Router Class Initialized
INFO - 2024-10-10 22:25:34 --> Output Class Initialized
INFO - 2024-10-10 22:25:34 --> Security Class Initialized
DEBUG - 2024-10-10 22:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:25:34 --> Input Class Initialized
INFO - 2024-10-10 22:25:34 --> Language Class Initialized
INFO - 2024-10-10 22:25:34 --> Language Class Initialized
INFO - 2024-10-10 22:25:34 --> Config Class Initialized
INFO - 2024-10-10 22:25:34 --> Loader Class Initialized
INFO - 2024-10-10 22:25:34 --> Helper loaded: url_helper
INFO - 2024-10-10 22:25:34 --> Helper loaded: file_helper
INFO - 2024-10-10 22:25:34 --> Helper loaded: form_helper
INFO - 2024-10-10 22:25:34 --> Helper loaded: my_helper
INFO - 2024-10-10 22:25:34 --> Database Driver Class Initialized
INFO - 2024-10-10 22:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:25:34 --> Controller Class Initialized
DEBUG - 2024-10-10 22:25:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-10 22:25:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:25:34 --> Final output sent to browser
DEBUG - 2024-10-10 22:25:34 --> Total execution time: 0.0325
INFO - 2024-10-10 22:25:38 --> Config Class Initialized
INFO - 2024-10-10 22:25:38 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:25:38 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:25:38 --> Utf8 Class Initialized
INFO - 2024-10-10 22:25:38 --> URI Class Initialized
INFO - 2024-10-10 22:25:38 --> Router Class Initialized
INFO - 2024-10-10 22:25:38 --> Output Class Initialized
INFO - 2024-10-10 22:25:38 --> Security Class Initialized
DEBUG - 2024-10-10 22:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:25:38 --> Input Class Initialized
INFO - 2024-10-10 22:25:38 --> Language Class Initialized
INFO - 2024-10-10 22:25:38 --> Language Class Initialized
INFO - 2024-10-10 22:25:38 --> Config Class Initialized
INFO - 2024-10-10 22:25:38 --> Loader Class Initialized
INFO - 2024-10-10 22:25:38 --> Helper loaded: url_helper
INFO - 2024-10-10 22:25:38 --> Helper loaded: file_helper
INFO - 2024-10-10 22:25:38 --> Helper loaded: form_helper
INFO - 2024-10-10 22:25:38 --> Helper loaded: my_helper
INFO - 2024-10-10 22:25:38 --> Database Driver Class Initialized
INFO - 2024-10-10 22:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:25:38 --> Controller Class Initialized
DEBUG - 2024-10-10 22:25:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-10 22:25:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:25:38 --> Final output sent to browser
DEBUG - 2024-10-10 22:25:38 --> Total execution time: 0.0318
INFO - 2024-10-10 22:25:40 --> Config Class Initialized
INFO - 2024-10-10 22:25:40 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:25:40 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:25:40 --> Utf8 Class Initialized
INFO - 2024-10-10 22:25:40 --> URI Class Initialized
INFO - 2024-10-10 22:25:40 --> Router Class Initialized
INFO - 2024-10-10 22:25:40 --> Output Class Initialized
INFO - 2024-10-10 22:25:40 --> Security Class Initialized
DEBUG - 2024-10-10 22:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:25:40 --> Input Class Initialized
INFO - 2024-10-10 22:25:40 --> Language Class Initialized
INFO - 2024-10-10 22:25:40 --> Language Class Initialized
INFO - 2024-10-10 22:25:40 --> Config Class Initialized
INFO - 2024-10-10 22:25:40 --> Loader Class Initialized
INFO - 2024-10-10 22:25:40 --> Helper loaded: url_helper
INFO - 2024-10-10 22:25:40 --> Helper loaded: file_helper
INFO - 2024-10-10 22:25:40 --> Helper loaded: form_helper
INFO - 2024-10-10 22:25:40 --> Helper loaded: my_helper
INFO - 2024-10-10 22:25:40 --> Database Driver Class Initialized
INFO - 2024-10-10 22:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:25:40 --> Controller Class Initialized
DEBUG - 2024-10-10 22:25:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 22:25:43 --> Final output sent to browser
DEBUG - 2024-10-10 22:25:43 --> Total execution time: 3.0235
INFO - 2024-10-10 22:25:58 --> Config Class Initialized
INFO - 2024-10-10 22:25:58 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:25:58 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:25:58 --> Utf8 Class Initialized
INFO - 2024-10-10 22:25:58 --> URI Class Initialized
INFO - 2024-10-10 22:25:58 --> Router Class Initialized
INFO - 2024-10-10 22:25:58 --> Output Class Initialized
INFO - 2024-10-10 22:25:58 --> Security Class Initialized
DEBUG - 2024-10-10 22:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:25:58 --> Input Class Initialized
INFO - 2024-10-10 22:25:58 --> Language Class Initialized
INFO - 2024-10-10 22:25:58 --> Language Class Initialized
INFO - 2024-10-10 22:25:58 --> Config Class Initialized
INFO - 2024-10-10 22:25:58 --> Loader Class Initialized
INFO - 2024-10-10 22:25:58 --> Helper loaded: url_helper
INFO - 2024-10-10 22:25:58 --> Helper loaded: file_helper
INFO - 2024-10-10 22:25:58 --> Helper loaded: form_helper
INFO - 2024-10-10 22:25:58 --> Helper loaded: my_helper
INFO - 2024-10-10 22:25:58 --> Database Driver Class Initialized
INFO - 2024-10-10 22:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:25:58 --> Controller Class Initialized
DEBUG - 2024-10-10 22:25:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 22:26:01 --> Final output sent to browser
DEBUG - 2024-10-10 22:26:01 --> Total execution time: 2.9491
INFO - 2024-10-10 22:26:08 --> Config Class Initialized
INFO - 2024-10-10 22:26:08 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:26:08 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:26:08 --> Utf8 Class Initialized
INFO - 2024-10-10 22:26:08 --> URI Class Initialized
INFO - 2024-10-10 22:26:08 --> Router Class Initialized
INFO - 2024-10-10 22:26:08 --> Output Class Initialized
INFO - 2024-10-10 22:26:08 --> Security Class Initialized
DEBUG - 2024-10-10 22:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:26:08 --> Input Class Initialized
INFO - 2024-10-10 22:26:08 --> Language Class Initialized
INFO - 2024-10-10 22:26:08 --> Language Class Initialized
INFO - 2024-10-10 22:26:08 --> Config Class Initialized
INFO - 2024-10-10 22:26:08 --> Loader Class Initialized
INFO - 2024-10-10 22:26:08 --> Helper loaded: url_helper
INFO - 2024-10-10 22:26:08 --> Helper loaded: file_helper
INFO - 2024-10-10 22:26:08 --> Helper loaded: form_helper
INFO - 2024-10-10 22:26:08 --> Helper loaded: my_helper
INFO - 2024-10-10 22:26:08 --> Database Driver Class Initialized
INFO - 2024-10-10 22:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:26:08 --> Controller Class Initialized
DEBUG - 2024-10-10 22:26:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 22:26:11 --> Final output sent to browser
DEBUG - 2024-10-10 22:26:11 --> Total execution time: 2.8604
INFO - 2024-10-10 22:26:18 --> Config Class Initialized
INFO - 2024-10-10 22:26:18 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:26:18 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:26:18 --> Utf8 Class Initialized
INFO - 2024-10-10 22:26:18 --> URI Class Initialized
INFO - 2024-10-10 22:26:18 --> Router Class Initialized
INFO - 2024-10-10 22:26:18 --> Output Class Initialized
INFO - 2024-10-10 22:26:18 --> Security Class Initialized
DEBUG - 2024-10-10 22:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:26:18 --> Input Class Initialized
INFO - 2024-10-10 22:26:18 --> Language Class Initialized
INFO - 2024-10-10 22:26:18 --> Language Class Initialized
INFO - 2024-10-10 22:26:18 --> Config Class Initialized
INFO - 2024-10-10 22:26:18 --> Loader Class Initialized
INFO - 2024-10-10 22:26:18 --> Helper loaded: url_helper
INFO - 2024-10-10 22:26:18 --> Helper loaded: file_helper
INFO - 2024-10-10 22:26:18 --> Helper loaded: form_helper
INFO - 2024-10-10 22:26:18 --> Helper loaded: my_helper
INFO - 2024-10-10 22:26:18 --> Database Driver Class Initialized
INFO - 2024-10-10 22:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:26:18 --> Controller Class Initialized
INFO - 2024-10-10 22:26:18 --> Helper loaded: cookie_helper
INFO - 2024-10-10 22:26:19 --> Config Class Initialized
INFO - 2024-10-10 22:26:19 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:26:19 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:26:19 --> Utf8 Class Initialized
INFO - 2024-10-10 22:26:19 --> URI Class Initialized
INFO - 2024-10-10 22:26:19 --> Router Class Initialized
INFO - 2024-10-10 22:26:19 --> Output Class Initialized
INFO - 2024-10-10 22:26:19 --> Security Class Initialized
DEBUG - 2024-10-10 22:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:26:19 --> Input Class Initialized
INFO - 2024-10-10 22:26:19 --> Language Class Initialized
INFO - 2024-10-10 22:26:19 --> Language Class Initialized
INFO - 2024-10-10 22:26:19 --> Config Class Initialized
INFO - 2024-10-10 22:26:19 --> Loader Class Initialized
INFO - 2024-10-10 22:26:19 --> Helper loaded: url_helper
INFO - 2024-10-10 22:26:19 --> Helper loaded: file_helper
INFO - 2024-10-10 22:26:19 --> Helper loaded: form_helper
INFO - 2024-10-10 22:26:19 --> Helper loaded: my_helper
INFO - 2024-10-10 22:26:19 --> Database Driver Class Initialized
INFO - 2024-10-10 22:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:26:19 --> Controller Class Initialized
INFO - 2024-10-10 22:26:19 --> Config Class Initialized
INFO - 2024-10-10 22:26:19 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:26:19 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:26:19 --> Utf8 Class Initialized
INFO - 2024-10-10 22:26:19 --> URI Class Initialized
INFO - 2024-10-10 22:26:19 --> Router Class Initialized
INFO - 2024-10-10 22:26:19 --> Output Class Initialized
INFO - 2024-10-10 22:26:19 --> Security Class Initialized
DEBUG - 2024-10-10 22:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:26:19 --> Input Class Initialized
INFO - 2024-10-10 22:26:19 --> Language Class Initialized
INFO - 2024-10-10 22:26:19 --> Language Class Initialized
INFO - 2024-10-10 22:26:19 --> Config Class Initialized
INFO - 2024-10-10 22:26:19 --> Loader Class Initialized
INFO - 2024-10-10 22:26:19 --> Helper loaded: url_helper
INFO - 2024-10-10 22:26:19 --> Helper loaded: file_helper
INFO - 2024-10-10 22:26:19 --> Helper loaded: form_helper
INFO - 2024-10-10 22:26:19 --> Helper loaded: my_helper
INFO - 2024-10-10 22:26:19 --> Database Driver Class Initialized
INFO - 2024-10-10 22:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:26:19 --> Controller Class Initialized
DEBUG - 2024-10-10 22:26:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-10 22:26:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:26:19 --> Final output sent to browser
DEBUG - 2024-10-10 22:26:19 --> Total execution time: 0.0307
INFO - 2024-10-10 22:26:29 --> Config Class Initialized
INFO - 2024-10-10 22:26:29 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:26:29 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:26:29 --> Utf8 Class Initialized
INFO - 2024-10-10 22:26:29 --> URI Class Initialized
INFO - 2024-10-10 22:26:29 --> Router Class Initialized
INFO - 2024-10-10 22:26:29 --> Output Class Initialized
INFO - 2024-10-10 22:26:29 --> Security Class Initialized
DEBUG - 2024-10-10 22:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:26:29 --> Input Class Initialized
INFO - 2024-10-10 22:26:29 --> Language Class Initialized
INFO - 2024-10-10 22:26:29 --> Language Class Initialized
INFO - 2024-10-10 22:26:29 --> Config Class Initialized
INFO - 2024-10-10 22:26:29 --> Loader Class Initialized
INFO - 2024-10-10 22:26:29 --> Helper loaded: url_helper
INFO - 2024-10-10 22:26:29 --> Helper loaded: file_helper
INFO - 2024-10-10 22:26:29 --> Helper loaded: form_helper
INFO - 2024-10-10 22:26:29 --> Helper loaded: my_helper
INFO - 2024-10-10 22:26:29 --> Database Driver Class Initialized
INFO - 2024-10-10 22:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:26:29 --> Controller Class Initialized
INFO - 2024-10-10 22:26:29 --> Helper loaded: cookie_helper
INFO - 2024-10-10 22:26:29 --> Final output sent to browser
DEBUG - 2024-10-10 22:26:29 --> Total execution time: 0.0307
INFO - 2024-10-10 22:26:29 --> Config Class Initialized
INFO - 2024-10-10 22:26:29 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:26:29 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:26:29 --> Utf8 Class Initialized
INFO - 2024-10-10 22:26:29 --> URI Class Initialized
INFO - 2024-10-10 22:26:29 --> Router Class Initialized
INFO - 2024-10-10 22:26:29 --> Output Class Initialized
INFO - 2024-10-10 22:26:29 --> Security Class Initialized
DEBUG - 2024-10-10 22:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:26:29 --> Input Class Initialized
INFO - 2024-10-10 22:26:29 --> Language Class Initialized
INFO - 2024-10-10 22:26:29 --> Language Class Initialized
INFO - 2024-10-10 22:26:29 --> Config Class Initialized
INFO - 2024-10-10 22:26:29 --> Loader Class Initialized
INFO - 2024-10-10 22:26:29 --> Helper loaded: url_helper
INFO - 2024-10-10 22:26:29 --> Helper loaded: file_helper
INFO - 2024-10-10 22:26:29 --> Helper loaded: form_helper
INFO - 2024-10-10 22:26:29 --> Helper loaded: my_helper
INFO - 2024-10-10 22:26:29 --> Database Driver Class Initialized
INFO - 2024-10-10 22:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:26:29 --> Controller Class Initialized
DEBUG - 2024-10-10 22:26:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-10 22:26:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:26:29 --> Final output sent to browser
DEBUG - 2024-10-10 22:26:29 --> Total execution time: 0.0382
INFO - 2024-10-10 22:26:33 --> Config Class Initialized
INFO - 2024-10-10 22:26:33 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:26:33 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:26:33 --> Utf8 Class Initialized
INFO - 2024-10-10 22:26:33 --> URI Class Initialized
INFO - 2024-10-10 22:26:33 --> Router Class Initialized
INFO - 2024-10-10 22:26:33 --> Output Class Initialized
INFO - 2024-10-10 22:26:33 --> Security Class Initialized
DEBUG - 2024-10-10 22:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:26:33 --> Input Class Initialized
INFO - 2024-10-10 22:26:33 --> Language Class Initialized
INFO - 2024-10-10 22:26:33 --> Language Class Initialized
INFO - 2024-10-10 22:26:33 --> Config Class Initialized
INFO - 2024-10-10 22:26:33 --> Loader Class Initialized
INFO - 2024-10-10 22:26:33 --> Helper loaded: url_helper
INFO - 2024-10-10 22:26:33 --> Helper loaded: file_helper
INFO - 2024-10-10 22:26:33 --> Helper loaded: form_helper
INFO - 2024-10-10 22:26:33 --> Helper loaded: my_helper
INFO - 2024-10-10 22:26:33 --> Database Driver Class Initialized
INFO - 2024-10-10 22:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:26:33 --> Controller Class Initialized
DEBUG - 2024-10-10 22:26:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-10 22:26:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:26:33 --> Final output sent to browser
DEBUG - 2024-10-10 22:26:33 --> Total execution time: 0.0334
INFO - 2024-10-10 22:26:36 --> Config Class Initialized
INFO - 2024-10-10 22:26:36 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:26:36 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:26:36 --> Utf8 Class Initialized
INFO - 2024-10-10 22:26:36 --> URI Class Initialized
INFO - 2024-10-10 22:26:36 --> Router Class Initialized
INFO - 2024-10-10 22:26:36 --> Output Class Initialized
INFO - 2024-10-10 22:26:37 --> Security Class Initialized
DEBUG - 2024-10-10 22:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:26:37 --> Input Class Initialized
INFO - 2024-10-10 22:26:37 --> Language Class Initialized
INFO - 2024-10-10 22:26:37 --> Language Class Initialized
INFO - 2024-10-10 22:26:37 --> Config Class Initialized
INFO - 2024-10-10 22:26:37 --> Loader Class Initialized
INFO - 2024-10-10 22:26:37 --> Helper loaded: url_helper
INFO - 2024-10-10 22:26:37 --> Helper loaded: file_helper
INFO - 2024-10-10 22:26:37 --> Helper loaded: form_helper
INFO - 2024-10-10 22:26:37 --> Helper loaded: my_helper
INFO - 2024-10-10 22:26:37 --> Database Driver Class Initialized
INFO - 2024-10-10 22:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:26:37 --> Controller Class Initialized
DEBUG - 2024-10-10 22:26:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-10 22:26:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:26:37 --> Final output sent to browser
DEBUG - 2024-10-10 22:26:37 --> Total execution time: 0.0409
INFO - 2024-10-10 22:26:37 --> Config Class Initialized
INFO - 2024-10-10 22:26:37 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:26:37 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:26:37 --> Utf8 Class Initialized
INFO - 2024-10-10 22:26:37 --> URI Class Initialized
INFO - 2024-10-10 22:26:37 --> Router Class Initialized
INFO - 2024-10-10 22:26:37 --> Output Class Initialized
INFO - 2024-10-10 22:26:37 --> Security Class Initialized
DEBUG - 2024-10-10 22:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:26:37 --> Input Class Initialized
INFO - 2024-10-10 22:26:37 --> Language Class Initialized
INFO - 2024-10-10 22:26:37 --> Language Class Initialized
INFO - 2024-10-10 22:26:37 --> Config Class Initialized
INFO - 2024-10-10 22:26:37 --> Loader Class Initialized
INFO - 2024-10-10 22:26:37 --> Helper loaded: url_helper
INFO - 2024-10-10 22:26:37 --> Helper loaded: file_helper
INFO - 2024-10-10 22:26:37 --> Helper loaded: form_helper
INFO - 2024-10-10 22:26:37 --> Helper loaded: my_helper
INFO - 2024-10-10 22:26:37 --> Database Driver Class Initialized
INFO - 2024-10-10 22:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:26:37 --> Controller Class Initialized
INFO - 2024-10-10 22:26:40 --> Config Class Initialized
INFO - 2024-10-10 22:26:40 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:26:40 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:26:40 --> Utf8 Class Initialized
INFO - 2024-10-10 22:26:40 --> URI Class Initialized
INFO - 2024-10-10 22:26:40 --> Router Class Initialized
INFO - 2024-10-10 22:26:40 --> Output Class Initialized
INFO - 2024-10-10 22:26:40 --> Security Class Initialized
DEBUG - 2024-10-10 22:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:26:40 --> Input Class Initialized
INFO - 2024-10-10 22:26:40 --> Language Class Initialized
INFO - 2024-10-10 22:26:40 --> Language Class Initialized
INFO - 2024-10-10 22:26:40 --> Config Class Initialized
INFO - 2024-10-10 22:26:40 --> Loader Class Initialized
INFO - 2024-10-10 22:26:40 --> Helper loaded: url_helper
INFO - 2024-10-10 22:26:40 --> Helper loaded: file_helper
INFO - 2024-10-10 22:26:40 --> Helper loaded: form_helper
INFO - 2024-10-10 22:26:40 --> Helper loaded: my_helper
INFO - 2024-10-10 22:26:40 --> Database Driver Class Initialized
INFO - 2024-10-10 22:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:26:40 --> Controller Class Initialized
INFO - 2024-10-10 22:26:40 --> Final output sent to browser
DEBUG - 2024-10-10 22:26:40 --> Total execution time: 0.0678
INFO - 2024-10-10 22:26:48 --> Config Class Initialized
INFO - 2024-10-10 22:26:48 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:26:48 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:26:48 --> Utf8 Class Initialized
INFO - 2024-10-10 22:26:48 --> URI Class Initialized
INFO - 2024-10-10 22:26:48 --> Router Class Initialized
INFO - 2024-10-10 22:26:48 --> Output Class Initialized
INFO - 2024-10-10 22:26:48 --> Security Class Initialized
DEBUG - 2024-10-10 22:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:26:48 --> Input Class Initialized
INFO - 2024-10-10 22:26:48 --> Language Class Initialized
INFO - 2024-10-10 22:26:48 --> Language Class Initialized
INFO - 2024-10-10 22:26:48 --> Config Class Initialized
INFO - 2024-10-10 22:26:48 --> Loader Class Initialized
INFO - 2024-10-10 22:26:48 --> Helper loaded: url_helper
INFO - 2024-10-10 22:26:48 --> Helper loaded: file_helper
INFO - 2024-10-10 22:26:48 --> Helper loaded: form_helper
INFO - 2024-10-10 22:26:48 --> Helper loaded: my_helper
INFO - 2024-10-10 22:26:48 --> Database Driver Class Initialized
INFO - 2024-10-10 22:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:26:48 --> Controller Class Initialized
INFO - 2024-10-10 22:26:48 --> Final output sent to browser
DEBUG - 2024-10-10 22:26:48 --> Total execution time: 0.0308
INFO - 2024-10-10 22:26:51 --> Config Class Initialized
INFO - 2024-10-10 22:26:51 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:26:51 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:26:51 --> Utf8 Class Initialized
INFO - 2024-10-10 22:26:51 --> URI Class Initialized
INFO - 2024-10-10 22:26:51 --> Router Class Initialized
INFO - 2024-10-10 22:26:51 --> Output Class Initialized
INFO - 2024-10-10 22:26:51 --> Security Class Initialized
DEBUG - 2024-10-10 22:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:26:51 --> Input Class Initialized
INFO - 2024-10-10 22:26:51 --> Language Class Initialized
INFO - 2024-10-10 22:26:51 --> Language Class Initialized
INFO - 2024-10-10 22:26:51 --> Config Class Initialized
INFO - 2024-10-10 22:26:51 --> Loader Class Initialized
INFO - 2024-10-10 22:26:51 --> Helper loaded: url_helper
INFO - 2024-10-10 22:26:51 --> Helper loaded: file_helper
INFO - 2024-10-10 22:26:51 --> Helper loaded: form_helper
INFO - 2024-10-10 22:26:51 --> Helper loaded: my_helper
INFO - 2024-10-10 22:26:51 --> Database Driver Class Initialized
INFO - 2024-10-10 22:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:26:51 --> Controller Class Initialized
INFO - 2024-10-10 22:26:51 --> Final output sent to browser
DEBUG - 2024-10-10 22:26:51 --> Total execution time: 0.0346
INFO - 2024-10-10 22:27:04 --> Config Class Initialized
INFO - 2024-10-10 22:27:04 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:27:04 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:27:04 --> Utf8 Class Initialized
INFO - 2024-10-10 22:27:04 --> URI Class Initialized
INFO - 2024-10-10 22:27:04 --> Router Class Initialized
INFO - 2024-10-10 22:27:04 --> Output Class Initialized
INFO - 2024-10-10 22:27:04 --> Security Class Initialized
DEBUG - 2024-10-10 22:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:27:04 --> Input Class Initialized
INFO - 2024-10-10 22:27:04 --> Language Class Initialized
INFO - 2024-10-10 22:27:04 --> Language Class Initialized
INFO - 2024-10-10 22:27:04 --> Config Class Initialized
INFO - 2024-10-10 22:27:04 --> Loader Class Initialized
INFO - 2024-10-10 22:27:04 --> Helper loaded: url_helper
INFO - 2024-10-10 22:27:04 --> Helper loaded: file_helper
INFO - 2024-10-10 22:27:04 --> Helper loaded: form_helper
INFO - 2024-10-10 22:27:04 --> Helper loaded: my_helper
INFO - 2024-10-10 22:27:04 --> Database Driver Class Initialized
INFO - 2024-10-10 22:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:27:04 --> Controller Class Initialized
INFO - 2024-10-10 22:27:04 --> Final output sent to browser
DEBUG - 2024-10-10 22:27:04 --> Total execution time: 0.0374
INFO - 2024-10-10 22:27:08 --> Config Class Initialized
INFO - 2024-10-10 22:27:08 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:27:08 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:27:08 --> Utf8 Class Initialized
INFO - 2024-10-10 22:27:08 --> URI Class Initialized
INFO - 2024-10-10 22:27:08 --> Router Class Initialized
INFO - 2024-10-10 22:27:08 --> Output Class Initialized
INFO - 2024-10-10 22:27:08 --> Security Class Initialized
DEBUG - 2024-10-10 22:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:27:08 --> Input Class Initialized
INFO - 2024-10-10 22:27:08 --> Language Class Initialized
INFO - 2024-10-10 22:27:08 --> Language Class Initialized
INFO - 2024-10-10 22:27:08 --> Config Class Initialized
INFO - 2024-10-10 22:27:08 --> Loader Class Initialized
INFO - 2024-10-10 22:27:08 --> Helper loaded: url_helper
INFO - 2024-10-10 22:27:08 --> Helper loaded: file_helper
INFO - 2024-10-10 22:27:08 --> Helper loaded: form_helper
INFO - 2024-10-10 22:27:08 --> Helper loaded: my_helper
INFO - 2024-10-10 22:27:08 --> Database Driver Class Initialized
INFO - 2024-10-10 22:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:27:08 --> Controller Class Initialized
DEBUG - 2024-10-10 22:27:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-10 22:27:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:27:08 --> Final output sent to browser
DEBUG - 2024-10-10 22:27:08 --> Total execution time: 0.0420
INFO - 2024-10-10 22:27:09 --> Config Class Initialized
INFO - 2024-10-10 22:27:09 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:27:09 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:27:09 --> Utf8 Class Initialized
INFO - 2024-10-10 22:27:09 --> URI Class Initialized
INFO - 2024-10-10 22:27:09 --> Router Class Initialized
INFO - 2024-10-10 22:27:09 --> Output Class Initialized
INFO - 2024-10-10 22:27:09 --> Security Class Initialized
DEBUG - 2024-10-10 22:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:27:09 --> Input Class Initialized
INFO - 2024-10-10 22:27:09 --> Language Class Initialized
INFO - 2024-10-10 22:27:10 --> Language Class Initialized
INFO - 2024-10-10 22:27:10 --> Config Class Initialized
INFO - 2024-10-10 22:27:10 --> Loader Class Initialized
INFO - 2024-10-10 22:27:10 --> Helper loaded: url_helper
INFO - 2024-10-10 22:27:10 --> Helper loaded: file_helper
INFO - 2024-10-10 22:27:10 --> Helper loaded: form_helper
INFO - 2024-10-10 22:27:10 --> Helper loaded: my_helper
INFO - 2024-10-10 22:27:10 --> Database Driver Class Initialized
INFO - 2024-10-10 22:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:27:10 --> Controller Class Initialized
DEBUG - 2024-10-10 22:27:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-10 22:27:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:27:10 --> Final output sent to browser
DEBUG - 2024-10-10 22:27:10 --> Total execution time: 0.0841
INFO - 2024-10-10 22:27:13 --> Config Class Initialized
INFO - 2024-10-10 22:27:13 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:27:13 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:27:13 --> Utf8 Class Initialized
INFO - 2024-10-10 22:27:13 --> URI Class Initialized
INFO - 2024-10-10 22:27:13 --> Router Class Initialized
INFO - 2024-10-10 22:27:13 --> Output Class Initialized
INFO - 2024-10-10 22:27:13 --> Security Class Initialized
DEBUG - 2024-10-10 22:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:27:13 --> Input Class Initialized
INFO - 2024-10-10 22:27:13 --> Language Class Initialized
INFO - 2024-10-10 22:27:13 --> Language Class Initialized
INFO - 2024-10-10 22:27:13 --> Config Class Initialized
INFO - 2024-10-10 22:27:13 --> Loader Class Initialized
INFO - 2024-10-10 22:27:13 --> Helper loaded: url_helper
INFO - 2024-10-10 22:27:13 --> Helper loaded: file_helper
INFO - 2024-10-10 22:27:13 --> Helper loaded: form_helper
INFO - 2024-10-10 22:27:13 --> Helper loaded: my_helper
INFO - 2024-10-10 22:27:13 --> Database Driver Class Initialized
INFO - 2024-10-10 22:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:27:13 --> Controller Class Initialized
INFO - 2024-10-10 22:27:13 --> Final output sent to browser
DEBUG - 2024-10-10 22:27:13 --> Total execution time: 0.0329
INFO - 2024-10-10 22:27:24 --> Config Class Initialized
INFO - 2024-10-10 22:27:24 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:27:24 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:27:24 --> Utf8 Class Initialized
INFO - 2024-10-10 22:27:24 --> URI Class Initialized
INFO - 2024-10-10 22:27:24 --> Router Class Initialized
INFO - 2024-10-10 22:27:24 --> Output Class Initialized
INFO - 2024-10-10 22:27:24 --> Security Class Initialized
DEBUG - 2024-10-10 22:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:27:24 --> Input Class Initialized
INFO - 2024-10-10 22:27:24 --> Language Class Initialized
INFO - 2024-10-10 22:27:24 --> Language Class Initialized
INFO - 2024-10-10 22:27:24 --> Config Class Initialized
INFO - 2024-10-10 22:27:24 --> Loader Class Initialized
INFO - 2024-10-10 22:27:24 --> Helper loaded: url_helper
INFO - 2024-10-10 22:27:24 --> Helper loaded: file_helper
INFO - 2024-10-10 22:27:24 --> Helper loaded: form_helper
INFO - 2024-10-10 22:27:24 --> Helper loaded: my_helper
INFO - 2024-10-10 22:27:24 --> Database Driver Class Initialized
INFO - 2024-10-10 22:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:27:24 --> Controller Class Initialized
DEBUG - 2024-10-10 22:27:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 22:27:27 --> Config Class Initialized
INFO - 2024-10-10 22:27:27 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:27:27 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:27:27 --> Utf8 Class Initialized
INFO - 2024-10-10 22:27:27 --> URI Class Initialized
INFO - 2024-10-10 22:27:27 --> Router Class Initialized
INFO - 2024-10-10 22:27:27 --> Output Class Initialized
INFO - 2024-10-10 22:27:27 --> Security Class Initialized
DEBUG - 2024-10-10 22:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:27:27 --> Input Class Initialized
INFO - 2024-10-10 22:27:27 --> Language Class Initialized
INFO - 2024-10-10 22:27:27 --> Language Class Initialized
INFO - 2024-10-10 22:27:27 --> Config Class Initialized
INFO - 2024-10-10 22:27:27 --> Loader Class Initialized
INFO - 2024-10-10 22:27:27 --> Helper loaded: url_helper
INFO - 2024-10-10 22:27:27 --> Helper loaded: file_helper
INFO - 2024-10-10 22:27:27 --> Helper loaded: form_helper
INFO - 2024-10-10 22:27:27 --> Helper loaded: my_helper
INFO - 2024-10-10 22:27:27 --> Database Driver Class Initialized
INFO - 2024-10-10 22:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:27:27 --> Controller Class Initialized
DEBUG - 2024-10-10 22:27:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 22:27:27 --> Final output sent to browser
DEBUG - 2024-10-10 22:27:27 --> Total execution time: 3.2020
INFO - 2024-10-10 22:27:30 --> Final output sent to browser
DEBUG - 2024-10-10 22:27:30 --> Total execution time: 2.9487
INFO - 2024-10-10 22:27:48 --> Config Class Initialized
INFO - 2024-10-10 22:27:48 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:27:48 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:27:48 --> Utf8 Class Initialized
INFO - 2024-10-10 22:27:48 --> URI Class Initialized
INFO - 2024-10-10 22:27:48 --> Router Class Initialized
INFO - 2024-10-10 22:27:48 --> Output Class Initialized
INFO - 2024-10-10 22:27:48 --> Security Class Initialized
DEBUG - 2024-10-10 22:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:27:48 --> Input Class Initialized
INFO - 2024-10-10 22:27:48 --> Language Class Initialized
INFO - 2024-10-10 22:27:48 --> Language Class Initialized
INFO - 2024-10-10 22:27:48 --> Config Class Initialized
INFO - 2024-10-10 22:27:48 --> Loader Class Initialized
INFO - 2024-10-10 22:27:48 --> Helper loaded: url_helper
INFO - 2024-10-10 22:27:48 --> Helper loaded: file_helper
INFO - 2024-10-10 22:27:48 --> Helper loaded: form_helper
INFO - 2024-10-10 22:27:48 --> Helper loaded: my_helper
INFO - 2024-10-10 22:27:48 --> Database Driver Class Initialized
INFO - 2024-10-10 22:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:27:48 --> Controller Class Initialized
INFO - 2024-10-10 22:27:48 --> Final output sent to browser
DEBUG - 2024-10-10 22:27:48 --> Total execution time: 0.0819
INFO - 2024-10-10 22:27:53 --> Config Class Initialized
INFO - 2024-10-10 22:27:53 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:27:53 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:27:53 --> Utf8 Class Initialized
INFO - 2024-10-10 22:27:53 --> URI Class Initialized
DEBUG - 2024-10-10 22:27:53 --> No URI present. Default controller set.
INFO - 2024-10-10 22:27:53 --> Router Class Initialized
INFO - 2024-10-10 22:27:53 --> Output Class Initialized
INFO - 2024-10-10 22:27:53 --> Security Class Initialized
DEBUG - 2024-10-10 22:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:27:53 --> Input Class Initialized
INFO - 2024-10-10 22:27:53 --> Language Class Initialized
INFO - 2024-10-10 22:27:53 --> Language Class Initialized
INFO - 2024-10-10 22:27:53 --> Config Class Initialized
INFO - 2024-10-10 22:27:53 --> Loader Class Initialized
INFO - 2024-10-10 22:27:53 --> Helper loaded: url_helper
INFO - 2024-10-10 22:27:53 --> Helper loaded: file_helper
INFO - 2024-10-10 22:27:53 --> Helper loaded: form_helper
INFO - 2024-10-10 22:27:53 --> Helper loaded: my_helper
INFO - 2024-10-10 22:27:53 --> Database Driver Class Initialized
INFO - 2024-10-10 22:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:27:53 --> Controller Class Initialized
DEBUG - 2024-10-10 22:27:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-10 22:27:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:27:53 --> Final output sent to browser
DEBUG - 2024-10-10 22:27:53 --> Total execution time: 0.0602
INFO - 2024-10-10 22:27:54 --> Config Class Initialized
INFO - 2024-10-10 22:27:54 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:27:54 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:27:54 --> Utf8 Class Initialized
INFO - 2024-10-10 22:27:54 --> URI Class Initialized
INFO - 2024-10-10 22:27:54 --> Router Class Initialized
INFO - 2024-10-10 22:27:54 --> Output Class Initialized
INFO - 2024-10-10 22:27:54 --> Security Class Initialized
DEBUG - 2024-10-10 22:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:27:54 --> Input Class Initialized
INFO - 2024-10-10 22:27:54 --> Language Class Initialized
INFO - 2024-10-10 22:27:54 --> Language Class Initialized
INFO - 2024-10-10 22:27:54 --> Config Class Initialized
INFO - 2024-10-10 22:27:54 --> Loader Class Initialized
INFO - 2024-10-10 22:27:54 --> Helper loaded: url_helper
INFO - 2024-10-10 22:27:54 --> Helper loaded: file_helper
INFO - 2024-10-10 22:27:54 --> Helper loaded: form_helper
INFO - 2024-10-10 22:27:54 --> Helper loaded: my_helper
INFO - 2024-10-10 22:27:54 --> Database Driver Class Initialized
INFO - 2024-10-10 22:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:27:54 --> Controller Class Initialized
INFO - 2024-10-10 22:27:54 --> Helper loaded: cookie_helper
INFO - 2024-10-10 22:27:55 --> Config Class Initialized
INFO - 2024-10-10 22:27:55 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:27:55 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:27:55 --> Utf8 Class Initialized
INFO - 2024-10-10 22:27:55 --> URI Class Initialized
INFO - 2024-10-10 22:27:55 --> Router Class Initialized
INFO - 2024-10-10 22:27:55 --> Output Class Initialized
INFO - 2024-10-10 22:27:55 --> Security Class Initialized
DEBUG - 2024-10-10 22:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:27:55 --> Input Class Initialized
INFO - 2024-10-10 22:27:55 --> Language Class Initialized
INFO - 2024-10-10 22:27:55 --> Language Class Initialized
INFO - 2024-10-10 22:27:55 --> Config Class Initialized
INFO - 2024-10-10 22:27:55 --> Loader Class Initialized
INFO - 2024-10-10 22:27:55 --> Helper loaded: url_helper
INFO - 2024-10-10 22:27:55 --> Helper loaded: file_helper
INFO - 2024-10-10 22:27:55 --> Helper loaded: form_helper
INFO - 2024-10-10 22:27:55 --> Helper loaded: my_helper
INFO - 2024-10-10 22:27:55 --> Database Driver Class Initialized
INFO - 2024-10-10 22:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:27:55 --> Controller Class Initialized
INFO - 2024-10-10 22:27:55 --> Config Class Initialized
INFO - 2024-10-10 22:27:55 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:27:55 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:27:55 --> Utf8 Class Initialized
INFO - 2024-10-10 22:27:55 --> URI Class Initialized
INFO - 2024-10-10 22:27:55 --> Router Class Initialized
INFO - 2024-10-10 22:27:55 --> Output Class Initialized
INFO - 2024-10-10 22:27:55 --> Security Class Initialized
DEBUG - 2024-10-10 22:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:27:55 --> Input Class Initialized
INFO - 2024-10-10 22:27:55 --> Language Class Initialized
INFO - 2024-10-10 22:27:55 --> Language Class Initialized
INFO - 2024-10-10 22:27:55 --> Config Class Initialized
INFO - 2024-10-10 22:27:55 --> Loader Class Initialized
INFO - 2024-10-10 22:27:55 --> Helper loaded: url_helper
INFO - 2024-10-10 22:27:55 --> Helper loaded: file_helper
INFO - 2024-10-10 22:27:55 --> Helper loaded: form_helper
INFO - 2024-10-10 22:27:55 --> Helper loaded: my_helper
INFO - 2024-10-10 22:27:55 --> Database Driver Class Initialized
INFO - 2024-10-10 22:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:27:55 --> Controller Class Initialized
DEBUG - 2024-10-10 22:27:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-10 22:27:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:27:55 --> Final output sent to browser
DEBUG - 2024-10-10 22:27:55 --> Total execution time: 0.0346
INFO - 2024-10-10 22:28:01 --> Config Class Initialized
INFO - 2024-10-10 22:28:01 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:28:01 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:28:01 --> Utf8 Class Initialized
INFO - 2024-10-10 22:28:01 --> URI Class Initialized
INFO - 2024-10-10 22:28:01 --> Router Class Initialized
INFO - 2024-10-10 22:28:01 --> Output Class Initialized
INFO - 2024-10-10 22:28:01 --> Security Class Initialized
DEBUG - 2024-10-10 22:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:28:01 --> Input Class Initialized
INFO - 2024-10-10 22:28:01 --> Language Class Initialized
INFO - 2024-10-10 22:28:01 --> Language Class Initialized
INFO - 2024-10-10 22:28:01 --> Config Class Initialized
INFO - 2024-10-10 22:28:01 --> Loader Class Initialized
INFO - 2024-10-10 22:28:01 --> Helper loaded: url_helper
INFO - 2024-10-10 22:28:01 --> Helper loaded: file_helper
INFO - 2024-10-10 22:28:01 --> Helper loaded: form_helper
INFO - 2024-10-10 22:28:01 --> Helper loaded: my_helper
INFO - 2024-10-10 22:28:01 --> Database Driver Class Initialized
INFO - 2024-10-10 22:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:28:01 --> Controller Class Initialized
INFO - 2024-10-10 22:28:01 --> Helper loaded: cookie_helper
INFO - 2024-10-10 22:28:01 --> Final output sent to browser
DEBUG - 2024-10-10 22:28:01 --> Total execution time: 0.2396
INFO - 2024-10-10 22:28:01 --> Config Class Initialized
INFO - 2024-10-10 22:28:01 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:28:01 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:28:01 --> Utf8 Class Initialized
INFO - 2024-10-10 22:28:01 --> URI Class Initialized
INFO - 2024-10-10 22:28:01 --> Router Class Initialized
INFO - 2024-10-10 22:28:01 --> Output Class Initialized
INFO - 2024-10-10 22:28:01 --> Security Class Initialized
DEBUG - 2024-10-10 22:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:28:01 --> Input Class Initialized
INFO - 2024-10-10 22:28:01 --> Language Class Initialized
INFO - 2024-10-10 22:28:01 --> Language Class Initialized
INFO - 2024-10-10 22:28:01 --> Config Class Initialized
INFO - 2024-10-10 22:28:01 --> Loader Class Initialized
INFO - 2024-10-10 22:28:01 --> Helper loaded: url_helper
INFO - 2024-10-10 22:28:01 --> Helper loaded: file_helper
INFO - 2024-10-10 22:28:01 --> Helper loaded: form_helper
INFO - 2024-10-10 22:28:01 --> Helper loaded: my_helper
INFO - 2024-10-10 22:28:01 --> Database Driver Class Initialized
INFO - 2024-10-10 22:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:28:01 --> Controller Class Initialized
DEBUG - 2024-10-10 22:28:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-10 22:28:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:28:01 --> Final output sent to browser
DEBUG - 2024-10-10 22:28:01 --> Total execution time: 0.0375
INFO - 2024-10-10 22:28:05 --> Config Class Initialized
INFO - 2024-10-10 22:28:05 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:28:05 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:28:05 --> Utf8 Class Initialized
INFO - 2024-10-10 22:28:05 --> URI Class Initialized
INFO - 2024-10-10 22:28:05 --> Router Class Initialized
INFO - 2024-10-10 22:28:05 --> Output Class Initialized
INFO - 2024-10-10 22:28:05 --> Security Class Initialized
DEBUG - 2024-10-10 22:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:28:05 --> Input Class Initialized
INFO - 2024-10-10 22:28:05 --> Language Class Initialized
INFO - 2024-10-10 22:28:05 --> Language Class Initialized
INFO - 2024-10-10 22:28:05 --> Config Class Initialized
INFO - 2024-10-10 22:28:05 --> Loader Class Initialized
INFO - 2024-10-10 22:28:05 --> Helper loaded: url_helper
INFO - 2024-10-10 22:28:05 --> Helper loaded: file_helper
INFO - 2024-10-10 22:28:05 --> Helper loaded: form_helper
INFO - 2024-10-10 22:28:05 --> Helper loaded: my_helper
INFO - 2024-10-10 22:28:05 --> Database Driver Class Initialized
INFO - 2024-10-10 22:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:28:05 --> Controller Class Initialized
DEBUG - 2024-10-10 22:28:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-10 22:28:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:28:05 --> Final output sent to browser
DEBUG - 2024-10-10 22:28:05 --> Total execution time: 0.0676
INFO - 2024-10-10 22:28:08 --> Config Class Initialized
INFO - 2024-10-10 22:28:08 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:28:08 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:28:08 --> Utf8 Class Initialized
INFO - 2024-10-10 22:28:08 --> URI Class Initialized
INFO - 2024-10-10 22:28:08 --> Router Class Initialized
INFO - 2024-10-10 22:28:08 --> Output Class Initialized
INFO - 2024-10-10 22:28:08 --> Security Class Initialized
DEBUG - 2024-10-10 22:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:28:08 --> Input Class Initialized
INFO - 2024-10-10 22:28:08 --> Language Class Initialized
INFO - 2024-10-10 22:28:08 --> Language Class Initialized
INFO - 2024-10-10 22:28:08 --> Config Class Initialized
INFO - 2024-10-10 22:28:08 --> Loader Class Initialized
INFO - 2024-10-10 22:28:08 --> Helper loaded: url_helper
INFO - 2024-10-10 22:28:08 --> Helper loaded: file_helper
INFO - 2024-10-10 22:28:08 --> Helper loaded: form_helper
INFO - 2024-10-10 22:28:08 --> Helper loaded: my_helper
INFO - 2024-10-10 22:28:08 --> Database Driver Class Initialized
INFO - 2024-10-10 22:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:28:08 --> Controller Class Initialized
DEBUG - 2024-10-10 22:28:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 22:28:11 --> Final output sent to browser
DEBUG - 2024-10-10 22:28:11 --> Total execution time: 2.9854
INFO - 2024-10-10 22:28:17 --> Config Class Initialized
INFO - 2024-10-10 22:28:17 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:28:17 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:28:17 --> Utf8 Class Initialized
INFO - 2024-10-10 22:28:17 --> URI Class Initialized
INFO - 2024-10-10 22:28:17 --> Router Class Initialized
INFO - 2024-10-10 22:28:17 --> Output Class Initialized
INFO - 2024-10-10 22:28:17 --> Security Class Initialized
DEBUG - 2024-10-10 22:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:28:17 --> Input Class Initialized
INFO - 2024-10-10 22:28:17 --> Language Class Initialized
INFO - 2024-10-10 22:28:17 --> Language Class Initialized
INFO - 2024-10-10 22:28:17 --> Config Class Initialized
INFO - 2024-10-10 22:28:17 --> Loader Class Initialized
INFO - 2024-10-10 22:28:17 --> Helper loaded: url_helper
INFO - 2024-10-10 22:28:17 --> Helper loaded: file_helper
INFO - 2024-10-10 22:28:17 --> Helper loaded: form_helper
INFO - 2024-10-10 22:28:17 --> Helper loaded: my_helper
INFO - 2024-10-10 22:28:17 --> Database Driver Class Initialized
INFO - 2024-10-10 22:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:28:17 --> Controller Class Initialized
INFO - 2024-10-10 22:28:17 --> Helper loaded: cookie_helper
INFO - 2024-10-10 22:28:17 --> Config Class Initialized
INFO - 2024-10-10 22:28:17 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:28:17 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:28:17 --> Utf8 Class Initialized
INFO - 2024-10-10 22:28:17 --> URI Class Initialized
INFO - 2024-10-10 22:28:17 --> Router Class Initialized
INFO - 2024-10-10 22:28:17 --> Output Class Initialized
INFO - 2024-10-10 22:28:17 --> Security Class Initialized
DEBUG - 2024-10-10 22:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:28:17 --> Input Class Initialized
INFO - 2024-10-10 22:28:17 --> Language Class Initialized
INFO - 2024-10-10 22:28:17 --> Language Class Initialized
INFO - 2024-10-10 22:28:17 --> Config Class Initialized
INFO - 2024-10-10 22:28:17 --> Loader Class Initialized
INFO - 2024-10-10 22:28:17 --> Helper loaded: url_helper
INFO - 2024-10-10 22:28:17 --> Helper loaded: file_helper
INFO - 2024-10-10 22:28:17 --> Helper loaded: form_helper
INFO - 2024-10-10 22:28:17 --> Helper loaded: my_helper
INFO - 2024-10-10 22:28:17 --> Database Driver Class Initialized
INFO - 2024-10-10 22:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:28:17 --> Controller Class Initialized
INFO - 2024-10-10 22:28:17 --> Config Class Initialized
INFO - 2024-10-10 22:28:17 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:28:17 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:28:17 --> Utf8 Class Initialized
INFO - 2024-10-10 22:28:17 --> URI Class Initialized
INFO - 2024-10-10 22:28:17 --> Router Class Initialized
INFO - 2024-10-10 22:28:17 --> Output Class Initialized
INFO - 2024-10-10 22:28:17 --> Security Class Initialized
DEBUG - 2024-10-10 22:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:28:17 --> Input Class Initialized
INFO - 2024-10-10 22:28:17 --> Language Class Initialized
INFO - 2024-10-10 22:28:17 --> Language Class Initialized
INFO - 2024-10-10 22:28:17 --> Config Class Initialized
INFO - 2024-10-10 22:28:17 --> Loader Class Initialized
INFO - 2024-10-10 22:28:17 --> Helper loaded: url_helper
INFO - 2024-10-10 22:28:17 --> Helper loaded: file_helper
INFO - 2024-10-10 22:28:17 --> Helper loaded: form_helper
INFO - 2024-10-10 22:28:17 --> Helper loaded: my_helper
INFO - 2024-10-10 22:28:17 --> Database Driver Class Initialized
INFO - 2024-10-10 22:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:28:17 --> Controller Class Initialized
DEBUG - 2024-10-10 22:28:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-10 22:28:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:28:17 --> Final output sent to browser
DEBUG - 2024-10-10 22:28:17 --> Total execution time: 0.0421
INFO - 2024-10-10 22:28:25 --> Config Class Initialized
INFO - 2024-10-10 22:28:25 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:28:25 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:28:25 --> Utf8 Class Initialized
INFO - 2024-10-10 22:28:25 --> URI Class Initialized
INFO - 2024-10-10 22:28:25 --> Router Class Initialized
INFO - 2024-10-10 22:28:25 --> Output Class Initialized
INFO - 2024-10-10 22:28:25 --> Security Class Initialized
DEBUG - 2024-10-10 22:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:28:25 --> Input Class Initialized
INFO - 2024-10-10 22:28:25 --> Language Class Initialized
INFO - 2024-10-10 22:28:25 --> Language Class Initialized
INFO - 2024-10-10 22:28:25 --> Config Class Initialized
INFO - 2024-10-10 22:28:25 --> Loader Class Initialized
INFO - 2024-10-10 22:28:25 --> Helper loaded: url_helper
INFO - 2024-10-10 22:28:25 --> Helper loaded: file_helper
INFO - 2024-10-10 22:28:25 --> Helper loaded: form_helper
INFO - 2024-10-10 22:28:25 --> Helper loaded: my_helper
INFO - 2024-10-10 22:28:25 --> Database Driver Class Initialized
INFO - 2024-10-10 22:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:28:25 --> Controller Class Initialized
INFO - 2024-10-10 22:28:25 --> Helper loaded: cookie_helper
INFO - 2024-10-10 22:28:25 --> Final output sent to browser
DEBUG - 2024-10-10 22:28:25 --> Total execution time: 0.0331
INFO - 2024-10-10 22:28:25 --> Config Class Initialized
INFO - 2024-10-10 22:28:25 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:28:25 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:28:25 --> Utf8 Class Initialized
INFO - 2024-10-10 22:28:25 --> URI Class Initialized
INFO - 2024-10-10 22:28:25 --> Router Class Initialized
INFO - 2024-10-10 22:28:25 --> Output Class Initialized
INFO - 2024-10-10 22:28:25 --> Security Class Initialized
DEBUG - 2024-10-10 22:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:28:25 --> Input Class Initialized
INFO - 2024-10-10 22:28:25 --> Language Class Initialized
INFO - 2024-10-10 22:28:25 --> Language Class Initialized
INFO - 2024-10-10 22:28:25 --> Config Class Initialized
INFO - 2024-10-10 22:28:25 --> Loader Class Initialized
INFO - 2024-10-10 22:28:25 --> Helper loaded: url_helper
INFO - 2024-10-10 22:28:25 --> Helper loaded: file_helper
INFO - 2024-10-10 22:28:25 --> Helper loaded: form_helper
INFO - 2024-10-10 22:28:25 --> Helper loaded: my_helper
INFO - 2024-10-10 22:28:25 --> Database Driver Class Initialized
INFO - 2024-10-10 22:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:28:25 --> Controller Class Initialized
DEBUG - 2024-10-10 22:28:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-10 22:28:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:28:25 --> Final output sent to browser
DEBUG - 2024-10-10 22:28:25 --> Total execution time: 0.0329
INFO - 2024-10-10 22:28:27 --> Config Class Initialized
INFO - 2024-10-10 22:28:27 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:28:27 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:28:27 --> Utf8 Class Initialized
INFO - 2024-10-10 22:28:27 --> URI Class Initialized
INFO - 2024-10-10 22:28:27 --> Router Class Initialized
INFO - 2024-10-10 22:28:27 --> Output Class Initialized
INFO - 2024-10-10 22:28:27 --> Security Class Initialized
DEBUG - 2024-10-10 22:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:28:27 --> Input Class Initialized
INFO - 2024-10-10 22:28:27 --> Language Class Initialized
INFO - 2024-10-10 22:28:27 --> Language Class Initialized
INFO - 2024-10-10 22:28:27 --> Config Class Initialized
INFO - 2024-10-10 22:28:27 --> Loader Class Initialized
INFO - 2024-10-10 22:28:27 --> Helper loaded: url_helper
INFO - 2024-10-10 22:28:27 --> Helper loaded: file_helper
INFO - 2024-10-10 22:28:27 --> Helper loaded: form_helper
INFO - 2024-10-10 22:28:27 --> Helper loaded: my_helper
INFO - 2024-10-10 22:28:27 --> Database Driver Class Initialized
INFO - 2024-10-10 22:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:28:27 --> Controller Class Initialized
DEBUG - 2024-10-10 22:28:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 22:28:29 --> Config Class Initialized
INFO - 2024-10-10 22:28:29 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:28:29 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:28:29 --> Utf8 Class Initialized
INFO - 2024-10-10 22:28:29 --> URI Class Initialized
INFO - 2024-10-10 22:28:29 --> Router Class Initialized
INFO - 2024-10-10 22:28:29 --> Output Class Initialized
INFO - 2024-10-10 22:28:29 --> Security Class Initialized
DEBUG - 2024-10-10 22:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:28:29 --> Input Class Initialized
INFO - 2024-10-10 22:28:29 --> Language Class Initialized
INFO - 2024-10-10 22:28:29 --> Language Class Initialized
INFO - 2024-10-10 22:28:29 --> Config Class Initialized
INFO - 2024-10-10 22:28:29 --> Loader Class Initialized
INFO - 2024-10-10 22:28:29 --> Helper loaded: url_helper
INFO - 2024-10-10 22:28:29 --> Helper loaded: file_helper
INFO - 2024-10-10 22:28:29 --> Helper loaded: form_helper
INFO - 2024-10-10 22:28:29 --> Helper loaded: my_helper
INFO - 2024-10-10 22:28:29 --> Database Driver Class Initialized
INFO - 2024-10-10 22:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:28:29 --> Controller Class Initialized
DEBUG - 2024-10-10 22:28:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-10 22:28:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:28:29 --> Final output sent to browser
DEBUG - 2024-10-10 22:28:29 --> Total execution time: 0.0636
INFO - 2024-10-10 22:28:30 --> Config Class Initialized
INFO - 2024-10-10 22:28:30 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:28:30 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:28:30 --> Utf8 Class Initialized
INFO - 2024-10-10 22:28:30 --> URI Class Initialized
INFO - 2024-10-10 22:28:30 --> Router Class Initialized
INFO - 2024-10-10 22:28:30 --> Output Class Initialized
INFO - 2024-10-10 22:28:30 --> Security Class Initialized
DEBUG - 2024-10-10 22:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:28:30 --> Input Class Initialized
INFO - 2024-10-10 22:28:30 --> Language Class Initialized
INFO - 2024-10-10 22:28:30 --> Language Class Initialized
INFO - 2024-10-10 22:28:30 --> Config Class Initialized
INFO - 2024-10-10 22:28:30 --> Loader Class Initialized
INFO - 2024-10-10 22:28:30 --> Helper loaded: url_helper
INFO - 2024-10-10 22:28:30 --> Helper loaded: file_helper
INFO - 2024-10-10 22:28:30 --> Helper loaded: form_helper
INFO - 2024-10-10 22:28:30 --> Helper loaded: my_helper
INFO - 2024-10-10 22:28:30 --> Database Driver Class Initialized
INFO - 2024-10-10 22:28:30 --> Final output sent to browser
DEBUG - 2024-10-10 22:28:30 --> Total execution time: 3.1118
INFO - 2024-10-10 22:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:28:30 --> Controller Class Initialized
DEBUG - 2024-10-10 22:28:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 22:28:31 --> Config Class Initialized
INFO - 2024-10-10 22:28:31 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:28:31 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:28:31 --> Utf8 Class Initialized
INFO - 2024-10-10 22:28:31 --> URI Class Initialized
INFO - 2024-10-10 22:28:31 --> Router Class Initialized
INFO - 2024-10-10 22:28:31 --> Output Class Initialized
INFO - 2024-10-10 22:28:31 --> Security Class Initialized
DEBUG - 2024-10-10 22:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:28:31 --> Input Class Initialized
INFO - 2024-10-10 22:28:31 --> Language Class Initialized
INFO - 2024-10-10 22:28:31 --> Language Class Initialized
INFO - 2024-10-10 22:28:31 --> Config Class Initialized
INFO - 2024-10-10 22:28:31 --> Loader Class Initialized
INFO - 2024-10-10 22:28:31 --> Helper loaded: url_helper
INFO - 2024-10-10 22:28:31 --> Helper loaded: file_helper
INFO - 2024-10-10 22:28:31 --> Helper loaded: form_helper
INFO - 2024-10-10 22:28:31 --> Helper loaded: my_helper
INFO - 2024-10-10 22:28:31 --> Database Driver Class Initialized
INFO - 2024-10-10 22:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:28:31 --> Controller Class Initialized
DEBUG - 2024-10-10 22:28:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-10 22:28:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:28:31 --> Final output sent to browser
DEBUG - 2024-10-10 22:28:31 --> Total execution time: 0.0998
INFO - 2024-10-10 22:28:32 --> Config Class Initialized
INFO - 2024-10-10 22:28:32 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:28:32 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:28:32 --> Utf8 Class Initialized
INFO - 2024-10-10 22:28:32 --> URI Class Initialized
INFO - 2024-10-10 22:28:32 --> Router Class Initialized
INFO - 2024-10-10 22:28:32 --> Output Class Initialized
INFO - 2024-10-10 22:28:32 --> Security Class Initialized
DEBUG - 2024-10-10 22:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:28:32 --> Input Class Initialized
INFO - 2024-10-10 22:28:32 --> Language Class Initialized
INFO - 2024-10-10 22:28:32 --> Language Class Initialized
INFO - 2024-10-10 22:28:32 --> Config Class Initialized
INFO - 2024-10-10 22:28:32 --> Loader Class Initialized
INFO - 2024-10-10 22:28:32 --> Helper loaded: url_helper
INFO - 2024-10-10 22:28:32 --> Helper loaded: file_helper
INFO - 2024-10-10 22:28:32 --> Helper loaded: form_helper
INFO - 2024-10-10 22:28:32 --> Helper loaded: my_helper
INFO - 2024-10-10 22:28:32 --> Database Driver Class Initialized
INFO - 2024-10-10 22:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:28:32 --> Controller Class Initialized
INFO - 2024-10-10 22:28:32 --> Final output sent to browser
DEBUG - 2024-10-10 22:28:32 --> Total execution time: 0.0801
INFO - 2024-10-10 22:28:34 --> Final output sent to browser
DEBUG - 2024-10-10 22:28:34 --> Total execution time: 4.1377
INFO - 2024-10-10 22:28:40 --> Config Class Initialized
INFO - 2024-10-10 22:28:40 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:28:40 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:28:40 --> Utf8 Class Initialized
INFO - 2024-10-10 22:28:40 --> URI Class Initialized
INFO - 2024-10-10 22:28:40 --> Router Class Initialized
INFO - 2024-10-10 22:28:40 --> Output Class Initialized
INFO - 2024-10-10 22:28:40 --> Security Class Initialized
DEBUG - 2024-10-10 22:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:28:40 --> Input Class Initialized
INFO - 2024-10-10 22:28:40 --> Language Class Initialized
INFO - 2024-10-10 22:28:40 --> Language Class Initialized
INFO - 2024-10-10 22:28:40 --> Config Class Initialized
INFO - 2024-10-10 22:28:40 --> Loader Class Initialized
INFO - 2024-10-10 22:28:40 --> Helper loaded: url_helper
INFO - 2024-10-10 22:28:40 --> Helper loaded: file_helper
INFO - 2024-10-10 22:28:40 --> Helper loaded: form_helper
INFO - 2024-10-10 22:28:40 --> Helper loaded: my_helper
INFO - 2024-10-10 22:28:40 --> Database Driver Class Initialized
INFO - 2024-10-10 22:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:28:40 --> Controller Class Initialized
INFO - 2024-10-10 22:28:40 --> Final output sent to browser
DEBUG - 2024-10-10 22:28:40 --> Total execution time: 0.0975
INFO - 2024-10-10 22:30:33 --> Config Class Initialized
INFO - 2024-10-10 22:30:33 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:30:33 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:30:33 --> Utf8 Class Initialized
INFO - 2024-10-10 22:30:33 --> URI Class Initialized
INFO - 2024-10-10 22:30:33 --> Router Class Initialized
INFO - 2024-10-10 22:30:33 --> Output Class Initialized
INFO - 2024-10-10 22:30:33 --> Security Class Initialized
DEBUG - 2024-10-10 22:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:30:33 --> Input Class Initialized
INFO - 2024-10-10 22:30:33 --> Language Class Initialized
INFO - 2024-10-10 22:30:33 --> Language Class Initialized
INFO - 2024-10-10 22:30:33 --> Config Class Initialized
INFO - 2024-10-10 22:30:33 --> Loader Class Initialized
INFO - 2024-10-10 22:30:33 --> Helper loaded: url_helper
INFO - 2024-10-10 22:30:33 --> Helper loaded: file_helper
INFO - 2024-10-10 22:30:33 --> Helper loaded: form_helper
INFO - 2024-10-10 22:30:33 --> Helper loaded: my_helper
INFO - 2024-10-10 22:30:33 --> Database Driver Class Initialized
INFO - 2024-10-10 22:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:30:33 --> Controller Class Initialized
INFO - 2024-10-10 22:30:33 --> Final output sent to browser
DEBUG - 2024-10-10 22:30:33 --> Total execution time: 0.1064
INFO - 2024-10-10 22:32:16 --> Config Class Initialized
INFO - 2024-10-10 22:32:16 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:32:16 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:32:16 --> Utf8 Class Initialized
INFO - 2024-10-10 22:32:16 --> URI Class Initialized
INFO - 2024-10-10 22:32:16 --> Router Class Initialized
INFO - 2024-10-10 22:32:16 --> Output Class Initialized
INFO - 2024-10-10 22:32:16 --> Security Class Initialized
DEBUG - 2024-10-10 22:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:32:16 --> Input Class Initialized
INFO - 2024-10-10 22:32:16 --> Language Class Initialized
INFO - 2024-10-10 22:32:16 --> Language Class Initialized
INFO - 2024-10-10 22:32:16 --> Config Class Initialized
INFO - 2024-10-10 22:32:16 --> Loader Class Initialized
INFO - 2024-10-10 22:32:16 --> Helper loaded: url_helper
INFO - 2024-10-10 22:32:16 --> Helper loaded: file_helper
INFO - 2024-10-10 22:32:16 --> Helper loaded: form_helper
INFO - 2024-10-10 22:32:16 --> Helper loaded: my_helper
INFO - 2024-10-10 22:32:16 --> Database Driver Class Initialized
INFO - 2024-10-10 22:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:32:16 --> Controller Class Initialized
DEBUG - 2024-10-10 22:32:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 22:32:19 --> Config Class Initialized
INFO - 2024-10-10 22:32:19 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:32:19 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:32:19 --> Utf8 Class Initialized
INFO - 2024-10-10 22:32:19 --> URI Class Initialized
INFO - 2024-10-10 22:32:19 --> Router Class Initialized
INFO - 2024-10-10 22:32:19 --> Output Class Initialized
INFO - 2024-10-10 22:32:19 --> Security Class Initialized
DEBUG - 2024-10-10 22:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:32:19 --> Input Class Initialized
INFO - 2024-10-10 22:32:19 --> Language Class Initialized
INFO - 2024-10-10 22:32:19 --> Language Class Initialized
INFO - 2024-10-10 22:32:19 --> Config Class Initialized
INFO - 2024-10-10 22:32:19 --> Loader Class Initialized
INFO - 2024-10-10 22:32:19 --> Helper loaded: url_helper
INFO - 2024-10-10 22:32:19 --> Helper loaded: file_helper
INFO - 2024-10-10 22:32:19 --> Helper loaded: form_helper
INFO - 2024-10-10 22:32:19 --> Helper loaded: my_helper
INFO - 2024-10-10 22:32:19 --> Database Driver Class Initialized
INFO - 2024-10-10 22:32:20 --> Final output sent to browser
DEBUG - 2024-10-10 22:32:20 --> Total execution time: 3.2969
INFO - 2024-10-10 22:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:32:20 --> Controller Class Initialized
DEBUG - 2024-10-10 22:32:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 22:32:21 --> Config Class Initialized
INFO - 2024-10-10 22:32:21 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:32:21 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:32:21 --> Utf8 Class Initialized
INFO - 2024-10-10 22:32:21 --> URI Class Initialized
INFO - 2024-10-10 22:32:21 --> Router Class Initialized
INFO - 2024-10-10 22:32:21 --> Output Class Initialized
INFO - 2024-10-10 22:32:21 --> Security Class Initialized
DEBUG - 2024-10-10 22:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:32:21 --> Input Class Initialized
INFO - 2024-10-10 22:32:21 --> Language Class Initialized
INFO - 2024-10-10 22:32:21 --> Language Class Initialized
INFO - 2024-10-10 22:32:21 --> Config Class Initialized
INFO - 2024-10-10 22:32:21 --> Loader Class Initialized
INFO - 2024-10-10 22:32:21 --> Helper loaded: url_helper
INFO - 2024-10-10 22:32:21 --> Helper loaded: file_helper
INFO - 2024-10-10 22:32:21 --> Helper loaded: form_helper
INFO - 2024-10-10 22:32:21 --> Helper loaded: my_helper
INFO - 2024-10-10 22:32:21 --> Database Driver Class Initialized
INFO - 2024-10-10 22:32:23 --> Final output sent to browser
DEBUG - 2024-10-10 22:32:23 --> Total execution time: 4.1140
INFO - 2024-10-10 22:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:32:23 --> Controller Class Initialized
DEBUG - 2024-10-10 22:32:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 22:32:25 --> Config Class Initialized
INFO - 2024-10-10 22:32:25 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:32:25 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:32:25 --> Utf8 Class Initialized
INFO - 2024-10-10 22:32:25 --> URI Class Initialized
INFO - 2024-10-10 22:32:25 --> Router Class Initialized
INFO - 2024-10-10 22:32:25 --> Output Class Initialized
INFO - 2024-10-10 22:32:25 --> Security Class Initialized
DEBUG - 2024-10-10 22:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:32:25 --> Input Class Initialized
INFO - 2024-10-10 22:32:25 --> Language Class Initialized
INFO - 2024-10-10 22:32:25 --> Language Class Initialized
INFO - 2024-10-10 22:32:25 --> Config Class Initialized
INFO - 2024-10-10 22:32:25 --> Loader Class Initialized
INFO - 2024-10-10 22:32:25 --> Helper loaded: url_helper
INFO - 2024-10-10 22:32:25 --> Helper loaded: file_helper
INFO - 2024-10-10 22:32:25 --> Helper loaded: form_helper
INFO - 2024-10-10 22:32:25 --> Helper loaded: my_helper
INFO - 2024-10-10 22:32:25 --> Database Driver Class Initialized
INFO - 2024-10-10 22:32:26 --> Final output sent to browser
DEBUG - 2024-10-10 22:32:26 --> Total execution time: 4.4411
INFO - 2024-10-10 22:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:32:26 --> Controller Class Initialized
DEBUG - 2024-10-10 22:32:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 22:32:29 --> Final output sent to browser
DEBUG - 2024-10-10 22:32:29 --> Total execution time: 3.8002
INFO - 2024-10-10 22:34:08 --> Config Class Initialized
INFO - 2024-10-10 22:34:08 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:34:08 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:34:08 --> Utf8 Class Initialized
INFO - 2024-10-10 22:34:08 --> URI Class Initialized
INFO - 2024-10-10 22:34:08 --> Router Class Initialized
INFO - 2024-10-10 22:34:08 --> Output Class Initialized
INFO - 2024-10-10 22:34:08 --> Security Class Initialized
DEBUG - 2024-10-10 22:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:34:08 --> Input Class Initialized
INFO - 2024-10-10 22:34:08 --> Language Class Initialized
INFO - 2024-10-10 22:34:09 --> Language Class Initialized
INFO - 2024-10-10 22:34:09 --> Config Class Initialized
INFO - 2024-10-10 22:34:09 --> Loader Class Initialized
INFO - 2024-10-10 22:34:09 --> Helper loaded: url_helper
INFO - 2024-10-10 22:34:09 --> Helper loaded: file_helper
INFO - 2024-10-10 22:34:09 --> Helper loaded: form_helper
INFO - 2024-10-10 22:34:09 --> Helper loaded: my_helper
INFO - 2024-10-10 22:34:09 --> Database Driver Class Initialized
INFO - 2024-10-10 22:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:34:09 --> Controller Class Initialized
DEBUG - 2024-10-10 22:34:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 22:34:11 --> Config Class Initialized
INFO - 2024-10-10 22:34:11 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:34:11 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:34:11 --> Utf8 Class Initialized
INFO - 2024-10-10 22:34:11 --> URI Class Initialized
INFO - 2024-10-10 22:34:11 --> Router Class Initialized
INFO - 2024-10-10 22:34:11 --> Output Class Initialized
INFO - 2024-10-10 22:34:11 --> Security Class Initialized
DEBUG - 2024-10-10 22:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:34:11 --> Input Class Initialized
INFO - 2024-10-10 22:34:11 --> Language Class Initialized
INFO - 2024-10-10 22:34:11 --> Language Class Initialized
INFO - 2024-10-10 22:34:11 --> Config Class Initialized
INFO - 2024-10-10 22:34:11 --> Loader Class Initialized
INFO - 2024-10-10 22:34:11 --> Helper loaded: url_helper
INFO - 2024-10-10 22:34:11 --> Helper loaded: file_helper
INFO - 2024-10-10 22:34:11 --> Helper loaded: form_helper
INFO - 2024-10-10 22:34:11 --> Helper loaded: my_helper
INFO - 2024-10-10 22:34:11 --> Database Driver Class Initialized
INFO - 2024-10-10 22:34:12 --> Final output sent to browser
DEBUG - 2024-10-10 22:34:12 --> Total execution time: 3.0768
INFO - 2024-10-10 22:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:34:12 --> Controller Class Initialized
DEBUG - 2024-10-10 22:34:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 22:34:13 --> Config Class Initialized
INFO - 2024-10-10 22:34:13 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:34:14 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:34:14 --> Utf8 Class Initialized
INFO - 2024-10-10 22:34:14 --> URI Class Initialized
INFO - 2024-10-10 22:34:14 --> Router Class Initialized
INFO - 2024-10-10 22:34:14 --> Output Class Initialized
INFO - 2024-10-10 22:34:14 --> Security Class Initialized
DEBUG - 2024-10-10 22:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:34:14 --> Input Class Initialized
INFO - 2024-10-10 22:34:14 --> Language Class Initialized
INFO - 2024-10-10 22:34:14 --> Language Class Initialized
INFO - 2024-10-10 22:34:14 --> Config Class Initialized
INFO - 2024-10-10 22:34:14 --> Loader Class Initialized
INFO - 2024-10-10 22:34:14 --> Helper loaded: url_helper
INFO - 2024-10-10 22:34:14 --> Helper loaded: file_helper
INFO - 2024-10-10 22:34:14 --> Helper loaded: form_helper
INFO - 2024-10-10 22:34:14 --> Helper loaded: my_helper
INFO - 2024-10-10 22:34:14 --> Database Driver Class Initialized
INFO - 2024-10-10 22:34:15 --> Final output sent to browser
DEBUG - 2024-10-10 22:34:15 --> Total execution time: 3.4318
INFO - 2024-10-10 22:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:34:15 --> Controller Class Initialized
DEBUG - 2024-10-10 22:34:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 22:34:16 --> Config Class Initialized
INFO - 2024-10-10 22:34:16 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:34:16 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:34:16 --> Utf8 Class Initialized
INFO - 2024-10-10 22:34:16 --> URI Class Initialized
INFO - 2024-10-10 22:34:16 --> Router Class Initialized
INFO - 2024-10-10 22:34:16 --> Output Class Initialized
INFO - 2024-10-10 22:34:16 --> Security Class Initialized
DEBUG - 2024-10-10 22:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:34:16 --> Input Class Initialized
INFO - 2024-10-10 22:34:16 --> Language Class Initialized
INFO - 2024-10-10 22:34:16 --> Language Class Initialized
INFO - 2024-10-10 22:34:16 --> Config Class Initialized
INFO - 2024-10-10 22:34:16 --> Loader Class Initialized
INFO - 2024-10-10 22:34:16 --> Helper loaded: url_helper
INFO - 2024-10-10 22:34:16 --> Helper loaded: file_helper
INFO - 2024-10-10 22:34:16 --> Helper loaded: form_helper
INFO - 2024-10-10 22:34:16 --> Helper loaded: my_helper
INFO - 2024-10-10 22:34:16 --> Database Driver Class Initialized
INFO - 2024-10-10 22:34:18 --> Final output sent to browser
DEBUG - 2024-10-10 22:34:18 --> Total execution time: 4.3139
INFO - 2024-10-10 22:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:34:18 --> Controller Class Initialized
DEBUG - 2024-10-10 22:34:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-10 22:34:21 --> Final output sent to browser
DEBUG - 2024-10-10 22:34:21 --> Total execution time: 4.8501
INFO - 2024-10-10 22:47:02 --> Config Class Initialized
INFO - 2024-10-10 22:47:02 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:47:02 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:47:02 --> Utf8 Class Initialized
INFO - 2024-10-10 22:47:02 --> URI Class Initialized
INFO - 2024-10-10 22:47:02 --> Router Class Initialized
INFO - 2024-10-10 22:47:02 --> Output Class Initialized
INFO - 2024-10-10 22:47:02 --> Security Class Initialized
DEBUG - 2024-10-10 22:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:47:02 --> Input Class Initialized
INFO - 2024-10-10 22:47:02 --> Language Class Initialized
INFO - 2024-10-10 22:47:02 --> Language Class Initialized
INFO - 2024-10-10 22:47:02 --> Config Class Initialized
INFO - 2024-10-10 22:47:02 --> Loader Class Initialized
INFO - 2024-10-10 22:47:02 --> Helper loaded: url_helper
INFO - 2024-10-10 22:47:02 --> Helper loaded: file_helper
INFO - 2024-10-10 22:47:02 --> Helper loaded: form_helper
INFO - 2024-10-10 22:47:02 --> Helper loaded: my_helper
INFO - 2024-10-10 22:47:02 --> Database Driver Class Initialized
INFO - 2024-10-10 22:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:47:02 --> Controller Class Initialized
INFO - 2024-10-10 22:47:02 --> Helper loaded: cookie_helper
INFO - 2024-10-10 22:47:02 --> Config Class Initialized
INFO - 2024-10-10 22:47:02 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:47:02 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:47:02 --> Utf8 Class Initialized
INFO - 2024-10-10 22:47:02 --> URI Class Initialized
INFO - 2024-10-10 22:47:02 --> Router Class Initialized
INFO - 2024-10-10 22:47:02 --> Output Class Initialized
INFO - 2024-10-10 22:47:02 --> Security Class Initialized
DEBUG - 2024-10-10 22:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:47:02 --> Input Class Initialized
INFO - 2024-10-10 22:47:02 --> Language Class Initialized
INFO - 2024-10-10 22:47:02 --> Language Class Initialized
INFO - 2024-10-10 22:47:02 --> Config Class Initialized
INFO - 2024-10-10 22:47:02 --> Loader Class Initialized
INFO - 2024-10-10 22:47:02 --> Helper loaded: url_helper
INFO - 2024-10-10 22:47:02 --> Helper loaded: file_helper
INFO - 2024-10-10 22:47:02 --> Helper loaded: form_helper
INFO - 2024-10-10 22:47:02 --> Helper loaded: my_helper
INFO - 2024-10-10 22:47:02 --> Database Driver Class Initialized
INFO - 2024-10-10 22:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:47:02 --> Controller Class Initialized
INFO - 2024-10-10 22:47:02 --> Config Class Initialized
INFO - 2024-10-10 22:47:02 --> Hooks Class Initialized
DEBUG - 2024-10-10 22:47:02 --> UTF-8 Support Enabled
INFO - 2024-10-10 22:47:02 --> Utf8 Class Initialized
INFO - 2024-10-10 22:47:02 --> URI Class Initialized
INFO - 2024-10-10 22:47:02 --> Router Class Initialized
INFO - 2024-10-10 22:47:02 --> Output Class Initialized
INFO - 2024-10-10 22:47:02 --> Security Class Initialized
DEBUG - 2024-10-10 22:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 22:47:02 --> Input Class Initialized
INFO - 2024-10-10 22:47:02 --> Language Class Initialized
INFO - 2024-10-10 22:47:02 --> Language Class Initialized
INFO - 2024-10-10 22:47:02 --> Config Class Initialized
INFO - 2024-10-10 22:47:02 --> Loader Class Initialized
INFO - 2024-10-10 22:47:02 --> Helper loaded: url_helper
INFO - 2024-10-10 22:47:02 --> Helper loaded: file_helper
INFO - 2024-10-10 22:47:02 --> Helper loaded: form_helper
INFO - 2024-10-10 22:47:02 --> Helper loaded: my_helper
INFO - 2024-10-10 22:47:02 --> Database Driver Class Initialized
INFO - 2024-10-10 22:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-10 22:47:02 --> Controller Class Initialized
DEBUG - 2024-10-10 22:47:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-10 22:47:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-10 22:47:02 --> Final output sent to browser
DEBUG - 2024-10-10 22:47:02 --> Total execution time: 0.0498
