<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-03-18 13:42:24 --> Config Class Initialized
INFO - 2020-03-18 13:42:24 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:42:24 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:42:24 --> Utf8 Class Initialized
INFO - 2020-03-18 13:42:25 --> URI Class Initialized
DEBUG - 2020-03-18 13:42:25 --> No URI present. Default controller set.
INFO - 2020-03-18 13:42:25 --> Router Class Initialized
INFO - 2020-03-18 13:42:25 --> Output Class Initialized
INFO - 2020-03-18 13:42:25 --> Security Class Initialized
DEBUG - 2020-03-18 13:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:42:25 --> Input Class Initialized
INFO - 2020-03-18 13:42:25 --> Language Class Initialized
INFO - 2020-03-18 13:42:25 --> Language Class Initialized
INFO - 2020-03-18 13:42:25 --> Config Class Initialized
INFO - 2020-03-18 13:42:25 --> Loader Class Initialized
INFO - 2020-03-18 13:42:25 --> Helper loaded: url_helper
INFO - 2020-03-18 13:42:25 --> Helper loaded: file_helper
INFO - 2020-03-18 13:42:25 --> Helper loaded: form_helper
INFO - 2020-03-18 13:42:25 --> Helper loaded: my_helper
INFO - 2020-03-18 13:42:26 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:42:26 --> Controller Class Initialized
INFO - 2020-03-18 13:42:42 --> Config Class Initialized
INFO - 2020-03-18 13:42:42 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:42:42 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:42:42 --> Utf8 Class Initialized
INFO - 2020-03-18 13:42:42 --> URI Class Initialized
DEBUG - 2020-03-18 13:42:42 --> No URI present. Default controller set.
INFO - 2020-03-18 13:42:42 --> Router Class Initialized
INFO - 2020-03-18 13:42:42 --> Output Class Initialized
INFO - 2020-03-18 13:42:42 --> Security Class Initialized
DEBUG - 2020-03-18 13:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:42:42 --> Input Class Initialized
INFO - 2020-03-18 13:42:42 --> Language Class Initialized
INFO - 2020-03-18 13:42:42 --> Language Class Initialized
INFO - 2020-03-18 13:42:42 --> Config Class Initialized
INFO - 2020-03-18 13:42:42 --> Loader Class Initialized
INFO - 2020-03-18 13:42:42 --> Helper loaded: url_helper
INFO - 2020-03-18 13:42:42 --> Helper loaded: file_helper
INFO - 2020-03-18 13:42:42 --> Helper loaded: form_helper
INFO - 2020-03-18 13:42:42 --> Helper loaded: my_helper
INFO - 2020-03-18 13:42:42 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:42:42 --> Controller Class Initialized
INFO - 2020-03-18 13:47:38 --> Config Class Initialized
INFO - 2020-03-18 13:47:38 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:47:38 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:47:38 --> Utf8 Class Initialized
INFO - 2020-03-18 13:47:38 --> URI Class Initialized
INFO - 2020-03-18 13:47:38 --> Router Class Initialized
INFO - 2020-03-18 13:47:38 --> Output Class Initialized
INFO - 2020-03-18 13:47:38 --> Security Class Initialized
DEBUG - 2020-03-18 13:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:47:38 --> Input Class Initialized
INFO - 2020-03-18 13:47:38 --> Language Class Initialized
INFO - 2020-03-18 13:47:38 --> Language Class Initialized
INFO - 2020-03-18 13:47:38 --> Config Class Initialized
INFO - 2020-03-18 13:47:38 --> Loader Class Initialized
INFO - 2020-03-18 13:47:38 --> Helper loaded: url_helper
INFO - 2020-03-18 13:47:38 --> Helper loaded: file_helper
INFO - 2020-03-18 13:47:38 --> Helper loaded: form_helper
INFO - 2020-03-18 13:47:38 --> Helper loaded: my_helper
INFO - 2020-03-18 13:47:38 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:47:38 --> Controller Class Initialized
DEBUG - 2020-03-18 13:47:38 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 13:47:38 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 13:47:38 --> Final output sent to browser
DEBUG - 2020-03-18 13:47:38 --> Total execution time: 0.6503
INFO - 2020-03-18 13:48:09 --> Config Class Initialized
INFO - 2020-03-18 13:48:09 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:48:10 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:48:10 --> Utf8 Class Initialized
INFO - 2020-03-18 13:48:10 --> URI Class Initialized
INFO - 2020-03-18 13:48:10 --> Router Class Initialized
INFO - 2020-03-18 13:48:10 --> Output Class Initialized
INFO - 2020-03-18 13:48:10 --> Security Class Initialized
DEBUG - 2020-03-18 13:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:48:10 --> Input Class Initialized
INFO - 2020-03-18 13:48:10 --> Language Class Initialized
INFO - 2020-03-18 13:48:10 --> Language Class Initialized
INFO - 2020-03-18 13:48:10 --> Config Class Initialized
INFO - 2020-03-18 13:48:10 --> Loader Class Initialized
INFO - 2020-03-18 13:48:10 --> Helper loaded: url_helper
INFO - 2020-03-18 13:48:10 --> Helper loaded: file_helper
INFO - 2020-03-18 13:48:10 --> Helper loaded: form_helper
INFO - 2020-03-18 13:48:10 --> Helper loaded: my_helper
INFO - 2020-03-18 13:48:10 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:48:10 --> Controller Class Initialized
INFO - 2020-03-18 13:48:10 --> Final output sent to browser
DEBUG - 2020-03-18 13:48:10 --> Total execution time: 0.4775
INFO - 2020-03-18 13:49:18 --> Config Class Initialized
INFO - 2020-03-18 13:49:18 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:49:18 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:49:18 --> Utf8 Class Initialized
INFO - 2020-03-18 13:49:18 --> URI Class Initialized
INFO - 2020-03-18 13:49:18 --> Router Class Initialized
INFO - 2020-03-18 13:49:18 --> Output Class Initialized
INFO - 2020-03-18 13:49:18 --> Security Class Initialized
DEBUG - 2020-03-18 13:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:49:18 --> Input Class Initialized
INFO - 2020-03-18 13:49:18 --> Language Class Initialized
INFO - 2020-03-18 13:49:18 --> Language Class Initialized
INFO - 2020-03-18 13:49:18 --> Config Class Initialized
INFO - 2020-03-18 13:49:18 --> Loader Class Initialized
INFO - 2020-03-18 13:49:18 --> Helper loaded: url_helper
INFO - 2020-03-18 13:49:18 --> Helper loaded: file_helper
INFO - 2020-03-18 13:49:18 --> Helper loaded: form_helper
INFO - 2020-03-18 13:49:18 --> Helper loaded: my_helper
INFO - 2020-03-18 13:49:18 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:49:18 --> Controller Class Initialized
INFO - 2020-03-18 13:49:18 --> Final output sent to browser
DEBUG - 2020-03-18 13:49:18 --> Total execution time: 0.4498
INFO - 2020-03-18 13:49:22 --> Config Class Initialized
INFO - 2020-03-18 13:49:22 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:49:22 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:49:22 --> Utf8 Class Initialized
INFO - 2020-03-18 13:49:22 --> URI Class Initialized
INFO - 2020-03-18 13:49:22 --> Router Class Initialized
INFO - 2020-03-18 13:49:22 --> Output Class Initialized
INFO - 2020-03-18 13:49:22 --> Security Class Initialized
DEBUG - 2020-03-18 13:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:49:22 --> Input Class Initialized
INFO - 2020-03-18 13:49:22 --> Language Class Initialized
INFO - 2020-03-18 13:49:22 --> Language Class Initialized
INFO - 2020-03-18 13:49:22 --> Config Class Initialized
INFO - 2020-03-18 13:49:22 --> Loader Class Initialized
INFO - 2020-03-18 13:49:22 --> Helper loaded: url_helper
INFO - 2020-03-18 13:49:22 --> Helper loaded: file_helper
INFO - 2020-03-18 13:49:22 --> Helper loaded: form_helper
INFO - 2020-03-18 13:49:22 --> Helper loaded: my_helper
INFO - 2020-03-18 13:49:22 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:49:22 --> Controller Class Initialized
INFO - 2020-03-18 13:49:22 --> Helper loaded: cookie_helper
INFO - 2020-03-18 13:49:22 --> Final output sent to browser
DEBUG - 2020-03-18 13:49:22 --> Total execution time: 0.5085
INFO - 2020-03-18 13:49:22 --> Config Class Initialized
INFO - 2020-03-18 13:49:23 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:49:23 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:49:23 --> Utf8 Class Initialized
INFO - 2020-03-18 13:49:23 --> URI Class Initialized
INFO - 2020-03-18 13:49:23 --> Router Class Initialized
INFO - 2020-03-18 13:49:23 --> Output Class Initialized
INFO - 2020-03-18 13:49:23 --> Security Class Initialized
DEBUG - 2020-03-18 13:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:49:23 --> Input Class Initialized
INFO - 2020-03-18 13:49:23 --> Language Class Initialized
INFO - 2020-03-18 13:49:23 --> Language Class Initialized
INFO - 2020-03-18 13:49:23 --> Config Class Initialized
INFO - 2020-03-18 13:49:23 --> Loader Class Initialized
INFO - 2020-03-18 13:49:23 --> Helper loaded: url_helper
INFO - 2020-03-18 13:49:23 --> Helper loaded: file_helper
INFO - 2020-03-18 13:49:23 --> Helper loaded: form_helper
INFO - 2020-03-18 13:49:23 --> Helper loaded: my_helper
INFO - 2020-03-18 13:49:23 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:49:23 --> Controller Class Initialized
DEBUG - 2020-03-18 13:49:23 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 13:49:23 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 13:49:23 --> Final output sent to browser
DEBUG - 2020-03-18 13:49:25 --> Total execution time: 0.7285
INFO - 2020-03-18 13:49:34 --> Config Class Initialized
INFO - 2020-03-18 13:49:34 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:49:34 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:49:34 --> Utf8 Class Initialized
INFO - 2020-03-18 13:49:34 --> URI Class Initialized
INFO - 2020-03-18 13:49:34 --> Router Class Initialized
INFO - 2020-03-18 13:49:34 --> Output Class Initialized
INFO - 2020-03-18 13:49:34 --> Security Class Initialized
DEBUG - 2020-03-18 13:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:49:34 --> Input Class Initialized
INFO - 2020-03-18 13:49:34 --> Language Class Initialized
INFO - 2020-03-18 13:49:34 --> Language Class Initialized
INFO - 2020-03-18 13:49:34 --> Config Class Initialized
INFO - 2020-03-18 13:49:34 --> Loader Class Initialized
INFO - 2020-03-18 13:49:34 --> Helper loaded: url_helper
INFO - 2020-03-18 13:49:34 --> Helper loaded: file_helper
INFO - 2020-03-18 13:49:34 --> Helper loaded: form_helper
INFO - 2020-03-18 13:49:34 --> Helper loaded: my_helper
INFO - 2020-03-18 13:49:34 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:49:34 --> Controller Class Initialized
DEBUG - 2020-03-18 13:49:34 --> File loaded: D:\xampp\htdocs\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-03-18 13:49:34 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 13:49:34 --> Final output sent to browser
DEBUG - 2020-03-18 13:49:34 --> Total execution time: 0.4495
INFO - 2020-03-18 13:49:35 --> Config Class Initialized
INFO - 2020-03-18 13:49:35 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:49:35 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:49:35 --> Utf8 Class Initialized
INFO - 2020-03-18 13:49:35 --> URI Class Initialized
INFO - 2020-03-18 13:49:35 --> Router Class Initialized
INFO - 2020-03-18 13:49:35 --> Output Class Initialized
INFO - 2020-03-18 13:49:35 --> Security Class Initialized
DEBUG - 2020-03-18 13:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:49:35 --> Input Class Initialized
INFO - 2020-03-18 13:49:35 --> Language Class Initialized
INFO - 2020-03-18 13:49:35 --> Language Class Initialized
INFO - 2020-03-18 13:49:35 --> Config Class Initialized
INFO - 2020-03-18 13:49:35 --> Loader Class Initialized
INFO - 2020-03-18 13:49:35 --> Helper loaded: url_helper
INFO - 2020-03-18 13:49:35 --> Helper loaded: file_helper
INFO - 2020-03-18 13:49:35 --> Helper loaded: form_helper
INFO - 2020-03-18 13:49:35 --> Helper loaded: my_helper
INFO - 2020-03-18 13:49:35 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:49:35 --> Controller Class Initialized
INFO - 2020-03-18 13:49:39 --> Config Class Initialized
INFO - 2020-03-18 13:49:39 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:49:39 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:49:39 --> Utf8 Class Initialized
INFO - 2020-03-18 13:49:39 --> URI Class Initialized
INFO - 2020-03-18 13:49:39 --> Router Class Initialized
INFO - 2020-03-18 13:49:39 --> Output Class Initialized
INFO - 2020-03-18 13:49:39 --> Security Class Initialized
DEBUG - 2020-03-18 13:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:49:40 --> Input Class Initialized
INFO - 2020-03-18 13:49:40 --> Language Class Initialized
INFO - 2020-03-18 13:49:40 --> Language Class Initialized
INFO - 2020-03-18 13:49:40 --> Config Class Initialized
INFO - 2020-03-18 13:49:40 --> Loader Class Initialized
INFO - 2020-03-18 13:49:40 --> Helper loaded: url_helper
INFO - 2020-03-18 13:49:40 --> Helper loaded: file_helper
INFO - 2020-03-18 13:49:40 --> Helper loaded: form_helper
INFO - 2020-03-18 13:49:40 --> Helper loaded: my_helper
INFO - 2020-03-18 13:49:40 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:49:40 --> Controller Class Initialized
DEBUG - 2020-03-18 13:49:40 --> File loaded: D:\xampp\htdocs\myraport\application\modules/set_walikelas/views/list.php
DEBUG - 2020-03-18 13:49:40 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 13:49:40 --> Final output sent to browser
DEBUG - 2020-03-18 13:49:40 --> Total execution time: 0.4750
INFO - 2020-03-18 13:49:41 --> Config Class Initialized
INFO - 2020-03-18 13:49:41 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:49:41 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:49:41 --> Utf8 Class Initialized
INFO - 2020-03-18 13:49:41 --> URI Class Initialized
INFO - 2020-03-18 13:49:41 --> Router Class Initialized
INFO - 2020-03-18 13:49:41 --> Output Class Initialized
INFO - 2020-03-18 13:49:41 --> Security Class Initialized
DEBUG - 2020-03-18 13:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:49:41 --> Input Class Initialized
INFO - 2020-03-18 13:49:41 --> Language Class Initialized
INFO - 2020-03-18 13:49:41 --> Language Class Initialized
INFO - 2020-03-18 13:49:41 --> Config Class Initialized
INFO - 2020-03-18 13:49:41 --> Loader Class Initialized
INFO - 2020-03-18 13:49:41 --> Helper loaded: url_helper
INFO - 2020-03-18 13:49:41 --> Helper loaded: file_helper
INFO - 2020-03-18 13:49:41 --> Helper loaded: form_helper
INFO - 2020-03-18 13:49:41 --> Helper loaded: my_helper
INFO - 2020-03-18 13:49:41 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:49:41 --> Controller Class Initialized
INFO - 2020-03-18 13:49:52 --> Config Class Initialized
INFO - 2020-03-18 13:49:52 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:49:52 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:49:52 --> Utf8 Class Initialized
INFO - 2020-03-18 13:49:52 --> URI Class Initialized
INFO - 2020-03-18 13:49:52 --> Router Class Initialized
INFO - 2020-03-18 13:49:52 --> Output Class Initialized
INFO - 2020-03-18 13:49:52 --> Security Class Initialized
DEBUG - 2020-03-18 13:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:49:52 --> Input Class Initialized
INFO - 2020-03-18 13:49:52 --> Language Class Initialized
INFO - 2020-03-18 13:49:52 --> Language Class Initialized
INFO - 2020-03-18 13:49:52 --> Config Class Initialized
INFO - 2020-03-18 13:49:52 --> Loader Class Initialized
INFO - 2020-03-18 13:49:52 --> Helper loaded: url_helper
INFO - 2020-03-18 13:49:52 --> Helper loaded: file_helper
INFO - 2020-03-18 13:49:52 --> Helper loaded: form_helper
INFO - 2020-03-18 13:49:52 --> Helper loaded: my_helper
INFO - 2020-03-18 13:49:52 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:49:52 --> Controller Class Initialized
DEBUG - 2020-03-18 13:49:52 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_guru/views/list.php
DEBUG - 2020-03-18 13:49:52 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 13:49:52 --> Final output sent to browser
DEBUG - 2020-03-18 13:49:52 --> Total execution time: 0.4648
INFO - 2020-03-18 13:49:53 --> Config Class Initialized
INFO - 2020-03-18 13:49:53 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:49:53 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:49:53 --> Utf8 Class Initialized
INFO - 2020-03-18 13:49:53 --> URI Class Initialized
INFO - 2020-03-18 13:49:53 --> Router Class Initialized
INFO - 2020-03-18 13:49:53 --> Output Class Initialized
INFO - 2020-03-18 13:49:53 --> Security Class Initialized
DEBUG - 2020-03-18 13:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:49:53 --> Input Class Initialized
INFO - 2020-03-18 13:49:53 --> Language Class Initialized
INFO - 2020-03-18 13:49:53 --> Language Class Initialized
INFO - 2020-03-18 13:49:53 --> Config Class Initialized
INFO - 2020-03-18 13:49:53 --> Loader Class Initialized
INFO - 2020-03-18 13:49:53 --> Helper loaded: url_helper
INFO - 2020-03-18 13:49:53 --> Helper loaded: file_helper
INFO - 2020-03-18 13:49:53 --> Helper loaded: form_helper
INFO - 2020-03-18 13:49:53 --> Helper loaded: my_helper
INFO - 2020-03-18 13:49:53 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:49:53 --> Controller Class Initialized
INFO - 2020-03-18 13:50:41 --> Config Class Initialized
INFO - 2020-03-18 13:50:41 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:50:41 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:50:41 --> Utf8 Class Initialized
INFO - 2020-03-18 13:50:41 --> URI Class Initialized
INFO - 2020-03-18 13:50:41 --> Router Class Initialized
INFO - 2020-03-18 13:50:41 --> Output Class Initialized
INFO - 2020-03-18 13:50:41 --> Security Class Initialized
DEBUG - 2020-03-18 13:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:50:41 --> Input Class Initialized
INFO - 2020-03-18 13:50:41 --> Language Class Initialized
INFO - 2020-03-18 13:50:41 --> Language Class Initialized
INFO - 2020-03-18 13:50:41 --> Config Class Initialized
INFO - 2020-03-18 13:50:41 --> Loader Class Initialized
INFO - 2020-03-18 13:50:41 --> Helper loaded: url_helper
INFO - 2020-03-18 13:50:41 --> Helper loaded: file_helper
INFO - 2020-03-18 13:50:41 --> Helper loaded: form_helper
INFO - 2020-03-18 13:50:41 --> Helper loaded: my_helper
INFO - 2020-03-18 13:50:41 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:50:41 --> Controller Class Initialized
INFO - 2020-03-18 13:50:41 --> Helper loaded: cookie_helper
INFO - 2020-03-18 13:50:41 --> Config Class Initialized
INFO - 2020-03-18 13:50:41 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:50:41 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:50:41 --> Utf8 Class Initialized
INFO - 2020-03-18 13:50:41 --> URI Class Initialized
INFO - 2020-03-18 13:50:41 --> Router Class Initialized
INFO - 2020-03-18 13:50:41 --> Output Class Initialized
INFO - 2020-03-18 13:50:41 --> Security Class Initialized
DEBUG - 2020-03-18 13:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:50:41 --> Input Class Initialized
INFO - 2020-03-18 13:50:41 --> Language Class Initialized
INFO - 2020-03-18 13:50:41 --> Language Class Initialized
INFO - 2020-03-18 13:50:41 --> Config Class Initialized
INFO - 2020-03-18 13:50:41 --> Loader Class Initialized
INFO - 2020-03-18 13:50:41 --> Helper loaded: url_helper
INFO - 2020-03-18 13:50:41 --> Helper loaded: file_helper
INFO - 2020-03-18 13:50:41 --> Helper loaded: form_helper
INFO - 2020-03-18 13:50:41 --> Helper loaded: my_helper
INFO - 2020-03-18 13:50:41 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:50:41 --> Controller Class Initialized
INFO - 2020-03-18 13:50:42 --> Config Class Initialized
INFO - 2020-03-18 13:50:42 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:50:42 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:50:42 --> Utf8 Class Initialized
INFO - 2020-03-18 13:50:42 --> URI Class Initialized
INFO - 2020-03-18 13:50:42 --> Router Class Initialized
INFO - 2020-03-18 13:50:42 --> Output Class Initialized
INFO - 2020-03-18 13:50:42 --> Security Class Initialized
DEBUG - 2020-03-18 13:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:50:42 --> Input Class Initialized
INFO - 2020-03-18 13:50:42 --> Language Class Initialized
INFO - 2020-03-18 13:50:42 --> Language Class Initialized
INFO - 2020-03-18 13:50:42 --> Config Class Initialized
INFO - 2020-03-18 13:50:42 --> Loader Class Initialized
INFO - 2020-03-18 13:50:42 --> Helper loaded: url_helper
INFO - 2020-03-18 13:50:42 --> Helper loaded: file_helper
INFO - 2020-03-18 13:50:42 --> Helper loaded: form_helper
INFO - 2020-03-18 13:50:42 --> Helper loaded: my_helper
INFO - 2020-03-18 13:50:42 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:50:42 --> Controller Class Initialized
DEBUG - 2020-03-18 13:50:42 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 13:50:42 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 13:50:42 --> Final output sent to browser
DEBUG - 2020-03-18 13:50:42 --> Total execution time: 0.4154
INFO - 2020-03-18 13:51:26 --> Config Class Initialized
INFO - 2020-03-18 13:51:26 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:51:26 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:51:26 --> Utf8 Class Initialized
INFO - 2020-03-18 13:51:26 --> URI Class Initialized
INFO - 2020-03-18 13:51:26 --> Router Class Initialized
INFO - 2020-03-18 13:51:26 --> Output Class Initialized
INFO - 2020-03-18 13:51:26 --> Security Class Initialized
DEBUG - 2020-03-18 13:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:51:26 --> Input Class Initialized
INFO - 2020-03-18 13:51:26 --> Language Class Initialized
INFO - 2020-03-18 13:51:26 --> Language Class Initialized
INFO - 2020-03-18 13:51:26 --> Config Class Initialized
INFO - 2020-03-18 13:51:26 --> Loader Class Initialized
INFO - 2020-03-18 13:51:26 --> Helper loaded: url_helper
INFO - 2020-03-18 13:51:26 --> Helper loaded: file_helper
INFO - 2020-03-18 13:51:26 --> Helper loaded: form_helper
INFO - 2020-03-18 13:51:26 --> Helper loaded: my_helper
INFO - 2020-03-18 13:51:26 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:51:27 --> Controller Class Initialized
DEBUG - 2020-03-18 13:51:27 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 13:51:27 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 13:51:27 --> Final output sent to browser
DEBUG - 2020-03-18 13:51:27 --> Total execution time: 0.4864
INFO - 2020-03-18 13:51:37 --> Config Class Initialized
INFO - 2020-03-18 13:51:37 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:51:37 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:51:37 --> Utf8 Class Initialized
INFO - 2020-03-18 13:51:37 --> URI Class Initialized
INFO - 2020-03-18 13:51:37 --> Router Class Initialized
INFO - 2020-03-18 13:51:37 --> Output Class Initialized
INFO - 2020-03-18 13:51:37 --> Security Class Initialized
DEBUG - 2020-03-18 13:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:51:38 --> Input Class Initialized
INFO - 2020-03-18 13:51:38 --> Language Class Initialized
INFO - 2020-03-18 13:51:38 --> Language Class Initialized
INFO - 2020-03-18 13:51:38 --> Config Class Initialized
INFO - 2020-03-18 13:51:38 --> Loader Class Initialized
INFO - 2020-03-18 13:51:38 --> Helper loaded: url_helper
INFO - 2020-03-18 13:51:38 --> Helper loaded: file_helper
INFO - 2020-03-18 13:51:38 --> Helper loaded: form_helper
INFO - 2020-03-18 13:51:38 --> Helper loaded: my_helper
INFO - 2020-03-18 13:51:38 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:51:38 --> Controller Class Initialized
INFO - 2020-03-18 13:51:38 --> Helper loaded: cookie_helper
INFO - 2020-03-18 13:51:38 --> Final output sent to browser
DEBUG - 2020-03-18 13:51:38 --> Total execution time: 0.4740
INFO - 2020-03-18 13:51:38 --> Config Class Initialized
INFO - 2020-03-18 13:51:38 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:51:38 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:51:38 --> Utf8 Class Initialized
INFO - 2020-03-18 13:51:38 --> URI Class Initialized
INFO - 2020-03-18 13:51:38 --> Router Class Initialized
INFO - 2020-03-18 13:51:38 --> Output Class Initialized
INFO - 2020-03-18 13:51:38 --> Security Class Initialized
DEBUG - 2020-03-18 13:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:51:38 --> Input Class Initialized
INFO - 2020-03-18 13:51:38 --> Language Class Initialized
INFO - 2020-03-18 13:51:38 --> Language Class Initialized
INFO - 2020-03-18 13:51:38 --> Config Class Initialized
INFO - 2020-03-18 13:51:38 --> Loader Class Initialized
INFO - 2020-03-18 13:51:38 --> Helper loaded: url_helper
INFO - 2020-03-18 13:51:38 --> Helper loaded: file_helper
INFO - 2020-03-18 13:51:38 --> Helper loaded: form_helper
INFO - 2020-03-18 13:51:38 --> Helper loaded: my_helper
INFO - 2020-03-18 13:51:38 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:51:39 --> Controller Class Initialized
DEBUG - 2020-03-18 13:51:39 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 13:51:39 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 13:51:39 --> Final output sent to browser
DEBUG - 2020-03-18 13:51:40 --> Total execution time: 0.6562
INFO - 2020-03-18 13:51:48 --> Config Class Initialized
INFO - 2020-03-18 13:51:48 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:51:48 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:51:48 --> Utf8 Class Initialized
INFO - 2020-03-18 13:51:48 --> URI Class Initialized
INFO - 2020-03-18 13:51:48 --> Router Class Initialized
INFO - 2020-03-18 13:51:48 --> Output Class Initialized
INFO - 2020-03-18 13:51:48 --> Security Class Initialized
DEBUG - 2020-03-18 13:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:51:48 --> Input Class Initialized
INFO - 2020-03-18 13:51:48 --> Language Class Initialized
INFO - 2020-03-18 13:51:48 --> Language Class Initialized
INFO - 2020-03-18 13:51:48 --> Config Class Initialized
INFO - 2020-03-18 13:51:48 --> Loader Class Initialized
INFO - 2020-03-18 13:51:48 --> Helper loaded: url_helper
INFO - 2020-03-18 13:51:48 --> Helper loaded: file_helper
INFO - 2020-03-18 13:51:48 --> Helper loaded: form_helper
INFO - 2020-03-18 13:51:48 --> Helper loaded: my_helper
INFO - 2020-03-18 13:51:48 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:51:48 --> Controller Class Initialized
DEBUG - 2020-03-18 13:51:48 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_guru/views/list.php
DEBUG - 2020-03-18 13:51:49 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 13:51:49 --> Final output sent to browser
DEBUG - 2020-03-18 13:51:49 --> Total execution time: 0.4752
INFO - 2020-03-18 13:51:49 --> Config Class Initialized
INFO - 2020-03-18 13:51:50 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:51:50 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:51:50 --> Utf8 Class Initialized
INFO - 2020-03-18 13:51:50 --> URI Class Initialized
INFO - 2020-03-18 13:51:50 --> Router Class Initialized
INFO - 2020-03-18 13:51:50 --> Output Class Initialized
INFO - 2020-03-18 13:51:50 --> Security Class Initialized
DEBUG - 2020-03-18 13:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:51:50 --> Input Class Initialized
INFO - 2020-03-18 13:51:50 --> Language Class Initialized
INFO - 2020-03-18 13:51:50 --> Language Class Initialized
INFO - 2020-03-18 13:51:50 --> Config Class Initialized
INFO - 2020-03-18 13:51:50 --> Loader Class Initialized
INFO - 2020-03-18 13:51:50 --> Helper loaded: url_helper
INFO - 2020-03-18 13:51:50 --> Helper loaded: file_helper
INFO - 2020-03-18 13:51:50 --> Helper loaded: form_helper
INFO - 2020-03-18 13:51:50 --> Helper loaded: my_helper
INFO - 2020-03-18 13:51:50 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:51:50 --> Controller Class Initialized
INFO - 2020-03-18 13:51:57 --> Config Class Initialized
INFO - 2020-03-18 13:51:57 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:51:57 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:51:57 --> Utf8 Class Initialized
INFO - 2020-03-18 13:51:57 --> URI Class Initialized
INFO - 2020-03-18 13:51:57 --> Router Class Initialized
INFO - 2020-03-18 13:51:57 --> Output Class Initialized
INFO - 2020-03-18 13:51:57 --> Security Class Initialized
DEBUG - 2020-03-18 13:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:51:57 --> Input Class Initialized
INFO - 2020-03-18 13:51:57 --> Language Class Initialized
INFO - 2020-03-18 13:51:57 --> Language Class Initialized
INFO - 2020-03-18 13:51:57 --> Config Class Initialized
INFO - 2020-03-18 13:51:57 --> Loader Class Initialized
INFO - 2020-03-18 13:51:57 --> Helper loaded: url_helper
INFO - 2020-03-18 13:51:57 --> Helper loaded: file_helper
INFO - 2020-03-18 13:51:57 --> Helper loaded: form_helper
INFO - 2020-03-18 13:51:57 --> Helper loaded: my_helper
INFO - 2020-03-18 13:51:57 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:51:57 --> Controller Class Initialized
INFO - 2020-03-18 13:51:57 --> Helper loaded: cookie_helper
INFO - 2020-03-18 13:51:57 --> Config Class Initialized
INFO - 2020-03-18 13:51:58 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:51:58 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:51:58 --> Utf8 Class Initialized
INFO - 2020-03-18 13:51:58 --> URI Class Initialized
INFO - 2020-03-18 13:51:58 --> Router Class Initialized
INFO - 2020-03-18 13:51:58 --> Output Class Initialized
INFO - 2020-03-18 13:51:58 --> Security Class Initialized
DEBUG - 2020-03-18 13:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:51:58 --> Input Class Initialized
INFO - 2020-03-18 13:51:58 --> Language Class Initialized
INFO - 2020-03-18 13:51:58 --> Language Class Initialized
INFO - 2020-03-18 13:51:58 --> Config Class Initialized
INFO - 2020-03-18 13:51:58 --> Loader Class Initialized
INFO - 2020-03-18 13:51:58 --> Helper loaded: url_helper
INFO - 2020-03-18 13:51:58 --> Helper loaded: file_helper
INFO - 2020-03-18 13:51:58 --> Helper loaded: form_helper
INFO - 2020-03-18 13:51:58 --> Helper loaded: my_helper
INFO - 2020-03-18 13:51:58 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:51:58 --> Controller Class Initialized
INFO - 2020-03-18 13:51:58 --> Config Class Initialized
INFO - 2020-03-18 13:51:58 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:51:58 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:51:58 --> Utf8 Class Initialized
INFO - 2020-03-18 13:51:58 --> URI Class Initialized
INFO - 2020-03-18 13:51:58 --> Router Class Initialized
INFO - 2020-03-18 13:51:58 --> Output Class Initialized
INFO - 2020-03-18 13:51:58 --> Security Class Initialized
DEBUG - 2020-03-18 13:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:51:58 --> Input Class Initialized
INFO - 2020-03-18 13:51:58 --> Language Class Initialized
INFO - 2020-03-18 13:51:58 --> Language Class Initialized
INFO - 2020-03-18 13:51:58 --> Config Class Initialized
INFO - 2020-03-18 13:51:58 --> Loader Class Initialized
INFO - 2020-03-18 13:51:58 --> Helper loaded: url_helper
INFO - 2020-03-18 13:51:58 --> Helper loaded: file_helper
INFO - 2020-03-18 13:51:58 --> Helper loaded: form_helper
INFO - 2020-03-18 13:51:59 --> Helper loaded: my_helper
INFO - 2020-03-18 13:51:59 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:51:59 --> Controller Class Initialized
DEBUG - 2020-03-18 13:51:59 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 13:51:59 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 13:51:59 --> Final output sent to browser
DEBUG - 2020-03-18 13:51:59 --> Total execution time: 0.4627
INFO - 2020-03-18 13:52:10 --> Config Class Initialized
INFO - 2020-03-18 13:52:10 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:52:10 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:52:10 --> Utf8 Class Initialized
INFO - 2020-03-18 13:52:10 --> URI Class Initialized
INFO - 2020-03-18 13:52:10 --> Router Class Initialized
INFO - 2020-03-18 13:52:10 --> Output Class Initialized
INFO - 2020-03-18 13:52:10 --> Security Class Initialized
DEBUG - 2020-03-18 13:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:52:10 --> Input Class Initialized
INFO - 2020-03-18 13:52:10 --> Language Class Initialized
INFO - 2020-03-18 13:52:10 --> Language Class Initialized
INFO - 2020-03-18 13:52:10 --> Config Class Initialized
INFO - 2020-03-18 13:52:10 --> Loader Class Initialized
INFO - 2020-03-18 13:52:10 --> Helper loaded: url_helper
INFO - 2020-03-18 13:52:10 --> Helper loaded: file_helper
INFO - 2020-03-18 13:52:10 --> Helper loaded: form_helper
INFO - 2020-03-18 13:52:10 --> Helper loaded: my_helper
INFO - 2020-03-18 13:52:10 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:52:10 --> Controller Class Initialized
INFO - 2020-03-18 13:52:10 --> Helper loaded: cookie_helper
INFO - 2020-03-18 13:52:10 --> Final output sent to browser
DEBUG - 2020-03-18 13:52:10 --> Total execution time: 0.5344
INFO - 2020-03-18 13:52:10 --> Config Class Initialized
INFO - 2020-03-18 13:52:10 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:52:10 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:52:10 --> Utf8 Class Initialized
INFO - 2020-03-18 13:52:10 --> URI Class Initialized
INFO - 2020-03-18 13:52:10 --> Router Class Initialized
INFO - 2020-03-18 13:52:10 --> Output Class Initialized
INFO - 2020-03-18 13:52:10 --> Security Class Initialized
DEBUG - 2020-03-18 13:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:52:11 --> Input Class Initialized
INFO - 2020-03-18 13:52:11 --> Language Class Initialized
INFO - 2020-03-18 13:52:11 --> Language Class Initialized
INFO - 2020-03-18 13:52:11 --> Config Class Initialized
INFO - 2020-03-18 13:52:11 --> Loader Class Initialized
INFO - 2020-03-18 13:52:11 --> Helper loaded: url_helper
INFO - 2020-03-18 13:52:11 --> Helper loaded: file_helper
INFO - 2020-03-18 13:52:11 --> Helper loaded: form_helper
INFO - 2020-03-18 13:52:11 --> Helper loaded: my_helper
INFO - 2020-03-18 13:52:11 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:52:11 --> Controller Class Initialized
DEBUG - 2020-03-18 13:52:11 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-03-18 13:52:11 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 13:52:11 --> Final output sent to browser
DEBUG - 2020-03-18 13:52:13 --> Total execution time: 0.7054
INFO - 2020-03-18 13:52:21 --> Config Class Initialized
INFO - 2020-03-18 13:52:21 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:52:21 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:52:21 --> Utf8 Class Initialized
INFO - 2020-03-18 13:52:21 --> URI Class Initialized
INFO - 2020-03-18 13:52:21 --> Router Class Initialized
INFO - 2020-03-18 13:52:21 --> Output Class Initialized
INFO - 2020-03-18 13:52:21 --> Security Class Initialized
DEBUG - 2020-03-18 13:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:52:21 --> Input Class Initialized
INFO - 2020-03-18 13:52:21 --> Language Class Initialized
INFO - 2020-03-18 13:52:21 --> Language Class Initialized
INFO - 2020-03-18 13:52:21 --> Config Class Initialized
INFO - 2020-03-18 13:52:21 --> Loader Class Initialized
INFO - 2020-03-18 13:52:21 --> Helper loaded: url_helper
INFO - 2020-03-18 13:52:21 --> Helper loaded: file_helper
INFO - 2020-03-18 13:52:21 --> Helper loaded: form_helper
INFO - 2020-03-18 13:52:21 --> Helper loaded: my_helper
INFO - 2020-03-18 13:52:21 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:52:21 --> Controller Class Initialized
DEBUG - 2020-03-18 13:52:21 --> File loaded: D:\xampp\htdocs\myraport\application\modules/cetak_raport/views/list.php
DEBUG - 2020-03-18 13:52:21 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 13:52:21 --> Final output sent to browser
DEBUG - 2020-03-18 13:52:21 --> Total execution time: 0.5124
INFO - 2020-03-18 13:52:26 --> Config Class Initialized
INFO - 2020-03-18 13:52:26 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:52:26 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:52:26 --> Utf8 Class Initialized
INFO - 2020-03-18 13:52:26 --> URI Class Initialized
INFO - 2020-03-18 13:52:26 --> Router Class Initialized
INFO - 2020-03-18 13:52:26 --> Output Class Initialized
INFO - 2020-03-18 13:52:26 --> Security Class Initialized
DEBUG - 2020-03-18 13:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:52:26 --> Input Class Initialized
INFO - 2020-03-18 13:52:26 --> Language Class Initialized
INFO - 2020-03-18 13:52:26 --> Language Class Initialized
INFO - 2020-03-18 13:52:26 --> Config Class Initialized
INFO - 2020-03-18 13:52:26 --> Loader Class Initialized
INFO - 2020-03-18 13:52:26 --> Helper loaded: url_helper
INFO - 2020-03-18 13:52:27 --> Helper loaded: file_helper
INFO - 2020-03-18 13:52:27 --> Helper loaded: form_helper
INFO - 2020-03-18 13:52:27 --> Helper loaded: my_helper
INFO - 2020-03-18 13:52:27 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:52:27 --> Controller Class Initialized
DEBUG - 2020-03-18 13:52:27 --> File loaded: D:\xampp\htdocs\myraport\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-03-18 13:52:27 --> Final output sent to browser
DEBUG - 2020-03-18 13:52:27 --> Total execution time: 1.4505
INFO - 2020-03-18 13:52:35 --> Config Class Initialized
INFO - 2020-03-18 13:52:36 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:52:36 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:52:36 --> Utf8 Class Initialized
INFO - 2020-03-18 13:52:36 --> URI Class Initialized
INFO - 2020-03-18 13:52:36 --> Router Class Initialized
INFO - 2020-03-18 13:52:36 --> Output Class Initialized
INFO - 2020-03-18 13:52:36 --> Security Class Initialized
DEBUG - 2020-03-18 13:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:52:36 --> Input Class Initialized
INFO - 2020-03-18 13:52:36 --> Language Class Initialized
INFO - 2020-03-18 13:52:36 --> Language Class Initialized
INFO - 2020-03-18 13:52:36 --> Config Class Initialized
INFO - 2020-03-18 13:52:36 --> Loader Class Initialized
INFO - 2020-03-18 13:52:36 --> Helper loaded: url_helper
INFO - 2020-03-18 13:52:36 --> Helper loaded: file_helper
INFO - 2020-03-18 13:52:36 --> Helper loaded: form_helper
INFO - 2020-03-18 13:52:36 --> Helper loaded: my_helper
INFO - 2020-03-18 13:52:36 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:52:36 --> Controller Class Initialized
DEBUG - 2020-03-18 13:52:36 --> File loaded: D:\xampp\htdocs\myraport\application\modules/cetak_raport/views/cetak_prestasi.php
INFO - 2020-03-18 13:52:36 --> Final output sent to browser
DEBUG - 2020-03-18 13:52:36 --> Total execution time: 1.1204
INFO - 2020-03-18 13:52:42 --> Config Class Initialized
INFO - 2020-03-18 13:52:43 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:52:43 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:52:43 --> Utf8 Class Initialized
INFO - 2020-03-18 13:52:43 --> URI Class Initialized
INFO - 2020-03-18 13:52:43 --> Router Class Initialized
INFO - 2020-03-18 13:52:43 --> Output Class Initialized
INFO - 2020-03-18 13:52:43 --> Security Class Initialized
DEBUG - 2020-03-18 13:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:52:43 --> Input Class Initialized
INFO - 2020-03-18 13:52:43 --> Language Class Initialized
INFO - 2020-03-18 13:52:43 --> Language Class Initialized
INFO - 2020-03-18 13:52:43 --> Config Class Initialized
INFO - 2020-03-18 13:52:43 --> Loader Class Initialized
INFO - 2020-03-18 13:52:43 --> Helper loaded: url_helper
INFO - 2020-03-18 13:52:43 --> Helper loaded: file_helper
INFO - 2020-03-18 13:52:43 --> Helper loaded: form_helper
INFO - 2020-03-18 13:52:43 --> Helper loaded: my_helper
INFO - 2020-03-18 13:52:43 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:52:43 --> Controller Class Initialized
DEBUG - 2020-03-18 13:52:44 --> File loaded: D:\xampp\htdocs\myraport\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2020-03-18 13:52:44 --> Final output sent to browser
DEBUG - 2020-03-18 13:52:44 --> Total execution time: 1.1460
INFO - 2020-03-18 13:52:47 --> Config Class Initialized
INFO - 2020-03-18 13:52:47 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:52:47 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:52:47 --> Utf8 Class Initialized
INFO - 2020-03-18 13:52:47 --> URI Class Initialized
INFO - 2020-03-18 13:52:47 --> Router Class Initialized
INFO - 2020-03-18 13:52:47 --> Output Class Initialized
INFO - 2020-03-18 13:52:47 --> Security Class Initialized
DEBUG - 2020-03-18 13:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:52:47 --> Input Class Initialized
INFO - 2020-03-18 13:52:47 --> Language Class Initialized
INFO - 2020-03-18 13:52:47 --> Language Class Initialized
INFO - 2020-03-18 13:52:47 --> Config Class Initialized
INFO - 2020-03-18 13:52:48 --> Loader Class Initialized
INFO - 2020-03-18 13:52:48 --> Helper loaded: url_helper
INFO - 2020-03-18 13:52:48 --> Helper loaded: file_helper
INFO - 2020-03-18 13:52:48 --> Helper loaded: form_helper
INFO - 2020-03-18 13:52:48 --> Helper loaded: my_helper
INFO - 2020-03-18 13:52:48 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:52:48 --> Controller Class Initialized
DEBUG - 2020-03-18 13:52:48 --> File loaded: D:\xampp\htdocs\myraport\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-03-18 13:52:48 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 13:52:48 --> Final output sent to browser
DEBUG - 2020-03-18 13:52:48 --> Total execution time: 0.6735
INFO - 2020-03-18 13:52:50 --> Config Class Initialized
INFO - 2020-03-18 13:52:50 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:52:50 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:52:50 --> Utf8 Class Initialized
INFO - 2020-03-18 13:52:50 --> URI Class Initialized
INFO - 2020-03-18 13:52:50 --> Router Class Initialized
INFO - 2020-03-18 13:52:50 --> Output Class Initialized
INFO - 2020-03-18 13:52:50 --> Security Class Initialized
DEBUG - 2020-03-18 13:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:52:50 --> Input Class Initialized
INFO - 2020-03-18 13:52:50 --> Language Class Initialized
INFO - 2020-03-18 13:52:50 --> Language Class Initialized
INFO - 2020-03-18 13:52:50 --> Config Class Initialized
INFO - 2020-03-18 13:52:50 --> Loader Class Initialized
INFO - 2020-03-18 13:52:50 --> Helper loaded: url_helper
INFO - 2020-03-18 13:52:50 --> Helper loaded: file_helper
INFO - 2020-03-18 13:52:50 --> Helper loaded: form_helper
INFO - 2020-03-18 13:52:50 --> Helper loaded: my_helper
INFO - 2020-03-18 13:52:50 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:52:50 --> Controller Class Initialized
DEBUG - 2020-03-18 13:52:52 --> File loaded: D:\xampp\htdocs\myraport\application\modules/cetak_leger/views/cetak.php
INFO - 2020-03-18 13:52:52 --> Final output sent to browser
DEBUG - 2020-03-18 13:52:52 --> Total execution time: 2.3569
INFO - 2020-03-18 13:53:02 --> Config Class Initialized
INFO - 2020-03-18 13:53:02 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:53:03 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:53:03 --> Utf8 Class Initialized
INFO - 2020-03-18 13:53:03 --> URI Class Initialized
INFO - 2020-03-18 13:53:03 --> Router Class Initialized
INFO - 2020-03-18 13:53:03 --> Output Class Initialized
INFO - 2020-03-18 13:53:03 --> Security Class Initialized
DEBUG - 2020-03-18 13:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:53:03 --> Input Class Initialized
INFO - 2020-03-18 13:53:03 --> Language Class Initialized
INFO - 2020-03-18 13:53:03 --> Language Class Initialized
INFO - 2020-03-18 13:53:03 --> Config Class Initialized
INFO - 2020-03-18 13:53:03 --> Loader Class Initialized
INFO - 2020-03-18 13:53:03 --> Helper loaded: url_helper
INFO - 2020-03-18 13:53:03 --> Helper loaded: file_helper
INFO - 2020-03-18 13:53:03 --> Helper loaded: form_helper
INFO - 2020-03-18 13:53:03 --> Helper loaded: my_helper
INFO - 2020-03-18 13:53:03 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:53:03 --> Controller Class Initialized
DEBUG - 2020-03-18 13:53:03 --> File loaded: D:\xampp\htdocs\myraport\application\modules/cetak_leger/views/cetak_ekstra.php
INFO - 2020-03-18 13:53:03 --> Final output sent to browser
DEBUG - 2020-03-18 13:53:04 --> Total execution time: 1.1596
INFO - 2020-03-18 13:53:20 --> Config Class Initialized
INFO - 2020-03-18 13:53:20 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:53:20 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:53:20 --> Utf8 Class Initialized
INFO - 2020-03-18 13:53:20 --> URI Class Initialized
INFO - 2020-03-18 13:53:20 --> Router Class Initialized
INFO - 2020-03-18 13:53:20 --> Output Class Initialized
INFO - 2020-03-18 13:53:20 --> Security Class Initialized
DEBUG - 2020-03-18 13:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:53:20 --> Input Class Initialized
INFO - 2020-03-18 13:53:20 --> Language Class Initialized
INFO - 2020-03-18 13:53:20 --> Language Class Initialized
INFO - 2020-03-18 13:53:20 --> Config Class Initialized
INFO - 2020-03-18 13:53:20 --> Loader Class Initialized
INFO - 2020-03-18 13:53:20 --> Helper loaded: url_helper
INFO - 2020-03-18 13:53:20 --> Helper loaded: file_helper
INFO - 2020-03-18 13:53:20 --> Helper loaded: form_helper
INFO - 2020-03-18 13:53:20 --> Helper loaded: my_helper
INFO - 2020-03-18 13:53:20 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:53:20 --> Controller Class Initialized
DEBUG - 2020-03-18 13:53:20 --> File loaded: D:\xampp\htdocs\myraport\application\modules/cetak_raport/views/list.php
DEBUG - 2020-03-18 13:53:20 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 13:53:20 --> Final output sent to browser
DEBUG - 2020-03-18 13:53:20 --> Total execution time: 0.4698
INFO - 2020-03-18 13:53:25 --> Config Class Initialized
INFO - 2020-03-18 13:53:25 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:53:25 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:53:25 --> Utf8 Class Initialized
INFO - 2020-03-18 13:53:25 --> URI Class Initialized
INFO - 2020-03-18 13:53:25 --> Router Class Initialized
INFO - 2020-03-18 13:53:25 --> Output Class Initialized
INFO - 2020-03-18 13:53:25 --> Security Class Initialized
DEBUG - 2020-03-18 13:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:53:25 --> Input Class Initialized
INFO - 2020-03-18 13:53:25 --> Language Class Initialized
INFO - 2020-03-18 13:53:25 --> Language Class Initialized
INFO - 2020-03-18 13:53:25 --> Config Class Initialized
INFO - 2020-03-18 13:53:25 --> Loader Class Initialized
INFO - 2020-03-18 13:53:25 --> Helper loaded: url_helper
INFO - 2020-03-18 13:53:25 --> Helper loaded: file_helper
INFO - 2020-03-18 13:53:25 --> Helper loaded: form_helper
INFO - 2020-03-18 13:53:25 --> Helper loaded: my_helper
INFO - 2020-03-18 13:53:25 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:53:25 --> Controller Class Initialized
DEBUG - 2020-03-18 13:53:25 --> File loaded: D:\xampp\htdocs\myraport\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2020-03-18 13:53:25 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 13:53:25 --> Final output sent to browser
DEBUG - 2020-03-18 13:53:25 --> Total execution time: 0.4862
INFO - 2020-03-18 13:53:27 --> Config Class Initialized
INFO - 2020-03-18 13:53:27 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:53:27 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:53:27 --> Utf8 Class Initialized
INFO - 2020-03-18 13:53:27 --> URI Class Initialized
INFO - 2020-03-18 13:53:27 --> Router Class Initialized
INFO - 2020-03-18 13:53:27 --> Output Class Initialized
INFO - 2020-03-18 13:53:27 --> Security Class Initialized
DEBUG - 2020-03-18 13:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:53:27 --> Input Class Initialized
INFO - 2020-03-18 13:53:27 --> Language Class Initialized
INFO - 2020-03-18 13:53:27 --> Language Class Initialized
INFO - 2020-03-18 13:53:27 --> Config Class Initialized
INFO - 2020-03-18 13:53:27 --> Loader Class Initialized
INFO - 2020-03-18 13:53:27 --> Helper loaded: url_helper
INFO - 2020-03-18 13:53:27 --> Helper loaded: file_helper
INFO - 2020-03-18 13:53:27 --> Helper loaded: form_helper
INFO - 2020-03-18 13:53:27 --> Helper loaded: my_helper
INFO - 2020-03-18 13:53:27 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:53:27 --> Controller Class Initialized
DEBUG - 2020-03-18 13:53:27 --> File loaded: D:\xampp\htdocs\myraport\application\modules/cetak_raport/views/list.php
DEBUG - 2020-03-18 13:53:27 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 13:53:27 --> Final output sent to browser
DEBUG - 2020-03-18 13:53:27 --> Total execution time: 0.4408
INFO - 2020-03-18 13:53:30 --> Config Class Initialized
INFO - 2020-03-18 13:53:30 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:53:30 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:53:30 --> Utf8 Class Initialized
INFO - 2020-03-18 13:53:30 --> URI Class Initialized
INFO - 2020-03-18 13:53:30 --> Router Class Initialized
INFO - 2020-03-18 13:53:30 --> Output Class Initialized
INFO - 2020-03-18 13:53:30 --> Security Class Initialized
DEBUG - 2020-03-18 13:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:53:30 --> Input Class Initialized
INFO - 2020-03-18 13:53:30 --> Language Class Initialized
INFO - 2020-03-18 13:53:30 --> Language Class Initialized
INFO - 2020-03-18 13:53:30 --> Config Class Initialized
INFO - 2020-03-18 13:53:30 --> Loader Class Initialized
INFO - 2020-03-18 13:53:30 --> Helper loaded: url_helper
INFO - 2020-03-18 13:53:30 --> Helper loaded: file_helper
INFO - 2020-03-18 13:53:30 --> Helper loaded: form_helper
INFO - 2020-03-18 13:53:30 --> Helper loaded: my_helper
INFO - 2020-03-18 13:53:30 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:53:30 --> Controller Class Initialized
DEBUG - 2020-03-18 13:53:30 --> File loaded: D:\xampp\htdocs\myraport\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-03-18 13:53:30 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 13:53:30 --> Final output sent to browser
DEBUG - 2020-03-18 13:53:30 --> Total execution time: 0.5478
INFO - 2020-03-18 13:53:31 --> Config Class Initialized
INFO - 2020-03-18 13:53:31 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:53:31 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:53:31 --> Utf8 Class Initialized
INFO - 2020-03-18 13:53:31 --> URI Class Initialized
INFO - 2020-03-18 13:53:31 --> Router Class Initialized
INFO - 2020-03-18 13:53:31 --> Output Class Initialized
INFO - 2020-03-18 13:53:31 --> Security Class Initialized
DEBUG - 2020-03-18 13:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:53:32 --> Input Class Initialized
INFO - 2020-03-18 13:53:32 --> Language Class Initialized
INFO - 2020-03-18 13:53:32 --> Language Class Initialized
INFO - 2020-03-18 13:53:32 --> Config Class Initialized
INFO - 2020-03-18 13:53:32 --> Loader Class Initialized
INFO - 2020-03-18 13:53:32 --> Helper loaded: url_helper
INFO - 2020-03-18 13:53:32 --> Helper loaded: file_helper
INFO - 2020-03-18 13:53:32 --> Helper loaded: form_helper
INFO - 2020-03-18 13:53:32 --> Helper loaded: my_helper
INFO - 2020-03-18 13:53:32 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:53:32 --> Controller Class Initialized
DEBUG - 2020-03-18 13:53:32 --> File loaded: D:\xampp\htdocs\myraport\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-03-18 13:53:32 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 13:53:32 --> Final output sent to browser
DEBUG - 2020-03-18 13:53:32 --> Total execution time: 0.5378
INFO - 2020-03-18 13:53:34 --> Config Class Initialized
INFO - 2020-03-18 13:53:34 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:53:34 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:53:34 --> Utf8 Class Initialized
INFO - 2020-03-18 13:53:34 --> URI Class Initialized
INFO - 2020-03-18 13:53:34 --> Router Class Initialized
INFO - 2020-03-18 13:53:34 --> Output Class Initialized
INFO - 2020-03-18 13:53:34 --> Security Class Initialized
DEBUG - 2020-03-18 13:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:53:34 --> Input Class Initialized
INFO - 2020-03-18 13:53:34 --> Language Class Initialized
INFO - 2020-03-18 13:53:34 --> Language Class Initialized
INFO - 2020-03-18 13:53:34 --> Config Class Initialized
INFO - 2020-03-18 13:53:34 --> Loader Class Initialized
INFO - 2020-03-18 13:53:34 --> Helper loaded: url_helper
INFO - 2020-03-18 13:53:34 --> Helper loaded: file_helper
INFO - 2020-03-18 13:53:34 --> Helper loaded: form_helper
INFO - 2020-03-18 13:53:34 --> Helper loaded: my_helper
INFO - 2020-03-18 13:53:34 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:53:34 --> Controller Class Initialized
DEBUG - 2020-03-18 13:53:35 --> File loaded: D:\xampp\htdocs\myraport\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-03-18 13:53:35 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 13:53:35 --> Final output sent to browser
DEBUG - 2020-03-18 13:53:35 --> Total execution time: 0.5800
INFO - 2020-03-18 13:53:38 --> Config Class Initialized
INFO - 2020-03-18 13:53:38 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:53:38 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:53:38 --> Utf8 Class Initialized
INFO - 2020-03-18 13:53:38 --> URI Class Initialized
INFO - 2020-03-18 13:53:38 --> Router Class Initialized
INFO - 2020-03-18 13:53:38 --> Output Class Initialized
INFO - 2020-03-18 13:53:38 --> Security Class Initialized
DEBUG - 2020-03-18 13:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:53:38 --> Input Class Initialized
INFO - 2020-03-18 13:53:38 --> Language Class Initialized
INFO - 2020-03-18 13:53:38 --> Language Class Initialized
INFO - 2020-03-18 13:53:38 --> Config Class Initialized
INFO - 2020-03-18 13:53:38 --> Loader Class Initialized
INFO - 2020-03-18 13:53:38 --> Helper loaded: url_helper
INFO - 2020-03-18 13:53:38 --> Helper loaded: file_helper
INFO - 2020-03-18 13:53:38 --> Helper loaded: form_helper
INFO - 2020-03-18 13:53:38 --> Helper loaded: my_helper
INFO - 2020-03-18 13:53:38 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:53:38 --> Controller Class Initialized
DEBUG - 2020-03-18 13:53:38 --> File loaded: D:\xampp\htdocs\myraport\application\modules/n_absensi/views/list.php
DEBUG - 2020-03-18 13:53:38 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 13:53:38 --> Final output sent to browser
DEBUG - 2020-03-18 13:53:38 --> Total execution time: 0.5094
INFO - 2020-03-18 13:53:43 --> Config Class Initialized
INFO - 2020-03-18 13:53:43 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:53:43 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:53:43 --> Utf8 Class Initialized
INFO - 2020-03-18 13:53:43 --> URI Class Initialized
INFO - 2020-03-18 13:53:43 --> Router Class Initialized
INFO - 2020-03-18 13:53:43 --> Output Class Initialized
INFO - 2020-03-18 13:53:43 --> Security Class Initialized
DEBUG - 2020-03-18 13:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:53:43 --> Input Class Initialized
INFO - 2020-03-18 13:53:43 --> Language Class Initialized
INFO - 2020-03-18 13:53:43 --> Language Class Initialized
INFO - 2020-03-18 13:53:43 --> Config Class Initialized
INFO - 2020-03-18 13:53:43 --> Loader Class Initialized
INFO - 2020-03-18 13:53:44 --> Helper loaded: url_helper
INFO - 2020-03-18 13:53:44 --> Helper loaded: file_helper
INFO - 2020-03-18 13:53:44 --> Helper loaded: form_helper
INFO - 2020-03-18 13:53:44 --> Helper loaded: my_helper
INFO - 2020-03-18 13:53:44 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:53:44 --> Controller Class Initialized
DEBUG - 2020-03-18 13:53:44 --> File loaded: D:\xampp\htdocs\myraport\application\modules/n_absensi/views/cetak.php
INFO - 2020-03-18 13:53:44 --> Final output sent to browser
DEBUG - 2020-03-18 13:53:44 --> Total execution time: 1.2077
INFO - 2020-03-18 13:53:54 --> Config Class Initialized
INFO - 2020-03-18 13:53:54 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:53:54 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:53:54 --> Utf8 Class Initialized
INFO - 2020-03-18 13:53:54 --> URI Class Initialized
INFO - 2020-03-18 13:53:54 --> Router Class Initialized
INFO - 2020-03-18 13:53:54 --> Output Class Initialized
INFO - 2020-03-18 13:53:54 --> Security Class Initialized
DEBUG - 2020-03-18 13:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:53:54 --> Input Class Initialized
INFO - 2020-03-18 13:53:54 --> Language Class Initialized
INFO - 2020-03-18 13:53:54 --> Language Class Initialized
INFO - 2020-03-18 13:53:54 --> Config Class Initialized
INFO - 2020-03-18 13:53:54 --> Loader Class Initialized
INFO - 2020-03-18 13:53:54 --> Helper loaded: url_helper
INFO - 2020-03-18 13:53:54 --> Helper loaded: file_helper
INFO - 2020-03-18 13:53:54 --> Helper loaded: form_helper
INFO - 2020-03-18 13:53:54 --> Helper loaded: my_helper
INFO - 2020-03-18 13:53:54 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:53:54 --> Controller Class Initialized
DEBUG - 2020-03-18 13:53:55 --> File loaded: D:\xampp\htdocs\myraport\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-03-18 13:53:55 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 13:53:55 --> Final output sent to browser
DEBUG - 2020-03-18 13:53:55 --> Total execution time: 0.4943
INFO - 2020-03-18 13:53:56 --> Config Class Initialized
INFO - 2020-03-18 13:53:56 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:53:56 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:53:56 --> Utf8 Class Initialized
INFO - 2020-03-18 13:53:56 --> URI Class Initialized
INFO - 2020-03-18 13:53:56 --> Router Class Initialized
INFO - 2020-03-18 13:53:56 --> Output Class Initialized
INFO - 2020-03-18 13:53:56 --> Security Class Initialized
DEBUG - 2020-03-18 13:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:53:56 --> Input Class Initialized
INFO - 2020-03-18 13:53:56 --> Language Class Initialized
INFO - 2020-03-18 13:53:57 --> Language Class Initialized
INFO - 2020-03-18 13:53:57 --> Config Class Initialized
INFO - 2020-03-18 13:53:57 --> Loader Class Initialized
INFO - 2020-03-18 13:53:57 --> Helper loaded: url_helper
INFO - 2020-03-18 13:53:57 --> Helper loaded: file_helper
INFO - 2020-03-18 13:53:57 --> Helper loaded: form_helper
INFO - 2020-03-18 13:53:57 --> Helper loaded: my_helper
INFO - 2020-03-18 13:53:57 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:53:57 --> Controller Class Initialized
DEBUG - 2020-03-18 13:53:57 --> File loaded: D:\xampp\htdocs\myraport\application\modules/n_absensi/views/list.php
DEBUG - 2020-03-18 13:53:57 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 13:53:57 --> Final output sent to browser
DEBUG - 2020-03-18 13:53:57 --> Total execution time: 0.4785
INFO - 2020-03-18 13:54:00 --> Config Class Initialized
INFO - 2020-03-18 13:54:00 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:54:00 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:54:00 --> Utf8 Class Initialized
INFO - 2020-03-18 13:54:00 --> URI Class Initialized
INFO - 2020-03-18 13:54:00 --> Router Class Initialized
INFO - 2020-03-18 13:54:00 --> Output Class Initialized
INFO - 2020-03-18 13:54:00 --> Security Class Initialized
DEBUG - 2020-03-18 13:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:54:00 --> Input Class Initialized
INFO - 2020-03-18 13:54:00 --> Language Class Initialized
INFO - 2020-03-18 13:54:00 --> Language Class Initialized
INFO - 2020-03-18 13:54:00 --> Config Class Initialized
INFO - 2020-03-18 13:54:00 --> Loader Class Initialized
INFO - 2020-03-18 13:54:00 --> Helper loaded: url_helper
INFO - 2020-03-18 13:54:00 --> Helper loaded: file_helper
INFO - 2020-03-18 13:54:00 --> Helper loaded: form_helper
INFO - 2020-03-18 13:54:00 --> Helper loaded: my_helper
INFO - 2020-03-18 13:54:00 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:54:00 --> Controller Class Initialized
DEBUG - 2020-03-18 13:54:00 --> File loaded: D:\xampp\htdocs\myraport\application\modules/cetak_raport/views/list.php
DEBUG - 2020-03-18 13:54:00 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 13:54:00 --> Final output sent to browser
DEBUG - 2020-03-18 13:54:00 --> Total execution time: 0.6785
INFO - 2020-03-18 13:54:02 --> Config Class Initialized
INFO - 2020-03-18 13:54:02 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:54:02 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:54:03 --> Utf8 Class Initialized
INFO - 2020-03-18 13:54:03 --> URI Class Initialized
INFO - 2020-03-18 13:54:03 --> Router Class Initialized
INFO - 2020-03-18 13:54:03 --> Output Class Initialized
INFO - 2020-03-18 13:54:03 --> Security Class Initialized
DEBUG - 2020-03-18 13:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:54:03 --> Input Class Initialized
INFO - 2020-03-18 13:54:03 --> Language Class Initialized
INFO - 2020-03-18 13:54:03 --> Language Class Initialized
INFO - 2020-03-18 13:54:03 --> Config Class Initialized
INFO - 2020-03-18 13:54:03 --> Loader Class Initialized
INFO - 2020-03-18 13:54:03 --> Helper loaded: url_helper
INFO - 2020-03-18 13:54:03 --> Helper loaded: file_helper
INFO - 2020-03-18 13:54:03 --> Helper loaded: form_helper
INFO - 2020-03-18 13:54:03 --> Helper loaded: my_helper
INFO - 2020-03-18 13:54:03 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:54:03 --> Controller Class Initialized
DEBUG - 2020-03-18 13:54:03 --> File loaded: D:\xampp\htdocs\myraport\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2020-03-18 13:54:03 --> Final output sent to browser
DEBUG - 2020-03-18 13:54:03 --> Total execution time: 1.1616
INFO - 2020-03-18 13:55:20 --> Config Class Initialized
INFO - 2020-03-18 13:55:21 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:55:21 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:55:21 --> Utf8 Class Initialized
INFO - 2020-03-18 13:55:21 --> URI Class Initialized
INFO - 2020-03-18 13:55:21 --> Router Class Initialized
INFO - 2020-03-18 13:55:21 --> Output Class Initialized
INFO - 2020-03-18 13:55:21 --> Security Class Initialized
DEBUG - 2020-03-18 13:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:55:21 --> Input Class Initialized
INFO - 2020-03-18 13:55:21 --> Language Class Initialized
INFO - 2020-03-18 13:55:21 --> Language Class Initialized
INFO - 2020-03-18 13:55:21 --> Config Class Initialized
INFO - 2020-03-18 13:55:21 --> Loader Class Initialized
INFO - 2020-03-18 13:55:21 --> Helper loaded: url_helper
INFO - 2020-03-18 13:55:21 --> Helper loaded: file_helper
INFO - 2020-03-18 13:55:22 --> Helper loaded: form_helper
INFO - 2020-03-18 13:55:22 --> Helper loaded: my_helper
INFO - 2020-03-18 13:55:22 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:55:22 --> Controller Class Initialized
DEBUG - 2020-03-18 13:55:22 --> File loaded: D:\xampp\htdocs\myraport\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2020-03-18 13:55:22 --> Final output sent to browser
DEBUG - 2020-03-18 13:55:22 --> Total execution time: 1.9671
INFO - 2020-03-18 13:56:03 --> Config Class Initialized
INFO - 2020-03-18 13:56:03 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:56:03 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:56:03 --> Utf8 Class Initialized
INFO - 2020-03-18 13:56:03 --> URI Class Initialized
INFO - 2020-03-18 13:56:03 --> Router Class Initialized
INFO - 2020-03-18 13:56:03 --> Output Class Initialized
INFO - 2020-03-18 13:56:03 --> Security Class Initialized
DEBUG - 2020-03-18 13:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:56:03 --> Input Class Initialized
INFO - 2020-03-18 13:56:03 --> Language Class Initialized
INFO - 2020-03-18 13:56:03 --> Language Class Initialized
INFO - 2020-03-18 13:56:03 --> Config Class Initialized
INFO - 2020-03-18 13:56:03 --> Loader Class Initialized
INFO - 2020-03-18 13:56:03 --> Helper loaded: url_helper
INFO - 2020-03-18 13:56:03 --> Helper loaded: file_helper
INFO - 2020-03-18 13:56:03 --> Helper loaded: form_helper
INFO - 2020-03-18 13:56:03 --> Helper loaded: my_helper
INFO - 2020-03-18 13:56:03 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:56:03 --> Controller Class Initialized
INFO - 2020-03-18 13:56:03 --> Helper loaded: cookie_helper
INFO - 2020-03-18 13:56:03 --> Config Class Initialized
INFO - 2020-03-18 13:56:03 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:56:03 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:56:03 --> Utf8 Class Initialized
INFO - 2020-03-18 13:56:03 --> URI Class Initialized
INFO - 2020-03-18 13:56:03 --> Router Class Initialized
INFO - 2020-03-18 13:56:03 --> Output Class Initialized
INFO - 2020-03-18 13:56:03 --> Security Class Initialized
DEBUG - 2020-03-18 13:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:56:03 --> Input Class Initialized
INFO - 2020-03-18 13:56:03 --> Language Class Initialized
INFO - 2020-03-18 13:56:03 --> Language Class Initialized
INFO - 2020-03-18 13:56:03 --> Config Class Initialized
INFO - 2020-03-18 13:56:03 --> Loader Class Initialized
INFO - 2020-03-18 13:56:04 --> Helper loaded: url_helper
INFO - 2020-03-18 13:56:04 --> Helper loaded: file_helper
INFO - 2020-03-18 13:56:04 --> Helper loaded: form_helper
INFO - 2020-03-18 13:56:04 --> Helper loaded: my_helper
INFO - 2020-03-18 13:56:04 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:56:04 --> Controller Class Initialized
INFO - 2020-03-18 13:56:04 --> Config Class Initialized
INFO - 2020-03-18 13:56:04 --> Hooks Class Initialized
DEBUG - 2020-03-18 13:56:04 --> UTF-8 Support Enabled
INFO - 2020-03-18 13:56:04 --> Utf8 Class Initialized
INFO - 2020-03-18 13:56:04 --> URI Class Initialized
INFO - 2020-03-18 13:56:04 --> Router Class Initialized
INFO - 2020-03-18 13:56:04 --> Output Class Initialized
INFO - 2020-03-18 13:56:04 --> Security Class Initialized
DEBUG - 2020-03-18 13:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 13:56:04 --> Input Class Initialized
INFO - 2020-03-18 13:56:04 --> Language Class Initialized
INFO - 2020-03-18 13:56:04 --> Language Class Initialized
INFO - 2020-03-18 13:56:04 --> Config Class Initialized
INFO - 2020-03-18 13:56:04 --> Loader Class Initialized
INFO - 2020-03-18 13:56:04 --> Helper loaded: url_helper
INFO - 2020-03-18 13:56:04 --> Helper loaded: file_helper
INFO - 2020-03-18 13:56:04 --> Helper loaded: form_helper
INFO - 2020-03-18 13:56:04 --> Helper loaded: my_helper
INFO - 2020-03-18 13:56:04 --> Database Driver Class Initialized
DEBUG - 2020-03-18 13:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 13:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 13:56:04 --> Controller Class Initialized
DEBUG - 2020-03-18 13:56:04 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 13:56:04 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 13:56:04 --> Final output sent to browser
DEBUG - 2020-03-18 13:56:04 --> Total execution time: 0.4439
INFO - 2020-03-18 14:21:02 --> Config Class Initialized
INFO - 2020-03-18 14:21:02 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:21:02 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:21:02 --> Utf8 Class Initialized
INFO - 2020-03-18 14:21:02 --> URI Class Initialized
INFO - 2020-03-18 14:21:02 --> Router Class Initialized
INFO - 2020-03-18 14:21:02 --> Output Class Initialized
INFO - 2020-03-18 14:21:02 --> Security Class Initialized
DEBUG - 2020-03-18 14:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:21:02 --> Input Class Initialized
INFO - 2020-03-18 14:21:02 --> Language Class Initialized
INFO - 2020-03-18 14:21:02 --> Language Class Initialized
INFO - 2020-03-18 14:21:03 --> Config Class Initialized
INFO - 2020-03-18 14:21:03 --> Loader Class Initialized
INFO - 2020-03-18 14:21:03 --> Helper loaded: url_helper
INFO - 2020-03-18 14:21:03 --> Helper loaded: file_helper
INFO - 2020-03-18 14:21:03 --> Helper loaded: form_helper
INFO - 2020-03-18 14:21:03 --> Helper loaded: my_helper
INFO - 2020-03-18 14:21:03 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:21:03 --> Controller Class Initialized
DEBUG - 2020-03-18 14:21:03 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 14:21:03 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 14:21:03 --> Final output sent to browser
DEBUG - 2020-03-18 14:21:03 --> Total execution time: 0.8284
INFO - 2020-03-18 14:21:22 --> Config Class Initialized
INFO - 2020-03-18 14:21:22 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:21:22 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:21:22 --> Utf8 Class Initialized
INFO - 2020-03-18 14:21:22 --> URI Class Initialized
DEBUG - 2020-03-18 14:21:22 --> No URI present. Default controller set.
INFO - 2020-03-18 14:21:22 --> Router Class Initialized
INFO - 2020-03-18 14:21:22 --> Output Class Initialized
INFO - 2020-03-18 14:21:22 --> Security Class Initialized
DEBUG - 2020-03-18 14:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:21:22 --> Input Class Initialized
INFO - 2020-03-18 14:21:22 --> Language Class Initialized
INFO - 2020-03-18 14:21:22 --> Language Class Initialized
INFO - 2020-03-18 14:21:22 --> Config Class Initialized
INFO - 2020-03-18 14:21:22 --> Loader Class Initialized
INFO - 2020-03-18 14:21:22 --> Helper loaded: url_helper
INFO - 2020-03-18 14:21:22 --> Helper loaded: file_helper
INFO - 2020-03-18 14:21:22 --> Helper loaded: form_helper
INFO - 2020-03-18 14:21:22 --> Helper loaded: my_helper
INFO - 2020-03-18 14:21:23 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:21:23 --> Controller Class Initialized
INFO - 2020-03-18 14:21:23 --> Config Class Initialized
INFO - 2020-03-18 14:21:23 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:21:23 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:21:23 --> Utf8 Class Initialized
INFO - 2020-03-18 14:21:23 --> URI Class Initialized
INFO - 2020-03-18 14:21:23 --> Router Class Initialized
INFO - 2020-03-18 14:21:23 --> Output Class Initialized
INFO - 2020-03-18 14:21:23 --> Security Class Initialized
DEBUG - 2020-03-18 14:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:21:23 --> Input Class Initialized
INFO - 2020-03-18 14:21:23 --> Language Class Initialized
INFO - 2020-03-18 14:21:23 --> Language Class Initialized
INFO - 2020-03-18 14:21:23 --> Config Class Initialized
INFO - 2020-03-18 14:21:23 --> Loader Class Initialized
INFO - 2020-03-18 14:21:23 --> Helper loaded: url_helper
INFO - 2020-03-18 14:21:23 --> Helper loaded: file_helper
INFO - 2020-03-18 14:21:23 --> Helper loaded: form_helper
INFO - 2020-03-18 14:21:23 --> Helper loaded: my_helper
INFO - 2020-03-18 14:21:23 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:21:23 --> Controller Class Initialized
DEBUG - 2020-03-18 14:21:23 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 14:21:23 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 14:21:23 --> Final output sent to browser
DEBUG - 2020-03-18 14:21:23 --> Total execution time: 0.4657
INFO - 2020-03-18 14:21:57 --> Config Class Initialized
INFO - 2020-03-18 14:21:57 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:21:57 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:21:57 --> Utf8 Class Initialized
INFO - 2020-03-18 14:21:57 --> URI Class Initialized
INFO - 2020-03-18 14:21:57 --> Router Class Initialized
INFO - 2020-03-18 14:21:57 --> Output Class Initialized
INFO - 2020-03-18 14:21:57 --> Security Class Initialized
DEBUG - 2020-03-18 14:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:21:57 --> Input Class Initialized
INFO - 2020-03-18 14:21:57 --> Language Class Initialized
INFO - 2020-03-18 14:21:57 --> Language Class Initialized
INFO - 2020-03-18 14:21:57 --> Config Class Initialized
INFO - 2020-03-18 14:21:57 --> Loader Class Initialized
INFO - 2020-03-18 14:21:57 --> Helper loaded: url_helper
INFO - 2020-03-18 14:21:57 --> Helper loaded: file_helper
INFO - 2020-03-18 14:21:57 --> Helper loaded: form_helper
INFO - 2020-03-18 14:21:57 --> Helper loaded: my_helper
INFO - 2020-03-18 14:21:57 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:21:57 --> Controller Class Initialized
DEBUG - 2020-03-18 14:21:57 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 14:21:57 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 14:21:57 --> Final output sent to browser
DEBUG - 2020-03-18 14:21:57 --> Total execution time: 0.5774
INFO - 2020-03-18 14:22:43 --> Config Class Initialized
INFO - 2020-03-18 14:22:43 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:22:43 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:22:43 --> Utf8 Class Initialized
INFO - 2020-03-18 14:22:43 --> URI Class Initialized
INFO - 2020-03-18 14:22:44 --> Router Class Initialized
INFO - 2020-03-18 14:22:44 --> Output Class Initialized
INFO - 2020-03-18 14:22:44 --> Security Class Initialized
DEBUG - 2020-03-18 14:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:22:44 --> Input Class Initialized
INFO - 2020-03-18 14:22:44 --> Language Class Initialized
INFO - 2020-03-18 14:22:44 --> Language Class Initialized
INFO - 2020-03-18 14:22:44 --> Config Class Initialized
INFO - 2020-03-18 14:22:44 --> Loader Class Initialized
INFO - 2020-03-18 14:22:44 --> Helper loaded: url_helper
INFO - 2020-03-18 14:22:44 --> Helper loaded: file_helper
INFO - 2020-03-18 14:22:44 --> Helper loaded: form_helper
INFO - 2020-03-18 14:22:44 --> Helper loaded: my_helper
INFO - 2020-03-18 14:22:44 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:22:44 --> Controller Class Initialized
DEBUG - 2020-03-18 14:22:44 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 14:22:44 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 14:22:44 --> Final output sent to browser
DEBUG - 2020-03-18 14:22:44 --> Total execution time: 0.5129
INFO - 2020-03-18 14:22:49 --> Config Class Initialized
INFO - 2020-03-18 14:22:49 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:22:49 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:22:49 --> Utf8 Class Initialized
INFO - 2020-03-18 14:22:49 --> URI Class Initialized
INFO - 2020-03-18 14:22:49 --> Router Class Initialized
INFO - 2020-03-18 14:22:49 --> Output Class Initialized
INFO - 2020-03-18 14:22:49 --> Security Class Initialized
DEBUG - 2020-03-18 14:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:22:49 --> Input Class Initialized
INFO - 2020-03-18 14:22:49 --> Language Class Initialized
INFO - 2020-03-18 14:22:49 --> Language Class Initialized
INFO - 2020-03-18 14:22:49 --> Config Class Initialized
INFO - 2020-03-18 14:22:49 --> Loader Class Initialized
INFO - 2020-03-18 14:22:49 --> Helper loaded: url_helper
INFO - 2020-03-18 14:22:49 --> Helper loaded: file_helper
INFO - 2020-03-18 14:22:49 --> Helper loaded: form_helper
INFO - 2020-03-18 14:22:49 --> Helper loaded: my_helper
INFO - 2020-03-18 14:22:49 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:22:49 --> Controller Class Initialized
DEBUG - 2020-03-18 14:22:49 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 14:22:49 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 14:22:49 --> Final output sent to browser
DEBUG - 2020-03-18 14:22:49 --> Total execution time: 0.4752
INFO - 2020-03-18 14:22:50 --> Config Class Initialized
INFO - 2020-03-18 14:22:50 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:22:50 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:22:50 --> Utf8 Class Initialized
INFO - 2020-03-18 14:22:50 --> URI Class Initialized
INFO - 2020-03-18 14:22:50 --> Router Class Initialized
INFO - 2020-03-18 14:22:50 --> Output Class Initialized
INFO - 2020-03-18 14:22:50 --> Security Class Initialized
DEBUG - 2020-03-18 14:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:22:50 --> Input Class Initialized
INFO - 2020-03-18 14:22:50 --> Language Class Initialized
INFO - 2020-03-18 14:22:50 --> Language Class Initialized
INFO - 2020-03-18 14:22:50 --> Config Class Initialized
INFO - 2020-03-18 14:22:51 --> Loader Class Initialized
INFO - 2020-03-18 14:22:51 --> Helper loaded: url_helper
INFO - 2020-03-18 14:22:51 --> Helper loaded: file_helper
INFO - 2020-03-18 14:22:51 --> Helper loaded: form_helper
INFO - 2020-03-18 14:22:51 --> Helper loaded: my_helper
INFO - 2020-03-18 14:22:51 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:22:51 --> Controller Class Initialized
DEBUG - 2020-03-18 14:22:51 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 14:22:51 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 14:22:51 --> Final output sent to browser
DEBUG - 2020-03-18 14:22:51 --> Total execution time: 0.4713
INFO - 2020-03-18 14:28:01 --> Config Class Initialized
INFO - 2020-03-18 14:28:01 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:28:01 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:28:01 --> Utf8 Class Initialized
INFO - 2020-03-18 14:28:01 --> URI Class Initialized
INFO - 2020-03-18 14:28:01 --> Router Class Initialized
INFO - 2020-03-18 14:28:01 --> Output Class Initialized
INFO - 2020-03-18 14:28:01 --> Security Class Initialized
DEBUG - 2020-03-18 14:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:28:01 --> Input Class Initialized
INFO - 2020-03-18 14:28:01 --> Language Class Initialized
INFO - 2020-03-18 14:28:01 --> Language Class Initialized
INFO - 2020-03-18 14:28:02 --> Config Class Initialized
INFO - 2020-03-18 14:28:02 --> Loader Class Initialized
INFO - 2020-03-18 14:28:02 --> Helper loaded: url_helper
INFO - 2020-03-18 14:28:02 --> Helper loaded: file_helper
INFO - 2020-03-18 14:28:02 --> Helper loaded: form_helper
INFO - 2020-03-18 14:28:02 --> Helper loaded: my_helper
INFO - 2020-03-18 14:28:02 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:28:02 --> Controller Class Initialized
DEBUG - 2020-03-18 14:28:02 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 14:28:02 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 14:28:02 --> Final output sent to browser
DEBUG - 2020-03-18 14:28:02 --> Total execution time: 0.5671
INFO - 2020-03-18 14:28:23 --> Config Class Initialized
INFO - 2020-03-18 14:28:23 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:28:23 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:28:23 --> Utf8 Class Initialized
INFO - 2020-03-18 14:28:23 --> URI Class Initialized
INFO - 2020-03-18 14:28:23 --> Router Class Initialized
INFO - 2020-03-18 14:28:23 --> Output Class Initialized
INFO - 2020-03-18 14:28:23 --> Security Class Initialized
DEBUG - 2020-03-18 14:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:28:23 --> Input Class Initialized
INFO - 2020-03-18 14:28:23 --> Language Class Initialized
INFO - 2020-03-18 14:28:23 --> Language Class Initialized
INFO - 2020-03-18 14:28:23 --> Config Class Initialized
INFO - 2020-03-18 14:28:23 --> Loader Class Initialized
INFO - 2020-03-18 14:28:23 --> Helper loaded: url_helper
INFO - 2020-03-18 14:28:23 --> Helper loaded: file_helper
INFO - 2020-03-18 14:28:23 --> Helper loaded: form_helper
INFO - 2020-03-18 14:28:23 --> Helper loaded: my_helper
INFO - 2020-03-18 14:28:23 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:28:24 --> Controller Class Initialized
DEBUG - 2020-03-18 14:28:24 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 14:28:24 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 14:28:24 --> Final output sent to browser
DEBUG - 2020-03-18 14:28:24 --> Total execution time: 0.7523
INFO - 2020-03-18 14:29:08 --> Config Class Initialized
INFO - 2020-03-18 14:29:08 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:29:08 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:29:08 --> Utf8 Class Initialized
INFO - 2020-03-18 14:29:08 --> URI Class Initialized
INFO - 2020-03-18 14:29:08 --> Router Class Initialized
INFO - 2020-03-18 14:29:08 --> Output Class Initialized
INFO - 2020-03-18 14:29:08 --> Security Class Initialized
DEBUG - 2020-03-18 14:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:29:08 --> Input Class Initialized
INFO - 2020-03-18 14:29:08 --> Language Class Initialized
INFO - 2020-03-18 14:29:08 --> Language Class Initialized
INFO - 2020-03-18 14:29:08 --> Config Class Initialized
INFO - 2020-03-18 14:29:08 --> Loader Class Initialized
INFO - 2020-03-18 14:29:08 --> Helper loaded: url_helper
INFO - 2020-03-18 14:29:08 --> Helper loaded: file_helper
INFO - 2020-03-18 14:29:08 --> Helper loaded: form_helper
INFO - 2020-03-18 14:29:08 --> Helper loaded: my_helper
INFO - 2020-03-18 14:29:08 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:29:08 --> Controller Class Initialized
DEBUG - 2020-03-18 14:29:09 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 14:29:09 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 14:29:09 --> Final output sent to browser
DEBUG - 2020-03-18 14:29:09 --> Total execution time: 0.6261
INFO - 2020-03-18 14:32:26 --> Config Class Initialized
INFO - 2020-03-18 14:32:26 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:32:26 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:32:26 --> Utf8 Class Initialized
INFO - 2020-03-18 14:32:26 --> URI Class Initialized
INFO - 2020-03-18 14:32:26 --> Router Class Initialized
INFO - 2020-03-18 14:32:26 --> Output Class Initialized
INFO - 2020-03-18 14:32:26 --> Security Class Initialized
DEBUG - 2020-03-18 14:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:32:26 --> Input Class Initialized
INFO - 2020-03-18 14:32:26 --> Language Class Initialized
INFO - 2020-03-18 14:32:26 --> Language Class Initialized
INFO - 2020-03-18 14:32:26 --> Config Class Initialized
INFO - 2020-03-18 14:32:26 --> Loader Class Initialized
INFO - 2020-03-18 14:32:26 --> Helper loaded: url_helper
INFO - 2020-03-18 14:32:26 --> Helper loaded: file_helper
INFO - 2020-03-18 14:32:26 --> Helper loaded: form_helper
INFO - 2020-03-18 14:32:26 --> Helper loaded: my_helper
INFO - 2020-03-18 14:32:26 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:32:26 --> Controller Class Initialized
DEBUG - 2020-03-18 14:32:26 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 14:32:26 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 14:32:26 --> Final output sent to browser
DEBUG - 2020-03-18 14:32:27 --> Total execution time: 0.5728
INFO - 2020-03-18 14:35:05 --> Config Class Initialized
INFO - 2020-03-18 14:35:05 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:35:06 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:35:06 --> Utf8 Class Initialized
INFO - 2020-03-18 14:35:06 --> URI Class Initialized
INFO - 2020-03-18 14:35:06 --> Router Class Initialized
INFO - 2020-03-18 14:35:06 --> Output Class Initialized
INFO - 2020-03-18 14:35:06 --> Security Class Initialized
DEBUG - 2020-03-18 14:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:35:06 --> Input Class Initialized
INFO - 2020-03-18 14:35:06 --> Language Class Initialized
INFO - 2020-03-18 14:35:06 --> Language Class Initialized
INFO - 2020-03-18 14:35:06 --> Config Class Initialized
INFO - 2020-03-18 14:35:06 --> Loader Class Initialized
INFO - 2020-03-18 14:35:06 --> Helper loaded: url_helper
INFO - 2020-03-18 14:35:06 --> Helper loaded: file_helper
INFO - 2020-03-18 14:35:06 --> Helper loaded: form_helper
INFO - 2020-03-18 14:35:06 --> Helper loaded: my_helper
INFO - 2020-03-18 14:35:06 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:35:06 --> Controller Class Initialized
DEBUG - 2020-03-18 14:35:06 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 14:35:06 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 14:35:06 --> Final output sent to browser
DEBUG - 2020-03-18 14:35:07 --> Total execution time: 0.6840
INFO - 2020-03-18 14:35:15 --> Config Class Initialized
INFO - 2020-03-18 14:35:15 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:35:15 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:35:15 --> Utf8 Class Initialized
INFO - 2020-03-18 14:35:15 --> URI Class Initialized
INFO - 2020-03-18 14:35:15 --> Router Class Initialized
INFO - 2020-03-18 14:35:15 --> Output Class Initialized
INFO - 2020-03-18 14:35:15 --> Security Class Initialized
DEBUG - 2020-03-18 14:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:35:15 --> Input Class Initialized
INFO - 2020-03-18 14:35:15 --> Language Class Initialized
INFO - 2020-03-18 14:35:15 --> Language Class Initialized
INFO - 2020-03-18 14:35:15 --> Config Class Initialized
INFO - 2020-03-18 14:35:15 --> Loader Class Initialized
INFO - 2020-03-18 14:35:15 --> Helper loaded: url_helper
INFO - 2020-03-18 14:35:15 --> Helper loaded: file_helper
INFO - 2020-03-18 14:35:15 --> Helper loaded: form_helper
INFO - 2020-03-18 14:35:15 --> Helper loaded: my_helper
INFO - 2020-03-18 14:35:15 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:35:15 --> Controller Class Initialized
DEBUG - 2020-03-18 14:35:15 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 14:35:15 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 14:35:15 --> Final output sent to browser
DEBUG - 2020-03-18 14:35:16 --> Total execution time: 0.7722
INFO - 2020-03-18 14:35:33 --> Config Class Initialized
INFO - 2020-03-18 14:35:33 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:35:33 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:35:33 --> Utf8 Class Initialized
INFO - 2020-03-18 14:35:33 --> URI Class Initialized
INFO - 2020-03-18 14:35:33 --> Router Class Initialized
INFO - 2020-03-18 14:35:33 --> Output Class Initialized
INFO - 2020-03-18 14:35:33 --> Security Class Initialized
DEBUG - 2020-03-18 14:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:35:33 --> Input Class Initialized
INFO - 2020-03-18 14:35:33 --> Language Class Initialized
INFO - 2020-03-18 14:35:33 --> Language Class Initialized
INFO - 2020-03-18 14:35:33 --> Config Class Initialized
INFO - 2020-03-18 14:35:33 --> Loader Class Initialized
INFO - 2020-03-18 14:35:33 --> Helper loaded: url_helper
INFO - 2020-03-18 14:35:33 --> Helper loaded: file_helper
INFO - 2020-03-18 14:35:33 --> Helper loaded: form_helper
INFO - 2020-03-18 14:35:34 --> Helper loaded: my_helper
INFO - 2020-03-18 14:35:34 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:35:34 --> Controller Class Initialized
DEBUG - 2020-03-18 14:35:34 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 14:35:34 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 14:35:34 --> Final output sent to browser
DEBUG - 2020-03-18 14:35:34 --> Total execution time: 0.6156
INFO - 2020-03-18 14:35:48 --> Config Class Initialized
INFO - 2020-03-18 14:35:48 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:35:48 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:35:48 --> Utf8 Class Initialized
INFO - 2020-03-18 14:35:48 --> URI Class Initialized
INFO - 2020-03-18 14:35:48 --> Router Class Initialized
INFO - 2020-03-18 14:35:48 --> Output Class Initialized
INFO - 2020-03-18 14:35:48 --> Security Class Initialized
DEBUG - 2020-03-18 14:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:35:48 --> Input Class Initialized
INFO - 2020-03-18 14:35:48 --> Language Class Initialized
INFO - 2020-03-18 14:35:48 --> Language Class Initialized
INFO - 2020-03-18 14:35:48 --> Config Class Initialized
INFO - 2020-03-18 14:35:48 --> Loader Class Initialized
INFO - 2020-03-18 14:35:48 --> Helper loaded: url_helper
INFO - 2020-03-18 14:35:48 --> Helper loaded: file_helper
INFO - 2020-03-18 14:35:48 --> Helper loaded: form_helper
INFO - 2020-03-18 14:35:48 --> Helper loaded: my_helper
INFO - 2020-03-18 14:35:48 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:35:48 --> Controller Class Initialized
DEBUG - 2020-03-18 14:35:49 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 14:35:49 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 14:35:49 --> Final output sent to browser
DEBUG - 2020-03-18 14:35:49 --> Total execution time: 0.5887
INFO - 2020-03-18 14:36:33 --> Config Class Initialized
INFO - 2020-03-18 14:36:34 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:36:34 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:36:34 --> Utf8 Class Initialized
INFO - 2020-03-18 14:36:34 --> URI Class Initialized
INFO - 2020-03-18 14:36:34 --> Router Class Initialized
INFO - 2020-03-18 14:36:34 --> Output Class Initialized
INFO - 2020-03-18 14:36:34 --> Security Class Initialized
DEBUG - 2020-03-18 14:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:36:34 --> Input Class Initialized
INFO - 2020-03-18 14:36:34 --> Language Class Initialized
INFO - 2020-03-18 14:36:34 --> Language Class Initialized
INFO - 2020-03-18 14:36:34 --> Config Class Initialized
INFO - 2020-03-18 14:36:34 --> Loader Class Initialized
INFO - 2020-03-18 14:36:34 --> Helper loaded: url_helper
INFO - 2020-03-18 14:36:34 --> Helper loaded: file_helper
INFO - 2020-03-18 14:36:34 --> Helper loaded: form_helper
INFO - 2020-03-18 14:36:34 --> Helper loaded: my_helper
INFO - 2020-03-18 14:36:34 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:36:34 --> Controller Class Initialized
DEBUG - 2020-03-18 14:36:34 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 14:36:34 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 14:36:34 --> Final output sent to browser
DEBUG - 2020-03-18 14:36:34 --> Total execution time: 0.5605
INFO - 2020-03-18 14:36:38 --> Config Class Initialized
INFO - 2020-03-18 14:36:38 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:36:38 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:36:38 --> Utf8 Class Initialized
INFO - 2020-03-18 14:36:38 --> URI Class Initialized
INFO - 2020-03-18 14:36:38 --> Router Class Initialized
INFO - 2020-03-18 14:36:38 --> Output Class Initialized
INFO - 2020-03-18 14:36:38 --> Security Class Initialized
DEBUG - 2020-03-18 14:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:36:39 --> Input Class Initialized
INFO - 2020-03-18 14:36:39 --> Language Class Initialized
INFO - 2020-03-18 14:36:39 --> Language Class Initialized
INFO - 2020-03-18 14:36:39 --> Config Class Initialized
INFO - 2020-03-18 14:36:39 --> Loader Class Initialized
INFO - 2020-03-18 14:36:39 --> Helper loaded: url_helper
INFO - 2020-03-18 14:36:39 --> Helper loaded: file_helper
INFO - 2020-03-18 14:36:39 --> Helper loaded: form_helper
INFO - 2020-03-18 14:36:39 --> Helper loaded: my_helper
INFO - 2020-03-18 14:36:39 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:36:39 --> Controller Class Initialized
DEBUG - 2020-03-18 14:36:39 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 14:36:39 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 14:36:39 --> Final output sent to browser
DEBUG - 2020-03-18 14:36:39 --> Total execution time: 0.5562
INFO - 2020-03-18 14:36:52 --> Config Class Initialized
INFO - 2020-03-18 14:36:52 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:36:52 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:36:53 --> Utf8 Class Initialized
INFO - 2020-03-18 14:36:53 --> URI Class Initialized
INFO - 2020-03-18 14:36:53 --> Router Class Initialized
INFO - 2020-03-18 14:36:53 --> Output Class Initialized
INFO - 2020-03-18 14:36:53 --> Security Class Initialized
DEBUG - 2020-03-18 14:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:36:53 --> Input Class Initialized
INFO - 2020-03-18 14:36:53 --> Language Class Initialized
INFO - 2020-03-18 14:36:53 --> Language Class Initialized
INFO - 2020-03-18 14:36:53 --> Config Class Initialized
INFO - 2020-03-18 14:36:53 --> Loader Class Initialized
INFO - 2020-03-18 14:36:53 --> Helper loaded: url_helper
INFO - 2020-03-18 14:36:53 --> Helper loaded: file_helper
INFO - 2020-03-18 14:36:53 --> Helper loaded: form_helper
INFO - 2020-03-18 14:36:53 --> Helper loaded: my_helper
INFO - 2020-03-18 14:36:53 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:36:53 --> Controller Class Initialized
DEBUG - 2020-03-18 14:36:53 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 14:36:53 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 14:36:53 --> Final output sent to browser
DEBUG - 2020-03-18 14:36:53 --> Total execution time: 0.6762
INFO - 2020-03-18 14:40:51 --> Config Class Initialized
INFO - 2020-03-18 14:40:51 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:40:51 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:40:51 --> Utf8 Class Initialized
INFO - 2020-03-18 14:40:51 --> URI Class Initialized
INFO - 2020-03-18 14:40:51 --> Router Class Initialized
INFO - 2020-03-18 14:40:51 --> Output Class Initialized
INFO - 2020-03-18 14:40:51 --> Security Class Initialized
DEBUG - 2020-03-18 14:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:40:51 --> Input Class Initialized
INFO - 2020-03-18 14:40:51 --> Language Class Initialized
INFO - 2020-03-18 14:40:51 --> Language Class Initialized
INFO - 2020-03-18 14:40:51 --> Config Class Initialized
INFO - 2020-03-18 14:40:51 --> Loader Class Initialized
INFO - 2020-03-18 14:40:52 --> Helper loaded: url_helper
INFO - 2020-03-18 14:40:52 --> Helper loaded: file_helper
INFO - 2020-03-18 14:40:52 --> Helper loaded: form_helper
INFO - 2020-03-18 14:40:52 --> Helper loaded: my_helper
INFO - 2020-03-18 14:40:52 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:40:52 --> Controller Class Initialized
DEBUG - 2020-03-18 14:40:52 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 14:40:52 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 14:40:52 --> Final output sent to browser
DEBUG - 2020-03-18 14:40:52 --> Total execution time: 0.6854
INFO - 2020-03-18 14:41:03 --> Config Class Initialized
INFO - 2020-03-18 14:41:03 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:41:04 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:41:04 --> Utf8 Class Initialized
INFO - 2020-03-18 14:41:04 --> URI Class Initialized
INFO - 2020-03-18 14:41:04 --> Router Class Initialized
INFO - 2020-03-18 14:41:04 --> Output Class Initialized
INFO - 2020-03-18 14:41:04 --> Security Class Initialized
DEBUG - 2020-03-18 14:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:41:04 --> Input Class Initialized
INFO - 2020-03-18 14:41:04 --> Language Class Initialized
INFO - 2020-03-18 14:41:04 --> Language Class Initialized
INFO - 2020-03-18 14:41:04 --> Config Class Initialized
INFO - 2020-03-18 14:41:04 --> Loader Class Initialized
INFO - 2020-03-18 14:41:04 --> Helper loaded: url_helper
INFO - 2020-03-18 14:41:04 --> Helper loaded: file_helper
INFO - 2020-03-18 14:41:04 --> Helper loaded: form_helper
INFO - 2020-03-18 14:41:04 --> Helper loaded: my_helper
INFO - 2020-03-18 14:41:04 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:41:04 --> Controller Class Initialized
INFO - 2020-03-18 14:41:04 --> Helper loaded: cookie_helper
INFO - 2020-03-18 14:41:04 --> Final output sent to browser
DEBUG - 2020-03-18 14:41:04 --> Total execution time: 0.5388
INFO - 2020-03-18 14:41:04 --> Config Class Initialized
INFO - 2020-03-18 14:41:04 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:41:04 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:41:04 --> Utf8 Class Initialized
INFO - 2020-03-18 14:41:04 --> URI Class Initialized
INFO - 2020-03-18 14:41:04 --> Router Class Initialized
INFO - 2020-03-18 14:41:04 --> Output Class Initialized
INFO - 2020-03-18 14:41:04 --> Security Class Initialized
DEBUG - 2020-03-18 14:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:41:04 --> Input Class Initialized
INFO - 2020-03-18 14:41:05 --> Language Class Initialized
INFO - 2020-03-18 14:41:05 --> Language Class Initialized
INFO - 2020-03-18 14:41:05 --> Config Class Initialized
INFO - 2020-03-18 14:41:05 --> Loader Class Initialized
INFO - 2020-03-18 14:41:05 --> Helper loaded: url_helper
INFO - 2020-03-18 14:41:05 --> Helper loaded: file_helper
INFO - 2020-03-18 14:41:05 --> Helper loaded: form_helper
INFO - 2020-03-18 14:41:05 --> Helper loaded: my_helper
INFO - 2020-03-18 14:41:05 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:41:05 --> Controller Class Initialized
DEBUG - 2020-03-18 14:41:05 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 14:41:05 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 14:41:05 --> Final output sent to browser
DEBUG - 2020-03-18 14:41:07 --> Total execution time: 0.6923
INFO - 2020-03-18 14:41:16 --> Config Class Initialized
INFO - 2020-03-18 14:41:16 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:41:16 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:41:16 --> Utf8 Class Initialized
INFO - 2020-03-18 14:41:16 --> URI Class Initialized
INFO - 2020-03-18 14:41:16 --> Router Class Initialized
INFO - 2020-03-18 14:41:16 --> Output Class Initialized
INFO - 2020-03-18 14:41:16 --> Security Class Initialized
DEBUG - 2020-03-18 14:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:41:16 --> Input Class Initialized
INFO - 2020-03-18 14:41:16 --> Language Class Initialized
INFO - 2020-03-18 14:41:16 --> Language Class Initialized
INFO - 2020-03-18 14:41:16 --> Config Class Initialized
INFO - 2020-03-18 14:41:16 --> Loader Class Initialized
INFO - 2020-03-18 14:41:16 --> Helper loaded: url_helper
INFO - 2020-03-18 14:41:16 --> Helper loaded: file_helper
INFO - 2020-03-18 14:41:16 --> Helper loaded: form_helper
INFO - 2020-03-18 14:41:16 --> Helper loaded: my_helper
INFO - 2020-03-18 14:41:16 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:41:17 --> Controller Class Initialized
DEBUG - 2020-03-18 14:41:17 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_ubah_password.php
DEBUG - 2020-03-18 14:41:17 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 14:41:17 --> Final output sent to browser
DEBUG - 2020-03-18 14:41:17 --> Total execution time: 0.7590
INFO - 2020-03-18 14:41:37 --> Config Class Initialized
INFO - 2020-03-18 14:41:37 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:41:37 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:41:37 --> Utf8 Class Initialized
INFO - 2020-03-18 14:41:37 --> URI Class Initialized
INFO - 2020-03-18 14:41:37 --> Router Class Initialized
INFO - 2020-03-18 14:41:37 --> Output Class Initialized
INFO - 2020-03-18 14:41:37 --> Security Class Initialized
DEBUG - 2020-03-18 14:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:41:37 --> Input Class Initialized
INFO - 2020-03-18 14:41:37 --> Language Class Initialized
INFO - 2020-03-18 14:41:37 --> Language Class Initialized
INFO - 2020-03-18 14:41:37 --> Config Class Initialized
INFO - 2020-03-18 14:41:37 --> Loader Class Initialized
INFO - 2020-03-18 14:41:37 --> Helper loaded: url_helper
INFO - 2020-03-18 14:41:37 --> Helper loaded: file_helper
INFO - 2020-03-18 14:41:37 --> Helper loaded: form_helper
INFO - 2020-03-18 14:41:37 --> Helper loaded: my_helper
INFO - 2020-03-18 14:41:37 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:41:37 --> Controller Class Initialized
INFO - 2020-03-18 14:41:51 --> Config Class Initialized
INFO - 2020-03-18 14:41:51 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:41:51 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:41:51 --> Utf8 Class Initialized
INFO - 2020-03-18 14:41:51 --> URI Class Initialized
INFO - 2020-03-18 14:41:51 --> Router Class Initialized
INFO - 2020-03-18 14:41:51 --> Output Class Initialized
INFO - 2020-03-18 14:41:51 --> Security Class Initialized
DEBUG - 2020-03-18 14:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:41:51 --> Input Class Initialized
INFO - 2020-03-18 14:41:51 --> Language Class Initialized
INFO - 2020-03-18 14:41:51 --> Language Class Initialized
INFO - 2020-03-18 14:41:51 --> Config Class Initialized
INFO - 2020-03-18 14:41:51 --> Loader Class Initialized
INFO - 2020-03-18 14:41:51 --> Helper loaded: url_helper
INFO - 2020-03-18 14:41:51 --> Helper loaded: file_helper
INFO - 2020-03-18 14:41:51 --> Helper loaded: form_helper
INFO - 2020-03-18 14:41:51 --> Helper loaded: my_helper
INFO - 2020-03-18 14:41:51 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:41:51 --> Controller Class Initialized
INFO - 2020-03-18 14:41:51 --> Helper loaded: cookie_helper
INFO - 2020-03-18 14:41:51 --> Config Class Initialized
INFO - 2020-03-18 14:41:51 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:41:51 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:41:51 --> Utf8 Class Initialized
INFO - 2020-03-18 14:41:51 --> URI Class Initialized
INFO - 2020-03-18 14:41:51 --> Router Class Initialized
INFO - 2020-03-18 14:41:51 --> Output Class Initialized
INFO - 2020-03-18 14:41:51 --> Security Class Initialized
DEBUG - 2020-03-18 14:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:41:52 --> Input Class Initialized
INFO - 2020-03-18 14:41:52 --> Language Class Initialized
INFO - 2020-03-18 14:41:52 --> Language Class Initialized
INFO - 2020-03-18 14:41:52 --> Config Class Initialized
INFO - 2020-03-18 14:41:52 --> Loader Class Initialized
INFO - 2020-03-18 14:41:52 --> Helper loaded: url_helper
INFO - 2020-03-18 14:41:52 --> Helper loaded: file_helper
INFO - 2020-03-18 14:41:52 --> Helper loaded: form_helper
INFO - 2020-03-18 14:41:52 --> Helper loaded: my_helper
INFO - 2020-03-18 14:41:52 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:41:52 --> Controller Class Initialized
INFO - 2020-03-18 14:41:52 --> Config Class Initialized
INFO - 2020-03-18 14:41:52 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:41:52 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:41:52 --> Utf8 Class Initialized
INFO - 2020-03-18 14:41:52 --> URI Class Initialized
INFO - 2020-03-18 14:41:52 --> Router Class Initialized
INFO - 2020-03-18 14:41:52 --> Output Class Initialized
INFO - 2020-03-18 14:41:52 --> Security Class Initialized
DEBUG - 2020-03-18 14:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:41:52 --> Input Class Initialized
INFO - 2020-03-18 14:41:52 --> Language Class Initialized
INFO - 2020-03-18 14:41:52 --> Language Class Initialized
INFO - 2020-03-18 14:41:52 --> Config Class Initialized
INFO - 2020-03-18 14:41:52 --> Loader Class Initialized
INFO - 2020-03-18 14:41:52 --> Helper loaded: url_helper
INFO - 2020-03-18 14:41:52 --> Helper loaded: file_helper
INFO - 2020-03-18 14:41:52 --> Helper loaded: form_helper
INFO - 2020-03-18 14:41:52 --> Helper loaded: my_helper
INFO - 2020-03-18 14:41:52 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:41:52 --> Controller Class Initialized
DEBUG - 2020-03-18 14:41:52 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 14:41:52 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 14:41:52 --> Final output sent to browser
DEBUG - 2020-03-18 14:41:52 --> Total execution time: 0.4941
INFO - 2020-03-18 14:41:58 --> Config Class Initialized
INFO - 2020-03-18 14:41:58 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:41:58 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:41:58 --> Utf8 Class Initialized
INFO - 2020-03-18 14:41:58 --> URI Class Initialized
INFO - 2020-03-18 14:41:58 --> Router Class Initialized
INFO - 2020-03-18 14:41:58 --> Output Class Initialized
INFO - 2020-03-18 14:41:58 --> Security Class Initialized
DEBUG - 2020-03-18 14:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:41:58 --> Input Class Initialized
INFO - 2020-03-18 14:41:58 --> Language Class Initialized
INFO - 2020-03-18 14:41:58 --> Language Class Initialized
INFO - 2020-03-18 14:41:58 --> Config Class Initialized
INFO - 2020-03-18 14:41:58 --> Loader Class Initialized
INFO - 2020-03-18 14:41:58 --> Helper loaded: url_helper
INFO - 2020-03-18 14:41:58 --> Helper loaded: file_helper
INFO - 2020-03-18 14:41:58 --> Helper loaded: form_helper
INFO - 2020-03-18 14:41:58 --> Helper loaded: my_helper
INFO - 2020-03-18 14:41:58 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:41:58 --> Controller Class Initialized
INFO - 2020-03-18 14:41:58 --> Final output sent to browser
DEBUG - 2020-03-18 14:41:58 --> Total execution time: 0.5366
INFO - 2020-03-18 14:42:03 --> Config Class Initialized
INFO - 2020-03-18 14:42:03 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:42:03 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:42:03 --> Utf8 Class Initialized
INFO - 2020-03-18 14:42:03 --> URI Class Initialized
INFO - 2020-03-18 14:42:03 --> Router Class Initialized
INFO - 2020-03-18 14:42:03 --> Output Class Initialized
INFO - 2020-03-18 14:42:03 --> Security Class Initialized
DEBUG - 2020-03-18 14:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:42:03 --> Input Class Initialized
INFO - 2020-03-18 14:42:03 --> Language Class Initialized
INFO - 2020-03-18 14:42:03 --> Language Class Initialized
INFO - 2020-03-18 14:42:03 --> Config Class Initialized
INFO - 2020-03-18 14:42:03 --> Loader Class Initialized
INFO - 2020-03-18 14:42:03 --> Helper loaded: url_helper
INFO - 2020-03-18 14:42:03 --> Helper loaded: file_helper
INFO - 2020-03-18 14:42:03 --> Helper loaded: form_helper
INFO - 2020-03-18 14:42:03 --> Helper loaded: my_helper
INFO - 2020-03-18 14:42:03 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:42:04 --> Controller Class Initialized
INFO - 2020-03-18 14:42:04 --> Helper loaded: cookie_helper
INFO - 2020-03-18 14:42:04 --> Final output sent to browser
DEBUG - 2020-03-18 14:42:04 --> Total execution time: 0.5770
INFO - 2020-03-18 14:42:04 --> Config Class Initialized
INFO - 2020-03-18 14:42:04 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:42:04 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:42:04 --> Utf8 Class Initialized
INFO - 2020-03-18 14:42:04 --> URI Class Initialized
INFO - 2020-03-18 14:42:04 --> Router Class Initialized
INFO - 2020-03-18 14:42:04 --> Output Class Initialized
INFO - 2020-03-18 14:42:04 --> Security Class Initialized
DEBUG - 2020-03-18 14:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:42:04 --> Input Class Initialized
INFO - 2020-03-18 14:42:04 --> Language Class Initialized
INFO - 2020-03-18 14:42:04 --> Language Class Initialized
INFO - 2020-03-18 14:42:04 --> Config Class Initialized
INFO - 2020-03-18 14:42:04 --> Loader Class Initialized
INFO - 2020-03-18 14:42:04 --> Helper loaded: url_helper
INFO - 2020-03-18 14:42:04 --> Helper loaded: file_helper
INFO - 2020-03-18 14:42:04 --> Helper loaded: form_helper
INFO - 2020-03-18 14:42:04 --> Helper loaded: my_helper
INFO - 2020-03-18 14:42:04 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:42:04 --> Controller Class Initialized
DEBUG - 2020-03-18 14:42:04 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 14:42:04 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 14:42:04 --> Final output sent to browser
DEBUG - 2020-03-18 14:42:07 --> Total execution time: 0.7208
INFO - 2020-03-18 14:48:25 --> Config Class Initialized
INFO - 2020-03-18 14:48:25 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:48:25 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:48:25 --> Utf8 Class Initialized
INFO - 2020-03-18 14:48:25 --> URI Class Initialized
INFO - 2020-03-18 14:48:25 --> Router Class Initialized
INFO - 2020-03-18 14:48:25 --> Output Class Initialized
INFO - 2020-03-18 14:48:25 --> Security Class Initialized
DEBUG - 2020-03-18 14:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:48:25 --> Input Class Initialized
INFO - 2020-03-18 14:48:25 --> Language Class Initialized
INFO - 2020-03-18 14:48:25 --> Language Class Initialized
INFO - 2020-03-18 14:48:25 --> Config Class Initialized
INFO - 2020-03-18 14:48:25 --> Loader Class Initialized
INFO - 2020-03-18 14:48:25 --> Helper loaded: url_helper
INFO - 2020-03-18 14:48:25 --> Helper loaded: file_helper
INFO - 2020-03-18 14:48:25 --> Helper loaded: form_helper
INFO - 2020-03-18 14:48:25 --> Helper loaded: my_helper
INFO - 2020-03-18 14:48:25 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:48:25 --> Controller Class Initialized
INFO - 2020-03-18 14:48:25 --> Helper loaded: cookie_helper
INFO - 2020-03-18 14:48:25 --> Config Class Initialized
INFO - 2020-03-18 14:48:25 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:48:25 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:48:25 --> Utf8 Class Initialized
INFO - 2020-03-18 14:48:25 --> URI Class Initialized
INFO - 2020-03-18 14:48:25 --> Router Class Initialized
INFO - 2020-03-18 14:48:25 --> Output Class Initialized
INFO - 2020-03-18 14:48:26 --> Security Class Initialized
DEBUG - 2020-03-18 14:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:48:26 --> Input Class Initialized
INFO - 2020-03-18 14:48:26 --> Language Class Initialized
INFO - 2020-03-18 14:48:26 --> Language Class Initialized
INFO - 2020-03-18 14:48:26 --> Config Class Initialized
INFO - 2020-03-18 14:48:26 --> Loader Class Initialized
INFO - 2020-03-18 14:48:26 --> Helper loaded: url_helper
INFO - 2020-03-18 14:48:26 --> Helper loaded: file_helper
INFO - 2020-03-18 14:48:26 --> Helper loaded: form_helper
INFO - 2020-03-18 14:48:26 --> Helper loaded: my_helper
INFO - 2020-03-18 14:48:26 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:48:26 --> Controller Class Initialized
INFO - 2020-03-18 14:48:26 --> Config Class Initialized
INFO - 2020-03-18 14:48:26 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:48:26 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:48:26 --> Utf8 Class Initialized
INFO - 2020-03-18 14:48:26 --> URI Class Initialized
INFO - 2020-03-18 14:48:26 --> Router Class Initialized
INFO - 2020-03-18 14:48:26 --> Output Class Initialized
INFO - 2020-03-18 14:48:26 --> Security Class Initialized
DEBUG - 2020-03-18 14:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:48:26 --> Input Class Initialized
INFO - 2020-03-18 14:48:26 --> Language Class Initialized
INFO - 2020-03-18 14:48:26 --> Language Class Initialized
INFO - 2020-03-18 14:48:26 --> Config Class Initialized
INFO - 2020-03-18 14:48:26 --> Loader Class Initialized
INFO - 2020-03-18 14:48:26 --> Helper loaded: url_helper
INFO - 2020-03-18 14:48:26 --> Helper loaded: file_helper
INFO - 2020-03-18 14:48:26 --> Helper loaded: form_helper
INFO - 2020-03-18 14:48:26 --> Helper loaded: my_helper
INFO - 2020-03-18 14:48:26 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:48:26 --> Controller Class Initialized
DEBUG - 2020-03-18 14:48:26 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 14:48:26 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 14:48:26 --> Final output sent to browser
DEBUG - 2020-03-18 14:48:27 --> Total execution time: 0.5268
INFO - 2020-03-18 14:52:28 --> Config Class Initialized
INFO - 2020-03-18 14:52:28 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:52:28 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:52:28 --> Utf8 Class Initialized
INFO - 2020-03-18 14:52:28 --> URI Class Initialized
INFO - 2020-03-18 14:52:28 --> Router Class Initialized
INFO - 2020-03-18 14:52:28 --> Output Class Initialized
INFO - 2020-03-18 14:52:28 --> Security Class Initialized
DEBUG - 2020-03-18 14:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:52:28 --> Input Class Initialized
INFO - 2020-03-18 14:52:28 --> Language Class Initialized
INFO - 2020-03-18 14:52:28 --> Language Class Initialized
INFO - 2020-03-18 14:52:28 --> Config Class Initialized
INFO - 2020-03-18 14:52:28 --> Loader Class Initialized
INFO - 2020-03-18 14:52:28 --> Helper loaded: url_helper
INFO - 2020-03-18 14:52:28 --> Helper loaded: file_helper
INFO - 2020-03-18 14:52:28 --> Helper loaded: form_helper
INFO - 2020-03-18 14:52:28 --> Helper loaded: my_helper
INFO - 2020-03-18 14:52:29 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:52:29 --> Controller Class Initialized
DEBUG - 2020-03-18 14:52:29 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 14:52:29 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 14:52:29 --> Final output sent to browser
DEBUG - 2020-03-18 14:52:29 --> Total execution time: 0.6168
INFO - 2020-03-18 14:53:45 --> Config Class Initialized
INFO - 2020-03-18 14:53:45 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:53:45 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:53:45 --> Utf8 Class Initialized
INFO - 2020-03-18 14:53:45 --> URI Class Initialized
INFO - 2020-03-18 14:53:45 --> Router Class Initialized
INFO - 2020-03-18 14:53:45 --> Output Class Initialized
INFO - 2020-03-18 14:53:45 --> Security Class Initialized
DEBUG - 2020-03-18 14:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:53:45 --> Input Class Initialized
INFO - 2020-03-18 14:53:45 --> Language Class Initialized
INFO - 2020-03-18 14:53:45 --> Language Class Initialized
INFO - 2020-03-18 14:53:45 --> Config Class Initialized
INFO - 2020-03-18 14:53:45 --> Loader Class Initialized
INFO - 2020-03-18 14:53:45 --> Helper loaded: url_helper
INFO - 2020-03-18 14:53:45 --> Helper loaded: file_helper
INFO - 2020-03-18 14:53:45 --> Helper loaded: form_helper
INFO - 2020-03-18 14:53:45 --> Helper loaded: my_helper
INFO - 2020-03-18 14:53:45 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:53:45 --> Controller Class Initialized
DEBUG - 2020-03-18 14:53:45 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 14:53:45 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 14:53:45 --> Final output sent to browser
DEBUG - 2020-03-18 14:53:45 --> Total execution time: 0.6979
INFO - 2020-03-18 14:54:13 --> Config Class Initialized
INFO - 2020-03-18 14:54:13 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:54:13 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:54:13 --> Utf8 Class Initialized
INFO - 2020-03-18 14:54:13 --> URI Class Initialized
INFO - 2020-03-18 14:54:13 --> Router Class Initialized
INFO - 2020-03-18 14:54:13 --> Output Class Initialized
INFO - 2020-03-18 14:54:13 --> Security Class Initialized
DEBUG - 2020-03-18 14:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:54:13 --> Input Class Initialized
INFO - 2020-03-18 14:54:13 --> Language Class Initialized
INFO - 2020-03-18 14:54:13 --> Language Class Initialized
INFO - 2020-03-18 14:54:13 --> Config Class Initialized
INFO - 2020-03-18 14:54:13 --> Loader Class Initialized
INFO - 2020-03-18 14:54:13 --> Helper loaded: url_helper
INFO - 2020-03-18 14:54:13 --> Helper loaded: file_helper
INFO - 2020-03-18 14:54:13 --> Helper loaded: form_helper
INFO - 2020-03-18 14:54:13 --> Helper loaded: my_helper
INFO - 2020-03-18 14:54:13 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:54:13 --> Controller Class Initialized
DEBUG - 2020-03-18 14:54:13 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 14:54:13 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 14:54:13 --> Final output sent to browser
DEBUG - 2020-03-18 14:54:13 --> Total execution time: 0.5897
INFO - 2020-03-18 14:54:16 --> Config Class Initialized
INFO - 2020-03-18 14:54:16 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:54:16 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:54:16 --> Utf8 Class Initialized
INFO - 2020-03-18 14:54:16 --> URI Class Initialized
INFO - 2020-03-18 14:54:16 --> Router Class Initialized
INFO - 2020-03-18 14:54:16 --> Output Class Initialized
INFO - 2020-03-18 14:54:16 --> Security Class Initialized
DEBUG - 2020-03-18 14:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:54:16 --> Input Class Initialized
INFO - 2020-03-18 14:54:16 --> Language Class Initialized
INFO - 2020-03-18 14:54:16 --> Language Class Initialized
INFO - 2020-03-18 14:54:16 --> Config Class Initialized
INFO - 2020-03-18 14:54:16 --> Loader Class Initialized
INFO - 2020-03-18 14:54:16 --> Helper loaded: url_helper
INFO - 2020-03-18 14:54:17 --> Helper loaded: file_helper
INFO - 2020-03-18 14:54:17 --> Helper loaded: form_helper
INFO - 2020-03-18 14:54:17 --> Helper loaded: my_helper
INFO - 2020-03-18 14:54:17 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:54:17 --> Controller Class Initialized
DEBUG - 2020-03-18 14:54:17 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 14:54:17 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 14:54:17 --> Final output sent to browser
DEBUG - 2020-03-18 14:54:17 --> Total execution time: 0.7228
INFO - 2020-03-18 14:54:39 --> Config Class Initialized
INFO - 2020-03-18 14:54:39 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:54:39 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:54:39 --> Utf8 Class Initialized
INFO - 2020-03-18 14:54:39 --> URI Class Initialized
INFO - 2020-03-18 14:54:39 --> Router Class Initialized
INFO - 2020-03-18 14:54:39 --> Output Class Initialized
INFO - 2020-03-18 14:54:39 --> Security Class Initialized
DEBUG - 2020-03-18 14:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:54:39 --> Input Class Initialized
INFO - 2020-03-18 14:54:39 --> Language Class Initialized
INFO - 2020-03-18 14:54:39 --> Language Class Initialized
INFO - 2020-03-18 14:54:39 --> Config Class Initialized
INFO - 2020-03-18 14:54:39 --> Loader Class Initialized
INFO - 2020-03-18 14:54:39 --> Helper loaded: url_helper
INFO - 2020-03-18 14:54:39 --> Helper loaded: file_helper
INFO - 2020-03-18 14:54:39 --> Helper loaded: form_helper
INFO - 2020-03-18 14:54:39 --> Helper loaded: my_helper
INFO - 2020-03-18 14:54:39 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:54:39 --> Controller Class Initialized
DEBUG - 2020-03-18 14:54:39 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 14:54:39 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 14:54:39 --> Final output sent to browser
DEBUG - 2020-03-18 14:54:40 --> Total execution time: 0.7054
INFO - 2020-03-18 14:54:42 --> Config Class Initialized
INFO - 2020-03-18 14:54:42 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:54:42 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:54:42 --> Utf8 Class Initialized
INFO - 2020-03-18 14:54:42 --> URI Class Initialized
INFO - 2020-03-18 14:54:42 --> Router Class Initialized
INFO - 2020-03-18 14:54:42 --> Output Class Initialized
INFO - 2020-03-18 14:54:42 --> Security Class Initialized
DEBUG - 2020-03-18 14:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:54:42 --> Input Class Initialized
INFO - 2020-03-18 14:54:42 --> Language Class Initialized
INFO - 2020-03-18 14:54:42 --> Language Class Initialized
INFO - 2020-03-18 14:54:42 --> Config Class Initialized
INFO - 2020-03-18 14:54:42 --> Loader Class Initialized
INFO - 2020-03-18 14:54:43 --> Helper loaded: url_helper
INFO - 2020-03-18 14:54:43 --> Helper loaded: file_helper
INFO - 2020-03-18 14:54:43 --> Helper loaded: form_helper
INFO - 2020-03-18 14:54:43 --> Helper loaded: my_helper
INFO - 2020-03-18 14:54:43 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:54:43 --> Controller Class Initialized
DEBUG - 2020-03-18 14:54:43 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 14:54:43 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 14:54:43 --> Final output sent to browser
DEBUG - 2020-03-18 14:54:43 --> Total execution time: 0.5586
INFO - 2020-03-18 14:54:54 --> Config Class Initialized
INFO - 2020-03-18 14:54:54 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:54:54 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:54:54 --> Utf8 Class Initialized
INFO - 2020-03-18 14:54:54 --> URI Class Initialized
INFO - 2020-03-18 14:54:54 --> Router Class Initialized
INFO - 2020-03-18 14:54:54 --> Output Class Initialized
INFO - 2020-03-18 14:54:54 --> Security Class Initialized
DEBUG - 2020-03-18 14:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:54:55 --> Input Class Initialized
INFO - 2020-03-18 14:54:55 --> Language Class Initialized
INFO - 2020-03-18 14:54:55 --> Language Class Initialized
INFO - 2020-03-18 14:54:55 --> Config Class Initialized
INFO - 2020-03-18 14:54:55 --> Loader Class Initialized
INFO - 2020-03-18 14:54:55 --> Helper loaded: url_helper
INFO - 2020-03-18 14:54:55 --> Helper loaded: file_helper
INFO - 2020-03-18 14:54:55 --> Helper loaded: form_helper
INFO - 2020-03-18 14:54:55 --> Helper loaded: my_helper
INFO - 2020-03-18 14:54:55 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:54:55 --> Controller Class Initialized
DEBUG - 2020-03-18 14:54:55 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 14:54:55 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 14:54:55 --> Final output sent to browser
DEBUG - 2020-03-18 14:54:55 --> Total execution time: 0.5738
INFO - 2020-03-18 14:55:19 --> Config Class Initialized
INFO - 2020-03-18 14:55:19 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:55:19 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:55:20 --> Utf8 Class Initialized
INFO - 2020-03-18 14:55:20 --> URI Class Initialized
INFO - 2020-03-18 14:55:20 --> Router Class Initialized
INFO - 2020-03-18 14:55:20 --> Output Class Initialized
INFO - 2020-03-18 14:55:20 --> Security Class Initialized
DEBUG - 2020-03-18 14:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:55:20 --> Input Class Initialized
INFO - 2020-03-18 14:55:20 --> Language Class Initialized
INFO - 2020-03-18 14:55:20 --> Language Class Initialized
INFO - 2020-03-18 14:55:20 --> Config Class Initialized
INFO - 2020-03-18 14:55:20 --> Loader Class Initialized
INFO - 2020-03-18 14:55:20 --> Helper loaded: url_helper
INFO - 2020-03-18 14:55:20 --> Helper loaded: file_helper
INFO - 2020-03-18 14:55:20 --> Helper loaded: form_helper
INFO - 2020-03-18 14:55:20 --> Helper loaded: my_helper
INFO - 2020-03-18 14:55:20 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:55:20 --> Controller Class Initialized
DEBUG - 2020-03-18 14:55:20 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 14:55:20 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 14:55:20 --> Final output sent to browser
DEBUG - 2020-03-18 14:55:20 --> Total execution time: 0.6305
INFO - 2020-03-18 14:56:05 --> Config Class Initialized
INFO - 2020-03-18 14:56:05 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:56:05 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:56:05 --> Utf8 Class Initialized
INFO - 2020-03-18 14:56:05 --> URI Class Initialized
DEBUG - 2020-03-18 14:56:05 --> No URI present. Default controller set.
INFO - 2020-03-18 14:56:05 --> Router Class Initialized
INFO - 2020-03-18 14:56:05 --> Output Class Initialized
INFO - 2020-03-18 14:56:05 --> Security Class Initialized
DEBUG - 2020-03-18 14:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:56:05 --> Input Class Initialized
INFO - 2020-03-18 14:56:05 --> Language Class Initialized
INFO - 2020-03-18 14:56:05 --> Language Class Initialized
INFO - 2020-03-18 14:56:05 --> Config Class Initialized
INFO - 2020-03-18 14:56:05 --> Loader Class Initialized
INFO - 2020-03-18 14:56:05 --> Helper loaded: url_helper
INFO - 2020-03-18 14:56:05 --> Helper loaded: file_helper
INFO - 2020-03-18 14:56:05 --> Helper loaded: form_helper
INFO - 2020-03-18 14:56:05 --> Helper loaded: my_helper
INFO - 2020-03-18 14:56:05 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:56:05 --> Controller Class Initialized
INFO - 2020-03-18 14:56:05 --> Config Class Initialized
INFO - 2020-03-18 14:56:05 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:56:05 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:56:05 --> Utf8 Class Initialized
INFO - 2020-03-18 14:56:05 --> URI Class Initialized
INFO - 2020-03-18 14:56:05 --> Router Class Initialized
INFO - 2020-03-18 14:56:05 --> Output Class Initialized
INFO - 2020-03-18 14:56:05 --> Security Class Initialized
DEBUG - 2020-03-18 14:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:56:05 --> Input Class Initialized
INFO - 2020-03-18 14:56:05 --> Language Class Initialized
INFO - 2020-03-18 14:56:05 --> Language Class Initialized
INFO - 2020-03-18 14:56:05 --> Config Class Initialized
INFO - 2020-03-18 14:56:05 --> Loader Class Initialized
INFO - 2020-03-18 14:56:05 --> Helper loaded: url_helper
INFO - 2020-03-18 14:56:05 --> Helper loaded: file_helper
INFO - 2020-03-18 14:56:05 --> Helper loaded: form_helper
INFO - 2020-03-18 14:56:05 --> Helper loaded: my_helper
INFO - 2020-03-18 14:56:05 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:56:05 --> Controller Class Initialized
DEBUG - 2020-03-18 14:56:06 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 14:56:06 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 14:56:06 --> Final output sent to browser
DEBUG - 2020-03-18 14:56:06 --> Total execution time: 0.5673
INFO - 2020-03-18 14:56:07 --> Config Class Initialized
INFO - 2020-03-18 14:56:07 --> Hooks Class Initialized
DEBUG - 2020-03-18 14:56:07 --> UTF-8 Support Enabled
INFO - 2020-03-18 14:56:08 --> Utf8 Class Initialized
INFO - 2020-03-18 14:56:08 --> URI Class Initialized
INFO - 2020-03-18 14:56:08 --> Router Class Initialized
INFO - 2020-03-18 14:56:08 --> Output Class Initialized
INFO - 2020-03-18 14:56:08 --> Security Class Initialized
DEBUG - 2020-03-18 14:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 14:56:08 --> Input Class Initialized
INFO - 2020-03-18 14:56:08 --> Language Class Initialized
INFO - 2020-03-18 14:56:08 --> Language Class Initialized
INFO - 2020-03-18 14:56:08 --> Config Class Initialized
INFO - 2020-03-18 14:56:08 --> Loader Class Initialized
INFO - 2020-03-18 14:56:08 --> Helper loaded: url_helper
INFO - 2020-03-18 14:56:08 --> Helper loaded: file_helper
INFO - 2020-03-18 14:56:08 --> Helper loaded: form_helper
INFO - 2020-03-18 14:56:08 --> Helper loaded: my_helper
INFO - 2020-03-18 14:56:08 --> Database Driver Class Initialized
DEBUG - 2020-03-18 14:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 14:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 14:56:08 --> Controller Class Initialized
DEBUG - 2020-03-18 14:56:08 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 14:56:08 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 14:56:08 --> Final output sent to browser
DEBUG - 2020-03-18 14:56:08 --> Total execution time: 0.5618
INFO - 2020-03-18 15:00:34 --> Config Class Initialized
INFO - 2020-03-18 15:00:34 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:00:34 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:00:34 --> Utf8 Class Initialized
INFO - 2020-03-18 15:00:34 --> URI Class Initialized
INFO - 2020-03-18 15:00:34 --> Router Class Initialized
INFO - 2020-03-18 15:00:34 --> Output Class Initialized
INFO - 2020-03-18 15:00:34 --> Security Class Initialized
DEBUG - 2020-03-18 15:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:00:34 --> Input Class Initialized
INFO - 2020-03-18 15:00:34 --> Language Class Initialized
INFO - 2020-03-18 15:00:34 --> Language Class Initialized
INFO - 2020-03-18 15:00:34 --> Config Class Initialized
INFO - 2020-03-18 15:00:34 --> Loader Class Initialized
INFO - 2020-03-18 15:00:35 --> Helper loaded: url_helper
INFO - 2020-03-18 15:00:35 --> Helper loaded: file_helper
INFO - 2020-03-18 15:00:35 --> Helper loaded: form_helper
INFO - 2020-03-18 15:00:35 --> Helper loaded: my_helper
INFO - 2020-03-18 15:00:35 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:00:35 --> Controller Class Initialized
DEBUG - 2020-03-18 15:00:35 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 15:00:35 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:00:35 --> Final output sent to browser
DEBUG - 2020-03-18 15:00:35 --> Total execution time: 0.8822
INFO - 2020-03-18 15:00:58 --> Config Class Initialized
INFO - 2020-03-18 15:00:58 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:00:58 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:00:58 --> Utf8 Class Initialized
INFO - 2020-03-18 15:00:58 --> URI Class Initialized
INFO - 2020-03-18 15:00:58 --> Router Class Initialized
INFO - 2020-03-18 15:00:58 --> Output Class Initialized
INFO - 2020-03-18 15:00:58 --> Security Class Initialized
DEBUG - 2020-03-18 15:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:00:58 --> Input Class Initialized
INFO - 2020-03-18 15:00:59 --> Language Class Initialized
INFO - 2020-03-18 15:00:59 --> Language Class Initialized
INFO - 2020-03-18 15:00:59 --> Config Class Initialized
INFO - 2020-03-18 15:00:59 --> Loader Class Initialized
INFO - 2020-03-18 15:00:59 --> Helper loaded: url_helper
INFO - 2020-03-18 15:00:59 --> Helper loaded: file_helper
INFO - 2020-03-18 15:00:59 --> Helper loaded: form_helper
INFO - 2020-03-18 15:00:59 --> Helper loaded: my_helper
INFO - 2020-03-18 15:00:59 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:00:59 --> Controller Class Initialized
DEBUG - 2020-03-18 15:00:59 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 15:00:59 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:00:59 --> Final output sent to browser
DEBUG - 2020-03-18 15:00:59 --> Total execution time: 0.7643
INFO - 2020-03-18 15:03:22 --> Config Class Initialized
INFO - 2020-03-18 15:03:22 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:03:22 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:03:22 --> Utf8 Class Initialized
INFO - 2020-03-18 15:03:22 --> URI Class Initialized
INFO - 2020-03-18 15:03:22 --> Router Class Initialized
INFO - 2020-03-18 15:03:22 --> Output Class Initialized
INFO - 2020-03-18 15:03:22 --> Security Class Initialized
DEBUG - 2020-03-18 15:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:03:23 --> Input Class Initialized
INFO - 2020-03-18 15:03:23 --> Language Class Initialized
INFO - 2020-03-18 15:03:23 --> Language Class Initialized
INFO - 2020-03-18 15:03:23 --> Config Class Initialized
INFO - 2020-03-18 15:03:23 --> Loader Class Initialized
INFO - 2020-03-18 15:03:23 --> Helper loaded: url_helper
INFO - 2020-03-18 15:03:23 --> Helper loaded: file_helper
INFO - 2020-03-18 15:03:23 --> Helper loaded: form_helper
INFO - 2020-03-18 15:03:23 --> Helper loaded: my_helper
INFO - 2020-03-18 15:03:23 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:03:23 --> Controller Class Initialized
DEBUG - 2020-03-18 15:03:23 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 15:03:23 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:03:23 --> Final output sent to browser
DEBUG - 2020-03-18 15:03:23 --> Total execution time: 0.5848
INFO - 2020-03-18 15:08:08 --> Config Class Initialized
INFO - 2020-03-18 15:08:08 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:08:08 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:08:08 --> Utf8 Class Initialized
INFO - 2020-03-18 15:08:08 --> URI Class Initialized
DEBUG - 2020-03-18 15:08:08 --> No URI present. Default controller set.
INFO - 2020-03-18 15:08:08 --> Router Class Initialized
INFO - 2020-03-18 15:08:08 --> Output Class Initialized
INFO - 2020-03-18 15:08:08 --> Security Class Initialized
DEBUG - 2020-03-18 15:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:08:08 --> Input Class Initialized
INFO - 2020-03-18 15:08:08 --> Language Class Initialized
INFO - 2020-03-18 15:08:08 --> Language Class Initialized
INFO - 2020-03-18 15:08:08 --> Config Class Initialized
INFO - 2020-03-18 15:08:08 --> Loader Class Initialized
INFO - 2020-03-18 15:08:08 --> Helper loaded: url_helper
INFO - 2020-03-18 15:08:08 --> Helper loaded: file_helper
INFO - 2020-03-18 15:08:08 --> Helper loaded: form_helper
INFO - 2020-03-18 15:08:08 --> Helper loaded: my_helper
INFO - 2020-03-18 15:08:08 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:08:08 --> Controller Class Initialized
INFO - 2020-03-18 15:08:08 --> Config Class Initialized
INFO - 2020-03-18 15:08:08 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:08:08 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:08:08 --> Utf8 Class Initialized
INFO - 2020-03-18 15:08:08 --> URI Class Initialized
INFO - 2020-03-18 15:08:08 --> Router Class Initialized
INFO - 2020-03-18 15:08:08 --> Output Class Initialized
INFO - 2020-03-18 15:08:08 --> Security Class Initialized
DEBUG - 2020-03-18 15:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:08:09 --> Input Class Initialized
INFO - 2020-03-18 15:08:09 --> Language Class Initialized
INFO - 2020-03-18 15:08:09 --> Language Class Initialized
INFO - 2020-03-18 15:08:09 --> Config Class Initialized
INFO - 2020-03-18 15:08:09 --> Loader Class Initialized
INFO - 2020-03-18 15:08:09 --> Helper loaded: url_helper
INFO - 2020-03-18 15:08:09 --> Helper loaded: file_helper
INFO - 2020-03-18 15:08:09 --> Helper loaded: form_helper
INFO - 2020-03-18 15:08:09 --> Helper loaded: my_helper
INFO - 2020-03-18 15:08:09 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:08:09 --> Controller Class Initialized
DEBUG - 2020-03-18 15:08:09 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 15:08:09 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:08:09 --> Final output sent to browser
DEBUG - 2020-03-18 15:08:09 --> Total execution time: 0.5065
INFO - 2020-03-18 15:08:17 --> Config Class Initialized
INFO - 2020-03-18 15:08:17 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:08:17 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:08:17 --> Utf8 Class Initialized
INFO - 2020-03-18 15:08:17 --> URI Class Initialized
INFO - 2020-03-18 15:08:17 --> Router Class Initialized
INFO - 2020-03-18 15:08:17 --> Output Class Initialized
INFO - 2020-03-18 15:08:17 --> Security Class Initialized
DEBUG - 2020-03-18 15:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:08:17 --> Input Class Initialized
INFO - 2020-03-18 15:08:17 --> Language Class Initialized
ERROR - 2020-03-18 15:08:17 --> 404 Page Not Found: /index
INFO - 2020-03-18 15:09:02 --> Config Class Initialized
INFO - 2020-03-18 15:09:02 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:09:02 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:09:02 --> Utf8 Class Initialized
INFO - 2020-03-18 15:09:02 --> URI Class Initialized
DEBUG - 2020-03-18 15:09:02 --> No URI present. Default controller set.
INFO - 2020-03-18 15:09:02 --> Router Class Initialized
INFO - 2020-03-18 15:09:02 --> Output Class Initialized
INFO - 2020-03-18 15:09:02 --> Security Class Initialized
DEBUG - 2020-03-18 15:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:09:02 --> Input Class Initialized
INFO - 2020-03-18 15:09:02 --> Language Class Initialized
INFO - 2020-03-18 15:09:02 --> Language Class Initialized
INFO - 2020-03-18 15:09:02 --> Config Class Initialized
INFO - 2020-03-18 15:09:02 --> Loader Class Initialized
INFO - 2020-03-18 15:09:02 --> Helper loaded: url_helper
INFO - 2020-03-18 15:09:02 --> Helper loaded: file_helper
INFO - 2020-03-18 15:09:02 --> Helper loaded: form_helper
INFO - 2020-03-18 15:09:02 --> Helper loaded: my_helper
INFO - 2020-03-18 15:09:02 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:09:02 --> Controller Class Initialized
INFO - 2020-03-18 15:09:02 --> Config Class Initialized
INFO - 2020-03-18 15:09:02 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:09:02 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:09:02 --> Utf8 Class Initialized
INFO - 2020-03-18 15:09:02 --> URI Class Initialized
INFO - 2020-03-18 15:09:02 --> Router Class Initialized
INFO - 2020-03-18 15:09:02 --> Output Class Initialized
INFO - 2020-03-18 15:09:02 --> Security Class Initialized
DEBUG - 2020-03-18 15:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:09:02 --> Input Class Initialized
INFO - 2020-03-18 15:09:02 --> Language Class Initialized
INFO - 2020-03-18 15:09:02 --> Language Class Initialized
INFO - 2020-03-18 15:09:02 --> Config Class Initialized
INFO - 2020-03-18 15:09:02 --> Loader Class Initialized
INFO - 2020-03-18 15:09:02 --> Helper loaded: url_helper
INFO - 2020-03-18 15:09:02 --> Helper loaded: file_helper
INFO - 2020-03-18 15:09:02 --> Helper loaded: form_helper
INFO - 2020-03-18 15:09:02 --> Helper loaded: my_helper
INFO - 2020-03-18 15:09:02 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:09:03 --> Controller Class Initialized
DEBUG - 2020-03-18 15:09:03 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 15:09:03 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:09:03 --> Final output sent to browser
DEBUG - 2020-03-18 15:09:03 --> Total execution time: 0.5436
INFO - 2020-03-18 15:10:20 --> Config Class Initialized
INFO - 2020-03-18 15:10:20 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:10:20 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:10:20 --> Utf8 Class Initialized
INFO - 2020-03-18 15:10:20 --> URI Class Initialized
INFO - 2020-03-18 15:10:20 --> Router Class Initialized
INFO - 2020-03-18 15:10:20 --> Output Class Initialized
INFO - 2020-03-18 15:10:20 --> Security Class Initialized
DEBUG - 2020-03-18 15:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:10:20 --> Input Class Initialized
INFO - 2020-03-18 15:10:20 --> Language Class Initialized
INFO - 2020-03-18 15:10:21 --> Language Class Initialized
INFO - 2020-03-18 15:10:21 --> Config Class Initialized
INFO - 2020-03-18 15:10:21 --> Loader Class Initialized
INFO - 2020-03-18 15:10:21 --> Helper loaded: url_helper
INFO - 2020-03-18 15:10:21 --> Helper loaded: file_helper
INFO - 2020-03-18 15:10:21 --> Helper loaded: form_helper
INFO - 2020-03-18 15:10:21 --> Helper loaded: my_helper
INFO - 2020-03-18 15:10:21 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:10:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:10:21 --> Controller Class Initialized
DEBUG - 2020-03-18 15:10:21 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 15:10:21 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:10:21 --> Final output sent to browser
DEBUG - 2020-03-18 15:10:21 --> Total execution time: 0.5547
INFO - 2020-03-18 15:10:27 --> Config Class Initialized
INFO - 2020-03-18 15:10:27 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:10:27 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:10:27 --> Utf8 Class Initialized
INFO - 2020-03-18 15:10:27 --> URI Class Initialized
INFO - 2020-03-18 15:10:27 --> Router Class Initialized
INFO - 2020-03-18 15:10:27 --> Output Class Initialized
INFO - 2020-03-18 15:10:27 --> Security Class Initialized
DEBUG - 2020-03-18 15:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:10:27 --> Input Class Initialized
INFO - 2020-03-18 15:10:28 --> Language Class Initialized
INFO - 2020-03-18 15:10:28 --> Language Class Initialized
INFO - 2020-03-18 15:10:28 --> Config Class Initialized
INFO - 2020-03-18 15:10:28 --> Loader Class Initialized
INFO - 2020-03-18 15:10:28 --> Helper loaded: url_helper
INFO - 2020-03-18 15:10:28 --> Helper loaded: file_helper
INFO - 2020-03-18 15:10:28 --> Helper loaded: form_helper
INFO - 2020-03-18 15:10:28 --> Helper loaded: my_helper
INFO - 2020-03-18 15:10:28 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:10:28 --> Controller Class Initialized
INFO - 2020-03-18 15:10:28 --> Helper loaded: cookie_helper
INFO - 2020-03-18 15:10:28 --> Final output sent to browser
DEBUG - 2020-03-18 15:10:28 --> Total execution time: 0.5526
INFO - 2020-03-18 15:10:28 --> Config Class Initialized
INFO - 2020-03-18 15:10:28 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:10:28 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:10:28 --> Utf8 Class Initialized
INFO - 2020-03-18 15:10:28 --> URI Class Initialized
INFO - 2020-03-18 15:10:28 --> Router Class Initialized
INFO - 2020-03-18 15:10:28 --> Output Class Initialized
INFO - 2020-03-18 15:10:28 --> Security Class Initialized
DEBUG - 2020-03-18 15:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:10:28 --> Input Class Initialized
INFO - 2020-03-18 15:10:28 --> Language Class Initialized
INFO - 2020-03-18 15:10:28 --> Language Class Initialized
INFO - 2020-03-18 15:10:28 --> Config Class Initialized
INFO - 2020-03-18 15:10:28 --> Loader Class Initialized
INFO - 2020-03-18 15:10:28 --> Helper loaded: url_helper
INFO - 2020-03-18 15:10:28 --> Helper loaded: file_helper
INFO - 2020-03-18 15:10:28 --> Helper loaded: form_helper
INFO - 2020-03-18 15:10:28 --> Helper loaded: my_helper
INFO - 2020-03-18 15:10:28 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:10:29 --> Controller Class Initialized
DEBUG - 2020-03-18 15:10:29 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 15:10:29 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:10:29 --> Final output sent to browser
DEBUG - 2020-03-18 15:10:31 --> Total execution time: 0.7055
INFO - 2020-03-18 15:11:59 --> Config Class Initialized
INFO - 2020-03-18 15:11:59 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:11:59 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:11:59 --> Utf8 Class Initialized
INFO - 2020-03-18 15:11:59 --> URI Class Initialized
INFO - 2020-03-18 15:11:59 --> Router Class Initialized
INFO - 2020-03-18 15:11:59 --> Output Class Initialized
INFO - 2020-03-18 15:11:59 --> Security Class Initialized
DEBUG - 2020-03-18 15:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:11:59 --> Input Class Initialized
INFO - 2020-03-18 15:12:00 --> Language Class Initialized
INFO - 2020-03-18 15:12:00 --> Language Class Initialized
INFO - 2020-03-18 15:12:00 --> Config Class Initialized
INFO - 2020-03-18 15:12:00 --> Loader Class Initialized
INFO - 2020-03-18 15:12:00 --> Helper loaded: url_helper
INFO - 2020-03-18 15:12:00 --> Helper loaded: file_helper
INFO - 2020-03-18 15:12:00 --> Helper loaded: form_helper
INFO - 2020-03-18 15:12:00 --> Helper loaded: my_helper
INFO - 2020-03-18 15:12:00 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:12:00 --> Controller Class Initialized
INFO - 2020-03-18 15:12:00 --> Helper loaded: cookie_helper
INFO - 2020-03-18 15:12:00 --> Config Class Initialized
INFO - 2020-03-18 15:12:00 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:12:00 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:12:00 --> Utf8 Class Initialized
INFO - 2020-03-18 15:12:00 --> URI Class Initialized
INFO - 2020-03-18 15:12:00 --> Router Class Initialized
INFO - 2020-03-18 15:12:00 --> Output Class Initialized
INFO - 2020-03-18 15:12:00 --> Security Class Initialized
DEBUG - 2020-03-18 15:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:12:00 --> Input Class Initialized
INFO - 2020-03-18 15:12:00 --> Language Class Initialized
INFO - 2020-03-18 15:12:00 --> Language Class Initialized
INFO - 2020-03-18 15:12:00 --> Config Class Initialized
INFO - 2020-03-18 15:12:00 --> Loader Class Initialized
INFO - 2020-03-18 15:12:00 --> Helper loaded: url_helper
INFO - 2020-03-18 15:12:00 --> Helper loaded: file_helper
INFO - 2020-03-18 15:12:00 --> Helper loaded: form_helper
INFO - 2020-03-18 15:12:00 --> Helper loaded: my_helper
INFO - 2020-03-18 15:12:00 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:12:01 --> Controller Class Initialized
INFO - 2020-03-18 15:12:01 --> Config Class Initialized
INFO - 2020-03-18 15:12:01 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:12:01 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:12:01 --> Utf8 Class Initialized
INFO - 2020-03-18 15:12:01 --> URI Class Initialized
INFO - 2020-03-18 15:12:01 --> Router Class Initialized
INFO - 2020-03-18 15:12:01 --> Output Class Initialized
INFO - 2020-03-18 15:12:01 --> Security Class Initialized
DEBUG - 2020-03-18 15:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:12:01 --> Input Class Initialized
INFO - 2020-03-18 15:12:01 --> Language Class Initialized
INFO - 2020-03-18 15:12:01 --> Language Class Initialized
INFO - 2020-03-18 15:12:01 --> Config Class Initialized
INFO - 2020-03-18 15:12:01 --> Loader Class Initialized
INFO - 2020-03-18 15:12:01 --> Helper loaded: url_helper
INFO - 2020-03-18 15:12:01 --> Helper loaded: file_helper
INFO - 2020-03-18 15:12:01 --> Helper loaded: form_helper
INFO - 2020-03-18 15:12:01 --> Helper loaded: my_helper
INFO - 2020-03-18 15:12:01 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:12:01 --> Controller Class Initialized
DEBUG - 2020-03-18 15:12:01 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 15:12:01 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:12:01 --> Final output sent to browser
DEBUG - 2020-03-18 15:12:01 --> Total execution time: 0.6531
INFO - 2020-03-18 15:12:05 --> Config Class Initialized
INFO - 2020-03-18 15:12:05 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:12:05 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:12:06 --> Utf8 Class Initialized
INFO - 2020-03-18 15:12:06 --> URI Class Initialized
INFO - 2020-03-18 15:12:06 --> Router Class Initialized
INFO - 2020-03-18 15:12:06 --> Output Class Initialized
INFO - 2020-03-18 15:12:06 --> Security Class Initialized
DEBUG - 2020-03-18 15:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:12:06 --> Input Class Initialized
INFO - 2020-03-18 15:12:06 --> Language Class Initialized
INFO - 2020-03-18 15:12:06 --> Language Class Initialized
INFO - 2020-03-18 15:12:06 --> Config Class Initialized
INFO - 2020-03-18 15:12:06 --> Loader Class Initialized
INFO - 2020-03-18 15:12:06 --> Helper loaded: url_helper
INFO - 2020-03-18 15:12:06 --> Helper loaded: file_helper
INFO - 2020-03-18 15:12:06 --> Helper loaded: form_helper
INFO - 2020-03-18 15:12:06 --> Helper loaded: my_helper
INFO - 2020-03-18 15:12:06 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:12:06 --> Controller Class Initialized
DEBUG - 2020-03-18 15:12:06 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 15:12:06 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:12:06 --> Final output sent to browser
DEBUG - 2020-03-18 15:12:06 --> Total execution time: 0.5831
INFO - 2020-03-18 15:13:04 --> Config Class Initialized
INFO - 2020-03-18 15:13:04 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:13:04 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:13:04 --> Utf8 Class Initialized
INFO - 2020-03-18 15:13:04 --> URI Class Initialized
INFO - 2020-03-18 15:13:04 --> Router Class Initialized
INFO - 2020-03-18 15:13:04 --> Output Class Initialized
INFO - 2020-03-18 15:13:04 --> Security Class Initialized
DEBUG - 2020-03-18 15:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:13:04 --> Input Class Initialized
INFO - 2020-03-18 15:13:04 --> Language Class Initialized
INFO - 2020-03-18 15:13:04 --> Language Class Initialized
INFO - 2020-03-18 15:13:04 --> Config Class Initialized
INFO - 2020-03-18 15:13:04 --> Loader Class Initialized
INFO - 2020-03-18 15:13:04 --> Helper loaded: url_helper
INFO - 2020-03-18 15:13:04 --> Helper loaded: file_helper
INFO - 2020-03-18 15:13:04 --> Helper loaded: form_helper
INFO - 2020-03-18 15:13:04 --> Helper loaded: my_helper
INFO - 2020-03-18 15:13:04 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:13:04 --> Controller Class Initialized
DEBUG - 2020-03-18 15:13:04 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 15:13:04 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:13:04 --> Final output sent to browser
DEBUG - 2020-03-18 15:13:05 --> Total execution time: 0.5866
INFO - 2020-03-18 15:22:07 --> Config Class Initialized
INFO - 2020-03-18 15:22:07 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:22:07 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:22:07 --> Utf8 Class Initialized
INFO - 2020-03-18 15:22:07 --> URI Class Initialized
INFO - 2020-03-18 15:22:07 --> Router Class Initialized
INFO - 2020-03-18 15:22:08 --> Output Class Initialized
INFO - 2020-03-18 15:22:08 --> Security Class Initialized
DEBUG - 2020-03-18 15:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:22:08 --> Input Class Initialized
INFO - 2020-03-18 15:22:08 --> Language Class Initialized
INFO - 2020-03-18 15:22:08 --> Language Class Initialized
INFO - 2020-03-18 15:22:08 --> Config Class Initialized
INFO - 2020-03-18 15:22:08 --> Loader Class Initialized
INFO - 2020-03-18 15:22:08 --> Helper loaded: url_helper
INFO - 2020-03-18 15:22:08 --> Helper loaded: file_helper
INFO - 2020-03-18 15:22:08 --> Helper loaded: form_helper
INFO - 2020-03-18 15:22:08 --> Helper loaded: my_helper
INFO - 2020-03-18 15:22:08 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:22:09 --> Controller Class Initialized
DEBUG - 2020-03-18 15:22:09 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 15:22:09 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:22:09 --> Final output sent to browser
DEBUG - 2020-03-18 15:22:09 --> Total execution time: 1.7431
INFO - 2020-03-18 15:28:40 --> Config Class Initialized
INFO - 2020-03-18 15:28:40 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:28:40 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:28:40 --> Utf8 Class Initialized
INFO - 2020-03-18 15:28:40 --> URI Class Initialized
INFO - 2020-03-18 15:28:40 --> Router Class Initialized
INFO - 2020-03-18 15:28:40 --> Output Class Initialized
INFO - 2020-03-18 15:28:40 --> Security Class Initialized
DEBUG - 2020-03-18 15:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:28:40 --> Input Class Initialized
INFO - 2020-03-18 15:28:40 --> Language Class Initialized
INFO - 2020-03-18 15:28:40 --> Language Class Initialized
INFO - 2020-03-18 15:28:40 --> Config Class Initialized
INFO - 2020-03-18 15:28:40 --> Loader Class Initialized
INFO - 2020-03-18 15:28:40 --> Helper loaded: url_helper
INFO - 2020-03-18 15:28:40 --> Helper loaded: file_helper
INFO - 2020-03-18 15:28:40 --> Helper loaded: form_helper
INFO - 2020-03-18 15:28:40 --> Helper loaded: my_helper
INFO - 2020-03-18 15:28:40 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:28:40 --> Controller Class Initialized
DEBUG - 2020-03-18 15:28:40 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 15:28:40 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:28:40 --> Final output sent to browser
DEBUG - 2020-03-18 15:28:41 --> Total execution time: 0.6528
INFO - 2020-03-18 15:29:00 --> Config Class Initialized
INFO - 2020-03-18 15:29:00 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:29:01 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:29:01 --> Utf8 Class Initialized
INFO - 2020-03-18 15:29:01 --> URI Class Initialized
INFO - 2020-03-18 15:29:01 --> Router Class Initialized
INFO - 2020-03-18 15:29:01 --> Output Class Initialized
INFO - 2020-03-18 15:29:01 --> Security Class Initialized
DEBUG - 2020-03-18 15:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:29:01 --> Input Class Initialized
INFO - 2020-03-18 15:29:01 --> Language Class Initialized
INFO - 2020-03-18 15:29:01 --> Language Class Initialized
INFO - 2020-03-18 15:29:01 --> Config Class Initialized
INFO - 2020-03-18 15:29:01 --> Loader Class Initialized
INFO - 2020-03-18 15:29:01 --> Helper loaded: url_helper
INFO - 2020-03-18 15:29:01 --> Helper loaded: file_helper
INFO - 2020-03-18 15:29:01 --> Helper loaded: form_helper
INFO - 2020-03-18 15:29:01 --> Helper loaded: my_helper
INFO - 2020-03-18 15:29:01 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:29:01 --> Controller Class Initialized
DEBUG - 2020-03-18 15:29:01 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 15:29:01 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:29:01 --> Final output sent to browser
DEBUG - 2020-03-18 15:29:01 --> Total execution time: 0.6946
INFO - 2020-03-18 15:29:38 --> Config Class Initialized
INFO - 2020-03-18 15:29:38 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:29:38 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:29:38 --> Utf8 Class Initialized
INFO - 2020-03-18 15:29:38 --> URI Class Initialized
INFO - 2020-03-18 15:29:38 --> Router Class Initialized
INFO - 2020-03-18 15:29:38 --> Output Class Initialized
INFO - 2020-03-18 15:29:38 --> Security Class Initialized
DEBUG - 2020-03-18 15:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:29:38 --> Input Class Initialized
INFO - 2020-03-18 15:29:38 --> Language Class Initialized
INFO - 2020-03-18 15:29:38 --> Language Class Initialized
INFO - 2020-03-18 15:29:38 --> Config Class Initialized
INFO - 2020-03-18 15:29:38 --> Loader Class Initialized
INFO - 2020-03-18 15:29:38 --> Helper loaded: url_helper
INFO - 2020-03-18 15:29:38 --> Helper loaded: file_helper
INFO - 2020-03-18 15:29:38 --> Helper loaded: form_helper
INFO - 2020-03-18 15:29:38 --> Helper loaded: my_helper
INFO - 2020-03-18 15:29:38 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:29:38 --> Controller Class Initialized
DEBUG - 2020-03-18 15:29:38 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 15:29:39 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:29:39 --> Final output sent to browser
DEBUG - 2020-03-18 15:29:39 --> Total execution time: 0.6118
INFO - 2020-03-18 15:29:42 --> Config Class Initialized
INFO - 2020-03-18 15:29:42 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:29:42 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:29:42 --> Utf8 Class Initialized
INFO - 2020-03-18 15:29:42 --> URI Class Initialized
INFO - 2020-03-18 15:29:42 --> Router Class Initialized
INFO - 2020-03-18 15:29:42 --> Output Class Initialized
INFO - 2020-03-18 15:29:42 --> Security Class Initialized
DEBUG - 2020-03-18 15:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:29:42 --> Input Class Initialized
INFO - 2020-03-18 15:29:42 --> Language Class Initialized
INFO - 2020-03-18 15:29:42 --> Language Class Initialized
INFO - 2020-03-18 15:29:42 --> Config Class Initialized
INFO - 2020-03-18 15:29:42 --> Loader Class Initialized
INFO - 2020-03-18 15:29:42 --> Helper loaded: url_helper
INFO - 2020-03-18 15:29:42 --> Helper loaded: file_helper
INFO - 2020-03-18 15:29:42 --> Helper loaded: form_helper
INFO - 2020-03-18 15:29:42 --> Helper loaded: my_helper
INFO - 2020-03-18 15:29:42 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:29:42 --> Controller Class Initialized
DEBUG - 2020-03-18 15:29:42 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 15:29:42 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:29:42 --> Final output sent to browser
DEBUG - 2020-03-18 15:29:42 --> Total execution time: 0.5584
INFO - 2020-03-18 15:29:53 --> Config Class Initialized
INFO - 2020-03-18 15:29:53 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:29:53 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:29:53 --> Utf8 Class Initialized
INFO - 2020-03-18 15:29:53 --> URI Class Initialized
INFO - 2020-03-18 15:29:53 --> Router Class Initialized
INFO - 2020-03-18 15:29:53 --> Output Class Initialized
INFO - 2020-03-18 15:29:53 --> Security Class Initialized
DEBUG - 2020-03-18 15:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:29:53 --> Input Class Initialized
INFO - 2020-03-18 15:29:53 --> Language Class Initialized
INFO - 2020-03-18 15:29:53 --> Language Class Initialized
INFO - 2020-03-18 15:29:53 --> Config Class Initialized
INFO - 2020-03-18 15:29:53 --> Loader Class Initialized
INFO - 2020-03-18 15:29:53 --> Helper loaded: url_helper
INFO - 2020-03-18 15:29:53 --> Helper loaded: file_helper
INFO - 2020-03-18 15:29:53 --> Helper loaded: form_helper
INFO - 2020-03-18 15:29:53 --> Helper loaded: my_helper
INFO - 2020-03-18 15:29:53 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:29:53 --> Controller Class Initialized
INFO - 2020-03-18 15:29:53 --> Helper loaded: cookie_helper
INFO - 2020-03-18 15:29:53 --> Final output sent to browser
DEBUG - 2020-03-18 15:29:53 --> Total execution time: 0.5728
INFO - 2020-03-18 15:29:53 --> Config Class Initialized
INFO - 2020-03-18 15:29:53 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:29:54 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:29:54 --> Utf8 Class Initialized
INFO - 2020-03-18 15:29:54 --> URI Class Initialized
INFO - 2020-03-18 15:29:54 --> Router Class Initialized
INFO - 2020-03-18 15:29:54 --> Output Class Initialized
INFO - 2020-03-18 15:29:54 --> Security Class Initialized
DEBUG - 2020-03-18 15:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:29:54 --> Input Class Initialized
INFO - 2020-03-18 15:29:54 --> Language Class Initialized
INFO - 2020-03-18 15:29:54 --> Language Class Initialized
INFO - 2020-03-18 15:29:54 --> Config Class Initialized
INFO - 2020-03-18 15:29:54 --> Loader Class Initialized
INFO - 2020-03-18 15:29:54 --> Helper loaded: url_helper
INFO - 2020-03-18 15:29:54 --> Helper loaded: file_helper
INFO - 2020-03-18 15:29:54 --> Helper loaded: form_helper
INFO - 2020-03-18 15:29:54 --> Helper loaded: my_helper
INFO - 2020-03-18 15:29:54 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:29:54 --> Controller Class Initialized
DEBUG - 2020-03-18 15:29:54 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 15:29:54 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:29:54 --> Final output sent to browser
DEBUG - 2020-03-18 15:29:58 --> Total execution time: 0.7636
INFO - 2020-03-18 15:32:25 --> Config Class Initialized
INFO - 2020-03-18 15:32:25 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:32:25 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:32:25 --> Utf8 Class Initialized
INFO - 2020-03-18 15:32:25 --> URI Class Initialized
INFO - 2020-03-18 15:32:25 --> Router Class Initialized
INFO - 2020-03-18 15:32:25 --> Output Class Initialized
INFO - 2020-03-18 15:32:25 --> Security Class Initialized
DEBUG - 2020-03-18 15:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:32:25 --> Input Class Initialized
INFO - 2020-03-18 15:32:25 --> Language Class Initialized
INFO - 2020-03-18 15:32:25 --> Language Class Initialized
INFO - 2020-03-18 15:32:25 --> Config Class Initialized
INFO - 2020-03-18 15:32:25 --> Loader Class Initialized
INFO - 2020-03-18 15:32:25 --> Helper loaded: url_helper
INFO - 2020-03-18 15:32:25 --> Helper loaded: file_helper
INFO - 2020-03-18 15:32:25 --> Helper loaded: form_helper
INFO - 2020-03-18 15:32:25 --> Helper loaded: my_helper
INFO - 2020-03-18 15:32:25 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:32:25 --> Controller Class Initialized
DEBUG - 2020-03-18 15:32:25 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 15:32:25 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:32:26 --> Final output sent to browser
DEBUG - 2020-03-18 15:32:26 --> Total execution time: 1.0234
INFO - 2020-03-18 15:40:03 --> Config Class Initialized
INFO - 2020-03-18 15:40:03 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:40:03 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:40:03 --> Utf8 Class Initialized
INFO - 2020-03-18 15:40:04 --> URI Class Initialized
INFO - 2020-03-18 15:40:04 --> Router Class Initialized
INFO - 2020-03-18 15:40:04 --> Output Class Initialized
INFO - 2020-03-18 15:40:04 --> Security Class Initialized
DEBUG - 2020-03-18 15:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:40:04 --> Input Class Initialized
INFO - 2020-03-18 15:40:04 --> Language Class Initialized
INFO - 2020-03-18 15:40:04 --> Language Class Initialized
INFO - 2020-03-18 15:40:04 --> Config Class Initialized
INFO - 2020-03-18 15:40:04 --> Loader Class Initialized
INFO - 2020-03-18 15:40:04 --> Helper loaded: url_helper
INFO - 2020-03-18 15:40:04 --> Helper loaded: file_helper
INFO - 2020-03-18 15:40:04 --> Helper loaded: form_helper
INFO - 2020-03-18 15:40:04 --> Helper loaded: my_helper
INFO - 2020-03-18 15:40:04 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:40:04 --> Controller Class Initialized
DEBUG - 2020-03-18 15:40:04 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 15:40:04 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:40:04 --> Final output sent to browser
DEBUG - 2020-03-18 15:40:04 --> Total execution time: 0.5938
INFO - 2020-03-18 15:40:46 --> Config Class Initialized
INFO - 2020-03-18 15:40:46 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:40:46 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:40:46 --> Utf8 Class Initialized
INFO - 2020-03-18 15:40:46 --> URI Class Initialized
INFO - 2020-03-18 15:40:46 --> Router Class Initialized
INFO - 2020-03-18 15:40:46 --> Output Class Initialized
INFO - 2020-03-18 15:40:46 --> Security Class Initialized
DEBUG - 2020-03-18 15:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:40:46 --> Input Class Initialized
INFO - 2020-03-18 15:40:46 --> Language Class Initialized
INFO - 2020-03-18 15:40:46 --> Language Class Initialized
INFO - 2020-03-18 15:40:46 --> Config Class Initialized
INFO - 2020-03-18 15:40:46 --> Loader Class Initialized
INFO - 2020-03-18 15:40:46 --> Helper loaded: url_helper
INFO - 2020-03-18 15:40:46 --> Helper loaded: file_helper
INFO - 2020-03-18 15:40:46 --> Helper loaded: form_helper
INFO - 2020-03-18 15:40:46 --> Helper loaded: my_helper
INFO - 2020-03-18 15:40:46 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:40:46 --> Controller Class Initialized
DEBUG - 2020-03-18 15:40:46 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 15:40:47 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:40:47 --> Final output sent to browser
DEBUG - 2020-03-18 15:40:47 --> Total execution time: 0.6229
INFO - 2020-03-18 15:42:46 --> Config Class Initialized
INFO - 2020-03-18 15:42:46 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:42:46 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:42:46 --> Utf8 Class Initialized
INFO - 2020-03-18 15:42:46 --> URI Class Initialized
INFO - 2020-03-18 15:42:46 --> Router Class Initialized
INFO - 2020-03-18 15:42:46 --> Output Class Initialized
INFO - 2020-03-18 15:42:46 --> Security Class Initialized
DEBUG - 2020-03-18 15:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:42:46 --> Input Class Initialized
INFO - 2020-03-18 15:42:46 --> Language Class Initialized
INFO - 2020-03-18 15:42:47 --> Language Class Initialized
INFO - 2020-03-18 15:42:47 --> Config Class Initialized
INFO - 2020-03-18 15:42:47 --> Loader Class Initialized
INFO - 2020-03-18 15:42:47 --> Helper loaded: url_helper
INFO - 2020-03-18 15:42:47 --> Helper loaded: file_helper
INFO - 2020-03-18 15:42:47 --> Helper loaded: form_helper
INFO - 2020-03-18 15:42:47 --> Helper loaded: my_helper
INFO - 2020-03-18 15:42:47 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:42:47 --> Controller Class Initialized
DEBUG - 2020-03-18 15:42:47 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 15:42:47 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:42:47 --> Final output sent to browser
DEBUG - 2020-03-18 15:42:47 --> Total execution time: 0.6175
INFO - 2020-03-18 15:44:00 --> Config Class Initialized
INFO - 2020-03-18 15:44:00 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:44:00 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:44:00 --> Utf8 Class Initialized
INFO - 2020-03-18 15:44:00 --> URI Class Initialized
INFO - 2020-03-18 15:44:00 --> Router Class Initialized
INFO - 2020-03-18 15:44:00 --> Output Class Initialized
INFO - 2020-03-18 15:44:01 --> Security Class Initialized
DEBUG - 2020-03-18 15:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:44:01 --> Input Class Initialized
INFO - 2020-03-18 15:44:01 --> Language Class Initialized
INFO - 2020-03-18 15:44:01 --> Language Class Initialized
INFO - 2020-03-18 15:44:01 --> Config Class Initialized
INFO - 2020-03-18 15:44:01 --> Loader Class Initialized
INFO - 2020-03-18 15:44:01 --> Helper loaded: url_helper
INFO - 2020-03-18 15:44:01 --> Helper loaded: file_helper
INFO - 2020-03-18 15:44:01 --> Helper loaded: form_helper
INFO - 2020-03-18 15:44:01 --> Helper loaded: my_helper
INFO - 2020-03-18 15:44:01 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:44:01 --> Controller Class Initialized
DEBUG - 2020-03-18 15:44:01 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 15:44:01 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:44:01 --> Final output sent to browser
DEBUG - 2020-03-18 15:44:01 --> Total execution time: 0.5849
INFO - 2020-03-18 15:44:30 --> Config Class Initialized
INFO - 2020-03-18 15:44:30 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:44:31 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:44:31 --> Utf8 Class Initialized
INFO - 2020-03-18 15:44:31 --> URI Class Initialized
INFO - 2020-03-18 15:44:31 --> Router Class Initialized
INFO - 2020-03-18 15:44:31 --> Output Class Initialized
INFO - 2020-03-18 15:44:31 --> Security Class Initialized
DEBUG - 2020-03-18 15:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:44:31 --> Input Class Initialized
INFO - 2020-03-18 15:44:31 --> Language Class Initialized
INFO - 2020-03-18 15:44:31 --> Language Class Initialized
INFO - 2020-03-18 15:44:31 --> Config Class Initialized
INFO - 2020-03-18 15:44:31 --> Loader Class Initialized
INFO - 2020-03-18 15:44:31 --> Helper loaded: url_helper
INFO - 2020-03-18 15:44:31 --> Helper loaded: file_helper
INFO - 2020-03-18 15:44:31 --> Helper loaded: form_helper
INFO - 2020-03-18 15:44:31 --> Helper loaded: my_helper
INFO - 2020-03-18 15:44:31 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:44:31 --> Controller Class Initialized
DEBUG - 2020-03-18 15:44:31 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 15:44:31 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:44:31 --> Final output sent to browser
DEBUG - 2020-03-18 15:44:32 --> Total execution time: 1.0411
INFO - 2020-03-18 15:44:37 --> Config Class Initialized
INFO - 2020-03-18 15:44:37 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:44:37 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:44:37 --> Utf8 Class Initialized
INFO - 2020-03-18 15:44:37 --> URI Class Initialized
INFO - 2020-03-18 15:44:37 --> Router Class Initialized
INFO - 2020-03-18 15:44:37 --> Output Class Initialized
INFO - 2020-03-18 15:44:37 --> Security Class Initialized
DEBUG - 2020-03-18 15:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:44:38 --> Input Class Initialized
INFO - 2020-03-18 15:44:38 --> Language Class Initialized
INFO - 2020-03-18 15:44:38 --> Language Class Initialized
INFO - 2020-03-18 15:44:38 --> Config Class Initialized
INFO - 2020-03-18 15:44:38 --> Loader Class Initialized
INFO - 2020-03-18 15:44:38 --> Helper loaded: url_helper
INFO - 2020-03-18 15:44:38 --> Helper loaded: file_helper
INFO - 2020-03-18 15:44:38 --> Helper loaded: form_helper
INFO - 2020-03-18 15:44:38 --> Helper loaded: my_helper
INFO - 2020-03-18 15:44:38 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:44:38 --> Controller Class Initialized
DEBUG - 2020-03-18 15:44:38 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-03-18 15:44:38 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:44:38 --> Final output sent to browser
DEBUG - 2020-03-18 15:44:38 --> Total execution time: 0.9544
INFO - 2020-03-18 15:44:39 --> Config Class Initialized
INFO - 2020-03-18 15:44:39 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:44:39 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:44:39 --> Utf8 Class Initialized
INFO - 2020-03-18 15:44:40 --> URI Class Initialized
INFO - 2020-03-18 15:44:40 --> Router Class Initialized
INFO - 2020-03-18 15:44:40 --> Output Class Initialized
INFO - 2020-03-18 15:44:40 --> Security Class Initialized
DEBUG - 2020-03-18 15:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:44:40 --> Input Class Initialized
INFO - 2020-03-18 15:44:40 --> Language Class Initialized
INFO - 2020-03-18 15:44:40 --> Language Class Initialized
INFO - 2020-03-18 15:44:40 --> Config Class Initialized
INFO - 2020-03-18 15:44:40 --> Loader Class Initialized
INFO - 2020-03-18 15:44:40 --> Helper loaded: url_helper
INFO - 2020-03-18 15:44:40 --> Helper loaded: file_helper
INFO - 2020-03-18 15:44:40 --> Helper loaded: form_helper
INFO - 2020-03-18 15:44:40 --> Helper loaded: my_helper
INFO - 2020-03-18 15:44:40 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:44:40 --> Controller Class Initialized
INFO - 2020-03-18 15:44:44 --> Config Class Initialized
INFO - 2020-03-18 15:44:44 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:44:44 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:44:44 --> Utf8 Class Initialized
INFO - 2020-03-18 15:44:44 --> URI Class Initialized
DEBUG - 2020-03-18 15:44:44 --> No URI present. Default controller set.
INFO - 2020-03-18 15:44:44 --> Router Class Initialized
INFO - 2020-03-18 15:44:44 --> Output Class Initialized
INFO - 2020-03-18 15:44:44 --> Security Class Initialized
DEBUG - 2020-03-18 15:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:44:44 --> Input Class Initialized
INFO - 2020-03-18 15:44:44 --> Language Class Initialized
INFO - 2020-03-18 15:44:44 --> Language Class Initialized
INFO - 2020-03-18 15:44:44 --> Config Class Initialized
INFO - 2020-03-18 15:44:44 --> Loader Class Initialized
INFO - 2020-03-18 15:44:44 --> Helper loaded: url_helper
INFO - 2020-03-18 15:44:44 --> Helper loaded: file_helper
INFO - 2020-03-18 15:44:44 --> Helper loaded: form_helper
INFO - 2020-03-18 15:44:44 --> Helper loaded: my_helper
INFO - 2020-03-18 15:44:44 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:44:44 --> Controller Class Initialized
DEBUG - 2020-03-18 15:44:44 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 15:44:44 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:44:44 --> Final output sent to browser
DEBUG - 2020-03-18 15:44:45 --> Total execution time: 0.5671
INFO - 2020-03-18 15:46:41 --> Config Class Initialized
INFO - 2020-03-18 15:46:41 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:46:41 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:46:41 --> Utf8 Class Initialized
INFO - 2020-03-18 15:46:41 --> URI Class Initialized
DEBUG - 2020-03-18 15:46:41 --> No URI present. Default controller set.
INFO - 2020-03-18 15:46:41 --> Router Class Initialized
INFO - 2020-03-18 15:46:41 --> Output Class Initialized
INFO - 2020-03-18 15:46:41 --> Security Class Initialized
DEBUG - 2020-03-18 15:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:46:41 --> Input Class Initialized
INFO - 2020-03-18 15:46:41 --> Language Class Initialized
INFO - 2020-03-18 15:46:42 --> Language Class Initialized
INFO - 2020-03-18 15:46:42 --> Config Class Initialized
INFO - 2020-03-18 15:46:42 --> Loader Class Initialized
INFO - 2020-03-18 15:46:42 --> Helper loaded: url_helper
INFO - 2020-03-18 15:46:42 --> Helper loaded: file_helper
INFO - 2020-03-18 15:46:42 --> Helper loaded: form_helper
INFO - 2020-03-18 15:46:42 --> Helper loaded: my_helper
INFO - 2020-03-18 15:46:42 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:46:42 --> Controller Class Initialized
DEBUG - 2020-03-18 15:46:42 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 15:46:42 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:46:42 --> Final output sent to browser
DEBUG - 2020-03-18 15:46:42 --> Total execution time: 0.7221
INFO - 2020-03-18 15:47:42 --> Config Class Initialized
INFO - 2020-03-18 15:47:42 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:47:42 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:47:42 --> Utf8 Class Initialized
INFO - 2020-03-18 15:47:42 --> URI Class Initialized
DEBUG - 2020-03-18 15:47:42 --> No URI present. Default controller set.
INFO - 2020-03-18 15:47:42 --> Router Class Initialized
INFO - 2020-03-18 15:47:42 --> Output Class Initialized
INFO - 2020-03-18 15:47:42 --> Security Class Initialized
DEBUG - 2020-03-18 15:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:47:42 --> Input Class Initialized
INFO - 2020-03-18 15:47:42 --> Language Class Initialized
INFO - 2020-03-18 15:47:42 --> Language Class Initialized
INFO - 2020-03-18 15:47:42 --> Config Class Initialized
INFO - 2020-03-18 15:47:42 --> Loader Class Initialized
INFO - 2020-03-18 15:47:42 --> Helper loaded: url_helper
INFO - 2020-03-18 15:47:42 --> Helper loaded: file_helper
INFO - 2020-03-18 15:47:42 --> Helper loaded: form_helper
INFO - 2020-03-18 15:47:42 --> Helper loaded: my_helper
INFO - 2020-03-18 15:47:42 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:47:42 --> Controller Class Initialized
DEBUG - 2020-03-18 15:47:42 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 15:47:42 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:47:42 --> Final output sent to browser
DEBUG - 2020-03-18 15:47:42 --> Total execution time: 0.6188
INFO - 2020-03-18 15:47:45 --> Config Class Initialized
INFO - 2020-03-18 15:47:45 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:47:45 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:47:45 --> Utf8 Class Initialized
INFO - 2020-03-18 15:47:45 --> URI Class Initialized
INFO - 2020-03-18 15:47:45 --> Router Class Initialized
INFO - 2020-03-18 15:47:45 --> Output Class Initialized
INFO - 2020-03-18 15:47:46 --> Security Class Initialized
DEBUG - 2020-03-18 15:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:47:46 --> Input Class Initialized
INFO - 2020-03-18 15:47:46 --> Language Class Initialized
INFO - 2020-03-18 15:47:46 --> Language Class Initialized
INFO - 2020-03-18 15:47:46 --> Config Class Initialized
INFO - 2020-03-18 15:47:46 --> Loader Class Initialized
INFO - 2020-03-18 15:47:46 --> Helper loaded: url_helper
INFO - 2020-03-18 15:47:46 --> Helper loaded: file_helper
INFO - 2020-03-18 15:47:46 --> Helper loaded: form_helper
INFO - 2020-03-18 15:47:46 --> Helper loaded: my_helper
INFO - 2020-03-18 15:47:46 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:47:46 --> Controller Class Initialized
DEBUG - 2020-03-18 15:47:46 --> File loaded: D:\xampp\htdocs\myraport\application\modules/set_mapel/views/list.php
DEBUG - 2020-03-18 15:47:46 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:47:46 --> Final output sent to browser
DEBUG - 2020-03-18 15:47:46 --> Total execution time: 0.6290
INFO - 2020-03-18 15:47:46 --> Config Class Initialized
INFO - 2020-03-18 15:47:46 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:47:46 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:47:46 --> Utf8 Class Initialized
INFO - 2020-03-18 15:47:46 --> URI Class Initialized
INFO - 2020-03-18 15:47:46 --> Router Class Initialized
INFO - 2020-03-18 15:47:47 --> Output Class Initialized
INFO - 2020-03-18 15:47:47 --> Security Class Initialized
DEBUG - 2020-03-18 15:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:47:47 --> Input Class Initialized
INFO - 2020-03-18 15:47:47 --> Language Class Initialized
INFO - 2020-03-18 15:47:47 --> Language Class Initialized
INFO - 2020-03-18 15:47:47 --> Config Class Initialized
INFO - 2020-03-18 15:47:47 --> Loader Class Initialized
INFO - 2020-03-18 15:47:47 --> Helper loaded: url_helper
INFO - 2020-03-18 15:47:47 --> Helper loaded: file_helper
INFO - 2020-03-18 15:47:47 --> Helper loaded: form_helper
INFO - 2020-03-18 15:47:47 --> Helper loaded: my_helper
INFO - 2020-03-18 15:47:47 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:47:47 --> Controller Class Initialized
INFO - 2020-03-18 15:47:54 --> Config Class Initialized
INFO - 2020-03-18 15:47:54 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:47:54 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:47:54 --> Utf8 Class Initialized
INFO - 2020-03-18 15:47:54 --> URI Class Initialized
INFO - 2020-03-18 15:47:54 --> Router Class Initialized
INFO - 2020-03-18 15:47:54 --> Output Class Initialized
INFO - 2020-03-18 15:47:54 --> Security Class Initialized
DEBUG - 2020-03-18 15:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:47:54 --> Input Class Initialized
INFO - 2020-03-18 15:47:54 --> Language Class Initialized
INFO - 2020-03-18 15:47:54 --> Language Class Initialized
INFO - 2020-03-18 15:47:54 --> Config Class Initialized
INFO - 2020-03-18 15:47:54 --> Loader Class Initialized
INFO - 2020-03-18 15:47:54 --> Helper loaded: url_helper
INFO - 2020-03-18 15:47:54 --> Helper loaded: file_helper
INFO - 2020-03-18 15:47:54 --> Helper loaded: form_helper
INFO - 2020-03-18 15:47:54 --> Helper loaded: my_helper
INFO - 2020-03-18 15:47:54 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:47:54 --> Controller Class Initialized
DEBUG - 2020-03-18 15:47:54 --> File loaded: D:\xampp\htdocs\myraport\application\modules/set_walikelas/views/list.php
DEBUG - 2020-03-18 15:47:54 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:47:54 --> Final output sent to browser
DEBUG - 2020-03-18 15:47:54 --> Total execution time: 0.5405
INFO - 2020-03-18 15:47:55 --> Config Class Initialized
INFO - 2020-03-18 15:47:55 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:47:55 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:47:55 --> Utf8 Class Initialized
INFO - 2020-03-18 15:47:55 --> URI Class Initialized
INFO - 2020-03-18 15:47:55 --> Router Class Initialized
INFO - 2020-03-18 15:47:55 --> Output Class Initialized
INFO - 2020-03-18 15:47:55 --> Security Class Initialized
DEBUG - 2020-03-18 15:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:47:55 --> Input Class Initialized
INFO - 2020-03-18 15:47:55 --> Language Class Initialized
INFO - 2020-03-18 15:47:55 --> Language Class Initialized
INFO - 2020-03-18 15:47:55 --> Config Class Initialized
INFO - 2020-03-18 15:47:55 --> Loader Class Initialized
INFO - 2020-03-18 15:47:55 --> Helper loaded: url_helper
INFO - 2020-03-18 15:47:55 --> Helper loaded: file_helper
INFO - 2020-03-18 15:47:55 --> Helper loaded: form_helper
INFO - 2020-03-18 15:47:55 --> Helper loaded: my_helper
INFO - 2020-03-18 15:47:55 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:47:55 --> Controller Class Initialized
INFO - 2020-03-18 15:48:13 --> Config Class Initialized
INFO - 2020-03-18 15:48:13 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:48:13 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:48:13 --> Utf8 Class Initialized
INFO - 2020-03-18 15:48:13 --> URI Class Initialized
INFO - 2020-03-18 15:48:13 --> Router Class Initialized
INFO - 2020-03-18 15:48:13 --> Output Class Initialized
INFO - 2020-03-18 15:48:13 --> Security Class Initialized
DEBUG - 2020-03-18 15:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:48:13 --> Input Class Initialized
INFO - 2020-03-18 15:48:13 --> Language Class Initialized
INFO - 2020-03-18 15:48:13 --> Language Class Initialized
INFO - 2020-03-18 15:48:13 --> Config Class Initialized
INFO - 2020-03-18 15:48:13 --> Loader Class Initialized
INFO - 2020-03-18 15:48:13 --> Helper loaded: url_helper
INFO - 2020-03-18 15:48:13 --> Helper loaded: file_helper
INFO - 2020-03-18 15:48:13 --> Helper loaded: form_helper
INFO - 2020-03-18 15:48:13 --> Helper loaded: my_helper
INFO - 2020-03-18 15:48:13 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:48:13 --> Controller Class Initialized
DEBUG - 2020-03-18 15:48:13 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-03-18 15:48:13 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:48:13 --> Final output sent to browser
DEBUG - 2020-03-18 15:48:13 --> Total execution time: 0.6503
INFO - 2020-03-18 15:48:14 --> Config Class Initialized
INFO - 2020-03-18 15:48:14 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:48:14 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:48:14 --> Utf8 Class Initialized
INFO - 2020-03-18 15:48:14 --> URI Class Initialized
INFO - 2020-03-18 15:48:14 --> Router Class Initialized
INFO - 2020-03-18 15:48:15 --> Output Class Initialized
INFO - 2020-03-18 15:48:15 --> Security Class Initialized
DEBUG - 2020-03-18 15:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:48:15 --> Input Class Initialized
INFO - 2020-03-18 15:48:15 --> Language Class Initialized
INFO - 2020-03-18 15:48:15 --> Language Class Initialized
INFO - 2020-03-18 15:48:15 --> Config Class Initialized
INFO - 2020-03-18 15:48:15 --> Loader Class Initialized
INFO - 2020-03-18 15:48:15 --> Helper loaded: url_helper
INFO - 2020-03-18 15:48:15 --> Helper loaded: file_helper
INFO - 2020-03-18 15:48:15 --> Helper loaded: form_helper
INFO - 2020-03-18 15:48:15 --> Helper loaded: my_helper
INFO - 2020-03-18 15:48:15 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:48:15 --> Controller Class Initialized
INFO - 2020-03-18 15:48:15 --> Config Class Initialized
INFO - 2020-03-18 15:48:15 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:48:15 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:48:15 --> Utf8 Class Initialized
INFO - 2020-03-18 15:48:15 --> URI Class Initialized
INFO - 2020-03-18 15:48:15 --> Router Class Initialized
INFO - 2020-03-18 15:48:15 --> Output Class Initialized
INFO - 2020-03-18 15:48:15 --> Security Class Initialized
DEBUG - 2020-03-18 15:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:48:15 --> Input Class Initialized
INFO - 2020-03-18 15:48:15 --> Language Class Initialized
INFO - 2020-03-18 15:48:15 --> Language Class Initialized
INFO - 2020-03-18 15:48:15 --> Config Class Initialized
INFO - 2020-03-18 15:48:15 --> Loader Class Initialized
INFO - 2020-03-18 15:48:15 --> Helper loaded: url_helper
INFO - 2020-03-18 15:48:15 --> Helper loaded: file_helper
INFO - 2020-03-18 15:48:15 --> Helper loaded: form_helper
INFO - 2020-03-18 15:48:15 --> Helper loaded: my_helper
INFO - 2020-03-18 15:48:15 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:48:16 --> Controller Class Initialized
DEBUG - 2020-03-18 15:48:16 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_guru/views/list.php
DEBUG - 2020-03-18 15:48:16 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:48:16 --> Final output sent to browser
DEBUG - 2020-03-18 15:48:16 --> Total execution time: 0.7246
INFO - 2020-03-18 15:48:16 --> Config Class Initialized
INFO - 2020-03-18 15:48:16 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:48:16 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:48:16 --> Utf8 Class Initialized
INFO - 2020-03-18 15:48:16 --> URI Class Initialized
INFO - 2020-03-18 15:48:16 --> Router Class Initialized
INFO - 2020-03-18 15:48:16 --> Output Class Initialized
INFO - 2020-03-18 15:48:16 --> Security Class Initialized
DEBUG - 2020-03-18 15:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:48:16 --> Input Class Initialized
INFO - 2020-03-18 15:48:16 --> Language Class Initialized
INFO - 2020-03-18 15:48:17 --> Language Class Initialized
INFO - 2020-03-18 15:48:17 --> Config Class Initialized
INFO - 2020-03-18 15:48:17 --> Loader Class Initialized
INFO - 2020-03-18 15:48:17 --> Helper loaded: url_helper
INFO - 2020-03-18 15:48:17 --> Helper loaded: file_helper
INFO - 2020-03-18 15:48:17 --> Helper loaded: form_helper
INFO - 2020-03-18 15:48:17 --> Helper loaded: my_helper
INFO - 2020-03-18 15:48:17 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:48:17 --> Controller Class Initialized
INFO - 2020-03-18 15:48:24 --> Config Class Initialized
INFO - 2020-03-18 15:48:24 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:48:24 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:48:24 --> Utf8 Class Initialized
INFO - 2020-03-18 15:48:24 --> URI Class Initialized
INFO - 2020-03-18 15:48:24 --> Router Class Initialized
INFO - 2020-03-18 15:48:24 --> Output Class Initialized
INFO - 2020-03-18 15:48:24 --> Security Class Initialized
DEBUG - 2020-03-18 15:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:48:24 --> Input Class Initialized
INFO - 2020-03-18 15:48:24 --> Language Class Initialized
INFO - 2020-03-18 15:48:24 --> Language Class Initialized
INFO - 2020-03-18 15:48:24 --> Config Class Initialized
INFO - 2020-03-18 15:48:24 --> Loader Class Initialized
INFO - 2020-03-18 15:48:24 --> Helper loaded: url_helper
INFO - 2020-03-18 15:48:24 --> Helper loaded: file_helper
INFO - 2020-03-18 15:48:24 --> Helper loaded: form_helper
INFO - 2020-03-18 15:48:24 --> Helper loaded: my_helper
INFO - 2020-03-18 15:48:24 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:48:24 --> Controller Class Initialized
INFO - 2020-03-18 15:48:24 --> Helper loaded: cookie_helper
INFO - 2020-03-18 15:48:24 --> Config Class Initialized
INFO - 2020-03-18 15:48:24 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:48:24 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:48:24 --> Utf8 Class Initialized
INFO - 2020-03-18 15:48:24 --> URI Class Initialized
INFO - 2020-03-18 15:48:24 --> Router Class Initialized
INFO - 2020-03-18 15:48:24 --> Output Class Initialized
INFO - 2020-03-18 15:48:24 --> Security Class Initialized
DEBUG - 2020-03-18 15:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:48:24 --> Input Class Initialized
INFO - 2020-03-18 15:48:24 --> Language Class Initialized
INFO - 2020-03-18 15:48:25 --> Language Class Initialized
INFO - 2020-03-18 15:48:25 --> Config Class Initialized
INFO - 2020-03-18 15:48:25 --> Loader Class Initialized
INFO - 2020-03-18 15:48:25 --> Helper loaded: url_helper
INFO - 2020-03-18 15:48:25 --> Helper loaded: file_helper
INFO - 2020-03-18 15:48:25 --> Helper loaded: form_helper
INFO - 2020-03-18 15:48:25 --> Helper loaded: my_helper
INFO - 2020-03-18 15:48:25 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:48:25 --> Controller Class Initialized
INFO - 2020-03-18 15:48:25 --> Config Class Initialized
INFO - 2020-03-18 15:48:25 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:48:25 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:48:25 --> Utf8 Class Initialized
INFO - 2020-03-18 15:48:25 --> URI Class Initialized
INFO - 2020-03-18 15:48:25 --> Router Class Initialized
INFO - 2020-03-18 15:48:25 --> Output Class Initialized
INFO - 2020-03-18 15:48:25 --> Security Class Initialized
DEBUG - 2020-03-18 15:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:48:25 --> Input Class Initialized
INFO - 2020-03-18 15:48:25 --> Language Class Initialized
INFO - 2020-03-18 15:48:25 --> Language Class Initialized
INFO - 2020-03-18 15:48:25 --> Config Class Initialized
INFO - 2020-03-18 15:48:25 --> Loader Class Initialized
INFO - 2020-03-18 15:48:25 --> Helper loaded: url_helper
INFO - 2020-03-18 15:48:25 --> Helper loaded: file_helper
INFO - 2020-03-18 15:48:25 --> Helper loaded: form_helper
INFO - 2020-03-18 15:48:25 --> Helper loaded: my_helper
INFO - 2020-03-18 15:48:25 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:48:25 --> Controller Class Initialized
DEBUG - 2020-03-18 15:48:25 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 15:48:25 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:48:25 --> Final output sent to browser
DEBUG - 2020-03-18 15:48:25 --> Total execution time: 0.5354
INFO - 2020-03-18 15:48:32 --> Config Class Initialized
INFO - 2020-03-18 15:48:32 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:48:32 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:48:32 --> Utf8 Class Initialized
INFO - 2020-03-18 15:48:32 --> URI Class Initialized
INFO - 2020-03-18 15:48:32 --> Router Class Initialized
INFO - 2020-03-18 15:48:32 --> Output Class Initialized
INFO - 2020-03-18 15:48:32 --> Security Class Initialized
DEBUG - 2020-03-18 15:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:48:32 --> Input Class Initialized
INFO - 2020-03-18 15:48:32 --> Language Class Initialized
INFO - 2020-03-18 15:48:33 --> Language Class Initialized
INFO - 2020-03-18 15:48:33 --> Config Class Initialized
INFO - 2020-03-18 15:48:33 --> Loader Class Initialized
INFO - 2020-03-18 15:48:33 --> Helper loaded: url_helper
INFO - 2020-03-18 15:48:33 --> Helper loaded: file_helper
INFO - 2020-03-18 15:48:33 --> Helper loaded: form_helper
INFO - 2020-03-18 15:48:33 --> Helper loaded: my_helper
INFO - 2020-03-18 15:48:33 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:48:33 --> Controller Class Initialized
INFO - 2020-03-18 15:48:33 --> Helper loaded: cookie_helper
INFO - 2020-03-18 15:48:33 --> Final output sent to browser
DEBUG - 2020-03-18 15:48:33 --> Total execution time: 0.6716
INFO - 2020-03-18 15:48:33 --> Config Class Initialized
INFO - 2020-03-18 15:48:33 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:48:33 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:48:33 --> Utf8 Class Initialized
INFO - 2020-03-18 15:48:33 --> URI Class Initialized
INFO - 2020-03-18 15:48:33 --> Router Class Initialized
INFO - 2020-03-18 15:48:33 --> Output Class Initialized
INFO - 2020-03-18 15:48:33 --> Security Class Initialized
DEBUG - 2020-03-18 15:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:48:33 --> Input Class Initialized
INFO - 2020-03-18 15:48:33 --> Language Class Initialized
INFO - 2020-03-18 15:48:33 --> Language Class Initialized
INFO - 2020-03-18 15:48:33 --> Config Class Initialized
INFO - 2020-03-18 15:48:34 --> Loader Class Initialized
INFO - 2020-03-18 15:48:34 --> Helper loaded: url_helper
INFO - 2020-03-18 15:48:34 --> Helper loaded: file_helper
INFO - 2020-03-18 15:48:34 --> Helper loaded: form_helper
INFO - 2020-03-18 15:48:34 --> Helper loaded: my_helper
INFO - 2020-03-18 15:48:34 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:48:34 --> Controller Class Initialized
DEBUG - 2020-03-18 15:48:34 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-03-18 15:48:34 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:48:34 --> Final output sent to browser
DEBUG - 2020-03-18 15:48:38 --> Total execution time: 0.9023
INFO - 2020-03-18 15:49:19 --> Config Class Initialized
INFO - 2020-03-18 15:49:19 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:49:19 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:49:19 --> Utf8 Class Initialized
INFO - 2020-03-18 15:49:19 --> URI Class Initialized
INFO - 2020-03-18 15:49:19 --> Router Class Initialized
INFO - 2020-03-18 15:49:19 --> Output Class Initialized
INFO - 2020-03-18 15:49:19 --> Security Class Initialized
DEBUG - 2020-03-18 15:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:49:19 --> Input Class Initialized
INFO - 2020-03-18 15:49:19 --> Language Class Initialized
INFO - 2020-03-18 15:49:19 --> Language Class Initialized
INFO - 2020-03-18 15:49:19 --> Config Class Initialized
INFO - 2020-03-18 15:49:19 --> Loader Class Initialized
INFO - 2020-03-18 15:49:20 --> Helper loaded: url_helper
INFO - 2020-03-18 15:49:20 --> Helper loaded: file_helper
INFO - 2020-03-18 15:49:20 --> Helper loaded: form_helper
INFO - 2020-03-18 15:49:20 --> Helper loaded: my_helper
INFO - 2020-03-18 15:49:20 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:49:20 --> Controller Class Initialized
DEBUG - 2020-03-18 15:49:20 --> File loaded: D:\xampp\htdocs\myraport\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-03-18 15:49:20 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:49:20 --> Final output sent to browser
DEBUG - 2020-03-18 15:49:20 --> Total execution time: 0.7130
INFO - 2020-03-18 15:49:20 --> Config Class Initialized
INFO - 2020-03-18 15:49:21 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:49:21 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:49:21 --> Utf8 Class Initialized
INFO - 2020-03-18 15:49:21 --> URI Class Initialized
INFO - 2020-03-18 15:49:21 --> Router Class Initialized
INFO - 2020-03-18 15:49:21 --> Output Class Initialized
INFO - 2020-03-18 15:49:21 --> Security Class Initialized
DEBUG - 2020-03-18 15:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:49:21 --> Input Class Initialized
INFO - 2020-03-18 15:49:21 --> Language Class Initialized
INFO - 2020-03-18 15:49:21 --> Language Class Initialized
INFO - 2020-03-18 15:49:21 --> Config Class Initialized
INFO - 2020-03-18 15:49:21 --> Loader Class Initialized
INFO - 2020-03-18 15:49:21 --> Helper loaded: url_helper
INFO - 2020-03-18 15:49:21 --> Helper loaded: file_helper
INFO - 2020-03-18 15:49:21 --> Helper loaded: form_helper
INFO - 2020-03-18 15:49:21 --> Helper loaded: my_helper
INFO - 2020-03-18 15:49:21 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:49:21 --> Controller Class Initialized
INFO - 2020-03-18 15:49:25 --> Config Class Initialized
INFO - 2020-03-18 15:49:25 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:49:25 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:49:25 --> Utf8 Class Initialized
INFO - 2020-03-18 15:49:25 --> URI Class Initialized
INFO - 2020-03-18 15:49:25 --> Router Class Initialized
INFO - 2020-03-18 15:49:25 --> Output Class Initialized
INFO - 2020-03-18 15:49:25 --> Security Class Initialized
DEBUG - 2020-03-18 15:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:49:25 --> Input Class Initialized
INFO - 2020-03-18 15:49:25 --> Language Class Initialized
INFO - 2020-03-18 15:49:25 --> Language Class Initialized
INFO - 2020-03-18 15:49:25 --> Config Class Initialized
INFO - 2020-03-18 15:49:25 --> Loader Class Initialized
INFO - 2020-03-18 15:49:25 --> Helper loaded: url_helper
INFO - 2020-03-18 15:49:25 --> Helper loaded: file_helper
INFO - 2020-03-18 15:49:25 --> Helper loaded: form_helper
INFO - 2020-03-18 15:49:25 --> Helper loaded: my_helper
INFO - 2020-03-18 15:49:25 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:49:25 --> Controller Class Initialized
DEBUG - 2020-03-18 15:49:25 --> File loaded: D:\xampp\htdocs\myraport\application\modules/n_pengetahuan/views/form.php
DEBUG - 2020-03-18 15:49:25 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:49:25 --> Final output sent to browser
DEBUG - 2020-03-18 15:49:25 --> Total execution time: 0.6463
INFO - 2020-03-18 15:49:28 --> Config Class Initialized
INFO - 2020-03-18 15:49:28 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:49:28 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:49:28 --> Utf8 Class Initialized
INFO - 2020-03-18 15:49:28 --> URI Class Initialized
INFO - 2020-03-18 15:49:28 --> Router Class Initialized
INFO - 2020-03-18 15:49:28 --> Output Class Initialized
INFO - 2020-03-18 15:49:28 --> Security Class Initialized
DEBUG - 2020-03-18 15:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:49:28 --> Input Class Initialized
INFO - 2020-03-18 15:49:28 --> Language Class Initialized
INFO - 2020-03-18 15:49:28 --> Language Class Initialized
INFO - 2020-03-18 15:49:29 --> Config Class Initialized
INFO - 2020-03-18 15:49:29 --> Loader Class Initialized
INFO - 2020-03-18 15:49:29 --> Helper loaded: url_helper
INFO - 2020-03-18 15:49:29 --> Helper loaded: file_helper
INFO - 2020-03-18 15:49:29 --> Helper loaded: form_helper
INFO - 2020-03-18 15:49:29 --> Helper loaded: my_helper
INFO - 2020-03-18 15:49:29 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:49:29 --> Controller Class Initialized
DEBUG - 2020-03-18 15:49:29 --> File loaded: D:\xampp\htdocs\myraport\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-03-18 15:49:29 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:49:29 --> Final output sent to browser
DEBUG - 2020-03-18 15:49:29 --> Total execution time: 0.9819
INFO - 2020-03-18 15:49:30 --> Config Class Initialized
INFO - 2020-03-18 15:49:30 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:49:30 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:49:30 --> Utf8 Class Initialized
INFO - 2020-03-18 15:49:30 --> URI Class Initialized
INFO - 2020-03-18 15:49:30 --> Router Class Initialized
INFO - 2020-03-18 15:49:30 --> Output Class Initialized
INFO - 2020-03-18 15:49:30 --> Security Class Initialized
DEBUG - 2020-03-18 15:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:49:30 --> Input Class Initialized
INFO - 2020-03-18 15:49:30 --> Language Class Initialized
INFO - 2020-03-18 15:49:30 --> Language Class Initialized
INFO - 2020-03-18 15:49:30 --> Config Class Initialized
INFO - 2020-03-18 15:49:30 --> Loader Class Initialized
INFO - 2020-03-18 15:49:30 --> Helper loaded: url_helper
INFO - 2020-03-18 15:49:30 --> Helper loaded: file_helper
INFO - 2020-03-18 15:49:30 --> Helper loaded: form_helper
INFO - 2020-03-18 15:49:30 --> Helper loaded: my_helper
INFO - 2020-03-18 15:49:30 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:49:30 --> Controller Class Initialized
INFO - 2020-03-18 15:49:37 --> Config Class Initialized
INFO - 2020-03-18 15:49:37 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:49:37 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:49:37 --> Utf8 Class Initialized
INFO - 2020-03-18 15:49:37 --> URI Class Initialized
INFO - 2020-03-18 15:49:37 --> Router Class Initialized
INFO - 2020-03-18 15:49:37 --> Output Class Initialized
INFO - 2020-03-18 15:49:37 --> Security Class Initialized
DEBUG - 2020-03-18 15:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:49:37 --> Input Class Initialized
INFO - 2020-03-18 15:49:37 --> Language Class Initialized
INFO - 2020-03-18 15:49:37 --> Language Class Initialized
INFO - 2020-03-18 15:49:37 --> Config Class Initialized
INFO - 2020-03-18 15:49:37 --> Loader Class Initialized
INFO - 2020-03-18 15:49:37 --> Helper loaded: url_helper
INFO - 2020-03-18 15:49:37 --> Helper loaded: file_helper
INFO - 2020-03-18 15:49:37 --> Helper loaded: form_helper
INFO - 2020-03-18 15:49:37 --> Helper loaded: my_helper
INFO - 2020-03-18 15:49:37 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:49:38 --> Controller Class Initialized
INFO - 2020-03-18 15:49:38 --> Final output sent to browser
DEBUG - 2020-03-18 15:49:38 --> Total execution time: 0.5353
INFO - 2020-03-18 15:49:46 --> Config Class Initialized
INFO - 2020-03-18 15:49:46 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:49:46 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:49:46 --> Utf8 Class Initialized
INFO - 2020-03-18 15:49:46 --> URI Class Initialized
INFO - 2020-03-18 15:49:46 --> Router Class Initialized
INFO - 2020-03-18 15:49:46 --> Output Class Initialized
INFO - 2020-03-18 15:49:46 --> Security Class Initialized
DEBUG - 2020-03-18 15:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:49:46 --> Input Class Initialized
INFO - 2020-03-18 15:49:46 --> Language Class Initialized
INFO - 2020-03-18 15:49:46 --> Language Class Initialized
INFO - 2020-03-18 15:49:46 --> Config Class Initialized
INFO - 2020-03-18 15:49:46 --> Loader Class Initialized
INFO - 2020-03-18 15:49:46 --> Helper loaded: url_helper
INFO - 2020-03-18 15:49:46 --> Helper loaded: file_helper
INFO - 2020-03-18 15:49:46 --> Helper loaded: form_helper
INFO - 2020-03-18 15:49:46 --> Helper loaded: my_helper
INFO - 2020-03-18 15:49:46 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:49:46 --> Controller Class Initialized
INFO - 2020-03-18 15:49:46 --> Final output sent to browser
DEBUG - 2020-03-18 15:49:47 --> Total execution time: 0.5172
INFO - 2020-03-18 15:49:48 --> Config Class Initialized
INFO - 2020-03-18 15:49:48 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:49:48 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:49:48 --> Utf8 Class Initialized
INFO - 2020-03-18 15:49:48 --> URI Class Initialized
INFO - 2020-03-18 15:49:48 --> Router Class Initialized
INFO - 2020-03-18 15:49:48 --> Output Class Initialized
INFO - 2020-03-18 15:49:48 --> Security Class Initialized
DEBUG - 2020-03-18 15:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:49:48 --> Input Class Initialized
INFO - 2020-03-18 15:49:48 --> Language Class Initialized
INFO - 2020-03-18 15:49:48 --> Language Class Initialized
INFO - 2020-03-18 15:49:48 --> Config Class Initialized
INFO - 2020-03-18 15:49:48 --> Loader Class Initialized
INFO - 2020-03-18 15:49:48 --> Helper loaded: url_helper
INFO - 2020-03-18 15:49:48 --> Helper loaded: file_helper
INFO - 2020-03-18 15:49:48 --> Helper loaded: form_helper
INFO - 2020-03-18 15:49:48 --> Helper loaded: my_helper
INFO - 2020-03-18 15:49:49 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:49:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:49:49 --> Controller Class Initialized
INFO - 2020-03-18 15:49:49 --> Final output sent to browser
DEBUG - 2020-03-18 15:49:49 --> Total execution time: 0.4742
INFO - 2020-03-18 15:49:51 --> Config Class Initialized
INFO - 2020-03-18 15:49:51 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:49:51 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:49:51 --> Utf8 Class Initialized
INFO - 2020-03-18 15:49:51 --> URI Class Initialized
INFO - 2020-03-18 15:49:51 --> Router Class Initialized
INFO - 2020-03-18 15:49:51 --> Output Class Initialized
INFO - 2020-03-18 15:49:51 --> Security Class Initialized
DEBUG - 2020-03-18 15:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:49:51 --> Input Class Initialized
INFO - 2020-03-18 15:49:51 --> Language Class Initialized
INFO - 2020-03-18 15:49:51 --> Language Class Initialized
INFO - 2020-03-18 15:49:51 --> Config Class Initialized
INFO - 2020-03-18 15:49:51 --> Loader Class Initialized
INFO - 2020-03-18 15:49:51 --> Helper loaded: url_helper
INFO - 2020-03-18 15:49:51 --> Helper loaded: file_helper
INFO - 2020-03-18 15:49:51 --> Helper loaded: form_helper
INFO - 2020-03-18 15:49:51 --> Helper loaded: my_helper
INFO - 2020-03-18 15:49:51 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:49:51 --> Controller Class Initialized
INFO - 2020-03-18 15:49:51 --> Final output sent to browser
DEBUG - 2020-03-18 15:49:51 --> Total execution time: 0.4830
INFO - 2020-03-18 15:49:55 --> Config Class Initialized
INFO - 2020-03-18 15:49:55 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:49:55 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:49:55 --> Utf8 Class Initialized
INFO - 2020-03-18 15:49:55 --> URI Class Initialized
INFO - 2020-03-18 15:49:55 --> Router Class Initialized
INFO - 2020-03-18 15:49:55 --> Output Class Initialized
INFO - 2020-03-18 15:49:55 --> Security Class Initialized
DEBUG - 2020-03-18 15:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:49:55 --> Input Class Initialized
INFO - 2020-03-18 15:49:55 --> Language Class Initialized
INFO - 2020-03-18 15:49:56 --> Language Class Initialized
INFO - 2020-03-18 15:49:56 --> Config Class Initialized
INFO - 2020-03-18 15:49:56 --> Loader Class Initialized
INFO - 2020-03-18 15:49:56 --> Helper loaded: url_helper
INFO - 2020-03-18 15:49:56 --> Helper loaded: file_helper
INFO - 2020-03-18 15:49:56 --> Helper loaded: form_helper
INFO - 2020-03-18 15:49:56 --> Helper loaded: my_helper
INFO - 2020-03-18 15:49:56 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:49:56 --> Controller Class Initialized
INFO - 2020-03-18 15:49:56 --> Final output sent to browser
DEBUG - 2020-03-18 15:49:56 --> Total execution time: 0.4682
INFO - 2020-03-18 15:49:59 --> Config Class Initialized
INFO - 2020-03-18 15:49:59 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:49:59 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:49:59 --> Utf8 Class Initialized
INFO - 2020-03-18 15:49:59 --> URI Class Initialized
INFO - 2020-03-18 15:49:59 --> Router Class Initialized
INFO - 2020-03-18 15:49:59 --> Output Class Initialized
INFO - 2020-03-18 15:49:59 --> Security Class Initialized
DEBUG - 2020-03-18 15:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:49:59 --> Input Class Initialized
INFO - 2020-03-18 15:49:59 --> Language Class Initialized
INFO - 2020-03-18 15:49:59 --> Language Class Initialized
INFO - 2020-03-18 15:49:59 --> Config Class Initialized
INFO - 2020-03-18 15:49:59 --> Loader Class Initialized
INFO - 2020-03-18 15:49:59 --> Helper loaded: url_helper
INFO - 2020-03-18 15:49:59 --> Helper loaded: file_helper
INFO - 2020-03-18 15:49:59 --> Helper loaded: form_helper
INFO - 2020-03-18 15:49:59 --> Helper loaded: my_helper
INFO - 2020-03-18 15:49:59 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:49:59 --> Controller Class Initialized
INFO - 2020-03-18 15:49:59 --> Final output sent to browser
DEBUG - 2020-03-18 15:50:00 --> Total execution time: 0.4935
INFO - 2020-03-18 15:50:03 --> Config Class Initialized
INFO - 2020-03-18 15:50:03 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:50:03 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:50:03 --> Utf8 Class Initialized
INFO - 2020-03-18 15:50:03 --> URI Class Initialized
INFO - 2020-03-18 15:50:03 --> Router Class Initialized
INFO - 2020-03-18 15:50:03 --> Output Class Initialized
INFO - 2020-03-18 15:50:03 --> Security Class Initialized
DEBUG - 2020-03-18 15:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:50:03 --> Input Class Initialized
INFO - 2020-03-18 15:50:03 --> Language Class Initialized
INFO - 2020-03-18 15:50:03 --> Language Class Initialized
INFO - 2020-03-18 15:50:03 --> Config Class Initialized
INFO - 2020-03-18 15:50:03 --> Loader Class Initialized
INFO - 2020-03-18 15:50:03 --> Helper loaded: url_helper
INFO - 2020-03-18 15:50:03 --> Helper loaded: file_helper
INFO - 2020-03-18 15:50:03 --> Helper loaded: form_helper
INFO - 2020-03-18 15:50:03 --> Helper loaded: my_helper
INFO - 2020-03-18 15:50:03 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:50:03 --> Controller Class Initialized
INFO - 2020-03-18 15:50:03 --> Final output sent to browser
DEBUG - 2020-03-18 15:50:03 --> Total execution time: 0.4814
INFO - 2020-03-18 15:50:13 --> Config Class Initialized
INFO - 2020-03-18 15:50:13 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:50:13 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:50:13 --> Utf8 Class Initialized
INFO - 2020-03-18 15:50:13 --> URI Class Initialized
INFO - 2020-03-18 15:50:13 --> Router Class Initialized
INFO - 2020-03-18 15:50:13 --> Output Class Initialized
INFO - 2020-03-18 15:50:13 --> Security Class Initialized
DEBUG - 2020-03-18 15:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:50:13 --> Input Class Initialized
INFO - 2020-03-18 15:50:13 --> Language Class Initialized
INFO - 2020-03-18 15:50:13 --> Language Class Initialized
INFO - 2020-03-18 15:50:14 --> Config Class Initialized
INFO - 2020-03-18 15:50:14 --> Loader Class Initialized
INFO - 2020-03-18 15:50:14 --> Helper loaded: url_helper
INFO - 2020-03-18 15:50:14 --> Helper loaded: file_helper
INFO - 2020-03-18 15:50:14 --> Helper loaded: form_helper
INFO - 2020-03-18 15:50:14 --> Helper loaded: my_helper
INFO - 2020-03-18 15:50:14 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:50:14 --> Controller Class Initialized
DEBUG - 2020-03-18 15:50:15 --> File loaded: D:\xampp\htdocs\myraport\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-03-18 15:50:15 --> Final output sent to browser
DEBUG - 2020-03-18 15:50:15 --> Total execution time: 1.7572
INFO - 2020-03-18 15:50:45 --> Config Class Initialized
INFO - 2020-03-18 15:50:45 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:50:45 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:50:45 --> Utf8 Class Initialized
INFO - 2020-03-18 15:50:45 --> URI Class Initialized
INFO - 2020-03-18 15:50:45 --> Router Class Initialized
INFO - 2020-03-18 15:50:45 --> Output Class Initialized
INFO - 2020-03-18 15:50:46 --> Security Class Initialized
DEBUG - 2020-03-18 15:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:50:46 --> Input Class Initialized
INFO - 2020-03-18 15:50:46 --> Language Class Initialized
INFO - 2020-03-18 15:50:46 --> Language Class Initialized
INFO - 2020-03-18 15:50:46 --> Config Class Initialized
INFO - 2020-03-18 15:50:46 --> Loader Class Initialized
INFO - 2020-03-18 15:50:46 --> Helper loaded: url_helper
INFO - 2020-03-18 15:50:46 --> Helper loaded: file_helper
INFO - 2020-03-18 15:50:46 --> Helper loaded: form_helper
INFO - 2020-03-18 15:50:46 --> Helper loaded: my_helper
INFO - 2020-03-18 15:50:46 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:50:46 --> Controller Class Initialized
INFO - 2020-03-18 15:50:46 --> Helper loaded: cookie_helper
INFO - 2020-03-18 15:50:46 --> Config Class Initialized
INFO - 2020-03-18 15:50:46 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:50:46 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:50:46 --> Utf8 Class Initialized
INFO - 2020-03-18 15:50:46 --> URI Class Initialized
INFO - 2020-03-18 15:50:46 --> Router Class Initialized
INFO - 2020-03-18 15:50:46 --> Output Class Initialized
INFO - 2020-03-18 15:50:46 --> Security Class Initialized
DEBUG - 2020-03-18 15:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:50:46 --> Input Class Initialized
INFO - 2020-03-18 15:50:46 --> Language Class Initialized
INFO - 2020-03-18 15:50:46 --> Language Class Initialized
INFO - 2020-03-18 15:50:46 --> Config Class Initialized
INFO - 2020-03-18 15:50:46 --> Loader Class Initialized
INFO - 2020-03-18 15:50:46 --> Helper loaded: url_helper
INFO - 2020-03-18 15:50:46 --> Helper loaded: file_helper
INFO - 2020-03-18 15:50:46 --> Helper loaded: form_helper
INFO - 2020-03-18 15:50:46 --> Helper loaded: my_helper
INFO - 2020-03-18 15:50:46 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:50:46 --> Controller Class Initialized
INFO - 2020-03-18 15:50:46 --> Config Class Initialized
INFO - 2020-03-18 15:50:46 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:50:46 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:50:47 --> Utf8 Class Initialized
INFO - 2020-03-18 15:50:47 --> URI Class Initialized
INFO - 2020-03-18 15:50:47 --> Router Class Initialized
INFO - 2020-03-18 15:50:47 --> Output Class Initialized
INFO - 2020-03-18 15:50:47 --> Security Class Initialized
DEBUG - 2020-03-18 15:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:50:47 --> Input Class Initialized
INFO - 2020-03-18 15:50:47 --> Language Class Initialized
INFO - 2020-03-18 15:50:47 --> Language Class Initialized
INFO - 2020-03-18 15:50:47 --> Config Class Initialized
INFO - 2020-03-18 15:50:47 --> Loader Class Initialized
INFO - 2020-03-18 15:50:47 --> Helper loaded: url_helper
INFO - 2020-03-18 15:50:47 --> Helper loaded: file_helper
INFO - 2020-03-18 15:50:47 --> Helper loaded: form_helper
INFO - 2020-03-18 15:50:47 --> Helper loaded: my_helper
INFO - 2020-03-18 15:50:47 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:50:47 --> Controller Class Initialized
DEBUG - 2020-03-18 15:50:47 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 15:50:47 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:50:47 --> Final output sent to browser
DEBUG - 2020-03-18 15:50:47 --> Total execution time: 0.5384
INFO - 2020-03-18 15:50:53 --> Config Class Initialized
INFO - 2020-03-18 15:50:53 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:50:53 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:50:53 --> Utf8 Class Initialized
INFO - 2020-03-18 15:50:53 --> URI Class Initialized
INFO - 2020-03-18 15:50:53 --> Router Class Initialized
INFO - 2020-03-18 15:50:53 --> Output Class Initialized
INFO - 2020-03-18 15:50:53 --> Security Class Initialized
DEBUG - 2020-03-18 15:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:50:53 --> Input Class Initialized
INFO - 2020-03-18 15:50:53 --> Language Class Initialized
INFO - 2020-03-18 15:50:53 --> Language Class Initialized
INFO - 2020-03-18 15:50:54 --> Config Class Initialized
INFO - 2020-03-18 15:50:54 --> Loader Class Initialized
INFO - 2020-03-18 15:50:54 --> Helper loaded: url_helper
INFO - 2020-03-18 15:50:54 --> Helper loaded: file_helper
INFO - 2020-03-18 15:50:54 --> Helper loaded: form_helper
INFO - 2020-03-18 15:50:54 --> Helper loaded: my_helper
INFO - 2020-03-18 15:50:54 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:50:54 --> Controller Class Initialized
INFO - 2020-03-18 15:50:54 --> Helper loaded: cookie_helper
INFO - 2020-03-18 15:50:54 --> Final output sent to browser
DEBUG - 2020-03-18 15:50:54 --> Total execution time: 0.8499
INFO - 2020-03-18 15:50:54 --> Config Class Initialized
INFO - 2020-03-18 15:50:54 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:50:54 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:50:54 --> Utf8 Class Initialized
INFO - 2020-03-18 15:50:54 --> URI Class Initialized
INFO - 2020-03-18 15:50:54 --> Router Class Initialized
INFO - 2020-03-18 15:50:54 --> Output Class Initialized
INFO - 2020-03-18 15:50:54 --> Security Class Initialized
DEBUG - 2020-03-18 15:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:50:54 --> Input Class Initialized
INFO - 2020-03-18 15:50:55 --> Language Class Initialized
INFO - 2020-03-18 15:50:55 --> Language Class Initialized
INFO - 2020-03-18 15:50:55 --> Config Class Initialized
INFO - 2020-03-18 15:50:55 --> Loader Class Initialized
INFO - 2020-03-18 15:50:55 --> Helper loaded: url_helper
INFO - 2020-03-18 15:50:55 --> Helper loaded: file_helper
INFO - 2020-03-18 15:50:55 --> Helper loaded: form_helper
INFO - 2020-03-18 15:50:55 --> Helper loaded: my_helper
INFO - 2020-03-18 15:50:55 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:50:55 --> Controller Class Initialized
DEBUG - 2020-03-18 15:50:55 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 15:50:55 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:50:55 --> Final output sent to browser
DEBUG - 2020-03-18 15:50:58 --> Total execution time: 1.2881
INFO - 2020-03-18 15:51:05 --> Config Class Initialized
INFO - 2020-03-18 15:51:05 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:51:05 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:51:05 --> Utf8 Class Initialized
INFO - 2020-03-18 15:51:06 --> URI Class Initialized
INFO - 2020-03-18 15:51:06 --> Router Class Initialized
INFO - 2020-03-18 15:51:06 --> Output Class Initialized
INFO - 2020-03-18 15:51:06 --> Security Class Initialized
DEBUG - 2020-03-18 15:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:51:06 --> Input Class Initialized
INFO - 2020-03-18 15:51:06 --> Language Class Initialized
INFO - 2020-03-18 15:51:06 --> Language Class Initialized
INFO - 2020-03-18 15:51:06 --> Config Class Initialized
INFO - 2020-03-18 15:51:06 --> Loader Class Initialized
INFO - 2020-03-18 15:51:06 --> Helper loaded: url_helper
INFO - 2020-03-18 15:51:06 --> Helper loaded: file_helper
INFO - 2020-03-18 15:51:06 --> Helper loaded: form_helper
INFO - 2020-03-18 15:51:06 --> Helper loaded: my_helper
INFO - 2020-03-18 15:51:06 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:51:06 --> Controller Class Initialized
DEBUG - 2020-03-18 15:51:06 --> File loaded: D:\xampp\htdocs\myraport\application\modules/set_mapel/views/list.php
DEBUG - 2020-03-18 15:51:06 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:51:06 --> Final output sent to browser
DEBUG - 2020-03-18 15:51:06 --> Total execution time: 0.7514
INFO - 2020-03-18 15:51:07 --> Config Class Initialized
INFO - 2020-03-18 15:51:07 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:51:07 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:51:07 --> Utf8 Class Initialized
INFO - 2020-03-18 15:51:07 --> URI Class Initialized
INFO - 2020-03-18 15:51:07 --> Router Class Initialized
INFO - 2020-03-18 15:51:07 --> Output Class Initialized
INFO - 2020-03-18 15:51:07 --> Security Class Initialized
DEBUG - 2020-03-18 15:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:51:07 --> Input Class Initialized
INFO - 2020-03-18 15:51:07 --> Language Class Initialized
INFO - 2020-03-18 15:51:07 --> Language Class Initialized
INFO - 2020-03-18 15:51:07 --> Config Class Initialized
INFO - 2020-03-18 15:51:07 --> Loader Class Initialized
INFO - 2020-03-18 15:51:07 --> Helper loaded: url_helper
INFO - 2020-03-18 15:51:07 --> Helper loaded: file_helper
INFO - 2020-03-18 15:51:07 --> Helper loaded: form_helper
INFO - 2020-03-18 15:51:07 --> Helper loaded: my_helper
INFO - 2020-03-18 15:51:07 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:51:07 --> Controller Class Initialized
INFO - 2020-03-18 15:51:10 --> Config Class Initialized
INFO - 2020-03-18 15:51:10 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:51:10 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:51:10 --> Utf8 Class Initialized
INFO - 2020-03-18 15:51:10 --> URI Class Initialized
INFO - 2020-03-18 15:51:10 --> Router Class Initialized
INFO - 2020-03-18 15:51:10 --> Output Class Initialized
INFO - 2020-03-18 15:51:10 --> Security Class Initialized
DEBUG - 2020-03-18 15:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:51:10 --> Input Class Initialized
INFO - 2020-03-18 15:51:10 --> Language Class Initialized
INFO - 2020-03-18 15:51:10 --> Language Class Initialized
INFO - 2020-03-18 15:51:10 --> Config Class Initialized
INFO - 2020-03-18 15:51:10 --> Loader Class Initialized
INFO - 2020-03-18 15:51:10 --> Helper loaded: url_helper
INFO - 2020-03-18 15:51:10 --> Helper loaded: file_helper
INFO - 2020-03-18 15:51:10 --> Helper loaded: form_helper
INFO - 2020-03-18 15:51:10 --> Helper loaded: my_helper
INFO - 2020-03-18 15:51:10 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:51:10 --> Controller Class Initialized
DEBUG - 2020-03-18 15:51:11 --> File loaded: D:\xampp\htdocs\myraport\application\modules/set_mapel/views/form.php
DEBUG - 2020-03-18 15:51:11 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:51:11 --> Final output sent to browser
DEBUG - 2020-03-18 15:51:11 --> Total execution time: 0.7562
INFO - 2020-03-18 15:51:16 --> Config Class Initialized
INFO - 2020-03-18 15:51:16 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:51:16 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:51:16 --> Utf8 Class Initialized
INFO - 2020-03-18 15:51:16 --> URI Class Initialized
INFO - 2020-03-18 15:51:16 --> Router Class Initialized
INFO - 2020-03-18 15:51:16 --> Output Class Initialized
INFO - 2020-03-18 15:51:16 --> Security Class Initialized
DEBUG - 2020-03-18 15:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:51:16 --> Input Class Initialized
INFO - 2020-03-18 15:51:16 --> Language Class Initialized
INFO - 2020-03-18 15:51:16 --> Language Class Initialized
INFO - 2020-03-18 15:51:16 --> Config Class Initialized
INFO - 2020-03-18 15:51:16 --> Loader Class Initialized
INFO - 2020-03-18 15:51:16 --> Helper loaded: url_helper
INFO - 2020-03-18 15:51:16 --> Helper loaded: file_helper
INFO - 2020-03-18 15:51:16 --> Helper loaded: form_helper
INFO - 2020-03-18 15:51:16 --> Helper loaded: my_helper
INFO - 2020-03-18 15:51:16 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:51:16 --> Controller Class Initialized
DEBUG - 2020-03-18 15:51:16 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-03-18 15:51:16 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:51:16 --> Final output sent to browser
DEBUG - 2020-03-18 15:51:17 --> Total execution time: 0.6177
INFO - 2020-03-18 15:51:17 --> Config Class Initialized
INFO - 2020-03-18 15:51:17 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:51:17 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:51:17 --> Utf8 Class Initialized
INFO - 2020-03-18 15:51:17 --> URI Class Initialized
INFO - 2020-03-18 15:51:17 --> Router Class Initialized
INFO - 2020-03-18 15:51:17 --> Output Class Initialized
INFO - 2020-03-18 15:51:17 --> Security Class Initialized
DEBUG - 2020-03-18 15:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:51:17 --> Input Class Initialized
INFO - 2020-03-18 15:51:17 --> Language Class Initialized
INFO - 2020-03-18 15:51:17 --> Language Class Initialized
INFO - 2020-03-18 15:51:17 --> Config Class Initialized
INFO - 2020-03-18 15:51:17 --> Loader Class Initialized
INFO - 2020-03-18 15:51:17 --> Helper loaded: url_helper
INFO - 2020-03-18 15:51:17 --> Helper loaded: file_helper
INFO - 2020-03-18 15:51:17 --> Helper loaded: form_helper
INFO - 2020-03-18 15:51:17 --> Helper loaded: my_helper
INFO - 2020-03-18 15:51:17 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:51:17 --> Controller Class Initialized
INFO - 2020-03-18 15:51:21 --> Config Class Initialized
INFO - 2020-03-18 15:51:21 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:51:21 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:51:22 --> Utf8 Class Initialized
INFO - 2020-03-18 15:51:22 --> URI Class Initialized
INFO - 2020-03-18 15:51:22 --> Router Class Initialized
INFO - 2020-03-18 15:51:22 --> Output Class Initialized
INFO - 2020-03-18 15:51:22 --> Security Class Initialized
DEBUG - 2020-03-18 15:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:51:22 --> Input Class Initialized
INFO - 2020-03-18 15:51:22 --> Language Class Initialized
INFO - 2020-03-18 15:51:22 --> Language Class Initialized
INFO - 2020-03-18 15:51:22 --> Config Class Initialized
INFO - 2020-03-18 15:51:22 --> Loader Class Initialized
INFO - 2020-03-18 15:51:22 --> Helper loaded: url_helper
INFO - 2020-03-18 15:51:22 --> Helper loaded: file_helper
INFO - 2020-03-18 15:51:22 --> Helper loaded: form_helper
INFO - 2020-03-18 15:51:22 --> Helper loaded: my_helper
INFO - 2020-03-18 15:51:22 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:51:22 --> Controller Class Initialized
DEBUG - 2020-03-18 15:51:22 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_guru/views/list.php
DEBUG - 2020-03-18 15:51:22 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:51:22 --> Final output sent to browser
DEBUG - 2020-03-18 15:51:22 --> Total execution time: 0.5540
INFO - 2020-03-18 15:51:22 --> Config Class Initialized
INFO - 2020-03-18 15:51:22 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:51:22 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:51:22 --> Utf8 Class Initialized
INFO - 2020-03-18 15:51:22 --> URI Class Initialized
INFO - 2020-03-18 15:51:22 --> Router Class Initialized
INFO - 2020-03-18 15:51:23 --> Output Class Initialized
INFO - 2020-03-18 15:51:23 --> Security Class Initialized
DEBUG - 2020-03-18 15:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:51:23 --> Input Class Initialized
INFO - 2020-03-18 15:51:23 --> Language Class Initialized
INFO - 2020-03-18 15:51:23 --> Language Class Initialized
INFO - 2020-03-18 15:51:23 --> Config Class Initialized
INFO - 2020-03-18 15:51:23 --> Loader Class Initialized
INFO - 2020-03-18 15:51:23 --> Helper loaded: url_helper
INFO - 2020-03-18 15:51:23 --> Helper loaded: file_helper
INFO - 2020-03-18 15:51:23 --> Helper loaded: form_helper
INFO - 2020-03-18 15:51:23 --> Helper loaded: my_helper
INFO - 2020-03-18 15:51:23 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:51:23 --> Controller Class Initialized
INFO - 2020-03-18 15:51:24 --> Config Class Initialized
INFO - 2020-03-18 15:51:24 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:51:24 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:51:24 --> Utf8 Class Initialized
INFO - 2020-03-18 15:51:24 --> URI Class Initialized
DEBUG - 2020-03-18 15:51:24 --> No URI present. Default controller set.
INFO - 2020-03-18 15:51:24 --> Router Class Initialized
INFO - 2020-03-18 15:51:24 --> Output Class Initialized
INFO - 2020-03-18 15:51:24 --> Security Class Initialized
DEBUG - 2020-03-18 15:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:51:24 --> Input Class Initialized
INFO - 2020-03-18 15:51:24 --> Language Class Initialized
INFO - 2020-03-18 15:51:24 --> Language Class Initialized
INFO - 2020-03-18 15:51:24 --> Config Class Initialized
INFO - 2020-03-18 15:51:24 --> Loader Class Initialized
INFO - 2020-03-18 15:51:24 --> Helper loaded: url_helper
INFO - 2020-03-18 15:51:24 --> Helper loaded: file_helper
INFO - 2020-03-18 15:51:24 --> Helper loaded: form_helper
INFO - 2020-03-18 15:51:24 --> Helper loaded: my_helper
INFO - 2020-03-18 15:51:24 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:51:24 --> Controller Class Initialized
DEBUG - 2020-03-18 15:51:24 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 15:51:24 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:51:24 --> Final output sent to browser
DEBUG - 2020-03-18 15:51:25 --> Total execution time: 0.6230
INFO - 2020-03-18 15:51:53 --> Config Class Initialized
INFO - 2020-03-18 15:51:53 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:51:53 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:51:53 --> Utf8 Class Initialized
INFO - 2020-03-18 15:51:53 --> URI Class Initialized
DEBUG - 2020-03-18 15:51:53 --> No URI present. Default controller set.
INFO - 2020-03-18 15:51:53 --> Router Class Initialized
INFO - 2020-03-18 15:51:54 --> Output Class Initialized
INFO - 2020-03-18 15:51:54 --> Security Class Initialized
DEBUG - 2020-03-18 15:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:51:54 --> Input Class Initialized
INFO - 2020-03-18 15:51:54 --> Language Class Initialized
INFO - 2020-03-18 15:51:54 --> Language Class Initialized
INFO - 2020-03-18 15:51:54 --> Config Class Initialized
INFO - 2020-03-18 15:51:54 --> Loader Class Initialized
INFO - 2020-03-18 15:51:54 --> Helper loaded: url_helper
INFO - 2020-03-18 15:51:54 --> Helper loaded: file_helper
INFO - 2020-03-18 15:51:54 --> Helper loaded: form_helper
INFO - 2020-03-18 15:51:54 --> Helper loaded: my_helper
INFO - 2020-03-18 15:51:54 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:51:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:51:54 --> Controller Class Initialized
DEBUG - 2020-03-18 15:51:54 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 15:51:54 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:51:54 --> Final output sent to browser
DEBUG - 2020-03-18 15:51:54 --> Total execution time: 0.6331
INFO - 2020-03-18 15:53:06 --> Config Class Initialized
INFO - 2020-03-18 15:53:06 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:53:06 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:53:06 --> Utf8 Class Initialized
INFO - 2020-03-18 15:53:06 --> URI Class Initialized
DEBUG - 2020-03-18 15:53:06 --> No URI present. Default controller set.
INFO - 2020-03-18 15:53:06 --> Router Class Initialized
INFO - 2020-03-18 15:53:06 --> Output Class Initialized
INFO - 2020-03-18 15:53:06 --> Security Class Initialized
DEBUG - 2020-03-18 15:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:53:06 --> Input Class Initialized
INFO - 2020-03-18 15:53:06 --> Language Class Initialized
INFO - 2020-03-18 15:53:06 --> Language Class Initialized
INFO - 2020-03-18 15:53:06 --> Config Class Initialized
INFO - 2020-03-18 15:53:06 --> Loader Class Initialized
INFO - 2020-03-18 15:53:06 --> Helper loaded: url_helper
INFO - 2020-03-18 15:53:06 --> Helper loaded: file_helper
INFO - 2020-03-18 15:53:06 --> Helper loaded: form_helper
INFO - 2020-03-18 15:53:06 --> Helper loaded: my_helper
INFO - 2020-03-18 15:53:06 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:53:07 --> Controller Class Initialized
DEBUG - 2020-03-18 15:53:07 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 15:53:07 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:53:07 --> Final output sent to browser
DEBUG - 2020-03-18 15:53:07 --> Total execution time: 0.9988
INFO - 2020-03-18 15:53:56 --> Config Class Initialized
INFO - 2020-03-18 15:53:56 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:53:56 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:53:56 --> Utf8 Class Initialized
INFO - 2020-03-18 15:53:56 --> URI Class Initialized
DEBUG - 2020-03-18 15:53:56 --> No URI present. Default controller set.
INFO - 2020-03-18 15:53:56 --> Router Class Initialized
INFO - 2020-03-18 15:53:56 --> Output Class Initialized
INFO - 2020-03-18 15:53:56 --> Security Class Initialized
DEBUG - 2020-03-18 15:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:53:56 --> Input Class Initialized
INFO - 2020-03-18 15:53:57 --> Language Class Initialized
INFO - 2020-03-18 15:53:57 --> Language Class Initialized
INFO - 2020-03-18 15:53:57 --> Config Class Initialized
INFO - 2020-03-18 15:53:57 --> Loader Class Initialized
INFO - 2020-03-18 15:53:57 --> Helper loaded: url_helper
INFO - 2020-03-18 15:53:57 --> Helper loaded: file_helper
INFO - 2020-03-18 15:53:57 --> Helper loaded: form_helper
INFO - 2020-03-18 15:53:57 --> Helper loaded: my_helper
INFO - 2020-03-18 15:53:57 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:53:57 --> Controller Class Initialized
DEBUG - 2020-03-18 15:53:57 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 15:53:57 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:53:57 --> Final output sent to browser
DEBUG - 2020-03-18 15:53:57 --> Total execution time: 0.6808
INFO - 2020-03-18 15:54:15 --> Config Class Initialized
INFO - 2020-03-18 15:54:15 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:54:15 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:54:15 --> Utf8 Class Initialized
INFO - 2020-03-18 15:54:15 --> URI Class Initialized
DEBUG - 2020-03-18 15:54:15 --> No URI present. Default controller set.
INFO - 2020-03-18 15:54:15 --> Router Class Initialized
INFO - 2020-03-18 15:54:15 --> Output Class Initialized
INFO - 2020-03-18 15:54:15 --> Security Class Initialized
DEBUG - 2020-03-18 15:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:54:15 --> Input Class Initialized
INFO - 2020-03-18 15:54:15 --> Language Class Initialized
INFO - 2020-03-18 15:54:15 --> Language Class Initialized
INFO - 2020-03-18 15:54:15 --> Config Class Initialized
INFO - 2020-03-18 15:54:15 --> Loader Class Initialized
INFO - 2020-03-18 15:54:15 --> Helper loaded: url_helper
INFO - 2020-03-18 15:54:16 --> Helper loaded: file_helper
INFO - 2020-03-18 15:54:16 --> Helper loaded: form_helper
INFO - 2020-03-18 15:54:16 --> Helper loaded: my_helper
INFO - 2020-03-18 15:54:16 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:54:16 --> Controller Class Initialized
DEBUG - 2020-03-18 15:54:16 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 15:54:16 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:54:16 --> Final output sent to browser
DEBUG - 2020-03-18 15:54:16 --> Total execution time: 0.9488
INFO - 2020-03-18 15:54:48 --> Config Class Initialized
INFO - 2020-03-18 15:54:48 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:54:48 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:54:48 --> Utf8 Class Initialized
INFO - 2020-03-18 15:54:48 --> URI Class Initialized
DEBUG - 2020-03-18 15:54:48 --> No URI present. Default controller set.
INFO - 2020-03-18 15:54:48 --> Router Class Initialized
INFO - 2020-03-18 15:54:48 --> Output Class Initialized
INFO - 2020-03-18 15:54:48 --> Security Class Initialized
DEBUG - 2020-03-18 15:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:54:48 --> Input Class Initialized
INFO - 2020-03-18 15:54:48 --> Language Class Initialized
INFO - 2020-03-18 15:54:48 --> Language Class Initialized
INFO - 2020-03-18 15:54:48 --> Config Class Initialized
INFO - 2020-03-18 15:54:48 --> Loader Class Initialized
INFO - 2020-03-18 15:54:48 --> Helper loaded: url_helper
INFO - 2020-03-18 15:54:48 --> Helper loaded: file_helper
INFO - 2020-03-18 15:54:48 --> Helper loaded: form_helper
INFO - 2020-03-18 15:54:48 --> Helper loaded: my_helper
INFO - 2020-03-18 15:54:48 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:54:48 --> Controller Class Initialized
DEBUG - 2020-03-18 15:54:49 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 15:54:49 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:54:49 --> Final output sent to browser
DEBUG - 2020-03-18 15:54:49 --> Total execution time: 0.7129
INFO - 2020-03-18 15:55:01 --> Config Class Initialized
INFO - 2020-03-18 15:55:01 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:55:01 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:55:01 --> Utf8 Class Initialized
INFO - 2020-03-18 15:55:01 --> URI Class Initialized
DEBUG - 2020-03-18 15:55:01 --> No URI present. Default controller set.
INFO - 2020-03-18 15:55:01 --> Router Class Initialized
INFO - 2020-03-18 15:55:01 --> Output Class Initialized
INFO - 2020-03-18 15:55:01 --> Security Class Initialized
DEBUG - 2020-03-18 15:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:55:01 --> Input Class Initialized
INFO - 2020-03-18 15:55:01 --> Language Class Initialized
INFO - 2020-03-18 15:55:01 --> Language Class Initialized
INFO - 2020-03-18 15:55:01 --> Config Class Initialized
INFO - 2020-03-18 15:55:01 --> Loader Class Initialized
INFO - 2020-03-18 15:55:01 --> Helper loaded: url_helper
INFO - 2020-03-18 15:55:01 --> Helper loaded: file_helper
INFO - 2020-03-18 15:55:01 --> Helper loaded: form_helper
INFO - 2020-03-18 15:55:01 --> Helper loaded: my_helper
INFO - 2020-03-18 15:55:01 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:55:01 --> Controller Class Initialized
DEBUG - 2020-03-18 15:55:01 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 15:55:01 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:55:01 --> Final output sent to browser
DEBUG - 2020-03-18 15:55:02 --> Total execution time: 0.6937
INFO - 2020-03-18 15:55:17 --> Config Class Initialized
INFO - 2020-03-18 15:55:17 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:55:17 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:55:17 --> Utf8 Class Initialized
INFO - 2020-03-18 15:55:18 --> URI Class Initialized
DEBUG - 2020-03-18 15:55:18 --> No URI present. Default controller set.
INFO - 2020-03-18 15:55:18 --> Router Class Initialized
INFO - 2020-03-18 15:55:18 --> Output Class Initialized
INFO - 2020-03-18 15:55:18 --> Security Class Initialized
DEBUG - 2020-03-18 15:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:55:18 --> Input Class Initialized
INFO - 2020-03-18 15:55:18 --> Language Class Initialized
INFO - 2020-03-18 15:55:18 --> Language Class Initialized
INFO - 2020-03-18 15:55:18 --> Config Class Initialized
INFO - 2020-03-18 15:55:18 --> Loader Class Initialized
INFO - 2020-03-18 15:55:18 --> Helper loaded: url_helper
INFO - 2020-03-18 15:55:18 --> Helper loaded: file_helper
INFO - 2020-03-18 15:55:18 --> Helper loaded: form_helper
INFO - 2020-03-18 15:55:18 --> Helper loaded: my_helper
INFO - 2020-03-18 15:55:18 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:55:18 --> Controller Class Initialized
DEBUG - 2020-03-18 15:55:18 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 15:55:18 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:55:18 --> Final output sent to browser
DEBUG - 2020-03-18 15:55:18 --> Total execution time: 0.8409
INFO - 2020-03-18 15:55:35 --> Config Class Initialized
INFO - 2020-03-18 15:55:35 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:55:35 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:55:35 --> Utf8 Class Initialized
INFO - 2020-03-18 15:55:35 --> URI Class Initialized
DEBUG - 2020-03-18 15:55:35 --> No URI present. Default controller set.
INFO - 2020-03-18 15:55:35 --> Router Class Initialized
INFO - 2020-03-18 15:55:35 --> Output Class Initialized
INFO - 2020-03-18 15:55:35 --> Security Class Initialized
DEBUG - 2020-03-18 15:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:55:35 --> Input Class Initialized
INFO - 2020-03-18 15:55:35 --> Language Class Initialized
INFO - 2020-03-18 15:55:35 --> Language Class Initialized
INFO - 2020-03-18 15:55:35 --> Config Class Initialized
INFO - 2020-03-18 15:55:35 --> Loader Class Initialized
INFO - 2020-03-18 15:55:35 --> Helper loaded: url_helper
INFO - 2020-03-18 15:55:35 --> Helper loaded: file_helper
INFO - 2020-03-18 15:55:36 --> Helper loaded: form_helper
INFO - 2020-03-18 15:55:36 --> Helper loaded: my_helper
INFO - 2020-03-18 15:55:36 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:55:36 --> Controller Class Initialized
DEBUG - 2020-03-18 15:55:36 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 15:55:36 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:55:36 --> Final output sent to browser
DEBUG - 2020-03-18 15:55:36 --> Total execution time: 0.7266
INFO - 2020-03-18 15:55:41 --> Config Class Initialized
INFO - 2020-03-18 15:55:41 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:55:41 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:55:41 --> Utf8 Class Initialized
INFO - 2020-03-18 15:55:41 --> URI Class Initialized
INFO - 2020-03-18 15:55:41 --> Router Class Initialized
INFO - 2020-03-18 15:55:41 --> Output Class Initialized
INFO - 2020-03-18 15:55:41 --> Security Class Initialized
DEBUG - 2020-03-18 15:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:55:41 --> Input Class Initialized
INFO - 2020-03-18 15:55:41 --> Language Class Initialized
INFO - 2020-03-18 15:55:41 --> Language Class Initialized
INFO - 2020-03-18 15:55:41 --> Config Class Initialized
INFO - 2020-03-18 15:55:41 --> Loader Class Initialized
INFO - 2020-03-18 15:55:41 --> Helper loaded: url_helper
INFO - 2020-03-18 15:55:41 --> Helper loaded: file_helper
INFO - 2020-03-18 15:55:41 --> Helper loaded: form_helper
INFO - 2020-03-18 15:55:41 --> Helper loaded: my_helper
INFO - 2020-03-18 15:55:41 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:55:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:55:41 --> Controller Class Initialized
INFO - 2020-03-18 15:55:41 --> Helper loaded: cookie_helper
INFO - 2020-03-18 15:55:42 --> Config Class Initialized
INFO - 2020-03-18 15:55:42 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:55:42 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:55:42 --> Utf8 Class Initialized
INFO - 2020-03-18 15:55:42 --> URI Class Initialized
INFO - 2020-03-18 15:55:42 --> Router Class Initialized
INFO - 2020-03-18 15:55:42 --> Output Class Initialized
INFO - 2020-03-18 15:55:42 --> Security Class Initialized
DEBUG - 2020-03-18 15:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:55:42 --> Input Class Initialized
INFO - 2020-03-18 15:55:42 --> Language Class Initialized
INFO - 2020-03-18 15:55:42 --> Language Class Initialized
INFO - 2020-03-18 15:55:42 --> Config Class Initialized
INFO - 2020-03-18 15:55:42 --> Loader Class Initialized
INFO - 2020-03-18 15:55:42 --> Helper loaded: url_helper
INFO - 2020-03-18 15:55:42 --> Helper loaded: file_helper
INFO - 2020-03-18 15:55:42 --> Helper loaded: form_helper
INFO - 2020-03-18 15:55:42 --> Helper loaded: my_helper
INFO - 2020-03-18 15:55:42 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:55:42 --> Controller Class Initialized
INFO - 2020-03-18 15:55:42 --> Config Class Initialized
INFO - 2020-03-18 15:55:42 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:55:42 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:55:42 --> Utf8 Class Initialized
INFO - 2020-03-18 15:55:42 --> URI Class Initialized
INFO - 2020-03-18 15:55:42 --> Router Class Initialized
INFO - 2020-03-18 15:55:42 --> Output Class Initialized
INFO - 2020-03-18 15:55:42 --> Security Class Initialized
DEBUG - 2020-03-18 15:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:55:42 --> Input Class Initialized
INFO - 2020-03-18 15:55:42 --> Language Class Initialized
INFO - 2020-03-18 15:55:42 --> Language Class Initialized
INFO - 2020-03-18 15:55:42 --> Config Class Initialized
INFO - 2020-03-18 15:55:42 --> Loader Class Initialized
INFO - 2020-03-18 15:55:42 --> Helper loaded: url_helper
INFO - 2020-03-18 15:55:42 --> Helper loaded: file_helper
INFO - 2020-03-18 15:55:42 --> Helper loaded: form_helper
INFO - 2020-03-18 15:55:42 --> Helper loaded: my_helper
INFO - 2020-03-18 15:55:43 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:55:43 --> Controller Class Initialized
DEBUG - 2020-03-18 15:55:43 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 15:55:43 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:55:43 --> Final output sent to browser
DEBUG - 2020-03-18 15:55:43 --> Total execution time: 0.5715
INFO - 2020-03-18 15:56:01 --> Config Class Initialized
INFO - 2020-03-18 15:56:01 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:56:01 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:56:01 --> Utf8 Class Initialized
INFO - 2020-03-18 15:56:01 --> URI Class Initialized
INFO - 2020-03-18 15:56:01 --> Router Class Initialized
INFO - 2020-03-18 15:56:01 --> Output Class Initialized
INFO - 2020-03-18 15:56:01 --> Security Class Initialized
DEBUG - 2020-03-18 15:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:56:01 --> Input Class Initialized
INFO - 2020-03-18 15:56:01 --> Language Class Initialized
INFO - 2020-03-18 15:56:01 --> Language Class Initialized
INFO - 2020-03-18 15:56:01 --> Config Class Initialized
INFO - 2020-03-18 15:56:01 --> Loader Class Initialized
INFO - 2020-03-18 15:56:01 --> Helper loaded: url_helper
INFO - 2020-03-18 15:56:01 --> Helper loaded: file_helper
INFO - 2020-03-18 15:56:01 --> Helper loaded: form_helper
INFO - 2020-03-18 15:56:01 --> Helper loaded: my_helper
INFO - 2020-03-18 15:56:01 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:56:01 --> Controller Class Initialized
DEBUG - 2020-03-18 15:56:02 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 15:56:02 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:56:02 --> Final output sent to browser
DEBUG - 2020-03-18 15:56:02 --> Total execution time: 0.8842
INFO - 2020-03-18 15:56:10 --> Config Class Initialized
INFO - 2020-03-18 15:56:10 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:56:10 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:56:10 --> Utf8 Class Initialized
INFO - 2020-03-18 15:56:10 --> URI Class Initialized
INFO - 2020-03-18 15:56:10 --> Router Class Initialized
INFO - 2020-03-18 15:56:10 --> Output Class Initialized
INFO - 2020-03-18 15:56:10 --> Security Class Initialized
DEBUG - 2020-03-18 15:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:56:10 --> Input Class Initialized
INFO - 2020-03-18 15:56:10 --> Language Class Initialized
INFO - 2020-03-18 15:56:10 --> Language Class Initialized
INFO - 2020-03-18 15:56:10 --> Config Class Initialized
INFO - 2020-03-18 15:56:10 --> Loader Class Initialized
INFO - 2020-03-18 15:56:10 --> Helper loaded: url_helper
INFO - 2020-03-18 15:56:10 --> Helper loaded: file_helper
INFO - 2020-03-18 15:56:10 --> Helper loaded: form_helper
INFO - 2020-03-18 15:56:10 --> Helper loaded: my_helper
INFO - 2020-03-18 15:56:10 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:56:10 --> Controller Class Initialized
INFO - 2020-03-18 15:56:10 --> Helper loaded: cookie_helper
INFO - 2020-03-18 15:56:10 --> Final output sent to browser
DEBUG - 2020-03-18 15:56:10 --> Total execution time: 0.7246
INFO - 2020-03-18 15:56:11 --> Config Class Initialized
INFO - 2020-03-18 15:56:11 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:56:11 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:56:11 --> Utf8 Class Initialized
INFO - 2020-03-18 15:56:11 --> URI Class Initialized
INFO - 2020-03-18 15:56:11 --> Router Class Initialized
INFO - 2020-03-18 15:56:11 --> Output Class Initialized
INFO - 2020-03-18 15:56:11 --> Security Class Initialized
DEBUG - 2020-03-18 15:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:56:11 --> Input Class Initialized
INFO - 2020-03-18 15:56:11 --> Language Class Initialized
INFO - 2020-03-18 15:56:11 --> Language Class Initialized
INFO - 2020-03-18 15:56:11 --> Config Class Initialized
INFO - 2020-03-18 15:56:11 --> Loader Class Initialized
INFO - 2020-03-18 15:56:11 --> Helper loaded: url_helper
INFO - 2020-03-18 15:56:11 --> Helper loaded: file_helper
INFO - 2020-03-18 15:56:11 --> Helper loaded: form_helper
INFO - 2020-03-18 15:56:11 --> Helper loaded: my_helper
INFO - 2020-03-18 15:56:11 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:56:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:56:11 --> Controller Class Initialized
DEBUG - 2020-03-18 15:56:11 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 15:56:11 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:56:11 --> Final output sent to browser
DEBUG - 2020-03-18 15:56:15 --> Total execution time: 0.8751
INFO - 2020-03-18 15:56:50 --> Config Class Initialized
INFO - 2020-03-18 15:56:50 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:56:50 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:56:50 --> Utf8 Class Initialized
INFO - 2020-03-18 15:56:50 --> URI Class Initialized
INFO - 2020-03-18 15:56:50 --> Router Class Initialized
INFO - 2020-03-18 15:56:50 --> Output Class Initialized
INFO - 2020-03-18 15:56:50 --> Security Class Initialized
DEBUG - 2020-03-18 15:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:56:50 --> Input Class Initialized
INFO - 2020-03-18 15:56:51 --> Language Class Initialized
INFO - 2020-03-18 15:56:51 --> Language Class Initialized
INFO - 2020-03-18 15:56:51 --> Config Class Initialized
INFO - 2020-03-18 15:56:51 --> Loader Class Initialized
INFO - 2020-03-18 15:56:51 --> Helper loaded: url_helper
INFO - 2020-03-18 15:56:51 --> Helper loaded: file_helper
INFO - 2020-03-18 15:56:51 --> Helper loaded: form_helper
INFO - 2020-03-18 15:56:51 --> Helper loaded: my_helper
INFO - 2020-03-18 15:56:51 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:56:51 --> Controller Class Initialized
DEBUG - 2020-03-18 15:56:51 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 15:56:51 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:56:51 --> Final output sent to browser
DEBUG - 2020-03-18 15:56:51 --> Total execution time: 0.8834
INFO - 2020-03-18 15:56:56 --> Config Class Initialized
INFO - 2020-03-18 15:56:56 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:56:56 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:56:56 --> Utf8 Class Initialized
INFO - 2020-03-18 15:56:56 --> URI Class Initialized
INFO - 2020-03-18 15:56:56 --> Router Class Initialized
INFO - 2020-03-18 15:56:56 --> Output Class Initialized
INFO - 2020-03-18 15:56:56 --> Security Class Initialized
DEBUG - 2020-03-18 15:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:56:56 --> Input Class Initialized
INFO - 2020-03-18 15:56:56 --> Language Class Initialized
INFO - 2020-03-18 15:56:56 --> Language Class Initialized
INFO - 2020-03-18 15:56:56 --> Config Class Initialized
INFO - 2020-03-18 15:56:56 --> Loader Class Initialized
INFO - 2020-03-18 15:56:57 --> Helper loaded: url_helper
INFO - 2020-03-18 15:56:57 --> Helper loaded: file_helper
INFO - 2020-03-18 15:56:57 --> Helper loaded: form_helper
INFO - 2020-03-18 15:56:57 --> Helper loaded: my_helper
INFO - 2020-03-18 15:56:57 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:56:57 --> Controller Class Initialized
INFO - 2020-03-18 15:56:57 --> Helper loaded: cookie_helper
INFO - 2020-03-18 15:56:57 --> Config Class Initialized
INFO - 2020-03-18 15:56:57 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:56:57 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:56:57 --> Utf8 Class Initialized
INFO - 2020-03-18 15:56:57 --> URI Class Initialized
INFO - 2020-03-18 15:56:57 --> Router Class Initialized
INFO - 2020-03-18 15:56:57 --> Output Class Initialized
INFO - 2020-03-18 15:56:57 --> Security Class Initialized
DEBUG - 2020-03-18 15:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:56:57 --> Input Class Initialized
INFO - 2020-03-18 15:56:57 --> Language Class Initialized
INFO - 2020-03-18 15:56:57 --> Language Class Initialized
INFO - 2020-03-18 15:56:57 --> Config Class Initialized
INFO - 2020-03-18 15:56:57 --> Loader Class Initialized
INFO - 2020-03-18 15:56:57 --> Helper loaded: url_helper
INFO - 2020-03-18 15:56:57 --> Helper loaded: file_helper
INFO - 2020-03-18 15:56:57 --> Helper loaded: form_helper
INFO - 2020-03-18 15:56:57 --> Helper loaded: my_helper
INFO - 2020-03-18 15:56:57 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:56:57 --> Controller Class Initialized
INFO - 2020-03-18 15:56:57 --> Config Class Initialized
INFO - 2020-03-18 15:56:57 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:56:57 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:56:57 --> Utf8 Class Initialized
INFO - 2020-03-18 15:56:57 --> URI Class Initialized
INFO - 2020-03-18 15:56:57 --> Router Class Initialized
INFO - 2020-03-18 15:56:57 --> Output Class Initialized
INFO - 2020-03-18 15:56:57 --> Security Class Initialized
DEBUG - 2020-03-18 15:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:56:58 --> Input Class Initialized
INFO - 2020-03-18 15:56:58 --> Language Class Initialized
INFO - 2020-03-18 15:56:58 --> Language Class Initialized
INFO - 2020-03-18 15:56:58 --> Config Class Initialized
INFO - 2020-03-18 15:56:58 --> Loader Class Initialized
INFO - 2020-03-18 15:56:58 --> Helper loaded: url_helper
INFO - 2020-03-18 15:56:58 --> Helper loaded: file_helper
INFO - 2020-03-18 15:56:58 --> Helper loaded: form_helper
INFO - 2020-03-18 15:56:58 --> Helper loaded: my_helper
INFO - 2020-03-18 15:56:58 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:56:58 --> Controller Class Initialized
DEBUG - 2020-03-18 15:56:58 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 15:56:58 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:56:58 --> Final output sent to browser
DEBUG - 2020-03-18 15:56:58 --> Total execution time: 0.5739
INFO - 2020-03-18 15:57:15 --> Config Class Initialized
INFO - 2020-03-18 15:57:15 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:57:15 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:57:15 --> Utf8 Class Initialized
INFO - 2020-03-18 15:57:15 --> URI Class Initialized
INFO - 2020-03-18 15:57:15 --> Router Class Initialized
INFO - 2020-03-18 15:57:15 --> Output Class Initialized
INFO - 2020-03-18 15:57:15 --> Security Class Initialized
DEBUG - 2020-03-18 15:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:57:15 --> Input Class Initialized
INFO - 2020-03-18 15:57:15 --> Language Class Initialized
INFO - 2020-03-18 15:57:15 --> Language Class Initialized
INFO - 2020-03-18 15:57:15 --> Config Class Initialized
INFO - 2020-03-18 15:57:15 --> Loader Class Initialized
INFO - 2020-03-18 15:57:15 --> Helper loaded: url_helper
INFO - 2020-03-18 15:57:15 --> Helper loaded: file_helper
INFO - 2020-03-18 15:57:15 --> Helper loaded: form_helper
INFO - 2020-03-18 15:57:15 --> Helper loaded: my_helper
INFO - 2020-03-18 15:57:15 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:57:15 --> Controller Class Initialized
INFO - 2020-03-18 15:57:15 --> Helper loaded: cookie_helper
INFO - 2020-03-18 15:57:15 --> Final output sent to browser
DEBUG - 2020-03-18 15:57:15 --> Total execution time: 0.6711
INFO - 2020-03-18 15:57:15 --> Config Class Initialized
INFO - 2020-03-18 15:57:16 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:57:16 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:57:16 --> Utf8 Class Initialized
INFO - 2020-03-18 15:57:16 --> URI Class Initialized
INFO - 2020-03-18 15:57:16 --> Router Class Initialized
INFO - 2020-03-18 15:57:16 --> Output Class Initialized
INFO - 2020-03-18 15:57:16 --> Security Class Initialized
DEBUG - 2020-03-18 15:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:57:16 --> Input Class Initialized
INFO - 2020-03-18 15:57:16 --> Language Class Initialized
INFO - 2020-03-18 15:57:16 --> Language Class Initialized
INFO - 2020-03-18 15:57:16 --> Config Class Initialized
INFO - 2020-03-18 15:57:16 --> Loader Class Initialized
INFO - 2020-03-18 15:57:16 --> Helper loaded: url_helper
INFO - 2020-03-18 15:57:16 --> Helper loaded: file_helper
INFO - 2020-03-18 15:57:16 --> Helper loaded: form_helper
INFO - 2020-03-18 15:57:16 --> Helper loaded: my_helper
INFO - 2020-03-18 15:57:16 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:57:17 --> Controller Class Initialized
DEBUG - 2020-03-18 15:57:17 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 15:57:17 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:57:17 --> Final output sent to browser
DEBUG - 2020-03-18 15:57:17 --> Total execution time: 1.2930
INFO - 2020-03-18 15:58:11 --> Config Class Initialized
INFO - 2020-03-18 15:58:11 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:58:12 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:58:12 --> Utf8 Class Initialized
INFO - 2020-03-18 15:58:12 --> URI Class Initialized
INFO - 2020-03-18 15:58:12 --> Router Class Initialized
INFO - 2020-03-18 15:58:12 --> Output Class Initialized
INFO - 2020-03-18 15:58:12 --> Security Class Initialized
DEBUG - 2020-03-18 15:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:58:12 --> Input Class Initialized
INFO - 2020-03-18 15:58:12 --> Language Class Initialized
INFO - 2020-03-18 15:58:12 --> Language Class Initialized
INFO - 2020-03-18 15:58:12 --> Config Class Initialized
INFO - 2020-03-18 15:58:12 --> Loader Class Initialized
INFO - 2020-03-18 15:58:12 --> Helper loaded: url_helper
INFO - 2020-03-18 15:58:12 --> Helper loaded: file_helper
INFO - 2020-03-18 15:58:12 --> Helper loaded: form_helper
INFO - 2020-03-18 15:58:12 --> Helper loaded: my_helper
INFO - 2020-03-18 15:58:12 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:58:12 --> Controller Class Initialized
DEBUG - 2020-03-18 15:58:12 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 15:58:12 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:58:12 --> Final output sent to browser
DEBUG - 2020-03-18 15:58:13 --> Total execution time: 0.9678
INFO - 2020-03-18 15:59:32 --> Config Class Initialized
INFO - 2020-03-18 15:59:32 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:59:32 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:59:32 --> Utf8 Class Initialized
INFO - 2020-03-18 15:59:32 --> URI Class Initialized
INFO - 2020-03-18 15:59:32 --> Router Class Initialized
INFO - 2020-03-18 15:59:32 --> Output Class Initialized
INFO - 2020-03-18 15:59:32 --> Security Class Initialized
DEBUG - 2020-03-18 15:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:59:32 --> Input Class Initialized
INFO - 2020-03-18 15:59:32 --> Language Class Initialized
INFO - 2020-03-18 15:59:32 --> Language Class Initialized
INFO - 2020-03-18 15:59:32 --> Config Class Initialized
INFO - 2020-03-18 15:59:33 --> Loader Class Initialized
INFO - 2020-03-18 15:59:33 --> Helper loaded: url_helper
INFO - 2020-03-18 15:59:33 --> Helper loaded: file_helper
INFO - 2020-03-18 15:59:33 --> Helper loaded: form_helper
INFO - 2020-03-18 15:59:33 --> Helper loaded: my_helper
INFO - 2020-03-18 15:59:33 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:59:33 --> Controller Class Initialized
DEBUG - 2020-03-18 15:59:33 --> File loaded: D:\xampp\htdocs\myraport\application\modules/set_walikelas/views/list.php
DEBUG - 2020-03-18 15:59:33 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:59:33 --> Final output sent to browser
DEBUG - 2020-03-18 15:59:33 --> Total execution time: 0.6190
INFO - 2020-03-18 15:59:34 --> Config Class Initialized
INFO - 2020-03-18 15:59:34 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:59:34 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:59:34 --> Utf8 Class Initialized
INFO - 2020-03-18 15:59:34 --> URI Class Initialized
INFO - 2020-03-18 15:59:34 --> Router Class Initialized
INFO - 2020-03-18 15:59:34 --> Output Class Initialized
INFO - 2020-03-18 15:59:34 --> Security Class Initialized
DEBUG - 2020-03-18 15:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:59:34 --> Input Class Initialized
INFO - 2020-03-18 15:59:34 --> Language Class Initialized
INFO - 2020-03-18 15:59:34 --> Language Class Initialized
INFO - 2020-03-18 15:59:34 --> Config Class Initialized
INFO - 2020-03-18 15:59:34 --> Loader Class Initialized
INFO - 2020-03-18 15:59:34 --> Helper loaded: url_helper
INFO - 2020-03-18 15:59:34 --> Helper loaded: file_helper
INFO - 2020-03-18 15:59:34 --> Helper loaded: form_helper
INFO - 2020-03-18 15:59:34 --> Helper loaded: my_helper
INFO - 2020-03-18 15:59:34 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:59:34 --> Controller Class Initialized
INFO - 2020-03-18 15:59:36 --> Config Class Initialized
INFO - 2020-03-18 15:59:36 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:59:37 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:59:37 --> Utf8 Class Initialized
INFO - 2020-03-18 15:59:37 --> URI Class Initialized
DEBUG - 2020-03-18 15:59:37 --> No URI present. Default controller set.
INFO - 2020-03-18 15:59:37 --> Router Class Initialized
INFO - 2020-03-18 15:59:37 --> Output Class Initialized
INFO - 2020-03-18 15:59:37 --> Security Class Initialized
DEBUG - 2020-03-18 15:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:59:37 --> Input Class Initialized
INFO - 2020-03-18 15:59:37 --> Language Class Initialized
INFO - 2020-03-18 15:59:37 --> Language Class Initialized
INFO - 2020-03-18 15:59:37 --> Config Class Initialized
INFO - 2020-03-18 15:59:37 --> Loader Class Initialized
INFO - 2020-03-18 15:59:37 --> Helper loaded: url_helper
INFO - 2020-03-18 15:59:37 --> Helper loaded: file_helper
INFO - 2020-03-18 15:59:37 --> Helper loaded: form_helper
INFO - 2020-03-18 15:59:37 --> Helper loaded: my_helper
INFO - 2020-03-18 15:59:37 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:59:37 --> Controller Class Initialized
DEBUG - 2020-03-18 15:59:37 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 15:59:37 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:59:37 --> Final output sent to browser
DEBUG - 2020-03-18 15:59:37 --> Total execution time: 0.6462
INFO - 2020-03-18 15:59:43 --> Config Class Initialized
INFO - 2020-03-18 15:59:43 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:59:43 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:59:43 --> Utf8 Class Initialized
INFO - 2020-03-18 15:59:43 --> URI Class Initialized
INFO - 2020-03-18 15:59:43 --> Router Class Initialized
INFO - 2020-03-18 15:59:43 --> Output Class Initialized
INFO - 2020-03-18 15:59:43 --> Security Class Initialized
DEBUG - 2020-03-18 15:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:59:43 --> Input Class Initialized
INFO - 2020-03-18 15:59:43 --> Language Class Initialized
INFO - 2020-03-18 15:59:43 --> Language Class Initialized
INFO - 2020-03-18 15:59:43 --> Config Class Initialized
INFO - 2020-03-18 15:59:43 --> Loader Class Initialized
INFO - 2020-03-18 15:59:43 --> Helper loaded: url_helper
INFO - 2020-03-18 15:59:43 --> Helper loaded: file_helper
INFO - 2020-03-18 15:59:43 --> Helper loaded: form_helper
INFO - 2020-03-18 15:59:43 --> Helper loaded: my_helper
INFO - 2020-03-18 15:59:43 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:59:43 --> Controller Class Initialized
INFO - 2020-03-18 15:59:43 --> Helper loaded: cookie_helper
INFO - 2020-03-18 15:59:43 --> Config Class Initialized
INFO - 2020-03-18 15:59:43 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:59:43 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:59:43 --> Utf8 Class Initialized
INFO - 2020-03-18 15:59:43 --> URI Class Initialized
INFO - 2020-03-18 15:59:43 --> Router Class Initialized
INFO - 2020-03-18 15:59:43 --> Output Class Initialized
INFO - 2020-03-18 15:59:43 --> Security Class Initialized
DEBUG - 2020-03-18 15:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:59:43 --> Input Class Initialized
INFO - 2020-03-18 15:59:43 --> Language Class Initialized
INFO - 2020-03-18 15:59:43 --> Language Class Initialized
INFO - 2020-03-18 15:59:44 --> Config Class Initialized
INFO - 2020-03-18 15:59:44 --> Loader Class Initialized
INFO - 2020-03-18 15:59:44 --> Helper loaded: url_helper
INFO - 2020-03-18 15:59:44 --> Helper loaded: file_helper
INFO - 2020-03-18 15:59:44 --> Helper loaded: form_helper
INFO - 2020-03-18 15:59:44 --> Helper loaded: my_helper
INFO - 2020-03-18 15:59:44 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:59:44 --> Controller Class Initialized
INFO - 2020-03-18 15:59:44 --> Config Class Initialized
INFO - 2020-03-18 15:59:44 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:59:44 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:59:44 --> Utf8 Class Initialized
INFO - 2020-03-18 15:59:44 --> URI Class Initialized
INFO - 2020-03-18 15:59:44 --> Router Class Initialized
INFO - 2020-03-18 15:59:44 --> Output Class Initialized
INFO - 2020-03-18 15:59:44 --> Security Class Initialized
DEBUG - 2020-03-18 15:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:59:44 --> Input Class Initialized
INFO - 2020-03-18 15:59:44 --> Language Class Initialized
INFO - 2020-03-18 15:59:44 --> Language Class Initialized
INFO - 2020-03-18 15:59:44 --> Config Class Initialized
INFO - 2020-03-18 15:59:44 --> Loader Class Initialized
INFO - 2020-03-18 15:59:44 --> Helper loaded: url_helper
INFO - 2020-03-18 15:59:44 --> Helper loaded: file_helper
INFO - 2020-03-18 15:59:44 --> Helper loaded: form_helper
INFO - 2020-03-18 15:59:44 --> Helper loaded: my_helper
INFO - 2020-03-18 15:59:44 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:59:44 --> Controller Class Initialized
DEBUG - 2020-03-18 15:59:44 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 15:59:44 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:59:44 --> Final output sent to browser
DEBUG - 2020-03-18 15:59:44 --> Total execution time: 0.5866
INFO - 2020-03-18 15:59:53 --> Config Class Initialized
INFO - 2020-03-18 15:59:53 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:59:54 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:59:54 --> Utf8 Class Initialized
INFO - 2020-03-18 15:59:54 --> URI Class Initialized
INFO - 2020-03-18 15:59:54 --> Router Class Initialized
INFO - 2020-03-18 15:59:54 --> Output Class Initialized
INFO - 2020-03-18 15:59:54 --> Security Class Initialized
DEBUG - 2020-03-18 15:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:59:54 --> Input Class Initialized
INFO - 2020-03-18 15:59:54 --> Language Class Initialized
INFO - 2020-03-18 15:59:54 --> Language Class Initialized
INFO - 2020-03-18 15:59:54 --> Config Class Initialized
INFO - 2020-03-18 15:59:54 --> Loader Class Initialized
INFO - 2020-03-18 15:59:54 --> Helper loaded: url_helper
INFO - 2020-03-18 15:59:54 --> Helper loaded: file_helper
INFO - 2020-03-18 15:59:54 --> Helper loaded: form_helper
INFO - 2020-03-18 15:59:54 --> Helper loaded: my_helper
INFO - 2020-03-18 15:59:54 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:59:54 --> Controller Class Initialized
INFO - 2020-03-18 15:59:54 --> Helper loaded: cookie_helper
INFO - 2020-03-18 15:59:54 --> Final output sent to browser
DEBUG - 2020-03-18 15:59:54 --> Total execution time: 0.6405
INFO - 2020-03-18 15:59:54 --> Config Class Initialized
INFO - 2020-03-18 15:59:54 --> Hooks Class Initialized
DEBUG - 2020-03-18 15:59:54 --> UTF-8 Support Enabled
INFO - 2020-03-18 15:59:54 --> Utf8 Class Initialized
INFO - 2020-03-18 15:59:54 --> URI Class Initialized
INFO - 2020-03-18 15:59:54 --> Router Class Initialized
INFO - 2020-03-18 15:59:55 --> Output Class Initialized
INFO - 2020-03-18 15:59:55 --> Security Class Initialized
DEBUG - 2020-03-18 15:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 15:59:55 --> Input Class Initialized
INFO - 2020-03-18 15:59:55 --> Language Class Initialized
INFO - 2020-03-18 15:59:55 --> Language Class Initialized
INFO - 2020-03-18 15:59:55 --> Config Class Initialized
INFO - 2020-03-18 15:59:56 --> Loader Class Initialized
INFO - 2020-03-18 15:59:56 --> Helper loaded: url_helper
INFO - 2020-03-18 15:59:56 --> Helper loaded: file_helper
INFO - 2020-03-18 15:59:56 --> Helper loaded: form_helper
INFO - 2020-03-18 15:59:56 --> Helper loaded: my_helper
INFO - 2020-03-18 15:59:56 --> Database Driver Class Initialized
DEBUG - 2020-03-18 15:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 15:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 15:59:57 --> Controller Class Initialized
DEBUG - 2020-03-18 15:59:57 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 15:59:57 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 15:59:57 --> Final output sent to browser
DEBUG - 2020-03-18 15:59:57 --> Total execution time: 2.3918
INFO - 2020-03-18 16:01:48 --> Config Class Initialized
INFO - 2020-03-18 16:01:48 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:01:48 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:01:48 --> Utf8 Class Initialized
INFO - 2020-03-18 16:01:48 --> URI Class Initialized
DEBUG - 2020-03-18 16:01:48 --> No URI present. Default controller set.
INFO - 2020-03-18 16:01:48 --> Router Class Initialized
INFO - 2020-03-18 16:01:48 --> Output Class Initialized
INFO - 2020-03-18 16:01:48 --> Security Class Initialized
DEBUG - 2020-03-18 16:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:01:48 --> Input Class Initialized
INFO - 2020-03-18 16:01:48 --> Language Class Initialized
INFO - 2020-03-18 16:01:48 --> Language Class Initialized
INFO - 2020-03-18 16:01:48 --> Config Class Initialized
INFO - 2020-03-18 16:01:48 --> Loader Class Initialized
INFO - 2020-03-18 16:01:48 --> Helper loaded: url_helper
INFO - 2020-03-18 16:01:48 --> Helper loaded: file_helper
INFO - 2020-03-18 16:01:48 --> Helper loaded: form_helper
INFO - 2020-03-18 16:01:48 --> Helper loaded: my_helper
INFO - 2020-03-18 16:01:48 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:01:49 --> Controller Class Initialized
DEBUG - 2020-03-18 16:01:49 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 16:01:49 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:01:49 --> Final output sent to browser
DEBUG - 2020-03-18 16:01:49 --> Total execution time: 0.6533
INFO - 2020-03-18 16:01:52 --> Config Class Initialized
INFO - 2020-03-18 16:01:52 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:01:52 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:01:52 --> Utf8 Class Initialized
INFO - 2020-03-18 16:01:52 --> URI Class Initialized
INFO - 2020-03-18 16:01:52 --> Router Class Initialized
INFO - 2020-03-18 16:01:52 --> Output Class Initialized
INFO - 2020-03-18 16:01:52 --> Security Class Initialized
DEBUG - 2020-03-18 16:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:01:52 --> Input Class Initialized
INFO - 2020-03-18 16:01:52 --> Language Class Initialized
INFO - 2020-03-18 16:01:52 --> Language Class Initialized
INFO - 2020-03-18 16:01:52 --> Config Class Initialized
INFO - 2020-03-18 16:01:52 --> Loader Class Initialized
INFO - 2020-03-18 16:01:52 --> Helper loaded: url_helper
INFO - 2020-03-18 16:01:52 --> Helper loaded: file_helper
INFO - 2020-03-18 16:01:52 --> Helper loaded: form_helper
INFO - 2020-03-18 16:01:52 --> Helper loaded: my_helper
INFO - 2020-03-18 16:01:52 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:01:52 --> Controller Class Initialized
INFO - 2020-03-18 16:01:52 --> Helper loaded: cookie_helper
INFO - 2020-03-18 16:01:52 --> Config Class Initialized
INFO - 2020-03-18 16:01:52 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:01:52 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:01:52 --> Utf8 Class Initialized
INFO - 2020-03-18 16:01:53 --> URI Class Initialized
INFO - 2020-03-18 16:01:53 --> Router Class Initialized
INFO - 2020-03-18 16:01:53 --> Output Class Initialized
INFO - 2020-03-18 16:01:53 --> Security Class Initialized
DEBUG - 2020-03-18 16:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:01:53 --> Input Class Initialized
INFO - 2020-03-18 16:01:53 --> Language Class Initialized
INFO - 2020-03-18 16:01:53 --> Language Class Initialized
INFO - 2020-03-18 16:01:53 --> Config Class Initialized
INFO - 2020-03-18 16:01:53 --> Loader Class Initialized
INFO - 2020-03-18 16:01:53 --> Helper loaded: url_helper
INFO - 2020-03-18 16:01:53 --> Helper loaded: file_helper
INFO - 2020-03-18 16:01:53 --> Helper loaded: form_helper
INFO - 2020-03-18 16:01:53 --> Helper loaded: my_helper
INFO - 2020-03-18 16:01:53 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:01:53 --> Controller Class Initialized
INFO - 2020-03-18 16:01:53 --> Config Class Initialized
INFO - 2020-03-18 16:01:53 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:01:53 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:01:53 --> Utf8 Class Initialized
INFO - 2020-03-18 16:01:53 --> URI Class Initialized
INFO - 2020-03-18 16:01:53 --> Router Class Initialized
INFO - 2020-03-18 16:01:53 --> Output Class Initialized
INFO - 2020-03-18 16:01:53 --> Security Class Initialized
DEBUG - 2020-03-18 16:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:01:53 --> Input Class Initialized
INFO - 2020-03-18 16:01:53 --> Language Class Initialized
INFO - 2020-03-18 16:01:53 --> Language Class Initialized
INFO - 2020-03-18 16:01:53 --> Config Class Initialized
INFO - 2020-03-18 16:01:53 --> Loader Class Initialized
INFO - 2020-03-18 16:01:53 --> Helper loaded: url_helper
INFO - 2020-03-18 16:01:53 --> Helper loaded: file_helper
INFO - 2020-03-18 16:01:53 --> Helper loaded: form_helper
INFO - 2020-03-18 16:01:54 --> Helper loaded: my_helper
INFO - 2020-03-18 16:01:54 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:01:54 --> Controller Class Initialized
DEBUG - 2020-03-18 16:01:54 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 16:01:54 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:01:54 --> Final output sent to browser
DEBUG - 2020-03-18 16:01:54 --> Total execution time: 0.6336
INFO - 2020-03-18 16:02:02 --> Config Class Initialized
INFO - 2020-03-18 16:02:02 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:02:02 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:02:02 --> Utf8 Class Initialized
INFO - 2020-03-18 16:02:02 --> URI Class Initialized
INFO - 2020-03-18 16:02:02 --> Router Class Initialized
INFO - 2020-03-18 16:02:02 --> Output Class Initialized
INFO - 2020-03-18 16:02:02 --> Security Class Initialized
DEBUG - 2020-03-18 16:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:02:02 --> Input Class Initialized
INFO - 2020-03-18 16:02:02 --> Language Class Initialized
INFO - 2020-03-18 16:02:02 --> Language Class Initialized
INFO - 2020-03-18 16:02:02 --> Config Class Initialized
INFO - 2020-03-18 16:02:02 --> Loader Class Initialized
INFO - 2020-03-18 16:02:02 --> Helper loaded: url_helper
INFO - 2020-03-18 16:02:02 --> Helper loaded: file_helper
INFO - 2020-03-18 16:02:02 --> Helper loaded: form_helper
INFO - 2020-03-18 16:02:02 --> Helper loaded: my_helper
INFO - 2020-03-18 16:02:02 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:02:02 --> Controller Class Initialized
INFO - 2020-03-18 16:02:03 --> Helper loaded: cookie_helper
INFO - 2020-03-18 16:02:03 --> Final output sent to browser
DEBUG - 2020-03-18 16:02:03 --> Total execution time: 0.6896
INFO - 2020-03-18 16:02:03 --> Config Class Initialized
INFO - 2020-03-18 16:02:03 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:02:03 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:02:03 --> Utf8 Class Initialized
INFO - 2020-03-18 16:02:03 --> URI Class Initialized
INFO - 2020-03-18 16:02:03 --> Router Class Initialized
INFO - 2020-03-18 16:02:03 --> Output Class Initialized
INFO - 2020-03-18 16:02:03 --> Security Class Initialized
DEBUG - 2020-03-18 16:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:02:03 --> Input Class Initialized
INFO - 2020-03-18 16:02:03 --> Language Class Initialized
INFO - 2020-03-18 16:02:03 --> Language Class Initialized
INFO - 2020-03-18 16:02:03 --> Config Class Initialized
INFO - 2020-03-18 16:02:03 --> Loader Class Initialized
INFO - 2020-03-18 16:02:03 --> Helper loaded: url_helper
INFO - 2020-03-18 16:02:03 --> Helper loaded: file_helper
INFO - 2020-03-18 16:02:03 --> Helper loaded: form_helper
INFO - 2020-03-18 16:02:03 --> Helper loaded: my_helper
INFO - 2020-03-18 16:02:03 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:02:03 --> Controller Class Initialized
DEBUG - 2020-03-18 16:02:03 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 16:02:04 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:02:04 --> Final output sent to browser
DEBUG - 2020-03-18 16:02:06 --> Total execution time: 0.8611
INFO - 2020-03-18 16:02:43 --> Config Class Initialized
INFO - 2020-03-18 16:02:43 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:02:43 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:02:43 --> Utf8 Class Initialized
INFO - 2020-03-18 16:02:43 --> URI Class Initialized
INFO - 2020-03-18 16:02:44 --> Router Class Initialized
INFO - 2020-03-18 16:02:44 --> Output Class Initialized
INFO - 2020-03-18 16:02:44 --> Security Class Initialized
DEBUG - 2020-03-18 16:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:02:44 --> Input Class Initialized
INFO - 2020-03-18 16:02:44 --> Language Class Initialized
INFO - 2020-03-18 16:02:44 --> Language Class Initialized
INFO - 2020-03-18 16:02:44 --> Config Class Initialized
INFO - 2020-03-18 16:02:44 --> Loader Class Initialized
INFO - 2020-03-18 16:02:44 --> Helper loaded: url_helper
INFO - 2020-03-18 16:02:44 --> Helper loaded: file_helper
INFO - 2020-03-18 16:02:44 --> Helper loaded: form_helper
INFO - 2020-03-18 16:02:44 --> Helper loaded: my_helper
INFO - 2020-03-18 16:02:44 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:02:44 --> Controller Class Initialized
DEBUG - 2020-03-18 16:02:44 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 16:02:44 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:02:44 --> Final output sent to browser
DEBUG - 2020-03-18 16:02:44 --> Total execution time: 0.7648
INFO - 2020-03-18 16:02:46 --> Config Class Initialized
INFO - 2020-03-18 16:02:46 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:02:46 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:02:46 --> Utf8 Class Initialized
INFO - 2020-03-18 16:02:46 --> URI Class Initialized
INFO - 2020-03-18 16:02:46 --> Router Class Initialized
INFO - 2020-03-18 16:02:46 --> Output Class Initialized
INFO - 2020-03-18 16:02:46 --> Security Class Initialized
DEBUG - 2020-03-18 16:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:02:46 --> Input Class Initialized
INFO - 2020-03-18 16:02:46 --> Language Class Initialized
INFO - 2020-03-18 16:02:46 --> Language Class Initialized
INFO - 2020-03-18 16:02:46 --> Config Class Initialized
INFO - 2020-03-18 16:02:46 --> Loader Class Initialized
INFO - 2020-03-18 16:02:47 --> Helper loaded: url_helper
INFO - 2020-03-18 16:02:47 --> Helper loaded: file_helper
INFO - 2020-03-18 16:02:47 --> Helper loaded: form_helper
INFO - 2020-03-18 16:02:47 --> Helper loaded: my_helper
INFO - 2020-03-18 16:02:47 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:02:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:02:47 --> Controller Class Initialized
DEBUG - 2020-03-18 16:02:47 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_siswa/views/list.php
DEBUG - 2020-03-18 16:02:47 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:02:47 --> Final output sent to browser
DEBUG - 2020-03-18 16:02:47 --> Total execution time: 0.6847
INFO - 2020-03-18 16:02:47 --> Config Class Initialized
INFO - 2020-03-18 16:02:47 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:02:47 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:02:47 --> Utf8 Class Initialized
INFO - 2020-03-18 16:02:47 --> URI Class Initialized
INFO - 2020-03-18 16:02:47 --> Router Class Initialized
INFO - 2020-03-18 16:02:48 --> Output Class Initialized
INFO - 2020-03-18 16:02:48 --> Security Class Initialized
DEBUG - 2020-03-18 16:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:02:48 --> Input Class Initialized
INFO - 2020-03-18 16:02:48 --> Language Class Initialized
INFO - 2020-03-18 16:02:48 --> Language Class Initialized
INFO - 2020-03-18 16:02:48 --> Config Class Initialized
INFO - 2020-03-18 16:02:48 --> Loader Class Initialized
INFO - 2020-03-18 16:02:48 --> Helper loaded: url_helper
INFO - 2020-03-18 16:02:48 --> Helper loaded: file_helper
INFO - 2020-03-18 16:02:48 --> Helper loaded: form_helper
INFO - 2020-03-18 16:02:48 --> Helper loaded: my_helper
INFO - 2020-03-18 16:02:48 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:02:48 --> Controller Class Initialized
INFO - 2020-03-18 16:02:56 --> Config Class Initialized
INFO - 2020-03-18 16:02:56 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:02:56 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:02:56 --> Utf8 Class Initialized
INFO - 2020-03-18 16:02:56 --> URI Class Initialized
INFO - 2020-03-18 16:02:56 --> Router Class Initialized
INFO - 2020-03-18 16:02:56 --> Output Class Initialized
INFO - 2020-03-18 16:02:56 --> Security Class Initialized
DEBUG - 2020-03-18 16:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:02:57 --> Input Class Initialized
INFO - 2020-03-18 16:02:57 --> Language Class Initialized
INFO - 2020-03-18 16:02:57 --> Language Class Initialized
INFO - 2020-03-18 16:02:57 --> Config Class Initialized
INFO - 2020-03-18 16:02:57 --> Loader Class Initialized
INFO - 2020-03-18 16:02:57 --> Helper loaded: url_helper
INFO - 2020-03-18 16:02:57 --> Helper loaded: file_helper
INFO - 2020-03-18 16:02:57 --> Helper loaded: form_helper
INFO - 2020-03-18 16:02:57 --> Helper loaded: my_helper
INFO - 2020-03-18 16:02:57 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:02:57 --> Controller Class Initialized
DEBUG - 2020-03-18 16:02:57 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_siswa/views/list.php
DEBUG - 2020-03-18 16:02:57 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:02:57 --> Final output sent to browser
DEBUG - 2020-03-18 16:02:57 --> Total execution time: 0.9376
INFO - 2020-03-18 16:02:58 --> Config Class Initialized
INFO - 2020-03-18 16:02:58 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:02:58 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:02:58 --> Utf8 Class Initialized
INFO - 2020-03-18 16:02:58 --> URI Class Initialized
INFO - 2020-03-18 16:02:58 --> Router Class Initialized
INFO - 2020-03-18 16:02:58 --> Output Class Initialized
INFO - 2020-03-18 16:02:58 --> Security Class Initialized
DEBUG - 2020-03-18 16:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:02:58 --> Input Class Initialized
INFO - 2020-03-18 16:02:58 --> Language Class Initialized
INFO - 2020-03-18 16:02:58 --> Language Class Initialized
INFO - 2020-03-18 16:02:58 --> Config Class Initialized
INFO - 2020-03-18 16:02:58 --> Loader Class Initialized
INFO - 2020-03-18 16:02:58 --> Helper loaded: url_helper
INFO - 2020-03-18 16:02:58 --> Helper loaded: file_helper
INFO - 2020-03-18 16:02:58 --> Helper loaded: form_helper
INFO - 2020-03-18 16:02:58 --> Helper loaded: my_helper
INFO - 2020-03-18 16:02:58 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:02:59 --> Controller Class Initialized
INFO - 2020-03-18 16:03:08 --> Config Class Initialized
INFO - 2020-03-18 16:03:08 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:03:08 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:03:08 --> Utf8 Class Initialized
INFO - 2020-03-18 16:03:08 --> URI Class Initialized
INFO - 2020-03-18 16:03:08 --> Router Class Initialized
INFO - 2020-03-18 16:03:08 --> Output Class Initialized
INFO - 2020-03-18 16:03:08 --> Security Class Initialized
DEBUG - 2020-03-18 16:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:03:08 --> Input Class Initialized
INFO - 2020-03-18 16:03:08 --> Language Class Initialized
INFO - 2020-03-18 16:03:08 --> Language Class Initialized
INFO - 2020-03-18 16:03:08 --> Config Class Initialized
INFO - 2020-03-18 16:03:08 --> Loader Class Initialized
INFO - 2020-03-18 16:03:08 --> Helper loaded: url_helper
INFO - 2020-03-18 16:03:08 --> Helper loaded: file_helper
INFO - 2020-03-18 16:03:08 --> Helper loaded: form_helper
INFO - 2020-03-18 16:03:08 --> Helper loaded: my_helper
INFO - 2020-03-18 16:03:08 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:03:09 --> Controller Class Initialized
ERROR - 2020-03-18 16:03:09 --> Severity: Notice --> Undefined variable: status_form D:\xampp\htdocs\myraport\application\modules\data_siswa\views\form.php 231
DEBUG - 2020-03-18 16:03:09 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_siswa/views/form.php
DEBUG - 2020-03-18 16:03:09 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:03:09 --> Final output sent to browser
DEBUG - 2020-03-18 16:03:09 --> Total execution time: 0.7232
INFO - 2020-03-18 16:03:16 --> Config Class Initialized
INFO - 2020-03-18 16:03:16 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:03:16 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:03:16 --> Utf8 Class Initialized
INFO - 2020-03-18 16:03:16 --> URI Class Initialized
INFO - 2020-03-18 16:03:16 --> Router Class Initialized
INFO - 2020-03-18 16:03:16 --> Output Class Initialized
INFO - 2020-03-18 16:03:16 --> Security Class Initialized
DEBUG - 2020-03-18 16:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:03:16 --> Input Class Initialized
INFO - 2020-03-18 16:03:16 --> Language Class Initialized
INFO - 2020-03-18 16:03:17 --> Language Class Initialized
INFO - 2020-03-18 16:03:17 --> Config Class Initialized
INFO - 2020-03-18 16:03:17 --> Loader Class Initialized
INFO - 2020-03-18 16:03:17 --> Helper loaded: url_helper
INFO - 2020-03-18 16:03:17 --> Helper loaded: file_helper
INFO - 2020-03-18 16:03:17 --> Helper loaded: form_helper
INFO - 2020-03-18 16:03:17 --> Helper loaded: my_helper
INFO - 2020-03-18 16:03:17 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:03:17 --> Controller Class Initialized
DEBUG - 2020-03-18 16:03:17 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_siswa/views/list.php
DEBUG - 2020-03-18 16:03:17 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:03:17 --> Final output sent to browser
DEBUG - 2020-03-18 16:03:17 --> Total execution time: 0.9141
INFO - 2020-03-18 16:03:18 --> Config Class Initialized
INFO - 2020-03-18 16:03:18 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:03:18 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:03:18 --> Utf8 Class Initialized
INFO - 2020-03-18 16:03:18 --> URI Class Initialized
INFO - 2020-03-18 16:03:18 --> Router Class Initialized
INFO - 2020-03-18 16:03:18 --> Output Class Initialized
INFO - 2020-03-18 16:03:18 --> Security Class Initialized
DEBUG - 2020-03-18 16:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:03:18 --> Input Class Initialized
INFO - 2020-03-18 16:03:18 --> Language Class Initialized
INFO - 2020-03-18 16:03:18 --> Language Class Initialized
INFO - 2020-03-18 16:03:18 --> Config Class Initialized
INFO - 2020-03-18 16:03:18 --> Loader Class Initialized
INFO - 2020-03-18 16:03:18 --> Helper loaded: url_helper
INFO - 2020-03-18 16:03:18 --> Helper loaded: file_helper
INFO - 2020-03-18 16:03:18 --> Helper loaded: form_helper
INFO - 2020-03-18 16:03:18 --> Helper loaded: my_helper
INFO - 2020-03-18 16:03:18 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:03:19 --> Controller Class Initialized
INFO - 2020-03-18 16:03:36 --> Config Class Initialized
INFO - 2020-03-18 16:03:36 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:03:36 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:03:36 --> Utf8 Class Initialized
INFO - 2020-03-18 16:03:36 --> URI Class Initialized
INFO - 2020-03-18 16:03:36 --> Router Class Initialized
INFO - 2020-03-18 16:03:36 --> Output Class Initialized
INFO - 2020-03-18 16:03:36 --> Security Class Initialized
DEBUG - 2020-03-18 16:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:03:36 --> Input Class Initialized
INFO - 2020-03-18 16:03:36 --> Language Class Initialized
INFO - 2020-03-18 16:03:36 --> Language Class Initialized
INFO - 2020-03-18 16:03:36 --> Config Class Initialized
INFO - 2020-03-18 16:03:36 --> Loader Class Initialized
INFO - 2020-03-18 16:03:36 --> Helper loaded: url_helper
INFO - 2020-03-18 16:03:36 --> Helper loaded: file_helper
INFO - 2020-03-18 16:03:36 --> Helper loaded: form_helper
INFO - 2020-03-18 16:03:36 --> Helper loaded: my_helper
INFO - 2020-03-18 16:03:36 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:03:36 --> Controller Class Initialized
INFO - 2020-03-18 16:03:37 --> Final output sent to browser
DEBUG - 2020-03-18 16:03:37 --> Total execution time: 0.8990
INFO - 2020-03-18 16:03:37 --> Config Class Initialized
INFO - 2020-03-18 16:03:37 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:03:37 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:03:37 --> Utf8 Class Initialized
INFO - 2020-03-18 16:03:37 --> URI Class Initialized
INFO - 2020-03-18 16:03:37 --> Router Class Initialized
INFO - 2020-03-18 16:03:37 --> Output Class Initialized
INFO - 2020-03-18 16:03:37 --> Security Class Initialized
DEBUG - 2020-03-18 16:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:03:37 --> Input Class Initialized
INFO - 2020-03-18 16:03:37 --> Language Class Initialized
INFO - 2020-03-18 16:03:37 --> Language Class Initialized
INFO - 2020-03-18 16:03:37 --> Config Class Initialized
INFO - 2020-03-18 16:03:37 --> Loader Class Initialized
INFO - 2020-03-18 16:03:37 --> Helper loaded: url_helper
INFO - 2020-03-18 16:03:37 --> Helper loaded: file_helper
INFO - 2020-03-18 16:03:37 --> Helper loaded: form_helper
INFO - 2020-03-18 16:03:37 --> Helper loaded: my_helper
INFO - 2020-03-18 16:03:37 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:03:37 --> Controller Class Initialized
INFO - 2020-03-18 16:03:44 --> Config Class Initialized
INFO - 2020-03-18 16:03:44 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:03:44 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:03:44 --> Utf8 Class Initialized
INFO - 2020-03-18 16:03:44 --> URI Class Initialized
INFO - 2020-03-18 16:03:44 --> Router Class Initialized
INFO - 2020-03-18 16:03:44 --> Output Class Initialized
INFO - 2020-03-18 16:03:44 --> Security Class Initialized
DEBUG - 2020-03-18 16:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:03:44 --> Input Class Initialized
INFO - 2020-03-18 16:03:44 --> Language Class Initialized
INFO - 2020-03-18 16:03:44 --> Language Class Initialized
INFO - 2020-03-18 16:03:45 --> Config Class Initialized
INFO - 2020-03-18 16:03:45 --> Loader Class Initialized
INFO - 2020-03-18 16:03:45 --> Helper loaded: url_helper
INFO - 2020-03-18 16:03:45 --> Helper loaded: file_helper
INFO - 2020-03-18 16:03:45 --> Helper loaded: form_helper
INFO - 2020-03-18 16:03:45 --> Helper loaded: my_helper
INFO - 2020-03-18 16:03:45 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:03:45 --> Controller Class Initialized
INFO - 2020-03-18 16:03:45 --> Helper loaded: cookie_helper
INFO - 2020-03-18 16:03:45 --> Config Class Initialized
INFO - 2020-03-18 16:03:45 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:03:45 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:03:45 --> Utf8 Class Initialized
INFO - 2020-03-18 16:03:45 --> URI Class Initialized
INFO - 2020-03-18 16:03:45 --> Router Class Initialized
INFO - 2020-03-18 16:03:45 --> Output Class Initialized
INFO - 2020-03-18 16:03:45 --> Security Class Initialized
DEBUG - 2020-03-18 16:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:03:45 --> Input Class Initialized
INFO - 2020-03-18 16:03:45 --> Language Class Initialized
INFO - 2020-03-18 16:03:45 --> Language Class Initialized
INFO - 2020-03-18 16:03:45 --> Config Class Initialized
INFO - 2020-03-18 16:03:45 --> Loader Class Initialized
INFO - 2020-03-18 16:03:45 --> Helper loaded: url_helper
INFO - 2020-03-18 16:03:45 --> Helper loaded: file_helper
INFO - 2020-03-18 16:03:45 --> Helper loaded: form_helper
INFO - 2020-03-18 16:03:45 --> Helper loaded: my_helper
INFO - 2020-03-18 16:03:45 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:03:46 --> Controller Class Initialized
INFO - 2020-03-18 16:03:46 --> Config Class Initialized
INFO - 2020-03-18 16:03:46 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:03:46 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:03:46 --> Utf8 Class Initialized
INFO - 2020-03-18 16:03:46 --> URI Class Initialized
INFO - 2020-03-18 16:03:46 --> Router Class Initialized
INFO - 2020-03-18 16:03:46 --> Output Class Initialized
INFO - 2020-03-18 16:03:46 --> Security Class Initialized
DEBUG - 2020-03-18 16:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:03:46 --> Input Class Initialized
INFO - 2020-03-18 16:03:46 --> Language Class Initialized
INFO - 2020-03-18 16:03:46 --> Language Class Initialized
INFO - 2020-03-18 16:03:46 --> Config Class Initialized
INFO - 2020-03-18 16:03:46 --> Loader Class Initialized
INFO - 2020-03-18 16:03:46 --> Helper loaded: url_helper
INFO - 2020-03-18 16:03:46 --> Helper loaded: file_helper
INFO - 2020-03-18 16:03:46 --> Helper loaded: form_helper
INFO - 2020-03-18 16:03:46 --> Helper loaded: my_helper
INFO - 2020-03-18 16:03:46 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:03:46 --> Controller Class Initialized
DEBUG - 2020-03-18 16:03:46 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 16:03:46 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:03:46 --> Final output sent to browser
DEBUG - 2020-03-18 16:03:46 --> Total execution time: 0.7247
INFO - 2020-03-18 16:03:51 --> Config Class Initialized
INFO - 2020-03-18 16:03:51 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:03:51 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:03:51 --> Utf8 Class Initialized
INFO - 2020-03-18 16:03:51 --> URI Class Initialized
INFO - 2020-03-18 16:03:51 --> Router Class Initialized
INFO - 2020-03-18 16:03:51 --> Output Class Initialized
INFO - 2020-03-18 16:03:51 --> Security Class Initialized
DEBUG - 2020-03-18 16:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:03:51 --> Input Class Initialized
INFO - 2020-03-18 16:03:51 --> Language Class Initialized
INFO - 2020-03-18 16:03:51 --> Language Class Initialized
INFO - 2020-03-18 16:03:51 --> Config Class Initialized
INFO - 2020-03-18 16:03:52 --> Loader Class Initialized
INFO - 2020-03-18 16:03:52 --> Helper loaded: url_helper
INFO - 2020-03-18 16:03:52 --> Helper loaded: file_helper
INFO - 2020-03-18 16:03:52 --> Helper loaded: form_helper
INFO - 2020-03-18 16:03:52 --> Helper loaded: my_helper
INFO - 2020-03-18 16:03:52 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:03:52 --> Controller Class Initialized
INFO - 2020-03-18 16:03:52 --> Helper loaded: cookie_helper
INFO - 2020-03-18 16:03:52 --> Final output sent to browser
DEBUG - 2020-03-18 16:03:52 --> Total execution time: 0.7248
INFO - 2020-03-18 16:03:52 --> Config Class Initialized
INFO - 2020-03-18 16:03:52 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:03:52 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:03:52 --> Utf8 Class Initialized
INFO - 2020-03-18 16:03:52 --> URI Class Initialized
INFO - 2020-03-18 16:03:52 --> Router Class Initialized
INFO - 2020-03-18 16:03:52 --> Output Class Initialized
INFO - 2020-03-18 16:03:52 --> Security Class Initialized
DEBUG - 2020-03-18 16:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:03:52 --> Input Class Initialized
INFO - 2020-03-18 16:03:52 --> Language Class Initialized
INFO - 2020-03-18 16:03:52 --> Language Class Initialized
INFO - 2020-03-18 16:03:52 --> Config Class Initialized
INFO - 2020-03-18 16:03:52 --> Loader Class Initialized
INFO - 2020-03-18 16:03:52 --> Helper loaded: url_helper
INFO - 2020-03-18 16:03:52 --> Helper loaded: file_helper
INFO - 2020-03-18 16:03:52 --> Helper loaded: form_helper
INFO - 2020-03-18 16:03:53 --> Helper loaded: my_helper
INFO - 2020-03-18 16:03:53 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:03:53 --> Controller Class Initialized
DEBUG - 2020-03-18 16:03:53 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home_siswa.php
DEBUG - 2020-03-18 16:03:53 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:03:53 --> Final output sent to browser
DEBUG - 2020-03-18 16:03:54 --> Total execution time: 0.8789
INFO - 2020-03-18 16:04:02 --> Config Class Initialized
INFO - 2020-03-18 16:04:02 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:04:02 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:04:02 --> Utf8 Class Initialized
INFO - 2020-03-18 16:04:02 --> URI Class Initialized
INFO - 2020-03-18 16:04:02 --> Router Class Initialized
INFO - 2020-03-18 16:04:02 --> Output Class Initialized
INFO - 2020-03-18 16:04:02 --> Security Class Initialized
DEBUG - 2020-03-18 16:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:04:02 --> Input Class Initialized
INFO - 2020-03-18 16:04:02 --> Language Class Initialized
INFO - 2020-03-18 16:04:02 --> Language Class Initialized
INFO - 2020-03-18 16:04:02 --> Config Class Initialized
INFO - 2020-03-18 16:04:02 --> Loader Class Initialized
INFO - 2020-03-18 16:04:02 --> Helper loaded: url_helper
INFO - 2020-03-18 16:04:02 --> Helper loaded: file_helper
INFO - 2020-03-18 16:04:02 --> Helper loaded: form_helper
INFO - 2020-03-18 16:04:02 --> Helper loaded: my_helper
INFO - 2020-03-18 16:04:02 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:04:03 --> Controller Class Initialized
DEBUG - 2020-03-18 16:04:03 --> File loaded: D:\xampp\htdocs\myraport\application\modules/lihat_raport/views/list.php
DEBUG - 2020-03-18 16:04:03 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:04:03 --> Final output sent to browser
DEBUG - 2020-03-18 16:04:03 --> Total execution time: 0.7402
INFO - 2020-03-18 16:04:08 --> Config Class Initialized
INFO - 2020-03-18 16:04:08 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:04:08 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:04:08 --> Utf8 Class Initialized
INFO - 2020-03-18 16:04:08 --> URI Class Initialized
INFO - 2020-03-18 16:04:09 --> Router Class Initialized
INFO - 2020-03-18 16:04:09 --> Output Class Initialized
INFO - 2020-03-18 16:04:09 --> Security Class Initialized
DEBUG - 2020-03-18 16:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:04:09 --> Input Class Initialized
INFO - 2020-03-18 16:04:09 --> Language Class Initialized
INFO - 2020-03-18 16:04:09 --> Language Class Initialized
INFO - 2020-03-18 16:04:09 --> Config Class Initialized
INFO - 2020-03-18 16:04:09 --> Loader Class Initialized
INFO - 2020-03-18 16:04:09 --> Helper loaded: url_helper
INFO - 2020-03-18 16:04:09 --> Helper loaded: file_helper
INFO - 2020-03-18 16:04:09 --> Helper loaded: form_helper
INFO - 2020-03-18 16:04:09 --> Helper loaded: my_helper
INFO - 2020-03-18 16:04:10 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:04:10 --> Controller Class Initialized
DEBUG - 2020-03-18 16:04:10 --> File loaded: D:\xampp\htdocs\myraport\application\modules/lihat_raport/views/cetak_sampul1.php
INFO - 2020-03-18 16:04:10 --> Final output sent to browser
DEBUG - 2020-03-18 16:04:10 --> Total execution time: 2.0263
INFO - 2020-03-18 16:04:13 --> Config Class Initialized
INFO - 2020-03-18 16:04:13 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:04:14 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:04:14 --> Utf8 Class Initialized
INFO - 2020-03-18 16:04:14 --> URI Class Initialized
INFO - 2020-03-18 16:04:14 --> Router Class Initialized
INFO - 2020-03-18 16:04:14 --> Output Class Initialized
INFO - 2020-03-18 16:04:14 --> Security Class Initialized
DEBUG - 2020-03-18 16:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:04:14 --> Input Class Initialized
INFO - 2020-03-18 16:04:14 --> Language Class Initialized
INFO - 2020-03-18 16:04:14 --> Language Class Initialized
INFO - 2020-03-18 16:04:14 --> Config Class Initialized
INFO - 2020-03-18 16:04:14 --> Loader Class Initialized
INFO - 2020-03-18 16:04:14 --> Helper loaded: url_helper
INFO - 2020-03-18 16:04:14 --> Helper loaded: file_helper
INFO - 2020-03-18 16:04:14 --> Helper loaded: form_helper
INFO - 2020-03-18 16:04:15 --> Helper loaded: my_helper
INFO - 2020-03-18 16:04:15 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:04:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:04:15 --> Controller Class Initialized
DEBUG - 2020-03-18 16:04:15 --> File loaded: D:\xampp\htdocs\myraport\application\modules/lihat_raport/views/cetak_rapot.php
INFO - 2020-03-18 16:04:15 --> Final output sent to browser
DEBUG - 2020-03-18 16:04:15 --> Total execution time: 1.5937
INFO - 2020-03-18 16:04:21 --> Config Class Initialized
INFO - 2020-03-18 16:04:21 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:04:21 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:04:21 --> Utf8 Class Initialized
INFO - 2020-03-18 16:04:21 --> URI Class Initialized
DEBUG - 2020-03-18 16:04:21 --> No URI present. Default controller set.
INFO - 2020-03-18 16:04:21 --> Router Class Initialized
INFO - 2020-03-18 16:04:21 --> Output Class Initialized
INFO - 2020-03-18 16:04:21 --> Security Class Initialized
DEBUG - 2020-03-18 16:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:04:21 --> Input Class Initialized
INFO - 2020-03-18 16:04:21 --> Language Class Initialized
INFO - 2020-03-18 16:04:21 --> Language Class Initialized
INFO - 2020-03-18 16:04:21 --> Config Class Initialized
INFO - 2020-03-18 16:04:21 --> Loader Class Initialized
INFO - 2020-03-18 16:04:21 --> Helper loaded: url_helper
INFO - 2020-03-18 16:04:21 --> Helper loaded: file_helper
INFO - 2020-03-18 16:04:21 --> Helper loaded: form_helper
INFO - 2020-03-18 16:04:21 --> Helper loaded: my_helper
INFO - 2020-03-18 16:04:21 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:04:21 --> Controller Class Initialized
DEBUG - 2020-03-18 16:04:21 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home_siswa.php
DEBUG - 2020-03-18 16:04:21 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:04:21 --> Final output sent to browser
DEBUG - 2020-03-18 16:04:21 --> Total execution time: 0.6709
INFO - 2020-03-18 16:04:24 --> Config Class Initialized
INFO - 2020-03-18 16:04:24 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:04:24 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:04:24 --> Utf8 Class Initialized
INFO - 2020-03-18 16:04:24 --> URI Class Initialized
INFO - 2020-03-18 16:04:24 --> Router Class Initialized
INFO - 2020-03-18 16:04:24 --> Output Class Initialized
INFO - 2020-03-18 16:04:24 --> Security Class Initialized
DEBUG - 2020-03-18 16:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:04:24 --> Input Class Initialized
INFO - 2020-03-18 16:04:24 --> Language Class Initialized
INFO - 2020-03-18 16:04:24 --> Language Class Initialized
INFO - 2020-03-18 16:04:24 --> Config Class Initialized
INFO - 2020-03-18 16:04:24 --> Loader Class Initialized
INFO - 2020-03-18 16:04:24 --> Helper loaded: url_helper
INFO - 2020-03-18 16:04:24 --> Helper loaded: file_helper
INFO - 2020-03-18 16:04:24 --> Helper loaded: form_helper
INFO - 2020-03-18 16:04:24 --> Helper loaded: my_helper
INFO - 2020-03-18 16:04:24 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:04:24 --> Controller Class Initialized
DEBUG - 2020-03-18 16:04:24 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_ubah_password.php
DEBUG - 2020-03-18 16:04:24 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:04:25 --> Final output sent to browser
DEBUG - 2020-03-18 16:04:25 --> Total execution time: 0.6560
INFO - 2020-03-18 16:04:30 --> Config Class Initialized
INFO - 2020-03-18 16:04:30 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:04:30 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:04:30 --> Utf8 Class Initialized
INFO - 2020-03-18 16:04:30 --> URI Class Initialized
INFO - 2020-03-18 16:04:30 --> Router Class Initialized
INFO - 2020-03-18 16:04:30 --> Output Class Initialized
INFO - 2020-03-18 16:04:30 --> Security Class Initialized
DEBUG - 2020-03-18 16:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:04:30 --> Input Class Initialized
INFO - 2020-03-18 16:04:30 --> Language Class Initialized
INFO - 2020-03-18 16:04:30 --> Language Class Initialized
INFO - 2020-03-18 16:04:30 --> Config Class Initialized
INFO - 2020-03-18 16:04:30 --> Loader Class Initialized
INFO - 2020-03-18 16:04:30 --> Helper loaded: url_helper
INFO - 2020-03-18 16:04:30 --> Helper loaded: file_helper
INFO - 2020-03-18 16:04:30 --> Helper loaded: form_helper
INFO - 2020-03-18 16:04:30 --> Helper loaded: my_helper
INFO - 2020-03-18 16:04:30 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:04:31 --> Controller Class Initialized
DEBUG - 2020-03-18 16:04:31 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_ubah_password.php
DEBUG - 2020-03-18 16:04:31 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:04:31 --> Final output sent to browser
DEBUG - 2020-03-18 16:04:31 --> Total execution time: 0.8611
INFO - 2020-03-18 16:04:31 --> Config Class Initialized
INFO - 2020-03-18 16:04:31 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:04:31 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:04:31 --> Utf8 Class Initialized
INFO - 2020-03-18 16:04:31 --> URI Class Initialized
DEBUG - 2020-03-18 16:04:31 --> No URI present. Default controller set.
INFO - 2020-03-18 16:04:31 --> Router Class Initialized
INFO - 2020-03-18 16:04:31 --> Output Class Initialized
INFO - 2020-03-18 16:04:31 --> Security Class Initialized
DEBUG - 2020-03-18 16:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:04:31 --> Input Class Initialized
INFO - 2020-03-18 16:04:31 --> Language Class Initialized
INFO - 2020-03-18 16:04:31 --> Language Class Initialized
INFO - 2020-03-18 16:04:31 --> Config Class Initialized
INFO - 2020-03-18 16:04:31 --> Loader Class Initialized
INFO - 2020-03-18 16:04:31 --> Helper loaded: url_helper
INFO - 2020-03-18 16:04:31 --> Helper loaded: file_helper
INFO - 2020-03-18 16:04:31 --> Helper loaded: form_helper
INFO - 2020-03-18 16:04:31 --> Helper loaded: my_helper
INFO - 2020-03-18 16:04:31 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:04:31 --> Controller Class Initialized
DEBUG - 2020-03-18 16:04:31 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home_siswa.php
DEBUG - 2020-03-18 16:04:31 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:04:31 --> Final output sent to browser
DEBUG - 2020-03-18 16:04:32 --> Total execution time: 0.6399
INFO - 2020-03-18 16:04:39 --> Config Class Initialized
INFO - 2020-03-18 16:04:39 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:04:39 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:04:39 --> Utf8 Class Initialized
INFO - 2020-03-18 16:04:39 --> URI Class Initialized
INFO - 2020-03-18 16:04:39 --> Router Class Initialized
INFO - 2020-03-18 16:04:39 --> Output Class Initialized
INFO - 2020-03-18 16:04:39 --> Security Class Initialized
DEBUG - 2020-03-18 16:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:04:39 --> Input Class Initialized
INFO - 2020-03-18 16:04:39 --> Language Class Initialized
INFO - 2020-03-18 16:04:39 --> Language Class Initialized
INFO - 2020-03-18 16:04:39 --> Config Class Initialized
INFO - 2020-03-18 16:04:39 --> Loader Class Initialized
INFO - 2020-03-18 16:04:39 --> Helper loaded: url_helper
INFO - 2020-03-18 16:04:39 --> Helper loaded: file_helper
INFO - 2020-03-18 16:04:39 --> Helper loaded: form_helper
INFO - 2020-03-18 16:04:39 --> Helper loaded: my_helper
INFO - 2020-03-18 16:04:39 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:04:40 --> Controller Class Initialized
DEBUG - 2020-03-18 16:04:40 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_ubah_password.php
DEBUG - 2020-03-18 16:04:40 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:04:40 --> Final output sent to browser
DEBUG - 2020-03-18 16:04:40 --> Total execution time: 0.6417
INFO - 2020-03-18 16:04:47 --> Config Class Initialized
INFO - 2020-03-18 16:04:47 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:04:47 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:04:47 --> Utf8 Class Initialized
INFO - 2020-03-18 16:04:47 --> URI Class Initialized
DEBUG - 2020-03-18 16:04:47 --> No URI present. Default controller set.
INFO - 2020-03-18 16:04:47 --> Router Class Initialized
INFO - 2020-03-18 16:04:47 --> Output Class Initialized
INFO - 2020-03-18 16:04:47 --> Security Class Initialized
DEBUG - 2020-03-18 16:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:04:47 --> Input Class Initialized
INFO - 2020-03-18 16:04:47 --> Language Class Initialized
INFO - 2020-03-18 16:04:47 --> Language Class Initialized
INFO - 2020-03-18 16:04:47 --> Config Class Initialized
INFO - 2020-03-18 16:04:47 --> Loader Class Initialized
INFO - 2020-03-18 16:04:47 --> Helper loaded: url_helper
INFO - 2020-03-18 16:04:47 --> Helper loaded: file_helper
INFO - 2020-03-18 16:04:47 --> Helper loaded: form_helper
INFO - 2020-03-18 16:04:47 --> Helper loaded: my_helper
INFO - 2020-03-18 16:04:47 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:04:48 --> Controller Class Initialized
DEBUG - 2020-03-18 16:04:48 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home_siswa.php
DEBUG - 2020-03-18 16:04:48 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:04:48 --> Final output sent to browser
DEBUG - 2020-03-18 16:04:48 --> Total execution time: 0.6775
INFO - 2020-03-18 16:04:54 --> Config Class Initialized
INFO - 2020-03-18 16:04:54 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:04:54 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:04:54 --> Utf8 Class Initialized
INFO - 2020-03-18 16:04:55 --> URI Class Initialized
INFO - 2020-03-18 16:04:55 --> Router Class Initialized
INFO - 2020-03-18 16:04:55 --> Output Class Initialized
INFO - 2020-03-18 16:04:55 --> Security Class Initialized
DEBUG - 2020-03-18 16:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:04:55 --> Input Class Initialized
INFO - 2020-03-18 16:04:55 --> Language Class Initialized
INFO - 2020-03-18 16:04:55 --> Language Class Initialized
INFO - 2020-03-18 16:04:55 --> Config Class Initialized
INFO - 2020-03-18 16:04:55 --> Loader Class Initialized
INFO - 2020-03-18 16:04:55 --> Helper loaded: url_helper
INFO - 2020-03-18 16:04:55 --> Helper loaded: file_helper
INFO - 2020-03-18 16:04:55 --> Helper loaded: form_helper
INFO - 2020-03-18 16:04:55 --> Helper loaded: my_helper
INFO - 2020-03-18 16:04:55 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:04:55 --> Controller Class Initialized
DEBUG - 2020-03-18 16:04:55 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_ubah_password.php
DEBUG - 2020-03-18 16:04:55 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:04:55 --> Final output sent to browser
DEBUG - 2020-03-18 16:04:55 --> Total execution time: 0.6354
INFO - 2020-03-18 16:09:10 --> Config Class Initialized
INFO - 2020-03-18 16:09:10 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:09:10 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:09:10 --> Utf8 Class Initialized
INFO - 2020-03-18 16:09:10 --> URI Class Initialized
INFO - 2020-03-18 16:09:10 --> Router Class Initialized
INFO - 2020-03-18 16:09:10 --> Output Class Initialized
INFO - 2020-03-18 16:09:10 --> Security Class Initialized
DEBUG - 2020-03-18 16:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:09:10 --> Input Class Initialized
INFO - 2020-03-18 16:09:10 --> Language Class Initialized
INFO - 2020-03-18 16:09:10 --> Language Class Initialized
INFO - 2020-03-18 16:09:10 --> Config Class Initialized
INFO - 2020-03-18 16:09:10 --> Loader Class Initialized
INFO - 2020-03-18 16:09:10 --> Helper loaded: url_helper
INFO - 2020-03-18 16:09:10 --> Helper loaded: file_helper
INFO - 2020-03-18 16:09:10 --> Helper loaded: form_helper
INFO - 2020-03-18 16:09:10 --> Helper loaded: my_helper
INFO - 2020-03-18 16:09:10 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:09:10 --> Controller Class Initialized
DEBUG - 2020-03-18 16:09:10 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_ubah_password.php
DEBUG - 2020-03-18 16:09:11 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:09:11 --> Final output sent to browser
DEBUG - 2020-03-18 16:09:11 --> Total execution time: 0.8442
INFO - 2020-03-18 16:09:21 --> Config Class Initialized
INFO - 2020-03-18 16:09:21 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:09:21 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:09:21 --> Utf8 Class Initialized
INFO - 2020-03-18 16:09:21 --> URI Class Initialized
DEBUG - 2020-03-18 16:09:21 --> No URI present. Default controller set.
INFO - 2020-03-18 16:09:21 --> Router Class Initialized
INFO - 2020-03-18 16:09:21 --> Output Class Initialized
INFO - 2020-03-18 16:09:21 --> Security Class Initialized
DEBUG - 2020-03-18 16:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:09:21 --> Input Class Initialized
INFO - 2020-03-18 16:09:21 --> Language Class Initialized
INFO - 2020-03-18 16:09:21 --> Language Class Initialized
INFO - 2020-03-18 16:09:21 --> Config Class Initialized
INFO - 2020-03-18 16:09:21 --> Loader Class Initialized
INFO - 2020-03-18 16:09:21 --> Helper loaded: url_helper
INFO - 2020-03-18 16:09:21 --> Helper loaded: file_helper
INFO - 2020-03-18 16:09:21 --> Helper loaded: form_helper
INFO - 2020-03-18 16:09:21 --> Helper loaded: my_helper
INFO - 2020-03-18 16:09:21 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:09:21 --> Controller Class Initialized
DEBUG - 2020-03-18 16:09:21 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home_siswa.php
DEBUG - 2020-03-18 16:09:21 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:09:21 --> Final output sent to browser
DEBUG - 2020-03-18 16:09:22 --> Total execution time: 0.7392
INFO - 2020-03-18 16:10:53 --> Config Class Initialized
INFO - 2020-03-18 16:10:53 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:10:53 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:10:53 --> Utf8 Class Initialized
INFO - 2020-03-18 16:10:53 --> URI Class Initialized
INFO - 2020-03-18 16:10:53 --> Router Class Initialized
INFO - 2020-03-18 16:10:53 --> Output Class Initialized
INFO - 2020-03-18 16:10:53 --> Security Class Initialized
DEBUG - 2020-03-18 16:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:10:53 --> Input Class Initialized
INFO - 2020-03-18 16:10:53 --> Language Class Initialized
INFO - 2020-03-18 16:10:53 --> Language Class Initialized
INFO - 2020-03-18 16:10:53 --> Config Class Initialized
INFO - 2020-03-18 16:10:53 --> Loader Class Initialized
INFO - 2020-03-18 16:10:53 --> Helper loaded: url_helper
INFO - 2020-03-18 16:10:53 --> Helper loaded: file_helper
INFO - 2020-03-18 16:10:53 --> Helper loaded: form_helper
INFO - 2020-03-18 16:10:53 --> Helper loaded: my_helper
INFO - 2020-03-18 16:10:53 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:10:53 --> Controller Class Initialized
INFO - 2020-03-18 16:10:53 --> Helper loaded: cookie_helper
INFO - 2020-03-18 16:10:53 --> Config Class Initialized
INFO - 2020-03-18 16:10:53 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:10:53 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:10:53 --> Utf8 Class Initialized
INFO - 2020-03-18 16:10:53 --> URI Class Initialized
INFO - 2020-03-18 16:10:53 --> Router Class Initialized
INFO - 2020-03-18 16:10:53 --> Output Class Initialized
INFO - 2020-03-18 16:10:53 --> Security Class Initialized
DEBUG - 2020-03-18 16:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:10:54 --> Input Class Initialized
INFO - 2020-03-18 16:10:54 --> Language Class Initialized
INFO - 2020-03-18 16:10:54 --> Language Class Initialized
INFO - 2020-03-18 16:10:54 --> Config Class Initialized
INFO - 2020-03-18 16:10:54 --> Loader Class Initialized
INFO - 2020-03-18 16:10:54 --> Helper loaded: url_helper
INFO - 2020-03-18 16:10:54 --> Helper loaded: file_helper
INFO - 2020-03-18 16:10:54 --> Helper loaded: form_helper
INFO - 2020-03-18 16:10:54 --> Helper loaded: my_helper
INFO - 2020-03-18 16:10:54 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:10:54 --> Controller Class Initialized
INFO - 2020-03-18 16:10:54 --> Config Class Initialized
INFO - 2020-03-18 16:10:54 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:10:54 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:10:54 --> Utf8 Class Initialized
INFO - 2020-03-18 16:10:54 --> URI Class Initialized
INFO - 2020-03-18 16:10:54 --> Router Class Initialized
INFO - 2020-03-18 16:10:54 --> Output Class Initialized
INFO - 2020-03-18 16:10:54 --> Security Class Initialized
DEBUG - 2020-03-18 16:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:10:54 --> Input Class Initialized
INFO - 2020-03-18 16:10:54 --> Language Class Initialized
INFO - 2020-03-18 16:10:54 --> Language Class Initialized
INFO - 2020-03-18 16:10:54 --> Config Class Initialized
INFO - 2020-03-18 16:10:54 --> Loader Class Initialized
INFO - 2020-03-18 16:10:54 --> Helper loaded: url_helper
INFO - 2020-03-18 16:10:54 --> Helper loaded: file_helper
INFO - 2020-03-18 16:10:54 --> Helper loaded: form_helper
INFO - 2020-03-18 16:10:54 --> Helper loaded: my_helper
INFO - 2020-03-18 16:10:54 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:10:54 --> Controller Class Initialized
DEBUG - 2020-03-18 16:10:54 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 16:10:54 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:10:55 --> Final output sent to browser
DEBUG - 2020-03-18 16:10:55 --> Total execution time: 0.6136
INFO - 2020-03-18 16:11:19 --> Config Class Initialized
INFO - 2020-03-18 16:11:19 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:11:19 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:11:19 --> Utf8 Class Initialized
INFO - 2020-03-18 16:11:19 --> URI Class Initialized
INFO - 2020-03-18 16:11:19 --> Router Class Initialized
INFO - 2020-03-18 16:11:19 --> Output Class Initialized
INFO - 2020-03-18 16:11:19 --> Security Class Initialized
DEBUG - 2020-03-18 16:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:11:19 --> Input Class Initialized
INFO - 2020-03-18 16:11:19 --> Language Class Initialized
INFO - 2020-03-18 16:11:19 --> Language Class Initialized
INFO - 2020-03-18 16:11:19 --> Config Class Initialized
INFO - 2020-03-18 16:11:19 --> Loader Class Initialized
INFO - 2020-03-18 16:11:19 --> Helper loaded: url_helper
INFO - 2020-03-18 16:11:19 --> Helper loaded: file_helper
INFO - 2020-03-18 16:11:19 --> Helper loaded: form_helper
INFO - 2020-03-18 16:11:19 --> Helper loaded: my_helper
INFO - 2020-03-18 16:11:20 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:11:20 --> Controller Class Initialized
INFO - 2020-03-18 16:11:20 --> Helper loaded: cookie_helper
INFO - 2020-03-18 16:11:20 --> Final output sent to browser
DEBUG - 2020-03-18 16:11:20 --> Total execution time: 0.7716
INFO - 2020-03-18 16:11:20 --> Config Class Initialized
INFO - 2020-03-18 16:11:20 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:11:20 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:11:20 --> Utf8 Class Initialized
INFO - 2020-03-18 16:11:20 --> URI Class Initialized
INFO - 2020-03-18 16:11:20 --> Router Class Initialized
INFO - 2020-03-18 16:11:20 --> Output Class Initialized
INFO - 2020-03-18 16:11:20 --> Security Class Initialized
DEBUG - 2020-03-18 16:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:11:21 --> Input Class Initialized
INFO - 2020-03-18 16:11:21 --> Language Class Initialized
INFO - 2020-03-18 16:11:21 --> Language Class Initialized
INFO - 2020-03-18 16:11:21 --> Config Class Initialized
INFO - 2020-03-18 16:11:21 --> Loader Class Initialized
INFO - 2020-03-18 16:11:21 --> Helper loaded: url_helper
INFO - 2020-03-18 16:11:21 --> Helper loaded: file_helper
INFO - 2020-03-18 16:11:21 --> Helper loaded: form_helper
INFO - 2020-03-18 16:11:21 --> Helper loaded: my_helper
INFO - 2020-03-18 16:11:21 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:11:21 --> Controller Class Initialized
DEBUG - 2020-03-18 16:11:21 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-18 16:11:21 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:11:21 --> Final output sent to browser
DEBUG - 2020-03-18 16:11:22 --> Total execution time: 1.3818
INFO - 2020-03-18 16:11:42 --> Config Class Initialized
INFO - 2020-03-18 16:11:42 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:11:42 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:11:42 --> Utf8 Class Initialized
INFO - 2020-03-18 16:11:42 --> URI Class Initialized
INFO - 2020-03-18 16:11:42 --> Router Class Initialized
INFO - 2020-03-18 16:11:42 --> Output Class Initialized
INFO - 2020-03-18 16:11:42 --> Security Class Initialized
DEBUG - 2020-03-18 16:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:11:43 --> Input Class Initialized
INFO - 2020-03-18 16:11:43 --> Language Class Initialized
INFO - 2020-03-18 16:11:43 --> Language Class Initialized
INFO - 2020-03-18 16:11:43 --> Config Class Initialized
INFO - 2020-03-18 16:11:43 --> Loader Class Initialized
INFO - 2020-03-18 16:11:43 --> Helper loaded: url_helper
INFO - 2020-03-18 16:11:43 --> Helper loaded: file_helper
INFO - 2020-03-18 16:11:43 --> Helper loaded: form_helper
INFO - 2020-03-18 16:11:43 --> Helper loaded: my_helper
INFO - 2020-03-18 16:11:43 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:11:43 --> Controller Class Initialized
DEBUG - 2020-03-18 16:11:43 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_guru/views/list.php
DEBUG - 2020-03-18 16:11:43 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:11:43 --> Final output sent to browser
DEBUG - 2020-03-18 16:11:44 --> Total execution time: 1.2448
INFO - 2020-03-18 16:11:45 --> Config Class Initialized
INFO - 2020-03-18 16:11:45 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:11:45 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:11:45 --> Utf8 Class Initialized
INFO - 2020-03-18 16:11:45 --> URI Class Initialized
INFO - 2020-03-18 16:11:45 --> Router Class Initialized
INFO - 2020-03-18 16:11:45 --> Output Class Initialized
INFO - 2020-03-18 16:11:45 --> Security Class Initialized
DEBUG - 2020-03-18 16:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:11:45 --> Input Class Initialized
INFO - 2020-03-18 16:11:45 --> Language Class Initialized
INFO - 2020-03-18 16:11:45 --> Language Class Initialized
INFO - 2020-03-18 16:11:45 --> Config Class Initialized
INFO - 2020-03-18 16:11:45 --> Loader Class Initialized
INFO - 2020-03-18 16:11:45 --> Helper loaded: url_helper
INFO - 2020-03-18 16:11:45 --> Helper loaded: file_helper
INFO - 2020-03-18 16:11:45 --> Helper loaded: form_helper
INFO - 2020-03-18 16:11:45 --> Helper loaded: my_helper
INFO - 2020-03-18 16:11:45 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:11:45 --> Controller Class Initialized
INFO - 2020-03-18 16:11:57 --> Config Class Initialized
INFO - 2020-03-18 16:11:57 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:11:57 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:11:57 --> Utf8 Class Initialized
INFO - 2020-03-18 16:11:57 --> URI Class Initialized
INFO - 2020-03-18 16:11:58 --> Router Class Initialized
INFO - 2020-03-18 16:11:58 --> Output Class Initialized
INFO - 2020-03-18 16:11:58 --> Security Class Initialized
DEBUG - 2020-03-18 16:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:11:58 --> Input Class Initialized
INFO - 2020-03-18 16:11:58 --> Language Class Initialized
INFO - 2020-03-18 16:11:58 --> Language Class Initialized
INFO - 2020-03-18 16:11:58 --> Config Class Initialized
INFO - 2020-03-18 16:11:58 --> Loader Class Initialized
INFO - 2020-03-18 16:11:58 --> Helper loaded: url_helper
INFO - 2020-03-18 16:11:58 --> Helper loaded: file_helper
INFO - 2020-03-18 16:11:58 --> Helper loaded: form_helper
INFO - 2020-03-18 16:11:58 --> Helper loaded: my_helper
INFO - 2020-03-18 16:11:58 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:11:58 --> Controller Class Initialized
DEBUG - 2020-03-18 16:11:58 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_siswa/views/list.php
DEBUG - 2020-03-18 16:11:58 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:11:58 --> Final output sent to browser
DEBUG - 2020-03-18 16:11:59 --> Total execution time: 1.2353
INFO - 2020-03-18 16:12:00 --> Config Class Initialized
INFO - 2020-03-18 16:12:00 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:12:00 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:12:00 --> Utf8 Class Initialized
INFO - 2020-03-18 16:12:00 --> URI Class Initialized
INFO - 2020-03-18 16:12:00 --> Router Class Initialized
INFO - 2020-03-18 16:12:00 --> Output Class Initialized
INFO - 2020-03-18 16:12:00 --> Security Class Initialized
DEBUG - 2020-03-18 16:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:12:00 --> Input Class Initialized
INFO - 2020-03-18 16:12:00 --> Language Class Initialized
INFO - 2020-03-18 16:12:01 --> Language Class Initialized
INFO - 2020-03-18 16:12:01 --> Config Class Initialized
INFO - 2020-03-18 16:12:01 --> Loader Class Initialized
INFO - 2020-03-18 16:12:01 --> Helper loaded: url_helper
INFO - 2020-03-18 16:12:01 --> Helper loaded: file_helper
INFO - 2020-03-18 16:12:01 --> Helper loaded: form_helper
INFO - 2020-03-18 16:12:01 --> Helper loaded: my_helper
INFO - 2020-03-18 16:12:01 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:12:01 --> Controller Class Initialized
INFO - 2020-03-18 16:12:15 --> Config Class Initialized
INFO - 2020-03-18 16:12:15 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:12:15 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:12:15 --> Utf8 Class Initialized
INFO - 2020-03-18 16:12:15 --> URI Class Initialized
INFO - 2020-03-18 16:12:15 --> Router Class Initialized
INFO - 2020-03-18 16:12:15 --> Output Class Initialized
INFO - 2020-03-18 16:12:15 --> Security Class Initialized
DEBUG - 2020-03-18 16:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:12:15 --> Input Class Initialized
INFO - 2020-03-18 16:12:15 --> Language Class Initialized
INFO - 2020-03-18 16:12:15 --> Language Class Initialized
INFO - 2020-03-18 16:12:15 --> Config Class Initialized
INFO - 2020-03-18 16:12:15 --> Loader Class Initialized
INFO - 2020-03-18 16:12:15 --> Helper loaded: url_helper
INFO - 2020-03-18 16:12:15 --> Helper loaded: file_helper
INFO - 2020-03-18 16:12:15 --> Helper loaded: form_helper
INFO - 2020-03-18 16:12:15 --> Helper loaded: my_helper
INFO - 2020-03-18 16:12:15 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:12:15 --> Controller Class Initialized
DEBUG - 2020-03-18 16:12:15 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-03-18 16:12:15 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:12:15 --> Final output sent to browser
DEBUG - 2020-03-18 16:12:16 --> Total execution time: 0.9513
INFO - 2020-03-18 16:12:17 --> Config Class Initialized
INFO - 2020-03-18 16:12:17 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:12:17 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:12:17 --> Utf8 Class Initialized
INFO - 2020-03-18 16:12:17 --> URI Class Initialized
INFO - 2020-03-18 16:12:17 --> Router Class Initialized
INFO - 2020-03-18 16:12:17 --> Output Class Initialized
INFO - 2020-03-18 16:12:17 --> Security Class Initialized
DEBUG - 2020-03-18 16:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:12:17 --> Input Class Initialized
INFO - 2020-03-18 16:12:17 --> Language Class Initialized
INFO - 2020-03-18 16:12:17 --> Language Class Initialized
INFO - 2020-03-18 16:12:17 --> Config Class Initialized
INFO - 2020-03-18 16:12:17 --> Loader Class Initialized
INFO - 2020-03-18 16:12:17 --> Helper loaded: url_helper
INFO - 2020-03-18 16:12:17 --> Helper loaded: file_helper
INFO - 2020-03-18 16:12:18 --> Helper loaded: form_helper
INFO - 2020-03-18 16:12:18 --> Helper loaded: my_helper
INFO - 2020-03-18 16:12:18 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:12:18 --> Controller Class Initialized
INFO - 2020-03-18 16:12:35 --> Config Class Initialized
INFO - 2020-03-18 16:12:35 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:12:35 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:12:35 --> Utf8 Class Initialized
INFO - 2020-03-18 16:12:36 --> URI Class Initialized
INFO - 2020-03-18 16:12:36 --> Router Class Initialized
INFO - 2020-03-18 16:12:36 --> Output Class Initialized
INFO - 2020-03-18 16:12:36 --> Security Class Initialized
DEBUG - 2020-03-18 16:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:12:36 --> Input Class Initialized
INFO - 2020-03-18 16:12:36 --> Language Class Initialized
INFO - 2020-03-18 16:12:36 --> Language Class Initialized
INFO - 2020-03-18 16:12:36 --> Config Class Initialized
INFO - 2020-03-18 16:12:36 --> Loader Class Initialized
INFO - 2020-03-18 16:12:36 --> Helper loaded: url_helper
INFO - 2020-03-18 16:12:36 --> Helper loaded: file_helper
INFO - 2020-03-18 16:12:36 --> Helper loaded: form_helper
INFO - 2020-03-18 16:12:36 --> Helper loaded: my_helper
INFO - 2020-03-18 16:12:36 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:12:36 --> Controller Class Initialized
DEBUG - 2020-03-18 16:12:36 --> File loaded: D:\xampp\htdocs\myraport\application\modules/set_walikelas/views/list.php
DEBUG - 2020-03-18 16:12:36 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:12:37 --> Final output sent to browser
DEBUG - 2020-03-18 16:12:37 --> Total execution time: 1.4011
INFO - 2020-03-18 16:12:38 --> Config Class Initialized
INFO - 2020-03-18 16:12:38 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:12:38 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:12:38 --> Utf8 Class Initialized
INFO - 2020-03-18 16:12:38 --> URI Class Initialized
INFO - 2020-03-18 16:12:38 --> Router Class Initialized
INFO - 2020-03-18 16:12:38 --> Output Class Initialized
INFO - 2020-03-18 16:12:38 --> Security Class Initialized
DEBUG - 2020-03-18 16:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:12:38 --> Input Class Initialized
INFO - 2020-03-18 16:12:38 --> Language Class Initialized
INFO - 2020-03-18 16:12:38 --> Language Class Initialized
INFO - 2020-03-18 16:12:38 --> Config Class Initialized
INFO - 2020-03-18 16:12:38 --> Loader Class Initialized
INFO - 2020-03-18 16:12:38 --> Helper loaded: url_helper
INFO - 2020-03-18 16:12:38 --> Helper loaded: file_helper
INFO - 2020-03-18 16:12:38 --> Helper loaded: form_helper
INFO - 2020-03-18 16:12:38 --> Helper loaded: my_helper
INFO - 2020-03-18 16:12:38 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:12:38 --> Controller Class Initialized
INFO - 2020-03-18 16:12:46 --> Config Class Initialized
INFO - 2020-03-18 16:12:47 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:12:47 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:12:47 --> Utf8 Class Initialized
INFO - 2020-03-18 16:12:47 --> URI Class Initialized
INFO - 2020-03-18 16:12:47 --> Router Class Initialized
INFO - 2020-03-18 16:12:47 --> Output Class Initialized
INFO - 2020-03-18 16:12:47 --> Security Class Initialized
DEBUG - 2020-03-18 16:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:12:47 --> Input Class Initialized
INFO - 2020-03-18 16:12:47 --> Language Class Initialized
INFO - 2020-03-18 16:12:47 --> Language Class Initialized
INFO - 2020-03-18 16:12:47 --> Config Class Initialized
INFO - 2020-03-18 16:12:47 --> Loader Class Initialized
INFO - 2020-03-18 16:12:47 --> Helper loaded: url_helper
INFO - 2020-03-18 16:12:47 --> Helper loaded: file_helper
INFO - 2020-03-18 16:12:47 --> Helper loaded: form_helper
INFO - 2020-03-18 16:12:47 --> Helper loaded: my_helper
INFO - 2020-03-18 16:12:47 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:12:48 --> Controller Class Initialized
DEBUG - 2020-03-18 16:12:48 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_mapel/views/list.php
DEBUG - 2020-03-18 16:12:48 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:12:48 --> Final output sent to browser
DEBUG - 2020-03-18 16:12:48 --> Total execution time: 1.4726
INFO - 2020-03-18 16:12:49 --> Config Class Initialized
INFO - 2020-03-18 16:12:49 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:12:49 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:12:49 --> Utf8 Class Initialized
INFO - 2020-03-18 16:12:49 --> URI Class Initialized
INFO - 2020-03-18 16:12:49 --> Router Class Initialized
INFO - 2020-03-18 16:12:49 --> Output Class Initialized
INFO - 2020-03-18 16:12:50 --> Security Class Initialized
DEBUG - 2020-03-18 16:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:12:50 --> Input Class Initialized
INFO - 2020-03-18 16:12:50 --> Language Class Initialized
INFO - 2020-03-18 16:12:50 --> Language Class Initialized
INFO - 2020-03-18 16:12:50 --> Config Class Initialized
INFO - 2020-03-18 16:12:50 --> Loader Class Initialized
INFO - 2020-03-18 16:12:50 --> Helper loaded: url_helper
INFO - 2020-03-18 16:12:50 --> Helper loaded: file_helper
INFO - 2020-03-18 16:12:50 --> Helper loaded: form_helper
INFO - 2020-03-18 16:12:50 --> Helper loaded: my_helper
INFO - 2020-03-18 16:12:50 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:12:50 --> Controller Class Initialized
INFO - 2020-03-18 16:13:04 --> Config Class Initialized
INFO - 2020-03-18 16:13:05 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:13:05 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:13:05 --> Utf8 Class Initialized
INFO - 2020-03-18 16:13:05 --> URI Class Initialized
INFO - 2020-03-18 16:13:05 --> Router Class Initialized
INFO - 2020-03-18 16:13:05 --> Output Class Initialized
INFO - 2020-03-18 16:13:05 --> Security Class Initialized
DEBUG - 2020-03-18 16:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:13:05 --> Input Class Initialized
INFO - 2020-03-18 16:13:05 --> Language Class Initialized
INFO - 2020-03-18 16:13:06 --> Language Class Initialized
INFO - 2020-03-18 16:13:06 --> Config Class Initialized
INFO - 2020-03-18 16:13:06 --> Loader Class Initialized
INFO - 2020-03-18 16:13:06 --> Helper loaded: url_helper
INFO - 2020-03-18 16:13:06 --> Helper loaded: file_helper
INFO - 2020-03-18 16:13:06 --> Helper loaded: form_helper
INFO - 2020-03-18 16:13:06 --> Helper loaded: my_helper
INFO - 2020-03-18 16:13:06 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:13:06 --> Controller Class Initialized
DEBUG - 2020-03-18 16:13:06 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_ekstra/views/list.php
DEBUG - 2020-03-18 16:13:06 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:13:06 --> Final output sent to browser
DEBUG - 2020-03-18 16:13:07 --> Total execution time: 2.1959
INFO - 2020-03-18 16:13:08 --> Config Class Initialized
INFO - 2020-03-18 16:13:08 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:13:08 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:13:08 --> Utf8 Class Initialized
INFO - 2020-03-18 16:13:08 --> URI Class Initialized
INFO - 2020-03-18 16:13:08 --> Router Class Initialized
INFO - 2020-03-18 16:13:08 --> Output Class Initialized
INFO - 2020-03-18 16:13:08 --> Security Class Initialized
DEBUG - 2020-03-18 16:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:13:08 --> Input Class Initialized
INFO - 2020-03-18 16:13:08 --> Language Class Initialized
INFO - 2020-03-18 16:13:08 --> Language Class Initialized
INFO - 2020-03-18 16:13:09 --> Config Class Initialized
INFO - 2020-03-18 16:13:09 --> Loader Class Initialized
INFO - 2020-03-18 16:13:09 --> Helper loaded: url_helper
INFO - 2020-03-18 16:13:09 --> Helper loaded: file_helper
INFO - 2020-03-18 16:13:09 --> Helper loaded: form_helper
INFO - 2020-03-18 16:13:09 --> Helper loaded: my_helper
INFO - 2020-03-18 16:13:09 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:13:09 --> Controller Class Initialized
INFO - 2020-03-18 16:13:19 --> Config Class Initialized
INFO - 2020-03-18 16:13:20 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:13:20 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:13:20 --> Utf8 Class Initialized
INFO - 2020-03-18 16:13:20 --> URI Class Initialized
INFO - 2020-03-18 16:13:20 --> Router Class Initialized
INFO - 2020-03-18 16:13:20 --> Output Class Initialized
INFO - 2020-03-18 16:13:20 --> Security Class Initialized
DEBUG - 2020-03-18 16:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:13:20 --> Input Class Initialized
INFO - 2020-03-18 16:13:20 --> Language Class Initialized
INFO - 2020-03-18 16:13:20 --> Language Class Initialized
INFO - 2020-03-18 16:13:21 --> Config Class Initialized
INFO - 2020-03-18 16:13:21 --> Loader Class Initialized
INFO - 2020-03-18 16:13:21 --> Helper loaded: url_helper
INFO - 2020-03-18 16:13:21 --> Helper loaded: file_helper
INFO - 2020-03-18 16:13:21 --> Helper loaded: form_helper
INFO - 2020-03-18 16:13:21 --> Helper loaded: my_helper
INFO - 2020-03-18 16:13:21 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:13:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:13:21 --> Controller Class Initialized
DEBUG - 2020-03-18 16:13:21 --> File loaded: D:\xampp\htdocs\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-03-18 16:13:21 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:13:21 --> Final output sent to browser
DEBUG - 2020-03-18 16:13:22 --> Total execution time: 2.2061
INFO - 2020-03-18 16:13:23 --> Config Class Initialized
INFO - 2020-03-18 16:13:23 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:13:23 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:13:23 --> Utf8 Class Initialized
INFO - 2020-03-18 16:13:23 --> URI Class Initialized
INFO - 2020-03-18 16:13:23 --> Router Class Initialized
INFO - 2020-03-18 16:13:23 --> Output Class Initialized
INFO - 2020-03-18 16:13:23 --> Security Class Initialized
DEBUG - 2020-03-18 16:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:13:23 --> Input Class Initialized
INFO - 2020-03-18 16:13:23 --> Language Class Initialized
INFO - 2020-03-18 16:13:23 --> Language Class Initialized
INFO - 2020-03-18 16:13:23 --> Config Class Initialized
INFO - 2020-03-18 16:13:23 --> Loader Class Initialized
INFO - 2020-03-18 16:13:24 --> Helper loaded: url_helper
INFO - 2020-03-18 16:13:24 --> Helper loaded: file_helper
INFO - 2020-03-18 16:13:24 --> Helper loaded: form_helper
INFO - 2020-03-18 16:13:24 --> Helper loaded: my_helper
INFO - 2020-03-18 16:13:24 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:13:24 --> Controller Class Initialized
INFO - 2020-03-18 16:13:34 --> Config Class Initialized
INFO - 2020-03-18 16:13:35 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:13:35 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:13:35 --> Utf8 Class Initialized
INFO - 2020-03-18 16:13:35 --> URI Class Initialized
INFO - 2020-03-18 16:13:35 --> Router Class Initialized
INFO - 2020-03-18 16:13:36 --> Output Class Initialized
INFO - 2020-03-18 16:13:36 --> Security Class Initialized
DEBUG - 2020-03-18 16:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:13:36 --> Input Class Initialized
INFO - 2020-03-18 16:13:36 --> Language Class Initialized
INFO - 2020-03-18 16:13:36 --> Language Class Initialized
INFO - 2020-03-18 16:13:36 --> Config Class Initialized
INFO - 2020-03-18 16:13:36 --> Loader Class Initialized
INFO - 2020-03-18 16:13:36 --> Helper loaded: url_helper
INFO - 2020-03-18 16:13:36 --> Helper loaded: file_helper
INFO - 2020-03-18 16:13:37 --> Helper loaded: form_helper
INFO - 2020-03-18 16:13:37 --> Helper loaded: my_helper
INFO - 2020-03-18 16:13:37 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:13:37 --> Controller Class Initialized
DEBUG - 2020-03-18 16:13:37 --> File loaded: D:\xampp\htdocs\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-03-18 16:13:37 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:13:37 --> Final output sent to browser
DEBUG - 2020-03-18 16:13:38 --> Total execution time: 2.7255
INFO - 2020-03-18 16:13:40 --> Config Class Initialized
INFO - 2020-03-18 16:13:40 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:13:40 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:13:40 --> Utf8 Class Initialized
INFO - 2020-03-18 16:13:40 --> URI Class Initialized
INFO - 2020-03-18 16:13:40 --> Router Class Initialized
INFO - 2020-03-18 16:13:40 --> Output Class Initialized
INFO - 2020-03-18 16:13:40 --> Security Class Initialized
DEBUG - 2020-03-18 16:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:13:40 --> Input Class Initialized
INFO - 2020-03-18 16:13:40 --> Language Class Initialized
INFO - 2020-03-18 16:13:40 --> Language Class Initialized
INFO - 2020-03-18 16:13:40 --> Config Class Initialized
INFO - 2020-03-18 16:13:40 --> Loader Class Initialized
INFO - 2020-03-18 16:13:40 --> Helper loaded: url_helper
INFO - 2020-03-18 16:13:40 --> Helper loaded: file_helper
INFO - 2020-03-18 16:13:40 --> Helper loaded: form_helper
INFO - 2020-03-18 16:13:40 --> Helper loaded: my_helper
INFO - 2020-03-18 16:13:40 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:13:41 --> Controller Class Initialized
INFO - 2020-03-18 16:13:50 --> Config Class Initialized
INFO - 2020-03-18 16:13:50 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:13:50 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:13:50 --> Utf8 Class Initialized
INFO - 2020-03-18 16:13:51 --> URI Class Initialized
INFO - 2020-03-18 16:13:51 --> Router Class Initialized
INFO - 2020-03-18 16:13:51 --> Output Class Initialized
INFO - 2020-03-18 16:13:51 --> Security Class Initialized
DEBUG - 2020-03-18 16:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:13:51 --> Input Class Initialized
INFO - 2020-03-18 16:13:51 --> Language Class Initialized
INFO - 2020-03-18 16:13:51 --> Language Class Initialized
INFO - 2020-03-18 16:13:51 --> Config Class Initialized
INFO - 2020-03-18 16:13:51 --> Loader Class Initialized
INFO - 2020-03-18 16:13:51 --> Helper loaded: url_helper
INFO - 2020-03-18 16:13:51 --> Helper loaded: file_helper
INFO - 2020-03-18 16:13:51 --> Helper loaded: form_helper
INFO - 2020-03-18 16:13:52 --> Helper loaded: my_helper
INFO - 2020-03-18 16:13:52 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:13:52 --> Controller Class Initialized
DEBUG - 2020-03-18 16:13:52 --> File loaded: D:\xampp\htdocs\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-03-18 16:13:52 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:13:52 --> Final output sent to browser
DEBUG - 2020-03-18 16:13:53 --> Total execution time: 2.4005
INFO - 2020-03-18 16:13:54 --> Config Class Initialized
INFO - 2020-03-18 16:13:54 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:13:54 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:13:54 --> Utf8 Class Initialized
INFO - 2020-03-18 16:13:54 --> URI Class Initialized
INFO - 2020-03-18 16:13:54 --> Router Class Initialized
INFO - 2020-03-18 16:13:54 --> Output Class Initialized
INFO - 2020-03-18 16:13:54 --> Security Class Initialized
DEBUG - 2020-03-18 16:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:13:55 --> Input Class Initialized
INFO - 2020-03-18 16:13:55 --> Language Class Initialized
INFO - 2020-03-18 16:13:55 --> Config Class Initialized
INFO - 2020-03-18 16:13:55 --> Hooks Class Initialized
INFO - 2020-03-18 16:13:55 --> Language Class Initialized
INFO - 2020-03-18 16:13:55 --> Config Class Initialized
DEBUG - 2020-03-18 16:13:55 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:13:55 --> Utf8 Class Initialized
INFO - 2020-03-18 16:13:55 --> Loader Class Initialized
INFO - 2020-03-18 16:13:55 --> URI Class Initialized
INFO - 2020-03-18 16:13:55 --> Helper loaded: url_helper
INFO - 2020-03-18 16:13:55 --> Router Class Initialized
INFO - 2020-03-18 16:13:55 --> Helper loaded: file_helper
INFO - 2020-03-18 16:13:55 --> Output Class Initialized
INFO - 2020-03-18 16:13:55 --> Helper loaded: form_helper
INFO - 2020-03-18 16:13:56 --> Security Class Initialized
INFO - 2020-03-18 16:13:56 --> Helper loaded: my_helper
DEBUG - 2020-03-18 16:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:13:56 --> Database Driver Class Initialized
INFO - 2020-03-18 16:13:56 --> Input Class Initialized
DEBUG - 2020-03-18 16:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:13:56 --> Language Class Initialized
INFO - 2020-03-18 16:13:56 --> Controller Class Initialized
INFO - 2020-03-18 16:13:56 --> Language Class Initialized
INFO - 2020-03-18 16:13:56 --> Config Class Initialized
INFO - 2020-03-18 16:13:56 --> Loader Class Initialized
INFO - 2020-03-18 16:13:56 --> Helper loaded: url_helper
INFO - 2020-03-18 16:13:56 --> Helper loaded: file_helper
INFO - 2020-03-18 16:13:56 --> Helper loaded: form_helper
INFO - 2020-03-18 16:13:56 --> Helper loaded: my_helper
INFO - 2020-03-18 16:13:56 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:13:56 --> Controller Class Initialized
DEBUG - 2020-03-18 16:13:57 --> File loaded: D:\xampp\htdocs\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-03-18 16:13:57 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:13:57 --> Final output sent to browser
DEBUG - 2020-03-18 16:13:58 --> Total execution time: 1.5688
INFO - 2020-03-18 16:14:18 --> Config Class Initialized
INFO - 2020-03-18 16:14:18 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:14:18 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:14:18 --> Utf8 Class Initialized
INFO - 2020-03-18 16:14:18 --> URI Class Initialized
INFO - 2020-03-18 16:14:18 --> Router Class Initialized
INFO - 2020-03-18 16:14:18 --> Output Class Initialized
INFO - 2020-03-18 16:14:18 --> Security Class Initialized
DEBUG - 2020-03-18 16:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:14:19 --> Input Class Initialized
INFO - 2020-03-18 16:14:19 --> Language Class Initialized
INFO - 2020-03-18 16:14:19 --> Language Class Initialized
INFO - 2020-03-18 16:14:19 --> Config Class Initialized
INFO - 2020-03-18 16:14:19 --> Loader Class Initialized
INFO - 2020-03-18 16:14:19 --> Helper loaded: url_helper
INFO - 2020-03-18 16:14:19 --> Helper loaded: file_helper
INFO - 2020-03-18 16:14:19 --> Helper loaded: form_helper
INFO - 2020-03-18 16:14:19 --> Helper loaded: my_helper
INFO - 2020-03-18 16:14:20 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:14:20 --> Controller Class Initialized
DEBUG - 2020-03-18 16:14:20 --> File loaded: D:\xampp\htdocs\myraport\application\modules/set_mapel/views/list.php
DEBUG - 2020-03-18 16:14:20 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:14:20 --> Final output sent to browser
DEBUG - 2020-03-18 16:14:20 --> Total execution time: 2.3305
INFO - 2020-03-18 16:14:21 --> Config Class Initialized
INFO - 2020-03-18 16:14:21 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:14:22 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:14:22 --> Utf8 Class Initialized
INFO - 2020-03-18 16:14:22 --> URI Class Initialized
INFO - 2020-03-18 16:14:22 --> Router Class Initialized
INFO - 2020-03-18 16:14:22 --> Output Class Initialized
INFO - 2020-03-18 16:14:22 --> Security Class Initialized
DEBUG - 2020-03-18 16:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:14:22 --> Input Class Initialized
INFO - 2020-03-18 16:14:22 --> Language Class Initialized
INFO - 2020-03-18 16:14:22 --> Language Class Initialized
INFO - 2020-03-18 16:14:22 --> Config Class Initialized
INFO - 2020-03-18 16:14:22 --> Loader Class Initialized
INFO - 2020-03-18 16:14:22 --> Helper loaded: url_helper
INFO - 2020-03-18 16:14:22 --> Helper loaded: file_helper
INFO - 2020-03-18 16:14:22 --> Helper loaded: form_helper
INFO - 2020-03-18 16:14:22 --> Helper loaded: my_helper
INFO - 2020-03-18 16:14:22 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:14:22 --> Controller Class Initialized
INFO - 2020-03-18 16:14:37 --> Config Class Initialized
INFO - 2020-03-18 16:14:37 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:14:37 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:14:37 --> Utf8 Class Initialized
INFO - 2020-03-18 16:14:37 --> URI Class Initialized
INFO - 2020-03-18 16:14:37 --> Router Class Initialized
INFO - 2020-03-18 16:14:38 --> Output Class Initialized
INFO - 2020-03-18 16:14:38 --> Security Class Initialized
DEBUG - 2020-03-18 16:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:14:38 --> Input Class Initialized
INFO - 2020-03-18 16:14:38 --> Language Class Initialized
INFO - 2020-03-18 16:14:38 --> Language Class Initialized
INFO - 2020-03-18 16:14:38 --> Config Class Initialized
INFO - 2020-03-18 16:14:38 --> Loader Class Initialized
INFO - 2020-03-18 16:14:38 --> Helper loaded: url_helper
INFO - 2020-03-18 16:14:38 --> Helper loaded: file_helper
INFO - 2020-03-18 16:14:38 --> Helper loaded: form_helper
INFO - 2020-03-18 16:14:38 --> Helper loaded: my_helper
INFO - 2020-03-18 16:14:38 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:14:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:14:38 --> Controller Class Initialized
DEBUG - 2020-03-18 16:14:38 --> File loaded: D:\xampp\htdocs\myraport\application\modules/set_walikelas/views/list.php
DEBUG - 2020-03-18 16:14:38 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:14:38 --> Final output sent to browser
DEBUG - 2020-03-18 16:14:38 --> Total execution time: 1.3774
INFO - 2020-03-18 16:14:40 --> Config Class Initialized
INFO - 2020-03-18 16:14:40 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:14:40 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:14:40 --> Utf8 Class Initialized
INFO - 2020-03-18 16:14:40 --> URI Class Initialized
INFO - 2020-03-18 16:14:40 --> Router Class Initialized
INFO - 2020-03-18 16:14:40 --> Output Class Initialized
INFO - 2020-03-18 16:14:40 --> Security Class Initialized
DEBUG - 2020-03-18 16:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:14:40 --> Input Class Initialized
INFO - 2020-03-18 16:14:40 --> Language Class Initialized
INFO - 2020-03-18 16:14:40 --> Language Class Initialized
INFO - 2020-03-18 16:14:40 --> Config Class Initialized
INFO - 2020-03-18 16:14:40 --> Loader Class Initialized
INFO - 2020-03-18 16:14:40 --> Helper loaded: url_helper
INFO - 2020-03-18 16:14:40 --> Helper loaded: file_helper
INFO - 2020-03-18 16:14:40 --> Helper loaded: form_helper
INFO - 2020-03-18 16:14:40 --> Helper loaded: my_helper
INFO - 2020-03-18 16:14:40 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:14:40 --> Controller Class Initialized
INFO - 2020-03-18 16:14:52 --> Config Class Initialized
INFO - 2020-03-18 16:14:53 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:14:53 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:14:53 --> Utf8 Class Initialized
INFO - 2020-03-18 16:14:53 --> URI Class Initialized
INFO - 2020-03-18 16:14:53 --> Router Class Initialized
INFO - 2020-03-18 16:14:53 --> Output Class Initialized
INFO - 2020-03-18 16:14:53 --> Security Class Initialized
DEBUG - 2020-03-18 16:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:14:53 --> Input Class Initialized
INFO - 2020-03-18 16:14:53 --> Language Class Initialized
INFO - 2020-03-18 16:14:53 --> Language Class Initialized
INFO - 2020-03-18 16:14:53 --> Config Class Initialized
INFO - 2020-03-18 16:14:53 --> Loader Class Initialized
INFO - 2020-03-18 16:14:54 --> Helper loaded: url_helper
INFO - 2020-03-18 16:14:54 --> Helper loaded: file_helper
INFO - 2020-03-18 16:14:54 --> Helper loaded: form_helper
INFO - 2020-03-18 16:14:54 --> Helper loaded: my_helper
INFO - 2020-03-18 16:14:54 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:14:54 --> Controller Class Initialized
DEBUG - 2020-03-18 16:14:54 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_ubah_password.php
DEBUG - 2020-03-18 16:14:54 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:14:54 --> Final output sent to browser
DEBUG - 2020-03-18 16:14:55 --> Total execution time: 2.0413
INFO - 2020-03-18 16:15:12 --> Config Class Initialized
INFO - 2020-03-18 16:15:12 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:15:12 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:15:12 --> Utf8 Class Initialized
INFO - 2020-03-18 16:15:13 --> URI Class Initialized
INFO - 2020-03-18 16:15:13 --> Router Class Initialized
INFO - 2020-03-18 16:15:13 --> Output Class Initialized
INFO - 2020-03-18 16:15:13 --> Security Class Initialized
DEBUG - 2020-03-18 16:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:15:13 --> Input Class Initialized
INFO - 2020-03-18 16:15:13 --> Language Class Initialized
INFO - 2020-03-18 16:15:13 --> Language Class Initialized
INFO - 2020-03-18 16:15:13 --> Config Class Initialized
INFO - 2020-03-18 16:15:13 --> Loader Class Initialized
INFO - 2020-03-18 16:15:13 --> Helper loaded: url_helper
INFO - 2020-03-18 16:15:13 --> Helper loaded: file_helper
INFO - 2020-03-18 16:15:13 --> Helper loaded: form_helper
INFO - 2020-03-18 16:15:13 --> Helper loaded: my_helper
INFO - 2020-03-18 16:15:13 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:15:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:15:13 --> Controller Class Initialized
DEBUG - 2020-03-18 16:15:13 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-03-18 16:15:14 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:15:14 --> Final output sent to browser
DEBUG - 2020-03-18 16:15:14 --> Total execution time: 1.6467
INFO - 2020-03-18 16:15:15 --> Config Class Initialized
INFO - 2020-03-18 16:15:15 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:15:15 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:15:15 --> Utf8 Class Initialized
INFO - 2020-03-18 16:15:15 --> URI Class Initialized
INFO - 2020-03-18 16:15:15 --> Router Class Initialized
INFO - 2020-03-18 16:15:15 --> Output Class Initialized
INFO - 2020-03-18 16:15:15 --> Security Class Initialized
DEBUG - 2020-03-18 16:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:15:16 --> Input Class Initialized
INFO - 2020-03-18 16:15:16 --> Language Class Initialized
INFO - 2020-03-18 16:15:16 --> Language Class Initialized
INFO - 2020-03-18 16:15:16 --> Config Class Initialized
INFO - 2020-03-18 16:15:16 --> Loader Class Initialized
INFO - 2020-03-18 16:15:16 --> Helper loaded: url_helper
INFO - 2020-03-18 16:15:16 --> Helper loaded: file_helper
INFO - 2020-03-18 16:15:16 --> Helper loaded: form_helper
INFO - 2020-03-18 16:15:16 --> Helper loaded: my_helper
INFO - 2020-03-18 16:15:16 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:15:16 --> Controller Class Initialized
INFO - 2020-03-18 16:15:16 --> Config Class Initialized
INFO - 2020-03-18 16:15:17 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:15:17 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:15:17 --> Utf8 Class Initialized
INFO - 2020-03-18 16:15:17 --> URI Class Initialized
INFO - 2020-03-18 16:15:17 --> Router Class Initialized
INFO - 2020-03-18 16:15:17 --> Output Class Initialized
INFO - 2020-03-18 16:15:17 --> Security Class Initialized
DEBUG - 2020-03-18 16:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:15:18 --> Input Class Initialized
INFO - 2020-03-18 16:15:18 --> Language Class Initialized
INFO - 2020-03-18 16:15:18 --> Language Class Initialized
INFO - 2020-03-18 16:15:18 --> Config Class Initialized
INFO - 2020-03-18 16:15:18 --> Loader Class Initialized
INFO - 2020-03-18 16:15:18 --> Helper loaded: url_helper
INFO - 2020-03-18 16:15:18 --> Helper loaded: file_helper
INFO - 2020-03-18 16:15:18 --> Helper loaded: form_helper
INFO - 2020-03-18 16:15:18 --> Helper loaded: my_helper
INFO - 2020-03-18 16:15:18 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:15:18 --> Controller Class Initialized
DEBUG - 2020-03-18 16:15:18 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_guru/views/list.php
DEBUG - 2020-03-18 16:15:18 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:15:19 --> Final output sent to browser
DEBUG - 2020-03-18 16:15:19 --> Total execution time: 2.0532
INFO - 2020-03-18 16:15:20 --> Config Class Initialized
INFO - 2020-03-18 16:15:21 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:15:21 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:15:21 --> Utf8 Class Initialized
INFO - 2020-03-18 16:15:21 --> URI Class Initialized
INFO - 2020-03-18 16:15:21 --> Router Class Initialized
INFO - 2020-03-18 16:15:21 --> Output Class Initialized
INFO - 2020-03-18 16:15:21 --> Security Class Initialized
DEBUG - 2020-03-18 16:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:15:21 --> Input Class Initialized
INFO - 2020-03-18 16:15:21 --> Language Class Initialized
INFO - 2020-03-18 16:15:21 --> Language Class Initialized
INFO - 2020-03-18 16:15:21 --> Config Class Initialized
INFO - 2020-03-18 16:15:21 --> Loader Class Initialized
INFO - 2020-03-18 16:15:21 --> Helper loaded: url_helper
INFO - 2020-03-18 16:15:21 --> Helper loaded: file_helper
INFO - 2020-03-18 16:15:21 --> Helper loaded: form_helper
INFO - 2020-03-18 16:15:21 --> Helper loaded: my_helper
INFO - 2020-03-18 16:15:21 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:15:21 --> Controller Class Initialized
INFO - 2020-03-18 16:15:34 --> Config Class Initialized
INFO - 2020-03-18 16:15:34 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:15:34 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:15:34 --> Utf8 Class Initialized
INFO - 2020-03-18 16:15:34 --> URI Class Initialized
INFO - 2020-03-18 16:15:34 --> Router Class Initialized
INFO - 2020-03-18 16:15:34 --> Output Class Initialized
INFO - 2020-03-18 16:15:34 --> Security Class Initialized
DEBUG - 2020-03-18 16:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:15:35 --> Input Class Initialized
INFO - 2020-03-18 16:15:35 --> Language Class Initialized
INFO - 2020-03-18 16:15:35 --> Language Class Initialized
INFO - 2020-03-18 16:15:35 --> Config Class Initialized
INFO - 2020-03-18 16:15:35 --> Loader Class Initialized
INFO - 2020-03-18 16:15:35 --> Helper loaded: url_helper
INFO - 2020-03-18 16:15:35 --> Helper loaded: file_helper
INFO - 2020-03-18 16:15:35 --> Helper loaded: form_helper
INFO - 2020-03-18 16:15:35 --> Helper loaded: my_helper
INFO - 2020-03-18 16:15:35 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:15:35 --> Controller Class Initialized
INFO - 2020-03-18 16:15:36 --> Helper loaded: cookie_helper
INFO - 2020-03-18 16:15:36 --> Config Class Initialized
INFO - 2020-03-18 16:15:36 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:15:36 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:15:36 --> Utf8 Class Initialized
INFO - 2020-03-18 16:15:36 --> URI Class Initialized
INFO - 2020-03-18 16:15:36 --> Router Class Initialized
INFO - 2020-03-18 16:15:36 --> Output Class Initialized
INFO - 2020-03-18 16:15:36 --> Security Class Initialized
DEBUG - 2020-03-18 16:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:15:36 --> Input Class Initialized
INFO - 2020-03-18 16:15:36 --> Language Class Initialized
INFO - 2020-03-18 16:15:36 --> Language Class Initialized
INFO - 2020-03-18 16:15:36 --> Config Class Initialized
INFO - 2020-03-18 16:15:36 --> Loader Class Initialized
INFO - 2020-03-18 16:15:36 --> Helper loaded: url_helper
INFO - 2020-03-18 16:15:36 --> Helper loaded: file_helper
INFO - 2020-03-18 16:15:36 --> Helper loaded: form_helper
INFO - 2020-03-18 16:15:36 --> Helper loaded: my_helper
INFO - 2020-03-18 16:15:37 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:15:37 --> Controller Class Initialized
INFO - 2020-03-18 16:15:37 --> Config Class Initialized
INFO - 2020-03-18 16:15:37 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:15:37 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:15:37 --> Utf8 Class Initialized
INFO - 2020-03-18 16:15:37 --> URI Class Initialized
INFO - 2020-03-18 16:15:37 --> Router Class Initialized
INFO - 2020-03-18 16:15:37 --> Output Class Initialized
INFO - 2020-03-18 16:15:37 --> Security Class Initialized
DEBUG - 2020-03-18 16:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:15:37 --> Input Class Initialized
INFO - 2020-03-18 16:15:37 --> Language Class Initialized
INFO - 2020-03-18 16:15:37 --> Language Class Initialized
INFO - 2020-03-18 16:15:37 --> Config Class Initialized
INFO - 2020-03-18 16:15:37 --> Loader Class Initialized
INFO - 2020-03-18 16:15:38 --> Helper loaded: url_helper
INFO - 2020-03-18 16:15:38 --> Helper loaded: file_helper
INFO - 2020-03-18 16:15:38 --> Helper loaded: form_helper
INFO - 2020-03-18 16:15:38 --> Helper loaded: my_helper
INFO - 2020-03-18 16:15:38 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:15:38 --> Controller Class Initialized
DEBUG - 2020-03-18 16:15:38 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 16:15:38 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:15:38 --> Final output sent to browser
DEBUG - 2020-03-18 16:15:39 --> Total execution time: 1.2612
INFO - 2020-03-18 16:15:45 --> Config Class Initialized
INFO - 2020-03-18 16:15:45 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:15:45 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:15:45 --> Utf8 Class Initialized
INFO - 2020-03-18 16:15:45 --> URI Class Initialized
INFO - 2020-03-18 16:15:45 --> Router Class Initialized
INFO - 2020-03-18 16:15:45 --> Output Class Initialized
INFO - 2020-03-18 16:15:45 --> Security Class Initialized
DEBUG - 2020-03-18 16:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:15:45 --> Input Class Initialized
INFO - 2020-03-18 16:15:45 --> Language Class Initialized
INFO - 2020-03-18 16:15:45 --> Language Class Initialized
INFO - 2020-03-18 16:15:45 --> Config Class Initialized
INFO - 2020-03-18 16:15:45 --> Loader Class Initialized
INFO - 2020-03-18 16:15:45 --> Helper loaded: url_helper
INFO - 2020-03-18 16:15:45 --> Helper loaded: file_helper
INFO - 2020-03-18 16:15:45 --> Helper loaded: form_helper
INFO - 2020-03-18 16:15:45 --> Helper loaded: my_helper
INFO - 2020-03-18 16:15:45 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:15:45 --> Controller Class Initialized
INFO - 2020-03-18 16:15:45 --> Helper loaded: cookie_helper
INFO - 2020-03-18 16:15:45 --> Final output sent to browser
DEBUG - 2020-03-18 16:15:45 --> Total execution time: 0.7381
INFO - 2020-03-18 16:15:46 --> Config Class Initialized
INFO - 2020-03-18 16:15:46 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:15:47 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:15:47 --> Utf8 Class Initialized
INFO - 2020-03-18 16:15:47 --> URI Class Initialized
INFO - 2020-03-18 16:15:47 --> Router Class Initialized
INFO - 2020-03-18 16:15:47 --> Output Class Initialized
INFO - 2020-03-18 16:15:47 --> Security Class Initialized
DEBUG - 2020-03-18 16:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:15:47 --> Input Class Initialized
INFO - 2020-03-18 16:15:47 --> Language Class Initialized
INFO - 2020-03-18 16:15:47 --> Language Class Initialized
INFO - 2020-03-18 16:15:48 --> Config Class Initialized
INFO - 2020-03-18 16:15:48 --> Loader Class Initialized
INFO - 2020-03-18 16:15:48 --> Helper loaded: url_helper
INFO - 2020-03-18 16:15:48 --> Helper loaded: file_helper
INFO - 2020-03-18 16:15:48 --> Helper loaded: form_helper
INFO - 2020-03-18 16:15:48 --> Helper loaded: my_helper
INFO - 2020-03-18 16:15:48 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:15:49 --> Controller Class Initialized
DEBUG - 2020-03-18 16:15:49 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-03-18 16:15:49 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:15:49 --> Final output sent to browser
DEBUG - 2020-03-18 16:15:53 --> Total execution time: 3.4134
INFO - 2020-03-18 16:16:27 --> Config Class Initialized
INFO - 2020-03-18 16:16:27 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:16:27 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:16:27 --> Utf8 Class Initialized
INFO - 2020-03-18 16:16:27 --> URI Class Initialized
INFO - 2020-03-18 16:16:27 --> Router Class Initialized
INFO - 2020-03-18 16:16:27 --> Output Class Initialized
INFO - 2020-03-18 16:16:27 --> Security Class Initialized
DEBUG - 2020-03-18 16:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:16:27 --> Input Class Initialized
INFO - 2020-03-18 16:16:27 --> Language Class Initialized
INFO - 2020-03-18 16:16:27 --> Language Class Initialized
INFO - 2020-03-18 16:16:27 --> Config Class Initialized
INFO - 2020-03-18 16:16:27 --> Loader Class Initialized
INFO - 2020-03-18 16:16:27 --> Helper loaded: url_helper
INFO - 2020-03-18 16:16:27 --> Helper loaded: file_helper
INFO - 2020-03-18 16:16:27 --> Helper loaded: form_helper
INFO - 2020-03-18 16:16:27 --> Helper loaded: my_helper
INFO - 2020-03-18 16:16:27 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:16:28 --> Controller Class Initialized
DEBUG - 2020-03-18 16:16:28 --> File loaded: D:\xampp\htdocs\myraport\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-03-18 16:16:28 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:16:28 --> Final output sent to browser
DEBUG - 2020-03-18 16:16:28 --> Total execution time: 0.8970
INFO - 2020-03-18 16:16:46 --> Config Class Initialized
INFO - 2020-03-18 16:16:46 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:16:46 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:16:46 --> Utf8 Class Initialized
INFO - 2020-03-18 16:16:46 --> URI Class Initialized
INFO - 2020-03-18 16:16:46 --> Router Class Initialized
INFO - 2020-03-18 16:16:46 --> Output Class Initialized
INFO - 2020-03-18 16:16:46 --> Security Class Initialized
DEBUG - 2020-03-18 16:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:16:46 --> Input Class Initialized
INFO - 2020-03-18 16:16:46 --> Language Class Initialized
INFO - 2020-03-18 16:16:46 --> Language Class Initialized
INFO - 2020-03-18 16:16:46 --> Config Class Initialized
INFO - 2020-03-18 16:16:46 --> Loader Class Initialized
INFO - 2020-03-18 16:16:46 --> Helper loaded: url_helper
INFO - 2020-03-18 16:16:46 --> Helper loaded: file_helper
INFO - 2020-03-18 16:16:46 --> Helper loaded: form_helper
INFO - 2020-03-18 16:16:46 --> Helper loaded: my_helper
INFO - 2020-03-18 16:16:46 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:16:46 --> Controller Class Initialized
DEBUG - 2020-03-18 16:16:46 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_ubah_password.php
DEBUG - 2020-03-18 16:16:46 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:16:46 --> Final output sent to browser
DEBUG - 2020-03-18 16:16:47 --> Total execution time: 0.9174
INFO - 2020-03-18 16:16:49 --> Config Class Initialized
INFO - 2020-03-18 16:16:49 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:16:49 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:16:49 --> Utf8 Class Initialized
INFO - 2020-03-18 16:16:49 --> URI Class Initialized
INFO - 2020-03-18 16:16:49 --> Router Class Initialized
INFO - 2020-03-18 16:16:49 --> Output Class Initialized
INFO - 2020-03-18 16:16:49 --> Security Class Initialized
DEBUG - 2020-03-18 16:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:16:50 --> Input Class Initialized
INFO - 2020-03-18 16:16:50 --> Language Class Initialized
INFO - 2020-03-18 16:16:50 --> Language Class Initialized
INFO - 2020-03-18 16:16:50 --> Config Class Initialized
INFO - 2020-03-18 16:16:50 --> Loader Class Initialized
INFO - 2020-03-18 16:16:50 --> Helper loaded: url_helper
INFO - 2020-03-18 16:16:50 --> Helper loaded: file_helper
INFO - 2020-03-18 16:16:50 --> Helper loaded: form_helper
INFO - 2020-03-18 16:16:50 --> Helper loaded: my_helper
INFO - 2020-03-18 16:16:50 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:16:50 --> Controller Class Initialized
DEBUG - 2020-03-18 16:16:50 --> File loaded: D:\xampp\htdocs\myraport\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-03-18 16:16:50 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:16:50 --> Final output sent to browser
DEBUG - 2020-03-18 16:16:50 --> Total execution time: 1.2015
INFO - 2020-03-18 16:17:05 --> Config Class Initialized
INFO - 2020-03-18 16:17:05 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:17:05 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:17:05 --> Utf8 Class Initialized
INFO - 2020-03-18 16:17:06 --> URI Class Initialized
INFO - 2020-03-18 16:17:06 --> Router Class Initialized
INFO - 2020-03-18 16:17:06 --> Output Class Initialized
INFO - 2020-03-18 16:17:06 --> Security Class Initialized
DEBUG - 2020-03-18 16:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:17:06 --> Input Class Initialized
INFO - 2020-03-18 16:17:06 --> Language Class Initialized
INFO - 2020-03-18 16:17:06 --> Language Class Initialized
INFO - 2020-03-18 16:17:06 --> Config Class Initialized
INFO - 2020-03-18 16:17:06 --> Loader Class Initialized
INFO - 2020-03-18 16:17:06 --> Helper loaded: url_helper
INFO - 2020-03-18 16:17:06 --> Helper loaded: file_helper
INFO - 2020-03-18 16:17:06 --> Helper loaded: form_helper
INFO - 2020-03-18 16:17:06 --> Helper loaded: my_helper
INFO - 2020-03-18 16:17:06 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:17:06 --> Controller Class Initialized
INFO - 2020-03-18 16:17:06 --> Helper loaded: cookie_helper
INFO - 2020-03-18 16:17:07 --> Config Class Initialized
INFO - 2020-03-18 16:17:07 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:17:07 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:17:07 --> Utf8 Class Initialized
INFO - 2020-03-18 16:17:07 --> URI Class Initialized
INFO - 2020-03-18 16:17:07 --> Router Class Initialized
INFO - 2020-03-18 16:17:07 --> Output Class Initialized
INFO - 2020-03-18 16:17:07 --> Security Class Initialized
DEBUG - 2020-03-18 16:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:17:07 --> Input Class Initialized
INFO - 2020-03-18 16:17:07 --> Language Class Initialized
INFO - 2020-03-18 16:17:07 --> Language Class Initialized
INFO - 2020-03-18 16:17:07 --> Config Class Initialized
INFO - 2020-03-18 16:17:07 --> Loader Class Initialized
INFO - 2020-03-18 16:17:07 --> Helper loaded: url_helper
INFO - 2020-03-18 16:17:07 --> Helper loaded: file_helper
INFO - 2020-03-18 16:17:07 --> Helper loaded: form_helper
INFO - 2020-03-18 16:17:07 --> Helper loaded: my_helper
INFO - 2020-03-18 16:17:07 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:17:07 --> Controller Class Initialized
INFO - 2020-03-18 16:17:07 --> Config Class Initialized
INFO - 2020-03-18 16:17:07 --> Hooks Class Initialized
DEBUG - 2020-03-18 16:17:07 --> UTF-8 Support Enabled
INFO - 2020-03-18 16:17:07 --> Utf8 Class Initialized
INFO - 2020-03-18 16:17:08 --> URI Class Initialized
INFO - 2020-03-18 16:17:08 --> Router Class Initialized
INFO - 2020-03-18 16:17:08 --> Output Class Initialized
INFO - 2020-03-18 16:17:08 --> Security Class Initialized
DEBUG - 2020-03-18 16:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 16:17:08 --> Input Class Initialized
INFO - 2020-03-18 16:17:08 --> Language Class Initialized
INFO - 2020-03-18 16:17:08 --> Language Class Initialized
INFO - 2020-03-18 16:17:08 --> Config Class Initialized
INFO - 2020-03-18 16:17:08 --> Loader Class Initialized
INFO - 2020-03-18 16:17:08 --> Helper loaded: url_helper
INFO - 2020-03-18 16:17:08 --> Helper loaded: file_helper
INFO - 2020-03-18 16:17:08 --> Helper loaded: form_helper
INFO - 2020-03-18 16:17:08 --> Helper loaded: my_helper
INFO - 2020-03-18 16:17:08 --> Database Driver Class Initialized
DEBUG - 2020-03-18 16:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-18 16:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-18 16:17:08 --> Controller Class Initialized
DEBUG - 2020-03-18 16:17:08 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-18 16:17:08 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-18 16:17:08 --> Final output sent to browser
DEBUG - 2020-03-18 16:17:09 --> Total execution time: 1.0762
