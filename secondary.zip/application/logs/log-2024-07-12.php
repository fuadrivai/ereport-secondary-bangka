<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-12 13:39:44 --> Config Class Initialized
INFO - 2024-07-12 13:39:44 --> Hooks Class Initialized
DEBUG - 2024-07-12 13:39:44 --> UTF-8 Support Enabled
INFO - 2024-07-12 13:39:44 --> Utf8 Class Initialized
INFO - 2024-07-12 13:39:44 --> URI Class Initialized
INFO - 2024-07-12 13:39:44 --> Router Class Initialized
INFO - 2024-07-12 13:39:44 --> Output Class Initialized
INFO - 2024-07-12 13:39:44 --> Security Class Initialized
DEBUG - 2024-07-12 13:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-12 13:39:44 --> Input Class Initialized
INFO - 2024-07-12 13:39:44 --> Language Class Initialized
INFO - 2024-07-12 13:39:44 --> Language Class Initialized
INFO - 2024-07-12 13:39:44 --> Config Class Initialized
INFO - 2024-07-12 13:39:44 --> Loader Class Initialized
INFO - 2024-07-12 13:39:44 --> Helper loaded: url_helper
INFO - 2024-07-12 13:39:44 --> Helper loaded: file_helper
INFO - 2024-07-12 13:39:44 --> Helper loaded: form_helper
INFO - 2024-07-12 13:39:44 --> Helper loaded: my_helper
INFO - 2024-07-12 13:39:44 --> Database Driver Class Initialized
INFO - 2024-07-12 13:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-12 13:39:44 --> Controller Class Initialized
DEBUG - 2024-07-12 13:39:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-07-12 13:39:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-12 13:39:45 --> Final output sent to browser
DEBUG - 2024-07-12 13:39:45 --> Total execution time: 0.3992
INFO - 2024-07-12 13:39:57 --> Config Class Initialized
INFO - 2024-07-12 13:39:57 --> Hooks Class Initialized
DEBUG - 2024-07-12 13:39:57 --> UTF-8 Support Enabled
INFO - 2024-07-12 13:39:57 --> Utf8 Class Initialized
INFO - 2024-07-12 13:39:57 --> URI Class Initialized
INFO - 2024-07-12 13:39:57 --> Router Class Initialized
INFO - 2024-07-12 13:39:57 --> Output Class Initialized
INFO - 2024-07-12 13:39:57 --> Security Class Initialized
DEBUG - 2024-07-12 13:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-12 13:39:57 --> Input Class Initialized
INFO - 2024-07-12 13:39:57 --> Language Class Initialized
INFO - 2024-07-12 13:39:57 --> Language Class Initialized
INFO - 2024-07-12 13:39:57 --> Config Class Initialized
INFO - 2024-07-12 13:39:57 --> Loader Class Initialized
INFO - 2024-07-12 13:39:57 --> Helper loaded: url_helper
INFO - 2024-07-12 13:39:57 --> Helper loaded: file_helper
INFO - 2024-07-12 13:39:57 --> Helper loaded: form_helper
INFO - 2024-07-12 13:39:57 --> Helper loaded: my_helper
INFO - 2024-07-12 13:39:57 --> Database Driver Class Initialized
INFO - 2024-07-12 13:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-12 13:39:57 --> Controller Class Initialized
INFO - 2024-07-12 13:39:57 --> Helper loaded: cookie_helper
INFO - 2024-07-12 13:39:57 --> Final output sent to browser
DEBUG - 2024-07-12 13:39:57 --> Total execution time: 0.1400
INFO - 2024-07-12 13:39:57 --> Config Class Initialized
INFO - 2024-07-12 13:39:57 --> Hooks Class Initialized
DEBUG - 2024-07-12 13:39:57 --> UTF-8 Support Enabled
INFO - 2024-07-12 13:39:57 --> Utf8 Class Initialized
INFO - 2024-07-12 13:39:57 --> URI Class Initialized
INFO - 2024-07-12 13:39:57 --> Router Class Initialized
INFO - 2024-07-12 13:39:57 --> Output Class Initialized
INFO - 2024-07-12 13:39:57 --> Security Class Initialized
DEBUG - 2024-07-12 13:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-12 13:39:57 --> Input Class Initialized
INFO - 2024-07-12 13:39:57 --> Language Class Initialized
INFO - 2024-07-12 13:39:57 --> Language Class Initialized
INFO - 2024-07-12 13:39:57 --> Config Class Initialized
INFO - 2024-07-12 13:39:57 --> Loader Class Initialized
INFO - 2024-07-12 13:39:57 --> Helper loaded: url_helper
INFO - 2024-07-12 13:39:57 --> Helper loaded: file_helper
INFO - 2024-07-12 13:39:57 --> Helper loaded: form_helper
INFO - 2024-07-12 13:39:57 --> Helper loaded: my_helper
INFO - 2024-07-12 13:39:57 --> Database Driver Class Initialized
INFO - 2024-07-12 13:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-12 13:39:57 --> Controller Class Initialized
DEBUG - 2024-07-12 13:39:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-07-12 13:39:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-12 13:39:57 --> Final output sent to browser
DEBUG - 2024-07-12 13:39:57 --> Total execution time: 0.0701
INFO - 2024-07-12 13:40:36 --> Config Class Initialized
INFO - 2024-07-12 13:40:36 --> Hooks Class Initialized
DEBUG - 2024-07-12 13:40:36 --> UTF-8 Support Enabled
INFO - 2024-07-12 13:40:36 --> Utf8 Class Initialized
INFO - 2024-07-12 13:40:36 --> URI Class Initialized
INFO - 2024-07-12 13:40:36 --> Router Class Initialized
INFO - 2024-07-12 13:40:36 --> Output Class Initialized
INFO - 2024-07-12 13:40:36 --> Security Class Initialized
DEBUG - 2024-07-12 13:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-12 13:40:36 --> Input Class Initialized
INFO - 2024-07-12 13:40:36 --> Language Class Initialized
INFO - 2024-07-12 13:40:36 --> Language Class Initialized
INFO - 2024-07-12 13:40:36 --> Config Class Initialized
INFO - 2024-07-12 13:40:36 --> Loader Class Initialized
INFO - 2024-07-12 13:40:36 --> Helper loaded: url_helper
INFO - 2024-07-12 13:40:36 --> Helper loaded: file_helper
INFO - 2024-07-12 13:40:36 --> Helper loaded: form_helper
INFO - 2024-07-12 13:40:36 --> Helper loaded: my_helper
INFO - 2024-07-12 13:40:36 --> Database Driver Class Initialized
INFO - 2024-07-12 13:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-12 13:40:36 --> Controller Class Initialized
DEBUG - 2024-07-12 13:40:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-07-12 13:40:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-12 13:40:36 --> Final output sent to browser
DEBUG - 2024-07-12 13:40:36 --> Total execution time: 0.0504
INFO - 2024-07-12 13:40:39 --> Config Class Initialized
INFO - 2024-07-12 13:40:39 --> Hooks Class Initialized
DEBUG - 2024-07-12 13:40:39 --> UTF-8 Support Enabled
INFO - 2024-07-12 13:40:39 --> Utf8 Class Initialized
INFO - 2024-07-12 13:40:39 --> URI Class Initialized
INFO - 2024-07-12 13:40:39 --> Router Class Initialized
INFO - 2024-07-12 13:40:39 --> Output Class Initialized
INFO - 2024-07-12 13:40:39 --> Security Class Initialized
DEBUG - 2024-07-12 13:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-12 13:40:39 --> Input Class Initialized
INFO - 2024-07-12 13:40:39 --> Language Class Initialized
INFO - 2024-07-12 13:40:39 --> Language Class Initialized
INFO - 2024-07-12 13:40:39 --> Config Class Initialized
INFO - 2024-07-12 13:40:39 --> Loader Class Initialized
INFO - 2024-07-12 13:40:39 --> Helper loaded: url_helper
INFO - 2024-07-12 13:40:39 --> Helper loaded: file_helper
INFO - 2024-07-12 13:40:39 --> Helper loaded: form_helper
INFO - 2024-07-12 13:40:39 --> Helper loaded: my_helper
INFO - 2024-07-12 13:40:39 --> Database Driver Class Initialized
INFO - 2024-07-12 13:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-12 13:40:39 --> Controller Class Initialized
DEBUG - 2024-07-12 13:40:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2024-07-12 13:40:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-12 13:40:39 --> Final output sent to browser
DEBUG - 2024-07-12 13:40:39 --> Total execution time: 0.0840
