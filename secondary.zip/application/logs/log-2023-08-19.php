<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-08-19 03:51:13 --> Config Class Initialized
INFO - 2023-08-19 03:51:13 --> Hooks Class Initialized
DEBUG - 2023-08-19 03:51:13 --> UTF-8 Support Enabled
INFO - 2023-08-19 03:51:13 --> Utf8 Class Initialized
INFO - 2023-08-19 03:51:13 --> URI Class Initialized
DEBUG - 2023-08-19 03:51:14 --> No URI present. Default controller set.
INFO - 2023-08-19 03:51:14 --> Router Class Initialized
INFO - 2023-08-19 03:51:14 --> Output Class Initialized
INFO - 2023-08-19 03:51:14 --> Security Class Initialized
DEBUG - 2023-08-19 03:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 03:51:14 --> Input Class Initialized
INFO - 2023-08-19 03:51:14 --> Language Class Initialized
INFO - 2023-08-19 03:51:14 --> Language Class Initialized
INFO - 2023-08-19 03:51:14 --> Config Class Initialized
INFO - 2023-08-19 03:51:14 --> Loader Class Initialized
INFO - 2023-08-19 03:51:14 --> Helper loaded: url_helper
INFO - 2023-08-19 03:51:14 --> Helper loaded: file_helper
INFO - 2023-08-19 03:51:14 --> Helper loaded: form_helper
INFO - 2023-08-19 03:51:14 --> Helper loaded: my_helper
INFO - 2023-08-19 03:51:14 --> Database Driver Class Initialized
DEBUG - 2023-08-19 03:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 03:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 03:51:14 --> Controller Class Initialized
DEBUG - 2023-08-19 03:51:14 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 03:51:14 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 03:51:14 --> Final output sent to browser
DEBUG - 2023-08-19 03:51:14 --> Total execution time: 0.8081
INFO - 2023-08-19 03:51:15 --> Config Class Initialized
INFO - 2023-08-19 03:51:15 --> Hooks Class Initialized
DEBUG - 2023-08-19 03:51:15 --> UTF-8 Support Enabled
INFO - 2023-08-19 03:51:15 --> Utf8 Class Initialized
INFO - 2023-08-19 03:51:15 --> URI Class Initialized
INFO - 2023-08-19 03:51:15 --> Router Class Initialized
INFO - 2023-08-19 03:51:15 --> Output Class Initialized
INFO - 2023-08-19 03:51:15 --> Security Class Initialized
DEBUG - 2023-08-19 03:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 03:51:15 --> Input Class Initialized
INFO - 2023-08-19 03:51:15 --> Language Class Initialized
INFO - 2023-08-19 03:51:15 --> Language Class Initialized
INFO - 2023-08-19 03:51:15 --> Config Class Initialized
INFO - 2023-08-19 03:51:15 --> Loader Class Initialized
INFO - 2023-08-19 03:51:15 --> Helper loaded: url_helper
INFO - 2023-08-19 03:51:15 --> Helper loaded: file_helper
INFO - 2023-08-19 03:51:15 --> Helper loaded: form_helper
INFO - 2023-08-19 03:51:15 --> Helper loaded: my_helper
INFO - 2023-08-19 03:51:15 --> Database Driver Class Initialized
DEBUG - 2023-08-19 03:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 03:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 03:51:15 --> Controller Class Initialized
DEBUG - 2023-08-19 03:51:15 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 03:51:15 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 03:51:15 --> Final output sent to browser
DEBUG - 2023-08-19 03:51:15 --> Total execution time: 0.1002
INFO - 2023-08-19 03:51:17 --> Config Class Initialized
INFO - 2023-08-19 03:51:17 --> Hooks Class Initialized
DEBUG - 2023-08-19 03:51:17 --> UTF-8 Support Enabled
INFO - 2023-08-19 03:51:17 --> Utf8 Class Initialized
INFO - 2023-08-19 03:51:17 --> URI Class Initialized
INFO - 2023-08-19 03:51:17 --> Router Class Initialized
INFO - 2023-08-19 03:51:17 --> Output Class Initialized
INFO - 2023-08-19 03:51:17 --> Security Class Initialized
DEBUG - 2023-08-19 03:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 03:51:17 --> Input Class Initialized
INFO - 2023-08-19 03:51:17 --> Language Class Initialized
INFO - 2023-08-19 03:51:17 --> Language Class Initialized
INFO - 2023-08-19 03:51:17 --> Config Class Initialized
INFO - 2023-08-19 03:51:17 --> Loader Class Initialized
INFO - 2023-08-19 03:51:17 --> Helper loaded: url_helper
INFO - 2023-08-19 03:51:17 --> Helper loaded: file_helper
INFO - 2023-08-19 03:51:17 --> Helper loaded: form_helper
INFO - 2023-08-19 03:51:17 --> Helper loaded: my_helper
INFO - 2023-08-19 03:51:17 --> Database Driver Class Initialized
DEBUG - 2023-08-19 03:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 03:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 03:51:17 --> Controller Class Initialized
DEBUG - 2023-08-19 03:51:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-08-19 03:51:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 03:51:17 --> Final output sent to browser
DEBUG - 2023-08-19 03:51:17 --> Total execution time: 0.0984
INFO - 2023-08-19 03:51:18 --> Config Class Initialized
INFO - 2023-08-19 03:51:18 --> Hooks Class Initialized
DEBUG - 2023-08-19 03:51:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 03:51:18 --> Utf8 Class Initialized
INFO - 2023-08-19 03:51:18 --> URI Class Initialized
INFO - 2023-08-19 03:51:18 --> Router Class Initialized
INFO - 2023-08-19 03:51:18 --> Output Class Initialized
INFO - 2023-08-19 03:51:18 --> Security Class Initialized
DEBUG - 2023-08-19 03:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 03:51:18 --> Input Class Initialized
INFO - 2023-08-19 03:51:18 --> Language Class Initialized
INFO - 2023-08-19 03:51:18 --> Language Class Initialized
INFO - 2023-08-19 03:51:18 --> Config Class Initialized
INFO - 2023-08-19 03:51:18 --> Loader Class Initialized
INFO - 2023-08-19 03:51:18 --> Helper loaded: url_helper
INFO - 2023-08-19 03:51:18 --> Helper loaded: file_helper
INFO - 2023-08-19 03:51:18 --> Helper loaded: form_helper
INFO - 2023-08-19 03:51:18 --> Helper loaded: my_helper
INFO - 2023-08-19 03:51:18 --> Database Driver Class Initialized
DEBUG - 2023-08-19 03:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 03:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 03:51:18 --> Controller Class Initialized
INFO - 2023-08-19 03:51:18 --> Final output sent to browser
DEBUG - 2023-08-19 03:51:18 --> Total execution time: 0.0250
INFO - 2023-08-19 03:51:19 --> Config Class Initialized
INFO - 2023-08-19 03:51:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 03:51:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 03:51:19 --> Utf8 Class Initialized
INFO - 2023-08-19 03:51:19 --> URI Class Initialized
INFO - 2023-08-19 03:51:19 --> Router Class Initialized
INFO - 2023-08-19 03:51:19 --> Output Class Initialized
INFO - 2023-08-19 03:51:19 --> Security Class Initialized
DEBUG - 2023-08-19 03:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 03:51:19 --> Input Class Initialized
INFO - 2023-08-19 03:51:19 --> Language Class Initialized
INFO - 2023-08-19 03:51:19 --> Language Class Initialized
INFO - 2023-08-19 03:51:19 --> Config Class Initialized
INFO - 2023-08-19 03:51:19 --> Loader Class Initialized
INFO - 2023-08-19 03:51:19 --> Helper loaded: url_helper
INFO - 2023-08-19 03:51:19 --> Helper loaded: file_helper
INFO - 2023-08-19 03:51:19 --> Helper loaded: form_helper
INFO - 2023-08-19 03:51:19 --> Helper loaded: my_helper
INFO - 2023-08-19 03:51:19 --> Database Driver Class Initialized
DEBUG - 2023-08-19 03:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 03:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 03:51:19 --> Controller Class Initialized
DEBUG - 2023-08-19 03:51:19 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 03:51:19 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 03:51:19 --> Final output sent to browser
DEBUG - 2023-08-19 03:51:19 --> Total execution time: 0.0255
INFO - 2023-08-19 03:51:20 --> Config Class Initialized
INFO - 2023-08-19 03:51:20 --> Hooks Class Initialized
DEBUG - 2023-08-19 03:51:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 03:51:20 --> Utf8 Class Initialized
INFO - 2023-08-19 03:51:20 --> URI Class Initialized
INFO - 2023-08-19 03:51:20 --> Router Class Initialized
INFO - 2023-08-19 03:51:20 --> Output Class Initialized
INFO - 2023-08-19 03:51:20 --> Security Class Initialized
DEBUG - 2023-08-19 03:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 03:51:20 --> Input Class Initialized
INFO - 2023-08-19 03:51:20 --> Language Class Initialized
INFO - 2023-08-19 03:51:20 --> Language Class Initialized
INFO - 2023-08-19 03:51:20 --> Config Class Initialized
INFO - 2023-08-19 03:51:20 --> Loader Class Initialized
INFO - 2023-08-19 03:51:20 --> Helper loaded: url_helper
INFO - 2023-08-19 03:51:20 --> Helper loaded: file_helper
INFO - 2023-08-19 03:51:20 --> Helper loaded: form_helper
INFO - 2023-08-19 03:51:20 --> Helper loaded: my_helper
INFO - 2023-08-19 03:51:20 --> Database Driver Class Initialized
DEBUG - 2023-08-19 03:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 03:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 03:51:20 --> Controller Class Initialized
DEBUG - 2023-08-19 03:51:20 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-08-19 03:51:20 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 03:51:20 --> Final output sent to browser
DEBUG - 2023-08-19 03:51:20 --> Total execution time: 0.0249
INFO - 2023-08-19 03:51:21 --> Config Class Initialized
INFO - 2023-08-19 03:51:21 --> Hooks Class Initialized
DEBUG - 2023-08-19 03:51:21 --> UTF-8 Support Enabled
INFO - 2023-08-19 03:51:21 --> Utf8 Class Initialized
INFO - 2023-08-19 03:51:21 --> URI Class Initialized
INFO - 2023-08-19 03:51:21 --> Router Class Initialized
INFO - 2023-08-19 03:51:21 --> Output Class Initialized
INFO - 2023-08-19 03:51:21 --> Security Class Initialized
DEBUG - 2023-08-19 03:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 03:51:21 --> Input Class Initialized
INFO - 2023-08-19 03:51:21 --> Language Class Initialized
INFO - 2023-08-19 03:51:21 --> Language Class Initialized
INFO - 2023-08-19 03:51:21 --> Config Class Initialized
INFO - 2023-08-19 03:51:21 --> Loader Class Initialized
INFO - 2023-08-19 03:51:21 --> Helper loaded: url_helper
INFO - 2023-08-19 03:51:21 --> Helper loaded: file_helper
INFO - 2023-08-19 03:51:21 --> Helper loaded: form_helper
INFO - 2023-08-19 03:51:21 --> Helper loaded: my_helper
INFO - 2023-08-19 03:51:21 --> Database Driver Class Initialized
DEBUG - 2023-08-19 03:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 03:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 03:51:21 --> Controller Class Initialized
INFO - 2023-08-19 03:51:21 --> Final output sent to browser
DEBUG - 2023-08-19 03:51:21 --> Total execution time: 0.0399
INFO - 2023-08-19 03:51:22 --> Config Class Initialized
INFO - 2023-08-19 03:51:22 --> Hooks Class Initialized
DEBUG - 2023-08-19 03:51:22 --> UTF-8 Support Enabled
INFO - 2023-08-19 03:51:22 --> Utf8 Class Initialized
INFO - 2023-08-19 03:51:22 --> URI Class Initialized
INFO - 2023-08-19 03:51:22 --> Router Class Initialized
INFO - 2023-08-19 03:51:22 --> Output Class Initialized
INFO - 2023-08-19 03:51:22 --> Security Class Initialized
DEBUG - 2023-08-19 03:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 03:51:22 --> Input Class Initialized
INFO - 2023-08-19 03:51:22 --> Language Class Initialized
INFO - 2023-08-19 03:51:22 --> Language Class Initialized
INFO - 2023-08-19 03:51:22 --> Config Class Initialized
INFO - 2023-08-19 03:51:22 --> Loader Class Initialized
INFO - 2023-08-19 03:51:22 --> Helper loaded: url_helper
INFO - 2023-08-19 03:51:22 --> Helper loaded: file_helper
INFO - 2023-08-19 03:51:22 --> Helper loaded: form_helper
INFO - 2023-08-19 03:51:22 --> Helper loaded: my_helper
INFO - 2023-08-19 03:51:22 --> Database Driver Class Initialized
DEBUG - 2023-08-19 03:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 03:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 03:51:22 --> Controller Class Initialized
DEBUG - 2023-08-19 03:51:22 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 03:51:22 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 03:51:22 --> Final output sent to browser
DEBUG - 2023-08-19 03:51:22 --> Total execution time: 0.0370
INFO - 2023-08-19 03:51:24 --> Config Class Initialized
INFO - 2023-08-19 03:51:24 --> Hooks Class Initialized
DEBUG - 2023-08-19 03:51:24 --> UTF-8 Support Enabled
INFO - 2023-08-19 03:51:24 --> Utf8 Class Initialized
INFO - 2023-08-19 03:51:24 --> URI Class Initialized
INFO - 2023-08-19 03:51:24 --> Router Class Initialized
INFO - 2023-08-19 03:51:24 --> Output Class Initialized
INFO - 2023-08-19 03:51:24 --> Security Class Initialized
DEBUG - 2023-08-19 03:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 03:51:24 --> Input Class Initialized
INFO - 2023-08-19 03:51:24 --> Language Class Initialized
INFO - 2023-08-19 03:51:24 --> Language Class Initialized
INFO - 2023-08-19 03:51:24 --> Config Class Initialized
INFO - 2023-08-19 03:51:24 --> Loader Class Initialized
INFO - 2023-08-19 03:51:24 --> Helper loaded: url_helper
INFO - 2023-08-19 03:51:24 --> Helper loaded: file_helper
INFO - 2023-08-19 03:51:24 --> Helper loaded: form_helper
INFO - 2023-08-19 03:51:24 --> Helper loaded: my_helper
INFO - 2023-08-19 03:51:24 --> Database Driver Class Initialized
DEBUG - 2023-08-19 03:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 03:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 03:51:24 --> Controller Class Initialized
DEBUG - 2023-08-19 03:51:24 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-08-19 03:51:24 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 03:51:24 --> Final output sent to browser
DEBUG - 2023-08-19 03:51:24 --> Total execution time: 0.0443
INFO - 2023-08-19 03:51:25 --> Config Class Initialized
INFO - 2023-08-19 03:51:25 --> Hooks Class Initialized
DEBUG - 2023-08-19 03:51:25 --> UTF-8 Support Enabled
INFO - 2023-08-19 03:51:25 --> Utf8 Class Initialized
INFO - 2023-08-19 03:51:25 --> URI Class Initialized
INFO - 2023-08-19 03:51:25 --> Router Class Initialized
INFO - 2023-08-19 03:51:25 --> Output Class Initialized
INFO - 2023-08-19 03:51:25 --> Security Class Initialized
DEBUG - 2023-08-19 03:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 03:51:25 --> Input Class Initialized
INFO - 2023-08-19 03:51:25 --> Language Class Initialized
INFO - 2023-08-19 03:51:25 --> Language Class Initialized
INFO - 2023-08-19 03:51:25 --> Config Class Initialized
INFO - 2023-08-19 03:51:25 --> Loader Class Initialized
INFO - 2023-08-19 03:51:25 --> Helper loaded: url_helper
INFO - 2023-08-19 03:51:25 --> Helper loaded: file_helper
INFO - 2023-08-19 03:51:25 --> Helper loaded: form_helper
INFO - 2023-08-19 03:51:25 --> Helper loaded: my_helper
INFO - 2023-08-19 03:51:25 --> Database Driver Class Initialized
DEBUG - 2023-08-19 03:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 03:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 03:51:25 --> Controller Class Initialized
INFO - 2023-08-19 03:51:25 --> Final output sent to browser
DEBUG - 2023-08-19 03:51:25 --> Total execution time: 0.0525
INFO - 2023-08-19 03:51:30 --> Config Class Initialized
INFO - 2023-08-19 03:51:30 --> Hooks Class Initialized
DEBUG - 2023-08-19 03:51:30 --> UTF-8 Support Enabled
INFO - 2023-08-19 03:51:30 --> Utf8 Class Initialized
INFO - 2023-08-19 03:51:30 --> URI Class Initialized
INFO - 2023-08-19 03:51:30 --> Router Class Initialized
INFO - 2023-08-19 03:51:30 --> Output Class Initialized
INFO - 2023-08-19 03:51:30 --> Security Class Initialized
DEBUG - 2023-08-19 03:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 03:51:30 --> Input Class Initialized
INFO - 2023-08-19 03:51:30 --> Language Class Initialized
INFO - 2023-08-19 03:51:30 --> Language Class Initialized
INFO - 2023-08-19 03:51:30 --> Config Class Initialized
INFO - 2023-08-19 03:51:30 --> Loader Class Initialized
INFO - 2023-08-19 03:51:30 --> Helper loaded: url_helper
INFO - 2023-08-19 03:51:30 --> Helper loaded: file_helper
INFO - 2023-08-19 03:51:30 --> Helper loaded: form_helper
INFO - 2023-08-19 03:51:30 --> Helper loaded: my_helper
INFO - 2023-08-19 03:51:30 --> Database Driver Class Initialized
DEBUG - 2023-08-19 03:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 03:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 03:51:30 --> Controller Class Initialized
DEBUG - 2023-08-19 03:51:30 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 03:51:30 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 03:51:30 --> Final output sent to browser
DEBUG - 2023-08-19 03:51:30 --> Total execution time: 0.0269
INFO - 2023-08-19 03:51:31 --> Config Class Initialized
INFO - 2023-08-19 03:51:31 --> Hooks Class Initialized
DEBUG - 2023-08-19 03:51:31 --> UTF-8 Support Enabled
INFO - 2023-08-19 03:51:31 --> Utf8 Class Initialized
INFO - 2023-08-19 03:51:31 --> URI Class Initialized
INFO - 2023-08-19 03:51:31 --> Router Class Initialized
INFO - 2023-08-19 03:51:31 --> Output Class Initialized
INFO - 2023-08-19 03:51:31 --> Security Class Initialized
DEBUG - 2023-08-19 03:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 03:51:31 --> Input Class Initialized
INFO - 2023-08-19 03:51:31 --> Language Class Initialized
INFO - 2023-08-19 03:51:31 --> Language Class Initialized
INFO - 2023-08-19 03:51:31 --> Config Class Initialized
INFO - 2023-08-19 03:51:31 --> Loader Class Initialized
INFO - 2023-08-19 03:51:31 --> Helper loaded: url_helper
INFO - 2023-08-19 03:51:31 --> Helper loaded: file_helper
INFO - 2023-08-19 03:51:31 --> Helper loaded: form_helper
INFO - 2023-08-19 03:51:31 --> Helper loaded: my_helper
INFO - 2023-08-19 03:51:31 --> Database Driver Class Initialized
DEBUG - 2023-08-19 03:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 03:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 03:51:31 --> Controller Class Initialized
DEBUG - 2023-08-19 03:51:31 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-08-19 03:51:31 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 03:51:31 --> Final output sent to browser
DEBUG - 2023-08-19 03:51:31 --> Total execution time: 0.0446
INFO - 2023-08-19 03:51:32 --> Config Class Initialized
INFO - 2023-08-19 03:51:32 --> Hooks Class Initialized
DEBUG - 2023-08-19 03:51:32 --> UTF-8 Support Enabled
INFO - 2023-08-19 03:51:32 --> Utf8 Class Initialized
INFO - 2023-08-19 03:51:32 --> URI Class Initialized
INFO - 2023-08-19 03:51:32 --> Router Class Initialized
INFO - 2023-08-19 03:51:32 --> Output Class Initialized
INFO - 2023-08-19 03:51:32 --> Security Class Initialized
DEBUG - 2023-08-19 03:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 03:51:32 --> Input Class Initialized
INFO - 2023-08-19 03:51:32 --> Language Class Initialized
INFO - 2023-08-19 03:51:32 --> Language Class Initialized
INFO - 2023-08-19 03:51:32 --> Config Class Initialized
INFO - 2023-08-19 03:51:32 --> Loader Class Initialized
INFO - 2023-08-19 03:51:32 --> Helper loaded: url_helper
INFO - 2023-08-19 03:51:32 --> Helper loaded: file_helper
INFO - 2023-08-19 03:51:32 --> Helper loaded: form_helper
INFO - 2023-08-19 03:51:32 --> Helper loaded: my_helper
INFO - 2023-08-19 03:51:32 --> Database Driver Class Initialized
DEBUG - 2023-08-19 03:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 03:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 03:51:32 --> Controller Class Initialized
INFO - 2023-08-19 03:51:32 --> Final output sent to browser
DEBUG - 2023-08-19 03:51:32 --> Total execution time: 0.0515
INFO - 2023-08-19 03:51:34 --> Config Class Initialized
INFO - 2023-08-19 03:51:34 --> Hooks Class Initialized
DEBUG - 2023-08-19 03:51:34 --> UTF-8 Support Enabled
INFO - 2023-08-19 03:51:34 --> Utf8 Class Initialized
INFO - 2023-08-19 03:51:34 --> URI Class Initialized
INFO - 2023-08-19 03:51:34 --> Router Class Initialized
INFO - 2023-08-19 03:51:34 --> Output Class Initialized
INFO - 2023-08-19 03:51:34 --> Security Class Initialized
DEBUG - 2023-08-19 03:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 03:51:34 --> Input Class Initialized
INFO - 2023-08-19 03:51:34 --> Language Class Initialized
INFO - 2023-08-19 03:51:34 --> Language Class Initialized
INFO - 2023-08-19 03:51:34 --> Config Class Initialized
INFO - 2023-08-19 03:51:34 --> Loader Class Initialized
INFO - 2023-08-19 03:51:34 --> Helper loaded: url_helper
INFO - 2023-08-19 03:51:34 --> Helper loaded: file_helper
INFO - 2023-08-19 03:51:34 --> Helper loaded: form_helper
INFO - 2023-08-19 03:51:34 --> Helper loaded: my_helper
INFO - 2023-08-19 03:51:34 --> Database Driver Class Initialized
DEBUG - 2023-08-19 03:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 03:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 03:51:34 --> Controller Class Initialized
DEBUG - 2023-08-19 03:51:34 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 03:51:34 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 03:51:34 --> Final output sent to browser
DEBUG - 2023-08-19 03:51:34 --> Total execution time: 0.0239
INFO - 2023-08-19 03:51:36 --> Config Class Initialized
INFO - 2023-08-19 03:51:36 --> Hooks Class Initialized
DEBUG - 2023-08-19 03:51:36 --> UTF-8 Support Enabled
INFO - 2023-08-19 03:51:36 --> Utf8 Class Initialized
INFO - 2023-08-19 03:51:36 --> URI Class Initialized
INFO - 2023-08-19 03:51:36 --> Router Class Initialized
INFO - 2023-08-19 03:51:36 --> Output Class Initialized
INFO - 2023-08-19 03:51:36 --> Security Class Initialized
DEBUG - 2023-08-19 03:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 03:51:36 --> Input Class Initialized
INFO - 2023-08-19 03:51:36 --> Language Class Initialized
INFO - 2023-08-19 03:51:36 --> Language Class Initialized
INFO - 2023-08-19 03:51:36 --> Config Class Initialized
INFO - 2023-08-19 03:51:36 --> Loader Class Initialized
INFO - 2023-08-19 03:51:36 --> Helper loaded: url_helper
INFO - 2023-08-19 03:51:36 --> Helper loaded: file_helper
INFO - 2023-08-19 03:51:36 --> Helper loaded: form_helper
INFO - 2023-08-19 03:51:36 --> Helper loaded: my_helper
INFO - 2023-08-19 03:51:36 --> Database Driver Class Initialized
DEBUG - 2023-08-19 03:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 03:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 03:51:36 --> Controller Class Initialized
DEBUG - 2023-08-19 03:51:36 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_keterampilan/views/list.php
DEBUG - 2023-08-19 03:51:36 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 03:51:36 --> Final output sent to browser
DEBUG - 2023-08-19 03:51:36 --> Total execution time: 0.1027
INFO - 2023-08-19 03:51:37 --> Config Class Initialized
INFO - 2023-08-19 03:51:37 --> Hooks Class Initialized
DEBUG - 2023-08-19 03:51:37 --> UTF-8 Support Enabled
INFO - 2023-08-19 03:51:37 --> Utf8 Class Initialized
INFO - 2023-08-19 03:51:37 --> URI Class Initialized
INFO - 2023-08-19 03:51:37 --> Router Class Initialized
INFO - 2023-08-19 03:51:37 --> Output Class Initialized
INFO - 2023-08-19 03:51:37 --> Security Class Initialized
DEBUG - 2023-08-19 03:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 03:51:37 --> Input Class Initialized
INFO - 2023-08-19 03:51:37 --> Language Class Initialized
INFO - 2023-08-19 03:51:37 --> Language Class Initialized
INFO - 2023-08-19 03:51:37 --> Config Class Initialized
INFO - 2023-08-19 03:51:37 --> Loader Class Initialized
INFO - 2023-08-19 03:51:37 --> Helper loaded: url_helper
INFO - 2023-08-19 03:51:37 --> Helper loaded: file_helper
INFO - 2023-08-19 03:51:37 --> Helper loaded: form_helper
INFO - 2023-08-19 03:51:37 --> Helper loaded: my_helper
INFO - 2023-08-19 03:51:37 --> Database Driver Class Initialized
DEBUG - 2023-08-19 03:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 03:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 03:51:37 --> Controller Class Initialized
INFO - 2023-08-19 03:51:37 --> Final output sent to browser
DEBUG - 2023-08-19 03:51:37 --> Total execution time: 0.0384
INFO - 2023-08-19 03:51:38 --> Config Class Initialized
INFO - 2023-08-19 03:51:38 --> Hooks Class Initialized
DEBUG - 2023-08-19 03:51:38 --> UTF-8 Support Enabled
INFO - 2023-08-19 03:51:38 --> Utf8 Class Initialized
INFO - 2023-08-19 03:51:38 --> URI Class Initialized
INFO - 2023-08-19 03:51:38 --> Router Class Initialized
INFO - 2023-08-19 03:51:38 --> Output Class Initialized
INFO - 2023-08-19 03:51:38 --> Security Class Initialized
DEBUG - 2023-08-19 03:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 03:51:38 --> Input Class Initialized
INFO - 2023-08-19 03:51:38 --> Language Class Initialized
INFO - 2023-08-19 03:51:38 --> Language Class Initialized
INFO - 2023-08-19 03:51:38 --> Config Class Initialized
INFO - 2023-08-19 03:51:38 --> Loader Class Initialized
INFO - 2023-08-19 03:51:38 --> Helper loaded: url_helper
INFO - 2023-08-19 03:51:38 --> Helper loaded: file_helper
INFO - 2023-08-19 03:51:38 --> Helper loaded: form_helper
INFO - 2023-08-19 03:51:38 --> Helper loaded: my_helper
INFO - 2023-08-19 03:51:38 --> Database Driver Class Initialized
DEBUG - 2023-08-19 03:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 03:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 03:51:38 --> Controller Class Initialized
DEBUG - 2023-08-19 03:51:38 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 03:51:38 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 03:51:38 --> Final output sent to browser
DEBUG - 2023-08-19 03:51:38 --> Total execution time: 0.0407
INFO - 2023-08-19 03:51:44 --> Config Class Initialized
INFO - 2023-08-19 03:51:44 --> Hooks Class Initialized
DEBUG - 2023-08-19 03:51:44 --> UTF-8 Support Enabled
INFO - 2023-08-19 03:51:44 --> Utf8 Class Initialized
INFO - 2023-08-19 03:51:44 --> URI Class Initialized
INFO - 2023-08-19 03:51:44 --> Router Class Initialized
INFO - 2023-08-19 03:51:44 --> Output Class Initialized
INFO - 2023-08-19 03:51:44 --> Security Class Initialized
DEBUG - 2023-08-19 03:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 03:51:44 --> Input Class Initialized
INFO - 2023-08-19 03:51:44 --> Language Class Initialized
INFO - 2023-08-19 03:51:44 --> Language Class Initialized
INFO - 2023-08-19 03:51:44 --> Config Class Initialized
INFO - 2023-08-19 03:51:44 --> Loader Class Initialized
INFO - 2023-08-19 03:51:44 --> Helper loaded: url_helper
INFO - 2023-08-19 03:51:44 --> Helper loaded: file_helper
INFO - 2023-08-19 03:51:44 --> Helper loaded: form_helper
INFO - 2023-08-19 03:51:44 --> Helper loaded: my_helper
INFO - 2023-08-19 03:51:44 --> Database Driver Class Initialized
DEBUG - 2023-08-19 03:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 03:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 03:51:44 --> Controller Class Initialized
DEBUG - 2023-08-19 03:51:44 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-08-19 03:51:44 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 03:51:44 --> Final output sent to browser
DEBUG - 2023-08-19 03:51:44 --> Total execution time: 0.0416
INFO - 2023-08-19 03:51:50 --> Config Class Initialized
INFO - 2023-08-19 03:51:50 --> Hooks Class Initialized
DEBUG - 2023-08-19 03:51:50 --> UTF-8 Support Enabled
INFO - 2023-08-19 03:51:50 --> Utf8 Class Initialized
INFO - 2023-08-19 03:51:50 --> URI Class Initialized
INFO - 2023-08-19 03:51:50 --> Router Class Initialized
INFO - 2023-08-19 03:51:50 --> Output Class Initialized
INFO - 2023-08-19 03:51:50 --> Security Class Initialized
DEBUG - 2023-08-19 03:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 03:51:50 --> Input Class Initialized
INFO - 2023-08-19 03:51:50 --> Language Class Initialized
ERROR - 2023-08-19 03:51:50 --> 404 Page Not Found: /index
INFO - 2023-08-19 03:51:58 --> Config Class Initialized
INFO - 2023-08-19 03:51:58 --> Hooks Class Initialized
DEBUG - 2023-08-19 03:51:58 --> UTF-8 Support Enabled
INFO - 2023-08-19 03:51:58 --> Utf8 Class Initialized
INFO - 2023-08-19 03:51:58 --> URI Class Initialized
INFO - 2023-08-19 03:51:58 --> Router Class Initialized
INFO - 2023-08-19 03:51:58 --> Output Class Initialized
INFO - 2023-08-19 03:51:58 --> Security Class Initialized
DEBUG - 2023-08-19 03:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 03:51:58 --> Input Class Initialized
INFO - 2023-08-19 03:51:58 --> Language Class Initialized
INFO - 2023-08-19 03:51:58 --> Language Class Initialized
INFO - 2023-08-19 03:51:58 --> Config Class Initialized
INFO - 2023-08-19 03:51:58 --> Loader Class Initialized
INFO - 2023-08-19 03:51:58 --> Helper loaded: url_helper
INFO - 2023-08-19 03:51:58 --> Helper loaded: file_helper
INFO - 2023-08-19 03:51:58 --> Helper loaded: form_helper
INFO - 2023-08-19 03:51:58 --> Helper loaded: my_helper
INFO - 2023-08-19 03:51:58 --> Database Driver Class Initialized
DEBUG - 2023-08-19 03:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 03:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 03:51:58 --> Controller Class Initialized
INFO - 2023-08-19 03:51:58 --> Final output sent to browser
DEBUG - 2023-08-19 03:51:58 --> Total execution time: 0.0412
INFO - 2023-08-19 03:53:48 --> Config Class Initialized
INFO - 2023-08-19 03:53:48 --> Hooks Class Initialized
DEBUG - 2023-08-19 03:53:48 --> UTF-8 Support Enabled
INFO - 2023-08-19 03:53:48 --> Utf8 Class Initialized
INFO - 2023-08-19 03:53:48 --> URI Class Initialized
INFO - 2023-08-19 03:53:48 --> Router Class Initialized
INFO - 2023-08-19 03:53:48 --> Output Class Initialized
INFO - 2023-08-19 03:53:48 --> Security Class Initialized
DEBUG - 2023-08-19 03:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 03:53:48 --> Input Class Initialized
INFO - 2023-08-19 03:53:48 --> Language Class Initialized
INFO - 2023-08-19 03:53:48 --> Language Class Initialized
INFO - 2023-08-19 03:53:48 --> Config Class Initialized
INFO - 2023-08-19 03:53:48 --> Loader Class Initialized
INFO - 2023-08-19 03:53:48 --> Helper loaded: url_helper
INFO - 2023-08-19 03:53:48 --> Helper loaded: file_helper
INFO - 2023-08-19 03:53:48 --> Helper loaded: form_helper
INFO - 2023-08-19 03:53:48 --> Helper loaded: my_helper
INFO - 2023-08-19 03:53:48 --> Database Driver Class Initialized
DEBUG - 2023-08-19 03:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 03:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 03:53:48 --> Controller Class Initialized
DEBUG - 2023-08-19 03:53:48 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-08-19 03:53:48 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 03:53:48 --> Final output sent to browser
DEBUG - 2023-08-19 03:53:48 --> Total execution time: 0.1151
INFO - 2023-08-19 03:53:48 --> Config Class Initialized
INFO - 2023-08-19 03:53:48 --> Hooks Class Initialized
DEBUG - 2023-08-19 03:53:48 --> UTF-8 Support Enabled
INFO - 2023-08-19 03:53:48 --> Utf8 Class Initialized
INFO - 2023-08-19 03:53:48 --> URI Class Initialized
INFO - 2023-08-19 03:53:48 --> Router Class Initialized
INFO - 2023-08-19 03:53:48 --> Output Class Initialized
INFO - 2023-08-19 03:53:48 --> Security Class Initialized
DEBUG - 2023-08-19 03:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 03:53:48 --> Input Class Initialized
INFO - 2023-08-19 03:53:48 --> Language Class Initialized
ERROR - 2023-08-19 03:53:48 --> 404 Page Not Found: /index
INFO - 2023-08-19 03:53:50 --> Config Class Initialized
INFO - 2023-08-19 03:53:50 --> Hooks Class Initialized
DEBUG - 2023-08-19 03:53:50 --> UTF-8 Support Enabled
INFO - 2023-08-19 03:53:50 --> Utf8 Class Initialized
INFO - 2023-08-19 03:53:50 --> URI Class Initialized
INFO - 2023-08-19 03:53:50 --> Router Class Initialized
INFO - 2023-08-19 03:53:50 --> Output Class Initialized
INFO - 2023-08-19 03:53:50 --> Security Class Initialized
DEBUG - 2023-08-19 03:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 03:53:50 --> Input Class Initialized
INFO - 2023-08-19 03:53:50 --> Language Class Initialized
INFO - 2023-08-19 03:53:50 --> Language Class Initialized
INFO - 2023-08-19 03:53:50 --> Config Class Initialized
INFO - 2023-08-19 03:53:50 --> Loader Class Initialized
INFO - 2023-08-19 03:53:50 --> Helper loaded: url_helper
INFO - 2023-08-19 03:53:50 --> Helper loaded: file_helper
INFO - 2023-08-19 03:53:50 --> Helper loaded: form_helper
INFO - 2023-08-19 03:53:50 --> Helper loaded: my_helper
INFO - 2023-08-19 03:53:50 --> Database Driver Class Initialized
DEBUG - 2023-08-19 03:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 03:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 03:53:50 --> Controller Class Initialized
INFO - 2023-08-19 03:53:50 --> Final output sent to browser
DEBUG - 2023-08-19 03:53:50 --> Total execution time: 0.0606
INFO - 2023-08-19 03:53:54 --> Config Class Initialized
INFO - 2023-08-19 03:53:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 03:53:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 03:53:54 --> Utf8 Class Initialized
INFO - 2023-08-19 03:53:54 --> URI Class Initialized
INFO - 2023-08-19 03:53:54 --> Router Class Initialized
INFO - 2023-08-19 03:53:54 --> Output Class Initialized
INFO - 2023-08-19 03:53:54 --> Security Class Initialized
DEBUG - 2023-08-19 03:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 03:53:54 --> Input Class Initialized
INFO - 2023-08-19 03:53:54 --> Language Class Initialized
INFO - 2023-08-19 03:53:54 --> Language Class Initialized
INFO - 2023-08-19 03:53:54 --> Config Class Initialized
INFO - 2023-08-19 03:53:54 --> Loader Class Initialized
INFO - 2023-08-19 03:53:54 --> Helper loaded: url_helper
INFO - 2023-08-19 03:53:54 --> Helper loaded: file_helper
INFO - 2023-08-19 03:53:54 --> Helper loaded: form_helper
INFO - 2023-08-19 03:53:54 --> Helper loaded: my_helper
INFO - 2023-08-19 03:53:54 --> Database Driver Class Initialized
DEBUG - 2023-08-19 03:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 03:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 03:53:54 --> Controller Class Initialized
ERROR - 2023-08-19 03:53:54 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules\n_catatan_guru\controllers\N_catatan_guru.php 174
ERROR - 2023-08-19 03:53:54 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules\n_catatan_guru\controllers\N_catatan_guru.php 174
INFO - 2023-08-19 03:54:54 --> Config Class Initialized
INFO - 2023-08-19 03:54:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 03:54:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 03:54:54 --> Utf8 Class Initialized
INFO - 2023-08-19 03:54:54 --> URI Class Initialized
INFO - 2023-08-19 03:54:54 --> Router Class Initialized
INFO - 2023-08-19 03:54:54 --> Output Class Initialized
INFO - 2023-08-19 03:54:54 --> Security Class Initialized
DEBUG - 2023-08-19 03:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 03:54:54 --> Input Class Initialized
INFO - 2023-08-19 03:54:54 --> Language Class Initialized
INFO - 2023-08-19 03:54:54 --> Language Class Initialized
INFO - 2023-08-19 03:54:54 --> Config Class Initialized
INFO - 2023-08-19 03:54:54 --> Loader Class Initialized
INFO - 2023-08-19 03:54:54 --> Helper loaded: url_helper
INFO - 2023-08-19 03:54:54 --> Helper loaded: file_helper
INFO - 2023-08-19 03:54:54 --> Helper loaded: form_helper
INFO - 2023-08-19 03:54:54 --> Helper loaded: my_helper
INFO - 2023-08-19 03:54:54 --> Database Driver Class Initialized
DEBUG - 2023-08-19 03:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 03:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 03:54:54 --> Controller Class Initialized
DEBUG - 2023-08-19 03:54:54 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-08-19 03:54:54 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 03:54:54 --> Final output sent to browser
DEBUG - 2023-08-19 03:54:54 --> Total execution time: 0.0619
INFO - 2023-08-19 03:54:55 --> Config Class Initialized
INFO - 2023-08-19 03:54:55 --> Hooks Class Initialized
DEBUG - 2023-08-19 03:54:55 --> UTF-8 Support Enabled
INFO - 2023-08-19 03:54:55 --> Utf8 Class Initialized
INFO - 2023-08-19 03:54:55 --> URI Class Initialized
INFO - 2023-08-19 03:54:55 --> Router Class Initialized
INFO - 2023-08-19 03:54:55 --> Output Class Initialized
INFO - 2023-08-19 03:54:55 --> Security Class Initialized
DEBUG - 2023-08-19 03:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 03:54:55 --> Input Class Initialized
INFO - 2023-08-19 03:54:55 --> Language Class Initialized
INFO - 2023-08-19 03:54:55 --> Language Class Initialized
INFO - 2023-08-19 03:54:55 --> Config Class Initialized
INFO - 2023-08-19 03:54:55 --> Loader Class Initialized
INFO - 2023-08-19 03:54:55 --> Helper loaded: url_helper
INFO - 2023-08-19 03:54:55 --> Helper loaded: file_helper
INFO - 2023-08-19 03:54:55 --> Helper loaded: form_helper
INFO - 2023-08-19 03:54:55 --> Helper loaded: my_helper
INFO - 2023-08-19 03:54:55 --> Database Driver Class Initialized
DEBUG - 2023-08-19 03:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 03:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 03:54:55 --> Controller Class Initialized
INFO - 2023-08-19 03:54:55 --> Final output sent to browser
DEBUG - 2023-08-19 03:54:55 --> Total execution time: 0.0246
INFO - 2023-08-19 03:54:56 --> Config Class Initialized
INFO - 2023-08-19 03:54:56 --> Hooks Class Initialized
DEBUG - 2023-08-19 03:54:56 --> UTF-8 Support Enabled
INFO - 2023-08-19 03:54:56 --> Utf8 Class Initialized
INFO - 2023-08-19 03:54:56 --> URI Class Initialized
INFO - 2023-08-19 03:54:56 --> Router Class Initialized
INFO - 2023-08-19 03:54:56 --> Output Class Initialized
INFO - 2023-08-19 03:54:56 --> Security Class Initialized
DEBUG - 2023-08-19 03:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 03:54:56 --> Input Class Initialized
INFO - 2023-08-19 03:54:56 --> Language Class Initialized
INFO - 2023-08-19 03:54:56 --> Language Class Initialized
INFO - 2023-08-19 03:54:56 --> Config Class Initialized
INFO - 2023-08-19 03:54:56 --> Loader Class Initialized
INFO - 2023-08-19 03:54:56 --> Helper loaded: url_helper
INFO - 2023-08-19 03:54:56 --> Helper loaded: file_helper
INFO - 2023-08-19 03:54:56 --> Helper loaded: form_helper
INFO - 2023-08-19 03:54:56 --> Helper loaded: my_helper
INFO - 2023-08-19 03:54:56 --> Database Driver Class Initialized
DEBUG - 2023-08-19 03:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 03:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 03:54:56 --> Controller Class Initialized
INFO - 2023-08-19 03:55:04 --> Config Class Initialized
INFO - 2023-08-19 03:55:04 --> Hooks Class Initialized
DEBUG - 2023-08-19 03:55:04 --> UTF-8 Support Enabled
INFO - 2023-08-19 03:55:04 --> Utf8 Class Initialized
INFO - 2023-08-19 03:55:04 --> URI Class Initialized
INFO - 2023-08-19 03:55:04 --> Router Class Initialized
INFO - 2023-08-19 03:55:05 --> Output Class Initialized
INFO - 2023-08-19 03:55:05 --> Security Class Initialized
DEBUG - 2023-08-19 03:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 03:55:05 --> Input Class Initialized
INFO - 2023-08-19 03:55:05 --> Language Class Initialized
INFO - 2023-08-19 03:55:05 --> Language Class Initialized
INFO - 2023-08-19 03:55:05 --> Config Class Initialized
INFO - 2023-08-19 03:55:05 --> Loader Class Initialized
INFO - 2023-08-19 03:55:05 --> Helper loaded: url_helper
INFO - 2023-08-19 03:55:05 --> Helper loaded: file_helper
INFO - 2023-08-19 03:55:05 --> Helper loaded: form_helper
INFO - 2023-08-19 03:55:05 --> Helper loaded: my_helper
INFO - 2023-08-19 03:55:05 --> Database Driver Class Initialized
DEBUG - 2023-08-19 03:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 03:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 03:55:05 --> Controller Class Initialized
INFO - 2023-08-19 03:55:47 --> Config Class Initialized
INFO - 2023-08-19 03:55:47 --> Hooks Class Initialized
DEBUG - 2023-08-19 03:55:47 --> UTF-8 Support Enabled
INFO - 2023-08-19 03:55:47 --> Utf8 Class Initialized
INFO - 2023-08-19 03:55:47 --> URI Class Initialized
INFO - 2023-08-19 03:55:47 --> Router Class Initialized
INFO - 2023-08-19 03:55:47 --> Output Class Initialized
INFO - 2023-08-19 03:55:47 --> Security Class Initialized
DEBUG - 2023-08-19 03:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 03:55:47 --> Input Class Initialized
INFO - 2023-08-19 03:55:47 --> Language Class Initialized
INFO - 2023-08-19 03:55:47 --> Language Class Initialized
INFO - 2023-08-19 03:55:47 --> Config Class Initialized
INFO - 2023-08-19 03:55:47 --> Loader Class Initialized
INFO - 2023-08-19 03:55:47 --> Helper loaded: url_helper
INFO - 2023-08-19 03:55:47 --> Helper loaded: file_helper
INFO - 2023-08-19 03:55:47 --> Helper loaded: form_helper
INFO - 2023-08-19 03:55:47 --> Helper loaded: my_helper
INFO - 2023-08-19 03:55:47 --> Database Driver Class Initialized
DEBUG - 2023-08-19 03:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 03:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 03:55:47 --> Controller Class Initialized
DEBUG - 2023-08-19 03:55:47 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 03:55:47 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 03:55:47 --> Final output sent to browser
DEBUG - 2023-08-19 03:55:47 --> Total execution time: 0.0294
INFO - 2023-08-19 03:55:48 --> Config Class Initialized
INFO - 2023-08-19 03:55:48 --> Hooks Class Initialized
DEBUG - 2023-08-19 03:55:48 --> UTF-8 Support Enabled
INFO - 2023-08-19 03:55:48 --> Utf8 Class Initialized
INFO - 2023-08-19 03:55:48 --> URI Class Initialized
INFO - 2023-08-19 03:55:48 --> Router Class Initialized
INFO - 2023-08-19 03:55:48 --> Output Class Initialized
INFO - 2023-08-19 03:55:48 --> Security Class Initialized
DEBUG - 2023-08-19 03:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 03:55:48 --> Input Class Initialized
INFO - 2023-08-19 03:55:48 --> Language Class Initialized
INFO - 2023-08-19 03:55:48 --> Language Class Initialized
INFO - 2023-08-19 03:55:48 --> Config Class Initialized
INFO - 2023-08-19 03:55:48 --> Loader Class Initialized
INFO - 2023-08-19 03:55:48 --> Helper loaded: url_helper
INFO - 2023-08-19 03:55:48 --> Helper loaded: file_helper
INFO - 2023-08-19 03:55:48 --> Helper loaded: form_helper
INFO - 2023-08-19 03:55:48 --> Helper loaded: my_helper
INFO - 2023-08-19 03:55:48 --> Database Driver Class Initialized
DEBUG - 2023-08-19 03:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 03:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 03:55:48 --> Controller Class Initialized
DEBUG - 2023-08-19 03:55:48 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_keterampilan/views/list.php
DEBUG - 2023-08-19 03:55:48 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 03:55:48 --> Final output sent to browser
DEBUG - 2023-08-19 03:55:48 --> Total execution time: 0.0437
INFO - 2023-08-19 03:55:50 --> Config Class Initialized
INFO - 2023-08-19 03:55:50 --> Hooks Class Initialized
DEBUG - 2023-08-19 03:55:50 --> UTF-8 Support Enabled
INFO - 2023-08-19 03:55:50 --> Utf8 Class Initialized
INFO - 2023-08-19 03:55:50 --> URI Class Initialized
INFO - 2023-08-19 03:55:50 --> Router Class Initialized
INFO - 2023-08-19 03:55:50 --> Output Class Initialized
INFO - 2023-08-19 03:55:50 --> Security Class Initialized
DEBUG - 2023-08-19 03:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 03:55:50 --> Input Class Initialized
INFO - 2023-08-19 03:55:50 --> Language Class Initialized
INFO - 2023-08-19 03:55:50 --> Language Class Initialized
INFO - 2023-08-19 03:55:50 --> Config Class Initialized
INFO - 2023-08-19 03:55:50 --> Loader Class Initialized
INFO - 2023-08-19 03:55:50 --> Helper loaded: url_helper
INFO - 2023-08-19 03:55:50 --> Helper loaded: file_helper
INFO - 2023-08-19 03:55:50 --> Helper loaded: form_helper
INFO - 2023-08-19 03:55:50 --> Helper loaded: my_helper
INFO - 2023-08-19 03:55:50 --> Database Driver Class Initialized
DEBUG - 2023-08-19 03:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 03:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 03:55:50 --> Controller Class Initialized
INFO - 2023-08-19 03:55:50 --> Final output sent to browser
DEBUG - 2023-08-19 03:55:50 --> Total execution time: 0.0247
INFO - 2023-08-19 04:01:24 --> Config Class Initialized
INFO - 2023-08-19 04:01:24 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:01:24 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:01:24 --> Utf8 Class Initialized
INFO - 2023-08-19 04:01:24 --> URI Class Initialized
INFO - 2023-08-19 04:01:24 --> Router Class Initialized
INFO - 2023-08-19 04:01:24 --> Output Class Initialized
INFO - 2023-08-19 04:01:24 --> Security Class Initialized
DEBUG - 2023-08-19 04:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:01:24 --> Input Class Initialized
INFO - 2023-08-19 04:01:24 --> Language Class Initialized
INFO - 2023-08-19 04:01:25 --> Language Class Initialized
INFO - 2023-08-19 04:01:25 --> Config Class Initialized
INFO - 2023-08-19 04:01:25 --> Loader Class Initialized
INFO - 2023-08-19 04:01:25 --> Helper loaded: url_helper
INFO - 2023-08-19 04:01:25 --> Helper loaded: file_helper
INFO - 2023-08-19 04:01:25 --> Helper loaded: form_helper
INFO - 2023-08-19 04:01:25 --> Helper loaded: my_helper
INFO - 2023-08-19 04:01:25 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:01:25 --> Controller Class Initialized
DEBUG - 2023-08-19 04:01:25 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_keterampilan/views/list.php
DEBUG - 2023-08-19 04:01:25 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:01:25 --> Final output sent to browser
DEBUG - 2023-08-19 04:01:25 --> Total execution time: 0.1063
INFO - 2023-08-19 04:01:26 --> Config Class Initialized
INFO - 2023-08-19 04:01:26 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:01:26 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:01:26 --> Utf8 Class Initialized
INFO - 2023-08-19 04:01:26 --> URI Class Initialized
INFO - 2023-08-19 04:01:26 --> Router Class Initialized
INFO - 2023-08-19 04:01:26 --> Output Class Initialized
INFO - 2023-08-19 04:01:26 --> Security Class Initialized
DEBUG - 2023-08-19 04:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:01:26 --> Input Class Initialized
INFO - 2023-08-19 04:01:26 --> Language Class Initialized
INFO - 2023-08-19 04:01:26 --> Language Class Initialized
INFO - 2023-08-19 04:01:26 --> Config Class Initialized
INFO - 2023-08-19 04:01:26 --> Loader Class Initialized
INFO - 2023-08-19 04:01:26 --> Helper loaded: url_helper
INFO - 2023-08-19 04:01:26 --> Helper loaded: file_helper
INFO - 2023-08-19 04:01:26 --> Helper loaded: form_helper
INFO - 2023-08-19 04:01:26 --> Helper loaded: my_helper
INFO - 2023-08-19 04:01:26 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:01:26 --> Controller Class Initialized
INFO - 2023-08-19 04:01:26 --> Final output sent to browser
DEBUG - 2023-08-19 04:01:26 --> Total execution time: 0.0419
INFO - 2023-08-19 04:01:28 --> Config Class Initialized
INFO - 2023-08-19 04:01:28 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:01:28 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:01:28 --> Utf8 Class Initialized
INFO - 2023-08-19 04:01:28 --> URI Class Initialized
INFO - 2023-08-19 04:01:28 --> Router Class Initialized
INFO - 2023-08-19 04:01:28 --> Output Class Initialized
INFO - 2023-08-19 04:01:28 --> Security Class Initialized
DEBUG - 2023-08-19 04:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:01:28 --> Input Class Initialized
INFO - 2023-08-19 04:01:28 --> Language Class Initialized
INFO - 2023-08-19 04:01:28 --> Language Class Initialized
INFO - 2023-08-19 04:01:28 --> Config Class Initialized
INFO - 2023-08-19 04:01:28 --> Loader Class Initialized
INFO - 2023-08-19 04:01:28 --> Helper loaded: url_helper
INFO - 2023-08-19 04:01:28 --> Helper loaded: file_helper
INFO - 2023-08-19 04:01:28 --> Helper loaded: form_helper
INFO - 2023-08-19 04:01:28 --> Helper loaded: my_helper
INFO - 2023-08-19 04:01:28 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:01:28 --> Controller Class Initialized
DEBUG - 2023-08-19 04:01:28 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 04:01:28 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:01:28 --> Final output sent to browser
DEBUG - 2023-08-19 04:01:28 --> Total execution time: 0.0401
INFO - 2023-08-19 04:01:31 --> Config Class Initialized
INFO - 2023-08-19 04:01:31 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:01:31 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:01:31 --> Utf8 Class Initialized
INFO - 2023-08-19 04:01:31 --> URI Class Initialized
INFO - 2023-08-19 04:01:31 --> Router Class Initialized
INFO - 2023-08-19 04:01:31 --> Output Class Initialized
INFO - 2023-08-19 04:01:31 --> Security Class Initialized
DEBUG - 2023-08-19 04:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:01:31 --> Input Class Initialized
INFO - 2023-08-19 04:01:31 --> Language Class Initialized
INFO - 2023-08-19 04:01:31 --> Language Class Initialized
INFO - 2023-08-19 04:01:31 --> Config Class Initialized
INFO - 2023-08-19 04:01:31 --> Loader Class Initialized
INFO - 2023-08-19 04:01:31 --> Helper loaded: url_helper
INFO - 2023-08-19 04:01:31 --> Helper loaded: file_helper
INFO - 2023-08-19 04:01:31 --> Helper loaded: form_helper
INFO - 2023-08-19 04:01:31 --> Helper loaded: my_helper
INFO - 2023-08-19 04:01:31 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:01:31 --> Controller Class Initialized
DEBUG - 2023-08-19 04:01:31 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-08-19 04:01:31 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:01:31 --> Final output sent to browser
DEBUG - 2023-08-19 04:01:31 --> Total execution time: 0.0497
INFO - 2023-08-19 04:01:31 --> Config Class Initialized
INFO - 2023-08-19 04:01:31 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:01:31 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:01:31 --> Utf8 Class Initialized
INFO - 2023-08-19 04:01:31 --> URI Class Initialized
INFO - 2023-08-19 04:01:31 --> Router Class Initialized
INFO - 2023-08-19 04:01:31 --> Output Class Initialized
INFO - 2023-08-19 04:01:31 --> Security Class Initialized
DEBUG - 2023-08-19 04:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:01:31 --> Input Class Initialized
INFO - 2023-08-19 04:01:31 --> Language Class Initialized
INFO - 2023-08-19 04:01:31 --> Language Class Initialized
INFO - 2023-08-19 04:01:31 --> Config Class Initialized
INFO - 2023-08-19 04:01:31 --> Loader Class Initialized
INFO - 2023-08-19 04:01:31 --> Helper loaded: url_helper
INFO - 2023-08-19 04:01:31 --> Helper loaded: file_helper
INFO - 2023-08-19 04:01:31 --> Helper loaded: form_helper
INFO - 2023-08-19 04:01:31 --> Helper loaded: my_helper
INFO - 2023-08-19 04:01:31 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:01:31 --> Controller Class Initialized
INFO - 2023-08-19 04:01:33 --> Config Class Initialized
INFO - 2023-08-19 04:01:33 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:01:33 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:01:33 --> Utf8 Class Initialized
INFO - 2023-08-19 04:01:33 --> URI Class Initialized
INFO - 2023-08-19 04:01:33 --> Router Class Initialized
INFO - 2023-08-19 04:01:33 --> Output Class Initialized
INFO - 2023-08-19 04:01:33 --> Security Class Initialized
DEBUG - 2023-08-19 04:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:01:33 --> Input Class Initialized
INFO - 2023-08-19 04:01:33 --> Language Class Initialized
INFO - 2023-08-19 04:01:33 --> Language Class Initialized
INFO - 2023-08-19 04:01:33 --> Config Class Initialized
INFO - 2023-08-19 04:01:33 --> Loader Class Initialized
INFO - 2023-08-19 04:01:33 --> Helper loaded: url_helper
INFO - 2023-08-19 04:01:33 --> Helper loaded: file_helper
INFO - 2023-08-19 04:01:33 --> Helper loaded: form_helper
INFO - 2023-08-19 04:01:33 --> Helper loaded: my_helper
INFO - 2023-08-19 04:01:33 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:01:33 --> Controller Class Initialized
INFO - 2023-08-19 04:01:33 --> Final output sent to browser
DEBUG - 2023-08-19 04:01:33 --> Total execution time: 0.0262
INFO - 2023-08-19 04:01:35 --> Config Class Initialized
INFO - 2023-08-19 04:01:35 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:01:35 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:01:35 --> Utf8 Class Initialized
INFO - 2023-08-19 04:01:35 --> URI Class Initialized
INFO - 2023-08-19 04:01:35 --> Router Class Initialized
INFO - 2023-08-19 04:01:35 --> Output Class Initialized
INFO - 2023-08-19 04:01:35 --> Security Class Initialized
DEBUG - 2023-08-19 04:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:01:35 --> Input Class Initialized
INFO - 2023-08-19 04:01:35 --> Language Class Initialized
INFO - 2023-08-19 04:01:35 --> Language Class Initialized
INFO - 2023-08-19 04:01:35 --> Config Class Initialized
INFO - 2023-08-19 04:01:35 --> Loader Class Initialized
INFO - 2023-08-19 04:01:35 --> Helper loaded: url_helper
INFO - 2023-08-19 04:01:35 --> Helper loaded: file_helper
INFO - 2023-08-19 04:01:35 --> Helper loaded: form_helper
INFO - 2023-08-19 04:01:35 --> Helper loaded: my_helper
INFO - 2023-08-19 04:01:35 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:01:35 --> Controller Class Initialized
DEBUG - 2023-08-19 04:01:35 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 04:01:35 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:01:35 --> Final output sent to browser
DEBUG - 2023-08-19 04:01:35 --> Total execution time: 0.0285
INFO - 2023-08-19 04:01:37 --> Config Class Initialized
INFO - 2023-08-19 04:01:37 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:01:37 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:01:37 --> Utf8 Class Initialized
INFO - 2023-08-19 04:01:37 --> URI Class Initialized
INFO - 2023-08-19 04:01:37 --> Router Class Initialized
INFO - 2023-08-19 04:01:37 --> Output Class Initialized
INFO - 2023-08-19 04:01:37 --> Security Class Initialized
DEBUG - 2023-08-19 04:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:01:37 --> Input Class Initialized
INFO - 2023-08-19 04:01:37 --> Language Class Initialized
INFO - 2023-08-19 04:01:37 --> Language Class Initialized
INFO - 2023-08-19 04:01:37 --> Config Class Initialized
INFO - 2023-08-19 04:01:37 --> Loader Class Initialized
INFO - 2023-08-19 04:01:37 --> Helper loaded: url_helper
INFO - 2023-08-19 04:01:37 --> Helper loaded: file_helper
INFO - 2023-08-19 04:01:37 --> Helper loaded: form_helper
INFO - 2023-08-19 04:01:37 --> Helper loaded: my_helper
INFO - 2023-08-19 04:01:37 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:01:37 --> Controller Class Initialized
DEBUG - 2023-08-19 04:01:37 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_keterampilan/views/list.php
DEBUG - 2023-08-19 04:01:37 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:01:37 --> Final output sent to browser
DEBUG - 2023-08-19 04:01:37 --> Total execution time: 0.0402
INFO - 2023-08-19 04:01:38 --> Config Class Initialized
INFO - 2023-08-19 04:01:38 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:01:38 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:01:38 --> Utf8 Class Initialized
INFO - 2023-08-19 04:01:38 --> URI Class Initialized
INFO - 2023-08-19 04:01:38 --> Router Class Initialized
INFO - 2023-08-19 04:01:38 --> Output Class Initialized
INFO - 2023-08-19 04:01:38 --> Security Class Initialized
DEBUG - 2023-08-19 04:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:01:38 --> Input Class Initialized
INFO - 2023-08-19 04:01:38 --> Language Class Initialized
INFO - 2023-08-19 04:01:39 --> Language Class Initialized
INFO - 2023-08-19 04:01:39 --> Config Class Initialized
INFO - 2023-08-19 04:01:39 --> Loader Class Initialized
INFO - 2023-08-19 04:01:39 --> Helper loaded: url_helper
INFO - 2023-08-19 04:01:39 --> Helper loaded: file_helper
INFO - 2023-08-19 04:01:39 --> Helper loaded: form_helper
INFO - 2023-08-19 04:01:39 --> Helper loaded: my_helper
INFO - 2023-08-19 04:01:39 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:01:39 --> Controller Class Initialized
DEBUG - 2023-08-19 04:01:39 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 04:01:39 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:01:39 --> Final output sent to browser
DEBUG - 2023-08-19 04:01:39 --> Total execution time: 0.0279
INFO - 2023-08-19 04:01:39 --> Config Class Initialized
INFO - 2023-08-19 04:01:39 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:01:39 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:01:39 --> Utf8 Class Initialized
INFO - 2023-08-19 04:01:39 --> URI Class Initialized
INFO - 2023-08-19 04:01:39 --> Router Class Initialized
INFO - 2023-08-19 04:01:39 --> Output Class Initialized
INFO - 2023-08-19 04:01:39 --> Security Class Initialized
DEBUG - 2023-08-19 04:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:01:39 --> Input Class Initialized
INFO - 2023-08-19 04:01:39 --> Language Class Initialized
INFO - 2023-08-19 04:01:39 --> Language Class Initialized
INFO - 2023-08-19 04:01:39 --> Config Class Initialized
INFO - 2023-08-19 04:01:39 --> Loader Class Initialized
INFO - 2023-08-19 04:01:39 --> Helper loaded: url_helper
INFO - 2023-08-19 04:01:39 --> Helper loaded: file_helper
INFO - 2023-08-19 04:01:39 --> Helper loaded: form_helper
INFO - 2023-08-19 04:01:39 --> Helper loaded: my_helper
INFO - 2023-08-19 04:01:39 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:01:39 --> Controller Class Initialized
DEBUG - 2023-08-19 04:01:39 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-08-19 04:01:39 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:01:39 --> Final output sent to browser
DEBUG - 2023-08-19 04:01:39 --> Total execution time: 0.0287
INFO - 2023-08-19 04:01:39 --> Config Class Initialized
INFO - 2023-08-19 04:01:39 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:01:39 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:01:39 --> Utf8 Class Initialized
INFO - 2023-08-19 04:01:39 --> URI Class Initialized
INFO - 2023-08-19 04:01:39 --> Router Class Initialized
INFO - 2023-08-19 04:01:39 --> Output Class Initialized
INFO - 2023-08-19 04:01:39 --> Security Class Initialized
DEBUG - 2023-08-19 04:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:01:39 --> Input Class Initialized
INFO - 2023-08-19 04:01:39 --> Language Class Initialized
INFO - 2023-08-19 04:01:39 --> Language Class Initialized
INFO - 2023-08-19 04:01:39 --> Config Class Initialized
INFO - 2023-08-19 04:01:39 --> Loader Class Initialized
INFO - 2023-08-19 04:01:39 --> Helper loaded: url_helper
INFO - 2023-08-19 04:01:39 --> Helper loaded: file_helper
INFO - 2023-08-19 04:01:39 --> Helper loaded: form_helper
INFO - 2023-08-19 04:01:39 --> Helper loaded: my_helper
INFO - 2023-08-19 04:01:39 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:01:39 --> Controller Class Initialized
INFO - 2023-08-19 04:01:41 --> Config Class Initialized
INFO - 2023-08-19 04:01:41 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:01:41 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:01:41 --> Utf8 Class Initialized
INFO - 2023-08-19 04:01:41 --> URI Class Initialized
INFO - 2023-08-19 04:01:41 --> Router Class Initialized
INFO - 2023-08-19 04:01:41 --> Output Class Initialized
INFO - 2023-08-19 04:01:41 --> Security Class Initialized
DEBUG - 2023-08-19 04:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:01:41 --> Input Class Initialized
INFO - 2023-08-19 04:01:41 --> Language Class Initialized
INFO - 2023-08-19 04:01:41 --> Language Class Initialized
INFO - 2023-08-19 04:01:41 --> Config Class Initialized
INFO - 2023-08-19 04:01:41 --> Loader Class Initialized
INFO - 2023-08-19 04:01:41 --> Helper loaded: url_helper
INFO - 2023-08-19 04:01:41 --> Helper loaded: file_helper
INFO - 2023-08-19 04:01:41 --> Helper loaded: form_helper
INFO - 2023-08-19 04:01:41 --> Helper loaded: my_helper
INFO - 2023-08-19 04:01:41 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:01:41 --> Controller Class Initialized
INFO - 2023-08-19 04:01:41 --> Final output sent to browser
DEBUG - 2023-08-19 04:01:41 --> Total execution time: 0.0472
INFO - 2023-08-19 04:01:42 --> Config Class Initialized
INFO - 2023-08-19 04:01:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:01:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:01:42 --> Utf8 Class Initialized
INFO - 2023-08-19 04:01:42 --> URI Class Initialized
INFO - 2023-08-19 04:01:42 --> Router Class Initialized
INFO - 2023-08-19 04:01:42 --> Output Class Initialized
INFO - 2023-08-19 04:01:42 --> Security Class Initialized
DEBUG - 2023-08-19 04:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:01:42 --> Input Class Initialized
INFO - 2023-08-19 04:01:42 --> Language Class Initialized
INFO - 2023-08-19 04:01:42 --> Language Class Initialized
INFO - 2023-08-19 04:01:42 --> Config Class Initialized
INFO - 2023-08-19 04:01:42 --> Loader Class Initialized
INFO - 2023-08-19 04:01:42 --> Helper loaded: url_helper
INFO - 2023-08-19 04:01:42 --> Helper loaded: file_helper
INFO - 2023-08-19 04:01:42 --> Helper loaded: form_helper
INFO - 2023-08-19 04:01:42 --> Helper loaded: my_helper
INFO - 2023-08-19 04:01:42 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:01:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:01:42 --> Controller Class Initialized
INFO - 2023-08-19 04:01:53 --> Config Class Initialized
INFO - 2023-08-19 04:01:53 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:01:53 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:01:53 --> Utf8 Class Initialized
INFO - 2023-08-19 04:01:53 --> URI Class Initialized
INFO - 2023-08-19 04:01:53 --> Router Class Initialized
INFO - 2023-08-19 04:01:53 --> Output Class Initialized
INFO - 2023-08-19 04:01:53 --> Security Class Initialized
DEBUG - 2023-08-19 04:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:01:53 --> Input Class Initialized
INFO - 2023-08-19 04:01:53 --> Language Class Initialized
INFO - 2023-08-19 04:01:53 --> Language Class Initialized
INFO - 2023-08-19 04:01:53 --> Config Class Initialized
INFO - 2023-08-19 04:01:53 --> Loader Class Initialized
INFO - 2023-08-19 04:01:53 --> Helper loaded: url_helper
INFO - 2023-08-19 04:01:53 --> Helper loaded: file_helper
INFO - 2023-08-19 04:01:53 --> Helper loaded: form_helper
INFO - 2023-08-19 04:01:53 --> Helper loaded: my_helper
INFO - 2023-08-19 04:01:53 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:01:53 --> Controller Class Initialized
DEBUG - 2023-08-19 04:01:53 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 04:01:53 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:01:53 --> Final output sent to browser
DEBUG - 2023-08-19 04:01:53 --> Total execution time: 0.0458
INFO - 2023-08-19 04:02:13 --> Config Class Initialized
INFO - 2023-08-19 04:02:13 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:02:13 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:02:13 --> Utf8 Class Initialized
INFO - 2023-08-19 04:02:13 --> URI Class Initialized
INFO - 2023-08-19 04:02:13 --> Router Class Initialized
INFO - 2023-08-19 04:02:13 --> Output Class Initialized
INFO - 2023-08-19 04:02:13 --> Security Class Initialized
DEBUG - 2023-08-19 04:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:02:13 --> Input Class Initialized
INFO - 2023-08-19 04:02:13 --> Language Class Initialized
INFO - 2023-08-19 04:02:13 --> Language Class Initialized
INFO - 2023-08-19 04:02:13 --> Config Class Initialized
INFO - 2023-08-19 04:02:13 --> Loader Class Initialized
INFO - 2023-08-19 04:02:13 --> Helper loaded: url_helper
INFO - 2023-08-19 04:02:13 --> Helper loaded: file_helper
INFO - 2023-08-19 04:02:13 --> Helper loaded: form_helper
INFO - 2023-08-19 04:02:13 --> Helper loaded: my_helper
INFO - 2023-08-19 04:02:13 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:02:13 --> Controller Class Initialized
INFO - 2023-08-19 04:02:13 --> Helper loaded: cookie_helper
INFO - 2023-08-19 04:02:13 --> Config Class Initialized
INFO - 2023-08-19 04:02:13 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:02:13 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:02:13 --> Utf8 Class Initialized
INFO - 2023-08-19 04:02:13 --> URI Class Initialized
INFO - 2023-08-19 04:02:13 --> Router Class Initialized
INFO - 2023-08-19 04:02:13 --> Output Class Initialized
INFO - 2023-08-19 04:02:13 --> Security Class Initialized
DEBUG - 2023-08-19 04:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:02:13 --> Input Class Initialized
INFO - 2023-08-19 04:02:13 --> Language Class Initialized
INFO - 2023-08-19 04:02:13 --> Language Class Initialized
INFO - 2023-08-19 04:02:13 --> Config Class Initialized
INFO - 2023-08-19 04:02:13 --> Loader Class Initialized
INFO - 2023-08-19 04:02:13 --> Helper loaded: url_helper
INFO - 2023-08-19 04:02:13 --> Helper loaded: file_helper
INFO - 2023-08-19 04:02:13 --> Helper loaded: form_helper
INFO - 2023-08-19 04:02:13 --> Helper loaded: my_helper
INFO - 2023-08-19 04:02:13 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:02:13 --> Controller Class Initialized
INFO - 2023-08-19 04:02:13 --> Config Class Initialized
INFO - 2023-08-19 04:02:13 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:02:13 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:02:13 --> Utf8 Class Initialized
INFO - 2023-08-19 04:02:13 --> URI Class Initialized
INFO - 2023-08-19 04:02:13 --> Router Class Initialized
INFO - 2023-08-19 04:02:13 --> Output Class Initialized
INFO - 2023-08-19 04:02:13 --> Security Class Initialized
DEBUG - 2023-08-19 04:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:02:13 --> Input Class Initialized
INFO - 2023-08-19 04:02:13 --> Language Class Initialized
INFO - 2023-08-19 04:02:13 --> Language Class Initialized
INFO - 2023-08-19 04:02:13 --> Config Class Initialized
INFO - 2023-08-19 04:02:13 --> Loader Class Initialized
INFO - 2023-08-19 04:02:13 --> Helper loaded: url_helper
INFO - 2023-08-19 04:02:13 --> Helper loaded: file_helper
INFO - 2023-08-19 04:02:13 --> Helper loaded: form_helper
INFO - 2023-08-19 04:02:13 --> Helper loaded: my_helper
INFO - 2023-08-19 04:02:13 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:02:13 --> Controller Class Initialized
DEBUG - 2023-08-19 04:02:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/login/views/login.php
DEBUG - 2023-08-19 04:02:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:02:13 --> Final output sent to browser
DEBUG - 2023-08-19 04:02:13 --> Total execution time: 0.0238
INFO - 2023-08-19 04:02:18 --> Config Class Initialized
INFO - 2023-08-19 04:02:18 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:02:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:02:18 --> Utf8 Class Initialized
INFO - 2023-08-19 04:02:18 --> URI Class Initialized
INFO - 2023-08-19 04:02:18 --> Router Class Initialized
INFO - 2023-08-19 04:02:18 --> Output Class Initialized
INFO - 2023-08-19 04:02:18 --> Security Class Initialized
DEBUG - 2023-08-19 04:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:02:18 --> Input Class Initialized
INFO - 2023-08-19 04:02:18 --> Language Class Initialized
INFO - 2023-08-19 04:02:18 --> Language Class Initialized
INFO - 2023-08-19 04:02:18 --> Config Class Initialized
INFO - 2023-08-19 04:02:18 --> Loader Class Initialized
INFO - 2023-08-19 04:02:18 --> Helper loaded: url_helper
INFO - 2023-08-19 04:02:18 --> Helper loaded: file_helper
INFO - 2023-08-19 04:02:18 --> Helper loaded: form_helper
INFO - 2023-08-19 04:02:18 --> Helper loaded: my_helper
INFO - 2023-08-19 04:02:18 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:02:18 --> Controller Class Initialized
INFO - 2023-08-19 04:02:18 --> Helper loaded: cookie_helper
INFO - 2023-08-19 04:02:18 --> Final output sent to browser
DEBUG - 2023-08-19 04:02:18 --> Total execution time: 0.0323
INFO - 2023-08-19 04:02:18 --> Config Class Initialized
INFO - 2023-08-19 04:02:18 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:02:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:02:18 --> Utf8 Class Initialized
INFO - 2023-08-19 04:02:18 --> URI Class Initialized
INFO - 2023-08-19 04:02:18 --> Router Class Initialized
INFO - 2023-08-19 04:02:18 --> Output Class Initialized
INFO - 2023-08-19 04:02:18 --> Security Class Initialized
DEBUG - 2023-08-19 04:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:02:18 --> Input Class Initialized
INFO - 2023-08-19 04:02:18 --> Language Class Initialized
INFO - 2023-08-19 04:02:18 --> Language Class Initialized
INFO - 2023-08-19 04:02:18 --> Config Class Initialized
INFO - 2023-08-19 04:02:18 --> Loader Class Initialized
INFO - 2023-08-19 04:02:18 --> Helper loaded: url_helper
INFO - 2023-08-19 04:02:18 --> Helper loaded: file_helper
INFO - 2023-08-19 04:02:18 --> Helper loaded: form_helper
INFO - 2023-08-19 04:02:18 --> Helper loaded: my_helper
INFO - 2023-08-19 04:02:18 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:02:18 --> Controller Class Initialized
DEBUG - 2023-08-19 04:02:18 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 04:02:18 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:02:18 --> Final output sent to browser
DEBUG - 2023-08-19 04:02:18 --> Total execution time: 0.0317
INFO - 2023-08-19 04:02:24 --> Config Class Initialized
INFO - 2023-08-19 04:02:24 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:02:24 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:02:24 --> Utf8 Class Initialized
INFO - 2023-08-19 04:02:24 --> URI Class Initialized
DEBUG - 2023-08-19 04:02:24 --> No URI present. Default controller set.
INFO - 2023-08-19 04:02:24 --> Router Class Initialized
INFO - 2023-08-19 04:02:24 --> Output Class Initialized
INFO - 2023-08-19 04:02:24 --> Security Class Initialized
DEBUG - 2023-08-19 04:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:02:24 --> Input Class Initialized
INFO - 2023-08-19 04:02:24 --> Language Class Initialized
INFO - 2023-08-19 04:02:24 --> Language Class Initialized
INFO - 2023-08-19 04:02:24 --> Config Class Initialized
INFO - 2023-08-19 04:02:24 --> Loader Class Initialized
INFO - 2023-08-19 04:02:24 --> Helper loaded: url_helper
INFO - 2023-08-19 04:02:24 --> Helper loaded: file_helper
INFO - 2023-08-19 04:02:24 --> Helper loaded: form_helper
INFO - 2023-08-19 04:02:24 --> Helper loaded: my_helper
INFO - 2023-08-19 04:02:24 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:02:24 --> Controller Class Initialized
DEBUG - 2023-08-19 04:02:24 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 04:02:24 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:02:24 --> Final output sent to browser
DEBUG - 2023-08-19 04:02:24 --> Total execution time: 0.0318
INFO - 2023-08-19 04:02:26 --> Config Class Initialized
INFO - 2023-08-19 04:02:26 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:02:26 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:02:26 --> Utf8 Class Initialized
INFO - 2023-08-19 04:02:26 --> URI Class Initialized
INFO - 2023-08-19 04:02:26 --> Router Class Initialized
INFO - 2023-08-19 04:02:26 --> Output Class Initialized
INFO - 2023-08-19 04:02:26 --> Security Class Initialized
DEBUG - 2023-08-19 04:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:02:26 --> Input Class Initialized
INFO - 2023-08-19 04:02:26 --> Language Class Initialized
INFO - 2023-08-19 04:02:26 --> Language Class Initialized
INFO - 2023-08-19 04:02:26 --> Config Class Initialized
INFO - 2023-08-19 04:02:26 --> Loader Class Initialized
INFO - 2023-08-19 04:02:26 --> Helper loaded: url_helper
INFO - 2023-08-19 04:02:26 --> Helper loaded: file_helper
INFO - 2023-08-19 04:02:26 --> Helper loaded: form_helper
INFO - 2023-08-19 04:02:26 --> Helper loaded: my_helper
INFO - 2023-08-19 04:02:26 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:02:26 --> Controller Class Initialized
DEBUG - 2023-08-19 04:02:26 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 04:02:26 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:02:26 --> Final output sent to browser
DEBUG - 2023-08-19 04:02:26 --> Total execution time: 0.0287
INFO - 2023-08-19 04:02:38 --> Config Class Initialized
INFO - 2023-08-19 04:02:38 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:02:38 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:02:38 --> Utf8 Class Initialized
INFO - 2023-08-19 04:02:38 --> URI Class Initialized
INFO - 2023-08-19 04:02:38 --> Router Class Initialized
INFO - 2023-08-19 04:02:38 --> Output Class Initialized
INFO - 2023-08-19 04:02:38 --> Security Class Initialized
DEBUG - 2023-08-19 04:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:02:38 --> Input Class Initialized
INFO - 2023-08-19 04:02:38 --> Language Class Initialized
INFO - 2023-08-19 04:02:38 --> Language Class Initialized
INFO - 2023-08-19 04:02:38 --> Config Class Initialized
INFO - 2023-08-19 04:02:38 --> Loader Class Initialized
INFO - 2023-08-19 04:02:38 --> Helper loaded: url_helper
INFO - 2023-08-19 04:02:38 --> Helper loaded: file_helper
INFO - 2023-08-19 04:02:38 --> Helper loaded: form_helper
INFO - 2023-08-19 04:02:38 --> Helper loaded: my_helper
INFO - 2023-08-19 04:02:38 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:02:38 --> Controller Class Initialized
INFO - 2023-08-19 04:02:38 --> Helper loaded: cookie_helper
INFO - 2023-08-19 04:02:38 --> Config Class Initialized
INFO - 2023-08-19 04:02:38 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:02:38 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:02:38 --> Utf8 Class Initialized
INFO - 2023-08-19 04:02:38 --> URI Class Initialized
INFO - 2023-08-19 04:02:38 --> Router Class Initialized
INFO - 2023-08-19 04:02:38 --> Output Class Initialized
INFO - 2023-08-19 04:02:38 --> Security Class Initialized
DEBUG - 2023-08-19 04:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:02:38 --> Input Class Initialized
INFO - 2023-08-19 04:02:38 --> Language Class Initialized
INFO - 2023-08-19 04:02:38 --> Language Class Initialized
INFO - 2023-08-19 04:02:38 --> Config Class Initialized
INFO - 2023-08-19 04:02:38 --> Loader Class Initialized
INFO - 2023-08-19 04:02:38 --> Helper loaded: url_helper
INFO - 2023-08-19 04:02:38 --> Helper loaded: file_helper
INFO - 2023-08-19 04:02:38 --> Helper loaded: form_helper
INFO - 2023-08-19 04:02:38 --> Helper loaded: my_helper
INFO - 2023-08-19 04:02:38 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:02:38 --> Controller Class Initialized
INFO - 2023-08-19 04:02:38 --> Config Class Initialized
INFO - 2023-08-19 04:02:38 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:02:38 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:02:38 --> Utf8 Class Initialized
INFO - 2023-08-19 04:02:38 --> URI Class Initialized
INFO - 2023-08-19 04:02:38 --> Router Class Initialized
INFO - 2023-08-19 04:02:38 --> Output Class Initialized
INFO - 2023-08-19 04:02:38 --> Security Class Initialized
DEBUG - 2023-08-19 04:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:02:38 --> Input Class Initialized
INFO - 2023-08-19 04:02:38 --> Language Class Initialized
INFO - 2023-08-19 04:02:38 --> Language Class Initialized
INFO - 2023-08-19 04:02:38 --> Config Class Initialized
INFO - 2023-08-19 04:02:38 --> Loader Class Initialized
INFO - 2023-08-19 04:02:38 --> Helper loaded: url_helper
INFO - 2023-08-19 04:02:38 --> Helper loaded: file_helper
INFO - 2023-08-19 04:02:38 --> Helper loaded: form_helper
INFO - 2023-08-19 04:02:38 --> Helper loaded: my_helper
INFO - 2023-08-19 04:02:38 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:02:38 --> Controller Class Initialized
DEBUG - 2023-08-19 04:02:38 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/login/views/login.php
DEBUG - 2023-08-19 04:02:38 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:02:38 --> Final output sent to browser
DEBUG - 2023-08-19 04:02:38 --> Total execution time: 0.0422
INFO - 2023-08-19 04:08:04 --> Config Class Initialized
INFO - 2023-08-19 04:08:04 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:08:04 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:08:04 --> Utf8 Class Initialized
INFO - 2023-08-19 04:08:04 --> URI Class Initialized
INFO - 2023-08-19 04:08:04 --> Router Class Initialized
INFO - 2023-08-19 04:08:04 --> Output Class Initialized
INFO - 2023-08-19 04:08:04 --> Security Class Initialized
DEBUG - 2023-08-19 04:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:08:04 --> Input Class Initialized
INFO - 2023-08-19 04:08:04 --> Language Class Initialized
INFO - 2023-08-19 04:08:04 --> Language Class Initialized
INFO - 2023-08-19 04:08:04 --> Config Class Initialized
INFO - 2023-08-19 04:08:04 --> Loader Class Initialized
INFO - 2023-08-19 04:08:04 --> Helper loaded: url_helper
INFO - 2023-08-19 04:08:04 --> Helper loaded: file_helper
INFO - 2023-08-19 04:08:04 --> Helper loaded: form_helper
INFO - 2023-08-19 04:08:04 --> Helper loaded: my_helper
INFO - 2023-08-19 04:08:04 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:08:04 --> Controller Class Initialized
INFO - 2023-08-19 04:08:04 --> Helper loaded: cookie_helper
INFO - 2023-08-19 04:08:04 --> Final output sent to browser
DEBUG - 2023-08-19 04:08:04 --> Total execution time: 0.0469
INFO - 2023-08-19 04:08:04 --> Config Class Initialized
INFO - 2023-08-19 04:08:04 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:08:04 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:08:04 --> Utf8 Class Initialized
INFO - 2023-08-19 04:08:04 --> URI Class Initialized
INFO - 2023-08-19 04:08:04 --> Router Class Initialized
INFO - 2023-08-19 04:08:04 --> Output Class Initialized
INFO - 2023-08-19 04:08:04 --> Security Class Initialized
DEBUG - 2023-08-19 04:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:08:04 --> Input Class Initialized
INFO - 2023-08-19 04:08:04 --> Language Class Initialized
INFO - 2023-08-19 04:08:04 --> Language Class Initialized
INFO - 2023-08-19 04:08:04 --> Config Class Initialized
INFO - 2023-08-19 04:08:04 --> Loader Class Initialized
INFO - 2023-08-19 04:08:04 --> Helper loaded: url_helper
INFO - 2023-08-19 04:08:04 --> Helper loaded: file_helper
INFO - 2023-08-19 04:08:04 --> Helper loaded: form_helper
INFO - 2023-08-19 04:08:04 --> Helper loaded: my_helper
INFO - 2023-08-19 04:08:04 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:08:04 --> Controller Class Initialized
DEBUG - 2023-08-19 04:08:04 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home.php
DEBUG - 2023-08-19 04:08:04 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:08:04 --> Final output sent to browser
DEBUG - 2023-08-19 04:08:04 --> Total execution time: 0.0416
INFO - 2023-08-19 04:08:35 --> Config Class Initialized
INFO - 2023-08-19 04:08:35 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:08:35 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:08:35 --> Utf8 Class Initialized
INFO - 2023-08-19 04:08:35 --> URI Class Initialized
INFO - 2023-08-19 04:08:35 --> Router Class Initialized
INFO - 2023-08-19 04:08:35 --> Output Class Initialized
INFO - 2023-08-19 04:08:35 --> Security Class Initialized
DEBUG - 2023-08-19 04:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:08:35 --> Input Class Initialized
INFO - 2023-08-19 04:08:35 --> Language Class Initialized
INFO - 2023-08-19 04:08:35 --> Language Class Initialized
INFO - 2023-08-19 04:08:35 --> Config Class Initialized
INFO - 2023-08-19 04:08:35 --> Loader Class Initialized
INFO - 2023-08-19 04:08:35 --> Helper loaded: url_helper
INFO - 2023-08-19 04:08:35 --> Helper loaded: file_helper
INFO - 2023-08-19 04:08:35 --> Helper loaded: form_helper
INFO - 2023-08-19 04:08:35 --> Helper loaded: my_helper
INFO - 2023-08-19 04:08:35 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:08:35 --> Controller Class Initialized
DEBUG - 2023-08-19 04:08:35 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/data_siswa/views/list.php
DEBUG - 2023-08-19 04:08:35 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:08:35 --> Final output sent to browser
DEBUG - 2023-08-19 04:08:35 --> Total execution time: 0.0314
INFO - 2023-08-19 04:08:35 --> Config Class Initialized
INFO - 2023-08-19 04:08:35 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:08:35 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:08:35 --> Utf8 Class Initialized
INFO - 2023-08-19 04:08:35 --> URI Class Initialized
INFO - 2023-08-19 04:08:35 --> Router Class Initialized
INFO - 2023-08-19 04:08:35 --> Output Class Initialized
INFO - 2023-08-19 04:08:35 --> Security Class Initialized
DEBUG - 2023-08-19 04:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:08:35 --> Input Class Initialized
INFO - 2023-08-19 04:08:35 --> Language Class Initialized
INFO - 2023-08-19 04:08:35 --> Language Class Initialized
INFO - 2023-08-19 04:08:35 --> Config Class Initialized
INFO - 2023-08-19 04:08:35 --> Loader Class Initialized
INFO - 2023-08-19 04:08:35 --> Helper loaded: url_helper
INFO - 2023-08-19 04:08:35 --> Helper loaded: file_helper
INFO - 2023-08-19 04:08:35 --> Helper loaded: form_helper
INFO - 2023-08-19 04:08:35 --> Helper loaded: my_helper
INFO - 2023-08-19 04:08:35 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:08:35 --> Controller Class Initialized
INFO - 2023-08-19 04:08:37 --> Config Class Initialized
INFO - 2023-08-19 04:08:37 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:08:37 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:08:37 --> Utf8 Class Initialized
INFO - 2023-08-19 04:08:37 --> URI Class Initialized
INFO - 2023-08-19 04:08:37 --> Router Class Initialized
INFO - 2023-08-19 04:08:37 --> Output Class Initialized
INFO - 2023-08-19 04:08:37 --> Security Class Initialized
DEBUG - 2023-08-19 04:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:08:37 --> Input Class Initialized
INFO - 2023-08-19 04:08:37 --> Language Class Initialized
INFO - 2023-08-19 04:08:37 --> Language Class Initialized
INFO - 2023-08-19 04:08:37 --> Config Class Initialized
INFO - 2023-08-19 04:08:37 --> Loader Class Initialized
INFO - 2023-08-19 04:08:37 --> Helper loaded: url_helper
INFO - 2023-08-19 04:08:37 --> Helper loaded: file_helper
INFO - 2023-08-19 04:08:37 --> Helper loaded: form_helper
INFO - 2023-08-19 04:08:37 --> Helper loaded: my_helper
INFO - 2023-08-19 04:08:37 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:08:37 --> Controller Class Initialized
DEBUG - 2023-08-19 04:08:37 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/data_kelas/views/list.php
DEBUG - 2023-08-19 04:08:37 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:08:37 --> Final output sent to browser
DEBUG - 2023-08-19 04:08:37 --> Total execution time: 0.0381
INFO - 2023-08-19 04:08:38 --> Config Class Initialized
INFO - 2023-08-19 04:08:38 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:08:38 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:08:38 --> Utf8 Class Initialized
INFO - 2023-08-19 04:08:38 --> URI Class Initialized
INFO - 2023-08-19 04:08:38 --> Router Class Initialized
INFO - 2023-08-19 04:08:38 --> Output Class Initialized
INFO - 2023-08-19 04:08:38 --> Security Class Initialized
DEBUG - 2023-08-19 04:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:08:38 --> Input Class Initialized
INFO - 2023-08-19 04:08:38 --> Language Class Initialized
INFO - 2023-08-19 04:08:38 --> Language Class Initialized
INFO - 2023-08-19 04:08:38 --> Config Class Initialized
INFO - 2023-08-19 04:08:38 --> Loader Class Initialized
INFO - 2023-08-19 04:08:38 --> Helper loaded: url_helper
INFO - 2023-08-19 04:08:38 --> Helper loaded: file_helper
INFO - 2023-08-19 04:08:38 --> Helper loaded: form_helper
INFO - 2023-08-19 04:08:38 --> Helper loaded: my_helper
INFO - 2023-08-19 04:08:38 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:08:38 --> Controller Class Initialized
INFO - 2023-08-19 04:08:41 --> Config Class Initialized
INFO - 2023-08-19 04:08:41 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:08:41 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:08:41 --> Utf8 Class Initialized
INFO - 2023-08-19 04:08:41 --> URI Class Initialized
INFO - 2023-08-19 04:08:41 --> Router Class Initialized
INFO - 2023-08-19 04:08:41 --> Output Class Initialized
INFO - 2023-08-19 04:08:41 --> Security Class Initialized
DEBUG - 2023-08-19 04:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:08:41 --> Input Class Initialized
INFO - 2023-08-19 04:08:41 --> Language Class Initialized
INFO - 2023-08-19 04:08:41 --> Language Class Initialized
INFO - 2023-08-19 04:08:41 --> Config Class Initialized
INFO - 2023-08-19 04:08:41 --> Loader Class Initialized
INFO - 2023-08-19 04:08:41 --> Helper loaded: url_helper
INFO - 2023-08-19 04:08:41 --> Helper loaded: file_helper
INFO - 2023-08-19 04:08:41 --> Helper loaded: form_helper
INFO - 2023-08-19 04:08:41 --> Helper loaded: my_helper
INFO - 2023-08-19 04:08:41 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:08:41 --> Controller Class Initialized
DEBUG - 2023-08-19 04:08:41 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/data_siswa/views/list.php
DEBUG - 2023-08-19 04:08:41 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:08:41 --> Final output sent to browser
DEBUG - 2023-08-19 04:08:41 --> Total execution time: 0.0560
INFO - 2023-08-19 04:08:41 --> Config Class Initialized
INFO - 2023-08-19 04:08:41 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:08:41 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:08:41 --> Utf8 Class Initialized
INFO - 2023-08-19 04:08:41 --> URI Class Initialized
INFO - 2023-08-19 04:08:41 --> Router Class Initialized
INFO - 2023-08-19 04:08:41 --> Output Class Initialized
INFO - 2023-08-19 04:08:41 --> Security Class Initialized
DEBUG - 2023-08-19 04:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:08:41 --> Input Class Initialized
INFO - 2023-08-19 04:08:41 --> Language Class Initialized
INFO - 2023-08-19 04:08:41 --> Language Class Initialized
INFO - 2023-08-19 04:08:41 --> Config Class Initialized
INFO - 2023-08-19 04:08:41 --> Loader Class Initialized
INFO - 2023-08-19 04:08:41 --> Helper loaded: url_helper
INFO - 2023-08-19 04:08:41 --> Helper loaded: file_helper
INFO - 2023-08-19 04:08:41 --> Helper loaded: form_helper
INFO - 2023-08-19 04:08:41 --> Helper loaded: my_helper
INFO - 2023-08-19 04:08:41 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:08:41 --> Controller Class Initialized
INFO - 2023-08-19 04:08:42 --> Config Class Initialized
INFO - 2023-08-19 04:08:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:08:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:08:42 --> Utf8 Class Initialized
INFO - 2023-08-19 04:08:42 --> URI Class Initialized
INFO - 2023-08-19 04:08:42 --> Router Class Initialized
INFO - 2023-08-19 04:08:42 --> Output Class Initialized
INFO - 2023-08-19 04:08:42 --> Security Class Initialized
DEBUG - 2023-08-19 04:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:08:42 --> Input Class Initialized
INFO - 2023-08-19 04:08:42 --> Language Class Initialized
INFO - 2023-08-19 04:08:42 --> Language Class Initialized
INFO - 2023-08-19 04:08:42 --> Config Class Initialized
INFO - 2023-08-19 04:08:42 --> Loader Class Initialized
INFO - 2023-08-19 04:08:42 --> Helper loaded: url_helper
INFO - 2023-08-19 04:08:42 --> Helper loaded: file_helper
INFO - 2023-08-19 04:08:42 --> Helper loaded: form_helper
INFO - 2023-08-19 04:08:42 --> Helper loaded: my_helper
INFO - 2023-08-19 04:08:42 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:08:42 --> Controller Class Initialized
DEBUG - 2023-08-19 04:08:42 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/data_mapel/views/list.php
DEBUG - 2023-08-19 04:08:42 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:08:42 --> Final output sent to browser
DEBUG - 2023-08-19 04:08:42 --> Total execution time: 0.0264
INFO - 2023-08-19 04:08:42 --> Config Class Initialized
INFO - 2023-08-19 04:08:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:08:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:08:42 --> Utf8 Class Initialized
INFO - 2023-08-19 04:08:42 --> URI Class Initialized
INFO - 2023-08-19 04:08:42 --> Router Class Initialized
INFO - 2023-08-19 04:08:42 --> Output Class Initialized
INFO - 2023-08-19 04:08:42 --> Security Class Initialized
DEBUG - 2023-08-19 04:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:08:42 --> Input Class Initialized
INFO - 2023-08-19 04:08:42 --> Language Class Initialized
INFO - 2023-08-19 04:08:42 --> Language Class Initialized
INFO - 2023-08-19 04:08:42 --> Config Class Initialized
INFO - 2023-08-19 04:08:42 --> Loader Class Initialized
INFO - 2023-08-19 04:08:42 --> Helper loaded: url_helper
INFO - 2023-08-19 04:08:42 --> Helper loaded: file_helper
INFO - 2023-08-19 04:08:42 --> Helper loaded: form_helper
INFO - 2023-08-19 04:08:42 --> Helper loaded: my_helper
INFO - 2023-08-19 04:08:42 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:08:42 --> Controller Class Initialized
INFO - 2023-08-19 04:08:43 --> Config Class Initialized
INFO - 2023-08-19 04:08:43 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:08:43 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:08:43 --> Utf8 Class Initialized
INFO - 2023-08-19 04:08:43 --> URI Class Initialized
INFO - 2023-08-19 04:08:43 --> Router Class Initialized
INFO - 2023-08-19 04:08:43 --> Output Class Initialized
INFO - 2023-08-19 04:08:43 --> Security Class Initialized
DEBUG - 2023-08-19 04:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:08:43 --> Input Class Initialized
INFO - 2023-08-19 04:08:43 --> Language Class Initialized
INFO - 2023-08-19 04:08:43 --> Language Class Initialized
INFO - 2023-08-19 04:08:43 --> Config Class Initialized
INFO - 2023-08-19 04:08:43 --> Loader Class Initialized
INFO - 2023-08-19 04:08:43 --> Helper loaded: url_helper
INFO - 2023-08-19 04:08:43 --> Helper loaded: file_helper
INFO - 2023-08-19 04:08:43 --> Helper loaded: form_helper
INFO - 2023-08-19 04:08:43 --> Helper loaded: my_helper
INFO - 2023-08-19 04:08:43 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:08:43 --> Controller Class Initialized
INFO - 2023-08-19 04:08:43 --> Final output sent to browser
DEBUG - 2023-08-19 04:08:43 --> Total execution time: 0.0317
INFO - 2023-08-19 04:12:05 --> Config Class Initialized
INFO - 2023-08-19 04:12:05 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:12:05 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:12:05 --> Utf8 Class Initialized
INFO - 2023-08-19 04:12:05 --> URI Class Initialized
INFO - 2023-08-19 04:12:05 --> Router Class Initialized
INFO - 2023-08-19 04:12:05 --> Output Class Initialized
INFO - 2023-08-19 04:12:05 --> Security Class Initialized
DEBUG - 2023-08-19 04:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:12:05 --> Input Class Initialized
INFO - 2023-08-19 04:12:05 --> Language Class Initialized
INFO - 2023-08-19 04:12:06 --> Language Class Initialized
INFO - 2023-08-19 04:12:06 --> Config Class Initialized
INFO - 2023-08-19 04:12:06 --> Loader Class Initialized
INFO - 2023-08-19 04:12:06 --> Helper loaded: url_helper
INFO - 2023-08-19 04:12:06 --> Helper loaded: file_helper
INFO - 2023-08-19 04:12:06 --> Helper loaded: form_helper
INFO - 2023-08-19 04:12:06 --> Helper loaded: my_helper
INFO - 2023-08-19 04:12:06 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:12:06 --> Controller Class Initialized
DEBUG - 2023-08-19 04:12:06 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/data_mapel/views/list.php
DEBUG - 2023-08-19 04:12:06 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:12:06 --> Final output sent to browser
DEBUG - 2023-08-19 04:12:06 --> Total execution time: 0.0692
INFO - 2023-08-19 04:12:06 --> Config Class Initialized
INFO - 2023-08-19 04:12:06 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:12:06 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:12:06 --> Utf8 Class Initialized
INFO - 2023-08-19 04:12:06 --> URI Class Initialized
INFO - 2023-08-19 04:12:06 --> Router Class Initialized
INFO - 2023-08-19 04:12:06 --> Output Class Initialized
INFO - 2023-08-19 04:12:06 --> Security Class Initialized
DEBUG - 2023-08-19 04:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:12:06 --> Input Class Initialized
INFO - 2023-08-19 04:12:06 --> Language Class Initialized
INFO - 2023-08-19 04:12:06 --> Language Class Initialized
INFO - 2023-08-19 04:12:06 --> Config Class Initialized
INFO - 2023-08-19 04:12:06 --> Loader Class Initialized
INFO - 2023-08-19 04:12:06 --> Helper loaded: url_helper
INFO - 2023-08-19 04:12:06 --> Helper loaded: file_helper
INFO - 2023-08-19 04:12:06 --> Helper loaded: form_helper
INFO - 2023-08-19 04:12:06 --> Helper loaded: my_helper
INFO - 2023-08-19 04:12:06 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:12:06 --> Controller Class Initialized
INFO - 2023-08-19 04:12:07 --> Config Class Initialized
INFO - 2023-08-19 04:12:07 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:12:07 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:12:07 --> Utf8 Class Initialized
INFO - 2023-08-19 04:12:07 --> URI Class Initialized
INFO - 2023-08-19 04:12:07 --> Router Class Initialized
INFO - 2023-08-19 04:12:07 --> Output Class Initialized
INFO - 2023-08-19 04:12:07 --> Security Class Initialized
DEBUG - 2023-08-19 04:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:12:07 --> Input Class Initialized
INFO - 2023-08-19 04:12:07 --> Language Class Initialized
INFO - 2023-08-19 04:12:07 --> Language Class Initialized
INFO - 2023-08-19 04:12:07 --> Config Class Initialized
INFO - 2023-08-19 04:12:07 --> Loader Class Initialized
INFO - 2023-08-19 04:12:07 --> Helper loaded: url_helper
INFO - 2023-08-19 04:12:07 --> Helper loaded: file_helper
INFO - 2023-08-19 04:12:07 --> Helper loaded: form_helper
INFO - 2023-08-19 04:12:07 --> Helper loaded: my_helper
INFO - 2023-08-19 04:12:07 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:12:07 --> Controller Class Initialized
INFO - 2023-08-19 04:12:07 --> Final output sent to browser
DEBUG - 2023-08-19 04:12:07 --> Total execution time: 0.0298
INFO - 2023-08-19 04:50:15 --> Config Class Initialized
INFO - 2023-08-19 04:50:15 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:50:15 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:50:15 --> Utf8 Class Initialized
INFO - 2023-08-19 04:50:15 --> URI Class Initialized
INFO - 2023-08-19 04:50:15 --> Router Class Initialized
INFO - 2023-08-19 04:50:15 --> Output Class Initialized
INFO - 2023-08-19 04:50:15 --> Security Class Initialized
DEBUG - 2023-08-19 04:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:50:15 --> Input Class Initialized
INFO - 2023-08-19 04:50:15 --> Language Class Initialized
INFO - 2023-08-19 04:50:15 --> Language Class Initialized
INFO - 2023-08-19 04:50:15 --> Config Class Initialized
INFO - 2023-08-19 04:50:15 --> Loader Class Initialized
INFO - 2023-08-19 04:50:15 --> Helper loaded: url_helper
INFO - 2023-08-19 04:50:15 --> Helper loaded: file_helper
INFO - 2023-08-19 04:50:15 --> Helper loaded: form_helper
INFO - 2023-08-19 04:50:15 --> Helper loaded: my_helper
INFO - 2023-08-19 04:50:15 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:50:15 --> Controller Class Initialized
INFO - 2023-08-19 04:50:15 --> Helper loaded: cookie_helper
INFO - 2023-08-19 04:50:15 --> Config Class Initialized
INFO - 2023-08-19 04:50:15 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:50:15 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:50:15 --> Utf8 Class Initialized
INFO - 2023-08-19 04:50:15 --> URI Class Initialized
INFO - 2023-08-19 04:50:15 --> Router Class Initialized
INFO - 2023-08-19 04:50:15 --> Output Class Initialized
INFO - 2023-08-19 04:50:15 --> Security Class Initialized
DEBUG - 2023-08-19 04:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:50:15 --> Input Class Initialized
INFO - 2023-08-19 04:50:15 --> Language Class Initialized
INFO - 2023-08-19 04:50:15 --> Language Class Initialized
INFO - 2023-08-19 04:50:15 --> Config Class Initialized
INFO - 2023-08-19 04:50:15 --> Loader Class Initialized
INFO - 2023-08-19 04:50:15 --> Helper loaded: url_helper
INFO - 2023-08-19 04:50:15 --> Helper loaded: file_helper
INFO - 2023-08-19 04:50:15 --> Helper loaded: form_helper
INFO - 2023-08-19 04:50:15 --> Helper loaded: my_helper
INFO - 2023-08-19 04:50:15 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:50:15 --> Controller Class Initialized
INFO - 2023-08-19 04:50:15 --> Config Class Initialized
INFO - 2023-08-19 04:50:15 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:50:15 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:50:15 --> Utf8 Class Initialized
INFO - 2023-08-19 04:50:15 --> URI Class Initialized
INFO - 2023-08-19 04:50:15 --> Router Class Initialized
INFO - 2023-08-19 04:50:15 --> Output Class Initialized
INFO - 2023-08-19 04:50:15 --> Security Class Initialized
DEBUG - 2023-08-19 04:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:50:15 --> Input Class Initialized
INFO - 2023-08-19 04:50:15 --> Language Class Initialized
INFO - 2023-08-19 04:50:15 --> Language Class Initialized
INFO - 2023-08-19 04:50:15 --> Config Class Initialized
INFO - 2023-08-19 04:50:15 --> Loader Class Initialized
INFO - 2023-08-19 04:50:15 --> Helper loaded: url_helper
INFO - 2023-08-19 04:50:15 --> Helper loaded: file_helper
INFO - 2023-08-19 04:50:15 --> Helper loaded: form_helper
INFO - 2023-08-19 04:50:15 --> Helper loaded: my_helper
INFO - 2023-08-19 04:50:15 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:50:15 --> Controller Class Initialized
DEBUG - 2023-08-19 04:50:15 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/login/views/login.php
DEBUG - 2023-08-19 04:50:15 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:50:15 --> Final output sent to browser
DEBUG - 2023-08-19 04:50:15 --> Total execution time: 0.0848
INFO - 2023-08-19 04:50:19 --> Config Class Initialized
INFO - 2023-08-19 04:50:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:50:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:50:19 --> Utf8 Class Initialized
INFO - 2023-08-19 04:50:19 --> URI Class Initialized
INFO - 2023-08-19 04:50:19 --> Router Class Initialized
INFO - 2023-08-19 04:50:19 --> Output Class Initialized
INFO - 2023-08-19 04:50:19 --> Security Class Initialized
DEBUG - 2023-08-19 04:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:50:19 --> Input Class Initialized
INFO - 2023-08-19 04:50:19 --> Language Class Initialized
INFO - 2023-08-19 04:50:19 --> Language Class Initialized
INFO - 2023-08-19 04:50:19 --> Config Class Initialized
INFO - 2023-08-19 04:50:19 --> Loader Class Initialized
INFO - 2023-08-19 04:50:19 --> Helper loaded: url_helper
INFO - 2023-08-19 04:50:19 --> Helper loaded: file_helper
INFO - 2023-08-19 04:50:19 --> Helper loaded: form_helper
INFO - 2023-08-19 04:50:19 --> Helper loaded: my_helper
INFO - 2023-08-19 04:50:19 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:50:19 --> Controller Class Initialized
INFO - 2023-08-19 04:50:19 --> Helper loaded: cookie_helper
INFO - 2023-08-19 04:50:19 --> Final output sent to browser
DEBUG - 2023-08-19 04:50:19 --> Total execution time: 0.0339
INFO - 2023-08-19 04:50:19 --> Config Class Initialized
INFO - 2023-08-19 04:50:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:50:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:50:19 --> Utf8 Class Initialized
INFO - 2023-08-19 04:50:19 --> URI Class Initialized
INFO - 2023-08-19 04:50:19 --> Router Class Initialized
INFO - 2023-08-19 04:50:19 --> Output Class Initialized
INFO - 2023-08-19 04:50:19 --> Security Class Initialized
DEBUG - 2023-08-19 04:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:50:19 --> Input Class Initialized
INFO - 2023-08-19 04:50:19 --> Language Class Initialized
INFO - 2023-08-19 04:50:19 --> Language Class Initialized
INFO - 2023-08-19 04:50:19 --> Config Class Initialized
INFO - 2023-08-19 04:50:19 --> Loader Class Initialized
INFO - 2023-08-19 04:50:19 --> Helper loaded: url_helper
INFO - 2023-08-19 04:50:19 --> Helper loaded: file_helper
INFO - 2023-08-19 04:50:19 --> Helper loaded: form_helper
INFO - 2023-08-19 04:50:19 --> Helper loaded: my_helper
INFO - 2023-08-19 04:50:19 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:50:19 --> Controller Class Initialized
DEBUG - 2023-08-19 04:50:19 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 04:50:19 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:50:19 --> Final output sent to browser
DEBUG - 2023-08-19 04:50:19 --> Total execution time: 0.0491
INFO - 2023-08-19 04:50:21 --> Config Class Initialized
INFO - 2023-08-19 04:50:21 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:50:21 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:50:21 --> Utf8 Class Initialized
INFO - 2023-08-19 04:50:21 --> URI Class Initialized
INFO - 2023-08-19 04:50:21 --> Router Class Initialized
INFO - 2023-08-19 04:50:21 --> Output Class Initialized
INFO - 2023-08-19 04:50:21 --> Security Class Initialized
DEBUG - 2023-08-19 04:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:50:21 --> Input Class Initialized
INFO - 2023-08-19 04:50:21 --> Language Class Initialized
INFO - 2023-08-19 04:50:21 --> Language Class Initialized
INFO - 2023-08-19 04:50:21 --> Config Class Initialized
INFO - 2023-08-19 04:50:21 --> Loader Class Initialized
INFO - 2023-08-19 04:50:21 --> Helper loaded: url_helper
INFO - 2023-08-19 04:50:21 --> Helper loaded: file_helper
INFO - 2023-08-19 04:50:21 --> Helper loaded: form_helper
INFO - 2023-08-19 04:50:21 --> Helper loaded: my_helper
INFO - 2023-08-19 04:50:21 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:50:21 --> Controller Class Initialized
DEBUG - 2023-08-19 04:50:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 04:50:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:50:21 --> Final output sent to browser
DEBUG - 2023-08-19 04:50:21 --> Total execution time: 0.0873
INFO - 2023-08-19 04:53:54 --> Config Class Initialized
INFO - 2023-08-19 04:53:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:53:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:53:54 --> Utf8 Class Initialized
INFO - 2023-08-19 04:53:54 --> URI Class Initialized
INFO - 2023-08-19 04:53:54 --> Router Class Initialized
INFO - 2023-08-19 04:53:54 --> Output Class Initialized
INFO - 2023-08-19 04:53:54 --> Security Class Initialized
DEBUG - 2023-08-19 04:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:53:54 --> Input Class Initialized
INFO - 2023-08-19 04:53:54 --> Language Class Initialized
INFO - 2023-08-19 04:53:54 --> Language Class Initialized
INFO - 2023-08-19 04:53:54 --> Config Class Initialized
INFO - 2023-08-19 04:53:54 --> Loader Class Initialized
INFO - 2023-08-19 04:53:54 --> Helper loaded: url_helper
INFO - 2023-08-19 04:53:54 --> Helper loaded: file_helper
INFO - 2023-08-19 04:53:54 --> Helper loaded: form_helper
INFO - 2023-08-19 04:53:54 --> Helper loaded: my_helper
INFO - 2023-08-19 04:53:54 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:53:54 --> Controller Class Initialized
DEBUG - 2023-08-19 04:53:54 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 04:53:54 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:53:54 --> Final output sent to browser
DEBUG - 2023-08-19 04:53:54 --> Total execution time: 0.1344
INFO - 2023-08-19 04:54:12 --> Config Class Initialized
INFO - 2023-08-19 04:54:12 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:54:12 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:54:12 --> Utf8 Class Initialized
INFO - 2023-08-19 04:54:12 --> URI Class Initialized
INFO - 2023-08-19 04:54:12 --> Router Class Initialized
INFO - 2023-08-19 04:54:12 --> Output Class Initialized
INFO - 2023-08-19 04:54:12 --> Security Class Initialized
DEBUG - 2023-08-19 04:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:54:12 --> Input Class Initialized
INFO - 2023-08-19 04:54:12 --> Language Class Initialized
INFO - 2023-08-19 04:54:12 --> Language Class Initialized
INFO - 2023-08-19 04:54:12 --> Config Class Initialized
INFO - 2023-08-19 04:54:12 --> Loader Class Initialized
INFO - 2023-08-19 04:54:12 --> Helper loaded: url_helper
INFO - 2023-08-19 04:54:12 --> Helper loaded: file_helper
INFO - 2023-08-19 04:54:12 --> Helper loaded: form_helper
INFO - 2023-08-19 04:54:12 --> Helper loaded: my_helper
INFO - 2023-08-19 04:54:12 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:54:12 --> Controller Class Initialized
DEBUG - 2023-08-19 04:54:12 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 04:54:12 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:54:12 --> Final output sent to browser
DEBUG - 2023-08-19 04:54:12 --> Total execution time: 0.0294
INFO - 2023-08-19 04:54:21 --> Config Class Initialized
INFO - 2023-08-19 04:54:21 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:54:21 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:54:21 --> Utf8 Class Initialized
INFO - 2023-08-19 04:54:21 --> URI Class Initialized
INFO - 2023-08-19 04:54:21 --> Router Class Initialized
INFO - 2023-08-19 04:54:21 --> Output Class Initialized
INFO - 2023-08-19 04:54:21 --> Security Class Initialized
DEBUG - 2023-08-19 04:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:54:21 --> Input Class Initialized
INFO - 2023-08-19 04:54:21 --> Language Class Initialized
INFO - 2023-08-19 04:54:21 --> Language Class Initialized
INFO - 2023-08-19 04:54:21 --> Config Class Initialized
INFO - 2023-08-19 04:54:21 --> Loader Class Initialized
INFO - 2023-08-19 04:54:21 --> Helper loaded: url_helper
INFO - 2023-08-19 04:54:21 --> Helper loaded: file_helper
INFO - 2023-08-19 04:54:21 --> Helper loaded: form_helper
INFO - 2023-08-19 04:54:21 --> Helper loaded: my_helper
INFO - 2023-08-19 04:54:21 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:54:21 --> Controller Class Initialized
DEBUG - 2023-08-19 04:54:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-08-19 04:54:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:54:21 --> Final output sent to browser
DEBUG - 2023-08-19 04:54:21 --> Total execution time: 0.0454
INFO - 2023-08-19 04:54:21 --> Config Class Initialized
INFO - 2023-08-19 04:54:21 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:54:21 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:54:21 --> Utf8 Class Initialized
INFO - 2023-08-19 04:54:21 --> URI Class Initialized
INFO - 2023-08-19 04:54:21 --> Router Class Initialized
INFO - 2023-08-19 04:54:21 --> Output Class Initialized
INFO - 2023-08-19 04:54:21 --> Security Class Initialized
DEBUG - 2023-08-19 04:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:54:21 --> Input Class Initialized
INFO - 2023-08-19 04:54:21 --> Language Class Initialized
INFO - 2023-08-19 04:54:21 --> Language Class Initialized
INFO - 2023-08-19 04:54:21 --> Config Class Initialized
INFO - 2023-08-19 04:54:21 --> Loader Class Initialized
INFO - 2023-08-19 04:54:21 --> Helper loaded: url_helper
INFO - 2023-08-19 04:54:21 --> Helper loaded: file_helper
INFO - 2023-08-19 04:54:21 --> Helper loaded: form_helper
INFO - 2023-08-19 04:54:21 --> Helper loaded: my_helper
INFO - 2023-08-19 04:54:21 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:54:21 --> Controller Class Initialized
INFO - 2023-08-19 04:56:07 --> Config Class Initialized
INFO - 2023-08-19 04:56:07 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:56:07 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:56:07 --> Utf8 Class Initialized
INFO - 2023-08-19 04:56:07 --> URI Class Initialized
INFO - 2023-08-19 04:56:07 --> Router Class Initialized
INFO - 2023-08-19 04:56:07 --> Output Class Initialized
INFO - 2023-08-19 04:56:07 --> Security Class Initialized
DEBUG - 2023-08-19 04:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:56:07 --> Input Class Initialized
INFO - 2023-08-19 04:56:07 --> Language Class Initialized
INFO - 2023-08-19 04:56:07 --> Language Class Initialized
INFO - 2023-08-19 04:56:07 --> Config Class Initialized
INFO - 2023-08-19 04:56:07 --> Loader Class Initialized
INFO - 2023-08-19 04:56:07 --> Helper loaded: url_helper
INFO - 2023-08-19 04:56:07 --> Helper loaded: file_helper
INFO - 2023-08-19 04:56:07 --> Helper loaded: form_helper
INFO - 2023-08-19 04:56:07 --> Helper loaded: my_helper
INFO - 2023-08-19 04:56:07 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:56:07 --> Controller Class Initialized
DEBUG - 2023-08-19 04:56:07 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-08-19 04:56:07 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:56:07 --> Final output sent to browser
DEBUG - 2023-08-19 04:56:07 --> Total execution time: 0.0638
INFO - 2023-08-19 04:56:07 --> Config Class Initialized
INFO - 2023-08-19 04:56:07 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:56:07 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:56:07 --> Utf8 Class Initialized
INFO - 2023-08-19 04:56:07 --> URI Class Initialized
INFO - 2023-08-19 04:56:07 --> Router Class Initialized
INFO - 2023-08-19 04:56:07 --> Output Class Initialized
INFO - 2023-08-19 04:56:07 --> Security Class Initialized
DEBUG - 2023-08-19 04:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:56:07 --> Input Class Initialized
INFO - 2023-08-19 04:56:07 --> Language Class Initialized
INFO - 2023-08-19 04:56:07 --> Language Class Initialized
INFO - 2023-08-19 04:56:07 --> Config Class Initialized
INFO - 2023-08-19 04:56:07 --> Loader Class Initialized
INFO - 2023-08-19 04:56:07 --> Helper loaded: url_helper
INFO - 2023-08-19 04:56:07 --> Helper loaded: file_helper
INFO - 2023-08-19 04:56:07 --> Helper loaded: form_helper
INFO - 2023-08-19 04:56:07 --> Helper loaded: my_helper
INFO - 2023-08-19 04:56:07 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:56:07 --> Controller Class Initialized
INFO - 2023-08-19 04:56:08 --> Config Class Initialized
INFO - 2023-08-19 04:56:08 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:56:08 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:56:08 --> Utf8 Class Initialized
INFO - 2023-08-19 04:56:08 --> URI Class Initialized
INFO - 2023-08-19 04:56:08 --> Router Class Initialized
INFO - 2023-08-19 04:56:08 --> Output Class Initialized
INFO - 2023-08-19 04:56:08 --> Security Class Initialized
DEBUG - 2023-08-19 04:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:56:08 --> Input Class Initialized
INFO - 2023-08-19 04:56:08 --> Language Class Initialized
INFO - 2023-08-19 04:56:08 --> Language Class Initialized
INFO - 2023-08-19 04:56:08 --> Config Class Initialized
INFO - 2023-08-19 04:56:08 --> Loader Class Initialized
INFO - 2023-08-19 04:56:08 --> Helper loaded: url_helper
INFO - 2023-08-19 04:56:08 --> Helper loaded: file_helper
INFO - 2023-08-19 04:56:08 --> Helper loaded: form_helper
INFO - 2023-08-19 04:56:08 --> Helper loaded: my_helper
INFO - 2023-08-19 04:56:08 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:56:08 --> Controller Class Initialized
DEBUG - 2023-08-19 04:56:08 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 04:56:08 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:56:08 --> Final output sent to browser
DEBUG - 2023-08-19 04:56:08 --> Total execution time: 0.0270
INFO - 2023-08-19 04:56:18 --> Config Class Initialized
INFO - 2023-08-19 04:56:18 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:56:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:56:18 --> Utf8 Class Initialized
INFO - 2023-08-19 04:56:18 --> URI Class Initialized
INFO - 2023-08-19 04:56:18 --> Router Class Initialized
INFO - 2023-08-19 04:56:18 --> Output Class Initialized
INFO - 2023-08-19 04:56:18 --> Security Class Initialized
DEBUG - 2023-08-19 04:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:56:18 --> Input Class Initialized
INFO - 2023-08-19 04:56:18 --> Language Class Initialized
INFO - 2023-08-19 04:56:18 --> Language Class Initialized
INFO - 2023-08-19 04:56:18 --> Config Class Initialized
INFO - 2023-08-19 04:56:18 --> Loader Class Initialized
INFO - 2023-08-19 04:56:18 --> Helper loaded: url_helper
INFO - 2023-08-19 04:56:18 --> Helper loaded: file_helper
INFO - 2023-08-19 04:56:18 --> Helper loaded: form_helper
INFO - 2023-08-19 04:56:18 --> Helper loaded: my_helper
INFO - 2023-08-19 04:56:18 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:56:18 --> Controller Class Initialized
DEBUG - 2023-08-19 04:56:18 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 04:56:18 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:56:18 --> Final output sent to browser
DEBUG - 2023-08-19 04:56:18 --> Total execution time: 0.0259
INFO - 2023-08-19 04:56:19 --> Config Class Initialized
INFO - 2023-08-19 04:56:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:56:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:56:19 --> Utf8 Class Initialized
INFO - 2023-08-19 04:56:19 --> URI Class Initialized
INFO - 2023-08-19 04:56:19 --> Router Class Initialized
INFO - 2023-08-19 04:56:19 --> Output Class Initialized
INFO - 2023-08-19 04:56:19 --> Security Class Initialized
DEBUG - 2023-08-19 04:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:56:19 --> Input Class Initialized
INFO - 2023-08-19 04:56:19 --> Language Class Initialized
INFO - 2023-08-19 04:56:19 --> Language Class Initialized
INFO - 2023-08-19 04:56:19 --> Config Class Initialized
INFO - 2023-08-19 04:56:19 --> Loader Class Initialized
INFO - 2023-08-19 04:56:19 --> Helper loaded: url_helper
INFO - 2023-08-19 04:56:19 --> Helper loaded: file_helper
INFO - 2023-08-19 04:56:19 --> Helper loaded: form_helper
INFO - 2023-08-19 04:56:19 --> Helper loaded: my_helper
INFO - 2023-08-19 04:56:19 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:56:19 --> Controller Class Initialized
DEBUG - 2023-08-19 04:56:19 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-08-19 04:56:19 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:56:19 --> Final output sent to browser
DEBUG - 2023-08-19 04:56:19 --> Total execution time: 0.0487
INFO - 2023-08-19 04:56:19 --> Config Class Initialized
INFO - 2023-08-19 04:56:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:56:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:56:19 --> Utf8 Class Initialized
INFO - 2023-08-19 04:56:19 --> URI Class Initialized
INFO - 2023-08-19 04:56:19 --> Router Class Initialized
INFO - 2023-08-19 04:56:19 --> Output Class Initialized
INFO - 2023-08-19 04:56:19 --> Security Class Initialized
DEBUG - 2023-08-19 04:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:56:19 --> Input Class Initialized
INFO - 2023-08-19 04:56:19 --> Language Class Initialized
INFO - 2023-08-19 04:56:19 --> Language Class Initialized
INFO - 2023-08-19 04:56:19 --> Config Class Initialized
INFO - 2023-08-19 04:56:19 --> Loader Class Initialized
INFO - 2023-08-19 04:56:19 --> Helper loaded: url_helper
INFO - 2023-08-19 04:56:19 --> Helper loaded: file_helper
INFO - 2023-08-19 04:56:19 --> Helper loaded: form_helper
INFO - 2023-08-19 04:56:19 --> Helper loaded: my_helper
INFO - 2023-08-19 04:56:19 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:56:19 --> Controller Class Initialized
INFO - 2023-08-19 04:56:27 --> Config Class Initialized
INFO - 2023-08-19 04:56:27 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:56:27 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:56:27 --> Utf8 Class Initialized
INFO - 2023-08-19 04:56:27 --> URI Class Initialized
INFO - 2023-08-19 04:56:27 --> Router Class Initialized
INFO - 2023-08-19 04:56:27 --> Output Class Initialized
INFO - 2023-08-19 04:56:27 --> Security Class Initialized
DEBUG - 2023-08-19 04:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:56:27 --> Input Class Initialized
INFO - 2023-08-19 04:56:27 --> Language Class Initialized
INFO - 2023-08-19 04:56:27 --> Language Class Initialized
INFO - 2023-08-19 04:56:27 --> Config Class Initialized
INFO - 2023-08-19 04:56:27 --> Loader Class Initialized
INFO - 2023-08-19 04:56:27 --> Helper loaded: url_helper
INFO - 2023-08-19 04:56:27 --> Helper loaded: file_helper
INFO - 2023-08-19 04:56:27 --> Helper loaded: form_helper
INFO - 2023-08-19 04:56:27 --> Helper loaded: my_helper
INFO - 2023-08-19 04:56:27 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:56:27 --> Controller Class Initialized
DEBUG - 2023-08-19 04:56:27 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-08-19 04:56:27 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:56:27 --> Final output sent to browser
DEBUG - 2023-08-19 04:56:27 --> Total execution time: 0.0272
INFO - 2023-08-19 04:56:27 --> Config Class Initialized
INFO - 2023-08-19 04:56:27 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:56:27 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:56:27 --> Utf8 Class Initialized
INFO - 2023-08-19 04:56:27 --> URI Class Initialized
INFO - 2023-08-19 04:56:27 --> Router Class Initialized
INFO - 2023-08-19 04:56:27 --> Output Class Initialized
INFO - 2023-08-19 04:56:27 --> Security Class Initialized
DEBUG - 2023-08-19 04:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:56:27 --> Input Class Initialized
INFO - 2023-08-19 04:56:27 --> Language Class Initialized
INFO - 2023-08-19 04:56:27 --> Language Class Initialized
INFO - 2023-08-19 04:56:27 --> Config Class Initialized
INFO - 2023-08-19 04:56:27 --> Loader Class Initialized
INFO - 2023-08-19 04:56:27 --> Helper loaded: url_helper
INFO - 2023-08-19 04:56:27 --> Helper loaded: file_helper
INFO - 2023-08-19 04:56:27 --> Helper loaded: form_helper
INFO - 2023-08-19 04:56:27 --> Helper loaded: my_helper
INFO - 2023-08-19 04:56:27 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:56:27 --> Controller Class Initialized
INFO - 2023-08-19 04:56:37 --> Config Class Initialized
INFO - 2023-08-19 04:56:37 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:56:37 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:56:37 --> Utf8 Class Initialized
INFO - 2023-08-19 04:56:37 --> URI Class Initialized
INFO - 2023-08-19 04:56:37 --> Router Class Initialized
INFO - 2023-08-19 04:56:37 --> Output Class Initialized
INFO - 2023-08-19 04:56:37 --> Security Class Initialized
DEBUG - 2023-08-19 04:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:56:37 --> Input Class Initialized
INFO - 2023-08-19 04:56:37 --> Language Class Initialized
INFO - 2023-08-19 04:56:37 --> Language Class Initialized
INFO - 2023-08-19 04:56:37 --> Config Class Initialized
INFO - 2023-08-19 04:56:37 --> Loader Class Initialized
INFO - 2023-08-19 04:56:37 --> Helper loaded: url_helper
INFO - 2023-08-19 04:56:37 --> Helper loaded: file_helper
INFO - 2023-08-19 04:56:37 --> Helper loaded: form_helper
INFO - 2023-08-19 04:56:37 --> Helper loaded: my_helper
INFO - 2023-08-19 04:56:37 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:56:37 --> Controller Class Initialized
DEBUG - 2023-08-19 04:56:37 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-08-19 04:56:37 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:56:37 --> Final output sent to browser
DEBUG - 2023-08-19 04:56:37 --> Total execution time: 0.0507
INFO - 2023-08-19 04:56:37 --> Config Class Initialized
INFO - 2023-08-19 04:56:37 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:56:37 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:56:37 --> Utf8 Class Initialized
INFO - 2023-08-19 04:56:37 --> URI Class Initialized
INFO - 2023-08-19 04:56:37 --> Router Class Initialized
INFO - 2023-08-19 04:56:37 --> Output Class Initialized
INFO - 2023-08-19 04:56:37 --> Security Class Initialized
DEBUG - 2023-08-19 04:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:56:37 --> Input Class Initialized
INFO - 2023-08-19 04:56:37 --> Language Class Initialized
INFO - 2023-08-19 04:56:37 --> Language Class Initialized
INFO - 2023-08-19 04:56:37 --> Config Class Initialized
INFO - 2023-08-19 04:56:37 --> Loader Class Initialized
INFO - 2023-08-19 04:56:37 --> Helper loaded: url_helper
INFO - 2023-08-19 04:56:37 --> Helper loaded: file_helper
INFO - 2023-08-19 04:56:37 --> Helper loaded: form_helper
INFO - 2023-08-19 04:56:37 --> Helper loaded: my_helper
INFO - 2023-08-19 04:56:37 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:56:37 --> Controller Class Initialized
INFO - 2023-08-19 04:56:40 --> Config Class Initialized
INFO - 2023-08-19 04:56:40 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:56:40 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:56:40 --> Utf8 Class Initialized
INFO - 2023-08-19 04:56:40 --> URI Class Initialized
INFO - 2023-08-19 04:56:40 --> Router Class Initialized
INFO - 2023-08-19 04:56:40 --> Output Class Initialized
INFO - 2023-08-19 04:56:40 --> Security Class Initialized
DEBUG - 2023-08-19 04:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:56:40 --> Input Class Initialized
INFO - 2023-08-19 04:56:40 --> Language Class Initialized
INFO - 2023-08-19 04:56:40 --> Language Class Initialized
INFO - 2023-08-19 04:56:40 --> Config Class Initialized
INFO - 2023-08-19 04:56:40 --> Loader Class Initialized
INFO - 2023-08-19 04:56:40 --> Helper loaded: url_helper
INFO - 2023-08-19 04:56:40 --> Helper loaded: file_helper
INFO - 2023-08-19 04:56:40 --> Helper loaded: form_helper
INFO - 2023-08-19 04:56:40 --> Helper loaded: my_helper
INFO - 2023-08-19 04:56:40 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:56:40 --> Controller Class Initialized
DEBUG - 2023-08-19 04:56:40 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 04:56:40 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:56:40 --> Final output sent to browser
DEBUG - 2023-08-19 04:56:40 --> Total execution time: 0.0270
INFO - 2023-08-19 04:56:41 --> Config Class Initialized
INFO - 2023-08-19 04:56:41 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:56:41 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:56:41 --> Utf8 Class Initialized
INFO - 2023-08-19 04:56:41 --> URI Class Initialized
INFO - 2023-08-19 04:56:41 --> Router Class Initialized
INFO - 2023-08-19 04:56:41 --> Output Class Initialized
INFO - 2023-08-19 04:56:41 --> Security Class Initialized
DEBUG - 2023-08-19 04:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:56:41 --> Input Class Initialized
INFO - 2023-08-19 04:56:41 --> Language Class Initialized
INFO - 2023-08-19 04:56:41 --> Language Class Initialized
INFO - 2023-08-19 04:56:41 --> Config Class Initialized
INFO - 2023-08-19 04:56:41 --> Loader Class Initialized
INFO - 2023-08-19 04:56:41 --> Helper loaded: url_helper
INFO - 2023-08-19 04:56:41 --> Helper loaded: file_helper
INFO - 2023-08-19 04:56:41 --> Helper loaded: form_helper
INFO - 2023-08-19 04:56:41 --> Helper loaded: my_helper
INFO - 2023-08-19 04:56:41 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:56:41 --> Controller Class Initialized
DEBUG - 2023-08-19 04:56:41 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 04:56:41 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:56:41 --> Final output sent to browser
DEBUG - 2023-08-19 04:56:41 --> Total execution time: 0.0373
INFO - 2023-08-19 04:56:42 --> Config Class Initialized
INFO - 2023-08-19 04:56:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:56:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:56:42 --> Utf8 Class Initialized
INFO - 2023-08-19 04:56:42 --> URI Class Initialized
INFO - 2023-08-19 04:56:42 --> Router Class Initialized
INFO - 2023-08-19 04:56:42 --> Output Class Initialized
INFO - 2023-08-19 04:56:42 --> Security Class Initialized
DEBUG - 2023-08-19 04:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:56:42 --> Input Class Initialized
INFO - 2023-08-19 04:56:42 --> Language Class Initialized
INFO - 2023-08-19 04:56:42 --> Language Class Initialized
INFO - 2023-08-19 04:56:42 --> Config Class Initialized
INFO - 2023-08-19 04:56:42 --> Loader Class Initialized
INFO - 2023-08-19 04:56:42 --> Helper loaded: url_helper
INFO - 2023-08-19 04:56:42 --> Helper loaded: file_helper
INFO - 2023-08-19 04:56:42 --> Helper loaded: form_helper
INFO - 2023-08-19 04:56:42 --> Helper loaded: my_helper
INFO - 2023-08-19 04:56:42 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:56:42 --> Controller Class Initialized
DEBUG - 2023-08-19 04:56:42 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-08-19 04:56:42 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:56:42 --> Final output sent to browser
DEBUG - 2023-08-19 04:56:42 --> Total execution time: 0.0270
INFO - 2023-08-19 04:56:42 --> Config Class Initialized
INFO - 2023-08-19 04:56:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:56:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:56:42 --> Utf8 Class Initialized
INFO - 2023-08-19 04:56:42 --> URI Class Initialized
INFO - 2023-08-19 04:56:42 --> Router Class Initialized
INFO - 2023-08-19 04:56:42 --> Output Class Initialized
INFO - 2023-08-19 04:56:42 --> Security Class Initialized
DEBUG - 2023-08-19 04:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:56:42 --> Input Class Initialized
INFO - 2023-08-19 04:56:42 --> Language Class Initialized
INFO - 2023-08-19 04:56:42 --> Language Class Initialized
INFO - 2023-08-19 04:56:42 --> Config Class Initialized
INFO - 2023-08-19 04:56:42 --> Loader Class Initialized
INFO - 2023-08-19 04:56:42 --> Helper loaded: url_helper
INFO - 2023-08-19 04:56:42 --> Helper loaded: file_helper
INFO - 2023-08-19 04:56:42 --> Helper loaded: form_helper
INFO - 2023-08-19 04:56:42 --> Helper loaded: my_helper
INFO - 2023-08-19 04:56:42 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:56:42 --> Controller Class Initialized
INFO - 2023-08-19 04:57:03 --> Config Class Initialized
INFO - 2023-08-19 04:57:03 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:57:03 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:57:03 --> Utf8 Class Initialized
INFO - 2023-08-19 04:57:03 --> URI Class Initialized
INFO - 2023-08-19 04:57:03 --> Router Class Initialized
INFO - 2023-08-19 04:57:03 --> Output Class Initialized
INFO - 2023-08-19 04:57:03 --> Security Class Initialized
DEBUG - 2023-08-19 04:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:57:03 --> Input Class Initialized
INFO - 2023-08-19 04:57:03 --> Language Class Initialized
INFO - 2023-08-19 04:57:03 --> Language Class Initialized
INFO - 2023-08-19 04:57:03 --> Config Class Initialized
INFO - 2023-08-19 04:57:03 --> Loader Class Initialized
INFO - 2023-08-19 04:57:03 --> Helper loaded: url_helper
INFO - 2023-08-19 04:57:03 --> Helper loaded: file_helper
INFO - 2023-08-19 04:57:03 --> Helper loaded: form_helper
INFO - 2023-08-19 04:57:03 --> Helper loaded: my_helper
INFO - 2023-08-19 04:57:03 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:57:03 --> Controller Class Initialized
DEBUG - 2023-08-19 04:57:03 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-08-19 04:57:03 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:57:03 --> Final output sent to browser
DEBUG - 2023-08-19 04:57:03 --> Total execution time: 0.0626
INFO - 2023-08-19 04:57:03 --> Config Class Initialized
INFO - 2023-08-19 04:57:03 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:57:03 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:57:03 --> Utf8 Class Initialized
INFO - 2023-08-19 04:57:03 --> URI Class Initialized
INFO - 2023-08-19 04:57:03 --> Router Class Initialized
INFO - 2023-08-19 04:57:03 --> Output Class Initialized
INFO - 2023-08-19 04:57:03 --> Security Class Initialized
DEBUG - 2023-08-19 04:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:57:03 --> Input Class Initialized
INFO - 2023-08-19 04:57:03 --> Language Class Initialized
INFO - 2023-08-19 04:57:03 --> Language Class Initialized
INFO - 2023-08-19 04:57:03 --> Config Class Initialized
INFO - 2023-08-19 04:57:03 --> Loader Class Initialized
INFO - 2023-08-19 04:57:03 --> Helper loaded: url_helper
INFO - 2023-08-19 04:57:03 --> Helper loaded: file_helper
INFO - 2023-08-19 04:57:03 --> Helper loaded: form_helper
INFO - 2023-08-19 04:57:03 --> Helper loaded: my_helper
INFO - 2023-08-19 04:57:03 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:57:03 --> Controller Class Initialized
INFO - 2023-08-19 04:57:04 --> Config Class Initialized
INFO - 2023-08-19 04:57:04 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:57:04 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:57:04 --> Utf8 Class Initialized
INFO - 2023-08-19 04:57:04 --> URI Class Initialized
INFO - 2023-08-19 04:57:04 --> Router Class Initialized
INFO - 2023-08-19 04:57:04 --> Output Class Initialized
INFO - 2023-08-19 04:57:04 --> Security Class Initialized
DEBUG - 2023-08-19 04:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:57:04 --> Input Class Initialized
INFO - 2023-08-19 04:57:04 --> Language Class Initialized
INFO - 2023-08-19 04:57:04 --> Language Class Initialized
INFO - 2023-08-19 04:57:04 --> Config Class Initialized
INFO - 2023-08-19 04:57:04 --> Loader Class Initialized
INFO - 2023-08-19 04:57:04 --> Helper loaded: url_helper
INFO - 2023-08-19 04:57:04 --> Helper loaded: file_helper
INFO - 2023-08-19 04:57:04 --> Helper loaded: form_helper
INFO - 2023-08-19 04:57:04 --> Helper loaded: my_helper
INFO - 2023-08-19 04:57:04 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:57:04 --> Controller Class Initialized
DEBUG - 2023-08-19 04:57:04 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 04:57:04 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:57:04 --> Final output sent to browser
DEBUG - 2023-08-19 04:57:04 --> Total execution time: 0.0254
INFO - 2023-08-19 04:57:15 --> Config Class Initialized
INFO - 2023-08-19 04:57:15 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:57:15 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:57:15 --> Utf8 Class Initialized
INFO - 2023-08-19 04:57:15 --> URI Class Initialized
INFO - 2023-08-19 04:57:15 --> Router Class Initialized
INFO - 2023-08-19 04:57:15 --> Output Class Initialized
INFO - 2023-08-19 04:57:15 --> Security Class Initialized
DEBUG - 2023-08-19 04:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:57:15 --> Input Class Initialized
INFO - 2023-08-19 04:57:15 --> Language Class Initialized
INFO - 2023-08-19 04:57:15 --> Language Class Initialized
INFO - 2023-08-19 04:57:15 --> Config Class Initialized
INFO - 2023-08-19 04:57:15 --> Loader Class Initialized
INFO - 2023-08-19 04:57:15 --> Helper loaded: url_helper
INFO - 2023-08-19 04:57:15 --> Helper loaded: file_helper
INFO - 2023-08-19 04:57:15 --> Helper loaded: form_helper
INFO - 2023-08-19 04:57:15 --> Helper loaded: my_helper
INFO - 2023-08-19 04:57:15 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:57:15 --> Controller Class Initialized
INFO - 2023-08-19 04:57:15 --> Helper loaded: cookie_helper
INFO - 2023-08-19 04:57:15 --> Config Class Initialized
INFO - 2023-08-19 04:57:15 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:57:15 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:57:15 --> Utf8 Class Initialized
INFO - 2023-08-19 04:57:15 --> URI Class Initialized
INFO - 2023-08-19 04:57:15 --> Router Class Initialized
INFO - 2023-08-19 04:57:15 --> Output Class Initialized
INFO - 2023-08-19 04:57:15 --> Security Class Initialized
DEBUG - 2023-08-19 04:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:57:15 --> Input Class Initialized
INFO - 2023-08-19 04:57:15 --> Language Class Initialized
INFO - 2023-08-19 04:57:15 --> Language Class Initialized
INFO - 2023-08-19 04:57:15 --> Config Class Initialized
INFO - 2023-08-19 04:57:15 --> Loader Class Initialized
INFO - 2023-08-19 04:57:15 --> Helper loaded: url_helper
INFO - 2023-08-19 04:57:15 --> Helper loaded: file_helper
INFO - 2023-08-19 04:57:15 --> Helper loaded: form_helper
INFO - 2023-08-19 04:57:15 --> Helper loaded: my_helper
INFO - 2023-08-19 04:57:15 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:57:15 --> Controller Class Initialized
INFO - 2023-08-19 04:57:15 --> Config Class Initialized
INFO - 2023-08-19 04:57:15 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:57:15 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:57:15 --> Utf8 Class Initialized
INFO - 2023-08-19 04:57:15 --> URI Class Initialized
INFO - 2023-08-19 04:57:15 --> Router Class Initialized
INFO - 2023-08-19 04:57:15 --> Output Class Initialized
INFO - 2023-08-19 04:57:15 --> Security Class Initialized
DEBUG - 2023-08-19 04:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:57:15 --> Input Class Initialized
INFO - 2023-08-19 04:57:15 --> Language Class Initialized
INFO - 2023-08-19 04:57:15 --> Language Class Initialized
INFO - 2023-08-19 04:57:15 --> Config Class Initialized
INFO - 2023-08-19 04:57:15 --> Loader Class Initialized
INFO - 2023-08-19 04:57:15 --> Helper loaded: url_helper
INFO - 2023-08-19 04:57:15 --> Helper loaded: file_helper
INFO - 2023-08-19 04:57:15 --> Helper loaded: form_helper
INFO - 2023-08-19 04:57:15 --> Helper loaded: my_helper
INFO - 2023-08-19 04:57:15 --> Database Driver Class Initialized
DEBUG - 2023-08-19 04:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 04:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:57:16 --> Controller Class Initialized
DEBUG - 2023-08-19 04:57:16 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/login/views/login.php
DEBUG - 2023-08-19 04:57:16 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 04:57:16 --> Final output sent to browser
DEBUG - 2023-08-19 04:57:16 --> Total execution time: 0.0424
INFO - 2023-08-19 05:06:31 --> Config Class Initialized
INFO - 2023-08-19 05:06:31 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:06:31 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:06:31 --> Utf8 Class Initialized
INFO - 2023-08-19 05:06:31 --> URI Class Initialized
INFO - 2023-08-19 05:06:31 --> Router Class Initialized
INFO - 2023-08-19 05:06:31 --> Output Class Initialized
INFO - 2023-08-19 05:06:31 --> Security Class Initialized
DEBUG - 2023-08-19 05:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:06:31 --> Input Class Initialized
INFO - 2023-08-19 05:06:31 --> Language Class Initialized
INFO - 2023-08-19 05:06:31 --> Language Class Initialized
INFO - 2023-08-19 05:06:31 --> Config Class Initialized
INFO - 2023-08-19 05:06:31 --> Loader Class Initialized
INFO - 2023-08-19 05:06:31 --> Helper loaded: url_helper
INFO - 2023-08-19 05:06:31 --> Helper loaded: file_helper
INFO - 2023-08-19 05:06:31 --> Helper loaded: form_helper
INFO - 2023-08-19 05:06:31 --> Helper loaded: my_helper
INFO - 2023-08-19 05:06:31 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:06:31 --> Controller Class Initialized
INFO - 2023-08-19 05:06:31 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:06:31 --> Final output sent to browser
DEBUG - 2023-08-19 05:06:31 --> Total execution time: 0.0435
INFO - 2023-08-19 05:06:31 --> Config Class Initialized
INFO - 2023-08-19 05:06:31 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:06:31 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:06:31 --> Utf8 Class Initialized
INFO - 2023-08-19 05:06:31 --> URI Class Initialized
INFO - 2023-08-19 05:06:31 --> Router Class Initialized
INFO - 2023-08-19 05:06:31 --> Output Class Initialized
INFO - 2023-08-19 05:06:31 --> Security Class Initialized
DEBUG - 2023-08-19 05:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:06:31 --> Input Class Initialized
INFO - 2023-08-19 05:06:31 --> Language Class Initialized
INFO - 2023-08-19 05:06:31 --> Language Class Initialized
INFO - 2023-08-19 05:06:31 --> Config Class Initialized
INFO - 2023-08-19 05:06:31 --> Loader Class Initialized
INFO - 2023-08-19 05:06:31 --> Helper loaded: url_helper
INFO - 2023-08-19 05:06:31 --> Helper loaded: file_helper
INFO - 2023-08-19 05:06:31 --> Helper loaded: form_helper
INFO - 2023-08-19 05:06:31 --> Helper loaded: my_helper
INFO - 2023-08-19 05:06:31 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:06:31 --> Controller Class Initialized
DEBUG - 2023-08-19 05:06:31 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 05:06:31 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 05:06:31 --> Final output sent to browser
DEBUG - 2023-08-19 05:06:31 --> Total execution time: 0.0349
INFO - 2023-08-19 05:06:34 --> Config Class Initialized
INFO - 2023-08-19 05:06:34 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:06:34 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:06:34 --> Utf8 Class Initialized
INFO - 2023-08-19 05:06:34 --> URI Class Initialized
INFO - 2023-08-19 05:06:34 --> Router Class Initialized
INFO - 2023-08-19 05:06:34 --> Output Class Initialized
INFO - 2023-08-19 05:06:34 --> Security Class Initialized
DEBUG - 2023-08-19 05:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:06:34 --> Input Class Initialized
INFO - 2023-08-19 05:06:34 --> Language Class Initialized
INFO - 2023-08-19 05:06:34 --> Language Class Initialized
INFO - 2023-08-19 05:06:34 --> Config Class Initialized
INFO - 2023-08-19 05:06:34 --> Loader Class Initialized
INFO - 2023-08-19 05:06:34 --> Helper loaded: url_helper
INFO - 2023-08-19 05:06:34 --> Helper loaded: file_helper
INFO - 2023-08-19 05:06:34 --> Helper loaded: form_helper
INFO - 2023-08-19 05:06:34 --> Helper loaded: my_helper
INFO - 2023-08-19 05:06:34 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:06:34 --> Controller Class Initialized
DEBUG - 2023-08-19 05:06:34 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-08-19 05:06:34 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 05:06:34 --> Final output sent to browser
DEBUG - 2023-08-19 05:06:34 --> Total execution time: 0.0318
INFO - 2023-08-19 05:06:36 --> Config Class Initialized
INFO - 2023-08-19 05:06:36 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:06:36 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:06:36 --> Utf8 Class Initialized
INFO - 2023-08-19 05:06:36 --> URI Class Initialized
INFO - 2023-08-19 05:06:36 --> Router Class Initialized
INFO - 2023-08-19 05:06:36 --> Output Class Initialized
INFO - 2023-08-19 05:06:36 --> Security Class Initialized
DEBUG - 2023-08-19 05:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:06:36 --> Input Class Initialized
INFO - 2023-08-19 05:06:36 --> Language Class Initialized
INFO - 2023-08-19 05:06:36 --> Language Class Initialized
INFO - 2023-08-19 05:06:36 --> Config Class Initialized
INFO - 2023-08-19 05:06:36 --> Loader Class Initialized
INFO - 2023-08-19 05:06:36 --> Helper loaded: url_helper
INFO - 2023-08-19 05:06:36 --> Helper loaded: file_helper
INFO - 2023-08-19 05:06:36 --> Helper loaded: form_helper
INFO - 2023-08-19 05:06:36 --> Helper loaded: my_helper
INFO - 2023-08-19 05:06:36 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:06:36 --> Controller Class Initialized
DEBUG - 2023-08-19 05:06:36 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-08-19 05:06:37 --> Final output sent to browser
DEBUG - 2023-08-19 05:06:37 --> Total execution time: 1.0073
INFO - 2023-08-19 05:09:53 --> Config Class Initialized
INFO - 2023-08-19 05:09:53 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:09:53 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:09:53 --> Utf8 Class Initialized
INFO - 2023-08-19 05:09:53 --> URI Class Initialized
INFO - 2023-08-19 05:09:53 --> Router Class Initialized
INFO - 2023-08-19 05:09:53 --> Output Class Initialized
INFO - 2023-08-19 05:09:53 --> Security Class Initialized
DEBUG - 2023-08-19 05:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:09:53 --> Input Class Initialized
INFO - 2023-08-19 05:09:53 --> Language Class Initialized
INFO - 2023-08-19 05:09:53 --> Language Class Initialized
INFO - 2023-08-19 05:09:53 --> Config Class Initialized
INFO - 2023-08-19 05:09:53 --> Loader Class Initialized
INFO - 2023-08-19 05:09:53 --> Helper loaded: url_helper
INFO - 2023-08-19 05:09:53 --> Helper loaded: file_helper
INFO - 2023-08-19 05:09:53 --> Helper loaded: form_helper
INFO - 2023-08-19 05:09:53 --> Helper loaded: my_helper
INFO - 2023-08-19 05:09:53 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:09:53 --> Controller Class Initialized
DEBUG - 2023-08-19 05:09:53 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 05:09:53 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 05:09:53 --> Final output sent to browser
DEBUG - 2023-08-19 05:09:53 --> Total execution time: 0.0390
INFO - 2023-08-19 05:09:57 --> Config Class Initialized
INFO - 2023-08-19 05:09:57 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:09:57 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:09:57 --> Utf8 Class Initialized
INFO - 2023-08-19 05:09:57 --> URI Class Initialized
INFO - 2023-08-19 05:09:57 --> Router Class Initialized
INFO - 2023-08-19 05:09:57 --> Output Class Initialized
INFO - 2023-08-19 05:09:57 --> Security Class Initialized
DEBUG - 2023-08-19 05:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:09:57 --> Input Class Initialized
INFO - 2023-08-19 05:09:57 --> Language Class Initialized
INFO - 2023-08-19 05:09:57 --> Language Class Initialized
INFO - 2023-08-19 05:09:57 --> Config Class Initialized
INFO - 2023-08-19 05:09:57 --> Loader Class Initialized
INFO - 2023-08-19 05:09:57 --> Helper loaded: url_helper
INFO - 2023-08-19 05:09:57 --> Helper loaded: file_helper
INFO - 2023-08-19 05:09:57 --> Helper loaded: form_helper
INFO - 2023-08-19 05:09:57 --> Helper loaded: my_helper
INFO - 2023-08-19 05:09:57 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:09:58 --> Controller Class Initialized
INFO - 2023-08-19 05:09:58 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:09:58 --> Config Class Initialized
INFO - 2023-08-19 05:09:58 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:09:58 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:09:58 --> Utf8 Class Initialized
INFO - 2023-08-19 05:09:58 --> URI Class Initialized
INFO - 2023-08-19 05:09:58 --> Router Class Initialized
INFO - 2023-08-19 05:09:58 --> Output Class Initialized
INFO - 2023-08-19 05:09:58 --> Security Class Initialized
DEBUG - 2023-08-19 05:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:09:58 --> Input Class Initialized
INFO - 2023-08-19 05:09:58 --> Language Class Initialized
INFO - 2023-08-19 05:09:58 --> Language Class Initialized
INFO - 2023-08-19 05:09:58 --> Config Class Initialized
INFO - 2023-08-19 05:09:58 --> Loader Class Initialized
INFO - 2023-08-19 05:09:58 --> Helper loaded: url_helper
INFO - 2023-08-19 05:09:58 --> Helper loaded: file_helper
INFO - 2023-08-19 05:09:58 --> Helper loaded: form_helper
INFO - 2023-08-19 05:09:58 --> Helper loaded: my_helper
INFO - 2023-08-19 05:09:58 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:09:58 --> Controller Class Initialized
INFO - 2023-08-19 05:09:58 --> Config Class Initialized
INFO - 2023-08-19 05:09:58 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:09:58 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:09:58 --> Utf8 Class Initialized
INFO - 2023-08-19 05:09:58 --> URI Class Initialized
INFO - 2023-08-19 05:09:58 --> Router Class Initialized
INFO - 2023-08-19 05:09:58 --> Output Class Initialized
INFO - 2023-08-19 05:09:58 --> Security Class Initialized
DEBUG - 2023-08-19 05:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:09:58 --> Input Class Initialized
INFO - 2023-08-19 05:09:58 --> Language Class Initialized
INFO - 2023-08-19 05:09:58 --> Language Class Initialized
INFO - 2023-08-19 05:09:58 --> Config Class Initialized
INFO - 2023-08-19 05:09:58 --> Loader Class Initialized
INFO - 2023-08-19 05:09:58 --> Helper loaded: url_helper
INFO - 2023-08-19 05:09:58 --> Helper loaded: file_helper
INFO - 2023-08-19 05:09:58 --> Helper loaded: form_helper
INFO - 2023-08-19 05:09:58 --> Helper loaded: my_helper
INFO - 2023-08-19 05:09:58 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:09:58 --> Controller Class Initialized
DEBUG - 2023-08-19 05:09:58 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/login/views/login.php
DEBUG - 2023-08-19 05:09:58 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 05:09:58 --> Final output sent to browser
DEBUG - 2023-08-19 05:09:58 --> Total execution time: 0.0406
INFO - 2023-08-19 05:10:03 --> Config Class Initialized
INFO - 2023-08-19 05:10:03 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:10:03 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:10:03 --> Utf8 Class Initialized
INFO - 2023-08-19 05:10:03 --> URI Class Initialized
INFO - 2023-08-19 05:10:03 --> Router Class Initialized
INFO - 2023-08-19 05:10:03 --> Output Class Initialized
INFO - 2023-08-19 05:10:03 --> Security Class Initialized
DEBUG - 2023-08-19 05:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:10:03 --> Input Class Initialized
INFO - 2023-08-19 05:10:03 --> Language Class Initialized
INFO - 2023-08-19 05:10:03 --> Language Class Initialized
INFO - 2023-08-19 05:10:03 --> Config Class Initialized
INFO - 2023-08-19 05:10:03 --> Loader Class Initialized
INFO - 2023-08-19 05:10:03 --> Helper loaded: url_helper
INFO - 2023-08-19 05:10:03 --> Helper loaded: file_helper
INFO - 2023-08-19 05:10:03 --> Helper loaded: form_helper
INFO - 2023-08-19 05:10:03 --> Helper loaded: my_helper
INFO - 2023-08-19 05:10:03 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:10:03 --> Controller Class Initialized
INFO - 2023-08-19 05:10:03 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:10:03 --> Final output sent to browser
DEBUG - 2023-08-19 05:10:03 --> Total execution time: 0.0256
INFO - 2023-08-19 05:10:03 --> Config Class Initialized
INFO - 2023-08-19 05:10:03 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:10:03 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:10:03 --> Utf8 Class Initialized
INFO - 2023-08-19 05:10:03 --> URI Class Initialized
INFO - 2023-08-19 05:10:03 --> Router Class Initialized
INFO - 2023-08-19 05:10:03 --> Output Class Initialized
INFO - 2023-08-19 05:10:03 --> Security Class Initialized
DEBUG - 2023-08-19 05:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:10:03 --> Input Class Initialized
INFO - 2023-08-19 05:10:03 --> Language Class Initialized
INFO - 2023-08-19 05:10:03 --> Language Class Initialized
INFO - 2023-08-19 05:10:03 --> Config Class Initialized
INFO - 2023-08-19 05:10:03 --> Loader Class Initialized
INFO - 2023-08-19 05:10:03 --> Helper loaded: url_helper
INFO - 2023-08-19 05:10:03 --> Helper loaded: file_helper
INFO - 2023-08-19 05:10:03 --> Helper loaded: form_helper
INFO - 2023-08-19 05:10:03 --> Helper loaded: my_helper
INFO - 2023-08-19 05:10:03 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:10:03 --> Controller Class Initialized
DEBUG - 2023-08-19 05:10:03 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home.php
DEBUG - 2023-08-19 05:10:03 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 05:10:03 --> Final output sent to browser
DEBUG - 2023-08-19 05:10:03 --> Total execution time: 0.0310
INFO - 2023-08-19 05:10:06 --> Config Class Initialized
INFO - 2023-08-19 05:10:06 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:10:06 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:10:06 --> Utf8 Class Initialized
INFO - 2023-08-19 05:10:06 --> URI Class Initialized
INFO - 2023-08-19 05:10:06 --> Router Class Initialized
INFO - 2023-08-19 05:10:06 --> Output Class Initialized
INFO - 2023-08-19 05:10:06 --> Security Class Initialized
DEBUG - 2023-08-19 05:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:10:06 --> Input Class Initialized
INFO - 2023-08-19 05:10:06 --> Language Class Initialized
INFO - 2023-08-19 05:10:06 --> Language Class Initialized
INFO - 2023-08-19 05:10:06 --> Config Class Initialized
INFO - 2023-08-19 05:10:06 --> Loader Class Initialized
INFO - 2023-08-19 05:10:06 --> Helper loaded: url_helper
INFO - 2023-08-19 05:10:06 --> Helper loaded: file_helper
INFO - 2023-08-19 05:10:06 --> Helper loaded: form_helper
INFO - 2023-08-19 05:10:06 --> Helper loaded: my_helper
INFO - 2023-08-19 05:10:06 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:10:06 --> Controller Class Initialized
DEBUG - 2023-08-19 05:10:06 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/data_mapel/views/list.php
DEBUG - 2023-08-19 05:10:06 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 05:10:06 --> Final output sent to browser
DEBUG - 2023-08-19 05:10:06 --> Total execution time: 0.0262
INFO - 2023-08-19 05:10:06 --> Config Class Initialized
INFO - 2023-08-19 05:10:06 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:10:06 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:10:06 --> Utf8 Class Initialized
INFO - 2023-08-19 05:10:06 --> URI Class Initialized
INFO - 2023-08-19 05:10:06 --> Router Class Initialized
INFO - 2023-08-19 05:10:06 --> Output Class Initialized
INFO - 2023-08-19 05:10:06 --> Security Class Initialized
DEBUG - 2023-08-19 05:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:10:06 --> Input Class Initialized
INFO - 2023-08-19 05:10:06 --> Language Class Initialized
INFO - 2023-08-19 05:10:06 --> Language Class Initialized
INFO - 2023-08-19 05:10:06 --> Config Class Initialized
INFO - 2023-08-19 05:10:06 --> Loader Class Initialized
INFO - 2023-08-19 05:10:06 --> Helper loaded: url_helper
INFO - 2023-08-19 05:10:06 --> Helper loaded: file_helper
INFO - 2023-08-19 05:10:06 --> Helper loaded: form_helper
INFO - 2023-08-19 05:10:06 --> Helper loaded: my_helper
INFO - 2023-08-19 05:10:06 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:10:06 --> Controller Class Initialized
INFO - 2023-08-19 05:10:09 --> Config Class Initialized
INFO - 2023-08-19 05:10:09 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:10:09 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:10:09 --> Utf8 Class Initialized
INFO - 2023-08-19 05:10:09 --> URI Class Initialized
INFO - 2023-08-19 05:10:09 --> Router Class Initialized
INFO - 2023-08-19 05:10:09 --> Output Class Initialized
INFO - 2023-08-19 05:10:09 --> Security Class Initialized
DEBUG - 2023-08-19 05:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:10:09 --> Input Class Initialized
INFO - 2023-08-19 05:10:09 --> Language Class Initialized
INFO - 2023-08-19 05:10:09 --> Language Class Initialized
INFO - 2023-08-19 05:10:09 --> Config Class Initialized
INFO - 2023-08-19 05:10:09 --> Loader Class Initialized
INFO - 2023-08-19 05:10:09 --> Helper loaded: url_helper
INFO - 2023-08-19 05:10:09 --> Helper loaded: file_helper
INFO - 2023-08-19 05:10:09 --> Helper loaded: form_helper
INFO - 2023-08-19 05:10:09 --> Helper loaded: my_helper
INFO - 2023-08-19 05:10:09 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:10:09 --> Controller Class Initialized
INFO - 2023-08-19 05:10:09 --> Final output sent to browser
DEBUG - 2023-08-19 05:10:09 --> Total execution time: 0.0513
INFO - 2023-08-19 05:10:15 --> Config Class Initialized
INFO - 2023-08-19 05:10:15 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:10:15 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:10:15 --> Utf8 Class Initialized
INFO - 2023-08-19 05:10:15 --> URI Class Initialized
INFO - 2023-08-19 05:10:15 --> Router Class Initialized
INFO - 2023-08-19 05:10:15 --> Output Class Initialized
INFO - 2023-08-19 05:10:15 --> Security Class Initialized
DEBUG - 2023-08-19 05:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:10:15 --> Input Class Initialized
INFO - 2023-08-19 05:10:15 --> Language Class Initialized
INFO - 2023-08-19 05:10:15 --> Language Class Initialized
INFO - 2023-08-19 05:10:15 --> Config Class Initialized
INFO - 2023-08-19 05:10:15 --> Loader Class Initialized
INFO - 2023-08-19 05:10:15 --> Helper loaded: url_helper
INFO - 2023-08-19 05:10:15 --> Helper loaded: file_helper
INFO - 2023-08-19 05:10:15 --> Helper loaded: form_helper
INFO - 2023-08-19 05:10:15 --> Helper loaded: my_helper
INFO - 2023-08-19 05:10:15 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:10:15 --> Controller Class Initialized
INFO - 2023-08-19 05:10:15 --> Final output sent to browser
DEBUG - 2023-08-19 05:10:15 --> Total execution time: 0.0499
INFO - 2023-08-19 05:10:23 --> Config Class Initialized
INFO - 2023-08-19 05:10:23 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:10:23 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:10:23 --> Utf8 Class Initialized
INFO - 2023-08-19 05:10:23 --> URI Class Initialized
INFO - 2023-08-19 05:10:23 --> Router Class Initialized
INFO - 2023-08-19 05:10:23 --> Output Class Initialized
INFO - 2023-08-19 05:10:23 --> Security Class Initialized
DEBUG - 2023-08-19 05:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:10:23 --> Input Class Initialized
INFO - 2023-08-19 05:10:23 --> Language Class Initialized
INFO - 2023-08-19 05:10:23 --> Language Class Initialized
INFO - 2023-08-19 05:10:23 --> Config Class Initialized
INFO - 2023-08-19 05:10:23 --> Loader Class Initialized
INFO - 2023-08-19 05:10:23 --> Helper loaded: url_helper
INFO - 2023-08-19 05:10:23 --> Helper loaded: file_helper
INFO - 2023-08-19 05:10:23 --> Helper loaded: form_helper
INFO - 2023-08-19 05:10:23 --> Helper loaded: my_helper
INFO - 2023-08-19 05:10:23 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:10:23 --> Controller Class Initialized
INFO - 2023-08-19 05:10:23 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:10:23 --> Config Class Initialized
INFO - 2023-08-19 05:10:23 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:10:23 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:10:23 --> Utf8 Class Initialized
INFO - 2023-08-19 05:10:23 --> URI Class Initialized
INFO - 2023-08-19 05:10:23 --> Router Class Initialized
INFO - 2023-08-19 05:10:23 --> Output Class Initialized
INFO - 2023-08-19 05:10:23 --> Security Class Initialized
DEBUG - 2023-08-19 05:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:10:23 --> Input Class Initialized
INFO - 2023-08-19 05:10:23 --> Language Class Initialized
INFO - 2023-08-19 05:10:23 --> Language Class Initialized
INFO - 2023-08-19 05:10:23 --> Config Class Initialized
INFO - 2023-08-19 05:10:23 --> Loader Class Initialized
INFO - 2023-08-19 05:10:23 --> Helper loaded: url_helper
INFO - 2023-08-19 05:10:23 --> Helper loaded: file_helper
INFO - 2023-08-19 05:10:23 --> Helper loaded: form_helper
INFO - 2023-08-19 05:10:23 --> Helper loaded: my_helper
INFO - 2023-08-19 05:10:23 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:10:23 --> Controller Class Initialized
INFO - 2023-08-19 05:10:23 --> Config Class Initialized
INFO - 2023-08-19 05:10:23 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:10:23 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:10:23 --> Utf8 Class Initialized
INFO - 2023-08-19 05:10:23 --> URI Class Initialized
INFO - 2023-08-19 05:10:23 --> Router Class Initialized
INFO - 2023-08-19 05:10:23 --> Output Class Initialized
INFO - 2023-08-19 05:10:23 --> Security Class Initialized
DEBUG - 2023-08-19 05:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:10:23 --> Input Class Initialized
INFO - 2023-08-19 05:10:23 --> Language Class Initialized
INFO - 2023-08-19 05:10:23 --> Language Class Initialized
INFO - 2023-08-19 05:10:23 --> Config Class Initialized
INFO - 2023-08-19 05:10:23 --> Loader Class Initialized
INFO - 2023-08-19 05:10:23 --> Helper loaded: url_helper
INFO - 2023-08-19 05:10:23 --> Helper loaded: file_helper
INFO - 2023-08-19 05:10:23 --> Helper loaded: form_helper
INFO - 2023-08-19 05:10:23 --> Helper loaded: my_helper
INFO - 2023-08-19 05:10:23 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:10:23 --> Controller Class Initialized
DEBUG - 2023-08-19 05:10:23 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/login/views/login.php
DEBUG - 2023-08-19 05:10:23 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 05:10:23 --> Final output sent to browser
DEBUG - 2023-08-19 05:10:23 --> Total execution time: 0.0232
INFO - 2023-08-19 05:10:27 --> Config Class Initialized
INFO - 2023-08-19 05:10:27 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:10:27 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:10:27 --> Utf8 Class Initialized
INFO - 2023-08-19 05:10:27 --> URI Class Initialized
INFO - 2023-08-19 05:10:27 --> Router Class Initialized
INFO - 2023-08-19 05:10:27 --> Output Class Initialized
INFO - 2023-08-19 05:10:27 --> Security Class Initialized
DEBUG - 2023-08-19 05:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:10:27 --> Input Class Initialized
INFO - 2023-08-19 05:10:27 --> Language Class Initialized
INFO - 2023-08-19 05:10:27 --> Language Class Initialized
INFO - 2023-08-19 05:10:27 --> Config Class Initialized
INFO - 2023-08-19 05:10:27 --> Loader Class Initialized
INFO - 2023-08-19 05:10:27 --> Helper loaded: url_helper
INFO - 2023-08-19 05:10:27 --> Helper loaded: file_helper
INFO - 2023-08-19 05:10:27 --> Helper loaded: form_helper
INFO - 2023-08-19 05:10:27 --> Helper loaded: my_helper
INFO - 2023-08-19 05:10:27 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:10:27 --> Controller Class Initialized
INFO - 2023-08-19 05:10:27 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:10:27 --> Final output sent to browser
DEBUG - 2023-08-19 05:10:27 --> Total execution time: 0.0411
INFO - 2023-08-19 05:10:27 --> Config Class Initialized
INFO - 2023-08-19 05:10:27 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:10:27 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:10:27 --> Utf8 Class Initialized
INFO - 2023-08-19 05:10:27 --> URI Class Initialized
INFO - 2023-08-19 05:10:27 --> Router Class Initialized
INFO - 2023-08-19 05:10:27 --> Output Class Initialized
INFO - 2023-08-19 05:10:27 --> Security Class Initialized
DEBUG - 2023-08-19 05:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:10:27 --> Input Class Initialized
INFO - 2023-08-19 05:10:27 --> Language Class Initialized
INFO - 2023-08-19 05:10:27 --> Language Class Initialized
INFO - 2023-08-19 05:10:27 --> Config Class Initialized
INFO - 2023-08-19 05:10:27 --> Loader Class Initialized
INFO - 2023-08-19 05:10:27 --> Helper loaded: url_helper
INFO - 2023-08-19 05:10:27 --> Helper loaded: file_helper
INFO - 2023-08-19 05:10:27 --> Helper loaded: form_helper
INFO - 2023-08-19 05:10:27 --> Helper loaded: my_helper
INFO - 2023-08-19 05:10:27 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:10:27 --> Controller Class Initialized
DEBUG - 2023-08-19 05:10:27 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 05:10:27 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 05:10:27 --> Final output sent to browser
DEBUG - 2023-08-19 05:10:27 --> Total execution time: 0.0493
INFO - 2023-08-19 05:15:38 --> Config Class Initialized
INFO - 2023-08-19 05:15:38 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:15:38 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:15:38 --> Utf8 Class Initialized
INFO - 2023-08-19 05:15:38 --> URI Class Initialized
INFO - 2023-08-19 05:15:38 --> Router Class Initialized
INFO - 2023-08-19 05:15:38 --> Output Class Initialized
INFO - 2023-08-19 05:15:38 --> Security Class Initialized
DEBUG - 2023-08-19 05:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:15:38 --> Input Class Initialized
INFO - 2023-08-19 05:15:38 --> Language Class Initialized
INFO - 2023-08-19 05:15:38 --> Language Class Initialized
INFO - 2023-08-19 05:15:38 --> Config Class Initialized
INFO - 2023-08-19 05:15:38 --> Loader Class Initialized
INFO - 2023-08-19 05:15:38 --> Helper loaded: url_helper
INFO - 2023-08-19 05:15:38 --> Helper loaded: file_helper
INFO - 2023-08-19 05:15:38 --> Helper loaded: form_helper
INFO - 2023-08-19 05:15:38 --> Helper loaded: my_helper
INFO - 2023-08-19 05:15:38 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:15:38 --> Controller Class Initialized
DEBUG - 2023-08-19 05:15:38 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-08-19 05:15:39 --> Final output sent to browser
DEBUG - 2023-08-19 05:15:39 --> Total execution time: 0.9405
INFO - 2023-08-19 05:45:58 --> Config Class Initialized
INFO - 2023-08-19 05:45:58 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:45:58 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:45:58 --> Utf8 Class Initialized
INFO - 2023-08-19 05:45:58 --> URI Class Initialized
INFO - 2023-08-19 05:45:58 --> Router Class Initialized
INFO - 2023-08-19 05:45:58 --> Output Class Initialized
INFO - 2023-08-19 05:45:58 --> Security Class Initialized
DEBUG - 2023-08-19 05:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:45:58 --> Input Class Initialized
INFO - 2023-08-19 05:45:58 --> Language Class Initialized
INFO - 2023-08-19 05:45:59 --> Language Class Initialized
INFO - 2023-08-19 05:45:59 --> Config Class Initialized
INFO - 2023-08-19 05:45:59 --> Loader Class Initialized
INFO - 2023-08-19 05:45:59 --> Helper loaded: url_helper
INFO - 2023-08-19 05:45:59 --> Helper loaded: file_helper
INFO - 2023-08-19 05:45:59 --> Helper loaded: form_helper
INFO - 2023-08-19 05:45:59 --> Helper loaded: my_helper
INFO - 2023-08-19 05:45:59 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:45:59 --> Controller Class Initialized
DEBUG - 2023-08-19 05:45:59 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 05:45:59 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 05:45:59 --> Final output sent to browser
DEBUG - 2023-08-19 05:45:59 --> Total execution time: 0.8354
INFO - 2023-08-19 05:46:05 --> Config Class Initialized
INFO - 2023-08-19 05:46:05 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:46:05 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:46:05 --> Utf8 Class Initialized
INFO - 2023-08-19 05:46:05 --> URI Class Initialized
INFO - 2023-08-19 05:46:05 --> Router Class Initialized
INFO - 2023-08-19 05:46:05 --> Output Class Initialized
INFO - 2023-08-19 05:46:05 --> Security Class Initialized
DEBUG - 2023-08-19 05:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:46:05 --> Input Class Initialized
INFO - 2023-08-19 05:46:05 --> Language Class Initialized
INFO - 2023-08-19 05:46:05 --> Language Class Initialized
INFO - 2023-08-19 05:46:05 --> Config Class Initialized
INFO - 2023-08-19 05:46:05 --> Loader Class Initialized
INFO - 2023-08-19 05:46:05 --> Helper loaded: url_helper
INFO - 2023-08-19 05:46:05 --> Helper loaded: file_helper
INFO - 2023-08-19 05:46:05 --> Helper loaded: form_helper
INFO - 2023-08-19 05:46:05 --> Helper loaded: my_helper
INFO - 2023-08-19 05:46:05 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:46:05 --> Controller Class Initialized
DEBUG - 2023-08-19 05:46:05 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 05:46:05 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 05:46:05 --> Final output sent to browser
DEBUG - 2023-08-19 05:46:05 --> Total execution time: 0.0847
INFO - 2023-08-19 05:46:07 --> Config Class Initialized
INFO - 2023-08-19 05:46:07 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:46:07 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:46:07 --> Utf8 Class Initialized
INFO - 2023-08-19 05:46:07 --> URI Class Initialized
INFO - 2023-08-19 05:46:07 --> Router Class Initialized
INFO - 2023-08-19 05:46:07 --> Output Class Initialized
INFO - 2023-08-19 05:46:07 --> Security Class Initialized
DEBUG - 2023-08-19 05:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:46:07 --> Input Class Initialized
INFO - 2023-08-19 05:46:07 --> Language Class Initialized
INFO - 2023-08-19 05:46:07 --> Language Class Initialized
INFO - 2023-08-19 05:46:07 --> Config Class Initialized
INFO - 2023-08-19 05:46:07 --> Loader Class Initialized
INFO - 2023-08-19 05:46:07 --> Helper loaded: url_helper
INFO - 2023-08-19 05:46:07 --> Helper loaded: file_helper
INFO - 2023-08-19 05:46:07 --> Helper loaded: form_helper
INFO - 2023-08-19 05:46:07 --> Helper loaded: my_helper
INFO - 2023-08-19 05:46:07 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:46:07 --> Controller Class Initialized
DEBUG - 2023-08-19 05:46:07 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_icb/views/list.php
DEBUG - 2023-08-19 05:46:07 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 05:46:07 --> Final output sent to browser
DEBUG - 2023-08-19 05:46:07 --> Total execution time: 0.0876
INFO - 2023-08-19 05:46:07 --> Config Class Initialized
INFO - 2023-08-19 05:46:07 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:46:07 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:46:07 --> Utf8 Class Initialized
INFO - 2023-08-19 05:46:07 --> URI Class Initialized
INFO - 2023-08-19 05:46:07 --> Router Class Initialized
INFO - 2023-08-19 05:46:07 --> Output Class Initialized
INFO - 2023-08-19 05:46:07 --> Security Class Initialized
DEBUG - 2023-08-19 05:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:46:07 --> Input Class Initialized
INFO - 2023-08-19 05:46:07 --> Language Class Initialized
INFO - 2023-08-19 05:46:07 --> Language Class Initialized
INFO - 2023-08-19 05:46:07 --> Config Class Initialized
INFO - 2023-08-19 05:46:07 --> Loader Class Initialized
INFO - 2023-08-19 05:46:07 --> Helper loaded: url_helper
INFO - 2023-08-19 05:46:07 --> Helper loaded: file_helper
INFO - 2023-08-19 05:46:07 --> Helper loaded: form_helper
INFO - 2023-08-19 05:46:07 --> Helper loaded: my_helper
INFO - 2023-08-19 05:46:07 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:46:07 --> Controller Class Initialized
INFO - 2023-08-19 05:46:08 --> Config Class Initialized
INFO - 2023-08-19 05:46:08 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:46:08 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:46:08 --> Utf8 Class Initialized
INFO - 2023-08-19 05:46:08 --> URI Class Initialized
INFO - 2023-08-19 05:46:08 --> Router Class Initialized
INFO - 2023-08-19 05:46:08 --> Output Class Initialized
INFO - 2023-08-19 05:46:08 --> Security Class Initialized
DEBUG - 2023-08-19 05:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:46:08 --> Input Class Initialized
INFO - 2023-08-19 05:46:08 --> Language Class Initialized
INFO - 2023-08-19 05:46:08 --> Language Class Initialized
INFO - 2023-08-19 05:46:08 --> Config Class Initialized
INFO - 2023-08-19 05:46:08 --> Loader Class Initialized
INFO - 2023-08-19 05:46:08 --> Helper loaded: url_helper
INFO - 2023-08-19 05:46:08 --> Helper loaded: file_helper
INFO - 2023-08-19 05:46:08 --> Helper loaded: form_helper
INFO - 2023-08-19 05:46:08 --> Helper loaded: my_helper
INFO - 2023-08-19 05:46:08 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:46:08 --> Controller Class Initialized
DEBUG - 2023-08-19 05:46:08 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 05:46:08 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 05:46:08 --> Final output sent to browser
DEBUG - 2023-08-19 05:46:08 --> Total execution time: 0.0467
INFO - 2023-08-19 05:46:09 --> Config Class Initialized
INFO - 2023-08-19 05:46:09 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:46:09 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:46:09 --> Utf8 Class Initialized
INFO - 2023-08-19 05:46:09 --> URI Class Initialized
INFO - 2023-08-19 05:46:09 --> Router Class Initialized
INFO - 2023-08-19 05:46:09 --> Output Class Initialized
INFO - 2023-08-19 05:46:09 --> Security Class Initialized
DEBUG - 2023-08-19 05:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:46:09 --> Input Class Initialized
INFO - 2023-08-19 05:46:09 --> Language Class Initialized
INFO - 2023-08-19 05:46:09 --> Language Class Initialized
INFO - 2023-08-19 05:46:09 --> Config Class Initialized
INFO - 2023-08-19 05:46:09 --> Loader Class Initialized
INFO - 2023-08-19 05:46:09 --> Helper loaded: url_helper
INFO - 2023-08-19 05:46:09 --> Helper loaded: file_helper
INFO - 2023-08-19 05:46:09 --> Helper loaded: form_helper
INFO - 2023-08-19 05:46:09 --> Helper loaded: my_helper
INFO - 2023-08-19 05:46:09 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:46:09 --> Controller Class Initialized
INFO - 2023-08-19 05:46:09 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:46:09 --> Config Class Initialized
INFO - 2023-08-19 05:46:09 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:46:09 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:46:09 --> Utf8 Class Initialized
INFO - 2023-08-19 05:46:09 --> URI Class Initialized
INFO - 2023-08-19 05:46:09 --> Router Class Initialized
INFO - 2023-08-19 05:46:09 --> Output Class Initialized
INFO - 2023-08-19 05:46:09 --> Security Class Initialized
DEBUG - 2023-08-19 05:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:46:09 --> Input Class Initialized
INFO - 2023-08-19 05:46:09 --> Language Class Initialized
INFO - 2023-08-19 05:46:09 --> Language Class Initialized
INFO - 2023-08-19 05:46:09 --> Config Class Initialized
INFO - 2023-08-19 05:46:09 --> Loader Class Initialized
INFO - 2023-08-19 05:46:09 --> Helper loaded: url_helper
INFO - 2023-08-19 05:46:09 --> Helper loaded: file_helper
INFO - 2023-08-19 05:46:09 --> Helper loaded: form_helper
INFO - 2023-08-19 05:46:09 --> Helper loaded: my_helper
INFO - 2023-08-19 05:46:09 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:46:09 --> Controller Class Initialized
INFO - 2023-08-19 05:46:09 --> Config Class Initialized
INFO - 2023-08-19 05:46:09 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:46:09 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:46:09 --> Utf8 Class Initialized
INFO - 2023-08-19 05:46:09 --> URI Class Initialized
INFO - 2023-08-19 05:46:09 --> Router Class Initialized
INFO - 2023-08-19 05:46:09 --> Output Class Initialized
INFO - 2023-08-19 05:46:09 --> Security Class Initialized
DEBUG - 2023-08-19 05:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:46:09 --> Input Class Initialized
INFO - 2023-08-19 05:46:09 --> Language Class Initialized
INFO - 2023-08-19 05:46:09 --> Language Class Initialized
INFO - 2023-08-19 05:46:09 --> Config Class Initialized
INFO - 2023-08-19 05:46:09 --> Loader Class Initialized
INFO - 2023-08-19 05:46:09 --> Helper loaded: url_helper
INFO - 2023-08-19 05:46:09 --> Helper loaded: file_helper
INFO - 2023-08-19 05:46:09 --> Helper loaded: form_helper
INFO - 2023-08-19 05:46:09 --> Helper loaded: my_helper
INFO - 2023-08-19 05:46:09 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:46:09 --> Controller Class Initialized
DEBUG - 2023-08-19 05:46:09 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/login/views/login.php
DEBUG - 2023-08-19 05:46:09 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 05:46:09 --> Final output sent to browser
DEBUG - 2023-08-19 05:46:09 --> Total execution time: 0.0644
INFO - 2023-08-19 05:46:12 --> Config Class Initialized
INFO - 2023-08-19 05:46:12 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:46:12 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:46:12 --> Utf8 Class Initialized
INFO - 2023-08-19 05:46:12 --> URI Class Initialized
INFO - 2023-08-19 05:46:12 --> Router Class Initialized
INFO - 2023-08-19 05:46:12 --> Output Class Initialized
INFO - 2023-08-19 05:46:12 --> Security Class Initialized
DEBUG - 2023-08-19 05:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:46:12 --> Input Class Initialized
INFO - 2023-08-19 05:46:12 --> Language Class Initialized
INFO - 2023-08-19 05:46:12 --> Language Class Initialized
INFO - 2023-08-19 05:46:12 --> Config Class Initialized
INFO - 2023-08-19 05:46:12 --> Loader Class Initialized
INFO - 2023-08-19 05:46:12 --> Helper loaded: url_helper
INFO - 2023-08-19 05:46:12 --> Helper loaded: file_helper
INFO - 2023-08-19 05:46:12 --> Helper loaded: form_helper
INFO - 2023-08-19 05:46:12 --> Helper loaded: my_helper
INFO - 2023-08-19 05:46:12 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:46:12 --> Controller Class Initialized
INFO - 2023-08-19 05:46:12 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:46:12 --> Final output sent to browser
DEBUG - 2023-08-19 05:46:12 --> Total execution time: 0.0393
INFO - 2023-08-19 05:46:12 --> Config Class Initialized
INFO - 2023-08-19 05:46:12 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:46:12 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:46:12 --> Utf8 Class Initialized
INFO - 2023-08-19 05:46:12 --> URI Class Initialized
INFO - 2023-08-19 05:46:12 --> Router Class Initialized
INFO - 2023-08-19 05:46:12 --> Output Class Initialized
INFO - 2023-08-19 05:46:12 --> Security Class Initialized
DEBUG - 2023-08-19 05:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:46:12 --> Input Class Initialized
INFO - 2023-08-19 05:46:12 --> Language Class Initialized
INFO - 2023-08-19 05:46:12 --> Language Class Initialized
INFO - 2023-08-19 05:46:12 --> Config Class Initialized
INFO - 2023-08-19 05:46:12 --> Loader Class Initialized
INFO - 2023-08-19 05:46:12 --> Helper loaded: url_helper
INFO - 2023-08-19 05:46:12 --> Helper loaded: file_helper
INFO - 2023-08-19 05:46:13 --> Helper loaded: form_helper
INFO - 2023-08-19 05:46:13 --> Helper loaded: my_helper
INFO - 2023-08-19 05:46:13 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:46:13 --> Controller Class Initialized
DEBUG - 2023-08-19 05:46:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 05:46:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 05:46:13 --> Final output sent to browser
DEBUG - 2023-08-19 05:46:13 --> Total execution time: 0.0479
INFO - 2023-08-19 05:46:14 --> Config Class Initialized
INFO - 2023-08-19 05:46:14 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:46:14 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:46:14 --> Utf8 Class Initialized
INFO - 2023-08-19 05:46:14 --> URI Class Initialized
INFO - 2023-08-19 05:46:14 --> Router Class Initialized
INFO - 2023-08-19 05:46:14 --> Output Class Initialized
INFO - 2023-08-19 05:46:14 --> Security Class Initialized
DEBUG - 2023-08-19 05:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:46:14 --> Input Class Initialized
INFO - 2023-08-19 05:46:14 --> Language Class Initialized
INFO - 2023-08-19 05:46:14 --> Language Class Initialized
INFO - 2023-08-19 05:46:14 --> Config Class Initialized
INFO - 2023-08-19 05:46:14 --> Loader Class Initialized
INFO - 2023-08-19 05:46:14 --> Helper loaded: url_helper
INFO - 2023-08-19 05:46:14 --> Helper loaded: file_helper
INFO - 2023-08-19 05:46:14 --> Helper loaded: form_helper
INFO - 2023-08-19 05:46:14 --> Helper loaded: my_helper
INFO - 2023-08-19 05:46:14 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:46:14 --> Controller Class Initialized
DEBUG - 2023-08-19 05:46:14 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 05:46:14 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 05:46:14 --> Final output sent to browser
DEBUG - 2023-08-19 05:46:14 --> Total execution time: 0.0461
INFO - 2023-08-19 05:46:19 --> Config Class Initialized
INFO - 2023-08-19 05:46:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:46:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:46:19 --> Utf8 Class Initialized
INFO - 2023-08-19 05:46:19 --> URI Class Initialized
INFO - 2023-08-19 05:46:19 --> Router Class Initialized
INFO - 2023-08-19 05:46:19 --> Output Class Initialized
INFO - 2023-08-19 05:46:19 --> Security Class Initialized
DEBUG - 2023-08-19 05:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:46:19 --> Input Class Initialized
INFO - 2023-08-19 05:46:19 --> Language Class Initialized
INFO - 2023-08-19 05:46:19 --> Language Class Initialized
INFO - 2023-08-19 05:46:19 --> Config Class Initialized
INFO - 2023-08-19 05:46:19 --> Loader Class Initialized
INFO - 2023-08-19 05:46:19 --> Helper loaded: url_helper
INFO - 2023-08-19 05:46:19 --> Helper loaded: file_helper
INFO - 2023-08-19 05:46:19 --> Helper loaded: form_helper
INFO - 2023-08-19 05:46:19 --> Helper loaded: my_helper
INFO - 2023-08-19 05:46:19 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:46:19 --> Controller Class Initialized
DEBUG - 2023-08-19 05:46:19 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_keterampilan/views/list.php
DEBUG - 2023-08-19 05:46:19 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 05:46:19 --> Final output sent to browser
DEBUG - 2023-08-19 05:46:19 --> Total execution time: 0.1185
INFO - 2023-08-19 05:46:20 --> Config Class Initialized
INFO - 2023-08-19 05:46:20 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:46:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:46:20 --> Utf8 Class Initialized
INFO - 2023-08-19 05:46:20 --> URI Class Initialized
INFO - 2023-08-19 05:46:20 --> Router Class Initialized
INFO - 2023-08-19 05:46:20 --> Output Class Initialized
INFO - 2023-08-19 05:46:20 --> Security Class Initialized
DEBUG - 2023-08-19 05:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:46:20 --> Input Class Initialized
INFO - 2023-08-19 05:46:20 --> Language Class Initialized
INFO - 2023-08-19 05:46:20 --> Language Class Initialized
INFO - 2023-08-19 05:46:20 --> Config Class Initialized
INFO - 2023-08-19 05:46:20 --> Loader Class Initialized
INFO - 2023-08-19 05:46:20 --> Helper loaded: url_helper
INFO - 2023-08-19 05:46:20 --> Helper loaded: file_helper
INFO - 2023-08-19 05:46:20 --> Helper loaded: form_helper
INFO - 2023-08-19 05:46:20 --> Helper loaded: my_helper
INFO - 2023-08-19 05:46:20 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:46:20 --> Controller Class Initialized
INFO - 2023-08-19 05:46:20 --> Final output sent to browser
DEBUG - 2023-08-19 05:46:20 --> Total execution time: 0.0265
INFO - 2023-08-19 05:46:25 --> Config Class Initialized
INFO - 2023-08-19 05:46:25 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:46:25 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:46:25 --> Utf8 Class Initialized
INFO - 2023-08-19 05:46:25 --> URI Class Initialized
INFO - 2023-08-19 05:46:25 --> Router Class Initialized
INFO - 2023-08-19 05:46:25 --> Output Class Initialized
INFO - 2023-08-19 05:46:25 --> Security Class Initialized
DEBUG - 2023-08-19 05:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:46:25 --> Input Class Initialized
INFO - 2023-08-19 05:46:25 --> Language Class Initialized
INFO - 2023-08-19 05:46:25 --> Language Class Initialized
INFO - 2023-08-19 05:46:25 --> Config Class Initialized
INFO - 2023-08-19 05:46:25 --> Loader Class Initialized
INFO - 2023-08-19 05:46:25 --> Helper loaded: url_helper
INFO - 2023-08-19 05:46:25 --> Helper loaded: file_helper
INFO - 2023-08-19 05:46:25 --> Helper loaded: form_helper
INFO - 2023-08-19 05:46:25 --> Helper loaded: my_helper
INFO - 2023-08-19 05:46:25 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:46:25 --> Controller Class Initialized
INFO - 2023-08-19 05:46:25 --> Final output sent to browser
DEBUG - 2023-08-19 05:46:25 --> Total execution time: 0.0273
INFO - 2023-08-19 05:46:25 --> Config Class Initialized
INFO - 2023-08-19 05:46:25 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:46:25 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:46:25 --> Utf8 Class Initialized
INFO - 2023-08-19 05:46:25 --> URI Class Initialized
INFO - 2023-08-19 05:46:25 --> Router Class Initialized
INFO - 2023-08-19 05:46:25 --> Output Class Initialized
INFO - 2023-08-19 05:46:25 --> Security Class Initialized
DEBUG - 2023-08-19 05:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:46:25 --> Input Class Initialized
INFO - 2023-08-19 05:46:25 --> Language Class Initialized
INFO - 2023-08-19 05:46:25 --> Language Class Initialized
INFO - 2023-08-19 05:46:25 --> Config Class Initialized
INFO - 2023-08-19 05:46:25 --> Loader Class Initialized
INFO - 2023-08-19 05:46:25 --> Helper loaded: url_helper
INFO - 2023-08-19 05:46:25 --> Helper loaded: file_helper
INFO - 2023-08-19 05:46:25 --> Helper loaded: form_helper
INFO - 2023-08-19 05:46:25 --> Helper loaded: my_helper
INFO - 2023-08-19 05:46:25 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:46:25 --> Controller Class Initialized
INFO - 2023-08-19 05:46:25 --> Final output sent to browser
DEBUG - 2023-08-19 05:46:25 --> Total execution time: 0.0316
INFO - 2023-08-19 05:46:25 --> Config Class Initialized
INFO - 2023-08-19 05:46:25 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:46:25 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:46:25 --> Utf8 Class Initialized
INFO - 2023-08-19 05:46:25 --> URI Class Initialized
INFO - 2023-08-19 05:46:25 --> Router Class Initialized
INFO - 2023-08-19 05:46:25 --> Output Class Initialized
INFO - 2023-08-19 05:46:25 --> Security Class Initialized
DEBUG - 2023-08-19 05:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:46:25 --> Input Class Initialized
INFO - 2023-08-19 05:46:25 --> Language Class Initialized
INFO - 2023-08-19 05:46:25 --> Language Class Initialized
INFO - 2023-08-19 05:46:25 --> Config Class Initialized
INFO - 2023-08-19 05:46:25 --> Loader Class Initialized
INFO - 2023-08-19 05:46:25 --> Helper loaded: url_helper
INFO - 2023-08-19 05:46:25 --> Helper loaded: file_helper
INFO - 2023-08-19 05:46:25 --> Helper loaded: form_helper
INFO - 2023-08-19 05:46:26 --> Helper loaded: my_helper
INFO - 2023-08-19 05:46:26 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:46:26 --> Controller Class Initialized
INFO - 2023-08-19 05:46:26 --> Final output sent to browser
DEBUG - 2023-08-19 05:46:26 --> Total execution time: 0.0462
INFO - 2023-08-19 05:46:28 --> Config Class Initialized
INFO - 2023-08-19 05:46:28 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:46:28 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:46:28 --> Utf8 Class Initialized
INFO - 2023-08-19 05:46:28 --> URI Class Initialized
INFO - 2023-08-19 05:46:28 --> Router Class Initialized
INFO - 2023-08-19 05:46:28 --> Output Class Initialized
INFO - 2023-08-19 05:46:28 --> Security Class Initialized
DEBUG - 2023-08-19 05:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:46:28 --> Input Class Initialized
INFO - 2023-08-19 05:46:28 --> Language Class Initialized
ERROR - 2023-08-19 05:46:28 --> 404 Page Not Found: /index
INFO - 2023-08-19 05:46:29 --> Config Class Initialized
INFO - 2023-08-19 05:46:29 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:46:29 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:46:29 --> Utf8 Class Initialized
INFO - 2023-08-19 05:46:29 --> URI Class Initialized
INFO - 2023-08-19 05:46:29 --> Router Class Initialized
INFO - 2023-08-19 05:46:29 --> Output Class Initialized
INFO - 2023-08-19 05:46:29 --> Security Class Initialized
DEBUG - 2023-08-19 05:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:46:29 --> Input Class Initialized
INFO - 2023-08-19 05:46:29 --> Language Class Initialized
INFO - 2023-08-19 05:46:29 --> Language Class Initialized
INFO - 2023-08-19 05:46:29 --> Config Class Initialized
INFO - 2023-08-19 05:46:29 --> Loader Class Initialized
INFO - 2023-08-19 05:46:29 --> Helper loaded: url_helper
INFO - 2023-08-19 05:46:29 --> Helper loaded: file_helper
INFO - 2023-08-19 05:46:29 --> Helper loaded: form_helper
INFO - 2023-08-19 05:46:29 --> Helper loaded: my_helper
INFO - 2023-08-19 05:46:29 --> Database Driver Class Initialized
DEBUG - 2023-08-19 05:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 05:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:46:29 --> Controller Class Initialized
INFO - 2023-08-19 05:46:29 --> Final output sent to browser
DEBUG - 2023-08-19 05:46:29 --> Total execution time: 0.0490
INFO - 2023-08-19 06:10:51 --> Config Class Initialized
INFO - 2023-08-19 06:10:51 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:10:51 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:10:51 --> Utf8 Class Initialized
INFO - 2023-08-19 06:10:51 --> URI Class Initialized
INFO - 2023-08-19 06:10:51 --> Router Class Initialized
INFO - 2023-08-19 06:10:51 --> Output Class Initialized
INFO - 2023-08-19 06:10:51 --> Security Class Initialized
DEBUG - 2023-08-19 06:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:10:51 --> Input Class Initialized
INFO - 2023-08-19 06:10:51 --> Language Class Initialized
INFO - 2023-08-19 06:10:51 --> Language Class Initialized
INFO - 2023-08-19 06:10:51 --> Config Class Initialized
INFO - 2023-08-19 06:10:51 --> Loader Class Initialized
INFO - 2023-08-19 06:10:51 --> Helper loaded: url_helper
INFO - 2023-08-19 06:10:51 --> Helper loaded: file_helper
INFO - 2023-08-19 06:10:51 --> Helper loaded: form_helper
INFO - 2023-08-19 06:10:51 --> Helper loaded: my_helper
INFO - 2023-08-19 06:10:51 --> Database Driver Class Initialized
DEBUG - 2023-08-19 06:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 06:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:10:51 --> Controller Class Initialized
DEBUG - 2023-08-19 06:10:52 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_keterampilan/views/list.php
DEBUG - 2023-08-19 06:10:52 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 06:10:52 --> Final output sent to browser
DEBUG - 2023-08-19 06:10:52 --> Total execution time: 0.1278
INFO - 2023-08-19 06:10:52 --> Config Class Initialized
INFO - 2023-08-19 06:10:52 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:10:52 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:10:52 --> Utf8 Class Initialized
INFO - 2023-08-19 06:10:52 --> URI Class Initialized
INFO - 2023-08-19 06:10:52 --> Router Class Initialized
INFO - 2023-08-19 06:10:52 --> Output Class Initialized
INFO - 2023-08-19 06:10:52 --> Security Class Initialized
DEBUG - 2023-08-19 06:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:10:52 --> Input Class Initialized
INFO - 2023-08-19 06:10:52 --> Language Class Initialized
ERROR - 2023-08-19 06:10:52 --> 404 Page Not Found: /index
INFO - 2023-08-19 06:10:54 --> Config Class Initialized
INFO - 2023-08-19 06:10:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:10:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:10:54 --> Utf8 Class Initialized
INFO - 2023-08-19 06:10:54 --> URI Class Initialized
INFO - 2023-08-19 06:10:54 --> Router Class Initialized
INFO - 2023-08-19 06:10:54 --> Output Class Initialized
INFO - 2023-08-19 06:10:54 --> Security Class Initialized
DEBUG - 2023-08-19 06:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:10:54 --> Input Class Initialized
INFO - 2023-08-19 06:10:54 --> Language Class Initialized
INFO - 2023-08-19 06:10:54 --> Language Class Initialized
INFO - 2023-08-19 06:10:54 --> Config Class Initialized
INFO - 2023-08-19 06:10:54 --> Loader Class Initialized
INFO - 2023-08-19 06:10:54 --> Helper loaded: url_helper
INFO - 2023-08-19 06:10:54 --> Helper loaded: file_helper
INFO - 2023-08-19 06:10:54 --> Helper loaded: form_helper
INFO - 2023-08-19 06:10:54 --> Helper loaded: my_helper
INFO - 2023-08-19 06:10:54 --> Database Driver Class Initialized
DEBUG - 2023-08-19 06:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 06:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:10:54 --> Controller Class Initialized
INFO - 2023-08-19 06:10:54 --> Final output sent to browser
DEBUG - 2023-08-19 06:10:54 --> Total execution time: 0.0381
INFO - 2023-08-19 06:21:31 --> Config Class Initialized
INFO - 2023-08-19 06:21:31 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:21:31 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:21:31 --> Utf8 Class Initialized
INFO - 2023-08-19 06:21:31 --> URI Class Initialized
INFO - 2023-08-19 06:21:31 --> Router Class Initialized
INFO - 2023-08-19 06:21:31 --> Output Class Initialized
INFO - 2023-08-19 06:21:31 --> Security Class Initialized
DEBUG - 2023-08-19 06:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:21:31 --> Input Class Initialized
INFO - 2023-08-19 06:21:31 --> Language Class Initialized
INFO - 2023-08-19 06:21:31 --> Language Class Initialized
INFO - 2023-08-19 06:21:31 --> Config Class Initialized
INFO - 2023-08-19 06:21:31 --> Loader Class Initialized
INFO - 2023-08-19 06:21:31 --> Helper loaded: url_helper
INFO - 2023-08-19 06:21:31 --> Helper loaded: file_helper
INFO - 2023-08-19 06:21:31 --> Helper loaded: form_helper
INFO - 2023-08-19 06:21:31 --> Helper loaded: my_helper
INFO - 2023-08-19 06:21:31 --> Database Driver Class Initialized
DEBUG - 2023-08-19 06:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 06:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:21:31 --> Controller Class Initialized
INFO - 2023-08-19 06:21:31 --> Final output sent to browser
DEBUG - 2023-08-19 06:21:31 --> Total execution time: 0.0726
INFO - 2023-08-19 06:21:33 --> Config Class Initialized
INFO - 2023-08-19 06:21:33 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:21:33 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:21:33 --> Utf8 Class Initialized
INFO - 2023-08-19 06:21:33 --> URI Class Initialized
INFO - 2023-08-19 06:21:33 --> Router Class Initialized
INFO - 2023-08-19 06:21:33 --> Output Class Initialized
INFO - 2023-08-19 06:21:33 --> Security Class Initialized
DEBUG - 2023-08-19 06:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:21:33 --> Input Class Initialized
INFO - 2023-08-19 06:21:33 --> Language Class Initialized
INFO - 2023-08-19 06:21:33 --> Language Class Initialized
INFO - 2023-08-19 06:21:33 --> Config Class Initialized
INFO - 2023-08-19 06:21:33 --> Loader Class Initialized
INFO - 2023-08-19 06:21:33 --> Helper loaded: url_helper
INFO - 2023-08-19 06:21:33 --> Helper loaded: file_helper
INFO - 2023-08-19 06:21:33 --> Helper loaded: form_helper
INFO - 2023-08-19 06:21:33 --> Helper loaded: my_helper
INFO - 2023-08-19 06:21:33 --> Database Driver Class Initialized
DEBUG - 2023-08-19 06:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 06:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:21:33 --> Controller Class Initialized
DEBUG - 2023-08-19 06:21:33 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 06:21:33 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 06:21:33 --> Final output sent to browser
DEBUG - 2023-08-19 06:21:33 --> Total execution time: 0.0438
INFO - 2023-08-19 06:21:35 --> Config Class Initialized
INFO - 2023-08-19 06:21:35 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:21:35 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:21:35 --> Utf8 Class Initialized
INFO - 2023-08-19 06:21:35 --> URI Class Initialized
INFO - 2023-08-19 06:21:35 --> Router Class Initialized
INFO - 2023-08-19 06:21:35 --> Output Class Initialized
INFO - 2023-08-19 06:21:35 --> Security Class Initialized
DEBUG - 2023-08-19 06:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:21:35 --> Input Class Initialized
INFO - 2023-08-19 06:21:35 --> Language Class Initialized
INFO - 2023-08-19 06:21:35 --> Language Class Initialized
INFO - 2023-08-19 06:21:35 --> Config Class Initialized
INFO - 2023-08-19 06:21:35 --> Loader Class Initialized
INFO - 2023-08-19 06:21:35 --> Helper loaded: url_helper
INFO - 2023-08-19 06:21:35 --> Helper loaded: file_helper
INFO - 2023-08-19 06:21:35 --> Helper loaded: form_helper
INFO - 2023-08-19 06:21:35 --> Helper loaded: my_helper
INFO - 2023-08-19 06:21:35 --> Database Driver Class Initialized
DEBUG - 2023-08-19 06:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 06:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:21:35 --> Controller Class Initialized
DEBUG - 2023-08-19 06:21:35 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-08-19 06:21:35 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 06:21:35 --> Final output sent to browser
DEBUG - 2023-08-19 06:21:35 --> Total execution time: 0.1364
INFO - 2023-08-19 06:21:36 --> Config Class Initialized
INFO - 2023-08-19 06:21:36 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:21:36 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:21:36 --> Utf8 Class Initialized
INFO - 2023-08-19 06:21:36 --> URI Class Initialized
INFO - 2023-08-19 06:21:36 --> Router Class Initialized
INFO - 2023-08-19 06:21:36 --> Output Class Initialized
INFO - 2023-08-19 06:21:36 --> Security Class Initialized
DEBUG - 2023-08-19 06:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:21:36 --> Input Class Initialized
INFO - 2023-08-19 06:21:36 --> Language Class Initialized
INFO - 2023-08-19 06:21:36 --> Language Class Initialized
INFO - 2023-08-19 06:21:36 --> Config Class Initialized
INFO - 2023-08-19 06:21:36 --> Loader Class Initialized
INFO - 2023-08-19 06:21:36 --> Helper loaded: url_helper
INFO - 2023-08-19 06:21:36 --> Helper loaded: file_helper
INFO - 2023-08-19 06:21:36 --> Helper loaded: form_helper
INFO - 2023-08-19 06:21:36 --> Helper loaded: my_helper
INFO - 2023-08-19 06:21:36 --> Database Driver Class Initialized
DEBUG - 2023-08-19 06:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 06:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:21:36 --> Controller Class Initialized
INFO - 2023-08-19 06:21:36 --> Final output sent to browser
DEBUG - 2023-08-19 06:21:36 --> Total execution time: 0.0267
INFO - 2023-08-19 06:21:37 --> Config Class Initialized
INFO - 2023-08-19 06:21:37 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:21:37 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:21:37 --> Utf8 Class Initialized
INFO - 2023-08-19 06:21:37 --> URI Class Initialized
INFO - 2023-08-19 06:21:37 --> Router Class Initialized
INFO - 2023-08-19 06:21:37 --> Output Class Initialized
INFO - 2023-08-19 06:21:37 --> Security Class Initialized
DEBUG - 2023-08-19 06:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:21:37 --> Input Class Initialized
INFO - 2023-08-19 06:21:37 --> Language Class Initialized
INFO - 2023-08-19 06:21:37 --> Language Class Initialized
INFO - 2023-08-19 06:21:37 --> Config Class Initialized
INFO - 2023-08-19 06:21:37 --> Loader Class Initialized
INFO - 2023-08-19 06:21:37 --> Helper loaded: url_helper
INFO - 2023-08-19 06:21:37 --> Helper loaded: file_helper
INFO - 2023-08-19 06:21:37 --> Helper loaded: form_helper
INFO - 2023-08-19 06:21:37 --> Helper loaded: my_helper
INFO - 2023-08-19 06:21:37 --> Database Driver Class Initialized
DEBUG - 2023-08-19 06:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 06:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:21:37 --> Controller Class Initialized
DEBUG - 2023-08-19 06:21:37 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 06:21:37 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 06:21:37 --> Final output sent to browser
DEBUG - 2023-08-19 06:21:37 --> Total execution time: 0.0259
INFO - 2023-08-19 06:21:39 --> Config Class Initialized
INFO - 2023-08-19 06:21:39 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:21:39 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:21:39 --> Utf8 Class Initialized
INFO - 2023-08-19 06:21:39 --> URI Class Initialized
INFO - 2023-08-19 06:21:39 --> Router Class Initialized
INFO - 2023-08-19 06:21:39 --> Output Class Initialized
INFO - 2023-08-19 06:21:39 --> Security Class Initialized
DEBUG - 2023-08-19 06:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:21:39 --> Input Class Initialized
INFO - 2023-08-19 06:21:39 --> Language Class Initialized
INFO - 2023-08-19 06:21:39 --> Language Class Initialized
INFO - 2023-08-19 06:21:39 --> Config Class Initialized
INFO - 2023-08-19 06:21:39 --> Loader Class Initialized
INFO - 2023-08-19 06:21:39 --> Helper loaded: url_helper
INFO - 2023-08-19 06:21:39 --> Helper loaded: file_helper
INFO - 2023-08-19 06:21:39 --> Helper loaded: form_helper
INFO - 2023-08-19 06:21:39 --> Helper loaded: my_helper
INFO - 2023-08-19 06:21:39 --> Database Driver Class Initialized
DEBUG - 2023-08-19 06:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 06:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:21:39 --> Controller Class Initialized
DEBUG - 2023-08-19 06:21:39 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_keterampilan/views/list.php
DEBUG - 2023-08-19 06:21:39 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 06:21:39 --> Final output sent to browser
DEBUG - 2023-08-19 06:21:39 --> Total execution time: 0.0457
INFO - 2023-08-19 06:21:44 --> Config Class Initialized
INFO - 2023-08-19 06:21:44 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:21:44 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:21:44 --> Utf8 Class Initialized
INFO - 2023-08-19 06:21:44 --> URI Class Initialized
INFO - 2023-08-19 06:21:44 --> Router Class Initialized
INFO - 2023-08-19 06:21:44 --> Output Class Initialized
INFO - 2023-08-19 06:21:44 --> Security Class Initialized
DEBUG - 2023-08-19 06:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:21:44 --> Input Class Initialized
INFO - 2023-08-19 06:21:44 --> Language Class Initialized
INFO - 2023-08-19 06:21:44 --> Language Class Initialized
INFO - 2023-08-19 06:21:44 --> Config Class Initialized
INFO - 2023-08-19 06:21:44 --> Loader Class Initialized
INFO - 2023-08-19 06:21:44 --> Helper loaded: url_helper
INFO - 2023-08-19 06:21:44 --> Helper loaded: file_helper
INFO - 2023-08-19 06:21:44 --> Helper loaded: form_helper
INFO - 2023-08-19 06:21:44 --> Helper loaded: my_helper
INFO - 2023-08-19 06:21:44 --> Database Driver Class Initialized
DEBUG - 2023-08-19 06:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 06:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:21:44 --> Controller Class Initialized
DEBUG - 2023-08-19 06:21:44 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 06:21:44 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 06:21:44 --> Final output sent to browser
DEBUG - 2023-08-19 06:21:44 --> Total execution time: 0.0552
INFO - 2023-08-19 06:24:44 --> Config Class Initialized
INFO - 2023-08-19 06:24:44 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:24:44 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:24:44 --> Utf8 Class Initialized
INFO - 2023-08-19 06:24:44 --> URI Class Initialized
INFO - 2023-08-19 06:24:44 --> Router Class Initialized
INFO - 2023-08-19 06:24:44 --> Output Class Initialized
INFO - 2023-08-19 06:24:44 --> Security Class Initialized
DEBUG - 2023-08-19 06:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:24:44 --> Input Class Initialized
INFO - 2023-08-19 06:24:44 --> Language Class Initialized
INFO - 2023-08-19 06:24:44 --> Language Class Initialized
INFO - 2023-08-19 06:24:44 --> Config Class Initialized
INFO - 2023-08-19 06:24:44 --> Loader Class Initialized
INFO - 2023-08-19 06:24:44 --> Helper loaded: url_helper
INFO - 2023-08-19 06:24:44 --> Helper loaded: file_helper
INFO - 2023-08-19 06:24:44 --> Helper loaded: form_helper
INFO - 2023-08-19 06:24:44 --> Helper loaded: my_helper
INFO - 2023-08-19 06:24:44 --> Database Driver Class Initialized
DEBUG - 2023-08-19 06:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 06:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:24:44 --> Controller Class Initialized
INFO - 2023-08-19 06:24:44 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:24:44 --> Config Class Initialized
INFO - 2023-08-19 06:24:44 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:24:44 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:24:44 --> Utf8 Class Initialized
INFO - 2023-08-19 06:24:44 --> URI Class Initialized
INFO - 2023-08-19 06:24:44 --> Router Class Initialized
INFO - 2023-08-19 06:24:44 --> Output Class Initialized
INFO - 2023-08-19 06:24:44 --> Security Class Initialized
DEBUG - 2023-08-19 06:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:24:44 --> Input Class Initialized
INFO - 2023-08-19 06:24:44 --> Language Class Initialized
INFO - 2023-08-19 06:24:44 --> Language Class Initialized
INFO - 2023-08-19 06:24:44 --> Config Class Initialized
INFO - 2023-08-19 06:24:44 --> Loader Class Initialized
INFO - 2023-08-19 06:24:44 --> Helper loaded: url_helper
INFO - 2023-08-19 06:24:44 --> Helper loaded: file_helper
INFO - 2023-08-19 06:24:44 --> Helper loaded: form_helper
INFO - 2023-08-19 06:24:44 --> Helper loaded: my_helper
INFO - 2023-08-19 06:24:44 --> Database Driver Class Initialized
DEBUG - 2023-08-19 06:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 06:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:24:44 --> Controller Class Initialized
INFO - 2023-08-19 06:24:44 --> Config Class Initialized
INFO - 2023-08-19 06:24:44 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:24:44 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:24:44 --> Utf8 Class Initialized
INFO - 2023-08-19 06:24:44 --> URI Class Initialized
INFO - 2023-08-19 06:24:44 --> Router Class Initialized
INFO - 2023-08-19 06:24:44 --> Output Class Initialized
INFO - 2023-08-19 06:24:44 --> Security Class Initialized
DEBUG - 2023-08-19 06:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:24:44 --> Input Class Initialized
INFO - 2023-08-19 06:24:44 --> Language Class Initialized
INFO - 2023-08-19 06:24:44 --> Language Class Initialized
INFO - 2023-08-19 06:24:44 --> Config Class Initialized
INFO - 2023-08-19 06:24:44 --> Loader Class Initialized
INFO - 2023-08-19 06:24:44 --> Helper loaded: url_helper
INFO - 2023-08-19 06:24:44 --> Helper loaded: file_helper
INFO - 2023-08-19 06:24:44 --> Helper loaded: form_helper
INFO - 2023-08-19 06:24:44 --> Helper loaded: my_helper
INFO - 2023-08-19 06:24:44 --> Database Driver Class Initialized
DEBUG - 2023-08-19 06:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 06:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:24:44 --> Controller Class Initialized
DEBUG - 2023-08-19 06:24:44 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/login/views/login.php
DEBUG - 2023-08-19 06:24:44 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 06:24:44 --> Final output sent to browser
DEBUG - 2023-08-19 06:24:44 --> Total execution time: 0.0245
INFO - 2023-08-19 06:24:49 --> Config Class Initialized
INFO - 2023-08-19 06:24:49 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:24:49 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:24:49 --> Utf8 Class Initialized
INFO - 2023-08-19 06:24:49 --> URI Class Initialized
INFO - 2023-08-19 06:24:49 --> Router Class Initialized
INFO - 2023-08-19 06:24:49 --> Output Class Initialized
INFO - 2023-08-19 06:24:49 --> Security Class Initialized
DEBUG - 2023-08-19 06:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:24:49 --> Input Class Initialized
INFO - 2023-08-19 06:24:49 --> Language Class Initialized
INFO - 2023-08-19 06:24:49 --> Language Class Initialized
INFO - 2023-08-19 06:24:49 --> Config Class Initialized
INFO - 2023-08-19 06:24:49 --> Loader Class Initialized
INFO - 2023-08-19 06:24:49 --> Helper loaded: url_helper
INFO - 2023-08-19 06:24:49 --> Helper loaded: file_helper
INFO - 2023-08-19 06:24:49 --> Helper loaded: form_helper
INFO - 2023-08-19 06:24:49 --> Helper loaded: my_helper
INFO - 2023-08-19 06:24:49 --> Database Driver Class Initialized
DEBUG - 2023-08-19 06:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 06:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:24:49 --> Controller Class Initialized
INFO - 2023-08-19 06:24:49 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:24:49 --> Final output sent to browser
DEBUG - 2023-08-19 06:24:49 --> Total execution time: 0.0508
INFO - 2023-08-19 06:24:49 --> Config Class Initialized
INFO - 2023-08-19 06:24:49 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:24:49 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:24:49 --> Utf8 Class Initialized
INFO - 2023-08-19 06:24:49 --> URI Class Initialized
INFO - 2023-08-19 06:24:49 --> Router Class Initialized
INFO - 2023-08-19 06:24:49 --> Output Class Initialized
INFO - 2023-08-19 06:24:49 --> Security Class Initialized
DEBUG - 2023-08-19 06:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:24:49 --> Input Class Initialized
INFO - 2023-08-19 06:24:49 --> Language Class Initialized
INFO - 2023-08-19 06:24:49 --> Language Class Initialized
INFO - 2023-08-19 06:24:49 --> Config Class Initialized
INFO - 2023-08-19 06:24:49 --> Loader Class Initialized
INFO - 2023-08-19 06:24:49 --> Helper loaded: url_helper
INFO - 2023-08-19 06:24:49 --> Helper loaded: file_helper
INFO - 2023-08-19 06:24:49 --> Helper loaded: form_helper
INFO - 2023-08-19 06:24:49 --> Helper loaded: my_helper
INFO - 2023-08-19 06:24:49 --> Database Driver Class Initialized
DEBUG - 2023-08-19 06:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 06:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:24:49 --> Controller Class Initialized
DEBUG - 2023-08-19 06:24:49 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 06:24:49 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 06:24:49 --> Final output sent to browser
DEBUG - 2023-08-19 06:24:49 --> Total execution time: 0.0445
INFO - 2023-08-19 06:24:52 --> Config Class Initialized
INFO - 2023-08-19 06:24:52 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:24:52 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:24:52 --> Utf8 Class Initialized
INFO - 2023-08-19 06:24:52 --> URI Class Initialized
INFO - 2023-08-19 06:24:52 --> Router Class Initialized
INFO - 2023-08-19 06:24:52 --> Output Class Initialized
INFO - 2023-08-19 06:24:52 --> Security Class Initialized
DEBUG - 2023-08-19 06:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:24:52 --> Input Class Initialized
INFO - 2023-08-19 06:24:52 --> Language Class Initialized
INFO - 2023-08-19 06:24:52 --> Language Class Initialized
INFO - 2023-08-19 06:24:52 --> Config Class Initialized
INFO - 2023-08-19 06:24:52 --> Loader Class Initialized
INFO - 2023-08-19 06:24:52 --> Helper loaded: url_helper
INFO - 2023-08-19 06:24:52 --> Helper loaded: file_helper
INFO - 2023-08-19 06:24:52 --> Helper loaded: form_helper
INFO - 2023-08-19 06:24:52 --> Helper loaded: my_helper
INFO - 2023-08-19 06:24:52 --> Database Driver Class Initialized
DEBUG - 2023-08-19 06:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 06:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:24:52 --> Controller Class Initialized
DEBUG - 2023-08-19 06:24:52 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-08-19 06:24:52 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 06:24:52 --> Final output sent to browser
DEBUG - 2023-08-19 06:24:52 --> Total execution time: 0.0925
INFO - 2023-08-19 06:26:19 --> Config Class Initialized
INFO - 2023-08-19 06:26:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:26:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:26:19 --> Utf8 Class Initialized
INFO - 2023-08-19 06:26:19 --> URI Class Initialized
INFO - 2023-08-19 06:26:19 --> Router Class Initialized
INFO - 2023-08-19 06:26:19 --> Output Class Initialized
INFO - 2023-08-19 06:26:19 --> Security Class Initialized
DEBUG - 2023-08-19 06:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:26:19 --> Input Class Initialized
INFO - 2023-08-19 06:26:19 --> Language Class Initialized
INFO - 2023-08-19 06:26:19 --> Language Class Initialized
INFO - 2023-08-19 06:26:19 --> Config Class Initialized
INFO - 2023-08-19 06:26:19 --> Loader Class Initialized
INFO - 2023-08-19 06:26:19 --> Helper loaded: url_helper
INFO - 2023-08-19 06:26:19 --> Helper loaded: file_helper
INFO - 2023-08-19 06:26:19 --> Helper loaded: form_helper
INFO - 2023-08-19 06:26:19 --> Helper loaded: my_helper
INFO - 2023-08-19 06:26:19 --> Database Driver Class Initialized
DEBUG - 2023-08-19 06:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 06:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:26:19 --> Controller Class Initialized
ERROR - 2023-08-19 06:26:19 --> Severity: Notice --> Undefined index: tingkat C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules\cetak_raport_pts\views\list.php 39
ERROR - 2023-08-19 06:26:19 --> Severity: Notice --> Undefined index: tingkat C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules\cetak_raport_pts\views\list.php 39
ERROR - 2023-08-19 06:26:19 --> Severity: Notice --> Undefined index: tingkat C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules\cetak_raport_pts\views\list.php 39
ERROR - 2023-08-19 06:26:19 --> Severity: Notice --> Undefined index: tingkat C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules\cetak_raport_pts\views\list.php 39
DEBUG - 2023-08-19 06:26:19 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-08-19 06:26:19 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 06:26:19 --> Final output sent to browser
DEBUG - 2023-08-19 06:26:19 --> Total execution time: 0.1111
INFO - 2023-08-19 06:27:15 --> Config Class Initialized
INFO - 2023-08-19 06:27:15 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:27:15 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:27:15 --> Utf8 Class Initialized
INFO - 2023-08-19 06:27:15 --> URI Class Initialized
INFO - 2023-08-19 06:27:15 --> Router Class Initialized
INFO - 2023-08-19 06:27:15 --> Output Class Initialized
INFO - 2023-08-19 06:27:15 --> Security Class Initialized
DEBUG - 2023-08-19 06:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:27:15 --> Input Class Initialized
INFO - 2023-08-19 06:27:15 --> Language Class Initialized
INFO - 2023-08-19 06:27:15 --> Language Class Initialized
INFO - 2023-08-19 06:27:15 --> Config Class Initialized
INFO - 2023-08-19 06:27:15 --> Loader Class Initialized
INFO - 2023-08-19 06:27:15 --> Helper loaded: url_helper
INFO - 2023-08-19 06:27:15 --> Helper loaded: file_helper
INFO - 2023-08-19 06:27:15 --> Helper loaded: form_helper
INFO - 2023-08-19 06:27:15 --> Helper loaded: my_helper
INFO - 2023-08-19 06:27:15 --> Database Driver Class Initialized
DEBUG - 2023-08-19 06:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 06:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:27:15 --> Controller Class Initialized
DEBUG - 2023-08-19 06:27:15 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-08-19 06:27:15 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 06:27:15 --> Final output sent to browser
DEBUG - 2023-08-19 06:27:15 --> Total execution time: 0.0665
INFO - 2023-08-19 06:27:37 --> Config Class Initialized
INFO - 2023-08-19 06:27:37 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:27:37 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:27:37 --> Utf8 Class Initialized
INFO - 2023-08-19 06:27:37 --> URI Class Initialized
INFO - 2023-08-19 06:27:37 --> Router Class Initialized
INFO - 2023-08-19 06:27:37 --> Output Class Initialized
INFO - 2023-08-19 06:27:37 --> Security Class Initialized
DEBUG - 2023-08-19 06:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:27:37 --> Input Class Initialized
INFO - 2023-08-19 06:27:37 --> Language Class Initialized
INFO - 2023-08-19 06:27:37 --> Language Class Initialized
INFO - 2023-08-19 06:27:37 --> Config Class Initialized
INFO - 2023-08-19 06:27:37 --> Loader Class Initialized
INFO - 2023-08-19 06:27:37 --> Helper loaded: url_helper
INFO - 2023-08-19 06:27:37 --> Helper loaded: file_helper
INFO - 2023-08-19 06:27:37 --> Helper loaded: form_helper
INFO - 2023-08-19 06:27:37 --> Helper loaded: my_helper
INFO - 2023-08-19 06:27:37 --> Database Driver Class Initialized
DEBUG - 2023-08-19 06:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 06:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:27:37 --> Controller Class Initialized
DEBUG - 2023-08-19 06:27:37 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-08-19 06:27:37 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-19 06:27:37 --> Final output sent to browser
DEBUG - 2023-08-19 06:27:37 --> Total execution time: 0.0387
INFO - 2023-08-19 06:27:40 --> Config Class Initialized
INFO - 2023-08-19 06:27:40 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:27:40 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:27:40 --> Utf8 Class Initialized
INFO - 2023-08-19 06:27:40 --> URI Class Initialized
INFO - 2023-08-19 06:27:40 --> Router Class Initialized
INFO - 2023-08-19 06:27:40 --> Output Class Initialized
INFO - 2023-08-19 06:27:40 --> Security Class Initialized
DEBUG - 2023-08-19 06:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:27:40 --> Input Class Initialized
INFO - 2023-08-19 06:27:40 --> Language Class Initialized
INFO - 2023-08-19 06:27:40 --> Language Class Initialized
INFO - 2023-08-19 06:27:40 --> Config Class Initialized
INFO - 2023-08-19 06:27:40 --> Loader Class Initialized
INFO - 2023-08-19 06:27:40 --> Helper loaded: url_helper
INFO - 2023-08-19 06:27:40 --> Helper loaded: file_helper
INFO - 2023-08-19 06:27:40 --> Helper loaded: form_helper
INFO - 2023-08-19 06:27:40 --> Helper loaded: my_helper
INFO - 2023-08-19 06:27:40 --> Database Driver Class Initialized
DEBUG - 2023-08-19 06:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 06:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:27:40 --> Controller Class Initialized
DEBUG - 2023-08-19 06:27:40 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-08-19 06:27:42 --> Final output sent to browser
DEBUG - 2023-08-19 06:27:42 --> Total execution time: 1.8943
INFO - 2023-08-19 12:33:18 --> Config Class Initialized
INFO - 2023-08-19 12:33:18 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:33:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:33:18 --> Utf8 Class Initialized
INFO - 2023-08-19 12:33:18 --> URI Class Initialized
INFO - 2023-08-19 12:33:18 --> Router Class Initialized
INFO - 2023-08-19 12:33:18 --> Output Class Initialized
INFO - 2023-08-19 12:33:18 --> Security Class Initialized
DEBUG - 2023-08-19 12:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:33:18 --> Input Class Initialized
INFO - 2023-08-19 12:33:18 --> Language Class Initialized
INFO - 2023-08-19 12:33:18 --> Language Class Initialized
INFO - 2023-08-19 12:33:18 --> Config Class Initialized
INFO - 2023-08-19 12:33:18 --> Loader Class Initialized
INFO - 2023-08-19 12:33:18 --> Helper loaded: url_helper
INFO - 2023-08-19 12:33:18 --> Helper loaded: file_helper
INFO - 2023-08-19 12:33:18 --> Helper loaded: form_helper
INFO - 2023-08-19 12:33:18 --> Helper loaded: my_helper
INFO - 2023-08-19 12:33:18 --> Database Driver Class Initialized
INFO - 2023-08-19 12:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:33:19 --> Controller Class Initialized
DEBUG - 2023-08-19 12:33:19 --> File loaded: /www/wwwroot/report.mhis.link/bintaro/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-08-19 12:33:19 --> File loaded: /www/wwwroot/report.mhis.link/bintaro/secondary/application/views/template_utama.php
INFO - 2023-08-19 12:33:19 --> Final output sent to browser
DEBUG - 2023-08-19 12:33:19 --> Total execution time: 0.5562
INFO - 2023-08-19 12:33:19 --> Config Class Initialized
INFO - 2023-08-19 12:33:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:33:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:33:19 --> Utf8 Class Initialized
INFO - 2023-08-19 12:33:19 --> URI Class Initialized
INFO - 2023-08-19 12:33:19 --> Router Class Initialized
INFO - 2023-08-19 12:33:19 --> Output Class Initialized
INFO - 2023-08-19 12:33:19 --> Security Class Initialized
DEBUG - 2023-08-19 12:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:33:19 --> Input Class Initialized
INFO - 2023-08-19 12:33:19 --> Language Class Initialized
INFO - 2023-08-19 12:33:19 --> Language Class Initialized
INFO - 2023-08-19 12:33:19 --> Config Class Initialized
INFO - 2023-08-19 12:33:19 --> Loader Class Initialized
INFO - 2023-08-19 12:33:19 --> Helper loaded: url_helper
INFO - 2023-08-19 12:33:19 --> Helper loaded: file_helper
INFO - 2023-08-19 12:33:19 --> Helper loaded: form_helper
INFO - 2023-08-19 12:33:19 --> Helper loaded: my_helper
INFO - 2023-08-19 12:33:19 --> Database Driver Class Initialized
INFO - 2023-08-19 12:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:33:19 --> Controller Class Initialized
INFO - 2023-08-19 12:33:21 --> Config Class Initialized
INFO - 2023-08-19 12:33:21 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:33:21 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:33:21 --> Utf8 Class Initialized
INFO - 2023-08-19 12:33:21 --> URI Class Initialized
INFO - 2023-08-19 12:33:21 --> Router Class Initialized
INFO - 2023-08-19 12:33:21 --> Output Class Initialized
INFO - 2023-08-19 12:33:21 --> Security Class Initialized
DEBUG - 2023-08-19 12:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:33:21 --> Input Class Initialized
INFO - 2023-08-19 12:33:21 --> Language Class Initialized
INFO - 2023-08-19 12:33:21 --> Language Class Initialized
INFO - 2023-08-19 12:33:21 --> Config Class Initialized
INFO - 2023-08-19 12:33:21 --> Loader Class Initialized
INFO - 2023-08-19 12:33:21 --> Helper loaded: url_helper
INFO - 2023-08-19 12:33:21 --> Helper loaded: file_helper
INFO - 2023-08-19 12:33:21 --> Helper loaded: form_helper
INFO - 2023-08-19 12:33:21 --> Helper loaded: my_helper
INFO - 2023-08-19 12:33:21 --> Database Driver Class Initialized
INFO - 2023-08-19 12:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:33:21 --> Controller Class Initialized
INFO - 2023-08-19 12:33:22 --> Final output sent to browser
DEBUG - 2023-08-19 12:33:22 --> Total execution time: 0.6445
INFO - 2023-08-19 12:33:25 --> Config Class Initialized
INFO - 2023-08-19 12:33:25 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:33:25 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:33:25 --> Utf8 Class Initialized
INFO - 2023-08-19 12:33:25 --> URI Class Initialized
INFO - 2023-08-19 12:33:25 --> Router Class Initialized
INFO - 2023-08-19 12:33:25 --> Output Class Initialized
INFO - 2023-08-19 12:33:25 --> Security Class Initialized
DEBUG - 2023-08-19 12:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:33:25 --> Input Class Initialized
INFO - 2023-08-19 12:33:25 --> Language Class Initialized
INFO - 2023-08-19 12:33:25 --> Language Class Initialized
INFO - 2023-08-19 12:33:25 --> Config Class Initialized
INFO - 2023-08-19 12:33:25 --> Loader Class Initialized
INFO - 2023-08-19 12:33:25 --> Helper loaded: url_helper
INFO - 2023-08-19 12:33:25 --> Helper loaded: file_helper
INFO - 2023-08-19 12:33:25 --> Helper loaded: form_helper
INFO - 2023-08-19 12:33:25 --> Helper loaded: my_helper
INFO - 2023-08-19 12:33:25 --> Database Driver Class Initialized
INFO - 2023-08-19 12:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:33:25 --> Controller Class Initialized
DEBUG - 2023-08-19 12:33:25 --> File loaded: /www/wwwroot/report.mhis.link/bintaro/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 12:33:25 --> File loaded: /www/wwwroot/report.mhis.link/bintaro/secondary/application/views/template_utama.php
INFO - 2023-08-19 12:33:25 --> Final output sent to browser
DEBUG - 2023-08-19 12:33:25 --> Total execution time: 0.1529
INFO - 2023-08-19 12:33:27 --> Config Class Initialized
INFO - 2023-08-19 12:33:27 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:33:27 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:33:27 --> Utf8 Class Initialized
INFO - 2023-08-19 12:33:27 --> URI Class Initialized
INFO - 2023-08-19 12:33:27 --> Router Class Initialized
INFO - 2023-08-19 12:33:27 --> Output Class Initialized
INFO - 2023-08-19 12:33:27 --> Security Class Initialized
DEBUG - 2023-08-19 12:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:33:27 --> Input Class Initialized
INFO - 2023-08-19 12:33:27 --> Language Class Initialized
INFO - 2023-08-19 12:33:27 --> Language Class Initialized
INFO - 2023-08-19 12:33:27 --> Config Class Initialized
INFO - 2023-08-19 12:33:27 --> Loader Class Initialized
INFO - 2023-08-19 12:33:27 --> Helper loaded: url_helper
INFO - 2023-08-19 12:33:27 --> Helper loaded: file_helper
INFO - 2023-08-19 12:33:27 --> Helper loaded: form_helper
INFO - 2023-08-19 12:33:27 --> Helper loaded: my_helper
INFO - 2023-08-19 12:33:27 --> Database Driver Class Initialized
INFO - 2023-08-19 12:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:33:27 --> Controller Class Initialized
DEBUG - 2023-08-19 12:33:27 --> File loaded: /www/wwwroot/report.mhis.link/bintaro/secondary/application/modules/n_keterampilan/views/list.php
DEBUG - 2023-08-19 12:33:27 --> File loaded: /www/wwwroot/report.mhis.link/bintaro/secondary/application/views/template_utama.php
INFO - 2023-08-19 12:33:27 --> Final output sent to browser
DEBUG - 2023-08-19 12:33:27 --> Total execution time: 0.1098
INFO - 2023-08-19 12:33:28 --> Config Class Initialized
INFO - 2023-08-19 12:33:28 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:33:28 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:33:28 --> Utf8 Class Initialized
INFO - 2023-08-19 12:33:28 --> URI Class Initialized
INFO - 2023-08-19 12:33:28 --> Router Class Initialized
INFO - 2023-08-19 12:33:28 --> Output Class Initialized
INFO - 2023-08-19 12:33:29 --> Security Class Initialized
DEBUG - 2023-08-19 12:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:33:29 --> Input Class Initialized
INFO - 2023-08-19 12:33:29 --> Language Class Initialized
INFO - 2023-08-19 12:33:29 --> Language Class Initialized
INFO - 2023-08-19 12:33:29 --> Config Class Initialized
INFO - 2023-08-19 12:33:29 --> Loader Class Initialized
INFO - 2023-08-19 12:33:29 --> Helper loaded: url_helper
INFO - 2023-08-19 12:33:29 --> Helper loaded: file_helper
INFO - 2023-08-19 12:33:29 --> Helper loaded: form_helper
INFO - 2023-08-19 12:33:29 --> Helper loaded: my_helper
INFO - 2023-08-19 12:33:29 --> Database Driver Class Initialized
INFO - 2023-08-19 12:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:33:29 --> Controller Class Initialized
INFO - 2023-08-19 12:33:29 --> Final output sent to browser
DEBUG - 2023-08-19 12:33:29 --> Total execution time: 0.3725
INFO - 2023-08-19 12:33:33 --> Config Class Initialized
INFO - 2023-08-19 12:33:33 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:33:33 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:33:33 --> Utf8 Class Initialized
INFO - 2023-08-19 12:33:33 --> URI Class Initialized
INFO - 2023-08-19 12:33:33 --> Router Class Initialized
INFO - 2023-08-19 12:33:33 --> Output Class Initialized
INFO - 2023-08-19 12:33:33 --> Security Class Initialized
DEBUG - 2023-08-19 12:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:33:33 --> Input Class Initialized
INFO - 2023-08-19 12:33:33 --> Language Class Initialized
INFO - 2023-08-19 12:33:33 --> Language Class Initialized
INFO - 2023-08-19 12:33:33 --> Config Class Initialized
INFO - 2023-08-19 12:33:33 --> Loader Class Initialized
INFO - 2023-08-19 12:33:33 --> Helper loaded: url_helper
INFO - 2023-08-19 12:33:33 --> Helper loaded: file_helper
INFO - 2023-08-19 12:33:33 --> Helper loaded: form_helper
INFO - 2023-08-19 12:33:33 --> Helper loaded: my_helper
INFO - 2023-08-19 12:33:33 --> Database Driver Class Initialized
INFO - 2023-08-19 12:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:33:33 --> Controller Class Initialized
DEBUG - 2023-08-19 12:33:33 --> File loaded: /www/wwwroot/report.mhis.link/bintaro/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 12:33:33 --> File loaded: /www/wwwroot/report.mhis.link/bintaro/secondary/application/views/template_utama.php
INFO - 2023-08-19 12:33:33 --> Final output sent to browser
DEBUG - 2023-08-19 12:33:33 --> Total execution time: 0.0444
INFO - 2023-08-19 12:33:50 --> Config Class Initialized
INFO - 2023-08-19 12:33:50 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:33:50 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:33:50 --> Utf8 Class Initialized
INFO - 2023-08-19 12:33:50 --> URI Class Initialized
INFO - 2023-08-19 12:33:50 --> Router Class Initialized
INFO - 2023-08-19 12:33:50 --> Output Class Initialized
INFO - 2023-08-19 12:33:50 --> Security Class Initialized
DEBUG - 2023-08-19 12:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:33:50 --> Input Class Initialized
INFO - 2023-08-19 12:33:50 --> Language Class Initialized
INFO - 2023-08-19 12:33:50 --> Language Class Initialized
INFO - 2023-08-19 12:33:50 --> Config Class Initialized
INFO - 2023-08-19 12:33:50 --> Loader Class Initialized
INFO - 2023-08-19 12:33:50 --> Helper loaded: url_helper
INFO - 2023-08-19 12:33:50 --> Helper loaded: file_helper
INFO - 2023-08-19 12:33:50 --> Helper loaded: form_helper
INFO - 2023-08-19 12:33:50 --> Helper loaded: my_helper
INFO - 2023-08-19 12:33:51 --> Database Driver Class Initialized
INFO - 2023-08-19 12:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:33:51 --> Controller Class Initialized
INFO - 2023-08-19 12:33:51 --> Helper loaded: cookie_helper
INFO - 2023-08-19 12:33:51 --> Config Class Initialized
INFO - 2023-08-19 12:33:51 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:33:51 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:33:51 --> Utf8 Class Initialized
INFO - 2023-08-19 12:33:51 --> URI Class Initialized
INFO - 2023-08-19 12:33:51 --> Router Class Initialized
INFO - 2023-08-19 12:33:51 --> Output Class Initialized
INFO - 2023-08-19 12:33:52 --> Security Class Initialized
DEBUG - 2023-08-19 12:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:33:52 --> Input Class Initialized
INFO - 2023-08-19 12:33:52 --> Language Class Initialized
INFO - 2023-08-19 12:33:52 --> Language Class Initialized
INFO - 2023-08-19 12:33:52 --> Config Class Initialized
INFO - 2023-08-19 12:33:52 --> Loader Class Initialized
INFO - 2023-08-19 12:33:52 --> Helper loaded: url_helper
INFO - 2023-08-19 12:33:52 --> Helper loaded: file_helper
INFO - 2023-08-19 12:33:52 --> Helper loaded: form_helper
INFO - 2023-08-19 12:33:52 --> Helper loaded: my_helper
INFO - 2023-08-19 12:33:52 --> Database Driver Class Initialized
INFO - 2023-08-19 12:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:33:52 --> Controller Class Initialized
INFO - 2023-08-19 12:33:52 --> Config Class Initialized
INFO - 2023-08-19 12:33:52 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:33:52 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:33:52 --> Utf8 Class Initialized
INFO - 2023-08-19 12:33:52 --> URI Class Initialized
INFO - 2023-08-19 12:33:52 --> Router Class Initialized
INFO - 2023-08-19 12:33:52 --> Output Class Initialized
INFO - 2023-08-19 12:33:52 --> Security Class Initialized
DEBUG - 2023-08-19 12:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:33:52 --> Input Class Initialized
INFO - 2023-08-19 12:33:52 --> Language Class Initialized
INFO - 2023-08-19 12:33:52 --> Language Class Initialized
INFO - 2023-08-19 12:33:52 --> Config Class Initialized
INFO - 2023-08-19 12:33:52 --> Loader Class Initialized
INFO - 2023-08-19 12:33:52 --> Helper loaded: url_helper
INFO - 2023-08-19 12:33:52 --> Helper loaded: file_helper
INFO - 2023-08-19 12:33:52 --> Helper loaded: form_helper
INFO - 2023-08-19 12:33:52 --> Helper loaded: my_helper
INFO - 2023-08-19 12:33:52 --> Database Driver Class Initialized
INFO - 2023-08-19 12:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:33:52 --> Controller Class Initialized
DEBUG - 2023-08-19 12:33:52 --> File loaded: /www/wwwroot/report.mhis.link/bintaro/secondary/application/modules/login/views/login.php
DEBUG - 2023-08-19 12:33:52 --> File loaded: /www/wwwroot/report.mhis.link/bintaro/secondary/application/views/template_utama.php
INFO - 2023-08-19 12:33:52 --> Final output sent to browser
DEBUG - 2023-08-19 12:33:52 --> Total execution time: 0.0707
INFO - 2023-08-19 12:36:13 --> Config Class Initialized
INFO - 2023-08-19 12:36:13 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:36:13 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:36:13 --> Utf8 Class Initialized
INFO - 2023-08-19 12:36:13 --> URI Class Initialized
DEBUG - 2023-08-19 12:36:13 --> No URI present. Default controller set.
INFO - 2023-08-19 12:36:13 --> Router Class Initialized
INFO - 2023-08-19 12:36:13 --> Output Class Initialized
INFO - 2023-08-19 12:36:13 --> Security Class Initialized
DEBUG - 2023-08-19 12:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:36:13 --> Input Class Initialized
INFO - 2023-08-19 12:36:13 --> Language Class Initialized
INFO - 2023-08-19 12:36:13 --> Language Class Initialized
INFO - 2023-08-19 12:36:13 --> Config Class Initialized
INFO - 2023-08-19 12:36:13 --> Loader Class Initialized
INFO - 2023-08-19 12:36:13 --> Helper loaded: url_helper
INFO - 2023-08-19 12:36:13 --> Helper loaded: file_helper
INFO - 2023-08-19 12:36:13 --> Helper loaded: form_helper
INFO - 2023-08-19 12:36:13 --> Helper loaded: my_helper
INFO - 2023-08-19 12:36:13 --> Database Driver Class Initialized
INFO - 2023-08-19 12:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:36:13 --> Controller Class Initialized
INFO - 2023-08-19 12:36:13 --> Config Class Initialized
INFO - 2023-08-19 12:36:13 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:36:13 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:36:13 --> Utf8 Class Initialized
INFO - 2023-08-19 12:36:13 --> URI Class Initialized
INFO - 2023-08-19 12:36:13 --> Router Class Initialized
INFO - 2023-08-19 12:36:13 --> Output Class Initialized
INFO - 2023-08-19 12:36:13 --> Security Class Initialized
DEBUG - 2023-08-19 12:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:36:13 --> Input Class Initialized
INFO - 2023-08-19 12:36:13 --> Language Class Initialized
INFO - 2023-08-19 12:36:13 --> Language Class Initialized
INFO - 2023-08-19 12:36:13 --> Config Class Initialized
INFO - 2023-08-19 12:36:13 --> Loader Class Initialized
INFO - 2023-08-19 12:36:13 --> Helper loaded: url_helper
INFO - 2023-08-19 12:36:13 --> Helper loaded: file_helper
INFO - 2023-08-19 12:36:13 --> Helper loaded: form_helper
INFO - 2023-08-19 12:36:13 --> Helper loaded: my_helper
INFO - 2023-08-19 12:36:13 --> Database Driver Class Initialized
INFO - 2023-08-19 12:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:36:13 --> Controller Class Initialized
DEBUG - 2023-08-19 12:36:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-08-19 12:36:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 12:36:13 --> Final output sent to browser
DEBUG - 2023-08-19 12:36:13 --> Total execution time: 0.0391
INFO - 2023-08-19 12:36:20 --> Config Class Initialized
INFO - 2023-08-19 12:36:20 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:36:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:36:20 --> Utf8 Class Initialized
INFO - 2023-08-19 12:36:20 --> URI Class Initialized
INFO - 2023-08-19 12:36:20 --> Router Class Initialized
INFO - 2023-08-19 12:36:20 --> Output Class Initialized
INFO - 2023-08-19 12:36:20 --> Security Class Initialized
DEBUG - 2023-08-19 12:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:36:20 --> Input Class Initialized
INFO - 2023-08-19 12:36:20 --> Language Class Initialized
INFO - 2023-08-19 12:36:20 --> Language Class Initialized
INFO - 2023-08-19 12:36:20 --> Config Class Initialized
INFO - 2023-08-19 12:36:20 --> Loader Class Initialized
INFO - 2023-08-19 12:36:20 --> Helper loaded: url_helper
INFO - 2023-08-19 12:36:20 --> Helper loaded: file_helper
INFO - 2023-08-19 12:36:20 --> Helper loaded: form_helper
INFO - 2023-08-19 12:36:20 --> Helper loaded: my_helper
INFO - 2023-08-19 12:36:20 --> Database Driver Class Initialized
INFO - 2023-08-19 12:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:36:20 --> Controller Class Initialized
INFO - 2023-08-19 12:36:20 --> Helper loaded: cookie_helper
INFO - 2023-08-19 12:36:20 --> Final output sent to browser
DEBUG - 2023-08-19 12:36:20 --> Total execution time: 0.5935
INFO - 2023-08-19 12:36:20 --> Config Class Initialized
INFO - 2023-08-19 12:36:20 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:36:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:36:20 --> Utf8 Class Initialized
INFO - 2023-08-19 12:36:20 --> URI Class Initialized
INFO - 2023-08-19 12:36:20 --> Router Class Initialized
INFO - 2023-08-19 12:36:20 --> Output Class Initialized
INFO - 2023-08-19 12:36:20 --> Security Class Initialized
DEBUG - 2023-08-19 12:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:36:20 --> Input Class Initialized
INFO - 2023-08-19 12:36:20 --> Language Class Initialized
INFO - 2023-08-19 12:36:20 --> Language Class Initialized
INFO - 2023-08-19 12:36:20 --> Config Class Initialized
INFO - 2023-08-19 12:36:20 --> Loader Class Initialized
INFO - 2023-08-19 12:36:20 --> Helper loaded: url_helper
INFO - 2023-08-19 12:36:20 --> Helper loaded: file_helper
INFO - 2023-08-19 12:36:20 --> Helper loaded: form_helper
INFO - 2023-08-19 12:36:20 --> Helper loaded: my_helper
INFO - 2023-08-19 12:36:20 --> Database Driver Class Initialized
INFO - 2023-08-19 12:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:36:20 --> Controller Class Initialized
DEBUG - 2023-08-19 12:36:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-08-19 12:36:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 12:36:20 --> Final output sent to browser
DEBUG - 2023-08-19 12:36:20 --> Total execution time: 0.0868
INFO - 2023-08-19 12:36:23 --> Config Class Initialized
INFO - 2023-08-19 12:36:23 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:36:23 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:36:23 --> Utf8 Class Initialized
INFO - 2023-08-19 12:36:23 --> URI Class Initialized
INFO - 2023-08-19 12:36:23 --> Router Class Initialized
INFO - 2023-08-19 12:36:23 --> Output Class Initialized
INFO - 2023-08-19 12:36:23 --> Security Class Initialized
DEBUG - 2023-08-19 12:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:36:23 --> Input Class Initialized
INFO - 2023-08-19 12:36:23 --> Language Class Initialized
INFO - 2023-08-19 12:36:23 --> Language Class Initialized
INFO - 2023-08-19 12:36:23 --> Config Class Initialized
INFO - 2023-08-19 12:36:23 --> Loader Class Initialized
INFO - 2023-08-19 12:36:23 --> Helper loaded: url_helper
INFO - 2023-08-19 12:36:23 --> Helper loaded: file_helper
INFO - 2023-08-19 12:36:23 --> Helper loaded: form_helper
INFO - 2023-08-19 12:36:23 --> Helper loaded: my_helper
INFO - 2023-08-19 12:36:23 --> Database Driver Class Initialized
INFO - 2023-08-19 12:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:36:23 --> Controller Class Initialized
DEBUG - 2023-08-19 12:36:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2023-08-19 12:36:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 12:36:23 --> Final output sent to browser
DEBUG - 2023-08-19 12:36:23 --> Total execution time: 0.0933
INFO - 2023-08-19 12:36:23 --> Config Class Initialized
INFO - 2023-08-19 12:36:23 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:36:23 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:36:23 --> Utf8 Class Initialized
INFO - 2023-08-19 12:36:23 --> URI Class Initialized
INFO - 2023-08-19 12:36:23 --> Router Class Initialized
INFO - 2023-08-19 12:36:23 --> Output Class Initialized
INFO - 2023-08-19 12:36:23 --> Security Class Initialized
DEBUG - 2023-08-19 12:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:36:23 --> Input Class Initialized
INFO - 2023-08-19 12:36:23 --> Language Class Initialized
ERROR - 2023-08-19 12:36:23 --> 404 Page Not Found: /index
INFO - 2023-08-19 12:36:23 --> Config Class Initialized
INFO - 2023-08-19 12:36:23 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:36:23 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:36:23 --> Utf8 Class Initialized
INFO - 2023-08-19 12:36:23 --> URI Class Initialized
INFO - 2023-08-19 12:36:23 --> Router Class Initialized
INFO - 2023-08-19 12:36:23 --> Output Class Initialized
INFO - 2023-08-19 12:36:23 --> Security Class Initialized
DEBUG - 2023-08-19 12:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:36:23 --> Input Class Initialized
INFO - 2023-08-19 12:36:23 --> Language Class Initialized
INFO - 2023-08-19 12:36:23 --> Language Class Initialized
INFO - 2023-08-19 12:36:23 --> Config Class Initialized
INFO - 2023-08-19 12:36:23 --> Loader Class Initialized
INFO - 2023-08-19 12:36:23 --> Helper loaded: url_helper
INFO - 2023-08-19 12:36:23 --> Helper loaded: file_helper
INFO - 2023-08-19 12:36:23 --> Helper loaded: form_helper
INFO - 2023-08-19 12:36:23 --> Helper loaded: my_helper
INFO - 2023-08-19 12:36:23 --> Database Driver Class Initialized
INFO - 2023-08-19 12:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:36:23 --> Controller Class Initialized
INFO - 2023-08-19 12:36:27 --> Config Class Initialized
INFO - 2023-08-19 12:36:27 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:36:27 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:36:27 --> Utf8 Class Initialized
INFO - 2023-08-19 12:36:27 --> URI Class Initialized
INFO - 2023-08-19 12:36:27 --> Router Class Initialized
INFO - 2023-08-19 12:36:27 --> Output Class Initialized
INFO - 2023-08-19 12:36:27 --> Security Class Initialized
DEBUG - 2023-08-19 12:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:36:27 --> Input Class Initialized
INFO - 2023-08-19 12:36:27 --> Language Class Initialized
INFO - 2023-08-19 12:36:28 --> Language Class Initialized
INFO - 2023-08-19 12:36:28 --> Config Class Initialized
INFO - 2023-08-19 12:36:28 --> Loader Class Initialized
INFO - 2023-08-19 12:36:28 --> Helper loaded: url_helper
INFO - 2023-08-19 12:36:28 --> Helper loaded: file_helper
INFO - 2023-08-19 12:36:28 --> Helper loaded: form_helper
INFO - 2023-08-19 12:36:28 --> Helper loaded: my_helper
INFO - 2023-08-19 12:36:28 --> Database Driver Class Initialized
INFO - 2023-08-19 12:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:36:28 --> Controller Class Initialized
INFO - 2023-08-19 12:36:28 --> Helper loaded: cookie_helper
INFO - 2023-08-19 12:36:28 --> Config Class Initialized
INFO - 2023-08-19 12:36:28 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:36:28 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:36:28 --> Utf8 Class Initialized
INFO - 2023-08-19 12:36:28 --> URI Class Initialized
INFO - 2023-08-19 12:36:28 --> Router Class Initialized
INFO - 2023-08-19 12:36:28 --> Output Class Initialized
INFO - 2023-08-19 12:36:28 --> Security Class Initialized
DEBUG - 2023-08-19 12:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:36:28 --> Input Class Initialized
INFO - 2023-08-19 12:36:28 --> Language Class Initialized
INFO - 2023-08-19 12:36:28 --> Language Class Initialized
INFO - 2023-08-19 12:36:28 --> Config Class Initialized
INFO - 2023-08-19 12:36:28 --> Loader Class Initialized
INFO - 2023-08-19 12:36:28 --> Helper loaded: url_helper
INFO - 2023-08-19 12:36:28 --> Helper loaded: file_helper
INFO - 2023-08-19 12:36:28 --> Helper loaded: form_helper
INFO - 2023-08-19 12:36:28 --> Helper loaded: my_helper
INFO - 2023-08-19 12:36:28 --> Database Driver Class Initialized
INFO - 2023-08-19 12:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:36:28 --> Controller Class Initialized
INFO - 2023-08-19 12:36:28 --> Config Class Initialized
INFO - 2023-08-19 12:36:28 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:36:28 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:36:28 --> Utf8 Class Initialized
INFO - 2023-08-19 12:36:28 --> URI Class Initialized
INFO - 2023-08-19 12:36:28 --> Router Class Initialized
INFO - 2023-08-19 12:36:28 --> Output Class Initialized
INFO - 2023-08-19 12:36:28 --> Security Class Initialized
DEBUG - 2023-08-19 12:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:36:28 --> Input Class Initialized
INFO - 2023-08-19 12:36:28 --> Language Class Initialized
INFO - 2023-08-19 12:36:28 --> Language Class Initialized
INFO - 2023-08-19 12:36:28 --> Config Class Initialized
INFO - 2023-08-19 12:36:28 --> Loader Class Initialized
INFO - 2023-08-19 12:36:28 --> Helper loaded: url_helper
INFO - 2023-08-19 12:36:28 --> Helper loaded: file_helper
INFO - 2023-08-19 12:36:28 --> Helper loaded: form_helper
INFO - 2023-08-19 12:36:28 --> Helper loaded: my_helper
INFO - 2023-08-19 12:36:28 --> Database Driver Class Initialized
INFO - 2023-08-19 12:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:36:28 --> Controller Class Initialized
DEBUG - 2023-08-19 12:36:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-08-19 12:36:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 12:36:28 --> Final output sent to browser
DEBUG - 2023-08-19 12:36:28 --> Total execution time: 0.1185
INFO - 2023-08-19 12:36:31 --> Config Class Initialized
INFO - 2023-08-19 12:36:31 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:36:31 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:36:31 --> Utf8 Class Initialized
INFO - 2023-08-19 12:36:31 --> URI Class Initialized
INFO - 2023-08-19 12:36:31 --> Router Class Initialized
INFO - 2023-08-19 12:36:31 --> Output Class Initialized
INFO - 2023-08-19 12:36:31 --> Security Class Initialized
DEBUG - 2023-08-19 12:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:36:31 --> Input Class Initialized
INFO - 2023-08-19 12:36:31 --> Language Class Initialized
INFO - 2023-08-19 12:36:31 --> Language Class Initialized
INFO - 2023-08-19 12:36:31 --> Config Class Initialized
INFO - 2023-08-19 12:36:31 --> Loader Class Initialized
INFO - 2023-08-19 12:36:31 --> Helper loaded: url_helper
INFO - 2023-08-19 12:36:31 --> Helper loaded: file_helper
INFO - 2023-08-19 12:36:31 --> Helper loaded: form_helper
INFO - 2023-08-19 12:36:31 --> Helper loaded: my_helper
INFO - 2023-08-19 12:36:32 --> Database Driver Class Initialized
INFO - 2023-08-19 12:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:36:32 --> Controller Class Initialized
INFO - 2023-08-19 12:36:32 --> Helper loaded: cookie_helper
INFO - 2023-08-19 12:36:32 --> Final output sent to browser
DEBUG - 2023-08-19 12:36:32 --> Total execution time: 1.0728
INFO - 2023-08-19 12:36:32 --> Config Class Initialized
INFO - 2023-08-19 12:36:32 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:36:32 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:36:32 --> Utf8 Class Initialized
INFO - 2023-08-19 12:36:32 --> URI Class Initialized
INFO - 2023-08-19 12:36:32 --> Router Class Initialized
INFO - 2023-08-19 12:36:32 --> Output Class Initialized
INFO - 2023-08-19 12:36:32 --> Security Class Initialized
DEBUG - 2023-08-19 12:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:36:32 --> Input Class Initialized
INFO - 2023-08-19 12:36:32 --> Language Class Initialized
INFO - 2023-08-19 12:36:32 --> Language Class Initialized
INFO - 2023-08-19 12:36:32 --> Config Class Initialized
INFO - 2023-08-19 12:36:32 --> Loader Class Initialized
INFO - 2023-08-19 12:36:32 --> Helper loaded: url_helper
INFO - 2023-08-19 12:36:32 --> Helper loaded: file_helper
INFO - 2023-08-19 12:36:32 --> Helper loaded: form_helper
INFO - 2023-08-19 12:36:32 --> Helper loaded: my_helper
INFO - 2023-08-19 12:36:33 --> Database Driver Class Initialized
INFO - 2023-08-19 12:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:36:33 --> Controller Class Initialized
DEBUG - 2023-08-19 12:36:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 12:36:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 12:36:33 --> Final output sent to browser
DEBUG - 2023-08-19 12:36:33 --> Total execution time: 0.6717
INFO - 2023-08-19 12:36:34 --> Config Class Initialized
INFO - 2023-08-19 12:36:34 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:36:34 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:36:34 --> Utf8 Class Initialized
INFO - 2023-08-19 12:36:34 --> URI Class Initialized
INFO - 2023-08-19 12:36:34 --> Router Class Initialized
INFO - 2023-08-19 12:36:34 --> Output Class Initialized
INFO - 2023-08-19 12:36:34 --> Security Class Initialized
DEBUG - 2023-08-19 12:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:36:34 --> Input Class Initialized
INFO - 2023-08-19 12:36:34 --> Language Class Initialized
INFO - 2023-08-19 12:36:34 --> Language Class Initialized
INFO - 2023-08-19 12:36:34 --> Config Class Initialized
INFO - 2023-08-19 12:36:34 --> Loader Class Initialized
INFO - 2023-08-19 12:36:34 --> Helper loaded: url_helper
INFO - 2023-08-19 12:36:34 --> Helper loaded: file_helper
INFO - 2023-08-19 12:36:34 --> Helper loaded: form_helper
INFO - 2023-08-19 12:36:34 --> Helper loaded: my_helper
INFO - 2023-08-19 12:36:34 --> Database Driver Class Initialized
INFO - 2023-08-19 12:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:36:34 --> Controller Class Initialized
DEBUG - 2023-08-19 12:36:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 12:36:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 12:36:34 --> Final output sent to browser
DEBUG - 2023-08-19 12:36:34 --> Total execution time: 0.3916
INFO - 2023-08-19 12:36:36 --> Config Class Initialized
INFO - 2023-08-19 12:36:36 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:36:36 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:36:36 --> Utf8 Class Initialized
INFO - 2023-08-19 12:36:36 --> URI Class Initialized
INFO - 2023-08-19 12:36:36 --> Router Class Initialized
INFO - 2023-08-19 12:36:36 --> Output Class Initialized
INFO - 2023-08-19 12:36:36 --> Security Class Initialized
DEBUG - 2023-08-19 12:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:36:36 --> Input Class Initialized
INFO - 2023-08-19 12:36:36 --> Language Class Initialized
INFO - 2023-08-19 12:36:36 --> Language Class Initialized
INFO - 2023-08-19 12:36:36 --> Config Class Initialized
INFO - 2023-08-19 12:36:36 --> Loader Class Initialized
INFO - 2023-08-19 12:36:36 --> Helper loaded: url_helper
INFO - 2023-08-19 12:36:36 --> Helper loaded: file_helper
INFO - 2023-08-19 12:36:36 --> Helper loaded: form_helper
INFO - 2023-08-19 12:36:37 --> Helper loaded: my_helper
INFO - 2023-08-19 12:36:37 --> Database Driver Class Initialized
INFO - 2023-08-19 12:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:36:37 --> Controller Class Initialized
DEBUG - 2023-08-19 12:36:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-08-19 12:36:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 12:36:38 --> Final output sent to browser
DEBUG - 2023-08-19 12:36:38 --> Total execution time: 1.8342
INFO - 2023-08-19 12:36:38 --> Config Class Initialized
INFO - 2023-08-19 12:36:38 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:36:38 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:36:38 --> Utf8 Class Initialized
INFO - 2023-08-19 12:36:38 --> URI Class Initialized
INFO - 2023-08-19 12:36:38 --> Router Class Initialized
INFO - 2023-08-19 12:36:38 --> Output Class Initialized
INFO - 2023-08-19 12:36:38 --> Security Class Initialized
DEBUG - 2023-08-19 12:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:36:38 --> Input Class Initialized
INFO - 2023-08-19 12:36:38 --> Language Class Initialized
INFO - 2023-08-19 12:36:39 --> Language Class Initialized
INFO - 2023-08-19 12:36:39 --> Config Class Initialized
INFO - 2023-08-19 12:36:39 --> Loader Class Initialized
INFO - 2023-08-19 12:36:39 --> Helper loaded: url_helper
INFO - 2023-08-19 12:36:39 --> Helper loaded: file_helper
INFO - 2023-08-19 12:36:39 --> Helper loaded: form_helper
INFO - 2023-08-19 12:36:39 --> Helper loaded: my_helper
INFO - 2023-08-19 12:36:39 --> Database Driver Class Initialized
INFO - 2023-08-19 12:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:36:39 --> Controller Class Initialized
INFO - 2023-08-19 12:36:40 --> Config Class Initialized
INFO - 2023-08-19 12:36:40 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:36:40 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:36:40 --> Utf8 Class Initialized
INFO - 2023-08-19 12:36:40 --> URI Class Initialized
INFO - 2023-08-19 12:36:40 --> Router Class Initialized
INFO - 2023-08-19 12:36:40 --> Output Class Initialized
INFO - 2023-08-19 12:36:40 --> Security Class Initialized
DEBUG - 2023-08-19 12:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:36:40 --> Input Class Initialized
INFO - 2023-08-19 12:36:40 --> Language Class Initialized
INFO - 2023-08-19 12:36:40 --> Language Class Initialized
INFO - 2023-08-19 12:36:40 --> Config Class Initialized
INFO - 2023-08-19 12:36:40 --> Loader Class Initialized
INFO - 2023-08-19 12:36:40 --> Helper loaded: url_helper
INFO - 2023-08-19 12:36:40 --> Helper loaded: file_helper
INFO - 2023-08-19 12:36:40 --> Helper loaded: form_helper
INFO - 2023-08-19 12:36:40 --> Helper loaded: my_helper
INFO - 2023-08-19 12:36:40 --> Database Driver Class Initialized
INFO - 2023-08-19 12:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:36:40 --> Controller Class Initialized
INFO - 2023-08-19 12:36:40 --> Final output sent to browser
DEBUG - 2023-08-19 12:36:40 --> Total execution time: 0.3679
INFO - 2023-08-19 12:36:43 --> Config Class Initialized
INFO - 2023-08-19 12:36:43 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:36:43 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:36:43 --> Utf8 Class Initialized
INFO - 2023-08-19 12:36:43 --> URI Class Initialized
INFO - 2023-08-19 12:36:43 --> Router Class Initialized
INFO - 2023-08-19 12:36:43 --> Output Class Initialized
INFO - 2023-08-19 12:36:43 --> Security Class Initialized
DEBUG - 2023-08-19 12:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:36:43 --> Input Class Initialized
INFO - 2023-08-19 12:36:43 --> Language Class Initialized
INFO - 2023-08-19 12:36:43 --> Language Class Initialized
INFO - 2023-08-19 12:36:43 --> Config Class Initialized
INFO - 2023-08-19 12:36:43 --> Loader Class Initialized
INFO - 2023-08-19 12:36:43 --> Helper loaded: url_helper
INFO - 2023-08-19 12:36:43 --> Helper loaded: file_helper
INFO - 2023-08-19 12:36:43 --> Helper loaded: form_helper
INFO - 2023-08-19 12:36:43 --> Helper loaded: my_helper
INFO - 2023-08-19 12:36:44 --> Database Driver Class Initialized
INFO - 2023-08-19 12:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:36:44 --> Controller Class Initialized
DEBUG - 2023-08-19 12:36:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 12:36:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 12:36:44 --> Final output sent to browser
DEBUG - 2023-08-19 12:36:44 --> Total execution time: 0.3773
INFO - 2023-08-19 12:36:50 --> Config Class Initialized
INFO - 2023-08-19 12:36:50 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:36:50 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:36:50 --> Utf8 Class Initialized
INFO - 2023-08-19 12:36:50 --> URI Class Initialized
DEBUG - 2023-08-19 12:36:50 --> No URI present. Default controller set.
INFO - 2023-08-19 12:36:50 --> Router Class Initialized
INFO - 2023-08-19 12:36:50 --> Output Class Initialized
INFO - 2023-08-19 12:36:50 --> Security Class Initialized
DEBUG - 2023-08-19 12:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:36:50 --> Input Class Initialized
INFO - 2023-08-19 12:36:50 --> Language Class Initialized
INFO - 2023-08-19 12:36:50 --> Language Class Initialized
INFO - 2023-08-19 12:36:50 --> Config Class Initialized
INFO - 2023-08-19 12:36:50 --> Loader Class Initialized
INFO - 2023-08-19 12:36:50 --> Helper loaded: url_helper
INFO - 2023-08-19 12:36:50 --> Helper loaded: file_helper
INFO - 2023-08-19 12:36:51 --> Helper loaded: form_helper
INFO - 2023-08-19 12:36:51 --> Helper loaded: my_helper
INFO - 2023-08-19 12:36:51 --> Database Driver Class Initialized
INFO - 2023-08-19 12:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:36:51 --> Controller Class Initialized
DEBUG - 2023-08-19 12:36:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 12:36:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 12:36:51 --> Final output sent to browser
DEBUG - 2023-08-19 12:36:51 --> Total execution time: 1.5482
INFO - 2023-08-19 12:41:38 --> Config Class Initialized
INFO - 2023-08-19 12:41:38 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:41:38 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:41:38 --> Utf8 Class Initialized
INFO - 2023-08-19 12:41:38 --> URI Class Initialized
INFO - 2023-08-19 12:41:38 --> Router Class Initialized
INFO - 2023-08-19 12:41:38 --> Output Class Initialized
INFO - 2023-08-19 12:41:38 --> Security Class Initialized
DEBUG - 2023-08-19 12:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:41:38 --> Input Class Initialized
INFO - 2023-08-19 12:41:38 --> Language Class Initialized
INFO - 2023-08-19 12:41:38 --> Language Class Initialized
INFO - 2023-08-19 12:41:38 --> Config Class Initialized
INFO - 2023-08-19 12:41:38 --> Loader Class Initialized
INFO - 2023-08-19 12:41:38 --> Helper loaded: url_helper
INFO - 2023-08-19 12:41:38 --> Helper loaded: file_helper
INFO - 2023-08-19 12:41:38 --> Helper loaded: form_helper
INFO - 2023-08-19 12:41:38 --> Helper loaded: my_helper
INFO - 2023-08-19 12:41:39 --> Database Driver Class Initialized
INFO - 2023-08-19 12:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:41:39 --> Controller Class Initialized
INFO - 2023-08-19 12:41:39 --> Helper loaded: cookie_helper
INFO - 2023-08-19 12:41:39 --> Config Class Initialized
INFO - 2023-08-19 12:41:39 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:41:39 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:41:39 --> Utf8 Class Initialized
INFO - 2023-08-19 12:41:39 --> URI Class Initialized
INFO - 2023-08-19 12:41:39 --> Router Class Initialized
INFO - 2023-08-19 12:41:39 --> Output Class Initialized
INFO - 2023-08-19 12:41:39 --> Security Class Initialized
DEBUG - 2023-08-19 12:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:41:39 --> Input Class Initialized
INFO - 2023-08-19 12:41:39 --> Language Class Initialized
INFO - 2023-08-19 12:41:39 --> Language Class Initialized
INFO - 2023-08-19 12:41:39 --> Config Class Initialized
INFO - 2023-08-19 12:41:39 --> Loader Class Initialized
INFO - 2023-08-19 12:41:39 --> Helper loaded: url_helper
INFO - 2023-08-19 12:41:39 --> Helper loaded: file_helper
INFO - 2023-08-19 12:41:39 --> Helper loaded: form_helper
INFO - 2023-08-19 12:41:39 --> Helper loaded: my_helper
INFO - 2023-08-19 12:41:39 --> Database Driver Class Initialized
INFO - 2023-08-19 12:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:41:39 --> Controller Class Initialized
INFO - 2023-08-19 12:41:39 --> Config Class Initialized
INFO - 2023-08-19 12:41:39 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:41:39 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:41:39 --> Utf8 Class Initialized
INFO - 2023-08-19 12:41:39 --> URI Class Initialized
INFO - 2023-08-19 12:41:39 --> Router Class Initialized
INFO - 2023-08-19 12:41:39 --> Output Class Initialized
INFO - 2023-08-19 12:41:39 --> Security Class Initialized
DEBUG - 2023-08-19 12:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:41:39 --> Input Class Initialized
INFO - 2023-08-19 12:41:39 --> Language Class Initialized
INFO - 2023-08-19 12:41:39 --> Language Class Initialized
INFO - 2023-08-19 12:41:39 --> Config Class Initialized
INFO - 2023-08-19 12:41:39 --> Loader Class Initialized
INFO - 2023-08-19 12:41:39 --> Helper loaded: url_helper
INFO - 2023-08-19 12:41:39 --> Helper loaded: file_helper
INFO - 2023-08-19 12:41:39 --> Helper loaded: form_helper
INFO - 2023-08-19 12:41:39 --> Helper loaded: my_helper
INFO - 2023-08-19 12:41:39 --> Database Driver Class Initialized
INFO - 2023-08-19 12:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:41:39 --> Controller Class Initialized
DEBUG - 2023-08-19 12:41:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-08-19 12:41:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 12:41:39 --> Final output sent to browser
DEBUG - 2023-08-19 12:41:39 --> Total execution time: 0.1206
INFO - 2023-08-19 13:45:07 --> Config Class Initialized
INFO - 2023-08-19 13:45:07 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:45:07 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:45:07 --> Utf8 Class Initialized
INFO - 2023-08-19 13:45:07 --> URI Class Initialized
INFO - 2023-08-19 13:45:07 --> Router Class Initialized
INFO - 2023-08-19 13:45:07 --> Output Class Initialized
INFO - 2023-08-19 13:45:07 --> Security Class Initialized
DEBUG - 2023-08-19 13:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:45:07 --> Input Class Initialized
INFO - 2023-08-19 13:45:07 --> Language Class Initialized
INFO - 2023-08-19 13:45:07 --> Language Class Initialized
INFO - 2023-08-19 13:45:07 --> Config Class Initialized
INFO - 2023-08-19 13:45:07 --> Loader Class Initialized
INFO - 2023-08-19 13:45:07 --> Helper loaded: url_helper
INFO - 2023-08-19 13:45:07 --> Helper loaded: file_helper
INFO - 2023-08-19 13:45:08 --> Helper loaded: form_helper
INFO - 2023-08-19 13:45:08 --> Helper loaded: my_helper
INFO - 2023-08-19 13:45:08 --> Database Driver Class Initialized
INFO - 2023-08-19 13:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:45:08 --> Controller Class Initialized
DEBUG - 2023-08-19 13:45:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-08-19 13:45:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 13:45:08 --> Final output sent to browser
DEBUG - 2023-08-19 13:45:08 --> Total execution time: 0.5281
INFO - 2023-08-19 13:47:55 --> Config Class Initialized
INFO - 2023-08-19 13:47:55 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:47:55 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:47:55 --> Utf8 Class Initialized
INFO - 2023-08-19 13:47:55 --> URI Class Initialized
INFO - 2023-08-19 13:47:55 --> Router Class Initialized
INFO - 2023-08-19 13:47:55 --> Output Class Initialized
INFO - 2023-08-19 13:47:55 --> Security Class Initialized
DEBUG - 2023-08-19 13:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:47:55 --> Input Class Initialized
INFO - 2023-08-19 13:47:55 --> Language Class Initialized
INFO - 2023-08-19 13:47:55 --> Language Class Initialized
INFO - 2023-08-19 13:47:55 --> Config Class Initialized
INFO - 2023-08-19 13:47:55 --> Loader Class Initialized
INFO - 2023-08-19 13:47:55 --> Helper loaded: url_helper
INFO - 2023-08-19 13:47:55 --> Helper loaded: file_helper
INFO - 2023-08-19 13:47:55 --> Helper loaded: form_helper
INFO - 2023-08-19 13:47:55 --> Helper loaded: my_helper
INFO - 2023-08-19 13:47:55 --> Database Driver Class Initialized
INFO - 2023-08-19 13:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:47:56 --> Controller Class Initialized
INFO - 2023-08-19 13:47:58 --> Helper loaded: cookie_helper
INFO - 2023-08-19 13:47:58 --> Final output sent to browser
DEBUG - 2023-08-19 13:47:58 --> Total execution time: 2.9555
INFO - 2023-08-19 13:47:58 --> Config Class Initialized
INFO - 2023-08-19 13:47:58 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:47:58 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:47:58 --> Utf8 Class Initialized
INFO - 2023-08-19 13:47:58 --> URI Class Initialized
INFO - 2023-08-19 13:47:58 --> Router Class Initialized
INFO - 2023-08-19 13:47:58 --> Output Class Initialized
INFO - 2023-08-19 13:47:58 --> Security Class Initialized
DEBUG - 2023-08-19 13:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:47:58 --> Input Class Initialized
INFO - 2023-08-19 13:47:58 --> Language Class Initialized
INFO - 2023-08-19 13:47:58 --> Language Class Initialized
INFO - 2023-08-19 13:47:58 --> Config Class Initialized
INFO - 2023-08-19 13:47:58 --> Loader Class Initialized
INFO - 2023-08-19 13:47:58 --> Helper loaded: url_helper
INFO - 2023-08-19 13:47:58 --> Helper loaded: file_helper
INFO - 2023-08-19 13:47:58 --> Helper loaded: form_helper
INFO - 2023-08-19 13:47:58 --> Helper loaded: my_helper
INFO - 2023-08-19 13:47:58 --> Database Driver Class Initialized
INFO - 2023-08-19 13:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:47:58 --> Controller Class Initialized
DEBUG - 2023-08-19 13:47:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 13:47:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 13:47:58 --> Final output sent to browser
DEBUG - 2023-08-19 13:47:58 --> Total execution time: 0.4253
INFO - 2023-08-19 13:48:15 --> Config Class Initialized
INFO - 2023-08-19 13:48:15 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:48:15 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:48:15 --> Utf8 Class Initialized
INFO - 2023-08-19 13:48:15 --> URI Class Initialized
INFO - 2023-08-19 13:48:15 --> Router Class Initialized
INFO - 2023-08-19 13:48:15 --> Output Class Initialized
INFO - 2023-08-19 13:48:15 --> Security Class Initialized
DEBUG - 2023-08-19 13:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:48:16 --> Input Class Initialized
INFO - 2023-08-19 13:48:16 --> Language Class Initialized
INFO - 2023-08-19 13:48:16 --> Language Class Initialized
INFO - 2023-08-19 13:48:16 --> Config Class Initialized
INFO - 2023-08-19 13:48:16 --> Loader Class Initialized
INFO - 2023-08-19 13:48:16 --> Helper loaded: url_helper
INFO - 2023-08-19 13:48:16 --> Helper loaded: file_helper
INFO - 2023-08-19 13:48:16 --> Helper loaded: form_helper
INFO - 2023-08-19 13:48:16 --> Helper loaded: my_helper
INFO - 2023-08-19 13:48:16 --> Database Driver Class Initialized
INFO - 2023-08-19 13:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:48:16 --> Controller Class Initialized
DEBUG - 2023-08-19 13:48:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 13:48:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 13:48:16 --> Final output sent to browser
DEBUG - 2023-08-19 13:48:16 --> Total execution time: 0.5386
INFO - 2023-08-19 13:49:05 --> Config Class Initialized
INFO - 2023-08-19 13:49:05 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:49:05 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:49:05 --> Utf8 Class Initialized
INFO - 2023-08-19 13:49:05 --> URI Class Initialized
INFO - 2023-08-19 13:49:05 --> Router Class Initialized
INFO - 2023-08-19 13:49:06 --> Output Class Initialized
INFO - 2023-08-19 13:49:06 --> Security Class Initialized
DEBUG - 2023-08-19 13:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:49:06 --> Input Class Initialized
INFO - 2023-08-19 13:49:06 --> Language Class Initialized
INFO - 2023-08-19 13:49:06 --> Language Class Initialized
INFO - 2023-08-19 13:49:06 --> Config Class Initialized
INFO - 2023-08-19 13:49:06 --> Loader Class Initialized
INFO - 2023-08-19 13:49:06 --> Helper loaded: url_helper
INFO - 2023-08-19 13:49:06 --> Helper loaded: file_helper
INFO - 2023-08-19 13:49:06 --> Helper loaded: form_helper
INFO - 2023-08-19 13:49:06 --> Helper loaded: my_helper
INFO - 2023-08-19 13:49:06 --> Database Driver Class Initialized
INFO - 2023-08-19 13:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:49:06 --> Controller Class Initialized
DEBUG - 2023-08-19 13:49:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-08-19 13:49:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 13:49:06 --> Final output sent to browser
DEBUG - 2023-08-19 13:49:06 --> Total execution time: 0.3694
INFO - 2023-08-19 13:49:06 --> Config Class Initialized
INFO - 2023-08-19 13:49:06 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:49:06 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:49:06 --> Utf8 Class Initialized
INFO - 2023-08-19 13:49:06 --> URI Class Initialized
INFO - 2023-08-19 13:49:06 --> Router Class Initialized
INFO - 2023-08-19 13:49:06 --> Output Class Initialized
INFO - 2023-08-19 13:49:06 --> Security Class Initialized
DEBUG - 2023-08-19 13:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:49:06 --> Input Class Initialized
INFO - 2023-08-19 13:49:06 --> Language Class Initialized
INFO - 2023-08-19 13:49:06 --> Language Class Initialized
INFO - 2023-08-19 13:49:06 --> Config Class Initialized
INFO - 2023-08-19 13:49:06 --> Loader Class Initialized
INFO - 2023-08-19 13:49:06 --> Helper loaded: url_helper
INFO - 2023-08-19 13:49:06 --> Helper loaded: file_helper
INFO - 2023-08-19 13:49:06 --> Helper loaded: form_helper
INFO - 2023-08-19 13:49:06 --> Helper loaded: my_helper
INFO - 2023-08-19 13:49:06 --> Database Driver Class Initialized
INFO - 2023-08-19 13:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:49:06 --> Controller Class Initialized
INFO - 2023-08-19 13:49:19 --> Config Class Initialized
INFO - 2023-08-19 13:49:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:49:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:49:19 --> Utf8 Class Initialized
INFO - 2023-08-19 13:49:19 --> URI Class Initialized
INFO - 2023-08-19 13:49:19 --> Router Class Initialized
INFO - 2023-08-19 13:49:19 --> Output Class Initialized
INFO - 2023-08-19 13:49:19 --> Security Class Initialized
DEBUG - 2023-08-19 13:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:49:19 --> Input Class Initialized
INFO - 2023-08-19 13:49:19 --> Language Class Initialized
INFO - 2023-08-19 13:49:19 --> Language Class Initialized
INFO - 2023-08-19 13:49:19 --> Config Class Initialized
INFO - 2023-08-19 13:49:19 --> Loader Class Initialized
INFO - 2023-08-19 13:49:19 --> Helper loaded: url_helper
INFO - 2023-08-19 13:49:19 --> Helper loaded: file_helper
INFO - 2023-08-19 13:49:19 --> Helper loaded: form_helper
INFO - 2023-08-19 13:49:19 --> Helper loaded: my_helper
INFO - 2023-08-19 13:49:19 --> Database Driver Class Initialized
INFO - 2023-08-19 13:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:49:19 --> Controller Class Initialized
INFO - 2023-08-19 13:49:19 --> Final output sent to browser
DEBUG - 2023-08-19 13:49:19 --> Total execution time: 0.1052
INFO - 2023-08-19 13:49:36 --> Config Class Initialized
INFO - 2023-08-19 13:49:36 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:49:36 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:49:36 --> Utf8 Class Initialized
INFO - 2023-08-19 13:49:36 --> URI Class Initialized
INFO - 2023-08-19 13:49:36 --> Router Class Initialized
INFO - 2023-08-19 13:49:36 --> Output Class Initialized
INFO - 2023-08-19 13:49:36 --> Security Class Initialized
DEBUG - 2023-08-19 13:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:49:36 --> Input Class Initialized
INFO - 2023-08-19 13:49:36 --> Language Class Initialized
INFO - 2023-08-19 13:49:36 --> Language Class Initialized
INFO - 2023-08-19 13:49:36 --> Config Class Initialized
INFO - 2023-08-19 13:49:36 --> Loader Class Initialized
INFO - 2023-08-19 13:49:36 --> Helper loaded: url_helper
INFO - 2023-08-19 13:49:36 --> Helper loaded: file_helper
INFO - 2023-08-19 13:49:36 --> Helper loaded: form_helper
INFO - 2023-08-19 13:49:36 --> Helper loaded: my_helper
INFO - 2023-08-19 13:49:36 --> Database Driver Class Initialized
INFO - 2023-08-19 13:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:49:36 --> Controller Class Initialized
INFO - 2023-08-19 13:49:36 --> Final output sent to browser
DEBUG - 2023-08-19 13:49:36 --> Total execution time: 0.0379
INFO - 2023-08-19 13:50:26 --> Config Class Initialized
INFO - 2023-08-19 13:50:26 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:50:26 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:50:26 --> Utf8 Class Initialized
INFO - 2023-08-19 13:50:26 --> URI Class Initialized
INFO - 2023-08-19 13:50:26 --> Router Class Initialized
INFO - 2023-08-19 13:50:26 --> Output Class Initialized
INFO - 2023-08-19 13:50:26 --> Security Class Initialized
DEBUG - 2023-08-19 13:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:50:26 --> Input Class Initialized
INFO - 2023-08-19 13:50:26 --> Language Class Initialized
INFO - 2023-08-19 13:50:26 --> Language Class Initialized
INFO - 2023-08-19 13:50:26 --> Config Class Initialized
INFO - 2023-08-19 13:50:26 --> Loader Class Initialized
INFO - 2023-08-19 13:50:26 --> Helper loaded: url_helper
INFO - 2023-08-19 13:50:26 --> Helper loaded: file_helper
INFO - 2023-08-19 13:50:26 --> Helper loaded: form_helper
INFO - 2023-08-19 13:50:26 --> Helper loaded: my_helper
INFO - 2023-08-19 13:50:26 --> Database Driver Class Initialized
INFO - 2023-08-19 13:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:50:26 --> Controller Class Initialized
INFO - 2023-08-19 13:50:26 --> Final output sent to browser
DEBUG - 2023-08-19 13:50:26 --> Total execution time: 0.2702
INFO - 2023-08-19 13:50:27 --> Config Class Initialized
INFO - 2023-08-19 13:50:27 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:50:27 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:50:27 --> Utf8 Class Initialized
INFO - 2023-08-19 13:50:27 --> URI Class Initialized
INFO - 2023-08-19 13:50:27 --> Router Class Initialized
INFO - 2023-08-19 13:50:27 --> Output Class Initialized
INFO - 2023-08-19 13:50:27 --> Security Class Initialized
DEBUG - 2023-08-19 13:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:50:27 --> Input Class Initialized
INFO - 2023-08-19 13:50:27 --> Language Class Initialized
INFO - 2023-08-19 13:50:27 --> Language Class Initialized
INFO - 2023-08-19 13:50:27 --> Config Class Initialized
INFO - 2023-08-19 13:50:27 --> Loader Class Initialized
INFO - 2023-08-19 13:50:27 --> Helper loaded: url_helper
INFO - 2023-08-19 13:50:27 --> Helper loaded: file_helper
INFO - 2023-08-19 13:50:27 --> Helper loaded: form_helper
INFO - 2023-08-19 13:50:27 --> Helper loaded: my_helper
INFO - 2023-08-19 13:50:27 --> Database Driver Class Initialized
INFO - 2023-08-19 13:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:50:27 --> Controller Class Initialized
INFO - 2023-08-19 13:50:31 --> Config Class Initialized
INFO - 2023-08-19 13:50:31 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:50:31 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:50:31 --> Utf8 Class Initialized
INFO - 2023-08-19 13:50:31 --> URI Class Initialized
INFO - 2023-08-19 13:50:32 --> Router Class Initialized
INFO - 2023-08-19 13:50:32 --> Output Class Initialized
INFO - 2023-08-19 13:50:32 --> Security Class Initialized
DEBUG - 2023-08-19 13:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:50:32 --> Input Class Initialized
INFO - 2023-08-19 13:50:32 --> Language Class Initialized
INFO - 2023-08-19 13:50:33 --> Language Class Initialized
INFO - 2023-08-19 13:50:33 --> Config Class Initialized
INFO - 2023-08-19 13:50:33 --> Loader Class Initialized
INFO - 2023-08-19 13:50:33 --> Helper loaded: url_helper
INFO - 2023-08-19 13:50:33 --> Helper loaded: file_helper
INFO - 2023-08-19 13:50:33 --> Helper loaded: form_helper
INFO - 2023-08-19 13:50:33 --> Helper loaded: my_helper
INFO - 2023-08-19 13:50:33 --> Database Driver Class Initialized
INFO - 2023-08-19 13:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:50:33 --> Controller Class Initialized
INFO - 2023-08-19 13:50:34 --> Final output sent to browser
DEBUG - 2023-08-19 13:50:34 --> Total execution time: 2.3904
INFO - 2023-08-19 13:50:34 --> Config Class Initialized
INFO - 2023-08-19 13:50:34 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:50:34 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:50:34 --> Utf8 Class Initialized
INFO - 2023-08-19 13:50:34 --> URI Class Initialized
INFO - 2023-08-19 13:50:34 --> Router Class Initialized
INFO - 2023-08-19 13:50:34 --> Output Class Initialized
INFO - 2023-08-19 13:50:34 --> Security Class Initialized
DEBUG - 2023-08-19 13:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:50:34 --> Input Class Initialized
INFO - 2023-08-19 13:50:34 --> Language Class Initialized
INFO - 2023-08-19 13:50:34 --> Language Class Initialized
INFO - 2023-08-19 13:50:34 --> Config Class Initialized
INFO - 2023-08-19 13:50:34 --> Loader Class Initialized
INFO - 2023-08-19 13:50:34 --> Helper loaded: url_helper
INFO - 2023-08-19 13:50:34 --> Helper loaded: file_helper
INFO - 2023-08-19 13:50:34 --> Helper loaded: form_helper
INFO - 2023-08-19 13:50:34 --> Helper loaded: my_helper
INFO - 2023-08-19 13:50:34 --> Database Driver Class Initialized
INFO - 2023-08-19 13:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:50:34 --> Controller Class Initialized
INFO - 2023-08-19 13:50:34 --> Final output sent to browser
DEBUG - 2023-08-19 13:50:34 --> Total execution time: 0.2109
INFO - 2023-08-19 13:50:50 --> Config Class Initialized
INFO - 2023-08-19 13:50:50 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:50:50 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:50:50 --> Utf8 Class Initialized
INFO - 2023-08-19 13:50:50 --> URI Class Initialized
INFO - 2023-08-19 13:50:50 --> Router Class Initialized
INFO - 2023-08-19 13:50:50 --> Output Class Initialized
INFO - 2023-08-19 13:50:50 --> Security Class Initialized
DEBUG - 2023-08-19 13:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:50:50 --> Input Class Initialized
INFO - 2023-08-19 13:50:50 --> Language Class Initialized
INFO - 2023-08-19 13:50:50 --> Language Class Initialized
INFO - 2023-08-19 13:50:50 --> Config Class Initialized
INFO - 2023-08-19 13:50:50 --> Loader Class Initialized
INFO - 2023-08-19 13:50:50 --> Helper loaded: url_helper
INFO - 2023-08-19 13:50:50 --> Helper loaded: file_helper
INFO - 2023-08-19 13:50:50 --> Helper loaded: form_helper
INFO - 2023-08-19 13:50:50 --> Helper loaded: my_helper
INFO - 2023-08-19 13:50:50 --> Database Driver Class Initialized
INFO - 2023-08-19 13:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:50:50 --> Controller Class Initialized
INFO - 2023-08-19 13:50:50 --> Final output sent to browser
DEBUG - 2023-08-19 13:50:50 --> Total execution time: 0.2460
INFO - 2023-08-19 13:50:52 --> Config Class Initialized
INFO - 2023-08-19 13:50:52 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:50:52 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:50:52 --> Utf8 Class Initialized
INFO - 2023-08-19 13:50:52 --> URI Class Initialized
INFO - 2023-08-19 13:50:52 --> Router Class Initialized
INFO - 2023-08-19 13:50:52 --> Output Class Initialized
INFO - 2023-08-19 13:50:52 --> Security Class Initialized
DEBUG - 2023-08-19 13:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:50:52 --> Input Class Initialized
INFO - 2023-08-19 13:50:52 --> Language Class Initialized
INFO - 2023-08-19 13:50:53 --> Language Class Initialized
INFO - 2023-08-19 13:50:53 --> Config Class Initialized
INFO - 2023-08-19 13:50:53 --> Loader Class Initialized
INFO - 2023-08-19 13:50:53 --> Helper loaded: url_helper
INFO - 2023-08-19 13:50:53 --> Helper loaded: file_helper
INFO - 2023-08-19 13:50:53 --> Helper loaded: form_helper
INFO - 2023-08-19 13:50:53 --> Helper loaded: my_helper
INFO - 2023-08-19 13:50:53 --> Database Driver Class Initialized
INFO - 2023-08-19 13:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:50:53 --> Controller Class Initialized
INFO - 2023-08-19 13:50:53 --> Final output sent to browser
DEBUG - 2023-08-19 13:50:53 --> Total execution time: 1.2247
INFO - 2023-08-19 13:50:55 --> Config Class Initialized
INFO - 2023-08-19 13:50:55 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:50:55 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:50:55 --> Utf8 Class Initialized
INFO - 2023-08-19 13:50:56 --> URI Class Initialized
INFO - 2023-08-19 13:50:56 --> Router Class Initialized
INFO - 2023-08-19 13:50:56 --> Output Class Initialized
INFO - 2023-08-19 13:50:56 --> Security Class Initialized
DEBUG - 2023-08-19 13:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:50:57 --> Input Class Initialized
INFO - 2023-08-19 13:50:57 --> Language Class Initialized
INFO - 2023-08-19 13:50:57 --> Language Class Initialized
INFO - 2023-08-19 13:50:57 --> Config Class Initialized
INFO - 2023-08-19 13:50:57 --> Loader Class Initialized
INFO - 2023-08-19 13:50:57 --> Helper loaded: url_helper
INFO - 2023-08-19 13:50:57 --> Helper loaded: file_helper
INFO - 2023-08-19 13:50:57 --> Helper loaded: form_helper
INFO - 2023-08-19 13:50:57 --> Helper loaded: my_helper
INFO - 2023-08-19 13:50:57 --> Database Driver Class Initialized
INFO - 2023-08-19 13:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:50:57 --> Controller Class Initialized
INFO - 2023-08-19 13:50:57 --> Final output sent to browser
DEBUG - 2023-08-19 13:50:57 --> Total execution time: 1.9217
INFO - 2023-08-19 13:50:57 --> Config Class Initialized
INFO - 2023-08-19 13:50:57 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:50:57 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:50:57 --> Utf8 Class Initialized
INFO - 2023-08-19 13:50:57 --> URI Class Initialized
INFO - 2023-08-19 13:50:57 --> Router Class Initialized
INFO - 2023-08-19 13:50:57 --> Output Class Initialized
INFO - 2023-08-19 13:50:57 --> Security Class Initialized
DEBUG - 2023-08-19 13:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:50:57 --> Input Class Initialized
INFO - 2023-08-19 13:50:57 --> Language Class Initialized
INFO - 2023-08-19 13:50:57 --> Language Class Initialized
INFO - 2023-08-19 13:50:57 --> Config Class Initialized
INFO - 2023-08-19 13:50:57 --> Loader Class Initialized
INFO - 2023-08-19 13:50:57 --> Helper loaded: url_helper
INFO - 2023-08-19 13:50:57 --> Helper loaded: file_helper
INFO - 2023-08-19 13:50:57 --> Helper loaded: form_helper
INFO - 2023-08-19 13:50:57 --> Helper loaded: my_helper
INFO - 2023-08-19 13:50:57 --> Database Driver Class Initialized
INFO - 2023-08-19 13:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:50:57 --> Controller Class Initialized
INFO - 2023-08-19 13:50:59 --> Config Class Initialized
INFO - 2023-08-19 13:50:59 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:50:59 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:50:59 --> Utf8 Class Initialized
INFO - 2023-08-19 13:50:59 --> URI Class Initialized
INFO - 2023-08-19 13:50:59 --> Router Class Initialized
INFO - 2023-08-19 13:50:59 --> Output Class Initialized
INFO - 2023-08-19 13:50:59 --> Security Class Initialized
DEBUG - 2023-08-19 13:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:50:59 --> Input Class Initialized
INFO - 2023-08-19 13:50:59 --> Language Class Initialized
INFO - 2023-08-19 13:50:59 --> Language Class Initialized
INFO - 2023-08-19 13:50:59 --> Config Class Initialized
INFO - 2023-08-19 13:50:59 --> Loader Class Initialized
INFO - 2023-08-19 13:50:59 --> Helper loaded: url_helper
INFO - 2023-08-19 13:50:59 --> Helper loaded: file_helper
INFO - 2023-08-19 13:50:59 --> Helper loaded: form_helper
INFO - 2023-08-19 13:50:59 --> Helper loaded: my_helper
INFO - 2023-08-19 13:50:59 --> Database Driver Class Initialized
INFO - 2023-08-19 13:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:50:59 --> Controller Class Initialized
INFO - 2023-08-19 13:50:59 --> Final output sent to browser
DEBUG - 2023-08-19 13:50:59 --> Total execution time: 0.0631
INFO - 2023-08-19 13:51:00 --> Config Class Initialized
INFO - 2023-08-19 13:51:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:51:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:51:00 --> Utf8 Class Initialized
INFO - 2023-08-19 13:51:00 --> URI Class Initialized
INFO - 2023-08-19 13:51:00 --> Router Class Initialized
INFO - 2023-08-19 13:51:00 --> Output Class Initialized
INFO - 2023-08-19 13:51:00 --> Security Class Initialized
DEBUG - 2023-08-19 13:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:51:00 --> Input Class Initialized
INFO - 2023-08-19 13:51:00 --> Language Class Initialized
INFO - 2023-08-19 13:51:00 --> Language Class Initialized
INFO - 2023-08-19 13:51:00 --> Config Class Initialized
INFO - 2023-08-19 13:51:00 --> Loader Class Initialized
INFO - 2023-08-19 13:51:00 --> Helper loaded: url_helper
INFO - 2023-08-19 13:51:00 --> Helper loaded: file_helper
INFO - 2023-08-19 13:51:00 --> Helper loaded: form_helper
INFO - 2023-08-19 13:51:00 --> Helper loaded: my_helper
INFO - 2023-08-19 13:51:00 --> Database Driver Class Initialized
INFO - 2023-08-19 13:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:51:00 --> Controller Class Initialized
INFO - 2023-08-19 13:51:00 --> Final output sent to browser
DEBUG - 2023-08-19 13:51:00 --> Total execution time: 0.0997
INFO - 2023-08-19 13:51:04 --> Config Class Initialized
INFO - 2023-08-19 13:51:04 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:51:04 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:51:04 --> Utf8 Class Initialized
INFO - 2023-08-19 13:51:04 --> URI Class Initialized
INFO - 2023-08-19 13:51:04 --> Router Class Initialized
INFO - 2023-08-19 13:51:04 --> Output Class Initialized
INFO - 2023-08-19 13:51:04 --> Security Class Initialized
DEBUG - 2023-08-19 13:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:51:04 --> Input Class Initialized
INFO - 2023-08-19 13:51:04 --> Language Class Initialized
INFO - 2023-08-19 13:51:04 --> Language Class Initialized
INFO - 2023-08-19 13:51:04 --> Config Class Initialized
INFO - 2023-08-19 13:51:04 --> Loader Class Initialized
INFO - 2023-08-19 13:51:04 --> Helper loaded: url_helper
INFO - 2023-08-19 13:51:04 --> Helper loaded: file_helper
INFO - 2023-08-19 13:51:04 --> Helper loaded: form_helper
INFO - 2023-08-19 13:51:04 --> Helper loaded: my_helper
INFO - 2023-08-19 13:51:04 --> Database Driver Class Initialized
INFO - 2023-08-19 13:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:51:04 --> Controller Class Initialized
INFO - 2023-08-19 13:51:04 --> Final output sent to browser
DEBUG - 2023-08-19 13:51:04 --> Total execution time: 0.4956
INFO - 2023-08-19 13:51:05 --> Config Class Initialized
INFO - 2023-08-19 13:51:05 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:51:05 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:51:05 --> Utf8 Class Initialized
INFO - 2023-08-19 13:51:05 --> URI Class Initialized
INFO - 2023-08-19 13:51:05 --> Router Class Initialized
INFO - 2023-08-19 13:51:05 --> Output Class Initialized
INFO - 2023-08-19 13:51:05 --> Security Class Initialized
DEBUG - 2023-08-19 13:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:51:05 --> Input Class Initialized
INFO - 2023-08-19 13:51:05 --> Language Class Initialized
INFO - 2023-08-19 13:51:05 --> Language Class Initialized
INFO - 2023-08-19 13:51:05 --> Config Class Initialized
INFO - 2023-08-19 13:51:05 --> Loader Class Initialized
INFO - 2023-08-19 13:51:05 --> Helper loaded: url_helper
INFO - 2023-08-19 13:51:05 --> Helper loaded: file_helper
INFO - 2023-08-19 13:51:05 --> Helper loaded: form_helper
INFO - 2023-08-19 13:51:05 --> Helper loaded: my_helper
INFO - 2023-08-19 13:51:05 --> Database Driver Class Initialized
INFO - 2023-08-19 13:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:51:05 --> Controller Class Initialized
INFO - 2023-08-19 13:51:05 --> Final output sent to browser
DEBUG - 2023-08-19 13:51:05 --> Total execution time: 0.1398
INFO - 2023-08-19 13:51:08 --> Config Class Initialized
INFO - 2023-08-19 13:51:08 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:51:08 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:51:08 --> Utf8 Class Initialized
INFO - 2023-08-19 13:51:08 --> URI Class Initialized
INFO - 2023-08-19 13:51:08 --> Router Class Initialized
INFO - 2023-08-19 13:51:08 --> Output Class Initialized
INFO - 2023-08-19 13:51:08 --> Security Class Initialized
DEBUG - 2023-08-19 13:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:51:08 --> Input Class Initialized
INFO - 2023-08-19 13:51:08 --> Language Class Initialized
INFO - 2023-08-19 13:51:08 --> Language Class Initialized
INFO - 2023-08-19 13:51:08 --> Config Class Initialized
INFO - 2023-08-19 13:51:08 --> Loader Class Initialized
INFO - 2023-08-19 13:51:08 --> Helper loaded: url_helper
INFO - 2023-08-19 13:51:08 --> Helper loaded: file_helper
INFO - 2023-08-19 13:51:08 --> Helper loaded: form_helper
INFO - 2023-08-19 13:51:08 --> Helper loaded: my_helper
INFO - 2023-08-19 13:51:08 --> Database Driver Class Initialized
INFO - 2023-08-19 13:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:51:08 --> Controller Class Initialized
INFO - 2023-08-19 13:51:08 --> Final output sent to browser
DEBUG - 2023-08-19 13:51:08 --> Total execution time: 0.0544
INFO - 2023-08-19 13:51:13 --> Config Class Initialized
INFO - 2023-08-19 13:51:13 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:51:13 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:51:13 --> Utf8 Class Initialized
INFO - 2023-08-19 13:51:13 --> URI Class Initialized
INFO - 2023-08-19 13:51:13 --> Router Class Initialized
INFO - 2023-08-19 13:51:13 --> Output Class Initialized
INFO - 2023-08-19 13:51:13 --> Security Class Initialized
DEBUG - 2023-08-19 13:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:51:13 --> Input Class Initialized
INFO - 2023-08-19 13:51:13 --> Language Class Initialized
INFO - 2023-08-19 13:51:13 --> Language Class Initialized
INFO - 2023-08-19 13:51:13 --> Config Class Initialized
INFO - 2023-08-19 13:51:13 --> Loader Class Initialized
INFO - 2023-08-19 13:51:13 --> Helper loaded: url_helper
INFO - 2023-08-19 13:51:13 --> Helper loaded: file_helper
INFO - 2023-08-19 13:51:13 --> Helper loaded: form_helper
INFO - 2023-08-19 13:51:13 --> Helper loaded: my_helper
INFO - 2023-08-19 13:51:13 --> Database Driver Class Initialized
INFO - 2023-08-19 13:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:51:13 --> Controller Class Initialized
INFO - 2023-08-19 13:51:13 --> Final output sent to browser
DEBUG - 2023-08-19 13:51:13 --> Total execution time: 0.0543
INFO - 2023-08-19 13:51:15 --> Config Class Initialized
INFO - 2023-08-19 13:51:15 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:51:15 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:51:15 --> Utf8 Class Initialized
INFO - 2023-08-19 13:51:15 --> URI Class Initialized
INFO - 2023-08-19 13:51:15 --> Router Class Initialized
INFO - 2023-08-19 13:51:15 --> Output Class Initialized
INFO - 2023-08-19 13:51:15 --> Security Class Initialized
DEBUG - 2023-08-19 13:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:51:15 --> Input Class Initialized
INFO - 2023-08-19 13:51:15 --> Language Class Initialized
INFO - 2023-08-19 13:51:15 --> Language Class Initialized
INFO - 2023-08-19 13:51:15 --> Config Class Initialized
INFO - 2023-08-19 13:51:15 --> Loader Class Initialized
INFO - 2023-08-19 13:51:15 --> Helper loaded: url_helper
INFO - 2023-08-19 13:51:15 --> Helper loaded: file_helper
INFO - 2023-08-19 13:51:15 --> Helper loaded: form_helper
INFO - 2023-08-19 13:51:15 --> Helper loaded: my_helper
INFO - 2023-08-19 13:51:15 --> Database Driver Class Initialized
INFO - 2023-08-19 13:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:51:15 --> Controller Class Initialized
INFO - 2023-08-19 13:51:15 --> Final output sent to browser
DEBUG - 2023-08-19 13:51:15 --> Total execution time: 0.1074
INFO - 2023-08-19 13:51:15 --> Config Class Initialized
INFO - 2023-08-19 13:51:15 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:51:15 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:51:15 --> Utf8 Class Initialized
INFO - 2023-08-19 13:51:15 --> URI Class Initialized
INFO - 2023-08-19 13:51:15 --> Router Class Initialized
INFO - 2023-08-19 13:51:15 --> Output Class Initialized
INFO - 2023-08-19 13:51:15 --> Security Class Initialized
DEBUG - 2023-08-19 13:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:51:15 --> Input Class Initialized
INFO - 2023-08-19 13:51:15 --> Language Class Initialized
INFO - 2023-08-19 13:51:15 --> Language Class Initialized
INFO - 2023-08-19 13:51:15 --> Config Class Initialized
INFO - 2023-08-19 13:51:15 --> Loader Class Initialized
INFO - 2023-08-19 13:51:15 --> Helper loaded: url_helper
INFO - 2023-08-19 13:51:15 --> Helper loaded: file_helper
INFO - 2023-08-19 13:51:15 --> Helper loaded: form_helper
INFO - 2023-08-19 13:51:15 --> Helper loaded: my_helper
INFO - 2023-08-19 13:51:15 --> Database Driver Class Initialized
INFO - 2023-08-19 13:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:51:15 --> Controller Class Initialized
INFO - 2023-08-19 13:51:15 --> Final output sent to browser
DEBUG - 2023-08-19 13:51:15 --> Total execution time: 0.0957
INFO - 2023-08-19 13:51:22 --> Config Class Initialized
INFO - 2023-08-19 13:51:22 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:51:22 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:51:22 --> Utf8 Class Initialized
INFO - 2023-08-19 13:51:22 --> URI Class Initialized
INFO - 2023-08-19 13:51:22 --> Router Class Initialized
INFO - 2023-08-19 13:51:22 --> Output Class Initialized
INFO - 2023-08-19 13:51:22 --> Security Class Initialized
DEBUG - 2023-08-19 13:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:51:22 --> Input Class Initialized
INFO - 2023-08-19 13:51:22 --> Language Class Initialized
INFO - 2023-08-19 13:51:22 --> Language Class Initialized
INFO - 2023-08-19 13:51:22 --> Config Class Initialized
INFO - 2023-08-19 13:51:22 --> Loader Class Initialized
INFO - 2023-08-19 13:51:22 --> Helper loaded: url_helper
INFO - 2023-08-19 13:51:22 --> Helper loaded: file_helper
INFO - 2023-08-19 13:51:22 --> Helper loaded: form_helper
INFO - 2023-08-19 13:51:22 --> Helper loaded: my_helper
INFO - 2023-08-19 13:51:22 --> Database Driver Class Initialized
INFO - 2023-08-19 13:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:51:22 --> Controller Class Initialized
INFO - 2023-08-19 13:51:22 --> Final output sent to browser
DEBUG - 2023-08-19 13:51:22 --> Total execution time: 0.0529
INFO - 2023-08-19 13:51:25 --> Config Class Initialized
INFO - 2023-08-19 13:51:25 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:51:25 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:51:25 --> Utf8 Class Initialized
INFO - 2023-08-19 13:51:25 --> URI Class Initialized
INFO - 2023-08-19 13:51:25 --> Router Class Initialized
INFO - 2023-08-19 13:51:25 --> Output Class Initialized
INFO - 2023-08-19 13:51:25 --> Security Class Initialized
DEBUG - 2023-08-19 13:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:51:25 --> Input Class Initialized
INFO - 2023-08-19 13:51:25 --> Language Class Initialized
INFO - 2023-08-19 13:51:25 --> Language Class Initialized
INFO - 2023-08-19 13:51:25 --> Config Class Initialized
INFO - 2023-08-19 13:51:25 --> Loader Class Initialized
INFO - 2023-08-19 13:51:25 --> Helper loaded: url_helper
INFO - 2023-08-19 13:51:25 --> Helper loaded: file_helper
INFO - 2023-08-19 13:51:25 --> Helper loaded: form_helper
INFO - 2023-08-19 13:51:25 --> Helper loaded: my_helper
INFO - 2023-08-19 13:51:25 --> Database Driver Class Initialized
INFO - 2023-08-19 13:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:51:25 --> Controller Class Initialized
DEBUG - 2023-08-19 13:51:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-08-19 13:51:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 13:51:26 --> Final output sent to browser
DEBUG - 2023-08-19 13:51:26 --> Total execution time: 0.0527
INFO - 2023-08-19 13:51:26 --> Config Class Initialized
INFO - 2023-08-19 13:51:26 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:51:26 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:51:26 --> Utf8 Class Initialized
INFO - 2023-08-19 13:51:26 --> URI Class Initialized
INFO - 2023-08-19 13:51:26 --> Router Class Initialized
INFO - 2023-08-19 13:51:26 --> Output Class Initialized
INFO - 2023-08-19 13:51:26 --> Security Class Initialized
DEBUG - 2023-08-19 13:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:51:26 --> Input Class Initialized
INFO - 2023-08-19 13:51:26 --> Language Class Initialized
INFO - 2023-08-19 13:51:26 --> Language Class Initialized
INFO - 2023-08-19 13:51:26 --> Config Class Initialized
INFO - 2023-08-19 13:51:26 --> Loader Class Initialized
INFO - 2023-08-19 13:51:26 --> Helper loaded: url_helper
INFO - 2023-08-19 13:51:26 --> Helper loaded: file_helper
INFO - 2023-08-19 13:51:26 --> Helper loaded: form_helper
INFO - 2023-08-19 13:51:26 --> Helper loaded: my_helper
INFO - 2023-08-19 13:51:26 --> Database Driver Class Initialized
INFO - 2023-08-19 13:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:51:26 --> Controller Class Initialized
INFO - 2023-08-19 13:51:28 --> Config Class Initialized
INFO - 2023-08-19 13:51:28 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:51:28 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:51:28 --> Utf8 Class Initialized
INFO - 2023-08-19 13:51:28 --> URI Class Initialized
INFO - 2023-08-19 13:51:28 --> Router Class Initialized
INFO - 2023-08-19 13:51:28 --> Output Class Initialized
INFO - 2023-08-19 13:51:28 --> Security Class Initialized
DEBUG - 2023-08-19 13:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:51:28 --> Input Class Initialized
INFO - 2023-08-19 13:51:28 --> Language Class Initialized
INFO - 2023-08-19 13:51:28 --> Language Class Initialized
INFO - 2023-08-19 13:51:28 --> Config Class Initialized
INFO - 2023-08-19 13:51:28 --> Loader Class Initialized
INFO - 2023-08-19 13:51:28 --> Helper loaded: url_helper
INFO - 2023-08-19 13:51:28 --> Helper loaded: file_helper
INFO - 2023-08-19 13:51:28 --> Helper loaded: form_helper
INFO - 2023-08-19 13:51:28 --> Helper loaded: my_helper
INFO - 2023-08-19 13:51:28 --> Database Driver Class Initialized
INFO - 2023-08-19 13:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:51:28 --> Controller Class Initialized
INFO - 2023-08-19 13:51:28 --> Final output sent to browser
DEBUG - 2023-08-19 13:51:28 --> Total execution time: 0.0474
INFO - 2023-08-19 13:51:28 --> Config Class Initialized
INFO - 2023-08-19 13:51:28 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:51:28 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:51:28 --> Utf8 Class Initialized
INFO - 2023-08-19 13:51:28 --> URI Class Initialized
INFO - 2023-08-19 13:51:28 --> Router Class Initialized
INFO - 2023-08-19 13:51:28 --> Output Class Initialized
INFO - 2023-08-19 13:51:28 --> Security Class Initialized
DEBUG - 2023-08-19 13:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:51:28 --> Input Class Initialized
INFO - 2023-08-19 13:51:28 --> Language Class Initialized
INFO - 2023-08-19 13:51:28 --> Language Class Initialized
INFO - 2023-08-19 13:51:28 --> Config Class Initialized
INFO - 2023-08-19 13:51:28 --> Loader Class Initialized
INFO - 2023-08-19 13:51:28 --> Helper loaded: url_helper
INFO - 2023-08-19 13:51:28 --> Helper loaded: file_helper
INFO - 2023-08-19 13:51:28 --> Helper loaded: form_helper
INFO - 2023-08-19 13:51:28 --> Helper loaded: my_helper
INFO - 2023-08-19 13:51:28 --> Database Driver Class Initialized
INFO - 2023-08-19 13:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:51:28 --> Controller Class Initialized
INFO - 2023-08-19 13:51:28 --> Final output sent to browser
DEBUG - 2023-08-19 13:51:28 --> Total execution time: 0.2466
INFO - 2023-08-19 13:51:29 --> Config Class Initialized
INFO - 2023-08-19 13:51:29 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:51:29 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:51:29 --> Utf8 Class Initialized
INFO - 2023-08-19 13:51:29 --> URI Class Initialized
INFO - 2023-08-19 13:51:29 --> Router Class Initialized
INFO - 2023-08-19 13:51:29 --> Output Class Initialized
INFO - 2023-08-19 13:51:29 --> Security Class Initialized
DEBUG - 2023-08-19 13:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:51:29 --> Input Class Initialized
INFO - 2023-08-19 13:51:29 --> Language Class Initialized
INFO - 2023-08-19 13:51:29 --> Language Class Initialized
INFO - 2023-08-19 13:51:29 --> Config Class Initialized
INFO - 2023-08-19 13:51:29 --> Loader Class Initialized
INFO - 2023-08-19 13:51:29 --> Helper loaded: url_helper
INFO - 2023-08-19 13:51:29 --> Helper loaded: file_helper
INFO - 2023-08-19 13:51:29 --> Helper loaded: form_helper
INFO - 2023-08-19 13:51:29 --> Helper loaded: my_helper
INFO - 2023-08-19 13:51:29 --> Database Driver Class Initialized
INFO - 2023-08-19 13:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:51:29 --> Controller Class Initialized
INFO - 2023-08-19 13:51:29 --> Final output sent to browser
DEBUG - 2023-08-19 13:51:29 --> Total execution time: 0.0435
INFO - 2023-08-19 13:51:30 --> Config Class Initialized
INFO - 2023-08-19 13:51:30 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:51:30 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:51:30 --> Utf8 Class Initialized
INFO - 2023-08-19 13:51:30 --> URI Class Initialized
INFO - 2023-08-19 13:51:30 --> Router Class Initialized
INFO - 2023-08-19 13:51:30 --> Output Class Initialized
INFO - 2023-08-19 13:51:30 --> Security Class Initialized
DEBUG - 2023-08-19 13:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:51:30 --> Input Class Initialized
INFO - 2023-08-19 13:51:30 --> Language Class Initialized
INFO - 2023-08-19 13:51:30 --> Language Class Initialized
INFO - 2023-08-19 13:51:30 --> Config Class Initialized
INFO - 2023-08-19 13:51:30 --> Loader Class Initialized
INFO - 2023-08-19 13:51:30 --> Helper loaded: url_helper
INFO - 2023-08-19 13:51:30 --> Helper loaded: file_helper
INFO - 2023-08-19 13:51:30 --> Helper loaded: form_helper
INFO - 2023-08-19 13:51:30 --> Helper loaded: my_helper
INFO - 2023-08-19 13:51:30 --> Database Driver Class Initialized
INFO - 2023-08-19 13:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:51:30 --> Controller Class Initialized
INFO - 2023-08-19 13:51:30 --> Final output sent to browser
DEBUG - 2023-08-19 13:51:30 --> Total execution time: 0.0430
INFO - 2023-08-19 13:51:35 --> Config Class Initialized
INFO - 2023-08-19 13:51:35 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:51:35 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:51:35 --> Utf8 Class Initialized
INFO - 2023-08-19 13:51:35 --> URI Class Initialized
INFO - 2023-08-19 13:51:35 --> Router Class Initialized
INFO - 2023-08-19 13:51:35 --> Output Class Initialized
INFO - 2023-08-19 13:51:35 --> Security Class Initialized
DEBUG - 2023-08-19 13:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:51:35 --> Input Class Initialized
INFO - 2023-08-19 13:51:35 --> Language Class Initialized
INFO - 2023-08-19 13:51:35 --> Language Class Initialized
INFO - 2023-08-19 13:51:35 --> Config Class Initialized
INFO - 2023-08-19 13:51:35 --> Loader Class Initialized
INFO - 2023-08-19 13:51:35 --> Helper loaded: url_helper
INFO - 2023-08-19 13:51:35 --> Helper loaded: file_helper
INFO - 2023-08-19 13:51:35 --> Helper loaded: form_helper
INFO - 2023-08-19 13:51:35 --> Helper loaded: my_helper
INFO - 2023-08-19 13:51:35 --> Database Driver Class Initialized
INFO - 2023-08-19 13:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:51:35 --> Controller Class Initialized
INFO - 2023-08-19 13:51:35 --> Final output sent to browser
DEBUG - 2023-08-19 13:51:35 --> Total execution time: 0.0385
INFO - 2023-08-19 14:12:56 --> Config Class Initialized
INFO - 2023-08-19 14:12:56 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:12:56 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:12:56 --> Utf8 Class Initialized
INFO - 2023-08-19 14:12:56 --> URI Class Initialized
INFO - 2023-08-19 14:12:56 --> Router Class Initialized
INFO - 2023-08-19 14:12:56 --> Output Class Initialized
INFO - 2023-08-19 14:12:56 --> Security Class Initialized
DEBUG - 2023-08-19 14:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:12:56 --> Input Class Initialized
INFO - 2023-08-19 14:12:56 --> Language Class Initialized
INFO - 2023-08-19 14:12:56 --> Language Class Initialized
INFO - 2023-08-19 14:12:56 --> Config Class Initialized
INFO - 2023-08-19 14:12:56 --> Loader Class Initialized
INFO - 2023-08-19 14:12:56 --> Helper loaded: url_helper
INFO - 2023-08-19 14:12:56 --> Helper loaded: file_helper
INFO - 2023-08-19 14:12:56 --> Helper loaded: form_helper
INFO - 2023-08-19 14:12:56 --> Helper loaded: my_helper
INFO - 2023-08-19 14:12:56 --> Database Driver Class Initialized
INFO - 2023-08-19 14:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:12:56 --> Controller Class Initialized
DEBUG - 2023-08-19 14:12:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-08-19 14:12:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 14:12:56 --> Final output sent to browser
DEBUG - 2023-08-19 14:12:56 --> Total execution time: 0.0503
INFO - 2023-08-19 14:12:58 --> Config Class Initialized
INFO - 2023-08-19 14:12:58 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:12:58 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:12:58 --> Utf8 Class Initialized
INFO - 2023-08-19 14:12:58 --> URI Class Initialized
INFO - 2023-08-19 14:12:58 --> Router Class Initialized
INFO - 2023-08-19 14:12:58 --> Output Class Initialized
INFO - 2023-08-19 14:12:58 --> Security Class Initialized
DEBUG - 2023-08-19 14:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:12:58 --> Input Class Initialized
INFO - 2023-08-19 14:12:58 --> Language Class Initialized
INFO - 2023-08-19 14:12:58 --> Language Class Initialized
INFO - 2023-08-19 14:12:58 --> Config Class Initialized
INFO - 2023-08-19 14:12:58 --> Loader Class Initialized
INFO - 2023-08-19 14:12:58 --> Helper loaded: url_helper
INFO - 2023-08-19 14:12:58 --> Helper loaded: file_helper
INFO - 2023-08-19 14:12:58 --> Helper loaded: form_helper
INFO - 2023-08-19 14:12:58 --> Helper loaded: my_helper
INFO - 2023-08-19 14:12:58 --> Database Driver Class Initialized
INFO - 2023-08-19 14:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:12:58 --> Controller Class Initialized
INFO - 2023-08-19 14:12:58 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:12:58 --> Final output sent to browser
DEBUG - 2023-08-19 14:12:58 --> Total execution time: 0.0351
INFO - 2023-08-19 14:12:59 --> Config Class Initialized
INFO - 2023-08-19 14:12:59 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:12:59 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:12:59 --> Utf8 Class Initialized
INFO - 2023-08-19 14:12:59 --> URI Class Initialized
INFO - 2023-08-19 14:12:59 --> Router Class Initialized
INFO - 2023-08-19 14:12:59 --> Output Class Initialized
INFO - 2023-08-19 14:12:59 --> Security Class Initialized
DEBUG - 2023-08-19 14:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:12:59 --> Input Class Initialized
INFO - 2023-08-19 14:12:59 --> Language Class Initialized
INFO - 2023-08-19 14:12:59 --> Language Class Initialized
INFO - 2023-08-19 14:12:59 --> Config Class Initialized
INFO - 2023-08-19 14:12:59 --> Loader Class Initialized
INFO - 2023-08-19 14:12:59 --> Helper loaded: url_helper
INFO - 2023-08-19 14:12:59 --> Helper loaded: file_helper
INFO - 2023-08-19 14:12:59 --> Helper loaded: form_helper
INFO - 2023-08-19 14:12:59 --> Helper loaded: my_helper
INFO - 2023-08-19 14:12:59 --> Database Driver Class Initialized
INFO - 2023-08-19 14:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:12:59 --> Controller Class Initialized
DEBUG - 2023-08-19 14:12:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-08-19 14:12:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 14:12:59 --> Final output sent to browser
DEBUG - 2023-08-19 14:12:59 --> Total execution time: 0.0394
INFO - 2023-08-19 14:13:06 --> Config Class Initialized
INFO - 2023-08-19 14:13:06 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:13:06 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:13:06 --> Utf8 Class Initialized
INFO - 2023-08-19 14:13:06 --> URI Class Initialized
INFO - 2023-08-19 14:13:06 --> Router Class Initialized
INFO - 2023-08-19 14:13:06 --> Output Class Initialized
INFO - 2023-08-19 14:13:06 --> Security Class Initialized
DEBUG - 2023-08-19 14:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:13:06 --> Input Class Initialized
INFO - 2023-08-19 14:13:06 --> Language Class Initialized
INFO - 2023-08-19 14:13:06 --> Language Class Initialized
INFO - 2023-08-19 14:13:06 --> Config Class Initialized
INFO - 2023-08-19 14:13:06 --> Loader Class Initialized
INFO - 2023-08-19 14:13:06 --> Helper loaded: url_helper
INFO - 2023-08-19 14:13:06 --> Helper loaded: file_helper
INFO - 2023-08-19 14:13:06 --> Helper loaded: form_helper
INFO - 2023-08-19 14:13:06 --> Helper loaded: my_helper
INFO - 2023-08-19 14:13:06 --> Database Driver Class Initialized
INFO - 2023-08-19 14:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:13:06 --> Controller Class Initialized
DEBUG - 2023-08-19 14:13:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-08-19 14:13:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 14:13:06 --> Final output sent to browser
DEBUG - 2023-08-19 14:13:06 --> Total execution time: 0.0464
INFO - 2023-08-19 14:13:06 --> Config Class Initialized
INFO - 2023-08-19 14:13:06 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:13:06 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:13:06 --> Utf8 Class Initialized
INFO - 2023-08-19 14:13:06 --> URI Class Initialized
INFO - 2023-08-19 14:13:06 --> Router Class Initialized
INFO - 2023-08-19 14:13:06 --> Output Class Initialized
INFO - 2023-08-19 14:13:06 --> Security Class Initialized
DEBUG - 2023-08-19 14:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:13:06 --> Input Class Initialized
INFO - 2023-08-19 14:13:06 --> Language Class Initialized
ERROR - 2023-08-19 14:13:06 --> 404 Page Not Found: /index
INFO - 2023-08-19 14:13:06 --> Config Class Initialized
INFO - 2023-08-19 14:13:06 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:13:06 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:13:06 --> Utf8 Class Initialized
INFO - 2023-08-19 14:13:06 --> URI Class Initialized
INFO - 2023-08-19 14:13:06 --> Router Class Initialized
INFO - 2023-08-19 14:13:06 --> Output Class Initialized
INFO - 2023-08-19 14:13:06 --> Security Class Initialized
DEBUG - 2023-08-19 14:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:13:06 --> Input Class Initialized
INFO - 2023-08-19 14:13:06 --> Language Class Initialized
INFO - 2023-08-19 14:13:06 --> Language Class Initialized
INFO - 2023-08-19 14:13:06 --> Config Class Initialized
INFO - 2023-08-19 14:13:06 --> Loader Class Initialized
INFO - 2023-08-19 14:13:06 --> Helper loaded: url_helper
INFO - 2023-08-19 14:13:06 --> Helper loaded: file_helper
INFO - 2023-08-19 14:13:06 --> Helper loaded: form_helper
INFO - 2023-08-19 14:13:06 --> Helper loaded: my_helper
INFO - 2023-08-19 14:13:06 --> Database Driver Class Initialized
INFO - 2023-08-19 14:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:13:06 --> Controller Class Initialized
INFO - 2023-08-19 14:13:24 --> Config Class Initialized
INFO - 2023-08-19 14:13:24 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:13:24 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:13:24 --> Utf8 Class Initialized
INFO - 2023-08-19 14:13:24 --> URI Class Initialized
INFO - 2023-08-19 14:13:24 --> Router Class Initialized
INFO - 2023-08-19 14:13:24 --> Output Class Initialized
INFO - 2023-08-19 14:13:24 --> Security Class Initialized
DEBUG - 2023-08-19 14:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:13:24 --> Input Class Initialized
INFO - 2023-08-19 14:13:24 --> Language Class Initialized
INFO - 2023-08-19 14:13:24 --> Language Class Initialized
INFO - 2023-08-19 14:13:24 --> Config Class Initialized
INFO - 2023-08-19 14:13:24 --> Loader Class Initialized
INFO - 2023-08-19 14:13:24 --> Helper loaded: url_helper
INFO - 2023-08-19 14:13:24 --> Helper loaded: file_helper
INFO - 2023-08-19 14:13:24 --> Helper loaded: form_helper
INFO - 2023-08-19 14:13:24 --> Helper loaded: my_helper
INFO - 2023-08-19 14:13:24 --> Database Driver Class Initialized
INFO - 2023-08-19 14:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:13:24 --> Controller Class Initialized
DEBUG - 2023-08-19 14:13:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-08-19 14:13:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 14:13:24 --> Final output sent to browser
DEBUG - 2023-08-19 14:13:24 --> Total execution time: 0.0421
INFO - 2023-08-19 14:13:24 --> Config Class Initialized
INFO - 2023-08-19 14:13:24 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:13:24 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:13:24 --> Utf8 Class Initialized
INFO - 2023-08-19 14:13:24 --> URI Class Initialized
INFO - 2023-08-19 14:13:24 --> Router Class Initialized
INFO - 2023-08-19 14:13:24 --> Output Class Initialized
INFO - 2023-08-19 14:13:24 --> Security Class Initialized
DEBUG - 2023-08-19 14:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:13:24 --> Input Class Initialized
INFO - 2023-08-19 14:13:24 --> Language Class Initialized
ERROR - 2023-08-19 14:13:24 --> 404 Page Not Found: /index
INFO - 2023-08-19 14:13:24 --> Config Class Initialized
INFO - 2023-08-19 14:13:24 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:13:24 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:13:24 --> Utf8 Class Initialized
INFO - 2023-08-19 14:13:24 --> URI Class Initialized
INFO - 2023-08-19 14:13:24 --> Router Class Initialized
INFO - 2023-08-19 14:13:24 --> Output Class Initialized
INFO - 2023-08-19 14:13:24 --> Security Class Initialized
DEBUG - 2023-08-19 14:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:13:24 --> Input Class Initialized
INFO - 2023-08-19 14:13:24 --> Language Class Initialized
INFO - 2023-08-19 14:13:24 --> Language Class Initialized
INFO - 2023-08-19 14:13:24 --> Config Class Initialized
INFO - 2023-08-19 14:13:24 --> Loader Class Initialized
INFO - 2023-08-19 14:13:24 --> Helper loaded: url_helper
INFO - 2023-08-19 14:13:24 --> Helper loaded: file_helper
INFO - 2023-08-19 14:13:24 --> Helper loaded: form_helper
INFO - 2023-08-19 14:13:24 --> Helper loaded: my_helper
INFO - 2023-08-19 14:13:24 --> Database Driver Class Initialized
INFO - 2023-08-19 14:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:13:24 --> Controller Class Initialized
INFO - 2023-08-19 14:13:25 --> Config Class Initialized
INFO - 2023-08-19 14:13:25 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:13:25 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:13:25 --> Utf8 Class Initialized
INFO - 2023-08-19 14:13:25 --> URI Class Initialized
INFO - 2023-08-19 14:13:25 --> Router Class Initialized
INFO - 2023-08-19 14:13:25 --> Output Class Initialized
INFO - 2023-08-19 14:13:25 --> Security Class Initialized
DEBUG - 2023-08-19 14:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:13:25 --> Input Class Initialized
INFO - 2023-08-19 14:13:25 --> Language Class Initialized
INFO - 2023-08-19 14:13:25 --> Language Class Initialized
INFO - 2023-08-19 14:13:25 --> Config Class Initialized
INFO - 2023-08-19 14:13:25 --> Loader Class Initialized
INFO - 2023-08-19 14:13:25 --> Helper loaded: url_helper
INFO - 2023-08-19 14:13:25 --> Helper loaded: file_helper
INFO - 2023-08-19 14:13:25 --> Helper loaded: form_helper
INFO - 2023-08-19 14:13:25 --> Helper loaded: my_helper
INFO - 2023-08-19 14:13:25 --> Database Driver Class Initialized
INFO - 2023-08-19 14:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:13:25 --> Controller Class Initialized
DEBUG - 2023-08-19 14:13:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2023-08-19 14:13:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 14:13:25 --> Final output sent to browser
DEBUG - 2023-08-19 14:13:25 --> Total execution time: 0.2126
INFO - 2023-08-19 14:13:34 --> Config Class Initialized
INFO - 2023-08-19 14:13:34 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:13:34 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:13:34 --> Utf8 Class Initialized
INFO - 2023-08-19 14:13:34 --> URI Class Initialized
INFO - 2023-08-19 14:13:34 --> Router Class Initialized
INFO - 2023-08-19 14:13:34 --> Output Class Initialized
INFO - 2023-08-19 14:13:34 --> Security Class Initialized
DEBUG - 2023-08-19 14:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:13:34 --> Input Class Initialized
INFO - 2023-08-19 14:13:34 --> Language Class Initialized
INFO - 2023-08-19 14:13:34 --> Language Class Initialized
INFO - 2023-08-19 14:13:34 --> Config Class Initialized
INFO - 2023-08-19 14:13:34 --> Loader Class Initialized
INFO - 2023-08-19 14:13:34 --> Helper loaded: url_helper
INFO - 2023-08-19 14:13:34 --> Helper loaded: file_helper
INFO - 2023-08-19 14:13:34 --> Helper loaded: form_helper
INFO - 2023-08-19 14:13:34 --> Helper loaded: my_helper
INFO - 2023-08-19 14:13:34 --> Database Driver Class Initialized
INFO - 2023-08-19 14:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:13:34 --> Controller Class Initialized
INFO - 2023-08-19 14:13:34 --> Config Class Initialized
INFO - 2023-08-19 14:13:34 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:13:34 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:13:34 --> Utf8 Class Initialized
INFO - 2023-08-19 14:13:34 --> URI Class Initialized
INFO - 2023-08-19 14:13:34 --> Router Class Initialized
INFO - 2023-08-19 14:13:34 --> Output Class Initialized
INFO - 2023-08-19 14:13:34 --> Security Class Initialized
DEBUG - 2023-08-19 14:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:13:34 --> Input Class Initialized
INFO - 2023-08-19 14:13:34 --> Language Class Initialized
INFO - 2023-08-19 14:13:34 --> Language Class Initialized
INFO - 2023-08-19 14:13:34 --> Config Class Initialized
INFO - 2023-08-19 14:13:34 --> Loader Class Initialized
INFO - 2023-08-19 14:13:34 --> Helper loaded: url_helper
INFO - 2023-08-19 14:13:34 --> Helper loaded: file_helper
INFO - 2023-08-19 14:13:34 --> Helper loaded: form_helper
INFO - 2023-08-19 14:13:34 --> Helper loaded: my_helper
INFO - 2023-08-19 14:13:34 --> Database Driver Class Initialized
INFO - 2023-08-19 14:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:13:34 --> Controller Class Initialized
DEBUG - 2023-08-19 14:13:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-08-19 14:13:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 14:13:34 --> Final output sent to browser
DEBUG - 2023-08-19 14:13:34 --> Total execution time: 0.0308
INFO - 2023-08-19 14:13:34 --> Config Class Initialized
INFO - 2023-08-19 14:13:34 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:13:34 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:13:34 --> Utf8 Class Initialized
INFO - 2023-08-19 14:13:34 --> URI Class Initialized
INFO - 2023-08-19 14:13:34 --> Router Class Initialized
INFO - 2023-08-19 14:13:34 --> Output Class Initialized
INFO - 2023-08-19 14:13:34 --> Security Class Initialized
DEBUG - 2023-08-19 14:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:13:34 --> Input Class Initialized
INFO - 2023-08-19 14:13:34 --> Language Class Initialized
ERROR - 2023-08-19 14:13:34 --> 404 Page Not Found: /index
INFO - 2023-08-19 14:13:34 --> Config Class Initialized
INFO - 2023-08-19 14:13:34 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:13:34 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:13:34 --> Utf8 Class Initialized
INFO - 2023-08-19 14:13:34 --> URI Class Initialized
INFO - 2023-08-19 14:13:34 --> Router Class Initialized
INFO - 2023-08-19 14:13:34 --> Output Class Initialized
INFO - 2023-08-19 14:13:34 --> Security Class Initialized
DEBUG - 2023-08-19 14:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:13:34 --> Input Class Initialized
INFO - 2023-08-19 14:13:34 --> Language Class Initialized
INFO - 2023-08-19 14:13:34 --> Language Class Initialized
INFO - 2023-08-19 14:13:34 --> Config Class Initialized
INFO - 2023-08-19 14:13:34 --> Loader Class Initialized
INFO - 2023-08-19 14:13:34 --> Helper loaded: url_helper
INFO - 2023-08-19 14:13:34 --> Helper loaded: file_helper
INFO - 2023-08-19 14:13:34 --> Helper loaded: form_helper
INFO - 2023-08-19 14:13:34 --> Helper loaded: my_helper
INFO - 2023-08-19 14:13:34 --> Database Driver Class Initialized
INFO - 2023-08-19 14:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:13:34 --> Controller Class Initialized
INFO - 2023-08-19 14:13:37 --> Config Class Initialized
INFO - 2023-08-19 14:13:37 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:13:37 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:13:37 --> Utf8 Class Initialized
INFO - 2023-08-19 14:13:37 --> URI Class Initialized
INFO - 2023-08-19 14:13:37 --> Router Class Initialized
INFO - 2023-08-19 14:13:37 --> Output Class Initialized
INFO - 2023-08-19 14:13:37 --> Security Class Initialized
DEBUG - 2023-08-19 14:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:13:37 --> Input Class Initialized
INFO - 2023-08-19 14:13:37 --> Language Class Initialized
INFO - 2023-08-19 14:13:37 --> Language Class Initialized
INFO - 2023-08-19 14:13:37 --> Config Class Initialized
INFO - 2023-08-19 14:13:37 --> Loader Class Initialized
INFO - 2023-08-19 14:13:37 --> Helper loaded: url_helper
INFO - 2023-08-19 14:13:37 --> Helper loaded: file_helper
INFO - 2023-08-19 14:13:37 --> Helper loaded: form_helper
INFO - 2023-08-19 14:13:37 --> Helper loaded: my_helper
INFO - 2023-08-19 14:13:37 --> Database Driver Class Initialized
INFO - 2023-08-19 14:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:13:37 --> Controller Class Initialized
DEBUG - 2023-08-19 14:13:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2023-08-19 14:13:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 14:13:37 --> Final output sent to browser
DEBUG - 2023-08-19 14:13:37 --> Total execution time: 0.0330
INFO - 2023-08-19 14:13:37 --> Config Class Initialized
INFO - 2023-08-19 14:13:37 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:13:37 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:13:37 --> Utf8 Class Initialized
INFO - 2023-08-19 14:13:37 --> URI Class Initialized
INFO - 2023-08-19 14:13:37 --> Router Class Initialized
INFO - 2023-08-19 14:13:37 --> Output Class Initialized
INFO - 2023-08-19 14:13:37 --> Security Class Initialized
DEBUG - 2023-08-19 14:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:13:37 --> Input Class Initialized
INFO - 2023-08-19 14:13:37 --> Language Class Initialized
ERROR - 2023-08-19 14:13:37 --> 404 Page Not Found: /index
INFO - 2023-08-19 14:13:37 --> Config Class Initialized
INFO - 2023-08-19 14:13:37 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:13:37 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:13:37 --> Utf8 Class Initialized
INFO - 2023-08-19 14:13:37 --> URI Class Initialized
INFO - 2023-08-19 14:13:37 --> Router Class Initialized
INFO - 2023-08-19 14:13:37 --> Output Class Initialized
INFO - 2023-08-19 14:13:37 --> Security Class Initialized
DEBUG - 2023-08-19 14:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:13:37 --> Input Class Initialized
INFO - 2023-08-19 14:13:37 --> Language Class Initialized
INFO - 2023-08-19 14:13:37 --> Language Class Initialized
INFO - 2023-08-19 14:13:37 --> Config Class Initialized
INFO - 2023-08-19 14:13:37 --> Loader Class Initialized
INFO - 2023-08-19 14:13:37 --> Helper loaded: url_helper
INFO - 2023-08-19 14:13:37 --> Helper loaded: file_helper
INFO - 2023-08-19 14:13:37 --> Helper loaded: form_helper
INFO - 2023-08-19 14:13:37 --> Helper loaded: my_helper
INFO - 2023-08-19 14:13:37 --> Database Driver Class Initialized
INFO - 2023-08-19 14:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:13:37 --> Controller Class Initialized
INFO - 2023-08-19 14:13:38 --> Config Class Initialized
INFO - 2023-08-19 14:13:38 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:13:38 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:13:38 --> Utf8 Class Initialized
INFO - 2023-08-19 14:13:38 --> URI Class Initialized
INFO - 2023-08-19 14:13:38 --> Router Class Initialized
INFO - 2023-08-19 14:13:38 --> Output Class Initialized
INFO - 2023-08-19 14:13:38 --> Security Class Initialized
DEBUG - 2023-08-19 14:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:13:38 --> Input Class Initialized
INFO - 2023-08-19 14:13:38 --> Language Class Initialized
INFO - 2023-08-19 14:13:38 --> Language Class Initialized
INFO - 2023-08-19 14:13:38 --> Config Class Initialized
INFO - 2023-08-19 14:13:38 --> Loader Class Initialized
INFO - 2023-08-19 14:13:38 --> Helper loaded: url_helper
INFO - 2023-08-19 14:13:38 --> Helper loaded: file_helper
INFO - 2023-08-19 14:13:38 --> Helper loaded: form_helper
INFO - 2023-08-19 14:13:38 --> Helper loaded: my_helper
INFO - 2023-08-19 14:13:38 --> Database Driver Class Initialized
INFO - 2023-08-19 14:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:13:38 --> Controller Class Initialized
DEBUG - 2023-08-19 14:13:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2023-08-19 14:13:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 14:13:38 --> Final output sent to browser
DEBUG - 2023-08-19 14:13:38 --> Total execution time: 0.0554
INFO - 2023-08-19 14:13:38 --> Config Class Initialized
INFO - 2023-08-19 14:13:38 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:13:38 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:13:38 --> Utf8 Class Initialized
INFO - 2023-08-19 14:13:38 --> URI Class Initialized
INFO - 2023-08-19 14:13:38 --> Router Class Initialized
INFO - 2023-08-19 14:13:38 --> Output Class Initialized
INFO - 2023-08-19 14:13:38 --> Security Class Initialized
DEBUG - 2023-08-19 14:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:13:38 --> Input Class Initialized
INFO - 2023-08-19 14:13:38 --> Language Class Initialized
ERROR - 2023-08-19 14:13:38 --> 404 Page Not Found: /index
INFO - 2023-08-19 14:13:38 --> Config Class Initialized
INFO - 2023-08-19 14:13:38 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:13:38 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:13:38 --> Utf8 Class Initialized
INFO - 2023-08-19 14:13:38 --> URI Class Initialized
INFO - 2023-08-19 14:13:38 --> Router Class Initialized
INFO - 2023-08-19 14:13:39 --> Output Class Initialized
INFO - 2023-08-19 14:13:39 --> Security Class Initialized
DEBUG - 2023-08-19 14:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:13:39 --> Input Class Initialized
INFO - 2023-08-19 14:13:39 --> Language Class Initialized
INFO - 2023-08-19 14:13:39 --> Language Class Initialized
INFO - 2023-08-19 14:13:39 --> Config Class Initialized
INFO - 2023-08-19 14:13:39 --> Loader Class Initialized
INFO - 2023-08-19 14:13:39 --> Helper loaded: url_helper
INFO - 2023-08-19 14:13:39 --> Helper loaded: file_helper
INFO - 2023-08-19 14:13:39 --> Helper loaded: form_helper
INFO - 2023-08-19 14:13:39 --> Helper loaded: my_helper
INFO - 2023-08-19 14:13:39 --> Database Driver Class Initialized
INFO - 2023-08-19 14:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:13:39 --> Controller Class Initialized
INFO - 2023-08-19 14:13:47 --> Config Class Initialized
INFO - 2023-08-19 14:13:47 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:13:47 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:13:47 --> Utf8 Class Initialized
INFO - 2023-08-19 14:13:47 --> URI Class Initialized
DEBUG - 2023-08-19 14:13:47 --> No URI present. Default controller set.
INFO - 2023-08-19 14:13:47 --> Router Class Initialized
INFO - 2023-08-19 14:13:47 --> Output Class Initialized
INFO - 2023-08-19 14:13:47 --> Security Class Initialized
DEBUG - 2023-08-19 14:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:13:47 --> Input Class Initialized
INFO - 2023-08-19 14:13:47 --> Language Class Initialized
INFO - 2023-08-19 14:13:47 --> Language Class Initialized
INFO - 2023-08-19 14:13:47 --> Config Class Initialized
INFO - 2023-08-19 14:13:47 --> Loader Class Initialized
INFO - 2023-08-19 14:13:47 --> Helper loaded: url_helper
INFO - 2023-08-19 14:13:47 --> Helper loaded: file_helper
INFO - 2023-08-19 14:13:47 --> Helper loaded: form_helper
INFO - 2023-08-19 14:13:47 --> Helper loaded: my_helper
INFO - 2023-08-19 14:13:47 --> Database Driver Class Initialized
INFO - 2023-08-19 14:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:13:48 --> Controller Class Initialized
DEBUG - 2023-08-19 14:13:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-08-19 14:13:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 14:13:48 --> Final output sent to browser
DEBUG - 2023-08-19 14:13:48 --> Total execution time: 0.0319
INFO - 2023-08-19 14:15:06 --> Config Class Initialized
INFO - 2023-08-19 14:15:06 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:15:06 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:15:06 --> Utf8 Class Initialized
INFO - 2023-08-19 14:15:06 --> URI Class Initialized
INFO - 2023-08-19 14:15:06 --> Router Class Initialized
INFO - 2023-08-19 14:15:06 --> Output Class Initialized
INFO - 2023-08-19 14:15:06 --> Security Class Initialized
DEBUG - 2023-08-19 14:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:15:06 --> Input Class Initialized
INFO - 2023-08-19 14:15:06 --> Language Class Initialized
INFO - 2023-08-19 14:15:06 --> Language Class Initialized
INFO - 2023-08-19 14:15:06 --> Config Class Initialized
INFO - 2023-08-19 14:15:06 --> Loader Class Initialized
INFO - 2023-08-19 14:15:06 --> Helper loaded: url_helper
INFO - 2023-08-19 14:15:06 --> Helper loaded: file_helper
INFO - 2023-08-19 14:15:06 --> Helper loaded: form_helper
INFO - 2023-08-19 14:15:06 --> Helper loaded: my_helper
INFO - 2023-08-19 14:15:06 --> Database Driver Class Initialized
INFO - 2023-08-19 14:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:15:06 --> Controller Class Initialized
DEBUG - 2023-08-19 14:15:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2023-08-19 14:15:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 14:15:06 --> Final output sent to browser
DEBUG - 2023-08-19 14:15:06 --> Total execution time: 0.0825
INFO - 2023-08-19 14:15:06 --> Config Class Initialized
INFO - 2023-08-19 14:15:06 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:15:06 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:15:06 --> Utf8 Class Initialized
INFO - 2023-08-19 14:15:06 --> URI Class Initialized
INFO - 2023-08-19 14:15:06 --> Router Class Initialized
INFO - 2023-08-19 14:15:06 --> Output Class Initialized
INFO - 2023-08-19 14:15:06 --> Security Class Initialized
DEBUG - 2023-08-19 14:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:15:06 --> Input Class Initialized
INFO - 2023-08-19 14:15:06 --> Language Class Initialized
ERROR - 2023-08-19 14:15:06 --> 404 Page Not Found: /index
INFO - 2023-08-19 14:15:06 --> Config Class Initialized
INFO - 2023-08-19 14:15:06 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:15:06 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:15:06 --> Utf8 Class Initialized
INFO - 2023-08-19 14:15:06 --> URI Class Initialized
INFO - 2023-08-19 14:15:06 --> Router Class Initialized
INFO - 2023-08-19 14:15:06 --> Output Class Initialized
INFO - 2023-08-19 14:15:06 --> Security Class Initialized
DEBUG - 2023-08-19 14:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:15:06 --> Input Class Initialized
INFO - 2023-08-19 14:15:06 --> Language Class Initialized
INFO - 2023-08-19 14:15:06 --> Language Class Initialized
INFO - 2023-08-19 14:15:06 --> Config Class Initialized
INFO - 2023-08-19 14:15:06 --> Loader Class Initialized
INFO - 2023-08-19 14:15:06 --> Helper loaded: url_helper
INFO - 2023-08-19 14:15:06 --> Helper loaded: file_helper
INFO - 2023-08-19 14:15:06 --> Helper loaded: form_helper
INFO - 2023-08-19 14:15:06 --> Helper loaded: my_helper
INFO - 2023-08-19 14:15:06 --> Database Driver Class Initialized
INFO - 2023-08-19 14:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:15:06 --> Controller Class Initialized
INFO - 2023-08-19 14:15:07 --> Config Class Initialized
INFO - 2023-08-19 14:15:07 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:15:07 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:15:07 --> Utf8 Class Initialized
INFO - 2023-08-19 14:15:07 --> URI Class Initialized
INFO - 2023-08-19 14:15:07 --> Router Class Initialized
INFO - 2023-08-19 14:15:07 --> Output Class Initialized
INFO - 2023-08-19 14:15:07 --> Security Class Initialized
DEBUG - 2023-08-19 14:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:15:07 --> Input Class Initialized
INFO - 2023-08-19 14:15:07 --> Language Class Initialized
INFO - 2023-08-19 14:15:07 --> Language Class Initialized
INFO - 2023-08-19 14:15:07 --> Config Class Initialized
INFO - 2023-08-19 14:15:07 --> Loader Class Initialized
INFO - 2023-08-19 14:15:07 --> Helper loaded: url_helper
INFO - 2023-08-19 14:15:07 --> Helper loaded: file_helper
INFO - 2023-08-19 14:15:07 --> Helper loaded: form_helper
INFO - 2023-08-19 14:15:07 --> Helper loaded: my_helper
INFO - 2023-08-19 14:15:07 --> Database Driver Class Initialized
INFO - 2023-08-19 14:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:15:07 --> Controller Class Initialized
DEBUG - 2023-08-19 14:15:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2023-08-19 14:15:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 14:15:07 --> Final output sent to browser
DEBUG - 2023-08-19 14:15:07 --> Total execution time: 0.0308
INFO - 2023-08-19 14:15:07 --> Config Class Initialized
INFO - 2023-08-19 14:15:07 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:15:07 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:15:07 --> Utf8 Class Initialized
INFO - 2023-08-19 14:15:07 --> URI Class Initialized
INFO - 2023-08-19 14:15:07 --> Router Class Initialized
INFO - 2023-08-19 14:15:07 --> Output Class Initialized
INFO - 2023-08-19 14:15:07 --> Security Class Initialized
DEBUG - 2023-08-19 14:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:15:07 --> Input Class Initialized
INFO - 2023-08-19 14:15:07 --> Language Class Initialized
ERROR - 2023-08-19 14:15:07 --> 404 Page Not Found: /index
INFO - 2023-08-19 14:15:07 --> Config Class Initialized
INFO - 2023-08-19 14:15:07 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:15:07 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:15:07 --> Utf8 Class Initialized
INFO - 2023-08-19 14:15:07 --> URI Class Initialized
INFO - 2023-08-19 14:15:07 --> Router Class Initialized
INFO - 2023-08-19 14:15:07 --> Output Class Initialized
INFO - 2023-08-19 14:15:07 --> Security Class Initialized
DEBUG - 2023-08-19 14:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:15:07 --> Input Class Initialized
INFO - 2023-08-19 14:15:07 --> Language Class Initialized
INFO - 2023-08-19 14:15:07 --> Language Class Initialized
INFO - 2023-08-19 14:15:07 --> Config Class Initialized
INFO - 2023-08-19 14:15:07 --> Loader Class Initialized
INFO - 2023-08-19 14:15:07 --> Helper loaded: url_helper
INFO - 2023-08-19 14:15:07 --> Helper loaded: file_helper
INFO - 2023-08-19 14:15:07 --> Helper loaded: form_helper
INFO - 2023-08-19 14:15:07 --> Helper loaded: my_helper
INFO - 2023-08-19 14:15:07 --> Database Driver Class Initialized
INFO - 2023-08-19 14:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:15:07 --> Controller Class Initialized
INFO - 2023-08-19 14:15:09 --> Config Class Initialized
INFO - 2023-08-19 14:15:09 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:15:09 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:15:09 --> Utf8 Class Initialized
INFO - 2023-08-19 14:15:09 --> URI Class Initialized
INFO - 2023-08-19 14:15:09 --> Router Class Initialized
INFO - 2023-08-19 14:15:09 --> Output Class Initialized
INFO - 2023-08-19 14:15:09 --> Security Class Initialized
DEBUG - 2023-08-19 14:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:15:09 --> Input Class Initialized
INFO - 2023-08-19 14:15:09 --> Language Class Initialized
INFO - 2023-08-19 14:15:09 --> Language Class Initialized
INFO - 2023-08-19 14:15:09 --> Config Class Initialized
INFO - 2023-08-19 14:15:09 --> Loader Class Initialized
INFO - 2023-08-19 14:15:09 --> Helper loaded: url_helper
INFO - 2023-08-19 14:15:09 --> Helper loaded: file_helper
INFO - 2023-08-19 14:15:09 --> Helper loaded: form_helper
INFO - 2023-08-19 14:15:09 --> Helper loaded: my_helper
INFO - 2023-08-19 14:15:09 --> Database Driver Class Initialized
INFO - 2023-08-19 14:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:15:09 --> Controller Class Initialized
DEBUG - 2023-08-19 14:15:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2023-08-19 14:15:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 14:15:09 --> Final output sent to browser
DEBUG - 2023-08-19 14:15:09 --> Total execution time: 0.0443
INFO - 2023-08-19 14:15:09 --> Config Class Initialized
INFO - 2023-08-19 14:15:09 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:15:09 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:15:09 --> Utf8 Class Initialized
INFO - 2023-08-19 14:15:09 --> URI Class Initialized
INFO - 2023-08-19 14:15:09 --> Router Class Initialized
INFO - 2023-08-19 14:15:09 --> Output Class Initialized
INFO - 2023-08-19 14:15:09 --> Security Class Initialized
DEBUG - 2023-08-19 14:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:15:09 --> Input Class Initialized
INFO - 2023-08-19 14:15:09 --> Language Class Initialized
ERROR - 2023-08-19 14:15:09 --> 404 Page Not Found: /index
INFO - 2023-08-19 14:15:09 --> Config Class Initialized
INFO - 2023-08-19 14:15:09 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:15:09 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:15:09 --> Utf8 Class Initialized
INFO - 2023-08-19 14:15:09 --> URI Class Initialized
INFO - 2023-08-19 14:15:09 --> Router Class Initialized
INFO - 2023-08-19 14:15:09 --> Output Class Initialized
INFO - 2023-08-19 14:15:09 --> Security Class Initialized
DEBUG - 2023-08-19 14:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:15:09 --> Input Class Initialized
INFO - 2023-08-19 14:15:09 --> Language Class Initialized
INFO - 2023-08-19 14:15:09 --> Language Class Initialized
INFO - 2023-08-19 14:15:09 --> Config Class Initialized
INFO - 2023-08-19 14:15:09 --> Loader Class Initialized
INFO - 2023-08-19 14:15:09 --> Helper loaded: url_helper
INFO - 2023-08-19 14:15:09 --> Helper loaded: file_helper
INFO - 2023-08-19 14:15:09 --> Helper loaded: form_helper
INFO - 2023-08-19 14:15:09 --> Helper loaded: my_helper
INFO - 2023-08-19 14:15:09 --> Database Driver Class Initialized
INFO - 2023-08-19 14:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:15:09 --> Controller Class Initialized
INFO - 2023-08-19 14:15:10 --> Config Class Initialized
INFO - 2023-08-19 14:15:10 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:15:10 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:15:10 --> Utf8 Class Initialized
INFO - 2023-08-19 14:15:10 --> URI Class Initialized
INFO - 2023-08-19 14:15:10 --> Router Class Initialized
INFO - 2023-08-19 14:15:10 --> Output Class Initialized
INFO - 2023-08-19 14:15:10 --> Security Class Initialized
DEBUG - 2023-08-19 14:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:15:10 --> Input Class Initialized
INFO - 2023-08-19 14:15:10 --> Language Class Initialized
INFO - 2023-08-19 14:15:10 --> Language Class Initialized
INFO - 2023-08-19 14:15:10 --> Config Class Initialized
INFO - 2023-08-19 14:15:10 --> Loader Class Initialized
INFO - 2023-08-19 14:15:10 --> Helper loaded: url_helper
INFO - 2023-08-19 14:15:10 --> Helper loaded: file_helper
INFO - 2023-08-19 14:15:10 --> Helper loaded: form_helper
INFO - 2023-08-19 14:15:10 --> Helper loaded: my_helper
INFO - 2023-08-19 14:15:10 --> Database Driver Class Initialized
INFO - 2023-08-19 14:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:15:10 --> Controller Class Initialized
DEBUG - 2023-08-19 14:15:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2023-08-19 14:15:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 14:15:10 --> Final output sent to browser
DEBUG - 2023-08-19 14:15:10 --> Total execution time: 0.0620
INFO - 2023-08-19 14:15:10 --> Config Class Initialized
INFO - 2023-08-19 14:15:10 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:15:10 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:15:10 --> Utf8 Class Initialized
INFO - 2023-08-19 14:15:10 --> URI Class Initialized
INFO - 2023-08-19 14:15:10 --> Router Class Initialized
INFO - 2023-08-19 14:15:10 --> Output Class Initialized
INFO - 2023-08-19 14:15:10 --> Security Class Initialized
DEBUG - 2023-08-19 14:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:15:10 --> Input Class Initialized
INFO - 2023-08-19 14:15:10 --> Language Class Initialized
ERROR - 2023-08-19 14:15:10 --> 404 Page Not Found: /index
INFO - 2023-08-19 14:15:11 --> Config Class Initialized
INFO - 2023-08-19 14:15:11 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:15:11 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:15:11 --> Utf8 Class Initialized
INFO - 2023-08-19 14:15:11 --> URI Class Initialized
INFO - 2023-08-19 14:15:11 --> Router Class Initialized
INFO - 2023-08-19 14:15:11 --> Output Class Initialized
INFO - 2023-08-19 14:15:11 --> Security Class Initialized
DEBUG - 2023-08-19 14:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:15:11 --> Input Class Initialized
INFO - 2023-08-19 14:15:11 --> Language Class Initialized
INFO - 2023-08-19 14:15:11 --> Language Class Initialized
INFO - 2023-08-19 14:15:11 --> Config Class Initialized
INFO - 2023-08-19 14:15:11 --> Loader Class Initialized
INFO - 2023-08-19 14:15:11 --> Helper loaded: url_helper
INFO - 2023-08-19 14:15:11 --> Helper loaded: file_helper
INFO - 2023-08-19 14:15:11 --> Helper loaded: form_helper
INFO - 2023-08-19 14:15:11 --> Helper loaded: my_helper
INFO - 2023-08-19 14:15:11 --> Database Driver Class Initialized
INFO - 2023-08-19 14:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:15:11 --> Controller Class Initialized
INFO - 2023-08-19 14:15:14 --> Config Class Initialized
INFO - 2023-08-19 14:15:14 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:15:14 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:15:14 --> Utf8 Class Initialized
INFO - 2023-08-19 14:15:14 --> URI Class Initialized
INFO - 2023-08-19 14:15:14 --> Router Class Initialized
INFO - 2023-08-19 14:15:14 --> Output Class Initialized
INFO - 2023-08-19 14:15:14 --> Security Class Initialized
DEBUG - 2023-08-19 14:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:15:14 --> Input Class Initialized
INFO - 2023-08-19 14:15:14 --> Language Class Initialized
INFO - 2023-08-19 14:15:14 --> Language Class Initialized
INFO - 2023-08-19 14:15:14 --> Config Class Initialized
INFO - 2023-08-19 14:15:14 --> Loader Class Initialized
INFO - 2023-08-19 14:15:14 --> Helper loaded: url_helper
INFO - 2023-08-19 14:15:14 --> Helper loaded: file_helper
INFO - 2023-08-19 14:15:14 --> Helper loaded: form_helper
INFO - 2023-08-19 14:15:14 --> Helper loaded: my_helper
INFO - 2023-08-19 14:15:14 --> Database Driver Class Initialized
INFO - 2023-08-19 14:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:15:14 --> Controller Class Initialized
DEBUG - 2023-08-19 14:15:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_ekstra/views/list.php
DEBUG - 2023-08-19 14:15:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 14:15:14 --> Final output sent to browser
DEBUG - 2023-08-19 14:15:14 --> Total execution time: 0.0294
INFO - 2023-08-19 14:15:15 --> Config Class Initialized
INFO - 2023-08-19 14:15:15 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:15:15 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:15:15 --> Utf8 Class Initialized
INFO - 2023-08-19 14:15:15 --> URI Class Initialized
INFO - 2023-08-19 14:15:15 --> Router Class Initialized
INFO - 2023-08-19 14:15:15 --> Output Class Initialized
INFO - 2023-08-19 14:15:15 --> Security Class Initialized
DEBUG - 2023-08-19 14:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:15:15 --> Input Class Initialized
INFO - 2023-08-19 14:15:15 --> Language Class Initialized
ERROR - 2023-08-19 14:15:15 --> 404 Page Not Found: /index
INFO - 2023-08-19 14:15:15 --> Config Class Initialized
INFO - 2023-08-19 14:15:15 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:15:15 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:15:15 --> Utf8 Class Initialized
INFO - 2023-08-19 14:15:15 --> URI Class Initialized
INFO - 2023-08-19 14:15:15 --> Router Class Initialized
INFO - 2023-08-19 14:15:15 --> Output Class Initialized
INFO - 2023-08-19 14:15:15 --> Security Class Initialized
DEBUG - 2023-08-19 14:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:15:15 --> Input Class Initialized
INFO - 2023-08-19 14:15:15 --> Language Class Initialized
INFO - 2023-08-19 14:15:15 --> Language Class Initialized
INFO - 2023-08-19 14:15:15 --> Config Class Initialized
INFO - 2023-08-19 14:15:15 --> Loader Class Initialized
INFO - 2023-08-19 14:15:15 --> Helper loaded: url_helper
INFO - 2023-08-19 14:15:15 --> Helper loaded: file_helper
INFO - 2023-08-19 14:15:15 --> Helper loaded: form_helper
INFO - 2023-08-19 14:15:15 --> Helper loaded: my_helper
INFO - 2023-08-19 14:15:15 --> Database Driver Class Initialized
INFO - 2023-08-19 14:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:15:15 --> Controller Class Initialized
INFO - 2023-08-19 15:15:24 --> Config Class Initialized
INFO - 2023-08-19 15:15:24 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:15:24 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:15:24 --> Utf8 Class Initialized
INFO - 2023-08-19 15:15:24 --> URI Class Initialized
INFO - 2023-08-19 15:15:24 --> Router Class Initialized
INFO - 2023-08-19 15:15:24 --> Output Class Initialized
INFO - 2023-08-19 15:15:24 --> Security Class Initialized
DEBUG - 2023-08-19 15:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:15:24 --> Input Class Initialized
INFO - 2023-08-19 15:15:24 --> Language Class Initialized
INFO - 2023-08-19 15:15:24 --> Language Class Initialized
INFO - 2023-08-19 15:15:24 --> Config Class Initialized
INFO - 2023-08-19 15:15:24 --> Loader Class Initialized
INFO - 2023-08-19 15:15:24 --> Helper loaded: url_helper
INFO - 2023-08-19 15:15:24 --> Helper loaded: file_helper
INFO - 2023-08-19 15:15:24 --> Helper loaded: form_helper
INFO - 2023-08-19 15:15:24 --> Helper loaded: my_helper
INFO - 2023-08-19 15:15:24 --> Database Driver Class Initialized
INFO - 2023-08-19 15:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:15:24 --> Controller Class Initialized
DEBUG - 2023-08-19 15:15:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-08-19 15:15:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:15:25 --> Final output sent to browser
DEBUG - 2023-08-19 15:15:25 --> Total execution time: 0.1541
INFO - 2023-08-19 15:15:25 --> Config Class Initialized
INFO - 2023-08-19 15:15:25 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:15:25 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:15:25 --> Utf8 Class Initialized
INFO - 2023-08-19 15:15:25 --> URI Class Initialized
INFO - 2023-08-19 15:15:25 --> Router Class Initialized
INFO - 2023-08-19 15:15:25 --> Output Class Initialized
INFO - 2023-08-19 15:15:25 --> Security Class Initialized
DEBUG - 2023-08-19 15:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:15:25 --> Input Class Initialized
INFO - 2023-08-19 15:15:25 --> Language Class Initialized
INFO - 2023-08-19 15:15:25 --> Language Class Initialized
INFO - 2023-08-19 15:15:25 --> Config Class Initialized
INFO - 2023-08-19 15:15:25 --> Loader Class Initialized
INFO - 2023-08-19 15:15:25 --> Helper loaded: url_helper
INFO - 2023-08-19 15:15:25 --> Helper loaded: file_helper
INFO - 2023-08-19 15:15:25 --> Helper loaded: form_helper
INFO - 2023-08-19 15:15:25 --> Helper loaded: my_helper
INFO - 2023-08-19 15:15:25 --> Database Driver Class Initialized
INFO - 2023-08-19 15:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:15:25 --> Controller Class Initialized
INFO - 2023-08-19 15:23:17 --> Config Class Initialized
INFO - 2023-08-19 15:23:17 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:23:17 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:23:17 --> Utf8 Class Initialized
INFO - 2023-08-19 15:23:17 --> URI Class Initialized
INFO - 2023-08-19 15:23:17 --> Router Class Initialized
INFO - 2023-08-19 15:23:17 --> Output Class Initialized
INFO - 2023-08-19 15:23:17 --> Security Class Initialized
DEBUG - 2023-08-19 15:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:23:17 --> Input Class Initialized
INFO - 2023-08-19 15:23:17 --> Language Class Initialized
INFO - 2023-08-19 15:23:17 --> Config Class Initialized
INFO - 2023-08-19 15:23:17 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:23:17 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:23:17 --> Utf8 Class Initialized
INFO - 2023-08-19 15:23:17 --> URI Class Initialized
INFO - 2023-08-19 15:23:17 --> Router Class Initialized
INFO - 2023-08-19 15:23:17 --> Output Class Initialized
INFO - 2023-08-19 15:23:17 --> Security Class Initialized
DEBUG - 2023-08-19 15:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:23:17 --> Input Class Initialized
INFO - 2023-08-19 15:23:17 --> Language Class Initialized
INFO - 2023-08-19 15:23:17 --> Language Class Initialized
INFO - 2023-08-19 15:23:17 --> Config Class Initialized
INFO - 2023-08-19 15:23:17 --> Loader Class Initialized
INFO - 2023-08-19 15:23:17 --> Helper loaded: url_helper
INFO - 2023-08-19 15:23:17 --> Language Class Initialized
INFO - 2023-08-19 15:23:17 --> Config Class Initialized
INFO - 2023-08-19 15:23:17 --> Loader Class Initialized
INFO - 2023-08-19 15:23:17 --> Helper loaded: url_helper
INFO - 2023-08-19 15:23:17 --> Helper loaded: file_helper
INFO - 2023-08-19 15:23:17 --> Helper loaded: file_helper
INFO - 2023-08-19 15:23:17 --> Helper loaded: form_helper
INFO - 2023-08-19 15:23:17 --> Helper loaded: my_helper
INFO - 2023-08-19 15:23:17 --> Helper loaded: form_helper
INFO - 2023-08-19 15:23:17 --> Helper loaded: my_helper
INFO - 2023-08-19 15:23:17 --> Database Driver Class Initialized
INFO - 2023-08-19 15:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:23:17 --> Controller Class Initialized
INFO - 2023-08-19 15:23:17 --> Database Driver Class Initialized
INFO - 2023-08-19 15:23:17 --> Final output sent to browser
DEBUG - 2023-08-19 15:23:17 --> Total execution time: 0.1106
INFO - 2023-08-19 15:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:23:17 --> Controller Class Initialized
INFO - 2023-08-19 15:23:17 --> Final output sent to browser
DEBUG - 2023-08-19 15:23:17 --> Total execution time: 0.0951
INFO - 2023-08-19 15:23:19 --> Config Class Initialized
INFO - 2023-08-19 15:23:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:23:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:23:19 --> Utf8 Class Initialized
INFO - 2023-08-19 15:23:19 --> URI Class Initialized
INFO - 2023-08-19 15:23:19 --> Router Class Initialized
INFO - 2023-08-19 15:23:19 --> Output Class Initialized
INFO - 2023-08-19 15:23:19 --> Security Class Initialized
DEBUG - 2023-08-19 15:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:23:19 --> Input Class Initialized
INFO - 2023-08-19 15:23:19 --> Language Class Initialized
INFO - 2023-08-19 15:23:19 --> Language Class Initialized
INFO - 2023-08-19 15:23:19 --> Config Class Initialized
INFO - 2023-08-19 15:23:19 --> Loader Class Initialized
INFO - 2023-08-19 15:23:19 --> Helper loaded: url_helper
INFO - 2023-08-19 15:23:19 --> Helper loaded: file_helper
INFO - 2023-08-19 15:23:19 --> Helper loaded: form_helper
INFO - 2023-08-19 15:23:19 --> Helper loaded: my_helper
INFO - 2023-08-19 15:23:19 --> Database Driver Class Initialized
INFO - 2023-08-19 15:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:23:19 --> Controller Class Initialized
DEBUG - 2023-08-19 15:23:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-08-19 15:23:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:23:19 --> Final output sent to browser
DEBUG - 2023-08-19 15:23:19 --> Total execution time: 0.0336
INFO - 2023-08-19 15:23:29 --> Config Class Initialized
INFO - 2023-08-19 15:23:29 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:23:29 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:23:29 --> Utf8 Class Initialized
INFO - 2023-08-19 15:23:29 --> URI Class Initialized
INFO - 2023-08-19 15:23:29 --> Router Class Initialized
INFO - 2023-08-19 15:23:29 --> Output Class Initialized
INFO - 2023-08-19 15:23:29 --> Security Class Initialized
DEBUG - 2023-08-19 15:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:23:29 --> Input Class Initialized
INFO - 2023-08-19 15:23:29 --> Language Class Initialized
INFO - 2023-08-19 15:23:29 --> Language Class Initialized
INFO - 2023-08-19 15:23:29 --> Config Class Initialized
INFO - 2023-08-19 15:23:29 --> Loader Class Initialized
INFO - 2023-08-19 15:23:29 --> Helper loaded: url_helper
INFO - 2023-08-19 15:23:29 --> Helper loaded: file_helper
INFO - 2023-08-19 15:23:29 --> Helper loaded: form_helper
INFO - 2023-08-19 15:23:29 --> Helper loaded: my_helper
INFO - 2023-08-19 15:23:29 --> Database Driver Class Initialized
INFO - 2023-08-19 15:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:23:29 --> Controller Class Initialized
DEBUG - 2023-08-19 15:23:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-08-19 15:23:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:23:29 --> Final output sent to browser
DEBUG - 2023-08-19 15:23:29 --> Total execution time: 0.0420
INFO - 2023-08-19 15:23:47 --> Config Class Initialized
INFO - 2023-08-19 15:23:47 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:23:47 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:23:47 --> Utf8 Class Initialized
INFO - 2023-08-19 15:23:47 --> URI Class Initialized
INFO - 2023-08-19 15:23:47 --> Router Class Initialized
INFO - 2023-08-19 15:23:47 --> Output Class Initialized
INFO - 2023-08-19 15:23:47 --> Security Class Initialized
DEBUG - 2023-08-19 15:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:23:47 --> Input Class Initialized
INFO - 2023-08-19 15:23:47 --> Language Class Initialized
INFO - 2023-08-19 15:23:47 --> Language Class Initialized
INFO - 2023-08-19 15:23:47 --> Config Class Initialized
INFO - 2023-08-19 15:23:47 --> Loader Class Initialized
INFO - 2023-08-19 15:23:47 --> Helper loaded: url_helper
INFO - 2023-08-19 15:23:47 --> Helper loaded: file_helper
INFO - 2023-08-19 15:23:47 --> Helper loaded: form_helper
INFO - 2023-08-19 15:23:47 --> Helper loaded: my_helper
INFO - 2023-08-19 15:23:47 --> Database Driver Class Initialized
INFO - 2023-08-19 15:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:23:47 --> Controller Class Initialized
INFO - 2023-08-19 15:23:47 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:23:47 --> Final output sent to browser
DEBUG - 2023-08-19 15:23:47 --> Total execution time: 0.0313
INFO - 2023-08-19 15:23:47 --> Config Class Initialized
INFO - 2023-08-19 15:23:47 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:23:47 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:23:47 --> Utf8 Class Initialized
INFO - 2023-08-19 15:23:47 --> URI Class Initialized
INFO - 2023-08-19 15:23:47 --> Router Class Initialized
INFO - 2023-08-19 15:23:47 --> Output Class Initialized
INFO - 2023-08-19 15:23:47 --> Security Class Initialized
DEBUG - 2023-08-19 15:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:23:47 --> Input Class Initialized
INFO - 2023-08-19 15:23:47 --> Language Class Initialized
INFO - 2023-08-19 15:23:47 --> Language Class Initialized
INFO - 2023-08-19 15:23:47 --> Config Class Initialized
INFO - 2023-08-19 15:23:47 --> Loader Class Initialized
INFO - 2023-08-19 15:23:47 --> Helper loaded: url_helper
INFO - 2023-08-19 15:23:47 --> Helper loaded: file_helper
INFO - 2023-08-19 15:23:47 --> Helper loaded: form_helper
INFO - 2023-08-19 15:23:47 --> Helper loaded: my_helper
INFO - 2023-08-19 15:23:47 --> Database Driver Class Initialized
INFO - 2023-08-19 15:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:23:47 --> Controller Class Initialized
DEBUG - 2023-08-19 15:23:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 15:23:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:23:47 --> Final output sent to browser
DEBUG - 2023-08-19 15:23:47 --> Total execution time: 0.0309
INFO - 2023-08-19 15:23:50 --> Config Class Initialized
INFO - 2023-08-19 15:23:50 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:23:50 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:23:50 --> Utf8 Class Initialized
INFO - 2023-08-19 15:23:50 --> URI Class Initialized
INFO - 2023-08-19 15:23:50 --> Router Class Initialized
INFO - 2023-08-19 15:23:50 --> Output Class Initialized
INFO - 2023-08-19 15:23:50 --> Security Class Initialized
DEBUG - 2023-08-19 15:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:23:50 --> Input Class Initialized
INFO - 2023-08-19 15:23:50 --> Language Class Initialized
INFO - 2023-08-19 15:23:50 --> Language Class Initialized
INFO - 2023-08-19 15:23:50 --> Config Class Initialized
INFO - 2023-08-19 15:23:50 --> Loader Class Initialized
INFO - 2023-08-19 15:23:50 --> Helper loaded: url_helper
INFO - 2023-08-19 15:23:50 --> Helper loaded: file_helper
INFO - 2023-08-19 15:23:50 --> Helper loaded: form_helper
INFO - 2023-08-19 15:23:50 --> Helper loaded: my_helper
INFO - 2023-08-19 15:23:50 --> Database Driver Class Initialized
INFO - 2023-08-19 15:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:23:50 --> Controller Class Initialized
DEBUG - 2023-08-19 15:23:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-08-19 15:23:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:23:50 --> Final output sent to browser
DEBUG - 2023-08-19 15:23:50 --> Total execution time: 0.0354
INFO - 2023-08-19 15:23:50 --> Config Class Initialized
INFO - 2023-08-19 15:23:50 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:23:50 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:23:50 --> Utf8 Class Initialized
INFO - 2023-08-19 15:23:50 --> URI Class Initialized
INFO - 2023-08-19 15:23:50 --> Router Class Initialized
INFO - 2023-08-19 15:23:50 --> Output Class Initialized
INFO - 2023-08-19 15:23:50 --> Security Class Initialized
DEBUG - 2023-08-19 15:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:23:50 --> Input Class Initialized
INFO - 2023-08-19 15:23:50 --> Language Class Initialized
INFO - 2023-08-19 15:23:50 --> Language Class Initialized
INFO - 2023-08-19 15:23:50 --> Config Class Initialized
INFO - 2023-08-19 15:23:50 --> Loader Class Initialized
INFO - 2023-08-19 15:23:50 --> Helper loaded: url_helper
INFO - 2023-08-19 15:23:50 --> Helper loaded: file_helper
INFO - 2023-08-19 15:23:50 --> Helper loaded: form_helper
INFO - 2023-08-19 15:23:50 --> Helper loaded: my_helper
INFO - 2023-08-19 15:23:50 --> Database Driver Class Initialized
INFO - 2023-08-19 15:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:23:50 --> Controller Class Initialized
INFO - 2023-08-19 15:23:54 --> Config Class Initialized
INFO - 2023-08-19 15:23:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:23:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:23:54 --> Utf8 Class Initialized
INFO - 2023-08-19 15:23:54 --> URI Class Initialized
INFO - 2023-08-19 15:23:54 --> Router Class Initialized
INFO - 2023-08-19 15:23:54 --> Output Class Initialized
INFO - 2023-08-19 15:23:54 --> Security Class Initialized
DEBUG - 2023-08-19 15:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:23:54 --> Input Class Initialized
INFO - 2023-08-19 15:23:54 --> Language Class Initialized
INFO - 2023-08-19 15:23:54 --> Language Class Initialized
INFO - 2023-08-19 15:23:54 --> Config Class Initialized
INFO - 2023-08-19 15:23:54 --> Loader Class Initialized
INFO - 2023-08-19 15:23:54 --> Helper loaded: url_helper
INFO - 2023-08-19 15:23:54 --> Helper loaded: file_helper
INFO - 2023-08-19 15:23:54 --> Helper loaded: form_helper
INFO - 2023-08-19 15:23:54 --> Helper loaded: my_helper
INFO - 2023-08-19 15:23:54 --> Database Driver Class Initialized
INFO - 2023-08-19 15:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:23:54 --> Controller Class Initialized
INFO - 2023-08-19 15:27:21 --> Config Class Initialized
INFO - 2023-08-19 15:27:21 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:27:21 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:27:21 --> Utf8 Class Initialized
INFO - 2023-08-19 15:27:21 --> URI Class Initialized
INFO - 2023-08-19 15:27:21 --> Router Class Initialized
INFO - 2023-08-19 15:27:21 --> Output Class Initialized
INFO - 2023-08-19 15:27:21 --> Security Class Initialized
DEBUG - 2023-08-19 15:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:27:21 --> Input Class Initialized
INFO - 2023-08-19 15:27:21 --> Language Class Initialized
INFO - 2023-08-19 15:27:21 --> Language Class Initialized
INFO - 2023-08-19 15:27:21 --> Config Class Initialized
INFO - 2023-08-19 15:27:21 --> Loader Class Initialized
INFO - 2023-08-19 15:27:21 --> Helper loaded: url_helper
INFO - 2023-08-19 15:27:21 --> Helper loaded: file_helper
INFO - 2023-08-19 15:27:21 --> Helper loaded: form_helper
INFO - 2023-08-19 15:27:21 --> Helper loaded: my_helper
INFO - 2023-08-19 15:27:21 --> Database Driver Class Initialized
INFO - 2023-08-19 15:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:27:21 --> Controller Class Initialized
DEBUG - 2023-08-19 15:27:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-08-19 15:27:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:27:21 --> Final output sent to browser
DEBUG - 2023-08-19 15:27:21 --> Total execution time: 0.0363
INFO - 2023-08-19 15:27:52 --> Config Class Initialized
INFO - 2023-08-19 15:27:52 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:27:52 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:27:52 --> Utf8 Class Initialized
INFO - 2023-08-19 15:27:52 --> URI Class Initialized
INFO - 2023-08-19 15:27:52 --> Router Class Initialized
INFO - 2023-08-19 15:27:52 --> Output Class Initialized
INFO - 2023-08-19 15:27:52 --> Security Class Initialized
DEBUG - 2023-08-19 15:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:27:52 --> Input Class Initialized
INFO - 2023-08-19 15:27:52 --> Language Class Initialized
INFO - 2023-08-19 15:27:52 --> Language Class Initialized
INFO - 2023-08-19 15:27:52 --> Config Class Initialized
INFO - 2023-08-19 15:27:52 --> Loader Class Initialized
INFO - 2023-08-19 15:27:52 --> Helper loaded: url_helper
INFO - 2023-08-19 15:27:52 --> Helper loaded: file_helper
INFO - 2023-08-19 15:27:52 --> Helper loaded: form_helper
INFO - 2023-08-19 15:27:52 --> Helper loaded: my_helper
INFO - 2023-08-19 15:27:52 --> Database Driver Class Initialized
INFO - 2023-08-19 15:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:27:52 --> Controller Class Initialized
DEBUG - 2023-08-19 15:27:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-08-19 15:27:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:27:52 --> Final output sent to browser
DEBUG - 2023-08-19 15:27:52 --> Total execution time: 0.0314
INFO - 2023-08-19 15:27:53 --> Config Class Initialized
INFO - 2023-08-19 15:27:53 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:27:53 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:27:53 --> Utf8 Class Initialized
INFO - 2023-08-19 15:27:53 --> URI Class Initialized
INFO - 2023-08-19 15:27:53 --> Router Class Initialized
INFO - 2023-08-19 15:27:53 --> Output Class Initialized
INFO - 2023-08-19 15:27:53 --> Security Class Initialized
DEBUG - 2023-08-19 15:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:27:53 --> Input Class Initialized
INFO - 2023-08-19 15:27:53 --> Language Class Initialized
INFO - 2023-08-19 15:27:53 --> Language Class Initialized
INFO - 2023-08-19 15:27:53 --> Config Class Initialized
INFO - 2023-08-19 15:27:53 --> Loader Class Initialized
INFO - 2023-08-19 15:27:53 --> Helper loaded: url_helper
INFO - 2023-08-19 15:27:53 --> Helper loaded: file_helper
INFO - 2023-08-19 15:27:53 --> Helper loaded: form_helper
INFO - 2023-08-19 15:27:53 --> Helper loaded: my_helper
INFO - 2023-08-19 15:27:53 --> Database Driver Class Initialized
INFO - 2023-08-19 15:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:27:53 --> Controller Class Initialized
INFO - 2023-08-19 15:29:10 --> Config Class Initialized
INFO - 2023-08-19 15:29:10 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:29:10 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:29:10 --> Utf8 Class Initialized
INFO - 2023-08-19 15:29:10 --> URI Class Initialized
DEBUG - 2023-08-19 15:29:10 --> No URI present. Default controller set.
INFO - 2023-08-19 15:29:10 --> Router Class Initialized
INFO - 2023-08-19 15:29:10 --> Output Class Initialized
INFO - 2023-08-19 15:29:10 --> Security Class Initialized
DEBUG - 2023-08-19 15:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:29:10 --> Input Class Initialized
INFO - 2023-08-19 15:29:10 --> Language Class Initialized
INFO - 2023-08-19 15:29:10 --> Language Class Initialized
INFO - 2023-08-19 15:29:10 --> Config Class Initialized
INFO - 2023-08-19 15:29:10 --> Loader Class Initialized
INFO - 2023-08-19 15:29:10 --> Helper loaded: url_helper
INFO - 2023-08-19 15:29:10 --> Helper loaded: file_helper
INFO - 2023-08-19 15:29:10 --> Helper loaded: form_helper
INFO - 2023-08-19 15:29:10 --> Helper loaded: my_helper
INFO - 2023-08-19 15:29:10 --> Database Driver Class Initialized
INFO - 2023-08-19 15:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:29:10 --> Controller Class Initialized
INFO - 2023-08-19 15:29:10 --> Config Class Initialized
INFO - 2023-08-19 15:29:10 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:29:10 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:29:10 --> Utf8 Class Initialized
INFO - 2023-08-19 15:29:10 --> URI Class Initialized
INFO - 2023-08-19 15:29:10 --> Router Class Initialized
INFO - 2023-08-19 15:29:10 --> Output Class Initialized
INFO - 2023-08-19 15:29:10 --> Security Class Initialized
DEBUG - 2023-08-19 15:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:29:10 --> Input Class Initialized
INFO - 2023-08-19 15:29:10 --> Language Class Initialized
INFO - 2023-08-19 15:29:10 --> Language Class Initialized
INFO - 2023-08-19 15:29:10 --> Config Class Initialized
INFO - 2023-08-19 15:29:10 --> Loader Class Initialized
INFO - 2023-08-19 15:29:10 --> Helper loaded: url_helper
INFO - 2023-08-19 15:29:10 --> Helper loaded: file_helper
INFO - 2023-08-19 15:29:10 --> Helper loaded: form_helper
INFO - 2023-08-19 15:29:10 --> Helper loaded: my_helper
INFO - 2023-08-19 15:29:10 --> Database Driver Class Initialized
INFO - 2023-08-19 15:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:29:10 --> Controller Class Initialized
DEBUG - 2023-08-19 15:29:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-08-19 15:29:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:29:10 --> Final output sent to browser
DEBUG - 2023-08-19 15:29:10 --> Total execution time: 0.0342
INFO - 2023-08-19 15:31:43 --> Config Class Initialized
INFO - 2023-08-19 15:31:43 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:31:43 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:31:43 --> Utf8 Class Initialized
INFO - 2023-08-19 15:31:43 --> URI Class Initialized
INFO - 2023-08-19 15:31:43 --> Router Class Initialized
INFO - 2023-08-19 15:31:43 --> Output Class Initialized
INFO - 2023-08-19 15:31:43 --> Security Class Initialized
DEBUG - 2023-08-19 15:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:31:43 --> Input Class Initialized
INFO - 2023-08-19 15:31:43 --> Language Class Initialized
INFO - 2023-08-19 15:31:43 --> Language Class Initialized
INFO - 2023-08-19 15:31:43 --> Config Class Initialized
INFO - 2023-08-19 15:31:43 --> Loader Class Initialized
INFO - 2023-08-19 15:31:43 --> Helper loaded: url_helper
INFO - 2023-08-19 15:31:43 --> Helper loaded: file_helper
INFO - 2023-08-19 15:31:43 --> Helper loaded: form_helper
INFO - 2023-08-19 15:31:43 --> Helper loaded: my_helper
INFO - 2023-08-19 15:31:43 --> Database Driver Class Initialized
INFO - 2023-08-19 15:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:31:43 --> Controller Class Initialized
DEBUG - 2023-08-19 15:31:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 15:31:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:31:43 --> Final output sent to browser
DEBUG - 2023-08-19 15:31:43 --> Total execution time: 0.0446
INFO - 2023-08-19 15:33:11 --> Config Class Initialized
INFO - 2023-08-19 15:33:11 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:33:11 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:33:11 --> Utf8 Class Initialized
INFO - 2023-08-19 15:33:11 --> URI Class Initialized
DEBUG - 2023-08-19 15:33:11 --> No URI present. Default controller set.
INFO - 2023-08-19 15:33:11 --> Router Class Initialized
INFO - 2023-08-19 15:33:11 --> Output Class Initialized
INFO - 2023-08-19 15:33:11 --> Security Class Initialized
DEBUG - 2023-08-19 15:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:33:11 --> Input Class Initialized
INFO - 2023-08-19 15:33:11 --> Language Class Initialized
INFO - 2023-08-19 15:33:11 --> Language Class Initialized
INFO - 2023-08-19 15:33:11 --> Config Class Initialized
INFO - 2023-08-19 15:33:11 --> Loader Class Initialized
INFO - 2023-08-19 15:33:11 --> Helper loaded: url_helper
INFO - 2023-08-19 15:33:11 --> Helper loaded: file_helper
INFO - 2023-08-19 15:33:11 --> Helper loaded: form_helper
INFO - 2023-08-19 15:33:11 --> Helper loaded: my_helper
INFO - 2023-08-19 15:33:11 --> Database Driver Class Initialized
INFO - 2023-08-19 15:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:33:11 --> Controller Class Initialized
DEBUG - 2023-08-19 15:33:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 15:33:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:33:11 --> Final output sent to browser
DEBUG - 2023-08-19 15:33:11 --> Total execution time: 0.0666
INFO - 2023-08-19 15:33:15 --> Config Class Initialized
INFO - 2023-08-19 15:33:15 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:33:15 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:33:15 --> Utf8 Class Initialized
INFO - 2023-08-19 15:33:15 --> URI Class Initialized
INFO - 2023-08-19 15:33:15 --> Router Class Initialized
INFO - 2023-08-19 15:33:15 --> Output Class Initialized
INFO - 2023-08-19 15:33:15 --> Security Class Initialized
DEBUG - 2023-08-19 15:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:33:15 --> Input Class Initialized
INFO - 2023-08-19 15:33:15 --> Language Class Initialized
INFO - 2023-08-19 15:33:15 --> Language Class Initialized
INFO - 2023-08-19 15:33:15 --> Config Class Initialized
INFO - 2023-08-19 15:33:15 --> Loader Class Initialized
INFO - 2023-08-19 15:33:15 --> Helper loaded: url_helper
INFO - 2023-08-19 15:33:15 --> Helper loaded: file_helper
INFO - 2023-08-19 15:33:15 --> Helper loaded: form_helper
INFO - 2023-08-19 15:33:15 --> Helper loaded: my_helper
INFO - 2023-08-19 15:33:15 --> Database Driver Class Initialized
INFO - 2023-08-19 15:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:33:15 --> Controller Class Initialized
DEBUG - 2023-08-19 15:33:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 15:33:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:33:15 --> Final output sent to browser
DEBUG - 2023-08-19 15:33:15 --> Total execution time: 0.0833
INFO - 2023-08-19 15:33:20 --> Config Class Initialized
INFO - 2023-08-19 15:33:20 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:33:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:33:20 --> Utf8 Class Initialized
INFO - 2023-08-19 15:33:20 --> URI Class Initialized
INFO - 2023-08-19 15:33:20 --> Router Class Initialized
INFO - 2023-08-19 15:33:20 --> Output Class Initialized
INFO - 2023-08-19 15:33:20 --> Security Class Initialized
DEBUG - 2023-08-19 15:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:33:20 --> Input Class Initialized
INFO - 2023-08-19 15:33:20 --> Language Class Initialized
INFO - 2023-08-19 15:33:20 --> Language Class Initialized
INFO - 2023-08-19 15:33:20 --> Config Class Initialized
INFO - 2023-08-19 15:33:20 --> Loader Class Initialized
INFO - 2023-08-19 15:33:20 --> Helper loaded: url_helper
INFO - 2023-08-19 15:33:20 --> Helper loaded: file_helper
INFO - 2023-08-19 15:33:20 --> Helper loaded: form_helper
INFO - 2023-08-19 15:33:20 --> Helper loaded: my_helper
INFO - 2023-08-19 15:33:20 --> Database Driver Class Initialized
INFO - 2023-08-19 15:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:33:20 --> Controller Class Initialized
DEBUG - 2023-08-19 15:33:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-08-19 15:33:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:33:20 --> Final output sent to browser
DEBUG - 2023-08-19 15:33:20 --> Total execution time: 0.0413
INFO - 2023-08-19 15:33:20 --> Config Class Initialized
INFO - 2023-08-19 15:33:20 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:33:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:33:20 --> Utf8 Class Initialized
INFO - 2023-08-19 15:33:20 --> URI Class Initialized
INFO - 2023-08-19 15:33:20 --> Router Class Initialized
INFO - 2023-08-19 15:33:20 --> Output Class Initialized
INFO - 2023-08-19 15:33:20 --> Security Class Initialized
DEBUG - 2023-08-19 15:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:33:20 --> Input Class Initialized
INFO - 2023-08-19 15:33:20 --> Language Class Initialized
INFO - 2023-08-19 15:33:20 --> Language Class Initialized
INFO - 2023-08-19 15:33:20 --> Config Class Initialized
INFO - 2023-08-19 15:33:20 --> Loader Class Initialized
INFO - 2023-08-19 15:33:20 --> Helper loaded: url_helper
INFO - 2023-08-19 15:33:20 --> Helper loaded: file_helper
INFO - 2023-08-19 15:33:20 --> Helper loaded: form_helper
INFO - 2023-08-19 15:33:20 --> Helper loaded: my_helper
INFO - 2023-08-19 15:33:20 --> Database Driver Class Initialized
INFO - 2023-08-19 15:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:33:20 --> Controller Class Initialized
INFO - 2023-08-19 15:34:17 --> Config Class Initialized
INFO - 2023-08-19 15:34:17 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:34:17 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:34:17 --> Utf8 Class Initialized
INFO - 2023-08-19 15:34:17 --> URI Class Initialized
INFO - 2023-08-19 15:34:17 --> Router Class Initialized
INFO - 2023-08-19 15:34:17 --> Output Class Initialized
INFO - 2023-08-19 15:34:17 --> Security Class Initialized
DEBUG - 2023-08-19 15:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:34:17 --> Input Class Initialized
INFO - 2023-08-19 15:34:17 --> Language Class Initialized
INFO - 2023-08-19 15:34:17 --> Language Class Initialized
INFO - 2023-08-19 15:34:17 --> Config Class Initialized
INFO - 2023-08-19 15:34:17 --> Loader Class Initialized
INFO - 2023-08-19 15:34:17 --> Helper loaded: url_helper
INFO - 2023-08-19 15:34:17 --> Helper loaded: file_helper
INFO - 2023-08-19 15:34:17 --> Helper loaded: form_helper
INFO - 2023-08-19 15:34:17 --> Helper loaded: my_helper
INFO - 2023-08-19 15:34:17 --> Database Driver Class Initialized
INFO - 2023-08-19 15:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:34:17 --> Controller Class Initialized
INFO - 2023-08-19 15:34:17 --> Final output sent to browser
DEBUG - 2023-08-19 15:34:17 --> Total execution time: 0.0311
INFO - 2023-08-19 15:34:22 --> Config Class Initialized
INFO - 2023-08-19 15:34:22 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:34:22 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:34:22 --> Utf8 Class Initialized
INFO - 2023-08-19 15:34:22 --> URI Class Initialized
INFO - 2023-08-19 15:34:22 --> Router Class Initialized
INFO - 2023-08-19 15:34:22 --> Output Class Initialized
INFO - 2023-08-19 15:34:22 --> Security Class Initialized
DEBUG - 2023-08-19 15:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:34:22 --> Input Class Initialized
INFO - 2023-08-19 15:34:22 --> Language Class Initialized
INFO - 2023-08-19 15:34:22 --> Language Class Initialized
INFO - 2023-08-19 15:34:22 --> Config Class Initialized
INFO - 2023-08-19 15:34:22 --> Loader Class Initialized
INFO - 2023-08-19 15:34:22 --> Helper loaded: url_helper
INFO - 2023-08-19 15:34:22 --> Helper loaded: file_helper
INFO - 2023-08-19 15:34:22 --> Helper loaded: form_helper
INFO - 2023-08-19 15:34:22 --> Helper loaded: my_helper
INFO - 2023-08-19 15:34:22 --> Database Driver Class Initialized
INFO - 2023-08-19 15:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:34:22 --> Controller Class Initialized
INFO - 2023-08-19 15:34:22 --> Final output sent to browser
DEBUG - 2023-08-19 15:34:22 --> Total execution time: 0.0425
INFO - 2023-08-19 15:34:48 --> Config Class Initialized
INFO - 2023-08-19 15:34:48 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:34:48 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:34:48 --> Utf8 Class Initialized
INFO - 2023-08-19 15:34:48 --> URI Class Initialized
INFO - 2023-08-19 15:34:48 --> Router Class Initialized
INFO - 2023-08-19 15:34:48 --> Output Class Initialized
INFO - 2023-08-19 15:34:48 --> Security Class Initialized
DEBUG - 2023-08-19 15:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:34:48 --> Input Class Initialized
INFO - 2023-08-19 15:34:48 --> Language Class Initialized
INFO - 2023-08-19 15:34:48 --> Language Class Initialized
INFO - 2023-08-19 15:34:48 --> Config Class Initialized
INFO - 2023-08-19 15:34:48 --> Loader Class Initialized
INFO - 2023-08-19 15:34:48 --> Helper loaded: url_helper
INFO - 2023-08-19 15:34:48 --> Helper loaded: file_helper
INFO - 2023-08-19 15:34:48 --> Helper loaded: form_helper
INFO - 2023-08-19 15:34:48 --> Helper loaded: my_helper
INFO - 2023-08-19 15:34:48 --> Database Driver Class Initialized
INFO - 2023-08-19 15:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:34:48 --> Controller Class Initialized
DEBUG - 2023-08-19 15:34:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-08-19 15:34:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:34:48 --> Final output sent to browser
DEBUG - 2023-08-19 15:34:48 --> Total execution time: 0.0287
INFO - 2023-08-19 15:35:06 --> Config Class Initialized
INFO - 2023-08-19 15:35:06 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:35:06 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:35:06 --> Utf8 Class Initialized
INFO - 2023-08-19 15:35:06 --> URI Class Initialized
INFO - 2023-08-19 15:35:06 --> Router Class Initialized
INFO - 2023-08-19 15:35:06 --> Output Class Initialized
INFO - 2023-08-19 15:35:06 --> Security Class Initialized
DEBUG - 2023-08-19 15:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:35:06 --> Input Class Initialized
INFO - 2023-08-19 15:35:06 --> Language Class Initialized
INFO - 2023-08-19 15:35:06 --> Language Class Initialized
INFO - 2023-08-19 15:35:06 --> Config Class Initialized
INFO - 2023-08-19 15:35:06 --> Loader Class Initialized
INFO - 2023-08-19 15:35:06 --> Helper loaded: url_helper
INFO - 2023-08-19 15:35:06 --> Helper loaded: file_helper
INFO - 2023-08-19 15:35:06 --> Helper loaded: form_helper
INFO - 2023-08-19 15:35:06 --> Helper loaded: my_helper
INFO - 2023-08-19 15:35:06 --> Database Driver Class Initialized
INFO - 2023-08-19 15:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:35:06 --> Controller Class Initialized
INFO - 2023-08-19 15:35:06 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:35:06 --> Final output sent to browser
DEBUG - 2023-08-19 15:35:06 --> Total execution time: 0.0816
INFO - 2023-08-19 15:35:06 --> Config Class Initialized
INFO - 2023-08-19 15:35:06 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:35:06 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:35:06 --> Utf8 Class Initialized
INFO - 2023-08-19 15:35:06 --> URI Class Initialized
INFO - 2023-08-19 15:35:06 --> Router Class Initialized
INFO - 2023-08-19 15:35:06 --> Output Class Initialized
INFO - 2023-08-19 15:35:06 --> Security Class Initialized
DEBUG - 2023-08-19 15:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:35:06 --> Input Class Initialized
INFO - 2023-08-19 15:35:06 --> Language Class Initialized
INFO - 2023-08-19 15:35:06 --> Language Class Initialized
INFO - 2023-08-19 15:35:06 --> Config Class Initialized
INFO - 2023-08-19 15:35:06 --> Loader Class Initialized
INFO - 2023-08-19 15:35:06 --> Helper loaded: url_helper
INFO - 2023-08-19 15:35:06 --> Helper loaded: file_helper
INFO - 2023-08-19 15:35:06 --> Helper loaded: form_helper
INFO - 2023-08-19 15:35:06 --> Helper loaded: my_helper
INFO - 2023-08-19 15:35:06 --> Database Driver Class Initialized
INFO - 2023-08-19 15:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:35:06 --> Controller Class Initialized
DEBUG - 2023-08-19 15:35:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 15:35:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:35:06 --> Final output sent to browser
DEBUG - 2023-08-19 15:35:06 --> Total execution time: 0.0754
INFO - 2023-08-19 15:35:15 --> Config Class Initialized
INFO - 2023-08-19 15:35:15 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:35:15 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:35:15 --> Utf8 Class Initialized
INFO - 2023-08-19 15:35:15 --> URI Class Initialized
INFO - 2023-08-19 15:35:15 --> Router Class Initialized
INFO - 2023-08-19 15:35:15 --> Output Class Initialized
INFO - 2023-08-19 15:35:15 --> Security Class Initialized
DEBUG - 2023-08-19 15:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:35:15 --> Input Class Initialized
INFO - 2023-08-19 15:35:15 --> Language Class Initialized
INFO - 2023-08-19 15:35:15 --> Language Class Initialized
INFO - 2023-08-19 15:35:15 --> Config Class Initialized
INFO - 2023-08-19 15:35:15 --> Loader Class Initialized
INFO - 2023-08-19 15:35:15 --> Helper loaded: url_helper
INFO - 2023-08-19 15:35:15 --> Helper loaded: file_helper
INFO - 2023-08-19 15:35:15 --> Helper loaded: form_helper
INFO - 2023-08-19 15:35:15 --> Helper loaded: my_helper
INFO - 2023-08-19 15:35:15 --> Database Driver Class Initialized
INFO - 2023-08-19 15:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:35:15 --> Controller Class Initialized
DEBUG - 2023-08-19 15:35:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 15:35:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:35:15 --> Final output sent to browser
DEBUG - 2023-08-19 15:35:15 --> Total execution time: 0.0308
INFO - 2023-08-19 15:35:21 --> Config Class Initialized
INFO - 2023-08-19 15:35:21 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:35:21 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:35:21 --> Utf8 Class Initialized
INFO - 2023-08-19 15:35:21 --> URI Class Initialized
INFO - 2023-08-19 15:35:21 --> Router Class Initialized
INFO - 2023-08-19 15:35:21 --> Output Class Initialized
INFO - 2023-08-19 15:35:21 --> Security Class Initialized
DEBUG - 2023-08-19 15:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:35:21 --> Input Class Initialized
INFO - 2023-08-19 15:35:21 --> Language Class Initialized
INFO - 2023-08-19 15:35:21 --> Language Class Initialized
INFO - 2023-08-19 15:35:21 --> Config Class Initialized
INFO - 2023-08-19 15:35:21 --> Loader Class Initialized
INFO - 2023-08-19 15:35:21 --> Helper loaded: url_helper
INFO - 2023-08-19 15:35:21 --> Helper loaded: file_helper
INFO - 2023-08-19 15:35:21 --> Helper loaded: form_helper
INFO - 2023-08-19 15:35:21 --> Helper loaded: my_helper
INFO - 2023-08-19 15:35:21 --> Database Driver Class Initialized
INFO - 2023-08-19 15:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:35:21 --> Controller Class Initialized
DEBUG - 2023-08-19 15:35:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-08-19 15:35:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:35:21 --> Final output sent to browser
DEBUG - 2023-08-19 15:35:21 --> Total execution time: 0.0323
INFO - 2023-08-19 15:35:21 --> Config Class Initialized
INFO - 2023-08-19 15:35:21 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:35:21 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:35:21 --> Utf8 Class Initialized
INFO - 2023-08-19 15:35:21 --> URI Class Initialized
INFO - 2023-08-19 15:35:21 --> Router Class Initialized
INFO - 2023-08-19 15:35:21 --> Output Class Initialized
INFO - 2023-08-19 15:35:21 --> Security Class Initialized
DEBUG - 2023-08-19 15:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:35:21 --> Input Class Initialized
INFO - 2023-08-19 15:35:21 --> Language Class Initialized
INFO - 2023-08-19 15:35:21 --> Language Class Initialized
INFO - 2023-08-19 15:35:21 --> Config Class Initialized
INFO - 2023-08-19 15:35:21 --> Loader Class Initialized
INFO - 2023-08-19 15:35:21 --> Helper loaded: url_helper
INFO - 2023-08-19 15:35:21 --> Helper loaded: file_helper
INFO - 2023-08-19 15:35:21 --> Helper loaded: form_helper
INFO - 2023-08-19 15:35:21 --> Helper loaded: my_helper
INFO - 2023-08-19 15:35:21 --> Database Driver Class Initialized
INFO - 2023-08-19 15:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:35:21 --> Controller Class Initialized
INFO - 2023-08-19 15:35:40 --> Config Class Initialized
INFO - 2023-08-19 15:35:40 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:35:40 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:35:40 --> Utf8 Class Initialized
INFO - 2023-08-19 15:35:40 --> URI Class Initialized
INFO - 2023-08-19 15:35:40 --> Router Class Initialized
INFO - 2023-08-19 15:35:40 --> Output Class Initialized
INFO - 2023-08-19 15:35:40 --> Security Class Initialized
DEBUG - 2023-08-19 15:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:35:40 --> Input Class Initialized
INFO - 2023-08-19 15:35:40 --> Language Class Initialized
INFO - 2023-08-19 15:35:40 --> Language Class Initialized
INFO - 2023-08-19 15:35:40 --> Config Class Initialized
INFO - 2023-08-19 15:35:40 --> Loader Class Initialized
INFO - 2023-08-19 15:35:40 --> Helper loaded: url_helper
INFO - 2023-08-19 15:35:40 --> Helper loaded: file_helper
INFO - 2023-08-19 15:35:40 --> Helper loaded: form_helper
INFO - 2023-08-19 15:35:40 --> Helper loaded: my_helper
INFO - 2023-08-19 15:35:40 --> Database Driver Class Initialized
INFO - 2023-08-19 15:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:35:40 --> Controller Class Initialized
INFO - 2023-08-19 15:35:40 --> Final output sent to browser
DEBUG - 2023-08-19 15:35:40 --> Total execution time: 0.0974
INFO - 2023-08-19 15:37:02 --> Config Class Initialized
INFO - 2023-08-19 15:37:02 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:37:02 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:37:02 --> Utf8 Class Initialized
INFO - 2023-08-19 15:37:02 --> URI Class Initialized
INFO - 2023-08-19 15:37:02 --> Router Class Initialized
INFO - 2023-08-19 15:37:02 --> Output Class Initialized
INFO - 2023-08-19 15:37:02 --> Security Class Initialized
DEBUG - 2023-08-19 15:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:37:02 --> Input Class Initialized
INFO - 2023-08-19 15:37:02 --> Language Class Initialized
INFO - 2023-08-19 15:37:02 --> Language Class Initialized
INFO - 2023-08-19 15:37:02 --> Config Class Initialized
INFO - 2023-08-19 15:37:02 --> Loader Class Initialized
INFO - 2023-08-19 15:37:02 --> Helper loaded: url_helper
INFO - 2023-08-19 15:37:02 --> Helper loaded: file_helper
INFO - 2023-08-19 15:37:02 --> Helper loaded: form_helper
INFO - 2023-08-19 15:37:02 --> Helper loaded: my_helper
INFO - 2023-08-19 15:37:02 --> Database Driver Class Initialized
INFO - 2023-08-19 15:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:37:02 --> Controller Class Initialized
DEBUG - 2023-08-19 15:37:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-08-19 15:37:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:37:02 --> Final output sent to browser
DEBUG - 2023-08-19 15:37:02 --> Total execution time: 0.0365
INFO - 2023-08-19 15:37:42 --> Config Class Initialized
INFO - 2023-08-19 15:37:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:37:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:37:42 --> Utf8 Class Initialized
INFO - 2023-08-19 15:37:42 --> URI Class Initialized
INFO - 2023-08-19 15:37:42 --> Router Class Initialized
INFO - 2023-08-19 15:37:42 --> Output Class Initialized
INFO - 2023-08-19 15:37:42 --> Security Class Initialized
DEBUG - 2023-08-19 15:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:37:42 --> Input Class Initialized
INFO - 2023-08-19 15:37:42 --> Language Class Initialized
INFO - 2023-08-19 15:37:42 --> Language Class Initialized
INFO - 2023-08-19 15:37:42 --> Config Class Initialized
INFO - 2023-08-19 15:37:42 --> Loader Class Initialized
INFO - 2023-08-19 15:37:42 --> Helper loaded: url_helper
INFO - 2023-08-19 15:37:42 --> Helper loaded: file_helper
INFO - 2023-08-19 15:37:42 --> Helper loaded: form_helper
INFO - 2023-08-19 15:37:42 --> Helper loaded: my_helper
INFO - 2023-08-19 15:37:42 --> Database Driver Class Initialized
INFO - 2023-08-19 15:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:37:42 --> Controller Class Initialized
DEBUG - 2023-08-19 15:37:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-08-19 15:37:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:37:42 --> Final output sent to browser
DEBUG - 2023-08-19 15:37:42 --> Total execution time: 0.0349
INFO - 2023-08-19 15:37:44 --> Config Class Initialized
INFO - 2023-08-19 15:37:44 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:37:44 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:37:44 --> Utf8 Class Initialized
INFO - 2023-08-19 15:37:44 --> URI Class Initialized
INFO - 2023-08-19 15:37:44 --> Router Class Initialized
INFO - 2023-08-19 15:37:44 --> Output Class Initialized
INFO - 2023-08-19 15:37:44 --> Security Class Initialized
DEBUG - 2023-08-19 15:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:37:44 --> Input Class Initialized
INFO - 2023-08-19 15:37:44 --> Language Class Initialized
INFO - 2023-08-19 15:37:44 --> Language Class Initialized
INFO - 2023-08-19 15:37:44 --> Config Class Initialized
INFO - 2023-08-19 15:37:44 --> Loader Class Initialized
INFO - 2023-08-19 15:37:44 --> Helper loaded: url_helper
INFO - 2023-08-19 15:37:44 --> Helper loaded: file_helper
INFO - 2023-08-19 15:37:44 --> Helper loaded: form_helper
INFO - 2023-08-19 15:37:44 --> Helper loaded: my_helper
INFO - 2023-08-19 15:37:44 --> Database Driver Class Initialized
INFO - 2023-08-19 15:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:37:44 --> Controller Class Initialized
INFO - 2023-08-19 15:38:46 --> Config Class Initialized
INFO - 2023-08-19 15:38:46 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:38:46 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:38:46 --> Utf8 Class Initialized
INFO - 2023-08-19 15:38:46 --> URI Class Initialized
DEBUG - 2023-08-19 15:38:46 --> No URI present. Default controller set.
INFO - 2023-08-19 15:38:46 --> Router Class Initialized
INFO - 2023-08-19 15:38:46 --> Output Class Initialized
INFO - 2023-08-19 15:38:46 --> Security Class Initialized
DEBUG - 2023-08-19 15:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:38:46 --> Input Class Initialized
INFO - 2023-08-19 15:38:46 --> Language Class Initialized
INFO - 2023-08-19 15:38:46 --> Language Class Initialized
INFO - 2023-08-19 15:38:46 --> Config Class Initialized
INFO - 2023-08-19 15:38:46 --> Loader Class Initialized
INFO - 2023-08-19 15:38:46 --> Helper loaded: url_helper
INFO - 2023-08-19 15:38:46 --> Helper loaded: file_helper
INFO - 2023-08-19 15:38:46 --> Helper loaded: form_helper
INFO - 2023-08-19 15:38:46 --> Helper loaded: my_helper
INFO - 2023-08-19 15:38:46 --> Database Driver Class Initialized
INFO - 2023-08-19 15:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:38:47 --> Controller Class Initialized
DEBUG - 2023-08-19 15:38:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 15:38:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:38:47 --> Final output sent to browser
DEBUG - 2023-08-19 15:38:47 --> Total execution time: 0.0325
INFO - 2023-08-19 15:40:06 --> Config Class Initialized
INFO - 2023-08-19 15:40:06 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:40:06 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:40:06 --> Utf8 Class Initialized
INFO - 2023-08-19 15:40:06 --> URI Class Initialized
INFO - 2023-08-19 15:40:06 --> Router Class Initialized
INFO - 2023-08-19 15:40:06 --> Output Class Initialized
INFO - 2023-08-19 15:40:06 --> Security Class Initialized
DEBUG - 2023-08-19 15:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:40:06 --> Input Class Initialized
INFO - 2023-08-19 15:40:06 --> Language Class Initialized
INFO - 2023-08-19 15:40:06 --> Language Class Initialized
INFO - 2023-08-19 15:40:06 --> Config Class Initialized
INFO - 2023-08-19 15:40:06 --> Loader Class Initialized
INFO - 2023-08-19 15:40:06 --> Helper loaded: url_helper
INFO - 2023-08-19 15:40:06 --> Helper loaded: file_helper
INFO - 2023-08-19 15:40:06 --> Helper loaded: form_helper
INFO - 2023-08-19 15:40:06 --> Helper loaded: my_helper
INFO - 2023-08-19 15:40:06 --> Database Driver Class Initialized
INFO - 2023-08-19 15:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:40:06 --> Controller Class Initialized
INFO - 2023-08-19 15:40:06 --> Final output sent to browser
DEBUG - 2023-08-19 15:40:06 --> Total execution time: 0.0351
INFO - 2023-08-19 15:40:09 --> Config Class Initialized
INFO - 2023-08-19 15:40:09 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:40:09 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:40:09 --> Utf8 Class Initialized
INFO - 2023-08-19 15:40:09 --> URI Class Initialized
INFO - 2023-08-19 15:40:09 --> Router Class Initialized
INFO - 2023-08-19 15:40:09 --> Output Class Initialized
INFO - 2023-08-19 15:40:09 --> Security Class Initialized
DEBUG - 2023-08-19 15:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:40:09 --> Input Class Initialized
INFO - 2023-08-19 15:40:09 --> Language Class Initialized
INFO - 2023-08-19 15:40:09 --> Language Class Initialized
INFO - 2023-08-19 15:40:09 --> Config Class Initialized
INFO - 2023-08-19 15:40:09 --> Loader Class Initialized
INFO - 2023-08-19 15:40:09 --> Helper loaded: url_helper
INFO - 2023-08-19 15:40:09 --> Helper loaded: file_helper
INFO - 2023-08-19 15:40:09 --> Helper loaded: form_helper
INFO - 2023-08-19 15:40:09 --> Helper loaded: my_helper
INFO - 2023-08-19 15:40:09 --> Database Driver Class Initialized
INFO - 2023-08-19 15:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:40:09 --> Controller Class Initialized
INFO - 2023-08-19 15:40:09 --> Final output sent to browser
DEBUG - 2023-08-19 15:40:09 --> Total execution time: 0.0991
INFO - 2023-08-19 15:40:56 --> Config Class Initialized
INFO - 2023-08-19 15:40:56 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:40:56 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:40:56 --> Utf8 Class Initialized
INFO - 2023-08-19 15:40:56 --> URI Class Initialized
INFO - 2023-08-19 15:40:56 --> Router Class Initialized
INFO - 2023-08-19 15:40:56 --> Output Class Initialized
INFO - 2023-08-19 15:40:56 --> Security Class Initialized
DEBUG - 2023-08-19 15:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:40:56 --> Input Class Initialized
INFO - 2023-08-19 15:40:56 --> Language Class Initialized
INFO - 2023-08-19 15:40:56 --> Language Class Initialized
INFO - 2023-08-19 15:40:56 --> Config Class Initialized
INFO - 2023-08-19 15:40:56 --> Loader Class Initialized
INFO - 2023-08-19 15:40:56 --> Helper loaded: url_helper
INFO - 2023-08-19 15:40:56 --> Helper loaded: file_helper
INFO - 2023-08-19 15:40:56 --> Helper loaded: form_helper
INFO - 2023-08-19 15:40:56 --> Helper loaded: my_helper
INFO - 2023-08-19 15:40:56 --> Database Driver Class Initialized
INFO - 2023-08-19 15:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:40:56 --> Controller Class Initialized
INFO - 2023-08-19 15:40:56 --> Config Class Initialized
INFO - 2023-08-19 15:40:56 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:40:56 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:40:56 --> Utf8 Class Initialized
INFO - 2023-08-19 15:40:56 --> URI Class Initialized
INFO - 2023-08-19 15:40:56 --> Router Class Initialized
INFO - 2023-08-19 15:40:56 --> Output Class Initialized
INFO - 2023-08-19 15:40:56 --> Security Class Initialized
DEBUG - 2023-08-19 15:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:40:56 --> Input Class Initialized
INFO - 2023-08-19 15:40:56 --> Language Class Initialized
INFO - 2023-08-19 15:40:56 --> Language Class Initialized
INFO - 2023-08-19 15:40:56 --> Config Class Initialized
INFO - 2023-08-19 15:40:56 --> Loader Class Initialized
INFO - 2023-08-19 15:40:56 --> Helper loaded: url_helper
INFO - 2023-08-19 15:40:56 --> Helper loaded: file_helper
INFO - 2023-08-19 15:40:56 --> Helper loaded: form_helper
INFO - 2023-08-19 15:40:56 --> Helper loaded: my_helper
INFO - 2023-08-19 15:40:56 --> Database Driver Class Initialized
INFO - 2023-08-19 15:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:40:56 --> Controller Class Initialized
DEBUG - 2023-08-19 15:40:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-08-19 15:40:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:40:56 --> Final output sent to browser
DEBUG - 2023-08-19 15:40:56 --> Total execution time: 0.0285
INFO - 2023-08-19 15:41:00 --> Config Class Initialized
INFO - 2023-08-19 15:41:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:41:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:41:00 --> Utf8 Class Initialized
INFO - 2023-08-19 15:41:00 --> URI Class Initialized
INFO - 2023-08-19 15:41:00 --> Router Class Initialized
INFO - 2023-08-19 15:41:00 --> Output Class Initialized
INFO - 2023-08-19 15:41:00 --> Security Class Initialized
DEBUG - 2023-08-19 15:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:41:00 --> Input Class Initialized
INFO - 2023-08-19 15:41:00 --> Language Class Initialized
INFO - 2023-08-19 15:41:00 --> Language Class Initialized
INFO - 2023-08-19 15:41:00 --> Config Class Initialized
INFO - 2023-08-19 15:41:00 --> Loader Class Initialized
INFO - 2023-08-19 15:41:00 --> Helper loaded: url_helper
INFO - 2023-08-19 15:41:00 --> Helper loaded: file_helper
INFO - 2023-08-19 15:41:00 --> Helper loaded: form_helper
INFO - 2023-08-19 15:41:00 --> Helper loaded: my_helper
INFO - 2023-08-19 15:41:00 --> Database Driver Class Initialized
INFO - 2023-08-19 15:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:41:00 --> Controller Class Initialized
INFO - 2023-08-19 15:41:00 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:41:00 --> Final output sent to browser
DEBUG - 2023-08-19 15:41:00 --> Total execution time: 0.0375
INFO - 2023-08-19 15:41:00 --> Config Class Initialized
INFO - 2023-08-19 15:41:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:41:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:41:00 --> Utf8 Class Initialized
INFO - 2023-08-19 15:41:00 --> URI Class Initialized
INFO - 2023-08-19 15:41:00 --> Router Class Initialized
INFO - 2023-08-19 15:41:00 --> Output Class Initialized
INFO - 2023-08-19 15:41:00 --> Security Class Initialized
DEBUG - 2023-08-19 15:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:41:00 --> Input Class Initialized
INFO - 2023-08-19 15:41:00 --> Language Class Initialized
INFO - 2023-08-19 15:41:00 --> Language Class Initialized
INFO - 2023-08-19 15:41:00 --> Config Class Initialized
INFO - 2023-08-19 15:41:00 --> Loader Class Initialized
INFO - 2023-08-19 15:41:00 --> Helper loaded: url_helper
INFO - 2023-08-19 15:41:00 --> Helper loaded: file_helper
INFO - 2023-08-19 15:41:00 --> Helper loaded: form_helper
INFO - 2023-08-19 15:41:00 --> Helper loaded: my_helper
INFO - 2023-08-19 15:41:00 --> Database Driver Class Initialized
INFO - 2023-08-19 15:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:41:00 --> Controller Class Initialized
DEBUG - 2023-08-19 15:41:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 15:41:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:41:00 --> Final output sent to browser
DEBUG - 2023-08-19 15:41:00 --> Total execution time: 0.0368
INFO - 2023-08-19 15:41:01 --> Config Class Initialized
INFO - 2023-08-19 15:41:01 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:41:01 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:41:01 --> Utf8 Class Initialized
INFO - 2023-08-19 15:41:01 --> URI Class Initialized
INFO - 2023-08-19 15:41:01 --> Router Class Initialized
INFO - 2023-08-19 15:41:01 --> Output Class Initialized
INFO - 2023-08-19 15:41:01 --> Security Class Initialized
DEBUG - 2023-08-19 15:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:41:01 --> Input Class Initialized
INFO - 2023-08-19 15:41:01 --> Language Class Initialized
INFO - 2023-08-19 15:41:01 --> Language Class Initialized
INFO - 2023-08-19 15:41:01 --> Config Class Initialized
INFO - 2023-08-19 15:41:01 --> Loader Class Initialized
INFO - 2023-08-19 15:41:01 --> Helper loaded: url_helper
INFO - 2023-08-19 15:41:01 --> Helper loaded: file_helper
INFO - 2023-08-19 15:41:01 --> Helper loaded: form_helper
INFO - 2023-08-19 15:41:01 --> Helper loaded: my_helper
INFO - 2023-08-19 15:41:01 --> Database Driver Class Initialized
INFO - 2023-08-19 15:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:41:01 --> Controller Class Initialized
ERROR - 2023-08-19 15:41:01 --> Severity: Notice --> Undefined index: username /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/controllers/Login.php 19
ERROR - 2023-08-19 15:41:01 --> Severity: Notice --> Undefined index: password /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/controllers/Login.php 20
INFO - 2023-08-19 15:41:01 --> Final output sent to browser
DEBUG - 2023-08-19 15:41:01 --> Total execution time: 0.0366
INFO - 2023-08-19 15:42:24 --> Config Class Initialized
INFO - 2023-08-19 15:42:24 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:42:24 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:42:24 --> Utf8 Class Initialized
INFO - 2023-08-19 15:42:24 --> URI Class Initialized
INFO - 2023-08-19 15:42:24 --> Router Class Initialized
INFO - 2023-08-19 15:42:24 --> Output Class Initialized
INFO - 2023-08-19 15:42:24 --> Security Class Initialized
DEBUG - 2023-08-19 15:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:42:24 --> Input Class Initialized
INFO - 2023-08-19 15:42:24 --> Language Class Initialized
INFO - 2023-08-19 15:42:25 --> Language Class Initialized
INFO - 2023-08-19 15:42:25 --> Config Class Initialized
INFO - 2023-08-19 15:42:25 --> Loader Class Initialized
INFO - 2023-08-19 15:42:25 --> Helper loaded: url_helper
INFO - 2023-08-19 15:42:25 --> Helper loaded: file_helper
INFO - 2023-08-19 15:42:25 --> Helper loaded: form_helper
INFO - 2023-08-19 15:42:25 --> Helper loaded: my_helper
INFO - 2023-08-19 15:42:25 --> Database Driver Class Initialized
INFO - 2023-08-19 15:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:42:25 --> Controller Class Initialized
INFO - 2023-08-19 15:42:25 --> Final output sent to browser
DEBUG - 2023-08-19 15:42:25 --> Total execution time: 0.0688
INFO - 2023-08-19 15:42:27 --> Config Class Initialized
INFO - 2023-08-19 15:42:27 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:42:27 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:42:27 --> Utf8 Class Initialized
INFO - 2023-08-19 15:42:27 --> URI Class Initialized
INFO - 2023-08-19 15:42:27 --> Router Class Initialized
INFO - 2023-08-19 15:42:27 --> Output Class Initialized
INFO - 2023-08-19 15:42:27 --> Security Class Initialized
DEBUG - 2023-08-19 15:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:42:27 --> Input Class Initialized
INFO - 2023-08-19 15:42:27 --> Language Class Initialized
INFO - 2023-08-19 15:42:27 --> Language Class Initialized
INFO - 2023-08-19 15:42:27 --> Config Class Initialized
INFO - 2023-08-19 15:42:27 --> Loader Class Initialized
INFO - 2023-08-19 15:42:27 --> Helper loaded: url_helper
INFO - 2023-08-19 15:42:27 --> Helper loaded: file_helper
INFO - 2023-08-19 15:42:27 --> Helper loaded: form_helper
INFO - 2023-08-19 15:42:27 --> Helper loaded: my_helper
INFO - 2023-08-19 15:42:27 --> Database Driver Class Initialized
INFO - 2023-08-19 15:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:42:27 --> Controller Class Initialized
INFO - 2023-08-19 15:42:27 --> Final output sent to browser
DEBUG - 2023-08-19 15:42:27 --> Total execution time: 0.0312
INFO - 2023-08-19 15:42:30 --> Config Class Initialized
INFO - 2023-08-19 15:42:30 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:42:30 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:42:30 --> Utf8 Class Initialized
INFO - 2023-08-19 15:42:30 --> URI Class Initialized
INFO - 2023-08-19 15:42:30 --> Router Class Initialized
INFO - 2023-08-19 15:42:30 --> Output Class Initialized
INFO - 2023-08-19 15:42:30 --> Security Class Initialized
DEBUG - 2023-08-19 15:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:42:30 --> Input Class Initialized
INFO - 2023-08-19 15:42:30 --> Language Class Initialized
INFO - 2023-08-19 15:42:30 --> Language Class Initialized
INFO - 2023-08-19 15:42:30 --> Config Class Initialized
INFO - 2023-08-19 15:42:30 --> Loader Class Initialized
INFO - 2023-08-19 15:42:30 --> Helper loaded: url_helper
INFO - 2023-08-19 15:42:30 --> Helper loaded: file_helper
INFO - 2023-08-19 15:42:30 --> Helper loaded: form_helper
INFO - 2023-08-19 15:42:30 --> Helper loaded: my_helper
INFO - 2023-08-19 15:42:30 --> Database Driver Class Initialized
INFO - 2023-08-19 15:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:42:30 --> Controller Class Initialized
INFO - 2023-08-19 15:42:30 --> Final output sent to browser
DEBUG - 2023-08-19 15:42:30 --> Total execution time: 0.0324
INFO - 2023-08-19 15:49:51 --> Config Class Initialized
INFO - 2023-08-19 15:49:51 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:49:51 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:49:51 --> Utf8 Class Initialized
INFO - 2023-08-19 15:49:51 --> URI Class Initialized
INFO - 2023-08-19 15:49:51 --> Router Class Initialized
INFO - 2023-08-19 15:49:51 --> Output Class Initialized
INFO - 2023-08-19 15:49:51 --> Security Class Initialized
DEBUG - 2023-08-19 15:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:49:51 --> Input Class Initialized
INFO - 2023-08-19 15:49:51 --> Language Class Initialized
INFO - 2023-08-19 15:49:51 --> Language Class Initialized
INFO - 2023-08-19 15:49:51 --> Config Class Initialized
INFO - 2023-08-19 15:49:51 --> Loader Class Initialized
INFO - 2023-08-19 15:49:51 --> Helper loaded: url_helper
INFO - 2023-08-19 15:49:51 --> Helper loaded: file_helper
INFO - 2023-08-19 15:49:51 --> Helper loaded: form_helper
INFO - 2023-08-19 15:49:51 --> Helper loaded: my_helper
INFO - 2023-08-19 15:49:51 --> Database Driver Class Initialized
INFO - 2023-08-19 15:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:49:51 --> Controller Class Initialized
DEBUG - 2023-08-19 15:49:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 15:49:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:49:51 --> Final output sent to browser
DEBUG - 2023-08-19 15:49:51 --> Total execution time: 0.0390
INFO - 2023-08-19 15:50:10 --> Config Class Initialized
INFO - 2023-08-19 15:50:10 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:50:10 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:50:10 --> Utf8 Class Initialized
INFO - 2023-08-19 15:50:10 --> URI Class Initialized
DEBUG - 2023-08-19 15:50:10 --> No URI present. Default controller set.
INFO - 2023-08-19 15:50:10 --> Router Class Initialized
INFO - 2023-08-19 15:50:10 --> Output Class Initialized
INFO - 2023-08-19 15:50:10 --> Security Class Initialized
DEBUG - 2023-08-19 15:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:50:10 --> Input Class Initialized
INFO - 2023-08-19 15:50:10 --> Language Class Initialized
INFO - 2023-08-19 15:50:10 --> Language Class Initialized
INFO - 2023-08-19 15:50:10 --> Config Class Initialized
INFO - 2023-08-19 15:50:10 --> Loader Class Initialized
INFO - 2023-08-19 15:50:10 --> Helper loaded: url_helper
INFO - 2023-08-19 15:50:10 --> Helper loaded: file_helper
INFO - 2023-08-19 15:50:10 --> Helper loaded: form_helper
INFO - 2023-08-19 15:50:10 --> Helper loaded: my_helper
INFO - 2023-08-19 15:50:10 --> Database Driver Class Initialized
INFO - 2023-08-19 15:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:50:10 --> Controller Class Initialized
DEBUG - 2023-08-19 15:50:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 15:50:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:50:10 --> Final output sent to browser
DEBUG - 2023-08-19 15:50:10 --> Total execution time: 0.0331
INFO - 2023-08-19 15:50:31 --> Config Class Initialized
INFO - 2023-08-19 15:50:31 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:50:31 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:50:31 --> Utf8 Class Initialized
INFO - 2023-08-19 15:50:31 --> URI Class Initialized
INFO - 2023-08-19 15:50:31 --> Router Class Initialized
INFO - 2023-08-19 15:50:31 --> Output Class Initialized
INFO - 2023-08-19 15:50:31 --> Security Class Initialized
DEBUG - 2023-08-19 15:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:50:31 --> Input Class Initialized
INFO - 2023-08-19 15:50:31 --> Language Class Initialized
INFO - 2023-08-19 15:50:31 --> Language Class Initialized
INFO - 2023-08-19 15:50:31 --> Config Class Initialized
INFO - 2023-08-19 15:50:31 --> Loader Class Initialized
INFO - 2023-08-19 15:50:31 --> Helper loaded: url_helper
INFO - 2023-08-19 15:50:31 --> Helper loaded: file_helper
INFO - 2023-08-19 15:50:31 --> Helper loaded: form_helper
INFO - 2023-08-19 15:50:31 --> Helper loaded: my_helper
INFO - 2023-08-19 15:50:31 --> Database Driver Class Initialized
INFO - 2023-08-19 15:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:50:31 --> Controller Class Initialized
DEBUG - 2023-08-19 15:50:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 15:50:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:50:31 --> Final output sent to browser
DEBUG - 2023-08-19 15:50:31 --> Total execution time: 0.0693
INFO - 2023-08-19 15:50:42 --> Config Class Initialized
INFO - 2023-08-19 15:50:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:50:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:50:42 --> Utf8 Class Initialized
INFO - 2023-08-19 15:50:42 --> URI Class Initialized
INFO - 2023-08-19 15:50:42 --> Router Class Initialized
INFO - 2023-08-19 15:50:42 --> Output Class Initialized
INFO - 2023-08-19 15:50:42 --> Security Class Initialized
DEBUG - 2023-08-19 15:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:50:42 --> Input Class Initialized
INFO - 2023-08-19 15:50:42 --> Language Class Initialized
INFO - 2023-08-19 15:50:42 --> Language Class Initialized
INFO - 2023-08-19 15:50:42 --> Config Class Initialized
INFO - 2023-08-19 15:50:42 --> Loader Class Initialized
INFO - 2023-08-19 15:50:42 --> Helper loaded: url_helper
INFO - 2023-08-19 15:50:42 --> Helper loaded: file_helper
INFO - 2023-08-19 15:50:42 --> Helper loaded: form_helper
INFO - 2023-08-19 15:50:42 --> Helper loaded: my_helper
INFO - 2023-08-19 15:50:42 --> Database Driver Class Initialized
INFO - 2023-08-19 15:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:50:42 --> Controller Class Initialized
DEBUG - 2023-08-19 15:50:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-08-19 15:50:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:50:42 --> Final output sent to browser
DEBUG - 2023-08-19 15:50:42 --> Total execution time: 0.0329
INFO - 2023-08-19 15:50:42 --> Config Class Initialized
INFO - 2023-08-19 15:50:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:50:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:50:42 --> Utf8 Class Initialized
INFO - 2023-08-19 15:50:42 --> URI Class Initialized
INFO - 2023-08-19 15:50:42 --> Router Class Initialized
INFO - 2023-08-19 15:50:42 --> Output Class Initialized
INFO - 2023-08-19 15:50:42 --> Security Class Initialized
DEBUG - 2023-08-19 15:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:50:42 --> Input Class Initialized
INFO - 2023-08-19 15:50:42 --> Language Class Initialized
INFO - 2023-08-19 15:50:42 --> Language Class Initialized
INFO - 2023-08-19 15:50:42 --> Config Class Initialized
INFO - 2023-08-19 15:50:42 --> Loader Class Initialized
INFO - 2023-08-19 15:50:42 --> Helper loaded: url_helper
INFO - 2023-08-19 15:50:42 --> Helper loaded: file_helper
INFO - 2023-08-19 15:50:42 --> Helper loaded: form_helper
INFO - 2023-08-19 15:50:42 --> Helper loaded: my_helper
INFO - 2023-08-19 15:50:42 --> Database Driver Class Initialized
INFO - 2023-08-19 15:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:50:42 --> Controller Class Initialized
INFO - 2023-08-19 15:50:42 --> Config Class Initialized
INFO - 2023-08-19 15:50:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:50:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:50:42 --> Utf8 Class Initialized
INFO - 2023-08-19 15:50:42 --> URI Class Initialized
INFO - 2023-08-19 15:50:42 --> Router Class Initialized
INFO - 2023-08-19 15:50:42 --> Output Class Initialized
INFO - 2023-08-19 15:50:42 --> Security Class Initialized
DEBUG - 2023-08-19 15:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:50:42 --> Input Class Initialized
INFO - 2023-08-19 15:50:42 --> Language Class Initialized
INFO - 2023-08-19 15:50:42 --> Language Class Initialized
INFO - 2023-08-19 15:50:42 --> Config Class Initialized
INFO - 2023-08-19 15:50:42 --> Loader Class Initialized
INFO - 2023-08-19 15:50:42 --> Helper loaded: url_helper
INFO - 2023-08-19 15:50:42 --> Helper loaded: file_helper
INFO - 2023-08-19 15:50:42 --> Helper loaded: form_helper
INFO - 2023-08-19 15:50:42 --> Helper loaded: my_helper
INFO - 2023-08-19 15:50:42 --> Database Driver Class Initialized
INFO - 2023-08-19 15:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:50:42 --> Controller Class Initialized
DEBUG - 2023-08-19 15:50:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 15:50:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:50:42 --> Final output sent to browser
DEBUG - 2023-08-19 15:50:42 --> Total execution time: 0.0419
INFO - 2023-08-19 15:50:49 --> Config Class Initialized
INFO - 2023-08-19 15:50:49 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:50:49 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:50:49 --> Utf8 Class Initialized
INFO - 2023-08-19 15:50:49 --> URI Class Initialized
INFO - 2023-08-19 15:50:49 --> Router Class Initialized
INFO - 2023-08-19 15:50:49 --> Output Class Initialized
INFO - 2023-08-19 15:50:49 --> Security Class Initialized
DEBUG - 2023-08-19 15:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:50:49 --> Input Class Initialized
INFO - 2023-08-19 15:50:49 --> Language Class Initialized
INFO - 2023-08-19 15:50:49 --> Language Class Initialized
INFO - 2023-08-19 15:50:49 --> Config Class Initialized
INFO - 2023-08-19 15:50:49 --> Loader Class Initialized
INFO - 2023-08-19 15:50:49 --> Helper loaded: url_helper
INFO - 2023-08-19 15:50:49 --> Helper loaded: file_helper
INFO - 2023-08-19 15:50:49 --> Helper loaded: form_helper
INFO - 2023-08-19 15:50:49 --> Helper loaded: my_helper
INFO - 2023-08-19 15:50:49 --> Database Driver Class Initialized
INFO - 2023-08-19 15:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:50:49 --> Controller Class Initialized
DEBUG - 2023-08-19 15:50:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-08-19 15:50:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:50:49 --> Final output sent to browser
DEBUG - 2023-08-19 15:50:49 --> Total execution time: 0.0402
INFO - 2023-08-19 15:50:49 --> Config Class Initialized
INFO - 2023-08-19 15:50:49 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:50:49 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:50:49 --> Utf8 Class Initialized
INFO - 2023-08-19 15:50:49 --> URI Class Initialized
INFO - 2023-08-19 15:50:49 --> Router Class Initialized
INFO - 2023-08-19 15:50:49 --> Output Class Initialized
INFO - 2023-08-19 15:50:49 --> Security Class Initialized
DEBUG - 2023-08-19 15:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:50:49 --> Input Class Initialized
INFO - 2023-08-19 15:50:49 --> Language Class Initialized
INFO - 2023-08-19 15:50:49 --> Language Class Initialized
INFO - 2023-08-19 15:50:49 --> Config Class Initialized
INFO - 2023-08-19 15:50:49 --> Loader Class Initialized
INFO - 2023-08-19 15:50:49 --> Helper loaded: url_helper
INFO - 2023-08-19 15:50:49 --> Helper loaded: file_helper
INFO - 2023-08-19 15:50:49 --> Helper loaded: form_helper
INFO - 2023-08-19 15:50:49 --> Helper loaded: my_helper
INFO - 2023-08-19 15:50:49 --> Database Driver Class Initialized
INFO - 2023-08-19 15:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:50:49 --> Controller Class Initialized
INFO - 2023-08-19 15:50:52 --> Config Class Initialized
INFO - 2023-08-19 15:50:52 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:50:52 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:50:52 --> Utf8 Class Initialized
INFO - 2023-08-19 15:50:52 --> URI Class Initialized
INFO - 2023-08-19 15:50:52 --> Router Class Initialized
INFO - 2023-08-19 15:50:52 --> Output Class Initialized
INFO - 2023-08-19 15:50:52 --> Security Class Initialized
DEBUG - 2023-08-19 15:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:50:52 --> Input Class Initialized
INFO - 2023-08-19 15:50:52 --> Language Class Initialized
INFO - 2023-08-19 15:50:52 --> Language Class Initialized
INFO - 2023-08-19 15:50:52 --> Config Class Initialized
INFO - 2023-08-19 15:50:52 --> Loader Class Initialized
INFO - 2023-08-19 15:50:52 --> Helper loaded: url_helper
INFO - 2023-08-19 15:50:52 --> Helper loaded: file_helper
INFO - 2023-08-19 15:50:52 --> Helper loaded: form_helper
INFO - 2023-08-19 15:50:52 --> Helper loaded: my_helper
INFO - 2023-08-19 15:50:52 --> Database Driver Class Initialized
INFO - 2023-08-19 15:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:50:52 --> Controller Class Initialized
DEBUG - 2023-08-19 15:50:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 15:50:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:50:52 --> Final output sent to browser
DEBUG - 2023-08-19 15:50:52 --> Total execution time: 0.0362
INFO - 2023-08-19 15:50:54 --> Config Class Initialized
INFO - 2023-08-19 15:50:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:50:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:50:54 --> Utf8 Class Initialized
INFO - 2023-08-19 15:50:54 --> URI Class Initialized
INFO - 2023-08-19 15:50:54 --> Router Class Initialized
INFO - 2023-08-19 15:50:54 --> Output Class Initialized
INFO - 2023-08-19 15:50:54 --> Security Class Initialized
DEBUG - 2023-08-19 15:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:50:54 --> Input Class Initialized
INFO - 2023-08-19 15:50:54 --> Language Class Initialized
INFO - 2023-08-19 15:50:54 --> Language Class Initialized
INFO - 2023-08-19 15:50:54 --> Config Class Initialized
INFO - 2023-08-19 15:50:54 --> Loader Class Initialized
INFO - 2023-08-19 15:50:54 --> Helper loaded: url_helper
INFO - 2023-08-19 15:50:54 --> Helper loaded: file_helper
INFO - 2023-08-19 15:50:54 --> Helper loaded: form_helper
INFO - 2023-08-19 15:50:54 --> Helper loaded: my_helper
INFO - 2023-08-19 15:50:54 --> Database Driver Class Initialized
INFO - 2023-08-19 15:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:50:54 --> Controller Class Initialized
DEBUG - 2023-08-19 15:50:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 15:50:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:50:54 --> Final output sent to browser
DEBUG - 2023-08-19 15:50:54 --> Total execution time: 0.0380
INFO - 2023-08-19 15:50:57 --> Config Class Initialized
INFO - 2023-08-19 15:50:57 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:50:57 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:50:57 --> Utf8 Class Initialized
INFO - 2023-08-19 15:50:57 --> URI Class Initialized
INFO - 2023-08-19 15:50:57 --> Router Class Initialized
INFO - 2023-08-19 15:50:57 --> Output Class Initialized
INFO - 2023-08-19 15:50:57 --> Security Class Initialized
DEBUG - 2023-08-19 15:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:50:57 --> Input Class Initialized
INFO - 2023-08-19 15:50:57 --> Language Class Initialized
INFO - 2023-08-19 15:50:57 --> Language Class Initialized
INFO - 2023-08-19 15:50:57 --> Config Class Initialized
INFO - 2023-08-19 15:50:57 --> Loader Class Initialized
INFO - 2023-08-19 15:50:57 --> Helper loaded: url_helper
INFO - 2023-08-19 15:50:57 --> Helper loaded: file_helper
INFO - 2023-08-19 15:50:57 --> Helper loaded: form_helper
INFO - 2023-08-19 15:50:57 --> Helper loaded: my_helper
INFO - 2023-08-19 15:50:57 --> Database Driver Class Initialized
INFO - 2023-08-19 15:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:50:57 --> Controller Class Initialized
DEBUG - 2023-08-19 15:50:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 15:50:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:50:57 --> Final output sent to browser
DEBUG - 2023-08-19 15:50:57 --> Total execution time: 0.0296
INFO - 2023-08-19 15:51:00 --> Config Class Initialized
INFO - 2023-08-19 15:51:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:51:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:51:00 --> Utf8 Class Initialized
INFO - 2023-08-19 15:51:00 --> URI Class Initialized
INFO - 2023-08-19 15:51:00 --> Router Class Initialized
INFO - 2023-08-19 15:51:00 --> Output Class Initialized
INFO - 2023-08-19 15:51:00 --> Security Class Initialized
DEBUG - 2023-08-19 15:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:51:00 --> Input Class Initialized
INFO - 2023-08-19 15:51:00 --> Language Class Initialized
INFO - 2023-08-19 15:51:00 --> Language Class Initialized
INFO - 2023-08-19 15:51:00 --> Config Class Initialized
INFO - 2023-08-19 15:51:00 --> Loader Class Initialized
INFO - 2023-08-19 15:51:00 --> Helper loaded: url_helper
INFO - 2023-08-19 15:51:00 --> Helper loaded: file_helper
INFO - 2023-08-19 15:51:00 --> Helper loaded: form_helper
INFO - 2023-08-19 15:51:00 --> Helper loaded: my_helper
INFO - 2023-08-19 15:51:00 --> Database Driver Class Initialized
INFO - 2023-08-19 15:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:51:00 --> Controller Class Initialized
INFO - 2023-08-19 15:51:00 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:51:00 --> Final output sent to browser
DEBUG - 2023-08-19 15:51:00 --> Total execution time: 0.0402
INFO - 2023-08-19 15:51:00 --> Config Class Initialized
INFO - 2023-08-19 15:51:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:51:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:51:00 --> Utf8 Class Initialized
INFO - 2023-08-19 15:51:00 --> URI Class Initialized
INFO - 2023-08-19 15:51:00 --> Router Class Initialized
INFO - 2023-08-19 15:51:00 --> Output Class Initialized
INFO - 2023-08-19 15:51:00 --> Security Class Initialized
DEBUG - 2023-08-19 15:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:51:00 --> Input Class Initialized
INFO - 2023-08-19 15:51:00 --> Language Class Initialized
INFO - 2023-08-19 15:51:00 --> Language Class Initialized
INFO - 2023-08-19 15:51:00 --> Config Class Initialized
INFO - 2023-08-19 15:51:00 --> Loader Class Initialized
INFO - 2023-08-19 15:51:00 --> Helper loaded: url_helper
INFO - 2023-08-19 15:51:00 --> Helper loaded: file_helper
INFO - 2023-08-19 15:51:00 --> Helper loaded: form_helper
INFO - 2023-08-19 15:51:00 --> Helper loaded: my_helper
INFO - 2023-08-19 15:51:00 --> Database Driver Class Initialized
INFO - 2023-08-19 15:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:51:00 --> Controller Class Initialized
DEBUG - 2023-08-19 15:51:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 15:51:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:51:00 --> Final output sent to browser
DEBUG - 2023-08-19 15:51:00 --> Total execution time: 0.0360
INFO - 2023-08-19 15:51:00 --> Config Class Initialized
INFO - 2023-08-19 15:51:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:51:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:51:00 --> Utf8 Class Initialized
INFO - 2023-08-19 15:51:00 --> URI Class Initialized
INFO - 2023-08-19 15:51:00 --> Router Class Initialized
INFO - 2023-08-19 15:51:00 --> Output Class Initialized
INFO - 2023-08-19 15:51:00 --> Security Class Initialized
DEBUG - 2023-08-19 15:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:51:00 --> Input Class Initialized
INFO - 2023-08-19 15:51:00 --> Language Class Initialized
INFO - 2023-08-19 15:51:00 --> Language Class Initialized
INFO - 2023-08-19 15:51:00 --> Config Class Initialized
INFO - 2023-08-19 15:51:00 --> Loader Class Initialized
INFO - 2023-08-19 15:51:00 --> Helper loaded: url_helper
INFO - 2023-08-19 15:51:00 --> Helper loaded: file_helper
INFO - 2023-08-19 15:51:00 --> Helper loaded: form_helper
INFO - 2023-08-19 15:51:00 --> Helper loaded: my_helper
INFO - 2023-08-19 15:51:00 --> Database Driver Class Initialized
INFO - 2023-08-19 15:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:51:00 --> Controller Class Initialized
DEBUG - 2023-08-19 15:51:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-08-19 15:51:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:51:00 --> Final output sent to browser
DEBUG - 2023-08-19 15:51:00 --> Total execution time: 0.0421
INFO - 2023-08-19 15:51:00 --> Config Class Initialized
INFO - 2023-08-19 15:51:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:51:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:51:00 --> Utf8 Class Initialized
INFO - 2023-08-19 15:51:00 --> URI Class Initialized
INFO - 2023-08-19 15:51:00 --> Router Class Initialized
INFO - 2023-08-19 15:51:00 --> Output Class Initialized
INFO - 2023-08-19 15:51:00 --> Security Class Initialized
DEBUG - 2023-08-19 15:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:51:00 --> Input Class Initialized
INFO - 2023-08-19 15:51:00 --> Language Class Initialized
INFO - 2023-08-19 15:51:00 --> Language Class Initialized
INFO - 2023-08-19 15:51:00 --> Config Class Initialized
INFO - 2023-08-19 15:51:00 --> Loader Class Initialized
INFO - 2023-08-19 15:51:00 --> Helper loaded: url_helper
INFO - 2023-08-19 15:51:00 --> Helper loaded: file_helper
INFO - 2023-08-19 15:51:00 --> Helper loaded: form_helper
INFO - 2023-08-19 15:51:00 --> Helper loaded: my_helper
INFO - 2023-08-19 15:51:00 --> Database Driver Class Initialized
INFO - 2023-08-19 15:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:51:00 --> Controller Class Initialized
INFO - 2023-08-19 15:51:22 --> Config Class Initialized
INFO - 2023-08-19 15:51:22 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:51:22 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:51:22 --> Utf8 Class Initialized
INFO - 2023-08-19 15:51:22 --> URI Class Initialized
INFO - 2023-08-19 15:51:22 --> Router Class Initialized
INFO - 2023-08-19 15:51:22 --> Output Class Initialized
INFO - 2023-08-19 15:51:22 --> Security Class Initialized
DEBUG - 2023-08-19 15:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:51:22 --> Input Class Initialized
INFO - 2023-08-19 15:51:22 --> Language Class Initialized
INFO - 2023-08-19 15:51:22 --> Language Class Initialized
INFO - 2023-08-19 15:51:22 --> Config Class Initialized
INFO - 2023-08-19 15:51:22 --> Loader Class Initialized
INFO - 2023-08-19 15:51:22 --> Helper loaded: url_helper
INFO - 2023-08-19 15:51:22 --> Helper loaded: file_helper
INFO - 2023-08-19 15:51:22 --> Helper loaded: form_helper
INFO - 2023-08-19 15:51:22 --> Helper loaded: my_helper
INFO - 2023-08-19 15:51:22 --> Database Driver Class Initialized
INFO - 2023-08-19 15:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:51:22 --> Controller Class Initialized
DEBUG - 2023-08-19 15:51:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_homeroom/views/list.php
DEBUG - 2023-08-19 15:51:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:51:22 --> Final output sent to browser
DEBUG - 2023-08-19 15:51:22 --> Total execution time: 0.0412
INFO - 2023-08-19 15:51:23 --> Config Class Initialized
INFO - 2023-08-19 15:51:23 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:51:23 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:51:23 --> Utf8 Class Initialized
INFO - 2023-08-19 15:51:23 --> URI Class Initialized
INFO - 2023-08-19 15:51:23 --> Router Class Initialized
INFO - 2023-08-19 15:51:23 --> Output Class Initialized
INFO - 2023-08-19 15:51:23 --> Security Class Initialized
DEBUG - 2023-08-19 15:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:51:23 --> Input Class Initialized
INFO - 2023-08-19 15:51:23 --> Language Class Initialized
INFO - 2023-08-19 15:51:23 --> Language Class Initialized
INFO - 2023-08-19 15:51:23 --> Config Class Initialized
INFO - 2023-08-19 15:51:23 --> Loader Class Initialized
INFO - 2023-08-19 15:51:23 --> Helper loaded: url_helper
INFO - 2023-08-19 15:51:23 --> Helper loaded: file_helper
INFO - 2023-08-19 15:51:23 --> Helper loaded: form_helper
INFO - 2023-08-19 15:51:23 --> Helper loaded: my_helper
INFO - 2023-08-19 15:51:23 --> Database Driver Class Initialized
INFO - 2023-08-19 15:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:51:23 --> Controller Class Initialized
INFO - 2023-08-19 15:51:23 --> Final output sent to browser
DEBUG - 2023-08-19 15:51:23 --> Total execution time: 0.0287
INFO - 2023-08-19 15:51:28 --> Config Class Initialized
INFO - 2023-08-19 15:51:28 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:51:28 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:51:28 --> Utf8 Class Initialized
INFO - 2023-08-19 15:51:28 --> URI Class Initialized
INFO - 2023-08-19 15:51:28 --> Router Class Initialized
INFO - 2023-08-19 15:51:28 --> Output Class Initialized
INFO - 2023-08-19 15:51:28 --> Security Class Initialized
DEBUG - 2023-08-19 15:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:51:28 --> Input Class Initialized
INFO - 2023-08-19 15:51:28 --> Language Class Initialized
INFO - 2023-08-19 15:51:28 --> Language Class Initialized
INFO - 2023-08-19 15:51:28 --> Config Class Initialized
INFO - 2023-08-19 15:51:28 --> Loader Class Initialized
INFO - 2023-08-19 15:51:28 --> Helper loaded: url_helper
INFO - 2023-08-19 15:51:28 --> Helper loaded: file_helper
INFO - 2023-08-19 15:51:28 --> Helper loaded: form_helper
INFO - 2023-08-19 15:51:28 --> Helper loaded: my_helper
INFO - 2023-08-19 15:51:28 --> Database Driver Class Initialized
INFO - 2023-08-19 15:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:51:28 --> Controller Class Initialized
DEBUG - 2023-08-19 15:51:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan/views/list.php
DEBUG - 2023-08-19 15:51:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:51:29 --> Final output sent to browser
DEBUG - 2023-08-19 15:51:29 --> Total execution time: 0.0856
INFO - 2023-08-19 15:51:35 --> Config Class Initialized
INFO - 2023-08-19 15:51:35 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:51:35 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:51:35 --> Utf8 Class Initialized
INFO - 2023-08-19 15:51:35 --> URI Class Initialized
INFO - 2023-08-19 15:51:35 --> Router Class Initialized
INFO - 2023-08-19 15:51:35 --> Output Class Initialized
INFO - 2023-08-19 15:51:35 --> Security Class Initialized
DEBUG - 2023-08-19 15:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:51:35 --> Input Class Initialized
INFO - 2023-08-19 15:51:35 --> Language Class Initialized
INFO - 2023-08-19 15:51:35 --> Language Class Initialized
INFO - 2023-08-19 15:51:35 --> Config Class Initialized
INFO - 2023-08-19 15:51:35 --> Loader Class Initialized
INFO - 2023-08-19 15:51:35 --> Helper loaded: url_helper
INFO - 2023-08-19 15:51:35 --> Helper loaded: file_helper
INFO - 2023-08-19 15:51:35 --> Helper loaded: form_helper
INFO - 2023-08-19 15:51:35 --> Helper loaded: my_helper
INFO - 2023-08-19 15:51:35 --> Database Driver Class Initialized
INFO - 2023-08-19 15:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:51:35 --> Controller Class Initialized
DEBUG - 2023-08-19 15:51:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2023-08-19 15:51:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:51:35 --> Final output sent to browser
DEBUG - 2023-08-19 15:51:35 --> Total execution time: 0.0296
INFO - 2023-08-19 15:51:39 --> Config Class Initialized
INFO - 2023-08-19 15:51:39 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:51:39 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:51:39 --> Utf8 Class Initialized
INFO - 2023-08-19 15:51:39 --> URI Class Initialized
INFO - 2023-08-19 15:51:39 --> Router Class Initialized
INFO - 2023-08-19 15:51:39 --> Output Class Initialized
INFO - 2023-08-19 15:51:39 --> Security Class Initialized
DEBUG - 2023-08-19 15:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:51:39 --> Input Class Initialized
INFO - 2023-08-19 15:51:39 --> Language Class Initialized
INFO - 2023-08-19 15:51:39 --> Language Class Initialized
INFO - 2023-08-19 15:51:39 --> Config Class Initialized
INFO - 2023-08-19 15:51:39 --> Loader Class Initialized
INFO - 2023-08-19 15:51:39 --> Helper loaded: url_helper
INFO - 2023-08-19 15:51:39 --> Helper loaded: file_helper
INFO - 2023-08-19 15:51:39 --> Helper loaded: form_helper
INFO - 2023-08-19 15:51:39 --> Helper loaded: my_helper
INFO - 2023-08-19 15:51:39 --> Database Driver Class Initialized
INFO - 2023-08-19 15:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:51:39 --> Controller Class Initialized
DEBUG - 2023-08-19 15:51:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 15:51:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:51:39 --> Final output sent to browser
DEBUG - 2023-08-19 15:51:39 --> Total execution time: 0.0295
INFO - 2023-08-19 15:51:46 --> Config Class Initialized
INFO - 2023-08-19 15:51:46 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:51:46 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:51:46 --> Utf8 Class Initialized
INFO - 2023-08-19 15:51:46 --> URI Class Initialized
INFO - 2023-08-19 15:51:46 --> Router Class Initialized
INFO - 2023-08-19 15:51:46 --> Output Class Initialized
INFO - 2023-08-19 15:51:46 --> Security Class Initialized
DEBUG - 2023-08-19 15:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:51:46 --> Input Class Initialized
INFO - 2023-08-19 15:51:46 --> Language Class Initialized
INFO - 2023-08-19 15:51:46 --> Language Class Initialized
INFO - 2023-08-19 15:51:46 --> Config Class Initialized
INFO - 2023-08-19 15:51:46 --> Loader Class Initialized
INFO - 2023-08-19 15:51:46 --> Helper loaded: url_helper
INFO - 2023-08-19 15:51:46 --> Helper loaded: file_helper
INFO - 2023-08-19 15:51:46 --> Helper loaded: form_helper
INFO - 2023-08-19 15:51:46 --> Helper loaded: my_helper
INFO - 2023-08-19 15:51:46 --> Database Driver Class Initialized
INFO - 2023-08-19 15:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:51:46 --> Controller Class Initialized
DEBUG - 2023-08-19 15:51:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-08-19 15:51:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:51:46 --> Final output sent to browser
DEBUG - 2023-08-19 15:51:46 --> Total execution time: 0.0438
INFO - 2023-08-19 15:51:46 --> Config Class Initialized
INFO - 2023-08-19 15:51:46 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:51:46 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:51:46 --> Utf8 Class Initialized
INFO - 2023-08-19 15:51:46 --> URI Class Initialized
INFO - 2023-08-19 15:51:46 --> Router Class Initialized
INFO - 2023-08-19 15:51:46 --> Output Class Initialized
INFO - 2023-08-19 15:51:46 --> Security Class Initialized
DEBUG - 2023-08-19 15:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:51:46 --> Input Class Initialized
INFO - 2023-08-19 15:51:46 --> Language Class Initialized
INFO - 2023-08-19 15:51:46 --> Language Class Initialized
INFO - 2023-08-19 15:51:46 --> Config Class Initialized
INFO - 2023-08-19 15:51:46 --> Loader Class Initialized
INFO - 2023-08-19 15:51:46 --> Helper loaded: url_helper
INFO - 2023-08-19 15:51:46 --> Helper loaded: file_helper
INFO - 2023-08-19 15:51:46 --> Helper loaded: form_helper
INFO - 2023-08-19 15:51:46 --> Helper loaded: my_helper
INFO - 2023-08-19 15:51:46 --> Database Driver Class Initialized
INFO - 2023-08-19 15:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:51:46 --> Controller Class Initialized
INFO - 2023-08-19 15:51:51 --> Config Class Initialized
INFO - 2023-08-19 15:51:51 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:51:51 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:51:51 --> Utf8 Class Initialized
INFO - 2023-08-19 15:51:51 --> URI Class Initialized
INFO - 2023-08-19 15:51:51 --> Router Class Initialized
INFO - 2023-08-19 15:51:51 --> Output Class Initialized
INFO - 2023-08-19 15:51:51 --> Security Class Initialized
DEBUG - 2023-08-19 15:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:51:51 --> Input Class Initialized
INFO - 2023-08-19 15:51:51 --> Language Class Initialized
INFO - 2023-08-19 15:51:51 --> Language Class Initialized
INFO - 2023-08-19 15:51:51 --> Config Class Initialized
INFO - 2023-08-19 15:51:51 --> Loader Class Initialized
INFO - 2023-08-19 15:51:51 --> Helper loaded: url_helper
INFO - 2023-08-19 15:51:51 --> Helper loaded: file_helper
INFO - 2023-08-19 15:51:52 --> Helper loaded: form_helper
INFO - 2023-08-19 15:51:52 --> Helper loaded: my_helper
INFO - 2023-08-19 15:51:52 --> Database Driver Class Initialized
INFO - 2023-08-19 15:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:51:52 --> Controller Class Initialized
INFO - 2023-08-19 15:51:52 --> Final output sent to browser
DEBUG - 2023-08-19 15:51:52 --> Total execution time: 0.0757
INFO - 2023-08-19 15:51:55 --> Config Class Initialized
INFO - 2023-08-19 15:51:55 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:51:55 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:51:55 --> Utf8 Class Initialized
INFO - 2023-08-19 15:51:55 --> URI Class Initialized
INFO - 2023-08-19 15:51:55 --> Router Class Initialized
INFO - 2023-08-19 15:51:55 --> Output Class Initialized
INFO - 2023-08-19 15:51:55 --> Security Class Initialized
DEBUG - 2023-08-19 15:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:51:55 --> Input Class Initialized
INFO - 2023-08-19 15:51:55 --> Language Class Initialized
INFO - 2023-08-19 15:51:55 --> Language Class Initialized
INFO - 2023-08-19 15:51:55 --> Config Class Initialized
INFO - 2023-08-19 15:51:55 --> Loader Class Initialized
INFO - 2023-08-19 15:51:55 --> Helper loaded: url_helper
INFO - 2023-08-19 15:51:55 --> Helper loaded: file_helper
INFO - 2023-08-19 15:51:55 --> Helper loaded: form_helper
INFO - 2023-08-19 15:51:55 --> Helper loaded: my_helper
INFO - 2023-08-19 15:51:55 --> Database Driver Class Initialized
INFO - 2023-08-19 15:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:51:55 --> Controller Class Initialized
INFO - 2023-08-19 15:52:01 --> Config Class Initialized
INFO - 2023-08-19 15:52:01 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:52:01 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:52:01 --> Utf8 Class Initialized
INFO - 2023-08-19 15:52:01 --> URI Class Initialized
INFO - 2023-08-19 15:52:01 --> Router Class Initialized
INFO - 2023-08-19 15:52:01 --> Output Class Initialized
INFO - 2023-08-19 15:52:01 --> Security Class Initialized
DEBUG - 2023-08-19 15:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:52:01 --> Input Class Initialized
INFO - 2023-08-19 15:52:01 --> Language Class Initialized
INFO - 2023-08-19 15:52:01 --> Language Class Initialized
INFO - 2023-08-19 15:52:01 --> Config Class Initialized
INFO - 2023-08-19 15:52:01 --> Loader Class Initialized
INFO - 2023-08-19 15:52:01 --> Helper loaded: url_helper
INFO - 2023-08-19 15:52:01 --> Helper loaded: file_helper
INFO - 2023-08-19 15:52:01 --> Helper loaded: form_helper
INFO - 2023-08-19 15:52:01 --> Helper loaded: my_helper
INFO - 2023-08-19 15:52:01 --> Database Driver Class Initialized
INFO - 2023-08-19 15:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:52:01 --> Controller Class Initialized
DEBUG - 2023-08-19 15:52:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-08-19 15:52:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 15:52:01 --> Final output sent to browser
DEBUG - 2023-08-19 15:52:01 --> Total execution time: 0.0687
INFO - 2023-08-19 15:52:01 --> Config Class Initialized
INFO - 2023-08-19 15:52:01 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:52:01 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:52:01 --> Utf8 Class Initialized
INFO - 2023-08-19 15:52:01 --> URI Class Initialized
INFO - 2023-08-19 15:52:01 --> Router Class Initialized
INFO - 2023-08-19 15:52:01 --> Output Class Initialized
INFO - 2023-08-19 15:52:01 --> Security Class Initialized
DEBUG - 2023-08-19 15:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:52:01 --> Input Class Initialized
INFO - 2023-08-19 15:52:01 --> Language Class Initialized
INFO - 2023-08-19 15:52:01 --> Language Class Initialized
INFO - 2023-08-19 15:52:01 --> Config Class Initialized
INFO - 2023-08-19 15:52:01 --> Loader Class Initialized
INFO - 2023-08-19 15:52:01 --> Helper loaded: url_helper
INFO - 2023-08-19 15:52:01 --> Helper loaded: file_helper
INFO - 2023-08-19 15:52:01 --> Helper loaded: form_helper
INFO - 2023-08-19 15:52:01 --> Helper loaded: my_helper
INFO - 2023-08-19 15:52:01 --> Database Driver Class Initialized
INFO - 2023-08-19 15:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:52:01 --> Controller Class Initialized
INFO - 2023-08-19 15:52:04 --> Config Class Initialized
INFO - 2023-08-19 15:52:04 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:52:04 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:52:04 --> Utf8 Class Initialized
INFO - 2023-08-19 15:52:04 --> URI Class Initialized
INFO - 2023-08-19 15:52:04 --> Router Class Initialized
INFO - 2023-08-19 15:52:04 --> Output Class Initialized
INFO - 2023-08-19 15:52:04 --> Security Class Initialized
DEBUG - 2023-08-19 15:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:52:04 --> Input Class Initialized
INFO - 2023-08-19 15:52:04 --> Language Class Initialized
INFO - 2023-08-19 15:52:04 --> Language Class Initialized
INFO - 2023-08-19 15:52:04 --> Config Class Initialized
INFO - 2023-08-19 15:52:04 --> Loader Class Initialized
INFO - 2023-08-19 15:52:04 --> Helper loaded: url_helper
INFO - 2023-08-19 15:52:04 --> Helper loaded: file_helper
INFO - 2023-08-19 15:52:04 --> Helper loaded: form_helper
INFO - 2023-08-19 15:52:04 --> Helper loaded: my_helper
INFO - 2023-08-19 15:52:04 --> Database Driver Class Initialized
INFO - 2023-08-19 15:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:52:04 --> Controller Class Initialized
INFO - 2023-08-19 15:52:04 --> Final output sent to browser
DEBUG - 2023-08-19 15:52:04 --> Total execution time: 0.0358
INFO - 2023-08-19 16:02:17 --> Config Class Initialized
INFO - 2023-08-19 16:02:17 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:02:17 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:02:17 --> Utf8 Class Initialized
INFO - 2023-08-19 16:02:17 --> URI Class Initialized
INFO - 2023-08-19 16:02:17 --> Router Class Initialized
INFO - 2023-08-19 16:02:17 --> Output Class Initialized
INFO - 2023-08-19 16:02:17 --> Security Class Initialized
DEBUG - 2023-08-19 16:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:02:17 --> Input Class Initialized
INFO - 2023-08-19 16:02:17 --> Language Class Initialized
INFO - 2023-08-19 16:02:17 --> Language Class Initialized
INFO - 2023-08-19 16:02:17 --> Config Class Initialized
INFO - 2023-08-19 16:02:17 --> Loader Class Initialized
INFO - 2023-08-19 16:02:17 --> Helper loaded: url_helper
INFO - 2023-08-19 16:02:17 --> Helper loaded: file_helper
INFO - 2023-08-19 16:02:17 --> Helper loaded: form_helper
INFO - 2023-08-19 16:02:17 --> Helper loaded: my_helper
INFO - 2023-08-19 16:02:17 --> Database Driver Class Initialized
INFO - 2023-08-19 16:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:02:17 --> Controller Class Initialized
INFO - 2023-08-19 16:02:17 --> Final output sent to browser
DEBUG - 2023-08-19 16:02:17 --> Total execution time: 0.0284
INFO - 2023-08-19 16:02:41 --> Config Class Initialized
INFO - 2023-08-19 16:02:41 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:02:41 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:02:41 --> Utf8 Class Initialized
INFO - 2023-08-19 16:02:41 --> URI Class Initialized
INFO - 2023-08-19 16:02:41 --> Router Class Initialized
INFO - 2023-08-19 16:02:41 --> Output Class Initialized
INFO - 2023-08-19 16:02:41 --> Security Class Initialized
DEBUG - 2023-08-19 16:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:02:41 --> Input Class Initialized
INFO - 2023-08-19 16:02:41 --> Language Class Initialized
INFO - 2023-08-19 16:02:41 --> Language Class Initialized
INFO - 2023-08-19 16:02:41 --> Config Class Initialized
INFO - 2023-08-19 16:02:41 --> Loader Class Initialized
INFO - 2023-08-19 16:02:41 --> Helper loaded: url_helper
INFO - 2023-08-19 16:02:41 --> Helper loaded: file_helper
INFO - 2023-08-19 16:02:41 --> Helper loaded: form_helper
INFO - 2023-08-19 16:02:41 --> Helper loaded: my_helper
INFO - 2023-08-19 16:02:41 --> Database Driver Class Initialized
INFO - 2023-08-19 16:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:02:41 --> Controller Class Initialized
INFO - 2023-08-19 16:02:41 --> Final output sent to browser
DEBUG - 2023-08-19 16:02:41 --> Total execution time: 0.0724
INFO - 2023-08-19 16:02:41 --> Config Class Initialized
INFO - 2023-08-19 16:02:41 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:02:41 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:02:41 --> Utf8 Class Initialized
INFO - 2023-08-19 16:02:41 --> URI Class Initialized
INFO - 2023-08-19 16:02:41 --> Router Class Initialized
INFO - 2023-08-19 16:02:41 --> Output Class Initialized
INFO - 2023-08-19 16:02:41 --> Security Class Initialized
DEBUG - 2023-08-19 16:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:02:41 --> Input Class Initialized
INFO - 2023-08-19 16:02:41 --> Language Class Initialized
INFO - 2023-08-19 16:02:41 --> Language Class Initialized
INFO - 2023-08-19 16:02:41 --> Config Class Initialized
INFO - 2023-08-19 16:02:41 --> Loader Class Initialized
INFO - 2023-08-19 16:02:41 --> Helper loaded: url_helper
INFO - 2023-08-19 16:02:41 --> Helper loaded: file_helper
INFO - 2023-08-19 16:02:41 --> Helper loaded: form_helper
INFO - 2023-08-19 16:02:41 --> Helper loaded: my_helper
INFO - 2023-08-19 16:02:41 --> Database Driver Class Initialized
INFO - 2023-08-19 16:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:02:41 --> Controller Class Initialized
INFO - 2023-08-19 16:03:05 --> Config Class Initialized
INFO - 2023-08-19 16:03:05 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:03:05 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:03:05 --> Utf8 Class Initialized
INFO - 2023-08-19 16:03:05 --> URI Class Initialized
INFO - 2023-08-19 16:03:05 --> Router Class Initialized
INFO - 2023-08-19 16:03:05 --> Output Class Initialized
INFO - 2023-08-19 16:03:05 --> Security Class Initialized
DEBUG - 2023-08-19 16:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:03:05 --> Input Class Initialized
INFO - 2023-08-19 16:03:05 --> Language Class Initialized
INFO - 2023-08-19 16:03:05 --> Language Class Initialized
INFO - 2023-08-19 16:03:05 --> Config Class Initialized
INFO - 2023-08-19 16:03:05 --> Loader Class Initialized
INFO - 2023-08-19 16:03:05 --> Helper loaded: url_helper
INFO - 2023-08-19 16:03:05 --> Helper loaded: file_helper
INFO - 2023-08-19 16:03:05 --> Helper loaded: form_helper
INFO - 2023-08-19 16:03:05 --> Helper loaded: my_helper
INFO - 2023-08-19 16:03:05 --> Database Driver Class Initialized
INFO - 2023-08-19 16:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:03:05 --> Controller Class Initialized
INFO - 2023-08-19 16:03:05 --> Final output sent to browser
DEBUG - 2023-08-19 16:03:05 --> Total execution time: 0.1012
INFO - 2023-08-19 16:03:14 --> Config Class Initialized
INFO - 2023-08-19 16:03:14 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:03:14 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:03:14 --> Utf8 Class Initialized
INFO - 2023-08-19 16:03:14 --> URI Class Initialized
INFO - 2023-08-19 16:03:14 --> Router Class Initialized
INFO - 2023-08-19 16:03:14 --> Output Class Initialized
INFO - 2023-08-19 16:03:14 --> Security Class Initialized
DEBUG - 2023-08-19 16:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:03:14 --> Input Class Initialized
INFO - 2023-08-19 16:03:14 --> Language Class Initialized
INFO - 2023-08-19 16:03:14 --> Language Class Initialized
INFO - 2023-08-19 16:03:14 --> Config Class Initialized
INFO - 2023-08-19 16:03:14 --> Loader Class Initialized
INFO - 2023-08-19 16:03:14 --> Helper loaded: url_helper
INFO - 2023-08-19 16:03:14 --> Helper loaded: file_helper
INFO - 2023-08-19 16:03:14 --> Helper loaded: form_helper
INFO - 2023-08-19 16:03:14 --> Helper loaded: my_helper
INFO - 2023-08-19 16:03:14 --> Database Driver Class Initialized
INFO - 2023-08-19 16:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:03:14 --> Controller Class Initialized
INFO - 2023-08-19 16:03:14 --> Final output sent to browser
DEBUG - 2023-08-19 16:03:14 --> Total execution time: 0.0329
INFO - 2023-08-19 16:03:14 --> Config Class Initialized
INFO - 2023-08-19 16:03:14 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:03:14 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:03:14 --> Utf8 Class Initialized
INFO - 2023-08-19 16:03:14 --> URI Class Initialized
INFO - 2023-08-19 16:03:14 --> Router Class Initialized
INFO - 2023-08-19 16:03:14 --> Output Class Initialized
INFO - 2023-08-19 16:03:14 --> Security Class Initialized
DEBUG - 2023-08-19 16:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:03:14 --> Input Class Initialized
INFO - 2023-08-19 16:03:14 --> Language Class Initialized
INFO - 2023-08-19 16:03:14 --> Language Class Initialized
INFO - 2023-08-19 16:03:14 --> Config Class Initialized
INFO - 2023-08-19 16:03:14 --> Loader Class Initialized
INFO - 2023-08-19 16:03:14 --> Helper loaded: url_helper
INFO - 2023-08-19 16:03:14 --> Helper loaded: file_helper
INFO - 2023-08-19 16:03:14 --> Helper loaded: form_helper
INFO - 2023-08-19 16:03:14 --> Helper loaded: my_helper
INFO - 2023-08-19 16:03:14 --> Database Driver Class Initialized
INFO - 2023-08-19 16:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:03:14 --> Controller Class Initialized
INFO - 2023-08-19 16:03:43 --> Config Class Initialized
INFO - 2023-08-19 16:03:43 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:03:43 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:03:43 --> Utf8 Class Initialized
INFO - 2023-08-19 16:03:43 --> URI Class Initialized
INFO - 2023-08-19 16:03:43 --> Router Class Initialized
INFO - 2023-08-19 16:03:43 --> Output Class Initialized
INFO - 2023-08-19 16:03:43 --> Security Class Initialized
DEBUG - 2023-08-19 16:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:03:43 --> Input Class Initialized
INFO - 2023-08-19 16:03:43 --> Language Class Initialized
INFO - 2023-08-19 16:03:43 --> Language Class Initialized
INFO - 2023-08-19 16:03:43 --> Config Class Initialized
INFO - 2023-08-19 16:03:43 --> Loader Class Initialized
INFO - 2023-08-19 16:03:43 --> Helper loaded: url_helper
INFO - 2023-08-19 16:03:43 --> Helper loaded: file_helper
INFO - 2023-08-19 16:03:43 --> Helper loaded: form_helper
INFO - 2023-08-19 16:03:43 --> Helper loaded: my_helper
INFO - 2023-08-19 16:03:43 --> Database Driver Class Initialized
INFO - 2023-08-19 16:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:03:43 --> Controller Class Initialized
INFO - 2023-08-19 16:03:43 --> Final output sent to browser
DEBUG - 2023-08-19 16:03:43 --> Total execution time: 0.0273
INFO - 2023-08-19 16:03:56 --> Config Class Initialized
INFO - 2023-08-19 16:03:56 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:03:56 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:03:56 --> Utf8 Class Initialized
INFO - 2023-08-19 16:03:56 --> URI Class Initialized
INFO - 2023-08-19 16:03:56 --> Router Class Initialized
INFO - 2023-08-19 16:03:56 --> Output Class Initialized
INFO - 2023-08-19 16:03:56 --> Security Class Initialized
DEBUG - 2023-08-19 16:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:03:56 --> Input Class Initialized
INFO - 2023-08-19 16:03:56 --> Language Class Initialized
INFO - 2023-08-19 16:03:56 --> Language Class Initialized
INFO - 2023-08-19 16:03:56 --> Config Class Initialized
INFO - 2023-08-19 16:03:56 --> Loader Class Initialized
INFO - 2023-08-19 16:03:56 --> Helper loaded: url_helper
INFO - 2023-08-19 16:03:56 --> Helper loaded: file_helper
INFO - 2023-08-19 16:03:56 --> Helper loaded: form_helper
INFO - 2023-08-19 16:03:56 --> Helper loaded: my_helper
INFO - 2023-08-19 16:03:56 --> Database Driver Class Initialized
INFO - 2023-08-19 16:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:03:56 --> Controller Class Initialized
INFO - 2023-08-19 16:03:56 --> Final output sent to browser
DEBUG - 2023-08-19 16:03:56 --> Total execution time: 0.0330
INFO - 2023-08-19 16:03:56 --> Config Class Initialized
INFO - 2023-08-19 16:03:56 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:03:56 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:03:56 --> Utf8 Class Initialized
INFO - 2023-08-19 16:03:56 --> URI Class Initialized
INFO - 2023-08-19 16:03:56 --> Router Class Initialized
INFO - 2023-08-19 16:03:56 --> Output Class Initialized
INFO - 2023-08-19 16:03:56 --> Security Class Initialized
DEBUG - 2023-08-19 16:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:03:56 --> Input Class Initialized
INFO - 2023-08-19 16:03:56 --> Language Class Initialized
INFO - 2023-08-19 16:03:56 --> Language Class Initialized
INFO - 2023-08-19 16:03:56 --> Config Class Initialized
INFO - 2023-08-19 16:03:56 --> Loader Class Initialized
INFO - 2023-08-19 16:03:56 --> Helper loaded: url_helper
INFO - 2023-08-19 16:03:56 --> Helper loaded: file_helper
INFO - 2023-08-19 16:03:56 --> Helper loaded: form_helper
INFO - 2023-08-19 16:03:56 --> Helper loaded: my_helper
INFO - 2023-08-19 16:03:56 --> Database Driver Class Initialized
INFO - 2023-08-19 16:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:03:56 --> Controller Class Initialized
INFO - 2023-08-19 16:04:03 --> Config Class Initialized
INFO - 2023-08-19 16:04:03 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:04:03 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:04:03 --> Utf8 Class Initialized
INFO - 2023-08-19 16:04:03 --> URI Class Initialized
INFO - 2023-08-19 16:04:03 --> Router Class Initialized
INFO - 2023-08-19 16:04:03 --> Output Class Initialized
INFO - 2023-08-19 16:04:03 --> Security Class Initialized
DEBUG - 2023-08-19 16:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:04:03 --> Input Class Initialized
INFO - 2023-08-19 16:04:03 --> Language Class Initialized
INFO - 2023-08-19 16:04:03 --> Language Class Initialized
INFO - 2023-08-19 16:04:03 --> Config Class Initialized
INFO - 2023-08-19 16:04:03 --> Loader Class Initialized
INFO - 2023-08-19 16:04:03 --> Helper loaded: url_helper
INFO - 2023-08-19 16:04:03 --> Helper loaded: file_helper
INFO - 2023-08-19 16:04:03 --> Helper loaded: form_helper
INFO - 2023-08-19 16:04:03 --> Helper loaded: my_helper
INFO - 2023-08-19 16:04:03 --> Database Driver Class Initialized
INFO - 2023-08-19 16:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:04:03 --> Controller Class Initialized
INFO - 2023-08-19 16:04:03 --> Final output sent to browser
DEBUG - 2023-08-19 16:04:03 --> Total execution time: 0.0306
INFO - 2023-08-19 16:04:11 --> Config Class Initialized
INFO - 2023-08-19 16:04:11 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:04:11 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:04:11 --> Utf8 Class Initialized
INFO - 2023-08-19 16:04:11 --> URI Class Initialized
INFO - 2023-08-19 16:04:11 --> Router Class Initialized
INFO - 2023-08-19 16:04:11 --> Output Class Initialized
INFO - 2023-08-19 16:04:11 --> Security Class Initialized
DEBUG - 2023-08-19 16:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:04:11 --> Input Class Initialized
INFO - 2023-08-19 16:04:11 --> Language Class Initialized
INFO - 2023-08-19 16:04:11 --> Language Class Initialized
INFO - 2023-08-19 16:04:11 --> Config Class Initialized
INFO - 2023-08-19 16:04:11 --> Loader Class Initialized
INFO - 2023-08-19 16:04:11 --> Helper loaded: url_helper
INFO - 2023-08-19 16:04:11 --> Helper loaded: file_helper
INFO - 2023-08-19 16:04:11 --> Helper loaded: form_helper
INFO - 2023-08-19 16:04:11 --> Helper loaded: my_helper
INFO - 2023-08-19 16:04:11 --> Database Driver Class Initialized
INFO - 2023-08-19 16:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:04:11 --> Controller Class Initialized
INFO - 2023-08-19 16:04:11 --> Final output sent to browser
DEBUG - 2023-08-19 16:04:11 --> Total execution time: 0.0316
INFO - 2023-08-19 16:04:11 --> Config Class Initialized
INFO - 2023-08-19 16:04:11 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:04:11 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:04:11 --> Utf8 Class Initialized
INFO - 2023-08-19 16:04:11 --> URI Class Initialized
INFO - 2023-08-19 16:04:11 --> Router Class Initialized
INFO - 2023-08-19 16:04:11 --> Output Class Initialized
INFO - 2023-08-19 16:04:11 --> Security Class Initialized
DEBUG - 2023-08-19 16:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:04:11 --> Input Class Initialized
INFO - 2023-08-19 16:04:11 --> Language Class Initialized
INFO - 2023-08-19 16:04:11 --> Language Class Initialized
INFO - 2023-08-19 16:04:11 --> Config Class Initialized
INFO - 2023-08-19 16:04:11 --> Loader Class Initialized
INFO - 2023-08-19 16:04:11 --> Helper loaded: url_helper
INFO - 2023-08-19 16:04:11 --> Helper loaded: file_helper
INFO - 2023-08-19 16:04:11 --> Helper loaded: form_helper
INFO - 2023-08-19 16:04:11 --> Helper loaded: my_helper
INFO - 2023-08-19 16:04:11 --> Database Driver Class Initialized
INFO - 2023-08-19 16:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:04:11 --> Controller Class Initialized
INFO - 2023-08-19 16:04:12 --> Config Class Initialized
INFO - 2023-08-19 16:04:12 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:04:12 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:04:12 --> Utf8 Class Initialized
INFO - 2023-08-19 16:04:12 --> URI Class Initialized
INFO - 2023-08-19 16:04:12 --> Router Class Initialized
INFO - 2023-08-19 16:04:12 --> Output Class Initialized
INFO - 2023-08-19 16:04:12 --> Security Class Initialized
DEBUG - 2023-08-19 16:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:04:12 --> Input Class Initialized
INFO - 2023-08-19 16:04:12 --> Language Class Initialized
INFO - 2023-08-19 16:04:12 --> Language Class Initialized
INFO - 2023-08-19 16:04:12 --> Config Class Initialized
INFO - 2023-08-19 16:04:12 --> Loader Class Initialized
INFO - 2023-08-19 16:04:12 --> Helper loaded: url_helper
INFO - 2023-08-19 16:04:12 --> Helper loaded: file_helper
INFO - 2023-08-19 16:04:12 --> Helper loaded: form_helper
INFO - 2023-08-19 16:04:12 --> Helper loaded: my_helper
INFO - 2023-08-19 16:04:12 --> Database Driver Class Initialized
INFO - 2023-08-19 16:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:04:12 --> Controller Class Initialized
DEBUG - 2023-08-19 16:04:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_absensi/views/list.php
DEBUG - 2023-08-19 16:04:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:04:12 --> Final output sent to browser
DEBUG - 2023-08-19 16:04:12 --> Total execution time: 0.0581
INFO - 2023-08-19 16:04:13 --> Config Class Initialized
INFO - 2023-08-19 16:04:13 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:04:13 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:04:13 --> Utf8 Class Initialized
INFO - 2023-08-19 16:04:13 --> URI Class Initialized
INFO - 2023-08-19 16:04:13 --> Router Class Initialized
INFO - 2023-08-19 16:04:13 --> Output Class Initialized
INFO - 2023-08-19 16:04:13 --> Security Class Initialized
DEBUG - 2023-08-19 16:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:04:13 --> Input Class Initialized
INFO - 2023-08-19 16:04:13 --> Language Class Initialized
INFO - 2023-08-19 16:04:13 --> Language Class Initialized
INFO - 2023-08-19 16:04:13 --> Config Class Initialized
INFO - 2023-08-19 16:04:13 --> Loader Class Initialized
INFO - 2023-08-19 16:04:13 --> Helper loaded: url_helper
INFO - 2023-08-19 16:04:13 --> Helper loaded: file_helper
INFO - 2023-08-19 16:04:13 --> Helper loaded: form_helper
INFO - 2023-08-19 16:04:13 --> Helper loaded: my_helper
INFO - 2023-08-19 16:04:13 --> Database Driver Class Initialized
INFO - 2023-08-19 16:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:04:13 --> Controller Class Initialized
INFO - 2023-08-19 16:04:13 --> Final output sent to browser
DEBUG - 2023-08-19 16:04:13 --> Total execution time: 0.0279
INFO - 2023-08-19 16:04:35 --> Config Class Initialized
INFO - 2023-08-19 16:04:35 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:04:35 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:04:35 --> Utf8 Class Initialized
INFO - 2023-08-19 16:04:35 --> URI Class Initialized
INFO - 2023-08-19 16:04:35 --> Router Class Initialized
INFO - 2023-08-19 16:04:35 --> Output Class Initialized
INFO - 2023-08-19 16:04:35 --> Security Class Initialized
DEBUG - 2023-08-19 16:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:04:35 --> Input Class Initialized
INFO - 2023-08-19 16:04:35 --> Language Class Initialized
INFO - 2023-08-19 16:04:35 --> Language Class Initialized
INFO - 2023-08-19 16:04:35 --> Config Class Initialized
INFO - 2023-08-19 16:04:35 --> Loader Class Initialized
INFO - 2023-08-19 16:04:35 --> Helper loaded: url_helper
INFO - 2023-08-19 16:04:35 --> Helper loaded: file_helper
INFO - 2023-08-19 16:04:35 --> Helper loaded: form_helper
INFO - 2023-08-19 16:04:35 --> Helper loaded: my_helper
INFO - 2023-08-19 16:04:35 --> Database Driver Class Initialized
INFO - 2023-08-19 16:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:04:35 --> Controller Class Initialized
INFO - 2023-08-19 16:04:35 --> Final output sent to browser
DEBUG - 2023-08-19 16:04:35 --> Total execution time: 0.0308
INFO - 2023-08-19 16:04:35 --> Config Class Initialized
INFO - 2023-08-19 16:04:35 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:04:35 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:04:35 --> Utf8 Class Initialized
INFO - 2023-08-19 16:04:35 --> URI Class Initialized
INFO - 2023-08-19 16:04:35 --> Router Class Initialized
INFO - 2023-08-19 16:04:35 --> Output Class Initialized
INFO - 2023-08-19 16:04:35 --> Security Class Initialized
DEBUG - 2023-08-19 16:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:04:35 --> Input Class Initialized
INFO - 2023-08-19 16:04:35 --> Language Class Initialized
INFO - 2023-08-19 16:04:35 --> Language Class Initialized
INFO - 2023-08-19 16:04:35 --> Config Class Initialized
INFO - 2023-08-19 16:04:35 --> Loader Class Initialized
INFO - 2023-08-19 16:04:35 --> Helper loaded: url_helper
INFO - 2023-08-19 16:04:35 --> Helper loaded: file_helper
INFO - 2023-08-19 16:04:35 --> Helper loaded: form_helper
INFO - 2023-08-19 16:04:35 --> Helper loaded: my_helper
INFO - 2023-08-19 16:04:35 --> Database Driver Class Initialized
INFO - 2023-08-19 16:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:04:35 --> Controller Class Initialized
INFO - 2023-08-19 16:06:33 --> Config Class Initialized
INFO - 2023-08-19 16:06:33 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:06:33 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:06:33 --> Utf8 Class Initialized
INFO - 2023-08-19 16:06:33 --> URI Class Initialized
INFO - 2023-08-19 16:06:33 --> Router Class Initialized
INFO - 2023-08-19 16:06:33 --> Output Class Initialized
INFO - 2023-08-19 16:06:33 --> Security Class Initialized
DEBUG - 2023-08-19 16:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:06:33 --> Input Class Initialized
INFO - 2023-08-19 16:06:33 --> Language Class Initialized
INFO - 2023-08-19 16:06:33 --> Language Class Initialized
INFO - 2023-08-19 16:06:33 --> Config Class Initialized
INFO - 2023-08-19 16:06:33 --> Loader Class Initialized
INFO - 2023-08-19 16:06:33 --> Helper loaded: url_helper
INFO - 2023-08-19 16:06:33 --> Helper loaded: file_helper
INFO - 2023-08-19 16:06:33 --> Helper loaded: form_helper
INFO - 2023-08-19 16:06:33 --> Helper loaded: my_helper
INFO - 2023-08-19 16:06:33 --> Database Driver Class Initialized
INFO - 2023-08-19 16:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:06:34 --> Controller Class Initialized
INFO - 2023-08-19 16:06:34 --> Final output sent to browser
DEBUG - 2023-08-19 16:06:34 --> Total execution time: 0.0782
INFO - 2023-08-19 16:06:35 --> Config Class Initialized
INFO - 2023-08-19 16:06:35 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:06:35 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:06:35 --> Utf8 Class Initialized
INFO - 2023-08-19 16:06:35 --> URI Class Initialized
INFO - 2023-08-19 16:06:35 --> Router Class Initialized
INFO - 2023-08-19 16:06:35 --> Output Class Initialized
INFO - 2023-08-19 16:06:35 --> Security Class Initialized
DEBUG - 2023-08-19 16:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:06:35 --> Input Class Initialized
INFO - 2023-08-19 16:06:35 --> Language Class Initialized
INFO - 2023-08-19 16:06:35 --> Language Class Initialized
INFO - 2023-08-19 16:06:35 --> Config Class Initialized
INFO - 2023-08-19 16:06:35 --> Loader Class Initialized
INFO - 2023-08-19 16:06:35 --> Helper loaded: url_helper
INFO - 2023-08-19 16:06:35 --> Helper loaded: file_helper
INFO - 2023-08-19 16:06:35 --> Helper loaded: form_helper
INFO - 2023-08-19 16:06:35 --> Helper loaded: my_helper
INFO - 2023-08-19 16:06:35 --> Database Driver Class Initialized
INFO - 2023-08-19 16:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:06:35 --> Controller Class Initialized
INFO - 2023-08-19 16:06:35 --> Final output sent to browser
DEBUG - 2023-08-19 16:06:35 --> Total execution time: 0.0411
INFO - 2023-08-19 16:06:36 --> Config Class Initialized
INFO - 2023-08-19 16:06:36 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:06:36 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:06:36 --> Utf8 Class Initialized
INFO - 2023-08-19 16:06:36 --> URI Class Initialized
INFO - 2023-08-19 16:06:36 --> Router Class Initialized
INFO - 2023-08-19 16:06:36 --> Output Class Initialized
INFO - 2023-08-19 16:06:36 --> Security Class Initialized
DEBUG - 2023-08-19 16:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:06:36 --> Input Class Initialized
INFO - 2023-08-19 16:06:36 --> Language Class Initialized
INFO - 2023-08-19 16:06:36 --> Language Class Initialized
INFO - 2023-08-19 16:06:36 --> Config Class Initialized
INFO - 2023-08-19 16:06:36 --> Loader Class Initialized
INFO - 2023-08-19 16:06:36 --> Helper loaded: url_helper
INFO - 2023-08-19 16:06:36 --> Helper loaded: file_helper
INFO - 2023-08-19 16:06:36 --> Helper loaded: form_helper
INFO - 2023-08-19 16:06:36 --> Helper loaded: my_helper
INFO - 2023-08-19 16:06:36 --> Database Driver Class Initialized
INFO - 2023-08-19 16:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:06:36 --> Controller Class Initialized
INFO - 2023-08-19 16:06:36 --> Final output sent to browser
DEBUG - 2023-08-19 16:06:36 --> Total execution time: 0.0303
INFO - 2023-08-19 16:06:38 --> Config Class Initialized
INFO - 2023-08-19 16:06:38 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:06:38 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:06:38 --> Utf8 Class Initialized
INFO - 2023-08-19 16:06:38 --> URI Class Initialized
INFO - 2023-08-19 16:06:38 --> Router Class Initialized
INFO - 2023-08-19 16:06:38 --> Output Class Initialized
INFO - 2023-08-19 16:06:38 --> Security Class Initialized
DEBUG - 2023-08-19 16:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:06:38 --> Input Class Initialized
INFO - 2023-08-19 16:06:38 --> Language Class Initialized
INFO - 2023-08-19 16:06:38 --> Language Class Initialized
INFO - 2023-08-19 16:06:38 --> Config Class Initialized
INFO - 2023-08-19 16:06:38 --> Loader Class Initialized
INFO - 2023-08-19 16:06:38 --> Helper loaded: url_helper
INFO - 2023-08-19 16:06:38 --> Helper loaded: file_helper
INFO - 2023-08-19 16:06:38 --> Helper loaded: form_helper
INFO - 2023-08-19 16:06:38 --> Helper loaded: my_helper
INFO - 2023-08-19 16:06:38 --> Database Driver Class Initialized
INFO - 2023-08-19 16:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:06:38 --> Controller Class Initialized
INFO - 2023-08-19 16:06:38 --> Final output sent to browser
DEBUG - 2023-08-19 16:06:38 --> Total execution time: 0.0296
INFO - 2023-08-19 16:06:42 --> Config Class Initialized
INFO - 2023-08-19 16:06:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:06:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:06:42 --> Utf8 Class Initialized
INFO - 2023-08-19 16:06:42 --> URI Class Initialized
INFO - 2023-08-19 16:06:42 --> Router Class Initialized
INFO - 2023-08-19 16:06:42 --> Output Class Initialized
INFO - 2023-08-19 16:06:42 --> Security Class Initialized
DEBUG - 2023-08-19 16:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:06:42 --> Input Class Initialized
INFO - 2023-08-19 16:06:42 --> Language Class Initialized
INFO - 2023-08-19 16:06:42 --> Language Class Initialized
INFO - 2023-08-19 16:06:42 --> Config Class Initialized
INFO - 2023-08-19 16:06:42 --> Loader Class Initialized
INFO - 2023-08-19 16:06:42 --> Helper loaded: url_helper
INFO - 2023-08-19 16:06:42 --> Helper loaded: file_helper
INFO - 2023-08-19 16:06:42 --> Helper loaded: form_helper
INFO - 2023-08-19 16:06:42 --> Helper loaded: my_helper
INFO - 2023-08-19 16:06:42 --> Database Driver Class Initialized
INFO - 2023-08-19 16:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:06:42 --> Controller Class Initialized
INFO - 2023-08-19 16:06:42 --> Final output sent to browser
DEBUG - 2023-08-19 16:06:42 --> Total execution time: 0.0406
INFO - 2023-08-19 16:06:43 --> Config Class Initialized
INFO - 2023-08-19 16:06:43 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:06:43 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:06:43 --> Utf8 Class Initialized
INFO - 2023-08-19 16:06:43 --> URI Class Initialized
INFO - 2023-08-19 16:06:43 --> Router Class Initialized
INFO - 2023-08-19 16:06:43 --> Output Class Initialized
INFO - 2023-08-19 16:06:43 --> Security Class Initialized
DEBUG - 2023-08-19 16:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:06:43 --> Input Class Initialized
INFO - 2023-08-19 16:06:43 --> Language Class Initialized
INFO - 2023-08-19 16:06:43 --> Language Class Initialized
INFO - 2023-08-19 16:06:43 --> Config Class Initialized
INFO - 2023-08-19 16:06:43 --> Loader Class Initialized
INFO - 2023-08-19 16:06:43 --> Helper loaded: url_helper
INFO - 2023-08-19 16:06:43 --> Helper loaded: file_helper
INFO - 2023-08-19 16:06:43 --> Helper loaded: form_helper
INFO - 2023-08-19 16:06:43 --> Helper loaded: my_helper
INFO - 2023-08-19 16:06:43 --> Database Driver Class Initialized
INFO - 2023-08-19 16:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:06:43 --> Controller Class Initialized
INFO - 2023-08-19 16:06:43 --> Final output sent to browser
DEBUG - 2023-08-19 16:06:43 --> Total execution time: 0.0328
INFO - 2023-08-19 16:06:44 --> Config Class Initialized
INFO - 2023-08-19 16:06:44 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:06:44 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:06:44 --> Utf8 Class Initialized
INFO - 2023-08-19 16:06:44 --> URI Class Initialized
INFO - 2023-08-19 16:06:44 --> Router Class Initialized
INFO - 2023-08-19 16:06:44 --> Output Class Initialized
INFO - 2023-08-19 16:06:44 --> Security Class Initialized
DEBUG - 2023-08-19 16:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:06:44 --> Input Class Initialized
INFO - 2023-08-19 16:06:44 --> Language Class Initialized
INFO - 2023-08-19 16:06:44 --> Language Class Initialized
INFO - 2023-08-19 16:06:44 --> Config Class Initialized
INFO - 2023-08-19 16:06:44 --> Loader Class Initialized
INFO - 2023-08-19 16:06:44 --> Helper loaded: url_helper
INFO - 2023-08-19 16:06:44 --> Helper loaded: file_helper
INFO - 2023-08-19 16:06:44 --> Helper loaded: form_helper
INFO - 2023-08-19 16:06:44 --> Helper loaded: my_helper
INFO - 2023-08-19 16:06:44 --> Database Driver Class Initialized
INFO - 2023-08-19 16:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:06:44 --> Controller Class Initialized
INFO - 2023-08-19 16:06:44 --> Final output sent to browser
DEBUG - 2023-08-19 16:06:44 --> Total execution time: 0.0282
INFO - 2023-08-19 16:06:46 --> Config Class Initialized
INFO - 2023-08-19 16:06:46 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:06:46 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:06:46 --> Utf8 Class Initialized
INFO - 2023-08-19 16:06:46 --> URI Class Initialized
INFO - 2023-08-19 16:06:46 --> Router Class Initialized
INFO - 2023-08-19 16:06:46 --> Output Class Initialized
INFO - 2023-08-19 16:06:46 --> Security Class Initialized
DEBUG - 2023-08-19 16:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:06:46 --> Input Class Initialized
INFO - 2023-08-19 16:06:46 --> Language Class Initialized
INFO - 2023-08-19 16:06:46 --> Language Class Initialized
INFO - 2023-08-19 16:06:46 --> Config Class Initialized
INFO - 2023-08-19 16:06:46 --> Loader Class Initialized
INFO - 2023-08-19 16:06:46 --> Helper loaded: url_helper
INFO - 2023-08-19 16:06:46 --> Helper loaded: file_helper
INFO - 2023-08-19 16:06:46 --> Helper loaded: form_helper
INFO - 2023-08-19 16:06:46 --> Helper loaded: my_helper
INFO - 2023-08-19 16:06:46 --> Database Driver Class Initialized
INFO - 2023-08-19 16:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:06:46 --> Controller Class Initialized
INFO - 2023-08-19 16:06:46 --> Final output sent to browser
DEBUG - 2023-08-19 16:06:46 --> Total execution time: 0.0392
INFO - 2023-08-19 16:06:55 --> Config Class Initialized
INFO - 2023-08-19 16:06:55 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:06:55 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:06:55 --> Utf8 Class Initialized
INFO - 2023-08-19 16:06:55 --> URI Class Initialized
INFO - 2023-08-19 16:06:55 --> Router Class Initialized
INFO - 2023-08-19 16:06:55 --> Output Class Initialized
INFO - 2023-08-19 16:06:55 --> Security Class Initialized
DEBUG - 2023-08-19 16:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:06:55 --> Input Class Initialized
INFO - 2023-08-19 16:06:55 --> Language Class Initialized
INFO - 2023-08-19 16:06:55 --> Language Class Initialized
INFO - 2023-08-19 16:06:55 --> Config Class Initialized
INFO - 2023-08-19 16:06:55 --> Loader Class Initialized
INFO - 2023-08-19 16:06:55 --> Helper loaded: url_helper
INFO - 2023-08-19 16:06:55 --> Helper loaded: file_helper
INFO - 2023-08-19 16:06:55 --> Helper loaded: form_helper
INFO - 2023-08-19 16:06:55 --> Helper loaded: my_helper
INFO - 2023-08-19 16:06:55 --> Database Driver Class Initialized
INFO - 2023-08-19 16:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:06:55 --> Controller Class Initialized
INFO - 2023-08-19 16:09:29 --> Config Class Initialized
INFO - 2023-08-19 16:09:29 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:09:29 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:09:29 --> Utf8 Class Initialized
INFO - 2023-08-19 16:09:29 --> URI Class Initialized
INFO - 2023-08-19 16:09:29 --> Router Class Initialized
INFO - 2023-08-19 16:09:29 --> Output Class Initialized
INFO - 2023-08-19 16:09:29 --> Security Class Initialized
DEBUG - 2023-08-19 16:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:09:29 --> Input Class Initialized
INFO - 2023-08-19 16:09:29 --> Language Class Initialized
INFO - 2023-08-19 16:09:29 --> Language Class Initialized
INFO - 2023-08-19 16:09:29 --> Config Class Initialized
INFO - 2023-08-19 16:09:29 --> Loader Class Initialized
INFO - 2023-08-19 16:09:29 --> Helper loaded: url_helper
INFO - 2023-08-19 16:09:29 --> Helper loaded: file_helper
INFO - 2023-08-19 16:09:29 --> Helper loaded: form_helper
INFO - 2023-08-19 16:09:29 --> Helper loaded: my_helper
INFO - 2023-08-19 16:09:29 --> Database Driver Class Initialized
INFO - 2023-08-19 16:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:09:29 --> Controller Class Initialized
DEBUG - 2023-08-19 16:09:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 16:09:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:09:29 --> Final output sent to browser
DEBUG - 2023-08-19 16:09:29 --> Total execution time: 0.0445
INFO - 2023-08-19 16:12:20 --> Config Class Initialized
INFO - 2023-08-19 16:12:20 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:12:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:12:20 --> Utf8 Class Initialized
INFO - 2023-08-19 16:12:20 --> URI Class Initialized
INFO - 2023-08-19 16:12:20 --> Router Class Initialized
INFO - 2023-08-19 16:12:20 --> Output Class Initialized
INFO - 2023-08-19 16:12:20 --> Security Class Initialized
DEBUG - 2023-08-19 16:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:12:20 --> Input Class Initialized
INFO - 2023-08-19 16:12:20 --> Language Class Initialized
INFO - 2023-08-19 16:12:20 --> Language Class Initialized
INFO - 2023-08-19 16:12:20 --> Config Class Initialized
INFO - 2023-08-19 16:12:20 --> Loader Class Initialized
INFO - 2023-08-19 16:12:20 --> Helper loaded: url_helper
INFO - 2023-08-19 16:12:20 --> Helper loaded: file_helper
INFO - 2023-08-19 16:12:20 --> Helper loaded: form_helper
INFO - 2023-08-19 16:12:20 --> Helper loaded: my_helper
INFO - 2023-08-19 16:12:20 --> Database Driver Class Initialized
INFO - 2023-08-19 16:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:12:20 --> Controller Class Initialized
DEBUG - 2023-08-19 16:12:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 16:12:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:12:20 --> Final output sent to browser
DEBUG - 2023-08-19 16:12:20 --> Total execution time: 0.0347
INFO - 2023-08-19 16:12:23 --> Config Class Initialized
INFO - 2023-08-19 16:12:23 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:12:23 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:12:23 --> Utf8 Class Initialized
INFO - 2023-08-19 16:12:23 --> URI Class Initialized
INFO - 2023-08-19 16:12:23 --> Router Class Initialized
INFO - 2023-08-19 16:12:23 --> Output Class Initialized
INFO - 2023-08-19 16:12:23 --> Security Class Initialized
DEBUG - 2023-08-19 16:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:12:23 --> Input Class Initialized
INFO - 2023-08-19 16:12:23 --> Language Class Initialized
INFO - 2023-08-19 16:12:23 --> Language Class Initialized
INFO - 2023-08-19 16:12:23 --> Config Class Initialized
INFO - 2023-08-19 16:12:23 --> Loader Class Initialized
INFO - 2023-08-19 16:12:23 --> Helper loaded: url_helper
INFO - 2023-08-19 16:12:23 --> Helper loaded: file_helper
INFO - 2023-08-19 16:12:23 --> Helper loaded: form_helper
INFO - 2023-08-19 16:12:23 --> Helper loaded: my_helper
INFO - 2023-08-19 16:12:23 --> Database Driver Class Initialized
INFO - 2023-08-19 16:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:12:23 --> Controller Class Initialized
DEBUG - 2023-08-19 16:12:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-08-19 16:12:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:12:23 --> Final output sent to browser
DEBUG - 2023-08-19 16:12:23 --> Total execution time: 0.0647
INFO - 2023-08-19 16:12:25 --> Config Class Initialized
INFO - 2023-08-19 16:12:25 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:12:25 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:12:25 --> Utf8 Class Initialized
INFO - 2023-08-19 16:12:25 --> URI Class Initialized
INFO - 2023-08-19 16:12:25 --> Router Class Initialized
INFO - 2023-08-19 16:12:25 --> Output Class Initialized
INFO - 2023-08-19 16:12:25 --> Security Class Initialized
DEBUG - 2023-08-19 16:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:12:25 --> Input Class Initialized
INFO - 2023-08-19 16:12:25 --> Language Class Initialized
INFO - 2023-08-19 16:12:25 --> Language Class Initialized
INFO - 2023-08-19 16:12:25 --> Config Class Initialized
INFO - 2023-08-19 16:12:25 --> Loader Class Initialized
INFO - 2023-08-19 16:12:25 --> Helper loaded: url_helper
INFO - 2023-08-19 16:12:25 --> Helper loaded: file_helper
INFO - 2023-08-19 16:12:25 --> Helper loaded: form_helper
INFO - 2023-08-19 16:12:25 --> Helper loaded: my_helper
INFO - 2023-08-19 16:12:25 --> Database Driver Class Initialized
INFO - 2023-08-19 16:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:12:25 --> Controller Class Initialized
INFO - 2023-08-19 16:12:25 --> Final output sent to browser
DEBUG - 2023-08-19 16:12:25 --> Total execution time: 0.0376
INFO - 2023-08-19 16:12:50 --> Config Class Initialized
INFO - 2023-08-19 16:12:50 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:12:50 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:12:50 --> Utf8 Class Initialized
INFO - 2023-08-19 16:12:50 --> URI Class Initialized
INFO - 2023-08-19 16:12:50 --> Router Class Initialized
INFO - 2023-08-19 16:12:50 --> Output Class Initialized
INFO - 2023-08-19 16:12:50 --> Security Class Initialized
DEBUG - 2023-08-19 16:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:12:50 --> Input Class Initialized
INFO - 2023-08-19 16:12:50 --> Language Class Initialized
INFO - 2023-08-19 16:12:50 --> Language Class Initialized
INFO - 2023-08-19 16:12:50 --> Config Class Initialized
INFO - 2023-08-19 16:12:50 --> Loader Class Initialized
INFO - 2023-08-19 16:12:50 --> Helper loaded: url_helper
INFO - 2023-08-19 16:12:50 --> Helper loaded: file_helper
INFO - 2023-08-19 16:12:50 --> Helper loaded: form_helper
INFO - 2023-08-19 16:12:50 --> Helper loaded: my_helper
INFO - 2023-08-19 16:12:50 --> Database Driver Class Initialized
INFO - 2023-08-19 16:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:12:50 --> Controller Class Initialized
DEBUG - 2023-08-19 16:12:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 16:12:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:12:50 --> Final output sent to browser
DEBUG - 2023-08-19 16:12:50 --> Total execution time: 0.0327
INFO - 2023-08-19 16:13:04 --> Config Class Initialized
INFO - 2023-08-19 16:13:04 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:13:04 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:13:04 --> Utf8 Class Initialized
INFO - 2023-08-19 16:13:04 --> URI Class Initialized
INFO - 2023-08-19 16:13:04 --> Router Class Initialized
INFO - 2023-08-19 16:13:04 --> Output Class Initialized
INFO - 2023-08-19 16:13:04 --> Security Class Initialized
DEBUG - 2023-08-19 16:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:13:04 --> Input Class Initialized
INFO - 2023-08-19 16:13:04 --> Language Class Initialized
INFO - 2023-08-19 16:13:04 --> Language Class Initialized
INFO - 2023-08-19 16:13:04 --> Config Class Initialized
INFO - 2023-08-19 16:13:04 --> Loader Class Initialized
INFO - 2023-08-19 16:13:04 --> Helper loaded: url_helper
INFO - 2023-08-19 16:13:04 --> Helper loaded: file_helper
INFO - 2023-08-19 16:13:04 --> Helper loaded: form_helper
INFO - 2023-08-19 16:13:04 --> Helper loaded: my_helper
INFO - 2023-08-19 16:13:04 --> Database Driver Class Initialized
INFO - 2023-08-19 16:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:13:04 --> Controller Class Initialized
DEBUG - 2023-08-19 16:13:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-08-19 16:13:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:13:04 --> Final output sent to browser
DEBUG - 2023-08-19 16:13:04 --> Total execution time: 0.0337
INFO - 2023-08-19 16:13:04 --> Config Class Initialized
INFO - 2023-08-19 16:13:04 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:13:04 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:13:04 --> Utf8 Class Initialized
INFO - 2023-08-19 16:13:04 --> URI Class Initialized
INFO - 2023-08-19 16:13:04 --> Router Class Initialized
INFO - 2023-08-19 16:13:04 --> Output Class Initialized
INFO - 2023-08-19 16:13:04 --> Security Class Initialized
DEBUG - 2023-08-19 16:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:13:04 --> Input Class Initialized
INFO - 2023-08-19 16:13:04 --> Language Class Initialized
INFO - 2023-08-19 16:13:04 --> Language Class Initialized
INFO - 2023-08-19 16:13:04 --> Config Class Initialized
INFO - 2023-08-19 16:13:04 --> Loader Class Initialized
INFO - 2023-08-19 16:13:04 --> Helper loaded: url_helper
INFO - 2023-08-19 16:13:04 --> Helper loaded: file_helper
INFO - 2023-08-19 16:13:04 --> Helper loaded: form_helper
INFO - 2023-08-19 16:13:04 --> Helper loaded: my_helper
INFO - 2023-08-19 16:13:04 --> Database Driver Class Initialized
INFO - 2023-08-19 16:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:13:04 --> Controller Class Initialized
INFO - 2023-08-19 16:13:53 --> Config Class Initialized
INFO - 2023-08-19 16:13:53 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:13:53 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:13:53 --> Utf8 Class Initialized
INFO - 2023-08-19 16:13:53 --> URI Class Initialized
INFO - 2023-08-19 16:13:53 --> Router Class Initialized
INFO - 2023-08-19 16:13:53 --> Output Class Initialized
INFO - 2023-08-19 16:13:53 --> Security Class Initialized
DEBUG - 2023-08-19 16:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:13:53 --> Input Class Initialized
INFO - 2023-08-19 16:13:53 --> Language Class Initialized
INFO - 2023-08-19 16:13:53 --> Language Class Initialized
INFO - 2023-08-19 16:13:53 --> Config Class Initialized
INFO - 2023-08-19 16:13:53 --> Loader Class Initialized
INFO - 2023-08-19 16:13:53 --> Helper loaded: url_helper
INFO - 2023-08-19 16:13:53 --> Helper loaded: file_helper
INFO - 2023-08-19 16:13:53 --> Helper loaded: form_helper
INFO - 2023-08-19 16:13:53 --> Helper loaded: my_helper
INFO - 2023-08-19 16:13:53 --> Database Driver Class Initialized
INFO - 2023-08-19 16:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:13:53 --> Controller Class Initialized
DEBUG - 2023-08-19 16:13:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 16:13:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:13:53 --> Final output sent to browser
DEBUG - 2023-08-19 16:13:53 --> Total execution time: 0.0659
INFO - 2023-08-19 16:13:57 --> Config Class Initialized
INFO - 2023-08-19 16:13:57 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:13:57 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:13:57 --> Utf8 Class Initialized
INFO - 2023-08-19 16:13:57 --> URI Class Initialized
INFO - 2023-08-19 16:13:57 --> Router Class Initialized
INFO - 2023-08-19 16:13:57 --> Output Class Initialized
INFO - 2023-08-19 16:13:57 --> Security Class Initialized
DEBUG - 2023-08-19 16:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:13:57 --> Input Class Initialized
INFO - 2023-08-19 16:13:57 --> Language Class Initialized
INFO - 2023-08-19 16:13:57 --> Language Class Initialized
INFO - 2023-08-19 16:13:57 --> Config Class Initialized
INFO - 2023-08-19 16:13:57 --> Loader Class Initialized
INFO - 2023-08-19 16:13:57 --> Helper loaded: url_helper
INFO - 2023-08-19 16:13:57 --> Helper loaded: file_helper
INFO - 2023-08-19 16:13:57 --> Helper loaded: form_helper
INFO - 2023-08-19 16:13:57 --> Helper loaded: my_helper
INFO - 2023-08-19 16:13:57 --> Database Driver Class Initialized
INFO - 2023-08-19 16:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:13:57 --> Controller Class Initialized
DEBUG - 2023-08-19 16:13:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-08-19 16:13:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:13:57 --> Final output sent to browser
DEBUG - 2023-08-19 16:13:57 --> Total execution time: 0.0515
INFO - 2023-08-19 16:13:58 --> Config Class Initialized
INFO - 2023-08-19 16:13:58 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:13:58 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:13:58 --> Utf8 Class Initialized
INFO - 2023-08-19 16:13:58 --> URI Class Initialized
INFO - 2023-08-19 16:13:58 --> Router Class Initialized
INFO - 2023-08-19 16:13:58 --> Output Class Initialized
INFO - 2023-08-19 16:13:58 --> Security Class Initialized
DEBUG - 2023-08-19 16:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:13:58 --> Input Class Initialized
INFO - 2023-08-19 16:13:58 --> Language Class Initialized
INFO - 2023-08-19 16:13:58 --> Language Class Initialized
INFO - 2023-08-19 16:13:58 --> Config Class Initialized
INFO - 2023-08-19 16:13:58 --> Loader Class Initialized
INFO - 2023-08-19 16:13:58 --> Helper loaded: url_helper
INFO - 2023-08-19 16:13:58 --> Helper loaded: file_helper
INFO - 2023-08-19 16:13:58 --> Helper loaded: form_helper
INFO - 2023-08-19 16:13:58 --> Helper loaded: my_helper
INFO - 2023-08-19 16:13:58 --> Database Driver Class Initialized
INFO - 2023-08-19 16:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:13:58 --> Controller Class Initialized
INFO - 2023-08-19 16:14:20 --> Config Class Initialized
INFO - 2023-08-19 16:14:20 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:14:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:14:20 --> Utf8 Class Initialized
INFO - 2023-08-19 16:14:20 --> URI Class Initialized
INFO - 2023-08-19 16:14:20 --> Router Class Initialized
INFO - 2023-08-19 16:14:20 --> Output Class Initialized
INFO - 2023-08-19 16:14:20 --> Security Class Initialized
DEBUG - 2023-08-19 16:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:14:20 --> Input Class Initialized
INFO - 2023-08-19 16:14:20 --> Language Class Initialized
INFO - 2023-08-19 16:14:20 --> Language Class Initialized
INFO - 2023-08-19 16:14:20 --> Config Class Initialized
INFO - 2023-08-19 16:14:20 --> Loader Class Initialized
INFO - 2023-08-19 16:14:20 --> Helper loaded: url_helper
INFO - 2023-08-19 16:14:20 --> Helper loaded: file_helper
INFO - 2023-08-19 16:14:20 --> Helper loaded: form_helper
INFO - 2023-08-19 16:14:20 --> Helper loaded: my_helper
INFO - 2023-08-19 16:14:20 --> Database Driver Class Initialized
INFO - 2023-08-19 16:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:14:20 --> Controller Class Initialized
INFO - 2023-08-19 16:14:20 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:14:20 --> Config Class Initialized
INFO - 2023-08-19 16:14:20 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:14:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:14:20 --> Utf8 Class Initialized
INFO - 2023-08-19 16:14:20 --> URI Class Initialized
INFO - 2023-08-19 16:14:20 --> Router Class Initialized
INFO - 2023-08-19 16:14:20 --> Output Class Initialized
INFO - 2023-08-19 16:14:20 --> Security Class Initialized
DEBUG - 2023-08-19 16:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:14:20 --> Input Class Initialized
INFO - 2023-08-19 16:14:20 --> Language Class Initialized
INFO - 2023-08-19 16:14:20 --> Language Class Initialized
INFO - 2023-08-19 16:14:20 --> Config Class Initialized
INFO - 2023-08-19 16:14:20 --> Loader Class Initialized
INFO - 2023-08-19 16:14:20 --> Helper loaded: url_helper
INFO - 2023-08-19 16:14:20 --> Helper loaded: file_helper
INFO - 2023-08-19 16:14:20 --> Helper loaded: form_helper
INFO - 2023-08-19 16:14:20 --> Helper loaded: my_helper
INFO - 2023-08-19 16:14:20 --> Database Driver Class Initialized
INFO - 2023-08-19 16:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:14:20 --> Controller Class Initialized
INFO - 2023-08-19 16:14:20 --> Config Class Initialized
INFO - 2023-08-19 16:14:20 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:14:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:14:20 --> Utf8 Class Initialized
INFO - 2023-08-19 16:14:20 --> URI Class Initialized
INFO - 2023-08-19 16:14:20 --> Router Class Initialized
INFO - 2023-08-19 16:14:20 --> Output Class Initialized
INFO - 2023-08-19 16:14:20 --> Security Class Initialized
DEBUG - 2023-08-19 16:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:14:20 --> Input Class Initialized
INFO - 2023-08-19 16:14:20 --> Language Class Initialized
INFO - 2023-08-19 16:14:20 --> Language Class Initialized
INFO - 2023-08-19 16:14:20 --> Config Class Initialized
INFO - 2023-08-19 16:14:20 --> Loader Class Initialized
INFO - 2023-08-19 16:14:20 --> Helper loaded: url_helper
INFO - 2023-08-19 16:14:20 --> Helper loaded: file_helper
INFO - 2023-08-19 16:14:20 --> Helper loaded: form_helper
INFO - 2023-08-19 16:14:20 --> Helper loaded: my_helper
INFO - 2023-08-19 16:14:20 --> Database Driver Class Initialized
INFO - 2023-08-19 16:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:14:20 --> Controller Class Initialized
DEBUG - 2023-08-19 16:14:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-08-19 16:14:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:14:20 --> Final output sent to browser
DEBUG - 2023-08-19 16:14:20 --> Total execution time: 0.0328
INFO - 2023-08-19 16:15:54 --> Config Class Initialized
INFO - 2023-08-19 16:15:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:15:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:15:54 --> Utf8 Class Initialized
INFO - 2023-08-19 16:15:54 --> URI Class Initialized
INFO - 2023-08-19 16:15:54 --> Router Class Initialized
INFO - 2023-08-19 16:15:54 --> Output Class Initialized
INFO - 2023-08-19 16:15:54 --> Security Class Initialized
DEBUG - 2023-08-19 16:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:15:54 --> Input Class Initialized
INFO - 2023-08-19 16:15:54 --> Language Class Initialized
INFO - 2023-08-19 16:15:54 --> Language Class Initialized
INFO - 2023-08-19 16:15:54 --> Config Class Initialized
INFO - 2023-08-19 16:15:54 --> Loader Class Initialized
INFO - 2023-08-19 16:15:54 --> Helper loaded: url_helper
INFO - 2023-08-19 16:15:54 --> Helper loaded: file_helper
INFO - 2023-08-19 16:15:54 --> Helper loaded: form_helper
INFO - 2023-08-19 16:15:54 --> Helper loaded: my_helper
INFO - 2023-08-19 16:15:54 --> Database Driver Class Initialized
INFO - 2023-08-19 16:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:15:54 --> Controller Class Initialized
INFO - 2023-08-19 16:15:54 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:15:55 --> Config Class Initialized
INFO - 2023-08-19 16:15:55 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:15:55 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:15:55 --> Utf8 Class Initialized
INFO - 2023-08-19 16:15:55 --> URI Class Initialized
INFO - 2023-08-19 16:15:55 --> Router Class Initialized
INFO - 2023-08-19 16:15:55 --> Output Class Initialized
INFO - 2023-08-19 16:15:55 --> Security Class Initialized
DEBUG - 2023-08-19 16:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:15:55 --> Input Class Initialized
INFO - 2023-08-19 16:15:55 --> Language Class Initialized
INFO - 2023-08-19 16:15:55 --> Language Class Initialized
INFO - 2023-08-19 16:15:55 --> Config Class Initialized
INFO - 2023-08-19 16:15:55 --> Loader Class Initialized
INFO - 2023-08-19 16:15:55 --> Helper loaded: url_helper
INFO - 2023-08-19 16:15:55 --> Helper loaded: file_helper
INFO - 2023-08-19 16:15:55 --> Helper loaded: form_helper
INFO - 2023-08-19 16:15:55 --> Helper loaded: my_helper
INFO - 2023-08-19 16:15:55 --> Database Driver Class Initialized
INFO - 2023-08-19 16:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:15:55 --> Controller Class Initialized
INFO - 2023-08-19 16:15:55 --> Config Class Initialized
INFO - 2023-08-19 16:15:55 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:15:55 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:15:55 --> Utf8 Class Initialized
INFO - 2023-08-19 16:15:55 --> URI Class Initialized
INFO - 2023-08-19 16:15:55 --> Router Class Initialized
INFO - 2023-08-19 16:15:55 --> Output Class Initialized
INFO - 2023-08-19 16:15:55 --> Security Class Initialized
DEBUG - 2023-08-19 16:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:15:55 --> Input Class Initialized
INFO - 2023-08-19 16:15:55 --> Language Class Initialized
INFO - 2023-08-19 16:15:55 --> Language Class Initialized
INFO - 2023-08-19 16:15:55 --> Config Class Initialized
INFO - 2023-08-19 16:15:55 --> Loader Class Initialized
INFO - 2023-08-19 16:15:55 --> Helper loaded: url_helper
INFO - 2023-08-19 16:15:55 --> Helper loaded: file_helper
INFO - 2023-08-19 16:15:55 --> Helper loaded: form_helper
INFO - 2023-08-19 16:15:55 --> Helper loaded: my_helper
INFO - 2023-08-19 16:15:55 --> Database Driver Class Initialized
INFO - 2023-08-19 16:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:15:55 --> Controller Class Initialized
DEBUG - 2023-08-19 16:15:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-08-19 16:15:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:15:55 --> Final output sent to browser
DEBUG - 2023-08-19 16:15:55 --> Total execution time: 0.0346
INFO - 2023-08-19 16:16:02 --> Config Class Initialized
INFO - 2023-08-19 16:16:02 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:16:02 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:16:02 --> Utf8 Class Initialized
INFO - 2023-08-19 16:16:02 --> URI Class Initialized
DEBUG - 2023-08-19 16:16:02 --> No URI present. Default controller set.
INFO - 2023-08-19 16:16:02 --> Router Class Initialized
INFO - 2023-08-19 16:16:02 --> Output Class Initialized
INFO - 2023-08-19 16:16:02 --> Security Class Initialized
DEBUG - 2023-08-19 16:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:16:02 --> Input Class Initialized
INFO - 2023-08-19 16:16:02 --> Language Class Initialized
INFO - 2023-08-19 16:16:02 --> Language Class Initialized
INFO - 2023-08-19 16:16:02 --> Config Class Initialized
INFO - 2023-08-19 16:16:02 --> Loader Class Initialized
INFO - 2023-08-19 16:16:02 --> Helper loaded: url_helper
INFO - 2023-08-19 16:16:02 --> Helper loaded: file_helper
INFO - 2023-08-19 16:16:02 --> Helper loaded: form_helper
INFO - 2023-08-19 16:16:02 --> Helper loaded: my_helper
INFO - 2023-08-19 16:16:02 --> Database Driver Class Initialized
INFO - 2023-08-19 16:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:16:02 --> Controller Class Initialized
INFO - 2023-08-19 16:16:02 --> Config Class Initialized
INFO - 2023-08-19 16:16:02 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:16:02 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:16:02 --> Utf8 Class Initialized
INFO - 2023-08-19 16:16:02 --> URI Class Initialized
INFO - 2023-08-19 16:16:02 --> Router Class Initialized
INFO - 2023-08-19 16:16:02 --> Output Class Initialized
INFO - 2023-08-19 16:16:02 --> Security Class Initialized
DEBUG - 2023-08-19 16:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:16:02 --> Input Class Initialized
INFO - 2023-08-19 16:16:02 --> Language Class Initialized
INFO - 2023-08-19 16:16:02 --> Language Class Initialized
INFO - 2023-08-19 16:16:02 --> Config Class Initialized
INFO - 2023-08-19 16:16:02 --> Loader Class Initialized
INFO - 2023-08-19 16:16:02 --> Helper loaded: url_helper
INFO - 2023-08-19 16:16:02 --> Helper loaded: file_helper
INFO - 2023-08-19 16:16:02 --> Helper loaded: form_helper
INFO - 2023-08-19 16:16:02 --> Helper loaded: my_helper
INFO - 2023-08-19 16:16:02 --> Database Driver Class Initialized
INFO - 2023-08-19 16:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:16:02 --> Controller Class Initialized
DEBUG - 2023-08-19 16:16:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-08-19 16:16:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:16:02 --> Final output sent to browser
DEBUG - 2023-08-19 16:16:02 --> Total execution time: 0.1014
INFO - 2023-08-19 16:16:05 --> Config Class Initialized
INFO - 2023-08-19 16:16:05 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:16:05 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:16:05 --> Utf8 Class Initialized
INFO - 2023-08-19 16:16:05 --> URI Class Initialized
DEBUG - 2023-08-19 16:16:05 --> No URI present. Default controller set.
INFO - 2023-08-19 16:16:05 --> Router Class Initialized
INFO - 2023-08-19 16:16:05 --> Output Class Initialized
INFO - 2023-08-19 16:16:05 --> Security Class Initialized
DEBUG - 2023-08-19 16:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:16:05 --> Input Class Initialized
INFO - 2023-08-19 16:16:05 --> Language Class Initialized
INFO - 2023-08-19 16:16:05 --> Language Class Initialized
INFO - 2023-08-19 16:16:05 --> Config Class Initialized
INFO - 2023-08-19 16:16:05 --> Loader Class Initialized
INFO - 2023-08-19 16:16:05 --> Helper loaded: url_helper
INFO - 2023-08-19 16:16:05 --> Helper loaded: file_helper
INFO - 2023-08-19 16:16:05 --> Helper loaded: form_helper
INFO - 2023-08-19 16:16:05 --> Helper loaded: my_helper
INFO - 2023-08-19 16:16:05 --> Database Driver Class Initialized
INFO - 2023-08-19 16:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:16:05 --> Controller Class Initialized
INFO - 2023-08-19 16:16:05 --> Config Class Initialized
INFO - 2023-08-19 16:16:05 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:16:05 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:16:05 --> Utf8 Class Initialized
INFO - 2023-08-19 16:16:05 --> URI Class Initialized
INFO - 2023-08-19 16:16:05 --> Router Class Initialized
INFO - 2023-08-19 16:16:05 --> Output Class Initialized
INFO - 2023-08-19 16:16:05 --> Security Class Initialized
DEBUG - 2023-08-19 16:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:16:05 --> Input Class Initialized
INFO - 2023-08-19 16:16:05 --> Language Class Initialized
INFO - 2023-08-19 16:16:05 --> Language Class Initialized
INFO - 2023-08-19 16:16:05 --> Config Class Initialized
INFO - 2023-08-19 16:16:05 --> Loader Class Initialized
INFO - 2023-08-19 16:16:05 --> Helper loaded: url_helper
INFO - 2023-08-19 16:16:05 --> Helper loaded: file_helper
INFO - 2023-08-19 16:16:05 --> Helper loaded: form_helper
INFO - 2023-08-19 16:16:05 --> Helper loaded: my_helper
INFO - 2023-08-19 16:16:05 --> Database Driver Class Initialized
INFO - 2023-08-19 16:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:16:05 --> Controller Class Initialized
DEBUG - 2023-08-19 16:16:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-08-19 16:16:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:16:05 --> Final output sent to browser
DEBUG - 2023-08-19 16:16:05 --> Total execution time: 0.0314
INFO - 2023-08-19 16:16:06 --> Config Class Initialized
INFO - 2023-08-19 16:16:06 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:16:06 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:16:06 --> Utf8 Class Initialized
INFO - 2023-08-19 16:16:06 --> URI Class Initialized
DEBUG - 2023-08-19 16:16:06 --> No URI present. Default controller set.
INFO - 2023-08-19 16:16:06 --> Router Class Initialized
INFO - 2023-08-19 16:16:06 --> Output Class Initialized
INFO - 2023-08-19 16:16:06 --> Security Class Initialized
DEBUG - 2023-08-19 16:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:16:06 --> Input Class Initialized
INFO - 2023-08-19 16:16:06 --> Language Class Initialized
INFO - 2023-08-19 16:16:06 --> Language Class Initialized
INFO - 2023-08-19 16:16:06 --> Config Class Initialized
INFO - 2023-08-19 16:16:06 --> Loader Class Initialized
INFO - 2023-08-19 16:16:06 --> Helper loaded: url_helper
INFO - 2023-08-19 16:16:06 --> Helper loaded: file_helper
INFO - 2023-08-19 16:16:06 --> Helper loaded: form_helper
INFO - 2023-08-19 16:16:06 --> Helper loaded: my_helper
INFO - 2023-08-19 16:16:06 --> Database Driver Class Initialized
INFO - 2023-08-19 16:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:16:06 --> Controller Class Initialized
INFO - 2023-08-19 16:16:06 --> Config Class Initialized
INFO - 2023-08-19 16:16:06 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:16:06 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:16:06 --> Utf8 Class Initialized
INFO - 2023-08-19 16:16:06 --> URI Class Initialized
INFO - 2023-08-19 16:16:06 --> Router Class Initialized
INFO - 2023-08-19 16:16:06 --> Output Class Initialized
INFO - 2023-08-19 16:16:06 --> Security Class Initialized
DEBUG - 2023-08-19 16:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:16:06 --> Input Class Initialized
INFO - 2023-08-19 16:16:06 --> Language Class Initialized
INFO - 2023-08-19 16:16:06 --> Language Class Initialized
INFO - 2023-08-19 16:16:06 --> Config Class Initialized
INFO - 2023-08-19 16:16:06 --> Loader Class Initialized
INFO - 2023-08-19 16:16:06 --> Helper loaded: url_helper
INFO - 2023-08-19 16:16:06 --> Helper loaded: file_helper
INFO - 2023-08-19 16:16:06 --> Helper loaded: form_helper
INFO - 2023-08-19 16:16:06 --> Helper loaded: my_helper
INFO - 2023-08-19 16:16:06 --> Database Driver Class Initialized
INFO - 2023-08-19 16:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:16:06 --> Controller Class Initialized
DEBUG - 2023-08-19 16:16:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-08-19 16:16:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:16:06 --> Final output sent to browser
DEBUG - 2023-08-19 16:16:06 --> Total execution time: 0.0325
INFO - 2023-08-19 16:16:07 --> Config Class Initialized
INFO - 2023-08-19 16:16:07 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:16:07 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:16:07 --> Utf8 Class Initialized
INFO - 2023-08-19 16:16:07 --> URI Class Initialized
INFO - 2023-08-19 16:16:07 --> Router Class Initialized
INFO - 2023-08-19 16:16:07 --> Output Class Initialized
INFO - 2023-08-19 16:16:07 --> Security Class Initialized
DEBUG - 2023-08-19 16:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:16:07 --> Input Class Initialized
INFO - 2023-08-19 16:16:07 --> Language Class Initialized
INFO - 2023-08-19 16:16:07 --> Language Class Initialized
INFO - 2023-08-19 16:16:07 --> Config Class Initialized
INFO - 2023-08-19 16:16:07 --> Loader Class Initialized
INFO - 2023-08-19 16:16:07 --> Helper loaded: url_helper
INFO - 2023-08-19 16:16:07 --> Helper loaded: file_helper
INFO - 2023-08-19 16:16:07 --> Helper loaded: form_helper
INFO - 2023-08-19 16:16:07 --> Helper loaded: my_helper
INFO - 2023-08-19 16:16:07 --> Database Driver Class Initialized
INFO - 2023-08-19 16:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:16:07 --> Controller Class Initialized
DEBUG - 2023-08-19 16:16:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-08-19 16:16:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:16:07 --> Final output sent to browser
DEBUG - 2023-08-19 16:16:07 --> Total execution time: 0.0540
INFO - 2023-08-19 16:16:12 --> Config Class Initialized
INFO - 2023-08-19 16:16:12 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:16:12 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:16:12 --> Utf8 Class Initialized
INFO - 2023-08-19 16:16:12 --> URI Class Initialized
DEBUG - 2023-08-19 16:16:12 --> No URI present. Default controller set.
INFO - 2023-08-19 16:16:12 --> Router Class Initialized
INFO - 2023-08-19 16:16:12 --> Output Class Initialized
INFO - 2023-08-19 16:16:12 --> Security Class Initialized
DEBUG - 2023-08-19 16:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:16:12 --> Input Class Initialized
INFO - 2023-08-19 16:16:12 --> Language Class Initialized
INFO - 2023-08-19 16:16:12 --> Language Class Initialized
INFO - 2023-08-19 16:16:12 --> Config Class Initialized
INFO - 2023-08-19 16:16:12 --> Loader Class Initialized
INFO - 2023-08-19 16:16:12 --> Helper loaded: url_helper
INFO - 2023-08-19 16:16:12 --> Helper loaded: file_helper
INFO - 2023-08-19 16:16:12 --> Helper loaded: form_helper
INFO - 2023-08-19 16:16:12 --> Helper loaded: my_helper
INFO - 2023-08-19 16:16:12 --> Database Driver Class Initialized
INFO - 2023-08-19 16:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:16:12 --> Controller Class Initialized
INFO - 2023-08-19 16:16:12 --> Config Class Initialized
INFO - 2023-08-19 16:16:12 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:16:12 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:16:12 --> Utf8 Class Initialized
INFO - 2023-08-19 16:16:12 --> URI Class Initialized
INFO - 2023-08-19 16:16:12 --> Router Class Initialized
INFO - 2023-08-19 16:16:12 --> Output Class Initialized
INFO - 2023-08-19 16:16:12 --> Security Class Initialized
DEBUG - 2023-08-19 16:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:16:12 --> Input Class Initialized
INFO - 2023-08-19 16:16:12 --> Language Class Initialized
INFO - 2023-08-19 16:16:12 --> Language Class Initialized
INFO - 2023-08-19 16:16:12 --> Config Class Initialized
INFO - 2023-08-19 16:16:12 --> Loader Class Initialized
INFO - 2023-08-19 16:16:12 --> Helper loaded: url_helper
INFO - 2023-08-19 16:16:12 --> Helper loaded: file_helper
INFO - 2023-08-19 16:16:12 --> Helper loaded: form_helper
INFO - 2023-08-19 16:16:12 --> Helper loaded: my_helper
INFO - 2023-08-19 16:16:12 --> Database Driver Class Initialized
INFO - 2023-08-19 16:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:16:12 --> Controller Class Initialized
DEBUG - 2023-08-19 16:16:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-08-19 16:16:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:16:12 --> Final output sent to browser
DEBUG - 2023-08-19 16:16:12 --> Total execution time: 0.0360
INFO - 2023-08-19 16:16:22 --> Config Class Initialized
INFO - 2023-08-19 16:16:22 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:16:22 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:16:22 --> Utf8 Class Initialized
INFO - 2023-08-19 16:16:22 --> URI Class Initialized
DEBUG - 2023-08-19 16:16:22 --> No URI present. Default controller set.
INFO - 2023-08-19 16:16:22 --> Router Class Initialized
INFO - 2023-08-19 16:16:22 --> Output Class Initialized
INFO - 2023-08-19 16:16:22 --> Security Class Initialized
DEBUG - 2023-08-19 16:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:16:22 --> Input Class Initialized
INFO - 2023-08-19 16:16:22 --> Language Class Initialized
INFO - 2023-08-19 16:16:22 --> Language Class Initialized
INFO - 2023-08-19 16:16:22 --> Config Class Initialized
INFO - 2023-08-19 16:16:22 --> Loader Class Initialized
INFO - 2023-08-19 16:16:22 --> Helper loaded: url_helper
INFO - 2023-08-19 16:16:22 --> Helper loaded: file_helper
INFO - 2023-08-19 16:16:22 --> Helper loaded: form_helper
INFO - 2023-08-19 16:16:22 --> Helper loaded: my_helper
INFO - 2023-08-19 16:16:22 --> Database Driver Class Initialized
INFO - 2023-08-19 16:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:16:22 --> Controller Class Initialized
INFO - 2023-08-19 16:16:22 --> Config Class Initialized
INFO - 2023-08-19 16:16:22 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:16:22 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:16:22 --> Utf8 Class Initialized
INFO - 2023-08-19 16:16:22 --> URI Class Initialized
INFO - 2023-08-19 16:16:22 --> Router Class Initialized
INFO - 2023-08-19 16:16:22 --> Output Class Initialized
INFO - 2023-08-19 16:16:22 --> Security Class Initialized
DEBUG - 2023-08-19 16:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:16:22 --> Input Class Initialized
INFO - 2023-08-19 16:16:22 --> Language Class Initialized
INFO - 2023-08-19 16:16:22 --> Language Class Initialized
INFO - 2023-08-19 16:16:22 --> Config Class Initialized
INFO - 2023-08-19 16:16:22 --> Loader Class Initialized
INFO - 2023-08-19 16:16:22 --> Helper loaded: url_helper
INFO - 2023-08-19 16:16:22 --> Helper loaded: file_helper
INFO - 2023-08-19 16:16:22 --> Helper loaded: form_helper
INFO - 2023-08-19 16:16:22 --> Helper loaded: my_helper
INFO - 2023-08-19 16:16:22 --> Database Driver Class Initialized
INFO - 2023-08-19 16:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:16:22 --> Controller Class Initialized
DEBUG - 2023-08-19 16:16:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-08-19 16:16:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:16:22 --> Final output sent to browser
DEBUG - 2023-08-19 16:16:22 --> Total execution time: 0.0310
INFO - 2023-08-19 16:16:24 --> Config Class Initialized
INFO - 2023-08-19 16:16:24 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:16:24 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:16:24 --> Utf8 Class Initialized
INFO - 2023-08-19 16:16:24 --> URI Class Initialized
DEBUG - 2023-08-19 16:16:24 --> No URI present. Default controller set.
INFO - 2023-08-19 16:16:24 --> Router Class Initialized
INFO - 2023-08-19 16:16:24 --> Output Class Initialized
INFO - 2023-08-19 16:16:24 --> Security Class Initialized
DEBUG - 2023-08-19 16:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:16:24 --> Input Class Initialized
INFO - 2023-08-19 16:16:24 --> Language Class Initialized
INFO - 2023-08-19 16:16:24 --> Language Class Initialized
INFO - 2023-08-19 16:16:24 --> Config Class Initialized
INFO - 2023-08-19 16:16:24 --> Loader Class Initialized
INFO - 2023-08-19 16:16:24 --> Helper loaded: url_helper
INFO - 2023-08-19 16:16:24 --> Helper loaded: file_helper
INFO - 2023-08-19 16:16:24 --> Helper loaded: form_helper
INFO - 2023-08-19 16:16:24 --> Helper loaded: my_helper
INFO - 2023-08-19 16:16:24 --> Database Driver Class Initialized
INFO - 2023-08-19 16:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:16:24 --> Controller Class Initialized
INFO - 2023-08-19 16:16:24 --> Config Class Initialized
INFO - 2023-08-19 16:16:24 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:16:24 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:16:24 --> Utf8 Class Initialized
INFO - 2023-08-19 16:16:24 --> URI Class Initialized
INFO - 2023-08-19 16:16:24 --> Router Class Initialized
INFO - 2023-08-19 16:16:24 --> Output Class Initialized
INFO - 2023-08-19 16:16:24 --> Security Class Initialized
DEBUG - 2023-08-19 16:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:16:24 --> Input Class Initialized
INFO - 2023-08-19 16:16:24 --> Language Class Initialized
INFO - 2023-08-19 16:16:24 --> Language Class Initialized
INFO - 2023-08-19 16:16:24 --> Config Class Initialized
INFO - 2023-08-19 16:16:24 --> Loader Class Initialized
INFO - 2023-08-19 16:16:24 --> Helper loaded: url_helper
INFO - 2023-08-19 16:16:24 --> Helper loaded: file_helper
INFO - 2023-08-19 16:16:24 --> Helper loaded: form_helper
INFO - 2023-08-19 16:16:24 --> Helper loaded: my_helper
INFO - 2023-08-19 16:16:24 --> Database Driver Class Initialized
INFO - 2023-08-19 16:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:16:24 --> Controller Class Initialized
DEBUG - 2023-08-19 16:16:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-08-19 16:16:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:16:24 --> Final output sent to browser
DEBUG - 2023-08-19 16:16:24 --> Total execution time: 0.0311
INFO - 2023-08-19 16:16:25 --> Config Class Initialized
INFO - 2023-08-19 16:16:25 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:16:25 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:16:25 --> Utf8 Class Initialized
INFO - 2023-08-19 16:16:25 --> URI Class Initialized
DEBUG - 2023-08-19 16:16:25 --> No URI present. Default controller set.
INFO - 2023-08-19 16:16:25 --> Router Class Initialized
INFO - 2023-08-19 16:16:25 --> Output Class Initialized
INFO - 2023-08-19 16:16:25 --> Security Class Initialized
DEBUG - 2023-08-19 16:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:16:25 --> Input Class Initialized
INFO - 2023-08-19 16:16:25 --> Language Class Initialized
INFO - 2023-08-19 16:16:25 --> Language Class Initialized
INFO - 2023-08-19 16:16:25 --> Config Class Initialized
INFO - 2023-08-19 16:16:25 --> Loader Class Initialized
INFO - 2023-08-19 16:16:25 --> Helper loaded: url_helper
INFO - 2023-08-19 16:16:25 --> Helper loaded: file_helper
INFO - 2023-08-19 16:16:25 --> Helper loaded: form_helper
INFO - 2023-08-19 16:16:25 --> Helper loaded: my_helper
INFO - 2023-08-19 16:16:25 --> Database Driver Class Initialized
INFO - 2023-08-19 16:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:16:25 --> Controller Class Initialized
INFO - 2023-08-19 16:16:25 --> Config Class Initialized
INFO - 2023-08-19 16:16:25 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:16:25 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:16:25 --> Utf8 Class Initialized
INFO - 2023-08-19 16:16:25 --> URI Class Initialized
INFO - 2023-08-19 16:16:25 --> Router Class Initialized
INFO - 2023-08-19 16:16:25 --> Output Class Initialized
INFO - 2023-08-19 16:16:25 --> Security Class Initialized
DEBUG - 2023-08-19 16:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:16:25 --> Input Class Initialized
INFO - 2023-08-19 16:16:25 --> Language Class Initialized
INFO - 2023-08-19 16:16:25 --> Language Class Initialized
INFO - 2023-08-19 16:16:25 --> Config Class Initialized
INFO - 2023-08-19 16:16:25 --> Loader Class Initialized
INFO - 2023-08-19 16:16:25 --> Helper loaded: url_helper
INFO - 2023-08-19 16:16:25 --> Helper loaded: file_helper
INFO - 2023-08-19 16:16:25 --> Helper loaded: form_helper
INFO - 2023-08-19 16:16:25 --> Helper loaded: my_helper
INFO - 2023-08-19 16:16:25 --> Database Driver Class Initialized
INFO - 2023-08-19 16:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:16:25 --> Controller Class Initialized
DEBUG - 2023-08-19 16:16:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-08-19 16:16:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:16:25 --> Final output sent to browser
DEBUG - 2023-08-19 16:16:25 --> Total execution time: 0.0311
INFO - 2023-08-19 16:18:13 --> Config Class Initialized
INFO - 2023-08-19 16:18:13 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:18:13 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:18:13 --> Utf8 Class Initialized
INFO - 2023-08-19 16:18:13 --> URI Class Initialized
DEBUG - 2023-08-19 16:18:13 --> No URI present. Default controller set.
INFO - 2023-08-19 16:18:13 --> Router Class Initialized
INFO - 2023-08-19 16:18:13 --> Output Class Initialized
INFO - 2023-08-19 16:18:13 --> Security Class Initialized
DEBUG - 2023-08-19 16:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:18:13 --> Input Class Initialized
INFO - 2023-08-19 16:18:13 --> Language Class Initialized
INFO - 2023-08-19 16:18:13 --> Language Class Initialized
INFO - 2023-08-19 16:18:13 --> Config Class Initialized
INFO - 2023-08-19 16:18:13 --> Loader Class Initialized
INFO - 2023-08-19 16:18:13 --> Helper loaded: url_helper
INFO - 2023-08-19 16:18:13 --> Helper loaded: file_helper
INFO - 2023-08-19 16:18:13 --> Helper loaded: form_helper
INFO - 2023-08-19 16:18:14 --> Helper loaded: my_helper
INFO - 2023-08-19 16:18:14 --> Database Driver Class Initialized
INFO - 2023-08-19 16:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:18:14 --> Controller Class Initialized
DEBUG - 2023-08-19 16:18:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 16:18:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:18:14 --> Final output sent to browser
DEBUG - 2023-08-19 16:18:14 --> Total execution time: 0.0332
INFO - 2023-08-19 16:18:19 --> Config Class Initialized
INFO - 2023-08-19 16:18:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:18:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:18:19 --> Utf8 Class Initialized
INFO - 2023-08-19 16:18:19 --> URI Class Initialized
INFO - 2023-08-19 16:18:19 --> Router Class Initialized
INFO - 2023-08-19 16:18:19 --> Output Class Initialized
INFO - 2023-08-19 16:18:19 --> Security Class Initialized
DEBUG - 2023-08-19 16:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:18:19 --> Input Class Initialized
INFO - 2023-08-19 16:18:19 --> Language Class Initialized
INFO - 2023-08-19 16:18:19 --> Language Class Initialized
INFO - 2023-08-19 16:18:19 --> Config Class Initialized
INFO - 2023-08-19 16:18:19 --> Loader Class Initialized
INFO - 2023-08-19 16:18:19 --> Helper loaded: url_helper
INFO - 2023-08-19 16:18:19 --> Helper loaded: file_helper
INFO - 2023-08-19 16:18:19 --> Helper loaded: form_helper
INFO - 2023-08-19 16:18:19 --> Helper loaded: my_helper
INFO - 2023-08-19 16:18:19 --> Database Driver Class Initialized
INFO - 2023-08-19 16:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:18:19 --> Controller Class Initialized
DEBUG - 2023-08-19 16:18:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 16:18:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:18:19 --> Final output sent to browser
DEBUG - 2023-08-19 16:18:19 --> Total execution time: 0.0339
INFO - 2023-08-19 16:19:05 --> Config Class Initialized
INFO - 2023-08-19 16:19:05 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:19:05 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:19:05 --> Utf8 Class Initialized
INFO - 2023-08-19 16:19:05 --> URI Class Initialized
INFO - 2023-08-19 16:19:05 --> Router Class Initialized
INFO - 2023-08-19 16:19:05 --> Output Class Initialized
INFO - 2023-08-19 16:19:05 --> Security Class Initialized
DEBUG - 2023-08-19 16:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:19:05 --> Input Class Initialized
INFO - 2023-08-19 16:19:05 --> Language Class Initialized
INFO - 2023-08-19 16:19:05 --> Language Class Initialized
INFO - 2023-08-19 16:19:05 --> Config Class Initialized
INFO - 2023-08-19 16:19:05 --> Loader Class Initialized
INFO - 2023-08-19 16:19:05 --> Helper loaded: url_helper
INFO - 2023-08-19 16:19:05 --> Helper loaded: file_helper
INFO - 2023-08-19 16:19:05 --> Helper loaded: form_helper
INFO - 2023-08-19 16:19:05 --> Helper loaded: my_helper
INFO - 2023-08-19 16:19:05 --> Database Driver Class Initialized
INFO - 2023-08-19 16:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:19:05 --> Controller Class Initialized
INFO - 2023-08-19 16:19:05 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:19:05 --> Final output sent to browser
DEBUG - 2023-08-19 16:19:05 --> Total execution time: 0.0330
INFO - 2023-08-19 16:19:05 --> Config Class Initialized
INFO - 2023-08-19 16:19:05 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:19:05 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:19:05 --> Utf8 Class Initialized
INFO - 2023-08-19 16:19:05 --> URI Class Initialized
INFO - 2023-08-19 16:19:05 --> Router Class Initialized
INFO - 2023-08-19 16:19:05 --> Output Class Initialized
INFO - 2023-08-19 16:19:05 --> Security Class Initialized
DEBUG - 2023-08-19 16:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:19:05 --> Input Class Initialized
INFO - 2023-08-19 16:19:05 --> Language Class Initialized
INFO - 2023-08-19 16:19:05 --> Language Class Initialized
INFO - 2023-08-19 16:19:05 --> Config Class Initialized
INFO - 2023-08-19 16:19:05 --> Loader Class Initialized
INFO - 2023-08-19 16:19:05 --> Helper loaded: url_helper
INFO - 2023-08-19 16:19:05 --> Helper loaded: file_helper
INFO - 2023-08-19 16:19:05 --> Helper loaded: form_helper
INFO - 2023-08-19 16:19:05 --> Helper loaded: my_helper
INFO - 2023-08-19 16:19:05 --> Database Driver Class Initialized
INFO - 2023-08-19 16:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:19:05 --> Controller Class Initialized
DEBUG - 2023-08-19 16:19:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 16:19:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:19:05 --> Final output sent to browser
DEBUG - 2023-08-19 16:19:05 --> Total execution time: 0.0404
INFO - 2023-08-19 16:19:10 --> Config Class Initialized
INFO - 2023-08-19 16:19:10 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:19:10 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:19:10 --> Utf8 Class Initialized
INFO - 2023-08-19 16:19:10 --> URI Class Initialized
INFO - 2023-08-19 16:19:10 --> Router Class Initialized
INFO - 2023-08-19 16:19:10 --> Output Class Initialized
INFO - 2023-08-19 16:19:10 --> Security Class Initialized
DEBUG - 2023-08-19 16:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:19:10 --> Input Class Initialized
INFO - 2023-08-19 16:19:10 --> Language Class Initialized
INFO - 2023-08-19 16:19:10 --> Language Class Initialized
INFO - 2023-08-19 16:19:10 --> Config Class Initialized
INFO - 2023-08-19 16:19:10 --> Loader Class Initialized
INFO - 2023-08-19 16:19:10 --> Helper loaded: url_helper
INFO - 2023-08-19 16:19:10 --> Helper loaded: file_helper
INFO - 2023-08-19 16:19:10 --> Helper loaded: form_helper
INFO - 2023-08-19 16:19:10 --> Helper loaded: my_helper
INFO - 2023-08-19 16:19:10 --> Database Driver Class Initialized
INFO - 2023-08-19 16:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:19:10 --> Controller Class Initialized
DEBUG - 2023-08-19 16:19:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 16:19:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:19:10 --> Final output sent to browser
DEBUG - 2023-08-19 16:19:10 --> Total execution time: 0.0704
INFO - 2023-08-19 16:19:51 --> Config Class Initialized
INFO - 2023-08-19 16:19:51 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:19:51 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:19:51 --> Utf8 Class Initialized
INFO - 2023-08-19 16:19:51 --> URI Class Initialized
DEBUG - 2023-08-19 16:19:51 --> No URI present. Default controller set.
INFO - 2023-08-19 16:19:51 --> Router Class Initialized
INFO - 2023-08-19 16:19:51 --> Output Class Initialized
INFO - 2023-08-19 16:19:51 --> Security Class Initialized
DEBUG - 2023-08-19 16:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:19:51 --> Input Class Initialized
INFO - 2023-08-19 16:19:51 --> Language Class Initialized
INFO - 2023-08-19 16:19:51 --> Language Class Initialized
INFO - 2023-08-19 16:19:51 --> Config Class Initialized
INFO - 2023-08-19 16:19:51 --> Loader Class Initialized
INFO - 2023-08-19 16:19:51 --> Helper loaded: url_helper
INFO - 2023-08-19 16:19:51 --> Helper loaded: file_helper
INFO - 2023-08-19 16:19:51 --> Helper loaded: form_helper
INFO - 2023-08-19 16:19:51 --> Helper loaded: my_helper
INFO - 2023-08-19 16:19:51 --> Database Driver Class Initialized
INFO - 2023-08-19 16:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:19:51 --> Controller Class Initialized
DEBUG - 2023-08-19 16:19:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 16:19:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:19:51 --> Final output sent to browser
DEBUG - 2023-08-19 16:19:51 --> Total execution time: 0.0543
INFO - 2023-08-19 16:20:19 --> Config Class Initialized
INFO - 2023-08-19 16:20:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:20:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:20:19 --> Utf8 Class Initialized
INFO - 2023-08-19 16:20:19 --> URI Class Initialized
DEBUG - 2023-08-19 16:20:19 --> No URI present. Default controller set.
INFO - 2023-08-19 16:20:19 --> Router Class Initialized
INFO - 2023-08-19 16:20:19 --> Output Class Initialized
INFO - 2023-08-19 16:20:19 --> Security Class Initialized
DEBUG - 2023-08-19 16:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:20:19 --> Input Class Initialized
INFO - 2023-08-19 16:20:19 --> Language Class Initialized
INFO - 2023-08-19 16:20:19 --> Language Class Initialized
INFO - 2023-08-19 16:20:19 --> Config Class Initialized
INFO - 2023-08-19 16:20:19 --> Loader Class Initialized
INFO - 2023-08-19 16:20:19 --> Helper loaded: url_helper
INFO - 2023-08-19 16:20:19 --> Helper loaded: file_helper
INFO - 2023-08-19 16:20:19 --> Helper loaded: form_helper
INFO - 2023-08-19 16:20:19 --> Helper loaded: my_helper
INFO - 2023-08-19 16:20:19 --> Database Driver Class Initialized
INFO - 2023-08-19 16:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:20:20 --> Controller Class Initialized
DEBUG - 2023-08-19 16:20:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 16:20:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:20:20 --> Final output sent to browser
DEBUG - 2023-08-19 16:20:20 --> Total execution time: 0.0351
INFO - 2023-08-19 16:20:45 --> Config Class Initialized
INFO - 2023-08-19 16:20:45 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:20:45 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:20:45 --> Utf8 Class Initialized
INFO - 2023-08-19 16:20:45 --> URI Class Initialized
INFO - 2023-08-19 16:20:45 --> Router Class Initialized
INFO - 2023-08-19 16:20:45 --> Output Class Initialized
INFO - 2023-08-19 16:20:45 --> Security Class Initialized
DEBUG - 2023-08-19 16:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:20:45 --> Input Class Initialized
INFO - 2023-08-19 16:20:45 --> Language Class Initialized
INFO - 2023-08-19 16:20:45 --> Language Class Initialized
INFO - 2023-08-19 16:20:45 --> Config Class Initialized
INFO - 2023-08-19 16:20:45 --> Loader Class Initialized
INFO - 2023-08-19 16:20:45 --> Helper loaded: url_helper
INFO - 2023-08-19 16:20:45 --> Helper loaded: file_helper
INFO - 2023-08-19 16:20:45 --> Helper loaded: form_helper
INFO - 2023-08-19 16:20:45 --> Helper loaded: my_helper
INFO - 2023-08-19 16:20:45 --> Database Driver Class Initialized
INFO - 2023-08-19 16:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:20:45 --> Controller Class Initialized
INFO - 2023-08-19 16:20:45 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:20:45 --> Final output sent to browser
DEBUG - 2023-08-19 16:20:45 --> Total execution time: 0.0350
INFO - 2023-08-19 16:20:45 --> Config Class Initialized
INFO - 2023-08-19 16:20:45 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:20:45 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:20:45 --> Utf8 Class Initialized
INFO - 2023-08-19 16:20:45 --> URI Class Initialized
INFO - 2023-08-19 16:20:45 --> Router Class Initialized
INFO - 2023-08-19 16:20:45 --> Output Class Initialized
INFO - 2023-08-19 16:20:45 --> Security Class Initialized
DEBUG - 2023-08-19 16:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:20:45 --> Input Class Initialized
INFO - 2023-08-19 16:20:45 --> Language Class Initialized
INFO - 2023-08-19 16:20:45 --> Language Class Initialized
INFO - 2023-08-19 16:20:45 --> Config Class Initialized
INFO - 2023-08-19 16:20:45 --> Loader Class Initialized
INFO - 2023-08-19 16:20:45 --> Helper loaded: url_helper
INFO - 2023-08-19 16:20:45 --> Helper loaded: file_helper
INFO - 2023-08-19 16:20:45 --> Helper loaded: form_helper
INFO - 2023-08-19 16:20:45 --> Helper loaded: my_helper
INFO - 2023-08-19 16:20:45 --> Database Driver Class Initialized
INFO - 2023-08-19 16:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:20:45 --> Controller Class Initialized
DEBUG - 2023-08-19 16:20:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 16:20:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:20:45 --> Final output sent to browser
DEBUG - 2023-08-19 16:20:45 --> Total execution time: 0.0310
INFO - 2023-08-19 16:20:48 --> Config Class Initialized
INFO - 2023-08-19 16:20:48 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:20:48 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:20:48 --> Utf8 Class Initialized
INFO - 2023-08-19 16:20:48 --> URI Class Initialized
INFO - 2023-08-19 16:20:48 --> Router Class Initialized
INFO - 2023-08-19 16:20:48 --> Output Class Initialized
INFO - 2023-08-19 16:20:48 --> Security Class Initialized
DEBUG - 2023-08-19 16:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:20:48 --> Input Class Initialized
INFO - 2023-08-19 16:20:48 --> Language Class Initialized
INFO - 2023-08-19 16:20:48 --> Language Class Initialized
INFO - 2023-08-19 16:20:48 --> Config Class Initialized
INFO - 2023-08-19 16:20:48 --> Loader Class Initialized
INFO - 2023-08-19 16:20:48 --> Helper loaded: url_helper
INFO - 2023-08-19 16:20:48 --> Helper loaded: file_helper
INFO - 2023-08-19 16:20:48 --> Helper loaded: form_helper
INFO - 2023-08-19 16:20:48 --> Helper loaded: my_helper
INFO - 2023-08-19 16:20:48 --> Database Driver Class Initialized
INFO - 2023-08-19 16:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:20:48 --> Controller Class Initialized
DEBUG - 2023-08-19 16:20:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 16:20:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:20:48 --> Final output sent to browser
DEBUG - 2023-08-19 16:20:48 --> Total execution time: 0.0315
INFO - 2023-08-19 16:20:52 --> Config Class Initialized
INFO - 2023-08-19 16:20:52 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:20:52 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:20:52 --> Utf8 Class Initialized
INFO - 2023-08-19 16:20:52 --> URI Class Initialized
INFO - 2023-08-19 16:20:52 --> Router Class Initialized
INFO - 2023-08-19 16:20:52 --> Output Class Initialized
INFO - 2023-08-19 16:20:52 --> Security Class Initialized
DEBUG - 2023-08-19 16:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:20:52 --> Input Class Initialized
INFO - 2023-08-19 16:20:52 --> Language Class Initialized
INFO - 2023-08-19 16:20:52 --> Language Class Initialized
INFO - 2023-08-19 16:20:52 --> Config Class Initialized
INFO - 2023-08-19 16:20:52 --> Loader Class Initialized
INFO - 2023-08-19 16:20:52 --> Helper loaded: url_helper
INFO - 2023-08-19 16:20:52 --> Helper loaded: file_helper
INFO - 2023-08-19 16:20:52 --> Helper loaded: form_helper
INFO - 2023-08-19 16:20:52 --> Helper loaded: my_helper
INFO - 2023-08-19 16:20:52 --> Database Driver Class Initialized
INFO - 2023-08-19 16:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:20:52 --> Controller Class Initialized
DEBUG - 2023-08-19 16:20:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-08-19 16:20:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:20:52 --> Final output sent to browser
DEBUG - 2023-08-19 16:20:52 --> Total execution time: 0.0309
INFO - 2023-08-19 16:20:52 --> Config Class Initialized
INFO - 2023-08-19 16:20:52 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:20:52 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:20:52 --> Utf8 Class Initialized
INFO - 2023-08-19 16:20:52 --> URI Class Initialized
INFO - 2023-08-19 16:20:52 --> Router Class Initialized
INFO - 2023-08-19 16:20:52 --> Output Class Initialized
INFO - 2023-08-19 16:20:52 --> Security Class Initialized
DEBUG - 2023-08-19 16:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:20:52 --> Input Class Initialized
INFO - 2023-08-19 16:20:52 --> Language Class Initialized
INFO - 2023-08-19 16:20:52 --> Language Class Initialized
INFO - 2023-08-19 16:20:52 --> Config Class Initialized
INFO - 2023-08-19 16:20:52 --> Loader Class Initialized
INFO - 2023-08-19 16:20:52 --> Helper loaded: url_helper
INFO - 2023-08-19 16:20:52 --> Helper loaded: file_helper
INFO - 2023-08-19 16:20:52 --> Helper loaded: form_helper
INFO - 2023-08-19 16:20:52 --> Helper loaded: my_helper
INFO - 2023-08-19 16:20:52 --> Database Driver Class Initialized
INFO - 2023-08-19 16:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:20:52 --> Controller Class Initialized
INFO - 2023-08-19 16:21:10 --> Config Class Initialized
INFO - 2023-08-19 16:21:10 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:21:10 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:21:10 --> Utf8 Class Initialized
INFO - 2023-08-19 16:21:10 --> URI Class Initialized
INFO - 2023-08-19 16:21:10 --> Router Class Initialized
INFO - 2023-08-19 16:21:10 --> Output Class Initialized
INFO - 2023-08-19 16:21:10 --> Security Class Initialized
DEBUG - 2023-08-19 16:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:21:10 --> Input Class Initialized
INFO - 2023-08-19 16:21:10 --> Language Class Initialized
INFO - 2023-08-19 16:21:10 --> Language Class Initialized
INFO - 2023-08-19 16:21:10 --> Config Class Initialized
INFO - 2023-08-19 16:21:10 --> Loader Class Initialized
INFO - 2023-08-19 16:21:10 --> Helper loaded: url_helper
INFO - 2023-08-19 16:21:10 --> Helper loaded: file_helper
INFO - 2023-08-19 16:21:10 --> Helper loaded: form_helper
INFO - 2023-08-19 16:21:10 --> Helper loaded: my_helper
INFO - 2023-08-19 16:21:10 --> Database Driver Class Initialized
INFO - 2023-08-19 16:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:21:10 --> Controller Class Initialized
INFO - 2023-08-19 16:21:10 --> Final output sent to browser
DEBUG - 2023-08-19 16:21:10 --> Total execution time: 0.0287
INFO - 2023-08-19 16:21:43 --> Config Class Initialized
INFO - 2023-08-19 16:21:43 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:21:43 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:21:43 --> Utf8 Class Initialized
INFO - 2023-08-19 16:21:43 --> URI Class Initialized
INFO - 2023-08-19 16:21:43 --> Router Class Initialized
INFO - 2023-08-19 16:21:43 --> Output Class Initialized
INFO - 2023-08-19 16:21:43 --> Security Class Initialized
DEBUG - 2023-08-19 16:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:21:43 --> Input Class Initialized
INFO - 2023-08-19 16:21:43 --> Language Class Initialized
INFO - 2023-08-19 16:21:43 --> Language Class Initialized
INFO - 2023-08-19 16:21:43 --> Config Class Initialized
INFO - 2023-08-19 16:21:43 --> Loader Class Initialized
INFO - 2023-08-19 16:21:43 --> Helper loaded: url_helper
INFO - 2023-08-19 16:21:43 --> Helper loaded: file_helper
INFO - 2023-08-19 16:21:43 --> Helper loaded: form_helper
INFO - 2023-08-19 16:21:43 --> Helper loaded: my_helper
INFO - 2023-08-19 16:21:43 --> Database Driver Class Initialized
INFO - 2023-08-19 16:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:21:43 --> Controller Class Initialized
INFO - 2023-08-19 16:21:43 --> Final output sent to browser
DEBUG - 2023-08-19 16:21:43 --> Total execution time: 0.0371
INFO - 2023-08-19 16:21:43 --> Config Class Initialized
INFO - 2023-08-19 16:21:43 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:21:43 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:21:43 --> Utf8 Class Initialized
INFO - 2023-08-19 16:21:43 --> URI Class Initialized
INFO - 2023-08-19 16:21:43 --> Router Class Initialized
INFO - 2023-08-19 16:21:43 --> Output Class Initialized
INFO - 2023-08-19 16:21:43 --> Security Class Initialized
DEBUG - 2023-08-19 16:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:21:43 --> Input Class Initialized
INFO - 2023-08-19 16:21:43 --> Language Class Initialized
INFO - 2023-08-19 16:21:43 --> Language Class Initialized
INFO - 2023-08-19 16:21:43 --> Config Class Initialized
INFO - 2023-08-19 16:21:43 --> Loader Class Initialized
INFO - 2023-08-19 16:21:43 --> Helper loaded: url_helper
INFO - 2023-08-19 16:21:43 --> Helper loaded: file_helper
INFO - 2023-08-19 16:21:43 --> Helper loaded: form_helper
INFO - 2023-08-19 16:21:43 --> Helper loaded: my_helper
INFO - 2023-08-19 16:21:43 --> Database Driver Class Initialized
INFO - 2023-08-19 16:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:21:43 --> Controller Class Initialized
INFO - 2023-08-19 16:21:48 --> Config Class Initialized
INFO - 2023-08-19 16:21:48 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:21:48 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:21:48 --> Utf8 Class Initialized
INFO - 2023-08-19 16:21:48 --> URI Class Initialized
INFO - 2023-08-19 16:21:48 --> Router Class Initialized
INFO - 2023-08-19 16:21:48 --> Output Class Initialized
INFO - 2023-08-19 16:21:48 --> Security Class Initialized
DEBUG - 2023-08-19 16:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:21:48 --> Input Class Initialized
INFO - 2023-08-19 16:21:48 --> Language Class Initialized
INFO - 2023-08-19 16:21:48 --> Language Class Initialized
INFO - 2023-08-19 16:21:48 --> Config Class Initialized
INFO - 2023-08-19 16:21:48 --> Loader Class Initialized
INFO - 2023-08-19 16:21:48 --> Helper loaded: url_helper
INFO - 2023-08-19 16:21:48 --> Helper loaded: file_helper
INFO - 2023-08-19 16:21:48 --> Helper loaded: form_helper
INFO - 2023-08-19 16:21:48 --> Helper loaded: my_helper
INFO - 2023-08-19 16:21:48 --> Database Driver Class Initialized
INFO - 2023-08-19 16:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:21:48 --> Controller Class Initialized
INFO - 2023-08-19 16:21:48 --> Final output sent to browser
DEBUG - 2023-08-19 16:21:48 --> Total execution time: 0.0314
INFO - 2023-08-19 16:22:37 --> Config Class Initialized
INFO - 2023-08-19 16:22:37 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:22:37 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:22:37 --> Utf8 Class Initialized
INFO - 2023-08-19 16:22:37 --> URI Class Initialized
INFO - 2023-08-19 16:22:37 --> Router Class Initialized
INFO - 2023-08-19 16:22:37 --> Output Class Initialized
INFO - 2023-08-19 16:22:37 --> Security Class Initialized
DEBUG - 2023-08-19 16:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:22:37 --> Input Class Initialized
INFO - 2023-08-19 16:22:37 --> Language Class Initialized
INFO - 2023-08-19 16:22:37 --> Language Class Initialized
INFO - 2023-08-19 16:22:37 --> Config Class Initialized
INFO - 2023-08-19 16:22:37 --> Loader Class Initialized
INFO - 2023-08-19 16:22:37 --> Helper loaded: url_helper
INFO - 2023-08-19 16:22:37 --> Helper loaded: file_helper
INFO - 2023-08-19 16:22:37 --> Helper loaded: form_helper
INFO - 2023-08-19 16:22:37 --> Helper loaded: my_helper
INFO - 2023-08-19 16:22:37 --> Database Driver Class Initialized
INFO - 2023-08-19 16:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:22:37 --> Controller Class Initialized
INFO - 2023-08-19 16:22:37 --> Final output sent to browser
DEBUG - 2023-08-19 16:22:37 --> Total execution time: 0.1097
INFO - 2023-08-19 16:22:37 --> Config Class Initialized
INFO - 2023-08-19 16:22:37 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:22:37 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:22:37 --> Utf8 Class Initialized
INFO - 2023-08-19 16:22:37 --> URI Class Initialized
INFO - 2023-08-19 16:22:37 --> Router Class Initialized
INFO - 2023-08-19 16:22:37 --> Output Class Initialized
INFO - 2023-08-19 16:22:37 --> Security Class Initialized
DEBUG - 2023-08-19 16:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:22:37 --> Input Class Initialized
INFO - 2023-08-19 16:22:37 --> Language Class Initialized
INFO - 2023-08-19 16:22:37 --> Language Class Initialized
INFO - 2023-08-19 16:22:37 --> Config Class Initialized
INFO - 2023-08-19 16:22:37 --> Loader Class Initialized
INFO - 2023-08-19 16:22:37 --> Helper loaded: url_helper
INFO - 2023-08-19 16:22:37 --> Helper loaded: file_helper
INFO - 2023-08-19 16:22:37 --> Helper loaded: form_helper
INFO - 2023-08-19 16:22:37 --> Helper loaded: my_helper
INFO - 2023-08-19 16:22:37 --> Database Driver Class Initialized
INFO - 2023-08-19 16:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:22:37 --> Controller Class Initialized
INFO - 2023-08-19 16:23:00 --> Config Class Initialized
INFO - 2023-08-19 16:23:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:23:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:23:00 --> Utf8 Class Initialized
INFO - 2023-08-19 16:23:00 --> URI Class Initialized
INFO - 2023-08-19 16:23:00 --> Router Class Initialized
INFO - 2023-08-19 16:23:00 --> Output Class Initialized
INFO - 2023-08-19 16:23:00 --> Security Class Initialized
DEBUG - 2023-08-19 16:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:23:00 --> Input Class Initialized
INFO - 2023-08-19 16:23:00 --> Language Class Initialized
INFO - 2023-08-19 16:23:00 --> Language Class Initialized
INFO - 2023-08-19 16:23:00 --> Config Class Initialized
INFO - 2023-08-19 16:23:00 --> Loader Class Initialized
INFO - 2023-08-19 16:23:00 --> Helper loaded: url_helper
INFO - 2023-08-19 16:23:00 --> Helper loaded: file_helper
INFO - 2023-08-19 16:23:00 --> Helper loaded: form_helper
INFO - 2023-08-19 16:23:00 --> Helper loaded: my_helper
INFO - 2023-08-19 16:23:00 --> Database Driver Class Initialized
INFO - 2023-08-19 16:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:23:00 --> Controller Class Initialized
DEBUG - 2023-08-19 16:23:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2023-08-19 16:23:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:23:00 --> Final output sent to browser
DEBUG - 2023-08-19 16:23:00 --> Total execution time: 0.0355
INFO - 2023-08-19 16:23:01 --> Config Class Initialized
INFO - 2023-08-19 16:23:01 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:23:01 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:23:01 --> Utf8 Class Initialized
INFO - 2023-08-19 16:23:01 --> URI Class Initialized
INFO - 2023-08-19 16:23:01 --> Router Class Initialized
INFO - 2023-08-19 16:23:01 --> Output Class Initialized
INFO - 2023-08-19 16:23:01 --> Security Class Initialized
DEBUG - 2023-08-19 16:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:23:01 --> Input Class Initialized
INFO - 2023-08-19 16:23:01 --> Language Class Initialized
ERROR - 2023-08-19 16:23:01 --> 404 Page Not Found: /index
INFO - 2023-08-19 16:23:01 --> Config Class Initialized
INFO - 2023-08-19 16:23:01 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:23:01 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:23:01 --> Utf8 Class Initialized
INFO - 2023-08-19 16:23:01 --> URI Class Initialized
INFO - 2023-08-19 16:23:01 --> Router Class Initialized
INFO - 2023-08-19 16:23:01 --> Output Class Initialized
INFO - 2023-08-19 16:23:01 --> Security Class Initialized
DEBUG - 2023-08-19 16:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:23:01 --> Input Class Initialized
INFO - 2023-08-19 16:23:01 --> Language Class Initialized
INFO - 2023-08-19 16:23:01 --> Language Class Initialized
INFO - 2023-08-19 16:23:01 --> Config Class Initialized
INFO - 2023-08-19 16:23:01 --> Loader Class Initialized
INFO - 2023-08-19 16:23:01 --> Helper loaded: url_helper
INFO - 2023-08-19 16:23:01 --> Helper loaded: file_helper
INFO - 2023-08-19 16:23:01 --> Helper loaded: form_helper
INFO - 2023-08-19 16:23:01 --> Helper loaded: my_helper
INFO - 2023-08-19 16:23:01 --> Database Driver Class Initialized
INFO - 2023-08-19 16:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:23:01 --> Controller Class Initialized
INFO - 2023-08-19 16:23:13 --> Config Class Initialized
INFO - 2023-08-19 16:23:13 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:23:13 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:23:13 --> Utf8 Class Initialized
INFO - 2023-08-19 16:23:13 --> URI Class Initialized
DEBUG - 2023-08-19 16:23:13 --> No URI present. Default controller set.
INFO - 2023-08-19 16:23:13 --> Router Class Initialized
INFO - 2023-08-19 16:23:13 --> Output Class Initialized
INFO - 2023-08-19 16:23:13 --> Security Class Initialized
DEBUG - 2023-08-19 16:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:23:13 --> Input Class Initialized
INFO - 2023-08-19 16:23:13 --> Language Class Initialized
INFO - 2023-08-19 16:23:13 --> Language Class Initialized
INFO - 2023-08-19 16:23:13 --> Config Class Initialized
INFO - 2023-08-19 16:23:13 --> Loader Class Initialized
INFO - 2023-08-19 16:23:13 --> Helper loaded: url_helper
INFO - 2023-08-19 16:23:13 --> Helper loaded: file_helper
INFO - 2023-08-19 16:23:13 --> Helper loaded: form_helper
INFO - 2023-08-19 16:23:13 --> Helper loaded: my_helper
INFO - 2023-08-19 16:23:13 --> Database Driver Class Initialized
INFO - 2023-08-19 16:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:23:13 --> Controller Class Initialized
INFO - 2023-08-19 16:23:13 --> Config Class Initialized
INFO - 2023-08-19 16:23:13 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:23:13 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:23:13 --> Utf8 Class Initialized
INFO - 2023-08-19 16:23:13 --> URI Class Initialized
INFO - 2023-08-19 16:23:13 --> Router Class Initialized
INFO - 2023-08-19 16:23:13 --> Output Class Initialized
INFO - 2023-08-19 16:23:13 --> Security Class Initialized
DEBUG - 2023-08-19 16:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:23:13 --> Input Class Initialized
INFO - 2023-08-19 16:23:13 --> Language Class Initialized
INFO - 2023-08-19 16:23:13 --> Language Class Initialized
INFO - 2023-08-19 16:23:13 --> Config Class Initialized
INFO - 2023-08-19 16:23:13 --> Loader Class Initialized
INFO - 2023-08-19 16:23:13 --> Helper loaded: url_helper
INFO - 2023-08-19 16:23:13 --> Helper loaded: file_helper
INFO - 2023-08-19 16:23:13 --> Helper loaded: form_helper
INFO - 2023-08-19 16:23:13 --> Helper loaded: my_helper
INFO - 2023-08-19 16:23:13 --> Database Driver Class Initialized
INFO - 2023-08-19 16:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:23:13 --> Controller Class Initialized
DEBUG - 2023-08-19 16:23:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-08-19 16:23:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:23:13 --> Final output sent to browser
DEBUG - 2023-08-19 16:23:13 --> Total execution time: 0.0282
INFO - 2023-08-19 16:23:15 --> Config Class Initialized
INFO - 2023-08-19 16:23:15 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:23:15 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:23:15 --> Utf8 Class Initialized
INFO - 2023-08-19 16:23:15 --> URI Class Initialized
INFO - 2023-08-19 16:23:15 --> Router Class Initialized
INFO - 2023-08-19 16:23:15 --> Output Class Initialized
INFO - 2023-08-19 16:23:15 --> Security Class Initialized
DEBUG - 2023-08-19 16:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:23:15 --> Input Class Initialized
INFO - 2023-08-19 16:23:15 --> Language Class Initialized
INFO - 2023-08-19 16:23:15 --> Language Class Initialized
INFO - 2023-08-19 16:23:15 --> Config Class Initialized
INFO - 2023-08-19 16:23:15 --> Loader Class Initialized
INFO - 2023-08-19 16:23:15 --> Helper loaded: url_helper
INFO - 2023-08-19 16:23:15 --> Helper loaded: file_helper
INFO - 2023-08-19 16:23:15 --> Helper loaded: form_helper
INFO - 2023-08-19 16:23:15 --> Helper loaded: my_helper
INFO - 2023-08-19 16:23:16 --> Database Driver Class Initialized
INFO - 2023-08-19 16:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:23:16 --> Controller Class Initialized
INFO - 2023-08-19 16:23:16 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:23:16 --> Final output sent to browser
DEBUG - 2023-08-19 16:23:16 --> Total execution time: 0.0312
INFO - 2023-08-19 16:23:16 --> Config Class Initialized
INFO - 2023-08-19 16:23:16 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:23:16 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:23:16 --> Utf8 Class Initialized
INFO - 2023-08-19 16:23:16 --> URI Class Initialized
INFO - 2023-08-19 16:23:16 --> Router Class Initialized
INFO - 2023-08-19 16:23:16 --> Output Class Initialized
INFO - 2023-08-19 16:23:16 --> Security Class Initialized
DEBUG - 2023-08-19 16:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:23:16 --> Input Class Initialized
INFO - 2023-08-19 16:23:16 --> Language Class Initialized
INFO - 2023-08-19 16:23:16 --> Language Class Initialized
INFO - 2023-08-19 16:23:16 --> Config Class Initialized
INFO - 2023-08-19 16:23:16 --> Loader Class Initialized
INFO - 2023-08-19 16:23:16 --> Helper loaded: url_helper
INFO - 2023-08-19 16:23:16 --> Helper loaded: file_helper
INFO - 2023-08-19 16:23:16 --> Helper loaded: form_helper
INFO - 2023-08-19 16:23:16 --> Helper loaded: my_helper
INFO - 2023-08-19 16:23:16 --> Database Driver Class Initialized
INFO - 2023-08-19 16:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:23:16 --> Controller Class Initialized
DEBUG - 2023-08-19 16:23:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-08-19 16:23:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:23:16 --> Final output sent to browser
DEBUG - 2023-08-19 16:23:16 --> Total execution time: 0.0310
INFO - 2023-08-19 16:23:30 --> Config Class Initialized
INFO - 2023-08-19 16:23:30 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:23:30 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:23:30 --> Utf8 Class Initialized
INFO - 2023-08-19 16:23:30 --> URI Class Initialized
INFO - 2023-08-19 16:23:30 --> Router Class Initialized
INFO - 2023-08-19 16:23:30 --> Output Class Initialized
INFO - 2023-08-19 16:23:30 --> Security Class Initialized
DEBUG - 2023-08-19 16:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:23:30 --> Input Class Initialized
INFO - 2023-08-19 16:23:30 --> Language Class Initialized
INFO - 2023-08-19 16:23:30 --> Language Class Initialized
INFO - 2023-08-19 16:23:30 --> Config Class Initialized
INFO - 2023-08-19 16:23:30 --> Loader Class Initialized
INFO - 2023-08-19 16:23:30 --> Helper loaded: url_helper
INFO - 2023-08-19 16:23:30 --> Helper loaded: file_helper
INFO - 2023-08-19 16:23:30 --> Helper loaded: form_helper
INFO - 2023-08-19 16:23:30 --> Helper loaded: my_helper
INFO - 2023-08-19 16:23:30 --> Database Driver Class Initialized
INFO - 2023-08-19 16:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:23:30 --> Controller Class Initialized
DEBUG - 2023-08-19 16:23:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-08-19 16:23:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:23:30 --> Final output sent to browser
DEBUG - 2023-08-19 16:23:30 --> Total execution time: 0.0617
INFO - 2023-08-19 16:23:30 --> Config Class Initialized
INFO - 2023-08-19 16:23:30 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:23:30 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:23:30 --> Utf8 Class Initialized
INFO - 2023-08-19 16:23:30 --> URI Class Initialized
INFO - 2023-08-19 16:23:30 --> Router Class Initialized
INFO - 2023-08-19 16:23:30 --> Output Class Initialized
INFO - 2023-08-19 16:23:30 --> Security Class Initialized
DEBUG - 2023-08-19 16:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:23:30 --> Input Class Initialized
INFO - 2023-08-19 16:23:30 --> Language Class Initialized
ERROR - 2023-08-19 16:23:30 --> 404 Page Not Found: /index
INFO - 2023-08-19 16:23:30 --> Config Class Initialized
INFO - 2023-08-19 16:23:30 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:23:30 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:23:30 --> Utf8 Class Initialized
INFO - 2023-08-19 16:23:30 --> URI Class Initialized
INFO - 2023-08-19 16:23:30 --> Router Class Initialized
INFO - 2023-08-19 16:23:30 --> Output Class Initialized
INFO - 2023-08-19 16:23:30 --> Security Class Initialized
DEBUG - 2023-08-19 16:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:23:30 --> Input Class Initialized
INFO - 2023-08-19 16:23:30 --> Language Class Initialized
INFO - 2023-08-19 16:23:30 --> Language Class Initialized
INFO - 2023-08-19 16:23:30 --> Config Class Initialized
INFO - 2023-08-19 16:23:30 --> Loader Class Initialized
INFO - 2023-08-19 16:23:30 --> Helper loaded: url_helper
INFO - 2023-08-19 16:23:30 --> Helper loaded: file_helper
INFO - 2023-08-19 16:23:30 --> Helper loaded: form_helper
INFO - 2023-08-19 16:23:30 --> Helper loaded: my_helper
INFO - 2023-08-19 16:23:30 --> Database Driver Class Initialized
INFO - 2023-08-19 16:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:23:30 --> Controller Class Initialized
INFO - 2023-08-19 16:23:31 --> Config Class Initialized
INFO - 2023-08-19 16:23:31 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:23:31 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:23:31 --> Utf8 Class Initialized
INFO - 2023-08-19 16:23:31 --> URI Class Initialized
INFO - 2023-08-19 16:23:31 --> Router Class Initialized
INFO - 2023-08-19 16:23:31 --> Output Class Initialized
INFO - 2023-08-19 16:23:31 --> Security Class Initialized
DEBUG - 2023-08-19 16:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:23:31 --> Input Class Initialized
INFO - 2023-08-19 16:23:31 --> Language Class Initialized
INFO - 2023-08-19 16:23:31 --> Language Class Initialized
INFO - 2023-08-19 16:23:31 --> Config Class Initialized
INFO - 2023-08-19 16:23:31 --> Loader Class Initialized
INFO - 2023-08-19 16:23:31 --> Helper loaded: url_helper
INFO - 2023-08-19 16:23:31 --> Helper loaded: file_helper
INFO - 2023-08-19 16:23:31 --> Helper loaded: form_helper
INFO - 2023-08-19 16:23:31 --> Helper loaded: my_helper
INFO - 2023-08-19 16:23:31 --> Database Driver Class Initialized
INFO - 2023-08-19 16:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:23:31 --> Controller Class Initialized
DEBUG - 2023-08-19 16:23:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2023-08-19 16:23:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:23:31 --> Final output sent to browser
DEBUG - 2023-08-19 16:23:31 --> Total execution time: 0.0323
INFO - 2023-08-19 16:23:46 --> Config Class Initialized
INFO - 2023-08-19 16:23:46 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:23:46 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:23:46 --> Utf8 Class Initialized
INFO - 2023-08-19 16:23:46 --> URI Class Initialized
INFO - 2023-08-19 16:23:46 --> Router Class Initialized
INFO - 2023-08-19 16:23:46 --> Output Class Initialized
INFO - 2023-08-19 16:23:46 --> Security Class Initialized
DEBUG - 2023-08-19 16:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:23:46 --> Input Class Initialized
INFO - 2023-08-19 16:23:46 --> Language Class Initialized
INFO - 2023-08-19 16:23:46 --> Language Class Initialized
INFO - 2023-08-19 16:23:46 --> Config Class Initialized
INFO - 2023-08-19 16:23:46 --> Loader Class Initialized
INFO - 2023-08-19 16:23:46 --> Helper loaded: url_helper
INFO - 2023-08-19 16:23:46 --> Helper loaded: file_helper
INFO - 2023-08-19 16:23:46 --> Helper loaded: form_helper
INFO - 2023-08-19 16:23:46 --> Helper loaded: my_helper
INFO - 2023-08-19 16:23:46 --> Database Driver Class Initialized
INFO - 2023-08-19 16:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:23:46 --> Controller Class Initialized
INFO - 2023-08-19 16:23:46 --> Config Class Initialized
INFO - 2023-08-19 16:23:46 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:23:46 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:23:46 --> Utf8 Class Initialized
INFO - 2023-08-19 16:23:46 --> URI Class Initialized
INFO - 2023-08-19 16:23:46 --> Router Class Initialized
INFO - 2023-08-19 16:23:46 --> Output Class Initialized
INFO - 2023-08-19 16:23:46 --> Security Class Initialized
DEBUG - 2023-08-19 16:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:23:46 --> Input Class Initialized
INFO - 2023-08-19 16:23:46 --> Language Class Initialized
INFO - 2023-08-19 16:23:46 --> Language Class Initialized
INFO - 2023-08-19 16:23:46 --> Config Class Initialized
INFO - 2023-08-19 16:23:46 --> Loader Class Initialized
INFO - 2023-08-19 16:23:46 --> Helper loaded: url_helper
INFO - 2023-08-19 16:23:46 --> Helper loaded: file_helper
INFO - 2023-08-19 16:23:46 --> Helper loaded: form_helper
INFO - 2023-08-19 16:23:46 --> Helper loaded: my_helper
INFO - 2023-08-19 16:23:46 --> Database Driver Class Initialized
INFO - 2023-08-19 16:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:23:46 --> Controller Class Initialized
DEBUG - 2023-08-19 16:23:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-08-19 16:23:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:23:46 --> Final output sent to browser
DEBUG - 2023-08-19 16:23:46 --> Total execution time: 0.0506
INFO - 2023-08-19 16:23:46 --> Config Class Initialized
INFO - 2023-08-19 16:23:46 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:23:46 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:23:46 --> Utf8 Class Initialized
INFO - 2023-08-19 16:23:46 --> URI Class Initialized
INFO - 2023-08-19 16:23:46 --> Router Class Initialized
INFO - 2023-08-19 16:23:46 --> Output Class Initialized
INFO - 2023-08-19 16:23:46 --> Security Class Initialized
DEBUG - 2023-08-19 16:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:23:46 --> Input Class Initialized
INFO - 2023-08-19 16:23:46 --> Language Class Initialized
ERROR - 2023-08-19 16:23:46 --> 404 Page Not Found: /index
INFO - 2023-08-19 16:23:46 --> Config Class Initialized
INFO - 2023-08-19 16:23:46 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:23:46 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:23:46 --> Utf8 Class Initialized
INFO - 2023-08-19 16:23:46 --> URI Class Initialized
INFO - 2023-08-19 16:23:46 --> Router Class Initialized
INFO - 2023-08-19 16:23:46 --> Output Class Initialized
INFO - 2023-08-19 16:23:46 --> Security Class Initialized
DEBUG - 2023-08-19 16:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:23:46 --> Input Class Initialized
INFO - 2023-08-19 16:23:46 --> Language Class Initialized
INFO - 2023-08-19 16:23:46 --> Language Class Initialized
INFO - 2023-08-19 16:23:46 --> Config Class Initialized
INFO - 2023-08-19 16:23:46 --> Loader Class Initialized
INFO - 2023-08-19 16:23:46 --> Helper loaded: url_helper
INFO - 2023-08-19 16:23:46 --> Helper loaded: file_helper
INFO - 2023-08-19 16:23:46 --> Helper loaded: form_helper
INFO - 2023-08-19 16:23:46 --> Helper loaded: my_helper
INFO - 2023-08-19 16:23:46 --> Database Driver Class Initialized
INFO - 2023-08-19 16:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:23:46 --> Controller Class Initialized
INFO - 2023-08-19 16:23:47 --> Config Class Initialized
INFO - 2023-08-19 16:23:47 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:23:47 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:23:47 --> Utf8 Class Initialized
INFO - 2023-08-19 16:23:47 --> URI Class Initialized
INFO - 2023-08-19 16:23:47 --> Router Class Initialized
INFO - 2023-08-19 16:23:47 --> Output Class Initialized
INFO - 2023-08-19 16:23:47 --> Security Class Initialized
DEBUG - 2023-08-19 16:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:23:47 --> Input Class Initialized
INFO - 2023-08-19 16:23:47 --> Language Class Initialized
INFO - 2023-08-19 16:23:47 --> Language Class Initialized
INFO - 2023-08-19 16:23:47 --> Config Class Initialized
INFO - 2023-08-19 16:23:47 --> Loader Class Initialized
INFO - 2023-08-19 16:23:47 --> Helper loaded: url_helper
INFO - 2023-08-19 16:23:47 --> Helper loaded: file_helper
INFO - 2023-08-19 16:23:47 --> Helper loaded: form_helper
INFO - 2023-08-19 16:23:47 --> Helper loaded: my_helper
INFO - 2023-08-19 16:23:47 --> Database Driver Class Initialized
INFO - 2023-08-19 16:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:23:47 --> Controller Class Initialized
DEBUG - 2023-08-19 16:23:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2023-08-19 16:23:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:23:47 --> Final output sent to browser
DEBUG - 2023-08-19 16:23:47 --> Total execution time: 0.0344
INFO - 2023-08-19 16:23:58 --> Config Class Initialized
INFO - 2023-08-19 16:23:58 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:23:58 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:23:58 --> Utf8 Class Initialized
INFO - 2023-08-19 16:23:58 --> URI Class Initialized
INFO - 2023-08-19 16:23:58 --> Router Class Initialized
INFO - 2023-08-19 16:23:58 --> Output Class Initialized
INFO - 2023-08-19 16:23:58 --> Security Class Initialized
DEBUG - 2023-08-19 16:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:23:58 --> Input Class Initialized
INFO - 2023-08-19 16:23:58 --> Language Class Initialized
INFO - 2023-08-19 16:23:58 --> Language Class Initialized
INFO - 2023-08-19 16:23:58 --> Config Class Initialized
INFO - 2023-08-19 16:23:58 --> Loader Class Initialized
INFO - 2023-08-19 16:23:58 --> Helper loaded: url_helper
INFO - 2023-08-19 16:23:58 --> Helper loaded: file_helper
INFO - 2023-08-19 16:23:58 --> Helper loaded: form_helper
INFO - 2023-08-19 16:23:58 --> Helper loaded: my_helper
INFO - 2023-08-19 16:23:58 --> Database Driver Class Initialized
INFO - 2023-08-19 16:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:23:58 --> Controller Class Initialized
INFO - 2023-08-19 16:23:58 --> Config Class Initialized
INFO - 2023-08-19 16:23:58 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:23:58 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:23:58 --> Utf8 Class Initialized
INFO - 2023-08-19 16:23:58 --> URI Class Initialized
INFO - 2023-08-19 16:23:58 --> Router Class Initialized
INFO - 2023-08-19 16:23:58 --> Output Class Initialized
INFO - 2023-08-19 16:23:58 --> Security Class Initialized
DEBUG - 2023-08-19 16:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:23:58 --> Input Class Initialized
INFO - 2023-08-19 16:23:58 --> Language Class Initialized
INFO - 2023-08-19 16:23:58 --> Language Class Initialized
INFO - 2023-08-19 16:23:58 --> Config Class Initialized
INFO - 2023-08-19 16:23:58 --> Loader Class Initialized
INFO - 2023-08-19 16:23:58 --> Helper loaded: url_helper
INFO - 2023-08-19 16:23:58 --> Helper loaded: file_helper
INFO - 2023-08-19 16:23:58 --> Helper loaded: form_helper
INFO - 2023-08-19 16:23:58 --> Helper loaded: my_helper
INFO - 2023-08-19 16:23:58 --> Database Driver Class Initialized
INFO - 2023-08-19 16:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:23:58 --> Controller Class Initialized
DEBUG - 2023-08-19 16:23:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-08-19 16:23:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:23:58 --> Final output sent to browser
DEBUG - 2023-08-19 16:23:58 --> Total execution time: 0.0250
INFO - 2023-08-19 16:23:58 --> Config Class Initialized
INFO - 2023-08-19 16:23:58 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:23:58 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:23:58 --> Utf8 Class Initialized
INFO - 2023-08-19 16:23:58 --> URI Class Initialized
INFO - 2023-08-19 16:23:58 --> Router Class Initialized
INFO - 2023-08-19 16:23:58 --> Output Class Initialized
INFO - 2023-08-19 16:23:58 --> Security Class Initialized
DEBUG - 2023-08-19 16:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:23:58 --> Input Class Initialized
INFO - 2023-08-19 16:23:58 --> Language Class Initialized
ERROR - 2023-08-19 16:23:58 --> 404 Page Not Found: /index
INFO - 2023-08-19 16:23:58 --> Config Class Initialized
INFO - 2023-08-19 16:23:58 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:23:58 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:23:58 --> Utf8 Class Initialized
INFO - 2023-08-19 16:23:58 --> URI Class Initialized
INFO - 2023-08-19 16:23:58 --> Router Class Initialized
INFO - 2023-08-19 16:23:58 --> Output Class Initialized
INFO - 2023-08-19 16:23:58 --> Security Class Initialized
DEBUG - 2023-08-19 16:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:23:58 --> Input Class Initialized
INFO - 2023-08-19 16:23:58 --> Language Class Initialized
INFO - 2023-08-19 16:23:58 --> Language Class Initialized
INFO - 2023-08-19 16:23:58 --> Config Class Initialized
INFO - 2023-08-19 16:23:58 --> Loader Class Initialized
INFO - 2023-08-19 16:23:58 --> Helper loaded: url_helper
INFO - 2023-08-19 16:23:58 --> Helper loaded: file_helper
INFO - 2023-08-19 16:23:58 --> Helper loaded: form_helper
INFO - 2023-08-19 16:23:58 --> Helper loaded: my_helper
INFO - 2023-08-19 16:23:58 --> Database Driver Class Initialized
INFO - 2023-08-19 16:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:23:58 --> Controller Class Initialized
INFO - 2023-08-19 16:23:59 --> Config Class Initialized
INFO - 2023-08-19 16:23:59 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:23:59 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:23:59 --> Utf8 Class Initialized
INFO - 2023-08-19 16:23:59 --> URI Class Initialized
INFO - 2023-08-19 16:23:59 --> Router Class Initialized
INFO - 2023-08-19 16:23:59 --> Output Class Initialized
INFO - 2023-08-19 16:23:59 --> Security Class Initialized
DEBUG - 2023-08-19 16:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:23:59 --> Input Class Initialized
INFO - 2023-08-19 16:23:59 --> Language Class Initialized
INFO - 2023-08-19 16:23:59 --> Language Class Initialized
INFO - 2023-08-19 16:23:59 --> Config Class Initialized
INFO - 2023-08-19 16:23:59 --> Loader Class Initialized
INFO - 2023-08-19 16:23:59 --> Helper loaded: url_helper
INFO - 2023-08-19 16:23:59 --> Helper loaded: file_helper
INFO - 2023-08-19 16:23:59 --> Helper loaded: form_helper
INFO - 2023-08-19 16:23:59 --> Helper loaded: my_helper
INFO - 2023-08-19 16:23:59 --> Database Driver Class Initialized
INFO - 2023-08-19 16:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:23:59 --> Controller Class Initialized
DEBUG - 2023-08-19 16:23:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2023-08-19 16:23:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:23:59 --> Final output sent to browser
DEBUG - 2023-08-19 16:23:59 --> Total execution time: 0.0326
INFO - 2023-08-19 16:24:08 --> Config Class Initialized
INFO - 2023-08-19 16:24:08 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:24:08 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:24:08 --> Utf8 Class Initialized
INFO - 2023-08-19 16:24:08 --> URI Class Initialized
INFO - 2023-08-19 16:24:08 --> Router Class Initialized
INFO - 2023-08-19 16:24:08 --> Output Class Initialized
INFO - 2023-08-19 16:24:08 --> Security Class Initialized
DEBUG - 2023-08-19 16:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:24:08 --> Input Class Initialized
INFO - 2023-08-19 16:24:08 --> Language Class Initialized
INFO - 2023-08-19 16:24:08 --> Language Class Initialized
INFO - 2023-08-19 16:24:08 --> Config Class Initialized
INFO - 2023-08-19 16:24:08 --> Loader Class Initialized
INFO - 2023-08-19 16:24:08 --> Helper loaded: url_helper
INFO - 2023-08-19 16:24:08 --> Helper loaded: file_helper
INFO - 2023-08-19 16:24:08 --> Helper loaded: form_helper
INFO - 2023-08-19 16:24:08 --> Helper loaded: my_helper
INFO - 2023-08-19 16:24:08 --> Database Driver Class Initialized
INFO - 2023-08-19 16:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:24:08 --> Controller Class Initialized
INFO - 2023-08-19 16:24:09 --> Config Class Initialized
INFO - 2023-08-19 16:24:09 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:24:09 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:24:09 --> Utf8 Class Initialized
INFO - 2023-08-19 16:24:09 --> URI Class Initialized
INFO - 2023-08-19 16:24:09 --> Router Class Initialized
INFO - 2023-08-19 16:24:09 --> Output Class Initialized
INFO - 2023-08-19 16:24:09 --> Security Class Initialized
DEBUG - 2023-08-19 16:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:24:09 --> Input Class Initialized
INFO - 2023-08-19 16:24:09 --> Language Class Initialized
INFO - 2023-08-19 16:24:09 --> Language Class Initialized
INFO - 2023-08-19 16:24:09 --> Config Class Initialized
INFO - 2023-08-19 16:24:09 --> Loader Class Initialized
INFO - 2023-08-19 16:24:09 --> Helper loaded: url_helper
INFO - 2023-08-19 16:24:09 --> Helper loaded: file_helper
INFO - 2023-08-19 16:24:09 --> Helper loaded: form_helper
INFO - 2023-08-19 16:24:09 --> Helper loaded: my_helper
INFO - 2023-08-19 16:24:09 --> Database Driver Class Initialized
INFO - 2023-08-19 16:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:24:09 --> Controller Class Initialized
DEBUG - 2023-08-19 16:24:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-08-19 16:24:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:24:09 --> Final output sent to browser
DEBUG - 2023-08-19 16:24:09 --> Total execution time: 0.0365
INFO - 2023-08-19 16:24:09 --> Config Class Initialized
INFO - 2023-08-19 16:24:09 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:24:09 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:24:09 --> Utf8 Class Initialized
INFO - 2023-08-19 16:24:09 --> URI Class Initialized
INFO - 2023-08-19 16:24:09 --> Router Class Initialized
INFO - 2023-08-19 16:24:09 --> Output Class Initialized
INFO - 2023-08-19 16:24:09 --> Security Class Initialized
DEBUG - 2023-08-19 16:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:24:09 --> Input Class Initialized
INFO - 2023-08-19 16:24:09 --> Language Class Initialized
ERROR - 2023-08-19 16:24:09 --> 404 Page Not Found: /index
INFO - 2023-08-19 16:24:09 --> Config Class Initialized
INFO - 2023-08-19 16:24:09 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:24:09 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:24:09 --> Utf8 Class Initialized
INFO - 2023-08-19 16:24:09 --> URI Class Initialized
INFO - 2023-08-19 16:24:09 --> Router Class Initialized
INFO - 2023-08-19 16:24:09 --> Output Class Initialized
INFO - 2023-08-19 16:24:09 --> Security Class Initialized
DEBUG - 2023-08-19 16:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:24:09 --> Input Class Initialized
INFO - 2023-08-19 16:24:09 --> Language Class Initialized
INFO - 2023-08-19 16:24:09 --> Language Class Initialized
INFO - 2023-08-19 16:24:09 --> Config Class Initialized
INFO - 2023-08-19 16:24:09 --> Loader Class Initialized
INFO - 2023-08-19 16:24:09 --> Helper loaded: url_helper
INFO - 2023-08-19 16:24:09 --> Helper loaded: file_helper
INFO - 2023-08-19 16:24:09 --> Helper loaded: form_helper
INFO - 2023-08-19 16:24:09 --> Helper loaded: my_helper
INFO - 2023-08-19 16:24:09 --> Database Driver Class Initialized
INFO - 2023-08-19 16:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:24:09 --> Controller Class Initialized
INFO - 2023-08-19 16:24:40 --> Config Class Initialized
INFO - 2023-08-19 16:24:40 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:24:40 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:24:40 --> Utf8 Class Initialized
INFO - 2023-08-19 16:24:40 --> URI Class Initialized
INFO - 2023-08-19 16:24:40 --> Router Class Initialized
INFO - 2023-08-19 16:24:40 --> Output Class Initialized
INFO - 2023-08-19 16:24:40 --> Security Class Initialized
DEBUG - 2023-08-19 16:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:24:40 --> Input Class Initialized
INFO - 2023-08-19 16:24:40 --> Language Class Initialized
INFO - 2023-08-19 16:24:40 --> Language Class Initialized
INFO - 2023-08-19 16:24:40 --> Config Class Initialized
INFO - 2023-08-19 16:24:40 --> Loader Class Initialized
INFO - 2023-08-19 16:24:40 --> Helper loaded: url_helper
INFO - 2023-08-19 16:24:40 --> Helper loaded: file_helper
INFO - 2023-08-19 16:24:40 --> Helper loaded: form_helper
INFO - 2023-08-19 16:24:40 --> Helper loaded: my_helper
INFO - 2023-08-19 16:24:40 --> Database Driver Class Initialized
INFO - 2023-08-19 16:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:24:40 --> Controller Class Initialized
DEBUG - 2023-08-19 16:24:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-08-19 16:24:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:24:40 --> Final output sent to browser
DEBUG - 2023-08-19 16:24:40 --> Total execution time: 0.0329
INFO - 2023-08-19 16:24:40 --> Config Class Initialized
INFO - 2023-08-19 16:24:40 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:24:40 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:24:40 --> Utf8 Class Initialized
INFO - 2023-08-19 16:24:40 --> URI Class Initialized
INFO - 2023-08-19 16:24:40 --> Router Class Initialized
INFO - 2023-08-19 16:24:40 --> Output Class Initialized
INFO - 2023-08-19 16:24:40 --> Security Class Initialized
DEBUG - 2023-08-19 16:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:24:40 --> Input Class Initialized
INFO - 2023-08-19 16:24:40 --> Language Class Initialized
ERROR - 2023-08-19 16:24:40 --> 404 Page Not Found: /index
INFO - 2023-08-19 16:24:41 --> Config Class Initialized
INFO - 2023-08-19 16:24:41 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:24:41 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:24:41 --> Utf8 Class Initialized
INFO - 2023-08-19 16:24:41 --> URI Class Initialized
INFO - 2023-08-19 16:24:41 --> Router Class Initialized
INFO - 2023-08-19 16:24:41 --> Output Class Initialized
INFO - 2023-08-19 16:24:41 --> Security Class Initialized
DEBUG - 2023-08-19 16:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:24:41 --> Input Class Initialized
INFO - 2023-08-19 16:24:41 --> Language Class Initialized
INFO - 2023-08-19 16:24:41 --> Language Class Initialized
INFO - 2023-08-19 16:24:41 --> Config Class Initialized
INFO - 2023-08-19 16:24:41 --> Loader Class Initialized
INFO - 2023-08-19 16:24:41 --> Helper loaded: url_helper
INFO - 2023-08-19 16:24:41 --> Helper loaded: file_helper
INFO - 2023-08-19 16:24:41 --> Helper loaded: form_helper
INFO - 2023-08-19 16:24:41 --> Helper loaded: my_helper
INFO - 2023-08-19 16:24:41 --> Database Driver Class Initialized
INFO - 2023-08-19 16:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:24:41 --> Controller Class Initialized
INFO - 2023-08-19 16:24:41 --> Config Class Initialized
INFO - 2023-08-19 16:24:41 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:24:41 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:24:41 --> Utf8 Class Initialized
INFO - 2023-08-19 16:24:41 --> URI Class Initialized
DEBUG - 2023-08-19 16:24:41 --> No URI present. Default controller set.
INFO - 2023-08-19 16:24:41 --> Router Class Initialized
INFO - 2023-08-19 16:24:41 --> Output Class Initialized
INFO - 2023-08-19 16:24:41 --> Security Class Initialized
DEBUG - 2023-08-19 16:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:24:41 --> Input Class Initialized
INFO - 2023-08-19 16:24:41 --> Language Class Initialized
INFO - 2023-08-19 16:24:41 --> Language Class Initialized
INFO - 2023-08-19 16:24:41 --> Config Class Initialized
INFO - 2023-08-19 16:24:41 --> Loader Class Initialized
INFO - 2023-08-19 16:24:41 --> Helper loaded: url_helper
INFO - 2023-08-19 16:24:41 --> Helper loaded: file_helper
INFO - 2023-08-19 16:24:41 --> Helper loaded: form_helper
INFO - 2023-08-19 16:24:41 --> Helper loaded: my_helper
INFO - 2023-08-19 16:24:41 --> Database Driver Class Initialized
INFO - 2023-08-19 16:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:24:41 --> Controller Class Initialized
DEBUG - 2023-08-19 16:24:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 16:24:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:24:41 --> Final output sent to browser
DEBUG - 2023-08-19 16:24:41 --> Total execution time: 0.0298
INFO - 2023-08-19 16:24:44 --> Config Class Initialized
INFO - 2023-08-19 16:24:44 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:24:44 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:24:44 --> Utf8 Class Initialized
INFO - 2023-08-19 16:24:44 --> URI Class Initialized
INFO - 2023-08-19 16:24:44 --> Router Class Initialized
INFO - 2023-08-19 16:24:44 --> Output Class Initialized
INFO - 2023-08-19 16:24:44 --> Security Class Initialized
DEBUG - 2023-08-19 16:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:24:44 --> Input Class Initialized
INFO - 2023-08-19 16:24:44 --> Language Class Initialized
INFO - 2023-08-19 16:24:44 --> Language Class Initialized
INFO - 2023-08-19 16:24:44 --> Config Class Initialized
INFO - 2023-08-19 16:24:44 --> Loader Class Initialized
INFO - 2023-08-19 16:24:44 --> Helper loaded: url_helper
INFO - 2023-08-19 16:24:44 --> Helper loaded: file_helper
INFO - 2023-08-19 16:24:44 --> Helper loaded: form_helper
INFO - 2023-08-19 16:24:44 --> Helper loaded: my_helper
INFO - 2023-08-19 16:24:44 --> Database Driver Class Initialized
INFO - 2023-08-19 16:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:24:44 --> Controller Class Initialized
DEBUG - 2023-08-19 16:24:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 16:24:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:24:44 --> Final output sent to browser
DEBUG - 2023-08-19 16:24:44 --> Total execution time: 0.0389
INFO - 2023-08-19 16:24:47 --> Config Class Initialized
INFO - 2023-08-19 16:24:47 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:24:47 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:24:47 --> Utf8 Class Initialized
INFO - 2023-08-19 16:24:47 --> URI Class Initialized
INFO - 2023-08-19 16:24:47 --> Router Class Initialized
INFO - 2023-08-19 16:24:47 --> Output Class Initialized
INFO - 2023-08-19 16:24:47 --> Security Class Initialized
DEBUG - 2023-08-19 16:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:24:47 --> Input Class Initialized
INFO - 2023-08-19 16:24:47 --> Language Class Initialized
INFO - 2023-08-19 16:24:47 --> Language Class Initialized
INFO - 2023-08-19 16:24:47 --> Config Class Initialized
INFO - 2023-08-19 16:24:47 --> Loader Class Initialized
INFO - 2023-08-19 16:24:47 --> Helper loaded: url_helper
INFO - 2023-08-19 16:24:47 --> Helper loaded: file_helper
INFO - 2023-08-19 16:24:47 --> Helper loaded: form_helper
INFO - 2023-08-19 16:24:47 --> Helper loaded: my_helper
INFO - 2023-08-19 16:24:47 --> Database Driver Class Initialized
INFO - 2023-08-19 16:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:24:47 --> Controller Class Initialized
DEBUG - 2023-08-19 16:24:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-08-19 16:24:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:24:47 --> Final output sent to browser
DEBUG - 2023-08-19 16:24:47 --> Total execution time: 0.0336
INFO - 2023-08-19 16:24:47 --> Config Class Initialized
INFO - 2023-08-19 16:24:47 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:24:47 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:24:47 --> Utf8 Class Initialized
INFO - 2023-08-19 16:24:47 --> URI Class Initialized
INFO - 2023-08-19 16:24:47 --> Router Class Initialized
INFO - 2023-08-19 16:24:47 --> Output Class Initialized
INFO - 2023-08-19 16:24:47 --> Security Class Initialized
DEBUG - 2023-08-19 16:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:24:47 --> Input Class Initialized
INFO - 2023-08-19 16:24:47 --> Language Class Initialized
INFO - 2023-08-19 16:24:47 --> Language Class Initialized
INFO - 2023-08-19 16:24:47 --> Config Class Initialized
INFO - 2023-08-19 16:24:47 --> Loader Class Initialized
INFO - 2023-08-19 16:24:47 --> Helper loaded: url_helper
INFO - 2023-08-19 16:24:47 --> Helper loaded: file_helper
INFO - 2023-08-19 16:24:47 --> Helper loaded: form_helper
INFO - 2023-08-19 16:24:47 --> Helper loaded: my_helper
INFO - 2023-08-19 16:24:47 --> Database Driver Class Initialized
INFO - 2023-08-19 16:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:24:47 --> Controller Class Initialized
INFO - 2023-08-19 16:24:54 --> Config Class Initialized
INFO - 2023-08-19 16:24:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:24:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:24:54 --> Utf8 Class Initialized
INFO - 2023-08-19 16:24:54 --> URI Class Initialized
DEBUG - 2023-08-19 16:24:54 --> No URI present. Default controller set.
INFO - 2023-08-19 16:24:54 --> Router Class Initialized
INFO - 2023-08-19 16:24:54 --> Output Class Initialized
INFO - 2023-08-19 16:24:54 --> Security Class Initialized
DEBUG - 2023-08-19 16:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:24:54 --> Input Class Initialized
INFO - 2023-08-19 16:24:54 --> Language Class Initialized
INFO - 2023-08-19 16:24:54 --> Language Class Initialized
INFO - 2023-08-19 16:24:54 --> Config Class Initialized
INFO - 2023-08-19 16:24:54 --> Loader Class Initialized
INFO - 2023-08-19 16:24:54 --> Helper loaded: url_helper
INFO - 2023-08-19 16:24:54 --> Helper loaded: file_helper
INFO - 2023-08-19 16:24:54 --> Helper loaded: form_helper
INFO - 2023-08-19 16:24:54 --> Helper loaded: my_helper
INFO - 2023-08-19 16:24:54 --> Database Driver Class Initialized
INFO - 2023-08-19 16:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:24:54 --> Controller Class Initialized
DEBUG - 2023-08-19 16:24:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 16:24:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:24:54 --> Final output sent to browser
DEBUG - 2023-08-19 16:24:54 --> Total execution time: 0.0284
INFO - 2023-08-19 16:24:55 --> Config Class Initialized
INFO - 2023-08-19 16:24:55 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:24:55 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:24:55 --> Utf8 Class Initialized
INFO - 2023-08-19 16:24:55 --> URI Class Initialized
DEBUG - 2023-08-19 16:24:55 --> No URI present. Default controller set.
INFO - 2023-08-19 16:24:55 --> Router Class Initialized
INFO - 2023-08-19 16:24:55 --> Output Class Initialized
INFO - 2023-08-19 16:24:55 --> Security Class Initialized
DEBUG - 2023-08-19 16:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:24:55 --> Input Class Initialized
INFO - 2023-08-19 16:24:55 --> Language Class Initialized
INFO - 2023-08-19 16:24:55 --> Language Class Initialized
INFO - 2023-08-19 16:24:55 --> Config Class Initialized
INFO - 2023-08-19 16:24:55 --> Loader Class Initialized
INFO - 2023-08-19 16:24:55 --> Helper loaded: url_helper
INFO - 2023-08-19 16:24:55 --> Helper loaded: file_helper
INFO - 2023-08-19 16:24:55 --> Helper loaded: form_helper
INFO - 2023-08-19 16:24:55 --> Helper loaded: my_helper
INFO - 2023-08-19 16:24:55 --> Database Driver Class Initialized
INFO - 2023-08-19 16:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:24:55 --> Controller Class Initialized
DEBUG - 2023-08-19 16:24:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 16:24:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:24:55 --> Final output sent to browser
DEBUG - 2023-08-19 16:24:55 --> Total execution time: 0.0316
INFO - 2023-08-19 16:24:56 --> Config Class Initialized
INFO - 2023-08-19 16:24:56 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:24:56 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:24:56 --> Utf8 Class Initialized
INFO - 2023-08-19 16:24:56 --> URI Class Initialized
DEBUG - 2023-08-19 16:24:56 --> No URI present. Default controller set.
INFO - 2023-08-19 16:24:56 --> Router Class Initialized
INFO - 2023-08-19 16:24:56 --> Output Class Initialized
INFO - 2023-08-19 16:24:56 --> Security Class Initialized
DEBUG - 2023-08-19 16:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:24:56 --> Input Class Initialized
INFO - 2023-08-19 16:24:56 --> Language Class Initialized
INFO - 2023-08-19 16:24:56 --> Language Class Initialized
INFO - 2023-08-19 16:24:56 --> Config Class Initialized
INFO - 2023-08-19 16:24:56 --> Loader Class Initialized
INFO - 2023-08-19 16:24:56 --> Helper loaded: url_helper
INFO - 2023-08-19 16:24:56 --> Helper loaded: file_helper
INFO - 2023-08-19 16:24:56 --> Helper loaded: form_helper
INFO - 2023-08-19 16:24:56 --> Helper loaded: my_helper
INFO - 2023-08-19 16:24:56 --> Database Driver Class Initialized
INFO - 2023-08-19 16:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:24:56 --> Controller Class Initialized
DEBUG - 2023-08-19 16:24:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 16:24:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:24:56 --> Final output sent to browser
DEBUG - 2023-08-19 16:24:56 --> Total execution time: 0.0278
INFO - 2023-08-19 16:24:57 --> Config Class Initialized
INFO - 2023-08-19 16:24:57 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:24:57 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:24:57 --> Utf8 Class Initialized
INFO - 2023-08-19 16:24:57 --> URI Class Initialized
DEBUG - 2023-08-19 16:24:57 --> No URI present. Default controller set.
INFO - 2023-08-19 16:24:57 --> Router Class Initialized
INFO - 2023-08-19 16:24:57 --> Output Class Initialized
INFO - 2023-08-19 16:24:57 --> Security Class Initialized
DEBUG - 2023-08-19 16:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:24:57 --> Input Class Initialized
INFO - 2023-08-19 16:24:57 --> Language Class Initialized
INFO - 2023-08-19 16:24:57 --> Language Class Initialized
INFO - 2023-08-19 16:24:57 --> Config Class Initialized
INFO - 2023-08-19 16:24:57 --> Loader Class Initialized
INFO - 2023-08-19 16:24:57 --> Helper loaded: url_helper
INFO - 2023-08-19 16:24:57 --> Helper loaded: file_helper
INFO - 2023-08-19 16:24:57 --> Helper loaded: form_helper
INFO - 2023-08-19 16:24:57 --> Helper loaded: my_helper
INFO - 2023-08-19 16:24:57 --> Database Driver Class Initialized
INFO - 2023-08-19 16:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:24:57 --> Controller Class Initialized
DEBUG - 2023-08-19 16:24:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 16:24:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:24:57 --> Final output sent to browser
DEBUG - 2023-08-19 16:24:57 --> Total execution time: 0.0278
INFO - 2023-08-19 16:24:58 --> Config Class Initialized
INFO - 2023-08-19 16:24:58 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:24:58 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:24:58 --> Utf8 Class Initialized
INFO - 2023-08-19 16:24:58 --> URI Class Initialized
DEBUG - 2023-08-19 16:24:58 --> No URI present. Default controller set.
INFO - 2023-08-19 16:24:58 --> Router Class Initialized
INFO - 2023-08-19 16:24:58 --> Output Class Initialized
INFO - 2023-08-19 16:24:58 --> Security Class Initialized
DEBUG - 2023-08-19 16:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:24:58 --> Input Class Initialized
INFO - 2023-08-19 16:24:58 --> Language Class Initialized
INFO - 2023-08-19 16:24:58 --> Language Class Initialized
INFO - 2023-08-19 16:24:58 --> Config Class Initialized
INFO - 2023-08-19 16:24:58 --> Loader Class Initialized
INFO - 2023-08-19 16:24:58 --> Helper loaded: url_helper
INFO - 2023-08-19 16:24:58 --> Helper loaded: file_helper
INFO - 2023-08-19 16:24:58 --> Helper loaded: form_helper
INFO - 2023-08-19 16:24:58 --> Helper loaded: my_helper
INFO - 2023-08-19 16:24:58 --> Database Driver Class Initialized
INFO - 2023-08-19 16:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:24:58 --> Controller Class Initialized
DEBUG - 2023-08-19 16:24:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 16:24:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:24:58 --> Final output sent to browser
DEBUG - 2023-08-19 16:24:58 --> Total execution time: 0.0378
INFO - 2023-08-19 16:24:59 --> Config Class Initialized
INFO - 2023-08-19 16:24:59 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:24:59 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:24:59 --> Utf8 Class Initialized
INFO - 2023-08-19 16:24:59 --> URI Class Initialized
INFO - 2023-08-19 16:24:59 --> Router Class Initialized
INFO - 2023-08-19 16:24:59 --> Output Class Initialized
INFO - 2023-08-19 16:24:59 --> Security Class Initialized
DEBUG - 2023-08-19 16:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:24:59 --> Input Class Initialized
INFO - 2023-08-19 16:24:59 --> Language Class Initialized
INFO - 2023-08-19 16:24:59 --> Language Class Initialized
INFO - 2023-08-19 16:24:59 --> Config Class Initialized
INFO - 2023-08-19 16:24:59 --> Loader Class Initialized
INFO - 2023-08-19 16:24:59 --> Helper loaded: url_helper
INFO - 2023-08-19 16:24:59 --> Helper loaded: file_helper
INFO - 2023-08-19 16:24:59 --> Helper loaded: form_helper
INFO - 2023-08-19 16:24:59 --> Helper loaded: my_helper
INFO - 2023-08-19 16:24:59 --> Database Driver Class Initialized
INFO - 2023-08-19 16:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:24:59 --> Controller Class Initialized
DEBUG - 2023-08-19 16:24:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 16:24:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:24:59 --> Final output sent to browser
DEBUG - 2023-08-19 16:24:59 --> Total execution time: 0.0301
INFO - 2023-08-19 16:25:00 --> Config Class Initialized
INFO - 2023-08-19 16:25:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:25:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:25:00 --> Utf8 Class Initialized
INFO - 2023-08-19 16:25:00 --> URI Class Initialized
DEBUG - 2023-08-19 16:25:00 --> No URI present. Default controller set.
INFO - 2023-08-19 16:25:00 --> Router Class Initialized
INFO - 2023-08-19 16:25:00 --> Output Class Initialized
INFO - 2023-08-19 16:25:00 --> Security Class Initialized
DEBUG - 2023-08-19 16:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:25:00 --> Input Class Initialized
INFO - 2023-08-19 16:25:00 --> Language Class Initialized
INFO - 2023-08-19 16:25:00 --> Language Class Initialized
INFO - 2023-08-19 16:25:00 --> Config Class Initialized
INFO - 2023-08-19 16:25:00 --> Loader Class Initialized
INFO - 2023-08-19 16:25:00 --> Helper loaded: url_helper
INFO - 2023-08-19 16:25:00 --> Helper loaded: file_helper
INFO - 2023-08-19 16:25:00 --> Helper loaded: form_helper
INFO - 2023-08-19 16:25:00 --> Helper loaded: my_helper
INFO - 2023-08-19 16:25:00 --> Database Driver Class Initialized
INFO - 2023-08-19 16:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:25:00 --> Controller Class Initialized
DEBUG - 2023-08-19 16:25:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 16:25:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:25:00 --> Final output sent to browser
DEBUG - 2023-08-19 16:25:00 --> Total execution time: 0.0319
INFO - 2023-08-19 16:25:03 --> Config Class Initialized
INFO - 2023-08-19 16:25:03 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:25:03 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:25:03 --> Utf8 Class Initialized
INFO - 2023-08-19 16:25:03 --> URI Class Initialized
DEBUG - 2023-08-19 16:25:03 --> No URI present. Default controller set.
INFO - 2023-08-19 16:25:03 --> Router Class Initialized
INFO - 2023-08-19 16:25:03 --> Output Class Initialized
INFO - 2023-08-19 16:25:03 --> Security Class Initialized
DEBUG - 2023-08-19 16:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:25:03 --> Input Class Initialized
INFO - 2023-08-19 16:25:03 --> Language Class Initialized
INFO - 2023-08-19 16:25:03 --> Language Class Initialized
INFO - 2023-08-19 16:25:03 --> Config Class Initialized
INFO - 2023-08-19 16:25:03 --> Loader Class Initialized
INFO - 2023-08-19 16:25:03 --> Helper loaded: url_helper
INFO - 2023-08-19 16:25:03 --> Helper loaded: file_helper
INFO - 2023-08-19 16:25:03 --> Helper loaded: form_helper
INFO - 2023-08-19 16:25:03 --> Helper loaded: my_helper
INFO - 2023-08-19 16:25:03 --> Database Driver Class Initialized
INFO - 2023-08-19 16:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:25:03 --> Controller Class Initialized
DEBUG - 2023-08-19 16:25:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 16:25:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:25:03 --> Final output sent to browser
DEBUG - 2023-08-19 16:25:03 --> Total execution time: 0.0722
INFO - 2023-08-19 16:25:07 --> Config Class Initialized
INFO - 2023-08-19 16:25:07 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:25:07 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:25:07 --> Utf8 Class Initialized
INFO - 2023-08-19 16:25:07 --> URI Class Initialized
INFO - 2023-08-19 16:25:07 --> Router Class Initialized
INFO - 2023-08-19 16:25:07 --> Output Class Initialized
INFO - 2023-08-19 16:25:07 --> Security Class Initialized
DEBUG - 2023-08-19 16:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:25:07 --> Input Class Initialized
INFO - 2023-08-19 16:25:07 --> Language Class Initialized
INFO - 2023-08-19 16:25:07 --> Language Class Initialized
INFO - 2023-08-19 16:25:07 --> Config Class Initialized
INFO - 2023-08-19 16:25:07 --> Loader Class Initialized
INFO - 2023-08-19 16:25:07 --> Helper loaded: url_helper
INFO - 2023-08-19 16:25:07 --> Helper loaded: file_helper
INFO - 2023-08-19 16:25:07 --> Helper loaded: form_helper
INFO - 2023-08-19 16:25:07 --> Helper loaded: my_helper
INFO - 2023-08-19 16:25:07 --> Database Driver Class Initialized
INFO - 2023-08-19 16:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:25:07 --> Controller Class Initialized
DEBUG - 2023-08-19 16:25:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 16:25:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:25:07 --> Final output sent to browser
DEBUG - 2023-08-19 16:25:07 --> Total execution time: 0.0497
INFO - 2023-08-19 16:25:18 --> Config Class Initialized
INFO - 2023-08-19 16:25:18 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:25:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:25:18 --> Utf8 Class Initialized
INFO - 2023-08-19 16:25:18 --> URI Class Initialized
INFO - 2023-08-19 16:25:18 --> Router Class Initialized
INFO - 2023-08-19 16:25:18 --> Output Class Initialized
INFO - 2023-08-19 16:25:18 --> Security Class Initialized
DEBUG - 2023-08-19 16:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:25:18 --> Input Class Initialized
INFO - 2023-08-19 16:25:18 --> Language Class Initialized
INFO - 2023-08-19 16:25:18 --> Language Class Initialized
INFO - 2023-08-19 16:25:18 --> Config Class Initialized
INFO - 2023-08-19 16:25:18 --> Loader Class Initialized
INFO - 2023-08-19 16:25:18 --> Helper loaded: url_helper
INFO - 2023-08-19 16:25:18 --> Helper loaded: file_helper
INFO - 2023-08-19 16:25:18 --> Helper loaded: form_helper
INFO - 2023-08-19 16:25:18 --> Helper loaded: my_helper
INFO - 2023-08-19 16:25:18 --> Database Driver Class Initialized
INFO - 2023-08-19 16:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:25:18 --> Controller Class Initialized
DEBUG - 2023-08-19 16:25:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 16:25:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:25:18 --> Final output sent to browser
DEBUG - 2023-08-19 16:25:18 --> Total execution time: 0.0311
INFO - 2023-08-19 16:25:19 --> Config Class Initialized
INFO - 2023-08-19 16:25:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:25:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:25:19 --> Utf8 Class Initialized
INFO - 2023-08-19 16:25:19 --> URI Class Initialized
INFO - 2023-08-19 16:25:19 --> Router Class Initialized
INFO - 2023-08-19 16:25:19 --> Output Class Initialized
INFO - 2023-08-19 16:25:19 --> Security Class Initialized
DEBUG - 2023-08-19 16:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:25:19 --> Input Class Initialized
INFO - 2023-08-19 16:25:19 --> Language Class Initialized
INFO - 2023-08-19 16:25:19 --> Language Class Initialized
INFO - 2023-08-19 16:25:19 --> Config Class Initialized
INFO - 2023-08-19 16:25:19 --> Loader Class Initialized
INFO - 2023-08-19 16:25:19 --> Helper loaded: url_helper
INFO - 2023-08-19 16:25:19 --> Helper loaded: file_helper
INFO - 2023-08-19 16:25:19 --> Helper loaded: form_helper
INFO - 2023-08-19 16:25:19 --> Helper loaded: my_helper
INFO - 2023-08-19 16:25:19 --> Database Driver Class Initialized
INFO - 2023-08-19 16:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:25:19 --> Controller Class Initialized
DEBUG - 2023-08-19 16:25:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 16:25:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:25:19 --> Final output sent to browser
DEBUG - 2023-08-19 16:25:19 --> Total execution time: 0.0375
INFO - 2023-08-19 16:25:20 --> Config Class Initialized
INFO - 2023-08-19 16:25:20 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:25:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:25:20 --> Utf8 Class Initialized
INFO - 2023-08-19 16:25:20 --> URI Class Initialized
INFO - 2023-08-19 16:25:20 --> Router Class Initialized
INFO - 2023-08-19 16:25:20 --> Output Class Initialized
INFO - 2023-08-19 16:25:20 --> Security Class Initialized
DEBUG - 2023-08-19 16:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:25:20 --> Input Class Initialized
INFO - 2023-08-19 16:25:20 --> Language Class Initialized
INFO - 2023-08-19 16:25:20 --> Language Class Initialized
INFO - 2023-08-19 16:25:20 --> Config Class Initialized
INFO - 2023-08-19 16:25:20 --> Loader Class Initialized
INFO - 2023-08-19 16:25:20 --> Helper loaded: url_helper
INFO - 2023-08-19 16:25:20 --> Helper loaded: file_helper
INFO - 2023-08-19 16:25:20 --> Helper loaded: form_helper
INFO - 2023-08-19 16:25:20 --> Helper loaded: my_helper
INFO - 2023-08-19 16:25:20 --> Database Driver Class Initialized
INFO - 2023-08-19 16:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:25:20 --> Controller Class Initialized
DEBUG - 2023-08-19 16:25:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 16:25:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:25:20 --> Final output sent to browser
DEBUG - 2023-08-19 16:25:20 --> Total execution time: 0.0303
INFO - 2023-08-19 16:26:51 --> Config Class Initialized
INFO - 2023-08-19 16:26:51 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:26:51 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:26:51 --> Utf8 Class Initialized
INFO - 2023-08-19 16:26:51 --> URI Class Initialized
INFO - 2023-08-19 16:26:51 --> Router Class Initialized
INFO - 2023-08-19 16:26:51 --> Output Class Initialized
INFO - 2023-08-19 16:26:51 --> Security Class Initialized
DEBUG - 2023-08-19 16:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:26:51 --> Input Class Initialized
INFO - 2023-08-19 16:26:51 --> Language Class Initialized
INFO - 2023-08-19 16:26:51 --> Language Class Initialized
INFO - 2023-08-19 16:26:51 --> Config Class Initialized
INFO - 2023-08-19 16:26:51 --> Loader Class Initialized
INFO - 2023-08-19 16:26:51 --> Helper loaded: url_helper
INFO - 2023-08-19 16:26:51 --> Helper loaded: file_helper
INFO - 2023-08-19 16:26:51 --> Helper loaded: form_helper
INFO - 2023-08-19 16:26:51 --> Helper loaded: my_helper
INFO - 2023-08-19 16:26:51 --> Database Driver Class Initialized
INFO - 2023-08-19 16:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:26:51 --> Controller Class Initialized
DEBUG - 2023-08-19 16:26:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 16:26:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:26:51 --> Final output sent to browser
DEBUG - 2023-08-19 16:26:51 --> Total execution time: 0.0695
INFO - 2023-08-19 16:26:54 --> Config Class Initialized
INFO - 2023-08-19 16:26:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:26:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:26:54 --> Utf8 Class Initialized
INFO - 2023-08-19 16:26:54 --> URI Class Initialized
INFO - 2023-08-19 16:26:54 --> Router Class Initialized
INFO - 2023-08-19 16:26:54 --> Output Class Initialized
INFO - 2023-08-19 16:26:54 --> Security Class Initialized
DEBUG - 2023-08-19 16:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:26:54 --> Input Class Initialized
INFO - 2023-08-19 16:26:54 --> Language Class Initialized
INFO - 2023-08-19 16:26:54 --> Language Class Initialized
INFO - 2023-08-19 16:26:54 --> Config Class Initialized
INFO - 2023-08-19 16:26:54 --> Loader Class Initialized
INFO - 2023-08-19 16:26:54 --> Helper loaded: url_helper
INFO - 2023-08-19 16:26:54 --> Helper loaded: file_helper
INFO - 2023-08-19 16:26:54 --> Helper loaded: form_helper
INFO - 2023-08-19 16:26:54 --> Helper loaded: my_helper
INFO - 2023-08-19 16:26:54 --> Database Driver Class Initialized
INFO - 2023-08-19 16:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:26:54 --> Controller Class Initialized
DEBUG - 2023-08-19 16:26:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 16:26:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:26:54 --> Final output sent to browser
DEBUG - 2023-08-19 16:26:54 --> Total execution time: 0.0321
INFO - 2023-08-19 16:26:55 --> Config Class Initialized
INFO - 2023-08-19 16:26:55 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:26:55 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:26:55 --> Utf8 Class Initialized
INFO - 2023-08-19 16:26:55 --> URI Class Initialized
INFO - 2023-08-19 16:26:55 --> Router Class Initialized
INFO - 2023-08-19 16:26:55 --> Output Class Initialized
INFO - 2023-08-19 16:26:55 --> Security Class Initialized
DEBUG - 2023-08-19 16:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:26:55 --> Input Class Initialized
INFO - 2023-08-19 16:26:55 --> Language Class Initialized
INFO - 2023-08-19 16:26:55 --> Language Class Initialized
INFO - 2023-08-19 16:26:55 --> Config Class Initialized
INFO - 2023-08-19 16:26:55 --> Loader Class Initialized
INFO - 2023-08-19 16:26:55 --> Helper loaded: url_helper
INFO - 2023-08-19 16:26:55 --> Helper loaded: file_helper
INFO - 2023-08-19 16:26:55 --> Helper loaded: form_helper
INFO - 2023-08-19 16:26:55 --> Helper loaded: my_helper
INFO - 2023-08-19 16:26:55 --> Database Driver Class Initialized
INFO - 2023-08-19 16:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:26:55 --> Controller Class Initialized
DEBUG - 2023-08-19 16:26:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 16:26:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:26:55 --> Final output sent to browser
DEBUG - 2023-08-19 16:26:55 --> Total execution time: 0.0293
INFO - 2023-08-19 16:27:03 --> Config Class Initialized
INFO - 2023-08-19 16:27:03 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:27:03 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:27:03 --> Utf8 Class Initialized
INFO - 2023-08-19 16:27:03 --> URI Class Initialized
INFO - 2023-08-19 16:27:03 --> Router Class Initialized
INFO - 2023-08-19 16:27:03 --> Output Class Initialized
INFO - 2023-08-19 16:27:03 --> Security Class Initialized
DEBUG - 2023-08-19 16:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:27:03 --> Input Class Initialized
INFO - 2023-08-19 16:27:03 --> Language Class Initialized
INFO - 2023-08-19 16:27:03 --> Language Class Initialized
INFO - 2023-08-19 16:27:03 --> Config Class Initialized
INFO - 2023-08-19 16:27:03 --> Loader Class Initialized
INFO - 2023-08-19 16:27:03 --> Helper loaded: url_helper
INFO - 2023-08-19 16:27:03 --> Helper loaded: file_helper
INFO - 2023-08-19 16:27:03 --> Helper loaded: form_helper
INFO - 2023-08-19 16:27:03 --> Helper loaded: my_helper
INFO - 2023-08-19 16:27:03 --> Database Driver Class Initialized
INFO - 2023-08-19 16:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:27:03 --> Controller Class Initialized
DEBUG - 2023-08-19 16:27:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 16:27:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:27:03 --> Final output sent to browser
DEBUG - 2023-08-19 16:27:03 --> Total execution time: 0.0519
INFO - 2023-08-19 16:27:04 --> Config Class Initialized
INFO - 2023-08-19 16:27:04 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:27:04 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:27:04 --> Utf8 Class Initialized
INFO - 2023-08-19 16:27:04 --> URI Class Initialized
DEBUG - 2023-08-19 16:27:04 --> No URI present. Default controller set.
INFO - 2023-08-19 16:27:04 --> Router Class Initialized
INFO - 2023-08-19 16:27:04 --> Output Class Initialized
INFO - 2023-08-19 16:27:04 --> Security Class Initialized
DEBUG - 2023-08-19 16:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:27:04 --> Input Class Initialized
INFO - 2023-08-19 16:27:04 --> Language Class Initialized
INFO - 2023-08-19 16:27:04 --> Language Class Initialized
INFO - 2023-08-19 16:27:04 --> Config Class Initialized
INFO - 2023-08-19 16:27:04 --> Loader Class Initialized
INFO - 2023-08-19 16:27:04 --> Helper loaded: url_helper
INFO - 2023-08-19 16:27:04 --> Helper loaded: file_helper
INFO - 2023-08-19 16:27:04 --> Helper loaded: form_helper
INFO - 2023-08-19 16:27:04 --> Helper loaded: my_helper
INFO - 2023-08-19 16:27:04 --> Database Driver Class Initialized
INFO - 2023-08-19 16:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:27:04 --> Controller Class Initialized
DEBUG - 2023-08-19 16:27:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 16:27:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:27:04 --> Final output sent to browser
DEBUG - 2023-08-19 16:27:04 --> Total execution time: 0.0500
INFO - 2023-08-19 16:27:14 --> Config Class Initialized
INFO - 2023-08-19 16:27:14 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:27:14 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:27:14 --> Utf8 Class Initialized
INFO - 2023-08-19 16:27:14 --> URI Class Initialized
DEBUG - 2023-08-19 16:27:14 --> No URI present. Default controller set.
INFO - 2023-08-19 16:27:14 --> Router Class Initialized
INFO - 2023-08-19 16:27:14 --> Output Class Initialized
INFO - 2023-08-19 16:27:14 --> Security Class Initialized
DEBUG - 2023-08-19 16:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:27:14 --> Input Class Initialized
INFO - 2023-08-19 16:27:14 --> Language Class Initialized
INFO - 2023-08-19 16:27:14 --> Language Class Initialized
INFO - 2023-08-19 16:27:14 --> Config Class Initialized
INFO - 2023-08-19 16:27:14 --> Loader Class Initialized
INFO - 2023-08-19 16:27:14 --> Helper loaded: url_helper
INFO - 2023-08-19 16:27:14 --> Helper loaded: file_helper
INFO - 2023-08-19 16:27:14 --> Helper loaded: form_helper
INFO - 2023-08-19 16:27:14 --> Helper loaded: my_helper
INFO - 2023-08-19 16:27:14 --> Database Driver Class Initialized
INFO - 2023-08-19 16:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:27:14 --> Controller Class Initialized
DEBUG - 2023-08-19 16:27:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 16:27:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:27:14 --> Final output sent to browser
DEBUG - 2023-08-19 16:27:14 --> Total execution time: 0.0308
INFO - 2023-08-19 16:27:18 --> Config Class Initialized
INFO - 2023-08-19 16:27:18 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:27:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:27:18 --> Utf8 Class Initialized
INFO - 2023-08-19 16:27:18 --> URI Class Initialized
INFO - 2023-08-19 16:27:18 --> Router Class Initialized
INFO - 2023-08-19 16:27:18 --> Output Class Initialized
INFO - 2023-08-19 16:27:18 --> Security Class Initialized
DEBUG - 2023-08-19 16:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:27:18 --> Input Class Initialized
INFO - 2023-08-19 16:27:18 --> Language Class Initialized
INFO - 2023-08-19 16:27:18 --> Language Class Initialized
INFO - 2023-08-19 16:27:18 --> Config Class Initialized
INFO - 2023-08-19 16:27:18 --> Loader Class Initialized
INFO - 2023-08-19 16:27:18 --> Helper loaded: url_helper
INFO - 2023-08-19 16:27:18 --> Helper loaded: file_helper
INFO - 2023-08-19 16:27:18 --> Helper loaded: form_helper
INFO - 2023-08-19 16:27:18 --> Helper loaded: my_helper
INFO - 2023-08-19 16:27:18 --> Database Driver Class Initialized
INFO - 2023-08-19 16:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:27:18 --> Controller Class Initialized
DEBUG - 2023-08-19 16:27:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 16:27:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:27:18 --> Final output sent to browser
DEBUG - 2023-08-19 16:27:18 --> Total execution time: 0.0314
INFO - 2023-08-19 16:27:38 --> Config Class Initialized
INFO - 2023-08-19 16:27:38 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:27:38 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:27:38 --> Utf8 Class Initialized
INFO - 2023-08-19 16:27:38 --> URI Class Initialized
DEBUG - 2023-08-19 16:27:38 --> No URI present. Default controller set.
INFO - 2023-08-19 16:27:38 --> Router Class Initialized
INFO - 2023-08-19 16:27:38 --> Output Class Initialized
INFO - 2023-08-19 16:27:38 --> Security Class Initialized
DEBUG - 2023-08-19 16:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:27:38 --> Input Class Initialized
INFO - 2023-08-19 16:27:38 --> Language Class Initialized
INFO - 2023-08-19 16:27:38 --> Language Class Initialized
INFO - 2023-08-19 16:27:38 --> Config Class Initialized
INFO - 2023-08-19 16:27:38 --> Loader Class Initialized
INFO - 2023-08-19 16:27:38 --> Helper loaded: url_helper
INFO - 2023-08-19 16:27:38 --> Helper loaded: file_helper
INFO - 2023-08-19 16:27:38 --> Helper loaded: form_helper
INFO - 2023-08-19 16:27:38 --> Helper loaded: my_helper
INFO - 2023-08-19 16:27:38 --> Database Driver Class Initialized
INFO - 2023-08-19 16:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:27:38 --> Controller Class Initialized
DEBUG - 2023-08-19 16:27:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 16:27:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:27:38 --> Final output sent to browser
DEBUG - 2023-08-19 16:27:38 --> Total execution time: 0.0362
INFO - 2023-08-19 16:27:40 --> Config Class Initialized
INFO - 2023-08-19 16:27:40 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:27:40 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:27:40 --> Utf8 Class Initialized
INFO - 2023-08-19 16:27:40 --> URI Class Initialized
INFO - 2023-08-19 16:27:40 --> Router Class Initialized
INFO - 2023-08-19 16:27:40 --> Output Class Initialized
INFO - 2023-08-19 16:27:40 --> Security Class Initialized
DEBUG - 2023-08-19 16:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:27:40 --> Input Class Initialized
INFO - 2023-08-19 16:27:40 --> Language Class Initialized
INFO - 2023-08-19 16:27:40 --> Language Class Initialized
INFO - 2023-08-19 16:27:40 --> Config Class Initialized
INFO - 2023-08-19 16:27:40 --> Loader Class Initialized
INFO - 2023-08-19 16:27:40 --> Helper loaded: url_helper
INFO - 2023-08-19 16:27:40 --> Helper loaded: file_helper
INFO - 2023-08-19 16:27:40 --> Helper loaded: form_helper
INFO - 2023-08-19 16:27:40 --> Helper loaded: my_helper
INFO - 2023-08-19 16:27:40 --> Database Driver Class Initialized
INFO - 2023-08-19 16:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:27:40 --> Controller Class Initialized
DEBUG - 2023-08-19 16:27:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 16:27:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:27:40 --> Final output sent to browser
DEBUG - 2023-08-19 16:27:40 --> Total execution time: 0.0270
INFO - 2023-08-19 16:27:56 --> Config Class Initialized
INFO - 2023-08-19 16:27:56 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:27:56 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:27:56 --> Utf8 Class Initialized
INFO - 2023-08-19 16:27:56 --> URI Class Initialized
DEBUG - 2023-08-19 16:27:56 --> No URI present. Default controller set.
INFO - 2023-08-19 16:27:56 --> Router Class Initialized
INFO - 2023-08-19 16:27:56 --> Output Class Initialized
INFO - 2023-08-19 16:27:56 --> Security Class Initialized
DEBUG - 2023-08-19 16:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:27:56 --> Input Class Initialized
INFO - 2023-08-19 16:27:56 --> Language Class Initialized
INFO - 2023-08-19 16:27:56 --> Language Class Initialized
INFO - 2023-08-19 16:27:56 --> Config Class Initialized
INFO - 2023-08-19 16:27:56 --> Loader Class Initialized
INFO - 2023-08-19 16:27:56 --> Helper loaded: url_helper
INFO - 2023-08-19 16:27:56 --> Helper loaded: file_helper
INFO - 2023-08-19 16:27:56 --> Helper loaded: form_helper
INFO - 2023-08-19 16:27:56 --> Helper loaded: my_helper
INFO - 2023-08-19 16:27:56 --> Database Driver Class Initialized
INFO - 2023-08-19 16:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:27:56 --> Controller Class Initialized
DEBUG - 2023-08-19 16:27:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 16:27:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:27:56 --> Final output sent to browser
DEBUG - 2023-08-19 16:27:56 --> Total execution time: 0.0285
INFO - 2023-08-19 16:28:21 --> Config Class Initialized
INFO - 2023-08-19 16:28:21 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:28:21 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:28:21 --> Utf8 Class Initialized
INFO - 2023-08-19 16:28:21 --> URI Class Initialized
DEBUG - 2023-08-19 16:28:21 --> No URI present. Default controller set.
INFO - 2023-08-19 16:28:21 --> Router Class Initialized
INFO - 2023-08-19 16:28:21 --> Output Class Initialized
INFO - 2023-08-19 16:28:21 --> Security Class Initialized
DEBUG - 2023-08-19 16:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:28:21 --> Input Class Initialized
INFO - 2023-08-19 16:28:21 --> Language Class Initialized
INFO - 2023-08-19 16:28:21 --> Language Class Initialized
INFO - 2023-08-19 16:28:21 --> Config Class Initialized
INFO - 2023-08-19 16:28:21 --> Loader Class Initialized
INFO - 2023-08-19 16:28:21 --> Helper loaded: url_helper
INFO - 2023-08-19 16:28:21 --> Helper loaded: file_helper
INFO - 2023-08-19 16:28:21 --> Helper loaded: form_helper
INFO - 2023-08-19 16:28:21 --> Helper loaded: my_helper
INFO - 2023-08-19 16:28:21 --> Database Driver Class Initialized
INFO - 2023-08-19 16:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:28:21 --> Controller Class Initialized
DEBUG - 2023-08-19 16:28:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 16:28:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:28:21 --> Final output sent to browser
DEBUG - 2023-08-19 16:28:21 --> Total execution time: 0.0488
INFO - 2023-08-19 16:29:19 --> Config Class Initialized
INFO - 2023-08-19 16:29:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:29:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:29:19 --> Utf8 Class Initialized
INFO - 2023-08-19 16:29:19 --> URI Class Initialized
INFO - 2023-08-19 16:29:19 --> Router Class Initialized
INFO - 2023-08-19 16:29:19 --> Output Class Initialized
INFO - 2023-08-19 16:29:19 --> Security Class Initialized
DEBUG - 2023-08-19 16:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:29:19 --> Input Class Initialized
INFO - 2023-08-19 16:29:19 --> Language Class Initialized
INFO - 2023-08-19 16:29:19 --> Language Class Initialized
INFO - 2023-08-19 16:29:19 --> Config Class Initialized
INFO - 2023-08-19 16:29:19 --> Loader Class Initialized
INFO - 2023-08-19 16:29:19 --> Helper loaded: url_helper
INFO - 2023-08-19 16:29:19 --> Helper loaded: file_helper
INFO - 2023-08-19 16:29:19 --> Helper loaded: form_helper
INFO - 2023-08-19 16:29:19 --> Helper loaded: my_helper
INFO - 2023-08-19 16:29:19 --> Database Driver Class Initialized
INFO - 2023-08-19 16:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:29:19 --> Controller Class Initialized
DEBUG - 2023-08-19 16:29:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2023-08-19 16:29:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:29:19 --> Final output sent to browser
DEBUG - 2023-08-19 16:29:19 --> Total execution time: 0.1012
INFO - 2023-08-19 16:29:20 --> Config Class Initialized
INFO - 2023-08-19 16:29:20 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:29:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:29:20 --> Utf8 Class Initialized
INFO - 2023-08-19 16:29:20 --> URI Class Initialized
INFO - 2023-08-19 16:29:20 --> Router Class Initialized
INFO - 2023-08-19 16:29:20 --> Output Class Initialized
INFO - 2023-08-19 16:29:20 --> Security Class Initialized
DEBUG - 2023-08-19 16:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:29:20 --> Input Class Initialized
INFO - 2023-08-19 16:29:20 --> Language Class Initialized
INFO - 2023-08-19 16:29:20 --> Language Class Initialized
INFO - 2023-08-19 16:29:20 --> Config Class Initialized
INFO - 2023-08-19 16:29:20 --> Loader Class Initialized
INFO - 2023-08-19 16:29:20 --> Helper loaded: url_helper
INFO - 2023-08-19 16:29:20 --> Helper loaded: file_helper
INFO - 2023-08-19 16:29:20 --> Helper loaded: form_helper
INFO - 2023-08-19 16:29:20 --> Helper loaded: my_helper
INFO - 2023-08-19 16:29:20 --> Database Driver Class Initialized
INFO - 2023-08-19 16:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:29:20 --> Controller Class Initialized
DEBUG - 2023-08-19 16:29:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2023-08-19 16:29:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:29:20 --> Final output sent to browser
DEBUG - 2023-08-19 16:29:20 --> Total execution time: 0.0340
INFO - 2023-08-19 16:29:20 --> Config Class Initialized
INFO - 2023-08-19 16:29:20 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:29:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:29:20 --> Utf8 Class Initialized
INFO - 2023-08-19 16:29:20 --> URI Class Initialized
INFO - 2023-08-19 16:29:20 --> Router Class Initialized
INFO - 2023-08-19 16:29:20 --> Output Class Initialized
INFO - 2023-08-19 16:29:20 --> Security Class Initialized
DEBUG - 2023-08-19 16:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:29:20 --> Input Class Initialized
INFO - 2023-08-19 16:29:20 --> Language Class Initialized
ERROR - 2023-08-19 16:29:20 --> 404 Page Not Found: /index
INFO - 2023-08-19 16:29:20 --> Config Class Initialized
INFO - 2023-08-19 16:29:20 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:29:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:29:20 --> Utf8 Class Initialized
INFO - 2023-08-19 16:29:20 --> URI Class Initialized
INFO - 2023-08-19 16:29:20 --> Router Class Initialized
INFO - 2023-08-19 16:29:20 --> Output Class Initialized
INFO - 2023-08-19 16:29:20 --> Security Class Initialized
DEBUG - 2023-08-19 16:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:29:20 --> Input Class Initialized
INFO - 2023-08-19 16:29:20 --> Language Class Initialized
INFO - 2023-08-19 16:29:20 --> Language Class Initialized
INFO - 2023-08-19 16:29:20 --> Config Class Initialized
INFO - 2023-08-19 16:29:20 --> Loader Class Initialized
INFO - 2023-08-19 16:29:20 --> Helper loaded: url_helper
INFO - 2023-08-19 16:29:20 --> Helper loaded: file_helper
INFO - 2023-08-19 16:29:20 --> Helper loaded: form_helper
INFO - 2023-08-19 16:29:20 --> Helper loaded: my_helper
INFO - 2023-08-19 16:29:20 --> Database Driver Class Initialized
INFO - 2023-08-19 16:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:29:20 --> Controller Class Initialized
INFO - 2023-08-19 16:29:22 --> Config Class Initialized
INFO - 2023-08-19 16:29:22 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:29:22 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:29:22 --> Utf8 Class Initialized
INFO - 2023-08-19 16:29:22 --> URI Class Initialized
INFO - 2023-08-19 16:29:22 --> Router Class Initialized
INFO - 2023-08-19 16:29:22 --> Output Class Initialized
INFO - 2023-08-19 16:29:22 --> Security Class Initialized
DEBUG - 2023-08-19 16:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:29:22 --> Input Class Initialized
INFO - 2023-08-19 16:29:22 --> Language Class Initialized
INFO - 2023-08-19 16:29:22 --> Language Class Initialized
INFO - 2023-08-19 16:29:22 --> Config Class Initialized
INFO - 2023-08-19 16:29:22 --> Loader Class Initialized
INFO - 2023-08-19 16:29:22 --> Helper loaded: url_helper
INFO - 2023-08-19 16:29:22 --> Helper loaded: file_helper
INFO - 2023-08-19 16:29:22 --> Helper loaded: form_helper
INFO - 2023-08-19 16:29:22 --> Helper loaded: my_helper
INFO - 2023-08-19 16:29:22 --> Database Driver Class Initialized
INFO - 2023-08-19 16:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:29:22 --> Controller Class Initialized
INFO - 2023-08-19 16:29:22 --> Final output sent to browser
DEBUG - 2023-08-19 16:29:22 --> Total execution time: 0.0343
INFO - 2023-08-19 16:29:27 --> Config Class Initialized
INFO - 2023-08-19 16:29:27 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:29:27 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:29:27 --> Utf8 Class Initialized
INFO - 2023-08-19 16:29:27 --> URI Class Initialized
INFO - 2023-08-19 16:29:27 --> Router Class Initialized
INFO - 2023-08-19 16:29:27 --> Output Class Initialized
INFO - 2023-08-19 16:29:27 --> Security Class Initialized
DEBUG - 2023-08-19 16:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:29:27 --> Input Class Initialized
INFO - 2023-08-19 16:29:27 --> Language Class Initialized
INFO - 2023-08-19 16:29:27 --> Language Class Initialized
INFO - 2023-08-19 16:29:27 --> Config Class Initialized
INFO - 2023-08-19 16:29:27 --> Loader Class Initialized
INFO - 2023-08-19 16:29:27 --> Helper loaded: url_helper
INFO - 2023-08-19 16:29:27 --> Helper loaded: file_helper
INFO - 2023-08-19 16:29:27 --> Helper loaded: form_helper
INFO - 2023-08-19 16:29:27 --> Helper loaded: my_helper
INFO - 2023-08-19 16:29:27 --> Database Driver Class Initialized
INFO - 2023-08-19 16:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:29:27 --> Controller Class Initialized
DEBUG - 2023-08-19 16:29:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-08-19 16:29:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:29:27 --> Final output sent to browser
DEBUG - 2023-08-19 16:29:27 --> Total execution time: 0.0282
INFO - 2023-08-19 16:29:27 --> Config Class Initialized
INFO - 2023-08-19 16:29:27 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:29:27 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:29:27 --> Utf8 Class Initialized
INFO - 2023-08-19 16:29:27 --> URI Class Initialized
INFO - 2023-08-19 16:29:27 --> Router Class Initialized
INFO - 2023-08-19 16:29:27 --> Output Class Initialized
INFO - 2023-08-19 16:29:27 --> Security Class Initialized
DEBUG - 2023-08-19 16:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:29:27 --> Input Class Initialized
INFO - 2023-08-19 16:29:27 --> Language Class Initialized
ERROR - 2023-08-19 16:29:27 --> 404 Page Not Found: /index
INFO - 2023-08-19 16:29:27 --> Config Class Initialized
INFO - 2023-08-19 16:29:27 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:29:27 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:29:27 --> Utf8 Class Initialized
INFO - 2023-08-19 16:29:27 --> URI Class Initialized
INFO - 2023-08-19 16:29:27 --> Router Class Initialized
INFO - 2023-08-19 16:29:27 --> Output Class Initialized
INFO - 2023-08-19 16:29:27 --> Security Class Initialized
DEBUG - 2023-08-19 16:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:29:27 --> Input Class Initialized
INFO - 2023-08-19 16:29:27 --> Language Class Initialized
INFO - 2023-08-19 16:29:27 --> Language Class Initialized
INFO - 2023-08-19 16:29:27 --> Config Class Initialized
INFO - 2023-08-19 16:29:27 --> Loader Class Initialized
INFO - 2023-08-19 16:29:27 --> Helper loaded: url_helper
INFO - 2023-08-19 16:29:27 --> Helper loaded: file_helper
INFO - 2023-08-19 16:29:27 --> Helper loaded: form_helper
INFO - 2023-08-19 16:29:27 --> Helper loaded: my_helper
INFO - 2023-08-19 16:29:27 --> Database Driver Class Initialized
INFO - 2023-08-19 16:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:29:27 --> Controller Class Initialized
INFO - 2023-08-19 16:29:28 --> Config Class Initialized
INFO - 2023-08-19 16:29:28 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:29:28 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:29:28 --> Utf8 Class Initialized
INFO - 2023-08-19 16:29:28 --> URI Class Initialized
INFO - 2023-08-19 16:29:28 --> Router Class Initialized
INFO - 2023-08-19 16:29:28 --> Output Class Initialized
INFO - 2023-08-19 16:29:28 --> Security Class Initialized
DEBUG - 2023-08-19 16:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:29:28 --> Input Class Initialized
INFO - 2023-08-19 16:29:28 --> Language Class Initialized
INFO - 2023-08-19 16:29:28 --> Language Class Initialized
INFO - 2023-08-19 16:29:28 --> Config Class Initialized
INFO - 2023-08-19 16:29:28 --> Loader Class Initialized
INFO - 2023-08-19 16:29:28 --> Helper loaded: url_helper
INFO - 2023-08-19 16:29:28 --> Helper loaded: file_helper
INFO - 2023-08-19 16:29:28 --> Helper loaded: form_helper
INFO - 2023-08-19 16:29:28 --> Helper loaded: my_helper
INFO - 2023-08-19 16:29:28 --> Database Driver Class Initialized
INFO - 2023-08-19 16:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:29:28 --> Controller Class Initialized
INFO - 2023-08-19 16:29:29 --> Config Class Initialized
INFO - 2023-08-19 16:29:29 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:29:29 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:29:29 --> Utf8 Class Initialized
INFO - 2023-08-19 16:29:29 --> URI Class Initialized
INFO - 2023-08-19 16:29:29 --> Router Class Initialized
INFO - 2023-08-19 16:29:29 --> Output Class Initialized
INFO - 2023-08-19 16:29:29 --> Security Class Initialized
DEBUG - 2023-08-19 16:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:29:29 --> Input Class Initialized
INFO - 2023-08-19 16:29:29 --> Language Class Initialized
INFO - 2023-08-19 16:29:29 --> Language Class Initialized
INFO - 2023-08-19 16:29:29 --> Config Class Initialized
INFO - 2023-08-19 16:29:29 --> Loader Class Initialized
INFO - 2023-08-19 16:29:29 --> Helper loaded: url_helper
INFO - 2023-08-19 16:29:29 --> Helper loaded: file_helper
INFO - 2023-08-19 16:29:29 --> Helper loaded: form_helper
INFO - 2023-08-19 16:29:29 --> Helper loaded: my_helper
INFO - 2023-08-19 16:29:29 --> Database Driver Class Initialized
INFO - 2023-08-19 16:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:29:29 --> Controller Class Initialized
DEBUG - 2023-08-19 16:29:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2023-08-19 16:29:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:29:29 --> Final output sent to browser
DEBUG - 2023-08-19 16:29:29 --> Total execution time: 0.0538
INFO - 2023-08-19 16:29:31 --> Config Class Initialized
INFO - 2023-08-19 16:29:31 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:29:31 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:29:31 --> Utf8 Class Initialized
INFO - 2023-08-19 16:29:31 --> URI Class Initialized
DEBUG - 2023-08-19 16:29:31 --> No URI present. Default controller set.
INFO - 2023-08-19 16:29:31 --> Router Class Initialized
INFO - 2023-08-19 16:29:31 --> Output Class Initialized
INFO - 2023-08-19 16:29:31 --> Security Class Initialized
DEBUG - 2023-08-19 16:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:29:31 --> Input Class Initialized
INFO - 2023-08-19 16:29:31 --> Language Class Initialized
INFO - 2023-08-19 16:29:31 --> Language Class Initialized
INFO - 2023-08-19 16:29:31 --> Config Class Initialized
INFO - 2023-08-19 16:29:31 --> Loader Class Initialized
INFO - 2023-08-19 16:29:31 --> Helper loaded: url_helper
INFO - 2023-08-19 16:29:31 --> Helper loaded: file_helper
INFO - 2023-08-19 16:29:31 --> Helper loaded: form_helper
INFO - 2023-08-19 16:29:31 --> Helper loaded: my_helper
INFO - 2023-08-19 16:29:31 --> Database Driver Class Initialized
INFO - 2023-08-19 16:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:29:32 --> Controller Class Initialized
DEBUG - 2023-08-19 16:29:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 16:29:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:29:32 --> Final output sent to browser
DEBUG - 2023-08-19 16:29:32 --> Total execution time: 0.0628
INFO - 2023-08-19 16:29:35 --> Config Class Initialized
INFO - 2023-08-19 16:29:35 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:29:35 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:29:35 --> Utf8 Class Initialized
INFO - 2023-08-19 16:29:35 --> URI Class Initialized
INFO - 2023-08-19 16:29:35 --> Router Class Initialized
INFO - 2023-08-19 16:29:35 --> Output Class Initialized
INFO - 2023-08-19 16:29:35 --> Security Class Initialized
DEBUG - 2023-08-19 16:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:29:35 --> Input Class Initialized
INFO - 2023-08-19 16:29:35 --> Language Class Initialized
INFO - 2023-08-19 16:29:35 --> Language Class Initialized
INFO - 2023-08-19 16:29:35 --> Config Class Initialized
INFO - 2023-08-19 16:29:35 --> Loader Class Initialized
INFO - 2023-08-19 16:29:35 --> Helper loaded: url_helper
INFO - 2023-08-19 16:29:35 --> Helper loaded: file_helper
INFO - 2023-08-19 16:29:35 --> Helper loaded: form_helper
INFO - 2023-08-19 16:29:35 --> Helper loaded: my_helper
INFO - 2023-08-19 16:29:35 --> Database Driver Class Initialized
INFO - 2023-08-19 16:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:29:35 --> Controller Class Initialized
DEBUG - 2023-08-19 16:29:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 16:29:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:29:35 --> Final output sent to browser
DEBUG - 2023-08-19 16:29:35 --> Total execution time: 0.0899
INFO - 2023-08-19 16:29:38 --> Config Class Initialized
INFO - 2023-08-19 16:29:38 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:29:38 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:29:38 --> Utf8 Class Initialized
INFO - 2023-08-19 16:29:38 --> URI Class Initialized
INFO - 2023-08-19 16:29:38 --> Router Class Initialized
INFO - 2023-08-19 16:29:38 --> Output Class Initialized
INFO - 2023-08-19 16:29:38 --> Security Class Initialized
DEBUG - 2023-08-19 16:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:29:38 --> Input Class Initialized
INFO - 2023-08-19 16:29:38 --> Language Class Initialized
INFO - 2023-08-19 16:29:38 --> Language Class Initialized
INFO - 2023-08-19 16:29:38 --> Config Class Initialized
INFO - 2023-08-19 16:29:38 --> Loader Class Initialized
INFO - 2023-08-19 16:29:38 --> Helper loaded: url_helper
INFO - 2023-08-19 16:29:38 --> Helper loaded: file_helper
INFO - 2023-08-19 16:29:38 --> Helper loaded: form_helper
INFO - 2023-08-19 16:29:38 --> Helper loaded: my_helper
INFO - 2023-08-19 16:29:38 --> Database Driver Class Initialized
INFO - 2023-08-19 16:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:29:38 --> Controller Class Initialized
DEBUG - 2023-08-19 16:29:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 16:29:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:29:38 --> Final output sent to browser
DEBUG - 2023-08-19 16:29:38 --> Total execution time: 0.0305
INFO - 2023-08-19 16:29:40 --> Config Class Initialized
INFO - 2023-08-19 16:29:40 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:29:40 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:29:40 --> Utf8 Class Initialized
INFO - 2023-08-19 16:29:40 --> URI Class Initialized
INFO - 2023-08-19 16:29:40 --> Router Class Initialized
INFO - 2023-08-19 16:29:40 --> Output Class Initialized
INFO - 2023-08-19 16:29:40 --> Security Class Initialized
DEBUG - 2023-08-19 16:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:29:40 --> Input Class Initialized
INFO - 2023-08-19 16:29:40 --> Language Class Initialized
INFO - 2023-08-19 16:29:40 --> Language Class Initialized
INFO - 2023-08-19 16:29:40 --> Config Class Initialized
INFO - 2023-08-19 16:29:40 --> Loader Class Initialized
INFO - 2023-08-19 16:29:40 --> Helper loaded: url_helper
INFO - 2023-08-19 16:29:40 --> Helper loaded: file_helper
INFO - 2023-08-19 16:29:40 --> Helper loaded: form_helper
INFO - 2023-08-19 16:29:40 --> Helper loaded: my_helper
INFO - 2023-08-19 16:29:40 --> Database Driver Class Initialized
INFO - 2023-08-19 16:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:29:40 --> Controller Class Initialized
INFO - 2023-08-19 16:29:40 --> Config Class Initialized
INFO - 2023-08-19 16:29:40 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:29:40 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:29:40 --> Utf8 Class Initialized
INFO - 2023-08-19 16:29:40 --> URI Class Initialized
INFO - 2023-08-19 16:29:40 --> Router Class Initialized
INFO - 2023-08-19 16:29:40 --> Output Class Initialized
INFO - 2023-08-19 16:29:40 --> Security Class Initialized
DEBUG - 2023-08-19 16:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:29:40 --> Input Class Initialized
INFO - 2023-08-19 16:29:40 --> Language Class Initialized
INFO - 2023-08-19 16:29:40 --> Language Class Initialized
INFO - 2023-08-19 16:29:40 --> Config Class Initialized
INFO - 2023-08-19 16:29:40 --> Loader Class Initialized
INFO - 2023-08-19 16:29:40 --> Helper loaded: url_helper
INFO - 2023-08-19 16:29:40 --> Helper loaded: file_helper
INFO - 2023-08-19 16:29:40 --> Helper loaded: form_helper
INFO - 2023-08-19 16:29:40 --> Helper loaded: my_helper
INFO - 2023-08-19 16:29:40 --> Database Driver Class Initialized
INFO - 2023-08-19 16:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:29:40 --> Controller Class Initialized
DEBUG - 2023-08-19 16:29:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-08-19 16:29:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:29:40 --> Final output sent to browser
DEBUG - 2023-08-19 16:29:40 --> Total execution time: 0.0738
INFO - 2023-08-19 16:29:40 --> Config Class Initialized
INFO - 2023-08-19 16:29:40 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:29:40 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:29:40 --> Utf8 Class Initialized
INFO - 2023-08-19 16:29:40 --> URI Class Initialized
INFO - 2023-08-19 16:29:40 --> Router Class Initialized
INFO - 2023-08-19 16:29:40 --> Output Class Initialized
INFO - 2023-08-19 16:29:40 --> Security Class Initialized
DEBUG - 2023-08-19 16:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:29:40 --> Input Class Initialized
INFO - 2023-08-19 16:29:40 --> Language Class Initialized
ERROR - 2023-08-19 16:29:40 --> 404 Page Not Found: /index
INFO - 2023-08-19 16:29:40 --> Config Class Initialized
INFO - 2023-08-19 16:29:40 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:29:40 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:29:40 --> Utf8 Class Initialized
INFO - 2023-08-19 16:29:40 --> URI Class Initialized
INFO - 2023-08-19 16:29:40 --> Router Class Initialized
INFO - 2023-08-19 16:29:40 --> Output Class Initialized
INFO - 2023-08-19 16:29:40 --> Security Class Initialized
DEBUG - 2023-08-19 16:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:29:40 --> Input Class Initialized
INFO - 2023-08-19 16:29:40 --> Language Class Initialized
INFO - 2023-08-19 16:29:40 --> Language Class Initialized
INFO - 2023-08-19 16:29:40 --> Config Class Initialized
INFO - 2023-08-19 16:29:40 --> Loader Class Initialized
INFO - 2023-08-19 16:29:40 --> Helper loaded: url_helper
INFO - 2023-08-19 16:29:40 --> Helper loaded: file_helper
INFO - 2023-08-19 16:29:40 --> Helper loaded: form_helper
INFO - 2023-08-19 16:29:40 --> Helper loaded: my_helper
INFO - 2023-08-19 16:29:40 --> Database Driver Class Initialized
INFO - 2023-08-19 16:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:29:40 --> Controller Class Initialized
INFO - 2023-08-19 16:29:44 --> Config Class Initialized
INFO - 2023-08-19 16:29:44 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:29:44 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:29:44 --> Utf8 Class Initialized
INFO - 2023-08-19 16:29:44 --> URI Class Initialized
INFO - 2023-08-19 16:29:44 --> Router Class Initialized
INFO - 2023-08-19 16:29:44 --> Output Class Initialized
INFO - 2023-08-19 16:29:44 --> Security Class Initialized
DEBUG - 2023-08-19 16:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:29:44 --> Input Class Initialized
INFO - 2023-08-19 16:29:44 --> Language Class Initialized
INFO - 2023-08-19 16:29:44 --> Language Class Initialized
INFO - 2023-08-19 16:29:44 --> Config Class Initialized
INFO - 2023-08-19 16:29:44 --> Loader Class Initialized
INFO - 2023-08-19 16:29:44 --> Helper loaded: url_helper
INFO - 2023-08-19 16:29:44 --> Helper loaded: file_helper
INFO - 2023-08-19 16:29:44 --> Helper loaded: form_helper
INFO - 2023-08-19 16:29:44 --> Helper loaded: my_helper
INFO - 2023-08-19 16:29:44 --> Database Driver Class Initialized
INFO - 2023-08-19 16:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:29:44 --> Controller Class Initialized
INFO - 2023-08-19 16:29:49 --> Config Class Initialized
INFO - 2023-08-19 16:29:49 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:29:49 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:29:49 --> Utf8 Class Initialized
INFO - 2023-08-19 16:29:49 --> URI Class Initialized
INFO - 2023-08-19 16:29:49 --> Router Class Initialized
INFO - 2023-08-19 16:29:49 --> Output Class Initialized
INFO - 2023-08-19 16:29:49 --> Security Class Initialized
DEBUG - 2023-08-19 16:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:29:49 --> Input Class Initialized
INFO - 2023-08-19 16:29:49 --> Language Class Initialized
INFO - 2023-08-19 16:29:49 --> Language Class Initialized
INFO - 2023-08-19 16:29:49 --> Config Class Initialized
INFO - 2023-08-19 16:29:49 --> Loader Class Initialized
INFO - 2023-08-19 16:29:49 --> Helper loaded: url_helper
INFO - 2023-08-19 16:29:49 --> Helper loaded: file_helper
INFO - 2023-08-19 16:29:49 --> Helper loaded: form_helper
INFO - 2023-08-19 16:29:49 --> Helper loaded: my_helper
INFO - 2023-08-19 16:29:49 --> Database Driver Class Initialized
INFO - 2023-08-19 16:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:29:49 --> Controller Class Initialized
INFO - 2023-08-19 16:30:18 --> Config Class Initialized
INFO - 2023-08-19 16:30:18 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:30:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:30:18 --> Utf8 Class Initialized
INFO - 2023-08-19 16:30:18 --> URI Class Initialized
INFO - 2023-08-19 16:30:18 --> Router Class Initialized
INFO - 2023-08-19 16:30:18 --> Output Class Initialized
INFO - 2023-08-19 16:30:18 --> Security Class Initialized
DEBUG - 2023-08-19 16:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:30:18 --> Input Class Initialized
INFO - 2023-08-19 16:30:18 --> Language Class Initialized
INFO - 2023-08-19 16:30:18 --> Language Class Initialized
INFO - 2023-08-19 16:30:18 --> Config Class Initialized
INFO - 2023-08-19 16:30:18 --> Loader Class Initialized
INFO - 2023-08-19 16:30:18 --> Helper loaded: url_helper
INFO - 2023-08-19 16:30:18 --> Helper loaded: file_helper
INFO - 2023-08-19 16:30:18 --> Helper loaded: form_helper
INFO - 2023-08-19 16:30:18 --> Helper loaded: my_helper
INFO - 2023-08-19 16:30:18 --> Database Driver Class Initialized
INFO - 2023-08-19 16:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:30:18 --> Controller Class Initialized
DEBUG - 2023-08-19 16:30:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2023-08-19 16:30:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:30:18 --> Final output sent to browser
DEBUG - 2023-08-19 16:30:18 --> Total execution time: 0.0405
INFO - 2023-08-19 16:30:18 --> Config Class Initialized
INFO - 2023-08-19 16:30:18 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:30:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:30:18 --> Utf8 Class Initialized
INFO - 2023-08-19 16:30:18 --> URI Class Initialized
INFO - 2023-08-19 16:30:18 --> Router Class Initialized
INFO - 2023-08-19 16:30:18 --> Output Class Initialized
INFO - 2023-08-19 16:30:18 --> Security Class Initialized
DEBUG - 2023-08-19 16:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:30:18 --> Input Class Initialized
INFO - 2023-08-19 16:30:18 --> Language Class Initialized
ERROR - 2023-08-19 16:30:18 --> 404 Page Not Found: /index
INFO - 2023-08-19 16:30:18 --> Config Class Initialized
INFO - 2023-08-19 16:30:18 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:30:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:30:18 --> Utf8 Class Initialized
INFO - 2023-08-19 16:30:18 --> URI Class Initialized
INFO - 2023-08-19 16:30:18 --> Router Class Initialized
INFO - 2023-08-19 16:30:18 --> Output Class Initialized
INFO - 2023-08-19 16:30:18 --> Security Class Initialized
DEBUG - 2023-08-19 16:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:30:18 --> Input Class Initialized
INFO - 2023-08-19 16:30:18 --> Language Class Initialized
INFO - 2023-08-19 16:30:18 --> Language Class Initialized
INFO - 2023-08-19 16:30:18 --> Config Class Initialized
INFO - 2023-08-19 16:30:18 --> Loader Class Initialized
INFO - 2023-08-19 16:30:18 --> Helper loaded: url_helper
INFO - 2023-08-19 16:30:18 --> Helper loaded: file_helper
INFO - 2023-08-19 16:30:18 --> Helper loaded: form_helper
INFO - 2023-08-19 16:30:18 --> Helper loaded: my_helper
INFO - 2023-08-19 16:30:18 --> Database Driver Class Initialized
INFO - 2023-08-19 16:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:30:18 --> Controller Class Initialized
INFO - 2023-08-19 16:30:30 --> Config Class Initialized
INFO - 2023-08-19 16:30:30 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:30:30 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:30:30 --> Utf8 Class Initialized
INFO - 2023-08-19 16:30:30 --> URI Class Initialized
INFO - 2023-08-19 16:30:30 --> Router Class Initialized
INFO - 2023-08-19 16:30:30 --> Output Class Initialized
INFO - 2023-08-19 16:30:30 --> Security Class Initialized
DEBUG - 2023-08-19 16:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:30:30 --> Input Class Initialized
INFO - 2023-08-19 16:30:30 --> Language Class Initialized
INFO - 2023-08-19 16:30:30 --> Language Class Initialized
INFO - 2023-08-19 16:30:30 --> Config Class Initialized
INFO - 2023-08-19 16:30:30 --> Loader Class Initialized
INFO - 2023-08-19 16:30:30 --> Helper loaded: url_helper
INFO - 2023-08-19 16:30:30 --> Helper loaded: file_helper
INFO - 2023-08-19 16:30:30 --> Helper loaded: form_helper
INFO - 2023-08-19 16:30:30 --> Helper loaded: my_helper
INFO - 2023-08-19 16:30:30 --> Database Driver Class Initialized
INFO - 2023-08-19 16:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:30:30 --> Controller Class Initialized
INFO - 2023-08-19 16:30:30 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:30:30 --> Config Class Initialized
INFO - 2023-08-19 16:30:30 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:30:30 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:30:30 --> Utf8 Class Initialized
INFO - 2023-08-19 16:30:30 --> URI Class Initialized
INFO - 2023-08-19 16:30:30 --> Router Class Initialized
INFO - 2023-08-19 16:30:30 --> Output Class Initialized
INFO - 2023-08-19 16:30:30 --> Security Class Initialized
DEBUG - 2023-08-19 16:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:30:30 --> Input Class Initialized
INFO - 2023-08-19 16:30:30 --> Language Class Initialized
INFO - 2023-08-19 16:30:30 --> Language Class Initialized
INFO - 2023-08-19 16:30:30 --> Config Class Initialized
INFO - 2023-08-19 16:30:30 --> Loader Class Initialized
INFO - 2023-08-19 16:30:30 --> Helper loaded: url_helper
INFO - 2023-08-19 16:30:30 --> Helper loaded: file_helper
INFO - 2023-08-19 16:30:30 --> Helper loaded: form_helper
INFO - 2023-08-19 16:30:30 --> Helper loaded: my_helper
INFO - 2023-08-19 16:30:30 --> Database Driver Class Initialized
INFO - 2023-08-19 16:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:30:30 --> Controller Class Initialized
INFO - 2023-08-19 16:30:30 --> Config Class Initialized
INFO - 2023-08-19 16:30:30 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:30:30 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:30:30 --> Utf8 Class Initialized
INFO - 2023-08-19 16:30:30 --> URI Class Initialized
INFO - 2023-08-19 16:30:30 --> Router Class Initialized
INFO - 2023-08-19 16:30:30 --> Output Class Initialized
INFO - 2023-08-19 16:30:30 --> Security Class Initialized
DEBUG - 2023-08-19 16:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:30:30 --> Input Class Initialized
INFO - 2023-08-19 16:30:30 --> Language Class Initialized
INFO - 2023-08-19 16:30:30 --> Language Class Initialized
INFO - 2023-08-19 16:30:30 --> Config Class Initialized
INFO - 2023-08-19 16:30:30 --> Loader Class Initialized
INFO - 2023-08-19 16:30:30 --> Helper loaded: url_helper
INFO - 2023-08-19 16:30:30 --> Helper loaded: file_helper
INFO - 2023-08-19 16:30:30 --> Helper loaded: form_helper
INFO - 2023-08-19 16:30:30 --> Helper loaded: my_helper
INFO - 2023-08-19 16:30:30 --> Database Driver Class Initialized
INFO - 2023-08-19 16:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:30:30 --> Controller Class Initialized
DEBUG - 2023-08-19 16:30:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-08-19 16:30:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:30:30 --> Final output sent to browser
DEBUG - 2023-08-19 16:30:30 --> Total execution time: 0.0400
INFO - 2023-08-19 16:30:37 --> Config Class Initialized
INFO - 2023-08-19 16:30:37 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:30:37 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:30:37 --> Utf8 Class Initialized
INFO - 2023-08-19 16:30:37 --> URI Class Initialized
INFO - 2023-08-19 16:30:37 --> Router Class Initialized
INFO - 2023-08-19 16:30:37 --> Output Class Initialized
INFO - 2023-08-19 16:30:37 --> Security Class Initialized
DEBUG - 2023-08-19 16:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:30:37 --> Input Class Initialized
INFO - 2023-08-19 16:30:37 --> Language Class Initialized
INFO - 2023-08-19 16:30:37 --> Language Class Initialized
INFO - 2023-08-19 16:30:37 --> Config Class Initialized
INFO - 2023-08-19 16:30:37 --> Loader Class Initialized
INFO - 2023-08-19 16:30:37 --> Helper loaded: url_helper
INFO - 2023-08-19 16:30:37 --> Helper loaded: file_helper
INFO - 2023-08-19 16:30:37 --> Helper loaded: form_helper
INFO - 2023-08-19 16:30:37 --> Helper loaded: my_helper
INFO - 2023-08-19 16:30:37 --> Database Driver Class Initialized
INFO - 2023-08-19 16:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:30:37 --> Controller Class Initialized
INFO - 2023-08-19 16:30:37 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:30:37 --> Final output sent to browser
DEBUG - 2023-08-19 16:30:37 --> Total execution time: 0.0591
INFO - 2023-08-19 16:30:37 --> Config Class Initialized
INFO - 2023-08-19 16:30:37 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:30:37 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:30:37 --> Utf8 Class Initialized
INFO - 2023-08-19 16:30:37 --> URI Class Initialized
INFO - 2023-08-19 16:30:37 --> Router Class Initialized
INFO - 2023-08-19 16:30:37 --> Output Class Initialized
INFO - 2023-08-19 16:30:37 --> Security Class Initialized
DEBUG - 2023-08-19 16:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:30:37 --> Input Class Initialized
INFO - 2023-08-19 16:30:37 --> Language Class Initialized
INFO - 2023-08-19 16:30:37 --> Language Class Initialized
INFO - 2023-08-19 16:30:37 --> Config Class Initialized
INFO - 2023-08-19 16:30:37 --> Loader Class Initialized
INFO - 2023-08-19 16:30:37 --> Helper loaded: url_helper
INFO - 2023-08-19 16:30:37 --> Helper loaded: file_helper
INFO - 2023-08-19 16:30:37 --> Helper loaded: form_helper
INFO - 2023-08-19 16:30:37 --> Helper loaded: my_helper
INFO - 2023-08-19 16:30:37 --> Database Driver Class Initialized
INFO - 2023-08-19 16:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:30:37 --> Controller Class Initialized
DEBUG - 2023-08-19 16:30:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 16:30:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:30:37 --> Final output sent to browser
DEBUG - 2023-08-19 16:30:37 --> Total execution time: 0.0531
INFO - 2023-08-19 16:31:19 --> Config Class Initialized
INFO - 2023-08-19 16:31:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:31:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:31:19 --> Utf8 Class Initialized
INFO - 2023-08-19 16:31:19 --> URI Class Initialized
INFO - 2023-08-19 16:31:19 --> Router Class Initialized
INFO - 2023-08-19 16:31:19 --> Output Class Initialized
INFO - 2023-08-19 16:31:19 --> Security Class Initialized
DEBUG - 2023-08-19 16:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:31:19 --> Input Class Initialized
INFO - 2023-08-19 16:31:19 --> Language Class Initialized
INFO - 2023-08-19 16:31:19 --> Language Class Initialized
INFO - 2023-08-19 16:31:19 --> Config Class Initialized
INFO - 2023-08-19 16:31:19 --> Loader Class Initialized
INFO - 2023-08-19 16:31:19 --> Helper loaded: url_helper
INFO - 2023-08-19 16:31:19 --> Helper loaded: file_helper
INFO - 2023-08-19 16:31:19 --> Helper loaded: form_helper
INFO - 2023-08-19 16:31:19 --> Helper loaded: my_helper
INFO - 2023-08-19 16:31:19 --> Database Driver Class Initialized
INFO - 2023-08-19 16:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:31:19 --> Controller Class Initialized
INFO - 2023-08-19 16:31:19 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:31:19 --> Config Class Initialized
INFO - 2023-08-19 16:31:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:31:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:31:19 --> Utf8 Class Initialized
INFO - 2023-08-19 16:31:19 --> URI Class Initialized
INFO - 2023-08-19 16:31:19 --> Router Class Initialized
INFO - 2023-08-19 16:31:19 --> Output Class Initialized
INFO - 2023-08-19 16:31:19 --> Security Class Initialized
DEBUG - 2023-08-19 16:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:31:19 --> Input Class Initialized
INFO - 2023-08-19 16:31:19 --> Language Class Initialized
INFO - 2023-08-19 16:31:19 --> Language Class Initialized
INFO - 2023-08-19 16:31:19 --> Config Class Initialized
INFO - 2023-08-19 16:31:19 --> Loader Class Initialized
INFO - 2023-08-19 16:31:19 --> Helper loaded: url_helper
INFO - 2023-08-19 16:31:19 --> Helper loaded: file_helper
INFO - 2023-08-19 16:31:19 --> Helper loaded: form_helper
INFO - 2023-08-19 16:31:19 --> Helper loaded: my_helper
INFO - 2023-08-19 16:31:19 --> Database Driver Class Initialized
INFO - 2023-08-19 16:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:31:19 --> Controller Class Initialized
INFO - 2023-08-19 16:31:20 --> Config Class Initialized
INFO - 2023-08-19 16:31:20 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:31:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:31:20 --> Utf8 Class Initialized
INFO - 2023-08-19 16:31:20 --> URI Class Initialized
INFO - 2023-08-19 16:31:20 --> Router Class Initialized
INFO - 2023-08-19 16:31:20 --> Output Class Initialized
INFO - 2023-08-19 16:31:20 --> Security Class Initialized
DEBUG - 2023-08-19 16:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:31:20 --> Input Class Initialized
INFO - 2023-08-19 16:31:20 --> Language Class Initialized
INFO - 2023-08-19 16:31:20 --> Language Class Initialized
INFO - 2023-08-19 16:31:20 --> Config Class Initialized
INFO - 2023-08-19 16:31:20 --> Loader Class Initialized
INFO - 2023-08-19 16:31:20 --> Helper loaded: url_helper
INFO - 2023-08-19 16:31:20 --> Helper loaded: file_helper
INFO - 2023-08-19 16:31:20 --> Helper loaded: form_helper
INFO - 2023-08-19 16:31:20 --> Helper loaded: my_helper
INFO - 2023-08-19 16:31:20 --> Database Driver Class Initialized
INFO - 2023-08-19 16:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:31:20 --> Controller Class Initialized
DEBUG - 2023-08-19 16:31:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-08-19 16:31:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:31:20 --> Final output sent to browser
DEBUG - 2023-08-19 16:31:20 --> Total execution time: 0.0932
INFO - 2023-08-19 16:31:22 --> Config Class Initialized
INFO - 2023-08-19 16:31:22 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:31:22 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:31:22 --> Utf8 Class Initialized
INFO - 2023-08-19 16:31:22 --> URI Class Initialized
INFO - 2023-08-19 16:31:22 --> Router Class Initialized
INFO - 2023-08-19 16:31:22 --> Output Class Initialized
INFO - 2023-08-19 16:31:22 --> Security Class Initialized
DEBUG - 2023-08-19 16:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:31:22 --> Input Class Initialized
INFO - 2023-08-19 16:31:22 --> Language Class Initialized
INFO - 2023-08-19 16:31:22 --> Language Class Initialized
INFO - 2023-08-19 16:31:22 --> Config Class Initialized
INFO - 2023-08-19 16:31:22 --> Loader Class Initialized
INFO - 2023-08-19 16:31:22 --> Helper loaded: url_helper
INFO - 2023-08-19 16:31:22 --> Helper loaded: file_helper
INFO - 2023-08-19 16:31:22 --> Helper loaded: form_helper
INFO - 2023-08-19 16:31:22 --> Helper loaded: my_helper
INFO - 2023-08-19 16:31:22 --> Database Driver Class Initialized
INFO - 2023-08-19 16:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:31:22 --> Controller Class Initialized
INFO - 2023-08-19 16:31:22 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:31:22 --> Final output sent to browser
DEBUG - 2023-08-19 16:31:22 --> Total execution time: 0.0275
INFO - 2023-08-19 16:31:22 --> Config Class Initialized
INFO - 2023-08-19 16:31:22 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:31:22 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:31:22 --> Utf8 Class Initialized
INFO - 2023-08-19 16:31:22 --> URI Class Initialized
INFO - 2023-08-19 16:31:22 --> Router Class Initialized
INFO - 2023-08-19 16:31:22 --> Output Class Initialized
INFO - 2023-08-19 16:31:22 --> Security Class Initialized
DEBUG - 2023-08-19 16:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:31:22 --> Input Class Initialized
INFO - 2023-08-19 16:31:22 --> Language Class Initialized
INFO - 2023-08-19 16:31:22 --> Language Class Initialized
INFO - 2023-08-19 16:31:22 --> Config Class Initialized
INFO - 2023-08-19 16:31:22 --> Loader Class Initialized
INFO - 2023-08-19 16:31:22 --> Helper loaded: url_helper
INFO - 2023-08-19 16:31:22 --> Helper loaded: file_helper
INFO - 2023-08-19 16:31:22 --> Helper loaded: form_helper
INFO - 2023-08-19 16:31:22 --> Helper loaded: my_helper
INFO - 2023-08-19 16:31:22 --> Database Driver Class Initialized
INFO - 2023-08-19 16:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:31:22 --> Controller Class Initialized
DEBUG - 2023-08-19 16:31:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-08-19 16:31:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:31:22 --> Final output sent to browser
DEBUG - 2023-08-19 16:31:22 --> Total execution time: 0.0357
INFO - 2023-08-19 16:33:16 --> Config Class Initialized
INFO - 2023-08-19 16:33:16 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:33:16 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:33:16 --> Utf8 Class Initialized
INFO - 2023-08-19 16:33:16 --> URI Class Initialized
INFO - 2023-08-19 16:33:16 --> Router Class Initialized
INFO - 2023-08-19 16:33:16 --> Output Class Initialized
INFO - 2023-08-19 16:33:16 --> Security Class Initialized
DEBUG - 2023-08-19 16:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:33:16 --> Input Class Initialized
INFO - 2023-08-19 16:33:16 --> Language Class Initialized
INFO - 2023-08-19 16:33:16 --> Language Class Initialized
INFO - 2023-08-19 16:33:16 --> Config Class Initialized
INFO - 2023-08-19 16:33:16 --> Loader Class Initialized
INFO - 2023-08-19 16:33:16 --> Helper loaded: url_helper
INFO - 2023-08-19 16:33:16 --> Helper loaded: file_helper
INFO - 2023-08-19 16:33:16 --> Helper loaded: form_helper
INFO - 2023-08-19 16:33:16 --> Helper loaded: my_helper
INFO - 2023-08-19 16:33:16 --> Database Driver Class Initialized
INFO - 2023-08-19 16:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:33:16 --> Controller Class Initialized
INFO - 2023-08-19 16:34:56 --> Config Class Initialized
INFO - 2023-08-19 16:34:56 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:34:56 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:34:56 --> Utf8 Class Initialized
INFO - 2023-08-19 16:34:56 --> URI Class Initialized
INFO - 2023-08-19 16:34:56 --> Router Class Initialized
INFO - 2023-08-19 16:34:56 --> Output Class Initialized
INFO - 2023-08-19 16:34:56 --> Security Class Initialized
DEBUG - 2023-08-19 16:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:34:56 --> Input Class Initialized
INFO - 2023-08-19 16:34:56 --> Language Class Initialized
INFO - 2023-08-19 16:34:56 --> Language Class Initialized
INFO - 2023-08-19 16:34:56 --> Config Class Initialized
INFO - 2023-08-19 16:34:56 --> Loader Class Initialized
INFO - 2023-08-19 16:34:56 --> Helper loaded: url_helper
INFO - 2023-08-19 16:34:56 --> Helper loaded: file_helper
INFO - 2023-08-19 16:34:56 --> Helper loaded: form_helper
INFO - 2023-08-19 16:34:56 --> Helper loaded: my_helper
INFO - 2023-08-19 16:34:56 --> Database Driver Class Initialized
INFO - 2023-08-19 16:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:34:56 --> Controller Class Initialized
INFO - 2023-08-19 16:35:20 --> Config Class Initialized
INFO - 2023-08-19 16:35:20 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:35:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:35:20 --> Utf8 Class Initialized
INFO - 2023-08-19 16:35:20 --> URI Class Initialized
INFO - 2023-08-19 16:35:20 --> Router Class Initialized
INFO - 2023-08-19 16:35:20 --> Output Class Initialized
INFO - 2023-08-19 16:35:20 --> Security Class Initialized
DEBUG - 2023-08-19 16:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:35:20 --> Input Class Initialized
INFO - 2023-08-19 16:35:20 --> Language Class Initialized
INFO - 2023-08-19 16:35:20 --> Language Class Initialized
INFO - 2023-08-19 16:35:20 --> Config Class Initialized
INFO - 2023-08-19 16:35:20 --> Loader Class Initialized
INFO - 2023-08-19 16:35:20 --> Helper loaded: url_helper
INFO - 2023-08-19 16:35:20 --> Helper loaded: file_helper
INFO - 2023-08-19 16:35:20 --> Helper loaded: form_helper
INFO - 2023-08-19 16:35:20 --> Helper loaded: my_helper
INFO - 2023-08-19 16:35:20 --> Database Driver Class Initialized
INFO - 2023-08-19 16:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:35:20 --> Controller Class Initialized
DEBUG - 2023-08-19 16:35:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 16:35:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:35:20 --> Final output sent to browser
DEBUG - 2023-08-19 16:35:20 --> Total execution time: 0.0463
INFO - 2023-08-19 16:35:22 --> Config Class Initialized
INFO - 2023-08-19 16:35:22 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:35:22 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:35:22 --> Utf8 Class Initialized
INFO - 2023-08-19 16:35:22 --> URI Class Initialized
INFO - 2023-08-19 16:35:22 --> Router Class Initialized
INFO - 2023-08-19 16:35:22 --> Output Class Initialized
INFO - 2023-08-19 16:35:22 --> Security Class Initialized
DEBUG - 2023-08-19 16:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:35:22 --> Input Class Initialized
INFO - 2023-08-19 16:35:22 --> Language Class Initialized
INFO - 2023-08-19 16:35:22 --> Language Class Initialized
INFO - 2023-08-19 16:35:22 --> Config Class Initialized
INFO - 2023-08-19 16:35:22 --> Loader Class Initialized
INFO - 2023-08-19 16:35:22 --> Helper loaded: url_helper
INFO - 2023-08-19 16:35:22 --> Helper loaded: file_helper
INFO - 2023-08-19 16:35:22 --> Helper loaded: form_helper
INFO - 2023-08-19 16:35:22 --> Helper loaded: my_helper
INFO - 2023-08-19 16:35:22 --> Database Driver Class Initialized
INFO - 2023-08-19 16:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:35:22 --> Controller Class Initialized
DEBUG - 2023-08-19 16:35:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 16:35:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:35:22 --> Final output sent to browser
DEBUG - 2023-08-19 16:35:22 --> Total execution time: 0.0420
INFO - 2023-08-19 16:36:16 --> Config Class Initialized
INFO - 2023-08-19 16:36:16 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:36:16 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:36:16 --> Utf8 Class Initialized
INFO - 2023-08-19 16:36:16 --> URI Class Initialized
DEBUG - 2023-08-19 16:36:16 --> No URI present. Default controller set.
INFO - 2023-08-19 16:36:16 --> Router Class Initialized
INFO - 2023-08-19 16:36:16 --> Output Class Initialized
INFO - 2023-08-19 16:36:16 --> Security Class Initialized
DEBUG - 2023-08-19 16:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:36:16 --> Input Class Initialized
INFO - 2023-08-19 16:36:16 --> Language Class Initialized
INFO - 2023-08-19 16:36:16 --> Language Class Initialized
INFO - 2023-08-19 16:36:16 --> Config Class Initialized
INFO - 2023-08-19 16:36:16 --> Loader Class Initialized
INFO - 2023-08-19 16:36:16 --> Helper loaded: url_helper
INFO - 2023-08-19 16:36:16 --> Helper loaded: file_helper
INFO - 2023-08-19 16:36:16 --> Helper loaded: form_helper
INFO - 2023-08-19 16:36:16 --> Helper loaded: my_helper
INFO - 2023-08-19 16:36:16 --> Database Driver Class Initialized
INFO - 2023-08-19 16:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:36:16 --> Controller Class Initialized
DEBUG - 2023-08-19 16:36:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 16:36:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:36:16 --> Final output sent to browser
DEBUG - 2023-08-19 16:36:16 --> Total execution time: 0.0309
INFO - 2023-08-19 16:36:18 --> Config Class Initialized
INFO - 2023-08-19 16:36:18 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:36:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:36:18 --> Utf8 Class Initialized
INFO - 2023-08-19 16:36:18 --> URI Class Initialized
INFO - 2023-08-19 16:36:18 --> Router Class Initialized
INFO - 2023-08-19 16:36:18 --> Output Class Initialized
INFO - 2023-08-19 16:36:18 --> Security Class Initialized
DEBUG - 2023-08-19 16:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:36:18 --> Input Class Initialized
INFO - 2023-08-19 16:36:18 --> Language Class Initialized
INFO - 2023-08-19 16:36:18 --> Language Class Initialized
INFO - 2023-08-19 16:36:18 --> Config Class Initialized
INFO - 2023-08-19 16:36:18 --> Loader Class Initialized
INFO - 2023-08-19 16:36:18 --> Helper loaded: url_helper
INFO - 2023-08-19 16:36:18 --> Helper loaded: file_helper
INFO - 2023-08-19 16:36:18 --> Helper loaded: form_helper
INFO - 2023-08-19 16:36:18 --> Helper loaded: my_helper
INFO - 2023-08-19 16:36:18 --> Database Driver Class Initialized
INFO - 2023-08-19 16:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:36:18 --> Controller Class Initialized
DEBUG - 2023-08-19 16:36:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 16:36:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:36:18 --> Final output sent to browser
DEBUG - 2023-08-19 16:36:18 --> Total execution time: 0.0262
INFO - 2023-08-19 16:36:42 --> Config Class Initialized
INFO - 2023-08-19 16:36:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:36:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:36:42 --> Utf8 Class Initialized
INFO - 2023-08-19 16:36:42 --> URI Class Initialized
INFO - 2023-08-19 16:36:42 --> Router Class Initialized
INFO - 2023-08-19 16:36:42 --> Output Class Initialized
INFO - 2023-08-19 16:36:42 --> Security Class Initialized
DEBUG - 2023-08-19 16:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:36:42 --> Input Class Initialized
INFO - 2023-08-19 16:36:42 --> Language Class Initialized
INFO - 2023-08-19 16:36:42 --> Language Class Initialized
INFO - 2023-08-19 16:36:42 --> Config Class Initialized
INFO - 2023-08-19 16:36:42 --> Loader Class Initialized
INFO - 2023-08-19 16:36:42 --> Helper loaded: url_helper
INFO - 2023-08-19 16:36:42 --> Helper loaded: file_helper
INFO - 2023-08-19 16:36:42 --> Helper loaded: form_helper
INFO - 2023-08-19 16:36:42 --> Helper loaded: my_helper
INFO - 2023-08-19 16:36:42 --> Database Driver Class Initialized
INFO - 2023-08-19 16:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:36:42 --> Controller Class Initialized
INFO - 2023-08-19 16:36:42 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:36:42 --> Config Class Initialized
INFO - 2023-08-19 16:36:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:36:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:36:42 --> Utf8 Class Initialized
INFO - 2023-08-19 16:36:42 --> URI Class Initialized
INFO - 2023-08-19 16:36:42 --> Router Class Initialized
INFO - 2023-08-19 16:36:42 --> Output Class Initialized
INFO - 2023-08-19 16:36:42 --> Security Class Initialized
DEBUG - 2023-08-19 16:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:36:42 --> Input Class Initialized
INFO - 2023-08-19 16:36:42 --> Language Class Initialized
INFO - 2023-08-19 16:36:42 --> Language Class Initialized
INFO - 2023-08-19 16:36:42 --> Config Class Initialized
INFO - 2023-08-19 16:36:42 --> Loader Class Initialized
INFO - 2023-08-19 16:36:42 --> Helper loaded: url_helper
INFO - 2023-08-19 16:36:42 --> Helper loaded: file_helper
INFO - 2023-08-19 16:36:42 --> Helper loaded: form_helper
INFO - 2023-08-19 16:36:42 --> Helper loaded: my_helper
INFO - 2023-08-19 16:36:42 --> Database Driver Class Initialized
INFO - 2023-08-19 16:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:36:42 --> Controller Class Initialized
INFO - 2023-08-19 16:36:42 --> Config Class Initialized
INFO - 2023-08-19 16:36:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:36:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:36:42 --> Utf8 Class Initialized
INFO - 2023-08-19 16:36:42 --> URI Class Initialized
INFO - 2023-08-19 16:36:42 --> Router Class Initialized
INFO - 2023-08-19 16:36:42 --> Output Class Initialized
INFO - 2023-08-19 16:36:42 --> Security Class Initialized
DEBUG - 2023-08-19 16:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:36:42 --> Input Class Initialized
INFO - 2023-08-19 16:36:42 --> Language Class Initialized
INFO - 2023-08-19 16:36:42 --> Language Class Initialized
INFO - 2023-08-19 16:36:42 --> Config Class Initialized
INFO - 2023-08-19 16:36:42 --> Loader Class Initialized
INFO - 2023-08-19 16:36:42 --> Helper loaded: url_helper
INFO - 2023-08-19 16:36:42 --> Helper loaded: file_helper
INFO - 2023-08-19 16:36:42 --> Helper loaded: form_helper
INFO - 2023-08-19 16:36:42 --> Helper loaded: my_helper
INFO - 2023-08-19 16:36:42 --> Database Driver Class Initialized
INFO - 2023-08-19 16:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:36:42 --> Controller Class Initialized
DEBUG - 2023-08-19 16:36:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-08-19 16:36:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:36:42 --> Final output sent to browser
DEBUG - 2023-08-19 16:36:42 --> Total execution time: 0.0285
INFO - 2023-08-19 16:36:48 --> Config Class Initialized
INFO - 2023-08-19 16:36:48 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:36:48 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:36:48 --> Utf8 Class Initialized
INFO - 2023-08-19 16:36:48 --> URI Class Initialized
INFO - 2023-08-19 16:36:48 --> Router Class Initialized
INFO - 2023-08-19 16:36:48 --> Output Class Initialized
INFO - 2023-08-19 16:36:48 --> Security Class Initialized
DEBUG - 2023-08-19 16:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:36:48 --> Input Class Initialized
INFO - 2023-08-19 16:36:48 --> Language Class Initialized
INFO - 2023-08-19 16:36:48 --> Language Class Initialized
INFO - 2023-08-19 16:36:48 --> Config Class Initialized
INFO - 2023-08-19 16:36:48 --> Loader Class Initialized
INFO - 2023-08-19 16:36:48 --> Helper loaded: url_helper
INFO - 2023-08-19 16:36:48 --> Helper loaded: file_helper
INFO - 2023-08-19 16:36:48 --> Helper loaded: form_helper
INFO - 2023-08-19 16:36:48 --> Helper loaded: my_helper
INFO - 2023-08-19 16:36:48 --> Database Driver Class Initialized
INFO - 2023-08-19 16:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:36:48 --> Controller Class Initialized
INFO - 2023-08-19 16:36:48 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:36:48 --> Final output sent to browser
DEBUG - 2023-08-19 16:36:48 --> Total execution time: 0.0287
INFO - 2023-08-19 16:36:48 --> Config Class Initialized
INFO - 2023-08-19 16:36:48 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:36:48 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:36:48 --> Utf8 Class Initialized
INFO - 2023-08-19 16:36:48 --> URI Class Initialized
INFO - 2023-08-19 16:36:48 --> Router Class Initialized
INFO - 2023-08-19 16:36:48 --> Output Class Initialized
INFO - 2023-08-19 16:36:48 --> Security Class Initialized
DEBUG - 2023-08-19 16:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:36:48 --> Input Class Initialized
INFO - 2023-08-19 16:36:48 --> Language Class Initialized
INFO - 2023-08-19 16:36:48 --> Language Class Initialized
INFO - 2023-08-19 16:36:48 --> Config Class Initialized
INFO - 2023-08-19 16:36:48 --> Loader Class Initialized
INFO - 2023-08-19 16:36:48 --> Helper loaded: url_helper
INFO - 2023-08-19 16:36:48 --> Helper loaded: file_helper
INFO - 2023-08-19 16:36:48 --> Helper loaded: form_helper
INFO - 2023-08-19 16:36:48 --> Helper loaded: my_helper
INFO - 2023-08-19 16:36:48 --> Database Driver Class Initialized
INFO - 2023-08-19 16:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:36:48 --> Controller Class Initialized
DEBUG - 2023-08-19 16:36:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-08-19 16:36:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:36:48 --> Final output sent to browser
DEBUG - 2023-08-19 16:36:48 --> Total execution time: 0.0383
INFO - 2023-08-19 16:36:51 --> Config Class Initialized
INFO - 2023-08-19 16:36:51 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:36:51 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:36:51 --> Utf8 Class Initialized
INFO - 2023-08-19 16:36:51 --> URI Class Initialized
INFO - 2023-08-19 16:36:51 --> Router Class Initialized
INFO - 2023-08-19 16:36:51 --> Output Class Initialized
INFO - 2023-08-19 16:36:51 --> Security Class Initialized
DEBUG - 2023-08-19 16:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:36:51 --> Input Class Initialized
INFO - 2023-08-19 16:36:51 --> Language Class Initialized
INFO - 2023-08-19 16:36:51 --> Language Class Initialized
INFO - 2023-08-19 16:36:51 --> Config Class Initialized
INFO - 2023-08-19 16:36:51 --> Loader Class Initialized
INFO - 2023-08-19 16:36:51 --> Helper loaded: url_helper
INFO - 2023-08-19 16:36:51 --> Helper loaded: file_helper
INFO - 2023-08-19 16:36:51 --> Helper loaded: form_helper
INFO - 2023-08-19 16:36:51 --> Helper loaded: my_helper
INFO - 2023-08-19 16:36:51 --> Database Driver Class Initialized
INFO - 2023-08-19 16:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:36:51 --> Controller Class Initialized
DEBUG - 2023-08-19 16:36:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-19 16:36:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:36:51 --> Final output sent to browser
DEBUG - 2023-08-19 16:36:51 --> Total execution time: 0.0276
INFO - 2023-08-19 16:48:37 --> Config Class Initialized
INFO - 2023-08-19 16:48:37 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:48:37 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:48:37 --> Utf8 Class Initialized
INFO - 2023-08-19 16:48:37 --> URI Class Initialized
INFO - 2023-08-19 16:48:37 --> Router Class Initialized
INFO - 2023-08-19 16:48:37 --> Output Class Initialized
INFO - 2023-08-19 16:48:37 --> Security Class Initialized
DEBUG - 2023-08-19 16:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:48:37 --> Input Class Initialized
INFO - 2023-08-19 16:48:37 --> Language Class Initialized
INFO - 2023-08-19 16:48:37 --> Language Class Initialized
INFO - 2023-08-19 16:48:37 --> Config Class Initialized
INFO - 2023-08-19 16:48:37 --> Loader Class Initialized
INFO - 2023-08-19 16:48:37 --> Helper loaded: url_helper
INFO - 2023-08-19 16:48:37 --> Helper loaded: file_helper
INFO - 2023-08-19 16:48:37 --> Helper loaded: form_helper
INFO - 2023-08-19 16:48:37 --> Helper loaded: my_helper
INFO - 2023-08-19 16:48:37 --> Database Driver Class Initialized
INFO - 2023-08-19 16:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:48:37 --> Controller Class Initialized
DEBUG - 2023-08-19 16:48:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-08-19 16:48:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:48:37 --> Final output sent to browser
DEBUG - 2023-08-19 16:48:37 --> Total execution time: 0.0307
INFO - 2023-08-19 16:48:37 --> Config Class Initialized
INFO - 2023-08-19 16:48:37 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:48:37 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:48:37 --> Utf8 Class Initialized
INFO - 2023-08-19 16:48:37 --> URI Class Initialized
INFO - 2023-08-19 16:48:37 --> Router Class Initialized
INFO - 2023-08-19 16:48:37 --> Output Class Initialized
INFO - 2023-08-19 16:48:37 --> Security Class Initialized
DEBUG - 2023-08-19 16:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:48:37 --> Input Class Initialized
INFO - 2023-08-19 16:48:37 --> Language Class Initialized
ERROR - 2023-08-19 16:48:37 --> 404 Page Not Found: /index
INFO - 2023-08-19 16:48:37 --> Config Class Initialized
INFO - 2023-08-19 16:48:37 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:48:37 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:48:37 --> Utf8 Class Initialized
INFO - 2023-08-19 16:48:37 --> URI Class Initialized
INFO - 2023-08-19 16:48:37 --> Router Class Initialized
INFO - 2023-08-19 16:48:37 --> Output Class Initialized
INFO - 2023-08-19 16:48:37 --> Security Class Initialized
DEBUG - 2023-08-19 16:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:48:37 --> Input Class Initialized
INFO - 2023-08-19 16:48:37 --> Language Class Initialized
INFO - 2023-08-19 16:48:37 --> Language Class Initialized
INFO - 2023-08-19 16:48:37 --> Config Class Initialized
INFO - 2023-08-19 16:48:37 --> Loader Class Initialized
INFO - 2023-08-19 16:48:37 --> Helper loaded: url_helper
INFO - 2023-08-19 16:48:37 --> Helper loaded: file_helper
INFO - 2023-08-19 16:48:37 --> Helper loaded: form_helper
INFO - 2023-08-19 16:48:37 --> Helper loaded: my_helper
INFO - 2023-08-19 16:48:37 --> Database Driver Class Initialized
INFO - 2023-08-19 16:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:48:37 --> Controller Class Initialized
INFO - 2023-08-19 16:52:21 --> Config Class Initialized
INFO - 2023-08-19 16:52:21 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:52:21 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:52:21 --> Utf8 Class Initialized
INFO - 2023-08-19 16:52:21 --> URI Class Initialized
INFO - 2023-08-19 16:52:21 --> Router Class Initialized
INFO - 2023-08-19 16:52:21 --> Output Class Initialized
INFO - 2023-08-19 16:52:21 --> Security Class Initialized
DEBUG - 2023-08-19 16:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:52:21 --> Input Class Initialized
INFO - 2023-08-19 16:52:21 --> Language Class Initialized
INFO - 2023-08-19 16:52:21 --> Language Class Initialized
INFO - 2023-08-19 16:52:21 --> Config Class Initialized
INFO - 2023-08-19 16:52:21 --> Loader Class Initialized
INFO - 2023-08-19 16:52:21 --> Helper loaded: url_helper
INFO - 2023-08-19 16:52:21 --> Helper loaded: file_helper
INFO - 2023-08-19 16:52:21 --> Helper loaded: form_helper
INFO - 2023-08-19 16:52:21 --> Helper loaded: my_helper
INFO - 2023-08-19 16:52:21 --> Database Driver Class Initialized
INFO - 2023-08-19 16:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:52:21 --> Controller Class Initialized
DEBUG - 2023-08-19 16:52:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-08-19 16:52:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-19 16:52:21 --> Final output sent to browser
DEBUG - 2023-08-19 16:52:21 --> Total execution time: 0.0952
