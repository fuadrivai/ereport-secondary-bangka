<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-11-01 08:12:15 --> Config Class Initialized
INFO - 2023-11-01 08:12:15 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:12:15 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:12:15 --> Utf8 Class Initialized
INFO - 2023-11-01 08:12:15 --> URI Class Initialized
INFO - 2023-11-01 08:12:15 --> Router Class Initialized
INFO - 2023-11-01 08:12:15 --> Output Class Initialized
INFO - 2023-11-01 08:12:15 --> Security Class Initialized
DEBUG - 2023-11-01 08:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:12:15 --> Input Class Initialized
INFO - 2023-11-01 08:12:15 --> Language Class Initialized
INFO - 2023-11-01 08:12:15 --> Language Class Initialized
INFO - 2023-11-01 08:12:15 --> Config Class Initialized
INFO - 2023-11-01 08:12:15 --> Loader Class Initialized
INFO - 2023-11-01 08:12:15 --> Helper loaded: url_helper
INFO - 2023-11-01 08:12:15 --> Helper loaded: file_helper
INFO - 2023-11-01 08:12:15 --> Helper loaded: form_helper
INFO - 2023-11-01 08:12:15 --> Helper loaded: my_helper
INFO - 2023-11-01 08:12:15 --> Database Driver Class Initialized
INFO - 2023-11-01 08:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:12:15 --> Controller Class Initialized
DEBUG - 2023-11-01 08:12:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-01 08:12:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-01 08:12:15 --> Final output sent to browser
DEBUG - 2023-11-01 08:12:15 --> Total execution time: 0.0756
INFO - 2023-11-01 08:12:20 --> Config Class Initialized
INFO - 2023-11-01 08:12:20 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:12:20 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:12:20 --> Utf8 Class Initialized
INFO - 2023-11-01 08:12:20 --> URI Class Initialized
INFO - 2023-11-01 08:12:20 --> Router Class Initialized
INFO - 2023-11-01 08:12:20 --> Output Class Initialized
INFO - 2023-11-01 08:12:20 --> Security Class Initialized
DEBUG - 2023-11-01 08:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:12:20 --> Input Class Initialized
INFO - 2023-11-01 08:12:20 --> Language Class Initialized
INFO - 2023-11-01 08:12:20 --> Language Class Initialized
INFO - 2023-11-01 08:12:20 --> Config Class Initialized
INFO - 2023-11-01 08:12:20 --> Loader Class Initialized
INFO - 2023-11-01 08:12:20 --> Helper loaded: url_helper
INFO - 2023-11-01 08:12:20 --> Helper loaded: file_helper
INFO - 2023-11-01 08:12:20 --> Helper loaded: form_helper
INFO - 2023-11-01 08:12:20 --> Helper loaded: my_helper
INFO - 2023-11-01 08:12:20 --> Database Driver Class Initialized
INFO - 2023-11-01 08:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:12:20 --> Controller Class Initialized
INFO - 2023-11-01 08:12:20 --> Helper loaded: cookie_helper
INFO - 2023-11-01 08:12:20 --> Final output sent to browser
DEBUG - 2023-11-01 08:12:20 --> Total execution time: 0.0841
INFO - 2023-11-01 08:12:20 --> Config Class Initialized
INFO - 2023-11-01 08:12:20 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:12:20 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:12:20 --> Utf8 Class Initialized
INFO - 2023-11-01 08:12:20 --> URI Class Initialized
INFO - 2023-11-01 08:12:20 --> Router Class Initialized
INFO - 2023-11-01 08:12:20 --> Output Class Initialized
INFO - 2023-11-01 08:12:20 --> Security Class Initialized
DEBUG - 2023-11-01 08:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:12:20 --> Input Class Initialized
INFO - 2023-11-01 08:12:20 --> Language Class Initialized
INFO - 2023-11-01 08:12:20 --> Language Class Initialized
INFO - 2023-11-01 08:12:20 --> Config Class Initialized
INFO - 2023-11-01 08:12:20 --> Loader Class Initialized
INFO - 2023-11-01 08:12:20 --> Helper loaded: url_helper
INFO - 2023-11-01 08:12:20 --> Helper loaded: file_helper
INFO - 2023-11-01 08:12:20 --> Helper loaded: form_helper
INFO - 2023-11-01 08:12:20 --> Helper loaded: my_helper
INFO - 2023-11-01 08:12:20 --> Database Driver Class Initialized
INFO - 2023-11-01 08:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:12:20 --> Controller Class Initialized
DEBUG - 2023-11-01 08:12:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-01 08:12:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-01 08:12:20 --> Final output sent to browser
DEBUG - 2023-11-01 08:12:20 --> Total execution time: 0.0551
INFO - 2023-11-01 08:12:28 --> Config Class Initialized
INFO - 2023-11-01 08:12:28 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:12:28 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:12:28 --> Utf8 Class Initialized
INFO - 2023-11-01 08:12:28 --> URI Class Initialized
INFO - 2023-11-01 08:12:28 --> Router Class Initialized
INFO - 2023-11-01 08:12:28 --> Output Class Initialized
INFO - 2023-11-01 08:12:28 --> Security Class Initialized
DEBUG - 2023-11-01 08:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:12:28 --> Input Class Initialized
INFO - 2023-11-01 08:12:28 --> Language Class Initialized
INFO - 2023-11-01 08:12:28 --> Language Class Initialized
INFO - 2023-11-01 08:12:28 --> Config Class Initialized
INFO - 2023-11-01 08:12:28 --> Loader Class Initialized
INFO - 2023-11-01 08:12:28 --> Helper loaded: url_helper
INFO - 2023-11-01 08:12:28 --> Helper loaded: file_helper
INFO - 2023-11-01 08:12:28 --> Helper loaded: form_helper
INFO - 2023-11-01 08:12:28 --> Helper loaded: my_helper
INFO - 2023-11-01 08:12:28 --> Database Driver Class Initialized
INFO - 2023-11-01 08:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:12:28 --> Controller Class Initialized
DEBUG - 2023-11-01 08:12:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2023-11-01 08:12:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-01 08:12:28 --> Final output sent to browser
DEBUG - 2023-11-01 08:12:28 --> Total execution time: 0.0519
INFO - 2023-11-01 08:12:30 --> Config Class Initialized
INFO - 2023-11-01 08:12:30 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:12:30 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:12:30 --> Utf8 Class Initialized
INFO - 2023-11-01 08:12:30 --> URI Class Initialized
INFO - 2023-11-01 08:12:30 --> Router Class Initialized
INFO - 2023-11-01 08:12:30 --> Output Class Initialized
INFO - 2023-11-01 08:12:30 --> Security Class Initialized
DEBUG - 2023-11-01 08:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:12:30 --> Input Class Initialized
INFO - 2023-11-01 08:12:30 --> Language Class Initialized
INFO - 2023-11-01 08:12:30 --> Language Class Initialized
INFO - 2023-11-01 08:12:30 --> Config Class Initialized
INFO - 2023-11-01 08:12:30 --> Loader Class Initialized
INFO - 2023-11-01 08:12:30 --> Helper loaded: url_helper
INFO - 2023-11-01 08:12:30 --> Helper loaded: file_helper
INFO - 2023-11-01 08:12:30 --> Helper loaded: form_helper
INFO - 2023-11-01 08:12:30 --> Helper loaded: my_helper
INFO - 2023-11-01 08:12:30 --> Database Driver Class Initialized
INFO - 2023-11-01 08:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:12:30 --> Controller Class Initialized
DEBUG - 2023-11-01 08:12:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 08:12:34 --> Final output sent to browser
DEBUG - 2023-11-01 08:12:34 --> Total execution time: 3.7201
INFO - 2023-11-01 08:14:24 --> Config Class Initialized
INFO - 2023-11-01 08:14:24 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:14:24 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:14:24 --> Utf8 Class Initialized
INFO - 2023-11-01 08:14:24 --> URI Class Initialized
INFO - 2023-11-01 08:14:24 --> Router Class Initialized
INFO - 2023-11-01 08:14:24 --> Output Class Initialized
INFO - 2023-11-01 08:14:24 --> Security Class Initialized
DEBUG - 2023-11-01 08:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:14:24 --> Input Class Initialized
INFO - 2023-11-01 08:14:24 --> Language Class Initialized
INFO - 2023-11-01 08:14:24 --> Language Class Initialized
INFO - 2023-11-01 08:14:24 --> Config Class Initialized
INFO - 2023-11-01 08:14:24 --> Loader Class Initialized
INFO - 2023-11-01 08:14:24 --> Helper loaded: url_helper
INFO - 2023-11-01 08:14:24 --> Helper loaded: file_helper
INFO - 2023-11-01 08:14:24 --> Helper loaded: form_helper
INFO - 2023-11-01 08:14:24 --> Helper loaded: my_helper
INFO - 2023-11-01 08:14:24 --> Database Driver Class Initialized
INFO - 2023-11-01 08:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:14:24 --> Controller Class Initialized
INFO - 2023-11-01 08:14:24 --> Helper loaded: cookie_helper
INFO - 2023-11-01 08:14:24 --> Config Class Initialized
INFO - 2023-11-01 08:14:24 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:14:24 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:14:24 --> Utf8 Class Initialized
INFO - 2023-11-01 08:14:24 --> URI Class Initialized
INFO - 2023-11-01 08:14:24 --> Router Class Initialized
INFO - 2023-11-01 08:14:24 --> Output Class Initialized
INFO - 2023-11-01 08:14:24 --> Security Class Initialized
DEBUG - 2023-11-01 08:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:14:24 --> Input Class Initialized
INFO - 2023-11-01 08:14:24 --> Language Class Initialized
INFO - 2023-11-01 08:14:24 --> Language Class Initialized
INFO - 2023-11-01 08:14:24 --> Config Class Initialized
INFO - 2023-11-01 08:14:24 --> Loader Class Initialized
INFO - 2023-11-01 08:14:24 --> Helper loaded: url_helper
INFO - 2023-11-01 08:14:24 --> Helper loaded: file_helper
INFO - 2023-11-01 08:14:24 --> Helper loaded: form_helper
INFO - 2023-11-01 08:14:24 --> Helper loaded: my_helper
INFO - 2023-11-01 08:14:24 --> Database Driver Class Initialized
INFO - 2023-11-01 08:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:14:24 --> Controller Class Initialized
INFO - 2023-11-01 08:14:24 --> Config Class Initialized
INFO - 2023-11-01 08:14:24 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:14:24 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:14:24 --> Utf8 Class Initialized
INFO - 2023-11-01 08:14:24 --> URI Class Initialized
INFO - 2023-11-01 08:14:24 --> Router Class Initialized
INFO - 2023-11-01 08:14:24 --> Output Class Initialized
INFO - 2023-11-01 08:14:24 --> Security Class Initialized
DEBUG - 2023-11-01 08:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:14:24 --> Input Class Initialized
INFO - 2023-11-01 08:14:24 --> Language Class Initialized
INFO - 2023-11-01 08:14:24 --> Language Class Initialized
INFO - 2023-11-01 08:14:24 --> Config Class Initialized
INFO - 2023-11-01 08:14:24 --> Loader Class Initialized
INFO - 2023-11-01 08:14:24 --> Helper loaded: url_helper
INFO - 2023-11-01 08:14:24 --> Helper loaded: file_helper
INFO - 2023-11-01 08:14:24 --> Helper loaded: form_helper
INFO - 2023-11-01 08:14:24 --> Helper loaded: my_helper
INFO - 2023-11-01 08:14:24 --> Database Driver Class Initialized
INFO - 2023-11-01 08:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:14:25 --> Controller Class Initialized
DEBUG - 2023-11-01 08:14:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-01 08:14:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-01 08:14:25 --> Final output sent to browser
DEBUG - 2023-11-01 08:14:25 --> Total execution time: 0.0412
INFO - 2023-11-01 08:14:54 --> Config Class Initialized
INFO - 2023-11-01 08:14:54 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:14:54 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:14:54 --> Utf8 Class Initialized
INFO - 2023-11-01 08:14:54 --> URI Class Initialized
INFO - 2023-11-01 08:14:54 --> Router Class Initialized
INFO - 2023-11-01 08:14:54 --> Output Class Initialized
INFO - 2023-11-01 08:14:54 --> Security Class Initialized
DEBUG - 2023-11-01 08:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:14:54 --> Input Class Initialized
INFO - 2023-11-01 08:14:54 --> Language Class Initialized
INFO - 2023-11-01 08:14:54 --> Language Class Initialized
INFO - 2023-11-01 08:14:54 --> Config Class Initialized
INFO - 2023-11-01 08:14:54 --> Loader Class Initialized
INFO - 2023-11-01 08:14:54 --> Helper loaded: url_helper
INFO - 2023-11-01 08:14:54 --> Helper loaded: file_helper
INFO - 2023-11-01 08:14:54 --> Helper loaded: form_helper
INFO - 2023-11-01 08:14:54 --> Helper loaded: my_helper
INFO - 2023-11-01 08:14:54 --> Database Driver Class Initialized
INFO - 2023-11-01 08:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:14:54 --> Controller Class Initialized
INFO - 2023-11-01 08:14:54 --> Helper loaded: cookie_helper
INFO - 2023-11-01 08:14:54 --> Final output sent to browser
DEBUG - 2023-11-01 08:14:54 --> Total execution time: 0.0373
INFO - 2023-11-01 08:15:09 --> Config Class Initialized
INFO - 2023-11-01 08:15:09 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:15:09 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:15:09 --> Utf8 Class Initialized
INFO - 2023-11-01 08:15:09 --> URI Class Initialized
INFO - 2023-11-01 08:15:09 --> Router Class Initialized
INFO - 2023-11-01 08:15:09 --> Output Class Initialized
INFO - 2023-11-01 08:15:09 --> Security Class Initialized
DEBUG - 2023-11-01 08:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:15:09 --> Input Class Initialized
INFO - 2023-11-01 08:15:09 --> Language Class Initialized
INFO - 2023-11-01 08:15:09 --> Language Class Initialized
INFO - 2023-11-01 08:15:09 --> Config Class Initialized
INFO - 2023-11-01 08:15:09 --> Loader Class Initialized
INFO - 2023-11-01 08:15:09 --> Helper loaded: url_helper
INFO - 2023-11-01 08:15:09 --> Helper loaded: file_helper
INFO - 2023-11-01 08:15:09 --> Helper loaded: form_helper
INFO - 2023-11-01 08:15:09 --> Helper loaded: my_helper
INFO - 2023-11-01 08:15:09 --> Database Driver Class Initialized
INFO - 2023-11-01 08:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:15:09 --> Controller Class Initialized
DEBUG - 2023-11-01 08:15:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-11-01 08:15:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-01 08:15:09 --> Final output sent to browser
DEBUG - 2023-11-01 08:15:09 --> Total execution time: 0.0371
INFO - 2023-11-01 08:16:59 --> Config Class Initialized
INFO - 2023-11-01 08:16:59 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:16:59 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:16:59 --> Utf8 Class Initialized
INFO - 2023-11-01 08:16:59 --> URI Class Initialized
INFO - 2023-11-01 08:16:59 --> Router Class Initialized
INFO - 2023-11-01 08:16:59 --> Output Class Initialized
INFO - 2023-11-01 08:16:59 --> Security Class Initialized
DEBUG - 2023-11-01 08:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:16:59 --> Input Class Initialized
INFO - 2023-11-01 08:16:59 --> Language Class Initialized
INFO - 2023-11-01 08:16:59 --> Language Class Initialized
INFO - 2023-11-01 08:16:59 --> Config Class Initialized
INFO - 2023-11-01 08:16:59 --> Loader Class Initialized
INFO - 2023-11-01 08:16:59 --> Helper loaded: url_helper
INFO - 2023-11-01 08:16:59 --> Helper loaded: file_helper
INFO - 2023-11-01 08:16:59 --> Helper loaded: form_helper
INFO - 2023-11-01 08:16:59 --> Helper loaded: my_helper
INFO - 2023-11-01 08:16:59 --> Database Driver Class Initialized
INFO - 2023-11-01 08:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:16:59 --> Controller Class Initialized
DEBUG - 2023-11-01 08:16:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2023-11-01 08:16:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-01 08:16:59 --> Final output sent to browser
DEBUG - 2023-11-01 08:16:59 --> Total execution time: 0.0826
INFO - 2023-11-01 08:17:00 --> Config Class Initialized
INFO - 2023-11-01 08:17:00 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:17:00 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:17:00 --> Utf8 Class Initialized
INFO - 2023-11-01 08:17:00 --> URI Class Initialized
INFO - 2023-11-01 08:17:00 --> Router Class Initialized
INFO - 2023-11-01 08:17:00 --> Output Class Initialized
INFO - 2023-11-01 08:17:00 --> Security Class Initialized
DEBUG - 2023-11-01 08:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:17:00 --> Input Class Initialized
INFO - 2023-11-01 08:17:00 --> Language Class Initialized
ERROR - 2023-11-01 08:17:00 --> 404 Page Not Found: /index
INFO - 2023-11-01 08:17:00 --> Config Class Initialized
INFO - 2023-11-01 08:17:00 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:17:00 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:17:00 --> Utf8 Class Initialized
INFO - 2023-11-01 08:17:00 --> URI Class Initialized
INFO - 2023-11-01 08:17:00 --> Router Class Initialized
INFO - 2023-11-01 08:17:00 --> Output Class Initialized
INFO - 2023-11-01 08:17:00 --> Security Class Initialized
DEBUG - 2023-11-01 08:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:17:00 --> Input Class Initialized
INFO - 2023-11-01 08:17:00 --> Language Class Initialized
INFO - 2023-11-01 08:17:00 --> Language Class Initialized
INFO - 2023-11-01 08:17:00 --> Config Class Initialized
INFO - 2023-11-01 08:17:00 --> Loader Class Initialized
INFO - 2023-11-01 08:17:00 --> Helper loaded: url_helper
INFO - 2023-11-01 08:17:00 --> Helper loaded: file_helper
INFO - 2023-11-01 08:17:00 --> Helper loaded: form_helper
INFO - 2023-11-01 08:17:00 --> Helper loaded: my_helper
INFO - 2023-11-01 08:17:00 --> Database Driver Class Initialized
INFO - 2023-11-01 08:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:17:00 --> Controller Class Initialized
INFO - 2023-11-01 08:17:12 --> Config Class Initialized
INFO - 2023-11-01 08:17:12 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:17:12 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:17:12 --> Utf8 Class Initialized
INFO - 2023-11-01 08:17:12 --> URI Class Initialized
INFO - 2023-11-01 08:17:12 --> Router Class Initialized
INFO - 2023-11-01 08:17:12 --> Output Class Initialized
INFO - 2023-11-01 08:17:12 --> Security Class Initialized
DEBUG - 2023-11-01 08:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:17:12 --> Input Class Initialized
INFO - 2023-11-01 08:17:12 --> Language Class Initialized
INFO - 2023-11-01 08:17:12 --> Language Class Initialized
INFO - 2023-11-01 08:17:12 --> Config Class Initialized
INFO - 2023-11-01 08:17:12 --> Loader Class Initialized
INFO - 2023-11-01 08:17:12 --> Helper loaded: url_helper
INFO - 2023-11-01 08:17:12 --> Helper loaded: file_helper
INFO - 2023-11-01 08:17:12 --> Helper loaded: form_helper
INFO - 2023-11-01 08:17:12 --> Helper loaded: my_helper
INFO - 2023-11-01 08:17:12 --> Database Driver Class Initialized
INFO - 2023-11-01 08:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:17:12 --> Controller Class Initialized
DEBUG - 2023-11-01 08:17:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_walikelas/views/list.php
DEBUG - 2023-11-01 08:17:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-01 08:17:12 --> Final output sent to browser
DEBUG - 2023-11-01 08:17:12 --> Total execution time: 0.0415
INFO - 2023-11-01 08:17:13 --> Config Class Initialized
INFO - 2023-11-01 08:17:13 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:17:13 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:17:13 --> Utf8 Class Initialized
INFO - 2023-11-01 08:17:13 --> URI Class Initialized
INFO - 2023-11-01 08:17:13 --> Router Class Initialized
INFO - 2023-11-01 08:17:13 --> Output Class Initialized
INFO - 2023-11-01 08:17:13 --> Security Class Initialized
DEBUG - 2023-11-01 08:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:17:13 --> Input Class Initialized
INFO - 2023-11-01 08:17:13 --> Language Class Initialized
ERROR - 2023-11-01 08:17:13 --> 404 Page Not Found: /index
INFO - 2023-11-01 08:17:13 --> Config Class Initialized
INFO - 2023-11-01 08:17:13 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:17:13 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:17:13 --> Utf8 Class Initialized
INFO - 2023-11-01 08:17:13 --> URI Class Initialized
INFO - 2023-11-01 08:17:13 --> Router Class Initialized
INFO - 2023-11-01 08:17:13 --> Output Class Initialized
INFO - 2023-11-01 08:17:13 --> Security Class Initialized
DEBUG - 2023-11-01 08:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:17:13 --> Input Class Initialized
INFO - 2023-11-01 08:17:13 --> Language Class Initialized
INFO - 2023-11-01 08:17:13 --> Language Class Initialized
INFO - 2023-11-01 08:17:13 --> Config Class Initialized
INFO - 2023-11-01 08:17:13 --> Loader Class Initialized
INFO - 2023-11-01 08:17:13 --> Helper loaded: url_helper
INFO - 2023-11-01 08:17:13 --> Helper loaded: file_helper
INFO - 2023-11-01 08:17:13 --> Helper loaded: form_helper
INFO - 2023-11-01 08:17:13 --> Helper loaded: my_helper
INFO - 2023-11-01 08:17:13 --> Database Driver Class Initialized
INFO - 2023-11-01 08:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:17:13 --> Controller Class Initialized
INFO - 2023-11-01 08:17:18 --> Config Class Initialized
INFO - 2023-11-01 08:17:18 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:17:18 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:17:18 --> Utf8 Class Initialized
INFO - 2023-11-01 08:17:18 --> URI Class Initialized
INFO - 2023-11-01 08:17:18 --> Router Class Initialized
INFO - 2023-11-01 08:17:18 --> Output Class Initialized
INFO - 2023-11-01 08:17:18 --> Security Class Initialized
DEBUG - 2023-11-01 08:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:17:18 --> Input Class Initialized
INFO - 2023-11-01 08:17:18 --> Language Class Initialized
INFO - 2023-11-01 08:17:18 --> Language Class Initialized
INFO - 2023-11-01 08:17:18 --> Config Class Initialized
INFO - 2023-11-01 08:17:18 --> Loader Class Initialized
INFO - 2023-11-01 08:17:18 --> Helper loaded: url_helper
INFO - 2023-11-01 08:17:18 --> Helper loaded: file_helper
INFO - 2023-11-01 08:17:18 --> Helper loaded: form_helper
INFO - 2023-11-01 08:17:18 --> Helper loaded: my_helper
INFO - 2023-11-01 08:17:19 --> Database Driver Class Initialized
INFO - 2023-11-01 08:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:17:19 --> Controller Class Initialized
INFO - 2023-11-01 08:17:19 --> Helper loaded: cookie_helper
INFO - 2023-11-01 08:17:19 --> Config Class Initialized
INFO - 2023-11-01 08:17:19 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:17:19 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:17:19 --> Utf8 Class Initialized
INFO - 2023-11-01 08:17:19 --> URI Class Initialized
INFO - 2023-11-01 08:17:19 --> Router Class Initialized
INFO - 2023-11-01 08:17:19 --> Output Class Initialized
INFO - 2023-11-01 08:17:19 --> Security Class Initialized
DEBUG - 2023-11-01 08:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:17:19 --> Input Class Initialized
INFO - 2023-11-01 08:17:19 --> Language Class Initialized
INFO - 2023-11-01 08:17:19 --> Language Class Initialized
INFO - 2023-11-01 08:17:19 --> Config Class Initialized
INFO - 2023-11-01 08:17:19 --> Loader Class Initialized
INFO - 2023-11-01 08:17:19 --> Helper loaded: url_helper
INFO - 2023-11-01 08:17:19 --> Helper loaded: file_helper
INFO - 2023-11-01 08:17:19 --> Helper loaded: form_helper
INFO - 2023-11-01 08:17:19 --> Helper loaded: my_helper
INFO - 2023-11-01 08:17:19 --> Database Driver Class Initialized
INFO - 2023-11-01 08:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:17:19 --> Controller Class Initialized
INFO - 2023-11-01 08:17:19 --> Config Class Initialized
INFO - 2023-11-01 08:17:19 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:17:19 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:17:19 --> Utf8 Class Initialized
INFO - 2023-11-01 08:17:19 --> URI Class Initialized
INFO - 2023-11-01 08:17:19 --> Router Class Initialized
INFO - 2023-11-01 08:17:19 --> Output Class Initialized
INFO - 2023-11-01 08:17:19 --> Security Class Initialized
DEBUG - 2023-11-01 08:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:17:19 --> Input Class Initialized
INFO - 2023-11-01 08:17:19 --> Language Class Initialized
INFO - 2023-11-01 08:17:19 --> Language Class Initialized
INFO - 2023-11-01 08:17:19 --> Config Class Initialized
INFO - 2023-11-01 08:17:19 --> Loader Class Initialized
INFO - 2023-11-01 08:17:19 --> Helper loaded: url_helper
INFO - 2023-11-01 08:17:19 --> Helper loaded: file_helper
INFO - 2023-11-01 08:17:19 --> Helper loaded: form_helper
INFO - 2023-11-01 08:17:19 --> Helper loaded: my_helper
INFO - 2023-11-01 08:17:19 --> Database Driver Class Initialized
INFO - 2023-11-01 08:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:17:19 --> Controller Class Initialized
DEBUG - 2023-11-01 08:17:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-01 08:17:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-01 08:17:19 --> Final output sent to browser
DEBUG - 2023-11-01 08:17:19 --> Total execution time: 0.0417
INFO - 2023-11-01 08:17:23 --> Config Class Initialized
INFO - 2023-11-01 08:17:23 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:17:23 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:17:23 --> Utf8 Class Initialized
INFO - 2023-11-01 08:17:23 --> URI Class Initialized
INFO - 2023-11-01 08:17:23 --> Router Class Initialized
INFO - 2023-11-01 08:17:23 --> Output Class Initialized
INFO - 2023-11-01 08:17:23 --> Security Class Initialized
DEBUG - 2023-11-01 08:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:17:23 --> Input Class Initialized
INFO - 2023-11-01 08:17:23 --> Language Class Initialized
INFO - 2023-11-01 08:17:23 --> Language Class Initialized
INFO - 2023-11-01 08:17:23 --> Config Class Initialized
INFO - 2023-11-01 08:17:23 --> Loader Class Initialized
INFO - 2023-11-01 08:17:23 --> Helper loaded: url_helper
INFO - 2023-11-01 08:17:23 --> Helper loaded: file_helper
INFO - 2023-11-01 08:17:23 --> Helper loaded: form_helper
INFO - 2023-11-01 08:17:23 --> Helper loaded: my_helper
INFO - 2023-11-01 08:17:23 --> Database Driver Class Initialized
INFO - 2023-11-01 08:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:17:23 --> Controller Class Initialized
INFO - 2023-11-01 08:17:23 --> Helper loaded: cookie_helper
INFO - 2023-11-01 08:17:23 --> Final output sent to browser
DEBUG - 2023-11-01 08:17:23 --> Total execution time: 0.0395
INFO - 2023-11-01 08:17:23 --> Config Class Initialized
INFO - 2023-11-01 08:17:23 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:17:23 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:17:23 --> Utf8 Class Initialized
INFO - 2023-11-01 08:17:23 --> URI Class Initialized
INFO - 2023-11-01 08:17:23 --> Router Class Initialized
INFO - 2023-11-01 08:17:23 --> Output Class Initialized
INFO - 2023-11-01 08:17:23 --> Security Class Initialized
DEBUG - 2023-11-01 08:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:17:23 --> Input Class Initialized
INFO - 2023-11-01 08:17:23 --> Language Class Initialized
INFO - 2023-11-01 08:17:23 --> Language Class Initialized
INFO - 2023-11-01 08:17:23 --> Config Class Initialized
INFO - 2023-11-01 08:17:23 --> Loader Class Initialized
INFO - 2023-11-01 08:17:23 --> Helper loaded: url_helper
INFO - 2023-11-01 08:17:23 --> Helper loaded: file_helper
INFO - 2023-11-01 08:17:23 --> Helper loaded: form_helper
INFO - 2023-11-01 08:17:23 --> Helper loaded: my_helper
INFO - 2023-11-01 08:17:23 --> Database Driver Class Initialized
INFO - 2023-11-01 08:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:17:23 --> Controller Class Initialized
DEBUG - 2023-11-01 08:17:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-01 08:17:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-01 08:17:23 --> Final output sent to browser
DEBUG - 2023-11-01 08:17:23 --> Total execution time: 0.0346
INFO - 2023-11-01 08:17:48 --> Config Class Initialized
INFO - 2023-11-01 08:17:48 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:17:48 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:17:48 --> Utf8 Class Initialized
INFO - 2023-11-01 08:17:48 --> URI Class Initialized
INFO - 2023-11-01 08:17:48 --> Router Class Initialized
INFO - 2023-11-01 08:17:48 --> Output Class Initialized
INFO - 2023-11-01 08:17:48 --> Security Class Initialized
DEBUG - 2023-11-01 08:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:17:48 --> Input Class Initialized
INFO - 2023-11-01 08:17:48 --> Language Class Initialized
INFO - 2023-11-01 08:17:48 --> Language Class Initialized
INFO - 2023-11-01 08:17:48 --> Config Class Initialized
INFO - 2023-11-01 08:17:48 --> Loader Class Initialized
INFO - 2023-11-01 08:17:48 --> Helper loaded: url_helper
INFO - 2023-11-01 08:17:48 --> Helper loaded: file_helper
INFO - 2023-11-01 08:17:48 --> Helper loaded: form_helper
INFO - 2023-11-01 08:17:48 --> Helper loaded: my_helper
INFO - 2023-11-01 08:17:48 --> Database Driver Class Initialized
INFO - 2023-11-01 08:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:17:48 --> Controller Class Initialized
INFO - 2023-11-01 08:17:48 --> Helper loaded: cookie_helper
INFO - 2023-11-01 08:17:48 --> Config Class Initialized
INFO - 2023-11-01 08:17:48 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:17:48 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:17:48 --> Utf8 Class Initialized
INFO - 2023-11-01 08:17:48 --> URI Class Initialized
INFO - 2023-11-01 08:17:48 --> Router Class Initialized
INFO - 2023-11-01 08:17:48 --> Output Class Initialized
INFO - 2023-11-01 08:17:48 --> Security Class Initialized
DEBUG - 2023-11-01 08:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:17:48 --> Input Class Initialized
INFO - 2023-11-01 08:17:48 --> Language Class Initialized
INFO - 2023-11-01 08:17:48 --> Language Class Initialized
INFO - 2023-11-01 08:17:48 --> Config Class Initialized
INFO - 2023-11-01 08:17:48 --> Loader Class Initialized
INFO - 2023-11-01 08:17:48 --> Helper loaded: url_helper
INFO - 2023-11-01 08:17:48 --> Helper loaded: file_helper
INFO - 2023-11-01 08:17:48 --> Helper loaded: form_helper
INFO - 2023-11-01 08:17:48 --> Helper loaded: my_helper
INFO - 2023-11-01 08:17:48 --> Database Driver Class Initialized
INFO - 2023-11-01 08:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:17:48 --> Controller Class Initialized
INFO - 2023-11-01 08:17:48 --> Config Class Initialized
INFO - 2023-11-01 08:17:48 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:17:48 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:17:48 --> Utf8 Class Initialized
INFO - 2023-11-01 08:17:48 --> URI Class Initialized
INFO - 2023-11-01 08:17:48 --> Router Class Initialized
INFO - 2023-11-01 08:17:48 --> Output Class Initialized
INFO - 2023-11-01 08:17:48 --> Security Class Initialized
DEBUG - 2023-11-01 08:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:17:48 --> Input Class Initialized
INFO - 2023-11-01 08:17:48 --> Language Class Initialized
INFO - 2023-11-01 08:17:48 --> Language Class Initialized
INFO - 2023-11-01 08:17:48 --> Config Class Initialized
INFO - 2023-11-01 08:17:48 --> Loader Class Initialized
INFO - 2023-11-01 08:17:48 --> Helper loaded: url_helper
INFO - 2023-11-01 08:17:48 --> Helper loaded: file_helper
INFO - 2023-11-01 08:17:48 --> Helper loaded: form_helper
INFO - 2023-11-01 08:17:48 --> Helper loaded: my_helper
INFO - 2023-11-01 08:17:48 --> Database Driver Class Initialized
INFO - 2023-11-01 08:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:17:48 --> Controller Class Initialized
DEBUG - 2023-11-01 08:17:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-01 08:17:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-01 08:17:48 --> Final output sent to browser
DEBUG - 2023-11-01 08:17:48 --> Total execution time: 0.0343
INFO - 2023-11-01 08:17:53 --> Config Class Initialized
INFO - 2023-11-01 08:17:53 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:17:53 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:17:53 --> Utf8 Class Initialized
INFO - 2023-11-01 08:17:53 --> URI Class Initialized
INFO - 2023-11-01 08:17:53 --> Router Class Initialized
INFO - 2023-11-01 08:17:53 --> Output Class Initialized
INFO - 2023-11-01 08:17:53 --> Security Class Initialized
DEBUG - 2023-11-01 08:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:17:53 --> Input Class Initialized
INFO - 2023-11-01 08:17:53 --> Language Class Initialized
INFO - 2023-11-01 08:17:53 --> Language Class Initialized
INFO - 2023-11-01 08:17:53 --> Config Class Initialized
INFO - 2023-11-01 08:17:53 --> Loader Class Initialized
INFO - 2023-11-01 08:17:53 --> Helper loaded: url_helper
INFO - 2023-11-01 08:17:53 --> Helper loaded: file_helper
INFO - 2023-11-01 08:17:53 --> Helper loaded: form_helper
INFO - 2023-11-01 08:17:53 --> Helper loaded: my_helper
INFO - 2023-11-01 08:17:53 --> Database Driver Class Initialized
INFO - 2023-11-01 08:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:17:53 --> Controller Class Initialized
INFO - 2023-11-01 08:17:53 --> Helper loaded: cookie_helper
INFO - 2023-11-01 08:17:53 --> Final output sent to browser
DEBUG - 2023-11-01 08:17:53 --> Total execution time: 0.0393
INFO - 2023-11-01 08:17:53 --> Config Class Initialized
INFO - 2023-11-01 08:17:53 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:17:53 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:17:53 --> Utf8 Class Initialized
INFO - 2023-11-01 08:17:53 --> URI Class Initialized
INFO - 2023-11-01 08:17:53 --> Router Class Initialized
INFO - 2023-11-01 08:17:53 --> Output Class Initialized
INFO - 2023-11-01 08:17:53 --> Security Class Initialized
DEBUG - 2023-11-01 08:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:17:53 --> Input Class Initialized
INFO - 2023-11-01 08:17:53 --> Language Class Initialized
INFO - 2023-11-01 08:17:53 --> Language Class Initialized
INFO - 2023-11-01 08:17:53 --> Config Class Initialized
INFO - 2023-11-01 08:17:53 --> Loader Class Initialized
INFO - 2023-11-01 08:17:53 --> Helper loaded: url_helper
INFO - 2023-11-01 08:17:53 --> Helper loaded: file_helper
INFO - 2023-11-01 08:17:53 --> Helper loaded: form_helper
INFO - 2023-11-01 08:17:53 --> Helper loaded: my_helper
INFO - 2023-11-01 08:17:53 --> Database Driver Class Initialized
INFO - 2023-11-01 08:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:17:53 --> Controller Class Initialized
DEBUG - 2023-11-01 08:17:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-11-01 08:17:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-01 08:17:53 --> Final output sent to browser
DEBUG - 2023-11-01 08:17:53 --> Total execution time: 0.0336
INFO - 2023-11-01 08:19:09 --> Config Class Initialized
INFO - 2023-11-01 08:19:09 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:19:09 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:19:09 --> Utf8 Class Initialized
INFO - 2023-11-01 08:19:09 --> URI Class Initialized
DEBUG - 2023-11-01 08:19:09 --> No URI present. Default controller set.
INFO - 2023-11-01 08:19:09 --> Router Class Initialized
INFO - 2023-11-01 08:19:09 --> Output Class Initialized
INFO - 2023-11-01 08:19:09 --> Security Class Initialized
DEBUG - 2023-11-01 08:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:19:09 --> Input Class Initialized
INFO - 2023-11-01 08:19:09 --> Language Class Initialized
INFO - 2023-11-01 08:19:09 --> Language Class Initialized
INFO - 2023-11-01 08:19:09 --> Config Class Initialized
INFO - 2023-11-01 08:19:09 --> Loader Class Initialized
INFO - 2023-11-01 08:19:09 --> Helper loaded: url_helper
INFO - 2023-11-01 08:19:09 --> Helper loaded: file_helper
INFO - 2023-11-01 08:19:09 --> Helper loaded: form_helper
INFO - 2023-11-01 08:19:09 --> Helper loaded: my_helper
INFO - 2023-11-01 08:19:09 --> Database Driver Class Initialized
INFO - 2023-11-01 08:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:19:09 --> Controller Class Initialized
INFO - 2023-11-01 08:19:09 --> Config Class Initialized
INFO - 2023-11-01 08:19:09 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:19:09 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:19:09 --> Utf8 Class Initialized
INFO - 2023-11-01 08:19:09 --> URI Class Initialized
INFO - 2023-11-01 08:19:09 --> Router Class Initialized
INFO - 2023-11-01 08:19:09 --> Output Class Initialized
INFO - 2023-11-01 08:19:09 --> Security Class Initialized
DEBUG - 2023-11-01 08:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:19:09 --> Input Class Initialized
INFO - 2023-11-01 08:19:09 --> Language Class Initialized
INFO - 2023-11-01 08:19:09 --> Language Class Initialized
INFO - 2023-11-01 08:19:09 --> Config Class Initialized
INFO - 2023-11-01 08:19:09 --> Loader Class Initialized
INFO - 2023-11-01 08:19:09 --> Helper loaded: url_helper
INFO - 2023-11-01 08:19:09 --> Helper loaded: file_helper
INFO - 2023-11-01 08:19:09 --> Helper loaded: form_helper
INFO - 2023-11-01 08:19:09 --> Helper loaded: my_helper
INFO - 2023-11-01 08:19:09 --> Database Driver Class Initialized
INFO - 2023-11-01 08:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:19:09 --> Controller Class Initialized
DEBUG - 2023-11-01 08:19:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-01 08:19:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-01 08:19:09 --> Final output sent to browser
DEBUG - 2023-11-01 08:19:09 --> Total execution time: 0.0439
INFO - 2023-11-01 08:19:15 --> Config Class Initialized
INFO - 2023-11-01 08:19:15 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:19:15 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:19:15 --> Utf8 Class Initialized
INFO - 2023-11-01 08:19:15 --> URI Class Initialized
INFO - 2023-11-01 08:19:15 --> Router Class Initialized
INFO - 2023-11-01 08:19:15 --> Output Class Initialized
INFO - 2023-11-01 08:19:15 --> Security Class Initialized
DEBUG - 2023-11-01 08:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:19:15 --> Input Class Initialized
INFO - 2023-11-01 08:19:15 --> Language Class Initialized
INFO - 2023-11-01 08:19:15 --> Language Class Initialized
INFO - 2023-11-01 08:19:15 --> Config Class Initialized
INFO - 2023-11-01 08:19:15 --> Loader Class Initialized
INFO - 2023-11-01 08:19:15 --> Helper loaded: url_helper
INFO - 2023-11-01 08:19:15 --> Helper loaded: file_helper
INFO - 2023-11-01 08:19:15 --> Helper loaded: form_helper
INFO - 2023-11-01 08:19:15 --> Helper loaded: my_helper
INFO - 2023-11-01 08:19:15 --> Database Driver Class Initialized
INFO - 2023-11-01 08:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:19:15 --> Controller Class Initialized
INFO - 2023-11-01 08:19:15 --> Helper loaded: cookie_helper
INFO - 2023-11-01 08:19:15 --> Final output sent to browser
DEBUG - 2023-11-01 08:19:15 --> Total execution time: 0.0364
INFO - 2023-11-01 08:19:15 --> Config Class Initialized
INFO - 2023-11-01 08:19:15 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:19:15 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:19:15 --> Utf8 Class Initialized
INFO - 2023-11-01 08:19:15 --> URI Class Initialized
INFO - 2023-11-01 08:19:15 --> Router Class Initialized
INFO - 2023-11-01 08:19:15 --> Output Class Initialized
INFO - 2023-11-01 08:19:15 --> Security Class Initialized
DEBUG - 2023-11-01 08:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:19:15 --> Input Class Initialized
INFO - 2023-11-01 08:19:15 --> Language Class Initialized
INFO - 2023-11-01 08:19:15 --> Language Class Initialized
INFO - 2023-11-01 08:19:15 --> Config Class Initialized
INFO - 2023-11-01 08:19:15 --> Loader Class Initialized
INFO - 2023-11-01 08:19:15 --> Helper loaded: url_helper
INFO - 2023-11-01 08:19:15 --> Helper loaded: file_helper
INFO - 2023-11-01 08:19:15 --> Helper loaded: form_helper
INFO - 2023-11-01 08:19:15 --> Helper loaded: my_helper
INFO - 2023-11-01 08:19:15 --> Database Driver Class Initialized
INFO - 2023-11-01 08:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:19:15 --> Controller Class Initialized
DEBUG - 2023-11-01 08:19:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-11-01 08:19:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-01 08:19:15 --> Final output sent to browser
DEBUG - 2023-11-01 08:19:15 --> Total execution time: 0.0467
INFO - 2023-11-01 08:19:19 --> Config Class Initialized
INFO - 2023-11-01 08:19:19 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:19:19 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:19:19 --> Utf8 Class Initialized
INFO - 2023-11-01 08:19:19 --> URI Class Initialized
INFO - 2023-11-01 08:19:19 --> Router Class Initialized
INFO - 2023-11-01 08:19:19 --> Output Class Initialized
INFO - 2023-11-01 08:19:19 --> Security Class Initialized
DEBUG - 2023-11-01 08:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:19:19 --> Input Class Initialized
INFO - 2023-11-01 08:19:19 --> Language Class Initialized
INFO - 2023-11-01 08:19:19 --> Language Class Initialized
INFO - 2023-11-01 08:19:19 --> Config Class Initialized
INFO - 2023-11-01 08:19:19 --> Loader Class Initialized
INFO - 2023-11-01 08:19:19 --> Helper loaded: url_helper
INFO - 2023-11-01 08:19:19 --> Helper loaded: file_helper
INFO - 2023-11-01 08:19:19 --> Helper loaded: form_helper
INFO - 2023-11-01 08:19:19 --> Helper loaded: my_helper
INFO - 2023-11-01 08:19:19 --> Database Driver Class Initialized
INFO - 2023-11-01 08:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:19:19 --> Controller Class Initialized
DEBUG - 2023-11-01 08:19:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_walikelas/views/list.php
DEBUG - 2023-11-01 08:19:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-01 08:19:19 --> Final output sent to browser
DEBUG - 2023-11-01 08:19:19 --> Total execution time: 0.0465
INFO - 2023-11-01 08:19:19 --> Config Class Initialized
INFO - 2023-11-01 08:19:19 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:19:19 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:19:19 --> Utf8 Class Initialized
INFO - 2023-11-01 08:19:19 --> URI Class Initialized
INFO - 2023-11-01 08:19:19 --> Router Class Initialized
INFO - 2023-11-01 08:19:19 --> Output Class Initialized
INFO - 2023-11-01 08:19:19 --> Security Class Initialized
DEBUG - 2023-11-01 08:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:19:19 --> Input Class Initialized
INFO - 2023-11-01 08:19:19 --> Language Class Initialized
ERROR - 2023-11-01 08:19:19 --> 404 Page Not Found: /index
INFO - 2023-11-01 08:19:19 --> Config Class Initialized
INFO - 2023-11-01 08:19:19 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:19:19 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:19:19 --> Utf8 Class Initialized
INFO - 2023-11-01 08:19:19 --> URI Class Initialized
INFO - 2023-11-01 08:19:19 --> Router Class Initialized
INFO - 2023-11-01 08:19:19 --> Output Class Initialized
INFO - 2023-11-01 08:19:19 --> Security Class Initialized
DEBUG - 2023-11-01 08:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:19:19 --> Input Class Initialized
INFO - 2023-11-01 08:19:19 --> Language Class Initialized
INFO - 2023-11-01 08:19:19 --> Language Class Initialized
INFO - 2023-11-01 08:19:19 --> Config Class Initialized
INFO - 2023-11-01 08:19:19 --> Loader Class Initialized
INFO - 2023-11-01 08:19:19 --> Helper loaded: url_helper
INFO - 2023-11-01 08:19:19 --> Helper loaded: file_helper
INFO - 2023-11-01 08:19:19 --> Helper loaded: form_helper
INFO - 2023-11-01 08:19:19 --> Helper loaded: my_helper
INFO - 2023-11-01 08:19:19 --> Database Driver Class Initialized
INFO - 2023-11-01 08:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:19:19 --> Controller Class Initialized
INFO - 2023-11-01 08:19:22 --> Config Class Initialized
INFO - 2023-11-01 08:19:22 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:19:22 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:19:22 --> Utf8 Class Initialized
INFO - 2023-11-01 08:19:22 --> URI Class Initialized
INFO - 2023-11-01 08:19:22 --> Router Class Initialized
INFO - 2023-11-01 08:19:22 --> Output Class Initialized
INFO - 2023-11-01 08:19:22 --> Security Class Initialized
DEBUG - 2023-11-01 08:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:19:22 --> Input Class Initialized
INFO - 2023-11-01 08:19:22 --> Language Class Initialized
INFO - 2023-11-01 08:19:22 --> Language Class Initialized
INFO - 2023-11-01 08:19:22 --> Config Class Initialized
INFO - 2023-11-01 08:19:22 --> Loader Class Initialized
INFO - 2023-11-01 08:19:22 --> Helper loaded: url_helper
INFO - 2023-11-01 08:19:22 --> Helper loaded: file_helper
INFO - 2023-11-01 08:19:22 --> Helper loaded: form_helper
INFO - 2023-11-01 08:19:22 --> Helper loaded: my_helper
INFO - 2023-11-01 08:19:22 --> Database Driver Class Initialized
INFO - 2023-11-01 08:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:19:22 --> Controller Class Initialized
INFO - 2023-11-01 08:19:22 --> Helper loaded: cookie_helper
INFO - 2023-11-01 08:19:22 --> Config Class Initialized
INFO - 2023-11-01 08:19:22 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:19:22 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:19:22 --> Utf8 Class Initialized
INFO - 2023-11-01 08:19:22 --> URI Class Initialized
INFO - 2023-11-01 08:19:22 --> Router Class Initialized
INFO - 2023-11-01 08:19:22 --> Output Class Initialized
INFO - 2023-11-01 08:19:22 --> Security Class Initialized
DEBUG - 2023-11-01 08:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:19:22 --> Input Class Initialized
INFO - 2023-11-01 08:19:22 --> Language Class Initialized
INFO - 2023-11-01 08:19:22 --> Language Class Initialized
INFO - 2023-11-01 08:19:22 --> Config Class Initialized
INFO - 2023-11-01 08:19:22 --> Loader Class Initialized
INFO - 2023-11-01 08:19:22 --> Helper loaded: url_helper
INFO - 2023-11-01 08:19:22 --> Helper loaded: file_helper
INFO - 2023-11-01 08:19:22 --> Helper loaded: form_helper
INFO - 2023-11-01 08:19:22 --> Helper loaded: my_helper
INFO - 2023-11-01 08:19:22 --> Database Driver Class Initialized
INFO - 2023-11-01 08:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:19:22 --> Controller Class Initialized
INFO - 2023-11-01 08:19:22 --> Config Class Initialized
INFO - 2023-11-01 08:19:22 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:19:22 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:19:22 --> Utf8 Class Initialized
INFO - 2023-11-01 08:19:22 --> URI Class Initialized
INFO - 2023-11-01 08:19:22 --> Router Class Initialized
INFO - 2023-11-01 08:19:22 --> Output Class Initialized
INFO - 2023-11-01 08:19:22 --> Security Class Initialized
DEBUG - 2023-11-01 08:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:19:22 --> Input Class Initialized
INFO - 2023-11-01 08:19:22 --> Language Class Initialized
INFO - 2023-11-01 08:19:22 --> Language Class Initialized
INFO - 2023-11-01 08:19:22 --> Config Class Initialized
INFO - 2023-11-01 08:19:22 --> Loader Class Initialized
INFO - 2023-11-01 08:19:22 --> Helper loaded: url_helper
INFO - 2023-11-01 08:19:22 --> Helper loaded: file_helper
INFO - 2023-11-01 08:19:22 --> Helper loaded: form_helper
INFO - 2023-11-01 08:19:22 --> Helper loaded: my_helper
INFO - 2023-11-01 08:19:22 --> Database Driver Class Initialized
INFO - 2023-11-01 08:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:19:22 --> Controller Class Initialized
DEBUG - 2023-11-01 08:19:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-01 08:19:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-01 08:19:22 --> Final output sent to browser
DEBUG - 2023-11-01 08:19:22 --> Total execution time: 0.0437
INFO - 2023-11-01 08:19:25 --> Config Class Initialized
INFO - 2023-11-01 08:19:25 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:19:25 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:19:25 --> Utf8 Class Initialized
INFO - 2023-11-01 08:19:25 --> URI Class Initialized
INFO - 2023-11-01 08:19:25 --> Router Class Initialized
INFO - 2023-11-01 08:19:25 --> Output Class Initialized
INFO - 2023-11-01 08:19:25 --> Security Class Initialized
DEBUG - 2023-11-01 08:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:19:25 --> Input Class Initialized
INFO - 2023-11-01 08:19:25 --> Language Class Initialized
INFO - 2023-11-01 08:19:25 --> Language Class Initialized
INFO - 2023-11-01 08:19:25 --> Config Class Initialized
INFO - 2023-11-01 08:19:25 --> Loader Class Initialized
INFO - 2023-11-01 08:19:25 --> Helper loaded: url_helper
INFO - 2023-11-01 08:19:25 --> Helper loaded: file_helper
INFO - 2023-11-01 08:19:25 --> Helper loaded: form_helper
INFO - 2023-11-01 08:19:25 --> Helper loaded: my_helper
INFO - 2023-11-01 08:19:25 --> Database Driver Class Initialized
INFO - 2023-11-01 08:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:19:25 --> Controller Class Initialized
INFO - 2023-11-01 08:19:25 --> Helper loaded: cookie_helper
INFO - 2023-11-01 08:19:25 --> Final output sent to browser
DEBUG - 2023-11-01 08:19:25 --> Total execution time: 0.0449
INFO - 2023-11-01 08:19:25 --> Config Class Initialized
INFO - 2023-11-01 08:19:25 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:19:25 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:19:25 --> Utf8 Class Initialized
INFO - 2023-11-01 08:19:25 --> URI Class Initialized
INFO - 2023-11-01 08:19:25 --> Router Class Initialized
INFO - 2023-11-01 08:19:25 --> Output Class Initialized
INFO - 2023-11-01 08:19:25 --> Security Class Initialized
DEBUG - 2023-11-01 08:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:19:25 --> Input Class Initialized
INFO - 2023-11-01 08:19:25 --> Language Class Initialized
INFO - 2023-11-01 08:19:26 --> Language Class Initialized
INFO - 2023-11-01 08:19:26 --> Config Class Initialized
INFO - 2023-11-01 08:19:26 --> Loader Class Initialized
INFO - 2023-11-01 08:19:26 --> Helper loaded: url_helper
INFO - 2023-11-01 08:19:26 --> Helper loaded: file_helper
INFO - 2023-11-01 08:19:26 --> Helper loaded: form_helper
INFO - 2023-11-01 08:19:26 --> Helper loaded: my_helper
INFO - 2023-11-01 08:19:26 --> Database Driver Class Initialized
INFO - 2023-11-01 08:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:19:26 --> Controller Class Initialized
DEBUG - 2023-11-01 08:19:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-01 08:19:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-01 08:19:26 --> Final output sent to browser
DEBUG - 2023-11-01 08:19:26 --> Total execution time: 0.0414
INFO - 2023-11-01 08:19:29 --> Config Class Initialized
INFO - 2023-11-01 08:19:29 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:19:29 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:19:29 --> Utf8 Class Initialized
INFO - 2023-11-01 08:19:29 --> URI Class Initialized
INFO - 2023-11-01 08:19:29 --> Router Class Initialized
INFO - 2023-11-01 08:19:29 --> Output Class Initialized
INFO - 2023-11-01 08:19:29 --> Security Class Initialized
DEBUG - 2023-11-01 08:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:19:29 --> Input Class Initialized
INFO - 2023-11-01 08:19:29 --> Language Class Initialized
INFO - 2023-11-01 08:19:29 --> Language Class Initialized
INFO - 2023-11-01 08:19:29 --> Config Class Initialized
INFO - 2023-11-01 08:19:29 --> Loader Class Initialized
INFO - 2023-11-01 08:19:29 --> Helper loaded: url_helper
INFO - 2023-11-01 08:19:29 --> Helper loaded: file_helper
INFO - 2023-11-01 08:19:29 --> Helper loaded: form_helper
INFO - 2023-11-01 08:19:29 --> Helper loaded: my_helper
INFO - 2023-11-01 08:19:29 --> Database Driver Class Initialized
INFO - 2023-11-01 08:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:19:29 --> Controller Class Initialized
DEBUG - 2023-11-01 08:19:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2023-11-01 08:19:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-01 08:19:29 --> Final output sent to browser
DEBUG - 2023-11-01 08:19:29 --> Total execution time: 0.0464
INFO - 2023-11-01 08:19:30 --> Config Class Initialized
INFO - 2023-11-01 08:19:30 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:19:30 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:19:30 --> Utf8 Class Initialized
INFO - 2023-11-01 08:19:30 --> URI Class Initialized
INFO - 2023-11-01 08:19:30 --> Router Class Initialized
INFO - 2023-11-01 08:19:30 --> Output Class Initialized
INFO - 2023-11-01 08:19:30 --> Security Class Initialized
DEBUG - 2023-11-01 08:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:19:30 --> Input Class Initialized
INFO - 2023-11-01 08:19:30 --> Language Class Initialized
INFO - 2023-11-01 08:19:30 --> Language Class Initialized
INFO - 2023-11-01 08:19:30 --> Config Class Initialized
INFO - 2023-11-01 08:19:30 --> Loader Class Initialized
INFO - 2023-11-01 08:19:30 --> Helper loaded: url_helper
INFO - 2023-11-01 08:19:30 --> Helper loaded: file_helper
INFO - 2023-11-01 08:19:30 --> Helper loaded: form_helper
INFO - 2023-11-01 08:19:30 --> Helper loaded: my_helper
INFO - 2023-11-01 08:19:30 --> Database Driver Class Initialized
INFO - 2023-11-01 08:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:19:30 --> Controller Class Initialized
DEBUG - 2023-11-01 08:19:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 08:19:34 --> Final output sent to browser
DEBUG - 2023-11-01 08:19:34 --> Total execution time: 3.6468
INFO - 2023-11-01 08:20:15 --> Config Class Initialized
INFO - 2023-11-01 08:20:15 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:20:15 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:20:15 --> Utf8 Class Initialized
INFO - 2023-11-01 08:20:15 --> URI Class Initialized
INFO - 2023-11-01 08:20:15 --> Router Class Initialized
INFO - 2023-11-01 08:20:15 --> Output Class Initialized
INFO - 2023-11-01 08:20:15 --> Security Class Initialized
DEBUG - 2023-11-01 08:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:20:15 --> Input Class Initialized
INFO - 2023-11-01 08:20:15 --> Language Class Initialized
INFO - 2023-11-01 08:20:15 --> Language Class Initialized
INFO - 2023-11-01 08:20:15 --> Config Class Initialized
INFO - 2023-11-01 08:20:15 --> Loader Class Initialized
INFO - 2023-11-01 08:20:15 --> Helper loaded: url_helper
INFO - 2023-11-01 08:20:15 --> Helper loaded: file_helper
INFO - 2023-11-01 08:20:15 --> Helper loaded: form_helper
INFO - 2023-11-01 08:20:15 --> Helper loaded: my_helper
INFO - 2023-11-01 08:20:15 --> Database Driver Class Initialized
INFO - 2023-11-01 08:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:20:15 --> Controller Class Initialized
DEBUG - 2023-11-01 08:20:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 08:20:19 --> Final output sent to browser
DEBUG - 2023-11-01 08:20:19 --> Total execution time: 3.6564
INFO - 2023-11-01 08:22:05 --> Config Class Initialized
INFO - 2023-11-01 08:22:05 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:22:06 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:22:06 --> Utf8 Class Initialized
INFO - 2023-11-01 08:22:06 --> URI Class Initialized
INFO - 2023-11-01 08:22:06 --> Router Class Initialized
INFO - 2023-11-01 08:22:06 --> Output Class Initialized
INFO - 2023-11-01 08:22:06 --> Security Class Initialized
DEBUG - 2023-11-01 08:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:22:06 --> Input Class Initialized
INFO - 2023-11-01 08:22:06 --> Language Class Initialized
INFO - 2023-11-01 08:22:06 --> Language Class Initialized
INFO - 2023-11-01 08:22:06 --> Config Class Initialized
INFO - 2023-11-01 08:22:06 --> Loader Class Initialized
INFO - 2023-11-01 08:22:06 --> Helper loaded: url_helper
INFO - 2023-11-01 08:22:06 --> Helper loaded: file_helper
INFO - 2023-11-01 08:22:06 --> Helper loaded: form_helper
INFO - 2023-11-01 08:22:06 --> Helper loaded: my_helper
INFO - 2023-11-01 08:22:06 --> Database Driver Class Initialized
INFO - 2023-11-01 08:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:22:06 --> Controller Class Initialized
INFO - 2023-11-01 08:22:06 --> Helper loaded: cookie_helper
INFO - 2023-11-01 08:22:06 --> Config Class Initialized
INFO - 2023-11-01 08:22:06 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:22:06 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:22:06 --> Utf8 Class Initialized
INFO - 2023-11-01 08:22:06 --> URI Class Initialized
INFO - 2023-11-01 08:22:06 --> Router Class Initialized
INFO - 2023-11-01 08:22:06 --> Output Class Initialized
INFO - 2023-11-01 08:22:06 --> Security Class Initialized
DEBUG - 2023-11-01 08:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:22:06 --> Input Class Initialized
INFO - 2023-11-01 08:22:06 --> Language Class Initialized
INFO - 2023-11-01 08:22:06 --> Language Class Initialized
INFO - 2023-11-01 08:22:06 --> Config Class Initialized
INFO - 2023-11-01 08:22:06 --> Loader Class Initialized
INFO - 2023-11-01 08:22:06 --> Helper loaded: url_helper
INFO - 2023-11-01 08:22:06 --> Helper loaded: file_helper
INFO - 2023-11-01 08:22:06 --> Helper loaded: form_helper
INFO - 2023-11-01 08:22:06 --> Helper loaded: my_helper
INFO - 2023-11-01 08:22:06 --> Database Driver Class Initialized
INFO - 2023-11-01 08:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:22:06 --> Controller Class Initialized
INFO - 2023-11-01 08:22:06 --> Config Class Initialized
INFO - 2023-11-01 08:22:06 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:22:06 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:22:06 --> Utf8 Class Initialized
INFO - 2023-11-01 08:22:06 --> URI Class Initialized
INFO - 2023-11-01 08:22:06 --> Router Class Initialized
INFO - 2023-11-01 08:22:06 --> Output Class Initialized
INFO - 2023-11-01 08:22:06 --> Security Class Initialized
DEBUG - 2023-11-01 08:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:22:06 --> Input Class Initialized
INFO - 2023-11-01 08:22:06 --> Language Class Initialized
INFO - 2023-11-01 08:22:06 --> Language Class Initialized
INFO - 2023-11-01 08:22:06 --> Config Class Initialized
INFO - 2023-11-01 08:22:06 --> Loader Class Initialized
INFO - 2023-11-01 08:22:06 --> Helper loaded: url_helper
INFO - 2023-11-01 08:22:06 --> Helper loaded: file_helper
INFO - 2023-11-01 08:22:06 --> Helper loaded: form_helper
INFO - 2023-11-01 08:22:06 --> Helper loaded: my_helper
INFO - 2023-11-01 08:22:06 --> Database Driver Class Initialized
INFO - 2023-11-01 08:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:22:06 --> Controller Class Initialized
DEBUG - 2023-11-01 08:22:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-01 08:22:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-01 08:22:06 --> Final output sent to browser
DEBUG - 2023-11-01 08:22:06 --> Total execution time: 0.0671
INFO - 2023-11-01 08:22:10 --> Config Class Initialized
INFO - 2023-11-01 08:22:10 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:22:10 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:22:10 --> Utf8 Class Initialized
INFO - 2023-11-01 08:22:10 --> URI Class Initialized
INFO - 2023-11-01 08:22:10 --> Router Class Initialized
INFO - 2023-11-01 08:22:10 --> Output Class Initialized
INFO - 2023-11-01 08:22:10 --> Security Class Initialized
DEBUG - 2023-11-01 08:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:22:10 --> Input Class Initialized
INFO - 2023-11-01 08:22:10 --> Language Class Initialized
INFO - 2023-11-01 08:22:10 --> Language Class Initialized
INFO - 2023-11-01 08:22:10 --> Config Class Initialized
INFO - 2023-11-01 08:22:10 --> Loader Class Initialized
INFO - 2023-11-01 08:22:10 --> Helper loaded: url_helper
INFO - 2023-11-01 08:22:10 --> Helper loaded: file_helper
INFO - 2023-11-01 08:22:10 --> Helper loaded: form_helper
INFO - 2023-11-01 08:22:10 --> Helper loaded: my_helper
INFO - 2023-11-01 08:22:10 --> Database Driver Class Initialized
INFO - 2023-11-01 08:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:22:10 --> Controller Class Initialized
INFO - 2023-11-01 08:22:10 --> Helper loaded: cookie_helper
INFO - 2023-11-01 08:22:10 --> Final output sent to browser
DEBUG - 2023-11-01 08:22:10 --> Total execution time: 0.0379
INFO - 2023-11-01 08:22:10 --> Config Class Initialized
INFO - 2023-11-01 08:22:10 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:22:10 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:22:10 --> Utf8 Class Initialized
INFO - 2023-11-01 08:22:10 --> URI Class Initialized
INFO - 2023-11-01 08:22:10 --> Router Class Initialized
INFO - 2023-11-01 08:22:10 --> Output Class Initialized
INFO - 2023-11-01 08:22:10 --> Security Class Initialized
DEBUG - 2023-11-01 08:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:22:10 --> Input Class Initialized
INFO - 2023-11-01 08:22:10 --> Language Class Initialized
INFO - 2023-11-01 08:22:10 --> Language Class Initialized
INFO - 2023-11-01 08:22:10 --> Config Class Initialized
INFO - 2023-11-01 08:22:10 --> Loader Class Initialized
INFO - 2023-11-01 08:22:10 --> Helper loaded: url_helper
INFO - 2023-11-01 08:22:10 --> Helper loaded: file_helper
INFO - 2023-11-01 08:22:10 --> Helper loaded: form_helper
INFO - 2023-11-01 08:22:10 --> Helper loaded: my_helper
INFO - 2023-11-01 08:22:10 --> Database Driver Class Initialized
INFO - 2023-11-01 08:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:22:10 --> Controller Class Initialized
DEBUG - 2023-11-01 08:22:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-01 08:22:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-01 08:22:10 --> Final output sent to browser
DEBUG - 2023-11-01 08:22:10 --> Total execution time: 0.0354
INFO - 2023-11-01 08:22:17 --> Config Class Initialized
INFO - 2023-11-01 08:22:17 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:22:17 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:22:17 --> Utf8 Class Initialized
INFO - 2023-11-01 08:22:17 --> URI Class Initialized
INFO - 2023-11-01 08:22:17 --> Router Class Initialized
INFO - 2023-11-01 08:22:17 --> Output Class Initialized
INFO - 2023-11-01 08:22:17 --> Security Class Initialized
DEBUG - 2023-11-01 08:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:22:17 --> Input Class Initialized
INFO - 2023-11-01 08:22:17 --> Language Class Initialized
INFO - 2023-11-01 08:22:17 --> Language Class Initialized
INFO - 2023-11-01 08:22:17 --> Config Class Initialized
INFO - 2023-11-01 08:22:17 --> Loader Class Initialized
INFO - 2023-11-01 08:22:17 --> Helper loaded: url_helper
INFO - 2023-11-01 08:22:17 --> Helper loaded: file_helper
INFO - 2023-11-01 08:22:17 --> Helper loaded: form_helper
INFO - 2023-11-01 08:22:17 --> Helper loaded: my_helper
INFO - 2023-11-01 08:22:17 --> Database Driver Class Initialized
INFO - 2023-11-01 08:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:22:17 --> Controller Class Initialized
DEBUG - 2023-11-01 08:22:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2023-11-01 08:22:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-01 08:22:17 --> Final output sent to browser
DEBUG - 2023-11-01 08:22:17 --> Total execution time: 0.0784
INFO - 2023-11-01 08:22:18 --> Config Class Initialized
INFO - 2023-11-01 08:22:18 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:22:18 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:22:18 --> Utf8 Class Initialized
INFO - 2023-11-01 08:22:18 --> URI Class Initialized
INFO - 2023-11-01 08:22:18 --> Router Class Initialized
INFO - 2023-11-01 08:22:18 --> Output Class Initialized
INFO - 2023-11-01 08:22:18 --> Security Class Initialized
DEBUG - 2023-11-01 08:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:22:18 --> Input Class Initialized
INFO - 2023-11-01 08:22:18 --> Language Class Initialized
INFO - 2023-11-01 08:22:18 --> Language Class Initialized
INFO - 2023-11-01 08:22:18 --> Config Class Initialized
INFO - 2023-11-01 08:22:18 --> Loader Class Initialized
INFO - 2023-11-01 08:22:18 --> Helper loaded: url_helper
INFO - 2023-11-01 08:22:18 --> Helper loaded: file_helper
INFO - 2023-11-01 08:22:18 --> Helper loaded: form_helper
INFO - 2023-11-01 08:22:18 --> Helper loaded: my_helper
INFO - 2023-11-01 08:22:18 --> Database Driver Class Initialized
INFO - 2023-11-01 08:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:22:18 --> Controller Class Initialized
DEBUG - 2023-11-01 08:22:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 08:22:22 --> Final output sent to browser
DEBUG - 2023-11-01 08:22:22 --> Total execution time: 3.7182
INFO - 2023-11-01 08:30:30 --> Config Class Initialized
INFO - 2023-11-01 08:30:30 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:30:30 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:30:30 --> Utf8 Class Initialized
INFO - 2023-11-01 08:30:30 --> URI Class Initialized
INFO - 2023-11-01 08:30:30 --> Router Class Initialized
INFO - 2023-11-01 08:30:30 --> Output Class Initialized
INFO - 2023-11-01 08:30:30 --> Security Class Initialized
DEBUG - 2023-11-01 08:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:30:30 --> Input Class Initialized
INFO - 2023-11-01 08:30:30 --> Language Class Initialized
INFO - 2023-11-01 08:30:30 --> Language Class Initialized
INFO - 2023-11-01 08:30:30 --> Config Class Initialized
INFO - 2023-11-01 08:30:30 --> Loader Class Initialized
INFO - 2023-11-01 08:30:30 --> Helper loaded: url_helper
INFO - 2023-11-01 08:30:30 --> Helper loaded: file_helper
INFO - 2023-11-01 08:30:30 --> Helper loaded: form_helper
INFO - 2023-11-01 08:30:30 --> Helper loaded: my_helper
INFO - 2023-11-01 08:30:30 --> Database Driver Class Initialized
INFO - 2023-11-01 08:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:30:30 --> Controller Class Initialized
DEBUG - 2023-11-01 08:30:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 08:30:33 --> Final output sent to browser
DEBUG - 2023-11-01 08:30:33 --> Total execution time: 3.4673
INFO - 2023-11-01 08:31:04 --> Config Class Initialized
INFO - 2023-11-01 08:31:04 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:31:04 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:31:04 --> Utf8 Class Initialized
INFO - 2023-11-01 08:31:04 --> URI Class Initialized
INFO - 2023-11-01 08:31:04 --> Router Class Initialized
INFO - 2023-11-01 08:31:04 --> Output Class Initialized
INFO - 2023-11-01 08:31:04 --> Security Class Initialized
DEBUG - 2023-11-01 08:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:31:04 --> Input Class Initialized
INFO - 2023-11-01 08:31:04 --> Language Class Initialized
INFO - 2023-11-01 08:31:04 --> Language Class Initialized
INFO - 2023-11-01 08:31:04 --> Config Class Initialized
INFO - 2023-11-01 08:31:04 --> Loader Class Initialized
INFO - 2023-11-01 08:31:04 --> Helper loaded: url_helper
INFO - 2023-11-01 08:31:04 --> Helper loaded: file_helper
INFO - 2023-11-01 08:31:04 --> Helper loaded: form_helper
INFO - 2023-11-01 08:31:04 --> Helper loaded: my_helper
INFO - 2023-11-01 08:31:04 --> Database Driver Class Initialized
INFO - 2023-11-01 08:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:31:04 --> Controller Class Initialized
DEBUG - 2023-11-01 08:31:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 08:31:09 --> Final output sent to browser
DEBUG - 2023-11-01 08:31:09 --> Total execution time: 4.5771
INFO - 2023-11-01 08:31:22 --> Config Class Initialized
INFO - 2023-11-01 08:31:22 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:31:22 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:31:22 --> Utf8 Class Initialized
INFO - 2023-11-01 08:31:22 --> URI Class Initialized
INFO - 2023-11-01 08:31:22 --> Router Class Initialized
INFO - 2023-11-01 08:31:22 --> Output Class Initialized
INFO - 2023-11-01 08:31:22 --> Security Class Initialized
DEBUG - 2023-11-01 08:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:31:22 --> Input Class Initialized
INFO - 2023-11-01 08:31:22 --> Language Class Initialized
INFO - 2023-11-01 08:31:22 --> Language Class Initialized
INFO - 2023-11-01 08:31:22 --> Config Class Initialized
INFO - 2023-11-01 08:31:22 --> Loader Class Initialized
INFO - 2023-11-01 08:31:22 --> Helper loaded: url_helper
INFO - 2023-11-01 08:31:22 --> Helper loaded: file_helper
INFO - 2023-11-01 08:31:22 --> Helper loaded: form_helper
INFO - 2023-11-01 08:31:22 --> Helper loaded: my_helper
INFO - 2023-11-01 08:31:22 --> Database Driver Class Initialized
INFO - 2023-11-01 08:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:31:22 --> Controller Class Initialized
DEBUG - 2023-11-01 08:31:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 08:31:25 --> Final output sent to browser
DEBUG - 2023-11-01 08:31:25 --> Total execution time: 3.4792
INFO - 2023-11-01 08:31:39 --> Config Class Initialized
INFO - 2023-11-01 08:31:39 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:31:39 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:31:39 --> Utf8 Class Initialized
INFO - 2023-11-01 08:31:39 --> URI Class Initialized
INFO - 2023-11-01 08:31:39 --> Router Class Initialized
INFO - 2023-11-01 08:31:39 --> Output Class Initialized
INFO - 2023-11-01 08:31:39 --> Security Class Initialized
DEBUG - 2023-11-01 08:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:31:39 --> Input Class Initialized
INFO - 2023-11-01 08:31:39 --> Language Class Initialized
INFO - 2023-11-01 08:31:39 --> Language Class Initialized
INFO - 2023-11-01 08:31:39 --> Config Class Initialized
INFO - 2023-11-01 08:31:39 --> Loader Class Initialized
INFO - 2023-11-01 08:31:39 --> Helper loaded: url_helper
INFO - 2023-11-01 08:31:39 --> Helper loaded: file_helper
INFO - 2023-11-01 08:31:39 --> Helper loaded: form_helper
INFO - 2023-11-01 08:31:39 --> Helper loaded: my_helper
INFO - 2023-11-01 08:31:39 --> Database Driver Class Initialized
INFO - 2023-11-01 08:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:31:39 --> Controller Class Initialized
DEBUG - 2023-11-01 08:31:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 08:31:42 --> Config Class Initialized
INFO - 2023-11-01 08:31:42 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:31:42 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:31:42 --> Utf8 Class Initialized
INFO - 2023-11-01 08:31:42 --> URI Class Initialized
INFO - 2023-11-01 08:31:42 --> Router Class Initialized
INFO - 2023-11-01 08:31:42 --> Output Class Initialized
INFO - 2023-11-01 08:31:42 --> Security Class Initialized
DEBUG - 2023-11-01 08:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:31:42 --> Input Class Initialized
INFO - 2023-11-01 08:31:42 --> Language Class Initialized
INFO - 2023-11-01 08:31:42 --> Language Class Initialized
INFO - 2023-11-01 08:31:42 --> Config Class Initialized
INFO - 2023-11-01 08:31:42 --> Loader Class Initialized
INFO - 2023-11-01 08:31:42 --> Helper loaded: url_helper
INFO - 2023-11-01 08:31:42 --> Helper loaded: file_helper
INFO - 2023-11-01 08:31:42 --> Helper loaded: form_helper
INFO - 2023-11-01 08:31:42 --> Helper loaded: my_helper
INFO - 2023-11-01 08:31:42 --> Database Driver Class Initialized
INFO - 2023-11-01 08:31:43 --> Final output sent to browser
DEBUG - 2023-11-01 08:31:43 --> Total execution time: 3.4910
INFO - 2023-11-01 08:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:31:43 --> Controller Class Initialized
DEBUG - 2023-11-01 08:31:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 08:31:46 --> Final output sent to browser
DEBUG - 2023-11-01 08:31:46 --> Total execution time: 3.8766
INFO - 2023-11-01 08:31:55 --> Config Class Initialized
INFO - 2023-11-01 08:31:55 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:31:55 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:31:55 --> Utf8 Class Initialized
INFO - 2023-11-01 08:31:55 --> URI Class Initialized
INFO - 2023-11-01 08:31:55 --> Router Class Initialized
INFO - 2023-11-01 08:31:55 --> Output Class Initialized
INFO - 2023-11-01 08:31:55 --> Security Class Initialized
DEBUG - 2023-11-01 08:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:31:55 --> Input Class Initialized
INFO - 2023-11-01 08:31:55 --> Language Class Initialized
INFO - 2023-11-01 08:31:55 --> Language Class Initialized
INFO - 2023-11-01 08:31:55 --> Config Class Initialized
INFO - 2023-11-01 08:31:55 --> Loader Class Initialized
INFO - 2023-11-01 08:31:55 --> Helper loaded: url_helper
INFO - 2023-11-01 08:31:55 --> Helper loaded: file_helper
INFO - 2023-11-01 08:31:55 --> Helper loaded: form_helper
INFO - 2023-11-01 08:31:55 --> Helper loaded: my_helper
INFO - 2023-11-01 08:31:55 --> Database Driver Class Initialized
INFO - 2023-11-01 08:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:31:55 --> Controller Class Initialized
DEBUG - 2023-11-01 08:31:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 08:31:58 --> Final output sent to browser
DEBUG - 2023-11-01 08:31:58 --> Total execution time: 3.2407
INFO - 2023-11-01 08:32:07 --> Config Class Initialized
INFO - 2023-11-01 08:32:07 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:32:07 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:32:07 --> Utf8 Class Initialized
INFO - 2023-11-01 08:32:07 --> URI Class Initialized
INFO - 2023-11-01 08:32:07 --> Router Class Initialized
INFO - 2023-11-01 08:32:07 --> Output Class Initialized
INFO - 2023-11-01 08:32:07 --> Security Class Initialized
DEBUG - 2023-11-01 08:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:32:07 --> Input Class Initialized
INFO - 2023-11-01 08:32:07 --> Language Class Initialized
INFO - 2023-11-01 08:32:07 --> Language Class Initialized
INFO - 2023-11-01 08:32:07 --> Config Class Initialized
INFO - 2023-11-01 08:32:07 --> Loader Class Initialized
INFO - 2023-11-01 08:32:07 --> Helper loaded: url_helper
INFO - 2023-11-01 08:32:07 --> Helper loaded: file_helper
INFO - 2023-11-01 08:32:07 --> Helper loaded: form_helper
INFO - 2023-11-01 08:32:07 --> Helper loaded: my_helper
INFO - 2023-11-01 08:32:07 --> Database Driver Class Initialized
INFO - 2023-11-01 08:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:32:07 --> Controller Class Initialized
DEBUG - 2023-11-01 08:32:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 08:32:10 --> Final output sent to browser
DEBUG - 2023-11-01 08:32:10 --> Total execution time: 3.2930
INFO - 2023-11-01 08:32:42 --> Config Class Initialized
INFO - 2023-11-01 08:32:42 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:32:42 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:32:42 --> Utf8 Class Initialized
INFO - 2023-11-01 08:32:42 --> URI Class Initialized
INFO - 2023-11-01 08:32:42 --> Router Class Initialized
INFO - 2023-11-01 08:32:42 --> Output Class Initialized
INFO - 2023-11-01 08:32:42 --> Security Class Initialized
DEBUG - 2023-11-01 08:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:32:42 --> Input Class Initialized
INFO - 2023-11-01 08:32:42 --> Language Class Initialized
INFO - 2023-11-01 08:32:42 --> Language Class Initialized
INFO - 2023-11-01 08:32:42 --> Config Class Initialized
INFO - 2023-11-01 08:32:42 --> Loader Class Initialized
INFO - 2023-11-01 08:32:42 --> Helper loaded: url_helper
INFO - 2023-11-01 08:32:42 --> Helper loaded: file_helper
INFO - 2023-11-01 08:32:42 --> Helper loaded: form_helper
INFO - 2023-11-01 08:32:42 --> Helper loaded: my_helper
INFO - 2023-11-01 08:32:42 --> Database Driver Class Initialized
INFO - 2023-11-01 08:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:32:42 --> Controller Class Initialized
DEBUG - 2023-11-01 08:32:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 08:32:46 --> Final output sent to browser
DEBUG - 2023-11-01 08:32:46 --> Total execution time: 3.9502
INFO - 2023-11-01 08:33:16 --> Config Class Initialized
INFO - 2023-11-01 08:33:16 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:33:16 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:33:16 --> Utf8 Class Initialized
INFO - 2023-11-01 08:33:16 --> URI Class Initialized
INFO - 2023-11-01 08:33:16 --> Router Class Initialized
INFO - 2023-11-01 08:33:16 --> Output Class Initialized
INFO - 2023-11-01 08:33:16 --> Security Class Initialized
DEBUG - 2023-11-01 08:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:33:16 --> Input Class Initialized
INFO - 2023-11-01 08:33:16 --> Language Class Initialized
INFO - 2023-11-01 08:33:16 --> Language Class Initialized
INFO - 2023-11-01 08:33:16 --> Config Class Initialized
INFO - 2023-11-01 08:33:16 --> Loader Class Initialized
INFO - 2023-11-01 08:33:16 --> Helper loaded: url_helper
INFO - 2023-11-01 08:33:16 --> Helper loaded: file_helper
INFO - 2023-11-01 08:33:16 --> Helper loaded: form_helper
INFO - 2023-11-01 08:33:16 --> Helper loaded: my_helper
INFO - 2023-11-01 08:33:16 --> Database Driver Class Initialized
INFO - 2023-11-01 08:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:33:16 --> Controller Class Initialized
DEBUG - 2023-11-01 08:33:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 08:33:20 --> Final output sent to browser
DEBUG - 2023-11-01 08:33:20 --> Total execution time: 3.9483
INFO - 2023-11-01 08:33:22 --> Config Class Initialized
INFO - 2023-11-01 08:33:22 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:33:22 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:33:22 --> Utf8 Class Initialized
INFO - 2023-11-01 08:33:22 --> URI Class Initialized
INFO - 2023-11-01 08:33:22 --> Router Class Initialized
INFO - 2023-11-01 08:33:22 --> Output Class Initialized
INFO - 2023-11-01 08:33:22 --> Security Class Initialized
DEBUG - 2023-11-01 08:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:33:22 --> Input Class Initialized
INFO - 2023-11-01 08:33:22 --> Language Class Initialized
INFO - 2023-11-01 08:33:22 --> Language Class Initialized
INFO - 2023-11-01 08:33:22 --> Config Class Initialized
INFO - 2023-11-01 08:33:22 --> Loader Class Initialized
INFO - 2023-11-01 08:33:22 --> Helper loaded: url_helper
INFO - 2023-11-01 08:33:22 --> Helper loaded: file_helper
INFO - 2023-11-01 08:33:22 --> Helper loaded: form_helper
INFO - 2023-11-01 08:33:22 --> Helper loaded: my_helper
INFO - 2023-11-01 08:33:22 --> Database Driver Class Initialized
INFO - 2023-11-01 08:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:33:22 --> Controller Class Initialized
DEBUG - 2023-11-01 08:33:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 08:33:26 --> Final output sent to browser
DEBUG - 2023-11-01 08:33:26 --> Total execution time: 4.4119
INFO - 2023-11-01 08:35:27 --> Config Class Initialized
INFO - 2023-11-01 08:35:27 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:35:27 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:35:27 --> Utf8 Class Initialized
INFO - 2023-11-01 08:35:27 --> URI Class Initialized
INFO - 2023-11-01 08:35:27 --> Router Class Initialized
INFO - 2023-11-01 08:35:27 --> Output Class Initialized
INFO - 2023-11-01 08:35:27 --> Security Class Initialized
DEBUG - 2023-11-01 08:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:35:27 --> Input Class Initialized
INFO - 2023-11-01 08:35:27 --> Language Class Initialized
INFO - 2023-11-01 08:35:27 --> Language Class Initialized
INFO - 2023-11-01 08:35:27 --> Config Class Initialized
INFO - 2023-11-01 08:35:27 --> Loader Class Initialized
INFO - 2023-11-01 08:35:27 --> Helper loaded: url_helper
INFO - 2023-11-01 08:35:27 --> Helper loaded: file_helper
INFO - 2023-11-01 08:35:27 --> Helper loaded: form_helper
INFO - 2023-11-01 08:35:27 --> Helper loaded: my_helper
INFO - 2023-11-01 08:35:27 --> Database Driver Class Initialized
INFO - 2023-11-01 08:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:35:27 --> Controller Class Initialized
DEBUG - 2023-11-01 08:35:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 08:35:31 --> Final output sent to browser
DEBUG - 2023-11-01 08:35:31 --> Total execution time: 3.8612
INFO - 2023-11-01 08:35:47 --> Config Class Initialized
INFO - 2023-11-01 08:35:47 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:35:47 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:35:47 --> Utf8 Class Initialized
INFO - 2023-11-01 08:35:47 --> URI Class Initialized
INFO - 2023-11-01 08:35:47 --> Router Class Initialized
INFO - 2023-11-01 08:35:47 --> Output Class Initialized
INFO - 2023-11-01 08:35:47 --> Security Class Initialized
DEBUG - 2023-11-01 08:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:35:47 --> Input Class Initialized
INFO - 2023-11-01 08:35:47 --> Language Class Initialized
INFO - 2023-11-01 08:35:47 --> Language Class Initialized
INFO - 2023-11-01 08:35:47 --> Config Class Initialized
INFO - 2023-11-01 08:35:47 --> Loader Class Initialized
INFO - 2023-11-01 08:35:47 --> Helper loaded: url_helper
INFO - 2023-11-01 08:35:47 --> Helper loaded: file_helper
INFO - 2023-11-01 08:35:47 --> Helper loaded: form_helper
INFO - 2023-11-01 08:35:47 --> Helper loaded: my_helper
INFO - 2023-11-01 08:35:47 --> Database Driver Class Initialized
INFO - 2023-11-01 08:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:35:47 --> Controller Class Initialized
DEBUG - 2023-11-01 08:35:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 08:35:51 --> Final output sent to browser
DEBUG - 2023-11-01 08:35:51 --> Total execution time: 3.4486
INFO - 2023-11-01 08:36:03 --> Config Class Initialized
INFO - 2023-11-01 08:36:03 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:36:03 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:36:03 --> Utf8 Class Initialized
INFO - 2023-11-01 08:36:03 --> URI Class Initialized
INFO - 2023-11-01 08:36:03 --> Router Class Initialized
INFO - 2023-11-01 08:36:03 --> Output Class Initialized
INFO - 2023-11-01 08:36:03 --> Security Class Initialized
DEBUG - 2023-11-01 08:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:36:03 --> Input Class Initialized
INFO - 2023-11-01 08:36:03 --> Language Class Initialized
INFO - 2023-11-01 08:36:03 --> Language Class Initialized
INFO - 2023-11-01 08:36:03 --> Config Class Initialized
INFO - 2023-11-01 08:36:03 --> Loader Class Initialized
INFO - 2023-11-01 08:36:03 --> Helper loaded: url_helper
INFO - 2023-11-01 08:36:03 --> Helper loaded: file_helper
INFO - 2023-11-01 08:36:03 --> Helper loaded: form_helper
INFO - 2023-11-01 08:36:03 --> Helper loaded: my_helper
INFO - 2023-11-01 08:36:03 --> Database Driver Class Initialized
INFO - 2023-11-01 08:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:36:03 --> Controller Class Initialized
DEBUG - 2023-11-01 08:36:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 08:36:07 --> Final output sent to browser
DEBUG - 2023-11-01 08:36:07 --> Total execution time: 3.7458
INFO - 2023-11-01 08:36:09 --> Config Class Initialized
INFO - 2023-11-01 08:36:09 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:36:09 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:36:09 --> Utf8 Class Initialized
INFO - 2023-11-01 08:36:09 --> URI Class Initialized
INFO - 2023-11-01 08:36:09 --> Router Class Initialized
INFO - 2023-11-01 08:36:09 --> Output Class Initialized
INFO - 2023-11-01 08:36:09 --> Security Class Initialized
DEBUG - 2023-11-01 08:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:36:09 --> Input Class Initialized
INFO - 2023-11-01 08:36:09 --> Language Class Initialized
INFO - 2023-11-01 08:36:09 --> Language Class Initialized
INFO - 2023-11-01 08:36:09 --> Config Class Initialized
INFO - 2023-11-01 08:36:09 --> Loader Class Initialized
INFO - 2023-11-01 08:36:09 --> Helper loaded: url_helper
INFO - 2023-11-01 08:36:09 --> Helper loaded: file_helper
INFO - 2023-11-01 08:36:09 --> Helper loaded: form_helper
INFO - 2023-11-01 08:36:09 --> Helper loaded: my_helper
INFO - 2023-11-01 08:36:09 --> Database Driver Class Initialized
INFO - 2023-11-01 08:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:36:09 --> Controller Class Initialized
DEBUG - 2023-11-01 08:36:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 08:36:13 --> Final output sent to browser
DEBUG - 2023-11-01 08:36:13 --> Total execution time: 3.5221
INFO - 2023-11-01 08:36:22 --> Config Class Initialized
INFO - 2023-11-01 08:36:22 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:36:22 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:36:22 --> Utf8 Class Initialized
INFO - 2023-11-01 08:36:22 --> URI Class Initialized
INFO - 2023-11-01 08:36:22 --> Router Class Initialized
INFO - 2023-11-01 08:36:22 --> Output Class Initialized
INFO - 2023-11-01 08:36:22 --> Security Class Initialized
DEBUG - 2023-11-01 08:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:36:22 --> Input Class Initialized
INFO - 2023-11-01 08:36:22 --> Language Class Initialized
INFO - 2023-11-01 08:36:22 --> Language Class Initialized
INFO - 2023-11-01 08:36:22 --> Config Class Initialized
INFO - 2023-11-01 08:36:22 --> Loader Class Initialized
INFO - 2023-11-01 08:36:22 --> Helper loaded: url_helper
INFO - 2023-11-01 08:36:22 --> Helper loaded: file_helper
INFO - 2023-11-01 08:36:22 --> Helper loaded: form_helper
INFO - 2023-11-01 08:36:22 --> Helper loaded: my_helper
INFO - 2023-11-01 08:36:22 --> Database Driver Class Initialized
INFO - 2023-11-01 08:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:36:22 --> Controller Class Initialized
DEBUG - 2023-11-01 08:36:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 08:36:26 --> Final output sent to browser
DEBUG - 2023-11-01 08:36:26 --> Total execution time: 3.4028
INFO - 2023-11-01 08:36:36 --> Config Class Initialized
INFO - 2023-11-01 08:36:36 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:36:36 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:36:36 --> Utf8 Class Initialized
INFO - 2023-11-01 08:36:36 --> URI Class Initialized
INFO - 2023-11-01 08:36:36 --> Router Class Initialized
INFO - 2023-11-01 08:36:36 --> Output Class Initialized
INFO - 2023-11-01 08:36:36 --> Security Class Initialized
DEBUG - 2023-11-01 08:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:36:36 --> Input Class Initialized
INFO - 2023-11-01 08:36:36 --> Language Class Initialized
INFO - 2023-11-01 08:36:36 --> Language Class Initialized
INFO - 2023-11-01 08:36:36 --> Config Class Initialized
INFO - 2023-11-01 08:36:36 --> Loader Class Initialized
INFO - 2023-11-01 08:36:36 --> Helper loaded: url_helper
INFO - 2023-11-01 08:36:36 --> Helper loaded: file_helper
INFO - 2023-11-01 08:36:36 --> Helper loaded: form_helper
INFO - 2023-11-01 08:36:36 --> Helper loaded: my_helper
INFO - 2023-11-01 08:36:36 --> Database Driver Class Initialized
INFO - 2023-11-01 08:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:36:36 --> Controller Class Initialized
DEBUG - 2023-11-01 08:36:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 08:36:40 --> Config Class Initialized
INFO - 2023-11-01 08:36:40 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:36:40 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:36:40 --> Utf8 Class Initialized
INFO - 2023-11-01 08:36:40 --> URI Class Initialized
INFO - 2023-11-01 08:36:40 --> Router Class Initialized
INFO - 2023-11-01 08:36:40 --> Output Class Initialized
INFO - 2023-11-01 08:36:40 --> Security Class Initialized
DEBUG - 2023-11-01 08:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:36:40 --> Input Class Initialized
INFO - 2023-11-01 08:36:40 --> Language Class Initialized
INFO - 2023-11-01 08:36:40 --> Language Class Initialized
INFO - 2023-11-01 08:36:40 --> Config Class Initialized
INFO - 2023-11-01 08:36:40 --> Loader Class Initialized
INFO - 2023-11-01 08:36:40 --> Helper loaded: url_helper
INFO - 2023-11-01 08:36:40 --> Helper loaded: file_helper
INFO - 2023-11-01 08:36:40 --> Helper loaded: form_helper
INFO - 2023-11-01 08:36:40 --> Helper loaded: my_helper
INFO - 2023-11-01 08:36:40 --> Database Driver Class Initialized
INFO - 2023-11-01 08:36:40 --> Final output sent to browser
DEBUG - 2023-11-01 08:36:40 --> Total execution time: 4.3279
INFO - 2023-11-01 08:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:36:40 --> Controller Class Initialized
DEBUG - 2023-11-01 08:36:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 08:36:44 --> Final output sent to browser
DEBUG - 2023-11-01 08:36:44 --> Total execution time: 4.4733
INFO - 2023-11-01 08:36:57 --> Config Class Initialized
INFO - 2023-11-01 08:36:57 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:36:57 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:36:57 --> Utf8 Class Initialized
INFO - 2023-11-01 08:36:57 --> URI Class Initialized
INFO - 2023-11-01 08:36:57 --> Router Class Initialized
INFO - 2023-11-01 08:36:57 --> Output Class Initialized
INFO - 2023-11-01 08:36:57 --> Security Class Initialized
DEBUG - 2023-11-01 08:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:36:57 --> Input Class Initialized
INFO - 2023-11-01 08:36:57 --> Language Class Initialized
INFO - 2023-11-01 08:36:57 --> Language Class Initialized
INFO - 2023-11-01 08:36:57 --> Config Class Initialized
INFO - 2023-11-01 08:36:57 --> Loader Class Initialized
INFO - 2023-11-01 08:36:57 --> Helper loaded: url_helper
INFO - 2023-11-01 08:36:57 --> Helper loaded: file_helper
INFO - 2023-11-01 08:36:57 --> Helper loaded: form_helper
INFO - 2023-11-01 08:36:57 --> Helper loaded: my_helper
INFO - 2023-11-01 08:36:57 --> Database Driver Class Initialized
INFO - 2023-11-01 08:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:36:57 --> Controller Class Initialized
DEBUG - 2023-11-01 08:36:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 08:37:00 --> Final output sent to browser
DEBUG - 2023-11-01 08:37:00 --> Total execution time: 3.2968
INFO - 2023-11-01 08:57:17 --> Config Class Initialized
INFO - 2023-11-01 08:57:17 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:57:17 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:57:17 --> Utf8 Class Initialized
INFO - 2023-11-01 08:57:17 --> URI Class Initialized
INFO - 2023-11-01 08:57:17 --> Router Class Initialized
INFO - 2023-11-01 08:57:17 --> Output Class Initialized
INFO - 2023-11-01 08:57:17 --> Security Class Initialized
DEBUG - 2023-11-01 08:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:57:17 --> Input Class Initialized
INFO - 2023-11-01 08:57:17 --> Language Class Initialized
INFO - 2023-11-01 08:57:17 --> Language Class Initialized
INFO - 2023-11-01 08:57:17 --> Config Class Initialized
INFO - 2023-11-01 08:57:17 --> Loader Class Initialized
INFO - 2023-11-01 08:57:17 --> Helper loaded: url_helper
INFO - 2023-11-01 08:57:17 --> Helper loaded: file_helper
INFO - 2023-11-01 08:57:17 --> Helper loaded: form_helper
INFO - 2023-11-01 08:57:17 --> Helper loaded: my_helper
INFO - 2023-11-01 08:57:17 --> Database Driver Class Initialized
INFO - 2023-11-01 08:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:57:17 --> Controller Class Initialized
DEBUG - 2023-11-01 08:57:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-01 08:57:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-01 08:57:17 --> Final output sent to browser
DEBUG - 2023-11-01 08:57:17 --> Total execution time: 0.0484
INFO - 2023-11-01 08:57:20 --> Config Class Initialized
INFO - 2023-11-01 08:57:20 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:57:20 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:57:20 --> Utf8 Class Initialized
INFO - 2023-11-01 08:57:20 --> URI Class Initialized
INFO - 2023-11-01 08:57:20 --> Router Class Initialized
INFO - 2023-11-01 08:57:20 --> Output Class Initialized
INFO - 2023-11-01 08:57:20 --> Security Class Initialized
DEBUG - 2023-11-01 08:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:57:20 --> Input Class Initialized
INFO - 2023-11-01 08:57:20 --> Language Class Initialized
INFO - 2023-11-01 08:57:20 --> Language Class Initialized
INFO - 2023-11-01 08:57:20 --> Config Class Initialized
INFO - 2023-11-01 08:57:20 --> Loader Class Initialized
INFO - 2023-11-01 08:57:20 --> Helper loaded: url_helper
INFO - 2023-11-01 08:57:20 --> Helper loaded: file_helper
INFO - 2023-11-01 08:57:20 --> Helper loaded: form_helper
INFO - 2023-11-01 08:57:20 --> Helper loaded: my_helper
INFO - 2023-11-01 08:57:20 --> Database Driver Class Initialized
INFO - 2023-11-01 08:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:57:20 --> Controller Class Initialized
INFO - 2023-11-01 08:57:20 --> Helper loaded: cookie_helper
INFO - 2023-11-01 08:57:20 --> Final output sent to browser
DEBUG - 2023-11-01 08:57:20 --> Total execution time: 0.0425
INFO - 2023-11-01 08:57:20 --> Config Class Initialized
INFO - 2023-11-01 08:57:20 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:57:20 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:57:20 --> Utf8 Class Initialized
INFO - 2023-11-01 08:57:20 --> URI Class Initialized
INFO - 2023-11-01 08:57:20 --> Router Class Initialized
INFO - 2023-11-01 08:57:20 --> Output Class Initialized
INFO - 2023-11-01 08:57:20 --> Security Class Initialized
DEBUG - 2023-11-01 08:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:57:20 --> Input Class Initialized
INFO - 2023-11-01 08:57:20 --> Language Class Initialized
INFO - 2023-11-01 08:57:20 --> Language Class Initialized
INFO - 2023-11-01 08:57:20 --> Config Class Initialized
INFO - 2023-11-01 08:57:20 --> Loader Class Initialized
INFO - 2023-11-01 08:57:20 --> Helper loaded: url_helper
INFO - 2023-11-01 08:57:20 --> Helper loaded: file_helper
INFO - 2023-11-01 08:57:20 --> Helper loaded: form_helper
INFO - 2023-11-01 08:57:20 --> Helper loaded: my_helper
INFO - 2023-11-01 08:57:20 --> Database Driver Class Initialized
INFO - 2023-11-01 08:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:57:20 --> Controller Class Initialized
DEBUG - 2023-11-01 08:57:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-01 08:57:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-01 08:57:20 --> Final output sent to browser
DEBUG - 2023-11-01 08:57:20 --> Total execution time: 0.0393
INFO - 2023-11-01 08:57:25 --> Config Class Initialized
INFO - 2023-11-01 08:57:25 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:57:25 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:57:25 --> Utf8 Class Initialized
INFO - 2023-11-01 08:57:25 --> URI Class Initialized
INFO - 2023-11-01 08:57:25 --> Router Class Initialized
INFO - 2023-11-01 08:57:25 --> Output Class Initialized
INFO - 2023-11-01 08:57:25 --> Security Class Initialized
DEBUG - 2023-11-01 08:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:57:25 --> Input Class Initialized
INFO - 2023-11-01 08:57:25 --> Language Class Initialized
INFO - 2023-11-01 08:57:25 --> Language Class Initialized
INFO - 2023-11-01 08:57:25 --> Config Class Initialized
INFO - 2023-11-01 08:57:25 --> Loader Class Initialized
INFO - 2023-11-01 08:57:25 --> Helper loaded: url_helper
INFO - 2023-11-01 08:57:25 --> Helper loaded: file_helper
INFO - 2023-11-01 08:57:25 --> Helper loaded: form_helper
INFO - 2023-11-01 08:57:25 --> Helper loaded: my_helper
INFO - 2023-11-01 08:57:25 --> Database Driver Class Initialized
INFO - 2023-11-01 08:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:57:25 --> Controller Class Initialized
DEBUG - 2023-11-01 08:57:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2023-11-01 08:57:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-01 08:57:25 --> Final output sent to browser
DEBUG - 2023-11-01 08:57:25 --> Total execution time: 0.0441
INFO - 2023-11-01 08:57:27 --> Config Class Initialized
INFO - 2023-11-01 08:57:27 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:57:27 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:57:27 --> Utf8 Class Initialized
INFO - 2023-11-01 08:57:27 --> URI Class Initialized
INFO - 2023-11-01 08:57:27 --> Router Class Initialized
INFO - 2023-11-01 08:57:27 --> Output Class Initialized
INFO - 2023-11-01 08:57:27 --> Security Class Initialized
DEBUG - 2023-11-01 08:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:57:27 --> Input Class Initialized
INFO - 2023-11-01 08:57:27 --> Language Class Initialized
INFO - 2023-11-01 08:57:27 --> Language Class Initialized
INFO - 2023-11-01 08:57:27 --> Config Class Initialized
INFO - 2023-11-01 08:57:27 --> Loader Class Initialized
INFO - 2023-11-01 08:57:27 --> Helper loaded: url_helper
INFO - 2023-11-01 08:57:27 --> Helper loaded: file_helper
INFO - 2023-11-01 08:57:27 --> Helper loaded: form_helper
INFO - 2023-11-01 08:57:27 --> Helper loaded: my_helper
INFO - 2023-11-01 08:57:27 --> Database Driver Class Initialized
INFO - 2023-11-01 08:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:57:27 --> Controller Class Initialized
DEBUG - 2023-11-01 08:57:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 08:57:32 --> Final output sent to browser
DEBUG - 2023-11-01 08:57:32 --> Total execution time: 4.7010
INFO - 2023-11-01 08:58:00 --> Config Class Initialized
INFO - 2023-11-01 08:58:00 --> Hooks Class Initialized
DEBUG - 2023-11-01 08:58:00 --> UTF-8 Support Enabled
INFO - 2023-11-01 08:58:00 --> Utf8 Class Initialized
INFO - 2023-11-01 08:58:00 --> URI Class Initialized
INFO - 2023-11-01 08:58:00 --> Router Class Initialized
INFO - 2023-11-01 08:58:00 --> Output Class Initialized
INFO - 2023-11-01 08:58:00 --> Security Class Initialized
DEBUG - 2023-11-01 08:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 08:58:00 --> Input Class Initialized
INFO - 2023-11-01 08:58:00 --> Language Class Initialized
INFO - 2023-11-01 08:58:00 --> Language Class Initialized
INFO - 2023-11-01 08:58:00 --> Config Class Initialized
INFO - 2023-11-01 08:58:00 --> Loader Class Initialized
INFO - 2023-11-01 08:58:00 --> Helper loaded: url_helper
INFO - 2023-11-01 08:58:00 --> Helper loaded: file_helper
INFO - 2023-11-01 08:58:00 --> Helper loaded: form_helper
INFO - 2023-11-01 08:58:00 --> Helper loaded: my_helper
INFO - 2023-11-01 08:58:00 --> Database Driver Class Initialized
INFO - 2023-11-01 08:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 08:58:00 --> Controller Class Initialized
DEBUG - 2023-11-01 08:58:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2023-11-01 08:58:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-01 08:58:00 --> Final output sent to browser
DEBUG - 2023-11-01 08:58:00 --> Total execution time: 0.1035
INFO - 2023-11-01 09:03:02 --> Config Class Initialized
INFO - 2023-11-01 09:03:02 --> Hooks Class Initialized
DEBUG - 2023-11-01 09:03:02 --> UTF-8 Support Enabled
INFO - 2023-11-01 09:03:02 --> Utf8 Class Initialized
INFO - 2023-11-01 09:03:02 --> URI Class Initialized
INFO - 2023-11-01 09:03:02 --> Router Class Initialized
INFO - 2023-11-01 09:03:02 --> Output Class Initialized
INFO - 2023-11-01 09:03:02 --> Security Class Initialized
DEBUG - 2023-11-01 09:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 09:03:02 --> Input Class Initialized
INFO - 2023-11-01 09:03:02 --> Language Class Initialized
INFO - 2023-11-01 09:03:02 --> Language Class Initialized
INFO - 2023-11-01 09:03:02 --> Config Class Initialized
INFO - 2023-11-01 09:03:02 --> Loader Class Initialized
INFO - 2023-11-01 09:03:02 --> Helper loaded: url_helper
INFO - 2023-11-01 09:03:02 --> Helper loaded: file_helper
INFO - 2023-11-01 09:03:02 --> Helper loaded: form_helper
INFO - 2023-11-01 09:03:02 --> Helper loaded: my_helper
INFO - 2023-11-01 09:03:02 --> Database Driver Class Initialized
INFO - 2023-11-01 09:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 09:03:02 --> Controller Class Initialized
DEBUG - 2023-11-01 09:03:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 09:03:08 --> Final output sent to browser
DEBUG - 2023-11-01 09:03:08 --> Total execution time: 6.4331
INFO - 2023-11-01 09:05:25 --> Config Class Initialized
INFO - 2023-11-01 09:05:25 --> Hooks Class Initialized
DEBUG - 2023-11-01 09:05:25 --> UTF-8 Support Enabled
INFO - 2023-11-01 09:05:25 --> Utf8 Class Initialized
INFO - 2023-11-01 09:05:25 --> URI Class Initialized
INFO - 2023-11-01 09:05:25 --> Router Class Initialized
INFO - 2023-11-01 09:05:25 --> Output Class Initialized
INFO - 2023-11-01 09:05:25 --> Security Class Initialized
DEBUG - 2023-11-01 09:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 09:05:25 --> Input Class Initialized
INFO - 2023-11-01 09:05:25 --> Language Class Initialized
INFO - 2023-11-01 09:05:25 --> Language Class Initialized
INFO - 2023-11-01 09:05:25 --> Config Class Initialized
INFO - 2023-11-01 09:05:25 --> Loader Class Initialized
INFO - 2023-11-01 09:05:25 --> Helper loaded: url_helper
INFO - 2023-11-01 09:05:25 --> Helper loaded: file_helper
INFO - 2023-11-01 09:05:25 --> Helper loaded: form_helper
INFO - 2023-11-01 09:05:25 --> Helper loaded: my_helper
INFO - 2023-11-01 09:05:25 --> Database Driver Class Initialized
INFO - 2023-11-01 09:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 09:05:25 --> Controller Class Initialized
DEBUG - 2023-11-01 09:05:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 09:05:30 --> Final output sent to browser
DEBUG - 2023-11-01 09:05:30 --> Total execution time: 5.3220
INFO - 2023-11-01 09:07:02 --> Config Class Initialized
INFO - 2023-11-01 09:07:02 --> Hooks Class Initialized
DEBUG - 2023-11-01 09:07:02 --> UTF-8 Support Enabled
INFO - 2023-11-01 09:07:02 --> Utf8 Class Initialized
INFO - 2023-11-01 09:07:02 --> URI Class Initialized
INFO - 2023-11-01 09:07:02 --> Router Class Initialized
INFO - 2023-11-01 09:07:02 --> Output Class Initialized
INFO - 2023-11-01 09:07:02 --> Security Class Initialized
DEBUG - 2023-11-01 09:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 09:07:02 --> Input Class Initialized
INFO - 2023-11-01 09:07:02 --> Language Class Initialized
INFO - 2023-11-01 09:07:02 --> Language Class Initialized
INFO - 2023-11-01 09:07:02 --> Config Class Initialized
INFO - 2023-11-01 09:07:02 --> Loader Class Initialized
INFO - 2023-11-01 09:07:02 --> Helper loaded: url_helper
INFO - 2023-11-01 09:07:02 --> Helper loaded: file_helper
INFO - 2023-11-01 09:07:02 --> Helper loaded: form_helper
INFO - 2023-11-01 09:07:02 --> Helper loaded: my_helper
INFO - 2023-11-01 09:07:02 --> Database Driver Class Initialized
INFO - 2023-11-01 09:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 09:07:02 --> Controller Class Initialized
DEBUG - 2023-11-01 09:07:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 09:07:06 --> Final output sent to browser
DEBUG - 2023-11-01 09:07:06 --> Total execution time: 4.5505
INFO - 2023-11-01 09:07:18 --> Config Class Initialized
INFO - 2023-11-01 09:07:18 --> Hooks Class Initialized
DEBUG - 2023-11-01 09:07:18 --> UTF-8 Support Enabled
INFO - 2023-11-01 09:07:18 --> Utf8 Class Initialized
INFO - 2023-11-01 09:07:18 --> URI Class Initialized
INFO - 2023-11-01 09:07:18 --> Router Class Initialized
INFO - 2023-11-01 09:07:18 --> Output Class Initialized
INFO - 2023-11-01 09:07:18 --> Security Class Initialized
DEBUG - 2023-11-01 09:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 09:07:18 --> Input Class Initialized
INFO - 2023-11-01 09:07:18 --> Language Class Initialized
INFO - 2023-11-01 09:07:18 --> Language Class Initialized
INFO - 2023-11-01 09:07:18 --> Config Class Initialized
INFO - 2023-11-01 09:07:18 --> Loader Class Initialized
INFO - 2023-11-01 09:07:18 --> Helper loaded: url_helper
INFO - 2023-11-01 09:07:18 --> Helper loaded: file_helper
INFO - 2023-11-01 09:07:18 --> Helper loaded: form_helper
INFO - 2023-11-01 09:07:18 --> Helper loaded: my_helper
INFO - 2023-11-01 09:07:18 --> Database Driver Class Initialized
INFO - 2023-11-01 09:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 09:07:18 --> Controller Class Initialized
DEBUG - 2023-11-01 09:07:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 09:07:22 --> Final output sent to browser
DEBUG - 2023-11-01 09:07:22 --> Total execution time: 3.6225
INFO - 2023-11-01 09:08:49 --> Config Class Initialized
INFO - 2023-11-01 09:08:49 --> Hooks Class Initialized
DEBUG - 2023-11-01 09:08:49 --> UTF-8 Support Enabled
INFO - 2023-11-01 09:08:49 --> Utf8 Class Initialized
INFO - 2023-11-01 09:08:49 --> URI Class Initialized
INFO - 2023-11-01 09:08:49 --> Router Class Initialized
INFO - 2023-11-01 09:08:49 --> Output Class Initialized
INFO - 2023-11-01 09:08:49 --> Security Class Initialized
DEBUG - 2023-11-01 09:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 09:08:49 --> Input Class Initialized
INFO - 2023-11-01 09:08:49 --> Language Class Initialized
INFO - 2023-11-01 09:08:49 --> Language Class Initialized
INFO - 2023-11-01 09:08:49 --> Config Class Initialized
INFO - 2023-11-01 09:08:49 --> Loader Class Initialized
INFO - 2023-11-01 09:08:49 --> Helper loaded: url_helper
INFO - 2023-11-01 09:08:49 --> Helper loaded: file_helper
INFO - 2023-11-01 09:08:49 --> Helper loaded: form_helper
INFO - 2023-11-01 09:08:49 --> Helper loaded: my_helper
INFO - 2023-11-01 09:08:49 --> Database Driver Class Initialized
INFO - 2023-11-01 09:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 09:08:49 --> Controller Class Initialized
DEBUG - 2023-11-01 09:08:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 09:08:53 --> Final output sent to browser
DEBUG - 2023-11-01 09:08:53 --> Total execution time: 3.3703
INFO - 2023-11-01 09:09:07 --> Config Class Initialized
INFO - 2023-11-01 09:09:07 --> Hooks Class Initialized
DEBUG - 2023-11-01 09:09:07 --> UTF-8 Support Enabled
INFO - 2023-11-01 09:09:07 --> Utf8 Class Initialized
INFO - 2023-11-01 09:09:07 --> URI Class Initialized
INFO - 2023-11-01 09:09:07 --> Router Class Initialized
INFO - 2023-11-01 09:09:07 --> Output Class Initialized
INFO - 2023-11-01 09:09:07 --> Security Class Initialized
DEBUG - 2023-11-01 09:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 09:09:07 --> Input Class Initialized
INFO - 2023-11-01 09:09:07 --> Language Class Initialized
INFO - 2023-11-01 09:09:07 --> Language Class Initialized
INFO - 2023-11-01 09:09:07 --> Config Class Initialized
INFO - 2023-11-01 09:09:07 --> Loader Class Initialized
INFO - 2023-11-01 09:09:07 --> Helper loaded: url_helper
INFO - 2023-11-01 09:09:07 --> Helper loaded: file_helper
INFO - 2023-11-01 09:09:07 --> Helper loaded: form_helper
INFO - 2023-11-01 09:09:07 --> Helper loaded: my_helper
INFO - 2023-11-01 09:09:07 --> Database Driver Class Initialized
INFO - 2023-11-01 09:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 09:09:07 --> Controller Class Initialized
DEBUG - 2023-11-01 09:09:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 09:09:11 --> Final output sent to browser
DEBUG - 2023-11-01 09:09:11 --> Total execution time: 4.7533
INFO - 2023-11-01 09:11:55 --> Config Class Initialized
INFO - 2023-11-01 09:11:55 --> Hooks Class Initialized
DEBUG - 2023-11-01 09:11:55 --> UTF-8 Support Enabled
INFO - 2023-11-01 09:11:55 --> Utf8 Class Initialized
INFO - 2023-11-01 09:11:55 --> URI Class Initialized
INFO - 2023-11-01 09:11:55 --> Router Class Initialized
INFO - 2023-11-01 09:11:55 --> Output Class Initialized
INFO - 2023-11-01 09:11:55 --> Security Class Initialized
DEBUG - 2023-11-01 09:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 09:11:55 --> Input Class Initialized
INFO - 2023-11-01 09:11:55 --> Language Class Initialized
INFO - 2023-11-01 09:11:55 --> Language Class Initialized
INFO - 2023-11-01 09:11:55 --> Config Class Initialized
INFO - 2023-11-01 09:11:55 --> Loader Class Initialized
INFO - 2023-11-01 09:11:55 --> Helper loaded: url_helper
INFO - 2023-11-01 09:11:55 --> Helper loaded: file_helper
INFO - 2023-11-01 09:11:55 --> Helper loaded: form_helper
INFO - 2023-11-01 09:11:55 --> Helper loaded: my_helper
INFO - 2023-11-01 09:11:55 --> Database Driver Class Initialized
INFO - 2023-11-01 09:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 09:11:55 --> Controller Class Initialized
DEBUG - 2023-11-01 09:11:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 09:11:59 --> Final output sent to browser
DEBUG - 2023-11-01 09:11:59 --> Total execution time: 3.5773
INFO - 2023-11-01 09:13:14 --> Config Class Initialized
INFO - 2023-11-01 09:13:14 --> Hooks Class Initialized
DEBUG - 2023-11-01 09:13:14 --> UTF-8 Support Enabled
INFO - 2023-11-01 09:13:14 --> Utf8 Class Initialized
INFO - 2023-11-01 09:13:14 --> URI Class Initialized
INFO - 2023-11-01 09:13:14 --> Router Class Initialized
INFO - 2023-11-01 09:13:14 --> Output Class Initialized
INFO - 2023-11-01 09:13:14 --> Security Class Initialized
DEBUG - 2023-11-01 09:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 09:13:14 --> Input Class Initialized
INFO - 2023-11-01 09:13:14 --> Language Class Initialized
INFO - 2023-11-01 09:13:14 --> Language Class Initialized
INFO - 2023-11-01 09:13:14 --> Config Class Initialized
INFO - 2023-11-01 09:13:14 --> Loader Class Initialized
INFO - 2023-11-01 09:13:14 --> Helper loaded: url_helper
INFO - 2023-11-01 09:13:14 --> Helper loaded: file_helper
INFO - 2023-11-01 09:13:14 --> Helper loaded: form_helper
INFO - 2023-11-01 09:13:14 --> Helper loaded: my_helper
INFO - 2023-11-01 09:13:14 --> Database Driver Class Initialized
INFO - 2023-11-01 09:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 09:13:14 --> Controller Class Initialized
DEBUG - 2023-11-01 09:13:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 09:13:17 --> Final output sent to browser
DEBUG - 2023-11-01 09:13:17 --> Total execution time: 3.1880
INFO - 2023-11-01 09:15:14 --> Config Class Initialized
INFO - 2023-11-01 09:15:14 --> Hooks Class Initialized
DEBUG - 2023-11-01 09:15:14 --> UTF-8 Support Enabled
INFO - 2023-11-01 09:15:14 --> Utf8 Class Initialized
INFO - 2023-11-01 09:15:14 --> URI Class Initialized
INFO - 2023-11-01 09:15:14 --> Router Class Initialized
INFO - 2023-11-01 09:15:14 --> Output Class Initialized
INFO - 2023-11-01 09:15:14 --> Security Class Initialized
DEBUG - 2023-11-01 09:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 09:15:14 --> Input Class Initialized
INFO - 2023-11-01 09:15:14 --> Language Class Initialized
INFO - 2023-11-01 09:15:14 --> Language Class Initialized
INFO - 2023-11-01 09:15:14 --> Config Class Initialized
INFO - 2023-11-01 09:15:14 --> Loader Class Initialized
INFO - 2023-11-01 09:15:14 --> Helper loaded: url_helper
INFO - 2023-11-01 09:15:14 --> Helper loaded: file_helper
INFO - 2023-11-01 09:15:14 --> Helper loaded: form_helper
INFO - 2023-11-01 09:15:14 --> Helper loaded: my_helper
INFO - 2023-11-01 09:15:14 --> Database Driver Class Initialized
INFO - 2023-11-01 09:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 09:15:14 --> Controller Class Initialized
DEBUG - 2023-11-01 09:15:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 09:15:18 --> Final output sent to browser
DEBUG - 2023-11-01 09:15:18 --> Total execution time: 4.1823
INFO - 2023-11-01 09:16:44 --> Config Class Initialized
INFO - 2023-11-01 09:16:44 --> Hooks Class Initialized
DEBUG - 2023-11-01 09:16:44 --> UTF-8 Support Enabled
INFO - 2023-11-01 09:16:44 --> Utf8 Class Initialized
INFO - 2023-11-01 09:16:44 --> URI Class Initialized
INFO - 2023-11-01 09:16:44 --> Router Class Initialized
INFO - 2023-11-01 09:16:44 --> Output Class Initialized
INFO - 2023-11-01 09:16:44 --> Security Class Initialized
DEBUG - 2023-11-01 09:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 09:16:44 --> Input Class Initialized
INFO - 2023-11-01 09:16:44 --> Language Class Initialized
INFO - 2023-11-01 09:16:44 --> Language Class Initialized
INFO - 2023-11-01 09:16:44 --> Config Class Initialized
INFO - 2023-11-01 09:16:44 --> Loader Class Initialized
INFO - 2023-11-01 09:16:44 --> Helper loaded: url_helper
INFO - 2023-11-01 09:16:44 --> Helper loaded: file_helper
INFO - 2023-11-01 09:16:44 --> Helper loaded: form_helper
INFO - 2023-11-01 09:16:44 --> Helper loaded: my_helper
INFO - 2023-11-01 09:16:44 --> Database Driver Class Initialized
INFO - 2023-11-01 09:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 09:16:44 --> Controller Class Initialized
DEBUG - 2023-11-01 09:16:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 09:16:47 --> Final output sent to browser
DEBUG - 2023-11-01 09:16:47 --> Total execution time: 3.4523
INFO - 2023-11-01 09:18:02 --> Config Class Initialized
INFO - 2023-11-01 09:18:02 --> Hooks Class Initialized
DEBUG - 2023-11-01 09:18:02 --> UTF-8 Support Enabled
INFO - 2023-11-01 09:18:02 --> Utf8 Class Initialized
INFO - 2023-11-01 09:18:02 --> URI Class Initialized
INFO - 2023-11-01 09:18:02 --> Router Class Initialized
INFO - 2023-11-01 09:18:02 --> Output Class Initialized
INFO - 2023-11-01 09:18:02 --> Security Class Initialized
DEBUG - 2023-11-01 09:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 09:18:02 --> Input Class Initialized
INFO - 2023-11-01 09:18:02 --> Language Class Initialized
INFO - 2023-11-01 09:18:02 --> Language Class Initialized
INFO - 2023-11-01 09:18:02 --> Config Class Initialized
INFO - 2023-11-01 09:18:02 --> Loader Class Initialized
INFO - 2023-11-01 09:18:02 --> Helper loaded: url_helper
INFO - 2023-11-01 09:18:02 --> Helper loaded: file_helper
INFO - 2023-11-01 09:18:02 --> Helper loaded: form_helper
INFO - 2023-11-01 09:18:02 --> Helper loaded: my_helper
INFO - 2023-11-01 09:18:02 --> Database Driver Class Initialized
INFO - 2023-11-01 09:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 09:18:02 --> Controller Class Initialized
DEBUG - 2023-11-01 09:18:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 09:18:06 --> Final output sent to browser
DEBUG - 2023-11-01 09:18:06 --> Total execution time: 4.7163
INFO - 2023-11-01 09:19:20 --> Config Class Initialized
INFO - 2023-11-01 09:19:20 --> Hooks Class Initialized
DEBUG - 2023-11-01 09:19:20 --> UTF-8 Support Enabled
INFO - 2023-11-01 09:19:20 --> Utf8 Class Initialized
INFO - 2023-11-01 09:19:20 --> URI Class Initialized
INFO - 2023-11-01 09:19:20 --> Router Class Initialized
INFO - 2023-11-01 09:19:20 --> Output Class Initialized
INFO - 2023-11-01 09:19:20 --> Security Class Initialized
DEBUG - 2023-11-01 09:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 09:19:20 --> Input Class Initialized
INFO - 2023-11-01 09:19:20 --> Language Class Initialized
INFO - 2023-11-01 09:19:20 --> Language Class Initialized
INFO - 2023-11-01 09:19:20 --> Config Class Initialized
INFO - 2023-11-01 09:19:20 --> Loader Class Initialized
INFO - 2023-11-01 09:19:20 --> Helper loaded: url_helper
INFO - 2023-11-01 09:19:20 --> Helper loaded: file_helper
INFO - 2023-11-01 09:19:20 --> Helper loaded: form_helper
INFO - 2023-11-01 09:19:20 --> Helper loaded: my_helper
INFO - 2023-11-01 09:19:20 --> Database Driver Class Initialized
INFO - 2023-11-01 09:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 09:19:20 --> Controller Class Initialized
DEBUG - 2023-11-01 09:19:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 09:19:24 --> Final output sent to browser
DEBUG - 2023-11-01 09:19:24 --> Total execution time: 4.2845
INFO - 2023-11-01 09:20:40 --> Config Class Initialized
INFO - 2023-11-01 09:20:40 --> Hooks Class Initialized
DEBUG - 2023-11-01 09:20:40 --> UTF-8 Support Enabled
INFO - 2023-11-01 09:20:40 --> Utf8 Class Initialized
INFO - 2023-11-01 09:20:40 --> URI Class Initialized
INFO - 2023-11-01 09:20:40 --> Router Class Initialized
INFO - 2023-11-01 09:20:40 --> Output Class Initialized
INFO - 2023-11-01 09:20:40 --> Security Class Initialized
DEBUG - 2023-11-01 09:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 09:20:40 --> Input Class Initialized
INFO - 2023-11-01 09:20:40 --> Language Class Initialized
INFO - 2023-11-01 09:20:40 --> Language Class Initialized
INFO - 2023-11-01 09:20:40 --> Config Class Initialized
INFO - 2023-11-01 09:20:40 --> Loader Class Initialized
INFO - 2023-11-01 09:20:40 --> Helper loaded: url_helper
INFO - 2023-11-01 09:20:40 --> Helper loaded: file_helper
INFO - 2023-11-01 09:20:40 --> Helper loaded: form_helper
INFO - 2023-11-01 09:20:40 --> Helper loaded: my_helper
INFO - 2023-11-01 09:20:40 --> Database Driver Class Initialized
INFO - 2023-11-01 09:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 09:20:40 --> Controller Class Initialized
DEBUG - 2023-11-01 09:20:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 09:20:43 --> Final output sent to browser
DEBUG - 2023-11-01 09:20:43 --> Total execution time: 3.4951
INFO - 2023-11-01 09:22:03 --> Config Class Initialized
INFO - 2023-11-01 09:22:03 --> Hooks Class Initialized
DEBUG - 2023-11-01 09:22:03 --> UTF-8 Support Enabled
INFO - 2023-11-01 09:22:03 --> Utf8 Class Initialized
INFO - 2023-11-01 09:22:03 --> URI Class Initialized
INFO - 2023-11-01 09:22:03 --> Router Class Initialized
INFO - 2023-11-01 09:22:03 --> Output Class Initialized
INFO - 2023-11-01 09:22:03 --> Security Class Initialized
DEBUG - 2023-11-01 09:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 09:22:03 --> Input Class Initialized
INFO - 2023-11-01 09:22:03 --> Language Class Initialized
INFO - 2023-11-01 09:22:03 --> Language Class Initialized
INFO - 2023-11-01 09:22:03 --> Config Class Initialized
INFO - 2023-11-01 09:22:03 --> Loader Class Initialized
INFO - 2023-11-01 09:22:03 --> Helper loaded: url_helper
INFO - 2023-11-01 09:22:03 --> Helper loaded: file_helper
INFO - 2023-11-01 09:22:03 --> Helper loaded: form_helper
INFO - 2023-11-01 09:22:03 --> Helper loaded: my_helper
INFO - 2023-11-01 09:22:03 --> Database Driver Class Initialized
INFO - 2023-11-01 09:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 09:22:03 --> Controller Class Initialized
DEBUG - 2023-11-01 09:22:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 09:22:07 --> Final output sent to browser
DEBUG - 2023-11-01 09:22:07 --> Total execution time: 3.9875
INFO - 2023-11-01 09:23:32 --> Config Class Initialized
INFO - 2023-11-01 09:23:32 --> Hooks Class Initialized
DEBUG - 2023-11-01 09:23:32 --> UTF-8 Support Enabled
INFO - 2023-11-01 09:23:32 --> Utf8 Class Initialized
INFO - 2023-11-01 09:23:32 --> URI Class Initialized
INFO - 2023-11-01 09:23:32 --> Router Class Initialized
INFO - 2023-11-01 09:23:32 --> Output Class Initialized
INFO - 2023-11-01 09:23:32 --> Security Class Initialized
DEBUG - 2023-11-01 09:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 09:23:32 --> Input Class Initialized
INFO - 2023-11-01 09:23:32 --> Language Class Initialized
INFO - 2023-11-01 09:23:32 --> Language Class Initialized
INFO - 2023-11-01 09:23:32 --> Config Class Initialized
INFO - 2023-11-01 09:23:32 --> Loader Class Initialized
INFO - 2023-11-01 09:23:32 --> Helper loaded: url_helper
INFO - 2023-11-01 09:23:32 --> Helper loaded: file_helper
INFO - 2023-11-01 09:23:32 --> Helper loaded: form_helper
INFO - 2023-11-01 09:23:32 --> Helper loaded: my_helper
INFO - 2023-11-01 09:23:32 --> Database Driver Class Initialized
INFO - 2023-11-01 09:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 09:23:32 --> Controller Class Initialized
DEBUG - 2023-11-01 09:23:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-01 09:23:36 --> Final output sent to browser
DEBUG - 2023-11-01 09:23:36 --> Total execution time: 4.0945
INFO - 2023-11-01 09:31:31 --> Config Class Initialized
INFO - 2023-11-01 09:31:31 --> Hooks Class Initialized
DEBUG - 2023-11-01 09:31:31 --> UTF-8 Support Enabled
INFO - 2023-11-01 09:31:31 --> Utf8 Class Initialized
INFO - 2023-11-01 09:31:31 --> URI Class Initialized
INFO - 2023-11-01 09:31:31 --> Router Class Initialized
INFO - 2023-11-01 09:31:31 --> Output Class Initialized
INFO - 2023-11-01 09:31:31 --> Security Class Initialized
DEBUG - 2023-11-01 09:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 09:31:31 --> Input Class Initialized
INFO - 2023-11-01 09:31:31 --> Language Class Initialized
INFO - 2023-11-01 09:31:31 --> Language Class Initialized
INFO - 2023-11-01 09:31:31 --> Config Class Initialized
INFO - 2023-11-01 09:31:31 --> Loader Class Initialized
INFO - 2023-11-01 09:31:31 --> Helper loaded: url_helper
INFO - 2023-11-01 09:31:31 --> Helper loaded: file_helper
INFO - 2023-11-01 09:31:31 --> Helper loaded: form_helper
INFO - 2023-11-01 09:31:31 --> Helper loaded: my_helper
INFO - 2023-11-01 09:31:31 --> Database Driver Class Initialized
INFO - 2023-11-01 09:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 09:31:31 --> Controller Class Initialized
DEBUG - 2023-11-01 09:31:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-11-01 09:31:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-01 09:31:31 --> Final output sent to browser
DEBUG - 2023-11-01 09:31:31 --> Total execution time: 0.1156
INFO - 2023-11-01 09:31:34 --> Config Class Initialized
INFO - 2023-11-01 09:31:34 --> Hooks Class Initialized
DEBUG - 2023-11-01 09:31:34 --> UTF-8 Support Enabled
INFO - 2023-11-01 09:31:34 --> Utf8 Class Initialized
INFO - 2023-11-01 09:31:34 --> URI Class Initialized
INFO - 2023-11-01 09:31:34 --> Router Class Initialized
INFO - 2023-11-01 09:31:34 --> Output Class Initialized
INFO - 2023-11-01 09:31:34 --> Security Class Initialized
DEBUG - 2023-11-01 09:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 09:31:34 --> Input Class Initialized
INFO - 2023-11-01 09:31:34 --> Language Class Initialized
INFO - 2023-11-01 09:31:34 --> Language Class Initialized
INFO - 2023-11-01 09:31:34 --> Config Class Initialized
INFO - 2023-11-01 09:31:34 --> Loader Class Initialized
INFO - 2023-11-01 09:31:34 --> Helper loaded: url_helper
INFO - 2023-11-01 09:31:34 --> Helper loaded: file_helper
INFO - 2023-11-01 09:31:34 --> Helper loaded: form_helper
INFO - 2023-11-01 09:31:34 --> Helper loaded: my_helper
INFO - 2023-11-01 09:31:34 --> Database Driver Class Initialized
INFO - 2023-11-01 09:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 09:31:34 --> Controller Class Initialized
DEBUG - 2023-11-01 09:31:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_sampul1.php
INFO - 2023-11-01 09:31:34 --> Final output sent to browser
DEBUG - 2023-11-01 09:31:34 --> Total execution time: 0.0502
INFO - 2023-11-01 09:31:42 --> Config Class Initialized
INFO - 2023-11-01 09:31:42 --> Hooks Class Initialized
DEBUG - 2023-11-01 09:31:42 --> UTF-8 Support Enabled
INFO - 2023-11-01 09:31:42 --> Utf8 Class Initialized
INFO - 2023-11-01 09:31:42 --> URI Class Initialized
INFO - 2023-11-01 09:31:42 --> Router Class Initialized
INFO - 2023-11-01 09:31:42 --> Output Class Initialized
INFO - 2023-11-01 09:31:42 --> Security Class Initialized
DEBUG - 2023-11-01 09:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 09:31:42 --> Input Class Initialized
INFO - 2023-11-01 09:31:42 --> Language Class Initialized
INFO - 2023-11-01 09:31:42 --> Language Class Initialized
INFO - 2023-11-01 09:31:42 --> Config Class Initialized
INFO - 2023-11-01 09:31:42 --> Loader Class Initialized
INFO - 2023-11-01 09:31:42 --> Helper loaded: url_helper
INFO - 2023-11-01 09:31:42 --> Helper loaded: file_helper
INFO - 2023-11-01 09:31:42 --> Helper loaded: form_helper
INFO - 2023-11-01 09:31:42 --> Helper loaded: my_helper
INFO - 2023-11-01 09:31:42 --> Database Driver Class Initialized
INFO - 2023-11-01 09:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 09:31:42 --> Controller Class Initialized
DEBUG - 2023-11-01 09:31:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_sampul2.php
INFO - 2023-11-01 09:31:42 --> Final output sent to browser
DEBUG - 2023-11-01 09:31:42 --> Total execution time: 0.0484
INFO - 2023-11-01 09:31:49 --> Config Class Initialized
INFO - 2023-11-01 09:31:49 --> Hooks Class Initialized
DEBUG - 2023-11-01 09:31:49 --> UTF-8 Support Enabled
INFO - 2023-11-01 09:31:49 --> Utf8 Class Initialized
INFO - 2023-11-01 09:31:49 --> URI Class Initialized
INFO - 2023-11-01 09:31:49 --> Router Class Initialized
INFO - 2023-11-01 09:31:49 --> Output Class Initialized
INFO - 2023-11-01 09:31:49 --> Security Class Initialized
DEBUG - 2023-11-01 09:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 09:31:49 --> Input Class Initialized
INFO - 2023-11-01 09:31:49 --> Language Class Initialized
INFO - 2023-11-01 09:31:49 --> Language Class Initialized
INFO - 2023-11-01 09:31:49 --> Config Class Initialized
INFO - 2023-11-01 09:31:49 --> Loader Class Initialized
INFO - 2023-11-01 09:31:49 --> Helper loaded: url_helper
INFO - 2023-11-01 09:31:49 --> Helper loaded: file_helper
INFO - 2023-11-01 09:31:49 --> Helper loaded: form_helper
INFO - 2023-11-01 09:31:49 --> Helper loaded: my_helper
INFO - 2023-11-01 09:31:49 --> Database Driver Class Initialized
INFO - 2023-11-01 09:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 09:31:49 --> Controller Class Initialized
DEBUG - 2023-11-01 09:31:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_sampul4.php
INFO - 2023-11-01 09:31:49 --> Final output sent to browser
DEBUG - 2023-11-01 09:31:49 --> Total execution time: 0.1240
INFO - 2023-11-01 09:32:16 --> Config Class Initialized
INFO - 2023-11-01 09:32:16 --> Hooks Class Initialized
DEBUG - 2023-11-01 09:32:16 --> UTF-8 Support Enabled
INFO - 2023-11-01 09:32:16 --> Utf8 Class Initialized
INFO - 2023-11-01 09:32:16 --> URI Class Initialized
INFO - 2023-11-01 09:32:16 --> Router Class Initialized
INFO - 2023-11-01 09:32:16 --> Output Class Initialized
INFO - 2023-11-01 09:32:16 --> Security Class Initialized
DEBUG - 2023-11-01 09:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 09:32:16 --> Input Class Initialized
INFO - 2023-11-01 09:32:16 --> Language Class Initialized
INFO - 2023-11-01 09:32:16 --> Language Class Initialized
INFO - 2023-11-01 09:32:16 --> Config Class Initialized
INFO - 2023-11-01 09:32:16 --> Loader Class Initialized
INFO - 2023-11-01 09:32:16 --> Helper loaded: url_helper
INFO - 2023-11-01 09:32:16 --> Helper loaded: file_helper
INFO - 2023-11-01 09:32:16 --> Helper loaded: form_helper
INFO - 2023-11-01 09:32:16 --> Helper loaded: my_helper
INFO - 2023-11-01 09:32:16 --> Database Driver Class Initialized
INFO - 2023-11-01 09:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 09:32:16 --> Controller Class Initialized
DEBUG - 2023-11-01 09:32:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
ERROR - 2023-11-01 09:32:16 --> Severity: error --> Exception: Unable to get the size of the image [C:\Users\sallu\Downloads\logo mh primary black.png] /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/spipu/html2pdf/src/Html2Pdf.php 1513
INFO - 2023-11-01 09:32:21 --> Config Class Initialized
INFO - 2023-11-01 09:32:21 --> Hooks Class Initialized
DEBUG - 2023-11-01 09:32:21 --> UTF-8 Support Enabled
INFO - 2023-11-01 09:32:21 --> Utf8 Class Initialized
INFO - 2023-11-01 09:32:21 --> URI Class Initialized
INFO - 2023-11-01 09:32:21 --> Router Class Initialized
INFO - 2023-11-01 09:32:21 --> Output Class Initialized
INFO - 2023-11-01 09:32:21 --> Security Class Initialized
DEBUG - 2023-11-01 09:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 09:32:21 --> Input Class Initialized
INFO - 2023-11-01 09:32:21 --> Language Class Initialized
INFO - 2023-11-01 09:32:22 --> Language Class Initialized
INFO - 2023-11-01 09:32:22 --> Config Class Initialized
INFO - 2023-11-01 09:32:22 --> Loader Class Initialized
INFO - 2023-11-01 09:32:22 --> Helper loaded: url_helper
INFO - 2023-11-01 09:32:22 --> Helper loaded: file_helper
INFO - 2023-11-01 09:32:22 --> Helper loaded: form_helper
INFO - 2023-11-01 09:32:22 --> Helper loaded: my_helper
INFO - 2023-11-01 09:32:22 --> Database Driver Class Initialized
INFO - 2023-11-01 09:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 09:32:22 --> Controller Class Initialized
DEBUG - 2023-11-01 09:32:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
ERROR - 2023-11-01 09:32:22 --> Severity: error --> Exception: Unable to get the size of the image [C:\Users\sallu\Downloads\Logo MH Transparan-01.png] /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/spipu/html2pdf/src/Html2Pdf.php 1513
INFO - 2023-11-01 09:48:47 --> Config Class Initialized
INFO - 2023-11-01 09:48:47 --> Hooks Class Initialized
DEBUG - 2023-11-01 09:48:47 --> UTF-8 Support Enabled
INFO - 2023-11-01 09:48:47 --> Utf8 Class Initialized
INFO - 2023-11-01 09:48:47 --> URI Class Initialized
INFO - 2023-11-01 09:48:47 --> Router Class Initialized
INFO - 2023-11-01 09:48:47 --> Output Class Initialized
INFO - 2023-11-01 09:48:47 --> Security Class Initialized
DEBUG - 2023-11-01 09:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 09:48:47 --> Input Class Initialized
INFO - 2023-11-01 09:48:47 --> Language Class Initialized
INFO - 2023-11-01 09:48:47 --> Language Class Initialized
INFO - 2023-11-01 09:48:47 --> Config Class Initialized
INFO - 2023-11-01 09:48:47 --> Loader Class Initialized
INFO - 2023-11-01 09:48:47 --> Helper loaded: url_helper
INFO - 2023-11-01 09:48:47 --> Helper loaded: file_helper
INFO - 2023-11-01 09:48:47 --> Helper loaded: form_helper
INFO - 2023-11-01 09:48:47 --> Helper loaded: my_helper
INFO - 2023-11-01 09:48:47 --> Database Driver Class Initialized
INFO - 2023-11-01 09:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 09:48:47 --> Controller Class Initialized
INFO - 2023-11-01 09:48:47 --> Helper loaded: cookie_helper
INFO - 2023-11-01 09:48:47 --> Config Class Initialized
INFO - 2023-11-01 09:48:47 --> Hooks Class Initialized
DEBUG - 2023-11-01 09:48:47 --> UTF-8 Support Enabled
INFO - 2023-11-01 09:48:47 --> Utf8 Class Initialized
INFO - 2023-11-01 09:48:47 --> URI Class Initialized
INFO - 2023-11-01 09:48:47 --> Router Class Initialized
INFO - 2023-11-01 09:48:47 --> Output Class Initialized
INFO - 2023-11-01 09:48:47 --> Security Class Initialized
DEBUG - 2023-11-01 09:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 09:48:47 --> Input Class Initialized
INFO - 2023-11-01 09:48:47 --> Language Class Initialized
INFO - 2023-11-01 09:48:47 --> Language Class Initialized
INFO - 2023-11-01 09:48:47 --> Config Class Initialized
INFO - 2023-11-01 09:48:47 --> Loader Class Initialized
INFO - 2023-11-01 09:48:47 --> Helper loaded: url_helper
INFO - 2023-11-01 09:48:47 --> Helper loaded: file_helper
INFO - 2023-11-01 09:48:47 --> Helper loaded: form_helper
INFO - 2023-11-01 09:48:47 --> Helper loaded: my_helper
INFO - 2023-11-01 09:48:47 --> Database Driver Class Initialized
INFO - 2023-11-01 09:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 09:48:47 --> Controller Class Initialized
INFO - 2023-11-01 09:48:47 --> Config Class Initialized
INFO - 2023-11-01 09:48:47 --> Hooks Class Initialized
DEBUG - 2023-11-01 09:48:47 --> UTF-8 Support Enabled
INFO - 2023-11-01 09:48:47 --> Utf8 Class Initialized
INFO - 2023-11-01 09:48:47 --> URI Class Initialized
INFO - 2023-11-01 09:48:47 --> Router Class Initialized
INFO - 2023-11-01 09:48:47 --> Output Class Initialized
INFO - 2023-11-01 09:48:47 --> Security Class Initialized
DEBUG - 2023-11-01 09:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 09:48:47 --> Input Class Initialized
INFO - 2023-11-01 09:48:47 --> Language Class Initialized
INFO - 2023-11-01 09:48:47 --> Language Class Initialized
INFO - 2023-11-01 09:48:47 --> Config Class Initialized
INFO - 2023-11-01 09:48:47 --> Loader Class Initialized
INFO - 2023-11-01 09:48:47 --> Helper loaded: url_helper
INFO - 2023-11-01 09:48:47 --> Helper loaded: file_helper
INFO - 2023-11-01 09:48:47 --> Helper loaded: form_helper
INFO - 2023-11-01 09:48:47 --> Helper loaded: my_helper
INFO - 2023-11-01 09:48:47 --> Database Driver Class Initialized
INFO - 2023-11-01 09:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 09:48:47 --> Controller Class Initialized
DEBUG - 2023-11-01 09:48:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-01 09:48:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-01 09:48:47 --> Final output sent to browser
DEBUG - 2023-11-01 09:48:47 --> Total execution time: 0.0442
INFO - 2023-11-01 10:34:08 --> Config Class Initialized
INFO - 2023-11-01 10:34:08 --> Hooks Class Initialized
DEBUG - 2023-11-01 10:34:08 --> UTF-8 Support Enabled
INFO - 2023-11-01 10:34:08 --> Utf8 Class Initialized
INFO - 2023-11-01 10:34:08 --> URI Class Initialized
INFO - 2023-11-01 10:34:08 --> Router Class Initialized
INFO - 2023-11-01 10:34:08 --> Output Class Initialized
INFO - 2023-11-01 10:34:08 --> Security Class Initialized
DEBUG - 2023-11-01 10:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 10:34:08 --> Input Class Initialized
INFO - 2023-11-01 10:34:08 --> Language Class Initialized
INFO - 2023-11-01 10:34:08 --> Language Class Initialized
INFO - 2023-11-01 10:34:08 --> Config Class Initialized
INFO - 2023-11-01 10:34:08 --> Loader Class Initialized
INFO - 2023-11-01 10:34:08 --> Helper loaded: url_helper
INFO - 2023-11-01 10:34:08 --> Helper loaded: file_helper
INFO - 2023-11-01 10:34:08 --> Helper loaded: form_helper
INFO - 2023-11-01 10:34:08 --> Helper loaded: my_helper
INFO - 2023-11-01 10:34:08 --> Database Driver Class Initialized
INFO - 2023-11-01 10:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 10:34:08 --> Controller Class Initialized
DEBUG - 2023-11-01 10:34:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-01 10:34:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-01 10:34:08 --> Final output sent to browser
DEBUG - 2023-11-01 10:34:08 --> Total execution time: 0.0523
INFO - 2023-11-01 10:34:10 --> Config Class Initialized
INFO - 2023-11-01 10:34:10 --> Hooks Class Initialized
DEBUG - 2023-11-01 10:34:10 --> UTF-8 Support Enabled
INFO - 2023-11-01 10:34:10 --> Utf8 Class Initialized
INFO - 2023-11-01 10:34:10 --> URI Class Initialized
INFO - 2023-11-01 10:34:10 --> Router Class Initialized
INFO - 2023-11-01 10:34:10 --> Output Class Initialized
INFO - 2023-11-01 10:34:10 --> Security Class Initialized
DEBUG - 2023-11-01 10:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 10:34:10 --> Input Class Initialized
INFO - 2023-11-01 10:34:10 --> Language Class Initialized
INFO - 2023-11-01 10:34:10 --> Language Class Initialized
INFO - 2023-11-01 10:34:10 --> Config Class Initialized
INFO - 2023-11-01 10:34:10 --> Loader Class Initialized
INFO - 2023-11-01 10:34:10 --> Helper loaded: url_helper
INFO - 2023-11-01 10:34:10 --> Helper loaded: file_helper
INFO - 2023-11-01 10:34:10 --> Helper loaded: form_helper
INFO - 2023-11-01 10:34:10 --> Helper loaded: my_helper
INFO - 2023-11-01 10:34:10 --> Database Driver Class Initialized
INFO - 2023-11-01 10:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 10:34:10 --> Controller Class Initialized
INFO - 2023-11-01 10:34:10 --> Helper loaded: cookie_helper
INFO - 2023-11-01 10:34:10 --> Final output sent to browser
DEBUG - 2023-11-01 10:34:10 --> Total execution time: 0.0493
INFO - 2023-11-01 10:34:10 --> Config Class Initialized
INFO - 2023-11-01 10:34:10 --> Hooks Class Initialized
DEBUG - 2023-11-01 10:34:10 --> UTF-8 Support Enabled
INFO - 2023-11-01 10:34:10 --> Utf8 Class Initialized
INFO - 2023-11-01 10:34:10 --> URI Class Initialized
INFO - 2023-11-01 10:34:10 --> Router Class Initialized
INFO - 2023-11-01 10:34:10 --> Output Class Initialized
INFO - 2023-11-01 10:34:10 --> Security Class Initialized
DEBUG - 2023-11-01 10:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 10:34:10 --> Input Class Initialized
INFO - 2023-11-01 10:34:10 --> Language Class Initialized
INFO - 2023-11-01 10:34:10 --> Language Class Initialized
INFO - 2023-11-01 10:34:10 --> Config Class Initialized
INFO - 2023-11-01 10:34:10 --> Loader Class Initialized
INFO - 2023-11-01 10:34:10 --> Helper loaded: url_helper
INFO - 2023-11-01 10:34:10 --> Helper loaded: file_helper
INFO - 2023-11-01 10:34:10 --> Helper loaded: form_helper
INFO - 2023-11-01 10:34:10 --> Helper loaded: my_helper
INFO - 2023-11-01 10:34:10 --> Database Driver Class Initialized
INFO - 2023-11-01 10:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 10:34:11 --> Controller Class Initialized
DEBUG - 2023-11-01 10:34:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-01 10:34:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-01 10:34:11 --> Final output sent to browser
DEBUG - 2023-11-01 10:34:11 --> Total execution time: 0.0387
INFO - 2023-11-01 10:34:20 --> Config Class Initialized
INFO - 2023-11-01 10:34:20 --> Hooks Class Initialized
DEBUG - 2023-11-01 10:34:20 --> UTF-8 Support Enabled
INFO - 2023-11-01 10:34:20 --> Utf8 Class Initialized
INFO - 2023-11-01 10:34:20 --> URI Class Initialized
INFO - 2023-11-01 10:34:20 --> Router Class Initialized
INFO - 2023-11-01 10:34:20 --> Output Class Initialized
INFO - 2023-11-01 10:34:20 --> Security Class Initialized
DEBUG - 2023-11-01 10:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 10:34:20 --> Input Class Initialized
INFO - 2023-11-01 10:34:20 --> Language Class Initialized
INFO - 2023-11-01 10:34:20 --> Language Class Initialized
INFO - 2023-11-01 10:34:20 --> Config Class Initialized
INFO - 2023-11-01 10:34:20 --> Loader Class Initialized
INFO - 2023-11-01 10:34:20 --> Helper loaded: url_helper
INFO - 2023-11-01 10:34:20 --> Helper loaded: file_helper
INFO - 2023-11-01 10:34:20 --> Helper loaded: form_helper
INFO - 2023-11-01 10:34:20 --> Helper loaded: my_helper
INFO - 2023-11-01 10:34:20 --> Database Driver Class Initialized
INFO - 2023-11-01 10:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 10:34:20 --> Controller Class Initialized
DEBUG - 2023-11-01 10:34:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-11-01 10:34:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-01 10:34:20 --> Final output sent to browser
DEBUG - 2023-11-01 10:34:20 --> Total execution time: 0.1360
INFO - 2023-11-01 10:34:22 --> Config Class Initialized
INFO - 2023-11-01 10:34:22 --> Hooks Class Initialized
DEBUG - 2023-11-01 10:34:22 --> UTF-8 Support Enabled
INFO - 2023-11-01 10:34:22 --> Utf8 Class Initialized
INFO - 2023-11-01 10:34:22 --> URI Class Initialized
INFO - 2023-11-01 10:34:22 --> Router Class Initialized
INFO - 2023-11-01 10:34:22 --> Output Class Initialized
INFO - 2023-11-01 10:34:22 --> Security Class Initialized
DEBUG - 2023-11-01 10:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 10:34:22 --> Input Class Initialized
INFO - 2023-11-01 10:34:22 --> Language Class Initialized
INFO - 2023-11-01 10:34:22 --> Language Class Initialized
INFO - 2023-11-01 10:34:22 --> Config Class Initialized
INFO - 2023-11-01 10:34:22 --> Loader Class Initialized
INFO - 2023-11-01 10:34:22 --> Helper loaded: url_helper
INFO - 2023-11-01 10:34:22 --> Helper loaded: file_helper
INFO - 2023-11-01 10:34:22 --> Helper loaded: form_helper
INFO - 2023-11-01 10:34:22 --> Helper loaded: my_helper
INFO - 2023-11-01 10:34:22 --> Database Driver Class Initialized
INFO - 2023-11-01 10:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 10:34:22 --> Controller Class Initialized
DEBUG - 2023-11-01 10:34:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_sampul1.php
INFO - 2023-11-01 10:34:22 --> Final output sent to browser
DEBUG - 2023-11-01 10:34:22 --> Total execution time: 0.0480
INFO - 2023-11-01 10:35:31 --> Config Class Initialized
INFO - 2023-11-01 10:35:31 --> Hooks Class Initialized
DEBUG - 2023-11-01 10:35:31 --> UTF-8 Support Enabled
INFO - 2023-11-01 10:35:31 --> Utf8 Class Initialized
INFO - 2023-11-01 10:35:31 --> URI Class Initialized
INFO - 2023-11-01 10:35:31 --> Router Class Initialized
INFO - 2023-11-01 10:35:31 --> Output Class Initialized
INFO - 2023-11-01 10:35:31 --> Security Class Initialized
DEBUG - 2023-11-01 10:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 10:35:31 --> Input Class Initialized
INFO - 2023-11-01 10:35:31 --> Language Class Initialized
INFO - 2023-11-01 10:35:31 --> Language Class Initialized
INFO - 2023-11-01 10:35:31 --> Config Class Initialized
INFO - 2023-11-01 10:35:31 --> Loader Class Initialized
INFO - 2023-11-01 10:35:31 --> Helper loaded: url_helper
INFO - 2023-11-01 10:35:31 --> Helper loaded: file_helper
INFO - 2023-11-01 10:35:31 --> Helper loaded: form_helper
INFO - 2023-11-01 10:35:31 --> Helper loaded: my_helper
INFO - 2023-11-01 10:35:31 --> Database Driver Class Initialized
INFO - 2023-11-01 10:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 10:35:31 --> Controller Class Initialized
DEBUG - 2023-11-01 10:35:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_sampul2.php
INFO - 2023-11-01 10:35:31 --> Final output sent to browser
DEBUG - 2023-11-01 10:35:31 --> Total execution time: 0.0441
INFO - 2023-11-01 10:36:24 --> Config Class Initialized
INFO - 2023-11-01 10:36:24 --> Hooks Class Initialized
DEBUG - 2023-11-01 10:36:24 --> UTF-8 Support Enabled
INFO - 2023-11-01 10:36:24 --> Utf8 Class Initialized
INFO - 2023-11-01 10:36:24 --> URI Class Initialized
INFO - 2023-11-01 10:36:24 --> Router Class Initialized
INFO - 2023-11-01 10:36:24 --> Output Class Initialized
INFO - 2023-11-01 10:36:24 --> Security Class Initialized
DEBUG - 2023-11-01 10:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-01 10:36:24 --> Input Class Initialized
INFO - 2023-11-01 10:36:24 --> Language Class Initialized
INFO - 2023-11-01 10:36:24 --> Language Class Initialized
INFO - 2023-11-01 10:36:24 --> Config Class Initialized
INFO - 2023-11-01 10:36:24 --> Loader Class Initialized
INFO - 2023-11-01 10:36:24 --> Helper loaded: url_helper
INFO - 2023-11-01 10:36:24 --> Helper loaded: file_helper
INFO - 2023-11-01 10:36:24 --> Helper loaded: form_helper
INFO - 2023-11-01 10:36:24 --> Helper loaded: my_helper
INFO - 2023-11-01 10:36:24 --> Database Driver Class Initialized
INFO - 2023-11-01 10:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-01 10:36:24 --> Controller Class Initialized
DEBUG - 2023-11-01 10:36:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_sampul4.php
INFO - 2023-11-01 10:36:24 --> Final output sent to browser
DEBUG - 2023-11-01 10:36:24 --> Total execution time: 0.0460
