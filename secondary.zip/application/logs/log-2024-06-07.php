<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-07 07:55:40 --> Config Class Initialized
INFO - 2024-06-07 07:55:40 --> Hooks Class Initialized
DEBUG - 2024-06-07 07:55:40 --> UTF-8 Support Enabled
INFO - 2024-06-07 07:55:40 --> Utf8 Class Initialized
INFO - 2024-06-07 07:55:40 --> URI Class Initialized
INFO - 2024-06-07 07:55:40 --> Router Class Initialized
INFO - 2024-06-07 07:55:40 --> Output Class Initialized
INFO - 2024-06-07 07:55:40 --> Security Class Initialized
DEBUG - 2024-06-07 07:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 07:55:40 --> Input Class Initialized
INFO - 2024-06-07 07:55:40 --> Language Class Initialized
INFO - 2024-06-07 07:55:40 --> Language Class Initialized
INFO - 2024-06-07 07:55:40 --> Config Class Initialized
INFO - 2024-06-07 07:55:40 --> Loader Class Initialized
INFO - 2024-06-07 07:55:40 --> Helper loaded: url_helper
INFO - 2024-06-07 07:55:40 --> Helper loaded: file_helper
INFO - 2024-06-07 07:55:40 --> Helper loaded: form_helper
INFO - 2024-06-07 07:55:40 --> Helper loaded: my_helper
INFO - 2024-06-07 07:55:40 --> Database Driver Class Initialized
INFO - 2024-06-07 07:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 07:55:40 --> Controller Class Initialized
INFO - 2024-06-07 07:57:31 --> Config Class Initialized
INFO - 2024-06-07 07:57:31 --> Hooks Class Initialized
DEBUG - 2024-06-07 07:57:31 --> UTF-8 Support Enabled
INFO - 2024-06-07 07:57:31 --> Utf8 Class Initialized
INFO - 2024-06-07 07:57:31 --> URI Class Initialized
INFO - 2024-06-07 07:57:31 --> Router Class Initialized
INFO - 2024-06-07 07:57:31 --> Output Class Initialized
INFO - 2024-06-07 07:57:31 --> Security Class Initialized
DEBUG - 2024-06-07 07:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 07:57:31 --> Input Class Initialized
INFO - 2024-06-07 07:57:31 --> Language Class Initialized
INFO - 2024-06-07 07:57:31 --> Language Class Initialized
INFO - 2024-06-07 07:57:31 --> Config Class Initialized
INFO - 2024-06-07 07:57:31 --> Loader Class Initialized
INFO - 2024-06-07 07:57:31 --> Helper loaded: url_helper
INFO - 2024-06-07 07:57:31 --> Helper loaded: file_helper
INFO - 2024-06-07 07:57:31 --> Helper loaded: form_helper
INFO - 2024-06-07 07:57:31 --> Helper loaded: my_helper
INFO - 2024-06-07 07:57:31 --> Database Driver Class Initialized
INFO - 2024-06-07 07:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 07:57:31 --> Controller Class Initialized
DEBUG - 2024-06-07 07:57:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-07 07:57:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 07:57:31 --> Final output sent to browser
DEBUG - 2024-06-07 07:57:31 --> Total execution time: 0.1277
INFO - 2024-06-07 07:57:36 --> Config Class Initialized
INFO - 2024-06-07 07:57:36 --> Hooks Class Initialized
DEBUG - 2024-06-07 07:57:36 --> UTF-8 Support Enabled
INFO - 2024-06-07 07:57:36 --> Utf8 Class Initialized
INFO - 2024-06-07 07:57:36 --> URI Class Initialized
INFO - 2024-06-07 07:57:36 --> Router Class Initialized
INFO - 2024-06-07 07:57:36 --> Output Class Initialized
INFO - 2024-06-07 07:57:36 --> Security Class Initialized
DEBUG - 2024-06-07 07:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 07:57:36 --> Input Class Initialized
INFO - 2024-06-07 07:57:36 --> Language Class Initialized
INFO - 2024-06-07 07:57:36 --> Language Class Initialized
INFO - 2024-06-07 07:57:36 --> Config Class Initialized
INFO - 2024-06-07 07:57:36 --> Loader Class Initialized
INFO - 2024-06-07 07:57:36 --> Helper loaded: url_helper
INFO - 2024-06-07 07:57:36 --> Helper loaded: file_helper
INFO - 2024-06-07 07:57:36 --> Helper loaded: form_helper
INFO - 2024-06-07 07:57:36 --> Helper loaded: my_helper
INFO - 2024-06-07 07:57:36 --> Database Driver Class Initialized
INFO - 2024-06-07 07:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 07:57:36 --> Controller Class Initialized
INFO - 2024-06-07 07:57:36 --> Helper loaded: cookie_helper
INFO - 2024-06-07 07:57:36 --> Final output sent to browser
DEBUG - 2024-06-07 07:57:36 --> Total execution time: 0.0308
INFO - 2024-06-07 07:57:36 --> Config Class Initialized
INFO - 2024-06-07 07:57:36 --> Hooks Class Initialized
DEBUG - 2024-06-07 07:57:36 --> UTF-8 Support Enabled
INFO - 2024-06-07 07:57:36 --> Utf8 Class Initialized
INFO - 2024-06-07 07:57:36 --> URI Class Initialized
INFO - 2024-06-07 07:57:36 --> Router Class Initialized
INFO - 2024-06-07 07:57:36 --> Output Class Initialized
INFO - 2024-06-07 07:57:36 --> Security Class Initialized
DEBUG - 2024-06-07 07:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 07:57:36 --> Input Class Initialized
INFO - 2024-06-07 07:57:36 --> Language Class Initialized
INFO - 2024-06-07 07:57:36 --> Language Class Initialized
INFO - 2024-06-07 07:57:36 --> Config Class Initialized
INFO - 2024-06-07 07:57:36 --> Loader Class Initialized
INFO - 2024-06-07 07:57:36 --> Helper loaded: url_helper
INFO - 2024-06-07 07:57:36 --> Helper loaded: file_helper
INFO - 2024-06-07 07:57:36 --> Helper loaded: form_helper
INFO - 2024-06-07 07:57:36 --> Helper loaded: my_helper
INFO - 2024-06-07 07:57:36 --> Database Driver Class Initialized
INFO - 2024-06-07 07:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 07:57:36 --> Controller Class Initialized
DEBUG - 2024-06-07 07:57:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-07 07:57:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 07:57:36 --> Final output sent to browser
DEBUG - 2024-06-07 07:57:36 --> Total execution time: 0.0423
INFO - 2024-06-07 07:57:40 --> Config Class Initialized
INFO - 2024-06-07 07:57:40 --> Hooks Class Initialized
DEBUG - 2024-06-07 07:57:40 --> UTF-8 Support Enabled
INFO - 2024-06-07 07:57:40 --> Utf8 Class Initialized
INFO - 2024-06-07 07:57:40 --> URI Class Initialized
INFO - 2024-06-07 07:57:40 --> Router Class Initialized
INFO - 2024-06-07 07:57:40 --> Output Class Initialized
INFO - 2024-06-07 07:57:40 --> Security Class Initialized
DEBUG - 2024-06-07 07:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 07:57:40 --> Input Class Initialized
INFO - 2024-06-07 07:57:40 --> Language Class Initialized
INFO - 2024-06-07 07:57:40 --> Language Class Initialized
INFO - 2024-06-07 07:57:40 --> Config Class Initialized
INFO - 2024-06-07 07:57:40 --> Loader Class Initialized
INFO - 2024-06-07 07:57:40 --> Helper loaded: url_helper
INFO - 2024-06-07 07:57:40 --> Helper loaded: file_helper
INFO - 2024-06-07 07:57:40 --> Helper loaded: form_helper
INFO - 2024-06-07 07:57:40 --> Helper loaded: my_helper
INFO - 2024-06-07 07:57:40 --> Database Driver Class Initialized
INFO - 2024-06-07 07:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 07:57:40 --> Controller Class Initialized
ERROR - 2024-06-07 07:57:40 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-07 07:57:40 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-07 07:57:40 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-07 07:57:40 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-07 07:57:40 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-07 07:57:40 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-07 07:57:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-07 07:57:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 07:57:40 --> Final output sent to browser
DEBUG - 2024-06-07 07:57:40 --> Total execution time: 0.0524
INFO - 2024-06-07 07:58:12 --> Config Class Initialized
INFO - 2024-06-07 07:58:12 --> Hooks Class Initialized
DEBUG - 2024-06-07 07:58:12 --> UTF-8 Support Enabled
INFO - 2024-06-07 07:58:12 --> Utf8 Class Initialized
INFO - 2024-06-07 07:58:12 --> URI Class Initialized
INFO - 2024-06-07 07:58:12 --> Router Class Initialized
INFO - 2024-06-07 07:58:12 --> Output Class Initialized
INFO - 2024-06-07 07:58:12 --> Security Class Initialized
DEBUG - 2024-06-07 07:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 07:58:12 --> Input Class Initialized
INFO - 2024-06-07 07:58:12 --> Language Class Initialized
INFO - 2024-06-07 07:58:12 --> Language Class Initialized
INFO - 2024-06-07 07:58:12 --> Config Class Initialized
INFO - 2024-06-07 07:58:12 --> Loader Class Initialized
INFO - 2024-06-07 07:58:12 --> Helper loaded: url_helper
INFO - 2024-06-07 07:58:12 --> Helper loaded: file_helper
INFO - 2024-06-07 07:58:12 --> Helper loaded: form_helper
INFO - 2024-06-07 07:58:12 --> Helper loaded: my_helper
INFO - 2024-06-07 07:58:12 --> Database Driver Class Initialized
INFO - 2024-06-07 07:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 07:58:12 --> Controller Class Initialized
DEBUG - 2024-06-07 07:58:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2024-06-07 07:58:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 07:58:12 --> Final output sent to browser
DEBUG - 2024-06-07 07:58:12 --> Total execution time: 0.0345
INFO - 2024-06-07 07:58:12 --> Config Class Initialized
INFO - 2024-06-07 07:58:12 --> Hooks Class Initialized
DEBUG - 2024-06-07 07:58:12 --> UTF-8 Support Enabled
INFO - 2024-06-07 07:58:12 --> Utf8 Class Initialized
INFO - 2024-06-07 07:58:12 --> URI Class Initialized
INFO - 2024-06-07 07:58:12 --> Router Class Initialized
INFO - 2024-06-07 07:58:12 --> Output Class Initialized
INFO - 2024-06-07 07:58:12 --> Security Class Initialized
DEBUG - 2024-06-07 07:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 07:58:12 --> Input Class Initialized
INFO - 2024-06-07 07:58:12 --> Language Class Initialized
INFO - 2024-06-07 07:58:12 --> Language Class Initialized
INFO - 2024-06-07 07:58:12 --> Config Class Initialized
INFO - 2024-06-07 07:58:12 --> Loader Class Initialized
INFO - 2024-06-07 07:58:12 --> Helper loaded: url_helper
INFO - 2024-06-07 07:58:12 --> Helper loaded: file_helper
INFO - 2024-06-07 07:58:12 --> Helper loaded: form_helper
INFO - 2024-06-07 07:58:12 --> Helper loaded: my_helper
INFO - 2024-06-07 07:58:12 --> Database Driver Class Initialized
INFO - 2024-06-07 07:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 07:58:12 --> Controller Class Initialized
INFO - 2024-06-07 07:58:16 --> Config Class Initialized
INFO - 2024-06-07 07:58:16 --> Hooks Class Initialized
DEBUG - 2024-06-07 07:58:16 --> UTF-8 Support Enabled
INFO - 2024-06-07 07:58:16 --> Utf8 Class Initialized
INFO - 2024-06-07 07:58:16 --> URI Class Initialized
INFO - 2024-06-07 07:58:16 --> Router Class Initialized
INFO - 2024-06-07 07:58:16 --> Output Class Initialized
INFO - 2024-06-07 07:58:16 --> Security Class Initialized
DEBUG - 2024-06-07 07:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 07:58:16 --> Input Class Initialized
INFO - 2024-06-07 07:58:16 --> Language Class Initialized
INFO - 2024-06-07 07:58:16 --> Language Class Initialized
INFO - 2024-06-07 07:58:16 --> Config Class Initialized
INFO - 2024-06-07 07:58:16 --> Loader Class Initialized
INFO - 2024-06-07 07:58:16 --> Helper loaded: url_helper
INFO - 2024-06-07 07:58:16 --> Helper loaded: file_helper
INFO - 2024-06-07 07:58:16 --> Helper loaded: form_helper
INFO - 2024-06-07 07:58:16 --> Helper loaded: my_helper
INFO - 2024-06-07 07:58:16 --> Database Driver Class Initialized
INFO - 2024-06-07 07:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 07:58:16 --> Controller Class Initialized
ERROR - 2024-06-07 07:58:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-07 07:58:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-07 07:58:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-07 07:58:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-07 07:58:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-07 07:58:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-07 07:58:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-07 07:58:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 07:58:16 --> Final output sent to browser
DEBUG - 2024-06-07 07:58:16 --> Total execution time: 0.0518
INFO - 2024-06-07 07:59:07 --> Config Class Initialized
INFO - 2024-06-07 07:59:07 --> Hooks Class Initialized
DEBUG - 2024-06-07 07:59:07 --> UTF-8 Support Enabled
INFO - 2024-06-07 07:59:07 --> Utf8 Class Initialized
INFO - 2024-06-07 07:59:07 --> URI Class Initialized
INFO - 2024-06-07 07:59:07 --> Router Class Initialized
INFO - 2024-06-07 07:59:07 --> Output Class Initialized
INFO - 2024-06-07 07:59:07 --> Security Class Initialized
DEBUG - 2024-06-07 07:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 07:59:07 --> Input Class Initialized
INFO - 2024-06-07 07:59:07 --> Language Class Initialized
INFO - 2024-06-07 07:59:07 --> Language Class Initialized
INFO - 2024-06-07 07:59:07 --> Config Class Initialized
INFO - 2024-06-07 07:59:07 --> Loader Class Initialized
INFO - 2024-06-07 07:59:07 --> Helper loaded: url_helper
INFO - 2024-06-07 07:59:07 --> Helper loaded: file_helper
INFO - 2024-06-07 07:59:07 --> Helper loaded: form_helper
INFO - 2024-06-07 07:59:07 --> Helper loaded: my_helper
INFO - 2024-06-07 07:59:07 --> Database Driver Class Initialized
INFO - 2024-06-07 07:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 07:59:07 --> Controller Class Initialized
DEBUG - 2024-06-07 07:59:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2024-06-07 07:59:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 07:59:07 --> Final output sent to browser
DEBUG - 2024-06-07 07:59:07 --> Total execution time: 0.0265
INFO - 2024-06-07 07:59:07 --> Config Class Initialized
INFO - 2024-06-07 07:59:07 --> Hooks Class Initialized
DEBUG - 2024-06-07 07:59:07 --> UTF-8 Support Enabled
INFO - 2024-06-07 07:59:07 --> Utf8 Class Initialized
INFO - 2024-06-07 07:59:07 --> URI Class Initialized
INFO - 2024-06-07 07:59:07 --> Router Class Initialized
INFO - 2024-06-07 07:59:07 --> Output Class Initialized
INFO - 2024-06-07 07:59:07 --> Security Class Initialized
DEBUG - 2024-06-07 07:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 07:59:07 --> Input Class Initialized
INFO - 2024-06-07 07:59:07 --> Language Class Initialized
INFO - 2024-06-07 07:59:07 --> Language Class Initialized
INFO - 2024-06-07 07:59:07 --> Config Class Initialized
INFO - 2024-06-07 07:59:07 --> Loader Class Initialized
INFO - 2024-06-07 07:59:07 --> Helper loaded: url_helper
INFO - 2024-06-07 07:59:07 --> Helper loaded: file_helper
INFO - 2024-06-07 07:59:07 --> Helper loaded: form_helper
INFO - 2024-06-07 07:59:07 --> Helper loaded: my_helper
INFO - 2024-06-07 07:59:07 --> Database Driver Class Initialized
INFO - 2024-06-07 07:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 07:59:07 --> Controller Class Initialized
INFO - 2024-06-07 08:00:48 --> Config Class Initialized
INFO - 2024-06-07 08:00:48 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:00:48 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:00:48 --> Utf8 Class Initialized
INFO - 2024-06-07 08:00:48 --> URI Class Initialized
INFO - 2024-06-07 08:00:48 --> Router Class Initialized
INFO - 2024-06-07 08:00:48 --> Output Class Initialized
INFO - 2024-06-07 08:00:48 --> Security Class Initialized
DEBUG - 2024-06-07 08:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:00:48 --> Input Class Initialized
INFO - 2024-06-07 08:00:48 --> Language Class Initialized
INFO - 2024-06-07 08:00:48 --> Language Class Initialized
INFO - 2024-06-07 08:00:48 --> Config Class Initialized
INFO - 2024-06-07 08:00:48 --> Loader Class Initialized
INFO - 2024-06-07 08:00:48 --> Helper loaded: url_helper
INFO - 2024-06-07 08:00:48 --> Helper loaded: file_helper
INFO - 2024-06-07 08:00:48 --> Helper loaded: form_helper
INFO - 2024-06-07 08:00:48 --> Helper loaded: my_helper
INFO - 2024-06-07 08:00:48 --> Database Driver Class Initialized
INFO - 2024-06-07 08:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:00:48 --> Controller Class Initialized
DEBUG - 2024-06-07 08:00:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-06-07 08:00:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:00:48 --> Final output sent to browser
DEBUG - 2024-06-07 08:00:48 --> Total execution time: 0.0404
INFO - 2024-06-07 08:00:55 --> Config Class Initialized
INFO - 2024-06-07 08:00:55 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:00:55 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:00:55 --> Utf8 Class Initialized
INFO - 2024-06-07 08:00:55 --> URI Class Initialized
INFO - 2024-06-07 08:00:55 --> Router Class Initialized
INFO - 2024-06-07 08:00:55 --> Output Class Initialized
INFO - 2024-06-07 08:00:55 --> Security Class Initialized
DEBUG - 2024-06-07 08:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:00:55 --> Input Class Initialized
INFO - 2024-06-07 08:00:55 --> Language Class Initialized
INFO - 2024-06-07 08:00:55 --> Language Class Initialized
INFO - 2024-06-07 08:00:55 --> Config Class Initialized
INFO - 2024-06-07 08:00:55 --> Loader Class Initialized
INFO - 2024-06-07 08:00:55 --> Helper loaded: url_helper
INFO - 2024-06-07 08:00:55 --> Helper loaded: file_helper
INFO - 2024-06-07 08:00:55 --> Helper loaded: form_helper
INFO - 2024-06-07 08:00:55 --> Helper loaded: my_helper
INFO - 2024-06-07 08:00:55 --> Database Driver Class Initialized
INFO - 2024-06-07 08:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:00:55 --> Controller Class Initialized
DEBUG - 2024-06-07 08:00:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-06-07 08:00:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:00:55 --> Final output sent to browser
DEBUG - 2024-06-07 08:00:55 --> Total execution time: 0.0348
INFO - 2024-06-07 08:00:59 --> Config Class Initialized
INFO - 2024-06-07 08:00:59 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:00:59 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:00:59 --> Utf8 Class Initialized
INFO - 2024-06-07 08:00:59 --> URI Class Initialized
INFO - 2024-06-07 08:00:59 --> Router Class Initialized
INFO - 2024-06-07 08:00:59 --> Output Class Initialized
INFO - 2024-06-07 08:00:59 --> Security Class Initialized
DEBUG - 2024-06-07 08:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:00:59 --> Input Class Initialized
INFO - 2024-06-07 08:00:59 --> Language Class Initialized
INFO - 2024-06-07 08:00:59 --> Language Class Initialized
INFO - 2024-06-07 08:00:59 --> Config Class Initialized
INFO - 2024-06-07 08:00:59 --> Loader Class Initialized
INFO - 2024-06-07 08:00:59 --> Helper loaded: url_helper
INFO - 2024-06-07 08:00:59 --> Helper loaded: file_helper
INFO - 2024-06-07 08:00:59 --> Helper loaded: form_helper
INFO - 2024-06-07 08:00:59 --> Helper loaded: my_helper
INFO - 2024-06-07 08:00:59 --> Database Driver Class Initialized
INFO - 2024-06-07 08:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:00:59 --> Controller Class Initialized
DEBUG - 2024-06-07 08:00:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-06-07 08:00:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:00:59 --> Final output sent to browser
DEBUG - 2024-06-07 08:00:59 --> Total execution time: 0.0290
INFO - 2024-06-07 08:01:02 --> Config Class Initialized
INFO - 2024-06-07 08:01:02 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:01:02 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:01:02 --> Utf8 Class Initialized
INFO - 2024-06-07 08:01:02 --> URI Class Initialized
INFO - 2024-06-07 08:01:02 --> Router Class Initialized
INFO - 2024-06-07 08:01:02 --> Output Class Initialized
INFO - 2024-06-07 08:01:02 --> Security Class Initialized
DEBUG - 2024-06-07 08:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:01:02 --> Input Class Initialized
INFO - 2024-06-07 08:01:02 --> Language Class Initialized
INFO - 2024-06-07 08:01:02 --> Language Class Initialized
INFO - 2024-06-07 08:01:02 --> Config Class Initialized
INFO - 2024-06-07 08:01:02 --> Loader Class Initialized
INFO - 2024-06-07 08:01:02 --> Helper loaded: url_helper
INFO - 2024-06-07 08:01:02 --> Helper loaded: file_helper
INFO - 2024-06-07 08:01:02 --> Helper loaded: form_helper
INFO - 2024-06-07 08:01:02 --> Helper loaded: my_helper
INFO - 2024-06-07 08:01:02 --> Database Driver Class Initialized
INFO - 2024-06-07 08:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:01:02 --> Controller Class Initialized
INFO - 2024-06-07 08:01:02 --> Config Class Initialized
INFO - 2024-06-07 08:01:02 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:01:02 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:01:02 --> Utf8 Class Initialized
INFO - 2024-06-07 08:01:02 --> URI Class Initialized
INFO - 2024-06-07 08:01:02 --> Router Class Initialized
INFO - 2024-06-07 08:01:02 --> Output Class Initialized
INFO - 2024-06-07 08:01:02 --> Security Class Initialized
DEBUG - 2024-06-07 08:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:01:02 --> Input Class Initialized
INFO - 2024-06-07 08:01:02 --> Language Class Initialized
INFO - 2024-06-07 08:01:02 --> Language Class Initialized
INFO - 2024-06-07 08:01:02 --> Config Class Initialized
INFO - 2024-06-07 08:01:02 --> Loader Class Initialized
INFO - 2024-06-07 08:01:02 --> Helper loaded: url_helper
INFO - 2024-06-07 08:01:02 --> Helper loaded: file_helper
INFO - 2024-06-07 08:01:02 --> Helper loaded: form_helper
INFO - 2024-06-07 08:01:02 --> Helper loaded: my_helper
INFO - 2024-06-07 08:01:02 --> Database Driver Class Initialized
INFO - 2024-06-07 08:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:01:02 --> Controller Class Initialized
DEBUG - 2024-06-07 08:01:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-07 08:01:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:01:02 --> Final output sent to browser
DEBUG - 2024-06-07 08:01:02 --> Total execution time: 0.0298
INFO - 2024-06-07 08:01:08 --> Config Class Initialized
INFO - 2024-06-07 08:01:08 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:01:08 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:01:08 --> Utf8 Class Initialized
INFO - 2024-06-07 08:01:08 --> URI Class Initialized
INFO - 2024-06-07 08:01:08 --> Router Class Initialized
INFO - 2024-06-07 08:01:08 --> Output Class Initialized
INFO - 2024-06-07 08:01:08 --> Security Class Initialized
DEBUG - 2024-06-07 08:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:01:08 --> Input Class Initialized
INFO - 2024-06-07 08:01:08 --> Language Class Initialized
INFO - 2024-06-07 08:01:08 --> Language Class Initialized
INFO - 2024-06-07 08:01:08 --> Config Class Initialized
INFO - 2024-06-07 08:01:08 --> Loader Class Initialized
INFO - 2024-06-07 08:01:08 --> Helper loaded: url_helper
INFO - 2024-06-07 08:01:08 --> Helper loaded: file_helper
INFO - 2024-06-07 08:01:08 --> Helper loaded: form_helper
INFO - 2024-06-07 08:01:08 --> Helper loaded: my_helper
INFO - 2024-06-07 08:01:08 --> Database Driver Class Initialized
INFO - 2024-06-07 08:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:01:08 --> Controller Class Initialized
ERROR - 2024-06-07 08:01:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-07 08:01:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-07 08:01:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-07 08:01:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-07 08:01:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-07 08:01:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-07 08:01:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-07 08:01:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:01:08 --> Final output sent to browser
DEBUG - 2024-06-07 08:01:08 --> Total execution time: 0.0747
INFO - 2024-06-07 08:01:10 --> Config Class Initialized
INFO - 2024-06-07 08:01:10 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:01:10 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:01:10 --> Utf8 Class Initialized
INFO - 2024-06-07 08:01:10 --> URI Class Initialized
INFO - 2024-06-07 08:01:10 --> Router Class Initialized
INFO - 2024-06-07 08:01:10 --> Output Class Initialized
INFO - 2024-06-07 08:01:10 --> Security Class Initialized
DEBUG - 2024-06-07 08:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:01:10 --> Input Class Initialized
INFO - 2024-06-07 08:01:10 --> Language Class Initialized
INFO - 2024-06-07 08:01:10 --> Language Class Initialized
INFO - 2024-06-07 08:01:10 --> Config Class Initialized
INFO - 2024-06-07 08:01:10 --> Loader Class Initialized
INFO - 2024-06-07 08:01:10 --> Helper loaded: url_helper
INFO - 2024-06-07 08:01:10 --> Helper loaded: file_helper
INFO - 2024-06-07 08:01:10 --> Helper loaded: form_helper
INFO - 2024-06-07 08:01:10 --> Helper loaded: my_helper
INFO - 2024-06-07 08:01:10 --> Database Driver Class Initialized
INFO - 2024-06-07 08:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:01:10 --> Controller Class Initialized
INFO - 2024-06-07 08:01:10 --> Helper loaded: cookie_helper
INFO - 2024-06-07 08:01:10 --> Final output sent to browser
DEBUG - 2024-06-07 08:01:10 --> Total execution time: 0.0838
INFO - 2024-06-07 08:01:10 --> Config Class Initialized
INFO - 2024-06-07 08:01:10 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:01:10 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:01:10 --> Utf8 Class Initialized
INFO - 2024-06-07 08:01:10 --> URI Class Initialized
INFO - 2024-06-07 08:01:10 --> Router Class Initialized
INFO - 2024-06-07 08:01:10 --> Output Class Initialized
INFO - 2024-06-07 08:01:10 --> Security Class Initialized
DEBUG - 2024-06-07 08:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:01:10 --> Input Class Initialized
INFO - 2024-06-07 08:01:10 --> Language Class Initialized
INFO - 2024-06-07 08:01:10 --> Language Class Initialized
INFO - 2024-06-07 08:01:10 --> Config Class Initialized
INFO - 2024-06-07 08:01:10 --> Loader Class Initialized
INFO - 2024-06-07 08:01:10 --> Helper loaded: url_helper
INFO - 2024-06-07 08:01:10 --> Helper loaded: file_helper
INFO - 2024-06-07 08:01:10 --> Helper loaded: form_helper
INFO - 2024-06-07 08:01:10 --> Helper loaded: my_helper
INFO - 2024-06-07 08:01:10 --> Database Driver Class Initialized
INFO - 2024-06-07 08:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:01:10 --> Controller Class Initialized
DEBUG - 2024-06-07 08:01:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-07 08:01:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:01:10 --> Final output sent to browser
DEBUG - 2024-06-07 08:01:10 --> Total execution time: 0.0534
INFO - 2024-06-07 08:01:14 --> Config Class Initialized
INFO - 2024-06-07 08:01:14 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:01:14 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:01:14 --> Utf8 Class Initialized
INFO - 2024-06-07 08:01:14 --> URI Class Initialized
INFO - 2024-06-07 08:01:14 --> Router Class Initialized
INFO - 2024-06-07 08:01:14 --> Output Class Initialized
INFO - 2024-06-07 08:01:14 --> Security Class Initialized
DEBUG - 2024-06-07 08:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:01:14 --> Input Class Initialized
INFO - 2024-06-07 08:01:14 --> Language Class Initialized
INFO - 2024-06-07 08:01:14 --> Language Class Initialized
INFO - 2024-06-07 08:01:14 --> Config Class Initialized
INFO - 2024-06-07 08:01:14 --> Loader Class Initialized
INFO - 2024-06-07 08:01:14 --> Helper loaded: url_helper
INFO - 2024-06-07 08:01:14 --> Helper loaded: file_helper
INFO - 2024-06-07 08:01:14 --> Helper loaded: form_helper
INFO - 2024-06-07 08:01:14 --> Helper loaded: my_helper
INFO - 2024-06-07 08:01:14 --> Database Driver Class Initialized
INFO - 2024-06-07 08:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:01:14 --> Controller Class Initialized
INFO - 2024-06-07 08:01:14 --> Helper loaded: cookie_helper
INFO - 2024-06-07 08:01:14 --> Config Class Initialized
INFO - 2024-06-07 08:01:14 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:01:14 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:01:14 --> Utf8 Class Initialized
INFO - 2024-06-07 08:01:14 --> URI Class Initialized
INFO - 2024-06-07 08:01:14 --> Router Class Initialized
INFO - 2024-06-07 08:01:14 --> Output Class Initialized
INFO - 2024-06-07 08:01:14 --> Security Class Initialized
DEBUG - 2024-06-07 08:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:01:14 --> Input Class Initialized
INFO - 2024-06-07 08:01:14 --> Language Class Initialized
INFO - 2024-06-07 08:01:14 --> Language Class Initialized
INFO - 2024-06-07 08:01:14 --> Config Class Initialized
INFO - 2024-06-07 08:01:14 --> Loader Class Initialized
INFO - 2024-06-07 08:01:14 --> Helper loaded: url_helper
INFO - 2024-06-07 08:01:14 --> Helper loaded: file_helper
INFO - 2024-06-07 08:01:14 --> Helper loaded: form_helper
INFO - 2024-06-07 08:01:14 --> Helper loaded: my_helper
INFO - 2024-06-07 08:01:14 --> Database Driver Class Initialized
INFO - 2024-06-07 08:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:01:14 --> Controller Class Initialized
INFO - 2024-06-07 08:01:14 --> Config Class Initialized
INFO - 2024-06-07 08:01:14 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:01:14 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:01:14 --> Utf8 Class Initialized
INFO - 2024-06-07 08:01:14 --> URI Class Initialized
INFO - 2024-06-07 08:01:14 --> Router Class Initialized
INFO - 2024-06-07 08:01:14 --> Output Class Initialized
INFO - 2024-06-07 08:01:14 --> Security Class Initialized
DEBUG - 2024-06-07 08:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:01:14 --> Input Class Initialized
INFO - 2024-06-07 08:01:14 --> Language Class Initialized
INFO - 2024-06-07 08:01:14 --> Language Class Initialized
INFO - 2024-06-07 08:01:14 --> Config Class Initialized
INFO - 2024-06-07 08:01:14 --> Loader Class Initialized
INFO - 2024-06-07 08:01:14 --> Helper loaded: url_helper
INFO - 2024-06-07 08:01:14 --> Helper loaded: file_helper
INFO - 2024-06-07 08:01:14 --> Helper loaded: form_helper
INFO - 2024-06-07 08:01:14 --> Helper loaded: my_helper
INFO - 2024-06-07 08:01:14 --> Database Driver Class Initialized
INFO - 2024-06-07 08:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:01:14 --> Controller Class Initialized
DEBUG - 2024-06-07 08:01:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-07 08:01:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:01:14 --> Final output sent to browser
DEBUG - 2024-06-07 08:01:14 --> Total execution time: 0.0252
INFO - 2024-06-07 08:01:16 --> Config Class Initialized
INFO - 2024-06-07 08:01:16 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:01:16 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:01:16 --> Utf8 Class Initialized
INFO - 2024-06-07 08:01:16 --> URI Class Initialized
INFO - 2024-06-07 08:01:16 --> Router Class Initialized
INFO - 2024-06-07 08:01:16 --> Output Class Initialized
INFO - 2024-06-07 08:01:16 --> Security Class Initialized
DEBUG - 2024-06-07 08:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:01:16 --> Input Class Initialized
INFO - 2024-06-07 08:01:16 --> Language Class Initialized
INFO - 2024-06-07 08:01:16 --> Language Class Initialized
INFO - 2024-06-07 08:01:16 --> Config Class Initialized
INFO - 2024-06-07 08:01:16 --> Loader Class Initialized
INFO - 2024-06-07 08:01:16 --> Helper loaded: url_helper
INFO - 2024-06-07 08:01:16 --> Helper loaded: file_helper
INFO - 2024-06-07 08:01:16 --> Helper loaded: form_helper
INFO - 2024-06-07 08:01:16 --> Helper loaded: my_helper
INFO - 2024-06-07 08:01:16 --> Database Driver Class Initialized
INFO - 2024-06-07 08:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:01:16 --> Controller Class Initialized
DEBUG - 2024-06-07 08:01:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-06-07 08:01:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:01:16 --> Final output sent to browser
DEBUG - 2024-06-07 08:01:16 --> Total execution time: 0.0356
INFO - 2024-06-07 08:01:18 --> Config Class Initialized
INFO - 2024-06-07 08:01:18 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:01:18 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:01:18 --> Utf8 Class Initialized
INFO - 2024-06-07 08:01:18 --> URI Class Initialized
INFO - 2024-06-07 08:01:18 --> Router Class Initialized
INFO - 2024-06-07 08:01:18 --> Output Class Initialized
INFO - 2024-06-07 08:01:18 --> Security Class Initialized
DEBUG - 2024-06-07 08:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:01:18 --> Input Class Initialized
INFO - 2024-06-07 08:01:18 --> Language Class Initialized
INFO - 2024-06-07 08:01:18 --> Language Class Initialized
INFO - 2024-06-07 08:01:18 --> Config Class Initialized
INFO - 2024-06-07 08:01:18 --> Loader Class Initialized
INFO - 2024-06-07 08:01:18 --> Helper loaded: url_helper
INFO - 2024-06-07 08:01:18 --> Helper loaded: file_helper
INFO - 2024-06-07 08:01:18 --> Helper loaded: form_helper
INFO - 2024-06-07 08:01:18 --> Helper loaded: my_helper
INFO - 2024-06-07 08:01:18 --> Database Driver Class Initialized
INFO - 2024-06-07 08:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:01:18 --> Controller Class Initialized
DEBUG - 2024-06-07 08:01:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-06-07 08:01:19 --> Config Class Initialized
INFO - 2024-06-07 08:01:19 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:01:19 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:01:19 --> Utf8 Class Initialized
INFO - 2024-06-07 08:01:19 --> URI Class Initialized
INFO - 2024-06-07 08:01:19 --> Router Class Initialized
INFO - 2024-06-07 08:01:19 --> Output Class Initialized
INFO - 2024-06-07 08:01:19 --> Security Class Initialized
DEBUG - 2024-06-07 08:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:01:19 --> Input Class Initialized
INFO - 2024-06-07 08:01:19 --> Language Class Initialized
INFO - 2024-06-07 08:01:19 --> Language Class Initialized
INFO - 2024-06-07 08:01:19 --> Config Class Initialized
INFO - 2024-06-07 08:01:19 --> Loader Class Initialized
INFO - 2024-06-07 08:01:19 --> Helper loaded: url_helper
INFO - 2024-06-07 08:01:19 --> Helper loaded: file_helper
INFO - 2024-06-07 08:01:19 --> Helper loaded: form_helper
INFO - 2024-06-07 08:01:19 --> Helper loaded: my_helper
INFO - 2024-06-07 08:01:19 --> Database Driver Class Initialized
INFO - 2024-06-07 08:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:01:19 --> Controller Class Initialized
INFO - 2024-06-07 08:01:20 --> Helper loaded: cookie_helper
INFO - 2024-06-07 08:01:20 --> Final output sent to browser
DEBUG - 2024-06-07 08:01:20 --> Total execution time: 0.3166
INFO - 2024-06-07 08:01:20 --> Config Class Initialized
INFO - 2024-06-07 08:01:20 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:01:20 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:01:20 --> Utf8 Class Initialized
INFO - 2024-06-07 08:01:20 --> URI Class Initialized
INFO - 2024-06-07 08:01:20 --> Router Class Initialized
INFO - 2024-06-07 08:01:20 --> Output Class Initialized
INFO - 2024-06-07 08:01:20 --> Security Class Initialized
DEBUG - 2024-06-07 08:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:01:20 --> Input Class Initialized
INFO - 2024-06-07 08:01:20 --> Language Class Initialized
INFO - 2024-06-07 08:01:20 --> Language Class Initialized
INFO - 2024-06-07 08:01:20 --> Config Class Initialized
INFO - 2024-06-07 08:01:20 --> Loader Class Initialized
INFO - 2024-06-07 08:01:20 --> Helper loaded: url_helper
INFO - 2024-06-07 08:01:20 --> Helper loaded: file_helper
INFO - 2024-06-07 08:01:20 --> Helper loaded: form_helper
INFO - 2024-06-07 08:01:20 --> Helper loaded: my_helper
INFO - 2024-06-07 08:01:20 --> Database Driver Class Initialized
INFO - 2024-06-07 08:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:01:20 --> Controller Class Initialized
DEBUG - 2024-06-07 08:01:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-06-07 08:01:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:01:20 --> Final output sent to browser
DEBUG - 2024-06-07 08:01:20 --> Total execution time: 0.6262
INFO - 2024-06-07 08:01:21 --> Final output sent to browser
DEBUG - 2024-06-07 08:01:21 --> Total execution time: 3.5160
INFO - 2024-06-07 08:01:27 --> Config Class Initialized
INFO - 2024-06-07 08:01:27 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:01:27 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:01:27 --> Utf8 Class Initialized
INFO - 2024-06-07 08:01:27 --> URI Class Initialized
INFO - 2024-06-07 08:01:27 --> Router Class Initialized
INFO - 2024-06-07 08:01:27 --> Output Class Initialized
INFO - 2024-06-07 08:01:27 --> Security Class Initialized
DEBUG - 2024-06-07 08:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:01:27 --> Input Class Initialized
INFO - 2024-06-07 08:01:27 --> Language Class Initialized
INFO - 2024-06-07 08:01:27 --> Language Class Initialized
INFO - 2024-06-07 08:01:27 --> Config Class Initialized
INFO - 2024-06-07 08:01:27 --> Loader Class Initialized
INFO - 2024-06-07 08:01:27 --> Helper loaded: url_helper
INFO - 2024-06-07 08:01:27 --> Helper loaded: file_helper
INFO - 2024-06-07 08:01:27 --> Helper loaded: form_helper
INFO - 2024-06-07 08:01:27 --> Helper loaded: my_helper
INFO - 2024-06-07 08:01:27 --> Database Driver Class Initialized
INFO - 2024-06-07 08:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:01:27 --> Controller Class Initialized
DEBUG - 2024-06-07 08:01:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-07 08:01:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:01:27 --> Final output sent to browser
DEBUG - 2024-06-07 08:01:27 --> Total execution time: 0.0430
INFO - 2024-06-07 08:01:30 --> Config Class Initialized
INFO - 2024-06-07 08:01:30 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:01:30 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:01:30 --> Utf8 Class Initialized
INFO - 2024-06-07 08:01:30 --> URI Class Initialized
INFO - 2024-06-07 08:01:30 --> Router Class Initialized
INFO - 2024-06-07 08:01:30 --> Output Class Initialized
INFO - 2024-06-07 08:01:30 --> Security Class Initialized
DEBUG - 2024-06-07 08:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:01:30 --> Input Class Initialized
INFO - 2024-06-07 08:01:30 --> Language Class Initialized
INFO - 2024-06-07 08:01:30 --> Language Class Initialized
INFO - 2024-06-07 08:01:30 --> Config Class Initialized
INFO - 2024-06-07 08:01:30 --> Loader Class Initialized
INFO - 2024-06-07 08:01:30 --> Helper loaded: url_helper
INFO - 2024-06-07 08:01:30 --> Helper loaded: file_helper
INFO - 2024-06-07 08:01:30 --> Helper loaded: form_helper
INFO - 2024-06-07 08:01:30 --> Helper loaded: my_helper
INFO - 2024-06-07 08:01:30 --> Database Driver Class Initialized
INFO - 2024-06-07 08:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:01:30 --> Controller Class Initialized
ERROR - 2024-06-07 08:01:30 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-06-07 08:01:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 235
DEBUG - 2024-06-07 08:01:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-07 08:01:34 --> Config Class Initialized
INFO - 2024-06-07 08:01:34 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:01:34 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:01:34 --> Utf8 Class Initialized
INFO - 2024-06-07 08:01:34 --> URI Class Initialized
INFO - 2024-06-07 08:01:34 --> Router Class Initialized
INFO - 2024-06-07 08:01:34 --> Final output sent to browser
DEBUG - 2024-06-07 08:01:34 --> Total execution time: 3.6627
INFO - 2024-06-07 08:01:34 --> Output Class Initialized
INFO - 2024-06-07 08:01:34 --> Security Class Initialized
DEBUG - 2024-06-07 08:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:01:34 --> Input Class Initialized
INFO - 2024-06-07 08:01:34 --> Language Class Initialized
INFO - 2024-06-07 08:01:34 --> Language Class Initialized
INFO - 2024-06-07 08:01:34 --> Config Class Initialized
INFO - 2024-06-07 08:01:34 --> Loader Class Initialized
INFO - 2024-06-07 08:01:34 --> Helper loaded: url_helper
INFO - 2024-06-07 08:01:34 --> Helper loaded: file_helper
INFO - 2024-06-07 08:01:34 --> Helper loaded: form_helper
INFO - 2024-06-07 08:01:34 --> Helper loaded: my_helper
INFO - 2024-06-07 08:01:34 --> Database Driver Class Initialized
INFO - 2024-06-07 08:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:01:34 --> Controller Class Initialized
DEBUG - 2024-06-07 08:01:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-06-07 08:01:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:01:34 --> Final output sent to browser
DEBUG - 2024-06-07 08:01:34 --> Total execution time: 0.0507
INFO - 2024-06-07 08:01:34 --> Config Class Initialized
INFO - 2024-06-07 08:01:34 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:01:34 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:01:34 --> Utf8 Class Initialized
INFO - 2024-06-07 08:01:34 --> URI Class Initialized
INFO - 2024-06-07 08:01:34 --> Router Class Initialized
INFO - 2024-06-07 08:01:34 --> Output Class Initialized
INFO - 2024-06-07 08:01:34 --> Security Class Initialized
DEBUG - 2024-06-07 08:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:01:34 --> Input Class Initialized
INFO - 2024-06-07 08:01:34 --> Language Class Initialized
ERROR - 2024-06-07 08:01:34 --> 404 Page Not Found: /index
INFO - 2024-06-07 08:01:34 --> Config Class Initialized
INFO - 2024-06-07 08:01:34 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:01:34 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:01:34 --> Utf8 Class Initialized
INFO - 2024-06-07 08:01:34 --> URI Class Initialized
INFO - 2024-06-07 08:01:34 --> Router Class Initialized
INFO - 2024-06-07 08:01:34 --> Output Class Initialized
INFO - 2024-06-07 08:01:34 --> Security Class Initialized
DEBUG - 2024-06-07 08:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:01:34 --> Input Class Initialized
INFO - 2024-06-07 08:01:34 --> Language Class Initialized
INFO - 2024-06-07 08:01:34 --> Language Class Initialized
INFO - 2024-06-07 08:01:34 --> Config Class Initialized
INFO - 2024-06-07 08:01:34 --> Loader Class Initialized
INFO - 2024-06-07 08:01:34 --> Helper loaded: url_helper
INFO - 2024-06-07 08:01:34 --> Helper loaded: file_helper
INFO - 2024-06-07 08:01:34 --> Helper loaded: form_helper
INFO - 2024-06-07 08:01:34 --> Helper loaded: my_helper
INFO - 2024-06-07 08:01:34 --> Database Driver Class Initialized
INFO - 2024-06-07 08:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:01:34 --> Controller Class Initialized
INFO - 2024-06-07 08:01:36 --> Config Class Initialized
INFO - 2024-06-07 08:01:36 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:01:36 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:01:36 --> Utf8 Class Initialized
INFO - 2024-06-07 08:01:36 --> URI Class Initialized
INFO - 2024-06-07 08:01:36 --> Router Class Initialized
INFO - 2024-06-07 08:01:36 --> Output Class Initialized
INFO - 2024-06-07 08:01:36 --> Security Class Initialized
DEBUG - 2024-06-07 08:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:01:36 --> Input Class Initialized
INFO - 2024-06-07 08:01:36 --> Language Class Initialized
INFO - 2024-06-07 08:01:36 --> Language Class Initialized
INFO - 2024-06-07 08:01:36 --> Config Class Initialized
INFO - 2024-06-07 08:01:36 --> Loader Class Initialized
INFO - 2024-06-07 08:01:36 --> Helper loaded: url_helper
INFO - 2024-06-07 08:01:36 --> Helper loaded: file_helper
INFO - 2024-06-07 08:01:36 --> Helper loaded: form_helper
INFO - 2024-06-07 08:01:36 --> Helper loaded: my_helper
INFO - 2024-06-07 08:01:36 --> Database Driver Class Initialized
INFO - 2024-06-07 08:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:01:36 --> Controller Class Initialized
INFO - 2024-06-07 08:01:36 --> Final output sent to browser
DEBUG - 2024-06-07 08:01:36 --> Total execution time: 0.0294
INFO - 2024-06-07 08:01:36 --> Config Class Initialized
INFO - 2024-06-07 08:01:36 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:01:36 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:01:36 --> Utf8 Class Initialized
INFO - 2024-06-07 08:01:36 --> URI Class Initialized
INFO - 2024-06-07 08:01:36 --> Router Class Initialized
INFO - 2024-06-07 08:01:36 --> Output Class Initialized
INFO - 2024-06-07 08:01:36 --> Security Class Initialized
DEBUG - 2024-06-07 08:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:01:36 --> Input Class Initialized
INFO - 2024-06-07 08:01:36 --> Language Class Initialized
ERROR - 2024-06-07 08:01:36 --> 404 Page Not Found: /index
INFO - 2024-06-07 08:01:36 --> Config Class Initialized
INFO - 2024-06-07 08:01:36 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:01:36 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:01:36 --> Utf8 Class Initialized
INFO - 2024-06-07 08:01:36 --> URI Class Initialized
INFO - 2024-06-07 08:01:36 --> Router Class Initialized
INFO - 2024-06-07 08:01:36 --> Output Class Initialized
INFO - 2024-06-07 08:01:36 --> Security Class Initialized
DEBUG - 2024-06-07 08:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:01:36 --> Input Class Initialized
INFO - 2024-06-07 08:01:36 --> Language Class Initialized
INFO - 2024-06-07 08:01:36 --> Language Class Initialized
INFO - 2024-06-07 08:01:36 --> Config Class Initialized
INFO - 2024-06-07 08:01:36 --> Loader Class Initialized
INFO - 2024-06-07 08:01:36 --> Helper loaded: url_helper
INFO - 2024-06-07 08:01:36 --> Helper loaded: file_helper
INFO - 2024-06-07 08:01:36 --> Helper loaded: form_helper
INFO - 2024-06-07 08:01:36 --> Helper loaded: my_helper
INFO - 2024-06-07 08:01:36 --> Database Driver Class Initialized
INFO - 2024-06-07 08:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:01:36 --> Controller Class Initialized
INFO - 2024-06-07 08:01:54 --> Config Class Initialized
INFO - 2024-06-07 08:01:54 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:01:54 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:01:54 --> Utf8 Class Initialized
INFO - 2024-06-07 08:01:54 --> URI Class Initialized
INFO - 2024-06-07 08:01:54 --> Router Class Initialized
INFO - 2024-06-07 08:01:54 --> Output Class Initialized
INFO - 2024-06-07 08:01:54 --> Security Class Initialized
DEBUG - 2024-06-07 08:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:01:54 --> Input Class Initialized
INFO - 2024-06-07 08:01:54 --> Language Class Initialized
INFO - 2024-06-07 08:01:54 --> Language Class Initialized
INFO - 2024-06-07 08:01:54 --> Config Class Initialized
INFO - 2024-06-07 08:01:54 --> Loader Class Initialized
INFO - 2024-06-07 08:01:54 --> Helper loaded: url_helper
INFO - 2024-06-07 08:01:54 --> Helper loaded: file_helper
INFO - 2024-06-07 08:01:54 --> Helper loaded: form_helper
INFO - 2024-06-07 08:01:54 --> Helper loaded: my_helper
INFO - 2024-06-07 08:01:54 --> Database Driver Class Initialized
INFO - 2024-06-07 08:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:01:54 --> Controller Class Initialized
DEBUG - 2024-06-07 08:01:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-07 08:01:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:01:54 --> Final output sent to browser
DEBUG - 2024-06-07 08:01:54 --> Total execution time: 0.0645
INFO - 2024-06-07 08:01:57 --> Config Class Initialized
INFO - 2024-06-07 08:01:57 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:01:57 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:01:57 --> Utf8 Class Initialized
INFO - 2024-06-07 08:01:57 --> URI Class Initialized
DEBUG - 2024-06-07 08:01:57 --> No URI present. Default controller set.
INFO - 2024-06-07 08:01:57 --> Router Class Initialized
INFO - 2024-06-07 08:01:57 --> Output Class Initialized
INFO - 2024-06-07 08:01:57 --> Security Class Initialized
DEBUG - 2024-06-07 08:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:01:57 --> Input Class Initialized
INFO - 2024-06-07 08:01:57 --> Language Class Initialized
INFO - 2024-06-07 08:01:57 --> Language Class Initialized
INFO - 2024-06-07 08:01:57 --> Config Class Initialized
INFO - 2024-06-07 08:01:57 --> Loader Class Initialized
INFO - 2024-06-07 08:01:57 --> Helper loaded: url_helper
INFO - 2024-06-07 08:01:57 --> Helper loaded: file_helper
INFO - 2024-06-07 08:01:57 --> Helper loaded: form_helper
INFO - 2024-06-07 08:01:57 --> Helper loaded: my_helper
INFO - 2024-06-07 08:01:57 --> Database Driver Class Initialized
INFO - 2024-06-07 08:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:01:57 --> Controller Class Initialized
DEBUG - 2024-06-07 08:01:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-07 08:01:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:01:57 --> Final output sent to browser
DEBUG - 2024-06-07 08:01:57 --> Total execution time: 0.0349
INFO - 2024-06-07 08:02:05 --> Config Class Initialized
INFO - 2024-06-07 08:02:05 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:02:05 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:02:05 --> Utf8 Class Initialized
INFO - 2024-06-07 08:02:05 --> URI Class Initialized
INFO - 2024-06-07 08:02:05 --> Router Class Initialized
INFO - 2024-06-07 08:02:05 --> Output Class Initialized
INFO - 2024-06-07 08:02:05 --> Security Class Initialized
DEBUG - 2024-06-07 08:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:02:05 --> Input Class Initialized
INFO - 2024-06-07 08:02:05 --> Language Class Initialized
INFO - 2024-06-07 08:02:05 --> Language Class Initialized
INFO - 2024-06-07 08:02:05 --> Config Class Initialized
INFO - 2024-06-07 08:02:05 --> Loader Class Initialized
INFO - 2024-06-07 08:02:05 --> Helper loaded: url_helper
INFO - 2024-06-07 08:02:05 --> Helper loaded: file_helper
INFO - 2024-06-07 08:02:05 --> Helper loaded: form_helper
INFO - 2024-06-07 08:02:05 --> Helper loaded: my_helper
INFO - 2024-06-07 08:02:05 --> Database Driver Class Initialized
INFO - 2024-06-07 08:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:02:05 --> Controller Class Initialized
DEBUG - 2024-06-07 08:02:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-07 08:02:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:02:05 --> Final output sent to browser
DEBUG - 2024-06-07 08:02:05 --> Total execution time: 0.0440
INFO - 2024-06-07 08:02:09 --> Config Class Initialized
INFO - 2024-06-07 08:02:09 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:02:09 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:02:09 --> Utf8 Class Initialized
INFO - 2024-06-07 08:02:09 --> URI Class Initialized
INFO - 2024-06-07 08:02:09 --> Router Class Initialized
INFO - 2024-06-07 08:02:09 --> Output Class Initialized
INFO - 2024-06-07 08:02:09 --> Security Class Initialized
DEBUG - 2024-06-07 08:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:02:09 --> Input Class Initialized
INFO - 2024-06-07 08:02:09 --> Language Class Initialized
INFO - 2024-06-07 08:02:09 --> Language Class Initialized
INFO - 2024-06-07 08:02:09 --> Config Class Initialized
INFO - 2024-06-07 08:02:09 --> Loader Class Initialized
INFO - 2024-06-07 08:02:09 --> Helper loaded: url_helper
INFO - 2024-06-07 08:02:09 --> Helper loaded: file_helper
INFO - 2024-06-07 08:02:09 --> Helper loaded: form_helper
INFO - 2024-06-07 08:02:09 --> Helper loaded: my_helper
INFO - 2024-06-07 08:02:09 --> Database Driver Class Initialized
INFO - 2024-06-07 08:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:02:09 --> Controller Class Initialized
INFO - 2024-06-07 08:02:09 --> Final output sent to browser
DEBUG - 2024-06-07 08:02:09 --> Total execution time: 0.0585
INFO - 2024-06-07 08:02:09 --> Config Class Initialized
INFO - 2024-06-07 08:02:09 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:02:09 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:02:09 --> Utf8 Class Initialized
INFO - 2024-06-07 08:02:09 --> URI Class Initialized
INFO - 2024-06-07 08:02:09 --> Router Class Initialized
INFO - 2024-06-07 08:02:09 --> Output Class Initialized
INFO - 2024-06-07 08:02:09 --> Security Class Initialized
DEBUG - 2024-06-07 08:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:02:09 --> Input Class Initialized
INFO - 2024-06-07 08:02:09 --> Language Class Initialized
ERROR - 2024-06-07 08:02:09 --> 404 Page Not Found: /index
INFO - 2024-06-07 08:02:09 --> Config Class Initialized
INFO - 2024-06-07 08:02:09 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:02:09 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:02:09 --> Utf8 Class Initialized
INFO - 2024-06-07 08:02:09 --> URI Class Initialized
INFO - 2024-06-07 08:02:09 --> Router Class Initialized
INFO - 2024-06-07 08:02:09 --> Output Class Initialized
INFO - 2024-06-07 08:02:09 --> Security Class Initialized
DEBUG - 2024-06-07 08:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:02:09 --> Input Class Initialized
INFO - 2024-06-07 08:02:09 --> Language Class Initialized
INFO - 2024-06-07 08:02:09 --> Language Class Initialized
INFO - 2024-06-07 08:02:09 --> Config Class Initialized
INFO - 2024-06-07 08:02:09 --> Loader Class Initialized
INFO - 2024-06-07 08:02:09 --> Helper loaded: url_helper
INFO - 2024-06-07 08:02:09 --> Helper loaded: file_helper
INFO - 2024-06-07 08:02:09 --> Helper loaded: form_helper
INFO - 2024-06-07 08:02:09 --> Helper loaded: my_helper
INFO - 2024-06-07 08:02:09 --> Database Driver Class Initialized
INFO - 2024-06-07 08:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:02:09 --> Controller Class Initialized
INFO - 2024-06-07 08:02:12 --> Config Class Initialized
INFO - 2024-06-07 08:02:12 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:02:12 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:02:12 --> Utf8 Class Initialized
INFO - 2024-06-07 08:02:12 --> URI Class Initialized
INFO - 2024-06-07 08:02:12 --> Router Class Initialized
INFO - 2024-06-07 08:02:12 --> Output Class Initialized
INFO - 2024-06-07 08:02:12 --> Security Class Initialized
DEBUG - 2024-06-07 08:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:02:12 --> Input Class Initialized
INFO - 2024-06-07 08:02:12 --> Language Class Initialized
INFO - 2024-06-07 08:02:12 --> Language Class Initialized
INFO - 2024-06-07 08:02:12 --> Config Class Initialized
INFO - 2024-06-07 08:02:12 --> Loader Class Initialized
INFO - 2024-06-07 08:02:12 --> Helper loaded: url_helper
INFO - 2024-06-07 08:02:12 --> Helper loaded: file_helper
INFO - 2024-06-07 08:02:12 --> Helper loaded: form_helper
INFO - 2024-06-07 08:02:12 --> Helper loaded: my_helper
INFO - 2024-06-07 08:02:12 --> Database Driver Class Initialized
INFO - 2024-06-07 08:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:02:12 --> Controller Class Initialized
INFO - 2024-06-07 08:02:12 --> Final output sent to browser
DEBUG - 2024-06-07 08:02:12 --> Total execution time: 0.1030
INFO - 2024-06-07 08:02:12 --> Config Class Initialized
INFO - 2024-06-07 08:02:12 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:02:12 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:02:12 --> Utf8 Class Initialized
INFO - 2024-06-07 08:02:12 --> URI Class Initialized
INFO - 2024-06-07 08:02:12 --> Router Class Initialized
INFO - 2024-06-07 08:02:12 --> Output Class Initialized
INFO - 2024-06-07 08:02:12 --> Security Class Initialized
DEBUG - 2024-06-07 08:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:02:12 --> Input Class Initialized
INFO - 2024-06-07 08:02:12 --> Language Class Initialized
ERROR - 2024-06-07 08:02:12 --> 404 Page Not Found: /index
INFO - 2024-06-07 08:02:12 --> Config Class Initialized
INFO - 2024-06-07 08:02:12 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:02:12 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:02:12 --> Utf8 Class Initialized
INFO - 2024-06-07 08:02:12 --> URI Class Initialized
INFO - 2024-06-07 08:02:12 --> Router Class Initialized
INFO - 2024-06-07 08:02:12 --> Output Class Initialized
INFO - 2024-06-07 08:02:12 --> Security Class Initialized
DEBUG - 2024-06-07 08:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:02:12 --> Input Class Initialized
INFO - 2024-06-07 08:02:12 --> Language Class Initialized
INFO - 2024-06-07 08:02:12 --> Language Class Initialized
INFO - 2024-06-07 08:02:12 --> Config Class Initialized
INFO - 2024-06-07 08:02:12 --> Loader Class Initialized
INFO - 2024-06-07 08:02:12 --> Helper loaded: url_helper
INFO - 2024-06-07 08:02:12 --> Helper loaded: file_helper
INFO - 2024-06-07 08:02:12 --> Helper loaded: form_helper
INFO - 2024-06-07 08:02:12 --> Helper loaded: my_helper
INFO - 2024-06-07 08:02:12 --> Database Driver Class Initialized
INFO - 2024-06-07 08:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:02:12 --> Controller Class Initialized
INFO - 2024-06-07 08:02:13 --> Config Class Initialized
INFO - 2024-06-07 08:02:13 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:02:13 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:02:13 --> Utf8 Class Initialized
INFO - 2024-06-07 08:02:13 --> URI Class Initialized
INFO - 2024-06-07 08:02:13 --> Router Class Initialized
INFO - 2024-06-07 08:02:13 --> Output Class Initialized
INFO - 2024-06-07 08:02:13 --> Security Class Initialized
DEBUG - 2024-06-07 08:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:02:13 --> Input Class Initialized
INFO - 2024-06-07 08:02:13 --> Language Class Initialized
INFO - 2024-06-07 08:02:13 --> Language Class Initialized
INFO - 2024-06-07 08:02:13 --> Config Class Initialized
INFO - 2024-06-07 08:02:13 --> Loader Class Initialized
INFO - 2024-06-07 08:02:13 --> Helper loaded: url_helper
INFO - 2024-06-07 08:02:13 --> Helper loaded: file_helper
INFO - 2024-06-07 08:02:13 --> Helper loaded: form_helper
INFO - 2024-06-07 08:02:13 --> Helper loaded: my_helper
INFO - 2024-06-07 08:02:13 --> Database Driver Class Initialized
INFO - 2024-06-07 08:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:02:13 --> Controller Class Initialized
ERROR - 2024-06-07 08:02:13 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-07 08:02:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:02:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:02:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:02:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:02:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:02:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:02:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:02:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:02:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:02:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:02:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:02:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:02:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:02:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:02:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:02:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:02:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:02:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:02:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:02:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:02:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:02:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:02:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-07 08:02:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-07 08:02:18 --> Final output sent to browser
DEBUG - 2024-06-07 08:02:18 --> Total execution time: 5.2090
INFO - 2024-06-07 08:02:20 --> Config Class Initialized
INFO - 2024-06-07 08:02:20 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:02:20 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:02:20 --> Utf8 Class Initialized
INFO - 2024-06-07 08:02:20 --> URI Class Initialized
INFO - 2024-06-07 08:02:20 --> Router Class Initialized
INFO - 2024-06-07 08:02:20 --> Output Class Initialized
INFO - 2024-06-07 08:02:20 --> Security Class Initialized
DEBUG - 2024-06-07 08:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:02:20 --> Input Class Initialized
INFO - 2024-06-07 08:02:20 --> Language Class Initialized
INFO - 2024-06-07 08:02:20 --> Language Class Initialized
INFO - 2024-06-07 08:02:20 --> Config Class Initialized
INFO - 2024-06-07 08:02:20 --> Loader Class Initialized
INFO - 2024-06-07 08:02:20 --> Helper loaded: url_helper
INFO - 2024-06-07 08:02:20 --> Helper loaded: file_helper
INFO - 2024-06-07 08:02:20 --> Helper loaded: form_helper
INFO - 2024-06-07 08:02:20 --> Helper loaded: my_helper
INFO - 2024-06-07 08:02:20 --> Database Driver Class Initialized
INFO - 2024-06-07 08:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:02:20 --> Controller Class Initialized
INFO - 2024-06-07 08:02:20 --> Helper loaded: cookie_helper
INFO - 2024-06-07 08:02:20 --> Config Class Initialized
INFO - 2024-06-07 08:02:20 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:02:20 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:02:20 --> Utf8 Class Initialized
INFO - 2024-06-07 08:02:20 --> URI Class Initialized
INFO - 2024-06-07 08:02:20 --> Router Class Initialized
INFO - 2024-06-07 08:02:20 --> Output Class Initialized
INFO - 2024-06-07 08:02:20 --> Security Class Initialized
DEBUG - 2024-06-07 08:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:02:20 --> Input Class Initialized
INFO - 2024-06-07 08:02:20 --> Language Class Initialized
INFO - 2024-06-07 08:02:20 --> Language Class Initialized
INFO - 2024-06-07 08:02:20 --> Config Class Initialized
INFO - 2024-06-07 08:02:20 --> Loader Class Initialized
INFO - 2024-06-07 08:02:20 --> Helper loaded: url_helper
INFO - 2024-06-07 08:02:20 --> Helper loaded: file_helper
INFO - 2024-06-07 08:02:20 --> Helper loaded: form_helper
INFO - 2024-06-07 08:02:20 --> Helper loaded: my_helper
INFO - 2024-06-07 08:02:20 --> Database Driver Class Initialized
INFO - 2024-06-07 08:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:02:20 --> Controller Class Initialized
INFO - 2024-06-07 08:02:20 --> Config Class Initialized
INFO - 2024-06-07 08:02:20 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:02:20 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:02:20 --> Utf8 Class Initialized
INFO - 2024-06-07 08:02:20 --> URI Class Initialized
INFO - 2024-06-07 08:02:20 --> Router Class Initialized
INFO - 2024-06-07 08:02:20 --> Output Class Initialized
INFO - 2024-06-07 08:02:20 --> Security Class Initialized
DEBUG - 2024-06-07 08:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:02:20 --> Input Class Initialized
INFO - 2024-06-07 08:02:20 --> Language Class Initialized
INFO - 2024-06-07 08:02:20 --> Language Class Initialized
INFO - 2024-06-07 08:02:20 --> Config Class Initialized
INFO - 2024-06-07 08:02:20 --> Loader Class Initialized
INFO - 2024-06-07 08:02:20 --> Helper loaded: url_helper
INFO - 2024-06-07 08:02:20 --> Helper loaded: file_helper
INFO - 2024-06-07 08:02:20 --> Helper loaded: form_helper
INFO - 2024-06-07 08:02:20 --> Helper loaded: my_helper
INFO - 2024-06-07 08:02:20 --> Database Driver Class Initialized
INFO - 2024-06-07 08:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:02:20 --> Controller Class Initialized
DEBUG - 2024-06-07 08:02:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-07 08:02:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:02:20 --> Final output sent to browser
DEBUG - 2024-06-07 08:02:20 --> Total execution time: 0.0307
INFO - 2024-06-07 08:02:25 --> Config Class Initialized
INFO - 2024-06-07 08:02:25 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:02:25 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:02:25 --> Utf8 Class Initialized
INFO - 2024-06-07 08:02:25 --> URI Class Initialized
INFO - 2024-06-07 08:02:25 --> Router Class Initialized
INFO - 2024-06-07 08:02:25 --> Output Class Initialized
INFO - 2024-06-07 08:02:25 --> Security Class Initialized
DEBUG - 2024-06-07 08:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:02:25 --> Input Class Initialized
INFO - 2024-06-07 08:02:25 --> Language Class Initialized
INFO - 2024-06-07 08:02:25 --> Language Class Initialized
INFO - 2024-06-07 08:02:25 --> Config Class Initialized
INFO - 2024-06-07 08:02:25 --> Loader Class Initialized
INFO - 2024-06-07 08:02:25 --> Helper loaded: url_helper
INFO - 2024-06-07 08:02:25 --> Helper loaded: file_helper
INFO - 2024-06-07 08:02:25 --> Helper loaded: form_helper
INFO - 2024-06-07 08:02:25 --> Helper loaded: my_helper
INFO - 2024-06-07 08:02:25 --> Database Driver Class Initialized
INFO - 2024-06-07 08:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:02:25 --> Controller Class Initialized
INFO - 2024-06-07 08:02:25 --> Helper loaded: cookie_helper
INFO - 2024-06-07 08:02:25 --> Final output sent to browser
DEBUG - 2024-06-07 08:02:25 --> Total execution time: 0.0320
INFO - 2024-06-07 08:02:25 --> Config Class Initialized
INFO - 2024-06-07 08:02:25 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:02:25 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:02:25 --> Utf8 Class Initialized
INFO - 2024-06-07 08:02:25 --> URI Class Initialized
INFO - 2024-06-07 08:02:25 --> Router Class Initialized
INFO - 2024-06-07 08:02:25 --> Output Class Initialized
INFO - 2024-06-07 08:02:25 --> Security Class Initialized
DEBUG - 2024-06-07 08:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:02:25 --> Input Class Initialized
INFO - 2024-06-07 08:02:25 --> Language Class Initialized
INFO - 2024-06-07 08:02:25 --> Language Class Initialized
INFO - 2024-06-07 08:02:25 --> Config Class Initialized
INFO - 2024-06-07 08:02:25 --> Loader Class Initialized
INFO - 2024-06-07 08:02:25 --> Helper loaded: url_helper
INFO - 2024-06-07 08:02:25 --> Helper loaded: file_helper
INFO - 2024-06-07 08:02:25 --> Helper loaded: form_helper
INFO - 2024-06-07 08:02:25 --> Helper loaded: my_helper
INFO - 2024-06-07 08:02:25 --> Database Driver Class Initialized
INFO - 2024-06-07 08:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:02:25 --> Controller Class Initialized
DEBUG - 2024-06-07 08:02:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-07 08:02:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:02:25 --> Final output sent to browser
DEBUG - 2024-06-07 08:02:25 --> Total execution time: 0.0266
INFO - 2024-06-07 08:02:31 --> Config Class Initialized
INFO - 2024-06-07 08:02:31 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:02:31 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:02:31 --> Utf8 Class Initialized
INFO - 2024-06-07 08:02:31 --> URI Class Initialized
INFO - 2024-06-07 08:02:31 --> Router Class Initialized
INFO - 2024-06-07 08:02:31 --> Output Class Initialized
INFO - 2024-06-07 08:02:31 --> Security Class Initialized
DEBUG - 2024-06-07 08:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:02:31 --> Input Class Initialized
INFO - 2024-06-07 08:02:31 --> Language Class Initialized
INFO - 2024-06-07 08:02:31 --> Language Class Initialized
INFO - 2024-06-07 08:02:31 --> Config Class Initialized
INFO - 2024-06-07 08:02:31 --> Loader Class Initialized
INFO - 2024-06-07 08:02:31 --> Helper loaded: url_helper
INFO - 2024-06-07 08:02:31 --> Helper loaded: file_helper
INFO - 2024-06-07 08:02:31 --> Helper loaded: form_helper
INFO - 2024-06-07 08:02:31 --> Helper loaded: my_helper
INFO - 2024-06-07 08:02:31 --> Database Driver Class Initialized
INFO - 2024-06-07 08:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:02:31 --> Controller Class Initialized
ERROR - 2024-06-07 08:02:31 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-07 08:02:31 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-07 08:02:31 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-07 08:02:31 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-07 08:02:31 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-07 08:02:31 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-07 08:02:31 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-07 08:02:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-07 08:02:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:02:31 --> Final output sent to browser
DEBUG - 2024-06-07 08:02:31 --> Total execution time: 0.0367
INFO - 2024-06-07 08:02:34 --> Config Class Initialized
INFO - 2024-06-07 08:02:34 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:02:34 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:02:34 --> Utf8 Class Initialized
INFO - 2024-06-07 08:02:34 --> URI Class Initialized
INFO - 2024-06-07 08:02:34 --> Router Class Initialized
INFO - 2024-06-07 08:02:34 --> Output Class Initialized
INFO - 2024-06-07 08:02:34 --> Security Class Initialized
DEBUG - 2024-06-07 08:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:02:34 --> Input Class Initialized
INFO - 2024-06-07 08:02:34 --> Language Class Initialized
INFO - 2024-06-07 08:02:34 --> Language Class Initialized
INFO - 2024-06-07 08:02:34 --> Config Class Initialized
INFO - 2024-06-07 08:02:34 --> Loader Class Initialized
INFO - 2024-06-07 08:02:34 --> Helper loaded: url_helper
INFO - 2024-06-07 08:02:34 --> Helper loaded: file_helper
INFO - 2024-06-07 08:02:34 --> Helper loaded: form_helper
INFO - 2024-06-07 08:02:34 --> Helper loaded: my_helper
INFO - 2024-06-07 08:02:34 --> Database Driver Class Initialized
INFO - 2024-06-07 08:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:02:34 --> Controller Class Initialized
DEBUG - 2024-06-07 08:02:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2024-06-07 08:02:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:02:34 --> Final output sent to browser
DEBUG - 2024-06-07 08:02:34 --> Total execution time: 0.1689
INFO - 2024-06-07 08:02:34 --> Config Class Initialized
INFO - 2024-06-07 08:02:34 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:02:34 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:02:34 --> Utf8 Class Initialized
INFO - 2024-06-07 08:02:34 --> URI Class Initialized
INFO - 2024-06-07 08:02:34 --> Router Class Initialized
INFO - 2024-06-07 08:02:34 --> Output Class Initialized
INFO - 2024-06-07 08:02:34 --> Security Class Initialized
DEBUG - 2024-06-07 08:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:02:34 --> Input Class Initialized
INFO - 2024-06-07 08:02:34 --> Language Class Initialized
INFO - 2024-06-07 08:02:34 --> Language Class Initialized
INFO - 2024-06-07 08:02:34 --> Config Class Initialized
INFO - 2024-06-07 08:02:34 --> Loader Class Initialized
INFO - 2024-06-07 08:02:34 --> Helper loaded: url_helper
INFO - 2024-06-07 08:02:34 --> Helper loaded: file_helper
INFO - 2024-06-07 08:02:34 --> Helper loaded: form_helper
INFO - 2024-06-07 08:02:34 --> Helper loaded: my_helper
INFO - 2024-06-07 08:02:34 --> Database Driver Class Initialized
INFO - 2024-06-07 08:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:02:34 --> Controller Class Initialized
INFO - 2024-06-07 08:02:38 --> Config Class Initialized
INFO - 2024-06-07 08:02:38 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:02:38 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:02:38 --> Utf8 Class Initialized
INFO - 2024-06-07 08:02:38 --> URI Class Initialized
INFO - 2024-06-07 08:02:38 --> Router Class Initialized
INFO - 2024-06-07 08:02:38 --> Output Class Initialized
INFO - 2024-06-07 08:02:38 --> Security Class Initialized
DEBUG - 2024-06-07 08:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:02:38 --> Input Class Initialized
INFO - 2024-06-07 08:02:38 --> Language Class Initialized
INFO - 2024-06-07 08:02:38 --> Language Class Initialized
INFO - 2024-06-07 08:02:38 --> Config Class Initialized
INFO - 2024-06-07 08:02:38 --> Loader Class Initialized
INFO - 2024-06-07 08:02:38 --> Helper loaded: url_helper
INFO - 2024-06-07 08:02:38 --> Helper loaded: file_helper
INFO - 2024-06-07 08:02:38 --> Helper loaded: form_helper
INFO - 2024-06-07 08:02:38 --> Helper loaded: my_helper
INFO - 2024-06-07 08:02:38 --> Database Driver Class Initialized
INFO - 2024-06-07 08:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:02:38 --> Controller Class Initialized
INFO - 2024-06-07 08:02:38 --> Final output sent to browser
DEBUG - 2024-06-07 08:02:38 --> Total execution time: 0.0314
INFO - 2024-06-07 08:03:09 --> Config Class Initialized
INFO - 2024-06-07 08:03:09 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:03:09 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:03:09 --> Utf8 Class Initialized
INFO - 2024-06-07 08:03:09 --> URI Class Initialized
INFO - 2024-06-07 08:03:09 --> Router Class Initialized
INFO - 2024-06-07 08:03:09 --> Output Class Initialized
INFO - 2024-06-07 08:03:09 --> Security Class Initialized
DEBUG - 2024-06-07 08:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:03:09 --> Input Class Initialized
INFO - 2024-06-07 08:03:09 --> Language Class Initialized
INFO - 2024-06-07 08:03:09 --> Language Class Initialized
INFO - 2024-06-07 08:03:09 --> Config Class Initialized
INFO - 2024-06-07 08:03:09 --> Loader Class Initialized
INFO - 2024-06-07 08:03:09 --> Helper loaded: url_helper
INFO - 2024-06-07 08:03:09 --> Helper loaded: file_helper
INFO - 2024-06-07 08:03:09 --> Helper loaded: form_helper
INFO - 2024-06-07 08:03:09 --> Helper loaded: my_helper
INFO - 2024-06-07 08:03:09 --> Database Driver Class Initialized
INFO - 2024-06-07 08:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:03:09 --> Controller Class Initialized
DEBUG - 2024-06-07 08:03:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_ekstra/views/list.php
DEBUG - 2024-06-07 08:03:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:03:09 --> Final output sent to browser
DEBUG - 2024-06-07 08:03:09 --> Total execution time: 0.0802
INFO - 2024-06-07 08:03:16 --> Config Class Initialized
INFO - 2024-06-07 08:03:16 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:03:16 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:03:16 --> Utf8 Class Initialized
INFO - 2024-06-07 08:03:16 --> URI Class Initialized
INFO - 2024-06-07 08:03:16 --> Router Class Initialized
INFO - 2024-06-07 08:03:16 --> Output Class Initialized
INFO - 2024-06-07 08:03:16 --> Security Class Initialized
DEBUG - 2024-06-07 08:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:03:16 --> Input Class Initialized
INFO - 2024-06-07 08:03:16 --> Language Class Initialized
INFO - 2024-06-07 08:03:16 --> Language Class Initialized
INFO - 2024-06-07 08:03:16 --> Config Class Initialized
INFO - 2024-06-07 08:03:16 --> Loader Class Initialized
INFO - 2024-06-07 08:03:16 --> Helper loaded: url_helper
INFO - 2024-06-07 08:03:16 --> Helper loaded: file_helper
INFO - 2024-06-07 08:03:16 --> Helper loaded: form_helper
INFO - 2024-06-07 08:03:16 --> Helper loaded: my_helper
INFO - 2024-06-07 08:03:16 --> Database Driver Class Initialized
INFO - 2024-06-07 08:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:03:16 --> Controller Class Initialized
INFO - 2024-06-07 08:03:16 --> Final output sent to browser
DEBUG - 2024-06-07 08:03:16 --> Total execution time: 0.0414
INFO - 2024-06-07 08:03:28 --> Config Class Initialized
INFO - 2024-06-07 08:03:28 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:03:28 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:03:28 --> Utf8 Class Initialized
INFO - 2024-06-07 08:03:28 --> URI Class Initialized
INFO - 2024-06-07 08:03:28 --> Router Class Initialized
INFO - 2024-06-07 08:03:28 --> Output Class Initialized
INFO - 2024-06-07 08:03:28 --> Security Class Initialized
DEBUG - 2024-06-07 08:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:03:28 --> Input Class Initialized
INFO - 2024-06-07 08:03:28 --> Language Class Initialized
INFO - 2024-06-07 08:03:28 --> Language Class Initialized
INFO - 2024-06-07 08:03:28 --> Config Class Initialized
INFO - 2024-06-07 08:03:28 --> Loader Class Initialized
INFO - 2024-06-07 08:03:28 --> Helper loaded: url_helper
INFO - 2024-06-07 08:03:28 --> Helper loaded: file_helper
INFO - 2024-06-07 08:03:28 --> Helper loaded: form_helper
INFO - 2024-06-07 08:03:28 --> Helper loaded: my_helper
INFO - 2024-06-07 08:03:28 --> Database Driver Class Initialized
INFO - 2024-06-07 08:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:03:28 --> Controller Class Initialized
INFO - 2024-06-07 08:03:28 --> Final output sent to browser
DEBUG - 2024-06-07 08:03:28 --> Total execution time: 0.0298
INFO - 2024-06-07 08:03:35 --> Config Class Initialized
INFO - 2024-06-07 08:03:35 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:03:35 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:03:35 --> Utf8 Class Initialized
INFO - 2024-06-07 08:03:35 --> URI Class Initialized
INFO - 2024-06-07 08:03:35 --> Router Class Initialized
INFO - 2024-06-07 08:03:35 --> Output Class Initialized
INFO - 2024-06-07 08:03:35 --> Security Class Initialized
DEBUG - 2024-06-07 08:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:03:35 --> Input Class Initialized
INFO - 2024-06-07 08:03:35 --> Language Class Initialized
INFO - 2024-06-07 08:03:35 --> Language Class Initialized
INFO - 2024-06-07 08:03:35 --> Config Class Initialized
INFO - 2024-06-07 08:03:35 --> Loader Class Initialized
INFO - 2024-06-07 08:03:35 --> Helper loaded: url_helper
INFO - 2024-06-07 08:03:35 --> Helper loaded: file_helper
INFO - 2024-06-07 08:03:35 --> Helper loaded: form_helper
INFO - 2024-06-07 08:03:35 --> Helper loaded: my_helper
INFO - 2024-06-07 08:03:35 --> Database Driver Class Initialized
INFO - 2024-06-07 08:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:03:35 --> Controller Class Initialized
INFO - 2024-06-07 08:03:35 --> Final output sent to browser
DEBUG - 2024-06-07 08:03:35 --> Total execution time: 0.0281
INFO - 2024-06-07 08:03:39 --> Config Class Initialized
INFO - 2024-06-07 08:03:39 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:03:39 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:03:39 --> Utf8 Class Initialized
INFO - 2024-06-07 08:03:39 --> URI Class Initialized
INFO - 2024-06-07 08:03:39 --> Router Class Initialized
INFO - 2024-06-07 08:03:39 --> Output Class Initialized
INFO - 2024-06-07 08:03:39 --> Security Class Initialized
DEBUG - 2024-06-07 08:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:03:39 --> Input Class Initialized
INFO - 2024-06-07 08:03:39 --> Language Class Initialized
INFO - 2024-06-07 08:03:39 --> Language Class Initialized
INFO - 2024-06-07 08:03:39 --> Config Class Initialized
INFO - 2024-06-07 08:03:39 --> Loader Class Initialized
INFO - 2024-06-07 08:03:39 --> Helper loaded: url_helper
INFO - 2024-06-07 08:03:39 --> Helper loaded: file_helper
INFO - 2024-06-07 08:03:39 --> Helper loaded: form_helper
INFO - 2024-06-07 08:03:39 --> Helper loaded: my_helper
INFO - 2024-06-07 08:03:39 --> Database Driver Class Initialized
INFO - 2024-06-07 08:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:03:39 --> Controller Class Initialized
INFO - 2024-06-07 08:03:39 --> Final output sent to browser
DEBUG - 2024-06-07 08:03:39 --> Total execution time: 0.0491
INFO - 2024-06-07 08:04:07 --> Config Class Initialized
INFO - 2024-06-07 08:04:07 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:04:07 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:04:07 --> Utf8 Class Initialized
INFO - 2024-06-07 08:04:07 --> URI Class Initialized
INFO - 2024-06-07 08:04:07 --> Router Class Initialized
INFO - 2024-06-07 08:04:07 --> Output Class Initialized
INFO - 2024-06-07 08:04:07 --> Security Class Initialized
DEBUG - 2024-06-07 08:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:04:07 --> Input Class Initialized
INFO - 2024-06-07 08:04:07 --> Language Class Initialized
INFO - 2024-06-07 08:04:07 --> Language Class Initialized
INFO - 2024-06-07 08:04:07 --> Config Class Initialized
INFO - 2024-06-07 08:04:07 --> Loader Class Initialized
INFO - 2024-06-07 08:04:07 --> Helper loaded: url_helper
INFO - 2024-06-07 08:04:07 --> Helper loaded: file_helper
INFO - 2024-06-07 08:04:07 --> Helper loaded: form_helper
INFO - 2024-06-07 08:04:07 --> Helper loaded: my_helper
INFO - 2024-06-07 08:04:07 --> Database Driver Class Initialized
INFO - 2024-06-07 08:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:04:07 --> Controller Class Initialized
ERROR - 2024-06-07 08:04:07 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-07 08:04:07 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-07 08:04:07 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-07 08:04:07 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-07 08:04:07 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-07 08:04:07 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-07 08:04:07 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-07 08:04:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-07 08:04:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:04:07 --> Final output sent to browser
DEBUG - 2024-06-07 08:04:07 --> Total execution time: 0.0342
INFO - 2024-06-07 08:04:22 --> Config Class Initialized
INFO - 2024-06-07 08:04:22 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:04:22 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:04:22 --> Utf8 Class Initialized
INFO - 2024-06-07 08:04:22 --> URI Class Initialized
INFO - 2024-06-07 08:04:22 --> Router Class Initialized
INFO - 2024-06-07 08:04:22 --> Output Class Initialized
INFO - 2024-06-07 08:04:22 --> Security Class Initialized
DEBUG - 2024-06-07 08:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:04:22 --> Input Class Initialized
INFO - 2024-06-07 08:04:22 --> Language Class Initialized
INFO - 2024-06-07 08:04:22 --> Language Class Initialized
INFO - 2024-06-07 08:04:22 --> Config Class Initialized
INFO - 2024-06-07 08:04:22 --> Loader Class Initialized
INFO - 2024-06-07 08:04:22 --> Helper loaded: url_helper
INFO - 2024-06-07 08:04:22 --> Helper loaded: file_helper
INFO - 2024-06-07 08:04:22 --> Helper loaded: form_helper
INFO - 2024-06-07 08:04:22 --> Helper loaded: my_helper
INFO - 2024-06-07 08:04:22 --> Database Driver Class Initialized
INFO - 2024-06-07 08:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:04:22 --> Controller Class Initialized
DEBUG - 2024-06-07 08:04:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2024-06-07 08:04:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:04:22 --> Final output sent to browser
DEBUG - 2024-06-07 08:04:22 --> Total execution time: 0.0334
INFO - 2024-06-07 08:04:22 --> Config Class Initialized
INFO - 2024-06-07 08:04:22 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:04:22 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:04:22 --> Utf8 Class Initialized
INFO - 2024-06-07 08:04:22 --> URI Class Initialized
INFO - 2024-06-07 08:04:22 --> Router Class Initialized
INFO - 2024-06-07 08:04:22 --> Output Class Initialized
INFO - 2024-06-07 08:04:22 --> Security Class Initialized
DEBUG - 2024-06-07 08:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:04:22 --> Input Class Initialized
INFO - 2024-06-07 08:04:22 --> Language Class Initialized
INFO - 2024-06-07 08:04:22 --> Language Class Initialized
INFO - 2024-06-07 08:04:22 --> Config Class Initialized
INFO - 2024-06-07 08:04:22 --> Loader Class Initialized
INFO - 2024-06-07 08:04:22 --> Helper loaded: url_helper
INFO - 2024-06-07 08:04:22 --> Helper loaded: file_helper
INFO - 2024-06-07 08:04:22 --> Helper loaded: form_helper
INFO - 2024-06-07 08:04:22 --> Helper loaded: my_helper
INFO - 2024-06-07 08:04:22 --> Database Driver Class Initialized
INFO - 2024-06-07 08:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:04:22 --> Controller Class Initialized
INFO - 2024-06-07 08:04:29 --> Config Class Initialized
INFO - 2024-06-07 08:04:29 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:04:29 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:04:29 --> Utf8 Class Initialized
INFO - 2024-06-07 08:04:29 --> URI Class Initialized
INFO - 2024-06-07 08:04:29 --> Router Class Initialized
INFO - 2024-06-07 08:04:29 --> Output Class Initialized
INFO - 2024-06-07 08:04:29 --> Security Class Initialized
DEBUG - 2024-06-07 08:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:04:29 --> Input Class Initialized
INFO - 2024-06-07 08:04:29 --> Language Class Initialized
INFO - 2024-06-07 08:04:29 --> Language Class Initialized
INFO - 2024-06-07 08:04:29 --> Config Class Initialized
INFO - 2024-06-07 08:04:29 --> Loader Class Initialized
INFO - 2024-06-07 08:04:29 --> Helper loaded: url_helper
INFO - 2024-06-07 08:04:29 --> Helper loaded: file_helper
INFO - 2024-06-07 08:04:29 --> Helper loaded: form_helper
INFO - 2024-06-07 08:04:29 --> Helper loaded: my_helper
INFO - 2024-06-07 08:04:29 --> Database Driver Class Initialized
INFO - 2024-06-07 08:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:04:29 --> Controller Class Initialized
ERROR - 2024-06-07 08:04:29 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-07 08:04:29 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-07 08:04:29 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-07 08:04:29 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-07 08:04:29 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-07 08:04:29 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-07 08:04:29 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-07 08:04:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-07 08:04:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:04:29 --> Final output sent to browser
DEBUG - 2024-06-07 08:04:29 --> Total execution time: 0.0278
INFO - 2024-06-07 08:04:56 --> Config Class Initialized
INFO - 2024-06-07 08:04:56 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:04:56 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:04:56 --> Utf8 Class Initialized
INFO - 2024-06-07 08:04:56 --> URI Class Initialized
INFO - 2024-06-07 08:04:56 --> Router Class Initialized
INFO - 2024-06-07 08:04:56 --> Output Class Initialized
INFO - 2024-06-07 08:04:56 --> Security Class Initialized
DEBUG - 2024-06-07 08:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:04:56 --> Input Class Initialized
INFO - 2024-06-07 08:04:56 --> Language Class Initialized
INFO - 2024-06-07 08:04:56 --> Language Class Initialized
INFO - 2024-06-07 08:04:56 --> Config Class Initialized
INFO - 2024-06-07 08:04:56 --> Loader Class Initialized
INFO - 2024-06-07 08:04:56 --> Helper loaded: url_helper
INFO - 2024-06-07 08:04:56 --> Helper loaded: file_helper
INFO - 2024-06-07 08:04:56 --> Helper loaded: form_helper
INFO - 2024-06-07 08:04:56 --> Helper loaded: my_helper
INFO - 2024-06-07 08:04:56 --> Database Driver Class Initialized
INFO - 2024-06-07 08:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:04:56 --> Controller Class Initialized
INFO - 2024-06-07 08:04:56 --> Helper loaded: cookie_helper
INFO - 2024-06-07 08:04:56 --> Config Class Initialized
INFO - 2024-06-07 08:04:56 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:04:56 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:04:56 --> Utf8 Class Initialized
INFO - 2024-06-07 08:04:56 --> URI Class Initialized
INFO - 2024-06-07 08:04:56 --> Router Class Initialized
INFO - 2024-06-07 08:04:56 --> Output Class Initialized
INFO - 2024-06-07 08:04:56 --> Security Class Initialized
DEBUG - 2024-06-07 08:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:04:56 --> Input Class Initialized
INFO - 2024-06-07 08:04:56 --> Language Class Initialized
INFO - 2024-06-07 08:04:56 --> Language Class Initialized
INFO - 2024-06-07 08:04:56 --> Config Class Initialized
INFO - 2024-06-07 08:04:56 --> Loader Class Initialized
INFO - 2024-06-07 08:04:56 --> Helper loaded: url_helper
INFO - 2024-06-07 08:04:56 --> Helper loaded: file_helper
INFO - 2024-06-07 08:04:56 --> Helper loaded: form_helper
INFO - 2024-06-07 08:04:56 --> Helper loaded: my_helper
INFO - 2024-06-07 08:04:56 --> Database Driver Class Initialized
INFO - 2024-06-07 08:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:04:56 --> Controller Class Initialized
INFO - 2024-06-07 08:04:56 --> Config Class Initialized
INFO - 2024-06-07 08:04:56 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:04:56 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:04:56 --> Utf8 Class Initialized
INFO - 2024-06-07 08:04:56 --> URI Class Initialized
INFO - 2024-06-07 08:04:56 --> Router Class Initialized
INFO - 2024-06-07 08:04:56 --> Output Class Initialized
INFO - 2024-06-07 08:04:56 --> Security Class Initialized
DEBUG - 2024-06-07 08:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:04:56 --> Input Class Initialized
INFO - 2024-06-07 08:04:56 --> Language Class Initialized
INFO - 2024-06-07 08:04:56 --> Language Class Initialized
INFO - 2024-06-07 08:04:56 --> Config Class Initialized
INFO - 2024-06-07 08:04:56 --> Loader Class Initialized
INFO - 2024-06-07 08:04:56 --> Helper loaded: url_helper
INFO - 2024-06-07 08:04:56 --> Helper loaded: file_helper
INFO - 2024-06-07 08:04:56 --> Helper loaded: form_helper
INFO - 2024-06-07 08:04:56 --> Helper loaded: my_helper
INFO - 2024-06-07 08:04:56 --> Database Driver Class Initialized
INFO - 2024-06-07 08:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:04:56 --> Controller Class Initialized
DEBUG - 2024-06-07 08:04:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-07 08:04:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:04:56 --> Final output sent to browser
DEBUG - 2024-06-07 08:04:56 --> Total execution time: 0.0716
INFO - 2024-06-07 08:05:01 --> Config Class Initialized
INFO - 2024-06-07 08:05:01 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:05:01 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:05:01 --> Utf8 Class Initialized
INFO - 2024-06-07 08:05:01 --> URI Class Initialized
INFO - 2024-06-07 08:05:01 --> Router Class Initialized
INFO - 2024-06-07 08:05:01 --> Output Class Initialized
INFO - 2024-06-07 08:05:01 --> Security Class Initialized
DEBUG - 2024-06-07 08:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:05:01 --> Input Class Initialized
INFO - 2024-06-07 08:05:01 --> Language Class Initialized
INFO - 2024-06-07 08:05:01 --> Language Class Initialized
INFO - 2024-06-07 08:05:01 --> Config Class Initialized
INFO - 2024-06-07 08:05:01 --> Loader Class Initialized
INFO - 2024-06-07 08:05:01 --> Helper loaded: url_helper
INFO - 2024-06-07 08:05:01 --> Helper loaded: file_helper
INFO - 2024-06-07 08:05:01 --> Helper loaded: form_helper
INFO - 2024-06-07 08:05:01 --> Helper loaded: my_helper
INFO - 2024-06-07 08:05:01 --> Database Driver Class Initialized
INFO - 2024-06-07 08:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:05:01 --> Controller Class Initialized
INFO - 2024-06-07 08:05:01 --> Helper loaded: cookie_helper
INFO - 2024-06-07 08:05:01 --> Final output sent to browser
DEBUG - 2024-06-07 08:05:01 --> Total execution time: 0.0846
INFO - 2024-06-07 08:05:01 --> Config Class Initialized
INFO - 2024-06-07 08:05:01 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:05:01 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:05:01 --> Utf8 Class Initialized
INFO - 2024-06-07 08:05:01 --> URI Class Initialized
INFO - 2024-06-07 08:05:01 --> Router Class Initialized
INFO - 2024-06-07 08:05:01 --> Output Class Initialized
INFO - 2024-06-07 08:05:01 --> Security Class Initialized
DEBUG - 2024-06-07 08:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:05:01 --> Input Class Initialized
INFO - 2024-06-07 08:05:01 --> Language Class Initialized
INFO - 2024-06-07 08:05:01 --> Language Class Initialized
INFO - 2024-06-07 08:05:01 --> Config Class Initialized
INFO - 2024-06-07 08:05:01 --> Loader Class Initialized
INFO - 2024-06-07 08:05:01 --> Helper loaded: url_helper
INFO - 2024-06-07 08:05:01 --> Helper loaded: file_helper
INFO - 2024-06-07 08:05:01 --> Helper loaded: form_helper
INFO - 2024-06-07 08:05:01 --> Helper loaded: my_helper
INFO - 2024-06-07 08:05:01 --> Database Driver Class Initialized
INFO - 2024-06-07 08:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:05:01 --> Controller Class Initialized
DEBUG - 2024-06-07 08:05:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-06-07 08:05:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:05:01 --> Final output sent to browser
DEBUG - 2024-06-07 08:05:01 --> Total execution time: 0.0401
INFO - 2024-06-07 08:05:07 --> Config Class Initialized
INFO - 2024-06-07 08:05:07 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:05:07 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:05:07 --> Utf8 Class Initialized
INFO - 2024-06-07 08:05:07 --> URI Class Initialized
INFO - 2024-06-07 08:05:07 --> Router Class Initialized
INFO - 2024-06-07 08:05:07 --> Output Class Initialized
INFO - 2024-06-07 08:05:07 --> Security Class Initialized
DEBUG - 2024-06-07 08:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:05:07 --> Input Class Initialized
INFO - 2024-06-07 08:05:07 --> Language Class Initialized
INFO - 2024-06-07 08:05:07 --> Language Class Initialized
INFO - 2024-06-07 08:05:07 --> Config Class Initialized
INFO - 2024-06-07 08:05:07 --> Loader Class Initialized
INFO - 2024-06-07 08:05:07 --> Helper loaded: url_helper
INFO - 2024-06-07 08:05:07 --> Helper loaded: file_helper
INFO - 2024-06-07 08:05:07 --> Helper loaded: form_helper
INFO - 2024-06-07 08:05:07 --> Helper loaded: my_helper
INFO - 2024-06-07 08:05:07 --> Database Driver Class Initialized
INFO - 2024-06-07 08:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:05:07 --> Controller Class Initialized
DEBUG - 2024-06-07 08:05:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-06-07 08:05:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:05:07 --> Final output sent to browser
DEBUG - 2024-06-07 08:05:07 --> Total execution time: 0.0604
INFO - 2024-06-07 08:05:07 --> Config Class Initialized
INFO - 2024-06-07 08:05:07 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:05:07 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:05:07 --> Utf8 Class Initialized
INFO - 2024-06-07 08:05:07 --> URI Class Initialized
INFO - 2024-06-07 08:05:07 --> Router Class Initialized
INFO - 2024-06-07 08:05:07 --> Output Class Initialized
INFO - 2024-06-07 08:05:07 --> Security Class Initialized
DEBUG - 2024-06-07 08:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:05:07 --> Input Class Initialized
INFO - 2024-06-07 08:05:07 --> Language Class Initialized
ERROR - 2024-06-07 08:05:07 --> 404 Page Not Found: /index
INFO - 2024-06-07 08:05:07 --> Config Class Initialized
INFO - 2024-06-07 08:05:07 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:05:07 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:05:07 --> Utf8 Class Initialized
INFO - 2024-06-07 08:05:07 --> URI Class Initialized
INFO - 2024-06-07 08:05:07 --> Router Class Initialized
INFO - 2024-06-07 08:05:07 --> Output Class Initialized
INFO - 2024-06-07 08:05:07 --> Security Class Initialized
DEBUG - 2024-06-07 08:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:05:07 --> Input Class Initialized
INFO - 2024-06-07 08:05:07 --> Language Class Initialized
INFO - 2024-06-07 08:05:07 --> Language Class Initialized
INFO - 2024-06-07 08:05:07 --> Config Class Initialized
INFO - 2024-06-07 08:05:07 --> Loader Class Initialized
INFO - 2024-06-07 08:05:07 --> Helper loaded: url_helper
INFO - 2024-06-07 08:05:07 --> Helper loaded: file_helper
INFO - 2024-06-07 08:05:07 --> Helper loaded: form_helper
INFO - 2024-06-07 08:05:07 --> Helper loaded: my_helper
INFO - 2024-06-07 08:05:07 --> Database Driver Class Initialized
INFO - 2024-06-07 08:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:05:07 --> Controller Class Initialized
INFO - 2024-06-07 08:05:09 --> Config Class Initialized
INFO - 2024-06-07 08:05:09 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:05:09 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:05:09 --> Utf8 Class Initialized
INFO - 2024-06-07 08:05:09 --> URI Class Initialized
INFO - 2024-06-07 08:05:09 --> Router Class Initialized
INFO - 2024-06-07 08:05:09 --> Output Class Initialized
INFO - 2024-06-07 08:05:09 --> Security Class Initialized
DEBUG - 2024-06-07 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:05:09 --> Input Class Initialized
INFO - 2024-06-07 08:05:09 --> Language Class Initialized
INFO - 2024-06-07 08:05:09 --> Language Class Initialized
INFO - 2024-06-07 08:05:09 --> Config Class Initialized
INFO - 2024-06-07 08:05:09 --> Loader Class Initialized
INFO - 2024-06-07 08:05:09 --> Helper loaded: url_helper
INFO - 2024-06-07 08:05:09 --> Helper loaded: file_helper
INFO - 2024-06-07 08:05:09 --> Helper loaded: form_helper
INFO - 2024-06-07 08:05:09 --> Helper loaded: my_helper
INFO - 2024-06-07 08:05:09 --> Database Driver Class Initialized
INFO - 2024-06-07 08:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:05:09 --> Controller Class Initialized
INFO - 2024-06-07 08:05:09 --> Final output sent to browser
DEBUG - 2024-06-07 08:05:09 --> Total execution time: 0.0333
INFO - 2024-06-07 08:05:09 --> Config Class Initialized
INFO - 2024-06-07 08:05:09 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:05:09 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:05:09 --> Utf8 Class Initialized
INFO - 2024-06-07 08:05:09 --> URI Class Initialized
INFO - 2024-06-07 08:05:09 --> Router Class Initialized
INFO - 2024-06-07 08:05:09 --> Output Class Initialized
INFO - 2024-06-07 08:05:09 --> Security Class Initialized
DEBUG - 2024-06-07 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:05:09 --> Input Class Initialized
INFO - 2024-06-07 08:05:09 --> Language Class Initialized
ERROR - 2024-06-07 08:05:09 --> 404 Page Not Found: /index
INFO - 2024-06-07 08:05:09 --> Config Class Initialized
INFO - 2024-06-07 08:05:09 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:05:09 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:05:09 --> Utf8 Class Initialized
INFO - 2024-06-07 08:05:09 --> URI Class Initialized
INFO - 2024-06-07 08:05:09 --> Router Class Initialized
INFO - 2024-06-07 08:05:09 --> Output Class Initialized
INFO - 2024-06-07 08:05:09 --> Security Class Initialized
DEBUG - 2024-06-07 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:05:09 --> Input Class Initialized
INFO - 2024-06-07 08:05:09 --> Language Class Initialized
INFO - 2024-06-07 08:05:09 --> Language Class Initialized
INFO - 2024-06-07 08:05:09 --> Config Class Initialized
INFO - 2024-06-07 08:05:09 --> Loader Class Initialized
INFO - 2024-06-07 08:05:09 --> Helper loaded: url_helper
INFO - 2024-06-07 08:05:09 --> Helper loaded: file_helper
INFO - 2024-06-07 08:05:09 --> Helper loaded: form_helper
INFO - 2024-06-07 08:05:09 --> Helper loaded: my_helper
INFO - 2024-06-07 08:05:09 --> Database Driver Class Initialized
INFO - 2024-06-07 08:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:05:09 --> Controller Class Initialized
INFO - 2024-06-07 08:05:18 --> Config Class Initialized
INFO - 2024-06-07 08:05:18 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:05:18 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:05:18 --> Utf8 Class Initialized
INFO - 2024-06-07 08:05:18 --> URI Class Initialized
INFO - 2024-06-07 08:05:18 --> Router Class Initialized
INFO - 2024-06-07 08:05:18 --> Output Class Initialized
INFO - 2024-06-07 08:05:18 --> Security Class Initialized
DEBUG - 2024-06-07 08:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:05:18 --> Input Class Initialized
INFO - 2024-06-07 08:05:18 --> Language Class Initialized
INFO - 2024-06-07 08:05:18 --> Language Class Initialized
INFO - 2024-06-07 08:05:18 --> Config Class Initialized
INFO - 2024-06-07 08:05:18 --> Loader Class Initialized
INFO - 2024-06-07 08:05:18 --> Helper loaded: url_helper
INFO - 2024-06-07 08:05:18 --> Helper loaded: file_helper
INFO - 2024-06-07 08:05:18 --> Helper loaded: form_helper
INFO - 2024-06-07 08:05:18 --> Helper loaded: my_helper
INFO - 2024-06-07 08:05:18 --> Database Driver Class Initialized
INFO - 2024-06-07 08:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:05:18 --> Controller Class Initialized
DEBUG - 2024-06-07 08:05:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_projek/views/list.php
DEBUG - 2024-06-07 08:05:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:05:18 --> Final output sent to browser
DEBUG - 2024-06-07 08:05:18 --> Total execution time: 0.0861
INFO - 2024-06-07 08:05:18 --> Config Class Initialized
INFO - 2024-06-07 08:05:18 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:05:18 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:05:18 --> Utf8 Class Initialized
INFO - 2024-06-07 08:05:18 --> URI Class Initialized
INFO - 2024-06-07 08:05:18 --> Router Class Initialized
INFO - 2024-06-07 08:05:18 --> Output Class Initialized
INFO - 2024-06-07 08:05:18 --> Security Class Initialized
DEBUG - 2024-06-07 08:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:05:18 --> Input Class Initialized
INFO - 2024-06-07 08:05:18 --> Language Class Initialized
ERROR - 2024-06-07 08:05:18 --> 404 Page Not Found: /index
INFO - 2024-06-07 08:05:18 --> Config Class Initialized
INFO - 2024-06-07 08:05:18 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:05:18 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:05:18 --> Utf8 Class Initialized
INFO - 2024-06-07 08:05:18 --> URI Class Initialized
INFO - 2024-06-07 08:05:18 --> Router Class Initialized
INFO - 2024-06-07 08:05:18 --> Output Class Initialized
INFO - 2024-06-07 08:05:18 --> Security Class Initialized
DEBUG - 2024-06-07 08:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:05:18 --> Input Class Initialized
INFO - 2024-06-07 08:05:18 --> Language Class Initialized
INFO - 2024-06-07 08:05:18 --> Language Class Initialized
INFO - 2024-06-07 08:05:18 --> Config Class Initialized
INFO - 2024-06-07 08:05:18 --> Loader Class Initialized
INFO - 2024-06-07 08:05:18 --> Helper loaded: url_helper
INFO - 2024-06-07 08:05:18 --> Helper loaded: file_helper
INFO - 2024-06-07 08:05:18 --> Helper loaded: form_helper
INFO - 2024-06-07 08:05:18 --> Helper loaded: my_helper
INFO - 2024-06-07 08:05:18 --> Database Driver Class Initialized
INFO - 2024-06-07 08:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:05:18 --> Controller Class Initialized
INFO - 2024-06-07 08:05:39 --> Config Class Initialized
INFO - 2024-06-07 08:05:39 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:05:39 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:05:39 --> Utf8 Class Initialized
INFO - 2024-06-07 08:05:39 --> URI Class Initialized
INFO - 2024-06-07 08:05:39 --> Router Class Initialized
INFO - 2024-06-07 08:05:39 --> Output Class Initialized
INFO - 2024-06-07 08:05:39 --> Security Class Initialized
DEBUG - 2024-06-07 08:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:05:39 --> Input Class Initialized
INFO - 2024-06-07 08:05:39 --> Language Class Initialized
INFO - 2024-06-07 08:05:39 --> Language Class Initialized
INFO - 2024-06-07 08:05:39 --> Config Class Initialized
INFO - 2024-06-07 08:05:39 --> Loader Class Initialized
INFO - 2024-06-07 08:05:39 --> Helper loaded: url_helper
INFO - 2024-06-07 08:05:39 --> Helper loaded: file_helper
INFO - 2024-06-07 08:05:39 --> Helper loaded: form_helper
INFO - 2024-06-07 08:05:39 --> Helper loaded: my_helper
INFO - 2024-06-07 08:05:39 --> Database Driver Class Initialized
INFO - 2024-06-07 08:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:05:39 --> Controller Class Initialized
DEBUG - 2024-06-07 08:05:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelompok/views/list.php
DEBUG - 2024-06-07 08:05:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:05:39 --> Final output sent to browser
DEBUG - 2024-06-07 08:05:39 --> Total execution time: 0.0360
INFO - 2024-06-07 08:05:39 --> Config Class Initialized
INFO - 2024-06-07 08:05:39 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:05:39 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:05:39 --> Utf8 Class Initialized
INFO - 2024-06-07 08:05:39 --> URI Class Initialized
INFO - 2024-06-07 08:05:39 --> Router Class Initialized
INFO - 2024-06-07 08:05:39 --> Output Class Initialized
INFO - 2024-06-07 08:05:39 --> Security Class Initialized
DEBUG - 2024-06-07 08:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:05:39 --> Input Class Initialized
INFO - 2024-06-07 08:05:39 --> Language Class Initialized
ERROR - 2024-06-07 08:05:39 --> 404 Page Not Found: /index
INFO - 2024-06-07 08:05:39 --> Config Class Initialized
INFO - 2024-06-07 08:05:39 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:05:39 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:05:39 --> Utf8 Class Initialized
INFO - 2024-06-07 08:05:39 --> URI Class Initialized
INFO - 2024-06-07 08:05:39 --> Router Class Initialized
INFO - 2024-06-07 08:05:39 --> Output Class Initialized
INFO - 2024-06-07 08:05:39 --> Security Class Initialized
DEBUG - 2024-06-07 08:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:05:39 --> Input Class Initialized
INFO - 2024-06-07 08:05:39 --> Language Class Initialized
INFO - 2024-06-07 08:05:39 --> Language Class Initialized
INFO - 2024-06-07 08:05:39 --> Config Class Initialized
INFO - 2024-06-07 08:05:39 --> Loader Class Initialized
INFO - 2024-06-07 08:05:39 --> Helper loaded: url_helper
INFO - 2024-06-07 08:05:39 --> Helper loaded: file_helper
INFO - 2024-06-07 08:05:39 --> Helper loaded: form_helper
INFO - 2024-06-07 08:05:39 --> Helper loaded: my_helper
INFO - 2024-06-07 08:05:39 --> Database Driver Class Initialized
INFO - 2024-06-07 08:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:05:39 --> Controller Class Initialized
INFO - 2024-06-07 08:05:46 --> Config Class Initialized
INFO - 2024-06-07 08:05:46 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:05:46 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:05:46 --> Utf8 Class Initialized
INFO - 2024-06-07 08:05:46 --> URI Class Initialized
INFO - 2024-06-07 08:05:46 --> Router Class Initialized
INFO - 2024-06-07 08:05:46 --> Output Class Initialized
INFO - 2024-06-07 08:05:46 --> Security Class Initialized
DEBUG - 2024-06-07 08:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:05:46 --> Input Class Initialized
INFO - 2024-06-07 08:05:46 --> Language Class Initialized
INFO - 2024-06-07 08:05:46 --> Language Class Initialized
INFO - 2024-06-07 08:05:46 --> Config Class Initialized
INFO - 2024-06-07 08:05:46 --> Loader Class Initialized
INFO - 2024-06-07 08:05:46 --> Helper loaded: url_helper
INFO - 2024-06-07 08:05:46 --> Helper loaded: file_helper
INFO - 2024-06-07 08:05:46 --> Helper loaded: form_helper
INFO - 2024-06-07 08:05:46 --> Helper loaded: my_helper
INFO - 2024-06-07 08:05:46 --> Database Driver Class Initialized
INFO - 2024-06-07 08:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:05:46 --> Controller Class Initialized
INFO - 2024-06-07 08:05:46 --> Final output sent to browser
DEBUG - 2024-06-07 08:05:46 --> Total execution time: 0.0889
INFO - 2024-06-07 08:06:11 --> Config Class Initialized
INFO - 2024-06-07 08:06:11 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:06:11 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:06:11 --> Utf8 Class Initialized
INFO - 2024-06-07 08:06:11 --> URI Class Initialized
INFO - 2024-06-07 08:06:11 --> Router Class Initialized
INFO - 2024-06-07 08:06:11 --> Output Class Initialized
INFO - 2024-06-07 08:06:11 --> Security Class Initialized
DEBUG - 2024-06-07 08:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:06:11 --> Input Class Initialized
INFO - 2024-06-07 08:06:11 --> Language Class Initialized
INFO - 2024-06-07 08:06:11 --> Language Class Initialized
INFO - 2024-06-07 08:06:11 --> Config Class Initialized
INFO - 2024-06-07 08:06:11 --> Loader Class Initialized
INFO - 2024-06-07 08:06:11 --> Helper loaded: url_helper
INFO - 2024-06-07 08:06:11 --> Helper loaded: file_helper
INFO - 2024-06-07 08:06:11 --> Helper loaded: form_helper
INFO - 2024-06-07 08:06:11 --> Helper loaded: my_helper
INFO - 2024-06-07 08:06:11 --> Database Driver Class Initialized
INFO - 2024-06-07 08:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:06:11 --> Controller Class Initialized
INFO - 2024-06-07 08:06:11 --> Final output sent to browser
DEBUG - 2024-06-07 08:06:11 --> Total execution time: 0.0325
INFO - 2024-06-07 08:06:49 --> Config Class Initialized
INFO - 2024-06-07 08:06:49 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:06:49 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:06:49 --> Utf8 Class Initialized
INFO - 2024-06-07 08:06:49 --> URI Class Initialized
INFO - 2024-06-07 08:06:49 --> Router Class Initialized
INFO - 2024-06-07 08:06:49 --> Output Class Initialized
INFO - 2024-06-07 08:06:49 --> Security Class Initialized
DEBUG - 2024-06-07 08:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:06:49 --> Input Class Initialized
INFO - 2024-06-07 08:06:49 --> Language Class Initialized
INFO - 2024-06-07 08:06:49 --> Language Class Initialized
INFO - 2024-06-07 08:06:49 --> Config Class Initialized
INFO - 2024-06-07 08:06:49 --> Loader Class Initialized
INFO - 2024-06-07 08:06:49 --> Helper loaded: url_helper
INFO - 2024-06-07 08:06:49 --> Helper loaded: file_helper
INFO - 2024-06-07 08:06:49 --> Helper loaded: form_helper
INFO - 2024-06-07 08:06:49 --> Helper loaded: my_helper
INFO - 2024-06-07 08:06:49 --> Database Driver Class Initialized
INFO - 2024-06-07 08:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:06:49 --> Controller Class Initialized
DEBUG - 2024-06-07 08:06:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_projek/views/list.php
DEBUG - 2024-06-07 08:06:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:06:49 --> Final output sent to browser
DEBUG - 2024-06-07 08:06:49 --> Total execution time: 0.0345
INFO - 2024-06-07 08:06:49 --> Config Class Initialized
INFO - 2024-06-07 08:06:49 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:06:49 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:06:49 --> Utf8 Class Initialized
INFO - 2024-06-07 08:06:49 --> URI Class Initialized
INFO - 2024-06-07 08:06:49 --> Router Class Initialized
INFO - 2024-06-07 08:06:49 --> Output Class Initialized
INFO - 2024-06-07 08:06:49 --> Security Class Initialized
DEBUG - 2024-06-07 08:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:06:49 --> Input Class Initialized
INFO - 2024-06-07 08:06:49 --> Language Class Initialized
ERROR - 2024-06-07 08:06:49 --> 404 Page Not Found: /index
INFO - 2024-06-07 08:06:49 --> Config Class Initialized
INFO - 2024-06-07 08:06:49 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:06:49 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:06:49 --> Utf8 Class Initialized
INFO - 2024-06-07 08:06:49 --> URI Class Initialized
INFO - 2024-06-07 08:06:49 --> Router Class Initialized
INFO - 2024-06-07 08:06:49 --> Output Class Initialized
INFO - 2024-06-07 08:06:49 --> Security Class Initialized
DEBUG - 2024-06-07 08:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:06:49 --> Input Class Initialized
INFO - 2024-06-07 08:06:49 --> Language Class Initialized
INFO - 2024-06-07 08:06:49 --> Language Class Initialized
INFO - 2024-06-07 08:06:49 --> Config Class Initialized
INFO - 2024-06-07 08:06:49 --> Loader Class Initialized
INFO - 2024-06-07 08:06:49 --> Helper loaded: url_helper
INFO - 2024-06-07 08:06:49 --> Helper loaded: file_helper
INFO - 2024-06-07 08:06:49 --> Helper loaded: form_helper
INFO - 2024-06-07 08:06:49 --> Helper loaded: my_helper
INFO - 2024-06-07 08:06:49 --> Database Driver Class Initialized
INFO - 2024-06-07 08:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:06:49 --> Controller Class Initialized
INFO - 2024-06-07 08:06:54 --> Config Class Initialized
INFO - 2024-06-07 08:06:54 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:06:54 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:06:54 --> Utf8 Class Initialized
INFO - 2024-06-07 08:06:54 --> URI Class Initialized
INFO - 2024-06-07 08:06:54 --> Router Class Initialized
INFO - 2024-06-07 08:06:54 --> Output Class Initialized
INFO - 2024-06-07 08:06:54 --> Security Class Initialized
DEBUG - 2024-06-07 08:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:06:54 --> Input Class Initialized
INFO - 2024-06-07 08:06:54 --> Language Class Initialized
INFO - 2024-06-07 08:06:54 --> Language Class Initialized
INFO - 2024-06-07 08:06:54 --> Config Class Initialized
INFO - 2024-06-07 08:06:54 --> Loader Class Initialized
INFO - 2024-06-07 08:06:54 --> Helper loaded: url_helper
INFO - 2024-06-07 08:06:54 --> Helper loaded: file_helper
INFO - 2024-06-07 08:06:54 --> Helper loaded: form_helper
INFO - 2024-06-07 08:06:54 --> Helper loaded: my_helper
INFO - 2024-06-07 08:06:54 --> Database Driver Class Initialized
INFO - 2024-06-07 08:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:06:54 --> Controller Class Initialized
INFO - 2024-06-07 08:06:54 --> Final output sent to browser
DEBUG - 2024-06-07 08:06:54 --> Total execution time: 0.0430
INFO - 2024-06-07 08:08:46 --> Config Class Initialized
INFO - 2024-06-07 08:08:46 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:08:46 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:08:46 --> Utf8 Class Initialized
INFO - 2024-06-07 08:08:46 --> URI Class Initialized
INFO - 2024-06-07 08:08:46 --> Router Class Initialized
INFO - 2024-06-07 08:08:46 --> Output Class Initialized
INFO - 2024-06-07 08:08:46 --> Security Class Initialized
DEBUG - 2024-06-07 08:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:08:46 --> Input Class Initialized
INFO - 2024-06-07 08:08:46 --> Language Class Initialized
INFO - 2024-06-07 08:08:46 --> Language Class Initialized
INFO - 2024-06-07 08:08:46 --> Config Class Initialized
INFO - 2024-06-07 08:08:46 --> Loader Class Initialized
INFO - 2024-06-07 08:08:46 --> Helper loaded: url_helper
INFO - 2024-06-07 08:08:46 --> Helper loaded: file_helper
INFO - 2024-06-07 08:08:46 --> Helper loaded: form_helper
INFO - 2024-06-07 08:08:46 --> Helper loaded: my_helper
INFO - 2024-06-07 08:08:46 --> Database Driver Class Initialized
INFO - 2024-06-07 08:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:08:46 --> Controller Class Initialized
INFO - 2024-06-07 08:08:46 --> Final output sent to browser
DEBUG - 2024-06-07 08:08:46 --> Total execution time: 0.0337
INFO - 2024-06-07 08:08:46 --> Config Class Initialized
INFO - 2024-06-07 08:08:46 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:08:46 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:08:46 --> Utf8 Class Initialized
INFO - 2024-06-07 08:08:46 --> URI Class Initialized
INFO - 2024-06-07 08:08:46 --> Router Class Initialized
INFO - 2024-06-07 08:08:46 --> Output Class Initialized
INFO - 2024-06-07 08:08:46 --> Security Class Initialized
DEBUG - 2024-06-07 08:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:08:46 --> Input Class Initialized
INFO - 2024-06-07 08:08:46 --> Language Class Initialized
ERROR - 2024-06-07 08:08:46 --> 404 Page Not Found: /index
INFO - 2024-06-07 08:08:46 --> Config Class Initialized
INFO - 2024-06-07 08:08:46 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:08:46 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:08:46 --> Utf8 Class Initialized
INFO - 2024-06-07 08:08:46 --> URI Class Initialized
INFO - 2024-06-07 08:08:46 --> Router Class Initialized
INFO - 2024-06-07 08:08:46 --> Output Class Initialized
INFO - 2024-06-07 08:08:46 --> Security Class Initialized
DEBUG - 2024-06-07 08:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:08:46 --> Input Class Initialized
INFO - 2024-06-07 08:08:46 --> Language Class Initialized
INFO - 2024-06-07 08:08:46 --> Language Class Initialized
INFO - 2024-06-07 08:08:46 --> Config Class Initialized
INFO - 2024-06-07 08:08:46 --> Loader Class Initialized
INFO - 2024-06-07 08:08:46 --> Helper loaded: url_helper
INFO - 2024-06-07 08:08:46 --> Helper loaded: file_helper
INFO - 2024-06-07 08:08:46 --> Helper loaded: form_helper
INFO - 2024-06-07 08:08:46 --> Helper loaded: my_helper
INFO - 2024-06-07 08:08:46 --> Database Driver Class Initialized
INFO - 2024-06-07 08:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:08:46 --> Controller Class Initialized
INFO - 2024-06-07 08:08:50 --> Config Class Initialized
INFO - 2024-06-07 08:08:50 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:08:50 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:08:50 --> Utf8 Class Initialized
INFO - 2024-06-07 08:08:50 --> URI Class Initialized
INFO - 2024-06-07 08:08:50 --> Router Class Initialized
INFO - 2024-06-07 08:08:50 --> Output Class Initialized
INFO - 2024-06-07 08:08:50 --> Security Class Initialized
DEBUG - 2024-06-07 08:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:08:50 --> Input Class Initialized
INFO - 2024-06-07 08:08:50 --> Language Class Initialized
INFO - 2024-06-07 08:08:50 --> Language Class Initialized
INFO - 2024-06-07 08:08:50 --> Config Class Initialized
INFO - 2024-06-07 08:08:50 --> Loader Class Initialized
INFO - 2024-06-07 08:08:50 --> Helper loaded: url_helper
INFO - 2024-06-07 08:08:50 --> Helper loaded: file_helper
INFO - 2024-06-07 08:08:50 --> Helper loaded: form_helper
INFO - 2024-06-07 08:08:50 --> Helper loaded: my_helper
INFO - 2024-06-07 08:08:50 --> Database Driver Class Initialized
INFO - 2024-06-07 08:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:08:50 --> Controller Class Initialized
INFO - 2024-06-07 08:08:50 --> Final output sent to browser
DEBUG - 2024-06-07 08:08:50 --> Total execution time: 0.0282
INFO - 2024-06-07 08:08:50 --> Config Class Initialized
INFO - 2024-06-07 08:08:50 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:08:50 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:08:50 --> Utf8 Class Initialized
INFO - 2024-06-07 08:08:50 --> URI Class Initialized
INFO - 2024-06-07 08:08:50 --> Router Class Initialized
INFO - 2024-06-07 08:08:50 --> Output Class Initialized
INFO - 2024-06-07 08:08:50 --> Security Class Initialized
DEBUG - 2024-06-07 08:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:08:50 --> Input Class Initialized
INFO - 2024-06-07 08:08:50 --> Language Class Initialized
ERROR - 2024-06-07 08:08:50 --> 404 Page Not Found: /index
INFO - 2024-06-07 08:08:50 --> Config Class Initialized
INFO - 2024-06-07 08:08:50 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:08:50 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:08:50 --> Utf8 Class Initialized
INFO - 2024-06-07 08:08:50 --> URI Class Initialized
INFO - 2024-06-07 08:08:50 --> Router Class Initialized
INFO - 2024-06-07 08:08:50 --> Output Class Initialized
INFO - 2024-06-07 08:08:50 --> Security Class Initialized
DEBUG - 2024-06-07 08:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:08:50 --> Input Class Initialized
INFO - 2024-06-07 08:08:50 --> Language Class Initialized
INFO - 2024-06-07 08:08:50 --> Language Class Initialized
INFO - 2024-06-07 08:08:50 --> Config Class Initialized
INFO - 2024-06-07 08:08:50 --> Loader Class Initialized
INFO - 2024-06-07 08:08:50 --> Helper loaded: url_helper
INFO - 2024-06-07 08:08:50 --> Helper loaded: file_helper
INFO - 2024-06-07 08:08:50 --> Helper loaded: form_helper
INFO - 2024-06-07 08:08:50 --> Helper loaded: my_helper
INFO - 2024-06-07 08:08:50 --> Database Driver Class Initialized
INFO - 2024-06-07 08:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:08:50 --> Controller Class Initialized
INFO - 2024-06-07 08:08:52 --> Config Class Initialized
INFO - 2024-06-07 08:08:52 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:08:52 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:08:52 --> Utf8 Class Initialized
INFO - 2024-06-07 08:08:52 --> URI Class Initialized
INFO - 2024-06-07 08:08:52 --> Router Class Initialized
INFO - 2024-06-07 08:08:52 --> Output Class Initialized
INFO - 2024-06-07 08:08:52 --> Security Class Initialized
DEBUG - 2024-06-07 08:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:08:52 --> Input Class Initialized
INFO - 2024-06-07 08:08:52 --> Language Class Initialized
INFO - 2024-06-07 08:08:52 --> Language Class Initialized
INFO - 2024-06-07 08:08:52 --> Config Class Initialized
INFO - 2024-06-07 08:08:52 --> Loader Class Initialized
INFO - 2024-06-07 08:08:52 --> Helper loaded: url_helper
INFO - 2024-06-07 08:08:52 --> Helper loaded: file_helper
INFO - 2024-06-07 08:08:52 --> Helper loaded: form_helper
INFO - 2024-06-07 08:08:52 --> Helper loaded: my_helper
INFO - 2024-06-07 08:08:52 --> Database Driver Class Initialized
INFO - 2024-06-07 08:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:08:52 --> Controller Class Initialized
INFO - 2024-06-07 08:08:52 --> Final output sent to browser
DEBUG - 2024-06-07 08:08:52 --> Total execution time: 0.0747
INFO - 2024-06-07 08:11:16 --> Config Class Initialized
INFO - 2024-06-07 08:11:16 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:11:16 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:11:16 --> Utf8 Class Initialized
INFO - 2024-06-07 08:11:16 --> URI Class Initialized
INFO - 2024-06-07 08:11:16 --> Router Class Initialized
INFO - 2024-06-07 08:11:16 --> Output Class Initialized
INFO - 2024-06-07 08:11:16 --> Security Class Initialized
DEBUG - 2024-06-07 08:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:11:16 --> Input Class Initialized
INFO - 2024-06-07 08:11:16 --> Language Class Initialized
INFO - 2024-06-07 08:11:16 --> Language Class Initialized
INFO - 2024-06-07 08:11:16 --> Config Class Initialized
INFO - 2024-06-07 08:11:16 --> Loader Class Initialized
INFO - 2024-06-07 08:11:16 --> Helper loaded: url_helper
INFO - 2024-06-07 08:11:16 --> Helper loaded: file_helper
INFO - 2024-06-07 08:11:16 --> Helper loaded: form_helper
INFO - 2024-06-07 08:11:16 --> Helper loaded: my_helper
INFO - 2024-06-07 08:11:16 --> Database Driver Class Initialized
INFO - 2024-06-07 08:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:11:16 --> Controller Class Initialized
INFO - 2024-06-07 08:11:16 --> Final output sent to browser
DEBUG - 2024-06-07 08:11:16 --> Total execution time: 0.0385
INFO - 2024-06-07 08:11:27 --> Config Class Initialized
INFO - 2024-06-07 08:11:27 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:11:27 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:11:27 --> Utf8 Class Initialized
INFO - 2024-06-07 08:11:27 --> URI Class Initialized
INFO - 2024-06-07 08:11:27 --> Router Class Initialized
INFO - 2024-06-07 08:11:27 --> Output Class Initialized
INFO - 2024-06-07 08:11:27 --> Security Class Initialized
DEBUG - 2024-06-07 08:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:11:27 --> Input Class Initialized
INFO - 2024-06-07 08:11:27 --> Language Class Initialized
INFO - 2024-06-07 08:11:27 --> Language Class Initialized
INFO - 2024-06-07 08:11:27 --> Config Class Initialized
INFO - 2024-06-07 08:11:27 --> Loader Class Initialized
INFO - 2024-06-07 08:11:27 --> Helper loaded: url_helper
INFO - 2024-06-07 08:11:27 --> Helper loaded: file_helper
INFO - 2024-06-07 08:11:27 --> Helper loaded: form_helper
INFO - 2024-06-07 08:11:27 --> Helper loaded: my_helper
INFO - 2024-06-07 08:11:27 --> Database Driver Class Initialized
INFO - 2024-06-07 08:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:11:27 --> Controller Class Initialized
ERROR - 2024-06-07 08:11:27 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:27 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:27 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:27 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:27 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:27 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:27 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:27 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:27 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:27 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:27 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:27 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:27 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:27 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:27 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:27 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:27 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:27 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:27 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:27 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:27 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:27 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:27 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:27 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-06-07 08:11:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-07 08:11:31 --> Final output sent to browser
DEBUG - 2024-06-07 08:11:31 --> Total execution time: 3.9527
INFO - 2024-06-07 08:11:39 --> Config Class Initialized
INFO - 2024-06-07 08:11:39 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:11:39 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:11:39 --> Utf8 Class Initialized
INFO - 2024-06-07 08:11:39 --> URI Class Initialized
INFO - 2024-06-07 08:11:39 --> Router Class Initialized
INFO - 2024-06-07 08:11:39 --> Output Class Initialized
INFO - 2024-06-07 08:11:39 --> Security Class Initialized
DEBUG - 2024-06-07 08:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:11:39 --> Input Class Initialized
INFO - 2024-06-07 08:11:39 --> Language Class Initialized
INFO - 2024-06-07 08:11:39 --> Language Class Initialized
INFO - 2024-06-07 08:11:39 --> Config Class Initialized
INFO - 2024-06-07 08:11:39 --> Loader Class Initialized
INFO - 2024-06-07 08:11:39 --> Helper loaded: url_helper
INFO - 2024-06-07 08:11:39 --> Helper loaded: file_helper
INFO - 2024-06-07 08:11:39 --> Helper loaded: form_helper
INFO - 2024-06-07 08:11:39 --> Helper loaded: my_helper
INFO - 2024-06-07 08:11:39 --> Database Driver Class Initialized
INFO - 2024-06-07 08:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:11:39 --> Controller Class Initialized
ERROR - 2024-06-07 08:11:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:11:39 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-06-07 08:11:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-07 08:11:42 --> Final output sent to browser
DEBUG - 2024-06-07 08:11:42 --> Total execution time: 3.0743
INFO - 2024-06-07 08:12:02 --> Config Class Initialized
INFO - 2024-06-07 08:12:02 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:12:02 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:12:02 --> Utf8 Class Initialized
INFO - 2024-06-07 08:12:02 --> URI Class Initialized
INFO - 2024-06-07 08:12:02 --> Router Class Initialized
INFO - 2024-06-07 08:12:02 --> Output Class Initialized
INFO - 2024-06-07 08:12:02 --> Security Class Initialized
DEBUG - 2024-06-07 08:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:12:02 --> Input Class Initialized
INFO - 2024-06-07 08:12:02 --> Language Class Initialized
INFO - 2024-06-07 08:12:02 --> Language Class Initialized
INFO - 2024-06-07 08:12:02 --> Config Class Initialized
INFO - 2024-06-07 08:12:02 --> Loader Class Initialized
INFO - 2024-06-07 08:12:02 --> Helper loaded: url_helper
INFO - 2024-06-07 08:12:02 --> Helper loaded: file_helper
INFO - 2024-06-07 08:12:02 --> Helper loaded: form_helper
INFO - 2024-06-07 08:12:02 --> Helper loaded: my_helper
INFO - 2024-06-07 08:12:02 --> Database Driver Class Initialized
INFO - 2024-06-07 08:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:12:02 --> Controller Class Initialized
DEBUG - 2024-06-07 08:12:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_projek/views/list.php
DEBUG - 2024-06-07 08:12:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:12:03 --> Final output sent to browser
DEBUG - 2024-06-07 08:12:03 --> Total execution time: 0.0392
INFO - 2024-06-07 08:12:13 --> Config Class Initialized
INFO - 2024-06-07 08:12:13 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:12:13 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:12:13 --> Utf8 Class Initialized
INFO - 2024-06-07 08:12:13 --> URI Class Initialized
INFO - 2024-06-07 08:12:13 --> Router Class Initialized
INFO - 2024-06-07 08:12:13 --> Output Class Initialized
INFO - 2024-06-07 08:12:13 --> Security Class Initialized
DEBUG - 2024-06-07 08:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:12:13 --> Input Class Initialized
INFO - 2024-06-07 08:12:13 --> Language Class Initialized
INFO - 2024-06-07 08:12:13 --> Language Class Initialized
INFO - 2024-06-07 08:12:13 --> Config Class Initialized
INFO - 2024-06-07 08:12:13 --> Loader Class Initialized
INFO - 2024-06-07 08:12:13 --> Helper loaded: url_helper
INFO - 2024-06-07 08:12:13 --> Helper loaded: file_helper
INFO - 2024-06-07 08:12:13 --> Helper loaded: form_helper
INFO - 2024-06-07 08:12:13 --> Helper loaded: my_helper
INFO - 2024-06-07 08:12:13 --> Database Driver Class Initialized
INFO - 2024-06-07 08:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:12:13 --> Controller Class Initialized
DEBUG - 2024-06-07 08:12:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl1/views/list.php
DEBUG - 2024-06-07 08:12:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:12:13 --> Final output sent to browser
DEBUG - 2024-06-07 08:12:13 --> Total execution time: 0.0277
INFO - 2024-06-07 08:12:18 --> Config Class Initialized
INFO - 2024-06-07 08:12:18 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:12:18 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:12:18 --> Utf8 Class Initialized
INFO - 2024-06-07 08:12:18 --> URI Class Initialized
INFO - 2024-06-07 08:12:18 --> Router Class Initialized
INFO - 2024-06-07 08:12:18 --> Output Class Initialized
INFO - 2024-06-07 08:12:18 --> Security Class Initialized
DEBUG - 2024-06-07 08:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:12:18 --> Input Class Initialized
INFO - 2024-06-07 08:12:18 --> Language Class Initialized
INFO - 2024-06-07 08:12:18 --> Language Class Initialized
INFO - 2024-06-07 08:12:18 --> Config Class Initialized
INFO - 2024-06-07 08:12:18 --> Loader Class Initialized
INFO - 2024-06-07 08:12:18 --> Helper loaded: url_helper
INFO - 2024-06-07 08:12:18 --> Helper loaded: file_helper
INFO - 2024-06-07 08:12:18 --> Helper loaded: form_helper
INFO - 2024-06-07 08:12:18 --> Helper loaded: my_helper
INFO - 2024-06-07 08:12:18 --> Database Driver Class Initialized
INFO - 2024-06-07 08:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:12:18 --> Controller Class Initialized
DEBUG - 2024-06-07 08:12:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl2/views/list.php
DEBUG - 2024-06-07 08:12:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:12:18 --> Final output sent to browser
DEBUG - 2024-06-07 08:12:18 --> Total execution time: 0.0300
INFO - 2024-06-07 08:12:52 --> Config Class Initialized
INFO - 2024-06-07 08:12:52 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:12:52 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:12:52 --> Utf8 Class Initialized
INFO - 2024-06-07 08:12:52 --> URI Class Initialized
INFO - 2024-06-07 08:12:52 --> Router Class Initialized
INFO - 2024-06-07 08:12:52 --> Output Class Initialized
INFO - 2024-06-07 08:12:52 --> Security Class Initialized
DEBUG - 2024-06-07 08:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:12:52 --> Input Class Initialized
INFO - 2024-06-07 08:12:52 --> Language Class Initialized
INFO - 2024-06-07 08:12:52 --> Language Class Initialized
INFO - 2024-06-07 08:12:52 --> Config Class Initialized
INFO - 2024-06-07 08:12:52 --> Loader Class Initialized
INFO - 2024-06-07 08:12:52 --> Helper loaded: url_helper
INFO - 2024-06-07 08:12:52 --> Helper loaded: file_helper
INFO - 2024-06-07 08:12:52 --> Helper loaded: form_helper
INFO - 2024-06-07 08:12:52 --> Helper loaded: my_helper
INFO - 2024-06-07 08:12:52 --> Database Driver Class Initialized
INFO - 2024-06-07 08:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:12:52 --> Controller Class Initialized
DEBUG - 2024-06-07 08:12:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-07 08:12:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:12:52 --> Final output sent to browser
DEBUG - 2024-06-07 08:12:52 --> Total execution time: 0.1179
INFO - 2024-06-07 08:12:54 --> Config Class Initialized
INFO - 2024-06-07 08:12:54 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:12:54 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:12:54 --> Utf8 Class Initialized
INFO - 2024-06-07 08:12:54 --> URI Class Initialized
INFO - 2024-06-07 08:12:54 --> Router Class Initialized
INFO - 2024-06-07 08:12:54 --> Output Class Initialized
INFO - 2024-06-07 08:12:54 --> Security Class Initialized
DEBUG - 2024-06-07 08:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:12:54 --> Input Class Initialized
INFO - 2024-06-07 08:12:54 --> Language Class Initialized
INFO - 2024-06-07 08:12:54 --> Language Class Initialized
INFO - 2024-06-07 08:12:54 --> Config Class Initialized
INFO - 2024-06-07 08:12:54 --> Loader Class Initialized
INFO - 2024-06-07 08:12:54 --> Helper loaded: url_helper
INFO - 2024-06-07 08:12:54 --> Helper loaded: file_helper
INFO - 2024-06-07 08:12:54 --> Helper loaded: form_helper
INFO - 2024-06-07 08:12:54 --> Helper loaded: my_helper
INFO - 2024-06-07 08:12:54 --> Database Driver Class Initialized
INFO - 2024-06-07 08:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:12:54 --> Controller Class Initialized
ERROR - 2024-06-07 08:12:54 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-06-07 08:12:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 235
DEBUG - 2024-06-07 08:12:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-07 08:12:57 --> Final output sent to browser
DEBUG - 2024-06-07 08:12:57 --> Total execution time: 3.2303
INFO - 2024-06-07 08:15:38 --> Config Class Initialized
INFO - 2024-06-07 08:15:38 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:15:38 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:15:38 --> Utf8 Class Initialized
INFO - 2024-06-07 08:15:38 --> URI Class Initialized
INFO - 2024-06-07 08:15:38 --> Router Class Initialized
INFO - 2024-06-07 08:15:38 --> Output Class Initialized
INFO - 2024-06-07 08:15:38 --> Security Class Initialized
DEBUG - 2024-06-07 08:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:15:38 --> Input Class Initialized
INFO - 2024-06-07 08:15:38 --> Language Class Initialized
INFO - 2024-06-07 08:15:38 --> Language Class Initialized
INFO - 2024-06-07 08:15:38 --> Config Class Initialized
INFO - 2024-06-07 08:15:38 --> Loader Class Initialized
INFO - 2024-06-07 08:15:38 --> Helper loaded: url_helper
INFO - 2024-06-07 08:15:38 --> Helper loaded: file_helper
INFO - 2024-06-07 08:15:38 --> Helper loaded: form_helper
INFO - 2024-06-07 08:15:38 --> Helper loaded: my_helper
INFO - 2024-06-07 08:15:38 --> Database Driver Class Initialized
INFO - 2024-06-07 08:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:15:38 --> Controller Class Initialized
DEBUG - 2024-06-07 08:15:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-07 08:15:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:15:38 --> Final output sent to browser
DEBUG - 2024-06-07 08:15:38 --> Total execution time: 0.0455
INFO - 2024-06-07 08:15:40 --> Config Class Initialized
INFO - 2024-06-07 08:15:40 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:15:40 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:15:40 --> Utf8 Class Initialized
INFO - 2024-06-07 08:15:40 --> URI Class Initialized
INFO - 2024-06-07 08:15:40 --> Router Class Initialized
INFO - 2024-06-07 08:15:40 --> Output Class Initialized
INFO - 2024-06-07 08:15:40 --> Security Class Initialized
DEBUG - 2024-06-07 08:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:15:40 --> Input Class Initialized
INFO - 2024-06-07 08:15:40 --> Language Class Initialized
INFO - 2024-06-07 08:15:40 --> Language Class Initialized
INFO - 2024-06-07 08:15:40 --> Config Class Initialized
INFO - 2024-06-07 08:15:40 --> Loader Class Initialized
INFO - 2024-06-07 08:15:40 --> Helper loaded: url_helper
INFO - 2024-06-07 08:15:40 --> Helper loaded: file_helper
INFO - 2024-06-07 08:15:40 --> Helper loaded: form_helper
INFO - 2024-06-07 08:15:40 --> Helper loaded: my_helper
INFO - 2024-06-07 08:15:40 --> Database Driver Class Initialized
INFO - 2024-06-07 08:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:15:40 --> Controller Class Initialized
DEBUG - 2024-06-07 08:15:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-07 08:15:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:15:40 --> Final output sent to browser
DEBUG - 2024-06-07 08:15:40 --> Total execution time: 0.0365
INFO - 2024-06-07 08:15:41 --> Config Class Initialized
INFO - 2024-06-07 08:15:41 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:15:41 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:15:41 --> Utf8 Class Initialized
INFO - 2024-06-07 08:15:41 --> URI Class Initialized
INFO - 2024-06-07 08:15:41 --> Router Class Initialized
INFO - 2024-06-07 08:15:41 --> Output Class Initialized
INFO - 2024-06-07 08:15:41 --> Security Class Initialized
DEBUG - 2024-06-07 08:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:15:41 --> Input Class Initialized
INFO - 2024-06-07 08:15:41 --> Language Class Initialized
INFO - 2024-06-07 08:15:41 --> Language Class Initialized
INFO - 2024-06-07 08:15:41 --> Config Class Initialized
INFO - 2024-06-07 08:15:41 --> Loader Class Initialized
INFO - 2024-06-07 08:15:41 --> Helper loaded: url_helper
INFO - 2024-06-07 08:15:41 --> Helper loaded: file_helper
INFO - 2024-06-07 08:15:41 --> Helper loaded: form_helper
INFO - 2024-06-07 08:15:41 --> Helper loaded: my_helper
INFO - 2024-06-07 08:15:41 --> Database Driver Class Initialized
INFO - 2024-06-07 08:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:15:41 --> Controller Class Initialized
INFO - 2024-06-07 08:15:41 --> Helper loaded: cookie_helper
INFO - 2024-06-07 08:15:41 --> Final output sent to browser
DEBUG - 2024-06-07 08:15:41 --> Total execution time: 0.0433
INFO - 2024-06-07 08:15:41 --> Config Class Initialized
INFO - 2024-06-07 08:15:41 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:15:41 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:15:41 --> Utf8 Class Initialized
INFO - 2024-06-07 08:15:41 --> URI Class Initialized
INFO - 2024-06-07 08:15:41 --> Router Class Initialized
INFO - 2024-06-07 08:15:41 --> Output Class Initialized
INFO - 2024-06-07 08:15:41 --> Security Class Initialized
DEBUG - 2024-06-07 08:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:15:41 --> Input Class Initialized
INFO - 2024-06-07 08:15:41 --> Language Class Initialized
INFO - 2024-06-07 08:15:41 --> Language Class Initialized
INFO - 2024-06-07 08:15:41 --> Config Class Initialized
INFO - 2024-06-07 08:15:41 --> Loader Class Initialized
INFO - 2024-06-07 08:15:41 --> Helper loaded: url_helper
INFO - 2024-06-07 08:15:41 --> Helper loaded: file_helper
INFO - 2024-06-07 08:15:41 --> Helper loaded: form_helper
INFO - 2024-06-07 08:15:41 --> Helper loaded: my_helper
INFO - 2024-06-07 08:15:41 --> Database Driver Class Initialized
INFO - 2024-06-07 08:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:15:41 --> Controller Class Initialized
DEBUG - 2024-06-07 08:15:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-07 08:15:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:15:41 --> Final output sent to browser
DEBUG - 2024-06-07 08:15:41 --> Total execution time: 0.0344
INFO - 2024-06-07 08:15:44 --> Config Class Initialized
INFO - 2024-06-07 08:15:44 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:15:44 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:15:44 --> Utf8 Class Initialized
INFO - 2024-06-07 08:15:44 --> URI Class Initialized
INFO - 2024-06-07 08:15:44 --> Router Class Initialized
INFO - 2024-06-07 08:15:44 --> Output Class Initialized
INFO - 2024-06-07 08:15:44 --> Security Class Initialized
DEBUG - 2024-06-07 08:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:15:44 --> Input Class Initialized
INFO - 2024-06-07 08:15:44 --> Language Class Initialized
INFO - 2024-06-07 08:15:44 --> Language Class Initialized
INFO - 2024-06-07 08:15:44 --> Config Class Initialized
INFO - 2024-06-07 08:15:44 --> Loader Class Initialized
INFO - 2024-06-07 08:15:44 --> Helper loaded: url_helper
INFO - 2024-06-07 08:15:44 --> Helper loaded: file_helper
INFO - 2024-06-07 08:15:44 --> Helper loaded: form_helper
INFO - 2024-06-07 08:15:44 --> Helper loaded: my_helper
INFO - 2024-06-07 08:15:44 --> Database Driver Class Initialized
INFO - 2024-06-07 08:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:15:44 --> Controller Class Initialized
DEBUG - 2024-06-07 08:15:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-07 08:15:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:15:44 --> Final output sent to browser
DEBUG - 2024-06-07 08:15:44 --> Total execution time: 0.0388
INFO - 2024-06-07 08:15:46 --> Config Class Initialized
INFO - 2024-06-07 08:15:46 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:15:46 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:15:46 --> Utf8 Class Initialized
INFO - 2024-06-07 08:15:46 --> URI Class Initialized
INFO - 2024-06-07 08:15:46 --> Router Class Initialized
INFO - 2024-06-07 08:15:46 --> Output Class Initialized
INFO - 2024-06-07 08:15:46 --> Security Class Initialized
DEBUG - 2024-06-07 08:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:15:46 --> Input Class Initialized
INFO - 2024-06-07 08:15:46 --> Language Class Initialized
INFO - 2024-06-07 08:15:46 --> Language Class Initialized
INFO - 2024-06-07 08:15:46 --> Config Class Initialized
INFO - 2024-06-07 08:15:46 --> Loader Class Initialized
INFO - 2024-06-07 08:15:46 --> Helper loaded: url_helper
INFO - 2024-06-07 08:15:46 --> Helper loaded: file_helper
INFO - 2024-06-07 08:15:46 --> Helper loaded: form_helper
INFO - 2024-06-07 08:15:46 --> Helper loaded: my_helper
INFO - 2024-06-07 08:15:46 --> Database Driver Class Initialized
INFO - 2024-06-07 08:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:15:46 --> Controller Class Initialized
DEBUG - 2024-06-07 08:15:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-07 08:15:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:15:46 --> Final output sent to browser
DEBUG - 2024-06-07 08:15:46 --> Total execution time: 0.0592
INFO - 2024-06-07 08:15:47 --> Config Class Initialized
INFO - 2024-06-07 08:15:47 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:15:47 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:15:47 --> Utf8 Class Initialized
INFO - 2024-06-07 08:15:47 --> URI Class Initialized
INFO - 2024-06-07 08:15:47 --> Router Class Initialized
INFO - 2024-06-07 08:15:47 --> Output Class Initialized
INFO - 2024-06-07 08:15:47 --> Security Class Initialized
DEBUG - 2024-06-07 08:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:15:47 --> Input Class Initialized
INFO - 2024-06-07 08:15:47 --> Language Class Initialized
INFO - 2024-06-07 08:15:47 --> Language Class Initialized
INFO - 2024-06-07 08:15:47 --> Config Class Initialized
INFO - 2024-06-07 08:15:47 --> Loader Class Initialized
INFO - 2024-06-07 08:15:47 --> Helper loaded: url_helper
INFO - 2024-06-07 08:15:47 --> Helper loaded: file_helper
INFO - 2024-06-07 08:15:47 --> Helper loaded: form_helper
INFO - 2024-06-07 08:15:47 --> Helper loaded: my_helper
INFO - 2024-06-07 08:15:47 --> Database Driver Class Initialized
INFO - 2024-06-07 08:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:15:47 --> Controller Class Initialized
INFO - 2024-06-07 08:16:01 --> Config Class Initialized
INFO - 2024-06-07 08:16:01 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:16:01 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:16:01 --> Utf8 Class Initialized
INFO - 2024-06-07 08:16:01 --> URI Class Initialized
INFO - 2024-06-07 08:16:01 --> Router Class Initialized
INFO - 2024-06-07 08:16:01 --> Output Class Initialized
INFO - 2024-06-07 08:16:01 --> Security Class Initialized
DEBUG - 2024-06-07 08:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:16:01 --> Input Class Initialized
INFO - 2024-06-07 08:16:01 --> Language Class Initialized
INFO - 2024-06-07 08:16:01 --> Language Class Initialized
INFO - 2024-06-07 08:16:01 --> Config Class Initialized
INFO - 2024-06-07 08:16:01 --> Loader Class Initialized
INFO - 2024-06-07 08:16:01 --> Helper loaded: url_helper
INFO - 2024-06-07 08:16:01 --> Helper loaded: file_helper
INFO - 2024-06-07 08:16:01 --> Helper loaded: form_helper
INFO - 2024-06-07 08:16:01 --> Helper loaded: my_helper
INFO - 2024-06-07 08:16:01 --> Database Driver Class Initialized
INFO - 2024-06-07 08:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:16:01 --> Controller Class Initialized
INFO - 2024-06-07 08:16:01 --> Final output sent to browser
DEBUG - 2024-06-07 08:16:01 --> Total execution time: 0.0361
INFO - 2024-06-07 08:16:04 --> Config Class Initialized
INFO - 2024-06-07 08:16:04 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:16:04 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:16:04 --> Utf8 Class Initialized
INFO - 2024-06-07 08:16:04 --> URI Class Initialized
INFO - 2024-06-07 08:16:04 --> Router Class Initialized
INFO - 2024-06-07 08:16:04 --> Output Class Initialized
INFO - 2024-06-07 08:16:04 --> Security Class Initialized
DEBUG - 2024-06-07 08:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:16:04 --> Input Class Initialized
INFO - 2024-06-07 08:16:04 --> Language Class Initialized
INFO - 2024-06-07 08:16:04 --> Language Class Initialized
INFO - 2024-06-07 08:16:04 --> Config Class Initialized
INFO - 2024-06-07 08:16:04 --> Loader Class Initialized
INFO - 2024-06-07 08:16:04 --> Helper loaded: url_helper
INFO - 2024-06-07 08:16:04 --> Helper loaded: file_helper
INFO - 2024-06-07 08:16:04 --> Helper loaded: form_helper
INFO - 2024-06-07 08:16:04 --> Helper loaded: my_helper
INFO - 2024-06-07 08:16:04 --> Database Driver Class Initialized
INFO - 2024-06-07 08:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:16:04 --> Controller Class Initialized
INFO - 2024-06-07 08:16:04 --> Final output sent to browser
DEBUG - 2024-06-07 08:16:04 --> Total execution time: 0.0328
INFO - 2024-06-07 08:16:10 --> Config Class Initialized
INFO - 2024-06-07 08:16:10 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:16:10 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:16:10 --> Utf8 Class Initialized
INFO - 2024-06-07 08:16:10 --> URI Class Initialized
INFO - 2024-06-07 08:16:10 --> Router Class Initialized
INFO - 2024-06-07 08:16:10 --> Output Class Initialized
INFO - 2024-06-07 08:16:10 --> Security Class Initialized
DEBUG - 2024-06-07 08:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:16:10 --> Input Class Initialized
INFO - 2024-06-07 08:16:10 --> Language Class Initialized
INFO - 2024-06-07 08:16:10 --> Language Class Initialized
INFO - 2024-06-07 08:16:10 --> Config Class Initialized
INFO - 2024-06-07 08:16:10 --> Loader Class Initialized
INFO - 2024-06-07 08:16:10 --> Helper loaded: url_helper
INFO - 2024-06-07 08:16:10 --> Helper loaded: file_helper
INFO - 2024-06-07 08:16:10 --> Helper loaded: form_helper
INFO - 2024-06-07 08:16:10 --> Helper loaded: my_helper
INFO - 2024-06-07 08:16:10 --> Database Driver Class Initialized
INFO - 2024-06-07 08:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:16:10 --> Controller Class Initialized
DEBUG - 2024-06-07 08:16:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-07 08:16:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:16:10 --> Final output sent to browser
DEBUG - 2024-06-07 08:16:10 --> Total execution time: 0.0468
INFO - 2024-06-07 08:16:13 --> Config Class Initialized
INFO - 2024-06-07 08:16:13 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:16:13 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:16:13 --> Utf8 Class Initialized
INFO - 2024-06-07 08:16:13 --> URI Class Initialized
INFO - 2024-06-07 08:16:13 --> Router Class Initialized
INFO - 2024-06-07 08:16:13 --> Output Class Initialized
INFO - 2024-06-07 08:16:13 --> Security Class Initialized
DEBUG - 2024-06-07 08:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:16:13 --> Input Class Initialized
INFO - 2024-06-07 08:16:13 --> Language Class Initialized
INFO - 2024-06-07 08:16:13 --> Language Class Initialized
INFO - 2024-06-07 08:16:13 --> Config Class Initialized
INFO - 2024-06-07 08:16:13 --> Loader Class Initialized
INFO - 2024-06-07 08:16:13 --> Helper loaded: url_helper
INFO - 2024-06-07 08:16:13 --> Helper loaded: file_helper
INFO - 2024-06-07 08:16:13 --> Helper loaded: form_helper
INFO - 2024-06-07 08:16:13 --> Helper loaded: my_helper
INFO - 2024-06-07 08:16:13 --> Database Driver Class Initialized
INFO - 2024-06-07 08:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:16:13 --> Controller Class Initialized
DEBUG - 2024-06-07 08:16:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-07 08:16:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:16:13 --> Final output sent to browser
DEBUG - 2024-06-07 08:16:13 --> Total execution time: 0.0339
INFO - 2024-06-07 08:16:13 --> Config Class Initialized
INFO - 2024-06-07 08:16:13 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:16:13 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:16:13 --> Utf8 Class Initialized
INFO - 2024-06-07 08:16:13 --> URI Class Initialized
INFO - 2024-06-07 08:16:13 --> Router Class Initialized
INFO - 2024-06-07 08:16:13 --> Output Class Initialized
INFO - 2024-06-07 08:16:13 --> Security Class Initialized
DEBUG - 2024-06-07 08:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:16:13 --> Input Class Initialized
INFO - 2024-06-07 08:16:13 --> Language Class Initialized
INFO - 2024-06-07 08:16:13 --> Language Class Initialized
INFO - 2024-06-07 08:16:13 --> Config Class Initialized
INFO - 2024-06-07 08:16:13 --> Loader Class Initialized
INFO - 2024-06-07 08:16:13 --> Helper loaded: url_helper
INFO - 2024-06-07 08:16:13 --> Helper loaded: file_helper
INFO - 2024-06-07 08:16:13 --> Helper loaded: form_helper
INFO - 2024-06-07 08:16:13 --> Helper loaded: my_helper
INFO - 2024-06-07 08:16:13 --> Database Driver Class Initialized
INFO - 2024-06-07 08:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:16:13 --> Controller Class Initialized
INFO - 2024-06-07 08:17:00 --> Config Class Initialized
INFO - 2024-06-07 08:17:00 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:17:00 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:17:00 --> Utf8 Class Initialized
INFO - 2024-06-07 08:17:00 --> URI Class Initialized
INFO - 2024-06-07 08:17:00 --> Router Class Initialized
INFO - 2024-06-07 08:17:00 --> Output Class Initialized
INFO - 2024-06-07 08:17:00 --> Security Class Initialized
DEBUG - 2024-06-07 08:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:17:00 --> Input Class Initialized
INFO - 2024-06-07 08:17:00 --> Language Class Initialized
INFO - 2024-06-07 08:17:00 --> Language Class Initialized
INFO - 2024-06-07 08:17:00 --> Config Class Initialized
INFO - 2024-06-07 08:17:00 --> Loader Class Initialized
INFO - 2024-06-07 08:17:00 --> Helper loaded: url_helper
INFO - 2024-06-07 08:17:00 --> Helper loaded: file_helper
INFO - 2024-06-07 08:17:00 --> Helper loaded: form_helper
INFO - 2024-06-07 08:17:00 --> Helper loaded: my_helper
INFO - 2024-06-07 08:17:00 --> Database Driver Class Initialized
INFO - 2024-06-07 08:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:17:00 --> Controller Class Initialized
INFO - 2024-06-07 08:17:00 --> Final output sent to browser
DEBUG - 2024-06-07 08:17:00 --> Total execution time: 0.0321
INFO - 2024-06-07 08:17:08 --> Config Class Initialized
INFO - 2024-06-07 08:17:08 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:17:08 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:17:08 --> Utf8 Class Initialized
INFO - 2024-06-07 08:17:08 --> URI Class Initialized
INFO - 2024-06-07 08:17:08 --> Router Class Initialized
INFO - 2024-06-07 08:17:08 --> Output Class Initialized
INFO - 2024-06-07 08:17:08 --> Security Class Initialized
DEBUG - 2024-06-07 08:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:17:08 --> Input Class Initialized
INFO - 2024-06-07 08:17:08 --> Language Class Initialized
INFO - 2024-06-07 08:17:08 --> Language Class Initialized
INFO - 2024-06-07 08:17:08 --> Config Class Initialized
INFO - 2024-06-07 08:17:08 --> Loader Class Initialized
INFO - 2024-06-07 08:17:08 --> Helper loaded: url_helper
INFO - 2024-06-07 08:17:08 --> Helper loaded: file_helper
INFO - 2024-06-07 08:17:08 --> Helper loaded: form_helper
INFO - 2024-06-07 08:17:08 --> Helper loaded: my_helper
INFO - 2024-06-07 08:17:08 --> Database Driver Class Initialized
INFO - 2024-06-07 08:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:17:08 --> Controller Class Initialized
INFO - 2024-06-07 08:17:08 --> Final output sent to browser
DEBUG - 2024-06-07 08:17:08 --> Total execution time: 0.0267
INFO - 2024-06-07 08:17:11 --> Config Class Initialized
INFO - 2024-06-07 08:17:11 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:17:11 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:17:11 --> Utf8 Class Initialized
INFO - 2024-06-07 08:17:11 --> URI Class Initialized
INFO - 2024-06-07 08:17:11 --> Router Class Initialized
INFO - 2024-06-07 08:17:11 --> Output Class Initialized
INFO - 2024-06-07 08:17:11 --> Security Class Initialized
DEBUG - 2024-06-07 08:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:17:11 --> Input Class Initialized
INFO - 2024-06-07 08:17:11 --> Language Class Initialized
INFO - 2024-06-07 08:17:11 --> Language Class Initialized
INFO - 2024-06-07 08:17:11 --> Config Class Initialized
INFO - 2024-06-07 08:17:11 --> Loader Class Initialized
INFO - 2024-06-07 08:17:11 --> Helper loaded: url_helper
INFO - 2024-06-07 08:17:11 --> Helper loaded: file_helper
INFO - 2024-06-07 08:17:11 --> Helper loaded: form_helper
INFO - 2024-06-07 08:17:11 --> Helper loaded: my_helper
INFO - 2024-06-07 08:17:11 --> Database Driver Class Initialized
INFO - 2024-06-07 08:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:17:11 --> Controller Class Initialized
INFO - 2024-06-07 08:17:11 --> Final output sent to browser
DEBUG - 2024-06-07 08:17:11 --> Total execution time: 0.0361
INFO - 2024-06-07 08:18:35 --> Config Class Initialized
INFO - 2024-06-07 08:18:35 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:18:35 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:18:35 --> Utf8 Class Initialized
INFO - 2024-06-07 08:18:35 --> URI Class Initialized
INFO - 2024-06-07 08:18:35 --> Router Class Initialized
INFO - 2024-06-07 08:18:35 --> Output Class Initialized
INFO - 2024-06-07 08:18:35 --> Security Class Initialized
DEBUG - 2024-06-07 08:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:18:35 --> Input Class Initialized
INFO - 2024-06-07 08:18:35 --> Language Class Initialized
INFO - 2024-06-07 08:18:35 --> Language Class Initialized
INFO - 2024-06-07 08:18:35 --> Config Class Initialized
INFO - 2024-06-07 08:18:35 --> Loader Class Initialized
INFO - 2024-06-07 08:18:35 --> Helper loaded: url_helper
INFO - 2024-06-07 08:18:35 --> Helper loaded: file_helper
INFO - 2024-06-07 08:18:35 --> Helper loaded: form_helper
INFO - 2024-06-07 08:18:35 --> Helper loaded: my_helper
INFO - 2024-06-07 08:18:35 --> Database Driver Class Initialized
INFO - 2024-06-07 08:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:18:35 --> Controller Class Initialized
INFO - 2024-06-07 08:18:35 --> Final output sent to browser
DEBUG - 2024-06-07 08:18:35 --> Total execution time: 0.0313
INFO - 2024-06-07 08:19:05 --> Config Class Initialized
INFO - 2024-06-07 08:19:05 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:19:05 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:19:05 --> Utf8 Class Initialized
INFO - 2024-06-07 08:19:05 --> URI Class Initialized
INFO - 2024-06-07 08:19:05 --> Router Class Initialized
INFO - 2024-06-07 08:19:05 --> Output Class Initialized
INFO - 2024-06-07 08:19:05 --> Security Class Initialized
DEBUG - 2024-06-07 08:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:19:05 --> Input Class Initialized
INFO - 2024-06-07 08:19:05 --> Language Class Initialized
INFO - 2024-06-07 08:19:05 --> Language Class Initialized
INFO - 2024-06-07 08:19:05 --> Config Class Initialized
INFO - 2024-06-07 08:19:05 --> Loader Class Initialized
INFO - 2024-06-07 08:19:05 --> Helper loaded: url_helper
INFO - 2024-06-07 08:19:05 --> Helper loaded: file_helper
INFO - 2024-06-07 08:19:05 --> Helper loaded: form_helper
INFO - 2024-06-07 08:19:05 --> Helper loaded: my_helper
INFO - 2024-06-07 08:19:05 --> Database Driver Class Initialized
INFO - 2024-06-07 08:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:19:05 --> Controller Class Initialized
INFO - 2024-06-07 08:19:05 --> Final output sent to browser
DEBUG - 2024-06-07 08:19:05 --> Total execution time: 0.0316
INFO - 2024-06-07 08:19:05 --> Config Class Initialized
INFO - 2024-06-07 08:19:05 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:19:05 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:19:05 --> Utf8 Class Initialized
INFO - 2024-06-07 08:19:05 --> URI Class Initialized
INFO - 2024-06-07 08:19:05 --> Router Class Initialized
INFO - 2024-06-07 08:19:05 --> Output Class Initialized
INFO - 2024-06-07 08:19:05 --> Security Class Initialized
DEBUG - 2024-06-07 08:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:19:05 --> Input Class Initialized
INFO - 2024-06-07 08:19:05 --> Language Class Initialized
INFO - 2024-06-07 08:19:05 --> Language Class Initialized
INFO - 2024-06-07 08:19:05 --> Config Class Initialized
INFO - 2024-06-07 08:19:05 --> Loader Class Initialized
INFO - 2024-06-07 08:19:05 --> Helper loaded: url_helper
INFO - 2024-06-07 08:19:05 --> Helper loaded: file_helper
INFO - 2024-06-07 08:19:05 --> Helper loaded: form_helper
INFO - 2024-06-07 08:19:05 --> Helper loaded: my_helper
INFO - 2024-06-07 08:19:05 --> Database Driver Class Initialized
INFO - 2024-06-07 08:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:19:05 --> Controller Class Initialized
INFO - 2024-06-07 08:19:24 --> Config Class Initialized
INFO - 2024-06-07 08:19:24 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:19:24 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:19:24 --> Utf8 Class Initialized
INFO - 2024-06-07 08:19:24 --> URI Class Initialized
INFO - 2024-06-07 08:19:24 --> Router Class Initialized
INFO - 2024-06-07 08:19:24 --> Output Class Initialized
INFO - 2024-06-07 08:19:24 --> Security Class Initialized
DEBUG - 2024-06-07 08:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:19:24 --> Input Class Initialized
INFO - 2024-06-07 08:19:24 --> Language Class Initialized
INFO - 2024-06-07 08:19:24 --> Language Class Initialized
INFO - 2024-06-07 08:19:24 --> Config Class Initialized
INFO - 2024-06-07 08:19:24 --> Loader Class Initialized
INFO - 2024-06-07 08:19:24 --> Helper loaded: url_helper
INFO - 2024-06-07 08:19:24 --> Helper loaded: file_helper
INFO - 2024-06-07 08:19:24 --> Helper loaded: form_helper
INFO - 2024-06-07 08:19:24 --> Helper loaded: my_helper
INFO - 2024-06-07 08:19:24 --> Database Driver Class Initialized
INFO - 2024-06-07 08:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:19:24 --> Controller Class Initialized
INFO - 2024-06-07 08:19:24 --> Final output sent to browser
DEBUG - 2024-06-07 08:19:24 --> Total execution time: 0.0444
INFO - 2024-06-07 08:19:40 --> Config Class Initialized
INFO - 2024-06-07 08:19:40 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:19:40 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:19:40 --> Utf8 Class Initialized
INFO - 2024-06-07 08:19:40 --> URI Class Initialized
INFO - 2024-06-07 08:19:40 --> Router Class Initialized
INFO - 2024-06-07 08:19:40 --> Output Class Initialized
INFO - 2024-06-07 08:19:40 --> Security Class Initialized
DEBUG - 2024-06-07 08:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:19:40 --> Input Class Initialized
INFO - 2024-06-07 08:19:40 --> Language Class Initialized
INFO - 2024-06-07 08:19:40 --> Language Class Initialized
INFO - 2024-06-07 08:19:40 --> Config Class Initialized
INFO - 2024-06-07 08:19:40 --> Loader Class Initialized
INFO - 2024-06-07 08:19:40 --> Helper loaded: url_helper
INFO - 2024-06-07 08:19:40 --> Helper loaded: file_helper
INFO - 2024-06-07 08:19:40 --> Helper loaded: form_helper
INFO - 2024-06-07 08:19:40 --> Helper loaded: my_helper
INFO - 2024-06-07 08:19:40 --> Database Driver Class Initialized
INFO - 2024-06-07 08:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:19:40 --> Controller Class Initialized
INFO - 2024-06-07 08:19:40 --> Final output sent to browser
DEBUG - 2024-06-07 08:19:40 --> Total execution time: 0.0283
INFO - 2024-06-07 08:19:40 --> Config Class Initialized
INFO - 2024-06-07 08:19:40 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:19:40 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:19:40 --> Utf8 Class Initialized
INFO - 2024-06-07 08:19:40 --> URI Class Initialized
INFO - 2024-06-07 08:19:40 --> Router Class Initialized
INFO - 2024-06-07 08:19:40 --> Output Class Initialized
INFO - 2024-06-07 08:19:40 --> Security Class Initialized
DEBUG - 2024-06-07 08:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:19:40 --> Input Class Initialized
INFO - 2024-06-07 08:19:40 --> Language Class Initialized
INFO - 2024-06-07 08:19:40 --> Language Class Initialized
INFO - 2024-06-07 08:19:40 --> Config Class Initialized
INFO - 2024-06-07 08:19:40 --> Loader Class Initialized
INFO - 2024-06-07 08:19:40 --> Helper loaded: url_helper
INFO - 2024-06-07 08:19:40 --> Helper loaded: file_helper
INFO - 2024-06-07 08:19:40 --> Helper loaded: form_helper
INFO - 2024-06-07 08:19:40 --> Helper loaded: my_helper
INFO - 2024-06-07 08:19:40 --> Database Driver Class Initialized
INFO - 2024-06-07 08:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:19:40 --> Controller Class Initialized
INFO - 2024-06-07 08:20:56 --> Config Class Initialized
INFO - 2024-06-07 08:20:56 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:20:56 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:20:56 --> Utf8 Class Initialized
INFO - 2024-06-07 08:20:56 --> URI Class Initialized
INFO - 2024-06-07 08:20:56 --> Router Class Initialized
INFO - 2024-06-07 08:20:56 --> Output Class Initialized
INFO - 2024-06-07 08:20:56 --> Security Class Initialized
DEBUG - 2024-06-07 08:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:20:56 --> Input Class Initialized
INFO - 2024-06-07 08:20:56 --> Language Class Initialized
INFO - 2024-06-07 08:20:56 --> Language Class Initialized
INFO - 2024-06-07 08:20:56 --> Config Class Initialized
INFO - 2024-06-07 08:20:56 --> Loader Class Initialized
INFO - 2024-06-07 08:20:56 --> Helper loaded: url_helper
INFO - 2024-06-07 08:20:56 --> Helper loaded: file_helper
INFO - 2024-06-07 08:20:56 --> Helper loaded: form_helper
INFO - 2024-06-07 08:20:56 --> Helper loaded: my_helper
INFO - 2024-06-07 08:20:56 --> Database Driver Class Initialized
INFO - 2024-06-07 08:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:20:56 --> Controller Class Initialized
INFO - 2024-06-07 08:20:56 --> Final output sent to browser
DEBUG - 2024-06-07 08:20:56 --> Total execution time: 0.0322
INFO - 2024-06-07 08:21:10 --> Config Class Initialized
INFO - 2024-06-07 08:21:10 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:21:10 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:21:10 --> Utf8 Class Initialized
INFO - 2024-06-07 08:21:10 --> URI Class Initialized
INFO - 2024-06-07 08:21:10 --> Router Class Initialized
INFO - 2024-06-07 08:21:10 --> Output Class Initialized
INFO - 2024-06-07 08:21:10 --> Security Class Initialized
DEBUG - 2024-06-07 08:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:21:10 --> Input Class Initialized
INFO - 2024-06-07 08:21:10 --> Language Class Initialized
INFO - 2024-06-07 08:21:10 --> Language Class Initialized
INFO - 2024-06-07 08:21:10 --> Config Class Initialized
INFO - 2024-06-07 08:21:10 --> Loader Class Initialized
INFO - 2024-06-07 08:21:10 --> Helper loaded: url_helper
INFO - 2024-06-07 08:21:10 --> Helper loaded: file_helper
INFO - 2024-06-07 08:21:10 --> Helper loaded: form_helper
INFO - 2024-06-07 08:21:10 --> Helper loaded: my_helper
INFO - 2024-06-07 08:21:10 --> Database Driver Class Initialized
INFO - 2024-06-07 08:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:21:10 --> Controller Class Initialized
INFO - 2024-06-07 08:21:10 --> Final output sent to browser
DEBUG - 2024-06-07 08:21:10 --> Total execution time: 0.0438
INFO - 2024-06-07 08:21:10 --> Config Class Initialized
INFO - 2024-06-07 08:21:10 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:21:10 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:21:10 --> Utf8 Class Initialized
INFO - 2024-06-07 08:21:10 --> URI Class Initialized
INFO - 2024-06-07 08:21:10 --> Router Class Initialized
INFO - 2024-06-07 08:21:10 --> Output Class Initialized
INFO - 2024-06-07 08:21:11 --> Security Class Initialized
DEBUG - 2024-06-07 08:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:21:11 --> Input Class Initialized
INFO - 2024-06-07 08:21:11 --> Language Class Initialized
INFO - 2024-06-07 08:21:11 --> Language Class Initialized
INFO - 2024-06-07 08:21:11 --> Config Class Initialized
INFO - 2024-06-07 08:21:11 --> Loader Class Initialized
INFO - 2024-06-07 08:21:11 --> Helper loaded: url_helper
INFO - 2024-06-07 08:21:11 --> Helper loaded: file_helper
INFO - 2024-06-07 08:21:11 --> Helper loaded: form_helper
INFO - 2024-06-07 08:21:11 --> Helper loaded: my_helper
INFO - 2024-06-07 08:21:11 --> Database Driver Class Initialized
INFO - 2024-06-07 08:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:21:11 --> Controller Class Initialized
INFO - 2024-06-07 08:21:54 --> Config Class Initialized
INFO - 2024-06-07 08:21:54 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:21:54 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:21:54 --> Utf8 Class Initialized
INFO - 2024-06-07 08:21:54 --> URI Class Initialized
INFO - 2024-06-07 08:21:54 --> Router Class Initialized
INFO - 2024-06-07 08:21:54 --> Output Class Initialized
INFO - 2024-06-07 08:21:54 --> Security Class Initialized
DEBUG - 2024-06-07 08:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:21:54 --> Input Class Initialized
INFO - 2024-06-07 08:21:54 --> Language Class Initialized
INFO - 2024-06-07 08:21:54 --> Language Class Initialized
INFO - 2024-06-07 08:21:54 --> Config Class Initialized
INFO - 2024-06-07 08:21:54 --> Loader Class Initialized
INFO - 2024-06-07 08:21:54 --> Helper loaded: url_helper
INFO - 2024-06-07 08:21:54 --> Helper loaded: file_helper
INFO - 2024-06-07 08:21:54 --> Helper loaded: form_helper
INFO - 2024-06-07 08:21:54 --> Helper loaded: my_helper
INFO - 2024-06-07 08:21:54 --> Database Driver Class Initialized
INFO - 2024-06-07 08:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:21:54 --> Controller Class Initialized
INFO - 2024-06-07 08:21:54 --> Final output sent to browser
DEBUG - 2024-06-07 08:21:54 --> Total execution time: 0.0274
INFO - 2024-06-07 08:22:07 --> Config Class Initialized
INFO - 2024-06-07 08:22:07 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:22:07 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:22:07 --> Utf8 Class Initialized
INFO - 2024-06-07 08:22:07 --> URI Class Initialized
INFO - 2024-06-07 08:22:07 --> Router Class Initialized
INFO - 2024-06-07 08:22:07 --> Output Class Initialized
INFO - 2024-06-07 08:22:07 --> Security Class Initialized
DEBUG - 2024-06-07 08:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:22:07 --> Input Class Initialized
INFO - 2024-06-07 08:22:07 --> Language Class Initialized
INFO - 2024-06-07 08:22:07 --> Language Class Initialized
INFO - 2024-06-07 08:22:07 --> Config Class Initialized
INFO - 2024-06-07 08:22:07 --> Loader Class Initialized
INFO - 2024-06-07 08:22:07 --> Helper loaded: url_helper
INFO - 2024-06-07 08:22:07 --> Helper loaded: file_helper
INFO - 2024-06-07 08:22:07 --> Helper loaded: form_helper
INFO - 2024-06-07 08:22:07 --> Helper loaded: my_helper
INFO - 2024-06-07 08:22:07 --> Database Driver Class Initialized
INFO - 2024-06-07 08:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:22:07 --> Controller Class Initialized
INFO - 2024-06-07 08:22:07 --> Final output sent to browser
DEBUG - 2024-06-07 08:22:07 --> Total execution time: 0.0419
INFO - 2024-06-07 08:22:07 --> Config Class Initialized
INFO - 2024-06-07 08:22:07 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:22:07 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:22:07 --> Utf8 Class Initialized
INFO - 2024-06-07 08:22:07 --> URI Class Initialized
INFO - 2024-06-07 08:22:07 --> Router Class Initialized
INFO - 2024-06-07 08:22:07 --> Output Class Initialized
INFO - 2024-06-07 08:22:07 --> Security Class Initialized
DEBUG - 2024-06-07 08:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:22:07 --> Input Class Initialized
INFO - 2024-06-07 08:22:07 --> Language Class Initialized
INFO - 2024-06-07 08:22:07 --> Language Class Initialized
INFO - 2024-06-07 08:22:07 --> Config Class Initialized
INFO - 2024-06-07 08:22:07 --> Loader Class Initialized
INFO - 2024-06-07 08:22:07 --> Helper loaded: url_helper
INFO - 2024-06-07 08:22:07 --> Helper loaded: file_helper
INFO - 2024-06-07 08:22:07 --> Helper loaded: form_helper
INFO - 2024-06-07 08:22:07 --> Helper loaded: my_helper
INFO - 2024-06-07 08:22:07 --> Database Driver Class Initialized
INFO - 2024-06-07 08:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:22:07 --> Controller Class Initialized
INFO - 2024-06-07 08:22:18 --> Config Class Initialized
INFO - 2024-06-07 08:22:18 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:22:18 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:22:18 --> Utf8 Class Initialized
INFO - 2024-06-07 08:22:18 --> URI Class Initialized
INFO - 2024-06-07 08:22:18 --> Router Class Initialized
INFO - 2024-06-07 08:22:18 --> Output Class Initialized
INFO - 2024-06-07 08:22:18 --> Security Class Initialized
DEBUG - 2024-06-07 08:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:22:18 --> Input Class Initialized
INFO - 2024-06-07 08:22:18 --> Language Class Initialized
INFO - 2024-06-07 08:22:18 --> Language Class Initialized
INFO - 2024-06-07 08:22:18 --> Config Class Initialized
INFO - 2024-06-07 08:22:18 --> Loader Class Initialized
INFO - 2024-06-07 08:22:18 --> Helper loaded: url_helper
INFO - 2024-06-07 08:22:18 --> Helper loaded: file_helper
INFO - 2024-06-07 08:22:18 --> Helper loaded: form_helper
INFO - 2024-06-07 08:22:18 --> Helper loaded: my_helper
INFO - 2024-06-07 08:22:18 --> Database Driver Class Initialized
INFO - 2024-06-07 08:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:22:18 --> Controller Class Initialized
INFO - 2024-06-07 08:22:18 --> Final output sent to browser
DEBUG - 2024-06-07 08:22:18 --> Total execution time: 0.0314
INFO - 2024-06-07 08:22:33 --> Config Class Initialized
INFO - 2024-06-07 08:22:33 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:22:33 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:22:33 --> Utf8 Class Initialized
INFO - 2024-06-07 08:22:33 --> URI Class Initialized
INFO - 2024-06-07 08:22:33 --> Router Class Initialized
INFO - 2024-06-07 08:22:33 --> Output Class Initialized
INFO - 2024-06-07 08:22:33 --> Security Class Initialized
DEBUG - 2024-06-07 08:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:22:33 --> Input Class Initialized
INFO - 2024-06-07 08:22:33 --> Language Class Initialized
INFO - 2024-06-07 08:22:33 --> Language Class Initialized
INFO - 2024-06-07 08:22:33 --> Config Class Initialized
INFO - 2024-06-07 08:22:33 --> Loader Class Initialized
INFO - 2024-06-07 08:22:33 --> Helper loaded: url_helper
INFO - 2024-06-07 08:22:33 --> Helper loaded: file_helper
INFO - 2024-06-07 08:22:33 --> Helper loaded: form_helper
INFO - 2024-06-07 08:22:33 --> Helper loaded: my_helper
INFO - 2024-06-07 08:22:33 --> Database Driver Class Initialized
INFO - 2024-06-07 08:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:22:33 --> Controller Class Initialized
INFO - 2024-06-07 08:22:33 --> Final output sent to browser
DEBUG - 2024-06-07 08:22:33 --> Total execution time: 0.0270
INFO - 2024-06-07 08:22:33 --> Config Class Initialized
INFO - 2024-06-07 08:22:33 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:22:33 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:22:33 --> Utf8 Class Initialized
INFO - 2024-06-07 08:22:33 --> URI Class Initialized
INFO - 2024-06-07 08:22:33 --> Router Class Initialized
INFO - 2024-06-07 08:22:33 --> Output Class Initialized
INFO - 2024-06-07 08:22:33 --> Security Class Initialized
DEBUG - 2024-06-07 08:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:22:33 --> Input Class Initialized
INFO - 2024-06-07 08:22:33 --> Language Class Initialized
INFO - 2024-06-07 08:22:33 --> Language Class Initialized
INFO - 2024-06-07 08:22:33 --> Config Class Initialized
INFO - 2024-06-07 08:22:33 --> Loader Class Initialized
INFO - 2024-06-07 08:22:33 --> Helper loaded: url_helper
INFO - 2024-06-07 08:22:33 --> Helper loaded: file_helper
INFO - 2024-06-07 08:22:33 --> Helper loaded: form_helper
INFO - 2024-06-07 08:22:33 --> Helper loaded: my_helper
INFO - 2024-06-07 08:22:33 --> Database Driver Class Initialized
INFO - 2024-06-07 08:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:22:33 --> Controller Class Initialized
INFO - 2024-06-07 08:22:55 --> Config Class Initialized
INFO - 2024-06-07 08:22:55 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:22:55 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:22:55 --> Utf8 Class Initialized
INFO - 2024-06-07 08:22:55 --> URI Class Initialized
INFO - 2024-06-07 08:22:55 --> Router Class Initialized
INFO - 2024-06-07 08:22:55 --> Output Class Initialized
INFO - 2024-06-07 08:22:55 --> Security Class Initialized
DEBUG - 2024-06-07 08:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:22:55 --> Input Class Initialized
INFO - 2024-06-07 08:22:55 --> Language Class Initialized
INFO - 2024-06-07 08:22:55 --> Language Class Initialized
INFO - 2024-06-07 08:22:55 --> Config Class Initialized
INFO - 2024-06-07 08:22:55 --> Loader Class Initialized
INFO - 2024-06-07 08:22:55 --> Helper loaded: url_helper
INFO - 2024-06-07 08:22:55 --> Helper loaded: file_helper
INFO - 2024-06-07 08:22:55 --> Helper loaded: form_helper
INFO - 2024-06-07 08:22:55 --> Helper loaded: my_helper
INFO - 2024-06-07 08:22:55 --> Database Driver Class Initialized
INFO - 2024-06-07 08:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:22:55 --> Controller Class Initialized
INFO - 2024-06-07 08:41:56 --> Config Class Initialized
INFO - 2024-06-07 08:41:56 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:41:56 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:41:56 --> Utf8 Class Initialized
INFO - 2024-06-07 08:41:56 --> URI Class Initialized
INFO - 2024-06-07 08:41:56 --> Router Class Initialized
INFO - 2024-06-07 08:41:56 --> Output Class Initialized
INFO - 2024-06-07 08:41:56 --> Security Class Initialized
DEBUG - 2024-06-07 08:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:41:56 --> Input Class Initialized
INFO - 2024-06-07 08:41:56 --> Language Class Initialized
INFO - 2024-06-07 08:41:56 --> Language Class Initialized
INFO - 2024-06-07 08:41:56 --> Config Class Initialized
INFO - 2024-06-07 08:41:56 --> Loader Class Initialized
INFO - 2024-06-07 08:41:56 --> Helper loaded: url_helper
INFO - 2024-06-07 08:41:56 --> Helper loaded: file_helper
INFO - 2024-06-07 08:41:56 --> Helper loaded: form_helper
INFO - 2024-06-07 08:41:56 --> Helper loaded: my_helper
INFO - 2024-06-07 08:41:56 --> Database Driver Class Initialized
INFO - 2024-06-07 08:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:41:56 --> Controller Class Initialized
DEBUG - 2024-06-07 08:41:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-07 08:41:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:41:56 --> Final output sent to browser
DEBUG - 2024-06-07 08:41:56 --> Total execution time: 0.1943
INFO - 2024-06-07 08:42:01 --> Config Class Initialized
INFO - 2024-06-07 08:42:01 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:42:01 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:42:01 --> Utf8 Class Initialized
INFO - 2024-06-07 08:42:01 --> URI Class Initialized
INFO - 2024-06-07 08:42:01 --> Router Class Initialized
INFO - 2024-06-07 08:42:01 --> Output Class Initialized
INFO - 2024-06-07 08:42:01 --> Security Class Initialized
DEBUG - 2024-06-07 08:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:42:01 --> Input Class Initialized
INFO - 2024-06-07 08:42:01 --> Language Class Initialized
INFO - 2024-06-07 08:42:01 --> Language Class Initialized
INFO - 2024-06-07 08:42:01 --> Config Class Initialized
INFO - 2024-06-07 08:42:01 --> Loader Class Initialized
INFO - 2024-06-07 08:42:01 --> Helper loaded: url_helper
INFO - 2024-06-07 08:42:01 --> Helper loaded: file_helper
INFO - 2024-06-07 08:42:01 --> Helper loaded: form_helper
INFO - 2024-06-07 08:42:01 --> Helper loaded: my_helper
INFO - 2024-06-07 08:42:01 --> Database Driver Class Initialized
INFO - 2024-06-07 08:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:42:01 --> Controller Class Initialized
INFO - 2024-06-07 08:42:01 --> Helper loaded: cookie_helper
INFO - 2024-06-07 08:42:01 --> Final output sent to browser
DEBUG - 2024-06-07 08:42:01 --> Total execution time: 0.1474
INFO - 2024-06-07 08:42:01 --> Config Class Initialized
INFO - 2024-06-07 08:42:01 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:42:01 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:42:01 --> Utf8 Class Initialized
INFO - 2024-06-07 08:42:01 --> URI Class Initialized
INFO - 2024-06-07 08:42:01 --> Router Class Initialized
INFO - 2024-06-07 08:42:01 --> Output Class Initialized
INFO - 2024-06-07 08:42:01 --> Security Class Initialized
DEBUG - 2024-06-07 08:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:42:01 --> Input Class Initialized
INFO - 2024-06-07 08:42:01 --> Language Class Initialized
INFO - 2024-06-07 08:42:01 --> Language Class Initialized
INFO - 2024-06-07 08:42:01 --> Config Class Initialized
INFO - 2024-06-07 08:42:01 --> Loader Class Initialized
INFO - 2024-06-07 08:42:01 --> Helper loaded: url_helper
INFO - 2024-06-07 08:42:01 --> Helper loaded: file_helper
INFO - 2024-06-07 08:42:01 --> Helper loaded: form_helper
INFO - 2024-06-07 08:42:01 --> Helper loaded: my_helper
INFO - 2024-06-07 08:42:02 --> Database Driver Class Initialized
INFO - 2024-06-07 08:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:42:02 --> Controller Class Initialized
DEBUG - 2024-06-07 08:42:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-07 08:42:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:42:02 --> Final output sent to browser
DEBUG - 2024-06-07 08:42:02 --> Total execution time: 0.1697
INFO - 2024-06-07 08:42:07 --> Config Class Initialized
INFO - 2024-06-07 08:42:07 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:42:07 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:42:07 --> Utf8 Class Initialized
INFO - 2024-06-07 08:42:07 --> URI Class Initialized
INFO - 2024-06-07 08:42:07 --> Router Class Initialized
INFO - 2024-06-07 08:42:07 --> Output Class Initialized
INFO - 2024-06-07 08:42:07 --> Security Class Initialized
DEBUG - 2024-06-07 08:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:42:07 --> Input Class Initialized
INFO - 2024-06-07 08:42:07 --> Language Class Initialized
INFO - 2024-06-07 08:42:07 --> Language Class Initialized
INFO - 2024-06-07 08:42:07 --> Config Class Initialized
INFO - 2024-06-07 08:42:07 --> Loader Class Initialized
INFO - 2024-06-07 08:42:07 --> Helper loaded: url_helper
INFO - 2024-06-07 08:42:07 --> Helper loaded: file_helper
INFO - 2024-06-07 08:42:07 --> Helper loaded: form_helper
INFO - 2024-06-07 08:42:07 --> Helper loaded: my_helper
INFO - 2024-06-07 08:42:07 --> Database Driver Class Initialized
INFO - 2024-06-07 08:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:42:07 --> Controller Class Initialized
DEBUG - 2024-06-07 08:42:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/views/landing.php
DEBUG - 2024-06-07 08:42:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:42:07 --> Final output sent to browser
DEBUG - 2024-06-07 08:42:07 --> Total execution time: 0.0355
INFO - 2024-06-07 08:42:09 --> Config Class Initialized
INFO - 2024-06-07 08:42:09 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:42:09 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:42:09 --> Utf8 Class Initialized
INFO - 2024-06-07 08:42:09 --> URI Class Initialized
INFO - 2024-06-07 08:42:09 --> Router Class Initialized
INFO - 2024-06-07 08:42:09 --> Output Class Initialized
INFO - 2024-06-07 08:42:09 --> Security Class Initialized
DEBUG - 2024-06-07 08:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:42:09 --> Input Class Initialized
INFO - 2024-06-07 08:42:09 --> Language Class Initialized
INFO - 2024-06-07 08:42:09 --> Language Class Initialized
INFO - 2024-06-07 08:42:09 --> Config Class Initialized
INFO - 2024-06-07 08:42:09 --> Loader Class Initialized
INFO - 2024-06-07 08:42:09 --> Helper loaded: url_helper
INFO - 2024-06-07 08:42:09 --> Helper loaded: file_helper
INFO - 2024-06-07 08:42:09 --> Helper loaded: form_helper
INFO - 2024-06-07 08:42:09 --> Helper loaded: my_helper
INFO - 2024-06-07 08:42:09 --> Database Driver Class Initialized
INFO - 2024-06-07 08:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:42:09 --> Controller Class Initialized
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-06-07 08:42:09 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
DEBUG - 2024-06-07 08:42:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/views/cetak.php
INFO - 2024-06-07 08:42:09 --> Final output sent to browser
DEBUG - 2024-06-07 08:42:09 --> Total execution time: 0.2861
INFO - 2024-06-07 08:42:19 --> Config Class Initialized
INFO - 2024-06-07 08:42:19 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:42:19 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:42:19 --> Utf8 Class Initialized
INFO - 2024-06-07 08:42:19 --> URI Class Initialized
INFO - 2024-06-07 08:42:19 --> Router Class Initialized
INFO - 2024-06-07 08:42:19 --> Output Class Initialized
INFO - 2024-06-07 08:42:19 --> Security Class Initialized
DEBUG - 2024-06-07 08:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:42:19 --> Input Class Initialized
INFO - 2024-06-07 08:42:19 --> Language Class Initialized
INFO - 2024-06-07 08:42:19 --> Language Class Initialized
INFO - 2024-06-07 08:42:19 --> Config Class Initialized
INFO - 2024-06-07 08:42:19 --> Loader Class Initialized
INFO - 2024-06-07 08:42:19 --> Helper loaded: url_helper
INFO - 2024-06-07 08:42:19 --> Helper loaded: file_helper
INFO - 2024-06-07 08:42:19 --> Helper loaded: form_helper
INFO - 2024-06-07 08:42:19 --> Helper loaded: my_helper
INFO - 2024-06-07 08:42:19 --> Database Driver Class Initialized
INFO - 2024-06-07 08:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:42:19 --> Controller Class Initialized
INFO - 2024-06-07 08:42:19 --> Helper loaded: cookie_helper
INFO - 2024-06-07 08:42:19 --> Config Class Initialized
INFO - 2024-06-07 08:42:19 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:42:19 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:42:19 --> Utf8 Class Initialized
INFO - 2024-06-07 08:42:19 --> URI Class Initialized
INFO - 2024-06-07 08:42:19 --> Router Class Initialized
INFO - 2024-06-07 08:42:19 --> Output Class Initialized
INFO - 2024-06-07 08:42:19 --> Security Class Initialized
DEBUG - 2024-06-07 08:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:42:19 --> Input Class Initialized
INFO - 2024-06-07 08:42:19 --> Language Class Initialized
INFO - 2024-06-07 08:42:19 --> Language Class Initialized
INFO - 2024-06-07 08:42:19 --> Config Class Initialized
INFO - 2024-06-07 08:42:19 --> Loader Class Initialized
INFO - 2024-06-07 08:42:19 --> Helper loaded: url_helper
INFO - 2024-06-07 08:42:19 --> Helper loaded: file_helper
INFO - 2024-06-07 08:42:19 --> Helper loaded: form_helper
INFO - 2024-06-07 08:42:19 --> Helper loaded: my_helper
INFO - 2024-06-07 08:42:19 --> Database Driver Class Initialized
INFO - 2024-06-07 08:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:42:19 --> Controller Class Initialized
INFO - 2024-06-07 08:42:19 --> Config Class Initialized
INFO - 2024-06-07 08:42:19 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:42:19 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:42:19 --> Utf8 Class Initialized
INFO - 2024-06-07 08:42:19 --> URI Class Initialized
INFO - 2024-06-07 08:42:19 --> Router Class Initialized
INFO - 2024-06-07 08:42:19 --> Output Class Initialized
INFO - 2024-06-07 08:42:19 --> Security Class Initialized
DEBUG - 2024-06-07 08:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:42:19 --> Input Class Initialized
INFO - 2024-06-07 08:42:19 --> Language Class Initialized
INFO - 2024-06-07 08:42:19 --> Language Class Initialized
INFO - 2024-06-07 08:42:19 --> Config Class Initialized
INFO - 2024-06-07 08:42:19 --> Loader Class Initialized
INFO - 2024-06-07 08:42:19 --> Helper loaded: url_helper
INFO - 2024-06-07 08:42:19 --> Helper loaded: file_helper
INFO - 2024-06-07 08:42:19 --> Helper loaded: form_helper
INFO - 2024-06-07 08:42:19 --> Helper loaded: my_helper
INFO - 2024-06-07 08:42:19 --> Database Driver Class Initialized
INFO - 2024-06-07 08:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:42:19 --> Controller Class Initialized
DEBUG - 2024-06-07 08:42:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-07 08:42:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:42:19 --> Final output sent to browser
DEBUG - 2024-06-07 08:42:19 --> Total execution time: 0.0292
INFO - 2024-06-07 08:42:24 --> Config Class Initialized
INFO - 2024-06-07 08:42:24 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:42:24 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:42:24 --> Utf8 Class Initialized
INFO - 2024-06-07 08:42:24 --> URI Class Initialized
INFO - 2024-06-07 08:42:24 --> Router Class Initialized
INFO - 2024-06-07 08:42:24 --> Output Class Initialized
INFO - 2024-06-07 08:42:24 --> Security Class Initialized
DEBUG - 2024-06-07 08:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:42:24 --> Input Class Initialized
INFO - 2024-06-07 08:42:24 --> Language Class Initialized
INFO - 2024-06-07 08:42:24 --> Language Class Initialized
INFO - 2024-06-07 08:42:24 --> Config Class Initialized
INFO - 2024-06-07 08:42:24 --> Loader Class Initialized
INFO - 2024-06-07 08:42:24 --> Helper loaded: url_helper
INFO - 2024-06-07 08:42:24 --> Helper loaded: file_helper
INFO - 2024-06-07 08:42:24 --> Helper loaded: form_helper
INFO - 2024-06-07 08:42:24 --> Helper loaded: my_helper
INFO - 2024-06-07 08:42:24 --> Database Driver Class Initialized
INFO - 2024-06-07 08:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:42:24 --> Controller Class Initialized
INFO - 2024-06-07 08:42:24 --> Helper loaded: cookie_helper
INFO - 2024-06-07 08:42:24 --> Final output sent to browser
DEBUG - 2024-06-07 08:42:24 --> Total execution time: 0.0322
INFO - 2024-06-07 08:42:24 --> Config Class Initialized
INFO - 2024-06-07 08:42:24 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:42:24 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:42:24 --> Utf8 Class Initialized
INFO - 2024-06-07 08:42:24 --> URI Class Initialized
INFO - 2024-06-07 08:42:24 --> Router Class Initialized
INFO - 2024-06-07 08:42:24 --> Output Class Initialized
INFO - 2024-06-07 08:42:24 --> Security Class Initialized
DEBUG - 2024-06-07 08:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:42:24 --> Input Class Initialized
INFO - 2024-06-07 08:42:24 --> Language Class Initialized
INFO - 2024-06-07 08:42:24 --> Language Class Initialized
INFO - 2024-06-07 08:42:24 --> Config Class Initialized
INFO - 2024-06-07 08:42:24 --> Loader Class Initialized
INFO - 2024-06-07 08:42:24 --> Helper loaded: url_helper
INFO - 2024-06-07 08:42:24 --> Helper loaded: file_helper
INFO - 2024-06-07 08:42:24 --> Helper loaded: form_helper
INFO - 2024-06-07 08:42:24 --> Helper loaded: my_helper
INFO - 2024-06-07 08:42:24 --> Database Driver Class Initialized
INFO - 2024-06-07 08:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:42:24 --> Controller Class Initialized
DEBUG - 2024-06-07 08:42:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-06-07 08:42:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:42:24 --> Final output sent to browser
DEBUG - 2024-06-07 08:42:24 --> Total execution time: 0.0492
INFO - 2024-06-07 08:43:55 --> Config Class Initialized
INFO - 2024-06-07 08:43:55 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:43:55 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:43:55 --> Utf8 Class Initialized
INFO - 2024-06-07 08:43:55 --> URI Class Initialized
INFO - 2024-06-07 08:43:55 --> Router Class Initialized
INFO - 2024-06-07 08:43:55 --> Output Class Initialized
INFO - 2024-06-07 08:43:55 --> Security Class Initialized
DEBUG - 2024-06-07 08:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:43:55 --> Input Class Initialized
INFO - 2024-06-07 08:43:55 --> Language Class Initialized
INFO - 2024-06-07 08:43:55 --> Language Class Initialized
INFO - 2024-06-07 08:43:55 --> Config Class Initialized
INFO - 2024-06-07 08:43:55 --> Loader Class Initialized
INFO - 2024-06-07 08:43:55 --> Helper loaded: url_helper
INFO - 2024-06-07 08:43:55 --> Helper loaded: file_helper
INFO - 2024-06-07 08:43:55 --> Helper loaded: form_helper
INFO - 2024-06-07 08:43:55 --> Helper loaded: my_helper
INFO - 2024-06-07 08:43:55 --> Database Driver Class Initialized
INFO - 2024-06-07 08:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:43:55 --> Controller Class Initialized
INFO - 2024-06-07 08:43:55 --> Helper loaded: cookie_helper
INFO - 2024-06-07 08:43:56 --> Config Class Initialized
INFO - 2024-06-07 08:43:56 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:43:56 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:43:56 --> Utf8 Class Initialized
INFO - 2024-06-07 08:43:56 --> URI Class Initialized
INFO - 2024-06-07 08:43:56 --> Router Class Initialized
INFO - 2024-06-07 08:43:56 --> Output Class Initialized
INFO - 2024-06-07 08:43:56 --> Security Class Initialized
DEBUG - 2024-06-07 08:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:43:56 --> Input Class Initialized
INFO - 2024-06-07 08:43:56 --> Language Class Initialized
INFO - 2024-06-07 08:43:56 --> Language Class Initialized
INFO - 2024-06-07 08:43:56 --> Config Class Initialized
INFO - 2024-06-07 08:43:56 --> Loader Class Initialized
INFO - 2024-06-07 08:43:56 --> Helper loaded: url_helper
INFO - 2024-06-07 08:43:56 --> Helper loaded: file_helper
INFO - 2024-06-07 08:43:56 --> Helper loaded: form_helper
INFO - 2024-06-07 08:43:56 --> Helper loaded: my_helper
INFO - 2024-06-07 08:43:56 --> Database Driver Class Initialized
INFO - 2024-06-07 08:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:43:56 --> Controller Class Initialized
INFO - 2024-06-07 08:43:56 --> Config Class Initialized
INFO - 2024-06-07 08:43:56 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:43:56 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:43:56 --> Utf8 Class Initialized
INFO - 2024-06-07 08:43:56 --> URI Class Initialized
INFO - 2024-06-07 08:43:56 --> Router Class Initialized
INFO - 2024-06-07 08:43:56 --> Output Class Initialized
INFO - 2024-06-07 08:43:56 --> Security Class Initialized
DEBUG - 2024-06-07 08:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:43:56 --> Input Class Initialized
INFO - 2024-06-07 08:43:56 --> Language Class Initialized
INFO - 2024-06-07 08:43:56 --> Language Class Initialized
INFO - 2024-06-07 08:43:56 --> Config Class Initialized
INFO - 2024-06-07 08:43:56 --> Loader Class Initialized
INFO - 2024-06-07 08:43:56 --> Helper loaded: url_helper
INFO - 2024-06-07 08:43:56 --> Helper loaded: file_helper
INFO - 2024-06-07 08:43:56 --> Helper loaded: form_helper
INFO - 2024-06-07 08:43:56 --> Helper loaded: my_helper
INFO - 2024-06-07 08:43:56 --> Database Driver Class Initialized
INFO - 2024-06-07 08:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:43:56 --> Controller Class Initialized
DEBUG - 2024-06-07 08:43:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-07 08:43:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:43:56 --> Final output sent to browser
DEBUG - 2024-06-07 08:43:56 --> Total execution time: 0.0297
INFO - 2024-06-07 08:44:01 --> Config Class Initialized
INFO - 2024-06-07 08:44:01 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:44:01 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:44:01 --> Utf8 Class Initialized
INFO - 2024-06-07 08:44:01 --> URI Class Initialized
INFO - 2024-06-07 08:44:01 --> Router Class Initialized
INFO - 2024-06-07 08:44:01 --> Output Class Initialized
INFO - 2024-06-07 08:44:01 --> Security Class Initialized
DEBUG - 2024-06-07 08:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:44:01 --> Input Class Initialized
INFO - 2024-06-07 08:44:01 --> Language Class Initialized
INFO - 2024-06-07 08:44:01 --> Language Class Initialized
INFO - 2024-06-07 08:44:01 --> Config Class Initialized
INFO - 2024-06-07 08:44:01 --> Loader Class Initialized
INFO - 2024-06-07 08:44:01 --> Helper loaded: url_helper
INFO - 2024-06-07 08:44:01 --> Helper loaded: file_helper
INFO - 2024-06-07 08:44:01 --> Helper loaded: form_helper
INFO - 2024-06-07 08:44:01 --> Helper loaded: my_helper
INFO - 2024-06-07 08:44:01 --> Database Driver Class Initialized
INFO - 2024-06-07 08:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:44:01 --> Controller Class Initialized
INFO - 2024-06-07 08:44:01 --> Helper loaded: cookie_helper
INFO - 2024-06-07 08:44:01 --> Final output sent to browser
DEBUG - 2024-06-07 08:44:01 --> Total execution time: 0.0308
INFO - 2024-06-07 08:44:01 --> Config Class Initialized
INFO - 2024-06-07 08:44:01 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:44:01 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:44:01 --> Utf8 Class Initialized
INFO - 2024-06-07 08:44:01 --> URI Class Initialized
INFO - 2024-06-07 08:44:01 --> Router Class Initialized
INFO - 2024-06-07 08:44:01 --> Output Class Initialized
INFO - 2024-06-07 08:44:01 --> Security Class Initialized
DEBUG - 2024-06-07 08:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:44:01 --> Input Class Initialized
INFO - 2024-06-07 08:44:01 --> Language Class Initialized
INFO - 2024-06-07 08:44:01 --> Language Class Initialized
INFO - 2024-06-07 08:44:01 --> Config Class Initialized
INFO - 2024-06-07 08:44:01 --> Loader Class Initialized
INFO - 2024-06-07 08:44:01 --> Helper loaded: url_helper
INFO - 2024-06-07 08:44:01 --> Helper loaded: file_helper
INFO - 2024-06-07 08:44:01 --> Helper loaded: form_helper
INFO - 2024-06-07 08:44:01 --> Helper loaded: my_helper
INFO - 2024-06-07 08:44:01 --> Database Driver Class Initialized
INFO - 2024-06-07 08:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:44:01 --> Controller Class Initialized
DEBUG - 2024-06-07 08:44:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-06-07 08:44:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:44:01 --> Final output sent to browser
DEBUG - 2024-06-07 08:44:01 --> Total execution time: 0.0325
INFO - 2024-06-07 08:44:06 --> Config Class Initialized
INFO - 2024-06-07 08:44:06 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:44:06 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:44:06 --> Utf8 Class Initialized
INFO - 2024-06-07 08:44:06 --> URI Class Initialized
INFO - 2024-06-07 08:44:06 --> Router Class Initialized
INFO - 2024-06-07 08:44:06 --> Output Class Initialized
INFO - 2024-06-07 08:44:06 --> Security Class Initialized
DEBUG - 2024-06-07 08:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:44:06 --> Input Class Initialized
INFO - 2024-06-07 08:44:06 --> Language Class Initialized
INFO - 2024-06-07 08:44:06 --> Language Class Initialized
INFO - 2024-06-07 08:44:06 --> Config Class Initialized
INFO - 2024-06-07 08:44:06 --> Loader Class Initialized
INFO - 2024-06-07 08:44:06 --> Helper loaded: url_helper
INFO - 2024-06-07 08:44:06 --> Helper loaded: file_helper
INFO - 2024-06-07 08:44:06 --> Helper loaded: form_helper
INFO - 2024-06-07 08:44:06 --> Helper loaded: my_helper
INFO - 2024-06-07 08:44:06 --> Database Driver Class Initialized
INFO - 2024-06-07 08:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:44:06 --> Controller Class Initialized
DEBUG - 2024-06-07 08:44:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-06-07 08:44:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:44:06 --> Final output sent to browser
DEBUG - 2024-06-07 08:44:06 --> Total execution time: 0.0315
INFO - 2024-06-07 08:44:06 --> Config Class Initialized
INFO - 2024-06-07 08:44:06 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:44:06 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:44:06 --> Utf8 Class Initialized
INFO - 2024-06-07 08:44:06 --> URI Class Initialized
INFO - 2024-06-07 08:44:06 --> Router Class Initialized
INFO - 2024-06-07 08:44:06 --> Output Class Initialized
INFO - 2024-06-07 08:44:06 --> Security Class Initialized
DEBUG - 2024-06-07 08:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:44:06 --> Input Class Initialized
INFO - 2024-06-07 08:44:06 --> Language Class Initialized
ERROR - 2024-06-07 08:44:06 --> 404 Page Not Found: /index
INFO - 2024-06-07 08:44:06 --> Config Class Initialized
INFO - 2024-06-07 08:44:06 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:44:06 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:44:06 --> Utf8 Class Initialized
INFO - 2024-06-07 08:44:06 --> URI Class Initialized
INFO - 2024-06-07 08:44:06 --> Router Class Initialized
INFO - 2024-06-07 08:44:06 --> Output Class Initialized
INFO - 2024-06-07 08:44:06 --> Security Class Initialized
DEBUG - 2024-06-07 08:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:44:06 --> Input Class Initialized
INFO - 2024-06-07 08:44:06 --> Language Class Initialized
INFO - 2024-06-07 08:44:06 --> Language Class Initialized
INFO - 2024-06-07 08:44:06 --> Config Class Initialized
INFO - 2024-06-07 08:44:06 --> Loader Class Initialized
INFO - 2024-06-07 08:44:06 --> Helper loaded: url_helper
INFO - 2024-06-07 08:44:06 --> Helper loaded: file_helper
INFO - 2024-06-07 08:44:06 --> Helper loaded: form_helper
INFO - 2024-06-07 08:44:06 --> Helper loaded: my_helper
INFO - 2024-06-07 08:44:06 --> Database Driver Class Initialized
INFO - 2024-06-07 08:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:44:06 --> Controller Class Initialized
INFO - 2024-06-07 08:44:08 --> Config Class Initialized
INFO - 2024-06-07 08:44:08 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:44:08 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:44:08 --> Utf8 Class Initialized
INFO - 2024-06-07 08:44:08 --> URI Class Initialized
INFO - 2024-06-07 08:44:08 --> Router Class Initialized
INFO - 2024-06-07 08:44:08 --> Output Class Initialized
INFO - 2024-06-07 08:44:08 --> Security Class Initialized
DEBUG - 2024-06-07 08:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:44:08 --> Input Class Initialized
INFO - 2024-06-07 08:44:08 --> Language Class Initialized
INFO - 2024-06-07 08:44:08 --> Language Class Initialized
INFO - 2024-06-07 08:44:08 --> Config Class Initialized
INFO - 2024-06-07 08:44:08 --> Loader Class Initialized
INFO - 2024-06-07 08:44:08 --> Helper loaded: url_helper
INFO - 2024-06-07 08:44:08 --> Helper loaded: file_helper
INFO - 2024-06-07 08:44:08 --> Helper loaded: form_helper
INFO - 2024-06-07 08:44:08 --> Helper loaded: my_helper
INFO - 2024-06-07 08:44:08 --> Database Driver Class Initialized
INFO - 2024-06-07 08:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:44:08 --> Controller Class Initialized
INFO - 2024-06-07 08:44:08 --> Final output sent to browser
DEBUG - 2024-06-07 08:44:08 --> Total execution time: 0.0311
INFO - 2024-06-07 08:44:08 --> Config Class Initialized
INFO - 2024-06-07 08:44:08 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:44:08 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:44:08 --> Utf8 Class Initialized
INFO - 2024-06-07 08:44:08 --> URI Class Initialized
INFO - 2024-06-07 08:44:08 --> Router Class Initialized
INFO - 2024-06-07 08:44:08 --> Output Class Initialized
INFO - 2024-06-07 08:44:08 --> Security Class Initialized
DEBUG - 2024-06-07 08:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:44:08 --> Input Class Initialized
INFO - 2024-06-07 08:44:08 --> Language Class Initialized
ERROR - 2024-06-07 08:44:08 --> 404 Page Not Found: /index
INFO - 2024-06-07 08:44:08 --> Config Class Initialized
INFO - 2024-06-07 08:44:08 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:44:08 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:44:08 --> Utf8 Class Initialized
INFO - 2024-06-07 08:44:08 --> URI Class Initialized
INFO - 2024-06-07 08:44:08 --> Router Class Initialized
INFO - 2024-06-07 08:44:08 --> Output Class Initialized
INFO - 2024-06-07 08:44:08 --> Security Class Initialized
DEBUG - 2024-06-07 08:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:44:08 --> Input Class Initialized
INFO - 2024-06-07 08:44:08 --> Language Class Initialized
INFO - 2024-06-07 08:44:08 --> Language Class Initialized
INFO - 2024-06-07 08:44:08 --> Config Class Initialized
INFO - 2024-06-07 08:44:08 --> Loader Class Initialized
INFO - 2024-06-07 08:44:08 --> Helper loaded: url_helper
INFO - 2024-06-07 08:44:08 --> Helper loaded: file_helper
INFO - 2024-06-07 08:44:08 --> Helper loaded: form_helper
INFO - 2024-06-07 08:44:08 --> Helper loaded: my_helper
INFO - 2024-06-07 08:44:08 --> Database Driver Class Initialized
INFO - 2024-06-07 08:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:44:08 --> Controller Class Initialized
INFO - 2024-06-07 08:44:12 --> Config Class Initialized
INFO - 2024-06-07 08:44:12 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:44:12 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:44:12 --> Utf8 Class Initialized
INFO - 2024-06-07 08:44:12 --> URI Class Initialized
INFO - 2024-06-07 08:44:12 --> Router Class Initialized
INFO - 2024-06-07 08:44:12 --> Output Class Initialized
INFO - 2024-06-07 08:44:12 --> Security Class Initialized
DEBUG - 2024-06-07 08:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:44:12 --> Input Class Initialized
INFO - 2024-06-07 08:44:12 --> Language Class Initialized
INFO - 2024-06-07 08:44:12 --> Language Class Initialized
INFO - 2024-06-07 08:44:12 --> Config Class Initialized
INFO - 2024-06-07 08:44:12 --> Loader Class Initialized
INFO - 2024-06-07 08:44:12 --> Helper loaded: url_helper
INFO - 2024-06-07 08:44:12 --> Helper loaded: file_helper
INFO - 2024-06-07 08:44:12 --> Helper loaded: form_helper
INFO - 2024-06-07 08:44:12 --> Helper loaded: my_helper
INFO - 2024-06-07 08:44:12 --> Database Driver Class Initialized
INFO - 2024-06-07 08:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:44:12 --> Controller Class Initialized
INFO - 2024-06-07 08:44:12 --> Helper loaded: cookie_helper
INFO - 2024-06-07 08:44:12 --> Config Class Initialized
INFO - 2024-06-07 08:44:12 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:44:12 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:44:12 --> Utf8 Class Initialized
INFO - 2024-06-07 08:44:12 --> URI Class Initialized
INFO - 2024-06-07 08:44:12 --> Router Class Initialized
INFO - 2024-06-07 08:44:12 --> Output Class Initialized
INFO - 2024-06-07 08:44:12 --> Security Class Initialized
DEBUG - 2024-06-07 08:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:44:12 --> Input Class Initialized
INFO - 2024-06-07 08:44:12 --> Language Class Initialized
INFO - 2024-06-07 08:44:12 --> Language Class Initialized
INFO - 2024-06-07 08:44:12 --> Config Class Initialized
INFO - 2024-06-07 08:44:12 --> Loader Class Initialized
INFO - 2024-06-07 08:44:12 --> Helper loaded: url_helper
INFO - 2024-06-07 08:44:12 --> Helper loaded: file_helper
INFO - 2024-06-07 08:44:12 --> Helper loaded: form_helper
INFO - 2024-06-07 08:44:12 --> Helper loaded: my_helper
INFO - 2024-06-07 08:44:12 --> Database Driver Class Initialized
INFO - 2024-06-07 08:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:44:12 --> Controller Class Initialized
INFO - 2024-06-07 08:44:12 --> Config Class Initialized
INFO - 2024-06-07 08:44:12 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:44:12 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:44:12 --> Utf8 Class Initialized
INFO - 2024-06-07 08:44:12 --> URI Class Initialized
INFO - 2024-06-07 08:44:12 --> Router Class Initialized
INFO - 2024-06-07 08:44:12 --> Output Class Initialized
INFO - 2024-06-07 08:44:12 --> Security Class Initialized
DEBUG - 2024-06-07 08:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:44:12 --> Input Class Initialized
INFO - 2024-06-07 08:44:12 --> Language Class Initialized
INFO - 2024-06-07 08:44:12 --> Language Class Initialized
INFO - 2024-06-07 08:44:12 --> Config Class Initialized
INFO - 2024-06-07 08:44:12 --> Loader Class Initialized
INFO - 2024-06-07 08:44:12 --> Helper loaded: url_helper
INFO - 2024-06-07 08:44:12 --> Helper loaded: file_helper
INFO - 2024-06-07 08:44:12 --> Helper loaded: form_helper
INFO - 2024-06-07 08:44:12 --> Helper loaded: my_helper
INFO - 2024-06-07 08:44:12 --> Database Driver Class Initialized
INFO - 2024-06-07 08:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:44:12 --> Controller Class Initialized
DEBUG - 2024-06-07 08:44:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-07 08:44:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:44:12 --> Final output sent to browser
DEBUG - 2024-06-07 08:44:12 --> Total execution time: 0.0306
INFO - 2024-06-07 08:44:18 --> Config Class Initialized
INFO - 2024-06-07 08:44:18 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:44:18 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:44:18 --> Utf8 Class Initialized
INFO - 2024-06-07 08:44:18 --> URI Class Initialized
INFO - 2024-06-07 08:44:18 --> Router Class Initialized
INFO - 2024-06-07 08:44:18 --> Output Class Initialized
INFO - 2024-06-07 08:44:18 --> Security Class Initialized
DEBUG - 2024-06-07 08:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:44:18 --> Input Class Initialized
INFO - 2024-06-07 08:44:18 --> Language Class Initialized
INFO - 2024-06-07 08:44:18 --> Language Class Initialized
INFO - 2024-06-07 08:44:18 --> Config Class Initialized
INFO - 2024-06-07 08:44:18 --> Loader Class Initialized
INFO - 2024-06-07 08:44:18 --> Helper loaded: url_helper
INFO - 2024-06-07 08:44:18 --> Helper loaded: file_helper
INFO - 2024-06-07 08:44:18 --> Helper loaded: form_helper
INFO - 2024-06-07 08:44:18 --> Helper loaded: my_helper
INFO - 2024-06-07 08:44:18 --> Database Driver Class Initialized
INFO - 2024-06-07 08:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:44:18 --> Controller Class Initialized
INFO - 2024-06-07 08:44:18 --> Helper loaded: cookie_helper
INFO - 2024-06-07 08:44:18 --> Final output sent to browser
DEBUG - 2024-06-07 08:44:18 --> Total execution time: 0.0375
INFO - 2024-06-07 08:44:18 --> Config Class Initialized
INFO - 2024-06-07 08:44:18 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:44:18 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:44:18 --> Utf8 Class Initialized
INFO - 2024-06-07 08:44:18 --> URI Class Initialized
INFO - 2024-06-07 08:44:18 --> Router Class Initialized
INFO - 2024-06-07 08:44:18 --> Output Class Initialized
INFO - 2024-06-07 08:44:18 --> Security Class Initialized
DEBUG - 2024-06-07 08:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:44:18 --> Input Class Initialized
INFO - 2024-06-07 08:44:18 --> Language Class Initialized
INFO - 2024-06-07 08:44:18 --> Language Class Initialized
INFO - 2024-06-07 08:44:18 --> Config Class Initialized
INFO - 2024-06-07 08:44:18 --> Loader Class Initialized
INFO - 2024-06-07 08:44:18 --> Helper loaded: url_helper
INFO - 2024-06-07 08:44:18 --> Helper loaded: file_helper
INFO - 2024-06-07 08:44:18 --> Helper loaded: form_helper
INFO - 2024-06-07 08:44:18 --> Helper loaded: my_helper
INFO - 2024-06-07 08:44:18 --> Database Driver Class Initialized
INFO - 2024-06-07 08:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:44:18 --> Controller Class Initialized
DEBUG - 2024-06-07 08:44:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-07 08:44:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:44:18 --> Final output sent to browser
DEBUG - 2024-06-07 08:44:18 --> Total execution time: 0.0298
INFO - 2024-06-07 08:44:24 --> Config Class Initialized
INFO - 2024-06-07 08:44:24 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:44:24 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:44:24 --> Utf8 Class Initialized
INFO - 2024-06-07 08:44:24 --> URI Class Initialized
INFO - 2024-06-07 08:44:24 --> Router Class Initialized
INFO - 2024-06-07 08:44:24 --> Output Class Initialized
INFO - 2024-06-07 08:44:24 --> Security Class Initialized
DEBUG - 2024-06-07 08:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:44:24 --> Input Class Initialized
INFO - 2024-06-07 08:44:24 --> Language Class Initialized
INFO - 2024-06-07 08:44:24 --> Language Class Initialized
INFO - 2024-06-07 08:44:24 --> Config Class Initialized
INFO - 2024-06-07 08:44:24 --> Loader Class Initialized
INFO - 2024-06-07 08:44:24 --> Helper loaded: url_helper
INFO - 2024-06-07 08:44:24 --> Helper loaded: file_helper
INFO - 2024-06-07 08:44:24 --> Helper loaded: form_helper
INFO - 2024-06-07 08:44:24 --> Helper loaded: my_helper
INFO - 2024-06-07 08:44:24 --> Database Driver Class Initialized
INFO - 2024-06-07 08:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:44:24 --> Controller Class Initialized
DEBUG - 2024-06-07 08:44:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-07 08:44:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:44:24 --> Final output sent to browser
DEBUG - 2024-06-07 08:44:24 --> Total execution time: 0.0368
INFO - 2024-06-07 08:44:38 --> Config Class Initialized
INFO - 2024-06-07 08:44:38 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:44:38 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:44:38 --> Utf8 Class Initialized
INFO - 2024-06-07 08:44:38 --> URI Class Initialized
INFO - 2024-06-07 08:44:38 --> Router Class Initialized
INFO - 2024-06-07 08:44:38 --> Output Class Initialized
INFO - 2024-06-07 08:44:38 --> Security Class Initialized
DEBUG - 2024-06-07 08:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:44:38 --> Input Class Initialized
INFO - 2024-06-07 08:44:38 --> Language Class Initialized
INFO - 2024-06-07 08:44:38 --> Language Class Initialized
INFO - 2024-06-07 08:44:38 --> Config Class Initialized
INFO - 2024-06-07 08:44:38 --> Loader Class Initialized
INFO - 2024-06-07 08:44:38 --> Helper loaded: url_helper
INFO - 2024-06-07 08:44:38 --> Helper loaded: file_helper
INFO - 2024-06-07 08:44:38 --> Helper loaded: form_helper
INFO - 2024-06-07 08:44:38 --> Helper loaded: my_helper
INFO - 2024-06-07 08:44:38 --> Database Driver Class Initialized
INFO - 2024-06-07 08:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:44:38 --> Controller Class Initialized
DEBUG - 2024-06-07 08:44:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-07 08:44:40 --> Final output sent to browser
DEBUG - 2024-06-07 08:44:40 --> Total execution time: 2.1734
INFO - 2024-06-07 08:46:17 --> Config Class Initialized
INFO - 2024-06-07 08:46:17 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:46:17 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:46:17 --> Utf8 Class Initialized
INFO - 2024-06-07 08:46:17 --> URI Class Initialized
INFO - 2024-06-07 08:46:17 --> Router Class Initialized
INFO - 2024-06-07 08:46:17 --> Output Class Initialized
INFO - 2024-06-07 08:46:17 --> Security Class Initialized
DEBUG - 2024-06-07 08:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:46:17 --> Input Class Initialized
INFO - 2024-06-07 08:46:17 --> Language Class Initialized
INFO - 2024-06-07 08:46:17 --> Language Class Initialized
INFO - 2024-06-07 08:46:17 --> Config Class Initialized
INFO - 2024-06-07 08:46:17 --> Loader Class Initialized
INFO - 2024-06-07 08:46:17 --> Helper loaded: url_helper
INFO - 2024-06-07 08:46:17 --> Helper loaded: file_helper
INFO - 2024-06-07 08:46:17 --> Helper loaded: form_helper
INFO - 2024-06-07 08:46:17 --> Helper loaded: my_helper
INFO - 2024-06-07 08:46:17 --> Database Driver Class Initialized
INFO - 2024-06-07 08:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:46:17 --> Controller Class Initialized
ERROR - 2024-06-07 08:46:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:46:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:46:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:46:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:46:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:46:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:46:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:46:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:46:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:46:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:46:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:46:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:46:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:46:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:46:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:46:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:46:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:46:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:46:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:46:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:46:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:46:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:46:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:46:17 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-06-07 08:46:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-07 08:46:21 --> Config Class Initialized
INFO - 2024-06-07 08:46:21 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:46:21 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:46:21 --> Utf8 Class Initialized
INFO - 2024-06-07 08:46:21 --> URI Class Initialized
INFO - 2024-06-07 08:46:21 --> Router Class Initialized
INFO - 2024-06-07 08:46:21 --> Output Class Initialized
INFO - 2024-06-07 08:46:21 --> Security Class Initialized
DEBUG - 2024-06-07 08:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:46:21 --> Input Class Initialized
INFO - 2024-06-07 08:46:21 --> Language Class Initialized
INFO - 2024-06-07 08:46:21 --> Language Class Initialized
INFO - 2024-06-07 08:46:21 --> Config Class Initialized
INFO - 2024-06-07 08:46:21 --> Loader Class Initialized
INFO - 2024-06-07 08:46:21 --> Helper loaded: url_helper
INFO - 2024-06-07 08:46:21 --> Helper loaded: file_helper
INFO - 2024-06-07 08:46:21 --> Helper loaded: form_helper
INFO - 2024-06-07 08:46:21 --> Helper loaded: my_helper
INFO - 2024-06-07 08:46:21 --> Database Driver Class Initialized
INFO - 2024-06-07 08:46:22 --> Final output sent to browser
DEBUG - 2024-06-07 08:46:22 --> Total execution time: 4.5642
INFO - 2024-06-07 08:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:46:22 --> Controller Class Initialized
DEBUG - 2024-06-07 08:46:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-07 08:46:24 --> Config Class Initialized
INFO - 2024-06-07 08:46:24 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:46:24 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:46:24 --> Utf8 Class Initialized
INFO - 2024-06-07 08:46:24 --> URI Class Initialized
INFO - 2024-06-07 08:46:24 --> Router Class Initialized
INFO - 2024-06-07 08:46:24 --> Output Class Initialized
INFO - 2024-06-07 08:46:24 --> Security Class Initialized
DEBUG - 2024-06-07 08:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:46:24 --> Input Class Initialized
INFO - 2024-06-07 08:46:24 --> Language Class Initialized
INFO - 2024-06-07 08:46:24 --> Language Class Initialized
INFO - 2024-06-07 08:46:24 --> Config Class Initialized
INFO - 2024-06-07 08:46:24 --> Loader Class Initialized
INFO - 2024-06-07 08:46:24 --> Helper loaded: url_helper
INFO - 2024-06-07 08:46:24 --> Helper loaded: file_helper
INFO - 2024-06-07 08:46:24 --> Helper loaded: form_helper
INFO - 2024-06-07 08:46:24 --> Helper loaded: my_helper
INFO - 2024-06-07 08:46:24 --> Database Driver Class Initialized
INFO - 2024-06-07 08:46:26 --> Final output sent to browser
DEBUG - 2024-06-07 08:46:26 --> Total execution time: 4.8744
INFO - 2024-06-07 08:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:46:26 --> Controller Class Initialized
DEBUG - 2024-06-07 08:46:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-07 08:46:30 --> Final output sent to browser
DEBUG - 2024-06-07 08:46:30 --> Total execution time: 6.0544
INFO - 2024-06-07 08:47:07 --> Config Class Initialized
INFO - 2024-06-07 08:47:07 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:47:07 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:47:07 --> Utf8 Class Initialized
INFO - 2024-06-07 08:47:07 --> URI Class Initialized
INFO - 2024-06-07 08:47:07 --> Router Class Initialized
INFO - 2024-06-07 08:47:07 --> Output Class Initialized
INFO - 2024-06-07 08:47:07 --> Security Class Initialized
DEBUG - 2024-06-07 08:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:47:07 --> Input Class Initialized
INFO - 2024-06-07 08:47:07 --> Language Class Initialized
INFO - 2024-06-07 08:47:07 --> Language Class Initialized
INFO - 2024-06-07 08:47:07 --> Config Class Initialized
INFO - 2024-06-07 08:47:07 --> Loader Class Initialized
INFO - 2024-06-07 08:47:07 --> Helper loaded: url_helper
INFO - 2024-06-07 08:47:07 --> Helper loaded: file_helper
INFO - 2024-06-07 08:47:07 --> Helper loaded: form_helper
INFO - 2024-06-07 08:47:07 --> Helper loaded: my_helper
INFO - 2024-06-07 08:47:07 --> Database Driver Class Initialized
INFO - 2024-06-07 08:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:47:07 --> Controller Class Initialized
DEBUG - 2024-06-07 08:47:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-07 08:47:09 --> Final output sent to browser
DEBUG - 2024-06-07 08:47:09 --> Total execution time: 2.2048
INFO - 2024-06-07 08:47:09 --> Config Class Initialized
INFO - 2024-06-07 08:47:09 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:47:09 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:47:09 --> Utf8 Class Initialized
INFO - 2024-06-07 08:47:09 --> URI Class Initialized
INFO - 2024-06-07 08:47:09 --> Router Class Initialized
INFO - 2024-06-07 08:47:09 --> Output Class Initialized
INFO - 2024-06-07 08:47:09 --> Security Class Initialized
DEBUG - 2024-06-07 08:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:47:09 --> Input Class Initialized
INFO - 2024-06-07 08:47:09 --> Language Class Initialized
INFO - 2024-06-07 08:47:09 --> Language Class Initialized
INFO - 2024-06-07 08:47:09 --> Config Class Initialized
INFO - 2024-06-07 08:47:09 --> Loader Class Initialized
INFO - 2024-06-07 08:47:09 --> Helper loaded: url_helper
INFO - 2024-06-07 08:47:09 --> Helper loaded: file_helper
INFO - 2024-06-07 08:47:09 --> Helper loaded: form_helper
INFO - 2024-06-07 08:47:09 --> Helper loaded: my_helper
INFO - 2024-06-07 08:47:09 --> Database Driver Class Initialized
INFO - 2024-06-07 08:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:47:09 --> Controller Class Initialized
ERROR - 2024-06-07 08:47:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:47:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:47:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:47:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:47:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:47:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:47:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:47:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:47:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:47:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:47:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:47:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:47:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:47:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:47:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:47:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:47:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:47:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:47:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:47:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:47:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:47:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:47:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:47:09 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-06-07 08:47:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-07 08:47:12 --> Config Class Initialized
INFO - 2024-06-07 08:47:12 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:47:12 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:47:12 --> Utf8 Class Initialized
INFO - 2024-06-07 08:47:12 --> URI Class Initialized
INFO - 2024-06-07 08:47:12 --> Router Class Initialized
INFO - 2024-06-07 08:47:12 --> Output Class Initialized
INFO - 2024-06-07 08:47:12 --> Security Class Initialized
DEBUG - 2024-06-07 08:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:47:12 --> Input Class Initialized
INFO - 2024-06-07 08:47:12 --> Language Class Initialized
INFO - 2024-06-07 08:47:12 --> Final output sent to browser
DEBUG - 2024-06-07 08:47:12 --> Total execution time: 2.9467
INFO - 2024-06-07 08:47:12 --> Language Class Initialized
INFO - 2024-06-07 08:47:12 --> Config Class Initialized
INFO - 2024-06-07 08:47:12 --> Loader Class Initialized
INFO - 2024-06-07 08:47:12 --> Helper loaded: url_helper
INFO - 2024-06-07 08:47:12 --> Helper loaded: file_helper
INFO - 2024-06-07 08:47:12 --> Helper loaded: form_helper
INFO - 2024-06-07 08:47:12 --> Helper loaded: my_helper
INFO - 2024-06-07 08:47:12 --> Database Driver Class Initialized
INFO - 2024-06-07 08:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:47:12 --> Controller Class Initialized
DEBUG - 2024-06-07 08:47:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-07 08:47:15 --> Config Class Initialized
INFO - 2024-06-07 08:47:15 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:47:15 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:47:15 --> Utf8 Class Initialized
INFO - 2024-06-07 08:47:15 --> URI Class Initialized
INFO - 2024-06-07 08:47:15 --> Router Class Initialized
INFO - 2024-06-07 08:47:15 --> Output Class Initialized
INFO - 2024-06-07 08:47:15 --> Security Class Initialized
DEBUG - 2024-06-07 08:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:47:15 --> Input Class Initialized
INFO - 2024-06-07 08:47:15 --> Language Class Initialized
INFO - 2024-06-07 08:47:15 --> Language Class Initialized
INFO - 2024-06-07 08:47:15 --> Config Class Initialized
INFO - 2024-06-07 08:47:15 --> Loader Class Initialized
INFO - 2024-06-07 08:47:15 --> Helper loaded: url_helper
INFO - 2024-06-07 08:47:15 --> Helper loaded: file_helper
INFO - 2024-06-07 08:47:15 --> Helper loaded: form_helper
INFO - 2024-06-07 08:47:15 --> Helper loaded: my_helper
INFO - 2024-06-07 08:47:15 --> Database Driver Class Initialized
INFO - 2024-06-07 08:47:17 --> Final output sent to browser
DEBUG - 2024-06-07 08:47:17 --> Total execution time: 4.9399
INFO - 2024-06-07 08:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:47:17 --> Controller Class Initialized
DEBUG - 2024-06-07 08:47:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-07 08:47:22 --> Final output sent to browser
DEBUG - 2024-06-07 08:47:22 --> Total execution time: 7.5400
INFO - 2024-06-07 08:48:02 --> Config Class Initialized
INFO - 2024-06-07 08:48:02 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:48:02 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:48:02 --> Utf8 Class Initialized
INFO - 2024-06-07 08:48:02 --> URI Class Initialized
INFO - 2024-06-07 08:48:02 --> Router Class Initialized
INFO - 2024-06-07 08:48:02 --> Output Class Initialized
INFO - 2024-06-07 08:48:02 --> Security Class Initialized
DEBUG - 2024-06-07 08:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:48:02 --> Input Class Initialized
INFO - 2024-06-07 08:48:02 --> Language Class Initialized
INFO - 2024-06-07 08:48:02 --> Language Class Initialized
INFO - 2024-06-07 08:48:02 --> Config Class Initialized
INFO - 2024-06-07 08:48:02 --> Loader Class Initialized
INFO - 2024-06-07 08:48:02 --> Helper loaded: url_helper
INFO - 2024-06-07 08:48:02 --> Helper loaded: file_helper
INFO - 2024-06-07 08:48:02 --> Helper loaded: form_helper
INFO - 2024-06-07 08:48:02 --> Helper loaded: my_helper
INFO - 2024-06-07 08:48:02 --> Database Driver Class Initialized
INFO - 2024-06-07 08:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:48:02 --> Controller Class Initialized
DEBUG - 2024-06-07 08:48:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-07 08:48:04 --> Final output sent to browser
DEBUG - 2024-06-07 08:48:04 --> Total execution time: 2.2352
INFO - 2024-06-07 08:48:05 --> Config Class Initialized
INFO - 2024-06-07 08:48:05 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:48:05 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:48:05 --> Utf8 Class Initialized
INFO - 2024-06-07 08:48:05 --> URI Class Initialized
INFO - 2024-06-07 08:48:05 --> Router Class Initialized
INFO - 2024-06-07 08:48:05 --> Output Class Initialized
INFO - 2024-06-07 08:48:05 --> Security Class Initialized
DEBUG - 2024-06-07 08:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:48:05 --> Input Class Initialized
INFO - 2024-06-07 08:48:05 --> Language Class Initialized
INFO - 2024-06-07 08:48:05 --> Language Class Initialized
INFO - 2024-06-07 08:48:05 --> Config Class Initialized
INFO - 2024-06-07 08:48:05 --> Loader Class Initialized
INFO - 2024-06-07 08:48:05 --> Helper loaded: url_helper
INFO - 2024-06-07 08:48:05 --> Helper loaded: file_helper
INFO - 2024-06-07 08:48:05 --> Helper loaded: form_helper
INFO - 2024-06-07 08:48:05 --> Helper loaded: my_helper
INFO - 2024-06-07 08:48:05 --> Database Driver Class Initialized
INFO - 2024-06-07 08:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:48:05 --> Controller Class Initialized
ERROR - 2024-06-07 08:48:05 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:48:05 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:48:05 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:48:05 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:48:05 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:48:05 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:48:05 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:48:05 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:48:05 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:48:05 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:48:05 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:48:05 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:48:05 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:48:05 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:48:05 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:48:05 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:48:05 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:48:05 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:48:05 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:48:05 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:48:05 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:48:05 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:48:05 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:48:05 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-06-07 08:48:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-07 08:48:07 --> Config Class Initialized
INFO - 2024-06-07 08:48:07 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:48:07 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:48:07 --> Utf8 Class Initialized
INFO - 2024-06-07 08:48:07 --> URI Class Initialized
INFO - 2024-06-07 08:48:07 --> Router Class Initialized
INFO - 2024-06-07 08:48:07 --> Output Class Initialized
INFO - 2024-06-07 08:48:07 --> Security Class Initialized
DEBUG - 2024-06-07 08:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:48:07 --> Input Class Initialized
INFO - 2024-06-07 08:48:07 --> Language Class Initialized
INFO - 2024-06-07 08:48:07 --> Language Class Initialized
INFO - 2024-06-07 08:48:07 --> Config Class Initialized
INFO - 2024-06-07 08:48:07 --> Loader Class Initialized
INFO - 2024-06-07 08:48:07 --> Helper loaded: url_helper
INFO - 2024-06-07 08:48:07 --> Helper loaded: file_helper
INFO - 2024-06-07 08:48:07 --> Helper loaded: form_helper
INFO - 2024-06-07 08:48:07 --> Helper loaded: my_helper
INFO - 2024-06-07 08:48:07 --> Database Driver Class Initialized
INFO - 2024-06-07 08:48:08 --> Final output sent to browser
DEBUG - 2024-06-07 08:48:08 --> Total execution time: 3.3247
INFO - 2024-06-07 08:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:48:08 --> Controller Class Initialized
DEBUG - 2024-06-07 08:48:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-07 08:48:11 --> Config Class Initialized
INFO - 2024-06-07 08:48:11 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:48:11 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:48:11 --> Utf8 Class Initialized
INFO - 2024-06-07 08:48:11 --> URI Class Initialized
INFO - 2024-06-07 08:48:11 --> Router Class Initialized
INFO - 2024-06-07 08:48:11 --> Output Class Initialized
INFO - 2024-06-07 08:48:11 --> Security Class Initialized
DEBUG - 2024-06-07 08:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:48:11 --> Input Class Initialized
INFO - 2024-06-07 08:48:11 --> Language Class Initialized
INFO - 2024-06-07 08:48:11 --> Language Class Initialized
INFO - 2024-06-07 08:48:11 --> Config Class Initialized
INFO - 2024-06-07 08:48:11 --> Loader Class Initialized
INFO - 2024-06-07 08:48:11 --> Helper loaded: url_helper
INFO - 2024-06-07 08:48:11 --> Helper loaded: file_helper
INFO - 2024-06-07 08:48:11 --> Helper loaded: form_helper
INFO - 2024-06-07 08:48:11 --> Helper loaded: my_helper
INFO - 2024-06-07 08:48:11 --> Database Driver Class Initialized
INFO - 2024-06-07 08:48:14 --> Final output sent to browser
DEBUG - 2024-06-07 08:48:14 --> Total execution time: 6.9516
INFO - 2024-06-07 08:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:48:14 --> Controller Class Initialized
DEBUG - 2024-06-07 08:48:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-07 08:48:17 --> Final output sent to browser
DEBUG - 2024-06-07 08:48:17 --> Total execution time: 6.5493
INFO - 2024-06-07 08:49:03 --> Config Class Initialized
INFO - 2024-06-07 08:49:03 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:49:03 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:49:03 --> Utf8 Class Initialized
INFO - 2024-06-07 08:49:03 --> URI Class Initialized
INFO - 2024-06-07 08:49:03 --> Router Class Initialized
INFO - 2024-06-07 08:49:03 --> Output Class Initialized
INFO - 2024-06-07 08:49:03 --> Security Class Initialized
DEBUG - 2024-06-07 08:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:49:03 --> Input Class Initialized
INFO - 2024-06-07 08:49:03 --> Language Class Initialized
INFO - 2024-06-07 08:49:03 --> Language Class Initialized
INFO - 2024-06-07 08:49:03 --> Config Class Initialized
INFO - 2024-06-07 08:49:03 --> Loader Class Initialized
INFO - 2024-06-07 08:49:03 --> Helper loaded: url_helper
INFO - 2024-06-07 08:49:03 --> Helper loaded: file_helper
INFO - 2024-06-07 08:49:03 --> Helper loaded: form_helper
INFO - 2024-06-07 08:49:03 --> Helper loaded: my_helper
INFO - 2024-06-07 08:49:03 --> Database Driver Class Initialized
INFO - 2024-06-07 08:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:49:03 --> Controller Class Initialized
DEBUG - 2024-06-07 08:49:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-07 08:49:05 --> Final output sent to browser
DEBUG - 2024-06-07 08:49:05 --> Total execution time: 1.9306
INFO - 2024-06-07 08:49:06 --> Config Class Initialized
INFO - 2024-06-07 08:49:06 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:49:06 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:49:06 --> Utf8 Class Initialized
INFO - 2024-06-07 08:49:06 --> URI Class Initialized
INFO - 2024-06-07 08:49:06 --> Router Class Initialized
INFO - 2024-06-07 08:49:06 --> Output Class Initialized
INFO - 2024-06-07 08:49:06 --> Security Class Initialized
DEBUG - 2024-06-07 08:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:49:06 --> Input Class Initialized
INFO - 2024-06-07 08:49:06 --> Language Class Initialized
INFO - 2024-06-07 08:49:06 --> Language Class Initialized
INFO - 2024-06-07 08:49:06 --> Config Class Initialized
INFO - 2024-06-07 08:49:06 --> Loader Class Initialized
INFO - 2024-06-07 08:49:06 --> Helper loaded: url_helper
INFO - 2024-06-07 08:49:06 --> Helper loaded: file_helper
INFO - 2024-06-07 08:49:06 --> Helper loaded: form_helper
INFO - 2024-06-07 08:49:06 --> Helper loaded: my_helper
INFO - 2024-06-07 08:49:06 --> Database Driver Class Initialized
INFO - 2024-06-07 08:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:49:06 --> Controller Class Initialized
ERROR - 2024-06-07 08:49:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:49:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:49:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:49:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:49:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:49:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:49:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:49:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:49:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:49:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:49:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:49:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:49:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:49:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:49:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:49:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:49:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:49:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:49:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:49:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:49:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:49:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:49:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:49:06 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-06-07 08:49:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-07 08:49:09 --> Config Class Initialized
INFO - 2024-06-07 08:49:09 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:49:09 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:49:09 --> Utf8 Class Initialized
INFO - 2024-06-07 08:49:09 --> URI Class Initialized
INFO - 2024-06-07 08:49:09 --> Router Class Initialized
INFO - 2024-06-07 08:49:09 --> Output Class Initialized
INFO - 2024-06-07 08:49:09 --> Security Class Initialized
DEBUG - 2024-06-07 08:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:49:09 --> Input Class Initialized
INFO - 2024-06-07 08:49:09 --> Language Class Initialized
INFO - 2024-06-07 08:49:09 --> Language Class Initialized
INFO - 2024-06-07 08:49:09 --> Config Class Initialized
INFO - 2024-06-07 08:49:09 --> Loader Class Initialized
INFO - 2024-06-07 08:49:09 --> Helper loaded: url_helper
INFO - 2024-06-07 08:49:09 --> Helper loaded: file_helper
INFO - 2024-06-07 08:49:09 --> Helper loaded: form_helper
INFO - 2024-06-07 08:49:09 --> Helper loaded: my_helper
INFO - 2024-06-07 08:49:09 --> Database Driver Class Initialized
INFO - 2024-06-07 08:49:11 --> Final output sent to browser
DEBUG - 2024-06-07 08:49:11 --> Total execution time: 4.4996
INFO - 2024-06-07 08:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:49:11 --> Controller Class Initialized
DEBUG - 2024-06-07 08:49:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-07 08:49:11 --> Config Class Initialized
INFO - 2024-06-07 08:49:11 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:49:11 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:49:11 --> Utf8 Class Initialized
INFO - 2024-06-07 08:49:11 --> URI Class Initialized
INFO - 2024-06-07 08:49:11 --> Router Class Initialized
INFO - 2024-06-07 08:49:11 --> Output Class Initialized
INFO - 2024-06-07 08:49:11 --> Security Class Initialized
DEBUG - 2024-06-07 08:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:49:11 --> Input Class Initialized
INFO - 2024-06-07 08:49:11 --> Language Class Initialized
INFO - 2024-06-07 08:49:11 --> Language Class Initialized
INFO - 2024-06-07 08:49:11 --> Config Class Initialized
INFO - 2024-06-07 08:49:11 --> Loader Class Initialized
INFO - 2024-06-07 08:49:11 --> Helper loaded: url_helper
INFO - 2024-06-07 08:49:11 --> Helper loaded: file_helper
INFO - 2024-06-07 08:49:11 --> Helper loaded: form_helper
INFO - 2024-06-07 08:49:11 --> Helper loaded: my_helper
INFO - 2024-06-07 08:49:11 --> Database Driver Class Initialized
INFO - 2024-06-07 08:49:15 --> Final output sent to browser
DEBUG - 2024-06-07 08:49:15 --> Total execution time: 6.7937
INFO - 2024-06-07 08:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:49:15 --> Controller Class Initialized
DEBUG - 2024-06-07 08:49:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-07 08:49:18 --> Final output sent to browser
DEBUG - 2024-06-07 08:49:18 --> Total execution time: 7.1941
INFO - 2024-06-07 08:50:03 --> Config Class Initialized
INFO - 2024-06-07 08:50:03 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:50:03 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:50:03 --> Utf8 Class Initialized
INFO - 2024-06-07 08:50:03 --> URI Class Initialized
INFO - 2024-06-07 08:50:03 --> Router Class Initialized
INFO - 2024-06-07 08:50:03 --> Output Class Initialized
INFO - 2024-06-07 08:50:03 --> Security Class Initialized
DEBUG - 2024-06-07 08:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:50:03 --> Input Class Initialized
INFO - 2024-06-07 08:50:03 --> Language Class Initialized
INFO - 2024-06-07 08:50:03 --> Language Class Initialized
INFO - 2024-06-07 08:50:03 --> Config Class Initialized
INFO - 2024-06-07 08:50:03 --> Loader Class Initialized
INFO - 2024-06-07 08:50:03 --> Helper loaded: url_helper
INFO - 2024-06-07 08:50:03 --> Helper loaded: file_helper
INFO - 2024-06-07 08:50:03 --> Helper loaded: form_helper
INFO - 2024-06-07 08:50:03 --> Helper loaded: my_helper
INFO - 2024-06-07 08:50:03 --> Database Driver Class Initialized
INFO - 2024-06-07 08:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:50:03 --> Controller Class Initialized
DEBUG - 2024-06-07 08:50:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-07 08:50:05 --> Final output sent to browser
DEBUG - 2024-06-07 08:50:05 --> Total execution time: 2.5250
INFO - 2024-06-07 08:50:06 --> Config Class Initialized
INFO - 2024-06-07 08:50:06 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:50:06 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:50:06 --> Utf8 Class Initialized
INFO - 2024-06-07 08:50:06 --> URI Class Initialized
INFO - 2024-06-07 08:50:06 --> Router Class Initialized
INFO - 2024-06-07 08:50:06 --> Output Class Initialized
INFO - 2024-06-07 08:50:06 --> Security Class Initialized
DEBUG - 2024-06-07 08:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:50:06 --> Input Class Initialized
INFO - 2024-06-07 08:50:06 --> Language Class Initialized
INFO - 2024-06-07 08:50:06 --> Language Class Initialized
INFO - 2024-06-07 08:50:06 --> Config Class Initialized
INFO - 2024-06-07 08:50:06 --> Loader Class Initialized
INFO - 2024-06-07 08:50:06 --> Helper loaded: url_helper
INFO - 2024-06-07 08:50:06 --> Helper loaded: file_helper
INFO - 2024-06-07 08:50:06 --> Helper loaded: form_helper
INFO - 2024-06-07 08:50:06 --> Helper loaded: my_helper
INFO - 2024-06-07 08:50:06 --> Database Driver Class Initialized
INFO - 2024-06-07 08:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:50:06 --> Controller Class Initialized
ERROR - 2024-06-07 08:50:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:50:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:50:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:50:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:50:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:50:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:50:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:50:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:50:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:50:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:50:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:50:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:50:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:50:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:50:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:50:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:50:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:50:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:50:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:50:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:50:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:50:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:50:06 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:50:06 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-06-07 08:50:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-07 08:50:09 --> Final output sent to browser
DEBUG - 2024-06-07 08:50:09 --> Total execution time: 3.1507
INFO - 2024-06-07 08:50:10 --> Config Class Initialized
INFO - 2024-06-07 08:50:10 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:50:10 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:50:10 --> Utf8 Class Initialized
INFO - 2024-06-07 08:50:10 --> URI Class Initialized
INFO - 2024-06-07 08:50:10 --> Router Class Initialized
INFO - 2024-06-07 08:50:10 --> Output Class Initialized
INFO - 2024-06-07 08:50:10 --> Security Class Initialized
DEBUG - 2024-06-07 08:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:50:10 --> Input Class Initialized
INFO - 2024-06-07 08:50:10 --> Language Class Initialized
INFO - 2024-06-07 08:50:10 --> Language Class Initialized
INFO - 2024-06-07 08:50:10 --> Config Class Initialized
INFO - 2024-06-07 08:50:10 --> Loader Class Initialized
INFO - 2024-06-07 08:50:10 --> Helper loaded: url_helper
INFO - 2024-06-07 08:50:10 --> Helper loaded: file_helper
INFO - 2024-06-07 08:50:10 --> Helper loaded: form_helper
INFO - 2024-06-07 08:50:10 --> Helper loaded: my_helper
INFO - 2024-06-07 08:50:10 --> Database Driver Class Initialized
INFO - 2024-06-07 08:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:50:10 --> Controller Class Initialized
DEBUG - 2024-06-07 08:50:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-07 08:50:12 --> Config Class Initialized
INFO - 2024-06-07 08:50:12 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:50:12 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:50:12 --> Utf8 Class Initialized
INFO - 2024-06-07 08:50:12 --> URI Class Initialized
INFO - 2024-06-07 08:50:12 --> Router Class Initialized
INFO - 2024-06-07 08:50:12 --> Output Class Initialized
INFO - 2024-06-07 08:50:12 --> Security Class Initialized
DEBUG - 2024-06-07 08:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:50:12 --> Input Class Initialized
INFO - 2024-06-07 08:50:12 --> Language Class Initialized
INFO - 2024-06-07 08:50:12 --> Language Class Initialized
INFO - 2024-06-07 08:50:12 --> Config Class Initialized
INFO - 2024-06-07 08:50:12 --> Loader Class Initialized
INFO - 2024-06-07 08:50:12 --> Helper loaded: url_helper
INFO - 2024-06-07 08:50:12 --> Helper loaded: file_helper
INFO - 2024-06-07 08:50:12 --> Helper loaded: form_helper
INFO - 2024-06-07 08:50:12 --> Helper loaded: my_helper
INFO - 2024-06-07 08:50:12 --> Database Driver Class Initialized
INFO - 2024-06-07 08:50:16 --> Final output sent to browser
DEBUG - 2024-06-07 08:50:16 --> Total execution time: 6.7023
INFO - 2024-06-07 08:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:50:16 --> Controller Class Initialized
DEBUG - 2024-06-07 08:50:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-07 08:50:20 --> Final output sent to browser
DEBUG - 2024-06-07 08:50:20 --> Total execution time: 7.2519
INFO - 2024-06-07 08:51:05 --> Config Class Initialized
INFO - 2024-06-07 08:51:05 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:51:05 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:51:05 --> Utf8 Class Initialized
INFO - 2024-06-07 08:51:05 --> URI Class Initialized
INFO - 2024-06-07 08:51:05 --> Router Class Initialized
INFO - 2024-06-07 08:51:05 --> Output Class Initialized
INFO - 2024-06-07 08:51:05 --> Security Class Initialized
DEBUG - 2024-06-07 08:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:51:05 --> Input Class Initialized
INFO - 2024-06-07 08:51:05 --> Language Class Initialized
INFO - 2024-06-07 08:51:06 --> Language Class Initialized
INFO - 2024-06-07 08:51:06 --> Config Class Initialized
INFO - 2024-06-07 08:51:06 --> Loader Class Initialized
INFO - 2024-06-07 08:51:06 --> Helper loaded: url_helper
INFO - 2024-06-07 08:51:06 --> Helper loaded: file_helper
INFO - 2024-06-07 08:51:06 --> Helper loaded: form_helper
INFO - 2024-06-07 08:51:06 --> Helper loaded: my_helper
INFO - 2024-06-07 08:51:06 --> Database Driver Class Initialized
INFO - 2024-06-07 08:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:51:06 --> Controller Class Initialized
DEBUG - 2024-06-07 08:51:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-06-07 08:51:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:51:06 --> Final output sent to browser
DEBUG - 2024-06-07 08:51:06 --> Total execution time: 0.0504
INFO - 2024-06-07 08:52:43 --> Config Class Initialized
INFO - 2024-06-07 08:52:43 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:52:43 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:52:43 --> Utf8 Class Initialized
INFO - 2024-06-07 08:52:43 --> URI Class Initialized
INFO - 2024-06-07 08:52:43 --> Router Class Initialized
INFO - 2024-06-07 08:52:43 --> Output Class Initialized
INFO - 2024-06-07 08:52:43 --> Security Class Initialized
DEBUG - 2024-06-07 08:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:52:43 --> Input Class Initialized
INFO - 2024-06-07 08:52:43 --> Language Class Initialized
INFO - 2024-06-07 08:52:43 --> Language Class Initialized
INFO - 2024-06-07 08:52:43 --> Config Class Initialized
INFO - 2024-06-07 08:52:43 --> Loader Class Initialized
INFO - 2024-06-07 08:52:43 --> Helper loaded: url_helper
INFO - 2024-06-07 08:52:43 --> Helper loaded: file_helper
INFO - 2024-06-07 08:52:43 --> Helper loaded: form_helper
INFO - 2024-06-07 08:52:43 --> Helper loaded: my_helper
INFO - 2024-06-07 08:52:43 --> Database Driver Class Initialized
INFO - 2024-06-07 08:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:52:43 --> Controller Class Initialized
DEBUG - 2024-06-07 08:52:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-07 08:52:45 --> Final output sent to browser
DEBUG - 2024-06-07 08:52:45 --> Total execution time: 1.9838
INFO - 2024-06-07 08:52:46 --> Config Class Initialized
INFO - 2024-06-07 08:52:46 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:52:46 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:52:46 --> Utf8 Class Initialized
INFO - 2024-06-07 08:52:46 --> URI Class Initialized
INFO - 2024-06-07 08:52:46 --> Router Class Initialized
INFO - 2024-06-07 08:52:46 --> Output Class Initialized
INFO - 2024-06-07 08:52:46 --> Security Class Initialized
DEBUG - 2024-06-07 08:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:52:46 --> Input Class Initialized
INFO - 2024-06-07 08:52:46 --> Language Class Initialized
INFO - 2024-06-07 08:52:46 --> Language Class Initialized
INFO - 2024-06-07 08:52:46 --> Config Class Initialized
INFO - 2024-06-07 08:52:46 --> Loader Class Initialized
INFO - 2024-06-07 08:52:46 --> Helper loaded: url_helper
INFO - 2024-06-07 08:52:46 --> Helper loaded: file_helper
INFO - 2024-06-07 08:52:46 --> Helper loaded: form_helper
INFO - 2024-06-07 08:52:46 --> Helper loaded: my_helper
INFO - 2024-06-07 08:52:46 --> Database Driver Class Initialized
INFO - 2024-06-07 08:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:52:46 --> Controller Class Initialized
ERROR - 2024-06-07 08:52:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:52:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:52:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:52:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:52:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:52:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:52:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:52:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:52:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:52:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:52:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:52:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:52:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:52:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:52:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:52:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:52:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:52:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:52:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:52:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:52:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:52:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:52:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:52:46 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-06-07 08:52:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-07 08:52:48 --> Final output sent to browser
DEBUG - 2024-06-07 08:52:48 --> Total execution time: 2.8369
INFO - 2024-06-07 08:54:00 --> Config Class Initialized
INFO - 2024-06-07 08:54:00 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:54:00 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:54:00 --> Utf8 Class Initialized
INFO - 2024-06-07 08:54:00 --> URI Class Initialized
INFO - 2024-06-07 08:54:00 --> Router Class Initialized
INFO - 2024-06-07 08:54:00 --> Output Class Initialized
INFO - 2024-06-07 08:54:00 --> Security Class Initialized
DEBUG - 2024-06-07 08:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:54:00 --> Input Class Initialized
INFO - 2024-06-07 08:54:00 --> Language Class Initialized
INFO - 2024-06-07 08:54:00 --> Language Class Initialized
INFO - 2024-06-07 08:54:00 --> Config Class Initialized
INFO - 2024-06-07 08:54:00 --> Loader Class Initialized
INFO - 2024-06-07 08:54:00 --> Helper loaded: url_helper
INFO - 2024-06-07 08:54:00 --> Helper loaded: file_helper
INFO - 2024-06-07 08:54:00 --> Helper loaded: form_helper
INFO - 2024-06-07 08:54:00 --> Helper loaded: my_helper
INFO - 2024-06-07 08:54:00 --> Database Driver Class Initialized
INFO - 2024-06-07 08:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:54:00 --> Controller Class Initialized
INFO - 2024-06-07 08:54:00 --> Helper loaded: cookie_helper
INFO - 2024-06-07 08:54:00 --> Config Class Initialized
INFO - 2024-06-07 08:54:00 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:54:00 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:54:00 --> Utf8 Class Initialized
INFO - 2024-06-07 08:54:00 --> URI Class Initialized
INFO - 2024-06-07 08:54:00 --> Router Class Initialized
INFO - 2024-06-07 08:54:00 --> Output Class Initialized
INFO - 2024-06-07 08:54:00 --> Security Class Initialized
DEBUG - 2024-06-07 08:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:54:00 --> Input Class Initialized
INFO - 2024-06-07 08:54:00 --> Language Class Initialized
INFO - 2024-06-07 08:54:00 --> Language Class Initialized
INFO - 2024-06-07 08:54:00 --> Config Class Initialized
INFO - 2024-06-07 08:54:00 --> Loader Class Initialized
INFO - 2024-06-07 08:54:00 --> Helper loaded: url_helper
INFO - 2024-06-07 08:54:00 --> Helper loaded: file_helper
INFO - 2024-06-07 08:54:00 --> Helper loaded: form_helper
INFO - 2024-06-07 08:54:00 --> Helper loaded: my_helper
INFO - 2024-06-07 08:54:00 --> Database Driver Class Initialized
INFO - 2024-06-07 08:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:54:00 --> Controller Class Initialized
INFO - 2024-06-07 08:54:01 --> Config Class Initialized
INFO - 2024-06-07 08:54:01 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:54:01 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:54:01 --> Utf8 Class Initialized
INFO - 2024-06-07 08:54:01 --> URI Class Initialized
INFO - 2024-06-07 08:54:01 --> Router Class Initialized
INFO - 2024-06-07 08:54:01 --> Output Class Initialized
INFO - 2024-06-07 08:54:01 --> Security Class Initialized
DEBUG - 2024-06-07 08:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:54:01 --> Input Class Initialized
INFO - 2024-06-07 08:54:01 --> Language Class Initialized
INFO - 2024-06-07 08:54:01 --> Language Class Initialized
INFO - 2024-06-07 08:54:01 --> Config Class Initialized
INFO - 2024-06-07 08:54:01 --> Loader Class Initialized
INFO - 2024-06-07 08:54:01 --> Helper loaded: url_helper
INFO - 2024-06-07 08:54:01 --> Helper loaded: file_helper
INFO - 2024-06-07 08:54:01 --> Helper loaded: form_helper
INFO - 2024-06-07 08:54:01 --> Helper loaded: my_helper
INFO - 2024-06-07 08:54:01 --> Database Driver Class Initialized
INFO - 2024-06-07 08:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:54:01 --> Controller Class Initialized
DEBUG - 2024-06-07 08:54:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-07 08:54:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:54:01 --> Final output sent to browser
DEBUG - 2024-06-07 08:54:01 --> Total execution time: 0.0340
INFO - 2024-06-07 08:54:06 --> Config Class Initialized
INFO - 2024-06-07 08:54:06 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:54:06 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:54:06 --> Utf8 Class Initialized
INFO - 2024-06-07 08:54:06 --> URI Class Initialized
INFO - 2024-06-07 08:54:06 --> Router Class Initialized
INFO - 2024-06-07 08:54:06 --> Output Class Initialized
INFO - 2024-06-07 08:54:06 --> Security Class Initialized
DEBUG - 2024-06-07 08:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:54:06 --> Input Class Initialized
INFO - 2024-06-07 08:54:06 --> Language Class Initialized
INFO - 2024-06-07 08:54:06 --> Language Class Initialized
INFO - 2024-06-07 08:54:06 --> Config Class Initialized
INFO - 2024-06-07 08:54:06 --> Loader Class Initialized
INFO - 2024-06-07 08:54:06 --> Helper loaded: url_helper
INFO - 2024-06-07 08:54:06 --> Helper loaded: file_helper
INFO - 2024-06-07 08:54:06 --> Helper loaded: form_helper
INFO - 2024-06-07 08:54:06 --> Helper loaded: my_helper
INFO - 2024-06-07 08:54:06 --> Database Driver Class Initialized
INFO - 2024-06-07 08:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:54:06 --> Controller Class Initialized
INFO - 2024-06-07 08:54:06 --> Helper loaded: cookie_helper
INFO - 2024-06-07 08:54:06 --> Final output sent to browser
DEBUG - 2024-06-07 08:54:06 --> Total execution time: 0.0282
INFO - 2024-06-07 08:54:06 --> Config Class Initialized
INFO - 2024-06-07 08:54:06 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:54:06 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:54:06 --> Utf8 Class Initialized
INFO - 2024-06-07 08:54:06 --> URI Class Initialized
INFO - 2024-06-07 08:54:06 --> Router Class Initialized
INFO - 2024-06-07 08:54:06 --> Output Class Initialized
INFO - 2024-06-07 08:54:06 --> Security Class Initialized
DEBUG - 2024-06-07 08:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:54:06 --> Input Class Initialized
INFO - 2024-06-07 08:54:06 --> Language Class Initialized
INFO - 2024-06-07 08:54:06 --> Language Class Initialized
INFO - 2024-06-07 08:54:06 --> Config Class Initialized
INFO - 2024-06-07 08:54:06 --> Loader Class Initialized
INFO - 2024-06-07 08:54:06 --> Helper loaded: url_helper
INFO - 2024-06-07 08:54:06 --> Helper loaded: file_helper
INFO - 2024-06-07 08:54:06 --> Helper loaded: form_helper
INFO - 2024-06-07 08:54:06 --> Helper loaded: my_helper
INFO - 2024-06-07 08:54:06 --> Database Driver Class Initialized
INFO - 2024-06-07 08:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:54:06 --> Controller Class Initialized
DEBUG - 2024-06-07 08:54:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-06-07 08:54:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:54:06 --> Final output sent to browser
DEBUG - 2024-06-07 08:54:06 --> Total execution time: 0.0383
INFO - 2024-06-07 08:54:09 --> Config Class Initialized
INFO - 2024-06-07 08:54:09 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:54:09 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:54:09 --> Utf8 Class Initialized
INFO - 2024-06-07 08:54:09 --> URI Class Initialized
INFO - 2024-06-07 08:54:09 --> Router Class Initialized
INFO - 2024-06-07 08:54:09 --> Output Class Initialized
INFO - 2024-06-07 08:54:09 --> Security Class Initialized
DEBUG - 2024-06-07 08:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:54:09 --> Input Class Initialized
INFO - 2024-06-07 08:54:09 --> Language Class Initialized
INFO - 2024-06-07 08:54:09 --> Language Class Initialized
INFO - 2024-06-07 08:54:09 --> Config Class Initialized
INFO - 2024-06-07 08:54:09 --> Loader Class Initialized
INFO - 2024-06-07 08:54:09 --> Helper loaded: url_helper
INFO - 2024-06-07 08:54:09 --> Helper loaded: file_helper
INFO - 2024-06-07 08:54:09 --> Helper loaded: form_helper
INFO - 2024-06-07 08:54:09 --> Helper loaded: my_helper
INFO - 2024-06-07 08:54:09 --> Database Driver Class Initialized
INFO - 2024-06-07 08:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:54:09 --> Controller Class Initialized
DEBUG - 2024-06-07 08:54:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_projek/views/list.php
DEBUG - 2024-06-07 08:54:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:54:09 --> Final output sent to browser
DEBUG - 2024-06-07 08:54:09 --> Total execution time: 0.0283
INFO - 2024-06-07 08:54:10 --> Config Class Initialized
INFO - 2024-06-07 08:54:10 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:54:10 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:54:10 --> Utf8 Class Initialized
INFO - 2024-06-07 08:54:10 --> URI Class Initialized
INFO - 2024-06-07 08:54:10 --> Router Class Initialized
INFO - 2024-06-07 08:54:10 --> Output Class Initialized
INFO - 2024-06-07 08:54:10 --> Security Class Initialized
DEBUG - 2024-06-07 08:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:54:10 --> Input Class Initialized
INFO - 2024-06-07 08:54:10 --> Language Class Initialized
ERROR - 2024-06-07 08:54:10 --> 404 Page Not Found: /index
INFO - 2024-06-07 08:54:10 --> Config Class Initialized
INFO - 2024-06-07 08:54:10 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:54:10 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:54:10 --> Utf8 Class Initialized
INFO - 2024-06-07 08:54:10 --> URI Class Initialized
INFO - 2024-06-07 08:54:10 --> Router Class Initialized
INFO - 2024-06-07 08:54:10 --> Output Class Initialized
INFO - 2024-06-07 08:54:10 --> Security Class Initialized
DEBUG - 2024-06-07 08:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:54:10 --> Input Class Initialized
INFO - 2024-06-07 08:54:10 --> Language Class Initialized
INFO - 2024-06-07 08:54:10 --> Language Class Initialized
INFO - 2024-06-07 08:54:10 --> Config Class Initialized
INFO - 2024-06-07 08:54:10 --> Loader Class Initialized
INFO - 2024-06-07 08:54:10 --> Helper loaded: url_helper
INFO - 2024-06-07 08:54:10 --> Helper loaded: file_helper
INFO - 2024-06-07 08:54:10 --> Helper loaded: form_helper
INFO - 2024-06-07 08:54:10 --> Helper loaded: my_helper
INFO - 2024-06-07 08:54:10 --> Database Driver Class Initialized
INFO - 2024-06-07 08:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:54:10 --> Controller Class Initialized
INFO - 2024-06-07 08:54:12 --> Config Class Initialized
INFO - 2024-06-07 08:54:12 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:54:12 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:54:12 --> Utf8 Class Initialized
INFO - 2024-06-07 08:54:12 --> URI Class Initialized
INFO - 2024-06-07 08:54:12 --> Router Class Initialized
INFO - 2024-06-07 08:54:12 --> Output Class Initialized
INFO - 2024-06-07 08:54:12 --> Security Class Initialized
DEBUG - 2024-06-07 08:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:54:12 --> Input Class Initialized
INFO - 2024-06-07 08:54:12 --> Language Class Initialized
INFO - 2024-06-07 08:54:12 --> Language Class Initialized
INFO - 2024-06-07 08:54:12 --> Config Class Initialized
INFO - 2024-06-07 08:54:12 --> Loader Class Initialized
INFO - 2024-06-07 08:54:12 --> Helper loaded: url_helper
INFO - 2024-06-07 08:54:12 --> Helper loaded: file_helper
INFO - 2024-06-07 08:54:12 --> Helper loaded: form_helper
INFO - 2024-06-07 08:54:12 --> Helper loaded: my_helper
INFO - 2024-06-07 08:54:12 --> Database Driver Class Initialized
INFO - 2024-06-07 08:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:54:12 --> Controller Class Initialized
INFO - 2024-06-07 08:54:12 --> Final output sent to browser
DEBUG - 2024-06-07 08:54:12 --> Total execution time: 0.0794
INFO - 2024-06-07 08:55:42 --> Config Class Initialized
INFO - 2024-06-07 08:55:42 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:55:42 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:55:42 --> Utf8 Class Initialized
INFO - 2024-06-07 08:55:42 --> URI Class Initialized
INFO - 2024-06-07 08:55:42 --> Router Class Initialized
INFO - 2024-06-07 08:55:42 --> Output Class Initialized
INFO - 2024-06-07 08:55:42 --> Security Class Initialized
DEBUG - 2024-06-07 08:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:55:42 --> Input Class Initialized
INFO - 2024-06-07 08:55:42 --> Language Class Initialized
INFO - 2024-06-07 08:55:42 --> Language Class Initialized
INFO - 2024-06-07 08:55:42 --> Config Class Initialized
INFO - 2024-06-07 08:55:42 --> Loader Class Initialized
INFO - 2024-06-07 08:55:42 --> Helper loaded: url_helper
INFO - 2024-06-07 08:55:42 --> Helper loaded: file_helper
INFO - 2024-06-07 08:55:42 --> Helper loaded: form_helper
INFO - 2024-06-07 08:55:42 --> Helper loaded: my_helper
INFO - 2024-06-07 08:55:42 --> Database Driver Class Initialized
INFO - 2024-06-07 08:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:55:42 --> Controller Class Initialized
DEBUG - 2024-06-07 08:55:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelompok/views/list.php
DEBUG - 2024-06-07 08:55:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:55:42 --> Final output sent to browser
DEBUG - 2024-06-07 08:55:42 --> Total execution time: 0.2254
INFO - 2024-06-07 08:55:42 --> Config Class Initialized
INFO - 2024-06-07 08:55:42 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:55:42 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:55:42 --> Utf8 Class Initialized
INFO - 2024-06-07 08:55:42 --> URI Class Initialized
INFO - 2024-06-07 08:55:42 --> Router Class Initialized
INFO - 2024-06-07 08:55:42 --> Output Class Initialized
INFO - 2024-06-07 08:55:42 --> Security Class Initialized
DEBUG - 2024-06-07 08:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:55:42 --> Input Class Initialized
INFO - 2024-06-07 08:55:42 --> Language Class Initialized
ERROR - 2024-06-07 08:55:42 --> 404 Page Not Found: /index
INFO - 2024-06-07 08:55:42 --> Config Class Initialized
INFO - 2024-06-07 08:55:42 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:55:42 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:55:42 --> Utf8 Class Initialized
INFO - 2024-06-07 08:55:42 --> URI Class Initialized
INFO - 2024-06-07 08:55:42 --> Router Class Initialized
INFO - 2024-06-07 08:55:42 --> Output Class Initialized
INFO - 2024-06-07 08:55:42 --> Security Class Initialized
DEBUG - 2024-06-07 08:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:55:42 --> Input Class Initialized
INFO - 2024-06-07 08:55:42 --> Language Class Initialized
INFO - 2024-06-07 08:55:42 --> Language Class Initialized
INFO - 2024-06-07 08:55:42 --> Config Class Initialized
INFO - 2024-06-07 08:55:42 --> Loader Class Initialized
INFO - 2024-06-07 08:55:42 --> Helper loaded: url_helper
INFO - 2024-06-07 08:55:42 --> Helper loaded: file_helper
INFO - 2024-06-07 08:55:42 --> Helper loaded: form_helper
INFO - 2024-06-07 08:55:42 --> Helper loaded: my_helper
INFO - 2024-06-07 08:55:42 --> Database Driver Class Initialized
INFO - 2024-06-07 08:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:55:42 --> Controller Class Initialized
INFO - 2024-06-07 08:55:47 --> Config Class Initialized
INFO - 2024-06-07 08:55:47 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:55:47 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:55:47 --> Utf8 Class Initialized
INFO - 2024-06-07 08:55:47 --> URI Class Initialized
INFO - 2024-06-07 08:55:47 --> Router Class Initialized
INFO - 2024-06-07 08:55:47 --> Output Class Initialized
INFO - 2024-06-07 08:55:47 --> Security Class Initialized
DEBUG - 2024-06-07 08:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:55:47 --> Input Class Initialized
INFO - 2024-06-07 08:55:47 --> Language Class Initialized
INFO - 2024-06-07 08:55:48 --> Language Class Initialized
INFO - 2024-06-07 08:55:48 --> Config Class Initialized
INFO - 2024-06-07 08:55:48 --> Loader Class Initialized
INFO - 2024-06-07 08:55:48 --> Helper loaded: url_helper
INFO - 2024-06-07 08:55:48 --> Helper loaded: file_helper
INFO - 2024-06-07 08:55:48 --> Helper loaded: form_helper
INFO - 2024-06-07 08:55:48 --> Helper loaded: my_helper
INFO - 2024-06-07 08:55:48 --> Database Driver Class Initialized
INFO - 2024-06-07 08:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:55:48 --> Controller Class Initialized
DEBUG - 2024-06-07 08:55:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_projek/views/list.php
DEBUG - 2024-06-07 08:55:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:55:48 --> Final output sent to browser
DEBUG - 2024-06-07 08:55:48 --> Total execution time: 0.0285
INFO - 2024-06-07 08:55:48 --> Config Class Initialized
INFO - 2024-06-07 08:55:48 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:55:48 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:55:48 --> Utf8 Class Initialized
INFO - 2024-06-07 08:55:48 --> URI Class Initialized
INFO - 2024-06-07 08:55:48 --> Router Class Initialized
INFO - 2024-06-07 08:55:48 --> Output Class Initialized
INFO - 2024-06-07 08:55:48 --> Security Class Initialized
DEBUG - 2024-06-07 08:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:55:48 --> Input Class Initialized
INFO - 2024-06-07 08:55:48 --> Language Class Initialized
ERROR - 2024-06-07 08:55:48 --> 404 Page Not Found: /index
INFO - 2024-06-07 08:55:48 --> Config Class Initialized
INFO - 2024-06-07 08:55:48 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:55:48 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:55:48 --> Utf8 Class Initialized
INFO - 2024-06-07 08:55:48 --> URI Class Initialized
INFO - 2024-06-07 08:55:48 --> Router Class Initialized
INFO - 2024-06-07 08:55:48 --> Output Class Initialized
INFO - 2024-06-07 08:55:48 --> Security Class Initialized
DEBUG - 2024-06-07 08:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:55:48 --> Input Class Initialized
INFO - 2024-06-07 08:55:48 --> Language Class Initialized
INFO - 2024-06-07 08:55:48 --> Language Class Initialized
INFO - 2024-06-07 08:55:48 --> Config Class Initialized
INFO - 2024-06-07 08:55:48 --> Loader Class Initialized
INFO - 2024-06-07 08:55:48 --> Helper loaded: url_helper
INFO - 2024-06-07 08:55:48 --> Helper loaded: file_helper
INFO - 2024-06-07 08:55:48 --> Helper loaded: form_helper
INFO - 2024-06-07 08:55:48 --> Helper loaded: my_helper
INFO - 2024-06-07 08:55:48 --> Database Driver Class Initialized
INFO - 2024-06-07 08:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:55:48 --> Controller Class Initialized
INFO - 2024-06-07 08:55:49 --> Config Class Initialized
INFO - 2024-06-07 08:55:49 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:55:49 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:55:49 --> Utf8 Class Initialized
INFO - 2024-06-07 08:55:49 --> URI Class Initialized
INFO - 2024-06-07 08:55:49 --> Router Class Initialized
INFO - 2024-06-07 08:55:49 --> Output Class Initialized
INFO - 2024-06-07 08:55:49 --> Security Class Initialized
DEBUG - 2024-06-07 08:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:55:49 --> Input Class Initialized
INFO - 2024-06-07 08:55:49 --> Language Class Initialized
INFO - 2024-06-07 08:55:49 --> Language Class Initialized
INFO - 2024-06-07 08:55:49 --> Config Class Initialized
INFO - 2024-06-07 08:55:49 --> Loader Class Initialized
INFO - 2024-06-07 08:55:49 --> Helper loaded: url_helper
INFO - 2024-06-07 08:55:49 --> Helper loaded: file_helper
INFO - 2024-06-07 08:55:49 --> Helper loaded: form_helper
INFO - 2024-06-07 08:55:49 --> Helper loaded: my_helper
INFO - 2024-06-07 08:55:49 --> Database Driver Class Initialized
INFO - 2024-06-07 08:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:55:49 --> Controller Class Initialized
INFO - 2024-06-07 08:55:49 --> Final output sent to browser
DEBUG - 2024-06-07 08:55:49 --> Total execution time: 0.0299
INFO - 2024-06-07 08:58:13 --> Config Class Initialized
INFO - 2024-06-07 08:58:13 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:58:13 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:58:13 --> Utf8 Class Initialized
INFO - 2024-06-07 08:58:13 --> URI Class Initialized
INFO - 2024-06-07 08:58:13 --> Router Class Initialized
INFO - 2024-06-07 08:58:13 --> Output Class Initialized
INFO - 2024-06-07 08:58:13 --> Security Class Initialized
DEBUG - 2024-06-07 08:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:58:13 --> Input Class Initialized
INFO - 2024-06-07 08:58:13 --> Language Class Initialized
INFO - 2024-06-07 08:58:13 --> Language Class Initialized
INFO - 2024-06-07 08:58:13 --> Config Class Initialized
INFO - 2024-06-07 08:58:13 --> Loader Class Initialized
INFO - 2024-06-07 08:58:13 --> Helper loaded: url_helper
INFO - 2024-06-07 08:58:13 --> Helper loaded: file_helper
INFO - 2024-06-07 08:58:13 --> Helper loaded: form_helper
INFO - 2024-06-07 08:58:13 --> Helper loaded: my_helper
INFO - 2024-06-07 08:58:13 --> Database Driver Class Initialized
INFO - 2024-06-07 08:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:58:13 --> Controller Class Initialized
INFO - 2024-06-07 08:58:13 --> Final output sent to browser
DEBUG - 2024-06-07 08:58:13 --> Total execution time: 0.0438
INFO - 2024-06-07 08:58:13 --> Config Class Initialized
INFO - 2024-06-07 08:58:13 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:58:13 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:58:13 --> Utf8 Class Initialized
INFO - 2024-06-07 08:58:13 --> URI Class Initialized
INFO - 2024-06-07 08:58:13 --> Router Class Initialized
INFO - 2024-06-07 08:58:13 --> Output Class Initialized
INFO - 2024-06-07 08:58:13 --> Security Class Initialized
DEBUG - 2024-06-07 08:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:58:13 --> Input Class Initialized
INFO - 2024-06-07 08:58:13 --> Language Class Initialized
ERROR - 2024-06-07 08:58:13 --> 404 Page Not Found: /index
INFO - 2024-06-07 08:58:13 --> Config Class Initialized
INFO - 2024-06-07 08:58:13 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:58:13 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:58:13 --> Utf8 Class Initialized
INFO - 2024-06-07 08:58:13 --> URI Class Initialized
INFO - 2024-06-07 08:58:13 --> Router Class Initialized
INFO - 2024-06-07 08:58:13 --> Output Class Initialized
INFO - 2024-06-07 08:58:13 --> Security Class Initialized
DEBUG - 2024-06-07 08:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:58:13 --> Input Class Initialized
INFO - 2024-06-07 08:58:13 --> Language Class Initialized
INFO - 2024-06-07 08:58:13 --> Language Class Initialized
INFO - 2024-06-07 08:58:13 --> Config Class Initialized
INFO - 2024-06-07 08:58:13 --> Loader Class Initialized
INFO - 2024-06-07 08:58:13 --> Helper loaded: url_helper
INFO - 2024-06-07 08:58:13 --> Helper loaded: file_helper
INFO - 2024-06-07 08:58:13 --> Helper loaded: form_helper
INFO - 2024-06-07 08:58:13 --> Helper loaded: my_helper
INFO - 2024-06-07 08:58:13 --> Database Driver Class Initialized
INFO - 2024-06-07 08:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:58:13 --> Controller Class Initialized
INFO - 2024-06-07 08:58:16 --> Config Class Initialized
INFO - 2024-06-07 08:58:16 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:58:16 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:58:16 --> Utf8 Class Initialized
INFO - 2024-06-07 08:58:16 --> URI Class Initialized
INFO - 2024-06-07 08:58:16 --> Router Class Initialized
INFO - 2024-06-07 08:58:16 --> Output Class Initialized
INFO - 2024-06-07 08:58:16 --> Security Class Initialized
DEBUG - 2024-06-07 08:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:58:16 --> Input Class Initialized
INFO - 2024-06-07 08:58:16 --> Language Class Initialized
INFO - 2024-06-07 08:58:16 --> Language Class Initialized
INFO - 2024-06-07 08:58:16 --> Config Class Initialized
INFO - 2024-06-07 08:58:16 --> Loader Class Initialized
INFO - 2024-06-07 08:58:16 --> Helper loaded: url_helper
INFO - 2024-06-07 08:58:16 --> Helper loaded: file_helper
INFO - 2024-06-07 08:58:16 --> Helper loaded: form_helper
INFO - 2024-06-07 08:58:16 --> Helper loaded: my_helper
INFO - 2024-06-07 08:58:16 --> Database Driver Class Initialized
INFO - 2024-06-07 08:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:58:16 --> Controller Class Initialized
INFO - 2024-06-07 08:58:16 --> Final output sent to browser
DEBUG - 2024-06-07 08:58:16 --> Total execution time: 0.0284
INFO - 2024-06-07 08:58:41 --> Config Class Initialized
INFO - 2024-06-07 08:58:41 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:58:41 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:58:41 --> Utf8 Class Initialized
INFO - 2024-06-07 08:58:41 --> URI Class Initialized
INFO - 2024-06-07 08:58:41 --> Router Class Initialized
INFO - 2024-06-07 08:58:41 --> Output Class Initialized
INFO - 2024-06-07 08:58:41 --> Security Class Initialized
DEBUG - 2024-06-07 08:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:58:41 --> Input Class Initialized
INFO - 2024-06-07 08:58:41 --> Language Class Initialized
INFO - 2024-06-07 08:58:41 --> Language Class Initialized
INFO - 2024-06-07 08:58:41 --> Config Class Initialized
INFO - 2024-06-07 08:58:41 --> Loader Class Initialized
INFO - 2024-06-07 08:58:41 --> Helper loaded: url_helper
INFO - 2024-06-07 08:58:41 --> Helper loaded: file_helper
INFO - 2024-06-07 08:58:41 --> Helper loaded: form_helper
INFO - 2024-06-07 08:58:41 --> Helper loaded: my_helper
INFO - 2024-06-07 08:58:41 --> Database Driver Class Initialized
INFO - 2024-06-07 08:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:58:41 --> Controller Class Initialized
INFO - 2024-06-07 08:58:41 --> Final output sent to browser
DEBUG - 2024-06-07 08:58:41 --> Total execution time: 0.0397
INFO - 2024-06-07 08:58:41 --> Config Class Initialized
INFO - 2024-06-07 08:58:41 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:58:41 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:58:41 --> Utf8 Class Initialized
INFO - 2024-06-07 08:58:41 --> URI Class Initialized
INFO - 2024-06-07 08:58:41 --> Router Class Initialized
INFO - 2024-06-07 08:58:41 --> Output Class Initialized
INFO - 2024-06-07 08:58:41 --> Security Class Initialized
DEBUG - 2024-06-07 08:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:58:41 --> Input Class Initialized
INFO - 2024-06-07 08:58:41 --> Language Class Initialized
ERROR - 2024-06-07 08:58:41 --> 404 Page Not Found: /index
INFO - 2024-06-07 08:58:41 --> Config Class Initialized
INFO - 2024-06-07 08:58:41 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:58:41 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:58:41 --> Utf8 Class Initialized
INFO - 2024-06-07 08:58:41 --> URI Class Initialized
INFO - 2024-06-07 08:58:41 --> Router Class Initialized
INFO - 2024-06-07 08:58:41 --> Output Class Initialized
INFO - 2024-06-07 08:58:41 --> Security Class Initialized
DEBUG - 2024-06-07 08:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:58:41 --> Input Class Initialized
INFO - 2024-06-07 08:58:41 --> Language Class Initialized
INFO - 2024-06-07 08:58:41 --> Language Class Initialized
INFO - 2024-06-07 08:58:41 --> Config Class Initialized
INFO - 2024-06-07 08:58:41 --> Loader Class Initialized
INFO - 2024-06-07 08:58:41 --> Helper loaded: url_helper
INFO - 2024-06-07 08:58:41 --> Helper loaded: file_helper
INFO - 2024-06-07 08:58:41 --> Helper loaded: form_helper
INFO - 2024-06-07 08:58:41 --> Helper loaded: my_helper
INFO - 2024-06-07 08:58:41 --> Database Driver Class Initialized
INFO - 2024-06-07 08:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:58:41 --> Controller Class Initialized
INFO - 2024-06-07 08:58:50 --> Config Class Initialized
INFO - 2024-06-07 08:58:50 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:58:50 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:58:50 --> Utf8 Class Initialized
INFO - 2024-06-07 08:58:50 --> URI Class Initialized
INFO - 2024-06-07 08:58:50 --> Router Class Initialized
INFO - 2024-06-07 08:58:50 --> Output Class Initialized
INFO - 2024-06-07 08:58:50 --> Security Class Initialized
DEBUG - 2024-06-07 08:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:58:50 --> Input Class Initialized
INFO - 2024-06-07 08:58:50 --> Language Class Initialized
INFO - 2024-06-07 08:58:50 --> Language Class Initialized
INFO - 2024-06-07 08:58:50 --> Config Class Initialized
INFO - 2024-06-07 08:58:50 --> Loader Class Initialized
INFO - 2024-06-07 08:58:50 --> Helper loaded: url_helper
INFO - 2024-06-07 08:58:50 --> Helper loaded: file_helper
INFO - 2024-06-07 08:58:50 --> Helper loaded: form_helper
INFO - 2024-06-07 08:58:50 --> Helper loaded: my_helper
INFO - 2024-06-07 08:58:50 --> Database Driver Class Initialized
INFO - 2024-06-07 08:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:58:50 --> Controller Class Initialized
INFO - 2024-06-07 08:58:50 --> Helper loaded: cookie_helper
INFO - 2024-06-07 08:58:50 --> Config Class Initialized
INFO - 2024-06-07 08:58:50 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:58:50 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:58:50 --> Utf8 Class Initialized
INFO - 2024-06-07 08:58:50 --> URI Class Initialized
INFO - 2024-06-07 08:58:50 --> Router Class Initialized
INFO - 2024-06-07 08:58:50 --> Output Class Initialized
INFO - 2024-06-07 08:58:50 --> Security Class Initialized
DEBUG - 2024-06-07 08:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:58:50 --> Input Class Initialized
INFO - 2024-06-07 08:58:50 --> Language Class Initialized
INFO - 2024-06-07 08:58:50 --> Language Class Initialized
INFO - 2024-06-07 08:58:50 --> Config Class Initialized
INFO - 2024-06-07 08:58:50 --> Loader Class Initialized
INFO - 2024-06-07 08:58:50 --> Helper loaded: url_helper
INFO - 2024-06-07 08:58:50 --> Helper loaded: file_helper
INFO - 2024-06-07 08:58:50 --> Helper loaded: form_helper
INFO - 2024-06-07 08:58:50 --> Helper loaded: my_helper
INFO - 2024-06-07 08:58:50 --> Database Driver Class Initialized
INFO - 2024-06-07 08:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:58:50 --> Controller Class Initialized
INFO - 2024-06-07 08:58:50 --> Config Class Initialized
INFO - 2024-06-07 08:58:50 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:58:50 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:58:50 --> Utf8 Class Initialized
INFO - 2024-06-07 08:58:50 --> URI Class Initialized
INFO - 2024-06-07 08:58:50 --> Router Class Initialized
INFO - 2024-06-07 08:58:50 --> Output Class Initialized
INFO - 2024-06-07 08:58:50 --> Security Class Initialized
DEBUG - 2024-06-07 08:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:58:50 --> Input Class Initialized
INFO - 2024-06-07 08:58:50 --> Language Class Initialized
INFO - 2024-06-07 08:58:50 --> Language Class Initialized
INFO - 2024-06-07 08:58:50 --> Config Class Initialized
INFO - 2024-06-07 08:58:50 --> Loader Class Initialized
INFO - 2024-06-07 08:58:50 --> Helper loaded: url_helper
INFO - 2024-06-07 08:58:50 --> Helper loaded: file_helper
INFO - 2024-06-07 08:58:50 --> Helper loaded: form_helper
INFO - 2024-06-07 08:58:50 --> Helper loaded: my_helper
INFO - 2024-06-07 08:58:50 --> Database Driver Class Initialized
INFO - 2024-06-07 08:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:58:50 --> Controller Class Initialized
DEBUG - 2024-06-07 08:58:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-07 08:58:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:58:50 --> Final output sent to browser
DEBUG - 2024-06-07 08:58:50 --> Total execution time: 0.0284
INFO - 2024-06-07 08:58:56 --> Config Class Initialized
INFO - 2024-06-07 08:58:56 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:58:56 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:58:56 --> Utf8 Class Initialized
INFO - 2024-06-07 08:58:56 --> URI Class Initialized
INFO - 2024-06-07 08:58:56 --> Router Class Initialized
INFO - 2024-06-07 08:58:56 --> Output Class Initialized
INFO - 2024-06-07 08:58:56 --> Security Class Initialized
DEBUG - 2024-06-07 08:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:58:56 --> Input Class Initialized
INFO - 2024-06-07 08:58:56 --> Language Class Initialized
INFO - 2024-06-07 08:58:56 --> Language Class Initialized
INFO - 2024-06-07 08:58:56 --> Config Class Initialized
INFO - 2024-06-07 08:58:56 --> Loader Class Initialized
INFO - 2024-06-07 08:58:56 --> Helper loaded: url_helper
INFO - 2024-06-07 08:58:56 --> Helper loaded: file_helper
INFO - 2024-06-07 08:58:56 --> Helper loaded: form_helper
INFO - 2024-06-07 08:58:56 --> Helper loaded: my_helper
INFO - 2024-06-07 08:58:56 --> Database Driver Class Initialized
INFO - 2024-06-07 08:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:58:56 --> Controller Class Initialized
INFO - 2024-06-07 08:58:56 --> Helper loaded: cookie_helper
INFO - 2024-06-07 08:58:56 --> Final output sent to browser
DEBUG - 2024-06-07 08:58:56 --> Total execution time: 0.0586
INFO - 2024-06-07 08:58:56 --> Config Class Initialized
INFO - 2024-06-07 08:58:56 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:58:56 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:58:56 --> Utf8 Class Initialized
INFO - 2024-06-07 08:58:56 --> URI Class Initialized
INFO - 2024-06-07 08:58:56 --> Router Class Initialized
INFO - 2024-06-07 08:58:56 --> Output Class Initialized
INFO - 2024-06-07 08:58:56 --> Security Class Initialized
DEBUG - 2024-06-07 08:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:58:56 --> Input Class Initialized
INFO - 2024-06-07 08:58:56 --> Language Class Initialized
INFO - 2024-06-07 08:58:56 --> Language Class Initialized
INFO - 2024-06-07 08:58:56 --> Config Class Initialized
INFO - 2024-06-07 08:58:56 --> Loader Class Initialized
INFO - 2024-06-07 08:58:56 --> Helper loaded: url_helper
INFO - 2024-06-07 08:58:56 --> Helper loaded: file_helper
INFO - 2024-06-07 08:58:56 --> Helper loaded: form_helper
INFO - 2024-06-07 08:58:56 --> Helper loaded: my_helper
INFO - 2024-06-07 08:58:56 --> Database Driver Class Initialized
INFO - 2024-06-07 08:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:58:56 --> Controller Class Initialized
DEBUG - 2024-06-07 08:58:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-07 08:58:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:58:56 --> Final output sent to browser
DEBUG - 2024-06-07 08:58:56 --> Total execution time: 0.0421
INFO - 2024-06-07 08:59:01 --> Config Class Initialized
INFO - 2024-06-07 08:59:01 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:59:01 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:59:01 --> Utf8 Class Initialized
INFO - 2024-06-07 08:59:01 --> URI Class Initialized
INFO - 2024-06-07 08:59:01 --> Router Class Initialized
INFO - 2024-06-07 08:59:01 --> Output Class Initialized
INFO - 2024-06-07 08:59:01 --> Security Class Initialized
DEBUG - 2024-06-07 08:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:59:01 --> Input Class Initialized
INFO - 2024-06-07 08:59:01 --> Language Class Initialized
INFO - 2024-06-07 08:59:01 --> Language Class Initialized
INFO - 2024-06-07 08:59:01 --> Config Class Initialized
INFO - 2024-06-07 08:59:01 --> Loader Class Initialized
INFO - 2024-06-07 08:59:01 --> Helper loaded: url_helper
INFO - 2024-06-07 08:59:01 --> Helper loaded: file_helper
INFO - 2024-06-07 08:59:01 --> Helper loaded: form_helper
INFO - 2024-06-07 08:59:01 --> Helper loaded: my_helper
INFO - 2024-06-07 08:59:01 --> Database Driver Class Initialized
INFO - 2024-06-07 08:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:59:01 --> Controller Class Initialized
DEBUG - 2024-06-07 08:59:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-06-07 08:59:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:59:01 --> Final output sent to browser
DEBUG - 2024-06-07 08:59:01 --> Total execution time: 0.0444
INFO - 2024-06-07 08:59:05 --> Config Class Initialized
INFO - 2024-06-07 08:59:05 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:59:05 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:59:05 --> Utf8 Class Initialized
INFO - 2024-06-07 08:59:05 --> URI Class Initialized
INFO - 2024-06-07 08:59:05 --> Router Class Initialized
INFO - 2024-06-07 08:59:05 --> Output Class Initialized
INFO - 2024-06-07 08:59:05 --> Security Class Initialized
DEBUG - 2024-06-07 08:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:59:05 --> Input Class Initialized
INFO - 2024-06-07 08:59:05 --> Language Class Initialized
INFO - 2024-06-07 08:59:05 --> Language Class Initialized
INFO - 2024-06-07 08:59:05 --> Config Class Initialized
INFO - 2024-06-07 08:59:05 --> Loader Class Initialized
INFO - 2024-06-07 08:59:05 --> Helper loaded: url_helper
INFO - 2024-06-07 08:59:05 --> Helper loaded: file_helper
INFO - 2024-06-07 08:59:05 --> Helper loaded: form_helper
INFO - 2024-06-07 08:59:05 --> Helper loaded: my_helper
INFO - 2024-06-07 08:59:05 --> Database Driver Class Initialized
INFO - 2024-06-07 08:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:59:05 --> Controller Class Initialized
DEBUG - 2024-06-07 08:59:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-07 08:59:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 08:59:05 --> Final output sent to browser
DEBUG - 2024-06-07 08:59:05 --> Total execution time: 0.0756
INFO - 2024-06-07 08:59:07 --> Config Class Initialized
INFO - 2024-06-07 08:59:07 --> Hooks Class Initialized
DEBUG - 2024-06-07 08:59:07 --> UTF-8 Support Enabled
INFO - 2024-06-07 08:59:07 --> Utf8 Class Initialized
INFO - 2024-06-07 08:59:07 --> URI Class Initialized
INFO - 2024-06-07 08:59:07 --> Router Class Initialized
INFO - 2024-06-07 08:59:07 --> Output Class Initialized
INFO - 2024-06-07 08:59:07 --> Security Class Initialized
DEBUG - 2024-06-07 08:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 08:59:07 --> Input Class Initialized
INFO - 2024-06-07 08:59:07 --> Language Class Initialized
INFO - 2024-06-07 08:59:07 --> Language Class Initialized
INFO - 2024-06-07 08:59:07 --> Config Class Initialized
INFO - 2024-06-07 08:59:07 --> Loader Class Initialized
INFO - 2024-06-07 08:59:07 --> Helper loaded: url_helper
INFO - 2024-06-07 08:59:07 --> Helper loaded: file_helper
INFO - 2024-06-07 08:59:07 --> Helper loaded: form_helper
INFO - 2024-06-07 08:59:07 --> Helper loaded: my_helper
INFO - 2024-06-07 08:59:07 --> Database Driver Class Initialized
INFO - 2024-06-07 08:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 08:59:07 --> Controller Class Initialized
ERROR - 2024-06-07 08:59:07 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-07 08:59:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:59:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:59:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:59:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:59:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:59:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:59:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:59:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:59:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:59:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:59:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:59:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:59:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:59:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:59:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:59:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:59:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:59:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:59:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:59:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:59:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:59:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 08:59:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-07 08:59:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-07 08:59:12 --> Final output sent to browser
DEBUG - 2024-06-07 08:59:12 --> Total execution time: 5.5050
INFO - 2024-06-07 09:00:36 --> Config Class Initialized
INFO - 2024-06-07 09:00:36 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:00:36 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:00:36 --> Utf8 Class Initialized
INFO - 2024-06-07 09:00:36 --> URI Class Initialized
INFO - 2024-06-07 09:00:36 --> Router Class Initialized
INFO - 2024-06-07 09:00:36 --> Output Class Initialized
INFO - 2024-06-07 09:00:36 --> Security Class Initialized
DEBUG - 2024-06-07 09:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:00:36 --> Input Class Initialized
INFO - 2024-06-07 09:00:36 --> Language Class Initialized
INFO - 2024-06-07 09:00:36 --> Language Class Initialized
INFO - 2024-06-07 09:00:36 --> Config Class Initialized
INFO - 2024-06-07 09:00:36 --> Loader Class Initialized
INFO - 2024-06-07 09:00:36 --> Helper loaded: url_helper
INFO - 2024-06-07 09:00:36 --> Helper loaded: file_helper
INFO - 2024-06-07 09:00:36 --> Helper loaded: form_helper
INFO - 2024-06-07 09:00:36 --> Helper loaded: my_helper
INFO - 2024-06-07 09:00:36 --> Database Driver Class Initialized
INFO - 2024-06-07 09:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:00:36 --> Controller Class Initialized
ERROR - 2024-06-07 09:00:36 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-07 09:00:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-07 09:00:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-07 09:00:42 --> Config Class Initialized
INFO - 2024-06-07 09:00:42 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:00:42 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:00:42 --> Utf8 Class Initialized
INFO - 2024-06-07 09:00:42 --> URI Class Initialized
INFO - 2024-06-07 09:00:42 --> Router Class Initialized
INFO - 2024-06-07 09:00:42 --> Output Class Initialized
INFO - 2024-06-07 09:00:42 --> Security Class Initialized
DEBUG - 2024-06-07 09:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:00:42 --> Input Class Initialized
INFO - 2024-06-07 09:00:42 --> Language Class Initialized
INFO - 2024-06-07 09:00:42 --> Language Class Initialized
INFO - 2024-06-07 09:00:42 --> Config Class Initialized
INFO - 2024-06-07 09:00:42 --> Loader Class Initialized
INFO - 2024-06-07 09:00:42 --> Helper loaded: url_helper
INFO - 2024-06-07 09:00:42 --> Helper loaded: file_helper
INFO - 2024-06-07 09:00:42 --> Helper loaded: form_helper
INFO - 2024-06-07 09:00:42 --> Helper loaded: my_helper
INFO - 2024-06-07 09:00:42 --> Database Driver Class Initialized
INFO - 2024-06-07 09:00:44 --> Final output sent to browser
DEBUG - 2024-06-07 09:00:44 --> Total execution time: 8.4116
INFO - 2024-06-07 09:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:00:44 --> Controller Class Initialized
ERROR - 2024-06-07 09:00:44 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-07 09:00:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-07 09:00:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-07 09:00:46 --> Config Class Initialized
INFO - 2024-06-07 09:00:46 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:00:46 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:00:46 --> Utf8 Class Initialized
INFO - 2024-06-07 09:00:46 --> URI Class Initialized
INFO - 2024-06-07 09:00:46 --> Router Class Initialized
INFO - 2024-06-07 09:00:46 --> Output Class Initialized
INFO - 2024-06-07 09:00:46 --> Security Class Initialized
DEBUG - 2024-06-07 09:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:00:46 --> Input Class Initialized
INFO - 2024-06-07 09:00:46 --> Language Class Initialized
INFO - 2024-06-07 09:00:46 --> Language Class Initialized
INFO - 2024-06-07 09:00:46 --> Config Class Initialized
INFO - 2024-06-07 09:00:46 --> Loader Class Initialized
INFO - 2024-06-07 09:00:46 --> Helper loaded: url_helper
INFO - 2024-06-07 09:00:46 --> Helper loaded: file_helper
INFO - 2024-06-07 09:00:46 --> Helper loaded: form_helper
INFO - 2024-06-07 09:00:46 --> Helper loaded: my_helper
INFO - 2024-06-07 09:00:46 --> Database Driver Class Initialized
INFO - 2024-06-07 09:00:48 --> Config Class Initialized
INFO - 2024-06-07 09:00:48 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:00:48 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:00:48 --> Utf8 Class Initialized
INFO - 2024-06-07 09:00:48 --> URI Class Initialized
INFO - 2024-06-07 09:00:48 --> Router Class Initialized
INFO - 2024-06-07 09:00:48 --> Output Class Initialized
INFO - 2024-06-07 09:00:48 --> Security Class Initialized
DEBUG - 2024-06-07 09:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:00:48 --> Input Class Initialized
INFO - 2024-06-07 09:00:48 --> Language Class Initialized
INFO - 2024-06-07 09:00:48 --> Language Class Initialized
INFO - 2024-06-07 09:00:48 --> Config Class Initialized
INFO - 2024-06-07 09:00:48 --> Loader Class Initialized
INFO - 2024-06-07 09:00:48 --> Helper loaded: url_helper
INFO - 2024-06-07 09:00:48 --> Helper loaded: file_helper
INFO - 2024-06-07 09:00:48 --> Helper loaded: form_helper
INFO - 2024-06-07 09:00:48 --> Helper loaded: my_helper
INFO - 2024-06-07 09:00:48 --> Database Driver Class Initialized
INFO - 2024-06-07 09:00:52 --> Final output sent to browser
DEBUG - 2024-06-07 09:00:52 --> Total execution time: 10.3774
INFO - 2024-06-07 09:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:00:52 --> Controller Class Initialized
ERROR - 2024-06-07 09:00:52 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-07 09:00:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-07 09:00:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-07 09:00:59 --> Final output sent to browser
DEBUG - 2024-06-07 09:00:59 --> Total execution time: 13.6939
INFO - 2024-06-07 09:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:00:59 --> Controller Class Initialized
ERROR - 2024-06-07 09:00:59 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-07 09:00:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:00:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-07 09:00:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-07 09:01:05 --> Final output sent to browser
DEBUG - 2024-06-07 09:01:05 --> Total execution time: 16.4045
INFO - 2024-06-07 09:01:29 --> Config Class Initialized
INFO - 2024-06-07 09:01:29 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:01:29 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:01:29 --> Utf8 Class Initialized
INFO - 2024-06-07 09:01:29 --> URI Class Initialized
INFO - 2024-06-07 09:01:29 --> Router Class Initialized
INFO - 2024-06-07 09:01:29 --> Output Class Initialized
INFO - 2024-06-07 09:01:29 --> Security Class Initialized
DEBUG - 2024-06-07 09:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:01:29 --> Input Class Initialized
INFO - 2024-06-07 09:01:29 --> Language Class Initialized
INFO - 2024-06-07 09:01:29 --> Language Class Initialized
INFO - 2024-06-07 09:01:29 --> Config Class Initialized
INFO - 2024-06-07 09:01:29 --> Loader Class Initialized
INFO - 2024-06-07 09:01:29 --> Helper loaded: url_helper
INFO - 2024-06-07 09:01:29 --> Helper loaded: file_helper
INFO - 2024-06-07 09:01:29 --> Helper loaded: form_helper
INFO - 2024-06-07 09:01:29 --> Helper loaded: my_helper
INFO - 2024-06-07 09:01:29 --> Database Driver Class Initialized
INFO - 2024-06-07 09:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:01:29 --> Controller Class Initialized
ERROR - 2024-06-07 09:01:29 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-07 09:01:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-07 09:01:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-07 09:01:32 --> Config Class Initialized
INFO - 2024-06-07 09:01:32 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:01:32 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:01:32 --> Utf8 Class Initialized
INFO - 2024-06-07 09:01:32 --> URI Class Initialized
INFO - 2024-06-07 09:01:32 --> Router Class Initialized
INFO - 2024-06-07 09:01:32 --> Output Class Initialized
INFO - 2024-06-07 09:01:32 --> Security Class Initialized
DEBUG - 2024-06-07 09:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:01:32 --> Input Class Initialized
INFO - 2024-06-07 09:01:32 --> Language Class Initialized
INFO - 2024-06-07 09:01:32 --> Language Class Initialized
INFO - 2024-06-07 09:01:32 --> Config Class Initialized
INFO - 2024-06-07 09:01:32 --> Loader Class Initialized
INFO - 2024-06-07 09:01:32 --> Helper loaded: url_helper
INFO - 2024-06-07 09:01:32 --> Helper loaded: file_helper
INFO - 2024-06-07 09:01:32 --> Helper loaded: form_helper
INFO - 2024-06-07 09:01:32 --> Helper loaded: my_helper
INFO - 2024-06-07 09:01:32 --> Database Driver Class Initialized
INFO - 2024-06-07 09:01:34 --> Config Class Initialized
INFO - 2024-06-07 09:01:34 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:01:34 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:01:34 --> Utf8 Class Initialized
INFO - 2024-06-07 09:01:34 --> URI Class Initialized
INFO - 2024-06-07 09:01:34 --> Router Class Initialized
INFO - 2024-06-07 09:01:34 --> Output Class Initialized
INFO - 2024-06-07 09:01:34 --> Security Class Initialized
DEBUG - 2024-06-07 09:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:01:34 --> Input Class Initialized
INFO - 2024-06-07 09:01:34 --> Language Class Initialized
INFO - 2024-06-07 09:01:34 --> Language Class Initialized
INFO - 2024-06-07 09:01:34 --> Config Class Initialized
INFO - 2024-06-07 09:01:34 --> Loader Class Initialized
INFO - 2024-06-07 09:01:34 --> Helper loaded: url_helper
INFO - 2024-06-07 09:01:34 --> Helper loaded: file_helper
INFO - 2024-06-07 09:01:34 --> Helper loaded: form_helper
INFO - 2024-06-07 09:01:34 --> Helper loaded: my_helper
INFO - 2024-06-07 09:01:34 --> Database Driver Class Initialized
INFO - 2024-06-07 09:01:35 --> Final output sent to browser
DEBUG - 2024-06-07 09:01:35 --> Total execution time: 5.6205
INFO - 2024-06-07 09:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:01:35 --> Controller Class Initialized
ERROR - 2024-06-07 09:01:35 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-07 09:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-07 09:01:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-07 09:01:37 --> Config Class Initialized
INFO - 2024-06-07 09:01:37 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:01:37 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:01:37 --> Utf8 Class Initialized
INFO - 2024-06-07 09:01:37 --> URI Class Initialized
INFO - 2024-06-07 09:01:37 --> Router Class Initialized
INFO - 2024-06-07 09:01:37 --> Output Class Initialized
INFO - 2024-06-07 09:01:37 --> Security Class Initialized
DEBUG - 2024-06-07 09:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:01:37 --> Input Class Initialized
INFO - 2024-06-07 09:01:37 --> Language Class Initialized
INFO - 2024-06-07 09:01:37 --> Language Class Initialized
INFO - 2024-06-07 09:01:37 --> Config Class Initialized
INFO - 2024-06-07 09:01:37 --> Loader Class Initialized
INFO - 2024-06-07 09:01:37 --> Helper loaded: url_helper
INFO - 2024-06-07 09:01:37 --> Helper loaded: file_helper
INFO - 2024-06-07 09:01:37 --> Helper loaded: form_helper
INFO - 2024-06-07 09:01:37 --> Helper loaded: my_helper
INFO - 2024-06-07 09:01:37 --> Database Driver Class Initialized
INFO - 2024-06-07 09:01:39 --> Final output sent to browser
DEBUG - 2024-06-07 09:01:39 --> Total execution time: 7.1675
INFO - 2024-06-07 09:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:01:39 --> Controller Class Initialized
ERROR - 2024-06-07 09:01:39 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-07 09:01:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:39 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-07 09:01:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-07 09:01:40 --> Config Class Initialized
INFO - 2024-06-07 09:01:40 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:01:40 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:01:40 --> Utf8 Class Initialized
INFO - 2024-06-07 09:01:40 --> URI Class Initialized
INFO - 2024-06-07 09:01:40 --> Router Class Initialized
INFO - 2024-06-07 09:01:40 --> Output Class Initialized
INFO - 2024-06-07 09:01:40 --> Security Class Initialized
DEBUG - 2024-06-07 09:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:01:40 --> Input Class Initialized
INFO - 2024-06-07 09:01:40 --> Language Class Initialized
INFO - 2024-06-07 09:01:40 --> Language Class Initialized
INFO - 2024-06-07 09:01:40 --> Config Class Initialized
INFO - 2024-06-07 09:01:40 --> Loader Class Initialized
INFO - 2024-06-07 09:01:40 --> Helper loaded: url_helper
INFO - 2024-06-07 09:01:40 --> Helper loaded: file_helper
INFO - 2024-06-07 09:01:40 --> Helper loaded: form_helper
INFO - 2024-06-07 09:01:40 --> Helper loaded: my_helper
INFO - 2024-06-07 09:01:40 --> Database Driver Class Initialized
INFO - 2024-06-07 09:01:43 --> Final output sent to browser
DEBUG - 2024-06-07 09:01:43 --> Total execution time: 8.9640
INFO - 2024-06-07 09:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:01:43 --> Controller Class Initialized
ERROR - 2024-06-07 09:01:43 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-07 09:01:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-07 09:01:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-07 09:01:44 --> Config Class Initialized
INFO - 2024-06-07 09:01:44 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:01:44 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:01:44 --> Utf8 Class Initialized
INFO - 2024-06-07 09:01:44 --> URI Class Initialized
INFO - 2024-06-07 09:01:44 --> Router Class Initialized
INFO - 2024-06-07 09:01:44 --> Output Class Initialized
INFO - 2024-06-07 09:01:44 --> Security Class Initialized
DEBUG - 2024-06-07 09:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:01:44 --> Input Class Initialized
INFO - 2024-06-07 09:01:44 --> Language Class Initialized
INFO - 2024-06-07 09:01:44 --> Language Class Initialized
INFO - 2024-06-07 09:01:44 --> Config Class Initialized
INFO - 2024-06-07 09:01:44 --> Loader Class Initialized
INFO - 2024-06-07 09:01:44 --> Helper loaded: url_helper
INFO - 2024-06-07 09:01:44 --> Helper loaded: file_helper
INFO - 2024-06-07 09:01:44 --> Helper loaded: form_helper
INFO - 2024-06-07 09:01:44 --> Helper loaded: my_helper
INFO - 2024-06-07 09:01:44 --> Database Driver Class Initialized
INFO - 2024-06-07 09:01:46 --> Config Class Initialized
INFO - 2024-06-07 09:01:46 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:01:46 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:01:46 --> Utf8 Class Initialized
INFO - 2024-06-07 09:01:46 --> URI Class Initialized
INFO - 2024-06-07 09:01:46 --> Router Class Initialized
INFO - 2024-06-07 09:01:46 --> Output Class Initialized
INFO - 2024-06-07 09:01:46 --> Security Class Initialized
DEBUG - 2024-06-07 09:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:01:46 --> Input Class Initialized
INFO - 2024-06-07 09:01:46 --> Language Class Initialized
INFO - 2024-06-07 09:01:46 --> Language Class Initialized
INFO - 2024-06-07 09:01:46 --> Config Class Initialized
INFO - 2024-06-07 09:01:46 --> Loader Class Initialized
INFO - 2024-06-07 09:01:46 --> Helper loaded: url_helper
INFO - 2024-06-07 09:01:46 --> Helper loaded: file_helper
INFO - 2024-06-07 09:01:46 --> Helper loaded: form_helper
INFO - 2024-06-07 09:01:46 --> Helper loaded: my_helper
INFO - 2024-06-07 09:01:46 --> Database Driver Class Initialized
INFO - 2024-06-07 09:01:49 --> Config Class Initialized
INFO - 2024-06-07 09:01:49 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:01:49 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:01:49 --> Utf8 Class Initialized
INFO - 2024-06-07 09:01:49 --> URI Class Initialized
INFO - 2024-06-07 09:01:49 --> Router Class Initialized
INFO - 2024-06-07 09:01:49 --> Output Class Initialized
INFO - 2024-06-07 09:01:49 --> Security Class Initialized
DEBUG - 2024-06-07 09:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:01:49 --> Input Class Initialized
INFO - 2024-06-07 09:01:49 --> Language Class Initialized
INFO - 2024-06-07 09:01:49 --> Language Class Initialized
INFO - 2024-06-07 09:01:49 --> Config Class Initialized
INFO - 2024-06-07 09:01:49 --> Loader Class Initialized
INFO - 2024-06-07 09:01:49 --> Helper loaded: url_helper
INFO - 2024-06-07 09:01:49 --> Helper loaded: file_helper
INFO - 2024-06-07 09:01:49 --> Helper loaded: form_helper
INFO - 2024-06-07 09:01:49 --> Helper loaded: my_helper
INFO - 2024-06-07 09:01:49 --> Database Driver Class Initialized
INFO - 2024-06-07 09:01:50 --> Final output sent to browser
DEBUG - 2024-06-07 09:01:50 --> Total execution time: 13.3177
INFO - 2024-06-07 09:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:01:50 --> Controller Class Initialized
ERROR - 2024-06-07 09:01:50 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-07 09:01:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-07 09:01:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-07 09:01:52 --> Config Class Initialized
INFO - 2024-06-07 09:01:52 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:01:52 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:01:52 --> Utf8 Class Initialized
INFO - 2024-06-07 09:01:52 --> URI Class Initialized
INFO - 2024-06-07 09:01:52 --> Router Class Initialized
INFO - 2024-06-07 09:01:52 --> Output Class Initialized
INFO - 2024-06-07 09:01:52 --> Security Class Initialized
DEBUG - 2024-06-07 09:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:01:52 --> Input Class Initialized
INFO - 2024-06-07 09:01:52 --> Language Class Initialized
INFO - 2024-06-07 09:01:52 --> Language Class Initialized
INFO - 2024-06-07 09:01:52 --> Config Class Initialized
INFO - 2024-06-07 09:01:52 --> Loader Class Initialized
INFO - 2024-06-07 09:01:52 --> Helper loaded: url_helper
INFO - 2024-06-07 09:01:52 --> Helper loaded: file_helper
INFO - 2024-06-07 09:01:52 --> Helper loaded: form_helper
INFO - 2024-06-07 09:01:52 --> Helper loaded: my_helper
INFO - 2024-06-07 09:01:52 --> Database Driver Class Initialized
INFO - 2024-06-07 09:01:56 --> Config Class Initialized
INFO - 2024-06-07 09:01:56 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:01:56 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:01:56 --> Utf8 Class Initialized
INFO - 2024-06-07 09:01:56 --> URI Class Initialized
INFO - 2024-06-07 09:01:56 --> Router Class Initialized
INFO - 2024-06-07 09:01:56 --> Output Class Initialized
INFO - 2024-06-07 09:01:56 --> Security Class Initialized
DEBUG - 2024-06-07 09:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:01:56 --> Input Class Initialized
INFO - 2024-06-07 09:01:56 --> Language Class Initialized
INFO - 2024-06-07 09:01:56 --> Language Class Initialized
INFO - 2024-06-07 09:01:56 --> Config Class Initialized
INFO - 2024-06-07 09:01:56 --> Loader Class Initialized
INFO - 2024-06-07 09:01:56 --> Helper loaded: url_helper
INFO - 2024-06-07 09:01:56 --> Helper loaded: file_helper
INFO - 2024-06-07 09:01:56 --> Helper loaded: form_helper
INFO - 2024-06-07 09:01:56 --> Helper loaded: my_helper
INFO - 2024-06-07 09:01:56 --> Database Driver Class Initialized
INFO - 2024-06-07 09:01:57 --> Final output sent to browser
DEBUG - 2024-06-07 09:01:57 --> Total execution time: 17.3406
INFO - 2024-06-07 09:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:01:57 --> Controller Class Initialized
ERROR - 2024-06-07 09:01:57 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-07 09:01:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:01:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-07 09:01:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-07 09:02:00 --> Config Class Initialized
INFO - 2024-06-07 09:02:00 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:02:00 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:02:00 --> Utf8 Class Initialized
INFO - 2024-06-07 09:02:00 --> URI Class Initialized
INFO - 2024-06-07 09:02:00 --> Router Class Initialized
INFO - 2024-06-07 09:02:00 --> Output Class Initialized
INFO - 2024-06-07 09:02:00 --> Security Class Initialized
DEBUG - 2024-06-07 09:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:02:00 --> Input Class Initialized
INFO - 2024-06-07 09:02:00 --> Language Class Initialized
INFO - 2024-06-07 09:02:00 --> Language Class Initialized
INFO - 2024-06-07 09:02:00 --> Config Class Initialized
INFO - 2024-06-07 09:02:00 --> Loader Class Initialized
INFO - 2024-06-07 09:02:00 --> Helper loaded: url_helper
INFO - 2024-06-07 09:02:00 --> Helper loaded: file_helper
INFO - 2024-06-07 09:02:00 --> Helper loaded: form_helper
INFO - 2024-06-07 09:02:00 --> Helper loaded: my_helper
INFO - 2024-06-07 09:02:00 --> Database Driver Class Initialized
INFO - 2024-06-07 09:02:03 --> Final output sent to browser
DEBUG - 2024-06-07 09:02:03 --> Total execution time: 19.8093
INFO - 2024-06-07 09:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:02:03 --> Controller Class Initialized
ERROR - 2024-06-07 09:02:03 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-07 09:02:03 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:03 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:03 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:03 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:03 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:03 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:03 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:03 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:03 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:03 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:03 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:03 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:03 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:03 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:03 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:03 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:03 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:03 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:03 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:03 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:03 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:03 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:03 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-07 09:02:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-07 09:02:09 --> Final output sent to browser
DEBUG - 2024-06-07 09:02:09 --> Total execution time: 22.8103
INFO - 2024-06-07 09:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:02:09 --> Controller Class Initialized
ERROR - 2024-06-07 09:02:09 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-07 09:02:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-07 09:02:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-07 09:02:15 --> Final output sent to browser
DEBUG - 2024-06-07 09:02:15 --> Total execution time: 25.6752
INFO - 2024-06-07 09:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:02:15 --> Controller Class Initialized
ERROR - 2024-06-07 09:02:15 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-07 09:02:15 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:15 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:15 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:15 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:15 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:15 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:15 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:15 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:15 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:15 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:15 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:15 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:15 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:15 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:15 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:15 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:15 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:15 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:15 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:15 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:15 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:15 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:15 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-07 09:02:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-07 09:02:20 --> Final output sent to browser
DEBUG - 2024-06-07 09:02:20 --> Total execution time: 27.7001
INFO - 2024-06-07 09:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:02:20 --> Controller Class Initialized
ERROR - 2024-06-07 09:02:20 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-07 09:02:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:20 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-07 09:02:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-07 09:02:24 --> Final output sent to browser
DEBUG - 2024-06-07 09:02:24 --> Total execution time: 28.0152
INFO - 2024-06-07 09:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:02:24 --> Controller Class Initialized
ERROR - 2024-06-07 09:02:24 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-07 09:02:24 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:24 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:24 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:24 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:24 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:24 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:24 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:24 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:24 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:24 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:24 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:24 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:24 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:24 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:24 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:24 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:24 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:24 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:24 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:24 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:24 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:24 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-07 09:02:24 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-07 09:02:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-07 09:02:29 --> Final output sent to browser
DEBUG - 2024-06-07 09:02:29 --> Total execution time: 29.8045
INFO - 2024-06-07 09:03:59 --> Config Class Initialized
INFO - 2024-06-07 09:03:59 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:03:59 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:03:59 --> Utf8 Class Initialized
INFO - 2024-06-07 09:03:59 --> URI Class Initialized
INFO - 2024-06-07 09:03:59 --> Router Class Initialized
INFO - 2024-06-07 09:03:59 --> Output Class Initialized
INFO - 2024-06-07 09:03:59 --> Security Class Initialized
DEBUG - 2024-06-07 09:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:03:59 --> Input Class Initialized
INFO - 2024-06-07 09:03:59 --> Language Class Initialized
INFO - 2024-06-07 09:03:59 --> Language Class Initialized
INFO - 2024-06-07 09:03:59 --> Config Class Initialized
INFO - 2024-06-07 09:03:59 --> Loader Class Initialized
INFO - 2024-06-07 09:03:59 --> Helper loaded: url_helper
INFO - 2024-06-07 09:03:59 --> Helper loaded: file_helper
INFO - 2024-06-07 09:03:59 --> Helper loaded: form_helper
INFO - 2024-06-07 09:03:59 --> Helper loaded: my_helper
INFO - 2024-06-07 09:03:59 --> Database Driver Class Initialized
INFO - 2024-06-07 09:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:03:59 --> Controller Class Initialized
DEBUG - 2024-06-07 09:03:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-07 09:04:01 --> Final output sent to browser
DEBUG - 2024-06-07 09:04:01 --> Total execution time: 2.0250
INFO - 2024-06-07 09:04:01 --> Config Class Initialized
INFO - 2024-06-07 09:04:01 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:04:01 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:04:01 --> Utf8 Class Initialized
INFO - 2024-06-07 09:04:01 --> URI Class Initialized
INFO - 2024-06-07 09:04:01 --> Router Class Initialized
INFO - 2024-06-07 09:04:01 --> Output Class Initialized
INFO - 2024-06-07 09:04:01 --> Security Class Initialized
DEBUG - 2024-06-07 09:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:04:01 --> Input Class Initialized
INFO - 2024-06-07 09:04:01 --> Language Class Initialized
INFO - 2024-06-07 09:04:01 --> Language Class Initialized
INFO - 2024-06-07 09:04:01 --> Config Class Initialized
INFO - 2024-06-07 09:04:01 --> Loader Class Initialized
INFO - 2024-06-07 09:04:01 --> Helper loaded: url_helper
INFO - 2024-06-07 09:04:01 --> Helper loaded: file_helper
INFO - 2024-06-07 09:04:01 --> Helper loaded: form_helper
INFO - 2024-06-07 09:04:01 --> Helper loaded: my_helper
INFO - 2024-06-07 09:04:02 --> Database Driver Class Initialized
INFO - 2024-06-07 09:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:04:02 --> Controller Class Initialized
DEBUG - 2024-06-07 09:04:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-07 09:04:04 --> Final output sent to browser
DEBUG - 2024-06-07 09:04:04 --> Total execution time: 2.4475
INFO - 2024-06-07 09:04:05 --> Config Class Initialized
INFO - 2024-06-07 09:04:05 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:04:05 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:04:05 --> Utf8 Class Initialized
INFO - 2024-06-07 09:04:05 --> URI Class Initialized
INFO - 2024-06-07 09:04:05 --> Router Class Initialized
INFO - 2024-06-07 09:04:05 --> Output Class Initialized
INFO - 2024-06-07 09:04:05 --> Security Class Initialized
DEBUG - 2024-06-07 09:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:04:05 --> Input Class Initialized
INFO - 2024-06-07 09:04:05 --> Language Class Initialized
INFO - 2024-06-07 09:04:05 --> Language Class Initialized
INFO - 2024-06-07 09:04:05 --> Config Class Initialized
INFO - 2024-06-07 09:04:05 --> Loader Class Initialized
INFO - 2024-06-07 09:04:05 --> Helper loaded: url_helper
INFO - 2024-06-07 09:04:05 --> Helper loaded: file_helper
INFO - 2024-06-07 09:04:05 --> Helper loaded: form_helper
INFO - 2024-06-07 09:04:05 --> Helper loaded: my_helper
INFO - 2024-06-07 09:04:05 --> Database Driver Class Initialized
INFO - 2024-06-07 09:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:04:05 --> Controller Class Initialized
DEBUG - 2024-06-07 09:04:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-07 09:04:07 --> Final output sent to browser
DEBUG - 2024-06-07 09:04:07 --> Total execution time: 1.9913
INFO - 2024-06-07 09:04:07 --> Config Class Initialized
INFO - 2024-06-07 09:04:07 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:04:07 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:04:07 --> Utf8 Class Initialized
INFO - 2024-06-07 09:04:07 --> URI Class Initialized
INFO - 2024-06-07 09:04:07 --> Router Class Initialized
INFO - 2024-06-07 09:04:07 --> Output Class Initialized
INFO - 2024-06-07 09:04:07 --> Security Class Initialized
DEBUG - 2024-06-07 09:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:04:07 --> Input Class Initialized
INFO - 2024-06-07 09:04:07 --> Language Class Initialized
INFO - 2024-06-07 09:04:07 --> Language Class Initialized
INFO - 2024-06-07 09:04:07 --> Config Class Initialized
INFO - 2024-06-07 09:04:07 --> Loader Class Initialized
INFO - 2024-06-07 09:04:07 --> Helper loaded: url_helper
INFO - 2024-06-07 09:04:07 --> Helper loaded: file_helper
INFO - 2024-06-07 09:04:07 --> Helper loaded: form_helper
INFO - 2024-06-07 09:04:07 --> Helper loaded: my_helper
INFO - 2024-06-07 09:04:07 --> Database Driver Class Initialized
INFO - 2024-06-07 09:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:04:07 --> Controller Class Initialized
DEBUG - 2024-06-07 09:04:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-07 09:04:09 --> Final output sent to browser
DEBUG - 2024-06-07 09:04:09 --> Total execution time: 2.0996
INFO - 2024-06-07 09:04:09 --> Config Class Initialized
INFO - 2024-06-07 09:04:09 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:04:09 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:04:09 --> Utf8 Class Initialized
INFO - 2024-06-07 09:04:09 --> URI Class Initialized
INFO - 2024-06-07 09:04:09 --> Router Class Initialized
INFO - 2024-06-07 09:04:09 --> Output Class Initialized
INFO - 2024-06-07 09:04:09 --> Security Class Initialized
DEBUG - 2024-06-07 09:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:04:09 --> Input Class Initialized
INFO - 2024-06-07 09:04:09 --> Language Class Initialized
INFO - 2024-06-07 09:04:09 --> Language Class Initialized
INFO - 2024-06-07 09:04:09 --> Config Class Initialized
INFO - 2024-06-07 09:04:09 --> Loader Class Initialized
INFO - 2024-06-07 09:04:09 --> Helper loaded: url_helper
INFO - 2024-06-07 09:04:09 --> Helper loaded: file_helper
INFO - 2024-06-07 09:04:09 --> Helper loaded: form_helper
INFO - 2024-06-07 09:04:09 --> Helper loaded: my_helper
INFO - 2024-06-07 09:04:09 --> Database Driver Class Initialized
INFO - 2024-06-07 09:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:04:09 --> Controller Class Initialized
DEBUG - 2024-06-07 09:04:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-07 09:04:11 --> Final output sent to browser
DEBUG - 2024-06-07 09:04:11 --> Total execution time: 2.1305
INFO - 2024-06-07 09:04:12 --> Config Class Initialized
INFO - 2024-06-07 09:04:12 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:04:12 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:04:12 --> Utf8 Class Initialized
INFO - 2024-06-07 09:04:12 --> URI Class Initialized
INFO - 2024-06-07 09:04:12 --> Router Class Initialized
INFO - 2024-06-07 09:04:12 --> Output Class Initialized
INFO - 2024-06-07 09:04:12 --> Security Class Initialized
DEBUG - 2024-06-07 09:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:04:12 --> Input Class Initialized
INFO - 2024-06-07 09:04:12 --> Language Class Initialized
INFO - 2024-06-07 09:04:12 --> Language Class Initialized
INFO - 2024-06-07 09:04:12 --> Config Class Initialized
INFO - 2024-06-07 09:04:12 --> Loader Class Initialized
INFO - 2024-06-07 09:04:12 --> Helper loaded: url_helper
INFO - 2024-06-07 09:04:12 --> Helper loaded: file_helper
INFO - 2024-06-07 09:04:12 --> Helper loaded: form_helper
INFO - 2024-06-07 09:04:12 --> Helper loaded: my_helper
INFO - 2024-06-07 09:04:12 --> Database Driver Class Initialized
INFO - 2024-06-07 09:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:04:12 --> Controller Class Initialized
DEBUG - 2024-06-07 09:04:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-07 09:04:14 --> Config Class Initialized
INFO - 2024-06-07 09:04:14 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:04:14 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:04:14 --> Utf8 Class Initialized
INFO - 2024-06-07 09:04:14 --> URI Class Initialized
INFO - 2024-06-07 09:04:14 --> Router Class Initialized
INFO - 2024-06-07 09:04:14 --> Output Class Initialized
INFO - 2024-06-07 09:04:14 --> Security Class Initialized
DEBUG - 2024-06-07 09:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:04:14 --> Input Class Initialized
INFO - 2024-06-07 09:04:14 --> Language Class Initialized
INFO - 2024-06-07 09:04:14 --> Language Class Initialized
INFO - 2024-06-07 09:04:14 --> Config Class Initialized
INFO - 2024-06-07 09:04:14 --> Loader Class Initialized
INFO - 2024-06-07 09:04:14 --> Helper loaded: url_helper
INFO - 2024-06-07 09:04:14 --> Helper loaded: file_helper
INFO - 2024-06-07 09:04:14 --> Helper loaded: form_helper
INFO - 2024-06-07 09:04:14 --> Helper loaded: my_helper
INFO - 2024-06-07 09:04:14 --> Final output sent to browser
DEBUG - 2024-06-07 09:04:14 --> Total execution time: 2.8249
INFO - 2024-06-07 09:04:14 --> Database Driver Class Initialized
INFO - 2024-06-07 09:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:04:14 --> Controller Class Initialized
DEBUG - 2024-06-07 09:04:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-07 09:04:17 --> Config Class Initialized
INFO - 2024-06-07 09:04:17 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:04:17 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:04:17 --> Utf8 Class Initialized
INFO - 2024-06-07 09:04:17 --> URI Class Initialized
INFO - 2024-06-07 09:04:17 --> Router Class Initialized
INFO - 2024-06-07 09:04:17 --> Output Class Initialized
INFO - 2024-06-07 09:04:17 --> Security Class Initialized
DEBUG - 2024-06-07 09:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:04:17 --> Input Class Initialized
INFO - 2024-06-07 09:04:17 --> Language Class Initialized
INFO - 2024-06-07 09:04:17 --> Language Class Initialized
INFO - 2024-06-07 09:04:17 --> Config Class Initialized
INFO - 2024-06-07 09:04:17 --> Loader Class Initialized
INFO - 2024-06-07 09:04:17 --> Helper loaded: url_helper
INFO - 2024-06-07 09:04:17 --> Helper loaded: file_helper
INFO - 2024-06-07 09:04:17 --> Helper loaded: form_helper
INFO - 2024-06-07 09:04:17 --> Helper loaded: my_helper
INFO - 2024-06-07 09:04:17 --> Database Driver Class Initialized
INFO - 2024-06-07 09:04:18 --> Final output sent to browser
DEBUG - 2024-06-07 09:04:18 --> Total execution time: 3.2567
INFO - 2024-06-07 09:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:04:18 --> Controller Class Initialized
DEBUG - 2024-06-07 09:04:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-07 09:04:20 --> Final output sent to browser
DEBUG - 2024-06-07 09:04:20 --> Total execution time: 2.2027
INFO - 2024-06-07 09:04:20 --> Config Class Initialized
INFO - 2024-06-07 09:04:20 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:04:20 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:04:20 --> Utf8 Class Initialized
INFO - 2024-06-07 09:04:20 --> URI Class Initialized
INFO - 2024-06-07 09:04:20 --> Router Class Initialized
INFO - 2024-06-07 09:04:20 --> Output Class Initialized
INFO - 2024-06-07 09:04:20 --> Security Class Initialized
DEBUG - 2024-06-07 09:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:04:20 --> Input Class Initialized
INFO - 2024-06-07 09:04:20 --> Language Class Initialized
INFO - 2024-06-07 09:04:21 --> Language Class Initialized
INFO - 2024-06-07 09:04:21 --> Config Class Initialized
INFO - 2024-06-07 09:04:21 --> Loader Class Initialized
INFO - 2024-06-07 09:04:21 --> Helper loaded: url_helper
INFO - 2024-06-07 09:04:21 --> Helper loaded: file_helper
INFO - 2024-06-07 09:04:21 --> Helper loaded: form_helper
INFO - 2024-06-07 09:04:21 --> Helper loaded: my_helper
INFO - 2024-06-07 09:04:21 --> Database Driver Class Initialized
INFO - 2024-06-07 09:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:04:21 --> Controller Class Initialized
DEBUG - 2024-06-07 09:04:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-07 09:04:23 --> Final output sent to browser
DEBUG - 2024-06-07 09:04:23 --> Total execution time: 2.0313
INFO - 2024-06-07 09:04:23 --> Config Class Initialized
INFO - 2024-06-07 09:04:23 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:04:23 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:04:23 --> Utf8 Class Initialized
INFO - 2024-06-07 09:04:23 --> URI Class Initialized
INFO - 2024-06-07 09:04:23 --> Router Class Initialized
INFO - 2024-06-07 09:04:23 --> Output Class Initialized
INFO - 2024-06-07 09:04:23 --> Security Class Initialized
DEBUG - 2024-06-07 09:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:04:23 --> Input Class Initialized
INFO - 2024-06-07 09:04:23 --> Language Class Initialized
INFO - 2024-06-07 09:04:23 --> Language Class Initialized
INFO - 2024-06-07 09:04:23 --> Config Class Initialized
INFO - 2024-06-07 09:04:23 --> Loader Class Initialized
INFO - 2024-06-07 09:04:23 --> Helper loaded: url_helper
INFO - 2024-06-07 09:04:23 --> Helper loaded: file_helper
INFO - 2024-06-07 09:04:23 --> Helper loaded: form_helper
INFO - 2024-06-07 09:04:23 --> Helper loaded: my_helper
INFO - 2024-06-07 09:04:23 --> Database Driver Class Initialized
INFO - 2024-06-07 09:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:04:23 --> Controller Class Initialized
DEBUG - 2024-06-07 09:04:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-07 09:04:26 --> Final output sent to browser
DEBUG - 2024-06-07 09:04:26 --> Total execution time: 2.7400
INFO - 2024-06-07 09:04:27 --> Config Class Initialized
INFO - 2024-06-07 09:04:27 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:04:27 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:04:27 --> Utf8 Class Initialized
INFO - 2024-06-07 09:04:27 --> URI Class Initialized
INFO - 2024-06-07 09:04:27 --> Router Class Initialized
INFO - 2024-06-07 09:04:27 --> Output Class Initialized
INFO - 2024-06-07 09:04:27 --> Security Class Initialized
DEBUG - 2024-06-07 09:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:04:27 --> Input Class Initialized
INFO - 2024-06-07 09:04:27 --> Language Class Initialized
INFO - 2024-06-07 09:04:27 --> Language Class Initialized
INFO - 2024-06-07 09:04:27 --> Config Class Initialized
INFO - 2024-06-07 09:04:27 --> Loader Class Initialized
INFO - 2024-06-07 09:04:27 --> Helper loaded: url_helper
INFO - 2024-06-07 09:04:27 --> Helper loaded: file_helper
INFO - 2024-06-07 09:04:27 --> Helper loaded: form_helper
INFO - 2024-06-07 09:04:27 --> Helper loaded: my_helper
INFO - 2024-06-07 09:04:27 --> Database Driver Class Initialized
INFO - 2024-06-07 09:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:04:27 --> Controller Class Initialized
DEBUG - 2024-06-07 09:04:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-07 09:04:29 --> Final output sent to browser
DEBUG - 2024-06-07 09:04:29 --> Total execution time: 2.1143
INFO - 2024-06-07 09:06:04 --> Config Class Initialized
INFO - 2024-06-07 09:06:04 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:06:04 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:06:04 --> Utf8 Class Initialized
INFO - 2024-06-07 09:06:04 --> URI Class Initialized
INFO - 2024-06-07 09:06:04 --> Router Class Initialized
INFO - 2024-06-07 09:06:04 --> Output Class Initialized
INFO - 2024-06-07 09:06:04 --> Security Class Initialized
DEBUG - 2024-06-07 09:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:06:04 --> Input Class Initialized
INFO - 2024-06-07 09:06:04 --> Language Class Initialized
INFO - 2024-06-07 09:06:04 --> Language Class Initialized
INFO - 2024-06-07 09:06:04 --> Config Class Initialized
INFO - 2024-06-07 09:06:04 --> Loader Class Initialized
INFO - 2024-06-07 09:06:04 --> Helper loaded: url_helper
INFO - 2024-06-07 09:06:04 --> Helper loaded: file_helper
INFO - 2024-06-07 09:06:04 --> Helper loaded: form_helper
INFO - 2024-06-07 09:06:04 --> Helper loaded: my_helper
INFO - 2024-06-07 09:06:04 --> Database Driver Class Initialized
INFO - 2024-06-07 09:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:06:04 --> Controller Class Initialized
DEBUG - 2024-06-07 09:06:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-07 09:06:06 --> Config Class Initialized
INFO - 2024-06-07 09:06:06 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:06:06 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:06:06 --> Utf8 Class Initialized
INFO - 2024-06-07 09:06:06 --> URI Class Initialized
INFO - 2024-06-07 09:06:06 --> Router Class Initialized
INFO - 2024-06-07 09:06:06 --> Output Class Initialized
INFO - 2024-06-07 09:06:06 --> Security Class Initialized
DEBUG - 2024-06-07 09:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:06:06 --> Input Class Initialized
INFO - 2024-06-07 09:06:06 --> Language Class Initialized
INFO - 2024-06-07 09:06:06 --> Language Class Initialized
INFO - 2024-06-07 09:06:06 --> Config Class Initialized
INFO - 2024-06-07 09:06:06 --> Loader Class Initialized
INFO - 2024-06-07 09:06:06 --> Helper loaded: url_helper
INFO - 2024-06-07 09:06:06 --> Helper loaded: file_helper
INFO - 2024-06-07 09:06:06 --> Helper loaded: form_helper
INFO - 2024-06-07 09:06:06 --> Helper loaded: my_helper
INFO - 2024-06-07 09:06:06 --> Database Driver Class Initialized
INFO - 2024-06-07 09:06:08 --> Config Class Initialized
INFO - 2024-06-07 09:06:08 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:06:08 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:06:08 --> Utf8 Class Initialized
INFO - 2024-06-07 09:06:08 --> URI Class Initialized
INFO - 2024-06-07 09:06:08 --> Router Class Initialized
INFO - 2024-06-07 09:06:08 --> Output Class Initialized
INFO - 2024-06-07 09:06:08 --> Security Class Initialized
DEBUG - 2024-06-07 09:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:06:08 --> Input Class Initialized
INFO - 2024-06-07 09:06:08 --> Language Class Initialized
INFO - 2024-06-07 09:06:08 --> Language Class Initialized
INFO - 2024-06-07 09:06:08 --> Config Class Initialized
INFO - 2024-06-07 09:06:08 --> Loader Class Initialized
INFO - 2024-06-07 09:06:08 --> Helper loaded: url_helper
INFO - 2024-06-07 09:06:08 --> Helper loaded: file_helper
INFO - 2024-06-07 09:06:08 --> Helper loaded: form_helper
INFO - 2024-06-07 09:06:08 --> Helper loaded: my_helper
INFO - 2024-06-07 09:06:08 --> Database Driver Class Initialized
INFO - 2024-06-07 09:06:09 --> Final output sent to browser
DEBUG - 2024-06-07 09:06:09 --> Total execution time: 5.1513
INFO - 2024-06-07 09:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:06:09 --> Controller Class Initialized
DEBUG - 2024-06-07 09:06:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-07 09:06:11 --> Config Class Initialized
INFO - 2024-06-07 09:06:11 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:06:11 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:06:11 --> Utf8 Class Initialized
INFO - 2024-06-07 09:06:11 --> URI Class Initialized
INFO - 2024-06-07 09:06:11 --> Router Class Initialized
INFO - 2024-06-07 09:06:11 --> Output Class Initialized
INFO - 2024-06-07 09:06:11 --> Security Class Initialized
DEBUG - 2024-06-07 09:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:06:11 --> Input Class Initialized
INFO - 2024-06-07 09:06:11 --> Language Class Initialized
INFO - 2024-06-07 09:06:11 --> Language Class Initialized
INFO - 2024-06-07 09:06:11 --> Config Class Initialized
INFO - 2024-06-07 09:06:11 --> Loader Class Initialized
INFO - 2024-06-07 09:06:11 --> Helper loaded: url_helper
INFO - 2024-06-07 09:06:11 --> Helper loaded: file_helper
INFO - 2024-06-07 09:06:11 --> Helper loaded: form_helper
INFO - 2024-06-07 09:06:11 --> Helper loaded: my_helper
INFO - 2024-06-07 09:06:11 --> Database Driver Class Initialized
INFO - 2024-06-07 09:06:14 --> Final output sent to browser
DEBUG - 2024-06-07 09:06:14 --> Total execution time: 8.1057
INFO - 2024-06-07 09:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:06:14 --> Controller Class Initialized
DEBUG - 2024-06-07 09:06:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-07 09:06:14 --> Config Class Initialized
INFO - 2024-06-07 09:06:14 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:06:14 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:06:14 --> Utf8 Class Initialized
INFO - 2024-06-07 09:06:14 --> URI Class Initialized
INFO - 2024-06-07 09:06:14 --> Router Class Initialized
INFO - 2024-06-07 09:06:14 --> Output Class Initialized
INFO - 2024-06-07 09:06:14 --> Security Class Initialized
DEBUG - 2024-06-07 09:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:06:14 --> Input Class Initialized
INFO - 2024-06-07 09:06:14 --> Language Class Initialized
INFO - 2024-06-07 09:06:14 --> Language Class Initialized
INFO - 2024-06-07 09:06:14 --> Config Class Initialized
INFO - 2024-06-07 09:06:14 --> Loader Class Initialized
INFO - 2024-06-07 09:06:14 --> Helper loaded: url_helper
INFO - 2024-06-07 09:06:14 --> Helper loaded: file_helper
INFO - 2024-06-07 09:06:14 --> Helper loaded: form_helper
INFO - 2024-06-07 09:06:14 --> Helper loaded: my_helper
INFO - 2024-06-07 09:06:14 --> Database Driver Class Initialized
INFO - 2024-06-07 09:06:17 --> Config Class Initialized
INFO - 2024-06-07 09:06:17 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:06:17 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:06:17 --> Utf8 Class Initialized
INFO - 2024-06-07 09:06:17 --> URI Class Initialized
INFO - 2024-06-07 09:06:17 --> Router Class Initialized
INFO - 2024-06-07 09:06:17 --> Output Class Initialized
INFO - 2024-06-07 09:06:17 --> Security Class Initialized
DEBUG - 2024-06-07 09:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:06:17 --> Input Class Initialized
INFO - 2024-06-07 09:06:17 --> Language Class Initialized
INFO - 2024-06-07 09:06:17 --> Language Class Initialized
INFO - 2024-06-07 09:06:17 --> Config Class Initialized
INFO - 2024-06-07 09:06:17 --> Loader Class Initialized
INFO - 2024-06-07 09:06:17 --> Helper loaded: url_helper
INFO - 2024-06-07 09:06:17 --> Helper loaded: file_helper
INFO - 2024-06-07 09:06:17 --> Helper loaded: form_helper
INFO - 2024-06-07 09:06:17 --> Helper loaded: my_helper
INFO - 2024-06-07 09:06:17 --> Database Driver Class Initialized
INFO - 2024-06-07 09:06:19 --> Final output sent to browser
DEBUG - 2024-06-07 09:06:19 --> Total execution time: 10.2411
INFO - 2024-06-07 09:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:06:19 --> Controller Class Initialized
DEBUG - 2024-06-07 09:06:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-07 09:06:20 --> Config Class Initialized
INFO - 2024-06-07 09:06:20 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:06:20 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:06:20 --> Utf8 Class Initialized
INFO - 2024-06-07 09:06:20 --> URI Class Initialized
INFO - 2024-06-07 09:06:20 --> Router Class Initialized
INFO - 2024-06-07 09:06:20 --> Output Class Initialized
INFO - 2024-06-07 09:06:20 --> Security Class Initialized
DEBUG - 2024-06-07 09:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:06:20 --> Input Class Initialized
INFO - 2024-06-07 09:06:20 --> Language Class Initialized
INFO - 2024-06-07 09:06:20 --> Language Class Initialized
INFO - 2024-06-07 09:06:20 --> Config Class Initialized
INFO - 2024-06-07 09:06:20 --> Loader Class Initialized
INFO - 2024-06-07 09:06:20 --> Helper loaded: url_helper
INFO - 2024-06-07 09:06:20 --> Helper loaded: file_helper
INFO - 2024-06-07 09:06:20 --> Helper loaded: form_helper
INFO - 2024-06-07 09:06:20 --> Helper loaded: my_helper
INFO - 2024-06-07 09:06:20 --> Database Driver Class Initialized
INFO - 2024-06-07 09:06:23 --> Config Class Initialized
INFO - 2024-06-07 09:06:23 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:06:23 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:06:23 --> Utf8 Class Initialized
INFO - 2024-06-07 09:06:23 --> URI Class Initialized
INFO - 2024-06-07 09:06:23 --> Router Class Initialized
INFO - 2024-06-07 09:06:23 --> Output Class Initialized
INFO - 2024-06-07 09:06:23 --> Security Class Initialized
DEBUG - 2024-06-07 09:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:06:23 --> Input Class Initialized
INFO - 2024-06-07 09:06:23 --> Language Class Initialized
INFO - 2024-06-07 09:06:23 --> Language Class Initialized
INFO - 2024-06-07 09:06:23 --> Config Class Initialized
INFO - 2024-06-07 09:06:23 --> Loader Class Initialized
INFO - 2024-06-07 09:06:23 --> Helper loaded: url_helper
INFO - 2024-06-07 09:06:23 --> Helper loaded: file_helper
INFO - 2024-06-07 09:06:23 --> Helper loaded: form_helper
INFO - 2024-06-07 09:06:23 --> Helper loaded: my_helper
INFO - 2024-06-07 09:06:23 --> Database Driver Class Initialized
INFO - 2024-06-07 09:06:23 --> Final output sent to browser
DEBUG - 2024-06-07 09:06:23 --> Total execution time: 12.2687
INFO - 2024-06-07 09:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:06:23 --> Controller Class Initialized
DEBUG - 2024-06-07 09:06:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-07 09:06:25 --> Config Class Initialized
INFO - 2024-06-07 09:06:25 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:06:25 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:06:25 --> Utf8 Class Initialized
INFO - 2024-06-07 09:06:25 --> URI Class Initialized
INFO - 2024-06-07 09:06:25 --> Router Class Initialized
INFO - 2024-06-07 09:06:25 --> Output Class Initialized
INFO - 2024-06-07 09:06:25 --> Security Class Initialized
DEBUG - 2024-06-07 09:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:06:25 --> Input Class Initialized
INFO - 2024-06-07 09:06:25 --> Language Class Initialized
INFO - 2024-06-07 09:06:25 --> Language Class Initialized
INFO - 2024-06-07 09:06:25 --> Config Class Initialized
INFO - 2024-06-07 09:06:25 --> Loader Class Initialized
INFO - 2024-06-07 09:06:25 --> Helper loaded: url_helper
INFO - 2024-06-07 09:06:25 --> Helper loaded: file_helper
INFO - 2024-06-07 09:06:25 --> Helper loaded: form_helper
INFO - 2024-06-07 09:06:25 --> Helper loaded: my_helper
INFO - 2024-06-07 09:06:25 --> Database Driver Class Initialized
INFO - 2024-06-07 09:06:28 --> Final output sent to browser
DEBUG - 2024-06-07 09:06:28 --> Total execution time: 13.6224
INFO - 2024-06-07 09:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:06:28 --> Controller Class Initialized
DEBUG - 2024-06-07 09:06:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-07 09:06:29 --> Config Class Initialized
INFO - 2024-06-07 09:06:29 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:06:29 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:06:29 --> Utf8 Class Initialized
INFO - 2024-06-07 09:06:29 --> URI Class Initialized
INFO - 2024-06-07 09:06:29 --> Router Class Initialized
INFO - 2024-06-07 09:06:29 --> Output Class Initialized
INFO - 2024-06-07 09:06:29 --> Security Class Initialized
DEBUG - 2024-06-07 09:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:06:29 --> Input Class Initialized
INFO - 2024-06-07 09:06:29 --> Language Class Initialized
INFO - 2024-06-07 09:06:29 --> Language Class Initialized
INFO - 2024-06-07 09:06:29 --> Config Class Initialized
INFO - 2024-06-07 09:06:29 --> Loader Class Initialized
INFO - 2024-06-07 09:06:29 --> Helper loaded: url_helper
INFO - 2024-06-07 09:06:29 --> Helper loaded: file_helper
INFO - 2024-06-07 09:06:29 --> Helper loaded: form_helper
INFO - 2024-06-07 09:06:29 --> Helper loaded: my_helper
INFO - 2024-06-07 09:06:29 --> Database Driver Class Initialized
INFO - 2024-06-07 09:06:32 --> Config Class Initialized
INFO - 2024-06-07 09:06:32 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:06:32 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:06:32 --> Utf8 Class Initialized
INFO - 2024-06-07 09:06:32 --> URI Class Initialized
INFO - 2024-06-07 09:06:32 --> Router Class Initialized
INFO - 2024-06-07 09:06:32 --> Output Class Initialized
INFO - 2024-06-07 09:06:32 --> Security Class Initialized
DEBUG - 2024-06-07 09:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:06:32 --> Input Class Initialized
INFO - 2024-06-07 09:06:32 --> Language Class Initialized
INFO - 2024-06-07 09:06:32 --> Language Class Initialized
INFO - 2024-06-07 09:06:32 --> Config Class Initialized
INFO - 2024-06-07 09:06:32 --> Loader Class Initialized
INFO - 2024-06-07 09:06:32 --> Helper loaded: url_helper
INFO - 2024-06-07 09:06:32 --> Helper loaded: file_helper
INFO - 2024-06-07 09:06:32 --> Helper loaded: form_helper
INFO - 2024-06-07 09:06:32 --> Helper loaded: my_helper
INFO - 2024-06-07 09:06:32 --> Database Driver Class Initialized
INFO - 2024-06-07 09:06:34 --> Final output sent to browser
DEBUG - 2024-06-07 09:06:34 --> Total execution time: 17.5806
INFO - 2024-06-07 09:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:06:34 --> Controller Class Initialized
DEBUG - 2024-06-07 09:06:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-07 09:06:36 --> Config Class Initialized
INFO - 2024-06-07 09:06:36 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:06:36 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:06:36 --> Utf8 Class Initialized
INFO - 2024-06-07 09:06:36 --> URI Class Initialized
INFO - 2024-06-07 09:06:36 --> Router Class Initialized
INFO - 2024-06-07 09:06:36 --> Output Class Initialized
INFO - 2024-06-07 09:06:36 --> Security Class Initialized
DEBUG - 2024-06-07 09:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:06:36 --> Input Class Initialized
INFO - 2024-06-07 09:06:36 --> Language Class Initialized
INFO - 2024-06-07 09:06:36 --> Language Class Initialized
INFO - 2024-06-07 09:06:36 --> Config Class Initialized
INFO - 2024-06-07 09:06:36 --> Loader Class Initialized
INFO - 2024-06-07 09:06:36 --> Helper loaded: url_helper
INFO - 2024-06-07 09:06:36 --> Helper loaded: file_helper
INFO - 2024-06-07 09:06:36 --> Helper loaded: form_helper
INFO - 2024-06-07 09:06:36 --> Helper loaded: my_helper
INFO - 2024-06-07 09:06:36 --> Database Driver Class Initialized
INFO - 2024-06-07 09:06:39 --> Config Class Initialized
INFO - 2024-06-07 09:06:39 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:06:39 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:06:39 --> Utf8 Class Initialized
INFO - 2024-06-07 09:06:39 --> URI Class Initialized
INFO - 2024-06-07 09:06:39 --> Router Class Initialized
INFO - 2024-06-07 09:06:39 --> Output Class Initialized
INFO - 2024-06-07 09:06:39 --> Security Class Initialized
DEBUG - 2024-06-07 09:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:06:39 --> Input Class Initialized
INFO - 2024-06-07 09:06:39 --> Language Class Initialized
INFO - 2024-06-07 09:06:39 --> Language Class Initialized
INFO - 2024-06-07 09:06:39 --> Config Class Initialized
INFO - 2024-06-07 09:06:39 --> Loader Class Initialized
INFO - 2024-06-07 09:06:39 --> Helper loaded: url_helper
INFO - 2024-06-07 09:06:39 --> Helper loaded: file_helper
INFO - 2024-06-07 09:06:39 --> Helper loaded: form_helper
INFO - 2024-06-07 09:06:39 --> Helper loaded: my_helper
INFO - 2024-06-07 09:06:39 --> Database Driver Class Initialized
INFO - 2024-06-07 09:06:39 --> Final output sent to browser
DEBUG - 2024-06-07 09:06:39 --> Total execution time: 19.6414
INFO - 2024-06-07 09:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:06:39 --> Controller Class Initialized
DEBUG - 2024-06-07 09:06:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-07 09:06:42 --> Config Class Initialized
INFO - 2024-06-07 09:06:42 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:06:42 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:06:42 --> Utf8 Class Initialized
INFO - 2024-06-07 09:06:42 --> URI Class Initialized
INFO - 2024-06-07 09:06:42 --> Router Class Initialized
INFO - 2024-06-07 09:06:42 --> Output Class Initialized
INFO - 2024-06-07 09:06:42 --> Security Class Initialized
DEBUG - 2024-06-07 09:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:06:42 --> Input Class Initialized
INFO - 2024-06-07 09:06:42 --> Language Class Initialized
INFO - 2024-06-07 09:06:42 --> Language Class Initialized
INFO - 2024-06-07 09:06:42 --> Config Class Initialized
INFO - 2024-06-07 09:06:42 --> Loader Class Initialized
INFO - 2024-06-07 09:06:42 --> Helper loaded: url_helper
INFO - 2024-06-07 09:06:42 --> Helper loaded: file_helper
INFO - 2024-06-07 09:06:42 --> Helper loaded: form_helper
INFO - 2024-06-07 09:06:42 --> Helper loaded: my_helper
INFO - 2024-06-07 09:06:42 --> Database Driver Class Initialized
INFO - 2024-06-07 09:06:44 --> Final output sent to browser
DEBUG - 2024-06-07 09:06:44 --> Total execution time: 21.7673
INFO - 2024-06-07 09:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:06:44 --> Controller Class Initialized
DEBUG - 2024-06-07 09:06:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-07 09:06:45 --> Config Class Initialized
INFO - 2024-06-07 09:06:45 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:06:45 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:06:45 --> Utf8 Class Initialized
INFO - 2024-06-07 09:06:45 --> URI Class Initialized
INFO - 2024-06-07 09:06:45 --> Router Class Initialized
INFO - 2024-06-07 09:06:45 --> Output Class Initialized
INFO - 2024-06-07 09:06:45 --> Security Class Initialized
DEBUG - 2024-06-07 09:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:06:45 --> Input Class Initialized
INFO - 2024-06-07 09:06:45 --> Language Class Initialized
INFO - 2024-06-07 09:06:45 --> Language Class Initialized
INFO - 2024-06-07 09:06:45 --> Config Class Initialized
INFO - 2024-06-07 09:06:45 --> Loader Class Initialized
INFO - 2024-06-07 09:06:45 --> Helper loaded: url_helper
INFO - 2024-06-07 09:06:45 --> Helper loaded: file_helper
INFO - 2024-06-07 09:06:45 --> Helper loaded: form_helper
INFO - 2024-06-07 09:06:45 --> Helper loaded: my_helper
INFO - 2024-06-07 09:06:45 --> Database Driver Class Initialized
INFO - 2024-06-07 09:06:48 --> Config Class Initialized
INFO - 2024-06-07 09:06:48 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:06:48 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:06:48 --> Utf8 Class Initialized
INFO - 2024-06-07 09:06:48 --> URI Class Initialized
INFO - 2024-06-07 09:06:48 --> Router Class Initialized
INFO - 2024-06-07 09:06:48 --> Output Class Initialized
INFO - 2024-06-07 09:06:48 --> Security Class Initialized
DEBUG - 2024-06-07 09:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:06:48 --> Input Class Initialized
INFO - 2024-06-07 09:06:48 --> Language Class Initialized
INFO - 2024-06-07 09:06:48 --> Language Class Initialized
INFO - 2024-06-07 09:06:48 --> Config Class Initialized
INFO - 2024-06-07 09:06:48 --> Loader Class Initialized
INFO - 2024-06-07 09:06:48 --> Helper loaded: url_helper
INFO - 2024-06-07 09:06:48 --> Helper loaded: file_helper
INFO - 2024-06-07 09:06:48 --> Helper loaded: form_helper
INFO - 2024-06-07 09:06:48 --> Helper loaded: my_helper
INFO - 2024-06-07 09:06:48 --> Database Driver Class Initialized
INFO - 2024-06-07 09:06:49 --> Final output sent to browser
DEBUG - 2024-06-07 09:06:49 --> Total execution time: 24.0067
INFO - 2024-06-07 09:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:06:49 --> Controller Class Initialized
DEBUG - 2024-06-07 09:06:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-07 09:06:55 --> Final output sent to browser
DEBUG - 2024-06-07 09:06:55 --> Total execution time: 25.9598
INFO - 2024-06-07 09:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:06:55 --> Controller Class Initialized
DEBUG - 2024-06-07 09:06:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-07 09:07:00 --> Final output sent to browser
DEBUG - 2024-06-07 09:07:00 --> Total execution time: 28.3399
INFO - 2024-06-07 09:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:07:00 --> Controller Class Initialized
DEBUG - 2024-06-07 09:07:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-07 09:07:06 --> Final output sent to browser
DEBUG - 2024-06-07 09:07:06 --> Total execution time: 29.4598
INFO - 2024-06-07 09:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:07:06 --> Controller Class Initialized
DEBUG - 2024-06-07 09:07:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-07 09:07:13 --> Final output sent to browser
DEBUG - 2024-06-07 09:07:13 --> Total execution time: 34.3574
INFO - 2024-06-07 09:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:07:13 --> Controller Class Initialized
DEBUG - 2024-06-07 09:07:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-07 09:07:19 --> Config Class Initialized
INFO - 2024-06-07 09:07:19 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:07:19 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:07:19 --> Utf8 Class Initialized
INFO - 2024-06-07 09:07:19 --> URI Class Initialized
INFO - 2024-06-07 09:07:19 --> Router Class Initialized
INFO - 2024-06-07 09:07:19 --> Output Class Initialized
INFO - 2024-06-07 09:07:19 --> Security Class Initialized
DEBUG - 2024-06-07 09:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:07:19 --> Input Class Initialized
INFO - 2024-06-07 09:07:19 --> Language Class Initialized
INFO - 2024-06-07 09:07:19 --> Language Class Initialized
INFO - 2024-06-07 09:07:19 --> Config Class Initialized
INFO - 2024-06-07 09:07:19 --> Loader Class Initialized
INFO - 2024-06-07 09:07:19 --> Helper loaded: url_helper
INFO - 2024-06-07 09:07:19 --> Helper loaded: file_helper
INFO - 2024-06-07 09:07:19 --> Helper loaded: form_helper
INFO - 2024-06-07 09:07:19 --> Helper loaded: my_helper
INFO - 2024-06-07 09:07:19 --> Database Driver Class Initialized
INFO - 2024-06-07 09:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:07:19 --> Controller Class Initialized
DEBUG - 2024-06-07 09:07:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-06-07 09:07:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 09:07:19 --> Final output sent to browser
DEBUG - 2024-06-07 09:07:19 --> Total execution time: 0.1754
INFO - 2024-06-07 09:07:20 --> Final output sent to browser
DEBUG - 2024-06-07 09:07:20 --> Total execution time: 37.8802
INFO - 2024-06-07 09:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:07:20 --> Controller Class Initialized
DEBUG - 2024-06-07 09:07:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-07 09:07:24 --> Final output sent to browser
DEBUG - 2024-06-07 09:07:24 --> Total execution time: 39.1588
INFO - 2024-06-07 09:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:07:24 --> Controller Class Initialized
DEBUG - 2024-06-07 09:07:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-07 09:07:29 --> Final output sent to browser
DEBUG - 2024-06-07 09:07:29 --> Total execution time: 40.8597
INFO - 2024-06-07 09:09:44 --> Config Class Initialized
INFO - 2024-06-07 09:09:44 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:09:44 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:09:44 --> Utf8 Class Initialized
INFO - 2024-06-07 09:09:44 --> URI Class Initialized
INFO - 2024-06-07 09:09:44 --> Router Class Initialized
INFO - 2024-06-07 09:09:44 --> Output Class Initialized
INFO - 2024-06-07 09:09:44 --> Security Class Initialized
DEBUG - 2024-06-07 09:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:09:44 --> Input Class Initialized
INFO - 2024-06-07 09:09:44 --> Language Class Initialized
INFO - 2024-06-07 09:09:44 --> Language Class Initialized
INFO - 2024-06-07 09:09:44 --> Config Class Initialized
INFO - 2024-06-07 09:09:44 --> Loader Class Initialized
INFO - 2024-06-07 09:09:44 --> Helper loaded: url_helper
INFO - 2024-06-07 09:09:44 --> Helper loaded: file_helper
INFO - 2024-06-07 09:09:44 --> Helper loaded: form_helper
INFO - 2024-06-07 09:09:44 --> Helper loaded: my_helper
INFO - 2024-06-07 09:09:44 --> Database Driver Class Initialized
INFO - 2024-06-07 09:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:09:44 --> Controller Class Initialized
DEBUG - 2024-06-07 09:09:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-07 09:09:47 --> Config Class Initialized
INFO - 2024-06-07 09:09:47 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:09:47 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:09:47 --> Utf8 Class Initialized
INFO - 2024-06-07 09:09:47 --> URI Class Initialized
INFO - 2024-06-07 09:09:47 --> Router Class Initialized
INFO - 2024-06-07 09:09:47 --> Output Class Initialized
INFO - 2024-06-07 09:09:47 --> Security Class Initialized
DEBUG - 2024-06-07 09:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:09:47 --> Input Class Initialized
INFO - 2024-06-07 09:09:47 --> Language Class Initialized
INFO - 2024-06-07 09:09:47 --> Language Class Initialized
INFO - 2024-06-07 09:09:47 --> Config Class Initialized
INFO - 2024-06-07 09:09:47 --> Loader Class Initialized
INFO - 2024-06-07 09:09:47 --> Helper loaded: url_helper
INFO - 2024-06-07 09:09:47 --> Helper loaded: file_helper
INFO - 2024-06-07 09:09:47 --> Helper loaded: form_helper
INFO - 2024-06-07 09:09:47 --> Helper loaded: my_helper
INFO - 2024-06-07 09:09:47 --> Database Driver Class Initialized
INFO - 2024-06-07 09:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:09:47 --> Controller Class Initialized
DEBUG - 2024-06-07 09:09:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-07 09:09:47 --> Final output sent to browser
DEBUG - 2024-06-07 09:09:47 --> Total execution time: 3.3749
INFO - 2024-06-07 09:09:50 --> Config Class Initialized
INFO - 2024-06-07 09:09:50 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:09:50 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:09:50 --> Utf8 Class Initialized
INFO - 2024-06-07 09:09:50 --> URI Class Initialized
INFO - 2024-06-07 09:09:50 --> Router Class Initialized
INFO - 2024-06-07 09:09:50 --> Output Class Initialized
INFO - 2024-06-07 09:09:50 --> Security Class Initialized
DEBUG - 2024-06-07 09:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:09:50 --> Input Class Initialized
INFO - 2024-06-07 09:09:50 --> Language Class Initialized
INFO - 2024-06-07 09:09:50 --> Language Class Initialized
INFO - 2024-06-07 09:09:50 --> Config Class Initialized
INFO - 2024-06-07 09:09:50 --> Loader Class Initialized
INFO - 2024-06-07 09:09:50 --> Helper loaded: url_helper
INFO - 2024-06-07 09:09:50 --> Helper loaded: file_helper
INFO - 2024-06-07 09:09:50 --> Helper loaded: form_helper
INFO - 2024-06-07 09:09:50 --> Helper loaded: my_helper
INFO - 2024-06-07 09:09:50 --> Database Driver Class Initialized
INFO - 2024-06-07 09:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:09:50 --> Controller Class Initialized
DEBUG - 2024-06-07 09:09:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-07 09:09:51 --> Final output sent to browser
DEBUG - 2024-06-07 09:09:51 --> Total execution time: 4.6061
INFO - 2024-06-07 09:09:53 --> Config Class Initialized
INFO - 2024-06-07 09:09:53 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:09:53 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:09:53 --> Utf8 Class Initialized
INFO - 2024-06-07 09:09:53 --> URI Class Initialized
INFO - 2024-06-07 09:09:53 --> Router Class Initialized
INFO - 2024-06-07 09:09:53 --> Output Class Initialized
INFO - 2024-06-07 09:09:53 --> Security Class Initialized
DEBUG - 2024-06-07 09:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:09:53 --> Input Class Initialized
INFO - 2024-06-07 09:09:53 --> Language Class Initialized
INFO - 2024-06-07 09:09:53 --> Language Class Initialized
INFO - 2024-06-07 09:09:53 --> Config Class Initialized
INFO - 2024-06-07 09:09:53 --> Loader Class Initialized
INFO - 2024-06-07 09:09:53 --> Helper loaded: url_helper
INFO - 2024-06-07 09:09:53 --> Helper loaded: file_helper
INFO - 2024-06-07 09:09:53 --> Helper loaded: form_helper
INFO - 2024-06-07 09:09:53 --> Helper loaded: my_helper
INFO - 2024-06-07 09:09:53 --> Database Driver Class Initialized
INFO - 2024-06-07 09:09:54 --> Final output sent to browser
DEBUG - 2024-06-07 09:09:54 --> Total execution time: 3.8791
INFO - 2024-06-07 09:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:09:54 --> Controller Class Initialized
DEBUG - 2024-06-07 09:09:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-07 09:09:55 --> Config Class Initialized
INFO - 2024-06-07 09:09:55 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:09:55 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:09:55 --> Utf8 Class Initialized
INFO - 2024-06-07 09:09:55 --> URI Class Initialized
INFO - 2024-06-07 09:09:55 --> Router Class Initialized
INFO - 2024-06-07 09:09:55 --> Output Class Initialized
INFO - 2024-06-07 09:09:55 --> Security Class Initialized
DEBUG - 2024-06-07 09:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:09:55 --> Input Class Initialized
INFO - 2024-06-07 09:09:55 --> Language Class Initialized
INFO - 2024-06-07 09:09:55 --> Language Class Initialized
INFO - 2024-06-07 09:09:55 --> Config Class Initialized
INFO - 2024-06-07 09:09:55 --> Loader Class Initialized
INFO - 2024-06-07 09:09:55 --> Helper loaded: url_helper
INFO - 2024-06-07 09:09:55 --> Helper loaded: file_helper
INFO - 2024-06-07 09:09:55 --> Helper loaded: form_helper
INFO - 2024-06-07 09:09:55 --> Helper loaded: my_helper
INFO - 2024-06-07 09:09:55 --> Database Driver Class Initialized
INFO - 2024-06-07 09:09:57 --> Final output sent to browser
DEBUG - 2024-06-07 09:09:57 --> Total execution time: 4.4124
INFO - 2024-06-07 09:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:09:57 --> Controller Class Initialized
DEBUG - 2024-06-07 09:09:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-07 09:09:58 --> Config Class Initialized
INFO - 2024-06-07 09:09:58 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:09:58 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:09:58 --> Utf8 Class Initialized
INFO - 2024-06-07 09:09:58 --> URI Class Initialized
INFO - 2024-06-07 09:09:58 --> Router Class Initialized
INFO - 2024-06-07 09:09:58 --> Output Class Initialized
INFO - 2024-06-07 09:09:58 --> Security Class Initialized
DEBUG - 2024-06-07 09:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:09:58 --> Input Class Initialized
INFO - 2024-06-07 09:09:58 --> Language Class Initialized
INFO - 2024-06-07 09:09:58 --> Language Class Initialized
INFO - 2024-06-07 09:09:58 --> Config Class Initialized
INFO - 2024-06-07 09:09:58 --> Loader Class Initialized
INFO - 2024-06-07 09:09:58 --> Helper loaded: url_helper
INFO - 2024-06-07 09:09:58 --> Helper loaded: file_helper
INFO - 2024-06-07 09:09:58 --> Helper loaded: form_helper
INFO - 2024-06-07 09:09:58 --> Helper loaded: my_helper
INFO - 2024-06-07 09:09:58 --> Database Driver Class Initialized
INFO - 2024-06-07 09:10:00 --> Config Class Initialized
INFO - 2024-06-07 09:10:00 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:10:00 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:10:00 --> Utf8 Class Initialized
INFO - 2024-06-07 09:10:00 --> URI Class Initialized
INFO - 2024-06-07 09:10:00 --> Router Class Initialized
INFO - 2024-06-07 09:10:00 --> Output Class Initialized
INFO - 2024-06-07 09:10:00 --> Security Class Initialized
DEBUG - 2024-06-07 09:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:10:00 --> Input Class Initialized
INFO - 2024-06-07 09:10:00 --> Language Class Initialized
INFO - 2024-06-07 09:10:00 --> Language Class Initialized
INFO - 2024-06-07 09:10:00 --> Config Class Initialized
INFO - 2024-06-07 09:10:00 --> Loader Class Initialized
INFO - 2024-06-07 09:10:00 --> Helper loaded: url_helper
INFO - 2024-06-07 09:10:00 --> Helper loaded: file_helper
INFO - 2024-06-07 09:10:00 --> Helper loaded: form_helper
INFO - 2024-06-07 09:10:00 --> Helper loaded: my_helper
INFO - 2024-06-07 09:10:00 --> Database Driver Class Initialized
INFO - 2024-06-07 09:10:02 --> Final output sent to browser
DEBUG - 2024-06-07 09:10:02 --> Total execution time: 6.7642
INFO - 2024-06-07 09:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:10:02 --> Controller Class Initialized
DEBUG - 2024-06-07 09:10:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-07 09:10:02 --> Config Class Initialized
INFO - 2024-06-07 09:10:02 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:10:02 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:10:02 --> Utf8 Class Initialized
INFO - 2024-06-07 09:10:02 --> URI Class Initialized
INFO - 2024-06-07 09:10:02 --> Router Class Initialized
INFO - 2024-06-07 09:10:02 --> Output Class Initialized
INFO - 2024-06-07 09:10:02 --> Security Class Initialized
DEBUG - 2024-06-07 09:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:10:02 --> Input Class Initialized
INFO - 2024-06-07 09:10:02 --> Language Class Initialized
INFO - 2024-06-07 09:10:02 --> Language Class Initialized
INFO - 2024-06-07 09:10:02 --> Config Class Initialized
INFO - 2024-06-07 09:10:02 --> Loader Class Initialized
INFO - 2024-06-07 09:10:02 --> Helper loaded: url_helper
INFO - 2024-06-07 09:10:02 --> Helper loaded: file_helper
INFO - 2024-06-07 09:10:02 --> Helper loaded: form_helper
INFO - 2024-06-07 09:10:02 --> Helper loaded: my_helper
INFO - 2024-06-07 09:10:02 --> Database Driver Class Initialized
INFO - 2024-06-07 09:10:05 --> Config Class Initialized
INFO - 2024-06-07 09:10:05 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:10:05 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:10:05 --> Utf8 Class Initialized
INFO - 2024-06-07 09:10:05 --> URI Class Initialized
INFO - 2024-06-07 09:10:05 --> Router Class Initialized
INFO - 2024-06-07 09:10:05 --> Output Class Initialized
INFO - 2024-06-07 09:10:05 --> Security Class Initialized
DEBUG - 2024-06-07 09:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:10:05 --> Input Class Initialized
INFO - 2024-06-07 09:10:05 --> Language Class Initialized
INFO - 2024-06-07 09:10:05 --> Language Class Initialized
INFO - 2024-06-07 09:10:05 --> Config Class Initialized
INFO - 2024-06-07 09:10:05 --> Loader Class Initialized
INFO - 2024-06-07 09:10:05 --> Helper loaded: url_helper
INFO - 2024-06-07 09:10:05 --> Helper loaded: file_helper
INFO - 2024-06-07 09:10:05 --> Helper loaded: form_helper
INFO - 2024-06-07 09:10:05 --> Helper loaded: my_helper
INFO - 2024-06-07 09:10:05 --> Database Driver Class Initialized
INFO - 2024-06-07 09:10:06 --> Final output sent to browser
DEBUG - 2024-06-07 09:10:06 --> Total execution time: 8.1890
INFO - 2024-06-07 09:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:10:06 --> Controller Class Initialized
DEBUG - 2024-06-07 09:10:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-07 09:10:07 --> Config Class Initialized
INFO - 2024-06-07 09:10:07 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:10:07 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:10:07 --> Utf8 Class Initialized
INFO - 2024-06-07 09:10:07 --> URI Class Initialized
INFO - 2024-06-07 09:10:07 --> Router Class Initialized
INFO - 2024-06-07 09:10:07 --> Output Class Initialized
INFO - 2024-06-07 09:10:07 --> Security Class Initialized
DEBUG - 2024-06-07 09:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:10:07 --> Input Class Initialized
INFO - 2024-06-07 09:10:07 --> Language Class Initialized
INFO - 2024-06-07 09:10:07 --> Language Class Initialized
INFO - 2024-06-07 09:10:07 --> Config Class Initialized
INFO - 2024-06-07 09:10:07 --> Loader Class Initialized
INFO - 2024-06-07 09:10:07 --> Helper loaded: url_helper
INFO - 2024-06-07 09:10:07 --> Helper loaded: file_helper
INFO - 2024-06-07 09:10:07 --> Helper loaded: form_helper
INFO - 2024-06-07 09:10:07 --> Helper loaded: my_helper
INFO - 2024-06-07 09:10:07 --> Database Driver Class Initialized
INFO - 2024-06-07 09:10:09 --> Final output sent to browser
DEBUG - 2024-06-07 09:10:09 --> Total execution time: 9.2947
INFO - 2024-06-07 09:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:10:09 --> Controller Class Initialized
DEBUG - 2024-06-07 09:10:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-07 09:10:11 --> Config Class Initialized
INFO - 2024-06-07 09:10:11 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:10:11 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:10:11 --> Utf8 Class Initialized
INFO - 2024-06-07 09:10:11 --> URI Class Initialized
INFO - 2024-06-07 09:10:11 --> Router Class Initialized
INFO - 2024-06-07 09:10:11 --> Output Class Initialized
INFO - 2024-06-07 09:10:11 --> Security Class Initialized
DEBUG - 2024-06-07 09:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:10:11 --> Input Class Initialized
INFO - 2024-06-07 09:10:11 --> Language Class Initialized
INFO - 2024-06-07 09:10:11 --> Language Class Initialized
INFO - 2024-06-07 09:10:11 --> Config Class Initialized
INFO - 2024-06-07 09:10:11 --> Loader Class Initialized
INFO - 2024-06-07 09:10:11 --> Helper loaded: url_helper
INFO - 2024-06-07 09:10:11 --> Helper loaded: file_helper
INFO - 2024-06-07 09:10:11 --> Helper loaded: form_helper
INFO - 2024-06-07 09:10:11 --> Helper loaded: my_helper
INFO - 2024-06-07 09:10:11 --> Database Driver Class Initialized
INFO - 2024-06-07 09:10:13 --> Final output sent to browser
DEBUG - 2024-06-07 09:10:13 --> Total execution time: 10.5028
INFO - 2024-06-07 09:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:10:13 --> Controller Class Initialized
DEBUG - 2024-06-07 09:10:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-07 09:10:16 --> Final output sent to browser
DEBUG - 2024-06-07 09:10:16 --> Total execution time: 11.4590
INFO - 2024-06-07 09:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:10:16 --> Controller Class Initialized
DEBUG - 2024-06-07 09:10:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-07 09:10:19 --> Final output sent to browser
DEBUG - 2024-06-07 09:10:19 --> Total execution time: 12.1528
INFO - 2024-06-07 09:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:10:19 --> Controller Class Initialized
DEBUG - 2024-06-07 09:10:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-07 09:10:22 --> Final output sent to browser
DEBUG - 2024-06-07 09:10:22 --> Total execution time: 11.3758
INFO - 2024-06-07 09:11:38 --> Config Class Initialized
INFO - 2024-06-07 09:11:38 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:11:38 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:11:38 --> Utf8 Class Initialized
INFO - 2024-06-07 09:11:38 --> URI Class Initialized
INFO - 2024-06-07 09:11:38 --> Router Class Initialized
INFO - 2024-06-07 09:11:38 --> Output Class Initialized
INFO - 2024-06-07 09:11:38 --> Security Class Initialized
DEBUG - 2024-06-07 09:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:11:38 --> Input Class Initialized
INFO - 2024-06-07 09:11:38 --> Language Class Initialized
INFO - 2024-06-07 09:11:38 --> Language Class Initialized
INFO - 2024-06-07 09:11:38 --> Config Class Initialized
INFO - 2024-06-07 09:11:38 --> Loader Class Initialized
INFO - 2024-06-07 09:11:38 --> Helper loaded: url_helper
INFO - 2024-06-07 09:11:38 --> Helper loaded: file_helper
INFO - 2024-06-07 09:11:38 --> Helper loaded: form_helper
INFO - 2024-06-07 09:11:38 --> Helper loaded: my_helper
INFO - 2024-06-07 09:11:38 --> Database Driver Class Initialized
INFO - 2024-06-07 09:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:11:38 --> Controller Class Initialized
INFO - 2024-06-07 09:11:38 --> Helper loaded: cookie_helper
INFO - 2024-06-07 09:11:38 --> Config Class Initialized
INFO - 2024-06-07 09:11:38 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:11:38 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:11:38 --> Utf8 Class Initialized
INFO - 2024-06-07 09:11:38 --> URI Class Initialized
INFO - 2024-06-07 09:11:38 --> Router Class Initialized
INFO - 2024-06-07 09:11:38 --> Output Class Initialized
INFO - 2024-06-07 09:11:38 --> Security Class Initialized
DEBUG - 2024-06-07 09:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:11:38 --> Input Class Initialized
INFO - 2024-06-07 09:11:38 --> Language Class Initialized
INFO - 2024-06-07 09:11:38 --> Language Class Initialized
INFO - 2024-06-07 09:11:38 --> Config Class Initialized
INFO - 2024-06-07 09:11:38 --> Loader Class Initialized
INFO - 2024-06-07 09:11:38 --> Helper loaded: url_helper
INFO - 2024-06-07 09:11:38 --> Helper loaded: file_helper
INFO - 2024-06-07 09:11:38 --> Helper loaded: form_helper
INFO - 2024-06-07 09:11:38 --> Helper loaded: my_helper
INFO - 2024-06-07 09:11:38 --> Database Driver Class Initialized
INFO - 2024-06-07 09:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:11:38 --> Controller Class Initialized
INFO - 2024-06-07 09:11:38 --> Config Class Initialized
INFO - 2024-06-07 09:11:38 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:11:38 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:11:38 --> Utf8 Class Initialized
INFO - 2024-06-07 09:11:38 --> URI Class Initialized
INFO - 2024-06-07 09:11:38 --> Router Class Initialized
INFO - 2024-06-07 09:11:38 --> Output Class Initialized
INFO - 2024-06-07 09:11:38 --> Security Class Initialized
DEBUG - 2024-06-07 09:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:11:38 --> Input Class Initialized
INFO - 2024-06-07 09:11:38 --> Language Class Initialized
INFO - 2024-06-07 09:11:38 --> Language Class Initialized
INFO - 2024-06-07 09:11:38 --> Config Class Initialized
INFO - 2024-06-07 09:11:38 --> Loader Class Initialized
INFO - 2024-06-07 09:11:38 --> Helper loaded: url_helper
INFO - 2024-06-07 09:11:38 --> Helper loaded: file_helper
INFO - 2024-06-07 09:11:38 --> Helper loaded: form_helper
INFO - 2024-06-07 09:11:38 --> Helper loaded: my_helper
INFO - 2024-06-07 09:11:38 --> Database Driver Class Initialized
INFO - 2024-06-07 09:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:11:38 --> Controller Class Initialized
DEBUG - 2024-06-07 09:11:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-07 09:11:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 09:11:38 --> Final output sent to browser
DEBUG - 2024-06-07 09:11:38 --> Total execution time: 0.0303
INFO - 2024-06-07 09:11:43 --> Config Class Initialized
INFO - 2024-06-07 09:11:43 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:11:43 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:11:43 --> Utf8 Class Initialized
INFO - 2024-06-07 09:11:43 --> URI Class Initialized
INFO - 2024-06-07 09:11:43 --> Router Class Initialized
INFO - 2024-06-07 09:11:43 --> Output Class Initialized
INFO - 2024-06-07 09:11:43 --> Security Class Initialized
DEBUG - 2024-06-07 09:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:11:43 --> Input Class Initialized
INFO - 2024-06-07 09:11:43 --> Language Class Initialized
INFO - 2024-06-07 09:11:43 --> Language Class Initialized
INFO - 2024-06-07 09:11:43 --> Config Class Initialized
INFO - 2024-06-07 09:11:43 --> Loader Class Initialized
INFO - 2024-06-07 09:11:43 --> Helper loaded: url_helper
INFO - 2024-06-07 09:11:43 --> Helper loaded: file_helper
INFO - 2024-06-07 09:11:43 --> Helper loaded: form_helper
INFO - 2024-06-07 09:11:43 --> Helper loaded: my_helper
INFO - 2024-06-07 09:11:43 --> Database Driver Class Initialized
INFO - 2024-06-07 09:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:11:43 --> Controller Class Initialized
INFO - 2024-06-07 09:11:43 --> Helper loaded: cookie_helper
INFO - 2024-06-07 09:11:43 --> Final output sent to browser
DEBUG - 2024-06-07 09:11:43 --> Total execution time: 0.0336
INFO - 2024-06-07 09:11:43 --> Config Class Initialized
INFO - 2024-06-07 09:11:43 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:11:43 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:11:43 --> Utf8 Class Initialized
INFO - 2024-06-07 09:11:43 --> URI Class Initialized
INFO - 2024-06-07 09:11:43 --> Router Class Initialized
INFO - 2024-06-07 09:11:43 --> Output Class Initialized
INFO - 2024-06-07 09:11:43 --> Security Class Initialized
DEBUG - 2024-06-07 09:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:11:43 --> Input Class Initialized
INFO - 2024-06-07 09:11:43 --> Language Class Initialized
INFO - 2024-06-07 09:11:43 --> Language Class Initialized
INFO - 2024-06-07 09:11:43 --> Config Class Initialized
INFO - 2024-06-07 09:11:43 --> Loader Class Initialized
INFO - 2024-06-07 09:11:43 --> Helper loaded: url_helper
INFO - 2024-06-07 09:11:43 --> Helper loaded: file_helper
INFO - 2024-06-07 09:11:43 --> Helper loaded: form_helper
INFO - 2024-06-07 09:11:43 --> Helper loaded: my_helper
INFO - 2024-06-07 09:11:43 --> Database Driver Class Initialized
INFO - 2024-06-07 09:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:11:43 --> Controller Class Initialized
DEBUG - 2024-06-07 09:11:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-06-07 09:11:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 09:11:43 --> Final output sent to browser
DEBUG - 2024-06-07 09:11:43 --> Total execution time: 0.0266
INFO - 2024-06-07 09:11:48 --> Config Class Initialized
INFO - 2024-06-07 09:11:48 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:11:48 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:11:48 --> Utf8 Class Initialized
INFO - 2024-06-07 09:11:48 --> URI Class Initialized
INFO - 2024-06-07 09:11:48 --> Router Class Initialized
INFO - 2024-06-07 09:11:48 --> Output Class Initialized
INFO - 2024-06-07 09:11:48 --> Security Class Initialized
DEBUG - 2024-06-07 09:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:11:48 --> Input Class Initialized
INFO - 2024-06-07 09:11:48 --> Language Class Initialized
INFO - 2024-06-07 09:11:48 --> Language Class Initialized
INFO - 2024-06-07 09:11:48 --> Config Class Initialized
INFO - 2024-06-07 09:11:48 --> Loader Class Initialized
INFO - 2024-06-07 09:11:48 --> Helper loaded: url_helper
INFO - 2024-06-07 09:11:48 --> Helper loaded: file_helper
INFO - 2024-06-07 09:11:48 --> Helper loaded: form_helper
INFO - 2024-06-07 09:11:48 --> Helper loaded: my_helper
INFO - 2024-06-07 09:11:48 --> Database Driver Class Initialized
INFO - 2024-06-07 09:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:11:48 --> Controller Class Initialized
DEBUG - 2024-06-07 09:11:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-06-07 09:11:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 09:11:48 --> Final output sent to browser
DEBUG - 2024-06-07 09:11:48 --> Total execution time: 0.0288
INFO - 2024-06-07 09:11:48 --> Config Class Initialized
INFO - 2024-06-07 09:11:48 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:11:48 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:11:48 --> Utf8 Class Initialized
INFO - 2024-06-07 09:11:48 --> URI Class Initialized
INFO - 2024-06-07 09:11:48 --> Router Class Initialized
INFO - 2024-06-07 09:11:48 --> Output Class Initialized
INFO - 2024-06-07 09:11:48 --> Security Class Initialized
DEBUG - 2024-06-07 09:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:11:48 --> Input Class Initialized
INFO - 2024-06-07 09:11:48 --> Language Class Initialized
ERROR - 2024-06-07 09:11:48 --> 404 Page Not Found: /index
INFO - 2024-06-07 09:11:48 --> Config Class Initialized
INFO - 2024-06-07 09:11:48 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:11:48 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:11:48 --> Utf8 Class Initialized
INFO - 2024-06-07 09:11:48 --> URI Class Initialized
INFO - 2024-06-07 09:11:48 --> Router Class Initialized
INFO - 2024-06-07 09:11:48 --> Output Class Initialized
INFO - 2024-06-07 09:11:48 --> Security Class Initialized
DEBUG - 2024-06-07 09:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:11:48 --> Input Class Initialized
INFO - 2024-06-07 09:11:48 --> Language Class Initialized
INFO - 2024-06-07 09:11:48 --> Language Class Initialized
INFO - 2024-06-07 09:11:48 --> Config Class Initialized
INFO - 2024-06-07 09:11:48 --> Loader Class Initialized
INFO - 2024-06-07 09:11:48 --> Helper loaded: url_helper
INFO - 2024-06-07 09:11:48 --> Helper loaded: file_helper
INFO - 2024-06-07 09:11:48 --> Helper loaded: form_helper
INFO - 2024-06-07 09:11:48 --> Helper loaded: my_helper
INFO - 2024-06-07 09:11:48 --> Database Driver Class Initialized
INFO - 2024-06-07 09:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:11:48 --> Controller Class Initialized
INFO - 2024-06-07 09:11:50 --> Config Class Initialized
INFO - 2024-06-07 09:11:50 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:11:50 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:11:50 --> Utf8 Class Initialized
INFO - 2024-06-07 09:11:50 --> URI Class Initialized
INFO - 2024-06-07 09:11:50 --> Router Class Initialized
INFO - 2024-06-07 09:11:50 --> Output Class Initialized
INFO - 2024-06-07 09:11:50 --> Security Class Initialized
DEBUG - 2024-06-07 09:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:11:50 --> Input Class Initialized
INFO - 2024-06-07 09:11:50 --> Language Class Initialized
INFO - 2024-06-07 09:11:50 --> Language Class Initialized
INFO - 2024-06-07 09:11:50 --> Config Class Initialized
INFO - 2024-06-07 09:11:50 --> Loader Class Initialized
INFO - 2024-06-07 09:11:50 --> Helper loaded: url_helper
INFO - 2024-06-07 09:11:50 --> Helper loaded: file_helper
INFO - 2024-06-07 09:11:50 --> Helper loaded: form_helper
INFO - 2024-06-07 09:11:50 --> Helper loaded: my_helper
INFO - 2024-06-07 09:11:50 --> Database Driver Class Initialized
INFO - 2024-06-07 09:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:11:50 --> Controller Class Initialized
INFO - 2024-06-07 09:11:50 --> Final output sent to browser
DEBUG - 2024-06-07 09:11:50 --> Total execution time: 0.0418
INFO - 2024-06-07 09:11:50 --> Config Class Initialized
INFO - 2024-06-07 09:11:50 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:11:50 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:11:50 --> Utf8 Class Initialized
INFO - 2024-06-07 09:11:50 --> URI Class Initialized
INFO - 2024-06-07 09:11:50 --> Router Class Initialized
INFO - 2024-06-07 09:11:50 --> Output Class Initialized
INFO - 2024-06-07 09:11:50 --> Security Class Initialized
DEBUG - 2024-06-07 09:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:11:50 --> Input Class Initialized
INFO - 2024-06-07 09:11:50 --> Language Class Initialized
ERROR - 2024-06-07 09:11:50 --> 404 Page Not Found: /index
INFO - 2024-06-07 09:11:50 --> Config Class Initialized
INFO - 2024-06-07 09:11:50 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:11:50 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:11:50 --> Utf8 Class Initialized
INFO - 2024-06-07 09:11:50 --> URI Class Initialized
INFO - 2024-06-07 09:11:50 --> Router Class Initialized
INFO - 2024-06-07 09:11:50 --> Output Class Initialized
INFO - 2024-06-07 09:11:50 --> Security Class Initialized
DEBUG - 2024-06-07 09:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:11:50 --> Input Class Initialized
INFO - 2024-06-07 09:11:50 --> Language Class Initialized
INFO - 2024-06-07 09:11:50 --> Language Class Initialized
INFO - 2024-06-07 09:11:50 --> Config Class Initialized
INFO - 2024-06-07 09:11:50 --> Loader Class Initialized
INFO - 2024-06-07 09:11:50 --> Helper loaded: url_helper
INFO - 2024-06-07 09:11:50 --> Helper loaded: file_helper
INFO - 2024-06-07 09:11:50 --> Helper loaded: form_helper
INFO - 2024-06-07 09:11:50 --> Helper loaded: my_helper
INFO - 2024-06-07 09:11:50 --> Database Driver Class Initialized
INFO - 2024-06-07 09:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:11:50 --> Controller Class Initialized
INFO - 2024-06-07 09:37:03 --> Config Class Initialized
INFO - 2024-06-07 09:37:03 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:37:03 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:37:03 --> Utf8 Class Initialized
INFO - 2024-06-07 09:37:03 --> URI Class Initialized
INFO - 2024-06-07 09:37:03 --> Router Class Initialized
INFO - 2024-06-07 09:37:03 --> Output Class Initialized
INFO - 2024-06-07 09:37:03 --> Security Class Initialized
DEBUG - 2024-06-07 09:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:37:03 --> Input Class Initialized
INFO - 2024-06-07 09:37:03 --> Language Class Initialized
INFO - 2024-06-07 09:37:03 --> Language Class Initialized
INFO - 2024-06-07 09:37:03 --> Config Class Initialized
INFO - 2024-06-07 09:37:03 --> Loader Class Initialized
INFO - 2024-06-07 09:37:03 --> Helper loaded: url_helper
INFO - 2024-06-07 09:37:03 --> Helper loaded: file_helper
INFO - 2024-06-07 09:37:03 --> Helper loaded: form_helper
INFO - 2024-06-07 09:37:03 --> Helper loaded: my_helper
INFO - 2024-06-07 09:37:03 --> Database Driver Class Initialized
INFO - 2024-06-07 09:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:37:03 --> Controller Class Initialized
DEBUG - 2024-06-07 09:37:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-06-07 09:37:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 09:37:03 --> Final output sent to browser
DEBUG - 2024-06-07 09:37:03 --> Total execution time: 0.0563
INFO - 2024-06-07 09:37:06 --> Config Class Initialized
INFO - 2024-06-07 09:37:06 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:37:06 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:37:06 --> Utf8 Class Initialized
INFO - 2024-06-07 09:37:06 --> URI Class Initialized
INFO - 2024-06-07 09:37:06 --> Router Class Initialized
INFO - 2024-06-07 09:37:06 --> Output Class Initialized
INFO - 2024-06-07 09:37:06 --> Security Class Initialized
DEBUG - 2024-06-07 09:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:37:06 --> Input Class Initialized
INFO - 2024-06-07 09:37:06 --> Language Class Initialized
INFO - 2024-06-07 09:37:06 --> Language Class Initialized
INFO - 2024-06-07 09:37:06 --> Config Class Initialized
INFO - 2024-06-07 09:37:06 --> Loader Class Initialized
INFO - 2024-06-07 09:37:06 --> Helper loaded: url_helper
INFO - 2024-06-07 09:37:06 --> Helper loaded: file_helper
INFO - 2024-06-07 09:37:06 --> Helper loaded: form_helper
INFO - 2024-06-07 09:37:06 --> Helper loaded: my_helper
INFO - 2024-06-07 09:37:06 --> Database Driver Class Initialized
INFO - 2024-06-07 09:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:37:06 --> Controller Class Initialized
DEBUG - 2024-06-07 09:37:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-06-07 09:37:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 09:37:06 --> Final output sent to browser
DEBUG - 2024-06-07 09:37:06 --> Total execution time: 0.0790
INFO - 2024-06-07 09:37:19 --> Config Class Initialized
INFO - 2024-06-07 09:37:19 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:37:19 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:37:19 --> Utf8 Class Initialized
INFO - 2024-06-07 09:37:19 --> URI Class Initialized
INFO - 2024-06-07 09:37:19 --> Router Class Initialized
INFO - 2024-06-07 09:37:19 --> Output Class Initialized
INFO - 2024-06-07 09:37:19 --> Security Class Initialized
DEBUG - 2024-06-07 09:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:37:19 --> Input Class Initialized
INFO - 2024-06-07 09:37:19 --> Language Class Initialized
INFO - 2024-06-07 09:37:19 --> Language Class Initialized
INFO - 2024-06-07 09:37:19 --> Config Class Initialized
INFO - 2024-06-07 09:37:19 --> Loader Class Initialized
INFO - 2024-06-07 09:37:19 --> Helper loaded: url_helper
INFO - 2024-06-07 09:37:19 --> Helper loaded: file_helper
INFO - 2024-06-07 09:37:19 --> Helper loaded: form_helper
INFO - 2024-06-07 09:37:19 --> Helper loaded: my_helper
INFO - 2024-06-07 09:37:19 --> Database Driver Class Initialized
INFO - 2024-06-07 09:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:37:19 --> Controller Class Initialized
INFO - 2024-06-07 09:37:19 --> Config Class Initialized
INFO - 2024-06-07 09:37:19 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:37:19 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:37:19 --> Utf8 Class Initialized
INFO - 2024-06-07 09:37:19 --> URI Class Initialized
INFO - 2024-06-07 09:37:19 --> Router Class Initialized
INFO - 2024-06-07 09:37:19 --> Output Class Initialized
INFO - 2024-06-07 09:37:19 --> Security Class Initialized
DEBUG - 2024-06-07 09:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:37:19 --> Input Class Initialized
INFO - 2024-06-07 09:37:19 --> Language Class Initialized
INFO - 2024-06-07 09:37:19 --> Language Class Initialized
INFO - 2024-06-07 09:37:19 --> Config Class Initialized
INFO - 2024-06-07 09:37:19 --> Loader Class Initialized
INFO - 2024-06-07 09:37:19 --> Helper loaded: url_helper
INFO - 2024-06-07 09:37:19 --> Helper loaded: file_helper
INFO - 2024-06-07 09:37:19 --> Helper loaded: form_helper
INFO - 2024-06-07 09:37:19 --> Helper loaded: my_helper
INFO - 2024-06-07 09:37:19 --> Database Driver Class Initialized
INFO - 2024-06-07 09:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:37:19 --> Controller Class Initialized
DEBUG - 2024-06-07 09:37:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-07 09:37:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 09:37:19 --> Final output sent to browser
DEBUG - 2024-06-07 09:37:19 --> Total execution time: 0.0322
INFO - 2024-06-07 09:37:19 --> Config Class Initialized
INFO - 2024-06-07 09:37:19 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:37:19 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:37:19 --> Utf8 Class Initialized
INFO - 2024-06-07 09:37:19 --> URI Class Initialized
INFO - 2024-06-07 09:37:19 --> Router Class Initialized
INFO - 2024-06-07 09:37:19 --> Output Class Initialized
INFO - 2024-06-07 09:37:19 --> Security Class Initialized
DEBUG - 2024-06-07 09:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:37:19 --> Input Class Initialized
INFO - 2024-06-07 09:37:19 --> Language Class Initialized
INFO - 2024-06-07 09:37:19 --> Language Class Initialized
INFO - 2024-06-07 09:37:19 --> Config Class Initialized
INFO - 2024-06-07 09:37:19 --> Loader Class Initialized
INFO - 2024-06-07 09:37:19 --> Helper loaded: url_helper
INFO - 2024-06-07 09:37:19 --> Helper loaded: file_helper
INFO - 2024-06-07 09:37:19 --> Helper loaded: form_helper
INFO - 2024-06-07 09:37:19 --> Helper loaded: my_helper
INFO - 2024-06-07 09:37:19 --> Database Driver Class Initialized
INFO - 2024-06-07 09:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:37:19 --> Controller Class Initialized
INFO - 2024-06-07 09:37:27 --> Config Class Initialized
INFO - 2024-06-07 09:37:27 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:37:27 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:37:27 --> Utf8 Class Initialized
INFO - 2024-06-07 09:37:27 --> URI Class Initialized
INFO - 2024-06-07 09:37:27 --> Router Class Initialized
INFO - 2024-06-07 09:37:27 --> Output Class Initialized
INFO - 2024-06-07 09:37:27 --> Security Class Initialized
DEBUG - 2024-06-07 09:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:37:27 --> Input Class Initialized
INFO - 2024-06-07 09:37:27 --> Language Class Initialized
INFO - 2024-06-07 09:37:27 --> Language Class Initialized
INFO - 2024-06-07 09:37:27 --> Config Class Initialized
INFO - 2024-06-07 09:37:27 --> Loader Class Initialized
INFO - 2024-06-07 09:37:27 --> Helper loaded: url_helper
INFO - 2024-06-07 09:37:27 --> Helper loaded: file_helper
INFO - 2024-06-07 09:37:27 --> Helper loaded: form_helper
INFO - 2024-06-07 09:37:27 --> Helper loaded: my_helper
INFO - 2024-06-07 09:37:27 --> Database Driver Class Initialized
INFO - 2024-06-07 09:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:37:27 --> Controller Class Initialized
INFO - 2024-06-07 09:37:27 --> Final output sent to browser
DEBUG - 2024-06-07 09:37:27 --> Total execution time: 0.0314
INFO - 2024-06-07 09:38:51 --> Config Class Initialized
INFO - 2024-06-07 09:38:51 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:38:51 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:38:51 --> Utf8 Class Initialized
INFO - 2024-06-07 09:38:51 --> URI Class Initialized
INFO - 2024-06-07 09:38:51 --> Router Class Initialized
INFO - 2024-06-07 09:38:51 --> Output Class Initialized
INFO - 2024-06-07 09:38:51 --> Security Class Initialized
DEBUG - 2024-06-07 09:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:38:51 --> Input Class Initialized
INFO - 2024-06-07 09:38:51 --> Language Class Initialized
INFO - 2024-06-07 09:38:51 --> Language Class Initialized
INFO - 2024-06-07 09:38:51 --> Config Class Initialized
INFO - 2024-06-07 09:38:51 --> Loader Class Initialized
INFO - 2024-06-07 09:38:51 --> Helper loaded: url_helper
INFO - 2024-06-07 09:38:51 --> Helper loaded: file_helper
INFO - 2024-06-07 09:38:51 --> Helper loaded: form_helper
INFO - 2024-06-07 09:38:51 --> Helper loaded: my_helper
INFO - 2024-06-07 09:38:51 --> Database Driver Class Initialized
INFO - 2024-06-07 09:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:38:51 --> Controller Class Initialized
INFO - 2024-06-07 09:38:51 --> Final output sent to browser
DEBUG - 2024-06-07 09:38:51 --> Total execution time: 0.0595
INFO - 2024-06-07 09:38:57 --> Config Class Initialized
INFO - 2024-06-07 09:38:57 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:38:57 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:38:57 --> Utf8 Class Initialized
INFO - 2024-06-07 09:38:57 --> URI Class Initialized
INFO - 2024-06-07 09:38:57 --> Router Class Initialized
INFO - 2024-06-07 09:38:57 --> Output Class Initialized
INFO - 2024-06-07 09:38:57 --> Security Class Initialized
DEBUG - 2024-06-07 09:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:38:57 --> Input Class Initialized
INFO - 2024-06-07 09:38:57 --> Language Class Initialized
INFO - 2024-06-07 09:38:57 --> Language Class Initialized
INFO - 2024-06-07 09:38:57 --> Config Class Initialized
INFO - 2024-06-07 09:38:57 --> Loader Class Initialized
INFO - 2024-06-07 09:38:57 --> Helper loaded: url_helper
INFO - 2024-06-07 09:38:57 --> Helper loaded: file_helper
INFO - 2024-06-07 09:38:57 --> Helper loaded: form_helper
INFO - 2024-06-07 09:38:57 --> Helper loaded: my_helper
INFO - 2024-06-07 09:38:57 --> Database Driver Class Initialized
INFO - 2024-06-07 09:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:38:57 --> Controller Class Initialized
INFO - 2024-06-07 09:38:57 --> Final output sent to browser
DEBUG - 2024-06-07 09:38:57 --> Total execution time: 0.0277
INFO - 2024-06-07 09:39:05 --> Config Class Initialized
INFO - 2024-06-07 09:39:05 --> Hooks Class Initialized
DEBUG - 2024-06-07 09:39:05 --> UTF-8 Support Enabled
INFO - 2024-06-07 09:39:05 --> Utf8 Class Initialized
INFO - 2024-06-07 09:39:05 --> URI Class Initialized
INFO - 2024-06-07 09:39:05 --> Router Class Initialized
INFO - 2024-06-07 09:39:05 --> Output Class Initialized
INFO - 2024-06-07 09:39:05 --> Security Class Initialized
DEBUG - 2024-06-07 09:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 09:39:05 --> Input Class Initialized
INFO - 2024-06-07 09:39:05 --> Language Class Initialized
INFO - 2024-06-07 09:39:05 --> Language Class Initialized
INFO - 2024-06-07 09:39:05 --> Config Class Initialized
INFO - 2024-06-07 09:39:05 --> Loader Class Initialized
INFO - 2024-06-07 09:39:05 --> Helper loaded: url_helper
INFO - 2024-06-07 09:39:05 --> Helper loaded: file_helper
INFO - 2024-06-07 09:39:05 --> Helper loaded: form_helper
INFO - 2024-06-07 09:39:05 --> Helper loaded: my_helper
INFO - 2024-06-07 09:39:05 --> Database Driver Class Initialized
INFO - 2024-06-07 09:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 09:39:05 --> Controller Class Initialized
INFO - 2024-06-07 09:39:05 --> Final output sent to browser
DEBUG - 2024-06-07 09:39:05 --> Total execution time: 0.0430
INFO - 2024-06-07 10:10:51 --> Config Class Initialized
INFO - 2024-06-07 10:10:51 --> Hooks Class Initialized
DEBUG - 2024-06-07 10:10:51 --> UTF-8 Support Enabled
INFO - 2024-06-07 10:10:51 --> Utf8 Class Initialized
INFO - 2024-06-07 10:10:51 --> URI Class Initialized
INFO - 2024-06-07 10:10:51 --> Router Class Initialized
INFO - 2024-06-07 10:10:51 --> Output Class Initialized
INFO - 2024-06-07 10:10:51 --> Security Class Initialized
DEBUG - 2024-06-07 10:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 10:10:51 --> Input Class Initialized
INFO - 2024-06-07 10:10:51 --> Language Class Initialized
INFO - 2024-06-07 10:10:51 --> Language Class Initialized
INFO - 2024-06-07 10:10:51 --> Config Class Initialized
INFO - 2024-06-07 10:10:51 --> Loader Class Initialized
INFO - 2024-06-07 10:10:51 --> Helper loaded: url_helper
INFO - 2024-06-07 10:10:51 --> Helper loaded: file_helper
INFO - 2024-06-07 10:10:51 --> Helper loaded: form_helper
INFO - 2024-06-07 10:10:51 --> Helper loaded: my_helper
INFO - 2024-06-07 10:10:51 --> Database Driver Class Initialized
INFO - 2024-06-07 10:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 10:10:51 --> Controller Class Initialized
DEBUG - 2024-06-07 10:10:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-07 10:10:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 10:10:51 --> Final output sent to browser
DEBUG - 2024-06-07 10:10:51 --> Total execution time: 0.0485
INFO - 2024-06-07 10:10:51 --> Config Class Initialized
INFO - 2024-06-07 10:10:51 --> Hooks Class Initialized
DEBUG - 2024-06-07 10:10:51 --> UTF-8 Support Enabled
INFO - 2024-06-07 10:10:51 --> Utf8 Class Initialized
INFO - 2024-06-07 10:10:51 --> URI Class Initialized
INFO - 2024-06-07 10:10:51 --> Router Class Initialized
INFO - 2024-06-07 10:10:51 --> Output Class Initialized
INFO - 2024-06-07 10:10:51 --> Security Class Initialized
DEBUG - 2024-06-07 10:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 10:10:51 --> Input Class Initialized
INFO - 2024-06-07 10:10:51 --> Language Class Initialized
INFO - 2024-06-07 10:10:51 --> Language Class Initialized
INFO - 2024-06-07 10:10:51 --> Config Class Initialized
INFO - 2024-06-07 10:10:51 --> Loader Class Initialized
INFO - 2024-06-07 10:10:51 --> Helper loaded: url_helper
INFO - 2024-06-07 10:10:51 --> Helper loaded: file_helper
INFO - 2024-06-07 10:10:51 --> Helper loaded: form_helper
INFO - 2024-06-07 10:10:51 --> Helper loaded: my_helper
INFO - 2024-06-07 10:10:51 --> Database Driver Class Initialized
INFO - 2024-06-07 10:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 10:10:51 --> Controller Class Initialized
INFO - 2024-06-07 10:47:07 --> Config Class Initialized
INFO - 2024-06-07 10:47:07 --> Hooks Class Initialized
DEBUG - 2024-06-07 10:47:07 --> UTF-8 Support Enabled
INFO - 2024-06-07 10:47:07 --> Utf8 Class Initialized
INFO - 2024-06-07 10:47:07 --> URI Class Initialized
INFO - 2024-06-07 10:47:07 --> Router Class Initialized
INFO - 2024-06-07 10:47:07 --> Output Class Initialized
INFO - 2024-06-07 10:47:07 --> Security Class Initialized
DEBUG - 2024-06-07 10:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 10:47:07 --> Input Class Initialized
INFO - 2024-06-07 10:47:07 --> Language Class Initialized
INFO - 2024-06-07 10:47:07 --> Language Class Initialized
INFO - 2024-06-07 10:47:07 --> Config Class Initialized
INFO - 2024-06-07 10:47:07 --> Loader Class Initialized
INFO - 2024-06-07 10:47:07 --> Helper loaded: url_helper
INFO - 2024-06-07 10:47:07 --> Helper loaded: file_helper
INFO - 2024-06-07 10:47:07 --> Helper loaded: form_helper
INFO - 2024-06-07 10:47:07 --> Helper loaded: my_helper
INFO - 2024-06-07 10:47:07 --> Database Driver Class Initialized
INFO - 2024-06-07 10:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 10:47:07 --> Controller Class Initialized
DEBUG - 2024-06-07 10:47:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-06-07 10:47:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 10:47:07 --> Final output sent to browser
DEBUG - 2024-06-07 10:47:07 --> Total execution time: 0.0868
INFO - 2024-06-07 10:47:07 --> Config Class Initialized
INFO - 2024-06-07 10:47:07 --> Hooks Class Initialized
DEBUG - 2024-06-07 10:47:07 --> UTF-8 Support Enabled
INFO - 2024-06-07 10:47:07 --> Utf8 Class Initialized
INFO - 2024-06-07 10:47:07 --> URI Class Initialized
INFO - 2024-06-07 10:47:07 --> Router Class Initialized
INFO - 2024-06-07 10:47:07 --> Output Class Initialized
INFO - 2024-06-07 10:47:07 --> Security Class Initialized
DEBUG - 2024-06-07 10:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 10:47:07 --> Input Class Initialized
INFO - 2024-06-07 10:47:07 --> Language Class Initialized
ERROR - 2024-06-07 10:47:07 --> 404 Page Not Found: /index
INFO - 2024-06-07 10:47:07 --> Config Class Initialized
INFO - 2024-06-07 10:47:07 --> Hooks Class Initialized
DEBUG - 2024-06-07 10:47:07 --> UTF-8 Support Enabled
INFO - 2024-06-07 10:47:07 --> Utf8 Class Initialized
INFO - 2024-06-07 10:47:07 --> URI Class Initialized
INFO - 2024-06-07 10:47:07 --> Router Class Initialized
INFO - 2024-06-07 10:47:07 --> Output Class Initialized
INFO - 2024-06-07 10:47:07 --> Security Class Initialized
DEBUG - 2024-06-07 10:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 10:47:07 --> Input Class Initialized
INFO - 2024-06-07 10:47:07 --> Language Class Initialized
INFO - 2024-06-07 10:47:07 --> Language Class Initialized
INFO - 2024-06-07 10:47:07 --> Config Class Initialized
INFO - 2024-06-07 10:47:07 --> Loader Class Initialized
INFO - 2024-06-07 10:47:07 --> Helper loaded: url_helper
INFO - 2024-06-07 10:47:07 --> Helper loaded: file_helper
INFO - 2024-06-07 10:47:07 --> Helper loaded: form_helper
INFO - 2024-06-07 10:47:07 --> Helper loaded: my_helper
INFO - 2024-06-07 10:47:07 --> Database Driver Class Initialized
INFO - 2024-06-07 10:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 10:47:07 --> Controller Class Initialized
INFO - 2024-06-07 10:47:20 --> Config Class Initialized
INFO - 2024-06-07 10:47:20 --> Hooks Class Initialized
DEBUG - 2024-06-07 10:47:20 --> UTF-8 Support Enabled
INFO - 2024-06-07 10:47:20 --> Utf8 Class Initialized
INFO - 2024-06-07 10:47:20 --> URI Class Initialized
INFO - 2024-06-07 10:47:20 --> Router Class Initialized
INFO - 2024-06-07 10:47:20 --> Output Class Initialized
INFO - 2024-06-07 10:47:20 --> Security Class Initialized
DEBUG - 2024-06-07 10:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 10:47:20 --> Input Class Initialized
INFO - 2024-06-07 10:47:20 --> Language Class Initialized
INFO - 2024-06-07 10:47:20 --> Language Class Initialized
INFO - 2024-06-07 10:47:20 --> Config Class Initialized
INFO - 2024-06-07 10:47:20 --> Loader Class Initialized
INFO - 2024-06-07 10:47:20 --> Helper loaded: url_helper
INFO - 2024-06-07 10:47:20 --> Helper loaded: file_helper
INFO - 2024-06-07 10:47:20 --> Helper loaded: form_helper
INFO - 2024-06-07 10:47:20 --> Helper loaded: my_helper
INFO - 2024-06-07 10:47:20 --> Database Driver Class Initialized
INFO - 2024-06-07 10:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 10:47:20 --> Controller Class Initialized
DEBUG - 2024-06-07 10:47:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-06-07 10:47:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 10:47:20 --> Final output sent to browser
DEBUG - 2024-06-07 10:47:20 --> Total execution time: 0.0242
INFO - 2024-06-07 10:47:20 --> Config Class Initialized
INFO - 2024-06-07 10:47:20 --> Hooks Class Initialized
DEBUG - 2024-06-07 10:47:20 --> UTF-8 Support Enabled
INFO - 2024-06-07 10:47:20 --> Utf8 Class Initialized
INFO - 2024-06-07 10:47:20 --> URI Class Initialized
INFO - 2024-06-07 10:47:20 --> Router Class Initialized
INFO - 2024-06-07 10:47:20 --> Output Class Initialized
INFO - 2024-06-07 10:47:20 --> Security Class Initialized
DEBUG - 2024-06-07 10:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 10:47:20 --> Input Class Initialized
INFO - 2024-06-07 10:47:20 --> Language Class Initialized
ERROR - 2024-06-07 10:47:20 --> 404 Page Not Found: /index
INFO - 2024-06-07 10:47:20 --> Config Class Initialized
INFO - 2024-06-07 10:47:20 --> Hooks Class Initialized
DEBUG - 2024-06-07 10:47:20 --> UTF-8 Support Enabled
INFO - 2024-06-07 10:47:20 --> Utf8 Class Initialized
INFO - 2024-06-07 10:47:20 --> URI Class Initialized
INFO - 2024-06-07 10:47:20 --> Router Class Initialized
INFO - 2024-06-07 10:47:20 --> Output Class Initialized
INFO - 2024-06-07 10:47:20 --> Security Class Initialized
DEBUG - 2024-06-07 10:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 10:47:20 --> Input Class Initialized
INFO - 2024-06-07 10:47:20 --> Language Class Initialized
INFO - 2024-06-07 10:47:20 --> Language Class Initialized
INFO - 2024-06-07 10:47:20 --> Config Class Initialized
INFO - 2024-06-07 10:47:20 --> Loader Class Initialized
INFO - 2024-06-07 10:47:20 --> Helper loaded: url_helper
INFO - 2024-06-07 10:47:20 --> Helper loaded: file_helper
INFO - 2024-06-07 10:47:20 --> Helper loaded: form_helper
INFO - 2024-06-07 10:47:20 --> Helper loaded: my_helper
INFO - 2024-06-07 10:47:20 --> Database Driver Class Initialized
INFO - 2024-06-07 10:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 10:47:20 --> Controller Class Initialized
INFO - 2024-06-07 10:47:27 --> Config Class Initialized
INFO - 2024-06-07 10:47:27 --> Hooks Class Initialized
DEBUG - 2024-06-07 10:47:27 --> UTF-8 Support Enabled
INFO - 2024-06-07 10:47:27 --> Utf8 Class Initialized
INFO - 2024-06-07 10:47:27 --> URI Class Initialized
INFO - 2024-06-07 10:47:27 --> Router Class Initialized
INFO - 2024-06-07 10:47:27 --> Output Class Initialized
INFO - 2024-06-07 10:47:27 --> Security Class Initialized
DEBUG - 2024-06-07 10:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 10:47:27 --> Input Class Initialized
INFO - 2024-06-07 10:47:27 --> Language Class Initialized
INFO - 2024-06-07 10:47:27 --> Language Class Initialized
INFO - 2024-06-07 10:47:27 --> Config Class Initialized
INFO - 2024-06-07 10:47:27 --> Loader Class Initialized
INFO - 2024-06-07 10:47:27 --> Helper loaded: url_helper
INFO - 2024-06-07 10:47:27 --> Helper loaded: file_helper
INFO - 2024-06-07 10:47:27 --> Helper loaded: form_helper
INFO - 2024-06-07 10:47:27 --> Helper loaded: my_helper
INFO - 2024-06-07 10:47:27 --> Database Driver Class Initialized
INFO - 2024-06-07 10:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 10:47:27 --> Controller Class Initialized
INFO - 2024-06-07 10:47:27 --> Helper loaded: cookie_helper
INFO - 2024-06-07 10:47:27 --> Config Class Initialized
INFO - 2024-06-07 10:47:27 --> Hooks Class Initialized
DEBUG - 2024-06-07 10:47:27 --> UTF-8 Support Enabled
INFO - 2024-06-07 10:47:27 --> Utf8 Class Initialized
INFO - 2024-06-07 10:47:27 --> URI Class Initialized
INFO - 2024-06-07 10:47:27 --> Router Class Initialized
INFO - 2024-06-07 10:47:27 --> Output Class Initialized
INFO - 2024-06-07 10:47:27 --> Security Class Initialized
DEBUG - 2024-06-07 10:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 10:47:27 --> Input Class Initialized
INFO - 2024-06-07 10:47:27 --> Language Class Initialized
INFO - 2024-06-07 10:47:27 --> Language Class Initialized
INFO - 2024-06-07 10:47:27 --> Config Class Initialized
INFO - 2024-06-07 10:47:27 --> Loader Class Initialized
INFO - 2024-06-07 10:47:27 --> Helper loaded: url_helper
INFO - 2024-06-07 10:47:27 --> Helper loaded: file_helper
INFO - 2024-06-07 10:47:27 --> Helper loaded: form_helper
INFO - 2024-06-07 10:47:27 --> Helper loaded: my_helper
INFO - 2024-06-07 10:47:27 --> Database Driver Class Initialized
INFO - 2024-06-07 10:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 10:47:27 --> Controller Class Initialized
INFO - 2024-06-07 10:47:27 --> Config Class Initialized
INFO - 2024-06-07 10:47:27 --> Hooks Class Initialized
DEBUG - 2024-06-07 10:47:27 --> UTF-8 Support Enabled
INFO - 2024-06-07 10:47:27 --> Utf8 Class Initialized
INFO - 2024-06-07 10:47:27 --> URI Class Initialized
INFO - 2024-06-07 10:47:27 --> Router Class Initialized
INFO - 2024-06-07 10:47:27 --> Output Class Initialized
INFO - 2024-06-07 10:47:27 --> Security Class Initialized
DEBUG - 2024-06-07 10:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 10:47:27 --> Input Class Initialized
INFO - 2024-06-07 10:47:27 --> Language Class Initialized
INFO - 2024-06-07 10:47:27 --> Language Class Initialized
INFO - 2024-06-07 10:47:27 --> Config Class Initialized
INFO - 2024-06-07 10:47:27 --> Loader Class Initialized
INFO - 2024-06-07 10:47:27 --> Helper loaded: url_helper
INFO - 2024-06-07 10:47:27 --> Helper loaded: file_helper
INFO - 2024-06-07 10:47:27 --> Helper loaded: form_helper
INFO - 2024-06-07 10:47:27 --> Helper loaded: my_helper
INFO - 2024-06-07 10:47:27 --> Database Driver Class Initialized
INFO - 2024-06-07 10:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 10:47:27 --> Controller Class Initialized
DEBUG - 2024-06-07 10:47:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-07 10:47:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 10:47:27 --> Final output sent to browser
DEBUG - 2024-06-07 10:47:27 --> Total execution time: 0.0250
INFO - 2024-06-07 10:47:36 --> Config Class Initialized
INFO - 2024-06-07 10:47:36 --> Hooks Class Initialized
DEBUG - 2024-06-07 10:47:36 --> UTF-8 Support Enabled
INFO - 2024-06-07 10:47:36 --> Utf8 Class Initialized
INFO - 2024-06-07 10:47:36 --> URI Class Initialized
INFO - 2024-06-07 10:47:36 --> Router Class Initialized
INFO - 2024-06-07 10:47:36 --> Output Class Initialized
INFO - 2024-06-07 10:47:36 --> Security Class Initialized
DEBUG - 2024-06-07 10:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 10:47:36 --> Input Class Initialized
INFO - 2024-06-07 10:47:36 --> Language Class Initialized
INFO - 2024-06-07 10:47:36 --> Language Class Initialized
INFO - 2024-06-07 10:47:36 --> Config Class Initialized
INFO - 2024-06-07 10:47:36 --> Loader Class Initialized
INFO - 2024-06-07 10:47:36 --> Helper loaded: url_helper
INFO - 2024-06-07 10:47:36 --> Helper loaded: file_helper
INFO - 2024-06-07 10:47:36 --> Helper loaded: form_helper
INFO - 2024-06-07 10:47:36 --> Helper loaded: my_helper
INFO - 2024-06-07 10:47:36 --> Database Driver Class Initialized
INFO - 2024-06-07 10:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 10:47:36 --> Controller Class Initialized
INFO - 2024-06-07 10:47:36 --> Helper loaded: cookie_helper
INFO - 2024-06-07 10:47:36 --> Final output sent to browser
DEBUG - 2024-06-07 10:47:36 --> Total execution time: 0.0402
INFO - 2024-06-07 10:47:36 --> Config Class Initialized
INFO - 2024-06-07 10:47:36 --> Hooks Class Initialized
DEBUG - 2024-06-07 10:47:36 --> UTF-8 Support Enabled
INFO - 2024-06-07 10:47:36 --> Utf8 Class Initialized
INFO - 2024-06-07 10:47:36 --> URI Class Initialized
INFO - 2024-06-07 10:47:36 --> Router Class Initialized
INFO - 2024-06-07 10:47:36 --> Output Class Initialized
INFO - 2024-06-07 10:47:36 --> Security Class Initialized
DEBUG - 2024-06-07 10:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 10:47:36 --> Input Class Initialized
INFO - 2024-06-07 10:47:36 --> Language Class Initialized
INFO - 2024-06-07 10:47:36 --> Language Class Initialized
INFO - 2024-06-07 10:47:36 --> Config Class Initialized
INFO - 2024-06-07 10:47:36 --> Loader Class Initialized
INFO - 2024-06-07 10:47:36 --> Helper loaded: url_helper
INFO - 2024-06-07 10:47:36 --> Helper loaded: file_helper
INFO - 2024-06-07 10:47:36 --> Helper loaded: form_helper
INFO - 2024-06-07 10:47:36 --> Helper loaded: my_helper
INFO - 2024-06-07 10:47:36 --> Database Driver Class Initialized
INFO - 2024-06-07 10:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 10:47:36 --> Controller Class Initialized
DEBUG - 2024-06-07 10:47:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-07 10:47:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 10:47:36 --> Final output sent to browser
DEBUG - 2024-06-07 10:47:36 --> Total execution time: 0.0319
INFO - 2024-06-07 10:47:41 --> Config Class Initialized
INFO - 2024-06-07 10:47:41 --> Hooks Class Initialized
DEBUG - 2024-06-07 10:47:41 --> UTF-8 Support Enabled
INFO - 2024-06-07 10:47:41 --> Utf8 Class Initialized
INFO - 2024-06-07 10:47:41 --> URI Class Initialized
INFO - 2024-06-07 10:47:41 --> Router Class Initialized
INFO - 2024-06-07 10:47:41 --> Output Class Initialized
INFO - 2024-06-07 10:47:41 --> Security Class Initialized
DEBUG - 2024-06-07 10:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 10:47:41 --> Input Class Initialized
INFO - 2024-06-07 10:47:41 --> Language Class Initialized
INFO - 2024-06-07 10:47:41 --> Language Class Initialized
INFO - 2024-06-07 10:47:41 --> Config Class Initialized
INFO - 2024-06-07 10:47:41 --> Loader Class Initialized
INFO - 2024-06-07 10:47:41 --> Helper loaded: url_helper
INFO - 2024-06-07 10:47:41 --> Helper loaded: file_helper
INFO - 2024-06-07 10:47:41 --> Helper loaded: form_helper
INFO - 2024-06-07 10:47:41 --> Helper loaded: my_helper
INFO - 2024-06-07 10:47:41 --> Database Driver Class Initialized
INFO - 2024-06-07 10:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 10:47:41 --> Controller Class Initialized
DEBUG - 2024-06-07 10:47:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2024-06-07 10:47:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 10:47:41 --> Final output sent to browser
DEBUG - 2024-06-07 10:47:41 --> Total execution time: 0.0287
INFO - 2024-06-07 10:47:47 --> Config Class Initialized
INFO - 2024-06-07 10:47:47 --> Hooks Class Initialized
DEBUG - 2024-06-07 10:47:47 --> UTF-8 Support Enabled
INFO - 2024-06-07 10:47:47 --> Utf8 Class Initialized
INFO - 2024-06-07 10:47:47 --> URI Class Initialized
INFO - 2024-06-07 10:47:47 --> Router Class Initialized
INFO - 2024-06-07 10:47:47 --> Output Class Initialized
INFO - 2024-06-07 10:47:47 --> Security Class Initialized
DEBUG - 2024-06-07 10:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 10:47:47 --> Input Class Initialized
INFO - 2024-06-07 10:47:47 --> Language Class Initialized
INFO - 2024-06-07 10:47:47 --> Language Class Initialized
INFO - 2024-06-07 10:47:47 --> Config Class Initialized
INFO - 2024-06-07 10:47:47 --> Loader Class Initialized
INFO - 2024-06-07 10:47:47 --> Helper loaded: url_helper
INFO - 2024-06-07 10:47:47 --> Helper loaded: file_helper
INFO - 2024-06-07 10:47:47 --> Helper loaded: form_helper
INFO - 2024-06-07 10:47:47 --> Helper loaded: my_helper
INFO - 2024-06-07 10:47:47 --> Database Driver Class Initialized
INFO - 2024-06-07 10:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 10:47:47 --> Controller Class Initialized
DEBUG - 2024-06-07 10:47:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2024-06-07 10:47:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 10:47:47 --> Final output sent to browser
DEBUG - 2024-06-07 10:47:47 --> Total execution time: 0.0583
INFO - 2024-06-07 10:47:48 --> Config Class Initialized
INFO - 2024-06-07 10:47:48 --> Hooks Class Initialized
DEBUG - 2024-06-07 10:47:48 --> UTF-8 Support Enabled
INFO - 2024-06-07 10:47:48 --> Utf8 Class Initialized
INFO - 2024-06-07 10:47:48 --> URI Class Initialized
INFO - 2024-06-07 10:47:48 --> Router Class Initialized
INFO - 2024-06-07 10:47:48 --> Output Class Initialized
INFO - 2024-06-07 10:47:48 --> Security Class Initialized
DEBUG - 2024-06-07 10:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 10:47:48 --> Input Class Initialized
INFO - 2024-06-07 10:47:48 --> Language Class Initialized
INFO - 2024-06-07 10:47:48 --> Language Class Initialized
INFO - 2024-06-07 10:47:48 --> Config Class Initialized
INFO - 2024-06-07 10:47:48 --> Loader Class Initialized
INFO - 2024-06-07 10:47:48 --> Helper loaded: url_helper
INFO - 2024-06-07 10:47:48 --> Helper loaded: file_helper
INFO - 2024-06-07 10:47:48 --> Helper loaded: form_helper
INFO - 2024-06-07 10:47:48 --> Helper loaded: my_helper
INFO - 2024-06-07 10:47:48 --> Database Driver Class Initialized
INFO - 2024-06-07 10:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 10:47:48 --> Controller Class Initialized
DEBUG - 2024-06-07 10:47:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-07 10:47:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 10:47:48 --> Final output sent to browser
DEBUG - 2024-06-07 10:47:48 --> Total execution time: 0.0332
INFO - 2024-06-07 10:47:50 --> Config Class Initialized
INFO - 2024-06-07 10:47:50 --> Hooks Class Initialized
DEBUG - 2024-06-07 10:47:50 --> UTF-8 Support Enabled
INFO - 2024-06-07 10:47:50 --> Utf8 Class Initialized
INFO - 2024-06-07 10:47:50 --> URI Class Initialized
INFO - 2024-06-07 10:47:50 --> Router Class Initialized
INFO - 2024-06-07 10:47:50 --> Output Class Initialized
INFO - 2024-06-07 10:47:50 --> Security Class Initialized
DEBUG - 2024-06-07 10:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 10:47:50 --> Input Class Initialized
INFO - 2024-06-07 10:47:50 --> Language Class Initialized
INFO - 2024-06-07 10:47:50 --> Language Class Initialized
INFO - 2024-06-07 10:47:50 --> Config Class Initialized
INFO - 2024-06-07 10:47:50 --> Loader Class Initialized
INFO - 2024-06-07 10:47:50 --> Helper loaded: url_helper
INFO - 2024-06-07 10:47:50 --> Helper loaded: file_helper
INFO - 2024-06-07 10:47:50 --> Helper loaded: form_helper
INFO - 2024-06-07 10:47:50 --> Helper loaded: my_helper
INFO - 2024-06-07 10:47:50 --> Database Driver Class Initialized
INFO - 2024-06-07 10:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 10:47:50 --> Controller Class Initialized
DEBUG - 2024-06-07 10:47:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-07 10:47:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 10:47:50 --> Final output sent to browser
DEBUG - 2024-06-07 10:47:50 --> Total execution time: 0.0308
INFO - 2024-06-07 10:47:50 --> Config Class Initialized
INFO - 2024-06-07 10:47:50 --> Hooks Class Initialized
DEBUG - 2024-06-07 10:47:50 --> UTF-8 Support Enabled
INFO - 2024-06-07 10:47:50 --> Utf8 Class Initialized
INFO - 2024-06-07 10:47:50 --> URI Class Initialized
INFO - 2024-06-07 10:47:50 --> Router Class Initialized
INFO - 2024-06-07 10:47:50 --> Output Class Initialized
INFO - 2024-06-07 10:47:50 --> Security Class Initialized
DEBUG - 2024-06-07 10:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 10:47:50 --> Input Class Initialized
INFO - 2024-06-07 10:47:50 --> Language Class Initialized
INFO - 2024-06-07 10:47:50 --> Language Class Initialized
INFO - 2024-06-07 10:47:50 --> Config Class Initialized
INFO - 2024-06-07 10:47:50 --> Loader Class Initialized
INFO - 2024-06-07 10:47:50 --> Helper loaded: url_helper
INFO - 2024-06-07 10:47:50 --> Helper loaded: file_helper
INFO - 2024-06-07 10:47:50 --> Helper loaded: form_helper
INFO - 2024-06-07 10:47:50 --> Helper loaded: my_helper
INFO - 2024-06-07 10:47:50 --> Database Driver Class Initialized
INFO - 2024-06-07 10:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 10:47:50 --> Controller Class Initialized
INFO - 2024-06-07 10:47:52 --> Config Class Initialized
INFO - 2024-06-07 10:47:52 --> Hooks Class Initialized
DEBUG - 2024-06-07 10:47:52 --> UTF-8 Support Enabled
INFO - 2024-06-07 10:47:52 --> Utf8 Class Initialized
INFO - 2024-06-07 10:47:52 --> URI Class Initialized
INFO - 2024-06-07 10:47:52 --> Router Class Initialized
INFO - 2024-06-07 10:47:52 --> Output Class Initialized
INFO - 2024-06-07 10:47:52 --> Security Class Initialized
DEBUG - 2024-06-07 10:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 10:47:52 --> Input Class Initialized
INFO - 2024-06-07 10:47:52 --> Language Class Initialized
INFO - 2024-06-07 10:47:52 --> Language Class Initialized
INFO - 2024-06-07 10:47:52 --> Config Class Initialized
INFO - 2024-06-07 10:47:52 --> Loader Class Initialized
INFO - 2024-06-07 10:47:52 --> Helper loaded: url_helper
INFO - 2024-06-07 10:47:52 --> Helper loaded: file_helper
INFO - 2024-06-07 10:47:52 --> Helper loaded: form_helper
INFO - 2024-06-07 10:47:52 --> Helper loaded: my_helper
INFO - 2024-06-07 10:47:52 --> Database Driver Class Initialized
INFO - 2024-06-07 10:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 10:47:52 --> Controller Class Initialized
DEBUG - 2024-06-07 10:47:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-07 10:47:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 10:47:52 --> Final output sent to browser
DEBUG - 2024-06-07 10:47:52 --> Total execution time: 0.0255
INFO - 2024-06-07 10:47:56 --> Config Class Initialized
INFO - 2024-06-07 10:47:56 --> Hooks Class Initialized
DEBUG - 2024-06-07 10:47:56 --> UTF-8 Support Enabled
INFO - 2024-06-07 10:47:56 --> Utf8 Class Initialized
INFO - 2024-06-07 10:47:56 --> URI Class Initialized
INFO - 2024-06-07 10:47:56 --> Router Class Initialized
INFO - 2024-06-07 10:47:56 --> Output Class Initialized
INFO - 2024-06-07 10:47:56 --> Security Class Initialized
DEBUG - 2024-06-07 10:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 10:47:56 --> Input Class Initialized
INFO - 2024-06-07 10:47:56 --> Language Class Initialized
INFO - 2024-06-07 10:47:56 --> Language Class Initialized
INFO - 2024-06-07 10:47:56 --> Config Class Initialized
INFO - 2024-06-07 10:47:56 --> Loader Class Initialized
INFO - 2024-06-07 10:47:56 --> Helper loaded: url_helper
INFO - 2024-06-07 10:47:56 --> Helper loaded: file_helper
INFO - 2024-06-07 10:47:56 --> Helper loaded: form_helper
INFO - 2024-06-07 10:47:56 --> Helper loaded: my_helper
INFO - 2024-06-07 10:47:56 --> Database Driver Class Initialized
INFO - 2024-06-07 10:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 10:47:56 --> Controller Class Initialized
DEBUG - 2024-06-07 10:47:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-07 10:47:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 10:47:56 --> Final output sent to browser
DEBUG - 2024-06-07 10:47:56 --> Total execution time: 0.0277
INFO - 2024-06-07 10:47:56 --> Config Class Initialized
INFO - 2024-06-07 10:47:56 --> Hooks Class Initialized
DEBUG - 2024-06-07 10:47:56 --> UTF-8 Support Enabled
INFO - 2024-06-07 10:47:56 --> Utf8 Class Initialized
INFO - 2024-06-07 10:47:56 --> URI Class Initialized
INFO - 2024-06-07 10:47:56 --> Router Class Initialized
INFO - 2024-06-07 10:47:56 --> Output Class Initialized
INFO - 2024-06-07 10:47:56 --> Security Class Initialized
DEBUG - 2024-06-07 10:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 10:47:56 --> Input Class Initialized
INFO - 2024-06-07 10:47:56 --> Language Class Initialized
INFO - 2024-06-07 10:47:56 --> Language Class Initialized
INFO - 2024-06-07 10:47:56 --> Config Class Initialized
INFO - 2024-06-07 10:47:56 --> Loader Class Initialized
INFO - 2024-06-07 10:47:56 --> Helper loaded: url_helper
INFO - 2024-06-07 10:47:56 --> Helper loaded: file_helper
INFO - 2024-06-07 10:47:56 --> Helper loaded: form_helper
INFO - 2024-06-07 10:47:56 --> Helper loaded: my_helper
INFO - 2024-06-07 10:47:56 --> Database Driver Class Initialized
INFO - 2024-06-07 10:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 10:47:56 --> Controller Class Initialized
INFO - 2024-06-07 11:04:18 --> Config Class Initialized
INFO - 2024-06-07 11:04:18 --> Hooks Class Initialized
DEBUG - 2024-06-07 11:04:18 --> UTF-8 Support Enabled
INFO - 2024-06-07 11:04:18 --> Utf8 Class Initialized
INFO - 2024-06-07 11:04:18 --> URI Class Initialized
INFO - 2024-06-07 11:04:18 --> Router Class Initialized
INFO - 2024-06-07 11:04:18 --> Output Class Initialized
INFO - 2024-06-07 11:04:18 --> Security Class Initialized
DEBUG - 2024-06-07 11:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 11:04:18 --> Input Class Initialized
INFO - 2024-06-07 11:04:18 --> Language Class Initialized
INFO - 2024-06-07 11:04:18 --> Language Class Initialized
INFO - 2024-06-07 11:04:18 --> Config Class Initialized
INFO - 2024-06-07 11:04:18 --> Loader Class Initialized
INFO - 2024-06-07 11:04:18 --> Helper loaded: url_helper
INFO - 2024-06-07 11:04:18 --> Helper loaded: file_helper
INFO - 2024-06-07 11:04:18 --> Helper loaded: form_helper
INFO - 2024-06-07 11:04:18 --> Helper loaded: my_helper
INFO - 2024-06-07 11:04:18 --> Database Driver Class Initialized
INFO - 2024-06-07 11:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 11:04:18 --> Controller Class Initialized
ERROR - 2024-06-07 11:04:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3888
DEBUG - 2024-06-07 11:04:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-07 11:04:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 11:04:18 --> Final output sent to browser
DEBUG - 2024-06-07 11:04:18 --> Total execution time: 0.1384
INFO - 2024-06-07 11:04:23 --> Config Class Initialized
INFO - 2024-06-07 11:04:23 --> Hooks Class Initialized
DEBUG - 2024-06-07 11:04:23 --> UTF-8 Support Enabled
INFO - 2024-06-07 11:04:23 --> Utf8 Class Initialized
INFO - 2024-06-07 11:04:23 --> URI Class Initialized
INFO - 2024-06-07 11:04:23 --> Router Class Initialized
INFO - 2024-06-07 11:04:23 --> Output Class Initialized
INFO - 2024-06-07 11:04:23 --> Security Class Initialized
DEBUG - 2024-06-07 11:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 11:04:23 --> Input Class Initialized
INFO - 2024-06-07 11:04:23 --> Language Class Initialized
INFO - 2024-06-07 11:04:23 --> Language Class Initialized
INFO - 2024-06-07 11:04:23 --> Config Class Initialized
INFO - 2024-06-07 11:04:23 --> Loader Class Initialized
INFO - 2024-06-07 11:04:23 --> Helper loaded: url_helper
INFO - 2024-06-07 11:04:23 --> Helper loaded: file_helper
INFO - 2024-06-07 11:04:23 --> Helper loaded: form_helper
INFO - 2024-06-07 11:04:23 --> Helper loaded: my_helper
INFO - 2024-06-07 11:04:23 --> Database Driver Class Initialized
INFO - 2024-06-07 11:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 11:04:24 --> Controller Class Initialized
ERROR - 2024-06-07 11:04:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl2/controllers/N_catatan_kl2.php 19
ERROR - 2024-06-07 11:04:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl2/controllers/N_catatan_kl2.php 20
DEBUG - 2024-06-07 11:04:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl2/views/list.php
DEBUG - 2024-06-07 11:04:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 11:04:24 --> Final output sent to browser
DEBUG - 2024-06-07 11:04:24 --> Total execution time: 0.0384
INFO - 2024-06-07 14:30:45 --> Config Class Initialized
INFO - 2024-06-07 14:30:45 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:30:45 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:30:45 --> Utf8 Class Initialized
INFO - 2024-06-07 14:30:45 --> URI Class Initialized
INFO - 2024-06-07 14:30:45 --> Router Class Initialized
INFO - 2024-06-07 14:30:45 --> Output Class Initialized
INFO - 2024-06-07 14:30:45 --> Security Class Initialized
DEBUG - 2024-06-07 14:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:30:45 --> Input Class Initialized
INFO - 2024-06-07 14:30:45 --> Language Class Initialized
INFO - 2024-06-07 14:30:45 --> Language Class Initialized
INFO - 2024-06-07 14:30:45 --> Config Class Initialized
INFO - 2024-06-07 14:30:45 --> Loader Class Initialized
INFO - 2024-06-07 14:30:45 --> Helper loaded: url_helper
INFO - 2024-06-07 14:30:45 --> Helper loaded: file_helper
INFO - 2024-06-07 14:30:45 --> Helper loaded: form_helper
INFO - 2024-06-07 14:30:45 --> Helper loaded: my_helper
INFO - 2024-06-07 14:30:45 --> Database Driver Class Initialized
INFO - 2024-06-07 14:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:30:45 --> Controller Class Initialized
DEBUG - 2024-06-07 14:30:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-07 14:30:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 14:30:45 --> Final output sent to browser
DEBUG - 2024-06-07 14:30:45 --> Total execution time: 0.0755
INFO - 2024-06-07 14:30:50 --> Config Class Initialized
INFO - 2024-06-07 14:30:50 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:30:50 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:30:50 --> Utf8 Class Initialized
INFO - 2024-06-07 14:30:50 --> URI Class Initialized
INFO - 2024-06-07 14:30:50 --> Router Class Initialized
INFO - 2024-06-07 14:30:50 --> Output Class Initialized
INFO - 2024-06-07 14:30:50 --> Security Class Initialized
DEBUG - 2024-06-07 14:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:30:50 --> Input Class Initialized
INFO - 2024-06-07 14:30:50 --> Language Class Initialized
INFO - 2024-06-07 14:30:50 --> Language Class Initialized
INFO - 2024-06-07 14:30:50 --> Config Class Initialized
INFO - 2024-06-07 14:30:50 --> Loader Class Initialized
INFO - 2024-06-07 14:30:50 --> Helper loaded: url_helper
INFO - 2024-06-07 14:30:50 --> Helper loaded: file_helper
INFO - 2024-06-07 14:30:50 --> Helper loaded: form_helper
INFO - 2024-06-07 14:30:50 --> Helper loaded: my_helper
INFO - 2024-06-07 14:30:50 --> Database Driver Class Initialized
INFO - 2024-06-07 14:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:30:50 --> Controller Class Initialized
INFO - 2024-06-07 14:30:50 --> Helper loaded: cookie_helper
INFO - 2024-06-07 14:30:51 --> Config Class Initialized
INFO - 2024-06-07 14:30:51 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:30:51 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:30:51 --> Utf8 Class Initialized
INFO - 2024-06-07 14:30:51 --> URI Class Initialized
INFO - 2024-06-07 14:30:51 --> Router Class Initialized
INFO - 2024-06-07 14:30:51 --> Output Class Initialized
INFO - 2024-06-07 14:30:51 --> Security Class Initialized
DEBUG - 2024-06-07 14:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:30:51 --> Input Class Initialized
INFO - 2024-06-07 14:30:51 --> Language Class Initialized
INFO - 2024-06-07 14:30:51 --> Language Class Initialized
INFO - 2024-06-07 14:30:51 --> Config Class Initialized
INFO - 2024-06-07 14:30:51 --> Loader Class Initialized
INFO - 2024-06-07 14:30:51 --> Helper loaded: url_helper
INFO - 2024-06-07 14:30:51 --> Helper loaded: file_helper
INFO - 2024-06-07 14:30:51 --> Helper loaded: form_helper
INFO - 2024-06-07 14:30:51 --> Helper loaded: my_helper
INFO - 2024-06-07 14:30:51 --> Database Driver Class Initialized
INFO - 2024-06-07 14:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:30:51 --> Controller Class Initialized
INFO - 2024-06-07 14:30:51 --> Config Class Initialized
INFO - 2024-06-07 14:30:51 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:30:51 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:30:51 --> Utf8 Class Initialized
INFO - 2024-06-07 14:30:51 --> URI Class Initialized
INFO - 2024-06-07 14:30:51 --> Router Class Initialized
INFO - 2024-06-07 14:30:51 --> Output Class Initialized
INFO - 2024-06-07 14:30:51 --> Security Class Initialized
DEBUG - 2024-06-07 14:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:30:51 --> Input Class Initialized
INFO - 2024-06-07 14:30:51 --> Language Class Initialized
INFO - 2024-06-07 14:30:51 --> Language Class Initialized
INFO - 2024-06-07 14:30:51 --> Config Class Initialized
INFO - 2024-06-07 14:30:51 --> Loader Class Initialized
INFO - 2024-06-07 14:30:51 --> Helper loaded: url_helper
INFO - 2024-06-07 14:30:51 --> Helper loaded: file_helper
INFO - 2024-06-07 14:30:51 --> Helper loaded: form_helper
INFO - 2024-06-07 14:30:51 --> Helper loaded: my_helper
INFO - 2024-06-07 14:30:51 --> Database Driver Class Initialized
INFO - 2024-06-07 14:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:30:51 --> Controller Class Initialized
DEBUG - 2024-06-07 14:30:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-07 14:30:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 14:30:51 --> Final output sent to browser
DEBUG - 2024-06-07 14:30:51 --> Total execution time: 0.0900
INFO - 2024-06-07 14:30:53 --> Config Class Initialized
INFO - 2024-06-07 14:30:53 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:30:53 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:30:53 --> Utf8 Class Initialized
INFO - 2024-06-07 14:30:53 --> URI Class Initialized
INFO - 2024-06-07 14:30:54 --> Router Class Initialized
INFO - 2024-06-07 14:30:54 --> Output Class Initialized
INFO - 2024-06-07 14:30:54 --> Security Class Initialized
DEBUG - 2024-06-07 14:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:30:54 --> Input Class Initialized
INFO - 2024-06-07 14:30:54 --> Language Class Initialized
INFO - 2024-06-07 14:30:54 --> Language Class Initialized
INFO - 2024-06-07 14:30:54 --> Config Class Initialized
INFO - 2024-06-07 14:30:54 --> Loader Class Initialized
INFO - 2024-06-07 14:30:54 --> Helper loaded: url_helper
INFO - 2024-06-07 14:30:54 --> Helper loaded: file_helper
INFO - 2024-06-07 14:30:54 --> Helper loaded: form_helper
INFO - 2024-06-07 14:30:54 --> Helper loaded: my_helper
INFO - 2024-06-07 14:30:54 --> Database Driver Class Initialized
INFO - 2024-06-07 14:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:30:54 --> Controller Class Initialized
INFO - 2024-06-07 14:30:54 --> Helper loaded: cookie_helper
INFO - 2024-06-07 14:30:54 --> Final output sent to browser
DEBUG - 2024-06-07 14:30:54 --> Total execution time: 0.0535
INFO - 2024-06-07 14:30:54 --> Config Class Initialized
INFO - 2024-06-07 14:30:54 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:30:54 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:30:54 --> Utf8 Class Initialized
INFO - 2024-06-07 14:30:54 --> URI Class Initialized
INFO - 2024-06-07 14:30:54 --> Router Class Initialized
INFO - 2024-06-07 14:30:54 --> Output Class Initialized
INFO - 2024-06-07 14:30:54 --> Security Class Initialized
DEBUG - 2024-06-07 14:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:30:54 --> Input Class Initialized
INFO - 2024-06-07 14:30:54 --> Language Class Initialized
INFO - 2024-06-07 14:30:54 --> Language Class Initialized
INFO - 2024-06-07 14:30:54 --> Config Class Initialized
INFO - 2024-06-07 14:30:54 --> Loader Class Initialized
INFO - 2024-06-07 14:30:54 --> Helper loaded: url_helper
INFO - 2024-06-07 14:30:54 --> Helper loaded: file_helper
INFO - 2024-06-07 14:30:54 --> Helper loaded: form_helper
INFO - 2024-06-07 14:30:54 --> Helper loaded: my_helper
INFO - 2024-06-07 14:30:54 --> Database Driver Class Initialized
INFO - 2024-06-07 14:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:30:54 --> Controller Class Initialized
DEBUG - 2024-06-07 14:30:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-07 14:30:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 14:30:54 --> Final output sent to browser
DEBUG - 2024-06-07 14:30:54 --> Total execution time: 0.0279
INFO - 2024-06-07 14:30:56 --> Config Class Initialized
INFO - 2024-06-07 14:30:56 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:30:56 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:30:56 --> Utf8 Class Initialized
INFO - 2024-06-07 14:30:56 --> URI Class Initialized
INFO - 2024-06-07 14:30:56 --> Router Class Initialized
INFO - 2024-06-07 14:30:56 --> Output Class Initialized
INFO - 2024-06-07 14:30:56 --> Security Class Initialized
DEBUG - 2024-06-07 14:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:30:56 --> Input Class Initialized
INFO - 2024-06-07 14:30:56 --> Language Class Initialized
INFO - 2024-06-07 14:30:56 --> Language Class Initialized
INFO - 2024-06-07 14:30:56 --> Config Class Initialized
INFO - 2024-06-07 14:30:56 --> Loader Class Initialized
INFO - 2024-06-07 14:30:56 --> Helper loaded: url_helper
INFO - 2024-06-07 14:30:56 --> Helper loaded: file_helper
INFO - 2024-06-07 14:30:56 --> Helper loaded: form_helper
INFO - 2024-06-07 14:30:56 --> Helper loaded: my_helper
INFO - 2024-06-07 14:30:56 --> Database Driver Class Initialized
INFO - 2024-06-07 14:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:30:56 --> Controller Class Initialized
DEBUG - 2024-06-07 14:30:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-07 14:30:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 14:30:56 --> Final output sent to browser
DEBUG - 2024-06-07 14:30:56 --> Total execution time: 0.0341
INFO - 2024-06-07 14:30:59 --> Config Class Initialized
INFO - 2024-06-07 14:30:59 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:30:59 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:30:59 --> Utf8 Class Initialized
INFO - 2024-06-07 14:30:59 --> URI Class Initialized
INFO - 2024-06-07 14:30:59 --> Router Class Initialized
INFO - 2024-06-07 14:30:59 --> Output Class Initialized
INFO - 2024-06-07 14:30:59 --> Security Class Initialized
DEBUG - 2024-06-07 14:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:30:59 --> Input Class Initialized
INFO - 2024-06-07 14:30:59 --> Language Class Initialized
INFO - 2024-06-07 14:30:59 --> Language Class Initialized
INFO - 2024-06-07 14:30:59 --> Config Class Initialized
INFO - 2024-06-07 14:30:59 --> Loader Class Initialized
INFO - 2024-06-07 14:30:59 --> Helper loaded: url_helper
INFO - 2024-06-07 14:30:59 --> Helper loaded: file_helper
INFO - 2024-06-07 14:30:59 --> Helper loaded: form_helper
INFO - 2024-06-07 14:30:59 --> Helper loaded: my_helper
INFO - 2024-06-07 14:30:59 --> Database Driver Class Initialized
INFO - 2024-06-07 14:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:30:59 --> Controller Class Initialized
DEBUG - 2024-06-07 14:30:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-07 14:30:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 14:30:59 --> Final output sent to browser
DEBUG - 2024-06-07 14:30:59 --> Total execution time: 0.4193
INFO - 2024-06-07 14:31:00 --> Config Class Initialized
INFO - 2024-06-07 14:31:00 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:31:00 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:31:00 --> Utf8 Class Initialized
INFO - 2024-06-07 14:31:00 --> URI Class Initialized
INFO - 2024-06-07 14:31:00 --> Router Class Initialized
INFO - 2024-06-07 14:31:00 --> Output Class Initialized
INFO - 2024-06-07 14:31:00 --> Security Class Initialized
DEBUG - 2024-06-07 14:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:31:00 --> Input Class Initialized
INFO - 2024-06-07 14:31:00 --> Language Class Initialized
INFO - 2024-06-07 14:31:00 --> Language Class Initialized
INFO - 2024-06-07 14:31:00 --> Config Class Initialized
INFO - 2024-06-07 14:31:00 --> Loader Class Initialized
INFO - 2024-06-07 14:31:00 --> Helper loaded: url_helper
INFO - 2024-06-07 14:31:00 --> Helper loaded: file_helper
INFO - 2024-06-07 14:31:00 --> Helper loaded: form_helper
INFO - 2024-06-07 14:31:00 --> Helper loaded: my_helper
INFO - 2024-06-07 14:31:00 --> Database Driver Class Initialized
INFO - 2024-06-07 14:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:31:00 --> Controller Class Initialized
INFO - 2024-06-07 14:31:04 --> Config Class Initialized
INFO - 2024-06-07 14:31:04 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:31:04 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:31:04 --> Utf8 Class Initialized
INFO - 2024-06-07 14:31:04 --> URI Class Initialized
INFO - 2024-06-07 14:31:04 --> Router Class Initialized
INFO - 2024-06-07 14:31:04 --> Output Class Initialized
INFO - 2024-06-07 14:31:04 --> Security Class Initialized
DEBUG - 2024-06-07 14:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:31:04 --> Input Class Initialized
INFO - 2024-06-07 14:31:04 --> Language Class Initialized
INFO - 2024-06-07 14:31:04 --> Language Class Initialized
INFO - 2024-06-07 14:31:04 --> Config Class Initialized
INFO - 2024-06-07 14:31:04 --> Loader Class Initialized
INFO - 2024-06-07 14:31:04 --> Helper loaded: url_helper
INFO - 2024-06-07 14:31:04 --> Helper loaded: file_helper
INFO - 2024-06-07 14:31:04 --> Helper loaded: form_helper
INFO - 2024-06-07 14:31:04 --> Helper loaded: my_helper
INFO - 2024-06-07 14:31:04 --> Database Driver Class Initialized
INFO - 2024-06-07 14:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:31:04 --> Controller Class Initialized
INFO - 2024-06-07 14:31:04 --> Final output sent to browser
DEBUG - 2024-06-07 14:31:04 --> Total execution time: 0.0825
INFO - 2024-06-07 14:31:10 --> Config Class Initialized
INFO - 2024-06-07 14:31:10 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:31:10 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:31:10 --> Utf8 Class Initialized
INFO - 2024-06-07 14:31:10 --> URI Class Initialized
INFO - 2024-06-07 14:31:10 --> Router Class Initialized
INFO - 2024-06-07 14:31:10 --> Output Class Initialized
INFO - 2024-06-07 14:31:10 --> Security Class Initialized
DEBUG - 2024-06-07 14:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:31:10 --> Input Class Initialized
INFO - 2024-06-07 14:31:10 --> Language Class Initialized
INFO - 2024-06-07 14:31:10 --> Language Class Initialized
INFO - 2024-06-07 14:31:10 --> Config Class Initialized
INFO - 2024-06-07 14:31:10 --> Loader Class Initialized
INFO - 2024-06-07 14:31:10 --> Helper loaded: url_helper
INFO - 2024-06-07 14:31:10 --> Helper loaded: file_helper
INFO - 2024-06-07 14:31:10 --> Helper loaded: form_helper
INFO - 2024-06-07 14:31:10 --> Helper loaded: my_helper
INFO - 2024-06-07 14:31:10 --> Database Driver Class Initialized
INFO - 2024-06-07 14:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:31:10 --> Controller Class Initialized
INFO - 2024-06-07 14:31:10 --> Final output sent to browser
DEBUG - 2024-06-07 14:31:10 --> Total execution time: 0.0407
INFO - 2024-06-07 14:31:19 --> Config Class Initialized
INFO - 2024-06-07 14:31:19 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:31:19 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:31:19 --> Utf8 Class Initialized
INFO - 2024-06-07 14:31:19 --> URI Class Initialized
INFO - 2024-06-07 14:31:19 --> Router Class Initialized
INFO - 2024-06-07 14:31:19 --> Output Class Initialized
INFO - 2024-06-07 14:31:19 --> Security Class Initialized
DEBUG - 2024-06-07 14:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:31:19 --> Input Class Initialized
INFO - 2024-06-07 14:31:19 --> Language Class Initialized
INFO - 2024-06-07 14:31:19 --> Language Class Initialized
INFO - 2024-06-07 14:31:19 --> Config Class Initialized
INFO - 2024-06-07 14:31:19 --> Loader Class Initialized
INFO - 2024-06-07 14:31:19 --> Helper loaded: url_helper
INFO - 2024-06-07 14:31:19 --> Helper loaded: file_helper
INFO - 2024-06-07 14:31:19 --> Helper loaded: form_helper
INFO - 2024-06-07 14:31:19 --> Helper loaded: my_helper
INFO - 2024-06-07 14:31:19 --> Database Driver Class Initialized
INFO - 2024-06-07 14:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:31:19 --> Controller Class Initialized
INFO - 2024-06-07 14:31:19 --> Final output sent to browser
DEBUG - 2024-06-07 14:31:19 --> Total execution time: 0.0263
INFO - 2024-06-07 14:31:58 --> Config Class Initialized
INFO - 2024-06-07 14:31:58 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:31:58 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:31:58 --> Utf8 Class Initialized
INFO - 2024-06-07 14:31:58 --> URI Class Initialized
INFO - 2024-06-07 14:31:58 --> Router Class Initialized
INFO - 2024-06-07 14:31:58 --> Output Class Initialized
INFO - 2024-06-07 14:31:58 --> Security Class Initialized
DEBUG - 2024-06-07 14:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:31:58 --> Input Class Initialized
INFO - 2024-06-07 14:31:58 --> Language Class Initialized
INFO - 2024-06-07 14:31:58 --> Language Class Initialized
INFO - 2024-06-07 14:31:58 --> Config Class Initialized
INFO - 2024-06-07 14:31:58 --> Loader Class Initialized
INFO - 2024-06-07 14:31:58 --> Helper loaded: url_helper
INFO - 2024-06-07 14:31:58 --> Helper loaded: file_helper
INFO - 2024-06-07 14:31:58 --> Helper loaded: form_helper
INFO - 2024-06-07 14:31:58 --> Helper loaded: my_helper
INFO - 2024-06-07 14:31:58 --> Database Driver Class Initialized
INFO - 2024-06-07 14:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:31:58 --> Controller Class Initialized
INFO - 2024-06-07 14:31:58 --> Final output sent to browser
DEBUG - 2024-06-07 14:31:58 --> Total execution time: 0.0431
INFO - 2024-06-07 14:31:58 --> Config Class Initialized
INFO - 2024-06-07 14:31:58 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:31:58 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:31:58 --> Utf8 Class Initialized
INFO - 2024-06-07 14:31:58 --> URI Class Initialized
INFO - 2024-06-07 14:31:58 --> Router Class Initialized
INFO - 2024-06-07 14:31:58 --> Output Class Initialized
INFO - 2024-06-07 14:31:58 --> Security Class Initialized
DEBUG - 2024-06-07 14:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:31:58 --> Input Class Initialized
INFO - 2024-06-07 14:31:58 --> Language Class Initialized
INFO - 2024-06-07 14:31:58 --> Language Class Initialized
INFO - 2024-06-07 14:31:58 --> Config Class Initialized
INFO - 2024-06-07 14:31:58 --> Loader Class Initialized
INFO - 2024-06-07 14:31:58 --> Helper loaded: url_helper
INFO - 2024-06-07 14:31:58 --> Helper loaded: file_helper
INFO - 2024-06-07 14:31:58 --> Helper loaded: form_helper
INFO - 2024-06-07 14:31:58 --> Helper loaded: my_helper
INFO - 2024-06-07 14:31:58 --> Database Driver Class Initialized
INFO - 2024-06-07 14:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:31:58 --> Controller Class Initialized
INFO - 2024-06-07 14:32:03 --> Config Class Initialized
INFO - 2024-06-07 14:32:03 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:32:03 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:32:03 --> Utf8 Class Initialized
INFO - 2024-06-07 14:32:03 --> URI Class Initialized
INFO - 2024-06-07 14:32:03 --> Router Class Initialized
INFO - 2024-06-07 14:32:03 --> Output Class Initialized
INFO - 2024-06-07 14:32:03 --> Security Class Initialized
DEBUG - 2024-06-07 14:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:32:03 --> Input Class Initialized
INFO - 2024-06-07 14:32:03 --> Language Class Initialized
INFO - 2024-06-07 14:32:03 --> Language Class Initialized
INFO - 2024-06-07 14:32:03 --> Config Class Initialized
INFO - 2024-06-07 14:32:03 --> Loader Class Initialized
INFO - 2024-06-07 14:32:03 --> Helper loaded: url_helper
INFO - 2024-06-07 14:32:03 --> Helper loaded: file_helper
INFO - 2024-06-07 14:32:03 --> Helper loaded: form_helper
INFO - 2024-06-07 14:32:03 --> Helper loaded: my_helper
INFO - 2024-06-07 14:32:03 --> Database Driver Class Initialized
INFO - 2024-06-07 14:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:32:03 --> Controller Class Initialized
INFO - 2024-06-07 14:32:03 --> Final output sent to browser
DEBUG - 2024-06-07 14:32:03 --> Total execution time: 0.0331
INFO - 2024-06-07 14:32:10 --> Config Class Initialized
INFO - 2024-06-07 14:32:10 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:32:10 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:32:10 --> Utf8 Class Initialized
INFO - 2024-06-07 14:32:10 --> URI Class Initialized
INFO - 2024-06-07 14:32:10 --> Router Class Initialized
INFO - 2024-06-07 14:32:10 --> Output Class Initialized
INFO - 2024-06-07 14:32:10 --> Security Class Initialized
DEBUG - 2024-06-07 14:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:32:10 --> Input Class Initialized
INFO - 2024-06-07 14:32:10 --> Language Class Initialized
INFO - 2024-06-07 14:32:10 --> Language Class Initialized
INFO - 2024-06-07 14:32:10 --> Config Class Initialized
INFO - 2024-06-07 14:32:10 --> Loader Class Initialized
INFO - 2024-06-07 14:32:10 --> Helper loaded: url_helper
INFO - 2024-06-07 14:32:10 --> Helper loaded: file_helper
INFO - 2024-06-07 14:32:10 --> Helper loaded: form_helper
INFO - 2024-06-07 14:32:10 --> Helper loaded: my_helper
INFO - 2024-06-07 14:32:10 --> Database Driver Class Initialized
INFO - 2024-06-07 14:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:32:10 --> Controller Class Initialized
INFO - 2024-06-07 14:32:10 --> Final output sent to browser
DEBUG - 2024-06-07 14:32:10 --> Total execution time: 0.0405
INFO - 2024-06-07 14:32:10 --> Config Class Initialized
INFO - 2024-06-07 14:32:10 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:32:10 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:32:10 --> Utf8 Class Initialized
INFO - 2024-06-07 14:32:10 --> URI Class Initialized
INFO - 2024-06-07 14:32:10 --> Router Class Initialized
INFO - 2024-06-07 14:32:10 --> Output Class Initialized
INFO - 2024-06-07 14:32:10 --> Security Class Initialized
DEBUG - 2024-06-07 14:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:32:10 --> Input Class Initialized
INFO - 2024-06-07 14:32:10 --> Language Class Initialized
INFO - 2024-06-07 14:32:10 --> Language Class Initialized
INFO - 2024-06-07 14:32:10 --> Config Class Initialized
INFO - 2024-06-07 14:32:10 --> Loader Class Initialized
INFO - 2024-06-07 14:32:10 --> Helper loaded: url_helper
INFO - 2024-06-07 14:32:10 --> Helper loaded: file_helper
INFO - 2024-06-07 14:32:10 --> Helper loaded: form_helper
INFO - 2024-06-07 14:32:10 --> Helper loaded: my_helper
INFO - 2024-06-07 14:32:10 --> Database Driver Class Initialized
INFO - 2024-06-07 14:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:32:10 --> Controller Class Initialized
INFO - 2024-06-07 14:32:13 --> Config Class Initialized
INFO - 2024-06-07 14:32:13 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:32:13 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:32:13 --> Utf8 Class Initialized
INFO - 2024-06-07 14:32:13 --> URI Class Initialized
INFO - 2024-06-07 14:32:13 --> Router Class Initialized
INFO - 2024-06-07 14:32:13 --> Output Class Initialized
INFO - 2024-06-07 14:32:13 --> Security Class Initialized
DEBUG - 2024-06-07 14:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:32:13 --> Input Class Initialized
INFO - 2024-06-07 14:32:13 --> Language Class Initialized
INFO - 2024-06-07 14:32:13 --> Language Class Initialized
INFO - 2024-06-07 14:32:13 --> Config Class Initialized
INFO - 2024-06-07 14:32:13 --> Loader Class Initialized
INFO - 2024-06-07 14:32:13 --> Helper loaded: url_helper
INFO - 2024-06-07 14:32:13 --> Helper loaded: file_helper
INFO - 2024-06-07 14:32:13 --> Helper loaded: form_helper
INFO - 2024-06-07 14:32:14 --> Helper loaded: my_helper
INFO - 2024-06-07 14:32:14 --> Database Driver Class Initialized
INFO - 2024-06-07 14:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:32:14 --> Controller Class Initialized
INFO - 2024-06-07 14:32:14 --> Final output sent to browser
DEBUG - 2024-06-07 14:32:14 --> Total execution time: 0.1153
INFO - 2024-06-07 14:32:28 --> Config Class Initialized
INFO - 2024-06-07 14:32:28 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:32:28 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:32:28 --> Utf8 Class Initialized
INFO - 2024-06-07 14:32:28 --> URI Class Initialized
INFO - 2024-06-07 14:32:28 --> Router Class Initialized
INFO - 2024-06-07 14:32:28 --> Output Class Initialized
INFO - 2024-06-07 14:32:28 --> Security Class Initialized
DEBUG - 2024-06-07 14:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:32:28 --> Input Class Initialized
INFO - 2024-06-07 14:32:28 --> Language Class Initialized
INFO - 2024-06-07 14:32:28 --> Language Class Initialized
INFO - 2024-06-07 14:32:28 --> Config Class Initialized
INFO - 2024-06-07 14:32:28 --> Loader Class Initialized
INFO - 2024-06-07 14:32:28 --> Helper loaded: url_helper
INFO - 2024-06-07 14:32:28 --> Helper loaded: file_helper
INFO - 2024-06-07 14:32:28 --> Helper loaded: form_helper
INFO - 2024-06-07 14:32:28 --> Helper loaded: my_helper
INFO - 2024-06-07 14:32:28 --> Database Driver Class Initialized
INFO - 2024-06-07 14:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:32:28 --> Controller Class Initialized
INFO - 2024-06-07 14:32:29 --> Final output sent to browser
DEBUG - 2024-06-07 14:32:29 --> Total execution time: 0.2917
INFO - 2024-06-07 14:32:29 --> Config Class Initialized
INFO - 2024-06-07 14:32:29 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:32:29 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:32:29 --> Utf8 Class Initialized
INFO - 2024-06-07 14:32:29 --> URI Class Initialized
INFO - 2024-06-07 14:32:29 --> Router Class Initialized
INFO - 2024-06-07 14:32:29 --> Output Class Initialized
INFO - 2024-06-07 14:32:29 --> Security Class Initialized
DEBUG - 2024-06-07 14:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:32:29 --> Input Class Initialized
INFO - 2024-06-07 14:32:29 --> Language Class Initialized
INFO - 2024-06-07 14:32:29 --> Language Class Initialized
INFO - 2024-06-07 14:32:29 --> Config Class Initialized
INFO - 2024-06-07 14:32:29 --> Loader Class Initialized
INFO - 2024-06-07 14:32:29 --> Helper loaded: url_helper
INFO - 2024-06-07 14:32:29 --> Helper loaded: file_helper
INFO - 2024-06-07 14:32:29 --> Helper loaded: form_helper
INFO - 2024-06-07 14:32:29 --> Helper loaded: my_helper
INFO - 2024-06-07 14:32:29 --> Database Driver Class Initialized
INFO - 2024-06-07 14:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:32:29 --> Controller Class Initialized
INFO - 2024-06-07 14:32:31 --> Config Class Initialized
INFO - 2024-06-07 14:32:31 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:32:31 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:32:31 --> Utf8 Class Initialized
INFO - 2024-06-07 14:32:31 --> URI Class Initialized
INFO - 2024-06-07 14:32:31 --> Router Class Initialized
INFO - 2024-06-07 14:32:31 --> Output Class Initialized
INFO - 2024-06-07 14:32:31 --> Security Class Initialized
DEBUG - 2024-06-07 14:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:32:31 --> Input Class Initialized
INFO - 2024-06-07 14:32:31 --> Language Class Initialized
INFO - 2024-06-07 14:32:31 --> Language Class Initialized
INFO - 2024-06-07 14:32:31 --> Config Class Initialized
INFO - 2024-06-07 14:32:31 --> Loader Class Initialized
INFO - 2024-06-07 14:32:31 --> Helper loaded: url_helper
INFO - 2024-06-07 14:32:31 --> Helper loaded: file_helper
INFO - 2024-06-07 14:32:31 --> Helper loaded: form_helper
INFO - 2024-06-07 14:32:31 --> Helper loaded: my_helper
INFO - 2024-06-07 14:32:31 --> Database Driver Class Initialized
INFO - 2024-06-07 14:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:32:31 --> Controller Class Initialized
INFO - 2024-06-07 14:32:31 --> Final output sent to browser
DEBUG - 2024-06-07 14:32:31 --> Total execution time: 0.0389
INFO - 2024-06-07 14:32:49 --> Config Class Initialized
INFO - 2024-06-07 14:32:49 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:32:49 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:32:49 --> Utf8 Class Initialized
INFO - 2024-06-07 14:32:49 --> URI Class Initialized
INFO - 2024-06-07 14:32:49 --> Router Class Initialized
INFO - 2024-06-07 14:32:49 --> Output Class Initialized
INFO - 2024-06-07 14:32:49 --> Security Class Initialized
DEBUG - 2024-06-07 14:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:32:49 --> Input Class Initialized
INFO - 2024-06-07 14:32:49 --> Language Class Initialized
INFO - 2024-06-07 14:32:49 --> Language Class Initialized
INFO - 2024-06-07 14:32:49 --> Config Class Initialized
INFO - 2024-06-07 14:32:49 --> Loader Class Initialized
INFO - 2024-06-07 14:32:49 --> Helper loaded: url_helper
INFO - 2024-06-07 14:32:49 --> Helper loaded: file_helper
INFO - 2024-06-07 14:32:49 --> Helper loaded: form_helper
INFO - 2024-06-07 14:32:49 --> Helper loaded: my_helper
INFO - 2024-06-07 14:32:49 --> Database Driver Class Initialized
INFO - 2024-06-07 14:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:32:49 --> Controller Class Initialized
INFO - 2024-06-07 14:32:49 --> Final output sent to browser
DEBUG - 2024-06-07 14:32:49 --> Total execution time: 0.0283
INFO - 2024-06-07 14:32:49 --> Config Class Initialized
INFO - 2024-06-07 14:32:49 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:32:49 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:32:49 --> Utf8 Class Initialized
INFO - 2024-06-07 14:32:49 --> URI Class Initialized
INFO - 2024-06-07 14:32:49 --> Router Class Initialized
INFO - 2024-06-07 14:32:49 --> Output Class Initialized
INFO - 2024-06-07 14:32:49 --> Security Class Initialized
DEBUG - 2024-06-07 14:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:32:49 --> Input Class Initialized
INFO - 2024-06-07 14:32:49 --> Language Class Initialized
INFO - 2024-06-07 14:32:49 --> Language Class Initialized
INFO - 2024-06-07 14:32:49 --> Config Class Initialized
INFO - 2024-06-07 14:32:49 --> Loader Class Initialized
INFO - 2024-06-07 14:32:49 --> Helper loaded: url_helper
INFO - 2024-06-07 14:32:49 --> Helper loaded: file_helper
INFO - 2024-06-07 14:32:49 --> Helper loaded: form_helper
INFO - 2024-06-07 14:32:49 --> Helper loaded: my_helper
INFO - 2024-06-07 14:32:49 --> Database Driver Class Initialized
INFO - 2024-06-07 14:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:32:49 --> Controller Class Initialized
INFO - 2024-06-07 14:32:51 --> Config Class Initialized
INFO - 2024-06-07 14:32:51 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:32:51 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:32:51 --> Utf8 Class Initialized
INFO - 2024-06-07 14:32:51 --> URI Class Initialized
INFO - 2024-06-07 14:32:51 --> Router Class Initialized
INFO - 2024-06-07 14:32:51 --> Output Class Initialized
INFO - 2024-06-07 14:32:51 --> Security Class Initialized
DEBUG - 2024-06-07 14:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:32:51 --> Input Class Initialized
INFO - 2024-06-07 14:32:51 --> Language Class Initialized
INFO - 2024-06-07 14:32:51 --> Language Class Initialized
INFO - 2024-06-07 14:32:51 --> Config Class Initialized
INFO - 2024-06-07 14:32:51 --> Loader Class Initialized
INFO - 2024-06-07 14:32:51 --> Helper loaded: url_helper
INFO - 2024-06-07 14:32:51 --> Helper loaded: file_helper
INFO - 2024-06-07 14:32:51 --> Helper loaded: form_helper
INFO - 2024-06-07 14:32:51 --> Helper loaded: my_helper
INFO - 2024-06-07 14:32:51 --> Database Driver Class Initialized
INFO - 2024-06-07 14:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:32:51 --> Controller Class Initialized
INFO - 2024-06-07 14:32:51 --> Final output sent to browser
DEBUG - 2024-06-07 14:32:51 --> Total execution time: 0.0275
INFO - 2024-06-07 14:33:20 --> Config Class Initialized
INFO - 2024-06-07 14:33:20 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:33:20 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:33:20 --> Utf8 Class Initialized
INFO - 2024-06-07 14:33:20 --> URI Class Initialized
INFO - 2024-06-07 14:33:20 --> Router Class Initialized
INFO - 2024-06-07 14:33:20 --> Output Class Initialized
INFO - 2024-06-07 14:33:20 --> Security Class Initialized
DEBUG - 2024-06-07 14:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:33:20 --> Input Class Initialized
INFO - 2024-06-07 14:33:20 --> Language Class Initialized
INFO - 2024-06-07 14:33:20 --> Language Class Initialized
INFO - 2024-06-07 14:33:20 --> Config Class Initialized
INFO - 2024-06-07 14:33:20 --> Loader Class Initialized
INFO - 2024-06-07 14:33:20 --> Helper loaded: url_helper
INFO - 2024-06-07 14:33:20 --> Helper loaded: file_helper
INFO - 2024-06-07 14:33:20 --> Helper loaded: form_helper
INFO - 2024-06-07 14:33:20 --> Helper loaded: my_helper
INFO - 2024-06-07 14:33:20 --> Database Driver Class Initialized
INFO - 2024-06-07 14:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:33:20 --> Controller Class Initialized
INFO - 2024-06-07 14:33:20 --> Final output sent to browser
DEBUG - 2024-06-07 14:33:20 --> Total execution time: 0.0608
INFO - 2024-06-07 14:33:20 --> Config Class Initialized
INFO - 2024-06-07 14:33:20 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:33:20 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:33:20 --> Utf8 Class Initialized
INFO - 2024-06-07 14:33:20 --> URI Class Initialized
INFO - 2024-06-07 14:33:20 --> Router Class Initialized
INFO - 2024-06-07 14:33:20 --> Output Class Initialized
INFO - 2024-06-07 14:33:20 --> Security Class Initialized
DEBUG - 2024-06-07 14:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:33:20 --> Input Class Initialized
INFO - 2024-06-07 14:33:20 --> Language Class Initialized
INFO - 2024-06-07 14:33:20 --> Language Class Initialized
INFO - 2024-06-07 14:33:20 --> Config Class Initialized
INFO - 2024-06-07 14:33:20 --> Loader Class Initialized
INFO - 2024-06-07 14:33:20 --> Helper loaded: url_helper
INFO - 2024-06-07 14:33:20 --> Helper loaded: file_helper
INFO - 2024-06-07 14:33:20 --> Helper loaded: form_helper
INFO - 2024-06-07 14:33:20 --> Helper loaded: my_helper
INFO - 2024-06-07 14:33:20 --> Database Driver Class Initialized
INFO - 2024-06-07 14:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:33:20 --> Controller Class Initialized
INFO - 2024-06-07 14:33:44 --> Config Class Initialized
INFO - 2024-06-07 14:33:44 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:33:44 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:33:44 --> Utf8 Class Initialized
INFO - 2024-06-07 14:33:44 --> URI Class Initialized
INFO - 2024-06-07 14:33:44 --> Router Class Initialized
INFO - 2024-06-07 14:33:44 --> Output Class Initialized
INFO - 2024-06-07 14:33:44 --> Security Class Initialized
DEBUG - 2024-06-07 14:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:33:44 --> Input Class Initialized
INFO - 2024-06-07 14:33:44 --> Language Class Initialized
INFO - 2024-06-07 14:33:44 --> Language Class Initialized
INFO - 2024-06-07 14:33:44 --> Config Class Initialized
INFO - 2024-06-07 14:33:44 --> Loader Class Initialized
INFO - 2024-06-07 14:33:44 --> Helper loaded: url_helper
INFO - 2024-06-07 14:33:44 --> Helper loaded: file_helper
INFO - 2024-06-07 14:33:44 --> Helper loaded: form_helper
INFO - 2024-06-07 14:33:44 --> Helper loaded: my_helper
INFO - 2024-06-07 14:33:44 --> Database Driver Class Initialized
INFO - 2024-06-07 14:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:33:44 --> Controller Class Initialized
INFO - 2024-06-07 14:53:45 --> Config Class Initialized
INFO - 2024-06-07 14:53:45 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:53:45 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:53:45 --> Utf8 Class Initialized
INFO - 2024-06-07 14:53:45 --> URI Class Initialized
DEBUG - 2024-06-07 14:53:45 --> No URI present. Default controller set.
INFO - 2024-06-07 14:53:45 --> Router Class Initialized
INFO - 2024-06-07 14:53:45 --> Output Class Initialized
INFO - 2024-06-07 14:53:45 --> Security Class Initialized
DEBUG - 2024-06-07 14:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:53:45 --> Input Class Initialized
INFO - 2024-06-07 14:53:45 --> Language Class Initialized
INFO - 2024-06-07 14:53:45 --> Language Class Initialized
INFO - 2024-06-07 14:53:45 --> Config Class Initialized
INFO - 2024-06-07 14:53:45 --> Loader Class Initialized
INFO - 2024-06-07 14:53:45 --> Helper loaded: url_helper
INFO - 2024-06-07 14:53:45 --> Helper loaded: file_helper
INFO - 2024-06-07 14:53:45 --> Helper loaded: form_helper
INFO - 2024-06-07 14:53:45 --> Helper loaded: my_helper
INFO - 2024-06-07 14:53:45 --> Database Driver Class Initialized
INFO - 2024-06-07 14:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:53:45 --> Controller Class Initialized
INFO - 2024-06-07 14:53:45 --> Config Class Initialized
INFO - 2024-06-07 14:53:45 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:53:45 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:53:45 --> Utf8 Class Initialized
INFO - 2024-06-07 14:53:45 --> URI Class Initialized
INFO - 2024-06-07 14:53:45 --> Router Class Initialized
INFO - 2024-06-07 14:53:45 --> Output Class Initialized
INFO - 2024-06-07 14:53:45 --> Security Class Initialized
DEBUG - 2024-06-07 14:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:53:45 --> Input Class Initialized
INFO - 2024-06-07 14:53:45 --> Language Class Initialized
INFO - 2024-06-07 14:53:45 --> Language Class Initialized
INFO - 2024-06-07 14:53:45 --> Config Class Initialized
INFO - 2024-06-07 14:53:45 --> Loader Class Initialized
INFO - 2024-06-07 14:53:45 --> Helper loaded: url_helper
INFO - 2024-06-07 14:53:45 --> Helper loaded: file_helper
INFO - 2024-06-07 14:53:45 --> Helper loaded: form_helper
INFO - 2024-06-07 14:53:45 --> Helper loaded: my_helper
INFO - 2024-06-07 14:53:45 --> Database Driver Class Initialized
INFO - 2024-06-07 14:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:53:45 --> Controller Class Initialized
DEBUG - 2024-06-07 14:53:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-07 14:53:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 14:53:45 --> Final output sent to browser
DEBUG - 2024-06-07 14:53:45 --> Total execution time: 0.0299
INFO - 2024-06-07 14:54:37 --> Config Class Initialized
INFO - 2024-06-07 14:54:37 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:54:37 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:54:37 --> Utf8 Class Initialized
INFO - 2024-06-07 14:54:37 --> URI Class Initialized
INFO - 2024-06-07 14:54:37 --> Router Class Initialized
INFO - 2024-06-07 14:54:37 --> Output Class Initialized
INFO - 2024-06-07 14:54:37 --> Security Class Initialized
DEBUG - 2024-06-07 14:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:54:37 --> Input Class Initialized
INFO - 2024-06-07 14:54:37 --> Language Class Initialized
INFO - 2024-06-07 14:54:37 --> Language Class Initialized
INFO - 2024-06-07 14:54:37 --> Config Class Initialized
INFO - 2024-06-07 14:54:37 --> Loader Class Initialized
INFO - 2024-06-07 14:54:37 --> Helper loaded: url_helper
INFO - 2024-06-07 14:54:37 --> Helper loaded: file_helper
INFO - 2024-06-07 14:54:37 --> Helper loaded: form_helper
INFO - 2024-06-07 14:54:37 --> Helper loaded: my_helper
INFO - 2024-06-07 14:54:37 --> Database Driver Class Initialized
INFO - 2024-06-07 14:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:54:37 --> Controller Class Initialized
DEBUG - 2024-06-07 14:54:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-06-07 14:54:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 14:54:37 --> Final output sent to browser
DEBUG - 2024-06-07 14:54:37 --> Total execution time: 0.0562
INFO - 2024-06-07 14:54:48 --> Config Class Initialized
INFO - 2024-06-07 14:54:48 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:54:48 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:54:48 --> Utf8 Class Initialized
INFO - 2024-06-07 14:54:48 --> URI Class Initialized
INFO - 2024-06-07 14:54:48 --> Router Class Initialized
INFO - 2024-06-07 14:54:48 --> Output Class Initialized
INFO - 2024-06-07 14:54:48 --> Security Class Initialized
DEBUG - 2024-06-07 14:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:54:48 --> Input Class Initialized
INFO - 2024-06-07 14:54:48 --> Language Class Initialized
INFO - 2024-06-07 14:54:48 --> Language Class Initialized
INFO - 2024-06-07 14:54:48 --> Config Class Initialized
INFO - 2024-06-07 14:54:48 --> Loader Class Initialized
INFO - 2024-06-07 14:54:48 --> Helper loaded: url_helper
INFO - 2024-06-07 14:54:48 --> Helper loaded: file_helper
INFO - 2024-06-07 14:54:48 --> Helper loaded: form_helper
INFO - 2024-06-07 14:54:48 --> Helper loaded: my_helper
INFO - 2024-06-07 14:54:48 --> Database Driver Class Initialized
INFO - 2024-06-07 14:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:54:48 --> Controller Class Initialized
INFO - 2024-06-07 14:54:49 --> Config Class Initialized
INFO - 2024-06-07 14:54:49 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:54:49 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:54:49 --> Utf8 Class Initialized
INFO - 2024-06-07 14:54:49 --> URI Class Initialized
INFO - 2024-06-07 14:54:49 --> Router Class Initialized
INFO - 2024-06-07 14:54:49 --> Output Class Initialized
INFO - 2024-06-07 14:54:49 --> Security Class Initialized
DEBUG - 2024-06-07 14:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:54:49 --> Input Class Initialized
INFO - 2024-06-07 14:54:49 --> Language Class Initialized
INFO - 2024-06-07 14:54:49 --> Language Class Initialized
INFO - 2024-06-07 14:54:49 --> Config Class Initialized
INFO - 2024-06-07 14:54:49 --> Loader Class Initialized
INFO - 2024-06-07 14:54:49 --> Helper loaded: url_helper
INFO - 2024-06-07 14:54:49 --> Helper loaded: file_helper
INFO - 2024-06-07 14:54:49 --> Helper loaded: form_helper
INFO - 2024-06-07 14:54:49 --> Helper loaded: my_helper
INFO - 2024-06-07 14:54:49 --> Database Driver Class Initialized
INFO - 2024-06-07 14:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:54:49 --> Controller Class Initialized
DEBUG - 2024-06-07 14:54:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-07 14:54:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 14:54:49 --> Final output sent to browser
DEBUG - 2024-06-07 14:54:49 --> Total execution time: 0.0328
INFO - 2024-06-07 14:54:49 --> Config Class Initialized
INFO - 2024-06-07 14:54:49 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:54:49 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:54:49 --> Utf8 Class Initialized
INFO - 2024-06-07 14:54:49 --> URI Class Initialized
INFO - 2024-06-07 14:54:49 --> Router Class Initialized
INFO - 2024-06-07 14:54:49 --> Output Class Initialized
INFO - 2024-06-07 14:54:49 --> Security Class Initialized
DEBUG - 2024-06-07 14:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:54:49 --> Input Class Initialized
INFO - 2024-06-07 14:54:49 --> Language Class Initialized
INFO - 2024-06-07 14:54:49 --> Language Class Initialized
INFO - 2024-06-07 14:54:49 --> Config Class Initialized
INFO - 2024-06-07 14:54:49 --> Loader Class Initialized
INFO - 2024-06-07 14:54:49 --> Helper loaded: url_helper
INFO - 2024-06-07 14:54:49 --> Helper loaded: file_helper
INFO - 2024-06-07 14:54:49 --> Helper loaded: form_helper
INFO - 2024-06-07 14:54:49 --> Helper loaded: my_helper
INFO - 2024-06-07 14:54:49 --> Database Driver Class Initialized
INFO - 2024-06-07 14:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:54:49 --> Controller Class Initialized
INFO - 2024-06-07 14:54:51 --> Config Class Initialized
INFO - 2024-06-07 14:54:51 --> Hooks Class Initialized
DEBUG - 2024-06-07 14:54:51 --> UTF-8 Support Enabled
INFO - 2024-06-07 14:54:51 --> Utf8 Class Initialized
INFO - 2024-06-07 14:54:51 --> URI Class Initialized
INFO - 2024-06-07 14:54:51 --> Router Class Initialized
INFO - 2024-06-07 14:54:51 --> Output Class Initialized
INFO - 2024-06-07 14:54:51 --> Security Class Initialized
DEBUG - 2024-06-07 14:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 14:54:51 --> Input Class Initialized
INFO - 2024-06-07 14:54:51 --> Language Class Initialized
INFO - 2024-06-07 14:54:51 --> Language Class Initialized
INFO - 2024-06-07 14:54:51 --> Config Class Initialized
INFO - 2024-06-07 14:54:51 --> Loader Class Initialized
INFO - 2024-06-07 14:54:51 --> Helper loaded: url_helper
INFO - 2024-06-07 14:54:51 --> Helper loaded: file_helper
INFO - 2024-06-07 14:54:51 --> Helper loaded: form_helper
INFO - 2024-06-07 14:54:51 --> Helper loaded: my_helper
INFO - 2024-06-07 14:54:51 --> Database Driver Class Initialized
INFO - 2024-06-07 14:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 14:54:51 --> Controller Class Initialized
DEBUG - 2024-06-07 14:54:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2024-06-07 14:54:52 --> Final output sent to browser
DEBUG - 2024-06-07 14:54:52 --> Total execution time: 0.1286
INFO - 2024-06-07 16:20:45 --> Config Class Initialized
INFO - 2024-06-07 16:20:45 --> Hooks Class Initialized
DEBUG - 2024-06-07 16:20:45 --> UTF-8 Support Enabled
INFO - 2024-06-07 16:20:45 --> Utf8 Class Initialized
INFO - 2024-06-07 16:20:45 --> URI Class Initialized
INFO - 2024-06-07 16:20:45 --> Router Class Initialized
INFO - 2024-06-07 16:20:45 --> Output Class Initialized
INFO - 2024-06-07 16:20:45 --> Security Class Initialized
DEBUG - 2024-06-07 16:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 16:20:45 --> Input Class Initialized
INFO - 2024-06-07 16:20:45 --> Language Class Initialized
INFO - 2024-06-07 16:20:45 --> Language Class Initialized
INFO - 2024-06-07 16:20:45 --> Config Class Initialized
INFO - 2024-06-07 16:20:45 --> Loader Class Initialized
INFO - 2024-06-07 16:20:45 --> Helper loaded: url_helper
INFO - 2024-06-07 16:20:45 --> Helper loaded: file_helper
INFO - 2024-06-07 16:20:45 --> Helper loaded: form_helper
INFO - 2024-06-07 16:20:45 --> Helper loaded: my_helper
INFO - 2024-06-07 16:20:45 --> Database Driver Class Initialized
INFO - 2024-06-07 16:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 16:20:45 --> Controller Class Initialized
DEBUG - 2024-06-07 16:20:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-07 16:20:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 16:20:45 --> Final output sent to browser
DEBUG - 2024-06-07 16:20:45 --> Total execution time: 0.0890
INFO - 2024-06-07 16:20:46 --> Config Class Initialized
INFO - 2024-06-07 16:20:46 --> Hooks Class Initialized
DEBUG - 2024-06-07 16:20:46 --> UTF-8 Support Enabled
INFO - 2024-06-07 16:20:46 --> Utf8 Class Initialized
INFO - 2024-06-07 16:20:46 --> URI Class Initialized
INFO - 2024-06-07 16:20:46 --> Router Class Initialized
INFO - 2024-06-07 16:20:46 --> Output Class Initialized
INFO - 2024-06-07 16:20:46 --> Security Class Initialized
DEBUG - 2024-06-07 16:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 16:20:46 --> Input Class Initialized
INFO - 2024-06-07 16:20:46 --> Language Class Initialized
INFO - 2024-06-07 16:20:46 --> Language Class Initialized
INFO - 2024-06-07 16:20:46 --> Config Class Initialized
INFO - 2024-06-07 16:20:46 --> Loader Class Initialized
INFO - 2024-06-07 16:20:46 --> Helper loaded: url_helper
INFO - 2024-06-07 16:20:46 --> Helper loaded: file_helper
INFO - 2024-06-07 16:20:46 --> Helper loaded: form_helper
INFO - 2024-06-07 16:20:46 --> Helper loaded: my_helper
INFO - 2024-06-07 16:20:46 --> Database Driver Class Initialized
INFO - 2024-06-07 16:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 16:20:46 --> Controller Class Initialized
INFO - 2024-06-07 16:21:05 --> Config Class Initialized
INFO - 2024-06-07 16:21:05 --> Hooks Class Initialized
DEBUG - 2024-06-07 16:21:05 --> UTF-8 Support Enabled
INFO - 2024-06-07 16:21:05 --> Utf8 Class Initialized
INFO - 2024-06-07 16:21:05 --> URI Class Initialized
INFO - 2024-06-07 16:21:05 --> Router Class Initialized
INFO - 2024-06-07 16:21:05 --> Output Class Initialized
INFO - 2024-06-07 16:21:05 --> Security Class Initialized
DEBUG - 2024-06-07 16:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 16:21:05 --> Input Class Initialized
INFO - 2024-06-07 16:21:05 --> Language Class Initialized
INFO - 2024-06-07 16:21:05 --> Language Class Initialized
INFO - 2024-06-07 16:21:05 --> Config Class Initialized
INFO - 2024-06-07 16:21:05 --> Loader Class Initialized
INFO - 2024-06-07 16:21:05 --> Helper loaded: url_helper
INFO - 2024-06-07 16:21:05 --> Helper loaded: file_helper
INFO - 2024-06-07 16:21:05 --> Helper loaded: form_helper
INFO - 2024-06-07 16:21:05 --> Helper loaded: my_helper
INFO - 2024-06-07 16:21:05 --> Database Driver Class Initialized
INFO - 2024-06-07 16:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 16:21:05 --> Controller Class Initialized
INFO - 2024-06-07 16:21:05 --> Config Class Initialized
INFO - 2024-06-07 16:21:05 --> Hooks Class Initialized
DEBUG - 2024-06-07 16:21:05 --> UTF-8 Support Enabled
INFO - 2024-06-07 16:21:05 --> Utf8 Class Initialized
INFO - 2024-06-07 16:21:05 --> URI Class Initialized
INFO - 2024-06-07 16:21:05 --> Router Class Initialized
INFO - 2024-06-07 16:21:05 --> Output Class Initialized
INFO - 2024-06-07 16:21:05 --> Security Class Initialized
DEBUG - 2024-06-07 16:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 16:21:05 --> Input Class Initialized
INFO - 2024-06-07 16:21:05 --> Language Class Initialized
INFO - 2024-06-07 16:21:05 --> Language Class Initialized
INFO - 2024-06-07 16:21:05 --> Config Class Initialized
INFO - 2024-06-07 16:21:05 --> Loader Class Initialized
INFO - 2024-06-07 16:21:05 --> Helper loaded: url_helper
INFO - 2024-06-07 16:21:05 --> Helper loaded: file_helper
INFO - 2024-06-07 16:21:05 --> Helper loaded: form_helper
INFO - 2024-06-07 16:21:05 --> Helper loaded: my_helper
INFO - 2024-06-07 16:21:05 --> Database Driver Class Initialized
INFO - 2024-06-07 16:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 16:21:05 --> Controller Class Initialized
DEBUG - 2024-06-07 16:21:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-07 16:21:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 16:21:05 --> Final output sent to browser
DEBUG - 2024-06-07 16:21:05 --> Total execution time: 0.0356
INFO - 2024-06-07 16:21:06 --> Config Class Initialized
INFO - 2024-06-07 16:21:06 --> Hooks Class Initialized
DEBUG - 2024-06-07 16:21:06 --> UTF-8 Support Enabled
INFO - 2024-06-07 16:21:06 --> Utf8 Class Initialized
INFO - 2024-06-07 16:21:06 --> URI Class Initialized
INFO - 2024-06-07 16:21:06 --> Router Class Initialized
INFO - 2024-06-07 16:21:06 --> Output Class Initialized
INFO - 2024-06-07 16:21:06 --> Security Class Initialized
DEBUG - 2024-06-07 16:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 16:21:06 --> Input Class Initialized
INFO - 2024-06-07 16:21:06 --> Language Class Initialized
INFO - 2024-06-07 16:21:06 --> Language Class Initialized
INFO - 2024-06-07 16:21:06 --> Config Class Initialized
INFO - 2024-06-07 16:21:06 --> Loader Class Initialized
INFO - 2024-06-07 16:21:06 --> Helper loaded: url_helper
INFO - 2024-06-07 16:21:06 --> Helper loaded: file_helper
INFO - 2024-06-07 16:21:06 --> Helper loaded: form_helper
INFO - 2024-06-07 16:21:06 --> Helper loaded: my_helper
INFO - 2024-06-07 16:21:06 --> Database Driver Class Initialized
INFO - 2024-06-07 16:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 16:21:06 --> Controller Class Initialized
INFO - 2024-06-07 16:21:07 --> Helper loaded: cookie_helper
INFO - 2024-06-07 16:21:07 --> Final output sent to browser
DEBUG - 2024-06-07 16:21:07 --> Total execution time: 0.0701
INFO - 2024-06-07 16:21:07 --> Config Class Initialized
INFO - 2024-06-07 16:21:07 --> Hooks Class Initialized
DEBUG - 2024-06-07 16:21:07 --> UTF-8 Support Enabled
INFO - 2024-06-07 16:21:07 --> Utf8 Class Initialized
INFO - 2024-06-07 16:21:07 --> URI Class Initialized
INFO - 2024-06-07 16:21:07 --> Router Class Initialized
INFO - 2024-06-07 16:21:07 --> Output Class Initialized
INFO - 2024-06-07 16:21:07 --> Security Class Initialized
DEBUG - 2024-06-07 16:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 16:21:07 --> Input Class Initialized
INFO - 2024-06-07 16:21:07 --> Language Class Initialized
INFO - 2024-06-07 16:21:07 --> Language Class Initialized
INFO - 2024-06-07 16:21:07 --> Config Class Initialized
INFO - 2024-06-07 16:21:07 --> Loader Class Initialized
INFO - 2024-06-07 16:21:07 --> Helper loaded: url_helper
INFO - 2024-06-07 16:21:07 --> Helper loaded: file_helper
INFO - 2024-06-07 16:21:07 --> Helper loaded: form_helper
INFO - 2024-06-07 16:21:07 --> Helper loaded: my_helper
INFO - 2024-06-07 16:21:07 --> Database Driver Class Initialized
INFO - 2024-06-07 16:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 16:21:07 --> Controller Class Initialized
DEBUG - 2024-06-07 16:21:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-07 16:21:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 16:21:07 --> Final output sent to browser
DEBUG - 2024-06-07 16:21:07 --> Total execution time: 0.0293
INFO - 2024-06-07 16:21:11 --> Config Class Initialized
INFO - 2024-06-07 16:21:11 --> Hooks Class Initialized
DEBUG - 2024-06-07 16:21:11 --> UTF-8 Support Enabled
INFO - 2024-06-07 16:21:11 --> Utf8 Class Initialized
INFO - 2024-06-07 16:21:11 --> URI Class Initialized
INFO - 2024-06-07 16:21:11 --> Router Class Initialized
INFO - 2024-06-07 16:21:11 --> Output Class Initialized
INFO - 2024-06-07 16:21:11 --> Security Class Initialized
DEBUG - 2024-06-07 16:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 16:21:11 --> Input Class Initialized
INFO - 2024-06-07 16:21:11 --> Language Class Initialized
INFO - 2024-06-07 16:21:11 --> Language Class Initialized
INFO - 2024-06-07 16:21:11 --> Config Class Initialized
INFO - 2024-06-07 16:21:11 --> Loader Class Initialized
INFO - 2024-06-07 16:21:11 --> Helper loaded: url_helper
INFO - 2024-06-07 16:21:11 --> Helper loaded: file_helper
INFO - 2024-06-07 16:21:11 --> Helper loaded: form_helper
INFO - 2024-06-07 16:21:11 --> Helper loaded: my_helper
INFO - 2024-06-07 16:21:11 --> Database Driver Class Initialized
INFO - 2024-06-07 16:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 16:21:11 --> Controller Class Initialized
DEBUG - 2024-06-07 16:21:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-07 16:21:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 16:21:11 --> Final output sent to browser
DEBUG - 2024-06-07 16:21:11 --> Total execution time: 0.0363
INFO - 2024-06-07 16:21:14 --> Config Class Initialized
INFO - 2024-06-07 16:21:14 --> Hooks Class Initialized
DEBUG - 2024-06-07 16:21:14 --> UTF-8 Support Enabled
INFO - 2024-06-07 16:21:14 --> Utf8 Class Initialized
INFO - 2024-06-07 16:21:14 --> URI Class Initialized
INFO - 2024-06-07 16:21:14 --> Router Class Initialized
INFO - 2024-06-07 16:21:14 --> Output Class Initialized
INFO - 2024-06-07 16:21:14 --> Security Class Initialized
DEBUG - 2024-06-07 16:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 16:21:14 --> Input Class Initialized
INFO - 2024-06-07 16:21:14 --> Language Class Initialized
INFO - 2024-06-07 16:21:14 --> Language Class Initialized
INFO - 2024-06-07 16:21:14 --> Config Class Initialized
INFO - 2024-06-07 16:21:14 --> Loader Class Initialized
INFO - 2024-06-07 16:21:14 --> Helper loaded: url_helper
INFO - 2024-06-07 16:21:14 --> Helper loaded: file_helper
INFO - 2024-06-07 16:21:14 --> Helper loaded: form_helper
INFO - 2024-06-07 16:21:14 --> Helper loaded: my_helper
INFO - 2024-06-07 16:21:14 --> Database Driver Class Initialized
INFO - 2024-06-07 16:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 16:21:14 --> Controller Class Initialized
DEBUG - 2024-06-07 16:21:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-07 16:21:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 16:21:14 --> Final output sent to browser
DEBUG - 2024-06-07 16:21:14 --> Total execution time: 0.0565
INFO - 2024-06-07 16:21:14 --> Config Class Initialized
INFO - 2024-06-07 16:21:14 --> Hooks Class Initialized
DEBUG - 2024-06-07 16:21:14 --> UTF-8 Support Enabled
INFO - 2024-06-07 16:21:14 --> Utf8 Class Initialized
INFO - 2024-06-07 16:21:14 --> URI Class Initialized
INFO - 2024-06-07 16:21:15 --> Router Class Initialized
INFO - 2024-06-07 16:21:15 --> Output Class Initialized
INFO - 2024-06-07 16:21:15 --> Security Class Initialized
DEBUG - 2024-06-07 16:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 16:21:15 --> Input Class Initialized
INFO - 2024-06-07 16:21:15 --> Language Class Initialized
INFO - 2024-06-07 16:21:15 --> Language Class Initialized
INFO - 2024-06-07 16:21:15 --> Config Class Initialized
INFO - 2024-06-07 16:21:15 --> Loader Class Initialized
INFO - 2024-06-07 16:21:15 --> Helper loaded: url_helper
INFO - 2024-06-07 16:21:15 --> Helper loaded: file_helper
INFO - 2024-06-07 16:21:15 --> Helper loaded: form_helper
INFO - 2024-06-07 16:21:15 --> Helper loaded: my_helper
INFO - 2024-06-07 16:21:15 --> Database Driver Class Initialized
INFO - 2024-06-07 16:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 16:21:15 --> Controller Class Initialized
INFO - 2024-06-07 16:21:19 --> Config Class Initialized
INFO - 2024-06-07 16:21:19 --> Hooks Class Initialized
DEBUG - 2024-06-07 16:21:19 --> UTF-8 Support Enabled
INFO - 2024-06-07 16:21:19 --> Utf8 Class Initialized
INFO - 2024-06-07 16:21:19 --> URI Class Initialized
INFO - 2024-06-07 16:21:19 --> Router Class Initialized
INFO - 2024-06-07 16:21:19 --> Output Class Initialized
INFO - 2024-06-07 16:21:19 --> Security Class Initialized
DEBUG - 2024-06-07 16:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 16:21:19 --> Input Class Initialized
INFO - 2024-06-07 16:21:19 --> Language Class Initialized
INFO - 2024-06-07 16:21:19 --> Language Class Initialized
INFO - 2024-06-07 16:21:19 --> Config Class Initialized
INFO - 2024-06-07 16:21:19 --> Loader Class Initialized
INFO - 2024-06-07 16:21:19 --> Helper loaded: url_helper
INFO - 2024-06-07 16:21:19 --> Helper loaded: file_helper
INFO - 2024-06-07 16:21:19 --> Helper loaded: form_helper
INFO - 2024-06-07 16:21:19 --> Helper loaded: my_helper
INFO - 2024-06-07 16:21:19 --> Database Driver Class Initialized
INFO - 2024-06-07 16:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 16:21:19 --> Controller Class Initialized
INFO - 2024-06-07 16:21:39 --> Config Class Initialized
INFO - 2024-06-07 16:21:39 --> Hooks Class Initialized
DEBUG - 2024-06-07 16:21:39 --> UTF-8 Support Enabled
INFO - 2024-06-07 16:21:39 --> Utf8 Class Initialized
INFO - 2024-06-07 16:21:39 --> URI Class Initialized
INFO - 2024-06-07 16:21:39 --> Router Class Initialized
INFO - 2024-06-07 16:21:39 --> Output Class Initialized
INFO - 2024-06-07 16:21:39 --> Security Class Initialized
DEBUG - 2024-06-07 16:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 16:21:39 --> Input Class Initialized
INFO - 2024-06-07 16:21:39 --> Language Class Initialized
INFO - 2024-06-07 16:21:39 --> Language Class Initialized
INFO - 2024-06-07 16:21:39 --> Config Class Initialized
INFO - 2024-06-07 16:21:39 --> Loader Class Initialized
INFO - 2024-06-07 16:21:39 --> Helper loaded: url_helper
INFO - 2024-06-07 16:21:39 --> Helper loaded: file_helper
INFO - 2024-06-07 16:21:39 --> Helper loaded: form_helper
INFO - 2024-06-07 16:21:39 --> Helper loaded: my_helper
INFO - 2024-06-07 16:21:39 --> Database Driver Class Initialized
INFO - 2024-06-07 16:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 16:21:39 --> Controller Class Initialized
INFO - 2024-06-07 16:21:39 --> Final output sent to browser
DEBUG - 2024-06-07 16:21:39 --> Total execution time: 0.0411
INFO - 2024-06-07 16:21:41 --> Config Class Initialized
INFO - 2024-06-07 16:21:41 --> Hooks Class Initialized
DEBUG - 2024-06-07 16:21:41 --> UTF-8 Support Enabled
INFO - 2024-06-07 16:21:41 --> Utf8 Class Initialized
INFO - 2024-06-07 16:21:41 --> URI Class Initialized
INFO - 2024-06-07 16:21:41 --> Router Class Initialized
INFO - 2024-06-07 16:21:41 --> Output Class Initialized
INFO - 2024-06-07 16:21:41 --> Security Class Initialized
DEBUG - 2024-06-07 16:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 16:21:41 --> Input Class Initialized
INFO - 2024-06-07 16:21:41 --> Language Class Initialized
INFO - 2024-06-07 16:21:41 --> Language Class Initialized
INFO - 2024-06-07 16:21:41 --> Config Class Initialized
INFO - 2024-06-07 16:21:41 --> Loader Class Initialized
INFO - 2024-06-07 16:21:41 --> Helper loaded: url_helper
INFO - 2024-06-07 16:21:41 --> Helper loaded: file_helper
INFO - 2024-06-07 16:21:41 --> Helper loaded: form_helper
INFO - 2024-06-07 16:21:41 --> Helper loaded: my_helper
INFO - 2024-06-07 16:21:41 --> Database Driver Class Initialized
INFO - 2024-06-07 16:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 16:21:41 --> Controller Class Initialized
INFO - 2024-06-07 16:21:41 --> Final output sent to browser
DEBUG - 2024-06-07 16:21:41 --> Total execution time: 0.0304
INFO - 2024-06-07 16:21:44 --> Config Class Initialized
INFO - 2024-06-07 16:21:44 --> Hooks Class Initialized
DEBUG - 2024-06-07 16:21:44 --> UTF-8 Support Enabled
INFO - 2024-06-07 16:21:44 --> Utf8 Class Initialized
INFO - 2024-06-07 16:21:44 --> URI Class Initialized
INFO - 2024-06-07 16:21:44 --> Router Class Initialized
INFO - 2024-06-07 16:21:44 --> Output Class Initialized
INFO - 2024-06-07 16:21:44 --> Security Class Initialized
DEBUG - 2024-06-07 16:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 16:21:44 --> Input Class Initialized
INFO - 2024-06-07 16:21:44 --> Language Class Initialized
INFO - 2024-06-07 16:21:44 --> Language Class Initialized
INFO - 2024-06-07 16:21:44 --> Config Class Initialized
INFO - 2024-06-07 16:21:44 --> Loader Class Initialized
INFO - 2024-06-07 16:21:44 --> Helper loaded: url_helper
INFO - 2024-06-07 16:21:44 --> Helper loaded: file_helper
INFO - 2024-06-07 16:21:44 --> Helper loaded: form_helper
INFO - 2024-06-07 16:21:44 --> Helper loaded: my_helper
INFO - 2024-06-07 16:21:44 --> Database Driver Class Initialized
INFO - 2024-06-07 16:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 16:21:44 --> Controller Class Initialized
INFO - 2024-06-07 16:21:44 --> Final output sent to browser
DEBUG - 2024-06-07 16:21:44 --> Total execution time: 0.0282
INFO - 2024-06-07 16:28:29 --> Config Class Initialized
INFO - 2024-06-07 16:28:29 --> Hooks Class Initialized
DEBUG - 2024-06-07 16:28:29 --> UTF-8 Support Enabled
INFO - 2024-06-07 16:28:29 --> Utf8 Class Initialized
INFO - 2024-06-07 16:28:29 --> URI Class Initialized
INFO - 2024-06-07 16:28:29 --> Router Class Initialized
INFO - 2024-06-07 16:28:29 --> Output Class Initialized
INFO - 2024-06-07 16:28:29 --> Security Class Initialized
DEBUG - 2024-06-07 16:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 16:28:29 --> Input Class Initialized
INFO - 2024-06-07 16:28:29 --> Language Class Initialized
INFO - 2024-06-07 16:28:29 --> Language Class Initialized
INFO - 2024-06-07 16:28:29 --> Config Class Initialized
INFO - 2024-06-07 16:28:29 --> Loader Class Initialized
INFO - 2024-06-07 16:28:29 --> Helper loaded: url_helper
INFO - 2024-06-07 16:28:29 --> Helper loaded: file_helper
INFO - 2024-06-07 16:28:29 --> Helper loaded: form_helper
INFO - 2024-06-07 16:28:29 --> Helper loaded: my_helper
INFO - 2024-06-07 16:28:29 --> Database Driver Class Initialized
INFO - 2024-06-07 16:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 16:28:29 --> Controller Class Initialized
INFO - 2024-06-07 16:28:29 --> Final output sent to browser
DEBUG - 2024-06-07 16:28:29 --> Total execution time: 0.0819
INFO - 2024-06-07 16:28:44 --> Config Class Initialized
INFO - 2024-06-07 16:28:44 --> Hooks Class Initialized
DEBUG - 2024-06-07 16:28:44 --> UTF-8 Support Enabled
INFO - 2024-06-07 16:28:44 --> Utf8 Class Initialized
INFO - 2024-06-07 16:28:44 --> URI Class Initialized
INFO - 2024-06-07 16:28:44 --> Router Class Initialized
INFO - 2024-06-07 16:28:44 --> Output Class Initialized
INFO - 2024-06-07 16:28:44 --> Security Class Initialized
DEBUG - 2024-06-07 16:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 16:28:44 --> Input Class Initialized
INFO - 2024-06-07 16:28:44 --> Language Class Initialized
INFO - 2024-06-07 16:28:44 --> Language Class Initialized
INFO - 2024-06-07 16:28:44 --> Config Class Initialized
INFO - 2024-06-07 16:28:44 --> Loader Class Initialized
INFO - 2024-06-07 16:28:44 --> Helper loaded: url_helper
INFO - 2024-06-07 16:28:44 --> Helper loaded: file_helper
INFO - 2024-06-07 16:28:44 --> Helper loaded: form_helper
INFO - 2024-06-07 16:28:44 --> Helper loaded: my_helper
INFO - 2024-06-07 16:28:44 --> Database Driver Class Initialized
INFO - 2024-06-07 16:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 16:28:44 --> Controller Class Initialized
INFO - 2024-06-07 16:28:44 --> Final output sent to browser
DEBUG - 2024-06-07 16:28:44 --> Total execution time: 0.0303
INFO - 2024-06-07 16:28:44 --> Config Class Initialized
INFO - 2024-06-07 16:28:44 --> Hooks Class Initialized
DEBUG - 2024-06-07 16:28:44 --> UTF-8 Support Enabled
INFO - 2024-06-07 16:28:44 --> Utf8 Class Initialized
INFO - 2024-06-07 16:28:44 --> URI Class Initialized
INFO - 2024-06-07 16:28:44 --> Router Class Initialized
INFO - 2024-06-07 16:28:44 --> Output Class Initialized
INFO - 2024-06-07 16:28:44 --> Security Class Initialized
DEBUG - 2024-06-07 16:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 16:28:44 --> Input Class Initialized
INFO - 2024-06-07 16:28:44 --> Language Class Initialized
INFO - 2024-06-07 16:28:44 --> Language Class Initialized
INFO - 2024-06-07 16:28:44 --> Config Class Initialized
INFO - 2024-06-07 16:28:44 --> Loader Class Initialized
INFO - 2024-06-07 16:28:44 --> Helper loaded: url_helper
INFO - 2024-06-07 16:28:44 --> Helper loaded: file_helper
INFO - 2024-06-07 16:28:44 --> Helper loaded: form_helper
INFO - 2024-06-07 16:28:44 --> Helper loaded: my_helper
INFO - 2024-06-07 16:28:44 --> Database Driver Class Initialized
INFO - 2024-06-07 16:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 16:28:44 --> Controller Class Initialized
INFO - 2024-06-07 16:28:46 --> Config Class Initialized
INFO - 2024-06-07 16:28:46 --> Hooks Class Initialized
DEBUG - 2024-06-07 16:28:46 --> UTF-8 Support Enabled
INFO - 2024-06-07 16:28:46 --> Utf8 Class Initialized
INFO - 2024-06-07 16:28:46 --> URI Class Initialized
INFO - 2024-06-07 16:28:46 --> Router Class Initialized
INFO - 2024-06-07 16:28:46 --> Output Class Initialized
INFO - 2024-06-07 16:28:46 --> Security Class Initialized
DEBUG - 2024-06-07 16:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 16:28:46 --> Input Class Initialized
INFO - 2024-06-07 16:28:46 --> Language Class Initialized
INFO - 2024-06-07 16:28:46 --> Language Class Initialized
INFO - 2024-06-07 16:28:46 --> Config Class Initialized
INFO - 2024-06-07 16:28:46 --> Loader Class Initialized
INFO - 2024-06-07 16:28:46 --> Helper loaded: url_helper
INFO - 2024-06-07 16:28:46 --> Helper loaded: file_helper
INFO - 2024-06-07 16:28:46 --> Helper loaded: form_helper
INFO - 2024-06-07 16:28:46 --> Helper loaded: my_helper
INFO - 2024-06-07 16:28:46 --> Database Driver Class Initialized
INFO - 2024-06-07 16:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 16:28:46 --> Controller Class Initialized
INFO - 2024-06-07 16:28:46 --> Final output sent to browser
DEBUG - 2024-06-07 16:28:46 --> Total execution time: 0.0781
INFO - 2024-06-07 16:28:47 --> Config Class Initialized
INFO - 2024-06-07 16:28:47 --> Hooks Class Initialized
DEBUG - 2024-06-07 16:28:47 --> UTF-8 Support Enabled
INFO - 2024-06-07 16:28:47 --> Utf8 Class Initialized
INFO - 2024-06-07 16:28:47 --> URI Class Initialized
INFO - 2024-06-07 16:28:47 --> Router Class Initialized
INFO - 2024-06-07 16:28:47 --> Output Class Initialized
INFO - 2024-06-07 16:28:47 --> Security Class Initialized
DEBUG - 2024-06-07 16:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 16:28:47 --> Input Class Initialized
INFO - 2024-06-07 16:28:47 --> Language Class Initialized
INFO - 2024-06-07 16:28:47 --> Language Class Initialized
INFO - 2024-06-07 16:28:47 --> Config Class Initialized
INFO - 2024-06-07 16:28:47 --> Loader Class Initialized
INFO - 2024-06-07 16:28:47 --> Helper loaded: url_helper
INFO - 2024-06-07 16:28:47 --> Helper loaded: file_helper
INFO - 2024-06-07 16:28:47 --> Helper loaded: form_helper
INFO - 2024-06-07 16:28:47 --> Helper loaded: my_helper
INFO - 2024-06-07 16:28:47 --> Database Driver Class Initialized
INFO - 2024-06-07 16:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 16:28:47 --> Controller Class Initialized
INFO - 2024-06-07 16:28:47 --> Final output sent to browser
DEBUG - 2024-06-07 16:28:47 --> Total execution time: 0.0281
INFO - 2024-06-07 16:28:58 --> Config Class Initialized
INFO - 2024-06-07 16:28:58 --> Hooks Class Initialized
DEBUG - 2024-06-07 16:28:58 --> UTF-8 Support Enabled
INFO - 2024-06-07 16:28:58 --> Utf8 Class Initialized
INFO - 2024-06-07 16:28:58 --> URI Class Initialized
INFO - 2024-06-07 16:28:58 --> Router Class Initialized
INFO - 2024-06-07 16:28:58 --> Output Class Initialized
INFO - 2024-06-07 16:28:58 --> Security Class Initialized
DEBUG - 2024-06-07 16:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 16:28:58 --> Input Class Initialized
INFO - 2024-06-07 16:28:58 --> Language Class Initialized
INFO - 2024-06-07 16:28:58 --> Language Class Initialized
INFO - 2024-06-07 16:28:58 --> Config Class Initialized
INFO - 2024-06-07 16:28:58 --> Loader Class Initialized
INFO - 2024-06-07 16:28:58 --> Helper loaded: url_helper
INFO - 2024-06-07 16:28:58 --> Helper loaded: file_helper
INFO - 2024-06-07 16:28:58 --> Helper loaded: form_helper
INFO - 2024-06-07 16:28:58 --> Helper loaded: my_helper
INFO - 2024-06-07 16:28:58 --> Database Driver Class Initialized
INFO - 2024-06-07 16:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 16:28:58 --> Controller Class Initialized
INFO - 2024-06-07 16:28:58 --> Final output sent to browser
DEBUG - 2024-06-07 16:28:58 --> Total execution time: 0.0409
INFO - 2024-06-07 16:28:58 --> Config Class Initialized
INFO - 2024-06-07 16:28:58 --> Hooks Class Initialized
DEBUG - 2024-06-07 16:28:58 --> UTF-8 Support Enabled
INFO - 2024-06-07 16:28:58 --> Utf8 Class Initialized
INFO - 2024-06-07 16:28:58 --> URI Class Initialized
INFO - 2024-06-07 16:28:58 --> Router Class Initialized
INFO - 2024-06-07 16:28:58 --> Output Class Initialized
INFO - 2024-06-07 16:28:58 --> Security Class Initialized
DEBUG - 2024-06-07 16:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 16:28:58 --> Input Class Initialized
INFO - 2024-06-07 16:28:58 --> Language Class Initialized
INFO - 2024-06-07 16:28:58 --> Language Class Initialized
INFO - 2024-06-07 16:28:58 --> Config Class Initialized
INFO - 2024-06-07 16:28:58 --> Loader Class Initialized
INFO - 2024-06-07 16:28:58 --> Helper loaded: url_helper
INFO - 2024-06-07 16:28:58 --> Helper loaded: file_helper
INFO - 2024-06-07 16:28:58 --> Helper loaded: form_helper
INFO - 2024-06-07 16:28:58 --> Helper loaded: my_helper
INFO - 2024-06-07 16:28:58 --> Database Driver Class Initialized
INFO - 2024-06-07 16:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 16:28:58 --> Controller Class Initialized
INFO - 2024-06-07 16:29:01 --> Config Class Initialized
INFO - 2024-06-07 16:29:01 --> Hooks Class Initialized
DEBUG - 2024-06-07 16:29:01 --> UTF-8 Support Enabled
INFO - 2024-06-07 16:29:01 --> Utf8 Class Initialized
INFO - 2024-06-07 16:29:01 --> URI Class Initialized
INFO - 2024-06-07 16:29:01 --> Router Class Initialized
INFO - 2024-06-07 16:29:01 --> Output Class Initialized
INFO - 2024-06-07 16:29:01 --> Security Class Initialized
DEBUG - 2024-06-07 16:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 16:29:01 --> Input Class Initialized
INFO - 2024-06-07 16:29:01 --> Language Class Initialized
INFO - 2024-06-07 16:29:01 --> Language Class Initialized
INFO - 2024-06-07 16:29:01 --> Config Class Initialized
INFO - 2024-06-07 16:29:01 --> Loader Class Initialized
INFO - 2024-06-07 16:29:01 --> Helper loaded: url_helper
INFO - 2024-06-07 16:29:01 --> Helper loaded: file_helper
INFO - 2024-06-07 16:29:01 --> Helper loaded: form_helper
INFO - 2024-06-07 16:29:01 --> Helper loaded: my_helper
INFO - 2024-06-07 16:29:01 --> Database Driver Class Initialized
INFO - 2024-06-07 16:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 16:29:01 --> Controller Class Initialized
INFO - 2024-06-07 16:29:01 --> Final output sent to browser
DEBUG - 2024-06-07 16:29:01 --> Total execution time: 0.0327
INFO - 2024-06-07 16:29:05 --> Config Class Initialized
INFO - 2024-06-07 16:29:05 --> Hooks Class Initialized
DEBUG - 2024-06-07 16:29:05 --> UTF-8 Support Enabled
INFO - 2024-06-07 16:29:05 --> Utf8 Class Initialized
INFO - 2024-06-07 16:29:05 --> URI Class Initialized
INFO - 2024-06-07 16:29:05 --> Router Class Initialized
INFO - 2024-06-07 16:29:05 --> Output Class Initialized
INFO - 2024-06-07 16:29:05 --> Security Class Initialized
DEBUG - 2024-06-07 16:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 16:29:05 --> Input Class Initialized
INFO - 2024-06-07 16:29:05 --> Language Class Initialized
INFO - 2024-06-07 16:29:05 --> Language Class Initialized
INFO - 2024-06-07 16:29:05 --> Config Class Initialized
INFO - 2024-06-07 16:29:05 --> Loader Class Initialized
INFO - 2024-06-07 16:29:05 --> Helper loaded: url_helper
INFO - 2024-06-07 16:29:05 --> Helper loaded: file_helper
INFO - 2024-06-07 16:29:05 --> Helper loaded: form_helper
INFO - 2024-06-07 16:29:05 --> Helper loaded: my_helper
INFO - 2024-06-07 16:29:05 --> Database Driver Class Initialized
INFO - 2024-06-07 16:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 16:29:05 --> Controller Class Initialized
INFO - 2024-06-07 16:29:05 --> Final output sent to browser
DEBUG - 2024-06-07 16:29:05 --> Total execution time: 0.0347
INFO - 2024-06-07 16:29:05 --> Config Class Initialized
INFO - 2024-06-07 16:29:05 --> Hooks Class Initialized
DEBUG - 2024-06-07 16:29:05 --> UTF-8 Support Enabled
INFO - 2024-06-07 16:29:05 --> Utf8 Class Initialized
INFO - 2024-06-07 16:29:05 --> URI Class Initialized
INFO - 2024-06-07 16:29:05 --> Router Class Initialized
INFO - 2024-06-07 16:29:05 --> Output Class Initialized
INFO - 2024-06-07 16:29:05 --> Security Class Initialized
DEBUG - 2024-06-07 16:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 16:29:05 --> Input Class Initialized
INFO - 2024-06-07 16:29:05 --> Language Class Initialized
INFO - 2024-06-07 16:29:05 --> Language Class Initialized
INFO - 2024-06-07 16:29:05 --> Config Class Initialized
INFO - 2024-06-07 16:29:05 --> Loader Class Initialized
INFO - 2024-06-07 16:29:05 --> Helper loaded: url_helper
INFO - 2024-06-07 16:29:05 --> Helper loaded: file_helper
INFO - 2024-06-07 16:29:05 --> Helper loaded: form_helper
INFO - 2024-06-07 16:29:05 --> Helper loaded: my_helper
INFO - 2024-06-07 16:29:05 --> Database Driver Class Initialized
INFO - 2024-06-07 16:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 16:29:05 --> Controller Class Initialized
INFO - 2024-06-07 16:29:21 --> Config Class Initialized
INFO - 2024-06-07 16:29:21 --> Hooks Class Initialized
DEBUG - 2024-06-07 16:29:21 --> UTF-8 Support Enabled
INFO - 2024-06-07 16:29:21 --> Utf8 Class Initialized
INFO - 2024-06-07 16:29:21 --> URI Class Initialized
INFO - 2024-06-07 16:29:21 --> Router Class Initialized
INFO - 2024-06-07 16:29:21 --> Output Class Initialized
INFO - 2024-06-07 16:29:21 --> Security Class Initialized
DEBUG - 2024-06-07 16:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 16:29:21 --> Input Class Initialized
INFO - 2024-06-07 16:29:21 --> Language Class Initialized
INFO - 2024-06-07 16:29:21 --> Language Class Initialized
INFO - 2024-06-07 16:29:21 --> Config Class Initialized
INFO - 2024-06-07 16:29:21 --> Loader Class Initialized
INFO - 2024-06-07 16:29:21 --> Helper loaded: url_helper
INFO - 2024-06-07 16:29:21 --> Helper loaded: file_helper
INFO - 2024-06-07 16:29:21 --> Helper loaded: form_helper
INFO - 2024-06-07 16:29:21 --> Helper loaded: my_helper
INFO - 2024-06-07 16:29:21 --> Database Driver Class Initialized
INFO - 2024-06-07 16:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 16:29:21 --> Controller Class Initialized
INFO - 2024-06-07 16:38:42 --> Config Class Initialized
INFO - 2024-06-07 16:38:42 --> Hooks Class Initialized
DEBUG - 2024-06-07 16:38:42 --> UTF-8 Support Enabled
INFO - 2024-06-07 16:38:42 --> Utf8 Class Initialized
INFO - 2024-06-07 16:38:42 --> URI Class Initialized
INFO - 2024-06-07 16:38:42 --> Router Class Initialized
INFO - 2024-06-07 16:38:42 --> Output Class Initialized
INFO - 2024-06-07 16:38:42 --> Security Class Initialized
DEBUG - 2024-06-07 16:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 16:38:42 --> Input Class Initialized
INFO - 2024-06-07 16:38:42 --> Language Class Initialized
INFO - 2024-06-07 16:38:42 --> Language Class Initialized
INFO - 2024-06-07 16:38:42 --> Config Class Initialized
INFO - 2024-06-07 16:38:42 --> Loader Class Initialized
INFO - 2024-06-07 16:38:42 --> Helper loaded: url_helper
INFO - 2024-06-07 16:38:42 --> Helper loaded: file_helper
INFO - 2024-06-07 16:38:42 --> Helper loaded: form_helper
INFO - 2024-06-07 16:38:42 --> Helper loaded: my_helper
INFO - 2024-06-07 16:38:42 --> Database Driver Class Initialized
INFO - 2024-06-07 16:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 16:38:42 --> Controller Class Initialized
DEBUG - 2024-06-07 16:38:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-06-07 16:38:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 16:38:42 --> Final output sent to browser
DEBUG - 2024-06-07 16:38:42 --> Total execution time: 0.0586
INFO - 2024-06-07 16:38:47 --> Config Class Initialized
INFO - 2024-06-07 16:38:47 --> Hooks Class Initialized
DEBUG - 2024-06-07 16:38:47 --> UTF-8 Support Enabled
INFO - 2024-06-07 16:38:47 --> Utf8 Class Initialized
INFO - 2024-06-07 16:38:47 --> URI Class Initialized
INFO - 2024-06-07 16:38:47 --> Router Class Initialized
INFO - 2024-06-07 16:38:47 --> Output Class Initialized
INFO - 2024-06-07 16:38:47 --> Security Class Initialized
DEBUG - 2024-06-07 16:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 16:38:47 --> Input Class Initialized
INFO - 2024-06-07 16:38:47 --> Language Class Initialized
INFO - 2024-06-07 16:38:47 --> Language Class Initialized
INFO - 2024-06-07 16:38:47 --> Config Class Initialized
INFO - 2024-06-07 16:38:47 --> Loader Class Initialized
INFO - 2024-06-07 16:38:47 --> Helper loaded: url_helper
INFO - 2024-06-07 16:38:47 --> Helper loaded: file_helper
INFO - 2024-06-07 16:38:47 --> Helper loaded: form_helper
INFO - 2024-06-07 16:38:47 --> Helper loaded: my_helper
INFO - 2024-06-07 16:38:47 --> Database Driver Class Initialized
INFO - 2024-06-07 16:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 16:38:47 --> Controller Class Initialized
INFO - 2024-06-07 16:38:48 --> Config Class Initialized
INFO - 2024-06-07 16:38:48 --> Hooks Class Initialized
DEBUG - 2024-06-07 16:38:48 --> UTF-8 Support Enabled
INFO - 2024-06-07 16:38:48 --> Utf8 Class Initialized
INFO - 2024-06-07 16:38:48 --> URI Class Initialized
INFO - 2024-06-07 16:38:48 --> Router Class Initialized
INFO - 2024-06-07 16:38:48 --> Output Class Initialized
INFO - 2024-06-07 16:38:48 --> Security Class Initialized
DEBUG - 2024-06-07 16:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 16:38:48 --> Input Class Initialized
INFO - 2024-06-07 16:38:48 --> Language Class Initialized
INFO - 2024-06-07 16:38:48 --> Language Class Initialized
INFO - 2024-06-07 16:38:48 --> Config Class Initialized
INFO - 2024-06-07 16:38:48 --> Loader Class Initialized
INFO - 2024-06-07 16:38:48 --> Helper loaded: url_helper
INFO - 2024-06-07 16:38:48 --> Helper loaded: file_helper
INFO - 2024-06-07 16:38:48 --> Helper loaded: form_helper
INFO - 2024-06-07 16:38:48 --> Helper loaded: my_helper
INFO - 2024-06-07 16:38:48 --> Database Driver Class Initialized
INFO - 2024-06-07 16:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 16:38:48 --> Controller Class Initialized
DEBUG - 2024-06-07 16:38:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-07 16:38:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-07 16:38:48 --> Final output sent to browser
DEBUG - 2024-06-07 16:38:48 --> Total execution time: 0.0435
INFO - 2024-06-07 16:38:48 --> Config Class Initialized
INFO - 2024-06-07 16:38:48 --> Hooks Class Initialized
DEBUG - 2024-06-07 16:38:48 --> UTF-8 Support Enabled
INFO - 2024-06-07 16:38:48 --> Utf8 Class Initialized
INFO - 2024-06-07 16:38:48 --> URI Class Initialized
INFO - 2024-06-07 16:38:48 --> Router Class Initialized
INFO - 2024-06-07 16:38:48 --> Output Class Initialized
INFO - 2024-06-07 16:38:48 --> Security Class Initialized
DEBUG - 2024-06-07 16:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 16:38:48 --> Input Class Initialized
INFO - 2024-06-07 16:38:48 --> Language Class Initialized
INFO - 2024-06-07 16:38:48 --> Language Class Initialized
INFO - 2024-06-07 16:38:48 --> Config Class Initialized
INFO - 2024-06-07 16:38:48 --> Loader Class Initialized
INFO - 2024-06-07 16:38:48 --> Helper loaded: url_helper
INFO - 2024-06-07 16:38:48 --> Helper loaded: file_helper
INFO - 2024-06-07 16:38:48 --> Helper loaded: form_helper
INFO - 2024-06-07 16:38:48 --> Helper loaded: my_helper
INFO - 2024-06-07 16:38:48 --> Database Driver Class Initialized
INFO - 2024-06-07 16:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 16:38:48 --> Controller Class Initialized
INFO - 2024-06-07 16:38:51 --> Config Class Initialized
INFO - 2024-06-07 16:38:51 --> Hooks Class Initialized
DEBUG - 2024-06-07 16:38:51 --> UTF-8 Support Enabled
INFO - 2024-06-07 16:38:51 --> Utf8 Class Initialized
INFO - 2024-06-07 16:38:51 --> URI Class Initialized
INFO - 2024-06-07 16:38:51 --> Router Class Initialized
INFO - 2024-06-07 16:38:51 --> Output Class Initialized
INFO - 2024-06-07 16:38:51 --> Security Class Initialized
DEBUG - 2024-06-07 16:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 16:38:51 --> Input Class Initialized
INFO - 2024-06-07 16:38:51 --> Language Class Initialized
INFO - 2024-06-07 16:38:51 --> Language Class Initialized
INFO - 2024-06-07 16:38:51 --> Config Class Initialized
INFO - 2024-06-07 16:38:51 --> Loader Class Initialized
INFO - 2024-06-07 16:38:51 --> Helper loaded: url_helper
INFO - 2024-06-07 16:38:51 --> Helper loaded: file_helper
INFO - 2024-06-07 16:38:51 --> Helper loaded: form_helper
INFO - 2024-06-07 16:38:51 --> Helper loaded: my_helper
INFO - 2024-06-07 16:38:51 --> Database Driver Class Initialized
INFO - 2024-06-07 16:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 16:38:51 --> Controller Class Initialized
INFO - 2024-06-07 16:38:51 --> Final output sent to browser
DEBUG - 2024-06-07 16:38:51 --> Total execution time: 0.0288
INFO - 2024-06-07 16:38:59 --> Config Class Initialized
INFO - 2024-06-07 16:38:59 --> Hooks Class Initialized
DEBUG - 2024-06-07 16:38:59 --> UTF-8 Support Enabled
INFO - 2024-06-07 16:38:59 --> Utf8 Class Initialized
INFO - 2024-06-07 16:38:59 --> URI Class Initialized
INFO - 2024-06-07 16:38:59 --> Router Class Initialized
INFO - 2024-06-07 16:38:59 --> Output Class Initialized
INFO - 2024-06-07 16:38:59 --> Security Class Initialized
DEBUG - 2024-06-07 16:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 16:38:59 --> Input Class Initialized
INFO - 2024-06-07 16:38:59 --> Language Class Initialized
INFO - 2024-06-07 16:38:59 --> Language Class Initialized
INFO - 2024-06-07 16:38:59 --> Config Class Initialized
INFO - 2024-06-07 16:38:59 --> Loader Class Initialized
INFO - 2024-06-07 16:38:59 --> Helper loaded: url_helper
INFO - 2024-06-07 16:38:59 --> Helper loaded: file_helper
INFO - 2024-06-07 16:38:59 --> Helper loaded: form_helper
INFO - 2024-06-07 16:38:59 --> Helper loaded: my_helper
INFO - 2024-06-07 16:38:59 --> Database Driver Class Initialized
INFO - 2024-06-07 16:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 16:38:59 --> Controller Class Initialized
INFO - 2024-06-07 16:38:59 --> Final output sent to browser
DEBUG - 2024-06-07 16:38:59 --> Total execution time: 0.0361
INFO - 2024-06-07 16:39:02 --> Config Class Initialized
INFO - 2024-06-07 16:39:02 --> Hooks Class Initialized
DEBUG - 2024-06-07 16:39:02 --> UTF-8 Support Enabled
INFO - 2024-06-07 16:39:02 --> Utf8 Class Initialized
INFO - 2024-06-07 16:39:02 --> URI Class Initialized
INFO - 2024-06-07 16:39:02 --> Router Class Initialized
INFO - 2024-06-07 16:39:02 --> Output Class Initialized
INFO - 2024-06-07 16:39:02 --> Security Class Initialized
DEBUG - 2024-06-07 16:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-07 16:39:02 --> Input Class Initialized
INFO - 2024-06-07 16:39:02 --> Language Class Initialized
INFO - 2024-06-07 16:39:02 --> Language Class Initialized
INFO - 2024-06-07 16:39:02 --> Config Class Initialized
INFO - 2024-06-07 16:39:02 --> Loader Class Initialized
INFO - 2024-06-07 16:39:02 --> Helper loaded: url_helper
INFO - 2024-06-07 16:39:02 --> Helper loaded: file_helper
INFO - 2024-06-07 16:39:02 --> Helper loaded: form_helper
INFO - 2024-06-07 16:39:02 --> Helper loaded: my_helper
INFO - 2024-06-07 16:39:02 --> Database Driver Class Initialized
INFO - 2024-06-07 16:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-07 16:39:02 --> Controller Class Initialized
INFO - 2024-06-07 16:39:02 --> Final output sent to browser
DEBUG - 2024-06-07 16:39:02 --> Total execution time: 0.1476
