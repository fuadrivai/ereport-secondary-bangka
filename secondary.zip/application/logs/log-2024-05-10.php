<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-05-10 20:11:12 --> Config Class Initialized
INFO - 2024-05-10 20:11:12 --> Hooks Class Initialized
DEBUG - 2024-05-10 20:11:12 --> UTF-8 Support Enabled
INFO - 2024-05-10 20:11:12 --> Utf8 Class Initialized
INFO - 2024-05-10 20:11:12 --> URI Class Initialized
INFO - 2024-05-10 20:11:12 --> Router Class Initialized
INFO - 2024-05-10 20:11:12 --> Output Class Initialized
INFO - 2024-05-10 20:11:13 --> Security Class Initialized
DEBUG - 2024-05-10 20:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-10 20:11:13 --> Input Class Initialized
INFO - 2024-05-10 20:11:13 --> Language Class Initialized
INFO - 2024-05-10 20:11:13 --> Language Class Initialized
INFO - 2024-05-10 20:11:13 --> Config Class Initialized
INFO - 2024-05-10 20:11:13 --> Loader Class Initialized
INFO - 2024-05-10 20:11:13 --> Helper loaded: url_helper
INFO - 2024-05-10 20:11:13 --> Helper loaded: file_helper
INFO - 2024-05-10 20:11:13 --> Helper loaded: form_helper
INFO - 2024-05-10 20:11:13 --> Helper loaded: my_helper
INFO - 2024-05-10 20:11:13 --> Database Driver Class Initialized
ERROR - 2024-05-10 20:11:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2024-05-10 20:11:13 --> Unable to connect to the database
INFO - 2024-05-10 20:11:13 --> Language file loaded: language/english/db_lang.php
