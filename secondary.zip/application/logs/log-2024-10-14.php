<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-14 07:41:40 --> Config Class Initialized
INFO - 2024-10-14 07:41:40 --> Hooks Class Initialized
DEBUG - 2024-10-14 07:41:40 --> UTF-8 Support Enabled
INFO - 2024-10-14 07:41:40 --> Utf8 Class Initialized
INFO - 2024-10-14 07:41:40 --> URI Class Initialized
INFO - 2024-10-14 07:41:40 --> Router Class Initialized
INFO - 2024-10-14 07:41:40 --> Output Class Initialized
INFO - 2024-10-14 07:41:40 --> Security Class Initialized
DEBUG - 2024-10-14 07:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 07:41:40 --> Input Class Initialized
INFO - 2024-10-14 07:41:40 --> Language Class Initialized
INFO - 2024-10-14 07:41:40 --> Language Class Initialized
INFO - 2024-10-14 07:41:40 --> Config Class Initialized
INFO - 2024-10-14 07:41:40 --> Loader Class Initialized
INFO - 2024-10-14 07:41:40 --> Helper loaded: url_helper
INFO - 2024-10-14 07:41:40 --> Helper loaded: file_helper
INFO - 2024-10-14 07:41:40 --> Helper loaded: form_helper
INFO - 2024-10-14 07:41:40 --> Helper loaded: my_helper
INFO - 2024-10-14 07:41:40 --> Database Driver Class Initialized
INFO - 2024-10-14 07:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 07:41:40 --> Controller Class Initialized
ERROR - 2024-10-14 07:41:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2392
DEBUG - 2024-10-14 07:41:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-14 07:41:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 07:41:40 --> Final output sent to browser
DEBUG - 2024-10-14 07:41:40 --> Total execution time: 0.0720
INFO - 2024-10-14 08:43:24 --> Config Class Initialized
INFO - 2024-10-14 08:43:24 --> Hooks Class Initialized
DEBUG - 2024-10-14 08:43:24 --> UTF-8 Support Enabled
INFO - 2024-10-14 08:43:24 --> Utf8 Class Initialized
INFO - 2024-10-14 08:43:24 --> URI Class Initialized
INFO - 2024-10-14 08:43:24 --> Router Class Initialized
INFO - 2024-10-14 08:43:24 --> Output Class Initialized
INFO - 2024-10-14 08:43:24 --> Security Class Initialized
DEBUG - 2024-10-14 08:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 08:43:24 --> Input Class Initialized
INFO - 2024-10-14 08:43:24 --> Language Class Initialized
INFO - 2024-10-14 08:43:24 --> Language Class Initialized
INFO - 2024-10-14 08:43:24 --> Config Class Initialized
INFO - 2024-10-14 08:43:24 --> Loader Class Initialized
INFO - 2024-10-14 08:43:24 --> Helper loaded: url_helper
INFO - 2024-10-14 08:43:24 --> Helper loaded: file_helper
INFO - 2024-10-14 08:43:24 --> Helper loaded: form_helper
INFO - 2024-10-14 08:43:24 --> Helper loaded: my_helper
INFO - 2024-10-14 08:43:24 --> Database Driver Class Initialized
INFO - 2024-10-14 08:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 08:43:24 --> Controller Class Initialized
INFO - 2024-10-14 08:43:24 --> Helper loaded: cookie_helper
INFO - 2024-10-14 08:43:24 --> Final output sent to browser
DEBUG - 2024-10-14 08:43:24 --> Total execution time: 0.0612
INFO - 2024-10-14 08:43:24 --> Config Class Initialized
INFO - 2024-10-14 08:43:24 --> Hooks Class Initialized
DEBUG - 2024-10-14 08:43:24 --> UTF-8 Support Enabled
INFO - 2024-10-14 08:43:24 --> Utf8 Class Initialized
INFO - 2024-10-14 08:43:24 --> URI Class Initialized
INFO - 2024-10-14 08:43:24 --> Router Class Initialized
INFO - 2024-10-14 08:43:24 --> Output Class Initialized
INFO - 2024-10-14 08:43:24 --> Security Class Initialized
DEBUG - 2024-10-14 08:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 08:43:24 --> Input Class Initialized
INFO - 2024-10-14 08:43:24 --> Language Class Initialized
INFO - 2024-10-14 08:43:24 --> Language Class Initialized
INFO - 2024-10-14 08:43:24 --> Config Class Initialized
INFO - 2024-10-14 08:43:24 --> Loader Class Initialized
INFO - 2024-10-14 08:43:24 --> Helper loaded: url_helper
INFO - 2024-10-14 08:43:24 --> Helper loaded: file_helper
INFO - 2024-10-14 08:43:24 --> Helper loaded: form_helper
INFO - 2024-10-14 08:43:24 --> Helper loaded: my_helper
INFO - 2024-10-14 08:43:24 --> Database Driver Class Initialized
INFO - 2024-10-14 08:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 08:43:24 --> Controller Class Initialized
INFO - 2024-10-14 08:43:24 --> Helper loaded: cookie_helper
INFO - 2024-10-14 08:43:24 --> Config Class Initialized
INFO - 2024-10-14 08:43:24 --> Hooks Class Initialized
DEBUG - 2024-10-14 08:43:24 --> UTF-8 Support Enabled
INFO - 2024-10-14 08:43:24 --> Utf8 Class Initialized
INFO - 2024-10-14 08:43:24 --> URI Class Initialized
INFO - 2024-10-14 08:43:24 --> Router Class Initialized
INFO - 2024-10-14 08:43:24 --> Output Class Initialized
INFO - 2024-10-14 08:43:24 --> Security Class Initialized
DEBUG - 2024-10-14 08:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 08:43:24 --> Input Class Initialized
INFO - 2024-10-14 08:43:24 --> Language Class Initialized
INFO - 2024-10-14 08:43:24 --> Language Class Initialized
INFO - 2024-10-14 08:43:24 --> Config Class Initialized
INFO - 2024-10-14 08:43:24 --> Loader Class Initialized
INFO - 2024-10-14 08:43:24 --> Helper loaded: url_helper
INFO - 2024-10-14 08:43:24 --> Helper loaded: file_helper
INFO - 2024-10-14 08:43:24 --> Helper loaded: form_helper
INFO - 2024-10-14 08:43:24 --> Helper loaded: my_helper
INFO - 2024-10-14 08:43:24 --> Database Driver Class Initialized
INFO - 2024-10-14 08:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 08:43:24 --> Controller Class Initialized
DEBUG - 2024-10-14 08:43:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-14 08:43:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 08:43:24 --> Final output sent to browser
DEBUG - 2024-10-14 08:43:24 --> Total execution time: 0.0438
INFO - 2024-10-14 08:43:42 --> Config Class Initialized
INFO - 2024-10-14 08:43:42 --> Hooks Class Initialized
DEBUG - 2024-10-14 08:43:42 --> UTF-8 Support Enabled
INFO - 2024-10-14 08:43:42 --> Utf8 Class Initialized
INFO - 2024-10-14 08:43:42 --> URI Class Initialized
INFO - 2024-10-14 08:43:42 --> Router Class Initialized
INFO - 2024-10-14 08:43:42 --> Output Class Initialized
INFO - 2024-10-14 08:43:42 --> Security Class Initialized
DEBUG - 2024-10-14 08:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 08:43:42 --> Input Class Initialized
INFO - 2024-10-14 08:43:42 --> Language Class Initialized
INFO - 2024-10-14 08:43:42 --> Language Class Initialized
INFO - 2024-10-14 08:43:42 --> Config Class Initialized
INFO - 2024-10-14 08:43:42 --> Loader Class Initialized
INFO - 2024-10-14 08:43:42 --> Helper loaded: url_helper
INFO - 2024-10-14 08:43:42 --> Helper loaded: file_helper
INFO - 2024-10-14 08:43:42 --> Helper loaded: form_helper
INFO - 2024-10-14 08:43:42 --> Helper loaded: my_helper
INFO - 2024-10-14 08:43:42 --> Database Driver Class Initialized
INFO - 2024-10-14 08:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 08:43:42 --> Controller Class Initialized
ERROR - 2024-10-14 08:43:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-14 08:43:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-14 08:43:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-14 08:43:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-14 08:43:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-14 08:43:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-14 08:43:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-14 08:43:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-14 08:43:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-14 08:43:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-14 08:43:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-14 08:43:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-14 08:43:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-14 08:43:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-14 08:43:45 --> Final output sent to browser
DEBUG - 2024-10-14 08:43:45 --> Total execution time: 2.9345
INFO - 2024-10-14 08:43:51 --> Config Class Initialized
INFO - 2024-10-14 08:43:51 --> Hooks Class Initialized
DEBUG - 2024-10-14 08:43:51 --> UTF-8 Support Enabled
INFO - 2024-10-14 08:43:51 --> Utf8 Class Initialized
INFO - 2024-10-14 08:43:51 --> URI Class Initialized
INFO - 2024-10-14 08:43:51 --> Router Class Initialized
INFO - 2024-10-14 08:43:51 --> Output Class Initialized
INFO - 2024-10-14 08:43:51 --> Security Class Initialized
DEBUG - 2024-10-14 08:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 08:43:51 --> Input Class Initialized
INFO - 2024-10-14 08:43:51 --> Language Class Initialized
INFO - 2024-10-14 08:43:51 --> Language Class Initialized
INFO - 2024-10-14 08:43:51 --> Config Class Initialized
INFO - 2024-10-14 08:43:51 --> Loader Class Initialized
INFO - 2024-10-14 08:43:51 --> Helper loaded: url_helper
INFO - 2024-10-14 08:43:51 --> Helper loaded: file_helper
INFO - 2024-10-14 08:43:51 --> Helper loaded: form_helper
INFO - 2024-10-14 08:43:51 --> Helper loaded: my_helper
INFO - 2024-10-14 08:43:51 --> Database Driver Class Initialized
INFO - 2024-10-14 08:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 08:43:51 --> Controller Class Initialized
ERROR - 2024-10-14 08:43:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-14 08:43:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-14 08:43:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-14 08:43:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-14 08:43:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-14 08:43:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-14 08:43:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-14 08:43:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-14 08:43:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-14 08:43:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-14 08:43:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-14 08:43:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-14 08:43:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-14 08:43:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-14 08:43:54 --> Final output sent to browser
DEBUG - 2024-10-14 08:43:54 --> Total execution time: 2.7959
INFO - 2024-10-14 08:44:46 --> Config Class Initialized
INFO - 2024-10-14 08:44:46 --> Hooks Class Initialized
DEBUG - 2024-10-14 08:44:46 --> UTF-8 Support Enabled
INFO - 2024-10-14 08:44:46 --> Utf8 Class Initialized
INFO - 2024-10-14 08:44:46 --> URI Class Initialized
INFO - 2024-10-14 08:44:46 --> Router Class Initialized
INFO - 2024-10-14 08:44:46 --> Output Class Initialized
INFO - 2024-10-14 08:44:46 --> Security Class Initialized
DEBUG - 2024-10-14 08:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 08:44:46 --> Input Class Initialized
INFO - 2024-10-14 08:44:46 --> Language Class Initialized
INFO - 2024-10-14 08:44:46 --> Language Class Initialized
INFO - 2024-10-14 08:44:46 --> Config Class Initialized
INFO - 2024-10-14 08:44:46 --> Loader Class Initialized
INFO - 2024-10-14 08:44:46 --> Helper loaded: url_helper
INFO - 2024-10-14 08:44:46 --> Helper loaded: file_helper
INFO - 2024-10-14 08:44:46 --> Helper loaded: form_helper
INFO - 2024-10-14 08:44:46 --> Helper loaded: my_helper
INFO - 2024-10-14 08:44:46 --> Database Driver Class Initialized
INFO - 2024-10-14 08:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 08:44:46 --> Controller Class Initialized
ERROR - 2024-10-14 08:44:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-10-14 08:44:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-10-14 08:44:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-10-14 08:44:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-10-14 08:44:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-10-14 08:44:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-10-14 08:44:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-10-14 08:44:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-10-14 08:44:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-10-14 08:44:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-10-14 08:44:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-10-14 08:44:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-10-14 08:44:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-10-14 08:44:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-10-14 08:44:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-10-14 08:44:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-10-14 08:44:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-10-14 08:44:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-10-14 08:44:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-10-14 08:44:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-10-14 08:44:49 --> Final output sent to browser
DEBUG - 2024-10-14 08:44:49 --> Total execution time: 2.8352
INFO - 2024-10-14 08:45:07 --> Config Class Initialized
INFO - 2024-10-14 08:45:07 --> Hooks Class Initialized
DEBUG - 2024-10-14 08:45:07 --> UTF-8 Support Enabled
INFO - 2024-10-14 08:45:07 --> Utf8 Class Initialized
INFO - 2024-10-14 08:45:07 --> URI Class Initialized
INFO - 2024-10-14 08:45:07 --> Router Class Initialized
INFO - 2024-10-14 08:45:07 --> Output Class Initialized
INFO - 2024-10-14 08:45:07 --> Security Class Initialized
DEBUG - 2024-10-14 08:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 08:45:07 --> Input Class Initialized
INFO - 2024-10-14 08:45:07 --> Language Class Initialized
INFO - 2024-10-14 08:45:07 --> Language Class Initialized
INFO - 2024-10-14 08:45:07 --> Config Class Initialized
INFO - 2024-10-14 08:45:07 --> Loader Class Initialized
INFO - 2024-10-14 08:45:07 --> Helper loaded: url_helper
INFO - 2024-10-14 08:45:07 --> Helper loaded: file_helper
INFO - 2024-10-14 08:45:07 --> Helper loaded: form_helper
INFO - 2024-10-14 08:45:07 --> Helper loaded: my_helper
INFO - 2024-10-14 08:45:07 --> Database Driver Class Initialized
INFO - 2024-10-14 08:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 08:45:07 --> Controller Class Initialized
DEBUG - 2024-10-14 08:45:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-10-14 08:45:11 --> Final output sent to browser
DEBUG - 2024-10-14 08:45:11 --> Total execution time: 4.1782
INFO - 2024-10-14 08:45:27 --> Config Class Initialized
INFO - 2024-10-14 08:45:27 --> Hooks Class Initialized
DEBUG - 2024-10-14 08:45:27 --> UTF-8 Support Enabled
INFO - 2024-10-14 08:45:27 --> Utf8 Class Initialized
INFO - 2024-10-14 08:45:27 --> URI Class Initialized
INFO - 2024-10-14 08:45:27 --> Router Class Initialized
INFO - 2024-10-14 08:45:27 --> Output Class Initialized
INFO - 2024-10-14 08:45:27 --> Security Class Initialized
DEBUG - 2024-10-14 08:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 08:45:27 --> Input Class Initialized
INFO - 2024-10-14 08:45:27 --> Language Class Initialized
INFO - 2024-10-14 08:45:27 --> Language Class Initialized
INFO - 2024-10-14 08:45:27 --> Config Class Initialized
INFO - 2024-10-14 08:45:27 --> Loader Class Initialized
INFO - 2024-10-14 08:45:27 --> Helper loaded: url_helper
INFO - 2024-10-14 08:45:27 --> Helper loaded: file_helper
INFO - 2024-10-14 08:45:27 --> Helper loaded: form_helper
INFO - 2024-10-14 08:45:27 --> Helper loaded: my_helper
INFO - 2024-10-14 08:45:27 --> Database Driver Class Initialized
INFO - 2024-10-14 08:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 08:45:27 --> Controller Class Initialized
ERROR - 2024-10-14 08:45:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1797
ERROR - 2024-10-14 08:45:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1804
ERROR - 2024-10-14 08:45:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-10-14 08:45:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-10-14 08:45:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-10-14 08:45:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 86
ERROR - 2024-10-14 08:45:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-10-14 08:45:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-10-14 08:45:27 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-10-14 08:45:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-10-14 08:45:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-10-14 08:45:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
ERROR - 2024-10-14 08:45:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
ERROR - 2024-10-14 08:45:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
INFO - 2024-10-14 08:45:31 --> Final output sent to browser
DEBUG - 2024-10-14 08:45:31 --> Total execution time: 3.7430
INFO - 2024-10-14 08:45:42 --> Config Class Initialized
INFO - 2024-10-14 08:45:42 --> Hooks Class Initialized
DEBUG - 2024-10-14 08:45:42 --> UTF-8 Support Enabled
INFO - 2024-10-14 08:45:42 --> Utf8 Class Initialized
INFO - 2024-10-14 08:45:42 --> URI Class Initialized
INFO - 2024-10-14 08:45:42 --> Router Class Initialized
INFO - 2024-10-14 08:45:42 --> Output Class Initialized
INFO - 2024-10-14 08:45:42 --> Security Class Initialized
DEBUG - 2024-10-14 08:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 08:45:42 --> Input Class Initialized
INFO - 2024-10-14 08:45:42 --> Language Class Initialized
INFO - 2024-10-14 08:45:42 --> Language Class Initialized
INFO - 2024-10-14 08:45:42 --> Config Class Initialized
INFO - 2024-10-14 08:45:42 --> Loader Class Initialized
INFO - 2024-10-14 08:45:42 --> Helper loaded: url_helper
INFO - 2024-10-14 08:45:42 --> Helper loaded: file_helper
INFO - 2024-10-14 08:45:42 --> Helper loaded: form_helper
INFO - 2024-10-14 08:45:42 --> Helper loaded: my_helper
INFO - 2024-10-14 08:45:42 --> Database Driver Class Initialized
INFO - 2024-10-14 08:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 08:45:42 --> Controller Class Initialized
DEBUG - 2024-10-14 08:45:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-14 08:45:46 --> Final output sent to browser
DEBUG - 2024-10-14 08:45:46 --> Total execution time: 3.6451
INFO - 2024-10-14 08:56:13 --> Config Class Initialized
INFO - 2024-10-14 08:56:13 --> Hooks Class Initialized
DEBUG - 2024-10-14 08:56:13 --> UTF-8 Support Enabled
INFO - 2024-10-14 08:56:13 --> Utf8 Class Initialized
INFO - 2024-10-14 08:56:13 --> URI Class Initialized
INFO - 2024-10-14 08:56:13 --> Router Class Initialized
INFO - 2024-10-14 08:56:13 --> Output Class Initialized
INFO - 2024-10-14 08:56:13 --> Security Class Initialized
DEBUG - 2024-10-14 08:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 08:56:13 --> Input Class Initialized
INFO - 2024-10-14 08:56:13 --> Language Class Initialized
INFO - 2024-10-14 08:56:13 --> Language Class Initialized
INFO - 2024-10-14 08:56:13 --> Config Class Initialized
INFO - 2024-10-14 08:56:13 --> Loader Class Initialized
INFO - 2024-10-14 08:56:13 --> Helper loaded: url_helper
INFO - 2024-10-14 08:56:13 --> Helper loaded: file_helper
INFO - 2024-10-14 08:56:13 --> Helper loaded: form_helper
INFO - 2024-10-14 08:56:13 --> Helper loaded: my_helper
INFO - 2024-10-14 08:56:13 --> Database Driver Class Initialized
INFO - 2024-10-14 08:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 08:56:13 --> Controller Class Initialized
DEBUG - 2024-10-14 08:56:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-14 08:56:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 08:56:13 --> Final output sent to browser
DEBUG - 2024-10-14 08:56:13 --> Total execution time: 0.0371
INFO - 2024-10-14 08:56:18 --> Config Class Initialized
INFO - 2024-10-14 08:56:18 --> Hooks Class Initialized
DEBUG - 2024-10-14 08:56:18 --> UTF-8 Support Enabled
INFO - 2024-10-14 08:56:18 --> Utf8 Class Initialized
INFO - 2024-10-14 08:56:18 --> URI Class Initialized
INFO - 2024-10-14 08:56:18 --> Router Class Initialized
INFO - 2024-10-14 08:56:18 --> Output Class Initialized
INFO - 2024-10-14 08:56:18 --> Security Class Initialized
DEBUG - 2024-10-14 08:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 08:56:18 --> Input Class Initialized
INFO - 2024-10-14 08:56:18 --> Language Class Initialized
INFO - 2024-10-14 08:56:18 --> Language Class Initialized
INFO - 2024-10-14 08:56:18 --> Config Class Initialized
INFO - 2024-10-14 08:56:18 --> Loader Class Initialized
INFO - 2024-10-14 08:56:18 --> Helper loaded: url_helper
INFO - 2024-10-14 08:56:18 --> Helper loaded: file_helper
INFO - 2024-10-14 08:56:18 --> Helper loaded: form_helper
INFO - 2024-10-14 08:56:18 --> Helper loaded: my_helper
INFO - 2024-10-14 08:56:18 --> Database Driver Class Initialized
INFO - 2024-10-14 08:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 08:56:18 --> Controller Class Initialized
INFO - 2024-10-14 08:56:18 --> Helper loaded: cookie_helper
INFO - 2024-10-14 08:56:18 --> Final output sent to browser
DEBUG - 2024-10-14 08:56:18 --> Total execution time: 0.0314
INFO - 2024-10-14 08:56:18 --> Config Class Initialized
INFO - 2024-10-14 08:56:18 --> Hooks Class Initialized
DEBUG - 2024-10-14 08:56:18 --> UTF-8 Support Enabled
INFO - 2024-10-14 08:56:18 --> Utf8 Class Initialized
INFO - 2024-10-14 08:56:18 --> URI Class Initialized
INFO - 2024-10-14 08:56:18 --> Router Class Initialized
INFO - 2024-10-14 08:56:18 --> Output Class Initialized
INFO - 2024-10-14 08:56:18 --> Security Class Initialized
DEBUG - 2024-10-14 08:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 08:56:18 --> Input Class Initialized
INFO - 2024-10-14 08:56:18 --> Language Class Initialized
INFO - 2024-10-14 08:56:18 --> Language Class Initialized
INFO - 2024-10-14 08:56:18 --> Config Class Initialized
INFO - 2024-10-14 08:56:18 --> Loader Class Initialized
INFO - 2024-10-14 08:56:18 --> Helper loaded: url_helper
INFO - 2024-10-14 08:56:18 --> Helper loaded: file_helper
INFO - 2024-10-14 08:56:18 --> Helper loaded: form_helper
INFO - 2024-10-14 08:56:18 --> Helper loaded: my_helper
INFO - 2024-10-14 08:56:18 --> Database Driver Class Initialized
INFO - 2024-10-14 08:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 08:56:18 --> Controller Class Initialized
DEBUG - 2024-10-14 08:56:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-10-14 08:56:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 08:56:18 --> Final output sent to browser
DEBUG - 2024-10-14 08:56:18 --> Total execution time: 0.0528
INFO - 2024-10-14 08:56:25 --> Config Class Initialized
INFO - 2024-10-14 08:56:25 --> Hooks Class Initialized
DEBUG - 2024-10-14 08:56:25 --> UTF-8 Support Enabled
INFO - 2024-10-14 08:56:25 --> Utf8 Class Initialized
INFO - 2024-10-14 08:56:25 --> URI Class Initialized
INFO - 2024-10-14 08:56:25 --> Router Class Initialized
INFO - 2024-10-14 08:56:25 --> Output Class Initialized
INFO - 2024-10-14 08:56:25 --> Security Class Initialized
DEBUG - 2024-10-14 08:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 08:56:25 --> Input Class Initialized
INFO - 2024-10-14 08:56:25 --> Language Class Initialized
INFO - 2024-10-14 08:56:25 --> Language Class Initialized
INFO - 2024-10-14 08:56:25 --> Config Class Initialized
INFO - 2024-10-14 08:56:25 --> Loader Class Initialized
INFO - 2024-10-14 08:56:25 --> Helper loaded: url_helper
INFO - 2024-10-14 08:56:25 --> Helper loaded: file_helper
INFO - 2024-10-14 08:56:25 --> Helper loaded: form_helper
INFO - 2024-10-14 08:56:25 --> Helper loaded: my_helper
INFO - 2024-10-14 08:56:25 --> Database Driver Class Initialized
INFO - 2024-10-14 08:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 08:56:25 --> Controller Class Initialized
DEBUG - 2024-10-14 08:56:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-14 08:56:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 08:56:25 --> Final output sent to browser
DEBUG - 2024-10-14 08:56:25 --> Total execution time: 0.0326
INFO - 2024-10-14 08:56:25 --> Config Class Initialized
INFO - 2024-10-14 08:56:25 --> Hooks Class Initialized
DEBUG - 2024-10-14 08:56:25 --> UTF-8 Support Enabled
INFO - 2024-10-14 08:56:25 --> Utf8 Class Initialized
INFO - 2024-10-14 08:56:25 --> URI Class Initialized
INFO - 2024-10-14 08:56:25 --> Router Class Initialized
INFO - 2024-10-14 08:56:25 --> Output Class Initialized
INFO - 2024-10-14 08:56:25 --> Security Class Initialized
DEBUG - 2024-10-14 08:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 08:56:25 --> Input Class Initialized
INFO - 2024-10-14 08:56:25 --> Language Class Initialized
ERROR - 2024-10-14 08:56:25 --> 404 Page Not Found: /index
INFO - 2024-10-14 08:56:25 --> Config Class Initialized
INFO - 2024-10-14 08:56:25 --> Hooks Class Initialized
DEBUG - 2024-10-14 08:56:25 --> UTF-8 Support Enabled
INFO - 2024-10-14 08:56:25 --> Utf8 Class Initialized
INFO - 2024-10-14 08:56:25 --> URI Class Initialized
INFO - 2024-10-14 08:56:25 --> Router Class Initialized
INFO - 2024-10-14 08:56:25 --> Output Class Initialized
INFO - 2024-10-14 08:56:25 --> Security Class Initialized
DEBUG - 2024-10-14 08:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 08:56:25 --> Input Class Initialized
INFO - 2024-10-14 08:56:25 --> Language Class Initialized
INFO - 2024-10-14 08:56:25 --> Language Class Initialized
INFO - 2024-10-14 08:56:25 --> Config Class Initialized
INFO - 2024-10-14 08:56:25 --> Loader Class Initialized
INFO - 2024-10-14 08:56:25 --> Helper loaded: url_helper
INFO - 2024-10-14 08:56:25 --> Helper loaded: file_helper
INFO - 2024-10-14 08:56:25 --> Helper loaded: form_helper
INFO - 2024-10-14 08:56:25 --> Helper loaded: my_helper
INFO - 2024-10-14 08:56:25 --> Database Driver Class Initialized
INFO - 2024-10-14 08:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 08:56:25 --> Controller Class Initialized
INFO - 2024-10-14 08:56:33 --> Config Class Initialized
INFO - 2024-10-14 08:56:33 --> Hooks Class Initialized
DEBUG - 2024-10-14 08:56:33 --> UTF-8 Support Enabled
INFO - 2024-10-14 08:56:33 --> Utf8 Class Initialized
INFO - 2024-10-14 08:56:33 --> URI Class Initialized
INFO - 2024-10-14 08:56:33 --> Router Class Initialized
INFO - 2024-10-14 08:56:33 --> Output Class Initialized
INFO - 2024-10-14 08:56:33 --> Security Class Initialized
DEBUG - 2024-10-14 08:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 08:56:33 --> Input Class Initialized
INFO - 2024-10-14 08:56:33 --> Language Class Initialized
INFO - 2024-10-14 08:56:33 --> Language Class Initialized
INFO - 2024-10-14 08:56:33 --> Config Class Initialized
INFO - 2024-10-14 08:56:33 --> Loader Class Initialized
INFO - 2024-10-14 08:56:33 --> Helper loaded: url_helper
INFO - 2024-10-14 08:56:33 --> Helper loaded: file_helper
INFO - 2024-10-14 08:56:33 --> Helper loaded: form_helper
INFO - 2024-10-14 08:56:33 --> Helper loaded: my_helper
INFO - 2024-10-14 08:56:33 --> Database Driver Class Initialized
INFO - 2024-10-14 08:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 08:56:33 --> Controller Class Initialized
DEBUG - 2024-10-14 08:56:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2024-10-14 08:56:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 08:56:33 --> Final output sent to browser
DEBUG - 2024-10-14 08:56:33 --> Total execution time: 0.0436
INFO - 2024-10-14 08:56:33 --> Config Class Initialized
INFO - 2024-10-14 08:56:33 --> Hooks Class Initialized
DEBUG - 2024-10-14 08:56:33 --> UTF-8 Support Enabled
INFO - 2024-10-14 08:56:33 --> Utf8 Class Initialized
INFO - 2024-10-14 08:56:33 --> URI Class Initialized
INFO - 2024-10-14 08:56:33 --> Router Class Initialized
INFO - 2024-10-14 08:56:33 --> Output Class Initialized
INFO - 2024-10-14 08:56:33 --> Security Class Initialized
DEBUG - 2024-10-14 08:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 08:56:33 --> Input Class Initialized
INFO - 2024-10-14 08:56:33 --> Language Class Initialized
ERROR - 2024-10-14 08:56:33 --> 404 Page Not Found: /index
INFO - 2024-10-14 08:56:33 --> Config Class Initialized
INFO - 2024-10-14 08:56:33 --> Hooks Class Initialized
DEBUG - 2024-10-14 08:56:33 --> UTF-8 Support Enabled
INFO - 2024-10-14 08:56:33 --> Utf8 Class Initialized
INFO - 2024-10-14 08:56:33 --> URI Class Initialized
INFO - 2024-10-14 08:56:33 --> Router Class Initialized
INFO - 2024-10-14 08:56:33 --> Output Class Initialized
INFO - 2024-10-14 08:56:33 --> Security Class Initialized
DEBUG - 2024-10-14 08:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 08:56:33 --> Input Class Initialized
INFO - 2024-10-14 08:56:33 --> Language Class Initialized
INFO - 2024-10-14 08:56:33 --> Language Class Initialized
INFO - 2024-10-14 08:56:33 --> Config Class Initialized
INFO - 2024-10-14 08:56:33 --> Loader Class Initialized
INFO - 2024-10-14 08:56:33 --> Helper loaded: url_helper
INFO - 2024-10-14 08:56:33 --> Helper loaded: file_helper
INFO - 2024-10-14 08:56:33 --> Helper loaded: form_helper
INFO - 2024-10-14 08:56:33 --> Helper loaded: my_helper
INFO - 2024-10-14 08:56:33 --> Database Driver Class Initialized
INFO - 2024-10-14 08:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 08:56:33 --> Controller Class Initialized
INFO - 2024-10-14 08:56:35 --> Config Class Initialized
INFO - 2024-10-14 08:56:35 --> Hooks Class Initialized
DEBUG - 2024-10-14 08:56:35 --> UTF-8 Support Enabled
INFO - 2024-10-14 08:56:35 --> Utf8 Class Initialized
INFO - 2024-10-14 08:56:35 --> URI Class Initialized
INFO - 2024-10-14 08:56:35 --> Router Class Initialized
INFO - 2024-10-14 08:56:35 --> Output Class Initialized
INFO - 2024-10-14 08:56:35 --> Security Class Initialized
DEBUG - 2024-10-14 08:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 08:56:35 --> Input Class Initialized
INFO - 2024-10-14 08:56:35 --> Language Class Initialized
INFO - 2024-10-14 08:56:35 --> Language Class Initialized
INFO - 2024-10-14 08:56:35 --> Config Class Initialized
INFO - 2024-10-14 08:56:35 --> Loader Class Initialized
INFO - 2024-10-14 08:56:35 --> Helper loaded: url_helper
INFO - 2024-10-14 08:56:35 --> Helper loaded: file_helper
INFO - 2024-10-14 08:56:35 --> Helper loaded: form_helper
INFO - 2024-10-14 08:56:35 --> Helper loaded: my_helper
INFO - 2024-10-14 08:56:35 --> Database Driver Class Initialized
INFO - 2024-10-14 08:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 08:56:35 --> Controller Class Initialized
DEBUG - 2024-10-14 08:56:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-14 08:56:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 08:56:35 --> Final output sent to browser
DEBUG - 2024-10-14 08:56:35 --> Total execution time: 0.0410
INFO - 2024-10-14 08:56:35 --> Config Class Initialized
INFO - 2024-10-14 08:56:35 --> Hooks Class Initialized
DEBUG - 2024-10-14 08:56:35 --> UTF-8 Support Enabled
INFO - 2024-10-14 08:56:35 --> Utf8 Class Initialized
INFO - 2024-10-14 08:56:35 --> URI Class Initialized
INFO - 2024-10-14 08:56:35 --> Router Class Initialized
INFO - 2024-10-14 08:56:35 --> Output Class Initialized
INFO - 2024-10-14 08:56:35 --> Security Class Initialized
DEBUG - 2024-10-14 08:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 08:56:35 --> Input Class Initialized
INFO - 2024-10-14 08:56:35 --> Language Class Initialized
ERROR - 2024-10-14 08:56:35 --> 404 Page Not Found: /index
INFO - 2024-10-14 08:56:35 --> Config Class Initialized
INFO - 2024-10-14 08:56:35 --> Hooks Class Initialized
DEBUG - 2024-10-14 08:56:35 --> UTF-8 Support Enabled
INFO - 2024-10-14 08:56:35 --> Utf8 Class Initialized
INFO - 2024-10-14 08:56:35 --> URI Class Initialized
INFO - 2024-10-14 08:56:35 --> Router Class Initialized
INFO - 2024-10-14 08:56:35 --> Output Class Initialized
INFO - 2024-10-14 08:56:35 --> Security Class Initialized
DEBUG - 2024-10-14 08:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 08:56:35 --> Input Class Initialized
INFO - 2024-10-14 08:56:35 --> Language Class Initialized
INFO - 2024-10-14 08:56:35 --> Language Class Initialized
INFO - 2024-10-14 08:56:35 --> Config Class Initialized
INFO - 2024-10-14 08:56:35 --> Loader Class Initialized
INFO - 2024-10-14 08:56:35 --> Helper loaded: url_helper
INFO - 2024-10-14 08:56:35 --> Helper loaded: file_helper
INFO - 2024-10-14 08:56:35 --> Helper loaded: form_helper
INFO - 2024-10-14 08:56:35 --> Helper loaded: my_helper
INFO - 2024-10-14 08:56:35 --> Database Driver Class Initialized
INFO - 2024-10-14 08:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 08:56:35 --> Controller Class Initialized
INFO - 2024-10-14 08:56:38 --> Config Class Initialized
INFO - 2024-10-14 08:56:38 --> Hooks Class Initialized
DEBUG - 2024-10-14 08:56:38 --> UTF-8 Support Enabled
INFO - 2024-10-14 08:56:38 --> Utf8 Class Initialized
INFO - 2024-10-14 08:56:38 --> URI Class Initialized
INFO - 2024-10-14 08:56:38 --> Router Class Initialized
INFO - 2024-10-14 08:56:38 --> Output Class Initialized
INFO - 2024-10-14 08:56:38 --> Security Class Initialized
DEBUG - 2024-10-14 08:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 08:56:38 --> Input Class Initialized
INFO - 2024-10-14 08:56:38 --> Language Class Initialized
INFO - 2024-10-14 08:56:38 --> Language Class Initialized
INFO - 2024-10-14 08:56:38 --> Config Class Initialized
INFO - 2024-10-14 08:56:38 --> Loader Class Initialized
INFO - 2024-10-14 08:56:38 --> Helper loaded: url_helper
INFO - 2024-10-14 08:56:38 --> Helper loaded: file_helper
INFO - 2024-10-14 08:56:38 --> Helper loaded: form_helper
INFO - 2024-10-14 08:56:38 --> Helper loaded: my_helper
INFO - 2024-10-14 08:56:38 --> Database Driver Class Initialized
INFO - 2024-10-14 08:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 08:56:38 --> Controller Class Initialized
DEBUG - 2024-10-14 08:56:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-10-14 08:56:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 08:56:38 --> Final output sent to browser
DEBUG - 2024-10-14 08:56:38 --> Total execution time: 0.0283
INFO - 2024-10-14 08:56:39 --> Config Class Initialized
INFO - 2024-10-14 08:56:39 --> Hooks Class Initialized
DEBUG - 2024-10-14 08:56:39 --> UTF-8 Support Enabled
INFO - 2024-10-14 08:56:39 --> Utf8 Class Initialized
INFO - 2024-10-14 08:56:39 --> URI Class Initialized
INFO - 2024-10-14 08:56:39 --> Router Class Initialized
INFO - 2024-10-14 08:56:39 --> Output Class Initialized
INFO - 2024-10-14 08:56:39 --> Security Class Initialized
DEBUG - 2024-10-14 08:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 08:56:39 --> Input Class Initialized
INFO - 2024-10-14 08:56:39 --> Language Class Initialized
ERROR - 2024-10-14 08:56:39 --> 404 Page Not Found: /index
INFO - 2024-10-14 08:56:39 --> Config Class Initialized
INFO - 2024-10-14 08:56:39 --> Hooks Class Initialized
DEBUG - 2024-10-14 08:56:39 --> UTF-8 Support Enabled
INFO - 2024-10-14 08:56:39 --> Utf8 Class Initialized
INFO - 2024-10-14 08:56:39 --> URI Class Initialized
INFO - 2024-10-14 08:56:39 --> Router Class Initialized
INFO - 2024-10-14 08:56:39 --> Output Class Initialized
INFO - 2024-10-14 08:56:39 --> Security Class Initialized
DEBUG - 2024-10-14 08:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 08:56:39 --> Input Class Initialized
INFO - 2024-10-14 08:56:39 --> Language Class Initialized
INFO - 2024-10-14 08:56:39 --> Language Class Initialized
INFO - 2024-10-14 08:56:39 --> Config Class Initialized
INFO - 2024-10-14 08:56:39 --> Loader Class Initialized
INFO - 2024-10-14 08:56:39 --> Helper loaded: url_helper
INFO - 2024-10-14 08:56:39 --> Helper loaded: file_helper
INFO - 2024-10-14 08:56:39 --> Helper loaded: form_helper
INFO - 2024-10-14 08:56:39 --> Helper loaded: my_helper
INFO - 2024-10-14 08:56:39 --> Database Driver Class Initialized
INFO - 2024-10-14 08:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 08:56:39 --> Controller Class Initialized
INFO - 2024-10-14 08:56:45 --> Config Class Initialized
INFO - 2024-10-14 08:56:45 --> Hooks Class Initialized
DEBUG - 2024-10-14 08:56:45 --> UTF-8 Support Enabled
INFO - 2024-10-14 08:56:45 --> Utf8 Class Initialized
INFO - 2024-10-14 08:56:45 --> URI Class Initialized
INFO - 2024-10-14 08:56:45 --> Router Class Initialized
INFO - 2024-10-14 08:56:45 --> Output Class Initialized
INFO - 2024-10-14 08:56:45 --> Security Class Initialized
DEBUG - 2024-10-14 08:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 08:56:45 --> Input Class Initialized
INFO - 2024-10-14 08:56:45 --> Language Class Initialized
INFO - 2024-10-14 08:56:45 --> Language Class Initialized
INFO - 2024-10-14 08:56:45 --> Config Class Initialized
INFO - 2024-10-14 08:56:45 --> Loader Class Initialized
INFO - 2024-10-14 08:56:45 --> Helper loaded: url_helper
INFO - 2024-10-14 08:56:45 --> Helper loaded: file_helper
INFO - 2024-10-14 08:56:45 --> Helper loaded: form_helper
INFO - 2024-10-14 08:56:45 --> Helper loaded: my_helper
INFO - 2024-10-14 08:56:45 --> Database Driver Class Initialized
INFO - 2024-10-14 08:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 08:56:45 --> Controller Class Initialized
DEBUG - 2024-10-14 08:56:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-10-14 08:56:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 08:56:45 --> Final output sent to browser
DEBUG - 2024-10-14 08:56:45 --> Total execution time: 0.0347
INFO - 2024-10-14 08:56:47 --> Config Class Initialized
INFO - 2024-10-14 08:56:47 --> Hooks Class Initialized
DEBUG - 2024-10-14 08:56:47 --> UTF-8 Support Enabled
INFO - 2024-10-14 08:56:47 --> Utf8 Class Initialized
INFO - 2024-10-14 08:56:47 --> URI Class Initialized
INFO - 2024-10-14 08:56:47 --> Router Class Initialized
INFO - 2024-10-14 08:56:47 --> Output Class Initialized
INFO - 2024-10-14 08:56:47 --> Security Class Initialized
DEBUG - 2024-10-14 08:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 08:56:47 --> Input Class Initialized
INFO - 2024-10-14 08:56:47 --> Language Class Initialized
INFO - 2024-10-14 08:56:47 --> Language Class Initialized
INFO - 2024-10-14 08:56:47 --> Config Class Initialized
INFO - 2024-10-14 08:56:47 --> Loader Class Initialized
INFO - 2024-10-14 08:56:47 --> Helper loaded: url_helper
INFO - 2024-10-14 08:56:47 --> Helper loaded: file_helper
INFO - 2024-10-14 08:56:47 --> Helper loaded: form_helper
INFO - 2024-10-14 08:56:47 --> Helper loaded: my_helper
INFO - 2024-10-14 08:56:47 --> Database Driver Class Initialized
INFO - 2024-10-14 08:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 08:56:47 --> Controller Class Initialized
INFO - 2024-10-14 08:56:47 --> Database Driver Class Initialized
INFO - 2024-10-14 08:56:47 --> Config Class Initialized
INFO - 2024-10-14 08:56:47 --> Hooks Class Initialized
DEBUG - 2024-10-14 08:56:47 --> UTF-8 Support Enabled
INFO - 2024-10-14 08:56:47 --> Utf8 Class Initialized
INFO - 2024-10-14 08:56:47 --> URI Class Initialized
INFO - 2024-10-14 08:56:47 --> Router Class Initialized
INFO - 2024-10-14 08:56:47 --> Output Class Initialized
INFO - 2024-10-14 08:56:47 --> Security Class Initialized
DEBUG - 2024-10-14 08:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 08:56:47 --> Input Class Initialized
INFO - 2024-10-14 08:56:47 --> Language Class Initialized
INFO - 2024-10-14 08:56:47 --> Language Class Initialized
INFO - 2024-10-14 08:56:47 --> Config Class Initialized
INFO - 2024-10-14 08:56:47 --> Loader Class Initialized
INFO - 2024-10-14 08:56:47 --> Helper loaded: url_helper
INFO - 2024-10-14 08:56:47 --> Helper loaded: file_helper
INFO - 2024-10-14 08:56:47 --> Helper loaded: form_helper
INFO - 2024-10-14 08:56:47 --> Helper loaded: my_helper
INFO - 2024-10-14 08:56:47 --> Database Driver Class Initialized
INFO - 2024-10-14 08:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 08:56:47 --> Controller Class Initialized
DEBUG - 2024-10-14 08:56:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-10-14 08:56:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 08:56:47 --> Final output sent to browser
DEBUG - 2024-10-14 08:56:47 --> Total execution time: 0.0342
INFO - 2024-10-14 09:15:34 --> Config Class Initialized
INFO - 2024-10-14 09:15:34 --> Hooks Class Initialized
DEBUG - 2024-10-14 09:15:34 --> UTF-8 Support Enabled
INFO - 2024-10-14 09:15:34 --> Utf8 Class Initialized
INFO - 2024-10-14 09:15:34 --> URI Class Initialized
INFO - 2024-10-14 09:15:34 --> Router Class Initialized
INFO - 2024-10-14 09:15:34 --> Output Class Initialized
INFO - 2024-10-14 09:15:34 --> Security Class Initialized
DEBUG - 2024-10-14 09:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 09:15:34 --> Input Class Initialized
INFO - 2024-10-14 09:15:34 --> Language Class Initialized
INFO - 2024-10-14 09:15:34 --> Language Class Initialized
INFO - 2024-10-14 09:15:34 --> Config Class Initialized
INFO - 2024-10-14 09:15:34 --> Loader Class Initialized
INFO - 2024-10-14 09:15:34 --> Helper loaded: url_helper
INFO - 2024-10-14 09:15:34 --> Helper loaded: file_helper
INFO - 2024-10-14 09:15:34 --> Helper loaded: form_helper
INFO - 2024-10-14 09:15:34 --> Helper loaded: my_helper
INFO - 2024-10-14 09:15:34 --> Database Driver Class Initialized
INFO - 2024-10-14 09:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 09:15:34 --> Controller Class Initialized
INFO - 2024-10-14 09:15:35 --> Helper loaded: cookie_helper
INFO - 2024-10-14 09:15:35 --> Final output sent to browser
DEBUG - 2024-10-14 09:15:35 --> Total execution time: 0.7823
INFO - 2024-10-14 09:29:56 --> Config Class Initialized
INFO - 2024-10-14 09:29:56 --> Hooks Class Initialized
DEBUG - 2024-10-14 09:29:56 --> UTF-8 Support Enabled
INFO - 2024-10-14 09:29:56 --> Utf8 Class Initialized
INFO - 2024-10-14 09:29:56 --> URI Class Initialized
INFO - 2024-10-14 09:29:56 --> Router Class Initialized
INFO - 2024-10-14 09:29:56 --> Output Class Initialized
INFO - 2024-10-14 09:29:56 --> Security Class Initialized
DEBUG - 2024-10-14 09:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 09:29:57 --> Input Class Initialized
INFO - 2024-10-14 09:29:57 --> Language Class Initialized
INFO - 2024-10-14 09:29:57 --> Language Class Initialized
INFO - 2024-10-14 09:29:57 --> Config Class Initialized
INFO - 2024-10-14 09:29:57 --> Loader Class Initialized
INFO - 2024-10-14 09:29:57 --> Helper loaded: url_helper
INFO - 2024-10-14 09:29:57 --> Helper loaded: file_helper
INFO - 2024-10-14 09:29:57 --> Helper loaded: form_helper
INFO - 2024-10-14 09:29:57 --> Helper loaded: my_helper
INFO - 2024-10-14 09:29:57 --> Database Driver Class Initialized
INFO - 2024-10-14 09:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 09:29:57 --> Controller Class Initialized
INFO - 2024-10-14 09:29:57 --> Helper loaded: cookie_helper
INFO - 2024-10-14 09:29:57 --> Final output sent to browser
DEBUG - 2024-10-14 09:29:57 --> Total execution time: 0.0774
INFO - 2024-10-14 09:29:57 --> Config Class Initialized
INFO - 2024-10-14 09:29:57 --> Hooks Class Initialized
DEBUG - 2024-10-14 09:29:57 --> UTF-8 Support Enabled
INFO - 2024-10-14 09:29:57 --> Utf8 Class Initialized
INFO - 2024-10-14 09:29:57 --> URI Class Initialized
INFO - 2024-10-14 09:29:57 --> Router Class Initialized
INFO - 2024-10-14 09:29:57 --> Output Class Initialized
INFO - 2024-10-14 09:29:57 --> Security Class Initialized
DEBUG - 2024-10-14 09:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 09:29:57 --> Input Class Initialized
INFO - 2024-10-14 09:29:57 --> Language Class Initialized
INFO - 2024-10-14 09:29:57 --> Language Class Initialized
INFO - 2024-10-14 09:29:57 --> Config Class Initialized
INFO - 2024-10-14 09:29:57 --> Loader Class Initialized
INFO - 2024-10-14 09:29:57 --> Helper loaded: url_helper
INFO - 2024-10-14 09:29:57 --> Helper loaded: file_helper
INFO - 2024-10-14 09:29:57 --> Helper loaded: form_helper
INFO - 2024-10-14 09:29:57 --> Helper loaded: my_helper
INFO - 2024-10-14 09:29:57 --> Database Driver Class Initialized
INFO - 2024-10-14 09:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 09:29:57 --> Controller Class Initialized
INFO - 2024-10-14 09:29:57 --> Helper loaded: cookie_helper
INFO - 2024-10-14 09:29:57 --> Config Class Initialized
INFO - 2024-10-14 09:29:57 --> Hooks Class Initialized
DEBUG - 2024-10-14 09:29:57 --> UTF-8 Support Enabled
INFO - 2024-10-14 09:29:57 --> Utf8 Class Initialized
INFO - 2024-10-14 09:29:57 --> URI Class Initialized
INFO - 2024-10-14 09:29:57 --> Router Class Initialized
INFO - 2024-10-14 09:29:57 --> Output Class Initialized
INFO - 2024-10-14 09:29:57 --> Security Class Initialized
DEBUG - 2024-10-14 09:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 09:29:57 --> Input Class Initialized
INFO - 2024-10-14 09:29:57 --> Language Class Initialized
INFO - 2024-10-14 09:29:57 --> Language Class Initialized
INFO - 2024-10-14 09:29:57 --> Config Class Initialized
INFO - 2024-10-14 09:29:57 --> Loader Class Initialized
INFO - 2024-10-14 09:29:57 --> Helper loaded: url_helper
INFO - 2024-10-14 09:29:57 --> Helper loaded: file_helper
INFO - 2024-10-14 09:29:57 --> Helper loaded: form_helper
INFO - 2024-10-14 09:29:57 --> Helper loaded: my_helper
INFO - 2024-10-14 09:29:57 --> Database Driver Class Initialized
INFO - 2024-10-14 09:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 09:29:57 --> Controller Class Initialized
DEBUG - 2024-10-14 09:29:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-14 09:29:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 09:29:57 --> Final output sent to browser
DEBUG - 2024-10-14 09:29:57 --> Total execution time: 0.0440
INFO - 2024-10-14 09:30:03 --> Config Class Initialized
INFO - 2024-10-14 09:30:03 --> Hooks Class Initialized
DEBUG - 2024-10-14 09:30:03 --> UTF-8 Support Enabled
INFO - 2024-10-14 09:30:03 --> Utf8 Class Initialized
INFO - 2024-10-14 09:30:03 --> URI Class Initialized
INFO - 2024-10-14 09:30:03 --> Router Class Initialized
INFO - 2024-10-14 09:30:03 --> Output Class Initialized
INFO - 2024-10-14 09:30:03 --> Security Class Initialized
DEBUG - 2024-10-14 09:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 09:30:03 --> Input Class Initialized
INFO - 2024-10-14 09:30:03 --> Language Class Initialized
INFO - 2024-10-14 09:30:03 --> Language Class Initialized
INFO - 2024-10-14 09:30:03 --> Config Class Initialized
INFO - 2024-10-14 09:30:03 --> Loader Class Initialized
INFO - 2024-10-14 09:30:03 --> Helper loaded: url_helper
INFO - 2024-10-14 09:30:03 --> Helper loaded: file_helper
INFO - 2024-10-14 09:30:03 --> Helper loaded: form_helper
INFO - 2024-10-14 09:30:03 --> Helper loaded: my_helper
INFO - 2024-10-14 09:30:03 --> Database Driver Class Initialized
INFO - 2024-10-14 09:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 09:30:03 --> Controller Class Initialized
ERROR - 2024-10-14 09:30:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2591
ERROR - 2024-10-14 09:30:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3156
ERROR - 2024-10-14 09:30:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3194
ERROR - 2024-10-14 09:30:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3232
ERROR - 2024-10-14 09:30:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3271
ERROR - 2024-10-14 09:30:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3388
ERROR - 2024-10-14 09:30:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3507
ERROR - 2024-10-14 09:30:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3626
ERROR - 2024-10-14 09:30:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3745
ERROR - 2024-10-14 09:30:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-10-14 09:30:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-10-14 09:30:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 40
ERROR - 2024-10-14 09:30:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-10-14 09:30:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-10-14 09:30:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
ERROR - 2024-10-14 09:30:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
DEBUG - 2024-10-14 09:30:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-10-14 09:31:16 --> Config Class Initialized
INFO - 2024-10-14 09:31:16 --> Hooks Class Initialized
DEBUG - 2024-10-14 09:31:16 --> UTF-8 Support Enabled
INFO - 2024-10-14 09:31:16 --> Utf8 Class Initialized
INFO - 2024-10-14 09:31:16 --> URI Class Initialized
INFO - 2024-10-14 09:31:16 --> Router Class Initialized
INFO - 2024-10-14 09:31:16 --> Output Class Initialized
INFO - 2024-10-14 09:31:16 --> Security Class Initialized
DEBUG - 2024-10-14 09:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 09:31:16 --> Input Class Initialized
INFO - 2024-10-14 09:31:16 --> Language Class Initialized
INFO - 2024-10-14 09:31:16 --> Language Class Initialized
INFO - 2024-10-14 09:31:16 --> Config Class Initialized
INFO - 2024-10-14 09:31:16 --> Loader Class Initialized
INFO - 2024-10-14 09:31:16 --> Helper loaded: url_helper
INFO - 2024-10-14 09:31:16 --> Helper loaded: file_helper
INFO - 2024-10-14 09:31:16 --> Helper loaded: form_helper
INFO - 2024-10-14 09:31:16 --> Helper loaded: my_helper
INFO - 2024-10-14 09:31:16 --> Database Driver Class Initialized
INFO - 2024-10-14 09:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 09:31:16 --> Controller Class Initialized
INFO - 2024-10-14 09:31:16 --> Helper loaded: cookie_helper
INFO - 2024-10-14 09:31:16 --> Final output sent to browser
DEBUG - 2024-10-14 09:31:16 --> Total execution time: 0.3933
INFO - 2024-10-14 09:31:16 --> Config Class Initialized
INFO - 2024-10-14 09:31:16 --> Hooks Class Initialized
DEBUG - 2024-10-14 09:31:16 --> UTF-8 Support Enabled
INFO - 2024-10-14 09:31:16 --> Utf8 Class Initialized
INFO - 2024-10-14 09:31:16 --> URI Class Initialized
INFO - 2024-10-14 09:31:16 --> Router Class Initialized
INFO - 2024-10-14 09:31:16 --> Output Class Initialized
INFO - 2024-10-14 09:31:16 --> Security Class Initialized
DEBUG - 2024-10-14 09:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 09:31:16 --> Input Class Initialized
INFO - 2024-10-14 09:31:16 --> Language Class Initialized
INFO - 2024-10-14 09:31:16 --> Language Class Initialized
INFO - 2024-10-14 09:31:16 --> Config Class Initialized
INFO - 2024-10-14 09:31:16 --> Loader Class Initialized
INFO - 2024-10-14 09:31:16 --> Helper loaded: url_helper
INFO - 2024-10-14 09:31:16 --> Helper loaded: file_helper
INFO - 2024-10-14 09:31:16 --> Helper loaded: form_helper
INFO - 2024-10-14 09:31:16 --> Helper loaded: my_helper
INFO - 2024-10-14 09:31:17 --> Database Driver Class Initialized
INFO - 2024-10-14 09:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 09:31:17 --> Controller Class Initialized
INFO - 2024-10-14 09:31:17 --> Helper loaded: cookie_helper
INFO - 2024-10-14 09:31:17 --> Config Class Initialized
INFO - 2024-10-14 09:31:17 --> Hooks Class Initialized
DEBUG - 2024-10-14 09:31:17 --> UTF-8 Support Enabled
INFO - 2024-10-14 09:31:17 --> Utf8 Class Initialized
INFO - 2024-10-14 09:31:17 --> URI Class Initialized
INFO - 2024-10-14 09:31:17 --> Router Class Initialized
INFO - 2024-10-14 09:31:17 --> Output Class Initialized
INFO - 2024-10-14 09:31:17 --> Security Class Initialized
DEBUG - 2024-10-14 09:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 09:31:17 --> Input Class Initialized
INFO - 2024-10-14 09:31:17 --> Language Class Initialized
INFO - 2024-10-14 09:31:17 --> Language Class Initialized
INFO - 2024-10-14 09:31:17 --> Config Class Initialized
INFO - 2024-10-14 09:31:17 --> Loader Class Initialized
INFO - 2024-10-14 09:31:17 --> Helper loaded: url_helper
INFO - 2024-10-14 09:31:17 --> Helper loaded: file_helper
INFO - 2024-10-14 09:31:17 --> Helper loaded: form_helper
INFO - 2024-10-14 09:31:17 --> Helper loaded: my_helper
INFO - 2024-10-14 09:31:17 --> Database Driver Class Initialized
INFO - 2024-10-14 09:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 09:31:17 --> Controller Class Initialized
DEBUG - 2024-10-14 09:31:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-14 09:31:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 09:31:17 --> Final output sent to browser
DEBUG - 2024-10-14 09:31:17 --> Total execution time: 0.1044
INFO - 2024-10-14 09:31:36 --> Config Class Initialized
INFO - 2024-10-14 09:31:36 --> Hooks Class Initialized
DEBUG - 2024-10-14 09:31:36 --> UTF-8 Support Enabled
INFO - 2024-10-14 09:31:36 --> Utf8 Class Initialized
INFO - 2024-10-14 09:31:36 --> URI Class Initialized
INFO - 2024-10-14 09:31:36 --> Router Class Initialized
INFO - 2024-10-14 09:31:36 --> Output Class Initialized
INFO - 2024-10-14 09:31:36 --> Security Class Initialized
DEBUG - 2024-10-14 09:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 09:31:36 --> Input Class Initialized
INFO - 2024-10-14 09:31:36 --> Language Class Initialized
INFO - 2024-10-14 09:31:36 --> Language Class Initialized
INFO - 2024-10-14 09:31:36 --> Config Class Initialized
INFO - 2024-10-14 09:31:36 --> Loader Class Initialized
INFO - 2024-10-14 09:31:36 --> Helper loaded: url_helper
INFO - 2024-10-14 09:31:36 --> Helper loaded: file_helper
INFO - 2024-10-14 09:31:36 --> Helper loaded: form_helper
INFO - 2024-10-14 09:31:36 --> Helper loaded: my_helper
INFO - 2024-10-14 09:31:36 --> Database Driver Class Initialized
INFO - 2024-10-14 09:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 09:31:36 --> Controller Class Initialized
ERROR - 2024-10-14 09:31:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-14 09:31:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-14 09:31:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-14 09:31:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-14 09:31:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-14 09:31:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-14 09:31:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-14 09:31:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-14 09:31:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-14 09:31:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-14 09:31:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-14 09:31:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-14 09:31:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-14 09:31:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-14 09:31:42 --> Final output sent to browser
DEBUG - 2024-10-14 09:31:42 --> Total execution time: 6.4488
INFO - 2024-10-14 09:34:24 --> Config Class Initialized
INFO - 2024-10-14 09:34:24 --> Hooks Class Initialized
DEBUG - 2024-10-14 09:34:24 --> UTF-8 Support Enabled
INFO - 2024-10-14 09:34:24 --> Utf8 Class Initialized
INFO - 2024-10-14 09:34:24 --> URI Class Initialized
INFO - 2024-10-14 09:34:24 --> Router Class Initialized
INFO - 2024-10-14 09:34:24 --> Output Class Initialized
INFO - 2024-10-14 09:34:24 --> Security Class Initialized
DEBUG - 2024-10-14 09:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 09:34:24 --> Input Class Initialized
INFO - 2024-10-14 09:34:24 --> Language Class Initialized
INFO - 2024-10-14 09:34:24 --> Language Class Initialized
INFO - 2024-10-14 09:34:24 --> Config Class Initialized
INFO - 2024-10-14 09:34:24 --> Loader Class Initialized
INFO - 2024-10-14 09:34:24 --> Helper loaded: url_helper
INFO - 2024-10-14 09:34:24 --> Helper loaded: file_helper
INFO - 2024-10-14 09:34:24 --> Helper loaded: form_helper
INFO - 2024-10-14 09:34:24 --> Helper loaded: my_helper
INFO - 2024-10-14 09:34:24 --> Database Driver Class Initialized
INFO - 2024-10-14 09:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 09:34:24 --> Controller Class Initialized
INFO - 2024-10-14 09:34:24 --> Helper loaded: cookie_helper
INFO - 2024-10-14 09:34:24 --> Final output sent to browser
DEBUG - 2024-10-14 09:34:24 --> Total execution time: 0.0680
INFO - 2024-10-14 09:34:24 --> Config Class Initialized
INFO - 2024-10-14 09:34:24 --> Hooks Class Initialized
DEBUG - 2024-10-14 09:34:24 --> UTF-8 Support Enabled
INFO - 2024-10-14 09:34:24 --> Utf8 Class Initialized
INFO - 2024-10-14 09:34:24 --> URI Class Initialized
INFO - 2024-10-14 09:34:24 --> Router Class Initialized
INFO - 2024-10-14 09:34:24 --> Output Class Initialized
INFO - 2024-10-14 09:34:24 --> Security Class Initialized
DEBUG - 2024-10-14 09:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 09:34:24 --> Input Class Initialized
INFO - 2024-10-14 09:34:24 --> Language Class Initialized
INFO - 2024-10-14 09:34:24 --> Language Class Initialized
INFO - 2024-10-14 09:34:24 --> Config Class Initialized
INFO - 2024-10-14 09:34:24 --> Loader Class Initialized
INFO - 2024-10-14 09:34:24 --> Helper loaded: url_helper
INFO - 2024-10-14 09:34:24 --> Helper loaded: file_helper
INFO - 2024-10-14 09:34:24 --> Helper loaded: form_helper
INFO - 2024-10-14 09:34:24 --> Helper loaded: my_helper
INFO - 2024-10-14 09:34:24 --> Database Driver Class Initialized
INFO - 2024-10-14 09:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 09:34:24 --> Controller Class Initialized
INFO - 2024-10-14 09:34:24 --> Helper loaded: cookie_helper
INFO - 2024-10-14 09:34:24 --> Config Class Initialized
INFO - 2024-10-14 09:34:24 --> Hooks Class Initialized
DEBUG - 2024-10-14 09:34:24 --> UTF-8 Support Enabled
INFO - 2024-10-14 09:34:24 --> Utf8 Class Initialized
INFO - 2024-10-14 09:34:24 --> URI Class Initialized
INFO - 2024-10-14 09:34:24 --> Router Class Initialized
INFO - 2024-10-14 09:34:24 --> Output Class Initialized
INFO - 2024-10-14 09:34:24 --> Security Class Initialized
DEBUG - 2024-10-14 09:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 09:34:24 --> Input Class Initialized
INFO - 2024-10-14 09:34:24 --> Language Class Initialized
INFO - 2024-10-14 09:34:24 --> Language Class Initialized
INFO - 2024-10-14 09:34:24 --> Config Class Initialized
INFO - 2024-10-14 09:34:24 --> Loader Class Initialized
INFO - 2024-10-14 09:34:24 --> Helper loaded: url_helper
INFO - 2024-10-14 09:34:24 --> Helper loaded: file_helper
INFO - 2024-10-14 09:34:24 --> Helper loaded: form_helper
INFO - 2024-10-14 09:34:24 --> Helper loaded: my_helper
INFO - 2024-10-14 09:34:24 --> Database Driver Class Initialized
INFO - 2024-10-14 09:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 09:34:24 --> Controller Class Initialized
DEBUG - 2024-10-14 09:34:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-14 09:34:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 09:34:24 --> Final output sent to browser
DEBUG - 2024-10-14 09:34:24 --> Total execution time: 0.0370
INFO - 2024-10-14 09:34:32 --> Config Class Initialized
INFO - 2024-10-14 09:34:32 --> Hooks Class Initialized
DEBUG - 2024-10-14 09:34:32 --> UTF-8 Support Enabled
INFO - 2024-10-14 09:34:32 --> Utf8 Class Initialized
INFO - 2024-10-14 09:34:32 --> URI Class Initialized
INFO - 2024-10-14 09:34:32 --> Router Class Initialized
INFO - 2024-10-14 09:34:32 --> Output Class Initialized
INFO - 2024-10-14 09:34:32 --> Security Class Initialized
DEBUG - 2024-10-14 09:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 09:34:32 --> Input Class Initialized
INFO - 2024-10-14 09:34:32 --> Language Class Initialized
INFO - 2024-10-14 09:34:32 --> Language Class Initialized
INFO - 2024-10-14 09:34:32 --> Config Class Initialized
INFO - 2024-10-14 09:34:32 --> Loader Class Initialized
INFO - 2024-10-14 09:34:32 --> Helper loaded: url_helper
INFO - 2024-10-14 09:34:32 --> Helper loaded: file_helper
INFO - 2024-10-14 09:34:32 --> Helper loaded: form_helper
INFO - 2024-10-14 09:34:32 --> Helper loaded: my_helper
INFO - 2024-10-14 09:34:32 --> Database Driver Class Initialized
INFO - 2024-10-14 09:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 09:34:32 --> Controller Class Initialized
ERROR - 2024-10-14 09:34:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-14 09:34:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-14 09:34:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-14 09:34:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-14 09:34:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-14 09:34:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-14 09:34:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-14 09:34:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-14 09:34:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-14 09:34:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-14 09:34:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-14 09:34:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-14 09:34:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-14 09:34:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-14 09:34:35 --> Final output sent to browser
DEBUG - 2024-10-14 09:34:35 --> Total execution time: 3.0588
INFO - 2024-10-14 09:35:13 --> Config Class Initialized
INFO - 2024-10-14 09:35:13 --> Hooks Class Initialized
DEBUG - 2024-10-14 09:35:13 --> UTF-8 Support Enabled
INFO - 2024-10-14 09:35:13 --> Utf8 Class Initialized
INFO - 2024-10-14 09:35:13 --> URI Class Initialized
INFO - 2024-10-14 09:35:13 --> Router Class Initialized
INFO - 2024-10-14 09:35:13 --> Output Class Initialized
INFO - 2024-10-14 09:35:13 --> Security Class Initialized
DEBUG - 2024-10-14 09:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 09:35:13 --> Input Class Initialized
INFO - 2024-10-14 09:35:13 --> Language Class Initialized
INFO - 2024-10-14 09:35:13 --> Language Class Initialized
INFO - 2024-10-14 09:35:13 --> Config Class Initialized
INFO - 2024-10-14 09:35:13 --> Loader Class Initialized
INFO - 2024-10-14 09:35:13 --> Helper loaded: url_helper
INFO - 2024-10-14 09:35:13 --> Helper loaded: file_helper
INFO - 2024-10-14 09:35:13 --> Helper loaded: form_helper
INFO - 2024-10-14 09:35:13 --> Helper loaded: my_helper
INFO - 2024-10-14 09:35:13 --> Database Driver Class Initialized
INFO - 2024-10-14 09:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 09:35:13 --> Controller Class Initialized
ERROR - 2024-10-14 09:35:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-14 09:35:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-14 09:35:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-14 09:35:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-14 09:35:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-14 09:35:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-14 09:35:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-14 09:35:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-14 09:35:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-14 09:35:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-14 09:35:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-14 09:35:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-14 09:35:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-14 09:35:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-14 09:35:16 --> Final output sent to browser
DEBUG - 2024-10-14 09:35:16 --> Total execution time: 2.9114
INFO - 2024-10-14 09:35:37 --> Config Class Initialized
INFO - 2024-10-14 09:35:37 --> Hooks Class Initialized
DEBUG - 2024-10-14 09:35:37 --> UTF-8 Support Enabled
INFO - 2024-10-14 09:35:37 --> Utf8 Class Initialized
INFO - 2024-10-14 09:35:37 --> URI Class Initialized
INFO - 2024-10-14 09:35:37 --> Router Class Initialized
INFO - 2024-10-14 09:35:37 --> Output Class Initialized
INFO - 2024-10-14 09:35:37 --> Security Class Initialized
DEBUG - 2024-10-14 09:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 09:35:37 --> Input Class Initialized
INFO - 2024-10-14 09:35:37 --> Language Class Initialized
INFO - 2024-10-14 09:35:37 --> Language Class Initialized
INFO - 2024-10-14 09:35:37 --> Config Class Initialized
INFO - 2024-10-14 09:35:37 --> Loader Class Initialized
INFO - 2024-10-14 09:35:37 --> Helper loaded: url_helper
INFO - 2024-10-14 09:35:37 --> Helper loaded: file_helper
INFO - 2024-10-14 09:35:37 --> Helper loaded: form_helper
INFO - 2024-10-14 09:35:37 --> Helper loaded: my_helper
INFO - 2024-10-14 09:35:37 --> Database Driver Class Initialized
INFO - 2024-10-14 09:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 09:35:37 --> Controller Class Initialized
DEBUG - 2024-10-14 09:35:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-10-14 09:35:41 --> Final output sent to browser
DEBUG - 2024-10-14 09:35:41 --> Total execution time: 3.7636
INFO - 2024-10-14 09:36:09 --> Config Class Initialized
INFO - 2024-10-14 09:36:09 --> Hooks Class Initialized
DEBUG - 2024-10-14 09:36:09 --> UTF-8 Support Enabled
INFO - 2024-10-14 09:36:09 --> Utf8 Class Initialized
INFO - 2024-10-14 09:36:09 --> URI Class Initialized
INFO - 2024-10-14 09:36:09 --> Router Class Initialized
INFO - 2024-10-14 09:36:09 --> Output Class Initialized
INFO - 2024-10-14 09:36:09 --> Security Class Initialized
DEBUG - 2024-10-14 09:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 09:36:09 --> Input Class Initialized
INFO - 2024-10-14 09:36:09 --> Language Class Initialized
INFO - 2024-10-14 09:36:09 --> Language Class Initialized
INFO - 2024-10-14 09:36:09 --> Config Class Initialized
INFO - 2024-10-14 09:36:09 --> Loader Class Initialized
INFO - 2024-10-14 09:36:09 --> Helper loaded: url_helper
INFO - 2024-10-14 09:36:09 --> Helper loaded: file_helper
INFO - 2024-10-14 09:36:09 --> Helper loaded: form_helper
INFO - 2024-10-14 09:36:09 --> Helper loaded: my_helper
INFO - 2024-10-14 09:36:09 --> Database Driver Class Initialized
INFO - 2024-10-14 09:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 09:36:09 --> Controller Class Initialized
DEBUG - 2024-10-14 09:36:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-14 09:36:12 --> Final output sent to browser
DEBUG - 2024-10-14 09:36:12 --> Total execution time: 3.0901
INFO - 2024-10-14 09:42:40 --> Config Class Initialized
INFO - 2024-10-14 09:42:40 --> Hooks Class Initialized
DEBUG - 2024-10-14 09:42:40 --> UTF-8 Support Enabled
INFO - 2024-10-14 09:42:40 --> Utf8 Class Initialized
INFO - 2024-10-14 09:42:40 --> URI Class Initialized
INFO - 2024-10-14 09:42:40 --> Router Class Initialized
INFO - 2024-10-14 09:42:40 --> Output Class Initialized
INFO - 2024-10-14 09:42:40 --> Security Class Initialized
DEBUG - 2024-10-14 09:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 09:42:40 --> Input Class Initialized
INFO - 2024-10-14 09:42:40 --> Language Class Initialized
INFO - 2024-10-14 09:42:40 --> Language Class Initialized
INFO - 2024-10-14 09:42:40 --> Config Class Initialized
INFO - 2024-10-14 09:42:40 --> Loader Class Initialized
INFO - 2024-10-14 09:42:40 --> Helper loaded: url_helper
INFO - 2024-10-14 09:42:40 --> Helper loaded: file_helper
INFO - 2024-10-14 09:42:40 --> Helper loaded: form_helper
INFO - 2024-10-14 09:42:40 --> Helper loaded: my_helper
INFO - 2024-10-14 09:42:40 --> Database Driver Class Initialized
INFO - 2024-10-14 09:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 09:42:40 --> Controller Class Initialized
INFO - 2024-10-14 09:42:40 --> Helper loaded: cookie_helper
INFO - 2024-10-14 09:42:40 --> Final output sent to browser
DEBUG - 2024-10-14 09:42:40 --> Total execution time: 0.0567
INFO - 2024-10-14 09:42:40 --> Config Class Initialized
INFO - 2024-10-14 09:42:40 --> Hooks Class Initialized
DEBUG - 2024-10-14 09:42:40 --> UTF-8 Support Enabled
INFO - 2024-10-14 09:42:40 --> Utf8 Class Initialized
INFO - 2024-10-14 09:42:40 --> URI Class Initialized
INFO - 2024-10-14 09:42:40 --> Router Class Initialized
INFO - 2024-10-14 09:42:40 --> Output Class Initialized
INFO - 2024-10-14 09:42:40 --> Security Class Initialized
DEBUG - 2024-10-14 09:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 09:42:40 --> Input Class Initialized
INFO - 2024-10-14 09:42:40 --> Language Class Initialized
INFO - 2024-10-14 09:42:40 --> Language Class Initialized
INFO - 2024-10-14 09:42:40 --> Config Class Initialized
INFO - 2024-10-14 09:42:40 --> Loader Class Initialized
INFO - 2024-10-14 09:42:40 --> Helper loaded: url_helper
INFO - 2024-10-14 09:42:40 --> Helper loaded: file_helper
INFO - 2024-10-14 09:42:40 --> Helper loaded: form_helper
INFO - 2024-10-14 09:42:40 --> Helper loaded: my_helper
INFO - 2024-10-14 09:42:40 --> Database Driver Class Initialized
INFO - 2024-10-14 09:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 09:42:40 --> Controller Class Initialized
INFO - 2024-10-14 09:42:40 --> Helper loaded: cookie_helper
INFO - 2024-10-14 09:42:40 --> Config Class Initialized
INFO - 2024-10-14 09:42:40 --> Hooks Class Initialized
DEBUG - 2024-10-14 09:42:40 --> UTF-8 Support Enabled
INFO - 2024-10-14 09:42:40 --> Utf8 Class Initialized
INFO - 2024-10-14 09:42:40 --> URI Class Initialized
INFO - 2024-10-14 09:42:40 --> Router Class Initialized
INFO - 2024-10-14 09:42:40 --> Output Class Initialized
INFO - 2024-10-14 09:42:40 --> Security Class Initialized
DEBUG - 2024-10-14 09:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 09:42:40 --> Input Class Initialized
INFO - 2024-10-14 09:42:40 --> Language Class Initialized
INFO - 2024-10-14 09:42:40 --> Language Class Initialized
INFO - 2024-10-14 09:42:40 --> Config Class Initialized
INFO - 2024-10-14 09:42:40 --> Loader Class Initialized
INFO - 2024-10-14 09:42:40 --> Helper loaded: url_helper
INFO - 2024-10-14 09:42:40 --> Helper loaded: file_helper
INFO - 2024-10-14 09:42:40 --> Helper loaded: form_helper
INFO - 2024-10-14 09:42:40 --> Helper loaded: my_helper
INFO - 2024-10-14 09:42:40 --> Database Driver Class Initialized
INFO - 2024-10-14 09:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 09:42:40 --> Controller Class Initialized
DEBUG - 2024-10-14 09:42:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-14 09:42:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 09:42:40 --> Final output sent to browser
DEBUG - 2024-10-14 09:42:40 --> Total execution time: 0.0639
INFO - 2024-10-14 09:42:55 --> Config Class Initialized
INFO - 2024-10-14 09:42:55 --> Hooks Class Initialized
DEBUG - 2024-10-14 09:42:55 --> UTF-8 Support Enabled
INFO - 2024-10-14 09:42:55 --> Utf8 Class Initialized
INFO - 2024-10-14 09:42:55 --> URI Class Initialized
INFO - 2024-10-14 09:42:55 --> Router Class Initialized
INFO - 2024-10-14 09:42:55 --> Output Class Initialized
INFO - 2024-10-14 09:42:55 --> Security Class Initialized
DEBUG - 2024-10-14 09:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 09:42:55 --> Input Class Initialized
INFO - 2024-10-14 09:42:55 --> Language Class Initialized
INFO - 2024-10-14 09:42:55 --> Language Class Initialized
INFO - 2024-10-14 09:42:55 --> Config Class Initialized
INFO - 2024-10-14 09:42:55 --> Loader Class Initialized
INFO - 2024-10-14 09:42:55 --> Helper loaded: url_helper
INFO - 2024-10-14 09:42:55 --> Helper loaded: file_helper
INFO - 2024-10-14 09:42:55 --> Helper loaded: form_helper
INFO - 2024-10-14 09:42:55 --> Helper loaded: my_helper
INFO - 2024-10-14 09:42:55 --> Database Driver Class Initialized
INFO - 2024-10-14 09:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 09:42:55 --> Controller Class Initialized
ERROR - 2024-10-14 09:42:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-14 09:42:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-14 09:42:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-14 09:42:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-14 09:42:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-14 09:42:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-14 09:42:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-14 09:42:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-14 09:42:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-14 09:42:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-14 09:42:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-14 09:42:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-14 09:42:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-14 09:42:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-14 09:42:58 --> Final output sent to browser
DEBUG - 2024-10-14 09:42:58 --> Total execution time: 2.8808
INFO - 2024-10-14 10:03:03 --> Config Class Initialized
INFO - 2024-10-14 10:03:03 --> Hooks Class Initialized
DEBUG - 2024-10-14 10:03:03 --> UTF-8 Support Enabled
INFO - 2024-10-14 10:03:03 --> Utf8 Class Initialized
INFO - 2024-10-14 10:03:03 --> URI Class Initialized
INFO - 2024-10-14 10:03:03 --> Router Class Initialized
INFO - 2024-10-14 10:03:03 --> Output Class Initialized
INFO - 2024-10-14 10:03:03 --> Security Class Initialized
DEBUG - 2024-10-14 10:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 10:03:03 --> Input Class Initialized
INFO - 2024-10-14 10:03:03 --> Language Class Initialized
INFO - 2024-10-14 10:03:03 --> Language Class Initialized
INFO - 2024-10-14 10:03:03 --> Config Class Initialized
INFO - 2024-10-14 10:03:03 --> Loader Class Initialized
INFO - 2024-10-14 10:03:03 --> Helper loaded: url_helper
INFO - 2024-10-14 10:03:03 --> Helper loaded: file_helper
INFO - 2024-10-14 10:03:03 --> Helper loaded: form_helper
INFO - 2024-10-14 10:03:03 --> Helper loaded: my_helper
INFO - 2024-10-14 10:03:03 --> Database Driver Class Initialized
INFO - 2024-10-14 10:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 10:03:03 --> Controller Class Initialized
INFO - 2024-10-14 10:03:03 --> Helper loaded: cookie_helper
INFO - 2024-10-14 10:03:03 --> Final output sent to browser
DEBUG - 2024-10-14 10:03:03 --> Total execution time: 0.0741
INFO - 2024-10-14 10:03:03 --> Config Class Initialized
INFO - 2024-10-14 10:03:03 --> Hooks Class Initialized
DEBUG - 2024-10-14 10:03:03 --> UTF-8 Support Enabled
INFO - 2024-10-14 10:03:03 --> Utf8 Class Initialized
INFO - 2024-10-14 10:03:03 --> URI Class Initialized
INFO - 2024-10-14 10:03:03 --> Router Class Initialized
INFO - 2024-10-14 10:03:03 --> Output Class Initialized
INFO - 2024-10-14 10:03:03 --> Security Class Initialized
DEBUG - 2024-10-14 10:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 10:03:03 --> Input Class Initialized
INFO - 2024-10-14 10:03:03 --> Language Class Initialized
INFO - 2024-10-14 10:03:03 --> Language Class Initialized
INFO - 2024-10-14 10:03:03 --> Config Class Initialized
INFO - 2024-10-14 10:03:03 --> Loader Class Initialized
INFO - 2024-10-14 10:03:03 --> Helper loaded: url_helper
INFO - 2024-10-14 10:03:03 --> Helper loaded: file_helper
INFO - 2024-10-14 10:03:03 --> Helper loaded: form_helper
INFO - 2024-10-14 10:03:03 --> Helper loaded: my_helper
INFO - 2024-10-14 10:03:03 --> Database Driver Class Initialized
INFO - 2024-10-14 10:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 10:03:03 --> Controller Class Initialized
INFO - 2024-10-14 10:03:03 --> Helper loaded: cookie_helper
INFO - 2024-10-14 10:03:03 --> Config Class Initialized
INFO - 2024-10-14 10:03:03 --> Hooks Class Initialized
DEBUG - 2024-10-14 10:03:03 --> UTF-8 Support Enabled
INFO - 2024-10-14 10:03:03 --> Utf8 Class Initialized
INFO - 2024-10-14 10:03:03 --> URI Class Initialized
INFO - 2024-10-14 10:03:03 --> Router Class Initialized
INFO - 2024-10-14 10:03:03 --> Output Class Initialized
INFO - 2024-10-14 10:03:03 --> Security Class Initialized
DEBUG - 2024-10-14 10:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 10:03:03 --> Input Class Initialized
INFO - 2024-10-14 10:03:03 --> Language Class Initialized
INFO - 2024-10-14 10:03:03 --> Language Class Initialized
INFO - 2024-10-14 10:03:03 --> Config Class Initialized
INFO - 2024-10-14 10:03:03 --> Loader Class Initialized
INFO - 2024-10-14 10:03:03 --> Helper loaded: url_helper
INFO - 2024-10-14 10:03:03 --> Helper loaded: file_helper
INFO - 2024-10-14 10:03:03 --> Helper loaded: form_helper
INFO - 2024-10-14 10:03:03 --> Helper loaded: my_helper
INFO - 2024-10-14 10:03:03 --> Database Driver Class Initialized
INFO - 2024-10-14 10:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 10:03:03 --> Controller Class Initialized
DEBUG - 2024-10-14 10:03:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-14 10:03:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 10:03:03 --> Final output sent to browser
DEBUG - 2024-10-14 10:03:03 --> Total execution time: 0.0370
INFO - 2024-10-14 10:03:14 --> Config Class Initialized
INFO - 2024-10-14 10:03:14 --> Hooks Class Initialized
DEBUG - 2024-10-14 10:03:14 --> UTF-8 Support Enabled
INFO - 2024-10-14 10:03:14 --> Utf8 Class Initialized
INFO - 2024-10-14 10:03:14 --> URI Class Initialized
INFO - 2024-10-14 10:03:14 --> Router Class Initialized
INFO - 2024-10-14 10:03:14 --> Output Class Initialized
INFO - 2024-10-14 10:03:14 --> Security Class Initialized
DEBUG - 2024-10-14 10:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 10:03:14 --> Input Class Initialized
INFO - 2024-10-14 10:03:14 --> Language Class Initialized
INFO - 2024-10-14 10:03:14 --> Language Class Initialized
INFO - 2024-10-14 10:03:14 --> Config Class Initialized
INFO - 2024-10-14 10:03:14 --> Loader Class Initialized
INFO - 2024-10-14 10:03:14 --> Helper loaded: url_helper
INFO - 2024-10-14 10:03:14 --> Helper loaded: file_helper
INFO - 2024-10-14 10:03:14 --> Helper loaded: form_helper
INFO - 2024-10-14 10:03:14 --> Helper loaded: my_helper
INFO - 2024-10-14 10:03:14 --> Database Driver Class Initialized
INFO - 2024-10-14 10:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 10:03:14 --> Controller Class Initialized
ERROR - 2024-10-14 10:03:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-14 10:03:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-14 10:03:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-14 10:03:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-14 10:03:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-14 10:03:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-14 10:03:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-14 10:03:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-14 10:03:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-14 10:03:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-14 10:03:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-14 10:03:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-14 10:03:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-14 10:03:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-14 10:03:17 --> Final output sent to browser
DEBUG - 2024-10-14 10:03:17 --> Total execution time: 3.0257
INFO - 2024-10-14 10:04:07 --> Config Class Initialized
INFO - 2024-10-14 10:04:07 --> Hooks Class Initialized
DEBUG - 2024-10-14 10:04:07 --> UTF-8 Support Enabled
INFO - 2024-10-14 10:04:07 --> Utf8 Class Initialized
INFO - 2024-10-14 10:04:07 --> URI Class Initialized
INFO - 2024-10-14 10:04:07 --> Router Class Initialized
INFO - 2024-10-14 10:04:07 --> Output Class Initialized
INFO - 2024-10-14 10:04:07 --> Security Class Initialized
DEBUG - 2024-10-14 10:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 10:04:07 --> Input Class Initialized
INFO - 2024-10-14 10:04:07 --> Language Class Initialized
INFO - 2024-10-14 10:04:07 --> Language Class Initialized
INFO - 2024-10-14 10:04:07 --> Config Class Initialized
INFO - 2024-10-14 10:04:07 --> Loader Class Initialized
INFO - 2024-10-14 10:04:07 --> Helper loaded: url_helper
INFO - 2024-10-14 10:04:07 --> Helper loaded: file_helper
INFO - 2024-10-14 10:04:07 --> Helper loaded: form_helper
INFO - 2024-10-14 10:04:07 --> Helper loaded: my_helper
INFO - 2024-10-14 10:04:07 --> Database Driver Class Initialized
INFO - 2024-10-14 10:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 10:04:07 --> Controller Class Initialized
DEBUG - 2024-10-14 10:04:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-14 10:04:10 --> Final output sent to browser
DEBUG - 2024-10-14 10:04:10 --> Total execution time: 3.2782
INFO - 2024-10-14 10:04:50 --> Config Class Initialized
INFO - 2024-10-14 10:04:50 --> Hooks Class Initialized
DEBUG - 2024-10-14 10:04:50 --> UTF-8 Support Enabled
INFO - 2024-10-14 10:04:50 --> Utf8 Class Initialized
INFO - 2024-10-14 10:04:50 --> URI Class Initialized
INFO - 2024-10-14 10:04:50 --> Router Class Initialized
INFO - 2024-10-14 10:04:50 --> Output Class Initialized
INFO - 2024-10-14 10:04:50 --> Security Class Initialized
DEBUG - 2024-10-14 10:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 10:04:50 --> Input Class Initialized
INFO - 2024-10-14 10:04:50 --> Language Class Initialized
INFO - 2024-10-14 10:04:50 --> Language Class Initialized
INFO - 2024-10-14 10:04:50 --> Config Class Initialized
INFO - 2024-10-14 10:04:50 --> Loader Class Initialized
INFO - 2024-10-14 10:04:50 --> Helper loaded: url_helper
INFO - 2024-10-14 10:04:50 --> Helper loaded: file_helper
INFO - 2024-10-14 10:04:50 --> Helper loaded: form_helper
INFO - 2024-10-14 10:04:50 --> Helper loaded: my_helper
INFO - 2024-10-14 10:04:50 --> Database Driver Class Initialized
INFO - 2024-10-14 10:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 10:04:50 --> Controller Class Initialized
DEBUG - 2024-10-14 10:04:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-14 10:04:54 --> Final output sent to browser
DEBUG - 2024-10-14 10:04:54 --> Total execution time: 3.8021
INFO - 2024-10-14 10:06:01 --> Config Class Initialized
INFO - 2024-10-14 10:06:01 --> Hooks Class Initialized
DEBUG - 2024-10-14 10:06:01 --> UTF-8 Support Enabled
INFO - 2024-10-14 10:06:01 --> Utf8 Class Initialized
INFO - 2024-10-14 10:06:01 --> URI Class Initialized
INFO - 2024-10-14 10:06:01 --> Router Class Initialized
INFO - 2024-10-14 10:06:01 --> Output Class Initialized
INFO - 2024-10-14 10:06:01 --> Security Class Initialized
DEBUG - 2024-10-14 10:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 10:06:01 --> Input Class Initialized
INFO - 2024-10-14 10:06:01 --> Language Class Initialized
INFO - 2024-10-14 10:06:01 --> Language Class Initialized
INFO - 2024-10-14 10:06:01 --> Config Class Initialized
INFO - 2024-10-14 10:06:01 --> Loader Class Initialized
INFO - 2024-10-14 10:06:01 --> Helper loaded: url_helper
INFO - 2024-10-14 10:06:01 --> Helper loaded: file_helper
INFO - 2024-10-14 10:06:01 --> Helper loaded: form_helper
INFO - 2024-10-14 10:06:01 --> Helper loaded: my_helper
INFO - 2024-10-14 10:06:01 --> Database Driver Class Initialized
INFO - 2024-10-14 10:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 10:06:01 --> Controller Class Initialized
DEBUG - 2024-10-14 10:06:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-14 10:06:05 --> Final output sent to browser
DEBUG - 2024-10-14 10:06:05 --> Total execution time: 3.9684
INFO - 2024-10-14 10:07:08 --> Config Class Initialized
INFO - 2024-10-14 10:07:08 --> Hooks Class Initialized
DEBUG - 2024-10-14 10:07:08 --> UTF-8 Support Enabled
INFO - 2024-10-14 10:07:08 --> Utf8 Class Initialized
INFO - 2024-10-14 10:07:08 --> URI Class Initialized
DEBUG - 2024-10-14 10:07:08 --> No URI present. Default controller set.
INFO - 2024-10-14 10:07:08 --> Router Class Initialized
INFO - 2024-10-14 10:07:08 --> Output Class Initialized
INFO - 2024-10-14 10:07:08 --> Security Class Initialized
DEBUG - 2024-10-14 10:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 10:07:08 --> Input Class Initialized
INFO - 2024-10-14 10:07:08 --> Language Class Initialized
INFO - 2024-10-14 10:07:08 --> Language Class Initialized
INFO - 2024-10-14 10:07:08 --> Config Class Initialized
INFO - 2024-10-14 10:07:08 --> Loader Class Initialized
INFO - 2024-10-14 10:07:08 --> Helper loaded: url_helper
INFO - 2024-10-14 10:07:08 --> Helper loaded: file_helper
INFO - 2024-10-14 10:07:08 --> Helper loaded: form_helper
INFO - 2024-10-14 10:07:08 --> Helper loaded: my_helper
INFO - 2024-10-14 10:07:08 --> Database Driver Class Initialized
INFO - 2024-10-14 10:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 10:07:08 --> Controller Class Initialized
DEBUG - 2024-10-14 10:07:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-10-14 10:07:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 10:07:08 --> Final output sent to browser
DEBUG - 2024-10-14 10:07:08 --> Total execution time: 0.0814
INFO - 2024-10-14 10:07:16 --> Config Class Initialized
INFO - 2024-10-14 10:07:16 --> Hooks Class Initialized
DEBUG - 2024-10-14 10:07:16 --> UTF-8 Support Enabled
INFO - 2024-10-14 10:07:16 --> Utf8 Class Initialized
INFO - 2024-10-14 10:07:16 --> URI Class Initialized
INFO - 2024-10-14 10:07:16 --> Router Class Initialized
INFO - 2024-10-14 10:07:16 --> Output Class Initialized
INFO - 2024-10-14 10:07:16 --> Security Class Initialized
DEBUG - 2024-10-14 10:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 10:07:16 --> Input Class Initialized
INFO - 2024-10-14 10:07:16 --> Language Class Initialized
INFO - 2024-10-14 10:07:16 --> Language Class Initialized
INFO - 2024-10-14 10:07:16 --> Config Class Initialized
INFO - 2024-10-14 10:07:16 --> Loader Class Initialized
INFO - 2024-10-14 10:07:16 --> Helper loaded: url_helper
INFO - 2024-10-14 10:07:16 --> Helper loaded: file_helper
INFO - 2024-10-14 10:07:16 --> Helper loaded: form_helper
INFO - 2024-10-14 10:07:16 --> Helper loaded: my_helper
INFO - 2024-10-14 10:07:16 --> Database Driver Class Initialized
INFO - 2024-10-14 10:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 10:07:16 --> Controller Class Initialized
DEBUG - 2024-10-14 10:07:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-14 10:07:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 10:07:16 --> Final output sent to browser
DEBUG - 2024-10-14 10:07:16 --> Total execution time: 0.0335
INFO - 2024-10-14 10:30:55 --> Config Class Initialized
INFO - 2024-10-14 10:30:55 --> Hooks Class Initialized
DEBUG - 2024-10-14 10:30:55 --> UTF-8 Support Enabled
INFO - 2024-10-14 10:30:55 --> Utf8 Class Initialized
INFO - 2024-10-14 10:30:55 --> URI Class Initialized
INFO - 2024-10-14 10:30:55 --> Router Class Initialized
INFO - 2024-10-14 10:30:55 --> Output Class Initialized
INFO - 2024-10-14 10:30:55 --> Security Class Initialized
DEBUG - 2024-10-14 10:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 10:30:55 --> Input Class Initialized
INFO - 2024-10-14 10:30:55 --> Language Class Initialized
INFO - 2024-10-14 10:30:55 --> Language Class Initialized
INFO - 2024-10-14 10:30:55 --> Config Class Initialized
INFO - 2024-10-14 10:30:55 --> Loader Class Initialized
INFO - 2024-10-14 10:30:55 --> Helper loaded: url_helper
INFO - 2024-10-14 10:30:55 --> Helper loaded: file_helper
INFO - 2024-10-14 10:30:55 --> Helper loaded: form_helper
INFO - 2024-10-14 10:30:55 --> Helper loaded: my_helper
INFO - 2024-10-14 10:30:55 --> Database Driver Class Initialized
INFO - 2024-10-14 10:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 10:30:55 --> Controller Class Initialized
ERROR - 2024-10-14 10:30:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-10-14 10:30:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-10-14 10:30:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-10-14 10:30:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-10-14 10:30:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-10-14 10:30:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-10-14 10:30:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-10-14 10:30:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-10-14 10:30:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-10-14 10:30:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-10-14 10:30:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-10-14 10:30:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-10-14 10:30:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-10-14 10:30:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-10-14 10:30:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-10-14 10:30:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-10-14 10:30:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-10-14 10:30:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-10-14 10:30:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-10-14 10:30:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-10-14 10:30:58 --> Final output sent to browser
DEBUG - 2024-10-14 10:30:58 --> Total execution time: 3.1217
INFO - 2024-10-14 10:31:00 --> Config Class Initialized
INFO - 2024-10-14 10:31:00 --> Hooks Class Initialized
DEBUG - 2024-10-14 10:31:00 --> UTF-8 Support Enabled
INFO - 2024-10-14 10:31:00 --> Utf8 Class Initialized
INFO - 2024-10-14 10:31:00 --> URI Class Initialized
INFO - 2024-10-14 10:31:00 --> Router Class Initialized
INFO - 2024-10-14 10:31:00 --> Output Class Initialized
INFO - 2024-10-14 10:31:00 --> Security Class Initialized
DEBUG - 2024-10-14 10:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 10:31:00 --> Input Class Initialized
INFO - 2024-10-14 10:31:00 --> Language Class Initialized
INFO - 2024-10-14 10:31:00 --> Language Class Initialized
INFO - 2024-10-14 10:31:00 --> Config Class Initialized
INFO - 2024-10-14 10:31:00 --> Loader Class Initialized
INFO - 2024-10-14 10:31:00 --> Helper loaded: url_helper
INFO - 2024-10-14 10:31:00 --> Helper loaded: file_helper
INFO - 2024-10-14 10:31:00 --> Helper loaded: form_helper
INFO - 2024-10-14 10:31:00 --> Helper loaded: my_helper
INFO - 2024-10-14 10:31:01 --> Database Driver Class Initialized
INFO - 2024-10-14 10:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 10:31:01 --> Controller Class Initialized
ERROR - 2024-10-14 10:31:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2591
ERROR - 2024-10-14 10:31:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3156
ERROR - 2024-10-14 10:31:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3194
ERROR - 2024-10-14 10:31:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3232
ERROR - 2024-10-14 10:31:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3271
ERROR - 2024-10-14 10:31:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3388
ERROR - 2024-10-14 10:31:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3507
ERROR - 2024-10-14 10:31:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3626
ERROR - 2024-10-14 10:31:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3745
ERROR - 2024-10-14 10:31:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-10-14 10:31:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-10-14 10:31:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 40
ERROR - 2024-10-14 10:31:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-10-14 10:31:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-10-14 10:31:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
ERROR - 2024-10-14 10:31:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
DEBUG - 2024-10-14 10:31:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-10-14 10:58:46 --> Config Class Initialized
INFO - 2024-10-14 10:58:46 --> Hooks Class Initialized
DEBUG - 2024-10-14 10:58:46 --> UTF-8 Support Enabled
INFO - 2024-10-14 10:58:46 --> Utf8 Class Initialized
INFO - 2024-10-14 10:58:46 --> URI Class Initialized
INFO - 2024-10-14 10:58:46 --> Router Class Initialized
INFO - 2024-10-14 10:58:46 --> Output Class Initialized
INFO - 2024-10-14 10:58:46 --> Security Class Initialized
DEBUG - 2024-10-14 10:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 10:58:46 --> Input Class Initialized
INFO - 2024-10-14 10:58:46 --> Language Class Initialized
INFO - 2024-10-14 10:58:46 --> Language Class Initialized
INFO - 2024-10-14 10:58:46 --> Config Class Initialized
INFO - 2024-10-14 10:58:46 --> Loader Class Initialized
INFO - 2024-10-14 10:58:46 --> Helper loaded: url_helper
INFO - 2024-10-14 10:58:46 --> Helper loaded: file_helper
INFO - 2024-10-14 10:58:46 --> Helper loaded: form_helper
INFO - 2024-10-14 10:58:46 --> Helper loaded: my_helper
INFO - 2024-10-14 10:58:46 --> Database Driver Class Initialized
INFO - 2024-10-14 10:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 10:58:46 --> Controller Class Initialized
INFO - 2024-10-14 10:58:46 --> Helper loaded: cookie_helper
INFO - 2024-10-14 10:58:46 --> Final output sent to browser
DEBUG - 2024-10-14 10:58:46 --> Total execution time: 0.0491
INFO - 2024-10-14 10:58:46 --> Config Class Initialized
INFO - 2024-10-14 10:58:46 --> Hooks Class Initialized
DEBUG - 2024-10-14 10:58:46 --> UTF-8 Support Enabled
INFO - 2024-10-14 10:58:46 --> Utf8 Class Initialized
INFO - 2024-10-14 10:58:46 --> URI Class Initialized
INFO - 2024-10-14 10:58:46 --> Router Class Initialized
INFO - 2024-10-14 10:58:46 --> Output Class Initialized
INFO - 2024-10-14 10:58:46 --> Security Class Initialized
DEBUG - 2024-10-14 10:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 10:58:46 --> Input Class Initialized
INFO - 2024-10-14 10:58:46 --> Language Class Initialized
INFO - 2024-10-14 10:58:46 --> Language Class Initialized
INFO - 2024-10-14 10:58:46 --> Config Class Initialized
INFO - 2024-10-14 10:58:46 --> Loader Class Initialized
INFO - 2024-10-14 10:58:46 --> Helper loaded: url_helper
INFO - 2024-10-14 10:58:46 --> Helper loaded: file_helper
INFO - 2024-10-14 10:58:46 --> Helper loaded: form_helper
INFO - 2024-10-14 10:58:46 --> Helper loaded: my_helper
INFO - 2024-10-14 10:58:46 --> Database Driver Class Initialized
INFO - 2024-10-14 10:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 10:58:46 --> Controller Class Initialized
INFO - 2024-10-14 10:58:46 --> Helper loaded: cookie_helper
INFO - 2024-10-14 10:58:46 --> Config Class Initialized
INFO - 2024-10-14 10:58:46 --> Hooks Class Initialized
DEBUG - 2024-10-14 10:58:46 --> UTF-8 Support Enabled
INFO - 2024-10-14 10:58:46 --> Utf8 Class Initialized
INFO - 2024-10-14 10:58:46 --> URI Class Initialized
INFO - 2024-10-14 10:58:46 --> Router Class Initialized
INFO - 2024-10-14 10:58:46 --> Output Class Initialized
INFO - 2024-10-14 10:58:46 --> Security Class Initialized
DEBUG - 2024-10-14 10:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 10:58:46 --> Input Class Initialized
INFO - 2024-10-14 10:58:46 --> Language Class Initialized
INFO - 2024-10-14 10:58:46 --> Language Class Initialized
INFO - 2024-10-14 10:58:46 --> Config Class Initialized
INFO - 2024-10-14 10:58:46 --> Loader Class Initialized
INFO - 2024-10-14 10:58:46 --> Helper loaded: url_helper
INFO - 2024-10-14 10:58:46 --> Helper loaded: file_helper
INFO - 2024-10-14 10:58:46 --> Helper loaded: form_helper
INFO - 2024-10-14 10:58:46 --> Helper loaded: my_helper
INFO - 2024-10-14 10:58:46 --> Database Driver Class Initialized
INFO - 2024-10-14 10:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 10:58:46 --> Controller Class Initialized
DEBUG - 2024-10-14 10:58:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-14 10:58:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 10:58:46 --> Final output sent to browser
DEBUG - 2024-10-14 10:58:46 --> Total execution time: 0.0375
INFO - 2024-10-14 10:58:48 --> Config Class Initialized
INFO - 2024-10-14 10:58:48 --> Hooks Class Initialized
DEBUG - 2024-10-14 10:58:48 --> UTF-8 Support Enabled
INFO - 2024-10-14 10:58:48 --> Utf8 Class Initialized
INFO - 2024-10-14 10:58:48 --> URI Class Initialized
INFO - 2024-10-14 10:58:48 --> Router Class Initialized
INFO - 2024-10-14 10:58:48 --> Output Class Initialized
INFO - 2024-10-14 10:58:48 --> Security Class Initialized
DEBUG - 2024-10-14 10:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 10:58:48 --> Input Class Initialized
INFO - 2024-10-14 10:58:48 --> Language Class Initialized
INFO - 2024-10-14 10:58:48 --> Language Class Initialized
INFO - 2024-10-14 10:58:48 --> Config Class Initialized
INFO - 2024-10-14 10:58:48 --> Loader Class Initialized
INFO - 2024-10-14 10:58:48 --> Helper loaded: url_helper
INFO - 2024-10-14 10:58:48 --> Helper loaded: file_helper
INFO - 2024-10-14 10:58:48 --> Helper loaded: form_helper
INFO - 2024-10-14 10:58:48 --> Helper loaded: my_helper
INFO - 2024-10-14 10:58:48 --> Database Driver Class Initialized
INFO - 2024-10-14 10:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 10:58:48 --> Controller Class Initialized
DEBUG - 2024-10-14 10:58:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-14 10:58:52 --> Final output sent to browser
DEBUG - 2024-10-14 10:58:52 --> Total execution time: 3.8936
INFO - 2024-10-14 11:00:11 --> Config Class Initialized
INFO - 2024-10-14 11:00:11 --> Hooks Class Initialized
DEBUG - 2024-10-14 11:00:11 --> UTF-8 Support Enabled
INFO - 2024-10-14 11:00:11 --> Utf8 Class Initialized
INFO - 2024-10-14 11:00:11 --> URI Class Initialized
INFO - 2024-10-14 11:00:11 --> Router Class Initialized
INFO - 2024-10-14 11:00:11 --> Output Class Initialized
INFO - 2024-10-14 11:00:11 --> Security Class Initialized
DEBUG - 2024-10-14 11:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 11:00:11 --> Input Class Initialized
INFO - 2024-10-14 11:00:11 --> Language Class Initialized
INFO - 2024-10-14 11:00:11 --> Language Class Initialized
INFO - 2024-10-14 11:00:11 --> Config Class Initialized
INFO - 2024-10-14 11:00:11 --> Loader Class Initialized
INFO - 2024-10-14 11:00:11 --> Helper loaded: url_helper
INFO - 2024-10-14 11:00:11 --> Helper loaded: file_helper
INFO - 2024-10-14 11:00:11 --> Helper loaded: form_helper
INFO - 2024-10-14 11:00:11 --> Helper loaded: my_helper
INFO - 2024-10-14 11:00:11 --> Database Driver Class Initialized
INFO - 2024-10-14 11:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 11:00:11 --> Controller Class Initialized
INFO - 2024-10-14 11:00:11 --> Helper loaded: cookie_helper
INFO - 2024-10-14 11:00:11 --> Final output sent to browser
DEBUG - 2024-10-14 11:00:11 --> Total execution time: 0.4318
INFO - 2024-10-14 11:00:12 --> Config Class Initialized
INFO - 2024-10-14 11:00:12 --> Hooks Class Initialized
DEBUG - 2024-10-14 11:00:12 --> UTF-8 Support Enabled
INFO - 2024-10-14 11:00:12 --> Utf8 Class Initialized
INFO - 2024-10-14 11:00:12 --> URI Class Initialized
INFO - 2024-10-14 11:00:12 --> Router Class Initialized
INFO - 2024-10-14 11:00:12 --> Output Class Initialized
INFO - 2024-10-14 11:00:12 --> Security Class Initialized
DEBUG - 2024-10-14 11:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 11:00:12 --> Input Class Initialized
INFO - 2024-10-14 11:00:12 --> Language Class Initialized
INFO - 2024-10-14 11:00:12 --> Language Class Initialized
INFO - 2024-10-14 11:00:12 --> Config Class Initialized
INFO - 2024-10-14 11:00:12 --> Loader Class Initialized
INFO - 2024-10-14 11:00:12 --> Helper loaded: url_helper
INFO - 2024-10-14 11:00:12 --> Helper loaded: file_helper
INFO - 2024-10-14 11:00:12 --> Helper loaded: form_helper
INFO - 2024-10-14 11:00:12 --> Helper loaded: my_helper
INFO - 2024-10-14 11:00:12 --> Database Driver Class Initialized
INFO - 2024-10-14 11:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 11:00:12 --> Controller Class Initialized
INFO - 2024-10-14 11:00:12 --> Helper loaded: cookie_helper
INFO - 2024-10-14 11:00:12 --> Config Class Initialized
INFO - 2024-10-14 11:00:12 --> Hooks Class Initialized
DEBUG - 2024-10-14 11:00:12 --> UTF-8 Support Enabled
INFO - 2024-10-14 11:00:12 --> Utf8 Class Initialized
INFO - 2024-10-14 11:00:12 --> URI Class Initialized
INFO - 2024-10-14 11:00:12 --> Router Class Initialized
INFO - 2024-10-14 11:00:12 --> Output Class Initialized
INFO - 2024-10-14 11:00:12 --> Security Class Initialized
DEBUG - 2024-10-14 11:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 11:00:12 --> Input Class Initialized
INFO - 2024-10-14 11:00:12 --> Language Class Initialized
INFO - 2024-10-14 11:00:12 --> Language Class Initialized
INFO - 2024-10-14 11:00:12 --> Config Class Initialized
INFO - 2024-10-14 11:00:12 --> Loader Class Initialized
INFO - 2024-10-14 11:00:12 --> Helper loaded: url_helper
INFO - 2024-10-14 11:00:12 --> Helper loaded: file_helper
INFO - 2024-10-14 11:00:12 --> Helper loaded: form_helper
INFO - 2024-10-14 11:00:12 --> Helper loaded: my_helper
INFO - 2024-10-14 11:00:12 --> Database Driver Class Initialized
INFO - 2024-10-14 11:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 11:00:12 --> Controller Class Initialized
DEBUG - 2024-10-14 11:00:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-14 11:00:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 11:00:12 --> Final output sent to browser
DEBUG - 2024-10-14 11:00:12 --> Total execution time: 0.4232
INFO - 2024-10-14 11:00:14 --> Config Class Initialized
INFO - 2024-10-14 11:00:14 --> Hooks Class Initialized
DEBUG - 2024-10-14 11:00:14 --> UTF-8 Support Enabled
INFO - 2024-10-14 11:00:14 --> Utf8 Class Initialized
INFO - 2024-10-14 11:00:14 --> URI Class Initialized
INFO - 2024-10-14 11:00:14 --> Router Class Initialized
INFO - 2024-10-14 11:00:14 --> Output Class Initialized
INFO - 2024-10-14 11:00:14 --> Security Class Initialized
DEBUG - 2024-10-14 11:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 11:00:14 --> Input Class Initialized
INFO - 2024-10-14 11:00:14 --> Language Class Initialized
INFO - 2024-10-14 11:00:14 --> Language Class Initialized
INFO - 2024-10-14 11:00:14 --> Config Class Initialized
INFO - 2024-10-14 11:00:14 --> Loader Class Initialized
INFO - 2024-10-14 11:00:14 --> Helper loaded: url_helper
INFO - 2024-10-14 11:00:14 --> Helper loaded: file_helper
INFO - 2024-10-14 11:00:14 --> Helper loaded: form_helper
INFO - 2024-10-14 11:00:14 --> Helper loaded: my_helper
INFO - 2024-10-14 11:00:14 --> Database Driver Class Initialized
INFO - 2024-10-14 11:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 11:00:14 --> Controller Class Initialized
DEBUG - 2024-10-14 11:00:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-14 11:00:32 --> Final output sent to browser
DEBUG - 2024-10-14 11:00:32 --> Total execution time: 18.4756
INFO - 2024-10-14 11:07:30 --> Config Class Initialized
INFO - 2024-10-14 11:07:30 --> Hooks Class Initialized
DEBUG - 2024-10-14 11:07:30 --> UTF-8 Support Enabled
INFO - 2024-10-14 11:07:30 --> Utf8 Class Initialized
INFO - 2024-10-14 11:07:30 --> URI Class Initialized
INFO - 2024-10-14 11:07:30 --> Router Class Initialized
INFO - 2024-10-14 11:07:30 --> Output Class Initialized
INFO - 2024-10-14 11:07:30 --> Security Class Initialized
DEBUG - 2024-10-14 11:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 11:07:30 --> Input Class Initialized
INFO - 2024-10-14 11:07:30 --> Language Class Initialized
INFO - 2024-10-14 11:07:30 --> Language Class Initialized
INFO - 2024-10-14 11:07:30 --> Config Class Initialized
INFO - 2024-10-14 11:07:30 --> Loader Class Initialized
INFO - 2024-10-14 11:07:30 --> Helper loaded: url_helper
INFO - 2024-10-14 11:07:30 --> Helper loaded: file_helper
INFO - 2024-10-14 11:07:30 --> Helper loaded: form_helper
INFO - 2024-10-14 11:07:30 --> Helper loaded: my_helper
INFO - 2024-10-14 11:07:30 --> Database Driver Class Initialized
INFO - 2024-10-14 11:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 11:07:30 --> Controller Class Initialized
INFO - 2024-10-14 11:07:30 --> Helper loaded: cookie_helper
INFO - 2024-10-14 11:07:30 --> Final output sent to browser
DEBUG - 2024-10-14 11:07:30 --> Total execution time: 0.0613
INFO - 2024-10-14 11:07:30 --> Config Class Initialized
INFO - 2024-10-14 11:07:30 --> Hooks Class Initialized
DEBUG - 2024-10-14 11:07:30 --> UTF-8 Support Enabled
INFO - 2024-10-14 11:07:30 --> Utf8 Class Initialized
INFO - 2024-10-14 11:07:30 --> URI Class Initialized
INFO - 2024-10-14 11:07:30 --> Router Class Initialized
INFO - 2024-10-14 11:07:30 --> Output Class Initialized
INFO - 2024-10-14 11:07:30 --> Security Class Initialized
DEBUG - 2024-10-14 11:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 11:07:30 --> Input Class Initialized
INFO - 2024-10-14 11:07:30 --> Language Class Initialized
INFO - 2024-10-14 11:07:30 --> Language Class Initialized
INFO - 2024-10-14 11:07:30 --> Config Class Initialized
INFO - 2024-10-14 11:07:30 --> Loader Class Initialized
INFO - 2024-10-14 11:07:30 --> Helper loaded: url_helper
INFO - 2024-10-14 11:07:30 --> Helper loaded: file_helper
INFO - 2024-10-14 11:07:30 --> Helper loaded: form_helper
INFO - 2024-10-14 11:07:30 --> Helper loaded: my_helper
INFO - 2024-10-14 11:07:30 --> Database Driver Class Initialized
INFO - 2024-10-14 11:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 11:07:30 --> Controller Class Initialized
INFO - 2024-10-14 11:07:30 --> Helper loaded: cookie_helper
INFO - 2024-10-14 11:07:30 --> Config Class Initialized
INFO - 2024-10-14 11:07:30 --> Hooks Class Initialized
DEBUG - 2024-10-14 11:07:30 --> UTF-8 Support Enabled
INFO - 2024-10-14 11:07:30 --> Utf8 Class Initialized
INFO - 2024-10-14 11:07:30 --> URI Class Initialized
INFO - 2024-10-14 11:07:30 --> Router Class Initialized
INFO - 2024-10-14 11:07:30 --> Output Class Initialized
INFO - 2024-10-14 11:07:30 --> Security Class Initialized
DEBUG - 2024-10-14 11:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 11:07:30 --> Input Class Initialized
INFO - 2024-10-14 11:07:30 --> Language Class Initialized
INFO - 2024-10-14 11:07:30 --> Language Class Initialized
INFO - 2024-10-14 11:07:30 --> Config Class Initialized
INFO - 2024-10-14 11:07:30 --> Loader Class Initialized
INFO - 2024-10-14 11:07:30 --> Helper loaded: url_helper
INFO - 2024-10-14 11:07:30 --> Helper loaded: file_helper
INFO - 2024-10-14 11:07:30 --> Helper loaded: form_helper
INFO - 2024-10-14 11:07:30 --> Helper loaded: my_helper
INFO - 2024-10-14 11:07:30 --> Database Driver Class Initialized
INFO - 2024-10-14 11:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 11:07:30 --> Controller Class Initialized
DEBUG - 2024-10-14 11:07:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-14 11:07:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 11:07:30 --> Final output sent to browser
DEBUG - 2024-10-14 11:07:30 --> Total execution time: 0.0427
INFO - 2024-10-14 11:07:33 --> Config Class Initialized
INFO - 2024-10-14 11:07:33 --> Hooks Class Initialized
DEBUG - 2024-10-14 11:07:33 --> UTF-8 Support Enabled
INFO - 2024-10-14 11:07:33 --> Utf8 Class Initialized
INFO - 2024-10-14 11:07:33 --> URI Class Initialized
INFO - 2024-10-14 11:07:33 --> Router Class Initialized
INFO - 2024-10-14 11:07:33 --> Output Class Initialized
INFO - 2024-10-14 11:07:33 --> Security Class Initialized
DEBUG - 2024-10-14 11:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 11:07:33 --> Input Class Initialized
INFO - 2024-10-14 11:07:33 --> Language Class Initialized
INFO - 2024-10-14 11:07:33 --> Language Class Initialized
INFO - 2024-10-14 11:07:33 --> Config Class Initialized
INFO - 2024-10-14 11:07:33 --> Loader Class Initialized
INFO - 2024-10-14 11:07:33 --> Helper loaded: url_helper
INFO - 2024-10-14 11:07:33 --> Helper loaded: file_helper
INFO - 2024-10-14 11:07:33 --> Helper loaded: form_helper
INFO - 2024-10-14 11:07:33 --> Helper loaded: my_helper
INFO - 2024-10-14 11:07:33 --> Database Driver Class Initialized
INFO - 2024-10-14 11:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 11:07:33 --> Controller Class Initialized
DEBUG - 2024-10-14 11:07:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-14 11:07:36 --> Final output sent to browser
DEBUG - 2024-10-14 11:07:36 --> Total execution time: 3.2375
INFO - 2024-10-14 11:10:22 --> Config Class Initialized
INFO - 2024-10-14 11:10:22 --> Hooks Class Initialized
DEBUG - 2024-10-14 11:10:22 --> UTF-8 Support Enabled
INFO - 2024-10-14 11:10:22 --> Utf8 Class Initialized
INFO - 2024-10-14 11:10:22 --> URI Class Initialized
INFO - 2024-10-14 11:10:22 --> Router Class Initialized
INFO - 2024-10-14 11:10:22 --> Output Class Initialized
INFO - 2024-10-14 11:10:22 --> Security Class Initialized
DEBUG - 2024-10-14 11:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 11:10:22 --> Input Class Initialized
INFO - 2024-10-14 11:10:22 --> Language Class Initialized
INFO - 2024-10-14 11:10:22 --> Language Class Initialized
INFO - 2024-10-14 11:10:22 --> Config Class Initialized
INFO - 2024-10-14 11:10:22 --> Loader Class Initialized
INFO - 2024-10-14 11:10:22 --> Helper loaded: url_helper
INFO - 2024-10-14 11:10:22 --> Helper loaded: file_helper
INFO - 2024-10-14 11:10:22 --> Helper loaded: form_helper
INFO - 2024-10-14 11:10:22 --> Helper loaded: my_helper
INFO - 2024-10-14 11:10:22 --> Database Driver Class Initialized
INFO - 2024-10-14 11:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 11:10:22 --> Controller Class Initialized
INFO - 2024-10-14 11:10:22 --> Helper loaded: cookie_helper
INFO - 2024-10-14 11:10:22 --> Final output sent to browser
DEBUG - 2024-10-14 11:10:22 --> Total execution time: 0.0354
INFO - 2024-10-14 11:10:22 --> Config Class Initialized
INFO - 2024-10-14 11:10:22 --> Hooks Class Initialized
DEBUG - 2024-10-14 11:10:22 --> UTF-8 Support Enabled
INFO - 2024-10-14 11:10:22 --> Utf8 Class Initialized
INFO - 2024-10-14 11:10:22 --> URI Class Initialized
INFO - 2024-10-14 11:10:22 --> Router Class Initialized
INFO - 2024-10-14 11:10:22 --> Output Class Initialized
INFO - 2024-10-14 11:10:22 --> Security Class Initialized
DEBUG - 2024-10-14 11:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 11:10:22 --> Input Class Initialized
INFO - 2024-10-14 11:10:22 --> Language Class Initialized
INFO - 2024-10-14 11:10:22 --> Language Class Initialized
INFO - 2024-10-14 11:10:22 --> Config Class Initialized
INFO - 2024-10-14 11:10:22 --> Loader Class Initialized
INFO - 2024-10-14 11:10:22 --> Helper loaded: url_helper
INFO - 2024-10-14 11:10:22 --> Helper loaded: file_helper
INFO - 2024-10-14 11:10:22 --> Helper loaded: form_helper
INFO - 2024-10-14 11:10:22 --> Helper loaded: my_helper
INFO - 2024-10-14 11:10:22 --> Database Driver Class Initialized
INFO - 2024-10-14 11:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 11:10:22 --> Controller Class Initialized
INFO - 2024-10-14 11:10:22 --> Helper loaded: cookie_helper
INFO - 2024-10-14 11:10:22 --> Config Class Initialized
INFO - 2024-10-14 11:10:22 --> Hooks Class Initialized
DEBUG - 2024-10-14 11:10:22 --> UTF-8 Support Enabled
INFO - 2024-10-14 11:10:22 --> Utf8 Class Initialized
INFO - 2024-10-14 11:10:22 --> URI Class Initialized
INFO - 2024-10-14 11:10:22 --> Router Class Initialized
INFO - 2024-10-14 11:10:22 --> Output Class Initialized
INFO - 2024-10-14 11:10:22 --> Security Class Initialized
DEBUG - 2024-10-14 11:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 11:10:22 --> Input Class Initialized
INFO - 2024-10-14 11:10:22 --> Language Class Initialized
INFO - 2024-10-14 11:10:22 --> Language Class Initialized
INFO - 2024-10-14 11:10:22 --> Config Class Initialized
INFO - 2024-10-14 11:10:22 --> Loader Class Initialized
INFO - 2024-10-14 11:10:22 --> Helper loaded: url_helper
INFO - 2024-10-14 11:10:22 --> Helper loaded: file_helper
INFO - 2024-10-14 11:10:22 --> Helper loaded: form_helper
INFO - 2024-10-14 11:10:22 --> Helper loaded: my_helper
INFO - 2024-10-14 11:10:22 --> Database Driver Class Initialized
INFO - 2024-10-14 11:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 11:10:22 --> Controller Class Initialized
DEBUG - 2024-10-14 11:10:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-14 11:10:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 11:10:22 --> Final output sent to browser
DEBUG - 2024-10-14 11:10:22 --> Total execution time: 0.0434
INFO - 2024-10-14 11:10:24 --> Config Class Initialized
INFO - 2024-10-14 11:10:24 --> Hooks Class Initialized
DEBUG - 2024-10-14 11:10:24 --> UTF-8 Support Enabled
INFO - 2024-10-14 11:10:24 --> Utf8 Class Initialized
INFO - 2024-10-14 11:10:24 --> URI Class Initialized
INFO - 2024-10-14 11:10:24 --> Router Class Initialized
INFO - 2024-10-14 11:10:24 --> Output Class Initialized
INFO - 2024-10-14 11:10:24 --> Security Class Initialized
DEBUG - 2024-10-14 11:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 11:10:24 --> Input Class Initialized
INFO - 2024-10-14 11:10:24 --> Language Class Initialized
INFO - 2024-10-14 11:10:24 --> Language Class Initialized
INFO - 2024-10-14 11:10:24 --> Config Class Initialized
INFO - 2024-10-14 11:10:24 --> Loader Class Initialized
INFO - 2024-10-14 11:10:24 --> Helper loaded: url_helper
INFO - 2024-10-14 11:10:24 --> Helper loaded: file_helper
INFO - 2024-10-14 11:10:24 --> Helper loaded: form_helper
INFO - 2024-10-14 11:10:24 --> Helper loaded: my_helper
INFO - 2024-10-14 11:10:24 --> Database Driver Class Initialized
INFO - 2024-10-14 11:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 11:10:24 --> Controller Class Initialized
DEBUG - 2024-10-14 11:10:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-14 11:10:27 --> Final output sent to browser
DEBUG - 2024-10-14 11:10:27 --> Total execution time: 3.3185
INFO - 2024-10-14 11:14:08 --> Config Class Initialized
INFO - 2024-10-14 11:14:08 --> Hooks Class Initialized
DEBUG - 2024-10-14 11:14:08 --> UTF-8 Support Enabled
INFO - 2024-10-14 11:14:08 --> Utf8 Class Initialized
INFO - 2024-10-14 11:14:08 --> URI Class Initialized
INFO - 2024-10-14 11:14:08 --> Router Class Initialized
INFO - 2024-10-14 11:14:08 --> Output Class Initialized
INFO - 2024-10-14 11:14:08 --> Security Class Initialized
DEBUG - 2024-10-14 11:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 11:14:08 --> Input Class Initialized
INFO - 2024-10-14 11:14:08 --> Language Class Initialized
INFO - 2024-10-14 11:14:08 --> Language Class Initialized
INFO - 2024-10-14 11:14:08 --> Config Class Initialized
INFO - 2024-10-14 11:14:08 --> Loader Class Initialized
INFO - 2024-10-14 11:14:08 --> Helper loaded: url_helper
INFO - 2024-10-14 11:14:08 --> Helper loaded: file_helper
INFO - 2024-10-14 11:14:08 --> Helper loaded: form_helper
INFO - 2024-10-14 11:14:08 --> Helper loaded: my_helper
INFO - 2024-10-14 11:14:08 --> Database Driver Class Initialized
INFO - 2024-10-14 11:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 11:14:08 --> Controller Class Initialized
INFO - 2024-10-14 11:14:08 --> Helper loaded: cookie_helper
INFO - 2024-10-14 11:14:08 --> Final output sent to browser
DEBUG - 2024-10-14 11:14:08 --> Total execution time: 0.0397
INFO - 2024-10-14 11:14:08 --> Config Class Initialized
INFO - 2024-10-14 11:14:08 --> Hooks Class Initialized
DEBUG - 2024-10-14 11:14:08 --> UTF-8 Support Enabled
INFO - 2024-10-14 11:14:08 --> Utf8 Class Initialized
INFO - 2024-10-14 11:14:08 --> URI Class Initialized
INFO - 2024-10-14 11:14:08 --> Router Class Initialized
INFO - 2024-10-14 11:14:08 --> Output Class Initialized
INFO - 2024-10-14 11:14:08 --> Security Class Initialized
DEBUG - 2024-10-14 11:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 11:14:08 --> Input Class Initialized
INFO - 2024-10-14 11:14:08 --> Language Class Initialized
INFO - 2024-10-14 11:14:08 --> Language Class Initialized
INFO - 2024-10-14 11:14:08 --> Config Class Initialized
INFO - 2024-10-14 11:14:08 --> Loader Class Initialized
INFO - 2024-10-14 11:14:08 --> Helper loaded: url_helper
INFO - 2024-10-14 11:14:08 --> Helper loaded: file_helper
INFO - 2024-10-14 11:14:08 --> Helper loaded: form_helper
INFO - 2024-10-14 11:14:08 --> Helper loaded: my_helper
INFO - 2024-10-14 11:14:08 --> Database Driver Class Initialized
INFO - 2024-10-14 11:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 11:14:08 --> Controller Class Initialized
INFO - 2024-10-14 11:14:08 --> Helper loaded: cookie_helper
INFO - 2024-10-14 11:14:08 --> Config Class Initialized
INFO - 2024-10-14 11:14:08 --> Hooks Class Initialized
DEBUG - 2024-10-14 11:14:08 --> UTF-8 Support Enabled
INFO - 2024-10-14 11:14:08 --> Utf8 Class Initialized
INFO - 2024-10-14 11:14:08 --> URI Class Initialized
INFO - 2024-10-14 11:14:08 --> Router Class Initialized
INFO - 2024-10-14 11:14:08 --> Output Class Initialized
INFO - 2024-10-14 11:14:08 --> Security Class Initialized
DEBUG - 2024-10-14 11:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 11:14:08 --> Input Class Initialized
INFO - 2024-10-14 11:14:08 --> Language Class Initialized
INFO - 2024-10-14 11:14:08 --> Language Class Initialized
INFO - 2024-10-14 11:14:08 --> Config Class Initialized
INFO - 2024-10-14 11:14:08 --> Loader Class Initialized
INFO - 2024-10-14 11:14:08 --> Helper loaded: url_helper
INFO - 2024-10-14 11:14:08 --> Helper loaded: file_helper
INFO - 2024-10-14 11:14:08 --> Helper loaded: form_helper
INFO - 2024-10-14 11:14:08 --> Helper loaded: my_helper
INFO - 2024-10-14 11:14:08 --> Database Driver Class Initialized
INFO - 2024-10-14 11:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 11:14:08 --> Controller Class Initialized
DEBUG - 2024-10-14 11:14:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-14 11:14:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 11:14:08 --> Final output sent to browser
DEBUG - 2024-10-14 11:14:08 --> Total execution time: 0.0313
INFO - 2024-10-14 11:14:10 --> Config Class Initialized
INFO - 2024-10-14 11:14:10 --> Hooks Class Initialized
DEBUG - 2024-10-14 11:14:10 --> UTF-8 Support Enabled
INFO - 2024-10-14 11:14:10 --> Utf8 Class Initialized
INFO - 2024-10-14 11:14:10 --> URI Class Initialized
INFO - 2024-10-14 11:14:10 --> Router Class Initialized
INFO - 2024-10-14 11:14:10 --> Output Class Initialized
INFO - 2024-10-14 11:14:10 --> Security Class Initialized
DEBUG - 2024-10-14 11:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 11:14:10 --> Input Class Initialized
INFO - 2024-10-14 11:14:10 --> Language Class Initialized
INFO - 2024-10-14 11:14:10 --> Language Class Initialized
INFO - 2024-10-14 11:14:10 --> Config Class Initialized
INFO - 2024-10-14 11:14:10 --> Loader Class Initialized
INFO - 2024-10-14 11:14:10 --> Helper loaded: url_helper
INFO - 2024-10-14 11:14:10 --> Helper loaded: file_helper
INFO - 2024-10-14 11:14:10 --> Helper loaded: form_helper
INFO - 2024-10-14 11:14:10 --> Helper loaded: my_helper
INFO - 2024-10-14 11:14:10 --> Database Driver Class Initialized
INFO - 2024-10-14 11:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 11:14:10 --> Controller Class Initialized
DEBUG - 2024-10-14 11:14:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-14 11:14:13 --> Final output sent to browser
DEBUG - 2024-10-14 11:14:13 --> Total execution time: 3.0009
INFO - 2024-10-14 12:36:54 --> Config Class Initialized
INFO - 2024-10-14 12:36:54 --> Hooks Class Initialized
DEBUG - 2024-10-14 12:36:54 --> UTF-8 Support Enabled
INFO - 2024-10-14 12:36:54 --> Utf8 Class Initialized
INFO - 2024-10-14 12:36:54 --> URI Class Initialized
INFO - 2024-10-14 12:36:54 --> Router Class Initialized
INFO - 2024-10-14 12:36:54 --> Output Class Initialized
INFO - 2024-10-14 12:36:54 --> Security Class Initialized
DEBUG - 2024-10-14 12:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 12:36:54 --> Input Class Initialized
INFO - 2024-10-14 12:36:54 --> Language Class Initialized
INFO - 2024-10-14 12:36:54 --> Language Class Initialized
INFO - 2024-10-14 12:36:54 --> Config Class Initialized
INFO - 2024-10-14 12:36:54 --> Loader Class Initialized
INFO - 2024-10-14 12:36:54 --> Helper loaded: url_helper
INFO - 2024-10-14 12:36:54 --> Helper loaded: file_helper
INFO - 2024-10-14 12:36:54 --> Helper loaded: form_helper
INFO - 2024-10-14 12:36:54 --> Helper loaded: my_helper
INFO - 2024-10-14 12:36:54 --> Database Driver Class Initialized
INFO - 2024-10-14 12:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 12:36:54 --> Controller Class Initialized
INFO - 2024-10-14 12:36:54 --> Helper loaded: cookie_helper
INFO - 2024-10-14 12:36:54 --> Final output sent to browser
DEBUG - 2024-10-14 12:36:54 --> Total execution time: 0.0677
INFO - 2024-10-14 12:36:55 --> Config Class Initialized
INFO - 2024-10-14 12:36:55 --> Hooks Class Initialized
DEBUG - 2024-10-14 12:36:55 --> UTF-8 Support Enabled
INFO - 2024-10-14 12:36:55 --> Utf8 Class Initialized
INFO - 2024-10-14 12:36:55 --> URI Class Initialized
INFO - 2024-10-14 12:36:55 --> Router Class Initialized
INFO - 2024-10-14 12:36:55 --> Output Class Initialized
INFO - 2024-10-14 12:36:55 --> Security Class Initialized
DEBUG - 2024-10-14 12:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 12:36:55 --> Input Class Initialized
INFO - 2024-10-14 12:36:55 --> Language Class Initialized
INFO - 2024-10-14 12:36:55 --> Language Class Initialized
INFO - 2024-10-14 12:36:55 --> Config Class Initialized
INFO - 2024-10-14 12:36:55 --> Loader Class Initialized
INFO - 2024-10-14 12:36:55 --> Helper loaded: url_helper
INFO - 2024-10-14 12:36:55 --> Helper loaded: file_helper
INFO - 2024-10-14 12:36:55 --> Helper loaded: form_helper
INFO - 2024-10-14 12:36:55 --> Helper loaded: my_helper
INFO - 2024-10-14 12:36:55 --> Database Driver Class Initialized
INFO - 2024-10-14 12:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 12:36:55 --> Controller Class Initialized
INFO - 2024-10-14 12:36:55 --> Helper loaded: cookie_helper
INFO - 2024-10-14 12:36:55 --> Config Class Initialized
INFO - 2024-10-14 12:36:55 --> Hooks Class Initialized
DEBUG - 2024-10-14 12:36:56 --> UTF-8 Support Enabled
INFO - 2024-10-14 12:36:56 --> Utf8 Class Initialized
INFO - 2024-10-14 12:36:56 --> URI Class Initialized
INFO - 2024-10-14 12:36:56 --> Router Class Initialized
INFO - 2024-10-14 12:36:56 --> Output Class Initialized
INFO - 2024-10-14 12:36:56 --> Security Class Initialized
DEBUG - 2024-10-14 12:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 12:36:56 --> Input Class Initialized
INFO - 2024-10-14 12:36:56 --> Language Class Initialized
INFO - 2024-10-14 12:36:56 --> Language Class Initialized
INFO - 2024-10-14 12:36:56 --> Config Class Initialized
INFO - 2024-10-14 12:36:56 --> Loader Class Initialized
INFO - 2024-10-14 12:36:56 --> Helper loaded: url_helper
INFO - 2024-10-14 12:36:56 --> Helper loaded: file_helper
INFO - 2024-10-14 12:36:56 --> Helper loaded: form_helper
INFO - 2024-10-14 12:36:56 --> Helper loaded: my_helper
INFO - 2024-10-14 12:36:56 --> Database Driver Class Initialized
INFO - 2024-10-14 12:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 12:36:56 --> Controller Class Initialized
DEBUG - 2024-10-14 12:36:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-14 12:36:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 12:36:56 --> Final output sent to browser
DEBUG - 2024-10-14 12:36:56 --> Total execution time: 0.0414
INFO - 2024-10-14 12:37:04 --> Config Class Initialized
INFO - 2024-10-14 12:37:04 --> Hooks Class Initialized
DEBUG - 2024-10-14 12:37:04 --> UTF-8 Support Enabled
INFO - 2024-10-14 12:37:04 --> Utf8 Class Initialized
INFO - 2024-10-14 12:37:04 --> URI Class Initialized
INFO - 2024-10-14 12:37:04 --> Router Class Initialized
INFO - 2024-10-14 12:37:04 --> Output Class Initialized
INFO - 2024-10-14 12:37:04 --> Security Class Initialized
DEBUG - 2024-10-14 12:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 12:37:04 --> Input Class Initialized
INFO - 2024-10-14 12:37:04 --> Language Class Initialized
INFO - 2024-10-14 12:37:04 --> Language Class Initialized
INFO - 2024-10-14 12:37:04 --> Config Class Initialized
INFO - 2024-10-14 12:37:04 --> Loader Class Initialized
INFO - 2024-10-14 12:37:04 --> Helper loaded: url_helper
INFO - 2024-10-14 12:37:04 --> Helper loaded: file_helper
INFO - 2024-10-14 12:37:04 --> Helper loaded: form_helper
INFO - 2024-10-14 12:37:04 --> Helper loaded: my_helper
INFO - 2024-10-14 12:37:04 --> Database Driver Class Initialized
INFO - 2024-10-14 12:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 12:37:04 --> Controller Class Initialized
ERROR - 2024-10-14 12:37:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-14 12:37:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-14 12:37:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-14 12:37:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-14 12:37:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-14 12:37:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-14 12:37:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-14 12:37:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-14 12:37:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-14 12:37:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-14 12:37:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-14 12:37:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-14 12:37:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-14 12:37:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-14 12:37:07 --> Final output sent to browser
DEBUG - 2024-10-14 12:37:07 --> Total execution time: 3.2847
INFO - 2024-10-14 12:37:58 --> Config Class Initialized
INFO - 2024-10-14 12:37:58 --> Hooks Class Initialized
DEBUG - 2024-10-14 12:37:58 --> UTF-8 Support Enabled
INFO - 2024-10-14 12:37:58 --> Utf8 Class Initialized
INFO - 2024-10-14 12:37:58 --> URI Class Initialized
INFO - 2024-10-14 12:37:58 --> Router Class Initialized
INFO - 2024-10-14 12:37:58 --> Output Class Initialized
INFO - 2024-10-14 12:37:58 --> Security Class Initialized
DEBUG - 2024-10-14 12:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 12:37:58 --> Input Class Initialized
INFO - 2024-10-14 12:37:58 --> Language Class Initialized
INFO - 2024-10-14 12:37:58 --> Language Class Initialized
INFO - 2024-10-14 12:37:58 --> Config Class Initialized
INFO - 2024-10-14 12:37:58 --> Loader Class Initialized
INFO - 2024-10-14 12:37:58 --> Helper loaded: url_helper
INFO - 2024-10-14 12:37:58 --> Helper loaded: file_helper
INFO - 2024-10-14 12:37:58 --> Helper loaded: form_helper
INFO - 2024-10-14 12:37:58 --> Helper loaded: my_helper
INFO - 2024-10-14 12:37:58 --> Database Driver Class Initialized
INFO - 2024-10-14 12:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 12:37:58 --> Controller Class Initialized
DEBUG - 2024-10-14 12:37:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-14 12:38:02 --> Final output sent to browser
DEBUG - 2024-10-14 12:38:02 --> Total execution time: 3.7604
INFO - 2024-10-14 12:38:28 --> Config Class Initialized
INFO - 2024-10-14 12:38:28 --> Hooks Class Initialized
DEBUG - 2024-10-14 12:38:28 --> UTF-8 Support Enabled
INFO - 2024-10-14 12:38:28 --> Utf8 Class Initialized
INFO - 2024-10-14 12:38:28 --> URI Class Initialized
INFO - 2024-10-14 12:38:28 --> Router Class Initialized
INFO - 2024-10-14 12:38:28 --> Output Class Initialized
INFO - 2024-10-14 12:38:28 --> Security Class Initialized
DEBUG - 2024-10-14 12:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 12:38:28 --> Input Class Initialized
INFO - 2024-10-14 12:38:28 --> Language Class Initialized
INFO - 2024-10-14 12:38:28 --> Language Class Initialized
INFO - 2024-10-14 12:38:28 --> Config Class Initialized
INFO - 2024-10-14 12:38:28 --> Loader Class Initialized
INFO - 2024-10-14 12:38:28 --> Helper loaded: url_helper
INFO - 2024-10-14 12:38:28 --> Helper loaded: file_helper
INFO - 2024-10-14 12:38:28 --> Helper loaded: form_helper
INFO - 2024-10-14 12:38:28 --> Helper loaded: my_helper
INFO - 2024-10-14 12:38:28 --> Database Driver Class Initialized
INFO - 2024-10-14 12:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 12:38:28 --> Controller Class Initialized
DEBUG - 2024-10-14 12:38:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-14 12:38:31 --> Final output sent to browser
DEBUG - 2024-10-14 12:38:31 --> Total execution time: 2.9483
INFO - 2024-10-14 12:38:59 --> Config Class Initialized
INFO - 2024-10-14 12:38:59 --> Hooks Class Initialized
DEBUG - 2024-10-14 12:38:59 --> UTF-8 Support Enabled
INFO - 2024-10-14 12:38:59 --> Utf8 Class Initialized
INFO - 2024-10-14 12:38:59 --> URI Class Initialized
INFO - 2024-10-14 12:38:59 --> Router Class Initialized
INFO - 2024-10-14 12:38:59 --> Output Class Initialized
INFO - 2024-10-14 12:38:59 --> Security Class Initialized
DEBUG - 2024-10-14 12:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 12:38:59 --> Input Class Initialized
INFO - 2024-10-14 12:38:59 --> Language Class Initialized
INFO - 2024-10-14 12:38:59 --> Language Class Initialized
INFO - 2024-10-14 12:38:59 --> Config Class Initialized
INFO - 2024-10-14 12:38:59 --> Loader Class Initialized
INFO - 2024-10-14 12:38:59 --> Helper loaded: url_helper
INFO - 2024-10-14 12:38:59 --> Helper loaded: file_helper
INFO - 2024-10-14 12:38:59 --> Helper loaded: form_helper
INFO - 2024-10-14 12:38:59 --> Helper loaded: my_helper
INFO - 2024-10-14 12:38:59 --> Database Driver Class Initialized
INFO - 2024-10-14 12:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 12:38:59 --> Controller Class Initialized
DEBUG - 2024-10-14 12:38:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-14 12:38:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 12:38:59 --> Final output sent to browser
DEBUG - 2024-10-14 12:38:59 --> Total execution time: 0.0337
INFO - 2024-10-14 12:39:05 --> Config Class Initialized
INFO - 2024-10-14 12:39:05 --> Hooks Class Initialized
DEBUG - 2024-10-14 12:39:05 --> UTF-8 Support Enabled
INFO - 2024-10-14 12:39:05 --> Utf8 Class Initialized
INFO - 2024-10-14 12:39:05 --> URI Class Initialized
INFO - 2024-10-14 12:39:05 --> Router Class Initialized
INFO - 2024-10-14 12:39:05 --> Output Class Initialized
INFO - 2024-10-14 12:39:05 --> Security Class Initialized
DEBUG - 2024-10-14 12:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 12:39:05 --> Input Class Initialized
INFO - 2024-10-14 12:39:05 --> Language Class Initialized
INFO - 2024-10-14 12:39:05 --> Language Class Initialized
INFO - 2024-10-14 12:39:05 --> Config Class Initialized
INFO - 2024-10-14 12:39:05 --> Loader Class Initialized
INFO - 2024-10-14 12:39:05 --> Helper loaded: url_helper
INFO - 2024-10-14 12:39:05 --> Helper loaded: file_helper
INFO - 2024-10-14 12:39:05 --> Helper loaded: form_helper
INFO - 2024-10-14 12:39:05 --> Helper loaded: my_helper
INFO - 2024-10-14 12:39:05 --> Database Driver Class Initialized
INFO - 2024-10-14 12:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 12:39:05 --> Controller Class Initialized
DEBUG - 2024-10-14 12:39:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-14 12:39:08 --> Final output sent to browser
DEBUG - 2024-10-14 12:39:08 --> Total execution time: 3.5629
INFO - 2024-10-14 12:44:50 --> Config Class Initialized
INFO - 2024-10-14 12:44:50 --> Hooks Class Initialized
DEBUG - 2024-10-14 12:44:50 --> UTF-8 Support Enabled
INFO - 2024-10-14 12:44:50 --> Utf8 Class Initialized
INFO - 2024-10-14 12:44:50 --> URI Class Initialized
INFO - 2024-10-14 12:44:50 --> Router Class Initialized
INFO - 2024-10-14 12:44:50 --> Output Class Initialized
INFO - 2024-10-14 12:44:50 --> Security Class Initialized
DEBUG - 2024-10-14 12:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 12:44:50 --> Input Class Initialized
INFO - 2024-10-14 12:44:50 --> Language Class Initialized
INFO - 2024-10-14 12:44:50 --> Language Class Initialized
INFO - 2024-10-14 12:44:50 --> Config Class Initialized
INFO - 2024-10-14 12:44:50 --> Loader Class Initialized
INFO - 2024-10-14 12:44:50 --> Helper loaded: url_helper
INFO - 2024-10-14 12:44:50 --> Helper loaded: file_helper
INFO - 2024-10-14 12:44:50 --> Helper loaded: form_helper
INFO - 2024-10-14 12:44:50 --> Helper loaded: my_helper
INFO - 2024-10-14 12:44:50 --> Database Driver Class Initialized
INFO - 2024-10-14 12:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 12:44:50 --> Controller Class Initialized
DEBUG - 2024-10-14 12:44:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-14 12:44:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 12:44:50 --> Final output sent to browser
DEBUG - 2024-10-14 12:44:50 --> Total execution time: 0.0380
INFO - 2024-10-14 12:44:52 --> Config Class Initialized
INFO - 2024-10-14 12:44:52 --> Hooks Class Initialized
DEBUG - 2024-10-14 12:44:52 --> UTF-8 Support Enabled
INFO - 2024-10-14 12:44:52 --> Utf8 Class Initialized
INFO - 2024-10-14 12:44:52 --> URI Class Initialized
INFO - 2024-10-14 12:44:52 --> Router Class Initialized
INFO - 2024-10-14 12:44:52 --> Output Class Initialized
INFO - 2024-10-14 12:44:52 --> Security Class Initialized
DEBUG - 2024-10-14 12:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 12:44:52 --> Input Class Initialized
INFO - 2024-10-14 12:44:52 --> Language Class Initialized
INFO - 2024-10-14 12:44:52 --> Language Class Initialized
INFO - 2024-10-14 12:44:52 --> Config Class Initialized
INFO - 2024-10-14 12:44:52 --> Loader Class Initialized
INFO - 2024-10-14 12:44:52 --> Helper loaded: url_helper
INFO - 2024-10-14 12:44:52 --> Helper loaded: file_helper
INFO - 2024-10-14 12:44:52 --> Helper loaded: form_helper
INFO - 2024-10-14 12:44:52 --> Helper loaded: my_helper
INFO - 2024-10-14 12:44:52 --> Database Driver Class Initialized
INFO - 2024-10-14 12:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 12:44:52 --> Controller Class Initialized
DEBUG - 2024-10-14 12:44:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-14 12:44:55 --> Final output sent to browser
DEBUG - 2024-10-14 12:44:55 --> Total execution time: 3.2061
INFO - 2024-10-14 13:05:09 --> Config Class Initialized
INFO - 2024-10-14 13:05:09 --> Hooks Class Initialized
DEBUG - 2024-10-14 13:05:09 --> UTF-8 Support Enabled
INFO - 2024-10-14 13:05:09 --> Utf8 Class Initialized
INFO - 2024-10-14 13:05:09 --> URI Class Initialized
INFO - 2024-10-14 13:05:09 --> Router Class Initialized
INFO - 2024-10-14 13:05:09 --> Output Class Initialized
INFO - 2024-10-14 13:05:09 --> Security Class Initialized
DEBUG - 2024-10-14 13:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 13:05:09 --> Input Class Initialized
INFO - 2024-10-14 13:05:09 --> Language Class Initialized
INFO - 2024-10-14 13:05:09 --> Language Class Initialized
INFO - 2024-10-14 13:05:09 --> Config Class Initialized
INFO - 2024-10-14 13:05:09 --> Loader Class Initialized
INFO - 2024-10-14 13:05:09 --> Helper loaded: url_helper
INFO - 2024-10-14 13:05:09 --> Helper loaded: file_helper
INFO - 2024-10-14 13:05:09 --> Helper loaded: form_helper
INFO - 2024-10-14 13:05:09 --> Helper loaded: my_helper
INFO - 2024-10-14 13:05:09 --> Database Driver Class Initialized
INFO - 2024-10-14 13:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 13:05:09 --> Controller Class Initialized
INFO - 2024-10-14 13:05:09 --> Helper loaded: cookie_helper
INFO - 2024-10-14 13:05:09 --> Final output sent to browser
DEBUG - 2024-10-14 13:05:09 --> Total execution time: 0.0525
INFO - 2024-10-14 13:05:10 --> Config Class Initialized
INFO - 2024-10-14 13:05:10 --> Hooks Class Initialized
DEBUG - 2024-10-14 13:05:10 --> UTF-8 Support Enabled
INFO - 2024-10-14 13:05:10 --> Utf8 Class Initialized
INFO - 2024-10-14 13:05:10 --> URI Class Initialized
INFO - 2024-10-14 13:05:10 --> Router Class Initialized
INFO - 2024-10-14 13:05:10 --> Output Class Initialized
INFO - 2024-10-14 13:05:10 --> Security Class Initialized
DEBUG - 2024-10-14 13:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 13:05:10 --> Input Class Initialized
INFO - 2024-10-14 13:05:10 --> Language Class Initialized
INFO - 2024-10-14 13:05:10 --> Language Class Initialized
INFO - 2024-10-14 13:05:10 --> Config Class Initialized
INFO - 2024-10-14 13:05:10 --> Loader Class Initialized
INFO - 2024-10-14 13:05:10 --> Helper loaded: url_helper
INFO - 2024-10-14 13:05:10 --> Helper loaded: file_helper
INFO - 2024-10-14 13:05:10 --> Helper loaded: form_helper
INFO - 2024-10-14 13:05:10 --> Helper loaded: my_helper
INFO - 2024-10-14 13:05:10 --> Database Driver Class Initialized
INFO - 2024-10-14 13:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 13:05:10 --> Controller Class Initialized
INFO - 2024-10-14 13:05:10 --> Helper loaded: cookie_helper
INFO - 2024-10-14 13:05:10 --> Config Class Initialized
INFO - 2024-10-14 13:05:10 --> Hooks Class Initialized
DEBUG - 2024-10-14 13:05:10 --> UTF-8 Support Enabled
INFO - 2024-10-14 13:05:10 --> Utf8 Class Initialized
INFO - 2024-10-14 13:05:10 --> URI Class Initialized
INFO - 2024-10-14 13:05:10 --> Router Class Initialized
INFO - 2024-10-14 13:05:10 --> Output Class Initialized
INFO - 2024-10-14 13:05:10 --> Security Class Initialized
DEBUG - 2024-10-14 13:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 13:05:10 --> Input Class Initialized
INFO - 2024-10-14 13:05:10 --> Language Class Initialized
INFO - 2024-10-14 13:05:10 --> Language Class Initialized
INFO - 2024-10-14 13:05:10 --> Config Class Initialized
INFO - 2024-10-14 13:05:10 --> Loader Class Initialized
INFO - 2024-10-14 13:05:10 --> Helper loaded: url_helper
INFO - 2024-10-14 13:05:10 --> Helper loaded: file_helper
INFO - 2024-10-14 13:05:10 --> Helper loaded: form_helper
INFO - 2024-10-14 13:05:10 --> Helper loaded: my_helper
INFO - 2024-10-14 13:05:10 --> Database Driver Class Initialized
INFO - 2024-10-14 13:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 13:05:10 --> Controller Class Initialized
DEBUG - 2024-10-14 13:05:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-14 13:05:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 13:05:10 --> Final output sent to browser
DEBUG - 2024-10-14 13:05:10 --> Total execution time: 0.0592
INFO - 2024-10-14 13:06:07 --> Config Class Initialized
INFO - 2024-10-14 13:06:07 --> Hooks Class Initialized
DEBUG - 2024-10-14 13:06:07 --> UTF-8 Support Enabled
INFO - 2024-10-14 13:06:07 --> Utf8 Class Initialized
INFO - 2024-10-14 13:06:07 --> URI Class Initialized
INFO - 2024-10-14 13:06:07 --> Router Class Initialized
INFO - 2024-10-14 13:06:07 --> Output Class Initialized
INFO - 2024-10-14 13:06:07 --> Security Class Initialized
DEBUG - 2024-10-14 13:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 13:06:07 --> Input Class Initialized
INFO - 2024-10-14 13:06:07 --> Language Class Initialized
INFO - 2024-10-14 13:06:07 --> Language Class Initialized
INFO - 2024-10-14 13:06:07 --> Config Class Initialized
INFO - 2024-10-14 13:06:07 --> Loader Class Initialized
INFO - 2024-10-14 13:06:07 --> Helper loaded: url_helper
INFO - 2024-10-14 13:06:07 --> Helper loaded: file_helper
INFO - 2024-10-14 13:06:07 --> Helper loaded: form_helper
INFO - 2024-10-14 13:06:07 --> Helper loaded: my_helper
INFO - 2024-10-14 13:06:07 --> Database Driver Class Initialized
INFO - 2024-10-14 13:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 13:06:07 --> Controller Class Initialized
INFO - 2024-10-14 13:06:07 --> Helper loaded: cookie_helper
INFO - 2024-10-14 13:06:07 --> Final output sent to browser
DEBUG - 2024-10-14 13:06:07 --> Total execution time: 0.0343
INFO - 2024-10-14 13:06:07 --> Config Class Initialized
INFO - 2024-10-14 13:06:07 --> Hooks Class Initialized
DEBUG - 2024-10-14 13:06:07 --> UTF-8 Support Enabled
INFO - 2024-10-14 13:06:07 --> Utf8 Class Initialized
INFO - 2024-10-14 13:06:07 --> URI Class Initialized
INFO - 2024-10-14 13:06:07 --> Router Class Initialized
INFO - 2024-10-14 13:06:07 --> Output Class Initialized
INFO - 2024-10-14 13:06:07 --> Security Class Initialized
DEBUG - 2024-10-14 13:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 13:06:07 --> Input Class Initialized
INFO - 2024-10-14 13:06:07 --> Language Class Initialized
INFO - 2024-10-14 13:06:07 --> Language Class Initialized
INFO - 2024-10-14 13:06:07 --> Config Class Initialized
INFO - 2024-10-14 13:06:07 --> Loader Class Initialized
INFO - 2024-10-14 13:06:07 --> Helper loaded: url_helper
INFO - 2024-10-14 13:06:07 --> Helper loaded: file_helper
INFO - 2024-10-14 13:06:07 --> Helper loaded: form_helper
INFO - 2024-10-14 13:06:07 --> Helper loaded: my_helper
INFO - 2024-10-14 13:06:07 --> Database Driver Class Initialized
INFO - 2024-10-14 13:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 13:06:07 --> Controller Class Initialized
INFO - 2024-10-14 13:06:07 --> Helper loaded: cookie_helper
INFO - 2024-10-14 13:06:07 --> Config Class Initialized
INFO - 2024-10-14 13:06:07 --> Hooks Class Initialized
DEBUG - 2024-10-14 13:06:07 --> UTF-8 Support Enabled
INFO - 2024-10-14 13:06:07 --> Utf8 Class Initialized
INFO - 2024-10-14 13:06:07 --> URI Class Initialized
INFO - 2024-10-14 13:06:07 --> Router Class Initialized
INFO - 2024-10-14 13:06:07 --> Output Class Initialized
INFO - 2024-10-14 13:06:07 --> Security Class Initialized
DEBUG - 2024-10-14 13:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 13:06:07 --> Input Class Initialized
INFO - 2024-10-14 13:06:07 --> Language Class Initialized
INFO - 2024-10-14 13:06:07 --> Language Class Initialized
INFO - 2024-10-14 13:06:07 --> Config Class Initialized
INFO - 2024-10-14 13:06:07 --> Loader Class Initialized
INFO - 2024-10-14 13:06:07 --> Helper loaded: url_helper
INFO - 2024-10-14 13:06:07 --> Helper loaded: file_helper
INFO - 2024-10-14 13:06:07 --> Helper loaded: form_helper
INFO - 2024-10-14 13:06:07 --> Helper loaded: my_helper
INFO - 2024-10-14 13:06:07 --> Database Driver Class Initialized
INFO - 2024-10-14 13:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 13:06:07 --> Controller Class Initialized
DEBUG - 2024-10-14 13:06:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-14 13:06:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 13:06:07 --> Final output sent to browser
DEBUG - 2024-10-14 13:06:07 --> Total execution time: 0.0377
INFO - 2024-10-14 13:06:16 --> Config Class Initialized
INFO - 2024-10-14 13:06:16 --> Hooks Class Initialized
DEBUG - 2024-10-14 13:06:16 --> UTF-8 Support Enabled
INFO - 2024-10-14 13:06:16 --> Utf8 Class Initialized
INFO - 2024-10-14 13:06:16 --> URI Class Initialized
INFO - 2024-10-14 13:06:16 --> Router Class Initialized
INFO - 2024-10-14 13:06:16 --> Output Class Initialized
INFO - 2024-10-14 13:06:16 --> Security Class Initialized
DEBUG - 2024-10-14 13:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 13:06:16 --> Input Class Initialized
INFO - 2024-10-14 13:06:16 --> Language Class Initialized
INFO - 2024-10-14 13:06:16 --> Language Class Initialized
INFO - 2024-10-14 13:06:16 --> Config Class Initialized
INFO - 2024-10-14 13:06:16 --> Loader Class Initialized
INFO - 2024-10-14 13:06:16 --> Helper loaded: url_helper
INFO - 2024-10-14 13:06:16 --> Helper loaded: file_helper
INFO - 2024-10-14 13:06:16 --> Helper loaded: form_helper
INFO - 2024-10-14 13:06:16 --> Helper loaded: my_helper
INFO - 2024-10-14 13:06:16 --> Database Driver Class Initialized
INFO - 2024-10-14 13:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 13:06:16 --> Controller Class Initialized
ERROR - 2024-10-14 13:06:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1797
ERROR - 2024-10-14 13:06:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1804
ERROR - 2024-10-14 13:06:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-10-14 13:06:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-10-14 13:06:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-10-14 13:06:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 86
ERROR - 2024-10-14 13:06:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-10-14 13:06:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-10-14 13:06:16 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-10-14 13:06:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-10-14 13:06:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-10-14 13:06:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
ERROR - 2024-10-14 13:06:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
ERROR - 2024-10-14 13:06:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
INFO - 2024-10-14 13:06:20 --> Final output sent to browser
DEBUG - 2024-10-14 13:06:20 --> Total execution time: 3.9000
INFO - 2024-10-14 13:07:39 --> Config Class Initialized
INFO - 2024-10-14 13:07:39 --> Hooks Class Initialized
DEBUG - 2024-10-14 13:07:39 --> UTF-8 Support Enabled
INFO - 2024-10-14 13:07:39 --> Utf8 Class Initialized
INFO - 2024-10-14 13:07:39 --> URI Class Initialized
INFO - 2024-10-14 13:07:39 --> Router Class Initialized
INFO - 2024-10-14 13:07:39 --> Output Class Initialized
INFO - 2024-10-14 13:07:39 --> Security Class Initialized
DEBUG - 2024-10-14 13:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 13:07:39 --> Input Class Initialized
INFO - 2024-10-14 13:07:39 --> Language Class Initialized
INFO - 2024-10-14 13:07:39 --> Language Class Initialized
INFO - 2024-10-14 13:07:39 --> Config Class Initialized
INFO - 2024-10-14 13:07:39 --> Loader Class Initialized
INFO - 2024-10-14 13:07:39 --> Helper loaded: url_helper
INFO - 2024-10-14 13:07:39 --> Helper loaded: file_helper
INFO - 2024-10-14 13:07:39 --> Helper loaded: form_helper
INFO - 2024-10-14 13:07:39 --> Helper loaded: my_helper
INFO - 2024-10-14 13:07:39 --> Database Driver Class Initialized
INFO - 2024-10-14 13:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 13:07:39 --> Controller Class Initialized
DEBUG - 2024-10-14 13:07:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-14 13:07:42 --> Final output sent to browser
DEBUG - 2024-10-14 13:07:42 --> Total execution time: 3.1029
INFO - 2024-10-14 14:34:00 --> Config Class Initialized
INFO - 2024-10-14 14:34:00 --> Hooks Class Initialized
DEBUG - 2024-10-14 14:34:00 --> UTF-8 Support Enabled
INFO - 2024-10-14 14:34:00 --> Utf8 Class Initialized
INFO - 2024-10-14 14:34:00 --> URI Class Initialized
INFO - 2024-10-14 14:34:00 --> Router Class Initialized
INFO - 2024-10-14 14:34:00 --> Output Class Initialized
INFO - 2024-10-14 14:34:00 --> Security Class Initialized
DEBUG - 2024-10-14 14:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 14:34:00 --> Input Class Initialized
INFO - 2024-10-14 14:34:00 --> Language Class Initialized
INFO - 2024-10-14 14:34:00 --> Language Class Initialized
INFO - 2024-10-14 14:34:00 --> Config Class Initialized
INFO - 2024-10-14 14:34:00 --> Loader Class Initialized
INFO - 2024-10-14 14:34:00 --> Helper loaded: url_helper
INFO - 2024-10-14 14:34:00 --> Helper loaded: file_helper
INFO - 2024-10-14 14:34:00 --> Helper loaded: form_helper
INFO - 2024-10-14 14:34:00 --> Helper loaded: my_helper
INFO - 2024-10-14 14:34:00 --> Database Driver Class Initialized
INFO - 2024-10-14 14:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 14:34:00 --> Controller Class Initialized
INFO - 2024-10-14 14:34:00 --> Helper loaded: cookie_helper
INFO - 2024-10-14 14:34:00 --> Final output sent to browser
DEBUG - 2024-10-14 14:34:00 --> Total execution time: 0.0633
INFO - 2024-10-14 14:34:01 --> Config Class Initialized
INFO - 2024-10-14 14:34:01 --> Hooks Class Initialized
DEBUG - 2024-10-14 14:34:01 --> UTF-8 Support Enabled
INFO - 2024-10-14 14:34:01 --> Utf8 Class Initialized
INFO - 2024-10-14 14:34:01 --> URI Class Initialized
INFO - 2024-10-14 14:34:01 --> Router Class Initialized
INFO - 2024-10-14 14:34:01 --> Output Class Initialized
INFO - 2024-10-14 14:34:01 --> Security Class Initialized
DEBUG - 2024-10-14 14:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 14:34:01 --> Input Class Initialized
INFO - 2024-10-14 14:34:01 --> Language Class Initialized
INFO - 2024-10-14 14:34:01 --> Language Class Initialized
INFO - 2024-10-14 14:34:01 --> Config Class Initialized
INFO - 2024-10-14 14:34:01 --> Loader Class Initialized
INFO - 2024-10-14 14:34:01 --> Helper loaded: url_helper
INFO - 2024-10-14 14:34:01 --> Helper loaded: file_helper
INFO - 2024-10-14 14:34:01 --> Helper loaded: form_helper
INFO - 2024-10-14 14:34:01 --> Helper loaded: my_helper
INFO - 2024-10-14 14:34:01 --> Database Driver Class Initialized
INFO - 2024-10-14 14:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 14:34:01 --> Controller Class Initialized
INFO - 2024-10-14 14:34:01 --> Helper loaded: cookie_helper
INFO - 2024-10-14 14:34:01 --> Config Class Initialized
INFO - 2024-10-14 14:34:01 --> Hooks Class Initialized
DEBUG - 2024-10-14 14:34:01 --> UTF-8 Support Enabled
INFO - 2024-10-14 14:34:01 --> Utf8 Class Initialized
INFO - 2024-10-14 14:34:01 --> URI Class Initialized
INFO - 2024-10-14 14:34:01 --> Router Class Initialized
INFO - 2024-10-14 14:34:01 --> Output Class Initialized
INFO - 2024-10-14 14:34:01 --> Security Class Initialized
DEBUG - 2024-10-14 14:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 14:34:01 --> Input Class Initialized
INFO - 2024-10-14 14:34:01 --> Language Class Initialized
INFO - 2024-10-14 14:34:01 --> Language Class Initialized
INFO - 2024-10-14 14:34:01 --> Config Class Initialized
INFO - 2024-10-14 14:34:01 --> Loader Class Initialized
INFO - 2024-10-14 14:34:01 --> Helper loaded: url_helper
INFO - 2024-10-14 14:34:01 --> Helper loaded: file_helper
INFO - 2024-10-14 14:34:01 --> Helper loaded: form_helper
INFO - 2024-10-14 14:34:01 --> Helper loaded: my_helper
INFO - 2024-10-14 14:34:01 --> Database Driver Class Initialized
INFO - 2024-10-14 14:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 14:34:01 --> Controller Class Initialized
DEBUG - 2024-10-14 14:34:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-14 14:34:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 14:34:01 --> Final output sent to browser
DEBUG - 2024-10-14 14:34:01 --> Total execution time: 0.0369
INFO - 2024-10-14 14:34:09 --> Config Class Initialized
INFO - 2024-10-14 14:34:09 --> Hooks Class Initialized
DEBUG - 2024-10-14 14:34:09 --> UTF-8 Support Enabled
INFO - 2024-10-14 14:34:09 --> Utf8 Class Initialized
INFO - 2024-10-14 14:34:09 --> URI Class Initialized
INFO - 2024-10-14 14:34:09 --> Router Class Initialized
INFO - 2024-10-14 14:34:09 --> Output Class Initialized
INFO - 2024-10-14 14:34:09 --> Security Class Initialized
DEBUG - 2024-10-14 14:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 14:34:09 --> Input Class Initialized
INFO - 2024-10-14 14:34:09 --> Language Class Initialized
INFO - 2024-10-14 14:34:09 --> Language Class Initialized
INFO - 2024-10-14 14:34:09 --> Config Class Initialized
INFO - 2024-10-14 14:34:09 --> Loader Class Initialized
INFO - 2024-10-14 14:34:09 --> Helper loaded: url_helper
INFO - 2024-10-14 14:34:09 --> Helper loaded: file_helper
INFO - 2024-10-14 14:34:09 --> Helper loaded: form_helper
INFO - 2024-10-14 14:34:09 --> Helper loaded: my_helper
INFO - 2024-10-14 14:34:09 --> Database Driver Class Initialized
INFO - 2024-10-14 14:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 14:34:09 --> Controller Class Initialized
DEBUG - 2024-10-14 14:34:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-14 14:34:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 14:34:09 --> Final output sent to browser
DEBUG - 2024-10-14 14:34:09 --> Total execution time: 0.0461
INFO - 2024-10-14 14:34:12 --> Config Class Initialized
INFO - 2024-10-14 14:34:12 --> Hooks Class Initialized
DEBUG - 2024-10-14 14:34:12 --> UTF-8 Support Enabled
INFO - 2024-10-14 14:34:12 --> Utf8 Class Initialized
INFO - 2024-10-14 14:34:12 --> URI Class Initialized
INFO - 2024-10-14 14:34:12 --> Router Class Initialized
INFO - 2024-10-14 14:34:12 --> Output Class Initialized
INFO - 2024-10-14 14:34:12 --> Security Class Initialized
DEBUG - 2024-10-14 14:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 14:34:12 --> Input Class Initialized
INFO - 2024-10-14 14:34:12 --> Language Class Initialized
INFO - 2024-10-14 14:34:12 --> Language Class Initialized
INFO - 2024-10-14 14:34:12 --> Config Class Initialized
INFO - 2024-10-14 14:34:12 --> Loader Class Initialized
INFO - 2024-10-14 14:34:12 --> Helper loaded: url_helper
INFO - 2024-10-14 14:34:12 --> Helper loaded: file_helper
INFO - 2024-10-14 14:34:12 --> Helper loaded: form_helper
INFO - 2024-10-14 14:34:12 --> Helper loaded: my_helper
INFO - 2024-10-14 14:34:12 --> Database Driver Class Initialized
INFO - 2024-10-14 14:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 14:34:12 --> Controller Class Initialized
DEBUG - 2024-10-14 14:34:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-14 14:34:15 --> Final output sent to browser
DEBUG - 2024-10-14 14:34:15 --> Total execution time: 3.2785
INFO - 2024-10-14 17:10:21 --> Config Class Initialized
INFO - 2024-10-14 17:10:21 --> Hooks Class Initialized
DEBUG - 2024-10-14 17:10:21 --> UTF-8 Support Enabled
INFO - 2024-10-14 17:10:21 --> Utf8 Class Initialized
INFO - 2024-10-14 17:10:21 --> URI Class Initialized
INFO - 2024-10-14 17:10:21 --> Router Class Initialized
INFO - 2024-10-14 17:10:21 --> Output Class Initialized
INFO - 2024-10-14 17:10:21 --> Security Class Initialized
DEBUG - 2024-10-14 17:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 17:10:22 --> Input Class Initialized
INFO - 2024-10-14 17:10:22 --> Language Class Initialized
INFO - 2024-10-14 17:10:22 --> Language Class Initialized
INFO - 2024-10-14 17:10:22 --> Config Class Initialized
INFO - 2024-10-14 17:10:22 --> Loader Class Initialized
INFO - 2024-10-14 17:10:22 --> Helper loaded: url_helper
INFO - 2024-10-14 17:10:22 --> Helper loaded: file_helper
INFO - 2024-10-14 17:10:22 --> Helper loaded: form_helper
INFO - 2024-10-14 17:10:22 --> Helper loaded: my_helper
INFO - 2024-10-14 17:10:22 --> Database Driver Class Initialized
INFO - 2024-10-14 17:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 17:10:22 --> Controller Class Initialized
INFO - 2024-10-14 17:10:22 --> Helper loaded: cookie_helper
INFO - 2024-10-14 17:10:22 --> Final output sent to browser
DEBUG - 2024-10-14 17:10:22 --> Total execution time: 0.0609
INFO - 2024-10-14 17:10:23 --> Config Class Initialized
INFO - 2024-10-14 17:10:23 --> Hooks Class Initialized
DEBUG - 2024-10-14 17:10:23 --> UTF-8 Support Enabled
INFO - 2024-10-14 17:10:23 --> Utf8 Class Initialized
INFO - 2024-10-14 17:10:23 --> URI Class Initialized
INFO - 2024-10-14 17:10:23 --> Router Class Initialized
INFO - 2024-10-14 17:10:23 --> Output Class Initialized
INFO - 2024-10-14 17:10:23 --> Security Class Initialized
DEBUG - 2024-10-14 17:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 17:10:23 --> Input Class Initialized
INFO - 2024-10-14 17:10:23 --> Language Class Initialized
INFO - 2024-10-14 17:10:23 --> Language Class Initialized
INFO - 2024-10-14 17:10:23 --> Config Class Initialized
INFO - 2024-10-14 17:10:23 --> Loader Class Initialized
INFO - 2024-10-14 17:10:23 --> Helper loaded: url_helper
INFO - 2024-10-14 17:10:23 --> Helper loaded: file_helper
INFO - 2024-10-14 17:10:23 --> Helper loaded: form_helper
INFO - 2024-10-14 17:10:23 --> Helper loaded: my_helper
INFO - 2024-10-14 17:10:23 --> Database Driver Class Initialized
INFO - 2024-10-14 17:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 17:10:23 --> Controller Class Initialized
INFO - 2024-10-14 17:10:23 --> Helper loaded: cookie_helper
INFO - 2024-10-14 17:10:23 --> Config Class Initialized
INFO - 2024-10-14 17:10:23 --> Hooks Class Initialized
DEBUG - 2024-10-14 17:10:23 --> UTF-8 Support Enabled
INFO - 2024-10-14 17:10:23 --> Utf8 Class Initialized
INFO - 2024-10-14 17:10:23 --> URI Class Initialized
INFO - 2024-10-14 17:10:23 --> Router Class Initialized
INFO - 2024-10-14 17:10:23 --> Output Class Initialized
INFO - 2024-10-14 17:10:23 --> Security Class Initialized
DEBUG - 2024-10-14 17:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 17:10:23 --> Input Class Initialized
INFO - 2024-10-14 17:10:23 --> Language Class Initialized
INFO - 2024-10-14 17:10:23 --> Language Class Initialized
INFO - 2024-10-14 17:10:23 --> Config Class Initialized
INFO - 2024-10-14 17:10:23 --> Loader Class Initialized
INFO - 2024-10-14 17:10:23 --> Helper loaded: url_helper
INFO - 2024-10-14 17:10:23 --> Helper loaded: file_helper
INFO - 2024-10-14 17:10:23 --> Helper loaded: form_helper
INFO - 2024-10-14 17:10:23 --> Helper loaded: my_helper
INFO - 2024-10-14 17:10:23 --> Database Driver Class Initialized
INFO - 2024-10-14 17:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 17:10:23 --> Controller Class Initialized
DEBUG - 2024-10-14 17:10:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-14 17:10:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 17:10:23 --> Final output sent to browser
DEBUG - 2024-10-14 17:10:23 --> Total execution time: 0.0404
INFO - 2024-10-14 17:10:27 --> Config Class Initialized
INFO - 2024-10-14 17:10:27 --> Hooks Class Initialized
DEBUG - 2024-10-14 17:10:27 --> UTF-8 Support Enabled
INFO - 2024-10-14 17:10:27 --> Utf8 Class Initialized
INFO - 2024-10-14 17:10:27 --> URI Class Initialized
INFO - 2024-10-14 17:10:27 --> Router Class Initialized
INFO - 2024-10-14 17:10:27 --> Output Class Initialized
INFO - 2024-10-14 17:10:27 --> Security Class Initialized
DEBUG - 2024-10-14 17:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 17:10:27 --> Input Class Initialized
INFO - 2024-10-14 17:10:27 --> Language Class Initialized
INFO - 2024-10-14 17:10:27 --> Language Class Initialized
INFO - 2024-10-14 17:10:27 --> Config Class Initialized
INFO - 2024-10-14 17:10:27 --> Loader Class Initialized
INFO - 2024-10-14 17:10:27 --> Helper loaded: url_helper
INFO - 2024-10-14 17:10:27 --> Helper loaded: file_helper
INFO - 2024-10-14 17:10:27 --> Helper loaded: form_helper
INFO - 2024-10-14 17:10:27 --> Helper loaded: my_helper
INFO - 2024-10-14 17:10:27 --> Database Driver Class Initialized
INFO - 2024-10-14 17:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 17:10:27 --> Controller Class Initialized
ERROR - 2024-10-14 17:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-14 17:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-14 17:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-14 17:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-14 17:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-14 17:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-14 17:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-14 17:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-14 17:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-14 17:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-14 17:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-14 17:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-14 17:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-14 17:10:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-14 17:10:30 --> Final output sent to browser
DEBUG - 2024-10-14 17:10:30 --> Total execution time: 2.8690
INFO - 2024-10-14 21:39:16 --> Config Class Initialized
INFO - 2024-10-14 21:39:16 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:39:16 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:39:16 --> Utf8 Class Initialized
INFO - 2024-10-14 21:39:16 --> URI Class Initialized
INFO - 2024-10-14 21:39:16 --> Router Class Initialized
INFO - 2024-10-14 21:39:16 --> Output Class Initialized
INFO - 2024-10-14 21:39:16 --> Security Class Initialized
DEBUG - 2024-10-14 21:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:39:16 --> Input Class Initialized
INFO - 2024-10-14 21:39:16 --> Language Class Initialized
INFO - 2024-10-14 21:39:16 --> Language Class Initialized
INFO - 2024-10-14 21:39:16 --> Config Class Initialized
INFO - 2024-10-14 21:39:16 --> Loader Class Initialized
INFO - 2024-10-14 21:39:16 --> Helper loaded: url_helper
INFO - 2024-10-14 21:39:16 --> Helper loaded: file_helper
INFO - 2024-10-14 21:39:16 --> Helper loaded: form_helper
INFO - 2024-10-14 21:39:16 --> Helper loaded: my_helper
INFO - 2024-10-14 21:39:16 --> Database Driver Class Initialized
INFO - 2024-10-14 21:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:39:16 --> Controller Class Initialized
INFO - 2024-10-14 21:39:16 --> Config Class Initialized
INFO - 2024-10-14 21:39:16 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:39:16 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:39:16 --> Utf8 Class Initialized
INFO - 2024-10-14 21:39:16 --> URI Class Initialized
INFO - 2024-10-14 21:39:16 --> Router Class Initialized
INFO - 2024-10-14 21:39:16 --> Output Class Initialized
INFO - 2024-10-14 21:39:16 --> Security Class Initialized
DEBUG - 2024-10-14 21:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:39:16 --> Input Class Initialized
INFO - 2024-10-14 21:39:16 --> Language Class Initialized
INFO - 2024-10-14 21:39:16 --> Language Class Initialized
INFO - 2024-10-14 21:39:16 --> Config Class Initialized
INFO - 2024-10-14 21:39:16 --> Loader Class Initialized
INFO - 2024-10-14 21:39:16 --> Helper loaded: url_helper
INFO - 2024-10-14 21:39:16 --> Helper loaded: file_helper
INFO - 2024-10-14 21:39:16 --> Helper loaded: form_helper
INFO - 2024-10-14 21:39:16 --> Helper loaded: my_helper
INFO - 2024-10-14 21:39:16 --> Database Driver Class Initialized
INFO - 2024-10-14 21:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:39:16 --> Controller Class Initialized
DEBUG - 2024-10-14 21:39:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-14 21:39:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 21:39:16 --> Final output sent to browser
DEBUG - 2024-10-14 21:39:16 --> Total execution time: 0.0321
INFO - 2024-10-14 21:40:53 --> Config Class Initialized
INFO - 2024-10-14 21:40:53 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:40:53 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:40:53 --> Utf8 Class Initialized
INFO - 2024-10-14 21:40:53 --> URI Class Initialized
INFO - 2024-10-14 21:40:53 --> Router Class Initialized
INFO - 2024-10-14 21:40:53 --> Output Class Initialized
INFO - 2024-10-14 21:40:53 --> Security Class Initialized
DEBUG - 2024-10-14 21:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:40:53 --> Input Class Initialized
INFO - 2024-10-14 21:40:53 --> Language Class Initialized
INFO - 2024-10-14 21:40:53 --> Config Class Initialized
INFO - 2024-10-14 21:40:53 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:40:53 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:40:53 --> Utf8 Class Initialized
INFO - 2024-10-14 21:40:53 --> URI Class Initialized
INFO - 2024-10-14 21:40:53 --> Router Class Initialized
INFO - 2024-10-14 21:40:53 --> Output Class Initialized
INFO - 2024-10-14 21:40:53 --> Security Class Initialized
DEBUG - 2024-10-14 21:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:40:53 --> Input Class Initialized
INFO - 2024-10-14 21:40:53 --> Language Class Initialized
INFO - 2024-10-14 21:40:53 --> Language Class Initialized
INFO - 2024-10-14 21:40:53 --> Config Class Initialized
INFO - 2024-10-14 21:40:53 --> Loader Class Initialized
INFO - 2024-10-14 21:40:53 --> Language Class Initialized
INFO - 2024-10-14 21:40:53 --> Config Class Initialized
INFO - 2024-10-14 21:40:53 --> Loader Class Initialized
INFO - 2024-10-14 21:40:53 --> Helper loaded: url_helper
INFO - 2024-10-14 21:40:53 --> Helper loaded: url_helper
INFO - 2024-10-14 21:40:53 --> Helper loaded: file_helper
INFO - 2024-10-14 21:40:53 --> Helper loaded: file_helper
INFO - 2024-10-14 21:40:53 --> Helper loaded: form_helper
INFO - 2024-10-14 21:40:53 --> Helper loaded: form_helper
INFO - 2024-10-14 21:40:53 --> Helper loaded: my_helper
INFO - 2024-10-14 21:40:53 --> Helper loaded: my_helper
INFO - 2024-10-14 21:40:53 --> Database Driver Class Initialized
INFO - 2024-10-14 21:40:53 --> Database Driver Class Initialized
INFO - 2024-10-14 21:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:40:53 --> Controller Class Initialized
INFO - 2024-10-14 21:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:40:53 --> Controller Class Initialized
INFO - 2024-10-14 21:40:53 --> Config Class Initialized
INFO - 2024-10-14 21:40:53 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:40:53 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:40:53 --> Utf8 Class Initialized
INFO - 2024-10-14 21:40:53 --> URI Class Initialized
INFO - 2024-10-14 21:40:53 --> Router Class Initialized
INFO - 2024-10-14 21:40:53 --> Output Class Initialized
INFO - 2024-10-14 21:40:53 --> Security Class Initialized
DEBUG - 2024-10-14 21:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:40:53 --> Input Class Initialized
INFO - 2024-10-14 21:40:53 --> Language Class Initialized
INFO - 2024-10-14 21:40:53 --> Language Class Initialized
INFO - 2024-10-14 21:40:53 --> Config Class Initialized
INFO - 2024-10-14 21:40:53 --> Loader Class Initialized
INFO - 2024-10-14 21:40:53 --> Helper loaded: url_helper
INFO - 2024-10-14 21:40:53 --> Helper loaded: file_helper
INFO - 2024-10-14 21:40:53 --> Helper loaded: form_helper
INFO - 2024-10-14 21:40:53 --> Helper loaded: my_helper
INFO - 2024-10-14 21:40:53 --> Database Driver Class Initialized
INFO - 2024-10-14 21:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:40:53 --> Controller Class Initialized
DEBUG - 2024-10-14 21:40:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-14 21:40:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 21:40:53 --> Final output sent to browser
DEBUG - 2024-10-14 21:40:53 --> Total execution time: 0.0310
INFO - 2024-10-14 21:48:40 --> Config Class Initialized
INFO - 2024-10-14 21:48:40 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:48:40 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:48:40 --> Utf8 Class Initialized
INFO - 2024-10-14 21:48:40 --> URI Class Initialized
INFO - 2024-10-14 21:48:40 --> Router Class Initialized
INFO - 2024-10-14 21:48:40 --> Output Class Initialized
INFO - 2024-10-14 21:48:40 --> Security Class Initialized
DEBUG - 2024-10-14 21:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:48:40 --> Input Class Initialized
INFO - 2024-10-14 21:48:40 --> Language Class Initialized
INFO - 2024-10-14 21:48:40 --> Language Class Initialized
INFO - 2024-10-14 21:48:40 --> Config Class Initialized
INFO - 2024-10-14 21:48:40 --> Loader Class Initialized
INFO - 2024-10-14 21:48:40 --> Helper loaded: url_helper
INFO - 2024-10-14 21:48:40 --> Helper loaded: file_helper
INFO - 2024-10-14 21:48:40 --> Helper loaded: form_helper
INFO - 2024-10-14 21:48:40 --> Helper loaded: my_helper
INFO - 2024-10-14 21:48:40 --> Database Driver Class Initialized
INFO - 2024-10-14 21:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:48:40 --> Controller Class Initialized
INFO - 2024-10-14 21:48:40 --> Helper loaded: cookie_helper
INFO - 2024-10-14 21:48:40 --> Final output sent to browser
DEBUG - 2024-10-14 21:48:40 --> Total execution time: 0.0391
INFO - 2024-10-14 21:48:40 --> Config Class Initialized
INFO - 2024-10-14 21:48:40 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:48:40 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:48:40 --> Utf8 Class Initialized
INFO - 2024-10-14 21:48:40 --> URI Class Initialized
INFO - 2024-10-14 21:48:40 --> Router Class Initialized
INFO - 2024-10-14 21:48:40 --> Output Class Initialized
INFO - 2024-10-14 21:48:40 --> Security Class Initialized
DEBUG - 2024-10-14 21:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:48:40 --> Input Class Initialized
INFO - 2024-10-14 21:48:40 --> Language Class Initialized
INFO - 2024-10-14 21:48:40 --> Language Class Initialized
INFO - 2024-10-14 21:48:40 --> Config Class Initialized
INFO - 2024-10-14 21:48:40 --> Loader Class Initialized
INFO - 2024-10-14 21:48:40 --> Helper loaded: url_helper
INFO - 2024-10-14 21:48:40 --> Helper loaded: file_helper
INFO - 2024-10-14 21:48:40 --> Helper loaded: form_helper
INFO - 2024-10-14 21:48:40 --> Helper loaded: my_helper
INFO - 2024-10-14 21:48:40 --> Database Driver Class Initialized
INFO - 2024-10-14 21:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:48:40 --> Controller Class Initialized
DEBUG - 2024-10-14 21:48:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-14 21:48:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 21:48:40 --> Final output sent to browser
DEBUG - 2024-10-14 21:48:40 --> Total execution time: 0.0422
INFO - 2024-10-14 21:48:44 --> Config Class Initialized
INFO - 2024-10-14 21:48:44 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:48:44 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:48:44 --> Utf8 Class Initialized
INFO - 2024-10-14 21:48:44 --> URI Class Initialized
DEBUG - 2024-10-14 21:48:44 --> No URI present. Default controller set.
INFO - 2024-10-14 21:48:44 --> Router Class Initialized
INFO - 2024-10-14 21:48:44 --> Output Class Initialized
INFO - 2024-10-14 21:48:44 --> Security Class Initialized
DEBUG - 2024-10-14 21:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:48:44 --> Input Class Initialized
INFO - 2024-10-14 21:48:44 --> Language Class Initialized
INFO - 2024-10-14 21:48:44 --> Language Class Initialized
INFO - 2024-10-14 21:48:44 --> Config Class Initialized
INFO - 2024-10-14 21:48:44 --> Loader Class Initialized
INFO - 2024-10-14 21:48:44 --> Helper loaded: url_helper
INFO - 2024-10-14 21:48:44 --> Helper loaded: file_helper
INFO - 2024-10-14 21:48:44 --> Helper loaded: form_helper
INFO - 2024-10-14 21:48:44 --> Helper loaded: my_helper
INFO - 2024-10-14 21:48:44 --> Database Driver Class Initialized
INFO - 2024-10-14 21:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:48:44 --> Controller Class Initialized
DEBUG - 2024-10-14 21:48:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-14 21:48:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 21:48:44 --> Final output sent to browser
DEBUG - 2024-10-14 21:48:44 --> Total execution time: 0.0373
INFO - 2024-10-14 21:48:50 --> Config Class Initialized
INFO - 2024-10-14 21:48:50 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:48:50 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:48:50 --> Utf8 Class Initialized
INFO - 2024-10-14 21:48:50 --> URI Class Initialized
INFO - 2024-10-14 21:48:50 --> Router Class Initialized
INFO - 2024-10-14 21:48:50 --> Output Class Initialized
INFO - 2024-10-14 21:48:50 --> Security Class Initialized
DEBUG - 2024-10-14 21:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:48:50 --> Input Class Initialized
INFO - 2024-10-14 21:48:50 --> Language Class Initialized
INFO - 2024-10-14 21:48:50 --> Language Class Initialized
INFO - 2024-10-14 21:48:50 --> Config Class Initialized
INFO - 2024-10-14 21:48:50 --> Loader Class Initialized
INFO - 2024-10-14 21:48:50 --> Helper loaded: url_helper
INFO - 2024-10-14 21:48:50 --> Helper loaded: file_helper
INFO - 2024-10-14 21:48:50 --> Helper loaded: form_helper
INFO - 2024-10-14 21:48:50 --> Helper loaded: my_helper
INFO - 2024-10-14 21:48:50 --> Database Driver Class Initialized
INFO - 2024-10-14 21:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:48:50 --> Controller Class Initialized
DEBUG - 2024-10-14 21:48:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-14 21:48:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 21:48:50 --> Final output sent to browser
DEBUG - 2024-10-14 21:48:50 --> Total execution time: 0.0456
INFO - 2024-10-14 21:48:53 --> Config Class Initialized
INFO - 2024-10-14 21:48:53 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:48:53 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:48:53 --> Utf8 Class Initialized
INFO - 2024-10-14 21:48:53 --> URI Class Initialized
INFO - 2024-10-14 21:48:53 --> Router Class Initialized
INFO - 2024-10-14 21:48:53 --> Output Class Initialized
INFO - 2024-10-14 21:48:53 --> Security Class Initialized
DEBUG - 2024-10-14 21:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:48:53 --> Input Class Initialized
INFO - 2024-10-14 21:48:53 --> Language Class Initialized
INFO - 2024-10-14 21:48:53 --> Language Class Initialized
INFO - 2024-10-14 21:48:53 --> Config Class Initialized
INFO - 2024-10-14 21:48:53 --> Loader Class Initialized
INFO - 2024-10-14 21:48:53 --> Helper loaded: url_helper
INFO - 2024-10-14 21:48:53 --> Helper loaded: file_helper
INFO - 2024-10-14 21:48:53 --> Helper loaded: form_helper
INFO - 2024-10-14 21:48:53 --> Helper loaded: my_helper
INFO - 2024-10-14 21:48:53 --> Database Driver Class Initialized
INFO - 2024-10-14 21:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:48:53 --> Controller Class Initialized
DEBUG - 2024-10-14 21:48:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-14 21:48:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 21:48:53 --> Final output sent to browser
DEBUG - 2024-10-14 21:48:53 --> Total execution time: 0.0371
INFO - 2024-10-14 21:48:54 --> Config Class Initialized
INFO - 2024-10-14 21:48:54 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:48:54 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:48:54 --> Utf8 Class Initialized
INFO - 2024-10-14 21:48:54 --> URI Class Initialized
INFO - 2024-10-14 21:48:54 --> Router Class Initialized
INFO - 2024-10-14 21:48:54 --> Output Class Initialized
INFO - 2024-10-14 21:48:54 --> Security Class Initialized
DEBUG - 2024-10-14 21:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:48:54 --> Input Class Initialized
INFO - 2024-10-14 21:48:54 --> Language Class Initialized
INFO - 2024-10-14 21:48:54 --> Language Class Initialized
INFO - 2024-10-14 21:48:54 --> Config Class Initialized
INFO - 2024-10-14 21:48:54 --> Loader Class Initialized
INFO - 2024-10-14 21:48:54 --> Helper loaded: url_helper
INFO - 2024-10-14 21:48:54 --> Helper loaded: file_helper
INFO - 2024-10-14 21:48:54 --> Helper loaded: form_helper
INFO - 2024-10-14 21:48:54 --> Helper loaded: my_helper
INFO - 2024-10-14 21:48:54 --> Database Driver Class Initialized
INFO - 2024-10-14 21:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:48:54 --> Controller Class Initialized
DEBUG - 2024-10-14 21:48:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-10-14 21:48:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 21:48:54 --> Final output sent to browser
DEBUG - 2024-10-14 21:48:54 --> Total execution time: 0.0380
INFO - 2024-10-14 21:49:01 --> Config Class Initialized
INFO - 2024-10-14 21:49:01 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:49:01 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:49:01 --> Utf8 Class Initialized
INFO - 2024-10-14 21:49:01 --> URI Class Initialized
INFO - 2024-10-14 21:49:01 --> Router Class Initialized
INFO - 2024-10-14 21:49:01 --> Output Class Initialized
INFO - 2024-10-14 21:49:01 --> Security Class Initialized
DEBUG - 2024-10-14 21:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:49:01 --> Input Class Initialized
INFO - 2024-10-14 21:49:01 --> Language Class Initialized
INFO - 2024-10-14 21:49:01 --> Language Class Initialized
INFO - 2024-10-14 21:49:01 --> Config Class Initialized
INFO - 2024-10-14 21:49:01 --> Loader Class Initialized
INFO - 2024-10-14 21:49:01 --> Helper loaded: url_helper
INFO - 2024-10-14 21:49:01 --> Helper loaded: file_helper
INFO - 2024-10-14 21:49:01 --> Helper loaded: form_helper
INFO - 2024-10-14 21:49:01 --> Helper loaded: my_helper
INFO - 2024-10-14 21:49:01 --> Database Driver Class Initialized
INFO - 2024-10-14 21:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:49:01 --> Controller Class Initialized
INFO - 2024-10-14 21:49:01 --> Config Class Initialized
INFO - 2024-10-14 21:49:01 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:49:01 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:49:01 --> Utf8 Class Initialized
INFO - 2024-10-14 21:49:01 --> URI Class Initialized
INFO - 2024-10-14 21:49:01 --> Router Class Initialized
INFO - 2024-10-14 21:49:01 --> Output Class Initialized
INFO - 2024-10-14 21:49:01 --> Security Class Initialized
DEBUG - 2024-10-14 21:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:49:01 --> Input Class Initialized
INFO - 2024-10-14 21:49:01 --> Language Class Initialized
INFO - 2024-10-14 21:49:01 --> Language Class Initialized
INFO - 2024-10-14 21:49:01 --> Config Class Initialized
INFO - 2024-10-14 21:49:01 --> Loader Class Initialized
INFO - 2024-10-14 21:49:01 --> Helper loaded: url_helper
INFO - 2024-10-14 21:49:01 --> Helper loaded: file_helper
INFO - 2024-10-14 21:49:01 --> Helper loaded: form_helper
INFO - 2024-10-14 21:49:01 --> Helper loaded: my_helper
INFO - 2024-10-14 21:49:01 --> Database Driver Class Initialized
INFO - 2024-10-14 21:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:49:01 --> Controller Class Initialized
DEBUG - 2024-10-14 21:49:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-14 21:49:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 21:49:01 --> Final output sent to browser
DEBUG - 2024-10-14 21:49:01 --> Total execution time: 0.0351
INFO - 2024-10-14 21:49:02 --> Config Class Initialized
INFO - 2024-10-14 21:49:02 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:49:02 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:49:02 --> Utf8 Class Initialized
INFO - 2024-10-14 21:49:02 --> URI Class Initialized
INFO - 2024-10-14 21:49:02 --> Router Class Initialized
INFO - 2024-10-14 21:49:02 --> Output Class Initialized
INFO - 2024-10-14 21:49:02 --> Security Class Initialized
DEBUG - 2024-10-14 21:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:49:02 --> Input Class Initialized
INFO - 2024-10-14 21:49:02 --> Language Class Initialized
INFO - 2024-10-14 21:49:02 --> Language Class Initialized
INFO - 2024-10-14 21:49:02 --> Config Class Initialized
INFO - 2024-10-14 21:49:02 --> Loader Class Initialized
INFO - 2024-10-14 21:49:02 --> Helper loaded: url_helper
INFO - 2024-10-14 21:49:02 --> Helper loaded: file_helper
INFO - 2024-10-14 21:49:02 --> Helper loaded: form_helper
INFO - 2024-10-14 21:49:02 --> Helper loaded: my_helper
INFO - 2024-10-14 21:49:02 --> Database Driver Class Initialized
INFO - 2024-10-14 21:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:49:02 --> Controller Class Initialized
INFO - 2024-10-14 21:49:02 --> Final output sent to browser
DEBUG - 2024-10-14 21:49:02 --> Total execution time: 0.0527
INFO - 2024-10-14 21:50:06 --> Config Class Initialized
INFO - 2024-10-14 21:50:06 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:50:06 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:50:06 --> Utf8 Class Initialized
INFO - 2024-10-14 21:50:06 --> URI Class Initialized
INFO - 2024-10-14 21:50:06 --> Router Class Initialized
INFO - 2024-10-14 21:50:06 --> Output Class Initialized
INFO - 2024-10-14 21:50:06 --> Security Class Initialized
DEBUG - 2024-10-14 21:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:50:06 --> Input Class Initialized
INFO - 2024-10-14 21:50:06 --> Language Class Initialized
INFO - 2024-10-14 21:50:06 --> Language Class Initialized
INFO - 2024-10-14 21:50:06 --> Config Class Initialized
INFO - 2024-10-14 21:50:06 --> Loader Class Initialized
INFO - 2024-10-14 21:50:06 --> Helper loaded: url_helper
INFO - 2024-10-14 21:50:06 --> Helper loaded: file_helper
INFO - 2024-10-14 21:50:06 --> Helper loaded: form_helper
INFO - 2024-10-14 21:50:06 --> Helper loaded: my_helper
INFO - 2024-10-14 21:50:06 --> Database Driver Class Initialized
INFO - 2024-10-14 21:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:50:06 --> Controller Class Initialized
DEBUG - 2024-10-14 21:50:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-14 21:50:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 21:50:06 --> Final output sent to browser
DEBUG - 2024-10-14 21:50:06 --> Total execution time: 0.0308
INFO - 2024-10-14 21:50:09 --> Config Class Initialized
INFO - 2024-10-14 21:50:09 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:50:09 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:50:09 --> Utf8 Class Initialized
INFO - 2024-10-14 21:50:09 --> URI Class Initialized
INFO - 2024-10-14 21:50:09 --> Router Class Initialized
INFO - 2024-10-14 21:50:09 --> Output Class Initialized
INFO - 2024-10-14 21:50:09 --> Security Class Initialized
DEBUG - 2024-10-14 21:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:50:09 --> Input Class Initialized
INFO - 2024-10-14 21:50:09 --> Language Class Initialized
INFO - 2024-10-14 21:50:09 --> Language Class Initialized
INFO - 2024-10-14 21:50:09 --> Config Class Initialized
INFO - 2024-10-14 21:50:09 --> Loader Class Initialized
INFO - 2024-10-14 21:50:09 --> Helper loaded: url_helper
INFO - 2024-10-14 21:50:09 --> Helper loaded: file_helper
INFO - 2024-10-14 21:50:09 --> Helper loaded: form_helper
INFO - 2024-10-14 21:50:09 --> Helper loaded: my_helper
INFO - 2024-10-14 21:50:09 --> Database Driver Class Initialized
INFO - 2024-10-14 21:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:50:09 --> Controller Class Initialized
DEBUG - 2024-10-14 21:50:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-14 21:50:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 21:50:09 --> Final output sent to browser
DEBUG - 2024-10-14 21:50:09 --> Total execution time: 0.0461
INFO - 2024-10-14 21:50:11 --> Config Class Initialized
INFO - 2024-10-14 21:50:11 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:50:11 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:50:11 --> Utf8 Class Initialized
INFO - 2024-10-14 21:50:11 --> URI Class Initialized
INFO - 2024-10-14 21:50:11 --> Router Class Initialized
INFO - 2024-10-14 21:50:11 --> Output Class Initialized
INFO - 2024-10-14 21:50:11 --> Security Class Initialized
DEBUG - 2024-10-14 21:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:50:11 --> Input Class Initialized
INFO - 2024-10-14 21:50:11 --> Language Class Initialized
INFO - 2024-10-14 21:50:11 --> Language Class Initialized
INFO - 2024-10-14 21:50:11 --> Config Class Initialized
INFO - 2024-10-14 21:50:11 --> Loader Class Initialized
INFO - 2024-10-14 21:50:11 --> Helper loaded: url_helper
INFO - 2024-10-14 21:50:11 --> Helper loaded: file_helper
INFO - 2024-10-14 21:50:11 --> Helper loaded: form_helper
INFO - 2024-10-14 21:50:11 --> Helper loaded: my_helper
INFO - 2024-10-14 21:50:11 --> Database Driver Class Initialized
INFO - 2024-10-14 21:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:50:11 --> Controller Class Initialized
DEBUG - 2024-10-14 21:50:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-10-14 21:50:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 21:50:11 --> Final output sent to browser
DEBUG - 2024-10-14 21:50:11 --> Total execution time: 0.0873
INFO - 2024-10-14 21:50:15 --> Config Class Initialized
INFO - 2024-10-14 21:50:15 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:50:15 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:50:15 --> Utf8 Class Initialized
INFO - 2024-10-14 21:50:15 --> URI Class Initialized
INFO - 2024-10-14 21:50:15 --> Router Class Initialized
INFO - 2024-10-14 21:50:15 --> Output Class Initialized
INFO - 2024-10-14 21:50:15 --> Security Class Initialized
DEBUG - 2024-10-14 21:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:50:15 --> Input Class Initialized
INFO - 2024-10-14 21:50:15 --> Language Class Initialized
INFO - 2024-10-14 21:50:15 --> Language Class Initialized
INFO - 2024-10-14 21:50:15 --> Config Class Initialized
INFO - 2024-10-14 21:50:15 --> Loader Class Initialized
INFO - 2024-10-14 21:50:15 --> Helper loaded: url_helper
INFO - 2024-10-14 21:50:15 --> Helper loaded: file_helper
INFO - 2024-10-14 21:50:15 --> Helper loaded: form_helper
INFO - 2024-10-14 21:50:15 --> Helper loaded: my_helper
INFO - 2024-10-14 21:50:15 --> Database Driver Class Initialized
INFO - 2024-10-14 21:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:50:15 --> Controller Class Initialized
INFO - 2024-10-14 21:50:15 --> Config Class Initialized
INFO - 2024-10-14 21:50:15 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:50:15 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:50:15 --> Utf8 Class Initialized
INFO - 2024-10-14 21:50:15 --> URI Class Initialized
INFO - 2024-10-14 21:50:15 --> Router Class Initialized
INFO - 2024-10-14 21:50:15 --> Output Class Initialized
INFO - 2024-10-14 21:50:15 --> Security Class Initialized
DEBUG - 2024-10-14 21:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:50:15 --> Input Class Initialized
INFO - 2024-10-14 21:50:15 --> Language Class Initialized
INFO - 2024-10-14 21:50:15 --> Language Class Initialized
INFO - 2024-10-14 21:50:15 --> Config Class Initialized
INFO - 2024-10-14 21:50:15 --> Loader Class Initialized
INFO - 2024-10-14 21:50:15 --> Helper loaded: url_helper
INFO - 2024-10-14 21:50:15 --> Helper loaded: file_helper
INFO - 2024-10-14 21:50:16 --> Helper loaded: form_helper
INFO - 2024-10-14 21:50:16 --> Helper loaded: my_helper
INFO - 2024-10-14 21:50:16 --> Database Driver Class Initialized
INFO - 2024-10-14 21:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:50:16 --> Controller Class Initialized
DEBUG - 2024-10-14 21:50:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-14 21:50:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 21:50:16 --> Final output sent to browser
DEBUG - 2024-10-14 21:50:16 --> Total execution time: 0.0711
INFO - 2024-10-14 21:50:18 --> Config Class Initialized
INFO - 2024-10-14 21:50:18 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:50:18 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:50:18 --> Utf8 Class Initialized
INFO - 2024-10-14 21:50:18 --> URI Class Initialized
INFO - 2024-10-14 21:50:18 --> Router Class Initialized
INFO - 2024-10-14 21:50:18 --> Output Class Initialized
INFO - 2024-10-14 21:50:18 --> Security Class Initialized
DEBUG - 2024-10-14 21:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:50:18 --> Input Class Initialized
INFO - 2024-10-14 21:50:18 --> Language Class Initialized
INFO - 2024-10-14 21:50:18 --> Language Class Initialized
INFO - 2024-10-14 21:50:18 --> Config Class Initialized
INFO - 2024-10-14 21:50:18 --> Loader Class Initialized
INFO - 2024-10-14 21:50:18 --> Helper loaded: url_helper
INFO - 2024-10-14 21:50:18 --> Helper loaded: file_helper
INFO - 2024-10-14 21:50:18 --> Helper loaded: form_helper
INFO - 2024-10-14 21:50:18 --> Helper loaded: my_helper
INFO - 2024-10-14 21:50:18 --> Database Driver Class Initialized
INFO - 2024-10-14 21:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:50:18 --> Controller Class Initialized
INFO - 2024-10-14 21:50:18 --> Final output sent to browser
DEBUG - 2024-10-14 21:50:18 --> Total execution time: 0.0551
INFO - 2024-10-14 21:52:19 --> Config Class Initialized
INFO - 2024-10-14 21:52:19 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:52:19 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:52:19 --> Utf8 Class Initialized
INFO - 2024-10-14 21:52:19 --> URI Class Initialized
INFO - 2024-10-14 21:52:19 --> Router Class Initialized
INFO - 2024-10-14 21:52:19 --> Output Class Initialized
INFO - 2024-10-14 21:52:19 --> Security Class Initialized
DEBUG - 2024-10-14 21:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:52:19 --> Input Class Initialized
INFO - 2024-10-14 21:52:19 --> Language Class Initialized
INFO - 2024-10-14 21:52:19 --> Language Class Initialized
INFO - 2024-10-14 21:52:19 --> Config Class Initialized
INFO - 2024-10-14 21:52:19 --> Loader Class Initialized
INFO - 2024-10-14 21:52:19 --> Helper loaded: url_helper
INFO - 2024-10-14 21:52:19 --> Helper loaded: file_helper
INFO - 2024-10-14 21:52:19 --> Helper loaded: form_helper
INFO - 2024-10-14 21:52:19 --> Helper loaded: my_helper
INFO - 2024-10-14 21:52:19 --> Database Driver Class Initialized
INFO - 2024-10-14 21:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:52:19 --> Controller Class Initialized
DEBUG - 2024-10-14 21:52:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-14 21:52:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 21:52:19 --> Final output sent to browser
DEBUG - 2024-10-14 21:52:19 --> Total execution time: 0.0375
INFO - 2024-10-14 21:52:23 --> Config Class Initialized
INFO - 2024-10-14 21:52:23 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:52:23 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:52:23 --> Utf8 Class Initialized
INFO - 2024-10-14 21:52:23 --> URI Class Initialized
INFO - 2024-10-14 21:52:23 --> Router Class Initialized
INFO - 2024-10-14 21:52:23 --> Output Class Initialized
INFO - 2024-10-14 21:52:23 --> Security Class Initialized
DEBUG - 2024-10-14 21:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:52:23 --> Input Class Initialized
INFO - 2024-10-14 21:52:23 --> Language Class Initialized
INFO - 2024-10-14 21:52:23 --> Language Class Initialized
INFO - 2024-10-14 21:52:23 --> Config Class Initialized
INFO - 2024-10-14 21:52:23 --> Loader Class Initialized
INFO - 2024-10-14 21:52:23 --> Helper loaded: url_helper
INFO - 2024-10-14 21:52:23 --> Helper loaded: file_helper
INFO - 2024-10-14 21:52:23 --> Helper loaded: form_helper
INFO - 2024-10-14 21:52:23 --> Helper loaded: my_helper
INFO - 2024-10-14 21:52:23 --> Database Driver Class Initialized
INFO - 2024-10-14 21:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:52:23 --> Controller Class Initialized
DEBUG - 2024-10-14 21:52:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-14 21:52:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 21:52:23 --> Final output sent to browser
DEBUG - 2024-10-14 21:52:23 --> Total execution time: 0.0338
INFO - 2024-10-14 21:52:24 --> Config Class Initialized
INFO - 2024-10-14 21:52:24 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:52:24 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:52:24 --> Utf8 Class Initialized
INFO - 2024-10-14 21:52:24 --> URI Class Initialized
INFO - 2024-10-14 21:52:24 --> Router Class Initialized
INFO - 2024-10-14 21:52:24 --> Output Class Initialized
INFO - 2024-10-14 21:52:24 --> Security Class Initialized
DEBUG - 2024-10-14 21:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:52:24 --> Input Class Initialized
INFO - 2024-10-14 21:52:24 --> Language Class Initialized
INFO - 2024-10-14 21:52:24 --> Language Class Initialized
INFO - 2024-10-14 21:52:24 --> Config Class Initialized
INFO - 2024-10-14 21:52:24 --> Loader Class Initialized
INFO - 2024-10-14 21:52:24 --> Helper loaded: url_helper
INFO - 2024-10-14 21:52:24 --> Helper loaded: file_helper
INFO - 2024-10-14 21:52:24 --> Helper loaded: form_helper
INFO - 2024-10-14 21:52:24 --> Helper loaded: my_helper
INFO - 2024-10-14 21:52:24 --> Database Driver Class Initialized
INFO - 2024-10-14 21:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:52:24 --> Controller Class Initialized
DEBUG - 2024-10-14 21:52:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-10-14 21:52:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 21:52:24 --> Final output sent to browser
DEBUG - 2024-10-14 21:52:24 --> Total execution time: 0.0430
INFO - 2024-10-14 21:52:30 --> Config Class Initialized
INFO - 2024-10-14 21:52:30 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:52:30 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:52:30 --> Utf8 Class Initialized
INFO - 2024-10-14 21:52:30 --> URI Class Initialized
INFO - 2024-10-14 21:52:30 --> Router Class Initialized
INFO - 2024-10-14 21:52:30 --> Output Class Initialized
INFO - 2024-10-14 21:52:30 --> Security Class Initialized
DEBUG - 2024-10-14 21:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:52:30 --> Input Class Initialized
INFO - 2024-10-14 21:52:30 --> Language Class Initialized
INFO - 2024-10-14 21:52:30 --> Language Class Initialized
INFO - 2024-10-14 21:52:30 --> Config Class Initialized
INFO - 2024-10-14 21:52:30 --> Loader Class Initialized
INFO - 2024-10-14 21:52:30 --> Helper loaded: url_helper
INFO - 2024-10-14 21:52:30 --> Helper loaded: file_helper
INFO - 2024-10-14 21:52:30 --> Helper loaded: form_helper
INFO - 2024-10-14 21:52:30 --> Helper loaded: my_helper
INFO - 2024-10-14 21:52:30 --> Database Driver Class Initialized
INFO - 2024-10-14 21:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:52:30 --> Controller Class Initialized
INFO - 2024-10-14 21:52:30 --> Config Class Initialized
INFO - 2024-10-14 21:52:30 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:52:30 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:52:30 --> Utf8 Class Initialized
INFO - 2024-10-14 21:52:30 --> URI Class Initialized
INFO - 2024-10-14 21:52:30 --> Router Class Initialized
INFO - 2024-10-14 21:52:30 --> Output Class Initialized
INFO - 2024-10-14 21:52:30 --> Security Class Initialized
DEBUG - 2024-10-14 21:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:52:30 --> Input Class Initialized
INFO - 2024-10-14 21:52:30 --> Language Class Initialized
INFO - 2024-10-14 21:52:30 --> Language Class Initialized
INFO - 2024-10-14 21:52:30 --> Config Class Initialized
INFO - 2024-10-14 21:52:30 --> Loader Class Initialized
INFO - 2024-10-14 21:52:30 --> Helper loaded: url_helper
INFO - 2024-10-14 21:52:30 --> Helper loaded: file_helper
INFO - 2024-10-14 21:52:30 --> Helper loaded: form_helper
INFO - 2024-10-14 21:52:30 --> Helper loaded: my_helper
INFO - 2024-10-14 21:52:30 --> Database Driver Class Initialized
INFO - 2024-10-14 21:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:52:30 --> Controller Class Initialized
DEBUG - 2024-10-14 21:52:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-14 21:52:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 21:52:30 --> Final output sent to browser
DEBUG - 2024-10-14 21:52:30 --> Total execution time: 0.0343
INFO - 2024-10-14 21:52:31 --> Config Class Initialized
INFO - 2024-10-14 21:52:31 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:52:31 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:52:31 --> Utf8 Class Initialized
INFO - 2024-10-14 21:52:31 --> URI Class Initialized
INFO - 2024-10-14 21:52:31 --> Router Class Initialized
INFO - 2024-10-14 21:52:31 --> Output Class Initialized
INFO - 2024-10-14 21:52:31 --> Security Class Initialized
DEBUG - 2024-10-14 21:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:52:31 --> Input Class Initialized
INFO - 2024-10-14 21:52:31 --> Language Class Initialized
INFO - 2024-10-14 21:52:31 --> Language Class Initialized
INFO - 2024-10-14 21:52:31 --> Config Class Initialized
INFO - 2024-10-14 21:52:31 --> Loader Class Initialized
INFO - 2024-10-14 21:52:31 --> Helper loaded: url_helper
INFO - 2024-10-14 21:52:31 --> Helper loaded: file_helper
INFO - 2024-10-14 21:52:31 --> Helper loaded: form_helper
INFO - 2024-10-14 21:52:31 --> Helper loaded: my_helper
INFO - 2024-10-14 21:52:31 --> Database Driver Class Initialized
INFO - 2024-10-14 21:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:52:31 --> Controller Class Initialized
INFO - 2024-10-14 21:52:31 --> Final output sent to browser
DEBUG - 2024-10-14 21:52:31 --> Total execution time: 0.0328
INFO - 2024-10-14 21:52:35 --> Config Class Initialized
INFO - 2024-10-14 21:52:35 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:52:35 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:52:35 --> Utf8 Class Initialized
INFO - 2024-10-14 21:52:35 --> URI Class Initialized
INFO - 2024-10-14 21:52:35 --> Router Class Initialized
INFO - 2024-10-14 21:52:35 --> Output Class Initialized
INFO - 2024-10-14 21:52:35 --> Security Class Initialized
DEBUG - 2024-10-14 21:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:52:35 --> Input Class Initialized
INFO - 2024-10-14 21:52:35 --> Language Class Initialized
INFO - 2024-10-14 21:52:35 --> Language Class Initialized
INFO - 2024-10-14 21:52:35 --> Config Class Initialized
INFO - 2024-10-14 21:52:35 --> Loader Class Initialized
INFO - 2024-10-14 21:52:35 --> Helper loaded: url_helper
INFO - 2024-10-14 21:52:35 --> Helper loaded: file_helper
INFO - 2024-10-14 21:52:35 --> Helper loaded: form_helper
INFO - 2024-10-14 21:52:35 --> Helper loaded: my_helper
INFO - 2024-10-14 21:52:35 --> Database Driver Class Initialized
INFO - 2024-10-14 21:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:52:35 --> Controller Class Initialized
DEBUG - 2024-10-14 21:52:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-14 21:52:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 21:52:35 --> Final output sent to browser
DEBUG - 2024-10-14 21:52:35 --> Total execution time: 0.0304
INFO - 2024-10-14 21:53:47 --> Config Class Initialized
INFO - 2024-10-14 21:53:47 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:53:47 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:53:47 --> Utf8 Class Initialized
INFO - 2024-10-14 21:53:47 --> URI Class Initialized
INFO - 2024-10-14 21:53:47 --> Router Class Initialized
INFO - 2024-10-14 21:53:47 --> Output Class Initialized
INFO - 2024-10-14 21:53:47 --> Security Class Initialized
DEBUG - 2024-10-14 21:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:53:47 --> Input Class Initialized
INFO - 2024-10-14 21:53:47 --> Language Class Initialized
INFO - 2024-10-14 21:53:47 --> Language Class Initialized
INFO - 2024-10-14 21:53:47 --> Config Class Initialized
INFO - 2024-10-14 21:53:47 --> Loader Class Initialized
INFO - 2024-10-14 21:53:47 --> Helper loaded: url_helper
INFO - 2024-10-14 21:53:47 --> Helper loaded: file_helper
INFO - 2024-10-14 21:53:47 --> Helper loaded: form_helper
INFO - 2024-10-14 21:53:47 --> Helper loaded: my_helper
INFO - 2024-10-14 21:53:47 --> Database Driver Class Initialized
INFO - 2024-10-14 21:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:53:47 --> Controller Class Initialized
DEBUG - 2024-10-14 21:53:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-14 21:53:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 21:53:47 --> Final output sent to browser
DEBUG - 2024-10-14 21:53:47 --> Total execution time: 0.0352
INFO - 2024-10-14 21:53:51 --> Config Class Initialized
INFO - 2024-10-14 21:53:51 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:53:51 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:53:51 --> Utf8 Class Initialized
INFO - 2024-10-14 21:53:51 --> URI Class Initialized
INFO - 2024-10-14 21:53:51 --> Router Class Initialized
INFO - 2024-10-14 21:53:51 --> Output Class Initialized
INFO - 2024-10-14 21:53:51 --> Security Class Initialized
DEBUG - 2024-10-14 21:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:53:51 --> Input Class Initialized
INFO - 2024-10-14 21:53:51 --> Language Class Initialized
INFO - 2024-10-14 21:53:51 --> Language Class Initialized
INFO - 2024-10-14 21:53:51 --> Config Class Initialized
INFO - 2024-10-14 21:53:51 --> Loader Class Initialized
INFO - 2024-10-14 21:53:51 --> Helper loaded: url_helper
INFO - 2024-10-14 21:53:51 --> Helper loaded: file_helper
INFO - 2024-10-14 21:53:51 --> Helper loaded: form_helper
INFO - 2024-10-14 21:53:51 --> Helper loaded: my_helper
INFO - 2024-10-14 21:53:51 --> Database Driver Class Initialized
INFO - 2024-10-14 21:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:53:51 --> Controller Class Initialized
DEBUG - 2024-10-14 21:53:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-10-14 21:53:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 21:53:51 --> Final output sent to browser
DEBUG - 2024-10-14 21:53:51 --> Total execution time: 0.0328
INFO - 2024-10-14 21:53:57 --> Config Class Initialized
INFO - 2024-10-14 21:53:57 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:53:57 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:53:57 --> Utf8 Class Initialized
INFO - 2024-10-14 21:53:57 --> URI Class Initialized
INFO - 2024-10-14 21:53:57 --> Router Class Initialized
INFO - 2024-10-14 21:53:57 --> Output Class Initialized
INFO - 2024-10-14 21:53:57 --> Security Class Initialized
DEBUG - 2024-10-14 21:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:53:57 --> Input Class Initialized
INFO - 2024-10-14 21:53:57 --> Language Class Initialized
INFO - 2024-10-14 21:53:57 --> Language Class Initialized
INFO - 2024-10-14 21:53:57 --> Config Class Initialized
INFO - 2024-10-14 21:53:57 --> Loader Class Initialized
INFO - 2024-10-14 21:53:57 --> Helper loaded: url_helper
INFO - 2024-10-14 21:53:57 --> Helper loaded: file_helper
INFO - 2024-10-14 21:53:57 --> Helper loaded: form_helper
INFO - 2024-10-14 21:53:57 --> Helper loaded: my_helper
INFO - 2024-10-14 21:53:57 --> Database Driver Class Initialized
INFO - 2024-10-14 21:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:53:57 --> Controller Class Initialized
INFO - 2024-10-14 21:53:57 --> Config Class Initialized
INFO - 2024-10-14 21:53:57 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:53:57 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:53:57 --> Utf8 Class Initialized
INFO - 2024-10-14 21:53:57 --> URI Class Initialized
INFO - 2024-10-14 21:53:57 --> Router Class Initialized
INFO - 2024-10-14 21:53:57 --> Output Class Initialized
INFO - 2024-10-14 21:53:57 --> Security Class Initialized
DEBUG - 2024-10-14 21:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:53:57 --> Input Class Initialized
INFO - 2024-10-14 21:53:57 --> Language Class Initialized
INFO - 2024-10-14 21:53:57 --> Language Class Initialized
INFO - 2024-10-14 21:53:57 --> Config Class Initialized
INFO - 2024-10-14 21:53:57 --> Loader Class Initialized
INFO - 2024-10-14 21:53:57 --> Helper loaded: url_helper
INFO - 2024-10-14 21:53:57 --> Helper loaded: file_helper
INFO - 2024-10-14 21:53:57 --> Helper loaded: form_helper
INFO - 2024-10-14 21:53:57 --> Helper loaded: my_helper
INFO - 2024-10-14 21:53:57 --> Database Driver Class Initialized
INFO - 2024-10-14 21:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:53:57 --> Controller Class Initialized
DEBUG - 2024-10-14 21:53:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-14 21:53:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 21:53:57 --> Final output sent to browser
DEBUG - 2024-10-14 21:53:57 --> Total execution time: 0.0379
INFO - 2024-10-14 21:54:56 --> Config Class Initialized
INFO - 2024-10-14 21:54:56 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:54:56 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:54:56 --> Utf8 Class Initialized
INFO - 2024-10-14 21:54:56 --> URI Class Initialized
INFO - 2024-10-14 21:54:56 --> Router Class Initialized
INFO - 2024-10-14 21:54:56 --> Output Class Initialized
INFO - 2024-10-14 21:54:56 --> Security Class Initialized
DEBUG - 2024-10-14 21:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:54:56 --> Input Class Initialized
INFO - 2024-10-14 21:54:56 --> Language Class Initialized
INFO - 2024-10-14 21:54:56 --> Language Class Initialized
INFO - 2024-10-14 21:54:56 --> Config Class Initialized
INFO - 2024-10-14 21:54:56 --> Loader Class Initialized
INFO - 2024-10-14 21:54:56 --> Helper loaded: url_helper
INFO - 2024-10-14 21:54:56 --> Helper loaded: file_helper
INFO - 2024-10-14 21:54:56 --> Helper loaded: form_helper
INFO - 2024-10-14 21:54:56 --> Helper loaded: my_helper
INFO - 2024-10-14 21:54:56 --> Database Driver Class Initialized
INFO - 2024-10-14 21:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:54:56 --> Controller Class Initialized
DEBUG - 2024-10-14 21:54:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-14 21:54:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 21:54:56 --> Final output sent to browser
DEBUG - 2024-10-14 21:54:56 --> Total execution time: 0.0291
INFO - 2024-10-14 21:55:01 --> Config Class Initialized
INFO - 2024-10-14 21:55:01 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:55:01 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:55:01 --> Utf8 Class Initialized
INFO - 2024-10-14 21:55:01 --> URI Class Initialized
INFO - 2024-10-14 21:55:01 --> Router Class Initialized
INFO - 2024-10-14 21:55:01 --> Output Class Initialized
INFO - 2024-10-14 21:55:01 --> Security Class Initialized
DEBUG - 2024-10-14 21:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:55:01 --> Input Class Initialized
INFO - 2024-10-14 21:55:01 --> Language Class Initialized
INFO - 2024-10-14 21:55:01 --> Language Class Initialized
INFO - 2024-10-14 21:55:01 --> Config Class Initialized
INFO - 2024-10-14 21:55:01 --> Loader Class Initialized
INFO - 2024-10-14 21:55:01 --> Helper loaded: url_helper
INFO - 2024-10-14 21:55:01 --> Helper loaded: file_helper
INFO - 2024-10-14 21:55:01 --> Helper loaded: form_helper
INFO - 2024-10-14 21:55:01 --> Helper loaded: my_helper
INFO - 2024-10-14 21:55:01 --> Database Driver Class Initialized
INFO - 2024-10-14 21:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:55:01 --> Controller Class Initialized
DEBUG - 2024-10-14 21:55:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-14 21:55:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 21:55:01 --> Final output sent to browser
DEBUG - 2024-10-14 21:55:01 --> Total execution time: 0.0405
INFO - 2024-10-14 21:55:02 --> Config Class Initialized
INFO - 2024-10-14 21:55:02 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:55:02 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:55:02 --> Utf8 Class Initialized
INFO - 2024-10-14 21:55:02 --> URI Class Initialized
INFO - 2024-10-14 21:55:02 --> Router Class Initialized
INFO - 2024-10-14 21:55:02 --> Output Class Initialized
INFO - 2024-10-14 21:55:02 --> Security Class Initialized
DEBUG - 2024-10-14 21:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:55:02 --> Input Class Initialized
INFO - 2024-10-14 21:55:02 --> Language Class Initialized
INFO - 2024-10-14 21:55:02 --> Language Class Initialized
INFO - 2024-10-14 21:55:02 --> Config Class Initialized
INFO - 2024-10-14 21:55:02 --> Loader Class Initialized
INFO - 2024-10-14 21:55:02 --> Helper loaded: url_helper
INFO - 2024-10-14 21:55:02 --> Helper loaded: file_helper
INFO - 2024-10-14 21:55:02 --> Helper loaded: form_helper
INFO - 2024-10-14 21:55:02 --> Helper loaded: my_helper
INFO - 2024-10-14 21:55:02 --> Database Driver Class Initialized
INFO - 2024-10-14 21:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:55:02 --> Controller Class Initialized
DEBUG - 2024-10-14 21:55:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-10-14 21:55:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 21:55:02 --> Final output sent to browser
DEBUG - 2024-10-14 21:55:02 --> Total execution time: 0.0396
INFO - 2024-10-14 21:55:07 --> Config Class Initialized
INFO - 2024-10-14 21:55:07 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:55:07 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:55:07 --> Utf8 Class Initialized
INFO - 2024-10-14 21:55:07 --> URI Class Initialized
INFO - 2024-10-14 21:55:07 --> Router Class Initialized
INFO - 2024-10-14 21:55:07 --> Output Class Initialized
INFO - 2024-10-14 21:55:07 --> Security Class Initialized
DEBUG - 2024-10-14 21:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:55:07 --> Input Class Initialized
INFO - 2024-10-14 21:55:07 --> Language Class Initialized
INFO - 2024-10-14 21:55:07 --> Language Class Initialized
INFO - 2024-10-14 21:55:07 --> Config Class Initialized
INFO - 2024-10-14 21:55:07 --> Loader Class Initialized
INFO - 2024-10-14 21:55:07 --> Helper loaded: url_helper
INFO - 2024-10-14 21:55:07 --> Helper loaded: file_helper
INFO - 2024-10-14 21:55:07 --> Helper loaded: form_helper
INFO - 2024-10-14 21:55:07 --> Helper loaded: my_helper
INFO - 2024-10-14 21:55:07 --> Database Driver Class Initialized
INFO - 2024-10-14 21:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:55:07 --> Controller Class Initialized
INFO - 2024-10-14 21:55:07 --> Config Class Initialized
INFO - 2024-10-14 21:55:07 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:55:07 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:55:07 --> Utf8 Class Initialized
INFO - 2024-10-14 21:55:07 --> URI Class Initialized
INFO - 2024-10-14 21:55:07 --> Router Class Initialized
INFO - 2024-10-14 21:55:07 --> Output Class Initialized
INFO - 2024-10-14 21:55:07 --> Security Class Initialized
DEBUG - 2024-10-14 21:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:55:07 --> Input Class Initialized
INFO - 2024-10-14 21:55:07 --> Language Class Initialized
INFO - 2024-10-14 21:55:07 --> Language Class Initialized
INFO - 2024-10-14 21:55:07 --> Config Class Initialized
INFO - 2024-10-14 21:55:07 --> Loader Class Initialized
INFO - 2024-10-14 21:55:07 --> Helper loaded: url_helper
INFO - 2024-10-14 21:55:07 --> Helper loaded: file_helper
INFO - 2024-10-14 21:55:07 --> Helper loaded: form_helper
INFO - 2024-10-14 21:55:07 --> Helper loaded: my_helper
INFO - 2024-10-14 21:55:07 --> Database Driver Class Initialized
INFO - 2024-10-14 21:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:55:07 --> Controller Class Initialized
DEBUG - 2024-10-14 21:55:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-14 21:55:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 21:55:07 --> Final output sent to browser
DEBUG - 2024-10-14 21:55:07 --> Total execution time: 0.0376
INFO - 2024-10-14 21:56:12 --> Config Class Initialized
INFO - 2024-10-14 21:56:12 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:56:12 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:56:12 --> Utf8 Class Initialized
INFO - 2024-10-14 21:56:12 --> URI Class Initialized
INFO - 2024-10-14 21:56:12 --> Router Class Initialized
INFO - 2024-10-14 21:56:12 --> Output Class Initialized
INFO - 2024-10-14 21:56:12 --> Security Class Initialized
DEBUG - 2024-10-14 21:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:56:12 --> Input Class Initialized
INFO - 2024-10-14 21:56:12 --> Language Class Initialized
INFO - 2024-10-14 21:56:12 --> Language Class Initialized
INFO - 2024-10-14 21:56:12 --> Config Class Initialized
INFO - 2024-10-14 21:56:12 --> Loader Class Initialized
INFO - 2024-10-14 21:56:12 --> Helper loaded: url_helper
INFO - 2024-10-14 21:56:12 --> Helper loaded: file_helper
INFO - 2024-10-14 21:56:12 --> Helper loaded: form_helper
INFO - 2024-10-14 21:56:12 --> Helper loaded: my_helper
INFO - 2024-10-14 21:56:12 --> Database Driver Class Initialized
INFO - 2024-10-14 21:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:56:12 --> Controller Class Initialized
DEBUG - 2024-10-14 21:56:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-14 21:56:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 21:56:12 --> Final output sent to browser
DEBUG - 2024-10-14 21:56:12 --> Total execution time: 0.0406
INFO - 2024-10-14 21:56:13 --> Config Class Initialized
INFO - 2024-10-14 21:56:13 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:56:13 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:56:13 --> Utf8 Class Initialized
INFO - 2024-10-14 21:56:13 --> URI Class Initialized
INFO - 2024-10-14 21:56:13 --> Router Class Initialized
INFO - 2024-10-14 21:56:13 --> Output Class Initialized
INFO - 2024-10-14 21:56:13 --> Security Class Initialized
DEBUG - 2024-10-14 21:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:56:13 --> Input Class Initialized
INFO - 2024-10-14 21:56:13 --> Language Class Initialized
INFO - 2024-10-14 21:56:13 --> Language Class Initialized
INFO - 2024-10-14 21:56:13 --> Config Class Initialized
INFO - 2024-10-14 21:56:13 --> Loader Class Initialized
INFO - 2024-10-14 21:56:13 --> Helper loaded: url_helper
INFO - 2024-10-14 21:56:13 --> Helper loaded: file_helper
INFO - 2024-10-14 21:56:13 --> Helper loaded: form_helper
INFO - 2024-10-14 21:56:13 --> Helper loaded: my_helper
INFO - 2024-10-14 21:56:14 --> Database Driver Class Initialized
INFO - 2024-10-14 21:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:56:14 --> Controller Class Initialized
DEBUG - 2024-10-14 21:56:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-14 21:56:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 21:56:14 --> Final output sent to browser
DEBUG - 2024-10-14 21:56:14 --> Total execution time: 0.0917
INFO - 2024-10-14 21:56:14 --> Config Class Initialized
INFO - 2024-10-14 21:56:14 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:56:14 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:56:14 --> Utf8 Class Initialized
INFO - 2024-10-14 21:56:14 --> URI Class Initialized
INFO - 2024-10-14 21:56:14 --> Router Class Initialized
INFO - 2024-10-14 21:56:14 --> Output Class Initialized
INFO - 2024-10-14 21:56:14 --> Security Class Initialized
DEBUG - 2024-10-14 21:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:56:14 --> Input Class Initialized
INFO - 2024-10-14 21:56:14 --> Language Class Initialized
INFO - 2024-10-14 21:56:14 --> Language Class Initialized
INFO - 2024-10-14 21:56:14 --> Config Class Initialized
INFO - 2024-10-14 21:56:14 --> Loader Class Initialized
INFO - 2024-10-14 21:56:14 --> Helper loaded: url_helper
INFO - 2024-10-14 21:56:14 --> Helper loaded: file_helper
INFO - 2024-10-14 21:56:14 --> Helper loaded: form_helper
INFO - 2024-10-14 21:56:14 --> Helper loaded: my_helper
INFO - 2024-10-14 21:56:14 --> Database Driver Class Initialized
INFO - 2024-10-14 21:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:56:14 --> Controller Class Initialized
INFO - 2024-10-14 21:56:14 --> Config Class Initialized
INFO - 2024-10-14 21:56:14 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:56:14 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:56:14 --> Utf8 Class Initialized
INFO - 2024-10-14 21:56:14 --> URI Class Initialized
INFO - 2024-10-14 21:56:14 --> Router Class Initialized
INFO - 2024-10-14 21:56:14 --> Output Class Initialized
INFO - 2024-10-14 21:56:14 --> Security Class Initialized
DEBUG - 2024-10-14 21:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:56:14 --> Input Class Initialized
INFO - 2024-10-14 21:56:14 --> Language Class Initialized
INFO - 2024-10-14 21:56:14 --> Language Class Initialized
INFO - 2024-10-14 21:56:14 --> Config Class Initialized
INFO - 2024-10-14 21:56:14 --> Loader Class Initialized
INFO - 2024-10-14 21:56:14 --> Helper loaded: url_helper
INFO - 2024-10-14 21:56:14 --> Helper loaded: file_helper
INFO - 2024-10-14 21:56:14 --> Helper loaded: form_helper
INFO - 2024-10-14 21:56:14 --> Helper loaded: my_helper
INFO - 2024-10-14 21:56:15 --> Database Driver Class Initialized
INFO - 2024-10-14 21:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:56:15 --> Controller Class Initialized
DEBUG - 2024-10-14 21:56:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-14 21:56:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 21:56:15 --> Final output sent to browser
DEBUG - 2024-10-14 21:56:15 --> Total execution time: 0.0377
INFO - 2024-10-14 21:56:15 --> Config Class Initialized
INFO - 2024-10-14 21:56:15 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:56:15 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:56:15 --> Utf8 Class Initialized
INFO - 2024-10-14 21:56:15 --> URI Class Initialized
INFO - 2024-10-14 21:56:15 --> Router Class Initialized
INFO - 2024-10-14 21:56:15 --> Output Class Initialized
INFO - 2024-10-14 21:56:15 --> Security Class Initialized
DEBUG - 2024-10-14 21:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:56:15 --> Input Class Initialized
INFO - 2024-10-14 21:56:15 --> Language Class Initialized
INFO - 2024-10-14 21:56:15 --> Language Class Initialized
INFO - 2024-10-14 21:56:15 --> Config Class Initialized
INFO - 2024-10-14 21:56:15 --> Loader Class Initialized
INFO - 2024-10-14 21:56:15 --> Helper loaded: url_helper
INFO - 2024-10-14 21:56:15 --> Helper loaded: file_helper
INFO - 2024-10-14 21:56:15 --> Helper loaded: form_helper
INFO - 2024-10-14 21:56:15 --> Helper loaded: my_helper
INFO - 2024-10-14 21:56:15 --> Database Driver Class Initialized
INFO - 2024-10-14 21:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:56:15 --> Controller Class Initialized
DEBUG - 2024-10-14 21:56:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-14 21:56:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 21:56:15 --> Final output sent to browser
DEBUG - 2024-10-14 21:56:15 --> Total execution time: 0.0347
INFO - 2024-10-14 21:56:17 --> Config Class Initialized
INFO - 2024-10-14 21:56:17 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:56:17 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:56:17 --> Utf8 Class Initialized
INFO - 2024-10-14 21:56:17 --> URI Class Initialized
INFO - 2024-10-14 21:56:17 --> Router Class Initialized
INFO - 2024-10-14 21:56:17 --> Output Class Initialized
INFO - 2024-10-14 21:56:17 --> Security Class Initialized
DEBUG - 2024-10-14 21:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:56:17 --> Input Class Initialized
INFO - 2024-10-14 21:56:17 --> Language Class Initialized
INFO - 2024-10-14 21:56:17 --> Language Class Initialized
INFO - 2024-10-14 21:56:17 --> Config Class Initialized
INFO - 2024-10-14 21:56:17 --> Loader Class Initialized
INFO - 2024-10-14 21:56:17 --> Helper loaded: url_helper
INFO - 2024-10-14 21:56:17 --> Helper loaded: file_helper
INFO - 2024-10-14 21:56:17 --> Helper loaded: form_helper
INFO - 2024-10-14 21:56:17 --> Helper loaded: my_helper
INFO - 2024-10-14 21:56:17 --> Database Driver Class Initialized
INFO - 2024-10-14 21:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:56:17 --> Controller Class Initialized
DEBUG - 2024-10-14 21:56:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-10-14 21:56:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 21:56:17 --> Final output sent to browser
DEBUG - 2024-10-14 21:56:17 --> Total execution time: 0.0438
INFO - 2024-10-14 21:56:22 --> Config Class Initialized
INFO - 2024-10-14 21:56:22 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:56:22 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:56:22 --> Utf8 Class Initialized
INFO - 2024-10-14 21:56:22 --> URI Class Initialized
INFO - 2024-10-14 21:56:22 --> Router Class Initialized
INFO - 2024-10-14 21:56:22 --> Output Class Initialized
INFO - 2024-10-14 21:56:22 --> Security Class Initialized
DEBUG - 2024-10-14 21:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:56:22 --> Input Class Initialized
INFO - 2024-10-14 21:56:22 --> Language Class Initialized
INFO - 2024-10-14 21:56:22 --> Language Class Initialized
INFO - 2024-10-14 21:56:22 --> Config Class Initialized
INFO - 2024-10-14 21:56:22 --> Loader Class Initialized
INFO - 2024-10-14 21:56:22 --> Helper loaded: url_helper
INFO - 2024-10-14 21:56:22 --> Helper loaded: file_helper
INFO - 2024-10-14 21:56:22 --> Helper loaded: form_helper
INFO - 2024-10-14 21:56:22 --> Helper loaded: my_helper
INFO - 2024-10-14 21:56:22 --> Database Driver Class Initialized
INFO - 2024-10-14 21:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:56:22 --> Controller Class Initialized
INFO - 2024-10-14 21:56:23 --> Config Class Initialized
INFO - 2024-10-14 21:56:23 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:56:23 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:56:23 --> Utf8 Class Initialized
INFO - 2024-10-14 21:56:23 --> URI Class Initialized
INFO - 2024-10-14 21:56:23 --> Router Class Initialized
INFO - 2024-10-14 21:56:23 --> Output Class Initialized
INFO - 2024-10-14 21:56:23 --> Security Class Initialized
DEBUG - 2024-10-14 21:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:56:23 --> Input Class Initialized
INFO - 2024-10-14 21:56:23 --> Language Class Initialized
INFO - 2024-10-14 21:56:23 --> Language Class Initialized
INFO - 2024-10-14 21:56:23 --> Config Class Initialized
INFO - 2024-10-14 21:56:23 --> Loader Class Initialized
INFO - 2024-10-14 21:56:23 --> Helper loaded: url_helper
INFO - 2024-10-14 21:56:23 --> Helper loaded: file_helper
INFO - 2024-10-14 21:56:23 --> Helper loaded: form_helper
INFO - 2024-10-14 21:56:23 --> Helper loaded: my_helper
INFO - 2024-10-14 21:56:23 --> Database Driver Class Initialized
INFO - 2024-10-14 21:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:56:23 --> Controller Class Initialized
DEBUG - 2024-10-14 21:56:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-14 21:56:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-14 21:56:23 --> Final output sent to browser
DEBUG - 2024-10-14 21:56:23 --> Total execution time: 0.0430
INFO - 2024-10-14 21:56:24 --> Config Class Initialized
INFO - 2024-10-14 21:56:24 --> Hooks Class Initialized
DEBUG - 2024-10-14 21:56:24 --> UTF-8 Support Enabled
INFO - 2024-10-14 21:56:24 --> Utf8 Class Initialized
INFO - 2024-10-14 21:56:24 --> URI Class Initialized
INFO - 2024-10-14 21:56:24 --> Router Class Initialized
INFO - 2024-10-14 21:56:24 --> Output Class Initialized
INFO - 2024-10-14 21:56:24 --> Security Class Initialized
DEBUG - 2024-10-14 21:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 21:56:24 --> Input Class Initialized
INFO - 2024-10-14 21:56:24 --> Language Class Initialized
INFO - 2024-10-14 21:56:24 --> Language Class Initialized
INFO - 2024-10-14 21:56:24 --> Config Class Initialized
INFO - 2024-10-14 21:56:24 --> Loader Class Initialized
INFO - 2024-10-14 21:56:24 --> Helper loaded: url_helper
INFO - 2024-10-14 21:56:24 --> Helper loaded: file_helper
INFO - 2024-10-14 21:56:24 --> Helper loaded: form_helper
INFO - 2024-10-14 21:56:24 --> Helper loaded: my_helper
INFO - 2024-10-14 21:56:24 --> Database Driver Class Initialized
INFO - 2024-10-14 21:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 21:56:24 --> Controller Class Initialized
INFO - 2024-10-14 21:56:24 --> Final output sent to browser
DEBUG - 2024-10-14 21:56:24 --> Total execution time: 0.0392
