<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-08-14 13:01:39 --> Config Class Initialized
INFO - 2018-08-14 13:01:39 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:01:39 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:01:39 --> Utf8 Class Initialized
INFO - 2018-08-14 13:01:39 --> URI Class Initialized
INFO - 2018-08-14 13:01:40 --> Router Class Initialized
INFO - 2018-08-14 13:01:40 --> Output Class Initialized
INFO - 2018-08-14 13:01:40 --> Security Class Initialized
DEBUG - 2018-08-14 13:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:01:40 --> Input Class Initialized
INFO - 2018-08-14 13:01:40 --> Language Class Initialized
INFO - 2018-08-14 13:01:40 --> Language Class Initialized
INFO - 2018-08-14 13:01:40 --> Config Class Initialized
INFO - 2018-08-14 13:01:40 --> Loader Class Initialized
INFO - 2018-08-14 13:01:40 --> Helper loaded: url_helper
INFO - 2018-08-14 13:01:40 --> Helper loaded: file_helper
INFO - 2018-08-14 13:01:40 --> Helper loaded: form_helper
INFO - 2018-08-14 13:01:40 --> Helper loaded: my_helper
INFO - 2018-08-14 13:01:40 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:01:40 --> Controller Class Initialized
INFO - 2018-08-14 13:02:07 --> Config Class Initialized
INFO - 2018-08-14 13:02:07 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:02:07 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:02:07 --> Utf8 Class Initialized
INFO - 2018-08-14 13:02:07 --> URI Class Initialized
INFO - 2018-08-14 13:02:07 --> Router Class Initialized
INFO - 2018-08-14 13:02:07 --> Output Class Initialized
INFO - 2018-08-14 13:02:07 --> Security Class Initialized
DEBUG - 2018-08-14 13:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:02:07 --> Input Class Initialized
INFO - 2018-08-14 13:02:07 --> Language Class Initialized
INFO - 2018-08-14 13:02:07 --> Language Class Initialized
INFO - 2018-08-14 13:02:07 --> Config Class Initialized
INFO - 2018-08-14 13:02:07 --> Loader Class Initialized
INFO - 2018-08-14 13:02:07 --> Helper loaded: url_helper
INFO - 2018-08-14 13:02:07 --> Helper loaded: file_helper
INFO - 2018-08-14 13:02:07 --> Helper loaded: form_helper
INFO - 2018-08-14 13:02:07 --> Helper loaded: my_helper
INFO - 2018-08-14 13:02:07 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:02:07 --> Controller Class Initialized
DEBUG - 2018-08-14 13:02:07 --> File loaded: D:\laragon\www\nilai\application\modules/login/views/login.php
DEBUG - 2018-08-14 13:02:07 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:02:07 --> Final output sent to browser
DEBUG - 2018-08-14 13:02:07 --> Total execution time: 0.2138
INFO - 2018-08-14 13:02:07 --> Config Class Initialized
INFO - 2018-08-14 13:02:07 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:02:07 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:02:07 --> Utf8 Class Initialized
INFO - 2018-08-14 13:02:07 --> URI Class Initialized
INFO - 2018-08-14 13:02:07 --> Router Class Initialized
INFO - 2018-08-14 13:02:07 --> Output Class Initialized
INFO - 2018-08-14 13:02:07 --> Security Class Initialized
DEBUG - 2018-08-14 13:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:02:08 --> Input Class Initialized
INFO - 2018-08-14 13:02:08 --> Language Class Initialized
ERROR - 2018-08-14 13:02:08 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:02:08 --> Config Class Initialized
INFO - 2018-08-14 13:02:08 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:02:08 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:02:08 --> Utf8 Class Initialized
INFO - 2018-08-14 13:02:08 --> URI Class Initialized
INFO - 2018-08-14 13:02:08 --> Router Class Initialized
INFO - 2018-08-14 13:02:08 --> Output Class Initialized
INFO - 2018-08-14 13:02:08 --> Security Class Initialized
DEBUG - 2018-08-14 13:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:02:08 --> Input Class Initialized
INFO - 2018-08-14 13:02:08 --> Language Class Initialized
INFO - 2018-08-14 13:02:08 --> Language Class Initialized
INFO - 2018-08-14 13:02:08 --> Config Class Initialized
INFO - 2018-08-14 13:02:08 --> Loader Class Initialized
INFO - 2018-08-14 13:02:08 --> Helper loaded: url_helper
INFO - 2018-08-14 13:02:08 --> Helper loaded: file_helper
INFO - 2018-08-14 13:02:08 --> Helper loaded: form_helper
INFO - 2018-08-14 13:02:08 --> Helper loaded: my_helper
INFO - 2018-08-14 13:02:08 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:02:08 --> Controller Class Initialized
DEBUG - 2018-08-14 13:02:08 --> File loaded: D:\laragon\www\nilai\application\modules/login/views/login.php
DEBUG - 2018-08-14 13:02:08 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:02:08 --> Final output sent to browser
DEBUG - 2018-08-14 13:02:09 --> Total execution time: 0.4610
INFO - 2018-08-14 13:02:09 --> Config Class Initialized
INFO - 2018-08-14 13:02:09 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:02:09 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:02:09 --> Utf8 Class Initialized
INFO - 2018-08-14 13:02:09 --> URI Class Initialized
INFO - 2018-08-14 13:02:09 --> Router Class Initialized
INFO - 2018-08-14 13:02:09 --> Output Class Initialized
INFO - 2018-08-14 13:02:09 --> Security Class Initialized
DEBUG - 2018-08-14 13:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:02:09 --> Input Class Initialized
INFO - 2018-08-14 13:02:09 --> Language Class Initialized
ERROR - 2018-08-14 13:02:09 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:02:12 --> Config Class Initialized
INFO - 2018-08-14 13:02:12 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:02:12 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:02:12 --> Utf8 Class Initialized
INFO - 2018-08-14 13:02:12 --> URI Class Initialized
INFO - 2018-08-14 13:02:12 --> Router Class Initialized
INFO - 2018-08-14 13:02:12 --> Output Class Initialized
INFO - 2018-08-14 13:02:12 --> Security Class Initialized
DEBUG - 2018-08-14 13:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:02:12 --> Input Class Initialized
INFO - 2018-08-14 13:02:12 --> Language Class Initialized
INFO - 2018-08-14 13:02:12 --> Language Class Initialized
INFO - 2018-08-14 13:02:12 --> Config Class Initialized
INFO - 2018-08-14 13:02:12 --> Loader Class Initialized
INFO - 2018-08-14 13:02:12 --> Helper loaded: url_helper
INFO - 2018-08-14 13:02:12 --> Helper loaded: file_helper
INFO - 2018-08-14 13:02:12 --> Helper loaded: form_helper
INFO - 2018-08-14 13:02:12 --> Helper loaded: my_helper
INFO - 2018-08-14 13:02:12 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:02:12 --> Controller Class Initialized
INFO - 2018-08-14 13:02:12 --> Final output sent to browser
DEBUG - 2018-08-14 13:02:12 --> Total execution time: 0.2448
INFO - 2018-08-14 13:02:16 --> Config Class Initialized
INFO - 2018-08-14 13:02:16 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:02:16 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:02:16 --> Utf8 Class Initialized
INFO - 2018-08-14 13:02:16 --> URI Class Initialized
INFO - 2018-08-14 13:02:16 --> Router Class Initialized
INFO - 2018-08-14 13:02:16 --> Output Class Initialized
INFO - 2018-08-14 13:02:16 --> Security Class Initialized
DEBUG - 2018-08-14 13:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:02:16 --> Input Class Initialized
INFO - 2018-08-14 13:02:16 --> Language Class Initialized
INFO - 2018-08-14 13:02:16 --> Language Class Initialized
INFO - 2018-08-14 13:02:16 --> Config Class Initialized
INFO - 2018-08-14 13:02:16 --> Loader Class Initialized
INFO - 2018-08-14 13:02:16 --> Helper loaded: url_helper
INFO - 2018-08-14 13:02:16 --> Helper loaded: file_helper
INFO - 2018-08-14 13:02:16 --> Helper loaded: form_helper
INFO - 2018-08-14 13:02:16 --> Helper loaded: my_helper
INFO - 2018-08-14 13:02:16 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:02:16 --> Controller Class Initialized
INFO - 2018-08-14 13:02:16 --> Helper loaded: cookie_helper
INFO - 2018-08-14 13:02:16 --> Final output sent to browser
DEBUG - 2018-08-14 13:02:16 --> Total execution time: 0.2485
INFO - 2018-08-14 13:02:17 --> Config Class Initialized
INFO - 2018-08-14 13:02:17 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:02:17 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:02:17 --> Utf8 Class Initialized
INFO - 2018-08-14 13:02:17 --> URI Class Initialized
INFO - 2018-08-14 13:02:17 --> Router Class Initialized
INFO - 2018-08-14 13:02:17 --> Output Class Initialized
INFO - 2018-08-14 13:02:17 --> Security Class Initialized
DEBUG - 2018-08-14 13:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:02:18 --> Input Class Initialized
INFO - 2018-08-14 13:02:18 --> Language Class Initialized
INFO - 2018-08-14 13:02:18 --> Language Class Initialized
INFO - 2018-08-14 13:02:18 --> Config Class Initialized
INFO - 2018-08-14 13:02:18 --> Loader Class Initialized
INFO - 2018-08-14 13:02:18 --> Helper loaded: url_helper
INFO - 2018-08-14 13:02:18 --> Helper loaded: file_helper
INFO - 2018-08-14 13:02:18 --> Helper loaded: form_helper
INFO - 2018-08-14 13:02:18 --> Helper loaded: my_helper
INFO - 2018-08-14 13:02:18 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:02:18 --> Controller Class Initialized
INFO - 2018-08-14 13:04:07 --> Config Class Initialized
INFO - 2018-08-14 13:04:07 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:04:07 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:04:07 --> Utf8 Class Initialized
INFO - 2018-08-14 13:04:07 --> URI Class Initialized
INFO - 2018-08-14 13:04:07 --> Router Class Initialized
INFO - 2018-08-14 13:04:07 --> Output Class Initialized
INFO - 2018-08-14 13:04:07 --> Security Class Initialized
DEBUG - 2018-08-14 13:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:04:07 --> Input Class Initialized
INFO - 2018-08-14 13:04:07 --> Language Class Initialized
INFO - 2018-08-14 13:04:07 --> Language Class Initialized
INFO - 2018-08-14 13:04:07 --> Config Class Initialized
INFO - 2018-08-14 13:04:07 --> Loader Class Initialized
INFO - 2018-08-14 13:04:07 --> Helper loaded: url_helper
INFO - 2018-08-14 13:04:07 --> Helper loaded: file_helper
INFO - 2018-08-14 13:04:07 --> Helper loaded: form_helper
INFO - 2018-08-14 13:04:07 --> Helper loaded: my_helper
INFO - 2018-08-14 13:04:07 --> Database Driver Class Initialized
INFO - 2018-08-14 13:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:04:07 --> Controller Class Initialized
INFO - 2018-08-14 13:04:09 --> Config Class Initialized
INFO - 2018-08-14 13:04:09 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:04:09 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:04:09 --> Utf8 Class Initialized
INFO - 2018-08-14 13:04:09 --> URI Class Initialized
INFO - 2018-08-14 13:04:09 --> Router Class Initialized
INFO - 2018-08-14 13:04:09 --> Output Class Initialized
INFO - 2018-08-14 13:04:09 --> Security Class Initialized
DEBUG - 2018-08-14 13:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:04:09 --> Input Class Initialized
INFO - 2018-08-14 13:04:09 --> Language Class Initialized
INFO - 2018-08-14 13:04:09 --> Language Class Initialized
INFO - 2018-08-14 13:04:09 --> Config Class Initialized
INFO - 2018-08-14 13:04:09 --> Loader Class Initialized
INFO - 2018-08-14 13:04:09 --> Helper loaded: url_helper
INFO - 2018-08-14 13:04:09 --> Helper loaded: file_helper
INFO - 2018-08-14 13:04:09 --> Helper loaded: form_helper
INFO - 2018-08-14 13:04:09 --> Helper loaded: my_helper
INFO - 2018-08-14 13:04:09 --> Database Driver Class Initialized
INFO - 2018-08-14 13:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:04:09 --> Controller Class Initialized
DEBUG - 2018-08-14 13:04:09 --> File loaded: D:\laragon\www\nilai\application\modules/login/views/login.php
DEBUG - 2018-08-14 13:04:09 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:04:09 --> Final output sent to browser
DEBUG - 2018-08-14 13:04:09 --> Total execution time: 0.2485
INFO - 2018-08-14 13:04:09 --> Config Class Initialized
INFO - 2018-08-14 13:04:09 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:04:09 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:04:09 --> Utf8 Class Initialized
INFO - 2018-08-14 13:04:09 --> URI Class Initialized
INFO - 2018-08-14 13:04:09 --> Router Class Initialized
INFO - 2018-08-14 13:04:09 --> Output Class Initialized
INFO - 2018-08-14 13:04:09 --> Security Class Initialized
DEBUG - 2018-08-14 13:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:04:09 --> Input Class Initialized
INFO - 2018-08-14 13:04:09 --> Language Class Initialized
ERROR - 2018-08-14 13:04:09 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:04:10 --> Config Class Initialized
INFO - 2018-08-14 13:04:10 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:04:10 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:04:10 --> Utf8 Class Initialized
INFO - 2018-08-14 13:04:10 --> URI Class Initialized
INFO - 2018-08-14 13:04:10 --> Router Class Initialized
INFO - 2018-08-14 13:04:10 --> Output Class Initialized
INFO - 2018-08-14 13:04:10 --> Security Class Initialized
DEBUG - 2018-08-14 13:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:04:10 --> Input Class Initialized
INFO - 2018-08-14 13:04:10 --> Language Class Initialized
INFO - 2018-08-14 13:04:10 --> Language Class Initialized
INFO - 2018-08-14 13:04:10 --> Config Class Initialized
INFO - 2018-08-14 13:04:10 --> Loader Class Initialized
INFO - 2018-08-14 13:04:10 --> Helper loaded: url_helper
INFO - 2018-08-14 13:04:10 --> Helper loaded: file_helper
INFO - 2018-08-14 13:04:10 --> Helper loaded: form_helper
INFO - 2018-08-14 13:04:10 --> Helper loaded: my_helper
INFO - 2018-08-14 13:04:10 --> Database Driver Class Initialized
INFO - 2018-08-14 13:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:04:10 --> Controller Class Initialized
DEBUG - 2018-08-14 13:04:10 --> File loaded: D:\laragon\www\nilai\application\modules/login/views/login.php
DEBUG - 2018-08-14 13:04:10 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:04:10 --> Final output sent to browser
DEBUG - 2018-08-14 13:04:10 --> Total execution time: 0.2408
INFO - 2018-08-14 13:04:10 --> Config Class Initialized
INFO - 2018-08-14 13:04:10 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:04:10 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:04:10 --> Utf8 Class Initialized
INFO - 2018-08-14 13:04:10 --> URI Class Initialized
INFO - 2018-08-14 13:04:10 --> Router Class Initialized
INFO - 2018-08-14 13:04:10 --> Output Class Initialized
INFO - 2018-08-14 13:04:11 --> Security Class Initialized
DEBUG - 2018-08-14 13:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:04:11 --> Input Class Initialized
INFO - 2018-08-14 13:04:11 --> Language Class Initialized
ERROR - 2018-08-14 13:04:11 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:04:14 --> Config Class Initialized
INFO - 2018-08-14 13:04:14 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:04:14 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:04:14 --> Utf8 Class Initialized
INFO - 2018-08-14 13:04:14 --> URI Class Initialized
INFO - 2018-08-14 13:04:14 --> Router Class Initialized
INFO - 2018-08-14 13:04:14 --> Output Class Initialized
INFO - 2018-08-14 13:04:14 --> Security Class Initialized
DEBUG - 2018-08-14 13:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:04:14 --> Input Class Initialized
INFO - 2018-08-14 13:04:14 --> Language Class Initialized
INFO - 2018-08-14 13:04:14 --> Language Class Initialized
INFO - 2018-08-14 13:04:14 --> Config Class Initialized
INFO - 2018-08-14 13:04:14 --> Loader Class Initialized
INFO - 2018-08-14 13:04:14 --> Helper loaded: url_helper
INFO - 2018-08-14 13:04:14 --> Helper loaded: file_helper
INFO - 2018-08-14 13:04:14 --> Helper loaded: form_helper
INFO - 2018-08-14 13:04:14 --> Helper loaded: my_helper
INFO - 2018-08-14 13:04:14 --> Database Driver Class Initialized
INFO - 2018-08-14 13:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:04:14 --> Controller Class Initialized
INFO - 2018-08-14 13:04:14 --> Helper loaded: cookie_helper
INFO - 2018-08-14 13:04:14 --> Final output sent to browser
DEBUG - 2018-08-14 13:04:14 --> Total execution time: 0.2327
INFO - 2018-08-14 13:04:14 --> Config Class Initialized
INFO - 2018-08-14 13:04:14 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:04:14 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:04:14 --> Utf8 Class Initialized
INFO - 2018-08-14 13:04:14 --> URI Class Initialized
INFO - 2018-08-14 13:04:14 --> Router Class Initialized
INFO - 2018-08-14 13:04:14 --> Output Class Initialized
INFO - 2018-08-14 13:04:14 --> Security Class Initialized
DEBUG - 2018-08-14 13:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:04:14 --> Input Class Initialized
INFO - 2018-08-14 13:04:14 --> Language Class Initialized
INFO - 2018-08-14 13:04:14 --> Language Class Initialized
INFO - 2018-08-14 13:04:14 --> Config Class Initialized
INFO - 2018-08-14 13:04:14 --> Loader Class Initialized
INFO - 2018-08-14 13:04:14 --> Helper loaded: url_helper
INFO - 2018-08-14 13:04:14 --> Helper loaded: file_helper
INFO - 2018-08-14 13:04:14 --> Helper loaded: form_helper
INFO - 2018-08-14 13:04:14 --> Helper loaded: my_helper
INFO - 2018-08-14 13:04:14 --> Database Driver Class Initialized
INFO - 2018-08-14 13:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:04:14 --> Controller Class Initialized
INFO - 2018-08-14 13:07:36 --> Config Class Initialized
INFO - 2018-08-14 13:07:36 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:07:36 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:07:36 --> Utf8 Class Initialized
INFO - 2018-08-14 13:07:36 --> URI Class Initialized
INFO - 2018-08-14 13:07:36 --> Router Class Initialized
INFO - 2018-08-14 13:07:36 --> Output Class Initialized
INFO - 2018-08-14 13:07:36 --> Security Class Initialized
DEBUG - 2018-08-14 13:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:07:36 --> Input Class Initialized
INFO - 2018-08-14 13:07:36 --> Language Class Initialized
INFO - 2018-08-14 13:07:36 --> Language Class Initialized
INFO - 2018-08-14 13:07:36 --> Config Class Initialized
INFO - 2018-08-14 13:07:36 --> Loader Class Initialized
INFO - 2018-08-14 13:07:36 --> Helper loaded: url_helper
INFO - 2018-08-14 13:07:36 --> Helper loaded: file_helper
INFO - 2018-08-14 13:07:36 --> Helper loaded: form_helper
INFO - 2018-08-14 13:07:36 --> Helper loaded: my_helper
INFO - 2018-08-14 13:07:36 --> Database Driver Class Initialized
ERROR - 2018-08-14 13:07:36 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time D:\laragon\www\nilai\system\libraries\Session\Session.php 314
INFO - 2018-08-14 13:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:07:36 --> Controller Class Initialized
INFO - 2018-08-14 13:07:45 --> Config Class Initialized
INFO - 2018-08-14 13:07:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:07:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:07:45 --> Utf8 Class Initialized
INFO - 2018-08-14 13:07:45 --> URI Class Initialized
INFO - 2018-08-14 13:07:45 --> Router Class Initialized
INFO - 2018-08-14 13:07:45 --> Output Class Initialized
INFO - 2018-08-14 13:07:45 --> Security Class Initialized
DEBUG - 2018-08-14 13:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:07:45 --> Input Class Initialized
INFO - 2018-08-14 13:07:45 --> Language Class Initialized
INFO - 2018-08-14 13:07:45 --> Language Class Initialized
INFO - 2018-08-14 13:07:45 --> Config Class Initialized
INFO - 2018-08-14 13:07:45 --> Loader Class Initialized
INFO - 2018-08-14 13:07:45 --> Helper loaded: url_helper
INFO - 2018-08-14 13:07:45 --> Helper loaded: file_helper
INFO - 2018-08-14 13:07:45 --> Helper loaded: form_helper
INFO - 2018-08-14 13:07:46 --> Helper loaded: my_helper
INFO - 2018-08-14 13:07:46 --> Database Driver Class Initialized
ERROR - 2018-08-14 13:07:46 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time D:\laragon\www\nilai\system\libraries\Session\Session.php 314
INFO - 2018-08-14 13:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:07:46 --> Controller Class Initialized
INFO - 2018-08-14 13:07:47 --> Config Class Initialized
INFO - 2018-08-14 13:07:47 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:07:47 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:07:47 --> Utf8 Class Initialized
INFO - 2018-08-14 13:07:47 --> URI Class Initialized
INFO - 2018-08-14 13:07:47 --> Router Class Initialized
INFO - 2018-08-14 13:07:47 --> Output Class Initialized
INFO - 2018-08-14 13:07:47 --> Security Class Initialized
DEBUG - 2018-08-14 13:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:07:47 --> Input Class Initialized
INFO - 2018-08-14 13:07:47 --> Language Class Initialized
INFO - 2018-08-14 13:07:47 --> Language Class Initialized
INFO - 2018-08-14 13:07:47 --> Config Class Initialized
INFO - 2018-08-14 13:07:47 --> Loader Class Initialized
INFO - 2018-08-14 13:07:47 --> Helper loaded: url_helper
INFO - 2018-08-14 13:07:47 --> Helper loaded: file_helper
INFO - 2018-08-14 13:07:47 --> Helper loaded: form_helper
INFO - 2018-08-14 13:07:47 --> Helper loaded: my_helper
INFO - 2018-08-14 13:07:47 --> Database Driver Class Initialized
ERROR - 2018-08-14 13:07:47 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time D:\laragon\www\nilai\system\libraries\Session\Session.php 314
INFO - 2018-08-14 13:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:07:47 --> Controller Class Initialized
INFO - 2018-08-14 13:07:59 --> Config Class Initialized
INFO - 2018-08-14 13:07:59 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:07:59 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:07:59 --> Utf8 Class Initialized
INFO - 2018-08-14 13:07:59 --> URI Class Initialized
INFO - 2018-08-14 13:08:00 --> Router Class Initialized
INFO - 2018-08-14 13:08:00 --> Output Class Initialized
INFO - 2018-08-14 13:08:00 --> Security Class Initialized
DEBUG - 2018-08-14 13:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:08:00 --> Input Class Initialized
INFO - 2018-08-14 13:08:00 --> Language Class Initialized
INFO - 2018-08-14 13:08:00 --> Language Class Initialized
INFO - 2018-08-14 13:08:00 --> Config Class Initialized
INFO - 2018-08-14 13:08:00 --> Loader Class Initialized
INFO - 2018-08-14 13:08:00 --> Helper loaded: url_helper
INFO - 2018-08-14 13:08:00 --> Helper loaded: file_helper
INFO - 2018-08-14 13:08:00 --> Helper loaded: form_helper
INFO - 2018-08-14 13:08:00 --> Helper loaded: my_helper
INFO - 2018-08-14 13:08:00 --> Database Driver Class Initialized
ERROR - 2018-08-14 13:08:00 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time D:\laragon\www\nilai\system\libraries\Session\Session.php 314
INFO - 2018-08-14 13:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:08:00 --> Controller Class Initialized
INFO - 2018-08-14 13:08:11 --> Config Class Initialized
INFO - 2018-08-14 13:08:11 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:08:11 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:08:11 --> Utf8 Class Initialized
INFO - 2018-08-14 13:08:11 --> URI Class Initialized
INFO - 2018-08-14 13:08:11 --> Router Class Initialized
INFO - 2018-08-14 13:08:11 --> Output Class Initialized
INFO - 2018-08-14 13:08:11 --> Security Class Initialized
DEBUG - 2018-08-14 13:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:08:11 --> Input Class Initialized
INFO - 2018-08-14 13:08:11 --> Language Class Initialized
INFO - 2018-08-14 13:08:11 --> Language Class Initialized
INFO - 2018-08-14 13:08:11 --> Config Class Initialized
INFO - 2018-08-14 13:08:11 --> Loader Class Initialized
INFO - 2018-08-14 13:08:11 --> Helper loaded: url_helper
INFO - 2018-08-14 13:08:11 --> Helper loaded: file_helper
INFO - 2018-08-14 13:08:11 --> Helper loaded: form_helper
INFO - 2018-08-14 13:08:11 --> Helper loaded: my_helper
INFO - 2018-08-14 13:08:11 --> Database Driver Class Initialized
INFO - 2018-08-14 13:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:08:11 --> Controller Class Initialized
INFO - 2018-08-14 13:08:12 --> Config Class Initialized
INFO - 2018-08-14 13:08:12 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:08:12 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:08:12 --> Utf8 Class Initialized
INFO - 2018-08-14 13:08:12 --> URI Class Initialized
INFO - 2018-08-14 13:08:12 --> Router Class Initialized
INFO - 2018-08-14 13:08:12 --> Output Class Initialized
INFO - 2018-08-14 13:08:12 --> Security Class Initialized
DEBUG - 2018-08-14 13:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:08:12 --> Input Class Initialized
INFO - 2018-08-14 13:08:12 --> Language Class Initialized
INFO - 2018-08-14 13:08:12 --> Language Class Initialized
INFO - 2018-08-14 13:08:12 --> Config Class Initialized
INFO - 2018-08-14 13:08:12 --> Loader Class Initialized
INFO - 2018-08-14 13:08:12 --> Helper loaded: url_helper
INFO - 2018-08-14 13:08:12 --> Helper loaded: file_helper
INFO - 2018-08-14 13:08:12 --> Helper loaded: form_helper
INFO - 2018-08-14 13:08:13 --> Helper loaded: my_helper
INFO - 2018-08-14 13:08:13 --> Database Driver Class Initialized
INFO - 2018-08-14 13:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:08:13 --> Controller Class Initialized
INFO - 2018-08-14 13:09:33 --> Config Class Initialized
INFO - 2018-08-14 13:09:33 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:09:33 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:09:34 --> Utf8 Class Initialized
INFO - 2018-08-14 13:09:34 --> URI Class Initialized
INFO - 2018-08-14 13:09:34 --> Router Class Initialized
INFO - 2018-08-14 13:09:34 --> Output Class Initialized
INFO - 2018-08-14 13:09:34 --> Security Class Initialized
DEBUG - 2018-08-14 13:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:09:34 --> Input Class Initialized
INFO - 2018-08-14 13:09:34 --> Language Class Initialized
INFO - 2018-08-14 13:09:34 --> Language Class Initialized
INFO - 2018-08-14 13:09:34 --> Config Class Initialized
INFO - 2018-08-14 13:09:34 --> Loader Class Initialized
INFO - 2018-08-14 13:09:34 --> Helper loaded: url_helper
INFO - 2018-08-14 13:09:34 --> Helper loaded: file_helper
INFO - 2018-08-14 13:09:34 --> Helper loaded: form_helper
INFO - 2018-08-14 13:09:34 --> Helper loaded: my_helper
INFO - 2018-08-14 13:09:34 --> Database Driver Class Initialized
INFO - 2018-08-14 13:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:09:34 --> Controller Class Initialized
INFO - 2018-08-14 13:10:59 --> Config Class Initialized
INFO - 2018-08-14 13:10:59 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:10:59 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:10:59 --> Utf8 Class Initialized
INFO - 2018-08-14 13:10:59 --> URI Class Initialized
INFO - 2018-08-14 13:10:59 --> Router Class Initialized
INFO - 2018-08-14 13:10:59 --> Output Class Initialized
INFO - 2018-08-14 13:10:59 --> Security Class Initialized
DEBUG - 2018-08-14 13:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:10:59 --> Input Class Initialized
INFO - 2018-08-14 13:10:59 --> Language Class Initialized
INFO - 2018-08-14 13:10:59 --> Language Class Initialized
INFO - 2018-08-14 13:10:59 --> Config Class Initialized
INFO - 2018-08-14 13:10:59 --> Loader Class Initialized
INFO - 2018-08-14 13:10:59 --> Helper loaded: url_helper
INFO - 2018-08-14 13:10:59 --> Helper loaded: file_helper
INFO - 2018-08-14 13:10:59 --> Helper loaded: form_helper
INFO - 2018-08-14 13:10:59 --> Helper loaded: my_helper
INFO - 2018-08-14 13:10:59 --> Database Driver Class Initialized
INFO - 2018-08-14 13:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:10:59 --> Controller Class Initialized
INFO - 2018-08-14 13:11:00 --> Config Class Initialized
INFO - 2018-08-14 13:11:00 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:11:00 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:11:00 --> Utf8 Class Initialized
INFO - 2018-08-14 13:11:00 --> URI Class Initialized
INFO - 2018-08-14 13:11:00 --> Router Class Initialized
INFO - 2018-08-14 13:11:00 --> Output Class Initialized
INFO - 2018-08-14 13:11:00 --> Security Class Initialized
DEBUG - 2018-08-14 13:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:11:00 --> Input Class Initialized
INFO - 2018-08-14 13:11:01 --> Language Class Initialized
INFO - 2018-08-14 13:11:01 --> Language Class Initialized
INFO - 2018-08-14 13:11:01 --> Config Class Initialized
INFO - 2018-08-14 13:11:01 --> Loader Class Initialized
INFO - 2018-08-14 13:11:01 --> Helper loaded: url_helper
INFO - 2018-08-14 13:11:01 --> Helper loaded: file_helper
INFO - 2018-08-14 13:11:01 --> Helper loaded: form_helper
INFO - 2018-08-14 13:11:01 --> Helper loaded: my_helper
INFO - 2018-08-14 13:11:01 --> Database Driver Class Initialized
INFO - 2018-08-14 13:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:11:01 --> Controller Class Initialized
INFO - 2018-08-14 13:11:20 --> Config Class Initialized
INFO - 2018-08-14 13:11:20 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:11:20 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:11:20 --> Utf8 Class Initialized
INFO - 2018-08-14 13:11:20 --> URI Class Initialized
INFO - 2018-08-14 13:11:20 --> Router Class Initialized
INFO - 2018-08-14 13:11:20 --> Output Class Initialized
INFO - 2018-08-14 13:11:20 --> Security Class Initialized
DEBUG - 2018-08-14 13:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:11:20 --> Input Class Initialized
INFO - 2018-08-14 13:11:20 --> Language Class Initialized
INFO - 2018-08-14 13:11:20 --> Language Class Initialized
INFO - 2018-08-14 13:11:20 --> Config Class Initialized
INFO - 2018-08-14 13:11:20 --> Loader Class Initialized
INFO - 2018-08-14 13:11:20 --> Helper loaded: url_helper
INFO - 2018-08-14 13:11:20 --> Helper loaded: file_helper
INFO - 2018-08-14 13:11:20 --> Helper loaded: form_helper
INFO - 2018-08-14 13:11:20 --> Helper loaded: my_helper
INFO - 2018-08-14 13:11:20 --> Database Driver Class Initialized
INFO - 2018-08-14 13:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:11:20 --> Controller Class Initialized
INFO - 2018-08-14 13:11:23 --> Config Class Initialized
INFO - 2018-08-14 13:11:23 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:11:23 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:11:23 --> Utf8 Class Initialized
INFO - 2018-08-14 13:11:23 --> URI Class Initialized
INFO - 2018-08-14 13:11:23 --> Router Class Initialized
INFO - 2018-08-14 13:11:23 --> Output Class Initialized
INFO - 2018-08-14 13:11:23 --> Security Class Initialized
DEBUG - 2018-08-14 13:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:11:23 --> Input Class Initialized
INFO - 2018-08-14 13:11:23 --> Language Class Initialized
INFO - 2018-08-14 13:11:23 --> Language Class Initialized
INFO - 2018-08-14 13:11:23 --> Config Class Initialized
INFO - 2018-08-14 13:11:23 --> Loader Class Initialized
INFO - 2018-08-14 13:11:23 --> Helper loaded: url_helper
INFO - 2018-08-14 13:11:23 --> Helper loaded: file_helper
INFO - 2018-08-14 13:11:23 --> Helper loaded: form_helper
INFO - 2018-08-14 13:11:23 --> Helper loaded: my_helper
INFO - 2018-08-14 13:11:23 --> Database Driver Class Initialized
INFO - 2018-08-14 13:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:11:23 --> Controller Class Initialized
DEBUG - 2018-08-14 13:11:23 --> File loaded: D:\laragon\www\nilai\application\modules/login/views/login.php
DEBUG - 2018-08-14 13:11:23 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:11:23 --> Final output sent to browser
DEBUG - 2018-08-14 13:11:23 --> Total execution time: 0.2294
INFO - 2018-08-14 13:11:24 --> Config Class Initialized
INFO - 2018-08-14 13:11:24 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:11:24 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:11:24 --> Utf8 Class Initialized
INFO - 2018-08-14 13:11:24 --> URI Class Initialized
INFO - 2018-08-14 13:11:24 --> Router Class Initialized
INFO - 2018-08-14 13:11:24 --> Output Class Initialized
INFO - 2018-08-14 13:11:24 --> Security Class Initialized
DEBUG - 2018-08-14 13:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:11:24 --> Input Class Initialized
INFO - 2018-08-14 13:11:24 --> Language Class Initialized
ERROR - 2018-08-14 13:11:24 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:11:24 --> Config Class Initialized
INFO - 2018-08-14 13:11:24 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:11:24 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:11:24 --> Utf8 Class Initialized
INFO - 2018-08-14 13:11:24 --> URI Class Initialized
INFO - 2018-08-14 13:11:24 --> Router Class Initialized
INFO - 2018-08-14 13:11:24 --> Output Class Initialized
INFO - 2018-08-14 13:11:24 --> Security Class Initialized
DEBUG - 2018-08-14 13:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:11:24 --> Input Class Initialized
INFO - 2018-08-14 13:11:24 --> Language Class Initialized
INFO - 2018-08-14 13:11:24 --> Language Class Initialized
INFO - 2018-08-14 13:11:24 --> Config Class Initialized
INFO - 2018-08-14 13:11:24 --> Loader Class Initialized
INFO - 2018-08-14 13:11:24 --> Helper loaded: url_helper
INFO - 2018-08-14 13:11:24 --> Helper loaded: file_helper
INFO - 2018-08-14 13:11:24 --> Helper loaded: form_helper
INFO - 2018-08-14 13:11:24 --> Helper loaded: my_helper
INFO - 2018-08-14 13:11:24 --> Database Driver Class Initialized
INFO - 2018-08-14 13:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:11:24 --> Controller Class Initialized
DEBUG - 2018-08-14 13:11:24 --> File loaded: D:\laragon\www\nilai\application\modules/login/views/login.php
DEBUG - 2018-08-14 13:11:24 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:11:24 --> Final output sent to browser
DEBUG - 2018-08-14 13:11:24 --> Total execution time: 0.4219
INFO - 2018-08-14 13:11:25 --> Config Class Initialized
INFO - 2018-08-14 13:11:25 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:11:25 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:11:25 --> Utf8 Class Initialized
INFO - 2018-08-14 13:11:25 --> URI Class Initialized
INFO - 2018-08-14 13:11:25 --> Router Class Initialized
INFO - 2018-08-14 13:11:25 --> Output Class Initialized
INFO - 2018-08-14 13:11:25 --> Security Class Initialized
DEBUG - 2018-08-14 13:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:11:25 --> Input Class Initialized
INFO - 2018-08-14 13:11:25 --> Language Class Initialized
ERROR - 2018-08-14 13:11:25 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:11:25 --> Config Class Initialized
INFO - 2018-08-14 13:11:25 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:11:25 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:11:25 --> Utf8 Class Initialized
INFO - 2018-08-14 13:11:25 --> URI Class Initialized
INFO - 2018-08-14 13:11:25 --> Router Class Initialized
INFO - 2018-08-14 13:11:25 --> Output Class Initialized
INFO - 2018-08-14 13:11:25 --> Security Class Initialized
DEBUG - 2018-08-14 13:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:11:25 --> Input Class Initialized
INFO - 2018-08-14 13:11:25 --> Language Class Initialized
INFO - 2018-08-14 13:11:25 --> Language Class Initialized
INFO - 2018-08-14 13:11:25 --> Config Class Initialized
INFO - 2018-08-14 13:11:25 --> Loader Class Initialized
INFO - 2018-08-14 13:11:25 --> Helper loaded: url_helper
INFO - 2018-08-14 13:11:25 --> Helper loaded: file_helper
INFO - 2018-08-14 13:11:25 --> Helper loaded: form_helper
INFO - 2018-08-14 13:11:25 --> Helper loaded: my_helper
INFO - 2018-08-14 13:11:25 --> Database Driver Class Initialized
INFO - 2018-08-14 13:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:11:25 --> Controller Class Initialized
DEBUG - 2018-08-14 13:11:25 --> File loaded: D:\laragon\www\nilai\application\modules/login/views/login.php
DEBUG - 2018-08-14 13:11:25 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:11:25 --> Final output sent to browser
DEBUG - 2018-08-14 13:11:25 --> Total execution time: 0.2482
INFO - 2018-08-14 13:11:25 --> Config Class Initialized
INFO - 2018-08-14 13:11:25 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:11:25 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:11:25 --> Utf8 Class Initialized
INFO - 2018-08-14 13:11:25 --> URI Class Initialized
INFO - 2018-08-14 13:11:25 --> Router Class Initialized
INFO - 2018-08-14 13:11:25 --> Output Class Initialized
INFO - 2018-08-14 13:11:25 --> Security Class Initialized
DEBUG - 2018-08-14 13:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:11:25 --> Input Class Initialized
INFO - 2018-08-14 13:11:25 --> Language Class Initialized
ERROR - 2018-08-14 13:11:25 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:11:28 --> Config Class Initialized
INFO - 2018-08-14 13:11:28 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:11:28 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:11:28 --> Utf8 Class Initialized
INFO - 2018-08-14 13:11:28 --> URI Class Initialized
INFO - 2018-08-14 13:11:28 --> Router Class Initialized
INFO - 2018-08-14 13:11:28 --> Output Class Initialized
INFO - 2018-08-14 13:11:28 --> Security Class Initialized
DEBUG - 2018-08-14 13:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:11:29 --> Input Class Initialized
INFO - 2018-08-14 13:11:29 --> Language Class Initialized
INFO - 2018-08-14 13:11:29 --> Language Class Initialized
INFO - 2018-08-14 13:11:29 --> Config Class Initialized
INFO - 2018-08-14 13:11:29 --> Loader Class Initialized
INFO - 2018-08-14 13:11:29 --> Helper loaded: url_helper
INFO - 2018-08-14 13:11:29 --> Helper loaded: file_helper
INFO - 2018-08-14 13:11:29 --> Helper loaded: form_helper
INFO - 2018-08-14 13:11:29 --> Helper loaded: my_helper
INFO - 2018-08-14 13:11:29 --> Database Driver Class Initialized
INFO - 2018-08-14 13:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:11:29 --> Controller Class Initialized
INFO - 2018-08-14 13:11:29 --> Helper loaded: cookie_helper
INFO - 2018-08-14 13:11:29 --> Final output sent to browser
DEBUG - 2018-08-14 13:11:29 --> Total execution time: 0.2425
INFO - 2018-08-14 13:11:29 --> Config Class Initialized
INFO - 2018-08-14 13:11:29 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:11:29 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:11:29 --> Utf8 Class Initialized
INFO - 2018-08-14 13:11:29 --> URI Class Initialized
INFO - 2018-08-14 13:11:29 --> Router Class Initialized
INFO - 2018-08-14 13:11:29 --> Output Class Initialized
INFO - 2018-08-14 13:11:29 --> Security Class Initialized
DEBUG - 2018-08-14 13:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:11:29 --> Input Class Initialized
INFO - 2018-08-14 13:11:29 --> Language Class Initialized
INFO - 2018-08-14 13:11:29 --> Language Class Initialized
INFO - 2018-08-14 13:11:29 --> Config Class Initialized
INFO - 2018-08-14 13:11:29 --> Loader Class Initialized
INFO - 2018-08-14 13:11:29 --> Helper loaded: url_helper
INFO - 2018-08-14 13:11:29 --> Helper loaded: file_helper
INFO - 2018-08-14 13:11:29 --> Helper loaded: form_helper
INFO - 2018-08-14 13:11:29 --> Helper loaded: my_helper
INFO - 2018-08-14 13:11:29 --> Database Driver Class Initialized
INFO - 2018-08-14 13:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:11:29 --> Controller Class Initialized
INFO - 2018-08-14 13:12:08 --> Config Class Initialized
INFO - 2018-08-14 13:12:08 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:12:08 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:12:08 --> Utf8 Class Initialized
INFO - 2018-08-14 13:12:08 --> URI Class Initialized
INFO - 2018-08-14 13:12:08 --> Router Class Initialized
INFO - 2018-08-14 13:12:08 --> Output Class Initialized
INFO - 2018-08-14 13:12:08 --> Security Class Initialized
DEBUG - 2018-08-14 13:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:12:08 --> Input Class Initialized
INFO - 2018-08-14 13:12:08 --> Language Class Initialized
INFO - 2018-08-14 13:12:08 --> Language Class Initialized
INFO - 2018-08-14 13:12:08 --> Config Class Initialized
INFO - 2018-08-14 13:12:08 --> Loader Class Initialized
INFO - 2018-08-14 13:12:08 --> Helper loaded: url_helper
INFO - 2018-08-14 13:12:08 --> Helper loaded: file_helper
INFO - 2018-08-14 13:12:08 --> Helper loaded: form_helper
INFO - 2018-08-14 13:12:08 --> Helper loaded: my_helper
INFO - 2018-08-14 13:12:08 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:12:08 --> Controller Class Initialized
INFO - 2018-08-14 13:12:21 --> Config Class Initialized
INFO - 2018-08-14 13:12:21 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:12:21 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:12:21 --> Utf8 Class Initialized
INFO - 2018-08-14 13:12:21 --> URI Class Initialized
INFO - 2018-08-14 13:12:21 --> Router Class Initialized
INFO - 2018-08-14 13:12:21 --> Output Class Initialized
INFO - 2018-08-14 13:12:21 --> Security Class Initialized
DEBUG - 2018-08-14 13:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:12:22 --> Input Class Initialized
INFO - 2018-08-14 13:12:22 --> Language Class Initialized
INFO - 2018-08-14 13:12:22 --> Language Class Initialized
INFO - 2018-08-14 13:12:22 --> Config Class Initialized
INFO - 2018-08-14 13:12:22 --> Loader Class Initialized
INFO - 2018-08-14 13:12:22 --> Helper loaded: url_helper
INFO - 2018-08-14 13:12:22 --> Helper loaded: file_helper
INFO - 2018-08-14 13:12:22 --> Helper loaded: form_helper
INFO - 2018-08-14 13:12:22 --> Helper loaded: my_helper
INFO - 2018-08-14 13:12:22 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:12:22 --> Controller Class Initialized
ERROR - 2018-08-14 13:12:22 --> Query error: Expression #1 of ORDER BY clause is not in GROUP BY clause and contains nonaggregated column 'nilai_mts.t_nilai_ket.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: select 
                t_guru_mapel.id_guru, m_guru.nama nmguru, m_mapel.kd_singkat nmmapel, m_kelas.nama nmkelas
                from t_nilai_ket
                inner join t_guru_mapel on t_nilai_ket.id_guru_mapel = t_guru_mapel.id
                inner join m_guru on t_guru_mapel.id_guru = m_guru.id
                inner join m_mapel on t_guru_mapel.id_mapel = m_mapel.id
                inner join m_kelas on t_guru_mapel.id_kelas = m_kelas.id
                where t_guru_mapel.tasm = '20181' 
                group by t_guru_mapel.id_guru, t_guru_mapel.id_mapel, t_guru_mapel.id_kelas
                order by t_nilai_ket.id
INFO - 2018-08-14 13:12:22 --> Language file loaded: language/english/db_lang.php
INFO - 2018-08-14 13:12:29 --> Config Class Initialized
INFO - 2018-08-14 13:12:29 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:12:29 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:12:29 --> Utf8 Class Initialized
INFO - 2018-08-14 13:12:29 --> URI Class Initialized
INFO - 2018-08-14 13:12:29 --> Router Class Initialized
INFO - 2018-08-14 13:12:29 --> Output Class Initialized
INFO - 2018-08-14 13:12:29 --> Security Class Initialized
DEBUG - 2018-08-14 13:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:12:29 --> Input Class Initialized
INFO - 2018-08-14 13:12:29 --> Language Class Initialized
INFO - 2018-08-14 13:12:29 --> Language Class Initialized
INFO - 2018-08-14 13:12:29 --> Config Class Initialized
INFO - 2018-08-14 13:12:29 --> Loader Class Initialized
INFO - 2018-08-14 13:12:29 --> Helper loaded: url_helper
INFO - 2018-08-14 13:12:29 --> Helper loaded: file_helper
INFO - 2018-08-14 13:12:29 --> Helper loaded: form_helper
INFO - 2018-08-14 13:12:29 --> Helper loaded: my_helper
INFO - 2018-08-14 13:12:29 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:12:29 --> Controller Class Initialized
ERROR - 2018-08-14 13:12:29 --> Query error: Expression #1 of ORDER BY clause is not in GROUP BY clause and contains nonaggregated column 'nilai_mts.t_nilai_ket.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: select 
                t_guru_mapel.id_guru, m_guru.nama nmguru, m_mapel.kd_singkat nmmapel, m_kelas.nama nmkelas
                from t_nilai_ket
                inner join t_guru_mapel on t_nilai_ket.id_guru_mapel = t_guru_mapel.id
                inner join m_guru on t_guru_mapel.id_guru = m_guru.id
                inner join m_mapel on t_guru_mapel.id_mapel = m_mapel.id
                inner join m_kelas on t_guru_mapel.id_kelas = m_kelas.id
                where t_guru_mapel.tasm = '20181' 
                group by t_guru_mapel.id_guru, t_guru_mapel.id_mapel, t_guru_mapel.id_kelas
                order by t_nilai_ket.id
INFO - 2018-08-14 13:12:29 --> Language file loaded: language/english/db_lang.php
INFO - 2018-08-14 13:13:16 --> Config Class Initialized
INFO - 2018-08-14 13:13:16 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:13:16 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:13:16 --> Utf8 Class Initialized
INFO - 2018-08-14 13:13:16 --> URI Class Initialized
INFO - 2018-08-14 13:13:16 --> Router Class Initialized
INFO - 2018-08-14 13:13:16 --> Output Class Initialized
INFO - 2018-08-14 13:13:16 --> Security Class Initialized
DEBUG - 2018-08-14 13:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:13:16 --> Input Class Initialized
INFO - 2018-08-14 13:13:16 --> Language Class Initialized
INFO - 2018-08-14 13:13:16 --> Language Class Initialized
INFO - 2018-08-14 13:13:16 --> Config Class Initialized
INFO - 2018-08-14 13:13:16 --> Loader Class Initialized
INFO - 2018-08-14 13:13:16 --> Helper loaded: url_helper
INFO - 2018-08-14 13:13:16 --> Helper loaded: file_helper
INFO - 2018-08-14 13:13:16 --> Helper loaded: form_helper
INFO - 2018-08-14 13:13:16 --> Helper loaded: my_helper
INFO - 2018-08-14 13:13:16 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:13:16 --> Controller Class Initialized
ERROR - 2018-08-14 13:13:16 --> Query error: Expression #1 of ORDER BY clause is not in GROUP BY clause and contains nonaggregated column 'nilai_mts.t_nilai_ket.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: select 
                t_guru_mapel.id_guru, m_guru.nama nmguru, m_mapel.kd_singkat nmmapel, m_kelas.nama nmkelas
                from t_nilai_ket
                inner join t_guru_mapel on t_nilai_ket.id_guru_mapel = t_guru_mapel.id
                inner join m_guru on t_guru_mapel.id_guru = m_guru.id
                inner join m_mapel on t_guru_mapel.id_mapel = m_mapel.id
                inner join m_kelas on t_guru_mapel.id_kelas = m_kelas.id
                where t_guru_mapel.tasm = '20181' 
                group by t_guru_mapel.id_guru, t_guru_mapel.id_mapel, t_guru_mapel.id_kelas
                order by t_nilai_ket.id
INFO - 2018-08-14 13:13:16 --> Language file loaded: language/english/db_lang.php
INFO - 2018-08-14 13:13:17 --> Config Class Initialized
INFO - 2018-08-14 13:13:17 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:13:17 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:13:17 --> Utf8 Class Initialized
INFO - 2018-08-14 13:13:17 --> URI Class Initialized
INFO - 2018-08-14 13:13:17 --> Router Class Initialized
INFO - 2018-08-14 13:13:17 --> Output Class Initialized
INFO - 2018-08-14 13:13:17 --> Security Class Initialized
DEBUG - 2018-08-14 13:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:13:17 --> Input Class Initialized
INFO - 2018-08-14 13:13:17 --> Language Class Initialized
INFO - 2018-08-14 13:13:17 --> Language Class Initialized
INFO - 2018-08-14 13:13:17 --> Config Class Initialized
INFO - 2018-08-14 13:13:17 --> Loader Class Initialized
INFO - 2018-08-14 13:13:17 --> Helper loaded: url_helper
INFO - 2018-08-14 13:13:17 --> Helper loaded: file_helper
INFO - 2018-08-14 13:13:17 --> Helper loaded: form_helper
INFO - 2018-08-14 13:13:17 --> Helper loaded: my_helper
INFO - 2018-08-14 13:13:17 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:13:17 --> Controller Class Initialized
ERROR - 2018-08-14 13:13:17 --> Query error: Expression #1 of ORDER BY clause is not in GROUP BY clause and contains nonaggregated column 'nilai_mts.t_nilai_ket.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: select 
                t_guru_mapel.id_guru, m_guru.nama nmguru, m_mapel.kd_singkat nmmapel, m_kelas.nama nmkelas
                from t_nilai_ket
                inner join t_guru_mapel on t_nilai_ket.id_guru_mapel = t_guru_mapel.id
                inner join m_guru on t_guru_mapel.id_guru = m_guru.id
                inner join m_mapel on t_guru_mapel.id_mapel = m_mapel.id
                inner join m_kelas on t_guru_mapel.id_kelas = m_kelas.id
                where t_guru_mapel.tasm = '20181' 
                group by t_guru_mapel.id_guru, t_guru_mapel.id_mapel, t_guru_mapel.id_kelas
                order by t_nilai_ket.id
INFO - 2018-08-14 13:13:17 --> Language file loaded: language/english/db_lang.php
INFO - 2018-08-14 13:13:55 --> Config Class Initialized
INFO - 2018-08-14 13:13:55 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:13:55 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:13:55 --> Utf8 Class Initialized
INFO - 2018-08-14 13:13:55 --> URI Class Initialized
INFO - 2018-08-14 13:13:55 --> Router Class Initialized
INFO - 2018-08-14 13:13:55 --> Output Class Initialized
INFO - 2018-08-14 13:13:55 --> Security Class Initialized
DEBUG - 2018-08-14 13:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:13:55 --> Input Class Initialized
INFO - 2018-08-14 13:13:55 --> Language Class Initialized
INFO - 2018-08-14 13:13:55 --> Language Class Initialized
INFO - 2018-08-14 13:13:55 --> Config Class Initialized
INFO - 2018-08-14 13:13:55 --> Loader Class Initialized
INFO - 2018-08-14 13:13:55 --> Helper loaded: url_helper
INFO - 2018-08-14 13:13:55 --> Helper loaded: file_helper
INFO - 2018-08-14 13:13:55 --> Helper loaded: form_helper
INFO - 2018-08-14 13:13:55 --> Helper loaded: my_helper
INFO - 2018-08-14 13:13:55 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:13:55 --> Controller Class Initialized
ERROR - 2018-08-14 13:13:56 --> Query error: Unknown column 't_nilai_ket.id' in 'group statement' - Invalid query: select 
                t_guru_mapel.id_guru, m_guru.nama nmguru, m_mapel.kd_singkat nmmapel, m_kelas.nama nmkelas
                from t_nilai
                inner join t_guru_mapel on t_nilai.id_guru_mapel = t_guru_mapel.id
                inner join m_guru on t_guru_mapel.id_guru = m_guru.id
                inner join m_mapel on t_guru_mapel.id_mapel = m_mapel.id
                inner join m_kelas on t_guru_mapel.id_kelas = m_kelas.id
                where t_guru_mapel.tasm = '20181' 
                group by t_guru_mapel.id_guru, t_guru_mapel.id_mapel, t_guru_mapel.id_kelas, t_nilai_ket.id
                order by t_nilai.id
INFO - 2018-08-14 13:13:56 --> Language file loaded: language/english/db_lang.php
INFO - 2018-08-14 13:13:56 --> Config Class Initialized
INFO - 2018-08-14 13:13:56 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:13:56 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:13:56 --> Utf8 Class Initialized
INFO - 2018-08-14 13:13:56 --> URI Class Initialized
INFO - 2018-08-14 13:13:56 --> Router Class Initialized
INFO - 2018-08-14 13:13:56 --> Output Class Initialized
INFO - 2018-08-14 13:13:56 --> Security Class Initialized
DEBUG - 2018-08-14 13:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:13:56 --> Input Class Initialized
INFO - 2018-08-14 13:13:56 --> Language Class Initialized
INFO - 2018-08-14 13:13:56 --> Language Class Initialized
INFO - 2018-08-14 13:13:56 --> Config Class Initialized
INFO - 2018-08-14 13:13:56 --> Loader Class Initialized
INFO - 2018-08-14 13:13:56 --> Helper loaded: url_helper
INFO - 2018-08-14 13:13:57 --> Helper loaded: file_helper
INFO - 2018-08-14 13:13:57 --> Helper loaded: form_helper
INFO - 2018-08-14 13:13:57 --> Helper loaded: my_helper
INFO - 2018-08-14 13:13:57 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:13:57 --> Controller Class Initialized
ERROR - 2018-08-14 13:13:57 --> Query error: Unknown column 't_nilai_ket.id' in 'group statement' - Invalid query: select 
                t_guru_mapel.id_guru, m_guru.nama nmguru, m_mapel.kd_singkat nmmapel, m_kelas.nama nmkelas
                from t_nilai
                inner join t_guru_mapel on t_nilai.id_guru_mapel = t_guru_mapel.id
                inner join m_guru on t_guru_mapel.id_guru = m_guru.id
                inner join m_mapel on t_guru_mapel.id_mapel = m_mapel.id
                inner join m_kelas on t_guru_mapel.id_kelas = m_kelas.id
                where t_guru_mapel.tasm = '20181' 
                group by t_guru_mapel.id_guru, t_guru_mapel.id_mapel, t_guru_mapel.id_kelas, t_nilai_ket.id
                order by t_nilai.id
INFO - 2018-08-14 13:13:57 --> Language file loaded: language/english/db_lang.php
INFO - 2018-08-14 13:13:57 --> Config Class Initialized
INFO - 2018-08-14 13:13:57 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:13:57 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:13:57 --> Utf8 Class Initialized
INFO - 2018-08-14 13:13:57 --> URI Class Initialized
INFO - 2018-08-14 13:13:57 --> Router Class Initialized
INFO - 2018-08-14 13:13:57 --> Output Class Initialized
INFO - 2018-08-14 13:13:57 --> Security Class Initialized
DEBUG - 2018-08-14 13:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:13:57 --> Input Class Initialized
INFO - 2018-08-14 13:13:57 --> Language Class Initialized
INFO - 2018-08-14 13:13:57 --> Language Class Initialized
INFO - 2018-08-14 13:13:57 --> Config Class Initialized
INFO - 2018-08-14 13:13:57 --> Loader Class Initialized
INFO - 2018-08-14 13:13:57 --> Helper loaded: url_helper
INFO - 2018-08-14 13:13:57 --> Helper loaded: file_helper
INFO - 2018-08-14 13:13:57 --> Helper loaded: form_helper
INFO - 2018-08-14 13:13:57 --> Helper loaded: my_helper
INFO - 2018-08-14 13:13:57 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:13:57 --> Controller Class Initialized
ERROR - 2018-08-14 13:13:58 --> Query error: Unknown column 't_nilai_ket.id' in 'group statement' - Invalid query: select 
                t_guru_mapel.id_guru, m_guru.nama nmguru, m_mapel.kd_singkat nmmapel, m_kelas.nama nmkelas
                from t_nilai
                inner join t_guru_mapel on t_nilai.id_guru_mapel = t_guru_mapel.id
                inner join m_guru on t_guru_mapel.id_guru = m_guru.id
                inner join m_mapel on t_guru_mapel.id_mapel = m_mapel.id
                inner join m_kelas on t_guru_mapel.id_kelas = m_kelas.id
                where t_guru_mapel.tasm = '20181' 
                group by t_guru_mapel.id_guru, t_guru_mapel.id_mapel, t_guru_mapel.id_kelas, t_nilai_ket.id
                order by t_nilai.id
INFO - 2018-08-14 13:13:58 --> Language file loaded: language/english/db_lang.php
INFO - 2018-08-14 13:14:04 --> Config Class Initialized
INFO - 2018-08-14 13:14:04 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:14:04 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:14:04 --> Utf8 Class Initialized
INFO - 2018-08-14 13:14:04 --> URI Class Initialized
INFO - 2018-08-14 13:14:04 --> Router Class Initialized
INFO - 2018-08-14 13:14:04 --> Output Class Initialized
INFO - 2018-08-14 13:14:04 --> Security Class Initialized
DEBUG - 2018-08-14 13:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:14:04 --> Input Class Initialized
INFO - 2018-08-14 13:14:04 --> Language Class Initialized
INFO - 2018-08-14 13:14:04 --> Language Class Initialized
INFO - 2018-08-14 13:14:04 --> Config Class Initialized
INFO - 2018-08-14 13:14:04 --> Loader Class Initialized
INFO - 2018-08-14 13:14:04 --> Helper loaded: url_helper
INFO - 2018-08-14 13:14:04 --> Helper loaded: file_helper
INFO - 2018-08-14 13:14:04 --> Helper loaded: form_helper
INFO - 2018-08-14 13:14:04 --> Helper loaded: my_helper
INFO - 2018-08-14 13:14:04 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:14:04 --> Controller Class Initialized
ERROR - 2018-08-14 13:14:04 --> Query error: Expression #1 of ORDER BY clause is not in GROUP BY clause and contains nonaggregated column 'nilai_mts.t_nilai_ket.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: select 
                t_guru_mapel.id_guru, m_guru.nama nmguru, m_mapel.kd_singkat nmmapel, m_kelas.nama nmkelas
                from t_nilai_ket
                inner join t_guru_mapel on t_nilai_ket.id_guru_mapel = t_guru_mapel.id
                inner join m_guru on t_guru_mapel.id_guru = m_guru.id
                inner join m_mapel on t_guru_mapel.id_mapel = m_mapel.id
                inner join m_kelas on t_guru_mapel.id_kelas = m_kelas.id
                where t_guru_mapel.tasm = '20181' 
                group by t_guru_mapel.id_guru, t_guru_mapel.id_mapel, t_guru_mapel.id_kelas
                order by t_nilai_ket.id
INFO - 2018-08-14 13:14:04 --> Language file loaded: language/english/db_lang.php
INFO - 2018-08-14 13:14:10 --> Config Class Initialized
INFO - 2018-08-14 13:14:10 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:14:10 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:14:10 --> Utf8 Class Initialized
INFO - 2018-08-14 13:14:10 --> URI Class Initialized
INFO - 2018-08-14 13:14:10 --> Router Class Initialized
INFO - 2018-08-14 13:14:10 --> Output Class Initialized
INFO - 2018-08-14 13:14:10 --> Security Class Initialized
DEBUG - 2018-08-14 13:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:14:10 --> Input Class Initialized
INFO - 2018-08-14 13:14:10 --> Language Class Initialized
INFO - 2018-08-14 13:14:10 --> Language Class Initialized
INFO - 2018-08-14 13:14:10 --> Config Class Initialized
INFO - 2018-08-14 13:14:10 --> Loader Class Initialized
INFO - 2018-08-14 13:14:10 --> Helper loaded: url_helper
INFO - 2018-08-14 13:14:10 --> Helper loaded: file_helper
INFO - 2018-08-14 13:14:10 --> Helper loaded: form_helper
INFO - 2018-08-14 13:14:10 --> Helper loaded: my_helper
INFO - 2018-08-14 13:14:10 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:14:10 --> Controller Class Initialized
ERROR - 2018-08-14 13:14:10 --> Query error: Expression #1 of ORDER BY clause is not in GROUP BY clause and contains nonaggregated column 'nilai_mts.t_nilai.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: select 
                t_guru_mapel.id_guru, m_guru.nama nmguru, m_mapel.kd_singkat nmmapel, m_kelas.nama nmkelas
                from t_nilai
                inner join t_guru_mapel on t_nilai.id_guru_mapel = t_guru_mapel.id
                inner join m_guru on t_guru_mapel.id_guru = m_guru.id
                inner join m_mapel on t_guru_mapel.id_mapel = m_mapel.id
                inner join m_kelas on t_guru_mapel.id_kelas = m_kelas.id
                where t_guru_mapel.tasm = '20181' 
                group by t_guru_mapel.id_guru, t_guru_mapel.id_mapel, t_guru_mapel.id_kelas
                order by t_nilai.id
INFO - 2018-08-14 13:14:10 --> Language file loaded: language/english/db_lang.php
INFO - 2018-08-14 13:14:24 --> Config Class Initialized
INFO - 2018-08-14 13:14:24 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:14:24 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:14:24 --> Utf8 Class Initialized
INFO - 2018-08-14 13:14:24 --> URI Class Initialized
INFO - 2018-08-14 13:14:24 --> Router Class Initialized
INFO - 2018-08-14 13:14:24 --> Output Class Initialized
INFO - 2018-08-14 13:14:24 --> Security Class Initialized
DEBUG - 2018-08-14 13:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:14:24 --> Input Class Initialized
INFO - 2018-08-14 13:14:24 --> Language Class Initialized
INFO - 2018-08-14 13:14:24 --> Language Class Initialized
INFO - 2018-08-14 13:14:24 --> Config Class Initialized
INFO - 2018-08-14 13:14:24 --> Loader Class Initialized
INFO - 2018-08-14 13:14:24 --> Helper loaded: url_helper
INFO - 2018-08-14 13:14:24 --> Helper loaded: file_helper
INFO - 2018-08-14 13:14:24 --> Helper loaded: form_helper
INFO - 2018-08-14 13:14:24 --> Helper loaded: my_helper
INFO - 2018-08-14 13:14:24 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:14:24 --> Controller Class Initialized
ERROR - 2018-08-14 13:14:24 --> Query error: Unknown column 't_nilai_ket.id' in 'group statement' - Invalid query: select 
                t_guru_mapel.id_guru, m_guru.nama nmguru, m_mapel.kd_singkat nmmapel, m_kelas.nama nmkelas
                from t_nilai
                inner join t_guru_mapel on t_nilai.id_guru_mapel = t_guru_mapel.id
                inner join m_guru on t_guru_mapel.id_guru = m_guru.id
                inner join m_mapel on t_guru_mapel.id_mapel = m_mapel.id
                inner join m_kelas on t_guru_mapel.id_kelas = m_kelas.id
                where t_guru_mapel.tasm = '20181' 
                group by t_guru_mapel.id_guru, t_guru_mapel.id_mapel, t_guru_mapel.id_kelas, t_nilai_ket.id
                order by t_nilai.id
INFO - 2018-08-14 13:14:24 --> Language file loaded: language/english/db_lang.php
INFO - 2018-08-14 13:14:38 --> Config Class Initialized
INFO - 2018-08-14 13:14:38 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:14:38 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:14:38 --> Utf8 Class Initialized
INFO - 2018-08-14 13:14:38 --> URI Class Initialized
INFO - 2018-08-14 13:14:38 --> Router Class Initialized
INFO - 2018-08-14 13:14:38 --> Output Class Initialized
INFO - 2018-08-14 13:14:38 --> Security Class Initialized
DEBUG - 2018-08-14 13:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:14:38 --> Input Class Initialized
INFO - 2018-08-14 13:14:38 --> Language Class Initialized
INFO - 2018-08-14 13:14:38 --> Language Class Initialized
INFO - 2018-08-14 13:14:38 --> Config Class Initialized
INFO - 2018-08-14 13:14:38 --> Loader Class Initialized
INFO - 2018-08-14 13:14:38 --> Helper loaded: url_helper
INFO - 2018-08-14 13:14:38 --> Helper loaded: file_helper
INFO - 2018-08-14 13:14:38 --> Helper loaded: form_helper
INFO - 2018-08-14 13:14:38 --> Helper loaded: my_helper
INFO - 2018-08-14 13:14:38 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:14:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:14:38 --> Controller Class Initialized
ERROR - 2018-08-14 13:14:38 --> Query error: Expression #1 of ORDER BY clause is not in GROUP BY clause and contains nonaggregated column 'nilai_mts.t_nilai.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: select 
                t_guru_mapel.id_guru, m_guru.nama nmguru, m_mapel.kd_singkat nmmapel, m_kelas.nama nmkelas
                from t_nilai
                inner join t_guru_mapel on t_nilai.id_guru_mapel = t_guru_mapel.id
                inner join m_guru on t_guru_mapel.id_guru = m_guru.id
                inner join m_mapel on t_guru_mapel.id_mapel = m_mapel.id
                inner join m_kelas on t_guru_mapel.id_kelas = m_kelas.id
                where t_guru_mapel.tasm = '20181' 
                group by t_guru_mapel.id_guru, t_guru_mapel.id_mapel, t_guru_mapel.id_kelas
                order by t_nilai.id
INFO - 2018-08-14 13:14:38 --> Language file loaded: language/english/db_lang.php
INFO - 2018-08-14 13:14:48 --> Config Class Initialized
INFO - 2018-08-14 13:14:48 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:14:48 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:14:48 --> Utf8 Class Initialized
INFO - 2018-08-14 13:14:48 --> URI Class Initialized
INFO - 2018-08-14 13:14:48 --> Router Class Initialized
INFO - 2018-08-14 13:14:48 --> Output Class Initialized
INFO - 2018-08-14 13:14:48 --> Security Class Initialized
DEBUG - 2018-08-14 13:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:14:48 --> Input Class Initialized
INFO - 2018-08-14 13:14:48 --> Language Class Initialized
INFO - 2018-08-14 13:14:48 --> Language Class Initialized
INFO - 2018-08-14 13:14:48 --> Config Class Initialized
INFO - 2018-08-14 13:14:48 --> Loader Class Initialized
INFO - 2018-08-14 13:14:48 --> Helper loaded: url_helper
INFO - 2018-08-14 13:14:48 --> Helper loaded: file_helper
INFO - 2018-08-14 13:14:48 --> Helper loaded: form_helper
INFO - 2018-08-14 13:14:48 --> Helper loaded: my_helper
INFO - 2018-08-14 13:14:48 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:14:48 --> Controller Class Initialized
DEBUG - 2018-08-14 13:14:48 --> File loaded: D:\laragon\www\nilai\application\modules/home/views/v_home.php
DEBUG - 2018-08-14 13:14:48 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:14:48 --> Final output sent to browser
DEBUG - 2018-08-14 13:14:49 --> Total execution time: 0.3801
INFO - 2018-08-14 13:14:49 --> Config Class Initialized
INFO - 2018-08-14 13:14:49 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:14:49 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:14:49 --> Utf8 Class Initialized
INFO - 2018-08-14 13:14:49 --> URI Class Initialized
INFO - 2018-08-14 13:14:49 --> Router Class Initialized
INFO - 2018-08-14 13:14:49 --> Output Class Initialized
INFO - 2018-08-14 13:14:49 --> Security Class Initialized
DEBUG - 2018-08-14 13:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:14:49 --> Input Class Initialized
INFO - 2018-08-14 13:14:49 --> Language Class Initialized
ERROR - 2018-08-14 13:14:49 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:14:51 --> Config Class Initialized
INFO - 2018-08-14 13:14:51 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:14:51 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:14:51 --> Utf8 Class Initialized
INFO - 2018-08-14 13:14:51 --> URI Class Initialized
INFO - 2018-08-14 13:14:51 --> Router Class Initialized
INFO - 2018-08-14 13:14:51 --> Output Class Initialized
INFO - 2018-08-14 13:14:51 --> Security Class Initialized
DEBUG - 2018-08-14 13:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:14:51 --> Input Class Initialized
INFO - 2018-08-14 13:14:51 --> Language Class Initialized
INFO - 2018-08-14 13:14:51 --> Language Class Initialized
INFO - 2018-08-14 13:14:51 --> Config Class Initialized
INFO - 2018-08-14 13:14:51 --> Loader Class Initialized
INFO - 2018-08-14 13:14:51 --> Helper loaded: url_helper
INFO - 2018-08-14 13:14:51 --> Helper loaded: file_helper
INFO - 2018-08-14 13:14:51 --> Helper loaded: form_helper
INFO - 2018-08-14 13:14:51 --> Helper loaded: my_helper
INFO - 2018-08-14 13:14:51 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:14:52 --> Controller Class Initialized
DEBUG - 2018-08-14 13:14:52 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:14:52 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:14:52 --> Final output sent to browser
DEBUG - 2018-08-14 13:14:52 --> Total execution time: 0.2675
INFO - 2018-08-14 13:14:52 --> Config Class Initialized
INFO - 2018-08-14 13:14:52 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:14:52 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:14:52 --> Utf8 Class Initialized
INFO - 2018-08-14 13:14:52 --> URI Class Initialized
INFO - 2018-08-14 13:14:52 --> Router Class Initialized
INFO - 2018-08-14 13:14:52 --> Output Class Initialized
INFO - 2018-08-14 13:14:52 --> Security Class Initialized
DEBUG - 2018-08-14 13:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:14:52 --> Input Class Initialized
INFO - 2018-08-14 13:14:52 --> Language Class Initialized
ERROR - 2018-08-14 13:14:52 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:14:52 --> Config Class Initialized
INFO - 2018-08-14 13:14:52 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:14:52 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:14:52 --> Utf8 Class Initialized
INFO - 2018-08-14 13:14:52 --> URI Class Initialized
INFO - 2018-08-14 13:14:52 --> Router Class Initialized
INFO - 2018-08-14 13:14:52 --> Output Class Initialized
INFO - 2018-08-14 13:14:52 --> Security Class Initialized
DEBUG - 2018-08-14 13:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:14:52 --> Input Class Initialized
INFO - 2018-08-14 13:14:52 --> Language Class Initialized
INFO - 2018-08-14 13:14:52 --> Language Class Initialized
INFO - 2018-08-14 13:14:52 --> Config Class Initialized
INFO - 2018-08-14 13:14:52 --> Loader Class Initialized
INFO - 2018-08-14 13:14:52 --> Helper loaded: url_helper
INFO - 2018-08-14 13:14:52 --> Helper loaded: file_helper
INFO - 2018-08-14 13:14:52 --> Helper loaded: form_helper
INFO - 2018-08-14 13:14:52 --> Helper loaded: my_helper
INFO - 2018-08-14 13:14:52 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:14:52 --> Controller Class Initialized
INFO - 2018-08-14 13:15:32 --> Config Class Initialized
INFO - 2018-08-14 13:15:32 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:15:32 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:15:32 --> Utf8 Class Initialized
INFO - 2018-08-14 13:15:32 --> URI Class Initialized
INFO - 2018-08-14 13:15:32 --> Router Class Initialized
INFO - 2018-08-14 13:15:32 --> Output Class Initialized
INFO - 2018-08-14 13:15:32 --> Security Class Initialized
DEBUG - 2018-08-14 13:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:15:32 --> Input Class Initialized
INFO - 2018-08-14 13:15:32 --> Language Class Initialized
INFO - 2018-08-14 13:15:32 --> Language Class Initialized
INFO - 2018-08-14 13:15:32 --> Config Class Initialized
INFO - 2018-08-14 13:15:32 --> Loader Class Initialized
INFO - 2018-08-14 13:15:32 --> Helper loaded: url_helper
INFO - 2018-08-14 13:15:32 --> Helper loaded: file_helper
INFO - 2018-08-14 13:15:32 --> Helper loaded: form_helper
INFO - 2018-08-14 13:15:32 --> Helper loaded: my_helper
INFO - 2018-08-14 13:15:32 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:15:33 --> Controller Class Initialized
DEBUG - 2018-08-14 13:15:33 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:15:33 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:15:33 --> Final output sent to browser
DEBUG - 2018-08-14 13:15:33 --> Total execution time: 0.3306
INFO - 2018-08-14 13:15:33 --> Config Class Initialized
INFO - 2018-08-14 13:15:33 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:15:33 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:15:33 --> Utf8 Class Initialized
INFO - 2018-08-14 13:15:33 --> URI Class Initialized
INFO - 2018-08-14 13:15:33 --> Router Class Initialized
INFO - 2018-08-14 13:15:33 --> Output Class Initialized
INFO - 2018-08-14 13:15:33 --> Security Class Initialized
DEBUG - 2018-08-14 13:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:15:33 --> Input Class Initialized
INFO - 2018-08-14 13:15:33 --> Language Class Initialized
ERROR - 2018-08-14 13:15:33 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:15:33 --> Config Class Initialized
INFO - 2018-08-14 13:15:33 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:15:33 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:15:33 --> Utf8 Class Initialized
INFO - 2018-08-14 13:15:33 --> URI Class Initialized
INFO - 2018-08-14 13:15:33 --> Router Class Initialized
INFO - 2018-08-14 13:15:33 --> Output Class Initialized
INFO - 2018-08-14 13:15:33 --> Security Class Initialized
DEBUG - 2018-08-14 13:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:15:33 --> Input Class Initialized
INFO - 2018-08-14 13:15:33 --> Language Class Initialized
INFO - 2018-08-14 13:15:33 --> Language Class Initialized
INFO - 2018-08-14 13:15:33 --> Config Class Initialized
INFO - 2018-08-14 13:15:33 --> Loader Class Initialized
INFO - 2018-08-14 13:15:33 --> Helper loaded: url_helper
INFO - 2018-08-14 13:15:33 --> Helper loaded: file_helper
INFO - 2018-08-14 13:15:33 --> Helper loaded: form_helper
INFO - 2018-08-14 13:15:33 --> Helper loaded: my_helper
INFO - 2018-08-14 13:15:33 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:15:33 --> Controller Class Initialized
INFO - 2018-08-14 13:15:56 --> Config Class Initialized
INFO - 2018-08-14 13:15:56 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:15:56 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:15:56 --> Utf8 Class Initialized
INFO - 2018-08-14 13:15:56 --> URI Class Initialized
INFO - 2018-08-14 13:15:56 --> Router Class Initialized
INFO - 2018-08-14 13:15:56 --> Output Class Initialized
INFO - 2018-08-14 13:15:56 --> Security Class Initialized
DEBUG - 2018-08-14 13:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:15:56 --> Input Class Initialized
INFO - 2018-08-14 13:15:56 --> Language Class Initialized
INFO - 2018-08-14 13:15:56 --> Language Class Initialized
INFO - 2018-08-14 13:15:56 --> Config Class Initialized
INFO - 2018-08-14 13:15:56 --> Loader Class Initialized
INFO - 2018-08-14 13:15:56 --> Helper loaded: url_helper
INFO - 2018-08-14 13:15:56 --> Helper loaded: file_helper
INFO - 2018-08-14 13:15:56 --> Helper loaded: form_helper
INFO - 2018-08-14 13:15:56 --> Helper loaded: my_helper
INFO - 2018-08-14 13:15:56 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:15:56 --> Controller Class Initialized
DEBUG - 2018-08-14 13:15:56 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:15:57 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:15:57 --> Final output sent to browser
DEBUG - 2018-08-14 13:15:57 --> Total execution time: 0.2975
INFO - 2018-08-14 13:15:57 --> Config Class Initialized
INFO - 2018-08-14 13:15:57 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:15:57 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:15:57 --> Utf8 Class Initialized
INFO - 2018-08-14 13:15:57 --> URI Class Initialized
INFO - 2018-08-14 13:15:57 --> Router Class Initialized
INFO - 2018-08-14 13:15:57 --> Output Class Initialized
INFO - 2018-08-14 13:15:57 --> Security Class Initialized
DEBUG - 2018-08-14 13:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:15:57 --> Input Class Initialized
INFO - 2018-08-14 13:15:57 --> Language Class Initialized
ERROR - 2018-08-14 13:15:57 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:15:57 --> Config Class Initialized
INFO - 2018-08-14 13:15:57 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:15:57 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:15:57 --> Utf8 Class Initialized
INFO - 2018-08-14 13:15:57 --> URI Class Initialized
INFO - 2018-08-14 13:15:57 --> Router Class Initialized
INFO - 2018-08-14 13:15:57 --> Output Class Initialized
INFO - 2018-08-14 13:15:57 --> Security Class Initialized
DEBUG - 2018-08-14 13:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:15:57 --> Input Class Initialized
INFO - 2018-08-14 13:15:57 --> Language Class Initialized
INFO - 2018-08-14 13:15:57 --> Language Class Initialized
INFO - 2018-08-14 13:15:57 --> Config Class Initialized
INFO - 2018-08-14 13:15:57 --> Loader Class Initialized
INFO - 2018-08-14 13:15:57 --> Helper loaded: url_helper
INFO - 2018-08-14 13:15:57 --> Helper loaded: file_helper
INFO - 2018-08-14 13:15:57 --> Helper loaded: form_helper
INFO - 2018-08-14 13:15:57 --> Helper loaded: my_helper
INFO - 2018-08-14 13:15:57 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:15:57 --> Controller Class Initialized
INFO - 2018-08-14 13:16:08 --> Config Class Initialized
INFO - 2018-08-14 13:16:08 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:16:08 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:16:08 --> Utf8 Class Initialized
INFO - 2018-08-14 13:16:08 --> URI Class Initialized
INFO - 2018-08-14 13:16:08 --> Router Class Initialized
INFO - 2018-08-14 13:16:08 --> Output Class Initialized
INFO - 2018-08-14 13:16:08 --> Security Class Initialized
DEBUG - 2018-08-14 13:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:16:08 --> Input Class Initialized
INFO - 2018-08-14 13:16:08 --> Language Class Initialized
INFO - 2018-08-14 13:16:08 --> Language Class Initialized
INFO - 2018-08-14 13:16:08 --> Config Class Initialized
INFO - 2018-08-14 13:16:08 --> Loader Class Initialized
INFO - 2018-08-14 13:16:08 --> Helper loaded: url_helper
INFO - 2018-08-14 13:16:08 --> Helper loaded: file_helper
INFO - 2018-08-14 13:16:08 --> Helper loaded: form_helper
INFO - 2018-08-14 13:16:08 --> Helper loaded: my_helper
INFO - 2018-08-14 13:16:08 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:16:08 --> Controller Class Initialized
DEBUG - 2018-08-14 13:16:08 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:16:08 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:16:08 --> Final output sent to browser
DEBUG - 2018-08-14 13:16:08 --> Total execution time: 0.2764
INFO - 2018-08-14 13:16:08 --> Config Class Initialized
INFO - 2018-08-14 13:16:08 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:16:08 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:16:08 --> Utf8 Class Initialized
INFO - 2018-08-14 13:16:08 --> URI Class Initialized
INFO - 2018-08-14 13:16:08 --> Router Class Initialized
INFO - 2018-08-14 13:16:08 --> Output Class Initialized
INFO - 2018-08-14 13:16:08 --> Security Class Initialized
DEBUG - 2018-08-14 13:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:16:08 --> Input Class Initialized
INFO - 2018-08-14 13:16:08 --> Language Class Initialized
ERROR - 2018-08-14 13:16:08 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:16:08 --> Config Class Initialized
INFO - 2018-08-14 13:16:08 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:16:08 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:16:08 --> Utf8 Class Initialized
INFO - 2018-08-14 13:16:08 --> URI Class Initialized
INFO - 2018-08-14 13:16:08 --> Router Class Initialized
INFO - 2018-08-14 13:16:08 --> Output Class Initialized
INFO - 2018-08-14 13:16:08 --> Security Class Initialized
DEBUG - 2018-08-14 13:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:16:08 --> Input Class Initialized
INFO - 2018-08-14 13:16:08 --> Language Class Initialized
INFO - 2018-08-14 13:16:08 --> Language Class Initialized
INFO - 2018-08-14 13:16:08 --> Config Class Initialized
INFO - 2018-08-14 13:16:08 --> Loader Class Initialized
INFO - 2018-08-14 13:16:08 --> Helper loaded: url_helper
INFO - 2018-08-14 13:16:08 --> Helper loaded: file_helper
INFO - 2018-08-14 13:16:08 --> Helper loaded: form_helper
INFO - 2018-08-14 13:16:08 --> Helper loaded: my_helper
INFO - 2018-08-14 13:16:08 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:16:08 --> Controller Class Initialized
INFO - 2018-08-14 13:17:45 --> Config Class Initialized
INFO - 2018-08-14 13:17:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:17:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:17:45 --> Utf8 Class Initialized
INFO - 2018-08-14 13:17:45 --> URI Class Initialized
INFO - 2018-08-14 13:17:45 --> Router Class Initialized
INFO - 2018-08-14 13:17:45 --> Output Class Initialized
INFO - 2018-08-14 13:17:45 --> Security Class Initialized
DEBUG - 2018-08-14 13:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:17:45 --> Input Class Initialized
INFO - 2018-08-14 13:17:45 --> Language Class Initialized
INFO - 2018-08-14 13:17:45 --> Language Class Initialized
INFO - 2018-08-14 13:17:45 --> Config Class Initialized
INFO - 2018-08-14 13:17:45 --> Loader Class Initialized
INFO - 2018-08-14 13:17:45 --> Helper loaded: url_helper
INFO - 2018-08-14 13:17:45 --> Helper loaded: file_helper
INFO - 2018-08-14 13:17:45 --> Helper loaded: form_helper
INFO - 2018-08-14 13:17:45 --> Helper loaded: my_helper
INFO - 2018-08-14 13:17:45 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:17:45 --> Controller Class Initialized
DEBUG - 2018-08-14 13:17:45 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:17:45 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:17:45 --> Final output sent to browser
DEBUG - 2018-08-14 13:17:45 --> Total execution time: 0.4235
INFO - 2018-08-14 13:17:45 --> Config Class Initialized
INFO - 2018-08-14 13:17:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:17:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:17:45 --> Utf8 Class Initialized
INFO - 2018-08-14 13:17:45 --> URI Class Initialized
INFO - 2018-08-14 13:17:45 --> Router Class Initialized
INFO - 2018-08-14 13:17:45 --> Output Class Initialized
INFO - 2018-08-14 13:17:45 --> Security Class Initialized
DEBUG - 2018-08-14 13:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:17:45 --> Input Class Initialized
INFO - 2018-08-14 13:17:45 --> Language Class Initialized
ERROR - 2018-08-14 13:17:45 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:17:45 --> Config Class Initialized
INFO - 2018-08-14 13:17:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:17:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:17:45 --> Utf8 Class Initialized
INFO - 2018-08-14 13:17:45 --> URI Class Initialized
INFO - 2018-08-14 13:17:45 --> Router Class Initialized
INFO - 2018-08-14 13:17:45 --> Output Class Initialized
INFO - 2018-08-14 13:17:45 --> Security Class Initialized
DEBUG - 2018-08-14 13:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:17:45 --> Input Class Initialized
INFO - 2018-08-14 13:17:45 --> Language Class Initialized
INFO - 2018-08-14 13:17:45 --> Language Class Initialized
INFO - 2018-08-14 13:17:45 --> Config Class Initialized
INFO - 2018-08-14 13:17:46 --> Loader Class Initialized
INFO - 2018-08-14 13:17:46 --> Helper loaded: url_helper
INFO - 2018-08-14 13:17:46 --> Helper loaded: file_helper
INFO - 2018-08-14 13:17:46 --> Helper loaded: form_helper
INFO - 2018-08-14 13:17:46 --> Helper loaded: my_helper
INFO - 2018-08-14 13:17:46 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:17:46 --> Controller Class Initialized
INFO - 2018-08-14 13:18:41 --> Config Class Initialized
INFO - 2018-08-14 13:18:41 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:18:41 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:18:41 --> Utf8 Class Initialized
INFO - 2018-08-14 13:18:41 --> URI Class Initialized
INFO - 2018-08-14 13:18:41 --> Router Class Initialized
INFO - 2018-08-14 13:18:41 --> Output Class Initialized
INFO - 2018-08-14 13:18:41 --> Security Class Initialized
DEBUG - 2018-08-14 13:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:18:41 --> Input Class Initialized
INFO - 2018-08-14 13:18:41 --> Language Class Initialized
INFO - 2018-08-14 13:18:41 --> Language Class Initialized
INFO - 2018-08-14 13:18:42 --> Config Class Initialized
INFO - 2018-08-14 13:18:42 --> Loader Class Initialized
INFO - 2018-08-14 13:18:42 --> Helper loaded: url_helper
INFO - 2018-08-14 13:18:42 --> Helper loaded: file_helper
INFO - 2018-08-14 13:18:42 --> Helper loaded: form_helper
INFO - 2018-08-14 13:18:42 --> Helper loaded: my_helper
INFO - 2018-08-14 13:18:42 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:18:42 --> Controller Class Initialized
DEBUG - 2018-08-14 13:18:42 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:18:42 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:18:42 --> Final output sent to browser
DEBUG - 2018-08-14 13:18:42 --> Total execution time: 0.4073
INFO - 2018-08-14 13:18:42 --> Config Class Initialized
INFO - 2018-08-14 13:18:42 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:18:42 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:18:42 --> Utf8 Class Initialized
INFO - 2018-08-14 13:18:42 --> URI Class Initialized
INFO - 2018-08-14 13:18:42 --> Router Class Initialized
INFO - 2018-08-14 13:18:42 --> Output Class Initialized
INFO - 2018-08-14 13:18:42 --> Security Class Initialized
DEBUG - 2018-08-14 13:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:18:42 --> Input Class Initialized
INFO - 2018-08-14 13:18:42 --> Language Class Initialized
ERROR - 2018-08-14 13:18:42 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:18:42 --> Config Class Initialized
INFO - 2018-08-14 13:18:42 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:18:42 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:18:42 --> Utf8 Class Initialized
INFO - 2018-08-14 13:18:42 --> URI Class Initialized
INFO - 2018-08-14 13:18:42 --> Router Class Initialized
INFO - 2018-08-14 13:18:42 --> Output Class Initialized
INFO - 2018-08-14 13:18:42 --> Security Class Initialized
DEBUG - 2018-08-14 13:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:18:42 --> Input Class Initialized
INFO - 2018-08-14 13:18:42 --> Language Class Initialized
INFO - 2018-08-14 13:18:42 --> Language Class Initialized
INFO - 2018-08-14 13:18:42 --> Config Class Initialized
INFO - 2018-08-14 13:18:42 --> Loader Class Initialized
INFO - 2018-08-14 13:18:42 --> Helper loaded: url_helper
INFO - 2018-08-14 13:18:42 --> Helper loaded: file_helper
INFO - 2018-08-14 13:18:42 --> Helper loaded: form_helper
INFO - 2018-08-14 13:18:42 --> Helper loaded: my_helper
INFO - 2018-08-14 13:18:42 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:18:42 --> Controller Class Initialized
INFO - 2018-08-14 13:19:27 --> Config Class Initialized
INFO - 2018-08-14 13:19:28 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:19:28 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:19:28 --> Utf8 Class Initialized
INFO - 2018-08-14 13:19:28 --> URI Class Initialized
INFO - 2018-08-14 13:19:28 --> Router Class Initialized
INFO - 2018-08-14 13:19:28 --> Output Class Initialized
INFO - 2018-08-14 13:19:28 --> Security Class Initialized
DEBUG - 2018-08-14 13:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:19:28 --> Input Class Initialized
INFO - 2018-08-14 13:19:28 --> Language Class Initialized
INFO - 2018-08-14 13:19:28 --> Language Class Initialized
INFO - 2018-08-14 13:19:28 --> Config Class Initialized
INFO - 2018-08-14 13:19:28 --> Loader Class Initialized
INFO - 2018-08-14 13:19:28 --> Helper loaded: url_helper
INFO - 2018-08-14 13:19:28 --> Helper loaded: file_helper
INFO - 2018-08-14 13:19:28 --> Helper loaded: form_helper
INFO - 2018-08-14 13:19:28 --> Helper loaded: my_helper
INFO - 2018-08-14 13:19:28 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:19:28 --> Controller Class Initialized
DEBUG - 2018-08-14 13:19:28 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:19:28 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:19:28 --> Final output sent to browser
DEBUG - 2018-08-14 13:19:28 --> Total execution time: 0.2853
INFO - 2018-08-14 13:19:28 --> Config Class Initialized
INFO - 2018-08-14 13:19:28 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:19:28 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:19:28 --> Utf8 Class Initialized
INFO - 2018-08-14 13:19:28 --> URI Class Initialized
INFO - 2018-08-14 13:19:28 --> Router Class Initialized
INFO - 2018-08-14 13:19:28 --> Output Class Initialized
INFO - 2018-08-14 13:19:28 --> Security Class Initialized
DEBUG - 2018-08-14 13:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:19:28 --> Input Class Initialized
INFO - 2018-08-14 13:19:28 --> Language Class Initialized
ERROR - 2018-08-14 13:19:28 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:19:28 --> Config Class Initialized
INFO - 2018-08-14 13:19:28 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:19:28 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:19:28 --> Utf8 Class Initialized
INFO - 2018-08-14 13:19:28 --> URI Class Initialized
INFO - 2018-08-14 13:19:28 --> Router Class Initialized
INFO - 2018-08-14 13:19:28 --> Output Class Initialized
INFO - 2018-08-14 13:19:28 --> Security Class Initialized
DEBUG - 2018-08-14 13:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:19:28 --> Input Class Initialized
INFO - 2018-08-14 13:19:28 --> Language Class Initialized
INFO - 2018-08-14 13:19:28 --> Language Class Initialized
INFO - 2018-08-14 13:19:28 --> Config Class Initialized
INFO - 2018-08-14 13:19:28 --> Loader Class Initialized
INFO - 2018-08-14 13:19:28 --> Helper loaded: url_helper
INFO - 2018-08-14 13:19:28 --> Helper loaded: file_helper
INFO - 2018-08-14 13:19:28 --> Helper loaded: form_helper
INFO - 2018-08-14 13:19:28 --> Helper loaded: my_helper
INFO - 2018-08-14 13:19:28 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:19:28 --> Controller Class Initialized
INFO - 2018-08-14 13:20:13 --> Config Class Initialized
INFO - 2018-08-14 13:20:13 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:20:13 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:20:13 --> Utf8 Class Initialized
INFO - 2018-08-14 13:20:13 --> URI Class Initialized
INFO - 2018-08-14 13:20:13 --> Router Class Initialized
INFO - 2018-08-14 13:20:13 --> Output Class Initialized
INFO - 2018-08-14 13:20:13 --> Security Class Initialized
DEBUG - 2018-08-14 13:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:20:13 --> Input Class Initialized
INFO - 2018-08-14 13:20:13 --> Language Class Initialized
INFO - 2018-08-14 13:20:13 --> Language Class Initialized
INFO - 2018-08-14 13:20:13 --> Config Class Initialized
INFO - 2018-08-14 13:20:13 --> Loader Class Initialized
INFO - 2018-08-14 13:20:13 --> Helper loaded: url_helper
INFO - 2018-08-14 13:20:13 --> Helper loaded: file_helper
INFO - 2018-08-14 13:20:13 --> Helper loaded: form_helper
INFO - 2018-08-14 13:20:13 --> Helper loaded: my_helper
INFO - 2018-08-14 13:20:13 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:20:13 --> Controller Class Initialized
DEBUG - 2018-08-14 13:20:13 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:20:13 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:20:13 --> Final output sent to browser
DEBUG - 2018-08-14 13:20:13 --> Total execution time: 0.3212
INFO - 2018-08-14 13:20:13 --> Config Class Initialized
INFO - 2018-08-14 13:20:13 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:20:13 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:20:13 --> Utf8 Class Initialized
INFO - 2018-08-14 13:20:13 --> URI Class Initialized
INFO - 2018-08-14 13:20:13 --> Router Class Initialized
INFO - 2018-08-14 13:20:13 --> Output Class Initialized
INFO - 2018-08-14 13:20:13 --> Security Class Initialized
DEBUG - 2018-08-14 13:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:20:13 --> Input Class Initialized
INFO - 2018-08-14 13:20:13 --> Language Class Initialized
ERROR - 2018-08-14 13:20:13 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:20:13 --> Config Class Initialized
INFO - 2018-08-14 13:20:13 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:20:13 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:20:13 --> Utf8 Class Initialized
INFO - 2018-08-14 13:20:13 --> URI Class Initialized
INFO - 2018-08-14 13:20:13 --> Router Class Initialized
INFO - 2018-08-14 13:20:13 --> Output Class Initialized
INFO - 2018-08-14 13:20:13 --> Security Class Initialized
DEBUG - 2018-08-14 13:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:20:13 --> Input Class Initialized
INFO - 2018-08-14 13:20:13 --> Language Class Initialized
INFO - 2018-08-14 13:20:13 --> Language Class Initialized
INFO - 2018-08-14 13:20:13 --> Config Class Initialized
INFO - 2018-08-14 13:20:13 --> Loader Class Initialized
INFO - 2018-08-14 13:20:13 --> Helper loaded: url_helper
INFO - 2018-08-14 13:20:13 --> Helper loaded: file_helper
INFO - 2018-08-14 13:20:14 --> Helper loaded: form_helper
INFO - 2018-08-14 13:20:14 --> Helper loaded: my_helper
INFO - 2018-08-14 13:20:14 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:20:14 --> Controller Class Initialized
INFO - 2018-08-14 13:20:29 --> Config Class Initialized
INFO - 2018-08-14 13:20:29 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:20:29 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:20:29 --> Utf8 Class Initialized
INFO - 2018-08-14 13:20:29 --> URI Class Initialized
INFO - 2018-08-14 13:20:29 --> Router Class Initialized
INFO - 2018-08-14 13:20:29 --> Output Class Initialized
INFO - 2018-08-14 13:20:29 --> Security Class Initialized
DEBUG - 2018-08-14 13:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:20:29 --> Input Class Initialized
INFO - 2018-08-14 13:20:29 --> Language Class Initialized
INFO - 2018-08-14 13:20:29 --> Language Class Initialized
INFO - 2018-08-14 13:20:29 --> Config Class Initialized
INFO - 2018-08-14 13:20:29 --> Loader Class Initialized
INFO - 2018-08-14 13:20:29 --> Helper loaded: url_helper
INFO - 2018-08-14 13:20:29 --> Helper loaded: file_helper
INFO - 2018-08-14 13:20:29 --> Helper loaded: form_helper
INFO - 2018-08-14 13:20:29 --> Helper loaded: my_helper
INFO - 2018-08-14 13:20:29 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:20:29 --> Controller Class Initialized
DEBUG - 2018-08-14 13:20:29 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:20:29 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:20:29 --> Final output sent to browser
DEBUG - 2018-08-14 13:20:29 --> Total execution time: 0.2940
INFO - 2018-08-14 13:20:30 --> Config Class Initialized
INFO - 2018-08-14 13:20:30 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:20:30 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:20:30 --> Utf8 Class Initialized
INFO - 2018-08-14 13:20:30 --> URI Class Initialized
INFO - 2018-08-14 13:20:30 --> Router Class Initialized
INFO - 2018-08-14 13:20:30 --> Output Class Initialized
INFO - 2018-08-14 13:20:30 --> Security Class Initialized
DEBUG - 2018-08-14 13:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:20:30 --> Input Class Initialized
INFO - 2018-08-14 13:20:30 --> Language Class Initialized
ERROR - 2018-08-14 13:20:30 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:20:30 --> Config Class Initialized
INFO - 2018-08-14 13:20:30 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:20:30 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:20:30 --> Utf8 Class Initialized
INFO - 2018-08-14 13:20:30 --> URI Class Initialized
INFO - 2018-08-14 13:20:30 --> Router Class Initialized
INFO - 2018-08-14 13:20:30 --> Output Class Initialized
INFO - 2018-08-14 13:20:30 --> Security Class Initialized
DEBUG - 2018-08-14 13:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:20:30 --> Input Class Initialized
INFO - 2018-08-14 13:20:30 --> Language Class Initialized
INFO - 2018-08-14 13:20:30 --> Language Class Initialized
INFO - 2018-08-14 13:20:30 --> Config Class Initialized
INFO - 2018-08-14 13:20:30 --> Loader Class Initialized
INFO - 2018-08-14 13:20:30 --> Helper loaded: url_helper
INFO - 2018-08-14 13:20:30 --> Helper loaded: file_helper
INFO - 2018-08-14 13:20:30 --> Helper loaded: form_helper
INFO - 2018-08-14 13:20:30 --> Helper loaded: my_helper
INFO - 2018-08-14 13:20:30 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:20:30 --> Controller Class Initialized
INFO - 2018-08-14 13:20:32 --> Config Class Initialized
INFO - 2018-08-14 13:20:32 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:20:32 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:20:32 --> Utf8 Class Initialized
INFO - 2018-08-14 13:20:32 --> URI Class Initialized
INFO - 2018-08-14 13:20:32 --> Router Class Initialized
INFO - 2018-08-14 13:20:32 --> Output Class Initialized
INFO - 2018-08-14 13:20:32 --> Security Class Initialized
DEBUG - 2018-08-14 13:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:20:32 --> Input Class Initialized
INFO - 2018-08-14 13:20:32 --> Language Class Initialized
INFO - 2018-08-14 13:20:32 --> Language Class Initialized
INFO - 2018-08-14 13:20:32 --> Config Class Initialized
INFO - 2018-08-14 13:20:32 --> Loader Class Initialized
INFO - 2018-08-14 13:20:32 --> Helper loaded: url_helper
INFO - 2018-08-14 13:20:32 --> Helper loaded: file_helper
INFO - 2018-08-14 13:20:32 --> Helper loaded: form_helper
INFO - 2018-08-14 13:20:32 --> Helper loaded: my_helper
INFO - 2018-08-14 13:20:32 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:20:32 --> Controller Class Initialized
INFO - 2018-08-14 13:20:32 --> Final output sent to browser
DEBUG - 2018-08-14 13:20:32 --> Total execution time: 0.2618
INFO - 2018-08-14 13:20:37 --> Config Class Initialized
INFO - 2018-08-14 13:20:37 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:20:37 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:20:37 --> Utf8 Class Initialized
INFO - 2018-08-14 13:20:37 --> URI Class Initialized
INFO - 2018-08-14 13:20:37 --> Router Class Initialized
INFO - 2018-08-14 13:20:37 --> Output Class Initialized
INFO - 2018-08-14 13:20:37 --> Security Class Initialized
DEBUG - 2018-08-14 13:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:20:37 --> Input Class Initialized
INFO - 2018-08-14 13:20:37 --> Language Class Initialized
INFO - 2018-08-14 13:20:37 --> Language Class Initialized
INFO - 2018-08-14 13:20:37 --> Config Class Initialized
INFO - 2018-08-14 13:20:37 --> Loader Class Initialized
INFO - 2018-08-14 13:20:37 --> Helper loaded: url_helper
INFO - 2018-08-14 13:20:37 --> Helper loaded: file_helper
INFO - 2018-08-14 13:20:37 --> Helper loaded: form_helper
INFO - 2018-08-14 13:20:37 --> Helper loaded: my_helper
INFO - 2018-08-14 13:20:37 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:20:37 --> Controller Class Initialized
INFO - 2018-08-14 13:20:37 --> Final output sent to browser
DEBUG - 2018-08-14 13:20:37 --> Total execution time: 0.3027
INFO - 2018-08-14 13:20:39 --> Config Class Initialized
INFO - 2018-08-14 13:20:39 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:20:39 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:20:39 --> Utf8 Class Initialized
INFO - 2018-08-14 13:20:39 --> URI Class Initialized
INFO - 2018-08-14 13:20:39 --> Router Class Initialized
INFO - 2018-08-14 13:20:39 --> Output Class Initialized
INFO - 2018-08-14 13:20:39 --> Security Class Initialized
DEBUG - 2018-08-14 13:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:20:39 --> Input Class Initialized
INFO - 2018-08-14 13:20:39 --> Language Class Initialized
INFO - 2018-08-14 13:20:39 --> Language Class Initialized
INFO - 2018-08-14 13:20:39 --> Config Class Initialized
INFO - 2018-08-14 13:20:39 --> Loader Class Initialized
INFO - 2018-08-14 13:20:39 --> Helper loaded: url_helper
INFO - 2018-08-14 13:20:39 --> Helper loaded: file_helper
INFO - 2018-08-14 13:20:39 --> Helper loaded: form_helper
INFO - 2018-08-14 13:20:39 --> Helper loaded: my_helper
INFO - 2018-08-14 13:20:39 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:20:39 --> Controller Class Initialized
INFO - 2018-08-14 13:20:39 --> Final output sent to browser
DEBUG - 2018-08-14 13:20:39 --> Total execution time: 0.2967
INFO - 2018-08-14 13:20:45 --> Config Class Initialized
INFO - 2018-08-14 13:20:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:20:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:20:45 --> Utf8 Class Initialized
INFO - 2018-08-14 13:20:45 --> URI Class Initialized
INFO - 2018-08-14 13:20:45 --> Router Class Initialized
INFO - 2018-08-14 13:20:45 --> Output Class Initialized
INFO - 2018-08-14 13:20:45 --> Security Class Initialized
DEBUG - 2018-08-14 13:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:20:45 --> Input Class Initialized
INFO - 2018-08-14 13:20:45 --> Language Class Initialized
INFO - 2018-08-14 13:20:45 --> Language Class Initialized
INFO - 2018-08-14 13:20:45 --> Config Class Initialized
INFO - 2018-08-14 13:20:45 --> Loader Class Initialized
INFO - 2018-08-14 13:20:45 --> Helper loaded: url_helper
INFO - 2018-08-14 13:20:45 --> Helper loaded: file_helper
INFO - 2018-08-14 13:20:45 --> Helper loaded: form_helper
INFO - 2018-08-14 13:20:45 --> Helper loaded: my_helper
INFO - 2018-08-14 13:20:45 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:20:45 --> Controller Class Initialized
DEBUG - 2018-08-14 13:20:45 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:20:45 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:20:45 --> Final output sent to browser
DEBUG - 2018-08-14 13:20:45 --> Total execution time: 0.2930
INFO - 2018-08-14 13:20:45 --> Config Class Initialized
INFO - 2018-08-14 13:20:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:20:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:20:45 --> Utf8 Class Initialized
INFO - 2018-08-14 13:20:45 --> URI Class Initialized
INFO - 2018-08-14 13:20:45 --> Router Class Initialized
INFO - 2018-08-14 13:20:45 --> Output Class Initialized
INFO - 2018-08-14 13:20:45 --> Security Class Initialized
DEBUG - 2018-08-14 13:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:20:45 --> Input Class Initialized
INFO - 2018-08-14 13:20:45 --> Language Class Initialized
ERROR - 2018-08-14 13:20:45 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:20:45 --> Config Class Initialized
INFO - 2018-08-14 13:20:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:20:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:20:45 --> Utf8 Class Initialized
INFO - 2018-08-14 13:20:45 --> URI Class Initialized
INFO - 2018-08-14 13:20:45 --> Router Class Initialized
INFO - 2018-08-14 13:20:45 --> Output Class Initialized
INFO - 2018-08-14 13:20:46 --> Security Class Initialized
DEBUG - 2018-08-14 13:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:20:46 --> Input Class Initialized
INFO - 2018-08-14 13:20:46 --> Language Class Initialized
INFO - 2018-08-14 13:20:46 --> Language Class Initialized
INFO - 2018-08-14 13:20:46 --> Config Class Initialized
INFO - 2018-08-14 13:20:46 --> Loader Class Initialized
INFO - 2018-08-14 13:20:46 --> Helper loaded: url_helper
INFO - 2018-08-14 13:20:46 --> Helper loaded: file_helper
INFO - 2018-08-14 13:20:46 --> Helper loaded: form_helper
INFO - 2018-08-14 13:20:46 --> Helper loaded: my_helper
INFO - 2018-08-14 13:20:46 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:20:46 --> Controller Class Initialized
INFO - 2018-08-14 13:20:49 --> Config Class Initialized
INFO - 2018-08-14 13:20:49 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:20:49 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:20:49 --> Utf8 Class Initialized
INFO - 2018-08-14 13:20:49 --> URI Class Initialized
INFO - 2018-08-14 13:20:49 --> Router Class Initialized
INFO - 2018-08-14 13:20:49 --> Output Class Initialized
INFO - 2018-08-14 13:20:49 --> Security Class Initialized
DEBUG - 2018-08-14 13:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:20:49 --> Input Class Initialized
INFO - 2018-08-14 13:20:49 --> Language Class Initialized
INFO - 2018-08-14 13:20:49 --> Language Class Initialized
INFO - 2018-08-14 13:20:49 --> Config Class Initialized
INFO - 2018-08-14 13:20:49 --> Loader Class Initialized
INFO - 2018-08-14 13:20:49 --> Helper loaded: url_helper
INFO - 2018-08-14 13:20:49 --> Helper loaded: file_helper
INFO - 2018-08-14 13:20:49 --> Helper loaded: form_helper
INFO - 2018-08-14 13:20:49 --> Helper loaded: my_helper
INFO - 2018-08-14 13:20:49 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:20:49 --> Controller Class Initialized
ERROR - 2018-08-14 13:20:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 7 - Invalid query: SELECT 
                                        a.*,
                                        (SELECT COUNT(id) FROM m_admin WHERE level = 'guru' AND konid = a.id) AS jml_aktif,
                                        b.username
                                        FROM m_guru a
                                        LEFT JOIN m_admin b ON CONCAT('guru',a.id) = CONCAT(b.level,b.konid) 
                                        WHERE a.nama LIKE '%%' ORDER BY a.nama ASC LIMIT , 
INFO - 2018-08-14 13:20:49 --> Language file loaded: language/english/db_lang.php
INFO - 2018-08-14 13:21:01 --> Config Class Initialized
INFO - 2018-08-14 13:21:01 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:21:01 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:21:01 --> Utf8 Class Initialized
INFO - 2018-08-14 13:21:01 --> URI Class Initialized
INFO - 2018-08-14 13:21:01 --> Router Class Initialized
INFO - 2018-08-14 13:21:01 --> Output Class Initialized
INFO - 2018-08-14 13:21:01 --> Security Class Initialized
DEBUG - 2018-08-14 13:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:21:01 --> Input Class Initialized
INFO - 2018-08-14 13:21:01 --> Language Class Initialized
INFO - 2018-08-14 13:21:01 --> Language Class Initialized
INFO - 2018-08-14 13:21:01 --> Config Class Initialized
INFO - 2018-08-14 13:21:01 --> Loader Class Initialized
INFO - 2018-08-14 13:21:01 --> Helper loaded: url_helper
INFO - 2018-08-14 13:21:01 --> Helper loaded: file_helper
INFO - 2018-08-14 13:21:01 --> Helper loaded: form_helper
INFO - 2018-08-14 13:21:01 --> Helper loaded: my_helper
INFO - 2018-08-14 13:21:01 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:21:01 --> Controller Class Initialized
INFO - 2018-08-14 13:21:19 --> Config Class Initialized
INFO - 2018-08-14 13:21:19 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:21:19 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:21:19 --> Utf8 Class Initialized
INFO - 2018-08-14 13:21:19 --> URI Class Initialized
INFO - 2018-08-14 13:21:19 --> Router Class Initialized
INFO - 2018-08-14 13:21:19 --> Output Class Initialized
INFO - 2018-08-14 13:21:19 --> Security Class Initialized
DEBUG - 2018-08-14 13:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:21:19 --> Input Class Initialized
INFO - 2018-08-14 13:21:19 --> Language Class Initialized
INFO - 2018-08-14 13:21:19 --> Language Class Initialized
INFO - 2018-08-14 13:21:19 --> Config Class Initialized
INFO - 2018-08-14 13:21:19 --> Loader Class Initialized
INFO - 2018-08-14 13:21:19 --> Helper loaded: url_helper
INFO - 2018-08-14 13:21:19 --> Helper loaded: file_helper
INFO - 2018-08-14 13:21:19 --> Helper loaded: form_helper
INFO - 2018-08-14 13:21:19 --> Helper loaded: my_helper
INFO - 2018-08-14 13:21:19 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:21:19 --> Controller Class Initialized
ERROR - 2018-08-14 13:21:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 7 - Invalid query: SELECT 
                                        a.*,
                                        (SELECT COUNT(id) FROM m_admin WHERE level = 'guru' AND konid = a.id) AS jml_aktif,
                                        b.username
                                        FROM m_guru a
                                        LEFT JOIN m_admin b ON CONCAT('guru',a.id) = CONCAT(b.level,b.konid) 
                                        WHERE a.nama LIKE '%%' ORDER BY a.nama ASC LIMIT , 
INFO - 2018-08-14 13:21:19 --> Language file loaded: language/english/db_lang.php
INFO - 2018-08-14 13:21:20 --> Config Class Initialized
INFO - 2018-08-14 13:21:20 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:21:20 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:21:20 --> Utf8 Class Initialized
INFO - 2018-08-14 13:21:20 --> URI Class Initialized
INFO - 2018-08-14 13:21:20 --> Router Class Initialized
INFO - 2018-08-14 13:21:20 --> Output Class Initialized
INFO - 2018-08-14 13:21:20 --> Security Class Initialized
DEBUG - 2018-08-14 13:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:21:21 --> Input Class Initialized
INFO - 2018-08-14 13:21:21 --> Language Class Initialized
INFO - 2018-08-14 13:21:21 --> Language Class Initialized
INFO - 2018-08-14 13:21:21 --> Config Class Initialized
INFO - 2018-08-14 13:21:21 --> Loader Class Initialized
INFO - 2018-08-14 13:21:21 --> Helper loaded: url_helper
INFO - 2018-08-14 13:21:21 --> Helper loaded: file_helper
INFO - 2018-08-14 13:21:21 --> Helper loaded: form_helper
INFO - 2018-08-14 13:21:21 --> Helper loaded: my_helper
INFO - 2018-08-14 13:21:21 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:21:21 --> Controller Class Initialized
DEBUG - 2018-08-14 13:21:21 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:21:21 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:21:21 --> Final output sent to browser
DEBUG - 2018-08-14 13:21:21 --> Total execution time: 0.3296
INFO - 2018-08-14 13:21:21 --> Config Class Initialized
INFO - 2018-08-14 13:21:21 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:21:21 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:21:21 --> Utf8 Class Initialized
INFO - 2018-08-14 13:21:21 --> URI Class Initialized
INFO - 2018-08-14 13:21:21 --> Router Class Initialized
INFO - 2018-08-14 13:21:21 --> Output Class Initialized
INFO - 2018-08-14 13:21:21 --> Security Class Initialized
DEBUG - 2018-08-14 13:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:21:21 --> Input Class Initialized
INFO - 2018-08-14 13:21:21 --> Language Class Initialized
ERROR - 2018-08-14 13:21:21 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:21:21 --> Config Class Initialized
INFO - 2018-08-14 13:21:21 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:21:21 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:21:21 --> Utf8 Class Initialized
INFO - 2018-08-14 13:21:21 --> URI Class Initialized
INFO - 2018-08-14 13:21:21 --> Router Class Initialized
INFO - 2018-08-14 13:21:21 --> Output Class Initialized
INFO - 2018-08-14 13:21:21 --> Security Class Initialized
DEBUG - 2018-08-14 13:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:21:21 --> Input Class Initialized
INFO - 2018-08-14 13:21:21 --> Language Class Initialized
INFO - 2018-08-14 13:21:21 --> Language Class Initialized
INFO - 2018-08-14 13:21:21 --> Config Class Initialized
INFO - 2018-08-14 13:21:21 --> Loader Class Initialized
INFO - 2018-08-14 13:21:21 --> Helper loaded: url_helper
INFO - 2018-08-14 13:21:21 --> Helper loaded: file_helper
INFO - 2018-08-14 13:21:21 --> Helper loaded: form_helper
INFO - 2018-08-14 13:21:21 --> Helper loaded: my_helper
INFO - 2018-08-14 13:21:21 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:21:21 --> Controller Class Initialized
INFO - 2018-08-14 13:21:38 --> Config Class Initialized
INFO - 2018-08-14 13:21:38 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:21:38 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:21:38 --> Utf8 Class Initialized
INFO - 2018-08-14 13:21:38 --> URI Class Initialized
INFO - 2018-08-14 13:21:38 --> Router Class Initialized
INFO - 2018-08-14 13:21:38 --> Output Class Initialized
INFO - 2018-08-14 13:21:38 --> Security Class Initialized
DEBUG - 2018-08-14 13:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:21:38 --> Input Class Initialized
INFO - 2018-08-14 13:21:38 --> Language Class Initialized
INFO - 2018-08-14 13:21:38 --> Language Class Initialized
INFO - 2018-08-14 13:21:38 --> Config Class Initialized
INFO - 2018-08-14 13:21:38 --> Loader Class Initialized
INFO - 2018-08-14 13:21:38 --> Helper loaded: url_helper
INFO - 2018-08-14 13:21:38 --> Helper loaded: file_helper
INFO - 2018-08-14 13:21:38 --> Helper loaded: form_helper
INFO - 2018-08-14 13:21:38 --> Helper loaded: my_helper
INFO - 2018-08-14 13:21:39 --> Database Driver Class Initialized
ERROR - 2018-08-14 13:21:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nilai_mtss' D:\laragon\www\nilai\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2018-08-14 13:21:39 --> Unable to connect to the database
INFO - 2018-08-14 13:21:39 --> Language file loaded: language/english/db_lang.php
INFO - 2018-08-14 13:21:50 --> Config Class Initialized
INFO - 2018-08-14 13:21:50 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:21:50 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:21:50 --> Utf8 Class Initialized
INFO - 2018-08-14 13:21:50 --> URI Class Initialized
INFO - 2018-08-14 13:21:50 --> Router Class Initialized
INFO - 2018-08-14 13:21:50 --> Output Class Initialized
INFO - 2018-08-14 13:21:50 --> Security Class Initialized
DEBUG - 2018-08-14 13:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:21:50 --> Input Class Initialized
INFO - 2018-08-14 13:21:50 --> Language Class Initialized
INFO - 2018-08-14 13:21:50 --> Language Class Initialized
INFO - 2018-08-14 13:21:50 --> Config Class Initialized
INFO - 2018-08-14 13:21:50 --> Loader Class Initialized
INFO - 2018-08-14 13:21:50 --> Helper loaded: url_helper
INFO - 2018-08-14 13:21:50 --> Helper loaded: file_helper
INFO - 2018-08-14 13:21:50 --> Helper loaded: form_helper
INFO - 2018-08-14 13:21:50 --> Helper loaded: my_helper
INFO - 2018-08-14 13:21:50 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:21:50 --> Controller Class Initialized
DEBUG - 2018-08-14 13:21:50 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:21:50 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:21:50 --> Final output sent to browser
DEBUG - 2018-08-14 13:21:50 --> Total execution time: 0.3023
INFO - 2018-08-14 13:21:50 --> Config Class Initialized
INFO - 2018-08-14 13:21:50 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:21:50 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:21:50 --> Utf8 Class Initialized
INFO - 2018-08-14 13:21:50 --> URI Class Initialized
INFO - 2018-08-14 13:21:50 --> Router Class Initialized
INFO - 2018-08-14 13:21:50 --> Output Class Initialized
INFO - 2018-08-14 13:21:50 --> Security Class Initialized
DEBUG - 2018-08-14 13:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:21:50 --> Input Class Initialized
INFO - 2018-08-14 13:21:50 --> Language Class Initialized
ERROR - 2018-08-14 13:21:50 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:21:50 --> Config Class Initialized
INFO - 2018-08-14 13:21:50 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:21:50 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:21:50 --> Utf8 Class Initialized
INFO - 2018-08-14 13:21:50 --> URI Class Initialized
INFO - 2018-08-14 13:21:50 --> Router Class Initialized
INFO - 2018-08-14 13:21:50 --> Output Class Initialized
INFO - 2018-08-14 13:21:50 --> Security Class Initialized
DEBUG - 2018-08-14 13:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:21:50 --> Input Class Initialized
INFO - 2018-08-14 13:21:50 --> Language Class Initialized
INFO - 2018-08-14 13:21:50 --> Language Class Initialized
INFO - 2018-08-14 13:21:50 --> Config Class Initialized
INFO - 2018-08-14 13:21:50 --> Loader Class Initialized
INFO - 2018-08-14 13:21:50 --> Helper loaded: url_helper
INFO - 2018-08-14 13:21:50 --> Helper loaded: file_helper
INFO - 2018-08-14 13:21:50 --> Helper loaded: form_helper
INFO - 2018-08-14 13:21:50 --> Helper loaded: my_helper
INFO - 2018-08-14 13:21:50 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:21:50 --> Controller Class Initialized
INFO - 2018-08-14 13:21:55 --> Config Class Initialized
INFO - 2018-08-14 13:21:55 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:21:55 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:21:55 --> Utf8 Class Initialized
INFO - 2018-08-14 13:21:55 --> URI Class Initialized
INFO - 2018-08-14 13:21:55 --> Router Class Initialized
INFO - 2018-08-14 13:21:55 --> Output Class Initialized
INFO - 2018-08-14 13:21:55 --> Security Class Initialized
DEBUG - 2018-08-14 13:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:21:55 --> Input Class Initialized
INFO - 2018-08-14 13:21:55 --> Language Class Initialized
INFO - 2018-08-14 13:21:55 --> Language Class Initialized
INFO - 2018-08-14 13:21:55 --> Config Class Initialized
INFO - 2018-08-14 13:21:55 --> Loader Class Initialized
INFO - 2018-08-14 13:21:55 --> Helper loaded: url_helper
INFO - 2018-08-14 13:21:55 --> Helper loaded: file_helper
INFO - 2018-08-14 13:21:55 --> Helper loaded: form_helper
INFO - 2018-08-14 13:21:55 --> Helper loaded: my_helper
INFO - 2018-08-14 13:21:55 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:21:55 --> Controller Class Initialized
DEBUG - 2018-08-14 13:21:55 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:21:55 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:21:55 --> Final output sent to browser
DEBUG - 2018-08-14 13:21:55 --> Total execution time: 0.3875
INFO - 2018-08-14 13:21:55 --> Config Class Initialized
INFO - 2018-08-14 13:21:55 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:21:55 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:21:55 --> Utf8 Class Initialized
INFO - 2018-08-14 13:21:56 --> URI Class Initialized
INFO - 2018-08-14 13:21:56 --> Router Class Initialized
INFO - 2018-08-14 13:21:56 --> Output Class Initialized
INFO - 2018-08-14 13:21:56 --> Security Class Initialized
DEBUG - 2018-08-14 13:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:21:56 --> Input Class Initialized
INFO - 2018-08-14 13:21:56 --> Language Class Initialized
ERROR - 2018-08-14 13:21:56 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:21:56 --> Config Class Initialized
INFO - 2018-08-14 13:21:56 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:21:56 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:21:56 --> Utf8 Class Initialized
INFO - 2018-08-14 13:21:56 --> URI Class Initialized
INFO - 2018-08-14 13:21:56 --> Router Class Initialized
INFO - 2018-08-14 13:21:56 --> Output Class Initialized
INFO - 2018-08-14 13:21:56 --> Security Class Initialized
DEBUG - 2018-08-14 13:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:21:56 --> Input Class Initialized
INFO - 2018-08-14 13:21:56 --> Language Class Initialized
INFO - 2018-08-14 13:21:56 --> Language Class Initialized
INFO - 2018-08-14 13:21:56 --> Config Class Initialized
INFO - 2018-08-14 13:21:56 --> Loader Class Initialized
INFO - 2018-08-14 13:21:56 --> Helper loaded: url_helper
INFO - 2018-08-14 13:21:56 --> Helper loaded: file_helper
INFO - 2018-08-14 13:21:56 --> Helper loaded: form_helper
INFO - 2018-08-14 13:21:56 --> Helper loaded: my_helper
INFO - 2018-08-14 13:21:56 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:21:56 --> Controller Class Initialized
INFO - 2018-08-14 13:21:57 --> Config Class Initialized
INFO - 2018-08-14 13:21:57 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:21:57 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:21:57 --> Utf8 Class Initialized
INFO - 2018-08-14 13:21:57 --> URI Class Initialized
INFO - 2018-08-14 13:21:57 --> Router Class Initialized
INFO - 2018-08-14 13:21:57 --> Output Class Initialized
INFO - 2018-08-14 13:21:57 --> Security Class Initialized
DEBUG - 2018-08-14 13:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:21:57 --> Input Class Initialized
INFO - 2018-08-14 13:21:57 --> Language Class Initialized
INFO - 2018-08-14 13:21:57 --> Language Class Initialized
INFO - 2018-08-14 13:21:57 --> Config Class Initialized
INFO - 2018-08-14 13:21:57 --> Loader Class Initialized
INFO - 2018-08-14 13:21:57 --> Helper loaded: url_helper
INFO - 2018-08-14 13:21:57 --> Helper loaded: file_helper
INFO - 2018-08-14 13:21:57 --> Helper loaded: form_helper
INFO - 2018-08-14 13:21:57 --> Helper loaded: my_helper
INFO - 2018-08-14 13:21:57 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:21:57 --> Controller Class Initialized
DEBUG - 2018-08-14 13:21:57 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:21:57 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:21:57 --> Final output sent to browser
DEBUG - 2018-08-14 13:21:57 --> Total execution time: 0.5187
INFO - 2018-08-14 13:21:57 --> Config Class Initialized
INFO - 2018-08-14 13:21:57 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:21:57 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:21:57 --> Utf8 Class Initialized
INFO - 2018-08-14 13:21:58 --> URI Class Initialized
INFO - 2018-08-14 13:21:58 --> Router Class Initialized
INFO - 2018-08-14 13:21:58 --> Output Class Initialized
INFO - 2018-08-14 13:21:58 --> Security Class Initialized
DEBUG - 2018-08-14 13:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:21:58 --> Input Class Initialized
INFO - 2018-08-14 13:21:58 --> Language Class Initialized
ERROR - 2018-08-14 13:21:58 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:21:58 --> Config Class Initialized
INFO - 2018-08-14 13:21:58 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:21:58 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:21:58 --> Utf8 Class Initialized
INFO - 2018-08-14 13:21:58 --> URI Class Initialized
INFO - 2018-08-14 13:21:58 --> Router Class Initialized
INFO - 2018-08-14 13:21:58 --> Output Class Initialized
INFO - 2018-08-14 13:21:58 --> Security Class Initialized
DEBUG - 2018-08-14 13:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:21:58 --> Input Class Initialized
INFO - 2018-08-14 13:21:58 --> Language Class Initialized
INFO - 2018-08-14 13:21:58 --> Language Class Initialized
INFO - 2018-08-14 13:21:58 --> Config Class Initialized
INFO - 2018-08-14 13:21:58 --> Loader Class Initialized
INFO - 2018-08-14 13:21:58 --> Helper loaded: url_helper
INFO - 2018-08-14 13:21:58 --> Helper loaded: file_helper
INFO - 2018-08-14 13:21:58 --> Helper loaded: form_helper
INFO - 2018-08-14 13:21:58 --> Helper loaded: my_helper
INFO - 2018-08-14 13:21:58 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:21:58 --> Controller Class Initialized
INFO - 2018-08-14 13:22:00 --> Config Class Initialized
INFO - 2018-08-14 13:22:00 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:22:00 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:22:00 --> Utf8 Class Initialized
INFO - 2018-08-14 13:22:00 --> URI Class Initialized
INFO - 2018-08-14 13:22:00 --> Router Class Initialized
INFO - 2018-08-14 13:22:00 --> Output Class Initialized
INFO - 2018-08-14 13:22:00 --> Security Class Initialized
DEBUG - 2018-08-14 13:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:22:00 --> Input Class Initialized
INFO - 2018-08-14 13:22:01 --> Language Class Initialized
INFO - 2018-08-14 13:22:01 --> Language Class Initialized
INFO - 2018-08-14 13:22:01 --> Config Class Initialized
INFO - 2018-08-14 13:22:01 --> Loader Class Initialized
INFO - 2018-08-14 13:22:01 --> Helper loaded: url_helper
INFO - 2018-08-14 13:22:01 --> Helper loaded: file_helper
INFO - 2018-08-14 13:22:01 --> Helper loaded: form_helper
INFO - 2018-08-14 13:22:01 --> Helper loaded: my_helper
INFO - 2018-08-14 13:22:01 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:22:01 --> Controller Class Initialized
DEBUG - 2018-08-14 13:22:01 --> File loaded: D:\laragon\www\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2018-08-14 13:22:01 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:22:01 --> Final output sent to browser
DEBUG - 2018-08-14 13:22:01 --> Total execution time: 0.2892
INFO - 2018-08-14 13:22:01 --> Config Class Initialized
INFO - 2018-08-14 13:22:01 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:22:01 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:22:01 --> Utf8 Class Initialized
INFO - 2018-08-14 13:22:01 --> URI Class Initialized
INFO - 2018-08-14 13:22:01 --> Router Class Initialized
INFO - 2018-08-14 13:22:01 --> Output Class Initialized
INFO - 2018-08-14 13:22:01 --> Security Class Initialized
DEBUG - 2018-08-14 13:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:22:01 --> Input Class Initialized
INFO - 2018-08-14 13:22:01 --> Language Class Initialized
ERROR - 2018-08-14 13:22:01 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:22:01 --> Config Class Initialized
INFO - 2018-08-14 13:22:01 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:22:01 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:22:01 --> Utf8 Class Initialized
INFO - 2018-08-14 13:22:01 --> URI Class Initialized
INFO - 2018-08-14 13:22:01 --> Router Class Initialized
INFO - 2018-08-14 13:22:01 --> Output Class Initialized
INFO - 2018-08-14 13:22:01 --> Security Class Initialized
DEBUG - 2018-08-14 13:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:22:01 --> Input Class Initialized
INFO - 2018-08-14 13:22:01 --> Language Class Initialized
INFO - 2018-08-14 13:22:01 --> Language Class Initialized
INFO - 2018-08-14 13:22:01 --> Config Class Initialized
INFO - 2018-08-14 13:22:01 --> Loader Class Initialized
INFO - 2018-08-14 13:22:01 --> Helper loaded: url_helper
INFO - 2018-08-14 13:22:01 --> Helper loaded: file_helper
INFO - 2018-08-14 13:22:01 --> Helper loaded: form_helper
INFO - 2018-08-14 13:22:01 --> Helper loaded: my_helper
INFO - 2018-08-14 13:22:01 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:22:01 --> Controller Class Initialized
INFO - 2018-08-14 13:22:05 --> Config Class Initialized
INFO - 2018-08-14 13:22:05 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:22:05 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:22:05 --> Utf8 Class Initialized
INFO - 2018-08-14 13:22:05 --> URI Class Initialized
INFO - 2018-08-14 13:22:05 --> Router Class Initialized
INFO - 2018-08-14 13:22:05 --> Output Class Initialized
INFO - 2018-08-14 13:22:05 --> Security Class Initialized
DEBUG - 2018-08-14 13:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:22:05 --> Input Class Initialized
INFO - 2018-08-14 13:22:05 --> Language Class Initialized
INFO - 2018-08-14 13:22:05 --> Language Class Initialized
INFO - 2018-08-14 13:22:05 --> Config Class Initialized
INFO - 2018-08-14 13:22:05 --> Loader Class Initialized
INFO - 2018-08-14 13:22:05 --> Helper loaded: url_helper
INFO - 2018-08-14 13:22:05 --> Helper loaded: file_helper
INFO - 2018-08-14 13:22:05 --> Helper loaded: form_helper
INFO - 2018-08-14 13:22:05 --> Helper loaded: my_helper
INFO - 2018-08-14 13:22:05 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:22:06 --> Controller Class Initialized
INFO - 2018-08-14 13:22:06 --> Config Class Initialized
INFO - 2018-08-14 13:22:06 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:22:06 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:22:06 --> Utf8 Class Initialized
INFO - 2018-08-14 13:22:06 --> URI Class Initialized
INFO - 2018-08-14 13:22:06 --> Router Class Initialized
INFO - 2018-08-14 13:22:06 --> Output Class Initialized
INFO - 2018-08-14 13:22:06 --> Security Class Initialized
DEBUG - 2018-08-14 13:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:22:06 --> Input Class Initialized
INFO - 2018-08-14 13:22:06 --> Language Class Initialized
INFO - 2018-08-14 13:22:06 --> Language Class Initialized
INFO - 2018-08-14 13:22:06 --> Config Class Initialized
INFO - 2018-08-14 13:22:06 --> Loader Class Initialized
INFO - 2018-08-14 13:22:06 --> Helper loaded: url_helper
INFO - 2018-08-14 13:22:06 --> Helper loaded: file_helper
INFO - 2018-08-14 13:22:06 --> Helper loaded: form_helper
INFO - 2018-08-14 13:22:06 --> Helper loaded: my_helper
INFO - 2018-08-14 13:22:06 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:22:06 --> Controller Class Initialized
INFO - 2018-08-14 13:22:09 --> Config Class Initialized
INFO - 2018-08-14 13:22:09 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:22:09 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:22:09 --> Utf8 Class Initialized
INFO - 2018-08-14 13:22:09 --> URI Class Initialized
INFO - 2018-08-14 13:22:09 --> Router Class Initialized
INFO - 2018-08-14 13:22:09 --> Output Class Initialized
INFO - 2018-08-14 13:22:09 --> Security Class Initialized
DEBUG - 2018-08-14 13:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:22:09 --> Input Class Initialized
INFO - 2018-08-14 13:22:09 --> Language Class Initialized
INFO - 2018-08-14 13:22:09 --> Language Class Initialized
INFO - 2018-08-14 13:22:09 --> Config Class Initialized
INFO - 2018-08-14 13:22:09 --> Loader Class Initialized
INFO - 2018-08-14 13:22:09 --> Helper loaded: url_helper
INFO - 2018-08-14 13:22:09 --> Helper loaded: file_helper
INFO - 2018-08-14 13:22:09 --> Helper loaded: form_helper
INFO - 2018-08-14 13:22:09 --> Helper loaded: my_helper
INFO - 2018-08-14 13:22:09 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:22:09 --> Controller Class Initialized
INFO - 2018-08-14 13:22:10 --> Config Class Initialized
INFO - 2018-08-14 13:22:10 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:22:10 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:22:10 --> Utf8 Class Initialized
INFO - 2018-08-14 13:22:10 --> URI Class Initialized
INFO - 2018-08-14 13:22:10 --> Router Class Initialized
INFO - 2018-08-14 13:22:10 --> Output Class Initialized
INFO - 2018-08-14 13:22:10 --> Security Class Initialized
DEBUG - 2018-08-14 13:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:22:10 --> Input Class Initialized
INFO - 2018-08-14 13:22:10 --> Language Class Initialized
INFO - 2018-08-14 13:22:10 --> Language Class Initialized
INFO - 2018-08-14 13:22:10 --> Config Class Initialized
INFO - 2018-08-14 13:22:10 --> Loader Class Initialized
INFO - 2018-08-14 13:22:10 --> Helper loaded: url_helper
INFO - 2018-08-14 13:22:10 --> Helper loaded: file_helper
INFO - 2018-08-14 13:22:10 --> Helper loaded: form_helper
INFO - 2018-08-14 13:22:10 --> Helper loaded: my_helper
INFO - 2018-08-14 13:22:10 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:22:10 --> Controller Class Initialized
INFO - 2018-08-14 13:22:12 --> Config Class Initialized
INFO - 2018-08-14 13:22:12 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:22:12 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:22:12 --> Utf8 Class Initialized
INFO - 2018-08-14 13:22:12 --> URI Class Initialized
DEBUG - 2018-08-14 13:22:12 --> No URI present. Default controller set.
INFO - 2018-08-14 13:22:12 --> Router Class Initialized
INFO - 2018-08-14 13:22:12 --> Output Class Initialized
INFO - 2018-08-14 13:22:12 --> Security Class Initialized
DEBUG - 2018-08-14 13:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:22:12 --> Input Class Initialized
INFO - 2018-08-14 13:22:12 --> Language Class Initialized
INFO - 2018-08-14 13:22:12 --> Language Class Initialized
INFO - 2018-08-14 13:22:12 --> Config Class Initialized
INFO - 2018-08-14 13:22:12 --> Loader Class Initialized
INFO - 2018-08-14 13:22:12 --> Helper loaded: url_helper
INFO - 2018-08-14 13:22:12 --> Helper loaded: file_helper
INFO - 2018-08-14 13:22:12 --> Helper loaded: form_helper
INFO - 2018-08-14 13:22:12 --> Helper loaded: my_helper
INFO - 2018-08-14 13:22:12 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:22:12 --> Controller Class Initialized
DEBUG - 2018-08-14 13:22:12 --> File loaded: D:\laragon\www\nilai\application\modules/home/views/v_home.php
DEBUG - 2018-08-14 13:22:12 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:22:12 --> Final output sent to browser
DEBUG - 2018-08-14 13:22:12 --> Total execution time: 0.3734
INFO - 2018-08-14 13:22:12 --> Config Class Initialized
INFO - 2018-08-14 13:22:12 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:22:12 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:22:12 --> Utf8 Class Initialized
INFO - 2018-08-14 13:22:12 --> URI Class Initialized
INFO - 2018-08-14 13:22:12 --> Router Class Initialized
INFO - 2018-08-14 13:22:12 --> Output Class Initialized
INFO - 2018-08-14 13:22:12 --> Security Class Initialized
DEBUG - 2018-08-14 13:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:22:12 --> Input Class Initialized
INFO - 2018-08-14 13:22:12 --> Language Class Initialized
ERROR - 2018-08-14 13:22:12 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:22:14 --> Config Class Initialized
INFO - 2018-08-14 13:22:14 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:22:14 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:22:14 --> Utf8 Class Initialized
INFO - 2018-08-14 13:22:14 --> URI Class Initialized
INFO - 2018-08-14 13:22:14 --> Router Class Initialized
INFO - 2018-08-14 13:22:14 --> Output Class Initialized
INFO - 2018-08-14 13:22:14 --> Security Class Initialized
DEBUG - 2018-08-14 13:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:22:14 --> Input Class Initialized
INFO - 2018-08-14 13:22:14 --> Language Class Initialized
INFO - 2018-08-14 13:22:14 --> Language Class Initialized
INFO - 2018-08-14 13:22:14 --> Config Class Initialized
INFO - 2018-08-14 13:22:14 --> Loader Class Initialized
INFO - 2018-08-14 13:22:14 --> Helper loaded: url_helper
INFO - 2018-08-14 13:22:14 --> Helper loaded: file_helper
INFO - 2018-08-14 13:22:14 --> Helper loaded: form_helper
INFO - 2018-08-14 13:22:14 --> Helper loaded: my_helper
INFO - 2018-08-14 13:22:14 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:22:14 --> Controller Class Initialized
DEBUG - 2018-08-14 13:22:14 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:22:14 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:22:14 --> Final output sent to browser
DEBUG - 2018-08-14 13:22:14 --> Total execution time: 0.3261
INFO - 2018-08-14 13:22:15 --> Config Class Initialized
INFO - 2018-08-14 13:22:15 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:22:15 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:22:15 --> Utf8 Class Initialized
INFO - 2018-08-14 13:22:15 --> URI Class Initialized
INFO - 2018-08-14 13:22:15 --> Router Class Initialized
INFO - 2018-08-14 13:22:15 --> Output Class Initialized
INFO - 2018-08-14 13:22:15 --> Security Class Initialized
DEBUG - 2018-08-14 13:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:22:15 --> Input Class Initialized
INFO - 2018-08-14 13:22:15 --> Language Class Initialized
ERROR - 2018-08-14 13:22:15 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:22:15 --> Config Class Initialized
INFO - 2018-08-14 13:22:15 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:22:15 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:22:15 --> Utf8 Class Initialized
INFO - 2018-08-14 13:22:15 --> URI Class Initialized
INFO - 2018-08-14 13:22:15 --> Router Class Initialized
INFO - 2018-08-14 13:22:15 --> Output Class Initialized
INFO - 2018-08-14 13:22:15 --> Security Class Initialized
DEBUG - 2018-08-14 13:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:22:15 --> Input Class Initialized
INFO - 2018-08-14 13:22:15 --> Language Class Initialized
INFO - 2018-08-14 13:22:15 --> Language Class Initialized
INFO - 2018-08-14 13:22:15 --> Config Class Initialized
INFO - 2018-08-14 13:22:15 --> Loader Class Initialized
INFO - 2018-08-14 13:22:15 --> Helper loaded: url_helper
INFO - 2018-08-14 13:22:15 --> Helper loaded: file_helper
INFO - 2018-08-14 13:22:15 --> Helper loaded: form_helper
INFO - 2018-08-14 13:22:15 --> Helper loaded: my_helper
INFO - 2018-08-14 13:22:15 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:22:15 --> Controller Class Initialized
INFO - 2018-08-14 13:22:24 --> Config Class Initialized
INFO - 2018-08-14 13:22:24 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:22:24 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:22:24 --> Utf8 Class Initialized
INFO - 2018-08-14 13:22:24 --> URI Class Initialized
INFO - 2018-08-14 13:22:24 --> Router Class Initialized
INFO - 2018-08-14 13:22:24 --> Output Class Initialized
INFO - 2018-08-14 13:22:24 --> Security Class Initialized
DEBUG - 2018-08-14 13:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:22:24 --> Input Class Initialized
INFO - 2018-08-14 13:22:24 --> Language Class Initialized
INFO - 2018-08-14 13:22:24 --> Language Class Initialized
INFO - 2018-08-14 13:22:24 --> Config Class Initialized
INFO - 2018-08-14 13:22:24 --> Loader Class Initialized
INFO - 2018-08-14 13:22:24 --> Helper loaded: url_helper
INFO - 2018-08-14 13:22:24 --> Helper loaded: file_helper
INFO - 2018-08-14 13:22:24 --> Helper loaded: form_helper
INFO - 2018-08-14 13:22:24 --> Helper loaded: my_helper
INFO - 2018-08-14 13:22:24 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:22:24 --> Controller Class Initialized
INFO - 2018-08-14 13:22:24 --> Final output sent to browser
DEBUG - 2018-08-14 13:22:24 --> Total execution time: 0.2799
INFO - 2018-08-14 13:22:24 --> Config Class Initialized
INFO - 2018-08-14 13:22:24 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:22:24 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:22:24 --> Utf8 Class Initialized
INFO - 2018-08-14 13:22:25 --> URI Class Initialized
INFO - 2018-08-14 13:22:25 --> Router Class Initialized
INFO - 2018-08-14 13:22:25 --> Output Class Initialized
INFO - 2018-08-14 13:22:25 --> Security Class Initialized
DEBUG - 2018-08-14 13:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:22:25 --> Input Class Initialized
INFO - 2018-08-14 13:22:25 --> Language Class Initialized
INFO - 2018-08-14 13:22:25 --> Language Class Initialized
INFO - 2018-08-14 13:22:25 --> Config Class Initialized
INFO - 2018-08-14 13:22:25 --> Loader Class Initialized
INFO - 2018-08-14 13:22:25 --> Helper loaded: url_helper
INFO - 2018-08-14 13:22:25 --> Helper loaded: file_helper
INFO - 2018-08-14 13:22:25 --> Helper loaded: form_helper
INFO - 2018-08-14 13:22:25 --> Helper loaded: my_helper
INFO - 2018-08-14 13:22:25 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:22:25 --> Controller Class Initialized
INFO - 2018-08-14 13:22:25 --> Final output sent to browser
DEBUG - 2018-08-14 13:22:25 --> Total execution time: 0.2513
INFO - 2018-08-14 13:22:31 --> Config Class Initialized
INFO - 2018-08-14 13:22:31 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:22:31 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:22:31 --> Utf8 Class Initialized
INFO - 2018-08-14 13:22:31 --> URI Class Initialized
INFO - 2018-08-14 13:22:31 --> Router Class Initialized
INFO - 2018-08-14 13:22:31 --> Output Class Initialized
INFO - 2018-08-14 13:22:31 --> Security Class Initialized
DEBUG - 2018-08-14 13:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:22:31 --> Input Class Initialized
INFO - 2018-08-14 13:22:31 --> Language Class Initialized
INFO - 2018-08-14 13:22:31 --> Language Class Initialized
INFO - 2018-08-14 13:22:31 --> Config Class Initialized
INFO - 2018-08-14 13:22:31 --> Loader Class Initialized
INFO - 2018-08-14 13:22:31 --> Helper loaded: url_helper
INFO - 2018-08-14 13:22:31 --> Helper loaded: file_helper
INFO - 2018-08-14 13:22:31 --> Helper loaded: form_helper
INFO - 2018-08-14 13:22:31 --> Helper loaded: my_helper
INFO - 2018-08-14 13:22:31 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:22:32 --> Controller Class Initialized
DEBUG - 2018-08-14 13:22:32 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:22:32 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:22:32 --> Final output sent to browser
DEBUG - 2018-08-14 13:22:32 --> Total execution time: 0.3813
INFO - 2018-08-14 13:22:32 --> Config Class Initialized
INFO - 2018-08-14 13:22:32 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:22:32 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:22:32 --> Utf8 Class Initialized
INFO - 2018-08-14 13:22:32 --> URI Class Initialized
INFO - 2018-08-14 13:22:32 --> Router Class Initialized
INFO - 2018-08-14 13:22:32 --> Output Class Initialized
INFO - 2018-08-14 13:22:32 --> Security Class Initialized
DEBUG - 2018-08-14 13:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:22:32 --> Input Class Initialized
INFO - 2018-08-14 13:22:32 --> Language Class Initialized
ERROR - 2018-08-14 13:22:32 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:22:32 --> Config Class Initialized
INFO - 2018-08-14 13:22:32 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:22:32 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:22:32 --> Utf8 Class Initialized
INFO - 2018-08-14 13:22:32 --> URI Class Initialized
INFO - 2018-08-14 13:22:32 --> Router Class Initialized
INFO - 2018-08-14 13:22:32 --> Output Class Initialized
INFO - 2018-08-14 13:22:32 --> Security Class Initialized
DEBUG - 2018-08-14 13:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:22:32 --> Input Class Initialized
INFO - 2018-08-14 13:22:32 --> Language Class Initialized
INFO - 2018-08-14 13:22:32 --> Language Class Initialized
INFO - 2018-08-14 13:22:32 --> Config Class Initialized
INFO - 2018-08-14 13:22:32 --> Loader Class Initialized
INFO - 2018-08-14 13:22:32 --> Helper loaded: url_helper
INFO - 2018-08-14 13:22:32 --> Helper loaded: file_helper
INFO - 2018-08-14 13:22:32 --> Helper loaded: form_helper
INFO - 2018-08-14 13:22:32 --> Helper loaded: my_helper
INFO - 2018-08-14 13:22:32 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:22:32 --> Controller Class Initialized
INFO - 2018-08-14 13:22:33 --> Config Class Initialized
INFO - 2018-08-14 13:22:33 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:22:33 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:22:33 --> Utf8 Class Initialized
INFO - 2018-08-14 13:22:33 --> URI Class Initialized
INFO - 2018-08-14 13:22:33 --> Router Class Initialized
INFO - 2018-08-14 13:22:33 --> Output Class Initialized
INFO - 2018-08-14 13:22:33 --> Security Class Initialized
DEBUG - 2018-08-14 13:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:22:33 --> Input Class Initialized
INFO - 2018-08-14 13:22:33 --> Language Class Initialized
INFO - 2018-08-14 13:22:33 --> Language Class Initialized
INFO - 2018-08-14 13:22:33 --> Config Class Initialized
INFO - 2018-08-14 13:22:33 --> Loader Class Initialized
INFO - 2018-08-14 13:22:33 --> Helper loaded: url_helper
INFO - 2018-08-14 13:22:33 --> Helper loaded: file_helper
INFO - 2018-08-14 13:22:33 --> Helper loaded: form_helper
INFO - 2018-08-14 13:22:33 --> Helper loaded: my_helper
INFO - 2018-08-14 13:22:33 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:22:33 --> Controller Class Initialized
DEBUG - 2018-08-14 13:22:33 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:22:33 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:22:33 --> Final output sent to browser
DEBUG - 2018-08-14 13:22:33 --> Total execution time: 0.3806
INFO - 2018-08-14 13:22:33 --> Config Class Initialized
INFO - 2018-08-14 13:22:33 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:22:33 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:22:33 --> Utf8 Class Initialized
INFO - 2018-08-14 13:22:33 --> URI Class Initialized
INFO - 2018-08-14 13:22:33 --> Router Class Initialized
INFO - 2018-08-14 13:22:33 --> Output Class Initialized
INFO - 2018-08-14 13:22:33 --> Security Class Initialized
DEBUG - 2018-08-14 13:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:22:33 --> Input Class Initialized
INFO - 2018-08-14 13:22:33 --> Language Class Initialized
ERROR - 2018-08-14 13:22:34 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:22:34 --> Config Class Initialized
INFO - 2018-08-14 13:22:34 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:22:34 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:22:34 --> Utf8 Class Initialized
INFO - 2018-08-14 13:22:34 --> URI Class Initialized
INFO - 2018-08-14 13:22:34 --> Router Class Initialized
INFO - 2018-08-14 13:22:34 --> Output Class Initialized
INFO - 2018-08-14 13:22:34 --> Security Class Initialized
DEBUG - 2018-08-14 13:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:22:34 --> Input Class Initialized
INFO - 2018-08-14 13:22:34 --> Language Class Initialized
INFO - 2018-08-14 13:22:34 --> Language Class Initialized
INFO - 2018-08-14 13:22:34 --> Config Class Initialized
INFO - 2018-08-14 13:22:34 --> Loader Class Initialized
INFO - 2018-08-14 13:22:34 --> Helper loaded: url_helper
INFO - 2018-08-14 13:22:34 --> Helper loaded: file_helper
INFO - 2018-08-14 13:22:34 --> Helper loaded: form_helper
INFO - 2018-08-14 13:22:34 --> Helper loaded: my_helper
INFO - 2018-08-14 13:22:34 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:22:34 --> Controller Class Initialized
INFO - 2018-08-14 13:22:38 --> Config Class Initialized
INFO - 2018-08-14 13:22:38 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:22:38 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:22:38 --> Utf8 Class Initialized
INFO - 2018-08-14 13:22:38 --> URI Class Initialized
INFO - 2018-08-14 13:22:38 --> Router Class Initialized
INFO - 2018-08-14 13:22:38 --> Output Class Initialized
INFO - 2018-08-14 13:22:38 --> Security Class Initialized
DEBUG - 2018-08-14 13:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:22:38 --> Input Class Initialized
INFO - 2018-08-14 13:22:38 --> Language Class Initialized
INFO - 2018-08-14 13:22:38 --> Language Class Initialized
INFO - 2018-08-14 13:22:38 --> Config Class Initialized
INFO - 2018-08-14 13:22:38 --> Loader Class Initialized
INFO - 2018-08-14 13:22:38 --> Helper loaded: url_helper
INFO - 2018-08-14 13:22:38 --> Helper loaded: file_helper
INFO - 2018-08-14 13:22:38 --> Helper loaded: form_helper
INFO - 2018-08-14 13:22:38 --> Helper loaded: my_helper
INFO - 2018-08-14 13:22:38 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:22:38 --> Controller Class Initialized
INFO - 2018-08-14 13:22:44 --> Config Class Initialized
INFO - 2018-08-14 13:22:44 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:22:44 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:22:44 --> Utf8 Class Initialized
INFO - 2018-08-14 13:22:44 --> URI Class Initialized
INFO - 2018-08-14 13:22:44 --> Router Class Initialized
INFO - 2018-08-14 13:22:44 --> Output Class Initialized
INFO - 2018-08-14 13:22:44 --> Security Class Initialized
DEBUG - 2018-08-14 13:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:22:44 --> Input Class Initialized
INFO - 2018-08-14 13:22:44 --> Language Class Initialized
INFO - 2018-08-14 13:22:44 --> Language Class Initialized
INFO - 2018-08-14 13:22:44 --> Config Class Initialized
INFO - 2018-08-14 13:22:44 --> Loader Class Initialized
INFO - 2018-08-14 13:22:44 --> Helper loaded: url_helper
INFO - 2018-08-14 13:22:44 --> Helper loaded: file_helper
INFO - 2018-08-14 13:22:44 --> Helper loaded: form_helper
INFO - 2018-08-14 13:22:44 --> Helper loaded: my_helper
INFO - 2018-08-14 13:22:44 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:22:44 --> Controller Class Initialized
DEBUG - 2018-08-14 13:22:44 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:22:44 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:22:44 --> Final output sent to browser
DEBUG - 2018-08-14 13:22:44 --> Total execution time: 0.3401
INFO - 2018-08-14 13:22:44 --> Config Class Initialized
INFO - 2018-08-14 13:22:44 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:22:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:22:45 --> Utf8 Class Initialized
INFO - 2018-08-14 13:22:45 --> URI Class Initialized
INFO - 2018-08-14 13:22:45 --> Router Class Initialized
INFO - 2018-08-14 13:22:45 --> Output Class Initialized
INFO - 2018-08-14 13:22:45 --> Security Class Initialized
DEBUG - 2018-08-14 13:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:22:45 --> Input Class Initialized
INFO - 2018-08-14 13:22:45 --> Language Class Initialized
ERROR - 2018-08-14 13:22:45 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:22:45 --> Config Class Initialized
INFO - 2018-08-14 13:22:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:22:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:22:45 --> Utf8 Class Initialized
INFO - 2018-08-14 13:22:45 --> URI Class Initialized
INFO - 2018-08-14 13:22:45 --> Router Class Initialized
INFO - 2018-08-14 13:22:45 --> Output Class Initialized
INFO - 2018-08-14 13:22:45 --> Security Class Initialized
DEBUG - 2018-08-14 13:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:22:45 --> Input Class Initialized
INFO - 2018-08-14 13:22:45 --> Language Class Initialized
INFO - 2018-08-14 13:22:45 --> Language Class Initialized
INFO - 2018-08-14 13:22:45 --> Config Class Initialized
INFO - 2018-08-14 13:22:45 --> Loader Class Initialized
INFO - 2018-08-14 13:22:45 --> Helper loaded: url_helper
INFO - 2018-08-14 13:22:45 --> Helper loaded: file_helper
INFO - 2018-08-14 13:22:45 --> Helper loaded: form_helper
INFO - 2018-08-14 13:22:45 --> Helper loaded: my_helper
INFO - 2018-08-14 13:22:45 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:22:45 --> Controller Class Initialized
INFO - 2018-08-14 13:22:47 --> Config Class Initialized
INFO - 2018-08-14 13:22:47 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:22:47 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:22:47 --> Utf8 Class Initialized
INFO - 2018-08-14 13:22:47 --> URI Class Initialized
INFO - 2018-08-14 13:22:47 --> Router Class Initialized
INFO - 2018-08-14 13:22:47 --> Output Class Initialized
INFO - 2018-08-14 13:22:47 --> Security Class Initialized
DEBUG - 2018-08-14 13:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:22:47 --> Input Class Initialized
INFO - 2018-08-14 13:22:47 --> Language Class Initialized
INFO - 2018-08-14 13:22:47 --> Language Class Initialized
INFO - 2018-08-14 13:22:47 --> Config Class Initialized
INFO - 2018-08-14 13:22:47 --> Loader Class Initialized
INFO - 2018-08-14 13:22:47 --> Helper loaded: url_helper
INFO - 2018-08-14 13:22:47 --> Helper loaded: file_helper
INFO - 2018-08-14 13:22:47 --> Helper loaded: form_helper
INFO - 2018-08-14 13:22:47 --> Helper loaded: my_helper
INFO - 2018-08-14 13:22:47 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:22:47 --> Controller Class Initialized
INFO - 2018-08-14 13:22:47 --> Final output sent to browser
DEBUG - 2018-08-14 13:22:47 --> Total execution time: 0.3156
INFO - 2018-08-14 13:22:49 --> Config Class Initialized
INFO - 2018-08-14 13:22:49 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:22:49 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:22:49 --> Utf8 Class Initialized
INFO - 2018-08-14 13:22:49 --> URI Class Initialized
INFO - 2018-08-14 13:22:49 --> Router Class Initialized
INFO - 2018-08-14 13:22:49 --> Output Class Initialized
INFO - 2018-08-14 13:22:49 --> Security Class Initialized
DEBUG - 2018-08-14 13:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:22:49 --> Input Class Initialized
INFO - 2018-08-14 13:22:49 --> Language Class Initialized
INFO - 2018-08-14 13:22:49 --> Language Class Initialized
INFO - 2018-08-14 13:22:49 --> Config Class Initialized
INFO - 2018-08-14 13:22:49 --> Loader Class Initialized
INFO - 2018-08-14 13:22:49 --> Helper loaded: url_helper
INFO - 2018-08-14 13:22:49 --> Helper loaded: file_helper
INFO - 2018-08-14 13:22:49 --> Helper loaded: form_helper
INFO - 2018-08-14 13:22:49 --> Helper loaded: my_helper
INFO - 2018-08-14 13:22:49 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:22:49 --> Controller Class Initialized
INFO - 2018-08-14 13:22:49 --> Final output sent to browser
DEBUG - 2018-08-14 13:22:49 --> Total execution time: 0.2811
INFO - 2018-08-14 13:23:34 --> Config Class Initialized
INFO - 2018-08-14 13:23:34 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:23:34 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:23:34 --> Utf8 Class Initialized
INFO - 2018-08-14 13:23:34 --> URI Class Initialized
INFO - 2018-08-14 13:23:34 --> Router Class Initialized
INFO - 2018-08-14 13:23:34 --> Output Class Initialized
INFO - 2018-08-14 13:23:34 --> Security Class Initialized
DEBUG - 2018-08-14 13:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:23:35 --> Input Class Initialized
INFO - 2018-08-14 13:23:35 --> Language Class Initialized
INFO - 2018-08-14 13:23:35 --> Language Class Initialized
INFO - 2018-08-14 13:23:35 --> Config Class Initialized
INFO - 2018-08-14 13:23:35 --> Loader Class Initialized
INFO - 2018-08-14 13:23:35 --> Helper loaded: url_helper
INFO - 2018-08-14 13:23:35 --> Helper loaded: file_helper
INFO - 2018-08-14 13:23:35 --> Helper loaded: form_helper
INFO - 2018-08-14 13:23:35 --> Helper loaded: my_helper
INFO - 2018-08-14 13:23:35 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:23:35 --> Controller Class Initialized
DEBUG - 2018-08-14 13:23:35 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:23:35 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:23:35 --> Final output sent to browser
DEBUG - 2018-08-14 13:23:35 --> Total execution time: 0.3621
INFO - 2018-08-14 13:23:35 --> Config Class Initialized
INFO - 2018-08-14 13:23:35 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:23:35 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:23:35 --> Utf8 Class Initialized
INFO - 2018-08-14 13:23:35 --> URI Class Initialized
INFO - 2018-08-14 13:23:35 --> Router Class Initialized
INFO - 2018-08-14 13:23:35 --> Output Class Initialized
INFO - 2018-08-14 13:23:35 --> Security Class Initialized
DEBUG - 2018-08-14 13:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:23:35 --> Input Class Initialized
INFO - 2018-08-14 13:23:35 --> Language Class Initialized
ERROR - 2018-08-14 13:23:35 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:23:35 --> Config Class Initialized
INFO - 2018-08-14 13:23:35 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:23:35 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:23:35 --> Utf8 Class Initialized
INFO - 2018-08-14 13:23:35 --> URI Class Initialized
INFO - 2018-08-14 13:23:35 --> Router Class Initialized
INFO - 2018-08-14 13:23:35 --> Output Class Initialized
INFO - 2018-08-14 13:23:35 --> Security Class Initialized
DEBUG - 2018-08-14 13:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:23:35 --> Input Class Initialized
INFO - 2018-08-14 13:23:35 --> Language Class Initialized
INFO - 2018-08-14 13:23:35 --> Language Class Initialized
INFO - 2018-08-14 13:23:35 --> Config Class Initialized
INFO - 2018-08-14 13:23:35 --> Loader Class Initialized
INFO - 2018-08-14 13:23:35 --> Helper loaded: url_helper
INFO - 2018-08-14 13:23:35 --> Helper loaded: file_helper
INFO - 2018-08-14 13:23:35 --> Helper loaded: form_helper
INFO - 2018-08-14 13:23:35 --> Helper loaded: my_helper
INFO - 2018-08-14 13:23:35 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:23:35 --> Controller Class Initialized
INFO - 2018-08-14 13:23:37 --> Config Class Initialized
INFO - 2018-08-14 13:23:37 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:23:37 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:23:37 --> Utf8 Class Initialized
INFO - 2018-08-14 13:23:37 --> URI Class Initialized
INFO - 2018-08-14 13:23:37 --> Router Class Initialized
INFO - 2018-08-14 13:23:37 --> Output Class Initialized
INFO - 2018-08-14 13:23:37 --> Security Class Initialized
DEBUG - 2018-08-14 13:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:23:37 --> Input Class Initialized
INFO - 2018-08-14 13:23:37 --> Language Class Initialized
INFO - 2018-08-14 13:23:37 --> Language Class Initialized
INFO - 2018-08-14 13:23:37 --> Config Class Initialized
INFO - 2018-08-14 13:23:37 --> Loader Class Initialized
INFO - 2018-08-14 13:23:37 --> Helper loaded: url_helper
INFO - 2018-08-14 13:23:37 --> Helper loaded: file_helper
INFO - 2018-08-14 13:23:37 --> Helper loaded: form_helper
INFO - 2018-08-14 13:23:37 --> Helper loaded: my_helper
INFO - 2018-08-14 13:23:37 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:23:37 --> Controller Class Initialized
DEBUG - 2018-08-14 13:23:37 --> File loaded: D:\laragon\www\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2018-08-14 13:23:37 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:23:37 --> Final output sent to browser
DEBUG - 2018-08-14 13:23:37 --> Total execution time: 0.3138
INFO - 2018-08-14 13:23:37 --> Config Class Initialized
INFO - 2018-08-14 13:23:37 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:23:37 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:23:38 --> Utf8 Class Initialized
INFO - 2018-08-14 13:23:38 --> URI Class Initialized
INFO - 2018-08-14 13:23:38 --> Router Class Initialized
INFO - 2018-08-14 13:23:38 --> Output Class Initialized
INFO - 2018-08-14 13:23:38 --> Security Class Initialized
DEBUG - 2018-08-14 13:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:23:38 --> Input Class Initialized
INFO - 2018-08-14 13:23:38 --> Language Class Initialized
ERROR - 2018-08-14 13:23:38 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:23:38 --> Config Class Initialized
INFO - 2018-08-14 13:23:38 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:23:38 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:23:38 --> Utf8 Class Initialized
INFO - 2018-08-14 13:23:38 --> URI Class Initialized
INFO - 2018-08-14 13:23:38 --> Router Class Initialized
INFO - 2018-08-14 13:23:38 --> Output Class Initialized
INFO - 2018-08-14 13:23:38 --> Security Class Initialized
DEBUG - 2018-08-14 13:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:23:38 --> Input Class Initialized
INFO - 2018-08-14 13:23:38 --> Language Class Initialized
INFO - 2018-08-14 13:23:38 --> Language Class Initialized
INFO - 2018-08-14 13:23:38 --> Config Class Initialized
INFO - 2018-08-14 13:23:38 --> Loader Class Initialized
INFO - 2018-08-14 13:23:38 --> Helper loaded: url_helper
INFO - 2018-08-14 13:23:38 --> Helper loaded: file_helper
INFO - 2018-08-14 13:23:38 --> Helper loaded: form_helper
INFO - 2018-08-14 13:23:38 --> Helper loaded: my_helper
INFO - 2018-08-14 13:23:38 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:23:38 --> Controller Class Initialized
INFO - 2018-08-14 13:23:39 --> Config Class Initialized
INFO - 2018-08-14 13:23:39 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:23:39 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:23:39 --> Utf8 Class Initialized
INFO - 2018-08-14 13:23:39 --> URI Class Initialized
INFO - 2018-08-14 13:23:39 --> Router Class Initialized
INFO - 2018-08-14 13:23:39 --> Output Class Initialized
INFO - 2018-08-14 13:23:39 --> Security Class Initialized
DEBUG - 2018-08-14 13:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:23:39 --> Input Class Initialized
INFO - 2018-08-14 13:23:39 --> Language Class Initialized
INFO - 2018-08-14 13:23:39 --> Language Class Initialized
INFO - 2018-08-14 13:23:39 --> Config Class Initialized
INFO - 2018-08-14 13:23:39 --> Loader Class Initialized
INFO - 2018-08-14 13:23:39 --> Helper loaded: url_helper
INFO - 2018-08-14 13:23:39 --> Helper loaded: file_helper
INFO - 2018-08-14 13:23:39 --> Helper loaded: form_helper
INFO - 2018-08-14 13:23:39 --> Helper loaded: my_helper
INFO - 2018-08-14 13:23:39 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:23:39 --> Controller Class Initialized
DEBUG - 2018-08-14 13:23:39 --> File loaded: D:\laragon\www\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2018-08-14 13:23:39 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:23:39 --> Final output sent to browser
DEBUG - 2018-08-14 13:23:39 --> Total execution time: 0.2980
INFO - 2018-08-14 13:23:39 --> Config Class Initialized
INFO - 2018-08-14 13:23:39 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:23:39 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:23:39 --> Utf8 Class Initialized
INFO - 2018-08-14 13:23:39 --> URI Class Initialized
INFO - 2018-08-14 13:23:39 --> Router Class Initialized
INFO - 2018-08-14 13:23:39 --> Output Class Initialized
INFO - 2018-08-14 13:23:39 --> Security Class Initialized
DEBUG - 2018-08-14 13:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:23:39 --> Input Class Initialized
INFO - 2018-08-14 13:23:39 --> Language Class Initialized
ERROR - 2018-08-14 13:23:39 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:23:39 --> Config Class Initialized
INFO - 2018-08-14 13:23:39 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:23:39 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:23:40 --> Utf8 Class Initialized
INFO - 2018-08-14 13:23:40 --> URI Class Initialized
INFO - 2018-08-14 13:23:40 --> Router Class Initialized
INFO - 2018-08-14 13:23:40 --> Output Class Initialized
INFO - 2018-08-14 13:23:40 --> Security Class Initialized
DEBUG - 2018-08-14 13:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:23:40 --> Input Class Initialized
INFO - 2018-08-14 13:23:40 --> Language Class Initialized
INFO - 2018-08-14 13:23:40 --> Language Class Initialized
INFO - 2018-08-14 13:23:40 --> Config Class Initialized
INFO - 2018-08-14 13:23:40 --> Loader Class Initialized
INFO - 2018-08-14 13:23:40 --> Helper loaded: url_helper
INFO - 2018-08-14 13:23:40 --> Helper loaded: file_helper
INFO - 2018-08-14 13:23:40 --> Helper loaded: form_helper
INFO - 2018-08-14 13:23:40 --> Helper loaded: my_helper
INFO - 2018-08-14 13:23:40 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:23:40 --> Controller Class Initialized
INFO - 2018-08-14 13:24:17 --> Config Class Initialized
INFO - 2018-08-14 13:24:17 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:24:17 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:24:17 --> Utf8 Class Initialized
INFO - 2018-08-14 13:24:17 --> URI Class Initialized
INFO - 2018-08-14 13:24:17 --> Router Class Initialized
INFO - 2018-08-14 13:24:17 --> Output Class Initialized
INFO - 2018-08-14 13:24:17 --> Security Class Initialized
DEBUG - 2018-08-14 13:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:24:17 --> Input Class Initialized
INFO - 2018-08-14 13:24:17 --> Language Class Initialized
INFO - 2018-08-14 13:24:17 --> Language Class Initialized
INFO - 2018-08-14 13:24:17 --> Config Class Initialized
INFO - 2018-08-14 13:24:17 --> Loader Class Initialized
INFO - 2018-08-14 13:24:17 --> Helper loaded: url_helper
INFO - 2018-08-14 13:24:17 --> Helper loaded: file_helper
INFO - 2018-08-14 13:24:17 --> Helper loaded: form_helper
INFO - 2018-08-14 13:24:17 --> Helper loaded: my_helper
INFO - 2018-08-14 13:24:17 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:24:17 --> Controller Class Initialized
DEBUG - 2018-08-14 13:24:17 --> File loaded: D:\laragon\www\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2018-08-14 13:24:17 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:24:17 --> Final output sent to browser
DEBUG - 2018-08-14 13:24:17 --> Total execution time: 0.3123
INFO - 2018-08-14 13:24:17 --> Config Class Initialized
INFO - 2018-08-14 13:24:17 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:24:17 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:24:17 --> Utf8 Class Initialized
INFO - 2018-08-14 13:24:17 --> URI Class Initialized
INFO - 2018-08-14 13:24:17 --> Router Class Initialized
INFO - 2018-08-14 13:24:17 --> Output Class Initialized
INFO - 2018-08-14 13:24:17 --> Security Class Initialized
DEBUG - 2018-08-14 13:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:24:17 --> Input Class Initialized
INFO - 2018-08-14 13:24:17 --> Language Class Initialized
ERROR - 2018-08-14 13:24:18 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:24:18 --> Config Class Initialized
INFO - 2018-08-14 13:24:18 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:24:18 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:24:18 --> Utf8 Class Initialized
INFO - 2018-08-14 13:24:18 --> URI Class Initialized
INFO - 2018-08-14 13:24:18 --> Router Class Initialized
INFO - 2018-08-14 13:24:18 --> Output Class Initialized
INFO - 2018-08-14 13:24:18 --> Security Class Initialized
DEBUG - 2018-08-14 13:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:24:18 --> Input Class Initialized
INFO - 2018-08-14 13:24:18 --> Language Class Initialized
INFO - 2018-08-14 13:24:18 --> Language Class Initialized
INFO - 2018-08-14 13:24:18 --> Config Class Initialized
INFO - 2018-08-14 13:24:18 --> Loader Class Initialized
INFO - 2018-08-14 13:24:18 --> Helper loaded: url_helper
INFO - 2018-08-14 13:24:18 --> Helper loaded: file_helper
INFO - 2018-08-14 13:24:18 --> Helper loaded: form_helper
INFO - 2018-08-14 13:24:18 --> Helper loaded: my_helper
INFO - 2018-08-14 13:24:18 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:24:18 --> Controller Class Initialized
INFO - 2018-08-14 13:24:19 --> Config Class Initialized
INFO - 2018-08-14 13:24:19 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:24:19 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:24:19 --> Utf8 Class Initialized
INFO - 2018-08-14 13:24:19 --> URI Class Initialized
INFO - 2018-08-14 13:24:19 --> Router Class Initialized
INFO - 2018-08-14 13:24:19 --> Output Class Initialized
INFO - 2018-08-14 13:24:19 --> Security Class Initialized
DEBUG - 2018-08-14 13:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:24:19 --> Input Class Initialized
INFO - 2018-08-14 13:24:19 --> Language Class Initialized
INFO - 2018-08-14 13:24:19 --> Language Class Initialized
INFO - 2018-08-14 13:24:19 --> Config Class Initialized
INFO - 2018-08-14 13:24:19 --> Loader Class Initialized
INFO - 2018-08-14 13:24:19 --> Helper loaded: url_helper
INFO - 2018-08-14 13:24:19 --> Helper loaded: file_helper
INFO - 2018-08-14 13:24:19 --> Helper loaded: form_helper
INFO - 2018-08-14 13:24:19 --> Helper loaded: my_helper
INFO - 2018-08-14 13:24:19 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:24:19 --> Controller Class Initialized
ERROR - 2018-08-14 13:24:19 --> Severity: Notice --> Undefined variable: status_form D:\laragon\www\nilai\application\modules\data_siswa\views\form.php 172
DEBUG - 2018-08-14 13:24:19 --> File loaded: D:\laragon\www\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2018-08-14 13:24:19 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:24:19 --> Final output sent to browser
DEBUG - 2018-08-14 13:24:19 --> Total execution time: 0.3056
INFO - 2018-08-14 13:24:19 --> Config Class Initialized
INFO - 2018-08-14 13:24:19 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:24:19 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:24:19 --> Utf8 Class Initialized
INFO - 2018-08-14 13:24:19 --> URI Class Initialized
INFO - 2018-08-14 13:24:19 --> Router Class Initialized
INFO - 2018-08-14 13:24:19 --> Output Class Initialized
INFO - 2018-08-14 13:24:19 --> Security Class Initialized
DEBUG - 2018-08-14 13:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:24:19 --> Input Class Initialized
INFO - 2018-08-14 13:24:19 --> Language Class Initialized
ERROR - 2018-08-14 13:24:19 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:24:25 --> Config Class Initialized
INFO - 2018-08-14 13:24:25 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:24:25 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:24:25 --> Utf8 Class Initialized
INFO - 2018-08-14 13:24:25 --> URI Class Initialized
DEBUG - 2018-08-14 13:24:25 --> No URI present. Default controller set.
INFO - 2018-08-14 13:24:25 --> Router Class Initialized
INFO - 2018-08-14 13:24:25 --> Output Class Initialized
INFO - 2018-08-14 13:24:25 --> Security Class Initialized
DEBUG - 2018-08-14 13:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:24:25 --> Input Class Initialized
INFO - 2018-08-14 13:24:25 --> Language Class Initialized
INFO - 2018-08-14 13:24:25 --> Language Class Initialized
INFO - 2018-08-14 13:24:25 --> Config Class Initialized
INFO - 2018-08-14 13:24:25 --> Loader Class Initialized
INFO - 2018-08-14 13:24:25 --> Helper loaded: url_helper
INFO - 2018-08-14 13:24:25 --> Helper loaded: file_helper
INFO - 2018-08-14 13:24:25 --> Helper loaded: form_helper
INFO - 2018-08-14 13:24:25 --> Helper loaded: my_helper
INFO - 2018-08-14 13:24:25 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:24:25 --> Controller Class Initialized
DEBUG - 2018-08-14 13:24:25 --> File loaded: D:\laragon\www\nilai\application\modules/home/views/v_home.php
DEBUG - 2018-08-14 13:24:25 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:24:25 --> Final output sent to browser
DEBUG - 2018-08-14 13:24:25 --> Total execution time: 0.3853
INFO - 2018-08-14 13:24:25 --> Config Class Initialized
INFO - 2018-08-14 13:24:25 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:24:25 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:24:25 --> Utf8 Class Initialized
INFO - 2018-08-14 13:24:25 --> URI Class Initialized
INFO - 2018-08-14 13:24:25 --> Router Class Initialized
INFO - 2018-08-14 13:24:25 --> Output Class Initialized
INFO - 2018-08-14 13:24:25 --> Security Class Initialized
DEBUG - 2018-08-14 13:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:24:25 --> Input Class Initialized
INFO - 2018-08-14 13:24:25 --> Language Class Initialized
ERROR - 2018-08-14 13:24:25 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:24:26 --> Config Class Initialized
INFO - 2018-08-14 13:24:26 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:24:26 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:24:26 --> Utf8 Class Initialized
INFO - 2018-08-14 13:24:26 --> URI Class Initialized
INFO - 2018-08-14 13:24:26 --> Router Class Initialized
INFO - 2018-08-14 13:24:27 --> Output Class Initialized
INFO - 2018-08-14 13:24:27 --> Security Class Initialized
DEBUG - 2018-08-14 13:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:24:27 --> Input Class Initialized
INFO - 2018-08-14 13:24:27 --> Language Class Initialized
INFO - 2018-08-14 13:24:27 --> Language Class Initialized
INFO - 2018-08-14 13:24:27 --> Config Class Initialized
INFO - 2018-08-14 13:24:27 --> Loader Class Initialized
INFO - 2018-08-14 13:24:27 --> Helper loaded: url_helper
INFO - 2018-08-14 13:24:27 --> Helper loaded: file_helper
INFO - 2018-08-14 13:24:27 --> Helper loaded: form_helper
INFO - 2018-08-14 13:24:27 --> Helper loaded: my_helper
INFO - 2018-08-14 13:24:27 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:24:27 --> Controller Class Initialized
DEBUG - 2018-08-14 13:24:27 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:24:27 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:24:27 --> Final output sent to browser
DEBUG - 2018-08-14 13:24:27 --> Total execution time: 0.3002
INFO - 2018-08-14 13:24:27 --> Config Class Initialized
INFO - 2018-08-14 13:24:27 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:24:27 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:24:27 --> Utf8 Class Initialized
INFO - 2018-08-14 13:24:27 --> URI Class Initialized
INFO - 2018-08-14 13:24:27 --> Router Class Initialized
INFO - 2018-08-14 13:24:27 --> Output Class Initialized
INFO - 2018-08-14 13:24:27 --> Security Class Initialized
DEBUG - 2018-08-14 13:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:24:27 --> Input Class Initialized
INFO - 2018-08-14 13:24:27 --> Language Class Initialized
ERROR - 2018-08-14 13:24:27 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:24:27 --> Config Class Initialized
INFO - 2018-08-14 13:24:27 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:24:27 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:24:27 --> Utf8 Class Initialized
INFO - 2018-08-14 13:24:27 --> URI Class Initialized
INFO - 2018-08-14 13:24:27 --> Router Class Initialized
INFO - 2018-08-14 13:24:27 --> Output Class Initialized
INFO - 2018-08-14 13:24:27 --> Security Class Initialized
DEBUG - 2018-08-14 13:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:24:27 --> Input Class Initialized
INFO - 2018-08-14 13:24:27 --> Language Class Initialized
INFO - 2018-08-14 13:24:27 --> Language Class Initialized
INFO - 2018-08-14 13:24:27 --> Config Class Initialized
INFO - 2018-08-14 13:24:27 --> Loader Class Initialized
INFO - 2018-08-14 13:24:27 --> Helper loaded: url_helper
INFO - 2018-08-14 13:24:27 --> Helper loaded: file_helper
INFO - 2018-08-14 13:24:27 --> Helper loaded: form_helper
INFO - 2018-08-14 13:24:28 --> Helper loaded: my_helper
INFO - 2018-08-14 13:24:28 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:24:28 --> Controller Class Initialized
INFO - 2018-08-14 13:26:56 --> Config Class Initialized
INFO - 2018-08-14 13:26:56 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:26:56 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:26:56 --> Utf8 Class Initialized
INFO - 2018-08-14 13:26:56 --> URI Class Initialized
INFO - 2018-08-14 13:26:56 --> Router Class Initialized
INFO - 2018-08-14 13:26:56 --> Output Class Initialized
INFO - 2018-08-14 13:26:56 --> Security Class Initialized
DEBUG - 2018-08-14 13:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:26:56 --> Input Class Initialized
INFO - 2018-08-14 13:26:56 --> Language Class Initialized
INFO - 2018-08-14 13:26:56 --> Language Class Initialized
INFO - 2018-08-14 13:26:56 --> Config Class Initialized
INFO - 2018-08-14 13:26:56 --> Loader Class Initialized
INFO - 2018-08-14 13:26:56 --> Helper loaded: url_helper
INFO - 2018-08-14 13:26:56 --> Helper loaded: file_helper
INFO - 2018-08-14 13:26:56 --> Helper loaded: form_helper
INFO - 2018-08-14 13:26:56 --> Helper loaded: my_helper
INFO - 2018-08-14 13:26:56 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:26:57 --> Controller Class Initialized
DEBUG - 2018-08-14 13:26:57 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:26:57 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:26:57 --> Final output sent to browser
DEBUG - 2018-08-14 13:26:57 --> Total execution time: 1.0445
INFO - 2018-08-14 13:26:57 --> Config Class Initialized
INFO - 2018-08-14 13:26:57 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:26:57 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:26:57 --> Utf8 Class Initialized
INFO - 2018-08-14 13:26:57 --> URI Class Initialized
INFO - 2018-08-14 13:26:57 --> Router Class Initialized
INFO - 2018-08-14 13:26:57 --> Output Class Initialized
INFO - 2018-08-14 13:26:57 --> Security Class Initialized
DEBUG - 2018-08-14 13:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:26:57 --> Input Class Initialized
INFO - 2018-08-14 13:26:57 --> Language Class Initialized
ERROR - 2018-08-14 13:26:57 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:26:57 --> Config Class Initialized
INFO - 2018-08-14 13:26:57 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:26:57 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:26:57 --> Utf8 Class Initialized
INFO - 2018-08-14 13:26:57 --> URI Class Initialized
INFO - 2018-08-14 13:26:57 --> Router Class Initialized
INFO - 2018-08-14 13:26:57 --> Output Class Initialized
INFO - 2018-08-14 13:26:57 --> Security Class Initialized
DEBUG - 2018-08-14 13:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:26:57 --> Input Class Initialized
INFO - 2018-08-14 13:26:57 --> Language Class Initialized
INFO - 2018-08-14 13:26:57 --> Language Class Initialized
INFO - 2018-08-14 13:26:57 --> Config Class Initialized
INFO - 2018-08-14 13:26:57 --> Loader Class Initialized
INFO - 2018-08-14 13:26:57 --> Helper loaded: url_helper
INFO - 2018-08-14 13:26:57 --> Helper loaded: file_helper
INFO - 2018-08-14 13:26:57 --> Helper loaded: form_helper
INFO - 2018-08-14 13:26:57 --> Helper loaded: my_helper
INFO - 2018-08-14 13:26:57 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:26:57 --> Controller Class Initialized
INFO - 2018-08-14 13:26:57 --> Config Class Initialized
INFO - 2018-08-14 13:26:57 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:26:57 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:26:57 --> Utf8 Class Initialized
INFO - 2018-08-14 13:26:57 --> URI Class Initialized
INFO - 2018-08-14 13:26:57 --> Router Class Initialized
INFO - 2018-08-14 13:26:57 --> Output Class Initialized
INFO - 2018-08-14 13:26:57 --> Security Class Initialized
DEBUG - 2018-08-14 13:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:26:58 --> Input Class Initialized
INFO - 2018-08-14 13:26:58 --> Language Class Initialized
INFO - 2018-08-14 13:26:58 --> Language Class Initialized
INFO - 2018-08-14 13:26:58 --> Config Class Initialized
INFO - 2018-08-14 13:26:58 --> Loader Class Initialized
INFO - 2018-08-14 13:26:58 --> Helper loaded: url_helper
INFO - 2018-08-14 13:26:58 --> Helper loaded: file_helper
INFO - 2018-08-14 13:26:58 --> Helper loaded: form_helper
INFO - 2018-08-14 13:26:58 --> Helper loaded: my_helper
INFO - 2018-08-14 13:26:58 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:26:58 --> Controller Class Initialized
DEBUG - 2018-08-14 13:26:58 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:26:58 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:26:58 --> Final output sent to browser
DEBUG - 2018-08-14 13:26:58 --> Total execution time: 0.3118
INFO - 2018-08-14 13:26:58 --> Config Class Initialized
INFO - 2018-08-14 13:26:58 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:26:58 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:26:58 --> Utf8 Class Initialized
INFO - 2018-08-14 13:26:58 --> URI Class Initialized
INFO - 2018-08-14 13:26:58 --> Router Class Initialized
INFO - 2018-08-14 13:26:58 --> Output Class Initialized
INFO - 2018-08-14 13:26:58 --> Security Class Initialized
DEBUG - 2018-08-14 13:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:26:58 --> Input Class Initialized
INFO - 2018-08-14 13:26:58 --> Language Class Initialized
ERROR - 2018-08-14 13:26:58 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:26:58 --> Config Class Initialized
INFO - 2018-08-14 13:26:58 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:26:58 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:26:58 --> Utf8 Class Initialized
INFO - 2018-08-14 13:26:58 --> URI Class Initialized
INFO - 2018-08-14 13:26:58 --> Router Class Initialized
INFO - 2018-08-14 13:26:58 --> Output Class Initialized
INFO - 2018-08-14 13:26:58 --> Security Class Initialized
DEBUG - 2018-08-14 13:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:26:58 --> Input Class Initialized
INFO - 2018-08-14 13:26:58 --> Language Class Initialized
INFO - 2018-08-14 13:26:58 --> Language Class Initialized
INFO - 2018-08-14 13:26:58 --> Config Class Initialized
INFO - 2018-08-14 13:26:58 --> Loader Class Initialized
INFO - 2018-08-14 13:26:58 --> Helper loaded: url_helper
INFO - 2018-08-14 13:26:58 --> Helper loaded: file_helper
INFO - 2018-08-14 13:26:58 --> Helper loaded: form_helper
INFO - 2018-08-14 13:26:58 --> Helper loaded: my_helper
INFO - 2018-08-14 13:26:58 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:26:58 --> Controller Class Initialized
INFO - 2018-08-14 13:27:01 --> Config Class Initialized
INFO - 2018-08-14 13:27:01 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:27:01 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:27:01 --> Utf8 Class Initialized
INFO - 2018-08-14 13:27:01 --> URI Class Initialized
INFO - 2018-08-14 13:27:01 --> Router Class Initialized
INFO - 2018-08-14 13:27:01 --> Output Class Initialized
INFO - 2018-08-14 13:27:01 --> Security Class Initialized
DEBUG - 2018-08-14 13:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:27:01 --> Input Class Initialized
INFO - 2018-08-14 13:27:01 --> Language Class Initialized
INFO - 2018-08-14 13:27:01 --> Language Class Initialized
INFO - 2018-08-14 13:27:01 --> Config Class Initialized
INFO - 2018-08-14 13:27:01 --> Loader Class Initialized
INFO - 2018-08-14 13:27:01 --> Helper loaded: url_helper
INFO - 2018-08-14 13:27:01 --> Helper loaded: file_helper
INFO - 2018-08-14 13:27:01 --> Helper loaded: form_helper
INFO - 2018-08-14 13:27:01 --> Helper loaded: my_helper
INFO - 2018-08-14 13:27:01 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:27:01 --> Controller Class Initialized
INFO - 2018-08-14 13:27:01 --> Final output sent to browser
DEBUG - 2018-08-14 13:27:01 --> Total execution time: 0.3260
INFO - 2018-08-14 13:27:01 --> Config Class Initialized
INFO - 2018-08-14 13:27:01 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:27:01 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:27:01 --> Utf8 Class Initialized
INFO - 2018-08-14 13:27:01 --> URI Class Initialized
INFO - 2018-08-14 13:27:01 --> Router Class Initialized
INFO - 2018-08-14 13:27:01 --> Output Class Initialized
INFO - 2018-08-14 13:27:01 --> Security Class Initialized
DEBUG - 2018-08-14 13:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:27:01 --> Input Class Initialized
INFO - 2018-08-14 13:27:01 --> Language Class Initialized
INFO - 2018-08-14 13:27:01 --> Language Class Initialized
INFO - 2018-08-14 13:27:01 --> Config Class Initialized
INFO - 2018-08-14 13:27:01 --> Loader Class Initialized
INFO - 2018-08-14 13:27:01 --> Helper loaded: url_helper
INFO - 2018-08-14 13:27:01 --> Helper loaded: file_helper
INFO - 2018-08-14 13:27:01 --> Helper loaded: form_helper
INFO - 2018-08-14 13:27:01 --> Helper loaded: my_helper
INFO - 2018-08-14 13:27:02 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:27:02 --> Controller Class Initialized
INFO - 2018-08-14 13:27:40 --> Config Class Initialized
INFO - 2018-08-14 13:27:40 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:27:40 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:27:40 --> Utf8 Class Initialized
INFO - 2018-08-14 13:27:40 --> URI Class Initialized
INFO - 2018-08-14 13:27:40 --> Router Class Initialized
INFO - 2018-08-14 13:27:40 --> Output Class Initialized
INFO - 2018-08-14 13:27:40 --> Security Class Initialized
DEBUG - 2018-08-14 13:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:27:40 --> Input Class Initialized
INFO - 2018-08-14 13:27:40 --> Language Class Initialized
INFO - 2018-08-14 13:27:40 --> Language Class Initialized
INFO - 2018-08-14 13:27:40 --> Config Class Initialized
INFO - 2018-08-14 13:27:40 --> Loader Class Initialized
INFO - 2018-08-14 13:27:40 --> Helper loaded: url_helper
INFO - 2018-08-14 13:27:40 --> Helper loaded: file_helper
INFO - 2018-08-14 13:27:40 --> Helper loaded: form_helper
INFO - 2018-08-14 13:27:40 --> Helper loaded: my_helper
INFO - 2018-08-14 13:27:40 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:27:40 --> Controller Class Initialized
DEBUG - 2018-08-14 13:27:40 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:27:40 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:27:40 --> Final output sent to browser
DEBUG - 2018-08-14 13:27:40 --> Total execution time: 0.4128
INFO - 2018-08-14 13:27:41 --> Config Class Initialized
INFO - 2018-08-14 13:27:41 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:27:41 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:27:41 --> Utf8 Class Initialized
INFO - 2018-08-14 13:27:41 --> URI Class Initialized
INFO - 2018-08-14 13:27:41 --> Router Class Initialized
INFO - 2018-08-14 13:27:41 --> Output Class Initialized
INFO - 2018-08-14 13:27:41 --> Security Class Initialized
DEBUG - 2018-08-14 13:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:27:41 --> Input Class Initialized
INFO - 2018-08-14 13:27:41 --> Language Class Initialized
ERROR - 2018-08-14 13:27:41 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:27:41 --> Config Class Initialized
INFO - 2018-08-14 13:27:41 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:27:41 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:27:41 --> Utf8 Class Initialized
INFO - 2018-08-14 13:27:41 --> URI Class Initialized
INFO - 2018-08-14 13:27:41 --> Router Class Initialized
INFO - 2018-08-14 13:27:41 --> Output Class Initialized
INFO - 2018-08-14 13:27:41 --> Security Class Initialized
DEBUG - 2018-08-14 13:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:27:41 --> Input Class Initialized
INFO - 2018-08-14 13:27:41 --> Language Class Initialized
INFO - 2018-08-14 13:27:41 --> Language Class Initialized
INFO - 2018-08-14 13:27:41 --> Config Class Initialized
INFO - 2018-08-14 13:27:41 --> Loader Class Initialized
INFO - 2018-08-14 13:27:41 --> Helper loaded: url_helper
INFO - 2018-08-14 13:27:41 --> Helper loaded: file_helper
INFO - 2018-08-14 13:27:41 --> Helper loaded: form_helper
INFO - 2018-08-14 13:27:41 --> Helper loaded: my_helper
INFO - 2018-08-14 13:27:41 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:27:41 --> Controller Class Initialized
INFO - 2018-08-14 13:28:02 --> Config Class Initialized
INFO - 2018-08-14 13:28:02 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:28:02 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:28:02 --> Utf8 Class Initialized
INFO - 2018-08-14 13:28:02 --> URI Class Initialized
INFO - 2018-08-14 13:28:02 --> Router Class Initialized
INFO - 2018-08-14 13:28:02 --> Output Class Initialized
INFO - 2018-08-14 13:28:02 --> Security Class Initialized
DEBUG - 2018-08-14 13:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:28:02 --> Input Class Initialized
INFO - 2018-08-14 13:28:02 --> Language Class Initialized
INFO - 2018-08-14 13:28:02 --> Language Class Initialized
INFO - 2018-08-14 13:28:02 --> Config Class Initialized
INFO - 2018-08-14 13:28:02 --> Loader Class Initialized
INFO - 2018-08-14 13:28:02 --> Helper loaded: url_helper
INFO - 2018-08-14 13:28:02 --> Helper loaded: file_helper
INFO - 2018-08-14 13:28:02 --> Helper loaded: form_helper
INFO - 2018-08-14 13:28:02 --> Helper loaded: my_helper
INFO - 2018-08-14 13:28:02 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:28:02 --> Controller Class Initialized
DEBUG - 2018-08-14 13:28:02 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:28:02 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:28:02 --> Final output sent to browser
DEBUG - 2018-08-14 13:28:02 --> Total execution time: 0.4791
INFO - 2018-08-14 13:28:02 --> Config Class Initialized
INFO - 2018-08-14 13:28:02 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:28:02 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:28:03 --> Utf8 Class Initialized
INFO - 2018-08-14 13:28:03 --> URI Class Initialized
INFO - 2018-08-14 13:28:03 --> Router Class Initialized
INFO - 2018-08-14 13:28:03 --> Output Class Initialized
INFO - 2018-08-14 13:28:03 --> Security Class Initialized
DEBUG - 2018-08-14 13:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:28:03 --> Input Class Initialized
INFO - 2018-08-14 13:28:03 --> Language Class Initialized
ERROR - 2018-08-14 13:28:03 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:28:03 --> Config Class Initialized
INFO - 2018-08-14 13:28:03 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:28:03 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:28:03 --> Utf8 Class Initialized
INFO - 2018-08-14 13:28:03 --> URI Class Initialized
INFO - 2018-08-14 13:28:03 --> Router Class Initialized
INFO - 2018-08-14 13:28:03 --> Output Class Initialized
INFO - 2018-08-14 13:28:03 --> Security Class Initialized
DEBUG - 2018-08-14 13:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:28:03 --> Input Class Initialized
INFO - 2018-08-14 13:28:03 --> Language Class Initialized
INFO - 2018-08-14 13:28:03 --> Language Class Initialized
INFO - 2018-08-14 13:28:03 --> Config Class Initialized
INFO - 2018-08-14 13:28:03 --> Loader Class Initialized
INFO - 2018-08-14 13:28:03 --> Helper loaded: url_helper
INFO - 2018-08-14 13:28:03 --> Helper loaded: file_helper
INFO - 2018-08-14 13:28:03 --> Helper loaded: form_helper
INFO - 2018-08-14 13:28:03 --> Helper loaded: my_helper
INFO - 2018-08-14 13:28:03 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:28:03 --> Controller Class Initialized
INFO - 2018-08-14 13:28:22 --> Config Class Initialized
INFO - 2018-08-14 13:28:22 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:28:22 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:28:22 --> Utf8 Class Initialized
INFO - 2018-08-14 13:28:22 --> URI Class Initialized
INFO - 2018-08-14 13:28:22 --> Router Class Initialized
INFO - 2018-08-14 13:28:22 --> Output Class Initialized
INFO - 2018-08-14 13:28:22 --> Security Class Initialized
DEBUG - 2018-08-14 13:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:28:23 --> Input Class Initialized
INFO - 2018-08-14 13:28:23 --> Language Class Initialized
INFO - 2018-08-14 13:28:23 --> Language Class Initialized
INFO - 2018-08-14 13:28:23 --> Config Class Initialized
INFO - 2018-08-14 13:28:23 --> Loader Class Initialized
INFO - 2018-08-14 13:28:23 --> Helper loaded: url_helper
INFO - 2018-08-14 13:28:23 --> Helper loaded: file_helper
INFO - 2018-08-14 13:28:23 --> Helper loaded: form_helper
INFO - 2018-08-14 13:28:23 --> Helper loaded: my_helper
INFO - 2018-08-14 13:28:23 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:28:23 --> Controller Class Initialized
INFO - 2018-08-14 13:28:23 --> Final output sent to browser
DEBUG - 2018-08-14 13:28:23 --> Total execution time: 0.4398
INFO - 2018-08-14 13:30:03 --> Config Class Initialized
INFO - 2018-08-14 13:30:03 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:30:03 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:30:03 --> Utf8 Class Initialized
INFO - 2018-08-14 13:30:03 --> URI Class Initialized
INFO - 2018-08-14 13:30:03 --> Router Class Initialized
INFO - 2018-08-14 13:30:03 --> Output Class Initialized
INFO - 2018-08-14 13:30:03 --> Security Class Initialized
DEBUG - 2018-08-14 13:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:30:03 --> Input Class Initialized
INFO - 2018-08-14 13:30:03 --> Language Class Initialized
INFO - 2018-08-14 13:30:03 --> Language Class Initialized
INFO - 2018-08-14 13:30:03 --> Config Class Initialized
INFO - 2018-08-14 13:30:03 --> Loader Class Initialized
INFO - 2018-08-14 13:30:03 --> Helper loaded: url_helper
INFO - 2018-08-14 13:30:03 --> Helper loaded: file_helper
INFO - 2018-08-14 13:30:03 --> Helper loaded: form_helper
INFO - 2018-08-14 13:30:03 --> Helper loaded: my_helper
INFO - 2018-08-14 13:30:03 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:30:03 --> Controller Class Initialized
DEBUG - 2018-08-14 13:30:03 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:30:03 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:30:03 --> Final output sent to browser
DEBUG - 2018-08-14 13:30:03 --> Total execution time: 0.3264
INFO - 2018-08-14 13:30:03 --> Config Class Initialized
INFO - 2018-08-14 13:30:03 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:30:03 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:30:03 --> Utf8 Class Initialized
INFO - 2018-08-14 13:30:03 --> URI Class Initialized
INFO - 2018-08-14 13:30:03 --> Router Class Initialized
INFO - 2018-08-14 13:30:03 --> Output Class Initialized
INFO - 2018-08-14 13:30:03 --> Security Class Initialized
DEBUG - 2018-08-14 13:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:30:03 --> Input Class Initialized
INFO - 2018-08-14 13:30:03 --> Language Class Initialized
ERROR - 2018-08-14 13:30:03 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:30:03 --> Config Class Initialized
INFO - 2018-08-14 13:30:03 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:30:03 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:30:03 --> Utf8 Class Initialized
INFO - 2018-08-14 13:30:03 --> URI Class Initialized
INFO - 2018-08-14 13:30:03 --> Router Class Initialized
INFO - 2018-08-14 13:30:03 --> Output Class Initialized
INFO - 2018-08-14 13:30:03 --> Security Class Initialized
DEBUG - 2018-08-14 13:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:30:03 --> Input Class Initialized
INFO - 2018-08-14 13:30:03 --> Language Class Initialized
INFO - 2018-08-14 13:30:03 --> Language Class Initialized
INFO - 2018-08-14 13:30:03 --> Config Class Initialized
INFO - 2018-08-14 13:30:03 --> Loader Class Initialized
INFO - 2018-08-14 13:30:03 --> Helper loaded: url_helper
INFO - 2018-08-14 13:30:03 --> Helper loaded: file_helper
INFO - 2018-08-14 13:30:03 --> Helper loaded: form_helper
INFO - 2018-08-14 13:30:03 --> Helper loaded: my_helper
INFO - 2018-08-14 13:30:03 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:30:04 --> Controller Class Initialized
INFO - 2018-08-14 13:30:04 --> Config Class Initialized
INFO - 2018-08-14 13:30:04 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:30:04 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:30:04 --> Utf8 Class Initialized
INFO - 2018-08-14 13:30:04 --> URI Class Initialized
INFO - 2018-08-14 13:30:04 --> Router Class Initialized
INFO - 2018-08-14 13:30:04 --> Output Class Initialized
INFO - 2018-08-14 13:30:04 --> Security Class Initialized
DEBUG - 2018-08-14 13:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:30:05 --> Input Class Initialized
INFO - 2018-08-14 13:30:05 --> Language Class Initialized
INFO - 2018-08-14 13:30:05 --> Language Class Initialized
INFO - 2018-08-14 13:30:05 --> Config Class Initialized
INFO - 2018-08-14 13:30:05 --> Loader Class Initialized
INFO - 2018-08-14 13:30:05 --> Helper loaded: url_helper
INFO - 2018-08-14 13:30:05 --> Helper loaded: file_helper
INFO - 2018-08-14 13:30:05 --> Helper loaded: form_helper
INFO - 2018-08-14 13:30:05 --> Helper loaded: my_helper
INFO - 2018-08-14 13:30:05 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:30:05 --> Controller Class Initialized
INFO - 2018-08-14 13:30:05 --> Final output sent to browser
DEBUG - 2018-08-14 13:30:05 --> Total execution time: 0.3262
INFO - 2018-08-14 13:30:14 --> Config Class Initialized
INFO - 2018-08-14 13:30:14 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:30:14 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:30:14 --> Utf8 Class Initialized
INFO - 2018-08-14 13:30:14 --> URI Class Initialized
INFO - 2018-08-14 13:30:14 --> Router Class Initialized
INFO - 2018-08-14 13:30:14 --> Output Class Initialized
INFO - 2018-08-14 13:30:14 --> Security Class Initialized
DEBUG - 2018-08-14 13:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:30:14 --> Input Class Initialized
INFO - 2018-08-14 13:30:14 --> Language Class Initialized
INFO - 2018-08-14 13:30:14 --> Language Class Initialized
INFO - 2018-08-14 13:30:14 --> Config Class Initialized
INFO - 2018-08-14 13:30:14 --> Loader Class Initialized
INFO - 2018-08-14 13:30:14 --> Helper loaded: url_helper
INFO - 2018-08-14 13:30:14 --> Helper loaded: file_helper
INFO - 2018-08-14 13:30:14 --> Helper loaded: form_helper
INFO - 2018-08-14 13:30:14 --> Helper loaded: my_helper
INFO - 2018-08-14 13:30:14 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:30:14 --> Controller Class Initialized
INFO - 2018-08-14 13:30:14 --> Final output sent to browser
DEBUG - 2018-08-14 13:30:14 --> Total execution time: 0.3705
INFO - 2018-08-14 13:30:14 --> Config Class Initialized
INFO - 2018-08-14 13:30:15 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:30:15 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:30:15 --> Utf8 Class Initialized
INFO - 2018-08-14 13:30:15 --> URI Class Initialized
INFO - 2018-08-14 13:30:15 --> Router Class Initialized
INFO - 2018-08-14 13:30:15 --> Output Class Initialized
INFO - 2018-08-14 13:30:15 --> Security Class Initialized
DEBUG - 2018-08-14 13:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:30:15 --> Input Class Initialized
INFO - 2018-08-14 13:30:15 --> Language Class Initialized
INFO - 2018-08-14 13:30:15 --> Language Class Initialized
INFO - 2018-08-14 13:30:15 --> Config Class Initialized
INFO - 2018-08-14 13:30:15 --> Loader Class Initialized
INFO - 2018-08-14 13:30:15 --> Helper loaded: url_helper
INFO - 2018-08-14 13:30:15 --> Helper loaded: file_helper
INFO - 2018-08-14 13:30:15 --> Helper loaded: form_helper
INFO - 2018-08-14 13:30:15 --> Helper loaded: my_helper
INFO - 2018-08-14 13:30:15 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:30:15 --> Controller Class Initialized
INFO - 2018-08-14 13:30:17 --> Config Class Initialized
INFO - 2018-08-14 13:30:17 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:30:17 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:30:17 --> Utf8 Class Initialized
INFO - 2018-08-14 13:30:17 --> URI Class Initialized
INFO - 2018-08-14 13:30:17 --> Router Class Initialized
INFO - 2018-08-14 13:30:17 --> Output Class Initialized
INFO - 2018-08-14 13:30:17 --> Security Class Initialized
DEBUG - 2018-08-14 13:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:30:17 --> Input Class Initialized
INFO - 2018-08-14 13:30:17 --> Language Class Initialized
INFO - 2018-08-14 13:30:17 --> Language Class Initialized
INFO - 2018-08-14 13:30:17 --> Config Class Initialized
INFO - 2018-08-14 13:30:17 --> Loader Class Initialized
INFO - 2018-08-14 13:30:17 --> Helper loaded: url_helper
INFO - 2018-08-14 13:30:17 --> Helper loaded: file_helper
INFO - 2018-08-14 13:30:17 --> Helper loaded: form_helper
INFO - 2018-08-14 13:30:17 --> Helper loaded: my_helper
INFO - 2018-08-14 13:30:17 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:30:17 --> Controller Class Initialized
INFO - 2018-08-14 13:30:17 --> Final output sent to browser
DEBUG - 2018-08-14 13:30:17 --> Total execution time: 0.3060
INFO - 2018-08-14 13:30:23 --> Config Class Initialized
INFO - 2018-08-14 13:30:23 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:30:23 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:30:23 --> Utf8 Class Initialized
INFO - 2018-08-14 13:30:23 --> URI Class Initialized
INFO - 2018-08-14 13:30:23 --> Router Class Initialized
INFO - 2018-08-14 13:30:23 --> Output Class Initialized
INFO - 2018-08-14 13:30:23 --> Security Class Initialized
DEBUG - 2018-08-14 13:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:30:23 --> Input Class Initialized
INFO - 2018-08-14 13:30:23 --> Language Class Initialized
INFO - 2018-08-14 13:30:23 --> Language Class Initialized
INFO - 2018-08-14 13:30:23 --> Config Class Initialized
INFO - 2018-08-14 13:30:23 --> Loader Class Initialized
INFO - 2018-08-14 13:30:23 --> Helper loaded: url_helper
INFO - 2018-08-14 13:30:23 --> Helper loaded: file_helper
INFO - 2018-08-14 13:30:23 --> Helper loaded: form_helper
INFO - 2018-08-14 13:30:23 --> Helper loaded: my_helper
INFO - 2018-08-14 13:30:23 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:30:23 --> Controller Class Initialized
INFO - 2018-08-14 13:30:23 --> Final output sent to browser
DEBUG - 2018-08-14 13:30:23 --> Total execution time: 0.3121
INFO - 2018-08-14 13:30:23 --> Config Class Initialized
INFO - 2018-08-14 13:30:23 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:30:23 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:30:23 --> Utf8 Class Initialized
INFO - 2018-08-14 13:30:23 --> URI Class Initialized
INFO - 2018-08-14 13:30:23 --> Router Class Initialized
INFO - 2018-08-14 13:30:23 --> Output Class Initialized
INFO - 2018-08-14 13:30:23 --> Security Class Initialized
DEBUG - 2018-08-14 13:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:30:23 --> Input Class Initialized
INFO - 2018-08-14 13:30:23 --> Language Class Initialized
INFO - 2018-08-14 13:30:23 --> Language Class Initialized
INFO - 2018-08-14 13:30:23 --> Config Class Initialized
INFO - 2018-08-14 13:30:23 --> Loader Class Initialized
INFO - 2018-08-14 13:30:23 --> Helper loaded: url_helper
INFO - 2018-08-14 13:30:23 --> Helper loaded: file_helper
INFO - 2018-08-14 13:30:23 --> Helper loaded: form_helper
INFO - 2018-08-14 13:30:23 --> Helper loaded: my_helper
INFO - 2018-08-14 13:30:23 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:30:23 --> Controller Class Initialized
INFO - 2018-08-14 13:30:24 --> Config Class Initialized
INFO - 2018-08-14 13:30:24 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:30:24 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:30:24 --> Utf8 Class Initialized
INFO - 2018-08-14 13:30:24 --> URI Class Initialized
INFO - 2018-08-14 13:30:25 --> Router Class Initialized
INFO - 2018-08-14 13:30:25 --> Output Class Initialized
INFO - 2018-08-14 13:30:25 --> Security Class Initialized
DEBUG - 2018-08-14 13:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:30:25 --> Input Class Initialized
INFO - 2018-08-14 13:30:25 --> Language Class Initialized
INFO - 2018-08-14 13:30:25 --> Language Class Initialized
INFO - 2018-08-14 13:30:25 --> Config Class Initialized
INFO - 2018-08-14 13:30:25 --> Loader Class Initialized
INFO - 2018-08-14 13:30:25 --> Helper loaded: url_helper
INFO - 2018-08-14 13:30:25 --> Helper loaded: file_helper
INFO - 2018-08-14 13:30:25 --> Helper loaded: form_helper
INFO - 2018-08-14 13:30:25 --> Helper loaded: my_helper
INFO - 2018-08-14 13:30:25 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:30:25 --> Controller Class Initialized
INFO - 2018-08-14 13:30:25 --> Final output sent to browser
DEBUG - 2018-08-14 13:30:25 --> Total execution time: 0.2990
INFO - 2018-08-14 13:30:35 --> Config Class Initialized
INFO - 2018-08-14 13:30:35 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:30:35 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:30:35 --> Utf8 Class Initialized
INFO - 2018-08-14 13:30:35 --> URI Class Initialized
INFO - 2018-08-14 13:30:35 --> Router Class Initialized
INFO - 2018-08-14 13:30:35 --> Output Class Initialized
INFO - 2018-08-14 13:30:35 --> Security Class Initialized
DEBUG - 2018-08-14 13:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:30:35 --> Input Class Initialized
INFO - 2018-08-14 13:30:35 --> Language Class Initialized
INFO - 2018-08-14 13:30:35 --> Language Class Initialized
INFO - 2018-08-14 13:30:35 --> Config Class Initialized
INFO - 2018-08-14 13:30:35 --> Loader Class Initialized
INFO - 2018-08-14 13:30:35 --> Helper loaded: url_helper
INFO - 2018-08-14 13:30:35 --> Helper loaded: file_helper
INFO - 2018-08-14 13:30:35 --> Helper loaded: form_helper
INFO - 2018-08-14 13:30:35 --> Helper loaded: my_helper
INFO - 2018-08-14 13:30:35 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:30:35 --> Controller Class Initialized
INFO - 2018-08-14 13:30:35 --> Final output sent to browser
DEBUG - 2018-08-14 13:30:35 --> Total execution time: 0.3666
INFO - 2018-08-14 13:30:35 --> Config Class Initialized
INFO - 2018-08-14 13:30:35 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:30:35 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:30:35 --> Utf8 Class Initialized
INFO - 2018-08-14 13:30:35 --> URI Class Initialized
INFO - 2018-08-14 13:30:35 --> Router Class Initialized
INFO - 2018-08-14 13:30:35 --> Output Class Initialized
INFO - 2018-08-14 13:30:35 --> Security Class Initialized
DEBUG - 2018-08-14 13:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:30:35 --> Input Class Initialized
INFO - 2018-08-14 13:30:35 --> Language Class Initialized
INFO - 2018-08-14 13:30:35 --> Language Class Initialized
INFO - 2018-08-14 13:30:35 --> Config Class Initialized
INFO - 2018-08-14 13:30:35 --> Loader Class Initialized
INFO - 2018-08-14 13:30:35 --> Helper loaded: url_helper
INFO - 2018-08-14 13:30:35 --> Helper loaded: file_helper
INFO - 2018-08-14 13:30:35 --> Helper loaded: form_helper
INFO - 2018-08-14 13:30:35 --> Helper loaded: my_helper
INFO - 2018-08-14 13:30:35 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:30:35 --> Controller Class Initialized
INFO - 2018-08-14 13:30:37 --> Config Class Initialized
INFO - 2018-08-14 13:30:37 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:30:37 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:30:37 --> Utf8 Class Initialized
INFO - 2018-08-14 13:30:37 --> URI Class Initialized
INFO - 2018-08-14 13:30:37 --> Router Class Initialized
INFO - 2018-08-14 13:30:37 --> Output Class Initialized
INFO - 2018-08-14 13:30:37 --> Security Class Initialized
DEBUG - 2018-08-14 13:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:30:37 --> Input Class Initialized
INFO - 2018-08-14 13:30:37 --> Language Class Initialized
INFO - 2018-08-14 13:30:37 --> Language Class Initialized
INFO - 2018-08-14 13:30:37 --> Config Class Initialized
INFO - 2018-08-14 13:30:37 --> Loader Class Initialized
INFO - 2018-08-14 13:30:37 --> Helper loaded: url_helper
INFO - 2018-08-14 13:30:37 --> Helper loaded: file_helper
INFO - 2018-08-14 13:30:37 --> Helper loaded: form_helper
INFO - 2018-08-14 13:30:37 --> Helper loaded: my_helper
INFO - 2018-08-14 13:30:37 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:30:37 --> Controller Class Initialized
INFO - 2018-08-14 13:30:37 --> Final output sent to browser
DEBUG - 2018-08-14 13:30:37 --> Total execution time: 0.4139
INFO - 2018-08-14 13:30:48 --> Config Class Initialized
INFO - 2018-08-14 13:30:48 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:30:48 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:30:48 --> Utf8 Class Initialized
INFO - 2018-08-14 13:30:48 --> URI Class Initialized
INFO - 2018-08-14 13:30:48 --> Router Class Initialized
INFO - 2018-08-14 13:30:48 --> Output Class Initialized
INFO - 2018-08-14 13:30:48 --> Security Class Initialized
DEBUG - 2018-08-14 13:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:30:48 --> Input Class Initialized
INFO - 2018-08-14 13:30:48 --> Language Class Initialized
INFO - 2018-08-14 13:30:48 --> Language Class Initialized
INFO - 2018-08-14 13:30:48 --> Config Class Initialized
INFO - 2018-08-14 13:30:48 --> Loader Class Initialized
INFO - 2018-08-14 13:30:48 --> Helper loaded: url_helper
INFO - 2018-08-14 13:30:48 --> Helper loaded: file_helper
INFO - 2018-08-14 13:30:48 --> Helper loaded: form_helper
INFO - 2018-08-14 13:30:48 --> Helper loaded: my_helper
INFO - 2018-08-14 13:30:48 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:30:49 --> Controller Class Initialized
INFO - 2018-08-14 13:30:49 --> Final output sent to browser
DEBUG - 2018-08-14 13:30:49 --> Total execution time: 0.3257
INFO - 2018-08-14 13:30:49 --> Config Class Initialized
INFO - 2018-08-14 13:30:49 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:30:49 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:30:49 --> Utf8 Class Initialized
INFO - 2018-08-14 13:30:49 --> URI Class Initialized
INFO - 2018-08-14 13:30:49 --> Router Class Initialized
INFO - 2018-08-14 13:30:49 --> Output Class Initialized
INFO - 2018-08-14 13:30:49 --> Security Class Initialized
DEBUG - 2018-08-14 13:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:30:49 --> Input Class Initialized
INFO - 2018-08-14 13:30:49 --> Language Class Initialized
INFO - 2018-08-14 13:30:49 --> Language Class Initialized
INFO - 2018-08-14 13:30:49 --> Config Class Initialized
INFO - 2018-08-14 13:30:49 --> Loader Class Initialized
INFO - 2018-08-14 13:30:49 --> Helper loaded: url_helper
INFO - 2018-08-14 13:30:49 --> Helper loaded: file_helper
INFO - 2018-08-14 13:30:49 --> Helper loaded: form_helper
INFO - 2018-08-14 13:30:49 --> Helper loaded: my_helper
INFO - 2018-08-14 13:30:49 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:30:49 --> Controller Class Initialized
INFO - 2018-08-14 13:30:50 --> Config Class Initialized
INFO - 2018-08-14 13:30:50 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:30:50 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:30:50 --> Utf8 Class Initialized
INFO - 2018-08-14 13:30:50 --> URI Class Initialized
INFO - 2018-08-14 13:30:50 --> Router Class Initialized
INFO - 2018-08-14 13:30:50 --> Output Class Initialized
INFO - 2018-08-14 13:30:50 --> Security Class Initialized
DEBUG - 2018-08-14 13:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:30:50 --> Input Class Initialized
INFO - 2018-08-14 13:30:50 --> Language Class Initialized
INFO - 2018-08-14 13:30:50 --> Language Class Initialized
INFO - 2018-08-14 13:30:50 --> Config Class Initialized
INFO - 2018-08-14 13:30:50 --> Loader Class Initialized
INFO - 2018-08-14 13:30:50 --> Helper loaded: url_helper
INFO - 2018-08-14 13:30:50 --> Helper loaded: file_helper
INFO - 2018-08-14 13:30:50 --> Helper loaded: form_helper
INFO - 2018-08-14 13:30:50 --> Helper loaded: my_helper
INFO - 2018-08-14 13:30:50 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:30:50 --> Controller Class Initialized
INFO - 2018-08-14 13:30:50 --> Final output sent to browser
DEBUG - 2018-08-14 13:30:50 --> Total execution time: 0.2894
INFO - 2018-08-14 13:30:56 --> Config Class Initialized
INFO - 2018-08-14 13:30:56 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:30:56 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:30:56 --> Utf8 Class Initialized
INFO - 2018-08-14 13:30:56 --> URI Class Initialized
INFO - 2018-08-14 13:30:56 --> Router Class Initialized
INFO - 2018-08-14 13:30:56 --> Output Class Initialized
INFO - 2018-08-14 13:30:56 --> Security Class Initialized
DEBUG - 2018-08-14 13:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:30:56 --> Input Class Initialized
INFO - 2018-08-14 13:30:56 --> Language Class Initialized
INFO - 2018-08-14 13:30:56 --> Language Class Initialized
INFO - 2018-08-14 13:30:56 --> Config Class Initialized
INFO - 2018-08-14 13:30:56 --> Loader Class Initialized
INFO - 2018-08-14 13:30:56 --> Helper loaded: url_helper
INFO - 2018-08-14 13:30:56 --> Helper loaded: file_helper
INFO - 2018-08-14 13:30:56 --> Helper loaded: form_helper
INFO - 2018-08-14 13:30:56 --> Helper loaded: my_helper
INFO - 2018-08-14 13:30:56 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:30:56 --> Controller Class Initialized
INFO - 2018-08-14 13:30:56 --> Final output sent to browser
DEBUG - 2018-08-14 13:30:56 --> Total execution time: 0.3222
INFO - 2018-08-14 13:30:57 --> Config Class Initialized
INFO - 2018-08-14 13:30:57 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:30:57 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:30:57 --> Utf8 Class Initialized
INFO - 2018-08-14 13:30:57 --> URI Class Initialized
INFO - 2018-08-14 13:30:57 --> Router Class Initialized
INFO - 2018-08-14 13:30:57 --> Output Class Initialized
INFO - 2018-08-14 13:30:57 --> Security Class Initialized
DEBUG - 2018-08-14 13:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:30:57 --> Input Class Initialized
INFO - 2018-08-14 13:30:57 --> Language Class Initialized
INFO - 2018-08-14 13:30:57 --> Language Class Initialized
INFO - 2018-08-14 13:30:57 --> Config Class Initialized
INFO - 2018-08-14 13:30:57 --> Loader Class Initialized
INFO - 2018-08-14 13:30:57 --> Helper loaded: url_helper
INFO - 2018-08-14 13:30:57 --> Helper loaded: file_helper
INFO - 2018-08-14 13:30:57 --> Helper loaded: form_helper
INFO - 2018-08-14 13:30:57 --> Helper loaded: my_helper
INFO - 2018-08-14 13:30:57 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:30:57 --> Controller Class Initialized
INFO - 2018-08-14 13:30:59 --> Config Class Initialized
INFO - 2018-08-14 13:30:59 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:30:59 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:30:59 --> Utf8 Class Initialized
INFO - 2018-08-14 13:30:59 --> URI Class Initialized
INFO - 2018-08-14 13:30:59 --> Router Class Initialized
INFO - 2018-08-14 13:30:59 --> Output Class Initialized
INFO - 2018-08-14 13:30:59 --> Security Class Initialized
DEBUG - 2018-08-14 13:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:30:59 --> Input Class Initialized
INFO - 2018-08-14 13:30:59 --> Language Class Initialized
INFO - 2018-08-14 13:30:59 --> Language Class Initialized
INFO - 2018-08-14 13:30:59 --> Config Class Initialized
INFO - 2018-08-14 13:30:59 --> Loader Class Initialized
INFO - 2018-08-14 13:30:59 --> Helper loaded: url_helper
INFO - 2018-08-14 13:30:59 --> Helper loaded: file_helper
INFO - 2018-08-14 13:30:59 --> Helper loaded: form_helper
INFO - 2018-08-14 13:30:59 --> Helper loaded: my_helper
INFO - 2018-08-14 13:30:59 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:30:59 --> Controller Class Initialized
INFO - 2018-08-14 13:30:59 --> Final output sent to browser
DEBUG - 2018-08-14 13:30:59 --> Total execution time: 0.3479
INFO - 2018-08-14 13:30:59 --> Config Class Initialized
INFO - 2018-08-14 13:30:59 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:30:59 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:30:59 --> Utf8 Class Initialized
INFO - 2018-08-14 13:30:59 --> URI Class Initialized
INFO - 2018-08-14 13:30:59 --> Router Class Initialized
INFO - 2018-08-14 13:30:59 --> Output Class Initialized
INFO - 2018-08-14 13:30:59 --> Security Class Initialized
DEBUG - 2018-08-14 13:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:30:59 --> Input Class Initialized
INFO - 2018-08-14 13:30:59 --> Language Class Initialized
INFO - 2018-08-14 13:30:59 --> Language Class Initialized
INFO - 2018-08-14 13:30:59 --> Config Class Initialized
INFO - 2018-08-14 13:30:59 --> Loader Class Initialized
INFO - 2018-08-14 13:30:59 --> Helper loaded: url_helper
INFO - 2018-08-14 13:30:59 --> Helper loaded: file_helper
INFO - 2018-08-14 13:30:59 --> Helper loaded: form_helper
INFO - 2018-08-14 13:30:59 --> Helper loaded: my_helper
INFO - 2018-08-14 13:30:59 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:30:59 --> Controller Class Initialized
INFO - 2018-08-14 13:32:54 --> Config Class Initialized
INFO - 2018-08-14 13:32:54 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:32:54 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:32:54 --> Utf8 Class Initialized
INFO - 2018-08-14 13:32:54 --> URI Class Initialized
INFO - 2018-08-14 13:32:54 --> Router Class Initialized
INFO - 2018-08-14 13:32:54 --> Output Class Initialized
INFO - 2018-08-14 13:32:54 --> Security Class Initialized
DEBUG - 2018-08-14 13:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:32:54 --> Input Class Initialized
INFO - 2018-08-14 13:32:54 --> Language Class Initialized
INFO - 2018-08-14 13:32:55 --> Language Class Initialized
INFO - 2018-08-14 13:32:55 --> Config Class Initialized
INFO - 2018-08-14 13:32:55 --> Loader Class Initialized
INFO - 2018-08-14 13:32:55 --> Helper loaded: url_helper
INFO - 2018-08-14 13:32:55 --> Helper loaded: file_helper
INFO - 2018-08-14 13:32:55 --> Helper loaded: form_helper
INFO - 2018-08-14 13:32:55 --> Helper loaded: my_helper
INFO - 2018-08-14 13:32:55 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:32:55 --> Controller Class Initialized
DEBUG - 2018-08-14 13:32:55 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:32:55 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:32:55 --> Final output sent to browser
DEBUG - 2018-08-14 13:32:55 --> Total execution time: 0.3351
INFO - 2018-08-14 13:32:55 --> Config Class Initialized
INFO - 2018-08-14 13:32:55 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:32:55 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:32:55 --> Utf8 Class Initialized
INFO - 2018-08-14 13:32:55 --> URI Class Initialized
INFO - 2018-08-14 13:32:55 --> Router Class Initialized
INFO - 2018-08-14 13:32:55 --> Output Class Initialized
INFO - 2018-08-14 13:32:55 --> Security Class Initialized
DEBUG - 2018-08-14 13:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:32:55 --> Input Class Initialized
INFO - 2018-08-14 13:32:55 --> Language Class Initialized
ERROR - 2018-08-14 13:32:55 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:32:55 --> Config Class Initialized
INFO - 2018-08-14 13:32:55 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:32:55 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:32:55 --> Utf8 Class Initialized
INFO - 2018-08-14 13:32:55 --> URI Class Initialized
INFO - 2018-08-14 13:32:55 --> Router Class Initialized
INFO - 2018-08-14 13:32:55 --> Output Class Initialized
INFO - 2018-08-14 13:32:55 --> Security Class Initialized
DEBUG - 2018-08-14 13:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:32:55 --> Input Class Initialized
INFO - 2018-08-14 13:32:55 --> Language Class Initialized
INFO - 2018-08-14 13:32:55 --> Language Class Initialized
INFO - 2018-08-14 13:32:55 --> Config Class Initialized
INFO - 2018-08-14 13:32:55 --> Loader Class Initialized
INFO - 2018-08-14 13:32:55 --> Helper loaded: url_helper
INFO - 2018-08-14 13:32:55 --> Helper loaded: file_helper
INFO - 2018-08-14 13:32:55 --> Helper loaded: form_helper
INFO - 2018-08-14 13:32:55 --> Helper loaded: my_helper
INFO - 2018-08-14 13:32:55 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:32:55 --> Controller Class Initialized
INFO - 2018-08-14 13:33:16 --> Config Class Initialized
INFO - 2018-08-14 13:33:17 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:33:17 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:33:17 --> Utf8 Class Initialized
INFO - 2018-08-14 13:33:17 --> URI Class Initialized
INFO - 2018-08-14 13:33:17 --> Router Class Initialized
INFO - 2018-08-14 13:33:17 --> Output Class Initialized
INFO - 2018-08-14 13:33:17 --> Security Class Initialized
DEBUG - 2018-08-14 13:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:33:17 --> Input Class Initialized
INFO - 2018-08-14 13:33:17 --> Language Class Initialized
INFO - 2018-08-14 13:33:17 --> Language Class Initialized
INFO - 2018-08-14 13:33:17 --> Config Class Initialized
INFO - 2018-08-14 13:33:17 --> Loader Class Initialized
INFO - 2018-08-14 13:33:17 --> Helper loaded: url_helper
INFO - 2018-08-14 13:33:17 --> Helper loaded: file_helper
INFO - 2018-08-14 13:33:17 --> Helper loaded: form_helper
INFO - 2018-08-14 13:33:17 --> Helper loaded: my_helper
INFO - 2018-08-14 13:33:17 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:33:17 --> Controller Class Initialized
DEBUG - 2018-08-14 13:33:17 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:33:17 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:33:17 --> Final output sent to browser
DEBUG - 2018-08-14 13:33:17 --> Total execution time: 0.3167
INFO - 2018-08-14 13:33:17 --> Config Class Initialized
INFO - 2018-08-14 13:33:17 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:33:17 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:33:17 --> Utf8 Class Initialized
INFO - 2018-08-14 13:33:17 --> URI Class Initialized
INFO - 2018-08-14 13:33:17 --> Router Class Initialized
INFO - 2018-08-14 13:33:17 --> Output Class Initialized
INFO - 2018-08-14 13:33:17 --> Security Class Initialized
DEBUG - 2018-08-14 13:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:33:17 --> Input Class Initialized
INFO - 2018-08-14 13:33:17 --> Language Class Initialized
ERROR - 2018-08-14 13:33:17 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:33:17 --> Config Class Initialized
INFO - 2018-08-14 13:33:17 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:33:17 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:33:17 --> Utf8 Class Initialized
INFO - 2018-08-14 13:33:17 --> URI Class Initialized
INFO - 2018-08-14 13:33:17 --> Router Class Initialized
INFO - 2018-08-14 13:33:17 --> Output Class Initialized
INFO - 2018-08-14 13:33:17 --> Security Class Initialized
DEBUG - 2018-08-14 13:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:33:17 --> Input Class Initialized
INFO - 2018-08-14 13:33:17 --> Language Class Initialized
INFO - 2018-08-14 13:33:17 --> Language Class Initialized
INFO - 2018-08-14 13:33:17 --> Config Class Initialized
INFO - 2018-08-14 13:33:17 --> Loader Class Initialized
INFO - 2018-08-14 13:33:17 --> Helper loaded: url_helper
INFO - 2018-08-14 13:33:17 --> Helper loaded: file_helper
INFO - 2018-08-14 13:33:17 --> Helper loaded: form_helper
INFO - 2018-08-14 13:33:17 --> Helper loaded: my_helper
INFO - 2018-08-14 13:33:17 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:33:17 --> Controller Class Initialized
INFO - 2018-08-14 13:33:18 --> Config Class Initialized
INFO - 2018-08-14 13:33:18 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:33:18 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:33:18 --> Utf8 Class Initialized
INFO - 2018-08-14 13:33:18 --> URI Class Initialized
INFO - 2018-08-14 13:33:19 --> Router Class Initialized
INFO - 2018-08-14 13:33:19 --> Output Class Initialized
INFO - 2018-08-14 13:33:19 --> Security Class Initialized
DEBUG - 2018-08-14 13:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:33:19 --> Input Class Initialized
INFO - 2018-08-14 13:33:19 --> Language Class Initialized
INFO - 2018-08-14 13:33:19 --> Language Class Initialized
INFO - 2018-08-14 13:33:19 --> Config Class Initialized
INFO - 2018-08-14 13:33:19 --> Loader Class Initialized
INFO - 2018-08-14 13:33:19 --> Helper loaded: url_helper
INFO - 2018-08-14 13:33:19 --> Helper loaded: file_helper
INFO - 2018-08-14 13:33:19 --> Helper loaded: form_helper
INFO - 2018-08-14 13:33:19 --> Helper loaded: my_helper
INFO - 2018-08-14 13:33:19 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:33:19 --> Controller Class Initialized
INFO - 2018-08-14 13:33:19 --> Final output sent to browser
DEBUG - 2018-08-14 13:33:19 --> Total execution time: 0.3677
INFO - 2018-08-14 13:33:19 --> Config Class Initialized
INFO - 2018-08-14 13:33:19 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:33:19 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:33:19 --> Utf8 Class Initialized
INFO - 2018-08-14 13:33:19 --> URI Class Initialized
INFO - 2018-08-14 13:33:19 --> Router Class Initialized
INFO - 2018-08-14 13:33:19 --> Output Class Initialized
INFO - 2018-08-14 13:33:19 --> Security Class Initialized
DEBUG - 2018-08-14 13:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:33:19 --> Input Class Initialized
INFO - 2018-08-14 13:33:19 --> Language Class Initialized
INFO - 2018-08-14 13:33:19 --> Language Class Initialized
INFO - 2018-08-14 13:33:19 --> Config Class Initialized
INFO - 2018-08-14 13:33:19 --> Loader Class Initialized
INFO - 2018-08-14 13:33:19 --> Helper loaded: url_helper
INFO - 2018-08-14 13:33:19 --> Helper loaded: file_helper
INFO - 2018-08-14 13:33:19 --> Helper loaded: form_helper
INFO - 2018-08-14 13:33:19 --> Helper loaded: my_helper
INFO - 2018-08-14 13:33:19 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:33:19 --> Controller Class Initialized
INFO - 2018-08-14 13:33:27 --> Config Class Initialized
INFO - 2018-08-14 13:33:27 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:33:27 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:33:27 --> Utf8 Class Initialized
INFO - 2018-08-14 13:33:27 --> URI Class Initialized
INFO - 2018-08-14 13:33:27 --> Router Class Initialized
INFO - 2018-08-14 13:33:27 --> Output Class Initialized
INFO - 2018-08-14 13:33:27 --> Security Class Initialized
DEBUG - 2018-08-14 13:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:33:27 --> Input Class Initialized
INFO - 2018-08-14 13:33:27 --> Language Class Initialized
INFO - 2018-08-14 13:33:27 --> Language Class Initialized
INFO - 2018-08-14 13:33:27 --> Config Class Initialized
INFO - 2018-08-14 13:33:27 --> Loader Class Initialized
INFO - 2018-08-14 13:33:27 --> Helper loaded: url_helper
INFO - 2018-08-14 13:33:27 --> Helper loaded: file_helper
INFO - 2018-08-14 13:33:27 --> Helper loaded: form_helper
INFO - 2018-08-14 13:33:27 --> Helper loaded: my_helper
INFO - 2018-08-14 13:33:27 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:33:27 --> Controller Class Initialized
INFO - 2018-08-14 13:33:27 --> Final output sent to browser
DEBUG - 2018-08-14 13:33:27 --> Total execution time: 0.5479
INFO - 2018-08-14 13:33:27 --> Config Class Initialized
INFO - 2018-08-14 13:33:27 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:33:27 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:33:27 --> Utf8 Class Initialized
INFO - 2018-08-14 13:33:27 --> URI Class Initialized
INFO - 2018-08-14 13:33:27 --> Router Class Initialized
INFO - 2018-08-14 13:33:27 --> Output Class Initialized
INFO - 2018-08-14 13:33:27 --> Security Class Initialized
DEBUG - 2018-08-14 13:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:33:27 --> Input Class Initialized
INFO - 2018-08-14 13:33:27 --> Language Class Initialized
INFO - 2018-08-14 13:33:27 --> Language Class Initialized
INFO - 2018-08-14 13:33:27 --> Config Class Initialized
INFO - 2018-08-14 13:33:28 --> Loader Class Initialized
INFO - 2018-08-14 13:33:28 --> Helper loaded: url_helper
INFO - 2018-08-14 13:33:28 --> Helper loaded: file_helper
INFO - 2018-08-14 13:33:28 --> Helper loaded: form_helper
INFO - 2018-08-14 13:33:28 --> Helper loaded: my_helper
INFO - 2018-08-14 13:33:28 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:33:28 --> Controller Class Initialized
INFO - 2018-08-14 13:33:34 --> Config Class Initialized
INFO - 2018-08-14 13:33:34 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:33:34 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:33:34 --> Utf8 Class Initialized
INFO - 2018-08-14 13:33:34 --> URI Class Initialized
INFO - 2018-08-14 13:33:34 --> Router Class Initialized
INFO - 2018-08-14 13:33:34 --> Output Class Initialized
INFO - 2018-08-14 13:33:34 --> Security Class Initialized
DEBUG - 2018-08-14 13:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:33:34 --> Input Class Initialized
INFO - 2018-08-14 13:33:34 --> Language Class Initialized
INFO - 2018-08-14 13:33:34 --> Language Class Initialized
INFO - 2018-08-14 13:33:34 --> Config Class Initialized
INFO - 2018-08-14 13:33:34 --> Loader Class Initialized
INFO - 2018-08-14 13:33:34 --> Helper loaded: url_helper
INFO - 2018-08-14 13:33:34 --> Helper loaded: file_helper
INFO - 2018-08-14 13:33:34 --> Helper loaded: form_helper
INFO - 2018-08-14 13:33:34 --> Helper loaded: my_helper
INFO - 2018-08-14 13:33:34 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:33:34 --> Controller Class Initialized
INFO - 2018-08-14 13:33:34 --> Final output sent to browser
DEBUG - 2018-08-14 13:33:34 --> Total execution time: 0.3567
INFO - 2018-08-14 13:33:35 --> Config Class Initialized
INFO - 2018-08-14 13:33:35 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:33:35 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:33:35 --> Utf8 Class Initialized
INFO - 2018-08-14 13:33:35 --> URI Class Initialized
INFO - 2018-08-14 13:33:35 --> Router Class Initialized
INFO - 2018-08-14 13:33:35 --> Output Class Initialized
INFO - 2018-08-14 13:33:35 --> Security Class Initialized
DEBUG - 2018-08-14 13:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:33:35 --> Input Class Initialized
INFO - 2018-08-14 13:33:35 --> Language Class Initialized
INFO - 2018-08-14 13:33:35 --> Language Class Initialized
INFO - 2018-08-14 13:33:35 --> Config Class Initialized
INFO - 2018-08-14 13:33:35 --> Loader Class Initialized
INFO - 2018-08-14 13:33:35 --> Helper loaded: url_helper
INFO - 2018-08-14 13:33:35 --> Helper loaded: file_helper
INFO - 2018-08-14 13:33:35 --> Helper loaded: form_helper
INFO - 2018-08-14 13:33:35 --> Helper loaded: my_helper
INFO - 2018-08-14 13:33:35 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:33:35 --> Controller Class Initialized
INFO - 2018-08-14 13:35:06 --> Config Class Initialized
INFO - 2018-08-14 13:35:06 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:35:06 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:35:06 --> Utf8 Class Initialized
INFO - 2018-08-14 13:35:06 --> URI Class Initialized
INFO - 2018-08-14 13:35:06 --> Router Class Initialized
INFO - 2018-08-14 13:35:06 --> Output Class Initialized
INFO - 2018-08-14 13:35:06 --> Security Class Initialized
DEBUG - 2018-08-14 13:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:35:06 --> Input Class Initialized
INFO - 2018-08-14 13:35:06 --> Language Class Initialized
INFO - 2018-08-14 13:35:06 --> Language Class Initialized
INFO - 2018-08-14 13:35:06 --> Config Class Initialized
INFO - 2018-08-14 13:35:06 --> Loader Class Initialized
INFO - 2018-08-14 13:35:06 --> Helper loaded: url_helper
INFO - 2018-08-14 13:35:06 --> Helper loaded: file_helper
INFO - 2018-08-14 13:35:06 --> Helper loaded: form_helper
INFO - 2018-08-14 13:35:06 --> Helper loaded: my_helper
INFO - 2018-08-14 13:35:06 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:35:06 --> Controller Class Initialized
INFO - 2018-08-14 13:35:06 --> Final output sent to browser
DEBUG - 2018-08-14 13:35:06 --> Total execution time: 0.3676
INFO - 2018-08-14 13:35:06 --> Config Class Initialized
INFO - 2018-08-14 13:35:06 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:35:06 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:35:06 --> Utf8 Class Initialized
INFO - 2018-08-14 13:35:06 --> URI Class Initialized
INFO - 2018-08-14 13:35:06 --> Router Class Initialized
INFO - 2018-08-14 13:35:06 --> Output Class Initialized
INFO - 2018-08-14 13:35:06 --> Security Class Initialized
DEBUG - 2018-08-14 13:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:35:06 --> Input Class Initialized
INFO - 2018-08-14 13:35:06 --> Language Class Initialized
INFO - 2018-08-14 13:35:06 --> Language Class Initialized
INFO - 2018-08-14 13:35:06 --> Config Class Initialized
INFO - 2018-08-14 13:35:06 --> Loader Class Initialized
INFO - 2018-08-14 13:35:06 --> Helper loaded: url_helper
INFO - 2018-08-14 13:35:06 --> Helper loaded: file_helper
INFO - 2018-08-14 13:35:07 --> Helper loaded: form_helper
INFO - 2018-08-14 13:35:07 --> Helper loaded: my_helper
INFO - 2018-08-14 13:35:07 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:35:07 --> Controller Class Initialized
INFO - 2018-08-14 13:37:14 --> Config Class Initialized
INFO - 2018-08-14 13:37:14 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:37:14 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:37:14 --> Utf8 Class Initialized
INFO - 2018-08-14 13:37:14 --> URI Class Initialized
INFO - 2018-08-14 13:37:14 --> Router Class Initialized
INFO - 2018-08-14 13:37:14 --> Output Class Initialized
INFO - 2018-08-14 13:37:14 --> Security Class Initialized
DEBUG - 2018-08-14 13:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:37:14 --> Input Class Initialized
INFO - 2018-08-14 13:37:14 --> Language Class Initialized
INFO - 2018-08-14 13:37:14 --> Language Class Initialized
INFO - 2018-08-14 13:37:14 --> Config Class Initialized
INFO - 2018-08-14 13:37:14 --> Loader Class Initialized
INFO - 2018-08-14 13:37:14 --> Helper loaded: url_helper
INFO - 2018-08-14 13:37:14 --> Helper loaded: file_helper
INFO - 2018-08-14 13:37:14 --> Helper loaded: form_helper
INFO - 2018-08-14 13:37:14 --> Helper loaded: my_helper
INFO - 2018-08-14 13:37:14 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:37:14 --> Controller Class Initialized
DEBUG - 2018-08-14 13:37:14 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:37:14 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:37:14 --> Final output sent to browser
DEBUG - 2018-08-14 13:37:14 --> Total execution time: 0.3432
INFO - 2018-08-14 13:37:14 --> Config Class Initialized
INFO - 2018-08-14 13:37:14 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:37:14 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:37:14 --> Utf8 Class Initialized
INFO - 2018-08-14 13:37:14 --> URI Class Initialized
INFO - 2018-08-14 13:37:14 --> Router Class Initialized
INFO - 2018-08-14 13:37:14 --> Output Class Initialized
INFO - 2018-08-14 13:37:14 --> Security Class Initialized
DEBUG - 2018-08-14 13:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:37:14 --> Input Class Initialized
INFO - 2018-08-14 13:37:14 --> Language Class Initialized
ERROR - 2018-08-14 13:37:14 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:37:14 --> Config Class Initialized
INFO - 2018-08-14 13:37:14 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:37:14 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:37:14 --> Utf8 Class Initialized
INFO - 2018-08-14 13:37:14 --> URI Class Initialized
INFO - 2018-08-14 13:37:14 --> Router Class Initialized
INFO - 2018-08-14 13:37:14 --> Output Class Initialized
INFO - 2018-08-14 13:37:14 --> Security Class Initialized
DEBUG - 2018-08-14 13:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:37:15 --> Input Class Initialized
INFO - 2018-08-14 13:37:15 --> Language Class Initialized
INFO - 2018-08-14 13:37:15 --> Language Class Initialized
INFO - 2018-08-14 13:37:15 --> Config Class Initialized
INFO - 2018-08-14 13:37:15 --> Loader Class Initialized
INFO - 2018-08-14 13:37:15 --> Helper loaded: url_helper
INFO - 2018-08-14 13:37:15 --> Helper loaded: file_helper
INFO - 2018-08-14 13:37:15 --> Helper loaded: form_helper
INFO - 2018-08-14 13:37:15 --> Helper loaded: my_helper
INFO - 2018-08-14 13:37:15 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:37:15 --> Controller Class Initialized
INFO - 2018-08-14 13:37:16 --> Config Class Initialized
INFO - 2018-08-14 13:37:16 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:37:16 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:37:16 --> Utf8 Class Initialized
INFO - 2018-08-14 13:37:16 --> URI Class Initialized
INFO - 2018-08-14 13:37:16 --> Router Class Initialized
INFO - 2018-08-14 13:37:16 --> Output Class Initialized
INFO - 2018-08-14 13:37:16 --> Security Class Initialized
DEBUG - 2018-08-14 13:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:37:16 --> Input Class Initialized
INFO - 2018-08-14 13:37:16 --> Language Class Initialized
INFO - 2018-08-14 13:37:16 --> Language Class Initialized
INFO - 2018-08-14 13:37:16 --> Config Class Initialized
INFO - 2018-08-14 13:37:16 --> Loader Class Initialized
INFO - 2018-08-14 13:37:16 --> Helper loaded: url_helper
INFO - 2018-08-14 13:37:16 --> Helper loaded: file_helper
INFO - 2018-08-14 13:37:16 --> Helper loaded: form_helper
INFO - 2018-08-14 13:37:16 --> Helper loaded: my_helper
INFO - 2018-08-14 13:37:16 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:37:16 --> Controller Class Initialized
INFO - 2018-08-14 13:37:16 --> Final output sent to browser
DEBUG - 2018-08-14 13:37:16 --> Total execution time: 0.3449
INFO - 2018-08-14 13:37:25 --> Config Class Initialized
INFO - 2018-08-14 13:37:25 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:37:25 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:37:25 --> Utf8 Class Initialized
INFO - 2018-08-14 13:37:25 --> URI Class Initialized
INFO - 2018-08-14 13:37:25 --> Router Class Initialized
INFO - 2018-08-14 13:37:25 --> Output Class Initialized
INFO - 2018-08-14 13:37:25 --> Security Class Initialized
DEBUG - 2018-08-14 13:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:37:25 --> Input Class Initialized
INFO - 2018-08-14 13:37:25 --> Language Class Initialized
INFO - 2018-08-14 13:37:25 --> Language Class Initialized
INFO - 2018-08-14 13:37:25 --> Config Class Initialized
INFO - 2018-08-14 13:37:25 --> Loader Class Initialized
INFO - 2018-08-14 13:37:25 --> Helper loaded: url_helper
INFO - 2018-08-14 13:37:25 --> Helper loaded: file_helper
INFO - 2018-08-14 13:37:25 --> Helper loaded: form_helper
INFO - 2018-08-14 13:37:25 --> Helper loaded: my_helper
INFO - 2018-08-14 13:37:25 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:37:25 --> Controller Class Initialized
INFO - 2018-08-14 13:37:26 --> Final output sent to browser
DEBUG - 2018-08-14 13:37:26 --> Total execution time: 0.3483
INFO - 2018-08-14 13:37:26 --> Config Class Initialized
INFO - 2018-08-14 13:37:26 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:37:26 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:37:26 --> Utf8 Class Initialized
INFO - 2018-08-14 13:37:26 --> URI Class Initialized
INFO - 2018-08-14 13:37:26 --> Router Class Initialized
INFO - 2018-08-14 13:37:26 --> Output Class Initialized
INFO - 2018-08-14 13:37:26 --> Security Class Initialized
DEBUG - 2018-08-14 13:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:37:26 --> Input Class Initialized
INFO - 2018-08-14 13:37:26 --> Language Class Initialized
INFO - 2018-08-14 13:37:26 --> Language Class Initialized
INFO - 2018-08-14 13:37:26 --> Config Class Initialized
INFO - 2018-08-14 13:37:26 --> Loader Class Initialized
INFO - 2018-08-14 13:37:26 --> Helper loaded: url_helper
INFO - 2018-08-14 13:37:26 --> Helper loaded: file_helper
INFO - 2018-08-14 13:37:26 --> Helper loaded: form_helper
INFO - 2018-08-14 13:37:26 --> Helper loaded: my_helper
INFO - 2018-08-14 13:37:26 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:37:26 --> Controller Class Initialized
INFO - 2018-08-14 13:37:33 --> Config Class Initialized
INFO - 2018-08-14 13:37:33 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:37:33 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:37:33 --> Utf8 Class Initialized
INFO - 2018-08-14 13:37:33 --> URI Class Initialized
INFO - 2018-08-14 13:37:33 --> Router Class Initialized
INFO - 2018-08-14 13:37:33 --> Output Class Initialized
INFO - 2018-08-14 13:37:33 --> Security Class Initialized
DEBUG - 2018-08-14 13:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:37:33 --> Input Class Initialized
INFO - 2018-08-14 13:37:33 --> Language Class Initialized
INFO - 2018-08-14 13:37:33 --> Language Class Initialized
INFO - 2018-08-14 13:37:33 --> Config Class Initialized
INFO - 2018-08-14 13:37:33 --> Loader Class Initialized
INFO - 2018-08-14 13:37:33 --> Helper loaded: url_helper
INFO - 2018-08-14 13:37:33 --> Helper loaded: file_helper
INFO - 2018-08-14 13:37:33 --> Helper loaded: form_helper
INFO - 2018-08-14 13:37:33 --> Helper loaded: my_helper
INFO - 2018-08-14 13:37:33 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:37:33 --> Controller Class Initialized
INFO - 2018-08-14 13:37:33 --> Final output sent to browser
DEBUG - 2018-08-14 13:37:33 --> Total execution time: 0.4269
INFO - 2018-08-14 13:37:33 --> Config Class Initialized
INFO - 2018-08-14 13:37:33 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:37:33 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:37:33 --> Utf8 Class Initialized
INFO - 2018-08-14 13:37:33 --> URI Class Initialized
INFO - 2018-08-14 13:37:33 --> Router Class Initialized
INFO - 2018-08-14 13:37:33 --> Output Class Initialized
INFO - 2018-08-14 13:37:34 --> Security Class Initialized
DEBUG - 2018-08-14 13:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:37:34 --> Input Class Initialized
INFO - 2018-08-14 13:37:34 --> Language Class Initialized
INFO - 2018-08-14 13:37:34 --> Language Class Initialized
INFO - 2018-08-14 13:37:34 --> Config Class Initialized
INFO - 2018-08-14 13:37:34 --> Loader Class Initialized
INFO - 2018-08-14 13:37:34 --> Helper loaded: url_helper
INFO - 2018-08-14 13:37:34 --> Helper loaded: file_helper
INFO - 2018-08-14 13:37:34 --> Helper loaded: form_helper
INFO - 2018-08-14 13:37:34 --> Helper loaded: my_helper
INFO - 2018-08-14 13:37:34 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:37:34 --> Controller Class Initialized
INFO - 2018-08-14 13:37:38 --> Config Class Initialized
INFO - 2018-08-14 13:37:38 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:37:38 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:37:38 --> Utf8 Class Initialized
INFO - 2018-08-14 13:37:38 --> URI Class Initialized
INFO - 2018-08-14 13:37:38 --> Router Class Initialized
INFO - 2018-08-14 13:37:38 --> Output Class Initialized
INFO - 2018-08-14 13:37:38 --> Security Class Initialized
DEBUG - 2018-08-14 13:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:37:38 --> Input Class Initialized
INFO - 2018-08-14 13:37:38 --> Language Class Initialized
INFO - 2018-08-14 13:37:38 --> Language Class Initialized
INFO - 2018-08-14 13:37:38 --> Config Class Initialized
INFO - 2018-08-14 13:37:38 --> Loader Class Initialized
INFO - 2018-08-14 13:37:38 --> Helper loaded: url_helper
INFO - 2018-08-14 13:37:38 --> Helper loaded: file_helper
INFO - 2018-08-14 13:37:38 --> Helper loaded: form_helper
INFO - 2018-08-14 13:37:38 --> Helper loaded: my_helper
INFO - 2018-08-14 13:37:38 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:37:39 --> Controller Class Initialized
INFO - 2018-08-14 13:37:39 --> Final output sent to browser
DEBUG - 2018-08-14 13:37:39 --> Total execution time: 0.3173
INFO - 2018-08-14 13:37:43 --> Config Class Initialized
INFO - 2018-08-14 13:37:43 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:37:43 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:37:44 --> Utf8 Class Initialized
INFO - 2018-08-14 13:37:44 --> URI Class Initialized
INFO - 2018-08-14 13:37:44 --> Router Class Initialized
INFO - 2018-08-14 13:37:44 --> Output Class Initialized
INFO - 2018-08-14 13:37:44 --> Security Class Initialized
DEBUG - 2018-08-14 13:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:37:44 --> Input Class Initialized
INFO - 2018-08-14 13:37:44 --> Language Class Initialized
INFO - 2018-08-14 13:37:44 --> Language Class Initialized
INFO - 2018-08-14 13:37:44 --> Config Class Initialized
INFO - 2018-08-14 13:37:44 --> Loader Class Initialized
INFO - 2018-08-14 13:37:44 --> Helper loaded: url_helper
INFO - 2018-08-14 13:37:44 --> Helper loaded: file_helper
INFO - 2018-08-14 13:37:44 --> Helper loaded: form_helper
INFO - 2018-08-14 13:37:44 --> Helper loaded: my_helper
INFO - 2018-08-14 13:37:44 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:37:44 --> Controller Class Initialized
INFO - 2018-08-14 13:37:44 --> Final output sent to browser
DEBUG - 2018-08-14 13:37:44 --> Total execution time: 0.3730
INFO - 2018-08-14 13:37:44 --> Config Class Initialized
INFO - 2018-08-14 13:37:44 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:37:44 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:37:44 --> Utf8 Class Initialized
INFO - 2018-08-14 13:37:44 --> URI Class Initialized
INFO - 2018-08-14 13:37:44 --> Router Class Initialized
INFO - 2018-08-14 13:37:44 --> Output Class Initialized
INFO - 2018-08-14 13:37:44 --> Security Class Initialized
DEBUG - 2018-08-14 13:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:37:44 --> Input Class Initialized
INFO - 2018-08-14 13:37:44 --> Language Class Initialized
INFO - 2018-08-14 13:37:44 --> Language Class Initialized
INFO - 2018-08-14 13:37:44 --> Config Class Initialized
INFO - 2018-08-14 13:37:44 --> Loader Class Initialized
INFO - 2018-08-14 13:37:44 --> Helper loaded: url_helper
INFO - 2018-08-14 13:37:44 --> Helper loaded: file_helper
INFO - 2018-08-14 13:37:44 --> Helper loaded: form_helper
INFO - 2018-08-14 13:37:44 --> Helper loaded: my_helper
INFO - 2018-08-14 13:37:44 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:37:44 --> Controller Class Initialized
INFO - 2018-08-14 13:37:46 --> Config Class Initialized
INFO - 2018-08-14 13:37:46 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:37:46 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:37:46 --> Utf8 Class Initialized
INFO - 2018-08-14 13:37:46 --> URI Class Initialized
INFO - 2018-08-14 13:37:46 --> Router Class Initialized
INFO - 2018-08-14 13:37:46 --> Output Class Initialized
INFO - 2018-08-14 13:37:46 --> Security Class Initialized
DEBUG - 2018-08-14 13:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:37:46 --> Input Class Initialized
INFO - 2018-08-14 13:37:46 --> Language Class Initialized
INFO - 2018-08-14 13:37:46 --> Language Class Initialized
INFO - 2018-08-14 13:37:46 --> Config Class Initialized
INFO - 2018-08-14 13:37:46 --> Loader Class Initialized
INFO - 2018-08-14 13:37:46 --> Helper loaded: url_helper
INFO - 2018-08-14 13:37:46 --> Helper loaded: file_helper
INFO - 2018-08-14 13:37:46 --> Helper loaded: form_helper
INFO - 2018-08-14 13:37:46 --> Helper loaded: my_helper
INFO - 2018-08-14 13:37:46 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:37:46 --> Controller Class Initialized
INFO - 2018-08-14 13:37:46 --> Final output sent to browser
DEBUG - 2018-08-14 13:37:46 --> Total execution time: 0.4046
INFO - 2018-08-14 13:37:46 --> Config Class Initialized
INFO - 2018-08-14 13:37:46 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:37:46 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:37:46 --> Utf8 Class Initialized
INFO - 2018-08-14 13:37:46 --> URI Class Initialized
INFO - 2018-08-14 13:37:46 --> Router Class Initialized
INFO - 2018-08-14 13:37:46 --> Output Class Initialized
INFO - 2018-08-14 13:37:46 --> Security Class Initialized
DEBUG - 2018-08-14 13:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:37:46 --> Input Class Initialized
INFO - 2018-08-14 13:37:46 --> Language Class Initialized
INFO - 2018-08-14 13:37:46 --> Language Class Initialized
INFO - 2018-08-14 13:37:46 --> Config Class Initialized
INFO - 2018-08-14 13:37:47 --> Loader Class Initialized
INFO - 2018-08-14 13:37:47 --> Helper loaded: url_helper
INFO - 2018-08-14 13:37:47 --> Helper loaded: file_helper
INFO - 2018-08-14 13:37:47 --> Helper loaded: form_helper
INFO - 2018-08-14 13:37:47 --> Helper loaded: my_helper
INFO - 2018-08-14 13:37:47 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:37:47 --> Controller Class Initialized
INFO - 2018-08-14 13:37:56 --> Config Class Initialized
INFO - 2018-08-14 13:37:56 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:37:56 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:37:56 --> Utf8 Class Initialized
INFO - 2018-08-14 13:37:56 --> URI Class Initialized
INFO - 2018-08-14 13:37:56 --> Router Class Initialized
INFO - 2018-08-14 13:37:56 --> Output Class Initialized
INFO - 2018-08-14 13:37:56 --> Security Class Initialized
DEBUG - 2018-08-14 13:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:37:56 --> Input Class Initialized
INFO - 2018-08-14 13:37:56 --> Language Class Initialized
INFO - 2018-08-14 13:37:56 --> Language Class Initialized
INFO - 2018-08-14 13:37:56 --> Config Class Initialized
INFO - 2018-08-14 13:37:56 --> Loader Class Initialized
INFO - 2018-08-14 13:37:56 --> Helper loaded: url_helper
INFO - 2018-08-14 13:37:56 --> Helper loaded: file_helper
INFO - 2018-08-14 13:37:56 --> Helper loaded: form_helper
INFO - 2018-08-14 13:37:57 --> Helper loaded: my_helper
INFO - 2018-08-14 13:37:57 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:37:57 --> Controller Class Initialized
DEBUG - 2018-08-14 13:37:57 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:37:57 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:37:57 --> Final output sent to browser
DEBUG - 2018-08-14 13:37:57 --> Total execution time: 0.4152
INFO - 2018-08-14 13:37:57 --> Config Class Initialized
INFO - 2018-08-14 13:37:57 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:37:57 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:37:57 --> Utf8 Class Initialized
INFO - 2018-08-14 13:37:57 --> URI Class Initialized
INFO - 2018-08-14 13:37:57 --> Router Class Initialized
INFO - 2018-08-14 13:37:57 --> Output Class Initialized
INFO - 2018-08-14 13:37:57 --> Security Class Initialized
DEBUG - 2018-08-14 13:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:37:57 --> Input Class Initialized
INFO - 2018-08-14 13:37:57 --> Language Class Initialized
ERROR - 2018-08-14 13:37:57 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:37:57 --> Config Class Initialized
INFO - 2018-08-14 13:37:57 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:37:57 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:37:57 --> Utf8 Class Initialized
INFO - 2018-08-14 13:37:57 --> URI Class Initialized
INFO - 2018-08-14 13:37:57 --> Router Class Initialized
INFO - 2018-08-14 13:37:57 --> Output Class Initialized
INFO - 2018-08-14 13:37:57 --> Security Class Initialized
DEBUG - 2018-08-14 13:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:37:57 --> Input Class Initialized
INFO - 2018-08-14 13:37:57 --> Language Class Initialized
INFO - 2018-08-14 13:37:57 --> Language Class Initialized
INFO - 2018-08-14 13:37:57 --> Config Class Initialized
INFO - 2018-08-14 13:37:57 --> Loader Class Initialized
INFO - 2018-08-14 13:37:57 --> Helper loaded: url_helper
INFO - 2018-08-14 13:37:57 --> Helper loaded: file_helper
INFO - 2018-08-14 13:37:57 --> Helper loaded: form_helper
INFO - 2018-08-14 13:37:57 --> Helper loaded: my_helper
INFO - 2018-08-14 13:37:57 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:37:57 --> Controller Class Initialized
INFO - 2018-08-14 13:38:42 --> Config Class Initialized
INFO - 2018-08-14 13:38:42 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:38:42 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:38:42 --> Utf8 Class Initialized
INFO - 2018-08-14 13:38:42 --> URI Class Initialized
INFO - 2018-08-14 13:38:42 --> Router Class Initialized
INFO - 2018-08-14 13:38:42 --> Output Class Initialized
INFO - 2018-08-14 13:38:42 --> Security Class Initialized
DEBUG - 2018-08-14 13:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:38:42 --> Input Class Initialized
INFO - 2018-08-14 13:38:42 --> Language Class Initialized
INFO - 2018-08-14 13:38:42 --> Language Class Initialized
INFO - 2018-08-14 13:38:42 --> Config Class Initialized
INFO - 2018-08-14 13:38:42 --> Loader Class Initialized
INFO - 2018-08-14 13:38:42 --> Helper loaded: url_helper
INFO - 2018-08-14 13:38:42 --> Helper loaded: file_helper
INFO - 2018-08-14 13:38:42 --> Helper loaded: form_helper
INFO - 2018-08-14 13:38:42 --> Helper loaded: my_helper
INFO - 2018-08-14 13:38:42 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:38:42 --> Controller Class Initialized
INFO - 2018-08-14 13:38:42 --> Final output sent to browser
DEBUG - 2018-08-14 13:38:42 --> Total execution time: 0.4211
INFO - 2018-08-14 13:38:42 --> Config Class Initialized
INFO - 2018-08-14 13:38:42 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:38:42 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:38:42 --> Utf8 Class Initialized
INFO - 2018-08-14 13:38:42 --> URI Class Initialized
INFO - 2018-08-14 13:38:42 --> Router Class Initialized
INFO - 2018-08-14 13:38:42 --> Output Class Initialized
INFO - 2018-08-14 13:38:42 --> Security Class Initialized
DEBUG - 2018-08-14 13:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:38:42 --> Input Class Initialized
INFO - 2018-08-14 13:38:42 --> Language Class Initialized
INFO - 2018-08-14 13:38:42 --> Language Class Initialized
INFO - 2018-08-14 13:38:42 --> Config Class Initialized
INFO - 2018-08-14 13:38:42 --> Loader Class Initialized
INFO - 2018-08-14 13:38:42 --> Helper loaded: url_helper
INFO - 2018-08-14 13:38:42 --> Helper loaded: file_helper
INFO - 2018-08-14 13:38:42 --> Helper loaded: form_helper
INFO - 2018-08-14 13:38:42 --> Helper loaded: my_helper
INFO - 2018-08-14 13:38:42 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:38:42 --> Controller Class Initialized
INFO - 2018-08-14 13:38:44 --> Config Class Initialized
INFO - 2018-08-14 13:38:44 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:38:44 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:38:44 --> Utf8 Class Initialized
INFO - 2018-08-14 13:38:44 --> URI Class Initialized
INFO - 2018-08-14 13:38:44 --> Router Class Initialized
INFO - 2018-08-14 13:38:44 --> Output Class Initialized
INFO - 2018-08-14 13:38:44 --> Security Class Initialized
DEBUG - 2018-08-14 13:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:38:44 --> Input Class Initialized
INFO - 2018-08-14 13:38:44 --> Language Class Initialized
INFO - 2018-08-14 13:38:44 --> Language Class Initialized
INFO - 2018-08-14 13:38:44 --> Config Class Initialized
INFO - 2018-08-14 13:38:44 --> Loader Class Initialized
INFO - 2018-08-14 13:38:44 --> Helper loaded: url_helper
INFO - 2018-08-14 13:38:44 --> Helper loaded: file_helper
INFO - 2018-08-14 13:38:44 --> Helper loaded: form_helper
INFO - 2018-08-14 13:38:44 --> Helper loaded: my_helper
INFO - 2018-08-14 13:38:44 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:38:44 --> Controller Class Initialized
DEBUG - 2018-08-14 13:38:44 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:38:44 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:38:44 --> Final output sent to browser
DEBUG - 2018-08-14 13:38:44 --> Total execution time: 0.3721
INFO - 2018-08-14 13:38:45 --> Config Class Initialized
INFO - 2018-08-14 13:38:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:38:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:38:45 --> Utf8 Class Initialized
INFO - 2018-08-14 13:38:45 --> URI Class Initialized
INFO - 2018-08-14 13:38:45 --> Router Class Initialized
INFO - 2018-08-14 13:38:45 --> Output Class Initialized
INFO - 2018-08-14 13:38:45 --> Security Class Initialized
DEBUG - 2018-08-14 13:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:38:45 --> Input Class Initialized
INFO - 2018-08-14 13:38:45 --> Language Class Initialized
ERROR - 2018-08-14 13:38:45 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:38:45 --> Config Class Initialized
INFO - 2018-08-14 13:38:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:38:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:38:45 --> Utf8 Class Initialized
INFO - 2018-08-14 13:38:45 --> URI Class Initialized
INFO - 2018-08-14 13:38:45 --> Router Class Initialized
INFO - 2018-08-14 13:38:45 --> Output Class Initialized
INFO - 2018-08-14 13:38:45 --> Security Class Initialized
DEBUG - 2018-08-14 13:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:38:45 --> Input Class Initialized
INFO - 2018-08-14 13:38:45 --> Language Class Initialized
INFO - 2018-08-14 13:38:45 --> Language Class Initialized
INFO - 2018-08-14 13:38:45 --> Config Class Initialized
INFO - 2018-08-14 13:38:45 --> Loader Class Initialized
INFO - 2018-08-14 13:38:45 --> Helper loaded: url_helper
INFO - 2018-08-14 13:38:45 --> Helper loaded: file_helper
INFO - 2018-08-14 13:38:45 --> Helper loaded: form_helper
INFO - 2018-08-14 13:38:45 --> Helper loaded: my_helper
INFO - 2018-08-14 13:38:45 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:38:45 --> Controller Class Initialized
INFO - 2018-08-14 13:38:47 --> Config Class Initialized
INFO - 2018-08-14 13:38:47 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:38:47 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:38:47 --> Utf8 Class Initialized
INFO - 2018-08-14 13:38:47 --> URI Class Initialized
INFO - 2018-08-14 13:38:47 --> Router Class Initialized
INFO - 2018-08-14 13:38:47 --> Output Class Initialized
INFO - 2018-08-14 13:38:47 --> Security Class Initialized
DEBUG - 2018-08-14 13:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:38:47 --> Input Class Initialized
INFO - 2018-08-14 13:38:48 --> Language Class Initialized
INFO - 2018-08-14 13:38:48 --> Language Class Initialized
INFO - 2018-08-14 13:38:48 --> Config Class Initialized
INFO - 2018-08-14 13:38:48 --> Loader Class Initialized
INFO - 2018-08-14 13:38:48 --> Helper loaded: url_helper
INFO - 2018-08-14 13:38:48 --> Helper loaded: file_helper
INFO - 2018-08-14 13:38:48 --> Helper loaded: form_helper
INFO - 2018-08-14 13:38:48 --> Helper loaded: my_helper
INFO - 2018-08-14 13:38:48 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:38:48 --> Controller Class Initialized
INFO - 2018-08-14 13:38:48 --> Final output sent to browser
DEBUG - 2018-08-14 13:38:48 --> Total execution time: 0.3371
INFO - 2018-08-14 13:38:48 --> Config Class Initialized
INFO - 2018-08-14 13:38:48 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:38:48 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:38:48 --> Utf8 Class Initialized
INFO - 2018-08-14 13:38:48 --> URI Class Initialized
INFO - 2018-08-14 13:38:48 --> Router Class Initialized
INFO - 2018-08-14 13:38:48 --> Output Class Initialized
INFO - 2018-08-14 13:38:48 --> Security Class Initialized
DEBUG - 2018-08-14 13:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:38:48 --> Input Class Initialized
INFO - 2018-08-14 13:38:48 --> Language Class Initialized
INFO - 2018-08-14 13:38:48 --> Language Class Initialized
INFO - 2018-08-14 13:38:48 --> Config Class Initialized
INFO - 2018-08-14 13:38:48 --> Loader Class Initialized
INFO - 2018-08-14 13:38:48 --> Helper loaded: url_helper
INFO - 2018-08-14 13:38:48 --> Helper loaded: file_helper
INFO - 2018-08-14 13:38:48 --> Helper loaded: form_helper
INFO - 2018-08-14 13:38:48 --> Helper loaded: my_helper
INFO - 2018-08-14 13:38:48 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:38:48 --> Controller Class Initialized
INFO - 2018-08-14 13:38:50 --> Config Class Initialized
INFO - 2018-08-14 13:38:50 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:38:50 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:38:50 --> Utf8 Class Initialized
INFO - 2018-08-14 13:38:50 --> URI Class Initialized
INFO - 2018-08-14 13:38:50 --> Router Class Initialized
INFO - 2018-08-14 13:38:50 --> Output Class Initialized
INFO - 2018-08-14 13:38:50 --> Security Class Initialized
DEBUG - 2018-08-14 13:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:38:50 --> Input Class Initialized
INFO - 2018-08-14 13:38:50 --> Language Class Initialized
INFO - 2018-08-14 13:38:50 --> Language Class Initialized
INFO - 2018-08-14 13:38:50 --> Config Class Initialized
INFO - 2018-08-14 13:38:50 --> Loader Class Initialized
INFO - 2018-08-14 13:38:50 --> Helper loaded: url_helper
INFO - 2018-08-14 13:38:50 --> Helper loaded: file_helper
INFO - 2018-08-14 13:38:50 --> Helper loaded: form_helper
INFO - 2018-08-14 13:38:50 --> Helper loaded: my_helper
INFO - 2018-08-14 13:38:50 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:38:50 --> Controller Class Initialized
INFO - 2018-08-14 13:38:51 --> Final output sent to browser
DEBUG - 2018-08-14 13:38:51 --> Total execution time: 0.3430
INFO - 2018-08-14 13:38:51 --> Config Class Initialized
INFO - 2018-08-14 13:38:51 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:38:51 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:38:51 --> Utf8 Class Initialized
INFO - 2018-08-14 13:38:51 --> URI Class Initialized
INFO - 2018-08-14 13:38:51 --> Router Class Initialized
INFO - 2018-08-14 13:38:51 --> Output Class Initialized
INFO - 2018-08-14 13:38:51 --> Security Class Initialized
DEBUG - 2018-08-14 13:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:38:51 --> Input Class Initialized
INFO - 2018-08-14 13:38:51 --> Language Class Initialized
INFO - 2018-08-14 13:38:51 --> Language Class Initialized
INFO - 2018-08-14 13:38:51 --> Config Class Initialized
INFO - 2018-08-14 13:38:51 --> Loader Class Initialized
INFO - 2018-08-14 13:38:51 --> Helper loaded: url_helper
INFO - 2018-08-14 13:38:51 --> Helper loaded: file_helper
INFO - 2018-08-14 13:38:51 --> Helper loaded: form_helper
INFO - 2018-08-14 13:38:51 --> Helper loaded: my_helper
INFO - 2018-08-14 13:38:51 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:38:51 --> Controller Class Initialized
INFO - 2018-08-14 13:38:52 --> Config Class Initialized
INFO - 2018-08-14 13:38:52 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:38:52 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:38:52 --> Utf8 Class Initialized
INFO - 2018-08-14 13:38:52 --> URI Class Initialized
INFO - 2018-08-14 13:38:52 --> Router Class Initialized
INFO - 2018-08-14 13:38:52 --> Output Class Initialized
INFO - 2018-08-14 13:38:52 --> Security Class Initialized
DEBUG - 2018-08-14 13:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:38:52 --> Input Class Initialized
INFO - 2018-08-14 13:38:52 --> Language Class Initialized
INFO - 2018-08-14 13:38:52 --> Language Class Initialized
INFO - 2018-08-14 13:38:52 --> Config Class Initialized
INFO - 2018-08-14 13:38:52 --> Loader Class Initialized
INFO - 2018-08-14 13:38:52 --> Helper loaded: url_helper
INFO - 2018-08-14 13:38:52 --> Helper loaded: file_helper
INFO - 2018-08-14 13:38:52 --> Helper loaded: form_helper
INFO - 2018-08-14 13:38:52 --> Helper loaded: my_helper
INFO - 2018-08-14 13:38:52 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:38:52 --> Controller Class Initialized
DEBUG - 2018-08-14 13:38:52 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:38:52 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:38:52 --> Final output sent to browser
DEBUG - 2018-08-14 13:38:52 --> Total execution time: 0.3560
INFO - 2018-08-14 13:38:52 --> Config Class Initialized
INFO - 2018-08-14 13:38:52 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:38:52 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:38:52 --> Utf8 Class Initialized
INFO - 2018-08-14 13:38:52 --> URI Class Initialized
INFO - 2018-08-14 13:38:52 --> Router Class Initialized
INFO - 2018-08-14 13:38:52 --> Output Class Initialized
INFO - 2018-08-14 13:38:52 --> Security Class Initialized
DEBUG - 2018-08-14 13:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:38:52 --> Input Class Initialized
INFO - 2018-08-14 13:38:52 --> Language Class Initialized
ERROR - 2018-08-14 13:38:52 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:38:52 --> Config Class Initialized
INFO - 2018-08-14 13:38:52 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:38:52 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:38:52 --> Utf8 Class Initialized
INFO - 2018-08-14 13:38:52 --> URI Class Initialized
INFO - 2018-08-14 13:38:52 --> Router Class Initialized
INFO - 2018-08-14 13:38:52 --> Output Class Initialized
INFO - 2018-08-14 13:38:52 --> Security Class Initialized
DEBUG - 2018-08-14 13:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:38:52 --> Input Class Initialized
INFO - 2018-08-14 13:38:53 --> Language Class Initialized
INFO - 2018-08-14 13:38:53 --> Language Class Initialized
INFO - 2018-08-14 13:38:53 --> Config Class Initialized
INFO - 2018-08-14 13:38:53 --> Loader Class Initialized
INFO - 2018-08-14 13:38:53 --> Helper loaded: url_helper
INFO - 2018-08-14 13:38:53 --> Helper loaded: file_helper
INFO - 2018-08-14 13:38:53 --> Helper loaded: form_helper
INFO - 2018-08-14 13:38:53 --> Helper loaded: my_helper
INFO - 2018-08-14 13:38:53 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:38:53 --> Controller Class Initialized
INFO - 2018-08-14 13:39:25 --> Config Class Initialized
INFO - 2018-08-14 13:39:25 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:39:25 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:39:25 --> Utf8 Class Initialized
INFO - 2018-08-14 13:39:25 --> URI Class Initialized
INFO - 2018-08-14 13:39:25 --> Router Class Initialized
INFO - 2018-08-14 13:39:25 --> Output Class Initialized
INFO - 2018-08-14 13:39:25 --> Security Class Initialized
DEBUG - 2018-08-14 13:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:39:25 --> Input Class Initialized
INFO - 2018-08-14 13:39:25 --> Language Class Initialized
INFO - 2018-08-14 13:39:25 --> Language Class Initialized
INFO - 2018-08-14 13:39:25 --> Config Class Initialized
INFO - 2018-08-14 13:39:25 --> Loader Class Initialized
INFO - 2018-08-14 13:39:25 --> Helper loaded: url_helper
INFO - 2018-08-14 13:39:25 --> Helper loaded: file_helper
INFO - 2018-08-14 13:39:25 --> Helper loaded: form_helper
INFO - 2018-08-14 13:39:25 --> Helper loaded: my_helper
INFO - 2018-08-14 13:39:25 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:39:25 --> Controller Class Initialized
DEBUG - 2018-08-14 13:39:25 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:39:25 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:39:25 --> Final output sent to browser
DEBUG - 2018-08-14 13:39:25 --> Total execution time: 0.3728
INFO - 2018-08-14 13:39:25 --> Config Class Initialized
INFO - 2018-08-14 13:39:25 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:39:25 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:39:25 --> Utf8 Class Initialized
INFO - 2018-08-14 13:39:25 --> URI Class Initialized
INFO - 2018-08-14 13:39:26 --> Router Class Initialized
INFO - 2018-08-14 13:39:26 --> Output Class Initialized
INFO - 2018-08-14 13:39:26 --> Security Class Initialized
DEBUG - 2018-08-14 13:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:39:26 --> Input Class Initialized
INFO - 2018-08-14 13:39:26 --> Language Class Initialized
ERROR - 2018-08-14 13:39:26 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:39:26 --> Config Class Initialized
INFO - 2018-08-14 13:39:26 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:39:26 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:39:26 --> Utf8 Class Initialized
INFO - 2018-08-14 13:39:26 --> URI Class Initialized
INFO - 2018-08-14 13:39:26 --> Router Class Initialized
INFO - 2018-08-14 13:39:26 --> Output Class Initialized
INFO - 2018-08-14 13:39:26 --> Security Class Initialized
DEBUG - 2018-08-14 13:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:39:26 --> Input Class Initialized
INFO - 2018-08-14 13:39:26 --> Language Class Initialized
INFO - 2018-08-14 13:39:26 --> Language Class Initialized
INFO - 2018-08-14 13:39:26 --> Config Class Initialized
INFO - 2018-08-14 13:39:26 --> Loader Class Initialized
INFO - 2018-08-14 13:39:26 --> Helper loaded: url_helper
INFO - 2018-08-14 13:39:26 --> Helper loaded: file_helper
INFO - 2018-08-14 13:39:26 --> Helper loaded: form_helper
INFO - 2018-08-14 13:39:26 --> Helper loaded: my_helper
INFO - 2018-08-14 13:39:26 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:39:26 --> Controller Class Initialized
INFO - 2018-08-14 13:39:47 --> Config Class Initialized
INFO - 2018-08-14 13:39:47 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:39:47 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:39:47 --> Utf8 Class Initialized
INFO - 2018-08-14 13:39:47 --> URI Class Initialized
INFO - 2018-08-14 13:39:47 --> Router Class Initialized
INFO - 2018-08-14 13:39:47 --> Output Class Initialized
INFO - 2018-08-14 13:39:47 --> Security Class Initialized
DEBUG - 2018-08-14 13:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:39:47 --> Input Class Initialized
INFO - 2018-08-14 13:39:47 --> Language Class Initialized
INFO - 2018-08-14 13:39:47 --> Language Class Initialized
INFO - 2018-08-14 13:39:47 --> Config Class Initialized
INFO - 2018-08-14 13:39:47 --> Loader Class Initialized
INFO - 2018-08-14 13:39:47 --> Helper loaded: url_helper
INFO - 2018-08-14 13:39:47 --> Helper loaded: file_helper
INFO - 2018-08-14 13:39:47 --> Helper loaded: form_helper
INFO - 2018-08-14 13:39:47 --> Helper loaded: my_helper
INFO - 2018-08-14 13:39:47 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:39:47 --> Controller Class Initialized
DEBUG - 2018-08-14 13:39:47 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:39:47 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:39:47 --> Final output sent to browser
DEBUG - 2018-08-14 13:39:47 --> Total execution time: 0.5725
INFO - 2018-08-14 13:39:48 --> Config Class Initialized
INFO - 2018-08-14 13:39:48 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:39:48 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:39:48 --> Utf8 Class Initialized
INFO - 2018-08-14 13:39:48 --> URI Class Initialized
INFO - 2018-08-14 13:39:48 --> Router Class Initialized
INFO - 2018-08-14 13:39:48 --> Output Class Initialized
INFO - 2018-08-14 13:39:48 --> Security Class Initialized
DEBUG - 2018-08-14 13:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:39:48 --> Input Class Initialized
INFO - 2018-08-14 13:39:48 --> Language Class Initialized
ERROR - 2018-08-14 13:39:48 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:39:48 --> Config Class Initialized
INFO - 2018-08-14 13:39:48 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:39:48 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:39:48 --> Utf8 Class Initialized
INFO - 2018-08-14 13:39:48 --> URI Class Initialized
INFO - 2018-08-14 13:39:48 --> Router Class Initialized
INFO - 2018-08-14 13:39:48 --> Output Class Initialized
INFO - 2018-08-14 13:39:48 --> Security Class Initialized
DEBUG - 2018-08-14 13:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:39:48 --> Input Class Initialized
INFO - 2018-08-14 13:39:48 --> Language Class Initialized
INFO - 2018-08-14 13:39:48 --> Language Class Initialized
INFO - 2018-08-14 13:39:48 --> Config Class Initialized
INFO - 2018-08-14 13:39:48 --> Loader Class Initialized
INFO - 2018-08-14 13:39:48 --> Helper loaded: url_helper
INFO - 2018-08-14 13:39:48 --> Helper loaded: file_helper
INFO - 2018-08-14 13:39:48 --> Helper loaded: form_helper
INFO - 2018-08-14 13:39:48 --> Helper loaded: my_helper
INFO - 2018-08-14 13:39:48 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:39:48 --> Controller Class Initialized
INFO - 2018-08-14 13:40:16 --> Config Class Initialized
INFO - 2018-08-14 13:40:16 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:40:16 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:40:16 --> Utf8 Class Initialized
INFO - 2018-08-14 13:40:16 --> URI Class Initialized
INFO - 2018-08-14 13:40:16 --> Router Class Initialized
INFO - 2018-08-14 13:40:16 --> Output Class Initialized
INFO - 2018-08-14 13:40:16 --> Security Class Initialized
DEBUG - 2018-08-14 13:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:40:16 --> Input Class Initialized
INFO - 2018-08-14 13:40:16 --> Language Class Initialized
INFO - 2018-08-14 13:40:16 --> Language Class Initialized
INFO - 2018-08-14 13:40:16 --> Config Class Initialized
INFO - 2018-08-14 13:40:16 --> Loader Class Initialized
INFO - 2018-08-14 13:40:16 --> Helper loaded: url_helper
INFO - 2018-08-14 13:40:16 --> Helper loaded: file_helper
INFO - 2018-08-14 13:40:16 --> Helper loaded: form_helper
INFO - 2018-08-14 13:40:16 --> Helper loaded: my_helper
INFO - 2018-08-14 13:40:16 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:40:16 --> Controller Class Initialized
DEBUG - 2018-08-14 13:40:16 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:40:16 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:40:16 --> Final output sent to browser
DEBUG - 2018-08-14 13:40:16 --> Total execution time: 0.3826
INFO - 2018-08-14 13:40:16 --> Config Class Initialized
INFO - 2018-08-14 13:40:17 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:40:17 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:40:17 --> Utf8 Class Initialized
INFO - 2018-08-14 13:40:17 --> URI Class Initialized
INFO - 2018-08-14 13:40:17 --> Router Class Initialized
INFO - 2018-08-14 13:40:17 --> Output Class Initialized
INFO - 2018-08-14 13:40:17 --> Security Class Initialized
DEBUG - 2018-08-14 13:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:40:17 --> Input Class Initialized
INFO - 2018-08-14 13:40:17 --> Language Class Initialized
ERROR - 2018-08-14 13:40:17 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:40:17 --> Config Class Initialized
INFO - 2018-08-14 13:40:17 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:40:17 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:40:17 --> Utf8 Class Initialized
INFO - 2018-08-14 13:40:17 --> URI Class Initialized
INFO - 2018-08-14 13:40:17 --> Router Class Initialized
INFO - 2018-08-14 13:40:17 --> Output Class Initialized
INFO - 2018-08-14 13:40:17 --> Security Class Initialized
DEBUG - 2018-08-14 13:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:40:17 --> Input Class Initialized
INFO - 2018-08-14 13:40:17 --> Language Class Initialized
INFO - 2018-08-14 13:40:17 --> Language Class Initialized
INFO - 2018-08-14 13:40:17 --> Config Class Initialized
INFO - 2018-08-14 13:40:17 --> Loader Class Initialized
INFO - 2018-08-14 13:40:17 --> Helper loaded: url_helper
INFO - 2018-08-14 13:40:17 --> Helper loaded: file_helper
INFO - 2018-08-14 13:40:17 --> Helper loaded: form_helper
INFO - 2018-08-14 13:40:17 --> Helper loaded: my_helper
INFO - 2018-08-14 13:40:17 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:40:17 --> Controller Class Initialized
INFO - 2018-08-14 13:40:26 --> Config Class Initialized
INFO - 2018-08-14 13:40:26 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:40:26 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:40:26 --> Utf8 Class Initialized
INFO - 2018-08-14 13:40:26 --> URI Class Initialized
INFO - 2018-08-14 13:40:26 --> Router Class Initialized
INFO - 2018-08-14 13:40:26 --> Output Class Initialized
INFO - 2018-08-14 13:40:26 --> Security Class Initialized
DEBUG - 2018-08-14 13:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:40:26 --> Input Class Initialized
INFO - 2018-08-14 13:40:26 --> Language Class Initialized
INFO - 2018-08-14 13:40:26 --> Language Class Initialized
INFO - 2018-08-14 13:40:26 --> Config Class Initialized
INFO - 2018-08-14 13:40:26 --> Loader Class Initialized
INFO - 2018-08-14 13:40:26 --> Helper loaded: url_helper
INFO - 2018-08-14 13:40:27 --> Helper loaded: file_helper
INFO - 2018-08-14 13:40:27 --> Helper loaded: form_helper
INFO - 2018-08-14 13:40:27 --> Helper loaded: my_helper
INFO - 2018-08-14 13:40:27 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:40:27 --> Controller Class Initialized
DEBUG - 2018-08-14 13:40:27 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:40:27 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:40:27 --> Final output sent to browser
DEBUG - 2018-08-14 13:40:27 --> Total execution time: 0.7877
INFO - 2018-08-14 13:40:27 --> Config Class Initialized
INFO - 2018-08-14 13:40:27 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:40:27 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:40:27 --> Utf8 Class Initialized
INFO - 2018-08-14 13:40:27 --> URI Class Initialized
INFO - 2018-08-14 13:40:27 --> Router Class Initialized
INFO - 2018-08-14 13:40:27 --> Output Class Initialized
INFO - 2018-08-14 13:40:27 --> Security Class Initialized
DEBUG - 2018-08-14 13:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:40:27 --> Input Class Initialized
INFO - 2018-08-14 13:40:27 --> Language Class Initialized
ERROR - 2018-08-14 13:40:27 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:40:27 --> Config Class Initialized
INFO - 2018-08-14 13:40:27 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:40:27 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:40:27 --> Utf8 Class Initialized
INFO - 2018-08-14 13:40:27 --> URI Class Initialized
INFO - 2018-08-14 13:40:27 --> Router Class Initialized
INFO - 2018-08-14 13:40:27 --> Output Class Initialized
INFO - 2018-08-14 13:40:27 --> Security Class Initialized
DEBUG - 2018-08-14 13:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:40:27 --> Input Class Initialized
INFO - 2018-08-14 13:40:27 --> Language Class Initialized
INFO - 2018-08-14 13:40:28 --> Language Class Initialized
INFO - 2018-08-14 13:40:28 --> Config Class Initialized
INFO - 2018-08-14 13:40:28 --> Loader Class Initialized
INFO - 2018-08-14 13:40:28 --> Helper loaded: url_helper
INFO - 2018-08-14 13:40:28 --> Helper loaded: file_helper
INFO - 2018-08-14 13:40:28 --> Helper loaded: form_helper
INFO - 2018-08-14 13:40:28 --> Helper loaded: my_helper
INFO - 2018-08-14 13:40:28 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:40:28 --> Controller Class Initialized
INFO - 2018-08-14 13:40:35 --> Config Class Initialized
INFO - 2018-08-14 13:40:35 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:40:35 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:40:35 --> Utf8 Class Initialized
INFO - 2018-08-14 13:40:35 --> URI Class Initialized
INFO - 2018-08-14 13:40:35 --> Router Class Initialized
INFO - 2018-08-14 13:40:35 --> Output Class Initialized
INFO - 2018-08-14 13:40:35 --> Security Class Initialized
DEBUG - 2018-08-14 13:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:40:35 --> Input Class Initialized
INFO - 2018-08-14 13:40:35 --> Language Class Initialized
INFO - 2018-08-14 13:40:35 --> Language Class Initialized
INFO - 2018-08-14 13:40:35 --> Config Class Initialized
INFO - 2018-08-14 13:40:35 --> Loader Class Initialized
INFO - 2018-08-14 13:40:35 --> Helper loaded: url_helper
INFO - 2018-08-14 13:40:35 --> Helper loaded: file_helper
INFO - 2018-08-14 13:40:35 --> Helper loaded: form_helper
INFO - 2018-08-14 13:40:35 --> Helper loaded: my_helper
INFO - 2018-08-14 13:40:35 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:40:35 --> Controller Class Initialized
DEBUG - 2018-08-14 13:40:35 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:40:35 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:40:35 --> Final output sent to browser
DEBUG - 2018-08-14 13:40:36 --> Total execution time: 0.3815
INFO - 2018-08-14 13:40:36 --> Config Class Initialized
INFO - 2018-08-14 13:40:36 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:40:36 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:40:36 --> Utf8 Class Initialized
INFO - 2018-08-14 13:40:36 --> URI Class Initialized
INFO - 2018-08-14 13:40:36 --> Router Class Initialized
INFO - 2018-08-14 13:40:36 --> Output Class Initialized
INFO - 2018-08-14 13:40:36 --> Security Class Initialized
DEBUG - 2018-08-14 13:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:40:36 --> Input Class Initialized
INFO - 2018-08-14 13:40:36 --> Language Class Initialized
ERROR - 2018-08-14 13:40:36 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:40:36 --> Config Class Initialized
INFO - 2018-08-14 13:40:36 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:40:36 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:40:36 --> Utf8 Class Initialized
INFO - 2018-08-14 13:40:36 --> URI Class Initialized
INFO - 2018-08-14 13:40:36 --> Router Class Initialized
INFO - 2018-08-14 13:40:36 --> Output Class Initialized
INFO - 2018-08-14 13:40:36 --> Security Class Initialized
DEBUG - 2018-08-14 13:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:40:36 --> Input Class Initialized
INFO - 2018-08-14 13:40:36 --> Language Class Initialized
INFO - 2018-08-14 13:40:36 --> Language Class Initialized
INFO - 2018-08-14 13:40:36 --> Config Class Initialized
INFO - 2018-08-14 13:40:36 --> Loader Class Initialized
INFO - 2018-08-14 13:40:36 --> Helper loaded: url_helper
INFO - 2018-08-14 13:40:36 --> Helper loaded: file_helper
INFO - 2018-08-14 13:40:36 --> Helper loaded: form_helper
INFO - 2018-08-14 13:40:36 --> Helper loaded: my_helper
INFO - 2018-08-14 13:40:36 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:40:36 --> Controller Class Initialized
INFO - 2018-08-14 13:40:37 --> Config Class Initialized
INFO - 2018-08-14 13:40:37 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:40:37 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:40:37 --> Utf8 Class Initialized
INFO - 2018-08-14 13:40:37 --> URI Class Initialized
INFO - 2018-08-14 13:40:37 --> Router Class Initialized
INFO - 2018-08-14 13:40:37 --> Output Class Initialized
INFO - 2018-08-14 13:40:37 --> Security Class Initialized
DEBUG - 2018-08-14 13:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:40:37 --> Input Class Initialized
INFO - 2018-08-14 13:40:37 --> Language Class Initialized
INFO - 2018-08-14 13:40:37 --> Language Class Initialized
INFO - 2018-08-14 13:40:37 --> Config Class Initialized
INFO - 2018-08-14 13:40:37 --> Loader Class Initialized
INFO - 2018-08-14 13:40:37 --> Helper loaded: url_helper
INFO - 2018-08-14 13:40:38 --> Helper loaded: file_helper
INFO - 2018-08-14 13:40:38 --> Helper loaded: form_helper
INFO - 2018-08-14 13:40:38 --> Helper loaded: my_helper
INFO - 2018-08-14 13:40:38 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:40:38 --> Controller Class Initialized
DEBUG - 2018-08-14 13:40:38 --> File loaded: D:\laragon\www\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2018-08-14 13:40:38 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:40:38 --> Final output sent to browser
DEBUG - 2018-08-14 13:40:38 --> Total execution time: 0.3623
INFO - 2018-08-14 13:40:38 --> Config Class Initialized
INFO - 2018-08-14 13:40:38 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:40:38 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:40:38 --> Utf8 Class Initialized
INFO - 2018-08-14 13:40:38 --> URI Class Initialized
INFO - 2018-08-14 13:40:38 --> Router Class Initialized
INFO - 2018-08-14 13:40:38 --> Output Class Initialized
INFO - 2018-08-14 13:40:38 --> Security Class Initialized
DEBUG - 2018-08-14 13:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:40:38 --> Input Class Initialized
INFO - 2018-08-14 13:40:38 --> Language Class Initialized
ERROR - 2018-08-14 13:40:38 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:40:38 --> Config Class Initialized
INFO - 2018-08-14 13:40:38 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:40:38 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:40:38 --> Utf8 Class Initialized
INFO - 2018-08-14 13:40:38 --> URI Class Initialized
INFO - 2018-08-14 13:40:38 --> Router Class Initialized
INFO - 2018-08-14 13:40:38 --> Output Class Initialized
INFO - 2018-08-14 13:40:38 --> Security Class Initialized
DEBUG - 2018-08-14 13:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:40:38 --> Input Class Initialized
INFO - 2018-08-14 13:40:38 --> Language Class Initialized
INFO - 2018-08-14 13:40:38 --> Language Class Initialized
INFO - 2018-08-14 13:40:38 --> Config Class Initialized
INFO - 2018-08-14 13:40:38 --> Loader Class Initialized
INFO - 2018-08-14 13:40:38 --> Helper loaded: url_helper
INFO - 2018-08-14 13:40:38 --> Helper loaded: file_helper
INFO - 2018-08-14 13:40:38 --> Helper loaded: form_helper
INFO - 2018-08-14 13:40:38 --> Helper loaded: my_helper
INFO - 2018-08-14 13:40:38 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:40:38 --> Controller Class Initialized
INFO - 2018-08-14 13:40:42 --> Config Class Initialized
INFO - 2018-08-14 13:40:42 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:40:42 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:40:42 --> Utf8 Class Initialized
INFO - 2018-08-14 13:40:42 --> URI Class Initialized
INFO - 2018-08-14 13:40:42 --> Router Class Initialized
INFO - 2018-08-14 13:40:42 --> Output Class Initialized
INFO - 2018-08-14 13:40:42 --> Security Class Initialized
DEBUG - 2018-08-14 13:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:40:42 --> Input Class Initialized
INFO - 2018-08-14 13:40:42 --> Language Class Initialized
INFO - 2018-08-14 13:40:42 --> Language Class Initialized
INFO - 2018-08-14 13:40:42 --> Config Class Initialized
INFO - 2018-08-14 13:40:42 --> Loader Class Initialized
INFO - 2018-08-14 13:40:42 --> Helper loaded: url_helper
INFO - 2018-08-14 13:40:42 --> Helper loaded: file_helper
INFO - 2018-08-14 13:40:42 --> Helper loaded: form_helper
INFO - 2018-08-14 13:40:42 --> Helper loaded: my_helper
INFO - 2018-08-14 13:40:42 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:40:42 --> Controller Class Initialized
DEBUG - 2018-08-14 13:40:42 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:40:42 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:40:42 --> Final output sent to browser
DEBUG - 2018-08-14 13:40:42 --> Total execution time: 0.4380
INFO - 2018-08-14 13:40:43 --> Config Class Initialized
INFO - 2018-08-14 13:40:43 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:40:43 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:40:43 --> Utf8 Class Initialized
INFO - 2018-08-14 13:40:43 --> URI Class Initialized
INFO - 2018-08-14 13:40:43 --> Router Class Initialized
INFO - 2018-08-14 13:40:43 --> Output Class Initialized
INFO - 2018-08-14 13:40:43 --> Security Class Initialized
DEBUG - 2018-08-14 13:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:40:43 --> Input Class Initialized
INFO - 2018-08-14 13:40:43 --> Language Class Initialized
ERROR - 2018-08-14 13:40:43 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:40:43 --> Config Class Initialized
INFO - 2018-08-14 13:40:43 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:40:43 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:40:43 --> Utf8 Class Initialized
INFO - 2018-08-14 13:40:43 --> URI Class Initialized
INFO - 2018-08-14 13:40:43 --> Router Class Initialized
INFO - 2018-08-14 13:40:43 --> Output Class Initialized
INFO - 2018-08-14 13:40:43 --> Security Class Initialized
DEBUG - 2018-08-14 13:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:40:43 --> Input Class Initialized
INFO - 2018-08-14 13:40:43 --> Language Class Initialized
INFO - 2018-08-14 13:40:43 --> Language Class Initialized
INFO - 2018-08-14 13:40:43 --> Config Class Initialized
INFO - 2018-08-14 13:40:43 --> Loader Class Initialized
INFO - 2018-08-14 13:40:43 --> Helper loaded: url_helper
INFO - 2018-08-14 13:40:43 --> Helper loaded: file_helper
INFO - 2018-08-14 13:40:43 --> Helper loaded: form_helper
INFO - 2018-08-14 13:40:43 --> Helper loaded: my_helper
INFO - 2018-08-14 13:40:43 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:40:43 --> Controller Class Initialized
INFO - 2018-08-14 13:40:45 --> Config Class Initialized
INFO - 2018-08-14 13:40:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:40:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:40:45 --> Utf8 Class Initialized
INFO - 2018-08-14 13:40:45 --> URI Class Initialized
INFO - 2018-08-14 13:40:45 --> Router Class Initialized
INFO - 2018-08-14 13:40:45 --> Output Class Initialized
INFO - 2018-08-14 13:40:45 --> Security Class Initialized
DEBUG - 2018-08-14 13:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:40:45 --> Input Class Initialized
INFO - 2018-08-14 13:40:45 --> Language Class Initialized
INFO - 2018-08-14 13:40:45 --> Language Class Initialized
INFO - 2018-08-14 13:40:45 --> Config Class Initialized
INFO - 2018-08-14 13:40:45 --> Loader Class Initialized
INFO - 2018-08-14 13:40:45 --> Helper loaded: url_helper
INFO - 2018-08-14 13:40:45 --> Helper loaded: file_helper
INFO - 2018-08-14 13:40:45 --> Helper loaded: form_helper
INFO - 2018-08-14 13:40:45 --> Helper loaded: my_helper
INFO - 2018-08-14 13:40:45 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:40:45 --> Controller Class Initialized
DEBUG - 2018-08-14 13:40:45 --> File loaded: D:\laragon\www\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2018-08-14 13:40:45 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:40:45 --> Final output sent to browser
DEBUG - 2018-08-14 13:40:45 --> Total execution time: 0.3917
INFO - 2018-08-14 13:40:45 --> Config Class Initialized
INFO - 2018-08-14 13:40:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:40:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:40:46 --> Utf8 Class Initialized
INFO - 2018-08-14 13:40:46 --> URI Class Initialized
INFO - 2018-08-14 13:40:46 --> Router Class Initialized
INFO - 2018-08-14 13:40:46 --> Output Class Initialized
INFO - 2018-08-14 13:40:46 --> Security Class Initialized
DEBUG - 2018-08-14 13:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:40:46 --> Input Class Initialized
INFO - 2018-08-14 13:40:46 --> Language Class Initialized
ERROR - 2018-08-14 13:40:46 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:40:46 --> Config Class Initialized
INFO - 2018-08-14 13:40:46 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:40:46 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:40:46 --> Utf8 Class Initialized
INFO - 2018-08-14 13:40:46 --> URI Class Initialized
INFO - 2018-08-14 13:40:46 --> Router Class Initialized
INFO - 2018-08-14 13:40:46 --> Output Class Initialized
INFO - 2018-08-14 13:40:46 --> Security Class Initialized
DEBUG - 2018-08-14 13:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:40:46 --> Input Class Initialized
INFO - 2018-08-14 13:40:46 --> Language Class Initialized
INFO - 2018-08-14 13:40:46 --> Language Class Initialized
INFO - 2018-08-14 13:40:46 --> Config Class Initialized
INFO - 2018-08-14 13:40:46 --> Loader Class Initialized
INFO - 2018-08-14 13:40:46 --> Helper loaded: url_helper
INFO - 2018-08-14 13:40:46 --> Helper loaded: file_helper
INFO - 2018-08-14 13:40:46 --> Helper loaded: form_helper
INFO - 2018-08-14 13:40:46 --> Helper loaded: my_helper
INFO - 2018-08-14 13:40:46 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:40:46 --> Controller Class Initialized
INFO - 2018-08-14 13:40:46 --> Config Class Initialized
INFO - 2018-08-14 13:40:46 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:40:46 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:40:46 --> Utf8 Class Initialized
INFO - 2018-08-14 13:40:46 --> URI Class Initialized
INFO - 2018-08-14 13:40:46 --> Router Class Initialized
INFO - 2018-08-14 13:40:46 --> Output Class Initialized
INFO - 2018-08-14 13:40:46 --> Security Class Initialized
DEBUG - 2018-08-14 13:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:40:46 --> Input Class Initialized
INFO - 2018-08-14 13:40:46 --> Language Class Initialized
INFO - 2018-08-14 13:40:46 --> Language Class Initialized
INFO - 2018-08-14 13:40:46 --> Config Class Initialized
INFO - 2018-08-14 13:40:46 --> Loader Class Initialized
INFO - 2018-08-14 13:40:46 --> Helper loaded: url_helper
INFO - 2018-08-14 13:40:46 --> Helper loaded: file_helper
INFO - 2018-08-14 13:40:46 --> Helper loaded: form_helper
INFO - 2018-08-14 13:40:46 --> Helper loaded: my_helper
INFO - 2018-08-14 13:40:46 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:40:46 --> Controller Class Initialized
ERROR - 2018-08-14 13:40:46 --> Severity: Notice --> Undefined variable: status_form D:\laragon\www\nilai\application\modules\data_siswa\views\form.php 172
DEBUG - 2018-08-14 13:40:47 --> File loaded: D:\laragon\www\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2018-08-14 13:40:47 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:40:47 --> Final output sent to browser
DEBUG - 2018-08-14 13:40:47 --> Total execution time: 0.3783
INFO - 2018-08-14 13:40:47 --> Config Class Initialized
INFO - 2018-08-14 13:40:47 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:40:47 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:40:47 --> Utf8 Class Initialized
INFO - 2018-08-14 13:40:47 --> URI Class Initialized
INFO - 2018-08-14 13:40:47 --> Router Class Initialized
INFO - 2018-08-14 13:40:47 --> Output Class Initialized
INFO - 2018-08-14 13:40:47 --> Security Class Initialized
DEBUG - 2018-08-14 13:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:40:47 --> Input Class Initialized
INFO - 2018-08-14 13:40:47 --> Language Class Initialized
ERROR - 2018-08-14 13:40:47 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:40:49 --> Config Class Initialized
INFO - 2018-08-14 13:40:49 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:40:49 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:40:49 --> Utf8 Class Initialized
INFO - 2018-08-14 13:40:49 --> URI Class Initialized
INFO - 2018-08-14 13:40:49 --> Router Class Initialized
INFO - 2018-08-14 13:40:49 --> Output Class Initialized
INFO - 2018-08-14 13:40:49 --> Security Class Initialized
DEBUG - 2018-08-14 13:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:40:49 --> Input Class Initialized
INFO - 2018-08-14 13:40:49 --> Language Class Initialized
INFO - 2018-08-14 13:40:49 --> Language Class Initialized
INFO - 2018-08-14 13:40:49 --> Config Class Initialized
INFO - 2018-08-14 13:40:49 --> Loader Class Initialized
INFO - 2018-08-14 13:40:49 --> Helper loaded: url_helper
INFO - 2018-08-14 13:40:49 --> Helper loaded: file_helper
INFO - 2018-08-14 13:40:49 --> Helper loaded: form_helper
INFO - 2018-08-14 13:40:49 --> Helper loaded: my_helper
INFO - 2018-08-14 13:40:49 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:40:49 --> Controller Class Initialized
DEBUG - 2018-08-14 13:40:49 --> File loaded: D:\laragon\www\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2018-08-14 13:40:49 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:40:49 --> Final output sent to browser
DEBUG - 2018-08-14 13:40:49 --> Total execution time: 0.4148
INFO - 2018-08-14 13:40:49 --> Config Class Initialized
INFO - 2018-08-14 13:40:49 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:40:49 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:40:49 --> Utf8 Class Initialized
INFO - 2018-08-14 13:40:49 --> URI Class Initialized
INFO - 2018-08-14 13:40:49 --> Router Class Initialized
INFO - 2018-08-14 13:40:49 --> Output Class Initialized
INFO - 2018-08-14 13:40:49 --> Security Class Initialized
DEBUG - 2018-08-14 13:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:40:49 --> Input Class Initialized
INFO - 2018-08-14 13:40:49 --> Language Class Initialized
ERROR - 2018-08-14 13:40:49 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:40:49 --> Config Class Initialized
INFO - 2018-08-14 13:40:49 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:40:50 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:40:50 --> Utf8 Class Initialized
INFO - 2018-08-14 13:40:50 --> URI Class Initialized
INFO - 2018-08-14 13:40:50 --> Router Class Initialized
INFO - 2018-08-14 13:40:50 --> Output Class Initialized
INFO - 2018-08-14 13:40:50 --> Security Class Initialized
DEBUG - 2018-08-14 13:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:40:50 --> Input Class Initialized
INFO - 2018-08-14 13:40:50 --> Language Class Initialized
INFO - 2018-08-14 13:40:50 --> Language Class Initialized
INFO - 2018-08-14 13:40:50 --> Config Class Initialized
INFO - 2018-08-14 13:40:50 --> Loader Class Initialized
INFO - 2018-08-14 13:40:50 --> Helper loaded: url_helper
INFO - 2018-08-14 13:40:50 --> Helper loaded: file_helper
INFO - 2018-08-14 13:40:50 --> Helper loaded: form_helper
INFO - 2018-08-14 13:40:50 --> Helper loaded: my_helper
INFO - 2018-08-14 13:40:50 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:40:50 --> Controller Class Initialized
INFO - 2018-08-14 13:42:27 --> Config Class Initialized
INFO - 2018-08-14 13:42:27 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:42:27 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:42:27 --> Utf8 Class Initialized
INFO - 2018-08-14 13:42:27 --> URI Class Initialized
INFO - 2018-08-14 13:42:27 --> Router Class Initialized
INFO - 2018-08-14 13:42:27 --> Output Class Initialized
INFO - 2018-08-14 13:42:27 --> Security Class Initialized
DEBUG - 2018-08-14 13:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:42:27 --> Input Class Initialized
INFO - 2018-08-14 13:42:27 --> Language Class Initialized
INFO - 2018-08-14 13:42:27 --> Language Class Initialized
INFO - 2018-08-14 13:42:27 --> Config Class Initialized
INFO - 2018-08-14 13:42:27 --> Loader Class Initialized
INFO - 2018-08-14 13:42:28 --> Helper loaded: url_helper
INFO - 2018-08-14 13:42:28 --> Helper loaded: file_helper
INFO - 2018-08-14 13:42:28 --> Helper loaded: form_helper
INFO - 2018-08-14 13:42:28 --> Helper loaded: my_helper
INFO - 2018-08-14 13:42:28 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:42:28 --> Controller Class Initialized
DEBUG - 2018-08-14 13:42:28 --> File loaded: D:\laragon\www\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2018-08-14 13:42:28 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:42:28 --> Final output sent to browser
DEBUG - 2018-08-14 13:42:28 --> Total execution time: 0.5778
INFO - 2018-08-14 13:42:28 --> Config Class Initialized
INFO - 2018-08-14 13:42:28 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:42:28 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:42:28 --> Utf8 Class Initialized
INFO - 2018-08-14 13:42:28 --> URI Class Initialized
INFO - 2018-08-14 13:42:28 --> Router Class Initialized
INFO - 2018-08-14 13:42:28 --> Output Class Initialized
INFO - 2018-08-14 13:42:28 --> Security Class Initialized
DEBUG - 2018-08-14 13:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:42:28 --> Input Class Initialized
INFO - 2018-08-14 13:42:28 --> Language Class Initialized
ERROR - 2018-08-14 13:42:28 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:42:28 --> Config Class Initialized
INFO - 2018-08-14 13:42:28 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:42:28 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:42:28 --> Utf8 Class Initialized
INFO - 2018-08-14 13:42:28 --> URI Class Initialized
INFO - 2018-08-14 13:42:28 --> Router Class Initialized
INFO - 2018-08-14 13:42:28 --> Output Class Initialized
INFO - 2018-08-14 13:42:28 --> Security Class Initialized
DEBUG - 2018-08-14 13:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:42:28 --> Input Class Initialized
INFO - 2018-08-14 13:42:28 --> Language Class Initialized
INFO - 2018-08-14 13:42:29 --> Language Class Initialized
INFO - 2018-08-14 13:42:29 --> Config Class Initialized
INFO - 2018-08-14 13:42:29 --> Loader Class Initialized
INFO - 2018-08-14 13:42:29 --> Helper loaded: url_helper
INFO - 2018-08-14 13:42:29 --> Helper loaded: file_helper
INFO - 2018-08-14 13:42:29 --> Helper loaded: form_helper
INFO - 2018-08-14 13:42:29 --> Helper loaded: my_helper
INFO - 2018-08-14 13:42:29 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:42:29 --> Controller Class Initialized
INFO - 2018-08-14 13:43:35 --> Config Class Initialized
INFO - 2018-08-14 13:43:35 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:43:35 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:43:35 --> Utf8 Class Initialized
INFO - 2018-08-14 13:43:35 --> URI Class Initialized
INFO - 2018-08-14 13:43:35 --> Router Class Initialized
INFO - 2018-08-14 13:43:35 --> Output Class Initialized
INFO - 2018-08-14 13:43:35 --> Security Class Initialized
DEBUG - 2018-08-14 13:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:43:35 --> Input Class Initialized
INFO - 2018-08-14 13:43:35 --> Language Class Initialized
INFO - 2018-08-14 13:43:35 --> Language Class Initialized
INFO - 2018-08-14 13:43:35 --> Config Class Initialized
INFO - 2018-08-14 13:43:35 --> Loader Class Initialized
INFO - 2018-08-14 13:43:35 --> Helper loaded: url_helper
INFO - 2018-08-14 13:43:35 --> Helper loaded: file_helper
INFO - 2018-08-14 13:43:35 --> Helper loaded: form_helper
INFO - 2018-08-14 13:43:35 --> Helper loaded: my_helper
INFO - 2018-08-14 13:43:36 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:43:36 --> Controller Class Initialized
DEBUG - 2018-08-14 13:43:36 --> File loaded: D:\laragon\www\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2018-08-14 13:43:36 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:43:36 --> Final output sent to browser
DEBUG - 2018-08-14 13:43:36 --> Total execution time: 0.4232
INFO - 2018-08-14 13:43:36 --> Config Class Initialized
INFO - 2018-08-14 13:43:36 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:43:36 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:43:36 --> Utf8 Class Initialized
INFO - 2018-08-14 13:43:36 --> URI Class Initialized
INFO - 2018-08-14 13:43:36 --> Router Class Initialized
INFO - 2018-08-14 13:43:36 --> Output Class Initialized
INFO - 2018-08-14 13:43:36 --> Security Class Initialized
DEBUG - 2018-08-14 13:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:43:36 --> Input Class Initialized
INFO - 2018-08-14 13:43:36 --> Language Class Initialized
ERROR - 2018-08-14 13:43:36 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:43:36 --> Config Class Initialized
INFO - 2018-08-14 13:43:36 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:43:36 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:43:36 --> Utf8 Class Initialized
INFO - 2018-08-14 13:43:36 --> URI Class Initialized
INFO - 2018-08-14 13:43:36 --> Router Class Initialized
INFO - 2018-08-14 13:43:36 --> Output Class Initialized
INFO - 2018-08-14 13:43:36 --> Security Class Initialized
DEBUG - 2018-08-14 13:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:43:36 --> Input Class Initialized
INFO - 2018-08-14 13:43:36 --> Language Class Initialized
INFO - 2018-08-14 13:43:36 --> Language Class Initialized
INFO - 2018-08-14 13:43:36 --> Config Class Initialized
INFO - 2018-08-14 13:43:36 --> Loader Class Initialized
INFO - 2018-08-14 13:43:36 --> Helper loaded: url_helper
INFO - 2018-08-14 13:43:36 --> Helper loaded: file_helper
INFO - 2018-08-14 13:43:36 --> Helper loaded: form_helper
INFO - 2018-08-14 13:43:36 --> Helper loaded: my_helper
INFO - 2018-08-14 13:43:36 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:43:37 --> Controller Class Initialized
INFO - 2018-08-14 13:43:38 --> Config Class Initialized
INFO - 2018-08-14 13:43:38 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:43:38 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:43:38 --> Utf8 Class Initialized
INFO - 2018-08-14 13:43:38 --> URI Class Initialized
INFO - 2018-08-14 13:43:38 --> Router Class Initialized
INFO - 2018-08-14 13:43:38 --> Output Class Initialized
INFO - 2018-08-14 13:43:38 --> Security Class Initialized
DEBUG - 2018-08-14 13:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:43:38 --> Input Class Initialized
INFO - 2018-08-14 13:43:38 --> Language Class Initialized
ERROR - 2018-08-14 13:43:38 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:43:40 --> Config Class Initialized
INFO - 2018-08-14 13:43:40 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:43:40 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:43:40 --> Utf8 Class Initialized
INFO - 2018-08-14 13:43:40 --> URI Class Initialized
INFO - 2018-08-14 13:43:40 --> Router Class Initialized
INFO - 2018-08-14 13:43:40 --> Output Class Initialized
INFO - 2018-08-14 13:43:40 --> Security Class Initialized
DEBUG - 2018-08-14 13:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:43:40 --> Input Class Initialized
INFO - 2018-08-14 13:43:40 --> Language Class Initialized
INFO - 2018-08-14 13:43:40 --> Language Class Initialized
INFO - 2018-08-14 13:43:40 --> Config Class Initialized
INFO - 2018-08-14 13:43:40 --> Loader Class Initialized
INFO - 2018-08-14 13:43:40 --> Helper loaded: url_helper
INFO - 2018-08-14 13:43:40 --> Helper loaded: file_helper
INFO - 2018-08-14 13:43:40 --> Helper loaded: form_helper
INFO - 2018-08-14 13:43:40 --> Helper loaded: my_helper
INFO - 2018-08-14 13:43:40 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:43:40 --> Controller Class Initialized
DEBUG - 2018-08-14 13:43:40 --> File loaded: D:\laragon\www\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2018-08-14 13:43:40 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:43:40 --> Final output sent to browser
DEBUG - 2018-08-14 13:43:40 --> Total execution time: 0.3686
INFO - 2018-08-14 13:43:40 --> Config Class Initialized
INFO - 2018-08-14 13:43:40 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:43:40 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:43:40 --> Utf8 Class Initialized
INFO - 2018-08-14 13:43:40 --> URI Class Initialized
INFO - 2018-08-14 13:43:40 --> Router Class Initialized
INFO - 2018-08-14 13:43:40 --> Output Class Initialized
INFO - 2018-08-14 13:43:41 --> Security Class Initialized
DEBUG - 2018-08-14 13:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:43:41 --> Input Class Initialized
INFO - 2018-08-14 13:43:41 --> Language Class Initialized
ERROR - 2018-08-14 13:43:41 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:43:41 --> Config Class Initialized
INFO - 2018-08-14 13:43:41 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:43:41 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:43:41 --> Utf8 Class Initialized
INFO - 2018-08-14 13:43:41 --> URI Class Initialized
INFO - 2018-08-14 13:43:41 --> Router Class Initialized
INFO - 2018-08-14 13:43:41 --> Output Class Initialized
INFO - 2018-08-14 13:43:41 --> Security Class Initialized
DEBUG - 2018-08-14 13:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:43:41 --> Input Class Initialized
INFO - 2018-08-14 13:43:41 --> Language Class Initialized
INFO - 2018-08-14 13:43:41 --> Language Class Initialized
INFO - 2018-08-14 13:43:41 --> Config Class Initialized
INFO - 2018-08-14 13:43:41 --> Loader Class Initialized
INFO - 2018-08-14 13:43:41 --> Helper loaded: url_helper
INFO - 2018-08-14 13:43:41 --> Helper loaded: file_helper
INFO - 2018-08-14 13:43:41 --> Helper loaded: form_helper
INFO - 2018-08-14 13:43:41 --> Helper loaded: my_helper
INFO - 2018-08-14 13:43:41 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:43:41 --> Controller Class Initialized
INFO - 2018-08-14 13:44:10 --> Config Class Initialized
INFO - 2018-08-14 13:44:10 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:44:10 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:44:10 --> Utf8 Class Initialized
INFO - 2018-08-14 13:44:10 --> URI Class Initialized
INFO - 2018-08-14 13:44:10 --> Router Class Initialized
INFO - 2018-08-14 13:44:10 --> Output Class Initialized
INFO - 2018-08-14 13:44:10 --> Security Class Initialized
DEBUG - 2018-08-14 13:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:44:10 --> Input Class Initialized
INFO - 2018-08-14 13:44:10 --> Language Class Initialized
INFO - 2018-08-14 13:44:10 --> Language Class Initialized
INFO - 2018-08-14 13:44:10 --> Config Class Initialized
INFO - 2018-08-14 13:44:10 --> Loader Class Initialized
INFO - 2018-08-14 13:44:10 --> Helper loaded: url_helper
INFO - 2018-08-14 13:44:10 --> Helper loaded: file_helper
INFO - 2018-08-14 13:44:10 --> Helper loaded: form_helper
INFO - 2018-08-14 13:44:10 --> Helper loaded: my_helper
INFO - 2018-08-14 13:44:10 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:44:10 --> Controller Class Initialized
DEBUG - 2018-08-14 13:44:10 --> File loaded: D:\laragon\www\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2018-08-14 13:44:10 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:44:10 --> Final output sent to browser
DEBUG - 2018-08-14 13:44:10 --> Total execution time: 0.4557
INFO - 2018-08-14 13:44:10 --> Config Class Initialized
INFO - 2018-08-14 13:44:10 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:44:10 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:44:10 --> Utf8 Class Initialized
INFO - 2018-08-14 13:44:10 --> URI Class Initialized
INFO - 2018-08-14 13:44:10 --> Router Class Initialized
INFO - 2018-08-14 13:44:11 --> Output Class Initialized
INFO - 2018-08-14 13:44:11 --> Security Class Initialized
DEBUG - 2018-08-14 13:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:44:11 --> Input Class Initialized
INFO - 2018-08-14 13:44:11 --> Language Class Initialized
ERROR - 2018-08-14 13:44:11 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:44:11 --> Config Class Initialized
INFO - 2018-08-14 13:44:11 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:44:11 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:44:11 --> Utf8 Class Initialized
INFO - 2018-08-14 13:44:11 --> URI Class Initialized
INFO - 2018-08-14 13:44:11 --> Router Class Initialized
INFO - 2018-08-14 13:44:11 --> Output Class Initialized
INFO - 2018-08-14 13:44:11 --> Security Class Initialized
DEBUG - 2018-08-14 13:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:44:11 --> Input Class Initialized
INFO - 2018-08-14 13:44:11 --> Language Class Initialized
INFO - 2018-08-14 13:44:11 --> Language Class Initialized
INFO - 2018-08-14 13:44:11 --> Config Class Initialized
INFO - 2018-08-14 13:44:11 --> Loader Class Initialized
INFO - 2018-08-14 13:44:11 --> Helper loaded: url_helper
INFO - 2018-08-14 13:44:11 --> Helper loaded: file_helper
INFO - 2018-08-14 13:44:11 --> Helper loaded: form_helper
INFO - 2018-08-14 13:44:11 --> Helper loaded: my_helper
INFO - 2018-08-14 13:44:11 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:44:11 --> Controller Class Initialized
INFO - 2018-08-14 13:46:44 --> Config Class Initialized
INFO - 2018-08-14 13:46:44 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:46:44 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:46:44 --> Utf8 Class Initialized
INFO - 2018-08-14 13:46:44 --> URI Class Initialized
INFO - 2018-08-14 13:46:44 --> Router Class Initialized
INFO - 2018-08-14 13:46:44 --> Output Class Initialized
INFO - 2018-08-14 13:46:44 --> Security Class Initialized
DEBUG - 2018-08-14 13:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:46:44 --> Input Class Initialized
INFO - 2018-08-14 13:46:44 --> Language Class Initialized
INFO - 2018-08-14 13:46:44 --> Language Class Initialized
INFO - 2018-08-14 13:46:44 --> Config Class Initialized
INFO - 2018-08-14 13:46:44 --> Loader Class Initialized
INFO - 2018-08-14 13:46:44 --> Helper loaded: url_helper
INFO - 2018-08-14 13:46:44 --> Helper loaded: file_helper
INFO - 2018-08-14 13:46:44 --> Helper loaded: form_helper
INFO - 2018-08-14 13:46:44 --> Helper loaded: my_helper
INFO - 2018-08-14 13:46:45 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:46:45 --> Controller Class Initialized
DEBUG - 2018-08-14 13:46:45 --> File loaded: D:\laragon\www\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2018-08-14 13:46:45 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:46:45 --> Final output sent to browser
DEBUG - 2018-08-14 13:46:45 --> Total execution time: 0.3686
INFO - 2018-08-14 13:46:45 --> Config Class Initialized
INFO - 2018-08-14 13:46:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:46:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:46:45 --> Utf8 Class Initialized
INFO - 2018-08-14 13:46:45 --> URI Class Initialized
INFO - 2018-08-14 13:46:45 --> Router Class Initialized
INFO - 2018-08-14 13:46:45 --> Output Class Initialized
INFO - 2018-08-14 13:46:45 --> Security Class Initialized
DEBUG - 2018-08-14 13:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:46:45 --> Input Class Initialized
INFO - 2018-08-14 13:46:45 --> Language Class Initialized
ERROR - 2018-08-14 13:46:45 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:46:51 --> Config Class Initialized
INFO - 2018-08-14 13:46:51 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:46:51 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:46:51 --> Utf8 Class Initialized
INFO - 2018-08-14 13:46:51 --> URI Class Initialized
INFO - 2018-08-14 13:46:51 --> Router Class Initialized
INFO - 2018-08-14 13:46:51 --> Output Class Initialized
INFO - 2018-08-14 13:46:51 --> Security Class Initialized
DEBUG - 2018-08-14 13:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:46:51 --> Input Class Initialized
INFO - 2018-08-14 13:46:51 --> Language Class Initialized
INFO - 2018-08-14 13:46:51 --> Language Class Initialized
INFO - 2018-08-14 13:46:51 --> Config Class Initialized
INFO - 2018-08-14 13:46:52 --> Loader Class Initialized
INFO - 2018-08-14 13:46:52 --> Helper loaded: url_helper
INFO - 2018-08-14 13:46:52 --> Helper loaded: file_helper
INFO - 2018-08-14 13:46:52 --> Helper loaded: form_helper
INFO - 2018-08-14 13:46:52 --> Helper loaded: my_helper
INFO - 2018-08-14 13:46:52 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:46:52 --> Controller Class Initialized
INFO - 2018-08-14 13:46:53 --> Config Class Initialized
INFO - 2018-08-14 13:46:53 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:46:53 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:46:53 --> Utf8 Class Initialized
INFO - 2018-08-14 13:46:53 --> URI Class Initialized
INFO - 2018-08-14 13:46:53 --> Router Class Initialized
INFO - 2018-08-14 13:46:53 --> Output Class Initialized
INFO - 2018-08-14 13:46:53 --> Security Class Initialized
DEBUG - 2018-08-14 13:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:46:53 --> Input Class Initialized
INFO - 2018-08-14 13:46:53 --> Language Class Initialized
INFO - 2018-08-14 13:46:53 --> Language Class Initialized
INFO - 2018-08-14 13:46:53 --> Config Class Initialized
INFO - 2018-08-14 13:46:53 --> Loader Class Initialized
INFO - 2018-08-14 13:46:53 --> Helper loaded: url_helper
INFO - 2018-08-14 13:46:53 --> Helper loaded: file_helper
INFO - 2018-08-14 13:46:53 --> Helper loaded: form_helper
INFO - 2018-08-14 13:46:53 --> Helper loaded: my_helper
INFO - 2018-08-14 13:46:53 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:46:53 --> Controller Class Initialized
DEBUG - 2018-08-14 13:46:53 --> File loaded: D:\laragon\www\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2018-08-14 13:46:53 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:46:53 --> Final output sent to browser
DEBUG - 2018-08-14 13:46:53 --> Total execution time: 0.3824
INFO - 2018-08-14 13:46:54 --> Config Class Initialized
INFO - 2018-08-14 13:46:54 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:46:54 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:46:54 --> Utf8 Class Initialized
INFO - 2018-08-14 13:46:54 --> URI Class Initialized
INFO - 2018-08-14 13:46:54 --> Router Class Initialized
INFO - 2018-08-14 13:46:54 --> Output Class Initialized
INFO - 2018-08-14 13:46:54 --> Security Class Initialized
DEBUG - 2018-08-14 13:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:46:54 --> Input Class Initialized
INFO - 2018-08-14 13:46:54 --> Language Class Initialized
ERROR - 2018-08-14 13:46:54 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:46:55 --> Config Class Initialized
INFO - 2018-08-14 13:46:55 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:46:55 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:46:55 --> Utf8 Class Initialized
INFO - 2018-08-14 13:46:55 --> URI Class Initialized
INFO - 2018-08-14 13:46:55 --> Router Class Initialized
INFO - 2018-08-14 13:46:55 --> Output Class Initialized
INFO - 2018-08-14 13:46:55 --> Security Class Initialized
DEBUG - 2018-08-14 13:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:46:55 --> Input Class Initialized
INFO - 2018-08-14 13:46:55 --> Language Class Initialized
INFO - 2018-08-14 13:46:55 --> Language Class Initialized
INFO - 2018-08-14 13:46:55 --> Config Class Initialized
INFO - 2018-08-14 13:46:55 --> Loader Class Initialized
INFO - 2018-08-14 13:46:55 --> Helper loaded: url_helper
INFO - 2018-08-14 13:46:55 --> Helper loaded: file_helper
INFO - 2018-08-14 13:46:55 --> Helper loaded: form_helper
INFO - 2018-08-14 13:46:55 --> Helper loaded: my_helper
INFO - 2018-08-14 13:46:56 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:46:56 --> Controller Class Initialized
DEBUG - 2018-08-14 13:46:56 --> File loaded: D:\laragon\www\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2018-08-14 13:46:56 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:46:56 --> Final output sent to browser
DEBUG - 2018-08-14 13:46:56 --> Total execution time: 0.3809
INFO - 2018-08-14 13:46:56 --> Config Class Initialized
INFO - 2018-08-14 13:46:56 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:46:56 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:46:56 --> Utf8 Class Initialized
INFO - 2018-08-14 13:46:56 --> URI Class Initialized
INFO - 2018-08-14 13:46:56 --> Router Class Initialized
INFO - 2018-08-14 13:46:56 --> Output Class Initialized
INFO - 2018-08-14 13:46:56 --> Security Class Initialized
DEBUG - 2018-08-14 13:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:46:56 --> Input Class Initialized
INFO - 2018-08-14 13:46:56 --> Language Class Initialized
ERROR - 2018-08-14 13:46:56 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:46:56 --> Config Class Initialized
INFO - 2018-08-14 13:46:56 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:46:56 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:46:56 --> Utf8 Class Initialized
INFO - 2018-08-14 13:46:56 --> URI Class Initialized
INFO - 2018-08-14 13:46:56 --> Router Class Initialized
INFO - 2018-08-14 13:46:56 --> Output Class Initialized
INFO - 2018-08-14 13:46:56 --> Security Class Initialized
DEBUG - 2018-08-14 13:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:46:56 --> Input Class Initialized
INFO - 2018-08-14 13:46:56 --> Language Class Initialized
INFO - 2018-08-14 13:46:56 --> Language Class Initialized
INFO - 2018-08-14 13:46:56 --> Config Class Initialized
INFO - 2018-08-14 13:46:56 --> Loader Class Initialized
INFO - 2018-08-14 13:46:56 --> Helper loaded: url_helper
INFO - 2018-08-14 13:46:56 --> Helper loaded: file_helper
INFO - 2018-08-14 13:46:56 --> Helper loaded: form_helper
INFO - 2018-08-14 13:46:56 --> Helper loaded: my_helper
INFO - 2018-08-14 13:46:56 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:46:56 --> Controller Class Initialized
INFO - 2018-08-14 13:47:30 --> Config Class Initialized
INFO - 2018-08-14 13:47:30 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:47:30 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:47:30 --> Utf8 Class Initialized
INFO - 2018-08-14 13:47:30 --> URI Class Initialized
INFO - 2018-08-14 13:47:30 --> Router Class Initialized
INFO - 2018-08-14 13:47:30 --> Output Class Initialized
INFO - 2018-08-14 13:47:30 --> Security Class Initialized
DEBUG - 2018-08-14 13:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:47:30 --> Input Class Initialized
INFO - 2018-08-14 13:47:30 --> Language Class Initialized
INFO - 2018-08-14 13:47:30 --> Language Class Initialized
INFO - 2018-08-14 13:47:30 --> Config Class Initialized
INFO - 2018-08-14 13:47:30 --> Loader Class Initialized
INFO - 2018-08-14 13:47:30 --> Helper loaded: url_helper
INFO - 2018-08-14 13:47:30 --> Helper loaded: file_helper
INFO - 2018-08-14 13:47:30 --> Helper loaded: form_helper
INFO - 2018-08-14 13:47:30 --> Helper loaded: my_helper
INFO - 2018-08-14 13:47:30 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:47:30 --> Controller Class Initialized
INFO - 2018-08-14 13:47:33 --> Config Class Initialized
INFO - 2018-08-14 13:47:33 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:47:33 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:47:33 --> Utf8 Class Initialized
INFO - 2018-08-14 13:47:33 --> URI Class Initialized
INFO - 2018-08-14 13:47:33 --> Router Class Initialized
INFO - 2018-08-14 13:47:33 --> Output Class Initialized
INFO - 2018-08-14 13:47:33 --> Security Class Initialized
DEBUG - 2018-08-14 13:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:47:33 --> Input Class Initialized
INFO - 2018-08-14 13:47:33 --> Language Class Initialized
INFO - 2018-08-14 13:47:33 --> Language Class Initialized
INFO - 2018-08-14 13:47:33 --> Config Class Initialized
INFO - 2018-08-14 13:47:33 --> Loader Class Initialized
INFO - 2018-08-14 13:47:33 --> Helper loaded: url_helper
INFO - 2018-08-14 13:47:33 --> Helper loaded: file_helper
INFO - 2018-08-14 13:47:33 --> Helper loaded: form_helper
INFO - 2018-08-14 13:47:33 --> Helper loaded: my_helper
INFO - 2018-08-14 13:47:33 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:47:33 --> Controller Class Initialized
ERROR - 2018-08-14 13:47:33 --> Severity: Notice --> Undefined variable: status_form D:\laragon\www\nilai\application\modules\data_siswa\views\form.php 223
DEBUG - 2018-08-14 13:47:33 --> File loaded: D:\laragon\www\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2018-08-14 13:47:33 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:47:33 --> Final output sent to browser
DEBUG - 2018-08-14 13:47:33 --> Total execution time: 0.3878
INFO - 2018-08-14 13:47:34 --> Config Class Initialized
INFO - 2018-08-14 13:47:34 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:47:34 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:47:34 --> Utf8 Class Initialized
INFO - 2018-08-14 13:47:34 --> URI Class Initialized
INFO - 2018-08-14 13:47:34 --> Router Class Initialized
INFO - 2018-08-14 13:47:34 --> Output Class Initialized
INFO - 2018-08-14 13:47:34 --> Security Class Initialized
DEBUG - 2018-08-14 13:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:47:34 --> Input Class Initialized
INFO - 2018-08-14 13:47:34 --> Language Class Initialized
ERROR - 2018-08-14 13:47:34 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:47:42 --> Config Class Initialized
INFO - 2018-08-14 13:47:42 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:47:42 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:47:42 --> Utf8 Class Initialized
INFO - 2018-08-14 13:47:42 --> URI Class Initialized
INFO - 2018-08-14 13:47:42 --> Router Class Initialized
INFO - 2018-08-14 13:47:42 --> Output Class Initialized
INFO - 2018-08-14 13:47:42 --> Security Class Initialized
DEBUG - 2018-08-14 13:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:47:42 --> Input Class Initialized
INFO - 2018-08-14 13:47:42 --> Language Class Initialized
INFO - 2018-08-14 13:47:43 --> Language Class Initialized
INFO - 2018-08-14 13:47:43 --> Config Class Initialized
INFO - 2018-08-14 13:47:43 --> Loader Class Initialized
INFO - 2018-08-14 13:47:43 --> Helper loaded: url_helper
INFO - 2018-08-14 13:47:43 --> Helper loaded: file_helper
INFO - 2018-08-14 13:47:43 --> Helper loaded: form_helper
INFO - 2018-08-14 13:47:43 --> Helper loaded: my_helper
INFO - 2018-08-14 13:47:43 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:47:43 --> Controller Class Initialized
DEBUG - 2018-08-14 13:47:43 --> File loaded: D:\laragon\www\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2018-08-14 13:47:43 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:47:43 --> Final output sent to browser
DEBUG - 2018-08-14 13:47:43 --> Total execution time: 0.3963
INFO - 2018-08-14 13:47:43 --> Config Class Initialized
INFO - 2018-08-14 13:47:43 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:47:43 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:47:43 --> Utf8 Class Initialized
INFO - 2018-08-14 13:47:43 --> URI Class Initialized
INFO - 2018-08-14 13:47:43 --> Router Class Initialized
INFO - 2018-08-14 13:47:43 --> Output Class Initialized
INFO - 2018-08-14 13:47:43 --> Security Class Initialized
DEBUG - 2018-08-14 13:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:47:43 --> Input Class Initialized
INFO - 2018-08-14 13:47:43 --> Language Class Initialized
ERROR - 2018-08-14 13:47:43 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:47:43 --> Config Class Initialized
INFO - 2018-08-14 13:47:43 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:47:43 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:47:43 --> Utf8 Class Initialized
INFO - 2018-08-14 13:47:43 --> URI Class Initialized
INFO - 2018-08-14 13:47:43 --> Router Class Initialized
INFO - 2018-08-14 13:47:43 --> Output Class Initialized
INFO - 2018-08-14 13:47:43 --> Security Class Initialized
DEBUG - 2018-08-14 13:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:47:44 --> Input Class Initialized
INFO - 2018-08-14 13:47:44 --> Language Class Initialized
INFO - 2018-08-14 13:47:44 --> Language Class Initialized
INFO - 2018-08-14 13:47:44 --> Config Class Initialized
INFO - 2018-08-14 13:47:44 --> Loader Class Initialized
INFO - 2018-08-14 13:47:44 --> Helper loaded: url_helper
INFO - 2018-08-14 13:47:44 --> Helper loaded: file_helper
INFO - 2018-08-14 13:47:44 --> Helper loaded: form_helper
INFO - 2018-08-14 13:47:44 --> Helper loaded: my_helper
INFO - 2018-08-14 13:47:44 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:47:44 --> Controller Class Initialized
INFO - 2018-08-14 13:47:44 --> Config Class Initialized
INFO - 2018-08-14 13:47:44 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:47:44 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:47:45 --> Utf8 Class Initialized
INFO - 2018-08-14 13:47:45 --> URI Class Initialized
INFO - 2018-08-14 13:47:45 --> Router Class Initialized
INFO - 2018-08-14 13:47:45 --> Output Class Initialized
INFO - 2018-08-14 13:47:45 --> Security Class Initialized
DEBUG - 2018-08-14 13:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:47:45 --> Input Class Initialized
INFO - 2018-08-14 13:47:45 --> Language Class Initialized
INFO - 2018-08-14 13:47:45 --> Language Class Initialized
INFO - 2018-08-14 13:47:45 --> Config Class Initialized
INFO - 2018-08-14 13:47:45 --> Loader Class Initialized
INFO - 2018-08-14 13:47:45 --> Helper loaded: url_helper
INFO - 2018-08-14 13:47:45 --> Helper loaded: file_helper
INFO - 2018-08-14 13:47:45 --> Helper loaded: form_helper
INFO - 2018-08-14 13:47:45 --> Helper loaded: my_helper
INFO - 2018-08-14 13:47:45 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:47:45 --> Controller Class Initialized
DEBUG - 2018-08-14 13:47:45 --> File loaded: D:\laragon\www\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2018-08-14 13:47:45 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:47:45 --> Final output sent to browser
DEBUG - 2018-08-14 13:47:45 --> Total execution time: 0.3643
INFO - 2018-08-14 13:47:45 --> Config Class Initialized
INFO - 2018-08-14 13:47:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:47:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:47:45 --> Utf8 Class Initialized
INFO - 2018-08-14 13:47:45 --> URI Class Initialized
INFO - 2018-08-14 13:47:45 --> Router Class Initialized
INFO - 2018-08-14 13:47:45 --> Output Class Initialized
INFO - 2018-08-14 13:47:45 --> Security Class Initialized
DEBUG - 2018-08-14 13:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:47:45 --> Input Class Initialized
INFO - 2018-08-14 13:47:45 --> Language Class Initialized
ERROR - 2018-08-14 13:47:45 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:47:45 --> Config Class Initialized
INFO - 2018-08-14 13:47:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:47:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:47:45 --> Utf8 Class Initialized
INFO - 2018-08-14 13:47:45 --> URI Class Initialized
INFO - 2018-08-14 13:47:45 --> Router Class Initialized
INFO - 2018-08-14 13:47:45 --> Output Class Initialized
INFO - 2018-08-14 13:47:45 --> Security Class Initialized
DEBUG - 2018-08-14 13:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:47:45 --> Input Class Initialized
INFO - 2018-08-14 13:47:45 --> Language Class Initialized
INFO - 2018-08-14 13:47:45 --> Language Class Initialized
INFO - 2018-08-14 13:47:45 --> Config Class Initialized
INFO - 2018-08-14 13:47:45 --> Loader Class Initialized
INFO - 2018-08-14 13:47:45 --> Helper loaded: url_helper
INFO - 2018-08-14 13:47:46 --> Helper loaded: file_helper
INFO - 2018-08-14 13:47:46 --> Helper loaded: form_helper
INFO - 2018-08-14 13:47:46 --> Helper loaded: my_helper
INFO - 2018-08-14 13:47:46 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:47:46 --> Controller Class Initialized
INFO - 2018-08-14 13:47:46 --> Config Class Initialized
INFO - 2018-08-14 13:47:46 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:47:46 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:47:46 --> Utf8 Class Initialized
INFO - 2018-08-14 13:47:46 --> URI Class Initialized
INFO - 2018-08-14 13:47:46 --> Router Class Initialized
INFO - 2018-08-14 13:47:46 --> Output Class Initialized
INFO - 2018-08-14 13:47:46 --> Security Class Initialized
DEBUG - 2018-08-14 13:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:47:46 --> Input Class Initialized
INFO - 2018-08-14 13:47:46 --> Language Class Initialized
INFO - 2018-08-14 13:47:46 --> Language Class Initialized
INFO - 2018-08-14 13:47:46 --> Config Class Initialized
INFO - 2018-08-14 13:47:47 --> Loader Class Initialized
INFO - 2018-08-14 13:47:47 --> Helper loaded: url_helper
INFO - 2018-08-14 13:47:47 --> Helper loaded: file_helper
INFO - 2018-08-14 13:47:47 --> Helper loaded: form_helper
INFO - 2018-08-14 13:47:47 --> Helper loaded: my_helper
INFO - 2018-08-14 13:47:47 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:47:47 --> Controller Class Initialized
DEBUG - 2018-08-14 13:47:47 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:47:47 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:47:47 --> Final output sent to browser
DEBUG - 2018-08-14 13:47:47 --> Total execution time: 0.4255
INFO - 2018-08-14 13:47:47 --> Config Class Initialized
INFO - 2018-08-14 13:47:47 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:47:47 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:47:47 --> Utf8 Class Initialized
INFO - 2018-08-14 13:47:47 --> URI Class Initialized
INFO - 2018-08-14 13:47:47 --> Router Class Initialized
INFO - 2018-08-14 13:47:47 --> Output Class Initialized
INFO - 2018-08-14 13:47:47 --> Security Class Initialized
DEBUG - 2018-08-14 13:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:47:47 --> Input Class Initialized
INFO - 2018-08-14 13:47:47 --> Language Class Initialized
ERROR - 2018-08-14 13:47:47 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:47:47 --> Config Class Initialized
INFO - 2018-08-14 13:47:47 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:47:47 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:47:47 --> Utf8 Class Initialized
INFO - 2018-08-14 13:47:47 --> URI Class Initialized
INFO - 2018-08-14 13:47:47 --> Router Class Initialized
INFO - 2018-08-14 13:47:47 --> Output Class Initialized
INFO - 2018-08-14 13:47:47 --> Security Class Initialized
DEBUG - 2018-08-14 13:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:47:47 --> Input Class Initialized
INFO - 2018-08-14 13:47:47 --> Language Class Initialized
INFO - 2018-08-14 13:47:47 --> Language Class Initialized
INFO - 2018-08-14 13:47:47 --> Config Class Initialized
INFO - 2018-08-14 13:47:47 --> Loader Class Initialized
INFO - 2018-08-14 13:47:47 --> Helper loaded: url_helper
INFO - 2018-08-14 13:47:47 --> Helper loaded: file_helper
INFO - 2018-08-14 13:47:47 --> Helper loaded: form_helper
INFO - 2018-08-14 13:47:47 --> Helper loaded: my_helper
INFO - 2018-08-14 13:47:47 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:47:47 --> Controller Class Initialized
INFO - 2018-08-14 13:47:50 --> Config Class Initialized
INFO - 2018-08-14 13:47:50 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:47:50 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:47:50 --> Utf8 Class Initialized
INFO - 2018-08-14 13:47:50 --> URI Class Initialized
INFO - 2018-08-14 13:47:50 --> Router Class Initialized
INFO - 2018-08-14 13:47:50 --> Output Class Initialized
INFO - 2018-08-14 13:47:50 --> Security Class Initialized
DEBUG - 2018-08-14 13:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:47:50 --> Input Class Initialized
INFO - 2018-08-14 13:47:50 --> Language Class Initialized
INFO - 2018-08-14 13:47:50 --> Language Class Initialized
INFO - 2018-08-14 13:47:50 --> Config Class Initialized
INFO - 2018-08-14 13:47:50 --> Loader Class Initialized
INFO - 2018-08-14 13:47:50 --> Helper loaded: url_helper
INFO - 2018-08-14 13:47:50 --> Helper loaded: file_helper
INFO - 2018-08-14 13:47:50 --> Helper loaded: form_helper
INFO - 2018-08-14 13:47:50 --> Helper loaded: my_helper
INFO - 2018-08-14 13:47:50 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:47:50 --> Controller Class Initialized
DEBUG - 2018-08-14 13:47:50 --> File loaded: D:\laragon\www\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2018-08-14 13:47:50 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:47:50 --> Final output sent to browser
DEBUG - 2018-08-14 13:47:50 --> Total execution time: 0.4277
INFO - 2018-08-14 13:47:50 --> Config Class Initialized
INFO - 2018-08-14 13:47:50 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:47:50 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:47:50 --> Utf8 Class Initialized
INFO - 2018-08-14 13:47:50 --> URI Class Initialized
INFO - 2018-08-14 13:47:50 --> Router Class Initialized
INFO - 2018-08-14 13:47:50 --> Output Class Initialized
INFO - 2018-08-14 13:47:50 --> Security Class Initialized
DEBUG - 2018-08-14 13:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:47:50 --> Input Class Initialized
INFO - 2018-08-14 13:47:50 --> Language Class Initialized
ERROR - 2018-08-14 13:47:50 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:47:50 --> Config Class Initialized
INFO - 2018-08-14 13:47:50 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:47:50 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:47:50 --> Utf8 Class Initialized
INFO - 2018-08-14 13:47:51 --> URI Class Initialized
INFO - 2018-08-14 13:47:51 --> Router Class Initialized
INFO - 2018-08-14 13:47:51 --> Output Class Initialized
INFO - 2018-08-14 13:47:51 --> Security Class Initialized
DEBUG - 2018-08-14 13:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:47:51 --> Input Class Initialized
INFO - 2018-08-14 13:47:51 --> Language Class Initialized
INFO - 2018-08-14 13:47:51 --> Language Class Initialized
INFO - 2018-08-14 13:47:51 --> Config Class Initialized
INFO - 2018-08-14 13:47:51 --> Loader Class Initialized
INFO - 2018-08-14 13:47:51 --> Helper loaded: url_helper
INFO - 2018-08-14 13:47:51 --> Helper loaded: file_helper
INFO - 2018-08-14 13:47:51 --> Helper loaded: form_helper
INFO - 2018-08-14 13:47:51 --> Helper loaded: my_helper
INFO - 2018-08-14 13:47:51 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:47:51 --> Controller Class Initialized
INFO - 2018-08-14 13:48:02 --> Config Class Initialized
INFO - 2018-08-14 13:48:02 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:48:02 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:48:02 --> Utf8 Class Initialized
INFO - 2018-08-14 13:48:02 --> URI Class Initialized
INFO - 2018-08-14 13:48:02 --> Router Class Initialized
INFO - 2018-08-14 13:48:02 --> Output Class Initialized
INFO - 2018-08-14 13:48:02 --> Security Class Initialized
DEBUG - 2018-08-14 13:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:48:02 --> Input Class Initialized
INFO - 2018-08-14 13:48:02 --> Language Class Initialized
INFO - 2018-08-14 13:48:02 --> Language Class Initialized
INFO - 2018-08-14 13:48:02 --> Config Class Initialized
INFO - 2018-08-14 13:48:02 --> Loader Class Initialized
INFO - 2018-08-14 13:48:02 --> Helper loaded: url_helper
INFO - 2018-08-14 13:48:02 --> Helper loaded: file_helper
INFO - 2018-08-14 13:48:02 --> Helper loaded: form_helper
INFO - 2018-08-14 13:48:02 --> Helper loaded: my_helper
INFO - 2018-08-14 13:48:02 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:48:02 --> Controller Class Initialized
DEBUG - 2018-08-14 13:48:02 --> File loaded: D:\laragon\www\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2018-08-14 13:48:02 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:48:02 --> Final output sent to browser
DEBUG - 2018-08-14 13:48:02 --> Total execution time: 0.5055
INFO - 2018-08-14 13:48:02 --> Config Class Initialized
INFO - 2018-08-14 13:48:02 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:48:02 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:48:02 --> Utf8 Class Initialized
INFO - 2018-08-14 13:48:02 --> URI Class Initialized
INFO - 2018-08-14 13:48:02 --> Router Class Initialized
INFO - 2018-08-14 13:48:02 --> Output Class Initialized
INFO - 2018-08-14 13:48:02 --> Security Class Initialized
DEBUG - 2018-08-14 13:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:48:02 --> Input Class Initialized
INFO - 2018-08-14 13:48:02 --> Language Class Initialized
ERROR - 2018-08-14 13:48:02 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:48:02 --> Config Class Initialized
INFO - 2018-08-14 13:48:03 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:48:03 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:48:03 --> Utf8 Class Initialized
INFO - 2018-08-14 13:48:03 --> URI Class Initialized
INFO - 2018-08-14 13:48:03 --> Router Class Initialized
INFO - 2018-08-14 13:48:03 --> Output Class Initialized
INFO - 2018-08-14 13:48:03 --> Security Class Initialized
DEBUG - 2018-08-14 13:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:48:03 --> Input Class Initialized
INFO - 2018-08-14 13:48:03 --> Language Class Initialized
INFO - 2018-08-14 13:48:03 --> Language Class Initialized
INFO - 2018-08-14 13:48:03 --> Config Class Initialized
INFO - 2018-08-14 13:48:03 --> Loader Class Initialized
INFO - 2018-08-14 13:48:03 --> Helper loaded: url_helper
INFO - 2018-08-14 13:48:03 --> Helper loaded: file_helper
INFO - 2018-08-14 13:48:03 --> Helper loaded: form_helper
INFO - 2018-08-14 13:48:03 --> Helper loaded: my_helper
INFO - 2018-08-14 13:48:03 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:48:03 --> Controller Class Initialized
INFO - 2018-08-14 13:48:14 --> Config Class Initialized
INFO - 2018-08-14 13:48:15 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:48:15 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:48:15 --> Utf8 Class Initialized
INFO - 2018-08-14 13:48:15 --> URI Class Initialized
INFO - 2018-08-14 13:48:15 --> Router Class Initialized
INFO - 2018-08-14 13:48:15 --> Output Class Initialized
INFO - 2018-08-14 13:48:15 --> Security Class Initialized
DEBUG - 2018-08-14 13:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:48:15 --> Input Class Initialized
INFO - 2018-08-14 13:48:15 --> Language Class Initialized
INFO - 2018-08-14 13:48:15 --> Language Class Initialized
INFO - 2018-08-14 13:48:15 --> Config Class Initialized
INFO - 2018-08-14 13:48:15 --> Loader Class Initialized
INFO - 2018-08-14 13:48:15 --> Helper loaded: url_helper
INFO - 2018-08-14 13:48:15 --> Helper loaded: file_helper
INFO - 2018-08-14 13:48:15 --> Helper loaded: form_helper
INFO - 2018-08-14 13:48:15 --> Helper loaded: my_helper
INFO - 2018-08-14 13:48:15 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:48:15 --> Controller Class Initialized
DEBUG - 2018-08-14 13:48:15 --> File loaded: D:\laragon\www\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2018-08-14 13:48:15 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:48:15 --> Final output sent to browser
DEBUG - 2018-08-14 13:48:15 --> Total execution time: 0.7508
INFO - 2018-08-14 13:48:15 --> Config Class Initialized
INFO - 2018-08-14 13:48:15 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:48:16 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:48:16 --> Utf8 Class Initialized
INFO - 2018-08-14 13:48:16 --> URI Class Initialized
INFO - 2018-08-14 13:48:16 --> Router Class Initialized
INFO - 2018-08-14 13:48:16 --> Output Class Initialized
INFO - 2018-08-14 13:48:16 --> Security Class Initialized
DEBUG - 2018-08-14 13:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:48:16 --> Input Class Initialized
INFO - 2018-08-14 13:48:16 --> Language Class Initialized
ERROR - 2018-08-14 13:48:16 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:48:16 --> Config Class Initialized
INFO - 2018-08-14 13:48:16 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:48:16 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:48:16 --> Utf8 Class Initialized
INFO - 2018-08-14 13:48:16 --> URI Class Initialized
INFO - 2018-08-14 13:48:16 --> Router Class Initialized
INFO - 2018-08-14 13:48:16 --> Output Class Initialized
INFO - 2018-08-14 13:48:16 --> Security Class Initialized
DEBUG - 2018-08-14 13:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:48:16 --> Input Class Initialized
INFO - 2018-08-14 13:48:16 --> Language Class Initialized
INFO - 2018-08-14 13:48:16 --> Language Class Initialized
INFO - 2018-08-14 13:48:16 --> Config Class Initialized
INFO - 2018-08-14 13:48:16 --> Loader Class Initialized
INFO - 2018-08-14 13:48:16 --> Helper loaded: url_helper
INFO - 2018-08-14 13:48:16 --> Helper loaded: file_helper
INFO - 2018-08-14 13:48:16 --> Helper loaded: form_helper
INFO - 2018-08-14 13:48:16 --> Helper loaded: my_helper
INFO - 2018-08-14 13:48:16 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:48:16 --> Controller Class Initialized
INFO - 2018-08-14 13:49:30 --> Config Class Initialized
INFO - 2018-08-14 13:49:30 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:49:30 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:49:30 --> Utf8 Class Initialized
INFO - 2018-08-14 13:49:30 --> URI Class Initialized
INFO - 2018-08-14 13:49:30 --> Router Class Initialized
INFO - 2018-08-14 13:49:30 --> Output Class Initialized
INFO - 2018-08-14 13:49:30 --> Security Class Initialized
DEBUG - 2018-08-14 13:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:49:30 --> Input Class Initialized
INFO - 2018-08-14 13:49:30 --> Language Class Initialized
INFO - 2018-08-14 13:49:30 --> Language Class Initialized
INFO - 2018-08-14 13:49:30 --> Config Class Initialized
INFO - 2018-08-14 13:49:30 --> Loader Class Initialized
INFO - 2018-08-14 13:49:30 --> Helper loaded: url_helper
INFO - 2018-08-14 13:49:30 --> Helper loaded: file_helper
INFO - 2018-08-14 13:49:30 --> Helper loaded: form_helper
INFO - 2018-08-14 13:49:30 --> Helper loaded: my_helper
INFO - 2018-08-14 13:49:30 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:49:30 --> Controller Class Initialized
DEBUG - 2018-08-14 13:49:30 --> File loaded: D:\laragon\www\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2018-08-14 13:49:30 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:49:30 --> Final output sent to browser
DEBUG - 2018-08-14 13:49:30 --> Total execution time: 0.4072
INFO - 2018-08-14 13:49:30 --> Config Class Initialized
INFO - 2018-08-14 13:49:30 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:49:30 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:49:30 --> Utf8 Class Initialized
INFO - 2018-08-14 13:49:30 --> URI Class Initialized
INFO - 2018-08-14 13:49:30 --> Router Class Initialized
INFO - 2018-08-14 13:49:30 --> Output Class Initialized
INFO - 2018-08-14 13:49:30 --> Security Class Initialized
DEBUG - 2018-08-14 13:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:49:30 --> Input Class Initialized
INFO - 2018-08-14 13:49:30 --> Language Class Initialized
ERROR - 2018-08-14 13:49:30 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:49:30 --> Config Class Initialized
INFO - 2018-08-14 13:49:30 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:49:30 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:49:31 --> Utf8 Class Initialized
INFO - 2018-08-14 13:49:31 --> URI Class Initialized
INFO - 2018-08-14 13:49:31 --> Router Class Initialized
INFO - 2018-08-14 13:49:31 --> Output Class Initialized
INFO - 2018-08-14 13:49:31 --> Security Class Initialized
DEBUG - 2018-08-14 13:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:49:31 --> Input Class Initialized
INFO - 2018-08-14 13:49:31 --> Language Class Initialized
INFO - 2018-08-14 13:49:31 --> Language Class Initialized
INFO - 2018-08-14 13:49:31 --> Config Class Initialized
INFO - 2018-08-14 13:49:31 --> Loader Class Initialized
INFO - 2018-08-14 13:49:31 --> Helper loaded: url_helper
INFO - 2018-08-14 13:49:31 --> Helper loaded: file_helper
INFO - 2018-08-14 13:49:31 --> Helper loaded: form_helper
INFO - 2018-08-14 13:49:31 --> Helper loaded: my_helper
INFO - 2018-08-14 13:49:31 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:49:31 --> Controller Class Initialized
INFO - 2018-08-14 13:50:20 --> Config Class Initialized
INFO - 2018-08-14 13:50:20 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:50:20 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:50:20 --> Utf8 Class Initialized
INFO - 2018-08-14 13:50:20 --> URI Class Initialized
INFO - 2018-08-14 13:50:20 --> Router Class Initialized
INFO - 2018-08-14 13:50:20 --> Output Class Initialized
INFO - 2018-08-14 13:50:20 --> Security Class Initialized
DEBUG - 2018-08-14 13:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:50:20 --> Input Class Initialized
INFO - 2018-08-14 13:50:21 --> Language Class Initialized
INFO - 2018-08-14 13:50:21 --> Language Class Initialized
INFO - 2018-08-14 13:50:21 --> Config Class Initialized
INFO - 2018-08-14 13:50:21 --> Loader Class Initialized
INFO - 2018-08-14 13:50:21 --> Helper loaded: url_helper
INFO - 2018-08-14 13:50:21 --> Helper loaded: file_helper
INFO - 2018-08-14 13:50:21 --> Helper loaded: form_helper
INFO - 2018-08-14 13:50:21 --> Helper loaded: my_helper
INFO - 2018-08-14 13:50:21 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:50:21 --> Controller Class Initialized
DEBUG - 2018-08-14 13:50:21 --> File loaded: D:\laragon\www\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2018-08-14 13:50:21 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:50:21 --> Final output sent to browser
DEBUG - 2018-08-14 13:50:21 --> Total execution time: 0.3883
INFO - 2018-08-14 13:50:21 --> Config Class Initialized
INFO - 2018-08-14 13:50:21 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:50:21 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:50:21 --> Utf8 Class Initialized
INFO - 2018-08-14 13:50:21 --> URI Class Initialized
INFO - 2018-08-14 13:50:21 --> Router Class Initialized
INFO - 2018-08-14 13:50:21 --> Output Class Initialized
INFO - 2018-08-14 13:50:21 --> Security Class Initialized
DEBUG - 2018-08-14 13:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:50:21 --> Input Class Initialized
INFO - 2018-08-14 13:50:21 --> Language Class Initialized
ERROR - 2018-08-14 13:50:21 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:50:21 --> Config Class Initialized
INFO - 2018-08-14 13:50:21 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:50:21 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:50:21 --> Utf8 Class Initialized
INFO - 2018-08-14 13:50:21 --> URI Class Initialized
INFO - 2018-08-14 13:50:21 --> Router Class Initialized
INFO - 2018-08-14 13:50:21 --> Output Class Initialized
INFO - 2018-08-14 13:50:21 --> Security Class Initialized
DEBUG - 2018-08-14 13:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:50:21 --> Input Class Initialized
INFO - 2018-08-14 13:50:21 --> Language Class Initialized
INFO - 2018-08-14 13:50:21 --> Language Class Initialized
INFO - 2018-08-14 13:50:21 --> Config Class Initialized
INFO - 2018-08-14 13:50:21 --> Loader Class Initialized
INFO - 2018-08-14 13:50:21 --> Helper loaded: url_helper
INFO - 2018-08-14 13:50:21 --> Helper loaded: file_helper
INFO - 2018-08-14 13:50:21 --> Helper loaded: form_helper
INFO - 2018-08-14 13:50:21 --> Helper loaded: my_helper
INFO - 2018-08-14 13:50:22 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:50:22 --> Controller Class Initialized
INFO - 2018-08-14 13:50:23 --> Config Class Initialized
INFO - 2018-08-14 13:50:23 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:50:23 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:50:23 --> Utf8 Class Initialized
INFO - 2018-08-14 13:50:23 --> URI Class Initialized
INFO - 2018-08-14 13:50:23 --> Router Class Initialized
INFO - 2018-08-14 13:50:23 --> Output Class Initialized
INFO - 2018-08-14 13:50:23 --> Security Class Initialized
DEBUG - 2018-08-14 13:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:50:23 --> Input Class Initialized
INFO - 2018-08-14 13:50:23 --> Language Class Initialized
INFO - 2018-08-14 13:50:23 --> Language Class Initialized
INFO - 2018-08-14 13:50:23 --> Config Class Initialized
INFO - 2018-08-14 13:50:23 --> Loader Class Initialized
INFO - 2018-08-14 13:50:23 --> Helper loaded: url_helper
INFO - 2018-08-14 13:50:23 --> Helper loaded: file_helper
INFO - 2018-08-14 13:50:23 --> Helper loaded: form_helper
INFO - 2018-08-14 13:50:23 --> Helper loaded: my_helper
INFO - 2018-08-14 13:50:23 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:50:24 --> Controller Class Initialized
INFO - 2018-08-14 13:50:26 --> Config Class Initialized
INFO - 2018-08-14 13:50:26 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:50:26 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:50:26 --> Utf8 Class Initialized
INFO - 2018-08-14 13:50:26 --> URI Class Initialized
INFO - 2018-08-14 13:50:26 --> Router Class Initialized
INFO - 2018-08-14 13:50:26 --> Output Class Initialized
INFO - 2018-08-14 13:50:26 --> Security Class Initialized
DEBUG - 2018-08-14 13:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:50:27 --> Input Class Initialized
INFO - 2018-08-14 13:50:27 --> Language Class Initialized
INFO - 2018-08-14 13:50:27 --> Language Class Initialized
INFO - 2018-08-14 13:50:27 --> Config Class Initialized
INFO - 2018-08-14 13:50:27 --> Loader Class Initialized
INFO - 2018-08-14 13:50:27 --> Helper loaded: url_helper
INFO - 2018-08-14 13:50:27 --> Helper loaded: file_helper
INFO - 2018-08-14 13:50:27 --> Helper loaded: form_helper
INFO - 2018-08-14 13:50:27 --> Helper loaded: my_helper
INFO - 2018-08-14 13:50:27 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:50:27 --> Controller Class Initialized
INFO - 2018-08-14 13:50:27 --> Config Class Initialized
INFO - 2018-08-14 13:50:27 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:50:27 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:50:27 --> Utf8 Class Initialized
INFO - 2018-08-14 13:50:27 --> URI Class Initialized
INFO - 2018-08-14 13:50:27 --> Router Class Initialized
INFO - 2018-08-14 13:50:27 --> Output Class Initialized
INFO - 2018-08-14 13:50:27 --> Security Class Initialized
DEBUG - 2018-08-14 13:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:50:27 --> Input Class Initialized
INFO - 2018-08-14 13:50:27 --> Language Class Initialized
INFO - 2018-08-14 13:50:27 --> Language Class Initialized
INFO - 2018-08-14 13:50:27 --> Config Class Initialized
INFO - 2018-08-14 13:50:27 --> Loader Class Initialized
INFO - 2018-08-14 13:50:27 --> Helper loaded: url_helper
INFO - 2018-08-14 13:50:27 --> Helper loaded: file_helper
INFO - 2018-08-14 13:50:27 --> Helper loaded: form_helper
INFO - 2018-08-14 13:50:27 --> Helper loaded: my_helper
INFO - 2018-08-14 13:50:27 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:50:28 --> Controller Class Initialized
DEBUG - 2018-08-14 13:50:28 --> File loaded: D:\laragon\www\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2018-08-14 13:50:28 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:50:28 --> Final output sent to browser
DEBUG - 2018-08-14 13:50:28 --> Total execution time: 0.8568
INFO - 2018-08-14 13:50:28 --> Config Class Initialized
INFO - 2018-08-14 13:50:28 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:50:28 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:50:28 --> Utf8 Class Initialized
INFO - 2018-08-14 13:50:28 --> URI Class Initialized
INFO - 2018-08-14 13:50:28 --> Router Class Initialized
INFO - 2018-08-14 13:50:28 --> Output Class Initialized
INFO - 2018-08-14 13:50:28 --> Security Class Initialized
DEBUG - 2018-08-14 13:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:50:28 --> Input Class Initialized
INFO - 2018-08-14 13:50:28 --> Language Class Initialized
ERROR - 2018-08-14 13:50:28 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:50:28 --> Config Class Initialized
INFO - 2018-08-14 13:50:28 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:50:28 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:50:28 --> Utf8 Class Initialized
INFO - 2018-08-14 13:50:28 --> URI Class Initialized
INFO - 2018-08-14 13:50:28 --> Router Class Initialized
INFO - 2018-08-14 13:50:28 --> Output Class Initialized
INFO - 2018-08-14 13:50:28 --> Security Class Initialized
DEBUG - 2018-08-14 13:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:50:28 --> Input Class Initialized
INFO - 2018-08-14 13:50:28 --> Language Class Initialized
INFO - 2018-08-14 13:50:28 --> Language Class Initialized
INFO - 2018-08-14 13:50:28 --> Config Class Initialized
INFO - 2018-08-14 13:50:28 --> Loader Class Initialized
INFO - 2018-08-14 13:50:28 --> Helper loaded: url_helper
INFO - 2018-08-14 13:50:28 --> Helper loaded: file_helper
INFO - 2018-08-14 13:50:28 --> Helper loaded: form_helper
INFO - 2018-08-14 13:50:28 --> Helper loaded: my_helper
INFO - 2018-08-14 13:50:29 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:50:29 --> Controller Class Initialized
INFO - 2018-08-14 13:50:30 --> Config Class Initialized
INFO - 2018-08-14 13:50:30 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:50:30 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:50:30 --> Utf8 Class Initialized
INFO - 2018-08-14 13:50:30 --> URI Class Initialized
INFO - 2018-08-14 13:50:30 --> Router Class Initialized
INFO - 2018-08-14 13:50:30 --> Output Class Initialized
INFO - 2018-08-14 13:50:30 --> Security Class Initialized
DEBUG - 2018-08-14 13:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:50:30 --> Input Class Initialized
INFO - 2018-08-14 13:50:30 --> Language Class Initialized
INFO - 2018-08-14 13:50:30 --> Language Class Initialized
INFO - 2018-08-14 13:50:30 --> Config Class Initialized
INFO - 2018-08-14 13:50:30 --> Loader Class Initialized
INFO - 2018-08-14 13:50:30 --> Helper loaded: url_helper
INFO - 2018-08-14 13:50:30 --> Helper loaded: file_helper
INFO - 2018-08-14 13:50:30 --> Helper loaded: form_helper
INFO - 2018-08-14 13:50:30 --> Helper loaded: my_helper
INFO - 2018-08-14 13:50:30 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:50:30 --> Controller Class Initialized
INFO - 2018-08-14 13:51:04 --> Config Class Initialized
INFO - 2018-08-14 13:51:04 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:51:04 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:51:04 --> Utf8 Class Initialized
INFO - 2018-08-14 13:51:04 --> URI Class Initialized
INFO - 2018-08-14 13:51:04 --> Router Class Initialized
INFO - 2018-08-14 13:51:04 --> Output Class Initialized
INFO - 2018-08-14 13:51:04 --> Security Class Initialized
DEBUG - 2018-08-14 13:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:51:04 --> Input Class Initialized
INFO - 2018-08-14 13:51:04 --> Language Class Initialized
INFO - 2018-08-14 13:51:04 --> Language Class Initialized
INFO - 2018-08-14 13:51:04 --> Config Class Initialized
INFO - 2018-08-14 13:51:04 --> Loader Class Initialized
INFO - 2018-08-14 13:51:04 --> Helper loaded: url_helper
INFO - 2018-08-14 13:51:04 --> Helper loaded: file_helper
INFO - 2018-08-14 13:51:04 --> Helper loaded: form_helper
INFO - 2018-08-14 13:51:04 --> Helper loaded: my_helper
INFO - 2018-08-14 13:51:04 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:51:04 --> Controller Class Initialized
DEBUG - 2018-08-14 13:51:04 --> File loaded: D:\laragon\www\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2018-08-14 13:51:04 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:51:04 --> Final output sent to browser
DEBUG - 2018-08-14 13:51:04 --> Total execution time: 0.4260
INFO - 2018-08-14 13:51:04 --> Config Class Initialized
INFO - 2018-08-14 13:51:04 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:51:04 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:51:04 --> Utf8 Class Initialized
INFO - 2018-08-14 13:51:04 --> URI Class Initialized
INFO - 2018-08-14 13:51:05 --> Router Class Initialized
INFO - 2018-08-14 13:51:05 --> Output Class Initialized
INFO - 2018-08-14 13:51:05 --> Security Class Initialized
DEBUG - 2018-08-14 13:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:51:05 --> Input Class Initialized
INFO - 2018-08-14 13:51:05 --> Language Class Initialized
ERROR - 2018-08-14 13:51:05 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:51:05 --> Config Class Initialized
INFO - 2018-08-14 13:51:05 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:51:05 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:51:05 --> Utf8 Class Initialized
INFO - 2018-08-14 13:51:05 --> URI Class Initialized
INFO - 2018-08-14 13:51:05 --> Router Class Initialized
INFO - 2018-08-14 13:51:05 --> Output Class Initialized
INFO - 2018-08-14 13:51:05 --> Security Class Initialized
DEBUG - 2018-08-14 13:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:51:05 --> Input Class Initialized
INFO - 2018-08-14 13:51:05 --> Language Class Initialized
INFO - 2018-08-14 13:51:05 --> Language Class Initialized
INFO - 2018-08-14 13:51:05 --> Config Class Initialized
INFO - 2018-08-14 13:51:05 --> Loader Class Initialized
INFO - 2018-08-14 13:51:05 --> Helper loaded: url_helper
INFO - 2018-08-14 13:51:05 --> Helper loaded: file_helper
INFO - 2018-08-14 13:51:05 --> Helper loaded: form_helper
INFO - 2018-08-14 13:51:05 --> Helper loaded: my_helper
INFO - 2018-08-14 13:51:05 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:51:05 --> Controller Class Initialized
INFO - 2018-08-14 13:51:11 --> Config Class Initialized
INFO - 2018-08-14 13:51:11 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:51:11 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:51:11 --> Utf8 Class Initialized
INFO - 2018-08-14 13:51:11 --> URI Class Initialized
INFO - 2018-08-14 13:51:11 --> Router Class Initialized
INFO - 2018-08-14 13:51:11 --> Output Class Initialized
INFO - 2018-08-14 13:51:11 --> Security Class Initialized
DEBUG - 2018-08-14 13:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:51:12 --> Input Class Initialized
INFO - 2018-08-14 13:51:12 --> Language Class Initialized
INFO - 2018-08-14 13:51:12 --> Language Class Initialized
INFO - 2018-08-14 13:51:12 --> Config Class Initialized
INFO - 2018-08-14 13:51:12 --> Loader Class Initialized
INFO - 2018-08-14 13:51:12 --> Helper loaded: url_helper
INFO - 2018-08-14 13:51:12 --> Helper loaded: file_helper
INFO - 2018-08-14 13:51:12 --> Helper loaded: form_helper
INFO - 2018-08-14 13:51:12 --> Helper loaded: my_helper
INFO - 2018-08-14 13:51:12 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:51:12 --> Controller Class Initialized
INFO - 2018-08-14 13:51:13 --> Config Class Initialized
INFO - 2018-08-14 13:51:13 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:51:13 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:51:13 --> Utf8 Class Initialized
INFO - 2018-08-14 13:51:13 --> URI Class Initialized
INFO - 2018-08-14 13:51:13 --> Router Class Initialized
INFO - 2018-08-14 13:51:13 --> Output Class Initialized
INFO - 2018-08-14 13:51:13 --> Security Class Initialized
DEBUG - 2018-08-14 13:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:51:13 --> Input Class Initialized
INFO - 2018-08-14 13:51:13 --> Language Class Initialized
INFO - 2018-08-14 13:51:13 --> Language Class Initialized
INFO - 2018-08-14 13:51:13 --> Config Class Initialized
INFO - 2018-08-14 13:51:13 --> Loader Class Initialized
INFO - 2018-08-14 13:51:13 --> Helper loaded: url_helper
INFO - 2018-08-14 13:51:13 --> Helper loaded: file_helper
INFO - 2018-08-14 13:51:13 --> Helper loaded: form_helper
INFO - 2018-08-14 13:51:14 --> Helper loaded: my_helper
INFO - 2018-08-14 13:51:14 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:51:14 --> Controller Class Initialized
INFO - 2018-08-14 13:51:14 --> Config Class Initialized
INFO - 2018-08-14 13:51:14 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:51:14 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:51:14 --> Utf8 Class Initialized
INFO - 2018-08-14 13:51:14 --> URI Class Initialized
INFO - 2018-08-14 13:51:14 --> Router Class Initialized
INFO - 2018-08-14 13:51:14 --> Output Class Initialized
INFO - 2018-08-14 13:51:14 --> Security Class Initialized
DEBUG - 2018-08-14 13:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:51:14 --> Input Class Initialized
INFO - 2018-08-14 13:51:14 --> Language Class Initialized
INFO - 2018-08-14 13:51:14 --> Language Class Initialized
INFO - 2018-08-14 13:51:14 --> Config Class Initialized
INFO - 2018-08-14 13:51:14 --> Loader Class Initialized
INFO - 2018-08-14 13:51:14 --> Helper loaded: url_helper
INFO - 2018-08-14 13:51:14 --> Helper loaded: file_helper
INFO - 2018-08-14 13:51:14 --> Helper loaded: form_helper
INFO - 2018-08-14 13:51:14 --> Helper loaded: my_helper
INFO - 2018-08-14 13:51:14 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:51:14 --> Controller Class Initialized
DEBUG - 2018-08-14 13:51:14 --> File loaded: D:\laragon\www\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2018-08-14 13:51:14 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:51:14 --> Final output sent to browser
DEBUG - 2018-08-14 13:51:14 --> Total execution time: 0.5405
INFO - 2018-08-14 13:51:14 --> Config Class Initialized
INFO - 2018-08-14 13:51:14 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:51:15 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:51:15 --> Utf8 Class Initialized
INFO - 2018-08-14 13:51:15 --> URI Class Initialized
INFO - 2018-08-14 13:51:15 --> Router Class Initialized
INFO - 2018-08-14 13:51:15 --> Output Class Initialized
INFO - 2018-08-14 13:51:15 --> Security Class Initialized
DEBUG - 2018-08-14 13:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:51:15 --> Input Class Initialized
INFO - 2018-08-14 13:51:15 --> Language Class Initialized
ERROR - 2018-08-14 13:51:15 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:51:15 --> Config Class Initialized
INFO - 2018-08-14 13:51:15 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:51:15 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:51:15 --> Utf8 Class Initialized
INFO - 2018-08-14 13:51:15 --> URI Class Initialized
INFO - 2018-08-14 13:51:15 --> Router Class Initialized
INFO - 2018-08-14 13:51:15 --> Output Class Initialized
INFO - 2018-08-14 13:51:15 --> Security Class Initialized
DEBUG - 2018-08-14 13:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:51:15 --> Input Class Initialized
INFO - 2018-08-14 13:51:15 --> Language Class Initialized
INFO - 2018-08-14 13:51:15 --> Language Class Initialized
INFO - 2018-08-14 13:51:15 --> Config Class Initialized
INFO - 2018-08-14 13:51:15 --> Loader Class Initialized
INFO - 2018-08-14 13:51:15 --> Helper loaded: url_helper
INFO - 2018-08-14 13:51:15 --> Helper loaded: file_helper
INFO - 2018-08-14 13:51:15 --> Helper loaded: form_helper
INFO - 2018-08-14 13:51:15 --> Helper loaded: my_helper
INFO - 2018-08-14 13:51:15 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:51:15 --> Controller Class Initialized
INFO - 2018-08-14 13:51:23 --> Config Class Initialized
INFO - 2018-08-14 13:51:23 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:51:23 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:51:23 --> Utf8 Class Initialized
INFO - 2018-08-14 13:51:23 --> URI Class Initialized
INFO - 2018-08-14 13:51:23 --> Router Class Initialized
INFO - 2018-08-14 13:51:23 --> Output Class Initialized
INFO - 2018-08-14 13:51:23 --> Security Class Initialized
DEBUG - 2018-08-14 13:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:51:23 --> Input Class Initialized
INFO - 2018-08-14 13:51:23 --> Language Class Initialized
INFO - 2018-08-14 13:51:23 --> Language Class Initialized
INFO - 2018-08-14 13:51:23 --> Config Class Initialized
INFO - 2018-08-14 13:51:23 --> Loader Class Initialized
INFO - 2018-08-14 13:51:23 --> Helper loaded: url_helper
INFO - 2018-08-14 13:51:23 --> Helper loaded: file_helper
INFO - 2018-08-14 13:51:23 --> Helper loaded: form_helper
INFO - 2018-08-14 13:51:23 --> Helper loaded: my_helper
INFO - 2018-08-14 13:51:23 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:51:24 --> Controller Class Initialized
INFO - 2018-08-14 13:52:17 --> Config Class Initialized
INFO - 2018-08-14 13:52:17 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:52:17 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:52:17 --> Utf8 Class Initialized
INFO - 2018-08-14 13:52:17 --> URI Class Initialized
INFO - 2018-08-14 13:52:17 --> Router Class Initialized
INFO - 2018-08-14 13:52:17 --> Output Class Initialized
INFO - 2018-08-14 13:52:17 --> Security Class Initialized
DEBUG - 2018-08-14 13:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:52:17 --> Input Class Initialized
INFO - 2018-08-14 13:52:17 --> Language Class Initialized
INFO - 2018-08-14 13:52:17 --> Language Class Initialized
INFO - 2018-08-14 13:52:17 --> Config Class Initialized
INFO - 2018-08-14 13:52:17 --> Loader Class Initialized
INFO - 2018-08-14 13:52:17 --> Helper loaded: url_helper
INFO - 2018-08-14 13:52:17 --> Helper loaded: file_helper
INFO - 2018-08-14 13:52:17 --> Helper loaded: form_helper
INFO - 2018-08-14 13:52:17 --> Helper loaded: my_helper
INFO - 2018-08-14 13:52:17 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:52:18 --> Controller Class Initialized
DEBUG - 2018-08-14 13:52:18 --> File loaded: D:\laragon\www\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2018-08-14 13:52:18 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:52:18 --> Final output sent to browser
DEBUG - 2018-08-14 13:52:18 --> Total execution time: 0.6306
INFO - 2018-08-14 13:52:18 --> Config Class Initialized
INFO - 2018-08-14 13:52:18 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:52:18 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:52:18 --> Utf8 Class Initialized
INFO - 2018-08-14 13:52:18 --> URI Class Initialized
INFO - 2018-08-14 13:52:18 --> Router Class Initialized
INFO - 2018-08-14 13:52:18 --> Output Class Initialized
INFO - 2018-08-14 13:52:18 --> Security Class Initialized
DEBUG - 2018-08-14 13:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:52:18 --> Input Class Initialized
INFO - 2018-08-14 13:52:18 --> Language Class Initialized
ERROR - 2018-08-14 13:52:18 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:52:18 --> Config Class Initialized
INFO - 2018-08-14 13:52:18 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:52:18 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:52:18 --> Utf8 Class Initialized
INFO - 2018-08-14 13:52:18 --> URI Class Initialized
INFO - 2018-08-14 13:52:18 --> Router Class Initialized
INFO - 2018-08-14 13:52:18 --> Output Class Initialized
INFO - 2018-08-14 13:52:18 --> Security Class Initialized
DEBUG - 2018-08-14 13:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:52:18 --> Input Class Initialized
INFO - 2018-08-14 13:52:18 --> Language Class Initialized
INFO - 2018-08-14 13:52:18 --> Language Class Initialized
INFO - 2018-08-14 13:52:18 --> Config Class Initialized
INFO - 2018-08-14 13:52:18 --> Loader Class Initialized
INFO - 2018-08-14 13:52:18 --> Helper loaded: url_helper
INFO - 2018-08-14 13:52:18 --> Helper loaded: file_helper
INFO - 2018-08-14 13:52:18 --> Helper loaded: form_helper
INFO - 2018-08-14 13:52:19 --> Helper loaded: my_helper
INFO - 2018-08-14 13:52:19 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:52:19 --> Controller Class Initialized
INFO - 2018-08-14 13:52:20 --> Config Class Initialized
INFO - 2018-08-14 13:52:20 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:52:20 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:52:20 --> Utf8 Class Initialized
INFO - 2018-08-14 13:52:20 --> URI Class Initialized
INFO - 2018-08-14 13:52:20 --> Router Class Initialized
INFO - 2018-08-14 13:52:20 --> Output Class Initialized
INFO - 2018-08-14 13:52:20 --> Security Class Initialized
DEBUG - 2018-08-14 13:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:52:20 --> Input Class Initialized
INFO - 2018-08-14 13:52:20 --> Language Class Initialized
INFO - 2018-08-14 13:52:20 --> Language Class Initialized
INFO - 2018-08-14 13:52:20 --> Config Class Initialized
INFO - 2018-08-14 13:52:20 --> Loader Class Initialized
INFO - 2018-08-14 13:52:20 --> Helper loaded: url_helper
INFO - 2018-08-14 13:52:20 --> Helper loaded: file_helper
INFO - 2018-08-14 13:52:20 --> Helper loaded: form_helper
INFO - 2018-08-14 13:52:20 --> Helper loaded: my_helper
INFO - 2018-08-14 13:52:20 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:52:20 --> Controller Class Initialized
INFO - 2018-08-14 13:52:25 --> Config Class Initialized
INFO - 2018-08-14 13:52:25 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:52:25 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:52:25 --> Utf8 Class Initialized
INFO - 2018-08-14 13:52:25 --> URI Class Initialized
INFO - 2018-08-14 13:52:25 --> Router Class Initialized
INFO - 2018-08-14 13:52:25 --> Output Class Initialized
INFO - 2018-08-14 13:52:25 --> Security Class Initialized
DEBUG - 2018-08-14 13:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:52:25 --> Input Class Initialized
INFO - 2018-08-14 13:52:25 --> Language Class Initialized
INFO - 2018-08-14 13:52:25 --> Language Class Initialized
INFO - 2018-08-14 13:52:25 --> Config Class Initialized
INFO - 2018-08-14 13:52:25 --> Loader Class Initialized
INFO - 2018-08-14 13:52:25 --> Helper loaded: url_helper
INFO - 2018-08-14 13:52:25 --> Helper loaded: file_helper
INFO - 2018-08-14 13:52:25 --> Helper loaded: form_helper
INFO - 2018-08-14 13:52:25 --> Helper loaded: my_helper
INFO - 2018-08-14 13:52:25 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:52:25 --> Controller Class Initialized
DEBUG - 2018-08-14 13:52:25 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:52:25 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:52:25 --> Final output sent to browser
DEBUG - 2018-08-14 13:52:25 --> Total execution time: 0.3770
INFO - 2018-08-14 13:52:26 --> Config Class Initialized
INFO - 2018-08-14 13:52:26 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:52:26 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:52:26 --> Utf8 Class Initialized
INFO - 2018-08-14 13:52:26 --> URI Class Initialized
INFO - 2018-08-14 13:52:26 --> Router Class Initialized
INFO - 2018-08-14 13:52:26 --> Output Class Initialized
INFO - 2018-08-14 13:52:26 --> Security Class Initialized
DEBUG - 2018-08-14 13:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:52:26 --> Input Class Initialized
INFO - 2018-08-14 13:52:26 --> Language Class Initialized
ERROR - 2018-08-14 13:52:26 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:52:26 --> Config Class Initialized
INFO - 2018-08-14 13:52:26 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:52:26 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:52:26 --> Utf8 Class Initialized
INFO - 2018-08-14 13:52:26 --> URI Class Initialized
INFO - 2018-08-14 13:52:26 --> Router Class Initialized
INFO - 2018-08-14 13:52:26 --> Output Class Initialized
INFO - 2018-08-14 13:52:26 --> Security Class Initialized
DEBUG - 2018-08-14 13:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:52:26 --> Input Class Initialized
INFO - 2018-08-14 13:52:26 --> Language Class Initialized
INFO - 2018-08-14 13:52:26 --> Language Class Initialized
INFO - 2018-08-14 13:52:26 --> Config Class Initialized
INFO - 2018-08-14 13:52:26 --> Loader Class Initialized
INFO - 2018-08-14 13:52:26 --> Helper loaded: url_helper
INFO - 2018-08-14 13:52:26 --> Helper loaded: file_helper
INFO - 2018-08-14 13:52:26 --> Helper loaded: form_helper
INFO - 2018-08-14 13:52:26 --> Helper loaded: my_helper
INFO - 2018-08-14 13:52:26 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:52:26 --> Controller Class Initialized
INFO - 2018-08-14 13:52:56 --> Config Class Initialized
INFO - 2018-08-14 13:52:56 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:52:56 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:52:56 --> Utf8 Class Initialized
INFO - 2018-08-14 13:52:56 --> URI Class Initialized
INFO - 2018-08-14 13:52:56 --> Router Class Initialized
INFO - 2018-08-14 13:52:56 --> Output Class Initialized
INFO - 2018-08-14 13:52:56 --> Security Class Initialized
DEBUG - 2018-08-14 13:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:52:56 --> Input Class Initialized
INFO - 2018-08-14 13:52:56 --> Language Class Initialized
INFO - 2018-08-14 13:52:56 --> Language Class Initialized
INFO - 2018-08-14 13:52:56 --> Config Class Initialized
INFO - 2018-08-14 13:52:56 --> Loader Class Initialized
INFO - 2018-08-14 13:52:56 --> Helper loaded: url_helper
INFO - 2018-08-14 13:52:56 --> Helper loaded: file_helper
INFO - 2018-08-14 13:52:56 --> Helper loaded: form_helper
INFO - 2018-08-14 13:52:56 --> Helper loaded: my_helper
INFO - 2018-08-14 13:52:56 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:52:56 --> Controller Class Initialized
DEBUG - 2018-08-14 13:52:56 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 13:52:56 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:52:56 --> Final output sent to browser
DEBUG - 2018-08-14 13:52:56 --> Total execution time: 0.4865
INFO - 2018-08-14 13:52:56 --> Config Class Initialized
INFO - 2018-08-14 13:52:56 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:52:56 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:52:56 --> Utf8 Class Initialized
INFO - 2018-08-14 13:52:56 --> URI Class Initialized
INFO - 2018-08-14 13:52:57 --> Router Class Initialized
INFO - 2018-08-14 13:52:57 --> Output Class Initialized
INFO - 2018-08-14 13:52:57 --> Security Class Initialized
DEBUG - 2018-08-14 13:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:52:57 --> Input Class Initialized
INFO - 2018-08-14 13:52:57 --> Language Class Initialized
ERROR - 2018-08-14 13:52:57 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:52:57 --> Config Class Initialized
INFO - 2018-08-14 13:52:57 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:52:57 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:52:57 --> Utf8 Class Initialized
INFO - 2018-08-14 13:52:57 --> URI Class Initialized
INFO - 2018-08-14 13:52:57 --> Router Class Initialized
INFO - 2018-08-14 13:52:57 --> Output Class Initialized
INFO - 2018-08-14 13:52:57 --> Security Class Initialized
DEBUG - 2018-08-14 13:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:52:57 --> Input Class Initialized
INFO - 2018-08-14 13:52:57 --> Language Class Initialized
INFO - 2018-08-14 13:52:57 --> Language Class Initialized
INFO - 2018-08-14 13:52:57 --> Config Class Initialized
INFO - 2018-08-14 13:52:57 --> Loader Class Initialized
INFO - 2018-08-14 13:52:57 --> Helper loaded: url_helper
INFO - 2018-08-14 13:52:57 --> Helper loaded: file_helper
INFO - 2018-08-14 13:52:57 --> Helper loaded: form_helper
INFO - 2018-08-14 13:52:57 --> Helper loaded: my_helper
INFO - 2018-08-14 13:52:57 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:52:57 --> Controller Class Initialized
INFO - 2018-08-14 13:52:59 --> Config Class Initialized
INFO - 2018-08-14 13:52:59 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:52:59 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:52:59 --> Utf8 Class Initialized
INFO - 2018-08-14 13:52:59 --> URI Class Initialized
INFO - 2018-08-14 13:52:59 --> Router Class Initialized
INFO - 2018-08-14 13:52:59 --> Output Class Initialized
INFO - 2018-08-14 13:52:59 --> Security Class Initialized
DEBUG - 2018-08-14 13:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:52:59 --> Input Class Initialized
INFO - 2018-08-14 13:52:59 --> Language Class Initialized
INFO - 2018-08-14 13:53:00 --> Language Class Initialized
INFO - 2018-08-14 13:53:00 --> Config Class Initialized
INFO - 2018-08-14 13:53:00 --> Loader Class Initialized
INFO - 2018-08-14 13:53:00 --> Helper loaded: url_helper
INFO - 2018-08-14 13:53:00 --> Helper loaded: file_helper
INFO - 2018-08-14 13:53:00 --> Helper loaded: form_helper
INFO - 2018-08-14 13:53:00 --> Helper loaded: my_helper
INFO - 2018-08-14 13:53:00 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:53:00 --> Controller Class Initialized
DEBUG - 2018-08-14 13:53:00 --> File loaded: D:\laragon\www\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2018-08-14 13:53:00 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:53:00 --> Final output sent to browser
DEBUG - 2018-08-14 13:53:00 --> Total execution time: 0.4052
INFO - 2018-08-14 13:53:00 --> Config Class Initialized
INFO - 2018-08-14 13:53:00 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:53:00 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:53:00 --> Utf8 Class Initialized
INFO - 2018-08-14 13:53:00 --> URI Class Initialized
INFO - 2018-08-14 13:53:00 --> Router Class Initialized
INFO - 2018-08-14 13:53:00 --> Output Class Initialized
INFO - 2018-08-14 13:53:00 --> Security Class Initialized
DEBUG - 2018-08-14 13:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:53:00 --> Input Class Initialized
INFO - 2018-08-14 13:53:00 --> Language Class Initialized
ERROR - 2018-08-14 13:53:00 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:53:00 --> Config Class Initialized
INFO - 2018-08-14 13:53:00 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:53:00 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:53:00 --> Utf8 Class Initialized
INFO - 2018-08-14 13:53:00 --> URI Class Initialized
INFO - 2018-08-14 13:53:00 --> Router Class Initialized
INFO - 2018-08-14 13:53:00 --> Output Class Initialized
INFO - 2018-08-14 13:53:00 --> Security Class Initialized
DEBUG - 2018-08-14 13:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:53:00 --> Input Class Initialized
INFO - 2018-08-14 13:53:00 --> Language Class Initialized
INFO - 2018-08-14 13:53:00 --> Language Class Initialized
INFO - 2018-08-14 13:53:00 --> Config Class Initialized
INFO - 2018-08-14 13:53:00 --> Loader Class Initialized
INFO - 2018-08-14 13:53:00 --> Helper loaded: url_helper
INFO - 2018-08-14 13:53:00 --> Helper loaded: file_helper
INFO - 2018-08-14 13:53:00 --> Helper loaded: form_helper
INFO - 2018-08-14 13:53:00 --> Helper loaded: my_helper
INFO - 2018-08-14 13:53:00 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:53:00 --> Controller Class Initialized
INFO - 2018-08-14 13:53:01 --> Config Class Initialized
INFO - 2018-08-14 13:53:01 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:53:01 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:53:01 --> Utf8 Class Initialized
INFO - 2018-08-14 13:53:01 --> URI Class Initialized
INFO - 2018-08-14 13:53:01 --> Router Class Initialized
INFO - 2018-08-14 13:53:01 --> Output Class Initialized
INFO - 2018-08-14 13:53:01 --> Security Class Initialized
DEBUG - 2018-08-14 13:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:53:01 --> Input Class Initialized
INFO - 2018-08-14 13:53:01 --> Language Class Initialized
INFO - 2018-08-14 13:53:01 --> Language Class Initialized
INFO - 2018-08-14 13:53:01 --> Config Class Initialized
INFO - 2018-08-14 13:53:01 --> Loader Class Initialized
INFO - 2018-08-14 13:53:01 --> Helper loaded: url_helper
INFO - 2018-08-14 13:53:01 --> Helper loaded: file_helper
INFO - 2018-08-14 13:53:01 --> Helper loaded: form_helper
INFO - 2018-08-14 13:53:01 --> Helper loaded: my_helper
INFO - 2018-08-14 13:53:01 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:53:01 --> Controller Class Initialized
DEBUG - 2018-08-14 13:53:01 --> File loaded: D:\laragon\www\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2018-08-14 13:53:01 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:53:01 --> Final output sent to browser
DEBUG - 2018-08-14 13:53:01 --> Total execution time: 0.5225
INFO - 2018-08-14 13:53:01 --> Config Class Initialized
INFO - 2018-08-14 13:53:01 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:53:01 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:53:01 --> Utf8 Class Initialized
INFO - 2018-08-14 13:53:01 --> URI Class Initialized
INFO - 2018-08-14 13:53:01 --> Router Class Initialized
INFO - 2018-08-14 13:53:02 --> Output Class Initialized
INFO - 2018-08-14 13:53:02 --> Security Class Initialized
DEBUG - 2018-08-14 13:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:53:02 --> Input Class Initialized
INFO - 2018-08-14 13:53:02 --> Language Class Initialized
ERROR - 2018-08-14 13:53:02 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:53:02 --> Config Class Initialized
INFO - 2018-08-14 13:53:02 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:53:02 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:53:02 --> Utf8 Class Initialized
INFO - 2018-08-14 13:53:02 --> URI Class Initialized
INFO - 2018-08-14 13:53:02 --> Router Class Initialized
INFO - 2018-08-14 13:53:02 --> Output Class Initialized
INFO - 2018-08-14 13:53:02 --> Security Class Initialized
DEBUG - 2018-08-14 13:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:53:02 --> Input Class Initialized
INFO - 2018-08-14 13:53:02 --> Language Class Initialized
INFO - 2018-08-14 13:53:02 --> Language Class Initialized
INFO - 2018-08-14 13:53:02 --> Config Class Initialized
INFO - 2018-08-14 13:53:02 --> Loader Class Initialized
INFO - 2018-08-14 13:53:02 --> Helper loaded: url_helper
INFO - 2018-08-14 13:53:02 --> Helper loaded: file_helper
INFO - 2018-08-14 13:53:02 --> Helper loaded: form_helper
INFO - 2018-08-14 13:53:02 --> Helper loaded: my_helper
INFO - 2018-08-14 13:53:02 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:53:02 --> Controller Class Initialized
INFO - 2018-08-14 13:53:37 --> Config Class Initialized
INFO - 2018-08-14 13:53:37 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:53:37 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:53:37 --> Utf8 Class Initialized
INFO - 2018-08-14 13:53:37 --> URI Class Initialized
INFO - 2018-08-14 13:53:37 --> Router Class Initialized
INFO - 2018-08-14 13:53:37 --> Output Class Initialized
INFO - 2018-08-14 13:53:37 --> Security Class Initialized
DEBUG - 2018-08-14 13:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:53:37 --> Input Class Initialized
INFO - 2018-08-14 13:53:37 --> Language Class Initialized
INFO - 2018-08-14 13:53:37 --> Language Class Initialized
INFO - 2018-08-14 13:53:37 --> Config Class Initialized
INFO - 2018-08-14 13:53:37 --> Loader Class Initialized
INFO - 2018-08-14 13:53:37 --> Helper loaded: url_helper
INFO - 2018-08-14 13:53:37 --> Helper loaded: file_helper
INFO - 2018-08-14 13:53:37 --> Helper loaded: form_helper
INFO - 2018-08-14 13:53:37 --> Helper loaded: my_helper
INFO - 2018-08-14 13:53:37 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:53:38 --> Controller Class Initialized
DEBUG - 2018-08-14 13:53:38 --> File loaded: D:\laragon\www\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2018-08-14 13:53:38 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:53:38 --> Final output sent to browser
DEBUG - 2018-08-14 13:53:38 --> Total execution time: 0.4239
INFO - 2018-08-14 13:53:38 --> Config Class Initialized
INFO - 2018-08-14 13:53:38 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:53:38 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:53:38 --> Utf8 Class Initialized
INFO - 2018-08-14 13:53:38 --> URI Class Initialized
INFO - 2018-08-14 13:53:38 --> Router Class Initialized
INFO - 2018-08-14 13:53:38 --> Output Class Initialized
INFO - 2018-08-14 13:53:38 --> Security Class Initialized
DEBUG - 2018-08-14 13:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:53:38 --> Input Class Initialized
INFO - 2018-08-14 13:53:38 --> Language Class Initialized
ERROR - 2018-08-14 13:53:38 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:53:38 --> Config Class Initialized
INFO - 2018-08-14 13:53:38 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:53:38 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:53:38 --> Utf8 Class Initialized
INFO - 2018-08-14 13:53:38 --> URI Class Initialized
INFO - 2018-08-14 13:53:38 --> Router Class Initialized
INFO - 2018-08-14 13:53:38 --> Output Class Initialized
INFO - 2018-08-14 13:53:38 --> Security Class Initialized
DEBUG - 2018-08-14 13:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:53:38 --> Input Class Initialized
INFO - 2018-08-14 13:53:38 --> Language Class Initialized
INFO - 2018-08-14 13:53:38 --> Language Class Initialized
INFO - 2018-08-14 13:53:38 --> Config Class Initialized
INFO - 2018-08-14 13:53:39 --> Loader Class Initialized
INFO - 2018-08-14 13:53:39 --> Helper loaded: url_helper
INFO - 2018-08-14 13:53:39 --> Helper loaded: file_helper
INFO - 2018-08-14 13:53:39 --> Helper loaded: form_helper
INFO - 2018-08-14 13:53:39 --> Helper loaded: my_helper
INFO - 2018-08-14 13:53:39 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:53:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:53:39 --> Controller Class Initialized
INFO - 2018-08-14 13:53:43 --> Config Class Initialized
INFO - 2018-08-14 13:53:43 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:53:43 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:53:43 --> Utf8 Class Initialized
INFO - 2018-08-14 13:53:43 --> URI Class Initialized
INFO - 2018-08-14 13:53:43 --> Router Class Initialized
INFO - 2018-08-14 13:53:43 --> Output Class Initialized
INFO - 2018-08-14 13:53:43 --> Security Class Initialized
DEBUG - 2018-08-14 13:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:53:43 --> Input Class Initialized
INFO - 2018-08-14 13:53:43 --> Language Class Initialized
INFO - 2018-08-14 13:53:43 --> Language Class Initialized
INFO - 2018-08-14 13:53:43 --> Config Class Initialized
INFO - 2018-08-14 13:53:43 --> Loader Class Initialized
INFO - 2018-08-14 13:53:43 --> Helper loaded: url_helper
INFO - 2018-08-14 13:53:43 --> Helper loaded: file_helper
INFO - 2018-08-14 13:53:43 --> Helper loaded: form_helper
INFO - 2018-08-14 13:53:43 --> Helper loaded: my_helper
INFO - 2018-08-14 13:53:43 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:53:43 --> Controller Class Initialized
DEBUG - 2018-08-14 13:53:43 --> File loaded: D:\laragon\www\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2018-08-14 13:53:43 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:53:43 --> Final output sent to browser
DEBUG - 2018-08-14 13:53:43 --> Total execution time: 0.4876
INFO - 2018-08-14 13:53:43 --> Config Class Initialized
INFO - 2018-08-14 13:53:43 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:53:43 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:53:43 --> Utf8 Class Initialized
INFO - 2018-08-14 13:53:43 --> URI Class Initialized
INFO - 2018-08-14 13:53:43 --> Router Class Initialized
INFO - 2018-08-14 13:53:43 --> Output Class Initialized
INFO - 2018-08-14 13:53:43 --> Security Class Initialized
DEBUG - 2018-08-14 13:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:53:43 --> Input Class Initialized
INFO - 2018-08-14 13:53:44 --> Language Class Initialized
ERROR - 2018-08-14 13:53:44 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:53:44 --> Config Class Initialized
INFO - 2018-08-14 13:53:44 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:53:44 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:53:44 --> Utf8 Class Initialized
INFO - 2018-08-14 13:53:44 --> URI Class Initialized
INFO - 2018-08-14 13:53:44 --> Router Class Initialized
INFO - 2018-08-14 13:53:44 --> Output Class Initialized
INFO - 2018-08-14 13:53:44 --> Security Class Initialized
DEBUG - 2018-08-14 13:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:53:44 --> Input Class Initialized
INFO - 2018-08-14 13:53:44 --> Language Class Initialized
INFO - 2018-08-14 13:53:44 --> Language Class Initialized
INFO - 2018-08-14 13:53:44 --> Config Class Initialized
INFO - 2018-08-14 13:53:44 --> Loader Class Initialized
INFO - 2018-08-14 13:53:44 --> Helper loaded: url_helper
INFO - 2018-08-14 13:53:44 --> Helper loaded: file_helper
INFO - 2018-08-14 13:53:44 --> Helper loaded: form_helper
INFO - 2018-08-14 13:53:44 --> Helper loaded: my_helper
INFO - 2018-08-14 13:53:44 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:53:44 --> Controller Class Initialized
INFO - 2018-08-14 13:53:44 --> Config Class Initialized
INFO - 2018-08-14 13:53:44 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:53:44 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:53:44 --> Utf8 Class Initialized
INFO - 2018-08-14 13:53:44 --> URI Class Initialized
INFO - 2018-08-14 13:53:44 --> Router Class Initialized
INFO - 2018-08-14 13:53:44 --> Output Class Initialized
INFO - 2018-08-14 13:53:44 --> Security Class Initialized
DEBUG - 2018-08-14 13:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:53:44 --> Input Class Initialized
INFO - 2018-08-14 13:53:44 --> Language Class Initialized
INFO - 2018-08-14 13:53:44 --> Language Class Initialized
INFO - 2018-08-14 13:53:44 --> Config Class Initialized
INFO - 2018-08-14 13:53:44 --> Loader Class Initialized
INFO - 2018-08-14 13:53:44 --> Helper loaded: url_helper
INFO - 2018-08-14 13:53:44 --> Helper loaded: file_helper
INFO - 2018-08-14 13:53:44 --> Helper loaded: form_helper
INFO - 2018-08-14 13:53:44 --> Helper loaded: my_helper
INFO - 2018-08-14 13:53:44 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:53:44 --> Controller Class Initialized
DEBUG - 2018-08-14 13:53:45 --> File loaded: D:\laragon\www\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2018-08-14 13:53:45 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:53:45 --> Final output sent to browser
DEBUG - 2018-08-14 13:53:45 --> Total execution time: 0.6628
INFO - 2018-08-14 13:53:45 --> Config Class Initialized
INFO - 2018-08-14 13:53:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:53:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:53:45 --> Utf8 Class Initialized
INFO - 2018-08-14 13:53:45 --> URI Class Initialized
INFO - 2018-08-14 13:53:45 --> Router Class Initialized
INFO - 2018-08-14 13:53:45 --> Output Class Initialized
INFO - 2018-08-14 13:53:45 --> Security Class Initialized
DEBUG - 2018-08-14 13:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:53:45 --> Input Class Initialized
INFO - 2018-08-14 13:53:45 --> Language Class Initialized
ERROR - 2018-08-14 13:53:45 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:53:45 --> Config Class Initialized
INFO - 2018-08-14 13:53:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:53:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:53:45 --> Utf8 Class Initialized
INFO - 2018-08-14 13:53:45 --> URI Class Initialized
INFO - 2018-08-14 13:53:45 --> Router Class Initialized
INFO - 2018-08-14 13:53:45 --> Output Class Initialized
INFO - 2018-08-14 13:53:45 --> Security Class Initialized
DEBUG - 2018-08-14 13:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:53:45 --> Input Class Initialized
INFO - 2018-08-14 13:53:45 --> Language Class Initialized
INFO - 2018-08-14 13:53:45 --> Language Class Initialized
INFO - 2018-08-14 13:53:45 --> Config Class Initialized
INFO - 2018-08-14 13:53:45 --> Loader Class Initialized
INFO - 2018-08-14 13:53:45 --> Helper loaded: url_helper
INFO - 2018-08-14 13:53:45 --> Helper loaded: file_helper
INFO - 2018-08-14 13:53:45 --> Helper loaded: form_helper
INFO - 2018-08-14 13:53:45 --> Helper loaded: my_helper
INFO - 2018-08-14 13:53:45 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:53:45 --> Controller Class Initialized
INFO - 2018-08-14 13:54:15 --> Config Class Initialized
INFO - 2018-08-14 13:54:15 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:54:15 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:54:15 --> Utf8 Class Initialized
INFO - 2018-08-14 13:54:15 --> URI Class Initialized
INFO - 2018-08-14 13:54:15 --> Router Class Initialized
INFO - 2018-08-14 13:54:15 --> Output Class Initialized
INFO - 2018-08-14 13:54:15 --> Security Class Initialized
DEBUG - 2018-08-14 13:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:54:15 --> Input Class Initialized
INFO - 2018-08-14 13:54:15 --> Language Class Initialized
INFO - 2018-08-14 13:54:15 --> Language Class Initialized
INFO - 2018-08-14 13:54:16 --> Config Class Initialized
INFO - 2018-08-14 13:54:16 --> Loader Class Initialized
INFO - 2018-08-14 13:54:16 --> Helper loaded: url_helper
INFO - 2018-08-14 13:54:16 --> Helper loaded: file_helper
INFO - 2018-08-14 13:54:16 --> Helper loaded: form_helper
INFO - 2018-08-14 13:54:16 --> Helper loaded: my_helper
INFO - 2018-08-14 13:54:16 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:54:16 --> Controller Class Initialized
DEBUG - 2018-08-14 13:54:16 --> File loaded: D:\laragon\www\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2018-08-14 13:54:16 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:54:16 --> Final output sent to browser
DEBUG - 2018-08-14 13:54:16 --> Total execution time: 0.5027
INFO - 2018-08-14 13:54:16 --> Config Class Initialized
INFO - 2018-08-14 13:54:16 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:54:16 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:54:16 --> Utf8 Class Initialized
INFO - 2018-08-14 13:54:16 --> URI Class Initialized
INFO - 2018-08-14 13:54:16 --> Router Class Initialized
INFO - 2018-08-14 13:54:16 --> Output Class Initialized
INFO - 2018-08-14 13:54:16 --> Security Class Initialized
DEBUG - 2018-08-14 13:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:54:16 --> Input Class Initialized
INFO - 2018-08-14 13:54:16 --> Language Class Initialized
ERROR - 2018-08-14 13:54:16 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:54:16 --> Config Class Initialized
INFO - 2018-08-14 13:54:16 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:54:16 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:54:16 --> Utf8 Class Initialized
INFO - 2018-08-14 13:54:16 --> URI Class Initialized
INFO - 2018-08-14 13:54:16 --> Router Class Initialized
INFO - 2018-08-14 13:54:16 --> Output Class Initialized
INFO - 2018-08-14 13:54:16 --> Security Class Initialized
DEBUG - 2018-08-14 13:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:54:16 --> Input Class Initialized
INFO - 2018-08-14 13:54:16 --> Language Class Initialized
INFO - 2018-08-14 13:54:16 --> Language Class Initialized
INFO - 2018-08-14 13:54:16 --> Config Class Initialized
INFO - 2018-08-14 13:54:16 --> Loader Class Initialized
INFO - 2018-08-14 13:54:17 --> Helper loaded: url_helper
INFO - 2018-08-14 13:54:17 --> Helper loaded: file_helper
INFO - 2018-08-14 13:54:17 --> Helper loaded: form_helper
INFO - 2018-08-14 13:54:17 --> Helper loaded: my_helper
INFO - 2018-08-14 13:54:17 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:54:17 --> Controller Class Initialized
INFO - 2018-08-14 13:54:21 --> Config Class Initialized
INFO - 2018-08-14 13:54:21 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:54:21 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:54:21 --> Utf8 Class Initialized
INFO - 2018-08-14 13:54:21 --> URI Class Initialized
INFO - 2018-08-14 13:54:21 --> Router Class Initialized
INFO - 2018-08-14 13:54:21 --> Output Class Initialized
INFO - 2018-08-14 13:54:21 --> Security Class Initialized
DEBUG - 2018-08-14 13:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:54:21 --> Input Class Initialized
INFO - 2018-08-14 13:54:21 --> Language Class Initialized
INFO - 2018-08-14 13:54:21 --> Language Class Initialized
INFO - 2018-08-14 13:54:21 --> Config Class Initialized
INFO - 2018-08-14 13:54:21 --> Loader Class Initialized
INFO - 2018-08-14 13:54:21 --> Helper loaded: url_helper
INFO - 2018-08-14 13:54:21 --> Helper loaded: file_helper
INFO - 2018-08-14 13:54:21 --> Helper loaded: form_helper
INFO - 2018-08-14 13:54:21 --> Helper loaded: my_helper
INFO - 2018-08-14 13:54:21 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:54:21 --> Controller Class Initialized
DEBUG - 2018-08-14 13:54:21 --> File loaded: D:\laragon\www\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2018-08-14 13:54:21 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:54:21 --> Final output sent to browser
DEBUG - 2018-08-14 13:54:21 --> Total execution time: 0.5707
INFO - 2018-08-14 13:54:22 --> Config Class Initialized
INFO - 2018-08-14 13:54:22 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:54:22 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:54:22 --> Utf8 Class Initialized
INFO - 2018-08-14 13:54:22 --> URI Class Initialized
INFO - 2018-08-14 13:54:22 --> Router Class Initialized
INFO - 2018-08-14 13:54:22 --> Output Class Initialized
INFO - 2018-08-14 13:54:22 --> Security Class Initialized
DEBUG - 2018-08-14 13:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:54:22 --> Input Class Initialized
INFO - 2018-08-14 13:54:22 --> Language Class Initialized
ERROR - 2018-08-14 13:54:22 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:54:22 --> Config Class Initialized
INFO - 2018-08-14 13:54:22 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:54:22 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:54:22 --> Utf8 Class Initialized
INFO - 2018-08-14 13:54:22 --> URI Class Initialized
INFO - 2018-08-14 13:54:22 --> Router Class Initialized
INFO - 2018-08-14 13:54:22 --> Output Class Initialized
INFO - 2018-08-14 13:54:22 --> Security Class Initialized
DEBUG - 2018-08-14 13:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:54:22 --> Input Class Initialized
INFO - 2018-08-14 13:54:22 --> Language Class Initialized
INFO - 2018-08-14 13:54:22 --> Language Class Initialized
INFO - 2018-08-14 13:54:22 --> Config Class Initialized
INFO - 2018-08-14 13:54:22 --> Loader Class Initialized
INFO - 2018-08-14 13:54:22 --> Helper loaded: url_helper
INFO - 2018-08-14 13:54:22 --> Helper loaded: file_helper
INFO - 2018-08-14 13:54:22 --> Helper loaded: form_helper
INFO - 2018-08-14 13:54:22 --> Helper loaded: my_helper
INFO - 2018-08-14 13:54:22 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:54:22 --> Controller Class Initialized
INFO - 2018-08-14 13:54:52 --> Config Class Initialized
INFO - 2018-08-14 13:54:52 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:54:52 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:54:52 --> Utf8 Class Initialized
INFO - 2018-08-14 13:54:52 --> URI Class Initialized
INFO - 2018-08-14 13:54:52 --> Router Class Initialized
INFO - 2018-08-14 13:54:52 --> Output Class Initialized
INFO - 2018-08-14 13:54:52 --> Security Class Initialized
DEBUG - 2018-08-14 13:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:54:52 --> Input Class Initialized
INFO - 2018-08-14 13:54:52 --> Language Class Initialized
INFO - 2018-08-14 13:54:52 --> Language Class Initialized
INFO - 2018-08-14 13:54:52 --> Config Class Initialized
INFO - 2018-08-14 13:54:52 --> Loader Class Initialized
INFO - 2018-08-14 13:54:52 --> Helper loaded: url_helper
INFO - 2018-08-14 13:54:52 --> Helper loaded: file_helper
INFO - 2018-08-14 13:54:52 --> Helper loaded: form_helper
INFO - 2018-08-14 13:54:52 --> Helper loaded: my_helper
INFO - 2018-08-14 13:54:52 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:54:52 --> Controller Class Initialized
DEBUG - 2018-08-14 13:54:52 --> File loaded: D:\laragon\www\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2018-08-14 13:54:52 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:54:52 --> Final output sent to browser
DEBUG - 2018-08-14 13:54:52 --> Total execution time: 0.4378
INFO - 2018-08-14 13:54:52 --> Config Class Initialized
INFO - 2018-08-14 13:54:52 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:54:52 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:54:52 --> Utf8 Class Initialized
INFO - 2018-08-14 13:54:52 --> URI Class Initialized
INFO - 2018-08-14 13:54:52 --> Router Class Initialized
INFO - 2018-08-14 13:54:53 --> Output Class Initialized
INFO - 2018-08-14 13:54:53 --> Security Class Initialized
DEBUG - 2018-08-14 13:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:54:53 --> Input Class Initialized
INFO - 2018-08-14 13:54:53 --> Language Class Initialized
ERROR - 2018-08-14 13:54:53 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:54:53 --> Config Class Initialized
INFO - 2018-08-14 13:54:53 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:54:53 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:54:53 --> Utf8 Class Initialized
INFO - 2018-08-14 13:54:53 --> URI Class Initialized
INFO - 2018-08-14 13:54:53 --> Router Class Initialized
INFO - 2018-08-14 13:54:53 --> Output Class Initialized
INFO - 2018-08-14 13:54:53 --> Security Class Initialized
DEBUG - 2018-08-14 13:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:54:53 --> Input Class Initialized
INFO - 2018-08-14 13:54:53 --> Language Class Initialized
INFO - 2018-08-14 13:54:53 --> Language Class Initialized
INFO - 2018-08-14 13:54:53 --> Config Class Initialized
INFO - 2018-08-14 13:54:53 --> Loader Class Initialized
INFO - 2018-08-14 13:54:53 --> Helper loaded: url_helper
INFO - 2018-08-14 13:54:53 --> Helper loaded: file_helper
INFO - 2018-08-14 13:54:53 --> Helper loaded: form_helper
INFO - 2018-08-14 13:54:53 --> Helper loaded: my_helper
INFO - 2018-08-14 13:54:53 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:54:53 --> Controller Class Initialized
INFO - 2018-08-14 13:54:56 --> Config Class Initialized
INFO - 2018-08-14 13:54:56 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:54:56 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:54:56 --> Utf8 Class Initialized
INFO - 2018-08-14 13:54:56 --> URI Class Initialized
INFO - 2018-08-14 13:54:56 --> Router Class Initialized
INFO - 2018-08-14 13:54:56 --> Output Class Initialized
INFO - 2018-08-14 13:54:56 --> Security Class Initialized
DEBUG - 2018-08-14 13:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:54:56 --> Input Class Initialized
INFO - 2018-08-14 13:54:56 --> Language Class Initialized
INFO - 2018-08-14 13:54:56 --> Language Class Initialized
INFO - 2018-08-14 13:54:56 --> Config Class Initialized
INFO - 2018-08-14 13:54:56 --> Loader Class Initialized
INFO - 2018-08-14 13:54:56 --> Helper loaded: url_helper
INFO - 2018-08-14 13:54:56 --> Helper loaded: file_helper
INFO - 2018-08-14 13:54:56 --> Helper loaded: form_helper
INFO - 2018-08-14 13:54:56 --> Helper loaded: my_helper
INFO - 2018-08-14 13:54:56 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:54:56 --> Controller Class Initialized
DEBUG - 2018-08-14 13:54:56 --> File loaded: D:\laragon\www\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2018-08-14 13:54:56 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:54:56 --> Final output sent to browser
DEBUG - 2018-08-14 13:54:56 --> Total execution time: 0.4168
INFO - 2018-08-14 13:54:56 --> Config Class Initialized
INFO - 2018-08-14 13:54:56 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:54:56 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:54:56 --> Utf8 Class Initialized
INFO - 2018-08-14 13:54:56 --> URI Class Initialized
INFO - 2018-08-14 13:54:56 --> Router Class Initialized
INFO - 2018-08-14 13:54:56 --> Output Class Initialized
INFO - 2018-08-14 13:54:56 --> Security Class Initialized
DEBUG - 2018-08-14 13:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:54:56 --> Input Class Initialized
INFO - 2018-08-14 13:54:56 --> Language Class Initialized
ERROR - 2018-08-14 13:54:56 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:54:57 --> Config Class Initialized
INFO - 2018-08-14 13:54:57 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:54:57 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:54:57 --> Utf8 Class Initialized
INFO - 2018-08-14 13:54:57 --> URI Class Initialized
INFO - 2018-08-14 13:54:57 --> Router Class Initialized
INFO - 2018-08-14 13:54:57 --> Output Class Initialized
INFO - 2018-08-14 13:54:57 --> Security Class Initialized
DEBUG - 2018-08-14 13:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:54:57 --> Input Class Initialized
INFO - 2018-08-14 13:54:57 --> Language Class Initialized
INFO - 2018-08-14 13:54:57 --> Language Class Initialized
INFO - 2018-08-14 13:54:57 --> Config Class Initialized
INFO - 2018-08-14 13:54:57 --> Loader Class Initialized
INFO - 2018-08-14 13:54:57 --> Helper loaded: url_helper
INFO - 2018-08-14 13:54:57 --> Helper loaded: file_helper
INFO - 2018-08-14 13:54:57 --> Helper loaded: form_helper
INFO - 2018-08-14 13:54:57 --> Helper loaded: my_helper
INFO - 2018-08-14 13:54:57 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:54:57 --> Controller Class Initialized
DEBUG - 2018-08-14 13:54:57 --> File loaded: D:\laragon\www\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2018-08-14 13:54:57 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:54:57 --> Final output sent to browser
DEBUG - 2018-08-14 13:54:57 --> Total execution time: 0.4160
INFO - 2018-08-14 13:54:57 --> Config Class Initialized
INFO - 2018-08-14 13:54:57 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:54:57 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:54:57 --> Utf8 Class Initialized
INFO - 2018-08-14 13:54:57 --> URI Class Initialized
INFO - 2018-08-14 13:54:57 --> Router Class Initialized
INFO - 2018-08-14 13:54:57 --> Output Class Initialized
INFO - 2018-08-14 13:54:57 --> Security Class Initialized
DEBUG - 2018-08-14 13:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:54:57 --> Input Class Initialized
INFO - 2018-08-14 13:54:57 --> Language Class Initialized
INFO - 2018-08-14 13:54:57 --> Language Class Initialized
INFO - 2018-08-14 13:54:57 --> Config Class Initialized
INFO - 2018-08-14 13:54:57 --> Loader Class Initialized
INFO - 2018-08-14 13:54:57 --> Helper loaded: url_helper
INFO - 2018-08-14 13:54:57 --> Helper loaded: file_helper
INFO - 2018-08-14 13:54:57 --> Helper loaded: form_helper
INFO - 2018-08-14 13:54:57 --> Helper loaded: my_helper
INFO - 2018-08-14 13:54:57 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:54:57 --> Controller Class Initialized
INFO - 2018-08-14 13:54:57 --> Config Class Initialized
INFO - 2018-08-14 13:54:57 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:54:57 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:54:57 --> Utf8 Class Initialized
INFO - 2018-08-14 13:54:57 --> URI Class Initialized
INFO - 2018-08-14 13:54:57 --> Router Class Initialized
INFO - 2018-08-14 13:54:58 --> Output Class Initialized
INFO - 2018-08-14 13:54:58 --> Security Class Initialized
DEBUG - 2018-08-14 13:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:54:58 --> Input Class Initialized
INFO - 2018-08-14 13:54:58 --> Language Class Initialized
ERROR - 2018-08-14 13:54:58 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:54:58 --> Config Class Initialized
INFO - 2018-08-14 13:54:58 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:54:58 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:54:58 --> Utf8 Class Initialized
INFO - 2018-08-14 13:54:58 --> URI Class Initialized
INFO - 2018-08-14 13:54:58 --> Router Class Initialized
INFO - 2018-08-14 13:54:58 --> Output Class Initialized
INFO - 2018-08-14 13:54:58 --> Security Class Initialized
DEBUG - 2018-08-14 13:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:54:58 --> Input Class Initialized
INFO - 2018-08-14 13:54:58 --> Language Class Initialized
INFO - 2018-08-14 13:54:58 --> Language Class Initialized
INFO - 2018-08-14 13:54:58 --> Config Class Initialized
INFO - 2018-08-14 13:54:58 --> Loader Class Initialized
INFO - 2018-08-14 13:54:58 --> Helper loaded: url_helper
INFO - 2018-08-14 13:54:58 --> Helper loaded: file_helper
INFO - 2018-08-14 13:54:58 --> Helper loaded: form_helper
INFO - 2018-08-14 13:54:58 --> Helper loaded: my_helper
INFO - 2018-08-14 13:54:58 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:54:58 --> Controller Class Initialized
INFO - 2018-08-14 13:55:00 --> Config Class Initialized
INFO - 2018-08-14 13:55:00 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:55:00 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:55:00 --> Utf8 Class Initialized
INFO - 2018-08-14 13:55:00 --> URI Class Initialized
INFO - 2018-08-14 13:55:00 --> Router Class Initialized
INFO - 2018-08-14 13:55:00 --> Output Class Initialized
INFO - 2018-08-14 13:55:00 --> Security Class Initialized
DEBUG - 2018-08-14 13:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:55:00 --> Input Class Initialized
INFO - 2018-08-14 13:55:00 --> Language Class Initialized
INFO - 2018-08-14 13:55:00 --> Language Class Initialized
INFO - 2018-08-14 13:55:00 --> Config Class Initialized
INFO - 2018-08-14 13:55:00 --> Loader Class Initialized
INFO - 2018-08-14 13:55:00 --> Helper loaded: url_helper
INFO - 2018-08-14 13:55:00 --> Helper loaded: file_helper
INFO - 2018-08-14 13:55:00 --> Helper loaded: form_helper
INFO - 2018-08-14 13:55:00 --> Helper loaded: my_helper
INFO - 2018-08-14 13:55:00 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:55:00 --> Controller Class Initialized
DEBUG - 2018-08-14 13:55:00 --> File loaded: D:\laragon\www\nilai\application\modules/tahun/views/list.php
DEBUG - 2018-08-14 13:55:00 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:55:00 --> Final output sent to browser
DEBUG - 2018-08-14 13:55:01 --> Total execution time: 0.6128
INFO - 2018-08-14 13:55:01 --> Config Class Initialized
INFO - 2018-08-14 13:55:01 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:55:01 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:55:01 --> Utf8 Class Initialized
INFO - 2018-08-14 13:55:01 --> URI Class Initialized
INFO - 2018-08-14 13:55:01 --> Router Class Initialized
INFO - 2018-08-14 13:55:01 --> Output Class Initialized
INFO - 2018-08-14 13:55:01 --> Security Class Initialized
DEBUG - 2018-08-14 13:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:55:01 --> Input Class Initialized
INFO - 2018-08-14 13:55:01 --> Language Class Initialized
ERROR - 2018-08-14 13:55:01 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:55:01 --> Config Class Initialized
INFO - 2018-08-14 13:55:01 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:55:01 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:55:01 --> Utf8 Class Initialized
INFO - 2018-08-14 13:55:01 --> URI Class Initialized
INFO - 2018-08-14 13:55:01 --> Router Class Initialized
INFO - 2018-08-14 13:55:01 --> Output Class Initialized
INFO - 2018-08-14 13:55:01 --> Security Class Initialized
DEBUG - 2018-08-14 13:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:55:01 --> Input Class Initialized
INFO - 2018-08-14 13:55:01 --> Language Class Initialized
INFO - 2018-08-14 13:55:01 --> Language Class Initialized
INFO - 2018-08-14 13:55:01 --> Config Class Initialized
INFO - 2018-08-14 13:55:01 --> Loader Class Initialized
INFO - 2018-08-14 13:55:01 --> Helper loaded: url_helper
INFO - 2018-08-14 13:55:01 --> Helper loaded: file_helper
INFO - 2018-08-14 13:55:01 --> Helper loaded: form_helper
INFO - 2018-08-14 13:55:01 --> Helper loaded: my_helper
INFO - 2018-08-14 13:55:01 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:55:01 --> Controller Class Initialized
INFO - 2018-08-14 13:55:04 --> Config Class Initialized
INFO - 2018-08-14 13:55:04 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:55:04 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:55:04 --> Utf8 Class Initialized
INFO - 2018-08-14 13:55:04 --> URI Class Initialized
INFO - 2018-08-14 13:55:04 --> Router Class Initialized
INFO - 2018-08-14 13:55:04 --> Output Class Initialized
INFO - 2018-08-14 13:55:04 --> Security Class Initialized
DEBUG - 2018-08-14 13:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:55:04 --> Input Class Initialized
INFO - 2018-08-14 13:55:04 --> Language Class Initialized
INFO - 2018-08-14 13:55:04 --> Language Class Initialized
INFO - 2018-08-14 13:55:04 --> Config Class Initialized
INFO - 2018-08-14 13:55:04 --> Loader Class Initialized
INFO - 2018-08-14 13:55:04 --> Helper loaded: url_helper
INFO - 2018-08-14 13:55:04 --> Helper loaded: file_helper
INFO - 2018-08-14 13:55:04 --> Helper loaded: form_helper
INFO - 2018-08-14 13:55:04 --> Helper loaded: my_helper
INFO - 2018-08-14 13:55:04 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:55:05 --> Controller Class Initialized
INFO - 2018-08-14 13:55:05 --> Final output sent to browser
DEBUG - 2018-08-14 13:55:05 --> Total execution time: 0.3994
INFO - 2018-08-14 13:55:36 --> Config Class Initialized
INFO - 2018-08-14 13:55:36 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:55:36 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:55:36 --> Utf8 Class Initialized
INFO - 2018-08-14 13:55:36 --> URI Class Initialized
INFO - 2018-08-14 13:55:36 --> Router Class Initialized
INFO - 2018-08-14 13:55:36 --> Output Class Initialized
INFO - 2018-08-14 13:55:36 --> Security Class Initialized
DEBUG - 2018-08-14 13:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:55:36 --> Input Class Initialized
INFO - 2018-08-14 13:55:36 --> Language Class Initialized
INFO - 2018-08-14 13:55:36 --> Language Class Initialized
INFO - 2018-08-14 13:55:36 --> Config Class Initialized
INFO - 2018-08-14 13:55:36 --> Loader Class Initialized
INFO - 2018-08-14 13:55:36 --> Helper loaded: url_helper
INFO - 2018-08-14 13:55:36 --> Helper loaded: file_helper
INFO - 2018-08-14 13:55:36 --> Helper loaded: form_helper
INFO - 2018-08-14 13:55:36 --> Helper loaded: my_helper
INFO - 2018-08-14 13:55:36 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:55:36 --> Controller Class Initialized
INFO - 2018-08-14 13:55:36 --> Final output sent to browser
DEBUG - 2018-08-14 13:55:36 --> Total execution time: 0.4348
INFO - 2018-08-14 13:55:36 --> Config Class Initialized
INFO - 2018-08-14 13:55:36 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:55:36 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:55:36 --> Utf8 Class Initialized
INFO - 2018-08-14 13:55:36 --> URI Class Initialized
INFO - 2018-08-14 13:55:36 --> Router Class Initialized
INFO - 2018-08-14 13:55:36 --> Output Class Initialized
INFO - 2018-08-14 13:55:36 --> Security Class Initialized
DEBUG - 2018-08-14 13:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:55:37 --> Input Class Initialized
INFO - 2018-08-14 13:55:37 --> Language Class Initialized
INFO - 2018-08-14 13:55:37 --> Language Class Initialized
INFO - 2018-08-14 13:55:37 --> Config Class Initialized
INFO - 2018-08-14 13:55:37 --> Loader Class Initialized
INFO - 2018-08-14 13:55:37 --> Helper loaded: url_helper
INFO - 2018-08-14 13:55:37 --> Helper loaded: file_helper
INFO - 2018-08-14 13:55:37 --> Helper loaded: form_helper
INFO - 2018-08-14 13:55:37 --> Helper loaded: my_helper
INFO - 2018-08-14 13:55:37 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:55:37 --> Controller Class Initialized
INFO - 2018-08-14 13:55:38 --> Config Class Initialized
INFO - 2018-08-14 13:55:39 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:55:39 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:55:39 --> Utf8 Class Initialized
INFO - 2018-08-14 13:55:39 --> URI Class Initialized
INFO - 2018-08-14 13:55:39 --> Router Class Initialized
INFO - 2018-08-14 13:55:39 --> Output Class Initialized
INFO - 2018-08-14 13:55:39 --> Security Class Initialized
DEBUG - 2018-08-14 13:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:55:39 --> Input Class Initialized
INFO - 2018-08-14 13:55:39 --> Language Class Initialized
INFO - 2018-08-14 13:55:39 --> Language Class Initialized
INFO - 2018-08-14 13:55:39 --> Config Class Initialized
INFO - 2018-08-14 13:55:39 --> Loader Class Initialized
INFO - 2018-08-14 13:55:39 --> Helper loaded: url_helper
INFO - 2018-08-14 13:55:39 --> Helper loaded: file_helper
INFO - 2018-08-14 13:55:39 --> Helper loaded: form_helper
INFO - 2018-08-14 13:55:39 --> Helper loaded: my_helper
INFO - 2018-08-14 13:55:39 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:55:39 --> Controller Class Initialized
INFO - 2018-08-14 13:55:39 --> Final output sent to browser
DEBUG - 2018-08-14 13:55:39 --> Total execution time: 0.4983
INFO - 2018-08-14 13:55:39 --> Config Class Initialized
INFO - 2018-08-14 13:55:39 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:55:39 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:55:39 --> Utf8 Class Initialized
INFO - 2018-08-14 13:55:39 --> URI Class Initialized
INFO - 2018-08-14 13:55:39 --> Router Class Initialized
INFO - 2018-08-14 13:55:39 --> Output Class Initialized
INFO - 2018-08-14 13:55:39 --> Security Class Initialized
DEBUG - 2018-08-14 13:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:55:39 --> Input Class Initialized
INFO - 2018-08-14 13:55:39 --> Language Class Initialized
INFO - 2018-08-14 13:55:39 --> Language Class Initialized
INFO - 2018-08-14 13:55:39 --> Config Class Initialized
INFO - 2018-08-14 13:55:39 --> Loader Class Initialized
INFO - 2018-08-14 13:55:39 --> Helper loaded: url_helper
INFO - 2018-08-14 13:55:39 --> Helper loaded: file_helper
INFO - 2018-08-14 13:55:39 --> Helper loaded: form_helper
INFO - 2018-08-14 13:55:39 --> Helper loaded: my_helper
INFO - 2018-08-14 13:55:39 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:55:40 --> Controller Class Initialized
INFO - 2018-08-14 13:55:44 --> Config Class Initialized
INFO - 2018-08-14 13:55:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:55:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:55:45 --> Utf8 Class Initialized
INFO - 2018-08-14 13:55:45 --> URI Class Initialized
INFO - 2018-08-14 13:55:45 --> Router Class Initialized
INFO - 2018-08-14 13:55:45 --> Output Class Initialized
INFO - 2018-08-14 13:55:45 --> Security Class Initialized
DEBUG - 2018-08-14 13:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:55:45 --> Input Class Initialized
INFO - 2018-08-14 13:55:45 --> Language Class Initialized
INFO - 2018-08-14 13:55:45 --> Language Class Initialized
INFO - 2018-08-14 13:55:45 --> Config Class Initialized
INFO - 2018-08-14 13:55:45 --> Loader Class Initialized
INFO - 2018-08-14 13:55:45 --> Helper loaded: url_helper
INFO - 2018-08-14 13:55:45 --> Helper loaded: file_helper
INFO - 2018-08-14 13:55:45 --> Helper loaded: form_helper
INFO - 2018-08-14 13:55:45 --> Helper loaded: my_helper
INFO - 2018-08-14 13:55:45 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:55:45 --> Controller Class Initialized
DEBUG - 2018-08-14 13:55:45 --> File loaded: D:\laragon\www\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2018-08-14 13:55:45 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:55:45 --> Final output sent to browser
DEBUG - 2018-08-14 13:55:45 --> Total execution time: 0.4430
INFO - 2018-08-14 13:55:45 --> Config Class Initialized
INFO - 2018-08-14 13:55:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:55:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:55:45 --> Utf8 Class Initialized
INFO - 2018-08-14 13:55:45 --> URI Class Initialized
INFO - 2018-08-14 13:55:45 --> Router Class Initialized
INFO - 2018-08-14 13:55:45 --> Output Class Initialized
INFO - 2018-08-14 13:55:45 --> Security Class Initialized
DEBUG - 2018-08-14 13:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:55:45 --> Input Class Initialized
INFO - 2018-08-14 13:55:45 --> Language Class Initialized
ERROR - 2018-08-14 13:55:45 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:55:45 --> Config Class Initialized
INFO - 2018-08-14 13:55:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:55:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:55:45 --> Utf8 Class Initialized
INFO - 2018-08-14 13:55:45 --> URI Class Initialized
INFO - 2018-08-14 13:55:45 --> Router Class Initialized
INFO - 2018-08-14 13:55:45 --> Output Class Initialized
INFO - 2018-08-14 13:55:45 --> Security Class Initialized
DEBUG - 2018-08-14 13:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:55:46 --> Input Class Initialized
INFO - 2018-08-14 13:55:46 --> Language Class Initialized
INFO - 2018-08-14 13:55:46 --> Language Class Initialized
INFO - 2018-08-14 13:55:46 --> Config Class Initialized
INFO - 2018-08-14 13:55:46 --> Loader Class Initialized
INFO - 2018-08-14 13:55:46 --> Helper loaded: url_helper
INFO - 2018-08-14 13:55:46 --> Helper loaded: file_helper
INFO - 2018-08-14 13:55:46 --> Helper loaded: form_helper
INFO - 2018-08-14 13:55:46 --> Helper loaded: my_helper
INFO - 2018-08-14 13:55:46 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:55:46 --> Controller Class Initialized
INFO - 2018-08-14 13:55:50 --> Config Class Initialized
INFO - 2018-08-14 13:55:50 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:55:50 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:55:50 --> Utf8 Class Initialized
INFO - 2018-08-14 13:55:50 --> URI Class Initialized
INFO - 2018-08-14 13:55:50 --> Router Class Initialized
INFO - 2018-08-14 13:55:50 --> Output Class Initialized
INFO - 2018-08-14 13:55:50 --> Security Class Initialized
DEBUG - 2018-08-14 13:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:55:50 --> Input Class Initialized
INFO - 2018-08-14 13:55:50 --> Language Class Initialized
INFO - 2018-08-14 13:55:50 --> Language Class Initialized
INFO - 2018-08-14 13:55:50 --> Config Class Initialized
INFO - 2018-08-14 13:55:50 --> Loader Class Initialized
INFO - 2018-08-14 13:55:50 --> Helper loaded: url_helper
INFO - 2018-08-14 13:55:50 --> Helper loaded: file_helper
INFO - 2018-08-14 13:55:50 --> Helper loaded: form_helper
INFO - 2018-08-14 13:55:50 --> Helper loaded: my_helper
INFO - 2018-08-14 13:55:50 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:55:50 --> Controller Class Initialized
DEBUG - 2018-08-14 13:55:50 --> File loaded: D:\laragon\www\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2018-08-14 13:55:50 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:55:50 --> Final output sent to browser
DEBUG - 2018-08-14 13:55:50 --> Total execution time: 0.5263
INFO - 2018-08-14 13:55:50 --> Config Class Initialized
INFO - 2018-08-14 13:55:50 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:55:50 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:55:50 --> Utf8 Class Initialized
INFO - 2018-08-14 13:55:50 --> URI Class Initialized
INFO - 2018-08-14 13:55:50 --> Router Class Initialized
INFO - 2018-08-14 13:55:50 --> Output Class Initialized
INFO - 2018-08-14 13:55:50 --> Security Class Initialized
DEBUG - 2018-08-14 13:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:55:50 --> Input Class Initialized
INFO - 2018-08-14 13:55:51 --> Language Class Initialized
ERROR - 2018-08-14 13:55:51 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:55:51 --> Config Class Initialized
INFO - 2018-08-14 13:55:51 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:55:51 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:55:51 --> Utf8 Class Initialized
INFO - 2018-08-14 13:55:51 --> URI Class Initialized
INFO - 2018-08-14 13:55:51 --> Router Class Initialized
INFO - 2018-08-14 13:55:51 --> Output Class Initialized
INFO - 2018-08-14 13:55:51 --> Security Class Initialized
DEBUG - 2018-08-14 13:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:55:51 --> Input Class Initialized
INFO - 2018-08-14 13:55:51 --> Language Class Initialized
INFO - 2018-08-14 13:55:51 --> Language Class Initialized
INFO - 2018-08-14 13:55:51 --> Config Class Initialized
INFO - 2018-08-14 13:55:51 --> Loader Class Initialized
INFO - 2018-08-14 13:55:51 --> Helper loaded: url_helper
INFO - 2018-08-14 13:55:51 --> Helper loaded: file_helper
INFO - 2018-08-14 13:55:51 --> Helper loaded: form_helper
INFO - 2018-08-14 13:55:51 --> Helper loaded: my_helper
INFO - 2018-08-14 13:55:51 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:55:51 --> Controller Class Initialized
INFO - 2018-08-14 13:55:51 --> Config Class Initialized
INFO - 2018-08-14 13:55:51 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:55:51 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:55:51 --> Utf8 Class Initialized
INFO - 2018-08-14 13:55:51 --> URI Class Initialized
INFO - 2018-08-14 13:55:51 --> Router Class Initialized
INFO - 2018-08-14 13:55:51 --> Output Class Initialized
INFO - 2018-08-14 13:55:51 --> Security Class Initialized
DEBUG - 2018-08-14 13:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:55:51 --> Input Class Initialized
INFO - 2018-08-14 13:55:51 --> Language Class Initialized
INFO - 2018-08-14 13:55:51 --> Language Class Initialized
INFO - 2018-08-14 13:55:51 --> Config Class Initialized
INFO - 2018-08-14 13:55:51 --> Loader Class Initialized
INFO - 2018-08-14 13:55:51 --> Helper loaded: url_helper
INFO - 2018-08-14 13:55:51 --> Helper loaded: file_helper
INFO - 2018-08-14 13:55:51 --> Helper loaded: form_helper
INFO - 2018-08-14 13:55:51 --> Helper loaded: my_helper
INFO - 2018-08-14 13:55:51 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:55:52 --> Controller Class Initialized
DEBUG - 2018-08-14 13:55:52 --> File loaded: D:\laragon\www\nilai\application\modules/tahun/views/list.php
DEBUG - 2018-08-14 13:55:52 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:55:52 --> Final output sent to browser
DEBUG - 2018-08-14 13:55:52 --> Total execution time: 0.4937
INFO - 2018-08-14 13:55:52 --> Config Class Initialized
INFO - 2018-08-14 13:55:52 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:55:52 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:55:52 --> Utf8 Class Initialized
INFO - 2018-08-14 13:55:52 --> URI Class Initialized
INFO - 2018-08-14 13:55:52 --> Router Class Initialized
INFO - 2018-08-14 13:55:52 --> Output Class Initialized
INFO - 2018-08-14 13:55:52 --> Security Class Initialized
DEBUG - 2018-08-14 13:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:55:52 --> Input Class Initialized
INFO - 2018-08-14 13:55:52 --> Language Class Initialized
ERROR - 2018-08-14 13:55:52 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:55:52 --> Config Class Initialized
INFO - 2018-08-14 13:55:52 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:55:52 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:55:52 --> Utf8 Class Initialized
INFO - 2018-08-14 13:55:52 --> URI Class Initialized
INFO - 2018-08-14 13:55:52 --> Router Class Initialized
INFO - 2018-08-14 13:55:52 --> Output Class Initialized
INFO - 2018-08-14 13:55:52 --> Security Class Initialized
DEBUG - 2018-08-14 13:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:55:52 --> Input Class Initialized
INFO - 2018-08-14 13:55:52 --> Language Class Initialized
INFO - 2018-08-14 13:55:52 --> Language Class Initialized
INFO - 2018-08-14 13:55:52 --> Config Class Initialized
INFO - 2018-08-14 13:55:52 --> Loader Class Initialized
INFO - 2018-08-14 13:55:52 --> Helper loaded: url_helper
INFO - 2018-08-14 13:55:52 --> Helper loaded: file_helper
INFO - 2018-08-14 13:55:52 --> Helper loaded: form_helper
INFO - 2018-08-14 13:55:52 --> Helper loaded: my_helper
INFO - 2018-08-14 13:55:52 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:55:53 --> Controller Class Initialized
INFO - 2018-08-14 13:55:53 --> Config Class Initialized
INFO - 2018-08-14 13:55:53 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:55:53 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:55:53 --> Utf8 Class Initialized
INFO - 2018-08-14 13:55:53 --> URI Class Initialized
INFO - 2018-08-14 13:55:53 --> Router Class Initialized
INFO - 2018-08-14 13:55:53 --> Output Class Initialized
INFO - 2018-08-14 13:55:53 --> Security Class Initialized
DEBUG - 2018-08-14 13:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:55:53 --> Input Class Initialized
INFO - 2018-08-14 13:55:53 --> Language Class Initialized
INFO - 2018-08-14 13:55:53 --> Language Class Initialized
INFO - 2018-08-14 13:55:53 --> Config Class Initialized
INFO - 2018-08-14 13:55:53 --> Loader Class Initialized
INFO - 2018-08-14 13:55:53 --> Helper loaded: url_helper
INFO - 2018-08-14 13:55:53 --> Helper loaded: file_helper
INFO - 2018-08-14 13:55:54 --> Helper loaded: form_helper
INFO - 2018-08-14 13:55:54 --> Helper loaded: my_helper
INFO - 2018-08-14 13:55:54 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:55:54 --> Controller Class Initialized
DEBUG - 2018-08-14 13:55:54 --> File loaded: D:\laragon\www\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2018-08-14 13:55:54 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:55:54 --> Final output sent to browser
DEBUG - 2018-08-14 13:55:54 --> Total execution time: 0.5189
INFO - 2018-08-14 13:55:54 --> Config Class Initialized
INFO - 2018-08-14 13:55:54 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:55:54 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:55:54 --> Utf8 Class Initialized
INFO - 2018-08-14 13:55:54 --> URI Class Initialized
INFO - 2018-08-14 13:55:54 --> Router Class Initialized
INFO - 2018-08-14 13:55:54 --> Output Class Initialized
INFO - 2018-08-14 13:55:54 --> Security Class Initialized
DEBUG - 2018-08-14 13:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:55:54 --> Input Class Initialized
INFO - 2018-08-14 13:55:54 --> Language Class Initialized
ERROR - 2018-08-14 13:55:54 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:56:32 --> Config Class Initialized
INFO - 2018-08-14 13:56:32 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:56:32 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:56:32 --> Utf8 Class Initialized
INFO - 2018-08-14 13:56:32 --> URI Class Initialized
INFO - 2018-08-14 13:56:32 --> Router Class Initialized
INFO - 2018-08-14 13:56:32 --> Output Class Initialized
INFO - 2018-08-14 13:56:32 --> Security Class Initialized
DEBUG - 2018-08-14 13:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:56:33 --> Input Class Initialized
INFO - 2018-08-14 13:56:33 --> Language Class Initialized
INFO - 2018-08-14 13:56:33 --> Language Class Initialized
INFO - 2018-08-14 13:56:33 --> Config Class Initialized
INFO - 2018-08-14 13:56:33 --> Loader Class Initialized
INFO - 2018-08-14 13:56:33 --> Helper loaded: url_helper
INFO - 2018-08-14 13:56:33 --> Helper loaded: file_helper
INFO - 2018-08-14 13:56:33 --> Helper loaded: form_helper
INFO - 2018-08-14 13:56:33 --> Helper loaded: my_helper
INFO - 2018-08-14 13:56:33 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:56:33 --> Controller Class Initialized
DEBUG - 2018-08-14 13:56:33 --> File loaded: D:\laragon\www\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2018-08-14 13:56:33 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:56:33 --> Final output sent to browser
DEBUG - 2018-08-14 13:56:33 --> Total execution time: 0.7788
INFO - 2018-08-14 13:56:33 --> Config Class Initialized
INFO - 2018-08-14 13:56:33 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:56:33 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:56:33 --> Utf8 Class Initialized
INFO - 2018-08-14 13:56:33 --> URI Class Initialized
INFO - 2018-08-14 13:56:33 --> Router Class Initialized
INFO - 2018-08-14 13:56:33 --> Output Class Initialized
INFO - 2018-08-14 13:56:33 --> Security Class Initialized
DEBUG - 2018-08-14 13:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:56:33 --> Input Class Initialized
INFO - 2018-08-14 13:56:33 --> Language Class Initialized
ERROR - 2018-08-14 13:56:33 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:56:35 --> Config Class Initialized
INFO - 2018-08-14 13:56:35 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:56:35 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:56:35 --> Utf8 Class Initialized
INFO - 2018-08-14 13:56:35 --> URI Class Initialized
INFO - 2018-08-14 13:56:35 --> Router Class Initialized
INFO - 2018-08-14 13:56:35 --> Output Class Initialized
INFO - 2018-08-14 13:56:35 --> Security Class Initialized
DEBUG - 2018-08-14 13:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:56:35 --> Input Class Initialized
INFO - 2018-08-14 13:56:35 --> Language Class Initialized
INFO - 2018-08-14 13:56:35 --> Language Class Initialized
INFO - 2018-08-14 13:56:35 --> Config Class Initialized
INFO - 2018-08-14 13:56:35 --> Loader Class Initialized
INFO - 2018-08-14 13:56:35 --> Helper loaded: url_helper
INFO - 2018-08-14 13:56:35 --> Helper loaded: file_helper
INFO - 2018-08-14 13:56:35 --> Helper loaded: form_helper
INFO - 2018-08-14 13:56:35 --> Helper loaded: my_helper
INFO - 2018-08-14 13:56:35 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:56:35 --> Controller Class Initialized
DEBUG - 2018-08-14 13:56:35 --> File loaded: D:\laragon\www\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2018-08-14 13:56:35 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:56:35 --> Final output sent to browser
DEBUG - 2018-08-14 13:56:35 --> Total execution time: 0.6130
INFO - 2018-08-14 13:56:36 --> Config Class Initialized
INFO - 2018-08-14 13:56:36 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:56:36 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:56:36 --> Utf8 Class Initialized
INFO - 2018-08-14 13:56:36 --> URI Class Initialized
INFO - 2018-08-14 13:56:36 --> Router Class Initialized
INFO - 2018-08-14 13:56:36 --> Output Class Initialized
INFO - 2018-08-14 13:56:36 --> Security Class Initialized
DEBUG - 2018-08-14 13:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:56:36 --> Input Class Initialized
INFO - 2018-08-14 13:56:36 --> Language Class Initialized
ERROR - 2018-08-14 13:56:36 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:57:34 --> Config Class Initialized
INFO - 2018-08-14 13:57:34 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:57:34 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:57:34 --> Utf8 Class Initialized
INFO - 2018-08-14 13:57:34 --> URI Class Initialized
INFO - 2018-08-14 13:57:34 --> Router Class Initialized
INFO - 2018-08-14 13:57:34 --> Output Class Initialized
INFO - 2018-08-14 13:57:34 --> Security Class Initialized
DEBUG - 2018-08-14 13:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:57:34 --> Input Class Initialized
INFO - 2018-08-14 13:57:34 --> Language Class Initialized
INFO - 2018-08-14 13:57:34 --> Language Class Initialized
INFO - 2018-08-14 13:57:34 --> Config Class Initialized
INFO - 2018-08-14 13:57:34 --> Loader Class Initialized
INFO - 2018-08-14 13:57:34 --> Helper loaded: url_helper
INFO - 2018-08-14 13:57:35 --> Helper loaded: file_helper
INFO - 2018-08-14 13:57:35 --> Helper loaded: form_helper
INFO - 2018-08-14 13:57:35 --> Helper loaded: my_helper
INFO - 2018-08-14 13:57:35 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:57:35 --> Controller Class Initialized
DEBUG - 2018-08-14 13:57:35 --> File loaded: D:\laragon\www\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2018-08-14 13:57:35 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:57:35 --> Final output sent to browser
DEBUG - 2018-08-14 13:57:35 --> Total execution time: 0.8785
INFO - 2018-08-14 13:57:35 --> Config Class Initialized
INFO - 2018-08-14 13:57:35 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:57:35 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:57:35 --> Utf8 Class Initialized
INFO - 2018-08-14 13:57:35 --> URI Class Initialized
INFO - 2018-08-14 13:57:35 --> Router Class Initialized
INFO - 2018-08-14 13:57:35 --> Output Class Initialized
INFO - 2018-08-14 13:57:35 --> Security Class Initialized
DEBUG - 2018-08-14 13:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:57:35 --> Input Class Initialized
INFO - 2018-08-14 13:57:35 --> Language Class Initialized
ERROR - 2018-08-14 13:57:35 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:58:04 --> Config Class Initialized
INFO - 2018-08-14 13:58:05 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:05 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:05 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:05 --> URI Class Initialized
INFO - 2018-08-14 13:58:05 --> Router Class Initialized
INFO - 2018-08-14 13:58:05 --> Output Class Initialized
INFO - 2018-08-14 13:58:05 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:05 --> Input Class Initialized
INFO - 2018-08-14 13:58:05 --> Language Class Initialized
INFO - 2018-08-14 13:58:05 --> Language Class Initialized
INFO - 2018-08-14 13:58:05 --> Config Class Initialized
INFO - 2018-08-14 13:58:05 --> Loader Class Initialized
INFO - 2018-08-14 13:58:05 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:05 --> Helper loaded: file_helper
INFO - 2018-08-14 13:58:05 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:05 --> Helper loaded: my_helper
INFO - 2018-08-14 13:58:05 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:05 --> Controller Class Initialized
INFO - 2018-08-14 13:58:05 --> Config Class Initialized
INFO - 2018-08-14 13:58:05 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:05 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:05 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:05 --> URI Class Initialized
INFO - 2018-08-14 13:58:05 --> Router Class Initialized
INFO - 2018-08-14 13:58:05 --> Output Class Initialized
INFO - 2018-08-14 13:58:05 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:05 --> Input Class Initialized
INFO - 2018-08-14 13:58:05 --> Language Class Initialized
INFO - 2018-08-14 13:58:05 --> Language Class Initialized
INFO - 2018-08-14 13:58:05 --> Config Class Initialized
INFO - 2018-08-14 13:58:05 --> Loader Class Initialized
INFO - 2018-08-14 13:58:05 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:05 --> Helper loaded: file_helper
INFO - 2018-08-14 13:58:05 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:05 --> Helper loaded: my_helper
INFO - 2018-08-14 13:58:05 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:05 --> Controller Class Initialized
DEBUG - 2018-08-14 13:58:05 --> File loaded: D:\laragon\www\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2018-08-14 13:58:05 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:58:05 --> Final output sent to browser
DEBUG - 2018-08-14 13:58:05 --> Total execution time: 0.4548
INFO - 2018-08-14 13:58:06 --> Config Class Initialized
INFO - 2018-08-14 13:58:06 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:06 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:06 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:06 --> URI Class Initialized
INFO - 2018-08-14 13:58:06 --> Router Class Initialized
INFO - 2018-08-14 13:58:06 --> Output Class Initialized
INFO - 2018-08-14 13:58:06 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:06 --> Input Class Initialized
INFO - 2018-08-14 13:58:06 --> Language Class Initialized
ERROR - 2018-08-14 13:58:06 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:58:07 --> Config Class Initialized
INFO - 2018-08-14 13:58:07 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:07 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:07 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:07 --> URI Class Initialized
INFO - 2018-08-14 13:58:07 --> Router Class Initialized
INFO - 2018-08-14 13:58:07 --> Output Class Initialized
INFO - 2018-08-14 13:58:07 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:07 --> Input Class Initialized
INFO - 2018-08-14 13:58:07 --> Language Class Initialized
INFO - 2018-08-14 13:58:07 --> Language Class Initialized
INFO - 2018-08-14 13:58:07 --> Config Class Initialized
INFO - 2018-08-14 13:58:07 --> Loader Class Initialized
INFO - 2018-08-14 13:58:07 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:07 --> Helper loaded: file_helper
INFO - 2018-08-14 13:58:07 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:07 --> Helper loaded: my_helper
INFO - 2018-08-14 13:58:07 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:08 --> Controller Class Initialized
DEBUG - 2018-08-14 13:58:08 --> File loaded: D:\laragon\www\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2018-08-14 13:58:08 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:58:08 --> Final output sent to browser
DEBUG - 2018-08-14 13:58:08 --> Total execution time: 0.6837
INFO - 2018-08-14 13:58:08 --> Config Class Initialized
INFO - 2018-08-14 13:58:08 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:08 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:08 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:08 --> URI Class Initialized
INFO - 2018-08-14 13:58:08 --> Router Class Initialized
INFO - 2018-08-14 13:58:08 --> Output Class Initialized
INFO - 2018-08-14 13:58:08 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:08 --> Input Class Initialized
INFO - 2018-08-14 13:58:08 --> Language Class Initialized
ERROR - 2018-08-14 13:58:08 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:58:15 --> Config Class Initialized
INFO - 2018-08-14 13:58:15 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:15 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:15 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:15 --> URI Class Initialized
INFO - 2018-08-14 13:58:15 --> Router Class Initialized
INFO - 2018-08-14 13:58:15 --> Output Class Initialized
INFO - 2018-08-14 13:58:15 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:15 --> Input Class Initialized
INFO - 2018-08-14 13:58:15 --> Language Class Initialized
INFO - 2018-08-14 13:58:15 --> Language Class Initialized
INFO - 2018-08-14 13:58:15 --> Config Class Initialized
INFO - 2018-08-14 13:58:15 --> Loader Class Initialized
INFO - 2018-08-14 13:58:15 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:15 --> Helper loaded: file_helper
INFO - 2018-08-14 13:58:15 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:15 --> Helper loaded: my_helper
INFO - 2018-08-14 13:58:15 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:15 --> Controller Class Initialized
INFO - 2018-08-14 13:58:15 --> Config Class Initialized
INFO - 2018-08-14 13:58:15 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:15 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:15 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:15 --> URI Class Initialized
INFO - 2018-08-14 13:58:15 --> Router Class Initialized
INFO - 2018-08-14 13:58:15 --> Output Class Initialized
INFO - 2018-08-14 13:58:15 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:15 --> Input Class Initialized
INFO - 2018-08-14 13:58:15 --> Language Class Initialized
INFO - 2018-08-14 13:58:15 --> Language Class Initialized
INFO - 2018-08-14 13:58:15 --> Config Class Initialized
INFO - 2018-08-14 13:58:16 --> Loader Class Initialized
INFO - 2018-08-14 13:58:16 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:16 --> Helper loaded: file_helper
INFO - 2018-08-14 13:58:16 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:16 --> Helper loaded: my_helper
INFO - 2018-08-14 13:58:16 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:16 --> Controller Class Initialized
DEBUG - 2018-08-14 13:58:16 --> File loaded: D:\laragon\www\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2018-08-14 13:58:16 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:58:16 --> Final output sent to browser
DEBUG - 2018-08-14 13:58:16 --> Total execution time: 0.6109
INFO - 2018-08-14 13:58:16 --> Config Class Initialized
INFO - 2018-08-14 13:58:16 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:16 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:16 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:16 --> URI Class Initialized
INFO - 2018-08-14 13:58:16 --> Router Class Initialized
INFO - 2018-08-14 13:58:16 --> Output Class Initialized
INFO - 2018-08-14 13:58:16 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:16 --> Input Class Initialized
INFO - 2018-08-14 13:58:16 --> Language Class Initialized
ERROR - 2018-08-14 13:58:16 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:58:18 --> Config Class Initialized
INFO - 2018-08-14 13:58:18 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:18 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:18 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:18 --> URI Class Initialized
INFO - 2018-08-14 13:58:18 --> Router Class Initialized
INFO - 2018-08-14 13:58:18 --> Output Class Initialized
INFO - 2018-08-14 13:58:18 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:18 --> Input Class Initialized
INFO - 2018-08-14 13:58:18 --> Language Class Initialized
INFO - 2018-08-14 13:58:18 --> Language Class Initialized
INFO - 2018-08-14 13:58:18 --> Config Class Initialized
INFO - 2018-08-14 13:58:18 --> Loader Class Initialized
INFO - 2018-08-14 13:58:18 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:18 --> Helper loaded: file_helper
INFO - 2018-08-14 13:58:18 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:18 --> Helper loaded: my_helper
INFO - 2018-08-14 13:58:18 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:18 --> Controller Class Initialized
DEBUG - 2018-08-14 13:58:18 --> File loaded: D:\laragon\www\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2018-08-14 13:58:18 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:58:18 --> Final output sent to browser
DEBUG - 2018-08-14 13:58:18 --> Total execution time: 0.4676
INFO - 2018-08-14 13:58:18 --> Config Class Initialized
INFO - 2018-08-14 13:58:18 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:18 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:18 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:18 --> URI Class Initialized
INFO - 2018-08-14 13:58:18 --> Router Class Initialized
INFO - 2018-08-14 13:58:18 --> Output Class Initialized
INFO - 2018-08-14 13:58:18 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:18 --> Input Class Initialized
INFO - 2018-08-14 13:58:18 --> Language Class Initialized
ERROR - 2018-08-14 13:58:18 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:58:25 --> Config Class Initialized
INFO - 2018-08-14 13:58:25 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:25 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:25 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:25 --> URI Class Initialized
INFO - 2018-08-14 13:58:25 --> Router Class Initialized
INFO - 2018-08-14 13:58:25 --> Output Class Initialized
INFO - 2018-08-14 13:58:25 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:25 --> Input Class Initialized
INFO - 2018-08-14 13:58:25 --> Language Class Initialized
INFO - 2018-08-14 13:58:25 --> Language Class Initialized
INFO - 2018-08-14 13:58:25 --> Config Class Initialized
INFO - 2018-08-14 13:58:25 --> Loader Class Initialized
INFO - 2018-08-14 13:58:25 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:25 --> Helper loaded: file_helper
INFO - 2018-08-14 13:58:25 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:25 --> Helper loaded: my_helper
INFO - 2018-08-14 13:58:25 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:25 --> Controller Class Initialized
INFO - 2018-08-14 13:58:25 --> Config Class Initialized
INFO - 2018-08-14 13:58:25 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:25 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:25 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:25 --> URI Class Initialized
INFO - 2018-08-14 13:58:25 --> Router Class Initialized
INFO - 2018-08-14 13:58:25 --> Output Class Initialized
INFO - 2018-08-14 13:58:25 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:25 --> Input Class Initialized
INFO - 2018-08-14 13:58:25 --> Language Class Initialized
INFO - 2018-08-14 13:58:25 --> Language Class Initialized
INFO - 2018-08-14 13:58:25 --> Config Class Initialized
INFO - 2018-08-14 13:58:25 --> Loader Class Initialized
INFO - 2018-08-14 13:58:26 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:26 --> Helper loaded: file_helper
INFO - 2018-08-14 13:58:26 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:26 --> Helper loaded: my_helper
INFO - 2018-08-14 13:58:26 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:26 --> Controller Class Initialized
DEBUG - 2018-08-14 13:58:26 --> File loaded: D:\laragon\www\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2018-08-14 13:58:26 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:58:26 --> Final output sent to browser
DEBUG - 2018-08-14 13:58:26 --> Total execution time: 0.4452
INFO - 2018-08-14 13:58:26 --> Config Class Initialized
INFO - 2018-08-14 13:58:26 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:26 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:26 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:26 --> URI Class Initialized
INFO - 2018-08-14 13:58:26 --> Router Class Initialized
INFO - 2018-08-14 13:58:26 --> Output Class Initialized
INFO - 2018-08-14 13:58:26 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:26 --> Input Class Initialized
INFO - 2018-08-14 13:58:26 --> Language Class Initialized
ERROR - 2018-08-14 13:58:26 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:58:30 --> Config Class Initialized
INFO - 2018-08-14 13:58:30 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:30 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:30 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:30 --> URI Class Initialized
INFO - 2018-08-14 13:58:30 --> Router Class Initialized
INFO - 2018-08-14 13:58:30 --> Output Class Initialized
INFO - 2018-08-14 13:58:30 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:30 --> Input Class Initialized
INFO - 2018-08-14 13:58:30 --> Language Class Initialized
INFO - 2018-08-14 13:58:30 --> Language Class Initialized
INFO - 2018-08-14 13:58:30 --> Config Class Initialized
INFO - 2018-08-14 13:58:30 --> Loader Class Initialized
INFO - 2018-08-14 13:58:30 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:30 --> Helper loaded: file_helper
INFO - 2018-08-14 13:58:31 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:31 --> Helper loaded: my_helper
INFO - 2018-08-14 13:58:31 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:31 --> Controller Class Initialized
DEBUG - 2018-08-14 13:58:31 --> File loaded: D:\laragon\www\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2018-08-14 13:58:31 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:58:31 --> Final output sent to browser
DEBUG - 2018-08-14 13:58:31 --> Total execution time: 0.4442
INFO - 2018-08-14 13:58:31 --> Config Class Initialized
INFO - 2018-08-14 13:58:31 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:31 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:31 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:31 --> URI Class Initialized
INFO - 2018-08-14 13:58:31 --> Router Class Initialized
INFO - 2018-08-14 13:58:31 --> Output Class Initialized
INFO - 2018-08-14 13:58:31 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:31 --> Input Class Initialized
INFO - 2018-08-14 13:58:31 --> Language Class Initialized
ERROR - 2018-08-14 13:58:31 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:58:31 --> Config Class Initialized
INFO - 2018-08-14 13:58:31 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:31 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:31 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:31 --> URI Class Initialized
INFO - 2018-08-14 13:58:31 --> Router Class Initialized
INFO - 2018-08-14 13:58:31 --> Output Class Initialized
INFO - 2018-08-14 13:58:31 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:31 --> Input Class Initialized
INFO - 2018-08-14 13:58:31 --> Language Class Initialized
INFO - 2018-08-14 13:58:31 --> Language Class Initialized
INFO - 2018-08-14 13:58:31 --> Config Class Initialized
INFO - 2018-08-14 13:58:31 --> Loader Class Initialized
INFO - 2018-08-14 13:58:31 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:31 --> Helper loaded: file_helper
INFO - 2018-08-14 13:58:31 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:31 --> Helper loaded: my_helper
INFO - 2018-08-14 13:58:31 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:31 --> Controller Class Initialized
INFO - 2018-08-14 13:58:32 --> Config Class Initialized
INFO - 2018-08-14 13:58:32 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:32 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:32 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:32 --> URI Class Initialized
INFO - 2018-08-14 13:58:32 --> Router Class Initialized
INFO - 2018-08-14 13:58:32 --> Output Class Initialized
INFO - 2018-08-14 13:58:32 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:32 --> Input Class Initialized
INFO - 2018-08-14 13:58:32 --> Language Class Initialized
INFO - 2018-08-14 13:58:32 --> Language Class Initialized
INFO - 2018-08-14 13:58:32 --> Config Class Initialized
INFO - 2018-08-14 13:58:32 --> Loader Class Initialized
INFO - 2018-08-14 13:58:32 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:32 --> Helper loaded: file_helper
INFO - 2018-08-14 13:58:32 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:32 --> Helper loaded: my_helper
INFO - 2018-08-14 13:58:32 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:32 --> Controller Class Initialized
DEBUG - 2018-08-14 13:58:32 --> File loaded: D:\laragon\www\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2018-08-14 13:58:32 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:58:32 --> Final output sent to browser
DEBUG - 2018-08-14 13:58:32 --> Total execution time: 0.4946
INFO - 2018-08-14 13:58:33 --> Config Class Initialized
INFO - 2018-08-14 13:58:33 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:33 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:33 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:33 --> URI Class Initialized
INFO - 2018-08-14 13:58:33 --> Router Class Initialized
INFO - 2018-08-14 13:58:33 --> Output Class Initialized
INFO - 2018-08-14 13:58:33 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:33 --> Input Class Initialized
INFO - 2018-08-14 13:58:33 --> Language Class Initialized
ERROR - 2018-08-14 13:58:33 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:58:33 --> Config Class Initialized
INFO - 2018-08-14 13:58:33 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:33 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:33 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:33 --> URI Class Initialized
INFO - 2018-08-14 13:58:33 --> Router Class Initialized
INFO - 2018-08-14 13:58:33 --> Output Class Initialized
INFO - 2018-08-14 13:58:33 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:33 --> Input Class Initialized
INFO - 2018-08-14 13:58:33 --> Language Class Initialized
INFO - 2018-08-14 13:58:33 --> Language Class Initialized
INFO - 2018-08-14 13:58:33 --> Config Class Initialized
INFO - 2018-08-14 13:58:33 --> Loader Class Initialized
INFO - 2018-08-14 13:58:33 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:33 --> Helper loaded: file_helper
INFO - 2018-08-14 13:58:33 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:33 --> Helper loaded: my_helper
INFO - 2018-08-14 13:58:33 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:33 --> Controller Class Initialized
INFO - 2018-08-14 13:58:34 --> Config Class Initialized
INFO - 2018-08-14 13:58:34 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:34 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:34 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:34 --> URI Class Initialized
INFO - 2018-08-14 13:58:34 --> Router Class Initialized
INFO - 2018-08-14 13:58:34 --> Output Class Initialized
INFO - 2018-08-14 13:58:34 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:34 --> Input Class Initialized
INFO - 2018-08-14 13:58:34 --> Language Class Initialized
INFO - 2018-08-14 13:58:34 --> Language Class Initialized
INFO - 2018-08-14 13:58:34 --> Config Class Initialized
INFO - 2018-08-14 13:58:34 --> Loader Class Initialized
INFO - 2018-08-14 13:58:34 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:34 --> Helper loaded: file_helper
INFO - 2018-08-14 13:58:34 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:34 --> Helper loaded: my_helper
INFO - 2018-08-14 13:58:34 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:35 --> Controller Class Initialized
DEBUG - 2018-08-14 13:58:35 --> File loaded: D:\laragon\www\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2018-08-14 13:58:35 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:58:35 --> Final output sent to browser
DEBUG - 2018-08-14 13:58:35 --> Total execution time: 0.4090
INFO - 2018-08-14 13:58:35 --> Config Class Initialized
INFO - 2018-08-14 13:58:35 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:35 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:35 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:35 --> URI Class Initialized
INFO - 2018-08-14 13:58:35 --> Router Class Initialized
INFO - 2018-08-14 13:58:35 --> Output Class Initialized
INFO - 2018-08-14 13:58:35 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:35 --> Input Class Initialized
INFO - 2018-08-14 13:58:35 --> Language Class Initialized
ERROR - 2018-08-14 13:58:35 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:58:35 --> Config Class Initialized
INFO - 2018-08-14 13:58:35 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:35 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:35 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:35 --> URI Class Initialized
INFO - 2018-08-14 13:58:35 --> Router Class Initialized
INFO - 2018-08-14 13:58:35 --> Output Class Initialized
INFO - 2018-08-14 13:58:35 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:35 --> Input Class Initialized
INFO - 2018-08-14 13:58:35 --> Language Class Initialized
INFO - 2018-08-14 13:58:35 --> Language Class Initialized
INFO - 2018-08-14 13:58:35 --> Config Class Initialized
INFO - 2018-08-14 13:58:35 --> Loader Class Initialized
INFO - 2018-08-14 13:58:35 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:35 --> Helper loaded: file_helper
INFO - 2018-08-14 13:58:35 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:35 --> Helper loaded: my_helper
INFO - 2018-08-14 13:58:35 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:35 --> Controller Class Initialized
INFO - 2018-08-14 13:58:36 --> Config Class Initialized
INFO - 2018-08-14 13:58:36 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:36 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:36 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:36 --> URI Class Initialized
INFO - 2018-08-14 13:58:36 --> Router Class Initialized
INFO - 2018-08-14 13:58:36 --> Output Class Initialized
INFO - 2018-08-14 13:58:36 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:36 --> Input Class Initialized
INFO - 2018-08-14 13:58:36 --> Language Class Initialized
INFO - 2018-08-14 13:58:36 --> Language Class Initialized
INFO - 2018-08-14 13:58:37 --> Config Class Initialized
INFO - 2018-08-14 13:58:37 --> Loader Class Initialized
INFO - 2018-08-14 13:58:37 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:37 --> Helper loaded: file_helper
INFO - 2018-08-14 13:58:37 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:37 --> Helper loaded: my_helper
INFO - 2018-08-14 13:58:37 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:58:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:37 --> Controller Class Initialized
DEBUG - 2018-08-14 13:58:37 --> File loaded: D:\laragon\www\nilai\application\modules/tahun/views/list.php
DEBUG - 2018-08-14 13:58:37 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:58:37 --> Final output sent to browser
DEBUG - 2018-08-14 13:58:37 --> Total execution time: 0.6073
INFO - 2018-08-14 13:58:37 --> Config Class Initialized
INFO - 2018-08-14 13:58:37 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:37 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:37 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:37 --> URI Class Initialized
INFO - 2018-08-14 13:58:37 --> Router Class Initialized
INFO - 2018-08-14 13:58:37 --> Output Class Initialized
INFO - 2018-08-14 13:58:37 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:37 --> Input Class Initialized
INFO - 2018-08-14 13:58:37 --> Language Class Initialized
ERROR - 2018-08-14 13:58:37 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:58:37 --> Config Class Initialized
INFO - 2018-08-14 13:58:37 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:37 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:37 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:37 --> URI Class Initialized
INFO - 2018-08-14 13:58:37 --> Router Class Initialized
INFO - 2018-08-14 13:58:38 --> Output Class Initialized
INFO - 2018-08-14 13:58:38 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:38 --> Input Class Initialized
INFO - 2018-08-14 13:58:38 --> Language Class Initialized
INFO - 2018-08-14 13:58:38 --> Language Class Initialized
INFO - 2018-08-14 13:58:38 --> Config Class Initialized
INFO - 2018-08-14 13:58:38 --> Loader Class Initialized
INFO - 2018-08-14 13:58:38 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:38 --> Helper loaded: file_helper
INFO - 2018-08-14 13:58:38 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:38 --> Helper loaded: my_helper
INFO - 2018-08-14 13:58:38 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:58:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:38 --> Controller Class Initialized
INFO - 2018-08-14 13:58:39 --> Config Class Initialized
INFO - 2018-08-14 13:58:39 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:39 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:39 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:39 --> URI Class Initialized
INFO - 2018-08-14 13:58:39 --> Router Class Initialized
INFO - 2018-08-14 13:58:39 --> Output Class Initialized
INFO - 2018-08-14 13:58:39 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:39 --> Input Class Initialized
INFO - 2018-08-14 13:58:39 --> Language Class Initialized
INFO - 2018-08-14 13:58:39 --> Language Class Initialized
INFO - 2018-08-14 13:58:40 --> Config Class Initialized
INFO - 2018-08-14 13:58:40 --> Loader Class Initialized
INFO - 2018-08-14 13:58:40 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:40 --> Helper loaded: file_helper
INFO - 2018-08-14 13:58:40 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:40 --> Helper loaded: my_helper
INFO - 2018-08-14 13:58:40 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:40 --> Controller Class Initialized
DEBUG - 2018-08-14 13:58:40 --> File loaded: D:\laragon\www\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2018-08-14 13:58:40 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:58:40 --> Final output sent to browser
DEBUG - 2018-08-14 13:58:40 --> Total execution time: 0.4734
INFO - 2018-08-14 13:58:40 --> Config Class Initialized
INFO - 2018-08-14 13:58:40 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:40 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:40 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:40 --> URI Class Initialized
INFO - 2018-08-14 13:58:40 --> Router Class Initialized
INFO - 2018-08-14 13:58:40 --> Output Class Initialized
INFO - 2018-08-14 13:58:40 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:40 --> Input Class Initialized
INFO - 2018-08-14 13:58:40 --> Language Class Initialized
ERROR - 2018-08-14 13:58:40 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:58:40 --> Config Class Initialized
INFO - 2018-08-14 13:58:40 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:40 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:40 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:40 --> URI Class Initialized
INFO - 2018-08-14 13:58:40 --> Router Class Initialized
INFO - 2018-08-14 13:58:40 --> Output Class Initialized
INFO - 2018-08-14 13:58:40 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:40 --> Input Class Initialized
INFO - 2018-08-14 13:58:40 --> Language Class Initialized
INFO - 2018-08-14 13:58:40 --> Language Class Initialized
INFO - 2018-08-14 13:58:40 --> Config Class Initialized
INFO - 2018-08-14 13:58:40 --> Loader Class Initialized
INFO - 2018-08-14 13:58:40 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:40 --> Helper loaded: file_helper
INFO - 2018-08-14 13:58:40 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:40 --> Helper loaded: my_helper
INFO - 2018-08-14 13:58:41 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:41 --> Controller Class Initialized
INFO - 2018-08-14 13:58:41 --> Config Class Initialized
INFO - 2018-08-14 13:58:41 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:41 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:41 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:41 --> URI Class Initialized
INFO - 2018-08-14 13:58:41 --> Router Class Initialized
INFO - 2018-08-14 13:58:41 --> Output Class Initialized
INFO - 2018-08-14 13:58:41 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:41 --> Input Class Initialized
INFO - 2018-08-14 13:58:41 --> Language Class Initialized
INFO - 2018-08-14 13:58:41 --> Language Class Initialized
INFO - 2018-08-14 13:58:41 --> Config Class Initialized
INFO - 2018-08-14 13:58:41 --> Loader Class Initialized
INFO - 2018-08-14 13:58:41 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:41 --> Helper loaded: file_helper
INFO - 2018-08-14 13:58:41 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:41 --> Helper loaded: my_helper
INFO - 2018-08-14 13:58:41 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:41 --> Controller Class Initialized
DEBUG - 2018-08-14 13:58:41 --> File loaded: D:\laragon\www\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2018-08-14 13:58:42 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:58:42 --> Final output sent to browser
DEBUG - 2018-08-14 13:58:42 --> Total execution time: 0.6010
INFO - 2018-08-14 13:58:42 --> Config Class Initialized
INFO - 2018-08-14 13:58:42 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:42 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:42 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:42 --> URI Class Initialized
INFO - 2018-08-14 13:58:42 --> Router Class Initialized
INFO - 2018-08-14 13:58:42 --> Output Class Initialized
INFO - 2018-08-14 13:58:42 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:42 --> Input Class Initialized
INFO - 2018-08-14 13:58:42 --> Language Class Initialized
ERROR - 2018-08-14 13:58:42 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:58:53 --> Config Class Initialized
INFO - 2018-08-14 13:58:53 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:53 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:53 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:53 --> URI Class Initialized
INFO - 2018-08-14 13:58:53 --> Router Class Initialized
INFO - 2018-08-14 13:58:53 --> Output Class Initialized
INFO - 2018-08-14 13:58:53 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:53 --> Input Class Initialized
INFO - 2018-08-14 13:58:53 --> Language Class Initialized
INFO - 2018-08-14 13:58:53 --> Language Class Initialized
INFO - 2018-08-14 13:58:53 --> Config Class Initialized
INFO - 2018-08-14 13:58:53 --> Loader Class Initialized
INFO - 2018-08-14 13:58:53 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:53 --> Helper loaded: file_helper
INFO - 2018-08-14 13:58:53 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:53 --> Helper loaded: my_helper
INFO - 2018-08-14 13:58:53 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:53 --> Controller Class Initialized
DEBUG - 2018-08-14 13:58:53 --> File loaded: D:\laragon\www\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2018-08-14 13:58:53 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:58:53 --> Final output sent to browser
DEBUG - 2018-08-14 13:58:54 --> Total execution time: 0.9146
INFO - 2018-08-14 13:58:54 --> Config Class Initialized
INFO - 2018-08-14 13:58:54 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:54 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:54 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:54 --> URI Class Initialized
INFO - 2018-08-14 13:58:54 --> Router Class Initialized
INFO - 2018-08-14 13:58:54 --> Output Class Initialized
INFO - 2018-08-14 13:58:54 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:54 --> Input Class Initialized
INFO - 2018-08-14 13:58:54 --> Language Class Initialized
ERROR - 2018-08-14 13:58:54 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:58:55 --> Config Class Initialized
INFO - 2018-08-14 13:58:55 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:55 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:55 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:55 --> URI Class Initialized
INFO - 2018-08-14 13:58:55 --> Router Class Initialized
INFO - 2018-08-14 13:58:55 --> Output Class Initialized
INFO - 2018-08-14 13:58:56 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:56 --> Input Class Initialized
INFO - 2018-08-14 13:58:56 --> Language Class Initialized
INFO - 2018-08-14 13:58:56 --> Language Class Initialized
INFO - 2018-08-14 13:58:56 --> Config Class Initialized
INFO - 2018-08-14 13:58:56 --> Loader Class Initialized
INFO - 2018-08-14 13:58:56 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:56 --> Helper loaded: file_helper
INFO - 2018-08-14 13:58:56 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:56 --> Helper loaded: my_helper
INFO - 2018-08-14 13:58:56 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:56 --> Controller Class Initialized
DEBUG - 2018-08-14 13:58:56 --> File loaded: D:\laragon\www\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2018-08-14 13:58:56 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:58:56 --> Final output sent to browser
DEBUG - 2018-08-14 13:58:56 --> Total execution time: 0.4366
INFO - 2018-08-14 13:58:56 --> Config Class Initialized
INFO - 2018-08-14 13:58:56 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:56 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:56 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:56 --> URI Class Initialized
INFO - 2018-08-14 13:58:56 --> Router Class Initialized
INFO - 2018-08-14 13:58:56 --> Output Class Initialized
INFO - 2018-08-14 13:58:56 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:56 --> Input Class Initialized
INFO - 2018-08-14 13:58:56 --> Language Class Initialized
ERROR - 2018-08-14 13:58:56 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:58:56 --> Config Class Initialized
INFO - 2018-08-14 13:58:56 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:56 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:56 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:56 --> URI Class Initialized
INFO - 2018-08-14 13:58:56 --> Router Class Initialized
INFO - 2018-08-14 13:58:56 --> Output Class Initialized
INFO - 2018-08-14 13:58:56 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:56 --> Input Class Initialized
INFO - 2018-08-14 13:58:56 --> Language Class Initialized
INFO - 2018-08-14 13:58:56 --> Language Class Initialized
INFO - 2018-08-14 13:58:56 --> Config Class Initialized
INFO - 2018-08-14 13:58:56 --> Loader Class Initialized
INFO - 2018-08-14 13:58:56 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:57 --> Helper loaded: file_helper
INFO - 2018-08-14 13:58:57 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:57 --> Helper loaded: my_helper
INFO - 2018-08-14 13:58:57 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:57 --> Controller Class Initialized
INFO - 2018-08-14 13:58:57 --> Config Class Initialized
INFO - 2018-08-14 13:58:57 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:57 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:57 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:57 --> URI Class Initialized
INFO - 2018-08-14 13:58:57 --> Router Class Initialized
INFO - 2018-08-14 13:58:57 --> Output Class Initialized
INFO - 2018-08-14 13:58:57 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:57 --> Input Class Initialized
INFO - 2018-08-14 13:58:57 --> Language Class Initialized
INFO - 2018-08-14 13:58:57 --> Language Class Initialized
INFO - 2018-08-14 13:58:57 --> Config Class Initialized
INFO - 2018-08-14 13:58:57 --> Loader Class Initialized
INFO - 2018-08-14 13:58:57 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:57 --> Helper loaded: file_helper
INFO - 2018-08-14 13:58:57 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:57 --> Helper loaded: my_helper
INFO - 2018-08-14 13:58:57 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:57 --> Controller Class Initialized
DEBUG - 2018-08-14 13:58:57 --> File loaded: D:\laragon\www\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2018-08-14 13:58:57 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:58:57 --> Final output sent to browser
DEBUG - 2018-08-14 13:58:57 --> Total execution time: 0.5130
INFO - 2018-08-14 13:58:58 --> Config Class Initialized
INFO - 2018-08-14 13:58:58 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:58 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:58 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:58 --> URI Class Initialized
INFO - 2018-08-14 13:58:58 --> Router Class Initialized
INFO - 2018-08-14 13:58:58 --> Output Class Initialized
INFO - 2018-08-14 13:58:58 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:58 --> Input Class Initialized
INFO - 2018-08-14 13:58:58 --> Language Class Initialized
ERROR - 2018-08-14 13:58:58 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:58:58 --> Config Class Initialized
INFO - 2018-08-14 13:58:58 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:58 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:58 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:58 --> URI Class Initialized
INFO - 2018-08-14 13:58:58 --> Router Class Initialized
INFO - 2018-08-14 13:58:58 --> Output Class Initialized
INFO - 2018-08-14 13:58:58 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:58 --> Input Class Initialized
INFO - 2018-08-14 13:58:58 --> Language Class Initialized
INFO - 2018-08-14 13:58:58 --> Language Class Initialized
INFO - 2018-08-14 13:58:58 --> Config Class Initialized
INFO - 2018-08-14 13:58:58 --> Loader Class Initialized
INFO - 2018-08-14 13:58:58 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:58 --> Helper loaded: file_helper
INFO - 2018-08-14 13:58:58 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:58 --> Helper loaded: my_helper
INFO - 2018-08-14 13:58:58 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:58 --> Controller Class Initialized
INFO - 2018-08-14 13:58:59 --> Config Class Initialized
INFO - 2018-08-14 13:58:59 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:59 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:59 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:59 --> URI Class Initialized
INFO - 2018-08-14 13:58:59 --> Router Class Initialized
INFO - 2018-08-14 13:58:59 --> Output Class Initialized
INFO - 2018-08-14 13:58:59 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:59 --> Input Class Initialized
INFO - 2018-08-14 13:58:59 --> Language Class Initialized
INFO - 2018-08-14 13:58:59 --> Language Class Initialized
INFO - 2018-08-14 13:58:59 --> Config Class Initialized
INFO - 2018-08-14 13:58:59 --> Loader Class Initialized
INFO - 2018-08-14 13:58:59 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:59 --> Helper loaded: file_helper
INFO - 2018-08-14 13:58:59 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:59 --> Helper loaded: my_helper
INFO - 2018-08-14 13:58:59 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:58:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:59 --> Controller Class Initialized
DEBUG - 2018-08-14 13:58:59 --> File loaded: D:\laragon\www\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2018-08-14 13:58:59 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:58:59 --> Final output sent to browser
DEBUG - 2018-08-14 13:58:59 --> Total execution time: 0.4081
INFO - 2018-08-14 13:59:00 --> Config Class Initialized
INFO - 2018-08-14 13:59:00 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:59:00 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:59:00 --> Utf8 Class Initialized
INFO - 2018-08-14 13:59:00 --> URI Class Initialized
INFO - 2018-08-14 13:59:00 --> Router Class Initialized
INFO - 2018-08-14 13:59:00 --> Output Class Initialized
INFO - 2018-08-14 13:59:00 --> Security Class Initialized
DEBUG - 2018-08-14 13:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:59:00 --> Input Class Initialized
INFO - 2018-08-14 13:59:00 --> Language Class Initialized
ERROR - 2018-08-14 13:59:00 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:59:09 --> Config Class Initialized
INFO - 2018-08-14 13:59:09 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:59:09 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:59:09 --> Utf8 Class Initialized
INFO - 2018-08-14 13:59:09 --> URI Class Initialized
INFO - 2018-08-14 13:59:09 --> Router Class Initialized
INFO - 2018-08-14 13:59:09 --> Output Class Initialized
INFO - 2018-08-14 13:59:09 --> Security Class Initialized
DEBUG - 2018-08-14 13:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:59:09 --> Input Class Initialized
INFO - 2018-08-14 13:59:09 --> Language Class Initialized
INFO - 2018-08-14 13:59:09 --> Language Class Initialized
INFO - 2018-08-14 13:59:09 --> Config Class Initialized
INFO - 2018-08-14 13:59:09 --> Loader Class Initialized
INFO - 2018-08-14 13:59:09 --> Helper loaded: url_helper
INFO - 2018-08-14 13:59:09 --> Helper loaded: file_helper
INFO - 2018-08-14 13:59:09 --> Helper loaded: form_helper
INFO - 2018-08-14 13:59:09 --> Helper loaded: my_helper
INFO - 2018-08-14 13:59:09 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:59:09 --> Controller Class Initialized
INFO - 2018-08-14 13:59:10 --> Config Class Initialized
INFO - 2018-08-14 13:59:10 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:59:10 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:59:10 --> Utf8 Class Initialized
INFO - 2018-08-14 13:59:10 --> URI Class Initialized
INFO - 2018-08-14 13:59:10 --> Router Class Initialized
INFO - 2018-08-14 13:59:10 --> Output Class Initialized
INFO - 2018-08-14 13:59:10 --> Security Class Initialized
DEBUG - 2018-08-14 13:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:59:10 --> Input Class Initialized
INFO - 2018-08-14 13:59:11 --> Language Class Initialized
INFO - 2018-08-14 13:59:11 --> Language Class Initialized
INFO - 2018-08-14 13:59:11 --> Config Class Initialized
INFO - 2018-08-14 13:59:11 --> Loader Class Initialized
INFO - 2018-08-14 13:59:11 --> Helper loaded: url_helper
INFO - 2018-08-14 13:59:11 --> Helper loaded: file_helper
INFO - 2018-08-14 13:59:11 --> Helper loaded: form_helper
INFO - 2018-08-14 13:59:11 --> Helper loaded: my_helper
INFO - 2018-08-14 13:59:11 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:59:11 --> Controller Class Initialized
DEBUG - 2018-08-14 13:59:11 --> File loaded: D:\laragon\www\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2018-08-14 13:59:11 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:59:11 --> Final output sent to browser
DEBUG - 2018-08-14 13:59:11 --> Total execution time: 1.0041
INFO - 2018-08-14 13:59:11 --> Config Class Initialized
INFO - 2018-08-14 13:59:11 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:59:11 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:59:11 --> Utf8 Class Initialized
INFO - 2018-08-14 13:59:11 --> URI Class Initialized
INFO - 2018-08-14 13:59:11 --> Router Class Initialized
INFO - 2018-08-14 13:59:11 --> Output Class Initialized
INFO - 2018-08-14 13:59:11 --> Security Class Initialized
DEBUG - 2018-08-14 13:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:59:11 --> Input Class Initialized
INFO - 2018-08-14 13:59:11 --> Language Class Initialized
ERROR - 2018-08-14 13:59:11 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:59:11 --> Config Class Initialized
INFO - 2018-08-14 13:59:12 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:59:12 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:59:12 --> Utf8 Class Initialized
INFO - 2018-08-14 13:59:12 --> URI Class Initialized
INFO - 2018-08-14 13:59:12 --> Router Class Initialized
INFO - 2018-08-14 13:59:12 --> Output Class Initialized
INFO - 2018-08-14 13:59:12 --> Security Class Initialized
DEBUG - 2018-08-14 13:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:59:12 --> Input Class Initialized
INFO - 2018-08-14 13:59:12 --> Language Class Initialized
INFO - 2018-08-14 13:59:12 --> Language Class Initialized
INFO - 2018-08-14 13:59:12 --> Config Class Initialized
INFO - 2018-08-14 13:59:12 --> Loader Class Initialized
INFO - 2018-08-14 13:59:12 --> Helper loaded: url_helper
INFO - 2018-08-14 13:59:12 --> Helper loaded: file_helper
INFO - 2018-08-14 13:59:12 --> Helper loaded: form_helper
INFO - 2018-08-14 13:59:12 --> Helper loaded: my_helper
INFO - 2018-08-14 13:59:12 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:59:12 --> Controller Class Initialized
INFO - 2018-08-14 13:59:17 --> Config Class Initialized
INFO - 2018-08-14 13:59:17 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:59:17 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:59:17 --> Utf8 Class Initialized
INFO - 2018-08-14 13:59:17 --> URI Class Initialized
INFO - 2018-08-14 13:59:17 --> Router Class Initialized
INFO - 2018-08-14 13:59:17 --> Output Class Initialized
INFO - 2018-08-14 13:59:17 --> Security Class Initialized
DEBUG - 2018-08-14 13:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:59:17 --> Input Class Initialized
INFO - 2018-08-14 13:59:17 --> Language Class Initialized
INFO - 2018-08-14 13:59:17 --> Language Class Initialized
INFO - 2018-08-14 13:59:17 --> Config Class Initialized
INFO - 2018-08-14 13:59:18 --> Loader Class Initialized
INFO - 2018-08-14 13:59:18 --> Helper loaded: url_helper
INFO - 2018-08-14 13:59:18 --> Helper loaded: file_helper
INFO - 2018-08-14 13:59:18 --> Helper loaded: form_helper
INFO - 2018-08-14 13:59:18 --> Helper loaded: my_helper
INFO - 2018-08-14 13:59:18 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:59:18 --> Controller Class Initialized
DEBUG - 2018-08-14 13:59:18 --> File loaded: D:\laragon\www\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2018-08-14 13:59:18 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:59:18 --> Final output sent to browser
DEBUG - 2018-08-14 13:59:18 --> Total execution time: 0.4828
INFO - 2018-08-14 13:59:18 --> Config Class Initialized
INFO - 2018-08-14 13:59:18 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:59:18 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:59:18 --> Utf8 Class Initialized
INFO - 2018-08-14 13:59:18 --> URI Class Initialized
INFO - 2018-08-14 13:59:18 --> Router Class Initialized
INFO - 2018-08-14 13:59:18 --> Output Class Initialized
INFO - 2018-08-14 13:59:18 --> Security Class Initialized
DEBUG - 2018-08-14 13:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:59:18 --> Input Class Initialized
INFO - 2018-08-14 13:59:18 --> Language Class Initialized
ERROR - 2018-08-14 13:59:18 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:59:25 --> Config Class Initialized
INFO - 2018-08-14 13:59:25 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:59:25 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:59:25 --> Utf8 Class Initialized
INFO - 2018-08-14 13:59:25 --> URI Class Initialized
INFO - 2018-08-14 13:59:25 --> Router Class Initialized
INFO - 2018-08-14 13:59:25 --> Output Class Initialized
INFO - 2018-08-14 13:59:25 --> Security Class Initialized
DEBUG - 2018-08-14 13:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:59:25 --> Input Class Initialized
INFO - 2018-08-14 13:59:25 --> Language Class Initialized
INFO - 2018-08-14 13:59:25 --> Language Class Initialized
INFO - 2018-08-14 13:59:26 --> Config Class Initialized
INFO - 2018-08-14 13:59:26 --> Loader Class Initialized
INFO - 2018-08-14 13:59:26 --> Helper loaded: url_helper
INFO - 2018-08-14 13:59:26 --> Helper loaded: file_helper
INFO - 2018-08-14 13:59:26 --> Helper loaded: form_helper
INFO - 2018-08-14 13:59:26 --> Helper loaded: my_helper
INFO - 2018-08-14 13:59:26 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:59:26 --> Controller Class Initialized
INFO - 2018-08-14 13:59:26 --> Config Class Initialized
INFO - 2018-08-14 13:59:26 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:59:26 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:59:26 --> Utf8 Class Initialized
INFO - 2018-08-14 13:59:26 --> URI Class Initialized
INFO - 2018-08-14 13:59:26 --> Router Class Initialized
INFO - 2018-08-14 13:59:26 --> Output Class Initialized
INFO - 2018-08-14 13:59:26 --> Security Class Initialized
DEBUG - 2018-08-14 13:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:59:26 --> Input Class Initialized
INFO - 2018-08-14 13:59:27 --> Language Class Initialized
INFO - 2018-08-14 13:59:27 --> Language Class Initialized
INFO - 2018-08-14 13:59:27 --> Config Class Initialized
INFO - 2018-08-14 13:59:27 --> Loader Class Initialized
INFO - 2018-08-14 13:59:27 --> Helper loaded: url_helper
INFO - 2018-08-14 13:59:27 --> Helper loaded: file_helper
INFO - 2018-08-14 13:59:27 --> Helper loaded: form_helper
INFO - 2018-08-14 13:59:27 --> Helper loaded: my_helper
INFO - 2018-08-14 13:59:27 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:59:27 --> Controller Class Initialized
DEBUG - 2018-08-14 13:59:27 --> File loaded: D:\laragon\www\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2018-08-14 13:59:27 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:59:27 --> Final output sent to browser
DEBUG - 2018-08-14 13:59:27 --> Total execution time: 0.6750
INFO - 2018-08-14 13:59:27 --> Config Class Initialized
INFO - 2018-08-14 13:59:27 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:59:27 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:59:27 --> Utf8 Class Initialized
INFO - 2018-08-14 13:59:27 --> URI Class Initialized
INFO - 2018-08-14 13:59:27 --> Router Class Initialized
INFO - 2018-08-14 13:59:27 --> Output Class Initialized
INFO - 2018-08-14 13:59:27 --> Security Class Initialized
DEBUG - 2018-08-14 13:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:59:27 --> Input Class Initialized
INFO - 2018-08-14 13:59:27 --> Language Class Initialized
ERROR - 2018-08-14 13:59:27 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:59:27 --> Config Class Initialized
INFO - 2018-08-14 13:59:27 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:59:27 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:59:27 --> Utf8 Class Initialized
INFO - 2018-08-14 13:59:27 --> URI Class Initialized
INFO - 2018-08-14 13:59:27 --> Router Class Initialized
INFO - 2018-08-14 13:59:27 --> Output Class Initialized
INFO - 2018-08-14 13:59:27 --> Security Class Initialized
DEBUG - 2018-08-14 13:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:59:27 --> Input Class Initialized
INFO - 2018-08-14 13:59:27 --> Language Class Initialized
INFO - 2018-08-14 13:59:27 --> Language Class Initialized
INFO - 2018-08-14 13:59:27 --> Config Class Initialized
INFO - 2018-08-14 13:59:28 --> Loader Class Initialized
INFO - 2018-08-14 13:59:28 --> Helper loaded: url_helper
INFO - 2018-08-14 13:59:28 --> Helper loaded: file_helper
INFO - 2018-08-14 13:59:28 --> Helper loaded: form_helper
INFO - 2018-08-14 13:59:28 --> Helper loaded: my_helper
INFO - 2018-08-14 13:59:28 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:59:28 --> Controller Class Initialized
INFO - 2018-08-14 13:59:28 --> Config Class Initialized
INFO - 2018-08-14 13:59:28 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:59:28 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:59:28 --> Utf8 Class Initialized
INFO - 2018-08-14 13:59:28 --> URI Class Initialized
INFO - 2018-08-14 13:59:29 --> Router Class Initialized
INFO - 2018-08-14 13:59:29 --> Output Class Initialized
INFO - 2018-08-14 13:59:29 --> Security Class Initialized
DEBUG - 2018-08-14 13:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:59:29 --> Input Class Initialized
INFO - 2018-08-14 13:59:29 --> Language Class Initialized
INFO - 2018-08-14 13:59:29 --> Language Class Initialized
INFO - 2018-08-14 13:59:29 --> Config Class Initialized
INFO - 2018-08-14 13:59:29 --> Loader Class Initialized
INFO - 2018-08-14 13:59:29 --> Helper loaded: url_helper
INFO - 2018-08-14 13:59:29 --> Helper loaded: file_helper
INFO - 2018-08-14 13:59:29 --> Helper loaded: form_helper
INFO - 2018-08-14 13:59:29 --> Helper loaded: my_helper
INFO - 2018-08-14 13:59:29 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:59:29 --> Controller Class Initialized
DEBUG - 2018-08-14 13:59:29 --> File loaded: D:\laragon\www\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2018-08-14 13:59:29 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:59:29 --> Final output sent to browser
DEBUG - 2018-08-14 13:59:29 --> Total execution time: 0.4449
INFO - 2018-08-14 13:59:29 --> Config Class Initialized
INFO - 2018-08-14 13:59:29 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:59:29 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:59:29 --> Utf8 Class Initialized
INFO - 2018-08-14 13:59:29 --> URI Class Initialized
INFO - 2018-08-14 13:59:29 --> Router Class Initialized
INFO - 2018-08-14 13:59:29 --> Output Class Initialized
INFO - 2018-08-14 13:59:29 --> Security Class Initialized
DEBUG - 2018-08-14 13:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:59:29 --> Input Class Initialized
INFO - 2018-08-14 13:59:29 --> Language Class Initialized
ERROR - 2018-08-14 13:59:29 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:59:43 --> Config Class Initialized
INFO - 2018-08-14 13:59:43 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:59:43 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:59:43 --> Utf8 Class Initialized
INFO - 2018-08-14 13:59:43 --> URI Class Initialized
INFO - 2018-08-14 13:59:43 --> Router Class Initialized
INFO - 2018-08-14 13:59:43 --> Output Class Initialized
INFO - 2018-08-14 13:59:43 --> Security Class Initialized
DEBUG - 2018-08-14 13:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:59:43 --> Input Class Initialized
INFO - 2018-08-14 13:59:43 --> Language Class Initialized
INFO - 2018-08-14 13:59:43 --> Language Class Initialized
INFO - 2018-08-14 13:59:43 --> Config Class Initialized
INFO - 2018-08-14 13:59:43 --> Loader Class Initialized
INFO - 2018-08-14 13:59:44 --> Helper loaded: url_helper
INFO - 2018-08-14 13:59:44 --> Helper loaded: file_helper
INFO - 2018-08-14 13:59:44 --> Helper loaded: form_helper
INFO - 2018-08-14 13:59:44 --> Helper loaded: my_helper
INFO - 2018-08-14 13:59:44 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:59:44 --> Controller Class Initialized
INFO - 2018-08-14 13:59:44 --> Config Class Initialized
INFO - 2018-08-14 13:59:44 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:59:44 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:59:44 --> Utf8 Class Initialized
INFO - 2018-08-14 13:59:44 --> URI Class Initialized
INFO - 2018-08-14 13:59:44 --> Router Class Initialized
INFO - 2018-08-14 13:59:44 --> Output Class Initialized
INFO - 2018-08-14 13:59:44 --> Security Class Initialized
DEBUG - 2018-08-14 13:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:59:45 --> Input Class Initialized
INFO - 2018-08-14 13:59:45 --> Language Class Initialized
INFO - 2018-08-14 13:59:45 --> Language Class Initialized
INFO - 2018-08-14 13:59:45 --> Config Class Initialized
INFO - 2018-08-14 13:59:45 --> Loader Class Initialized
INFO - 2018-08-14 13:59:45 --> Helper loaded: url_helper
INFO - 2018-08-14 13:59:45 --> Helper loaded: file_helper
INFO - 2018-08-14 13:59:45 --> Helper loaded: form_helper
INFO - 2018-08-14 13:59:45 --> Helper loaded: my_helper
INFO - 2018-08-14 13:59:45 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:59:45 --> Controller Class Initialized
DEBUG - 2018-08-14 13:59:45 --> File loaded: D:\laragon\www\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2018-08-14 13:59:45 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:59:45 --> Final output sent to browser
DEBUG - 2018-08-14 13:59:45 --> Total execution time: 0.9954
INFO - 2018-08-14 13:59:45 --> Config Class Initialized
INFO - 2018-08-14 13:59:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:59:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:59:45 --> Utf8 Class Initialized
INFO - 2018-08-14 13:59:45 --> URI Class Initialized
INFO - 2018-08-14 13:59:45 --> Router Class Initialized
INFO - 2018-08-14 13:59:45 --> Output Class Initialized
INFO - 2018-08-14 13:59:45 --> Security Class Initialized
DEBUG - 2018-08-14 13:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:59:45 --> Input Class Initialized
INFO - 2018-08-14 13:59:45 --> Language Class Initialized
ERROR - 2018-08-14 13:59:45 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:59:45 --> Config Class Initialized
INFO - 2018-08-14 13:59:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:59:46 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:59:46 --> Utf8 Class Initialized
INFO - 2018-08-14 13:59:46 --> URI Class Initialized
INFO - 2018-08-14 13:59:46 --> Router Class Initialized
INFO - 2018-08-14 13:59:46 --> Output Class Initialized
INFO - 2018-08-14 13:59:46 --> Security Class Initialized
DEBUG - 2018-08-14 13:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:59:46 --> Input Class Initialized
INFO - 2018-08-14 13:59:46 --> Language Class Initialized
INFO - 2018-08-14 13:59:46 --> Language Class Initialized
INFO - 2018-08-14 13:59:46 --> Config Class Initialized
INFO - 2018-08-14 13:59:46 --> Loader Class Initialized
INFO - 2018-08-14 13:59:46 --> Helper loaded: url_helper
INFO - 2018-08-14 13:59:46 --> Helper loaded: file_helper
INFO - 2018-08-14 13:59:46 --> Helper loaded: form_helper
INFO - 2018-08-14 13:59:46 --> Helper loaded: my_helper
INFO - 2018-08-14 13:59:46 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:59:46 --> Controller Class Initialized
INFO - 2018-08-14 13:59:48 --> Config Class Initialized
INFO - 2018-08-14 13:59:48 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:59:48 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:59:48 --> Utf8 Class Initialized
INFO - 2018-08-14 13:59:48 --> URI Class Initialized
INFO - 2018-08-14 13:59:48 --> Router Class Initialized
INFO - 2018-08-14 13:59:48 --> Output Class Initialized
INFO - 2018-08-14 13:59:48 --> Security Class Initialized
DEBUG - 2018-08-14 13:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:59:48 --> Input Class Initialized
INFO - 2018-08-14 13:59:48 --> Language Class Initialized
INFO - 2018-08-14 13:59:48 --> Language Class Initialized
INFO - 2018-08-14 13:59:49 --> Config Class Initialized
INFO - 2018-08-14 13:59:49 --> Loader Class Initialized
INFO - 2018-08-14 13:59:49 --> Helper loaded: url_helper
INFO - 2018-08-14 13:59:49 --> Helper loaded: file_helper
INFO - 2018-08-14 13:59:49 --> Helper loaded: form_helper
INFO - 2018-08-14 13:59:49 --> Helper loaded: my_helper
INFO - 2018-08-14 13:59:49 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:59:49 --> Controller Class Initialized
INFO - 2018-08-14 13:59:49 --> Config Class Initialized
INFO - 2018-08-14 13:59:49 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:59:49 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:59:49 --> Utf8 Class Initialized
INFO - 2018-08-14 13:59:49 --> URI Class Initialized
INFO - 2018-08-14 13:59:50 --> Router Class Initialized
INFO - 2018-08-14 13:59:50 --> Output Class Initialized
INFO - 2018-08-14 13:59:50 --> Security Class Initialized
DEBUG - 2018-08-14 13:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:59:50 --> Input Class Initialized
INFO - 2018-08-14 13:59:50 --> Language Class Initialized
INFO - 2018-08-14 13:59:50 --> Language Class Initialized
INFO - 2018-08-14 13:59:50 --> Config Class Initialized
INFO - 2018-08-14 13:59:50 --> Loader Class Initialized
INFO - 2018-08-14 13:59:50 --> Helper loaded: url_helper
INFO - 2018-08-14 13:59:50 --> Helper loaded: file_helper
INFO - 2018-08-14 13:59:50 --> Helper loaded: form_helper
INFO - 2018-08-14 13:59:50 --> Helper loaded: my_helper
INFO - 2018-08-14 13:59:50 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:59:50 --> Controller Class Initialized
INFO - 2018-08-14 13:59:52 --> Config Class Initialized
INFO - 2018-08-14 13:59:52 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:59:52 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:59:52 --> Utf8 Class Initialized
INFO - 2018-08-14 13:59:52 --> URI Class Initialized
INFO - 2018-08-14 13:59:52 --> Router Class Initialized
INFO - 2018-08-14 13:59:52 --> Output Class Initialized
INFO - 2018-08-14 13:59:52 --> Security Class Initialized
DEBUG - 2018-08-14 13:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:59:52 --> Input Class Initialized
INFO - 2018-08-14 13:59:52 --> Language Class Initialized
INFO - 2018-08-14 13:59:52 --> Language Class Initialized
INFO - 2018-08-14 13:59:52 --> Config Class Initialized
INFO - 2018-08-14 13:59:52 --> Loader Class Initialized
INFO - 2018-08-14 13:59:52 --> Helper loaded: url_helper
INFO - 2018-08-14 13:59:52 --> Helper loaded: file_helper
INFO - 2018-08-14 13:59:52 --> Helper loaded: form_helper
INFO - 2018-08-14 13:59:52 --> Helper loaded: my_helper
INFO - 2018-08-14 13:59:52 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:59:52 --> Controller Class Initialized
DEBUG - 2018-08-14 13:59:52 --> File loaded: D:\laragon\www\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2018-08-14 13:59:52 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:59:53 --> Final output sent to browser
DEBUG - 2018-08-14 13:59:53 --> Total execution time: 0.4240
INFO - 2018-08-14 13:59:53 --> Config Class Initialized
INFO - 2018-08-14 13:59:53 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:59:53 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:59:53 --> Utf8 Class Initialized
INFO - 2018-08-14 13:59:53 --> URI Class Initialized
INFO - 2018-08-14 13:59:53 --> Router Class Initialized
INFO - 2018-08-14 13:59:53 --> Output Class Initialized
INFO - 2018-08-14 13:59:53 --> Security Class Initialized
DEBUG - 2018-08-14 13:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:59:53 --> Input Class Initialized
INFO - 2018-08-14 13:59:53 --> Language Class Initialized
ERROR - 2018-08-14 13:59:53 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:59:57 --> Config Class Initialized
INFO - 2018-08-14 13:59:57 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:59:57 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:59:57 --> Utf8 Class Initialized
INFO - 2018-08-14 13:59:57 --> URI Class Initialized
INFO - 2018-08-14 13:59:57 --> Router Class Initialized
INFO - 2018-08-14 13:59:57 --> Output Class Initialized
INFO - 2018-08-14 13:59:57 --> Security Class Initialized
DEBUG - 2018-08-14 13:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:59:57 --> Input Class Initialized
INFO - 2018-08-14 13:59:57 --> Language Class Initialized
INFO - 2018-08-14 13:59:57 --> Language Class Initialized
INFO - 2018-08-14 13:59:57 --> Config Class Initialized
INFO - 2018-08-14 13:59:57 --> Loader Class Initialized
INFO - 2018-08-14 13:59:57 --> Helper loaded: url_helper
INFO - 2018-08-14 13:59:57 --> Helper loaded: file_helper
INFO - 2018-08-14 13:59:57 --> Helper loaded: form_helper
INFO - 2018-08-14 13:59:57 --> Helper loaded: my_helper
INFO - 2018-08-14 13:59:57 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:59:58 --> Controller Class Initialized
DEBUG - 2018-08-14 13:59:58 --> File loaded: D:\laragon\www\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2018-08-14 13:59:58 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 13:59:58 --> Final output sent to browser
DEBUG - 2018-08-14 13:59:58 --> Total execution time: 0.4471
INFO - 2018-08-14 13:59:58 --> Config Class Initialized
INFO - 2018-08-14 13:59:58 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:59:58 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:59:58 --> Utf8 Class Initialized
INFO - 2018-08-14 13:59:58 --> URI Class Initialized
INFO - 2018-08-14 13:59:58 --> Router Class Initialized
INFO - 2018-08-14 13:59:58 --> Output Class Initialized
INFO - 2018-08-14 13:59:58 --> Security Class Initialized
DEBUG - 2018-08-14 13:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:59:58 --> Input Class Initialized
INFO - 2018-08-14 13:59:58 --> Language Class Initialized
ERROR - 2018-08-14 13:59:58 --> 404 Page Not Found: /index
INFO - 2018-08-14 13:59:58 --> Config Class Initialized
INFO - 2018-08-14 13:59:58 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:59:58 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:59:58 --> Utf8 Class Initialized
INFO - 2018-08-14 13:59:58 --> URI Class Initialized
INFO - 2018-08-14 13:59:58 --> Router Class Initialized
INFO - 2018-08-14 13:59:58 --> Output Class Initialized
INFO - 2018-08-14 13:59:58 --> Security Class Initialized
DEBUG - 2018-08-14 13:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:59:58 --> Input Class Initialized
INFO - 2018-08-14 13:59:58 --> Language Class Initialized
INFO - 2018-08-14 13:59:58 --> Language Class Initialized
INFO - 2018-08-14 13:59:58 --> Config Class Initialized
INFO - 2018-08-14 13:59:58 --> Loader Class Initialized
INFO - 2018-08-14 13:59:58 --> Helper loaded: url_helper
INFO - 2018-08-14 13:59:58 --> Helper loaded: file_helper
INFO - 2018-08-14 13:59:58 --> Helper loaded: form_helper
INFO - 2018-08-14 13:59:58 --> Helper loaded: my_helper
INFO - 2018-08-14 13:59:58 --> Database Driver Class Initialized
DEBUG - 2018-08-14 13:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:59:58 --> Controller Class Initialized
INFO - 2018-08-14 14:00:00 --> Config Class Initialized
INFO - 2018-08-14 14:00:00 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:00:00 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:00:00 --> Utf8 Class Initialized
INFO - 2018-08-14 14:00:00 --> URI Class Initialized
INFO - 2018-08-14 14:00:00 --> Router Class Initialized
INFO - 2018-08-14 14:00:00 --> Output Class Initialized
INFO - 2018-08-14 14:00:00 --> Security Class Initialized
DEBUG - 2018-08-14 14:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:00:00 --> Input Class Initialized
INFO - 2018-08-14 14:00:01 --> Language Class Initialized
INFO - 2018-08-14 14:00:01 --> Language Class Initialized
INFO - 2018-08-14 14:00:01 --> Config Class Initialized
INFO - 2018-08-14 14:00:01 --> Loader Class Initialized
INFO - 2018-08-14 14:00:01 --> Helper loaded: url_helper
INFO - 2018-08-14 14:00:01 --> Helper loaded: file_helper
INFO - 2018-08-14 14:00:01 --> Helper loaded: form_helper
INFO - 2018-08-14 14:00:01 --> Helper loaded: my_helper
INFO - 2018-08-14 14:00:01 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:00:01 --> Controller Class Initialized
INFO - 2018-08-14 14:00:03 --> Config Class Initialized
INFO - 2018-08-14 14:00:03 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:00:03 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:00:03 --> Utf8 Class Initialized
INFO - 2018-08-14 14:00:03 --> URI Class Initialized
INFO - 2018-08-14 14:00:03 --> Router Class Initialized
INFO - 2018-08-14 14:00:03 --> Output Class Initialized
INFO - 2018-08-14 14:00:03 --> Security Class Initialized
DEBUG - 2018-08-14 14:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:00:03 --> Input Class Initialized
INFO - 2018-08-14 14:00:03 --> Language Class Initialized
INFO - 2018-08-14 14:00:03 --> Language Class Initialized
INFO - 2018-08-14 14:00:03 --> Config Class Initialized
INFO - 2018-08-14 14:00:03 --> Loader Class Initialized
INFO - 2018-08-14 14:00:03 --> Helper loaded: url_helper
INFO - 2018-08-14 14:00:03 --> Helper loaded: file_helper
INFO - 2018-08-14 14:00:03 --> Helper loaded: form_helper
INFO - 2018-08-14 14:00:03 --> Helper loaded: my_helper
INFO - 2018-08-14 14:00:04 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:00:04 --> Controller Class Initialized
DEBUG - 2018-08-14 14:00:04 --> File loaded: D:\laragon\www\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2018-08-14 14:00:04 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:00:04 --> Final output sent to browser
DEBUG - 2018-08-14 14:00:04 --> Total execution time: 0.4914
INFO - 2018-08-14 14:00:04 --> Config Class Initialized
INFO - 2018-08-14 14:00:04 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:00:04 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:00:04 --> Utf8 Class Initialized
INFO - 2018-08-14 14:00:04 --> URI Class Initialized
INFO - 2018-08-14 14:00:04 --> Router Class Initialized
INFO - 2018-08-14 14:00:04 --> Output Class Initialized
INFO - 2018-08-14 14:00:04 --> Security Class Initialized
DEBUG - 2018-08-14 14:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:00:04 --> Input Class Initialized
INFO - 2018-08-14 14:00:04 --> Language Class Initialized
ERROR - 2018-08-14 14:00:04 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:00:11 --> Config Class Initialized
INFO - 2018-08-14 14:00:11 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:00:11 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:00:11 --> Utf8 Class Initialized
INFO - 2018-08-14 14:00:11 --> URI Class Initialized
INFO - 2018-08-14 14:00:11 --> Router Class Initialized
INFO - 2018-08-14 14:00:11 --> Output Class Initialized
INFO - 2018-08-14 14:00:11 --> Security Class Initialized
DEBUG - 2018-08-14 14:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:00:11 --> Input Class Initialized
INFO - 2018-08-14 14:00:11 --> Language Class Initialized
INFO - 2018-08-14 14:00:11 --> Language Class Initialized
INFO - 2018-08-14 14:00:11 --> Config Class Initialized
INFO - 2018-08-14 14:00:11 --> Loader Class Initialized
INFO - 2018-08-14 14:00:11 --> Helper loaded: url_helper
INFO - 2018-08-14 14:00:11 --> Helper loaded: file_helper
INFO - 2018-08-14 14:00:11 --> Helper loaded: form_helper
INFO - 2018-08-14 14:00:11 --> Helper loaded: my_helper
INFO - 2018-08-14 14:00:11 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:00:11 --> Controller Class Initialized
INFO - 2018-08-14 14:00:12 --> Config Class Initialized
INFO - 2018-08-14 14:00:12 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:00:12 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:00:12 --> Utf8 Class Initialized
INFO - 2018-08-14 14:00:12 --> URI Class Initialized
INFO - 2018-08-14 14:00:12 --> Router Class Initialized
INFO - 2018-08-14 14:00:12 --> Output Class Initialized
INFO - 2018-08-14 14:00:12 --> Security Class Initialized
DEBUG - 2018-08-14 14:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:00:13 --> Input Class Initialized
INFO - 2018-08-14 14:00:13 --> Language Class Initialized
INFO - 2018-08-14 14:00:13 --> Language Class Initialized
INFO - 2018-08-14 14:00:13 --> Config Class Initialized
INFO - 2018-08-14 14:00:13 --> Loader Class Initialized
INFO - 2018-08-14 14:00:13 --> Helper loaded: url_helper
INFO - 2018-08-14 14:00:13 --> Helper loaded: file_helper
INFO - 2018-08-14 14:00:13 --> Helper loaded: form_helper
INFO - 2018-08-14 14:00:13 --> Helper loaded: my_helper
INFO - 2018-08-14 14:00:13 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:00:13 --> Controller Class Initialized
DEBUG - 2018-08-14 14:00:13 --> File loaded: D:\laragon\www\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2018-08-14 14:00:13 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:00:13 --> Final output sent to browser
DEBUG - 2018-08-14 14:00:13 --> Total execution time: 0.9810
INFO - 2018-08-14 14:00:13 --> Config Class Initialized
INFO - 2018-08-14 14:00:13 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:00:13 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:00:13 --> Utf8 Class Initialized
INFO - 2018-08-14 14:00:13 --> URI Class Initialized
INFO - 2018-08-14 14:00:13 --> Router Class Initialized
INFO - 2018-08-14 14:00:13 --> Output Class Initialized
INFO - 2018-08-14 14:00:13 --> Security Class Initialized
DEBUG - 2018-08-14 14:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:00:13 --> Input Class Initialized
INFO - 2018-08-14 14:00:13 --> Language Class Initialized
ERROR - 2018-08-14 14:00:13 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:00:14 --> Config Class Initialized
INFO - 2018-08-14 14:00:14 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:00:14 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:00:14 --> Utf8 Class Initialized
INFO - 2018-08-14 14:00:14 --> URI Class Initialized
INFO - 2018-08-14 14:00:14 --> Router Class Initialized
INFO - 2018-08-14 14:00:14 --> Output Class Initialized
INFO - 2018-08-14 14:00:14 --> Security Class Initialized
DEBUG - 2018-08-14 14:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:00:14 --> Input Class Initialized
INFO - 2018-08-14 14:00:14 --> Language Class Initialized
INFO - 2018-08-14 14:00:14 --> Language Class Initialized
INFO - 2018-08-14 14:00:14 --> Config Class Initialized
INFO - 2018-08-14 14:00:14 --> Loader Class Initialized
INFO - 2018-08-14 14:00:14 --> Helper loaded: url_helper
INFO - 2018-08-14 14:00:14 --> Helper loaded: file_helper
INFO - 2018-08-14 14:00:14 --> Helper loaded: form_helper
INFO - 2018-08-14 14:00:14 --> Helper loaded: my_helper
INFO - 2018-08-14 14:00:14 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:00:14 --> Controller Class Initialized
INFO - 2018-08-14 14:00:14 --> Config Class Initialized
INFO - 2018-08-14 14:00:14 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:00:14 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:00:14 --> Utf8 Class Initialized
INFO - 2018-08-14 14:00:14 --> URI Class Initialized
INFO - 2018-08-14 14:00:14 --> Router Class Initialized
INFO - 2018-08-14 14:00:15 --> Output Class Initialized
INFO - 2018-08-14 14:00:15 --> Security Class Initialized
DEBUG - 2018-08-14 14:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:00:15 --> Input Class Initialized
INFO - 2018-08-14 14:00:15 --> Language Class Initialized
INFO - 2018-08-14 14:00:15 --> Language Class Initialized
INFO - 2018-08-14 14:00:15 --> Config Class Initialized
INFO - 2018-08-14 14:00:15 --> Loader Class Initialized
INFO - 2018-08-14 14:00:15 --> Helper loaded: url_helper
INFO - 2018-08-14 14:00:15 --> Helper loaded: file_helper
INFO - 2018-08-14 14:00:15 --> Helper loaded: form_helper
INFO - 2018-08-14 14:00:15 --> Helper loaded: my_helper
INFO - 2018-08-14 14:00:15 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:00:15 --> Controller Class Initialized
DEBUG - 2018-08-14 14:00:15 --> File loaded: D:\laragon\www\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2018-08-14 14:00:15 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:00:15 --> Final output sent to browser
DEBUG - 2018-08-14 14:00:15 --> Total execution time: 0.4239
INFO - 2018-08-14 14:00:15 --> Config Class Initialized
INFO - 2018-08-14 14:00:15 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:00:15 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:00:15 --> Utf8 Class Initialized
INFO - 2018-08-14 14:00:15 --> URI Class Initialized
INFO - 2018-08-14 14:00:15 --> Router Class Initialized
INFO - 2018-08-14 14:00:15 --> Output Class Initialized
INFO - 2018-08-14 14:00:15 --> Security Class Initialized
DEBUG - 2018-08-14 14:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:00:15 --> Input Class Initialized
INFO - 2018-08-14 14:00:15 --> Language Class Initialized
ERROR - 2018-08-14 14:00:15 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:00:25 --> Config Class Initialized
INFO - 2018-08-14 14:00:25 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:00:25 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:00:25 --> Utf8 Class Initialized
INFO - 2018-08-14 14:00:25 --> URI Class Initialized
INFO - 2018-08-14 14:00:25 --> Router Class Initialized
INFO - 2018-08-14 14:00:25 --> Output Class Initialized
INFO - 2018-08-14 14:00:25 --> Security Class Initialized
DEBUG - 2018-08-14 14:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:00:25 --> Input Class Initialized
INFO - 2018-08-14 14:00:25 --> Language Class Initialized
INFO - 2018-08-14 14:00:25 --> Language Class Initialized
INFO - 2018-08-14 14:00:25 --> Config Class Initialized
INFO - 2018-08-14 14:00:25 --> Loader Class Initialized
INFO - 2018-08-14 14:00:25 --> Helper loaded: url_helper
INFO - 2018-08-14 14:00:25 --> Helper loaded: file_helper
INFO - 2018-08-14 14:00:25 --> Helper loaded: form_helper
INFO - 2018-08-14 14:00:26 --> Helper loaded: my_helper
INFO - 2018-08-14 14:00:26 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:00:26 --> Controller Class Initialized
INFO - 2018-08-14 14:00:26 --> Config Class Initialized
INFO - 2018-08-14 14:00:26 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:00:26 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:00:26 --> Utf8 Class Initialized
INFO - 2018-08-14 14:00:26 --> URI Class Initialized
INFO - 2018-08-14 14:00:26 --> Router Class Initialized
INFO - 2018-08-14 14:00:26 --> Output Class Initialized
INFO - 2018-08-14 14:00:26 --> Security Class Initialized
DEBUG - 2018-08-14 14:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:00:26 --> Input Class Initialized
INFO - 2018-08-14 14:00:26 --> Language Class Initialized
INFO - 2018-08-14 14:00:26 --> Language Class Initialized
INFO - 2018-08-14 14:00:26 --> Config Class Initialized
INFO - 2018-08-14 14:00:26 --> Loader Class Initialized
INFO - 2018-08-14 14:00:26 --> Helper loaded: url_helper
INFO - 2018-08-14 14:00:26 --> Helper loaded: file_helper
INFO - 2018-08-14 14:00:26 --> Helper loaded: form_helper
INFO - 2018-08-14 14:00:26 --> Helper loaded: my_helper
INFO - 2018-08-14 14:00:26 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:00:26 --> Controller Class Initialized
DEBUG - 2018-08-14 14:00:27 --> File loaded: D:\laragon\www\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2018-08-14 14:00:27 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:00:27 --> Final output sent to browser
DEBUG - 2018-08-14 14:00:27 --> Total execution time: 0.8945
INFO - 2018-08-14 14:00:27 --> Config Class Initialized
INFO - 2018-08-14 14:00:27 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:00:27 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:00:27 --> Utf8 Class Initialized
INFO - 2018-08-14 14:00:27 --> URI Class Initialized
INFO - 2018-08-14 14:00:27 --> Router Class Initialized
INFO - 2018-08-14 14:00:27 --> Output Class Initialized
INFO - 2018-08-14 14:00:27 --> Security Class Initialized
DEBUG - 2018-08-14 14:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:00:27 --> Input Class Initialized
INFO - 2018-08-14 14:00:27 --> Language Class Initialized
ERROR - 2018-08-14 14:00:27 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:00:27 --> Config Class Initialized
INFO - 2018-08-14 14:00:27 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:00:27 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:00:27 --> Utf8 Class Initialized
INFO - 2018-08-14 14:00:27 --> URI Class Initialized
INFO - 2018-08-14 14:00:27 --> Router Class Initialized
INFO - 2018-08-14 14:00:27 --> Output Class Initialized
INFO - 2018-08-14 14:00:27 --> Security Class Initialized
DEBUG - 2018-08-14 14:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:00:27 --> Input Class Initialized
INFO - 2018-08-14 14:00:27 --> Language Class Initialized
INFO - 2018-08-14 14:00:27 --> Language Class Initialized
INFO - 2018-08-14 14:00:28 --> Config Class Initialized
INFO - 2018-08-14 14:00:28 --> Loader Class Initialized
INFO - 2018-08-14 14:00:28 --> Helper loaded: url_helper
INFO - 2018-08-14 14:00:28 --> Helper loaded: file_helper
INFO - 2018-08-14 14:00:28 --> Helper loaded: form_helper
INFO - 2018-08-14 14:00:28 --> Helper loaded: my_helper
INFO - 2018-08-14 14:00:28 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:00:28 --> Controller Class Initialized
INFO - 2018-08-14 14:00:31 --> Config Class Initialized
INFO - 2018-08-14 14:00:31 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:00:31 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:00:31 --> Utf8 Class Initialized
INFO - 2018-08-14 14:00:31 --> URI Class Initialized
INFO - 2018-08-14 14:00:31 --> Router Class Initialized
INFO - 2018-08-14 14:00:31 --> Output Class Initialized
INFO - 2018-08-14 14:00:31 --> Security Class Initialized
DEBUG - 2018-08-14 14:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:00:31 --> Input Class Initialized
INFO - 2018-08-14 14:00:31 --> Language Class Initialized
INFO - 2018-08-14 14:00:31 --> Language Class Initialized
INFO - 2018-08-14 14:00:31 --> Config Class Initialized
INFO - 2018-08-14 14:00:31 --> Loader Class Initialized
INFO - 2018-08-14 14:00:31 --> Helper loaded: url_helper
INFO - 2018-08-14 14:00:31 --> Helper loaded: file_helper
INFO - 2018-08-14 14:00:31 --> Helper loaded: form_helper
INFO - 2018-08-14 14:00:31 --> Helper loaded: my_helper
INFO - 2018-08-14 14:00:31 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:00:31 --> Controller Class Initialized
INFO - 2018-08-14 14:00:32 --> Config Class Initialized
INFO - 2018-08-14 14:00:32 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:00:32 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:00:32 --> Utf8 Class Initialized
INFO - 2018-08-14 14:00:32 --> URI Class Initialized
INFO - 2018-08-14 14:00:32 --> Router Class Initialized
INFO - 2018-08-14 14:00:32 --> Output Class Initialized
INFO - 2018-08-14 14:00:32 --> Security Class Initialized
DEBUG - 2018-08-14 14:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:00:32 --> Input Class Initialized
INFO - 2018-08-14 14:00:32 --> Language Class Initialized
INFO - 2018-08-14 14:00:32 --> Language Class Initialized
INFO - 2018-08-14 14:00:32 --> Config Class Initialized
INFO - 2018-08-14 14:00:32 --> Loader Class Initialized
INFO - 2018-08-14 14:00:32 --> Helper loaded: url_helper
INFO - 2018-08-14 14:00:32 --> Helper loaded: file_helper
INFO - 2018-08-14 14:00:32 --> Helper loaded: form_helper
INFO - 2018-08-14 14:00:32 --> Helper loaded: my_helper
INFO - 2018-08-14 14:00:32 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:00:32 --> Controller Class Initialized
INFO - 2018-08-14 14:00:33 --> Config Class Initialized
INFO - 2018-08-14 14:00:33 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:00:33 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:00:33 --> Utf8 Class Initialized
INFO - 2018-08-14 14:00:33 --> URI Class Initialized
INFO - 2018-08-14 14:00:33 --> Router Class Initialized
INFO - 2018-08-14 14:00:33 --> Output Class Initialized
INFO - 2018-08-14 14:00:33 --> Security Class Initialized
DEBUG - 2018-08-14 14:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:00:33 --> Input Class Initialized
INFO - 2018-08-14 14:00:33 --> Language Class Initialized
INFO - 2018-08-14 14:00:33 --> Language Class Initialized
INFO - 2018-08-14 14:00:33 --> Config Class Initialized
INFO - 2018-08-14 14:00:33 --> Loader Class Initialized
INFO - 2018-08-14 14:00:33 --> Helper loaded: url_helper
INFO - 2018-08-14 14:00:33 --> Helper loaded: file_helper
INFO - 2018-08-14 14:00:33 --> Helper loaded: form_helper
INFO - 2018-08-14 14:00:33 --> Helper loaded: my_helper
INFO - 2018-08-14 14:00:33 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:00:33 --> Controller Class Initialized
INFO - 2018-08-14 14:00:36 --> Config Class Initialized
INFO - 2018-08-14 14:00:36 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:00:36 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:00:36 --> Utf8 Class Initialized
INFO - 2018-08-14 14:00:36 --> URI Class Initialized
INFO - 2018-08-14 14:00:36 --> Router Class Initialized
INFO - 2018-08-14 14:00:36 --> Output Class Initialized
INFO - 2018-08-14 14:00:36 --> Security Class Initialized
DEBUG - 2018-08-14 14:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:00:36 --> Input Class Initialized
INFO - 2018-08-14 14:00:36 --> Language Class Initialized
INFO - 2018-08-14 14:00:36 --> Language Class Initialized
INFO - 2018-08-14 14:00:36 --> Config Class Initialized
INFO - 2018-08-14 14:00:36 --> Loader Class Initialized
INFO - 2018-08-14 14:00:36 --> Helper loaded: url_helper
INFO - 2018-08-14 14:00:36 --> Helper loaded: file_helper
INFO - 2018-08-14 14:00:36 --> Helper loaded: form_helper
INFO - 2018-08-14 14:00:36 --> Helper loaded: my_helper
INFO - 2018-08-14 14:00:36 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:00:36 --> Controller Class Initialized
DEBUG - 2018-08-14 14:00:36 --> File loaded: D:\laragon\www\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2018-08-14 14:00:36 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:00:36 --> Final output sent to browser
DEBUG - 2018-08-14 14:00:36 --> Total execution time: 0.4651
INFO - 2018-08-14 14:00:36 --> Config Class Initialized
INFO - 2018-08-14 14:00:36 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:00:36 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:00:36 --> Utf8 Class Initialized
INFO - 2018-08-14 14:00:36 --> URI Class Initialized
INFO - 2018-08-14 14:00:36 --> Router Class Initialized
INFO - 2018-08-14 14:00:37 --> Output Class Initialized
INFO - 2018-08-14 14:00:37 --> Security Class Initialized
DEBUG - 2018-08-14 14:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:00:37 --> Input Class Initialized
INFO - 2018-08-14 14:00:37 --> Language Class Initialized
ERROR - 2018-08-14 14:00:37 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:00:54 --> Config Class Initialized
INFO - 2018-08-14 14:00:54 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:00:54 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:00:54 --> Utf8 Class Initialized
INFO - 2018-08-14 14:00:54 --> URI Class Initialized
INFO - 2018-08-14 14:00:54 --> Router Class Initialized
INFO - 2018-08-14 14:00:54 --> Output Class Initialized
INFO - 2018-08-14 14:00:54 --> Security Class Initialized
DEBUG - 2018-08-14 14:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:00:54 --> Input Class Initialized
INFO - 2018-08-14 14:00:54 --> Language Class Initialized
INFO - 2018-08-14 14:00:54 --> Language Class Initialized
INFO - 2018-08-14 14:00:54 --> Config Class Initialized
INFO - 2018-08-14 14:00:54 --> Loader Class Initialized
INFO - 2018-08-14 14:00:54 --> Helper loaded: url_helper
INFO - 2018-08-14 14:00:55 --> Helper loaded: file_helper
INFO - 2018-08-14 14:00:55 --> Helper loaded: form_helper
INFO - 2018-08-14 14:00:55 --> Helper loaded: my_helper
INFO - 2018-08-14 14:00:55 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:00:55 --> Controller Class Initialized
INFO - 2018-08-14 14:00:55 --> Config Class Initialized
INFO - 2018-08-14 14:00:55 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:00:55 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:00:55 --> Utf8 Class Initialized
INFO - 2018-08-14 14:00:55 --> URI Class Initialized
INFO - 2018-08-14 14:00:55 --> Router Class Initialized
INFO - 2018-08-14 14:00:55 --> Output Class Initialized
INFO - 2018-08-14 14:00:55 --> Security Class Initialized
DEBUG - 2018-08-14 14:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:00:56 --> Input Class Initialized
INFO - 2018-08-14 14:00:56 --> Language Class Initialized
INFO - 2018-08-14 14:00:56 --> Language Class Initialized
INFO - 2018-08-14 14:00:56 --> Config Class Initialized
INFO - 2018-08-14 14:00:56 --> Loader Class Initialized
INFO - 2018-08-14 14:00:56 --> Helper loaded: url_helper
INFO - 2018-08-14 14:00:56 --> Helper loaded: file_helper
INFO - 2018-08-14 14:00:56 --> Helper loaded: form_helper
INFO - 2018-08-14 14:00:56 --> Helper loaded: my_helper
INFO - 2018-08-14 14:00:56 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:00:56 --> Controller Class Initialized
DEBUG - 2018-08-14 14:00:56 --> File loaded: D:\laragon\www\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2018-08-14 14:00:56 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:00:56 --> Final output sent to browser
DEBUG - 2018-08-14 14:00:56 --> Total execution time: 0.7887
INFO - 2018-08-14 14:00:56 --> Config Class Initialized
INFO - 2018-08-14 14:00:56 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:00:56 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:00:56 --> Utf8 Class Initialized
INFO - 2018-08-14 14:00:56 --> URI Class Initialized
INFO - 2018-08-14 14:00:56 --> Router Class Initialized
INFO - 2018-08-14 14:00:56 --> Output Class Initialized
INFO - 2018-08-14 14:00:56 --> Security Class Initialized
DEBUG - 2018-08-14 14:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:00:56 --> Input Class Initialized
INFO - 2018-08-14 14:00:56 --> Language Class Initialized
ERROR - 2018-08-14 14:00:56 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:00:56 --> Config Class Initialized
INFO - 2018-08-14 14:00:56 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:00:56 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:00:56 --> Utf8 Class Initialized
INFO - 2018-08-14 14:00:56 --> URI Class Initialized
INFO - 2018-08-14 14:00:56 --> Router Class Initialized
INFO - 2018-08-14 14:00:57 --> Output Class Initialized
INFO - 2018-08-14 14:00:57 --> Security Class Initialized
DEBUG - 2018-08-14 14:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:00:57 --> Input Class Initialized
INFO - 2018-08-14 14:00:57 --> Language Class Initialized
INFO - 2018-08-14 14:00:57 --> Language Class Initialized
INFO - 2018-08-14 14:00:57 --> Config Class Initialized
INFO - 2018-08-14 14:00:57 --> Loader Class Initialized
INFO - 2018-08-14 14:00:57 --> Helper loaded: url_helper
INFO - 2018-08-14 14:00:57 --> Helper loaded: file_helper
INFO - 2018-08-14 14:00:57 --> Helper loaded: form_helper
INFO - 2018-08-14 14:00:57 --> Helper loaded: my_helper
INFO - 2018-08-14 14:00:57 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:00:57 --> Controller Class Initialized
INFO - 2018-08-14 14:00:59 --> Config Class Initialized
INFO - 2018-08-14 14:00:59 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:00:59 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:00:59 --> Utf8 Class Initialized
INFO - 2018-08-14 14:00:59 --> URI Class Initialized
INFO - 2018-08-14 14:00:59 --> Router Class Initialized
INFO - 2018-08-14 14:00:59 --> Output Class Initialized
INFO - 2018-08-14 14:00:59 --> Security Class Initialized
DEBUG - 2018-08-14 14:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:00:59 --> Input Class Initialized
INFO - 2018-08-14 14:00:59 --> Language Class Initialized
INFO - 2018-08-14 14:00:59 --> Language Class Initialized
INFO - 2018-08-14 14:00:59 --> Config Class Initialized
INFO - 2018-08-14 14:00:59 --> Loader Class Initialized
INFO - 2018-08-14 14:00:59 --> Helper loaded: url_helper
INFO - 2018-08-14 14:00:59 --> Helper loaded: file_helper
INFO - 2018-08-14 14:00:59 --> Helper loaded: form_helper
INFO - 2018-08-14 14:00:59 --> Helper loaded: my_helper
INFO - 2018-08-14 14:00:59 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:01:00 --> Controller Class Initialized
DEBUG - 2018-08-14 14:01:00 --> File loaded: D:\laragon\www\nilai\application\modules/tahun/views/list.php
DEBUG - 2018-08-14 14:01:00 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:01:00 --> Final output sent to browser
DEBUG - 2018-08-14 14:01:00 --> Total execution time: 0.4994
INFO - 2018-08-14 14:01:00 --> Config Class Initialized
INFO - 2018-08-14 14:01:00 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:01:00 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:01:00 --> Utf8 Class Initialized
INFO - 2018-08-14 14:01:00 --> URI Class Initialized
INFO - 2018-08-14 14:01:00 --> Router Class Initialized
INFO - 2018-08-14 14:01:00 --> Output Class Initialized
INFO - 2018-08-14 14:01:00 --> Security Class Initialized
DEBUG - 2018-08-14 14:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:01:00 --> Input Class Initialized
INFO - 2018-08-14 14:01:00 --> Language Class Initialized
ERROR - 2018-08-14 14:01:00 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:01:00 --> Config Class Initialized
INFO - 2018-08-14 14:01:00 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:01:00 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:01:00 --> Utf8 Class Initialized
INFO - 2018-08-14 14:01:00 --> URI Class Initialized
INFO - 2018-08-14 14:01:00 --> Router Class Initialized
INFO - 2018-08-14 14:01:00 --> Output Class Initialized
INFO - 2018-08-14 14:01:00 --> Security Class Initialized
DEBUG - 2018-08-14 14:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:01:00 --> Input Class Initialized
INFO - 2018-08-14 14:01:00 --> Language Class Initialized
INFO - 2018-08-14 14:01:00 --> Language Class Initialized
INFO - 2018-08-14 14:01:00 --> Config Class Initialized
INFO - 2018-08-14 14:01:00 --> Loader Class Initialized
INFO - 2018-08-14 14:01:00 --> Helper loaded: url_helper
INFO - 2018-08-14 14:01:00 --> Helper loaded: file_helper
INFO - 2018-08-14 14:01:00 --> Helper loaded: form_helper
INFO - 2018-08-14 14:01:00 --> Helper loaded: my_helper
INFO - 2018-08-14 14:01:00 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:01:01 --> Controller Class Initialized
INFO - 2018-08-14 14:01:01 --> Config Class Initialized
INFO - 2018-08-14 14:01:01 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:01:01 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:01:01 --> Utf8 Class Initialized
INFO - 2018-08-14 14:01:01 --> URI Class Initialized
INFO - 2018-08-14 14:01:02 --> Router Class Initialized
INFO - 2018-08-14 14:01:02 --> Output Class Initialized
INFO - 2018-08-14 14:01:02 --> Security Class Initialized
DEBUG - 2018-08-14 14:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:01:02 --> Input Class Initialized
INFO - 2018-08-14 14:01:02 --> Language Class Initialized
INFO - 2018-08-14 14:01:02 --> Language Class Initialized
INFO - 2018-08-14 14:01:02 --> Config Class Initialized
INFO - 2018-08-14 14:01:02 --> Loader Class Initialized
INFO - 2018-08-14 14:01:02 --> Helper loaded: url_helper
INFO - 2018-08-14 14:01:02 --> Helper loaded: file_helper
INFO - 2018-08-14 14:01:02 --> Helper loaded: form_helper
INFO - 2018-08-14 14:01:02 --> Helper loaded: my_helper
INFO - 2018-08-14 14:01:02 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:01:02 --> Controller Class Initialized
DEBUG - 2018-08-14 14:01:02 --> File loaded: D:\laragon\www\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2018-08-14 14:01:02 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:01:02 --> Final output sent to browser
DEBUG - 2018-08-14 14:01:02 --> Total execution time: 0.6001
INFO - 2018-08-14 14:01:02 --> Config Class Initialized
INFO - 2018-08-14 14:01:02 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:01:02 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:01:02 --> Utf8 Class Initialized
INFO - 2018-08-14 14:01:02 --> URI Class Initialized
INFO - 2018-08-14 14:01:02 --> Router Class Initialized
INFO - 2018-08-14 14:01:02 --> Output Class Initialized
INFO - 2018-08-14 14:01:02 --> Security Class Initialized
DEBUG - 2018-08-14 14:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:01:02 --> Input Class Initialized
INFO - 2018-08-14 14:01:02 --> Language Class Initialized
ERROR - 2018-08-14 14:01:02 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:01:04 --> Config Class Initialized
INFO - 2018-08-14 14:01:04 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:01:04 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:01:04 --> Utf8 Class Initialized
INFO - 2018-08-14 14:01:04 --> URI Class Initialized
INFO - 2018-08-14 14:01:04 --> Router Class Initialized
INFO - 2018-08-14 14:01:04 --> Output Class Initialized
INFO - 2018-08-14 14:01:04 --> Security Class Initialized
DEBUG - 2018-08-14 14:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:01:04 --> Input Class Initialized
INFO - 2018-08-14 14:01:04 --> Language Class Initialized
INFO - 2018-08-14 14:01:04 --> Language Class Initialized
INFO - 2018-08-14 14:01:04 --> Config Class Initialized
INFO - 2018-08-14 14:01:04 --> Loader Class Initialized
INFO - 2018-08-14 14:01:04 --> Helper loaded: url_helper
INFO - 2018-08-14 14:01:04 --> Helper loaded: file_helper
INFO - 2018-08-14 14:01:04 --> Helper loaded: form_helper
INFO - 2018-08-14 14:01:04 --> Helper loaded: my_helper
INFO - 2018-08-14 14:01:04 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:01:05 --> Controller Class Initialized
DEBUG - 2018-08-14 14:01:05 --> File loaded: D:\laragon\www\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2018-08-14 14:01:05 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:01:05 --> Final output sent to browser
DEBUG - 2018-08-14 14:01:05 --> Total execution time: 0.5304
INFO - 2018-08-14 14:01:05 --> Config Class Initialized
INFO - 2018-08-14 14:01:05 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:01:05 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:01:05 --> Utf8 Class Initialized
INFO - 2018-08-14 14:01:05 --> URI Class Initialized
INFO - 2018-08-14 14:01:05 --> Router Class Initialized
INFO - 2018-08-14 14:01:05 --> Output Class Initialized
INFO - 2018-08-14 14:01:05 --> Security Class Initialized
DEBUG - 2018-08-14 14:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:01:05 --> Input Class Initialized
INFO - 2018-08-14 14:01:05 --> Language Class Initialized
ERROR - 2018-08-14 14:01:05 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:01:05 --> Config Class Initialized
INFO - 2018-08-14 14:01:05 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:01:05 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:01:05 --> Utf8 Class Initialized
INFO - 2018-08-14 14:01:05 --> URI Class Initialized
INFO - 2018-08-14 14:01:05 --> Router Class Initialized
INFO - 2018-08-14 14:01:05 --> Output Class Initialized
INFO - 2018-08-14 14:01:05 --> Security Class Initialized
DEBUG - 2018-08-14 14:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:01:05 --> Input Class Initialized
INFO - 2018-08-14 14:01:05 --> Language Class Initialized
INFO - 2018-08-14 14:01:05 --> Language Class Initialized
INFO - 2018-08-14 14:01:05 --> Config Class Initialized
INFO - 2018-08-14 14:01:05 --> Loader Class Initialized
INFO - 2018-08-14 14:01:05 --> Helper loaded: url_helper
INFO - 2018-08-14 14:01:05 --> Helper loaded: file_helper
INFO - 2018-08-14 14:01:05 --> Helper loaded: form_helper
INFO - 2018-08-14 14:01:05 --> Helper loaded: my_helper
INFO - 2018-08-14 14:01:05 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:01:06 --> Controller Class Initialized
INFO - 2018-08-14 14:01:08 --> Config Class Initialized
INFO - 2018-08-14 14:01:08 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:01:08 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:01:08 --> Utf8 Class Initialized
INFO - 2018-08-14 14:01:08 --> URI Class Initialized
INFO - 2018-08-14 14:01:08 --> Router Class Initialized
INFO - 2018-08-14 14:01:08 --> Output Class Initialized
INFO - 2018-08-14 14:01:08 --> Security Class Initialized
DEBUG - 2018-08-14 14:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:01:08 --> Input Class Initialized
INFO - 2018-08-14 14:01:08 --> Language Class Initialized
INFO - 2018-08-14 14:01:08 --> Language Class Initialized
INFO - 2018-08-14 14:01:08 --> Config Class Initialized
INFO - 2018-08-14 14:01:08 --> Loader Class Initialized
INFO - 2018-08-14 14:01:08 --> Helper loaded: url_helper
INFO - 2018-08-14 14:01:08 --> Helper loaded: file_helper
INFO - 2018-08-14 14:01:08 --> Helper loaded: form_helper
INFO - 2018-08-14 14:01:08 --> Helper loaded: my_helper
INFO - 2018-08-14 14:01:08 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:01:08 --> Controller Class Initialized
DEBUG - 2018-08-14 14:01:08 --> File loaded: D:\laragon\www\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2018-08-14 14:01:08 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:01:08 --> Final output sent to browser
DEBUG - 2018-08-14 14:01:08 --> Total execution time: 0.4627
INFO - 2018-08-14 14:01:08 --> Config Class Initialized
INFO - 2018-08-14 14:01:08 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:01:09 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:01:09 --> Utf8 Class Initialized
INFO - 2018-08-14 14:01:09 --> URI Class Initialized
INFO - 2018-08-14 14:01:09 --> Router Class Initialized
INFO - 2018-08-14 14:01:09 --> Output Class Initialized
INFO - 2018-08-14 14:01:09 --> Security Class Initialized
DEBUG - 2018-08-14 14:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:01:09 --> Input Class Initialized
INFO - 2018-08-14 14:01:09 --> Language Class Initialized
ERROR - 2018-08-14 14:01:09 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:01:09 --> Config Class Initialized
INFO - 2018-08-14 14:01:09 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:01:09 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:01:09 --> Utf8 Class Initialized
INFO - 2018-08-14 14:01:09 --> URI Class Initialized
INFO - 2018-08-14 14:01:09 --> Router Class Initialized
INFO - 2018-08-14 14:01:09 --> Output Class Initialized
INFO - 2018-08-14 14:01:09 --> Security Class Initialized
DEBUG - 2018-08-14 14:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:01:09 --> Input Class Initialized
INFO - 2018-08-14 14:01:09 --> Language Class Initialized
INFO - 2018-08-14 14:01:09 --> Language Class Initialized
INFO - 2018-08-14 14:01:09 --> Config Class Initialized
INFO - 2018-08-14 14:01:09 --> Loader Class Initialized
INFO - 2018-08-14 14:01:09 --> Helper loaded: url_helper
INFO - 2018-08-14 14:01:09 --> Helper loaded: file_helper
INFO - 2018-08-14 14:01:09 --> Helper loaded: form_helper
INFO - 2018-08-14 14:01:09 --> Helper loaded: my_helper
INFO - 2018-08-14 14:01:09 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:01:09 --> Controller Class Initialized
INFO - 2018-08-14 14:01:10 --> Config Class Initialized
INFO - 2018-08-14 14:01:10 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:01:10 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:01:10 --> Utf8 Class Initialized
INFO - 2018-08-14 14:01:10 --> URI Class Initialized
INFO - 2018-08-14 14:01:10 --> Router Class Initialized
INFO - 2018-08-14 14:01:10 --> Output Class Initialized
INFO - 2018-08-14 14:01:10 --> Security Class Initialized
DEBUG - 2018-08-14 14:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:01:10 --> Input Class Initialized
INFO - 2018-08-14 14:01:10 --> Language Class Initialized
INFO - 2018-08-14 14:01:10 --> Language Class Initialized
INFO - 2018-08-14 14:01:10 --> Config Class Initialized
INFO - 2018-08-14 14:01:10 --> Loader Class Initialized
INFO - 2018-08-14 14:01:10 --> Helper loaded: url_helper
INFO - 2018-08-14 14:01:10 --> Helper loaded: file_helper
INFO - 2018-08-14 14:01:10 --> Helper loaded: form_helper
INFO - 2018-08-14 14:01:10 --> Helper loaded: my_helper
INFO - 2018-08-14 14:01:10 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:01:10 --> Controller Class Initialized
INFO - 2018-08-14 14:01:10 --> Final output sent to browser
DEBUG - 2018-08-14 14:01:10 --> Total execution time: 0.4663
INFO - 2018-08-14 14:01:14 --> Config Class Initialized
INFO - 2018-08-14 14:01:14 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:01:14 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:01:14 --> Utf8 Class Initialized
INFO - 2018-08-14 14:01:14 --> URI Class Initialized
INFO - 2018-08-14 14:01:14 --> Router Class Initialized
INFO - 2018-08-14 14:01:14 --> Output Class Initialized
INFO - 2018-08-14 14:01:14 --> Security Class Initialized
DEBUG - 2018-08-14 14:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:01:14 --> Input Class Initialized
INFO - 2018-08-14 14:01:14 --> Language Class Initialized
INFO - 2018-08-14 14:01:14 --> Language Class Initialized
INFO - 2018-08-14 14:01:14 --> Config Class Initialized
INFO - 2018-08-14 14:01:14 --> Loader Class Initialized
INFO - 2018-08-14 14:01:14 --> Helper loaded: url_helper
INFO - 2018-08-14 14:01:14 --> Helper loaded: file_helper
INFO - 2018-08-14 14:01:14 --> Helper loaded: form_helper
INFO - 2018-08-14 14:01:14 --> Helper loaded: my_helper
INFO - 2018-08-14 14:01:14 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:01:14 --> Controller Class Initialized
INFO - 2018-08-14 14:01:14 --> Final output sent to browser
DEBUG - 2018-08-14 14:01:14 --> Total execution time: 0.4548
INFO - 2018-08-14 14:01:14 --> Config Class Initialized
INFO - 2018-08-14 14:01:14 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:01:14 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:01:15 --> Utf8 Class Initialized
INFO - 2018-08-14 14:01:15 --> URI Class Initialized
INFO - 2018-08-14 14:01:15 --> Router Class Initialized
INFO - 2018-08-14 14:01:15 --> Output Class Initialized
INFO - 2018-08-14 14:01:15 --> Security Class Initialized
DEBUG - 2018-08-14 14:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:01:15 --> Input Class Initialized
INFO - 2018-08-14 14:01:15 --> Language Class Initialized
INFO - 2018-08-14 14:01:15 --> Language Class Initialized
INFO - 2018-08-14 14:01:15 --> Config Class Initialized
INFO - 2018-08-14 14:01:15 --> Loader Class Initialized
INFO - 2018-08-14 14:01:15 --> Helper loaded: url_helper
INFO - 2018-08-14 14:01:15 --> Helper loaded: file_helper
INFO - 2018-08-14 14:01:15 --> Helper loaded: form_helper
INFO - 2018-08-14 14:01:15 --> Helper loaded: my_helper
INFO - 2018-08-14 14:01:15 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:01:15 --> Controller Class Initialized
INFO - 2018-08-14 14:01:16 --> Config Class Initialized
INFO - 2018-08-14 14:01:16 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:01:16 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:01:16 --> Utf8 Class Initialized
INFO - 2018-08-14 14:01:16 --> URI Class Initialized
INFO - 2018-08-14 14:01:16 --> Router Class Initialized
INFO - 2018-08-14 14:01:16 --> Output Class Initialized
INFO - 2018-08-14 14:01:16 --> Security Class Initialized
DEBUG - 2018-08-14 14:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:01:16 --> Input Class Initialized
INFO - 2018-08-14 14:01:16 --> Language Class Initialized
INFO - 2018-08-14 14:01:16 --> Language Class Initialized
INFO - 2018-08-14 14:01:16 --> Config Class Initialized
INFO - 2018-08-14 14:01:16 --> Loader Class Initialized
INFO - 2018-08-14 14:01:16 --> Helper loaded: url_helper
INFO - 2018-08-14 14:01:16 --> Helper loaded: file_helper
INFO - 2018-08-14 14:01:16 --> Helper loaded: form_helper
INFO - 2018-08-14 14:01:16 --> Helper loaded: my_helper
INFO - 2018-08-14 14:01:16 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:01:16 --> Controller Class Initialized
INFO - 2018-08-14 14:01:16 --> Final output sent to browser
DEBUG - 2018-08-14 14:01:16 --> Total execution time: 0.5240
INFO - 2018-08-14 14:01:20 --> Config Class Initialized
INFO - 2018-08-14 14:01:20 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:01:20 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:01:20 --> Utf8 Class Initialized
INFO - 2018-08-14 14:01:21 --> URI Class Initialized
INFO - 2018-08-14 14:01:21 --> Router Class Initialized
INFO - 2018-08-14 14:01:21 --> Output Class Initialized
INFO - 2018-08-14 14:01:21 --> Security Class Initialized
DEBUG - 2018-08-14 14:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:01:21 --> Input Class Initialized
INFO - 2018-08-14 14:01:21 --> Language Class Initialized
INFO - 2018-08-14 14:01:21 --> Language Class Initialized
INFO - 2018-08-14 14:01:21 --> Config Class Initialized
INFO - 2018-08-14 14:01:21 --> Loader Class Initialized
INFO - 2018-08-14 14:01:21 --> Helper loaded: url_helper
INFO - 2018-08-14 14:01:21 --> Helper loaded: file_helper
INFO - 2018-08-14 14:01:21 --> Helper loaded: form_helper
INFO - 2018-08-14 14:01:21 --> Helper loaded: my_helper
INFO - 2018-08-14 14:01:21 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:01:21 --> Controller Class Initialized
INFO - 2018-08-14 14:01:21 --> Final output sent to browser
DEBUG - 2018-08-14 14:01:21 --> Total execution time: 0.4749
INFO - 2018-08-14 14:01:21 --> Config Class Initialized
INFO - 2018-08-14 14:01:21 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:01:21 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:01:21 --> Utf8 Class Initialized
INFO - 2018-08-14 14:01:21 --> URI Class Initialized
INFO - 2018-08-14 14:01:21 --> Router Class Initialized
INFO - 2018-08-14 14:01:21 --> Output Class Initialized
INFO - 2018-08-14 14:01:21 --> Security Class Initialized
DEBUG - 2018-08-14 14:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:01:21 --> Input Class Initialized
INFO - 2018-08-14 14:01:21 --> Language Class Initialized
INFO - 2018-08-14 14:01:21 --> Language Class Initialized
INFO - 2018-08-14 14:01:21 --> Config Class Initialized
INFO - 2018-08-14 14:01:21 --> Loader Class Initialized
INFO - 2018-08-14 14:01:21 --> Helper loaded: url_helper
INFO - 2018-08-14 14:01:21 --> Helper loaded: file_helper
INFO - 2018-08-14 14:01:21 --> Helper loaded: form_helper
INFO - 2018-08-14 14:01:21 --> Helper loaded: my_helper
INFO - 2018-08-14 14:01:21 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:01:21 --> Controller Class Initialized
INFO - 2018-08-14 14:01:22 --> Config Class Initialized
INFO - 2018-08-14 14:01:22 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:01:22 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:01:22 --> Utf8 Class Initialized
INFO - 2018-08-14 14:01:22 --> URI Class Initialized
INFO - 2018-08-14 14:01:22 --> Router Class Initialized
INFO - 2018-08-14 14:01:22 --> Output Class Initialized
INFO - 2018-08-14 14:01:22 --> Security Class Initialized
DEBUG - 2018-08-14 14:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:01:22 --> Input Class Initialized
INFO - 2018-08-14 14:01:22 --> Language Class Initialized
INFO - 2018-08-14 14:01:22 --> Language Class Initialized
INFO - 2018-08-14 14:01:22 --> Config Class Initialized
INFO - 2018-08-14 14:01:22 --> Loader Class Initialized
INFO - 2018-08-14 14:01:22 --> Helper loaded: url_helper
INFO - 2018-08-14 14:01:22 --> Helper loaded: file_helper
INFO - 2018-08-14 14:01:22 --> Helper loaded: form_helper
INFO - 2018-08-14 14:01:22 --> Helper loaded: my_helper
INFO - 2018-08-14 14:01:22 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:01:22 --> Controller Class Initialized
INFO - 2018-08-14 14:01:23 --> Final output sent to browser
DEBUG - 2018-08-14 14:01:23 --> Total execution time: 0.4390
INFO - 2018-08-14 14:01:29 --> Config Class Initialized
INFO - 2018-08-14 14:01:29 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:01:29 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:01:29 --> Utf8 Class Initialized
INFO - 2018-08-14 14:01:29 --> URI Class Initialized
INFO - 2018-08-14 14:01:29 --> Router Class Initialized
INFO - 2018-08-14 14:01:29 --> Output Class Initialized
INFO - 2018-08-14 14:01:29 --> Security Class Initialized
DEBUG - 2018-08-14 14:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:01:29 --> Input Class Initialized
INFO - 2018-08-14 14:01:29 --> Language Class Initialized
INFO - 2018-08-14 14:01:29 --> Language Class Initialized
INFO - 2018-08-14 14:01:29 --> Config Class Initialized
INFO - 2018-08-14 14:01:29 --> Loader Class Initialized
INFO - 2018-08-14 14:01:29 --> Helper loaded: url_helper
INFO - 2018-08-14 14:01:29 --> Helper loaded: file_helper
INFO - 2018-08-14 14:01:29 --> Helper loaded: form_helper
INFO - 2018-08-14 14:01:29 --> Helper loaded: my_helper
INFO - 2018-08-14 14:01:29 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:01:29 --> Controller Class Initialized
INFO - 2018-08-14 14:01:29 --> Final output sent to browser
DEBUG - 2018-08-14 14:01:29 --> Total execution time: 0.4465
INFO - 2018-08-14 14:01:30 --> Config Class Initialized
INFO - 2018-08-14 14:01:30 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:01:30 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:01:30 --> Utf8 Class Initialized
INFO - 2018-08-14 14:01:30 --> URI Class Initialized
INFO - 2018-08-14 14:01:30 --> Router Class Initialized
INFO - 2018-08-14 14:01:30 --> Output Class Initialized
INFO - 2018-08-14 14:01:30 --> Security Class Initialized
DEBUG - 2018-08-14 14:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:01:30 --> Input Class Initialized
INFO - 2018-08-14 14:01:30 --> Language Class Initialized
INFO - 2018-08-14 14:01:30 --> Language Class Initialized
INFO - 2018-08-14 14:01:30 --> Config Class Initialized
INFO - 2018-08-14 14:01:30 --> Loader Class Initialized
INFO - 2018-08-14 14:01:30 --> Helper loaded: url_helper
INFO - 2018-08-14 14:01:30 --> Helper loaded: file_helper
INFO - 2018-08-14 14:01:30 --> Helper loaded: form_helper
INFO - 2018-08-14 14:01:30 --> Helper loaded: my_helper
INFO - 2018-08-14 14:01:30 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:01:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:01:30 --> Controller Class Initialized
INFO - 2018-08-14 14:01:30 --> Config Class Initialized
INFO - 2018-08-14 14:01:30 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:01:30 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:01:30 --> Utf8 Class Initialized
INFO - 2018-08-14 14:01:30 --> URI Class Initialized
INFO - 2018-08-14 14:01:30 --> Router Class Initialized
INFO - 2018-08-14 14:01:30 --> Output Class Initialized
INFO - 2018-08-14 14:01:30 --> Security Class Initialized
DEBUG - 2018-08-14 14:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:01:30 --> Input Class Initialized
INFO - 2018-08-14 14:01:31 --> Language Class Initialized
INFO - 2018-08-14 14:01:31 --> Language Class Initialized
INFO - 2018-08-14 14:01:31 --> Config Class Initialized
INFO - 2018-08-14 14:01:31 --> Loader Class Initialized
INFO - 2018-08-14 14:01:31 --> Helper loaded: url_helper
INFO - 2018-08-14 14:01:31 --> Helper loaded: file_helper
INFO - 2018-08-14 14:01:31 --> Helper loaded: form_helper
INFO - 2018-08-14 14:01:31 --> Helper loaded: my_helper
INFO - 2018-08-14 14:01:31 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:01:31 --> Controller Class Initialized
INFO - 2018-08-14 14:01:31 --> Final output sent to browser
DEBUG - 2018-08-14 14:01:31 --> Total execution time: 0.4167
INFO - 2018-08-14 14:01:37 --> Config Class Initialized
INFO - 2018-08-14 14:01:37 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:01:37 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:01:37 --> Utf8 Class Initialized
INFO - 2018-08-14 14:01:37 --> URI Class Initialized
INFO - 2018-08-14 14:01:37 --> Router Class Initialized
INFO - 2018-08-14 14:01:37 --> Output Class Initialized
INFO - 2018-08-14 14:01:37 --> Security Class Initialized
DEBUG - 2018-08-14 14:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:01:37 --> Input Class Initialized
INFO - 2018-08-14 14:01:37 --> Language Class Initialized
INFO - 2018-08-14 14:01:38 --> Language Class Initialized
INFO - 2018-08-14 14:01:38 --> Config Class Initialized
INFO - 2018-08-14 14:01:38 --> Loader Class Initialized
INFO - 2018-08-14 14:01:38 --> Helper loaded: url_helper
INFO - 2018-08-14 14:01:38 --> Helper loaded: file_helper
INFO - 2018-08-14 14:01:38 --> Helper loaded: form_helper
INFO - 2018-08-14 14:01:38 --> Helper loaded: my_helper
INFO - 2018-08-14 14:01:38 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:01:38 --> Controller Class Initialized
INFO - 2018-08-14 14:01:38 --> Final output sent to browser
DEBUG - 2018-08-14 14:01:38 --> Total execution time: 0.4667
INFO - 2018-08-14 14:01:38 --> Config Class Initialized
INFO - 2018-08-14 14:01:38 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:01:38 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:01:38 --> Utf8 Class Initialized
INFO - 2018-08-14 14:01:38 --> URI Class Initialized
INFO - 2018-08-14 14:01:38 --> Router Class Initialized
INFO - 2018-08-14 14:01:38 --> Output Class Initialized
INFO - 2018-08-14 14:01:38 --> Security Class Initialized
DEBUG - 2018-08-14 14:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:01:38 --> Input Class Initialized
INFO - 2018-08-14 14:01:38 --> Language Class Initialized
INFO - 2018-08-14 14:01:38 --> Language Class Initialized
INFO - 2018-08-14 14:01:38 --> Config Class Initialized
INFO - 2018-08-14 14:01:38 --> Loader Class Initialized
INFO - 2018-08-14 14:01:38 --> Helper loaded: url_helper
INFO - 2018-08-14 14:01:38 --> Helper loaded: file_helper
INFO - 2018-08-14 14:01:38 --> Helper loaded: form_helper
INFO - 2018-08-14 14:01:38 --> Helper loaded: my_helper
INFO - 2018-08-14 14:01:38 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:01:38 --> Controller Class Initialized
INFO - 2018-08-14 14:01:38 --> Config Class Initialized
INFO - 2018-08-14 14:01:38 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:01:38 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:01:39 --> Utf8 Class Initialized
INFO - 2018-08-14 14:01:39 --> URI Class Initialized
INFO - 2018-08-14 14:01:39 --> Router Class Initialized
INFO - 2018-08-14 14:01:39 --> Output Class Initialized
INFO - 2018-08-14 14:01:39 --> Security Class Initialized
DEBUG - 2018-08-14 14:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:01:39 --> Input Class Initialized
INFO - 2018-08-14 14:01:39 --> Language Class Initialized
INFO - 2018-08-14 14:01:39 --> Language Class Initialized
INFO - 2018-08-14 14:01:39 --> Config Class Initialized
INFO - 2018-08-14 14:01:39 --> Loader Class Initialized
INFO - 2018-08-14 14:01:39 --> Helper loaded: url_helper
INFO - 2018-08-14 14:01:39 --> Helper loaded: file_helper
INFO - 2018-08-14 14:01:39 --> Helper loaded: form_helper
INFO - 2018-08-14 14:01:39 --> Helper loaded: my_helper
INFO - 2018-08-14 14:01:39 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:01:39 --> Controller Class Initialized
INFO - 2018-08-14 14:01:39 --> Final output sent to browser
DEBUG - 2018-08-14 14:01:39 --> Total execution time: 0.4192
INFO - 2018-08-14 14:01:45 --> Config Class Initialized
INFO - 2018-08-14 14:01:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:01:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:01:45 --> Utf8 Class Initialized
INFO - 2018-08-14 14:01:45 --> URI Class Initialized
INFO - 2018-08-14 14:01:45 --> Router Class Initialized
INFO - 2018-08-14 14:01:45 --> Output Class Initialized
INFO - 2018-08-14 14:01:45 --> Security Class Initialized
DEBUG - 2018-08-14 14:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:01:45 --> Input Class Initialized
INFO - 2018-08-14 14:01:45 --> Language Class Initialized
INFO - 2018-08-14 14:01:45 --> Language Class Initialized
INFO - 2018-08-14 14:01:45 --> Config Class Initialized
INFO - 2018-08-14 14:01:45 --> Loader Class Initialized
INFO - 2018-08-14 14:01:45 --> Helper loaded: url_helper
INFO - 2018-08-14 14:01:45 --> Helper loaded: file_helper
INFO - 2018-08-14 14:01:45 --> Helper loaded: form_helper
INFO - 2018-08-14 14:01:45 --> Helper loaded: my_helper
INFO - 2018-08-14 14:01:45 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:01:45 --> Controller Class Initialized
INFO - 2018-08-14 14:01:45 --> Final output sent to browser
DEBUG - 2018-08-14 14:01:45 --> Total execution time: 0.4621
INFO - 2018-08-14 14:01:46 --> Config Class Initialized
INFO - 2018-08-14 14:01:46 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:01:46 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:01:46 --> Utf8 Class Initialized
INFO - 2018-08-14 14:01:46 --> URI Class Initialized
INFO - 2018-08-14 14:01:46 --> Router Class Initialized
INFO - 2018-08-14 14:01:46 --> Output Class Initialized
INFO - 2018-08-14 14:01:46 --> Security Class Initialized
DEBUG - 2018-08-14 14:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:01:46 --> Input Class Initialized
INFO - 2018-08-14 14:01:46 --> Language Class Initialized
INFO - 2018-08-14 14:01:46 --> Language Class Initialized
INFO - 2018-08-14 14:01:46 --> Config Class Initialized
INFO - 2018-08-14 14:01:46 --> Loader Class Initialized
INFO - 2018-08-14 14:01:46 --> Helper loaded: url_helper
INFO - 2018-08-14 14:01:46 --> Helper loaded: file_helper
INFO - 2018-08-14 14:01:46 --> Helper loaded: form_helper
INFO - 2018-08-14 14:01:46 --> Helper loaded: my_helper
INFO - 2018-08-14 14:01:46 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:01:46 --> Controller Class Initialized
INFO - 2018-08-14 14:01:48 --> Config Class Initialized
INFO - 2018-08-14 14:01:48 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:01:48 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:01:48 --> Utf8 Class Initialized
INFO - 2018-08-14 14:01:49 --> URI Class Initialized
INFO - 2018-08-14 14:01:49 --> Router Class Initialized
INFO - 2018-08-14 14:01:49 --> Output Class Initialized
INFO - 2018-08-14 14:01:49 --> Security Class Initialized
DEBUG - 2018-08-14 14:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:01:49 --> Input Class Initialized
INFO - 2018-08-14 14:01:49 --> Language Class Initialized
INFO - 2018-08-14 14:01:49 --> Language Class Initialized
INFO - 2018-08-14 14:01:49 --> Config Class Initialized
INFO - 2018-08-14 14:01:49 --> Loader Class Initialized
INFO - 2018-08-14 14:01:49 --> Helper loaded: url_helper
INFO - 2018-08-14 14:01:49 --> Helper loaded: file_helper
INFO - 2018-08-14 14:01:49 --> Helper loaded: form_helper
INFO - 2018-08-14 14:01:49 --> Helper loaded: my_helper
INFO - 2018-08-14 14:01:49 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:01:49 --> Controller Class Initialized
DEBUG - 2018-08-14 14:01:49 --> File loaded: D:\laragon\www\nilai\application\modules/home/views/v_cetak.php
DEBUG - 2018-08-14 14:01:49 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:01:49 --> Final output sent to browser
DEBUG - 2018-08-14 14:01:49 --> Total execution time: 0.6489
INFO - 2018-08-14 14:01:49 --> Config Class Initialized
INFO - 2018-08-14 14:01:49 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:01:49 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:01:49 --> Utf8 Class Initialized
INFO - 2018-08-14 14:01:49 --> URI Class Initialized
INFO - 2018-08-14 14:01:49 --> Router Class Initialized
INFO - 2018-08-14 14:01:49 --> Output Class Initialized
INFO - 2018-08-14 14:01:49 --> Security Class Initialized
DEBUG - 2018-08-14 14:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:01:50 --> Input Class Initialized
INFO - 2018-08-14 14:01:50 --> Language Class Initialized
ERROR - 2018-08-14 14:01:50 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:02:15 --> Config Class Initialized
INFO - 2018-08-14 14:02:15 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:02:15 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:02:15 --> Utf8 Class Initialized
INFO - 2018-08-14 14:02:15 --> URI Class Initialized
INFO - 2018-08-14 14:02:15 --> Router Class Initialized
INFO - 2018-08-14 14:02:15 --> Output Class Initialized
INFO - 2018-08-14 14:02:15 --> Security Class Initialized
DEBUG - 2018-08-14 14:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:02:15 --> Input Class Initialized
INFO - 2018-08-14 14:02:15 --> Language Class Initialized
INFO - 2018-08-14 14:02:15 --> Language Class Initialized
INFO - 2018-08-14 14:02:15 --> Config Class Initialized
INFO - 2018-08-14 14:02:15 --> Loader Class Initialized
INFO - 2018-08-14 14:02:15 --> Helper loaded: url_helper
INFO - 2018-08-14 14:02:15 --> Helper loaded: file_helper
INFO - 2018-08-14 14:02:15 --> Helper loaded: form_helper
INFO - 2018-08-14 14:02:15 --> Helper loaded: my_helper
INFO - 2018-08-14 14:02:15 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:02:15 --> Controller Class Initialized
DEBUG - 2018-08-14 14:02:15 --> File loaded: D:\laragon\www\nilai\application\modules/home/views/v_cetak.php
DEBUG - 2018-08-14 14:02:15 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:02:15 --> Final output sent to browser
DEBUG - 2018-08-14 14:02:16 --> Total execution time: 0.5093
INFO - 2018-08-14 14:02:16 --> Config Class Initialized
INFO - 2018-08-14 14:02:16 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:02:16 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:02:16 --> Utf8 Class Initialized
INFO - 2018-08-14 14:02:16 --> URI Class Initialized
INFO - 2018-08-14 14:02:16 --> Router Class Initialized
INFO - 2018-08-14 14:02:16 --> Output Class Initialized
INFO - 2018-08-14 14:02:16 --> Security Class Initialized
DEBUG - 2018-08-14 14:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:02:16 --> Input Class Initialized
INFO - 2018-08-14 14:02:16 --> Language Class Initialized
ERROR - 2018-08-14 14:02:16 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:02:19 --> Config Class Initialized
INFO - 2018-08-14 14:02:19 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:02:19 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:02:19 --> Utf8 Class Initialized
INFO - 2018-08-14 14:02:19 --> URI Class Initialized
INFO - 2018-08-14 14:02:19 --> Router Class Initialized
INFO - 2018-08-14 14:02:19 --> Output Class Initialized
INFO - 2018-08-14 14:02:19 --> Security Class Initialized
DEBUG - 2018-08-14 14:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:02:19 --> Input Class Initialized
INFO - 2018-08-14 14:02:19 --> Language Class Initialized
INFO - 2018-08-14 14:02:19 --> Language Class Initialized
INFO - 2018-08-14 14:02:19 --> Config Class Initialized
INFO - 2018-08-14 14:02:19 --> Loader Class Initialized
INFO - 2018-08-14 14:02:19 --> Helper loaded: url_helper
INFO - 2018-08-14 14:02:19 --> Helper loaded: file_helper
INFO - 2018-08-14 14:02:19 --> Helper loaded: form_helper
INFO - 2018-08-14 14:02:19 --> Helper loaded: my_helper
INFO - 2018-08-14 14:02:19 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:02:19 --> Controller Class Initialized
DEBUG - 2018-08-14 14:02:19 --> File loaded: D:\laragon\www\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2018-08-14 14:02:19 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:02:19 --> Final output sent to browser
DEBUG - 2018-08-14 14:02:19 --> Total execution time: 0.5698
INFO - 2018-08-14 14:02:20 --> Config Class Initialized
INFO - 2018-08-14 14:02:20 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:02:20 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:02:20 --> Utf8 Class Initialized
INFO - 2018-08-14 14:02:20 --> URI Class Initialized
INFO - 2018-08-14 14:02:20 --> Router Class Initialized
INFO - 2018-08-14 14:02:20 --> Output Class Initialized
INFO - 2018-08-14 14:02:20 --> Security Class Initialized
DEBUG - 2018-08-14 14:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:02:20 --> Input Class Initialized
INFO - 2018-08-14 14:02:20 --> Language Class Initialized
ERROR - 2018-08-14 14:02:20 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:02:20 --> Config Class Initialized
INFO - 2018-08-14 14:02:20 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:02:20 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:02:20 --> Utf8 Class Initialized
INFO - 2018-08-14 14:02:20 --> URI Class Initialized
INFO - 2018-08-14 14:02:20 --> Router Class Initialized
INFO - 2018-08-14 14:02:20 --> Output Class Initialized
INFO - 2018-08-14 14:02:20 --> Security Class Initialized
DEBUG - 2018-08-14 14:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:02:20 --> Input Class Initialized
INFO - 2018-08-14 14:02:20 --> Language Class Initialized
INFO - 2018-08-14 14:02:20 --> Language Class Initialized
INFO - 2018-08-14 14:02:20 --> Config Class Initialized
INFO - 2018-08-14 14:02:20 --> Loader Class Initialized
INFO - 2018-08-14 14:02:20 --> Helper loaded: url_helper
INFO - 2018-08-14 14:02:20 --> Helper loaded: file_helper
INFO - 2018-08-14 14:02:20 --> Helper loaded: form_helper
INFO - 2018-08-14 14:02:20 --> Helper loaded: my_helper
INFO - 2018-08-14 14:02:20 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:02:20 --> Controller Class Initialized
INFO - 2018-08-14 14:02:26 --> Config Class Initialized
INFO - 2018-08-14 14:02:26 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:02:26 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:02:26 --> Utf8 Class Initialized
INFO - 2018-08-14 14:02:26 --> URI Class Initialized
INFO - 2018-08-14 14:02:26 --> Router Class Initialized
INFO - 2018-08-14 14:02:26 --> Output Class Initialized
INFO - 2018-08-14 14:02:26 --> Security Class Initialized
DEBUG - 2018-08-14 14:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:02:26 --> Input Class Initialized
INFO - 2018-08-14 14:02:26 --> Language Class Initialized
INFO - 2018-08-14 14:02:26 --> Language Class Initialized
INFO - 2018-08-14 14:02:26 --> Config Class Initialized
INFO - 2018-08-14 14:02:26 --> Loader Class Initialized
INFO - 2018-08-14 14:02:26 --> Helper loaded: url_helper
INFO - 2018-08-14 14:02:26 --> Helper loaded: file_helper
INFO - 2018-08-14 14:02:26 --> Helper loaded: form_helper
INFO - 2018-08-14 14:02:26 --> Helper loaded: my_helper
INFO - 2018-08-14 14:02:26 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:02:26 --> Controller Class Initialized
INFO - 2018-08-14 14:02:26 --> Final output sent to browser
DEBUG - 2018-08-14 14:02:26 --> Total execution time: 0.6437
INFO - 2018-08-14 14:02:30 --> Config Class Initialized
INFO - 2018-08-14 14:02:30 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:02:30 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:02:30 --> Utf8 Class Initialized
INFO - 2018-08-14 14:02:30 --> URI Class Initialized
INFO - 2018-08-14 14:02:30 --> Router Class Initialized
INFO - 2018-08-14 14:02:30 --> Output Class Initialized
INFO - 2018-08-14 14:02:30 --> Security Class Initialized
DEBUG - 2018-08-14 14:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:02:30 --> Input Class Initialized
INFO - 2018-08-14 14:02:30 --> Language Class Initialized
INFO - 2018-08-14 14:02:30 --> Language Class Initialized
INFO - 2018-08-14 14:02:30 --> Config Class Initialized
INFO - 2018-08-14 14:02:30 --> Loader Class Initialized
INFO - 2018-08-14 14:02:30 --> Helper loaded: url_helper
INFO - 2018-08-14 14:02:30 --> Helper loaded: file_helper
INFO - 2018-08-14 14:02:30 --> Helper loaded: form_helper
INFO - 2018-08-14 14:02:30 --> Helper loaded: my_helper
INFO - 2018-08-14 14:02:30 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:02:30 --> Controller Class Initialized
DEBUG - 2018-08-14 14:02:30 --> File loaded: D:\laragon\www\nilai\application\modules/home/views/v_ubah_password.php
DEBUG - 2018-08-14 14:02:30 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:02:30 --> Final output sent to browser
DEBUG - 2018-08-14 14:02:30 --> Total execution time: 0.6623
INFO - 2018-08-14 14:02:30 --> Config Class Initialized
INFO - 2018-08-14 14:02:31 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:02:31 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:02:31 --> Utf8 Class Initialized
INFO - 2018-08-14 14:02:31 --> URI Class Initialized
INFO - 2018-08-14 14:02:31 --> Router Class Initialized
INFO - 2018-08-14 14:02:31 --> Output Class Initialized
INFO - 2018-08-14 14:02:31 --> Security Class Initialized
DEBUG - 2018-08-14 14:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:02:31 --> Input Class Initialized
INFO - 2018-08-14 14:02:31 --> Language Class Initialized
ERROR - 2018-08-14 14:02:31 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:02:32 --> Config Class Initialized
INFO - 2018-08-14 14:02:32 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:02:32 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:02:32 --> Utf8 Class Initialized
INFO - 2018-08-14 14:02:32 --> URI Class Initialized
INFO - 2018-08-14 14:02:32 --> Router Class Initialized
INFO - 2018-08-14 14:02:32 --> Output Class Initialized
INFO - 2018-08-14 14:02:32 --> Security Class Initialized
DEBUG - 2018-08-14 14:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:02:32 --> Input Class Initialized
INFO - 2018-08-14 14:02:32 --> Language Class Initialized
INFO - 2018-08-14 14:02:32 --> Language Class Initialized
INFO - 2018-08-14 14:02:32 --> Config Class Initialized
INFO - 2018-08-14 14:02:32 --> Loader Class Initialized
INFO - 2018-08-14 14:02:32 --> Helper loaded: url_helper
INFO - 2018-08-14 14:02:32 --> Helper loaded: file_helper
INFO - 2018-08-14 14:02:32 --> Helper loaded: form_helper
INFO - 2018-08-14 14:02:32 --> Helper loaded: my_helper
INFO - 2018-08-14 14:02:32 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:02:32 --> Controller Class Initialized
DEBUG - 2018-08-14 14:02:32 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 14:02:32 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:02:32 --> Final output sent to browser
DEBUG - 2018-08-14 14:02:32 --> Total execution time: 0.4508
INFO - 2018-08-14 14:02:32 --> Config Class Initialized
INFO - 2018-08-14 14:02:32 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:02:32 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:02:32 --> Utf8 Class Initialized
INFO - 2018-08-14 14:02:32 --> URI Class Initialized
INFO - 2018-08-14 14:02:33 --> Router Class Initialized
INFO - 2018-08-14 14:02:33 --> Output Class Initialized
INFO - 2018-08-14 14:02:33 --> Security Class Initialized
DEBUG - 2018-08-14 14:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:02:33 --> Input Class Initialized
INFO - 2018-08-14 14:02:33 --> Language Class Initialized
ERROR - 2018-08-14 14:02:33 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:02:33 --> Config Class Initialized
INFO - 2018-08-14 14:02:33 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:02:33 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:02:33 --> Utf8 Class Initialized
INFO - 2018-08-14 14:02:33 --> URI Class Initialized
INFO - 2018-08-14 14:02:33 --> Router Class Initialized
INFO - 2018-08-14 14:02:33 --> Output Class Initialized
INFO - 2018-08-14 14:02:33 --> Security Class Initialized
DEBUG - 2018-08-14 14:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:02:33 --> Input Class Initialized
INFO - 2018-08-14 14:02:33 --> Language Class Initialized
INFO - 2018-08-14 14:02:33 --> Language Class Initialized
INFO - 2018-08-14 14:02:33 --> Config Class Initialized
INFO - 2018-08-14 14:02:33 --> Loader Class Initialized
INFO - 2018-08-14 14:02:33 --> Helper loaded: url_helper
INFO - 2018-08-14 14:02:33 --> Helper loaded: file_helper
INFO - 2018-08-14 14:02:33 --> Helper loaded: form_helper
INFO - 2018-08-14 14:02:33 --> Helper loaded: my_helper
INFO - 2018-08-14 14:02:33 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:02:33 --> Controller Class Initialized
INFO - 2018-08-14 14:05:50 --> Config Class Initialized
INFO - 2018-08-14 14:05:50 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:05:50 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:05:50 --> Utf8 Class Initialized
INFO - 2018-08-14 14:05:50 --> URI Class Initialized
INFO - 2018-08-14 14:05:50 --> Router Class Initialized
INFO - 2018-08-14 14:05:50 --> Output Class Initialized
INFO - 2018-08-14 14:05:50 --> Security Class Initialized
DEBUG - 2018-08-14 14:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:05:50 --> Input Class Initialized
INFO - 2018-08-14 14:05:50 --> Language Class Initialized
INFO - 2018-08-14 14:05:50 --> Language Class Initialized
INFO - 2018-08-14 14:05:50 --> Config Class Initialized
INFO - 2018-08-14 14:05:50 --> Loader Class Initialized
INFO - 2018-08-14 14:05:50 --> Helper loaded: url_helper
INFO - 2018-08-14 14:05:50 --> Helper loaded: file_helper
INFO - 2018-08-14 14:05:50 --> Helper loaded: form_helper
INFO - 2018-08-14 14:05:50 --> Helper loaded: my_helper
INFO - 2018-08-14 14:05:50 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:05:50 --> Controller Class Initialized
DEBUG - 2018-08-14 14:05:50 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 14:05:50 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:05:50 --> Final output sent to browser
DEBUG - 2018-08-14 14:05:50 --> Total execution time: 0.4568
INFO - 2018-08-14 14:05:50 --> Config Class Initialized
INFO - 2018-08-14 14:05:50 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:05:50 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:05:50 --> Utf8 Class Initialized
INFO - 2018-08-14 14:05:50 --> URI Class Initialized
INFO - 2018-08-14 14:05:50 --> Router Class Initialized
INFO - 2018-08-14 14:05:50 --> Output Class Initialized
INFO - 2018-08-14 14:05:50 --> Security Class Initialized
DEBUG - 2018-08-14 14:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:05:50 --> Input Class Initialized
INFO - 2018-08-14 14:05:50 --> Language Class Initialized
ERROR - 2018-08-14 14:05:51 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:05:51 --> Config Class Initialized
INFO - 2018-08-14 14:05:51 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:05:51 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:05:51 --> Utf8 Class Initialized
INFO - 2018-08-14 14:05:51 --> URI Class Initialized
INFO - 2018-08-14 14:05:51 --> Router Class Initialized
INFO - 2018-08-14 14:05:51 --> Output Class Initialized
INFO - 2018-08-14 14:05:51 --> Security Class Initialized
DEBUG - 2018-08-14 14:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:05:51 --> Input Class Initialized
INFO - 2018-08-14 14:05:51 --> Language Class Initialized
INFO - 2018-08-14 14:05:51 --> Language Class Initialized
INFO - 2018-08-14 14:05:51 --> Config Class Initialized
INFO - 2018-08-14 14:05:51 --> Loader Class Initialized
INFO - 2018-08-14 14:05:51 --> Helper loaded: url_helper
INFO - 2018-08-14 14:05:51 --> Helper loaded: file_helper
INFO - 2018-08-14 14:05:51 --> Helper loaded: form_helper
INFO - 2018-08-14 14:05:51 --> Helper loaded: my_helper
INFO - 2018-08-14 14:05:51 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:05:51 --> Controller Class Initialized
INFO - 2018-08-14 14:10:46 --> Config Class Initialized
INFO - 2018-08-14 14:10:46 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:10:46 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:10:46 --> Utf8 Class Initialized
INFO - 2018-08-14 14:10:46 --> URI Class Initialized
INFO - 2018-08-14 14:10:46 --> Router Class Initialized
INFO - 2018-08-14 14:10:46 --> Output Class Initialized
INFO - 2018-08-14 14:10:46 --> Security Class Initialized
DEBUG - 2018-08-14 14:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:10:47 --> Input Class Initialized
INFO - 2018-08-14 14:10:47 --> Language Class Initialized
INFO - 2018-08-14 14:10:47 --> Language Class Initialized
INFO - 2018-08-14 14:10:47 --> Config Class Initialized
INFO - 2018-08-14 14:10:47 --> Loader Class Initialized
INFO - 2018-08-14 14:10:47 --> Helper loaded: url_helper
INFO - 2018-08-14 14:10:47 --> Helper loaded: file_helper
INFO - 2018-08-14 14:10:47 --> Helper loaded: form_helper
INFO - 2018-08-14 14:10:47 --> Helper loaded: my_helper
INFO - 2018-08-14 14:10:47 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:10:47 --> Controller Class Initialized
DEBUG - 2018-08-14 14:10:47 --> File loaded: D:\laragon\www\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2018-08-14 14:10:47 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:10:47 --> Final output sent to browser
DEBUG - 2018-08-14 14:10:47 --> Total execution time: 0.6544
INFO - 2018-08-14 14:10:47 --> Config Class Initialized
INFO - 2018-08-14 14:10:47 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:10:47 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:10:47 --> Utf8 Class Initialized
INFO - 2018-08-14 14:10:47 --> URI Class Initialized
INFO - 2018-08-14 14:10:47 --> Router Class Initialized
INFO - 2018-08-14 14:10:47 --> Output Class Initialized
INFO - 2018-08-14 14:10:47 --> Security Class Initialized
DEBUG - 2018-08-14 14:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:10:47 --> Input Class Initialized
INFO - 2018-08-14 14:10:47 --> Language Class Initialized
ERROR - 2018-08-14 14:10:47 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:10:47 --> Config Class Initialized
INFO - 2018-08-14 14:10:47 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:10:48 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:10:48 --> Utf8 Class Initialized
INFO - 2018-08-14 14:10:48 --> URI Class Initialized
INFO - 2018-08-14 14:10:48 --> Router Class Initialized
INFO - 2018-08-14 14:10:48 --> Output Class Initialized
INFO - 2018-08-14 14:10:48 --> Security Class Initialized
DEBUG - 2018-08-14 14:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:10:48 --> Input Class Initialized
INFO - 2018-08-14 14:10:48 --> Language Class Initialized
INFO - 2018-08-14 14:10:48 --> Language Class Initialized
INFO - 2018-08-14 14:10:48 --> Config Class Initialized
INFO - 2018-08-14 14:10:48 --> Loader Class Initialized
INFO - 2018-08-14 14:10:48 --> Helper loaded: url_helper
INFO - 2018-08-14 14:10:48 --> Helper loaded: file_helper
INFO - 2018-08-14 14:10:48 --> Helper loaded: form_helper
INFO - 2018-08-14 14:10:48 --> Helper loaded: my_helper
INFO - 2018-08-14 14:10:48 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:10:48 --> Controller Class Initialized
INFO - 2018-08-14 14:12:27 --> Config Class Initialized
INFO - 2018-08-14 14:12:27 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:12:27 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:12:27 --> Utf8 Class Initialized
INFO - 2018-08-14 14:12:27 --> URI Class Initialized
INFO - 2018-08-14 14:12:27 --> Router Class Initialized
INFO - 2018-08-14 14:12:27 --> Output Class Initialized
INFO - 2018-08-14 14:12:27 --> Security Class Initialized
DEBUG - 2018-08-14 14:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:12:27 --> Input Class Initialized
INFO - 2018-08-14 14:12:27 --> Language Class Initialized
INFO - 2018-08-14 14:12:27 --> Language Class Initialized
INFO - 2018-08-14 14:12:27 --> Config Class Initialized
INFO - 2018-08-14 14:12:28 --> Loader Class Initialized
INFO - 2018-08-14 14:12:28 --> Helper loaded: url_helper
INFO - 2018-08-14 14:12:28 --> Helper loaded: file_helper
INFO - 2018-08-14 14:12:28 --> Helper loaded: form_helper
INFO - 2018-08-14 14:12:28 --> Helper loaded: my_helper
INFO - 2018-08-14 14:12:28 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:12:28 --> Controller Class Initialized
DEBUG - 2018-08-14 14:12:28 --> File loaded: D:\laragon\www\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2018-08-14 14:12:28 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:12:28 --> Final output sent to browser
DEBUG - 2018-08-14 14:12:28 --> Total execution time: 0.5233
INFO - 2018-08-14 14:12:28 --> Config Class Initialized
INFO - 2018-08-14 14:12:28 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:12:28 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:12:28 --> Utf8 Class Initialized
INFO - 2018-08-14 14:12:28 --> URI Class Initialized
INFO - 2018-08-14 14:12:28 --> Router Class Initialized
INFO - 2018-08-14 14:12:28 --> Output Class Initialized
INFO - 2018-08-14 14:12:28 --> Security Class Initialized
DEBUG - 2018-08-14 14:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:12:28 --> Input Class Initialized
INFO - 2018-08-14 14:12:28 --> Language Class Initialized
ERROR - 2018-08-14 14:12:28 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:12:28 --> Config Class Initialized
INFO - 2018-08-14 14:12:28 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:12:28 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:12:28 --> Utf8 Class Initialized
INFO - 2018-08-14 14:12:28 --> URI Class Initialized
INFO - 2018-08-14 14:12:28 --> Router Class Initialized
INFO - 2018-08-14 14:12:28 --> Output Class Initialized
INFO - 2018-08-14 14:12:28 --> Security Class Initialized
DEBUG - 2018-08-14 14:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:12:28 --> Input Class Initialized
INFO - 2018-08-14 14:12:28 --> Language Class Initialized
INFO - 2018-08-14 14:12:28 --> Language Class Initialized
INFO - 2018-08-14 14:12:29 --> Config Class Initialized
INFO - 2018-08-14 14:12:29 --> Loader Class Initialized
INFO - 2018-08-14 14:12:29 --> Helper loaded: url_helper
INFO - 2018-08-14 14:12:29 --> Helper loaded: file_helper
INFO - 2018-08-14 14:12:29 --> Helper loaded: form_helper
INFO - 2018-08-14 14:12:29 --> Helper loaded: my_helper
INFO - 2018-08-14 14:12:29 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:12:29 --> Controller Class Initialized
INFO - 2018-08-14 14:12:57 --> Config Class Initialized
INFO - 2018-08-14 14:12:57 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:12:57 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:12:57 --> Utf8 Class Initialized
INFO - 2018-08-14 14:12:57 --> URI Class Initialized
INFO - 2018-08-14 14:12:57 --> Router Class Initialized
INFO - 2018-08-14 14:12:57 --> Output Class Initialized
INFO - 2018-08-14 14:12:57 --> Security Class Initialized
DEBUG - 2018-08-14 14:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:12:58 --> Input Class Initialized
INFO - 2018-08-14 14:12:58 --> Language Class Initialized
INFO - 2018-08-14 14:12:58 --> Language Class Initialized
INFO - 2018-08-14 14:12:58 --> Config Class Initialized
INFO - 2018-08-14 14:12:58 --> Loader Class Initialized
INFO - 2018-08-14 14:12:58 --> Helper loaded: url_helper
INFO - 2018-08-14 14:12:58 --> Helper loaded: file_helper
INFO - 2018-08-14 14:12:58 --> Helper loaded: form_helper
INFO - 2018-08-14 14:12:58 --> Helper loaded: my_helper
INFO - 2018-08-14 14:12:58 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:12:58 --> Controller Class Initialized
DEBUG - 2018-08-14 14:12:58 --> File loaded: D:\laragon\www\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2018-08-14 14:12:58 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:12:58 --> Final output sent to browser
DEBUG - 2018-08-14 14:12:58 --> Total execution time: 0.5253
INFO - 2018-08-14 14:12:58 --> Config Class Initialized
INFO - 2018-08-14 14:12:58 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:12:58 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:12:58 --> Utf8 Class Initialized
INFO - 2018-08-14 14:12:58 --> URI Class Initialized
INFO - 2018-08-14 14:12:58 --> Router Class Initialized
INFO - 2018-08-14 14:12:58 --> Output Class Initialized
INFO - 2018-08-14 14:12:58 --> Security Class Initialized
DEBUG - 2018-08-14 14:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:12:58 --> Input Class Initialized
INFO - 2018-08-14 14:12:58 --> Language Class Initialized
ERROR - 2018-08-14 14:12:58 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:12:58 --> Config Class Initialized
INFO - 2018-08-14 14:12:58 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:12:58 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:12:58 --> Utf8 Class Initialized
INFO - 2018-08-14 14:12:58 --> URI Class Initialized
INFO - 2018-08-14 14:12:58 --> Router Class Initialized
INFO - 2018-08-14 14:12:58 --> Output Class Initialized
INFO - 2018-08-14 14:12:58 --> Security Class Initialized
DEBUG - 2018-08-14 14:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:12:59 --> Input Class Initialized
INFO - 2018-08-14 14:12:59 --> Language Class Initialized
INFO - 2018-08-14 14:12:59 --> Language Class Initialized
INFO - 2018-08-14 14:12:59 --> Config Class Initialized
INFO - 2018-08-14 14:12:59 --> Loader Class Initialized
INFO - 2018-08-14 14:12:59 --> Helper loaded: url_helper
INFO - 2018-08-14 14:12:59 --> Helper loaded: file_helper
INFO - 2018-08-14 14:12:59 --> Helper loaded: form_helper
INFO - 2018-08-14 14:12:59 --> Helper loaded: my_helper
INFO - 2018-08-14 14:12:59 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:12:59 --> Controller Class Initialized
INFO - 2018-08-14 14:12:59 --> Config Class Initialized
INFO - 2018-08-14 14:12:59 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:12:59 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:12:59 --> Utf8 Class Initialized
INFO - 2018-08-14 14:12:59 --> URI Class Initialized
INFO - 2018-08-14 14:12:59 --> Router Class Initialized
INFO - 2018-08-14 14:12:59 --> Output Class Initialized
INFO - 2018-08-14 14:12:59 --> Security Class Initialized
DEBUG - 2018-08-14 14:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:12:59 --> Input Class Initialized
INFO - 2018-08-14 14:12:59 --> Language Class Initialized
INFO - 2018-08-14 14:12:59 --> Language Class Initialized
INFO - 2018-08-14 14:12:59 --> Config Class Initialized
INFO - 2018-08-14 14:12:59 --> Loader Class Initialized
INFO - 2018-08-14 14:12:59 --> Helper loaded: url_helper
INFO - 2018-08-14 14:12:59 --> Helper loaded: file_helper
INFO - 2018-08-14 14:12:59 --> Helper loaded: form_helper
INFO - 2018-08-14 14:12:59 --> Helper loaded: my_helper
INFO - 2018-08-14 14:12:59 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:12:59 --> Controller Class Initialized
INFO - 2018-08-14 14:12:59 --> Final output sent to browser
DEBUG - 2018-08-14 14:12:59 --> Total execution time: 0.4461
INFO - 2018-08-14 14:13:57 --> Config Class Initialized
INFO - 2018-08-14 14:13:57 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:13:57 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:13:57 --> Utf8 Class Initialized
INFO - 2018-08-14 14:13:57 --> URI Class Initialized
INFO - 2018-08-14 14:13:57 --> Router Class Initialized
INFO - 2018-08-14 14:13:57 --> Output Class Initialized
INFO - 2018-08-14 14:13:57 --> Security Class Initialized
DEBUG - 2018-08-14 14:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:13:57 --> Input Class Initialized
INFO - 2018-08-14 14:13:57 --> Language Class Initialized
INFO - 2018-08-14 14:13:57 --> Language Class Initialized
INFO - 2018-08-14 14:13:57 --> Config Class Initialized
INFO - 2018-08-14 14:13:57 --> Loader Class Initialized
INFO - 2018-08-14 14:13:57 --> Helper loaded: url_helper
INFO - 2018-08-14 14:13:57 --> Helper loaded: file_helper
INFO - 2018-08-14 14:13:57 --> Helper loaded: form_helper
INFO - 2018-08-14 14:13:57 --> Helper loaded: my_helper
INFO - 2018-08-14 14:13:57 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:13:57 --> Controller Class Initialized
DEBUG - 2018-08-14 14:13:57 --> File loaded: D:\laragon\www\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2018-08-14 14:13:57 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:13:57 --> Final output sent to browser
DEBUG - 2018-08-14 14:13:57 --> Total execution time: 0.5709
INFO - 2018-08-14 14:13:58 --> Config Class Initialized
INFO - 2018-08-14 14:13:58 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:13:58 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:13:58 --> Utf8 Class Initialized
INFO - 2018-08-14 14:13:58 --> URI Class Initialized
INFO - 2018-08-14 14:13:58 --> Router Class Initialized
INFO - 2018-08-14 14:13:58 --> Output Class Initialized
INFO - 2018-08-14 14:13:58 --> Security Class Initialized
DEBUG - 2018-08-14 14:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:13:58 --> Input Class Initialized
INFO - 2018-08-14 14:13:58 --> Language Class Initialized
ERROR - 2018-08-14 14:13:58 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:13:59 --> Config Class Initialized
INFO - 2018-08-14 14:13:59 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:13:59 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:13:59 --> Utf8 Class Initialized
INFO - 2018-08-14 14:13:59 --> URI Class Initialized
INFO - 2018-08-14 14:13:59 --> Router Class Initialized
INFO - 2018-08-14 14:13:59 --> Output Class Initialized
INFO - 2018-08-14 14:13:59 --> Security Class Initialized
DEBUG - 2018-08-14 14:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:13:59 --> Input Class Initialized
INFO - 2018-08-14 14:13:59 --> Language Class Initialized
INFO - 2018-08-14 14:13:59 --> Language Class Initialized
INFO - 2018-08-14 14:13:59 --> Config Class Initialized
INFO - 2018-08-14 14:13:59 --> Loader Class Initialized
INFO - 2018-08-14 14:13:59 --> Helper loaded: url_helper
INFO - 2018-08-14 14:13:59 --> Helper loaded: file_helper
INFO - 2018-08-14 14:13:59 --> Helper loaded: form_helper
INFO - 2018-08-14 14:13:59 --> Helper loaded: my_helper
INFO - 2018-08-14 14:13:59 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:14:00 --> Controller Class Initialized
DEBUG - 2018-08-14 14:14:00 --> File loaded: D:\laragon\www\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2018-08-14 14:14:00 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:14:00 --> Final output sent to browser
DEBUG - 2018-08-14 14:14:00 --> Total execution time: 0.5107
INFO - 2018-08-14 14:14:00 --> Config Class Initialized
INFO - 2018-08-14 14:14:00 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:14:00 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:14:00 --> Utf8 Class Initialized
INFO - 2018-08-14 14:14:00 --> URI Class Initialized
INFO - 2018-08-14 14:14:00 --> Router Class Initialized
INFO - 2018-08-14 14:14:00 --> Output Class Initialized
INFO - 2018-08-14 14:14:00 --> Security Class Initialized
DEBUG - 2018-08-14 14:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:14:00 --> Input Class Initialized
INFO - 2018-08-14 14:14:00 --> Language Class Initialized
ERROR - 2018-08-14 14:14:00 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:14:00 --> Config Class Initialized
INFO - 2018-08-14 14:14:00 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:14:00 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:14:00 --> Utf8 Class Initialized
INFO - 2018-08-14 14:14:00 --> URI Class Initialized
INFO - 2018-08-14 14:14:00 --> Router Class Initialized
INFO - 2018-08-14 14:14:00 --> Output Class Initialized
INFO - 2018-08-14 14:14:00 --> Security Class Initialized
DEBUG - 2018-08-14 14:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:14:00 --> Input Class Initialized
INFO - 2018-08-14 14:14:00 --> Language Class Initialized
INFO - 2018-08-14 14:14:00 --> Language Class Initialized
INFO - 2018-08-14 14:14:00 --> Config Class Initialized
INFO - 2018-08-14 14:14:00 --> Loader Class Initialized
INFO - 2018-08-14 14:14:00 --> Helper loaded: url_helper
INFO - 2018-08-14 14:14:00 --> Helper loaded: file_helper
INFO - 2018-08-14 14:14:00 --> Helper loaded: form_helper
INFO - 2018-08-14 14:14:00 --> Helper loaded: my_helper
INFO - 2018-08-14 14:14:00 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:14:01 --> Controller Class Initialized
DEBUG - 2018-08-14 14:14:01 --> File loaded: D:\laragon\www\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2018-08-14 14:14:01 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:14:01 --> Final output sent to browser
DEBUG - 2018-08-14 14:14:01 --> Total execution time: 0.4852
INFO - 2018-08-14 14:14:01 --> Config Class Initialized
INFO - 2018-08-14 14:14:01 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:14:01 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:14:01 --> Utf8 Class Initialized
INFO - 2018-08-14 14:14:01 --> URI Class Initialized
INFO - 2018-08-14 14:14:01 --> Router Class Initialized
INFO - 2018-08-14 14:14:01 --> Output Class Initialized
INFO - 2018-08-14 14:14:01 --> Security Class Initialized
DEBUG - 2018-08-14 14:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:14:01 --> Input Class Initialized
INFO - 2018-08-14 14:14:01 --> Language Class Initialized
ERROR - 2018-08-14 14:14:01 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:14:01 --> Config Class Initialized
INFO - 2018-08-14 14:14:01 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:14:01 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:14:01 --> Utf8 Class Initialized
INFO - 2018-08-14 14:14:01 --> URI Class Initialized
INFO - 2018-08-14 14:14:01 --> Router Class Initialized
INFO - 2018-08-14 14:14:01 --> Output Class Initialized
INFO - 2018-08-14 14:14:01 --> Security Class Initialized
DEBUG - 2018-08-14 14:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:14:01 --> Input Class Initialized
INFO - 2018-08-14 14:14:01 --> Language Class Initialized
INFO - 2018-08-14 14:14:01 --> Language Class Initialized
INFO - 2018-08-14 14:14:01 --> Config Class Initialized
INFO - 2018-08-14 14:14:01 --> Loader Class Initialized
INFO - 2018-08-14 14:14:01 --> Helper loaded: url_helper
INFO - 2018-08-14 14:14:01 --> Helper loaded: file_helper
INFO - 2018-08-14 14:14:01 --> Helper loaded: form_helper
INFO - 2018-08-14 14:14:01 --> Helper loaded: my_helper
INFO - 2018-08-14 14:14:01 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:14:01 --> Controller Class Initialized
DEBUG - 2018-08-14 14:14:02 --> File loaded: D:\laragon\www\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2018-08-14 14:14:02 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:14:02 --> Final output sent to browser
DEBUG - 2018-08-14 14:14:02 --> Total execution time: 0.6190
INFO - 2018-08-14 14:14:02 --> Config Class Initialized
INFO - 2018-08-14 14:14:02 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:14:02 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:14:02 --> Utf8 Class Initialized
INFO - 2018-08-14 14:14:02 --> URI Class Initialized
INFO - 2018-08-14 14:14:02 --> Router Class Initialized
INFO - 2018-08-14 14:14:02 --> Output Class Initialized
INFO - 2018-08-14 14:14:02 --> Security Class Initialized
DEBUG - 2018-08-14 14:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:14:02 --> Input Class Initialized
INFO - 2018-08-14 14:14:02 --> Language Class Initialized
ERROR - 2018-08-14 14:14:02 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:14:02 --> Config Class Initialized
INFO - 2018-08-14 14:14:02 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:14:02 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:14:02 --> Utf8 Class Initialized
INFO - 2018-08-14 14:14:02 --> URI Class Initialized
INFO - 2018-08-14 14:14:02 --> Router Class Initialized
INFO - 2018-08-14 14:14:02 --> Output Class Initialized
INFO - 2018-08-14 14:14:02 --> Security Class Initialized
DEBUG - 2018-08-14 14:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:14:02 --> Input Class Initialized
INFO - 2018-08-14 14:14:02 --> Language Class Initialized
INFO - 2018-08-14 14:14:02 --> Language Class Initialized
INFO - 2018-08-14 14:14:02 --> Config Class Initialized
INFO - 2018-08-14 14:14:02 --> Loader Class Initialized
INFO - 2018-08-14 14:14:02 --> Helper loaded: url_helper
INFO - 2018-08-14 14:14:02 --> Helper loaded: file_helper
INFO - 2018-08-14 14:14:02 --> Helper loaded: form_helper
INFO - 2018-08-14 14:14:02 --> Helper loaded: my_helper
INFO - 2018-08-14 14:14:02 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:14:03 --> Controller Class Initialized
INFO - 2018-08-14 14:14:39 --> Config Class Initialized
INFO - 2018-08-14 14:14:39 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:14:39 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:14:39 --> Utf8 Class Initialized
INFO - 2018-08-14 14:14:39 --> URI Class Initialized
INFO - 2018-08-14 14:14:39 --> Router Class Initialized
INFO - 2018-08-14 14:14:39 --> Output Class Initialized
INFO - 2018-08-14 14:14:39 --> Security Class Initialized
DEBUG - 2018-08-14 14:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:14:39 --> Input Class Initialized
INFO - 2018-08-14 14:14:39 --> Language Class Initialized
INFO - 2018-08-14 14:14:39 --> Language Class Initialized
INFO - 2018-08-14 14:14:39 --> Config Class Initialized
INFO - 2018-08-14 14:14:39 --> Loader Class Initialized
INFO - 2018-08-14 14:14:39 --> Helper loaded: url_helper
INFO - 2018-08-14 14:14:39 --> Helper loaded: file_helper
INFO - 2018-08-14 14:14:39 --> Helper loaded: form_helper
INFO - 2018-08-14 14:14:39 --> Helper loaded: my_helper
INFO - 2018-08-14 14:14:39 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:14:39 --> Controller Class Initialized
DEBUG - 2018-08-14 14:14:39 --> File loaded: D:\laragon\www\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2018-08-14 14:14:39 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:14:39 --> Final output sent to browser
DEBUG - 2018-08-14 14:14:39 --> Total execution time: 0.5653
INFO - 2018-08-14 14:14:40 --> Config Class Initialized
INFO - 2018-08-14 14:14:40 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:14:40 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:14:40 --> Utf8 Class Initialized
INFO - 2018-08-14 14:14:40 --> URI Class Initialized
INFO - 2018-08-14 14:14:40 --> Router Class Initialized
INFO - 2018-08-14 14:14:40 --> Output Class Initialized
INFO - 2018-08-14 14:14:40 --> Security Class Initialized
DEBUG - 2018-08-14 14:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:14:40 --> Input Class Initialized
INFO - 2018-08-14 14:14:40 --> Language Class Initialized
ERROR - 2018-08-14 14:14:40 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:14:40 --> Config Class Initialized
INFO - 2018-08-14 14:14:40 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:14:40 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:14:40 --> Utf8 Class Initialized
INFO - 2018-08-14 14:14:40 --> URI Class Initialized
INFO - 2018-08-14 14:14:40 --> Router Class Initialized
INFO - 2018-08-14 14:14:40 --> Output Class Initialized
INFO - 2018-08-14 14:14:40 --> Security Class Initialized
DEBUG - 2018-08-14 14:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:14:40 --> Input Class Initialized
INFO - 2018-08-14 14:14:40 --> Language Class Initialized
INFO - 2018-08-14 14:14:40 --> Language Class Initialized
INFO - 2018-08-14 14:14:40 --> Config Class Initialized
INFO - 2018-08-14 14:14:40 --> Loader Class Initialized
INFO - 2018-08-14 14:14:40 --> Helper loaded: url_helper
INFO - 2018-08-14 14:14:40 --> Helper loaded: file_helper
INFO - 2018-08-14 14:14:40 --> Helper loaded: form_helper
INFO - 2018-08-14 14:14:40 --> Helper loaded: my_helper
INFO - 2018-08-14 14:14:41 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:14:41 --> Controller Class Initialized
INFO - 2018-08-14 14:14:42 --> Config Class Initialized
INFO - 2018-08-14 14:14:42 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:14:42 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:14:42 --> Utf8 Class Initialized
INFO - 2018-08-14 14:14:42 --> URI Class Initialized
INFO - 2018-08-14 14:14:42 --> Router Class Initialized
INFO - 2018-08-14 14:14:42 --> Output Class Initialized
INFO - 2018-08-14 14:14:42 --> Security Class Initialized
DEBUG - 2018-08-14 14:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:14:42 --> Input Class Initialized
INFO - 2018-08-14 14:14:42 --> Language Class Initialized
INFO - 2018-08-14 14:14:42 --> Language Class Initialized
INFO - 2018-08-14 14:14:42 --> Config Class Initialized
INFO - 2018-08-14 14:14:42 --> Loader Class Initialized
INFO - 2018-08-14 14:14:43 --> Helper loaded: url_helper
INFO - 2018-08-14 14:14:43 --> Helper loaded: file_helper
INFO - 2018-08-14 14:14:43 --> Helper loaded: form_helper
INFO - 2018-08-14 14:14:43 --> Helper loaded: my_helper
INFO - 2018-08-14 14:14:43 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:14:43 --> Controller Class Initialized
DEBUG - 2018-08-14 14:14:43 --> File loaded: D:\laragon\www\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2018-08-14 14:14:43 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:14:43 --> Final output sent to browser
DEBUG - 2018-08-14 14:14:43 --> Total execution time: 0.4765
INFO - 2018-08-14 14:14:43 --> Config Class Initialized
INFO - 2018-08-14 14:14:43 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:14:43 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:14:43 --> Utf8 Class Initialized
INFO - 2018-08-14 14:14:43 --> URI Class Initialized
INFO - 2018-08-14 14:14:43 --> Router Class Initialized
INFO - 2018-08-14 14:14:43 --> Output Class Initialized
INFO - 2018-08-14 14:14:43 --> Security Class Initialized
DEBUG - 2018-08-14 14:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:14:43 --> Input Class Initialized
INFO - 2018-08-14 14:14:43 --> Language Class Initialized
ERROR - 2018-08-14 14:14:43 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:14:43 --> Config Class Initialized
INFO - 2018-08-14 14:14:43 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:14:43 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:14:43 --> Utf8 Class Initialized
INFO - 2018-08-14 14:14:43 --> URI Class Initialized
INFO - 2018-08-14 14:14:43 --> Router Class Initialized
INFO - 2018-08-14 14:14:43 --> Output Class Initialized
INFO - 2018-08-14 14:14:43 --> Security Class Initialized
DEBUG - 2018-08-14 14:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:14:43 --> Input Class Initialized
INFO - 2018-08-14 14:14:43 --> Language Class Initialized
INFO - 2018-08-14 14:14:43 --> Language Class Initialized
INFO - 2018-08-14 14:14:43 --> Config Class Initialized
INFO - 2018-08-14 14:14:43 --> Loader Class Initialized
INFO - 2018-08-14 14:14:43 --> Helper loaded: url_helper
INFO - 2018-08-14 14:14:43 --> Helper loaded: file_helper
INFO - 2018-08-14 14:14:43 --> Helper loaded: form_helper
INFO - 2018-08-14 14:14:44 --> Helper loaded: my_helper
INFO - 2018-08-14 14:14:44 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:14:44 --> Controller Class Initialized
INFO - 2018-08-14 14:14:46 --> Config Class Initialized
INFO - 2018-08-14 14:14:46 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:14:46 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:14:46 --> Utf8 Class Initialized
INFO - 2018-08-14 14:14:46 --> URI Class Initialized
INFO - 2018-08-14 14:14:46 --> Router Class Initialized
INFO - 2018-08-14 14:14:46 --> Output Class Initialized
INFO - 2018-08-14 14:14:46 --> Security Class Initialized
DEBUG - 2018-08-14 14:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:14:46 --> Input Class Initialized
INFO - 2018-08-14 14:14:46 --> Language Class Initialized
INFO - 2018-08-14 14:14:46 --> Language Class Initialized
INFO - 2018-08-14 14:14:46 --> Config Class Initialized
INFO - 2018-08-14 14:14:46 --> Loader Class Initialized
INFO - 2018-08-14 14:14:46 --> Helper loaded: url_helper
INFO - 2018-08-14 14:14:46 --> Helper loaded: file_helper
INFO - 2018-08-14 14:14:46 --> Helper loaded: form_helper
INFO - 2018-08-14 14:14:46 --> Helper loaded: my_helper
INFO - 2018-08-14 14:14:46 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:14:46 --> Controller Class Initialized
INFO - 2018-08-14 14:14:46 --> Helper loaded: cookie_helper
INFO - 2018-08-14 14:14:46 --> Config Class Initialized
INFO - 2018-08-14 14:14:46 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:14:46 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:14:46 --> Utf8 Class Initialized
INFO - 2018-08-14 14:14:46 --> URI Class Initialized
INFO - 2018-08-14 14:14:46 --> Router Class Initialized
INFO - 2018-08-14 14:14:46 --> Output Class Initialized
INFO - 2018-08-14 14:14:46 --> Security Class Initialized
DEBUG - 2018-08-14 14:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:14:46 --> Input Class Initialized
INFO - 2018-08-14 14:14:46 --> Language Class Initialized
INFO - 2018-08-14 14:14:46 --> Language Class Initialized
INFO - 2018-08-14 14:14:46 --> Config Class Initialized
INFO - 2018-08-14 14:14:46 --> Loader Class Initialized
INFO - 2018-08-14 14:14:46 --> Helper loaded: url_helper
INFO - 2018-08-14 14:14:46 --> Helper loaded: file_helper
INFO - 2018-08-14 14:14:46 --> Helper loaded: form_helper
INFO - 2018-08-14 14:14:46 --> Helper loaded: my_helper
INFO - 2018-08-14 14:14:46 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:14:47 --> Controller Class Initialized
DEBUG - 2018-08-14 14:14:47 --> File loaded: D:\laragon\www\nilai\application\modules/home/views/v_home.php
DEBUG - 2018-08-14 14:14:47 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:14:47 --> Final output sent to browser
DEBUG - 2018-08-14 14:14:47 --> Total execution time: 0.5032
INFO - 2018-08-14 14:14:47 --> Config Class Initialized
INFO - 2018-08-14 14:14:47 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:14:47 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:14:47 --> Utf8 Class Initialized
INFO - 2018-08-14 14:14:47 --> URI Class Initialized
INFO - 2018-08-14 14:14:47 --> Router Class Initialized
INFO - 2018-08-14 14:14:47 --> Output Class Initialized
INFO - 2018-08-14 14:14:47 --> Security Class Initialized
DEBUG - 2018-08-14 14:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:14:47 --> Input Class Initialized
INFO - 2018-08-14 14:14:47 --> Language Class Initialized
ERROR - 2018-08-14 14:14:47 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:14:50 --> Config Class Initialized
INFO - 2018-08-14 14:14:50 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:14:50 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:14:50 --> Utf8 Class Initialized
INFO - 2018-08-14 14:14:51 --> URI Class Initialized
INFO - 2018-08-14 14:14:51 --> Router Class Initialized
INFO - 2018-08-14 14:14:51 --> Output Class Initialized
INFO - 2018-08-14 14:14:51 --> Security Class Initialized
DEBUG - 2018-08-14 14:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:14:51 --> Input Class Initialized
INFO - 2018-08-14 14:14:51 --> Language Class Initialized
INFO - 2018-08-14 14:14:51 --> Language Class Initialized
INFO - 2018-08-14 14:14:51 --> Config Class Initialized
INFO - 2018-08-14 14:14:51 --> Loader Class Initialized
INFO - 2018-08-14 14:14:51 --> Helper loaded: url_helper
INFO - 2018-08-14 14:14:51 --> Helper loaded: file_helper
INFO - 2018-08-14 14:14:51 --> Helper loaded: form_helper
INFO - 2018-08-14 14:14:51 --> Helper loaded: my_helper
INFO - 2018-08-14 14:14:51 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:14:51 --> Controller Class Initialized
DEBUG - 2018-08-14 14:14:51 --> File loaded: D:\laragon\www\nilai\application\modules/login/views/login.php
DEBUG - 2018-08-14 14:14:51 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:14:51 --> Final output sent to browser
DEBUG - 2018-08-14 14:14:51 --> Total execution time: 0.4851
INFO - 2018-08-14 14:14:51 --> Config Class Initialized
INFO - 2018-08-14 14:14:51 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:14:51 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:14:51 --> Utf8 Class Initialized
INFO - 2018-08-14 14:14:51 --> URI Class Initialized
INFO - 2018-08-14 14:14:51 --> Router Class Initialized
INFO - 2018-08-14 14:14:51 --> Output Class Initialized
INFO - 2018-08-14 14:14:51 --> Security Class Initialized
DEBUG - 2018-08-14 14:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:14:51 --> Input Class Initialized
INFO - 2018-08-14 14:14:51 --> Language Class Initialized
ERROR - 2018-08-14 14:14:51 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:14:53 --> Config Class Initialized
INFO - 2018-08-14 14:14:53 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:14:53 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:14:53 --> Utf8 Class Initialized
INFO - 2018-08-14 14:14:53 --> URI Class Initialized
DEBUG - 2018-08-14 14:14:53 --> No URI present. Default controller set.
INFO - 2018-08-14 14:14:53 --> Router Class Initialized
INFO - 2018-08-14 14:14:53 --> Output Class Initialized
INFO - 2018-08-14 14:14:53 --> Security Class Initialized
DEBUG - 2018-08-14 14:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:14:53 --> Input Class Initialized
INFO - 2018-08-14 14:14:53 --> Language Class Initialized
INFO - 2018-08-14 14:14:53 --> Language Class Initialized
INFO - 2018-08-14 14:14:53 --> Config Class Initialized
INFO - 2018-08-14 14:14:53 --> Loader Class Initialized
INFO - 2018-08-14 14:14:53 --> Helper loaded: url_helper
INFO - 2018-08-14 14:14:53 --> Helper loaded: file_helper
INFO - 2018-08-14 14:14:53 --> Helper loaded: form_helper
INFO - 2018-08-14 14:14:53 --> Helper loaded: my_helper
INFO - 2018-08-14 14:14:53 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:14:53 --> Controller Class Initialized
DEBUG - 2018-08-14 14:14:53 --> File loaded: D:\laragon\www\nilai\application\modules/home/views/v_home.php
DEBUG - 2018-08-14 14:14:53 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:14:53 --> Final output sent to browser
DEBUG - 2018-08-14 14:14:53 --> Total execution time: 0.6422
INFO - 2018-08-14 14:14:54 --> Config Class Initialized
INFO - 2018-08-14 14:14:54 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:14:54 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:14:54 --> Utf8 Class Initialized
INFO - 2018-08-14 14:14:54 --> URI Class Initialized
INFO - 2018-08-14 14:14:54 --> Router Class Initialized
INFO - 2018-08-14 14:14:54 --> Output Class Initialized
INFO - 2018-08-14 14:14:54 --> Security Class Initialized
DEBUG - 2018-08-14 14:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:14:54 --> Input Class Initialized
INFO - 2018-08-14 14:14:54 --> Language Class Initialized
ERROR - 2018-08-14 14:14:54 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:14:55 --> Config Class Initialized
INFO - 2018-08-14 14:14:55 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:14:55 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:14:55 --> Utf8 Class Initialized
INFO - 2018-08-14 14:14:55 --> URI Class Initialized
DEBUG - 2018-08-14 14:14:55 --> No URI present. Default controller set.
INFO - 2018-08-14 14:14:55 --> Router Class Initialized
INFO - 2018-08-14 14:14:55 --> Output Class Initialized
INFO - 2018-08-14 14:14:55 --> Security Class Initialized
DEBUG - 2018-08-14 14:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:14:55 --> Input Class Initialized
INFO - 2018-08-14 14:14:55 --> Language Class Initialized
INFO - 2018-08-14 14:14:55 --> Language Class Initialized
INFO - 2018-08-14 14:14:55 --> Config Class Initialized
INFO - 2018-08-14 14:14:55 --> Loader Class Initialized
INFO - 2018-08-14 14:14:55 --> Helper loaded: url_helper
INFO - 2018-08-14 14:14:55 --> Helper loaded: file_helper
INFO - 2018-08-14 14:14:55 --> Helper loaded: form_helper
INFO - 2018-08-14 14:14:55 --> Helper loaded: my_helper
INFO - 2018-08-14 14:14:55 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:14:55 --> Controller Class Initialized
DEBUG - 2018-08-14 14:14:56 --> File loaded: D:\laragon\www\nilai\application\modules/home/views/v_home.php
DEBUG - 2018-08-14 14:14:56 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:14:56 --> Final output sent to browser
DEBUG - 2018-08-14 14:14:56 --> Total execution time: 0.7388
INFO - 2018-08-14 14:14:56 --> Config Class Initialized
INFO - 2018-08-14 14:14:56 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:14:56 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:14:56 --> Utf8 Class Initialized
INFO - 2018-08-14 14:14:56 --> URI Class Initialized
INFO - 2018-08-14 14:14:56 --> Router Class Initialized
INFO - 2018-08-14 14:14:56 --> Output Class Initialized
INFO - 2018-08-14 14:14:56 --> Security Class Initialized
DEBUG - 2018-08-14 14:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:14:56 --> Input Class Initialized
INFO - 2018-08-14 14:14:56 --> Language Class Initialized
ERROR - 2018-08-14 14:14:56 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:15:22 --> Config Class Initialized
INFO - 2018-08-14 14:15:22 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:15:22 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:15:22 --> Utf8 Class Initialized
INFO - 2018-08-14 14:15:22 --> URI Class Initialized
DEBUG - 2018-08-14 14:15:22 --> No URI present. Default controller set.
INFO - 2018-08-14 14:15:22 --> Router Class Initialized
INFO - 2018-08-14 14:15:22 --> Output Class Initialized
INFO - 2018-08-14 14:15:22 --> Security Class Initialized
DEBUG - 2018-08-14 14:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:15:22 --> Input Class Initialized
INFO - 2018-08-14 14:15:22 --> Language Class Initialized
INFO - 2018-08-14 14:15:22 --> Language Class Initialized
INFO - 2018-08-14 14:15:22 --> Config Class Initialized
INFO - 2018-08-14 14:15:22 --> Loader Class Initialized
INFO - 2018-08-14 14:15:22 --> Helper loaded: url_helper
INFO - 2018-08-14 14:15:22 --> Helper loaded: file_helper
INFO - 2018-08-14 14:15:22 --> Helper loaded: form_helper
INFO - 2018-08-14 14:15:22 --> Helper loaded: my_helper
INFO - 2018-08-14 14:15:22 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:15:23 --> Controller Class Initialized
INFO - 2018-08-14 14:15:23 --> Config Class Initialized
INFO - 2018-08-14 14:15:23 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:15:23 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:15:23 --> Utf8 Class Initialized
INFO - 2018-08-14 14:15:23 --> URI Class Initialized
INFO - 2018-08-14 14:15:23 --> Router Class Initialized
INFO - 2018-08-14 14:15:23 --> Output Class Initialized
INFO - 2018-08-14 14:15:23 --> Security Class Initialized
DEBUG - 2018-08-14 14:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:15:23 --> Input Class Initialized
INFO - 2018-08-14 14:15:23 --> Language Class Initialized
INFO - 2018-08-14 14:15:23 --> Language Class Initialized
INFO - 2018-08-14 14:15:23 --> Config Class Initialized
INFO - 2018-08-14 14:15:23 --> Loader Class Initialized
INFO - 2018-08-14 14:15:23 --> Helper loaded: url_helper
INFO - 2018-08-14 14:15:23 --> Helper loaded: file_helper
INFO - 2018-08-14 14:15:23 --> Helper loaded: form_helper
INFO - 2018-08-14 14:15:23 --> Helper loaded: my_helper
INFO - 2018-08-14 14:15:23 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:15:23 --> Controller Class Initialized
DEBUG - 2018-08-14 14:15:23 --> File loaded: D:\laragon\www\nilai\application\modules/login/views/login.php
DEBUG - 2018-08-14 14:15:23 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:15:23 --> Final output sent to browser
DEBUG - 2018-08-14 14:15:24 --> Total execution time: 0.9127
INFO - 2018-08-14 14:15:24 --> Config Class Initialized
INFO - 2018-08-14 14:15:24 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:15:24 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:15:24 --> Utf8 Class Initialized
INFO - 2018-08-14 14:15:24 --> URI Class Initialized
INFO - 2018-08-14 14:15:24 --> Router Class Initialized
INFO - 2018-08-14 14:15:24 --> Output Class Initialized
INFO - 2018-08-14 14:15:24 --> Security Class Initialized
DEBUG - 2018-08-14 14:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:15:24 --> Input Class Initialized
INFO - 2018-08-14 14:15:24 --> Language Class Initialized
ERROR - 2018-08-14 14:15:24 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:15:33 --> Config Class Initialized
INFO - 2018-08-14 14:15:33 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:15:33 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:15:33 --> Utf8 Class Initialized
INFO - 2018-08-14 14:15:33 --> URI Class Initialized
INFO - 2018-08-14 14:15:33 --> Router Class Initialized
INFO - 2018-08-14 14:15:33 --> Output Class Initialized
INFO - 2018-08-14 14:15:33 --> Security Class Initialized
DEBUG - 2018-08-14 14:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:15:33 --> Input Class Initialized
INFO - 2018-08-14 14:15:33 --> Language Class Initialized
INFO - 2018-08-14 14:15:33 --> Language Class Initialized
INFO - 2018-08-14 14:15:33 --> Config Class Initialized
INFO - 2018-08-14 14:15:33 --> Loader Class Initialized
INFO - 2018-08-14 14:15:33 --> Helper loaded: url_helper
INFO - 2018-08-14 14:15:33 --> Helper loaded: file_helper
INFO - 2018-08-14 14:15:33 --> Helper loaded: form_helper
INFO - 2018-08-14 14:15:33 --> Helper loaded: my_helper
INFO - 2018-08-14 14:15:33 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:15:33 --> Controller Class Initialized
INFO - 2018-08-14 14:15:33 --> Helper loaded: cookie_helper
INFO - 2018-08-14 14:15:33 --> Final output sent to browser
DEBUG - 2018-08-14 14:15:33 --> Total execution time: 0.4736
INFO - 2018-08-14 14:15:34 --> Config Class Initialized
INFO - 2018-08-14 14:15:34 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:15:34 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:15:34 --> Utf8 Class Initialized
INFO - 2018-08-14 14:15:34 --> URI Class Initialized
INFO - 2018-08-14 14:15:34 --> Router Class Initialized
INFO - 2018-08-14 14:15:34 --> Output Class Initialized
INFO - 2018-08-14 14:15:34 --> Security Class Initialized
DEBUG - 2018-08-14 14:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:15:34 --> Input Class Initialized
INFO - 2018-08-14 14:15:34 --> Language Class Initialized
INFO - 2018-08-14 14:15:34 --> Language Class Initialized
INFO - 2018-08-14 14:15:34 --> Config Class Initialized
INFO - 2018-08-14 14:15:34 --> Loader Class Initialized
INFO - 2018-08-14 14:15:34 --> Helper loaded: url_helper
INFO - 2018-08-14 14:15:34 --> Helper loaded: file_helper
INFO - 2018-08-14 14:15:34 --> Helper loaded: form_helper
INFO - 2018-08-14 14:15:34 --> Helper loaded: my_helper
INFO - 2018-08-14 14:15:34 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:15:34 --> Controller Class Initialized
DEBUG - 2018-08-14 14:15:34 --> File loaded: D:\laragon\www\nilai\application\modules/home/views/v_home.php
DEBUG - 2018-08-14 14:15:34 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:15:34 --> Final output sent to browser
DEBUG - 2018-08-14 14:15:35 --> Total execution time: 0.5149
INFO - 2018-08-14 14:15:35 --> Config Class Initialized
INFO - 2018-08-14 14:15:35 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:15:35 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:15:35 --> Utf8 Class Initialized
INFO - 2018-08-14 14:15:35 --> URI Class Initialized
INFO - 2018-08-14 14:15:35 --> Router Class Initialized
INFO - 2018-08-14 14:15:35 --> Output Class Initialized
INFO - 2018-08-14 14:15:35 --> Security Class Initialized
DEBUG - 2018-08-14 14:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:15:35 --> Input Class Initialized
INFO - 2018-08-14 14:15:35 --> Language Class Initialized
ERROR - 2018-08-14 14:15:35 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:15:37 --> Config Class Initialized
INFO - 2018-08-14 14:15:37 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:15:37 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:15:37 --> Utf8 Class Initialized
INFO - 2018-08-14 14:15:37 --> URI Class Initialized
INFO - 2018-08-14 14:15:37 --> Router Class Initialized
INFO - 2018-08-14 14:15:37 --> Output Class Initialized
INFO - 2018-08-14 14:15:37 --> Security Class Initialized
DEBUG - 2018-08-14 14:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:15:37 --> Input Class Initialized
INFO - 2018-08-14 14:15:37 --> Language Class Initialized
INFO - 2018-08-14 14:15:37 --> Language Class Initialized
INFO - 2018-08-14 14:15:37 --> Config Class Initialized
INFO - 2018-08-14 14:15:37 --> Loader Class Initialized
INFO - 2018-08-14 14:15:37 --> Helper loaded: url_helper
INFO - 2018-08-14 14:15:37 --> Helper loaded: file_helper
INFO - 2018-08-14 14:15:37 --> Helper loaded: form_helper
INFO - 2018-08-14 14:15:37 --> Helper loaded: my_helper
INFO - 2018-08-14 14:15:37 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:15:37 --> Controller Class Initialized
DEBUG - 2018-08-14 14:15:37 --> File loaded: D:\laragon\www\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2018-08-14 14:15:37 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:15:38 --> Final output sent to browser
DEBUG - 2018-08-14 14:15:38 --> Total execution time: 0.6535
INFO - 2018-08-14 14:15:38 --> Config Class Initialized
INFO - 2018-08-14 14:15:38 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:15:38 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:15:38 --> Utf8 Class Initialized
INFO - 2018-08-14 14:15:38 --> URI Class Initialized
INFO - 2018-08-14 14:15:38 --> Router Class Initialized
INFO - 2018-08-14 14:15:38 --> Output Class Initialized
INFO - 2018-08-14 14:15:38 --> Security Class Initialized
DEBUG - 2018-08-14 14:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:15:38 --> Input Class Initialized
INFO - 2018-08-14 14:15:38 --> Language Class Initialized
ERROR - 2018-08-14 14:15:38 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:15:38 --> Config Class Initialized
INFO - 2018-08-14 14:15:38 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:15:38 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:15:38 --> Utf8 Class Initialized
INFO - 2018-08-14 14:15:38 --> URI Class Initialized
INFO - 2018-08-14 14:15:38 --> Router Class Initialized
INFO - 2018-08-14 14:15:38 --> Output Class Initialized
INFO - 2018-08-14 14:15:38 --> Security Class Initialized
DEBUG - 2018-08-14 14:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:15:38 --> Input Class Initialized
INFO - 2018-08-14 14:15:38 --> Language Class Initialized
INFO - 2018-08-14 14:15:38 --> Language Class Initialized
INFO - 2018-08-14 14:15:38 --> Config Class Initialized
INFO - 2018-08-14 14:15:38 --> Loader Class Initialized
INFO - 2018-08-14 14:15:38 --> Helper loaded: url_helper
INFO - 2018-08-14 14:15:38 --> Helper loaded: file_helper
INFO - 2018-08-14 14:15:38 --> Helper loaded: form_helper
INFO - 2018-08-14 14:15:38 --> Helper loaded: my_helper
INFO - 2018-08-14 14:15:38 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:15:38 --> Controller Class Initialized
INFO - 2018-08-14 14:15:38 --> Config Class Initialized
INFO - 2018-08-14 14:15:39 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:15:39 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:15:39 --> Utf8 Class Initialized
INFO - 2018-08-14 14:15:39 --> URI Class Initialized
INFO - 2018-08-14 14:15:39 --> Router Class Initialized
INFO - 2018-08-14 14:15:39 --> Output Class Initialized
INFO - 2018-08-14 14:15:39 --> Security Class Initialized
DEBUG - 2018-08-14 14:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:15:39 --> Input Class Initialized
INFO - 2018-08-14 14:15:39 --> Language Class Initialized
INFO - 2018-08-14 14:15:39 --> Language Class Initialized
INFO - 2018-08-14 14:15:39 --> Config Class Initialized
INFO - 2018-08-14 14:15:39 --> Loader Class Initialized
INFO - 2018-08-14 14:15:39 --> Helper loaded: url_helper
INFO - 2018-08-14 14:15:39 --> Helper loaded: file_helper
INFO - 2018-08-14 14:15:39 --> Helper loaded: form_helper
INFO - 2018-08-14 14:15:39 --> Helper loaded: my_helper
INFO - 2018-08-14 14:15:39 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:15:39 --> Controller Class Initialized
DEBUG - 2018-08-14 14:15:39 --> File loaded: D:\laragon\www\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2018-08-14 14:15:39 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:15:39 --> Final output sent to browser
DEBUG - 2018-08-14 14:15:39 --> Total execution time: 0.4802
INFO - 2018-08-14 14:15:39 --> Config Class Initialized
INFO - 2018-08-14 14:15:39 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:15:39 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:15:39 --> Utf8 Class Initialized
INFO - 2018-08-14 14:15:39 --> URI Class Initialized
INFO - 2018-08-14 14:15:39 --> Router Class Initialized
INFO - 2018-08-14 14:15:39 --> Output Class Initialized
INFO - 2018-08-14 14:15:39 --> Security Class Initialized
DEBUG - 2018-08-14 14:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:15:39 --> Input Class Initialized
INFO - 2018-08-14 14:15:39 --> Language Class Initialized
ERROR - 2018-08-14 14:15:39 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:15:39 --> Config Class Initialized
INFO - 2018-08-14 14:15:39 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:15:39 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:15:39 --> Utf8 Class Initialized
INFO - 2018-08-14 14:15:39 --> URI Class Initialized
INFO - 2018-08-14 14:15:40 --> Router Class Initialized
INFO - 2018-08-14 14:15:40 --> Output Class Initialized
INFO - 2018-08-14 14:15:40 --> Security Class Initialized
DEBUG - 2018-08-14 14:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:15:40 --> Input Class Initialized
INFO - 2018-08-14 14:15:40 --> Language Class Initialized
INFO - 2018-08-14 14:15:40 --> Language Class Initialized
INFO - 2018-08-14 14:15:40 --> Config Class Initialized
INFO - 2018-08-14 14:15:40 --> Loader Class Initialized
INFO - 2018-08-14 14:15:40 --> Helper loaded: url_helper
INFO - 2018-08-14 14:15:40 --> Helper loaded: file_helper
INFO - 2018-08-14 14:15:40 --> Helper loaded: form_helper
INFO - 2018-08-14 14:15:40 --> Helper loaded: my_helper
INFO - 2018-08-14 14:15:40 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:15:40 --> Controller Class Initialized
INFO - 2018-08-14 14:15:40 --> Config Class Initialized
INFO - 2018-08-14 14:15:40 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:15:40 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:15:40 --> Utf8 Class Initialized
INFO - 2018-08-14 14:15:40 --> URI Class Initialized
INFO - 2018-08-14 14:15:40 --> Router Class Initialized
INFO - 2018-08-14 14:15:40 --> Output Class Initialized
INFO - 2018-08-14 14:15:40 --> Security Class Initialized
DEBUG - 2018-08-14 14:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:15:40 --> Input Class Initialized
INFO - 2018-08-14 14:15:40 --> Language Class Initialized
INFO - 2018-08-14 14:15:40 --> Language Class Initialized
INFO - 2018-08-14 14:15:40 --> Config Class Initialized
INFO - 2018-08-14 14:15:40 --> Loader Class Initialized
INFO - 2018-08-14 14:15:40 --> Helper loaded: url_helper
INFO - 2018-08-14 14:15:40 --> Helper loaded: file_helper
INFO - 2018-08-14 14:15:40 --> Helper loaded: form_helper
INFO - 2018-08-14 14:15:40 --> Helper loaded: my_helper
INFO - 2018-08-14 14:15:40 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:15:41 --> Controller Class Initialized
DEBUG - 2018-08-14 14:15:41 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-14 14:15:41 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:15:41 --> Final output sent to browser
DEBUG - 2018-08-14 14:15:41 --> Total execution time: 0.8087
INFO - 2018-08-14 14:15:41 --> Config Class Initialized
INFO - 2018-08-14 14:15:41 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:15:41 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:15:41 --> Utf8 Class Initialized
INFO - 2018-08-14 14:15:41 --> URI Class Initialized
INFO - 2018-08-14 14:15:41 --> Router Class Initialized
INFO - 2018-08-14 14:15:41 --> Output Class Initialized
INFO - 2018-08-14 14:15:41 --> Security Class Initialized
DEBUG - 2018-08-14 14:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:15:41 --> Input Class Initialized
INFO - 2018-08-14 14:15:41 --> Language Class Initialized
ERROR - 2018-08-14 14:15:41 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:15:41 --> Config Class Initialized
INFO - 2018-08-14 14:15:41 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:15:41 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:15:41 --> Utf8 Class Initialized
INFO - 2018-08-14 14:15:41 --> URI Class Initialized
INFO - 2018-08-14 14:15:41 --> Router Class Initialized
INFO - 2018-08-14 14:15:41 --> Output Class Initialized
INFO - 2018-08-14 14:15:41 --> Security Class Initialized
DEBUG - 2018-08-14 14:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:15:41 --> Input Class Initialized
INFO - 2018-08-14 14:15:41 --> Language Class Initialized
INFO - 2018-08-14 14:15:41 --> Language Class Initialized
INFO - 2018-08-14 14:15:41 --> Config Class Initialized
INFO - 2018-08-14 14:15:41 --> Loader Class Initialized
INFO - 2018-08-14 14:15:41 --> Helper loaded: url_helper
INFO - 2018-08-14 14:15:41 --> Helper loaded: file_helper
INFO - 2018-08-14 14:15:41 --> Helper loaded: form_helper
INFO - 2018-08-14 14:15:41 --> Helper loaded: my_helper
INFO - 2018-08-14 14:15:41 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:15:42 --> Controller Class Initialized
INFO - 2018-08-14 14:15:43 --> Config Class Initialized
INFO - 2018-08-14 14:15:43 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:15:43 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:15:43 --> Utf8 Class Initialized
INFO - 2018-08-14 14:15:43 --> URI Class Initialized
INFO - 2018-08-14 14:15:43 --> Router Class Initialized
INFO - 2018-08-14 14:15:43 --> Output Class Initialized
INFO - 2018-08-14 14:15:43 --> Security Class Initialized
DEBUG - 2018-08-14 14:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:15:43 --> Input Class Initialized
INFO - 2018-08-14 14:15:43 --> Language Class Initialized
INFO - 2018-08-14 14:15:43 --> Language Class Initialized
INFO - 2018-08-14 14:15:43 --> Config Class Initialized
INFO - 2018-08-14 14:15:43 --> Loader Class Initialized
INFO - 2018-08-14 14:15:43 --> Helper loaded: url_helper
INFO - 2018-08-14 14:15:43 --> Helper loaded: file_helper
INFO - 2018-08-14 14:15:43 --> Helper loaded: form_helper
INFO - 2018-08-14 14:15:43 --> Helper loaded: my_helper
INFO - 2018-08-14 14:15:43 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:15:43 --> Controller Class Initialized
INFO - 2018-08-14 14:15:43 --> Final output sent to browser
DEBUG - 2018-08-14 14:15:43 --> Total execution time: 0.5285
INFO - 2018-08-14 14:15:44 --> Config Class Initialized
INFO - 2018-08-14 14:15:44 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:15:44 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:15:44 --> Utf8 Class Initialized
INFO - 2018-08-14 14:15:44 --> URI Class Initialized
INFO - 2018-08-14 14:15:44 --> Router Class Initialized
INFO - 2018-08-14 14:15:44 --> Output Class Initialized
INFO - 2018-08-14 14:15:44 --> Security Class Initialized
DEBUG - 2018-08-14 14:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:15:44 --> Input Class Initialized
INFO - 2018-08-14 14:15:44 --> Language Class Initialized
INFO - 2018-08-14 14:15:44 --> Language Class Initialized
INFO - 2018-08-14 14:15:44 --> Config Class Initialized
INFO - 2018-08-14 14:15:44 --> Loader Class Initialized
INFO - 2018-08-14 14:15:44 --> Helper loaded: url_helper
INFO - 2018-08-14 14:15:44 --> Helper loaded: file_helper
INFO - 2018-08-14 14:15:44 --> Helper loaded: form_helper
INFO - 2018-08-14 14:15:44 --> Helper loaded: my_helper
INFO - 2018-08-14 14:15:44 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:15:44 --> Controller Class Initialized
INFO - 2018-08-14 14:15:45 --> Config Class Initialized
INFO - 2018-08-14 14:15:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:15:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:15:45 --> Utf8 Class Initialized
INFO - 2018-08-14 14:15:45 --> URI Class Initialized
INFO - 2018-08-14 14:15:45 --> Router Class Initialized
INFO - 2018-08-14 14:15:45 --> Output Class Initialized
INFO - 2018-08-14 14:15:45 --> Security Class Initialized
DEBUG - 2018-08-14 14:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:15:45 --> Input Class Initialized
INFO - 2018-08-14 14:15:45 --> Language Class Initialized
INFO - 2018-08-14 14:15:45 --> Language Class Initialized
INFO - 2018-08-14 14:15:45 --> Config Class Initialized
INFO - 2018-08-14 14:15:45 --> Loader Class Initialized
INFO - 2018-08-14 14:15:45 --> Helper loaded: url_helper
INFO - 2018-08-14 14:15:45 --> Helper loaded: file_helper
INFO - 2018-08-14 14:15:45 --> Helper loaded: form_helper
INFO - 2018-08-14 14:15:45 --> Helper loaded: my_helper
INFO - 2018-08-14 14:15:45 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:15:45 --> Controller Class Initialized
INFO - 2018-08-14 14:15:46 --> Final output sent to browser
DEBUG - 2018-08-14 14:15:46 --> Total execution time: 0.5000
INFO - 2018-08-14 14:15:46 --> Config Class Initialized
INFO - 2018-08-14 14:15:46 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:15:46 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:15:46 --> Utf8 Class Initialized
INFO - 2018-08-14 14:15:46 --> URI Class Initialized
INFO - 2018-08-14 14:15:46 --> Router Class Initialized
INFO - 2018-08-14 14:15:46 --> Output Class Initialized
INFO - 2018-08-14 14:15:46 --> Security Class Initialized
DEBUG - 2018-08-14 14:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:15:46 --> Input Class Initialized
INFO - 2018-08-14 14:15:46 --> Language Class Initialized
INFO - 2018-08-14 14:15:46 --> Language Class Initialized
INFO - 2018-08-14 14:15:46 --> Config Class Initialized
INFO - 2018-08-14 14:15:46 --> Loader Class Initialized
INFO - 2018-08-14 14:15:46 --> Helper loaded: url_helper
INFO - 2018-08-14 14:15:46 --> Helper loaded: file_helper
INFO - 2018-08-14 14:15:46 --> Helper loaded: form_helper
INFO - 2018-08-14 14:15:46 --> Helper loaded: my_helper
INFO - 2018-08-14 14:15:46 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:15:46 --> Controller Class Initialized
INFO - 2018-08-14 14:15:47 --> Config Class Initialized
INFO - 2018-08-14 14:15:47 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:15:47 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:15:47 --> Utf8 Class Initialized
INFO - 2018-08-14 14:15:47 --> URI Class Initialized
INFO - 2018-08-14 14:15:47 --> Router Class Initialized
INFO - 2018-08-14 14:15:47 --> Output Class Initialized
INFO - 2018-08-14 14:15:47 --> Security Class Initialized
DEBUG - 2018-08-14 14:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:15:48 --> Input Class Initialized
INFO - 2018-08-14 14:15:48 --> Language Class Initialized
INFO - 2018-08-14 14:15:48 --> Language Class Initialized
INFO - 2018-08-14 14:15:48 --> Config Class Initialized
INFO - 2018-08-14 14:15:48 --> Loader Class Initialized
INFO - 2018-08-14 14:15:48 --> Helper loaded: url_helper
INFO - 2018-08-14 14:15:48 --> Helper loaded: file_helper
INFO - 2018-08-14 14:15:48 --> Helper loaded: form_helper
INFO - 2018-08-14 14:15:48 --> Helper loaded: my_helper
INFO - 2018-08-14 14:15:48 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:15:48 --> Controller Class Initialized
INFO - 2018-08-14 14:15:48 --> Final output sent to browser
DEBUG - 2018-08-14 14:15:48 --> Total execution time: 0.4651
INFO - 2018-08-14 14:15:48 --> Config Class Initialized
INFO - 2018-08-14 14:15:48 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:15:48 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:15:48 --> Utf8 Class Initialized
INFO - 2018-08-14 14:15:48 --> URI Class Initialized
INFO - 2018-08-14 14:15:48 --> Router Class Initialized
INFO - 2018-08-14 14:15:48 --> Output Class Initialized
INFO - 2018-08-14 14:15:48 --> Security Class Initialized
DEBUG - 2018-08-14 14:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:15:48 --> Input Class Initialized
INFO - 2018-08-14 14:15:48 --> Language Class Initialized
INFO - 2018-08-14 14:15:48 --> Language Class Initialized
INFO - 2018-08-14 14:15:48 --> Config Class Initialized
INFO - 2018-08-14 14:15:48 --> Loader Class Initialized
INFO - 2018-08-14 14:15:48 --> Helper loaded: url_helper
INFO - 2018-08-14 14:15:48 --> Helper loaded: file_helper
INFO - 2018-08-14 14:15:48 --> Helper loaded: form_helper
INFO - 2018-08-14 14:15:48 --> Helper loaded: my_helper
INFO - 2018-08-14 14:15:48 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:15:48 --> Controller Class Initialized
INFO - 2018-08-14 14:15:49 --> Config Class Initialized
INFO - 2018-08-14 14:15:49 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:15:49 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:15:49 --> Utf8 Class Initialized
INFO - 2018-08-14 14:15:49 --> URI Class Initialized
INFO - 2018-08-14 14:15:49 --> Router Class Initialized
INFO - 2018-08-14 14:15:49 --> Output Class Initialized
INFO - 2018-08-14 14:15:49 --> Security Class Initialized
DEBUG - 2018-08-14 14:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:15:49 --> Input Class Initialized
INFO - 2018-08-14 14:15:49 --> Language Class Initialized
INFO - 2018-08-14 14:15:49 --> Language Class Initialized
INFO - 2018-08-14 14:15:49 --> Config Class Initialized
INFO - 2018-08-14 14:15:49 --> Loader Class Initialized
INFO - 2018-08-14 14:15:49 --> Helper loaded: url_helper
INFO - 2018-08-14 14:15:49 --> Helper loaded: file_helper
INFO - 2018-08-14 14:15:49 --> Helper loaded: form_helper
INFO - 2018-08-14 14:15:49 --> Helper loaded: my_helper
INFO - 2018-08-14 14:15:49 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:15:50 --> Controller Class Initialized
INFO - 2018-08-14 14:15:50 --> Final output sent to browser
DEBUG - 2018-08-14 14:15:50 --> Total execution time: 0.4570
INFO - 2018-08-14 14:15:50 --> Config Class Initialized
INFO - 2018-08-14 14:15:50 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:15:50 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:15:50 --> Utf8 Class Initialized
INFO - 2018-08-14 14:15:50 --> URI Class Initialized
INFO - 2018-08-14 14:15:50 --> Router Class Initialized
INFO - 2018-08-14 14:15:50 --> Output Class Initialized
INFO - 2018-08-14 14:15:50 --> Security Class Initialized
DEBUG - 2018-08-14 14:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:15:50 --> Input Class Initialized
INFO - 2018-08-14 14:15:50 --> Language Class Initialized
INFO - 2018-08-14 14:15:50 --> Language Class Initialized
INFO - 2018-08-14 14:15:50 --> Config Class Initialized
INFO - 2018-08-14 14:15:50 --> Loader Class Initialized
INFO - 2018-08-14 14:15:50 --> Helper loaded: url_helper
INFO - 2018-08-14 14:15:50 --> Helper loaded: file_helper
INFO - 2018-08-14 14:15:50 --> Helper loaded: form_helper
INFO - 2018-08-14 14:15:50 --> Helper loaded: my_helper
INFO - 2018-08-14 14:15:50 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:15:50 --> Controller Class Initialized
INFO - 2018-08-14 14:15:55 --> Config Class Initialized
INFO - 2018-08-14 14:15:55 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:15:55 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:15:55 --> Utf8 Class Initialized
INFO - 2018-08-14 14:15:55 --> URI Class Initialized
INFO - 2018-08-14 14:15:55 --> Router Class Initialized
INFO - 2018-08-14 14:15:55 --> Output Class Initialized
INFO - 2018-08-14 14:15:55 --> Security Class Initialized
DEBUG - 2018-08-14 14:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:15:55 --> Input Class Initialized
INFO - 2018-08-14 14:15:55 --> Language Class Initialized
INFO - 2018-08-14 14:15:55 --> Language Class Initialized
INFO - 2018-08-14 14:15:55 --> Config Class Initialized
INFO - 2018-08-14 14:15:55 --> Loader Class Initialized
INFO - 2018-08-14 14:15:55 --> Helper loaded: url_helper
INFO - 2018-08-14 14:15:55 --> Helper loaded: file_helper
INFO - 2018-08-14 14:15:55 --> Helper loaded: form_helper
INFO - 2018-08-14 14:15:55 --> Helper loaded: my_helper
INFO - 2018-08-14 14:15:56 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:15:56 --> Controller Class Initialized
INFO - 2018-08-14 14:15:56 --> Helper loaded: cookie_helper
INFO - 2018-08-14 14:15:56 --> Config Class Initialized
INFO - 2018-08-14 14:15:56 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:15:56 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:15:56 --> Utf8 Class Initialized
INFO - 2018-08-14 14:15:56 --> URI Class Initialized
INFO - 2018-08-14 14:15:56 --> Router Class Initialized
INFO - 2018-08-14 14:15:56 --> Output Class Initialized
INFO - 2018-08-14 14:15:56 --> Security Class Initialized
DEBUG - 2018-08-14 14:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:15:56 --> Input Class Initialized
INFO - 2018-08-14 14:15:56 --> Language Class Initialized
INFO - 2018-08-14 14:15:56 --> Language Class Initialized
INFO - 2018-08-14 14:15:56 --> Config Class Initialized
INFO - 2018-08-14 14:15:56 --> Loader Class Initialized
INFO - 2018-08-14 14:15:56 --> Helper loaded: url_helper
INFO - 2018-08-14 14:15:56 --> Helper loaded: file_helper
INFO - 2018-08-14 14:15:56 --> Helper loaded: form_helper
INFO - 2018-08-14 14:15:56 --> Helper loaded: my_helper
INFO - 2018-08-14 14:15:56 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:15:56 --> Controller Class Initialized
INFO - 2018-08-14 14:15:56 --> Config Class Initialized
INFO - 2018-08-14 14:15:56 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:15:56 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:15:56 --> Utf8 Class Initialized
INFO - 2018-08-14 14:15:56 --> URI Class Initialized
INFO - 2018-08-14 14:15:56 --> Router Class Initialized
INFO - 2018-08-14 14:15:56 --> Output Class Initialized
INFO - 2018-08-14 14:15:56 --> Security Class Initialized
DEBUG - 2018-08-14 14:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:15:56 --> Input Class Initialized
INFO - 2018-08-14 14:15:56 --> Language Class Initialized
INFO - 2018-08-14 14:15:56 --> Language Class Initialized
INFO - 2018-08-14 14:15:56 --> Config Class Initialized
INFO - 2018-08-14 14:15:56 --> Loader Class Initialized
INFO - 2018-08-14 14:15:56 --> Helper loaded: url_helper
INFO - 2018-08-14 14:15:56 --> Helper loaded: file_helper
INFO - 2018-08-14 14:15:56 --> Helper loaded: form_helper
INFO - 2018-08-14 14:15:56 --> Helper loaded: my_helper
INFO - 2018-08-14 14:15:57 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:15:57 --> Controller Class Initialized
DEBUG - 2018-08-14 14:15:57 --> File loaded: D:\laragon\www\nilai\application\modules/login/views/login.php
DEBUG - 2018-08-14 14:15:57 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:15:57 --> Final output sent to browser
DEBUG - 2018-08-14 14:15:57 --> Total execution time: 0.5705
INFO - 2018-08-14 14:15:57 --> Config Class Initialized
INFO - 2018-08-14 14:15:57 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:15:57 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:15:57 --> Utf8 Class Initialized
INFO - 2018-08-14 14:15:57 --> URI Class Initialized
INFO - 2018-08-14 14:15:57 --> Router Class Initialized
INFO - 2018-08-14 14:15:57 --> Output Class Initialized
INFO - 2018-08-14 14:15:57 --> Security Class Initialized
DEBUG - 2018-08-14 14:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:15:57 --> Input Class Initialized
INFO - 2018-08-14 14:15:57 --> Language Class Initialized
ERROR - 2018-08-14 14:15:57 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:16:00 --> Config Class Initialized
INFO - 2018-08-14 14:16:01 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:16:01 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:16:01 --> Utf8 Class Initialized
INFO - 2018-08-14 14:16:01 --> URI Class Initialized
INFO - 2018-08-14 14:16:01 --> Router Class Initialized
INFO - 2018-08-14 14:16:01 --> Output Class Initialized
INFO - 2018-08-14 14:16:01 --> Security Class Initialized
DEBUG - 2018-08-14 14:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:16:01 --> Input Class Initialized
INFO - 2018-08-14 14:16:01 --> Language Class Initialized
INFO - 2018-08-14 14:16:01 --> Language Class Initialized
INFO - 2018-08-14 14:16:01 --> Config Class Initialized
INFO - 2018-08-14 14:16:01 --> Loader Class Initialized
INFO - 2018-08-14 14:16:01 --> Helper loaded: url_helper
INFO - 2018-08-14 14:16:01 --> Helper loaded: file_helper
INFO - 2018-08-14 14:16:01 --> Helper loaded: form_helper
INFO - 2018-08-14 14:16:01 --> Helper loaded: my_helper
INFO - 2018-08-14 14:16:01 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:16:01 --> Controller Class Initialized
INFO - 2018-08-14 14:16:01 --> Helper loaded: cookie_helper
INFO - 2018-08-14 14:16:01 --> Final output sent to browser
DEBUG - 2018-08-14 14:16:01 --> Total execution time: 0.6030
INFO - 2018-08-14 14:16:03 --> Config Class Initialized
INFO - 2018-08-14 14:16:03 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:16:03 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:16:03 --> Utf8 Class Initialized
INFO - 2018-08-14 14:16:03 --> URI Class Initialized
INFO - 2018-08-14 14:16:03 --> Router Class Initialized
INFO - 2018-08-14 14:16:03 --> Output Class Initialized
INFO - 2018-08-14 14:16:03 --> Security Class Initialized
DEBUG - 2018-08-14 14:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:16:03 --> Input Class Initialized
INFO - 2018-08-14 14:16:03 --> Language Class Initialized
INFO - 2018-08-14 14:16:03 --> Language Class Initialized
INFO - 2018-08-14 14:16:03 --> Config Class Initialized
INFO - 2018-08-14 14:16:03 --> Loader Class Initialized
INFO - 2018-08-14 14:16:03 --> Helper loaded: url_helper
INFO - 2018-08-14 14:16:03 --> Helper loaded: file_helper
INFO - 2018-08-14 14:16:03 --> Helper loaded: form_helper
INFO - 2018-08-14 14:16:03 --> Helper loaded: my_helper
INFO - 2018-08-14 14:16:03 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:16:03 --> Controller Class Initialized
DEBUG - 2018-08-14 14:16:03 --> File loaded: D:\laragon\www\nilai\application\modules/home/views/v_home.php
DEBUG - 2018-08-14 14:16:04 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:16:04 --> Final output sent to browser
DEBUG - 2018-08-14 14:16:04 --> Total execution time: 0.5392
INFO - 2018-08-14 14:16:04 --> Config Class Initialized
INFO - 2018-08-14 14:16:04 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:16:04 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:16:04 --> Utf8 Class Initialized
INFO - 2018-08-14 14:16:04 --> URI Class Initialized
INFO - 2018-08-14 14:16:04 --> Router Class Initialized
INFO - 2018-08-14 14:16:04 --> Output Class Initialized
INFO - 2018-08-14 14:16:04 --> Security Class Initialized
DEBUG - 2018-08-14 14:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:16:04 --> Input Class Initialized
INFO - 2018-08-14 14:16:04 --> Language Class Initialized
ERROR - 2018-08-14 14:16:04 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:16:07 --> Config Class Initialized
INFO - 2018-08-14 14:16:07 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:16:07 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:16:07 --> Utf8 Class Initialized
INFO - 2018-08-14 14:16:07 --> URI Class Initialized
DEBUG - 2018-08-14 14:16:07 --> No URI present. Default controller set.
INFO - 2018-08-14 14:16:07 --> Router Class Initialized
INFO - 2018-08-14 14:16:07 --> Output Class Initialized
INFO - 2018-08-14 14:16:07 --> Security Class Initialized
DEBUG - 2018-08-14 14:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:16:07 --> Input Class Initialized
INFO - 2018-08-14 14:16:07 --> Language Class Initialized
INFO - 2018-08-14 14:16:07 --> Language Class Initialized
INFO - 2018-08-14 14:16:07 --> Config Class Initialized
INFO - 2018-08-14 14:16:07 --> Loader Class Initialized
INFO - 2018-08-14 14:16:07 --> Helper loaded: url_helper
INFO - 2018-08-14 14:16:07 --> Helper loaded: file_helper
INFO - 2018-08-14 14:16:07 --> Helper loaded: form_helper
INFO - 2018-08-14 14:16:07 --> Helper loaded: my_helper
INFO - 2018-08-14 14:16:07 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:16:07 --> Controller Class Initialized
DEBUG - 2018-08-14 14:16:07 --> File loaded: D:\laragon\www\nilai\application\modules/home/views/v_home.php
DEBUG - 2018-08-14 14:16:07 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:16:07 --> Final output sent to browser
DEBUG - 2018-08-14 14:16:07 --> Total execution time: 0.5039
INFO - 2018-08-14 14:16:08 --> Config Class Initialized
INFO - 2018-08-14 14:16:08 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:16:08 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:16:08 --> Utf8 Class Initialized
INFO - 2018-08-14 14:16:08 --> URI Class Initialized
INFO - 2018-08-14 14:16:08 --> Router Class Initialized
INFO - 2018-08-14 14:16:08 --> Output Class Initialized
INFO - 2018-08-14 14:16:08 --> Security Class Initialized
DEBUG - 2018-08-14 14:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:16:08 --> Input Class Initialized
INFO - 2018-08-14 14:16:08 --> Language Class Initialized
ERROR - 2018-08-14 14:16:08 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:16:20 --> Config Class Initialized
INFO - 2018-08-14 14:16:20 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:16:20 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:16:20 --> Utf8 Class Initialized
INFO - 2018-08-14 14:16:20 --> URI Class Initialized
INFO - 2018-08-14 14:16:20 --> Router Class Initialized
INFO - 2018-08-14 14:16:20 --> Output Class Initialized
INFO - 2018-08-14 14:16:20 --> Security Class Initialized
DEBUG - 2018-08-14 14:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:16:20 --> Input Class Initialized
INFO - 2018-08-14 14:16:20 --> Language Class Initialized
INFO - 2018-08-14 14:16:21 --> Language Class Initialized
INFO - 2018-08-14 14:16:21 --> Config Class Initialized
INFO - 2018-08-14 14:16:21 --> Loader Class Initialized
INFO - 2018-08-14 14:16:21 --> Helper loaded: url_helper
INFO - 2018-08-14 14:16:21 --> Helper loaded: file_helper
INFO - 2018-08-14 14:16:21 --> Helper loaded: form_helper
INFO - 2018-08-14 14:16:21 --> Helper loaded: my_helper
INFO - 2018-08-14 14:16:21 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:16:21 --> Controller Class Initialized
DEBUG - 2018-08-14 14:16:21 --> File loaded: D:\laragon\www\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2018-08-14 14:16:21 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:16:21 --> Final output sent to browser
DEBUG - 2018-08-14 14:16:21 --> Total execution time: 0.5080
INFO - 2018-08-14 14:16:21 --> Config Class Initialized
INFO - 2018-08-14 14:16:21 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:16:21 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:16:21 --> Utf8 Class Initialized
INFO - 2018-08-14 14:16:21 --> URI Class Initialized
INFO - 2018-08-14 14:16:21 --> Router Class Initialized
INFO - 2018-08-14 14:16:21 --> Output Class Initialized
INFO - 2018-08-14 14:16:21 --> Security Class Initialized
DEBUG - 2018-08-14 14:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:16:21 --> Input Class Initialized
INFO - 2018-08-14 14:16:21 --> Language Class Initialized
ERROR - 2018-08-14 14:16:21 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:16:49 --> Config Class Initialized
INFO - 2018-08-14 14:16:49 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:16:49 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:16:49 --> Utf8 Class Initialized
INFO - 2018-08-14 14:16:49 --> URI Class Initialized
INFO - 2018-08-14 14:16:49 --> Router Class Initialized
INFO - 2018-08-14 14:16:49 --> Output Class Initialized
INFO - 2018-08-14 14:16:49 --> Security Class Initialized
DEBUG - 2018-08-14 14:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:16:50 --> Input Class Initialized
INFO - 2018-08-14 14:16:50 --> Language Class Initialized
INFO - 2018-08-14 14:16:50 --> Language Class Initialized
INFO - 2018-08-14 14:16:50 --> Config Class Initialized
INFO - 2018-08-14 14:16:50 --> Loader Class Initialized
INFO - 2018-08-14 14:16:50 --> Helper loaded: url_helper
INFO - 2018-08-14 14:16:50 --> Helper loaded: file_helper
INFO - 2018-08-14 14:16:50 --> Helper loaded: form_helper
INFO - 2018-08-14 14:16:50 --> Helper loaded: my_helper
INFO - 2018-08-14 14:16:50 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:16:50 --> Controller Class Initialized
DEBUG - 2018-08-14 14:16:50 --> File loaded: D:\laragon\www\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2018-08-14 14:16:50 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:16:50 --> Final output sent to browser
DEBUG - 2018-08-14 14:16:50 --> Total execution time: 0.5483
INFO - 2018-08-14 14:16:50 --> Config Class Initialized
INFO - 2018-08-14 14:16:50 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:16:50 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:16:50 --> Utf8 Class Initialized
INFO - 2018-08-14 14:16:50 --> URI Class Initialized
INFO - 2018-08-14 14:16:50 --> Router Class Initialized
INFO - 2018-08-14 14:16:50 --> Output Class Initialized
INFO - 2018-08-14 14:16:50 --> Security Class Initialized
DEBUG - 2018-08-14 14:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:16:50 --> Input Class Initialized
INFO - 2018-08-14 14:16:50 --> Language Class Initialized
ERROR - 2018-08-14 14:16:50 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:16:55 --> Config Class Initialized
INFO - 2018-08-14 14:16:55 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:16:55 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:16:55 --> Utf8 Class Initialized
INFO - 2018-08-14 14:16:55 --> URI Class Initialized
INFO - 2018-08-14 14:16:55 --> Router Class Initialized
INFO - 2018-08-14 14:16:55 --> Output Class Initialized
INFO - 2018-08-14 14:16:55 --> Security Class Initialized
DEBUG - 2018-08-14 14:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:16:55 --> Input Class Initialized
INFO - 2018-08-14 14:16:55 --> Language Class Initialized
INFO - 2018-08-14 14:16:56 --> Language Class Initialized
INFO - 2018-08-14 14:16:56 --> Config Class Initialized
INFO - 2018-08-14 14:16:56 --> Loader Class Initialized
INFO - 2018-08-14 14:16:56 --> Helper loaded: url_helper
INFO - 2018-08-14 14:16:56 --> Helper loaded: file_helper
INFO - 2018-08-14 14:16:56 --> Helper loaded: form_helper
INFO - 2018-08-14 14:16:56 --> Helper loaded: my_helper
INFO - 2018-08-14 14:16:56 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:16:56 --> Controller Class Initialized
DEBUG - 2018-08-14 14:16:56 --> File loaded: D:\laragon\www\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2018-08-14 14:16:56 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:16:56 --> Final output sent to browser
DEBUG - 2018-08-14 14:16:56 --> Total execution time: 0.5715
INFO - 2018-08-14 14:16:56 --> Config Class Initialized
INFO - 2018-08-14 14:16:56 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:16:56 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:16:56 --> Utf8 Class Initialized
INFO - 2018-08-14 14:16:56 --> URI Class Initialized
INFO - 2018-08-14 14:16:56 --> Router Class Initialized
INFO - 2018-08-14 14:16:56 --> Output Class Initialized
INFO - 2018-08-14 14:16:56 --> Security Class Initialized
DEBUG - 2018-08-14 14:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:16:56 --> Input Class Initialized
INFO - 2018-08-14 14:16:56 --> Language Class Initialized
ERROR - 2018-08-14 14:16:56 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:16:57 --> Config Class Initialized
INFO - 2018-08-14 14:16:57 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:16:57 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:16:57 --> Utf8 Class Initialized
INFO - 2018-08-14 14:16:57 --> URI Class Initialized
DEBUG - 2018-08-14 14:16:57 --> No URI present. Default controller set.
INFO - 2018-08-14 14:16:57 --> Router Class Initialized
INFO - 2018-08-14 14:16:57 --> Output Class Initialized
INFO - 2018-08-14 14:16:57 --> Security Class Initialized
DEBUG - 2018-08-14 14:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:16:57 --> Input Class Initialized
INFO - 2018-08-14 14:16:57 --> Language Class Initialized
INFO - 2018-08-14 14:16:57 --> Language Class Initialized
INFO - 2018-08-14 14:16:57 --> Config Class Initialized
INFO - 2018-08-14 14:16:57 --> Loader Class Initialized
INFO - 2018-08-14 14:16:57 --> Helper loaded: url_helper
INFO - 2018-08-14 14:16:57 --> Helper loaded: file_helper
INFO - 2018-08-14 14:16:57 --> Helper loaded: form_helper
INFO - 2018-08-14 14:16:57 --> Helper loaded: my_helper
INFO - 2018-08-14 14:16:57 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:16:57 --> Controller Class Initialized
DEBUG - 2018-08-14 14:16:57 --> File loaded: D:\laragon\www\nilai\application\modules/home/views/v_home.php
DEBUG - 2018-08-14 14:16:57 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:16:57 --> Final output sent to browser
DEBUG - 2018-08-14 14:16:57 --> Total execution time: 0.4999
INFO - 2018-08-14 14:16:58 --> Config Class Initialized
INFO - 2018-08-14 14:16:58 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:16:58 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:16:58 --> Utf8 Class Initialized
INFO - 2018-08-14 14:16:58 --> URI Class Initialized
INFO - 2018-08-14 14:16:58 --> Router Class Initialized
INFO - 2018-08-14 14:16:58 --> Output Class Initialized
INFO - 2018-08-14 14:16:58 --> Security Class Initialized
DEBUG - 2018-08-14 14:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:16:58 --> Input Class Initialized
INFO - 2018-08-14 14:16:58 --> Language Class Initialized
ERROR - 2018-08-14 14:16:58 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:16:58 --> Config Class Initialized
INFO - 2018-08-14 14:16:58 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:16:58 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:16:58 --> Utf8 Class Initialized
INFO - 2018-08-14 14:16:58 --> URI Class Initialized
INFO - 2018-08-14 14:16:58 --> Router Class Initialized
INFO - 2018-08-14 14:16:58 --> Output Class Initialized
INFO - 2018-08-14 14:16:58 --> Security Class Initialized
DEBUG - 2018-08-14 14:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:16:58 --> Input Class Initialized
INFO - 2018-08-14 14:16:58 --> Language Class Initialized
INFO - 2018-08-14 14:16:58 --> Language Class Initialized
INFO - 2018-08-14 14:16:58 --> Config Class Initialized
INFO - 2018-08-14 14:16:58 --> Loader Class Initialized
INFO - 2018-08-14 14:16:58 --> Helper loaded: url_helper
INFO - 2018-08-14 14:16:58 --> Helper loaded: file_helper
INFO - 2018-08-14 14:16:58 --> Helper loaded: form_helper
INFO - 2018-08-14 14:16:59 --> Helper loaded: my_helper
INFO - 2018-08-14 14:16:59 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:16:59 --> Controller Class Initialized
DEBUG - 2018-08-14 14:16:59 --> File loaded: D:\laragon\www\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2018-08-14 14:16:59 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:16:59 --> Final output sent to browser
DEBUG - 2018-08-14 14:16:59 --> Total execution time: 0.7005
INFO - 2018-08-14 14:16:59 --> Config Class Initialized
INFO - 2018-08-14 14:16:59 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:16:59 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:16:59 --> Utf8 Class Initialized
INFO - 2018-08-14 14:16:59 --> URI Class Initialized
INFO - 2018-08-14 14:16:59 --> Router Class Initialized
INFO - 2018-08-14 14:16:59 --> Output Class Initialized
INFO - 2018-08-14 14:16:59 --> Security Class Initialized
DEBUG - 2018-08-14 14:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:16:59 --> Input Class Initialized
INFO - 2018-08-14 14:16:59 --> Language Class Initialized
ERROR - 2018-08-14 14:16:59 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:17:00 --> Config Class Initialized
INFO - 2018-08-14 14:17:00 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:17:00 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:17:00 --> Utf8 Class Initialized
INFO - 2018-08-14 14:17:00 --> URI Class Initialized
INFO - 2018-08-14 14:17:00 --> Router Class Initialized
INFO - 2018-08-14 14:17:00 --> Output Class Initialized
INFO - 2018-08-14 14:17:00 --> Security Class Initialized
DEBUG - 2018-08-14 14:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:17:00 --> Input Class Initialized
INFO - 2018-08-14 14:17:00 --> Language Class Initialized
INFO - 2018-08-14 14:17:00 --> Language Class Initialized
INFO - 2018-08-14 14:17:00 --> Config Class Initialized
INFO - 2018-08-14 14:17:00 --> Loader Class Initialized
INFO - 2018-08-14 14:17:00 --> Helper loaded: url_helper
INFO - 2018-08-14 14:17:00 --> Helper loaded: file_helper
INFO - 2018-08-14 14:17:01 --> Helper loaded: form_helper
INFO - 2018-08-14 14:17:01 --> Helper loaded: my_helper
INFO - 2018-08-14 14:17:01 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:17:01 --> Controller Class Initialized
DEBUG - 2018-08-14 14:17:01 --> File loaded: D:\laragon\www\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2018-08-14 14:17:01 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:17:01 --> Final output sent to browser
DEBUG - 2018-08-14 14:17:01 --> Total execution time: 0.6468
INFO - 2018-08-14 14:17:01 --> Config Class Initialized
INFO - 2018-08-14 14:17:01 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:17:01 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:17:01 --> Utf8 Class Initialized
INFO - 2018-08-14 14:17:01 --> URI Class Initialized
INFO - 2018-08-14 14:17:01 --> Router Class Initialized
INFO - 2018-08-14 14:17:01 --> Output Class Initialized
INFO - 2018-08-14 14:17:01 --> Security Class Initialized
DEBUG - 2018-08-14 14:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:17:01 --> Input Class Initialized
INFO - 2018-08-14 14:17:01 --> Language Class Initialized
ERROR - 2018-08-14 14:17:01 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:17:04 --> Config Class Initialized
INFO - 2018-08-14 14:17:04 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:17:04 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:17:04 --> Utf8 Class Initialized
INFO - 2018-08-14 14:17:04 --> URI Class Initialized
INFO - 2018-08-14 14:17:04 --> Router Class Initialized
INFO - 2018-08-14 14:17:04 --> Output Class Initialized
INFO - 2018-08-14 14:17:04 --> Security Class Initialized
DEBUG - 2018-08-14 14:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:17:04 --> Input Class Initialized
INFO - 2018-08-14 14:17:04 --> Language Class Initialized
INFO - 2018-08-14 14:17:04 --> Language Class Initialized
INFO - 2018-08-14 14:17:04 --> Config Class Initialized
INFO - 2018-08-14 14:17:04 --> Loader Class Initialized
INFO - 2018-08-14 14:17:04 --> Helper loaded: url_helper
INFO - 2018-08-14 14:17:04 --> Helper loaded: file_helper
INFO - 2018-08-14 14:17:04 --> Helper loaded: form_helper
INFO - 2018-08-14 14:17:04 --> Helper loaded: my_helper
INFO - 2018-08-14 14:17:04 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:17:04 --> Controller Class Initialized
INFO - 2018-08-14 14:17:04 --> Final output sent to browser
DEBUG - 2018-08-14 14:17:04 --> Total execution time: 0.4696
INFO - 2018-08-14 14:17:07 --> Config Class Initialized
INFO - 2018-08-14 14:17:07 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:17:07 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:17:07 --> Utf8 Class Initialized
INFO - 2018-08-14 14:17:07 --> URI Class Initialized
INFO - 2018-08-14 14:17:07 --> Router Class Initialized
INFO - 2018-08-14 14:17:07 --> Output Class Initialized
INFO - 2018-08-14 14:17:07 --> Security Class Initialized
DEBUG - 2018-08-14 14:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:17:07 --> Input Class Initialized
INFO - 2018-08-14 14:17:07 --> Language Class Initialized
INFO - 2018-08-14 14:17:07 --> Language Class Initialized
INFO - 2018-08-14 14:17:07 --> Config Class Initialized
INFO - 2018-08-14 14:17:07 --> Loader Class Initialized
INFO - 2018-08-14 14:17:07 --> Helper loaded: url_helper
INFO - 2018-08-14 14:17:07 --> Helper loaded: file_helper
INFO - 2018-08-14 14:17:08 --> Helper loaded: form_helper
INFO - 2018-08-14 14:17:08 --> Helper loaded: my_helper
INFO - 2018-08-14 14:17:08 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:17:08 --> Controller Class Initialized
DEBUG - 2018-08-14 14:17:08 --> File loaded: D:\laragon\www\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2018-08-14 14:17:08 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:17:08 --> Final output sent to browser
DEBUG - 2018-08-14 14:17:08 --> Total execution time: 0.5170
INFO - 2018-08-14 14:17:08 --> Config Class Initialized
INFO - 2018-08-14 14:17:08 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:17:08 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:17:08 --> Utf8 Class Initialized
INFO - 2018-08-14 14:17:08 --> URI Class Initialized
INFO - 2018-08-14 14:17:08 --> Router Class Initialized
INFO - 2018-08-14 14:17:08 --> Output Class Initialized
INFO - 2018-08-14 14:17:08 --> Security Class Initialized
DEBUG - 2018-08-14 14:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:17:08 --> Input Class Initialized
INFO - 2018-08-14 14:17:08 --> Language Class Initialized
ERROR - 2018-08-14 14:17:08 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:17:10 --> Config Class Initialized
INFO - 2018-08-14 14:17:10 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:17:10 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:17:10 --> Utf8 Class Initialized
INFO - 2018-08-14 14:17:10 --> URI Class Initialized
INFO - 2018-08-14 14:17:10 --> Router Class Initialized
INFO - 2018-08-14 14:17:10 --> Output Class Initialized
INFO - 2018-08-14 14:17:10 --> Security Class Initialized
DEBUG - 2018-08-14 14:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:17:10 --> Input Class Initialized
INFO - 2018-08-14 14:17:10 --> Language Class Initialized
INFO - 2018-08-14 14:17:10 --> Language Class Initialized
INFO - 2018-08-14 14:17:10 --> Config Class Initialized
INFO - 2018-08-14 14:17:11 --> Loader Class Initialized
INFO - 2018-08-14 14:17:11 --> Helper loaded: url_helper
INFO - 2018-08-14 14:17:11 --> Helper loaded: file_helper
INFO - 2018-08-14 14:17:11 --> Helper loaded: form_helper
INFO - 2018-08-14 14:17:11 --> Helper loaded: my_helper
INFO - 2018-08-14 14:17:11 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:17:11 --> Controller Class Initialized
DEBUG - 2018-08-14 14:17:11 --> File loaded: D:\laragon\www\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2018-08-14 14:17:11 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:17:11 --> Final output sent to browser
DEBUG - 2018-08-14 14:17:11 --> Total execution time: 0.8511
INFO - 2018-08-14 14:17:11 --> Config Class Initialized
INFO - 2018-08-14 14:17:11 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:17:11 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:17:11 --> Utf8 Class Initialized
INFO - 2018-08-14 14:17:11 --> URI Class Initialized
INFO - 2018-08-14 14:17:11 --> Router Class Initialized
INFO - 2018-08-14 14:17:11 --> Output Class Initialized
INFO - 2018-08-14 14:17:11 --> Security Class Initialized
DEBUG - 2018-08-14 14:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:17:11 --> Input Class Initialized
INFO - 2018-08-14 14:17:11 --> Language Class Initialized
ERROR - 2018-08-14 14:17:11 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:17:13 --> Config Class Initialized
INFO - 2018-08-14 14:17:13 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:17:13 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:17:13 --> Utf8 Class Initialized
INFO - 2018-08-14 14:17:13 --> URI Class Initialized
INFO - 2018-08-14 14:17:13 --> Router Class Initialized
INFO - 2018-08-14 14:17:13 --> Output Class Initialized
INFO - 2018-08-14 14:17:13 --> Security Class Initialized
DEBUG - 2018-08-14 14:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:17:13 --> Input Class Initialized
INFO - 2018-08-14 14:17:13 --> Language Class Initialized
INFO - 2018-08-14 14:17:13 --> Language Class Initialized
INFO - 2018-08-14 14:17:13 --> Config Class Initialized
INFO - 2018-08-14 14:17:13 --> Loader Class Initialized
INFO - 2018-08-14 14:17:13 --> Helper loaded: url_helper
INFO - 2018-08-14 14:17:13 --> Helper loaded: file_helper
INFO - 2018-08-14 14:17:13 --> Helper loaded: form_helper
INFO - 2018-08-14 14:17:13 --> Helper loaded: my_helper
INFO - 2018-08-14 14:17:13 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:17:13 --> Controller Class Initialized
INFO - 2018-08-14 14:17:13 --> Final output sent to browser
DEBUG - 2018-08-14 14:17:13 --> Total execution time: 0.6594
INFO - 2018-08-14 14:17:15 --> Config Class Initialized
INFO - 2018-08-14 14:17:15 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:17:15 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:17:15 --> Utf8 Class Initialized
INFO - 2018-08-14 14:17:15 --> URI Class Initialized
INFO - 2018-08-14 14:17:15 --> Router Class Initialized
INFO - 2018-08-14 14:17:15 --> Output Class Initialized
INFO - 2018-08-14 14:17:15 --> Security Class Initialized
DEBUG - 2018-08-14 14:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:17:15 --> Input Class Initialized
INFO - 2018-08-14 14:17:15 --> Language Class Initialized
INFO - 2018-08-14 14:17:15 --> Language Class Initialized
INFO - 2018-08-14 14:17:15 --> Config Class Initialized
INFO - 2018-08-14 14:17:15 --> Loader Class Initialized
INFO - 2018-08-14 14:17:15 --> Helper loaded: url_helper
INFO - 2018-08-14 14:17:15 --> Helper loaded: file_helper
INFO - 2018-08-14 14:17:15 --> Helper loaded: form_helper
INFO - 2018-08-14 14:17:15 --> Helper loaded: my_helper
INFO - 2018-08-14 14:17:15 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:17:15 --> Controller Class Initialized
INFO - 2018-08-14 14:17:15 --> Final output sent to browser
DEBUG - 2018-08-14 14:17:15 --> Total execution time: 0.5079
INFO - 2018-08-14 14:17:28 --> Config Class Initialized
INFO - 2018-08-14 14:17:28 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:17:28 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:17:28 --> Utf8 Class Initialized
INFO - 2018-08-14 14:17:28 --> URI Class Initialized
INFO - 2018-08-14 14:17:28 --> Router Class Initialized
INFO - 2018-08-14 14:17:28 --> Output Class Initialized
INFO - 2018-08-14 14:17:28 --> Security Class Initialized
DEBUG - 2018-08-14 14:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:17:28 --> Input Class Initialized
INFO - 2018-08-14 14:17:28 --> Language Class Initialized
INFO - 2018-08-14 14:17:28 --> Language Class Initialized
INFO - 2018-08-14 14:17:28 --> Config Class Initialized
INFO - 2018-08-14 14:17:28 --> Loader Class Initialized
INFO - 2018-08-14 14:17:28 --> Helper loaded: url_helper
INFO - 2018-08-14 14:17:28 --> Helper loaded: file_helper
INFO - 2018-08-14 14:17:28 --> Helper loaded: form_helper
INFO - 2018-08-14 14:17:28 --> Helper loaded: my_helper
INFO - 2018-08-14 14:17:28 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:17:28 --> Controller Class Initialized
INFO - 2018-08-14 14:17:28 --> Final output sent to browser
DEBUG - 2018-08-14 14:17:28 --> Total execution time: 0.5208
INFO - 2018-08-14 14:17:29 --> Config Class Initialized
INFO - 2018-08-14 14:17:29 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:17:29 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:17:29 --> Utf8 Class Initialized
INFO - 2018-08-14 14:17:29 --> URI Class Initialized
INFO - 2018-08-14 14:17:29 --> Router Class Initialized
INFO - 2018-08-14 14:17:29 --> Output Class Initialized
INFO - 2018-08-14 14:17:29 --> Security Class Initialized
DEBUG - 2018-08-14 14:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:17:29 --> Input Class Initialized
INFO - 2018-08-14 14:17:29 --> Language Class Initialized
INFO - 2018-08-14 14:17:29 --> Language Class Initialized
INFO - 2018-08-14 14:17:29 --> Config Class Initialized
INFO - 2018-08-14 14:17:29 --> Loader Class Initialized
INFO - 2018-08-14 14:17:29 --> Helper loaded: url_helper
INFO - 2018-08-14 14:17:29 --> Helper loaded: file_helper
INFO - 2018-08-14 14:17:29 --> Helper loaded: form_helper
INFO - 2018-08-14 14:17:29 --> Helper loaded: my_helper
INFO - 2018-08-14 14:17:29 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:17:30 --> Controller Class Initialized
DEBUG - 2018-08-14 14:17:30 --> File loaded: D:\laragon\www\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2018-08-14 14:17:30 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:17:30 --> Final output sent to browser
DEBUG - 2018-08-14 14:17:30 --> Total execution time: 1.1068
INFO - 2018-08-14 14:17:30 --> Config Class Initialized
INFO - 2018-08-14 14:17:30 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:17:30 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:17:30 --> Utf8 Class Initialized
INFO - 2018-08-14 14:17:30 --> URI Class Initialized
INFO - 2018-08-14 14:17:30 --> Router Class Initialized
INFO - 2018-08-14 14:17:30 --> Output Class Initialized
INFO - 2018-08-14 14:17:30 --> Security Class Initialized
DEBUG - 2018-08-14 14:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:17:30 --> Input Class Initialized
INFO - 2018-08-14 14:17:30 --> Language Class Initialized
ERROR - 2018-08-14 14:17:30 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:17:32 --> Config Class Initialized
INFO - 2018-08-14 14:17:32 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:17:32 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:17:32 --> Utf8 Class Initialized
INFO - 2018-08-14 14:17:32 --> URI Class Initialized
INFO - 2018-08-14 14:17:32 --> Router Class Initialized
INFO - 2018-08-14 14:17:32 --> Output Class Initialized
INFO - 2018-08-14 14:17:32 --> Security Class Initialized
DEBUG - 2018-08-14 14:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:17:32 --> Input Class Initialized
INFO - 2018-08-14 14:17:32 --> Language Class Initialized
INFO - 2018-08-14 14:17:32 --> Language Class Initialized
INFO - 2018-08-14 14:17:32 --> Config Class Initialized
INFO - 2018-08-14 14:17:32 --> Loader Class Initialized
INFO - 2018-08-14 14:17:32 --> Helper loaded: url_helper
INFO - 2018-08-14 14:17:33 --> Helper loaded: file_helper
INFO - 2018-08-14 14:17:33 --> Helper loaded: form_helper
INFO - 2018-08-14 14:17:33 --> Helper loaded: my_helper
INFO - 2018-08-14 14:17:33 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:17:33 --> Controller Class Initialized
INFO - 2018-08-14 14:17:33 --> Final output sent to browser
DEBUG - 2018-08-14 14:17:33 --> Total execution time: 0.4922
INFO - 2018-08-14 14:17:45 --> Config Class Initialized
INFO - 2018-08-14 14:17:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:17:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:17:45 --> Utf8 Class Initialized
INFO - 2018-08-14 14:17:45 --> URI Class Initialized
INFO - 2018-08-14 14:17:45 --> Router Class Initialized
INFO - 2018-08-14 14:17:45 --> Output Class Initialized
INFO - 2018-08-14 14:17:45 --> Security Class Initialized
DEBUG - 2018-08-14 14:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:17:45 --> Input Class Initialized
INFO - 2018-08-14 14:17:45 --> Language Class Initialized
INFO - 2018-08-14 14:17:45 --> Language Class Initialized
INFO - 2018-08-14 14:17:45 --> Config Class Initialized
INFO - 2018-08-14 14:17:45 --> Loader Class Initialized
INFO - 2018-08-14 14:17:45 --> Helper loaded: url_helper
INFO - 2018-08-14 14:17:45 --> Helper loaded: file_helper
INFO - 2018-08-14 14:17:45 --> Helper loaded: form_helper
INFO - 2018-08-14 14:17:45 --> Helper loaded: my_helper
INFO - 2018-08-14 14:17:45 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:17:45 --> Controller Class Initialized
INFO - 2018-08-14 14:17:45 --> Final output sent to browser
DEBUG - 2018-08-14 14:17:45 --> Total execution time: 0.5952
INFO - 2018-08-14 14:17:45 --> Config Class Initialized
INFO - 2018-08-14 14:17:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:17:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:17:45 --> Utf8 Class Initialized
INFO - 2018-08-14 14:17:46 --> URI Class Initialized
INFO - 2018-08-14 14:17:46 --> Router Class Initialized
INFO - 2018-08-14 14:17:46 --> Output Class Initialized
INFO - 2018-08-14 14:17:46 --> Security Class Initialized
DEBUG - 2018-08-14 14:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:17:46 --> Input Class Initialized
INFO - 2018-08-14 14:17:46 --> Language Class Initialized
INFO - 2018-08-14 14:17:46 --> Language Class Initialized
INFO - 2018-08-14 14:17:46 --> Config Class Initialized
INFO - 2018-08-14 14:17:46 --> Loader Class Initialized
INFO - 2018-08-14 14:17:46 --> Helper loaded: url_helper
INFO - 2018-08-14 14:17:46 --> Helper loaded: file_helper
INFO - 2018-08-14 14:17:46 --> Helper loaded: form_helper
INFO - 2018-08-14 14:17:46 --> Helper loaded: my_helper
INFO - 2018-08-14 14:17:46 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:17:46 --> Controller Class Initialized
DEBUG - 2018-08-14 14:17:46 --> File loaded: D:\laragon\www\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2018-08-14 14:17:46 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:17:46 --> Final output sent to browser
DEBUG - 2018-08-14 14:17:46 --> Total execution time: 0.7337
INFO - 2018-08-14 14:17:46 --> Config Class Initialized
INFO - 2018-08-14 14:17:46 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:17:46 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:17:46 --> Utf8 Class Initialized
INFO - 2018-08-14 14:17:46 --> URI Class Initialized
INFO - 2018-08-14 14:17:46 --> Router Class Initialized
INFO - 2018-08-14 14:17:46 --> Output Class Initialized
INFO - 2018-08-14 14:17:46 --> Security Class Initialized
DEBUG - 2018-08-14 14:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:17:46 --> Input Class Initialized
INFO - 2018-08-14 14:17:46 --> Language Class Initialized
ERROR - 2018-08-14 14:17:46 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:17:48 --> Config Class Initialized
INFO - 2018-08-14 14:17:48 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:17:48 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:17:48 --> Utf8 Class Initialized
INFO - 2018-08-14 14:17:48 --> URI Class Initialized
INFO - 2018-08-14 14:17:48 --> Router Class Initialized
INFO - 2018-08-14 14:17:48 --> Output Class Initialized
INFO - 2018-08-14 14:17:48 --> Security Class Initialized
DEBUG - 2018-08-14 14:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:17:48 --> Input Class Initialized
INFO - 2018-08-14 14:17:48 --> Language Class Initialized
INFO - 2018-08-14 14:17:48 --> Language Class Initialized
INFO - 2018-08-14 14:17:48 --> Config Class Initialized
INFO - 2018-08-14 14:17:48 --> Loader Class Initialized
INFO - 2018-08-14 14:17:48 --> Helper loaded: url_helper
INFO - 2018-08-14 14:17:48 --> Helper loaded: file_helper
INFO - 2018-08-14 14:17:48 --> Helper loaded: form_helper
INFO - 2018-08-14 14:17:48 --> Helper loaded: my_helper
INFO - 2018-08-14 14:17:48 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:17:48 --> Controller Class Initialized
INFO - 2018-08-14 14:17:48 --> Final output sent to browser
DEBUG - 2018-08-14 14:17:48 --> Total execution time: 0.4880
INFO - 2018-08-14 14:17:51 --> Config Class Initialized
INFO - 2018-08-14 14:17:51 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:17:51 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:17:51 --> Utf8 Class Initialized
INFO - 2018-08-14 14:17:51 --> URI Class Initialized
INFO - 2018-08-14 14:17:51 --> Router Class Initialized
INFO - 2018-08-14 14:17:51 --> Output Class Initialized
INFO - 2018-08-14 14:17:51 --> Security Class Initialized
DEBUG - 2018-08-14 14:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:17:52 --> Input Class Initialized
INFO - 2018-08-14 14:17:52 --> Language Class Initialized
INFO - 2018-08-14 14:17:52 --> Language Class Initialized
INFO - 2018-08-14 14:17:52 --> Config Class Initialized
INFO - 2018-08-14 14:17:52 --> Loader Class Initialized
INFO - 2018-08-14 14:17:52 --> Helper loaded: url_helper
INFO - 2018-08-14 14:17:52 --> Helper loaded: file_helper
INFO - 2018-08-14 14:17:52 --> Helper loaded: form_helper
INFO - 2018-08-14 14:17:52 --> Helper loaded: my_helper
INFO - 2018-08-14 14:17:52 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:17:52 --> Controller Class Initialized
INFO - 2018-08-14 14:17:52 --> Final output sent to browser
DEBUG - 2018-08-14 14:17:52 --> Total execution time: 0.5531
INFO - 2018-08-14 14:17:53 --> Config Class Initialized
INFO - 2018-08-14 14:17:53 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:17:54 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:17:54 --> Utf8 Class Initialized
INFO - 2018-08-14 14:17:54 --> URI Class Initialized
INFO - 2018-08-14 14:17:54 --> Router Class Initialized
INFO - 2018-08-14 14:17:54 --> Output Class Initialized
INFO - 2018-08-14 14:17:54 --> Security Class Initialized
DEBUG - 2018-08-14 14:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:17:54 --> Input Class Initialized
INFO - 2018-08-14 14:17:54 --> Language Class Initialized
INFO - 2018-08-14 14:17:54 --> Language Class Initialized
INFO - 2018-08-14 14:17:54 --> Config Class Initialized
INFO - 2018-08-14 14:17:54 --> Loader Class Initialized
INFO - 2018-08-14 14:17:54 --> Helper loaded: url_helper
INFO - 2018-08-14 14:17:54 --> Helper loaded: file_helper
INFO - 2018-08-14 14:17:54 --> Helper loaded: form_helper
INFO - 2018-08-14 14:17:54 --> Helper loaded: my_helper
INFO - 2018-08-14 14:17:54 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:17:54 --> Controller Class Initialized
INFO - 2018-08-14 14:17:54 --> Final output sent to browser
DEBUG - 2018-08-14 14:17:54 --> Total execution time: 0.8512
INFO - 2018-08-14 14:17:58 --> Config Class Initialized
INFO - 2018-08-14 14:17:58 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:17:58 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:17:58 --> Utf8 Class Initialized
INFO - 2018-08-14 14:17:58 --> URI Class Initialized
INFO - 2018-08-14 14:17:58 --> Router Class Initialized
INFO - 2018-08-14 14:17:58 --> Output Class Initialized
INFO - 2018-08-14 14:17:58 --> Security Class Initialized
DEBUG - 2018-08-14 14:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:17:58 --> Input Class Initialized
INFO - 2018-08-14 14:17:58 --> Language Class Initialized
INFO - 2018-08-14 14:17:58 --> Language Class Initialized
INFO - 2018-08-14 14:17:58 --> Config Class Initialized
INFO - 2018-08-14 14:17:58 --> Loader Class Initialized
INFO - 2018-08-14 14:17:58 --> Helper loaded: url_helper
INFO - 2018-08-14 14:17:58 --> Helper loaded: file_helper
INFO - 2018-08-14 14:17:58 --> Helper loaded: form_helper
INFO - 2018-08-14 14:17:59 --> Helper loaded: my_helper
INFO - 2018-08-14 14:17:59 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:17:59 --> Controller Class Initialized
INFO - 2018-08-14 14:17:59 --> Final output sent to browser
DEBUG - 2018-08-14 14:17:59 --> Total execution time: 0.5474
INFO - 2018-08-14 14:18:00 --> Config Class Initialized
INFO - 2018-08-14 14:18:00 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:18:00 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:18:00 --> Utf8 Class Initialized
INFO - 2018-08-14 14:18:00 --> URI Class Initialized
INFO - 2018-08-14 14:18:00 --> Router Class Initialized
INFO - 2018-08-14 14:18:00 --> Output Class Initialized
INFO - 2018-08-14 14:18:00 --> Security Class Initialized
DEBUG - 2018-08-14 14:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:18:00 --> Input Class Initialized
INFO - 2018-08-14 14:18:00 --> Language Class Initialized
INFO - 2018-08-14 14:18:00 --> Language Class Initialized
INFO - 2018-08-14 14:18:00 --> Config Class Initialized
INFO - 2018-08-14 14:18:00 --> Loader Class Initialized
INFO - 2018-08-14 14:18:00 --> Helper loaded: url_helper
INFO - 2018-08-14 14:18:00 --> Helper loaded: file_helper
INFO - 2018-08-14 14:18:00 --> Helper loaded: form_helper
INFO - 2018-08-14 14:18:00 --> Helper loaded: my_helper
INFO - 2018-08-14 14:18:00 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:18:00 --> Controller Class Initialized
INFO - 2018-08-14 14:18:00 --> Final output sent to browser
DEBUG - 2018-08-14 14:18:00 --> Total execution time: 0.5003
INFO - 2018-08-14 14:18:04 --> Config Class Initialized
INFO - 2018-08-14 14:18:04 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:18:04 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:18:04 --> Utf8 Class Initialized
INFO - 2018-08-14 14:18:04 --> URI Class Initialized
INFO - 2018-08-14 14:18:04 --> Router Class Initialized
INFO - 2018-08-14 14:18:04 --> Output Class Initialized
INFO - 2018-08-14 14:18:04 --> Security Class Initialized
DEBUG - 2018-08-14 14:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:18:04 --> Input Class Initialized
INFO - 2018-08-14 14:18:04 --> Language Class Initialized
INFO - 2018-08-14 14:18:04 --> Language Class Initialized
INFO - 2018-08-14 14:18:04 --> Config Class Initialized
INFO - 2018-08-14 14:18:04 --> Loader Class Initialized
INFO - 2018-08-14 14:18:04 --> Helper loaded: url_helper
INFO - 2018-08-14 14:18:04 --> Helper loaded: file_helper
INFO - 2018-08-14 14:18:04 --> Helper loaded: form_helper
INFO - 2018-08-14 14:18:04 --> Helper loaded: my_helper
INFO - 2018-08-14 14:18:04 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:18:04 --> Controller Class Initialized
INFO - 2018-08-14 14:18:04 --> Final output sent to browser
DEBUG - 2018-08-14 14:18:05 --> Total execution time: 0.5905
INFO - 2018-08-14 14:18:05 --> Config Class Initialized
INFO - 2018-08-14 14:18:05 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:18:05 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:18:06 --> Utf8 Class Initialized
INFO - 2018-08-14 14:18:06 --> URI Class Initialized
INFO - 2018-08-14 14:18:06 --> Router Class Initialized
INFO - 2018-08-14 14:18:06 --> Output Class Initialized
INFO - 2018-08-14 14:18:06 --> Security Class Initialized
DEBUG - 2018-08-14 14:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:18:06 --> Input Class Initialized
INFO - 2018-08-14 14:18:06 --> Language Class Initialized
INFO - 2018-08-14 14:18:06 --> Language Class Initialized
INFO - 2018-08-14 14:18:06 --> Config Class Initialized
INFO - 2018-08-14 14:18:06 --> Loader Class Initialized
INFO - 2018-08-14 14:18:06 --> Helper loaded: url_helper
INFO - 2018-08-14 14:18:06 --> Helper loaded: file_helper
INFO - 2018-08-14 14:18:06 --> Helper loaded: form_helper
INFO - 2018-08-14 14:18:06 --> Helper loaded: my_helper
INFO - 2018-08-14 14:18:06 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:18:06 --> Controller Class Initialized
INFO - 2018-08-14 14:18:06 --> Final output sent to browser
DEBUG - 2018-08-14 14:18:06 --> Total execution time: 0.4757
INFO - 2018-08-14 14:18:09 --> Config Class Initialized
INFO - 2018-08-14 14:18:09 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:18:09 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:18:09 --> Utf8 Class Initialized
INFO - 2018-08-14 14:18:09 --> URI Class Initialized
INFO - 2018-08-14 14:18:09 --> Router Class Initialized
INFO - 2018-08-14 14:18:09 --> Output Class Initialized
INFO - 2018-08-14 14:18:09 --> Security Class Initialized
DEBUG - 2018-08-14 14:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:18:09 --> Input Class Initialized
INFO - 2018-08-14 14:18:09 --> Language Class Initialized
INFO - 2018-08-14 14:18:09 --> Language Class Initialized
INFO - 2018-08-14 14:18:09 --> Config Class Initialized
INFO - 2018-08-14 14:18:09 --> Loader Class Initialized
INFO - 2018-08-14 14:18:09 --> Helper loaded: url_helper
INFO - 2018-08-14 14:18:09 --> Helper loaded: file_helper
INFO - 2018-08-14 14:18:09 --> Helper loaded: form_helper
INFO - 2018-08-14 14:18:09 --> Helper loaded: my_helper
INFO - 2018-08-14 14:18:09 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:18:10 --> Controller Class Initialized
INFO - 2018-08-14 14:18:10 --> Final output sent to browser
DEBUG - 2018-08-14 14:18:10 --> Total execution time: 0.5619
INFO - 2018-08-14 14:18:11 --> Config Class Initialized
INFO - 2018-08-14 14:18:11 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:18:11 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:18:11 --> Utf8 Class Initialized
INFO - 2018-08-14 14:18:11 --> URI Class Initialized
INFO - 2018-08-14 14:18:11 --> Router Class Initialized
INFO - 2018-08-14 14:18:11 --> Output Class Initialized
INFO - 2018-08-14 14:18:11 --> Security Class Initialized
DEBUG - 2018-08-14 14:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:18:11 --> Input Class Initialized
INFO - 2018-08-14 14:18:11 --> Language Class Initialized
INFO - 2018-08-14 14:18:11 --> Language Class Initialized
INFO - 2018-08-14 14:18:11 --> Config Class Initialized
INFO - 2018-08-14 14:18:11 --> Loader Class Initialized
INFO - 2018-08-14 14:18:11 --> Helper loaded: url_helper
INFO - 2018-08-14 14:18:11 --> Helper loaded: file_helper
INFO - 2018-08-14 14:18:11 --> Helper loaded: form_helper
INFO - 2018-08-14 14:18:11 --> Helper loaded: my_helper
INFO - 2018-08-14 14:18:11 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:18:11 --> Controller Class Initialized
ERROR - 2018-08-14 14:18:11 --> Query error: Expression #4 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'nilai_mts.a.nilai' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: select 
                a.id_siswa, a.jenis, a.id_mapel_kd, a.nilai
                from t_nilai a 
                where a.id_guru_mapel = '4'
                group by a.id_siswa, a.jenis, a.id_mapel_kd
INFO - 2018-08-14 14:18:11 --> Language file loaded: language/english/db_lang.php
INFO - 2018-08-14 14:18:13 --> Config Class Initialized
INFO - 2018-08-14 14:18:13 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:18:13 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:18:13 --> Utf8 Class Initialized
INFO - 2018-08-14 14:18:13 --> URI Class Initialized
INFO - 2018-08-14 14:18:13 --> Router Class Initialized
INFO - 2018-08-14 14:18:13 --> Output Class Initialized
INFO - 2018-08-14 14:18:13 --> Security Class Initialized
DEBUG - 2018-08-14 14:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:18:13 --> Input Class Initialized
INFO - 2018-08-14 14:18:13 --> Language Class Initialized
INFO - 2018-08-14 14:18:13 --> Language Class Initialized
INFO - 2018-08-14 14:18:13 --> Config Class Initialized
INFO - 2018-08-14 14:18:14 --> Loader Class Initialized
INFO - 2018-08-14 14:18:14 --> Helper loaded: url_helper
INFO - 2018-08-14 14:18:14 --> Helper loaded: file_helper
INFO - 2018-08-14 14:18:14 --> Helper loaded: form_helper
INFO - 2018-08-14 14:18:14 --> Helper loaded: my_helper
INFO - 2018-08-14 14:18:14 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:18:14 --> Controller Class Initialized
ERROR - 2018-08-14 14:18:14 --> Query error: Expression #4 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'nilai_mts.a.nilai' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: select 
                a.id_siswa, a.jenis, a.id_mapel_kd, a.nilai
                from t_nilai a 
                where a.id_guru_mapel = '4'
                group by a.id_siswa, a.jenis, a.id_mapel_kd
INFO - 2018-08-14 14:18:14 --> Language file loaded: language/english/db_lang.php
INFO - 2018-08-14 14:18:58 --> Config Class Initialized
INFO - 2018-08-14 14:18:58 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:18:58 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:18:58 --> Utf8 Class Initialized
INFO - 2018-08-14 14:18:58 --> URI Class Initialized
INFO - 2018-08-14 14:18:58 --> Router Class Initialized
INFO - 2018-08-14 14:18:58 --> Output Class Initialized
INFO - 2018-08-14 14:18:58 --> Security Class Initialized
DEBUG - 2018-08-14 14:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:18:58 --> Input Class Initialized
INFO - 2018-08-14 14:18:58 --> Language Class Initialized
INFO - 2018-08-14 14:18:58 --> Language Class Initialized
INFO - 2018-08-14 14:18:58 --> Config Class Initialized
INFO - 2018-08-14 14:18:58 --> Loader Class Initialized
INFO - 2018-08-14 14:18:58 --> Helper loaded: url_helper
INFO - 2018-08-14 14:18:58 --> Helper loaded: file_helper
INFO - 2018-08-14 14:18:58 --> Helper loaded: form_helper
INFO - 2018-08-14 14:18:58 --> Helper loaded: my_helper
INFO - 2018-08-14 14:18:58 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:18:58 --> Controller Class Initialized
ERROR - 2018-08-14 14:18:58 --> Query error: Expression #4 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'nilai_mts.a.nilai' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: select 
                a.id_siswa, a.jenis, a.id_mapel_kd, a.nilai
                from t_nilai a 
                where a.id_guru_mapel = '4'
                group by a.id_siswa, a.jenis, a.id_mapel_kd
INFO - 2018-08-14 14:18:58 --> Language file loaded: language/english/db_lang.php
INFO - 2018-08-14 14:19:41 --> Config Class Initialized
INFO - 2018-08-14 14:19:41 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:19:41 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:19:41 --> Utf8 Class Initialized
INFO - 2018-08-14 14:19:41 --> URI Class Initialized
INFO - 2018-08-14 14:19:41 --> Router Class Initialized
INFO - 2018-08-14 14:19:41 --> Output Class Initialized
INFO - 2018-08-14 14:19:41 --> Security Class Initialized
DEBUG - 2018-08-14 14:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:19:41 --> Input Class Initialized
INFO - 2018-08-14 14:19:42 --> Language Class Initialized
INFO - 2018-08-14 14:19:42 --> Language Class Initialized
INFO - 2018-08-14 14:19:42 --> Config Class Initialized
INFO - 2018-08-14 14:19:42 --> Loader Class Initialized
INFO - 2018-08-14 14:19:42 --> Helper loaded: url_helper
INFO - 2018-08-14 14:19:42 --> Helper loaded: file_helper
INFO - 2018-08-14 14:19:42 --> Helper loaded: form_helper
INFO - 2018-08-14 14:19:42 --> Helper loaded: my_helper
INFO - 2018-08-14 14:19:42 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:19:42 --> Controller Class Initialized
DEBUG - 2018-08-14 14:19:42 --> File loaded: D:\laragon\www\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2018-08-14 14:19:42 --> Final output sent to browser
DEBUG - 2018-08-14 14:19:42 --> Total execution time: 1.2099
INFO - 2018-08-14 14:19:53 --> Config Class Initialized
INFO - 2018-08-14 14:19:53 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:19:53 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:19:53 --> Utf8 Class Initialized
INFO - 2018-08-14 14:19:53 --> URI Class Initialized
INFO - 2018-08-14 14:19:53 --> Router Class Initialized
INFO - 2018-08-14 14:19:53 --> Output Class Initialized
INFO - 2018-08-14 14:19:53 --> Security Class Initialized
DEBUG - 2018-08-14 14:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:19:53 --> Input Class Initialized
INFO - 2018-08-14 14:19:53 --> Language Class Initialized
INFO - 2018-08-14 14:19:53 --> Language Class Initialized
INFO - 2018-08-14 14:19:53 --> Config Class Initialized
INFO - 2018-08-14 14:19:53 --> Loader Class Initialized
INFO - 2018-08-14 14:19:53 --> Helper loaded: url_helper
INFO - 2018-08-14 14:19:53 --> Helper loaded: file_helper
INFO - 2018-08-14 14:19:53 --> Helper loaded: form_helper
INFO - 2018-08-14 14:19:53 --> Helper loaded: my_helper
INFO - 2018-08-14 14:19:53 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:19:53 --> Controller Class Initialized
DEBUG - 2018-08-14 14:19:53 --> File loaded: D:\laragon\www\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2018-08-14 14:19:53 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:19:53 --> Final output sent to browser
DEBUG - 2018-08-14 14:19:53 --> Total execution time: 0.5160
INFO - 2018-08-14 14:19:53 --> Config Class Initialized
INFO - 2018-08-14 14:19:54 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:19:54 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:19:54 --> Utf8 Class Initialized
INFO - 2018-08-14 14:19:54 --> URI Class Initialized
INFO - 2018-08-14 14:19:54 --> Router Class Initialized
INFO - 2018-08-14 14:19:54 --> Output Class Initialized
INFO - 2018-08-14 14:19:54 --> Security Class Initialized
DEBUG - 2018-08-14 14:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:19:54 --> Input Class Initialized
INFO - 2018-08-14 14:19:54 --> Language Class Initialized
ERROR - 2018-08-14 14:19:54 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:19:55 --> Config Class Initialized
INFO - 2018-08-14 14:19:55 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:19:55 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:19:55 --> Utf8 Class Initialized
INFO - 2018-08-14 14:19:56 --> URI Class Initialized
INFO - 2018-08-14 14:19:56 --> Router Class Initialized
INFO - 2018-08-14 14:19:56 --> Output Class Initialized
INFO - 2018-08-14 14:19:56 --> Security Class Initialized
DEBUG - 2018-08-14 14:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:19:56 --> Input Class Initialized
INFO - 2018-08-14 14:19:56 --> Language Class Initialized
INFO - 2018-08-14 14:19:56 --> Language Class Initialized
INFO - 2018-08-14 14:19:56 --> Config Class Initialized
INFO - 2018-08-14 14:19:56 --> Loader Class Initialized
INFO - 2018-08-14 14:19:56 --> Helper loaded: url_helper
INFO - 2018-08-14 14:19:56 --> Helper loaded: file_helper
INFO - 2018-08-14 14:19:56 --> Helper loaded: form_helper
INFO - 2018-08-14 14:19:56 --> Helper loaded: my_helper
INFO - 2018-08-14 14:19:56 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:19:56 --> Controller Class Initialized
DEBUG - 2018-08-14 14:19:56 --> File loaded: D:\laragon\www\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2018-08-14 14:19:56 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:19:56 --> Final output sent to browser
DEBUG - 2018-08-14 14:19:56 --> Total execution time: 0.6982
INFO - 2018-08-14 14:19:56 --> Config Class Initialized
INFO - 2018-08-14 14:19:56 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:19:56 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:19:56 --> Utf8 Class Initialized
INFO - 2018-08-14 14:19:56 --> URI Class Initialized
INFO - 2018-08-14 14:19:56 --> Router Class Initialized
INFO - 2018-08-14 14:19:56 --> Output Class Initialized
INFO - 2018-08-14 14:19:56 --> Security Class Initialized
DEBUG - 2018-08-14 14:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:19:57 --> Input Class Initialized
INFO - 2018-08-14 14:19:57 --> Language Class Initialized
ERROR - 2018-08-14 14:19:57 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:20:00 --> Config Class Initialized
INFO - 2018-08-14 14:20:00 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:20:00 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:20:00 --> Utf8 Class Initialized
INFO - 2018-08-14 14:20:00 --> URI Class Initialized
INFO - 2018-08-14 14:20:00 --> Router Class Initialized
INFO - 2018-08-14 14:20:00 --> Output Class Initialized
INFO - 2018-08-14 14:20:00 --> Security Class Initialized
DEBUG - 2018-08-14 14:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:20:00 --> Input Class Initialized
INFO - 2018-08-14 14:20:00 --> Language Class Initialized
INFO - 2018-08-14 14:20:00 --> Language Class Initialized
INFO - 2018-08-14 14:20:00 --> Config Class Initialized
INFO - 2018-08-14 14:20:00 --> Loader Class Initialized
INFO - 2018-08-14 14:20:00 --> Helper loaded: url_helper
INFO - 2018-08-14 14:20:00 --> Helper loaded: file_helper
INFO - 2018-08-14 14:20:00 --> Helper loaded: form_helper
INFO - 2018-08-14 14:20:00 --> Helper loaded: my_helper
INFO - 2018-08-14 14:20:00 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:20:00 --> Controller Class Initialized
INFO - 2018-08-14 14:20:01 --> Final output sent to browser
DEBUG - 2018-08-14 14:20:01 --> Total execution time: 0.4933
INFO - 2018-08-14 14:20:08 --> Config Class Initialized
INFO - 2018-08-14 14:20:08 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:20:08 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:20:08 --> Utf8 Class Initialized
INFO - 2018-08-14 14:20:08 --> URI Class Initialized
INFO - 2018-08-14 14:20:08 --> Router Class Initialized
INFO - 2018-08-14 14:20:08 --> Output Class Initialized
INFO - 2018-08-14 14:20:08 --> Security Class Initialized
DEBUG - 2018-08-14 14:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:20:08 --> Input Class Initialized
INFO - 2018-08-14 14:20:08 --> Language Class Initialized
INFO - 2018-08-14 14:20:08 --> Language Class Initialized
INFO - 2018-08-14 14:20:08 --> Config Class Initialized
INFO - 2018-08-14 14:20:08 --> Loader Class Initialized
INFO - 2018-08-14 14:20:08 --> Helper loaded: url_helper
INFO - 2018-08-14 14:20:08 --> Helper loaded: file_helper
INFO - 2018-08-14 14:20:08 --> Helper loaded: form_helper
INFO - 2018-08-14 14:20:08 --> Helper loaded: my_helper
INFO - 2018-08-14 14:20:08 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:20:08 --> Controller Class Initialized
INFO - 2018-08-14 14:20:08 --> Final output sent to browser
DEBUG - 2018-08-14 14:20:08 --> Total execution time: 0.5397
INFO - 2018-08-14 14:20:08 --> Config Class Initialized
INFO - 2018-08-14 14:20:08 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:20:08 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:20:08 --> Utf8 Class Initialized
INFO - 2018-08-14 14:20:09 --> URI Class Initialized
INFO - 2018-08-14 14:20:09 --> Router Class Initialized
INFO - 2018-08-14 14:20:09 --> Output Class Initialized
INFO - 2018-08-14 14:20:09 --> Security Class Initialized
DEBUG - 2018-08-14 14:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:20:09 --> Input Class Initialized
INFO - 2018-08-14 14:20:09 --> Language Class Initialized
INFO - 2018-08-14 14:20:09 --> Language Class Initialized
INFO - 2018-08-14 14:20:09 --> Config Class Initialized
INFO - 2018-08-14 14:20:09 --> Loader Class Initialized
INFO - 2018-08-14 14:20:09 --> Helper loaded: url_helper
INFO - 2018-08-14 14:20:09 --> Helper loaded: file_helper
INFO - 2018-08-14 14:20:09 --> Helper loaded: form_helper
INFO - 2018-08-14 14:20:09 --> Helper loaded: my_helper
INFO - 2018-08-14 14:20:09 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:20:09 --> Controller Class Initialized
DEBUG - 2018-08-14 14:20:09 --> File loaded: D:\laragon\www\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2018-08-14 14:20:09 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:20:09 --> Final output sent to browser
DEBUG - 2018-08-14 14:20:09 --> Total execution time: 0.5360
INFO - 2018-08-14 14:20:09 --> Config Class Initialized
INFO - 2018-08-14 14:20:09 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:20:09 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:20:09 --> Utf8 Class Initialized
INFO - 2018-08-14 14:20:09 --> URI Class Initialized
INFO - 2018-08-14 14:20:09 --> Router Class Initialized
INFO - 2018-08-14 14:20:09 --> Output Class Initialized
INFO - 2018-08-14 14:20:09 --> Security Class Initialized
DEBUG - 2018-08-14 14:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:20:09 --> Input Class Initialized
INFO - 2018-08-14 14:20:09 --> Language Class Initialized
ERROR - 2018-08-14 14:20:09 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:20:10 --> Config Class Initialized
INFO - 2018-08-14 14:20:10 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:20:10 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:20:10 --> Utf8 Class Initialized
INFO - 2018-08-14 14:20:10 --> URI Class Initialized
INFO - 2018-08-14 14:20:10 --> Router Class Initialized
INFO - 2018-08-14 14:20:10 --> Output Class Initialized
INFO - 2018-08-14 14:20:10 --> Security Class Initialized
DEBUG - 2018-08-14 14:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:20:10 --> Input Class Initialized
INFO - 2018-08-14 14:20:10 --> Language Class Initialized
INFO - 2018-08-14 14:20:10 --> Language Class Initialized
INFO - 2018-08-14 14:20:10 --> Config Class Initialized
INFO - 2018-08-14 14:20:10 --> Loader Class Initialized
INFO - 2018-08-14 14:20:10 --> Helper loaded: url_helper
INFO - 2018-08-14 14:20:10 --> Helper loaded: file_helper
INFO - 2018-08-14 14:20:10 --> Helper loaded: form_helper
INFO - 2018-08-14 14:20:10 --> Helper loaded: my_helper
INFO - 2018-08-14 14:20:10 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:20:11 --> Controller Class Initialized
INFO - 2018-08-14 14:20:11 --> Final output sent to browser
DEBUG - 2018-08-14 14:20:11 --> Total execution time: 0.5105
INFO - 2018-08-14 14:20:16 --> Config Class Initialized
INFO - 2018-08-14 14:20:16 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:20:16 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:20:16 --> Utf8 Class Initialized
INFO - 2018-08-14 14:20:16 --> URI Class Initialized
INFO - 2018-08-14 14:20:16 --> Router Class Initialized
INFO - 2018-08-14 14:20:16 --> Output Class Initialized
INFO - 2018-08-14 14:20:16 --> Security Class Initialized
DEBUG - 2018-08-14 14:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:20:16 --> Input Class Initialized
INFO - 2018-08-14 14:20:16 --> Language Class Initialized
INFO - 2018-08-14 14:20:16 --> Language Class Initialized
INFO - 2018-08-14 14:20:16 --> Config Class Initialized
INFO - 2018-08-14 14:20:16 --> Loader Class Initialized
INFO - 2018-08-14 14:20:16 --> Helper loaded: url_helper
INFO - 2018-08-14 14:20:16 --> Helper loaded: file_helper
INFO - 2018-08-14 14:20:16 --> Helper loaded: form_helper
INFO - 2018-08-14 14:20:16 --> Helper loaded: my_helper
INFO - 2018-08-14 14:20:17 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:20:17 --> Controller Class Initialized
INFO - 2018-08-14 14:20:17 --> Final output sent to browser
DEBUG - 2018-08-14 14:20:17 --> Total execution time: 0.5384
INFO - 2018-08-14 14:20:17 --> Config Class Initialized
INFO - 2018-08-14 14:20:17 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:20:17 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:20:17 --> Utf8 Class Initialized
INFO - 2018-08-14 14:20:17 --> URI Class Initialized
INFO - 2018-08-14 14:20:17 --> Router Class Initialized
INFO - 2018-08-14 14:20:17 --> Output Class Initialized
INFO - 2018-08-14 14:20:17 --> Security Class Initialized
DEBUG - 2018-08-14 14:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:20:17 --> Input Class Initialized
INFO - 2018-08-14 14:20:17 --> Language Class Initialized
INFO - 2018-08-14 14:20:17 --> Language Class Initialized
INFO - 2018-08-14 14:20:17 --> Config Class Initialized
INFO - 2018-08-14 14:20:17 --> Loader Class Initialized
INFO - 2018-08-14 14:20:17 --> Helper loaded: url_helper
INFO - 2018-08-14 14:20:17 --> Helper loaded: file_helper
INFO - 2018-08-14 14:20:17 --> Helper loaded: form_helper
INFO - 2018-08-14 14:20:17 --> Helper loaded: my_helper
INFO - 2018-08-14 14:20:17 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:20:17 --> Controller Class Initialized
DEBUG - 2018-08-14 14:20:17 --> File loaded: D:\laragon\www\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2018-08-14 14:20:17 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:20:17 --> Final output sent to browser
DEBUG - 2018-08-14 14:20:17 --> Total execution time: 0.5486
INFO - 2018-08-14 14:20:17 --> Config Class Initialized
INFO - 2018-08-14 14:20:18 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:20:18 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:20:18 --> Utf8 Class Initialized
INFO - 2018-08-14 14:20:18 --> URI Class Initialized
INFO - 2018-08-14 14:20:18 --> Router Class Initialized
INFO - 2018-08-14 14:20:18 --> Output Class Initialized
INFO - 2018-08-14 14:20:18 --> Security Class Initialized
DEBUG - 2018-08-14 14:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:20:18 --> Input Class Initialized
INFO - 2018-08-14 14:20:18 --> Language Class Initialized
ERROR - 2018-08-14 14:20:18 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:20:19 --> Config Class Initialized
INFO - 2018-08-14 14:20:19 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:20:19 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:20:19 --> Utf8 Class Initialized
INFO - 2018-08-14 14:20:19 --> URI Class Initialized
INFO - 2018-08-14 14:20:19 --> Router Class Initialized
INFO - 2018-08-14 14:20:19 --> Output Class Initialized
INFO - 2018-08-14 14:20:19 --> Security Class Initialized
DEBUG - 2018-08-14 14:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:20:19 --> Input Class Initialized
INFO - 2018-08-14 14:20:19 --> Language Class Initialized
INFO - 2018-08-14 14:20:19 --> Language Class Initialized
INFO - 2018-08-14 14:20:19 --> Config Class Initialized
INFO - 2018-08-14 14:20:19 --> Loader Class Initialized
INFO - 2018-08-14 14:20:19 --> Helper loaded: url_helper
INFO - 2018-08-14 14:20:19 --> Helper loaded: file_helper
INFO - 2018-08-14 14:20:19 --> Helper loaded: form_helper
INFO - 2018-08-14 14:20:19 --> Helper loaded: my_helper
INFO - 2018-08-14 14:20:19 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:20:19 --> Controller Class Initialized
INFO - 2018-08-14 14:20:19 --> Final output sent to browser
DEBUG - 2018-08-14 14:20:19 --> Total execution time: 0.7667
INFO - 2018-08-14 14:20:22 --> Config Class Initialized
INFO - 2018-08-14 14:20:22 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:20:23 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:20:23 --> Utf8 Class Initialized
INFO - 2018-08-14 14:20:23 --> URI Class Initialized
INFO - 2018-08-14 14:20:23 --> Router Class Initialized
INFO - 2018-08-14 14:20:23 --> Output Class Initialized
INFO - 2018-08-14 14:20:23 --> Security Class Initialized
DEBUG - 2018-08-14 14:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:20:23 --> Input Class Initialized
INFO - 2018-08-14 14:20:23 --> Language Class Initialized
INFO - 2018-08-14 14:20:23 --> Language Class Initialized
INFO - 2018-08-14 14:20:23 --> Config Class Initialized
INFO - 2018-08-14 14:20:23 --> Loader Class Initialized
INFO - 2018-08-14 14:20:23 --> Helper loaded: url_helper
INFO - 2018-08-14 14:20:23 --> Helper loaded: file_helper
INFO - 2018-08-14 14:20:23 --> Helper loaded: form_helper
INFO - 2018-08-14 14:20:23 --> Helper loaded: my_helper
INFO - 2018-08-14 14:20:23 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:20:23 --> Controller Class Initialized
INFO - 2018-08-14 14:20:23 --> Final output sent to browser
DEBUG - 2018-08-14 14:20:23 --> Total execution time: 0.6164
INFO - 2018-08-14 14:20:25 --> Config Class Initialized
INFO - 2018-08-14 14:20:25 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:20:25 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:20:25 --> Utf8 Class Initialized
INFO - 2018-08-14 14:20:25 --> URI Class Initialized
INFO - 2018-08-14 14:20:25 --> Router Class Initialized
INFO - 2018-08-14 14:20:25 --> Output Class Initialized
INFO - 2018-08-14 14:20:25 --> Security Class Initialized
DEBUG - 2018-08-14 14:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:20:25 --> Input Class Initialized
INFO - 2018-08-14 14:20:25 --> Language Class Initialized
INFO - 2018-08-14 14:20:25 --> Language Class Initialized
INFO - 2018-08-14 14:20:25 --> Config Class Initialized
INFO - 2018-08-14 14:20:25 --> Loader Class Initialized
INFO - 2018-08-14 14:20:25 --> Helper loaded: url_helper
INFO - 2018-08-14 14:20:25 --> Helper loaded: file_helper
INFO - 2018-08-14 14:20:25 --> Helper loaded: form_helper
INFO - 2018-08-14 14:20:25 --> Helper loaded: my_helper
INFO - 2018-08-14 14:20:25 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:20:25 --> Controller Class Initialized
INFO - 2018-08-14 14:20:25 --> Final output sent to browser
DEBUG - 2018-08-14 14:20:26 --> Total execution time: 0.5727
INFO - 2018-08-14 14:20:29 --> Config Class Initialized
INFO - 2018-08-14 14:20:29 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:20:29 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:20:29 --> Utf8 Class Initialized
INFO - 2018-08-14 14:20:29 --> URI Class Initialized
INFO - 2018-08-14 14:20:29 --> Router Class Initialized
INFO - 2018-08-14 14:20:29 --> Output Class Initialized
INFO - 2018-08-14 14:20:29 --> Security Class Initialized
DEBUG - 2018-08-14 14:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:20:29 --> Input Class Initialized
INFO - 2018-08-14 14:20:29 --> Language Class Initialized
INFO - 2018-08-14 14:20:29 --> Language Class Initialized
INFO - 2018-08-14 14:20:29 --> Config Class Initialized
INFO - 2018-08-14 14:20:29 --> Loader Class Initialized
INFO - 2018-08-14 14:20:29 --> Helper loaded: url_helper
INFO - 2018-08-14 14:20:29 --> Helper loaded: file_helper
INFO - 2018-08-14 14:20:29 --> Helper loaded: form_helper
INFO - 2018-08-14 14:20:29 --> Helper loaded: my_helper
INFO - 2018-08-14 14:20:29 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:20:29 --> Controller Class Initialized
INFO - 2018-08-14 14:20:29 --> Final output sent to browser
DEBUG - 2018-08-14 14:20:29 --> Total execution time: 0.5529
INFO - 2018-08-14 14:20:32 --> Config Class Initialized
INFO - 2018-08-14 14:20:32 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:20:32 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:20:32 --> Utf8 Class Initialized
INFO - 2018-08-14 14:20:32 --> URI Class Initialized
INFO - 2018-08-14 14:20:32 --> Router Class Initialized
INFO - 2018-08-14 14:20:32 --> Output Class Initialized
INFO - 2018-08-14 14:20:33 --> Security Class Initialized
DEBUG - 2018-08-14 14:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:20:33 --> Input Class Initialized
INFO - 2018-08-14 14:20:33 --> Language Class Initialized
INFO - 2018-08-14 14:20:33 --> Language Class Initialized
INFO - 2018-08-14 14:20:33 --> Config Class Initialized
INFO - 2018-08-14 14:20:33 --> Loader Class Initialized
INFO - 2018-08-14 14:20:33 --> Helper loaded: url_helper
INFO - 2018-08-14 14:20:33 --> Helper loaded: file_helper
INFO - 2018-08-14 14:20:33 --> Helper loaded: form_helper
INFO - 2018-08-14 14:20:33 --> Helper loaded: my_helper
INFO - 2018-08-14 14:20:33 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:20:33 --> Controller Class Initialized
DEBUG - 2018-08-14 14:20:33 --> File loaded: D:\laragon\www\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2018-08-14 14:20:33 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:20:33 --> Final output sent to browser
DEBUG - 2018-08-14 14:20:33 --> Total execution time: 0.5688
INFO - 2018-08-14 14:20:33 --> Config Class Initialized
INFO - 2018-08-14 14:20:33 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:20:33 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:20:33 --> Utf8 Class Initialized
INFO - 2018-08-14 14:20:33 --> URI Class Initialized
INFO - 2018-08-14 14:20:33 --> Router Class Initialized
INFO - 2018-08-14 14:20:33 --> Output Class Initialized
INFO - 2018-08-14 14:20:33 --> Security Class Initialized
DEBUG - 2018-08-14 14:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:20:33 --> Input Class Initialized
INFO - 2018-08-14 14:20:33 --> Language Class Initialized
ERROR - 2018-08-14 14:20:33 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:20:46 --> Config Class Initialized
INFO - 2018-08-14 14:20:46 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:20:46 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:20:47 --> Utf8 Class Initialized
INFO - 2018-08-14 14:20:47 --> URI Class Initialized
INFO - 2018-08-14 14:20:47 --> Router Class Initialized
INFO - 2018-08-14 14:20:47 --> Output Class Initialized
INFO - 2018-08-14 14:20:47 --> Security Class Initialized
DEBUG - 2018-08-14 14:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:20:47 --> Input Class Initialized
INFO - 2018-08-14 14:20:47 --> Language Class Initialized
INFO - 2018-08-14 14:20:47 --> Language Class Initialized
INFO - 2018-08-14 14:20:47 --> Config Class Initialized
INFO - 2018-08-14 14:20:47 --> Loader Class Initialized
INFO - 2018-08-14 14:20:47 --> Helper loaded: url_helper
INFO - 2018-08-14 14:20:47 --> Helper loaded: file_helper
INFO - 2018-08-14 14:20:47 --> Helper loaded: form_helper
INFO - 2018-08-14 14:20:47 --> Helper loaded: my_helper
INFO - 2018-08-14 14:20:47 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:20:47 --> Controller Class Initialized
INFO - 2018-08-14 14:20:47 --> Final output sent to browser
DEBUG - 2018-08-14 14:20:47 --> Total execution time: 0.5024
INFO - 2018-08-14 14:20:55 --> Config Class Initialized
INFO - 2018-08-14 14:20:55 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:20:55 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:20:55 --> Utf8 Class Initialized
INFO - 2018-08-14 14:20:55 --> URI Class Initialized
INFO - 2018-08-14 14:20:55 --> Router Class Initialized
INFO - 2018-08-14 14:20:55 --> Output Class Initialized
INFO - 2018-08-14 14:20:55 --> Security Class Initialized
DEBUG - 2018-08-14 14:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:20:55 --> Input Class Initialized
INFO - 2018-08-14 14:20:55 --> Language Class Initialized
INFO - 2018-08-14 14:20:55 --> Language Class Initialized
INFO - 2018-08-14 14:20:55 --> Config Class Initialized
INFO - 2018-08-14 14:20:55 --> Loader Class Initialized
INFO - 2018-08-14 14:20:55 --> Helper loaded: url_helper
INFO - 2018-08-14 14:20:55 --> Helper loaded: file_helper
INFO - 2018-08-14 14:20:55 --> Helper loaded: form_helper
INFO - 2018-08-14 14:20:55 --> Helper loaded: my_helper
INFO - 2018-08-14 14:20:55 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:20:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:20:55 --> Controller Class Initialized
DEBUG - 2018-08-14 14:20:55 --> File loaded: D:\laragon\www\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2018-08-14 14:20:55 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:20:55 --> Final output sent to browser
DEBUG - 2018-08-14 14:20:55 --> Total execution time: 0.6310
INFO - 2018-08-14 14:20:56 --> Config Class Initialized
INFO - 2018-08-14 14:20:56 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:20:56 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:20:56 --> Utf8 Class Initialized
INFO - 2018-08-14 14:20:56 --> URI Class Initialized
INFO - 2018-08-14 14:20:56 --> Router Class Initialized
INFO - 2018-08-14 14:20:56 --> Output Class Initialized
INFO - 2018-08-14 14:20:56 --> Security Class Initialized
DEBUG - 2018-08-14 14:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:20:56 --> Input Class Initialized
INFO - 2018-08-14 14:20:56 --> Language Class Initialized
ERROR - 2018-08-14 14:20:56 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:21:02 --> Config Class Initialized
INFO - 2018-08-14 14:21:02 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:21:02 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:21:02 --> Utf8 Class Initialized
INFO - 2018-08-14 14:21:02 --> URI Class Initialized
INFO - 2018-08-14 14:21:02 --> Router Class Initialized
INFO - 2018-08-14 14:21:02 --> Output Class Initialized
INFO - 2018-08-14 14:21:02 --> Security Class Initialized
DEBUG - 2018-08-14 14:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:21:02 --> Input Class Initialized
INFO - 2018-08-14 14:21:02 --> Language Class Initialized
INFO - 2018-08-14 14:21:02 --> Language Class Initialized
INFO - 2018-08-14 14:21:02 --> Config Class Initialized
INFO - 2018-08-14 14:21:02 --> Loader Class Initialized
INFO - 2018-08-14 14:21:02 --> Helper loaded: url_helper
INFO - 2018-08-14 14:21:02 --> Helper loaded: file_helper
INFO - 2018-08-14 14:21:02 --> Helper loaded: form_helper
INFO - 2018-08-14 14:21:02 --> Helper loaded: my_helper
INFO - 2018-08-14 14:21:02 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:21:02 --> Controller Class Initialized
INFO - 2018-08-14 14:21:03 --> Final output sent to browser
DEBUG - 2018-08-14 14:21:03 --> Total execution time: 0.8335
INFO - 2018-08-14 14:21:04 --> Config Class Initialized
INFO - 2018-08-14 14:21:04 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:21:04 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:21:05 --> Utf8 Class Initialized
INFO - 2018-08-14 14:21:05 --> URI Class Initialized
INFO - 2018-08-14 14:21:05 --> Router Class Initialized
INFO - 2018-08-14 14:21:05 --> Output Class Initialized
INFO - 2018-08-14 14:21:05 --> Security Class Initialized
DEBUG - 2018-08-14 14:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:21:05 --> Input Class Initialized
INFO - 2018-08-14 14:21:05 --> Language Class Initialized
INFO - 2018-08-14 14:21:05 --> Language Class Initialized
INFO - 2018-08-14 14:21:05 --> Config Class Initialized
INFO - 2018-08-14 14:21:05 --> Loader Class Initialized
INFO - 2018-08-14 14:21:05 --> Helper loaded: url_helper
INFO - 2018-08-14 14:21:05 --> Helper loaded: file_helper
INFO - 2018-08-14 14:21:05 --> Helper loaded: form_helper
INFO - 2018-08-14 14:21:05 --> Helper loaded: my_helper
INFO - 2018-08-14 14:21:05 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:21:05 --> Controller Class Initialized
DEBUG - 2018-08-14 14:21:05 --> File loaded: D:\laragon\www\nilai\application\modules/n_sikap_so/views/cetak.php
INFO - 2018-08-14 14:21:05 --> Final output sent to browser
DEBUG - 2018-08-14 14:21:05 --> Total execution time: 0.5527
INFO - 2018-08-14 14:21:08 --> Config Class Initialized
INFO - 2018-08-14 14:21:08 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:21:08 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:21:08 --> Utf8 Class Initialized
INFO - 2018-08-14 14:21:08 --> URI Class Initialized
INFO - 2018-08-14 14:21:08 --> Router Class Initialized
INFO - 2018-08-14 14:21:08 --> Output Class Initialized
INFO - 2018-08-14 14:21:08 --> Security Class Initialized
DEBUG - 2018-08-14 14:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:21:08 --> Input Class Initialized
INFO - 2018-08-14 14:21:08 --> Language Class Initialized
INFO - 2018-08-14 14:21:08 --> Language Class Initialized
INFO - 2018-08-14 14:21:08 --> Config Class Initialized
INFO - 2018-08-14 14:21:08 --> Loader Class Initialized
INFO - 2018-08-14 14:21:08 --> Helper loaded: url_helper
INFO - 2018-08-14 14:21:08 --> Helper loaded: file_helper
INFO - 2018-08-14 14:21:08 --> Helper loaded: form_helper
INFO - 2018-08-14 14:21:08 --> Helper loaded: my_helper
INFO - 2018-08-14 14:21:08 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:21:08 --> Controller Class Initialized
DEBUG - 2018-08-14 14:21:08 --> File loaded: D:\laragon\www\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2018-08-14 14:21:08 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:21:08 --> Final output sent to browser
DEBUG - 2018-08-14 14:21:09 --> Total execution time: 0.5519
INFO - 2018-08-14 14:21:09 --> Config Class Initialized
INFO - 2018-08-14 14:21:09 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:21:09 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:21:09 --> Utf8 Class Initialized
INFO - 2018-08-14 14:21:09 --> URI Class Initialized
INFO - 2018-08-14 14:21:09 --> Router Class Initialized
INFO - 2018-08-14 14:21:09 --> Output Class Initialized
INFO - 2018-08-14 14:21:09 --> Security Class Initialized
DEBUG - 2018-08-14 14:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:21:09 --> Input Class Initialized
INFO - 2018-08-14 14:21:09 --> Language Class Initialized
ERROR - 2018-08-14 14:21:09 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:21:13 --> Config Class Initialized
INFO - 2018-08-14 14:21:13 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:21:13 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:21:13 --> Utf8 Class Initialized
INFO - 2018-08-14 14:21:13 --> URI Class Initialized
INFO - 2018-08-14 14:21:13 --> Router Class Initialized
INFO - 2018-08-14 14:21:13 --> Output Class Initialized
INFO - 2018-08-14 14:21:13 --> Security Class Initialized
DEBUG - 2018-08-14 14:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:21:13 --> Input Class Initialized
INFO - 2018-08-14 14:21:13 --> Language Class Initialized
INFO - 2018-08-14 14:21:13 --> Language Class Initialized
INFO - 2018-08-14 14:21:13 --> Config Class Initialized
INFO - 2018-08-14 14:21:13 --> Loader Class Initialized
INFO - 2018-08-14 14:21:13 --> Helper loaded: url_helper
INFO - 2018-08-14 14:21:13 --> Helper loaded: file_helper
INFO - 2018-08-14 14:21:13 --> Helper loaded: form_helper
INFO - 2018-08-14 14:21:13 --> Helper loaded: my_helper
INFO - 2018-08-14 14:21:13 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:21:13 --> Controller Class Initialized
DEBUG - 2018-08-14 14:21:13 --> File loaded: D:\laragon\www\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2018-08-14 14:21:13 --> Final output sent to browser
DEBUG - 2018-08-14 14:21:13 --> Total execution time: 0.7238
INFO - 2018-08-14 14:21:20 --> Config Class Initialized
INFO - 2018-08-14 14:21:20 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:21:20 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:21:20 --> Utf8 Class Initialized
INFO - 2018-08-14 14:21:20 --> URI Class Initialized
INFO - 2018-08-14 14:21:20 --> Router Class Initialized
INFO - 2018-08-14 14:21:20 --> Output Class Initialized
INFO - 2018-08-14 14:21:20 --> Security Class Initialized
DEBUG - 2018-08-14 14:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:21:20 --> Input Class Initialized
INFO - 2018-08-14 14:21:20 --> Language Class Initialized
INFO - 2018-08-14 14:21:20 --> Language Class Initialized
INFO - 2018-08-14 14:21:20 --> Config Class Initialized
INFO - 2018-08-14 14:21:20 --> Loader Class Initialized
INFO - 2018-08-14 14:21:20 --> Helper loaded: url_helper
INFO - 2018-08-14 14:21:21 --> Helper loaded: file_helper
INFO - 2018-08-14 14:21:21 --> Helper loaded: form_helper
INFO - 2018-08-14 14:21:21 --> Helper loaded: my_helper
INFO - 2018-08-14 14:21:21 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:21:21 --> Controller Class Initialized
DEBUG - 2018-08-14 14:21:21 --> File loaded: D:\laragon\www\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2018-08-14 14:21:21 --> Final output sent to browser
DEBUG - 2018-08-14 14:21:21 --> Total execution time: 0.5807
INFO - 2018-08-14 14:21:26 --> Config Class Initialized
INFO - 2018-08-14 14:21:26 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:21:26 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:21:26 --> Utf8 Class Initialized
INFO - 2018-08-14 14:21:26 --> URI Class Initialized
INFO - 2018-08-14 14:21:26 --> Router Class Initialized
INFO - 2018-08-14 14:21:26 --> Output Class Initialized
INFO - 2018-08-14 14:21:26 --> Security Class Initialized
DEBUG - 2018-08-14 14:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:21:26 --> Input Class Initialized
INFO - 2018-08-14 14:21:26 --> Language Class Initialized
INFO - 2018-08-14 14:21:26 --> Language Class Initialized
INFO - 2018-08-14 14:21:26 --> Config Class Initialized
INFO - 2018-08-14 14:21:26 --> Loader Class Initialized
INFO - 2018-08-14 14:21:26 --> Helper loaded: url_helper
INFO - 2018-08-14 14:21:26 --> Helper loaded: file_helper
INFO - 2018-08-14 14:21:26 --> Helper loaded: form_helper
INFO - 2018-08-14 14:21:26 --> Helper loaded: my_helper
INFO - 2018-08-14 14:21:26 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:21:26 --> Controller Class Initialized
DEBUG - 2018-08-14 14:21:26 --> File loaded: D:\laragon\www\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2018-08-14 14:21:26 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:21:26 --> Final output sent to browser
DEBUG - 2018-08-14 14:21:26 --> Total execution time: 0.6827
INFO - 2018-08-14 14:21:27 --> Config Class Initialized
INFO - 2018-08-14 14:21:27 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:21:27 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:21:27 --> Utf8 Class Initialized
INFO - 2018-08-14 14:21:27 --> URI Class Initialized
INFO - 2018-08-14 14:21:27 --> Router Class Initialized
INFO - 2018-08-14 14:21:27 --> Output Class Initialized
INFO - 2018-08-14 14:21:27 --> Security Class Initialized
DEBUG - 2018-08-14 14:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:21:27 --> Input Class Initialized
INFO - 2018-08-14 14:21:27 --> Language Class Initialized
ERROR - 2018-08-14 14:21:27 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:21:28 --> Config Class Initialized
INFO - 2018-08-14 14:21:28 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:21:28 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:21:28 --> Utf8 Class Initialized
INFO - 2018-08-14 14:21:28 --> URI Class Initialized
INFO - 2018-08-14 14:21:28 --> Router Class Initialized
INFO - 2018-08-14 14:21:28 --> Output Class Initialized
INFO - 2018-08-14 14:21:28 --> Security Class Initialized
DEBUG - 2018-08-14 14:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:21:28 --> Input Class Initialized
INFO - 2018-08-14 14:21:28 --> Language Class Initialized
INFO - 2018-08-14 14:21:28 --> Language Class Initialized
INFO - 2018-08-14 14:21:28 --> Config Class Initialized
INFO - 2018-08-14 14:21:28 --> Loader Class Initialized
INFO - 2018-08-14 14:21:28 --> Helper loaded: url_helper
INFO - 2018-08-14 14:21:28 --> Helper loaded: file_helper
INFO - 2018-08-14 14:21:28 --> Helper loaded: form_helper
INFO - 2018-08-14 14:21:28 --> Helper loaded: my_helper
INFO - 2018-08-14 14:21:28 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:21:28 --> Controller Class Initialized
DEBUG - 2018-08-14 14:21:28 --> File loaded: D:\laragon\www\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2018-08-14 14:21:28 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:21:28 --> Final output sent to browser
DEBUG - 2018-08-14 14:21:28 --> Total execution time: 0.5249
INFO - 2018-08-14 14:21:29 --> Config Class Initialized
INFO - 2018-08-14 14:21:29 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:21:29 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:21:29 --> Utf8 Class Initialized
INFO - 2018-08-14 14:21:29 --> URI Class Initialized
INFO - 2018-08-14 14:21:29 --> Router Class Initialized
INFO - 2018-08-14 14:21:29 --> Output Class Initialized
INFO - 2018-08-14 14:21:29 --> Security Class Initialized
DEBUG - 2018-08-14 14:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:21:29 --> Input Class Initialized
INFO - 2018-08-14 14:21:29 --> Language Class Initialized
ERROR - 2018-08-14 14:21:29 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:21:30 --> Config Class Initialized
INFO - 2018-08-14 14:21:30 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:21:31 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:21:31 --> Utf8 Class Initialized
INFO - 2018-08-14 14:21:31 --> URI Class Initialized
INFO - 2018-08-14 14:21:31 --> Router Class Initialized
INFO - 2018-08-14 14:21:31 --> Output Class Initialized
INFO - 2018-08-14 14:21:31 --> Security Class Initialized
DEBUG - 2018-08-14 14:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:21:31 --> Input Class Initialized
INFO - 2018-08-14 14:21:31 --> Language Class Initialized
INFO - 2018-08-14 14:21:31 --> Language Class Initialized
INFO - 2018-08-14 14:21:31 --> Config Class Initialized
INFO - 2018-08-14 14:21:31 --> Loader Class Initialized
INFO - 2018-08-14 14:21:31 --> Helper loaded: url_helper
INFO - 2018-08-14 14:21:31 --> Helper loaded: file_helper
INFO - 2018-08-14 14:21:31 --> Helper loaded: form_helper
INFO - 2018-08-14 14:21:31 --> Helper loaded: my_helper
INFO - 2018-08-14 14:21:31 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:21:31 --> Controller Class Initialized
DEBUG - 2018-08-14 14:21:31 --> File loaded: D:\laragon\www\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2018-08-14 14:21:31 --> Final output sent to browser
DEBUG - 2018-08-14 14:21:31 --> Total execution time: 0.5322
INFO - 2018-08-14 14:21:34 --> Config Class Initialized
INFO - 2018-08-14 14:21:34 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:21:34 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:21:34 --> Utf8 Class Initialized
INFO - 2018-08-14 14:21:34 --> URI Class Initialized
INFO - 2018-08-14 14:21:34 --> Router Class Initialized
INFO - 2018-08-14 14:21:34 --> Output Class Initialized
INFO - 2018-08-14 14:21:34 --> Security Class Initialized
DEBUG - 2018-08-14 14:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:21:35 --> Input Class Initialized
INFO - 2018-08-14 14:21:35 --> Language Class Initialized
INFO - 2018-08-14 14:21:35 --> Language Class Initialized
INFO - 2018-08-14 14:21:35 --> Config Class Initialized
INFO - 2018-08-14 14:21:35 --> Loader Class Initialized
INFO - 2018-08-14 14:21:35 --> Helper loaded: url_helper
INFO - 2018-08-14 14:21:35 --> Helper loaded: file_helper
INFO - 2018-08-14 14:21:35 --> Helper loaded: form_helper
INFO - 2018-08-14 14:21:35 --> Helper loaded: my_helper
INFO - 2018-08-14 14:21:35 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:21:35 --> Controller Class Initialized
DEBUG - 2018-08-14 14:21:35 --> File loaded: D:\laragon\www\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2018-08-14 14:21:35 --> Final output sent to browser
DEBUG - 2018-08-14 14:21:35 --> Total execution time: 0.6037
INFO - 2018-08-14 14:21:38 --> Config Class Initialized
INFO - 2018-08-14 14:21:38 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:21:38 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:21:38 --> Utf8 Class Initialized
INFO - 2018-08-14 14:21:38 --> URI Class Initialized
INFO - 2018-08-14 14:21:38 --> Router Class Initialized
INFO - 2018-08-14 14:21:38 --> Output Class Initialized
INFO - 2018-08-14 14:21:38 --> Security Class Initialized
DEBUG - 2018-08-14 14:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:21:38 --> Input Class Initialized
INFO - 2018-08-14 14:21:38 --> Language Class Initialized
INFO - 2018-08-14 14:21:38 --> Language Class Initialized
INFO - 2018-08-14 14:21:39 --> Config Class Initialized
INFO - 2018-08-14 14:21:39 --> Loader Class Initialized
INFO - 2018-08-14 14:21:39 --> Helper loaded: url_helper
INFO - 2018-08-14 14:21:39 --> Helper loaded: file_helper
INFO - 2018-08-14 14:21:39 --> Helper loaded: form_helper
INFO - 2018-08-14 14:21:39 --> Helper loaded: my_helper
INFO - 2018-08-14 14:21:39 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:21:39 --> Controller Class Initialized
DEBUG - 2018-08-14 14:21:39 --> File loaded: D:\laragon\www\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2018-08-14 14:21:39 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:21:39 --> Final output sent to browser
DEBUG - 2018-08-14 14:21:39 --> Total execution time: 0.6185
INFO - 2018-08-14 14:21:39 --> Config Class Initialized
INFO - 2018-08-14 14:21:39 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:21:39 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:21:39 --> Utf8 Class Initialized
INFO - 2018-08-14 14:21:39 --> URI Class Initialized
INFO - 2018-08-14 14:21:39 --> Router Class Initialized
INFO - 2018-08-14 14:21:39 --> Output Class Initialized
INFO - 2018-08-14 14:21:39 --> Security Class Initialized
DEBUG - 2018-08-14 14:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:21:39 --> Input Class Initialized
INFO - 2018-08-14 14:21:39 --> Language Class Initialized
ERROR - 2018-08-14 14:21:39 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:21:42 --> Config Class Initialized
INFO - 2018-08-14 14:21:42 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:21:42 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:21:42 --> Utf8 Class Initialized
INFO - 2018-08-14 14:21:42 --> URI Class Initialized
INFO - 2018-08-14 14:21:42 --> Router Class Initialized
INFO - 2018-08-14 14:21:42 --> Output Class Initialized
INFO - 2018-08-14 14:21:42 --> Security Class Initialized
DEBUG - 2018-08-14 14:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:21:42 --> Input Class Initialized
INFO - 2018-08-14 14:21:42 --> Language Class Initialized
INFO - 2018-08-14 14:21:42 --> Language Class Initialized
INFO - 2018-08-14 14:21:42 --> Config Class Initialized
INFO - 2018-08-14 14:21:42 --> Loader Class Initialized
INFO - 2018-08-14 14:21:42 --> Helper loaded: url_helper
INFO - 2018-08-14 14:21:42 --> Helper loaded: file_helper
INFO - 2018-08-14 14:21:42 --> Helper loaded: form_helper
INFO - 2018-08-14 14:21:42 --> Helper loaded: my_helper
INFO - 2018-08-14 14:21:42 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:21:42 --> Controller Class Initialized
DEBUG - 2018-08-14 14:21:43 --> File loaded: D:\laragon\www\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2018-08-14 14:21:43 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:21:43 --> Final output sent to browser
DEBUG - 2018-08-14 14:21:43 --> Total execution time: 0.6112
INFO - 2018-08-14 14:21:59 --> Config Class Initialized
INFO - 2018-08-14 14:21:59 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:21:59 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:21:59 --> Utf8 Class Initialized
INFO - 2018-08-14 14:21:59 --> URI Class Initialized
INFO - 2018-08-14 14:21:59 --> Router Class Initialized
INFO - 2018-08-14 14:21:59 --> Output Class Initialized
INFO - 2018-08-14 14:21:59 --> Security Class Initialized
DEBUG - 2018-08-14 14:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:21:59 --> Input Class Initialized
INFO - 2018-08-14 14:21:59 --> Language Class Initialized
INFO - 2018-08-14 14:21:59 --> Language Class Initialized
INFO - 2018-08-14 14:21:59 --> Config Class Initialized
INFO - 2018-08-14 14:21:59 --> Loader Class Initialized
INFO - 2018-08-14 14:21:59 --> Helper loaded: url_helper
INFO - 2018-08-14 14:21:59 --> Helper loaded: file_helper
INFO - 2018-08-14 14:21:59 --> Helper loaded: form_helper
INFO - 2018-08-14 14:21:59 --> Helper loaded: my_helper
INFO - 2018-08-14 14:21:59 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:21:59 --> Controller Class Initialized
DEBUG - 2018-08-14 14:21:59 --> File loaded: D:\laragon\www\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2018-08-14 14:21:59 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:21:59 --> Final output sent to browser
DEBUG - 2018-08-14 14:21:59 --> Total execution time: 0.6561
INFO - 2018-08-14 14:22:01 --> Config Class Initialized
INFO - 2018-08-14 14:22:01 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:22:01 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:22:01 --> Utf8 Class Initialized
INFO - 2018-08-14 14:22:01 --> URI Class Initialized
INFO - 2018-08-14 14:22:01 --> Router Class Initialized
INFO - 2018-08-14 14:22:01 --> Output Class Initialized
INFO - 2018-08-14 14:22:01 --> Security Class Initialized
DEBUG - 2018-08-14 14:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:22:01 --> Input Class Initialized
INFO - 2018-08-14 14:22:01 --> Language Class Initialized
INFO - 2018-08-14 14:22:01 --> Language Class Initialized
INFO - 2018-08-14 14:22:01 --> Config Class Initialized
INFO - 2018-08-14 14:22:01 --> Loader Class Initialized
INFO - 2018-08-14 14:22:01 --> Helper loaded: url_helper
INFO - 2018-08-14 14:22:01 --> Helper loaded: file_helper
INFO - 2018-08-14 14:22:01 --> Helper loaded: form_helper
INFO - 2018-08-14 14:22:01 --> Helper loaded: my_helper
INFO - 2018-08-14 14:22:01 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:22:01 --> Controller Class Initialized
INFO - 2018-08-14 14:22:01 --> Final output sent to browser
DEBUG - 2018-08-14 14:22:01 --> Total execution time: 0.6049
INFO - 2018-08-14 14:22:03 --> Config Class Initialized
INFO - 2018-08-14 14:22:03 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:22:03 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:22:03 --> Utf8 Class Initialized
INFO - 2018-08-14 14:22:03 --> URI Class Initialized
INFO - 2018-08-14 14:22:03 --> Router Class Initialized
INFO - 2018-08-14 14:22:03 --> Output Class Initialized
INFO - 2018-08-14 14:22:03 --> Security Class Initialized
DEBUG - 2018-08-14 14:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:22:03 --> Input Class Initialized
INFO - 2018-08-14 14:22:03 --> Language Class Initialized
INFO - 2018-08-14 14:22:03 --> Language Class Initialized
INFO - 2018-08-14 14:22:03 --> Config Class Initialized
INFO - 2018-08-14 14:22:03 --> Loader Class Initialized
INFO - 2018-08-14 14:22:03 --> Helper loaded: url_helper
INFO - 2018-08-14 14:22:03 --> Helper loaded: file_helper
INFO - 2018-08-14 14:22:03 --> Helper loaded: form_helper
INFO - 2018-08-14 14:22:03 --> Helper loaded: my_helper
INFO - 2018-08-14 14:22:03 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:22:03 --> Controller Class Initialized
INFO - 2018-08-14 14:22:03 --> Final output sent to browser
DEBUG - 2018-08-14 14:22:03 --> Total execution time: 0.6197
INFO - 2018-08-14 14:22:04 --> Config Class Initialized
INFO - 2018-08-14 14:22:04 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:22:04 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:22:04 --> Utf8 Class Initialized
INFO - 2018-08-14 14:22:04 --> URI Class Initialized
INFO - 2018-08-14 14:22:04 --> Router Class Initialized
INFO - 2018-08-14 14:22:04 --> Output Class Initialized
INFO - 2018-08-14 14:22:04 --> Security Class Initialized
DEBUG - 2018-08-14 14:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:22:04 --> Input Class Initialized
INFO - 2018-08-14 14:22:04 --> Language Class Initialized
INFO - 2018-08-14 14:22:04 --> Language Class Initialized
INFO - 2018-08-14 14:22:04 --> Config Class Initialized
INFO - 2018-08-14 14:22:04 --> Loader Class Initialized
INFO - 2018-08-14 14:22:04 --> Helper loaded: url_helper
INFO - 2018-08-14 14:22:04 --> Helper loaded: file_helper
INFO - 2018-08-14 14:22:04 --> Helper loaded: form_helper
INFO - 2018-08-14 14:22:04 --> Helper loaded: my_helper
INFO - 2018-08-14 14:22:04 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:22:04 --> Controller Class Initialized
DEBUG - 2018-08-14 14:22:04 --> File loaded: D:\laragon\www\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2018-08-14 14:22:04 --> Final output sent to browser
DEBUG - 2018-08-14 14:22:04 --> Total execution time: 0.5342
INFO - 2018-08-14 14:22:06 --> Config Class Initialized
INFO - 2018-08-14 14:22:06 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:22:06 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:22:06 --> Utf8 Class Initialized
INFO - 2018-08-14 14:22:06 --> URI Class Initialized
INFO - 2018-08-14 14:22:06 --> Router Class Initialized
INFO - 2018-08-14 14:22:06 --> Output Class Initialized
INFO - 2018-08-14 14:22:06 --> Security Class Initialized
DEBUG - 2018-08-14 14:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:22:06 --> Input Class Initialized
INFO - 2018-08-14 14:22:06 --> Language Class Initialized
INFO - 2018-08-14 14:22:06 --> Language Class Initialized
INFO - 2018-08-14 14:22:06 --> Config Class Initialized
INFO - 2018-08-14 14:22:06 --> Loader Class Initialized
INFO - 2018-08-14 14:22:06 --> Helper loaded: url_helper
INFO - 2018-08-14 14:22:06 --> Helper loaded: file_helper
INFO - 2018-08-14 14:22:06 --> Helper loaded: form_helper
INFO - 2018-08-14 14:22:06 --> Helper loaded: my_helper
INFO - 2018-08-14 14:22:06 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:22:06 --> Controller Class Initialized
DEBUG - 2018-08-14 14:22:06 --> File loaded: D:\laragon\www\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2018-08-14 14:22:06 --> Final output sent to browser
DEBUG - 2018-08-14 14:22:06 --> Total execution time: 0.7444
INFO - 2018-08-14 14:22:40 --> Config Class Initialized
INFO - 2018-08-14 14:22:40 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:22:40 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:22:40 --> Utf8 Class Initialized
INFO - 2018-08-14 14:22:40 --> URI Class Initialized
INFO - 2018-08-14 14:22:40 --> Router Class Initialized
INFO - 2018-08-14 14:22:40 --> Output Class Initialized
INFO - 2018-08-14 14:22:40 --> Security Class Initialized
DEBUG - 2018-08-14 14:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:22:40 --> Input Class Initialized
INFO - 2018-08-14 14:22:40 --> Language Class Initialized
INFO - 2018-08-14 14:22:40 --> Language Class Initialized
INFO - 2018-08-14 14:22:40 --> Config Class Initialized
INFO - 2018-08-14 14:22:40 --> Loader Class Initialized
INFO - 2018-08-14 14:22:40 --> Helper loaded: url_helper
INFO - 2018-08-14 14:22:40 --> Helper loaded: file_helper
INFO - 2018-08-14 14:22:40 --> Helper loaded: form_helper
INFO - 2018-08-14 14:22:40 --> Helper loaded: my_helper
INFO - 2018-08-14 14:22:40 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:22:41 --> Controller Class Initialized
DEBUG - 2018-08-14 14:22:41 --> File loaded: D:\laragon\www\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2018-08-14 14:22:41 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:22:41 --> Final output sent to browser
DEBUG - 2018-08-14 14:22:41 --> Total execution time: 0.5311
INFO - 2018-08-14 14:22:43 --> Config Class Initialized
INFO - 2018-08-14 14:22:43 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:22:43 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:22:43 --> Utf8 Class Initialized
INFO - 2018-08-14 14:22:43 --> URI Class Initialized
INFO - 2018-08-14 14:22:43 --> Router Class Initialized
INFO - 2018-08-14 14:22:43 --> Output Class Initialized
INFO - 2018-08-14 14:22:43 --> Security Class Initialized
DEBUG - 2018-08-14 14:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:22:43 --> Input Class Initialized
INFO - 2018-08-14 14:22:43 --> Language Class Initialized
INFO - 2018-08-14 14:22:43 --> Language Class Initialized
INFO - 2018-08-14 14:22:43 --> Config Class Initialized
INFO - 2018-08-14 14:22:43 --> Loader Class Initialized
INFO - 2018-08-14 14:22:43 --> Helper loaded: url_helper
INFO - 2018-08-14 14:22:43 --> Helper loaded: file_helper
INFO - 2018-08-14 14:22:43 --> Helper loaded: form_helper
INFO - 2018-08-14 14:22:43 --> Helper loaded: my_helper
INFO - 2018-08-14 14:22:43 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:22:43 --> Controller Class Initialized
DEBUG - 2018-08-14 14:22:43 --> File loaded: D:\laragon\www\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2018-08-14 14:22:43 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:22:43 --> Final output sent to browser
DEBUG - 2018-08-14 14:22:43 --> Total execution time: 0.6530
INFO - 2018-08-14 14:22:45 --> Config Class Initialized
INFO - 2018-08-14 14:22:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:22:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:22:45 --> Utf8 Class Initialized
INFO - 2018-08-14 14:22:45 --> URI Class Initialized
INFO - 2018-08-14 14:22:45 --> Router Class Initialized
INFO - 2018-08-14 14:22:45 --> Output Class Initialized
INFO - 2018-08-14 14:22:45 --> Security Class Initialized
DEBUG - 2018-08-14 14:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:22:45 --> Input Class Initialized
INFO - 2018-08-14 14:22:45 --> Language Class Initialized
INFO - 2018-08-14 14:22:45 --> Language Class Initialized
INFO - 2018-08-14 14:22:45 --> Config Class Initialized
INFO - 2018-08-14 14:22:45 --> Loader Class Initialized
INFO - 2018-08-14 14:22:45 --> Helper loaded: url_helper
INFO - 2018-08-14 14:22:45 --> Helper loaded: file_helper
INFO - 2018-08-14 14:22:45 --> Helper loaded: form_helper
INFO - 2018-08-14 14:22:45 --> Helper loaded: my_helper
INFO - 2018-08-14 14:22:45 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:22:45 --> Controller Class Initialized
DEBUG - 2018-08-14 14:22:45 --> File loaded: D:\laragon\www\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2018-08-14 14:22:45 --> Final output sent to browser
DEBUG - 2018-08-14 14:22:45 --> Total execution time: 0.5905
INFO - 2018-08-14 14:22:51 --> Config Class Initialized
INFO - 2018-08-14 14:22:51 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:22:51 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:22:51 --> Utf8 Class Initialized
INFO - 2018-08-14 14:22:51 --> URI Class Initialized
INFO - 2018-08-14 14:22:51 --> Router Class Initialized
INFO - 2018-08-14 14:22:51 --> Output Class Initialized
INFO - 2018-08-14 14:22:51 --> Security Class Initialized
DEBUG - 2018-08-14 14:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:22:51 --> Input Class Initialized
INFO - 2018-08-14 14:22:51 --> Language Class Initialized
INFO - 2018-08-14 14:22:51 --> Language Class Initialized
INFO - 2018-08-14 14:22:51 --> Config Class Initialized
INFO - 2018-08-14 14:22:51 --> Loader Class Initialized
INFO - 2018-08-14 14:22:51 --> Helper loaded: url_helper
INFO - 2018-08-14 14:22:51 --> Helper loaded: file_helper
INFO - 2018-08-14 14:22:51 --> Helper loaded: form_helper
INFO - 2018-08-14 14:22:51 --> Helper loaded: my_helper
INFO - 2018-08-14 14:22:51 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:22:51 --> Controller Class Initialized
DEBUG - 2018-08-14 14:22:52 --> File loaded: D:\laragon\www\nilai\application\modules/cetak_leger/views/cetak_ekstra.php
INFO - 2018-08-14 14:22:52 --> Final output sent to browser
DEBUG - 2018-08-14 14:22:52 --> Total execution time: 0.7121
INFO - 2018-08-14 14:22:58 --> Config Class Initialized
INFO - 2018-08-14 14:22:58 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:22:58 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:22:58 --> Utf8 Class Initialized
INFO - 2018-08-14 14:22:58 --> URI Class Initialized
INFO - 2018-08-14 14:22:58 --> Router Class Initialized
INFO - 2018-08-14 14:22:58 --> Output Class Initialized
INFO - 2018-08-14 14:22:58 --> Security Class Initialized
DEBUG - 2018-08-14 14:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:22:58 --> Input Class Initialized
INFO - 2018-08-14 14:22:58 --> Language Class Initialized
INFO - 2018-08-14 14:22:58 --> Language Class Initialized
INFO - 2018-08-14 14:22:58 --> Config Class Initialized
INFO - 2018-08-14 14:22:58 --> Loader Class Initialized
INFO - 2018-08-14 14:22:58 --> Helper loaded: url_helper
INFO - 2018-08-14 14:22:58 --> Helper loaded: file_helper
INFO - 2018-08-14 14:22:58 --> Helper loaded: form_helper
INFO - 2018-08-14 14:22:58 --> Helper loaded: my_helper
INFO - 2018-08-14 14:22:58 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:22:58 --> Controller Class Initialized
DEBUG - 2018-08-14 14:22:58 --> File loaded: D:\laragon\www\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2018-08-14 14:22:58 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:22:58 --> Final output sent to browser
DEBUG - 2018-08-14 14:22:59 --> Total execution time: 0.9379
INFO - 2018-08-14 14:23:00 --> Config Class Initialized
INFO - 2018-08-14 14:23:00 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:23:00 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:23:00 --> Utf8 Class Initialized
INFO - 2018-08-14 14:23:00 --> URI Class Initialized
INFO - 2018-08-14 14:23:00 --> Router Class Initialized
INFO - 2018-08-14 14:23:00 --> Output Class Initialized
INFO - 2018-08-14 14:23:00 --> Security Class Initialized
DEBUG - 2018-08-14 14:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:23:00 --> Input Class Initialized
INFO - 2018-08-14 14:23:00 --> Language Class Initialized
INFO - 2018-08-14 14:23:00 --> Language Class Initialized
INFO - 2018-08-14 14:23:00 --> Config Class Initialized
INFO - 2018-08-14 14:23:00 --> Loader Class Initialized
INFO - 2018-08-14 14:23:00 --> Helper loaded: url_helper
INFO - 2018-08-14 14:23:00 --> Helper loaded: file_helper
INFO - 2018-08-14 14:23:00 --> Helper loaded: form_helper
INFO - 2018-08-14 14:23:00 --> Helper loaded: my_helper
INFO - 2018-08-14 14:23:00 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:23:00 --> Controller Class Initialized
DEBUG - 2018-08-14 14:23:00 --> File loaded: D:\laragon\www\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2018-08-14 14:23:00 --> Final output sent to browser
DEBUG - 2018-08-14 14:23:00 --> Total execution time: 0.5978
INFO - 2018-08-14 14:23:04 --> Config Class Initialized
INFO - 2018-08-14 14:23:04 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:23:04 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:23:04 --> Utf8 Class Initialized
INFO - 2018-08-14 14:23:04 --> URI Class Initialized
INFO - 2018-08-14 14:23:04 --> Router Class Initialized
INFO - 2018-08-14 14:23:04 --> Output Class Initialized
INFO - 2018-08-14 14:23:05 --> Security Class Initialized
DEBUG - 2018-08-14 14:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:23:05 --> Input Class Initialized
INFO - 2018-08-14 14:23:05 --> Language Class Initialized
INFO - 2018-08-14 14:23:05 --> Language Class Initialized
INFO - 2018-08-14 14:23:05 --> Config Class Initialized
INFO - 2018-08-14 14:23:05 --> Loader Class Initialized
INFO - 2018-08-14 14:23:05 --> Helper loaded: url_helper
INFO - 2018-08-14 14:23:05 --> Helper loaded: file_helper
INFO - 2018-08-14 14:23:05 --> Helper loaded: form_helper
INFO - 2018-08-14 14:23:05 --> Helper loaded: my_helper
INFO - 2018-08-14 14:23:05 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:23:05 --> Controller Class Initialized
DEBUG - 2018-08-14 14:23:05 --> File loaded: D:\laragon\www\nilai\application\modules/cetak_raport/views/cetak_prestasi.php
INFO - 2018-08-14 14:23:05 --> Final output sent to browser
DEBUG - 2018-08-14 14:23:05 --> Total execution time: 0.5273
INFO - 2018-08-14 14:23:12 --> Config Class Initialized
INFO - 2018-08-14 14:23:12 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:23:12 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:23:12 --> Utf8 Class Initialized
INFO - 2018-08-14 14:23:12 --> URI Class Initialized
INFO - 2018-08-14 14:23:12 --> Router Class Initialized
INFO - 2018-08-14 14:23:12 --> Output Class Initialized
INFO - 2018-08-14 14:23:12 --> Security Class Initialized
DEBUG - 2018-08-14 14:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:23:12 --> Input Class Initialized
INFO - 2018-08-14 14:23:12 --> Language Class Initialized
INFO - 2018-08-14 14:23:12 --> Language Class Initialized
INFO - 2018-08-14 14:23:12 --> Config Class Initialized
INFO - 2018-08-14 14:23:12 --> Loader Class Initialized
INFO - 2018-08-14 14:23:12 --> Helper loaded: url_helper
INFO - 2018-08-14 14:23:12 --> Helper loaded: file_helper
INFO - 2018-08-14 14:23:12 --> Helper loaded: form_helper
INFO - 2018-08-14 14:23:13 --> Helper loaded: my_helper
INFO - 2018-08-14 14:23:13 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:23:13 --> Controller Class Initialized
DEBUG - 2018-08-14 14:23:13 --> File loaded: D:\laragon\www\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2018-08-14 14:23:13 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:23:13 --> Final output sent to browser
DEBUG - 2018-08-14 14:23:13 --> Total execution time: 0.8233
INFO - 2018-08-14 14:23:18 --> Config Class Initialized
INFO - 2018-08-14 14:23:19 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:23:19 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:23:19 --> Utf8 Class Initialized
INFO - 2018-08-14 14:23:19 --> URI Class Initialized
INFO - 2018-08-14 14:23:19 --> Router Class Initialized
INFO - 2018-08-14 14:23:19 --> Output Class Initialized
INFO - 2018-08-14 14:23:19 --> Security Class Initialized
DEBUG - 2018-08-14 14:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:23:19 --> Input Class Initialized
INFO - 2018-08-14 14:23:19 --> Language Class Initialized
INFO - 2018-08-14 14:23:19 --> Language Class Initialized
INFO - 2018-08-14 14:23:19 --> Config Class Initialized
INFO - 2018-08-14 14:23:19 --> Loader Class Initialized
INFO - 2018-08-14 14:23:19 --> Helper loaded: url_helper
INFO - 2018-08-14 14:23:19 --> Helper loaded: file_helper
INFO - 2018-08-14 14:23:19 --> Helper loaded: form_helper
INFO - 2018-08-14 14:23:19 --> Helper loaded: my_helper
INFO - 2018-08-14 14:23:19 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:23:19 --> Controller Class Initialized
INFO - 2018-08-14 14:23:19 --> Final output sent to browser
DEBUG - 2018-08-14 14:23:19 --> Total execution time: 0.7153
INFO - 2018-08-14 14:23:22 --> Config Class Initialized
INFO - 2018-08-14 14:23:22 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:23:22 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:23:22 --> Utf8 Class Initialized
INFO - 2018-08-14 14:23:22 --> URI Class Initialized
INFO - 2018-08-14 14:23:22 --> Router Class Initialized
INFO - 2018-08-14 14:23:22 --> Output Class Initialized
INFO - 2018-08-14 14:23:22 --> Security Class Initialized
DEBUG - 2018-08-14 14:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:23:22 --> Input Class Initialized
INFO - 2018-08-14 14:23:23 --> Language Class Initialized
INFO - 2018-08-14 14:23:23 --> Language Class Initialized
INFO - 2018-08-14 14:23:23 --> Config Class Initialized
INFO - 2018-08-14 14:23:23 --> Loader Class Initialized
INFO - 2018-08-14 14:23:23 --> Helper loaded: url_helper
INFO - 2018-08-14 14:23:23 --> Helper loaded: file_helper
INFO - 2018-08-14 14:23:23 --> Helper loaded: form_helper
INFO - 2018-08-14 14:23:23 --> Helper loaded: my_helper
INFO - 2018-08-14 14:23:23 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:23:23 --> Controller Class Initialized
DEBUG - 2018-08-14 14:23:23 --> File loaded: D:\laragon\www\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2018-08-14 14:23:23 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:23:23 --> Final output sent to browser
DEBUG - 2018-08-14 14:23:23 --> Total execution time: 0.6968
INFO - 2018-08-14 14:23:24 --> Config Class Initialized
INFO - 2018-08-14 14:23:24 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:23:25 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:23:25 --> Utf8 Class Initialized
INFO - 2018-08-14 14:23:25 --> URI Class Initialized
INFO - 2018-08-14 14:23:25 --> Router Class Initialized
INFO - 2018-08-14 14:23:25 --> Output Class Initialized
INFO - 2018-08-14 14:23:25 --> Security Class Initialized
DEBUG - 2018-08-14 14:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:23:25 --> Input Class Initialized
INFO - 2018-08-14 14:23:25 --> Language Class Initialized
INFO - 2018-08-14 14:23:25 --> Language Class Initialized
INFO - 2018-08-14 14:23:25 --> Config Class Initialized
INFO - 2018-08-14 14:23:25 --> Loader Class Initialized
INFO - 2018-08-14 14:23:25 --> Helper loaded: url_helper
INFO - 2018-08-14 14:23:25 --> Helper loaded: file_helper
INFO - 2018-08-14 14:23:25 --> Helper loaded: form_helper
INFO - 2018-08-14 14:23:25 --> Helper loaded: my_helper
INFO - 2018-08-14 14:23:25 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:23:25 --> Controller Class Initialized
INFO - 2018-08-14 14:23:25 --> Final output sent to browser
DEBUG - 2018-08-14 14:23:25 --> Total execution time: 0.7990
INFO - 2018-08-14 14:23:30 --> Config Class Initialized
INFO - 2018-08-14 14:23:30 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:23:30 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:23:30 --> Utf8 Class Initialized
INFO - 2018-08-14 14:23:30 --> URI Class Initialized
INFO - 2018-08-14 14:23:30 --> Router Class Initialized
INFO - 2018-08-14 14:23:30 --> Output Class Initialized
INFO - 2018-08-14 14:23:30 --> Security Class Initialized
DEBUG - 2018-08-14 14:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:23:30 --> Input Class Initialized
INFO - 2018-08-14 14:23:31 --> Language Class Initialized
INFO - 2018-08-14 14:23:31 --> Language Class Initialized
INFO - 2018-08-14 14:23:31 --> Config Class Initialized
INFO - 2018-08-14 14:23:31 --> Loader Class Initialized
INFO - 2018-08-14 14:23:31 --> Helper loaded: url_helper
INFO - 2018-08-14 14:23:31 --> Helper loaded: file_helper
INFO - 2018-08-14 14:23:31 --> Helper loaded: form_helper
INFO - 2018-08-14 14:23:31 --> Helper loaded: my_helper
INFO - 2018-08-14 14:23:31 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:23:31 --> Controller Class Initialized
INFO - 2018-08-14 14:23:31 --> Final output sent to browser
DEBUG - 2018-08-14 14:23:31 --> Total execution time: 0.5805
INFO - 2018-08-14 14:23:32 --> Config Class Initialized
INFO - 2018-08-14 14:23:32 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:23:32 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:23:32 --> Utf8 Class Initialized
INFO - 2018-08-14 14:23:33 --> URI Class Initialized
INFO - 2018-08-14 14:23:33 --> Router Class Initialized
INFO - 2018-08-14 14:23:33 --> Output Class Initialized
INFO - 2018-08-14 14:23:33 --> Security Class Initialized
DEBUG - 2018-08-14 14:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:23:33 --> Input Class Initialized
INFO - 2018-08-14 14:23:33 --> Language Class Initialized
INFO - 2018-08-14 14:23:33 --> Language Class Initialized
INFO - 2018-08-14 14:23:33 --> Config Class Initialized
INFO - 2018-08-14 14:23:33 --> Loader Class Initialized
INFO - 2018-08-14 14:23:33 --> Helper loaded: url_helper
INFO - 2018-08-14 14:23:33 --> Helper loaded: file_helper
INFO - 2018-08-14 14:23:33 --> Helper loaded: form_helper
INFO - 2018-08-14 14:23:33 --> Helper loaded: my_helper
INFO - 2018-08-14 14:23:33 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:23:33 --> Controller Class Initialized
INFO - 2018-08-14 14:23:33 --> Final output sent to browser
DEBUG - 2018-08-14 14:23:33 --> Total execution time: 0.6694
INFO - 2018-08-14 14:23:37 --> Config Class Initialized
INFO - 2018-08-14 14:23:37 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:23:37 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:23:37 --> Utf8 Class Initialized
INFO - 2018-08-14 14:23:37 --> URI Class Initialized
INFO - 2018-08-14 14:23:37 --> Router Class Initialized
INFO - 2018-08-14 14:23:37 --> Output Class Initialized
INFO - 2018-08-14 14:23:37 --> Security Class Initialized
DEBUG - 2018-08-14 14:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:23:37 --> Input Class Initialized
INFO - 2018-08-14 14:23:37 --> Language Class Initialized
INFO - 2018-08-14 14:23:37 --> Language Class Initialized
INFO - 2018-08-14 14:23:37 --> Config Class Initialized
INFO - 2018-08-14 14:23:37 --> Loader Class Initialized
INFO - 2018-08-14 14:23:37 --> Helper loaded: url_helper
INFO - 2018-08-14 14:23:37 --> Helper loaded: file_helper
INFO - 2018-08-14 14:23:37 --> Helper loaded: form_helper
INFO - 2018-08-14 14:23:37 --> Helper loaded: my_helper
INFO - 2018-08-14 14:23:37 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:23:37 --> Controller Class Initialized
INFO - 2018-08-14 14:23:37 --> Final output sent to browser
DEBUG - 2018-08-14 14:23:37 --> Total execution time: 0.6055
INFO - 2018-08-14 14:23:45 --> Config Class Initialized
INFO - 2018-08-14 14:23:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:23:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:23:45 --> Utf8 Class Initialized
INFO - 2018-08-14 14:23:45 --> URI Class Initialized
INFO - 2018-08-14 14:23:45 --> Router Class Initialized
INFO - 2018-08-14 14:23:45 --> Output Class Initialized
INFO - 2018-08-14 14:23:45 --> Security Class Initialized
DEBUG - 2018-08-14 14:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:23:45 --> Input Class Initialized
INFO - 2018-08-14 14:23:45 --> Language Class Initialized
INFO - 2018-08-14 14:23:45 --> Language Class Initialized
INFO - 2018-08-14 14:23:45 --> Config Class Initialized
INFO - 2018-08-14 14:23:45 --> Loader Class Initialized
INFO - 2018-08-14 14:23:45 --> Helper loaded: url_helper
INFO - 2018-08-14 14:23:45 --> Helper loaded: file_helper
INFO - 2018-08-14 14:23:45 --> Helper loaded: form_helper
INFO - 2018-08-14 14:23:45 --> Helper loaded: my_helper
INFO - 2018-08-14 14:23:45 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:23:45 --> Controller Class Initialized
DEBUG - 2018-08-14 14:23:45 --> File loaded: D:\laragon\www\nilai\application\modules/n_prestasi/views/list.php
DEBUG - 2018-08-14 14:23:45 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:23:45 --> Final output sent to browser
DEBUG - 2018-08-14 14:23:45 --> Total execution time: 0.6595
INFO - 2018-08-14 14:23:45 --> Config Class Initialized
INFO - 2018-08-14 14:23:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:23:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:23:46 --> Utf8 Class Initialized
INFO - 2018-08-14 14:23:46 --> URI Class Initialized
INFO - 2018-08-14 14:23:46 --> Router Class Initialized
INFO - 2018-08-14 14:23:46 --> Output Class Initialized
INFO - 2018-08-14 14:23:46 --> Security Class Initialized
DEBUG - 2018-08-14 14:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:23:46 --> Input Class Initialized
INFO - 2018-08-14 14:23:46 --> Language Class Initialized
INFO - 2018-08-14 14:23:46 --> Language Class Initialized
INFO - 2018-08-14 14:23:46 --> Config Class Initialized
INFO - 2018-08-14 14:23:46 --> Loader Class Initialized
INFO - 2018-08-14 14:23:46 --> Helper loaded: url_helper
INFO - 2018-08-14 14:23:46 --> Helper loaded: file_helper
INFO - 2018-08-14 14:23:46 --> Helper loaded: form_helper
INFO - 2018-08-14 14:23:46 --> Helper loaded: my_helper
INFO - 2018-08-14 14:23:46 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:23:46 --> Controller Class Initialized
INFO - 2018-08-14 14:23:56 --> Config Class Initialized
INFO - 2018-08-14 14:23:56 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:23:56 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:23:57 --> Utf8 Class Initialized
INFO - 2018-08-14 14:23:57 --> URI Class Initialized
INFO - 2018-08-14 14:23:57 --> Router Class Initialized
INFO - 2018-08-14 14:23:57 --> Output Class Initialized
INFO - 2018-08-14 14:23:57 --> Security Class Initialized
DEBUG - 2018-08-14 14:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:23:57 --> Input Class Initialized
INFO - 2018-08-14 14:23:57 --> Language Class Initialized
INFO - 2018-08-14 14:23:57 --> Language Class Initialized
INFO - 2018-08-14 14:23:57 --> Config Class Initialized
INFO - 2018-08-14 14:23:57 --> Loader Class Initialized
INFO - 2018-08-14 14:23:57 --> Helper loaded: url_helper
INFO - 2018-08-14 14:23:57 --> Helper loaded: file_helper
INFO - 2018-08-14 14:23:57 --> Helper loaded: form_helper
INFO - 2018-08-14 14:23:57 --> Helper loaded: my_helper
INFO - 2018-08-14 14:23:57 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:23:57 --> Controller Class Initialized
INFO - 2018-08-14 14:23:57 --> Final output sent to browser
DEBUG - 2018-08-14 14:23:57 --> Total execution time: 0.5133
INFO - 2018-08-14 14:23:57 --> Config Class Initialized
INFO - 2018-08-14 14:23:57 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:23:57 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:23:57 --> Utf8 Class Initialized
INFO - 2018-08-14 14:23:57 --> URI Class Initialized
INFO - 2018-08-14 14:23:57 --> Router Class Initialized
INFO - 2018-08-14 14:23:57 --> Output Class Initialized
INFO - 2018-08-14 14:23:57 --> Security Class Initialized
DEBUG - 2018-08-14 14:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:23:57 --> Input Class Initialized
INFO - 2018-08-14 14:23:57 --> Language Class Initialized
INFO - 2018-08-14 14:23:57 --> Language Class Initialized
INFO - 2018-08-14 14:23:57 --> Config Class Initialized
INFO - 2018-08-14 14:23:57 --> Loader Class Initialized
INFO - 2018-08-14 14:23:57 --> Helper loaded: url_helper
INFO - 2018-08-14 14:23:57 --> Helper loaded: file_helper
INFO - 2018-08-14 14:23:57 --> Helper loaded: form_helper
INFO - 2018-08-14 14:23:57 --> Helper loaded: my_helper
INFO - 2018-08-14 14:23:57 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:23:58 --> Controller Class Initialized
INFO - 2018-08-14 14:24:01 --> Config Class Initialized
INFO - 2018-08-14 14:24:01 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:24:01 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:24:01 --> Utf8 Class Initialized
INFO - 2018-08-14 14:24:01 --> URI Class Initialized
INFO - 2018-08-14 14:24:01 --> Router Class Initialized
INFO - 2018-08-14 14:24:01 --> Output Class Initialized
INFO - 2018-08-14 14:24:01 --> Security Class Initialized
DEBUG - 2018-08-14 14:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:24:01 --> Input Class Initialized
INFO - 2018-08-14 14:24:01 --> Language Class Initialized
INFO - 2018-08-14 14:24:01 --> Language Class Initialized
INFO - 2018-08-14 14:24:01 --> Config Class Initialized
INFO - 2018-08-14 14:24:01 --> Loader Class Initialized
INFO - 2018-08-14 14:24:01 --> Helper loaded: url_helper
INFO - 2018-08-14 14:24:01 --> Helper loaded: file_helper
INFO - 2018-08-14 14:24:01 --> Helper loaded: form_helper
INFO - 2018-08-14 14:24:01 --> Helper loaded: my_helper
INFO - 2018-08-14 14:24:01 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:24:01 --> Controller Class Initialized
DEBUG - 2018-08-14 14:24:01 --> File loaded: D:\laragon\www\nilai\application\modules/n_prestasi/views/list.php
DEBUG - 2018-08-14 14:24:01 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:24:01 --> Final output sent to browser
DEBUG - 2018-08-14 14:24:01 --> Total execution time: 0.7312
INFO - 2018-08-14 14:24:02 --> Config Class Initialized
INFO - 2018-08-14 14:24:02 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:24:02 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:24:02 --> Utf8 Class Initialized
INFO - 2018-08-14 14:24:02 --> URI Class Initialized
INFO - 2018-08-14 14:24:02 --> Router Class Initialized
INFO - 2018-08-14 14:24:02 --> Output Class Initialized
INFO - 2018-08-14 14:24:02 --> Security Class Initialized
DEBUG - 2018-08-14 14:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:24:02 --> Input Class Initialized
INFO - 2018-08-14 14:24:02 --> Language Class Initialized
INFO - 2018-08-14 14:24:02 --> Language Class Initialized
INFO - 2018-08-14 14:24:02 --> Config Class Initialized
INFO - 2018-08-14 14:24:02 --> Loader Class Initialized
INFO - 2018-08-14 14:24:02 --> Helper loaded: url_helper
INFO - 2018-08-14 14:24:02 --> Helper loaded: file_helper
INFO - 2018-08-14 14:24:02 --> Helper loaded: form_helper
INFO - 2018-08-14 14:24:02 --> Helper loaded: my_helper
INFO - 2018-08-14 14:24:02 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:24:02 --> Controller Class Initialized
INFO - 2018-08-14 14:24:59 --> Config Class Initialized
INFO - 2018-08-14 14:24:59 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:24:59 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:24:59 --> Utf8 Class Initialized
INFO - 2018-08-14 14:24:59 --> URI Class Initialized
INFO - 2018-08-14 14:24:59 --> Router Class Initialized
INFO - 2018-08-14 14:24:59 --> Output Class Initialized
INFO - 2018-08-14 14:24:59 --> Security Class Initialized
DEBUG - 2018-08-14 14:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:24:59 --> Input Class Initialized
INFO - 2018-08-14 14:24:59 --> Language Class Initialized
INFO - 2018-08-14 14:24:59 --> Language Class Initialized
INFO - 2018-08-14 14:24:59 --> Config Class Initialized
INFO - 2018-08-14 14:24:59 --> Loader Class Initialized
INFO - 2018-08-14 14:24:59 --> Helper loaded: url_helper
INFO - 2018-08-14 14:24:59 --> Helper loaded: file_helper
INFO - 2018-08-14 14:24:59 --> Helper loaded: form_helper
INFO - 2018-08-14 14:24:59 --> Helper loaded: my_helper
INFO - 2018-08-14 14:24:59 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:24:59 --> Controller Class Initialized
DEBUG - 2018-08-14 14:24:59 --> File loaded: D:\laragon\www\nilai\application\modules/n_prestasi/views/list.php
DEBUG - 2018-08-14 14:24:59 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:24:59 --> Final output sent to browser
DEBUG - 2018-08-14 14:24:59 --> Total execution time: 0.6831
INFO - 2018-08-14 14:24:59 --> Config Class Initialized
INFO - 2018-08-14 14:24:59 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:24:59 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:24:59 --> Utf8 Class Initialized
INFO - 2018-08-14 14:24:59 --> URI Class Initialized
INFO - 2018-08-14 14:24:59 --> Router Class Initialized
INFO - 2018-08-14 14:24:59 --> Output Class Initialized
INFO - 2018-08-14 14:24:59 --> Security Class Initialized
DEBUG - 2018-08-14 14:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:25:00 --> Input Class Initialized
INFO - 2018-08-14 14:25:00 --> Language Class Initialized
INFO - 2018-08-14 14:25:00 --> Language Class Initialized
INFO - 2018-08-14 14:25:00 --> Config Class Initialized
INFO - 2018-08-14 14:25:00 --> Loader Class Initialized
INFO - 2018-08-14 14:25:00 --> Helper loaded: url_helper
INFO - 2018-08-14 14:25:00 --> Helper loaded: file_helper
INFO - 2018-08-14 14:25:00 --> Helper loaded: form_helper
INFO - 2018-08-14 14:25:00 --> Helper loaded: my_helper
INFO - 2018-08-14 14:25:00 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:25:00 --> Controller Class Initialized
INFO - 2018-08-14 14:25:06 --> Config Class Initialized
INFO - 2018-08-14 14:25:07 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:25:07 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:25:07 --> Utf8 Class Initialized
INFO - 2018-08-14 14:25:07 --> URI Class Initialized
INFO - 2018-08-14 14:25:07 --> Router Class Initialized
INFO - 2018-08-14 14:25:07 --> Output Class Initialized
INFO - 2018-08-14 14:25:07 --> Security Class Initialized
DEBUG - 2018-08-14 14:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:25:07 --> Input Class Initialized
INFO - 2018-08-14 14:25:07 --> Language Class Initialized
INFO - 2018-08-14 14:25:07 --> Language Class Initialized
INFO - 2018-08-14 14:25:07 --> Config Class Initialized
INFO - 2018-08-14 14:25:07 --> Loader Class Initialized
INFO - 2018-08-14 14:25:07 --> Helper loaded: url_helper
INFO - 2018-08-14 14:25:07 --> Helper loaded: file_helper
INFO - 2018-08-14 14:25:07 --> Helper loaded: form_helper
INFO - 2018-08-14 14:25:07 --> Helper loaded: my_helper
INFO - 2018-08-14 14:25:07 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:25:07 --> Controller Class Initialized
INFO - 2018-08-14 14:25:07 --> Final output sent to browser
DEBUG - 2018-08-14 14:25:07 --> Total execution time: 0.5104
INFO - 2018-08-14 14:25:07 --> Config Class Initialized
INFO - 2018-08-14 14:25:07 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:25:07 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:25:07 --> Utf8 Class Initialized
INFO - 2018-08-14 14:25:07 --> URI Class Initialized
INFO - 2018-08-14 14:25:07 --> Router Class Initialized
INFO - 2018-08-14 14:25:07 --> Output Class Initialized
INFO - 2018-08-14 14:25:07 --> Security Class Initialized
DEBUG - 2018-08-14 14:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:25:07 --> Input Class Initialized
INFO - 2018-08-14 14:25:07 --> Language Class Initialized
INFO - 2018-08-14 14:25:07 --> Language Class Initialized
INFO - 2018-08-14 14:25:07 --> Config Class Initialized
INFO - 2018-08-14 14:25:07 --> Loader Class Initialized
INFO - 2018-08-14 14:25:08 --> Helper loaded: url_helper
INFO - 2018-08-14 14:25:08 --> Helper loaded: file_helper
INFO - 2018-08-14 14:25:08 --> Helper loaded: form_helper
INFO - 2018-08-14 14:25:08 --> Helper loaded: my_helper
INFO - 2018-08-14 14:25:08 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:25:08 --> Controller Class Initialized
INFO - 2018-08-14 14:25:12 --> Config Class Initialized
INFO - 2018-08-14 14:25:12 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:25:12 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:25:12 --> Utf8 Class Initialized
INFO - 2018-08-14 14:25:12 --> URI Class Initialized
INFO - 2018-08-14 14:25:12 --> Router Class Initialized
INFO - 2018-08-14 14:25:12 --> Output Class Initialized
INFO - 2018-08-14 14:25:12 --> Security Class Initialized
DEBUG - 2018-08-14 14:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:25:12 --> Input Class Initialized
INFO - 2018-08-14 14:25:12 --> Language Class Initialized
INFO - 2018-08-14 14:25:12 --> Language Class Initialized
INFO - 2018-08-14 14:25:12 --> Config Class Initialized
INFO - 2018-08-14 14:25:12 --> Loader Class Initialized
INFO - 2018-08-14 14:25:12 --> Helper loaded: url_helper
INFO - 2018-08-14 14:25:12 --> Helper loaded: file_helper
INFO - 2018-08-14 14:25:13 --> Helper loaded: form_helper
INFO - 2018-08-14 14:25:13 --> Helper loaded: my_helper
INFO - 2018-08-14 14:25:13 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:25:13 --> Controller Class Initialized
DEBUG - 2018-08-14 14:25:13 --> File loaded: D:\laragon\www\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2018-08-14 14:25:13 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:25:13 --> Final output sent to browser
DEBUG - 2018-08-14 14:25:13 --> Total execution time: 0.8004
INFO - 2018-08-14 14:25:27 --> Config Class Initialized
INFO - 2018-08-14 14:25:27 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:25:27 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:25:27 --> Utf8 Class Initialized
INFO - 2018-08-14 14:25:27 --> URI Class Initialized
INFO - 2018-08-14 14:25:27 --> Router Class Initialized
INFO - 2018-08-14 14:25:27 --> Output Class Initialized
INFO - 2018-08-14 14:25:27 --> Security Class Initialized
DEBUG - 2018-08-14 14:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:25:27 --> Input Class Initialized
INFO - 2018-08-14 14:25:27 --> Language Class Initialized
INFO - 2018-08-14 14:25:27 --> Language Class Initialized
INFO - 2018-08-14 14:25:27 --> Config Class Initialized
INFO - 2018-08-14 14:25:27 --> Loader Class Initialized
INFO - 2018-08-14 14:25:27 --> Helper loaded: url_helper
INFO - 2018-08-14 14:25:27 --> Helper loaded: file_helper
INFO - 2018-08-14 14:25:27 --> Helper loaded: form_helper
INFO - 2018-08-14 14:25:27 --> Helper loaded: my_helper
INFO - 2018-08-14 14:25:27 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:25:28 --> Controller Class Initialized
INFO - 2018-08-14 14:25:28 --> Final output sent to browser
DEBUG - 2018-08-14 14:25:28 --> Total execution time: 0.5313
INFO - 2018-08-14 14:25:29 --> Config Class Initialized
INFO - 2018-08-14 14:25:29 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:25:29 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:25:29 --> Utf8 Class Initialized
INFO - 2018-08-14 14:25:29 --> URI Class Initialized
INFO - 2018-08-14 14:25:29 --> Router Class Initialized
INFO - 2018-08-14 14:25:29 --> Output Class Initialized
INFO - 2018-08-14 14:25:29 --> Security Class Initialized
DEBUG - 2018-08-14 14:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:25:29 --> Input Class Initialized
INFO - 2018-08-14 14:25:29 --> Language Class Initialized
INFO - 2018-08-14 14:25:29 --> Language Class Initialized
INFO - 2018-08-14 14:25:29 --> Config Class Initialized
INFO - 2018-08-14 14:25:29 --> Loader Class Initialized
INFO - 2018-08-14 14:25:29 --> Helper loaded: url_helper
INFO - 2018-08-14 14:25:29 --> Helper loaded: file_helper
INFO - 2018-08-14 14:25:29 --> Helper loaded: form_helper
INFO - 2018-08-14 14:25:29 --> Helper loaded: my_helper
INFO - 2018-08-14 14:25:29 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:25:30 --> Controller Class Initialized
DEBUG - 2018-08-14 14:25:30 --> File loaded: D:\laragon\www\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2018-08-14 14:25:30 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:25:30 --> Final output sent to browser
DEBUG - 2018-08-14 14:25:30 --> Total execution time: 0.9946
INFO - 2018-08-14 14:25:33 --> Config Class Initialized
INFO - 2018-08-14 14:25:33 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:25:33 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:25:33 --> Utf8 Class Initialized
INFO - 2018-08-14 14:25:33 --> URI Class Initialized
INFO - 2018-08-14 14:25:33 --> Router Class Initialized
INFO - 2018-08-14 14:25:33 --> Output Class Initialized
INFO - 2018-08-14 14:25:33 --> Security Class Initialized
DEBUG - 2018-08-14 14:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:25:33 --> Input Class Initialized
INFO - 2018-08-14 14:25:33 --> Language Class Initialized
INFO - 2018-08-14 14:25:33 --> Language Class Initialized
INFO - 2018-08-14 14:25:33 --> Config Class Initialized
INFO - 2018-08-14 14:25:33 --> Loader Class Initialized
INFO - 2018-08-14 14:25:33 --> Helper loaded: url_helper
INFO - 2018-08-14 14:25:33 --> Helper loaded: file_helper
INFO - 2018-08-14 14:25:33 --> Helper loaded: form_helper
INFO - 2018-08-14 14:25:33 --> Helper loaded: my_helper
INFO - 2018-08-14 14:25:33 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:25:34 --> Controller Class Initialized
DEBUG - 2018-08-14 14:25:34 --> File loaded: D:\laragon\www\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2018-08-14 14:25:34 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:25:34 --> Final output sent to browser
DEBUG - 2018-08-14 14:25:34 --> Total execution time: 0.7356
INFO - 2018-08-14 14:25:35 --> Config Class Initialized
INFO - 2018-08-14 14:25:35 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:25:35 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:25:35 --> Utf8 Class Initialized
INFO - 2018-08-14 14:25:35 --> URI Class Initialized
INFO - 2018-08-14 14:25:35 --> Router Class Initialized
INFO - 2018-08-14 14:25:35 --> Output Class Initialized
INFO - 2018-08-14 14:25:35 --> Security Class Initialized
DEBUG - 2018-08-14 14:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:25:36 --> Input Class Initialized
INFO - 2018-08-14 14:25:36 --> Language Class Initialized
INFO - 2018-08-14 14:25:36 --> Language Class Initialized
INFO - 2018-08-14 14:25:36 --> Config Class Initialized
INFO - 2018-08-14 14:25:36 --> Loader Class Initialized
INFO - 2018-08-14 14:25:36 --> Helper loaded: url_helper
INFO - 2018-08-14 14:25:36 --> Helper loaded: file_helper
INFO - 2018-08-14 14:25:36 --> Helper loaded: form_helper
INFO - 2018-08-14 14:25:36 --> Helper loaded: my_helper
INFO - 2018-08-14 14:25:36 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:25:36 --> Controller Class Initialized
DEBUG - 2018-08-14 14:25:36 --> File loaded: D:\laragon\www\nilai\application\modules/cetak_raport/views/cetak_prestasi.php
INFO - 2018-08-14 14:25:36 --> Final output sent to browser
DEBUG - 2018-08-14 14:25:36 --> Total execution time: 0.5986
INFO - 2018-08-14 14:25:43 --> Config Class Initialized
INFO - 2018-08-14 14:25:43 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:25:43 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:25:43 --> Utf8 Class Initialized
INFO - 2018-08-14 14:25:43 --> URI Class Initialized
INFO - 2018-08-14 14:25:43 --> Router Class Initialized
INFO - 2018-08-14 14:25:43 --> Output Class Initialized
INFO - 2018-08-14 14:25:43 --> Security Class Initialized
DEBUG - 2018-08-14 14:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:25:43 --> Input Class Initialized
INFO - 2018-08-14 14:25:43 --> Language Class Initialized
INFO - 2018-08-14 14:25:43 --> Language Class Initialized
INFO - 2018-08-14 14:25:43 --> Config Class Initialized
INFO - 2018-08-14 14:25:43 --> Loader Class Initialized
INFO - 2018-08-14 14:25:43 --> Helper loaded: url_helper
INFO - 2018-08-14 14:25:43 --> Helper loaded: file_helper
INFO - 2018-08-14 14:25:43 --> Helper loaded: form_helper
INFO - 2018-08-14 14:25:43 --> Helper loaded: my_helper
INFO - 2018-08-14 14:25:43 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:25:43 --> Controller Class Initialized
DEBUG - 2018-08-14 14:25:43 --> File loaded: D:\laragon\www\nilai\application\modules/cetak_raport/views/cetak_prestasi.php
INFO - 2018-08-14 14:25:43 --> Final output sent to browser
DEBUG - 2018-08-14 14:25:43 --> Total execution time: 0.6579
INFO - 2018-08-14 14:25:48 --> Config Class Initialized
INFO - 2018-08-14 14:25:48 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:25:48 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:25:48 --> Utf8 Class Initialized
INFO - 2018-08-14 14:25:48 --> URI Class Initialized
INFO - 2018-08-14 14:25:48 --> Router Class Initialized
INFO - 2018-08-14 14:25:48 --> Output Class Initialized
INFO - 2018-08-14 14:25:48 --> Security Class Initialized
DEBUG - 2018-08-14 14:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:25:48 --> Input Class Initialized
INFO - 2018-08-14 14:25:48 --> Language Class Initialized
INFO - 2018-08-14 14:25:48 --> Language Class Initialized
INFO - 2018-08-14 14:25:48 --> Config Class Initialized
INFO - 2018-08-14 14:25:48 --> Loader Class Initialized
INFO - 2018-08-14 14:25:48 --> Helper loaded: url_helper
INFO - 2018-08-14 14:25:48 --> Helper loaded: file_helper
INFO - 2018-08-14 14:25:48 --> Helper loaded: form_helper
INFO - 2018-08-14 14:25:48 --> Helper loaded: my_helper
INFO - 2018-08-14 14:25:48 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:25:49 --> Controller Class Initialized
DEBUG - 2018-08-14 14:25:49 --> File loaded: D:\laragon\www\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2018-08-14 14:25:49 --> Final output sent to browser
DEBUG - 2018-08-14 14:25:49 --> Total execution time: 0.7587
INFO - 2018-08-14 14:28:03 --> Config Class Initialized
INFO - 2018-08-14 14:28:03 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:28:03 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:28:03 --> Utf8 Class Initialized
INFO - 2018-08-14 14:28:03 --> URI Class Initialized
INFO - 2018-08-14 14:28:03 --> Router Class Initialized
INFO - 2018-08-14 14:28:03 --> Output Class Initialized
INFO - 2018-08-14 14:28:03 --> Security Class Initialized
DEBUG - 2018-08-14 14:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:28:03 --> Input Class Initialized
INFO - 2018-08-14 14:28:03 --> Language Class Initialized
INFO - 2018-08-14 14:28:03 --> Language Class Initialized
INFO - 2018-08-14 14:28:03 --> Config Class Initialized
INFO - 2018-08-14 14:28:03 --> Loader Class Initialized
INFO - 2018-08-14 14:28:03 --> Helper loaded: url_helper
INFO - 2018-08-14 14:28:03 --> Helper loaded: file_helper
INFO - 2018-08-14 14:28:03 --> Helper loaded: form_helper
INFO - 2018-08-14 14:28:03 --> Helper loaded: my_helper
INFO - 2018-08-14 14:28:03 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:28:03 --> Controller Class Initialized
DEBUG - 2018-08-14 14:28:03 --> File loaded: D:\laragon\www\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2018-08-14 14:28:03 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:28:03 --> Final output sent to browser
DEBUG - 2018-08-14 14:28:03 --> Total execution time: 0.5772
INFO - 2018-08-14 14:28:04 --> Config Class Initialized
INFO - 2018-08-14 14:28:04 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:28:04 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:28:04 --> Utf8 Class Initialized
INFO - 2018-08-14 14:28:05 --> URI Class Initialized
INFO - 2018-08-14 14:28:05 --> Router Class Initialized
INFO - 2018-08-14 14:28:05 --> Output Class Initialized
INFO - 2018-08-14 14:28:05 --> Security Class Initialized
DEBUG - 2018-08-14 14:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:28:05 --> Input Class Initialized
INFO - 2018-08-14 14:28:05 --> Language Class Initialized
INFO - 2018-08-14 14:28:05 --> Language Class Initialized
INFO - 2018-08-14 14:28:05 --> Config Class Initialized
INFO - 2018-08-14 14:28:05 --> Loader Class Initialized
INFO - 2018-08-14 14:28:05 --> Helper loaded: url_helper
INFO - 2018-08-14 14:28:05 --> Helper loaded: file_helper
INFO - 2018-08-14 14:28:05 --> Helper loaded: form_helper
INFO - 2018-08-14 14:28:05 --> Helper loaded: my_helper
INFO - 2018-08-14 14:28:05 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:28:05 --> Controller Class Initialized
DEBUG - 2018-08-14 14:28:05 --> File loaded: D:\laragon\www\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2018-08-14 14:28:05 --> Final output sent to browser
DEBUG - 2018-08-14 14:28:05 --> Total execution time: 0.5551
INFO - 2018-08-14 14:28:09 --> Config Class Initialized
INFO - 2018-08-14 14:28:09 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:28:09 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:28:09 --> Utf8 Class Initialized
INFO - 2018-08-14 14:28:09 --> URI Class Initialized
INFO - 2018-08-14 14:28:09 --> Router Class Initialized
INFO - 2018-08-14 14:28:09 --> Output Class Initialized
INFO - 2018-08-14 14:28:09 --> Security Class Initialized
DEBUG - 2018-08-14 14:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:28:09 --> Input Class Initialized
INFO - 2018-08-14 14:28:09 --> Language Class Initialized
INFO - 2018-08-14 14:28:09 --> Language Class Initialized
INFO - 2018-08-14 14:28:09 --> Config Class Initialized
INFO - 2018-08-14 14:28:09 --> Loader Class Initialized
INFO - 2018-08-14 14:28:09 --> Helper loaded: url_helper
INFO - 2018-08-14 14:28:09 --> Helper loaded: file_helper
INFO - 2018-08-14 14:28:09 --> Helper loaded: form_helper
INFO - 2018-08-14 14:28:09 --> Helper loaded: my_helper
INFO - 2018-08-14 14:28:10 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:28:10 --> Controller Class Initialized
DEBUG - 2018-08-14 14:28:10 --> File loaded: D:\laragon\www\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2018-08-14 14:28:10 --> Final output sent to browser
DEBUG - 2018-08-14 14:28:10 --> Total execution time: 0.7136
INFO - 2018-08-14 14:28:32 --> Config Class Initialized
INFO - 2018-08-14 14:28:33 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:28:33 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:28:33 --> Utf8 Class Initialized
INFO - 2018-08-14 14:28:33 --> URI Class Initialized
INFO - 2018-08-14 14:28:33 --> Router Class Initialized
INFO - 2018-08-14 14:28:33 --> Output Class Initialized
INFO - 2018-08-14 14:28:33 --> Security Class Initialized
DEBUG - 2018-08-14 14:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:28:33 --> Input Class Initialized
INFO - 2018-08-14 14:28:33 --> Language Class Initialized
INFO - 2018-08-14 14:28:33 --> Language Class Initialized
INFO - 2018-08-14 14:28:33 --> Config Class Initialized
INFO - 2018-08-14 14:28:33 --> Loader Class Initialized
INFO - 2018-08-14 14:28:33 --> Helper loaded: url_helper
INFO - 2018-08-14 14:28:33 --> Helper loaded: file_helper
INFO - 2018-08-14 14:28:33 --> Helper loaded: form_helper
INFO - 2018-08-14 14:28:33 --> Helper loaded: my_helper
INFO - 2018-08-14 14:28:33 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:28:33 --> Controller Class Initialized
DEBUG - 2018-08-14 14:28:33 --> File loaded: D:\laragon\www\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2018-08-14 14:28:33 --> Final output sent to browser
DEBUG - 2018-08-14 14:28:33 --> Total execution time: 0.9215
INFO - 2018-08-14 14:28:47 --> Config Class Initialized
INFO - 2018-08-14 14:28:47 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:28:47 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:28:47 --> Utf8 Class Initialized
INFO - 2018-08-14 14:28:47 --> URI Class Initialized
INFO - 2018-08-14 14:28:47 --> Router Class Initialized
INFO - 2018-08-14 14:28:47 --> Output Class Initialized
INFO - 2018-08-14 14:28:47 --> Security Class Initialized
DEBUG - 2018-08-14 14:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:28:47 --> Input Class Initialized
INFO - 2018-08-14 14:28:47 --> Language Class Initialized
INFO - 2018-08-14 14:28:47 --> Language Class Initialized
INFO - 2018-08-14 14:28:47 --> Config Class Initialized
INFO - 2018-08-14 14:28:47 --> Loader Class Initialized
INFO - 2018-08-14 14:28:47 --> Helper loaded: url_helper
INFO - 2018-08-14 14:28:47 --> Helper loaded: file_helper
INFO - 2018-08-14 14:28:47 --> Helper loaded: form_helper
INFO - 2018-08-14 14:28:47 --> Helper loaded: my_helper
INFO - 2018-08-14 14:28:47 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:28:47 --> Controller Class Initialized
DEBUG - 2018-08-14 14:28:48 --> File loaded: D:\laragon\www\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2018-08-14 14:28:48 --> Final output sent to browser
DEBUG - 2018-08-14 14:28:48 --> Total execution time: 0.7749
INFO - 2018-08-14 14:28:51 --> Config Class Initialized
INFO - 2018-08-14 14:28:51 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:28:51 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:28:51 --> Utf8 Class Initialized
INFO - 2018-08-14 14:28:51 --> URI Class Initialized
INFO - 2018-08-14 14:28:51 --> Router Class Initialized
INFO - 2018-08-14 14:28:51 --> Output Class Initialized
INFO - 2018-08-14 14:28:51 --> Security Class Initialized
DEBUG - 2018-08-14 14:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:28:51 --> Input Class Initialized
INFO - 2018-08-14 14:28:51 --> Language Class Initialized
INFO - 2018-08-14 14:28:51 --> Language Class Initialized
INFO - 2018-08-14 14:28:51 --> Config Class Initialized
INFO - 2018-08-14 14:28:51 --> Loader Class Initialized
INFO - 2018-08-14 14:28:51 --> Helper loaded: url_helper
INFO - 2018-08-14 14:28:51 --> Helper loaded: file_helper
INFO - 2018-08-14 14:28:51 --> Helper loaded: form_helper
INFO - 2018-08-14 14:28:51 --> Helper loaded: my_helper
INFO - 2018-08-14 14:28:51 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:28:51 --> Controller Class Initialized
DEBUG - 2018-08-14 14:28:51 --> File loaded: D:\laragon\www\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2018-08-14 14:28:52 --> Final output sent to browser
DEBUG - 2018-08-14 14:28:52 --> Total execution time: 0.5440
INFO - 2018-08-14 14:29:56 --> Config Class Initialized
INFO - 2018-08-14 14:29:56 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:29:56 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:29:56 --> Utf8 Class Initialized
INFO - 2018-08-14 14:29:56 --> URI Class Initialized
INFO - 2018-08-14 14:29:56 --> Router Class Initialized
INFO - 2018-08-14 14:29:56 --> Output Class Initialized
INFO - 2018-08-14 14:29:56 --> Security Class Initialized
DEBUG - 2018-08-14 14:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:29:56 --> Input Class Initialized
INFO - 2018-08-14 14:29:56 --> Language Class Initialized
INFO - 2018-08-14 14:29:56 --> Language Class Initialized
INFO - 2018-08-14 14:29:56 --> Config Class Initialized
INFO - 2018-08-14 14:29:57 --> Loader Class Initialized
INFO - 2018-08-14 14:29:57 --> Helper loaded: url_helper
INFO - 2018-08-14 14:29:57 --> Helper loaded: file_helper
INFO - 2018-08-14 14:29:57 --> Helper loaded: form_helper
INFO - 2018-08-14 14:29:57 --> Helper loaded: my_helper
INFO - 2018-08-14 14:29:57 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:29:57 --> Controller Class Initialized
DEBUG - 2018-08-14 14:29:57 --> File loaded: D:\laragon\www\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2018-08-14 14:29:57 --> Final output sent to browser
DEBUG - 2018-08-14 14:29:57 --> Total execution time: 0.6453
INFO - 2018-08-14 14:30:01 --> Config Class Initialized
INFO - 2018-08-14 14:30:01 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:30:01 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:30:01 --> Utf8 Class Initialized
INFO - 2018-08-14 14:30:01 --> URI Class Initialized
INFO - 2018-08-14 14:30:01 --> Router Class Initialized
INFO - 2018-08-14 14:30:01 --> Output Class Initialized
INFO - 2018-08-14 14:30:01 --> Security Class Initialized
DEBUG - 2018-08-14 14:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:30:01 --> Input Class Initialized
INFO - 2018-08-14 14:30:01 --> Language Class Initialized
INFO - 2018-08-14 14:30:01 --> Language Class Initialized
INFO - 2018-08-14 14:30:01 --> Config Class Initialized
INFO - 2018-08-14 14:30:01 --> Loader Class Initialized
INFO - 2018-08-14 14:30:01 --> Helper loaded: url_helper
INFO - 2018-08-14 14:30:01 --> Helper loaded: file_helper
INFO - 2018-08-14 14:30:01 --> Helper loaded: form_helper
INFO - 2018-08-14 14:30:01 --> Helper loaded: my_helper
INFO - 2018-08-14 14:30:01 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:30:01 --> Controller Class Initialized
ERROR - 2018-08-14 14:30:01 --> Severity: Notice --> Undefined offset: -1 D:\laragon\www\nilai\application\helpers\my_helper.php 144
DEBUG - 2018-08-14 14:30:02 --> File loaded: D:\laragon\www\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2018-08-14 14:30:02 --> Final output sent to browser
DEBUG - 2018-08-14 14:30:02 --> Total execution time: 0.6684
INFO - 2018-08-14 14:30:54 --> Config Class Initialized
INFO - 2018-08-14 14:30:54 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:30:54 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:30:54 --> Utf8 Class Initialized
INFO - 2018-08-14 14:30:54 --> URI Class Initialized
INFO - 2018-08-14 14:30:54 --> Router Class Initialized
INFO - 2018-08-14 14:30:55 --> Output Class Initialized
INFO - 2018-08-14 14:30:55 --> Security Class Initialized
DEBUG - 2018-08-14 14:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:30:55 --> Input Class Initialized
INFO - 2018-08-14 14:30:55 --> Language Class Initialized
INFO - 2018-08-14 14:30:55 --> Language Class Initialized
INFO - 2018-08-14 14:30:55 --> Config Class Initialized
INFO - 2018-08-14 14:30:55 --> Loader Class Initialized
INFO - 2018-08-14 14:30:55 --> Helper loaded: url_helper
INFO - 2018-08-14 14:30:55 --> Helper loaded: file_helper
INFO - 2018-08-14 14:30:55 --> Helper loaded: form_helper
INFO - 2018-08-14 14:30:55 --> Helper loaded: my_helper
INFO - 2018-08-14 14:30:55 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:30:55 --> Controller Class Initialized
DEBUG - 2018-08-14 14:30:55 --> File loaded: D:\laragon\www\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2018-08-14 14:30:55 --> Final output sent to browser
DEBUG - 2018-08-14 14:30:55 --> Total execution time: 1.2647
INFO - 2018-08-14 14:31:02 --> Config Class Initialized
INFO - 2018-08-14 14:31:02 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:31:02 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:31:02 --> Utf8 Class Initialized
INFO - 2018-08-14 14:31:02 --> URI Class Initialized
INFO - 2018-08-14 14:31:02 --> Router Class Initialized
INFO - 2018-08-14 14:31:02 --> Output Class Initialized
INFO - 2018-08-14 14:31:02 --> Security Class Initialized
DEBUG - 2018-08-14 14:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:31:02 --> Input Class Initialized
INFO - 2018-08-14 14:31:02 --> Language Class Initialized
INFO - 2018-08-14 14:31:02 --> Language Class Initialized
INFO - 2018-08-14 14:31:02 --> Config Class Initialized
INFO - 2018-08-14 14:31:02 --> Loader Class Initialized
INFO - 2018-08-14 14:31:02 --> Helper loaded: url_helper
INFO - 2018-08-14 14:31:02 --> Helper loaded: file_helper
INFO - 2018-08-14 14:31:02 --> Helper loaded: form_helper
INFO - 2018-08-14 14:31:02 --> Helper loaded: my_helper
INFO - 2018-08-14 14:31:02 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:31:02 --> Controller Class Initialized
DEBUG - 2018-08-14 14:31:02 --> File loaded: D:\laragon\www\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2018-08-14 14:31:02 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:31:02 --> Final output sent to browser
DEBUG - 2018-08-14 14:31:03 --> Total execution time: 0.6164
INFO - 2018-08-14 14:31:04 --> Config Class Initialized
INFO - 2018-08-14 14:31:04 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:31:04 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:31:04 --> Utf8 Class Initialized
INFO - 2018-08-14 14:31:04 --> URI Class Initialized
INFO - 2018-08-14 14:31:04 --> Router Class Initialized
INFO - 2018-08-14 14:31:04 --> Output Class Initialized
INFO - 2018-08-14 14:31:04 --> Security Class Initialized
DEBUG - 2018-08-14 14:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:31:04 --> Input Class Initialized
INFO - 2018-08-14 14:31:04 --> Language Class Initialized
INFO - 2018-08-14 14:31:04 --> Language Class Initialized
INFO - 2018-08-14 14:31:04 --> Config Class Initialized
INFO - 2018-08-14 14:31:04 --> Loader Class Initialized
INFO - 2018-08-14 14:31:04 --> Helper loaded: url_helper
INFO - 2018-08-14 14:31:04 --> Helper loaded: file_helper
INFO - 2018-08-14 14:31:04 --> Helper loaded: form_helper
INFO - 2018-08-14 14:31:04 --> Helper loaded: my_helper
INFO - 2018-08-14 14:31:05 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:31:05 --> Controller Class Initialized
DEBUG - 2018-08-14 14:31:05 --> File loaded: D:\laragon\www\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2018-08-14 14:31:05 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:31:05 --> Final output sent to browser
DEBUG - 2018-08-14 14:31:05 --> Total execution time: 0.7321
INFO - 2018-08-14 14:31:07 --> Config Class Initialized
INFO - 2018-08-14 14:31:07 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:31:07 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:31:07 --> Utf8 Class Initialized
INFO - 2018-08-14 14:31:07 --> URI Class Initialized
INFO - 2018-08-14 14:31:07 --> Router Class Initialized
INFO - 2018-08-14 14:31:07 --> Output Class Initialized
INFO - 2018-08-14 14:31:07 --> Security Class Initialized
DEBUG - 2018-08-14 14:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:31:07 --> Input Class Initialized
INFO - 2018-08-14 14:31:07 --> Language Class Initialized
INFO - 2018-08-14 14:31:07 --> Language Class Initialized
INFO - 2018-08-14 14:31:07 --> Config Class Initialized
INFO - 2018-08-14 14:31:07 --> Loader Class Initialized
INFO - 2018-08-14 14:31:07 --> Helper loaded: url_helper
INFO - 2018-08-14 14:31:07 --> Helper loaded: file_helper
INFO - 2018-08-14 14:31:07 --> Helper loaded: form_helper
INFO - 2018-08-14 14:31:07 --> Helper loaded: my_helper
INFO - 2018-08-14 14:31:07 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:31:08 --> Controller Class Initialized
DEBUG - 2018-08-14 14:31:08 --> File loaded: D:\laragon\www\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2018-08-14 14:31:08 --> Final output sent to browser
DEBUG - 2018-08-14 14:31:08 --> Total execution time: 0.6650
INFO - 2018-08-14 14:31:37 --> Config Class Initialized
INFO - 2018-08-14 14:31:37 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:31:37 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:31:37 --> Utf8 Class Initialized
INFO - 2018-08-14 14:31:37 --> URI Class Initialized
INFO - 2018-08-14 14:31:37 --> Router Class Initialized
INFO - 2018-08-14 14:31:37 --> Output Class Initialized
INFO - 2018-08-14 14:31:37 --> Security Class Initialized
DEBUG - 2018-08-14 14:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:31:37 --> Input Class Initialized
INFO - 2018-08-14 14:31:37 --> Language Class Initialized
INFO - 2018-08-14 14:31:37 --> Language Class Initialized
INFO - 2018-08-14 14:31:37 --> Config Class Initialized
INFO - 2018-08-14 14:31:37 --> Loader Class Initialized
INFO - 2018-08-14 14:31:37 --> Helper loaded: url_helper
INFO - 2018-08-14 14:31:37 --> Helper loaded: file_helper
INFO - 2018-08-14 14:31:37 --> Helper loaded: form_helper
INFO - 2018-08-14 14:31:38 --> Helper loaded: my_helper
INFO - 2018-08-14 14:31:38 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:31:38 --> Controller Class Initialized
DEBUG - 2018-08-14 14:31:38 --> File loaded: D:\laragon\www\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2018-08-14 14:31:38 --> Final output sent to browser
DEBUG - 2018-08-14 14:31:38 --> Total execution time: 0.7813
INFO - 2018-08-14 14:31:42 --> Config Class Initialized
INFO - 2018-08-14 14:31:42 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:31:42 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:31:42 --> Utf8 Class Initialized
INFO - 2018-08-14 14:31:42 --> URI Class Initialized
INFO - 2018-08-14 14:31:42 --> Router Class Initialized
INFO - 2018-08-14 14:31:42 --> Output Class Initialized
INFO - 2018-08-14 14:31:42 --> Security Class Initialized
DEBUG - 2018-08-14 14:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:31:42 --> Input Class Initialized
INFO - 2018-08-14 14:31:43 --> Language Class Initialized
INFO - 2018-08-14 14:31:43 --> Language Class Initialized
INFO - 2018-08-14 14:31:43 --> Config Class Initialized
INFO - 2018-08-14 14:31:43 --> Loader Class Initialized
INFO - 2018-08-14 14:31:43 --> Helper loaded: url_helper
INFO - 2018-08-14 14:31:43 --> Helper loaded: file_helper
INFO - 2018-08-14 14:31:43 --> Helper loaded: form_helper
INFO - 2018-08-14 14:31:43 --> Helper loaded: my_helper
INFO - 2018-08-14 14:31:43 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:31:43 --> Controller Class Initialized
DEBUG - 2018-08-14 14:31:43 --> File loaded: D:\laragon\www\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2018-08-14 14:31:43 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:31:43 --> Final output sent to browser
DEBUG - 2018-08-14 14:31:43 --> Total execution time: 0.6474
INFO - 2018-08-14 14:31:47 --> Config Class Initialized
INFO - 2018-08-14 14:31:47 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:31:47 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:31:47 --> Utf8 Class Initialized
INFO - 2018-08-14 14:31:47 --> URI Class Initialized
INFO - 2018-08-14 14:31:47 --> Router Class Initialized
INFO - 2018-08-14 14:31:47 --> Output Class Initialized
INFO - 2018-08-14 14:31:47 --> Security Class Initialized
DEBUG - 2018-08-14 14:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:31:47 --> Input Class Initialized
INFO - 2018-08-14 14:31:47 --> Language Class Initialized
INFO - 2018-08-14 14:31:47 --> Language Class Initialized
INFO - 2018-08-14 14:31:47 --> Config Class Initialized
INFO - 2018-08-14 14:31:47 --> Loader Class Initialized
INFO - 2018-08-14 14:31:47 --> Helper loaded: url_helper
INFO - 2018-08-14 14:31:47 --> Helper loaded: file_helper
INFO - 2018-08-14 14:31:47 --> Helper loaded: form_helper
INFO - 2018-08-14 14:31:48 --> Helper loaded: my_helper
INFO - 2018-08-14 14:31:48 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:31:48 --> Controller Class Initialized
DEBUG - 2018-08-14 14:31:48 --> File loaded: D:\laragon\www\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2018-08-14 14:31:48 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:31:48 --> Final output sent to browser
DEBUG - 2018-08-14 14:31:48 --> Total execution time: 0.6748
INFO - 2018-08-14 14:31:49 --> Config Class Initialized
INFO - 2018-08-14 14:31:49 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:31:49 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:31:49 --> Utf8 Class Initialized
INFO - 2018-08-14 14:31:49 --> URI Class Initialized
INFO - 2018-08-14 14:31:49 --> Router Class Initialized
INFO - 2018-08-14 14:31:49 --> Output Class Initialized
INFO - 2018-08-14 14:31:49 --> Security Class Initialized
DEBUG - 2018-08-14 14:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:31:49 --> Input Class Initialized
INFO - 2018-08-14 14:31:49 --> Language Class Initialized
INFO - 2018-08-14 14:31:49 --> Language Class Initialized
INFO - 2018-08-14 14:31:49 --> Config Class Initialized
INFO - 2018-08-14 14:31:49 --> Loader Class Initialized
INFO - 2018-08-14 14:31:49 --> Helper loaded: url_helper
INFO - 2018-08-14 14:31:49 --> Helper loaded: file_helper
INFO - 2018-08-14 14:31:49 --> Helper loaded: form_helper
INFO - 2018-08-14 14:31:50 --> Helper loaded: my_helper
INFO - 2018-08-14 14:31:50 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:31:50 --> Controller Class Initialized
DEBUG - 2018-08-14 14:31:50 --> File loaded: D:\laragon\www\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2018-08-14 14:31:50 --> Final output sent to browser
DEBUG - 2018-08-14 14:31:50 --> Total execution time: 0.5687
INFO - 2018-08-14 14:32:02 --> Config Class Initialized
INFO - 2018-08-14 14:32:02 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:32:02 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:32:02 --> Utf8 Class Initialized
INFO - 2018-08-14 14:32:02 --> URI Class Initialized
INFO - 2018-08-14 14:32:02 --> Router Class Initialized
INFO - 2018-08-14 14:32:02 --> Output Class Initialized
INFO - 2018-08-14 14:32:02 --> Security Class Initialized
DEBUG - 2018-08-14 14:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:32:02 --> Input Class Initialized
INFO - 2018-08-14 14:32:03 --> Language Class Initialized
INFO - 2018-08-14 14:32:03 --> Language Class Initialized
INFO - 2018-08-14 14:32:03 --> Config Class Initialized
INFO - 2018-08-14 14:32:03 --> Loader Class Initialized
INFO - 2018-08-14 14:32:03 --> Helper loaded: url_helper
INFO - 2018-08-14 14:32:03 --> Helper loaded: file_helper
INFO - 2018-08-14 14:32:03 --> Helper loaded: form_helper
INFO - 2018-08-14 14:32:03 --> Helper loaded: my_helper
INFO - 2018-08-14 14:32:03 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:32:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:32:03 --> Controller Class Initialized
DEBUG - 2018-08-14 14:32:03 --> File loaded: D:\laragon\www\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2018-08-14 14:32:03 --> Final output sent to browser
DEBUG - 2018-08-14 14:32:03 --> Total execution time: 0.5677
INFO - 2018-08-14 14:32:05 --> Config Class Initialized
INFO - 2018-08-14 14:32:05 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:32:05 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:32:05 --> Utf8 Class Initialized
INFO - 2018-08-14 14:32:05 --> URI Class Initialized
INFO - 2018-08-14 14:32:05 --> Router Class Initialized
INFO - 2018-08-14 14:32:05 --> Output Class Initialized
INFO - 2018-08-14 14:32:05 --> Security Class Initialized
DEBUG - 2018-08-14 14:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:32:05 --> Input Class Initialized
INFO - 2018-08-14 14:32:05 --> Language Class Initialized
INFO - 2018-08-14 14:32:05 --> Language Class Initialized
INFO - 2018-08-14 14:32:06 --> Config Class Initialized
INFO - 2018-08-14 14:32:06 --> Loader Class Initialized
INFO - 2018-08-14 14:32:06 --> Helper loaded: url_helper
INFO - 2018-08-14 14:32:06 --> Helper loaded: file_helper
INFO - 2018-08-14 14:32:06 --> Helper loaded: form_helper
INFO - 2018-08-14 14:32:06 --> Helper loaded: my_helper
INFO - 2018-08-14 14:32:06 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:32:06 --> Controller Class Initialized
DEBUG - 2018-08-14 14:32:06 --> File loaded: D:\laragon\www\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2018-08-14 14:32:06 --> Final output sent to browser
DEBUG - 2018-08-14 14:32:06 --> Total execution time: 0.7147
INFO - 2018-08-14 14:32:29 --> Config Class Initialized
INFO - 2018-08-14 14:32:29 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:32:29 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:32:29 --> Utf8 Class Initialized
INFO - 2018-08-14 14:32:29 --> URI Class Initialized
INFO - 2018-08-14 14:32:29 --> Router Class Initialized
INFO - 2018-08-14 14:32:29 --> Output Class Initialized
INFO - 2018-08-14 14:32:29 --> Security Class Initialized
DEBUG - 2018-08-14 14:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:32:30 --> Input Class Initialized
INFO - 2018-08-14 14:32:30 --> Language Class Initialized
INFO - 2018-08-14 14:32:30 --> Language Class Initialized
INFO - 2018-08-14 14:32:30 --> Config Class Initialized
INFO - 2018-08-14 14:32:30 --> Loader Class Initialized
INFO - 2018-08-14 14:32:30 --> Helper loaded: url_helper
INFO - 2018-08-14 14:32:30 --> Helper loaded: file_helper
INFO - 2018-08-14 14:32:30 --> Helper loaded: form_helper
INFO - 2018-08-14 14:32:30 --> Helper loaded: my_helper
INFO - 2018-08-14 14:32:30 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:32:30 --> Controller Class Initialized
DEBUG - 2018-08-14 14:32:30 --> File loaded: D:\laragon\www\nilai\application\modules/home/views/v_ubah_password.php
DEBUG - 2018-08-14 14:32:30 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:32:30 --> Final output sent to browser
DEBUG - 2018-08-14 14:32:30 --> Total execution time: 0.5467
INFO - 2018-08-14 14:32:30 --> Config Class Initialized
INFO - 2018-08-14 14:32:30 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:32:30 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:32:30 --> Utf8 Class Initialized
INFO - 2018-08-14 14:32:30 --> URI Class Initialized
INFO - 2018-08-14 14:32:30 --> Router Class Initialized
INFO - 2018-08-14 14:32:30 --> Output Class Initialized
INFO - 2018-08-14 14:32:30 --> Security Class Initialized
DEBUG - 2018-08-14 14:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:32:30 --> Input Class Initialized
INFO - 2018-08-14 14:32:30 --> Language Class Initialized
ERROR - 2018-08-14 14:32:30 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:32:32 --> Config Class Initialized
INFO - 2018-08-14 14:32:32 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:32:32 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:32:32 --> Utf8 Class Initialized
INFO - 2018-08-14 14:32:32 --> URI Class Initialized
INFO - 2018-08-14 14:32:32 --> Router Class Initialized
INFO - 2018-08-14 14:32:32 --> Output Class Initialized
INFO - 2018-08-14 14:32:32 --> Security Class Initialized
DEBUG - 2018-08-14 14:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:32:32 --> Input Class Initialized
INFO - 2018-08-14 14:32:32 --> Language Class Initialized
INFO - 2018-08-14 14:32:32 --> Language Class Initialized
INFO - 2018-08-14 14:32:32 --> Config Class Initialized
INFO - 2018-08-14 14:32:32 --> Loader Class Initialized
INFO - 2018-08-14 14:32:32 --> Helper loaded: url_helper
INFO - 2018-08-14 14:32:32 --> Helper loaded: file_helper
INFO - 2018-08-14 14:32:32 --> Helper loaded: form_helper
INFO - 2018-08-14 14:32:32 --> Helper loaded: my_helper
INFO - 2018-08-14 14:32:32 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:32:32 --> Controller Class Initialized
DEBUG - 2018-08-14 14:32:32 --> File loaded: D:\laragon\www\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2018-08-14 14:32:32 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:32:32 --> Final output sent to browser
DEBUG - 2018-08-14 14:32:32 --> Total execution time: 0.5761
INFO - 2018-08-14 14:32:33 --> Config Class Initialized
INFO - 2018-08-14 14:32:33 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:32:33 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:32:33 --> Utf8 Class Initialized
INFO - 2018-08-14 14:32:33 --> URI Class Initialized
INFO - 2018-08-14 14:32:33 --> Router Class Initialized
INFO - 2018-08-14 14:32:33 --> Output Class Initialized
INFO - 2018-08-14 14:32:33 --> Security Class Initialized
DEBUG - 2018-08-14 14:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:32:33 --> Input Class Initialized
INFO - 2018-08-14 14:32:33 --> Language Class Initialized
ERROR - 2018-08-14 14:32:33 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:32:35 --> Config Class Initialized
INFO - 2018-08-14 14:32:35 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:32:35 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:32:35 --> Utf8 Class Initialized
INFO - 2018-08-14 14:32:35 --> URI Class Initialized
INFO - 2018-08-14 14:32:35 --> Router Class Initialized
INFO - 2018-08-14 14:32:35 --> Output Class Initialized
INFO - 2018-08-14 14:32:35 --> Security Class Initialized
DEBUG - 2018-08-14 14:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:32:35 --> Input Class Initialized
INFO - 2018-08-14 14:32:35 --> Language Class Initialized
INFO - 2018-08-14 14:32:35 --> Language Class Initialized
INFO - 2018-08-14 14:32:35 --> Config Class Initialized
INFO - 2018-08-14 14:32:35 --> Loader Class Initialized
INFO - 2018-08-14 14:32:35 --> Helper loaded: url_helper
INFO - 2018-08-14 14:32:35 --> Helper loaded: file_helper
INFO - 2018-08-14 14:32:35 --> Helper loaded: form_helper
INFO - 2018-08-14 14:32:35 --> Helper loaded: my_helper
INFO - 2018-08-14 14:32:35 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:32:35 --> Controller Class Initialized
DEBUG - 2018-08-14 14:32:35 --> File loaded: D:\laragon\www\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2018-08-14 14:32:35 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:32:35 --> Final output sent to browser
DEBUG - 2018-08-14 14:32:35 --> Total execution time: 0.6960
INFO - 2018-08-14 14:32:35 --> Config Class Initialized
INFO - 2018-08-14 14:32:35 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:32:35 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:32:35 --> Utf8 Class Initialized
INFO - 2018-08-14 14:32:35 --> URI Class Initialized
INFO - 2018-08-14 14:32:36 --> Router Class Initialized
INFO - 2018-08-14 14:32:36 --> Output Class Initialized
INFO - 2018-08-14 14:32:36 --> Security Class Initialized
DEBUG - 2018-08-14 14:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:32:36 --> Input Class Initialized
INFO - 2018-08-14 14:32:36 --> Language Class Initialized
ERROR - 2018-08-14 14:32:36 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:32:55 --> Config Class Initialized
INFO - 2018-08-14 14:32:55 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:32:55 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:32:55 --> Utf8 Class Initialized
INFO - 2018-08-14 14:32:55 --> URI Class Initialized
INFO - 2018-08-14 14:32:55 --> Router Class Initialized
INFO - 2018-08-14 14:32:55 --> Output Class Initialized
INFO - 2018-08-14 14:32:55 --> Security Class Initialized
DEBUG - 2018-08-14 14:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:32:55 --> Input Class Initialized
INFO - 2018-08-14 14:32:55 --> Language Class Initialized
INFO - 2018-08-14 14:32:55 --> Language Class Initialized
INFO - 2018-08-14 14:32:55 --> Config Class Initialized
INFO - 2018-08-14 14:32:55 --> Loader Class Initialized
INFO - 2018-08-14 14:32:55 --> Helper loaded: url_helper
INFO - 2018-08-14 14:32:56 --> Helper loaded: file_helper
INFO - 2018-08-14 14:32:56 --> Helper loaded: form_helper
INFO - 2018-08-14 14:32:56 --> Helper loaded: my_helper
INFO - 2018-08-14 14:32:56 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:32:56 --> Controller Class Initialized
DEBUG - 2018-08-14 14:32:56 --> File loaded: D:\laragon\www\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2018-08-14 14:32:56 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:32:56 --> Final output sent to browser
DEBUG - 2018-08-14 14:32:56 --> Total execution time: 0.8194
INFO - 2018-08-14 14:32:56 --> Config Class Initialized
INFO - 2018-08-14 14:32:56 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:32:56 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:32:56 --> Utf8 Class Initialized
INFO - 2018-08-14 14:32:56 --> URI Class Initialized
INFO - 2018-08-14 14:32:56 --> Router Class Initialized
INFO - 2018-08-14 14:32:56 --> Output Class Initialized
INFO - 2018-08-14 14:32:56 --> Security Class Initialized
DEBUG - 2018-08-14 14:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:32:56 --> Input Class Initialized
INFO - 2018-08-14 14:32:56 --> Language Class Initialized
ERROR - 2018-08-14 14:32:56 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:33:02 --> Config Class Initialized
INFO - 2018-08-14 14:33:02 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:33:02 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:33:02 --> Utf8 Class Initialized
INFO - 2018-08-14 14:33:02 --> URI Class Initialized
INFO - 2018-08-14 14:33:02 --> Router Class Initialized
INFO - 2018-08-14 14:33:02 --> Output Class Initialized
INFO - 2018-08-14 14:33:02 --> Security Class Initialized
DEBUG - 2018-08-14 14:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:33:02 --> Input Class Initialized
INFO - 2018-08-14 14:33:02 --> Language Class Initialized
INFO - 2018-08-14 14:33:02 --> Language Class Initialized
INFO - 2018-08-14 14:33:02 --> Config Class Initialized
INFO - 2018-08-14 14:33:02 --> Loader Class Initialized
INFO - 2018-08-14 14:33:02 --> Helper loaded: url_helper
INFO - 2018-08-14 14:33:02 --> Helper loaded: file_helper
INFO - 2018-08-14 14:33:02 --> Helper loaded: form_helper
INFO - 2018-08-14 14:33:02 --> Helper loaded: my_helper
INFO - 2018-08-14 14:33:02 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:33:02 --> Controller Class Initialized
DEBUG - 2018-08-14 14:33:02 --> File loaded: D:\laragon\www\nilai\application\modules/home/views/v_ubah_password.php
DEBUG - 2018-08-14 14:33:02 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:33:02 --> Final output sent to browser
DEBUG - 2018-08-14 14:33:02 --> Total execution time: 0.7936
INFO - 2018-08-14 14:33:03 --> Config Class Initialized
INFO - 2018-08-14 14:33:03 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:33:03 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:33:03 --> Utf8 Class Initialized
INFO - 2018-08-14 14:33:03 --> URI Class Initialized
INFO - 2018-08-14 14:33:03 --> Router Class Initialized
INFO - 2018-08-14 14:33:03 --> Output Class Initialized
INFO - 2018-08-14 14:33:03 --> Security Class Initialized
DEBUG - 2018-08-14 14:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:33:03 --> Input Class Initialized
INFO - 2018-08-14 14:33:03 --> Language Class Initialized
ERROR - 2018-08-14 14:33:03 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:33:04 --> Config Class Initialized
INFO - 2018-08-14 14:33:04 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:33:04 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:33:04 --> Utf8 Class Initialized
INFO - 2018-08-14 14:33:04 --> URI Class Initialized
INFO - 2018-08-14 14:33:04 --> Router Class Initialized
INFO - 2018-08-14 14:33:04 --> Output Class Initialized
INFO - 2018-08-14 14:33:04 --> Security Class Initialized
DEBUG - 2018-08-14 14:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:33:04 --> Input Class Initialized
INFO - 2018-08-14 14:33:04 --> Language Class Initialized
INFO - 2018-08-14 14:33:04 --> Language Class Initialized
INFO - 2018-08-14 14:33:04 --> Config Class Initialized
INFO - 2018-08-14 14:33:04 --> Loader Class Initialized
INFO - 2018-08-14 14:33:04 --> Helper loaded: url_helper
INFO - 2018-08-14 14:33:04 --> Helper loaded: file_helper
INFO - 2018-08-14 14:33:04 --> Helper loaded: form_helper
INFO - 2018-08-14 14:33:04 --> Helper loaded: my_helper
INFO - 2018-08-14 14:33:04 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:33:04 --> Controller Class Initialized
DEBUG - 2018-08-14 14:33:04 --> File loaded: D:\laragon\www\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2018-08-14 14:33:04 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:33:04 --> Final output sent to browser
DEBUG - 2018-08-14 14:33:04 --> Total execution time: 0.5874
INFO - 2018-08-14 14:33:04 --> Config Class Initialized
INFO - 2018-08-14 14:33:04 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:33:04 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:33:04 --> Utf8 Class Initialized
INFO - 2018-08-14 14:33:04 --> URI Class Initialized
INFO - 2018-08-14 14:33:04 --> Router Class Initialized
INFO - 2018-08-14 14:33:04 --> Output Class Initialized
INFO - 2018-08-14 14:33:05 --> Security Class Initialized
DEBUG - 2018-08-14 14:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:33:05 --> Input Class Initialized
INFO - 2018-08-14 14:33:05 --> Language Class Initialized
ERROR - 2018-08-14 14:33:05 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:33:06 --> Config Class Initialized
INFO - 2018-08-14 14:33:06 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:33:06 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:33:06 --> Utf8 Class Initialized
INFO - 2018-08-14 14:33:06 --> URI Class Initialized
INFO - 2018-08-14 14:33:06 --> Router Class Initialized
INFO - 2018-08-14 14:33:06 --> Output Class Initialized
INFO - 2018-08-14 14:33:06 --> Security Class Initialized
DEBUG - 2018-08-14 14:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:33:06 --> Input Class Initialized
INFO - 2018-08-14 14:33:06 --> Language Class Initialized
INFO - 2018-08-14 14:33:06 --> Language Class Initialized
INFO - 2018-08-14 14:33:06 --> Config Class Initialized
INFO - 2018-08-14 14:33:06 --> Loader Class Initialized
INFO - 2018-08-14 14:33:06 --> Helper loaded: url_helper
INFO - 2018-08-14 14:33:06 --> Helper loaded: file_helper
INFO - 2018-08-14 14:33:06 --> Helper loaded: form_helper
INFO - 2018-08-14 14:33:06 --> Helper loaded: my_helper
INFO - 2018-08-14 14:33:06 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:33:06 --> Controller Class Initialized
DEBUG - 2018-08-14 14:33:06 --> File loaded: D:\laragon\www\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2018-08-14 14:33:06 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:33:06 --> Final output sent to browser
DEBUG - 2018-08-14 14:33:06 --> Total execution time: 0.6447
INFO - 2018-08-14 14:33:06 --> Config Class Initialized
INFO - 2018-08-14 14:33:06 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:33:06 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:33:06 --> Utf8 Class Initialized
INFO - 2018-08-14 14:33:07 --> URI Class Initialized
INFO - 2018-08-14 14:33:07 --> Router Class Initialized
INFO - 2018-08-14 14:33:07 --> Output Class Initialized
INFO - 2018-08-14 14:33:07 --> Security Class Initialized
DEBUG - 2018-08-14 14:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:33:07 --> Input Class Initialized
INFO - 2018-08-14 14:33:07 --> Language Class Initialized
ERROR - 2018-08-14 14:33:07 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:33:08 --> Config Class Initialized
INFO - 2018-08-14 14:33:08 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:33:08 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:33:08 --> Utf8 Class Initialized
INFO - 2018-08-14 14:33:08 --> URI Class Initialized
INFO - 2018-08-14 14:33:08 --> Router Class Initialized
INFO - 2018-08-14 14:33:08 --> Output Class Initialized
INFO - 2018-08-14 14:33:08 --> Security Class Initialized
DEBUG - 2018-08-14 14:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:33:08 --> Input Class Initialized
INFO - 2018-08-14 14:33:08 --> Language Class Initialized
INFO - 2018-08-14 14:33:08 --> Language Class Initialized
INFO - 2018-08-14 14:33:09 --> Config Class Initialized
INFO - 2018-08-14 14:33:09 --> Loader Class Initialized
INFO - 2018-08-14 14:33:09 --> Helper loaded: url_helper
INFO - 2018-08-14 14:33:09 --> Helper loaded: file_helper
INFO - 2018-08-14 14:33:09 --> Helper loaded: form_helper
INFO - 2018-08-14 14:33:09 --> Helper loaded: my_helper
INFO - 2018-08-14 14:33:09 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:33:09 --> Controller Class Initialized
DEBUG - 2018-08-14 14:33:09 --> File loaded: D:\laragon\www\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2018-08-14 14:33:09 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:33:09 --> Final output sent to browser
DEBUG - 2018-08-14 14:33:09 --> Total execution time: 0.7100
INFO - 2018-08-14 14:33:09 --> Config Class Initialized
INFO - 2018-08-14 14:33:09 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:33:09 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:33:09 --> Utf8 Class Initialized
INFO - 2018-08-14 14:33:09 --> URI Class Initialized
INFO - 2018-08-14 14:33:09 --> Router Class Initialized
INFO - 2018-08-14 14:33:09 --> Output Class Initialized
INFO - 2018-08-14 14:33:09 --> Security Class Initialized
DEBUG - 2018-08-14 14:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:33:09 --> Input Class Initialized
INFO - 2018-08-14 14:33:09 --> Language Class Initialized
ERROR - 2018-08-14 14:33:09 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:33:11 --> Config Class Initialized
INFO - 2018-08-14 14:33:11 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:33:11 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:33:11 --> Utf8 Class Initialized
INFO - 2018-08-14 14:33:11 --> URI Class Initialized
INFO - 2018-08-14 14:33:11 --> Router Class Initialized
INFO - 2018-08-14 14:33:11 --> Output Class Initialized
INFO - 2018-08-14 14:33:11 --> Security Class Initialized
DEBUG - 2018-08-14 14:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:33:11 --> Input Class Initialized
INFO - 2018-08-14 14:33:11 --> Language Class Initialized
INFO - 2018-08-14 14:33:11 --> Language Class Initialized
INFO - 2018-08-14 14:33:11 --> Config Class Initialized
INFO - 2018-08-14 14:33:11 --> Loader Class Initialized
INFO - 2018-08-14 14:33:11 --> Helper loaded: url_helper
INFO - 2018-08-14 14:33:11 --> Helper loaded: file_helper
INFO - 2018-08-14 14:33:11 --> Helper loaded: form_helper
INFO - 2018-08-14 14:33:11 --> Helper loaded: my_helper
INFO - 2018-08-14 14:33:11 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:33:11 --> Controller Class Initialized
DEBUG - 2018-08-14 14:33:11 --> File loaded: D:\laragon\www\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2018-08-14 14:33:11 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:33:12 --> Final output sent to browser
DEBUG - 2018-08-14 14:33:12 --> Total execution time: 0.6625
INFO - 2018-08-14 14:33:12 --> Config Class Initialized
INFO - 2018-08-14 14:33:12 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:33:12 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:33:12 --> Utf8 Class Initialized
INFO - 2018-08-14 14:33:12 --> URI Class Initialized
INFO - 2018-08-14 14:33:12 --> Router Class Initialized
INFO - 2018-08-14 14:33:12 --> Output Class Initialized
INFO - 2018-08-14 14:33:12 --> Security Class Initialized
DEBUG - 2018-08-14 14:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:33:12 --> Input Class Initialized
INFO - 2018-08-14 14:33:12 --> Language Class Initialized
ERROR - 2018-08-14 14:33:12 --> 404 Page Not Found: /index
INFO - 2018-08-14 14:33:14 --> Config Class Initialized
INFO - 2018-08-14 14:33:14 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:33:14 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:33:14 --> Utf8 Class Initialized
INFO - 2018-08-14 14:33:14 --> URI Class Initialized
INFO - 2018-08-14 14:33:14 --> Router Class Initialized
INFO - 2018-08-14 14:33:14 --> Output Class Initialized
INFO - 2018-08-14 14:33:14 --> Security Class Initialized
DEBUG - 2018-08-14 14:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:33:14 --> Input Class Initialized
INFO - 2018-08-14 14:33:14 --> Language Class Initialized
INFO - 2018-08-14 14:33:14 --> Language Class Initialized
INFO - 2018-08-14 14:33:14 --> Config Class Initialized
INFO - 2018-08-14 14:33:14 --> Loader Class Initialized
INFO - 2018-08-14 14:33:14 --> Helper loaded: url_helper
INFO - 2018-08-14 14:33:14 --> Helper loaded: file_helper
INFO - 2018-08-14 14:33:14 --> Helper loaded: form_helper
INFO - 2018-08-14 14:33:14 --> Helper loaded: my_helper
INFO - 2018-08-14 14:33:14 --> Database Driver Class Initialized
DEBUG - 2018-08-14 14:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:33:14 --> Controller Class Initialized
DEBUG - 2018-08-14 14:33:14 --> File loaded: D:\laragon\www\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2018-08-14 14:33:14 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-14 14:33:14 --> Final output sent to browser
DEBUG - 2018-08-14 14:33:15 --> Total execution time: 0.7750
INFO - 2018-08-14 14:33:15 --> Config Class Initialized
INFO - 2018-08-14 14:33:15 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:33:15 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:33:15 --> Utf8 Class Initialized
INFO - 2018-08-14 14:33:15 --> URI Class Initialized
INFO - 2018-08-14 14:33:15 --> Router Class Initialized
INFO - 2018-08-14 14:33:15 --> Output Class Initialized
INFO - 2018-08-14 14:33:15 --> Security Class Initialized
DEBUG - 2018-08-14 14:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:33:15 --> Input Class Initialized
INFO - 2018-08-14 14:33:15 --> Language Class Initialized
ERROR - 2018-08-14 14:33:15 --> 404 Page Not Found: /index
