<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-04-25 13:08:28 --> Config Class Initialized
INFO - 2023-04-25 13:08:28 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:08:28 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:08:28 --> Utf8 Class Initialized
INFO - 2023-04-25 13:08:28 --> URI Class Initialized
INFO - 2023-04-25 13:08:28 --> Router Class Initialized
INFO - 2023-04-25 13:08:28 --> Output Class Initialized
INFO - 2023-04-25 13:08:28 --> Security Class Initialized
DEBUG - 2023-04-25 13:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:08:28 --> Input Class Initialized
INFO - 2023-04-25 13:08:28 --> Language Class Initialized
INFO - 2023-04-25 13:08:28 --> Language Class Initialized
INFO - 2023-04-25 13:08:28 --> Config Class Initialized
INFO - 2023-04-25 13:08:28 --> Loader Class Initialized
INFO - 2023-04-25 13:08:28 --> Helper loaded: url_helper
INFO - 2023-04-25 13:08:28 --> Helper loaded: file_helper
INFO - 2023-04-25 13:08:28 --> Helper loaded: form_helper
INFO - 2023-04-25 13:08:28 --> Helper loaded: my_helper
INFO - 2023-04-25 13:08:29 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:08:29 --> Controller Class Initialized
ERROR - 2023-04-25 13:08:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 2181
DEBUG - 2023-04-25 13:08:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-04-25 13:08:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-25 13:08:29 --> Final output sent to browser
DEBUG - 2023-04-25 13:08:29 --> Total execution time: 0.9100
INFO - 2023-04-25 13:08:41 --> Config Class Initialized
INFO - 2023-04-25 13:08:41 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:08:41 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:08:41 --> Utf8 Class Initialized
INFO - 2023-04-25 13:08:41 --> URI Class Initialized
DEBUG - 2023-04-25 13:08:41 --> No URI present. Default controller set.
INFO - 2023-04-25 13:08:41 --> Router Class Initialized
INFO - 2023-04-25 13:08:41 --> Output Class Initialized
INFO - 2023-04-25 13:08:41 --> Security Class Initialized
DEBUG - 2023-04-25 13:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:08:41 --> Input Class Initialized
INFO - 2023-04-25 13:08:41 --> Language Class Initialized
INFO - 2023-04-25 13:08:41 --> Language Class Initialized
INFO - 2023-04-25 13:08:41 --> Config Class Initialized
INFO - 2023-04-25 13:08:41 --> Loader Class Initialized
INFO - 2023-04-25 13:08:41 --> Helper loaded: url_helper
INFO - 2023-04-25 13:08:41 --> Helper loaded: file_helper
INFO - 2023-04-25 13:08:41 --> Helper loaded: form_helper
INFO - 2023-04-25 13:08:41 --> Helper loaded: my_helper
INFO - 2023-04-25 13:08:41 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:08:41 --> Controller Class Initialized
INFO - 2023-04-25 13:08:42 --> Config Class Initialized
INFO - 2023-04-25 13:08:42 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:08:42 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:08:42 --> Utf8 Class Initialized
INFO - 2023-04-25 13:08:42 --> URI Class Initialized
INFO - 2023-04-25 13:08:42 --> Router Class Initialized
INFO - 2023-04-25 13:08:42 --> Output Class Initialized
INFO - 2023-04-25 13:08:42 --> Security Class Initialized
DEBUG - 2023-04-25 13:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:08:42 --> Input Class Initialized
INFO - 2023-04-25 13:08:42 --> Language Class Initialized
INFO - 2023-04-25 13:08:42 --> Language Class Initialized
INFO - 2023-04-25 13:08:42 --> Config Class Initialized
INFO - 2023-04-25 13:08:42 --> Loader Class Initialized
INFO - 2023-04-25 13:08:42 --> Helper loaded: url_helper
INFO - 2023-04-25 13:08:42 --> Helper loaded: file_helper
INFO - 2023-04-25 13:08:42 --> Helper loaded: form_helper
INFO - 2023-04-25 13:08:42 --> Helper loaded: my_helper
INFO - 2023-04-25 13:08:42 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:08:42 --> Controller Class Initialized
DEBUG - 2023-04-25 13:08:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-04-25 13:08:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-25 13:08:42 --> Final output sent to browser
DEBUG - 2023-04-25 13:08:42 --> Total execution time: 0.0856
INFO - 2023-04-25 13:08:50 --> Config Class Initialized
INFO - 2023-04-25 13:08:50 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:08:50 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:08:50 --> Utf8 Class Initialized
INFO - 2023-04-25 13:08:50 --> URI Class Initialized
INFO - 2023-04-25 13:08:50 --> Router Class Initialized
INFO - 2023-04-25 13:08:50 --> Output Class Initialized
INFO - 2023-04-25 13:08:50 --> Security Class Initialized
DEBUG - 2023-04-25 13:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:08:50 --> Input Class Initialized
INFO - 2023-04-25 13:08:50 --> Language Class Initialized
INFO - 2023-04-25 13:08:50 --> Language Class Initialized
INFO - 2023-04-25 13:08:50 --> Config Class Initialized
INFO - 2023-04-25 13:08:50 --> Loader Class Initialized
INFO - 2023-04-25 13:08:50 --> Helper loaded: url_helper
INFO - 2023-04-25 13:08:50 --> Helper loaded: file_helper
INFO - 2023-04-25 13:08:50 --> Helper loaded: form_helper
INFO - 2023-04-25 13:08:50 --> Helper loaded: my_helper
INFO - 2023-04-25 13:08:50 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:08:50 --> Controller Class Initialized
INFO - 2023-04-25 13:08:50 --> Helper loaded: cookie_helper
INFO - 2023-04-25 13:08:50 --> Final output sent to browser
DEBUG - 2023-04-25 13:08:50 --> Total execution time: 0.1009
INFO - 2023-04-25 13:08:50 --> Config Class Initialized
INFO - 2023-04-25 13:08:50 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:08:50 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:08:50 --> Utf8 Class Initialized
INFO - 2023-04-25 13:08:50 --> URI Class Initialized
INFO - 2023-04-25 13:08:50 --> Router Class Initialized
INFO - 2023-04-25 13:08:50 --> Output Class Initialized
INFO - 2023-04-25 13:08:50 --> Security Class Initialized
DEBUG - 2023-04-25 13:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:08:50 --> Input Class Initialized
INFO - 2023-04-25 13:08:50 --> Language Class Initialized
INFO - 2023-04-25 13:08:50 --> Language Class Initialized
INFO - 2023-04-25 13:08:50 --> Config Class Initialized
INFO - 2023-04-25 13:08:50 --> Loader Class Initialized
INFO - 2023-04-25 13:08:50 --> Helper loaded: url_helper
INFO - 2023-04-25 13:08:50 --> Helper loaded: file_helper
INFO - 2023-04-25 13:08:50 --> Helper loaded: form_helper
INFO - 2023-04-25 13:08:50 --> Helper loaded: my_helper
INFO - 2023-04-25 13:08:50 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:08:50 --> Controller Class Initialized
DEBUG - 2023-04-25 13:08:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-04-25 13:08:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-25 13:08:50 --> Final output sent to browser
DEBUG - 2023-04-25 13:08:50 --> Total execution time: 0.0821
INFO - 2023-04-25 13:08:53 --> Config Class Initialized
INFO - 2023-04-25 13:08:53 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:08:53 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:08:53 --> Utf8 Class Initialized
INFO - 2023-04-25 13:08:53 --> URI Class Initialized
INFO - 2023-04-25 13:08:53 --> Router Class Initialized
INFO - 2023-04-25 13:08:53 --> Output Class Initialized
INFO - 2023-04-25 13:08:53 --> Security Class Initialized
DEBUG - 2023-04-25 13:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:08:53 --> Input Class Initialized
INFO - 2023-04-25 13:08:53 --> Language Class Initialized
INFO - 2023-04-25 13:08:53 --> Language Class Initialized
INFO - 2023-04-25 13:08:53 --> Config Class Initialized
INFO - 2023-04-25 13:08:53 --> Loader Class Initialized
INFO - 2023-04-25 13:08:53 --> Helper loaded: url_helper
INFO - 2023-04-25 13:08:53 --> Helper loaded: file_helper
INFO - 2023-04-25 13:08:53 --> Helper loaded: form_helper
INFO - 2023-04-25 13:08:53 --> Helper loaded: my_helper
INFO - 2023-04-25 13:08:53 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:08:53 --> Controller Class Initialized
DEBUG - 2023-04-25 13:08:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/list.php
DEBUG - 2023-04-25 13:08:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-25 13:08:53 --> Final output sent to browser
DEBUG - 2023-04-25 13:08:53 --> Total execution time: 0.0889
INFO - 2023-04-25 13:08:53 --> Config Class Initialized
INFO - 2023-04-25 13:08:53 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:08:53 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:08:53 --> Utf8 Class Initialized
INFO - 2023-04-25 13:08:53 --> URI Class Initialized
INFO - 2023-04-25 13:08:53 --> Router Class Initialized
INFO - 2023-04-25 13:08:53 --> Output Class Initialized
INFO - 2023-04-25 13:08:53 --> Security Class Initialized
DEBUG - 2023-04-25 13:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:08:53 --> Input Class Initialized
INFO - 2023-04-25 13:08:53 --> Language Class Initialized
INFO - 2023-04-25 13:08:53 --> Language Class Initialized
INFO - 2023-04-25 13:08:53 --> Config Class Initialized
INFO - 2023-04-25 13:08:53 --> Loader Class Initialized
INFO - 2023-04-25 13:08:53 --> Helper loaded: url_helper
INFO - 2023-04-25 13:08:53 --> Helper loaded: file_helper
INFO - 2023-04-25 13:08:53 --> Helper loaded: form_helper
INFO - 2023-04-25 13:08:53 --> Helper loaded: my_helper
INFO - 2023-04-25 13:08:53 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:08:53 --> Controller Class Initialized
INFO - 2023-04-25 13:09:09 --> Config Class Initialized
INFO - 2023-04-25 13:09:09 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:09:09 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:09:09 --> Utf8 Class Initialized
INFO - 2023-04-25 13:09:09 --> URI Class Initialized
INFO - 2023-04-25 13:09:09 --> Router Class Initialized
INFO - 2023-04-25 13:09:09 --> Output Class Initialized
INFO - 2023-04-25 13:09:09 --> Security Class Initialized
DEBUG - 2023-04-25 13:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:09:09 --> Input Class Initialized
INFO - 2023-04-25 13:09:09 --> Language Class Initialized
INFO - 2023-04-25 13:09:09 --> Language Class Initialized
INFO - 2023-04-25 13:09:09 --> Config Class Initialized
INFO - 2023-04-25 13:09:09 --> Loader Class Initialized
INFO - 2023-04-25 13:09:09 --> Helper loaded: url_helper
INFO - 2023-04-25 13:09:09 --> Helper loaded: file_helper
INFO - 2023-04-25 13:09:09 --> Helper loaded: form_helper
INFO - 2023-04-25 13:09:09 --> Helper loaded: my_helper
INFO - 2023-04-25 13:09:09 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:09:09 --> Controller Class Initialized
INFO - 2023-04-25 13:09:09 --> Final output sent to browser
DEBUG - 2023-04-25 13:09:09 --> Total execution time: 0.0741
INFO - 2023-04-25 13:09:09 --> Config Class Initialized
INFO - 2023-04-25 13:09:09 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:09:09 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:09:09 --> Utf8 Class Initialized
INFO - 2023-04-25 13:09:09 --> URI Class Initialized
INFO - 2023-04-25 13:09:09 --> Router Class Initialized
INFO - 2023-04-25 13:09:09 --> Output Class Initialized
INFO - 2023-04-25 13:09:09 --> Security Class Initialized
DEBUG - 2023-04-25 13:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:09:09 --> Input Class Initialized
INFO - 2023-04-25 13:09:09 --> Language Class Initialized
INFO - 2023-04-25 13:09:09 --> Language Class Initialized
INFO - 2023-04-25 13:09:09 --> Config Class Initialized
INFO - 2023-04-25 13:09:09 --> Loader Class Initialized
INFO - 2023-04-25 13:09:09 --> Helper loaded: url_helper
INFO - 2023-04-25 13:09:09 --> Helper loaded: file_helper
INFO - 2023-04-25 13:09:09 --> Helper loaded: form_helper
INFO - 2023-04-25 13:09:09 --> Helper loaded: my_helper
INFO - 2023-04-25 13:09:09 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:09:09 --> Controller Class Initialized
INFO - 2023-04-25 13:09:17 --> Config Class Initialized
INFO - 2023-04-25 13:09:17 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:09:17 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:09:17 --> Utf8 Class Initialized
INFO - 2023-04-25 13:09:17 --> URI Class Initialized
INFO - 2023-04-25 13:09:17 --> Router Class Initialized
INFO - 2023-04-25 13:09:17 --> Output Class Initialized
INFO - 2023-04-25 13:09:17 --> Security Class Initialized
DEBUG - 2023-04-25 13:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:09:17 --> Input Class Initialized
INFO - 2023-04-25 13:09:17 --> Language Class Initialized
INFO - 2023-04-25 13:09:17 --> Language Class Initialized
INFO - 2023-04-25 13:09:17 --> Config Class Initialized
INFO - 2023-04-25 13:09:17 --> Loader Class Initialized
INFO - 2023-04-25 13:09:17 --> Helper loaded: url_helper
INFO - 2023-04-25 13:09:17 --> Helper loaded: file_helper
INFO - 2023-04-25 13:09:17 --> Helper loaded: form_helper
INFO - 2023-04-25 13:09:17 --> Helper loaded: my_helper
INFO - 2023-04-25 13:09:17 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:09:17 --> Controller Class Initialized
INFO - 2023-04-25 13:09:17 --> Helper loaded: cookie_helper
INFO - 2023-04-25 13:09:17 --> Config Class Initialized
INFO - 2023-04-25 13:09:17 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:09:17 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:09:17 --> Utf8 Class Initialized
INFO - 2023-04-25 13:09:17 --> URI Class Initialized
INFO - 2023-04-25 13:09:17 --> Router Class Initialized
INFO - 2023-04-25 13:09:17 --> Output Class Initialized
INFO - 2023-04-25 13:09:17 --> Security Class Initialized
DEBUG - 2023-04-25 13:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:09:17 --> Input Class Initialized
INFO - 2023-04-25 13:09:17 --> Language Class Initialized
INFO - 2023-04-25 13:09:17 --> Language Class Initialized
INFO - 2023-04-25 13:09:17 --> Config Class Initialized
INFO - 2023-04-25 13:09:17 --> Loader Class Initialized
INFO - 2023-04-25 13:09:17 --> Helper loaded: url_helper
INFO - 2023-04-25 13:09:17 --> Helper loaded: file_helper
INFO - 2023-04-25 13:09:17 --> Helper loaded: form_helper
INFO - 2023-04-25 13:09:17 --> Helper loaded: my_helper
INFO - 2023-04-25 13:09:17 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:09:17 --> Controller Class Initialized
INFO - 2023-04-25 13:09:17 --> Config Class Initialized
INFO - 2023-04-25 13:09:17 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:09:17 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:09:17 --> Utf8 Class Initialized
INFO - 2023-04-25 13:09:17 --> URI Class Initialized
INFO - 2023-04-25 13:09:17 --> Router Class Initialized
INFO - 2023-04-25 13:09:17 --> Output Class Initialized
INFO - 2023-04-25 13:09:17 --> Security Class Initialized
DEBUG - 2023-04-25 13:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:09:17 --> Input Class Initialized
INFO - 2023-04-25 13:09:17 --> Language Class Initialized
INFO - 2023-04-25 13:09:17 --> Language Class Initialized
INFO - 2023-04-25 13:09:17 --> Config Class Initialized
INFO - 2023-04-25 13:09:17 --> Loader Class Initialized
INFO - 2023-04-25 13:09:17 --> Helper loaded: url_helper
INFO - 2023-04-25 13:09:17 --> Helper loaded: file_helper
INFO - 2023-04-25 13:09:17 --> Helper loaded: form_helper
INFO - 2023-04-25 13:09:17 --> Helper loaded: my_helper
INFO - 2023-04-25 13:09:17 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:09:17 --> Controller Class Initialized
DEBUG - 2023-04-25 13:09:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-04-25 13:09:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-25 13:09:17 --> Final output sent to browser
DEBUG - 2023-04-25 13:09:17 --> Total execution time: 0.0548
INFO - 2023-04-25 13:09:19 --> Config Class Initialized
INFO - 2023-04-25 13:09:19 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:09:19 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:09:19 --> Utf8 Class Initialized
INFO - 2023-04-25 13:09:19 --> URI Class Initialized
INFO - 2023-04-25 13:09:19 --> Router Class Initialized
INFO - 2023-04-25 13:09:19 --> Output Class Initialized
INFO - 2023-04-25 13:09:19 --> Security Class Initialized
DEBUG - 2023-04-25 13:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:09:19 --> Input Class Initialized
INFO - 2023-04-25 13:09:19 --> Language Class Initialized
INFO - 2023-04-25 13:09:19 --> Language Class Initialized
INFO - 2023-04-25 13:09:19 --> Config Class Initialized
INFO - 2023-04-25 13:09:19 --> Loader Class Initialized
INFO - 2023-04-25 13:09:19 --> Helper loaded: url_helper
INFO - 2023-04-25 13:09:19 --> Helper loaded: file_helper
INFO - 2023-04-25 13:09:19 --> Helper loaded: form_helper
INFO - 2023-04-25 13:09:19 --> Helper loaded: my_helper
INFO - 2023-04-25 13:09:19 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:09:19 --> Controller Class Initialized
INFO - 2023-04-25 13:09:19 --> Final output sent to browser
DEBUG - 2023-04-25 13:09:19 --> Total execution time: 0.0680
INFO - 2023-04-25 13:09:26 --> Config Class Initialized
INFO - 2023-04-25 13:09:26 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:09:26 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:09:26 --> Utf8 Class Initialized
INFO - 2023-04-25 13:09:26 --> URI Class Initialized
INFO - 2023-04-25 13:09:26 --> Router Class Initialized
INFO - 2023-04-25 13:09:26 --> Output Class Initialized
INFO - 2023-04-25 13:09:26 --> Security Class Initialized
DEBUG - 2023-04-25 13:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:09:26 --> Input Class Initialized
INFO - 2023-04-25 13:09:26 --> Language Class Initialized
INFO - 2023-04-25 13:09:26 --> Language Class Initialized
INFO - 2023-04-25 13:09:26 --> Config Class Initialized
INFO - 2023-04-25 13:09:26 --> Loader Class Initialized
INFO - 2023-04-25 13:09:26 --> Helper loaded: url_helper
INFO - 2023-04-25 13:09:26 --> Helper loaded: file_helper
INFO - 2023-04-25 13:09:26 --> Helper loaded: form_helper
INFO - 2023-04-25 13:09:26 --> Helper loaded: my_helper
INFO - 2023-04-25 13:09:26 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:09:26 --> Controller Class Initialized
INFO - 2023-04-25 13:09:26 --> Helper loaded: cookie_helper
INFO - 2023-04-25 13:09:26 --> Final output sent to browser
DEBUG - 2023-04-25 13:09:26 --> Total execution time: 0.0455
INFO - 2023-04-25 13:09:26 --> Config Class Initialized
INFO - 2023-04-25 13:09:26 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:09:26 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:09:26 --> Utf8 Class Initialized
INFO - 2023-04-25 13:09:26 --> URI Class Initialized
INFO - 2023-04-25 13:09:26 --> Router Class Initialized
INFO - 2023-04-25 13:09:26 --> Output Class Initialized
INFO - 2023-04-25 13:09:26 --> Security Class Initialized
DEBUG - 2023-04-25 13:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:09:26 --> Input Class Initialized
INFO - 2023-04-25 13:09:26 --> Language Class Initialized
INFO - 2023-04-25 13:09:26 --> Language Class Initialized
INFO - 2023-04-25 13:09:26 --> Config Class Initialized
INFO - 2023-04-25 13:09:26 --> Loader Class Initialized
INFO - 2023-04-25 13:09:26 --> Helper loaded: url_helper
INFO - 2023-04-25 13:09:26 --> Helper loaded: file_helper
INFO - 2023-04-25 13:09:26 --> Helper loaded: form_helper
INFO - 2023-04-25 13:09:26 --> Helper loaded: my_helper
INFO - 2023-04-25 13:09:26 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:09:26 --> Controller Class Initialized
DEBUG - 2023-04-25 13:09:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-04-25 13:09:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-25 13:09:26 --> Final output sent to browser
DEBUG - 2023-04-25 13:09:26 --> Total execution time: 0.0509
INFO - 2023-04-25 13:09:30 --> Config Class Initialized
INFO - 2023-04-25 13:09:30 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:09:30 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:09:30 --> Utf8 Class Initialized
INFO - 2023-04-25 13:09:30 --> URI Class Initialized
INFO - 2023-04-25 13:09:30 --> Router Class Initialized
INFO - 2023-04-25 13:09:30 --> Output Class Initialized
INFO - 2023-04-25 13:09:30 --> Security Class Initialized
DEBUG - 2023-04-25 13:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:09:30 --> Input Class Initialized
INFO - 2023-04-25 13:09:30 --> Language Class Initialized
INFO - 2023-04-25 13:09:30 --> Language Class Initialized
INFO - 2023-04-25 13:09:30 --> Config Class Initialized
INFO - 2023-04-25 13:09:30 --> Loader Class Initialized
INFO - 2023-04-25 13:09:30 --> Helper loaded: url_helper
INFO - 2023-04-25 13:09:30 --> Helper loaded: file_helper
INFO - 2023-04-25 13:09:30 --> Helper loaded: form_helper
INFO - 2023-04-25 13:09:30 --> Helper loaded: my_helper
INFO - 2023-04-25 13:09:30 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:09:30 --> Controller Class Initialized
DEBUG - 2023-04-25 13:09:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/list.php
DEBUG - 2023-04-25 13:09:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-25 13:09:30 --> Final output sent to browser
DEBUG - 2023-04-25 13:09:30 --> Total execution time: 0.0386
INFO - 2023-04-25 13:09:30 --> Config Class Initialized
INFO - 2023-04-25 13:09:30 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:09:30 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:09:30 --> Utf8 Class Initialized
INFO - 2023-04-25 13:09:30 --> URI Class Initialized
INFO - 2023-04-25 13:09:30 --> Router Class Initialized
INFO - 2023-04-25 13:09:30 --> Output Class Initialized
INFO - 2023-04-25 13:09:30 --> Security Class Initialized
DEBUG - 2023-04-25 13:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:09:30 --> Input Class Initialized
INFO - 2023-04-25 13:09:30 --> Language Class Initialized
INFO - 2023-04-25 13:09:30 --> Language Class Initialized
INFO - 2023-04-25 13:09:30 --> Config Class Initialized
INFO - 2023-04-25 13:09:30 --> Loader Class Initialized
INFO - 2023-04-25 13:09:30 --> Helper loaded: url_helper
INFO - 2023-04-25 13:09:30 --> Helper loaded: file_helper
INFO - 2023-04-25 13:09:30 --> Helper loaded: form_helper
INFO - 2023-04-25 13:09:30 --> Helper loaded: my_helper
INFO - 2023-04-25 13:09:30 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:09:30 --> Controller Class Initialized
INFO - 2023-04-25 13:09:32 --> Config Class Initialized
INFO - 2023-04-25 13:09:32 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:09:32 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:09:32 --> Utf8 Class Initialized
INFO - 2023-04-25 13:09:32 --> URI Class Initialized
INFO - 2023-04-25 13:09:32 --> Router Class Initialized
INFO - 2023-04-25 13:09:32 --> Output Class Initialized
INFO - 2023-04-25 13:09:32 --> Security Class Initialized
DEBUG - 2023-04-25 13:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:09:32 --> Input Class Initialized
INFO - 2023-04-25 13:09:32 --> Language Class Initialized
INFO - 2023-04-25 13:09:32 --> Language Class Initialized
INFO - 2023-04-25 13:09:32 --> Config Class Initialized
INFO - 2023-04-25 13:09:32 --> Loader Class Initialized
INFO - 2023-04-25 13:09:32 --> Helper loaded: url_helper
INFO - 2023-04-25 13:09:32 --> Helper loaded: file_helper
INFO - 2023-04-25 13:09:32 --> Helper loaded: form_helper
INFO - 2023-04-25 13:09:32 --> Helper loaded: my_helper
INFO - 2023-04-25 13:09:32 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:09:32 --> Controller Class Initialized
ERROR - 2023-04-25 13:09:32 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\myraportk13\application\modules\data_siswa\views\form.php 231
DEBUG - 2023-04-25 13:09:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/form.php
DEBUG - 2023-04-25 13:09:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-25 13:09:32 --> Final output sent to browser
DEBUG - 2023-04-25 13:09:32 --> Total execution time: 0.1083
INFO - 2023-04-25 13:09:44 --> Config Class Initialized
INFO - 2023-04-25 13:09:44 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:09:44 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:09:44 --> Utf8 Class Initialized
INFO - 2023-04-25 13:09:44 --> URI Class Initialized
INFO - 2023-04-25 13:09:44 --> Router Class Initialized
INFO - 2023-04-25 13:09:44 --> Output Class Initialized
INFO - 2023-04-25 13:09:44 --> Security Class Initialized
DEBUG - 2023-04-25 13:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:09:44 --> Input Class Initialized
INFO - 2023-04-25 13:09:44 --> Language Class Initialized
INFO - 2023-04-25 13:09:44 --> Language Class Initialized
INFO - 2023-04-25 13:09:44 --> Config Class Initialized
INFO - 2023-04-25 13:09:44 --> Loader Class Initialized
INFO - 2023-04-25 13:09:44 --> Helper loaded: url_helper
INFO - 2023-04-25 13:09:44 --> Helper loaded: file_helper
INFO - 2023-04-25 13:09:44 --> Helper loaded: form_helper
INFO - 2023-04-25 13:09:44 --> Helper loaded: my_helper
INFO - 2023-04-25 13:09:44 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:09:44 --> Controller Class Initialized
DEBUG - 2023-04-25 13:09:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/list.php
DEBUG - 2023-04-25 13:09:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-25 13:09:44 --> Final output sent to browser
DEBUG - 2023-04-25 13:09:44 --> Total execution time: 0.0430
INFO - 2023-04-25 13:09:44 --> Config Class Initialized
INFO - 2023-04-25 13:09:44 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:09:44 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:09:44 --> Utf8 Class Initialized
INFO - 2023-04-25 13:09:44 --> URI Class Initialized
INFO - 2023-04-25 13:09:44 --> Router Class Initialized
INFO - 2023-04-25 13:09:44 --> Output Class Initialized
INFO - 2023-04-25 13:09:44 --> Security Class Initialized
DEBUG - 2023-04-25 13:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:09:44 --> Input Class Initialized
INFO - 2023-04-25 13:09:44 --> Language Class Initialized
INFO - 2023-04-25 13:09:44 --> Language Class Initialized
INFO - 2023-04-25 13:09:44 --> Config Class Initialized
INFO - 2023-04-25 13:09:44 --> Loader Class Initialized
INFO - 2023-04-25 13:09:44 --> Helper loaded: url_helper
INFO - 2023-04-25 13:09:44 --> Helper loaded: file_helper
INFO - 2023-04-25 13:09:44 --> Helper loaded: form_helper
INFO - 2023-04-25 13:09:44 --> Helper loaded: my_helper
INFO - 2023-04-25 13:09:44 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:09:44 --> Controller Class Initialized
INFO - 2023-04-25 13:09:49 --> Config Class Initialized
INFO - 2023-04-25 13:09:49 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:09:49 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:09:49 --> Utf8 Class Initialized
INFO - 2023-04-25 13:09:49 --> URI Class Initialized
INFO - 2023-04-25 13:09:49 --> Router Class Initialized
INFO - 2023-04-25 13:09:49 --> Output Class Initialized
INFO - 2023-04-25 13:09:49 --> Security Class Initialized
DEBUG - 2023-04-25 13:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:09:49 --> Input Class Initialized
INFO - 2023-04-25 13:09:49 --> Language Class Initialized
INFO - 2023-04-25 13:09:49 --> Language Class Initialized
INFO - 2023-04-25 13:09:49 --> Config Class Initialized
INFO - 2023-04-25 13:09:49 --> Loader Class Initialized
INFO - 2023-04-25 13:09:49 --> Helper loaded: url_helper
INFO - 2023-04-25 13:09:49 --> Helper loaded: file_helper
INFO - 2023-04-25 13:09:49 --> Helper loaded: form_helper
INFO - 2023-04-25 13:09:49 --> Helper loaded: my_helper
INFO - 2023-04-25 13:09:49 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:09:49 --> Controller Class Initialized
INFO - 2023-04-25 13:09:49 --> Helper loaded: cookie_helper
INFO - 2023-04-25 13:09:49 --> Config Class Initialized
INFO - 2023-04-25 13:09:49 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:09:49 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:09:49 --> Utf8 Class Initialized
INFO - 2023-04-25 13:09:49 --> URI Class Initialized
INFO - 2023-04-25 13:09:49 --> Router Class Initialized
INFO - 2023-04-25 13:09:49 --> Output Class Initialized
INFO - 2023-04-25 13:09:49 --> Security Class Initialized
DEBUG - 2023-04-25 13:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:09:49 --> Input Class Initialized
INFO - 2023-04-25 13:09:49 --> Language Class Initialized
INFO - 2023-04-25 13:09:49 --> Language Class Initialized
INFO - 2023-04-25 13:09:49 --> Config Class Initialized
INFO - 2023-04-25 13:09:49 --> Loader Class Initialized
INFO - 2023-04-25 13:09:49 --> Helper loaded: url_helper
INFO - 2023-04-25 13:09:49 --> Helper loaded: file_helper
INFO - 2023-04-25 13:09:49 --> Helper loaded: form_helper
INFO - 2023-04-25 13:09:49 --> Helper loaded: my_helper
INFO - 2023-04-25 13:09:49 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:09:49 --> Controller Class Initialized
INFO - 2023-04-25 13:09:49 --> Config Class Initialized
INFO - 2023-04-25 13:09:49 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:09:49 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:09:49 --> Utf8 Class Initialized
INFO - 2023-04-25 13:09:49 --> URI Class Initialized
INFO - 2023-04-25 13:09:49 --> Router Class Initialized
INFO - 2023-04-25 13:09:49 --> Output Class Initialized
INFO - 2023-04-25 13:09:49 --> Security Class Initialized
DEBUG - 2023-04-25 13:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:09:49 --> Input Class Initialized
INFO - 2023-04-25 13:09:49 --> Language Class Initialized
INFO - 2023-04-25 13:09:49 --> Language Class Initialized
INFO - 2023-04-25 13:09:49 --> Config Class Initialized
INFO - 2023-04-25 13:09:49 --> Loader Class Initialized
INFO - 2023-04-25 13:09:49 --> Helper loaded: url_helper
INFO - 2023-04-25 13:09:49 --> Helper loaded: file_helper
INFO - 2023-04-25 13:09:49 --> Helper loaded: form_helper
INFO - 2023-04-25 13:09:49 --> Helper loaded: my_helper
INFO - 2023-04-25 13:09:49 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:09:49 --> Controller Class Initialized
DEBUG - 2023-04-25 13:09:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-04-25 13:09:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-25 13:09:49 --> Final output sent to browser
DEBUG - 2023-04-25 13:09:49 --> Total execution time: 0.0550
INFO - 2023-04-25 13:10:19 --> Config Class Initialized
INFO - 2023-04-25 13:10:19 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:10:19 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:10:19 --> Utf8 Class Initialized
INFO - 2023-04-25 13:10:19 --> URI Class Initialized
INFO - 2023-04-25 13:10:19 --> Router Class Initialized
INFO - 2023-04-25 13:10:19 --> Output Class Initialized
INFO - 2023-04-25 13:10:19 --> Security Class Initialized
DEBUG - 2023-04-25 13:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:10:19 --> Input Class Initialized
INFO - 2023-04-25 13:10:19 --> Language Class Initialized
INFO - 2023-04-25 13:10:19 --> Language Class Initialized
INFO - 2023-04-25 13:10:19 --> Config Class Initialized
INFO - 2023-04-25 13:10:19 --> Loader Class Initialized
INFO - 2023-04-25 13:10:19 --> Helper loaded: url_helper
INFO - 2023-04-25 13:10:19 --> Helper loaded: file_helper
INFO - 2023-04-25 13:10:19 --> Helper loaded: form_helper
INFO - 2023-04-25 13:10:19 --> Helper loaded: my_helper
INFO - 2023-04-25 13:10:19 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:10:19 --> Controller Class Initialized
INFO - 2023-04-25 13:10:19 --> Helper loaded: cookie_helper
INFO - 2023-04-25 13:10:19 --> Final output sent to browser
DEBUG - 2023-04-25 13:10:19 --> Total execution time: 0.0455
INFO - 2023-04-25 13:10:19 --> Config Class Initialized
INFO - 2023-04-25 13:10:19 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:10:19 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:10:19 --> Utf8 Class Initialized
INFO - 2023-04-25 13:10:19 --> URI Class Initialized
INFO - 2023-04-25 13:10:19 --> Router Class Initialized
INFO - 2023-04-25 13:10:19 --> Output Class Initialized
INFO - 2023-04-25 13:10:19 --> Security Class Initialized
DEBUG - 2023-04-25 13:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:10:19 --> Input Class Initialized
INFO - 2023-04-25 13:10:19 --> Language Class Initialized
INFO - 2023-04-25 13:10:19 --> Language Class Initialized
INFO - 2023-04-25 13:10:19 --> Config Class Initialized
INFO - 2023-04-25 13:10:19 --> Loader Class Initialized
INFO - 2023-04-25 13:10:19 --> Helper loaded: url_helper
INFO - 2023-04-25 13:10:19 --> Helper loaded: file_helper
INFO - 2023-04-25 13:10:19 --> Helper loaded: form_helper
INFO - 2023-04-25 13:10:19 --> Helper loaded: my_helper
INFO - 2023-04-25 13:10:19 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:10:19 --> Controller Class Initialized
DEBUG - 2023-04-25 13:10:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_siswa.php
DEBUG - 2023-04-25 13:10:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-25 13:10:19 --> Final output sent to browser
DEBUG - 2023-04-25 13:10:19 --> Total execution time: 0.0586
INFO - 2023-04-25 13:10:21 --> Config Class Initialized
INFO - 2023-04-25 13:10:21 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:10:21 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:10:21 --> Utf8 Class Initialized
INFO - 2023-04-25 13:10:21 --> URI Class Initialized
DEBUG - 2023-04-25 13:10:21 --> No URI present. Default controller set.
INFO - 2023-04-25 13:10:21 --> Router Class Initialized
INFO - 2023-04-25 13:10:21 --> Output Class Initialized
INFO - 2023-04-25 13:10:21 --> Security Class Initialized
DEBUG - 2023-04-25 13:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:10:21 --> Input Class Initialized
INFO - 2023-04-25 13:10:21 --> Language Class Initialized
INFO - 2023-04-25 13:10:21 --> Language Class Initialized
INFO - 2023-04-25 13:10:21 --> Config Class Initialized
INFO - 2023-04-25 13:10:21 --> Loader Class Initialized
INFO - 2023-04-25 13:10:21 --> Helper loaded: url_helper
INFO - 2023-04-25 13:10:21 --> Helper loaded: file_helper
INFO - 2023-04-25 13:10:21 --> Helper loaded: form_helper
INFO - 2023-04-25 13:10:21 --> Helper loaded: my_helper
INFO - 2023-04-25 13:10:21 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:10:22 --> Controller Class Initialized
DEBUG - 2023-04-25 13:10:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_siswa.php
DEBUG - 2023-04-25 13:10:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-25 13:10:22 --> Final output sent to browser
DEBUG - 2023-04-25 13:10:22 --> Total execution time: 0.0569
INFO - 2023-04-25 13:10:23 --> Config Class Initialized
INFO - 2023-04-25 13:10:23 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:10:23 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:10:23 --> Utf8 Class Initialized
INFO - 2023-04-25 13:10:23 --> URI Class Initialized
INFO - 2023-04-25 13:10:23 --> Router Class Initialized
INFO - 2023-04-25 13:10:23 --> Output Class Initialized
INFO - 2023-04-25 13:10:23 --> Security Class Initialized
DEBUG - 2023-04-25 13:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:10:23 --> Input Class Initialized
INFO - 2023-04-25 13:10:23 --> Language Class Initialized
INFO - 2023-04-25 13:10:23 --> Language Class Initialized
INFO - 2023-04-25 13:10:23 --> Config Class Initialized
INFO - 2023-04-25 13:10:23 --> Loader Class Initialized
INFO - 2023-04-25 13:10:23 --> Helper loaded: url_helper
INFO - 2023-04-25 13:10:23 --> Helper loaded: file_helper
INFO - 2023-04-25 13:10:23 --> Helper loaded: form_helper
INFO - 2023-04-25 13:10:23 --> Helper loaded: my_helper
INFO - 2023-04-25 13:10:23 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:10:23 --> Controller Class Initialized
DEBUG - 2023-04-25 13:10:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/lihat_raport/views/list.php
DEBUG - 2023-04-25 13:10:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-25 13:10:23 --> Final output sent to browser
DEBUG - 2023-04-25 13:10:23 --> Total execution time: 0.0861
INFO - 2023-04-25 13:10:25 --> Config Class Initialized
INFO - 2023-04-25 13:10:25 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:10:25 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:10:25 --> Utf8 Class Initialized
INFO - 2023-04-25 13:10:25 --> URI Class Initialized
DEBUG - 2023-04-25 13:10:25 --> No URI present. Default controller set.
INFO - 2023-04-25 13:10:25 --> Router Class Initialized
INFO - 2023-04-25 13:10:25 --> Output Class Initialized
INFO - 2023-04-25 13:10:25 --> Security Class Initialized
DEBUG - 2023-04-25 13:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:10:25 --> Input Class Initialized
INFO - 2023-04-25 13:10:25 --> Language Class Initialized
INFO - 2023-04-25 13:10:25 --> Language Class Initialized
INFO - 2023-04-25 13:10:25 --> Config Class Initialized
INFO - 2023-04-25 13:10:25 --> Loader Class Initialized
INFO - 2023-04-25 13:10:25 --> Helper loaded: url_helper
INFO - 2023-04-25 13:10:25 --> Helper loaded: file_helper
INFO - 2023-04-25 13:10:25 --> Helper loaded: form_helper
INFO - 2023-04-25 13:10:25 --> Helper loaded: my_helper
INFO - 2023-04-25 13:10:25 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:10:25 --> Controller Class Initialized
DEBUG - 2023-04-25 13:10:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_siswa.php
DEBUG - 2023-04-25 13:10:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-25 13:10:25 --> Final output sent to browser
DEBUG - 2023-04-25 13:10:25 --> Total execution time: 0.0393
INFO - 2023-04-25 13:10:28 --> Config Class Initialized
INFO - 2023-04-25 13:10:28 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:10:28 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:10:28 --> Utf8 Class Initialized
INFO - 2023-04-25 13:10:28 --> URI Class Initialized
INFO - 2023-04-25 13:10:28 --> Router Class Initialized
INFO - 2023-04-25 13:10:28 --> Output Class Initialized
INFO - 2023-04-25 13:10:28 --> Security Class Initialized
DEBUG - 2023-04-25 13:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:10:28 --> Input Class Initialized
INFO - 2023-04-25 13:10:28 --> Language Class Initialized
INFO - 2023-04-25 13:10:28 --> Language Class Initialized
INFO - 2023-04-25 13:10:28 --> Config Class Initialized
INFO - 2023-04-25 13:10:28 --> Loader Class Initialized
INFO - 2023-04-25 13:10:28 --> Helper loaded: url_helper
INFO - 2023-04-25 13:10:28 --> Helper loaded: file_helper
INFO - 2023-04-25 13:10:28 --> Helper loaded: form_helper
INFO - 2023-04-25 13:10:28 --> Helper loaded: my_helper
INFO - 2023-04-25 13:10:28 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:10:28 --> Controller Class Initialized
DEBUG - 2023-04-25 13:10:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/lihat_raport/views/list.php
DEBUG - 2023-04-25 13:10:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-25 13:10:28 --> Final output sent to browser
DEBUG - 2023-04-25 13:10:28 --> Total execution time: 0.0568
INFO - 2023-04-25 13:10:33 --> Config Class Initialized
INFO - 2023-04-25 13:10:33 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:10:33 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:10:33 --> Utf8 Class Initialized
INFO - 2023-04-25 13:10:33 --> URI Class Initialized
INFO - 2023-04-25 13:10:33 --> Router Class Initialized
INFO - 2023-04-25 13:10:33 --> Output Class Initialized
INFO - 2023-04-25 13:10:33 --> Security Class Initialized
DEBUG - 2023-04-25 13:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:10:33 --> Input Class Initialized
INFO - 2023-04-25 13:10:33 --> Language Class Initialized
INFO - 2023-04-25 13:10:33 --> Language Class Initialized
INFO - 2023-04-25 13:10:33 --> Config Class Initialized
INFO - 2023-04-25 13:10:33 --> Loader Class Initialized
INFO - 2023-04-25 13:10:33 --> Helper loaded: url_helper
INFO - 2023-04-25 13:10:33 --> Helper loaded: file_helper
INFO - 2023-04-25 13:10:33 --> Helper loaded: form_helper
INFO - 2023-04-25 13:10:33 --> Helper loaded: my_helper
INFO - 2023-04-25 13:10:33 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:10:33 --> Controller Class Initialized
ERROR - 2023-04-25 13:10:33 --> Severity: error --> Exception: Too few arguments to function nilai_pre(), 1 passed in C:\xampp\htdocs\myraportk13\application\modules\lihat_raport\controllers\Lihat_raport.php on line 130 and exactly 3 expected C:\xampp\htdocs\myraportk13\application\helpers\my_helper.php 81
INFO - 2023-04-25 13:10:40 --> Config Class Initialized
INFO - 2023-04-25 13:10:40 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:10:40 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:10:40 --> Utf8 Class Initialized
INFO - 2023-04-25 13:10:40 --> URI Class Initialized
INFO - 2023-04-25 13:10:40 --> Router Class Initialized
INFO - 2023-04-25 13:10:40 --> Output Class Initialized
INFO - 2023-04-25 13:10:40 --> Security Class Initialized
DEBUG - 2023-04-25 13:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:10:40 --> Input Class Initialized
INFO - 2023-04-25 13:10:40 --> Language Class Initialized
INFO - 2023-04-25 13:10:40 --> Language Class Initialized
INFO - 2023-04-25 13:10:40 --> Config Class Initialized
INFO - 2023-04-25 13:10:40 --> Loader Class Initialized
INFO - 2023-04-25 13:10:40 --> Helper loaded: url_helper
INFO - 2023-04-25 13:10:40 --> Helper loaded: file_helper
INFO - 2023-04-25 13:10:40 --> Helper loaded: form_helper
INFO - 2023-04-25 13:10:40 --> Helper loaded: my_helper
INFO - 2023-04-25 13:10:40 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:10:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:10:40 --> Controller Class Initialized
ERROR - 2023-04-25 13:10:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\lihat_raport\controllers\Lihat_raport.php 288
ERROR - 2023-04-25 13:10:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\lihat_raport\controllers\Lihat_raport.php 289
DEBUG - 2023-04-25 13:10:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/lihat_raport/views/cetak_rapot.php
INFO - 2023-04-25 13:10:40 --> Final output sent to browser
DEBUG - 2023-04-25 13:10:40 --> Total execution time: 0.1021
INFO - 2023-04-25 13:10:46 --> Config Class Initialized
INFO - 2023-04-25 13:10:46 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:10:46 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:10:46 --> Utf8 Class Initialized
INFO - 2023-04-25 13:10:46 --> URI Class Initialized
INFO - 2023-04-25 13:10:46 --> Router Class Initialized
INFO - 2023-04-25 13:10:46 --> Output Class Initialized
INFO - 2023-04-25 13:10:46 --> Security Class Initialized
DEBUG - 2023-04-25 13:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:10:46 --> Input Class Initialized
INFO - 2023-04-25 13:10:46 --> Language Class Initialized
INFO - 2023-04-25 13:10:46 --> Language Class Initialized
INFO - 2023-04-25 13:10:46 --> Config Class Initialized
INFO - 2023-04-25 13:10:46 --> Loader Class Initialized
INFO - 2023-04-25 13:10:46 --> Helper loaded: url_helper
INFO - 2023-04-25 13:10:46 --> Helper loaded: file_helper
INFO - 2023-04-25 13:10:46 --> Helper loaded: form_helper
INFO - 2023-04-25 13:10:46 --> Helper loaded: my_helper
INFO - 2023-04-25 13:10:46 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:10:46 --> Controller Class Initialized
DEBUG - 2023-04-25 13:10:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/lihat_raport/views/cetak_sampul2.php
INFO - 2023-04-25 13:10:46 --> Final output sent to browser
DEBUG - 2023-04-25 13:10:46 --> Total execution time: 0.0593
INFO - 2023-04-25 13:10:55 --> Config Class Initialized
INFO - 2023-04-25 13:10:55 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:10:55 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:10:55 --> Utf8 Class Initialized
INFO - 2023-04-25 13:10:55 --> URI Class Initialized
DEBUG - 2023-04-25 13:10:55 --> No URI present. Default controller set.
INFO - 2023-04-25 13:10:55 --> Router Class Initialized
INFO - 2023-04-25 13:10:55 --> Output Class Initialized
INFO - 2023-04-25 13:10:55 --> Security Class Initialized
DEBUG - 2023-04-25 13:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:10:55 --> Input Class Initialized
INFO - 2023-04-25 13:10:55 --> Language Class Initialized
INFO - 2023-04-25 13:10:55 --> Language Class Initialized
INFO - 2023-04-25 13:10:55 --> Config Class Initialized
INFO - 2023-04-25 13:10:55 --> Loader Class Initialized
INFO - 2023-04-25 13:10:55 --> Helper loaded: url_helper
INFO - 2023-04-25 13:10:55 --> Helper loaded: file_helper
INFO - 2023-04-25 13:10:55 --> Helper loaded: form_helper
INFO - 2023-04-25 13:10:55 --> Helper loaded: my_helper
INFO - 2023-04-25 13:10:55 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:10:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:10:55 --> Controller Class Initialized
DEBUG - 2023-04-25 13:10:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_siswa.php
DEBUG - 2023-04-25 13:10:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-25 13:10:55 --> Final output sent to browser
DEBUG - 2023-04-25 13:10:55 --> Total execution time: 0.0492
INFO - 2023-04-25 13:11:05 --> Config Class Initialized
INFO - 2023-04-25 13:11:05 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:11:05 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:11:05 --> Utf8 Class Initialized
INFO - 2023-04-25 13:11:05 --> URI Class Initialized
INFO - 2023-04-25 13:11:05 --> Router Class Initialized
INFO - 2023-04-25 13:11:05 --> Output Class Initialized
INFO - 2023-04-25 13:11:05 --> Security Class Initialized
DEBUG - 2023-04-25 13:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:11:05 --> Input Class Initialized
INFO - 2023-04-25 13:11:05 --> Language Class Initialized
INFO - 2023-04-25 13:11:05 --> Language Class Initialized
INFO - 2023-04-25 13:11:05 --> Config Class Initialized
INFO - 2023-04-25 13:11:05 --> Loader Class Initialized
INFO - 2023-04-25 13:11:05 --> Helper loaded: url_helper
INFO - 2023-04-25 13:11:05 --> Helper loaded: file_helper
INFO - 2023-04-25 13:11:05 --> Helper loaded: form_helper
INFO - 2023-04-25 13:11:05 --> Helper loaded: my_helper
INFO - 2023-04-25 13:11:05 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:11:05 --> Controller Class Initialized
DEBUG - 2023-04-25 13:11:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/lihat_raport/views/list.php
DEBUG - 2023-04-25 13:11:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-25 13:11:05 --> Final output sent to browser
DEBUG - 2023-04-25 13:11:05 --> Total execution time: 0.0588
INFO - 2023-04-25 13:11:15 --> Config Class Initialized
INFO - 2023-04-25 13:11:15 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:11:15 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:11:15 --> Utf8 Class Initialized
INFO - 2023-04-25 13:11:15 --> URI Class Initialized
INFO - 2023-04-25 13:11:15 --> Router Class Initialized
INFO - 2023-04-25 13:11:15 --> Output Class Initialized
INFO - 2023-04-25 13:11:15 --> Security Class Initialized
DEBUG - 2023-04-25 13:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:11:15 --> Input Class Initialized
INFO - 2023-04-25 13:11:15 --> Language Class Initialized
INFO - 2023-04-25 13:11:15 --> Language Class Initialized
INFO - 2023-04-25 13:11:15 --> Config Class Initialized
INFO - 2023-04-25 13:11:15 --> Loader Class Initialized
INFO - 2023-04-25 13:11:15 --> Helper loaded: url_helper
INFO - 2023-04-25 13:11:15 --> Helper loaded: file_helper
INFO - 2023-04-25 13:11:15 --> Helper loaded: form_helper
INFO - 2023-04-25 13:11:15 --> Helper loaded: my_helper
INFO - 2023-04-25 13:11:15 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:11:15 --> Controller Class Initialized
INFO - 2023-04-25 13:11:15 --> Helper loaded: cookie_helper
INFO - 2023-04-25 13:11:15 --> Config Class Initialized
INFO - 2023-04-25 13:11:15 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:11:15 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:11:15 --> Utf8 Class Initialized
INFO - 2023-04-25 13:11:15 --> URI Class Initialized
INFO - 2023-04-25 13:11:15 --> Router Class Initialized
INFO - 2023-04-25 13:11:15 --> Output Class Initialized
INFO - 2023-04-25 13:11:15 --> Security Class Initialized
DEBUG - 2023-04-25 13:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:11:15 --> Input Class Initialized
INFO - 2023-04-25 13:11:15 --> Language Class Initialized
INFO - 2023-04-25 13:11:15 --> Language Class Initialized
INFO - 2023-04-25 13:11:15 --> Config Class Initialized
INFO - 2023-04-25 13:11:15 --> Loader Class Initialized
INFO - 2023-04-25 13:11:15 --> Helper loaded: url_helper
INFO - 2023-04-25 13:11:15 --> Helper loaded: file_helper
INFO - 2023-04-25 13:11:15 --> Helper loaded: form_helper
INFO - 2023-04-25 13:11:15 --> Helper loaded: my_helper
INFO - 2023-04-25 13:11:15 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:11:15 --> Controller Class Initialized
INFO - 2023-04-25 13:11:15 --> Config Class Initialized
INFO - 2023-04-25 13:11:15 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:11:15 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:11:15 --> Utf8 Class Initialized
INFO - 2023-04-25 13:11:15 --> URI Class Initialized
INFO - 2023-04-25 13:11:15 --> Router Class Initialized
INFO - 2023-04-25 13:11:15 --> Output Class Initialized
INFO - 2023-04-25 13:11:15 --> Security Class Initialized
DEBUG - 2023-04-25 13:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:11:15 --> Input Class Initialized
INFO - 2023-04-25 13:11:15 --> Language Class Initialized
INFO - 2023-04-25 13:11:15 --> Language Class Initialized
INFO - 2023-04-25 13:11:15 --> Config Class Initialized
INFO - 2023-04-25 13:11:15 --> Loader Class Initialized
INFO - 2023-04-25 13:11:15 --> Helper loaded: url_helper
INFO - 2023-04-25 13:11:15 --> Helper loaded: file_helper
INFO - 2023-04-25 13:11:15 --> Helper loaded: form_helper
INFO - 2023-04-25 13:11:15 --> Helper loaded: my_helper
INFO - 2023-04-25 13:11:15 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:11:15 --> Controller Class Initialized
DEBUG - 2023-04-25 13:11:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-04-25 13:11:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-25 13:11:15 --> Final output sent to browser
DEBUG - 2023-04-25 13:11:15 --> Total execution time: 0.0461
INFO - 2023-04-25 13:11:28 --> Config Class Initialized
INFO - 2023-04-25 13:11:28 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:11:28 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:11:28 --> Utf8 Class Initialized
INFO - 2023-04-25 13:11:28 --> URI Class Initialized
INFO - 2023-04-25 13:11:28 --> Router Class Initialized
INFO - 2023-04-25 13:11:28 --> Output Class Initialized
INFO - 2023-04-25 13:11:28 --> Security Class Initialized
DEBUG - 2023-04-25 13:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:11:28 --> Input Class Initialized
INFO - 2023-04-25 13:11:28 --> Language Class Initialized
INFO - 2023-04-25 13:11:28 --> Language Class Initialized
INFO - 2023-04-25 13:11:28 --> Config Class Initialized
INFO - 2023-04-25 13:11:28 --> Loader Class Initialized
INFO - 2023-04-25 13:11:28 --> Helper loaded: url_helper
INFO - 2023-04-25 13:11:28 --> Helper loaded: file_helper
INFO - 2023-04-25 13:11:28 --> Helper loaded: form_helper
INFO - 2023-04-25 13:11:28 --> Helper loaded: my_helper
INFO - 2023-04-25 13:11:28 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:11:28 --> Controller Class Initialized
INFO - 2023-04-25 13:11:28 --> Helper loaded: cookie_helper
INFO - 2023-04-25 13:11:28 --> Final output sent to browser
DEBUG - 2023-04-25 13:11:28 --> Total execution time: 0.0617
INFO - 2023-04-25 13:11:28 --> Config Class Initialized
INFO - 2023-04-25 13:11:28 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:11:28 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:11:28 --> Utf8 Class Initialized
INFO - 2023-04-25 13:11:28 --> URI Class Initialized
INFO - 2023-04-25 13:11:28 --> Router Class Initialized
INFO - 2023-04-25 13:11:28 --> Output Class Initialized
INFO - 2023-04-25 13:11:28 --> Security Class Initialized
DEBUG - 2023-04-25 13:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:11:28 --> Input Class Initialized
INFO - 2023-04-25 13:11:28 --> Language Class Initialized
INFO - 2023-04-25 13:11:28 --> Language Class Initialized
INFO - 2023-04-25 13:11:28 --> Config Class Initialized
INFO - 2023-04-25 13:11:28 --> Loader Class Initialized
INFO - 2023-04-25 13:11:28 --> Helper loaded: url_helper
INFO - 2023-04-25 13:11:28 --> Helper loaded: file_helper
INFO - 2023-04-25 13:11:28 --> Helper loaded: form_helper
INFO - 2023-04-25 13:11:28 --> Helper loaded: my_helper
INFO - 2023-04-25 13:11:28 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:11:28 --> Controller Class Initialized
DEBUG - 2023-04-25 13:11:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-04-25 13:11:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-25 13:11:28 --> Final output sent to browser
DEBUG - 2023-04-25 13:11:28 --> Total execution time: 0.0639
INFO - 2023-04-25 13:11:30 --> Config Class Initialized
INFO - 2023-04-25 13:11:30 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:11:30 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:11:30 --> Utf8 Class Initialized
INFO - 2023-04-25 13:11:30 --> URI Class Initialized
INFO - 2023-04-25 13:11:30 --> Router Class Initialized
INFO - 2023-04-25 13:11:30 --> Output Class Initialized
INFO - 2023-04-25 13:11:30 --> Security Class Initialized
DEBUG - 2023-04-25 13:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:11:30 --> Input Class Initialized
INFO - 2023-04-25 13:11:30 --> Language Class Initialized
INFO - 2023-04-25 13:11:30 --> Language Class Initialized
INFO - 2023-04-25 13:11:30 --> Config Class Initialized
INFO - 2023-04-25 13:11:30 --> Loader Class Initialized
INFO - 2023-04-25 13:11:30 --> Helper loaded: url_helper
INFO - 2023-04-25 13:11:30 --> Helper loaded: file_helper
INFO - 2023-04-25 13:11:30 --> Helper loaded: form_helper
INFO - 2023-04-25 13:11:30 --> Helper loaded: my_helper
INFO - 2023-04-25 13:11:30 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:11:30 --> Controller Class Initialized
DEBUG - 2023-04-25 13:11:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/list.php
DEBUG - 2023-04-25 13:11:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-25 13:11:30 --> Final output sent to browser
DEBUG - 2023-04-25 13:11:30 --> Total execution time: 0.0527
INFO - 2023-04-25 13:11:30 --> Config Class Initialized
INFO - 2023-04-25 13:11:30 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:11:30 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:11:30 --> Utf8 Class Initialized
INFO - 2023-04-25 13:11:30 --> URI Class Initialized
INFO - 2023-04-25 13:11:30 --> Router Class Initialized
INFO - 2023-04-25 13:11:30 --> Output Class Initialized
INFO - 2023-04-25 13:11:30 --> Security Class Initialized
DEBUG - 2023-04-25 13:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:11:30 --> Input Class Initialized
INFO - 2023-04-25 13:11:30 --> Language Class Initialized
INFO - 2023-04-25 13:11:30 --> Language Class Initialized
INFO - 2023-04-25 13:11:30 --> Config Class Initialized
INFO - 2023-04-25 13:11:30 --> Loader Class Initialized
INFO - 2023-04-25 13:11:30 --> Helper loaded: url_helper
INFO - 2023-04-25 13:11:30 --> Helper loaded: file_helper
INFO - 2023-04-25 13:11:30 --> Helper loaded: form_helper
INFO - 2023-04-25 13:11:30 --> Helper loaded: my_helper
INFO - 2023-04-25 13:11:30 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:11:30 --> Controller Class Initialized
INFO - 2023-04-25 13:11:45 --> Config Class Initialized
INFO - 2023-04-25 13:11:45 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:11:45 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:11:45 --> Utf8 Class Initialized
INFO - 2023-04-25 13:11:45 --> URI Class Initialized
DEBUG - 2023-04-25 13:11:45 --> No URI present. Default controller set.
INFO - 2023-04-25 13:11:45 --> Router Class Initialized
INFO - 2023-04-25 13:11:45 --> Output Class Initialized
INFO - 2023-04-25 13:11:45 --> Security Class Initialized
DEBUG - 2023-04-25 13:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:11:45 --> Input Class Initialized
INFO - 2023-04-25 13:11:45 --> Language Class Initialized
INFO - 2023-04-25 13:11:45 --> Language Class Initialized
INFO - 2023-04-25 13:11:45 --> Config Class Initialized
INFO - 2023-04-25 13:11:45 --> Loader Class Initialized
INFO - 2023-04-25 13:11:45 --> Helper loaded: url_helper
INFO - 2023-04-25 13:11:45 --> Helper loaded: file_helper
INFO - 2023-04-25 13:11:45 --> Helper loaded: form_helper
INFO - 2023-04-25 13:11:45 --> Helper loaded: my_helper
INFO - 2023-04-25 13:11:45 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:11:45 --> Controller Class Initialized
DEBUG - 2023-04-25 13:11:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-04-25 13:11:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-25 13:11:45 --> Final output sent to browser
DEBUG - 2023-04-25 13:11:45 --> Total execution time: 0.0606
INFO - 2023-04-25 13:11:51 --> Config Class Initialized
INFO - 2023-04-25 13:11:51 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:11:51 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:11:51 --> Utf8 Class Initialized
INFO - 2023-04-25 13:11:51 --> URI Class Initialized
INFO - 2023-04-25 13:11:51 --> Router Class Initialized
INFO - 2023-04-25 13:11:51 --> Output Class Initialized
INFO - 2023-04-25 13:11:51 --> Security Class Initialized
DEBUG - 2023-04-25 13:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:11:51 --> Input Class Initialized
INFO - 2023-04-25 13:11:51 --> Language Class Initialized
INFO - 2023-04-25 13:11:51 --> Language Class Initialized
INFO - 2023-04-25 13:11:51 --> Config Class Initialized
INFO - 2023-04-25 13:11:51 --> Loader Class Initialized
INFO - 2023-04-25 13:11:51 --> Helper loaded: url_helper
INFO - 2023-04-25 13:11:51 --> Helper loaded: file_helper
INFO - 2023-04-25 13:11:51 --> Helper loaded: form_helper
INFO - 2023-04-25 13:11:51 --> Helper loaded: my_helper
INFO - 2023-04-25 13:11:51 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:11:51 --> Controller Class Initialized
DEBUG - 2023-04-25 13:11:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_ekstra/views/list.php
DEBUG - 2023-04-25 13:11:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-25 13:11:51 --> Final output sent to browser
DEBUG - 2023-04-25 13:11:51 --> Total execution time: 0.0698
INFO - 2023-04-25 13:11:51 --> Config Class Initialized
INFO - 2023-04-25 13:11:51 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:11:51 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:11:51 --> Utf8 Class Initialized
INFO - 2023-04-25 13:11:51 --> URI Class Initialized
INFO - 2023-04-25 13:11:51 --> Router Class Initialized
INFO - 2023-04-25 13:11:51 --> Output Class Initialized
INFO - 2023-04-25 13:11:51 --> Security Class Initialized
DEBUG - 2023-04-25 13:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:11:51 --> Input Class Initialized
INFO - 2023-04-25 13:11:51 --> Language Class Initialized
INFO - 2023-04-25 13:11:51 --> Language Class Initialized
INFO - 2023-04-25 13:11:51 --> Config Class Initialized
INFO - 2023-04-25 13:11:51 --> Loader Class Initialized
INFO - 2023-04-25 13:11:51 --> Helper loaded: url_helper
INFO - 2023-04-25 13:11:51 --> Helper loaded: file_helper
INFO - 2023-04-25 13:11:51 --> Helper loaded: form_helper
INFO - 2023-04-25 13:11:51 --> Helper loaded: my_helper
INFO - 2023-04-25 13:11:51 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:11:51 --> Controller Class Initialized
INFO - 2023-04-25 13:12:07 --> Config Class Initialized
INFO - 2023-04-25 13:12:07 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:12:07 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:12:07 --> Utf8 Class Initialized
INFO - 2023-04-25 13:12:07 --> URI Class Initialized
INFO - 2023-04-25 13:12:07 --> Router Class Initialized
INFO - 2023-04-25 13:12:07 --> Output Class Initialized
INFO - 2023-04-25 13:12:07 --> Security Class Initialized
DEBUG - 2023-04-25 13:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:12:07 --> Input Class Initialized
INFO - 2023-04-25 13:12:07 --> Language Class Initialized
INFO - 2023-04-25 13:12:07 --> Language Class Initialized
INFO - 2023-04-25 13:12:07 --> Config Class Initialized
INFO - 2023-04-25 13:12:07 --> Loader Class Initialized
INFO - 2023-04-25 13:12:07 --> Helper loaded: url_helper
INFO - 2023-04-25 13:12:07 --> Helper loaded: file_helper
INFO - 2023-04-25 13:12:07 --> Helper loaded: form_helper
INFO - 2023-04-25 13:12:07 --> Helper loaded: my_helper
INFO - 2023-04-25 13:12:07 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:12:07 --> Controller Class Initialized
DEBUG - 2023-04-25 13:12:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/list.php
DEBUG - 2023-04-25 13:12:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-25 13:12:07 --> Final output sent to browser
DEBUG - 2023-04-25 13:12:07 --> Total execution time: 0.0751
INFO - 2023-04-25 13:12:07 --> Config Class Initialized
INFO - 2023-04-25 13:12:07 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:12:07 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:12:07 --> Utf8 Class Initialized
INFO - 2023-04-25 13:12:07 --> URI Class Initialized
INFO - 2023-04-25 13:12:07 --> Router Class Initialized
INFO - 2023-04-25 13:12:07 --> Output Class Initialized
INFO - 2023-04-25 13:12:07 --> Security Class Initialized
DEBUG - 2023-04-25 13:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:12:07 --> Input Class Initialized
INFO - 2023-04-25 13:12:07 --> Language Class Initialized
INFO - 2023-04-25 13:12:07 --> Language Class Initialized
INFO - 2023-04-25 13:12:07 --> Config Class Initialized
INFO - 2023-04-25 13:12:07 --> Loader Class Initialized
INFO - 2023-04-25 13:12:07 --> Helper loaded: url_helper
INFO - 2023-04-25 13:12:07 --> Helper loaded: file_helper
INFO - 2023-04-25 13:12:07 --> Helper loaded: form_helper
INFO - 2023-04-25 13:12:07 --> Helper loaded: my_helper
INFO - 2023-04-25 13:12:07 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:12:07 --> Controller Class Initialized
INFO - 2023-04-25 13:12:15 --> Config Class Initialized
INFO - 2023-04-25 13:12:15 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:12:15 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:12:15 --> Utf8 Class Initialized
INFO - 2023-04-25 13:12:15 --> URI Class Initialized
INFO - 2023-04-25 13:12:15 --> Router Class Initialized
INFO - 2023-04-25 13:12:15 --> Output Class Initialized
INFO - 2023-04-25 13:12:15 --> Security Class Initialized
DEBUG - 2023-04-25 13:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:12:15 --> Input Class Initialized
INFO - 2023-04-25 13:12:15 --> Language Class Initialized
INFO - 2023-04-25 13:12:15 --> Language Class Initialized
INFO - 2023-04-25 13:12:15 --> Config Class Initialized
INFO - 2023-04-25 13:12:15 --> Loader Class Initialized
INFO - 2023-04-25 13:12:15 --> Helper loaded: url_helper
INFO - 2023-04-25 13:12:15 --> Helper loaded: file_helper
INFO - 2023-04-25 13:12:15 --> Helper loaded: form_helper
INFO - 2023-04-25 13:12:15 --> Helper loaded: my_helper
INFO - 2023-04-25 13:12:15 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:12:15 --> Controller Class Initialized
DEBUG - 2023-04-25 13:12:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/backup_db/views/list.php
DEBUG - 2023-04-25 13:12:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-25 13:12:15 --> Final output sent to browser
DEBUG - 2023-04-25 13:12:15 --> Total execution time: 0.0720
INFO - 2023-04-25 13:12:15 --> Config Class Initialized
INFO - 2023-04-25 13:12:15 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:12:15 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:12:15 --> Utf8 Class Initialized
INFO - 2023-04-25 13:12:15 --> URI Class Initialized
INFO - 2023-04-25 13:12:15 --> Router Class Initialized
INFO - 2023-04-25 13:12:15 --> Output Class Initialized
INFO - 2023-04-25 13:12:15 --> Security Class Initialized
DEBUG - 2023-04-25 13:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:12:15 --> Input Class Initialized
INFO - 2023-04-25 13:12:15 --> Language Class Initialized
INFO - 2023-04-25 13:12:15 --> Language Class Initialized
INFO - 2023-04-25 13:12:15 --> Config Class Initialized
INFO - 2023-04-25 13:12:15 --> Loader Class Initialized
INFO - 2023-04-25 13:12:15 --> Helper loaded: url_helper
INFO - 2023-04-25 13:12:15 --> Helper loaded: file_helper
INFO - 2023-04-25 13:12:15 --> Helper loaded: form_helper
INFO - 2023-04-25 13:12:15 --> Helper loaded: my_helper
INFO - 2023-04-25 13:12:15 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:12:15 --> Controller Class Initialized
INFO - 2023-04-25 13:12:19 --> Config Class Initialized
INFO - 2023-04-25 13:12:19 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:12:19 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:12:19 --> Utf8 Class Initialized
INFO - 2023-04-25 13:12:19 --> URI Class Initialized
DEBUG - 2023-04-25 13:12:19 --> No URI present. Default controller set.
INFO - 2023-04-25 13:12:19 --> Router Class Initialized
INFO - 2023-04-25 13:12:19 --> Output Class Initialized
INFO - 2023-04-25 13:12:19 --> Security Class Initialized
DEBUG - 2023-04-25 13:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:12:19 --> Input Class Initialized
INFO - 2023-04-25 13:12:19 --> Language Class Initialized
INFO - 2023-04-25 13:12:19 --> Language Class Initialized
INFO - 2023-04-25 13:12:19 --> Config Class Initialized
INFO - 2023-04-25 13:12:19 --> Loader Class Initialized
INFO - 2023-04-25 13:12:19 --> Helper loaded: url_helper
INFO - 2023-04-25 13:12:19 --> Helper loaded: file_helper
INFO - 2023-04-25 13:12:19 --> Helper loaded: form_helper
INFO - 2023-04-25 13:12:19 --> Helper loaded: my_helper
INFO - 2023-04-25 13:12:19 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:12:19 --> Controller Class Initialized
DEBUG - 2023-04-25 13:12:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-04-25 13:12:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-25 13:12:19 --> Final output sent to browser
DEBUG - 2023-04-25 13:12:19 --> Total execution time: 0.0584
INFO - 2023-04-25 13:27:38 --> Config Class Initialized
INFO - 2023-04-25 13:27:38 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:27:38 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:27:38 --> Utf8 Class Initialized
INFO - 2023-04-25 13:27:38 --> URI Class Initialized
INFO - 2023-04-25 13:27:38 --> Router Class Initialized
INFO - 2023-04-25 13:27:38 --> Output Class Initialized
INFO - 2023-04-25 13:27:38 --> Security Class Initialized
DEBUG - 2023-04-25 13:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:27:38 --> Input Class Initialized
INFO - 2023-04-25 13:27:38 --> Language Class Initialized
INFO - 2023-04-25 13:27:38 --> Language Class Initialized
INFO - 2023-04-25 13:27:38 --> Config Class Initialized
INFO - 2023-04-25 13:27:38 --> Loader Class Initialized
INFO - 2023-04-25 13:27:38 --> Helper loaded: url_helper
INFO - 2023-04-25 13:27:38 --> Helper loaded: file_helper
INFO - 2023-04-25 13:27:38 --> Helper loaded: form_helper
INFO - 2023-04-25 13:27:38 --> Helper loaded: my_helper
INFO - 2023-04-25 13:27:38 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:27:38 --> Controller Class Initialized
INFO - 2023-04-25 13:27:38 --> Helper loaded: cookie_helper
INFO - 2023-04-25 13:27:38 --> Config Class Initialized
INFO - 2023-04-25 13:27:38 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:27:38 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:27:38 --> Utf8 Class Initialized
INFO - 2023-04-25 13:27:38 --> URI Class Initialized
INFO - 2023-04-25 13:27:38 --> Router Class Initialized
INFO - 2023-04-25 13:27:38 --> Output Class Initialized
INFO - 2023-04-25 13:27:38 --> Security Class Initialized
DEBUG - 2023-04-25 13:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:27:38 --> Input Class Initialized
INFO - 2023-04-25 13:27:38 --> Language Class Initialized
INFO - 2023-04-25 13:27:38 --> Language Class Initialized
INFO - 2023-04-25 13:27:38 --> Config Class Initialized
INFO - 2023-04-25 13:27:38 --> Loader Class Initialized
INFO - 2023-04-25 13:27:38 --> Helper loaded: url_helper
INFO - 2023-04-25 13:27:38 --> Helper loaded: file_helper
INFO - 2023-04-25 13:27:38 --> Helper loaded: form_helper
INFO - 2023-04-25 13:27:38 --> Helper loaded: my_helper
INFO - 2023-04-25 13:27:38 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:27:38 --> Controller Class Initialized
INFO - 2023-04-25 13:27:38 --> Config Class Initialized
INFO - 2023-04-25 13:27:38 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:27:38 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:27:38 --> Utf8 Class Initialized
INFO - 2023-04-25 13:27:38 --> URI Class Initialized
INFO - 2023-04-25 13:27:38 --> Router Class Initialized
INFO - 2023-04-25 13:27:38 --> Output Class Initialized
INFO - 2023-04-25 13:27:38 --> Security Class Initialized
DEBUG - 2023-04-25 13:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:27:38 --> Input Class Initialized
INFO - 2023-04-25 13:27:38 --> Language Class Initialized
INFO - 2023-04-25 13:27:38 --> Language Class Initialized
INFO - 2023-04-25 13:27:38 --> Config Class Initialized
INFO - 2023-04-25 13:27:38 --> Loader Class Initialized
INFO - 2023-04-25 13:27:38 --> Helper loaded: url_helper
INFO - 2023-04-25 13:27:38 --> Helper loaded: file_helper
INFO - 2023-04-25 13:27:38 --> Helper loaded: form_helper
INFO - 2023-04-25 13:27:38 --> Helper loaded: my_helper
INFO - 2023-04-25 13:27:38 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:27:38 --> Controller Class Initialized
DEBUG - 2023-04-25 13:27:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-04-25 13:27:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-25 13:27:38 --> Final output sent to browser
DEBUG - 2023-04-25 13:27:38 --> Total execution time: 0.0374
INFO - 2023-04-25 13:27:43 --> Config Class Initialized
INFO - 2023-04-25 13:27:43 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:27:43 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:27:43 --> Utf8 Class Initialized
INFO - 2023-04-25 13:27:43 --> URI Class Initialized
INFO - 2023-04-25 13:27:43 --> Router Class Initialized
INFO - 2023-04-25 13:27:43 --> Output Class Initialized
INFO - 2023-04-25 13:27:43 --> Security Class Initialized
DEBUG - 2023-04-25 13:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:27:43 --> Input Class Initialized
INFO - 2023-04-25 13:27:43 --> Language Class Initialized
INFO - 2023-04-25 13:27:43 --> Language Class Initialized
INFO - 2023-04-25 13:27:43 --> Config Class Initialized
INFO - 2023-04-25 13:27:43 --> Loader Class Initialized
INFO - 2023-04-25 13:27:43 --> Helper loaded: url_helper
INFO - 2023-04-25 13:27:43 --> Helper loaded: file_helper
INFO - 2023-04-25 13:27:43 --> Helper loaded: form_helper
INFO - 2023-04-25 13:27:43 --> Helper loaded: my_helper
INFO - 2023-04-25 13:27:43 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:27:43 --> Controller Class Initialized
INFO - 2023-04-25 13:27:43 --> Helper loaded: cookie_helper
INFO - 2023-04-25 13:27:43 --> Final output sent to browser
DEBUG - 2023-04-25 13:27:43 --> Total execution time: 0.0467
INFO - 2023-04-25 13:27:43 --> Config Class Initialized
INFO - 2023-04-25 13:27:43 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:27:43 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:27:43 --> Utf8 Class Initialized
INFO - 2023-04-25 13:27:43 --> URI Class Initialized
INFO - 2023-04-25 13:27:43 --> Router Class Initialized
INFO - 2023-04-25 13:27:43 --> Output Class Initialized
INFO - 2023-04-25 13:27:43 --> Security Class Initialized
DEBUG - 2023-04-25 13:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:27:43 --> Input Class Initialized
INFO - 2023-04-25 13:27:43 --> Language Class Initialized
INFO - 2023-04-25 13:27:43 --> Language Class Initialized
INFO - 2023-04-25 13:27:43 --> Config Class Initialized
INFO - 2023-04-25 13:27:43 --> Loader Class Initialized
INFO - 2023-04-25 13:27:43 --> Helper loaded: url_helper
INFO - 2023-04-25 13:27:43 --> Helper loaded: file_helper
INFO - 2023-04-25 13:27:43 --> Helper loaded: form_helper
INFO - 2023-04-25 13:27:43 --> Helper loaded: my_helper
INFO - 2023-04-25 13:27:43 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:27:43 --> Controller Class Initialized
DEBUG - 2023-04-25 13:27:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-04-25 13:27:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-25 13:27:43 --> Final output sent to browser
DEBUG - 2023-04-25 13:27:43 --> Total execution time: 0.0879
INFO - 2023-04-25 13:27:55 --> Config Class Initialized
INFO - 2023-04-25 13:27:55 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:27:55 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:27:55 --> Utf8 Class Initialized
INFO - 2023-04-25 13:27:55 --> URI Class Initialized
INFO - 2023-04-25 13:27:55 --> Router Class Initialized
INFO - 2023-04-25 13:27:55 --> Output Class Initialized
INFO - 2023-04-25 13:27:55 --> Security Class Initialized
DEBUG - 2023-04-25 13:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:27:55 --> Input Class Initialized
INFO - 2023-04-25 13:27:55 --> Language Class Initialized
INFO - 2023-04-25 13:27:55 --> Language Class Initialized
INFO - 2023-04-25 13:27:55 --> Config Class Initialized
INFO - 2023-04-25 13:27:55 --> Loader Class Initialized
INFO - 2023-04-25 13:27:55 --> Helper loaded: url_helper
INFO - 2023-04-25 13:27:55 --> Helper loaded: file_helper
INFO - 2023-04-25 13:27:55 --> Helper loaded: form_helper
INFO - 2023-04-25 13:27:55 --> Helper loaded: my_helper
INFO - 2023-04-25 13:27:55 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:27:55 --> Controller Class Initialized
DEBUG - 2023-04-25 13:27:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-04-25 13:27:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-25 13:27:55 --> Final output sent to browser
DEBUG - 2023-04-25 13:27:55 --> Total execution time: 0.0686
INFO - 2023-04-25 13:27:57 --> Config Class Initialized
INFO - 2023-04-25 13:27:57 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:27:57 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:27:57 --> Utf8 Class Initialized
INFO - 2023-04-25 13:27:57 --> URI Class Initialized
INFO - 2023-04-25 13:27:57 --> Router Class Initialized
INFO - 2023-04-25 13:27:57 --> Output Class Initialized
INFO - 2023-04-25 13:27:57 --> Security Class Initialized
DEBUG - 2023-04-25 13:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:27:57 --> Input Class Initialized
INFO - 2023-04-25 13:27:57 --> Language Class Initialized
INFO - 2023-04-25 13:27:57 --> Language Class Initialized
INFO - 2023-04-25 13:27:57 --> Config Class Initialized
INFO - 2023-04-25 13:27:57 --> Loader Class Initialized
INFO - 2023-04-25 13:27:57 --> Helper loaded: url_helper
INFO - 2023-04-25 13:27:57 --> Helper loaded: file_helper
INFO - 2023-04-25 13:27:57 --> Helper loaded: form_helper
INFO - 2023-04-25 13:27:57 --> Helper loaded: my_helper
INFO - 2023-04-25 13:27:57 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:27:57 --> Controller Class Initialized
DEBUG - 2023-04-25 13:27:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-04-25 13:27:59 --> Final output sent to browser
DEBUG - 2023-04-25 13:27:59 --> Total execution time: 2.5009
INFO - 2023-04-25 13:28:08 --> Config Class Initialized
INFO - 2023-04-25 13:28:08 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:28:08 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:28:08 --> Utf8 Class Initialized
INFO - 2023-04-25 13:28:08 --> URI Class Initialized
INFO - 2023-04-25 13:28:08 --> Router Class Initialized
INFO - 2023-04-25 13:28:08 --> Output Class Initialized
INFO - 2023-04-25 13:28:08 --> Security Class Initialized
DEBUG - 2023-04-25 13:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:28:08 --> Input Class Initialized
INFO - 2023-04-25 13:28:08 --> Language Class Initialized
INFO - 2023-04-25 13:28:08 --> Language Class Initialized
INFO - 2023-04-25 13:28:08 --> Config Class Initialized
INFO - 2023-04-25 13:28:08 --> Loader Class Initialized
INFO - 2023-04-25 13:28:08 --> Helper loaded: url_helper
INFO - 2023-04-25 13:28:08 --> Helper loaded: file_helper
INFO - 2023-04-25 13:28:08 --> Helper loaded: form_helper
INFO - 2023-04-25 13:28:08 --> Helper loaded: my_helper
INFO - 2023-04-25 13:28:08 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:28:08 --> Controller Class Initialized
DEBUG - 2023-04-25 13:28:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-25 13:28:09 --> Final output sent to browser
DEBUG - 2023-04-25 13:28:09 --> Total execution time: 0.6965
INFO - 2023-04-25 13:29:58 --> Config Class Initialized
INFO - 2023-04-25 13:29:58 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:29:58 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:29:58 --> Utf8 Class Initialized
INFO - 2023-04-25 13:29:58 --> URI Class Initialized
INFO - 2023-04-25 13:29:58 --> Router Class Initialized
INFO - 2023-04-25 13:29:58 --> Output Class Initialized
INFO - 2023-04-25 13:29:58 --> Security Class Initialized
DEBUG - 2023-04-25 13:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:29:58 --> Input Class Initialized
INFO - 2023-04-25 13:29:58 --> Language Class Initialized
INFO - 2023-04-25 13:29:58 --> Language Class Initialized
INFO - 2023-04-25 13:29:58 --> Config Class Initialized
INFO - 2023-04-25 13:29:58 --> Loader Class Initialized
INFO - 2023-04-25 13:29:58 --> Helper loaded: url_helper
INFO - 2023-04-25 13:29:58 --> Helper loaded: file_helper
INFO - 2023-04-25 13:29:58 --> Helper loaded: form_helper
INFO - 2023-04-25 13:29:58 --> Helper loaded: my_helper
INFO - 2023-04-25 13:29:58 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:29:58 --> Controller Class Initialized
DEBUG - 2023-04-25 13:29:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-25 13:29:59 --> Final output sent to browser
DEBUG - 2023-04-25 13:29:59 --> Total execution time: 0.8106
INFO - 2023-04-25 13:30:25 --> Config Class Initialized
INFO - 2023-04-25 13:30:25 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:30:25 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:30:25 --> Utf8 Class Initialized
INFO - 2023-04-25 13:30:25 --> URI Class Initialized
INFO - 2023-04-25 13:30:25 --> Router Class Initialized
INFO - 2023-04-25 13:30:25 --> Output Class Initialized
INFO - 2023-04-25 13:30:25 --> Security Class Initialized
DEBUG - 2023-04-25 13:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:30:25 --> Input Class Initialized
INFO - 2023-04-25 13:30:25 --> Language Class Initialized
INFO - 2023-04-25 13:30:25 --> Language Class Initialized
INFO - 2023-04-25 13:30:25 --> Config Class Initialized
INFO - 2023-04-25 13:30:25 --> Loader Class Initialized
INFO - 2023-04-25 13:30:25 --> Helper loaded: url_helper
INFO - 2023-04-25 13:30:25 --> Helper loaded: file_helper
INFO - 2023-04-25 13:30:25 --> Helper loaded: form_helper
INFO - 2023-04-25 13:30:25 --> Helper loaded: my_helper
INFO - 2023-04-25 13:30:25 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:30:25 --> Controller Class Initialized
DEBUG - 2023-04-25 13:30:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl1/views/list.php
DEBUG - 2023-04-25 13:30:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-25 13:30:25 --> Final output sent to browser
DEBUG - 2023-04-25 13:30:25 --> Total execution time: 0.1040
INFO - 2023-04-25 13:33:46 --> Config Class Initialized
INFO - 2023-04-25 13:33:46 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:33:46 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:33:46 --> Utf8 Class Initialized
INFO - 2023-04-25 13:33:46 --> URI Class Initialized
INFO - 2023-04-25 13:33:46 --> Router Class Initialized
INFO - 2023-04-25 13:33:46 --> Output Class Initialized
INFO - 2023-04-25 13:33:46 --> Security Class Initialized
DEBUG - 2023-04-25 13:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:33:46 --> Input Class Initialized
INFO - 2023-04-25 13:33:46 --> Language Class Initialized
INFO - 2023-04-25 13:33:46 --> Language Class Initialized
INFO - 2023-04-25 13:33:46 --> Config Class Initialized
INFO - 2023-04-25 13:33:46 --> Loader Class Initialized
INFO - 2023-04-25 13:33:46 --> Helper loaded: url_helper
INFO - 2023-04-25 13:33:46 --> Helper loaded: file_helper
INFO - 2023-04-25 13:33:46 --> Helper loaded: form_helper
INFO - 2023-04-25 13:33:46 --> Helper loaded: my_helper
INFO - 2023-04-25 13:33:46 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:33:46 --> Controller Class Initialized
DEBUG - 2023-04-25 13:33:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-25 13:33:47 --> Final output sent to browser
DEBUG - 2023-04-25 13:33:47 --> Total execution time: 0.8674
INFO - 2023-04-25 13:35:06 --> Config Class Initialized
INFO - 2023-04-25 13:35:06 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:35:06 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:35:06 --> Utf8 Class Initialized
INFO - 2023-04-25 13:35:06 --> URI Class Initialized
INFO - 2023-04-25 13:35:06 --> Router Class Initialized
INFO - 2023-04-25 13:35:06 --> Output Class Initialized
INFO - 2023-04-25 13:35:06 --> Security Class Initialized
DEBUG - 2023-04-25 13:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:35:06 --> Input Class Initialized
INFO - 2023-04-25 13:35:06 --> Language Class Initialized
INFO - 2023-04-25 13:35:06 --> Language Class Initialized
INFO - 2023-04-25 13:35:06 --> Config Class Initialized
INFO - 2023-04-25 13:35:06 --> Loader Class Initialized
INFO - 2023-04-25 13:35:06 --> Helper loaded: url_helper
INFO - 2023-04-25 13:35:06 --> Helper loaded: file_helper
INFO - 2023-04-25 13:35:06 --> Helper loaded: form_helper
INFO - 2023-04-25 13:35:06 --> Helper loaded: my_helper
INFO - 2023-04-25 13:35:06 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:35:06 --> Controller Class Initialized
DEBUG - 2023-04-25 13:35:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-25 13:35:07 --> Final output sent to browser
DEBUG - 2023-04-25 13:35:07 --> Total execution time: 0.8002
INFO - 2023-04-25 13:35:55 --> Config Class Initialized
INFO - 2023-04-25 13:35:55 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:35:55 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:35:55 --> Utf8 Class Initialized
INFO - 2023-04-25 13:35:55 --> URI Class Initialized
INFO - 2023-04-25 13:35:55 --> Router Class Initialized
INFO - 2023-04-25 13:35:55 --> Output Class Initialized
INFO - 2023-04-25 13:35:55 --> Security Class Initialized
DEBUG - 2023-04-25 13:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:35:55 --> Input Class Initialized
INFO - 2023-04-25 13:35:55 --> Language Class Initialized
INFO - 2023-04-25 13:35:55 --> Language Class Initialized
INFO - 2023-04-25 13:35:55 --> Config Class Initialized
INFO - 2023-04-25 13:35:55 --> Loader Class Initialized
INFO - 2023-04-25 13:35:55 --> Helper loaded: url_helper
INFO - 2023-04-25 13:35:55 --> Helper loaded: file_helper
INFO - 2023-04-25 13:35:55 --> Helper loaded: form_helper
INFO - 2023-04-25 13:35:55 --> Helper loaded: my_helper
INFO - 2023-04-25 13:35:55 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:35:55 --> Controller Class Initialized
DEBUG - 2023-04-25 13:35:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-25 13:35:56 --> Final output sent to browser
DEBUG - 2023-04-25 13:35:56 --> Total execution time: 0.9425
INFO - 2023-04-25 13:36:05 --> Config Class Initialized
INFO - 2023-04-25 13:36:05 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:36:05 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:36:05 --> Utf8 Class Initialized
INFO - 2023-04-25 13:36:05 --> URI Class Initialized
INFO - 2023-04-25 13:36:05 --> Router Class Initialized
INFO - 2023-04-25 13:36:05 --> Output Class Initialized
INFO - 2023-04-25 13:36:05 --> Security Class Initialized
DEBUG - 2023-04-25 13:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:36:05 --> Input Class Initialized
INFO - 2023-04-25 13:36:05 --> Language Class Initialized
INFO - 2023-04-25 13:36:05 --> Language Class Initialized
INFO - 2023-04-25 13:36:05 --> Config Class Initialized
INFO - 2023-04-25 13:36:05 --> Loader Class Initialized
INFO - 2023-04-25 13:36:05 --> Helper loaded: url_helper
INFO - 2023-04-25 13:36:05 --> Helper loaded: file_helper
INFO - 2023-04-25 13:36:05 --> Helper loaded: form_helper
INFO - 2023-04-25 13:36:05 --> Helper loaded: my_helper
INFO - 2023-04-25 13:36:05 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:36:05 --> Controller Class Initialized
DEBUG - 2023-04-25 13:36:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-25 13:36:06 --> Final output sent to browser
DEBUG - 2023-04-25 13:36:06 --> Total execution time: 0.8283
INFO - 2023-04-25 13:36:20 --> Config Class Initialized
INFO - 2023-04-25 13:36:20 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:36:20 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:36:20 --> Utf8 Class Initialized
INFO - 2023-04-25 13:36:20 --> URI Class Initialized
INFO - 2023-04-25 13:36:20 --> Router Class Initialized
INFO - 2023-04-25 13:36:20 --> Output Class Initialized
INFO - 2023-04-25 13:36:20 --> Security Class Initialized
DEBUG - 2023-04-25 13:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:36:20 --> Input Class Initialized
INFO - 2023-04-25 13:36:20 --> Language Class Initialized
INFO - 2023-04-25 13:36:20 --> Language Class Initialized
INFO - 2023-04-25 13:36:20 --> Config Class Initialized
INFO - 2023-04-25 13:36:20 --> Loader Class Initialized
INFO - 2023-04-25 13:36:20 --> Helper loaded: url_helper
INFO - 2023-04-25 13:36:20 --> Helper loaded: file_helper
INFO - 2023-04-25 13:36:20 --> Helper loaded: form_helper
INFO - 2023-04-25 13:36:20 --> Helper loaded: my_helper
INFO - 2023-04-25 13:36:20 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:36:20 --> Controller Class Initialized
DEBUG - 2023-04-25 13:36:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-25 13:36:21 --> Final output sent to browser
DEBUG - 2023-04-25 13:36:21 --> Total execution time: 0.8420
INFO - 2023-04-25 13:36:31 --> Config Class Initialized
INFO - 2023-04-25 13:36:31 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:36:31 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:36:31 --> Utf8 Class Initialized
INFO - 2023-04-25 13:36:31 --> URI Class Initialized
INFO - 2023-04-25 13:36:31 --> Router Class Initialized
INFO - 2023-04-25 13:36:31 --> Output Class Initialized
INFO - 2023-04-25 13:36:31 --> Security Class Initialized
DEBUG - 2023-04-25 13:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:36:31 --> Input Class Initialized
INFO - 2023-04-25 13:36:31 --> Language Class Initialized
INFO - 2023-04-25 13:36:31 --> Language Class Initialized
INFO - 2023-04-25 13:36:31 --> Config Class Initialized
INFO - 2023-04-25 13:36:31 --> Loader Class Initialized
INFO - 2023-04-25 13:36:31 --> Helper loaded: url_helper
INFO - 2023-04-25 13:36:31 --> Helper loaded: file_helper
INFO - 2023-04-25 13:36:31 --> Helper loaded: form_helper
INFO - 2023-04-25 13:36:31 --> Helper loaded: my_helper
INFO - 2023-04-25 13:36:31 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:36:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:36:31 --> Controller Class Initialized
DEBUG - 2023-04-25 13:36:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-25 13:36:32 --> Final output sent to browser
DEBUG - 2023-04-25 13:36:32 --> Total execution time: 0.7088
INFO - 2023-04-25 13:36:55 --> Config Class Initialized
INFO - 2023-04-25 13:36:55 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:36:55 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:36:55 --> Utf8 Class Initialized
INFO - 2023-04-25 13:36:55 --> URI Class Initialized
INFO - 2023-04-25 13:36:55 --> Router Class Initialized
INFO - 2023-04-25 13:36:55 --> Output Class Initialized
INFO - 2023-04-25 13:36:55 --> Security Class Initialized
DEBUG - 2023-04-25 13:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:36:55 --> Input Class Initialized
INFO - 2023-04-25 13:36:55 --> Language Class Initialized
INFO - 2023-04-25 13:36:55 --> Language Class Initialized
INFO - 2023-04-25 13:36:55 --> Config Class Initialized
INFO - 2023-04-25 13:36:55 --> Loader Class Initialized
INFO - 2023-04-25 13:36:55 --> Helper loaded: url_helper
INFO - 2023-04-25 13:36:55 --> Helper loaded: file_helper
INFO - 2023-04-25 13:36:55 --> Helper loaded: form_helper
INFO - 2023-04-25 13:36:55 --> Helper loaded: my_helper
INFO - 2023-04-25 13:36:55 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:36:55 --> Controller Class Initialized
DEBUG - 2023-04-25 13:36:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-25 13:36:56 --> Final output sent to browser
DEBUG - 2023-04-25 13:36:56 --> Total execution time: 0.8128
INFO - 2023-04-25 13:37:44 --> Config Class Initialized
INFO - 2023-04-25 13:37:44 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:37:44 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:37:44 --> Utf8 Class Initialized
INFO - 2023-04-25 13:37:44 --> URI Class Initialized
INFO - 2023-04-25 13:37:44 --> Router Class Initialized
INFO - 2023-04-25 13:37:44 --> Output Class Initialized
INFO - 2023-04-25 13:37:44 --> Security Class Initialized
DEBUG - 2023-04-25 13:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:37:44 --> Input Class Initialized
INFO - 2023-04-25 13:37:44 --> Language Class Initialized
INFO - 2023-04-25 13:37:44 --> Language Class Initialized
INFO - 2023-04-25 13:37:44 --> Config Class Initialized
INFO - 2023-04-25 13:37:44 --> Loader Class Initialized
INFO - 2023-04-25 13:37:44 --> Helper loaded: url_helper
INFO - 2023-04-25 13:37:44 --> Helper loaded: file_helper
INFO - 2023-04-25 13:37:44 --> Helper loaded: form_helper
INFO - 2023-04-25 13:37:44 --> Helper loaded: my_helper
INFO - 2023-04-25 13:37:44 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:37:44 --> Controller Class Initialized
DEBUG - 2023-04-25 13:37:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-25 13:37:45 --> Final output sent to browser
DEBUG - 2023-04-25 13:37:45 --> Total execution time: 0.8005
INFO - 2023-04-25 13:40:00 --> Config Class Initialized
INFO - 2023-04-25 13:40:00 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:40:00 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:40:00 --> Utf8 Class Initialized
INFO - 2023-04-25 13:40:00 --> URI Class Initialized
INFO - 2023-04-25 13:40:00 --> Router Class Initialized
INFO - 2023-04-25 13:40:00 --> Output Class Initialized
INFO - 2023-04-25 13:40:00 --> Security Class Initialized
DEBUG - 2023-04-25 13:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:40:00 --> Input Class Initialized
INFO - 2023-04-25 13:40:00 --> Language Class Initialized
INFO - 2023-04-25 13:40:00 --> Language Class Initialized
INFO - 2023-04-25 13:40:00 --> Config Class Initialized
INFO - 2023-04-25 13:40:00 --> Loader Class Initialized
INFO - 2023-04-25 13:40:00 --> Helper loaded: url_helper
INFO - 2023-04-25 13:40:00 --> Helper loaded: file_helper
INFO - 2023-04-25 13:40:00 --> Helper loaded: form_helper
INFO - 2023-04-25 13:40:00 --> Helper loaded: my_helper
INFO - 2023-04-25 13:40:00 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:40:00 --> Controller Class Initialized
DEBUG - 2023-04-25 13:40:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-25 13:40:01 --> Final output sent to browser
DEBUG - 2023-04-25 13:40:01 --> Total execution time: 0.7667
INFO - 2023-04-25 13:40:21 --> Config Class Initialized
INFO - 2023-04-25 13:40:21 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:40:21 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:40:21 --> Utf8 Class Initialized
INFO - 2023-04-25 13:40:21 --> URI Class Initialized
INFO - 2023-04-25 13:40:21 --> Router Class Initialized
INFO - 2023-04-25 13:40:21 --> Output Class Initialized
INFO - 2023-04-25 13:40:21 --> Security Class Initialized
DEBUG - 2023-04-25 13:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:40:21 --> Input Class Initialized
INFO - 2023-04-25 13:40:21 --> Language Class Initialized
INFO - 2023-04-25 13:40:21 --> Language Class Initialized
INFO - 2023-04-25 13:40:21 --> Config Class Initialized
INFO - 2023-04-25 13:40:21 --> Loader Class Initialized
INFO - 2023-04-25 13:40:21 --> Helper loaded: url_helper
INFO - 2023-04-25 13:40:21 --> Helper loaded: file_helper
INFO - 2023-04-25 13:40:21 --> Helper loaded: form_helper
INFO - 2023-04-25 13:40:21 --> Helper loaded: my_helper
INFO - 2023-04-25 13:40:21 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:40:21 --> Controller Class Initialized
DEBUG - 2023-04-25 13:40:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-25 13:40:22 --> Final output sent to browser
DEBUG - 2023-04-25 13:40:22 --> Total execution time: 0.7542
INFO - 2023-04-25 13:42:31 --> Config Class Initialized
INFO - 2023-04-25 13:42:31 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:42:31 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:42:31 --> Utf8 Class Initialized
INFO - 2023-04-25 13:42:31 --> URI Class Initialized
INFO - 2023-04-25 13:42:31 --> Router Class Initialized
INFO - 2023-04-25 13:42:31 --> Output Class Initialized
INFO - 2023-04-25 13:42:31 --> Security Class Initialized
DEBUG - 2023-04-25 13:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:42:31 --> Input Class Initialized
INFO - 2023-04-25 13:42:31 --> Language Class Initialized
INFO - 2023-04-25 13:42:31 --> Language Class Initialized
INFO - 2023-04-25 13:42:31 --> Config Class Initialized
INFO - 2023-04-25 13:42:31 --> Loader Class Initialized
INFO - 2023-04-25 13:42:31 --> Helper loaded: url_helper
INFO - 2023-04-25 13:42:31 --> Helper loaded: file_helper
INFO - 2023-04-25 13:42:31 --> Helper loaded: form_helper
INFO - 2023-04-25 13:42:31 --> Helper loaded: my_helper
INFO - 2023-04-25 13:42:31 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:42:31 --> Controller Class Initialized
DEBUG - 2023-04-25 13:42:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-25 13:42:32 --> Final output sent to browser
DEBUG - 2023-04-25 13:42:32 --> Total execution time: 0.7296
INFO - 2023-04-25 13:49:39 --> Config Class Initialized
INFO - 2023-04-25 13:49:39 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:49:39 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:49:39 --> Utf8 Class Initialized
INFO - 2023-04-25 13:49:39 --> URI Class Initialized
INFO - 2023-04-25 13:49:39 --> Router Class Initialized
INFO - 2023-04-25 13:49:39 --> Output Class Initialized
INFO - 2023-04-25 13:49:39 --> Security Class Initialized
DEBUG - 2023-04-25 13:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:49:39 --> Input Class Initialized
INFO - 2023-04-25 13:49:39 --> Language Class Initialized
INFO - 2023-04-25 13:49:39 --> Language Class Initialized
INFO - 2023-04-25 13:49:39 --> Config Class Initialized
INFO - 2023-04-25 13:49:39 --> Loader Class Initialized
INFO - 2023-04-25 13:49:39 --> Helper loaded: url_helper
INFO - 2023-04-25 13:49:39 --> Helper loaded: file_helper
INFO - 2023-04-25 13:49:39 --> Helper loaded: form_helper
INFO - 2023-04-25 13:49:39 --> Helper loaded: my_helper
INFO - 2023-04-25 13:49:39 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:49:39 --> Controller Class Initialized
DEBUG - 2023-04-25 13:49:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
ERROR - 2023-04-25 13:49:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5156
ERROR - 2023-04-25 13:49:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5158
ERROR - 2023-04-25 13:49:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5159
ERROR - 2023-04-25 13:49:39 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5159
ERROR - 2023-04-25 13:49:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5156
ERROR - 2023-04-25 13:49:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5158
ERROR - 2023-04-25 13:49:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5159
ERROR - 2023-04-25 13:49:39 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5159
ERROR - 2023-04-25 13:49:39 --> Severity: error --> Exception: TCPDF ERROR: Some data has already been output, can't send PDF file C:\xampp\htdocs\myraportk13\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 2950
ERROR - 2023-04-25 13:49:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\system\core\Common.php 570
INFO - 2023-04-25 13:49:58 --> Config Class Initialized
INFO - 2023-04-25 13:49:58 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:49:58 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:49:58 --> Utf8 Class Initialized
INFO - 2023-04-25 13:49:58 --> URI Class Initialized
INFO - 2023-04-25 13:49:58 --> Router Class Initialized
INFO - 2023-04-25 13:49:58 --> Output Class Initialized
INFO - 2023-04-25 13:49:58 --> Security Class Initialized
DEBUG - 2023-04-25 13:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:49:58 --> Input Class Initialized
INFO - 2023-04-25 13:49:58 --> Language Class Initialized
INFO - 2023-04-25 13:49:58 --> Language Class Initialized
INFO - 2023-04-25 13:49:58 --> Config Class Initialized
INFO - 2023-04-25 13:49:58 --> Loader Class Initialized
INFO - 2023-04-25 13:49:58 --> Helper loaded: url_helper
INFO - 2023-04-25 13:49:58 --> Helper loaded: file_helper
INFO - 2023-04-25 13:49:58 --> Helper loaded: form_helper
INFO - 2023-04-25 13:49:58 --> Helper loaded: my_helper
INFO - 2023-04-25 13:49:58 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:49:58 --> Controller Class Initialized
DEBUG - 2023-04-25 13:49:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
ERROR - 2023-04-25 13:49:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5156
ERROR - 2023-04-25 13:49:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5158
ERROR - 2023-04-25 13:49:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5159
ERROR - 2023-04-25 13:49:59 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5159
ERROR - 2023-04-25 13:49:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5156
ERROR - 2023-04-25 13:49:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5158
ERROR - 2023-04-25 13:49:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5159
ERROR - 2023-04-25 13:49:59 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5159
ERROR - 2023-04-25 13:49:59 --> Severity: error --> Exception: TCPDF ERROR: Some data has already been output, can't send PDF file C:\xampp\htdocs\myraportk13\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 2950
ERROR - 2023-04-25 13:49:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\system\core\Common.php 570
INFO - 2023-04-25 13:51:07 --> Config Class Initialized
INFO - 2023-04-25 13:51:07 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:51:07 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:51:07 --> Utf8 Class Initialized
INFO - 2023-04-25 13:51:07 --> URI Class Initialized
INFO - 2023-04-25 13:51:07 --> Router Class Initialized
INFO - 2023-04-25 13:51:07 --> Output Class Initialized
INFO - 2023-04-25 13:51:07 --> Security Class Initialized
DEBUG - 2023-04-25 13:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:51:07 --> Input Class Initialized
INFO - 2023-04-25 13:51:07 --> Language Class Initialized
INFO - 2023-04-25 13:51:07 --> Language Class Initialized
INFO - 2023-04-25 13:51:07 --> Config Class Initialized
INFO - 2023-04-25 13:51:07 --> Loader Class Initialized
INFO - 2023-04-25 13:51:07 --> Helper loaded: url_helper
INFO - 2023-04-25 13:51:07 --> Helper loaded: file_helper
INFO - 2023-04-25 13:51:07 --> Helper loaded: form_helper
INFO - 2023-04-25 13:51:07 --> Helper loaded: my_helper
INFO - 2023-04-25 13:51:07 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:51:07 --> Controller Class Initialized
DEBUG - 2023-04-25 13:51:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-25 13:51:08 --> Final output sent to browser
DEBUG - 2023-04-25 13:51:08 --> Total execution time: 0.6495
INFO - 2023-04-25 13:51:26 --> Config Class Initialized
INFO - 2023-04-25 13:51:26 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:51:26 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:51:26 --> Utf8 Class Initialized
INFO - 2023-04-25 13:51:26 --> URI Class Initialized
INFO - 2023-04-25 13:51:26 --> Router Class Initialized
INFO - 2023-04-25 13:51:26 --> Output Class Initialized
INFO - 2023-04-25 13:51:26 --> Security Class Initialized
DEBUG - 2023-04-25 13:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:51:26 --> Input Class Initialized
INFO - 2023-04-25 13:51:26 --> Language Class Initialized
INFO - 2023-04-25 13:51:26 --> Language Class Initialized
INFO - 2023-04-25 13:51:26 --> Config Class Initialized
INFO - 2023-04-25 13:51:26 --> Loader Class Initialized
INFO - 2023-04-25 13:51:26 --> Helper loaded: url_helper
INFO - 2023-04-25 13:51:26 --> Helper loaded: file_helper
INFO - 2023-04-25 13:51:26 --> Helper loaded: form_helper
INFO - 2023-04-25 13:51:26 --> Helper loaded: my_helper
INFO - 2023-04-25 13:51:26 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:51:27 --> Controller Class Initialized
DEBUG - 2023-04-25 13:51:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-04-25 13:51:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-25 13:51:27 --> Final output sent to browser
DEBUG - 2023-04-25 13:51:27 --> Total execution time: 0.1163
INFO - 2023-04-25 13:51:28 --> Config Class Initialized
INFO - 2023-04-25 13:51:28 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:51:28 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:51:28 --> Utf8 Class Initialized
INFO - 2023-04-25 13:51:28 --> URI Class Initialized
INFO - 2023-04-25 13:51:28 --> Router Class Initialized
INFO - 2023-04-25 13:51:28 --> Output Class Initialized
INFO - 2023-04-25 13:51:28 --> Security Class Initialized
DEBUG - 2023-04-25 13:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:51:28 --> Input Class Initialized
INFO - 2023-04-25 13:51:28 --> Language Class Initialized
INFO - 2023-04-25 13:51:28 --> Language Class Initialized
INFO - 2023-04-25 13:51:28 --> Config Class Initialized
INFO - 2023-04-25 13:51:28 --> Loader Class Initialized
INFO - 2023-04-25 13:51:28 --> Helper loaded: url_helper
INFO - 2023-04-25 13:51:28 --> Helper loaded: file_helper
INFO - 2023-04-25 13:51:28 --> Helper loaded: form_helper
INFO - 2023-04-25 13:51:28 --> Helper loaded: my_helper
INFO - 2023-04-25 13:51:28 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:51:28 --> Controller Class Initialized
DEBUG - 2023-04-25 13:51:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-25 13:51:30 --> Final output sent to browser
DEBUG - 2023-04-25 13:51:30 --> Total execution time: 1.5098
INFO - 2023-04-25 13:52:19 --> Config Class Initialized
INFO - 2023-04-25 13:52:19 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:52:19 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:52:19 --> Utf8 Class Initialized
INFO - 2023-04-25 13:52:19 --> URI Class Initialized
INFO - 2023-04-25 13:52:19 --> Router Class Initialized
INFO - 2023-04-25 13:52:19 --> Output Class Initialized
INFO - 2023-04-25 13:52:19 --> Security Class Initialized
DEBUG - 2023-04-25 13:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:52:19 --> Input Class Initialized
INFO - 2023-04-25 13:52:19 --> Language Class Initialized
INFO - 2023-04-25 13:52:19 --> Language Class Initialized
INFO - 2023-04-25 13:52:19 --> Config Class Initialized
INFO - 2023-04-25 13:52:19 --> Loader Class Initialized
INFO - 2023-04-25 13:52:19 --> Helper loaded: url_helper
INFO - 2023-04-25 13:52:19 --> Helper loaded: file_helper
INFO - 2023-04-25 13:52:19 --> Helper loaded: form_helper
INFO - 2023-04-25 13:52:19 --> Helper loaded: my_helper
INFO - 2023-04-25 13:52:19 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:52:19 --> Controller Class Initialized
DEBUG - 2023-04-25 13:52:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-04-25 13:52:21 --> Final output sent to browser
DEBUG - 2023-04-25 13:52:21 --> Total execution time: 1.4682
INFO - 2023-04-25 13:53:35 --> Config Class Initialized
INFO - 2023-04-25 13:53:35 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:53:35 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:53:35 --> Utf8 Class Initialized
INFO - 2023-04-25 13:53:35 --> URI Class Initialized
INFO - 2023-04-25 13:53:35 --> Router Class Initialized
INFO - 2023-04-25 13:53:35 --> Output Class Initialized
INFO - 2023-04-25 13:53:35 --> Security Class Initialized
DEBUG - 2023-04-25 13:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:53:35 --> Input Class Initialized
INFO - 2023-04-25 13:53:35 --> Language Class Initialized
INFO - 2023-04-25 13:53:35 --> Language Class Initialized
INFO - 2023-04-25 13:53:35 --> Config Class Initialized
INFO - 2023-04-25 13:53:35 --> Loader Class Initialized
INFO - 2023-04-25 13:53:35 --> Helper loaded: url_helper
INFO - 2023-04-25 13:53:35 --> Helper loaded: file_helper
INFO - 2023-04-25 13:53:35 --> Helper loaded: form_helper
INFO - 2023-04-25 13:53:35 --> Helper loaded: my_helper
INFO - 2023-04-25 13:53:35 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:53:35 --> Controller Class Initialized
DEBUG - 2023-04-25 13:53:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-25 13:53:35 --> Final output sent to browser
DEBUG - 2023-04-25 13:53:35 --> Total execution time: 0.7408
INFO - 2023-04-25 13:53:55 --> Config Class Initialized
INFO - 2023-04-25 13:53:55 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:53:55 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:53:55 --> Utf8 Class Initialized
INFO - 2023-04-25 13:53:55 --> URI Class Initialized
INFO - 2023-04-25 13:53:55 --> Router Class Initialized
INFO - 2023-04-25 13:53:55 --> Output Class Initialized
INFO - 2023-04-25 13:53:55 --> Security Class Initialized
DEBUG - 2023-04-25 13:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:53:55 --> Input Class Initialized
INFO - 2023-04-25 13:53:55 --> Language Class Initialized
INFO - 2023-04-25 13:53:55 --> Language Class Initialized
INFO - 2023-04-25 13:53:55 --> Config Class Initialized
INFO - 2023-04-25 13:53:55 --> Loader Class Initialized
INFO - 2023-04-25 13:53:55 --> Helper loaded: url_helper
INFO - 2023-04-25 13:53:55 --> Helper loaded: file_helper
INFO - 2023-04-25 13:53:55 --> Helper loaded: form_helper
INFO - 2023-04-25 13:53:55 --> Helper loaded: my_helper
INFO - 2023-04-25 13:53:55 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:53:55 --> Controller Class Initialized
DEBUG - 2023-04-25 13:53:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-25 13:53:56 --> Final output sent to browser
DEBUG - 2023-04-25 13:53:56 --> Total execution time: 0.7132
INFO - 2023-04-25 13:54:18 --> Config Class Initialized
INFO - 2023-04-25 13:54:18 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:54:18 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:54:18 --> Utf8 Class Initialized
INFO - 2023-04-25 13:54:18 --> URI Class Initialized
INFO - 2023-04-25 13:54:18 --> Router Class Initialized
INFO - 2023-04-25 13:54:18 --> Output Class Initialized
INFO - 2023-04-25 13:54:18 --> Security Class Initialized
DEBUG - 2023-04-25 13:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:54:18 --> Input Class Initialized
INFO - 2023-04-25 13:54:18 --> Language Class Initialized
INFO - 2023-04-25 13:54:18 --> Language Class Initialized
INFO - 2023-04-25 13:54:18 --> Config Class Initialized
INFO - 2023-04-25 13:54:18 --> Loader Class Initialized
INFO - 2023-04-25 13:54:18 --> Helper loaded: url_helper
INFO - 2023-04-25 13:54:18 --> Helper loaded: file_helper
INFO - 2023-04-25 13:54:18 --> Helper loaded: form_helper
INFO - 2023-04-25 13:54:18 --> Helper loaded: my_helper
INFO - 2023-04-25 13:54:18 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:54:18 --> Controller Class Initialized
DEBUG - 2023-04-25 13:54:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-25 13:54:19 --> Final output sent to browser
DEBUG - 2023-04-25 13:54:19 --> Total execution time: 0.7530
INFO - 2023-04-25 13:55:25 --> Config Class Initialized
INFO - 2023-04-25 13:55:25 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:55:25 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:55:25 --> Utf8 Class Initialized
INFO - 2023-04-25 13:55:25 --> URI Class Initialized
INFO - 2023-04-25 13:55:25 --> Router Class Initialized
INFO - 2023-04-25 13:55:25 --> Output Class Initialized
INFO - 2023-04-25 13:55:25 --> Security Class Initialized
DEBUG - 2023-04-25 13:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:55:25 --> Input Class Initialized
INFO - 2023-04-25 13:55:25 --> Language Class Initialized
INFO - 2023-04-25 13:55:25 --> Language Class Initialized
INFO - 2023-04-25 13:55:25 --> Config Class Initialized
INFO - 2023-04-25 13:55:25 --> Loader Class Initialized
INFO - 2023-04-25 13:55:25 --> Helper loaded: url_helper
INFO - 2023-04-25 13:55:25 --> Helper loaded: file_helper
INFO - 2023-04-25 13:55:25 --> Helper loaded: form_helper
INFO - 2023-04-25 13:55:25 --> Helper loaded: my_helper
INFO - 2023-04-25 13:55:25 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:55:25 --> Controller Class Initialized
DEBUG - 2023-04-25 13:55:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-25 13:55:25 --> Final output sent to browser
DEBUG - 2023-04-25 13:55:25 --> Total execution time: 0.6927
INFO - 2023-04-25 13:56:51 --> Config Class Initialized
INFO - 2023-04-25 13:56:51 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:56:51 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:56:51 --> Utf8 Class Initialized
INFO - 2023-04-25 13:56:51 --> URI Class Initialized
INFO - 2023-04-25 13:56:51 --> Router Class Initialized
INFO - 2023-04-25 13:56:51 --> Output Class Initialized
INFO - 2023-04-25 13:56:51 --> Security Class Initialized
DEBUG - 2023-04-25 13:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:56:51 --> Input Class Initialized
INFO - 2023-04-25 13:56:51 --> Language Class Initialized
INFO - 2023-04-25 13:56:51 --> Language Class Initialized
INFO - 2023-04-25 13:56:51 --> Config Class Initialized
INFO - 2023-04-25 13:56:51 --> Loader Class Initialized
INFO - 2023-04-25 13:56:51 --> Helper loaded: url_helper
INFO - 2023-04-25 13:56:51 --> Helper loaded: file_helper
INFO - 2023-04-25 13:56:51 --> Helper loaded: form_helper
INFO - 2023-04-25 13:56:51 --> Helper loaded: my_helper
INFO - 2023-04-25 13:56:51 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:56:51 --> Controller Class Initialized
DEBUG - 2023-04-25 13:56:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-25 13:56:51 --> Final output sent to browser
DEBUG - 2023-04-25 13:56:51 --> Total execution time: 0.7179
INFO - 2023-04-25 13:57:20 --> Config Class Initialized
INFO - 2023-04-25 13:57:20 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:57:20 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:57:20 --> Utf8 Class Initialized
INFO - 2023-04-25 13:57:20 --> URI Class Initialized
INFO - 2023-04-25 13:57:20 --> Router Class Initialized
INFO - 2023-04-25 13:57:20 --> Output Class Initialized
INFO - 2023-04-25 13:57:20 --> Security Class Initialized
DEBUG - 2023-04-25 13:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:57:20 --> Input Class Initialized
INFO - 2023-04-25 13:57:20 --> Language Class Initialized
INFO - 2023-04-25 13:57:20 --> Language Class Initialized
INFO - 2023-04-25 13:57:20 --> Config Class Initialized
INFO - 2023-04-25 13:57:20 --> Loader Class Initialized
INFO - 2023-04-25 13:57:20 --> Helper loaded: url_helper
INFO - 2023-04-25 13:57:20 --> Helper loaded: file_helper
INFO - 2023-04-25 13:57:20 --> Helper loaded: form_helper
INFO - 2023-04-25 13:57:20 --> Helper loaded: my_helper
INFO - 2023-04-25 13:57:20 --> Database Driver Class Initialized
DEBUG - 2023-04-25 13:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-25 13:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:57:20 --> Controller Class Initialized
DEBUG - 2023-04-25 13:57:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-25 13:57:21 --> Final output sent to browser
DEBUG - 2023-04-25 13:57:21 --> Total execution time: 0.7846
