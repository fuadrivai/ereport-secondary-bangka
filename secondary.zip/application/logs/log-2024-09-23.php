<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-23 10:04:47 --> Config Class Initialized
INFO - 2024-09-23 10:04:47 --> Hooks Class Initialized
DEBUG - 2024-09-23 10:04:47 --> UTF-8 Support Enabled
INFO - 2024-09-23 10:04:47 --> Utf8 Class Initialized
INFO - 2024-09-23 10:04:47 --> URI Class Initialized
INFO - 2024-09-23 10:04:47 --> Router Class Initialized
INFO - 2024-09-23 10:04:47 --> Output Class Initialized
INFO - 2024-09-23 10:04:47 --> Security Class Initialized
DEBUG - 2024-09-23 10:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-23 10:04:47 --> Input Class Initialized
INFO - 2024-09-23 10:04:47 --> Language Class Initialized
INFO - 2024-09-23 10:04:47 --> Language Class Initialized
INFO - 2024-09-23 10:04:47 --> Config Class Initialized
INFO - 2024-09-23 10:04:47 --> Loader Class Initialized
INFO - 2024-09-23 10:04:47 --> Helper loaded: url_helper
INFO - 2024-09-23 10:04:47 --> Helper loaded: file_helper
INFO - 2024-09-23 10:04:47 --> Helper loaded: form_helper
INFO - 2024-09-23 10:04:47 --> Helper loaded: my_helper
INFO - 2024-09-23 10:04:47 --> Database Driver Class Initialized
INFO - 2024-09-23 10:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-23 10:04:47 --> Controller Class Initialized
INFO - 2024-09-23 10:04:47 --> Helper loaded: cookie_helper
INFO - 2024-09-23 10:04:47 --> Final output sent to browser
DEBUG - 2024-09-23 10:04:47 --> Total execution time: 0.0677
INFO - 2024-09-23 10:04:47 --> Config Class Initialized
INFO - 2024-09-23 10:04:47 --> Hooks Class Initialized
DEBUG - 2024-09-23 10:04:47 --> UTF-8 Support Enabled
INFO - 2024-09-23 10:04:47 --> Utf8 Class Initialized
INFO - 2024-09-23 10:04:47 --> URI Class Initialized
INFO - 2024-09-23 10:04:47 --> Router Class Initialized
INFO - 2024-09-23 10:04:47 --> Output Class Initialized
INFO - 2024-09-23 10:04:47 --> Security Class Initialized
DEBUG - 2024-09-23 10:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-23 10:04:47 --> Input Class Initialized
INFO - 2024-09-23 10:04:47 --> Language Class Initialized
INFO - 2024-09-23 10:04:47 --> Language Class Initialized
INFO - 2024-09-23 10:04:47 --> Config Class Initialized
INFO - 2024-09-23 10:04:47 --> Loader Class Initialized
INFO - 2024-09-23 10:04:47 --> Helper loaded: url_helper
INFO - 2024-09-23 10:04:47 --> Helper loaded: file_helper
INFO - 2024-09-23 10:04:47 --> Helper loaded: form_helper
INFO - 2024-09-23 10:04:47 --> Helper loaded: my_helper
INFO - 2024-09-23 10:04:47 --> Database Driver Class Initialized
INFO - 2024-09-23 10:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-23 10:04:47 --> Controller Class Initialized
INFO - 2024-09-23 10:04:47 --> Helper loaded: cookie_helper
INFO - 2024-09-23 10:04:47 --> Config Class Initialized
INFO - 2024-09-23 10:04:47 --> Hooks Class Initialized
DEBUG - 2024-09-23 10:04:47 --> UTF-8 Support Enabled
INFO - 2024-09-23 10:04:47 --> Utf8 Class Initialized
INFO - 2024-09-23 10:04:47 --> URI Class Initialized
INFO - 2024-09-23 10:04:47 --> Router Class Initialized
INFO - 2024-09-23 10:04:47 --> Output Class Initialized
INFO - 2024-09-23 10:04:47 --> Security Class Initialized
DEBUG - 2024-09-23 10:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-23 10:04:47 --> Input Class Initialized
INFO - 2024-09-23 10:04:47 --> Language Class Initialized
INFO - 2024-09-23 10:04:47 --> Language Class Initialized
INFO - 2024-09-23 10:04:47 --> Config Class Initialized
INFO - 2024-09-23 10:04:47 --> Loader Class Initialized
INFO - 2024-09-23 10:04:47 --> Helper loaded: url_helper
INFO - 2024-09-23 10:04:47 --> Helper loaded: file_helper
INFO - 2024-09-23 10:04:47 --> Helper loaded: form_helper
INFO - 2024-09-23 10:04:47 --> Helper loaded: my_helper
INFO - 2024-09-23 10:04:47 --> Database Driver Class Initialized
INFO - 2024-09-23 10:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-23 10:04:47 --> Controller Class Initialized
DEBUG - 2024-09-23 10:04:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-23 10:04:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-23 10:04:47 --> Final output sent to browser
DEBUG - 2024-09-23 10:04:47 --> Total execution time: 0.0418
INFO - 2024-09-23 10:04:55 --> Config Class Initialized
INFO - 2024-09-23 10:04:55 --> Hooks Class Initialized
DEBUG - 2024-09-23 10:04:55 --> UTF-8 Support Enabled
INFO - 2024-09-23 10:04:55 --> Utf8 Class Initialized
INFO - 2024-09-23 10:04:55 --> URI Class Initialized
INFO - 2024-09-23 10:04:55 --> Router Class Initialized
INFO - 2024-09-23 10:04:55 --> Output Class Initialized
INFO - 2024-09-23 10:04:55 --> Security Class Initialized
DEBUG - 2024-09-23 10:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-23 10:04:55 --> Input Class Initialized
INFO - 2024-09-23 10:04:55 --> Language Class Initialized
INFO - 2024-09-23 10:04:55 --> Language Class Initialized
INFO - 2024-09-23 10:04:55 --> Config Class Initialized
INFO - 2024-09-23 10:04:55 --> Loader Class Initialized
INFO - 2024-09-23 10:04:55 --> Helper loaded: url_helper
INFO - 2024-09-23 10:04:55 --> Helper loaded: file_helper
INFO - 2024-09-23 10:04:55 --> Helper loaded: form_helper
INFO - 2024-09-23 10:04:55 --> Helper loaded: my_helper
INFO - 2024-09-23 10:04:55 --> Database Driver Class Initialized
INFO - 2024-09-23 10:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-23 10:04:55 --> Controller Class Initialized
ERROR - 2024-09-23 10:04:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-23 10:04:55 --> Severity: Notice --> Undefined variable: kkmx /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1493
ERROR - 2024-09-23 10:04:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-23 10:04:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-23 10:04:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-23 10:04:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-23 10:04:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-23 10:04:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-23 10:04:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-23 10:04:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-23 10:04:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-23 10:04:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-23 10:04:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-23 10:04:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-23 10:04:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-23 10:04:57 --> Final output sent to browser
DEBUG - 2024-09-23 10:04:57 --> Total execution time: 2.6388
INFO - 2024-09-23 10:05:12 --> Config Class Initialized
INFO - 2024-09-23 10:05:12 --> Hooks Class Initialized
DEBUG - 2024-09-23 10:05:12 --> UTF-8 Support Enabled
INFO - 2024-09-23 10:05:12 --> Utf8 Class Initialized
INFO - 2024-09-23 10:05:12 --> URI Class Initialized
DEBUG - 2024-09-23 10:05:12 --> No URI present. Default controller set.
INFO - 2024-09-23 10:05:12 --> Router Class Initialized
INFO - 2024-09-23 10:05:12 --> Output Class Initialized
INFO - 2024-09-23 10:05:12 --> Security Class Initialized
DEBUG - 2024-09-23 10:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-23 10:05:12 --> Input Class Initialized
INFO - 2024-09-23 10:05:12 --> Language Class Initialized
INFO - 2024-09-23 10:05:12 --> Language Class Initialized
INFO - 2024-09-23 10:05:12 --> Config Class Initialized
INFO - 2024-09-23 10:05:12 --> Loader Class Initialized
INFO - 2024-09-23 10:05:12 --> Helper loaded: url_helper
INFO - 2024-09-23 10:05:12 --> Helper loaded: file_helper
INFO - 2024-09-23 10:05:12 --> Helper loaded: form_helper
INFO - 2024-09-23 10:05:12 --> Helper loaded: my_helper
INFO - 2024-09-23 10:05:12 --> Database Driver Class Initialized
INFO - 2024-09-23 10:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-23 10:05:12 --> Controller Class Initialized
DEBUG - 2024-09-23 10:05:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-09-23 10:05:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-23 10:05:12 --> Final output sent to browser
DEBUG - 2024-09-23 10:05:12 --> Total execution time: 0.0385
INFO - 2024-09-23 12:06:04 --> Config Class Initialized
INFO - 2024-09-23 12:06:04 --> Hooks Class Initialized
DEBUG - 2024-09-23 12:06:04 --> UTF-8 Support Enabled
INFO - 2024-09-23 12:06:04 --> Utf8 Class Initialized
INFO - 2024-09-23 12:06:04 --> URI Class Initialized
INFO - 2024-09-23 12:06:04 --> Router Class Initialized
INFO - 2024-09-23 12:06:04 --> Output Class Initialized
INFO - 2024-09-23 12:06:04 --> Security Class Initialized
DEBUG - 2024-09-23 12:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-23 12:06:04 --> Input Class Initialized
INFO - 2024-09-23 12:06:04 --> Language Class Initialized
INFO - 2024-09-23 12:06:04 --> Language Class Initialized
INFO - 2024-09-23 12:06:04 --> Config Class Initialized
INFO - 2024-09-23 12:06:04 --> Loader Class Initialized
INFO - 2024-09-23 12:06:04 --> Helper loaded: url_helper
INFO - 2024-09-23 12:06:04 --> Helper loaded: file_helper
INFO - 2024-09-23 12:06:04 --> Helper loaded: form_helper
INFO - 2024-09-23 12:06:04 --> Helper loaded: my_helper
INFO - 2024-09-23 12:06:04 --> Database Driver Class Initialized
INFO - 2024-09-23 12:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-23 12:06:04 --> Controller Class Initialized
INFO - 2024-09-23 12:06:04 --> Helper loaded: cookie_helper
INFO - 2024-09-23 12:06:04 --> Final output sent to browser
DEBUG - 2024-09-23 12:06:04 --> Total execution time: 0.0545
INFO - 2024-09-23 12:06:04 --> Config Class Initialized
INFO - 2024-09-23 12:06:04 --> Hooks Class Initialized
DEBUG - 2024-09-23 12:06:04 --> UTF-8 Support Enabled
INFO - 2024-09-23 12:06:04 --> Utf8 Class Initialized
INFO - 2024-09-23 12:06:04 --> URI Class Initialized
INFO - 2024-09-23 12:06:04 --> Router Class Initialized
INFO - 2024-09-23 12:06:04 --> Output Class Initialized
INFO - 2024-09-23 12:06:04 --> Security Class Initialized
DEBUG - 2024-09-23 12:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-23 12:06:04 --> Input Class Initialized
INFO - 2024-09-23 12:06:04 --> Language Class Initialized
INFO - 2024-09-23 12:06:04 --> Language Class Initialized
INFO - 2024-09-23 12:06:04 --> Config Class Initialized
INFO - 2024-09-23 12:06:04 --> Loader Class Initialized
INFO - 2024-09-23 12:06:04 --> Helper loaded: url_helper
INFO - 2024-09-23 12:06:04 --> Helper loaded: file_helper
INFO - 2024-09-23 12:06:04 --> Helper loaded: form_helper
INFO - 2024-09-23 12:06:04 --> Helper loaded: my_helper
INFO - 2024-09-23 12:06:04 --> Database Driver Class Initialized
INFO - 2024-09-23 12:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-23 12:06:04 --> Controller Class Initialized
INFO - 2024-09-23 12:06:04 --> Helper loaded: cookie_helper
INFO - 2024-09-23 12:06:04 --> Config Class Initialized
INFO - 2024-09-23 12:06:04 --> Hooks Class Initialized
DEBUG - 2024-09-23 12:06:04 --> UTF-8 Support Enabled
INFO - 2024-09-23 12:06:04 --> Utf8 Class Initialized
INFO - 2024-09-23 12:06:04 --> URI Class Initialized
INFO - 2024-09-23 12:06:04 --> Router Class Initialized
INFO - 2024-09-23 12:06:04 --> Output Class Initialized
INFO - 2024-09-23 12:06:04 --> Security Class Initialized
DEBUG - 2024-09-23 12:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-23 12:06:04 --> Input Class Initialized
INFO - 2024-09-23 12:06:04 --> Language Class Initialized
INFO - 2024-09-23 12:06:04 --> Language Class Initialized
INFO - 2024-09-23 12:06:04 --> Config Class Initialized
INFO - 2024-09-23 12:06:04 --> Loader Class Initialized
INFO - 2024-09-23 12:06:04 --> Helper loaded: url_helper
INFO - 2024-09-23 12:06:04 --> Helper loaded: file_helper
INFO - 2024-09-23 12:06:04 --> Helper loaded: form_helper
INFO - 2024-09-23 12:06:04 --> Helper loaded: my_helper
INFO - 2024-09-23 12:06:04 --> Database Driver Class Initialized
INFO - 2024-09-23 12:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-23 12:06:04 --> Controller Class Initialized
DEBUG - 2024-09-23 12:06:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-23 12:06:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-23 12:06:04 --> Final output sent to browser
DEBUG - 2024-09-23 12:06:04 --> Total execution time: 0.0364
INFO - 2024-09-23 12:06:07 --> Config Class Initialized
INFO - 2024-09-23 12:06:07 --> Hooks Class Initialized
DEBUG - 2024-09-23 12:06:07 --> UTF-8 Support Enabled
INFO - 2024-09-23 12:06:07 --> Utf8 Class Initialized
INFO - 2024-09-23 12:06:07 --> URI Class Initialized
INFO - 2024-09-23 12:06:07 --> Router Class Initialized
INFO - 2024-09-23 12:06:07 --> Output Class Initialized
INFO - 2024-09-23 12:06:07 --> Security Class Initialized
DEBUG - 2024-09-23 12:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-23 12:06:07 --> Input Class Initialized
INFO - 2024-09-23 12:06:07 --> Language Class Initialized
INFO - 2024-09-23 12:06:07 --> Language Class Initialized
INFO - 2024-09-23 12:06:07 --> Config Class Initialized
INFO - 2024-09-23 12:06:07 --> Loader Class Initialized
INFO - 2024-09-23 12:06:07 --> Helper loaded: url_helper
INFO - 2024-09-23 12:06:07 --> Helper loaded: file_helper
INFO - 2024-09-23 12:06:07 --> Helper loaded: form_helper
INFO - 2024-09-23 12:06:07 --> Helper loaded: my_helper
INFO - 2024-09-23 12:06:07 --> Database Driver Class Initialized
INFO - 2024-09-23 12:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-23 12:06:07 --> Controller Class Initialized
DEBUG - 2024-09-23 12:06:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-09-23 12:06:10 --> Config Class Initialized
INFO - 2024-09-23 12:06:10 --> Hooks Class Initialized
DEBUG - 2024-09-23 12:06:10 --> UTF-8 Support Enabled
INFO - 2024-09-23 12:06:10 --> Utf8 Class Initialized
INFO - 2024-09-23 12:06:10 --> URI Class Initialized
INFO - 2024-09-23 12:06:10 --> Router Class Initialized
INFO - 2024-09-23 12:06:10 --> Output Class Initialized
INFO - 2024-09-23 12:06:10 --> Security Class Initialized
DEBUG - 2024-09-23 12:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-23 12:06:10 --> Input Class Initialized
INFO - 2024-09-23 12:06:10 --> Language Class Initialized
INFO - 2024-09-23 12:06:10 --> Language Class Initialized
INFO - 2024-09-23 12:06:10 --> Config Class Initialized
INFO - 2024-09-23 12:06:10 --> Loader Class Initialized
INFO - 2024-09-23 12:06:10 --> Helper loaded: url_helper
INFO - 2024-09-23 12:06:10 --> Helper loaded: file_helper
INFO - 2024-09-23 12:06:10 --> Helper loaded: form_helper
INFO - 2024-09-23 12:06:10 --> Helper loaded: my_helper
INFO - 2024-09-23 12:06:10 --> Database Driver Class Initialized
INFO - 2024-09-23 12:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-23 12:06:10 --> Controller Class Initialized
ERROR - 2024-09-23 12:06:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1797
ERROR - 2024-09-23 12:06:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1804
ERROR - 2024-09-23 12:06:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-09-23 12:06:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-09-23 12:06:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-09-23 12:06:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 86
ERROR - 2024-09-23 12:06:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-09-23 12:06:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-09-23 12:06:10 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-09-23 12:06:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-09-23 12:06:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-09-23 12:06:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-09-23 12:06:12 --> Config Class Initialized
INFO - 2024-09-23 12:06:12 --> Hooks Class Initialized
DEBUG - 2024-09-23 12:06:12 --> UTF-8 Support Enabled
INFO - 2024-09-23 12:06:12 --> Utf8 Class Initialized
INFO - 2024-09-23 12:06:12 --> URI Class Initialized
INFO - 2024-09-23 12:06:12 --> Router Class Initialized
INFO - 2024-09-23 12:06:12 --> Output Class Initialized
INFO - 2024-09-23 12:06:12 --> Security Class Initialized
DEBUG - 2024-09-23 12:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-23 12:06:12 --> Input Class Initialized
INFO - 2024-09-23 12:06:12 --> Language Class Initialized
INFO - 2024-09-23 12:06:12 --> Language Class Initialized
INFO - 2024-09-23 12:06:12 --> Config Class Initialized
INFO - 2024-09-23 12:06:12 --> Loader Class Initialized
INFO - 2024-09-23 12:06:12 --> Helper loaded: url_helper
INFO - 2024-09-23 12:06:12 --> Helper loaded: file_helper
INFO - 2024-09-23 12:06:12 --> Helper loaded: form_helper
INFO - 2024-09-23 12:06:12 --> Helper loaded: my_helper
INFO - 2024-09-23 12:06:12 --> Database Driver Class Initialized
INFO - 2024-09-23 12:06:13 --> Config Class Initialized
INFO - 2024-09-23 12:06:13 --> Hooks Class Initialized
DEBUG - 2024-09-23 12:06:13 --> UTF-8 Support Enabled
INFO - 2024-09-23 12:06:13 --> Utf8 Class Initialized
INFO - 2024-09-23 12:06:13 --> URI Class Initialized
INFO - 2024-09-23 12:06:13 --> Router Class Initialized
INFO - 2024-09-23 12:06:13 --> Output Class Initialized
INFO - 2024-09-23 12:06:13 --> Security Class Initialized
DEBUG - 2024-09-23 12:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-23 12:06:13 --> Input Class Initialized
INFO - 2024-09-23 12:06:13 --> Language Class Initialized
INFO - 2024-09-23 12:06:13 --> Language Class Initialized
INFO - 2024-09-23 12:06:13 --> Config Class Initialized
INFO - 2024-09-23 12:06:13 --> Loader Class Initialized
INFO - 2024-09-23 12:06:13 --> Helper loaded: url_helper
INFO - 2024-09-23 12:06:13 --> Helper loaded: file_helper
INFO - 2024-09-23 12:06:13 --> Helper loaded: form_helper
INFO - 2024-09-23 12:06:13 --> Helper loaded: my_helper
INFO - 2024-09-23 12:06:13 --> Database Driver Class Initialized
ERROR - 2024-09-23 12:06:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
ERROR - 2024-09-23 12:06:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
INFO - 2024-09-23 12:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-23 12:06:14 --> Controller Class Initialized
ERROR - 2024-09-23 12:06:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2591
ERROR - 2024-09-23 12:06:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3156
ERROR - 2024-09-23 12:06:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3194
ERROR - 2024-09-23 12:06:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3232
ERROR - 2024-09-23 12:06:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3271
ERROR - 2024-09-23 12:06:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3388
ERROR - 2024-09-23 12:06:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3507
ERROR - 2024-09-23 12:06:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3626
ERROR - 2024-09-23 12:06:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3745
ERROR - 2024-09-23 12:06:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-09-23 12:06:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-09-23 12:06:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 40
ERROR - 2024-09-23 12:06:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-09-23 12:06:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-09-23 12:06:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
ERROR - 2024-09-23 12:06:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
DEBUG - 2024-09-23 12:06:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-09-23 12:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-23 12:09:31 --> Controller Class Initialized
ERROR - 2024-09-23 12:09:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-09-23 12:09:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-23 12:09:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-23 12:09:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-09-23 12:09:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-23 12:09:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-23 12:09:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-09-23 12:09:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-09-23 12:09:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-23 12:09:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-23 12:09:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-09-23 12:09:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-23 12:09:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-23 12:09:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-09-23 12:09:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-23 12:09:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-23 12:09:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-09-23 12:09:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-09-23 12:09:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-09-23 12:09:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-09-23 12:09:33 --> Final output sent to browser
DEBUG - 2024-09-23 12:09:33 --> Total execution time: 199.8144
